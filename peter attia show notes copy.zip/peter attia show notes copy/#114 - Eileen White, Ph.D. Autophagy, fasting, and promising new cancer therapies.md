# #114 – Eileen White, Ph.D.: Autophagy, fasting, and promising new cancer therapies

**Source:** [https://peterattiamd.com/eileenwhite/](https://peterattiamd.com/eileenwhite/)

---

In this episode, Eileen White, Chief Scientific Officer at the Rutgers Cancer Institute, describes the fundamental role of autophagy in the maintenance of health and prevention of neurodegeneration, cancer, and other diseases. She also goes into detail about the paradoxical finding that autophagy may benefit an existing cancer cell and help it to survive—a discovery leading to new possibilities in cancer therapy. We also discuss fasting (and molecules that induce autophagy) and the critical need to decode the proper fasting “dose” in order to improve human health.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/eileenwhite/the_Drive_public.png)

Play

#114 - Eileen White, Ph.D.: Autophagy, fasting, and promising new cancer therapies

#114 - Eileen White, Ph.D.: Autophagy, fasting, and promising new cancer therapies

1x15s30s

0:001:58:55

## We discuss:

- Eileen’s discovery that a specific oncogene blocks apoptosis [3:40];
- Defining apoptosis and its role in cancer prevention [10:00];
- How cancer cells use the autophagy pathway to survive [17:20];
- Stressors that induce autophagy [29:15];
- The importance of autophagy in the brain and liver [32:45];
- The mechanisms that can trigger autophagy to support longevity [40:00];
- Evidence for cancer treatment by blocking autophagy [42:30];
- Types of cancer that are most autophagy-dependent [46:45];
- The autophagy paradox [52:40];
- Finding a molecular signal for autophagy [59:15];
- Current knowledge gaps around fasting as a tool for longevity [1:13:00];
- Rapamycin, metformin, and other molecules that may induce autophagy [1:22:15];
- How to study fasting and exercise as longevity tools [1:32:50];
- The Nobel Prize for autophagic research [1:36:45];
- Eileen’s future areas of research [1:38:25];
- A fasting strategy for Alzheimer’s disease prevention[1:49:25];
- Future study of metabolism and autophagy [1:51:30]; and
- More.

§

## Show Notes

## Eileen’s discovery that a certain oncogene worked by blocking apoptosis [3:40]

**When she got interested in science?**

- Eileen’s parents fostered her interested in scientific discovery
- Eileen got a Ph.D. in biology
- She studied in the department led by Dr. Arnie Levine, who discovered p53
- She then went to Cold Spring Harbor Lab where she got a postdoc with Bruce Stillman
- There were two Nobel Prizes awarded while she was there
- She then went to Rutgers to be on the faculty
- Shortly after that, they hired a cancer center director, Bill Hait, and she and Bill helped to build what’s now the [Rutgers Cancer Institute](https://www.cinj.org/)

**So where in your journey did autophagy pique your curiosity?**

- She was given an oncogene to study while a postdoc
- She found that this gene was a viral homolog of [Bcl-2](https://en.wikipedia.org/wiki/Bcl-2)
- Bcl-2 is a human oncogene and it functions by blocking apoptosis (programmed cell death)
- So she figured out that one novel function of cancer is to evade cell death
- Then the pharmaceutical industry started developing inhibitors of Bcl-2 to promote apoptosis in cancer
- That was the “*ultimate goal*”… to **make tumor cells die and have a drug that will do that**
- Eileen’s lab is still involved with taking those drugs and putting them in patients and optimizing their use in solid tumors

## Defining apoptosis and its role in cancer prevention [10:00]

**How apoptosis works**

- Family of proteins called the [Bcl-2 family](https://en.wikipedia.org/wiki/Bcl-2_family)
  - Some of the Bcl-2 like proteins (e.g., Bcl-xL) **inhibit** apoptosis so they keep tumor cells alive
  - [BH3 only proteins](https://en.wikipedia.org/wiki/Bcl-2_family#BH3-only_family) ⇒ **antagonizers** of Bcl-2 proteins and they are often activated to inhibit Bcl-2 to trigger apoptosis via the initiation Bax/Bak-dependent apoptosis
  - BAX and Bak ⇒ the core apoptotic machinery that triggers apoptosis
    - They reside in the mitochondrial membrane
    - When they’re triggered to undergo apoptosis, they oligomerize and poke holes in the mitochondrial outer membrane and that releases proteins that activate proteases to grade the cell
      - Bcl-xL, for example, and other inhibitors of apoptosis, are trying to antagonize this process

**What goes wrong in a cell for it to go down the suicidal pathway?**

- Mitochondrial damage can certainly trigger apoptosis
- But the best way to explain it is by using the example of [**p53**](https://en.wikipedia.org/wiki/P53)
  - p53 is a tumor suppressor and one of the functions is to **promote** apoptosis to prevent an emerging cancer cell from progressing
  - One mechanism by which p53 does that is by turning on the transcription of [PUMA](https://en.wikipedia.org/wiki/P53_upregulated_modulator_of_apoptosis) and [Noxa](https://en.wikipedia.org/wiki/Phorbol-12-myristate-13-acetate-induced_protein_1) (antagonizers of Bcl-2 and activators of Bax and Bak)
- *What activates p53 to do that?*
  - That could be a long list of things from DNA damage, oxidative stress, and more
- **In summary**, something bad happens to an emerging cancer cell and then p53 gets activated and one of the tumor suppression functions of p53 is to turn on these promoters of apoptosis that antagonize Bcl-2

**Mutations in p53 accounts for about half of all cancers**

- Hotspot mutations in p53 that are very common in cancer
- p53 functions as a [heterodimer](https://en.wikipedia.org/wiki/Protein_dimer)
- What these mutant p53s do is that they end up entering into a dimer with wild type subunits and that interferes with the function of the complex
- It can be a loss of function of the p53 heterodimer
- But there’s evidence that it not only causes a loss of function, but it actually may do other things as well that are cancer-promoting

**What happens post apoptosis?**

*Once it dies, does an apoptotic cell elicit any immune response or does the process of apoptosis yield sort of an inert body of cellular matter that just goes away?*

- You would get protein degradation and packaging of pieces of the dead cells into these apoptotic bodies
- And then that would reduce inflammation
- There’s evidence that macrophages can then go and take up these apoptotic bodies and that may facilitate [antigen presentation](https://www.sciencedirect.com/topics/medicine-and-dentistry/antigen-presentation)

*If your immune system devours a dead cancer cell that underwent apoptosis, do you then gain some long term immunity against that specific type of mutation?*

- Yes, says Eileen, “*I think something like that occur*s”

**Contrasting apoptosis with necrotic cell death**

- In apoptosis, you have proteolytic degradation of a cell and packaging it into these bodies and you say, ‘*Well, does that limit inflammation*?”
- Well, when you compare it to a different form of cell death like [necrosis](https://en.wikipedia.org/wiki/Necrosis)…
- Necrosis is very proinflammatory ⇒ nucleic acids are released and mitochondrial content is released (which is probably the most immunogenic given its bacterial origin of the DNA)
- Apoptosis is much “cleaner” than necrosis

## How cancer cells use the autophagy pathway to survive [17:20]

**What happens when you disable apoptosis in a cancer cell?**

- When we disable apoptosis in a cancer cell, it can’t commit suicide and tumor cells become more tumorigenic
- In the early 90s, an unexpected observation was…**the extraordinary propensity for cancel cell survival**
- We could leave the cells out and put them in buffer & they wouldn’t die under extraordinary circumstances that we couldn’t explain
  - (This was in *kidney cancer cells* from mice)

-Then the question was now “*why would a cell that just couldn’t commit suicide survive in buffer with no nutrients at all?”*

- They then discovered that these cells had **turned on autophagy and we’re using that for survival**
- *How did they see this?* ⇒ Looking through an electron microscope, they saw something they had never seen before which was: **A ton of double membrane vesicles (**[**autophagosomes**](https://en.wikipedia.org/wiki/Autophagosome)**) all over the cell**
- This was a “Eureka moment” for Eileen

-Next, they started asking ‘*What are these autophagosomes? What do they do*?’

- And in the yeast literature, they were meant to capture intracellular proteins and organelles and bring to the vacuole of the mammalian lysosome for degradation and recycling and that **this was a mechanism by which yeasts survived starvation**

–*Cancer cells using autophagy to survive:*

- Autophagosomes were already known to exist in cells in mammals
- However, there was almost no information on autophagy and cancer at the time
- And Eileen hypothesized that cancer cells were using autophagy to survive (in the same way yeast did)

*-Inhibiting autophagy reduced the survival of cancer cells*

- When autophagy was inhibited in cancer cells, in many different cell lines, **the survival of the cancer cells was reduced**

*–****Huge implications…***“if cancer cells had usurped the autophagy pathway for their survival, then we needed to inhibit autophagy for cancer therapy. “

**Does cancer use autophagy differently than a “normal” cell?**

- Normal cells in the fed state don’t have autophagy “on”… it functions at a very, very low level
- But if you starved cells for nutrients, then there’s a massive upregulation of autophagy
- What was striking about the cancer setting was… **even in the fed state, autophagy was elevated**
  - And then if you stress cancer cells, it goes up even further
  - And this was done [in vitro](https://en.wikipedia.org/wiki/In_vitro)

**In a** [**2009 paper**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) **about the** [**Warburg Effect**](https://en.wikipedia.org/wiki/Warburg_effect_(oncology))**…**

- The authors offered an alternative explanation for the Warburg hypothesis
- It might not be that the mitochondria of the cancer cells are defective and can’t undergo oxidative phosphorylation…
- …instead it might be that they’re optimizing for growth as opposed to metabolism
- In other words, they don’t care as much about ATP as they care about building blocks…
- …and therefore they’re deliberately taking an inefficient route of glycolysis to lactate because they want the cellular building blocks
- This is congruent with Eileen’s work on cancer cells and autophagy: **The tumor cell is undergoing more constant proliferation, and therefore they want more building block**

**Metabolism of cancer cells**

*-When Eileen studies the metabolism of cancer cells…*

- The metabolism of a cancer cell is designed to facilitate [de novo synthesis of nucleotides](https://en.wikipedia.org/wiki/De_novo_synthesis)
- So a common observation is that nucleotides seem to be rate limiting

*-Another observation is that the autophagy pathway can “eat” ribosomes…*

- A [paper](https://pubmed.ncbi.nlm.nih.gov/29700228/) David Sabatini has shown that a large amount of the mass of a cell is ribosomal RNA and that the autophagy pathway can cannibalize those ribosomes (ribophagy) because they’re unnecessary in a state of stress/starvation

*-Evolution preserved the ability to use autophagy over billions of years…*

- “*Something that is so important that it just doesn’t really seem to change over about a billion years. . .rule of thumb, it matters.*”
- When you compare how yeast does autophagy and how when mammals do autophagy and what they’re using it for… it just looks like the mammalian version of autophagy is a little bit more complicated.
- They have probably more different circumstances where autophagy might be necessary, but the basic process is surprisingly the same.

![](https://peterattiamd.com/wp-content/uploads/2020/06/Role-of-autophagy-in-starvation-tumor-suppression-and-tumor-promotion-White-et-al.-2015-1024x912.png)

**Figure 1. Role of autophagy in starvation, tumor suppression, and tumor promotion: A, induction of autophagy-mediated survival in starvation. B, autophagy deficiency produces the accumulation of damaged proteins, particularly p62, and organelles. This causes cell death, tissue damage, DNA damage, oncogenic signaling, chronic inflammation, stem/progenitor expansion, and tumor initiation. C, autophagy is activated in tumors and promotes survival and growth, whereas loss of autophagy causes substrate accumulation, tumor cell growth arrest, senescence, and death and restricts tumor progression to benign disease.** Image credit: ([White et al. 2015](https://pubmed.ncbi.nlm.nih.gov/26567363/?from_term=%28Eileen+White%5BAuthor%5D%29+AND+%28%28%222015%22%5BDate+-+Publication%5D+%3A+%222015%22%5BDate+-+Publication%5D%29%29&from_pos=1))

## Stressors that induce autophagy [29:15]

**Three pathways at the** ***mechanistic*** **level**:

  1—The mTOR pathway, which is mostly sensing amino acids

  2—AMPK pathway, which is mostly sensing energy and ATP in general

  3—The Acetyl-CoA protein deacetylation pathway, which is also just basically sensing substrate of fatty acid and glucose

- Those are three ways that **low nutrients** can still trigger the same pathway

  4—Additionally, stresses that result in i) organelle damage–such as depolarization or dysfunction of mitochondria, ii) activation of protein misfolding, and iii) generation of protein aggregates

*What are some stresses that come from* ***outside of the cell*** *that induce autophagy?*

- **Temperature** extremes would induce protein misfolding and induce autophagy as a remedy for that
- **Exercise** induces autophagy very potently because exercise damages the muscle, and autophagy is one of the processes that helps mitigate the damage that occurs during damage
- **Hypoxia** potently induces autophagy
  - Tumors are well known to have hypoxia in the center
  - When Eileen engineered tumor cells to be genetically deficient for autophagy, you’ll see that the tumor is hollow, meaning…
    - the further the cells get from a blood supply, the more susceptible they are to hypoxia, and they’re dead
    - The middle of a tumor is hypoxic… that’s where the autophagy is most active, and if you genetically knock out autophagy in the tumor, you end up with a hollow tumor because the tumor cells in the middle don’t survive.
  - In other words, [autophagy protects tumors from hypoxia](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(17)30209-7?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1550413117302097%3Fshowall%3Dtrue)

## The importance of autophagy in the brain and liver [32:45]

**In newborn mice**:

- In Japan, mouse strains that were made to be deficient in either of two essential autophagy genes (ATG5 or ATG7)
- In [this experiment](https://pubmed.ncbi.nlm.nih.gov/15525940/), they showed that once these mice are born, these autophagy-deficient newborn mice don’t survive more than a few hours
- They fail to survive the neonatal starvation period because period between the cut-off of the placenta and suckling is a common feature in mammals and is potent induction of autophagy during that period
- Furthermore, if they force fed the mice, they only lived for another 24 hour

> “Wow. I think that simply underscores the evolutionary preservation of something. If you knock it out, it is uniformly fatal.” —Peter Attia

**In adult mice**:

- Eileen’s team [did an experiment](https://cancerdiscovery.aacrjournals.org/content/candisc/4/8/914.full.pdf) where they engineered adult mice where they can give chemicals so that an essential autophagy gene will be deleted throughout the entire animal
- After deletion, they lived for **two to three months**
- They **died predominantly of neurodegeneration** (Autophagy is very important in the brain over the long term)
- But those same **mice would die in just 16 hours** ***if there were fasted***

**Importance of autophagy to the brain**

–*Using Alzheimer’s disease specifically as an example…*

- When you think about the toxicities that are driving neurodegeneration, there’s a lot of crap that’s basically getting accumulated in neurons
- This would be an elegant way to suggest that autophagy is keeping that at bay
- The brain, therefore, is **extremely autophagy dependent**

*-What other tissues are more (or less) autophagy dependent than others?*

- When looking at an adult mouse that lacked autophagy…
- The lungs looked relatively normal suggesting it’s not autophagy dependent
- The **liver**, on the other hand, was very sensitive
  - If you did a liver-specific knockout of an essential autophagy gene, they developed fatty liver disease
  - Suggesting that autophagy probably plays a role in preventing
    - i) fat accumulation, and
    - ii) accumulation of [mallory bodies](https://en.wikipedia.org/wiki/Mallory_body), which are large protein aggregates composed of a protein called p62

–*The difference between the brain and liver is that…*

- The liver manages to tolerate it, the brain does not and it just accumulates all the crap

*-Was there evidence that the brain, in some last ditch effort to survive, was undergoing more apoptosis of neurons?*

- Yes, a common feature is increased apoptosis in the brain
- “*This has been part of a* ***major effort to generate autophagy stimulators as a remedy or as a means to delay neurodegenerative diseases****.*”

## The mechanisms that can trigger autophagy to support longevity [40:00]

**Fasting**

“*Fasting is one of the most potent stimulators of autophagy. I spend a lot of time thinking about how does fasting fit into our toolkit of longevity…*

*…I think it’s very safe to say, based on all the animal data, and frankly all the centenarian data, that the key to living longer is delaying the onset of chronic disease…*

*…So even when you look at centenarians who are genetically gifted with tools to live longer, if you unpack what the gift is, it’s delaying the onset of the disease, not living longer once you have the disease…*

*…So the centenarians, once they get cancer and once they get heart disease, they die at about the same rate, over the same duration, as the rest of us schmucks. The difference is, they get those diseases 20-25 years later. And again, that suggests to me that if you want to live longer, you have to delay the onset of these things, not live longer once you have them…*

*…It’s hard to think that fasting doesn’t play an essential role in that when you realize the role that fasting plays in the mitigation of Alzheimer’s disease and metabolic disease.*”

**Molecules that induce autophagy**

“*We can also induce autophagy sort of pharmacologically or chemically. The first thing that would jump to your mind is anything that mimics fasting. The first thing that comes to mind would be metformin, rapamycin, and things like…*

*…We talked about these huge pathways that tell the body nutrients are scarce. So when mTOR activity is down, that’s a sign that we’re deficient in amino acids. We can also do that with rapamycin…*

*…When AMPK is up, that’s the cell being told we’re deficient in ATP. Another way that you can do that is to give Metformin.*”

## Evidence for cancer treatment by blocking autophagy [42:30]

*Eileen had two questions she wanted to answer*:

-Question 1—***If you inhibited autophagy in an adult mouse, what would happen?***

- Because if they died in an hour, then targeting autophagy for cancer therapy would be pointless
- But instead, [those mice died in 2-3 months from neurodegeneration](https://cancerdiscovery.aacrjournals.org/content/candisc/4/8/914.full.pdf)

-Question 2—***When you knock out autophagy in a mouse with cancer, which dies first: the mouse of the tumor?***

- This mouse had lung cancer
- First, shut the autophagy pathway off
- Then, see which died first, the mouse or the tumor
- *The answer*? ⇒  **Tumor died first**

*-But, what would happen if you could turn autophagy back on?*

- In a mouse model where you could toggle the autophagy off and back on, the tissues were able to restore themselves back to normal when autophagy is turned back on

“*That experiment basically becomes the* ***proof point that says targeting autophagy in cancer makes sense.***”

## Types of cancer that are most autophagy-dependent [46:45]

**Kras-driven cancers**

- Kras-driven [**lung cancer and pancreatic cancer**](https://pubmed.ncbi.nlm.nih.gov/27516533/?from_single_result=27516533&expanded_search_query=27516533) are extraordinarily autophagy dependent
- The tumors are very susceptible to the functional loss of autophagy

*-What’s KRAS?*

- KRAS is a GTP binding protein that is responsible for activating what’s called the MAP kinase pathway which is very key in driving cell proliferation
- And so, cancers have mutations in RAS that leave it in the GTP-bound or “on” state … meaning unresponsive to cell signaling, and when you are fixed in the on position, you can’t turn off

*-Why have we failed to drug KRAS cancers?*

- What’s particularly interesting about RAS driven cancers is that we have been very unsuccessful in drugging RAS given that there are too many workarounds it has in response the drugs
- However, there’s a subset of the mutations in RAS that involve a cysteine residue that there are now drugs that target that… so “*there’s hope after decades of failure.”*
  - What they’ve done is gone downstream of RAS and targeted inhibitors of Raf, MEK, and ERK and those are actively in use in the clinic
  - That said, they seem to be **not durably effective** in RAS-driven cancers because of the work-arounds

**Are there mutations or mutant drivers of cancer that we know are not dependent on autophagy, and unresponsive to the autophagy blockade?**

–*There seems to be a spectrum of sensitivity…*

- Cancers that are quite sensitive include:
  - RAS driven cancers are particularly sensitive
  - B-Raf driven cancers (e.g., B-Raf V600E) are particularly sensitive
  - Lung cancer and melanoma are examples
  - Homologous recombination deficient breast cancers
  - And those would be models of hereditary breast cancer
  - APC deficient colon cancer
  - Prostate cancer (“[we did that work](https://pubmed.ncbi.nlm.nih.gov/22241682)”)
- There is a long list of cancers that are sensitive, but the sensitivity is not all equal
  - For example, B-raf driven cancers are more sensitive than RAS driven lung cancers
- **The most sensitive cancer**: RAS-Driven Lung Cancer Without LKB1 ([Research done by Dr. Jessie Guo](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6362813/))

## The autophagy paradox [52:40]

**Contrasting observations**:

- 1—Cancer utilizes autophagy to survive
- 2—Autophagy is protective (evidenced by a mouse will die quickly without it)

*-What are these contrasting observations telling us?*

> “It’s telling us that a main function of autophagy in tissue homeostasis is to preserve cellular function to be normal, to prevent chronic damage and inflammation. And tissues that are susceptible to cancer as a result of chronic damage and inflammation, autophagy is highly protective.”

*-How do you further reconcile these contrasting observations?*

- I think it’s a matter of thinking of the role of autophagy in cancers being context-dependent.
- On the one hand, functional autophagy can delay the onset of chronic damage and inflammation that are known causes of cancer (in particular, pancreas and the liver)
- Stimulating autophagy through fasting or through pharmacologic means at one point can be thought of as preserving health
- But once you have a cancer, it’s a completely different context … and in that setting, what we’ve learned is **inhibiting autophagy is preferentially damaging to the tumor compared to the normal tissues**

**How might fasting combined with chemotherapy be superior to chemotherapy alone for cancer treatment** ([as the literature suggests](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6530042/))**?**

- Calorie restriction takes away nutrients for the cancer to grow
- Autophagy may also reduce inflammation

> “It might be that we can’t necessarily say that fasting isn’t helpful in cancer, because while it may be counterproductive from the standpoint of autophagy, that may be offset by other things that are beneficial, such as the reduction of overall nutrients and inflammation that accompany this.”

## Finding a molecular signal for autophagy [59:15]

**How do we think about using autophagy in disease prevention and disease treatment?**

- Fasting might be the most potent way to stimulate autophagy
  - (more so than metformin or exercise)
- There are biotech companies working on pharmacological agents that can stimulate autophagy (e.g., [Spermidine](https://en.wikipedia.org/wiki/Spermidine))

-Eileen asks, “*why not cultivate the use of fasting instead?*”

- Peter’s answer:
  - A big part of it is **we don’t yet have the tools to measure the signatures of autophagy**
  - In other words, we don’t know the correct “dose” of fasting, or the minimum effective dose, to enhance autophagy
  - And therefore get the benefits of being protected from every chronic disease
- What we do know…
  - After 7 days, autophagy is fully cranked
  - We also know that after 12 hours of fasting, autophagy is not stimulated
  - But in between those numbers is where it becomes much less clear

**We NEED a “signature” of autophagy, says Peter**: “*I put this in the top three most important translational questions in my field. In other words, as I think about the practice of medicine as it pertains to longevity, it’s our inability to understand how to quantify the benefit of nutrient deprivation. In other words, our inability to dose it. That is our greatest, certainly among our top three detriments, to using this incredibly potent tool.*”

**What Peter has learned from his fasting experiments:**

–*After a* ***7 day*** *fast, the following predictable changes occur…*

- Glucose plummets
- Insulin becomes unmeasurable
- [beta-Hydroxybutyric](https://en.wikipedia.org/wiki/Beta-Hydroxybutyric_acid) goes way up
- [Uric acid](https://en.wikipedia.org/wiki/Uric_acid) doubles
- Dramatic changes in endocrine system:
  - [T3](https://en.wikipedia.org/wiki/Triiodothyronine) goes down significantly
  - [Reverse T3](https://en.wikipedia.org/wiki/Reverse_triiodothyronine) goes up significantly
  - The ratio of these changes by four to six fold, which means you basically shut off metabolism
    - (Explains why you become incredibly cold intolerant during a fast)
- [Gonadotropins](https://en.wikipedia.org/wiki/Gonadotropin) go down

–*When compared to a* ***3 day*** *fast…*

- Peter noticed that after 3 days of fasting he sees **all of the same things from a 7 day fast but just not to the same magnitude**
  - That just got Peter intuitively thinking that three days was the **minimum dose** you needed to really move the needle with metabolic things (e.g., the spike in uric acid, the bottoming out of glucose)
- Other things happening after 3 days:
  - **Glucose equilibrium**—As you turn more and more free fatty acid into ketone and turn more glycerol into glucose, you reach an equilibrium where your glucose is pretty much going to stay at about three to four millimolar, and that takes about two to three days
  - AMPK way up
  - mTOR must be way down
  - Protein deacetylation must be off

**\*Peter’s dream experiment would be the following**: Get a tube of blood after a three day fast, a four day fast, a five day fast, a seven day fast, a 10 day fast, and send it to Eileen to get some sort of quantification of autophagy

**Where would Eileen look for a signature of autophagy?**

- Currently, from experiments in mice, we know that looking for LC3 proteins (measuring the rate at which LC3-I gets converted to LC3-II, and then the rate at which LC3-II ends up being degraded in the lysosome) could help you see the formation of autophagosomes
- The [Mizushima lab used that to assess autophagy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC363084/) in a living mouse by taking tissue samples and looking at them
- *What they found…* was that autophagy is turned on during fasting in a mouse, but it was **not uniform across every tissue**

*-Could this same thing be done in people?*

- Not exactly, because that involved making a genetically engineered mouse
- In people, you could look at a tissue section and stain it for LC3 and look to see if there were spots
- If you tried to look for LC3 conversion from I to II in blood samples, it would be much more challenging
- And you’d end up only being able to **infer** autophagic flux because you wouldn’t actually be able to measure it

**An proposed experiment Peter thinks could help to find a signature for autophagy in humans:**

- Hundred volunteers
- They would fast for different periods of time (Three, four, five, six, seven days, et cetera.)
- And they each would be subject to blood draws and muscle biopsies
- In the blood you could looks for things like…BHB, glucose, leucine, methionine, uric acid, then there’s probably a whole bunch of other small molecules and things in the proteome that we don’t know yet know
- **In rodents, Eileen** has also already found that [glucuronic acid](https://en.wikipedia.org/wiki/Glucuronic_acid) accumulates when they inhibited autophagy
- “We could use metabolites as surrogate markers for the consequences of autophagy.” says Eileen
- This is a project that “*so ripe for a* ***machine learning environment*****”**, says Peter
- Then you have the check, which is the muscle biopsy, which can give you some sort of quantifiable gradation.

**Something Eileen plans to explore in rodents**:

- A metabolic characterization of a **wild type mouse** fasted versus an **autophagy-deficient mouse** fasted.
- That would potentially identify the metabolic changes that were autophagy dependent
- And I think that would provide some clues as to what to look at in humans

## Current knowledge gaps around fasting as a tool for longevity [1:13:00]

**Peter finds it “ridiculous” that more attention isn’t being dedicated to finding the proper dose and frequency of a tool as potent as fasting is to human health**:

> “*Imagine we had a drug that we knew could kill cancer, but we just didn’t know how much to give or how often to give it. We wouldn’t tolerate that for a minute. In fasting we have arguably the most potent tool, and certainly if not the most potent, probably one of the three most potent tools, in which we can affect human health, and we don’t have a clue how to dose it or what frequency with which to use it. And I find that ridiculous.*” —Peter Attia

- That said, Peter is confident that if there were a really great proposal put together that would go from the animal model to the human model, it would be fully fundable through philanthropic efforts.
- He hopes that Eileen would be apart of helping him put that together

⇒ With his [Fast Mimicking Diet](https://en.wikipedia.org/wiki/Valter_Longo#Fasting_mimicking_diet) ([Prolon](https://prolonfast.com/)), [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo) asserts that it’s possible to get **most of the benefit without actually having to be fully fasted**, but to instead reduce your calories significantly for a period of five days.

- “Maybe he’s right, but we have no idea. We have no idea what the efficacy of that approach is versus a total water only fast for five days.” says Peter

⇒ [George Cahill’s 40 day starvation experiment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf)

- By about seven days into a prolonged fast, you pretty much reach a steady state
- Consistent flux of triglyceride into free fatty acid out of the fat cell.
- Steady state level of beta-hydroxybutyrate, acetoacetate, and glucose, such that basically the sum total of them in millimolar concentrations is about preserved to where you would be non fasting.
- So it begs the question, if we posit that once you reach that steady state of seven to 10 days, you’re clearly in a fully turned on autophagy state, what’s the switch look like?
- The jugular question is: **When you’re 24 hours or 48 hours or 72 hours into a fast, are you 80% of the way to the benefit or just 20%?**

–*If you look back over history…*

- Almost all cultures have fasting as part of their history
- They must have learned by trial and error that this was a healthy thing to do
- “I think that autophagy is playing a major role in promoting health in response to fasting.” says Eileen

*-Fasting vs. a pill to initiate autophagy…*

- Using fasting (as opposed to trying to find some pill you could take) seems like the easier thing to do
- The irony? ⇒ **If you took 1% of the budget that is being dispensed to find pills to stimulate autophagy, we would actually be able to answer the fasting dose question clearly**.
- However, it doesn’t mean that those things (fasting and drugs, e.g., rapamycin) can’t coexist, says Peter

**Has anyone formally studied people who are susceptible to a neurodegenerative disease and seen if fasting was helpful or not?**

- What we’ve seen indirectly is dietary restriction as opposed to just pure caloric restriction where you improve the quality of macronutrients (specifically around improving glycemic control)
- You can take people that are in an early stage of cognitive impairment and delay it and or reverse it through that type of nutritional intervention
- That *doesn’t necessarily say autophagy is playing a role* since other good things are happening like improving glucose and insulin signaling in the brain
- At minimum, we’re really starting to see **the impact of metabolism in the brain**

## Rapamycin, metformin, and other molecules that may induce autophagy [1:22:15]

**Rapamycin**

- Rapamycin is a very potent inhibitor of mTOR
- Presumably it induces some level of autophagy
- Data [suggests](https://pubmed.ncbi.nlm.nih.gov/27660271/) that rapamycin is **neuroprotective**
- It’s the only molecule that has [demonstrated](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4906330/) a longevity benefit across all four models of eukaryotic cells
  - The question is: **By what mechanism is it producing longevity?**
    - How much of that benefit is through autophagy?
    - How much of it is through inhibition of senescent cells?
    - What about the reduction of inflammation?

**Why aren’t we looking into this?**

- Peter says it’s frustrating that we have these amazing tools, but because they’re not particularly profitable, you don’t really have somebody that’s interested in answering them
  - A) These are answerable questions.
  - B) I don’t think they are billion dollar questions and studies could probably be funded by the philanthropic community
  - C) It’s hard to think of examples of where you could put dollars to work in research that would have a greater impact on human life.

–*Eileen says…*

- The biomedical community has been mostly focused on putting out fires rather than disease prevention
- But on a positive note, she sees the tide changing (At the NCI, the National Cancer Institute, a bigger interest in cancer prevention is building)

–*Peter says…*

- For the quarter of a trillion dollars that has been spent on that problem over the last 50 years…
- We have only extended the median survival by **less than about a year** (on avg.) for solid organ tumors
- And there’s not much evidence we’ve even reduced the **arrival of cancer** especially given the increase in the prevalence of type 2 diabetes, insulin resistance, and all of the metabolic dysregulation

**The main chronic diseases that account for most deaths in people above age 50**:

–*If you remove deaths related to smoking (*[*COPD*](https://en.wikipedia.org/wiki/Chronic_obstructive_pulmonary_disease)*)…*

- **82% of death** is attributable to:
  - i) cardiovascular disease,
  - ii) cancer,
  - iii) Alzheimer’s disease, and
  - iv) complications of diabetes.
- “*There’s no question that when you improve metabolic health, which you can do through fasting, you reduce the risk of all of those significantly.*”

-The question then becomes: **How much of a role does autophagy play in that?**

- There’s a compelling case that autophagy is good for **neurodegeneration** and **cancer**
  - But, *what about cardiovascular disease*?
    - Not much in the literature directly looking at autophagy and CVD
    - However, there are more than likely benefits from fasting (which inducing autophagy)
    - Peter’s interpretation of things is that the benefits of fasting in CVD are primarily mediated through the metabolic health benefits of it
      - Lower glucose
      - Lower insulin
      - Lower homocysteine in time
      - Lower inflammation generally (as opposed to something that directly pertains to apoB or the inflammatory response to that)

**Autophagy and cellular senescence**

*What’s happening when an animal or a human is undergoing autophagy with respect to either* [*SASP*](https://en.wikipedia.org/wiki/Senescence-associated_secretory_phenotype) *or just the overall* [*senescent cells*](https://en.wikipedia.org/wiki/Cellular_senescence)*?*

- It’s complicated and context dependent, says Eileen
- Evidence [suggests](https://pubmed.ncbi.nlm.nih.gov/19652542/) that SASP (the secretion of inflammatory factors that occurs during senescence) is facilitated by autophagy
- In the cancer setting, there’s also examples where loss of autophagy limits senescence

**Metformin and autophagy**

*In a fed state, if we give an animal or a human metformin, will it still induce autophagy through just the AMPK activation?*

- Yes, and I think that that’s true
- But, we don’t understand over the long term what the consequences of having autophagy or not having autophagy actually is, says Eileen
- In other words… *What is the consequence of autophagy induction by metformin?*
- It’s probably best to test that in a system where autophagy could be toggled up or down (rather than just on or off)

**Rapamycin and autophagy**

- Rapamycin has been studied liberally in everything from yeast, flies, worms, mammals
- It [**uniformly extends life**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4906330/) across all those organisms
- It’s also a potent inhibitor of mTOR (which would signal autophagy, all things equal)

*-Why isn’t this being more highly promoted and used as an anti-aging molecule?*

- Safety is the reason, says Eileen
  - It does other things such as suppress the immune system
  - Although that is dose dependent
  - In fact, this [experiment](https://pubmed.ncbi.nlm.nih.gov/25540326/) showed rapamycin is actually **immune enhancing** when given intermittently
- That said, drug companies shy away from it because when a drug is about prevention of disease, you have a much narrower margin of error
- The opposite example would be taking a group of people who will die soon of cancer anyway, there’s a bit of latitude in what can be done clinically to test whether or not there’s a small molecule or some sort of drug that will be safe and possibly have efficacy

\*Peter points out that this is **exactly the reason** we’re in the situation we’re in medically/scientifically:

> “We have a situation where I am not convinced that longevity as a game is going to be won on the back of extending the time you have a disease. I have never seen a shred of evidence to suggest that that is the answer. Everything in humans and animals points to the opposite end of the spectrum. Longevity is about delaying the time it takes until disease comes. The implication of that is **prevention is the single most important tool in the longevity toolkit**.” —Peter Attia

## How to study fasting and exercise as longevity tools [1:32:50]

**The need to study the most effective dose of fasting and exercise**

- Pharma companies are hesitant to focus on drugs that are about “prevention”
- And that fact makes a compelling case that for taking the best and safest drug of them all, **which is fasting**, and understanding how to dose it and what frequency to dose it
- The same is true for **exercise**, says Peter
- Most people need to simply do more exercise however it would be very valuable to understand the minimum effective amount

> “So both from an exercise perspective and a nutrient deprivation perspective, there’s no more low hanging fruit in terms of minimizing human suffering and understanding how these things work.” —Peter Attia

**Why Peter should start a biotech company**

- David Sabatini and Peter have discussed this possibility (although Peter says he won’t do it)
- But there’s an huge opportunity there because the metabolic response to nutrients is a black box
- And there’s probably a multibillion dollar opportunity in decoding the black box
- In other words, when we understand exactly what the response is to each different type of nutrient in every different dose and frequency and we can decode that in the way that we can do with so many other biochemical processes, you can do everything.
- There’s a drug development platform that comes out of that
- But Peter is most interested in applying this knowledge into clinical practice with patients
- The drug development side is high risk/effort but high reward
- But there’s actually very little risk in doing proper studies to find an autophagy signature
  - E.g., A mouse study to identify the 50 metabolites, proteomics signature things that are generally going up with autophagy and comparing that in an unbiased way against human subjects
    - Cost would probably be in the tens of millions of dollars (not the hundreds of millions of dollars)
- “*If you add one year of life to each human as a result of that, that’s kind of staggering.*”

\*Eileen offers a reminder: Even if you do everything ‘right” in terms of delaying disease, there are still “unlucky” people and “we can’t forget about them in the context of health and longevity and wellbeing” (something [Bert Vogelstein has found](https://hub.jhu.edu/2015/01/01/bad-luck-cancer-mutations/) in his research)

## The Nobel Prize for autophagic research [1:36:45]

The [2016 Nobel Prize](https://www.nobelprize.org/prizes/medicine/2016/press-release/) was awarded to [Yoshinori Ohsumi](https://en.wikipedia.org/wiki/Yoshinori_Ohsumi) for the genetic elucidation of autophagy

- Yeast requires nitrogen for survival
- So Ohsumi asked: *What are the genes that are required for nitrogen survival?*
- From there he identified the essential autophagy genes.
- This was sort of a high risk venture because there was no clear disease connection
- Once they discovered these essential autophagy genes in yeast, then it was apparent that there were homologs in mammals

> “Sometimes scientific discoveries are so basic that you can’t ever anticipate what it would ultimately lead to, and in this case it led to something very extraordinary.”

## Eileen’s future areas of research [1:38:25]

***How would Eileen like to spend the coming years of her career?***

- “*I would like to translate what we’ve learned about the role of autophagy in cancer and that involves developing small molecule inhibitors to inhibit autophagy for cancer therapy*.”

**Eileen’s company:** [Vescor Therapeutics](https://vescortx.com/)

- Eileen, along with [Alec Kimmelman](https://nyulangone.org/doctors/1891729877/alec-kimmelman), have started a company that is currently focusing on defining at the molecular level what the functional requirements for autophagy are in individual cancers
- This involves understanding the metabolic role of autophagy,
  - i.e., *Why does one cancer need autophagy more than another*?

*-Inflammation and autophagy*

- The newest connection is the **connection between autophagy and inflammation**
- When you **turn off** autophagy, you **stimulate inflammation**
- In the context of cancer, that can be a really good thing because the game changer in cancer therapy now is [immune checkpoint blockade](https://en.wikipedia.org/wiki/Immune_checkpoint)

*⇒ Patient case study:*

- One patient went through surgery, radiation, chemotherapy, and it all failed
- Her body was riddled with tumors
- She went on a clinical trial for immune checkpoint blockade and all the tumors melted away
- “*What we have to do is make that work for everybody*” says Eileen
- In other words, people who don’t respond to the immune checkpoint blockade **may respond to the inhibition of autophagy** … “*so that would be critically important to do*”

**Cancers responsive to immunotherapy**

- [CTLA-4](https://en.wikipedia.org/wiki/CTLA-4) and [PD-1](https://en.wikipedia.org/wiki/Programmed_cell_death_protein_1)
- Melanoma is responsive because it is so mutagenic
- Peter had a friend with [Lynch syndrome](https://www.mayoclinic.org/diseases-conditions/lynch-syndrome/symptoms-causes/syc-20374714) (a familial syndrome where people are predisposed to cancer) who developed pancreatic cancer ([adenocarcinoma](https://en.wikipedia.org/wiki/Adenocarcinoma)) which is uniformly fatal and he presented with an advanced state so he was not even a surgical candidate
- They found a clinical trial and got him in where he was given [Keytruda](https://en.wikipedia.org/wiki/Pembrolizumab)
- Five years later he is cancer free… “*so you go from unresectable pancreatic adenocarcinoma to no pancreatic cancer. Pretty remarkable.*”

-Peter asks Eileen: *Tell me how autophagy fits into that because I think I’m missing the link of why enhanced, nonspecific immune response would factor into that?*

- That’s exactly where we’re going with the research, says Eileen
- We know that tumors with a very high mutation burden respond better to immune checkpoint blockade
- *But it’s not that simple…* because there are patients with tumors that do have a high mutation burden that don’t respond and we don’t know why
- And then we also know there are tumors that have a low mutation burden that do respond.

⇒ Upcoming experiment: A mouse model of cancer with low, medium and high mutation burden using proofreading mutations and polymerase Epsilon and Delta to generate mice with cancer with various levels of mutation burden in their tumors

- From there, they can ask questions like:
  - How many mutations do you need?
  - When you have a low mutation burden, what can you do to make the immune system see that tumor?
  - Do you need only mutations in the nuclear genome?
  - What about mutations in the mitochondrial genome?
- Next is to figure out the mechanism of response to immune checkpoint blockade to make cold tumors hot
- And that’s essentially what the *loss of autophagy* is doing by promoting inflammation ⇒ **it is taking a tumor that is not killed by T-cells, that does not respond to immune checkpoint blockade, and rendering that tumor responsive**

> “This is an elegant example of stacking something that is clearly going to become a pillar of oncology, which is immune based therapy, with something that frankly is partially metabolic and partially more complicated than just metabolic therapy. So you almost add this to the layer of pieces of swiss cheese, you start to stack on top. If you have enough of them, you’re not going to be able to drop a pencil through, the cancer doesn’t survive.” —Peter Attia

**What’s the role of autophagy in the immune cell itself?**

- When you turn autophagy off in a mouse and ask: *How does that affect the basic immune response?*
  - The answer is: **Everything in the short term appeared to be completely functional**
    - [T cells](https://en.wikipedia.org/wiki/T_cell) were actually *more* antitumorigenic
- But if you knockout autophagy *for the long term* (9 months for example)…
  - Those T cells are not going to be very functional
  - But when it comes to cancer therapy, we want to know what happens *acutely* … And when you’re inhibiting autophagy, the **immune system seems to function well**, if not better, in the presence of autophagy inhibition

**Peter says this is all quite confusing…**

- “You would think that given the benefits of autophagy in preventing cancer, you would think that that would only enhance innate immunity because of the role innate immunity plays in cancer screening.”
- “It just speaks to the fact that we are still really scratching the surface of all of the different tentacles that come out of these tools.”
- “Something like fasting seems very simple and it’s simple of course to do, but it has such a set of pleiotropic extensions and benefits that it’s very unlikely that it’s about all or none.”

## A fasting strategy for Alzheimer’s disease prevention [1:49:25]

- Peter thinks Alzheimer’s disease is a great opportunity to explore whether fasting and enhancing autophagy through various means could be beneficial in prevention
- Currently, we have no way of treating/reversing AD once a person has it
  - Two big anti-amyloid drug trials were [stopped](https://medcitynews.com/2019/04/failure-of-once-promising-alzheimers-drug-reinforces-doubts-about-amyloid-beta/) because of futility
- “*If any disease demands prevention, it has to be this one. It’s hard to make the case that fasting isn’t going to play a beneficial role there*.” says Peter
- Eileen agrees but notes that we must be fully tested to know for sure

Eileen’s take on why drugs have failed in trying to treat AD: “*I think that that is the reason for these spectacular failures is they’re trying to treat a symptom of the disease rather than the cause of the disease.*”

## Future study of metabolism and autophagy [1:51:30]

*Anything else Eileen is interested in exploring?*

**How autophagy impacts metabolism**

- Eileen is really interested in **understanding in greater detail how autophagy impacts metabolism**
- Her hope is that they can identify new targets for anti-cancer therapy and/or signatures of metabolic problems

**Immunotherapy**

- She also feels like they have made huge progress in the field of immunotherapy and wants to keep pushing in that area… “*we can’t take our eyes off that ball*”

**Decoding metabolism**

- Eileen says the technology has advanced to the state where we can really start to understand this better
- By using 13C or 15N labeled tracers, you can put them into a mouse, infuse a mouse with these tracers and by looking at where they go by mass spectrometry, over different time points, you can see metabolism. . .“*And that was something that was never possible before.*”

*-You could even do this in humans…*

- [Ralph DeBerardinis](https://profiles.utsouthwestern.edu/profile/99018/ralph-deberardinis.html) at UT Southwestern is infusing isotope tracers into humans with cancer and actually measuring the metabolism of human tumors

> “This is a growing field. It’s very exciting. And understanding metabolism in mammals at a level we’ve never seen before in various disease states is tremendous.”

**Decoding the dose effect of fasting**

*Would Eileen be interested in working on figuring out the dose effect of fasting and a signature for autophagy?*

- Yes, says Eileen

“*I am very much interested in fasting as a way to preserve health…I’m also interested in the dietary part, because I think all of this has to go together. It’s not just how many calories you eat or how often you eat them, it’s what they are.*”

§

## Selected Links / Related Material

**Select publications by Eileen White’s lab**: [White Laboratory – Select Publications](https://www.cinj.org/research/white-laboratory-select-publications) | (cinj.org)

**Cancer center that Eileen helped to build**: [Rutgers Cancer Institute](https://www.cinj.org/) | (cinj.org) [6:25]

**2009 Warburg effect review by Matt Vander Heiden, Thompson, and Cantley that provided a more complex explanation for the Warburg Effect**: [Understanding the Warburg Effect: The Metabolic Requirements of Cell Proliferation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) (Vander Heiden, et al., 2009) [25:15]

**David Sabatini’s “beautiful” paper where he was making the argument that ribophagy, the autophagy of ribosomes, was an important metabolic survival mechanism**: [NUFIP1 Is a Ribosome Receptor for Starvation-Induced Ribophagy](https://pubmed.ncbi.nlm.nih.gov/29700228/) (Wyant et al., 2018) [27:15]

**Autophagy protects tumors from hypoxia**: [Autophagy and Tumor Metabolism](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(17)30209-7?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1550413117302097%3Fshowall%3Dtrue) (Kimmelman and Whilte, 2017) [31:55]

**Autophagy deficient newborn mice only survive for a few hours**: [The Role of Autophagy During the Early Neonatal Starvation Period](https://pubmed.ncbi.nlm.nih.gov/15525940/) (Kuma et al., 2004) [33:00]

**Eileen’s study showing that knocking out autophagy in a mouse cause them to die from neurodegeneration within 2-3 months**: [Autophagy Is Required for Glucose Homeostasis and Lung Tumor Maintenance](https://cancerdiscovery.aacrjournals.org/content/candisc/4/8/914.full.pdf) (Karsli-Uzunbas et al., 2014) [35:25, 43:45]

**Kras-driven lung cancer and pancreatic cancer are extraordinarily autophagy dependent and the tumors are very susceptible to the functional loss of autophagy**: [Autophagy Provides Metabolic Substrates to Maintain Energy Charge and Nucleotide Pools in Ras-driven Lung Cancer Cells](https://pubmed.ncbi.nlm.nih.gov/27516533/?from_single_result=27516533&expanded_search_query=27516533) (Guo et al., 2016) [47:15]

**Eileen’s work showing prostate cancer is sensitive to autophagy inhibition**: [Effect of Dual Inhibition of Apoptosis and Autophagy in Prostate Cancer](https://pubmed.ncbi.nlm.nih.gov/22241682) (Saleem et al., 2012) [50:55]

**The most sensitive cancer to autophagy inhibition is RAS-Driven Lung Cancer Without LKB1**: [Autophagy modulates lipid metabolism to maintain metabolic flexibility for Lkb1-deficient Kras-driven lung tumorigenesis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6362813/) (Bhatt et al., 2019) [52:00]

**Literature suggesting that fasting combined with chemotherapy is superior to just chemotherapy in cancer treatment**: [Effects of short-term fasting on cancer treatment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6530042/) (de Groot et al., 2019) [57:45]

**AMA episode of The Drive discussing Peter’s 3-day fasting regimen**: [#108 – AMA #13: 3-day fasting, exogenous ketones, autophagy, and exercise for longevity](https://peterattiamd.com/ama13/) | Peter Attia (peterattiamd.com) [1:03:00]

**Mizushima Lab made a mouse that had a transgenic LC3-GFP protein expressed used that to assess autophagy in a living mouse**: [In Vivo Analysis of Autophagy in Response to Nutrient Starvation Using Transgenic Mice Expressing a Fluorescent Autophagosome Marker](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC363084/) (Mizushima et al., 2004) [1:06:10]

**Valter Longo’s dietary protocol that mimics fasting**: [ProLon Fast | Fasting Mimicking Diet](https://prolonfast.com/) | (prolonfast.com) [1:15:45]

**Rabinowitz and White have used 13C-labeled glucose and amino acids in mice to see how different tissues use them and how there’s nutrients sharing between tissues**: [Glucose feeds the TCA cycle via circulating lactate](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5898814/) (Hui et al., 2018) [1:16:30]

**George Cahill’s famous study fasting subjects for 40 days**: [Ketoacids? Good medicine?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf) (Cahill and Veech, 2003) [1:18:45]

**Rapamycin, a potent inhibitor of mTOR, extends life and is across everything from yeast, flies, worms, mammals**: [Rapamycin: An InhibiTOR of Aging Emerges From the Soil of Easter Island](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4906330/) (Apelo and Lamming, 2016) 1:22:15, [1:30:30]

**Some data that suggests that rapamycin is neuroprotective**: [Neuroprotection Through Rapamycin-Induced Activation of Autophagy and PI3K/Akt1/mTOR/CREB Signaling Against Amyloid-β-Induced Oxidative Stress, Synaptic/Neurotransmission Dysfunction, and Neurodegeneration in Adult Rats](https://pubmed.ncbi.nlm.nih.gov/27660271/) (Singh et al., 2017) [1:22:15]

**Evidence that SASP is facilitated by autophagy**: [Autophagy Facilitates Oncogene-Induced Senescence](https://pubmed.ncbi.nlm.nih.gov/19652542/) (Narita et al., 2009) [1:28:30]

**Data suggesting rapamycin is immune enhancing when given intermittently**: [mTOR Inhibition Improves Immune Function in the Elderly](https://pubmed.ncbi.nlm.nih.gov/25540326/) (Mannick et al., 2014) [1:31:00]

**Bert Vogelstein has found that “bad luck” plays a big role in who gets cancer**: [Bad luck plays larger role than environmental, genetic factors in determining who gets cancer | HUB Staff Report](https://hub.jhu.edu/2015/01/01/bad-luck-cancer-mutations/) (hub.jhu.edu) [1:36:00]

**The 2016 Nobel Prize was awarded to Yoshinori Ohsumi for the genetic elucidation of autophagy**: [The Nobel Prize in Physiology or Medicine 2016](https://www.nobelprize.org/prizes/medicine/2016/press-release/) | (nobelprize.org) [1:36:45]

**Company started by Eileen and Alec Kimmelman  in order to translate knowledge about the role of autophagy in cancer and into developing small molecule inhibitors to inhibit autophagy for cancer therapy**: [Vescor Therapeutics](https://vescortx.com/) | (vescortx.com) [1:38:45]

**Two enormous failures in the anti-amyloid beta drug trials**: [Failure of once-promising Alzheimer’s drug reinforces doubts about amyloid beta](https://medcitynews.com/2019/04/failure-of-once-promising-alzheimers-drug-reinforces-doubts-about-amyloid-beta/) | Alaric Dearment (medcitynews.com) [1:49:30]

**Ralph DeBerardinis is infusing isotope tracers to humans with cancer and measuring the metabolism of tumors**: [Isotope Tracing of Human Clear Cell Renal Cell Carcinomas Demonstrates Suppressed Glucose Oxidation In Vivo](https://pubmed.ncbi.nlm.nih.gov/30146487/?from_single_result=30146487&show_create_notification_links=False) (Courtney et al., 2018) [1:53:45]

§

## People Mentioned

- [David Sabatini](https://biology.mit.edu/profile/david-sabatini/) [3:45, 27:15, 1:33:45, 1:52:45]
- [Arnie Levine](https://en.wikipedia.org/wiki/Arnold_J._Levine) [5:00]
- [Bruce Stillman](https://www.cshl.edu/research/faculty-staff/bruce-stillman/) [5:00, 7:55]
- [Bill Hait](https://leadingdiscoveries.aacr.org/dr-william-n-hait-a-visionary-with-a-focus-on-patients/) [6:25]
- [Noboru Mizushima](https://molbiolut.jp/en/member/%e6%b0%b4%e5%b3%b6%e3%80%80%e6%98%87/) [33:00]
- [Jesse Guo](https://www.cinj.org/research/profile-jessie-yanxiang-guo-phd) [52:00]
- [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo) [1:15:45]
- [Josh Rabinowitz](https://scholar.princeton.edu/rabinowitz/home) [1:16:30]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) [1:18:45]
- [Bert Vogelstein](https://en.wikipedia.org/wiki/Bert_Vogelstein) [1:36:00]
- [Yoshinori Ohsumi](https://en.wikipedia.org/wiki/Yoshinori_Ohsumi) [1:36:45]
- [Alec Kimmelman](https://nyulangone.org/doctors/1891729877/alec-kimmelman) [1:38:45]
- [Ralph DeBerardinis](https://profiles.utsouthwestern.edu/profile/99018/ralph-deberardinis.html) [1:53:45]

§

![](https://peterattiamd.com/wp-content/uploads/2020/06/e-white.jpg)

##### Eileen White, Ph.D.

Dr. Eileen White, Ph.D. is the Chief Scientific Officer and Deputy Director for Basic Science at the Rutgers Cancer Institute of New Jersey, an NCI-designated Comprehensive Cancer Center. She is also a Distinguished Professor of Molecular Biology and Biochemistry at Rutgers University. Dr. White currently serves on the Board of Scientific Advisors for the National Cancer Institute.

Current research of the White Laboratory at the Rutgers Cancer Institute of New Jersey is focused on determining the role of the catabolic process of autophagy in protein and organelle homeostasis, and how this recycling of cellular components sustains cancer metabolism and tumorigenesis.

She is the recipient of numerous awards including a MERIT award from the National Cancer Institute, the Red Smith award from the Damon Runyon Cancer Research Foundation, a Howard Hughes Medical Institute Investigatorship, an Achievement Award from the International Cell Death Society, a Career Award for the European Cell Death Organization, and is an elected Fellow of the American Society of Microbiology (ASM) and the American Association for the Advancement of Science (AAAS).

She is currently on the External Advisory Boards of the Yale, Case, and MGH Comprehensive Cancer Centers and her Editorial Board memberships have included Genes & Development, Cancer Discovery, the Journal of Cell Biology, Oncogene, Cancer Prevention Research, Molecular Cancer Research, Autophagy and Cell Death and Disease. [[vescortx.com](https://vescortx.com/about-us/scientific-advisors/)]