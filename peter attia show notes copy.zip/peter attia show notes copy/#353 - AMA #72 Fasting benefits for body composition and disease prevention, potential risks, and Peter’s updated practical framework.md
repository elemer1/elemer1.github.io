# #353 – AMA #72: Fasting: benefits for body composition and disease prevention, potential risks, and Peter’s updated practical framework

**Source:** [https://peterattiamd.com/ama72/](https://peterattiamd.com/ama72/)

---

In this “Ask Me Anything” (AMA) episode, Peter revisits the topic of fasting, sharing how his thinking has evolved over time. The episode explores fasting-related terminology and common types of fasting, as well as the various reasons individuals might choose to fast. Peter explores potential benefits including improvements in body composition, metabolic health, lifespan extension, cardiovascular disease, cancer prevention and treatment, neurodegenerative conditions such as Alzheimer’s and Parkinson’s, and autoimmune symptoms like arthritis. He also examines the risks and potential downsides of fasting and offers a practical framework to help assess when and how fasting may be most appropriately applied.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #72 show notes page](https://peterattiamd.com/ama72). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Why the topic of fasting is being revisited [1:45];
- The importance of being open to changing one’s opinion in science and medicine as new evidence emerges [4:15];
- Defining fasting and how it fits in the framework of dietary restriction, time-restricted feeding, and calorie restriction [7:30];
- The most common types of fasting [11:45];
- Why someone might choose fasting over continuous caloric restriction [19:00];
- The biochemical effects of fasting: fuel partitioning, autophagy, and more [21:00];
- Autophagy: a cellular cleanup process stimulated by fasting and energy depletion [26:00];
- Comparing the physiological effects of a ketogenic diet to those of long-term fasting [27:45];
- How long fasting takes to induce ketosis and boost autophagy, and how autophagy is measured [29:45];
- At-home tests for ketones [33:45];
- Reducing senescent (“zombie”) cells and inflammation through autophagy [35:00];
- Examining the evidence for the long-term health benefits of fasting beyond short-term metabolic effects [37:15];
- The common health claims associated with fasting across metabolic, neurological, oncological, autoimmune, and longevity domains [40:30];
- The impact of fasting on body weight and body composition [42:00];
- Weight regain and potential metabolic consequences of fasting [44:00];
- The risk of lean mass loss with fasting and how to mitigate it [47:15];
- A practical framework for using fasting as a strategy to improve body composition [52:15];
- How extended fasting compares to caloric restriction in improving insulin sensitivity in people with insulin resistance or type 2 diabetes [54:00];
- Is there any evidence that fasting can extend lifespan? [55:45];
- Examining whether fasting improves cardiovascular disease risk beyond the effects of weight loss and calorie reduction [58:15];
- Exploring whether prolonged fasting can reduce cancer risk [59:45];
- The potential benefits of fasting or fasting-mimicking diets during cancer treatment: emerging evidence and practical considerations [1:02:15];
- Fasting for protection against neurodegenerative diseases: early evidence of therapeutic benefit and open questions [1:10:45];
- Various fasting methods for autoimmune diseases: potential symptom relief with cautious application [1:14:00];
- Fasting and type 1 diabetes: risks, evidence, and careful dietary alternatives [1:16:45];
- Fasting and gut disorders: potential benefits outside of flare-ups [1:18:45];
- The primary risks and downsides associated with fasting [1:19:45];
- The essential vitamins and minerals to supplement during prolonged fasting [1:21:30];
- Who should avoid fasting and why [1:22:15];
- Fasting’s role in health: where it shows promise and where it likely offers no distinct advantage over caloric restriction [1:23:45]; and
- More.

---

The Peter Attia Drive

#353 – AMA #72: Fasting: benefits for body composition and disease prevention, potential risks, and Peter’s updated practical framework

---

## Show Notes


---

## Why the topic of fasting is being revisited [1:45]

**The topic of Fasting**:

- First time fasting was covered in [AMA #11](https://peterattiamd.com/ama11/), released January 2020.
- This episode is AMA #72, highlighting how long it’s been since they fully addressed the topic.

Rationale for Revisit

- Fasting is a highly requested and frequently misunderstood topic.
- Though touched on in various episodes since AMA #11, this is the first full dedicated revisit.
- Peter’s thinking has evolved since then, including patient application and personal practice.

Episode Structure Preview

- Clarifying Terminology
  - Acknowledgment that confusion arises from inconsistent definitions (e.g., “fasting” means different things to different people).
  - First goal of the episode: define terms and types of fasting protocols.
- Main Content Themes
  - Reasons people choose to fast and the purported or actual benefits.
- Topic areas include:
  - Body composition
  - Metabolic health
  - Lifespan / longevity
  - Cardiovascular disease
  - Cancer (prevention and treatment)
  - Neurodegenerative diseases (e.g., Alzheimer’s, Parkinson’s)
  - Autoimmune conditions (e.g., arthritis)
- Risks and Downsides
  - Will explore potential negative effects of fasting and who should be cautious.
- Practical Application
  - The episode will close with a framework to:
    - Help listeners decide how (or if) to use fasting.
    - Show how Peter uses fasting personally and with his patients.

## The importance of being open to changing one’s opinion in science and medicine as new evidence emerges [4:15]

**Why Changing Opinions Matters**

- Peter is known for changing his mind when new evidence emerges.
- References the “Strong Convictions, Loosely Held” theme used in milestone episodes like [#200](https://peterattiamd.com/strong-convictions-loosely-held-2/) and [#300](https://peterattiamd.com/ep-300-exercise-nutrition-fasting-more/).
- This episode focuses on fasting, a topic where Peter’s views have evolved over time based on new data and clinical experience.
- Many public figures—and people in general—become overly attached to their initial beliefs and resist change.
- When someone changes their mind publicly, people often criticize them by saying, “How could you say this if you used to say that?”

Peter’s Response: A Framework for Intellectual Flexibility

- Everyone—not just scientists or doctors—should be open to changing opinions in light of new information.
- In today’s world, especially in politics, changing your mind is often seen as a weakness. The more firmly someone sticks to their opinion, the more credible they appear.
- Changing your mind should be seen as a strength, not a flaw.
- Science is inherently probabilistic, not absolute. Even facts that feel like certainties (e.g., gravity) are grounded in probabilities.
- Medicine and science evolve constantly. No belief should be held with rigid certainty.

Examples of Changing Positions

- Peter received backlash for changing his position on GLP-1 agonists (e.g., Ozempic, Wegovy).
  - See episodes #[184](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/), [246](https://peterattiamd.com/ama45/), [279](https://peterattiamd.com/ama53/), [320](https://peterattiamd.com/ama64/)
- He quotes economist [John Maynard Keynes](https://en.wikipedia.org/wiki/John_Maynard_Keynes): “*When the facts change, I change my mind. What do you do, sir?*”

Guiding Principle

- Peter is not wed to being right—he is wed to knowing what is right.
- He recommends that others adopt the same orientation: focus on truth and growth, not ego or consistency.
- Constant evolution of understanding is the best way to stay aligned with reality.

## Defining fasting and how it fits in the framework of dietary restriction, time-restricted feeding, and calorie restriction [7:30]

**Establishing a Foundational Nutrition Framework**

- Energy balance is essential: consuming too much or too little is harmful.
- Adequate protein intake is a constant requirement for maintaining lean mass.
- The ratio of carbohydrates to fats is less important as long as total energy intake is appropriate.
- Sufficient micronutrient intake and avoiding toxins are also fundamental.
- For over 80% of people (based on Peter’s clinical experience), maintaining energy balance requires effort and strategy.

Peter’s DR/TR/CR Framework

- DR (Dietary Restriction): Deliberately restricts a specific dietary element.
  - Can involve limiting carbs, fats, animal products, or processed foods.
  - No single best method—many forms can work if the restriction is significant enough.
- TR (Time restriction): Limits the eating window each day without necessarily changing food quality or quantity.
  - Also referred to as intermittent fasting.
  - Narrowing the eating window often naturally reduces caloric intake.
- CR (Caloric Restriction): Focuses on reducing total calories consumed, regardless of the type or timing of food.
  - May not involve food type or timing changes—just smaller portions.
- These strategies can be combined.
  - Example: During peak cycling performance, Peter used both DR and TR, eating one snack and one meal daily, with significant dietary constraints, resulting in being 16–17 pounds lighter than his current weight.

Clarifying the Term “Fasting”

- “Fasting” lacks a standardized definition and is used broadly.
- It can describe:
  - Complete water-only fasting for multiple days.
  - Daily time-restricted feeding (e.g., 16:8 or 18:6 fasting windows).
- The discussion in the episode will further explore various fasting protocols, their definitions, and their pros and cons.

## The most common types of fasting [11:45]

In this figure, you can see what an ADF protocol might look like—the pink squares on this over the course of a seven-day week show you days of either complete or significant caloric restriction:

![](https://peterattiamd.com/wp-content/uploads/2025/06/f1-ama72-1024x582.png)

**Figure 1.** [[source](https://www.embopress.org/doi/full/10.15252/emmm.202114418)]

**Types of Fasting Explained**

- Intermittent Fasting (IF):
  - Generally refers to food abstinence lasting from 12 to 36 hours, depending on definitions used.
  - Subtypes include:
    - Time-Restricted Eating (TRE): Eating only within a narrow daily window (typically 6–8 hours). Peter considers <16 hours of fasting as borderline TRE, with 16–18 hours being more common.
    - Alternate-Day Fasting (ADF): Alternating between normal eating days and fasting or very low-calorie days (0–25% intake).
- Periodic Fasting:
  - Involves stretches of normal eating followed by one or more consecutive days of full caloric restriction.
- Long-Term Fasting:
  - Continuous fasting lasting multiple days (e.g., 3–10 days or more).
- [Fasting-Mimicking Diet](https://gero.usc.edu/2024/02/20/fasting-mimicking-diet-biological-age/) (FMD):
  - Hypocaloric feeding over 4–5 days, with first day ~750 calories and remaining days ~500 calories.
  - Developed and trademarked by [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo) at USC.

Historical Anecdote: The Longest Fast on Record

- [Angus Barbieri](https://en.wikipedia.org/wiki/Angus_Barbieri%27s_fast)‘s Medically Supervised Fast:
  - Lasted 382 days (tea, coffee, sparkling water, vitamins, yeast extract only).
  - Started at ~450 lbs and ended at ~170–175 lbs.
  - [Maintained normal weight](https://pmc.ncbi.nlm.nih.gov/articles/PMC2495396/) even 6–7 years post-discharge.
  - This story was initially included in Outlive but was cut during editing.

Peter’s Personal Fasting Experience

- Has done:
  - TRE extensively for years.
  - Long-term water-only fasts ranging from 3 to 10 days.
    - For ~3 years, fasted quarterly for 7–10 days and monthly for 3 days.
  - FMD (Valter Longo’s version).
- Has not done ADF (alternate-day fasting).
- Peter says it is difficult to compare fasting protocols because many haven’t been directly studied.

Reflections on Extreme Fasting

- Despite curiosity, Peter never seriously considered replicating Angus Barbieri’s 382-day fast.
- Notes the emotional challenge of breaking long fasts—often felt like he could’ve done one more day.
- Emphasizes caution with refeeding after extended fasts due to potential health risks.

## Why someone might choose fasting over continuous caloric restriction [19:00]

**Why People Choose Fasting Over Continuous Caloric Restriction (CR)**

- Continuous Caloric Restriction Is Very Difficult:
  - Maintaining a constant 700 kcal/day deficit requires living in a persistent state of hunger.
  - This leads to ongoing discomfort, making it psychologically and physically challenging to sustain.
- Fasting Offers a More Tolerable Alternative:
  - Periodic fasting allows for short bursts of hunger, followed by normal eating periods.
  - This structure may be easier to adhere to for many individuals.
  - Peter finds it more manageable and notes patients often report the same.
- Efficacy for Weight Loss:
  - Peter believes continuous CR might be more effective than fasting when it comes to pure weight loss.
  - Fasting, if done enough, can still lead to a net energy imbalance, but isn’t necessarily the best tool for this purpose.
- Lean Mass Loss from Fasting:
  - During Peter’s 3-year stretch of frequent fasting, he lost about 20 pounds—much of it lean mass.
  - It took him approximately 18 months to regain that lean mass, illustrating a significant downside to fasting for body composition.
- Key Takeaway:
  - Fasting may be easier to implement, but caloric restriction may be more effective for weight loss.
  - The ideal approach depends on the person’s objective and their tolerance for hunger or dietary structure.

## The biochemical effects of fasting: fuel partitioning, autophagy, and more [21:00]

**Biochemical Effects of Fasting**

- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.), a renowned Harvard metabolic scientist, conducted pivotal 1960s fasting studies on healthy medical students—putting them on 40-day supervised fasts. These studies provided foundational knowledge of fasting physiology. (Note: these studies would likely be considered unethical by today’s standards.)

In the figure below, we’re looking at what’s happening in the muscle, what’s happening in the fat, and what’s happening in the liver. That’s what’s shown in the top curves of the figure:

![](https://peterattiamd.com/wp-content/uploads/2025/06/f2-ama72-1024x690.png)

**Figure 2.** [[source](https://journals.physiology.org/doi/full/10.1152/physrev.00006.2022?utm_term=apspublications&utm_campaign=&utm_medium=twitter&utm_source=hootsuite&utm_content=7e33698c-959d-4960-842f-f2ba5fcdd169)]

- The physiology of fasting can be divided into three distinct metabolic phases:
  - **Postprandial phase**: Shortly after eating, glucose rises, triggering insulin release, which promotes fat storage and prioritizes glucose as the body’s main energy source.
  - **Postabsorptive phase**: A few hours after a meal, glucose and insulin decline, and the body shifts to using fatty acids and hepatic glucose to meet energy needs.
  - **Fasting phase**: After an extended fast, the body enters a state where glucose primarily fuels the brain, while muscles rely on fatty acids. The liver still provides glucose (~60 mg/dL in Cahill’s data), but ketones become the dominant brain and heart fuel.
- Key difference between fasting and continuous caloric restriction:
  - In caloric restriction (especially if carb-rich), the body may stay in a postprandial or postabsorptive state most of the time.
  - In fasting, especially past 3–5 days, the body enters a true fasted state, with ketones rising above glucose levels, leading to distinct metabolic effects.
- Peter noted that in the figure above, it mistakenly suggests ketones exceed glucose on day 2 of fasting, which is only possible if starting from a ketogenic state.
  - But for anybody entering this from a mixed macro diet, the crossover point happens on days 3 to 5.
- Ketones become the primary energy source for the brain and heart, while glucose supports about 40% of brain function, with the rest supplied by ketones.
- Fat breakdown (lipolysis) accelerates dramatically in fasting, supporting energy demands through fatty acids and ketone production.

## Autophagy: a cellular cleanup process stimulated by fasting and energy depletion [26:00]

Additional Physiological Processes During Fasting

- In addition to metabolic shifts (glycogen depletion, ketone production), autophagy is a significant cellular process activated during fasting.
- Autophagy (from *auto* = self, and *phagy* = eating) involves the degradation and recycling of cellular components like proteins and organelles.

Triggering Autophagy

- A key trigger is a drop in glycogen levels—this is why fasting stimulates it.
- However, fasting is not the only way to induce autophagy:
  - Exercise also stimulates autophagy due to glycogen depletion.
  - Any state of underfeeding or reduced fuel availability can trigger it.

Importance of Autophagy

- It is widely accepted that autophagy is beneficial. Lack of autophagy is associated with severe consequences:
  - Peter references a past [podcast episode featuring Eileen White](https://peterattiamd.com/eileenwhite/), which discussed a [study](https://watermark.silverchair.com/914.pdf?token=AQECAHi208BE49Ooan9kkhW_Ercy7Dm3ZL_9Cf3qfKAc485ysgAAA0MwggM_BgkqhkiG9w0BBwagggMwMIIDLAIBADCCAyUGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQMDzRHTY9uzyQmRgQWAgEQgIIC9keH9d8DP-jLL8CQ9d17r9Tump2OUGoARdUh0oe90GfDBg2lup55EtnYMgeoKNh6up-VpUrgigWU8vN7vgKb8Z09Ulnmk9wWoYzW4UOeR3XItFppcPUWJ-VZLLzr7zLCALqJ6VllL888oT4fEA3eATBlnRLUE103zta2KQHMMtUHChmYwrzycXIWmgsz4mOtqn6Za7PQ_kyeD0HACecg5oTEtRhkPQkt0rML-nSD-3-4o0OavSIuOcTtugsw4RTxiuMSQytLFjuHpkdoJnhvh-1FkJeYQtsh1HUCEwk7P-gApe_xsc0XwEK6wwZK-u0Xk8O3vdYHAJVsdL6qhxW7BRCfBGp9IIE_6yQBGDzPqK16SnsZx8ejyjXO89WSYwrTPMaJ1AN6s12NdqEV9tC40pIpYRZAHycuQo2Vtbg4Zyw0yh8aiKeu-yZqEHgjjZdoucj4Led06e2NcLeHYvWldjyQ992PyJEQSHaVmdFJ9I1wZXkFq0s092uIK4qohlAwZbSYkYVO_fjScrkGNojJN5u-kFDm_9zTcviXv1nQ8KlDvjCB7Zj1s2B2Z1Zn2D1gYCaqviqZStZ5EB_3oZDGVepik8HfyzbV2bww85Rsnu1YwJgtp1Yz1EOZNkh1KsHmFipYJZMyF0khXIESJz02le-4NwaTau_gqltfTrcWXi4rBiSQfz4txxiMSlQbWF98dj7R2l28X-lrH_E2v4ORdylH5r-zfdoHqjLqUEQiL5A1J1ntM9ndPyYZocQWG1QwMr_8qMlMWjTGUo5B_rpHSPonU8xJkX-ntoP25T4bcIVl51gW5fm6QvlTyLeJ3dxkZGse_2_7WrwLldOxFbkEgCyRXiKFeJU3RKhjTqkoArjeG5fHgP42ZfzD8XOawgvzo55swRq_Ucpa7kNgxr_0MyvHSZoVA4B6DBDlCibqgEq8ZjdfDoTOCiMJPkxuH8K3aOkOrBjYxx_8R4zOFNaXMNYG-wqOEzTucNLAaRaaTxeoyheMFZRN) showing mice with genetic defects preventing autophagy experienced fatal neurodegenerative conditions.
- Given its role in cellular maintenance, autophagy is considered one of the main benefits of prolonged fasting and may underlie its potential effects on:
  - Lifespan extension
  - Reduction in chronic disease risk
  - Especially evident in animal models

## Comparing the physiological effects of a ketogenic diet to those of long-term fasting [27:45]

**Ketogenic Diet vs. Long-Term Fasting**

Peter’s Personal Background in Dietary Experimentation

- Peter reflects on his extensive personal experimentation with various dietary protocols over the past 15 years.
- Peter followed a strict ketogenic diet for three years straight and even tried veganism for six months.
- This level of experience contextualizes his comments and positions him as someone who has tested the effects firsthand.

What Defines a Ketogenic Diet

- A ketogenic diet is defined by severe carbohydrate restriction.
- Most people need to consume fewer than 30–50 grams of total carbohydrates per day to achieve a biochemical state that closely mimics fasting.
- This level of carbohydrate restriction causes profound glycogen depletion and pushes the body to rely on ketone production, similar to fasting.
- Achieving and maintaining this state requires deliberate and sustained effort.

Similarities Between Ketogenic Diet and Long-Term Fasting

- Both dietary strategies induce glycogen depletion, which plays a key role in shifting metabolic states.
- Some benefits seen in long-term fasting are also seen in a ketogenic diet, including:
  - Increased ketone production
  - Some stimulation of autophagy
  - Improved metabolic flexibility

Differences Between the Two

- While a ketogenic diet can stimulate autophagy due to glycogen depletion, it likely does not do so to the same extent as a prolonged fast.
- The ketogenic diet does not seem to reduce oxidative stress as significantly as long-term fasting.
- These differences are based on the best available scientific data, though Peter acknowledges more research is needed.

## How long fasting takes to induce ketosis and boost autophagy, and how autophagy is measured [29:45]

**Fasting Duration to Achieve Ketosis and Autophagy**

*How long does someone need to fast to be in ketosis and then see those increases in autophagy?*

- Peter explains that for someone coming from a standard macronutrient diet (roughly 50% carbs, 20% protein, 30% fat), ketosis begins to initiate around 16 hours after their last meal.
- At this point, the body starts producing beta-hydroxybutyrate (BHB), a key ketone body, at a concentration of about 0.1–0.2 mmol.
- By 24 hours into a fast, BHB levels typically reach 0.3–0.4 mmol, and by 0.5 mmol, people often begin to feel appetite suppression and increased energy—markers that ketosis is taking effect.
- Most people will enter this functional ketosis zone between 24–36 hours.
- Deeper ketosis—defined as BHB levels above 2 or 3 mmol—can take 2 to 4 days, depending on factors such as metabolic rate and prior fasting experience.
- Peter notes his own peak ketone level was 6–7 mmol, which occurred during long, extended fasts and required carefully managing exercise levels to boost ketone production.

Autophagy Timeline and Triggers

- Autophagy generally initiates around 16 to 20 hours into a fast.
- The process ramps up and likely plateaus between Day 1 and Day 3 of fasting.
- This cellular cleanup mechanism is stimulated by multiple factors, including:
  - Glycogen depletion
  - Decreased insulin levels, since insulin suppresses autophagy
  - Increased AMPK (AMP-activated protein kinase) activity, which is triggered when ATP levels drop and ADP/AMP ratios rise

Biochemical Pathways and Related Interventions

- Peter mentions three different mechanisms that can stimulate autophagy:
  - Fasting and ketosis → activate autophagy via AMPK
  - Metformin → activates AMPK
  - Rapamycin → activates autophagy via mTOR inhibition
- These pathways were [previously discussed](https://peterattiamd.com/metformin-and-longevity/)

Challenges in Measuring Autophagy in Humans

- Unlike ketones or glucose, autophagy cannot be measured non-invasively.
- There is no fingerstick, urine test, or breath test available to determine autophagy status.
- Research studies must rely on muscle biopsies, circulating leukocyte analysis, and gene expression to assess autophagy.
- These tests look at specific cellular structures and filaments that form during autophagy.
- As a result, most of what we know about autophagy in humans is inferred from animal models and limited human studies.

## At-home tests for ketones [33:45]

*If someone wants to track ketosis, is there an at-home test that exists where they can measure that to see where they are in that potentially one to two, three-day window?*

- Ketosis is easy to measure at home
- Peter confirms that tracking ketosis at home is very easy, unlike autophagy, which remains difficult to measure non-invasively.
- He shares his personal experience from his fasting days, explaining that he used finger stick blood tests to measure beta-hydroxybutyrate (BHB) levels.
- Peter used two devices in parallel:
  - The [Abbott Precision Xtra](https://abbottstore.com/diabetes-management/precision-brand/precision-brand/precision-xtra-blood-glucose-ketone-monitoring-system-1-pack-9881465.html?srsltid=AfmBOorHwV2JIQoaPvchwas_VVQGRpf25iCIlHJMXR4jzMotflvQewvh) device for ketone measurement.
  - A device called [Keto-Mojo](https://www.amazon.com/KETO-MOJO-Bluetooth-Diabetes-Management-Solutions/dp/B08G5BZQVL/ref=sr_1_1_sspa?dib=eyJ2IjoiMSJ9.I1oiXoUt_nJup6Rkd5QA3RXJMiaXdcXvIKbox6dzQtN4WEhlPgYgS6XbcgQc1DMWv2JezpgYdm_EmIimr3tIUSNI9k8qptv0ikrDF4S26wZJg-VbBzNaKJVuDYMO27Mm-RSaU3PNTVWDI3JlwnX1W4ufkY4mlZP_xiPnGZM1cIa-U4HUOuxVyzYfHU_pM_z2hPcPm_YE6BHnlmjtU143B4oXbHoLqPtrqotZekKdcDlEgQnxkbrGnJ3u7NvCD2ABuOKJ3OmW6KNrZ1fG2UgnsJA6Xz35b6YVyzpKDtH5OO8.AFdMPV7byWDJqE6RdBWgpwEzRhuFLLbqtN1vX79K_RE&dib_tag=se&hvadid=694890689970&hvdev=c&hvexpln=67&hvlocphy=9197960&hvnetw=g&hvocijid=10245427139806720546--&hvqmt=e&hvrand=10245427139806720546&hvtargid=kwd-410128437966&hydadcr=4020_13191958&keywords=keto-mojo&mcid=b01862671ca8308a9ce501d28fd00003&qid=1749755507&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1), which was also popular among those following ketogenic diets.
- Many more devices likely exist today and that he hasn’t kept up with current options, but these were reliable for his purposes.
- Ketone test strip prices have improved
  - When Peter was actively using ketone strips nearly 15 years ago, the cost per strip was around $5, since they were primarily intended for type 1 diabetics to monitor for ketoacidosis.
  - These costs added up quickly, especially if testing multiple times per day.
  - Fortunately, prices have decreased significantly, making self-monitoring more accessible now.

## Reducing senescent (“zombie”) cells and inflammation through autophagy [35:00]

**Definition of “Zombie Cells” (Senescent Cells)**

- “Zombie cells” is a lay term used to describe senescent cells, a term that wasn’t considered accessible enough for Disney Plus during the Limitless series with Chris Hemsworth.
  - Senescent cells are dysfunctional cells that stop dividing properly but remain alive and active.
  - These cells continue to signal inflammation and negatively affect nearby tissue and organ function.
  - While they don’t die, they behave abnormally and contribute to aging and chronic disease.

Context from the Limitless Series

- During the Disney Plus series [Limitless](https://www.disneyplus.com/browse/entity-e5503eed-f8c2-4071-bd2f-46b5c6057a19), Peter and [Chris Hemsworth](https://en.wikipedia.org/wiki/Chris_Hemsworth) did a 4-day fast as part of exploring health and longevity topics.
- Chris had never done a fast before, and the experience was portrayed accurately — including the physical challenges alongside intense training.
- The fasting episode was intended to highlight how lifestyle interventions could potentially help clear senescent cells.

Ketosis and Senescent Cells

- The belief that ketosis helps reduce zombie/senescent cells is common, but the data isn’t entirely clear.
- A recent [study](https://www.science.org/doi/10.1126/sciadv.ado1463) suggests ketosis might actually increase senescence in certain tissues, specifically the heart, kidney, and blood.
- Despite that, the net effect of ketosis still appears to be anti-inflammatory, particularly in the brain.
- One proposed mechanism is that [ketosis reduces brain inflammation by modulating microglial activation](https://pmc.ncbi.nlm.nih.gov/articles/PMC11345202/) (brain immune cells).

Fasting and Autophagy vs. Ketosis

- Fasting appears more clearly beneficial in this context than ketosis.
- Autophagy, stimulated more robustly by fasting than by ketosis, plays a dual role:
  - It clears out damaged or non-viable cells.
  - It helps repair and restore still-viable but underperforming cells.
- This dual action of autophagy contributes to a more uniform and reliable reduction in cellular senescence.

> “*I would say that we have more clarity around the benefits of fasting than we do ketosis when it comes to [reducing cellular senescence].*” —Peter Attia

## Examining the evidence for the long-term health benefits of fasting beyond short-term metabolic effects [37:15]

Framing the benefits of fasting

- All of the physiological mechanisms previously discussed—such as ketosis, autophagy, glycogen depletion, and hormonal shifts—suggest that fasting could provide health benefits that go beyond simple caloric restriction.
- These mechanisms form a compelling theoretical framework, but theory alone is not sufficient.

Lack of long-term clinical evidence

- There is very limited concrete evidence showing that the benefits of fasting persist after refeeding.
- Peter shares his own experience doing seven-day fasts while collecting extensive bloodwork. During the fast, his body showed profound hormonal and metabolic changes.
- However, it remains unclear how long those changes last and whether any of the benefits remain a week after resuming normal eating.

The “garage” analogy

- Peter uses an analogy to illustrate the uncertainty: if you clean your garage once a month but immediately start filling it with junk again, is that better than never cleaning it at all?
- This highlights the lack of understanding around whether temporary benefits of fasting have a lasting impact.

Fasting and chronic disease risk

- So far, both observational and experimental studies attempting to link the short-term molecular effects of fasting with long-term clinical outcomes (e.g., reduced risk of atherosclerotic cardiovascular disease, type 2 diabetes, or cancer) have mostly shown no significant long-term benefits.
- The available human data are limited and of poor quality, making it difficult to draw firm conclusions.

Theoretical potential vs. demonstrated outcomes

- The molecular biology behind fasting suggests promising health effects.
- However, the scientific community has not yet been able to experimentally confirm those benefits in human trials.

## The common health claims associated with fasting across metabolic, neurological, oncological, autoimmune, and longevity domains [40:30]

**Overview of common claims about fasting benefits**

- Fasting—both intermittent and extended—is frequently associated with a wide array of proposed health benefits. These include both metabolic and non-metabolic outcomes.

Metabolic health benefits (most commonly cited)

- Weight loss, particularly fat loss
- Improvements in body composition
- Increased insulin sensitivity

Prevention of chronic diseases

- Proposed benefits include lowered risk for:
  - Neurodegenerative diseases, particularly dementias
  - Cancer
  - All-cause mortality, with the broader goal being potential lifespan extension

Use of fasting in cancer treatment

- Some proponents claim fasting may:
  - Reduce the morbidity associated with cancer itself
  - Lessen side effects from chemotherapy
  - Improve efficacy of cancer treatments

Fasting and inflammatory/autoimmune conditions

- Suggested benefit includes a reduction in symptoms of autoimmune and other inflammatory conditions

Preview of what’s to come

- Peter notes upfront that the strength of evidence supporting these various claims varies widely.
- Some of these benefits are supported by far more robust data than others, and the discussion ahead will reflect that variability.

## The impact of fasting on body weight and body composition [42:00]

Fasting and body composition goals

- Fasting is fundamentally a tool for reducing overall caloric intake, which supports weight loss.
- However, Peter emphasizes the importance of clarifying what most people truly mean when they say they want to “lose weight”:
  - What people really want is fat loss while preserving lean mass.
  - No one intentionally aims to lose muscle and stay fat, even if they don’t explicitly say it.

Importance of preserving lean mass

- This principle is not only important for fasting but also for the use of GLP-1 agonists.
  - Without strategic planning, these drugs can lead to significant weight loss but may negatively affect body composition by sacrificing lean mass.

Core question explored: *Does fasting provide better body composition outcomes than continuous caloric restriction (CR) when calorie intake is matched?*

- When matched for calories over a short-term period, fasting does not promote more weight loss than continuous caloric restriction.
- It’s difficult to perfectly compare fasting vs. CR because:
  - Fasting typically results in greater short-term energy imbalance (due to zero intake periods).
  - But refeeding periods complicate the overall outcome in terms of fat vs. muscle loss.

Short-term vs. long-term effects

- Water-only fasting is a faster method of weight loss compared to continuous CR or intermittent fasting.
- However, the net effect on body composition over the long term, especially regarding fat loss vs. lean mass loss, is not well understood.
- Here is a [review article](https://pmc.ncbi.nlm.nih.gov/articles/PMC11494232/) that evaluates prolonged fasting in the existing literature.

## Weight regain and potential metabolic consequences of fasting [44:00]

**Weight regain after fasting**

- Most evidence indicates that weight lost during fasting is generally regained after resuming normal eating habits—unless a fundamental dietary shift accompanies refeeding.
- Returning to one’s previous eating habits typically leads to regaining most or all of the lost weight.

Patient example

- Peter shares an example of a patient who successfully lost significant weight by integrating monthly five-day fasts with a 25-day cycle of reasonably restrictive dieting in between.
  - The patient began with ad libitum eating.
  - This structured cyclical approach continued for several years, resulting in sustained weight loss and improved metabolic health.
  - The key to success was not the fasting alone, but using fasting as a trigger for sustained dietary change.

**Unanswered question: Does extended fasting harm metabolism?**

- Peter raises a theoretical concern: *Does a long period of extended fasting suppress energy expenditure and increase appetite in such a way that it persists when you refeed?*
  - In lay terms: Could repeated long fasts “jack” your metabolism and lead to rebound weight gain?
  - There is no definitive human data to answer this question.
- Rodent [study](https://www.sciencedirect.com/science/article/abs/pii/S0955286320304897?via%3Dihub) insights:
  - Both one-time and two-time extended fasting/refeeding cycles led to increased body weight and fat mass during refeeding compared to mice never food-deprived.
  - Mice that fasted twice showed:
    - Greater appetite for high-fat foods
    - Lower energy expenditure
    - Decreased respiratory exchange ratio (RER), suggesting changes in fuel utilization
  - While these results could imply a downside to extended fasting, Peter emphasizes that mice are metabolically different from humans, making the findings non-translatable without caution.
- Human [data](https://onlinelibrary.wiley.com/doi/full/10.1002/oby.22518) on time-restricted eating (TRE)
  - Unlike extended fasting, time-restricted eating [does not appear to negatively impact](https://pmc.ncbi.nlm.nih.gov/articles/PMC10255792/#:~:text=found%20no%20significant%20differences%20in,mechanisms%20behind%20this%20are%20uncertain):
    - Energy expenditure
    - Appetite levels outside the eating window
  - There is no similar long-term human data available yet for prolonged fasting’s impact on these outcomes.

## The risk of lean mass loss with fasting and how to mitigate it [47:15]

**Proportion of lean vs. fat mass lost during fasting**

- Extended fasting leads to a disproportionately high loss of lean mass relative to fat mass.
  - [Studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC11494232/) show that lean mass accounts for 50–66% of total weight lost during prolonged fasting.
  - This is worse than GLP-1 agonists or bariatric surgery, where lean mass typically comprises about one-third of weight lost.
  - Ideal goal: limit lean mass loss to 25% of total weight loss.
- Losing 10 pounds via fasting could result in 5 to 7.5 pounds of lean mass lost, including water weight.
  - This is concerning and highlights the potential downsides of extended fasting for body composition.

Glycogen depletion and water weight

- Lean mass loss includes glycogen-associated water weight, which can be misleading.
  - Each gram of glycogen carries 3 grams of water.
  - Ketogenic diets show similar initial weight drops due to glycogen and water loss, not necessarily fat loss.

Alternative approach: Caloric restriction

- The [CALERIE study](https://calerie.duke.edu/) (discussed on a previous [podcast episode with Eric Ravussin](https://peterattiamd.com/ericravussin/)) involved a 12% continuous caloric restriction over two years.
  - Resulted in minor lean mass loss, but muscle quality improved.
  - Markers of improvement included better muscle repair and mitochondrial biogenesis.
- For patients seeking body composition improvements, Peter recommends spread-out caloric restriction over prolonged fasting.

***What do we know about the proportion of lean mass loss when it comes to intermittent fasting as opposed to long-term fasting?***

- Intermittent fasting (e.g. time-restricted eating) likely results in less lean mass loss than extended fasts.
  - Prolonged fasting is less optimal for muscle retention.
  - TRE offers a better balance of caloric deficit and muscle preservation.

**Strategies to preserve lean mass during fasting**

- Two potential interventions:
  - 1) Resistance training
  - 2) Protein supplementation during the fast (i.e., protein-sparing modified fast)
- Example: consuming 60–65g of protein daily during a fast (~250 calories/day).
  - Protein provides an anabolic signal to maintain muscle.
  - Resistance training enhances this anabolic effect.
- Protein intake during fasting technically breaks the fast but may be worth it to preserve muscle mass.
  - 0.8 g/kg body weight is the minimum RDA needed to prevent malnutrition, not to build muscle.
  - This level of intake can help minimize muscle loss during fasts.

Peter’s personal reflection

- During his three-year period of aggressive fasting:
  - He lifted weights daily, avoiding cardio, to stimulate muscle protein synthesis.
  - In hindsight, he believes he was likely just breaking down and rebuilding muscle due to lack of dietary amino acids.
  - Wishes he had consumed 60–80g of whey protein isolate daily during that time to reduce muscle loss.

## A practical framework for using fasting as a strategy to improve body composition [52:15]

**Peter’s framework for evaluating fasting suitability**

- When considering fasting as a tool, Peter uses a framework built on three key questions:
  - 1) Is the person overnourished, adequately nourished, or undernourished?
    - Undernourishment is rare but may apply to individuals with very low body fat (<10%) and low muscle mass.
  - 2) Is the person adequately muscled or undermuscled?
  - 3) Is the person metabolically healthy or metabolically unhealthy?
- For overnourished, adequately muscled, metabolically unhealthy individuals (often obese)
  - Extended fasting may be a reasonable intervention to:
    - Kickstart weight loss
    - Deplete glycogen
    - Serve as a transition into a healthier dietary pattern
  - Fasting is not magical on its own—benefit comes only if it initiates lasting behavior change.
  - Simply fasting for a few days and returning to the prior eating pattern does not result in meaningful change.
- For normal-weight individuals, especially with low muscle mass
  - Peter generally advises against fasting for this population.
  - Fasting could further reduce lean mass and offer limited benefits.
  - Recommends using other strategies (e.g. training, dietary adjustments) to improve body composition rather than fasting.

## How extended fasting compares to caloric restriction in improving insulin sensitivity in people with insulin resistance or type 2 diabetes [54:00]

**Fasting and insulin resistance/type 2 diabetes**

- Intermittent fasting does improve insulin sensitivity, but not more than equivalent caloric restriction.
- This conclusion is supported by multiple meta-analyses and studies conducted in recent years.
- Example: If someone follows a 16–18 hour intermittent fasting regimen and eats a restricted number of calories in a short window, the metabolic benefit is comparable to spreading that same calorie amount across the full day.
- Intermittent fasting is not superior to continuous caloric restriction when calories are matched.
- Some studies suggest that spreading calories out over the day may lead to better lean mass retention, though data on this is mixed and sometimes underpowered.
- There are also studies that examine the impact of extended water-only fasting and refeeding protocols on insulin sensitivity and glycemic control in individuals with obesity.
  - Among individuals with baseline obesity: one [trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC8951503/) investigated the effect of both extended water fasting (17 days) and refeeding on insulin sensitivity and glycemic control.
    - At the start of refeeding, plasma glucose, insulin, and HOMA-IR had improved relative to pre-fasting, but these metrics all significantly exceeded baseline values within a few weeks of refeeding, despite partial maintenance of fasting-induced weight loss.
    - However, it’s very possible that this represents a temporary rebound from the ketotic state and would reverse with time (the median follow-up was only 8 days post-fast).
  - Among individuals with normal weight: a [trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC8320652/#ctm2502-fig-0001) with a 5-day water fast followed by a 3-month follow-up showed that insulin levels dropped during fasting but returned to baseline within one month of refeeding.

## Is there any evidence that fasting can extend lifespan? [55:45]

***Does fasting extend lifespan?***

- There is *no direct evidence* in humans that fasting extends lifespan.
- However, many of the cellular and molecular effects of fasting (e.g., reduced oxidative stress, reduced inflammation, increased autophagy) are mechanistically linked to lifespan extension.
- In rodents, fasting has been shown to increase lifespan, but:
  - When directly compared to continuous caloric restriction (CR), CR performs as well or better for extending lifespan.
  - This suggests the benefits come more from total calorie reduction than the fasting/refeeding pattern itself.
- The implication is that fasting likely mimics caloric restriction, and the longevity benefits stem from that overlap, rather than something uniquely magical about fasting.
- Peter reiterates the importance of this point: even in controlled animal studies, continuous CR typically outperforms intermittent fasting for lifespan extension.
- He references high-quality, long-term [studies](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(18)30512-6?fbclid=IwAR3yqDyhhHRalfPQylL4999A7GBvTarJoF5K9AI0XMiOymo4CGacfd2Suwo):
  - National Institute on Aging (NIA) study
  - University of Wisconsin study
  - Related monkey study discussed in his book Outlive

Data in the figure below show that mice on continuous CR outlived mice on single-meal feeding regardless of diet composition:

![](https://peterattiamd.com/wp-content/uploads/2025/06/f3-ama72-1024x639.jpg)

**Figure 3.** Comparison of survival in mice on ad-libitum feeding (AL), single meal feeding (MF), or continuous calorie restriction (CR) on either the National Institute of Aging (NIA) diet, University of Wisconsin diet (WIS), or an average of both diet cohorts. [[source](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(18)30512-6?fbclid=IwAR3yqDyhhHRalfPQylL4999A7GBvTarJoF5K9AI0XMiOymo4CGacfd2Suwo)]

\*\*\*

Podcast Side Note: Peter would like to have [Dr. Christopher Ramsden](https://irp.nih.gov/pi/christopher-ramsden), a researcher whose work Peter frequently references, on the podcast. If anyone knows him, feel free to encourage him to come on for an episode of The Drive!

## Examining whether fasting improves cardiovascular disease risk beyond the effects of weight loss and calorie reduction [58:15]

***Can fasting help prevent cardiovascular disease (CVD)?***

- In theory, fasting should reduce CVD risk because it can lower inflammation, a known contributor to cardiovascular disease.
- However, there is no clear evidence that fasting produces lasting, unique benefits for CVD prevention beyond those achieved through:
  - Caloric restriction (CR)
  - Weight loss
- Fasting has been shown to reduce CVD risk factors, such as:
  - Body weight
  - Blood pressure
  - Cholesterol
  - Glucose metabolism
- But these improvements are likely due to weight loss, not the fasting protocol itself.
- Peter emphasizes the importance of the comparison:
  - If fasting is compared to an unhealthy, unrestricted diet, then yes, it helps.
  - But when fasting is compared to an equivalent caloric restriction, no superior benefit is observed for CVD risk reduction.
- A [Cochrane review](https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD013496.pub2/full) examines this question.

## Exploring whether prolonged fasting can reduce cancer risk [59:45]

**Can fasting reduce cancer risk?**

- There is significant interest in whether fasting could lower the risk of cancer, especially because cancer is the second leading cause of death and often occurs in otherwise healthy people.
- The idea that fasting reduces cancer risk is theoretical. For example:
  - It may stimulate autophagy, helping eliminate damaged cells and senescent cells that could become cancerous.
  - This idea influenced Peter’s own fasting practice in the past, though he now views it as unproven speculation.
- The clearest connection between fasting and cancer prevention comes through indirect benefits:
  - Fasting that leads to sustained fat loss may reduce cancer risk.
  - This is because excess adiposity is the [second leading environmental cause of cancer](https://pmc.ncbi.nlm.nih.gov/articles/PMC10661911/) (after smoking), likely due to its ties to insulin resistance and chronic inflammation.
- If fasting helps maintain a lower body fat percentage long term, it may reduce cancer risk—but fasting alone, without improving adiposity, does not have proven cancer-protective effects.

## The potential benefits of fasting or fasting-mimicking diets during cancer treatment: emerging evidence and practical considerations [1:02:15]

***Can fasting improve outcomes for people undergoing cancer treatment?***

- This is an evolving area of research—past views strongly opposed fasting during cancer treatment
  - “10 years ago, the answer was cancer patients should be force-fed Ensure drinks because they’re going to have a hard enough keeping weight on in the course of their treatment”
  - But today the perspective is shifting—there are several companies out there that are really working on nutritional solutions for cancer patients
- A concept called **differential stress resistance** supports fasting: it may make healthy cells more *resistant* to chemotherapy and cancer cells more *vulnerable*, thanks to their inability to stop proliferating.
  - In nutritional deprivation, healthy cells enter a protective, repair-focused state while cancer cells, due to mutations in tumor suppressor genes, continue growing and remain exposed to chemotherapy damage.
  - Fasting may thus serve as a tool to increase the gap between healthy and cancer cells, allowing for more selective treatment effects.

A closer look into what’s happening when you treat cancer:

- If you have cancer, it’s not that we don’t have drugs that can’t kill the cancer, it’s actually really easy to kill a cancer cell with many different chemicals
  - The problem is they would kill every cell in your body
- So the question is: *How do you selectively kill the cancer cell while sparing the normal cell?*
- Chemotherapy in the most traditional sense is targeting dividing cells because cancer cells are more often dividing than non-cancer cells, which of course explains why normal cells that are dividing get ravaged by traditional chemotherapy (e.g., hair falls out, mouth sores, sores in their GI system)
- This is why immunotherapy is very attractive when it works because if the cancer cell looks different immunologically, then you can send the immune cells after that
- In this sense, nutrition becomes another tool that we can use to create a difference through this mechanism
- In the context of nutritional deprivation, healthy cells devote energy towards maintenance and repair instead of growth, which allows them to resist damage from chemotherapy and radiation, which therefore reduces side effects
- Now, tumor cells instead are unable to slow down growth due to the mutations in the tumor suppressor genes which make them more susceptible to cancer treatments.

> “*We want to create differences between cancer and non-cancer cells that we can exploit with therapy. And what’s elegant about this [nutritional] approach is that we’re able to use drugs that are otherwise very blunt instruments in the treatment of cancer*.” —Peter Attia

This figure below explains what’s happening between normal cells and cancer cells if they’re both fed normally and if they’re calorie restricted:

![](https://peterattiamd.com/wp-content/uploads/2025/06/f4-ama72-1024x626.png)

**Figure 4.** Differential responses to fasting between normal cells and cancer cells can enhance effectiveness of chemotherapy in destroying cancer cells while mitigating damage to normal cells. [[source](https://www.nejm.org/doi/full/10.1056/NEJMcibr1202395)]

- Early [studies](https://www.mdpi.com/2072-6643/15/12/2666?utm_source=chatgpt.com) of water-only fasting show:
  - Water-only fasting (≥24 hours) can reduce chemotherapy side effects.
  - This allows patients to better tolerate full chemotherapy protocols, potentially leading to better outcomes.
- Fasting Mimicking Diets (FMDs) have shown [promising results](https://www.nature.com/articles/s41467-020-18194-1?utm_source=chatgpt.com) in breast cancer:
  - Greater tumor regression
  - Potentially better survival outcomes.
  - Based on unpublished data, there are early signs that FMDs preferentially work in women with triple negative breast cancers
    - Triple negative breast cancer as we learned on the [podcast with Hal Burstein](https://peterattiamd.com/haroldburstein/) is a particularly devastating type of breast cancer
- Companies like [Faeth](https://www.faeththerapeutics.com/) are exploring ketogenic diets as cancer therapy adjuncts, inspired by preclinical models.
  - See episodes with [Lew Cantley](https://peterattiamd.com/lewcantley/) and [Sid Mukerjee](https://peterattiamd.com/sidmukherjee2/)

**Peter’s clinical perspective on when and how fasting or FMDs might be safely and effectively used during cancer treatment:**

- For cancer prevention, fasting is not yet a proven tool; better evidence supports:
  - Maintaining metabolic health.
  - Reducing excess adiposity.
  - Increasing muscle mass.
- For patients with active cancer, Peter is supportive of FMDs or similar calorie-restricted approaches, especially if they are:
  - Coordinated with the patient’s oncology team.
  - Aimed at reducing chemo side effects and potentially improving efficacy.
- He cautions against doing this without medical oversight, but says attitudes in oncology are improving, and more teams are open to nutrition-integrated treatment strategies.

## Fasting for protection against neurodegenerative diseases: early evidence of therapeutic benefit and open questions [1:10:45]

***Can prolonged fasting help prevent or slow neurodegenerative diseases like Alzheimer’s disease or Parkinson’s disease?***

- No direct clinical evidence exists that fasting reduces the risk or slows progression of these diseases in humans.
- However, there are mechanistic reasons for optimism:
  - Fasting can reduce adiposity and improve metabolic health, which are known to lower risk for diseases like Alzheimer’s.
  - In a couple [animal](https://academic.oup.com/nutritionreviews/article/81/9/1225/7116310)[studies](https://www.imrpress.com/journal/JIN/23/3/10.31083/j.jin2303050/htm#b93), extended fasting has:
    - Lowered amyloid beta and phosphorylated tau levels (both linked to Alzheimer’s).
    - Improved learning and memory in mouse models.
  - The challenge is disentangling the effects of caloric restriction (CR) from fasting.
    - Many of the benefits observed in animals could be due to the CR rather than fasting per se.
- Human data is limited:
  - A very small crossover [trial](https://link.springer.com/article/10.1186/s13195-021-00783-x) (around 20 patients) in people with Alzheimer’s disease showed that a ketogenic diet may improve:
    - Activities of daily living.
    - Self-reported quality of life.
  - While encouraging, this does not yet warrant a change in standard of care. Larger, well-powered trials are needed.

Why might ketosis help?

- Some forms of Alzheimer’s may be driven by neuronal insulin resistance.
- In these cases, the brain [struggles to metabolize glucose](https://peterattiamd.com/alzheimers-disease-and-glucose-metabolism/), but can still use ketones like beta-hydroxybutyrate or lactate, potentially improving brain energy metabolism.

## Various fasting methods for autoimmune diseases: potential symptom relief with cautious application [1:14:00]

**Can fasting help with autoimmune diseases like MS or rheumatoid arthritis?**

- Prevention: There’s no strong evidence that fasting *prevents* autoimmune disease.
- Symptom relief: Some fasting protocols may reduce systemic inflammation and mitigate symptoms, though effectiveness varies by condition.

Multiple Sclerosis (MS)

- Intermittent fasting (IF) and fast-mimicking diets (FMDs) may:
  - Lower neuroinflammation and oxidative stress.
  - Lead to symptom improvement, based on limited animal and mechanistic human data.
- Long water-only fasts are less supported and may increase cellular stress, potentially offsetting benefits.
- Recommendation: For MS, Peter favors IF or daily hypocaloric intake (500–700 kcal) over extended fasts, as refeeding after long fasts can trigger inflammation spikes.

Rheumatoid Arthritis (RA)

- Early trials showed that a 7–10 day water-only fast, followed by a plant-based diet, could lead to sustained symptom relief.
- However, these studies were done before current medications and diet strategies were available, and have not been consistently replicated.
- Could still be a viable option for individuals who prefer dietary interventions over medication or don’t respond well to drugs.

Takeaway

Fasting may provide symptom relief in certain autoimmune diseases—especially MS and possibly RA—primarily through inflammation reduction. But benefits depend on the type of fasting, and evidence is mixed. Caution is advised with extended water-only fasts, especially without medical supervision.

## Fasting and type 1 diabetes: risks, evidence, and careful dietary alternatives [1:16:45]

***Does fasting help with type 1 diabetes?***

- Type 1 diabetes is fundamentally different from type 2:
  - It’s caused by an autoimmune destruction of pancreatic beta cells, leading to insulin deficiency.
  - The issue is not insulin resistance, as in type 2, but the inability to produce insulin at all.

Fasting & Risk

- In healthy individuals, ketones produced during fasting trigger insulin release, which helps regulate ketone levels.
- In type 1 diabetics, that feedback loop is broken—they don’t make insulin, so ketones can rise unchecked, potentially leading to dangerous ketoacidosis.
- For this reason, fasting is not recommended in type 1 diabetes, despite theoretical benefits.

Animal Studies

- In mouse models, FMD cycles have shown regeneration of beta cells and even reversal of diabetic symptoms.
- No strong human evidence yet supports this.

Alternative Approaches

- Many individuals with type 1 diabetes have had success managing their disease with low-carb or ketogenic diets, but this requires high vigilance and medical oversight.

Takeaway

- Fasting is not safe or advisable for people with type 1 diabetes due to the risk of ketoacidosis from unregulated ketone production. While mouse studies show promise, there’s insufficient evidence in humans to support fasting as a safe intervention.

## Fasting and gut disorders: potential benefits outside of flare-ups [1:18:45]

***Can fasting help with gut-related disorders like IBD (Inflammatory Bowel Disease)?***

- Fasting is not recommended during active flare-ups of IBD due to the risk of:
  - Nutritional deficiencies
  - Worsening complications
- However, during remission, certain fasting strategies may provide anti-inflammatory benefits:
  - Intermittent fasting, hypocaloric diets, or fasting-mimicking diets (FMDs) could potentially help reduce inflammation while minimizing nutritional risks.
- Animal [studies](https://www.sciencedirect.com/science/article/pii/S2213231720303840#fig1) (especially in mice) show promising results:
  - [Time-restricted eating](https://pubmed.ncbi.nlm.nih.gov/36618695/) has reduced gut inflammation in preclinical models.
  - These findings have not yet been demonstrated in humans.
- Peter recommends that patients in remission who are attuned to their body may benefit from tinkering:
  - Experiment with elimination of dietary triggers
  - Try different caloric restriction or fasting protocols
  - Goal: Discover what minimizes symptoms and potentially extends remission

Takeaway

- Fasting is not advised during IBD flare-ups, but in remission phases, careful experimentation with fasting or low-calorie protocols might help reduce inflammation. No conclusive human evidence yet, but patient-led tinkering could be valuable.

## The primary risks and downsides associated with fasting [1:19:45]

***What are the risks people should be aware of with fasting?***

- Loss of muscle mass is one of the primary risks, especially with longer fasts or when fasting is done frequently without sufficient resistance training or protein intake.
- Overeating during the feeding window is a common mistake, particularly with intermittent fasting:
- Some people compensate for fasting by binging on unhealthy foods during eating windows.
  - This can lead to weight gain, even if fasting windows are long.
  - Example: A patient who fasted 18 hours daily but gained fat due to poor eating choices (e.g., pizza and soda) during the 6-hour eating window.
- Micronutrient deficiencies can occur with long water-only fasts, especially if done repeatedly without guidance or supplementation.
- Ketoacidosis is a serious risk for individuals with type 1 diabetes, and fasting should be avoided altogether for this group unless under strict medical supervision.

## The essential vitamins and minerals to supplement during prolonged fasting [1:21:30]

***What vitamins and minerals should be monitored during longer fasts?***

- Key water-soluble vitamins:
  - B vitamins are especially important to maintain during prolonged fasting.
- Essential minerals to focus on:
  - Sodium – Peter consumed around 4 grams per day during his fasts.
  - Magnesium – Can be hard on the gut during fasting, but he still aimed for 1–2 grams per day of magnesium chloride.
  - Potassium and calcium are also important to support overall electrolyte balance.
- The goal is to prevent deficiencies and maintain electrolyte homeostasis, which is critical during extended fasting.

## Who should avoid fasting and why [1:22:15]

***Who should avoid long-term fasting?***

- Type 1 diabetics or individuals with beta cell dysfunction:
  - High risk due to impaired insulin regulation; fasting could lead to dangerous complications without close medical supervision.
- Pregnant women:
  - Even with gestational diabetes, fasting is discouraged.
  - Emphasis should be on healthy dietary modifications that support fetal growth, not calorie deprivation.
- Individuals with a history of eating disorders (anorexia, bulimia):
  - Fasting poses a high risk of relapse, malnutrition, or worsening mental health.
- People with very low muscle mass:
  - Fasting can exacerbate muscle loss, making sustained caloric restriction a safer and more strategic approach.

> “*Sometimes it’s hard when you see a patient who is metabolically unhealthy, wildly overnourished, and very low in muscle mass. These are hard patients to treat. . .I feel quite strongly about not using fasting and rather trying to rely on a more sustained caloric restriction*.” —Peter Attia

Takeaway

- Fasting is not appropriate for individuals with type 1 diabetes, pregnancy, disordered eating history, or very low muscle mass, due to the elevated risk of harm in each case.

## Fasting’s role in health: where it shows promise and where it likely offers no distinct advantage over caloric restriction [1:23:45]

**Framework summary for fasting**:

- Most health benefits from fasting are likely due to caloric restriction, not the fasting protocol itself.
- There might be some areas where we see unique benefits potentially on cognitive health.
- Cancer treatment stands out as the most promising area where fasting may provide unique advantages:
  - Enhances tolerance to chemotherapy and radiation via potentiating side effects.
  - Helps protect healthy tissue while improving treatment outcomes.
- For chronic diseases like diabetes, heart disease, and cancer prevention, fasting is not superior to achieving energy balance through modest calorie intake.
- In terms of lifespan extension, even in animal models, continuous caloric restriction outperforms or matches fasting protocols.
  - Peter says “*I think it would be very difficult to make the case that fasting brings a unique benefit*.”

---

## Selected Links / Related Material

**First episode of The Drive dedicated to fasting**: [#89 – AMA #11: All things fasting](https://peterattiamd.com/ama11/) (January 20, 2020) | Peter Atta (peterattamd.com) [2:00]

**Peter’s book**: [Outlive: The Science and Art of Longevity](https://peterattiamd.com/outlive/) by Peter Attia ([peterattiamd.com](https://peterattiamd.com)) [2:45]

**Previous episodes of The Drive where Peter describes where his mind has changed based on new information**: [4:45]

- [#202 – Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes](https://peterattiamd.com/strong-convictions-loosely-held-2/) | Peter Attia (peterattiamd.com)
- [#300 – Special episode: Peter on exercise, fasting, nutrition, stem cells, geroprotective drugs, and more — promising interventions or just noise?](https://peterattiamd.com/ep-300-exercise-nutrition-fasting-more/) | Peter Attia (peterattiamd.com)

**The world’s longest recorded fast**: [Angus Barbieri’s fast](https://en.wikipedia.org/wiki/Angus_Barbieri%27s_fast) | (wikipedia.org) [14:15]

- Paper about how he was able to maintain his weight: [Features of a successful therapeutic fast of 382 days’ duration](https://pmc.ncbi.nlm.nih.gov/articles/PMC2495396/) (Stewart and Fleming, 1973) [15:00]

**The trademart diet by Walter Longo**: [Fast Mimicking Diet](https://valterlongo.com/fasting-mimicking-program-and-longevity/) | (valterlongo.com) [17:00]

**Episode of The Drive with Eileen White about autophagy**: [#114 – Eileen White, Ph.D.: Autophagy, fasting, and promising new cancer therapies](https://peterattiamd.com/eileenwhite/) | Peter Atta ([peterattamd.com](http://peterattamd.com)) [26:30]

**A study showing mice with genetic defects preventing autophagy experienced fatal neurodegenerative conditions**: [Autophagy Is Required for Glucose Homeostasis and Lung Tumor Maintenance](https://watermark.silverchair.com/914.pdf?token=AQECAHi208BE49Ooan9kkhW_Ercy7Dm3ZL_9Cf3qfKAc485ysgAAA0MwggM_BgkqhkiG9w0BBwagggMwMIIDLAIBADCCAyUGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQMSoX8Figw5vIZv6BOAgEQgIIC9qOK1hNb5MgQfBn6QrXLnuuJUno_4ihgUN11iqO-1kI5CIlTyaqJ6M_G8vGWxxuSUAw2lSdyeIPXKhkP_VLi5zJSfqT-E-ZaaDBM5WpTd5QjsCOCTTqUNhj-1tZknOehqCih-9mlxAD0lCybqNYAvEo5CdrZEJcL89VIpMZuO7PAuM6_2WqxGcuzvG-ZCOOAkC8ekzLLe8wHHjCorVsUmABduY1xCCfIwt6Psc701jZ1fO8wMjJ8myanYEIBos57hnO_4VfYvZRVPopYaz1EYTKfBWc2nxqdkLesr7ftg9Iw0XDkJkOltyiy7uA6GLc19hPV3ZcQS6KwYjx5bB3juARhqcryduk8sJlu3yU3Bxp6n4ptxN8MOavaa0pVB8siIUBvoG4vKOvCdbgLiGFZ6MoItu3ytmq96yLnkkl304MdHJ-tJs4YYi35PLyJw3MG_ofGat29PgkOaENN2cJmYuL6dA0Hqz_hu6Xk3PyIGRrE_nxSAhm3qYWORmIQfl4QdTQGGo58QBLnFS2vcYjRuBycSc5OS_7fSzmofUrQl9tsWz6Y1DbEttGq9KQl3C18BC3nTf5nZUphalXW99VMjO9t9U_flAdW_3c-WFxas6Z4RnaIfmRFqnCczl_1GXzw5X37_AxSfHvREKpd8uzYrwDU4ypdu4m1ng2pPCxH_Jrfk0O0o9MYQX6yNEJtkPzilccb9Nqpp6XxbU5wP763_fXo7lYA0_2QmiXHjdtzWG9iLs5PTS7t2f1IXQWSW878Kqn56suKus3C5iJfT9R2CMh-ZMZ6S3uDCMIUDiOHCRpKjOF0iVfS61iZlAjZHiNpklxmI2DP07rusuRywu9rkQ0gdUy8eipNqB3WQn3TmHwcN-dknl1wEGTjgWKTxprF0ay-TS0j706-eARGZCiurkRVoRpPGJsbRURagDVxyM5EqaC9zR_sDwmldaEmYAxMcPzN8nv9Md2kKnNbQ8KQxcDm8KNKH0GONSwpo_Tlt1zOmhlXC8kx) (Karsli-Uzunbas et al., 2014) [27:00]

**Metformin and AMP kinase, an enzyme that is expressed in higher quantities when the ratio of ATP to ADP and ADP to AMP is falling**: [Metformin as a potential longevity medication: where do we stand?](https://peterattiamd.com/metformin-and-longevity/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com)) [32:00]

**At home devices for measuring ketone levels**: [34:45]

- [Abbott Precision Xtra](https://abbottstore.com/diabetes-management/precision-brand/precision-brand/precision-xtra-blood-glucose-ketone-monitoring-system-1-pack-9881465.html?srsltid=AfmBOorHwV2JIQoaPvchwas_VVQGRpf25iCIlHJMXR4jzMotflvQewvh)
- [Keto-Mojo](https://www.amazon.com/KETO-MOJO-Bluetooth-Diabetes-Management-Solutions/dp/B08G5BZQVL/ref=sr_1_1_sspa?dib=eyJ2IjoiMSJ9.I1oiXoUt_nJup6Rkd5QA3RXJMiaXdcXvIKbox6dzQtN4WEhlPgYgS6XbcgQc1DMWv2JezpgYdm_EmIimr3tIUSNI9k8qptv0ikrDF4S26wZJg-VbBzNaKJVuDYMO27Mm-RSaU3PNTVWDI3JlwnX1W4ufkY4mlZP_xiPnGZM1cIa-U4HUOuxVyzYfHU_pM_z2hPcPm_YE6BHnlmjtU143B4oXbHoLqPtrqotZekKdcDlEgQnxkbrGnJ3u7NvCD2ABuOKJ3OmW6KNrZ1fG2UgnsJA6Xz35b6YVyzpKDtH5OO8.AFdMPV7byWDJqE6RdBWgpwEzRhuFLLbqtN1vX79K_RE&dib_tag=se&hvadid=694890689970&hvdev=c&hvexpln=67&hvlocphy=9197960&hvnetw=g&hvocijid=10245427139806720546--&hvqmt=e&hvrand=10245427139806720546&hvtargid=kwd-410128437966&hydadcr=4020_13191958&keywords=keto-mojo&mcid=b01862671ca8308a9ce501d28fd00003&qid=1749755507&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1)

**Show on Disney Plus with Chris Hemsworth**: [Limitless](https://www.disneyplus.com/browse/entity-e5503eed-f8c2-4071-bd2f-46b5c6057a19) | (disneyplus.com) [35:30]

**A recent study suggests ketosis might actually increase senescence in certain tissues, specifically the heart, kidney, and blood**: [Ketogenic diet induces p53-dependent cellular senescence in multiple organs](https://www.science.org/doi/10.1126/sciadv.ado1463) (Wei et al., 2024) [36:15]

**The net effect of ketosis still appears to be anti-inflammatory, particularly in the brain via modulating microglial activation (brain immune cells)**: [ketosis reduces brain inflammation by modulating microglial activation](https://pmc.ncbi.nlm.nih.gov/articles/PMC11345202/) (Monda et al., 2024) [36:45]

**A review looking at human trials of prolonged, water-only fasting**: [Efficacy and safety of prolonged water fasting: a narrative review of human trials](https://pmc.ncbi.nlm.nih.gov/articles/PMC11494232/) (Ezpeleta et al., 2023) [43:45]

**A mouse study where extended fasting/refeeding cycles led to increased body weight and fat mass during refeeding compared to mice never food-deprived**: [Prolonged fasting induces long-lasting metabolic consequences in mice](https://www.sciencedirect.com/science/article/abs/pii/S0955286320304897?via%3Dihub) (Pedroso et al., 2020) [46:00]

**Unlike extended fasting, time-restricted eating does not appear to negatively impact on energy expenditure and appetite levels outside the eating window**: [Early Time-Restricted Feeding Reduces Appetite and Increases Fat Oxidation But Does Not Affect Energy Expenditure in Humans](https://onlinelibrary.wiley.com/doi/full/10.1002/oby.22518) (Ravussin et al., 2019) [46:45]

**Studies of extended fasting have shown that the ratio of lean mass lost to fat mass lost is very high**: [Efficacy and safety of prolonged water fasting: a narrative review of human trials](https://pmc.ncbi.nlm.nih.gov/articles/PMC11494232/) (Ezpeleta et al., 2023)[47:30]

**The CALERIE study (discussed on a previous** [**podcast episode with Eric Ravussin**](https://peterattiamd.com/ericravussin/)**) involved a 12% continuous caloric restriction over two years**: [CALERIE study](https://calerie.duke.edu/) | (calerie.duke.edu) [48:48]

**Multiple studies have shown intermittent fasting does improve insulin sensitivity, but not to a greater extent than the equivalent amount of caloric restriction**: [54:30]

- [The Effects of Prolonged Water-Only Fasting and Refeeding on Markers of Cardiometabolic Risk](https://pmc.ncbi.nlm.nih.gov/articles/PMC8951503/) (Scharf et al., 2022)
- [Five‐day water‐only fasting decreased metabolic‐syndrome risk factors and increased anti‐aging biomarkers without toxicity in a clinical trial of normal‐weight individuals](https://pmc.ncbi.nlm.nih.gov/articles/PMC8320652/#ctm2502-fig-0001) (Jiang et al., 2021)

**The National Institute of Aging/University of Wisconsin study that found mice on continuous CR outlived mice on single-meal feeding regardless of diet composition**: [Daily Fasting Improves Health and Survival in Male Mice Independent of Diet Composition and Calories](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(18)30512-6?fbclid=IwAR3yqDyhhHRalfPQylL4999A7GBvTarJoF5K9AI0XMiOymo4CGacfd2Suwo) (Mitchell et al., 2019) [57:30]

**The Cochrane review examines the question of whether fasting help prevent cardiovascular disease**: [Intermittent fasting for the prevention of cardiovascular disease](https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD013496.pub2/full) (Allaf et al., 2021) [59:45]

**There are a couple of clinical trials that have shown that water-only fasting for at least 24 hours reduces the side effects during chemo**: [Therapeutic Fasting in Reducing Chemotherapy Side Effects in Cancer Patients: A Systematic Review and Meta-Analysis](https://www.mdpi.com/2072-6643/15/12/2666?utm_source=chatgpt.com) (Ferro et al., 2023) [1:06:15]

**The Fast Mimicking Diet was shown to promote greater tumor regression and improved overall patient survival with breast cancer**: [Fasting-mimicking diet plus chemotherapy in breast cancer treatment](https://www.nature.com/articles/s41467-020-18194-1?utm_source=chatgpt.com) (Vernieri et al., 2020) [1:07:00]

**Episode of The Drive with Hal Burstein describing triple negative breast cancer as a particularly devastating type of breast cancer**: [#278 ‒ Breast cancer: how to catch, treat, and survive breast cancer | Harold Burstein, M.D., Ph.D.](https://peterattiamd.com/haroldburstein/) | Peter Attia (peterattiamd.com) [1:08:00]

**Episode of The Drive with Lew Cantley**: [#110 – Lew Cantley, Ph.D.: Cancer metabolism, cancer therapies, and the discovery of PI3K](https://peterattiamd.com/lewcantley/) | Peter Atta ([peterattamd.com](http://peterattamd.com)) [1:08:30]

**Episode of The Drive with Sid Mukherjee**: [#244 ‒ The history of the cell, cell therapy, gene therapy, and more | Siddhartha Mukherjee](https://peterattiamd.com/sidmukherjee2/) | Peter Atta ([peterattamd.com](http://peterattamd.com)) [1:08:30]

**Companies like Faeth are exploring ketogenic diets as cancer therapy adjuncts**: [Faeth](https://www.faeththerapeutics.com/) [1:08:30]

**Mouse models of Alzheimer’s disease have indicated that extending fasting can reduce levels of amyloid beta and p-tau in CSF and improve memory and learning—but these effects have been shown with caloric restriction**: [1:11:45]

- [Effects of intermittent fasting on cognitive health and Alzheimer’s disease](https://academic.oup.com/nutritionreviews/article/81/9/1225/7116310) (Elias et al., 2023)
- [Fasting, a Potential Intervention in Alzheimer’s Disease](https://www.imrpress.com/journal/JIN/23/3/10.31083/j.jin2303050/htm#b93) (Zeng et al., 2024)

**A small crossover trial looked at a 12-week intervention found that a ketogenic diet may have had benefits in activities of daily living and quality of life self-assessment scores in patients with Alzheimer’s disease**: [Randomized crossover trial of a modified ketogenic diet in Alzheimer’s disease](https://link.springer.com/article/10.1186/s13195-021-00783-x) (Phillips et al., 2021) [1:12:45]

**At least one subset of patients with Alzheimer’s disease are experiencing it due to neuronal insulin resistance**: [Alzheimer’s disease and glucose metabolism](https://peterattiamd.com/alzheimers-disease-and-glucose-metabolism/) | Peter Attia (peterattiamd.com) [1:13:30]

**In rodent studies, time-restricted eating has been shown to reduce gut inflammation**: [1:19:15]

- [Effects of alternate-day fasting, time-restricted fasting and intermittent energy restriction DSS-induced on colitis and behavioral disorders](https://www.sciencedirect.com/science/article/pii/S2213231720303840#fig1) (Zhang et at., 2020)
- [Time-restricted feeding ameliorates dextran sulfate sodium-induced colitis via reducing intestinal inflammation](https://pubmed.ncbi.nlm.nih.gov/36618695/) (Song et al., 2022)

---

## People Mentioned

- [John Maynard Keynes](https://en.wikipedia.org/wiki/John_Maynard_Keynes) [6:45]
- [Angus Barbieri](https://en.wikipedia.org/wiki/Angus_Barbieri%27s_fast) [14:15]
- [Valter Longo](https://valterlongo.com/biography/) [17:00]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) [21:15]
- [Eileen White](https://www.cinj.org/research/eileen-white-phd) [26:30]
- [Chris Hemsworth](https://en.wikipedia.org/wiki/Chris_Hemsworth) [35:30]
- [Eric Ravussin](https://www.pbrc.edu/research-and-faculty/faculty/Ravussin-Eric-PhD.aspx) [48:48]
- [Christopher Ramsden](https://irp.nih.gov/pi/christopher-ramsden) [57:45]
- [Hal Burstein](https://www.dana-farber.org/find-a-doctor/harold-j-burstein) [1:08:00]
- [Lew Cantley](https://cellbio.hms.harvard.edu/faculty-staff/lewis-cantley) [1:08:30]
- [Sid Mukherjee](https://en.wikipedia.org/wiki/Siddhartha_Mukherjee) [1:08:30]