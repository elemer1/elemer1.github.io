# #72 – Dan Harris: 10% happier – meditation, kindness, and compassion

**Source:** [https://peterattiamd.com/danharris/](https://peterattiamd.com/danharris/)

---

In this episode, Dan Harris, correspondent for ABC News and co-founder of the [Ten Percent Happier](https://www.tenpercent.com/) meditation app, speaks openly about his struggles with self-centeredness, addiction, depression, emotional volatility, and the deep-rooted insecurities that drove him to career success. He tells the story of how a panic attack on live TV lead him down a path of self-discovery culminating in a meditation practice which has since transformed his life—in terms of his own personal suffering, his relationships with those closest to him, and his ability to be kind and compassionate (which has its own selfish advantages). Dan also shares some very practical advice and tips for new meditators, dispels some of the myths around meditation, and gives people some things to look forward to as they progress with their practice. Last but not least, we talk about the importance of not passing shame and trauma to our kids and the role that mindfulness and meditation plays in that.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/danharris/the_Drive_public.png)

Play

#72 - Dan Harris: 10% happier – meditation, kindness, and compassion

#72 - Dan Harris: 10% happier – meditation, kindness, and compassion

1x15s30s

0:002:24:36

We discuss:

- Dan’s meditation book, and the panic attack on live TV that started it all [8:00];
- Addiction: the spectrum of addiction, the socially acceptable forms, and Dan’s own battle with addiction and depression [13:30];
- Dan’s drive for self-protection, a defining moment of childhood, and how his upbringing shaped him [20:30];
- A selfish reason to be kind and compassionate [28:30];
- Using mindfulness to avoid being controlled by your emotions such as anger and grandiosity [36:15];
- How Dan found meditation, and how he went from skeptic to someone willing to try it [40:45];
- Advice for new meditators, misconceptions about meditation, and the difference between changes in state vs. changes in trait [48:00];
- Difference between being “mindful” versus being “present” [55:00];
- The overlap between psychology and Buddhism, who is the real Buddha, and a Buddhism 101 lesson [57:45];
- What convinced Dan to finally try meditation, and how did his first session go? [1:05:30];
- Lessons from Dan’s 10-day silent retreat: “*You’re trying too hard”* [1:12:30];
- How Dan’s meditation has evolved over 10 years of practice [1:27:30];
- Dan’s 360 Review: A painful process illuminating his selfishness, and putting him on a path to more kindness and compassion [1:30:45];
- How to quiet mental suffering in tough times, and how meditation has helped (and not helped) Dan get through some of the hardest moments of his life [1:41:30];
- How Dan’s practice has made him a better husband [1:47:45];
- How to prevent the transference of trauma and shame to your kids [1:50:45];
- Does past trauma drive successful people? Can a person be successful professionally if they give up that negative insecurity that is driving them? [1:56:00];
- The pillars of emotional health, and how to help yourself when you feel insecure [2:08:30];
- Why it’s important to let your kids see that you are a flawed human [2:11:30];
- Learning from the incredible (but flawed) Peter Jennings [2:15:15];
- When is Dan’s next book coming out? [2:21:15]; and
- More.

§

## Show Notes

## Dan’s meditation book, and the panic attack on live TV that started it all [8:00]

**Dan’s book**

- Peter says Dan’s book, [10% Happier](https://www.amazon.com/10-Happier-Self-Help-Actually-Works/dp/0062265431), has “*almost single-handedly been responsible for my interest in meditation*”
- Peter comments on how he likes the title because it doesn’t “overpromise”

**The embarrassing event that started Dan’s journey towards mental health**

> “A few seconds in I just lost the ability to breathe. My palms were sweaty, my heart was racing, my lungs seized up, I just couldn’t talk.”

- While filling in as the “newsreader” on [Good Morning America](https://en.wikipedia.org/wiki/Good_Morning_America), Dan had a panic attack on live television
- The audience was 5 million people
- This incident led Dan down a path of trying to figure out WHY this happened

## Addiction: the spectrum of addiction, the socially acceptable forms, and Dan’s own battle with addiction and depression [13:30]

Dan’s time as a reporter in war zones

- After 9/11, Dan spent a lot of time in war zones
- Afghanistan, Pakistan, Israel, Gaza, and Iraq
- When he returned home, he got depressed
- Having trouble getting out of bed and felt sick a lot
- At this point, he didn’t really know WHY he felt depressed

Cocaine use

- One night out, someone offered Dan some cocaine
- He said he has never even considered drugs to this point but for some reason that night he said yes
  - Probably because he was feeling so crappy

*Why was he feeling depressed?*

- In hindsight, Dan says he was depressed from the time he spent reporting in war zones
- But NOT because of being traumatized, but because **he missed the action**
- It was a **withdrawal from the adrenaline** and the *cocaine was a synthetic squirt of that adrenaline*

Visiting a therapist

- A doctor that was a “panic expert” asked Dan whether he took drugs
- Dan revealed he did cocaine intermittently
- The doctor said even that could alter his brain chemistry and make it more likely to have a panic attack
- Dan calls this an “aha” moment, and he quit doing drugs

**\*Addiction doesn’t always mean drugs\***

- Peter points out that taking drugs is just one way that people go to satisfy some dopamine needs
- Drugs are just one way to numb something
- And the same can be said about perfectionism, performance, sex, etc.
- Other people can just as easily be addicted to the career, or anything that lights up their “pleasure center” of the brain

**==> Peter’s book recommendation** about addiction: [In the Realm of Hungry Ghosts](https://www.amazon.com/Realm-Hungry-Ghosts-Encounters-Addiction/dp/155643880X) by [Gabor Mate](https://en.wikipedia.org/wiki/Gabor_Mat%C3%A9_(physician))

**==> Dan’s book recommendation** on addiction: [The Craving Mind](https://www.amazon.com/Craving-Mind-Cigarettes-Smartphones-Love-Why-ebook/dp/B06VSPVRQQ) by Judson Brewer

*Addiction is a spectrum*

- Dan’s take from Brewer’s book is as follows…
  - **Addiction is a spectrum**, you may think you’re not an addict because you don’t have a needle hanging out of your arm, but that needle hanging out of your arm is just the extreme end of the spectrum
  - But we’re all addicted to lots of things
    - Your phone
    - Your relationship with professional success
    - Sex? Shopping? Gambling? Drinking?
    - “*We are rats in a maze and we go where the pellets are.*”

Socially acceptable addictions are harder to get help for

- Peter points out that socially acceptable addictions actually have a disadvantage
- If there’s one advantage to having a needle in your arm, at least everybody realizes it’s wrong and you’re more likely to do something about it and get help
- Rarely do people push you to seek help about your addiction to perfectionism, says Peter
  - In fact, you’re more like to be praised for it

## Dan’s drive for self-protection, a defining moment of childhood, and how his upbringing shaped him [20:30]

Dan’s upbringing

- Dan’s parents were both respected and successful in the field of medicine
- However, that did not translate to a lot of money
- He grew up in Newton, Mass
- Dan says he was “really keenly aware of the fact that we were much poorer than a lot of the kids that I went to school with”
- He says this made him feel really insecure

Defining moment

- One time his parents got a paid trip to Europe to give some lectures
- Dan was ~10 years old
- And they got put up in a fancy hotel called [Hôtel Régina](https://en.wikipedia.org/wiki/H%C3%B4tel_R%C3%A9gina)
- Something clicked during this visit and Dan told himself he was never going to be the person who was poor and frugal like his parents

> “It’s not as simple as just saying, ‘It was The Hotel Regina that did it’, but that to me seems like a defining moment.”

**A drive for self-protection**

- Dan’s credits [Jerry Colonna](https://en.wikipedia.org/wiki/Jerry_Colonna_(financier)), his “executive coach”, for helping him understand his drive for safety
- Jerry often talks about our 3 primary needs: 1) love 2) safety, and 3) belonging
- “*Over time I started to realize that* ***safety*** *is actually something really important for me.*”
- Dan says this may even be an intergenerational trait… his great-grandparents escaped the [Cossacks](https://en.wikipedia.org/wiki/Cossacks)
- He mentions there was also some severe cases of depression, alcoholism, poverty, and suicide in his family tree
- Both his parents were “inveterate worriers”

The Cold War

- Dan says that the Cold War actually made him feel unsafe as a child

> “It freaked me out so much I had to go see a shrink when I was a little kid. I think part of the drive is the self-protection.”

**Dan’s grandfather with a temper, and how it impacts him to this day**

- Dan’s grandfather (his mother’s father) had an angry/resentful disposition for most of his life
- This made a big impact on Dan’s mother, and also on Dan
- Dan says he sees a lot of his grandfather in himself, something he has to wrestle with
- Dan would like to be less quick tempered
- And much more kind and compassionate
- But these things aren’t necessarily coming natural to him

## A selfish reason to be kind and compassionate [28:30]

The cliché of kindness and compassion

- Dan mentions that saying the words kindness and compassion make him feel a bit uneasy
- Why? ⇒ “*It’s Hallmarky, ooey gooey, meaningless cliché . . .  it’s bland, dogmatic, exhortation, finger-wagging, God-is-watching type of stuff.*”

He says we need a way to present it in a self-interested way

- Evidence shows that people who are compassionate are happier, healthier, more successful, more popular, and it feels good ⇒ [Could Compassion Fuel Your Success?](https://www.psychologytoday.com/us/blog/functioning-flourishing/201804/could-compassion-fuel-your-success)
- It also feel good
- We are wired to get “feel good” chemicals released in our brain

**A counterintuitive reason to do the giving**

- Dan says his meditation teacher has a great little rule: If you notice the impulse to give something arise, just do it
- Compliment someone
  - Send a note to that person that did a great job
  - Give a dollar to the homeless man
- Why do this giving?
  - Do NOT do it because … “*I’m just trying to make the world a better place, man.*”
  - Do it because it feels good **for you**

⇒ Dan has a chapter in his [book](https://www.amazon.com/10-Happier-Revised-Self-Help-Works/dp/0062917609/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) called, *The self-interested case for not being a dick*

How to talk about kindness and compassion so that people will listen

- The only one self help book that’s been successful about on selling compassion in a self-interested way: [How to Win Friends & Influence People](https://www.amazon.com/How-Win-Friends-Influence-People/dp/0671027034)
- Dan says this book has been inspirational for how he is thinking about finding a way to talk about kindness and compassion in a way that *people will actually listen*

**Peter’s story about handling conflict**

- Peter recently encountered a jerk at the gym who wouldn’t let Peter work in on a machine
- Normally, Peter said he would have let the situation escalate
- Fortunately, Peter had used [Dan’s meditation app](https://10percenthappier.app.link/install) that morning
- He specifically listened to a guided meditation by [Joseph Goldstein](https://en.wikipedia.org/wiki/Joseph_Goldstein_(writer)) who had suggested to choose to do the kind thing even in a moment of conflict
- Against his instincts, Peter says, “Okay, no problem. I’ll wait until you’re done.” and walked away
- Peter noticed the following…
  - 1) He stopped being upset about it very quickly
  - 2) Within about five minutes, he felt bad for the guy and was literally worried about him, thinking “*he probably feels like a jerk now because I haven’t put up any fight. I’ve been very kind and pleasant*”

Wise selfishness

- Dan says even the Dalai Lama has coined something called “[wise selfishness](https://kripalu.org/resources/wise-selfish-cultivating-compassion)”
- It’s the ultimate form of selfishness…It is to be kind because YOU will be happier/healthier/more popular

> “We don’t generally do things unless…there’s a pellet in it for us. I fear that the way kindness is discussed is like the Care Bears, or some religious figure in robes wagging his finger at you, that doesn’t strike me as scalable. Especially at a time where we really need this. We’ve got epidemic levels of anxiety, depression, suicide, and levels of political polarization. We’ve got global problems that require cooperation like climate change. This is the time where we actually need to start pulling our heads out of our asses. So I’m excited to see if I can make a little contribution in this way.”

## Using mindfulness to avoid being controlled by your emotions such as anger and grandiosity [36:15]

The numbing effects of anger and grandiosity

- They are beautiful anesthetics for the maladaptive mind
- **Kindness and compassion are the antidotes** to that

*How important is it to explore the* ***root cause*** *that underlie people’s addictions/shames/excessive drives?*

> “It’s like you got to figure out the pain of holding onto the hot coal, which then it feels really good to drop it.”

- Dan says it’s been very important, and useful, to explore it for him personally
- For Dan that meant,
  - Exploring the psychological content of exploring his relationship to my grandfather
  - But also the moment by moment mental processes, what it feels like to suffer *right now*

⇒ An expression about anger from the [Buddha](https://en.wikipedia.org/wiki/Gautama_Buddha): “*It has a honey tip, but a poison root.*“

**Mindfulness and self-awareness**

- Mindfulness (or self-awareness) is the **ability to know what’s happening in your head at any given moment without getting carried away by it**.
- It is a skill that we develop through meditation, but there are other ways to do it
- Meditation is just the cleanest, clearest way to do it

> “Meditation helps you have more visibility on your own inner weather and then you’re not so yanked around by it.”

Anger

- Be mindful on can show you that anger feels bad
- It may feel good initially, it’s a good release of energy
- but then it’s in your system for a while
- It takes a long time to detoxify

Grandiosity

- The truly dangerous very of grandiosity is more subtle
- Peter’s example,
  - At the airport, the TSA guy pulls my suitcase out of the line because of no reason apparently at all
  - It takes 20 minutes
  - Now this delay means I don’t get to buy lunch before I get on my flight, etc.
  - The internal grandiosity thoughts, “*I’m so much better than you. Why don’t you get over here and do your job? I’m doing my job. Do you know how hard I work?*”

> “That’s the grandiosity that I think is the absolute poison. . .if I’m going to be brutally honest with myself, that’s the biggest struggle that I have.” —Peter Attia

**The vicious cycle of anger and grandiosity**: Get angry/grandiose  ⇒ Feel shame ⇒ Get angry/grandiose  ⇒ Feel shame

## How Dan found meditation, and how he went from skeptic to someone willing to try it [40:45]

- Dan’s therapist helped him realize he’s addicted to the high of his job at ABC News
- Adrenaline junkie
- And it’s soothing some need of his

**Covering faith and spirituality for ABC News**

- In tandem to Dan’s therapy, [Peter Jennings](https://en.wikipedia.org/wiki/Peter_Jennings) assigns him to explore and probe the growing religious movement
- Dan was not particularly happy about this assignment
- But ultimately it was great because
  - He learned a lot about faith and spirituality (“I was totally ignorant on the subject”)
  - Made a lot of new friends and it brought me into parts of the world that I wouldn’t have otherwise seen
  - And it ultimately **brought him to meditation**

**Eckhart Tolle and the Ego**

- This assignment lead him to self-help writer, [Eckhart Tolle](https://en.wikipedia.org/wiki/Eckhart_Tolle)
- After reading one of his books, Dan was thinking “this is BS”
- However, one thing that Tolle did well was how he described our inner **ego**

⇒ The inner ego

- We all have this running dialogue, this inner narrator, this voice that chases you out of bed in the morning and is yammering at you all day long
- It’s making you think about the past or the future *to the detriment of whatever’s happening* ***right now***
- Tolle’s argument is… when you’re not aware of this nonstop conversation, it owns you
- That to me was incredibly powerful, say Dan
  - 1) It just seemed intuitively true
  - 2) It explained the most embarrassing moment of my life, my panic attack.
    - The voice in my head was why I went off to cover wars without thinking about the consequences, came home, got depressed, was insufficiently self aware to even know it, and then blindly self medicated, and it all just blew up in my face. So reading Tolle’s book was incredibly powerful for me.

*How to tame the inner dialogue*?

Dan once [interviewed Tolle](https://www.youtube.com/watch?v=Scj4hJuKhI0) for ABC News

- In the conversation, Dan asked Tolle for some practical advice about how to make the inner voice stop talking
  - Tolle’s response was “Take one conscious breath”
  - In Dan’s head, he was thinking, “what the fuck does that mean??”
- Dan’s investigation also lead him to [Deepak Chopra](https://en.wikipedia.org/wiki/Deepak_Chopra)
  - Dan partially credits Deepak for helping him realize that **the mechanism one can use for taming the voice in the head is meditation**

## Advice for new meditators, misconceptions about meditation, and the difference between changes in state vs. changes in trait [48:00]

> “The whole game of meditation is not to stop thinking, which is impossible, it’s to notice when you’ve become distracted and start again and again and again.”

Meditation is the victim of the “*worst marketing campaign ever*” says Dan

- Traditional artwork shows people sitting in an impossible position floating off into the cosmos
- Reality is you are sitting in silence, probably in physical pain, distracted as hell with your unpleasant thoughts

It’s not about stopping thoughts

- The whole game of meditation is not to stop thinking (which is impossible)
- It’s to notice when you’ve become distracted and start again and again and again

Altering **traits** *no*t **states**

⇒ Peter recommends this book about meditation: [Altered Traits](https://www.amazon.com/Altered-Traits-Science-Reveals-Meditation/dp/0399184384)

- Peter says the feeling of meditating in the moment usually isn’t pleasant (but it can be sometimes)
- So if you are focused on the transient change in your **state** (feeling blissful, lowering your heart rate, not stressing out), you will probably get frustrated and feel like it is not working
- But realizing that the real benefit is the change in **trait** (i.e., your attitude the rest of the day) is what truly matters

“If I meditate for 20 minutes in a day, I’m not meditating for those 20 minutes. I’m meditating for the other 23 hours and 40 minutes.” —Peter Attia

**\*Advice to new meditators\***

1. The point of meditation is not to feel any specific way… **it’s to feel whatever you’re feeling right now so that you learn how not to let your feelings push you around**
2. The real world application of that is that you’re better at life: “We don’t meditate to get better at meditation, we meditate to get better at life.”
3. The thing to know primarily for meditators is **don’t get hung up on feeling calm or blissful**
4. Just tune in on your ability to see clearly whatever’s happening right now (distracting thoughts, knee pain, an itch?)

Real world application (Example)

- What we’re training over time is the ability to notice that anger, for example, has come upon us
- And can you in that moment resist the urge to say something that’s going to ruin the next 48 hours of your marriage?

## Difference between being “mindful” versus being “present” [55:00]

Defining being present

- Like a dog, or a toddler, he/she is living in the moment
- They’re probably not thinking about what they’re going to eat tomorrow and they’re not thinking about the dog that barked at them yesterday
- They’re not swept up in bad past decisions or fretting over the future
- But being present is **necessary but not sufficient** for mindfulness

Being mindful

- You also need meta cognition = you know that you’re in the present moment AND you know *that you know* you’re in the present moment
- We have this ability to step out of the stream of our consciousness and notice, “yeah I’m having all of these thoughts, I’m having all these urges, I’m having all these emotions” and to not be carried away by them
- This could only happen for a nanosecond at a time, but it’s still what makes us “homo sapien sapiens” and differentiates us from our early, early ancestors and from animals

## The overlap between psychology and Buddhism, who is the real Buddha, and a Buddhism 101 lesson [57:45]

Dan learning about Buddhism

- Around the time that Dan was learning about Eckhart Tolle and Deepak Chopra, his wife ([Bianca](https://health.usnews.com/doctors/bianca-harris-681255)) gave him a book by [Dr. Mark Epstein](https://en.wikipedia.org/wiki/Mark_Epstein)
  - ⇒ Check out Epstein’s 2 appearances on Dan’s podcast (here’s [one](https://podcasts.apple.com/nz/podcast/22-dr-mark-epstein/id1087147821?i=1000371162457), and [another](https://podcasts.apple.com/us/podcast/172-mark-epstein-combining-buddhism-western-psychotherapy/id1087147821?i=1000428769857))
- Epstein is a practicing psychiatrist here in New York City
- He’s written “beautiful books about the overlap between psychology and Buddhism”
- Buddha refers to the voice in the head as the “monkey mind”

*Who is the real Buddha?*

- Name was purported to be [Siddhārtha Gautama](https://en.wikipedia.org/wiki/Gautama_Buddha)
- He lived around 2,600 years ago
- Born in Nepal and moved all over India
- Son of a king but didn’t want to be a king
- He wanted to be a spiritual leader
- He made his decision to become a spiritual leader after he witnessed all the suffering happening in the community
- He realized that, “*Suffering is a part of life. And if you try to pretend otherwise you’re going to suffer even more.*”

Buddha starts his journey

- As legend has it…
- In his 20s, Buddha runs into the forest
- He spends the next ~6 years studying with great meditation masters
- At that time, there was a lot of self mortification (inflict a lot of pain, you don’t eat, you stand in funny positions, you hang upside down, etc.)
- He ultimately realized that he was still suffering
- So one day he actually ate a little bit and stopped starving himself
- He sat down under the Bodhi tree, a big famous tree in Bodhgaya, India and said, “*I’m not getting up until I’m enlightened.*”
- After he got enlightened, he delivered his seminal speech, “[The Four Noble Truths](https://en.wikipedia.org/wiki/Four_Noble_Truths)”

**The Four Noble Truths**

**1)** *Life is suffering*

- The idea is that everything is impermanent
- If you try to cling to things that will not last, you will suffer
- So life is inherently unsatisfactory because nothing lasts.

**2)** *The root of that suffering is our insatiable desire (or thirst)*

**3)** *There is a way out of this suffering*

**4)** *The eightfold path (which is the way out of it)*

- Meditation practices, ethical practices, right livelihood, right speech, right action, and then a bunch of meditation techniques like mindfulness and philosophical stuff about how to view the world

The Buddha’s message

- It was NOT some death defying dogma about how you can have eternal life
- It was more about how you might be able to reduce the amount of suffering you are experiencing (Much of it kind of voluntary)

> “I have been trying this out for 10 years. And in my experience there’s a lot to it. And the science that has looked at it too has also been interesting.”

## What convinced Dan to finally try meditation, and how did his first session go? [1:05:30]

*What got Dan to finally try meditation?*

A combination of the following…

- Really intrigued by Buddhism as a philosophy
- Cannot overstate the power of Eckhart Tolle “lifting of the curtain on my own mind” to see that suffering is a consequence of the inner voice
- Reading lots of books
- Talking to Mark Epstein
- Finally realized that meditation practice is the corrective to the inner voice causing the suffering
- Plus the science showing the benefits of meditation

The science showing benefits

- The science was a huge deal for Dan
- Such as science showing meditation can
  - [Lower blood pressure](https://www.ncbi.nlm.nih.gov/pubmed/30425326)
  - [Boost immune system](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4940234/)
  - Brain scans that show that you can have an impact on your [prefrontal cortex and your amygdala](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4203918/)

That said…

- Peter says the science is the last reason he is doing meditation, “*there are an infinite number of ways to lower my blood pressure…there’s only one way I know about to understand the nature of my mind, which is an awful demon.*”
- Dan agrees, and says that he uses the science to help skeptics get over the hump (as it did for him)

> “In my experience, the science gets people over the hump and then they no longer care, because once you’ve done it for six weeks or so and you realize you’re less of a shit-head, you don’t care if your prefrontal cortex might look different in an MRI. That is utterly irrelevant.”

**First time actually sitting down to meditate**

- It was 2009 (five years after his panic attack on live TV)
- Went into a bedroom and closed the door
- Sat on the floor
- Set a timer
- Tried to watch my breath coming in and going out, going in and going out
- Immediately there was like a **million thoughts**, “*Where do gerbils run wild?*”
- He got up after five minutes thinking, “Wow, I suck at this.”
- However, this experience did leave him realizing that there was a light, this was a serious thing that can help with the monkey mind

## Lessons from Dan’s 10-day silent retreat: “*You’re trying too hard”* [1:12:30]

- About a year after trying meditation in his bedroom, Dan was convinced to try a silent retreat
- \*Dan does want to point out that new meditators should not feel like they need a silent retreat to benefit or learn to meditate

Peter remembers a powerful moment when reading Dan’s book in the section about the silent retreat…

- On day 5 or 6, Dan described hearing a hummingbird’s wings flap
- At the time, Peter thought, how is that even possible, he must be making that up
- But subsequently, Peter has had his own moments like that as he gets deeper into meditation
- For example,
  - When listening to guided walking meditation by [Jeff Warren](https://jeffwarren.org/) on the [10% Happier app](https://www.tenpercent.com/)
  - Peter actually felt the wind on his fingers as his hand swung forward
  - He thought to himself, “*How have I been walking all this time and never feeling that?*”

*What convinced him to go on the retreat?*

- [Mark Epstein](https://en.wikipedia.org/wiki/Mark_Epstein) and [Sam Harris](https://en.wikipedia.org/wiki/Sam_Harris) were very influential
- Sam was able to get Dan a coveted spot in Joseph Goldstein’s retreat

*The retreat*

- It was a 10 day retreat
- Prior to this event he was maybe getting 10 minutes of meditation per day
- It didn’t start well
  - His mind was on overdrive
  - The meditation was “just awful”
  - He was in physical pain while sitting
  - Walking meditation was difficult
  - Didn’t know what he was doing, “I was all over the place”
- By day 4 or 5, **he was going to quit**

The advice that turned it around for him

- That day he was planning to quit, he met with [Spring Washam](https://twitter.com/SpringWasham), one of the teachers on the retreat
- She said,
  - “*You’re trying too hard…*
  - …*Don’t try too hard. Just notice your breath, when it’s coming in and when it’s going out, and when you get distracted, start again. You’re going to get distracted. Don’t try to make anything special happens. Just stop trying so hard.*”

*What happened next?*

- “*As soon as I stopped trying, the whole thing unfurled and I was just so vividly present and mindful.*”
- You start to see how fast things are going in your sensory life ⇒ Going from hearing the rustling of the leaves to the clanking of the pots in the kitchen, to the footsteps in the hallway, to the feeling of a pain in my knee, to an itch on my back, to a thought coming up.
- It was a really thrilling realization accompanied by a “huge blast of serotonin”
- This “breakthrough” for 36 hours
- Dan says it was the **happiest he’s ever been**
- But the big asterisk is if you try too hard, you will tangle yourself up in knots

Desire

- One of the classic hindrances to meditation is desire
- If you want it too hard, you’re going to shoot yourself in the foot
- It’s like a weird video game where the only way to move forward is to not want to move forward

*How did Dan’s meditation differ/improved when he returned from the retreat?*

- “I feel like you’re leapfrogging your practice, but I don’t know if it shows up that prominently in your 10 minutes when you get home.”
- Meditation practice improves your capacity to stay present (aka your concentration)
- With practice, you will have improved your ability to stay focused on your breath, so you can do it longer, and when a distraction does inevitably come, it doesn’t throw you off as much
- Like a fitness boot camp, you’re going to build those focus/concentration muscles much more actively on retreat

You will also occasionally will have a “peak experience”

- But it’s not like every time you meditate you have a peak experience
- For Dan, it’s more just that
  - 1) I’m imbued with a much deeper faith or trust that this is a worthy endeavor
  - 2) It’s in my mind stream that some of what I’ve seen and understood, some distant echoes of that, are still here

## How Dan’s meditation has evolved over 10 years of practice [1:27:30]

**Meditation** ***CAN*** **be pleasant in the moment**

- Dan says that it is often unpleasant while actually meditating (although less so the more you do it)
- And it’s worth reiterating that meditation is not about what you’re feeling right now…
- It’s about knowing what you’re feeling **so that your feelings don’t own you**
- That said…
- Being able to stay awake and concentrate on something [feels really good](https://www.danielgilbert.com/KILLINGSWORTH%20&%20GILBERT%20(2010).pdf)
- Dan finds that his daily meditation actually is much more pleasant now (compared to 10 years ago)
- There’s like a body high associated with it
- There’s a word for it in the ancient language of Pāli… the word is piti (feels like body tingling)
- There’s a schedule for when this shows up in your practice
- But it doesn’t mean it shows up every time
- “*Wanting it guarantees I won’t get it*”

*What is the biggest difference between your practice now versus 10 years ago?*

- The biggest difference is Dan’s ability to
  - A) More quickly realize that a distraction has come and to come back to the object of focus, and
  - B) React to the distraction in a more “warmer” and more calm way
- Dan believes the **reaction to the distraction is more important**
- If you chastise yourself each time a thought bubbles up, “*you’re teaching the mind that catching yourself and getting distracted is going to come with punishment, and in some ways, not incentivizing the mind to wake up.*”

## Dan’s 360 Review: A painful process illuminating his selfishness, and putting him on a path to more kindness and compassion [1:30:45]

Dan’s devastating *360 Review:*

- Dan is writing a book about kindness and compassion
- For the book, Dan’s wife suggested Dan get feedback from his peers about what he needed to work on in terms of kindness and compassion
- Dan hired executive coach, Jerry Colonna, to perform an in depth version of a 360 Review
- A [360 Review](https://en.wikipedia.org/wiki/360-degree_feedback) is often used in a corporate context as a way to measure performance of executives
- The way they do it is they talk to the person’s peers, subordinates, and superiors, so you get a holistic panoramic 360 view into this person’s performance
- This culminated in a 41 page report
- “It was devastating” says Dan
- His initial reaction was… “I’m a monster…broken, defective, incurably selfish, self-centered, narcissist.”
  - By coincidence, Peter had the same thing done on him and he had the exact reaction, which was “I’m a monster.”
  - Peter said he slipped into depression, “I did not want to leave a dark room for days. I was eviscerated by that report.”
- Additionally, Dan felt like a total fraud and called into question about whether he could write a book about compassion and kindness after reading this report

*How did Dan pick himself up after this report?*

  **1)** The first thing that happened…

- A meeting with Jerry Colonna immediately after the report
- Jerry put Dan through an exercise that went like this…
  - “You now see all this stuff. Now what we’re going to do is we’re going to **love it**.
  - We’re not going to get into shame or anger or self-flagellation.
  - This behavior was serving some primordial need you had that was not particularly skillful.
  - We’re going to give it a hug and say ‘you are no longer needed’”
- This exercise was to push Dan **away from shame** and towards an interest in ‘*why was I behaving this way*?’

  **2)** Dan’s wife forced Dan to not dismiss a lot of the *positive* things in the report

> “There are a lot of people out there who are really selfish and have really made a bunch of bad moves, but there are reasons why we are like this, and those can get untangled and we can work on it. Not only will it be good for everybody, for us, and those in our direct orbit, but if we do this in public, it could help countless people. Now I’m really energized to work on the book.”

## How to quiet mental suffering in tough times, and how meditation has helped (and not helped) Dan get through some of the hardest moments of his life [1:41:30]

Dan has 2 examples of difficult times in his life that were not within his control

- His wife got breast cancer
- He and his wife had infertility issues

Peter wonders how Dan was able to “tame” the projecting thoughts that Peter says he personally struggles with…

- E.g., my wife could die or we’re never gonna have kids
- Peter says he could win a Nobel Prize in that type of “nonsensical thinking”

He described the breast cancer experience as being an opportunity for him to tune into his compassionate/caretaking side

- He says this does NOT come naturally to him
- His default state is selfish and self-centered
- But he says this situation allowed him to see the pleasantness of caring for someone

“There’s a description of enlightenment in the Tibetan tradition, which is a **clearing away and a bringing forth**. That, to me, seem like a great definition of enlightenment. I can clear away my bullshit which blocks me from being useful to other people.”

- There is something called the [Helper’s High](https://en.wikipedia.org/wiki/Prosocial_behavior#Helper's_high)
- The [same regions in your brain light up that light up when you eat chocolate](https://www.huffpost.com/entry/want-to-be-happier-give-m_b_6175358?guccounter=1&guce_referrer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8&guce_referrer_sig=AQAAAD10mclXUGeswL_dNvuCcZziYPJSGgRvjVk_CQ9COBW4K9JLmEyzJa0EFxK1fDyh--tchuYdrq406UD59-O8yG7DAgBgZ0SPQRkhd6gZaRtQbcAiyxiOuzmsZt-OqkFaPtFnVWqL1PpxSOMJZ_owdtke6UtNVGSUA6IvUlIiEgI2)

In the case of infertility,

- Dan says he never really allowed his mind to go to that place of “oh no, we’re never going to have a kid”
- And eventually they were able to get pregnant

*Dealing with mental suffering in tough times*

- **Peter’s take**: When I’ve dealt with really awful things that have confronted me, it’s this realization that we are suffering so much in our minds, probably more than in reality. So much of that suffering is due to thought. It’s due to projection. It’s due to playing out scenarios.

Dan’s admits he isn’t perfect when it comes to applying the lessons he’s learned through meditation

- In neither case did I do a particularly good job at relaxing into the uncertainty.
- Maybe why that could potentially be useful to say or to here is that there are limits to the practice.
- I am not enlightened… I’m a schmo who started meditating 10 years ago
- I’m good sometimes at applying the lessons and sometimes I’m not

## How Dan’s practice has made him a better husband [1:47:45]

*How has Dan’s mindfulness practice helped his relationship?*

- My moment to moment basic blocking and tackling of being a human in a relationship is much better.
- The mindfulness helps me see when I’m about to be overtaken by anger, fear, irritation, and I can let it pass
- I can feel the raw data of the anger, but I don’t need to have the satisfying, energetic release of saying something tart that’s going to get me in trouble

Mindfulness is just one piece of the picture

- Dan says mindfulness alone isn’t enough
- Warmth, friendliness, compassion, is also incredibly important
- Then there are also skills for better communication.
- Learning to be a better listener,
- learning how to phrase my assertions in ways that are less provocative
- Training up baseline levels of friendliness through meditation
- and ability to lean in and give a shit is all super useful (and btw it feels really good when you’re doing it)

*Does Dan still feel rage and detachment?*

- Yes, but he increasingly notices how detachment doesn’t feel good (Leaning in feels better)
- He no longer raises his voice
- But of course, he’s not a “perfected human”
- It’s all about marginal improvement

## How to prevent the transference of trauma and shame to your kids [1:50:45]

> “Every man is a bridge spanning the trauma of his past to the legacy of his future.” —Terry Real (paraphrased by Peter)

Peter’s take on not letting shame transfer to your kids:

- Peter stresses the importance (in his opinion) of not allowing your past traumas and shame to manifest in your parenting and therefore transfer it to your kids
- Peter says, “*My single greatest purpose in life at this point is what do I have to do to make sure that none of my shame makes its way to my three kids*”

Dan’s take:

1. I want it to be that we are bottomless wells of love, and affection and wisdom for our children to the extent possible, and
2. we show them that you’re going to have lots of dark parts of your own personality, it’s unavoidable and you can be okay with that

**How meditation can help**:

- Meditation has probably prevented Dan from transmitting some of his own shame
- So even though Dan seems fortunate enough that his past traumas have lead to *maladaptions* that have been largely successful and helpful to society (his book, podcast, his app, etc.)…
- …But at some point those traumas leak out in the form of being stressed, and snippy and rushed, and inpatient and greedy (in Dan’s case)
- And your inner circle and family takes the brunt of that
- Mindfulness can allow you to reduce that negative manifestation

## Does past trauma drive successful people? Can a person be successful professionally if they give up that negative insecurity that is driving them? [1:56:00]

*Can a person be successful professionally if remove the negative insecurity that may be driving them?*

- First, the negative never goes away completely
- But you can **turn down the volume** on the less wholesome motivations (attention, money) and turn up the volume on more wholesome motivations (being of service, helping others)

**Redefining success**

- It may also require a little bit of a *shifting of how you define success*
- During 10% Happier and the subsequent never-ending book tour, Dan was really adamant that people would not lose your edge because of meditation
- However, as his practice evolves, Dan says you do start to change a little bit how you define success

Dan’s personal example,

- He recently went part time at ABC News and gave up anchoring Nightline
- In a way, he’s dropping a dream of 25 years of reaching the absolute top of TV news
- That said, Dan is having to battle between “letting it go” versus a triggering event that makes him start getting competitive again
- And so it’s not clean, but the overall trend is toward letting it go
- Analogy: Dan’s self talk is like an iPhone app that was running that was sucking up a lot of the battery life, but he wasn’t using it
- “*I still want to be in TV news,* ***I just want to be in TV news in a way that’s really enjoyable****, which is I’m not constantly angling for the next job. I’m just loving the one I have right now and trying to ace this thing.  For me, it’s much more pleasant.*”

*A billion dollar company?*

- Dan says even with his new mindset through mindfulness, he still has big ambitions
- He was 10% Happier to be a billion dollar business one day

\*Peter plugs Dan’s app\*

- Peter says both [Calm](https://www.calm.com/) and [Headspace](https://www.headspace.com/headspace-meditation-app) are great apps…
- But they don’t even compare to Dan’s [10% Happier app](https://www.tenpercent.com/) (or Sam Harris’s app, [Waking Up](https://wakingup.com/))

> “I think it’s impossible to put a stake in the heart of all of your demons forever. . .I don’t imagine all of my inner hobgoblins evaporating permanently, but I do think I can turn the volume down and operate out of a cooler space.”

## The pillars of emotional health, and how to help yourself when you feel insecure [2:08:30]

**The three pillars of emotional health (by Peter)**

1. Mindfulness (developing the capacity to be mindful)
2. Reframing (developing the capacity to reframe things-stoicism and then some)
3. Relationality

⇒ Peter said earlier that he still feels a tremendous sense of insecurity that “everything could be taken away tomorrow”

- The tool Peter uses to help with this insecurity is reframing
- He recognized that… “*If I lose the capacity to do my work tomorrow, I don’t lose my relationships.*”

We’ll never get rid of all insecurities: Mindfulness and meditation is about bringing forth **marginal improvement** over time with an *escape valve for backsliding*

## Why it’s important to let your kids see that you are a flawed human [2:11:30]

**Importance of letting your kids see you are flawed**

- For most of Peter’s life as a parent, he has felt it was important to hide his mistakes from his children, to “see me as perfect”
- With his work with therapist, he’s come to realize this is very wrong
- His daughter would benefit from seeing he Dad is flawed and that he is actively working on being “less flawed”
- Quoting his therapist…“*You’re not helping her by letting her think your some indestructible force who never struggles, who doesn’t have remorse, who doesn’t make mistakes, and then come to repent.*”

Peter’s struggles

- Peter is prone to having outbursts of rage
- And admits that his kids have seen some ugly stuff from him (although never directed at them)

Meditation

- But with meditation practice, “*I’m just less likely to lose my mind now.*”
- And he is looking forward in his life to be able to share this growth with his kids

“*For her to understand that your dad’s flawed and he’s trying to be less flawed, I think of this is like one of the greatest things that we could do as parents.*” says Peter

*Why is this so important?*

- She will have her own flaws and she needs to know that that’s okay
- There is a way to deal with them and reduce her own suffering

> “You are modeling successful relationships with your own complexity and own demons to your kid. That not only enriches your behavior and relationship with the kid because they really know you, but it also just gives them a tool for moving through life in a way that will reduce their own suffering.”

## Learning from the incredible (but flawed) Peter Jennings [2:15:15]

![](https://peterattiamd.com/wp-content/uploads/2019/09/Peter-Jennings-1024x575.png)

**Figure 1. Peter Jennings.** Image credit: [adweek.com](https://www.adweek.com/tvnewser/abc-remembers-peter-jennings-10-years-after-his-death/269193/)

Dan’s last convo with Peter Jennings

- Jennings was telling Dan he need to go to Israel and Iraq
- And also told Dan there was a perception that he wasn’t so good at foreign coverage
- “*He was giving me this big assignment and also smacking me in the face while he did it, just a little pointed jab at, ‘You need to prove to us once again that you’re good at this thing*.’”
- That last convo was in early 2005
- Jennings died in August of 2005 from cancer

*Was Peter Jennings happy?*

- I think he could be happy, but I think fundamentally he seemed to me like somebody who wasn’t super happy.
- I think he was driven a lot by the dark spots, the wanting to prove, wanting to win.
- That dysfunctional part of him created so much value in that he was just such an intrepid reporter
- We learned so much just by being near him

*Would Dan have suggested meditation to Peter Jennings?*

- Probably not
- To simply probe his happiness level and what might be contributing to unhappiness could have been interesting and productive
- If I had evangelized meditation to him, I think that probably would have backfired.
- Peter agrees: When thinking about people with Peter Jennings phenotype, meditation usually isn’t the place to start

**How Peter talks to patients about meditation**

- I’m not talking to anybody about this stuff as an authority who’s figured anything out.
- I’m talking about it as a schlep who’s right there.
- Whereas a lot of times when doctors talk to patients, the patient perceives the doc as someone who knows the answer and give you instructions
- But this is clearly an area where that’s not the case

*If Peter Jennings was a “Buddha zen dude”, could he have had that same impact?*

-Dan’s intuition is **yes**

“*My intuition is that you’re going to have more of an impact on people if you’re not stressing them out so much…because you shut down their ability for cognitive function…*

*But if he felt safe and was willing to sort of calmly impart the many lessons he had learned over the course of his illustrious career, I think we would’ve learned even more…*

*…Instead, one of the things we learned was how to deal with a bully.*”

## When is Dan’s next book coming out? [2:21:15]

- Dan is writing a book about kindness and compassion
- He is estimating a mid-2021 release

§

## Selected Links / Related Material

**Dan’s New York Times best-selling book**: [10% Happier: How I Tamed the Voice in My Head, Reduced Stress Without Losing My Edge, and Found Self-Help That Actually Works–A True Story](https://www.amazon.com/10-Happier-Self-Help-Actually-Works/dp/0062265423/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Dan Harris | (amazon.com) [6:00, 8:45, 31:00, 1:13:30, 1:58:00, 2:15:15]

**The 10% Happier Podcast**: [Ten Percent Happier Podcast with Dan Harris](https://www.tenpercent.com/podcast) | (tenpercent.com) [6:00, 1:14:15

**Peter’s appearance on Dan’s podcast**: [#202: Can Meditation Prolong Your Life?, Dr. Peter Attia](https://podcasts.apple.com/us/podcast/202-can-meditation-prolong-your-life-dr-peter-attia/id1087147821?i=1000447987039) | Ten Percent Happier with Dan Harris [6:00]

**Dan’s meditation app that Peter cannot recommend more highly**: [Ten Percent Happier](https://10percenthappier.app.link/install) | [6:00, 32:00, 1:14:15, 1:59:10, 2:04:15]

- [Apple app store](https://apps.apple.com/us/app/10-happier-meditation/id992210239)
- [Google Play store](https://play.google.com/store/apps/details?id=com.changecollective.tenpercenthappier&hl=en_US)

**Dan is a co-host of the Weekend Edition of Good Morning America**: [Good Morning America: Weekend editions](https://en.wikipedia.org/wiki/Good_Morning_America#Weekend_editions) | (wikipedia.org) [6:15]

**Dan was previously the co-anchor of Nightline**: [Nightline](https://en.wikipedia.org/wiki/Nightline) | (wikipedia.org) [6:15]

**Dan’s panic attack on national TV in 2004**: [Panic Attack on Live Television | ABC World News Tonight](https://www.youtube.com/watch?v=_qo4uPxhUzU) | ABC News (youtube.com)  [7:00, 9:00]

**Peter’s book recommendation about addiction**: [In the Realm of Hungry Ghosts](https://www.amazon.com/Realm-Hungry-Ghosts-Encounters-Addiction/dp/155643880X) by Gabor Mate | (amazon.com) [17:15]

**Dan’s book recommendation on addiction**: [The Craving Mind](https://www.amazon.com/Craving-Mind-Cigarettes-Smartphones-Love-Why-ebook/dp/B06VSPVRQQ) by [Judson Brewer](https://www.ted.com/speakers/judson_brewer) | (amazon.com) [18:45]

**Dan compares himself to “Sammy” in this book**: [What Makes Sammy Run?](https://www.amazon.com/What-Makes-Sammy-Budd-Schulberg/dp/0679734228) by Budd Schulberg | (amazon.com) [20:30, 1:52:00]

**Fancy Paris hotel that Dan stayed at as a child that was a defining moment for him**: [Hôtel Régina](https://en.wikipedia.org/wiki/H%C3%B4tel_R%C3%A9gina) | (wikipedia.org) [21:45]

**Where Dan’s grandfather worked which only added to his embitteredness**: [Yellow pages](https://en.wikipedia.org/wiki/Yellow_pages) | (wikipedia.org) [25:30]

**Evidence that shows that people who are compassionate are happier, healthier, more successful, more popular, and it feels good**: [Could Compassion Fuel Your Success?](https://www.psychologytoday.com/us/blog/functioning-flourishing/201804/could-compassion-fuel-your-success) | Michelle McQuaid (psychologytoday.com)  [29:00]

**Only self-help book that successfully pitches using compassion for self-interested reasons**: [How To Win Friends And Influence People](https://www.amazon.com/How-Win-Friends-Influence-People/dp/0671027034) by Dale Carnegie | (amazon.com) [31:30]

**Meditation app that Peter really likes created by Sam Harris**: [Waking Up app](https://wakingup.com/) | (wakingup.com) [32:00, 2:04:15]

**The idea of “wise selfishness” from the Dalai Lama**:  [“Wise Selfish”: Cultivating Compassion](https://kripalu.org/resources/wise-selfish-cultivating-compassion) | Daniel Goleman (kripalu.org) [34:30]

**Book that Dan partially read that says that the quintessential asshole rallying cry is, “don’t you know who I am?”**: [Assholes: A Theory](https://www.amazon.com/Assholes-Theory-Aaron-James/dp/0804171351) by Aaron James | (amazon.com) [40:00]

**Books by Eckhart Tolle**: [Eckhart Tolle’s books](https://shop.eckharttolle.com/collections/books) | (eckharttolle.com) [42:40]

**Dan interviews Eckhart Tolle**: [ABC News Feb. 24, 2009 Interview](https://www.youtube.com/watch?v=Scj4hJuKhI0) | COHAL DRAGOS MIHAI (youtube.com) [45:45]

**Book that highlights the difference between altering states vs. traits with meditation**: [Altered Traits: Science Reveals How Meditation Changes Your Mind, Brain, and Body](https://www.amazon.com/Altered-Traits-Science-Reveals-Meditation/dp/0399184384) by Daniel Goleman and Richard J. Davidson | (amazon.com) [49:30]

**Episodes of Ten Percent Happier Podcasts with Richie Davidson and Danny Goleman (authors of Altered Traits)**: [52:20]

- [#1: Dalai Lama](https://podtail.com/podcast/10-happier-with-dan-harris/1-dalai-lama/) | (podtail.com)
- [#29: Dr. Richard Davidson](https://podcasts.apple.com/bm/podcast/29-dr-richard-davidson/id1087147821?i=1000373946037) | (Apple Podcasts)
- [#72: Daniel Goleman, Diving into ‘Emotional Intelligence’ (Bonus Episode!)](https://podcasts.apple.com/my/podcast/72-daniel-goleman-diving-into-emotional-intelligence/id1087147821?i=1000384368044) | (Apple Podcasts)
- [#98: Daniel Goleman, Dr. Richard Davidson, ‘Altered Traits’ (Bonus!)](https://podcasts.apple.com/us/podcast/98-daniel-goleman-dr-richard-davidson-altered-traits-bonus/id1087147821?i=1000391981467) | (Apple Podcasts)

**Mark Epstein as a guest on Dan’s podcast**: [57:45]

- [#22: Dr. Mark Epstein](https://podcasts.apple.com/nz/podcast/22-dr-mark-epstein/id1087147821?i=1000371162457) | (Apple Podcasts)
- [#172: Mark Epstein, Combining Buddhism and Western Psychotherapy](https://podcasts.apple.com/us/podcast/172-mark-epstein-combining-buddhism-western-psychotherapy/id1087147821?i=1000428769857) | (Apple Podcasts)

**Mark Epstein has written beautiful books about the overlap between psychology and Buddhism**: [Books by Mark Epstein](https://markepsteinmd.com/?cat=2) | (markepsteinmd.com) [57:45]

**The Buddha’s seminal speech after years of becoming enlightened**: [Four Noble Truths](https://en.wikipedia.org/wiki/Four_Noble_Truths) | (wikipedia.org) [1:02:00]

**Meditation may lower blood pressure**: [Benefits of mindfulness meditation in reducing blood pressure and stress in patients with arterial hypertension.](https://www.ncbi.nlm.nih.gov/pubmed/30425326) (Marquez et al., 2019) [1:07:30]

**Meditation may boost immune system**: [Mindfulness meditation and the immune system: a systematic review of randomized controlled trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4940234/) (Black et al., 2016) [1:07:30]

**Brain scans show the meditation can reduce amygdala activity**: [Effects of Mindfulness-Based Stress Reduction (MBSR) on Emotion Regulation in Social Anxiety Disorder](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4203918/) (Goldin et al., 2014) [1:07:30]

**The first fiction book Peter has read in almost 20 years**: [The Alchemist](https://www.amazon.com/Alchemist-Paulo-Coelho/dp/0061122416) by Paulo Coelho | (amazon.com) [1:10:00]

**Funny movie that both Dan and Peter enjoy**: [Fletch](https://en.wikipedia.org/wiki/Fletch_(film)) | (wikipedia.org) [1:11:15]

**Dan moderated a debate between Sam Harris and Deepak Chopra**: [Does God Have a Future? NightLine DEBATE FULL](https://www.youtube.com/watch?v=wi2IC6e5DUY) | ChristopherHitchslap (youtube.com) [1:16:00]

**Sequels that Dan jokingly mentions when he’s describing the desired to have a “sequel” to his first meditation breakthrough**:

- [Breakin’ 2: Electric Boogaloo](https://en.wikipedia.org/wiki/Breakin%27_2:_Electric_Boogaloo) | (wikipedia.org) [1:22:45]
- [Pajama Jammy Jam](https://www.youtube.com/watch?v=PYzMQC49NfM) | David Cush (youtube.com) [1:22:45]

**Movie that Peter uses as an analogy for how it feels to have a meditation “breakthrough”**: [The Matrix](https://en.wikipedia.org/wiki/The_Matrix) | (wikipedia.org) [1:23:30]

**Paper that might help explain why concentration is pleasurable**: [A Wandering Mind is an Unhappy Mind](https://www.danielgilbert.com/KILLINGSWORTH%20&%20GILBERT%20(2010).pdf) | Matthew A. Killingsworth and Daniel T. Gilbert (danielgilbert.com) [1:28:00]

**Term for the good feeling you get when being compassionate or helping others**: [Helper’s high](https://en.wikipedia.org/wiki/Prosocial_behavior#Helper's_high) | (wikipedia.org) [1:44:15]

**Other popular meditation apps that Peter says pale in comparison to 10% Happier and Waking Up**:

- [Calm](https://www.calm.com/) | (calm.com) [2:04:15]
- [Headspace](https://www.headspace.com/headspace-meditation-app) | (headspace.com) [2:04:45]

§

## People Mentioned

- [Peter Jennings](https://en.wikipedia.org/wiki/Peter_Jennings) (legendary journalist who Dan trained under)  [8:20, 42:00, 1:59:45, 2:15:15]
- [Robin Roberts](https://en.wikipedia.org/wiki/Robin_Roberts_(newscaster)) (anchor of ABC’s Good Morning America) [10:15]
- [Charlie Gibson](https://en.wikipedia.org/wiki/Charles_Gibson) (retired host of Good Morning America) [11:00]
- [Diane Sawyer](https://en.wikipedia.org/wiki/Diane_Sawyer) (famous American television journalist) [13:15, 2:00:45]
- [Gabor Maté](https://en.wikipedia.org/wiki/Gabor_Mat%C3%A9_(physician)) (wrote book In the Realm of Hungry Ghosts) [17:15]
- [Judson Brewer](https://www.ted.com/speakers/judson_brewer) (neuroscientist researching meditation’s effect on the brain, wrote [The Craving Mind](https://www.amazon.com/Craving-Mind-Cigarettes-Smartphones-Hooked/dp/0300223242?tag=teco06-20)) [18:45]
- [Nancy Lee Harris](https://en.wikipedia.org/wiki/Nancy_Lee_Harris) (Dan’s mom, editor at The New England Journal of Medicine) [20:30]
- [Jay R. Harris](https://www.lbbc.org/about/about-us/jay-r-harris-md) (Dan’s dad, former Chief of Radiation Oncology at the Brigham Young Women’s and one of the pioneers in radiation therapy) [20:30]
- [Sumner Redstone](https://en.wikipedia.org/wiki/Sumner_Redstone) (Dan’s friend lived a couple doors down from him) [21:30]
- [Jerry Colonna](https://en.wikipedia.org/wiki/Jerry_Colonna_(financier)) (Dan’s executive coach) [22:45, 1:32:50, 1:51:50, 2:05:15]
- Robert Johnson (Dan’s angry grandfather who Dan feels like he has part of him inside himself) [24:45, 37:00, 1:50:30]
- [Matt Harris](https://www.baincapitalventures.com/team/matth/) (Dan’s brother, venture capitalist) [28:00, 1:40:30]
- [Sam Harris](https://en.wikipedia.org/wiki/Sam_Harris) (Waking Up app, mutual friend) [32:00, 44:50, 1:15:45]
- [Joseph Goldstein](https://en.wikipedia.org/wiki/Joseph_Goldstein_(writer)) (one of the meditation trainers on 10% Happier app) [32:15, 1:15:30, 1:40:15]
- [Jeff Warren](https://jeffwarren.org/) (leads a great walking meditation on Dan’s 10% Happier app) [32:15, 1:14:15]
- [Dalai Lama](https://en.wikipedia.org/wiki/Dalai_Lama) [34:30]
- [Eckhart Tolle](https://en.wikipedia.org/wiki/Eckhart_Tolle) (Dan credit’s Eckhart for “lifting the curtain on my own mind”) [42:30, 1:06:15]
- [Oprah Winfrey](https://en.wikipedia.org/wiki/Oprah_Winfrey) (helped Eckhart Tolle get his message out to the masses) [43:00]
- [Paris Hilton](https://en.wikipedia.org/wiki/Paris_Hilton) [43:00]
- [Deepak Chopra](https://en.wikipedia.org/wiki/Deepak_Chopra) [47:00, 1:16:00]
- [Richard Davidson](https://www.richardjdavidson.com/about) (wrote Altered Traits) [52:20]
- [Daniel Goleman](https://en.wikipedia.org/wiki/Daniel_Goleman) (wrote Altered Traits) [52:20]
- [Bianca Harris](https://health.usnews.com/doctors/bianca-harris-681255) (Dan’s wife, pulmonologist) [57:30, 1:37:00, 1:47:15, 2:02:45]
- [Mark Epstein](https://en.wikipedia.org/wiki/Mark_Epstein) (influential in getting Dan into meditation and going on a silent retreat) [57:45, 1:15:30]
- [Buddha](https://en.wikipedia.org/wiki/Gautama_Buddha) (Siddhārtha Gautama) [58:00]
- [Rāhula](https://en.wikipedia.org/wiki/R%C4%81hula) (Buddha’s son) [1:01:00]
- [Anika Harris](https://twitter.com/annakaharris?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (meditation, author, wife of Sam Harris) [1:16:30]
- [Spring Washam](https://twitter.com/SpringWasham) (saved Dan from quitting the silent retreat) [1:19:20]
- [Neo](https://en.wikipedia.org/wiki/Neo_(The_Matrix)) [1:23:30]
- [Terry Real](https://www.terryreal.com/about/) (author of [I Don’t Want to Talk About It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398)) [1:50:50]
- [Tom Brokaw](https://en.wikipedia.org/wiki/Tom_Brokaw) [1:59:45]
- [Dan Rather](https://en.wikipedia.org/wiki/Dan_Rather) [1:59:45]
- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) [1:59:45]
- [Michael Jordan](https://en.wikipedia.org/wiki/Michael_Jordan) [1:59:45]
- [Anderson Cooper](https://en.wikipedia.org/wiki/Anderson_Cooper) [2:00:45]
- [George Stephanopoulos](https://en.wikipedia.org/wiki/George_Stephanopoulos) [2:00:45]
- [Diane Sawyer](https://en.wikipedia.org/wiki/Diane_Sawyer) [2:00:45]
- [Sean Hannity](https://en.wikipedia.org/wiki/Sean_Hannity) [2:00:45]
- [Joe Scarborough](https://en.wikipedia.org/wiki/Joe_Scarborough) [2:00:45]
- [Michael Strahan](https://en.wikipedia.org/wiki/Michael_Strahan) [2:00:45]
- [Matt Lauer](https://en.wikipedia.org/wiki/Matt_Lauer) [2:00:45]
- [Charlie Rose](https://en.wikipedia.org/wiki/Charlie_Rose) [2:00:45]
- [Jake Tapper](https://en.wikipedia.org/wiki/Jake_Tapper) (learned from Peter Jennings) [2:20:00]
- [Chris Cuomo](https://en.wikipedia.org/wiki/Chris_Cuomo) (learned from Peter Jennings) [2:20:00]
- [John Berman](https://en.wikipedia.org/wiki/John_Berman) (learned from Peter Jennings) [2:20:00]
- [Bob Woodruff](https://en.wikipedia.org/wiki/Bob_Woodruff) (learned from Peter Jennings) [2:20:00]
- [Martha Raddatz](https://en.wikipedia.org/wiki/Martha_Raddatz) (learned from Peter Jennings) [2:20:00]
- [Jonathan Karl](https://en.wikipedia.org/wiki/Jonathan_Karl) (learned from Peter Jennings) [2:20:00]
- [Pierre Thomas](https://en.wikipedia.org/wiki/Pierre_Thomas_(journalist)) (learned from Peter Jennings) [2:20:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/09/dan-harris-bio-image-500x500.jpeg)

##### Dan Harris

Dan Harris is a correspondent for ABC News, co-anchor for the weekend edition of Good Morning America, and formerly the co-anchor of Nightline. He has reported from all over the world, covering wars in Afghanistan, Israel/Palestine, and Iraq, and producing investigative reports in Haiti, Cambodia, and the Congo. He has also spent many years covering religion in America, despite the fact that he is agnostic.

He wrote the book [10% Happier](https://www.amazon.com/10-Happier-Self-Help-Actually-Works/dp/0062265431), a #1 New York Times bestseller, then launched the [Ten Percent Happier podcast](https://www.tenpercent.com/podcast) and co-founded the [Ten Percent Happier meditation app](https://www.tenpercent.com/). He is currently working on a new book about kindness and compassion with an estimated release date of 2021.