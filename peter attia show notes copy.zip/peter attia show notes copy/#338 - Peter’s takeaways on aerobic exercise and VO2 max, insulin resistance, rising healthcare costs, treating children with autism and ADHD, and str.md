# #338 ‒ Peter’s takeaways on aerobic exercise and VO2 max, insulin resistance, rising healthcare costs, treating children with autism and ADHD, and strength training | Podcast Summary #4

**Source:** [https://peterattiamd.com/qps4/](https://peterattiamd.com/qps4/)

---

In this podcast summary episode, Peter summarizes his biggest takeaways from the last three months of guest interviews on the podcast. Peter shares key insights from his discussions on diverse topics such as aerobic efficiency and VO2 max with Olav Aleksander Bu; insulin resistance with Ralph DeFronzo; economics of the US healthcare system and cost-saving strategies with Saum Sutaria; diagnosis and treatment of autism, ADHD, and anxiety in children with Trenna Sutcliffe; and strength training with Mike Israetel. Additionally, Peter shares any personal behavioral adjustments or modifications to his patient care practices that have arisen from these fascinating discussions.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [episode #338 show notes page](https://peterattiamd.com/qps4). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of topics to be discussed [2:00];
- Olav Aleksander Bu Pt.2 episode: metrics to track aerobic efficiency and insights about VO2 max, and the ability of increased carbohydrate consumption to boost performance [4:30];
- The best practices for performing a VO2 max test, the differences between VO2 max training and all-out efforts, and the role of energy intake in endurance performance [14:45];
- Ralph DeFronzo episode: the pathophysiology of insulin resistance and type 2 diabetes—how it impacts different organs, flaws in conventional diabetes treatment, and more [24:30];
- Understanding type 2 diabetes beyond the traditional triumvirate of features: the “ominous octet” describes changes in other organs [31:45];
- Pharmacological treatments for insulin resistance and type 2 diabetes [41:30];
- The importance of early detection and intervention in insulin resistance [50:30];
- Saum Sutaria episode: the economic and systemic drivers of high healthcare costs in the U.S. [54:00];
- Reducing health care costs: redefining health insurance, lowering drug prices while maintaining innovation, leveraging AI for efficiency, and more [1:07:15];
- Trenna Sutcliffe episode: insights on autism, ADHD, and anxiety in children—definitions and diagnosis [1:11:45];
- Exploring the rising prevalence of autism spectrum disorder [1:17:15];
- Trenna’s views on caring for children with autism [1:21:15];
- Misconceptions around vaccines and autism [1:26:00];
- Mike Israetel episode: insights about strength training, minimum effective dose, troubleshooting plateaus, tips for beginners, and more [1:28:15];
- Topics Peter is interested in exploring in future podcasts [1:40:15]; and
- More.

---

The Peter Attia Drive

#338 ‒ Peter’s takeaways on aerobic exercise and VO2 max, insulin resistance, rising healthcare costs, treating children with autism and ADHD, and strength training | Podcast Summary #4

---

## Show Notes


---

\***Notes from intro**:

- Welcome to another special AMA episode, this is the 4th installment of the podcast summary
- In this conversation, Peter discusses what he learned from the last quarter of interviews
  - What he thinks were some of the most important insights
  - Things that have resulted in a change in his work and behavior
- Please note, listening to this episode does not remotely constitute a substitute for listening to the actual episodes
- His hope that listening to this episode helps you think about refining what you might have learned there, and if something you hear in one of these summaries is of interest and you missed the original episode, you’ll go back and listen to it
- Today, we cover interviews with: Olav Aleksander Bu, Ralph DeFronzo, Saum Sutaria, Trenna Sutcliffe, and Mike Israetel
- Throughout these, we talk on various topics
  - VO2 max
  - Power at VO2 max
  - Insulin resistance
  - Metformin
  - SGLT2 inhibitors
  - GLP-1 agonists
  - US healthcare costs
  - Diagnosis and treatment approaches to autism
  - ADHD and anxiety
  - Zone 2 and resistance training
  - Learning all the effects of anabolic steroids
- That sounds like a hodgepodge of topics, but that’s because it’s pulled from all of these discussions

## Overview of topics to be discussed [2:00]

**Purpose of the Episode**:

- Review past episodes from the quarter.
- Highlight main takeaways, insights, and changes in behavior or practice based on the discussions.
- Serve as an augmentation to the original episodes, not a replacement.
- Many listeners use this summary episode to revisit key moments in prior episodes.

**Topics Covered in the Past Quarter**

- [Olav Aleksander Bu Pt.2](https://peterattiamd.com/olavaleksanderbu2/) – Training, Performance, and VO2 Max
  - Second appearance on the podcast.
  - Attempted to make the episode less technical than the first, but ended up being equally or more technical.
  - Breakdown of key insights and takeaways from Olav’s expertise.
- [Ralph DeFronzo](https://peterattiamd.com/ralphdefronzo//) – Insulin Resistance, Type 2 Diabetes, and Medications
  - Discussion on Metformin, SGLT2 inhibitors, and other drugs.
  - In-depth analysis of insulin resistance and diabetes management.
- [Saum Sutaria](https://peterattiamd.com/saumsutaria/) – U.S. Healthcare System
  - Exploration of why U.S. healthcare costs nearly double per capita compared to other developed nations.
  - Examination of inefficiencies and systemic issues in healthcare.
- [Trenna Sutcliffe](https://peterattiamd.com/trennasutcliffe/) – Autism, ADHD, and Anxiety
  - Review of research and insights into neurodevelopmental conditions.
  - Discussion of anxiety and its relationship to ADHD and autism.
- [Mike Israetel](https://peterattiamd.com/mikeisraetel//) – Resistance Training
  - Deep dive into resistance training principles.
  - Impact on health, longevity, and overall well-being.

**Peter’s Reflection on the Past Quarter**

- Volume of Notes Taken:
  - This quarter had the most extensive set of notes Peter has ever taken for a quarterly review.
  - The episodes with Ralph (diabetes) and Som (healthcare) stood out, with 3-4 times the usual amount of notes.
  - Attempted to synthesize the insights but acknowledges the dense nature of these discussions.
- Expectation for a Long Episode:
  - Given the richness of the topics covered, this summary episode might be the longest quarterly review yet.

## Olav Aleksander Bu Pt.2 episode: metrics to track aerobic efficiency and insights about VO2 max, and the ability of increased carbohydrate consumption to boost performance [4:30]

[#331 ‒ Optimizing endurance performance: metrics, nutrition, lactate, and more insights from elite performers | Olav Aleksander Bu (Pt. 2](https://peterattiamd.com/olavaleksanderbu2/)) (January 13, 2025)

\*\*\*

**Peter’s biggest insights from the second episode with Olav**

- We talked beforehand about trying to make it a little less technical because the first one was pretty technical
- Peter could not resist the tractor pull of trying to explain some technical things
- Looking back, he was probably more technical
- They started the discussion by explaining the difference between things like functional threshold power and critical power

***Peter hesitates to bring these up now because he just doesn’t think they’re relevant unless you are a cyclist***

**⇒** The **functional threshold power (or FTP)** is the power that you can hold for one hour

- One way to test it: get on a stationary bike and ride as hard as you can without blowing up for 1 hour
- Whatever the average power is that you held is your FTP
- When Peter was a cyclist, he would do this in a 20-minute test and would typically discount it by 10%
  - Olaf suggested discounting by only 5%
  - In Peter’s experience, 10% was necessary

**⇒** **Critical power** is very similar, but rather than it being the power you can hold for an hour, it’s the power you can hold for 30 to 40 minutes

- The important distinction here is critical power is much easier to calculate
- You can do it from a set of curves that are derived from 3-4 individual tests that are much shorter

*Why is this relevant?*

- If you want to have other **metrics** beyond VO2 max **for higher end aerobic efficiency**, you might want to know your FTP or critical power, and critical power is much easier to measure
- These days Peter doesn’t spend a lot of time worrying about his FTP
  - In fact, he doesn’t know what it is

***It made Peter realize maybe he ought to do a critical power test just so that he has another benchmark to be tracking***

**A personal insight about power at VO****2** **max (PVO****2** **max)**

- This is the relationship between VO2 max and PVO2 max (or vVO2 max [which is velocity at VO2 max])
- VO2 max is maximum ventilation, meaning maximum oxygen consumption
  - It’s usually sustained for at least a minute when you’re doing the test
  - It’s the highest amount of oxygen in liters per minute that can be consumed for a minute
- This is achieved during a ramp exercise, almost exclusively done on a stationary bike or on a treadmill
- And when you hit that VO2 max, you will note the velocity
  - If you’re on a treadmill, assuming you’re running flat
  - Or if you’re on a bike, then your PVO2 max is the power that you’ve achieved
- Some have argued that vVO2 max or PVO2 max are actually more predictive of sports specific performance than just the number VO2 max
- Peter thinks there might be something to that because he shared his numbers with Olaf and the truth of it is he has always had a very low PV02 max to VO2 max
  - Stated another way, he has always had a VO2 max that is higher than many people who are much better cyclists
  - It wasn’t uncommon when he was training that his VO2 max was 15 points higher than people who had a higher FTP than him
- What Olaf suggested speaks to an **inefficiency** there
  - Peter may be over-training aerobically and undertraining anaerobically
  - That inefficiency means that he is actually requiring more energy across the board to put out more power

*Something interesting that comes from that is there might be an association between people like that and a lesser propensity to gain weight*

- Every time Peter has done a resting metabolic expenditure test (he’s actually done the doubly labeled water test and the metabolic chambers), he always seems to have a through-the-roof energy expenditure for his body weight

For the first time, that all came together

- On the one hand he has an advantage perhaps in that he has a very high energy expenditure
  - So relative to somebody else who eats as much as he does, he’s going to be leaner
- The flip side of that is he is actually quite inefficient at utilizing energy

**Beyond training, is there anything a person can do to boost their VO****2** **max**

**⇒** Beetroot concentrate is rich in nitrates

- The body converts it to nitric oxide and that helps with vasodilation (opens up capillary beds)
- Anything that impairs nitric oxide synthase is going to impede it
  - And there are many things that do from homocysteine to insulin resistance
- At the elite level, this doesn’t make much of a difference, but in amateur athletes, it can be about a 5% boost
  - [Peter discussed evidence around benefits of nitrates from beetroot concentrate in a [newsletter](https://peterattiamd.com/nitrates-athletic-performance/) from 2022]

*A strategy that is more gamesmanship than anything else*

**⇒** As you approach failure in a VO2 max test, do a few breath holds

- That produces a significant boost in VO2 max
- It’s just a reactive overconsumption of oxygen (Peter doesn’t know if that means anything)

**Some data that suggests that acetaminophen use can boost peak endurance performance by 1-2%**

- Kristian and Gustav (the 2 world-class triathletes Olav trains) are not using this
- Olav raised an interesting point: while acetaminophen (or Tylenol) can obviously reduce the perception of pain (which has been one of the arguments for why it boosts performance), it may impair the athlete from giving off heat (from heat dissipation)
- He questioned whether or not that would be a worthwhile trade-off
- For Peter, that begs the desire to do an experiment and find out

**What is the upper limit of carbohydrate consumption while doing cardio activity and racing**?

- This is relevant to high performance athletes (a triathlete, cyclist, or ultra marathon runner)
- If you do the math, energy expenditure of doing an Ironman is somewhere between 700-1000 kcal/hour (depending on your fitness level)
  - Let’s say you’re going easy, you’d be at 600-700 kcal/hour
- We don’t have that much stored glycogen
  - You’ve got maybe 50, 100, 200 g of glycogen stored (if you have really big muscles)
- That’s going to supply you for maybe 1.5 hours
  - You’re going to run out pretty quickly
- Thereafter, you have to meet your needs from body fat and intake of carbohydrates
- The conventional thinking has always been that you can only consume about 60 g of glucose per hour
  - And 60 grams of glucose, of course, is only about 240 kilocalories
- This has always been one of Peter’s main arguments for why being fat adapted is very important because if you’re consuming that 60 of glucose and that’s giving you whatever it’s giving you, you have to get the balance from fat and you’re only going to do that if you’re heavily fat adapted
  - So you get into this cycle

> “*The biggest innovation in endurance sports like the Tour de France and Ironman over the past decade is the amount of glucose that these guys are able to consume*.”‒ Peter Attia

- Olav talked about numbers Peter had never heard before
- Recently, Peter [interviewed Tadej Pogačar](https://peterattiamd.com/tadejpogacar/), the greatest cyclist on the planet
- His numbers blew Peter’s mind of the type of carbohydrate intake that he was tolerating: 150, 180 g/hour

***Olaf said that they’re now pushing triathletes at the world-class level to 240 g/hour, and what that basically tells you is you can meet all of your glycolytic needs indefinitely through that***

**⇒** You have to train this system

- These are athletes that consume gels and eat carbohydrates at a 12% mixture
  - 12% mixture means 120 grams per liter
  - 10% mixture is 100 grams per liter, etc.
- Conventional wisdom is that our gastrointestinal system cannot tolerate more than a 5% mixture
- Personally, when Peter used to do ultra-distance stuff, he had a hard time going above 5-6%

***You can train your GI system to utilize a 12% carbohydrate mixture***

- How these guys are drinking 2 liters per hour of a 12% mixture (which would be 240 grams), Peter simply can’t fathom
- But clearly, that’s what they’re doing or they’re doing some combination of consuming gels plus water that amounts to that mixture
- When you look at the hyperbolic performance of endurance athletes today, it’s very quick and tempting to think they’re using drugs we haven’t figured out yet

***Another explanation is that they literally figured out how to double the octane of the fuel***

- It’s like a car that went from racing at 70 octane to 140 octane
  - Peter’s not even sure if there’s a 140, but you know what he’s  getting at

## The best practices for performing a VO2 max test, the differences between VO2 max training and all-out efforts, and the role of energy intake in endurance performance [14:45]

**Protocol to make sure you’re giving it your best when you do a VO****2** **max test**

- This is something Peter has started implementing with patients if they do a VO2 max test
- 1 – You want to do a VO2 max test at the time of day that you would normally train
- 2 – You want to be well rested, minimize traveling the day before, etc.
- 3 – The warmup should be:
  - 6 minutes of very, very easy
  - 6 minutes of Zone 2
  - 3 minutes at threshold (or FTP) 2-3x at a 10-15 second burst at about what you expect your PVO2 max is
- 4 – A relatively short rest of 10-15 minutes, get a drink, then do the test

*This is a decent warmup*

- When Nick did VO2 max testing, he doesn’t recall if they had him do any kind of warmup
  - He kind of hit the treadmill and then started going
- This has people go through a little bit of a workout before the test begins

*Peter does most of his VO**2* *max testing outdoors now using the* [*VO2 Master*](https://vo2master.com/) *device*

- He leaves the house and rides 10-15 minutes to the place where he does a hill repeat (that’s the warmup)
  - There are a couple of short little climbs where he’ll do 30 seconds of relatively high power just to get up over a little pitch
- He will do 2-3 full runs of the hill at escalating power before he’s truly going to hit his max
- He’ll do a 4-5 minute up, maybe 85% of what his maximum power would be for that climb, come down for the same amount of rest period
- Go up again at maybe 90% of what his maximum power would be, come back down, and then maybe he would go and give it
  - The third one would be up there
  - By the time he’s done it, he’s really warmed up

*A patient did his VO**2* *max test at a University facility*

- Peter was surprised what his number was ‒ it was lower than expected
- The patient was told to get on the treadmill and just start cranking it
- His VO2 max was determined about 5 minutes into it

Peter’s takeaway, “*That’s a garbage protocol. You were not warmed up and ready to do that*.”

**Long-term preparation for a VO****2** **max test**

**⇒** Peter has noticed that his performance takes a hit in the summer

- He prefers to test VO2 max in the spring, fall, or winter

*In the month leading up to it, so the past month, have you changed your training at all? Are you doing anything in particular for it?*

- Not at all
- This is just a data check

*Just as a reminder for people, what does your VO**2* *max training look like in a typical week? Is that 1 day a week?*

- Just 1 day a week
- A typical week is 3 days of Zone 2 and 1 day a week of interval training
  - Interval training at that specific 4, 5, upper limit 8-minute intervals
- When we talk about VO2 max training, Nick thinks back to one of the first video podcasts they ever did, with [Alex Hutchinson [episode #151]](https://peterattiamd.com/alexhutchinson/)

*A lot of times when people think of VO**2* *max training (or Tabata training or going all-out), people lose sight of how hard that actually is*

- VO2 max training hurts less than a true [Tabata](https://en.wikipedia.org/wiki/High-intensity_interval_training#Tabata_regimen)
- That’s where people have a hard time understanding what all-out means

**⇒** Technically, Peter doesn’t think the human body is capable of going all-out for more than 10 seconds

- A Tabata is a 20 second effort followed by a 10 second rest repeated 8x
- Even at the level of even a 20 second Tabata, there’s a governor that is self-regulating how hard you go
- The **reverse Tabata** where you go 10 seconds all out, 20 seconds rest for 8 rounds, that’s about the closest thing that Peter thinks we’re capable of doing as a truly all-out

***You will increase your VO******2*** ***max doing that type of an exercise, but not nearly, not nearly as much as if you’re doing intervals in the 3-8 minute range***

**⇒** By definition, if you’re doing something for 3-8 minutes, you’re not going all-out

- What you’re trying to do is go as hard as you can for that distance and for that time
- It’s a different animal
- Peter thinks it hurts more because it’s a lower level of peak pain, but it’s spread out over a longer period of time
  - So the area under the pain curve is greater
  - But it’s far from all-out and at any moment in time, the pain is not the same

**A 4-minute interval**

*You’re not starting that going as hard as you can and trying to sustain it for 4 minutes; walk through how you think about the energy you put out spread across those 4 minutes*

- Technically, the power is constant throughout the 4 minutes
  - Peter knows how many watts he wants to produce and the average wattage should over the 4 minutes
- Let’s just say he wants to do 4 minutes at 300 watts
  - Of course, you’re outdoors, so you don’t have complete control, it’s always jumping around
  - He’s really watching the 3-second power tracing and the average power to keep it there
- It should be really easy for the 1st minutes
  - If you’re dying, you’ve set your target too high
- Half-way in (2-2.5 min), Peter still feels pretty good
  - His heart rate is going to be within 5 beats of what its maximum is
- The “pain train” starts to leave the station at about 3-3.5
  - That’s when it really starts to feel miserable
- That last minute is really difficult

***If you’ve done this right, when you finish, you’re going to need 4-5 minutes of very, very easy pedaling to let your heart rate come back down before your repeat it***

- The goal is not to have killed yourself in the interval such that you you can’t do it again

**⇒** What you’re trying to do is preserve that power across all the intervals

**Follow-up on carbohydrate consumption explaining an increase in performance**

*How much of a difference do you think that makes?*

- For people like Peter and most people listening to this podcast, this is not something that should be on our radar
  - He’s not doing a 10-hour endurance event again
- If he’s exercising for 2 hours, that’s a long time ‒ and at 2 hours, he’s fine with just water
  - He’s living off his own glycogen and whatever
- It’s very difficult now to think about people competing at a world-class level in cycling and Ironman because what Olaf and many others have now argued is **the problem of peak endurance is effectively an energetic problem**
- It’s basically a question of how much chemical energy in the form of food can you convert into electrical energy via the metabolism of food back into chemical energy in the form of ATP back into mechanical energy

***It’s just an energy transfer problem, and more energy input means more energy output***

- The more logs you can put into the fire, the hotter the fire burns, the more steam it makes, the faster the wheel turns
- What we’ve seen over the past decade is quite literally a more than doubling of the feedstock that goes into the furnace

## Ralph DeFronzo episode: the pathophysiology of insulin resistance and type 2 diabetes—how it impacts different organs, flaws in conventional diabetes treatment, and more [24:30]

[#337 – Insulin resistance masterclass: The full body impact of metabolic dysfunction and prevention, diagnosis, and treatment | Ralph DeFronzo, M.D.](https://peterattiamd.com/ralphdefronzo//) (February 24, 2025)

\*\*\*

- This episode might set the record for the most notes Peter has ever taken in a podcast
  - He actually transcribed his notes twice because he’s trying to make them more condensed
- This is one where you just have to listen to this podcast a couple of times
- It’s more of a senior level class on the subject

**Expectations for what was discussed**

- Focused more the pathophysiology, the organ level organization of type 2 diabetes
- We didn’t talk about some of the important tools for addressing insulin resistance, such as diet, exercise, and sleep

> “*The most mind-blowing was really around his approach to the pharmacologic management of this*.”‒ Peter Attia

- Peter is not a diabetologist
- When he does have patients with type 2 diabetes, he tends to do the things that Ralph suggests we not do (he’ll explain shortly)\_
- Peter learned a great deal
- They deliberately did not spend oodles of time redefining and explaining at the molecular level exactly what is happening in insulin resistance
- Peter did a podcast with Ralph’s understudy, [Gerald Schulman [episode #140]](https://peterattiamd.com/geraldshulman/), a few years ago where they did a very deep dive on what’s happening at least in the muscle
  - Which is one of the more critical organs and maybe one of the first organs to be affected

**A brief summary of what’s going on at the molecular level in the muscle insulin resistance**

- Everybody can picture a little cell in the muscle, a myocyte
- [Insulin](https://en.wikipedia.org/wiki/Insulin) is secreted as a pro-peptide from the pancreas from a [ꞵ-cell](https://en.wikipedia.org/wiki/Beta_cell)
- This pro-insulin molecule gets broken down into [C-peptide](https://en.wikipedia.org/wiki/C-peptide) and insulin
- Insulin makes its way onto the [insulin receptor](https://en.wikipedia.org/wiki/Insulin_receptor)
- The insulin receptor then signals something called [IRS-1](https://en.wikipedia.org/wiki/Insulin_receptor_substrate_1) inside the cell, which then activates a pathway

The [PI3K/AKT pathway](https://en.wikipedia.org/wiki/PI3K/AKT/mTOR_pathway), which then basically activates a system called [PPARγ](https://en.wikipedia.org/wiki/Peroxisome_proliferator-activated_receptor_gamma), that then brings something called the [GLUT4 transporter](https://en.wikipedia.org/wiki/GLUT4) to the surface of the cell [see the asterisks in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f1-qps4.png)

**Figure 1. Insulin receptor (IR) signaling through the IRS-1/PI3K/AKT pathway.** Image credit: [*Expert Reviews in Molecular Medicine* 2012](https://pubmed.ncbi.nlm.nih.gov/22233681/)

*What all that means*

- The GLUT4 transporter is like a straw
  - Picture a straw that gets poked through the skin of a balloon, but without bursting it
  - The balloon is the cell, the straw is the transporter
  - Now anything on the outside can passively flow into the cell
    - Assuming the gradient is right for that to happen (which it is)
  - Glucose is outside the cell, glucose can now come into the cell

***That’s how insulin facilitates a transport of glucose into a muscle***

*An aside, and we didn’t talk about this on the podcast*

**⇒** GLUT4 translocation can also occur and does occur with aerobic exercise

- We have what’s called insulin-mediated and **non-insulin-mediated glucose uptake**
- Peter wrote about this quite a bit in [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=2ZYBSH4PVWXHU&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZdGttk3nhLTMuCT6AR1kYNZM5GlbGc7sG7frYGTuNiGpkoBZiYOC6EYxK7QKEQgkYogUA2OVAmiwc-Tl62q0kAHeGIM98gUS3_Sgh_-H6Uprg_G_fPia6T9kS8P662eumfyipVF5SkV-05UKJnFIsaksZK18aV3Q_KU2K3DF4TrbFOsrRoCYOdISbkxeFPtx_0GOEyRQE4gbz-eJG2wwC7w.uiBJO2j8aQHP-pgagACGHl9WOToCBHtOBAivaOJ1Wzk&dib_tag=se&keywords=outlive&qid=1734100779&sprefix=outlive%2Caps%2C101&sr=8-1), and he talked about the differences

***This is a big part of why exercise is such an important part of glucose disposal, especially for people with diabetes***

**When a person is insulin resistant, what does that mean?**

- It means that when insulin binds to the insulin receptor, it kind of gets stuck
- For the same level of insulin, it doesn’t kick off the IRS-1/PI3K/Akt/PPARγ pathway
- And ever-increasing levels of insulin are needed to actually lead to the uptake in glucose

*What is a normal level of insulin?*

- In a metabolically healthy person eating a well-balanced diet
  - This is a person who’s not carbohydrate-restricted
  - This is a person who’s getting 50 to 55% of their calories from carbohydrates, 15 to 20% from protein, and the rest from fats

Put somebody on a “normal diet,” if they’re insulin sensitive, they are going to be making a grand total of probably ***less than 35 units of insulin per day***

**⇒** If you are on exogenous insulin and it’s 40, 50, 60, 200 units of insulin a day, you have to ask yourself, “*What is going on? Why is it that I’m now requiring even more insulin than I would’ve ever made at a healthy state?*”

- The answer is because the muscle and the liver, as we’ll talk about, are very insulin resistant

**How is all of this measured?**

- We spent time discussing a technique called an [euglycemic clamp](https://en.wikipedia.org/wiki/Glucose_clamp_technique) (developed by Ralph and his colleagues)
- This is not a test you will have ever done
- You don’t go to your doctor and get an euglycemic clamp
- Those of us who read the literature all the time are familiar with this, and it’s something that is only done in the hospital for a research setting

*How the euglycemic clamp technique works*

- You take a subject and put an IV in each arm
- Euglycemic means constant level of glucose
- So, in one arm, they start infusing glucose
- In the other arm, they start infusing insulin
- They are adjusting the glucose intake,t(he concentration of glucose) to hold the serum glucose level constant
  - So if the person shows up and their blood glucose is 100 mg/dL, they will infuse insulin and glucose such that they keep the glucose at 100 mg/dL
- And they are raising the insulin dose as they go

**⇒** What they’re looking to see is how much glucose do they need to infuse

***The more glucose you need to infuse, the more insulin-sensitive you are***

- This is where we got into what is happening to each set of cells in the body in response to insulin
- For Peter, this was the most eye-opening

**The standard definition of type 2 diabetes (the triumvirate)**

**⇒** What is happening in the liver, in the muscle, in the pancreas (in type 2 diabetes)

- The muscle is getting resistant to insulin
- When that happens, more and more insulin is required to dispose of the same amount of glucose
- The pancreas is getting fatigued, so the [ꞵ-cell](https://en.wikipedia.org/wiki/Beta_cell) is having a harder and harder time getting insulin out, and eventually, it begins to fatigue
- Then the liver itself is also becoming resistant to the effects of insulin

*What should the liver do when insulin goes up?*

- It should stop making glucose
- If insulin is up, it means glucose is up in the periphery, and the last thing the liver should do is undergo gluconeogenesis (making glucose) or even letting glucose into the circulation (hepatic glucose output)

## Understanding type 2 diabetes beyond the traditional triumvirate of features: the “ominous octet” describes changes in other organs [31:45]

- All of that is pretty logical, but what Ralph has done is taken that and expanded that from what he refers to as the triumvirate to the “[ominous octet](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/#:~:text=a%20new%20tab-,The%20ominous%20octet.,-See%20text%20for)”
- In addition to those things that we’ve talked about, let’s add a few more things

**The muscle is insulin resistant**

- Which means that that pathway, that continuum of insulin to IRS-1 to AKT/PI3K/PPARγ, that system is not working
- An aside: one of the drivers of that is intramyocellular lipids
  - Inside a muscle, as fat accumulates that is stagnant (that is not being oxidized), that’s going to impair fat oxidation

**We talked about what’s happening in the pancreas**

- The ꞵ-cell is fatiguing
  - And so we are seeing eventually less insulin coming out

**We talked about the liver becoming resistant to insulin**

- That means that even in the presence of high insulin and high glucose, the liver doesn’t care
  - It keeps pumping out glucose, and it keeps making glucose

**We talked about the fat cell**

- This is interesting, and this is the area where Peter was always confused
- There’s a transition
- Initially, the fat cell is your friend when you have insulin resistance because what it’s doing is protecting you from the excess glucose
  - It’s taking the excess glucose in as stored fatty acid, which is great because it’s not toxic
  - Remember, while we might aesthetically not love the idea of having big, plump fat cells full of fat, it’s very safe
  - That’s the way to store excess energy
- However, over time, that insulin resistance actually leads to something paradoxical, which is increased [lipolysis](https://en.wikipedia.org/wiki/Lipolysis)
  - Lipolysis is when the fat cell begins to release fat, and this fat, which gets broken down into free fatty acids, actually impairs insulin secretion

**⇒** Free fatty acids impairs insulin secretion by the ꞵ-cells, by disrupting the insulin signal transduction pathway

**We also talked about what’s going on with the GI system and the gut hormones**

- People are going to be very familiar with the idea of [GLP-1s](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) and [GIP](https://en.wikipedia.org/wiki/Gastric_inhibitory_polypeptide)

*The GI system is really important, and it has become much more important in the past 5 years as* [*GLP-1 class drugs*](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) *have become very popular*

- These are referred to as [incretins](https://en.wikipedia.org/wiki/Incretin) and the incretin effect
- Discussed in the very first podcast [[episode #184](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/)] Peter did on GLP-1 receptor agonists (4-5 years ago)
  - Talked about the difference in glycemic and insulin response to an oral versus intravenous glucose bolus
  - If you gave somebody 100 grams of oral glucose versus 100 grams of intravenous glucose, you get a totally different response
  - It’s because of GLP-1 and GIP

**⇒** Ralph pointed out something Peter was not aware of: under normal, healthy circumstances, GLP-1 and GIP account for 70% of insulin release

- In other words, 70% of the ꞵ-cell’s response in terms of giving insulin is in response to GLP and GIP
  - Normally, an oral glucose challenge (which is basically anytime you’re getting glucose in your system, since none of us walk around getting intravenous glucose) produces the release of GIP and GLP-1, and they go and tell the pancreas to make some insulin
- And while the mechanism is still unclear, the beta cells begin to become deaf to the sound or signal of GLP-1 and to GIP
- If that signal becomes weaker, you get less insulin coming out
- So it’s a double whammy: at the time when you need more insulin, you’re actually making less

**The α-cells in the pancreas**

- We talked about the ꞵ-cells that make insulin, but now we’re talking about the [α-cells](https://en.wikipedia.org/wiki/Alpha_cell) of the pancreas that make [glucagon](https://en.wikipedia.org/wiki/Glucagon)

**⇒** The α-cells make more glucagon in the presence of insulin resistance, which actually promotes gluconeogenesis and it increases hepatic glucose output

***So it further exacerbates the insulin resistance that we see in the liver normally***

**The kidney**

- We’ve talked about the kidney on previous podcasts [[AMA #49](https://peterattiamd.com/ama49/#:~:text=heart%20rate.%E2%80%9D-,How%20kidney%20health%20and%20function%20typically%20measured%20%5B42%3A30%5D,-Kidney%20function) starting at 42:30], and it’s a pretty amazing in that it’s a tiny organ
  - It’s a couple % of the body weight, but it gets about 20-25% of the cardiac output
  - It’s the most important organ for filtering [the blood]
- What happens is, all the glucose that enters your circulation is going to the kidney
- It gets filtered out of the kidney and then reabsorbed
- We have these transporters called [SGLT2](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_2) and [SGLT1](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_1) that were discovered by Raply and his colleagues, and they’re responsible for most glucose absorption

**⇒** SGLT2 is responsible for 90% of glucose reabsorption (which is about 180 g per day of filtration)

- If you have type 2 diabetes, you would like to see these things go down
  - You would want to see the SGLT2 transporter fail so that you reabsorb less
- But what happens is the exact opposite

***In type 2 diabetes, the SGLT2 transporter is upregulated, and a patient with diabetes paradoxically absorbs even more glucose***

- Everything about this system just doesn’t make sense fundamentally
- It’s like the body initially does the right thing and then completely flips
- Of course, this explains why we have drugs that are highly effective, called SGLT2 inhibitors

**The final organ we introduced to this “ominous octet” is the brain**

- Here our friend GLP-1 revisits because now the individual in the presence of insulin resistance is having **neurotransmitter dysfunction**

**⇒** Insulin resistant individuals are having GLP-1 resistance, amylin resistance, leptin resistance

***All of these things, taken together, mean that the brain is no longer responding to satiety signals***

- That means we eat more than we should
  - We eat even when we don’t metabolically need to eat
- This is a very important point to understand because we can very easily look at an individual who’s overweight and say, “*Why the hell are they eating?*”
  - Well, they’re eating because they’re hungry
  - Even though you may think they have 100 lbs. of fat (that should feed them forever)
  - If they are insulin resistant, the brain doesn’t appreciate the storage form of energy

**When you take all of this together, you start to realize there’s a lot going on here**

Peter adds, “*One of the most important takeaways from this podcast for any clinician is if you have eight organs that are involved in something, you have to be pretty optimistic if you think just one drug is going to be successful.*”

**Peter says this in the context of we’ve tried everything else**

- We’ve tried increasing exercise
- We’ve improved sleep
- We’ve tried non-pharmacologic interventions, caloric restriction
- But the individual is still diabetic or pre-diabetic

**One more point, before getting into the pharmacology side of this**

**⇒** It’s well-understood and well-documented that insulin resistance exacerbates significantly cardiovascular disease

- Peter was unaware of the following point: the Akt/PI3K/PPARγ pathway, that is so critical in insulin resistance, is also critical in the regulation of nitric oxide synthase, which regulates [nitric oxide production](https://en.wikipedia.org/wiki/Nitric_oxide#Biological_functions), which improves vascular health

***One reason that we see a significant increase in cardiovascular mortality with type 2 diabetes (and even frank insulin resistance) is the inhibition of the nitric oxide pathway, which inhibits vasodilation, thereby allowing vasoconstriction to increase the risk of vascular disease***

**Peter’s summary on understanding insulin resistance in these 8 tissues**

- Peter has said a lot here, but this is not a substitute for listening to the podcast
- Maybe there are a lot of people listening to this that are like, “*I don’t care. Just tell me what to do.*”

- You have to go through that to understand why some of the pharmacological stuff makes sense
- Going through that, you realize you’ve got a problem in the muscle where it’s developed insulin resistance because of intramuscular lipid
- You’ve got a pancreas that fatiguing and not listening to the gut
- You’ve got the brain that’s resistant to the gut
- You’ve got the liver that is paradoxically making more glucose than it should be
  - When it should be shutting it off, it’s making it
- You’ve got a kidney that’s reabsorbing more of it [glucose] than it should
- It’s like everything is broken
- If you’re going to tackle that pharmacologically, you’re going to need to combine therapies

> “*You need to tackle the foe by addressing more than one leg of the stool at a time*.”‒ Peter Attia

## Pharmacological treatments for insulin resistance and type 2 diabetes [41:30]

**One of the more important drugs in this discussion is metformin**

**⇒** [Metformin](https://en.wikipedia.org/wiki/Metformin) works by impairing hepatic glucose output, but it does not increase insulin sensitivity

*A very important thing that Peter learned in this podcast*

- In the past, Peter has raised concerns personally about metformin, “*Maybe we shouldn’t be using this except in people with diabetes who are significantly insulin resistant who can’t or won’t exercise*.”
  - Because it mucks around with the mitochondria, impairing the electron transport chain

***Ralph pointed out that metformin can only get into a cell through an organic cation transport that is only found in the liver***

- Ralph sent some papers that showed this [he emailed the slide below]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f2-qps4.png)

**Figure 2. PET studies of labeled metformin show its uptake by the liver and kidneys**. Image credit: 2015 ADA meeting [abstract #128-LB](https://app.core-apps.com/tristar_ada15/abstract/1678f29f2a56ce35baedcc25f394afd9)

- That’s quite interesting because it means that when we see that slight elevation in lactate (both resting and produced lactate) in patients taking metformin, that’s hepatic production of lactate
  - By the way, that might not be a bad thing at all
  - We know lactate is a preferred fuel [discussed in [episode #312](https://peterattiamd.com/georgebrooks/) with George A. Brooks]

Peter explains, “*A big takeaway for me was that these* [*organic cation transporters*](https://en.wikipedia.org/wiki/Organic_cation_transport_protein)*, they’re called OCT-1 (which are found in the liver) and OCT-2 (found in the kidney), means that basically those are the only two cells that are taking in metformin.*”

- Metformin is taken in by the liver, where it exerts its effect on minimizing hepatic glucose output
- And then it’s excreted by the kidney, and that’s the end of it
- Peter has looked through the tracer studies
- Ralph argues that the weight loss that is seen in metformin is mostly due to the GI issues, nausea, and slight reduction in appetite (not due to insulin sensitivity)
  - The average weight loss is about 6 lbs.

**The biggest surprise by far was pioglitazone**

- [Pioglitazone](https://en.wikipedia.org/wiki/Pioglitazone) (brand name Actos) is a drug Peter has never prescribed
  - Because nobody seems to prescribe it anymore
- It is an insulin-sensitizing drug, and it does a whole bunch of good things
- But it does 2 things that nobody seems to like, and for that reason, it has largely fallen out of favor
  - That doesn’t mean there aren’t people listening who take Actos or pioglitazone
  - Instead, it’s no longer considered a 1st-line or 2nd-line or even a 3rd-line drug

*The good things it does*

- It’s a very inexpensive pill
- The first thing it does is lower triglycerides
- It lowers blood pressure
- It lowers [HbA1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin)
- It raises HDL-cholesterol
- It reduces hepatic glucose production
- Generally, these are all good things

*The 2 things people don’t seem to like*

- 1 – People seem to get a little fatter
- Ralph argues that what it’s doing is redistributing fat from the places where you don’t want it (in the liver and in the muscle and around the viscera) to the places you do want it (in the subcutaneous space)
- So we go from being an insulin-resistant phenotype to an insulin-sensitive phenotype
- 2 – The other thing is it causes vasodilation, and if you have a patient who’s on the cusp of [heart failure](https://en.wikipedia.org/wiki/Heart_failure), that’s a really bad thing

***But it might be that the weight gain and the vasodilation are just as much a part of pioglitazone actually fixing the PPARγ mechanism that we talked about***

- Remember, that’s what’s driving nitric oxide synthase
- That’s what’s leading to the production of more nitric oxide
- So it could be that while pioglitazone does all of these good things, the 2 not-so-good things it’s doing are masquerading as bad things, but they’re actually redistributions
  - Meaning, as we see more nitric oxide production, we see more vasodilation
  - That, in the short run, manifests itself as more fluid retention and, obviously, the redistribution of fat

**⇒** What Ralph maintains is that you don’t ever want to use pioglitazone in isolation and that what you want to do is use pioglitazone in combination with at least 1 (if not 2) other drugs that will address its shortcomings

*Some of those other drugs to use with pioglitazone*

- 1 – The [SGLT2 inhibitor](https://en.wikipedia.org/wiki/SGLT2_inhibitor)
- Now that you understand what the kidney is doing, especially in the insulin-resistant patient (or the diabetic patient) where the SGLT2 transporter is actually doing more glucose reabsorption, it clearly makes sense why you would want a drug that inhibits that
- This will get more glucose out and with it more fluid
- 2 – The [GLP-1 agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist)
- We are now on our 4th generation of GLP-1 agonists with [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide)
  - Prior to that, [semaglutide](https://en.wikipedia.org/wiki/Semaglutide)
  - Prior to that, [liraglutide](https://en.wikipedia.org/wiki/Liraglutide)
  - Prior to that, [exenatide](https://en.wikipedia.org/wiki/Exenatide) was the first one
- Peter has no experience with exenatide
- The first GLP-1 agonist he ever prescribed was in 2014, and that was liraglutide
  - It was effective but not that effective, and certainly not for weight loss (which is what he was trying to prescribe it for)

***What Ralph argues is that no patient should ever be on these drugs in isolation and that what you really want to do is be on triple therapy***

**⇒** **Ralph’s go-to first-line triple therapy is metformin, pioglitazone, and exenatide**

- The reason he uses exenatide is that it’s far less expensive, and it also doesn’t have the weight loss effects if an individual is not overweight

*Other options for triple therapy*

- If a person has very favorable insurance, you might instead go with metformin, pioglitazone, and a new GLP-1 agonist
- Or you might go with metformin, pioglitazone
- If the diabetes is quite severe, you would add a SGLT2 inhibitor along with, or plus or minus, a GLP-1 agonist, including a more modern one

**The Qatar Study**

- Because Peter’s mind was being so blown by this, Ralph shared a study called the [Qatar Study](https://pubmed.ncbi.nlm.nih.gov/28096223/)
  - Performed in the country Qatar
- The Qatar Study looked at about 220 people who were very poorly managed type 2 diabetics
- They were on metformin and sulfonylurea , but they were failing therapy
  - [Sulfonylurea](https://en.wikipedia.org/wiki/Sulfonylurea) is a class of drug we also talked about on the podcast
- Their [HbA1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin) was 10% on average
  - 10% is very, very poorly managed type 2 diabetes
  - These are people whose lifespan is dramatically shortened, not to mention their quality of life
  - When you have a HbA1c of 10, you’re going to be going blind
    - You’re going to be getting amputations
    - You can’t have erections
    - Everything is broken in your body
- These patients who were on metformin and sulfonylurea but clearly not responding to therapy were randomized to either a **combination therapy of just pioglitazone and exenatide**
  - Not even staying on the metformin or intensive insulin therapy
- You may think that both metformin and intensive insulin therapy should lower your glucose, but only the former is addressing the problem

**How each drug acts to address a problem with insulin resistance and type 2 diabetes**

- Pioglitazone is attacking the insulin resistance
- Exenatide is amplifying GLP-1 to overcome the GLP resistance
- Insulin therapy isnot going to fix any of that
  - It’s just going to hammer more insulin into the system

**Results from the Qatar study of combination therapy**

- The combination therapy group at 1 year ended up with a HbA1c of 6.1% ± 0.1%
- Whereas the intensive insulin therapy group was still actually diabetic at 1 year at 7.1%
  - There’s many reasons for that
  - When you’re using a hammer-like insulin, you also have to be wary about hypoglycemia
  - It certainly would’ve been possible for those patients to have had a lower glucose level (a lower HbA1c level), but you would’ve compromised their safety in other ways

**⇒** All of this is to say that if those studies are run long enough, the group receiving combination therapy is also going to see a reduction in their risk of diabetic comorbidities, whereas the intensive insulin therapy group will not

- We know this from study after study that when you use intensive insulin therapy, you correct the microvascular deficits (i.e., the deficits that accrue to high levels of glucose), but you do not correct the macrovascular deficits
  - ***You do not reduce the risk of cerebrovascular disease and the risk of coronary artery disease***

**Peter’s final thoughts about the episode with Ralph DeFronzo**

- Even before this podcast came out, he sent the unedited recording of it to his entire clinical team and said, “*Listen, guys, maybe we’re taking a little too long to move to pharmacotherapy for recalcitrant insulin resistance.*”

*Mainstays of therapy for managing hyperinsulinemia, insulin resistance, and even type 2 diabetes*

**⇒** Even though we didn’t discuss it on the podcast, Peter still believes that the primary mainstays of therapy should be ***exercise, caloric restriction, and sleep***

- He no longer feels it is ethical to sit around and wait 1-2 years for a patient to get better when we have ***a suite of drugs*** that can be used to augment what they’re trying to do from a lifestyle perspective

## The importance of early detection and intervention in insulin resistance [50:30]

**Follow-up question: opinion on using metformin in non-insulin resistant folks for geroprotection**

*You talked about muscle, and updated thoughts [on metformin not getting into muscle]*

- It doesn’t really change his thought on that
- If anything, this information makes it harder for Peter to imagine that metformin is geroprotective (it’s still TBD)
- If metformin is geroprotective, wouldn’t that imply it needs to be able to get into all sorts of other cells as well?
- Or do we believe that all of its geroprotector is coming through its impact on the liver? (that’s possible)

***Peter doesn’t think we have enough information either way to say that***

**Follow-up on the importance of not letting yourself become insulin resistant**

- Not only is there complexity with how you treat it
- You can see how many things being insulin resistant affects
- You should be even more aggressive in making sure you don’t get to an insulin-resistant state because of how many negative consequences there are
  - Even though if you would have asked Peter 6 months ago, he would’ve told you he’s already a 10 out of 10 in terms of how aggressive he is on this

*Peter was talking to a patient this morning*

- He’s in his mid-30s (young and healthy) and he ostensibly looks amazing, but his HbA1c was 5.8% on his last blood draw
  - And it’s always been a little bit elevated, but, HbA1c is often falsely elevated
- They did a CGM on him, and Peter didn’t like the results
  - His average blood glucose over the 10 days was 115 mg/dL
  - This is actually congruent with the HbA1c of 5.8%
- That puts him in the category of pre-diabetic, and even though his fasting glucose was 90 and his fasting insulin was 6 (which are both great numbers)

***It’s clear that, postprandially, he’s having issues***

- Again, that’s being captured in the A1C and in the CGM
- Most people wouldn’t even dream of getting worked up about this, but we talked about it today, and Peter said, “*Look, let’s do another CGM tracing in a couple of weeks, and if things continue to be this way, I want to get even more aggressive on what we’re doing with you from an exercise-nutrition standpoint*.”
- And although Peter didn’t bring up pharmacology today, he thinks we’re still one step removed from that

**⇒** The bottom line is Peter is not going to let that guy walk around with an average glucose of 115 because pretty soon he will start to develop postprandial and fasting hyperinsulinemia, and then he’s on a devastating cascade

- This guy is only 30 or 35, so you have to play the long game here ‒ not letting someone get to that point

## Saum Sutaria episode: the economic and systemic drivers of high healthcare costs in the U.S. [54:00]

[#327 – Choices, costs, and challenges in US healthcare: insurance intricacies, drug pricing, economic impacts, and potential reforms | Saum Sutaria, M.D.](https://peterattiamd.com/saumsutaria/) (December 2, 2024)

\*\*\*

- The episode with Saum on the US healthcare system was insanely technical, insanely interesting
- Clearly a lot of eyes are on it right now, to say the least
- Peter has known Saum for a long time and has been interested in this topic for a long time
  - Saum is not only an incredibly close friend, but also among the most important mentors Peter has ever had
- Saum is a physician, trained as a cardiologist, but left medicine to join [McKinsey](https://www.mckinsey.com/) 25, 26 years ago
- He was the guy that recruited Peter when he left medicine to come to McKinsey
  - That’s where Saum was running McKinsey’s North American healthcare practice, at the time
- Even though Peter spent most of his time at McKinsey working in financial services, he did spend about a quarter of his time in healthcare and all of it was with Saum and it was working in the healthcare system
- Even after Peter left the firm, he and Saum have remained very close
- Saum’s career has been remarkable
- Peter and Saum always talk about this stuff
- Saum is the CEO of Tenet, which is the second largest hospital system in the United States
- Peter said to him, “*Look, I realize it’s hard for CEOs of public companies to do podcasts*.” But he agreed to do it

**⇒** This episode was just his views, not the company’s views

**Why we pay 2x per capita of what every other country pays for healthcare and we can’t deliver even top-20 life expectancy**

- This podcast did a deep dive into this, and Peter is not going to be able to summarize it all here
- If you find this topic even remotely interesting, just pick up your phone and go to this episode and listen to it

**Peter’s main takeaways**

*It’s important to just have some scale on all of these things*

- The US federal budget each year is about $5 trillion
- We typically overspend that by about $2 trillion, which is what a deficit means
- So the US budget ends up being actually closer to about $7 trillion per year (that’s what the US government spends every year)
  - And obviously that $2 trillion of excess is being added to a pile of debt that now sits at about $35 trillion
- Our GDP (gross domestic product) is probably in the neighborhood of about $28-30 trillion at this time
- Total US health care spending: right now we’re sitting at $4-4.5 trillion a year
  - It varies a little bit from year to year, and we saw a bit of an uptick in COVID

**Breakdown of the $4+ trillion/year of US healthcare spending**

- About $1 trillion of that is insurance premiums and out of pocket spending by consumers
- About another $1 trillion of that is the employer’s spending to insure their employees
- About $2+ trillion of that is the government spending through something called [CMS (the Center for Medicaid and Medicare Services)](https://en.wikipedia.org/wiki/Centers_for_Medicare_%26_Medicaid_Services)
  - This is both state and federal spending

**Where does that money go?**

- 15% off the top (of $4.5 trillion) goes to administration
  - Payment adjudication and reconciliation is a very big deal
  - This is very unique to the US because we are the only country that doesn’t have a single payer system (like the UK, Canada, Australia, or most of Europe)
  - The movement of money in our system is something that doesn’t exist in any other system, and that costs an enormous administrative burden

*The easiest way to think of the remaining 85% is to actually just break it into thirds*

- ⅓ of the remainder is drugs and medical devices
  - Much more of that cost comes from drugs than medical devices (we’re going to come back to that)
- ⅓ is capital investment in hospital facilities and infrastructure (the actual buildings)
- ⅓ is the medical office, clinic
  - We’re really mostly talking about the wages

***The easiest way to think about it is we’ve got the administrative spending about moving money, wages are very high in the US, and we have a lot of infrastructure***

- As an aside, we talked about the [Hill-Burton Act of 1946](https://en.wikipedia.org/wiki/Hill%E2%80%93Burton_Act), which was really an act that wanted to ensure that Americans didn’t have to travel very far to get medical care

**⇒** This is a bit of a death by 1,000 cuts problem

- When you live in a country as big as the United States, it’s very different than if you’re creating healthcare policy in the UK where people are on top of each other
- The US has a huge rural population relative to other places potentially and at a greater distance from major cities, you just have to incur much more of a capital base and infrastructure
- Drugs and drug prices: it’s no secret that we pay more for drugs than anybody else

***Healthcare is about 18% of GDP ‒ that’s staggering, both in absolute dollars, nobody’s within the same zip code***

- Keep in mind, we were 5% of GDP in 1960, 6% of GDP in 1970, and we’re 18% of GDP today
- In **absolute dollars**: in 1970, it was $74 billion
- In the year 2000 (this is 24 years ago), it was $1.4 trillion
- Today it’s $4.5 trillion

> “*The thing that should give anybody chest pain if they’re listening to this is the rate of healthcare inflation is exceeding the real rate of GDP inflation and the nominal rate of GDP inflation. This is very concerning.*”‒ Peter Attia

**If someone wanted to reduce healthcare spending by $3-4 trillion dollars in the next 5 years, how would they do it?**

- Saum took a framework that Peter has talked about before, but added something to it that makes it better

⇒ American consumerism demands and it expects choice, speed, quality as the things that matter; it’s not optimizing for cost

- The reason for it is (like most healthcare systems) we don’t bear the cost
- Individuals only make up 15% of the total healthcare costs
  - Out of our pockets we pay very little
- In the 1950s, Americans paid 50% of healthcare out of pocket, but the total dollars were so much smaller on a relative basis to their budget

***If we demand choice and speed and quality and we’re not optimizing for cost, we’re never going to lower that***

*The question is, do we really want to go from $4 trillion to $3 trillion in spending? And if so, what would we give up?*

- Would we give up choice? Speed? Quality?
- If you need an MRI, do you want to be able to get it within the week or do you want to wait 6 months like your neighbors to the north and our European neighbors might have to wait?
  - Because if you want to get it in a week, you need more MRI machines than if you’re willing to wait 6 months
  - You’re going to need more radiologists, more technicians
- You have to think through this

⇒ Most other countries throttle supply on healthcare

**How other countries spend a fraction of what we spend on healthcare**

- Basically by limiting the number of facilities and machines and the infrastructure
- Coupled with having the power to negotiate drug prices
- Coupled with having a single payer system that doesn’t have any administrative friction of cost
- Coupled with not dealing with [PBMs](https://en.wikipedia.org/wiki/Pharmacy_benefit_management) (we’ll come back to this)

***But you have to give something up; and the question is, how much of that are we willing to give up?***

> “*The good news is I actually don’t think we have to give up a whole heck of a lot, and I think we could actually reduce the cost of healthcare significantly*.”‒ Peter Attia

**How we could significantly reduce the cost of healthcare**

- He doesn’t know that we could get it down to $3 trillion
- But we could absolutely get healthcare cost to grow at a much slower rate than GDP is growing

*Go back to the 3 buckets [that constitute ⅓ of spending after administrative costs]*

- 1 – The hardest bucket to constrain is **wages** because that’s where you really do need to keep up with inflation
  - We’re just not going to ask people to all of a sudden overnight start working for less money
  - Doctors, nurses, technicians, their standard of living shouldn’t go down in an effort to cap the cost of healthcare
- That is going to be the bucket where cost is going to continue to grow at what it’s growing

**⇒** That bucket can start to come down and we use AI do more of the jobs (AI efficiency)

- But on a per individual basis, we’re not going to see cost cutting there
- 2 – On the **infrastructure** side, there is an opportunity to reduce cost by basically reducing the capital footprint of marginal assets
- This is not a huge opportunity because if you cut down too much of the infrastructure, you start to lose choice and speed
- Americans have, for right or wrong (Peter included) decided we don’t want that
  - If you need an MRI, you want to be able to get it in a day or two; you don’t want to wait 6 months like Peter’s family does up in Canada
  - That’s the trade-off that we have to think about
- 3 – On the **drug pricing** side, there’s an enormous opportunity

2 things would need to be true and there’s no reason either of these need not be true

- 1 – The United States government (to begin with) and ultimately private payers need to be able to negotiate reasonably with pharma companies
  - Peter’s not going to get into the history and the politics of why that’s not the case, but that’s a fixable problem and that’s a very bipartisan issue

**⇒** As it stands today, the United States is truly subsidizing the rest of the world from a pharma pricing standpoint

- We develop all these drugs and everybody gets them for cheap and we don’t
- 2 – The [PBMs (pharmacy benefit management entities)](https://en.wikipedia.org/wiki/Pharmacy_benefit_management) need to go away
- They’re opaque
  - Peter will probably end up doing a dedicated podcast on this because he really wants to make sure every single listener to this podcast understands how perverse the incentive structures are around PBMs and how value destructive they are
- They operate in the shadows of healthcare, most people are completely unaware of what they are, and as a result are completely unaware of how destructive they are

***If we could simply get rid of PBMs and basically allow AI to help benefits managers within companies do the work themselves, we can get rid of that shell game***

**US life expectancy is horrible relative to other developed nations**

- Which is that much more upsetting in light of how much we spend
- Saum made an interesting point, which is it’s mostly because of how much life expectancy is dragged down for people below 60

**⇒** Where the US is really failing is that our mortality for people under 60 is really bad

- It’s largely due to prenatal care
- It’s largely due to higher infant mortality.
- It’s largely due to higher drug use and substance abuse
- Higher injuries and homicides
- Most of those things end up killing people below the age of 60, and that’s a huge drag down on life expectancy

**If you look at people between the ages of 60-75, it actually flips and we actually end up having a very high life expectancy**

- Once you make it out of those other causes of death

**⇒** Between the ages of 60-75 is probably where our medical system thrives

- It’s like eking out incremental life via medicine 2.0 once the low-hanging fruit of some of these other public health measures are not addressed
- Peter could talk about this stuff forever, but it’s just better to go back and listen to the podcast

## Reducing health care costs: redefining health insurance, lowering drug prices while maintaining innovation, leveraging AI for efficiency, and more [1:07:15]

**Health insurance isn’t necessarily insurance**

*It’s almost like a discount card*

- This is an interesting way to think about it that’s not necessarily always talked about
- Of all the things that you have insurance for ‒ you buy insurance for unexpected things
  - You have umbrella insurance, car insurance, property insurance, life insurance
  - You don’t buy car insurance to take care of our oil change
  - We buy car insurance so that if we get into an accident, someone pays the catastrophic cost
- That’s not actually what health insurance is at all

**⇒** Health insurance is a discount card: it’s basically a tool that allows group purchasing power for services that are to be expected

- There’s all sorts of people, policymakers and non, are thinking about ways to sort of rethink the model of healthcare delivery

**Another obvious point Peter failed to mention: if people were healthier, healthcare costs would be lower**

- Americans are not very healthy
- Not just mortality, but talk about morbidity
  - Americans have more obesity, more type 2 diabetes, and more of these things means higher costs as well

**Where the US could improve**

- What would it take to be healthier?
- What would it take to have AI reduce all the administrative friction in payment?
- What would it take to have AI improve efficiency in the workforce?
- What would it take to legally be permitted to negotiate with pharma companies and to eliminate the PBMs?

***You add all that up, and there’s a world in which we only have to spend 12% of GDP on healthcare***

- And that’s still at the upper end of what a developed nation spends, but that’s infinitely more sustainable than the path we’re on now

**If we used price controls to lower the cost of drugs, how would that affect innovation?**

- Peter doesn’t think that more competitive drug pricing in the United States to mirror the rest of the world should hamper innovation
- There are always going to be innovative people
- There are always going to be innovative small companies that are always going to be pushing the envelope of what can be done
- Yes, AI is already making an impact at part of that
  - It’s certainly making an impact around on the molecular side of drug discovery [discussed in [episode #33 with Mike Israetel, Ph.D.](https://peterattiamd.com/mikeisraetel/)]
- Peter thinks this is a narrative thrown out by people whose interest is in preserving a certain economic structure
  - But he doesn’t see any evidence to it
- Most innovation these days is done by smaller companies that are taking the risk, and that’s venture backed

***Peter would be willing to take the bet that this will not stifle innovation***

- He thinks innovation is only accelerating, not slowing down

**Do you think money spent by pharmaceutical companies on advertising has anything to do with lowering healthcare costs?**

- Peter doesn’t know how much of that would factor into healthcare costs

**⇒** He absolutely thinks pharmaceutical advertising should be abolished

- He sees no reason for it whatsoever
- He thinks it’s manipulative
- Advertising in general should be scrutinized a little harder

***Peter would certainly agree with the idea that we just don’t need to be advertising drugs to either patients or doctors***

- We should allow people to do their own research and certainly not be told to go and ask your doctor about this and that and the other thing (he finds that to be distasteful)

## Trenna Sutcliffe episode: insights on autism, ADHD, and anxiety in children—definitions and diagnosis [1:11:45]

[#330 – Autism, ADHD, and Anxiety: Understanding the rise in autism and a multidisciplinary approach to diagnosis and treatment of each condition in children | Trenna Sutcliffe, M.D.](https://peterattiamd.com/trennasutcliffe/) (January 6, 2024)

\*\*\*

- Peter really enjoyed his discussion with Trenna
- He wasn’t very familiar with what she refers to as **a biopsychosocial model for treatment** of children and adolescents
  - It makes a lot of sense

**⇒** Which is you want to be able to completely integrate the biological component, the mental health component, and the social component of a condition

- And it’s that social component that bridges between mental health and education, which for kids is such an important thing

**She’s largely talked about 3 things: autism, ADHD, and anxiety**

- But she always starts from a question of: is the trait a set of traits that manifest with the diagnosis of autism?
  - A set of traits that manifest through ADHD?
    - ADHD is a term that just gets thrown around nonstop, everyone’s got ADHD today and anxiety
  - With anxiety?

**⇒** She’s not interested in the label, she’s interested in the impairment

- This is very helpful, especially for parents thinking, “*Hey, if I’m told that my kid has ADHD, should I be worried?*”

**Look how a trait/ diagnosis is impacting 3 things**

- 1 – How does it impact your child socially?
- 2 – How does it impact your child’s ability to communicate with other children, with adults?
- 3 – How does it impact your child’s ability to learn?

***And if the answer is, “None of the above,” then it’s very difficult to call it a disorder***

*She digs in a little bit deeper*

- Are these traits impacting the interaction of the child with their peers?
- Their ability to learn at school?
- And even their own sense of self-esteem?

**The system and the DSM-5**

- There was a change in the DSM-5 that took place about 10 years ago regarding autism spectrum disorder (now called ASD) ‒ this is a very broad spectrum that includes many things that were not included before

*In the DMS-4, you had 3 diagnoses*

- 1 – Autism was a disorder of social deficits, stereotyped or repetitive behaviors, restricted interests, and significant communication challenges that included but were not necessarily limited to non-verbal behavior
- 2 – You had something that was called pervasive developmental disorder not otherwise specified (or PDD-NOS)
  - And it usually meant that a kid didn’t fit the threshold for autism or Asperger’s
- 3 – Asperger’s, which is no longer a term that is used, now someone that would’ve fit the diagnosis of Asperger’s is somewhere on the ASD spectrum
  - Formerly, we specifically called out Asperger’s as a high-functioning form of autism that had autism-like symptoms, but normal language and normal or high IQ
- These are kind of messy buckets
  - Because you have Asperger’s, which is today what we think of as high-functioning autism
  - You have autism, which was quite severe
  - And then you have this PDD-NOS, which is just another way of saying something’s wrong, but it’s not otherwise specified, so we don’t know what to call it

*Right out of the gate the DSM-5 consolidated all 3 of these into 1 diagnosis called ASD (or Autism spectrum disorder)*

- They were divided into 3 levels based on the increasing severity
- Kids at **level one** have a lot of skills, and many of the formerly Asperger’s children would be in level one
  - A lot of times these kids are not diagnosed
  - If they are, they’re not necessarily supported

*The definition today is a lot broader, but in particular it’s broader in 3 areas*

- 1 – It pays more attention to social reciprocity
- 2 – It pays more attention to nonverbal communication skills, eye contact gestures
- 3 – It pays more attention to how children understand relationships

**When people talk about the increase in the prevalence of autism, a part of that is due to a change in the diagnosis**

- Does that explain all of it? It certainly does not (and we talked about that)
- But when you change the diagnostic criteria from autism (being a relatively narrow diagnosis) to now ASD (including a whole bunch of other things that weren’t there), you’re going to see it go up

## Exploring the rising prevalence of autism spectrum disorder [1:17:15]

**What is the heritability of ASD?**

- This also came up on 2 previous podcasts [episodes [#191](https://peterattiamd.com/karldeisseroth/) & [#268](https://peterattiamd.com/wendychung/#:~:text=major%20major%2C%20driver-,The%20genetics%20of%20autism%20%5B1%3A48%3A45%5D,-Autism%20is%20in)]
- [Heritability](https://en.wikipedia.org/wiki/Heritability) is a term that refers to how genetically encoded is it?
- The way that heritability studies are done is by looking at identical twins that are raised separately
  - It’s the closest we have to an experiment that can tell us: how do genes more than environment impact outcome?
  - If you have identical twins that are raised in separate environments, that’s the best way we can understand the heritability of various conditions
- For example, we understand the heritability of depression, the heritability of schizophrenia, the heritability of major depressive disorder, bipolar disorder, things of that nature

**⇒** Depending on this study you look at, the heritability of ASD is anywhere from 70% to the mid to high 90s

> “*Here’s the kicker, it involves multiple genes. There is no autism gene. In fact, there is no commonly identified set of genes.*”‒ Peter Attia

***There are simply many genes and what appears necessary is a confluence of factors***

- In biology this is often referred to as a hit model
- So is it a two-hit model?
  - A lot of hereditary cancers end up being two-hit models
  - You have this gene that already predisposes you, and then you get one perturbation to the system and you get the cancer
- Scientists don’t think that that’s what’s going on with autism
- They think it’s a multiple hit gene and the timing of those hits matters

**What explains the increase in the incidence of autism beyond the diagnostic criteria change and the awareness of it and the increased screening for it?**

**⇒** Trenna cited the following: maternal stress, maternal diet, paternal age, and pollution

- She believes that those 4 things in addition to the diagnostic changes, coupled with the increased awareness and the increased looking, are playing the biggest role
- One of the things that was not here was vaccines
  - We’ve covered this in great detail on previous podcasts [episodes [#158](https://peterattiamd.com/briandeer/), [#159](https://peterattiamd.com/peterhotez3/), and [#317](https://peterattiamd.com/martymakary3/)] and it’s important to understand that

*When it comes to understanding the increase in autism, it seems there are 2 very polarizing views*

- One view is, it’s caused by vaccines
- The other view is, this is all in your imagination
- Peter finds that very problematic
- Because while he completely agrees that vaccines are not driving autism that doesn’t mean **something else in the environment** isn’t triggering it
  - Back to vaccines ‒ just on first principles it doesn’t even make sense when you look at the data, when you understand that autism develops long before children even get vaccines
  - There’s so much evidence for why vaccines are not causing autism
- Peter has no idea what in the environment may be triggering the increase in autism
- He doesn’t think he’s qualified enough to suggest what role maternal stress, diet, paternal age, pollution, or any other environmental trigger plays

Peter explains, “*The only reason I can comment so emphatically on the vaccine one is I’ve gone down that rabbit hole, and I’ve gone very deep down that rabbit hole, and I feel very comfortable asserting that. But it does bother me when the view is one or the other. It’s either vaccines or it’s nothing, and you’re just crazy to suggest that there’s an environmental thing going on here.*”

## Trenna’s views on caring for children with autism [1:21:15]

- She’s taken care of countless children like this

She said, “*If you’ve met one child with autism, you’ve met one child with autism.*”

**⇒** All the care for kids with autism needs to be very tailored to them and their family’s needs

- Diagnosis is important, but primarily what we want to do is get to treatment options
- She wants to give tools to help the adults around the children
- She wants to give structure for how to leverage a kid’s strengths and weaknesses
- So we often hear parents of kids with autism their kid’s certain superpowers but they also their kryptonite
- It’s very important to figure out how to manage that both at home and at school

**The 3 A’s: ADS, ADHD, and anxiety**

*They involve different parts of the brain*

- ASD is in the frontal lobes, the amygdala, the cerebellum, and the temporal lobes
- ADHD is mostly prefrontal cortex with executive function and the frontal lobes
- Anxiety is mostly in the amygdala

**⇒** The interesting and confounding and sometimes unfortunate thing is that ASD also has a high overlap with ADHD

- It’s about a 40-70% overlap
- And 40% of those kids on average have anxiety
- So many have all three

***This makes the diagnosis challenging, makes the treatment challenging***

**ADHD is also often accompanied by anxiety and it’s often accompanied by oppositional defiant disorder**

*Any parent listening can relate to a kid that sometimes comes across as quite oppositional defiant*

**⇒** Trenna asked an interesting question, a question Peter has been doing with his kids: **When kids are being oppositional, what is the function it is serving?**

- Is it sensory overload?
- Are they anxious about something?
- Are they impulsive?
- Are they embarrassed?
- What’s going on?

**Anxiety has many types**

- We talked briefly through these things

**We talked also about the age at which kids can be diagnosed**

- Peter was surprised that the typical age for autism is 3-4, but she said if a person really knows what they’re looking for, 18 months would be when you would typically diagnose it
- Amazingly, she said half of kids with autism are not diagnosed until they’re over 6 years of age
  - That’s a little bit sad to hear, because that means that those kids have already entered school at the time of diagnosis, which means they didn’t get off to the right start necessarily
- ADHD can be diagnosed at age 4-5 but 5-6 is more typical
- Anxiety could be diagnosed at any point in time

**We talked about medications around this**

- This is an area where Peter just has no insight
- He still finds it amazing that stimulants and amphetamines are the drug of choice here

***Peter has studied this quite a bit and come to the conclusion that if the symptoms warrant it, and if your alternative is a child who’s not able to learn and not able to maintain relationships, then these drugs can be miracle drugs***

- Even though it seems counterintuitive and there’s clearly a cultural zeitgeist that suggests that parents shouldn’t be giving their children these drugs, Peter thinks that type of shaming is ridiculous
- He can’t tell you the number of parents he knows whose kids have done so well, have experienced a complete 180, when they’ve been put on these various drugs

**Types of medications used to treat ADHD**

- 1 – The [methylphenidate](https://en.wikipedia.org/wiki/Methylphenidate) drugs: Ritalin, [Focalin](https://en.wikipedia.org/wiki/Dexmethylphenidate)
- 2 – The [amphetamine](https://en.wikipedia.org/wiki/Amphetamine) drugs: [Adderall](https://en.wikipedia.org/wiki/Adderall), [Vyvanse](https://en.wikipedia.org/wiki/Lisdexamfetamine)

> “*One of the things I took away from my discussion with her is, if your child looks like they’re going to benefit from pharmacology and you go down that route, don’t stick with the first drug that you try if you’re not happy with the outcome. There are so many different ways to do this.*”‒ Peter Attia

- Just because a child is put on one of these drugs doesn’t mean that they’re going to be on that drug for life
- Nor does it mean that they should tough it through that drug
- 3 – There’s also non-stimulants: [Stratera](https://en.wikipedia.org/wiki/Atomoxetine) increases norepinephrine level in the synapses

**ASD really has no treatment**

- The only treatment pharmacologically would be for any of the symptoms that come up that are typically with ADHD or emotional regulation or anxiety

**What do you look for in a provider?**

- Trenna said you want people who are very personalized in their care
- People who are skilled in treating the parents and not just educating them (this is very important)
  - It’s actually teaching them how to be better parents
  - And then they’re very proactive as opposed to just open to helping the parent create a collaborative team between the school and the home

## Misconceptions around vaccines and autism [1:26:00]

**Do you think understanding where the increase in autism prevalence is coming from is an easily answerable question, or is that always going to be an area that causes confusion?**

- Peter thinks it is easy to answer if people could be honest
- It’s very difficult to answer if there’s a constant shifting of goalposts
- People can go back and listen to the [Brian Deer](https://briandeer.com/about-us.htm) podcast [[episode #158](https://peterattiamd.com/briandeer/)] where we go through the entire history of the controversy around MMR and autism
  - Peter can’t tell you how many people he’s talked with who have said MMR vaccines cause autism, and he’s gone through that entire argument with them, which is, you can’t run from it
  - And instead they come up with a new argument altogether the moment you’re done spending an hour talking through that
  - And they’re like, “*Well, it’s got to be this thing… But what about this vaccine and what about this vaccine?*”
- Peter wants to be clear, he’s not saying it makes sense to give children every vaccine according to every schedule
  - He doesn’t want to get into it
  - It’s not his area of expertise
  - On a personal level, he did not choose to give his kids the Hep B vaccine 10 minutes after they were born or whatever was recommended
    - Let’s give the things that seem like they make sense, and things that don’t make sense today, let’s postpone them for a year or two or whatever it is
- He thinks there’s a middle ground where it’s very hard to exist because you feel attacked from both sides

Peter adds, “*I really do pity the parents who are not armed with this information and are being misled by people who are suggesting that if their kids get the MMR vaccine or the polio vaccine, they’re increasing the risk of autism.*”

***This is categorically untrue***

- It’s as demonstrated through the literature as virtually anything can be based on the complete and total abundance of negative epidemiologic data demonstrating any causality
- So when we start to talk about MMR and polio and things like that, Peter gets particularly distressed

## Mike Israetel episode: insights about strength training, minimum effective dose, troubleshooting plateaus, tips for beginners, and more [1:28:15]

[#335 ‒ The science of resistance training, building muscle, and anabolic steroid use in bodybuilding | Mike Israetel, Ph.D.](https://peterattiamd.com/mikeisraetel/) (February 9, 2025)

\*\*\*

- Really interesting episode about resistance training
- Early on in the discussion, we started talking about the differences in intensity

**Why is it that we can do lower intensity training (like cardio training) much more than we can do resistance training?**

- Basically he pointed out the obvious, which is that it’s really a difference in the metabolism of the muscle fiber
  - When you’re doing cardio training, you’re mostly using type I muscle fibers
  - When you’re doing resistance training, you’re mostly using type II muscle fibers, which are much more forceful
- The oxidative stress of training type II fibers is much higher, and there’s a very nonlinear exponential increase in damage that occurs using muscle fibers under higher forces

***All of those things say that to adapt type II fibers requires much less volume in total than to adapt a type I fiber***

- We talked a lot about the relationship between **neural fatigue** also being more of an issue when you’re lifting something really heavy versus even doing a VO2 max type workout where you can actually tolerate much more volume because you’re still primarily using an oxidative system

**Mike is probably one of the most transparent people about his use of anabolic steroids**

Peter adds, “*It’s probably funny to watch my face during some of this episode, because again, it’s not that I haven’t heard of people taking such high doses before, but somehow Mike sitting there articulating it seemed that much more amusing to me.*”

- Mike talked at length about his use of testosterone and other anabolic agents that are similar
- His uses are quite significant
- He said his maintenance low dose is in the 250-500 mg of testosterone per week
  - Though at times he cycles to 2,000 mg/week
- To put that in perspective, a typical medical replacement dose would be about 100-120 mg/week
  - Maybe 140 mg/week ‒ that would be a lot
- So if his maintenance dose is 2-4x that, and at times going up to 2,000 is pretty remarkable

**2 remarkable things about strength training**

- 1 – What’s the minimum effective dose workout?
- 2 – If I’m in the gym and I’m training and part of my motivation is hypertrophy and it’s not happening, can you give me a sense of why?

*For #1: Mike said that you could achieve 70-80% of your maximum potential if you did only 30 minutes twice a week*

- Spaced out by 3 days
  - If you did a Monday, Thursday or Tuesday, Friday or something like that

**⇒** But this is only true if you’re willing to do a very, very intense and exhaustive workout

- To be clear, most people (Peter includes himself) could not do that for very long
- So this doesn’t apply to Peter and it doesn’t apply to most people, but it’s just interesting to note

What would that workout look like?

- This workout would be a whole day body split twice
  - Meaning you do the whole day body split on Tuesday, then on Friday
- There are no breaks in the workout
  - You just do opposing muscles back and forth, back and forth
  - You’re basically just doing compound movements: rows, pull-ups, pull-downs, squats, deadlifts

***You’ll train much harder than you think is reasonable and be really exhausted if you do this***

- This type of a workout has its pluses and minuses
  - You could say, “*Well, great, hey, I only need to work out an hour a day*.”
  - But the focus and attention that you need to bring to that workout is really hard
- Peter prefers to work out more frequently, spend more time, and not have to work out that hard (sounds a little soft)
  - For example, he works out 3x a week
  - He does each body part once a week
  - Each of those workouts ends up being about 90 minutes

*For #2: I’m crushing it in the gym, but I’m not making any gains. What’s going on?*

- Mike used a nice framework which was there’s going to be “in the gym” reasons and “out of the gym” reasons

“In the gym” reasons include

- 1 – Exercise selection ‒ for example, if you want to grow your arms and you’re not doing a lot of triceps (they are more than ½ the upper arm)
- 2 – Technique ‒ if you’re trying to grow your pecs, but nothing you do is ever putting the pec under a deep stretch, you’re never going to fully appreciate the force at the open end of the range of the muscle
- 3 – Volume ‒ Mike argued that you need to do a minimum of 10 working sets per week
  - That doesn’t include your warmups
  - Per week per muscle
  - If you’re below that, you’re probably going to have a hard time achieving hypertrophy
- 4 – Intensity ‒ you should not be at an intensity less than 2 reps in reserve
  - This has been echoed by many other guests on this podcast: Lane Norton, Andy Galpin
  - That means if you put the bar back and you could have done 3 or 4 reps, so that’s 3 or 4 reps in reserve (you didn’t go hard enough)
- 5 – A lack of consistency ‒ so even if you’re doing everything right but you can’t do it consistently, it’s going to be very difficult to make gains

“Out of the gym” reasons include

- 1 – Rest ‒ it’s not just sufficient to rest between training days
  - If you can’t train the same muscle 3x a week, it’s just not going to be sufficient
  - So it’s the inter-week rest, but then it’s also, he figures about every 8 weeks you need a deload week where you really reduce your intensity
  - And then maybe 1-2 weeks a year where you’re completely off
- 2 – Genetics ‒ which are not only out of the gym, but non-modifiable, plays a significant role here
- 3 – Age ‒ the older you are, all things equal, the harder it is to achieve hypertrophy
  - This could be due to fewer type II muscle fibers, less capacity to recover, more stress, more inflammation
- 4 – Nutrition ‒ are you getting enough calories and enough protein?
- 5 – Lack of consistency ‒ you can be doing most of these things right most of the time, and that might not be efficient or sufficient

**How does someone truly know what their reps in reserve are?**

- You mentioned, if you stop and you really had 3-4 in the bank, do you really have to go to failure to understand what that is?
- And then how often do you reset what your reps in reserve are?
  - Do you go to failure, and then maybe a few times a year you do the same to see if you’ve made improvements?

> “*Everybody needs to know what it feels like to go to failure, and everybody therefore needs to get familiar with what does it feel like when I was one rep before that.*”‒ Peter Attia

- And what it feels like when I was 2 reps before that, 3 reps before that
- Peter’s 1 rep in reserve will vary quite a bit from week to week
- Yesterday was a chest, tricep day, shoulder day and Peter shares, “*Man, for reasons I don’t know, I was doing 1-2 fewer reps for all of my presses yesterday. Swiss bar, dumbbell, incline, everything I did yesterday was just a little bit lower. But I didn’t have to go to failure to know that because I’m very familiar just through having done it so many times what it feels like when I’m about 1 rep away from failure.*”

*Everybody needs to get familiar with failing*

- Obviously don’t pick an exercise that’s dangerous
- You don’t want to figure it out on a squat or a barbell bench press

***Get comfortable doing it either when you have spotters or when you can do it on an exercise where the consequences are not dire***

- You will quickly start to understand, when you’re on that second rep before failure, you will have the sense that you could do 1-2 more, and that’s about it

*If someone’s new to exercise, is it worth them even knowing what that reps in reserve is? Or is that something where they need to just build up some muscle first?*

- It just depends on where you’re starting from
- Because if you’re truly starting from a place of knowing nothing, having never done resistance training, it probably doesn’t matter
  - It’s okay if you’re at 3-4 reps in reserve
  - If you’re just doing a program that’s set up as 3 sets of 12 or 3 sets of 15, it’s not worth worrying about this, because you’re going to make amazing gains because you’re starting so far on the curve

***Peter wouldn’t have people stressing about this if they’re completely new to resistance training***

*Is there at any point, at a certain age you worry about also doing this? Is there potential harm if you hit failure?*

- Obviously it’s different if you have a spotter
- Peter still has his older patients think about reps in reserve
- It’s another way to be very deliberate when you’re training, and frankly, that’s more important as you get older
  - Because we still have to try to do all we can to hold onto and preserve the type II muscle fibers
- There’s lots of safe ways to do that
  - They don’t have to be methods that put you at extreme risk

**A lot of people understand that exercise is important, but time is a huge factor and hearing Mike say, “*****Hey, all you need is 30 minutes twice a week,*****” (just for the resistance training piece) is very appealing**

- The way he does it is no breaks ‒ it’s not an easy 30 minutes
  - You’re not checking your phone, you’re not doing emails, texts in between

*What advice would you have for someone who’s thinking to themselves, “I want to get in the gym, I don’t have much time”?*

- If the alternative is doing nothing, Peter would say, “*Absolutely do it*,” but he would build into it a little bit slowly
- You would just hate to see somebody do that and then get injured along the way, or frankly just burn out due to the intensity of it
- But for some people, that could be really effective, especially if they have a trainer
- It might be a little challenging to do it on your own

***This is one of those things where if you have an accountability partner, that kind of workout could be more bang for your buck***

## Topics Peter is interested in exploring in future podcasts [1:40:15]

- Peter is really interested in the role of AI in education
  - That might be something he’d like to do a podcast on ‒ to understand how to accelerate learning for kids
- He’s really interested in healthcare policy stuff
- He’s become a huge fan this podcast called [*Acquired*](https://www.acquired.fm/)
  - [David Rosenthal](https://www.linkedin.com/in/davidjamesrosenthal/) and [Ben Gilbert](https://www.linkedin.com/in/benjamingilbert/) do these super deep dives into interesting companies
  - That’s Peter’s intellectual candy these days

**You want to talk about your renewed interest in chess right now?**

- Not renewed, Peter had never played chess until a couple weeks ago
- Now, it’s the first thing we play in the morning, and it’s the last thing we play before bed

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Olav Aleksander Bu (Pt.2)**:[#331 ‒ Optimizing endurance performance: metrics, nutrition, lactate, and more insights from elite performers | Olav Aleksander Bu (Pt. 2](https://peterattiamd.com/olavaleksanderbu2/)) (January 13, 2025) | [2:00]

**Episode of** ***The Drive*** **with Tadej Pogačar**: [#318 ‒ Cycling phenom and Tour de France champion Tadej Pogačar reveals his training strategies, on-bike nutrition, and future aspirations](https://peterattiamd.com/tadejpogacar/) (September 23, 2024) | [12:45]

**Portable VO****2** **analyzer**: [VO2 Master](https://vo2master.com/) | [17:00]

**Episode of** ***The Drive*** **with Alex Hutchinson**: [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/) (March 1, 2021) | [19:15]

**Episode of** ***The Drive*** **with Ralph DeFronzo**: [#337 – Insulin resistance masterclass: The full body impact of metabolic dysfunction and prevention, diagnosis, and treatment | Ralph DeFronzo, M.D.](https://peterattiamd.com/ralphdefronzo//) (February 24, 2025) | [24:30]

**Episode of** ***The Drive*** **with Gerald Shulman**:  [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) (December 7, 2020) | [26:00]

**The “ominous octet” of diabetes**: [Banting Lecture. From the Triumvirate to the Ominous Octet: A New Paradigm for the Treatment of Type 2 Diabetes Mellitus](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/) | *Diabetes* (R DeFronzo 2009) | [32:15, 38:30]

**First episode of** ***The Drive*** **about GLP-1 receptor agonists**: [#184 – AMA #29: GLP-1 Agonists – The Future of Treating Obesity?](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/) (November 15, 2021) | [35:00]

**Episode of** ***The Drive*** **discussing the kidney**: [#262 – AMA #49: Heart rate recovery, strength training, rucking, kidney function, and brain health](https://peterattiamd.com/ama49/#:~:text=heart%20rate.%E2%80%9D-,How%20kidney%20health%20and%20function%20typically%20measured%20%5B42%3A30%5D,-Kidney%20function) (July 17, 2023) | [36:45]

**Qatar study**: [47:45]

- [Combination Therapy With Exenatide Plus Pioglitazone Versus Basal/Bolus Insulin in Patients With Poorly Controlled Type 2 Diabetes on Sulfonylurea Plus Metformin: The Qatar Study](https://pubmed.ncbi.nlm.nih.gov/28096223/) | *Diabetes Care* (M Abdul-Ghani et al. 2017)
- [Combination therapy with pioglitazone/exenatide improves beta-cell function and produces superior glycaemic control compared with basal/bolus insulin in poorly controlled type 2 diabetes: A 3-year follow-up of the Qatar study](https://pubmed.ncbi.nlm.nih.gov/32729222/) |  *Diabetes, Obesity & Metabolism* (T Abdul-Ghani et al. 2020)
- [Type 2 diabetes subgroups and response to glucose-lowering therapy: Results from the EDICT and Qatar studies](https://pubmed.ncbi.nlm.nih.gov/35581905/) | *Diabetes, Obesity & Metabolism* (T Abdul-Ghani et al. 2022)

**Episode of** ***The Drive*** **with Saum Sutaria**: [#327 – Choices, costs, and challenges in US healthcare: insurance intricacies, drug pricing, economic impacts, and potential reforms | Saum Sutaria, M.D.](https://peterattiamd.com/saumsutaria/) (December 2, 2024) | [54:15]

**Episode of** ***The Drive*** **with Trenna Sutcliffe**: [#330 – Autism, ADHD, and Anxiety: Understanding the rise in autism and a multidisciplinary approach to diagnosis and treatment of each condition in children | Trenna Sutcliffe, M.D.](https://peterattiamd.com/trennasutcliffe/) (January 6, 2024) | [1:12:15]

**Episodes of** ***The Drive*** **that discuss the heritability of autism**: | [1:17:30]

- [#268 ‒ Genetics: testing, therapy, editing, association with disease risk, autism, and more | Wendy Chung, M.D., Ph.D.](https://peterattiamd.com/wendychung/#:~:text=major%20major%2C%20driver-,The%20genetics%20of%20autism%20%5B1%3A48%3A45%5D,-Autism%20is%20in) (August 28, 2023)
- [#191 – Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.](https://peterattiamd.com/karldeisseroth/) (January 17, 2022)

**Episodes of** ***The Drive*** **that debunk the perceived link between vaccines and autism**: [1:19:45]

- [#158 – Brian Deer: A tale of scientific fraud—exposing Andrew Wakefield and the origin of the belief that vaccines cause autism](https://peterattiamd.com/briandeer/) (April 19, 2021)
- [#159 – Peter Hotez, M.D., Ph.D.: Evolution of the anti-vaccine movement, the causes of autism, and COVID-19 vaccine state of affairs](https://peterattiamd.com/peterhotez3/) (April 26, 2021)
- [#317 ‒ Reforming medicine: uncovering blind spots, challenging the norm, and embracing innovation | Marty Makary, M.D., M.P.H.](https://peterattiamd.com/martymakary3/) (September 16, 2024)

**Episode of** ***The Drive*** **with Brian Deer**: [#158 – Brian Deer: A tale of scientific fraud—exposing Andrew Wakefield and the origin of the belief that vaccines cause autism](https://peterattiamd.com/briandeer/) (April 19, 2021) | [1:27:00]

**Episode of** ***The Drive*** **with Mike Israetel**: [#335 ‒ The science of resistance training, building muscle, and anabolic steroid use in bodybuilding | Mike Israetel, Ph.D.](https://peterattiamd.com/mikeisraetel/) (February 9, 2025) | [1:28:30]**Podcast Peter is a huge fan of**: [Acquired: Every company has a story](https://www.acquired.fm/) (2024) | [1:41:30]

---

## People Mentioned

- [Olav Aleksander Bu](https://www.sloansportsconference.com/people/olav-aleksander-bu)
- [Ralph DeFronzo](https://directory.uthscsa.edu/academics/profile/defronzo)
- [Saum Sutaria](https://investor.tenethealth.com/governance/person-details/default.aspx?ItemId=30f3fc46-815b-4e2b-9f36-9534f4cc5f28)
- [Trenna Sutcliffe](https://www.sutcliffeclinic.com/trenna-sutcliffe)
- [Mike Israetel](https://www.instagram.com/drmikeisraetel/?hl=en)
- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar)
- [Alex Hutchinson](https://www.alexhutchinson.net/)
- [Gerald Schulman](https://medicine.yale.edu/profile/gerald-shulman/)
- [George A. Brooks](https://ib.berkeley.edu/people/faculty/brooksg)
- [Brian Deer](https://en.wikipedia.org/wiki/Brian_Deer)
- [David Rosenthal](https://www.linkedin.com/in/davidjamesrosenthal/)
- [Ben Gilbert](https://www.linkedin.com/in/benjamingilbert/)