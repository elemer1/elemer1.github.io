# #329 ‒ Special AMA: Peter on exercise, important labs, building good habits, promising longevity research, and more

**Source:** [https://peterattiamd.com/specialama/](https://peterattiamd.com/specialama/)

---

In this special episode of The Drive, Peter tackles a wide range of listener questions submitted over the past year. The discussion spans essential topics such as exercise—covering grip strength, traveling workouts, and why Peter doesn’t consider exercise an ideal weight-loss strategy—and the top biomarkers everyone should track. He also explores promising new longevity research, his evolving views on longevity, and frameworks like “objective, strategy, tactics” for personalized decision-making. The episode wraps up with insights on building good habits and a glimpse into Peter’s recent reading list.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [Special AMA show notes page](https://peterattiamd.com/specialAMA/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of episode topics (and Peter’s car stereo saga) [1:45];
- The importance of grip strength and the best methods for training it effectively [3:45];
- Exercise while traveling: strategies for staying active and maintaining an exercise routine [14:45];
- Why women should prioritize strength training [18:00];
- The limited role of exercise in weight loss and its greater importance in improving health, body composition, and insulin sensitivity [19:45];
- The “top five most important biomarkers” for assessing health [22:45];
- Promising developments in longevity research [28:15];
- The development of Klotho as a neuroprotective drug: challenges, timelines of trials, and more [34:00];
- Peter’s updated view on the potential of epigenome manipulation to restore aged cells to their youthful state [39:45];
- How reversing age-related epigenetic changes in immune cells could revolutionize our approach to aging and disease [43:30];
- The “objective, strategy, tactics” framework, and the importance prioritizing impactful lifestyle habits over less significant health trends [49:30];
- Strategies for building and maintaining good habits [56:45];
- How to think about drugs and supplements as part of a longevity toolkit [1:02:00];
- Peter’s recent reading list [1:05:15]; and
- More.

---

The Peter Attia Drive

#329 ‒ Special AMA: Peter on exercise, important labs, building good habits, promising longevity research, and more

---

## Show Notes


---

\***Notes from intro**:

- Welcome to a special rapid fire “Ask Me Anything” episode
- Peter is joined by co-host Nick Stenson
- In today’s AMA episode, we thought it would be fun to do an end-of-year bonus AMA in a more rapid style manner to answer many questions that are commonly asked that have come through over the past year across a wide range of topics and frameworks
- We discuss questions on exercise
  - Grip strength
  - Exercise while traveling
  - The importance of strength training
  - Why Peter does not believe that exercise is an ideal strategy for weight loss
- We talk about labs
  - The “top 5 most important biomarkers” that everyone should know for themselves
    - Spoiler alert: Peter hates that question
- We talk about new research on longevity
  - Peter answers the question: if he has changed his mind on anything recently as it relates to longevity
- We speak about some of the frameworks Peter uses, and the importance of using the “objective, strategy, tactics” model as an approach versus a “one-size fits all” approach
- We close the conversation by talking about building good habits and Peter’s recent reading list
- If you’re a subscriber and want to watch the full video of this podcast, you can find it on the show notes page
- If you’re not a subscriber, you can watch the sneak peak on our YouTube page

## Overview of episode topics (and Peter’s car stereo saga) [1:45]

**Car stereo saga**

- Peter shares a funny story about a mechanic who has been trying to fix his car stereo for weeks
- Finally, one morning he got a video from his mechanic of AC/DC’s “[Back in Black](https://www.youtube.com/watch?v=pAgnJDJN4VA)” playing at full volume in his car — “*an awesome text message*” to wake up to
- Nick asks Peter if he ever installed big subwoofers in his car; Peter reveals he didn’t own a car until med school, relying on biking and public transport before that.

**AMA Format Overview**:

- Today’s episode is a more conversational style of the AMA, mixing specific and broad questions.
- Topics to be covered include exercise, labs, cancer, action prioritization, longevity, books, and other miscellaneous subjects.

## The importance of grip strength and the best methods for training it effectively [3:45]

- Grip strength is important probably for a little bit of the reasons that we understand **“the drunk under the streetlight problem”**
  - Which means the old adage of the drunk guy standing under the streetlight and someone asks him what he’s doing and he says he’s looking for his keys and they ask him if this is where he dropped him and he says, “*No, but this is where the light is.*”

**⇒** So sometimes where it’s brightest is where you end up looking

- Not to minimize grip strength, but to point out that in the literature, when you are interested in studying the relationship between strength and outcomes, you need an objective measurement of strength to test
  - Outcomes being everything from onset of dementia, all-cause mortality, cardiovascular disease, etc.

***If your hypothesis is strength is positively associated with, correlates with or even causal towards these things, you have to be able to test it***

**The question becomes, how do you test strength**

- Should we have people deadlift things?
- If you go through that exercise, you pretty quickly realize that’s probably not a good idea because most people don’t deadlift and technique is pretty important in deadlifting
  - It’s pretty easy for somebody to hurt themselves
- What scientists have done instead over the years is they’ve tended to study things that anybody can do, even if they don’t do the particular exercise that’s being tested
  - You shouldn’t be testing squat strength or deadlift strength if a person doesn’t deadlift or squat

***The things that have typically emerged as strength tests are grip strength, wall sits, bench press, leg extension, and sometimes leg press***

- Wall sits are a test of at least isometric quad strength
- If you don’t bench press, that’s a bit of a stretch

Peter adds a caveat, “*I don’t think there’s something super, super magical about grip strength. We just have such an abundance of data on it because it’s such an easy thing to test.*”

**The next question: is there something magical about having a strong grip?**

- Partly yes
- A strong grip in isolation doesn’t really exist
  - There’s really no example where a person has a very strong grip in their hand, but their forearm, deltoids, scapula, triceps, all of these other things are weak

***A strong grip is a way to test very strong, very stable control through the upper extremity all the way down to the outside world, and that’s a very practical thing***

- Just talk to any person who’s reached an age where they can’t open a new jar of pickles or they struggle to unlock a door or they struggle to carry a heavy plate
- When your grip strength goes, your quality of life absolutely goes

**⇒** Again, grip strength is just a proxy for people who are strong

**How should you train it?**

- What’s undeniable is the strength of the association
- Peter is not even going to go into that because the data on the association between grip strength and any and everything, positive warrants, no further discussion

**⇒** The more important question: is it causal?

- If grip strength is just a proxy for health and increasing grip strength does nothing to increase health, then we really shouldn’t be talking about this ‒ Peter doesn’t believe that that’s the case
- Peter makes an argument for that in [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=TJ6LQ7XM812M&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZcDrwEz2ut4KVIGSm5NlAO7omM4_pH67erX-o6Spqq6D21CWN_XYg2OLY4fsD1FjM_GrvbWXU0PG_bf9rd5n9t6lpNoZssWc5Qkpa25axRrV0tZvHEqZBI4sjeM9GbJurSRam_3RmEvS_mgam0R7C-8J4gJYRvoUGtA8oW4IER-zX4KtkmmqkeSZSN979kZ-pLNP2Sv_k6y87KyYiaw_2EU.6yOFGicS44ocUHmy03LyFqGbjIzcPPPOloANFviRQys&dib_tag=se&keywords=outlive+the+science+and+art+of+longevity+book&qid=1730206615&sprefix=outlive+th%2Caps%2C94&sr=8-1), going through the [Bradford Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) and explaining why he thinks there is causality in the association
  - In other words, why is it that increasing metrics of strength and endurance also improves lifespan and healthspan?
  - Not that they are just markers of healthy people who go on to have a better lifespan and healthspan

***What you really want to do is all of the other things that rely on strong grip***

- Squeezing a little grip squeezer bought on Amazon is not the optimal way to train grip strength

*Examples of what you want to do are exercises that involve carrying and pulling and hanging*

- Doing a [seated cable pull](https://www.youtube.com/watch?v=sP_4vybjVJs&pp=ygUac2VhdGVkIGNhYmxlIHJvdyB0ZWNobmlxdWU%3D), if you’re doing a pull down
- Doing a [pull-up](https://youtu.be/NBOmFfctBWQ)
- Doing a [farmer’s carry](https://www.youtube.com/watch?v=z7E_YU9P1jU)
- Doing a [deadlift](https://www.youtube.com/watch?v=WAn7OPr2RdE)

***Peter doesn’t do very many things that are “deliberate grip strength exercises”, but when he does farmer’s carries, he’s almost exclusively doing that to push the limits of his grip***

**⇒** 2 of these things that are the easiest for people to test on themselves at the gym with the least amount of equipment are the [farmer’s carry](https://www.youtube.com/watch?v=z7E_YU9P1jU) and [dead hang](https://youtu.be/3CEmHJXbNpc)

- Peter mentioned earlier, that if you haven’t deadlift before, you probably shouldn’t just start deadlift without understanding the form

**Goals depend on how extreme you want to go**

- There’s a standard out there that basically says the definition of exceptional strength is being able to walk with twice your body weight for 30 seconds
  - So if you weigh 175 pounds, you should be able to do a trap bar deadlift with 350 pounds and then carry it, walk with it for 30 seconds
  - Obviously that’s a very high standard
- A more reasonable standard for maybe sub-elite athletes, for a male in his 40s: to be able to carry his body weight for 1 minute is good and for 2 minutes is very good
  - So again, if you weighed 175 pounds, you’d put 175 pounds on a trap bar, you’d pick it up and march with that for one to two minutes
  - For a woman, carrying 75% of her body weight would be an excellent achievement
  - You might discount that by 10% per decade [after age 40]

Peter adds, “*I don’t think a person should be discouraged if the first time they try to do that they can’t do it. In fact, if you haven’t been doing that thing and if you’re not used to deadlifting and doing a lot of pull-ups and hangs, I would not expect anybody to be able to do that.*”

You want to work up to that goal without going to maximal effort (build resilience slowly)

*For example, if a 175 lb. person tried that test*

- They want to carry 175 pounds on a hex bar for at least a minute and 30 seconds
- Peter wants you to drop the weight on that bar to 150 pounds (25 pounds below that 175) and do 30 seconds sets
  - Do 10 sets at 30 seconds
  - Then, advance weight and or time accordingly,
  - But you to be able to get through those 10 sets such that at the end of the 10 you’re really completely gassed
    - That’s the way Peter likes to see people build strength

**The dead hang**

- As its name suggests, you just put your hands up on the bar and you hang
  - You can do it over any configuration of bars, but Peter likes to do it over a straight bar and
- There’s two big things to be thinking about here: do you do it with the scapula engaged or not engaged?
  - Peter likes to do it with the scapula engaged
  - So the scapula are down and so the lats are under a lot of stress, but they’re not being as stretched
  - If the scapula go up, you’re going to put a little bit more stress on the elbows
  - That doesn’t necessarily cause problems
  - Peter can dead hang both and his dead hang record was actually an attempt where his scapula were up
  - Sometimes he will go back and forth between the 2 techniques and he didn’t suffer any permanent injury from doing that

**⇒** A very strong 40-year-old male should be able to dead hang for at least 2 minutes, and a very strong 40-year-old female should be able to dead hang for at least 90 seconds

- Again, you would discount that as time goes by decade and probably subtract about 10 seconds per decade
- A lot of people don’t succeed in that at their first time, and that’s fine
- You can do that either by adding **resistance bands**: use a band that you are sinking into, you put your feet into it so it’s removing some of the weight
- Alternatively, just go for much **shorter periods of time**: maybe do 30 second hangs and repeat those

*Do you have a preference on hand placement?*

- You can mix and match
- Peter likes to be palms out, so he’s palms out both hands the same over

*What was your record?*

- 4 minutes, 35 seconds with full scapula up, not engaged scapulas
- His wife’s record is 3 minutes 10 seconds
  - Which he thinks is more impressive
  - She probably trains it a little less
  - It was literally the second time she ever did a dead hang

**Wall sits**

*What is an ideal time that you should be able to do that for?*

- 2 minutes is a pretty good wall sit for anybody [[AMA #55](https://peterattiamd.com/ama55/)]
- Peter doesn’t tend to do wall sits like that

*There’s another exercise Peter prefers to do on an air bike*

- Ride on the air bike for a minute hard and then hold a kettlebell and wall sit for 30 seconds to a minute
- It’s a shorter sit, but he comes in pre-fatigued, plus he’s adding some stress by holding a weight

## Exercise while traveling: strategies for staying active and maintaining an exercise routine [14:45]

**What are easy exercises you can do to stay active when you’re traveling?**

***You have to be deliberate***

- When Peter is traveling, his #1 question is, “*Show me the gym.*”
- He wants to know exactly what the gym looks like

*Unless you’re going to the middle of nowhere, you have a choice in where you stay*

- You may have to make a concession
  - Maybe you’re going to add 10 or 15 minutes of driving time
  - Maybe the hotel is going to be a little bit more expensive
- The hotel is not going to allow you to do everything you do at home
- But Peter has not been to a hotel where he can’t do something
- Even if they just have a bench and dumbbells
  - Hopefully they have a bench incline as well as a flat bench
  - He can do presses
  - He can do rows
  - He could do push-ups
  - He could do rear foot elevated split squats, regular split squats

> “*There’s a lot you can do with a modest amount of dumbbells and a bench*.”‒ Peter Attia

- Most gyms have much more than that, but that is step #1

*Step #2 when traveling is you have to be mindful of what jetlag is going to do to you*

- Peter is in central time and when he travels west to California, it’s really easy for him to work out early in the morning (5:00 A.M.)
  - He can start his meetings early on those days because he knows he’s going to get the workout done early
- Conversely, if he goes to New York, he has to keep in mind that he’s going to be a little bit tired
  - He’s not going to want to work out at 6:00 A.M.
  - Even though he’s comfortable getting up at 5:00, he doesn’t want to work out first thing at 5:00
  - Then he has to adjust the timing of meetings [for later]

***The 2 big things are to make sure your schedule has the time for you to do the workout (budget according to what jet lag is going to do to you), and pick a place to go so you can do the workout in the hotel***

**⇒** The key is something’s better than nothing when you’re traveling and it comes to exercise

- The goal of exercising when you’re traveling is not to make the most incredible gains, it’s just to prevent the losses

## Why women should prioritize strength training [18:00]

**If you have female patients who prefer cardio to weightlifting, why do you think women should pay special attention to strength training?**

- There are 2 big reasons
- 1 – Women naturally have less muscle mass and are not as strong as men, and yet they still live in the same environment as men do
  - Which is to say they’re going to be subject to all the same forces
- And this is one of the reasons why we see women fall more than men
  - It’s not just that women are more injured by falls, which they are (we’ll discuss that in a moment)
  - It’s that women actually fall more than men and one of the reasons for that is a disparate exchange in strength
- 2 – Strength training is one of the most important exercises that we have to stabilize bone density
- Because women tend to have a lower genetic ceiling, and more importantly, because women lose estrogen during the middle of their lives, they begin to experience a disproportionate drop in bone density as they age
- The gap between men and women (that’s always there) really begins to widen in the 5th or 6th decade of a woman’s life
- And that’s all the more reason why she needs to be strength training because there really is no substitute for the type of strain that is placed on bones during strength training

***The bone benefits of strength training can’t be replicated by running, and certainly can’t be replicated by cycling or swimming or other endurance sports or yoga; all of those things are simply not going to do it***

## The limited role of exercise in weight loss and its greater importance in improving health, body composition, and insulin sensitivity [19:45]

Peter’s take: “*Overall, I don’t think exercise is a phenomenal strategy for weight loss*.”

- That’s not to say that exercise doesn’t play a role in maintaining a healthy weight (Peter thinks it does)
- If you look at the experimental evidence (ie. calorie expenditure), exercise does not appear to be a very viable tool for fat loss

**⇒** The majority of the work for fat loss really has to be done through caloric restriction

> “*If you just want to simplify and think of a machine with inputs and outputs, it’s really reduction of the inputs that seems to play the greater role in weight loss.*”‒ Peter Attia

- That said, we think that exercise is a very important part of health and that health is the single most important thing
  - Health is more important than weight loss per se
- Furthermore, exercise does indeed make a difference for **body composition**, and body composition should probably be thought of as more important than weight per se

*Peter doesn’t think a* [*BMI*](https://en.wikipedia.org/wiki/Body_mass_index) *is an especially valuable tool at the individual level*

- It’s a reasonable tool at the population level
- But for any one individual, BMI is not really that helpful
- Peter doesn’t know his BMI, but he knows it’s in the overweight category
  - It’s probably 27 or 28
  - Above 25 is overweight
  - Above 30 is obese
- If his BMI is overweight, is that a bad thing?
- Not necessarily; it depends on his body composition

**⇒** Body composition is an area where exercise makes a huge difference

**Indirectly, there are other areas where exercise is very important for weight maintenance**

- Exercise maintains insulin sensitivity and the more insulin sensitive a person is, the easier it is for them to respond to appetite signals
- While just doing the accounting of calories burned versus calories in, exercise generally falls short there
  - In other words, whatever calories you expend doing the workout, you’re generally going to pay them back

***The goal is to be sensitive to the appropriate appetite signals so that one doesn’t overeat in that state***

**Any other things on exercise that you want to share before we move on?**

Peter adds “*I like exercise.*”

- He tried to say that in a *Steve Carell voice*, like, “*I like lamp. I love lamp*.”

## The “top five most important biomarkers” for assessing health [22:45]

**If you were going to meet with a new patient and you could only see 5 biomarkers to figure out their risk to figure out where they’re at, what would those be?**

- Peter hates this question and responds, “*I don’t know how you guys keep sneaking this goddamn question in here.*”
- A few months ago, he was on [Chris Williamson’s podcast](https://youtu.be/_hi8qOZB2qU?si=NU0lVOe9HD-lAoKD) and Chris asked him to pick his 10 favorite exercises
- Peter thinks he spent the next 10 minutes negotiating where he was going to draw the line between what constituted an exercise versus…
- He might end up doing the same thing here

*Blood-based biomarkers*

***#1 & 2 Peter wants to know*** [***apoB***](https://en.wikipedia.org/wiki/Apolipoprotein_B) ***and*** [***Lp(a***)](https://en.wikipedia.org/wiki/Lipoprotein(a))

- He doesn’t need to know anything else about your lipids
- He doesn’t need to know your LDL cholesterol, HDL cholesterol, or even your triglycerides (unless you’re an edge case with triglycerides>600 mg/dL)

**⇒** ApoB captures the full burden of your atherogenic particles

- ApoB contains all the information of VLDL, ILDL and is more accurate than non-HDL cholesterol
- He wants to know your Lp(a) because of the unique risk that carries
- The good news is he only needs to know your Lp(a) 1 time and then we’re done with it

**⇒** If either apoB or Lp(a) is elevated, we have work to do

***#3 Peter likes to know the*** [***APOE genotype***](https://en.wikipedia.org/wiki/Apolipoprotein_E)

- It’s like the Lp(a), that’s a 1 and done test (you don’t need to know it over and over)

Peter explains, “*I am firmly in the camp that this is actionable information. So I don’t think anybody including the most hardcore naysayers would argue that the information is important and it speaks heavily towards the risk of dementia and to a lesser extent cardiovascular disease.*”

- Folks like [Richard Isaacson](https://ind.org/about#team) and Peter think there’s an action that can be taken toward prevention
- Knowing this genotype is valuable information not just to doomsday, but to plan accordingly

Peter is going to skip the hormones because we’re limited to 5 (as much as he wants to understand someone’s thyroid status, androgens, and other things)

***#4*** [***OGTT***](https://en.wikipedia.org/wiki/Glucose_tolerance_test) ***gets into metabolic health by measuring fasting insulin and glucose***

*You can count that as 1 test, but for people who can’t get an OGTT (because it’s not the easiest), what would be a backup test?*

- You could argue that [hemoglobin A1c (HbA1c)](https://en.wikipedia.org/wiki/Glycated_hemoglobin) could be used instead
- Peter has [written](https://peterattiamd.com/problems-with-hba1c/) at length about why HbAlc is misleading
- Peter measures HbA1c and is always interested in relative changes, but he never does it without knowing the OGTT
- If there’s a discordance between what the OGTT spits out and what the A1c is predicting, he will use a [CGM](https://en.wikipedia.org/wiki/Continuous_glucose_monitor)

*An OGTT will provide a fasting insulin and glucose*

- The patient drinks 75 grams of glucola and there’s a blood draw at 30, 60, and 90 minutes (he doesn’t go to 120 min)
- You’re going to check insulin and glucose, and there’s a very predictable curve that we are looking for both for insulin and glucose and deviations from those are diagnostic of what’s going on
- That’s very valuable information

***#5 Peter is going to just cheat here and just say he wants a metabolic panel***

- He jokes, “*You can tell me to go to hell, but I think if you can let me get a* [*CMP*](https://en.wikipedia.org/wiki/Comprehensive_metabolic_panel) *and maybe* [*cystatin C*](https://en.wikipedia.org/wiki/Cystatin_C#Laboratory_measurement) *for kidney function.*”
- Normally a complete metabolic panel comes with electrolytes, and he would not rank those at top 5
  - A person needs to be sick for those things to be out of whack
  - He doesn’t care about that
- What he’s really trying to figure out is a way to cheat this question so he can see their **liver function and renal function**

**⇒** Cystatin C gives information about renal function

- Peter would also like to see their [homocysteine](https://en.wikipedia.org/wiki/Homocysteine), but if he had cystatin C and [LFTs](https://en.wikipedia.org/wiki/Liver_function_tests) he’d be pretty happy
- [AST](https://en.wikipedia.org/wiki/Aspartate_transaminase) and [ALT](https://en.wikipedia.org/wiki/Alanine_transaminase) transaminases (horrible names) give information about liver function

## Promising developments in longevity research [28:15]

- Despite the busyness of his schedule and obligations, one of the of the highlights of the week for Peter is sitting down for an hour on Fridays and going through some of the curated scientific journal feeds that he gets
  - Just perusing the most relevant 20 or 30 papers that have been published in the week
- It’s important to put this in context: about 125 to 150,000 papers in the English language make their way onto PubMed each month
  - It’s just a staggering number and there’s no way to filter through that
- The best we can do right now is to lean on other people and algorithms to curate things for us
  - Peter thinks this is going to change
- Long gone is the day when you could look through every single article of *The New England Journal of Medicine* and *JAMA* every week
- Much of what those journals write about doesn’t really feed into Peter’s wheelhouse anymore
- He needs to be reading far more upstream in the basic science and translational science than in the clinical
  - Of course, he does pay very close attention to the clinical stuff
- When a trial comes out that talks about the impacts of [SGLT2 inhibitors](https://en.wikipedia.org/wiki/SGLT2_inhibitor) on [heart failure](https://en.wikipedia.org/wiki/Heart_failure), that’s a relevant finding
  - Peter wants to understand that when it talks about the benefits of SGLT2 inhibitors on renal function

**The 1st thing Peter is really excited about is the ability we have to leverage AI to help us do more of this searching**

- Peter thinks AI is getting to the point where it’s getting better and better and smarter and smarter at identifying papers that we’re going to find interesting
- Where it is still woefully deficient is it cannot interpret a paper to save its life
- It can summarize a paper and that’s great
  - It can do a better summary than what the abstract is
- As of this point in time, there is no substitute for a hyper-intelligent, hyper-well-informed person with scientific training going through a paper and dissecting it (as our analysts do)
  - Teasing out what’s relevant, what’s not, what’s noise, what’s signal
  - Where’s the blind spot, where’s the error, all of those things

***When we are able to train models to do that, that’ll be a step function change in our productivity***

**Not long ago, a** [**paper**](https://pubmed.ncbi.nlm.nih.gov/39020175/) **came out that looked at a molecule that was an antibody to interleukin 11 (IL-11)**

- The hypothesis of the authors in this paper was that [IL-11](https://en.wikipedia.org/wiki/Interleukin_11) is pro-inflammatory, pro-fibrotic, and it might promote aging
- The question was, if we block that, do we blunt the effects of aging?
- To be honest, if Peter was asked that question before the experiment, he would’ve said, “*It’ll be interesting, but I don’t think it’ll have an effect on lifespan*.”
  - That’s why we do experiments
- In the study, they gave mice the antibody from age 75 weeks until death
  - Let’s do the math in human years, that’s like starting a human in their 60s
  - This was a deliberate decision on the part of the investigators, which is to wait until the mice were “old” to begin to treat them
- The treated mice (both male and female) lived longer; and it wasn’t subtle
- If you look at the Kaplan-Meier graph [shown below], the median male lifespan extended by 20.5%, the median female lifespan extended by 25%
  - We also wrote a [newsletter](https://peterattiamd.com/interleukin-11-and-lifespan/) about this

![](https://peterattiamd.com/wp-content/uploads/2024/12/f1-specialama-1024x355.png)

**Figure 1. Kaplan-Meier survival curves (shading represents 95% confidence interval) showing the cumulative survival probabilities for male (d) and female (e) receiving monthly administration of IgG control or anti-Il-11, starting at 75 weeks of age (red dotted line)**. Image credit: [*Nature* 2024](https://www.nature.com/articles/s41586-024-07701-9)

- This is very interesting
- It’s also congruent with what has been seen in certain genetic experiments where deletion of IL-11 also extends lifespan in both sexes [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/12/f2-specialama-1024x350.png)

**Figure 2. Kaplan-Meier survival curves (shading represents 95% confidence interval) showing the cumulative survival probabilities for male (a) and female (b) mice lacking IL-11 (*****IL11******–******/******–*****) and wild-type mice (WT)**. Image credit: [*Nature* 2024](https://www.nature.com/articles/s41586-024-07701-9)

- Peter had a good back and forth between friends and colleagues who pay a lot of attention to this stuff

**⇒** The real question is what’s the downstream path that’s mediating this?

- Is this being mediated through one of the other existing pathways that we understand such as [mTOR](https://en.wikipedia.org/wiki/MTOR#Clinical_significance) or is it through a novel pathway?
- Of course, there are lots of ways you can test this, but the most interesting way to test this might be to do an **additive experiment**
- Peter is not convinced that will happen, but he’ll just leave it to say that he found this to be very interesting
  - He does not think this is noise
- Of course he’d love to see this experiment both replicated in this model, but more importantly in other models (a different mouse model, primates)

## The development of Klotho as a neuroprotective drug: challenges, timelines of trials, and more [34:00]

**Work discussed on a recent podcast with Dena Dubal around klotho**

- [[Episode #303](https://peterattiamd.com/denadubal/)]
- [Klotho](https://en.wikipedia.org/wiki/Klotho_(biology)) is a protein that is made in the kidney
- We don’t really know much about how it works
  - It increases with certain factors like exercise
  - It decreases in general with aging
  - It seems to be remarkably and completely neuroprotective
- As Peter disclosed in that podcast, he’s involved in a company that is trying to commercialize klotho

***The idea of getting that into clinical trials in the next couple of years is incredibly interesting based on the mouse and monkey data***

*A lot has to happen before we fully know how promising that work actually is. How long does science take before we figure out if there is something valuable there for humans?*

- A lot of it depends on how much money is behind an idea
- But even with all the money in the world, you still have to go through a regulatory process
- In this case, because most of the animal work has been done, it’s now a question of scaling up what’s called [GMP](https://en.wikipedia.org/wiki/Good_manufacturing_practice) production
  - How do you scale up the process of making this under good manufacturing processes that are going to be suitable for giving a drug to a human?
- Every FDA approved drug has to go through this process of actually demonstrating that it can be manufactured in a pristine way, and then the process to do a couple of other experiments to finish getting what’s called the [IND](https://en.wikipedia.org/wiki/Investigational_New_Drug)
  - That’s the Investigational New Drug license or document that effectively allows you to now move into a human clinical trial
- Once you have that in place, your first human clinical trials are known as phase I trials
- Technically we now don’t just do a phase I, II, and III, but rather a Ia, Ib, IIa, and IIb, where the studies get slightly larger each time [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/12/f3-specialama-1024x560.png)

**Figure 3. Phases of drug development and clinical trials**. Image credit: [Tracer](https://www.tracercro.com/early-phase-clinical-trials/)

- The purpose of the **phase I studies** (which are very small) are to test escalating doses of the drug, and the primary outcome is adverse reaction
  - So in an ever-increasing dose of this drug, especially starting well below what you believe is the therapeutic dose right up to and beyond the therapeutic dose, does this exhibit toxicity?
  - Without that being met, nothing else matters
    - If it’s toxic, it doesn’t matter if you find the drug is working really well
- Safety is paramount before you move into the **phase II studies** where you’re continuing to look at safety data because you have a larger cohort, but you’re really now turning your interest to efficacy
- How long does all of that take?

Peter explains, “*I would say that in the case of Klotho, that’s probably by the beginning of 2027, so 2.5 years to have those into hopefully phase I and maybe even by the end of ‘27 into early phase II*.”

- And if that were successful, then you really, you’re thinking about this being a potentially approved drug maybe within 5 years after that
- This stuff takes a while

Nick responds, “*From a layman perspective, you hear that and you’re like, man, it’s frustrating how long it takes to even know if something fully works or not, right?*”

- All this time and money, and at the end of those 5 years, it’s not guaranteed to make this huge difference
- Obviously those steps are there for a reason

**Can science ever become faster, or is that just the nature of safely finding answers to questions that are really hard?**

- Yeah, Peter thinks it is
- Most drugs that are thought of or discovered or created ultimately aren’t going to work and that to work, these 2 things have to be completely true
- 1 – The drug has to be really safe, and if it’s not 100% safe, it has to have a very clear, well-defined, understood set of toxicities that are justifiable for the disease it’s treating
  - In other words, you’re going to be way more willing to tolerate some toxicity for a cancer drug than you are for a drug that’s going to be used for prevention of disease such as a blood pressure lowering drug or a lipid lowering drug
- 2 – You have to measure efficacy
  - What we don’t want to do is create another supplement industry where drugs are getting approved that don’t necessarily work (and then people are wasting their money)

Peter adds, “*I don’t think there’s a very clear transparency between those three variables, safety, efficacy and cost.*”

- People making decisions on buying drugs aren’t doing a risk adjusted return on investment calculation for a drug
  - To do that, you have to know exactly what the efficacy is, exactly what the risk is and exactly what the cost is
- There’s so much opacity around that in pharma that it’s very difficult for people to understand that
  - Especially in oncology in terms of making sense of is this drug really worth $40,000 for a 2-month course that has this much toxicity that extends life for potentially this much?
  - Those are very difficult things to answer, but again, the only way you can get at that is through these trials

## Peter’s updated view on the potential of epigenome manipulation to restore aged cells to their youthful state [39:45]

**Is there anything in the field of longevity that you’ve changed your mind on recently or are thinking about differently?**

- There are 2 things Peter is updating his priors on
- 1 – The idea of using drugs to manipulate the [epigenome](https://en.wikipedia.org/wiki/Epigenome) as a better way to regulate the genome
- For example, using epigenomic silencing as a targeted therapy
- This idea of cell or tissue specific epigenomic restoration to address changes in the epigenome that occur over time as the tissue ages
- Peter has talked about this on other podcasts [[episode #222](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/)], the idea of using [Yamanaka factors](https://en.wikipedia.org/wiki/Shinya_Yamanaka#Yamanaka's_research:~:text=he%20identified%20the%20four%20key%20genes.%20They%20found%20that%204%20transcriptional%20factors%20(Myc%2C%20Oct3/4%2C%20Sox2%20and%20Klf4)%20were%20sufficient%20to%20convert%20mouse%20embryonic%20or%20adult%20fibroblasts%20to%20pluripotent%20stem%20cells) to take mature cells back to immature stem cells
  - That’s a great proof of concept, but probably not practical
- A more interesting idea is rewriting the code not to revert it back to a stem cell, but take it back to a young cell that’s already differentiated (a younger version of itself)
  - That’s really interesting
  - The implications are limitless if this can be done
- [2 problems] are writing the source code and then delivering the vehicle to make that happen
  - Progress on the former is being made
  - We have work to do on the latter, but we’re in a place now that Peter wouldn’t have expected 10 years ago (and that’s exciting)

**People always ask Peter, “*****Hey, it’s been two years since you wrote*** [***Outlive***](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=13YLPEE9XHVEG&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZd-rQeR9h0AuJR0iuQfOKefb1pX0k60Tf-0SmH6Y20jHlCSJZAt2_cq-hsNe-RSZzHsXQveMRbdFaKWfeEHtdYvQmJ6o5_XUIXT5R69R8vVaoudoPpOgukz6DE-2vLeyKFKeUmGl_qSywVK2q6oqx0lIkSyIefvPeBwKkiaNlSMVpU1RaVyqPLVsW6TwkQ-91JE3REZ0CLvfTIX0wqh2T9Q.uVVb8l-qr2zBIaoLWSrmxylyCWh7_89F0iT3O1M9saA&dib_tag=se&keywords=outlive+peter+attia&qid=1730993430&sprefix=outlive%2Caps%2C97&sr=8-1)***. Have you changed your mind on anything or have you modified?*****”**

> “*I really think that a fifth horseman that can’t be ignored is immune function.*”‒ Peter Attia

- The **4 horsemen of death** are the cardiovascular/cerebrovascular diseases of ASCVD, cancer, the neurodegenerative and dementing diseases, and the metabolic diseases
- Everyone listening to this knows a person in old age who got one pneumonia (or terrible cold) that they never recovered from
  - Even if they didn’t die from that, it really compromised their quality of life
  - Not even thinking about COVID
- Peter reflects on this every time he has a cold
- He had a really bad cough about a month ago and it didn’t phase him
  - It didn’t interrupt his life
  - He didn’t take any antibiotics; he muscled through it
  - His workout performance sucked for about 10 days
  - He could just imagine what nastiness was in his lungs based on what he was hacking up
- He thought, “*If [this] same infection falls on me in 30 years, it could be a very different outcome, because right now my immune system’s fine, it’s just going to handle it. But in 30 years it might not be.*”

***Peter would like immune aging to be a target of therapy, and he thinks the epigenome is the way to go about doing that***

- He would love to know that when a person is 80, 90 years old, we can give them [CD4 cells](https://en.wikipedia.org/wiki/T_helper_cell), [CD8 cells](https://en.wikipedia.org/wiki/Cytotoxic_T_cell), [B cells](https://en.wikipedia.org/wiki/B_cell) that actually look and behave as though they were 40 years old
- That would be a game changer in terms of lifespan and health span

## How reversing age-related epigenetic changes in immune cells could revolutionize our approach to aging and disease [43:30]

**How would you explain manipulation of the epigenome to a 9th grader, and then also explain what that means for immune function**

- Let’s say you took an 80-year-old and made their immune function back to a 40-year-old. That doesn’t necessarily mean you think they’re going to live for another 50 years
- That means that their chance of dying from something like a cold goes down a lot more

Peter shares, “*There’s still nothing in my world that points towards immortality or living to 200 or things like that. It’s just that once you’re in your your ninth and 10th decade of life, you lack resilience.*”

- There’s 2 things going on
- 1 – The probability of acquiring disease gets higher
  - You’ve been around longer, you’ve acquired more genetic mutations
  - Eventually at some point, some of these mutations escape, they become cancer
  - You’ve been around longer, your coronary arteries have been exposed to more and more oxidative stress at the hands of lipoproteins and eventually the atherosclerosis tips in the favor of an ischemic event

***All of those things are correct, but you have to understand this, as you get older, you also become a lot less resilient***

- This is a lot of what sucks about aging
- Peter feels this in his 40s compared to his 20s and 30s, “*I’m not the man I used to be. I can’t do 3 hard workouts in a day anymore… I can’t recover quick enough*.”
- Imagine what the immune system is like when you’re 85
  - It’s not going to bounce back from things

**⇒** The objective is to push back on all of those forces ever so slightly to preserve quality of life

- And along the way, you’re going to get a longer life
- Peter can’t tell you if it’s going to be 10 years longer, 5 years longer, 15 years longer
- He can’t imagine it’s going to be 30 years longer (that’s science fiction)

***The objective here is how do I not succumb to all of these insults in an ever-increasing world of declining resilience***

**⇒** Forms of low resilience as we age include: [declines in] immune function, frailty, sarcopenia, insulin resistance, and anabolic resistance

- The goal is to address as many of them as we can through the deliberate choices we make
- Peter hopes that some of those deliberate choices include molecules that can address that

*To address the 1st question, what does that mean ‒ let’s look at a T cell*

- You’ve got a [CD4 T cell](https://en.wikipedia.org/wiki/T_helper_cell) and a [CD8 T cell](https://en.wikipedia.org/wiki/Cytotoxic_T_cell) (2 very important cells in your immune system)
- If you could draw a tube of blood and sequence a sample from the time you are born, what we would notice if we looked at the DNA inside those T cells
- We would notice that on the backbone of that DNA, there are [methyl groups](https://en.wikipedia.org/wiki/DNA_methylation)
  - The methyl groups tend to be associated on the Cs when they’re next to Gs
    - We call them CpGs, a C phosphate G is where we tend to see those methyl groups
- Obviously your DNA isn’t changing as you age, because you’re the same person, right?
- So we’re going to have the exact same DNA sequence over and over and over again, but what we notice is those little methyl groups (the CH3’s) that are stuck to the C backbones, they’re changing
- If we do this on a lot of people, we’re going to notice, everybody’s got different DNA, but there’s a very predictable change in what those methylation groups look like on the DNA backbone

**⇒** The trillion-dollar question is, are those changes casual or are those changes reactive?

- Nobody disputes that these changes are happening
- Peter is involved in a company called [Moonwalk](https://moonwalk.bio/) that can probably measure these changes better than any company out there using literally base pair resolution

*Interesting questions*

- What’s driving the phenotypic change in your T-cell?
- Nick is so young [at age 38] that he hasn’t experienced this yet, but if we were to continue this exercise until you’re 90, **at some point the phenotypic change in your T-cells is so profound that they cease to be functional**
  - That’s why you’re going to succumb to more cancer and more infections

***What we want to know is, what if we could change those methyl groups to look just like they looked when you were 20?***

- Would that change the phenotype of your T-cell back to the same place?
- For Peter, that is potentially the most important question in biology

**Is that answer 5 years away, 10 years away?**

- That’s hard to answer
- The good news with that question is Peter believes it’s an answerable question
- There are questions out there that are so fascinating and Peter doesn’t know how you could answer them
  - Meaning, doing the experiment would be so complicated
- That’s not the case here

***We don’t yet have the tools to do it, but conceptually, this is an answerable question***

- Peter hopes it’s within our lifetime because even if he doesn’t live long enough to experience the benefits of this, he would love to live long enough to know that this is paid dividends

## The “objective, strategy, tactics” framework, and the importance prioritizing impactful lifestyle habits over less significant health trends [49:30]

- A lot of times this come up when people ask about how they should exercise, should they take this supplement or that drug

**Why do you think “objective, strategy, tactic” is so important, and how do you apply that for you and your patients?**

- There’s a reason Peter organized [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=13YLPEE9XHVEG&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZd-rQeR9h0AuJR0iuQfOKefb1pX0k60Tf-0SmH6Y20jHlCSJZAt2_cq-hsNe-RSZzHsXQveMRbdFaKWfeEHtdYvQmJ6o5_XUIXT5R69R8vVaoudoPpOgukz6DE-2vLeyKFKeUmGl_qSywVK2q6oqx0lIkSyIefvPeBwKkiaNlSMVpU1RaVyqPLVsW6TwkQ-91JE3REZ0CLvfTIX0wqh2T9Q.uVVb8l-qr2zBIaoLWSrmxylyCWh7_89F0iT3O1M9saA&dib_tag=se&keywords=outlive+peter+attia&qid=1730993430&sprefix=outlive%2Caps%2C97&sr=8-1) in some ways around that principle
- He doesn’t think it’s a necessary principle when you’re addressing a simple question
  - If you’re going out to the pool and you want to make sure you don’t get a sunburn, you don’t need to apply “objective, strategy, tactics”
  - You can go straight to tactics (the objective is self-evident)
  - Peter explains, “*Do not pass ‘Go.’ Do not engage in strategy.*”
- Once you start to get into the complicated stuff, you’re often surprised at how unclear you are on what the objective is
- If you’re not even clear on the objective, there is zero probability you will find your way to the right tactics
  - Especially if you’re not even attempting to go through strategy

*For example, should I take curcumin or bee’s knees pollen, or something like that*

- When a person is asking that, they’re clearly asking a **tactical question**
  - Do I take this or do I take that?
  - Do I do this lift or do I do that lift?
  - If you even ask them the why, they rarely can say why
- For example, “*There’s an NAD clinic that’s doing IV* [*NAD*](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) *infusions. This has got to be good for me, right? I’m doing it. It’s just awesome.*”

**⇒** Start with the objective: what are you doing this for?

- “*I feel better*.”
- Really? How much better do you feel?
  - How are you quantifying that and how long does that last?
- By the way, most people don’t feel better with IV NAD infusions
  - They usually actually feel worse acutely
  - Maybe they do feel better after; it’s not been studied clearly
- You want to get people to at least think about the question correctly
- If it’s you feel better, great. What does that translate to?
  - Does that translate to more energy?
  - Does it translate to better performance?
  - Let’s be very, very clear and very articulate about what we’re doing this for
- You should ask yourself a question: ***Are you doing this more as a way to address healthspan, or more as a way to address lifespan?***
  - Is this something that you are doing because it is reducing your risk of death or delaying the onset of chronic disease?
  - Or are you doing this because you believe that this intervention is improving the quality of your life as defined by these very objective measurements?
    - We can really define quality of life through movement, through avoidance of pain, through strength, through endurance, through memory, through processing speed
    - There’s a more than a dozen very easy objective ways to define quality of life
- And if a person is skipping that step or being vague in that step, they’re going to really, really struggle

***When it comes down to the role of supplements, once you identify the objective, and once you’ve identified the risk and the reward trade-off, you can generally run straight to tactics***

*But when you think about things like exercise (for example), you do need to go through strategy phase as well*

- You could argue exercise is good, mostly without exception
- But now you have to think about how to divide your portfolio up
- You might have to think, “*Well God, if I’ve been a lifelong runner and I’ve got a great cardio engine, but I’m lanky and my bone density is mediocre and I’m really not that strong and I’m willing to spend this much time exercising, but no more, how do I need to adjust the portfolio to make that happen?*”

⇒ Here is where we tend to rely on frameworks, and here the framework we’re going to turn people to is the [centenarian decathlon](https://peterattiamd.com/training-for-the-centenarian-decathlon/)

- The centenarian decathlon becomes the strategic lattice that you would figure out where your gaps are

***Because the goal is gap identification***

- We want to understand not what your deficits are at 40, because they’re not that interesting and they’re not that great

⇒ It’s where your gap’s going to be at 80 because that’s where it’s going to be most profound

- And if you project back from 80 to 40, you’ll see that those gaps are probably there, but they’re just not causing problems yet
- The strategy of gap identification based on **backcasting** [a term Peter borrowed from Annie Duke, discussed in [episode #60](https://peterattiamd.com/annieduke/)], which is of course everything that he does at [102](https://10squared.com/) and elsewhere, and that becomes a very important way to do things

**Explain another core framework that you talk about: the idea of “major in the major, minor in the minor”**

- There’s so much information coming at people and sometimes they can be a little bit paralyzed on what to do

Peter adds, “*There is an epidemic of ‘majoring in the minor’ and ‘minoring in the major,’ and I don’t know who first said that.*”

- It’s not a mystery why this happens
- It’s easier to think about [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) drips and [saunas](https://peterattiamd.com/sauna-facts-myths-and-how-to/) and [cold plunges](https://peterattiamd.com/cold-therapy/) and [red light therapy](https://peterattiamd.com/ama65/) and [green juices](https://peterattiamd.com/ama36/?_gl=1*1pjvquh*_up*MQ..*_ga*MTEyNjI3MDQyLjE3MzIwNDEwNTI.*_ga_1CG74LFGNE*MTczMjA0MTA0OS4xLjAuMTczMjA0MTA0OS4wLjAuMA..#:~:text=of%20supplementing%20with-,green%20powders,-%2C%20multivitamins%2C%20and%20more) and this supplement and that supplement when all you have to do is basically buy them and they’re pleasant to engage in
  - Okay, saunas and cold plunge can be a little bit uncomfortable, but for the most part they’re pretty pleasant to engage in
- It’s actually a pain in the butt to work out and be mindful of your nutrition
  - To minimize the amount of alcohol you eat
  - To put your stupid phone down and actually pay attention to the world
  - To go to bed on time and get up on time
  - Those things move the needle greatly, but they’re hard
- We are all humans and we all tend to gravitate towards things that are easier
  - It’s easier to get a massage than to do a workout
- And so therefore it’s easier to pontificate on which style of massage is the best, when in reality, it doesn’t probably matter nearly as much as what you’re doing to get sore enough to need that massage in the first place

## Strategies for building and maintaining good habits [56:45]

- If anybody hasn’t listened to the podcast we did with James Clear on habits [[episode #183](https://peterattiamd.com/jamesclear/)], it’s great
  - We re-release it every New Year’s, and probably will continue to do so because it stands the test of time
- When patients come to Peter, not all of them have the proper habits in place

**How do you talk with people about habits?**

- Nick knows one example: if there’s junk food in your house, you’re probably going to eat it
  - It’s oftentimes easier to not have junk food in the house so you don’t have to have willpower over and over again

Peter shares, “*I’m really good at relating to half of it and I’m not great at relating to half of it, so I try to at least approach this through the lens of some humility with patients because I understand that exercise is probably a small addiction for me and there’s no effort required for me to exercise.*”

- There’s never a moment for Peter when he doesn’t feel like exercising but knows he’s got to do it
  - He always wants to do it
  - He never had to build habits around exercise
  - He knows that’s not true for everybody

***Peter’s best advice (having studied this and having seen what works and what doesn’t work) is to start very small and make the change the goal, not the outcome***

- This is consistent with what James and many others have written about
- If you’re taking a person who’s never exercised, the goal is to do something for 10 minutes a day
  - It doesn’t matter what it is, we’re not going to measure anything
  - If you don’t do anything, if I could get you to go out and do a walk for 10 minutes in the morning before you start your day, we’ve won the game
  - If a month later you’re still able to go out and do a 10 minute walk before you start your day, even though the training effect of that is zero (let’s be clear, that’s not exercise), it doesn’t matter
  - That’s how we **build the habit**, and then we go from there
- When it’s something like exercise, if this is a person who doesn’t love exercise, we’re not going for maximum effort, we’re not going for maximum pain

*We’re going to start by doing something that gives you a benefit on the way out*

- Peter does have patients who really dislike exercise, and so the goal with them is to make sure that they start to feel some benefit within a few months
- You don’t want this to just be blind faith that this is good for you
  - Even if they believe that, but it’s just you’re going to suffer for the next 60 years so that you can live a bit longer and do this more
  - That can’t be a strategy
- It also comes down to now tailoring the type of exercise to some extent to what they do

*On the subtractive habits, which is food*

- This is where Peter can really relate to the struggle

> “*Everything comes down to food environment or what I call default food environment. So the DFE is the most important variable in how you eat.*”‒ Peter Attia

- The more effort you put into meal preparation: if you just had every meal prepped for you, it gets a heck of a lot easier to eat the right thing
  - Peter doesn’t do this, although he keeps thinking about doing it
- The problem in his house is their pantry sucks, and it’s actually pretty funny
  - Peter asked his wife the other day, “*There’s a lot of crap in this pantry. Can we just get rid of it all?*”
  - He went into the pantry this morning, and all the crap was in the pantry, but now it was in a bin and it had a sticker on it labeled something like “*For school lunches only*.”
    - Like somehow that was going to stop him from eating it
    - He thought it was the funniest thing he ever saw
    - So not a good strategy, at least not for him
    - Peter needs the stuff to be actually gone
- A lot of times just having a **displacement of food** is valuable
  - The more good options he has, the less likely he is to eat crap
  - Because he’s probably not going to win the battle of not having Chex Mix in the house because his kids love Chex Mix
- The problem for Peter is he can’t eat a bag of Chex Mix, he eats 2

Peter explains, “*But if we have other things that I can eat that are right next to the Chex Mix, I can win that fight. The fight I struggle to win is there’s nothing in there that I want to eat or should eat, and it’s just crickets and Chex Mix I’m going to lose.*”

- Nick loves the fact of Peter’s wife just putting a box with a sticker on it that’s basically, “*Peter, do not touch.*”
  - It’s also the equivalent of in the gym, her seeing him struggle with a dead hang and be like, “*I just don’t get it. Why don’t you hang on longer? How hard is it?*”

## How to think about drugs and supplements as part of a longevity toolkit [1:02:00]

- There are different phenotypes of people
- Some people openly take every drug and supplement available
- Some people are like, “*I’ll take all the supplements in the world, I don’t want to take drugs*.”
- Some will take drugs but don’t want to take supplements
- And some will say I’ll do anything but take drug and supplements
- From a high level perspective, obviously not going into the details of each one, and as you’ve talked about, there’s some maybe that are beneficial (the “objective, strategy, tactics”)

**In general, how do you talk to patients about how they should think about drugs and supplements?**

- Peter finds the 3 extremes to be a bit odd
- 1 – Those who will take anything that’s a supplement but will never touch anything sold by a drug company
  - That’s the hardest one for Peter to wrap his head around because they’re basically saying, “*I’m really happy to trust companies that are totally unregulated to sell me something with dubious claims.*”
  - People who are highly regulated probably still make some dubious claims, but at least they have the foot of the government on their neck when they try to make them
- 2 – The group that says,  “*Lifestyle is the only thing that matters. You should never ever take a drug for anything and you can always fix your problems with your diet and exercise and sleep and mindfulness.*”
  - Peter can appreciate an aspect of that if he’s trying to be charitable to their point of view
  - He understands the rationale, which is we certainly have lots of evidence of people living long healthy lives without any reliance on pharmacotherapy
    - But that doesn’t necessarily mean that they couldn’t have lived longer or that doesn’t mean that you couldn’t live longer or better with the assistance of pharmacotherapy
  - It’s this absolutist view that he finds a bit difficult to reconcile, and it fails any test of logic once you probe
- 3 – The third camp would take every molecule that’s ever been created, and that’s going to be the panacea; but they’re not going to do this other stuff: exercise or care about how they sleep or eat or anything like that
  - There’s a version of this which is, “*I’m just telling you this is the best I can do.*” (and Peter can accept that)
  - There are others who think that all the molecules in the world will offset all of their poor choices in those other areas
    - This is one where the data just patently make clear that that’s not the case
- Peter doesn’t fit into any of those camps

> “*My view is hard problems require lots of tools.*”‒ Peter Attia

- If you want to build a picnic table, you don’t need many tools
- If you want to build a rocket ship, you need a lot of tool
- The question is, is trying to maximize your lifespan and health span more akin to building a picnic table or a rocket?
- Peter thinks it’s more akin to a rocket, and as such, he would like to have more tools at his disposal
- This doesn’t mean he will use every tool, but he certainly wants to know that as a general contractor, any single contractor or subcontractor tool, technique is at his disposal
- Whereas if he’s building a picnic table, that’s fine; he’ll just do it himself
  - He needs a saw and a hammer and some nails

## Peter’s recent reading list [1:05:15]

**What are some recent books that you have read, and what are some of “the greatest hits”?**

- The most recent books that Peter has read that he enjoyed greatly is Bill Maher’s book,, [*What This Comedian Said Will Shock You*](https://www.amazon.com/What-This-Comedian-Said-Shock/dp/1668051354/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.Wp-8AsMN5l81LpBbs_jeFbHKOnpDactM9dSr4JnWiG9MEQ0yCtwhAmmSPEAj4g48GqL5rgN1mc5ZbolJw6qYVVqkADgzJM7sVn0wEltcQ36oiBTIoCPZG0hXbzsnzOG40FfZH3_6fxIw7TAdWGXgN--v7POIKuPEgXbgyowFEND2pwXuN8aNzDVwdSt_bwhxc5OftDWhgcPL6W1-qAj6qyve9iVAx3dd_RSpH3aWrww.DixfyZEX6g-Oiw3Ux7Vg-csVVzdt_SiT2vNJelqaLPc&qid=1731001391&sr=8-1)
- It’s basically a collection of the last 20 years of his monologues at the end of the show, which are absolutely exceptional
- There’s a book called [*The Formula*](https://www.amazon.com/Formula-Rogues-Geniuses-Reengineered-Fastest-Growing/dp/0063318628/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.ZqY78yolcOCwmlpt5JXs0jvm4EqkbDJ7CMYvchFqhOtEapRhT6T17I5pBFh55cZlJ5CXUz30UfqMH7fll85WKL9mrZQRKGRdAAoRRf1FOXnEfirF-XLKz9IxNSR5yMmsdcj6BOdMl6gGRQ02ceEH10Ktl8M3PNbGYdUzcWYpvVbyXtkMNE91ZcTxRrveAJtVMxCpO2Gz4L4_nbEw27RF93x_HkvFa8gZ8e3PFFYlaO0.KGOwesEHFuIFTIDhyzCUzNLpSqdNeXLhU_Ppyum5_Tg&qid=1731002012&sr=8-1), and it’s about the history of Formula One
  - Peter doesn’t know how he missed it when it came out
  - It’s really funny
  - He went back and looked in his WhatsApp chat group (F1 chat group), and it was indeed recommended a year ago, and somehow he didn’t read it then
  - He assumed it was going to be too pedestrian to read for a diehard fan like him
  - But then he flagged it to the WhatsApp group and asked if anybody had read it and if it was worth the read…
  - To make a long story short, Peter read it and loved it
- He reads a lot of books for the podcast
- One that really stands out is [*In My Time of Dying*](https://www.amazon.com/My-Time-Dying-Came-Afterlife/dp/1668050838/ref=sr_1_1?crid=JUKLNR0X0OXU&dib=eyJ2IjoiMSJ9.t3dJWKptSgaYBmpzMf0EPeYzJdvzYYZQ-y2EDFZZl_R1DdCboL7y2MDq-V4E-P0UpbqtdNR8BR8zMEkDQbrGB_IE0Flxy4gUcxDUpwho1aAS4NRbeV1kVszDbNaA7qnNAOyS3dF17qhiHP92xjKHYnvLuF-EH8eknx2EWkwajE62TJiacFGe-4R8rjA51fgg0TxLzkt87tV9vLjGCK4lqMrrTGjQgKnR6RXEnLirrl0.hlhqvb8cyUd8cedi7WNwicvTr-Hn9f0nFO_G1zk9iZc&dib_tag=se&keywords=in+my+time+of+dying&qid=1731001901&sprefix=in+my+time+of+dying%2Caps%2C128&sr=8-1), which is a very short book by Sebastian Junger
  - He talked about this book on the podcast [[episode #315](https://peterattiamd.com/sebastianjunger2/)]

*There’s a genre of books that Peter’s obsessed with: historical, geopolitical, predictive pontificating*

- Peter Zeihan’s book, [*The Accidental Superpower*](https://www.amazon.com/Accidental-Superpower-Generation-American-Preeminence/dp/1455583669/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.IFGnGPo4XF5apUTjHG8u6nvGIyVK3tUIQMuGng52TsMb1v0Fkjd2_jzhtxelGCyPY9jXPccy5om4b2IEkQfJzN78zsvY_KIFtqzIa3hJJZE.UeCW0kYt4RPxTrQlgtNC5jsYyxOk3k6kXYJHath3ni4&qid=1731002373&sr=8-1)
  - This is a book that he wrote about a decade ago
- Then he wrote a follow-up to it [[*The Accidental Superpower: Ten Years On*](https://www.amazon.com/Accidental-Superpower-Generation-American-Preeminence/dp/1455583669/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.IFGnGPo4XF5apUTjHG8u6nvGIyVK3tUIQMuGng52TsMb1v0Fkjd2_jzhtxelGCyPY9jXPccy5om4b2IEkQfJzN78zsvY_KIFtqzIa3hJJZE.UeCW0kYt4RPxTrQlgtNC5jsYyxOk3k6kXYJHath3ni4&qid=1731002373&sr=8-1)], which is essentially the same book with an afterword to each chapter
  - If you are interested in geopolitics more than politics, this is a fascinating book
- Peter has read a lot of Peter’s books and he’s never met him
  - He’d love to meet him, Peter can just devour what he says
  - He has very interesting views, especially around the role between China and the US
  - And obviously he’s very bullish on the US and so maybe there’s a little bit of just needing to feel better about the situation we’re in
- Another similar book in that category is [*The Next 100 Years*](https://www.amazon.com/Next-100-Years-Forecast-Century/dp/038551705X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.OBe1HLslL6scyiwoUZ8RfK4bIwz-hHPT5jD7rczGlwzYWVPR8pOYRLkUi-yzovvDRAd2nOteF9bpfdcBD8vMYB6QC7eDPpolKNipWm44bQ0.muTKTCzU4EjkqBpCWt0mxia7hKrZVl0_9ks7c63CiVQ&qid=1731002742&sr=8-1) by George Friedman
  - That one is a little bit harder because it’s really stretching your imagination
  - George Friedman is a Hungarian-born political scientist who lives in Austin
  - Peter loves his stuff and got to have dinner with him a few months ago, which was incredible
- The books *The Accidental Superpower* and Peter’s most recent book [*The Accidental Superpower: Ten Years On*] are really talking more about what’s happening now and over the next decade
- Whereas what George is trying to do in *The Next 100 Years* is almost impossible, which is trying to predict what’s going to happen a hundred years out
  - By the way, that book was written more than a decade ago, and what’s very interesting is a couple of his predictions have already come absolutely clear
  - One being the invasion of Ukraine by Russia (that was very easily predicted by him 10 to 15 years ago)
- Another very interesting book that Peter read in the last 6 months was [*Blitzed*](https://www.amazon.com/Blitzed-Drugs-Third-Norman-Ohler/dp/1328663795/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.UaAMIYp2vsiNCDvfe0lxmFfA9UNmts0Gy_o-yhV1G6WIVZwuFVQI8sQb7CKzHHY14lsmQu7sJ225aQU2f6M99IozZ4Wst5rY9jLAJPy7wHkqZcZMfBVTkMY-c02C_tEUjd-juMQoolRu5idBGpahrjo3vVDGdQfcJU5Wp-YXOK-DWTPKHwyOVX-Kpb5hVITEIoKbS8AQhk5Td3Z1HIEPaXvDD1Oc_AQgg41eG58TX0Q.yu1Nq1_lbM72zmfNb8ZqEfc_V0F0DPjOouy2rlHlvDk&qid=1731003135&sr=8-1) by Norman Ohler
  - This is a book about the rampant use of stimulants by the Third Reich
  - Peter was very pleased to see that Joe Rogan had Norman on his podcast [[episode #2183](https://youtu.be/yUsJIcqwARk?si=_RG6iUnBA9V8_zhP)]
    - Peter had recommended the book to Joe over breakfast
- The last one is a book Peter probably read about 9 months ago called [*The Worst Hard Time*](https://www.amazon.com/Worst-Hard-Time-Survived-American/dp/061834697X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.01gv1t59d_g1a_-V6IowQYRD7A_zMvDuTP-4bUISPLZ_0k-Bp3Sucd44LnjquxaSS1TCrswf46oUCfMM_xXyTrkYskGJMPaSC3p21AEA8RF_1cVJtoZuAvhJZ5uBFlh9hymk0eSL2WYqyXKCyjkb0ScS3pqNPnTznrpISJNVtsDZatY1F0d17VXz6LP4Ugj-TCW8amgXq6AcjXkzfkXpnQsXjkPyfIfBEBS--mty1Ac.XCMUvZsvMUeIEeEsvtKdtj5WLKVbh0MbNgpaK0gcCfI&qid=1731008294&sr=8-1)
  - This is a book about the Great Depression and the Dust Bowl
  - Peter actually recommends this book to everybody
  - This is a great book to help you feel gratitude for being alive when you’re alive because you only needed to be alive a hundred years ago to live in a world that’s difficult to imagine
  - This is a book that takes place in the 1930s, so not even a hundred years ago
  - And if you think about people who lived right where we live right now in the middle of the country a hundred years ago, it’s an unimaginable world
    - 1 – Peter can’t believe people survived this
    - 2 – It’s hard to believe that on such a short time-scale, life could get so much better (which it has)

*The “greatest hits,” maybe not the most recent books*

- Peter would need more time to think about this
- What he can say is there are a handful of books that he keeps multiple copies of in the house, and he loves giving them to people
  - If somebody’s over for dinner and one of these topics comes up and they haven’t read the book, they’re just going to go home with a little gift bag of the book
- Bill Perkins book, [*Die With Zero*](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.HUNGjW6LkGMLKjGS3Fgr5w73_DS9T2pJS9vdRnrsmrLhd3oymQu6afg5FDXNK-vG9bEs1t3jW7E8rLcKdsRcgvg-4Nemzobm--P7bj6DsKi6kwOOYgnoT8ThP3uGnSe_qJp4OdBJrtULKfKLfF5dOTpBOkwZNmHZb7O0t_EliJatdZrYIKf2nsHQT-zj0i1dDY69cikolO1L5fZ4JOlkuz5GW1bSjF3g2yw_w72nAvA.SVGa--xOIE3M8Ap1pqkf_vgP8xRXgLsaUCSE-6Ze4ao&qid=1732041941&sr=1-1) [the subject of [episode #237](https://peterattiamd.com/billperkins/)]
- Arthur Brooks book on happiness [[*Build the Life You Want: The Art and Science of Getting Happier*](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.V5XWxX6lo5mQI9u-lLV55ClqePRVTg6x5eJND-hHWL8yjnEkEBE6saWNeB8zdvh64TTU1OOwt7T58r7Fzq7ES8f1kD_zLquzN1wTtMLL3cIuIaUHOCm0wMdH8I_CZCvYU8b4_cA2ahB27vw5BjA6AHG3SPEZGvXcES-gUUBnguDrHW7c50p_XD_0hTo5WaFt993vjE8Aq8pM5Wa1aPgET0pm9wekCNewY2iIEEpUQRk.htxE-_zrOWWVWrdrfcRbQlis_MxcdXDzFCiNiOU_EaE&qid=1732042022&sr=1-1); the subject of [episode #280](https://peterattiamd.com/arthurbrooks2/)]
- Michael Easter’s book, [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.aQfpYB2BuBM7-z8o_3dzfW2lxIfCMT9nMdh-93xOKIrttcpxNzLtXTzK7glR07SPpD_UH4e-HS3YPKRmkIXWwiVnXGBCK_1H34kgMq8VQ5B1ZqHFs_FXFiKrtZRp0AnF6j004cTYR0tXvdq4kwQqCwaP60hwxiBPDw1MCqt-K3Ocdafm4cfe_JgzGKfFxRrOCF_dvJmvum5uYNPEf-J4IY7GVrnVUvh1Xf6J4rusAg4.G3MUzF6MYvcp7DEHodAVsIoOYbZHcT6L45Z6EAmRJv8&qid=1732042113&sr=1-1) [the subject of [episode #225](https://peterattiamd.com/michaeleaster/)]
- Oliver Burkeman’s book, I think it’s called [*Four Thousand Weeks: Time Management for Mortals*](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/0374159122/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.2e1RiAVyclMJkGOzA0_LWly2mxhpsnyc9c3GUgoCok3YSGe57qpZdaOmASK3yG812mAQbhTQfdO3BLMPSPAg03nqD3beXjTlKkwpJ9AA0Hf7_Zh37_i4aiFIGOY5bvYia2CRdUCgyAGqIerz03SIrqi64pLevVtCFS3RjhoCnJ1WeVtmJG-_zy_TErFSQcI4rkYl4PD6AZDhVfOa10WRK4cmOhwuB05_w7GphmDtGF8.9v0055dGyz8DgzdAKCVkjHiFfaZhHM8HKLzaI96lxXA&qid=1732042160&sr=1-1) [the subject of [episode #265](https://peterattiamd.com/oliverburkeman/)]
- Ryan Holiday’s, [*Stillness Is The Key*](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.nAZWv5PRiAzfLfbbnynAIHo_QrZA4LL7L9Lthe0K_qP3UnzEyZxdfIbNhG7boKe7WyFOI7ESDTBEhBoF3BIj-G3902N73feHKjVMr7vU2oPL-P5BT0-5kNCHc77PJfPIm4Zm3-0C0QDvhLyUOW1XuwWn8y_vAiUzz5Dt9A5t5wPHmX7-tj1XH7TQHmkCvG4RocVZMYTf5r5mYU4Hz2smKjZb1reoViZE85ljmuHaKcE.JxOD8VOQbz3tmlk0e80iQgGsIZxga53r0dV8CzQGPZg&qid=1732042228&sr=1-1) [the subject of [episode #90](https://peterattiamd.com/ryanholiday/)]

Peter explains, “*These are just books I think everybody benefits from… People who think about life and think about meaning, I think they’re the books you could read every year and it’s probably not a bad idea to do so.*”

**Back to unhealthy snacking**

- Peter jokes that he might go and get some Chex Mix now
- Nick asks, “*You ever mix Chex Mix and Cheez-Its together?*”
- Yeah, they’re in the same stupid bin
- It’s the little pre-packaged, little school lunch bags of Chex Mix, Cheez-Its, Doritos
- All of this ridiculous good tasting garbage that should never be made
  - It’s like zero purpose for this stuff to exist in the human food supply
- Luckily, his kids won’t even finish a bag (they’re normal, but he’s a pig)

**It didn’t come up in the books, but there’s a quote Nick knows Peter is a fan of, “*****Ocean waves, birds and shit, waterfalls, thunder, all that shit*****.”** That is prime [David Goggins](https://davidgoggins.com/about/) [[Instagram post](https://www.instagram.com/tv/CbVlOFZLFH8/?igshid=MDJmNzVkMjY%3D)] right there

---

## Selected Links / Related Material

**Chris Williamson’s podcast with Peter**: [Master Your Health: Build Muscle, Boost Mood, Sleep Better – Dr Peter Attia (4K)](https://youtu.be/_hi8qOZB2qU?si=qFDCrEWVeiRLxIrQ) | Chris Williamson (April 15, 2024) | [23:30]

**Newsletter on why HbA1c is misleading**: [Assessing metabolic health: where HbA1c falls short, and how it compares to fasting glucose, CGM, and OGTT](https://peterattiamd.com/problems-with-hba1c/) | PeterAttiaMD.com (S Lipman, K Birkenbach, P Attia, 2024) | [26:15]

**Study blocking interleukin 11**: [Inhibition of IL-11 signalling extends mammalian healthspan and lifespan](https://pubmed.ncbi.nlm.nih.gov/39020175/) | *Nature* (A Widjaja et al 2024) | [31:15]

**Newsletter on IL-11 as a longevity target**: [Is interleukin-11 a promising new target for lifespan-extending interventions?](https://peterattiamd.com/interleukin-11-and-lifespan/) | PeterAttiaMD.com (K Birkenbach, P Attia, 2024) | [32:45]

**Episode of** ***The Drive*** **about klotho**: [#303 – A breakthrough in Alzheimer’s disease: the promising potential of klotho for brain health, cognitive decline, and as a therapeutic tool for Alzheimer’s disease | Dena Dubal, M.D., Ph.D.](https://peterattiamd.com/denadubal/) (May 27, 2024) | [34:00]

**Episode of** ***The Drive*** **which discussed the use of Yamanaka factors to convert a cell to a stem cell**: [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/) (September 12, 2022) | [40:30]

**Biotech focused on epigenetic medicine**: [Moonwalk Biosciences](https://moonwalk.bio/) (2024) | [47:45]

**Episode of** ***The Drive*** **focused on the centenarian decathlon**: [#261 ‒ Training for The Centenarian Decathlon: zone 2, VO2 max, stability, and strength | Peter Attia, M.D.](https://peterattiamd.com/training-for-the-centenarian-decathlon/) (July 10, 2023) | [54:00]

**Episode of** ***The Drive*** **about habits**: [#183 – James Clear: Building & Changing Habits](https://peterattiamd.com/jamesclear/) (November 8, 2021) | [56:45]

**Peter’s book recommendations**: [1:05:45]

- [What This Comedian Said Will Shock You](https://www.amazon.com/What-This-Comedian-Said-Shock/dp/1668051354/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.Wp-8AsMN5l81LpBbs_jeFbHKOnpDactM9dSr4JnWiG9MEQ0yCtwhAmmSPEAj4g48GqL5rgN1mc5ZbolJw6qYVVqkADgzJM7sVn0wEltcQ36oiBTIoCPZG0hXbzsnzOG40FfZH3_6fxIw7TAdWGXgN--v7POIKuPEgXbgyowFEND2pwXuN8aNzDVwdSt_bwhxc5OftDWhgcPL6W1-qAj6qyve9iVAx3dd_RSpH3aWrww.DixfyZEX6g-Oiw3Ux7Vg-csVVzdt_SiT2vNJelqaLPc&qid=1731001391&sr=8-1) by Bill Maher (2024)
- [The Formula: How Rogues, Geniuses, and Speed Freaks Reengineered F1 into the World’s Fastest-Growing Sport](https://www.amazon.com/Formula-Rogues-Geniuses-Reengineered-Fastest-Growing/dp/0063318628/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.ZqY78yolcOCwmlpt5JXs0jvm4EqkbDJ7CMYvchFqhOtEapRhT6T17I5pBFh55cZlJ5CXUz30UfqMH7fll85WKL9mrZQRKGRdAAoRRf1FOXnEfirF-XLKz9IxNSR5yMmsdcj6BOdMl6gGRQ02ceEH10Ktl8M3PNbGYdUzcWYpvVbyXtkMNE91ZcTxRrveAJtVMxCpO2Gz4L4_nbEw27RF93x_HkvFa8gZ8e3PFFYlaO0.KGOwesEHFuIFTIDhyzCUzNLpSqdNeXLhU_Ppyum5_Tg&qid=1731002012&sr=8-1) by Joshua Robinson and Jonathan Clegg (2024)
- [In My Time of Dying: How I Came Face to Face with the Idea of an Afterlife](https://www.amazon.com/My-Time-Dying-Came-Afterlife/dp/1668050838/ref=sr_1_1?crid=JUKLNR0X0OXU&dib=eyJ2IjoiMSJ9.t3dJWKptSgaYBmpzMf0EPeYzJdvzYYZQ-y2EDFZZl_R1DdCboL7y2MDq-V4E-P0UpbqtdNR8BR8zMEkDQbrGB_IE0Flxy4gUcxDUpwho1aAS4NRbeV1kVszDbNaA7qnNAOyS3dF17qhiHP92xjKHYnvLuF-EH8eknx2EWkwajE62TJiacFGe-4R8rjA51fgg0TxLzkt87tV9vLjGCK4lqMrrTGjQgKnR6RXEnLirrl0.hlhqvb8cyUd8cedi7WNwicvTr-Hn9f0nFO_G1zk9iZc&dib_tag=se&keywords=in+my+time+of+dying&qid=1731001901&sprefix=in+my+time+of+dying%2Caps%2C128&sr=8-1) by Sebaastian Junger (2024)
- [The Accidental Superpower: The Next Generation of American Preeminence and the Coming Global Disorder](https://www.amazon.com/Accidental-Superpower-Generation-American-Preeminence/dp/1455583669/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.IFGnGPo4XF5apUTjHG8u6nvGIyVK3tUIQMuGng52TsMb1v0Fkjd2_jzhtxelGCyPY9jXPccy5om4b2IEkQfJzN78zsvY_KIFtqzIa3hJJZE.UeCW0kYt4RPxTrQlgtNC5jsYyxOk3k6kXYJHath3ni4&qid=1731002373&sr=8-1) by Peter Zeihan (2014)
- [The Accidental Superpower: Ten Years On](https://www.amazon.com/Accidental-Superpower-Ten-Years/dp/1538767341/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.IFGnGPo4XF5apUTjHG8u6nvGIyVK3tUIQMuGng52TsMb1v0Fkjd2_jzhtxelGCyPY9jXPccy5om4b2IEkQfJzN78zsvY_KIFtqzIa3hJJZE.UeCW0kYt4RPxTrQlgtNC5jsYyxOk3k6kXYJHath3ni4&qid=1731002373&sr=8-1) by Peter Zeihan (2023)
- [The Next 100 Years](https://www.amazon.com/Next-100-Years-Forecast-Century/dp/038551705X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.OBe1HLslL6scyiwoUZ8RfK4bIwz-hHPT5jD7rczGlwzYWVPR8pOYRLkUi-yzovvDRAd2nOteF9bpfdcBD8vMYB6QC7eDPpolKNipWm44bQ0.muTKTCzU4EjkqBpCWt0mxia7hKrZVl0_9ks7c63CiVQ&qid=1731002742&sr=8-1) by George Friedman (2009)
- [Blitzed](https://www.amazon.com/Blitzed-Drugs-Third-Norman-Ohler/dp/1328663795/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.UaAMIYp2vsiNCDvfe0lxmFfA9UNmts0Gy_o-yhV1G6WIVZwuFVQI8sQb7CKzHHY14lsmQu7sJ225aQU2f6M99IozZ4Wst5rY9jLAJPy7wHkqZcZMfBVTkMY-c02C_tEUjd-juMQoolRu5idBGpahrjo3vVDGdQfcJU5Wp-YXOK-DWTPKHwyOVX-Kpb5hVITEIoKbS8AQhk5Td3Z1HIEPaXvDD1Oc_AQgg41eG58TX0Q.yu1Nq1_lbM72zmfNb8ZqEfc_V0F0DPjOouy2rlHlvDk&qid=1731003135&sr=8-1) by Norman Ohler (2017)
- [The Worst Hard Time: The Untold Story of Those Who Survived the Great American Dust Bowl](https://www.amazon.com/Worst-Hard-Time-Survived-American/dp/061834697X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.01gv1t59d_g1a_-V6IowQYRD7A_zMvDuTP-4bUISPLZ_0k-Bp3Sucd44LnjquxaSS1TCrswf46oUCfMM_xXyTrkYskGJMPaSC3p21AEA8RF_1cVJtoZuAvhJZ5uBFlh9hymk0eSL2WYqyXKCyjkb0ScS3pqNPnTznrpISJNVtsDZatY1F0d17VXz6LP4Ugj-TCW8amgXq6AcjXkzfkXpnQsXjkPyfIfBEBS--mty1Ac.XCMUvZsvMUeIEeEsvtKdtj5WLKVbh0MbNgpaK0gcCfI&qid=1731008294&sr=8-1) by Timothy Egan (2005)

**Episode of** ***The Drive*** **about the book** ***In My Time of Dying***: [#315 ‒ Life after near-death: a new perspective on living, dying, and the afterlife | Sebastian Junger](https://peterattiamd.com/sebastianjunger2/) (August 26, 2024) | [1:06:45]

**Episode of Joe Rogan with Norman Ohler**: [Joe Rogan Experience #2183 – Norman Ohler](https://youtu.be/yUsJIcqwARk?si=_RG6iUnBA9V8_zhP) (August 1, 2024) | [1:08:45]

**Books Peter keeps on hand to give away**: [1:10:15]

- [Die With Zero](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.HUNGjW6LkGMLKjGS3Fgr5w73_DS9T2pJS9vdRnrsmrLhd3oymQu6afg5FDXNK-vG9bEs1t3jW7E8rLcKdsRcgvg-4Nemzobm--P7bj6DsKi6kwOOYgnoT8ThP3uGnSe_qJp4OdBJrtULKfKLfF5dOTpBOkwZNmHZb7O0t_EliJatdZrYIKf2nsHQT-zj0i1dDY69cikolO1L5fZ4JOlkuz5GW1bSjF3g2yw_w72nAvA.SVGa--xOIE3M8Ap1pqkf_vgP8xRXgLsaUCSE-6Ze4ao&qid=1732041941&sr=1-1) by Bill Perkins (2020)
- [Build the Life You Want: The Art and Science of Getting Happier](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.V5XWxX6lo5mQI9u-lLV55ClqePRVTg6x5eJND-hHWL8yjnEkEBE6saWNeB8zdvh64TTU1OOwt7T58r7Fzq7ES8f1kD_zLquzN1wTtMLL3cIuIaUHOCm0wMdH8I_CZCvYU8b4_cA2ahB27vw5BjA6AHG3SPEZGvXcES-gUUBnguDrHW7c50p_XD_0hTo5WaFt993vjE8Aq8pM5Wa1aPgET0pm9wekCNewY2iIEEpUQRk.htxE-_zrOWWVWrdrfcRbQlis_MxcdXDzFCiNiOU_EaE&qid=1732042022&sr=1-1) by Arthur Brooks and Oprah Winfrey (2023)
- [The Comfort Crisis](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.aQfpYB2BuBM7-z8o_3dzfW2lxIfCMT9nMdh-93xOKIrttcpxNzLtXTzK7glR07SPpD_UH4e-HS3YPKRmkIXWwiVnXGBCK_1H34kgMq8VQ5B1ZqHFs_FXFiKrtZRp0AnF6j004cTYR0tXvdq4kwQqCwaP60hwxiBPDw1MCqt-K3Ocdafm4cfe_JgzGKfFxRrOCF_dvJmvum5uYNPEf-J4IY7GVrnVUvh1Xf6J4rusAg4.G3MUzF6MYvcp7DEHodAVsIoOYbZHcT6L45Z6EAmRJv8&qid=1732042113&sr=1-1) by Michael Easter
- [Four Thousand Weeks: Time Management for Mortals](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/0374159122/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.2e1RiAVyclMJkGOzA0_LWly2mxhpsnyc9c3GUgoCok3YSGe57qpZdaOmASK3yG812mAQbhTQfdO3BLMPSPAg03nqD3beXjTlKkwpJ9AA0Hf7_Zh37_i4aiFIGOY5bvYia2CRdUCgyAGqIerz03SIrqi64pLevVtCFS3RjhoCnJ1WeVtmJG-_zy_TErFSQcI4rkYl4PD6AZDhVfOa10WRK4cmOhwuB05_w7GphmDtGF8.9v0055dGyz8DgzdAKCVkjHiFfaZhHM8HKLzaI96lxXA&qid=1732042160&sr=1-1) by Oliver Burkeman (2021)
- [Stillness Is The Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.nAZWv5PRiAzfLfbbnynAIHo_QrZA4LL7L9Lthe0K_qP3UnzEyZxdfIbNhG7boKe7WyFOI7ESDTBEhBoF3BIj-G3902N73feHKjVMr7vU2oPL-P5BT0-5kNCHc77PJfPIm4Zm3-0C0QDvhLyUOW1XuwWn8y_vAiUzz5Dt9A5t5wPHmX7-tj1XH7TQHmkCvG4RocVZMYTf5r5mYU4Hz2smKjZb1reoViZE85ljmuHaKcE.JxOD8VOQbz3tmlk0e80iQgGsIZxga53r0dV8CzQGPZg&qid=1732042228&sr=1-1) by Ryan Holiday (2019)

---

## People Mentioned

[Richard Isaacson](https://ind.org/about#team) (Preventive Neurologist at the Institute for Neurodegenerative Diseases. He is a Harvard-trained neurologist who founded and directed the first Alzheimer’s Prevention Clinic in the U.S. in 2013 at Weill Cornell Medicine/NewYork-Presbyterian) [25:15]