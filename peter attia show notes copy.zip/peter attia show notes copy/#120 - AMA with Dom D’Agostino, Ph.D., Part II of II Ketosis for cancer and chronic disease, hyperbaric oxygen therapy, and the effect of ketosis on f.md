# #120 – AMA with Dom D’Agostino, Ph.D., Part II of II: Ketosis for cancer and chronic disease, hyperbaric oxygen therapy, and the effect of ketosis on female health

**Source:** [https://peterattiamd.com/domdagostinoama02/](https://peterattiamd.com/domdagostinoama02/)

---

##### Check out more content with Dom D’Agostino:

- *(July 16, 2018)* [Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer](/domdagostino/)
- *(June 22, 2020)* [AMA with Dom D’Agostino, Ph.D., Part I of II: Ketogenic diet, exogenous ketones, and exercise](/domdagostinoama01/)
- *(July 20, 2020)* [AMA with Dom D’Agostino, Ph.D., Part II of II: Ketosis for cancer and chronic disease, hyperbaric oxygen therapy, and the effect of ketosis on female health](/domdagostinoama02/)

In part 2 of this special AMA episode, [ketosis](/ketosis-advantaged-or-misunderstood-state-part-i/) expert Dom D’Agostino once again joins Bob Kaplan, Peter’s Head of Research, to discuss the impact of ketosis on various chronic diseases as well as the latest research on the metabolic management of cancer. Dom also discusses the numerous applications of hyperbaric oxygen therapy, provides insights into the application of ketosis on female health and performance, and much more. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA.  If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on the website [show notes page](https://peterattiamd.com/domdagostinoama02/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Update on Dom’s Press-pulse therapeutic strategy for the metabolic management of cancer [2:05];
- Potential role for vitamin C in cancer treatment [12:45];
- Glutamine targeting in cancer therapy—evidence that the mitochondria in cancer are damaged? [17:45];
- Can a ketogenic diet lessen the toxicity of cancer therapies? [24:45];
- 3BP—a promising agent in cancer therapy [26:45];
- The relationship between cancer and ketogenic diets [29:30];
- Hyperbaric oxygen therapy (HBOT)—primer, protocols, and therapeutic uses [33:30];
- Is there a potential role for HBOT in treating COVID-19 patients? [44:15];
- Non-cancer applications of HBOT [47:30];
- The inverse relationship between glucose and ketones [50:30];
- Is a ketogenic diet appropriate for type 1 diabetics? [54:00];
- How ketosis may reduce the risk for Alzheimer’s disease and Parkinson’s disease [1:00:30];
- Ketosis for females—considerations, fertility, performance, and the latest research [1:11:00];
- Low-carb diets during pregnancy and postpartum [1:17:00];
- A high-protein diet to counteract common hormonal issues associated with the ketogenic diet [1:21:15];
- Nutritional tips for remaining metabolically flexible [1:22:45];
- What is one belief Dom has changed his mind about? [1:26:45];
- In utero experiments, and other interesting questions Dom wants to explore [1:29:45];
- The anti-catabolic effect of ketones, cancer cachexia, and nutritional interventions for cancer patients [1:38:30];
- What is the one interesting experiment Dom would do if money and time were no barrier? [1:46:25]; and
- More.

§

The Peter Attia Drive

Part II of II: Ketosis for cancer and chronic disease and the effect of ketosis on female health

§

## Show Notes

## Update on Dom’s Press-pulse therapeutic strategy for the metabolic management of cancer [2:05]

**Dom’s Press-Pulse paper with Tom Seyfried from 2017**: [Press-pulse: a novel therapeutic strategy for the metabolic management of cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2)

- Dom discussed this paper on his [first appearance on The Drive podcast](https://peterattiamd.com/domdagostino/)
- [Tom Seyfried](https://www.bc.edu/bc-web/schools/mcas/departments/biology/people/faculty-directory/thomas-seyfried.html) has also [previously discussed](https://peterattiamd.com/tomseyfried/) the Press-Pulse approach with Peter

**The press-pulse concept**

- It’s the idea of using ketone metabolic therapy (or therapeutic ketosis) and other modalities to compromise tumor growth and proliferation
- This weakens the tumor making it more susceptible to be killed by other modalities

⇒ Example, the **ketogenic diet combined with hyperbaric oxygen therapy** (HBOT)

- Being in a state of therapeutic ketosis…
  - Suppresses insulin signaling, which drives PI-3 kinase, lowers glucose availability to the tumor,
  - It elevates ketone bodies which can not be readily utilized by most cancers as a source of fuel
  - Ketones also impair antioxidant pathways that the tumors use to defend itself (e.g., the pentose phosphate pathway generates more glutathione in cancer cells and that is being fed by glucose)
- \***In summary**—if you reduce glucose availability and inhibit insulin, which suppresses glycolysis, you’re creating a scenario where **if you give an oxidative challenge with hyperbaric oxygen therapy, you can potentially kill the cancer cells**

**The ketogenic diet and hyperbaric oxygen therapy prolong survival in mice with systemic metastatic cancer** [Poff et al., 2013](https://pubmed.ncbi.nlm.nih.gov/23755243/)

- In 2013, [Dr. Angela Poff](https://u.osu.edu/ketodiet/speaker-bios/angela-poff-phd/) studied the ketogenic diet with hyperbaric oxygen
- Hyperbaric oxygen was delivered at 2.5 atmospheres of oxygen, 90 minutes, 3 times per week
- The ketogenic diet combined with the hyperbaric oxygen protocol proved to decrease tumor burden and extend the lifespan in VM-M3 mouse model (developed by [Thomas Seyfried](https://www.bc.edu/bc-web/schools/mcas/departments/biology/people/faculty-directory/thomas-seyfried.html))

Tom Seyfriend’s paper: [The glucose ketone index calculator: a simple tool to monitor therapeutic efficacy for metabolic management of brain cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-015-0009-2)

- Supports the idea that a lower the glucose-ketone (ideally in the 1 to 2 range) slows tumor growth and proliferation and makes it more vulnerable to HBOT

**Many different things that you can combine in press-pulse therapy**

- A weakened tumor from therapeutic ketosis may be more vulnerable to a number of other cancer specific metabolic drugs—
  - PI3K inhibitors (see [Lew Cantley episode](https://peterattiamd.com/lewcantley/) of The Drive)
  - 2-Deoxy-d-glucose—which inhibits hexokinase and inhibits glycolysis
  - 3-Bromopyruvate (3BP)
  - Dichloroacetate (DCA)
  - Metformin
  - Vitamin C at high doses
    - Dom and team has done in vitro [experiments](https://cdn.technologynetworks.com/ep/pdfs/pharmacological-ascorbic-acid-and-hyperbaric-oxygen-therapy-target-tumor-cell-metabolism-via-an.pdf) with high doses of vitamin C—presented by [Janine Deblasi, now PhD student researcher](https://www.linkedin.com/in/janine-deblasi-39857a101/),
  - SGLT2 inhibitors

Dom’s [2017 review](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2) was more of a preclinical concept, but now there are a number of relevant papers coming out—

- Valter Longo’s [mouse study](https://www.nature.com/articles/s41467-020-16243-3) showed a remarkable effect using a nontoxic combination of a fasting-mimicking-diet (FMD) with IV vitamin C against KRAS mutated cancers
- Another [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7227442/) showed a decrease in tumor burden in a woman with metastatic thymoma treated with a ketogenic diet and fasting combined with prednisone and other immune based therapies

![](https://peterattiamd.com/wp-content/uploads/2020/07/fig-1.-lung-cancer-imaging-Phillips-et-al.-2020-847x1024.png)

**Figure 1. PET image showing decrease in tumor burden in a woman with metastatic thymoma treated with a ketogenic diet and fasting combined with prednisone and other immune based therapies.** Image credit: [Phillips et al., 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7227442/)

- Tom Seyfried also has been a coauthor on several case studies such as a person with—
  - [triple negative breast cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5589510/) and
  - Somebody with [glioblastoma](https://www.nature.com/articles/s42003-019-0455-x)

## Potential role for vitamin C in cancer treatment [12:45]

**Vitamin C as a PRO-oxidant?**

- Most people think of vitamin C as an antioxidant
- But high concentrations of vitamin C can be a prooxidant–making it relevant in cancer treatment

**Adding HBOT during radiation**

- Radiation therapy kills cancer cells by 80 to 90% just through reactive oxygen species (ROS) generation because they are toxic tumor cells
- The efficacy of radiation therapy is directly proportional to the pO2 of the tumor—so if you oxygenate the tumor and then radiate it there is a greater burst of intr-tumor ROS
- Tumors tend to grow and outstrip their blood supply, so they’re hypoxic, making them resistant to radiation
- So adding HBOT **during** radiation would dramatically sensitize it

*What about HBOT* ***before*** *or* ***after*** *radiation therapy?*

- After having hyperbaric oxygen therapy, you’ll have a residual elevation of reactive oxygen species for hours after
- And it’ll be somewhat site-specific increase in reactive oxygen species, because various mitochondrial abnormalities
  - There’s a debate whether the mitochondria are damaged or they are not damaged
  - Dom is 100% certain that the mitochondria are at least **dysregulated** in a way that they overproduce reactive oxygen species in response to an elevation of the pO2 of the tissue
  - This occurs because there’s defects in the mitochondrial electron transport chain
  - There’s a lot of free [heme](https://en.wikipedia.org/wiki/Heme) available—free iron that’s available drives the [Fenton reaction](https://en.wikipedia.org/wiki/Fenton%27s_reagent)
  - The Fenton reaction is when you have a lot of free iron, it drives the production of [hydroxyl radical](https://en.wikipedia.org/wiki/Hydroxyl_radical)—a super reactive oxygen species—and that can kill cancer cells very dramatically
- So the combination of hyperbaric oxygen therapy, IV vitamin C, and radiation (or even without radiation) can be a **potent prooxidant therapy**

**The double benefit of vitamin C**

- [Dehydroascorbic acid](https://en.wikipedia.org/wiki/Dehydroascorbic_acid)—the oxidized form of vitamin C—uses the glucose transporter to get inside cells
- So if you elevate this form of vitamin C into millimolar concentrations in the blood using an IV, it functions as a glucose antagonist to the point where you may have hypoglycemic symptoms
- So you are delivering a glucose antagonist that’s also dramatically increasing reactive oxygen species in cancer cells because tumors have a lot of free heme (iron)

> “[Vitamin C is] a really important component now, we think, to the press-pulse concept of cancer management.”

## Glutamine targeting in cancer therapy—evidence that the mitochondria in cancer are damaged? [17:45]

- Literature [suggests](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2917518/#:~:text=Cancer%20cells%20can%20be%20addicted%20to%20glutamine,-The%20advent%20of&text=First%2C%20several%20oncogenes%20and%20tumor,metabolism%20%5B4%E2%80%937%5D.) that tumor cells can be “addicted” to glutamine (i.e., mitochondrial substrate level phosphorylation with glutamine)
- Tom Seyfried has [experimented](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6541653/) with combining calorie-restricted ketogenic diet and **glutamine targeting** in late-stage experimental glioblastoma
  - He is using his VM-M3 glioblastoma mice (glioblastoma that has metastasized)
  - “It is the most deadly animal model of cancer that I know about, and so it makes it kind of a fantastic model system to study.” says Dom
  - Dom published a [paper](https://onlinelibrary.wiley.com/doi/full/10.1002/jcsm.12554) with Andrew Koutnik which demonstrated that the VM-M3 mouse model is a superior model to study cancer metastasis and cachexia

In Tom’s [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6541653/)—

- He combined a **calorie-restricted ketogenic diet** with [**6-diazo-5-oxo-L-norleucine**](https://en.wikipedia.org/wiki/6-Diazo-5-oxo-L-norleucine) **(DON)**— a glutamine antagonist/inhibitor
- All the mice on that protocol survived out to 40 days
- The other mice on a standard diet, or on a ketogenic diet with DON had ALL died

![](https://peterattiamd.com/wp-content/uploads/2020/07/fig-2.-Mukherjee-et-al.-2019-1024x581.png)

**Figure 2. The log-rank statistical analysis test showed a significant difference between groups in this survival study. SD-UR=standard chow diet unrestricted; KD-R=ketogenic diet in restricted amounts to reduce body weight by about 15%; DON=0.1–1.0 mg/kg of 6-diazo-5-oxo-L-norleucine.** Image credit: [Mukherjee et al., 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6541653/)

*Is this evidence that the mitochondria are, in fact, “damaged” in cancer cells?*

- Speculating what Tom Seyfried would think…
  - Cancer cells may appear to have “normal” mitochondria in that it’s consuming oxygen
  - But Tom is arguing is that yes, it may be taking in oxygen, but it’s not producing ATP via OXPHOS—it may be that the tumor is not just getting energy from the Warburg effect or aerobic fermentation, but it also might be **fermentation of glutamine** (part of his [hypothesis of cancer as a mitochondrial metabolic disease](https://peterattiamd.com/tomseyfried/))
- Dom’s take:
  - There’s more likely to be a “happy medium” in terms of the spectrum of normal-to-damaged mitochondria
  - Mitochondria are transformed in ways to help a tumor expand it’s biomass—
    - Glycolysis is elevated tremendously
    - Glutaminolysis is elevated and serves as a fuel and anabolic precursor
    - ATP generation is elevated to to fuel anabolic processes
  - In terms of using DON…
    - Dom says it’s a great strategy in theory, but DON is toxic
    - “*We need to come up with better molecules that could reduce glutamine levels in the blood and tissue and also just function as a glutamine antagonist.*”

## Can a ketogenic diet lessen the toxicity of cancer therapies? [24:45]

- Tom Seyfried mentioned in his [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6541653/) that there was less toxicity associated with giving DON when the mice were on a ketogenic diet when compared to a standard diet

*Are there other instances where the ketogenic diet can lessen toxicity of cancer therapies?*

- Starting a ketogenic diet (especially calorie-restricted) “sets the stage” for cancer therapies to work—
  - suppression of insulin signaling,
  - decreasing glucose availability,
  - limiting glutamine availability

- - Lowering of many of the amino acids and associated anabolic signals that can drive tumor growth

- - You do all that and cripple antioxidant defenses by reducing pentose phosphate pathway activity

It’s possible to “set the stage” nicely for an oxidative stress stimulus that could kill the cancer — therapies like:

- A drug therapy — with PI 3-kinase drug, you get results, but it’s nothing like if you start the diet a week or two before
- Hyperbaric oxygen

- IV vitamin C (functions as a pro-oxidant)

- Chemotherapy—which is a form of metabolic therapy, since you’re inhibiting the formation of molecules and crippling the mitochondria to some extent and their ability to make ATP
- Radiation (kills cancer primarily through  oxidative stress)
- IV vitamin C hyperbaric oxygen, and, of course, radiation and chemo (combined)
- Many chemotherapeutic agents kill cancer cells through a redox mechanism…
  - Metformin, for example, has anticancer effects which are linked mitochondrial dysfunction and ROS production

## 3BP—a promising agent in cancer therapy [26:45]

Book recommendation: [Tripping Over the Truth](https://www.amazon.com/dp/160358935X/ref=dp-kindle-redirect?_encoding=UTF8&btkr=1) by Travis Christofferson

- This book talks about the use of [3BP](https://pubmed.ncbi.nlm.nih.gov/22382780/) alongside [2-DG](https://en.wikipedia.org/wiki/2-Deoxy-D-glucose) in cancer therapy
- Dom calls 3BP—a hexokinase-2 inhibitor—an enormously promising agent
- Detractors will says that 2-DG is cardiotoxic—which is true at high enough doses—but it also seems to have anticancer effects
- Dom’s understanding is that for 3BP to have an anticancer effect and also to be nontoxic, it needs to be delivered in a very specific way, ideally site-specific in a liposomal preparation
- But the waters have been muddied with a lot of competing interests and legal disputes (more about this in the [book](https://www.amazon.com/dp/160358935X/ref=dp-kindle-redirect?_encoding=UTF8&btkr=1))
- Dom would love to include 3BP in his experiments in the future under the mentorship of [Dr. Young Ko](https://www.kodiscovery.org/)
- He’s hopeful that clinical trials will start and more animal research will indicate the best way to use these compounds

## The relationship between cancer and ketogenic diets [29:30]

Suggested literature on this topic:

- **Comprehensive review on Keto Diet and Cancer** : [Ketogenic diet in the treatment of cancer – Where do we stand?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7056920/)
- **Ketogenic Diet and Drug Synergy under investigation:** [A 2-Week Ketogenic Diet in Combination With Letrozole to Modulate PI3K Signaling in ER+ Breast Cancer (Vanderbilt)](https://clinicaltrials.gov/ct2/show/NCT03962647?term=ketogenic&cond=cancer&draw=2&rank=1)

**The latest**

- 10 years ago, there was very little on clinicaltrials.gov
- Now there’s about 40 preclinical trials (animals and humans) on clinicaltrials.gov
- Some of the most [promising work is with Lew Cantley](https://peterattiamd.com/lewcantley/), using a diet plus drug combination

**What types of cancers are most responsive to a ketogenic diet?**

Many cancers have a metabolic cause—

- Ovarian
- Endometrial
- Breast cancer
- GI cancers especially
- Liver
- Gallbladder
- Colon
- Stomach
- Esophagus

\*Dom points out that pretty much all cancers grow in part through the activation PI3 kinase being driven by insulin

- A [Nature Communications paper](https://www.nature.com/articles/s41467-020-16243-3) showed that even the KRAS mutation (previously thought not to be responsive to a ketogenic diet) might actually be responsive to a keto diet—KRAS mutations associated with different lung cancers, pancreas, and colon cancer did respond

**Are there any situations where the ketogenic diet would fuel tumor growth?**

- A recent [paper](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(16)30643-X) that came out suggesting dietary fat intake might promote the growth of melanoma tumors harboring BRAF V600E mutations
- Tuberous sclerosis complex is another tricky type cancer where has either no effect or maybe even a pro tumor effect
- Blood cancers (e.g., lymphoma)—the ketogenic diet may not be right choice
  - There are blood cancer exceptions, such as [AML](https://en.wikipedia.org/wiki/Acute_myeloid_leukemia)—Lew Cantley [showed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6197057/) that the ketogenic diet with the PI3 kinase inhibitor may be responsive in the context of insulin suppression (with ketogenic diet) combined with PI3K inhibition

“*So, you have a lot of things going on with the ketogenic diet across different cancer types.*” says Dom

## Hyperbaric oxygen therapy (HBOT)—primer, protocols, and therapeutic uses [33:30]

**What HBOT protocol did Dom use for cancer research?**

Using info from the existing literature and preclinical animal models, they used the following protocol with the goal of killing a tumor—

- 2.5 atmospheres of oxygen
  - Tumors have aberrant blood vessel formation and the blood vessels are small
  - So you really need to hyper-oxygenate the plasma for the oxygen to get into all the nooks and crannies of the tumor
  - In order to do that you have to increase the [barometric pressure](https://en.wikipedia.org/wiki/Atmospheric_pressure)
- 60-90 minutes
- 3 times per week
  - Instead of doing it five days continuously—which they would use for wound healing—you need a break to allow adaptation and recovery from the high dose of oxygen before you hit it again
- Dom hasn’t done the experiment yet, but he thinks it would be best to combine that with IV vitamin C and some other drugs as well

**A primer on atmospheric pressure**

- At sea level, 20% of the air that you’re breathing is oxygen—so that’s **0.2 atmospheres absolute oxygen**
- If you’re breathing 100% oxygen off a mask in a room filled completely with oxygen, that would be 1.0 ATA
- Every atmosphere is like 33 feet of seawater or 10 meters… so 2.5 atmospheres would be 15 meters
- Once the [hemoglobin](https://en.wikipedia.org/wiki/Hemoglobin) is saturated, the increase in **barometric pressure pushes the oxygen into the blood and into the tissues**

–*This is important in the context of scuba diving…*

- A standard scuba diver is breathing a tank of compressed air with a mix similar to regular air (i.e., 20% oxygen)
  - You would get to 1.0 atmosphere of oxygen if you were to dive down to a max of 132 feet of sea water (20% x 5 atmospheres of air = 1.0 atmosphere of oxygen)
- There is also [nitrox](https://en.wikipedia.org/wiki/Nitrox) which is a higher percentage of oxygen used in deeper, longer dives
- The Navy Seals use rebreathers with 100% oxygen which allows for no bubbles to be more stealthy
  - But if you’re breathing 100% and you dive down to 132 feet seawater, five atmospheres, the potential for a seizure is very high even within five minutes
  - Oxygen is a neuro stimulant that can be used therapeutically for brain injury, but it’s such a powerful stimulant that **it can cause a seizure**
  - Dom’s main research program is studying the negative effects of hyperbaric oxygen therapy when it’s at an extreme level and we call that central nervous system (CNS) oxygen toxicity
  - Dom’s team made the initial discovery that [**therapeutic ketosis delivered with a ketone ester is an extremely powerful countermeasure against CNS oxygen toxicity**](https://journals.physiology.org/doi/full/10.1152/ajpregu.00506.2012)
- The increased pressure of diving is pushing nitrogen into your system
  - This is why is you surface to quickly, your blood and tissues will be saturated with nitrogen resulting in [decompression sickness](https://en.wikipedia.org/wiki/Decompression_sickness)
  - When that happens you must be put into a hyperbaric oxygen chamber to repressurize to get that nitrogen back in and then slowly breathe out that nitrogen

Types of hyperbaric oxygen chambers

- Hyperbaric means you’re increasing the barometric pressure
- **A mono place chamber**–one person inside with the entire air inside the chamber is typically 100% oxygen
  - But having the whole room filled with oxygen creates a fire hazard
  - A spark becomes a bomb (that’s what happened with [Apollo 1](https://en.wikipedia.org/wiki/Apollo_1))
- **A multi place chamber**–a chamber where up to 20 people and they typically have a technician that’s inside making sure everybody’s okay
- They pressurize the chamber to 2.0-2.5 atmospheres
- But the individuals are breathing 100% oxygen **through a mask**
- If they have a seizure in that context of a multi place chamber, you could just take the mask off and they would go from 100% oxygen breathing to a hyperbaric air, which is still elevated in oxygen, but it’s not enough to cause a seizure
- So if they had a seizure you could take the mask off and the seizure would likely stop.

**Other benefits of HBOT:**

“*There’s a wide range of protocols depending on what you’re treating.*” says Dom

- Hyperbaric oxygen has a lot of effects on the physiology as a whole
- Immune boosting effects
- Stimulates the mobilization (and maybe production) of stem cells
- For cancer purposes, it can function as a [radiosensitizer](https://blog.dana-farber.org/insight/2018/01/what-is-a-radiosensitizer/)
- Aids in wound healing
- It may helps athletes recover
- Possible longevity benefits
- Recovering from traumatic brain injury

## Is there a potential role for HBOT in treating COVID-19 patients? [44:15]

In regards to COVID-19—

- Patients are becoming extremely desaturated
- One theory floating around is that the COVID-19 causes hemoglobin to release oxygen
- But Dom thinks it’s more like that there’s a **lack of O2 transfer in the lung**—
  - i.e., oxygen cannot get pass all the inflammation in the tissues in the lung which are extremely damaged by COVID-19
  - This is contributing to the desaturation and not the COVID-19 desaturating the hemoglobin molecule by kicking oxygen off

Dom says there’s a potential a role for hyperbaric oxygen to treat these disorders and restore oxygenation

- Some [reports came out of China](https://www.ihausa.org/covid19-hyperbaric-therapy/) showing that HBOT could reverse COVID-19 and save a patient’s life
- But there is a big risk in using HBOT on COVID-19 patients…
  - COVID-19 is an inflammatory process that is driving the pathology
  - Increasing tissue PO2 in the lungs can increase reactive oxygen species
  - So you could be fueling a compromised system just through an increase in redox stress in the lung

> “I’m on the fence whether we should be throwing everybody inside a hyperbaric chamber with COVID-19 if the ventilator doesn’t work. But I think it needs to be explored.”

## Non-cancer applications of HBOT [47:30]

**Is Dom incorporating HBOT into his personal routine?**

- He is not — “*From a cost perspective and a feasibility perspective, I don’t use hyperbaric oxygen therapy.*”

–*That said, he does see some legitimate applications*:

- It can [mobilize stem cells](https://pubmed.ncbi.nlm.nih.gov/16299259/) which, once in circulation, hone in on sites of injury and aid in repair and potentially regenerative processes
- It can also stimulate the immune system

- Some work demonstrates that hyperbaric oxygen increases gene expression of superoxide dismutase and catalase, and maybe glutathione too, [through hyperbaric preconditioning](https://pubmed.ncbi.nlm.nih.gov/24984322/)

- So it increases your endogenous antioxidant systems—which in theory could make you more resilient against subsequent oxidative challenges (e.g., exercise)
- There are NFL athletes using HBOT that swear by it, says Dom

**Keto diet in a hyperbaric environment –** [**NASA Extreme Environment Mission Operations**](https://www.nasa.gov/mission_pages/NEEMO/index.html) **(NEEMO) 22 mission**

- Dom did live in a hyperbaric environment for 10 days during his NEEMO 22 mission
- During this mission he stayed at a moderate to high level of ketosis and [completed many different types of experiments with his crew](https://www.flickr.com/photos/40054892@N06/35183053350/in/album-72157683015049201/)
- He reached his lowest glucose ever
- Ketones got up to 6.7 and a glucose in the 40s or 50s range
- These numbers were typical following [his EVAs](https://www.flickr.com/photos/40054892@N06/35405313042/in/album-72157683015049201/)—
  - he would suit up and work on the ocean floor for up to five hours at a time
  - Afterwards, he would be mildly hypothermic and his metabolism skyrocketed
  - That’s when he had his lowest glucose ever and the first time he was able to achieve glucose super low and ketones really high

![](https://peterattiamd.com/wp-content/uploads/2020/07/fig-3.-Dom-on-an-EVA-1024x768.png)

**Figure 3. Dom on an EVA during NEEMO 22.** Image credit: [nasa.gov](https://www.flickr.com/photos/40054892@N06/35405313042/in/album-72157683015049201/)

## The inverse relationship between glucose and ketones [50:30]

- In terms of a fuel substrate, BHB (ketones) and glucose tend to have an inverse relationship
- If you add ketones, the available glucose will lower
- And it’s all dependent upon the liver.
- The liver is the master regulator that choreographs this dynamic interplay between these metabolites.
- A finely tuned physiological system under a very powerful homeostatic regulation will adjust glucose relative to ketones to the point where they’re inversely proportional.
- For example, if you take exogenous ketones, you see a drop in your glucose
  - This is true under normal conditions
  - But someone with unregulated type 1 diabetes lacks the counterregulatory system associated with control of ketones ⇒ without insulin, you have runaway ketogenesis

**2 types of  ketoacidosis**:

  1 | Diabetic ketoacidosis—

- the counterregulatory mechanisms of insulin are not working
- If you’re on a ketogenic diet and then ketones spill into the bloodstream, they feed back to the pancreas and small pulses of insulin will decrease beta oxidation of fatty acids in the liver and reduce ketogenesis.

  2 | Alcoholic ketoacidosis—

- Ethanol de-energizes the liver, and it causes redox stress in the liver, inhibiting hepatic gluconeogenesis resulting in runaway ketoacidosis
- It’s a reactionary thing that your body does because it thinks it’s starving

## Is a ketogenic diet appropriate for type 1 diabetics? [54:00]

***Can ketogenic diet be used for those with type one diabetes?***

- “*Yes, absolutely*.” says Dom
- One of Dom’s former students, [Andrew Koutnik](https://www.andrewkoutnik.com/about-me), has T1D and [blogs](https://www.andrewkoutnik.com/) about his use of a low-carb, ketogenic diet to manage it
- He also gave a [TEDx Talk](https://www.youtube.com/watch?v=eDfgulV_F6o) that explained how all 10 causes of death for humans are increased with type 1 diabetes, but they’re reduced when you use a low carb approach to managing type one diabetes

\**The important thing to remember*: If you are a type 1 diabetic using insulin and you start a low carb ketogenic diet approach, the insulin dose needs to be adjusted because insulin requirements will be dramatically reduced and this needs to be done under very **close supervision with an endocrinologist**.

There is no cure, but there’s really no therapy like it—

- Hemoglobin A1C goes into non-diabetic ranges when a person adheres to a low carb ketogenic diet strategy for managing their type 1 diabetes
- The low carb protocol is generally modeled after Richard Berstein’s book called [Dr. Bernstein’s Diabetes Solution](https://www.amazon.com/Dr-Bernsteins-Diabetes-Solution-Achieving/dp/0316182699)
- Just under 50 grams per day of carbohydrates on average basically puts a type 1 diabetic’s hemoglobin A1C into nondiabetic range “*and that’s remarkable.*”
- What happens is…
  - It really crushes the glycemic variability.
  - So you have far fewer hyperglycemic events and far fewer hypoglycemic events.
  - And of course, a hypoglycemic event, if you’re on a normal diet could be deadly.
  - But say if your ketones are elevated, you’ll be much more resilient during hypoglycemia.
  - And these hyperglycemic events don’t really realize that they’re happening, but they take a big toll on your body and on your brain and your organs.

> “From my perspective. . .the most effective way, probably the safest way, to manage type 1 diabetes is with low carb.”

Resources:

- Facebook group: [TYPEONEGRIT](https://www.facebook.com/Type1Grit/)
- From Dom’s website: [Managing Type-1 Diabetes with Nutrition](https://www.ketonutrition.org/blog/2018/8/27/type1diabetes)
- Andrew Koutniks blog: [andrewkoutnik.com](https://www.andrewkoutnik.com/)
- Andrew’s TEDx talk: [Rethinking Nutrition for Type-1 Diabetics](https://www.youtube.com/watch?v=eDfgulV_F6o)
- Observational study by Lennerz and Ludwig: [Management of Type 1 Diabetes With a Very Low–Carbohydrate Diet](https://pediatrics.aappublications.org/content/141/6/e20173349?fbclid=IwAR0QXBxNoQNnEfytOC_20p6KUz9ZnqJah3pnXg3xXtc_LiPgAnluYZYNDbg)
- Episode of The Drive on the management of T1D: [#41 – Jake Kushner, M.D.: How to thrive with type 1 diabetes and how everyone can benefit from the valuable insights](https://peterattiamd.com/jakekushner/)

## How ketosis may reduce the risk for Alzheimer’s disease and Parkinson’s disease [1:00:30]

**How the brain uses ketones and why nutritional ketosis lifestyle may reduce the risk for dementia**

- Around 2008, Dom’s original thinking was that the keto diet needed to be followed for a period of time before your brain was capable of adapting to using ketones for fuel
- But [Dr. Mary Newport](https://coconutketones.com/mary-newport-md-bio-books/) convinced Dom that you could just drink ketones or take a fat which could convert to ketones and your brain could use it
- Dom’s thinking was also greatly influenced by Dr. Mary Newport: [The Complete Book Of Ketones](https://www.amazon.com/gp/product/1684421608/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ketonutrition-20&creative=9325&linkCode=as2&creativeASIN=1684421608&linkId=d9f84654357db2e3e0138ae80858ef26)

*Ketones function as an alternative fuel for the brain*

- And this can mitigate symptoms of Alzheimer’s disease because a hallmark characteristic of most neurodegenerative diseases is [brain glucose hypometabolism](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4937039/)
- And that could be from a number of different reasons—
  - A vascular blood flow reason
  - Decreased activity of [pyruvate dehydrogenase complex](https://en.wikipedia.org/wiki/Pyruvate_dehydrogenase_complex)
  - Internalization of the glucose transporter, the GLUT3 transporter that’s in neurons
- “*So ketones could be functioning as an alternative fuel to* ***restore brain energy metabolism*** *in the face of glucose hypometabolism*.”

*Issue with* ***amyloid clearance*** *that’s associated with Alzheimer’s disease (an energy dependent process)—*

- If you’re inhibiting energetic processes in the brain, the amyloid does not clear as fast as it should
- That is driven by a number of different factors—
  - Genetically, APOE4 may predispose you to that
  - Inflammation in the brain—inflammatory processes are associated with an increase in production of amyloid (and a decrease of clearing the amyloid)
    - Research is showing that [inflammation and processes](https://pubmed.ncbi.nlm.nih.gov/27350397/) are associated with an increase in production of amyloid

Research by [Stephen Cunnane](https://u.osu.edu/ketodiet/speaker-bios/stephen-cunnane-phd/):

- He is doing glucose-ketone PET scans and has found that there’s significant glucose hypometabolism associated with aging, but the same thing **doesn’t happen with ketone metabolism**
- He gave an [IHMC talk](https://www.youtube.com/watch?v=pR8bHXZKZj8) and a [Virta Health talk](https://www.youtube.com/watch?v=XxGiQ7YrUYE)
- He was also on [episode 59](https://www.ihmc.us/stemtalk/episode-59/) of the IHMC STEM-Talk podcast
- He was also a speaker at the [2019 Metabolic Health Summit](https://metabolichealthsummit.com/products/mhs-2019-presentation-videos?aff=9)

![](https://peterattiamd.com/wp-content/uploads/2020/07/fig-4.-stephen-cunnane-pet-scan-1024x769.png)

**Figure 4. Images showing uptake of ketones by the brain compared to glucose.** Image credit: [YouTube | Virta Health](https://www.youtube.com/watch?v=XxGiQ7YrUYE)

**Relevant study**: [Modified Ketogenic Diet Is Associated With Improved Cerebrospinal Fluid Biomarker Profile, Cerebral Perfusion, and Cerebral Ketone Body Uptake in Older Adults at Risk for Alzheimer’s Disease: A Pilot Study](https://pubmed.ncbi.nlm.nih.gov/31757576/)

**Ketosis and Parkinson’s disease**

*Any data or studies on the benefits of ketosis in Parkinson’s disease?*

- A [2005 paper by Dr. Theodore VanItallie](https://pubmed.ncbi.nlm.nih.gov/15728303/) showed that the ketogenic diet could be followed by patients with Parkinson’s disease and it may have lessened or mitigated some of the symptoms
- Rationale for Ketones to be used in Parkinson’s and other Neuro diseases: [Hashim and VanItallie, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24598140)
- There’s a [registered clinical trial](https://clinicaltrials.gov/ct2/show/NCT01364545) at Oxford to look at a ketone ester as a therapy for Parkinson’s disease

In animal models—

- Good scientific preclinical animal model data (and in cell culture) [demonstrate that ketones are neuroprotective](https://pubmed.ncbi.nlm.nih.gov/14604265/) to [dopaminergic neurons](https://en.wikipedia.org/wiki/Dopaminergic_cell_groups)

- After about 90% of dopaminergic neurons degenerate, we get Parkinson’s disease
- The issue is that it’s already too late because the neuronal populations have already degraded
- It’s possible that following a ketogenic diet (or supplemental ketosis) over time could prevent dopaminergic neurons from degenerating in the first place

*Dom thinks that they may be neuroprotective because…*

- They can help energetically support the health and vitality of the neurons
- They also have an ability to decrease reactive oxygen species in the neurons
- So dopaminergic neurons—
  - Use monoamine oxidase and the metabolism of monoamine oxidase can result in higher reactive oxygen species and even drive the Fenton reaction under some conditions
  - The dopaminergic neuron population is selectively vulnerable to oxidative stress but they may be less vulnerable/more resilient in a brain that’s fueled off ketones

**Is there a link with mitochondrial dysfunction and whether that’s a cause or a consequence of Parkinson’s?**

- Mitochondrial dysfunction is the root cause, says Dom

*Example—*

- [MPTP](https://en.wikipedia.org/wiki/MPTP), a drug that was synthesized as a recreational drug, was taken by a group of people and this caused Parkinson’s disease
- When you consume it, it’s selectively taken up into dopaminergic neurons and causes a burst reactive oxygen species, and then selective destruction of this anatomical region, the [substantia nigra](https://en.wikipedia.org/wiki/Substantia_nigra)
- PBS did a special called [The Case of the Frozen Addicts](https://openvault.wgbh.org/catalog/V_474CF2C8A20B4173988486AC4C605A3C)
- By implanting STEM cells into a region of the brain, they were able to restore function in animal models and some of the patients
- It was a very dramatic demonstration of mitochondrial dysregulation through a neurotoxin causing Parkinson’s disease.

*Oxidative stress*

- Oxidative stress specifically in this dopaminergic neuron population triggers apoptosis and programmed cell death
- That can be mitigated in part by an optimal metabolic environment where the mitochondria is functioning efficiently

> “The function of the mitochondria and mitochondrial health are the ultimate mitigator of neurodegenerative diseases, probably Parkinson’s disease being at the top of that list, just by reducing the potential for reactive oxygen species related damage.”

## Ketosis for females—considerations, fertility, performance, and the latest research [1:11:00]

Dom reached out to [Kristi Storoschuk](https://twitter.com/krististors?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) who is very well read up on this topic

- One study found that [45% of the women](https://onlinelibrary.wiley.com/doi/pdf/10.1046/j.1528-1157.2003.57002.x) in the study that were on a ketogenic diet experienced menstrual dysfunction (e.g., [secondary amenorrhea](https://www.healthline.com/health/secondary-amenorrhea))
- Secondary amenorrhea can also be caused by—
  - Excess exercise
  - Reduced energy intake
  - Stress
  - Low body fat

Ketogenic diet may not be ideal for fertility—

- Recent [animal study](https://www.jstage.jst.go.jp/article/jrd/57/3/57_11-001S/_pdf/-char/en) sltk showed that an infusion of exogenous ketones suppressed luteinizing hormone (LH), and the response was dependent upon an increase in catecholamines
  - The implications may be that the ketone infusion—by decreasing LH and elevating ketones—this may help you get leaner, but it’s **not going to help you maintain fertility**
  - Ketones may be a signal to the body and the brain that it may not be the best time for child rearing—because if you have low resources (e.g., fasted) you’re going to be in a state of ketosis

When it might HELP fertility—

- Females that have metabolic syndrome and insulin resistant (e.g., [polycystic ovary syndrome](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome), or PCOS)
- The ketogenic diet can restore their fertility and restore their hormonal balance
- See this [pilot study looking at PCOS](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1334192/)

**\*Takeaway**: A clinical ketogenic diet (high fat, low carb) should be approached cautiously, whereas a low carb, moderate-to-high protein diet may be a better choice for females that are going to try this approach to reduce carbohydrates gradually.

**Female-only studies with ketogenic diets**

*What research is there on women and ketogenic diets?*

- From the epilepsy literature, we do see some sort of hormonal/fertility issues
  - When girls who have epilepsy are using the ketogenic diet and they go through puberty, that can influence their ketone levels

Two studies, ([Vargas-Molina et al., 2020](https://jissn.biomedcentral.com/articles/10.1186/s12970-020-00348-7) and [Gregory et al., 2017](https://clinmedjournals.org/articles/ijsem/international-journal-of-sports-and-exercise-medicine-ijsem-3-054.php?jid=ijsem)), looked at the ketogenic diet for lean body mass and performance in women—

- The observation was that women on a low carb ketogenic diet could maintain lean body mass and increase performance

[A 2005 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1334192/) looked at fertility and women on low carb ketogenic diets—

- Two of the women were actually able to get pregnant after being infertile for a period of time

The effect of a low carb diet varies depending on the individual woman—

- Where they are in terms of metabolic health
- The design of the diet—the macronutrient ratios, the source of fats and protein also make a difference

> “There needs to be more data for sure. Some of the data indicates that it can be beneficial, especially in women that have metabolic syndrome.”

## Low-carb diets during pregnancy and postpartum [1:17:00]

**Considerations for women considering low-carb and/or keto diets during pregnancy and postpartum**

- Be cautious using a purely ketogenic diet during pregnancy
  - Keto diets dramatically suppress insulin (a growth hormone), and can have great health consequences
  - However, during pregnancy you want to grow and do not want to impair growth of the developing fetus
- In the case of a pregnant woman is **obese or a type 2 diabetic**, low-carb approach can be very powerful approach, says Dom

Postpartum—

- Dom has seen multiple examples of women who have trouble producing milk for breastfeeding while on a ketogenic diet—the suppression of insulin signaling for some reason is decreasing lactation and the ability to make milk
- That said, Dom has received emails from women saying they had no problem breastfeeding while on a keto diet
- So, issues with breastfeeding appears to happen in some percentage of women and not others

## A high-protein diet to counteract common hormonal issues associated with the ketogenic diet [1:21:15]

**Ketosis and leptin**

- ([Volek et al., 2008](https://link.springer.com/article/10.1007/s11745-008-3274-2))
  - There is a decrease in leptin associated with ketosis
  - But there was also an increase in leptin sensitivity
  - “S*o even though leptin went down, leptin sensitivity is higher*.”

**Dom’s thoughts on a higher protein approach for women with hormonal issues**— *hypothyroidism, peri- and post-menopause, amenorrhea, PCOS, etc.*

- A lot of the issues and side effects that women are experiencing are probably from—
  - Calorie restriction
  - Overexercising
  - And suppression of insulin signaling from calorie restriction plus carbohydrate restriction
    - The insulin suppression impact women more than men in terms of maintaining a hormone balance (especially with the sex hormones)

*Hypothyroidism—* (See [Part 1](https://peterattiamd.com/domdagostinoama01/) for more on hypothyroidism)

- Low insulin can result in an increase in reverse T3
- Periodic spikes in insulin can typically reverse that
- And those moderate spikes could be achieved with protein

**Takeaway**: Periodically increasing protein into your diet may be beneficial for women to avoid some of the potential counterregulatory hormonal effects that can occur through insulin suppression associated with the ketogenic diet.

## Nutritional tips for remaining metabolically flexible [1:22:45]

> “I think it’s really important to pulse insulin occasionally in and around training. And that definitely facilitates repair of tissues, recovery.”

- If you’re using a diet therapeutically, it’s important to maintain insulin suppression and low blood glucose and ketones
- And the more Dom studies this, he more convinced that it’s not just about low glucose, but **low insulin**

For a normal, healthy person using the ketogenic diet as a lifestyle—

- For someone doing physical activity of exercise, you need to enhance recovery at times
- Spiking insulin into the moderate range a few times a week can really be beneficial to assist in recovery, but to also keep that energetic pathway open
- It’s not about using one fuel over another, but rather about being **metabolically flexible**
- In other words, the ability to use ALL the fuels as efficiently as possible in the context of a normal, healthy metabolism

“A super strict ketogenic diet all the time is going to produce some level of physiological insulin resistance that I’m not convinced is advantageous.” says Dom

## What is one belief Dom has changed his mind about? [1:26:45]

- Dom now believes that “doing less” can make a person more productive
- 5 to 10 years ago, Dom was completely convinced that you have to pick your one thing and be a hundred percent all in, all the time
- But he’s found that scheduling in **creative downtime** paradoxically improves productivity

[Amos Tversky](https://en.wikipedia.org/wiki/Amos_Tversky), a famous psychologist for his work on behavioral economics, [once said](https://www.collaborativefund.com/blog/the-advantage-of-being-a-little-bit-underemployed/#:~:text=Amos%20Tversky%2C%20the%20late%20collaborator,being%20able%20to%20waste%20hours.%E2%80%9D), “*You waste years by not being able to waste hours.*”

## In utero experiments, and other interesting questions Dom wants to explore [1:29:45]

**In utero experiments**

- Dom is very interested in doing in utero experiments on disorders that we already know are responsive to the ketogenic diet (e.g., cancer and genetic disorders)
- The idea is to take a pregnant mom and apply ketone metabolic therapy and seeing the outcome on the fetus, the babies, and then what happens after they’re weaned later on in life
- Dom thinks that the beta-hydroxybutyrate is functioning as a histone deacetylase inhibitor—essentially an epigenetic regulator to help symptomatically treat patients

⇒ *Genetic disorders, for example*:

- If genetic testing revealed that the baby was going to have a genetic disease that we know already responds to therapeutic ketosis, such as…
  - [Glucose transporter type 1 deficiency syndrome](https://rarediseases.org/rare-diseases/glucose-transporter-type-1-deficiency-syndrome/#:~:text=Glucose%20transporter%20type%201%20deficiency%20syndrome%20(Glut1DS)%20is%20a%20rare,barrier%20and%20other%20tissue%20barriers.)
    - where the fetus and baby would basically have impaired glucose transport across the blood-brain barrier into the brain
    - and that hypoglycemia in the brain is not only decreasing energy, but also has pretty significant developmental consequences
  - [Kabuki syndrome](https://en.wikipedia.org/wiki/Kabuki_syndrome)
  - [Lennox-Gastaut syndrome](https://en.wikipedia.org/wiki/Lennox%E2%80%93Gastaut_syndrome)
  - Different seizure disorders
  - Neurometabolic disorders

Dom and his partners have developed a [clinical trial](https://trialsjournal.biomedcentral.com/articles/10.1186/s13063-019-3996-x) to look at therapeutic ketosis with ketone salts and MCT combination in children with Angelman syndrome

⇒ *Cancer*:

- The idea would be to suppress oncogenic transformation with the therapy starting in utero resulting in animals (or people) less prone to developing tumors
- There’s are people who are genetically very susceptible to certain types of cancers—and the idea would be to see if you could prevent them from occurring by starting treatment in utero

Additionally, Dom would like to explore the opposite approach—

- In utero experiments where you feed the mom **high-fructose corn syrup, oxidized fats, trans fats, glyphosate, chemicals**
- And follow the offspring to see if there’s an increase in disease

**Glucose transporter type 1 deficiency syndrome and the lack of cancer**

- People with glucose transporter type 1 (GLUT1) deficiency syndrome, do not seem to get cancer
- In cancer cells, there’s a rapid increase in [GLUT1 transporters](https://en.wikipedia.org/wiki/GLUT1)
- This massive upregulation of the GLUT1 transporter is how they maintain their voracious appetite for sugar/glucose
- Inhibiting that would be a very powerful strategy to restrict glucose availability to the tumor
- That said, you’d be restricting glucose availability to the brain too, so being able to do it site specifically would be important
- Pharmaceutical companies are looking for site-specific ways to block GLUT1 in the tumor

\*Dom encourages people to check out the work going on at the [Glut1 Deficiency Foundation](https://www.g1dfoundation.org/what-is-glut1-deficiency.html)

## The anti-catabolic effect of ketones, cancer cachexia, and nutritional interventions for cancer patients [1:38:30]

**Cancer cachexia**

- Cancer cachexia is a form of weight loss, specifically muscle, associated with cancer and is a big issue
- People like Tom Seyfried is making the case that the ketogenic diet should be standard of care for people with cancer
- Yet, the American Cancer Society [recommends on their website](https://www.cancer.org/treatment/survivorship-during-and-after-treatment/staying-active/nutrition/once-treatment-starts.html) that cancer patients eat ice cream as a topping on cake to combat weight loss

*-How is this possible??*

- Everyone in medicine is very **specialized**—So an oncologist is typically not very read-up on the metabolic characteristics of cancer
- While oncologist have incredible depth in their field, they are sort of “clueless” when it comes to nutrition, nutritional ketosis, nutrition, and metabolic physiology
  - (Peter and Dom says there’s a need for **metabolic oncology**)

> “We need to have practitioners that understand the importance of this…as a means to further augment and enhance existing standard of care…and as a preventative approach too, because there’s so many cancers that are associated with metabolic syndrome.”

**Anti-catabolic effects of ketones**

Paper by Dom and Andrew Koutnik: [Ketone Bodies Attenuate Wasting in Models of Atrophy](https://onlinelibrary.wiley.com/doi/full/10.1002/jcsm.12554)

- The study showed that the muscle-sparing effects of ketones were pretty remarkable in multiple model systems
- When people reach the point where they can’t move around and exercise (due to cancer cachexia), they rapidly decline and succumb to the tumor burden much quicker
- And the anti-catabolic effects of ketones may be able to mitigate

> “A lot of cancer-related death is associated with cancer cachexia, and therapeutic ketosis may be a way to mitigate that just by virtue of the ketone bodies having an anti-catabolic effect.”

**Evolutionary mechanism by which ketones are anti-catabolic**

- In a fasting state, the generation of ketones to supply the central nervous system with energy prevented gluconeogenic amino acids in skeletal muscle from being catabolized to maintain the glucose supply to the brain
- So the ability for the body to basically convert fat and generate these water-soluble fat molecules that could pass the blood-brain barrier and preserve the high energy demands of the brain, that becomes a very effective, very powerful anti-catabolic strategy

***How it’s helping cancer cachexia*** **—**

- One major pathway found by Andrew Koutnik is that it **inhibits specific inflammatory pathways that are driving cancer cachexia**
- Dom is doing more research to figure out other pathways

***Can you counteract cancer cachexia/weight loss by shoveling in all types of food?***

- It will, but at the consequence of driving all the pathways associated with cancer growth and proliferation
- PI3K inhibitors, for example, have much potential in cancer therapy — but the side effect is an increase in glucose and insulin — so that’s why their efficacy is dependent upon simultaneously delivering this with a **ketogenic diet** which suppresses the insulin that would otherwise be elevated.
- So when you’re force-feeding cancer patients these hyperpalatable foods (e.g., ice cream and cake)…
- You may get their weight up, but you are doing a major disservice because you are driving many of the things that are associated with cancer growth and what are ultimately going to be poor outcomes: *inflammation, metabolic syndrome, hyperinsulinemia, hyperglycemia, nonalcoholic fatty liver disease*

**What nutrition for cancer patients should look like**:

- We need engineered foods for cancer patients
- Carbohydrate restricted
- Moderate in protein to supply just enough protein to meet the needs of the cancer patient
- Plus we need a whole ingredient list of natural additives that have anti-cancer properties, a few examples being—
  - [EGCG](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3509513/#:~:text=In%20a%20subsequent%20study%2C%20synergistic,chemoprevention%20%5B18%2C19%5D.)
  - [Turmeric](https://www.mskcc.org/cancer-care/integrative-medicine/herbs/turmeric)
  - [DHEA](https://www.mskcc.org/cancer-care/integrative-medicine/herbs/dehydroepiandrosterone) in certain situations
  - Omega-3 fatty acids can also have an anticatabolic anti-cancer cachexia effect.
- [Ensure](https://ensure.com/?gclsrc=aw.ds&&gclid=Cj0KCQjw9b_4BRCMARIsADMUIyrYWxTklPz8nTznYSZMJXPuuyrl42RLjfj2JLqdS8DWzILdKU9-iw8aAhGtEALw_wcB&gclsrc=aw.ds)—the dietary drink commonly given to cancer patients . . . *“is not the solution. . .that should be criminal*.” says Dom

## What is the one interesting experiment Dom would do if money and time were no barrier? [1:46:25]

- Dom recently listened to an episode of the [Joe Rogan podcast with Elon Musk](https://www.youtube.com/watch?v=RcYjXbSJBN8)
- Dom is fascinated by the concept of connecting the universal consciousness with a biological project like [Neuralink](https://www.youtube.com/watch?v=r-vbh3t7WVI&feature=youtu.be)

**Dom says**:

“*In a way, this technology would sort of allow us to be like born again almost from a religious standpoint, where we understand, empathize with other humans and groups of humans. . .*

*. . And there could be some system that would quantify it and tell us if we’re doing a good job and redirect our thinking in a way to where we could promote actionable behavior that would move the human species in the right direction.*”

§

## Selected Links / Related Material

**Relevant blog posts from KetoNutrition (KN)**:

- [Cancer cachexia blog post on KN](https://www.ketonutrition.org/blog/2020/4/14/what-is-cancer-cachexia-and-why-is-it-a-problem-worth-investigating)
- [Inverse relationship between glucose and ketones blog post on KN](https://www.ketonutrition.org/blog/2020/1/23/glucose-lowering-effect-of-ketones)
- [Anticatabolic effects of ketones blog post on KN](https://www.ketonutrition.org/blog/2019/4/19/anticatabolic-effects-of-ketone-bodies)
- [Investigating Ketone Bodies as Immunometabolic Countermeasure against Respiratory Infections](https://www.cell.com/med/fulltext/S2666-6340(20)30013-1#secsectitle0021)

**Dom’s Press-Pulse paper with Tom Seyfried from 2017**: [Press-pulse: a novel therapeutic strategy for the metabolic management of cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-017-0178-2) (Seyfried et al., 2017) [2:00, 8:45]

**Dom first appearance on The Drive podcast**: [#05 – Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer](https://peterattiamd.com/domdagostino/) | Peter Attia (peterattiamd.com) [2:00]

**Tom Seyfried’s appearance on The Drive podcast discussing the Press-pulse protocol**: [#30 – Thomas Seyfried, Ph.D.: Controversial discussion—cancer as a mitochondrial metabolic disease?](https://peterattiamd.com/tomseyfried/) | Peter Attia (peterattiamd.com) [2:45, 12:45]

**The ketogenic diet and hyperbaric oxygen therapy prolong survival in mice with systemic metastatic cancer** [The ketogenic diet and hyperbaric oxygen therapy prolong survival in mice with systemic metastatic cancer](https://pubmed.ncbi.nlm.nih.gov/23755243/) (Poff et al., 2013) [6:45]

**Tom Seyfriend’s paper about the glucose-ketone index**: [The glucose ketone index calculator: a simple tool to monitor therapeutic efficacy for metabolic management of brain cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-015-0009-2) (Meidenbauer et al., 2015) [7:20]

**Lew Cantley discussed PI3K inhibitors on The Drive podcast**: [#110 – Lew Cantley, Ph.D.: Cancer metabolism, cancer therapies, and the discovery of PI3K](https://peterattiamd.com/lewcantley/) | Peter Attia (peterattiamd.com) [8:15, 25:00]

**Dom’s in vitro experiments with high doses of vitamin C**: [Pharmacological Ascorbic Acid and Hyperbaric Oxygen Therapy Target Tumor Cell Metabolism via an Oxidative Stress Mechanism](https://cdn.technologynetworks.com/ep/pdfs/pharmacological-ascorbic-acid-and-hyperbaric-oxygen-therapy-target-tumor-cell-metabolism-via-an.pdf) (DeBlasi et al., 2017) [8:30]

[Valter Longo’s mouse study showed a remarkable effect using a nontoxic combination of a fasting-mimicking-diet (FMD) with IV vitamin C against KRAS mutated cancers](https://www.nature.com/articles/s41467-020-16243-3): [Synergistic effect of fasting-mimicking diet and vitamin C against KRAS mutated cancers](https://www.nature.com/articles/s41467-020-16243-3) (Di Tano et al., 2020) [9:15]

**Paper showing a decrease in tumor burden in a woman with metastatic thymoma treated with a ketogenic diet and fasting combined with prednisone and other immune based therapies**: [Managing Metastatic Thymoma With Metabolic and Medical Therapy: A Case Report](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7227442/) (Phillips et al., 2020) [9:30]

**Case studies by Tom Seyfried**: [12:30]

- *Triple negative breast cancer*: [Efficacy of Metabolically Supported Chemotherapy Combined with Ketogenic Diet, Hyperthermia, and Hyperbaric Oxygen Therapy for Stage IV Triple-Negative Breast Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5589510/) (İyikesici et al., 2017)
- *Glioblastoma*: [Therapeutic benefit of combining calorie-restricted ketogenic diet and glutamine targeting in late-stage experimental glioblastoma](https://www.nature.com/articles/s42003-019-0455-x) (Mukherjee et al., 2019)

**Tumor cells can be “addicted” to glutamine (i.e., mitochondrial substrate level phosphorylation with glutamine)**: [Glutamine Addiction: A New Therapeutic Target in Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2917518/#:~:text=Cancer%20cells%20can%20be%20addicted%20to%20glutamine,-The%20advent%20of&text=First%2C%20several%20oncogenes%20and%20tumor,metabolism%20%5B4%E2%80%937%5D.) (Wise and Thompson, 2010) [17:45]

**Tom Seyfried has experimented with combining calorie-restricted ketogenic diet and glutamine targeting in late-stage experimental glioblastoma**: [Therapeutic benefit of combining calorie-restricted ketogenic diet and glutamine targeting in late-stage experimental glioblastoma](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6541653/) (Mukherjee et al., 2019) [17:45, 20:15]

**Dom published a paper with Andrew Koutnik which demonstrated that the VM-M3 mouse model is an amazing model to study cancer cachexia**: [Ketone Bodies Attenuate Wasting in Models of Atrophy](https://onlinelibrary.wiley.com/doi/full/10.1002/jcsm.12554) (Koutnik et al., 2020) [18:45]

**Episode of Seinfeld Kramer is a driving a car that’s nearly out of gas and they want to see how far they can take it**: [Seinfeld Gas Tank Episode](https://www.youtube.com/watch?v=tDnAzGpxR4k) | Erin Cramer (youtube.com) [21:15]

**Book Dom recommends that discusses 3BP—an exciting molecule in cancer treatment**: [Tripping Over the Truth: How the Metabolic Theory of Cancer Is Overturning One of Medicine’s Most Entrenched Paradigms](https://www.amazon.com/dp/160358935X/ref=dp-kindle-redirect?_encoding=UTF8&btkr=1) by Travis Christofferson | (amazon.com) [27:00]

**Suggested literature by Dom on the topic of the relationship between cancer and ketogenic diets**: [29:30]

- **Comprehensive review on Keto Diet and Cancer** : [Ketogenic diet in the treatment of cancer – Where do we stand?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7056920/) (Weber et al., 2020)
- **Ketogenic Diet and Drug Synergy under investigation:** [A 2-Week Ketogenic Diet in Combination With Letrozole to Modulate PI3K Signaling in ER+ Breast Cancer (Vanderbilt)](https://clinicaltrials.gov/ct2/show/NCT03962647?term=ketogenic&cond=cancer&draw=2&rank=1) | (clinicaltrials.gov)

**Evidence that KRAS mutations associated with  different lung cancers, pancreas and colon cancer were responsive to ketogenic diets**: [Synergistic effect of fasting-mimicking diet and vitamin C against KRAS mutated cancers](https://www.nature.com/articles/s41467-020-16243-3) (Di Tano et al., 2020) [31:30]

**Paper suggesting dietary fat intake might promote the growth of melanoma tumors harboring BRAF V600E mutations**: [Prevention of Dietary-Fat-Fueled Ketogenesis Attenuates BRAF V600E Tumor Growth](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(16)30643-X) (Xia et al., 2017) [31:45]

**Lew Cantley showed certain blood cancers (e.g., AML) are responsive to the ketogenic diet combined with a PI3 kinase inhibitor**: [Suppression of insulin feedback enhances the efficacy of PI3K inhibitors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6197057/) (Hopkins et al., 2018) [32:15]

**Dom’s team made the initial discovery that therapeutic ketosis delivered with a ketone ester is an extremely powerful countermeasure against CNS oxygen toxicity**: [Therapeutic ketosis with ketone ester delays central nervous system oxygen toxicity seizure in rats](https://journals.physiology.org/doi/full/10.1152/ajpregu.00506.2012) (D’Agostino et al., 2013) [41:15]

**Reports came out of China showing that HBOT could reverse COVID-19 and save a patient’s life**: [Hyperbaric Oxygen Therapy in the Treatment of COVID-19 — Severe Cases](https://www.ihausa.org/covid19-hyperbaric-therapy/) | (ihausa.org)  [46:45]

**HBOT can mobilize stem cells which, once in circulation, hone in on sites of injury and aid in repair and potentially regenerative processes**: [Stem cell mobilization by hyperbaric oxygen](https://pubmed.ncbi.nlm.nih.gov/16299259/) (Thom et al., 2006) [47:30]

**Dom lived in a hyperbaric environment for 10 days during his NEEMO 22 mission and achieved his lowest glucose levels every**: [NEEMO 22 mission](https://www.flickr.com/photos/40054892@N06/albums/72157683015049201) | (nasa.gov) [47:45]

- Photos of Dom during NEEMO 22: [Here](https://www.flickr.com/photos/40054892@N06/35183053350/in/album-72157683015049201/) and [here](https://www.flickr.com/photos/40054892@N06/35405313042/in/album-72157683015049201/)

**Some work demonstrates that hyperbaric oxygen increases gene expression of superoxide dismutase and catalase, and maybe glutathione too, through hyperbaric preconditioning**: [Hyperbaric oxygen pretreatment and preconditioning](https://pubmed.ncbi.nlm.nih.gov/24984322/) (Camporesi and Bosco, 2014) [48:30]

**Blog about using the keto diet to manage type 1 diabetes by** [**Andrew Koutnik**](https://www.andrewkoutnik.com/about-me) **(Dom’s former student)**: [AndrewKoutnik.com](https://www.andrewkoutnik.com/) [54:15]

**TEDx Talk by Andrew Koutnik that explained how all 10 causes of death for humans are increased with type 1 diabetes, but they’re reduced when you use a low carb approach to managing type one diabetes**: [Rethinking Nutrition for Type-1 Diabetics | Andrew Koutnik | TEDxUSF](https://www.youtube.com/watch?v=eDfgulV_F6o) | TEDx Talks (youtube.com) [54:15]

**Managing type 1 diabetes with the ketogenic diet—resources and literature**: [54:00]

- *Andrew Koutniks blog*: [andrewkoutnik.com](https://www.andrewkoutnik.com/) [54:00]
- *Andrew’s TEDx talk*: [Rethinking Nutrition for Type-1 Diabetics | Andrew Koutnik | TEDxUSF](https://www.youtube.com/watch?v=eDfgulV_F6o) | TEDx Talks (youtube.com) [54:00]
- *Facebook group for type 1 diabetics*: [TYPEONEGRIT](https://www.facebook.com/Type1Grit/) | (facebook.com) [55:45]
- The T1D low-carb protocol is generally modeled after Richard Berstein’s book:  [Dr. Bernstein’s Diabetes Solution: The Complete Guide to Achieving Normal Blood Sugars](https://www.amazon.com/Dr-Bernsteins-Diabetes-Solution-Achieving/dp/0316182699) by Richard Bernstein | (amazon.com) [56:00]
- *From Dom’s website*: [Managing Type-1 Diabetes with Nutrition](https://www.ketonutrition.org/blog/2018/8/27/type1diabetes) | (ketonutrition.org)
- *Observational study by Lennerz and Ludwig*: [Management of Type 1 Diabetes With a Very Low–Carbohydrate Diet](https://pediatrics.aappublications.org/content/141/6/e20173349?fbclid=IwAR0QXBxNoQNnEfytOC_20p6KUz9ZnqJah3pnXg3xXtc_LiPgAnluYZYNDbg) (Lennerz et al., 2018) [1:00:00]
- *Episode of The Drive on the management of T1D*: [#41 – Jake Kushner, M.D.: How to thrive with type 1 diabetes and how everyone can benefit from the valuable insights](https://peterattiamd.com/jakekushner/) | Peter Attia (peterattiamd.com)

**Book that greatly influenced Dom’s thinking on ketones for brain health**: [The Complete Book of Ketones: A Practical Guide to Ketogenic Diets and Ketone Supplements](https://www.amazon.com/gp/product/1684421608/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ketonutrition-20&creative=9325&linkCode=as2&creativeASIN=1684421608&linkId=d9f84654357db2e3e0138ae80858ef26) by Mary Newport | (amazon.com) [1:00:45, 1:04:30]

**Research showing inflammatory processes are associated with an increase in production of amyloid**: [Cerebral hypoperfusion and glucose hypometabolism: Key pathophysiological modulators promote neurodegeneration, cognitive impairment, and Alzheimer’s disease](https://pubmed.ncbi.nlm.nih.gov/27350397/) (Daulatzai, 2017) [1:03:15]

**Lectures by** [**Stephen Cunnane**](https://u.osu.edu/ketodiet/speaker-bios/stephen-cunnane-phd/) **on the topic of glucose hypometabolism associated with aging and ketones as an alternative fuel for the aging brain**: [1:04:00]

- IHMC talk: [Stephen Cunnane – Can Ketones Slow Down Alzheimer’s?](https://www.youtube.com/watch?v=pR8bHXZKZj8) | TheIHMC (youtube.com)
- [Virta Health talk](https://www.youtube.com/watch?v=XxGiQ7YrUYE): [Dr. Stephen Cunnane – Brain Glucose and Ketone Metabolism](https://www.youtube.com/watch?v=XxGiQ7YrUYE) | Virta Health (youtube.com)
- Episode 59 of the IHMC STEM-Talk podcast: [EPISODE 59: STEPHEN CUNNANE DISCUSSES THE ROLE OF KETONES IN HUMAN EVOLUTION AND ALZHEIMER’S](https://www.ihmc.us/stemtalk/episode-59/) | (ihmc.us)
- Speaker at the 2019 Metabolic Health Summit: [MHS 2019 Presentations & Panels Package](https://metabolichealthsummit.com/products/mhs-2019-presentation-videos?aff=9) | (metabolichealthsummit.com)

**Relevant study about ketosis and Alzheimer’s disease**: [Modified Ketogenic Diet Is Associated With Improved Cerebrospinal Fluid Biomarker Profile, Cerebral Perfusion, and Cerebral Ketone Body Uptake in Older Adults at Risk for Alzheimer’s Disease: A Pilot Study](https://pubmed.ncbi.nlm.nih.gov/31757576/)  (Neth et al., 2020) [1:05:00]

**A 2005 paper by Dr. Theodore VanItallie showed that the ketogenic diet could be followed by patients with Parkinson’s disease and it may have lessened or mitigated some of the symptoms**: [Treatment of Parkinson disease with diet-induced hyperketonemia: a feasibility study](https://pubmed.ncbi.nlm.nih.gov/15728303/) (Vanitallie et al., 2005) [1:05:45]

**Rationale for Ketones to be used in Parkinson’s and other Neuro diseases**: [Ketone body therapy: from the ketogenic diet to the oral administration of ketone ester](https://www.ncbi.nlm.nih.gov/pubmed/24598140) (Hashim and VanItallie, 2014) [1:06:00]

C**linical trial at Oxford to look at a ketone ester as a therapy for Parkinson’s disease**: [Ketogenic Diets for Symptoms of Parkinson’s Disease](https://clinicaltrials.gov/ct2/show/NCT01364545) | (clinicaltrials.gov) [1:06:00]

**Good scientific preclinical animal model data (and in cell culture) demonstrate that ketones are neuroprotective to dopaminergic neurons**: [Ketones: metabolism’s ugly duckling](https://pubmed.ncbi.nlm.nih.gov/14604265/) (VanItallie and Nufert, 2003) [1:06:30]

**PBS did a special on people who developed Parkinson’s disease after taking the drug MPTP**: [The Case of the Frozen Addicts](https://openvault.wgbh.org/catalog/V_474CF2C8A20B4173988486AC4C605A3C) | (wgbh.org) [1:08:30]

**Literature suggests that about 45% of women on a ketogenic diet get secondary amenorrhea**: [The Ketogenic Diet: Adolescents Can Do It, Too](https://onlinelibrary.wiley.com/doi/pdf/10.1046/j.1528-1157.2003.57002.x) (Mady et al., 2003) [1:11:30]

**Animal study showing that an infusion of exogenous ketones suppressed luteinizing hormone (LH), and the response was dependent upon an increase in catecholamines**: [Central Injection of Ketone Body Suppresses Luteinizing Hormone Release via the Catecholaminergic Pathway in Female Rats](https://www.jstage.jst.go.jp/article/jrd/57/3/57_11-001S/_pdf/-char/en) (Iwata et al., 2011) [1:13:15]

**Two studies showing that women on a low carb ketogenic diet could maintain lean body mass and increase performance**: [1:15:30]

- [Effects of a ketogenic diet on body composition and strength in trained women](https://jissn.biomedcentral.com/articles/10.1186/s12970-020-00348-7) (Vargas-Molina et al., 2020)
- [A Low-Carbohydrate Ketogenic Diet Combined with 6-Weeks of Crossfit Training Improves Body Composition and Performance](https://clinmedjournals.org/articles/ijsem/international-journal-of-sports-and-exercise-medicine-ijsem-3-054.php?jid=ijsem) (Gregory et al., 2017)

**A 2005 study looked at fertility and women on low carb ketogenic diets—Two of the women were actually able to get pregnant after being infertile for a period of time**: [The effects of a low-carbohydrate, ketogenic diet on the polycystic ovary syndrome: A pilot study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1334192/) (Mavropoulos et al., 2005) [1:16:00]

**Decrease in leptin but an increase in leptin sensitivity associated with ketosis**: [Carbohydrate Restriction has a More Favorable Impact on the Metabolic Syndrome than a Low Fat Diet](https://link.springer.com/article/10.1007/s11745-008-3274-2) (Volek et al., 2008) [1:21:15]

**Dom’s clinical trial to look at therapeutic ketosis with ketone salts and MCT combination in children with Angelman syndrome**: [Evaluation of the safety and tolerability of a nutritional Formulation in patients with ANgelman Syndrome (FANS): study protocol for a randomized controlled trial](https://trialsjournal.biomedcentral.com/articles/10.1186/s13063-019-3996-x) (Herber et al., 2020) [1:31:15]

**The foundation dedicated to finding treatments and cures for glucose transporter type 1 (GLUT1) deficiency syndrome**: [Glut1 Deficiency Foundation](https://www.g1dfoundation.org/what-is-glut1-deficiency.html) | (g1dfoundation.org) [1:40:00]

**The American Cancer Society recommends cancer patients eat ice cream as a topping on cake to combat weight loss**: [Eating Well During Treatment](https://www.cancer.org/treatment/survivorship-during-and-after-treatment/staying-active/nutrition/once-treatment-starts.html) | (cancer.org) [1:38:45]

**Anti-catabolic effects of ketones–a paper by Dom and Andrew Koutnik**: [Ketone Bodies Attenuate Wasting in Models of Atrophy](https://onlinelibrary.wiley.com/doi/full/10.1002/jcsm.12554) (Koutnik et al., 2020) [1:40:45]

**Joe Rogan podcast with Elon Musk where they discuss Neuralink**: [Joe Rogan Experience #1470 – Elon Musk](https://www.youtube.com/watch?v=RcYjXbSJBN8) | PowerfulJRE (youtube.com) [1:46:45]

**Elon Musk talking about his new company called Neuralink**: [Neuralink Launch Event](https://www.youtube.com/watch?v=r-vbh3t7WVI&feature=youtu.be) | Neuralink (youtube.com) [1:46:45]

**Neuralink website**: [Neuralink.com](https://www.neuralink.com/)

§

## People Mentioned

- [Tom Seyfried](https://www.bc.edu/bc-web/schools/mcas/departments/biology/people/faculty-directory/thomas-seyfried.html) [2:00, 1:38:30]
- [Angela Poff](https://u.osu.edu/ketodiet/speaker-bios/angela-poff-phd/) [6:45, 1:17:45]
- [Lew Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) [8:15, 25:00, 29:45]
- [Janine Deblasi](https://www.linkedin.com/in/janine-deblasi-39857a101/) [8:30, 17:00]
- [Valter Longo](https://valterlongo.com/) [9:15]
- [Andrew Koutnik](https://www.andrewkoutnik.com/about-me) [18:45, 54:15]
- [Gary Taubes](https://garytaubes.com/) [20:00]
- [Travis Christofferson](https://twitter.com/tchristoff1?lang=en) [27:00]
- [Young Ko](https://www.kodiscovery.org/) [27:00]
- [Richard Berstein](https://en.wikipedia.org/wiki/Richard_K._Bernstein) [55:45]
- [David Ludwig](https://www.drdavidludwig.com/) [1:00:00]
- [Belinda Lennerz](https://www.childrenshospital.org/directory/physicians/l/belinda-lennerz) [1:00:00]
- [Mary Newport](https://coconutketones.com/mary-newport-md-bio-books/) [1:00:45, 1:04:30]
- [Richard Veech](https://www.ketonutrition.org/blog/2020/2/11/tribute-to-dr-richard-veech) [1:01:15, 1:04:30]
- [Stephen Cunnane](https://u.osu.edu/ketodiet/speaker-bios/stephen-cunnane-phd/) [1:04:00]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) [1:04:45]
- [Kristi Storoschuk](https://twitter.com/krististors?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:11:30]
- [Amos Tversky](https://en.wikipedia.org/wiki/Amos_Tversky) [1:28:30]
- [Daniel Kahneman](https://en.wikipedia.org/wiki/Daniel_Kahneman) [1:28:30]
- [James Watson](https://en.wikipedia.org/wiki/James_Watson) [1:28:30]
- [Francis Crick](https://en.wikipedia.org/wiki/Francis_Crick) [1:28:30]
- [Darryl De Vivo](https://www.columbianeurology.org/profile/dcdevivo) [1:34:00]
- [Juan Pascual](https://profiles.utsouthwestern.edu/profile/85158/juan-pascual.html) [1:34:00]
- [Joerg Klepper](https://www.matthewsfriends.org/glut1uk/glut1-experts/) [1:34:00]

§

![](https://peterattiamd.com/wp-content/uploads/2020/06/dominic-dagostino-bio-image-500x500.jpg)

##### Dom D'Agostino, Ph.D.

Dom is an Associate Professor at the University of South Florida where he teaches at the Morsani College of Medicine and the Department of Molecular Pharmacology and Physiology. He focuses on neuropharmacology, medical biochemistry, physiology, neuroscience, neuropharmacology. Dom holds a PhD in neuroscience and Physiology. [See full bio at [KetoNutrition.org](https://www.ketonutrition.org/about)]

Twitter: [@DominicDAgosti2](https://twitter.com/DominicDAgosti2?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Instagram: [@dominic.dagostino.kt](https://www.instagram.com/dominic.dagostino.kt/?hl=en)