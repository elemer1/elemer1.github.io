# #22 – Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins

**Source:** [https://peterattiamd.com/tomdayspring3/](https://peterattiamd.com/tomdayspring3/)

---

##### Check out our 5-part series with Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology:

- *(October 15, 2018)* [Part I of V: An introduction to lipidology](/tomdayspring1/)
- *(October 16, 2018)* [Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](/tomdayspring2/)
- *(October 17, 2018)* [Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](/tomdayspring3/)
- *(October 18, 2018)* [Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](/tomdayspring4/)
- *(October 19, 2018)* [Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](/tomdayspring5/)
- *(September 21, 2020)* [**FOLLOW-UP:** The latest insights into cardiovascular disease and lipidology](/tomdayspring6/)

In this five-part series, Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology, and one of Peter’s most important clinical mentors, shares his wealth of knowledge on the subject of lipids. In Part III, Peter and Tom dig into why “reverse cholesterol transport” is a lot more nuanced than what most of us are taught, lipid transport, apolipoproteins, and more. In addition, this episode highlights the complexity of HDL and a discussion about the CETP inhibitor trials.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tomdayspring3/the_Drive_public.png)

Play

#22 - Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins

#22 - Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins

1x15s30s

0:001:04:13

We discuss:

- Reverse cholesterol transport [1:40];
- Lipid transportation, apolipoproteins, VLDL, IDL, and LDL particles [11:00];
- Remnant lipoproteins and apoC-III [16:45];
- Particles having sex: lipid exchange [28:00];
- Cholesteryl Ester Transfer Protein (CETP) and CETP inhibitors [40:45];
- 2006 CETP inhibitor trial: torcetrapib (Pfizer) [54:45];
- 2012 CETP inhibitor trial: dalcetrapib (Hoffmann–La Roche) [56:15];
- 2017 CETP inhibitor trials: evacetrapib (Eli Lilly) and anacetrapib (Merck) [58:00]; and
- More.

§

## Show Notes

## Reverse cholesterol transport [1:40]

Peter Attia: Let’s define now direct versus indirect RCT ([Dayspring, 2007](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1559-4564.2007.06008.x)).

Tom Dayspring: All right. So if we’re talking about the cholesterol in lipoproteins, at the end of the day, if you have perfect cholesterol homeostasis or for some reason some cholesterol excess in your body, it’s going to wind up in your artery wall, or if you’re lucky it’s going to wind up in your stool, that would be the preferred way. So the body clearly knows beyond a certain point, we don’t want cholesterol, we’ve talked about that at a bit of length so far. So now how can the body get rid of cholesterol that’s already inside us, it’s made by cells, or absorbed from diet, and everybody thinks the liver makes most of the cholesterol. We’re not talking about the brain now, that’s separate. Of the rest of your cholesterol in your body, the liver makes 20% of it, the rest is made in your peripheral cells ([Dietschy et al., 1993](https://www.ncbi.nlm.nih.gov/pubmed/8245716)).

Tom Dayspring: So the bulk of your cholesterol that’s in your body, if your peripheral cells are making too much, it’s got to get out, or that cell will die, so the cells through, even beyond ABCA1 efflux ([Phillips, 2004](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4148835/)) that we talked about, it can free diffuse out of there, there’s another ABC (i.e., ATP Binding Cassette) transporter that can pump cholesterol out, and it gets in a lipoprotein or it binds to albumin, or it binds to a red blood cell and it can be taken elsewhere ([Hellerstein and Turner, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24362356)).

Tom Dayspring: So classically we were taught that a-ha!, the HDL particles are definitely a substrate that a cell can efflux cholesterol out into, especially an empty HDL apo-AI, the protein itself, that’s unlipidated or a real baby HDL particle (i.e., small, immature), very small HDL particle, is a great cholesterol acceptor. And we have membrane transporters that can give them free cholesterol.

Tom Dayspring: So now the HDL has cholesterol, and what were we taught? Well, of course the HDL just brings it right back to the liver, and the liver then will, if it has a need for cholesterol, it’ll use it up, and then it’ll put it in your bile, it’ll go down, it’ll go right out your rear end.

Tom Dayspring: Or your liver can actually change it to a bile salt, which it sends down to bile, and your bile salt could be excreted in the stool. So in effect, that’s a major way of getting rid of cholesterol. But our ileum doesn’t cooperate (Figure 1). Our ileum typically reabsorbs 90% to 95% of the bile salts and reuses them. So it’s not the best way, unless you can make sure that bile salt is being excreted ([Russell, 2009](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1194%2Fjlr.R800026-JLR200)), and we have a drug, the bile acid sequestrants, that makes sure that happens. Then you would deplete internal cholesterol.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-89.png)

**Figure 1. Reabsorption and circulation of bile acids.** Bile acids are reabsorbed at the ileum by specific transporters and pass through enterocytes and into the portal circulation for trafficking back to the liver. They can then be used again. Bile acids that are not reabsorbed back into the ileum are excreted into the stool – this ileal action is a major part of the cholesterol homeostatic forces.

Tom Dayspring: So that’s so simple. So our VLDLs and LDLs, and chylomicrons bring cholesterol to the tissues, and if for some reason there’s too much cholesterol, the HDLs bring it back to the liver, and it goes bye-bye.

Tom Dayspring: Now if you’re talking to a second grader or physician at one point in our careers, that made great sense, that’s plausible, that’s perfect, that’s why HDLs are not delivering cholesterol to the artery wall. They’re bringing it back to an organ that’s going to get rid of it or use it properly. Perfect.

Tom Dayspring: And if the VLDL, chylos (i.e., chylomicrons), and LDLs are bringing cholesterol to the tissues, they never [applied a name to that process], but I would say well that’s *forward cholesterol transport*. And if the HDLs are bringing it back that’s reverse. Perfect. And if we have a great balance between forward and reverse cholesterol transport, that’s good cholesterol homeostasis, you’re not going to get in trouble.

Tom Dayspring: And then we made the mistake of aha, our metrics of these pathways are going to be LDL cholesterol, maybe total cholesterol, or HDL cholesterol, and that’s where the whole thing falls apart. Because those metrics have zero to do with describing the complex flux and trafficking of all these pools of cholesterol. There is no cholesterol measurement in the plasma that tells you anything about that movement, and are your cells building up too much cholesterol, are they not, or [that tell us] you have great reverse cholesterol transport.

Tom Dayspring: So it made such perfect sense, and we were all stupid in medical school, we’re never going to contradict a professor or even give it two seconds worth of thought if somebody told us something like, “The higher your HDL cholesterol, you got great reverse cholesterol transport, because that HDL is going to take it to the liver.”

Tom Dayspring: At a certain point in my studying of lipids, and trying to understand this stuff, and I knew, God, what is it about not everybody with high HDL cholesterol is protected ([Wilkins et al., 2014](https://www.ncbi.nlm.nih.gov/pubmed/24627418))? There are people with low HDL cholesterol who don’t get disease ([Frikke-Schmidt et al., 2008](https://www.ncbi.nlm.nih.gov/pubmed/18523221)). But if what HDLs do is reverse cholesterol transport, and they’re bringing cholesterol back to the liver, shouldn’t your HDL cholesterol go down? Why would HDL cholesterol go up if it was bringing it back to the liver and being internalized or delipidated. That made no sense to me.

Tom Dayspring: So I knew there was more to the story, and of course guys like Dan Rader who has been a mentor to me before, and Bryan Brewer and John Chapman [note from Tom Dayspring: *whom has written a 600-page book, highly recommended:* [Kontush and Chapman, 2011](https://onlinelibrary.wiley.com/doi/book/10.1002/9781118158678)], are among the top HDL experts in this world, have figured this out pretty much by now, saying, “No, this lipid transportation system is way more complex than an HDL bringing it back.” And in those, we give that a different name now, so HDLs indeed are capable of bringing cholesterol back to the liver itself, there is a receptor that will delipidate cholesteryl ester from an HDL, that’s called the scavenger receptor B1 ([Leiva et al., 2011](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.atherosclerosis.2011.05.036)), or SR-B1. There is a holoparticle receptor that can internalize large HDL particles and bring them into the liver ([Martinez et al., 2000](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1021%2Fbi991971y)). But free diffusion can also occur ([Hellerstein and Turner, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24362356)). A big HDL can abut against a hepatocyte and cholesterol just diffuses from the HDL membrane into the liver.

Tom Dayspring: So there are at least three pathways of cholesterol getting back to the liver. That same thing we now know happens at the intestine also. So HDLs don’t even have to go anywhere near the liver. They can go get rid of some cholesterol at the intestine. Remember that TICE pathway, **T**rans**I**ntestinal **C**holesterol **E**fflux. And now we have boggled our minds, and there are great papers on this, red blood cells carry way more cholesterol than do lipoproteins (Figures 2-4). They’re so much bigger. Now granted, the cholesterol is all on your surface, but they have a ton of cell membrane surface, so there’s free cholesterol.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-91.png)

**Figure 2. Reverse cholesterol Transport (RCT) complexities.** Graphic shows lipidation (ABCA1, ABCG1) and delipidation (by SR-B1) or internalization of HDL particles via holoparticle receptor, the transfer of core HDL cholesteryl ester to apoB particles, internalization of apoB (primarily LDL) particles. Also depicted is hepatic transfer of free cholesterol to the biliary system. Not shown is conversion of hepatic cholesterol to bile acids and their excretion into bile. Intestinal pathways also not demonstrated in this graphic.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-94.png)

**Figure 3. Many avenues of reverse cholesterol transport (RCT) – mediated by both apoA-I (HDL) particles and apoB (primarily LDL) particles.** HDLs and LDLs can traffic their cholesterol/cholesteryl ester to the liver or to the small intestine (Transintestinal cholesterol efflux or TICE). If an HDL does the trafficking it is called direct RCT and if the LDL (or other apoB particle) does the process is called indirect RCT. Of course, HDLs transfer a significant portion of their core CE to LDLs and VLDLs using cholesteryl ester transfer protein or CETP). Note also lipoproteins can acquire or deliver cholesterol by free diffusion from membranes and that cholesterol can bind to and be transported by erythrocytes and albumin. Once transported to the enterocytes (by HDLs or LDLs), the cholesterol can be effluxed to the gut lumen by ABCG5/G8 transporters for excretion or it can be reabsorbed by NPC1L1 proteins. Extracting cholesterol from arterial wall foam cells is termed macrophage RCT. Not one of the above pathways is reflected by measuring HDL-C.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-95.png)

**Figure 4.** **Many avenues of reverse cholesterol transport (RCT) – mediated by both apoA-I (HDL) particles and apoB (primarily LDL) particles (continued).** HDLs and LDLs can traffic their cholesterol/cholesteryl ester to the liver or to the small intestine (Transintestinal cholesterol efflux or TICE). If an HDL does the trafficking it is called direct RCT and if the LDL (or other apoB particle) does it the process is called indirect RCT. Once transported to the enterocytes, the cholesterol can be effluxed to the gut lumen by ABCG5/G8 transporters for excretion or it can be reabsorbed by NPC1L1 proteins. Extracting cholesterol from arterial wall foam cells is termed macrophage RCT. Not one of the above pathways is reflected by measuring HDL-C.

Tom Dayspring: The albumin molecule can attach to 17 molecules of cholesterol. So we now know to variable degrees, both red blood cells and albumin can just abut against any cell in your body and accept free cholesterol by free diffusion ([Hellerstein and Turner, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24362356)). An LDL particle can abut against a cell and accept cholesterol by free diffusion from a cell. So now LDLs have another way of acquiring cholesterol.

Peter Attia: That’s interesting, this would be a great question for someone like Josh Knowles, who’s such an expert in FH, but has anybody looked at red blood cell cholesterol membrane concentration, or even size in FH patients. Because one hypothesis would be, especially the FH patients who have FH as a result of LDL receptor deficiencies in some sort, you’d think that there would be more free diffusion of cholesterol from their LDL into their red blood cell.

Tom Dayspring: Yeah, and whether anybody’s ever looked at that, I don’t know.

Peter Attia: That might not be the case at all, but that would be a question.

Tom Dayspring: No, but look theoretically free diffusion can occur between any two membrane surfaces, so do their red blood cells, I would imagine at a certain degree it would cause red blood cell irregularities.

Peter Attia: It’s going to saturate. There might be too much noise, but you’d look at the MCV (i.e., mean corpuscular volume) or something like that, and you’d see have you increased or decreased the mean corpuscular volume of these things, is there anything happening?

Tom Dayspring: I don’t know, you’re changing certainly the membrane structure if that process is occurring in those people, whether that would affect red blood cell functionality. Remember when you start putting phytosterols into red blood cell membranes, you get hemolytic anemias and red blood cell abnormalities, sitosterolemia, phytosterolemia, that’s part of their pathology, because the red blood cell is looking for cholesterol to stay healthy, not phytosterols.

Peter Attia: I didn’t know that, so I didn’t realize that’s one of the hallmarks.

**[10:00]**

Tom Dayspring: Yeah, it’s part of the phenotypic picture of sitosterolemia, is red blood cell hemolytic anemias. Or crazy red blood cell structure spherocytes and things like that, so it’s one way that the early investigators, well this person has anemia, what’s this red blood cell problem that’s going on in this person, too?

Peter Attia: So this is interesting. The HDL story is one where the more time goes on, the less I know. I mean there few things in lipidology that humble me more than my complete and utter buffoonery and ignorance when it comes to understanding high density lipoproteins.

Tom Dayspring: It’s true of all of us, and that’s why I don’t want you reading my 2002 Lipidaholic’s Anonymous Newsletters.

Peter Attia: You’re embarrassed.

Tom Dayspring: Yeah, oh God, I would criticize somebody spouting that stuff today. So only if you read it with that in mind, and you would see how things change.

Peter Attia: Can we use a very specific example to explain this. Let’s talk about the first failed CETP inhibitor trial, which was Pfizer’s, back in the mid 2000s. So let me give the background, and then I want you to explain why this may have failed.

## Lipid transportation, apolipoproteins, VLDL, IDL, and LDL particles [11:00]

Tom Dayspring: Maybe I just ought to explain a little more about the lipid transportation system, so you know what CETP is. So remember I talked about the early on view was forward cholesterol transport, even though they didn’t call it, that’s the apoB family bringing cholesterol to tissues, and the HDL family bringing it back. And here’s why that’s such an absurd theory.

Tom Dayspring: Because when the intestine pumps out chylomicrons, that have a lot of your absorbed cholesterol in it [keep in mind most of that absorbed cholesterol was exogenously produced and delivered to the intestine via the biliary system], and your liver certainly when it manufactures a VLDL particle whose primary purpose, and everybody please listen to this, the VLDL has two purposes, one of which is not to deliver cholesterol anywhere. The liver [via the VLDL]: to transport triglycerides, energy to cells that either store or utilize fatty acids for energy, and also to transport phospholipids.

Tom Dayspring: So that’s what your VLDL and chylomicrons do. So they’re part of the forward cholesterol transportation system. So the liver or the intestine secretes them, and then they’re floating around. So what do they do? They go to adipocytes or they go to muscle cells. Their triglycerides are extracted (i.e., hydrolyzed), and then their phospholipids break off [from the particle surfaces]and are utilized by cells.

Tom Dayspring: So what are you left with when a chylomicron [or VLDL] loses surface phospholipids and core triglycerides? You’re left with a small VLDL, or a smaller chylomicron. Any lipoprotein that goes from a bigger size to a smaller size, but it’s still within the density of a VLDL or chylomicron, it’s called a remnant. It’s just smaller. If Peter just amputated my right arm now, I’d be a remnant of my former self, because I have one less arm. So the VLDLs and chylos have lost their core triglycerides, and they’ve lost their core phospholipids, and a few proteins have broken off (i.e., disassociated) too.

Tom Dayspring: So now what happens to those remnant VLDLs and chylos? They’re virtually instantly cleared by receptors that exist in the liver, primarily. And how do those receptors clear these VLDL particles, and these chylomicron particles that have accomplished their mission of delivering triglycerides? They bind to either the apoB100 that’s on the VLDL, but LDL receptors won’t bind to apoB48 in the chylomicron, but they bind to apoE, and chylos and VLDLs typically, if you’re lucky, have multiple copies of apoE. So as soon as the chylos or VLDLs deliver your energy, deliver your phospholipids, they are cleared, which is why the chylomicron half life is minutes, and the VLDL half life is a couple of hours. Don’t ever confuse half life with plasma residence time, that’s a little bit longer. But that’s only a few particles that are persisting beyond those average half lives.

Tom Dayspring: Now any of the VLDLs that are not totally cleared by the liver, keep getting smaller, they become smaller remnants, but then ultimately change densities to a certain different degree density range. So you can’t call it a VLDL anymore. You call it an intermediate-density lipoprotein (i.e., IDL). The same thing happens, that’s got a half life of an hour, [the IDL is also] cleared, because IDLs have several copies of apoE on it. But at the liver they’re being cleared, there’s another enzyme that transform some of your IDLs into a smaller particle. What’s an IDL remnant called? Well you’d be entering a new specific density boundary. And it would be [classified as] the low-density lipoprotein (i.e., LDL).

Tom Dayspring: So technically, you can say, “Yes, some VLDLs do become IDLs, that become LDLs,” and then the LDLs will hang around forever until the LDL receptor clears an LDL by binding to apoB (Figure 5). The reason chylos, VLDLs, and IDLs, get cleared so much quicker than LDLs is the apoE content, which is a mega ligand for the LDL receptor. The LDL receptor is really an apoB/apoE receptor and there are other apoE receptors, too. So that’s why those particles don’t last long.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-96.png)

**Figure 5. ApoB-containing VLDL particles are secreted by the liver and undergo lipase mediated hydrolysis of triglycerides (TG), c****ausing the VLDL size to shrink (core TG and surface phospholipids are lost).** VLDLs also exchange their core TG for cholesteryl ester (CE) with HDLs (that is termed heterotypic exchange) Thus as VLDLs lose TG, they often gain CE (become cholesterol-rich) and simply return it to the liver (thus VLDLs are also part of the indirect reverse cholesterol transport process). As VLDLs lose their lipids they become smaller and denser and are called IDLs. After further lipolysis, the IDLs, if not cleared by LDL receptors, become LDLs. The LDLs, because they do not have apoE, have a much longer half-life than VLDLs and IDLs, and also gain additional CE from HDLs. Ultimately, the LDLs are cleared at the liver, completing the indirect RCT process. Thus the major function of an LDL is RCT. Of course, if there are too may LDLs or inefficient clearance by LDLR, the LDL-P level rises, and LDLs enter arteries (primarily driven by particle number). Also note that HDLs can exchange core lipids with each other in the process called homotypic exchange.

Peter Attia: And just to interrupt you for a second, apoE greatly amplifies the efficacy of that ligand, the apoB ligand?

Tom Dayspring: It is a preferred ligand for either an LDL receptor: they’re called LDL receptor-related receptors.

Peter Attia: I want to come right back to this, but I know I’ll forget to ask. What percentage of LDL particles also coexpress apoE?

Tom Dayspring: If you are lucky enough to have that genetic gift, it’s half life is pretty much the same as an IDL. They’re gone.

Peter Attia: You just can’t clear those things out.

Tom Dayspring: You have an enhanced clearance. Your apoB, your LDL particle level will be much lower. You don’t get heart disease. In an average population it’s about 3 to 4% [i.e., about 3-4% of LDL particles will contain apoE]. But I guarantee there are, depending on genes you inherit, some people probably have a lot of apoE on their LDLs. And of course I would bet, if they were studied genetically, they don’t get heart disease because it’s being cleared, all those particles. And we’ll talk about it later but there are other apoproteins that can retard clearance of VLDLs, IDLs, and even LDLs. I’ll just mention its name now. It’s apolipoprotein C-III (i.e., apoC-III). You got that on your particles, you’re going to have seriously increased plasma residence time on all those things. And LDL with apoC-III on it is intensely more atherogenic than an LDL that only has apoB100 on it.

## Remnant lipoproteins and apoC-III [16:45]

Peter Attia: We were shooting the breeze one day by phone and I remember you saying that if you could add one clinical assay to the arsenal of lipidologist it would be an apoC-III assay. Is that still true?

Tom Dayspring: It would be because I think that’s going to be the way we really smartly identify remnant lipoproteins that are the VLDLs that are potentially causing trouble. Most VLDLs are not troublemakers. They’re cleared rapidly. Or the LDLs that are number one on the list as to what’s going in your arterial wall. ApoC-III, as you know Peter, is overexpressed in insulin resistant situations. So I have no doubt that one day that would be a cool test unless maybe we can just measure your genetics, the genes that give you apoC-III.

Peter Attia: Except that insulin sensitivity and insulin impacted would suggest that if you took two people with the same lipid profile at the lipoprotein level but one had higher apoC-III than the other, that person’s at higher risk.

Tom Dayspring: And I think we got enough data now that shows that. And to show you pharma believes that, there’s a a major trial ongoing now with an apoC-III inhibitor that’s coming because it will be the way to get rid of an extremely atherogenic-

Peter Attia: Is this Isis [now called Ionis/AKCEA] doing this?

Tom Dayspring: Believe so. Yeah.

Peter Attia: Oh sorry, just for the listener, Isis: there’s a pharma company in San Diego [that went by this name].

**Note from Tom Dayspring**: Another technical error I(we) made was the confusion of the antisense oligonucleotide drug being produced to inhibit synthesis of apo(a). I forgot the company, for obvious reasons, changed its name from ISIS to Ionis and then formed a wholly owned (by Ionis) subsidiary called AKCEA for the antisense drugs a few years ago. But the drug, which was called ISIS-APO(a), has changed. They also had ISIS-APOCIII Rx. Now referred to as AKCEA-APO(a)-L Rx, AKCEA-APOC-III Rx, and a new one, AKCEA-ANGPTL3-L Rx.

Peter Attia: And they’re looking at antisense oligonucleotides (i.e., ASOs).

Tom Dayspring: So, keep your fingers crossed.

Peter Attia:We should come back and talk about that because the anti-C-III and the antisense oligonucleotides against apoprotein(a), those are hugely interesting.

Tom Dayspring: They’re going to probably be great therapeutic avenues for us if we need it. I think there will be utility for measuring this right now before a third party payer is ever going to pay some lab for doing that. It’s going to need little more proof then what we have so far.

Tom Dayspring: But back to our lipid transportation system. Please understand: there are just too many people out there who think every VLDL becomes an LDL. It’s not even close. (Figures 6 and 7) And, in fact, if you are not insulin resistant, and you don’t have a triglyceride issue, which I might define as a trig above 130 or so, 40% of the apoB particles coming out of your liver are not VLDLs, they’re LDLs. And the VLDLs that are coming out are not big because they’re not carrying extra triglycerides because you don’t have them. They’re just carrying some degree of cholesterol and a little bit of triglycerides to supply the energy you really need.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-97.png)

**Figure 6. Hepatic apoB-lipoprotein secretion.** Classic lipid teaching is that during lipolysis VLDLs become IDLs which become LDLs. Note depending on whether TG levels are > 135 mg/dL, about 40% of LDL are directly secreted from the liver and are not the result of VLDL lipolysis. As TG levels rise more LDLs are the result of VLDL lipolysis.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-98.png)

**Figure 7. Overview of apoC-III in TG metabolism.** ApoC-III retards the lipolytic action of LPL in muscular and adipocyte beds and prevents LDL-receptor mediated clearance of apoB particles.

Tom Dayspring: And that’s why if you are measuring some VLDL metric, big VLDLs occur only in triglyceride-rich lipoprotein pathologies, by far the most common of which is insulin resistance. But, clearly, because that VLDL would come out, and I guarantee you it’s probably got apoC-III on it, it doesn’t have a half life of a few hours. It’s plasma residence time is much longer.

**[20:00]**

Tom Dayspring: There is more conversation of that VLDL particle into LDL particles which would be triglyceride-rich through some transformation they become the small LDLs which are even less rapidly cleared. So your apoB particle number, your LDL particle number goes through the roof.

Tom Dayspring: Now, yes, part of those apoB are the remnants, but I’ve posted enough slides on Twitter. Even when you take these type 2 diabetics with severe insulin resistance, or insulin resistance just proved by an insulin clamp study, their apoB levels, their particle levels are going up.

Tom Dayspring: But the LDL particles go up astronomically and the VLDL maybe doubles or triples. It goes from 30 to 90. Whereas the LDL particles go from 1,000 to 3,000.

Peter Attia: That’s an important distinction. A lot of people will say when you’re insulin resistant, all of that net difference that we see, because there’s no disputing, the more insulin resistance you get the more discordant you get between your LDL-P and your LDL-C. And all things equal, the LDL-P is just going up and up and up as you become more insulin resistant. So people will say, it’s all the VLDL. Furthermore they’ll confuse a percentage increase that’s relative with an absolute increase. So, as you pointed out, you’re referring to the Garvey paper, I think?

Tom Dayspring: Yes.

Peter Attia: Yeah. In that paper, you might see VLDL particle number: I’m making this up, so someone will see the numbers and decide for themselves, but it might go from 30 to 60 ([Garvey et al., 2003](https://www.ncbi.nlm.nih.gov/pubmed/12540621)) (Figure 8).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-99.png)

**Figure 8. NMR lipoprotein particle concentrations in insulin sensitive, insulin resistant, and T2D patients.** Regardless of insulin sensitivity or even the presence of T2D, the vast majority of apoB particles are LDLs.

Tom Dayspring: Yeah, or 150 even.

Peter Attia: Nanomole per liter. And you think, “Well, God. That’s a much bigger relative increase.”

Peter Attia: And it is, but if anybody’s read our lengthy treatise on relative versus absolute risk, you cannot evaluate a relative change without understanding it’s absolute change. And, even though the relative change in the LDL-P is smaller, it’s starting from such a high base, that it might add 3 to 400 nanomole per liter, which might only be a 30 or 40% increase but that absolutely dominates the lion’s share of the increase. Not the extra 30 to 50 nanomole per liter you might get on the VLDL.

Peter Attia: That’s a really important point if you want to be a lipid geek.

Tom Dayspring: It is. And this is one reason why non-HDL cholesterol is becoming en vogue. Because remember, non-HDL cholesterol, we told you, you calculate it by subtracting HDL cholesterol from total cholesterol but you could really add directly measured LDL cholesterol to a VLDL cholesterol, your cholesterol that is not in your HDL particles, theoretically, potentially atherogenic cholesterol. And, hey, that’s a free calculation, too. So, they use non-HDL cholesterol as a marker of remnants.

Tom Dayspring: Okay. And there’s no doubt some of those VLDL particles would be remnants but we’ll get into this later, I hope. I’ll make a case that a lot of those VLDL particles are not remnants and they’re not going into your heart arteries.

Peter Attia: Yeah, it’s funny, I used to always sit a patient down and the very first time we reviewed a blood test, I would say, “Look, there’s four things we’re going to talk about from a lipid standpoint. We got to know your Lp(a)” Excuse me. “We have to know your LDL-P. I would like to know how many of those are small, because it’s a proxy for some other stuff. And I want to know your VLDL remnant. I can’t measure that so we’re going to approximate it with VLDL-C.”

Peter Attia: Well, I don’t say that anymore.

Tom Dayspring: You really shouldn’t.

Peter Attia: That’s a very crude, crude estimation that’s almost useless.

Tom Dayspring: I wouldn’t call it useless.

Peter Attia: I used the word almost in front of it.

Tom Dayspring: And I’ll get all my lipid colleagues real mad at me if I start saying that because I get into this in a lot of the papers that we do.

Peter Attia: And we still say to patients, “I want your VLDL cholesterol less than 15 milligrams per deciliter.”

Tom Dayspring: And the odds are good in an insulin resistant patient you have other ways of knowing who’s insulin resistant and who’s not. If that marker is up, remnant lipoproteins are part of their pathology. But the exact same therapy I’m going to give you to get rid of the real troublemaker, your LDL particles, is going to get rid of the remnants, too. At the end of the day I’ve got to normalize apoB or LDL particle number and there is significant discordance. Allan Sniderman has published it many times, as good as non-HDL cholesterol, meaning better the LDL cholesterol is a metric of apoB, there’s a lot of discordance between apoB or LDL particle number and non-HDL cholesterol.

Tom Dayspring: So, I understand it’s a free calculation. Please, in people who you really are worried about or you think at risk, you’ve got to use particle numbers to make the proper clinical decisions.

Peter Attia: This reminds me, I need an excuse to get up to Montreal so I can interview Allan.

Tom Dayspring: If you can get him on a podcast, I’ll be your first listener. Nothing comes out of his mouth that you don’t want to write down.

Peter Attia: Allan is a special guy.

Tom Dayspring: He is. And Allan is not afraid to call a spade a spade, so to speak. He will just tell you. And that’s why I love him. I don’t mind Allan telling me I’m an idiot. “No, Tom you’re wrong on that. Here’s the way it is.” You learn from guys like that who are not afraid to put you in your place.

Peter Attia: Allan if you’re listening to this, why don’t you come up with an excuse to come to New York or San Diego, and if I do have an excuse to come to Montreal, I will.

Tom Dayspring: But let’s get back to our lipid transportation system now. So we have our theoretical forward delivering particles, the apoB particles, and they tell you how they transform into one another, how they deliver their cholesterol. By the way, no VLDL or IDL or chylo is delivering cholesterol to your peripheral cells. They don’t need it. They’re [i.e., the cells of the body] making all they need.

Peter Attia: Just restate that please for the court’s transcript. So, tell me again. What chylos are not doing what?

Tom Dayspring: You walked out of the room to do something when I was explaining what chylos and VLDLs

Peter Attia: Tom just outed me. I went to go take a leak a minute ago. But alright.

Tom Dayspring: I explicitly went over that the purpose, the functional purpose of chylomicrons in VLDL, is to deliver energy in the form of triglycerides. To the adipocytes and myocytes and phospholipids, not to deliver cholesterol to any darn cell in your body. Just spend your time reading on it. That’s what they do. You could even make the case that if they’re not delivering cholesterol, why is cholesterol even in their particles? And it goes back to something what Peter said. These particles have to be spherical. So when a VLDL or an enterocyte is starting to lipidate apoB48, or especially the liver, apoB100, if you put cholesterol in that, and we have proteins that do that, microsomal triglyceride transfer and other cellular lipid transport proteins. By putting cholesterol on the apoB, it becomes a spherical particle. So all primordial VLDLs and chylomicrons are first just very cholesterol rich spherical particles. They don’t have the triglycerides yet.

Tom Dayspring: Then, when they’re a spherical particle they can really fill up with their triglycerides. So the cholesterol is in there for a structural property to make them spherical particles so that they can carry more triglycerides. And that’s why when they go out, they become smaller spherical particles that are triglyceride-depleted and they just bring that cholesterol back to the liver or the intestine and then they [i.e., hepatocytes and enterocytes] do whatever they do with it.

Tom Dayspring: So, that’s why cholesterol’s in there. They’re not bringing cholesterol to my nose or your kidney or any place else because those cells need cholesterol. Those cells will make it or they’ll get it by some freak diffusion if they really need it. Or, absolutely, virtually any cell if it absolutely needed cholesterol because for some reason, the synthesis was broken, any cell could ultimately upregulate an LDL receptor, but most of them don’t because they have no need for the cholesterol that’s in an LDL. The liver upregulates most of your LDL receptors because that’s involved the clearance of these particles. That’s [i.e., hepatocytes] where your LDL receptors are heavily expressed.

## Particles having sex: lipid exchange [28:00]

Tom Dayspring: But now you do have these particles that have certain half lives or plasma residence times. VLDLs even for a few hours, or LDLs for at least a day, in some instances more. HDLs for a few days. So are they stagnant particles that never change? No. Guess what? They’re living breathing particles. I used to have animated diagrams of this. Every second of every minute of every day your particles are having sex with one another. They’re transferring bodily fluids. They exchange, from their core, every lipoprotein in your body has some degree, in it’s core, of triglycerides and cholesteryl ester. Every particle from an HDL to a chylomicron to a VLDL, IDL, and LDL.

Tom Dayspring: And we actually have a protein that’s pretty much carried on HDLs. It was originally called apoprotein or apolipoprotein D, as in dog, capital D. And in my dirty New Jersey mind, think of an HDL particle which carries most of the apoD. Men carry something between their legs that if it got erect, it’s sticking up and it can penetrate something else. So if HDLs are carrying this apoD and it suddenly sticks up, it can penetrate another particle, be it another HDL, or an apoB particle.

Tom Dayspring: And that’s a phospholipid sort of tunnel. It’s like a little tunnel that can connect to circulating lipoproteins and therefore the core lipids can exchange.

Peter Attia: And this is HDL to HDL? Or can it be HDL to LDL?

Tom Dayspring: It can be HDL to HDL, in which case it’s called a homotypic transfer because it’s two like particles exchanging their bodily fluids (Figures 5 and 9).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-100.png)

**Figure 9. Mediated exchange of core lipids.** Slide demonstrates the CETP tunnel-like structure through which particle core CE exchanges for TG in a homotypic or heterotypic fashion.

**[30:00]**

Tom Dayspring: Or heterotypic where apoA particles exchange their core lipids with apoB particles. What is hardly known out there is two apoB particles can exchange their lipids. A VLDL can exchange it’s core lipids with an LDL. And I’m going to tell you, that’s where remnants get a lot of their cholesterol.

Tom Dayspring: So, that would be homotypic exchange of cholesterol and triglycerides between two different apoB containing particles. So a lot of it is between HDLs and apoB particles, and why? Why would we even be given that lipid transfer protein? Because HDL’s job is to be a great cholesterol acceptor. It is very important in delipidation. Helping cells efflux the cholesterol they don’t want. When an HDL acquires that free cholesterol from a cell, what does it do? Well, HDL carries that ACAT like enzyme I talk about, except it’s called LCAT because it’s in a lipoprotein. It esterifies the cholesterol to cholesteryl ester. It goes to the core of the particle, the HDL becomes bigger, then the HDL transfers it’s cholesteryl ester to, let’s say an apoB particle, 95% of which are LDL particles. So here’s where the joke comes in. I know you’re all calling the cholesterol in HDL, that’s *good cholesterol*. But what do you call that cholesterol molecule, the second an HDL transfers it to an LDL? Does it instantly become, “Oh, it’s bad now.” If I looked at it, it’s still the exact same cholesterol molecule. If you want to use those darn adjectives to a patient, I guess what’s going to determine what’s good or bad cholesterol is, what is that lipoprotein going to do with it’s cholesterol molecule? If it’s an HDL and it’s an LDL, and it’s bringing it back to the liver or the intestine, well, that’s not bad because those organs know how to get rid of cholesterol. So, I don’t know, maybe that’s a good cholesterol pathway. But I don’t think you can apply that to the cholesterol molecule itself.

Tom Dayspring: But follow me here. What if that HDL pulled cholesterol out of your cell because it was over-producing too much and it gave it to an LDL and said, “Buddy, take off. The liver has got that LDL receptor. It’s going to clear you.” And that LDL particle raced back to the liver and for some reason, there was no LDL receptor so there weren’t enough of them there. Where is that LDL going?

Peter Attia: He might wind his way back into circulation.

Tom Dayspring: He will because he’s not going to be cleared.

Peter Attia: He might wind his way back to the endothelium.

Tom Dayspring: Right to the endothelium and all of a sudden your good cholesterol is in the macrophage in your arterial wall. So, spare me the nonsense. Stop using this absurd term. It has no meaning. You’re miseducating patients if you tell them it’s good cholesterol. Because they use that because they’re measuring HDL cholesterol in the blood as a marker that I’m in good shape or not. Trust me, virtually all of the early trials that showed low HDL cholesterol was bad news were never, ever adjusted for apoB or LDL particle counts.

Peter Attia: And that includes Framingham, which I alluded to earlier. Because a lot of people like to hang their hat on the fact that Framingham. Most people forget what Framingham is. They throw the term around, so let’s me just spend one minute explaining this. Framingham started out as a five geography, a five city, or five region, observational study, purely observational. Of which Framingham was one.

Tom Dayspring: Framingham was only Framingham, Massachusetts [see: **[Mahmood et al., 2014](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(13)61752-3/fulltext)**].

Peter Attia: But the original cohort of that study from NIH was Framingham, Puerto Rico, San Francisco, Honolulu [**This is incorrect: the Framingham Heart Study began independently in 1948. Framingham was later invited to participate in a study ([Castelli et al., 1977](https://www.jclinepi.com/article/0021-9681(77)90082-0/abstract)) that included the cohorts Peter mentions here**.]

Peter Attia: And that’s where they gathered the information. That’s where they made the observation. So there was a purely retrospective assessment of five cities and I’m blanking on the 5th.

**Note**: The populations Peter is referring to were all inependently established epidemiological studies prior to a collaborative effort by the NIH – drawn from Albany (year began: [1953](https://www.epi.umn.edu/cvdepi/study-synopsis/albany-cardiovascular-health-center-study/)), Framingham ([1948](https://www.epi.umn.edu/cvdepi/study-synopsis/framingham-heart-study/)), Puerto Rico ([1965](https://www.epi.umn.edu/cvdepi/study-synopsis/puerto-rico-cardiovascular-disease-study/)) Evans County ([1960](https://www.epi.umn.edu/cvdepi/study-synopsis/evans-county-cardiovascular-and-cerebrovascular-study/)), Honolulu ([1965](https://www.epi.umn.edu/cvdepi/study-synopsis/honolulu-heart-study/)), and San Francisco (1965, part of the Honolulu Heart Study in men of Japense ancestry) – in a study that measured and analyzed triglycerides, total cholesterol, HDL cholesterol, and (calculated) LDL cholesterol ([Castelli et al., 1977](https://www.ncbi.nlm.nih.gov/pubmed/191465)).

Peter Attia: But anyway, the point, but the prospective work was then concentrated in Framingham, Massachusetts [**statement is incorrect — Framingham was a novel, new study started after WWII, see: [Mahmood et al., 2014](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(13)61752-3/fulltext)**]. But the point is, a lot of people like to point out that LDL is irrelevant because the LDL cholesterol, which by the way, was calculated, not measured directly.

Tom Dayspring: And, years later, not in the first 20 years of the study.

Peter Attia: Correct. It turned out to be less predictive then the absolute level of HDL-C and triglyceride. A lot of people like to stop at that and say, “Look, that means LDL doesn’t matter.” What they don’t realize is those are two enormous proxies for apoB.

Tom Dayspring: That’s all they are. And virtually all of your insulin resistant patients are getting atherosclerotic disease. It’s apoB. It’s LDL particle mediated because everybody who’s not on a drug or a serious diet who had a triglyceride HDL cholesterol axis abnormality has astronomical apoB.

Tom Dayspring: So, if you go back for all of this cited forever epidemiologic data that low HDL cholesterol is such an important risk factor, do me a favor pal, adjust it for apoB or LDL-P, which was never done and can’t be done in those studies now. It would disappear as an independent risk factor, low HDL cholesterol (statement is incorrect — see: [Toth et al., 2013](https://www.ncbi.nlm.nih.gov/pubmed/24079290)).

Peter Attia: Well, that’s certainly the hypothesis. I mean, I guess, the question is, does MESA still have enough data kicking around, enough blood kicking around to measure that. Or Framingham offspring might.

Tom Dayspring: It does. MESA has certainly shown in the discordant people, where there’s a discordance with apoB and LDL cholesterol. Or, in people who have low HDL cholesterol, apoB, LDL particle is your most important metric.

Peter Attia: And MESA, when we’re saying this, by the way folks, we’re not talking Mesa, Arizona, we’re talking about the Multi Ethnic Study of Atherosclerosis, which is abbreviated MESA. So, you’ll often hear people refer to MESA and Framingham. What they’re referring to are enormous studies of atherosclerosis that still have biobanks that are available to do these retrospective analyses on prospectively collected samples.

Tom Dayspring: MESA’s much more contemporary and multi-ethnic.

Peter Attia: Another criticism of Framingham is, “You’ve taught me a lot about middle class white people and the Northeast, but what have you told me about African American, Hispanic, etc.?”

Tom Dayspring: All information is always good. There’s always weaknesses with all information or shortcomings or so. But, we build step-wise on it. So, before you declare and make any statements based on an HDL metric, please make sure you have an LDL particle or apoB metric in front of you also: and pretty much base what you’re going to advise a patient on risk and assessment based on that.

Peter Attia: So, one of the most amazing papers you ever sent me, and this was actually kind of recent. I feel like this was maybe a year ago, maybe a year and a half ago, was a case study of a woman who had an HDL cholesterol of about 130 to 140 milligrams per deciliter. So, for the listener, you just never see levels of HDL like that unless you work in the lipid community or you’re a lipidologist. Which means I don’t see them because I’m not a lipidologist. I just pretend to be one.

Peter Attia: But, the average person, the average female might walk around with an HDL cholesterol of 60 milligrams per deciliter. So this woman is showing at two and a half times normal. And interestingly, I don’t know even know if you remember this case study, Tom, but if not I think I remember enough of the details. She had very accelerated atherosclerosis. She did not, by the way, to my recollection, have particularly elevated LDL cholesterol. Her LDL cholesterol was probably about 110 milligrams per deciliter, slightly below her HDL cholesterol.

Peter Attia: And, of course, the question was, why did this woman have elevated atherosclerosis when she had normal amounts of quote, unquote, “the bad cholesterol”, and two and a half to three times normal good cholesterol? Do you remember this case?

Tom Dayspring: It’s been well explained. And this is a rare genetic thing where this cholesterol trafficking pattern is disrupted in certain ways. Something’s wrong with that pathway because that HDL should be getting rid of its cholesterol and it should be bringing it back some place. So, this person would have to have incredibly massive HDL particles that are carrying way more cholesterol particles per HDL particle than it should be. And it turns out, and they’re not being cleared as much as they should. So this is going to turn out to be cholesterol-rich HDL particles that don’t have a protein that’s very integral with clearing HDLs, and apoE again.

Tom Dayspring: So, if you don’t have apoE on your HDLs they might become cholesterol-rich. Your HDL cholesterol’s through the roof, those are incredibly dysfunctional HDLs. And part of their disfunction is they’re probably carrying the wrong type of phospholipids and they’re not carrying the type of protective proteins that an HDL should be carrying. Because when you have a surface area that’s that big, the proteins that should be binding to it no longer bind because they’re looking for the molecules they’re supposed to covalently bind to and they can’t find it. So, that’s the circumstance of a very dysfunctional HDL ([Remaley, 2015](https://www.ncbi.nlm.nih.gov/pubmed/25634835)).

Peter Attia: And now I remember the context which was a really good friend of mine from med school sent me a friend of a friend’s blood and the numbers were like that. And I remember reaching out to you saying, “This is odd, Tom. What do you make of this?” You sent me the case study. There’s really nothing to do to treat these people except lower apoB, right?

Tom Dayspring: You just have to chase, it’s sort of like what do we do for Lp(a) now. You chase every other identifiable cardiovascular risk factor. Interesting, nobody would do it to her, but there is a product that induces a receptor in the liver that pulls cholesterol out of HDL particles. It’s called probucol ([Zhao et al., 2011](https://www.ncbi.nlm.nih.gov/pubmed/21840001); [Tardif et al., 1997](https://www.ncbi.nlm.nih.gov/pubmed/9241125)). I don’t know if it’s even still available by prescription. It induces the scavenger receptor, it drastically lowers HDL but it’s a powerful antioxidant. And there were some really arteriographic studies that suggested, “This is good.” Arteries, at least on an arterial imaging look better. So say apoA-I Milano.

**[40:00]**

Peter Attia: Just to be clear, there’s 217 ways to be fooled by an angiogram. It’s about as crude a way to access this process as anything. That said, if you believe that this is improving, you believe it’s basically increasing the throughput of HDL to delipidate.

Tom Dayspring: Yeah. So, the theory would be, this is the case where, hey, remember I espoused the theory before that if HDLs are really delivering cholesterol back to the liver, shouldn’t HDL cholesterol be going down? Well, here’s a drug that depletes HDL cholesterol and, at least arteriographically ([Tardif et al., 1997](https://www.ncbi.nlm.nih.gov/pubmed/9241125)), people look better. We now have identified a gene that regulates the functioning of the scavenger receptor ([Hoekstra and Sorci-Thomas, 2017](https://www.ncbi.nlm.nih.gov/pubmed/28301373)), so if you have an inactivity of that scavenger receptor, you have very big HDL particles, high HDL cholesterol, and coronary atherosclerosis.

## Cholesteryl Ester Transfer Protein, better known as CETP, and CETP inhibitors [40:45]

Peter Attia: So, this is a nice transition. Let’s summarize that. This is, again, overly simplistic. This is a zero order analysis. We’re just going to put our 4th grade hats on which is acceptable for limited periods of time. If you have low HDL-C, you cannot infer if it’s low because you’re failing to quote, unquote, “pick up cholesterol,” or because you’re delivering it quickly.

Tom Dayspring: You don’t know.

Peter Attia: Conversely, or similarly I should say, if you have high HDL-C, it is not clear if it is high because you pick up a lot, which in theory would be quote, unquote, “good,” or because you’re deficient at dropping it off which would be quote, unquote, “bad.”

Tom Dayspring: Right.

Peter Attia: And therein lies, perhaps, one of the most interesting, or certainly top five interesting, drug stories which are these CETP inhibitors.

Tom Dayspring: Right. So I told you HDL has this apoD. But apoD is better known as cholesteryl ester transfer protein. It really ought to be called cholesteryl ester triglyceride transfer protein. C-E-T-P.

Tom Dayspring: So, we’re going to talk about a CETP inhibitor in a moment because it’s going to stop that process. The lipoproteins can’t exchange between the particles anymore. Now, wait a minute, if you’re following me so far, an HDL which is pulling cholesterol out of cells, it’s really good at that, is then transferring a lot of that cholesterol to LDLs. Here’s something that’s going to shock you. In an average person, **anywhere from 30 to 60% of the cholesterol in that LDL particle arrived via an HDL particle**.

Tom Dayspring: So, if that LDL particle will accept that cholesterol from an HDL and race it back to the liver, “Thank you, LDL.” It’s like the HDL was a quarterback, it passed it to the tight end who ran it across the goal line. Who gets the credit? The quarterback, or the tight end, or both of them? So, in the lipid transportation system, they work harmoniously together if everything works including the lipid transfer proteins.

Tom Dayspring: We’re not going to talk about it today, but God also gave us lipid inhibitory transfer proteins, apolipoprotein F. ApoC-I. So, everything is tightly regulated in our homeostatic system. But, we’ll leave that for another day.

Peter Attia: Yeah, so if this is the master’s class on lipids, that will be the whatever falls above a master class.

Tom Dayspring: So, it’s always more complicated. Now, just to finish up the definitions of our reverse cholesterol transport (Figures 2-5, and 9), all day it’s HDL back to the liver. Nowadays, it’s HDL gets cholesterol from wherever. If things go right it could bring it back to either the liver or the small intestine or an adrenal gland or an ovary or a testis. So, that’s going to be called direct, because the HDL is doing it. We’re saying HDLs the primary factor here because it does pull cholesterol out of the cells.

Tom Dayspring: But we now also know that HDL can give it’s cholesterol to an LDL, to a VLDL, to a chylomicron, to an IDL. Since most of them are LDLs, it’s giving most of it to an LDL. And they can bring that cholesterol. They’re going to be cleared at the liver if you have the proper number of LDL receptors. So, if an HDL give it’s cholesterol to an apoB particle, it brings it back to the liver. That is called *indirect reverse cholesterol transpor*t.

Tom Dayspring: We’re still debating, can an LDL bring it back to the small intestine also? For awhile that was *yes*. Then it was *probably no*. Now it’s back to a *probably yes* again. But, if an LDL brings it back to the liver for sure, and the intestine, then that’s *indirect cholesterol* or *reverse cholesterol transpor*t if you still need the *reverse* adjective put in there. But, part of that pathway is, it’s not the liver, it’s the intestine. The transintestinal cholesterol efflux.

Tom Dayspring: So if you want to talk about total reverse cholesterol transport, I would rather just talk about lipid transport. It’s every particle is part of the system. But, if you want to stick with *reverse cholesterol transport*, total RCT is the sum of indirect plus direct. And both direct and indirect involve the liver and the intestine. And a serum HDL cholesterol tells you nada about that process.

Peter Attia: We may or may not have time to get into this, but yesterday over dinner we talked about the futility, or *challenges* is maybe a better way of saying it, to be a little more optimistic. But the challenges in coming up with HDL functional assays, because that’s, once you get deep enough into this topic, as we’re getting now, you very quickly start to realize that to measure HDL cholesterol, or even HDL particle number, is so crude in terms of providing an insight into it’s functional status, that the best we can do today is we measure HDL cholesterol, HDL particle number and HDL particle size, and we try to triangulate, just as we used to when we could look at Lp(a) mass and Lp(a) cholesterol, we could sort of triangulate if we were in the zone. But, that’s still not the answer. That just doesn’t tell us how well these things function.

Tom Dayspring: We just need more specific biomarkers nowadays to take it to the next level and the types of therapies that are coming along. And I think that’s even important knowledge to know when you’re going to prescribe a specific nutritional therapy also. That all these things come into play. You know?

Tom Dayspring: So, very important to understand this stuff but I hope you can see how this world has changed and we ought to stop even using the term *reverse cholesterol transport*. It’s idiotic. It’s so immensely complex, you don’t know what you’re talking about. And you have no biomarker that you can evaluate that on a given patient. And the functionality of these particles, do they really participate in these pathways, or not, are determined, in large particles, by their phospholipid content and in the proteins that are on these surfaces apart from just the apoD we talked about.

Tom Dayspring: And, with HDLs, just briefly, I think there’s probably hundreds of HDL subpopulations. HDLs carry an immense number of proteins, way more than LDLs or VLDLs ever can. But they all can carry one or two proteins. They can’t carry 200 proteins that have been identified as coming from HDLs. So, it’s probably the protein signature of an HDL, or even a phospholipid makeup, the lipidome of an HDL. Just like, you know I love fire departments. Fire departments have hook and ladder trucks, they have pumper trucks, they have hazmat trucks, they got a variety of rescue vehicles nowadays. They got ambulances, rescue trucks, and they don’t all show up at every fire. The dispatch sends the trucks that are needed to specific types of fires. Well, your HDL subpopulation show up where they’re needed. They know where they’re needed because the cells that need them, recognize the proteins or the phospholipids that are on the surface and pull them in.

Tom Dayspring: So, I don’t know whether it’s going to come down to lipidomic or proteomic analysis of these particles I think that maybe will take us to the next level. Wouldn’t hold your breath on that anytime soon.

Peter Attia: All right, so I want to start talking a little bit about some drugs. But, rather than start chronologically, which I want to do after we get to this question, but just because while we’re on HDL, there are really two drugs that have been discussed as ways to “raise HDL.” One being niacin, which we’ll come to later on, but the other being these CETP inhibitors, which are relatively recent. It was 2006 when the first CETP trial, at least when the first data became available, and they weren’t promising ([Tanne, 2006](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1702474/)). So, first of all, why would inhibition of CETP been thought to be an optimal strategy, and two, why do you think it didn’t turn out that way?

Tom Dayspring: Because we don’t know what we’re doing with HDLs, and especially using metrics to analyze them. And the story starts a lot longer than that, in Italy. That little section up on northeastern Italy where apoA-I Milano was discovered, and these were people who had HDL cholesterol levels of five and 10 and yet had longevity and how could that possibly be, because Framingham has taught us, Low HDL cholesterol? You’re out of here.” And yet, here were people with longevity, and it turns out they had a very functional apoA-I that really did the flux system very quickly or had other properties that didn’t matter how much cholesterol was in the HDL. The HDL was unbelievably functional.

Peter Attia: Do you know anything about their apoB’s?

Tom Dayspring: That’s probably out there. I can’t answer that off the top of my head.

Peter Attia: So maybe we’ll look that up if we can, but they’re high functioning apoA-I.

Tom Dayspring: Yeah.

Peter Attia: Seems to have protected them.

Tom Dayspring: I doubt if apoB matters, because some of them probably would.

**[50:00]**

Tom Dayspring: Although, they’re all on that Mediterranean diet, so maybe they don’t have the atherogenic part, so I can’t answer that. So, that led pharma to, “Hey, let’s just invent, either synthesize apoA-I, or a truncated apoA-I and commercialize that, at least for people who have had acute coronary syndromes. We’ll infuse that into them, it’ll delipidate their plaque, and they’re home free.” Every single trial failed, including a very recent trial.

Tom Dayspring: But, you know, there were people in the past that Peter talked about. He gave a case where a woman had very high HDL cholesterol, but had coronary atherosclerosis, but there is a bunch of people out there with very high HDL cholesterol who don’t have[heart disease.] I’m going to theorize in retrospect maybe apoE’s got something to do with that, but I don’t know that, because that would enhance their clearing ([Qi et al., 2018](https://www.ncbi.nlm.nih.gov/pubmed/29217413)).

Tom Dayspring: But, what is one of the genetic conditions that would give you high HDL cholesterol? Well remember, I just taught you what apoD is: CETP. It takes the cholesterol out of your HDL and gives it to an apoB particle, so theoretically, that would lower your HDL cholesterol. But if I inhibited CETP, your HDL would get to keep all its cholesterol. Well, it would go through the roof, your HDL cholesterol, and the genetic model was at least some people with certain CETP variants had very high HDL cholesterol, and they didn’t seem to get much heart disease.

Peter Attia: Although, what I’m confused by, Tom, is that in 2011-ish, didn’t a Mendelian randomization look at this and conclude that those people were not better off? It’s a Nature paper, and we’ll pull it, but-

Tom Dayspring: I think that CETP and the investigations drugs were long before the Mendelian randomization-

Peter Attia: Absolutely, yeah.

Tom Dayspring: So, they didn’t have that data that Mendelian randomization shows not necessarily with high HDL cholesterol you’re protected, whereas nowadays, most of that data would show it’s not.

Peter Attia: My recollection is that the MR came out in 2010, 2011, and it basically validated what had, at the time, been seen in two trials, which was, “Wow, inhibit CETP, things don’t get better.

Tom Dayspring: So, I think Mendelian randomization, had they had that data first, they would have never investigated these drugs.

Peter Attia: They might never have made the drug.

Tom Dayspring: Which is why they did chase PCSK9 inhibitors, because the genetic model told them this can’t fail, unless there’s a downside to the drug.

Tom Dayspring: That we don’t know about. And that’s always a problem with a drug that’s going to change a gene, it may do good to a marker and do bad to some other marker you’re not smart enough to know about yet.

Peter Attia: Oh, I can’t wait until we’re going to talk about PCSK9.

Tom Dayspring: Yeah. So, let’s inhibit CETP, the HDL’s get to keep all their cholesterol. HDL cholesterol goes through the roof, that’s good epidemiologically, right?

Peter Attia: Except on first principles, it doesn’t even make sense, in light of what you just told us.

Tom Dayspring: No, but they didn’t know that then, either. Remember, this whole HDL story has evolved, too.

Peter Attia: But wait, so that’s interesting. I don’t think I understood that, and so, I should give them more credit. Are you saying that it absolutely was not known?

Tom Dayspring: No, there were no theories on it. Guys like Dan Rader were always talking about it, but you don’t know how much you’re interrupting the system with that. They’re so heavily focused on basic lipid biomarkers like LDL cholesterol and HDL cholesterol.

Peter Attia: LDL bad, HDL good.

Tom Dayspring: And it’s the same with the niacin story. How could it not work? It raises HDL cholesterol. And it turns out niacin doesn’t work if you want to take legitimate trials to show it works, and is there a price for using niacin, even if you don’t believe the legitimate trials? So, that’s another story, which we’ll probably get into.

Peter Attia: We’ll definitely get into that, because this is one area where your peers will argue with you.

Tom Dayspring: Some. Many will not.

Tom Dayspring: I’ve tried everything else. Nothing else has worked. And look, I’m a guy who took niacin myself for a bunch of years, but that was before I knew what I knew now, and it didn’t, unfortunately, work for me, anyway.

Tom Dayspring: So, the CETP, it’s going to raise HDL cholesterol, but how much it raises it really depends on the potency of the CETP inhibitor, and there are different degrees of CETP inhibition. We have weak inhibitors, and we have super strong inhibitors. The first one that came out, Pfizer had developed a drug that inhibited, thought it was going to be a multi-billion dollar drug because it raised HDL cholesterol. Pfizer and many other companies already proved lowering apoB, LDL cholesterol works really well. Imagine if we can take those people with residual risk because their HDL cholesterol’s still low, and we could raise their HDL cholesterol. That niacin angiographic trial would really support doing that.

Tom Dayspring: Okay. So, they said, “Let’s inhibit CETP and raise HDL cholesterol.” So Pfizer went to market, many people were buying its stock in its infancy, thought they’d make a zillion dollars.

## 2006 CETP inhibitor trial: torcetrapib (Pfizer) [54:45]

Peter Attia: I remember where I was standing the moment those results were announced, and it’s interesting, because I was not at all a lipid guy, but at the time, I was working at McKinsey. I was in San Francisco. It was on a September day, a beautiful September day in San Francisco, 2006 ([Tanne, 2006](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1702474/)), and I took it as a fait accompli that this drug would work and Pfizer stock was going to skyrocket.

Tom Dayspring: Look, we all knew the company Esperion who developed that and we knew their guys. We had heard them lecture many a time. Everybody was banking on that. “Boy, this is real.” You never know in a clinical trial, but.

Peter Attia: It looked like a slam dunk.

Tom Dayspring: It really did, and I remember, whenever I found out, I forget whether that day, but it was late at night and I saw a little thing, and it was like, 11:30 at night. I don’t even know why I saw it, that “Pfizer terminates torcetrapib trial.”

Peter Attia: Well, in fairness, you were actually seeing it in real time. I saw it the next morning.

Tom Dayspring: And look, there was no Twitter then. I could call up every lipidologist I know. I emailed a few close buddies, “Look at what I just saw.” And so, they stopped the trial, not because it was harming people. And as it turns out, it looks like that drug had some other properties that screwed up certain electrolytes and other hormonal levels that okay, no wonder. So, raising HDL cholesterol, if it’s going to bring a downside to the table, goodbye. So, Pfizer lost a lot of money in that.

## 2012 CETP inhibitor trial: dalcetrapib (Hoffmann–La Roche) [56:15]

Tom Dayspring: But that didn’t stop research on a drug. As they develop these other toxicities that maybe were specifically related to that CETP inhibitor, let’s develop better CETP inhibitors and go with them. So they did, and they came up with a very weak one called dalcetrapib.

Peter Attia: Who made that? It wasn’t Merck. Because Merck did the third one. So there’s someone in between I keep forgetting. [Hoffmann–La Roche.]

Tom Dayspring: And then two other companies, again, it was Merck and Lilly, had super potency CETP inhibitors, but they did all the tests and it didn’t have this other toxicity with electrolytes and renin-angiotensin levels and things like that, so maybe this would work.

Tom Dayspring: And of course, the stronger your CETP inhibition, the more you would raise HDL cholesterol, so dalcetrapib raised it 20-30%, whereas the stronger ones raised it 80, 100%, HDL cholesterol. So the dalcetrapib, they enrolled in acute coronary syndrome, a humongous population, and were doing a randomized trial [called dal-Outcomes] ([Schwartz et al., 2012](https://www.ncbi.nlm.nih.gov/pubmed/23126252)). And after a few years, they didn’t see any downside. They weren’t killing anybody.

Peter Attia: There was no superiority, no inferiority.

Tom Dayspring: But it was futility. And those are very expensive trials, so the bean counters said, “That’s it. Futile trial. Forget about it.”

Peter Attia: I think that those trials, combined with the MR, have put an end to this approach to lipid modulation.

## 2017 CETP inhibitor trials: evacetrapib (Eli Lilly) and anacetrapib (Merck) [58:00]

Tom Dayspring: They did, and the two other companies, those said, “Well, it’s a weak CETP inhibitor. We’re potent, so we’re going to continue. Our trials are well underway, too.” So, with anacetrapib and evacetrapib, the remaining things, they did them, and sooner or later, Lilly just bailed on their trial. More futility; they weren’t going to take it to trial conclusion, but Merck continued their trial.

Tom Dayspring: So Lilly, with a potent evacetrapib, was seeing not only drastic raisings in HDL cholesterol, but LDL cholesterol, PCSK9 inhibitors were starting to appear by then. Nobody’s going to ever prescribe this drug based on what it does to LDL cholesterol, and we’re not so convinced that raising HDL cholesterol matters anymore. There was some futility, so they bailed on their trial, too ([Lincoff et al., 2017](https://www.ncbi.nlm.nih.gov/pubmed/28514624)). Some people wish they would have continued that trial.

Tom Dayspring: But Merck did continue, and Merck did hit its endpoint ([Bowman et al., 2017](https://www.ncbi.nlm.nih.gov/pubmed/28847206)), that it did reduce coronary events. It drastically raised HDL cholesterol, but it dramatically lowered apoB, also. So the theory came to be what a CETP inhibitor does to the metric HDL cholesterol has nothing to do with anything, but if it can lower apoB, it works. And the trial worked, but they’re not going to bring it to market because it stays in the human body for years, and they just are afraid of that.

Tom Dayspring: They have no idea what might show up.

Peter Attia: Well, especially when there’s no upside. Relative to what you can do anyway.

Tom Dayspring: And we’ve got other things that’ll give you that type of apoB lowering that seem to be safe and have been around.

Tom Dayspring: Merck is not going to commercialize that product, even though it has a successful trial. So if you want to definitively say CETP inhibition doesn’t reduce artherosclerosis, it did, but at what price and at what benefit? And there are other LDL-lowering things coming to the market.

**[1:00:00]**

Peter Attia: It’s not entirely clear why one of those drugs is working and why one is not, because the inhibition of CETP, it’s interrupting a transfer, but it doesn’t actually tell you what happens after the transfer, and that becomes the problem.

Tom Dayspring: Even though some of the primitive HDL functions such as cholesterol efflux, it didn’t look like they were screwing up the HDL, but there’s immense numbers of HDL function. You don’t know what you’re doing. And if that [drug] is going to stay in your body forever, what other consequences might there be long-term, screwing up of other biological systems or something? So you couldn’t risk that.

Peter Attia: Well, kudos to Merck, because I think the FDA would have approved it, don’t you?

Tom Dayspring: Not with the prolonged tissue residual time.

Peter Attia: Oh, so you think the FDA would have denied it based on that. I see.

Tom Dayspring: I think they had that fear, and even if they thought they could get it by, their lawyers probably told them to forget it.

Peter Attia: You know, it’s funny. A lot of people don’t remember what happened at Merck with Vioxx.

Peter Attia: With the failure of the black box warning, and I actually, I’ve got to tell you, that, to me, is one example of an overreaction too late, versus an appropriate reaction sooner. So, you know, not that I’m a pharma guy and know much about pharma, but Vioxx was an amazing drug. I mean, 10 times better than the Celebrex ever was. For the listener who’s wondering what we’re talking about, Celebrex and Vioxx were the first two versions of these things called selective COX-2 inhibitors, which were potent and much more selective anti-inflammatory drugs, so for people with orthopedic issues, joint pain, things like that. But they don’t have some of the drawbacks you have with using just non-selective inhibitors of cyclo-oxygenase, such as Advil or Aleve or things like that.

Peter Attia: Anyway, to make a long story short, it was about 2001 when they saw a small subset of patients, it turned out those, I think, that were hypertensive, were having higher risk of MI, taking Vioxx. The drug got immediately yanked. I think it was the best anti-inflammatory COX inhibitor ever out there, and in reality, I think what emerged after the fact was, “Hey, the guys at Merck sort of knew this earlier on.” There was data that suggested there was something going on. And instead, they should have partitioned it and said, “Hey, maybe there’s a subset of patients in whom we don’t let this drug be taken,” because I think a lot of patients got deprived of an amazing drug on the basis of a few. So anyway, my guess is Merck’s highly sensitive to that stuff.

Tom Dayspring: Sure. In today’s medical legal world, that stuff comes back to haunt those companies. One person goes south and it’s a zillion dollar lawsuit, so it is very, very tough, and look, it goes back to my young days where we couldn’t do anything for MI but suppress ventricular arrhythmias with any number of drugs, and all we did was kill people with them.

Peter Attia: Yeah, those things were the most toxic drugs imaginable.

Tom Dayspring: Right. But, the VPC’s disappeared, and so did they. So, you’ve got to be careful.

§

## Selected Links / Related Material

**HDL and RCT:** [High‐Density Lipoproteins: Emerging Knowledge](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1559-4564.2007.06008.x) (Dayspring, 2007) [1:40]

**LDL homeostasis**: [Role of liver in the maintenance of cholesterol and low density lipoprotein homeostasis in different animal species, including humans](https://www.ncbi.nlm.nih.gov/pubmed/8245716) (Dietschy et al., 1993) [1:40]

**Cholesterol efflux**: [Molecular Mechanisms of Cellular Cholesterol Efflux](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4148835/) (Phillips, 2014) [2:30]

**RCT fluxes**: [Reverse cholesterol transport fluxes](https://www.ncbi.nlm.nih.gov/pubmed/24362356) (Hellerstein and Turner, 2014) [2:30, 8:15]

**Bile acids**: [Fifty years of advances in bile acid synthesis and metabolism](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1194%2Fjlr.R800026-JLR200) (Russell, 2009) [3:45]

**Not everyone with high HDL-C is protected**: [Coronary heart disease risks associated with high levels of HDL cholesterol](https://www.ncbi.nlm.nih.gov/pubmed/24627418) (Wilkins et al., 2014) [6:00]

**People with low HDL-C without heart disease**: [Association of loss-of-function mutations in the ABCA1 gene with high-density lipoprotein cholesterol levels and risk of ischemic heart disease](https://www.ncbi.nlm.nih.gov/pubmed/18523221) (Frikke-Schmidt et al., 2008) [6:00]

**John Chapman’s 600-page book, highly recommended by Tom**: [High‐Density Lipoproteins: Structure, Metabolism, Function, and Therapeutics](https://onlinelibrary.wiley.com/doi/book/10.1002/9781118158678) (Kontush and Chapman, 2011) [6:30]

**Scavenger receptor**: [Mechanisms regulating hepatic SR-BI expression and their impact on HDL metabolism](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.atherosclerosis.2011.05.036) (Leiva et al., 2011) [6:30]

**Holoparticles**: [Characterization of two high-density lipoprotein binding sites on porcine hepatocyte plasma membranes: contribution of scavenger receptor class B type I (SR-BI) to the low-affinity component](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1021%2Fbi991971y) (Martinez et al., 2000) [6:30]

**VLDL particle number**: [Effects of insulin resistance and type 2 diabetes on lipoprotein subclass particle size and concentration determined by nuclear magnetic resonance](https://www.ncbi.nlm.nih.gov/pubmed/12540621) (Garvey et al., 2003) [21:15]

**Cooperative lipoprotein study**: [Distribution of triglyceride and total, LDL and HDL cholesterol in several populations: A cooperative lipoprotein phenotyping study](https://www.ncbi.nlm.nih.gov/pubmed/191465) (Castelli et al., 1977) [33:15]

**Correction — Framingham was a novel, new study started after WWII**: [The Framingham Heart Study and the epidemiology of cardiovascular disease: a historical perspective](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(13)61752-3/fulltext) (Mahmood et al., 2014) [33:45]

**Correction — regarding HDL-C**: [High-density lipoproteins: a consensus statement from the National Lipid Association](https://www.ncbi.nlm.nih.gov/pubmed/24079290) (Toth et al., 2013) [34:30]

**HDL-C and HDL particles**: [HDL cholesterol/HDL particle ratio: a new measure of HDL function?](https://www.ncbi.nlm.nih.gov/pubmed/25634835) (Remaley, 2015) [38:45]

**Product that induces a receptor in the liver that pulls cholesterol out of HDL particles (probucol)**: [Hypocholesterolemia, foam cell accumulation, but no atherosclerosis in mice lacking ABC-transporter A1 and scavenger receptor BI](https://www.ncbi.nlm.nih.gov/pubmed/21840001) (Zhao et al., 2011) [39:15]

**Product that induces a receptor in the liver that pulls cholesterol out of HDL particles (probucol)**: [Probucol and multivitamins in the prevention of restenosis after coronary angioplasty. Multivitamins and Probucol Study Group](https://www.ncbi.nlm.nih.gov/pubmed/9241125) (Tardif et al., 1997) [39:15]

**Identified a gene that regulates the functioning of the scavenger receptor**: [Rediscovering scavenger receptor type BI: surprising new roles for the HDL receptor](https://www.ncbi.nlm.nih.gov/pubmed/28301373) (Hoekstra and Sorci-Thomas, 2017) [40:00]

**ApoE and HDL**: [Apolipoprotein E-containing high-density lipoprotein (HDL) modifies the impact of cholesterol-overloaded HDL on incident coronary heart disease risk: A community-based cohort study](https://www.ncbi.nlm.nih.gov/pubmed/29217413) (Qi et al., 2018) [50:30]

**Pfizer and torcetrapib (a CETP inhibitor)**: [Pfizer stops clinical trials of heart drug](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1702474/) (Tanne, 2006) [54:45]

**Dalcetrapib (a CETP inhibitor)**: [Effects of dalcetrapib in patients with a recent acute coronary syndrome](https://www.ncbi.nlm.nih.gov/pubmed/23126252) (Schwartz et al., 2012) [57:15]

**ACCELERATE trial, evacetrapib (a CETP inhibitor)**: [Evacetrapib and Cardiovascular Outcomes in High-Risk Vascular Disease](https://www.ncbi.nlm.nih.gov/pubmed/28514624) (Lincoff et al., 2017) [58:30]

**REVEAL trial, anacetrapib (a CETP inhibitor)**: [Effects of Anacetrapib in Patients with Atherosclerotic Vascular Disease](https://www.ncbi.nlm.nih.gov/pubmed/28847206) (Bowman et al., 2017) [58:45]

§

## People Mentioned

- [Dan Rader](https://www.med.upenn.edu/apps/faculty/index.php/g5165284/p17778) (HDL expert) [6:30]
- [Bryan Brewer](https://www.medscape.org/viewarticle/520393) (HDL expert) [6:30]
- [John Chapman](https://www.eas-society.org/page/chapman_bio) (HDL expert) [6:30]
- [Josh Knowles](https://profiles.stanford.edu/joshua-knowles) (FH expert) [8:30]
- [Allan Sniderman](https://www.mcgill.ca/expmed/dr-allan-d-sniderman) (discordance between apoB or LDL particle number and non-HDL cholesterol) [24:00]

§

![](https://peterattiamd.com/wp-content/uploads/2018/10/tom-dayspring-300x300.jpg)

##### Thomas Dayspring, M.D., FACP, FNLA

Thomas Dayspring, MD, FACP, FNLA is the chief academic officer for True Health Diagnostics, LLC. He provides scientific leadership and direction for the company’s comprehensive educational programs. Dr. Dayspring is a fellow of both the American College of Physicians and the National Lipid Association. He is certified in internal medicine and clinical lipidology.

Before relocating to Virginia in 2012, Dr. Dayspring practiced medicine in New Jersey for 37 years. Over the last two decades, he has given over 4,000 domestic and international lectures, including over 600 CME programs on topics such as atherothrombosis, lipoprotein and vascular biology, biomarker testing, and women’s cardiovascular issues.

Dr Dayspring is an Associate Editor of the Journal of Clinical Lipidology. He has authored or co-authored numerous manuscripts published across leading journals such as the American Journal of Cardiology, the Journal of Clinical Lipidology, and several lipid-related book chapters. He was the recipient of the 2011 National Lipid Association President’s Award for services to clinical lipidology. [[truehealthdiag.com](https://truehealthdiag.com/leadership/thomas-dayspring/)]

Disclosures:

- Employed full time for last three years by True Health Diagnostics, LLC, which provides biomarker diagnostics and clinical services to clinicians, patients, and healthcare organizations
- 2017: small consulting project for Abbvie

Tom on Twitter: [@DrLipid](https://twitter.com/Drlipid)