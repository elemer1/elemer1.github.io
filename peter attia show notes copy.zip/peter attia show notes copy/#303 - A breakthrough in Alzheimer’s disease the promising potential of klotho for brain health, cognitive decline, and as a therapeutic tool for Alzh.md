# #303 – A breakthrough in Alzheimer’s disease: the promising potential of klotho for brain health, cognitive decline, and as a therapeutic tool for Alzheimer’s disease | Dena Dubal, M.D., Ph.D.

**Source:** [https://peterattiamd.com/denadubal/](https://peterattiamd.com/denadubal/)

---

Dena Dubal is a physician-scientist and professor of neurology at UCSF whose work focuses on mechanisms of longevity and brain resilience. In this episode, Dena delves into the intricacies of the longevity factor klotho: its formation and distribution in the body, the factors such as stress and exercise that impact its levels, and its profound impact on cognitive function and overall brain health. Dena shares insights from exciting research in animal models showing the potential of klotho in treating neurodegenerative diseases as well as its broader implications for organ health and disease prevention. She concludes with an optimistic outlook for future research in humans and the potential of klotho for the prevention and treatment of Alzheimer’s disease.

*Disclosure: Peter is an investor in Jocasta Neuroscience, a company working to develop klotho as a therapy for people with Alzheimer’s disease.*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/denadubal/the_Drive_public.png)

Play

#303 - A breakthrough in Alzheimer's disease: the promising potential of klotho for brain health, cognitive decline, and as a therapeutic tool for Alzheimer's disease | Dena Dubal, M.D., Ph.D.

#303 - A breakthrough in Alzheimer's disease: the promising potential of klotho for brain health, cognitive decline, and as a therapeutic tool for Alzheimer's disease | Dena Dubal, M.D., Ph.D.

1x15s30s

0:002:05:08

## We discuss:

- Dena’s fascination with aging and how she came to study klotho [3:30];
- Biological properties of klotho: production, regulation, decline with age, and factors influencing its levels [11:45];
- Potential benefits of klotho on brain health [22:00];
- The relationship between soluble klotho protein, platelet factors, and cognitive enhancement [33:45];
- The role of platelet factor 4 (PF4) and it’s interaction with GluN2B in mediating cognitive enhancement [46:45];
- Benefits of klotho observed in a mouse model of Parkinson’s disease [55:45];
- Benefits of klotho observed in a mouse model of Alzheimer’s disease [1:03:00];
- Promising results of klotho in primate models, and the importance of finding an appropriate therapeutic dose before moving to human trials [1:08:00];
- Speculating why a single klotho injection has such long-lasting effects [1:25:30];
- Potential cognitive benefits of klotho in humans, the impact of the KL-VS genetic variant on klotho levels, and the need for human trials to confirm these effects [1:27:45];
- The interaction between the KL-VS genetic variant and APOE4 and how it impacts risk of Alzheimer’s disease [1:34:45];
- The significance of klotho levels: studies linking lower levels to increased mortality and the broader implications for organ health and disease prevention [1:47:15];
- Measuring klotho levels and determining an individual’s KL-VS status [1:52:15];
- The promising potential of klotho for Alzheimer’s disease treatment, and the importance of philanthropy for funding research [1:58:00]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Dena Dubal is a physician-scientist, professor of neurology at the University of California San Francisco
  - She holds the David A. Coulter Endowed Chair in Aging and Neurodegenerative Disease
  - She is also an investigator with the Simons Foundation and Bakar Aging Research Institute
- Her work is recognized for its significant potential towards therapies to help people live longer and better
- She directs a laboratory focused on mechanisms of longevity and brain resilience that integrate genetic and molecular approaches to investigate aging, Alzheimer’s disease, and Parkinson’s disease
- In this conversation we focus on something called klotho
- If you’ve heard Peter talk on this podcast and other podcasts, you’ve probably heard him bring up klotho (either the protein or the gene that codes for the protein)
- His interest in klotho started a couple of years ago when he became aware of some of the genetic data in humans about the relationship between klotho and Alzheimer’s disease prevention
  - Particularly in people who are carriers of the [*APOE4* gene](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms)
- This has led him deeper and deeper down the klotho rabbit hole, and really all roads lead to Dena if you want to have this discussion
- We begin our discussion with an overview of klotho
  - What is it?
  - How is it formed?
  - How does it get around our body?
  - What does it do?
- We talk about the mechanisms regulating klotho in the body and in particular, in the brain
- We also talk about things that impact klotho levels, such as stress and exercise (and to what extent they do)
- From there, we look at the research that’s being done in how klotho relates to various cognitive functions as well as its role in brain health across different species and across different ages
  - As well as klotho treatment may be helpful in treating neurodegenerative disease (particularly Alzheimer’s disease)
- We wrap-up this discussion speaking about the broader impacts of klotho on organ health in addition to what its potential may hold for the treatment of Alzheimer’s disease in the future
- Peter discloses a conflict of interest: he is a co-founder of and investor in Jocasta Neuroscience, a company working to develop klotho as a therapy for people with Alzheimer’s disease

## Dena’s fascination with aging and how she came to study klotho [3:30]

**Tell me a little about your clinical work, your research work, what you did during your PhD and how that carried forward during your tenure**

- Dena is a neurologist and a neuroscientist
- She directs a group that is deeply involved in the discovery around [klotho](https://en.wikipedia.org/wiki/Klotho_(biology))

*Thinking back to when her interest in aging actually began*

- She thought back to her undergraduate days at UC Berkeley when she was a 19-year-old that was oddly interested in aging (kind of obsessed)
- She worked with a medical anthropologist at Berkeley ([Lawrence Cohen](https://anthropology.berkeley.edu/lawrence-cohen)) on what it meant to experience dementia in different cultures (India versus the United States)
- Simultaneously she took a class on the physiology of aging ‒ she was at the edge of her seat learning about cellular senescence
  - It’s amazing that this is happening to us day by day, yet we don’t know much about it
  - We don’t know much about brain aging

***As an undergraduate, she was committed to learning more about brain aging and possibly to do something about it, and that led her to do a MD PhD at the University of Kentucky***

- She trained with [Phyllis Wise](https://colostudy.org/people/phyllis-wise/), a neuroendocrinologist who studied brain aging, who was an amazing PhD
- She learned so much, fell in love with the discovery process of science
- Fast-forward, she then trained as a neurologist at UCSF where she is now
  - And that was over 20 years ago, 2003

*Her work at UCSF*

- She’s on the wards, it’s a regular day of patient rounding, and the former chair of UCSF neurology ([Stephen Hauser](https://profiles.ucsf.edu/stephen.hauser)) turned to her and he said, “*Dena, when you go back to the lab, do things that are big and important and not incremental or mediocre because they’ll take you the same amount of time.*”
  - That really clicked with her, and it became her mantra
- After an Alzheimer’s fellowship, in both clinical and basic science, she had the chance to build a group and really start her own scientific discovery
- They focused on klotho, the subject of what we’ll talk about today
  - Named after the Greek fate who spins the thread of life

***The idea of studying klotho is to understand whether factors that help us to live longer could help us to live better***

- Whether this longevity factor could actually help the brain
- Could help it stave off Alzheimer’s disease?

**The first time klotho crossed her radar**

- She was a junior faculty thinking about what to focus on, “*What was going to be our chance to do something big and important?*”
- She was intrigued by a few decades of work showing that aging itself was malleable
  - [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) demonstrated that tweaking genetics in worms could dramatically increase their lifespan
    - Her work knocked-out an analog of one of the IGF genes, [*DAF-16*](https://en.wikipedia.org/wiki/Daf-16)
- Dena wanted to know if that could have effects in the brain
- Klotho had emerged as a longevity factor, and it was a chance to understand: could klotho do something in the brain?
- Very little was known about klotho when she started
- A colleague had observed that the levels decrease in the white matter of monkey brains, that a variant of klotho that we can talk about in a bit was associated with decreased stroke risk
- The person who discovered klotho had noted that mice without klotho moved slowly and they were cognitively a little slow
- Dena was the right person at the right time, and had the chance to really dig in

***It was risky to start with something that not much was known about in the brain, but it was a chance to do something maybe big and important***

**The discovery of klotho is such a story of serendipity**

- It was in 1997, [Makoto Kuro-o](https://research.com/u/makoto-kuro-o), a Japanese scientist accidentally discovered klotho
- He was studying hypertension and he engineered a mouse to insert a gene, and then he noticed that in a few lines of these mice, maybe it was just one line of these mice, there was this premature aging phenotype
  - The mice lived to about 3 months instead of about 30 months
  - They developed normally, but around 2 weeks of age they became progeroid: they looked like they were rapidly aging with osteoporosis, atherosclerosis, emphysema, and they moved slow
  - They looked really old
- So, he went back to that mouse and he mapped out what had been disrupted, and that was klotho
- That was the first time klotho was found, and he named it after the [Greek fate (Clotho)](https://en.wikipedia.org/wiki/Clotho) who spins the thread of life, daughter of Zeus
  - He named it K-L-O-T-H-O in homage to his discovery
  - His name is Kuro-o
- And a longevity factor isn’t something that just causes premature aging if disrupted
  - So, it was very important for him to then go back and see what would happen if he overexpressed it
- He engineered mice to overexpress klotho, and those mice lived 30% longer

***That showed that klotho is a longevity factor ‒ disruption caused premature aging and overexpression extended lifespan***

- Peter adds, “*It’s a great story for people especially maybe who don’t do or haven’t done science because it illustrates the role of curiosity and serendipity*.”
- There are some people who maybe wouldn’t have even gone back and done the experiments that he did to understand what turned out to be the most relevant thing

> “*He followed the science, he opened the field. He looked into the mistake, the oops of science. And here we are, maybe on the cusp of a new therapy*.”‒ Dena Dubal

## Biological properties of klotho: production, regulation, decline with age, and factors influencing its levels [11:45]

- [Klotho](https://en.wikipedia.org/wiki/Klotho_(biology)) itself is a pretty big protein: it’s about a 1,000 amino acids, by weight maybe 130 kilodaltons
- It codes for a type I transmembrane protein
  - Which means that its N-terminus will sit in the extracellular space, it has one pass through the membrane, and its C-terminus is inside the cell
- Its N-terminus (that part that sits outside the cell) has two repeat domains: KL-1 and KL-2
  - And those domains have high homology to proteins that are found throughout mammalian worm and fly biology
  - There are homologs of klotho throughout species, and it’s pretty conserved in mammals
- Klotho is primarily made in the kidney and then it gets transported into the membrane
  - It’s also made in the choroid plexus of the brain (there are a few forms of klotho)
- Enzymes come across base ADAM10, ADAM17 and they clip that extracellular portion of klotho and release it into the blood
  - Or in the case of the brain, release it into the CSF
  - And that form of klotho is known as a **soluble form of klotho** or the secreted form of klotho
    - Dena calls it a **hormonal form of klotho** because it’s released at one site and then can act at different sites at multiple organs

**How big is that N-terminus piece that gets clipped and now goes and acts like a hormone?**

- It’s the majority of the protein
- The part inside the cell and that crosses the membrane is very small

**If we were to take a blood test and measure a person’s klotho levels, what could we observe about it across people of the same age, people of different ages?**

*What factors do we think might influence the expression? And does the expression and production of the protein become the sole determinant of the soluble factor? In other words, is there also variability at the cleavage efficacy? Or are there other factors that lead to consumption of the protein or degradation of the protein in the periphery?*

- Starting with levels of klotho across the lifespan: klotho circulates in us and it circulates in mice
- Dena started her studies in mice and wanted to make sure it was going to be relevant to the human condition (and it is)

***We are born with about 6X more klotho than we have now, and klotho levels decline throughout our lifespan***

- From 40 onwards, they can decrease by half during aging
- They also have a circadian rhythm or a [diurnal rhythm](https://en.wikipedia.org/wiki/Diurnal_cycle) in that when we wake up, we have high levels of klotho, and by 4:00 PM, 3:00 PM when people are looking to grab a cup of coffee, the klotho levels are really starting to decline and then they nader by around midnight
  - It can be a 40% or so decrease

Peter asks, “*What explains the daily variation? Is it some ‘consumption?’ Or is it being turned over that quickly and the supply of klotho is decreasing by the time of day?*”

- The answer to that is not known
  - What regulates the daily levels?
  - How is it being degraded?
  - Is the expression being increased?
- The **half-life** is short in mice, it’s maybe 7-10 minutes
- But it’s much longer in humans and monkeys it’s much longer (at least a day or so)
  - So, it’s unlikely that the production is really actually increasing and decreasing
- Dena speculates it may be sequestered in organs or degrades
- She’s seen a couple of reports of this diurnal variation and it’s really not clear why it’s increasing and decreasing
- But it is known in aging for example, this longer term decline and slow decline that we see it’s been observed
  - Work by [Fabrizio Ambrosio’s](https://connects.catalyst.harvard.edu/Profiles/display/Person/209504) lab showed that there is a hypermethylation around the klotho promoter that occurs with aging that stops its transcription (and translation)

**That’s an interesting thing to think about: if we wanted to preserve our klotho levels, how can we interfere with that methylation that happens with aging?**

- In general for klotho, methylation really turns things off
- It’s believed that the main mechanism driving the reduced production of klotho is the increase in methylation of the [promoter](https://en.wikipedia.org/wiki/Promoter_(genetics))
- There are other possibilities like maybe the kidney is less efficient at making it with aging
- Dena thinks that Ambrosio’s lab is really onto something
  - They showed it in chondrocytes and aging chondrocytes
  - It was really the first molecular demonstration about why klotho may be decreasing

**There are other things that decrease klotho**

- One big one is chronic stress
- Dena did a [study](https://pubmed.ncbi.nlm.nih.gov/26080320/) with [Elissa Epel](https://profiles.ucsf.edu/elissa.epel) and [Aric Prather](https://profiles.ucsf.edu/aric.prather) at UCSF, and mothers with neurodevelopmentally typical or atypical children
  - The mothers with high levels of stress with children with autism spectrum disorder had much lower levels of klotho, as well as shorter telomeres

***With increasing stress, there was a decrease in the klotho level***

Peter asks, “*Did you demonstrate in those folks a higher degree of methylation of the promoter relative to their age? And did it basically look like they were older at the level of the promoter?*”

- Dena hasn’t done that, but it would be really neat to look at

**Do we know the mechanism by which chronic stress could be mediating the reduction in klotho?**

- [Ryan Brown](https://profiles.ucsf.edu/ryan.brown) (at UCSF), Aric Prather, Alyssa Epple, and Dena have [looked at](https://pubmed.ncbi.nlm.nih.gov/37580799/) whether there might be a relationship between klotho levels and telomere length in these same women
  - And there is a very direct relationship with a very tight correlation between **shorter telomeres** and lower klotho levels
- So, there may be some convergence around these different hallmarks of aging
  - Maybe some relationship of them regulating each other or maybe they’re changing in parallel
  - It’s hard to say

**Good news about the effect of exercise on klotho levels**

- One of the most robust interventions that increases klotho levels is exercise
- It’s been shown in study after study and in [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/36266389/) (it’s been done in about 12 studies)

***The data are that after 12 weeks of what people call chronic exercise, that klotho levels increase by about 30%***

- In mice, they can even double acutely after a 45-minute treadmill run (a study with preliminary data)
- How it’s increased is unknown
- Klotho is beginning to be thought of as an [exerkine](https://en.wikipedia.org/wiki/Exerkine), something that is produced and released in the body following exercise

**How would klotho stack up in your mind compared to something else that we would think of along these lines such as** [**BDNF**](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor)**?**

- Peter has talked about this at length on the podcast [see the “Selected Links” section at the end]
- He explains, if you look objectively at all of the modifiable behaviors around dementia, routinely exercise is at the absolute top of the list
- About exercise, Peter explains, “*More potent even in its magnitude than lipid management, glucose management, and hypertension, all of which themselves are enormously powerful. But something about exercise seems even greater*.”
  - It could be that it indirectly mediates at least 2 of these 3
  - But people point to something else that’s going on and BDNF is often discussed

Peter asks, “*Do you think that maybe part of that effect is klotho? And do you think that the effect of klotho may be even more potent?*”

- Dena doesn’t know, but it’s a really important question
  - Is there a relationship between klotho and BDNF?
  - Does klotho increase BDNF levels in the brain? (she doesn’t know)

## Potential benefits of klotho on brain health [22:00]

**BDNF has a very striking effect in the brain**

- [BDNF](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor) is brain-derived neurotrophic factor
- It has been shown in the brain to really be associated with drive and positive brain health
- Intermittent fasting increases BDNF in the brain, exercise increases BDNF
- Giving BDNF to the brain, the neurons function better
- It’s a really good trophic factor for the brain
- And it does remind one of klotho and the effects of klotho
  - In fact, intermittent fasting simultaneously increases klotho in the brains of mice along with BDNF

Peter asks, “*How long do the mice need to fast to get that effect?*”

- The mice fasted for 24 hours
- Peter points out, “*So, not really something we can translate to humans given that that’s… I mean, 24 hours in a mouse, that’s half the distance to death*.”
  - This is a real problem with extrapolating from mice data
  - Even a 12-hour fast in a mouse is an overwhelming feat of calorie deprivation; 24 hours is staggering
  - We don’t have a way to translate that to humans, but it could be that that’s on the order of weeks
- Peter wants to make sure people aren’t listening to this thinking, *“Hey, all I got to do is skip breakfast and I’m getting the same amount of BDNF or klotho that I would get from a 45-minute workout.*”
  - His guess is those two are not even in the same zip code

*Dena thinks differently about it*

- When she thinks about mouse time and mouse lifespan (they live 2-3 years), she believes they’re aging faster
- They have a shorter lifespan, but it’s possible that their 24 hour lives are similar to our 24 hour lives

Peter asks, “*But 48 hours of fasting will usually kill a mouse, right?*”

- Dena doesn’t know how long a mouse can go
- Peter remembers an [IRB](https://en.wikipedia.org/wiki/Institutional_review_board) would really scrutinize an investigator who’s trying to get 36 hours of fasting in a mouse
- She doesn’t do fasting studies in mice but agrees that in general, we have to be careful when extrapolating from mice to humans
- Dena thinks that in the area of cognition and neurodegenerative diseases, studying mice in mouse brains, and their neural circuits, and their hippocampi, and their prefrontal cortices tell us fundamental things about the human condition
- Particularly because they have to have very strong navigation strategies and memories for foraging, for coming back to their nest
  - And these memory circuits are very, very fundamental and quite preserved up to non-human primates including us
- Having said that, she is always aware of: are we doing something that is important to the human condition? Is it relevant? Who cares? Will any of this matter?
- The majority of her work is in mice, and there are certainly limitations, but there are many strengths, particularly in studying memory and neural circuits in the brain

**In mice Dena has found that klotho enhances cognition**

- She collaborated with biotech and Yale University and [found](https://pubmed.ncbi.nlm.nih.gov/37400721/) that actually klotho enhances learning, and memory, and cognition in old monkeys
  - In a very complex brain, genetically diverse, anatomically diverse functionally complex that in a brain like ours that klotho had very similar effects to what we see in mice

**Peter’s summary about what we know so far**

- Klotho was discovered in ‘97 based on a knockout
- The lack of klotho is incompatible with a long life
- The reverse is true, when klotho is enhanced, lifespan is also enhanced by about 30%
  - That’s remarkable in a mouse
  - That’s up there with the most draconian caloric restriction, rapamycin administration under certain settings
  - That’s a very reproducible and robust finding

**More about the causal relationship between klotho and brain health**

- Dena’s research started with the hypothesis that in these mice that overexpress klotho (that live longer) might resilient to Alzheimer’s toxins
- They back-crossed Alzheimer’s models with klotho-overexpressing models to create mice who have mousheimers, and then have mousheimers plus lots of klotho

*In this* [*study*](https://pubmed.ncbi.nlm.nih.gov/25673831/)*, there were 4 experimental groups*

- 1 – Normal mice [labeled NTG in the study]
- 2 – Normal mice with higher levels of klotho [labeled KL]
- 3 – Alzheimer’s mice [labeled hAPP]
- 4 – Alzheimer’s mice with higher levels of klotho [labeled hAPP/KL]
- Group #2 showed a remarkable statistically significant difference across multiple cognitive tasks and across different ages
  - You put them in a maze and they could map the room better, escape quicker, not because they were swimming faster, not because they could see better, but because they were remembering and learning more efficiently and better

> “*The mice that overexpress klotho that live longer were smarter… and that was a complete surprise.*”‒ Dena Dubal

*The magnitude of this result*

- Often people hear the term **statically significant** and they confuse with with **clinically significant**
- Those are not necessarily the same thing, however in this case, it is
- Stating this is statistically significant almost undersells what the magnitude of the differences are
- Peter has a friend who likes to point out that the really powerful stuff in biology is the stuff that you don’t actually need to do the statistics on
  - When the delta is so big that you don’t need to whip out the [student’s t-test](https://en.wikipedia.org/wiki/Student%27s_t-test) and calculate the [*p-*value](https://en.wikipedia.org/wiki/P-value) to make sure you’re not being fooled
    - Which by the way is very important and you should be doing it every time
    - When it’s actually just a formality because the answer is so clear looking at the data, that’s the really big aha moment

*Peter thinks he’d be safe in saying that that was the case here*

- Dena explains, “*You’re right. We tend to be really conservative. We don’t want to make an error… I can imagine the graphs now, and there were non-overlapping data points.*”
- Sometimes experiments will show you those differences and then the next time you do it, they don’t
  - Someone who runs the water maze is wearing a new cologne and the mice get stressed out
  - They don’t always repeat and are not always replicable

***They iterated, and they did experiment after experiment, and the*** [***data***](https://pubmed.ncbi.nlm.nih.gov/28793260/) ***held strong in mice that klotho overexpression really enhanced their cognition***

**Overexpression of klotho enhances cognition in mice**

- In young mice, in aging mice, in mice that modeled Alzheimer’s disease, and also in mice in that model Parkinson’s disease (publication that’s in peer review now), overexpression of klotho enhanced cognition
- It is really a remarkable finding, and Dena thinks it’s maybe one of the most important findings in her professional career
  - Peter goes further, “*I feel like it’s one of the most important findings in brain health period. I mean, on some levels, it’s a bit of a mystery to me why this isn’t known by everyone… this is such a big deal.*”
    - This is part of why he is really, really happy to be talking with Dena, and why he’s wanted to for the better part of 6 months
- Peter also wants to reiterate something she said a moment ago: the reproducibility coupled with the magnitude of the effect

***The consistent, enormous magnitude of difference across studies, across labs, across investigators, that signals something is going on here***

## The relationship between soluble klotho protein, platelet factors, and cognitive enhancement [33:45]

**Tell me what you think is happening with this soluble klotho protein**

- Dena first mentions: as we think about how different interventions may relate to the same biology, it is interesting that mice treated with [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) have increased klotho levels
  - Rapamycin either directly or indirectly will increase klotho levels (just thinking about the convergence of biology)
- The major question for her lab (and many others): how does klotho enhance cognition in a young aging and diseased brain?

*The first thing they turned to was a component of NMDA receptors*

- [NMDA receptors](https://en.wikipedia.org/wiki/NMDA_receptor) are really key in connections between neurons, and when they’re stimulated, they let in calcium into a neuron, and they allow, essentially, a potentiation of a neuron, for functional connections to form, and really, for the neural substrate of memory to form
- There’s a component of NMDA receptors called [GluN2B](https://en.wikipedia.org/wiki/GRIN2B), it’s a subunit
  - It’s very important
- Dena remembers something affectionately called a “[Doogie Howser](https://en.wikipedia.org/wiki/Doogie_Howser,_M.D.) mouse,” and it was a mouse that was smarter [[long-term potentiation](https://en.wikipedia.org/wiki/Long-term_potentiation#Relationship_to_behavioral_memory)]

***There are very, very few things that will make a mouse smarter, and this GluN2B overexpressing mouse (the Doogie Howser mouse) showed a very similar phenotype to the klotho overexpressing mouse***

- Dena wondered whether klotho was acting through GluN2B to enhance cognition
- They gathered data that supported this hypothesis
- It wasn’t a surprise in that overexpressing klotho caused an increase in GluN2B at the synapse (at the area where brain cells connect) and led to a more efficient connection and memory formation (synaptic plasticity) at the level of the neural cells

***When they blocked GluN2B with multiple pharmacologic inhibitors, they abrogated klotho’s ability to enhance cognition***

*Major head-scratcher: klotho does not cross the blood-brain barrier*

- Klotho is expressed in the kidney and is also expressed in the brain (secreted through the choroid plexus, which makes the fluid that the brain sits in [the [CSF](https://en.wikipedia.org/wiki/Cerebrospinal_fluid)])
- Dena and others have looked looked through autoradiography, through IP, through Western blot, through many immunohistochemistry, through many different methods and can see very clearly that it doesn’t cross into the brain

***However, when they give a shot of klotho to mice, to monkeys, in their arm or their belly, (it doesn’t matter), within 4 hours, there is cognitive enhancement; and that cognitive enhancement lasts for at least a couple of weeks***

- How is it that giving peripheral klotho is enhancing brain functions, if it’s not actually crossing into the brain?
- That’s been a major question that Dena and others have been working on, and they have some clues that led them to unexpected places
- Dena explains, “*It’s actually amazing that you give something peripherally, it has a central action, it’s not crossing into the brain, and it’s something physiologic that our bodies are used to, that we have seen high levels of, upon birth and development. It does not have known side effects at physiologic levels that have been observed yet.*”

**Dena started with the premise that maybe klotho was doing something in the blood that would then send a messenger into the brain**

- They [published](https://www.nature.com/articles/s43587-023-00468-0) one clue recently in *Nature Aging*
- Maybe there was a messenger of klotho that was going into the brain, when you gave klotho peripherally
- They did a very simple experiment: injected mice with klotho, and 4 hours later (at the time of cognitive enhancement), they did an agnostic profiling of the proteins in their plasma (in their blood)

***What they found was unimaginable: all of these platelet factors were increased when klotho was injected into the blood***

- When Dena saw this data she wasn’t really interested in looking at platelets (they’re involved in wound healing)
  - She thought, “*This is weird*.”
  - But her postdoc ([Cana Park](https://www.linkedin.com/in/cana-park/)) was very persistent

Peter asks, “*Did you do the same multi-omic observation of the CSF in the mice, in parallel, to see if there was something new that was showing up in the CSF, to parallel the platelet factors in the plasma?*”

- Yes, they took both blood and CSF from the same mice; she hasn’t published it yet
- Cana repeated the findings in many different ways
- Ultimately, she did a series of studies demonstrating that this biology is real, that klotho is actually activating platelets very modestly

**Let’s first just step back, what is a platelet?**

- A [platelet](https://en.wikipedia.org/wiki/Platelet) is an anuclear cell in our blood, and it contains little compartments of bioactive chemicals, [chemokines](https://en.wikipedia.org/wiki/Chemokine)
- And when a platelet is stimulated or activated, it actually releases these factors, and it does so in a context dependent way
- So when there is a cut or a wound, there is a huge activation of platelets, and they release all sorts of factors that help with clotting and help with the wound healing
  - That’s what they’re traditionally known for

***But it turns out that when we exercise, our platelets are activated and they’re releasing factors that travel into the brain***

- Who would’ve thought that platelets could be messengers of brain health and could take center stage as a messenger of brain health?
- This was [found](https://pubmed.ncbi.nlm.nih.gov/37587147/) by an Australian group led by [Tara Walker](https://qbi.uq.edu.au/dr-tara-walker) that, when we exercise, platelets are activated, and certain platelet factors (one of them being [platelet factor 4](https://en.wikipedia.org/wiki/Platelet_factor_4)) are released and travel to the brain and actually causes neurogenesis or the production of new neurons in the brain
  - That was very new data
- With that data in mind, Dena felt like maybe there’s something to this klotho-platelet connection
- Cana isolated platelets and put klotho on them, and she found they released PF4 (platelet factor 4)

***She gave PF4 to mice as a shot in the belly (just like they had given klotho), and found it enhanced cognition in young mice, and in an aging mouse it reversed cognitive defects ‒ it was totally remarkable***

> “*This is where it gets weirder and wilder*.”‒ Dena Dubal

**More evidence for brain benefits of PF4**

- Dena wen to her colleague and close friend, [Saul Villeda](https://profiles.ucsf.edu/saul.villeda) at UCSF ‒ he’s the **young blood** and old brain scientist
  - He’s built a really nice body of experiments and literature [showing](https://pubmed.ncbi.nlm.nih.gov/37587343/) that, if you give young blood to an old mouse, it rejuvenates their brain
  - Dena shared these results with him and he said, “*Dena, we found the same thing with young blood, in that, when we give young blood to old mice, that young blood is enriched for platelet factor 4, which declines in aging. And then, we give platelet factor 4, we rejuvenate the old brain.*”
- Tara Walker in Australia [found](https://pubmed.ncbi.nlm.nih.gov/37587147/) the same thing with **exercise**: exercise increases PF4, and when she gives PF4 to old mice, it enhances their cognition

***This is an incredible convergence of biology, where klotho, young blood, and exercise were activating platelets, releasing PF4, and PF4 is enhancing the brain***

- The biology was amazing as they each had their own unique approach
- The practical question for these friends was: Are we competitors now? Or are we going to hold hands and go through the publication process together?
- They went to the editors and went through a couple years of revisions and reviews, and at the end of the day all 3 papers came out in the Nature family of journals on the same day
  - It made for an impactful splash
- Dena explains, “*This was amazing and a complete surprise that platelet factors could play a role here*.”

## The role of platelet factor 4 (PF4) and it’s interaction with GluN2B in mediating cognitive enhancement [46:45]

**Do we believe that it’s platelet factor 4 that is directly acting on GluN2B then? And if so, what do you think is happening at the level of substrate and receptor?**

- Dena looked at the question: Does PF4 actually cross into the brain?
  - And it does
  - They gave it peripherally, immediately looked into the brain, and saw it ended up near neural cells or even with neural cells
- The next question was: Does it act on the brain?
  - One of her lab members took hippocampal slices and put PF4 on it and immediately saw a change in the [membrane potential](https://en.wikipedia.org/wiki/Membrane_potential) (more calcium was being let in)
    - The hippocampus  is the area of the brain that is really executing the learning and memory and is targeted by aging and diseases of aging
- They thought maybe this would be GluN2B acting, and so, they put on GluN2B inhibitors, and PF4 no longer potentiated the synapse or enhanced the neural function

***We know that platelet factor 4, like klotho, is working through GluN2B; and maybe klotho is working through platelet factor 4 to change GluN2B***

Peter asks, “*Has that same experiment been done to look at the klotho that is derived from the choroid plexus to say, when you dump klotho directly onto GluN2B, you see an influx of calcium, when you block GluN2B, you abrogate the effect as well? So you now have two things, platelet factor 4 and klotho, that can independently do the same thing, is that a correct statement?*”

- They haven’t done that experiment yet
- They have done transgenic overexpression in the brain, and they’ve given klotho peripherally
- They haven’t dumped klotho itself onto the hippocampus to see whether there can be a direct effect
- Other groups have overexpressed klotho specifically in the brain and seen cognitive enhancement
- But Dena hasn’t seen studies that examine whether klotho is actually directly influencing GluN2B ‒ we know that it indirectly influences GluN2B

***We know that we can give klotho peripherally and it’ll increase synaptic plasticity through GluN2B, but we don’t know whether it can actually directly do that too***

**Dena asked the question: Is PF4 required for klotho-mediated cognitive enhancement?**

- To answer this, they generated a colony of PF4 knockout mice (they don’t have PF4)
- They gave them klotho versus vehicle (always randomized and blinded) and put them through a series of cognitive tests
  - Cognitive tests : water maze, large Y-maze, one maze after another, because you like to see the same effect reproduced
  - [vehicle is the placebo-control here]

***What they found was that klotho continued to enhance cognition, even in the absence of platelet factor 4 (to the same extent)***

**Peter’s takeaway**: it tells us there’s more than one factor

- It has to be such an important pathway and it is so conserved that there is no way biology is going to let one thing be the messenger
  - Peter is making all this up, of course, but hypothesizing that, if klotho is so important, it can’t be limited to one messenger
  - If it gets to the gate and it can’t get through, it has to have multiple messengers that it can deliver the message to, PF4 being one of them

*Clearly, this experiment would suggest that there’s at least one other messenger, right?*

- Right

***PF4 is sufficient to recapitulate the klotho-mediated cognitive enhancement but it is not necessary***

**What other signals were in that first experiment?**

- Peter wonders if there was something else that was missed, because PF4 was such a big signal
- Dena explains there were many signals, many other platelet factors, many other proteins
- They are systematically marching through those proteins and metabolites
- They are asking this in a cell type specific way using a system called [TurboID](https://www.creative-biolabs.com/turboid.html)
  - This labels the protein as it’s secreted from the liver, the kidney, the heart, from lymphocytes
  - It’s a really unique and elegant genetic manipulation that does a biotin label once a protein is secreted
- They’re asking, “*When we inject klotho, what gets secreted out of the liver and into the plasma?*”
- They’re doing higher resolution studies to understand how klotho really changes the systemic circulation in a cell type specific way, and they they’re asking, “*Which one of those factors that comes from the kidney, the liver, the lymphocytes, the heart, which one of those factors is necessary and required for klotho-mediated enhancement?*”
- The answer at the end of the day might be that there are many factors that have overlapping functions of cognitive enhancement
  - Maybe the work together
  - Maybe they work independently
- Dena agrees, this is a very important biologic function and it shouldn’t rely on just one factor

**More about the assay where you add PF4 or klotho to the GluN2b subparticle of NMDAand see a massive influx of calcium**

- It seems reasonable to Peter that this assay could become a great screening tool to see if you can enhance cognition
  - You run the risk that if klotho is working through secondary mechanisms, you’ll miss it
  - But it’s good as a first screen for a whole bunch of molecules to look for activation and then go back and search the serum for the molecule
- Dena is doing it, and they’re doing it with synaptic plasticity as a measure, as a substrate of cognition
- They’re also doing it in vitro at the cellular level, using live cell imaging, where they can isolate neurons from a mouse brain
  - They grow beautifully on a dish
  - They connect with each other
  - They survive for weeks on end
  - And you can do live cell imaging to see whether, if you put klotho on
- Her graduate student (Barbara Shariva) is doing this right now
  - Putting klotho onto neurons and these other factors that we’re seeing from the omics onto neurons and seeing whether there is an increase in the neurite outgrowth and the connections, the physical connections, between neurons
  - This isn’t cognition itself, but it’s a substrate of cognition ‒ it’s a way to screen with synaptic plasticity, with the outgrowth of the neurons connections

## Benefits of klotho observed in a mouse model of Parkinson’s disease [55:45]

**Benefits of klotho for Parkinson’s disease**

- Peter thinks all of this makes a lot of sense for a mouse model of Alzheimer’s disease, where the primary deficit is a cognitive deficit that seems disproportionately focused in memory
- Dena also mentioned earlier that she is seeing positive signals in a mouse model of Parkinson’s disease

Peter asks, “*Are you seeing them, in the mild cognitive impairment, that it can accompany Parkinson’s disease? Or are you seeing it in the movement disorder? Are you seeing an improvement in the primary issue associated with Parkinson’s disease?*”

- Part of this is [published](https://pubmed.ncbi.nlm.nih.gov/28793260/) and part is in the peer-review process
- They took mice that overexpress [alpha-synuclein](https://en.wikipedia.org/wiki/Alpha-synuclein)
  - This is a pathogenic player in [Parkinson’s disease](https://en.wikipedia.org/wiki/Parkinson%27s_disease): it disrupts the synapse and has a causative role in Parkinson’s disease
  - We know that people with mutations and causing overexpression of alpha-synuclein will develop Parkinson’s disease
    - It’s like the equivalent of APP in people with Alzheimer’s disease, where it’s not necessarily the dominant driver of the disease, but it’s clearly playing a causal role (based on these mutation studies)
    - The mice Dena used for her Alzheimer’s studies were APP mutant overexpressors
- The Parkinson’s model mice have both motor defects and cognitive difficulties
  - They have motor difficulty
    - If they walk across a balance beam and they’ll fall
    - If they’re put on a spinning rod, they’re discoordinated and they’ll fall
  - They also have cognitive difficulties, but not as severe as the Alzheimer’s model mice
    - They have difficulties in their ability to map a spatial environment and to hold memory in their mind with working memory

*They did 2 things with the Parkinson’s model mice*

- 1 – They injected them with klotho and remarkably saw that klotho treatment improved their cognition [summarized in the figure below]
  - It didn’t normalize, but it improved their cognitive abilities by maybe 70% or so (it nearly normalized their cognitive functions)

![](https://peterattiamd.com/wp-content/uploads/2024/05/f1-denadubal.png)

**Figure 1. Brain benefits of klotho injection**. Image credit: [*Cell Reports* 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5816951/)

- 2 – It didn’t do anything to their motor functions, so they continued to have motor dysfunction, and klotho did not help that
- That was also true with the transgenic overexpression of klotho all over the body and brain for a lifetime
  - That warded the cognitive deficits induced by Parkinson’s toxicity, but it did nothing for the motor problems
- Dena has spoken to her Parkinson’s colleagues about this, and there’s a lot of interest in potentially using klotho as a treatment for Parkinson’s disease
  - In the clinic, they can treat the tremor and the rigidity, but people complain constantly about the cognitive deficits
    - And those deficits specifically are problems with executive function, which is the ability to focus, to shift attention, to make certain judgments, to think quickly, and it is mediated by the prefrontal cortex, an area that became important when we looked at human studie

***The bottom line was that, in mice, klotho really enhanced, cognition, but didn’t do anything for motor functions***

**Is there a mouse model that fits between the Alzheimer’s model and the Parkinson’s model, that is more akin to a Lewy body dementia model, where it has some of that alpha-synuclein pathology, but als, has a much more significant cognitive component?**

- There are so many mouse models
- A good good mouse model for Lewy body would be alpha-synuclein and maybe more in the brainstem and the hippocampus and cortex
  - Dena bets there is one but is not clear
- Peter thinks a reasonable hypothesis would be that it would provide some relief of the cognitive symptoms but not necessarily the movement symptoms
  - Yes, this is what Dena is seeing consistently

**Analogy to understand how klotho helps the brain during neurodegenerative disease**

***Think about klotho as a helmet to protect neurons***

- So that whatever came crashing the cell’s way (whether it was alpha-synuclein, tau, amyloid beta, aging stresses), that neuron was protected
- The effect of klotho is really in cognition itself (in hippocampal and frontal cortical circuits), that these neurons and glia and other cell types are really protected against multiple toxicities

**Dena thinks this is the time to really move klotho toward human clinical trials**

- She asks, “*Wouldn’t it be amazing if we had a cocktail for Alzheimer’s disease, in addition to* [*lecanemab*](https://en.wikipedia.org/wiki/Lecanemab) *or* [*donanemab*](https://en.wikipedia.org/wiki/Donanemab)*, that’s removing the amyloid beta from the brain? What about adding something like klotho that can really help shore up the functions of the cells?*”
- We know that Alzheimer’s disease is a multi-proteinopathy
  - It’s not just one protein that’s causing the disease
- We need cocktails that can really resist multiple protein toxicities

> “*I have this dream that people might be able someday to benefit from klotho, this factor that naturally circulates in our body, that helps with longevity, that helps with other organ systems and enhances the brain.*”‒ Dena Dubal

- We know from our monkey studies, that klotho has a long-acting action
- For at least a couple of weeks (if not more), there is funding for a certain amount of time

***We need to put helmets around the neurons to really stave off multiple toxicities, and this is what klotho does ‒ it protects our brains***

- Peter replies, “*Yeah, you’re preaching to the, not just the choir, but the fully converted*.”

## Benefits of klotho observed in a mouse model of Alzheimer’s disease [1:03:00]

**In a mouse model of Alzheimer’s disease (maybe the APP mouse) how old is the mouse when it starts to develop clinical disease, accumulate amyloid in the CSF?**

*And then, when does it start to show cognitive impairment?*

- It depends on the mouse model and there are so many [mouse models of Alzheimer’s](https://www.frontiersin.org/articles/10.3389/fnmol.2022.912995/full) (including APP models)
- One that Dena has used consistently is called a [J20 model](https://www.alzforum.org/research-models/j20-pdgf-appswind)
  - It expresses human APP, which produces amyloid beta in mutant forms, and it’s a more aggressive model
  - It causes synaptic loss (that connection between cells), and it really disrupts that connection between cells really early, before 3 months
  - Then it starts producing cognitive deficits at around 3-4 months

**Has the experiment been done where you give those mice klotho starting at birth at a high dose, and does it delay the onset of the inevitability?**

- Overexpression of klotho throughout the brain and body of those APP mice will allow them to have almost normalized cognition
- But we don’t know whether it’s delaying the onset of disease
- Dena has taken the J20 mouse (the APP mutant) and caused it to overexpress klotho by about 3-4-fold; the [results](https://pubmed.ncbi.nlm.nih.gov/25673831/) are
  - 1 – That mouse will live much longer (extended lifespan)
  - 2 – It will normalize its cognition across its lifespan
  - 3 – When you look at the levels of amyloid beta and of tau in its brain, they’re not different from the mice without high levels of klotho

***In other words, their brains are still riddled with the Alzheimer’s toxins, but they’ve been able to really thwart the effects of those toxins because they show normal cognition***

- In collaboration with [Lennart Mucke](https://profiles.ucsf.edu/lennart.mucke) and [Eliezer Masliah](https://www.nia.nih.gov/about/staff/masliah-eliezer), they looked at the synapses in the brains of these mice and [found](https://pubmed.ncbi.nlm.nih.gov/25673831/) that the synapses were all preserved
- Again, this analogy where klotho is really providing a helmet around each neuron, it really allowed the synapses to be preserved, but there was a whole bunch of amyloid and tau still there, and that is resilience

***The toxins won’t necessarily go away with klotho (at least in mice, the story may be different in humans), but klotho provided resilience and thwarted the toxicities of Alzheimer’s disease***

- Peter believes that at some point we will have klotho as a drug, and Dena agrees that it’s going to come to market
- The question is: do we believe klotho is a drug we will only want to give to people once they have [MCI](https://en.wikipedia.org/wiki/Mild_cognitive_impairment), or do we believe that anyone who’s susceptible will be given it, even before there is a demonstrated disease risk?

## Promising results of klotho in primate models, and the importance of finding an appropriate therapeutic dose before moving to human trials [1:08:00]

- The body of literature in mice is incredible
- It’s reasonable to be circumspect around mice literature, but when you start to talk about the volume of literature here and the breadth of mouse models and the number of investigators that consistently find the same results and the magnitude of the results, it passes “the eyeball test”
  - This looks incredible, but it would be nice if we  had a more convincing model

**Primate brains and the body of literature around klotho in that brain**

- Dena doesn’t work with monkeys, testing cognition in monkeys is a very, very specialized field
- About 8 years ago, she really wanted to know whether klotho can enhance a more complex brain than a mouse brain
- Mice are really important in scientific discovery, but there are so many examples of what worked in mice and cured Alzheimer’s disease failed in humans
  - That’s the valley of death: works in mice, doesn’t translate to humans
  - It’s not true for everything
  - And mice have been very, very important for fundamental scientific discovery and for medicines
- Dena wanted to test klotho in primates, and she was pitching this all across Silicon Valley to biotech and pharma
- She joined forces with [Ned David](https://unitybiotechnology.com/team/nathaniel-david-2/), who had started the company [Unity Biotechnology](https://unitybiotechnology.com/about-us/) to attack aging
  - They fundraised and found really great collaborators at Yale to test klotho and cognitive enhancement in a brain like ours
- When people would tell her, “*If it doesn’t work, it’s going to kill your research program*.”
  - She would say, “*Let it die then. I don’t want to spend my career on something that’s not important. If it’s done well, we’ll know.*”
- [Rhesus macaques](https://en.wikipedia.org/wiki/Rhesus_macaque) are incredible organisms
  - They have very complex brains
  - They are more genetically diverse than humans
    - And that genetic diversity is something that often trumps effects
    - It can often really influence whether an effect is able to survive genetic diversity or not, and having a lot of genetic diversity is very important to really challenge and test the biology
    - Mice are inbred: they all have the same genetics
  - They have a functional complexity that’s very similar to humans in terms of even more of the neural circuits (the hippocampus, the prefrontal cortex)
  - And they have an anatomic complexity that’s pretty similar to us
- By testing klotho in nonhuman primates, the idea was to jump over this valley of death
  - If it worked in primates, let’s look towards humans
  - If not, let’s do something else
- Peter realizes that was a huge “burn your ships” moment
  - She was a wildly successful investigator before this who had a lab group of 7-11 people (PhDs, post-docs, students)
  - She had a well-oiled machine generating R01s and all sorts of grants

Peter asks, “*It’s not easy to start all over again if all of that dries up, right?*”

- Dena explains that’s why it was so risky
  - Some people just go to a human trial and do biomarkers, but this is risky
  - It’s risky if it’s not done well, but it’s super informative, even if it’s negative
    - If it’s good negative data and not because the experiments were done in a sloppy way, then it really tells you something
- She had other projects on longevity
  - She studies why women live longer than men, what does a second X chromosome have to do with it?
  - And there are other longevity factors

***It was really important to push forward and to push forward in a rigorous way and also with the knowledge that the results could really change the direction of what we’re doing***

> “*I really want to be doing something that I have a lot of faith in and that potentially has meaning for the human condition, to improve human health. And if we’ve done a really great experiment that’s negative and there’s really reason to believe that this isn’t going to go forward, then that’s fine*.”‒ Dena Dubal

- Dena explains that we don’t have lifetimes to devote to 100 different scientific projects
- We have to be very choosy, and she really, really wanted to make sure that this is something really worth putting time, energy, resource, passion, constant thought, training, fundraising
- Peter commends Dena for something he doesn’t think most scientists would be willing to do ‒ the job is knowledge creation for the purpose of making lives better
  - Science is a process for knowledge creation and these are very different things, they overlap, and it’s easy to lose sight of that in the weeds
  - He doesn’t think everyone would have come to the same conclusion as Dena did

**How Dena and her colleagues at Yale thought of the right question to ask and the right experimental design**

- Monkeys undergo cognitive decline in a very similar parallel fashion to humans
  - They have synaptic loss (the connection between neurons) with aging, as do humans do
  - The circuits that are affected in aging are really similar to the human circuits
    - They are the hippocampal frontal circuits, the hippocampus and the frontal lobes, and aging will preferentially target working memory and also spatial memory and other types of memory
    - But this working memory: holding something in your mind, you go to the refrigerator, you open the door and you think, why did I come here? What was holding that immediate memory in your mind is something that aging really targets
- There are ways to test monkeys that interrogate those circuits, and a spatial delay task was used
  - [Graham Williams](https://www.linkedin.com/in/graham-williams-b5b71851/) and Stacy Castner conducted the studies
  - Klotho actually preferentially targets those circuits that aging erodes
- Summary of the model system
  - It’s genetically, anatomically, functionally complex
  - It undergoes cognitive aging parallel to humans, and there are really well-developed tests by these exceptional scientists who are very experienced and adept at conducting these tests

***It was a really excellent setup to ask: Can klotho enhance cognition in these aging monkeys?***

- They used something called a **spatial delayed response**
  - The monkeys are presented with a bin of multiple wells, and a treat is placed in a well, they can see you place the treat
    - Sometimes there’s a few wells and sometimes there’s a lot of wells
    - It’s harder when there’s a lot of wells to find a treat
  - Then a screen drops and all the wells are covered so that you cannot see where the treat is
  - Then the blind is opened and they are tested where to choose because they’re basing this on spatial memory and on working memory of where that treat was
    - Again, it’s a little easier if there’s only 3 wells, it’s easier to choose 1 out of 3 and get it correct
    - It’s harder when there’s 9 wells to remember spatial and working memory where that treat was
- The [study](https://pubmed.ncbi.nlm.nih.gov/37400721/) was done very rigorously, it was largely blinded so that the injection of klotho wouldn’t cause stress in memory
  - Everyone got a baseline, they then got a vehicle, and then they got vehicle or klotho
  - Vehicle is the placebo control
  - [results shown in the figure below]

***It was blinded, the monkeys that got a klotho treatment, and they performed better than the ones that got vehicle treatment***

![](https://peterattiamd.com/wp-content/uploads/2024/05/f2-denadubal.png)

**Figure 2. Cognitive testing of aged rhesus macaques after klotho (KL) injection**. Image credit: [*Nature Aging* 2023](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10432271/)

Peter asks, “*How did you guys decide how to raise the dose?*”

- He assumes that when they did the experiments on mice they were dosing a certain number of milligrams per gram of the animal
- They went with 2 things in mind
  - 1 – They wanted to stay at least with 1 dose in a physiologic range ‒ something that the body has been exposed to and has seen over its lifetime (**a physiological dose**)
    - This is what they have always used in mice
  - 2 – And another dose they wanted to go somewhere up to maybe 4-5-fold higher (**a rejuvenating dose**)
    - This was meant to test if you could push the system to improve cognition more than what is observed with that physiological dose
    - Giving this huge dose in mice enhanced cognition

Peter asks, “*When you gave the supraphysiologic doses to mice, so presumably tenfold and beyond, did you run into any problems? For example, did the mice ever develop antibodies to the protein? Did anything else arise that would suggest that more is not always better?*”

- They didn’t see signals in mice, but they didn’t systematically study where doses of 100 mg/kg was doing something different
- They didn’t observe differences in their normal behaviors or their basic blood work
- It worked, but it didn’t work better

***In mice, super low doses worked just as well as super high doses***

Peter asks, “*If we call 6X [the physiological level] the peak dose, what was the minimum effective dose in mice relative to that?*”

- More than 5X less, a very small dose
- As Dena remembers it, if they gave mice 10 micrograms/ kg
  - 0.5-2 micrograms enhanced cognition
- Just a touch more enhanced cognition, and their strategy was to stay within a physiologic dose and make sure that that was represented in the monkey studies
- Dena really thought about this, consulted with people that have taken drugs to market
  - Tom Boone is one of them and was very instructive and taught her a lot in terms of thinking about relevantly dosing in monkeys
- They also used higher doses than the body has seen, 10X higher, maybe 20X higher and beyond

***What they found is that the low physiologic, that natural dose of klotho enhanced cognition in the monkeys, and it did so within 4 hours; and that cognition stayed better***

- Their ability to think, remember, stayed better for at least 3 weeks, and some were even tested out to a month
- At some point the study had to be stopped (it was $1 million or more)
- Dena explains, “*But it was remarkable that one* [*SubQ*](https://en.wikipedia.org/wiki/Subcutaneous_administration) *dose (like a shot of* [*Ozempic*](https://en.wikipedia.org/wiki/Semaglutide) *would be given), a SubQ dose that was low physiologic, had an immediate effect on cognitive enhancement that lasted for a very long time*.”

**They ran different types of tests**

- One was for normal memory load and one was for high memory load
- The high memory load was a test with a lot of different bins where they had to remember which 1 among 7 or 8 wells had the treat hidden in it
  - It’s just more taxing with more choices to remember
  - And they did even better in that study of high memory load, with a low dose

***Monkeys receiving klotho were particularly smarter when the task became harder***

> “*It all came together because klotho works on these circuits that are tested in the monkeys that decline with aging and with neurodegenerative diseases like Alzheimer’s and Parkinson’s*.”‒ Dena Dubal

**A high dose did not work**

- The high doses that gave the monkey’s klotho way beyond what they’ve seen in their lifetime, they didn’t harm, they did not impair cognition, but they didn’t help cognition
- It’s not too much of a stretch to think that too much of something that does multiple things in the body and maybe multiple pathways that could just create an imbalance that doesn’t support cognitive function
- That was different from the mice
  - And this may be a big difference between mice and a more complex brain with a non-human primate
  - In mice, they saw continued cognitive enhancement
- In monkeys they really got a window before going into clinical trials that if they’re giving klotho, they probably should be thinking about a specific therapeutic window: one that the body knows, one that the body is used to

## Speculating why a single klotho injection has such long-lasting effects [1:25:30]

**Why do you think the effect lasts for so long?**

- To Peter, this is a little counterintuitive when you consider the hourly variation of klotho naturally
  - When you consider the transient effects potentially of things like exercise where you see these large boosts over a short period of time following a bout of exercise
  - But it seems hard to imagine that the benefits of an hour of exercise persist 3 weeks later the way a subcutaneous injection of klotho did
- Dena doesn’t know but she’ll speculate
- This is remarkable as we imagine therapeutics that maybe this type of treatment could be administered maybe once a month, once every 3 months as a shot in the arm (for example)

***Mechanistically, this means that klotho has not just an acute effect of immediately enhancing*** [***NMDA receptor***](https://en.wikipedia.org/wiki/NMDA_receptor#Structure) ***functions (synaptic plasticity, cognitive function) at 4 hours, but it has an organizational effect: it’s doing something to in the longer term, really help to remodel a synapse (for example)***

- She would imagine with [GluN2B](https://en.wikipedia.org/wiki/GRIN2B) being trafficked to the synapse and to promote better functions that those sort of synaptic organizational effects are happening for and staying put for a longer period of time
- She thinks the biology of this organizational effect of klotho has yet to be discovered, but it’s something that’s happening at the synapse
  - She has a very strong sense of something that’s happening organizationally, structurally at the synapse

## Potential cognitive benefits of klotho in humans, the impact of the KL-VS genetic variant on klotho levels, and the need for human trials to confirm these effects [1:27:45]

**What evidence do we have in humans?**

*People listening are wondering, “Is this going to make a difference for my mom or for my dad who are in the early stages of dementia? Is this going to make a difference for me because of my risk factors, even though it’s 20 years from now?”*

Peter also asks about a SNP associated with the *Klotho* gene called *KL-VS*

- Dena agrees that none of this matters if it doesn’t have potential to help the human condition
- She won’t know if they’ve done anything big until they test klotho in humans
- In 2011, 2012 when they were first testing klotho in mice and discovering these cognitive enhancing effects, she was thinking about patients
  - Remember, she’s a physician scientist
  - She’s thinking about Alzheimer’s disease, 50 million people around the world
    - And this is going to triple by 2050

> “*Cognitive decline is our biggest biomedical challenge*.”‒ Dena Dubal

- Dena went to her friend and colleague, [Jennifer Yokoyama](https://profiles.ucsf.edu/jennifer.yokoyama) at the Memory and Aging Center at UCSF, and told her about this genetic variant of klotho
- She’s a geneticist and she and others at the Memory and Aging Center, [Joel Kramer](https://profiles.ucsf.edu/joel.kramer), [Bruce Miller](https://profiles.ucsf.edu/bruce.miller), have built this incredible population of individuals and patients with Alzheimer’s disease, with normal aging, with frontotemporal dementia
  - And they really carefully characterized their genetics, their blood biomarkers, etc.
- Dena went to Jennifer and asked, “*Is there any way we can know whether this genetic variant of* [*Klotho (KL-VS)*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9682425/#:~:text=A%20common%20haplotype%20consisting%20of,gene%20is%20termed%20KL%2DVS.&text=Heterozygosity%20for%20KL%2DVS%20is,of%20Klotho%20in%20normal%20aging.) *has any association with cognition?*”
  - Because that would mean that this klotho is important to brain
  - It would mean that there was some link with humans and brain health

**What is** ***KL-VS*** **and what does it associate with?**

- We all have klotho circulating in our blood and around are brain
- Some of us (about 1 in 4 or 1 in 5) carry a genetic code for klotho that leads to higher levels of production, and *KL-VS* refers to 2 [SNPs](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism) that cause a difference in the coding of the protein itself
  - People with 1 copy of this *KL-VS* (the [heterozygotes](https://en.wikipedia.org/wiki/Zygosity#Heterozygous)) will genetically have higher levels of klotho circulating in their blood
  - Very rarely will someone be [homozygous](https://en.wikipedia.org/wiki/Zygosity#Homozygous) for *KL-VS*, and those people end up having multiple disadvantages in lifespan and vulnerability to different diseases

***When we talk about KL-VS, we’re talking specifically about heterozygosity carrying one allele of it***

Peter asks, “*What are some of the health consequences of being homozygous, and what is the prevalence of homozygosity?*”

- If the prevalence of heterozygosity is around 25% of the population, it’s probably 1-2%
- It would kind of mirror [*APOE4*](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms), where the heterozygosity is about the same and homozygosity is about 1 in 50 to 1 in 100
- Those people have shorter lifespans, much lower levels of klotho, and they are at risk for anything that the heterozygosity helps with
  - Here homozygosity hurts

*The heterozygotes have been a really interesting window into klotho natural experiments*

Peter asks, “*How much higher is their klotho level?*”

- Dena and Jennifer did a [study](https://pubmed.ncbi.nlm.nih.gov/27714549/) where they took serum from a few hundred individuals here at the Memory and Aging Center and tested the ones that were non-carriers that just have the typical *Klotho* gene versus the *KL-VS* heterozygote carriers
- And the heterozygote carrier status increased klotho levels by about 15, maybe 20%
- Just to give you context, if you’re wondering, “*Am I carrier?*” ‒ exercise increases klotho on average by 30%

> “*I don’t want people to forget that exercise is thus far one of the more powerful modulators of Klotho expression and exercise increases Klotho on average by 30%, so much more than what the genetic influence is.*”‒ Dena Dubal

***KL-VS increases klotho levels by about 15%***

- For example, let’s say a non-carrier had 800 picograms/mL of klotho circulating in their serum, a *KL-VS* carrier might have like 950 pg/mL or so [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/05/f3-denadubal.png)

**Figure 3. Serum levels of klotho in non-carriers (NC), heterozygotes for** ***KL-VS*** **(HET), and homozygotes for** ***KL-VS*** **(HOM)**. Image credit: [*Brain Imaging and Behavior* 2017](https://pubmed.ncbi.nlm.nih.gov/27714549/)

- There’s reason to believe that [genetic changes in *KL-VS*] increases klotho because those 2 SNPs translate into a different amino acid in the protein itself influences secretion of klotho from cells
  - There’s a biologic reason that this variant is probably changing klotho levels

## The interaction between the *KL-VS* genetic variant and *APOE4* and how it impacts risk of Alzheimer’s disease [1:34:45]

- Listeners of this podcast are absolutely not strangers to the population-based [risk of *APOE4*](https://peterattiamd.com/peter-on-alzheimers-disease-prevention-and-the-latest-on-apoe4/) [see also the “Selected Links” section at the end]
- Of course, Peter always wants to remind people that at the individual level, it’s very difficult to make that statement; but at the population-based level, we know that having an *APOE3* and an *APOE4* is at least a doubling of risk, maybe even slightly more
  - And homozygosity for *APOE4* could be an 8-12 fold increase (call it a log-order increase in risk)

**What did you find in people who are homozygous and heterozygous for** ***APOE4*****, who also happen to be heterozygous for** ***KL-VS*** **(ie. have a single copy of the favorable variant of** ***Klotho*****)?**

- Back to that original experiment Dena [published](https://pubmed.ncbi.nlm.nih.gov/24813892/) with Jennifer in 2014 ‒ people that carrier the *KL-VS* allele did better across cognitive testing
  - This is in normal aging, not Alzheimer’s disease
  - Carrying *KL-VS* associated with better cognition across the board
  - They did better to the same extent that *APOE4* carriers would do worse
- Many groups and many people have looked at *KL-VS* in their populations, and that association has held largely in most studies (not in all)
- To the question of Alzheimer’s risk in individuals who carry *APOE4* and *KL-VS*, Dena collaborated in a [study](https://pubmed.ncbi.nlm.nih.gov/30867273/) led by [Ozioma Okonkwo](https://www.medicine.wisc.edu/directory/okonkwo_ozioma) that showed that these individuals has less of the effects of *APOE4* in terms of less Aꞵ deposition, less cognitive problems
- It was a smaller study of a few hundred people at risk for Alzheimer’s disease, but it was a good study
- The study Dena is most excited about (she’s not a part of) came from Stanford led by [Michael Belloy](https://profiles.wustl.edu/en/persons/michael-belloy-2)
- He and [Michael Greicius](https://profiles.stanford.edu/michael-greicius) are wizards at doing genetic population studies, and they did this remarkable [study](https://pubmed.ncbi.nlm.nih.gov/32282020/) of 22 different cohorts that were normal cognition, MCI (mild cognitive impairment), over 20,000 individuals, a very large meta-analysis
  - They looked at if there was a relationship between *KL-VS* carriers and *APOE4*

***The bottom line of what they found was that if an individual carried KL-VS, the APOE4 didn’t matter***

- What that actually meant in their experiment: in those people that carry *APOE4*, if they were also heterozygote for *KL-VS*, they had a decreased risk for developing Alzheimer’s disease that was pretty close to the normal population
  - They had a decreased conversion from MCI to AD, and they had decreased Alzheimer’s biomarkers both in their CSF and in their brain, they just had less amyloid beta
- It’s a really striking study because it has the power of statistical analysis, it holds across many, many cohorts and its many, many people

***They found that KL-VS essentially blocks the toxicity by this genetic association***

Peter asks, “*Did the double E4s, did the homozygotes reduce to a completely normal three-three [APOE3/APOE3] risk?*”

- Peter’s recollection was that people with the genotype *APOE3/APOE4 (3/4’s)*, their risk of Alzheimer’s was completely abrogated to the level of people with the genotype *APOE3/APOE3* (3/3’s)
  - And people with the genotype *APOE4/APOE4* (4/4’s) ended up coming way down, but they still looked more like a 3/4
- Dena explains that they didn’t actually publish that
  - They excluded the homozygotes from the analysis
  - But it might be in a supplement somewhere
- Dena had the same question and reached out to Michael about the 4/4s, and by verbal communication he indicated that the 4/4 also associated with the protection from the *KL-VS* heterozygosity
  - So the effect of having 1 *APOE4* wasn’t different than having 2 *APOE4*s in terms of *KL-VS* protection

***KL-VS protected both heterozygosity and homozygosity of the APOE4 allele***

Peter asks, “*Did they find anything negative?*”

- He’s going back to the mechanism of klotho, which in part is communicated through a platelet factor, and he’s wondering if there was an increase in stroke risk
  - Was there anything with an increase in a platelet factor that could have led to an increase in [DVTs](https://en.wikipedia.org/wiki/Deep_vein_thrombosis) or something?
  - When you have a sample size as large as they did, presumably you would find something that was negatively associated with the *KL-VS*
- Dena is not aware of an increase

***It’s actually the opposite: KL-VS heterozygosity actually associates with the protection against stroke risks, cardiovascular risks, and metabolic risks***

- She has searched for something that could be negative and found in the cancer literature that *KL-VS*  indicates a poorer prognosis in [*BRCA1*](https://en.wikipedia.org/wiki/BRCA_mutation) carriers with breast cancer

**Going back to the human homozygotes for** ***KL-VS*****, do we know how much of an increase in klotho they produce?**

- If the heterozygotes are producing 15 to maybe 20% more, Peter wonders how much more klotho is being produced by the homozygotes?
  - And does that give us an insight into toxicity in humans that was not observed in mice and not even observed in the primates?
    - In primates, when you gave too much, you just didn’t get a benefit, but you didn’t get a harm
    - In the mice, you actually got more and more benefit
    - As the organisms get more and more complicated it seems that the therapeutic window is getting narrower and narrower
- Dena and [Jen](https://profiles.ucsf.edu/jennifer.yokoyama) in the [Memory and Aging Center](https://memory.ucsf.edu/) at UCSF have access to homozygote serum and have looked at several homozygotes compared to non-carriers and heterozygotes
  - ***They found that klotho levels in homozygotes are actually lower than normal***
  - They think that has something to do with the genetic change
    - This is really important when we think about therapeutics
    - Many genetic variants won’t cause a change in the protein sequence itself
    - For example, if a nucleotide change is in an [intron](https://en.wikipedia.org/wiki/Intron), it’s just not going to change the structure or function or anything of the protein
- In *KL-VS*, there are 2 nucleotide changes and they translate into different amino acids in 2 places of the klotho protein
  - They speculate based on [in vitro studies](https://pubmed.ncbi.nlm.nih.gov/11792841/) that [Arking](https://www.arkinglab.org/people/) did in 2002, that in the klotho heterozygotes in which one allele is making a mutant protein, we think that there’s an overcompensation for that mutant protein by increasing wild type levels
    - Because what that variant does is it mucks up klotho secretion from the cell
  - Just to be clear, carrying one variant is likely changing the structure and function of klotho, but ***there’s probably an overcompensation from the wild type allele causing higher levels of the wild type klotho***
- Peter would not have guessed that
- He can’t believe he didn’t think to ask such an obvious question: Do the *KL-VS* individuals produce the same protein?

Peter asks, “*If you assay those individuals, are you finding 2 proteins in them? A protein that mirrors the wild type? That’s the one that’s elevated 15 to 20%, and an actual mutated protein or a protein that has 2 different amino acids (which again, to many people, sounds like a big deal*).”

- At this point, it’s the hypothesis that the wild type one is really compensating, overcompensating by increasing levels for what may be a mutant protein
- Dena has done [ELISA’s (enzyme linked immunoassays)](https://en.wikipedia.org/wiki/ELISA) on thousands and thousands of individuals, but the ELISA itself doesn’t distinguish between a KL-VS protein and a normal wild type klotho protein, and so the answer to that question is not known
  - Peter thinks an ELISA is just too blunt an instrument to figure that out

*If we take that a step further and ask: What’s happening in a klotho homozygote?*

- They’re expressing a mutant protein from one allele that mucks up secretion and they’re expressing a mutant protein from another allele that mucks up secretion

***The KL-VS homozygotes don’t have wild type klotho ‒ all of their klotho is the KL-VS form, and it’s very low***

- In Dena’s studies, if there was a 15% increase with heterozygosity compared to non-carriers, there was probably a 30% decrease with homozygosity compared to non-carrier
  - To give you a sense of numbers, if a non-carrier was at 800, a *KL-VS* homozygote carrier was below 600 (something like that)

## The significance of klotho levels: studies linking lower levels to increased mortality and the broader implications for organ health and disease prevention [1:47:15]

**Why klotho levels matter**

- It matters for many reasons
- There have been some really large scale studies recently, one is called the [NHANES study](https://pubmed.ncbi.nlm.nih.gov/34628493/) published in 2022, and what this study showed us is that klotho levels (as measured by ELISA) really correlated with mortality [shown in the figure below]
  - It was over 10,000 people in the United States
  - Klotho serum was measured on everyone
  - The mean age was about 56 years
  - If the mean klotho level was around 800 pg/mL, then something less than what they defined as 666 pg/mL was associated with a 30% mortality over 5 years

![](https://peterattiamd.com/wp-content/uploads/2024/05/f4-denadubal.png)

**Figure 4. Kaplan-Meier all-cause survival estimates by klotho quartiles**. Image credit: [*Journal of Gerontology* 2022](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9122743/)

- That finding was replicated in another study called [InCHIANTI](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3143348/): lower levels of klotho (maybe it’s like 30% of a decrease of levels) is associated with a 30% mortality over 5 years
- That mortality was primarily in cancer and cardiovascular disease

**Dena explains, “*****I think levels are going to matter. As we think about our human aging, as we think about our organismal health, heart health, brain health, cancer health, the levels, at least by association right now matter and lower levels are really associated with more diseases of aging.*****”**

**Peter’s takeaway**

- We have just spent 2 hours talking about the limits of our understanding of klotho and brain health, and yet this [NHANES study](https://pubmed.ncbi.nlm.nih.gov/34628493/) is looking at something totally different: all-cause mortality
  - If you’re in your 50s and your klotho levels are 30% below what would be expected for someone to your age, it’s associated with a 30% increase in all-cause mortality over the next 5 years
- The manner in which that death was distributed was cardiovascular and cancer
  - So it doesn’t’ even have to do with more dementia, which wouldn’t be kicking in in your 50s

***If low levels of klotho turn out to be causal, it suggests that klotho is doing even more than just protecting brain health***

**What are your thoughts as to how that could be happening?**

- Dena’s expertise is as a neurologist and neuroscientist
- The side effects of klotho increasing may be much more than helping brain health

***It clearly has a very strong association with protection against cancer, cardiovascular disease, and kidney disease***

- There is a very, very large literature on klotho and organ health, a very strong one in the cancer field
- There are many preclinical models, in rats and mice that show that giving klotho (the soluble hormonal form) actually stopped and reversed cancers in mice like pancreatic cancer
- There are association studies in humans too

> “*There is so much more to the biology of Klotho than only what it’s doing in the brain.*”‒ Dena Dubal

**In kidney disease, klotho is going to come to market and maybe the kidney people will beat the brain people**

- In **chronic kidney disease**, there is a decrease in klotho secretion and decrease in klotho in the blood
- The kidney specialists are really developing klotho as a **diagnostic biomarker** to understand when the kidney starts failing
  - The idea there is that right now the measures are [glomerular filtration rate](https://en.wikipedia.org/wiki/Glomerular_filtration_rate), urea, and these are not as sensitive as they would want biomarkers to be in detecting kidney dysfunction
  - As soon as the kidney starts having trouble, klotho declines, as soon as it starts having trouble
- Dena suggests, “*If we think in the broader sense about klotho, maybe someday (and maybe someday soon) we would have our klotho levels checked just as we do our blood pressure and our cholesterol and we get breast exams and we have colonoscopies. Why not have a klotho level checked? Everyone’s will be different.*”

## Measuring klotho levels and determining an individual’s KL-VS status [1:52:15]

**How do we get around the issue that it has this diurnal effect?**

- What jumps to his mind when you’re talking about a marker of [eGFR](https://en.wikipedia.org/wiki/Glomerular_filtration_rate) is the markers he looks at ([cystatin C](https://en.wikipedia.org/wiki/Cystatin_C) and [creatinine](https://en.wikipedia.org/wiki/Creatinine)) don’t depend terribly on the time of day

*Do you think the answer is to have it done 60 minutes after you wake-up in the morning, it’s non-negotiable?*

- Dena thinks that is going to give us the best and more accurate level of klotho
- She has done thousands and thousands of klotho measurements in human serum and human CSF (cerebral spinal fluid), and she always makes sure that the specimen is collected in the morning when the patient is fasting

*Why? Do you know that eating impacts klotho levels?*

- She doesn’t know that it’s been tested per se
- It would be one less confounding factors in the background
- The decline by age is a consistent decline, but the time of day does matter because it can decrease by almost 40% by midnight
- In the literature, the diurnal rhythm of klotho has been shown in a small number of people (but the data looked good) that it’s not really statistically different until afternoon, but it’s starting to decline

***If Dena had to design the time and day, she  would say that we need a klotho test that people take in the morning fasting like they do with their cholesterol***

- Just get it along with the cholesterol draw

**And most importantly, we need a standardized assay**

- There is not a [CLIA](https://en.wikipedia.org/wiki/Clinical_Laboratory_Improvement_Amendments)-based assay for this, but Dena thinks it’s coming
- Everything done in Dena’s lab is consistent to their methods and standards, and they standardize everything
- But her lab may have slightly different values than what is going on in another lab

Peter asks, “*If I woke up in the morning and I checked my level and I was at 800 pg/mL… and then from 7:00 to 9:00 in the morning, I’m in the gym, I could easily be 1200 pg/mL after. How does that impact our understanding of what’s going on?*”

- Dena thinks this is a really good, important point
- She wants to emphasize that the human studies show chronic exercise increases klotho after a 3 months, and there’s been a mouse study that shows an acute bout of exercise can really nearly double klotho
- It would be important to get a baseline level of: where are you living?

***She has not seen human data that demonstrate that acute bouts of exercise dramatically change klotho levels***

- Peter likes to test his patients to see if they have the *KL-VS* polymorphism (especially those who are higher risk for Alzheimer’s disease), and it’s very difficult to get that information

**How are you guys getting that information? Are you aware of any commercial assays for individuals to determine their** ***KL-VS*** **status?**

- Peter can’t seem to get it out of [23andMe](https://www.23andme.com/)
- When Dena collaborates with clinical researchers, they have their populations completely genotyped for *Klotho*, *APOE4* and most other genes out there with the polymorphisms
  - There’s been a really deep sequencing and genetic screen of all of those individuals
- She’ll have to get back to him on this question

## The promising potential of klotho for Alzheimer’s disease treatment, and the importance of philanthropy for funding research [1:58:00]

- This has been a fascinating discussion
- For a disease like Alzheimers (which he calls 1 of the 4 horsemen of death), there’s very little we offer patients once they’re in the throes of the disease
- Even with the advent of anti-amyloid therapies, they have barely put a dent in this enormous problem
- For that reason, Peter is very excited about this and applauds Dena’s work
- This is only the beginning, and we have to get this into human clinical trials
- Philanthropy can have an enormous impact in science
  - For something that is too risky for the NIH to fund or for industry to fund
  - But has enough biologic plausibility and enough potential upside that if it works, it’s a game changer
    - Klotho is a poster child for that type of work

§

## Selected Links / Related Material

**Chronic stress associated with lower klotho levels**: [Longevity factor klotho and chronic psychological stress](https://pubmed.ncbi.nlm.nih.gov/26080320/) | *Translational Psychiatry* (A Prather et al 2015) | [18:30]

**Chronic stress associated with lower klotho levels and shorter telomeres**: [Associations between klotho and telomere biology in high stress caregivers](https://pubmed.ncbi.nlm.nih.gov/37580799/) | *Aging* (R Brown et al 2023)  | [19:30]

**Exercise increases klotho levels**: [A systematic review and meta-analysis demonstrating Klotho as an emerging exerkine](https://pubmed.ncbi.nlm.nih.gov/36266389/) | *Scientific Reports* (H Correa et al 2022)  [20:15]

**Peter’s discussions about BDNF**: [21:00]

- [Aerobic exercise for Parkinson’s disease](https://peterattiamd.com/benefit-of-exercise-in-parkinsons/) | PeterAttiaMD.com (E Donahue, K Niotis, K Birkenbach, P Attia 2024)
- [#236 ‒ Neurodegenerative disease: pathology, screening, and prevention | Kellyann Niotis, M.D.](https://peterattiamd.com/kellyannniotis/) (January 2, 2023)
- [Muscle Mass and Cognitive Function](https://peterattiamd.com/muscle-mass-and-cognitive-function/) | PeterAttiaMD.com (A Misic, K Birkenbach, P Attia 2022)

**Klotho enhances learning, and memory, and cognition in old monkeys**: [Longevity factor klotho enhances cognition in aged nonhuman primates](https://pubmed.ncbi.nlm.nih.gov/37400721/) | *Nature Aging* (S Castner et al 2023) | [26:15, 1:17:45]

**Overexpression of klotho in amuse model of Alzheimer’s**: [Life extension factor klotho prevents mortality and enhances cognition in hAPP transgenic mice](https://pubmed.ncbi.nlm.nih.gov/25673831/) | *The Journal of Neuroscience* (D Dubal et al 2015) | [28:15, 1:06:30]

**Overexpression of klotho enhances cognition in mice**: [Peripheral Elevation of a Klotho Fragment Enhances Brain Function and Resilience in Young, Aging, and α-Synuclein Transgenic Mice](https://pubmed.ncbi.nlm.nih.gov/28793260/) | *Cell Reports* (J Leon et al 2017) | [31:30]

**Klotho injection induces platelet factors**: [Platelet factors are induced by longevity factor klotho and enhance cognition in young and aging mice](https://pubmed.ncbi.nlm.nih.gov/37587231/) | *Nature Aging* (C Park et al 2023) | [39:30]

**Platelet factors in the blood of young mice rejuvenates the brain of old mice**: [Platelet factors attenuate inflammation and rescue cognition in ageing](https://pubmed.ncbi.nlm.nih.gov/37587343/) | *Nature* (A Schroer et al 2023)  [44:15]

**Platelet factor 4 enhances cognition in old mice**: [Platelet-derived exerkine CXCL4/platelet factor 4 rejuvenates hippocampal neurogenesis and restores cognitive function in aged mice](https://pubmed.ncbi.nlm.nih.gov/37587147/) | *Nature Communications* (O Leiter et al 2023) | [45:15]

**Benefits of klotho for a mouse model of Parkinson’s disease**: [Peripheral Elevation of a Klotho Fragment Enhances Brain Function and Resilience in Young, Aging, and α-Synuclein Transgenic Mice](https://pubmed.ncbi.nlm.nih.gov/28793260/) | *Cell Reports* (J Leon et al 2017) | [56:30]

***KL-VS*** **heterozygotes have increased klotho levels**: [Systemic klotho is associated with KLOTHO variation and predicts intrinsic cortical connectivity in healthy human aging](https://pubmed.ncbi.nlm.nih.gov/27714549/) | *Brain Imaging and Behavior* (J Yokoyama et al 2017) | [1:33:00]

**Peter’s discussions about** ***APOE4***: [1:35:00]

- [#18 – Richard Isaacson, M.D.: Alzheimer’s prevention](https://peterattiamd.com/richardisaacson/) (October 1, 2018)
- [#138 – Lauren Miller Rogen and Richard Isaacson, M.D.: Alzheimer’s disease prevention—patient and doctor perspectives](https://peterattiamd.com/laurenmillerrogen-richardisaacson/) (November 23, 2020)
- [Peter on Alzheimer’s disease prevention and the latest on APOE4](https://peterattiamd.com/peter-on-alzheimers-disease-prevention-and-the-latest-on-apoe4/) | PeterAttiaMD.com (P Attia 2022)
- [#255 ‒ Latest therapeutics in CVD, APOE’s role in Alzheimer’s disease and CVD, familial hypercholesterolemia, and more | John Kastelein, M.D., Ph.D.](https://peterattiamd.com/johnkastelein/) (May 22, 2023)

**Carrying** ***KL-VS*** **associated with better cognition**: [Life extension factor klotho enhances cognition](https://pubmed.ncbi.nlm.nih.gov/24813892/) | *Cell Reports* (D Dubal et al 2014) | [1:35:45]

***KL-VS*** **reduces Alzheimer’s risk in** ***APOE4*** **carriers**: [*KLOTHO* heterozygosity attenuates *APOE4*-related amyloid burden in preclinical AD](https://pubmed.ncbi.nlm.nih.gov/30867273/) | *Neurology* (C Erickson et al 2019)| [1:37:15]

**Meta-analysis: Alzheimer’s risk reduced in** ***APOE4*** **carriers who also carry** ***KL-VS***: [Association of Klotho-VS Heterozygosity With Risk of Alzheimer Disease in Individuals Who Carry APOE4](https://pubmed.ncbi.nlm.nih.gov/32282020/) | *JAMA Neurology* (M Belloy et al 2020) | [1:38:00]

**In vitro studies of klotho production in cells heterozygous for** ***KL-VS***: [Association of human aging with a functional variant of klotho](https://pubmed.ncbi.nlm.nih.gov/11792841/) | *PNAS* (D Arking et al 2002) | [1:44:00]

**Low klotho levels associated with increased mortality**: [Low Serum Klotho Associated With All-cause Mortality Among a Nationally Representative Sample of American Adults](https://pubmed.ncbi.nlm.nih.gov/34628493/) | *The Journals of Gerontology* (J Kresovich, C Bulka 2022) | [1:47:15]

**InCHIANTI study measurement of klotho levels and mortality**: [Plasma klotho and mortality risk in older community-dwelling adults](https://pubmed.ncbi.nlm.nih.gov/21474560/) | *The Journals of Gerontology* (R Semba et al 2011) | [1:48:30]

§

## People Mentioned

- [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) (Emeritus Professor of Biochemistry and Biophysics at UCSF, expert in longevity in *C. elegans*) [7:30]
- [Makoto Kuro-o](https://research.com/u/makoto-kuro-o) (Japanese scientist who discovered klotho) [9:00]
- [Fabrizio Ambrosio](https://connects.catalyst.harvard.edu/Profiles/display/Person/209504) (Associate Professor of Physical Medicine and Rehabilitation at Harvard Medical School) [17:00]
- [Elissa Epel](https://profiles.ucsf.edu/elissa.epel) (Professor and Vice Chair in the Department of Psychiatry at UCSF and Director of the Aging, Metabolism, and Emotions Center) [18:30]
- [Aric Prather](https://profiles.ucsf.edu/aric.prather) (Professor of Psychiatry at UCSF Weill Institute for Neurosciences) [18:30]
- [Ryan Brown](https://profiles.ucsf.edu/ryan.brown) (Postdoctoral scholar of psychology at UCSF) [19:30]
- [Cana Park](https://www.linkedin.com/in/cana-park/) (Postdoctoral scholar at UCSF) [40:45]
- [Tara Walker](https://qbi.uq.edu.au/dr-tara-walker) (Research fellow at the Queensland Brain Institute, The University of Queensland, Australia) [43:00]
- [Saul Villeda](https://profiles.ucsf.edu/saul.villeda) (Associate Professor of Anatomy at UCSF, expert in use of young blood in old animals) [44:00]
- [Lennart Mucke](https://profiles.ucsf.edu/lennart.mucke) (Professor of Neurology at UCSF and expert in neurodegenerative disease) [1:06:30]
- [Eliezer Masliah](https://www.nia.nih.gov/about/staff/masliah-eliezer) (Director of Neuroscience at the National Institute on Aging and expert in neurodegenerative disorders) [1:06:30]
- [Nathaniel (Ned) David](https://unitybiotechnology.com/team/nathaniel-david-2/) (Co-founder of UNITY Biotechnology, expert in diseases of aging) [1:10:00]
- [Graham Williams](https://www.linkedin.com/in/graham-williams-b5b71851/) (Principal Scientist at SimCogNova former research scientist at Yale) [1:17:00]
- [Jennifer Yokoyama](https://profiles.ucsf.edu/jennifer.yokoyama) (Associate Professor of Neurology at UCSF, expert in neurogenetics of aging) [1:29:45, 1:33:00]
- [Joel Kramer](https://profiles.ucsf.edu/joel.kramer) (Professor of Neurology at UCSF, expert in neurodegenerative disease) [1:30:00]
- [Bruce Miller](https://profiles.ucsf.edu/bruce.miller) (Professor of Neurology at UCSF, expert in neurocognitive disorders) [1:30:00]
- [Ozioma Okonkwo](https://www.medicine.wisc.edu/directory/okonkwo_ozioma) (Professor of Geriatrics and Gerontology at The University of Wisconsin School of Medicine and Public Health, Alzheimer’s expert) [1:37:15]
- [Michael Belloy](https://profiles.wustl.edu/en/persons/michael-belloy-2) (Assistant Professor of Neurology, Division of Aging & Dementia at Washington University School of Medicine in St. Louis, expert in Alzheimer’s genetics) [1:37:45]
- [Michael Greicius](https://profiles.stanford.edu/michael-greicius) (Professor of Neurology and Neurological Sciences at Stanford, expert in neurodegenerative diseases) [1:38:00]
- [Dan Arking](https://www.arkinglab.org/people/) (Professor of Medicine at Johns Hopkins, expert in genome-wide association studies) [1:44:00]

§

![](https://peterattiamd.com/wp-content/uploads/2024/05/bio-denadubal.jpeg)

##### Dena B. Dubal M.D., Ph.D.

Dena B. Dubal MD, PhD is a physician-scientist and [Professor in the Dept of Neurology](https://neurograd.ucsf.edu/people/dena-dubal-md-phd) and Weill Institute of Neurosciences at the University of California, San Francisco (UCSF). She holds the David A. Coulter Endowed Chair in Aging and Neurodegenerative Disease and is an Investigator with the Simons Foundation and Bakar Aging Research Institute. Dr. Dubal received her MD and PhD degrees from the University of Kentucky College of Medicine. She completed a medical internship and neurology specialty training at UCSF, where she served as chief resident.

Dr. Dubal trained at UCSF for a Behavioral Neurology Fellowship at the Memory and Aging Center. She now directs a laboratory focused on mechanisms of longevity and brain resilience that integrates genetic and molecular approaches to investigate aging, Alzheimer’s and Parkinson’s disease – in animal models and human populations at UCSF.

Her discoveries have been profiled in high-impact media such as [*The New York Times*](https://www.nytimes.com/2019/04/02/health/klotho-brain-enhancement-dementia-alzheimers.html) and [*The Economist*](https://www.economist.com/science-and-technology/2014/05/08/the-3-solution). Her work is recognized for its potential toward therapies to live longer and better. Among her honors, Dr. Dubal received the NIA/AFAR Paul Beeson Award for Aging Research, Glenn Award in Biologic Mechanisms of Aging, Grass Award in Neuroscience, and the Neuroendocrine Research Award from the American Academy of Neurology. She served on the Board of the American Neurological Association and currently serves in the leadership of JAMA Neurology, the Weill Institute Neurohub, and the Glenn Foundation for Medical Research.

**Conflict of Interest Disclosures:** Dr. Dubal has consulted for Unity Biotechnology and S.V. Health and reports funding for her research from the National Institutes of Health, the Simons Foundation, the American Federation for Aging Research, the Glenn Medical Foundation, Unity Biotechnology, and philanthropy; in addition, Dr. Dubal holds a patent for Methods for Improving Cognition, focused on klotho, filed by the Regents of the University of California and issued.

Lab website: [Dubal Lab](http://www.duballab.org/wp/)

X: [@DenaDubal](https://twitter.com/DenaDubal?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)