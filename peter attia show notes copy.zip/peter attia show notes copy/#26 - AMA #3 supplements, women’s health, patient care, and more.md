# #26 – AMA #3: supplements, women’s health, patient care, and more

**Source:** [https://peterattiamd.com/ama03/](https://peterattiamd.com/ama03/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a wide range of questions from readers and podcast listeners. Bob Kaplan, Peter’s head analyst, asks the questions.

This also marks the first video release of the podcast.

If you have any questions for the next AMA, please submit them to the AMA section on the website (peterattiamd.com).

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ama03/the_Drive_public.png)

Play

#26 - AMA #3: supplements, women's health, patient care, and more

#26 - AMA #3: supplements, women's health, patient care, and more

1x15s30s

0:002:08:48

## We discuss:

- What references ranges does Peter consider too broad on lab tests? [5:30];
- What aspect of women’s health is the least studied/understood? [21:15];
- What are your thoughts on fasting and ketosis for females? [31:30];
- Advice for medical students and residents, how to get through it, and optimize their time while in med school [38:00];
- What is Peter’s opinion on the best way to monetize a podcast to make it sustainable? [47:45];
- What are you looking to achieve and monitor with your blood glucose monitor? [57:15];
- Thoughts on lithium supplementation? [1:08:15];
- Insights about berberine? [1:16:00];
- Why does Peter take a baby aspirin? What does the science say? [1:19:20];
- How do you use HR variability as a metric in your practice and/or in your own personal use? Sleep, pre/post exercise, pre/post eating, every morning readiness? [1:23:25];
- With the emergence of “the coconut oil is pure poison” article, can you shed some light on saturated fat in the literature and the types of studies done specifically on coconut oil? [1:38:45];
- Would you discuss the recent meta studies that claim that moderate carbohydrate intake may be best for health? [1:40:45];
- What is the number one recommendation/habit you would suggest every person add to their daily regimen (besides physical activity) for wholesome health? [1:42:45];
- What does it mean if your body has a harder time getting into ketosis via fasting than it used to (testing using a Precision Xtra)? [1:44:15];
- Why are you taking Zetia and Lipitor? Are you mitigating risk based on your APOE4? Or is there something else going on? [1:46:10];
- What will your book be about and what is the expected release date? [1:47:45];
- What are your thoughts on nicotinamide riboside supplementation for longevity? [1:49:30];
- Which brand of supplements have you found to be effective? [1:54:30];
- Are you currently accepting new patients? And how do I find a ‘Peter Attia clone’ in my area? [1:56:20];
- Bob’s personal experience with Peter as a doctor [1:58:45];
- Can you tell us more about the latest and best of APOE4? [2:06:15]; and
- More.

[smart\_podcast\_player social\_twitter=”true” social\_facebook=”true” social\_gplus=”true” social\_linkedin=”true” social\_pinterest=”true” social\_email=”true” featured\_episode=”27″]

§

## Show Notes

## What references ranges does Peter consider too broad on lab tests? [5:30]

**Lipids**

- Triglycerides (TGs): reference is < 150 mg/dL (< 1.7 mmol/L)
  - Peter wants this < 100 mg/dL (< 1.13 mmol/L)
  - More stringent, but something Peter likes to see: TG < HDL-C (when measured in mg/dL)
- LDL-P: < 1,000 nmol/L (~ 20th percentile)
- Small LDL-P: < 500 nmol/L (~ 25th percentile)

Why so low? The reason is heart disease and atherosclerotic disease are the most ubiquitous causes of death, so why would you want to be average?

For more on lipids, LDL-P, and LDL-C, listen to the podcasts with Ron Krauss, Dave Feldman, and Tom Dayspring:

- [Ron Krauss, M.D.: a deep dive into heart disease (EP.03)](https://peterattiamd.com/ronkrauss/)
- [Dave Feldman: stress testing the lipid energy model (EP.19)](https://peterattiamd.com/davefeldman/)
- [Tom Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology (EP.20)](https://peterattiamd.com/tomdayspring1/)
- [Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation (EP.21)](https://peterattiamd.com/tomdayspring2/)
- [Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins (EP.22)](https://peterattiamd.com/tomdayspring3/)
- [Tom Dayspring, M.D., FACP, FNLA – Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain (EP.23)](https://peterattiamd.com/tomdayspring4/)
- [Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more (EP.24)](https://peterattiamd.com/tomdayspring5/)

**Inflammation and oxidation markers**: high sensitivity c-reactive protein (hsCRP) and oxidized LDL (oxLDL)

- hsCRP: < 1 mg/L (labs say below 2)
- oxLDL: < 40 U/L (labs say < 60 U/L)

**Metabolic**

- Uric acid: < 5.0 mg/dL (labs say < 6-7 because they are optimizing for not getting gout)

**Liver function tests**: alanine aminotransferase (ALT) and aspartate aminotransferase (AST)

- ALT: < 20 U/L and (reference upper limit: 42-44) and AST 40 but Peter wants patients below 20
- AST: < 20 U/L (reference upper limit: 40)

**OGTT (oral glucose tolerance test)**

- Fasting glucose < 90 mg/dL
- Fasting insulin < 6 (uIU/mL)
  - 1-hour glucose: < 130\*
  - 1-hour insulin: < 30\*
    - 2-hour glucose: < 100
    - 2-hour insulin: < 20

\* For a woman who is smaller, or less muscular, he will tolerate slightly higher levels

**Hormones**

Thyroid — TSH [thryoid stimulating hormone], free T3 [triiodothyronine] (fT3), reverse T3 (rT3), T4 [thyroxine] — these need to be taken in context

- If one or more of those are out of whack, how do you even begin to make the diagnosis of hypothyroid, for example?
- TSH is really only telling you about what the pituitary gland is seeing as far as the T4 to T3 conversion (which is telling you about the deiodinase in the brain that’s making that distinction)
- fT3 is telling you how much peripheral T4 is converting to T3
- rT3 is telling you how much peripheral T4 is converting to rT3, which opposes T3
- Each of those have a completely different cause, but a whiteboard is in order to explain this (will likely a video at some point for people interested)

Sex hormones:

- DHEA (dehydroepiandrosterone)
- FSH (follicle stimulating hormone)
- LH (luteinizing hormone)
- DHT (dihydrotestosterone)
- Progesterone
- SHBG (sex hormone binding globulin)
- Estrogen (estrone [E1], estradiol [E2], estriol [E3])

This is also very complex (another whiteboard/video discussion at a later time)

About nine things we measure

**Omega-3s**: EPA (eicosapentaenoic acid) & DHA (docosahexaenoic acid)

- Also very complex
- Likes to see EPA/DHA index above 8.5
- Used to think 8.0, but sometimes OK with up to 10-12, if no side effects (e.g., nosebleeds)
- More complicated, for some patients you want to see DHA higher than the EPA
- What you’re optimizing for: neurodegenerative (DHA) or atherosclerosis (EPA is more important)
- Also matters: your sources of these things (e.g., supplements, food)

**Cholesterol synthesis and absorption biomarkers**

- Desmosterol (synthesis)
- Campesterol, sitosterol, cholestanol (absorption)

Peter likes to use these markers to assess therapeutic options, and he’s concerned about oversuppression of cholesterol synthesis at the individual level (desmosterol is a way to gauge this)

**IGF-1 (insulin-like growth factor 1)**

- Changed his mind over time
- Used to think low is best (i.e., below 50th percentile)
- It’s likely that cycling between low and high levels of IGF-1 is optimal
- Fasting can dramatically lower IGF-1

Three things that impact IGF-1 most:

1. Amino acid intake (methionine)
2. Insulin levels (largely dietary carbs)
3. Exogenous hormones (e.g., growth hormone, an analog of the human pituitary gland to make more IGF-1)

Bob says, when looking at IGF-1 as a marker, that is a snapshot, but we’re really living in a movie where it goes up and down at different periods, and that’s not captured on a single blood draw

- Bob points out in Valter Longo’s FMD studies in mice, you see shrinking of organs during FMD and low IGF-1, but then the regeneration/rejuvenation occurs upon refeeding, your IGF-1 levels are likely to come back up at this time
- If you are cycling through periods of feast and famine, and you get an annual IGF-1 blood test, you’re looking at an average, when what you may want to capture is the variability that the cycling induces — we may be looking for punctuated periods of low IGF-1, with recovery that necessitates relatively higher levels of IGF-1
- Peter says IGF is more stable, than GH (which is more dynamic), so don’t measure GH (e.g., sit in a sauna for 20 minutes, it will change your GH but not your IGF-1)

## What aspect of women’s health is the least studied/understood? [21:15]

**Most important distinction is sex hormones**

- Men have gradual decline in hormones, like a frog in hot water, doesn’t notice it as much
- Women, on the other hand, have a more stark drop off
- Women, during reproductive years, menstrual cycle experiencing profound fluctuations in hormones
- Losing estrogen, progesterone and testosterone
- Men have about 15 ng/L and women have about 1 ng/L, however, testosterone is still the dominant hormone in women
- In menopause all the hormones kind of stop suddenly
- Peter’s pet peeve is doctors that disregard perimenopausal and postmenopausal symptoms in women, “Without having ever read a single study or limits in the methodologies of the Women’s Health Initiative but still come to the conclusion that women should never take hormones and just deal with it”

**There’s something about multiple pregnancies and the HPA axis in women**

- Having two kids, he doesn’t see it
- But having 3-4 kids, unlikely that her thyroid will bounce back to normal
- Energy levels are super low and can’t get it back
- They have normal TSH typically, but peripherally metabolism of T4 is very altered
- You can make interventions which will help immediately feel a lot better, yet they in many cases will just fall through the cracks… due to just a failure to appreciate these subtle differences between men and women

Bob mentions a [Freakonomics podcast episode](https://freakonomics.com/podcast/bad-medicine-part-2-drug-trials-and-tribulations/), there was the thalidomide issue, where women were taking the drug while pregnant (for morning sickness), and led to a lot of fetal deaths and birth defects, and led to fewer studies of women

- Because of the effects on young women and on the fetus, it suggested that women shouldn’t be included in clinical trials because of the potential adverse events to the fetus
- After this period, women were studied far less than men, they were [excluded from early clinical trials](https://www.fda.gov/ScienceResearch/SpecialTopics/WomensHealthResearch/ucm472932.htm) for new drugs

**Another difference: women get less cardiovascular disease**

- Peter says is you normalize for all common factors such as LDL-P, apoB, blood pressure, etc., all things equal, they indeed get less cardiovascular disease
- You would have to look at iron levels
- In men, the more metabolically deranged, the better they do with therapeutic phlebotomy, but the less deranged they are, the less they are affected by giving blood, and therefore reducing the oxidative stress of iron
- It might be the case that women may have less iron than a man due to the menstrual cycle and this hypothesis is something Peter would be interested to know more about

**Women get more Alzheimer’s disease**

- 2 out of 3 cases of Alzheimer’s are women but the reason for this needs to be studied more
- Peter says some people try to say it’s because women live longer, but doesn’t think the increase in longevity accounts for the number of women compared to men getting AD

**Women get less cancer in the US**

**Women live longer than men**

## What are your thoughts on fasting and ketosis for females? [31:30]

Women need to be thoughtful about a couple things:

- Fertility issues, or trying to get pregnant, can’t make a compelling case that a woman should be in nutritional ketosis
- David Mangelsdorf looked at differences in male and female brain in the presence of changing FGF21 levels
- Long story short, “In a calorie restricted state, when ketones are elevated, it suppresses FSH and LH in women but not in men”
- Super interesting because profound evolutionary “in a period of famine, you would want women to stop reproducing, you would want to shut off FSH and LH, you would want men to have no impairment on their T level” because they’re trying to get food
- It’s certainly possible to get pregnant in ketosis but the question is how are you optimizing?
- The other part of this is should women who are pregnant be in ketosis?
- Clearly evolved to be able to handle this, however, is it optimal?
- As a general rule, not convinced it’s the best strategy: far better strategy is don’t eat junk food, less sugar, etc.

## Advice for medical students and residents, how to get through it, and optimize their time while in med school [38:00]

Most key advice: Don’t study pre-med in college

- All that stuff is like JV version of med school, and you’ll get the full version in med school
- Pick a major that you freaking love because the last thing you want to do is study a major with the sole purpose of passing the MCAT

Once you’re in med school

- Be prepared to be super unhappy during some days
- Peter, for example, hated to memorize things but realized you just can’t get through it on first principles and he finally accepted that you had to get a base knowledge
- Peter was once given some very wise advice: Anytime you find yourself in a situation that you think sucks, go find someone who would give *anything* to be in your situation and help them out

Maintain a balance

- It is important to get out of those books for a while and do something pleasant
- Probably better off only studying 85 hours instead of 100, for instance, and use those other 15 hours to enjoy life for a minute

Finally, don’t lose sight of *why* you’re doing it

- Interact with as many patients you can because it’ll help you realize you have this bizarre privilege of hearing about people’s issues
- So as a med student, if you aren’t awe inspired by interactions with patients you might want to consider a change in profession because you’ll be beaten down by the rest of it

## What is Peter’s opinion on the best way to monetize a podcast to make it sustainable? [47:45]

- First, Peter has really enjoyed this podcast process more than he thought
- Initially felt like “I have to” do this
- Now thinks he “gets to” do this
- However, it’s not cheap, costs roughly $2,500 per podcast not including Peter’s time
- Need to figure out how to pay for this because 1) not cool to flush $120,000 yearly and 2) Peter wants to be able to do so stuff if podcast can not only pay for itself but also to fund some of the research so that would be a great
- Just hired a 6th researcher, wants to hire as many as possible
- Clinical practice subsidizing the cost of the research team, all under Attia Medical
- Would like to figure out a way for the podcast to 1) cover the cost of research, and 2) wishful that it will also generate a pool of capital to invest in types of research he wants to see at universities

So, what are the options for monetizing a podcast?

Sell ads: doesn’t want to sell ads

Listener-Support Model

- Sam Harris does this and has been helping Peter think through a listener-support model, Sam explains his rationale for this on his podcast
- Rhonda Patrick is also listener support model but different than Sam’s

Subscription/Member-only network, Netflix model, so you pay to have access to the network

- Monetization of the podcast will likely be one of these two rather than running ads
- Bob: “I have nothing to add”
- [At Berkshire Hathaway’s annual shareholder’s meetings](https://www.forbes.com/sites/michaelsimmons/2015/03/23/how-one-life-hack-from-a-self-made-billionaire-leads-to-exceptional-success/#50c7dd3f543d), Munger lets Buffett answer the questions, often times commenting, “I have nothing to add.”

## What are you looking to achieve and monitor with your blood glucose monitor? [57:15]

- CGM, [the G6](https://www.dexcom.com/g6-cgm-system)
- Also loves the [Oura Ring](https://ouraring.com/)
- Only two products he cannot stop wearing

Regarding hemoglobin A1c (HbA1c):

- “Directionally tolerable but mostly shit”
- He knows bc he’s used CGM in so many patients and compared reports to A1c and you realize that A1c is at the mercy of the fact that a red blood cell lives for 90-120 days

## Thoughts on lithium supplementation? [1:08:15]

- Peter says that the evidence that groundwater containing higher levels of lithium is contributing to better mental health is as good as any such data can be which is to say “not great” (Tier 2 epidemiology)
- Peter calls it “Tier 2 epidemiology”, which is a step up from the absolute worst epidemiology, which is when you are trying to assess inputs and outputs such as “people who exercise *this way* tend to live *this long*” or . . . “people who eat *this way* have *this much* disease”
- Lithium observations are tier 2 epidemiology because one of the variables is *fixed*, and there’s no healthy user bias, you’re just measuring the mental health
- When you overlay the groundwater map with mental health there’s actually a nice association
- No doubt you could think of other explanations (could be a proxy for something else) but all that said, at the first order, there is no *obvious* proxy

Peter experimented on himself to see if taking lithium would stabilize his mood

- Note: Don’t EVER do this outside of the care of a “super dialed in physician”
- First consulted with Paul Conti, a psychiatrist who uses lithium in monotherapy for high-risk bipolar patients who don’t respond well (or at all) to the common bipolar drugs
- Peter was taking 600 mg/day (about half what a bipolar patient would take)
- Did this for about a year, didn’t tell anyone, because he figured that if there truly were noticeable differences and wanted to see if others noticed on their own
- The first person to notice was Peter’s wife, she noticed after 4 months
- When Peter asked how she knew, her response was, “You’re less of an asshole”
- Peter decided not to continue to take a mega dose of lithium (he did notice some side effects such as nausea)
- Peter now takes low dose 10-20 mg lithium
- He categorizes this as “probably not harmful, [but] not sure how much value I’m getting out of it”

## Insights about berberine? [1:16:00]

[Berberine](https://en.wikipedia.org/wiki/Berberine), a plant-derived extract with 2 properties

First, it is a weak activator of [AMP kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase) (the “secret sauce” of [Metformin](https://en.wikipedia.org/wiki/Metformin) is that it activates AMP kinase)

- OTC dose is generally 500-1000 2x per day (similar to Metformin)
- The net effect is decreasing hepatic glucose output, “poor man’s version of Metformin”
- Not that exciting for Peter, just use metformin

Secondly, the more exciting piece is that it is a weak inhibitor of the enzyme, [PCSK9](https://en.wikipedia.org/wiki/PCSK9)

- Word on the street, it probably only works in a subset of people who overexpress PCSK9 (an enzyme [technically a proprotein convertase: it acts more like a chaperone than a catalytic enzyme] that degrades LDL receptors) which ends up in higher LDL-P (only about 5% of the time will this be the reason someone isn’t clearing LDL particles, there are literally thousands of possible reasons)
- These patients respond well to berberine

For more on PCSK9, see the following episodes of The Drive: [Ron Krauss](https://peterattiamd.com/ronkrauss/), [Dave Feldman](https://peterattiamd.com/davefeldman/), and [Tom Dayspring (Part IV)](https://peterattiamd.com/tomdayspring4/)

## Why does Peter take a baby aspirin? What does the science say? [1:19:20]

Peter has recently changed his thinking on this topic (more below)

- But the reason he *was* doing so is that heart disease is rampant in Peter’s family so he is simply trying to mitigate risk
- Quote from Charlie Munger, “All I want to know is where I’m going to die so I never go there”
- Baby aspirin has some effect on inflammation, but the majority of the benefit is on platelets, therefore reducing thrombotic events (blood clot), which can be the final moment where you have an MI

*What has changed about Peter’s view recently?*

- A month ago, his view was . . . if your “Aspirin Works Test” is positive (test in urine that measures metabolites of platelets to predict which patients will respond to baby Aspirin) *combined* with at least one other factor that indicates possible heart disease, he would recommend taking it
- There are side effects to be considered, easier bruising, bleeding, a small risk of ulcer, etc.
- [Study that came out recently](https://www.thelancet.com/article/S0140-6736(18)31924-X/fulltext) that looked at relatively low-risk populations, found that the risk of taking baby aspirin was small, but so was the benefit, making it a “wash” in Peter’s mind
- Now he’s just a little less likely to suggest (this especially to low risk patients)

*Will Peter stop taking it?* Perhaps, even though it makes sense intuitively, the data simply don’t support it

## How do you use HR variability as a metric in your practice and/or in your own personal use? Sleep, pre/post exercise, pre/post eating, every morning readiness? [1:23:25]

**HRV**

HRV measures the specific changes in time (i.e., variability) between successive heartbeats.

The raw measurement is the [interbeat interval](https://en.wikipedia.org/wiki/Interbeat_interval) (IBI): IBI is used in reference to the time interval between individual beats of the heart.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-177.png)

**Figure 1. Schematic representation of normal ECG.**

From there, HRV can be expressed in 2 domains: time or frequency. The Oura ring shows time domain, which is expressed in raw RMSSD (Root Mean Square of Successive RR Differences).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-178.png)

**Figure 2. RR interval.** The RMSSD looks at the successive RR differences.

Frequency-domain methods: frequency domain methods assign bands of frequency and then count the number of RR intervals that match each band.

- The bands are typically high frequency (HF) from 0.15 to 0.4 Hz,
- low frequency (LF) from 0.04 to 0.15 Hz,
- and the very low frequency (VLF) from 0.0033 to 0.04 Hz ([Wikipedia](https://en.wikipedia.org/wiki/Heart_rate_variability#Frequency-domain_methods), accessed 9/8/18)

Oura doesn’t show frequency domains because they claim that the low-frequency to high-frequency (LF/HF) ratio often does not accurately measure cardiac sympathovagal balance (personal communication; [Billman, 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3576706/)). Also, different programs may use different scales to define LF vs HF, which may also skew the results. Oura does claim that it could provide an accurate measure of sympathovagal balance because of the high precision of the IBI measurement from the ring (personal communication).

- Will Eden, works for Peter Thiel, got Peter into HR variability long before all these wearables came out tracking it
- Six years ago, spent a day at Peter Thiel’s office and was showed data from HeartMath, algorithm on chest straps

For more on high frequency vs. low frequency HR variability, see the episode of [The Drive with Robert Lustig](https://peterattiamd.com/roblustig/)

- With Oura ring, recovery index, looking at HRV
- Peter says, alcohol and shitty food close to bedtime will drive HR way up, and HRV way down, which diminishes your recovery and sleep quality
- HRV with temperature and movement feeds an algorithm in Oura that predicts sleep quality

Is it actionable? What is valuable about knowing HRV?

Need to know two things:

1. Real-time feedback

- Hard to do anything without it
- If your HRV is off in the morning when you wake up you can immediately ask what did I do differently?
- Peter knows he can only have one drink
- Meal timing, room temperature are factors
- Can tinker with stuff to try to improve sleep quality

2. “Readiness” score

- Not as sensitive to lifting workouts
- A couple of teams in the Tour de France wore Oura and Peter would love to see the data because their “recovery scores must’ve been the lowest numbers imaginable”

![](https://peterattiamd.com/wp-content/uploads/2018/10/IMG_5142-169x300.png)

**Figure 3. Readiness score example.** Screenshot of the Oura app.

![](https://peterattiamd.com/wp-content/uploads/2018/10/IMG_5143.png)

**Figure 4. Readiness score contributors example.** Screenshot of the Oura app.

![](https://peterattiamd.com/wp-content/uploads/2018/10/IMG_5144.png)

**Figure 5. Readiness score contributors.** Screenshot of the Oura app.

![](https://peterattiamd.com/wp-content/uploads/2018/10/IMG_5145.png)

**Figure 6. Night time HRV contributing to readiness score example**. Screenshot of the Oura app.

![](https://peterattiamd.com/wp-content/uploads/2018/10/IMG_5147.png)

**Figure 7. Readiness score description.** Screenshot of the Oura app.

Fasting and sleep

- Bob asks how fasting affects PA’s sleep and what the Oura ring told him
- The biggest thing was deep sleep (stage 3 and 4) went up the most
- Light slight (stage 1 and 2) went down the most
- REM was unchanged
- HRV was higher
- Resting HR was on par with what it is if you’re not eating and drinking before bed
- Respiratory Rate went down

**\*\* Speed round begins, Peter has 90 seconds to answer each question [1:38:15] \*\***

## With the emergence of “the coconut oil is pure poison” article, can you shed some light on saturated fat in the literature and the types of studies done specifically on coconut oil? [1:38:45]

[Coconut oil is pure poison](https://www.usatoday.com/story/news/nation-now/2018/08/22/harvard-professor-coconut-oil-pure-poison/1060269002/)?

- The literature is ridiculous
- Nutritional epidemiology is the lowest form of human inference
- That said, the case for saturated fat may be overstated, the view that it is never harmful and eating 90% of saturated fat can’t be healthy for everyone
- Rather than rely on some “knucklehead” study, Peter suggests that we “learn to understand what the biomarkers are that changes as a result of [consuming saturated fat],” meaning inflammation, lipoproteins, and lipids

## Would you discuss the recent meta studies that claim that moderate carbohydrate intake may be best for health? [1:40:45]

The meta study: [Dietary carbohydrate intake and mortality: a prospective cohort study and meta-analysis](https://www.thelancet.com/journals/lanpub/article/PIIS2468-2667(18)30135-X/fulltext)

Peter says that the paper suffers from all the problems of nutritional epidemiology, a horrible brand of science

[Zoe Harcombe](https://twitter.com/zoeharcombe?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) wrote a [great article](https://www.zoeharcombe.com/2018/08/low-moderate-or-high-carbohydrate/) on this which points out that the paper:

- Didn’t correct for alcohol consumption
- Has a number of odd confounders
- Hazard ratios are quite low
- Risks are discussed in relative terms instead of absolute terms

“You have to know relative risk, you have to know absolute risk, **and you have to know the period over time under which the condition was studied relative to the natural course of the illness”**

“It’s that third part that doesn’t get enough attention”

## What is the number one recommendation/habit you would suggest every person add to their daily regimen (besides physical activity) for wholesome health? [1:42:45]

Peter not a huge fan of this type of question

The “glib” answer is to:

- Sleep well
- Do something physical
- Don’t eat for a long period
- When you do eat, don’t eat crap
- Meditate

With that said, “sleep is the one we are going to be most sensitive to”

Lack of good sleep is the one you will “suffer from the quickest”

## What does it mean if your body has a harder time getting into ketosis via fasting than it used to (testing using a Precision Xtra)? [1:44:15]

If the concern is that the person does not get to the same levels of BHB (beta-hydroxybutyrate), the first two things Peter would consider are the following:

1. Perhaps they are more efficiently utilizing the ketones (hard to demonstrate outside of a laboratory)
2. Just producing less of them due to something different they are doing than what they were doing in the past (changed fatty acid consumption, eating more protein, more carbs)

Note: If testing ketones by way of urine strips, it’s possible that the more fat-adapted a person becomes, the less acetoacetate that will show up in their urine because they are utilizing more of the ketones as a substrate

## Why are you taking Zetia and Lipitor? Are you mitigating risk based on your APOE4? Or is there something else going on? [1:46:10]

- Actually not taking it anymore
- Simply stated, he *was* taking it in the past because he’s trying to live as long as he can, which means delaying the onset of atherosclerotic disease as much as possible
- Peter has an all-hands-on-deck approach defined as:
  - Reducing the burden of lipoproteins
  - Reducing inflammation
  - Improving endothelial health
  - Increasing insulin sensitivity
- As for choosing Zetia (ezetimibe) and Lipitor (atorvastatin) specifically: Lipitor, empirically derived, trial and error, found that taking 10 mg 3x per week when coupled with the Zetia, minimum effective dose got Peter to below the 20th percentile

## What will your book be about and what is the expected release date? [1:47:45]

- Plot: Peter’s little known alternate life as a shepherd (wink wink)
- Release date: Early 2020

## What are your thoughts on nicotinamide riboside supplementation for longevity? [1:49:30]

- Cells need NAD, so you could argue having more NAD in a cell is a better thing (second order question)
- But cells cannot take up NAD, a cell has to be able to make its own
- With that said, giving *precursors* is an interesting idea

Referencing the [paper in Cell Metabolism by Josh Rabinowitz](https://www.sciencedirect.com/science/article/pii/S1550413118301967?via%3Dihub=)

- They developed a tracer to track all the intermediaries of NAD and all the precursors
- When given oral precursors (NR or [NMN](/does-nmn-improve-metabolic-health-in-humans/)), only the liver could take them up and make NAD using tryptophan, no other cell could take it up
- So if you’re taking oral NR or NMN, you are pretty much just giving it to your liver, not the place you want it to be (not changed by using pterostilbene)
- Based on data, only way to increase cellular NAD would be *intravenous* doses of NR or NMN
- Taking it orally is probably not harmful, but probably waste of money

For more on NAD, see [episode of The Drive with David Sinclair](https://peterattiamd.com/davidsinclair/) as well as Dave Asprey’s [podcast episode](https://blog.bulletproof.com/charles-brenner/) with Charles Brenner

**Note: Bob misspoke about Dave Asprey taking intravenous NR.** Dave mentioned in his podcast with Charles Brenner that he took NAD (not NR) intravenously. Here is the exchange, courtesy of [Dave Asprey’s blog](https://blog.bulletproof.com/charles-brenner/) (and [transcript](https://44uc8dkwa8q3f5b66w13vilg-wpengine.netdna-ssl.com/wp-content/uploads/2018/05/CharlesBrenner-491.pdf)):

Dave Asprey: I’ve got to ask what about just straight out injecting NAD because I’ve had about 15 grams of NAD intravenously. We’re doing it at Bulletproof Labs on occasion. It’s been pretty profound, but I’m taking a gram of NAD in my bloodstream. What’s the difference between nicotinamide riboside and just straight-up doing NAD?

Charles Brenner: Injecting NAD doesn’t make any sense to me because NAD doesn’t go into cells as NAD.

## Which brand of supplements have you found to be effective? [1:54:30]

“Well, the problem is that the whole supplement world is kind of a shit show”

Companies Peter relies on for a variety of supplements

- [Jarrow](https://jarrow.com/)
- [Pure Encapsulations](https://www.pureencapsulations.com/)

For DHA/EPA

- [Nordic Naturals](https://www.nordicnaturals.com/consumers/)
- [Carlson Labs](https://www.carlsonlabs.com/)

For Berberine: [Thorne](https://www.thorne.com/products/dp/berberine-500)

## Are you currently accepting new patients? And how do I find a ‘Peter Attia clone’ in my area? [1:56:20]

No, not for the remainder of this year, Attia Medical is overbooked

How does one find a “Peter Attia clone” in their area?

- For a clone, you can maybe try Toronto attorney, Paul Attia
- You’re also welcome to seek medical advice from [Tom Morello](https://twitter.com/tmorello?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) at your own risk

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-179.png)

**Figure 8. Tom or Peter?** Image credit: [Rolling Stone](https://www.rollingstone.com/music/music-news/watch-injured-tom-morello-recruit-fan-for-rage-against-the-machine-song-666846/)

Matching doctors and patients

- Peter and Bob have aspirations of creating an online forum that can act as a matchmaking service between doctors and patients where Attia Medical can become sort of a clearinghouse that allows for patients to submit questions (to be upvoted/downvoted) and give doctors an opportunity to answer the questions and provide info as to how patients can reach them
- Peter is unsure what it is about him that people want to find in a doctor in their local community
- Bob believes people want a doctor like Peter who is comprehensive, deliberate, and thoughtful, and who has a similar objective, strategy, and tactics approach

## Bob’s personal experience with Peter as a doctor [1:58:45]

- Bob’s dad was in the medical ICU (MICU) for 30 days at Massachusetts General Hospital (MGH)
- For the first few days, he was considered to be in the worst shape in the MICU (that has about 20 beds)
- [According to the subhed on their website](https://www.massgeneral.org/pulmonary/services/treatmentprograms.aspx?id=1688), the MGH MICU, “Cares for patients with a wide variety of serious medical illnesses from sepsis to pneumonia, acute respiratory distress syndrome to multiple organ failure”
- Bob’s dad had all four — sepsis, pneumonia, ARDS, and multiple organ failure — simultaneously
- Bob would talk to the nurses, interns, residents, attendings, and fellows, update friends and family ([here’s one from day 2-3 in the ICU](https://www.dropbox.com/s/qmsoj7mq1j6jecr/170218AMDadMGH.pdf?dl=0)), and do a systems review with Peter
- The depth and level of obsession that’s required in an ICU, and the collective knowledge and sharing ideas, the intervention and feedback loops, Bob saw parallels with how Peter thinks and operates, and how the team works with patients under his care

## Can you tell us more about the latest and best of *APOE4*? [2:06:15]

- For the latest on ApoE, check out a [previous episode of The Drive](https://peterattiamd.com/richardisaacson/) with [Richard Isaacson](https://weillcornell.org/risaacson), a neurologist at Cornell who runs the largest [Alzheimer’s Prevention Clinic](https://neurology.weill.cornell.edu/clinical-services/alzheimers-disease-memory-disorders-program/alzheimers-prevention-clinic) in the world
- The [APOE4.info](https://www.apoe4.info/) site and forum is also a great resource for APOE4

§

§

## Selected Links / Related Material

**Previous AMA episode where Peter discussed his blood values before, during, and after fasting**: [AMA #2: the Nothingburger — results from Peter’s week-long fast between two weeks of nutritional ketosis — and answering questions on all things fasting (EP.11)](https://peterattiamd.com/ama02/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [5:30]

**The Drive episode with Dave Feldman**: [Dave Feldman: stress testing the lipid energy model (EP.19)](https://peterattiamd.com/davefeldman/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [7:00]

**The Drive episodes with Tom Dayspring**: [7:00]

- **Part 1**: [Tom Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology (EP.20)](https://peterattiamd.com/tomdayspring1/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/))
- **Part 2**: [Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation (EP.21)](https://peterattiamd.com/tomdayspring2/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/))
- **Part 3**:[Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins (EP.22)](https://peterattiamd.com/tomdayspring3/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/))
- **Part 4**: [Tom Dayspring, M.D., FACP, FNLA – Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain (EP.23)](https://peterattiamd.com/tomdayspring4/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/))
- **Part 5**: [Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more (EP.24)](https://peterattiamd.com/tomdayspring5/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/))

**Longo’s FMD studies**: [Prolon — Science & Research](https://prolonfmd.com/science-research/) | (prolonfmd.com) [19:00]

**Freakonomics episode discussing the history of study women**: [Bad Medicine, Part 2: (Drug) Trials and Tribulations](https://freakonomics.com/podcast/bad-medicine-part-2-drug-trials-and-tribulations/) | Stephen J. Dubner ([freakonomics.com](https://freakonomics.com/)) [28:30]

**Peter and Richard Isaacson discuss the prevalence of Alzheimer’s in women (2 of 3 cases)**: [Richard Isaacson, M.D.: Alzheimer’s prevention (EP.18)](https://peterattiamd.com/richardisaacson/) | Peter Attia (peterattiamd.com) [30:50, 2:06:30]

**David Mangelsdorf, FGF21, and ketogenic diet**: [The Hormone FGF21 Stimulates Water Drinking in Response to Ketogenic Diet and Alcohol](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(18)30242-0) (Song et al., 2018) [33:00]

**Company that helped Peter’s sister after her battle with diabetes following her third pregnancy**: [Virta Health](https://www.virtahealth.com/) | ([virtahealth.com](https://www.virtahealth.com/)) [36:30]

**How to say “no” elegantly**: [How to Say “No” Gracefully and Uncommit (#328)](https://tim.blog/2018/07/19/essentialism/) | Tim Ferriss ([tim.blog](https://tim.blog/)) [46:15]

**Episode of The Drive with Robert Lustig**: [Robert Lustig, M.D., M.S.L.: fructose, processed food, NAFLD, and changing the food system (EP.14)](https://peterattiamd.com/roblustig/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [48:15, 1:28:30]

**Peter’s favorite beverage**: [Topo Chico](https://www.topochicousa.net/) | ([topochicousa.net](https://www.topochicousa.net/)) [52:00]

**Example of a “listener support model” podcast**: [Waking Up Podcast](https://samharris.org/podcast/) by Sam Harris | ([samharris.org](https://samharris.org/)) [54:00]

**Example of a “listener support model” podcast**: [FoundMyFitness](https://www.foundmyfitness.com/episodes) by Rhonda Patrick | ([foundmyfitness.com](https://www.foundmyfitness.com/)) [54:30]

**Peter’s favorite continuous blood glucose monitor**: [The G6](https://www.dexcom.com/g6-cgm-system) | (dexcom.com) [57:15]

**Favorite sleep monitor**: [Oura Ring](https://ouraring.com/?gclid=Cj0KCQjwjbveBRDVARIsAKxH7vkNvSgnI8jfhB8mQEMTr2Ddw-HskMTKnPNuaW6M-Scr9HqaHQITGzQaAndhEALw_wcB) | ([ouraring.com](https://ouraring.com/?gclid=Cj0KCQjwjbveBRDVARIsAKxH7vkNvSgnI8jfhB8mQEMTr2Ddw-HskMTKnPNuaW6M-Scr9HqaHQITGzQaAndhEALw_wcB)) [57:30]

**The Drive episode with Paul Conti, a psychiatrist**: [Paul Conti, M.D.: trauma, suicide, community, and self-compassion (EP.15)](https://peterattiamd.com/paulconti/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [1:10:30]

**Episodes of The Drive discussing PCSK9**: [1:17:30]

- [Ron Krauss, M.D.: a deep dive into heart disease (EP.03)](https://peterattiamd.com/ronkrauss/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/))
- [Dave Feldman: stress testing the lipid energy model (EP.19)](https://peterattiamd.com/davefeldman/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/))
- [Tom Dayspring, M.D., FACP, FNLA – Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain (EP.23)](https://peterattiamd.com/tomdayspring4/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/))

**Aspirin study**: [Use of aspirin to reduce risk of initial vascular events in patients at moderate risk of cardiovascular disease (ARRIVE): a randomised, double-blind, placebo-controlled trial](https://www.thelancet.com/article/S0140-6736(18)31924-X/fulltext) (Gaziano et al., 2018)[1:21:30]

**Company that analyzes data taken from heart rate monitors**: [Heart Math](https://www.heartmath.com/) | ([heartmath.com](https://www.heartmath.com/)) [1:24:00]

**Another company that analyzes data taken from heart rate monitors**: [FirstBeat: Heartbeat Analytics](https://www.firstbeat.com/en/) | ([firstbeat.com](https://www.firstbeat.com/en/)) [1:29:00]

**Devices that try to measure heart rate variability**: [1:31:30]

- [Oura Ring](https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwiBuJnCjKLeAhULvsAKHWNtAskYABAAGgJpbQ&ohost=www.google.com&cid=CAESQOD2OtWfm8l5fLWpK0_XdkvMZxvmYOQS_tZnnza-NLUOyG62tE0O3mxubUPugrgoBzpDFNuI239kZ0uwEgyjjA0&sig=AOD64_0rlPmd11135K73T2Lgw4kojmzF1w&q=&ved=2ahUKEwj20JDCjKLeAhUMpYMKHU8CCmgQ0Qx6BAgCEAI&adurl=)
- [Whoop](https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwiN1aHQjKLeAhVOnsAKHdNyC3EYABAAGgJpbQ&ohost=www.google.com&cid=CAESQOD2ml1AzjjWX14zam_uM61F-4xqKHxtdYDn9cjT4SSjX4JWUEDgC-XW_5KvPW3ubk4DPpOF615kO1PYIE6wGR0&sig=AOD64_0zoAArQUEwmAoCcKiM0IgjEUxp7Q&q=&ved=2ahUKEwjNkZrQjKLeAhUpyoMKHcMDB3wQ0Qx6BAgFEAI&adurl=)
- [Motiv](https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwjlw5jbjKLeAhXGuMAKHchtDvkYABAAGgJpbQ&ohost=www.google.com&cid=CAESQOD2dlbtK34VNhKu_Ws2Sgv8NNn_j0clwkWiSNCNgHwTD4a7IzUgdqj2q37V7XkD3ydcFyq8_GQoc4N2SA-mvok&sig=AOD64_3q-DurcGLnT09CD3jFtJInakMuFA&q=&ved=2ahUKEwiwl4_bjKLeAhXLz4MKHQJwBgoQ0Qx6BAgFEAI&adurl=)

**Wristwatches mentioned**: [1:38:15]

- [Speedmaster Professional Moon watch](https://www.omegawatches.com/en-us/watches/speedmaster/moonwatch/professional/product) ([omegawatches.com](https://www.omegawatches.com/))
- [Casio Calculator watch](https://www.amazon.com/slp/casio-calculator-watches/dtwqbqb4bvkamdd) ([amazon.com](https://www.amazon.com/))

**Coconut oil is pure poison**: [Coconut oil is ‘pure poison,’ Harvard professor says in talk on nutrition](https://www.usatoday.com/story/news/nation-now/2018/08/22/harvard-professor-coconut-oil-pure-poison/1060269002/) | Andrew May (usatoday.com) [1:38:45]

**Recent meta-studies that claim that moderate carbohydrate intake may be best for health**: [Dietary carbohydrate intake and mortality: a prospective cohort study and meta-analysis](https://www.thelancet.com/journals/lanpub/article/PIIS2468-2667(18)30135-X/fulltext) | (Seidelmann et. al, 2018) [1:40:45]

**Zoe Harcombe’s article responding to the meta-study suggesting moderate carbohydrate intake is best**: [Low, moderate or high carbohydrate?](https://www.zoeharcombe.com/2018/08/low-moderate-or-high-carbohydrate/) | Zoe Harcombe (zoeharcombe.com) [1:41:00]

**At home device that measure blood ketones**: [Precision Xtra](https://www.amazon.com/Precision-Glucose-Monitoring-Freestyle-Lancets/dp/B01N9NRDVI) | ([amazon.com](https://www.amazon.com/)) [1:44:15]

**Lipid-lowering medications Peter was/is taking at the time of the podcast**: [1:46:10]

- Zetia ([ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe))
- Lipitor ([atorvastatin](https://en.wikipedia.org/wiki/Atorvastatin))

**Paper by Joshua D. Rabinowitz on NAD**: [Quantitative Analysis of NAD Synthesis-Breakdown Fluxes](https://www.sciencedirect.com/science/article/pii/S1550413118301967?via%3Dihub=) (Liu et. al, 2018) [1:49:55]

**Peter’s trip to Easter Island which upset Josh Rabinowitz for the lack of an invite**: [My Life Extension Pilgrimage to Easter Island](https://tim.blog/2016/10/20/my-life-extension-pilgrimage-to-easter-island/) | Tim Ferriss ([tim.blog](https://tim.blog/)) [1:51:45]

**Dave Asprey podcast discussing intravenous NR with Charles Brenner**: [How To Boost NAD, The Coenzyme of Life: Charles Brenner #491](https://blog.bulletproof.com/charles-brenner/) | Dave Asprey ([bulletproof.com](https://www.bulletproof.com/)) [1:54:00]

**Brands of BCAA that Peter trusts**: [1:55:00]

- [Jarrow](https://jarrow.com/) ([jarrow.com](https://www.jarrow.com/))
- [Pure Encapsulations](https://www.pureencapsulations.com/) ([pureencapsulations.com](https://www.pureencapsulations.com/))

**Brands of DHA/EPA that Peter trusts**: [1:55:30]

- [Nordic Naturals](https://www.nordicnaturals.com/consumers/) ([nordicnaturals.com](https://www.nordicnaturals.com/consumers/))
- [Carlson Labs](https://www.carlsonlabs.com/) ([carlsonlabs.com](https://www.carlsonlabs.com/))

**Brand of berberine Peter trusts**: [Thorne](https://www.thorne.com/products/dp/berberine-500) | ([thorne.com](https://www.thorne.com/)) [1:56:00]

**Peter and Richard Isaacson discuss APOE4**: [Richard Isaacson, M.D.: Alzheimer’s prevention (EP.18)](https://peterattiamd.com/richardisaacson/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [30:50, 2:06:30]

**Richard Isaacson’s clinic**: [Alzheimer’s Prevention Clinic](https://neurology.weill.cornell.edu/clinical-services/alzheimers-disease-memory-disorders-program/alzheimers-prevention-clinic) | ([weill.cornell.edu](https://weill.cornell.edu/)) [2:06:30]

§

§

## People Mentioned

- [Bob Kaplan](https://twitter.com/bobkaplan) (head analyst, co-host of AMA #3) [3:55]
- [Dave Feldman](https://twitter.com/daveketo?lang=en) (LDL-P, previous podcast guest) [7:00]
- [Tom Dayspring](https://twitter.com/drlipid?lang=en) (LDL-P, previous podcast guest) [7:00]
- [Bill Harris](https://omegaquant.com/dr-william-s-harris/) (EPA and DHA) [14:30]
- [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo) (IGF) [19:00]
- [Roy Walford](https://en.wikipedia.org/wiki/Roy_Walford) (Valter Longo’s mentor, a pioneer in calorie restriction) [19:45]
- [Richard Isaacson](https://weillcornell.org/risaacson) (Alzheimer’s in women) [30:50, 2:06:30]
- [David Sinclair](https://twitter.com/davidasinclair?lang=en) (pregnancy and ketosis) [32:45, 1:49:45]
- [David Mangelsdorf](https://profiles.utsouthwestern.edu/profile/14570/david-mangelsdorf.html) (paper on FGF21, pregnancy, and ketosis) [33:00]
- [Tim Ferriss](https://twitter.com/timferriss?lang=en) (podcast episode about how to say no elegantly) [46:15, 48:40]
- [Robert Lustig](https://twitter.com/RobertLustigMD/status/1036038562406227968) (podcast [guest on The Drive](https://peterattiamd.com/roblustig/)) [48:15]
- Nick Stenson (Attia Medical analyst, encouraged Peter to start podcast) [48:40]
- [Kevin Rose](https://twitter.com/kevinrose) (encouraged Peter to start podcast) [48:40]
- [Jocko Willink](https://twitter.com/jockowillink) (encouraged Peter to start podcast) [48:40]
- [Anahad O’Connor](https://twitter.com/anahadoconnor) (encouraged Peter to start podcast) [48:40]
- [Patrick O’Shaughnessy](https://twitter.com/patrick_oshag) (encouraged Peter to start podcast) [48:40]
- [Travis Denson](https://twitter.com/tden185) (Attia Medical analyst, show notes contributor) [49:15]
- [Sam Harris](https://twitter.com/SamHarrisOrg?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (Listener support model for his podcast) [54:00]
- [Rhonda Patrick](https://twitter.com/foundmyfitness/status/1013860638529970176) (Listener support model for her podcast) [54:30, 1:27:00]
- [Warren Buffett](https://en.wikipedia.org/wiki/Warren_Buffett) [56:45]
- [Charlie Munger](https://en.wikipedia.org/wiki/Charlie_Munger) [56:45, 1:19:40]
- [Paul Conti](https://peterattiamd.com/paulconti/) (helped Peter with his lithium self-experiment) [1:10:30]
- [Dan Palenchar](https://www.linkedin.com/in/danielpalenchar/) (Attia Medical analyst, looked into the literature on baby aspirin) [1:22:45]
- [Will Eden](https://www.linkedin.com/in/williamaeden) (introduced Peter to HR variability) [1:23:45]
- [Peter Thiel](https://en.wikipedia.org/wiki/Peter_Thiel) (introduced Peter to HR variability) [1:23:45]
- [Zoe Harcombe](https://twitter.com/zoeharcombe?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (wrote an article discussing moderate carb study done by Harvard) [1:41:00]
- [Joshua D. Rabinowitz](https://scholar.princeton.edu/rabinowitz/bio) (wrote a paper on NAD precursor supplementation) [1:49:55]
- [Dave Asprey](https://twitter.com/daveasprey?lang=en) (podcast episode with Charles Brenner discussing intravenous NR) [1:54:00]
- [Charles Brenner](https://twitter.com/charlesmbrenner?lang=en) (on a podcast with Dave Asprey discussing NAD, and intravenous NAD) [1:54:00]
- [Mary Stephens](https://www.linkedin.com/in/mary-stephens-2a603386/) (runs practice operations for Attia Medical) [1:56:30, 2:04:00]
- [Paul Attia](https://twitter.com/papaalphablog?lang=en) (Peter’s brother) [1:56:45]
- [Borat](https://en.wikipedia.org/wiki/Borat) (Peter and Peter’s brother do a great impression of Borat) [1:57:00]
- [Tom Morello](https://twitter.com/tmorello?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (musician that looks like Peter) [1:57:15]
- [Ralph Esposito](https://twitter.com/drralphesposito?lang=en) (Attia Medical) [2:04:00]
- [Nicole (Vantress) Grant](https://www.linkedin.com/in/nicole-grant-rd-cnsc-94554b42/) (dietician at Attia Medical) [2:04:00]
- [Heather Richardson](https://www.linkedin.com/in/heather-richardson-94284928/) (Attia Medical) [2:04:00]

§