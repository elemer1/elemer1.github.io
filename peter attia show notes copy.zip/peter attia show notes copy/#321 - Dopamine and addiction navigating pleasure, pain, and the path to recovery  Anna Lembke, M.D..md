# #321 – Dopamine and addiction: navigating pleasure, pain, and the path to recovery | Anna Lembke, M.D.

**Source:** [https://peterattiamd.com/annalembke/](https://peterattiamd.com/annalembke/)

---

Anna Lembke is the Chief of the Stanford Addiction Medicine Dual Diagnosis Clinic and author of [Dopamine Nation: Finding Balance in the Age of Indulgence](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1). In this episode, Anna dives deep into the biochemistry and neurobiology of addiction, exploring the critical role of dopamine and the prefrontal cortex. She shares her framework for diagnosing and treating addiction, providing real-world examples involving alcohol, gambling, cannabis, social media, and more. Anna outlines the risk factors for addiction, including inherited and nurture-based risks, explores the rise of addictions in younger generations, and discusses effective ways to address these issues with children. Additionally, she touches on healthy coping strategies, the evolution of the “marshmallow experiment,” and provides insights into GLP-1 agonists as a possible tool for addiction treatment. Finally, she reflects on the value of 12-step programs and how she navigates the emotional challenges of her work.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/annalembke/the_Drive_public.png)

Play

#321 – Dopamine and addiction: navigating pleasure, pain, and the path to recovery | Anna Lembke, M.D.

#321 – Dopamine and addiction: navigating pleasure, pain, and the path to recovery | Anna Lembke, M.D.

1x15s30s

0:002:21:59

## We discuss:

- The role of dopamine and the prefrontal cortex in addiction [3:00];
- The clinical definition of addiction, and the behavioral criteria for diagnosing it [13:00];
- Assessing alcohol use: patterns, risks, and addiction diagnosis [17:15];
- Applying the addiction diagnosis framework using gambling as an example [21:45];
- Exploring addiction variability: how nature, nurture, and access shape individual vulnerability and drug of choice [25:15];
- How abstinence from addictive behaviors can help reset the brain’s reward system and improve mental health [41:15];
- Safely abstaining from addiction substances, drugs needing medical supervision, and other key considerations [51:30];
- Transitioning from abstinence to long-term recovery: tools and considerations [59:00];
- Exploring behavioral addictions like sex addiction, and the gender differences in addiction patterns [1:08:30];
- Factors contributing to the increasing levels of addiction across the world [1:13:45];
- How online pornography can affect young boys’ developing brains and lead to addictive behaviors, and strategies for parents to address this issue [1:23:30];
- The link between social media use and declines in mental health, potential solutions, and protective measures [1:34:45];
- How exercise affects brain chemistry, the role of dopamine and endorphins, and how exercise can become addictive [1:44:00];
- Cold-water immersion for mood regulation, and other healthy coping strategies [1:47:15];
- The “marshmallow experiment”: how broken promises affect behavior and trustworthy environments helps children develop self-control [1:54:00];
- Can GLP-1 agonists be useful in treating addiction? [1:58:30];
- The benefits of 12-step programs [2:06:00];
- Why understanding a patient’s story is essential for meaningful psychiatric care [2:11:45]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Dr. Anna Lembke is the Chief of the Stanford Addiction Medicine Dual Diagnosis Clinic, the Medical Director of Addiction Medicine, and a professor of psychiatry and behavioral sciences at the Stanford University School of Medicine
- Her clinical focus is addiction medicine
- In 2021 she published her book, [*Dopamine Nation: Finding Balance in the Age of Indulgence*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1)
- On October 1 of this year, she’s releasing *The Official Dopamine Nation Workbook: a Practical Guide*
- In this conversation, we begin by laying the foundation for understanding addiction, and understanding the biochemistry and neurobiology of dopamine
  - Explaining the various functions of the prefrontal cortex, etc.
- Anna explains the framework she uses to address patients with addiction
- We talk through some examples of addiction and how this framework would be put into practice for alcohol and gambling addictions
- We also speak about addictions to cannabis, sex, social media, and exercise
- Anna outlines the risk factors for addiction, including inherited and nurture-based risks
  - Why different individuals are more susceptible to specific and different addictions
- We then dive into the rise of addictions in the younger generation
  - In particular the addiction to pornography in young men
  - And how to have conversations with your children about these subjects
- From there, we discuss healthy coping strategies, the famous marshmallow experiment and how it has been revised
- We talk about cross-addiction
- We talk about Anna’s experience and knowledge around GLP-1 agonists, and whether or not they may be a tool for treating addictions
- Lastly, we speak about 12-step programs and Anna’s perspective on their benefits and impact
- As well how she personally copes with the intensity of her work

## The role of dopamine and the prefrontal cortex in addiction [3:00]

**Understanding some of the biochemistry and neurobiology of dopamine**

- [Dopamine](https://en.wikipedia.org/wiki/Dopamine) is a neurotransmitter, so it’s a chemical that we make in our brains
- [Neurotransmitters](https://en.wikipedia.org/wiki/Neurotransmitter) are the chemicals that allow for fine-tuned modulation of the neural circuits that make us who we are

*You might think of the brain as a collection of wires*

- Those wires are neurons
- They send electrical impulses, one to the other, but the neurons don’t actually touch end to end
- There’s a little gap between them called the [synapse](https://en.wikipedia.org/wiki/Chemical_synapse), and that gap is bridged by molecules called neurotransmitters

![](https://peterattiamd.com/wp-content/uploads/2024/10/f1-annalembke.png)

**Figure 1. Illustration of a synapse**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Chemical_synapse)

- There are many different neurotransmitters in the brain, and they have many different functions

***Dopamine has become the common currency for measuring pleasure, reward, and motivation***

- It’s not the only neurotransmitter involved in that process, but it is the final common pathway for all reinforcing substances and behaviors
  - Whether the substance is primarily modulating our serotonergic system or norepinephrine or the nicotinic system or the endogenous opioid system or the endogenous cannabinoid system, the final common pathway for all of those chemical cascades is to release dopamine in a dedicated part of the brain called the [reward circuitry](https://en.wikipedia.org/wiki/Reward_system)
- Reward circuitry consists of the [prefrontal cortex](https://en.wikipedia.org/wiki/Prefrontal_cortex) (that large gray matter area right behind our foreheads) and these deeper limbic or emotion brain structures like the [nucleus accumbens](https://en.wikipedia.org/wiki/Nucleus_accumbens) and the [ventral tegmental area](https://en.wikipedia.org/wiki/Ventral_tegmental_area)

![](https://peterattiamd.com/wp-content/uploads/2024/10/f2-annalembke-1024x552.png)

**Figure 2. Neuroanatomy of reward circuitry and dopamine release.** Image credit: [*Foundations of Neuroscience* 2021](https://openbooks.lib.msu.edu/neuroscience/chapter/motivation-and-reward/)

- We’re always releasing dopamine at a baseline tonic level
- But when we do something that’s pleasurable or reinforcing , then temporarily we will increase dopamine firing above baseline
  - Something that our brains consider salient or important for survival, in some cases it might even be an aversive stimulus
- That generally feels good to us, which is how we tell our brains, “*Oh, this is important. I should approach, explore, and consider doing this again.*”
- Broadly speaking, that’s dopamine’s function
- It’s not its only function

*Dopamine is also really important for movement*

- [Parkinson’s disease](https://en.wikipedia.org/wiki/Parkinson%27s_disease) (which is a movement disorder) is characterized by a decrease or a depletion of dopamine in a different part of the brain called the [substantia nigra](https://en.wikipedia.org/wiki/Substantia_nigra)
- One of the ways that we treat Parkinson’s is to actually give people L-DOPA, which is a dopamine precursor
  - Why do we give them L-DOPA and not dopamine?
  - Because dopamine itself actually can’t cross the blood-brain barrier
  - So we give them a precursor that crosses the blood-brain barrier and then binds to dopamine receptors in the substantial nigra allowing for more fluid movements in people with Parkinson’s
- Unfortunately, L-DOPA transformed to dopamine also binds dopamine receptors in the reward pathway, which is why about a quarter of folks with Parkinson’s who get treated with L-DOPA end up with addictive disorders that are usually reversible when you stop the L-DOPA and tend to be dose dependent
  - So the more L-DOPA, the more likely the sex addiction, shopping addiction or whatever the compulsive behavior

**Are humans more susceptible to addiction because we have a larger prefrontal cortex, or is it not as simple as the anatomic size of this part of the brain?**

- The prefrontal cortex comes up a lot when we talk about dementia and higher order cognitive function judgment centers
- It is also something that is more developed in our species than others

***The prefrontal cortex has many roles, and when we think about its role in addiction or other appetitive disorders, it actually has a stop function***

- If you analogize to a car, the prefrontal cortex acts like the brakes on the car
- It allows for delayed gratification
- This is where we have the control centers
- It allows for appreciating future consequences
- It lights up when we’re engaged in autobiographical narrative
  - And of course, narrative is part of the ways that we actually create metacognitive awareness to inform future decisions

***Having a very robust prefrontal cortex is potentially protective against addiction***

- People who have cognitive or attentional disorders, who are thought to have a **disorder of the prefrontal cortex** (for example, [attention deficit disorder](https://en.wikipedia.org/wiki/Attention_deficit_hyperactivity_disorder)) are at higher risk to develop addictive disorders

*The nucleus accumbens is the accelerator*

- The nucleus accumbens is deep in the brain, is rich in dopamine releasing neurons, and that acts like the accelerator on the car

> “*Addiction is a problem either with too little on the brakes, too much on the accelerator, or some combination thereof.*”‒ Anna Lembke

Anna explains, “*In terms of whether or not humans are more likely to get addicted than animals, I would say no*.”

**What’s remarkable about this reward circuitry is how incredibly conserved it is over millions of years of evolution and across species**

- Neuroscientists used to talk about the lizard brain or the triune brain
- They’re not typically using that phraseology so much anymore, but what they were getting at was that if you look at the [nucleus accumbens](https://en.wikipedia.org/wiki/Nucleus_accumbens), [ventral tegmental area](https://en.wikipedia.org/wiki/Ventral_tegmental_area), it’s amazingly unchanged across species over millions of years of evolution
- It’s really our reflexive approach in pleasure and avoiding pain is what has kept us alive for so many, many generations on the planet
- It’s a very basic primordial structure that all living organisms, even primitive organisms have
  - Even the most primitive nematode or worm will release dopamine in response to food in its environment, which that dopamine allows it to locomote toward food
- It’s probably no coincidence that the same neurotransmitter involved in movement is also involved in pleasure, reward, and motivation, because prior to about 500 years ago, if you wanted to get a reward, you had to work for it
  - That’s no longer true, which is one of the reasons our brains are so confused today

***You could almost make the argument that because we have these large frontal lobes that can sort of reason and appreciate future consequences, human beings might be even more capable of getting out of the cycle of addiction than other organisms***

- It is miraculous that even people deep in the most severe addiction can find somewhere within themselves the capacity to stop using

> “*It seems to me almost a miracle in my clinical work when I get people who have been in severe addictions for decades who somehow find it within themselves, either through some logical reasoning or some spiritual surrender or some combination to actually get into recovery.*”‒ Anna Lembke

## The clinical definition of addiction, and the behavioral criteria for diagnosing it [13:00]

**How does one truly define an addiction in a clinical setting?**

- The diagnosis of addiction is based on what we call **phenomenology**
  - These are patterns of behavior that repeat themselves across individuals with unique temperaments, demographics, time periods, geographic locations
- There is no brain scan or blood test to diagnose addiction, although we know that addiction is characterized by distinct brain changes
  - We are just not at a state of the art where we can diagnose it based on that

*It’s based on patterns of behavior that can broadly be summarized as the 4 Cs, plus tolerance and withdrawal*

- **The 4 C’s** are out of **c**ontrol use, **c**ompulsive use, **c**ravings, and **c**ontinued use despite consequences
- As you can imagine, that phenomenology is going to be a judgment call
  - And it’s going to be based on both that individual’s subjective endorsement of having those kinds of issues, plus the observation of other people around them
  - Which is to say you went to 10 different psychiatrists, you might get 10 different diagnoses, and that is true for all mental health disorders
- The entire [DSM (or Diagnostic and Statistical Manual of Mental Disorders)](https://en.wikipedia.org/wiki/Diagnostic_and_Statistical_Manual_of_Mental_Disorders) is our codification of different buckets that we put people in for different forms of psychopathology, is completely based on phenomenology

***The 4 C’s, tolerance, and withdrawal are very clear evidence of physiologic changes***

- Psychological changes are also physiologic changes, but here we’re talking about more obvious manifestations of it being say a physical chemical body reaction
- [Tolerance](https://en.wikipedia.org/wiki/Drug_tolerance) is the phenomenon of finding that the drug stops working over time and that we need more and more to get the same effect or more potent forms
  - Tolerance is overcome by using more, using more often, or overcoming tolerance by changing the delivery mechanism
    - Instead of orally ingesting, maybe smoking or injecting or overcoming tolerance by changing slightly the chemical combination or moiety, or combining drugs together so that the brain sees something that’s similar but slightly novel
- [Withdrawal](https://en.wikipedia.org/wiki/Drug_withdrawal) occurs when one cuts back or stops using: their body reacts in a very predictable fashion, which is most often the opposite of whatever the toxicant causes
  - So if I’m taking a stimulant like cocaine or meth or nicotine or caffeine, and I try to stop using, my withdrawal phenomenon will feel like sedation, lethargy, inattention
  - If I’m using a sedative like alcohol, then my withdrawal phenomenon will be restlessness, jitteriness, maybe even seizures
    - Maybe even life-threatening seizures in the case of alcohol and [benzodiazepines](https://en.wikipedia.org/wiki/Benzodiazepine)

***Keep in mind that the universal symptoms of withdrawal from any addictive substance are anxiety, irritability, insomnia, dysphoria, and craving***

- Anna always likes to mention that because she’ll have cannabis users or alcohol users come in and say, “*Well, I don’t have any withdrawal, so therefore I’m not addicted.*”
- Well, did you feel anxious? Did you feel restless? Were you unable to sleep? Were you in craving mind?
  - Because those are all the actions (so to speak) that our brain takes to get us to try to use again

## Assessing alcohol use: patterns, risks, and addiction diagnosis [17:15]

**If a person comes to you and says, “*****I’m here because people around me think I drink too much,*****” what are the questions you go through to probe that?**

- Anna has developed a framework that relies on gathering data in a way that’s not threatening and sort of factually based, starting simply with data

*What do you drink?*

*How much and how often?*

- When we try to quantify that specifically with alcohol, we bring it down to what we call the standard drink
- A [standard drink](https://en.wikipedia.org/wiki/Standard_drink) is one 12 ounce bottle of beer, a 5 ounce glass of wine, or 1-1.5 ounces of hard liquor

![](https://peterattiamd.com/wp-content/uploads/2024/10/f3-annalembke.png)

**Figure 3. Examples of a standard drink that contain 14 grams of alcohol**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Standard_drink)

- We use something called the [timeline followback method](https://en.wikipedia.org/wiki/Timeline_Followback_Method_Assessment_(Alcohol)) [here’s an [example](https://adai.uw.edu/instruments/pdf/Alcohol_Timeline_Followback_30.pdf)] because it tends to be more reliable than a sort of general gestalt where we say, “*Okay, how much did you drink yesterday? How much did you drink the day before that? And the day before that? And the day before that?*” Until we get 7 days
- We add it all up and then the person goes, “*Oh, wow, I’m drinking 21 standard drinks in a week*.”

***That’s very useful information for the healthcare provider and that individual because when we’re chasing dopamine, we have a funny way of not being very good self observers and losing track***

*We simply gather the data, then we ask people to tell us why they drink, what is the positive thing that they get out of it*

- We also try to hint a little bit at tolerance, which is to say, “*Is it still working for them the way that it used to?*”
- When we’re gathering data, we’re also looking for **binge patterns**
- Some people can go a long time without drinking, but then they’ll have, let’s say **for an adult male, a binge is considered 5 or more standard drinks in a sitting**
  - A sitting is a single day
  - **For an adult female, it’s 4 or more standard drinks in a sitting**
- And when we find that pattern, that’s also very concerning
- The nice thing about alcohol is that these questions are based on [epidemiologic studies](https://pubmed.ncbi.nlm.nih.gov/37000449/) showing that for an adult male who drinks more than 14 standard drinks per week or more than 4 on any given day, there’s a much higher risk not only of having an alcohol addiction, but also developing all-cause morbidity and mortality
  - Or an adult female who drinks more than 7 standard drinks per week or more than 3 on any given day
  - This includes pancreatitis, heart disease, cancer, injury, accident and death

*We start there, then we probe why do people drink?*

- People drink for all kinds of reasons, but broadly speaking, they drink to have fun or to solve a problem
- That problem can be anything from social anxiety to loneliness to boredom and everything in between

*What are the problems that you have noticed?*

- Interpersonal problems, work problems, health problems, the simple problem of tolerance that it’s not working for you the way that it used to
- Are you having mental health problems, depression, anxiety, insomnia and attention?
- Then based on that, we begin to see a picture that nudges us toward thinking that yes, this person has what we call an alcohol use disorder
- You can see it’s quite judgmental and contextual depending upon the culture
- But one of the things that often happens is people will normalize their use by affiliating with other people who drink heavily
  - They’ll say, “*Well, you may think that’s a lot, but my fraternity brother Joe drinks way more than I do.*”
- Well, yes, but in the general population, you’re in the one percentile in terms of even just the amounts that you drink
- And we know that just based on amounts, you’re at higher risk for all-cause morbidity and mortality, even separate from our diagnosing an addictive disorder
- With alcohol, many people are familiar with the medical complexity of alcohol withdrawal and how things like [DTs](https://emedicine.medscape.com/article/166032-overview) can become an actual physiologic risk to mortality if a patient isn’t withdrawn safely from alcohol using things like [benzodiazepines](https://en.wikipedia.org/wiki/Benzodiazepine)
- Tolerance is clear in alcohol

## Applying the addiction diagnosis framework using gambling as an example [21:45]

**What if we talk about something like gambling? How does the framework work for something like that?**

*If a person loses a million dollars a year in gambling, but they make 10x that and it’s not actually impacting their life in other ways, how do you ferret out whether or not this is pathologic?*

- When you think about the four C’s (out of control, compulsion, craving, and consequences) plus tolerance and withdrawal, none of those is sine qua non
- And in fact, you can have no tolerance and no withdrawal and still meet criteria for an addiction

***People can actually have physical withdrawal from behavioral addictions like gambling where they have headache, nausea, vomiting, insomnia***

- But for gambling disorder, theoretically, you could have somebody who was gambling a lot and had no control issues
  - Meaning that they could set a certain amount that they were going to spend, and even if that was a very large amount, they adhered to that amount
  - When they decided to cut back or abstain for a period of time, they were able to do that
  - They could have no reported cravings, although again, we’re not the best judges often of ourselves when it comes to this disease process

***They could have no consequences because they’re making money, although generally with pathological gambling, that almost never works out that way (the house wins)***

**Then you have to get into the more subtle factors of compulsive use**

- Compulsive use means a lot of mental real estate occupied with thinking about using, getting the drug
  - Maybe covering up drug use because other people don’t approve
  - Finding that other things are less salient
    - So a kind of narrowing of our focus on that particular activity, a loss of joy in other things that we used to find pleasurable, and a level of automaticity
  - They are immersed in it and have a kind of a qualitative judgment about the attachment

*Which is to say, feeling like if I don’t have this activity as an outlet, I can’t function*

- Even on just a mental level, even if objectively everything looks great on paper in terms of my life, I’m so deeply immersed in this kind of addiction vortex that I’m thinking about it all the time
- I’m organizing my life around it
- I don’t feel like there are other things that I can do or take joy in
- When I try to decathect (or remove some attachment), I get anxious, I get irritable, I can’t sleep

> “*The interesting thing for me about treating addiction is that it is a biopsychosocial disease*.”‒ Anna Lembke

- There’s a biological component, psychological, and a deeply embedded social and cultural component

**For example, workaholism is really celebrated in our culture**

- We have many, many workaholics, and Anna and Peter might even be in that category
- And yet there are so many social rewards, monetary, social validation, you name it, that this compulsive engagement in the work that we do, we may not ever identify as problematic unless we begin to look at more **subtle manifestations or harms like opportunity costs**
  - Like, because I’m spending all this time working, I really don’t know my children
  - Or because I’m spending all this time working, I’m not cultivating friendships or not investing in my partner or in my health or whatever it may be

## Exploring addiction variability: how nature, nurture, and access shape individual vulnerability and drug of choice [25:15]

**Why different individuals become addicted to very different stimuli, even if the final common pathway is comparable**

- Peter wonders, if you could put all of us into whatever type of scan (fMRI) that we might use to pick up on the areas of the brain that undergo excitation, why is it that for one individual, alcohol becomes the thing, whereas for another person it becomes an opioid?
- And are there clusters where for certain people, chemicals really are the problem, and yet for others it’s more behaviors?
  - Chemicals may be opioids, alcohol, cocaine

*Why Peter asks this question*

- When he was in medical school, he suffered a really debilitating back injury, and through some errors in the part of the medical system, he ended up on very high doses of [oxycodone (brand name OxyContin)](https://en.wikipedia.org/wiki/Oxycodone)
- Predictability, he went through the escalation of those doses until he was up to 300 mg a day of Oxycontin (a pretty staggering dose)
  - That’s a dose that if Anna and Peter split it right now, they would be dead
- After about 6 months of being on enough oxy to kill a horse, he decided he wanted off
- It was a strange moment when he realized he wasn’t taking it because he was in pain anymore but because he wanted to escape how depressed he was that he was debilitated
- He stopped cold turkey, and the anesthesiology resident he was dating at the time said, “*You are effing crazy. You’re going to die. We need to put you on* [*nortriptyline*](https://en.wikipedia.org/wiki/Nortriptyline) *and 10 other drugs to taper you off.*”
- He insisted on doing it cold turkey, and spent the next 2 weeks in hell

***The point of this story is he is no more inclined to struggle with an opioid than any other person for reasons he doesn’t understand***

- After that experience he was afraid of opioids, and he assumed he was addicted
- But maybe 10 years later when he had a really bad tooth condition and nothing was touching the pain, he finally took a [Percocet](https://en.wikipedia.org/wiki/Oxycodone/paracetamol)
  - Then after the tooth was addressed, he stopped taking Percocet and there was no issue

***He concluded from that experience that this was not a willpower thing that allowed him to quit; it was just a luck thing***

- There is something physiologically about him that was not becoming addicted to that substance, and that’s why he was able to stop cold turkey

Peter asks, “*What explains this difference?*”

- Clearly there are areas (like work) where Peter is not so lucky, where the addiction is real and the struggle is daily
- Anna starts with Peter’s interpretation of his experience, which is that he became physiologically dependent on opioids in medical school, but ultimately, he is not a person who’s going to be addicted to opioids
  - He ultimately decided that this was not an inevitable problem for him
  - But he recognized that it could be an inevitable problem for somebody else

**Risk factors for addiction can broadly be placed into 3 separate buckets, which Anna calls: nature, nurture, and neighborhood**

- The **inherited or inborn risk for addiction** based on family and twin studies is about 50 to 60%
  - Studies showing that if you have a biological parent or grandparent addicted to alcohol, you are at increased risk of getting addicted to alcohol than the general population, even if raised outside of that alcohol using home
  - These are really nicely, carefully done studies
  - High [heritability](https://en.wikipedia.org/wiki/Heritability) is determined by twin [concordance](https://en.wikipedia.org/wiki/Concordance_(genetics)) and family studies
    - Looking at kids who were adopted into non-alcohol using homes who developed alcohol use disorder at higher rates because they had a biological parent or grandparent
- For a long time, people have talked about the “addictive personality,” but it gets to the heart of this idea that yes, people come into the world with different vulnerability to this tendency to take to the extreme the pursuit of certain types of highly reinforcing substance behaviors once discovered in the environment
- It’s also probably true that we each have different what are called ‘drugs of choice’
  - Even with people who are **polysubstance users**
    - By the way, this is more common than not today
    - People use a lot of different substances and behaviors

**Interestingly, there’s very little science on the concept of drug of choice**

- This concept is really important because what it means is that we have the phenomenon of access intersecting with drug of choice to increase the risk for certain individual

*To back up*

- 1 – We’ve got the nature, the inherited risk
  - By the way, that probably goes along with co-occurring mental health disorders
  - People with mental health disorders are at increased risk of developing addictive disorders, and addiction is probably a complex polygenic phenomenon
- 2 – Then we have risk factors based on nurture
  - This is the way that we are raised
  - Early childhood development
  - Parents that model maladaptive, addictive behaviors or that explicitly or implicitly condone substance use or other addictive behaviors
    - Those kids are more likely to develop addiction in adulthood, especially if there’s trauma, if there’s negative attachment
    - Whereas kids who are raised in a home where patients are modeling healthy, adaptive coping strategies, where they have a good attachment to their kids, where there’s not sexual, physical or emotional abuse, those kids are relatively protected
  - Nobody’s completely protected
  - You can have the perfect childhood and still end up addicted
- 3 – Then we have what Anna calls **neighborhood risk factors**, and these get to the key of access

> “*One of the biggest risk factors for addiction is simple access to that drug. If you live in a neighborhood where drugs are sold on the street corner, you’re more likely to try them and more likely to get addicted*.”‒ Anna Lembke

- If you go and get medical care at a place where people liberally prescribe opioids, benzodiazepine, stimulants, your brain will be exposed to those drugs, it will change in response to those drugs, and you are at increased risk of getting addicted to those drugs

**Back to Peter’s case**

- The risk of access was ultimately what got him initially hooked, but probably other innate protective factors allowed him to not end up with a serious addiction
- Probably in terms of genetic protective elements, maybe having to do with the way that he was raised
- Anna doesn’t know him, so it’s hard for her to judge
- But essentially, that’s how we think about it

*The part that’s most curious to Peter is that there are clearly things where he behaves in very addictive ways today*

- Online shopping
  - Peter’s wife describes him as an E-shopaholic, and she can tell his stress level by the number of Amazon packages that come to the door
  - When he’s under low stress, he’ll go a week without a package
  - When he’s under high stress, 3 packages a day
  - To be clear, it’s not breaking the bank, he’s buying stupid irrelevant trinkets, but it’s a dumb little escape
- He’s fortunate that the consequences of that addiction are minimal, but he’d like to believe he’s at least wise to the fact that there’s just a general good luck that is permitting Amazon to be his pusher as opposed to someone selling illicit drugs

*And he wonders why*

- To Peter, this speaks to: we’re all addicts potentially

*Why are some people unlucky in that the addiction turns out to either kill them, or destroy the quality of their life and their relationships?*

- In Anna’s book ([*Dopamine Nation*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1)) she talked about how she got addicted to romance novels
  - Granted, it was a minor addiction
  - Once she recognized it, she changed those behaviors

***This brings us back to this concept of drug of choice and how it intersects with access***

- Because what’s so challenging about the world today is that not only do we have more access to more potent forms of traditional drugs (including alcohol, but all the other drugs that have been around for millennia), but we also have brand new drugs that didn’t exist before
  - All of the online digital media, online shopping, pornography, the drugification of the romance novel, etc.
- Peter loves the way she described this in her book, “*We are cacti living in a rainforest*.”
  - It’s a beautiful way to describe the bizarre existence of the human in this condition relative to 10,000 years ago
  - This is [Dr. Finucane’s](https://biography.omicsonline.org/united-states-of-america/johns-hopkins-university/thomas-finucane-262940) metaphor

***We weren’t evolved for the world that we live in now***

- Back to Anna’s example, she thought that she hadn’t inherited this so-called “addiction gene” because alcohol was never reinforcing for her
  - Caffeine doesn’t wake her up
  - These are the legal and easily accessible drugs that people who do find those drugs reinforcing are going to be vulnerable to because they’re legal and accessible

> “*Why do nicotine and alcohol kill more people every year than any other drug? Because they’re legal and they’re accessible.*”‒ Anna Lembke

- Now that we have drugs like online shopping and romance novels, people like Peter and Anna who maybe thought they didn’t inherit this “addiction gene,” maybe that’s not true at all

***Maybe we just hadn’t yet met our drug of choice, and now that we have new drugs proliferating, we are discovering we are just as vulnerable as the next person given the key that fits into our neurobiological lock***

**When Anna thinks about this from an evolutionary perspective**

- It makes a lot of sense that mother nature would want there to be inter-individual variability in terms of drug of choice
- If we’re living together in a tribe, in a world of scarcity and ever present danger, it’s very good if we’re not all going for the same exact berry bush
  - Which is the world that humans have existed in for most of the time that we’ve been around
  - If you like the red berries and I like the blueberries and somebody else wants to hunt meat, and somebody else wants to look for people, that way, we as a tribe can be pretty well guaranteed that together we’re going to be able to get all of the scarce resources that we need to survive

**What Anna thinks about the heart of Peter’s question**

- It’s not so much, “*Why is it that some people get addicted and others don’t?*”
- Because we’ve just explored the fact that really we’re all vulnerable, especially in the modern ecosystem
- But why is it that some people can self-correct that as we progress on this road of compulsive overconsumption

**Why is it that some people can see it and make an adjustment?**

*Peter want’s to make sure the listener understands about his experience with opioids*

- When he tells that story, he’s not claiming to have self-corrected
- He is simply saying it was not the “lock and key” for him
- It was actually quite easy to stop
- The only suffering he went through was the physiologic withdrawal
  - Which is dramatic, but it’s a chemical reaction that was gone after a few weeks
- Even now as he sits here, he has a bottle of Percocet in his bathroom, and it’s been there for 10 years
  - It wouldn’t occur to him to use it, but if he was in significant pain, he would take 2 and not think twice about it (and it would be fine)
- To be clear, it wasn’t through any self-discipline that he stopped taking it
- It was quite easy once he decided and made the observation that he shouldn’t be taking it
- Peter adds, “*If I was truly one of willpower, I would never step foot on Amazon again. Or if I did, it would only be for something that I needed.*”
  - In that sense, he is a junkie and doesn’t seem to possess the tools (at least innately) to stop it

**Anna’s takeaway**: Peter doesn’t think he has a vulnerability to opioid addiction, but he is addicted to online shopping

- She thinks Peter is too hopeless about his online shopping
- She thinks that’s an addiction that if he decided he wanted to, he could work on and make progress

**In her book, Anna talks about a patient who got addicted to online shopping**

- Addicted to the point where his house was full of partially open boxes, he was in credit card debt approaching financial ruin
- He didn’t even get pleasure from the things he ordered anymore
- It was just the anticipation, and then it would come, and as soon as he opened the box, he would have an immediate come down
  - Which Peter can relate to
  - It would be awful if you’re spending all of that energy on something and you open the package and you’re like, “*Yeah, great. Okay, what’s next?*”

## How abstinence from addictive behaviors can help reset the brain’s reward system and improve mental health [41:15]

- [Aristotle](https://en.wikipedia.org/wiki/Aristotle) talked about what he called “wide-eyed incontinence:” “*Why is it that I do what I do not want to do?*”
- Because really that’s at the heart of addictive behaviors, and Anna is  guessing that people look to Peter as a sort of paragon of self-discipline
- So it’s very nice for people to recognize that even Peter has arenas in which he is incontinent in this regard
  - Which by the way is really hard to admit in our culture because we’re all supposed to have it together and have all this kind of self-control

***Almost all of us now have some space in our lives where we’re over consuming either a substance or behavior, even if it’s only mildly problematic that we’d like to change***

**Anna has seen people with very severe and life-threatening addictions be able to get into recovery and maintain recovery for decade**s

- We can all look to those individuals as guides for the rest of us and not be overly fatalistic about our own capacity to change these behaviors
- We can change these behaviors, and she would also suggest that to do so is not just important for our own mental health, but it’s also important for the planet
  - Our consumptive behaviors really do affect everything around us

- As Peter read some of the stories in her [book](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1), he thought, “*Well, she included this person there must be a happy ending*,” but as he’s reading it he’s thinking, “*There’s no way this person is getting out of this alive*.”
- He had a lot of empathy for these people
- Maybe that’s because anybody reading it who themselves has an addiction (even a “benign” one) realizes that’s devastating

**Young woman discussed in the** [**book**](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1) **whose parents talk her into seeing Anna, who consumes pot around the clock**

- The legalization of marijuana is very controversial
  - This is something Peter finds himself divided on
- Anna talked about the neighborhood a second ago, and this is a good example
- All the patients Anna talks about in the book are patients who she knew well
  - They were long time patients
  - She asked for their permission to share their stories using a pseudonym
- This was a young woman, very typical for the types of patients that we will see now, who came in not looking for help with her cannabis use, but looking for help with her **anxiety** and her **depression**
- 20 years ago, the first thing Anna would’ve done for a patient like this was prescribe an antidepressant or an anxiolytic (maybe [Xanax](https://en.wikipedia.org/wiki/Alprazolam) or [Klonopin](https://en.wikipedia.org/wiki/Clonazepam)) and referred her for psychotherapy

> “*My practice has changed very much in the last two decades because of what I’ve learned from patients in recovery and the ways in which repeated use of highly reinforcing substances and behaviors actually changes our hedonic or joy set point and creates exacerbates and drives depression and anxiety*.”‒ Anna Lembke

***Now the first intervention that she does with a patient like this is to actually ask them to abstain from their drug of choice for 4 weeks as a way to reset those reward pathways to see whether or not that alone will address the anxiety and depression***

- In the majority of her patients, if they are willing and able to do that, they feel so much better after that abstinence trial or dopamine fast
- Such that there’s not even an indication after that to prescribe an antidepressant or an anxiolytic or necessarily do psychotherapy

**How our brains balance pleasure and pain [46:30]**

*How that hedonic setpoint gets changed from the perspective of neuroscience:*

- One of the most interesting findings in neuroscience in the past 75 years is that pain and pleasure are co-located in the brain and work like opposite sides of a balance
- So if you imagine that deep in these limbic structures in nucleus accumbens (the area that’s rich in dopamine releasing neurons), there’s something like a teeter-totter [shown below], a central beam on a fulcrum that in a very simplified way represents how we process pleasure and pain

![](https://peterattiamd.com/wp-content/uploads/2024/10/f4-annalembke.png)

**Figure 4. Metaphorical representation of how our brains balance pleasure and pain**. Image credit: [*Dopamine Nation*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1)

- When we experience pleasure it tips one way, pain, it tips the other
- There are certain rules governing this balance, and the first and most important rule is that the balance wants to remain level
  - And that level balance is what neuroscientists call **homeostasis**, such that with any deviation from that level position (which is the definition of biological stress), our brains will work very hard to restore a level balance
- For example, this patient uses cannabis through the endogenous opioid system that ultimately leads to the release of dopamine and the reward pathway
  - Her pleasure, pain, balance tilts to the side of pleasure, and then her brain says, “*Oh, that was good. Let’s do that again*.”

 ***But remember, the balance wants to return to the level position, and it does that by adapting to that increased dopamine, by downregulating dopamine transmission and production, not just to baseline levels but below baseline levels***

- Anna imagines that as these neuroadaptation gremlins hopping on the pain side of the balance to bring it level again [shown in the figure above]
- But the gremlins like it on the balance, so they stay on until the balance is tilted in equal and opposite amount to the side of pain [depicted in the figure below]
  - That’s the hangover, the come down, the “blue Monday,” or just that state of craving

![](https://peterattiamd.com/wp-content/uploads/2024/10/f5-annalembke.png)

**Figure 5. Metaphorical representation of how our brains pleasure and pain whereby pushing on the pleasure side causes gremlins to hop on the pain side**. Image credit: [*Dopamine Nation*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1)

- Now if after that initial use, the patient doesn’t smoke again, those neuroadaptation gremlins get the message that their work is complete, they hop off the balance and homeostasis is restored, craving goes away, and she goes on with her day

***But if she continues to use that substance (in her case, cannabis) repeatedly over time, ultimately what happens is those gremlins on the pain side of the balance start to accumulate***

- They get bigger, they get stronger
- Now they’re camped out there
- And now essentially we’re entering addicted brain

***Now when she uses cannabis, that initial deviation to the site of pleasure is weaker and shorter in duration, but that after response to pain gets stronger and longer***

- Ultimately, she ends up in a kind of **chronic dopamine deficit state** below her natural dopamine baseline where she is experiencing the **universal symptoms of withdrawal** from any addictive substance
  - Which are: anxiety, irritability, insomnia, dysphoria and craving
- When she uses cannabis, that temporarily counteracts those gremlins on the pain side of the balance, and she feels better
- So she thinks to herself, “*I’m self-medicating my anxiety with my medical marijuana,*” but in truth, all she’s really doing is just adding more gremlins to the pain side of the balance
- The intervention is to have her abstain from cannabis long enough so that those neuroadaptation gremlins get the message they need to hop off the pain side of balance so that healthy levels of dopamine firing can be restored
- This is obviously a vast oversimplification of a very complex process, but it gets to the heart of homeostasis (a level balance)
- **Allostasis** is our brain’s attempt to adapt to these highly reinforcing stimuli for which it was not evolved

***And the definition of an intoxicant is that it releases a lot of dopamine all at once in the brain’s reward pathway***

- Our brains were evolved for us to have to work very hard to find a tiny little jolt of dopamine and then essentially do that again and again to stay alive

**The intervention is to ask her to abstain and to let her know that she’s going to feel worse before she feels better**

*Maybe she’ll have other signs of physiologic withdrawal*

- She had vomiting, which really shocked her, because she thought that was a physical sign that she had become dependent on or addicted to the cannabis

> “*If you can just get through about the first 10 to 14 days of feeling worse after you give up your drug of choice, by the time you make it to about week three or four, you will feel better, less craving, less anxious, less depressed, better able to sleep*.”‒ Anna Lembke

- That’s so often a revelation for people; because they have become convinced that their drug of choice is “self-medicating” their depression or whatever it is

## Safely abstaining from addiction substances, drugs needing medical supervision, and other key considerations [51:30]

***Which drugs or chemicals is it not safe to do that with?***

- In the case of cannabis, the pain that she experienced was not life-threatening and therefore she didn’t need anything to cope with withdrawal
- We’ve already discussed how that would *not* be the case with ethanol
  - If someone was having 6 drinks a day and they wanted to stop, and they tried to not drink and come back in 4 weeks, there’s a very good change they would be dead due to the cardiovascular side effects

*What other dependencies would you not have the liberty of stopping cold turkey?*

- That’s a very good point to qualify this intervention, but it’s not necessarily true that for somebody with an alcohol addiction, they couldn’t do this intervention
- It would depend on how severely physiologically dependent they were and whether or not they were at risk for life-threatening withdrawal or [delirium tremens](https://en.wikipedia.org/wiki/Delirium_tremens) or seizures

***Most people who are addicted to alcohol actually won’t have life-threatening withdrawal and could do this***

*How do you determine that?*

- When Peter was in surgical residency and they operated on people who appeared to drink a lot, they would run an ethanol drip in them for safety
  - He doesn’t think there was any real insight into whether that was really necessary or not

***The biggest predictor of how someone is going to withdraw from alcohol is past withdrawal***

- Anna will ask them, “*When was the last time you stopped drinking? For how long? And what was your symptomatology?*”
- It’s not fail safe
- As people age, they lose neuroplasticity, their risk of having some kind of more difficult or even potentially life-threatening withdrawal increases
- It also increases over the drinking career, especially as their liver is compromised or pancreas is compromised
- Anna explains, “*We don’t understand why some people who drink enormous quantities for decades can stop and have minimal withdrawal, and other people who have had much shorter drinking careers will go into delirium tremens or have life-threatening seizures. So we’re not at all cavalier about it*.”

***For any patient that we remotely suspect might have a serious withdrawal, we would recommend medical monitoring or possibly inpatient monitoring***

- We don’t recommend this early intervention for somebody who was at risk
- But most people who are addicted to alcohol will not have life-threatening withdrawal from alcohol

***The other major category is benzodiazepines, which is alcohol in pill form***

- They work on the same or similar [GABA receptors](https://en.wikipedia.org/wiki/GABA_receptor)
- People can have life-threatening withdrawal from benzodiazepines, which is why for many individuals we will recommend a medically monitored slow taper or a more rapid inpatient detox
- We used to think that **opioid withdrawal**, although extremely painful, was not life-threatening
- But in the last 20 years as we’ve been helping people decrease the very large doses of prescription opioids they’ve been given by their doctors, we have noticed that especially in older people and people with serious medical comorbidities (for example, cardiac comorbidities), the stress is just too much and those individuals ***need to be slowly tapered down***

***The ones we screen for are alcohol, benzodiazepines, and opioids***

**The other category of individual in which we would not recommend this “dopamine fast” or abstinence trial is individuals who have repeatedly tried to stop on their own and have been unable to**

- That would just be a lesson in frustration
- Those are individuals that we would recommend to a higher level of care, like a day treatment program or a residential treatment program

*Especially with opioid use disorder (opioid addiction)*

- We are finding that some people, even with long periods of abstinence, never get out of that state of craving and really can’t move on with their lives, which is why we will prescribe opioids to treat opioid addiction in some cases, and for example
  - Medications like [buprenorphine](http://buprenorphine) or [methadone](https://en.wikipedia.org/wiki/Methadone) maintenance are evidence-based interventions for opioid addiction
- It seems counterintuitive to give a patient with an opioid addiction an opioid, but they’re very unique opioids
  - They have a long half-life, which means it gets people out of this repeated cycle of intoxication, withdrawal, drug seeking… gets them out of that state of craving
- And if you think back to this pleasure pain balance, we’re not getting folks with opioid use disorder high by giving them opioids, we’re just allowing them to level their pleasure, pain balance, go back to baseline homeostasis, which then frees up their energy and creativity to engage in other aspects of their recovery

**If someone’s listening to us now, and by the end of this podcast they’ve become convinced that maybe they’re drinking too much and they’d like to try this dopamine fast, do you recommend that they speak with their doctor before doing it?**

*Is this something that a person can safely try if they’re aware of what side effects might prompt medical attention?*

- If the individual has any concern about serious medically dangerous withdrawal from alcohol (or from benzodiazepines or from opioids), they should consult a medical specialist
- But the majority of people who use these substances have taken periods on the order of days or maybe even weeks when they have stopped
  - So they have a pretty good sense of #1 whether they can do it, and #2 what kind of reaction their body will have

***Anna thinks this is an experiment that most people can try without medical supervision, especially if they’re in a position to either not be able to afford it or have access to somebody who’s trained in addiction medicine***

- We have far fewer addiction medicine providers in this country than we have the need to address the problem

> “*I think as an early intervention, it can be a nice experiment even just to see if they can do it.*”‒ Anna Lembke

- Sometimes we think we have some degree of control, and then it turns out we don’t have the degree of control that we thought we had
- It’s also just a very interesting experiment for those who are not addictive to get a sense of deep understanding and empathy for the problem of addiction
- Even just giving up something like online shopping or romance novels or video games or what have you, and to observe ourselves going through withdrawal can be enlightening
- As Peter experienced with the opioid withdrawal in that medical setting [discussed earlier], it gave him a great deal of empathy and healthy respect for the phenomenon of addiction

## Transitioning from abstinence to long-term recovery: tools and considerations [59:00]

**The point about the neighborhood is really clear**

- It’s very difficult to kick a habit if you go right back into the environment in which that habit was rife
- In the case of this patient, she comes back after 4 weeks
  - It’s been a transformative experience in that she’s gone through very painful withdrawal
    - Anna prepared her for it by telling her it was going to hurt a lot, and that she needed to sit in the pain effectively
  - And when she comes back, the anxiety is gone

*How do you now help her with this next phase of recovery, and how difficult a set of choices does that person need to make if indeed their social circle basically fed into that addiction?*

- Peter thinks that as hard as that 4 week abstinence program is, what follows might actually be harder

***If that patient is able to abstain for 4 weeks, when they come back, Anna asks them how it went and they make a list of pros and cons***

- What was good about not using, what was bad about not using in those 4 weeks
- About 80% of folks feel better (20% don’t); and that’s also really useful information because it tells us that something else is driving this, and then we explore that
- For this case, the feeling better **on the pros side**, people will talk about, “*I was more productive. I had more time. I was able to be more present. I felt physically better. I was less anxious, less depressed, slept better, etc*.”
  - There’s really a nice long list of things that they gained from stopping using

***What is so powerful about this intervention is that the person has their own experience, and Anna is no longer in the role of having to persuade them that not using or using less will make them feel better***

- They have experienced it for themselves
- What was bad about not using, **on the cons list**, Peter already anticipated pretty much the top one, which is, “*I couldn’t hang out with my friends because all my friends use and I really like my friends and I want to go back to hanging out with them.*”
  - That poses a serious dilemma
- The other major con that people endorse is just simple **boredom**
  - All of a sudden, people are left with lots of time and wondering what to do with it
- Anna likes to talk a lot with patients about boredom being kind of the midwife of creativity

**Self-binding strategies are important for recovery [1:01:15]**

*Then we talk about next steps*

- The first time around, ***most patients want to go back to using their drug of choice, but they want to use differently***, they want to use in moderation
- She supports them in that goal (even if she thinks that’s a bad idea) because again, this is experiential learning

***She can talk till the cows come home, until they experience it for themselves, it’s not really going to take***

**Anna has discovered that she’s a very bad predictor of who’s going to be successful and who isn’t**

- She’s had patients who definitely meet criteria for alcohol use disorder, serious alcohol addictions, who have been able to go back to using alcohol in moderation after an extended period of abstinence

Peter asks, “*What fraction do you think fits that description?*”

- It’s a small minority
- It’s definitely less than 10%, maybe even hovering closer to 1%

**Peter’s takeaway**: these people are clearly anomalies

Peter asks, “*What is it about an individual that allows them, on the one hand, to have met complete criteria for a true addiction (whether it be to alcohol or another substance), to go through a period of detoxification and emerge from that and say, ‘You know what? It’s true. I used to drink 6 drinks a day and I would blackout drink and binge drink, and it was ruining my life. DUIs all day long… but now I’m going to become a social drinker. I’m going to have a glass of wine with dinner every night. That’s it’?*”

- They’re doing it with a lot of **hard** **work**; it doesn’t come just like that
- It’s not like you abstain for a while, you reset your reward pathways, and you’re good to go

***Quite the contrary, once we’ve created those kinds of addiction circuits, even though we can get them to quiet down, they’re very easily reignited, not just by exposure to our drug of choice itself, but to reminders of the drug of choice***

**What Anna talks a lot with patients about is the specificity of the plan for how they will consume (the more specific, the better)**

- And this is all in the spirit of self-binding strategies
- Self-binding strategies are very, very important in a world where we’re constantly being titillated and invited to consume and told that that’s the good life

***Self-binding strategies are both literal and metacognitive barriers that we put between ourselves and our drug of choice so that we can press the pause button between desire and consumption***

- For a patient with a drinking problem, that might look like not having any alcohol in the house, right?
  - A very simple and obvious self-binding strategy
- That might look like pledging to never drink alone, but only with friends on special occasions
  - Making sure that I don’t fill my schedule up with many different special occasions (which happens)
  - That can look like making sure that I am very cognizant of how much I’m drinking and keep it to no more than 2 standard drinks on any given occasion, and track it carefully and write it down so that I don’t get into that state of blurry denial where I can tell myself it was only 1 drink when it was really 5
- That might even look like taking medications
- Medications like [naltrexone](https://en.wikipedia.org/wiki/Naltrexone), which is an opioid receptor blocker
  - Alcohol works in part through our endogenous opioid system, and by blocking the opioid receptor, we essentially make alcohol less reinforcing
  - People who will take naltrexone will say (at least the ones for whom it works), “*When I’m taking naltrexone, I can look at a six pack of beer and I just want to drink two. I don’t want to drink the whole six pack*.”
    - And that’s really a revelation for these people because before it would just be like, “*I really want to drink the whole six pack.*”

***Self-binding strategies can be at the literal physical barrier level; it can be at the chemical barrier level; it can be at a kind of interpersonal accountability level; it can be at a spiritual level***

- So wanting to live in accordance with one’s values or a greater good and seeing their use or their excessive use as contrary to living according to those values
- Really getting at it from all different angle
- People with the most severe addictions ultimately really need to get a totally different orientation on their lives, in the sense that they really need to inculcate a philosophy about life that allows them to maintain their recovery
  - Living recovery principles in all aspects of their lives
  - That’s things like **telling the truth in all situations**
- A lot of people in recovery have taught Anna that if they start to lie even about little things (like why they were late for a meeting), that is a potential for them to tip over and relapse
- It’s like a recovery mindset/lifestyle/philosophy; it has to become bigger than just the substance itself

**Typical outcomes after a “dopamine fast” or abstinence trial**

- Anna just described the effort that one would have to go to to dip their toe back into the water if a patient just wanted to have a couple of drinks
- Peter wonders about the cost of putting systems in place to adhere to that limit as opposed to just complete abstinence
  - That’s a lot of energy that could go into living a fuller life in other ways

**Is it really worth having a couple drinks a week or whatever it is you’ve agreed to?**

- This is a common discussion
- The typical outcomes that we see after the dopamine fast or the absence trial is first the **abstinence violation effect** where people say, “*I’m going to go back to using a moderation,*” and immediately they’re plunged into a binge episode even worse than what was there before
- Then there’s the discussion of, “*Gee, maybe moderation is really not possible.*”
- Or people who are able to achieve moderation, but who ultimately decide it’s so effortful and so much work that it’s essentially not worth it
- There’s this **famous AA lingo**, “*One drink is too many and two is never enough*.” Which kind of captures that very well
  - This idea that stopping at 2 doesn’t actually get me what I’m looking for, but does in fact reignite those addiction circuits such that it’s very difficult to stop at 2, and I want to keep drinking

***Those people will often ultimately decide that abstinence is not only better for them, but also easier***

## Exploring behavioral addictions like sex addiction, and the gender differences in addiction patterns [1:08:30]

- Of all the stories in [*Dopamine Nation*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1), the one about Jacob invites enormous sympathy
- Everybody’s heard of **sex** **addiction** and has an understanding of what it is, but it’s not necessarily what Anna describes in Jacob
  - His sex addiction is not the one that you would think of when you’re watching a TV show that features someone who’s a sex addict

**Briefly tell the story about Jacob and describe the pathology there, and what is the addiction giving him that maybe a gambling addiction wouldn’t give a gambler or an alcohol addiction doesn’t give the alcoholic?**

*What was the pleasure he was seeking relative to maybe what someone would normally think of as a sex addict is seeking many partners?*

- There are many different ways that sex addiction can manifest

***Sometimes when people get addicted to sex, they compulsively seek out partners, but many people addicted to sex now are addicted to pornography and compulsive masturbation***

- It’s very hard to get numbers on any of this
- The majority of cases that we see are *not* people who are having sex with other people
- They are people who are spending enormous amounts of time looking at pornography, masturbating
  - That’s so easy to do now, given the advent of the internet and online pornography
- Jacob started out with pornography and compulsive masturbation, but he is an engineer and ultimately built a masturbation machine that escalated over time as his addiction progressed
- As addictions will progress, he was ultimately hooking himself up to the internet, letting strangers in chat rooms manipulate this machine in a way that was really very dangerous and potentially life-threatening
  - Which he was fully aware of, and yet struggled to stop the behavior
- Ultimately, when the behavior was discovered by his wife, she left him and he considered ending his life
- When people say, “*Oh, you can’t really get addicted to sex the way you can with drugs and alcohol.*” Anna would just invite them to be a fly on the wall in the work that she does
  - We are seeing more and more men of all ilk coming in with what we broadly classify as sex addictions
  - This is compulsive masturbation or the pursuit of orgasm in many different ways (really devastating)

Peter asks, “*You mentioned this as primarily a male problem. Why do you think that is?*”

- There’s enough evidence to show that men in aggregate have a higher sex drive than women
- The joke about how much of a teenage boy’s brain is occupied with thinking about sex, it’s 99%; Anna loathes to speculate too much about that, but it’s just the truth
- That’s what we’re seeing
- We’re not seeing women coming in with sex addictions the way we are as with men
  - Occasionally we’ll see that, but it’s quite rare
- Although there are data emerging showing that more and more women are consuming pornography

> “*What’s been interesting to see in the modern era, the ways in which certain demographic groups that were previously relatively immune to certain types of addictions, that’s no longer the case.*”‒ Anna Lembke

- For example, with alcohol use disorder, for generations the ratio of men to women with an alcohol addiction was 5 to 1
- 30 years ago it was 2 to 1
- Today among millennials it’s 1 to 1
- We are now seeing young women presenting with alcohol use disorders pretty much as often as we see men

***So, who knows. With enough time it could well be that this is not necessarily a biological phenomenon and really just a sociocultural one, certainly in part it’s probably sociocultural.***

**Gender differences in addiction patterns [1:12:45]**

- Men effectively make up most of the patients who suffer from various forms of sex addiction
- Peter guesses that the same is probably true with gambling

*What are the addictions that may be stated the other way, where women disproportionately make up the patients?*

- The only one that Anna has seen data for where women outstrip men is for [benzodiazepines](https://en.wikipedia.org/wiki/Benzodiazepine)
  - Sedatives like [Xanax](https://en.wikipedia.org/wiki/Alprazolam), [Valium](https://en.wikipedia.org/wiki/Diazepam), [Klonopin](https://en.wikipedia.org/wiki/Clonazepam)

**If we take all addictions together, men have a greater problem with addiction than women I would guess just based on the simple fact that in most cases men outstrip women?**

- The new wrinkle there is **social media addiction** where we’re seeing more women and girls

Peter asks, “*Do you think that that fits more into nature, nurture, or neighborhood as the driver?*”

- It’s a combination of those 3 things

## Factors contributing to the increasing levels of addiction across the world [1:13:45]

**You talk about loss-chasing. Is that what the gambler is looking for?**

*Is there an analog to that in other forms of addiction?*

- Yes

***Loss-chasing is a phenomenon that’s been observed in pathological gamblers where they will report that when they are deep in an episode of gambling, they actually want to lose***

- The reason they want to lose is because the losing allows them to justify staying in the game longer
- That’s revealing because it shows that on some level, a gambling addiction isn’t really about being addicted to money

***It’s about being addicted to the pursuit of money or the game itself or the trance-like state that people can get into when they’re deep in their addictive behaviors, which Anna would argue applies to every single addiction under the sun***

**For example, sex addiction is not really about sex**

- It’s about self-soothing
- It’s about escape
- It’s about numbing
- It’s about relieving tension

***And that that’s true for all addictive behaviors***

**Brain imaging of dopamine levels in gamblers**

- There’s been some work using brain imaging looking at dopamine levels in pathological gamblers’ brains compared to healthy control subjects who are gambling
- Researchers [found](https://pubmed.ncbi.nlm.nih.gov/20712823/) that when pathological gamblers are winning, there will be an increase in dopamine transmission in the reward pathway, and the same will be true for healthy control subjects
- But the difference comes when they’re losing
  - When healthy control subjects lose, there’s no increase in dopamine transmission

***Pathological gamblers will actually have an increase in dopamine transmission when they’re losing, which maps very nicely on to this subjective experience of loss-chasing***

- And it looks like in a pathological gambler dopamine is released at the highest level when the chances of winning and losing are equal
- So it’s that place of uncertainty in the gambling state that is on some level the most appealing state for the pathological gambler

**Increased prevalence of addictions in the population**

- Addictions to social media are on the rise for the obvious reason that it didn’t exist 20 years ago
- Opioid addiction is clearly on the rise, partially attributable to the neighborhood access phenomenon

*Is the same true for marijuana?*

- Anna hasn’t looked at the latest data, but certainly overall in the last 20 years, Americans are using a lot more cannabis than they were previously
- And they’re using more potent forms of cannabis
- What we’re seeing in particular is that there’s a subset of individuals who use cannabis who are using very, very large quantities
- A generation ago (20, 30 years ago), people who used cannabis we’re still mostly using it recreationally on the weekends with friends

***Now what we’re seeing is a very hardcore group of individuals who use cannabis every day, all day, dabbing, highly potent forms, vaping, getting very high levels in their brains ‒ these are the trends***

> “*In other words, the increased access is going to harm a subset of the most vulnerable individuals who will be most likely to use it in very potent forms, in very large amounts*.”‒ Anna Lembke

**This raises a challenging societal question**: Do you punish all of the people for whom the increased access has potentially made life better?

**It sounds like sex addiction is on the rise**

- It’s very hard to get numbers on sex addiction, but based on 25 years of clinical practice, it’s on the rise
  - At least in terms of help seeking individuals
- Anna’s sense is that since the advent of the internet (especially the smartphone), which makes online pornography and chat rooms, dating apps, etc, so easy to access, we are dealing with an enormous problem in ever younger age groups

***What we see is really just the tip of an iceberg of kind of a rampant compulsive consumption of pornography among men and boys (more in a moment)***

**To close the loop on gambling, benzos, cocaine, and things of that nature ‒ where is the trajectory and trend line on those things?**

- With **gambling**, online sports betting has now become legal in many different states
- And in the states where it has become legal, we’ve seen a 300-500% increase in calls to pathological gambling hotlines, which is just one metric

*Again, it’s difficult to get numbers on these, but it does suggest that the old bugaboo of increased access leading to increased harms in a subset of the populations raising difficult policy questions*

- Do we as a society have a responsibility to protect those vulnerable individuals?
- And how do we do that?
- Do we do it at the expense of individuals who maybe can use those substances and behaviors recreationally without too much harm?

***Online sports betting is on the rise and just the portability of these devices, the ability to place a bet without a mediator anywhere, anytime, has really created very difficult situation for individuals who are vulnerable to pathological gambling***

*In terms of cocaine, methamphetamine, benzos*

- We’re seeing a rise in recent years in addictive use and harmful use of cocaine and methamphetamine, and it’s hard to know exactly why that is or where it’s coming from
- Again, accessibility: it may be partially related to decreased access in recent years to prescription opioids, people switching to stimulants or finding that when they combine a stimulant with an opioid, they can overcome tolerance and get more of a high

***Overall, if you look at all drugs of abuse, what we’re seeing is a gradual (not even gradual in some cases), what almost appears an exponential rise in drug overdose deaths. Anna would attribute that to ubiquitous access***

> “*There’s probably no corner of the world anymore that you can go to where you can’t get drugs.*”‒ Anna Lembke

- Peter finds this a little bit depressing because he didn’t hear that anything is going down
- In other words, you can’t even argue that the increase in some of these addictions is due to the substitution effect of some things are going down

**Is that assessment [of increased addiction] shared by both the data and your clinical experience?**

- The data show that, for example, **cigarette use** has gone down in the last 20 to 30 years
- And that you do get a kind of a whack-a-mole effect, as prescription opioids became less available, illicit fentanyl came in to replace it
- It’s not that everything is going up
- We are seeing some trends: as cigarette use went down, [e-cigs](https://www.cdc.gov/tobacco/e-cigarettes/index.html) go up
- The point Anna tries to make in [*Dopamine Nation*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1) is, “*We are living in a drugified world where we all have more access to highly reinforcing substances and behaviors, and that even so-called healthy behaviors like exercise and playing chess and reading novels have been made addictive through the advent of the internet and social media and all comparisons and what have you*.”

**We’ve really fine-tuned our understanding of how to get people hooked on just about anything which you could argue is a natural byproduct of a successful capitalist system**

- In the most successful capitalist system, we would all be addicts
- Addicts are the ultimate consumers
- Anna is not arguing for a system other than capitalism

***Anna is suggesting that this is problematic and that we’ve reached some kind of tipping point where if we don’t put some guardrails and measures in place to guard against this extreme version of consumption, we are all of us liable to suffer the harms of addictive behaviors***

## How online pornography can affect young boys’ developing brains and lead to addictive behaviors, and strategies for parents to address this issue [1:23:30]

- Anybody listening to this who has young boys is probably aware of and concerned about this
- Peter always thinks [Bill Maher](https://en.wikipedia.org/wiki/Bill_Maher) does the best job talking about this
  - He says, for people of our generation, pornography was like finding a raggedy old *Playboy* magazine in the woods
  - And there’s no question that you were obsessed with looking at that, but it didn’t warp your sense of sex
  - It didn’t pervert you to the point of potential pathology
  - And yet, today anything on your smartphone can basically do just that

**Is there an argument to be made that the impact of porn on your smartphone is differentially worse in a prepubescent/in puberty brain than it is in an adult?**

*What can parents do to educate their kids?*

- One of the things that has been very interesting to Anna in treating patients with sex addiction is to see **how tolerance manifests**
- Many of these individuals start out with kind of run-of-the-mill legal types of engagement with pornography or what have you
- But over time, as their brain adapts to those rewards, they develop tolerance, they need more potent forms to get the same effect, and they find themselves a year, 2 years, 5, 10 years later, then engaging in highly deviant or violent or pedophilic pornography
  - Or engaging with sex workers, illegal activities
- That is important because when we’re trying to distinguish a [paraphilia](https://en.wikipedia.org/wiki/Paraphilia) from a sex addiction

***Anna thinks many psychiatrists are not recognizing that the way that that person presents at sort of their end stage sex addiction might really be 100% due to tolerance***

- And if you can get them out of that addiction cycle, their preference for this illegal activity really might not be there

*In terms of the developing brain*: ***We do believe that children and adolescents are more vulnerable to these highly reinforcing stimuli, and that the earlier that folks are exposed, the more likely they are to develop an addictive process***

- We base that on analogy with substances because we know that the earlier that kids start using substances, the more likely they are to develop a substance use disorder in their lives
- We speculate that that is because adolescents still are developing the connectivity between the frontal lobe and those deep limbic structures (the emotion part of the brain)
- Anna explains, “*Adolescence is characterized by a period of pruning where the brain essentially cuts back on those neuronal circuits, and dendrites and axons that are being used least often, and myelinates those circuits that are used most often*.”
  - [Myelination](https://en.wikipedia.org/wiki/Myelin#Function) is what makes the conductivity faster and more efficient
  - Such that by the time we’re about age 25, we’ve essentially created the neurological scaffolding that will serve us for our adult lives

***That means if young people are engaging in maladaptive coping strategies and strengthening those circuits, it’s not impossible, but it’s harder to change once they reach 25 or early adulthood***

*The key for parents to realize*

- While they still have some modicum of control over how their children and adolescents are engaging with the internet, exercise that control to **limit access as well as educating and having open discussions** about the potential harm there
- What is the potential harm: these images are highly reinforcing
  - We were wired to find mates and partner

***What pornography essentially does is it hijacks these reward pathways with very potent images that are made all the more reinforcing by the fact that the individual can control them in the moment, with very little work that is required in real relationships***

- Orgasm is the release of bunch of neurotransmitters all at once, which feels really good for many people
- Anna highlights, “*Not every boy or man is actually drawn to pornography or sex.*”
  - We have this inter-individual variability
- But for boys and men for whom that is a reinforcer, it is the medium itself of the internet, the easy access, the potency, even dating apps
- The idea of **dating apps** is that we’re going to be matched with a partner, but what can happen is people get just addicted to the match, the confetti of the match, and then they want to have the pursuit and the match again
- And it’s not even necessarily leading to any kind of intimacy beyond that
- Or if it is, it’s just leading to hookups which are about the sex

*Anna’s recommendations for parents*

- Children under 13 not have unsupervised access to the internet, and if they must have some kind of phone device, have it be a light phone or a flip phone
- Once children get to the point where they have data and access to the internet, have a lot of open discussions about pornography
  - They can be really, really awkward discussions (Anna knows from her discussion with her 2 boys)

**Coaching points for discussing this with children**

- It’s been easy for Peter to have discussions with his daughter about illicit drug use because it’s a biochemistry discussion and the risk is really obvious
- He had a local sheriff from Austin on the podcast ([Anthony Hipolito, episode #243](https://peterattiamd.com/anthonyhipolito/)) talk about fentanyl toxicity and fentanyl-laced drugs
  - There are kids all over that are dropping dead from drugs laced with fentanyl (Ambien, Xanax, cocaine, whatever)

Peter asks, “*How are you making the case to a 13-year-old or 14-year-old that, hey, you’re going to be over at your friend’s house one day and you’re going to be playing sports, and all of a sudden he’s going to say, hey, come and look at this, because maybe in their household it’s not going to be as policed as it is in our household.*”

- This is where Anna really encourages parents to try as much as possible to be curious

***A good metaphor is to pretend like you’re a journalist and you’re just trying to get the story***

- Just ask them, what did you think about that?
- It’s very easy as a parent to get dysregulated in even speaking about these things or imagining their child engaging with these images, but it is the reality, so we have to go there

*Questions to ask*

- What did you think about that?
- Is that something that you have started using yourself to masturbate or get as an escape or a release? How is that working for you?
- How do you feel afterward?
- Really zeroing in on “*how do you feel afterward*” can be very instructive because usually there’s a pretty hard come down
  - As well as a feeling of like, wow, that didn’t actually do for me what I was hoping that it did, and I kind of am feeling bad about that experience
- This gets into the whole quagmire of sexual liberation and this argument that nothing’s wrong with pornography, nothing’s wrong with masturbation
- People are going to come to this with the different value systems

Peter asks, “*What do the data say? Are there data to tell us that one approach is healthier than the other?  What are the clinical anecdotes that probably are more valuable than just our built-in beliefs?*”

- The data that we have is that men and boys, and actually women now too, are spending a lot more time-consuming pornography and young people in particular are much less likely to go out and actually have sex with other people and be in relationship
- Now, whether or not those things are causative or correlative, we don’t know

***We could certainly make an argument that all the time that men and boys are spending engaging in pornography is actually becoming a substitution for real life engagement, either with their spouses or partners or other people that they might meet***

**Phenomenology of behavioral addictions**

- In clinical care, what we see with behavioral addictions (including sex addiction) is that the phenomenology is identical to drug and alcohol addiction
- People start out for fun or to solve a problem if it works for them
- They repeat that behavior, they go back again and again
- Over time, it tends to work less well
  - They need more potent forms or larger quantities to get the same effect
- And then at some point in severe cases, they’re marshaling all of their available resources in order to do that activity or consume that drug

***This is a very new problem, and we don’t have a lot of good data***

**People are not rushing forward saying, “*****I have a sex addiction*****”**

- It’s very common in clinical care that we’ll have a man come in and say in the first 1-3 visits that he’s here for some reason that’s not really the reason that he brought him in
  - He’s really here for a sex addiction, but it’s so difficult for him to talk about that
- This is highly stigmatized because at the same time that we have this incredible access to pornography, we also have a culture and a climate in which men and boys are really seen as sexual predators
- It’s a very potentially uncertain and dangerous environment for them to be trying to cultivate relationships in real life
  - It’s a risky environment
- And that is contributing to this kind of retreat from engagement and a kind of a self-soothing through this medium

## The link between social media use and declines in mental health, potential solutions, and protective measures [1:34:45]

- Social media is the forefront of everybody’s attention right now
- There’s a book out about this by [Jonathan Haidt](https://jonathanhaidt.com/) that talks a lot about this [[*The Anxious Generation: How the Great Rewiring of Childhood Is Causing an Epidemic of Mental Illness*](https://www.amazon.com/Anxious-Generation-Rewiring-Childhood-Epidemic/dp/0593655036/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.pLA6Rb-vSM6-wdPqDulw2K5ILrcN6OGLECqt7jVfs_b9v5bG7su5i2kcZexjOqy9V1GTaZE5fTDKSXx6L_rqyGTccLCBZILDR1XIAKuhTIGNfhbUxdr-o1c93LyZkhI98D2wtDtrcec6osK58yOlILw3r0Zc3zlhOILlVC1lYkd4f-qU0Hmy1TnPo_yS8RNasvTnWrtxpF0CZaEGR2drW2PiQ2IwatUD7-9SCB5BVKE.JIihCznpYfby3m9Wfz1eBg2I1y28wA20VBEfS5tbSxU&qid=1721314717&sr=8-1)]
- Peter had dinner with Jonathan several months ago before the book came out and asked him about the **correlation between social media and declining mental health amongst young people**

- He asked, “*How compelling are the data and what would need to be done to demonstrate causality?*”

- Because if you have causality, it becomes much easier to have a discussion about policy and action
- For example, once causality could be unambiguously established for tobacco use and cancer, the die was cast for the monotonic decrease in tobacco consumption that has occurred over the last 50 years
  - Which really occurred in the late ’60s
  - By the way, it didn’t occur through RCTs, right?
  - It occurred through a very careful application of the [Bradford Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria), coupled with some mechanistic and animal research
    - Obviously, no one could do the RCT to demonstrate the harm of tobacco with respect to cancer
- And when causality is missing, it becomes very difficult to make the case for it

***Peter has read all of these arguments, and the majority of people believe there is causality***

- The **minority argument** is there are a lot of reasons that young people are too anxious today
  - Social media might be one of them, but it’s far from the only one
  - These people would argue that we’ve catastrophized everything in the world

**Do you think we have causal evidence that social media is a net negative?**

- Anna starts at the end: she doesn’t think anybody who thinks there’s a causal harm from social media thinks that we should get rid of social media (that’s impossible)
- What we’re talking about is guardrails
- Peter adds that Jonathan doesn’t think that either ‒ his argument is maybe people should not be using social media while they’re young

*One of the most important type of evidence in medicine is empirical evidence*

- This is observation and subjective experience

***We have plenty of empirical evidence to show that young people endorse, that they feel addicted to social media, not all, but many, and that they use it more than they would like and that it’s adversely affecting their mental health***

- That is a powerful piece of evidence
- Anna focuses on on young people because when you think about a policy intervention, we’re thinking about how to direct that to young people
- We also have a lot of observational evidence that is showing many of the [Bradford Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria), starting with a **dose dependent response** [#5 in the figure below]
  - We know that the more time that people spend on social media, the more likely they are to experience anxiety, depression, insomnia, and attention, etc.

![](https://peterattiamd.com/wp-content/uploads/2024/10/f6-annalembke.png)

**Figure 6. The Bradford Hill criteria**. Summarized from: [*European Journal of Epidemiology* 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8206235/)

- Now, you could argue chicken and the egg: maybe those were individuals who were vulnerable or already had depression anxiety, which made them want to self-medicate by using more social media
- Anna thinks the strongest evidence against that is the evidence that we have on another Bradford Hill criteria, which is **experimentation**
  - When we intervene in these cases of depressed and anxious individuals and take social media away for a period of time, or even limit use, people are feeling less depressed and anxious; and that is a very powerful piece of evidence
- Another Bradford Hill criteria is **biological plausibility**: does it even make biological sense that engaging with social media could change the brain in ways that are potentially harmful and beneficial?
  - Sure. That’s the organ that we’re using to consume social media, so it’s completely biologically plausible
  - We also know that when people are doing activities that engage in, for example, social validation, that releases dopamine in the brain’s reward pathway
  - And what is social media if not a slot machine for validation?
- You have **strength of association**
  - Yes, these are correlative phenomenon, but study after study show similar findings
  - Yes, there are exceptions, but in general, powerful studies show the strength of association
- And then you have **temporality,** meaning that which comes first
  - Are people using social media a lot and then get depressed and anxious, depressed and anxious, and then using social media?
    - Our natural retrospective scope will want to rationalize and explain certain irrational behaviors
  - We can often get pretty good reports of temporality subjectively in an individual clinical case, but also epidemiologically, and this is [Jonathan Haidt’s](https://jonathanhaidt.com/) work
    - He’s [saying](https://www.amazon.com/Anxious-Generation-Rewiring-Childhood-Epidemic/dp/0593655036/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.pLA6Rb-vSM6-wdPqDulw2K5ILrcN6OGLECqt7jVfs_b9v5bG7su5i2kcZexjOqy9V1GTaZE5fTDKSXx6L_rqyGTccLCBZILDR1XIAKuhTIGNfhbUxdr-o1c93LyZkhI98D2wtDtrcec6osK58yOlILw3r0Zc3zlhOILlVC1lYkd4f-qU0Hmy1TnPo_yS8RNasvTnWrtxpF0CZaEGR2drW2PiQ2IwatUD7-9SCB5BVKE.JIihCznpYfby3m9Wfz1eBg2I1y28wA20VBEfS5tbSxU&qid=1721314717&sr=8-1), if you look at when social media became widely available on college campuses, it didn’t happen uniformly
    - Some college campuses got social media up and running much earlier than others
    - And you see on those campuses where it was widely available and used, worse mental health outcomes

***The weight of the evidence makes it more likely than not that social media is causing mental health harms, especially in youth***

**What can parents do**

- It shouldn’t be solely up to parents; parents need help
- Schools need to get smartphones out of the schools so that adolescents can actually have the liberty and freedom to concentrate on learning
  - Because these devices, the way that they hijack the reward system, make it almost impossible for children to learn, and almost impossible for teachers to teach

*Analogize to alcohol*

- We have lots of laws that limit a child’s access to alcohol
- The drinking age of 21 is universal in every state now. Why?
  - Because federal funding for highways are tied to drinking age limits, and people wanted those dollars to build their highways
- We should be doing that: we should be offering federal and state funding to schools that actually make sure that from the top down kids are not looking at their smartphones
  - And that they have some tech-free spaces
  - And some opportunities for both socializing and learning that don’t rely on the internet and technology

*What are we hearing from schools?*

- Mostly private schools that are eliminating smartphones
- The schools are noisy again because kids are actually interacting with each other

*Anna’s summary*

- Lots and lots of empirical evidence that’s also consistent with our intuition that there’s a problem here, and we need to do something about it
- Which isn’t the same thing as saying social media is bad and nobody should be on social media, and it’s all evil, and it’s the devil
- The way that the algorithms learn what we’ve done before making these media so potently addictive
- You only have to walk through an airport to see the ways in which we’ve all stopped engaging with our surroundings

## How exercise affects brain chemistry, the role of dopamine and endorphins, and how exercise can become addictive [1:44:00]

**Start with the brain chemistry of exercise, what exactly is an endorphin?**

*Is this really boiled down to dopamine again?*

- Yes and yes
- [Endorphin](https://en.wikipedia.org/wiki/Endorphins) is an endogenous opioid
- We make our own opioids, otherwise we wouldn’t be able to cope with physical pain
- Exercise is actually immediately toxic to cells
  - Strange. Why would something that is toxic to cells be ultimately healthy for us?
- And the evidence is overwhelming that exercise in moderation, depending upon that person’s fitness level, is healthy

***Essentially what’s happening is that as the body senses injury, we up-regulate production of our own feel-good neurotransmitters like dopamine, but also serotonin, norepinephrine, and endogenous opioids (that’s the runner’s high)***

- If you look back at this metaphor of the pleasure, pain, balance, we saw that when we press on the pleasure side, the gremlins of a neuro-adaptation hop on the pain side, as a way to bring us in balance

![](https://peterattiamd.com/wp-content/uploads/2024/10/f7-annalembke.png)

**Figure 7. Metaphorical representation of how our brains balance pleasure and pain whereby pushing on the pleasure side causes gremlins to hop on the pain side**. Image credit: [*Dopamine Nation*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1)

- Ultimately, again, the same thing happens with painful stimuli

> “*When we do things intentionally that are physically or mentally challenging for us, our body senses injury, up regulates feel good neurotransmitters, and those gremlins actually go over and hop on the pleasure side, so we get our dopamine indirectly by paying for it upfront.*”‒ Anna Lembke

![](https://peterattiamd.com/wp-content/uploads/2024/10/f8-annalembke.png)

**Figure 8. Metaphorical representation of how our brains balance pleasure and pain whereby pushing on the pain side causes gremlins to hop on the pleasure side**. Image credit: [*Dopamine Nation*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1)

**Cold-water immersion**

- For example, [studies](https://pubmed.ncbi.nlm.nih.gov/10751106/) that have looked at ice-cold water immersion, noted that dopamine levels rise gradually over the latter half of the immersive ice-cold water bath
  - And then interestingly, those dopamine levels and serotonin and norepinephrine stay elevated for hours afterwards, before going back down to the baseline levels of dopamine firing
- Which is amazing because what that says is we never go into that dopamine deficit state

***We get our dopamine indirectly by paying for it upfront, and that process is relatively more immune to the problem of addiction because we had to work first to get it. Whereas intoxicants caused that sudden upward spike of dopamine followed by dopamine freefall, that dopamine deficit state, that state of craving before going back to the level position.***

**Are there certain personalities that can get addicted to exercise?**

- Absolutely
- We do see this in clinical care, and we also see it in our culture
- We’ve also drugified exercise, made it more potent, made it possible to do it in more extreme conditions
- We’ve social mediafied it so that now people are comparing themselves not just to their immediate neighbor but to people all over the world
- We’ve quantified it down to the nth degree
  - We’re constantly measuring ourselves, our heartbeats, our breathing, our sleep
  - Many people actually get addicted to those numbers or quantifications now they’re pursuing a certain numerical outcome

***Dopamine is probably ultimately quite sensitive to numerification***

**Intervention for an exercise addiction**

- We intervene similar to the way that we intervene for other addictions: we ask people to abstain from that particular exercise for a period of time
  - Try to reset reward pathways, and then when they go back to using, using in a way that’s not harmful or self or other destructive

## Cold-water immersion for mood regulation, and other healthy coping strategies [1:47:15]

- Both exercise and cold are healthy ways (for the most part) to experience pleasure because the pain comes first and you have to do the work to get the pain to experience the pleasure

**Anna writes in her book about a fellow who maybe took the cold plunge a little too extreme**

- Anna agrees, it was the lesser of 2 evils, because ultimately this became a well-adapted coping mechanism to an otherwise maladaptive addiction
- This was an individual addicted to alcohol and cocaine who got into recovery, experienced a lot of [dysphoria](https://en.wikipedia.org/wiki/Dysphoria) and discovered that taking an ice-cold shower in the morning (that was recommended to him by a trainer) actually made him high
  - It gave him the kind of response that he often got from drugs
  - So he began doing daily ice-cold shower and then over time got himself a cooler and would submerse himself in ever colder temperatures
    - And then he got a motor to circulate the water, so he was breaking the ice off in the morning
- At some point he realized that his tendency to take things to an extreme may be operating here

***Ultimately this was a healthy coping strategy***

**This really speaks to what is a healthy coping strategy**

- It’s something that we also do with other people
  - He started doing it with his family, with social groups
  - People would come over for ice-cold water bath parties ‒ much better than having people over to snort some lines or whatever the case may be
- Anna has lots of patients who when they get into recovery from drugs and alcohol will often discover **sports and endurance athletes** in order so that they can still have that striving and that goal and the endorphins
- We just have to make sure they don’t continue to do it to the point of personal injury

**Peter discovered something about cold-water immersion several years ago**

- If he took an ice-cold shower when he was very upset/ angry, the mood would reverse quite quickly
- He attributed that to stimulation of the vagus nerve
- His head had to be immersed in cold water
  - Presumably, even dipping his head in cold water, stimulating the diving reflex

***He enjoys a cold-plunge, enjoys sharing that experience ‒ it’s an absolutely mood lifting experience***

- People ask him all the time, “*Is cold-plunging an elixir of longevity?*”
- Having looked at the data very carefully, he can say that the answer appears unlikely [discussed in a [newsletter](https://peterattiamd.com/sauna-facts-myths-and-how-to/) earlier this year]
- He sees no evidence that cold immersion alters any of the hallmarks of aging, with the one possible exception being a reduction in inflammation
- But that’s never translated to a clinical benefit vis-a-vis disease, in the way he thinks there is benefit to sauna

*If you look at the sauna literature and run that same Bradford Hill criteria along with the experimental data*

- There really is probably causality between the benefits of sauna and disease prevention
- Peter doesn’t see that with cold
- His use of cold-water immersion personally stems from the mood elevation he experiences afterwards
  - He doesn’t think it has any ability to reduce the risk of cancer, heart disease, or dementia

***Anna thinks cold-water plunges are good in terms of a mood modulator and a replacement behavior***

> “*Ultimately we are strivers, we want to experience intense emotions, and it’s not that we can just not have goals and not have emotions. We want that intensity and certainly many of my patients have reported similar types of positive responses to ice-cold water plunges.*”‒ Anna Lembke

**Peter doesn’t notice the same effects with sauna (with extreme heat)**

- It’s a different sensation that he also enjoys greatly

Peter asks, “*I’m curious, do you think that there’s something about cold that produces more pain?*”

- Anna doesn’t think we know
- She thinks the immediate response is going to be some kind of hormetic response
  - **Hormesis** being this Greek term that means to set in motion, setting into motion our own regulatory healing response in response to injury
  - And the branch of science called hormesis is looking at the ways in which toxic or noxious stimuli actually makes us more resilient over the long run
- We see this being beneficial not just in people struggling with addiction or looking for alternative sources of dopamine, but also when people get immediately dysregulated
  - Peter noted that when he gets angry, it’s helpful

**Anna explains, “*****When we have patients who are very dysregulated, overwhelmed by their emotions, [and] can’t re-regulate, we say, ‘Stick your face in an ice-cold water bath. Plunge your hands in an ice-cold water bath,’ and it really, really works for some people.*****”**

- There’s also interesting work looking at cold more broadly and what it does to neurons, and it turns out that cold is one of the most potent stimuli for neurogenesis

**People look at this concept of drug of choice**

- For example, cold does absolutely nothing for Anna
  - She doesn’t enjoy the experience, but also she doesn’t get benefit afterward
    - She wishes she did because it’s an easily accessible tool
  - But for many people, it’s very potent

## The “marshmallow experiment”: how broken promises affect behavior and trustworthy environments helps children develop self-control [1:54:00]

- Anna [writes](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1) about a very famous experiment that everyone listening to this has heard, which is the marshmallow experiment
- Most of us who are parents did the marshmallow experiment on our kids, with the real hope that they would be able to refrain from eating the marshmallow because of how we believe it might predict better success later in life
- But Anna also writes about a revised version of that experiment, which Peter thinks is a little more interesting

**Explain both the original experiment and the revised version; and above all else, what that tells us about being parents**

- The [original marshmallow experiment](https://www.semanticscholar.org/paper/Attention-in-delay-of-gratification.-Mischel-Ebbesen/29346b98f0947a822b8744f4792bcf1a297f01d3) was conducted at Stanford and it looked at kids between about the age of 2-5
  - The child was placed in a room with nothing in the room except for a table, a chair, a little plate, and on that plate, a single marshmallow
  - The researcher said to the child, “*I’m going to leave the room and I’ll be back in 15 minutes. If you can go the whole 15 minutes without eating this marshmallow, when I come back, I will give you a second marshmallow so you’ll get two.*”
  - The whole point of it was to really measure delayed gratification and a child’s ability to delay gratification

***The most significant finding was very simply that older children were better able to delay gratification than younger children ‒ that this is a skill or a capacity that children will develop with age***

- But even within a single age cohort, there were differences
  - Some children were better able than others to wait the full 15 minutes, or just wait longer before eating that first marshmallow
  - And what they then was followed those kids prospectively, in some cases all the way through college and later, and looked at their life outcomes
    - And this part of the study is a little bit controversial
  - The claim was that the kids who, within their age cohort, were able to wait longer for the marshmallow (i.e. delay gratification) were also more likely to graduate high school, graduate college and go on to have successful lives, so to speak
- The variance on the marshmallow experiment was that they decided to do [another version](https://depts.washington.edu/shodalab/wordpress/wp-content/uploads/2015/05/1990.PredictingAdolescent_Shoda.pdf) in which they divided the groups of kids into 2 groups, and in addition to the plate and the marshmallow, there was also a bell that they could ring
  - They told one group, “*If at any point in these 15 minutes you’d like me to return for any reason, just ring this bell and I’ll come back*.”
    - They told that to both of those groups
  - But in one group, when the child rang the bell, the researcher came back and in the other group when the child rang the bell, the researcher didn’t come back until the full 15 minutes were over
  - In other words, one group of children was told the truth and another group of children was lied to

***What they*** [***discovered***](https://depts.washington.edu/shodalab/wordpress/wp-content/uploads/2015/05/1990.PredictingAdolescent_Shoda.pdf) ***was that the children who were lied to were much more likely to eat that marshmallow before the full 15 minutes were up***

*Anna’s takeaway: It’s such a powerful paradigm for the importance of truth-telling*

- Not only to teach our kids the importance of telling the truth, but to model that for our kids and actually be truthful and show up when we said we were going to show up
- Because it looks like what happens when we’re living in an environment where people cannot rely on other people around them, especially adult caregivers to do what they said they were going to do, that we essentially go into a **survival mode**
  - Where we just feel like nobody’s going to take care of me; I got to take care of myself
  - I better eat this marshmallow now because if they’re not going to come back in the room, maybe they’re also not going to bring me a second marshmallow if I wait the full 15 minutes
- That [unreliability/ lying] can really breed within a family dynamic, a very toxic interpersonal family system that does increase the risk of addictive behaviors later on

***What we’ll often see in patients with severe addiction is, not only that they had a parent or caregiver who was addicted, but that they lived in a house where lying was rampant***

- Where people almost never showed up when they said they were going to show up, never did what they said they were going to do

> “*It’s very interesting to me how something like telling the truth can be such a powerful shaper of repetitive control*.”‒ Anna Lembke

## Can GLP-1 agonists be useful in treating addiction? [1:58:30]

**Alcoholism in people who have undergone gastric bypass surgery**

- Speaking of repetitive control, in her [book](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1), Anna notes how individuals who have had gastric bypass are prone to higher rates of alcoholism
  - This surgery is quite successful in curbing appetite and ultimately food consumption
  - Therefore, it’s a great tool for managing obesity and type 2 diabetes

*Can you say a little more about that?*

- About a quarter of individuals undergoing gastric bypass for obesity, which you might conceptualize as food addiction in certain vulnerable individuals, will go on to develop an alcohol use disorder after their gastric bypass
- And that’s probably operating on multiple levels
- One level on which it’s operating is that alcohol becomes immediately a much more potent drug for them because, through the gastric bypass, they essentially have a dumping syndrome where they get the equivalent of many more drinks because it immediately goes into the duodenum and is absorbed
  - They get where they can have one drink and immediately feel their effects
  - And part of potency is not just how much dopamine it’s released but how quickly it’s released, which is why for example, injecting is so potentially addictive because basically right to the brain
  - So alcohol becomes a very potent drug for them
- But also because of the problem of cross addiction where when people give up one addictive substance or behavior, they are vulnerable to switch that addictive tendency over to another substance or behavior
  - Unless we’re directly addressing the problem of the behavioral addiction itself, at the same time that we’re addressing the obesity and doing the bypass surgery, folks are going to be vulnerable to that

**What has been your experience clinically with the significant increase we’ve seen in the use of** [**GLP-1 agonists**](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) **and the expansion in use from type 2 diabetes, to obesity, to overweight, to basically anybody?**

- Peter points out there have been lots of reports that GLP-1 agonists not only curb appetite, but may also curb desire and maybe even pleasure
- And that would suggest that unlike a gastric bypass, an individual who uses a GLP-1 agonist to achieve their weight loss goals might also have another benefit in that it might curb other maladaptive behaviors such as alcohol consumption
- These are really fascinating drugs and what Anna is seeing clinically is individuals with food addiction and individuals with alcohol addiction where we have experimented off-label with [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) are those where we have tried almost everything to get their addiction under control
  - Alcohol use disorder is closely linked to food addiction because alcohol is caloric, so we’ve got both mediated through the carbohydrate system
- We have more experience with **treatment refractory alcohol use disorder**, including trying medications, medications like [baclofen](https://en.wikipedia.org/wiki/Baclofen), medications like [naltrexone](https://en.wikipedia.org/wiki/Naltrexone)

Peter asks, “*Baclofen (the muscle relaxant) is used to treat alcohol disorder?*”

- There are more placebo controlled trials in Europe than here in the US
- It’s not FDA-approved for that indication
- It’s not first line for us, but we will sometimes use baclofen, sometimes we will use [gabapentin](https://en.wikipedia.org/wiki/Gabapentin)

*What doses of baclofen and gabapentin are necessary to produce that effect?*

- Anna is using less gabapentin than she used to because she’s been seeing people actually get physically dependent and in some cases addicted to gabapentin
- Typically we’ll use the 600 mg, 3X a day to help people withdraw from alcohol
  - And in some cases, maintenance, although less of that
- She don’t use baclofen often enough to remember what the dose is
- More often we’re using [naltrexone](https://en.wikipedia.org/wiki/Naltrexone) (the opioid receptor blocker) which can be very nice because many people’s goal is moderation, not just abstinence and naltrexone been shown to help not just with abstinence, but also reducing drinks on drinking days
  - We use that almost as first line
- We use [Antabuse (disulfiram)](https://en.wikipedia.org/wiki/Disulfiram) which is the one that’s a deterrent
  - If you drink on it, you’ll get sick
  - People don’t usually like to go to that first line, but it works when people take it
  - Peter points out that if patients do use that and drink through it, they are actually increasing the toxicity of alcohol gram for gram because they’re experiencing more acetaldehyde, which is obviously the toxic mediator
  - Anna agrees, you really have to be careful who you prescribe it to, and it has to be somebody who can really be committed to not drinking once they’ve taken that medication
- She also uses [topiramate](https://en.wikipedia.org/wiki/Topiramate) (which is a seizure medication) which was first discovered off-label to be helpful for binge-eating disorder, and later was shown to be helpful for alcohol use disorder

Anna explains, “*The bottom line is when we have a case of a patient who has tried these various medications, who’s been involved in Alcoholics Anonymous, who’s tried psychotherapy, who’s gone to rehab, who’s done it all, in that rare instance, because it is off-label and because it’s so new, and so we are conservative with medications, we have occasionally recommended semaglutide or the GLP-1 drugs.*”

***In one case in particular, it was very striking the extent to which this individual with treatment refractory alcohol use disorder endorsed the complete cessation of alcohol craving, with*** [***semaglutide***](https://en.wikipedia.org/wiki/Semaglutide)

- And it’s very moving to see that in an individual who has struggled so long and so hard to battle their addiction, there’s this drug that seems to just suddenly turn off all the noise for them

Peter asks, “*Was that patient at all overweight?*”

- Yes, and that’s how we could justify it
  - We were giving it to him for being overweight and being at risk for type 2 diabetes
- But our real agenda was the alcohol and it worked very well for that

**Do you think that will ever be able to explore, in a rigorous scientific way, the question of whether or not independent of weight, GLP-1 agonists might be tools to help people with addictions more broadly?**

*Beginning with alcohol before we talk about other substances*

- Small trials are already underway and showing some effect
- Anna would not be at all surprised if in 5 to 10 years semaglutide is FDA approved for alcohol use disorder
- It might not happen because the company doesn’t need it and it’s expensive to get those FDA approvals
  - And there’s no shortage of demand for semaglutide, so they may never pursue that FDA indication
- She thinks that it will be used more and more often for alcohol use disorder in particular, and binge-eating disorder

## The benefits of 12-step programs [2:06:00]

- Peter thinks Anna did the best job he’s ever encountered of [describing 12-step programs](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1)
- People tend to have very polarizing views about them
  - It ranges from thinking everybody should be in a 12-step program to people who say, “*It’s a cult*”
- Anna covered both sides of this and landed in a very reasonable position: this type of program is favorable for a given individual, but maybe not for all individuals
- Peter has been to many meetings himself and always found the sharing amazing
  - This is something Anna described as pro-social shame

**Say a little more about 12-step programs: how it helps those who are struggling with addiction, what pro-social shame means and why it’s an important part of recovery**

- 12-step groups are not a treatment per se; they’re not professionally led
- These are peer recovery groups where people are helping other people struggling with the same problem, and they intentionally issue affiliation with any kind of political agenda
- There’s no fee structure; they don’t involve themselves in money
- All of that is incredibly wise, recognizing that we humans are so vulnerable to mismanaging and asserting our own agendas in these kinds of endeavors, and so to keep it free and accessible and everywhere
  - That makes the bar for admission much, much lower, which increases access

***Even if you’re talking about an effect size that may not be as large as some kind of professional mediated treatment, the simple fact that it’s free and it’s in every church or synagogue basement in the world, or community center equivalent, makes it already a very potent intervention***

*It’s also important to acknowledge that for people with more extreme forms of addiction, that the 12-step groups may work even better than individual or group psychotherapy that’s professionally led*

- Anna refers folks to the [Cochrane Review](https://pubmed.ncbi.nlm.nih.gov/32159228/) by John Kelly and Keith Humphreys and co-authors that really reviews the evidence and clearly shows that 12-step programs are an effective intervention for people who actively participate
- For reasons that Anna doesn’t entirely understand, the press and the media and the culture has been very 12-step bashing of late
- She thinks it’s important not to force people to go to 12-step or to say that’s the only way to do it
- You don’t want to also then malign or get rid of something that’s clearly very effective

*Why does 12-step work when it does work?*

- One of the main sources of efficacy is easy access, low bar for participation, and it may be one of the few places left in modern society where people can show up and be their fully flawed and broken selves, and be entirely accepted for that
  - Not just accepted, but where our brokenness becomes a positive social good
- This may not be true anymore in faith-based organizations where people are sometimes get so caught up in proving the bounties of believing that they are then loathe or reluctant or even discourage from disclosing the ways in which their life is not working out

*Anecdote on the benefits of 12-step meetings instead of faith-based meetings*

- Anna has a very good friend who’s a theologian and a devout Christian who, of late, has stopped going to his church and instead is going to 12-step meetings
- He does not in fact have an addiction, but he gets so much nourishment from this coming together of people who can talk freely about their mess-ups and their greed and their mistakes that they’ve made and their shameful, guilt-ridden, types of behaviors and come out the other side feeling better for it, less ashamed, more motivated to change those behaviors

*The whole sponsorship program is so powerful where you get a sponsor, you work the steps*

- People can call their sponsors any time of the day, any day of the week
- You can’t do that with Anna
  - If you call her at midnight on a Saturday, she’s not going to get that message till Monday, and depending upon the clinical acuity, she might not return that call till Tuesday
- That’s not true for a sponsor: you can call a sponsor in the middle of the night and that sponsorship bond, that person might even come over to your house

***It’s just a very remarkable social movement, it’s incredibly potent and powerful***

- It’s definitely not for everybody, especially in a world that is, in general, conspiring against our mental health

## Why understanding a patient’s story is essential for meaningful psychiatric care [2:11:45]

**Listening to the story of a person rather than coming up with the DSM-5 code**

- Anna wrote about something that reminded Peter of his close friend, [Paul Conti](https://drpaulconti.com/)
  - Paul always talks about the patient’s story
- Anna wrote about how we’ve pathologized mental health so much, down to history of present illness, review of systems
- She talked about her own journey as a psychiatrist and her evolution away from the traditional training where, at the end of the day, you’ve got to come up with the DSM-5 code (you have to be able to come up with a label)
  - You’re interacting with a person and you’re in the mode of, what’s the label? What’s the diagnosis?
- She talked about how she now teaches residents to put that aside and listen to the story of the person

*What is it in your journey that led you there and how difficult or how easy is it to be training other psychiatrists in that school of thinking?*

- What immediately comes to her mind is going to sound super selfish: ***it was the realization that she was not engaged or interested in this person***
- She could not capture her own empathy for them unless she knew the story, the “mini-autobiography” of their lives
  - What had transpired in their early life?
  - What were the major milestones?
  - How did they end up where they are today?
  - Who was in their life?
  - What were the major influences?

*Narrative is so powerful, as you know, our brains are wired for story*

- Our prefrontal cortex is activated when we listen to narrative
- We learn through narrative
- [Foucault](https://en.wikipedia.org/wiki/Michel_Foucault) said something like, “*Narrative is the only way we can measure lived time,*” which is really powerful and it’s also one of the primary ways to get at causality
- Of course, we can tell ourselves stories that aren’t true and come up with causal relationships that aren’t based in fact
- But when we’re telling true stories, it is the way that we understand what led to what, led to what
  - It’s also just much more interesting and more fun
- That’s the data and Anna sees that as a psychiatrist’s job
  - The cardiologist gets the EKG, the surgeon’s cutting and sewing, and psychiatrists deal in story
- When we have new addiction medicine fellows, they come from many different specialties
  - We have family medicine doctors, emergency medicine doctors, pediatricians, psychiatrists
- And it’s so hard for them to let go of that structured categorization: chief complaint, history of present illness, past medical history
- Anna *tells them, “Trust me on this. Trust me. Start with their story.”*
- Say, “*Tell me the story of your life, where you were born, who raised you, what you were like as a kid, made your milestones, memories that you remember that were impactful, important.*”
  - All the way up into the present day, “*Who do you live with? Who are the important people in your life? What do you care about? What are your goals and dreams?*”

***If we don’t do that, we end up with a laundry list of symptoms that is not actually a person***

**What about the patients who don’t recover?**

Peter asks, “*When you think back over your career, you’ve written about what are undoubtedly a lot of the amazing success stories, people who seemed on the brink of death in some cases, and if not death, outright destruction of their lives and relationships. But I have to imagine that there’s a graveyard too of people that you haven’t been able to help. How have you coped with that?*”

- This is a great question and it’s very timely
  - Anna had clinic yesterday and had an interaction with a patient that was not good: the patient was very angry at her
- The key for Anna is to **stay curious**, to just continue to wonder about this person, what shaped them, what their motives might be, and how all of that might inform how we can help them, so to stay in this **empathic** professional stance
- She explains, “*To look at myself, if a patient criticizes me or the treatment, what is potentially correct about that? How have I messed up? How can I make amends? So really trying to walk a path of humility*.”
- The longer she’s practiced psychiatry, the less she thinks she actually understands about the brain and how people change (in some ways)

***At some really core level, it is a great mystery, so just trying to stay humble and curious and empathic, and then also go home and forget about it for a while and make sure she take care of herself and her family***

*When you lose a patient, is that something where you’ve accepted the fact that that’s going to happen, but being attached to that patient and suffering the pain of their loss, is the price you pay to be a better doctor, or is there a way to create a boundary and never let yourself hurt in that situation?*

- One of Anna’s early mentors and supervisors said something to her that’s she’ll never forget
- He said, “*Anna, the reason that the work that we do works when it does work is because we actually love our patients and the emotions are real. We have to come to the therapeutic encounter with our own physical, mental, sexual needs met so that we are there 100% for the patient’s needs, but the emotions are real, the relationship is real. We have to care about these folks.*”

***She thinks that is deep truism, and when a patient dies, it is devastating, and the guilt is enormous***

- The “what ifs”: if only I had done that, if only we had been more present or more proactive, or whatever it is, you can’t get away from that

§

## Selected Links / Related Material

**Anna’s book**: [Dopamine Nation: Finding Balance in the Age of Indulgence](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1) by Anna Lembke (2021) | [1:15, 35:15, 42:45, 1:14:30, 1:22:30, 1:47:30, 1:54:00, 2:06:00]

**Epidemiological studies find increased all-cause mortality in heavy drinkers**: [Association Between Daily Alcohol Intake and Risk of All-Cause Mortality: A Systematic Review and Meta-analyses](https://pubmed.ncbi.nlm.nih.gov/37000449/) | *JAMA Network Open* (J Zhao et al 2023) | 19:15]

**Brain imaging of dopamine levels in gamblers’**: [Dopamine release in ventral striatum of pathological gamblers losing money](https://pubmed.ncbi.nlm.nih.gov/20712823/) | *Acta psychiatricia Scandinavica* (J Linnet et al 2010) | [1:15:15]

**Episode of** ***The Drive*** **with Anthony Hipolito**: [#243 ‒ The fentanyl crisis and why everyone should be paying attention | Anthony Hipolito](https://peterattiamd.com/anthonyhipolito/) (February 20, 2023) | [1:30:00]

**Jonathan Haidt’s book on social media**: [The Anxious Generation: How the Great Rewiring of Childhood Is Causing an Epidemic of Mental Illness](https://www.amazon.com/Anxious-Generation-Rewiring-Childhood-Epidemic/dp/0593655036/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.pLA6Rb-vSM6-wdPqDulw2K5ILrcN6OGLECqt7jVfs_b9v5bG7su5i2kcZexjOqy9V1GTaZE5fTDKSXx6L_rqyGTccLCBZILDR1XIAKuhTIGNfhbUxdr-o1c93LyZkhI98D2wtDtrcec6osK58yOlILw3r0Zc3zlhOILlVC1lYkd4f-qU0Hmy1TnPo_yS8RNasvTnWrtxpF0CZaEGR2drW2PiQ2IwatUD7-9SCB5BVKE.JIihCznpYfby3m9Wfz1eBg2I1y28wA20VBEfS5tbSxU&qid=1721314717&sr=8-1) by Jonathan Haidt (2024) | [1:34:45, 1:41:30]

**Dopamine release after cold water immersion**: [Human physiological responses to immersion into water of different temperatures](https://pubmed.ncbi.nlm.nih.gov/10751106/) | *European Journal of Applied Physiology* (P Šrámek et al 2000) | [1:45:30]

**Newsletter about the use of saunas**: [Saunas: the facts, the myths, and the how-to](https://peterattiamd.com/sauna-facts-myths-and-how-to/) | PeterAttiaMD.com (E Donahue, K Birkenbach, P Attia 2024) | [1:48:00]

**Original marshmallow experiment**: [Attention in delay of gratification](https://www.semanticscholar.org/paper/Attention-in-delay-of-gratification.-Mischel-Ebbesen/29346b98f0947a822b8744f4792bcf1a297f01d3) | *Journal of Personality and Social Psychology* (W Mischel, E Ebbesen 1970) | [1:54:45]

**Revised marshmallow experiment**: [Predicting Adolescent Cognitive and Self-Regulatory Competencies From Preschool Delay of Gratification: Identifying Diagnostic Conditions](https://depts.washington.edu/shodalab/wordpress/wp-content/uploads/2015/05/1990.PredictingAdolescent_Shoda.pdf) | *Developmental Psychology* ( Y Shoda, W Mischel, P Peake, 1990) | [1:56:15]

**Cochrane review of 12-step programs**: [Alcoholics Anonymous and other 12-step programs for alcohol use disorder](https://pubmed.ncbi.nlm.nih.gov/32159228/) | *Cochrane Database of Systematic Reviews* (J Kelly, K Humphreys, M Ferri 2020) | [2:09:00]

§

## People Mentioned

- [Thomas Finucane](https://biography.omicsonline.org/united-states-of-america/johns-hopkins-university/thomas-finucane-262940) ([Professor Emeritus](https://pure.johnshopkins.edu/en/persons/thomas-finucane) in the School of Medicine at Johns Hopkins University) [36:15]
- [Bill Maher](https://en.wikipedia.org/wiki/Bill_Maher) (comedian and political commentator) [1:23:30]
- [Anthony Hipolito](https://www.hipolitoforsheriff.com/about) (Law enforcement officer in the Hays County Sheriff’s office who works in the community outreach division, formerly a Sergeant in the Austin police department) [1:30:00]
- [Jonathan Haidt](https://jonathanhaidt.com/) (Social psychologist at New York University’s Stern School of Business and best-selling author) [1:35:00, 1:41:30]
- [Paul Conti](https://drpaulconti.com/) (psychiatrist who specializes in trauma and author of *Trauma: The Invisible Epidemic*) [2:11:45]
- [Michel Foucault](https://en.wikipedia.org/wiki/Michel_Foucault) (1926-1984, French historian of ideas and philosopher who focused on the relationships between power versus knowledge and liberty and how they are used for social control) [2:13:30]

§

![](https://peterattiamd.com/wp-content/uploads/2024/10/bio-image-annalembke-500x500.png)

##### Anna Lembke, M.D.

Dr. Anna Lembke received her undergraduate degree in Humanities from Yale University and her medical degree from Stanford University. She is currently Professor and Medical Director of Addiction Medicine at Stanford University School of Medicine. She is also Program Director of the Stanford Addiction Medicine Fellowship, Chief of the Stanford Addiction Medicine Dual Diagnosis Clinic, and a diplomate of the American Board of Psychiatry and Neurology and the American Board of Addiction Medicine.

A clinician scholar, Dr. Lembke has published more than a hundred peer-reviewed papers, book chapters, and commentaries. She has developed multiple teaching programs on addiction and safe prescribing, as well as opioid tapering. In 2016, she published [*Drug Dealer, MD – How Doctors Were Duped, Patients Got Hooked, and Why It’s So Hard to Stop*](https://www.amazon.com/Drug-Dealer-MD-Doctors-Patients/dp/1421421402/ref=sr_1_1?crid=FCIIY0ZJP0RX&dib=eyJ2IjoiMSJ9.l0B0riJInZ0i1VgXO4pQFw.AF1CPAKQSp_hb-xgDDZb8xjBcOkxw_UzuXN0eO9EAGE&dib_tag=se&keywords=Drug+Dealer%2C+MD+%E2%80%93+How+Doctors+Were+Duped%2C+Patients+Got+Hooked%2C+and+Why+It%E2%80%99s+So+Hard+to+Stop&qid=1721239179&sprefix=drug+dealer%2C+md+how+doctors+were+duped%2C+patients+got+hooked%2C+and+why+it+s+so+hard+to+stop%2Caps%2C87&sr=8-1), which was highlighted in the New York Times as one of the top five books to read to understand the opioid epidemic. Her most recent book and New York Times bestseller is, [*Dopamine Nation: Finding Balance in the Age of Indulgence*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1). It combines the neuroscience of addiction with the wisdom of recovery to explore the problem of compulsive overconsumption in a dopamine-overloaded world. [[Stanford](https://profiles.stanford.edu/anna-lembke)]