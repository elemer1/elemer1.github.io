# #18 – Richard Isaacson, M.D.: Alzheimer’s prevention

**Source:** [https://peterattiamd.com/richardisaacson/](https://peterattiamd.com/richardisaacson/)

---

##### Check out more content with neurologist, Richard Isaacson, M.D.:

- *(Oct 1, 2018)* [#18 – Richard Isaacson, M.D.: Alzheimer’s prevention](/richardisaacson/)
- *(Nov 22, 2020)* [Q&A on Alzheimer’s disease drug therapy with Dr. Richard Isaacson](/qa-with-dr-richard-isaacson-on-aducanumab-alzheimers-disease-drug-therapy/)
- *(Nov 23, 2020)* [#138 – Lauren Miller Rogen and Richard Isaacson, M.D.: Alzheimer’s disease prevention—patient and doctor perspectives](/laurenmillerrogen-richardisaacson/)

In this episode, Richard Isaacson, a neurologist and director of the Alzheimer’s Prevention Clinic at Weill Cornell Medicine and New York-Presbyterian, discusses strategies for staving off Alzheimer’s disease. Richard shares a wealth of insight for people who want to know more about Alzheimer’s and what you can do to help yourself and your loved ones — starting today and continuing throughout the entire lifespan.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/richardisaacson/the_Drive_public.png)

Play

#18 - Richard Isaacson, M.D.: Alzheimer's prevention

1x15s30s

0:002:24:18

## We discuss:

- Richard’s fun-facts (and alter egos): “bling” phones, Doogie Howser, and DJ Rush [8:00];
- Richard’s impetus to focus on Alzheimer’s disease: Uncle Bob [18:20];
- Starting an Alzheimer’s Prevention Clinic [27:00];
- How Alzheimer’s is diagnosed [30:00];
- Short-term memory, processing speed, executive function, and how they’re tested [35:45];
- Prevention vs reduction of Alzheimer’s [44:00];
- What is the prevalence of Alzheimer’s in America? [49:30];
- How do people actually die from Alzheimer’s or dementia? [51:30];
- How can people do everything right and still get Alzheimer’s? It’s all about AGE [55:15];
- The *APOE* gene [58:15];
- Why is the risk of Alzheimer’s higher for women? [1:13:00];
- How many different paths lead to Alzheimer’s? [1:15:45];
- What role does *MTHFR* play in Alzheimer’s? [1:19:45];
- What are the “ABCs” of Alzheimer’s prevention? [1:26:45];
- Baptists, Tauists, Syners, and Apostates [1:36:30];
- Concerns with statin use for high-risk patients [1:45:00];
- The use of Theracurmin [1:48:45];
- What are the five actionable things one can do to reduce the risk for Alzheimer’s today? [1:54:30];
- The cognitive reserve [2:14:15]; and
- More.

§

## Show Notes

## Richard’s fun-facts (and alter egos): “bling” phones, Doogie Howser, and DJ Rush [8:00]

**Luxury vintage cell phones**

- Richard is an avid collector of luxury vintage cell phones
- Owns a [Vertu Constellation Quest](https://www.cnet.com/news/vertu-constellation-quest-the-blingtastic-17300-smart-phone/)
- Owned many different luxury vintage cell phones (Figures 1, 2-7)
- Phone features and accessories include (but not limited to): white alligator skin, sapphire keys, 18 karat gold trim, and a diamond “pillow”
- Richard shares some remarkable phone-related stories
- Peter actually collected old Blackberrys and Hewlett-Packard calculators

![](https://peterattiamd.com/wp-content/uploads/2018/09/white-diamond-alligator.jpg)

**Figure 1. Vertu Quest White Alligator Diamond.**

**Doogie Howser**

- Richard finished medical school at age 23, which is before Peter even entered med school
- Richard spent six years at the University of Missouri in Kansas City, getting his lab coat at age 17, and exposed himself to a ton of clinical medicine

**DJ Rush**

- Richard exchanged his Bar Mitzvah money for a recording studio
- Richard also made money as a computer tutor
- He knew he wanted to be a neurologist at an early age: he read [Neuroanatomy Made Easy and Understandable](https://www.amazon.com/Neuroanatomy-Made-Understandable-Michael-Liebman/dp/0834202026) during summer camp around 6th grade
- Richard’s brother is also a neurologist (and 13 years older than Richard)
- Richard’s band: [The Regenerates](https://www.facebook.com/TheRegenerates/): music for the right brain (Figures 2, 9)

![](https://peterattiamd.com/wp-content/uploads/2018/09/null-6.jpeg)

**Figure 2. The Regenerates (Richard’s band).**

## Richard’s impetus to focus on Alzheimer’s disease: Uncle Bob [18:20]

- Richard’s uncle was diagnosed with Alzheimer’s disease (AD) when Richard was in high school
- His uncle introduced Richard’s parents to each other
- His uncle also saved his life: at age three, Richard jumped into a pool, and sank to the bottom, when everyone was inside his Aunt’s house — Uncle Bob ran out, jumped in, and got Richard out of the pool
- Richard has always felt a connection to older people

![](https://peterattiamd.com/wp-content/uploads/2018/09/the-vertu-constellation-quest-ferrari-smartphone_100381190_m.jpg)

**Figure 3. Vertu Constellation Quest Ferrari.**

## Starting an Alzheimer’s Prevention Clinic [27:00]

- Richard spent time working in Miami, and came up with an extensive plan to treat his AD patients
- This turned into a book: [Alzheimer’s Treatment Alzheimer’s Prevention: A Patient and Family Guide](https://www.amazon.com/Alzheimers-Treatment-Prevention-Patient-Family/dp/0983186979/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1537891723&sr=1-4)
- Richard received flack for putting the word *Prevention* next to *Alzheimer’s Disease* (this would not be the last time he would receive such criticism)
- “The only way to prove in a rigorous way that multimodal interventions work, it’s patient education, lifestyle interventions, pharmacologic management, everything . . . is in a large academic medical center”
- Richard interviewed at Cornell to propose his plan for an Alzheimer’s Prevention Clinic
- He needed to sell the Dean on his idea in about 15 minutes
- During the interview, Richard said the Dean looked down at his CV, and back at him, and asks, “*How old are you?*” (He was 23 at the time)
- She may have been expecting to see someone in the Oliver Sacks mold, and instead, she’s looking across at Doogie Howser — nevertheless, she was sold

![](https://peterattiamd.com/wp-content/uploads/2018/09/004_Vertu-Vertu-Constellation-Quest-Carbon-Fibre.jpg)

**Figure 4. Vertu Constellation Quest: Carbon Fibre.**

## How Alzheimer’s is diagnosed [30:00]

- Alzheimer’s disease has traditionally been a clinical diagnosis
- This means you talk to a patient, you get a history of progressive, short-term memory loss
- When that memory loss and other cognitive changes (e.g., sleep trouble, behavior changes, depression, agitation) leads to a loss of the ability to perform activities of daily living (ADL), then the person has probable Alzheimer’s disease, dementia.
- “Common things happen commonly,” it’s going to be AD about 60-70% of the time, based on this type of diagnosis
- Upshot: when people have progressive short-term memory loss, and other cognitive changes, it’s probably Alzheimer’s, until proven otherwise
- Regarding imaging, Richard recommends an MRI, looking at vascular burden (about 35% of the time there’s vascular cognitive impairment alongside AD) and atrophy of the brain (especially the frontal lobes and hippocampus)
- Richard’s team can also look for amyloid (i.e., plaques) and tau protein (i.e., tangles) to get a definitive diagnosis of AD — the main reason they do that is if they think the patient is going to be a subject in a clinical trial
- With AD, you can make a clinical diagnosis, but the clinical diagnosis isn’t always correct: that’s why they use different biomarkers in certain situations

NOTE: Richard created a site, [Alzheimer’s Universe](https://www.alzu.org/), that provides extensive education on AD, and offers the most up-to-date information on Alzheimer’s prevention, treatment, and caregiving

![](https://peterattiamd.com/wp-content/uploads/2018/09/Vertu-Vertu-Constellation-Quest-Carbon-Fibre.jpg)

**Figure 5. Vertu Constellation Quest: Carbon Fibre.**

**Cognitive aging vs Alzheimer’s**

- Cognitive aging is different from AD
- When people get older, sometimes they forget things, they lose their keys
- You have a word on the tip of your tongue, but can’t get it out immediately
- But you remember that word later, and you find your keys later
- These are non-pathological changes associated with aging that don’t affect ADL

## Short-term memory, processing speed, executive function, and how they’re tested [35:45]

Regarding cognitive function, a few things to look at:

- Short-term memory
- Processing speed (i.e., attention)
- Executive function: higher order processing (i.e., judgment, planning)
- Language is important
- Learning is important
- If you can’t learn something, how can you remember it?
- Richard’s team tries to home in on exactly what cognitive domain is deficient

**The APC Battery**

- A little more than 50% is on the computer
- Also uses odor identification (i.e., scratch, sniff, identify the odor)
- Problem with most of the cognitive tests for AD: they’re scaled and validated to detect people with dementia
- They’re not sensitive to pick up people with early cognitive decline who don’t have dementia
- Richard’s team is trying to create an additional free cognitive assessment that is [online](https://www.alzu.org/)
- They have six versions of something called the face-name associated memory test (FNAME)
- Worked with Doreen Rentz to help us with this
- She [validated](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3137730/) that if you do poorly on an FNAME, it predicts amyloid in the brain

![](https://peterattiamd.com/wp-content/uploads/2018/09/Vertu-Constellation-Quest-Diamond-Black-Leather-7-600x600.jpg)

**Figure 6. Vertu Constellation Quest with a diamond pillow.**

## Prevention vs reduction of Alzheimer’s [44:00]

- There’s a big debate on which is the more accurate term: prevention or risk reduction?
- Richard’s group wrote a paper (not submitted yet): Prevention vs Alzheimer’s risk reduction: transcending semantics for clinical practice
- Richard argues there’s a big difference with important implications: when you say prevention, the patient sitting in front of you understands what that means — when you say risk reduction, what kind of message does that send? It’s confusing

## What is the prevalence of Alzheimer’s in America? [49:30]

- Anyone with a brain is at risk for AD
- Prevalence of AD is typically reported between 5-6 million Americans
- Probably around 4-5 million have AD dementia
- Up to 47 million Americans have preclinical AD, meaning they have AD in the brain, but no symptoms

![](https://peterattiamd.com/wp-content/uploads/2018/09/signature.jpg)

**Figure 7. The Vertu Signature S.**

## How do people actually die from Alzheimer’s or dementia? [51:30]

- Very few patients actually understand what it means to die from AD
- AD is an indirect cause of death
- For example, someone with AD gets a urinary tract infection, they’re unable to convey this to the appropriate people to get help, and it develops into a life-threatening condition (i.e., sepsis)
- People with AD are unable to report their pain
- AD is a life-course disease

## How can people do everything right and still get Alzheimer’s? It’s all about AGE [55:15]

- Richard uses a pneumonic called AGE: **A**ge, **G**enetics, **E**nvironment
- Epigenetics, your interaction between the environment and your genome, is going to put you on the path, or try to knock you off of the path, towards AD
- Some people can do everything right, but because of their *APOE* e4 gene, plus another gene, or because of their interaction with the environment, they’re going to get AD
- Other people can modify their environment, modify the impact of that gene on their outcomes, and it’s very reasonable to expect that one out of three cases of AD can be prevented
- Because if you can delay AD by several years by doing everything right in that subset, they’re going to probably die from something else

## The *APOE* gene [58:15]

The three major *APOE* alleles are:

- ApoE2 (ε2)
- ApoE3 (ε3)
- ApoE4 (ε4)

You inherit two copies, one from each parent, so you will effectively fall into the bucket of one of six combinations:

- ε2/ε2
- ε3/ε3
- ε4/ε4
- ε2/ε3
- ε2/ε4
- ε3/ε4

**Table 1. Estimated percentages (frequency) of the U.S. population with the six possible *APOE* pairs (Raber et al., 2004) and odds ratio for developing Alzheimer’s disease according to apolipoprotein E (*APOE*) genotype in Caucasians: clinic/autopsy studies (Farrer et al., 1997).** Adjusted for age and study. Odds ratio for *APOE* genotype derived assuming a reference odds ratio of 1 for *APOE* ε3/ε3 genotype.

![](https://peterattiamd.com/wp-content/uploads/2018/07/apoe-frequency-and-risk.jpg)

- Having two copies of e4 does not mean you’re going to get the disease
- It’s a polygenic risk when it comes to AD
- Richard doesn’t think you can use the risk estimates (Table 1) to put patients into buckets of risk: you can’t really know until you know what the other person’s genes are
- The person that walks into Richard’s clinic with an e3/e4, he’s actually more optimistic because he knows what he’s up against
- He knows lifestyle interventions work for these patients
- To get into Richard’s clinic, you must have normal cognitive function with a family history of AD
- The problem is actually when someone comes in with an e3/e3: here’s a person who has presumably a “normal” *APOE* genotype, but the person is at higher risk, and there is less certainty as to why
- Maybe the patient’s father had AD, and was an e3/e4 (and the patient inherited the e3)
- But maybe Mom and Dad were both e3/e3, so something else that Richard hasn’t pinpointed, he’s less confident about what he’s up against in terms of the patient’s risk
- The *TNF* gene is an example of polygenic risk: if you have a variant of this gene, and at least one copy of e4, there’s a six-fold greater associated risk ([rs1799724-T](https://www.snpedia.com/index.php/Rs1799724)) of AD: that’s polygenic risk — the *TNF* gene can lead to early onset AD
- The deterministic genes for AD: mutations of *PSEN1*, *PSEN2*, and *APP*
- Richard notes it’s very controversial, but he thinks that in some people, having a deterministic gene does not necessarily mean they will get the disease
- People who are born with *APOE* e4 begin life with a smaller brain
- *APOE* e4 + age = higher likelihood of amyloid
- Women + *APOE* e4 + age (65+) = much higher likelihood of amyloid

## Why is the risk of Alzheimer’s higher for women? [1:13:00]

- Upshot: brain-aging acceleration due to menopause transition
- About two in three of all AD cases are in women
- Another factor is that women generally live longer than men, and therefore more women get the disease late in life
- People think of AD as amyloid and tau: Richard thinks amyloid is the garbage that accumulates, and if you don’t take the garbage out you, you’re going to get sick
- But the upstream effect is mitochondrial dysfunction
- Richard thinks that the perimenopause transition has bioenergetic impacts on the brain, fast-forwarding a woman to AD — it’s brain-aging acceleration due to the menopause transition
- The withdrawal of sex hormones that is accelerating the process is either mitochondrial decline, or something that is leading to the accumulation of waste products, being manifested as amyloid and tau
- Metabolic status may have something to do with women and AD: Roberta Brinton has looked at women with vascular and metabolic issues, and those patients are the ones that respond preferentially to hormone therapy (Brinton [believes](https://www.alzforum.org/news/conference-coverage/do-brain-changes-menopause-make-women-more-prone-alzheimers) that hormone therapy might be most beneficial in women who are at heightened risk for AD, namely *APOE* e4 carriers with unhealthy metabolism), but there’s a lot of precision medicine in here that is very hazy
- [Brinton’s lab’s research](https://www.robertabrinton.com/) “[H]as demonstrated that ovarian steroids and neurosteroids are key mechanistic regulators of the bioenergetic and regenerative systems of the brain — Moreover, loss of ovarian hormones leads to activation of a sequence of compensatory responses that ultimately lead to the development of Alzheimer’s pathology”
- Do you intervene before menopause? Perimenopause? What do you do? What progesterone? Estrogen? Should you use a pill or a cream or a patch? Do you use it for two years, five years, seven years? Do you have to balance the decision based on breast cancer and other risks?
- What is the critical window of opportunity to intervene, how do we intervene, and when? are the key questions

## How many different paths lead to Alzheimer’s? [1:15:45]

- Richard thinks there might be 12 to 16 paths
- Peter generally refers to three or four different paths to the same place where you have the same final common pathway (vascular, metabolic/mitochondrial, toxin)
- Everybody’s accumulating amyloid beta and tau, but you can get there through microvascular disease, which then becomes basically a disease of hypoxia
- You can get there through diabetes, which then becomes an energetic problem
- You can get there through mitochondrial dysfunction

## What role does *MTHFR* play in Alzheimer’s? [1:19:45]

- MTHFR stands for methylenetetrahydrofolate reductase
- It’s getting attention due to genetic variants that may lead to high levels of homocysteine in the blood and low levels of folate and other vitamins
- Since March of 2015, Richard’s team is recruiting patients into a registry where they follow patients across primary prevention, secondary prevention, and tertiary prevention of AD
- With *MTHFR*, two polymorphisms, C677T (i.e., [rs1801133-T](https://www.snpedia.com/index.php/Rs1801133)) and A1298C (i.e., [rs1801131-C](https://www.snpedia.com/index.php/Rs1801131)), have had the greatest investigation as to their association with AD ([Berkowitz et al., 2018](https://www.mdpi.com/2227-9032/6/3/82/htm); [Román, 2015](https://www.ncbi.nlm.nih.gov/pubmed/26401555))
- The role of *MTHFR* in AD may be a metabolic road through homocysteine
- These people may have problems or be inefficient at metabolizing B vitamins, and because of that, they’re in the downstream cascade of biochemistry
- Homocysteine goes up and it’s a marker for something not working efficiently, and/or well in detoxifying
- If someone has an elevated homocysteine, but he or she is treated with B vitamins, it can slow overall brain atrophy and improved memory
- However, that will only work if you have optimized omega three fatty acids
- When a person with particular *MTHFR* mutations/polymorphisms is not responding to traditional B vitamins, Richard will give him or her methylcobalamin B-12 and methyl folate: that is usually enough to get the homocysteine down
- Richard and Peter use [Jarrow Formulas Methyl B-12/Methyl Folate and Pyridoxal-5-phosphate (P-5-P) Lozenges](https://www.amazon.com/Jarrow-Formulas-Methyl-Pyridoxal-5-phosphate-Lozenges/dp/B01LOOIDK4/ref=sr_1_5_s_it?s=hpc&ie=UTF8&qid=1538135847&sr=1-5&keywords=jarrow+lozenge)

Richard’s team created a free online CME course for physicians at [Alzheimer’s Universe](https://www.alzu.org/)

**Table 2. *MTHFR* / *APOE* poster showing changes in biomarkers and cognition and *APOE* and *MTHFR* status.** Image credit: Isaacson et al. poster presentation.

![](https://peterattiamd.com/wp-content/uploads/2018/09/Change-in-blood-biomarkers-and-cognition-mediated-by-ApoE-and-MTHFR-Status-01.png)

![](https://peterattiamd.com/wp-content/uploads/2018/09/Change-in-blood-biomarkers-and-cognition-mediated-by-ApoE-and-MTHFR-Status-02.png)

## What are the “ABCs” of Alzheimer’s prevention? [1:26:45]

- **A**nthropometric: body fat (visceral vs subcutaneous) and lean mass
- **B**iomarkers: lipoproteins, inflammation
- **C**ognitive function

Examples of biomarkers assessed (Table 2):

**Lipoproteins**

- apoB
- apoA-I
- Particle numbers
- Particle sizes
- Triglycerides

**Inflammation**

- Myeloperoxidase
- Lp-PLA2
- Fibrinogen
- hs-CRP
- Adiponectin

**Metabolism & Nutrition**

- DHA
- EPA
- ALA
- SFA
- MUFA
- Arachidonic acid
- Linoleic acid
- hbA1c
- Homocysteine
- Vitamin B12
- Vitamin D
- Fasting insulin
- Fasting glucose
- HOMA-IR

Richard’s team can then give patients a personalized precision medicine plan with a better likelihood of a positive outcome: they  also track changes in biomarkers over time to assess the efficacy of the interventions

**Cognitive function**

- When Richard sees lipid abnormalities, he sees executive function abnormalities
- When he sees metabolism problems, he sees memory and learning problems
- When he sees vitamin D and homocysteine out of range, he sees processing speed issues

Peter gets on his soapbox: “If you’re listening to this and you’re in some way touched by AD, either because you have a family member who’s got it, or you’re concerned about . . . and you’re considering [funding research](https://neurology.weill.cornell.edu/ways-to-give): I can’t emphasize enough the importance of funding the type of research that Richard does. Whether that means funding Richard directly, or somebody else, because AD prevention is so underfunded . . . The success rate of pharmacology for AD is 0.4% percent. In other words, 99.6% of drugs brought forth to treat AD are abject failures. Is it throwing more money into the same pile that’s taking the same approach to a disease that’s not working? Or is it possibly looking to this novel idea of Alzheimer’s prevention?”

## Baptists, Tauists, Syners, and Apostates [1:36:30]

Researchers and neurologists have different “faiths” about what is driving brain degeneration:

- 𝜷-Amyloid Peptide proponents (i.e., BAPtists, BAPineuzumab)
- 𝜏-inclusions are the primary driving force of brain degeneration (i.e., TAUists)
- α-synuclein, the building block of Lewy-Bodies, and related amyloid-like inclusions in Parkinson’s, AD, and other related disorders may be the most upstream in leading to neurodegeneration (i.e., SYNers)
- Richard may be an apostate: renouncing these faiths and believing that AD is mostly a mitochondrial metabolic disease ([Swerdlow et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3962811/))

## Concerns with statin use for high-risk patients [1:45:00]

- Five years ago, Richard would say he wasn’t worried, but today he is: after seeing patient after patient in the clinic, and certain genotypes and phenotypes, Richard is concerned
- Different statins likely work differently in different people
- When in doubt, low-dose is better
- There is likely a gender difference
- People with an e4 gene, especially two e4 genes, “Holy cow, you have to be careful”
- Sometimes the lipoprotein numbers will look great, but their memory gets worse on statins
- Richard is pro-statin, but anti-one-size-fits-all
- Peter comments, “I consider myself pro-everything under the right conditions: I’m pro-hammers when I have a nail and a piece of wood, but I’m pro-Phillips screwdriver when I have a Phillips screw and a piece of drywall”

## The use of Theracurmin [1:48:45]

- Gary Small and colleagues [showed](https://www.sciencedirect.com/science/article/pii/S1064748117305110) that after 18 months of using it, when you look at PET scans, there was less amyloid in the intervention group
- But not everyone may need curcumin
- Depends on your ABCs, and/or if you have chronic inflammation
- You can get Theracurmin off the shelf (i.e., at Amazon): note that Theracurmin is a registered trademark of Theravalues (the company that supplied Small and colleagues with the compound used in the study), so look for registered trademark symbol (®) on products with Theracumin®

## What are the five actionable things one can do to reduce the risk for Alzheimer’s today? [1:54:30]

*\* Disclaimer \* — Richard likes to use generalities about as much as Peter, so remember that context and individual differences are critical*

1. Education — knowledge is power: learn about brain health
2. Know — and manage — your numbers
3. Exercise
4. Optimize your nutrition
5. Manage your sleep and stress

**1 | Education**

- Incremental changes that you make now at 30, 40, 50 (the earlier the better), and throughout the lifespan — learn about brain health — because there are things you can do
- Visit Richard’s website: [Alzheimer’s Universe](https://www.alzu.org/)

**2 | Know — and manage — your numbers**

- What is your blood pressure?
- What is your pulse?
- What is your weight?
- What are your lipoproteins?
- What is your blood sugar?
- What is your body fat?
- What is your muscle mass?
- Know everything about yourself
- Get lipoproteins, diabetes, and blood pressure under control
- Systolic blood PRessure INtervention Trial (SPRINT) Memory and cognition IN Decreased hypertension (SPRINT MIND) [suggests](https://www.nih.gov/news-events/news-releases/nih-funded-researchers-present-preliminary-clinical-trial-results-suggesting-aggressive-blood-pressure-control-may-lower-risk-cognitive-impairment) aggressive blood pressure control may lower risk of cognitive impairment (“The findings suggest that intensive lowering of blood pressure may reduce the risk of mild cognitive impairment [MCI] and the combined risk of MCI and dementia, but not dementia alone”)

**3 | Exercise**

- The only thing a person can do right now if they have amyloid in their brain to reduce it, or slow the accumulation, is exercise on a regular basis
- Mix up your exercise between aerobic and anaerobic
- Lift weights (Figure 8)
- Avoid sitting for extending periods of time

![](https://peterattiamd.com/wp-content/uploads/2018/09/oliver-sacks-squat-300x284.png)

**Figure 8. Oliver Sacks squatting 600 lbs: a California state record in 1961.** “I felt inspired by Karl and determined to lift greater pound-ages myself, to work on the one lift I was already fairly good at— the squat. Training intensively, even obsessively, at a small gym in San Rafael, I worked up to doing five sets of five reps with 555 pounds every fifth day. The symmetry of this pleased me but caused amusement at the gym—“ Sacks and his fives.” I didn’t realize how exceptional this was until another lifter encouraged me to have a go at the California squat record. I did so, diffidently, and to my delight was able to set a new record, a squat with a 600-pound bar on my shoulders. This was to serve as my introduction to the power-lifting world; a weight-lifting record is equivalent, in these circles, to publishing a scientific paper or a book in academia.” Image and copy credit: [On the Move: A Life](https://www.amazon.com/Move-Life-Oliver-Sacks/dp/0804170932/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1538221920&sr=8-1) by Oliver Sacks.

**4 | Nutrition**

- Lower carbs
- Lots of leafy green vegetables
- Blueberries may be beneficial [Krikorian]
- Intermittent fasting

The bigger the belly, the smaller the hippocampus (the memory center)

**5 | Manage your sleep and stress**

- Get adequate sleep
- Manage your stress

## The cognitive reserve [2:14:15]

- How much does cognitive activity ward off cognitive decline? Is there any data to support that?
- Yes, but it’s complicated
- Early life risk factors for AD are different than midlife, and late life, and early life
- Risk can be mitigated the most by long-term educational attainment: that’s the best evidence we have
- Difficult to tell how much the healthy-user bias is at play here (i.e., socioeconomic status, related confounders)
- Richard believes early-life educational attainment (e.g., musical experience) and midlife educational attainment, absolutely can get built up
- Greater cognitive reserves, so that when you get AD, you’re more resilient
- If you don’t use it, you lose it: build and maintain a better backup pathway in the brain
- People that have AD and are very cognitively engaged, and have a good backup pathway, they’re not going to decline as quickly
- Once the disease takes hold, maybe they stop working or they lose a sense of purpose, you can see a much sharper decline: people with high cognitive reserve, high cognitive backup systems, are resistant to the effects of the amyloid burden

![](https://peterattiamd.com/wp-content/uploads/2018/09/regenerates-richard-isaacson.jpg)

**Figure 9. Poster for a Regenerates concert on May 24, 2012.** (Canceled because of rain.) Image credit: [The Regenerates](https://www.facebook.com/TheRegenerates/) on Facebook

§

§

## Selected Links / Related Material

- **Richard’s clinic**: [Alzheimer’s Prevention Clinic](https://neurology.weill.cornell.edu/clinical-services/alzheimers-disease-memory-disorders-program/alzheimers-prevention-clinic) | (weill.cornell.edu) [00:45]
- **Single most important resource for people with Alzheimer’s**: [Alzheimer’s Universe](https://www.alzu.org/) | ([alzu.org](https://www.alzu.org/)) [2:15]
- **The bling phone Richard had with him**: [Vertu Constellation Quest: The blingtastic £17,300 smart phone](https://www.cnet.com/news/vertu-constellation-quest-the-blingtastic-17300-smart-phone/) | Asavin Wattanajantra ([cnet.com](https://www.cnet.com/)) [3:00, 9:30, 23:30]
- **Richard’s guitar shaped like an NJ Warlock**: [NJ Series Warlock Electric Guitar](https://www.guitarcenter.com/BC-Rich/NJ-Series-Warlock-Electric-Guitar.gc) | (guitarcenter.com) [17:00]
- **Book that Richard took to summer camp**: [Liebman’s Neuroanatomy Made Easy And Understandable](https://www.amazon.com/Liebmans-Neuroanatomy-Made-Easy-Understandable/dp/1416401636) by S. David Gertz | (amazon.com) [17:30]
- **Where Richard was trained in cognitive neurology**: [Beth Israel Deaconess Medical Center](https://www.bidmc.org/) | (bidmc.org) [19:00]
- **Richard’s band**: [The Regenerates](https://www.facebook.com/TheRegenerates/) | ([facebook.com](https://facebook.com/)) [23:30]
- **Richard’s book, a guide for Alzheimer’s treatment and prevention**: [Alzheimer’s Treatment Alzheimer’s Prevention: A Patient and Family Guide](https://www.amazon.com/Alzheimers-Treatment-Prevention-Patient-Family/dp/0983186979/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) by Richard Isaacson | ([amazon.com](https://www.amazon.com/)) [24:30]
- **Location of Richard’s clinic**: [NewYork-Presbyterian/Weill Cornell Medical Center](https://www.nyp.org/locations/newyork-presbyterian-weill-cornell-medical-center) | ([nyp.org](https://nyp.org/)) [29:15]
- **Type of dementia found in Robin Williams**: [Lewy body dementia](https://en.wikipedia.org/wiki/Lewy_body_dementia) | ([wikipedia.org](https://www.wikipedia.org/)) [31:30]
- **37 percent of *APOE4* non-carriers and 13 percent of *APOE4* carriers with a clinical diagnosis of mild-to-moderate Alzheimer’s had minimal evidence amyloid plaque**: [Many Patients with Clinical Alzheimer’s Do Not Have Significant Amyloid Pathology](https://medicalresearch.com/mental-health-research/alzheimers-dementia/many-patients-with-clinical-alzheimers-do-not-have-significant-amyloid-pathology/16997/) | ([medicalresearch.com](https://medicalresearch.com/)) [35:00]
- **37 percent of *APOE4* non-carriers and 13 percent of *APOE4* carriers with a clinical diagnosis of mild-to-moderate Alzheimer’s had minimal evidence amyloid plaque**: [Characterizing Apolipoprotein E ε4 Carriers and Noncarriers With the Clinical Diagnosis of Mild to Moderate Alzheimer Dementia and Minimal β-Amyloid Peptide Plaques](https://www.ncbi.nlm.nih.gov/pubmed/26302353) (Monsell et al., 2015) [35:00]
- **Alzheimer’s prevention clinics (other than Richard’s)** [41:40]
  - [Alzheimer’s Risk Assessment and Intervention Clinic](https://www.uab.edu/medicine/alzheimers/alzheimer-s-risk-assessment-and-intervention-clinic) ([uab.edu](https://www.uab.edu/))
  - [Alzheimer’s Prevention Clinic & Research Center of Puerto Rico](https://www.alzu.org/apcpr/) ([alzu.org](https://www.alzu.org/))
  - [Center for Brain Health](https://www.northshore.org/neurological-institute/centers-and-programs/center-for-brain-health/) ([northshore.org](https://www.northshore.org/))
  - [Dementia Prevention Initiative](https://www.fau.edu/newsdesk/articles/ccbh-dementia-prevention.php) ([fau.edu](https://www.fau.edu/))
  - [Pacific Brain Health Center](https://www.pacificneuroscienceinstitute.org/brain-health-lp/) (pacificneuroscienceinstitute.org)
- **Memory test that predicts amyloid in the brain**: [Face-name Associative Memory Performance is Related To Amyloid Burden in Normal Elderly](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3137730/) (Rentz et al., 2012) [43:30]
- **Richard on Dr. Oz explaining Face-Name Memory Test**: [Introducing the Face-Name Memory Test](https://www.doctoroz.com/episode/alzheimer-s-summit-new-prevention-breakthroughs-and-judge-hatchett-s-family-heartbreak?video_id=5578900458001) | ([doctoroz.com](https://www.doctoroz.com/)) [43:30]
- **The Alzheimer’s Association put out 10 tips for brain health to preserve cognitive health**: [10 Ways to Love Your Brain](https://www.alz.org/help-support/brain_health/10_ways_to_love_your_brain) | Alzheimer’s Association ([alz.org](https://www.alz.org/)) [44:30]
- **Richard’s paper recently published about Alzheimer’s prevention**: [Nutritional interventions for Alzheimer’s prevention: a clinical precision medicine approach](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5674531/) (Schelke et al., 2017) [44:45]
- **How we are able to link genes to traits**: [Genome-wide association study](https://en.wikipedia.org/wiki/Genome-wide_association_study) | ([wikipedia.org](https://www.wikipedia.org/)) [1:08:45]
- **Company what will test your DNA for ancestry, genetic health risks, etc.**: [23andMe](https://www.23andme.com/?myg=true) | ([23andme.com](https://www.23andme.com/)) [1:11:15]
- **Peter and Richard’s recent paper they collaborated on**: [Mechanisms of Risk Reduction in the Clinical Practice of Alzheimer’s Disease Prevention](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5907312/) (Schelke et al., 2018) [1:16:45]
- **Study looking at hormone therapy for women at risk for dementia**: [Prospective Randomized Trial to Assess Effects of Continuing Hormone Therapy on Cerebral Function in Postmenopausal Women at Risk for Dementia](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0089095) (Rasgon et al., 2014) [1:17:00]
- **Free online CME course for physicians**: [HEALTHCARE PROVIDERS](https://www.alzu.org/hcp/) | (alzu.org) [1:25:15]
- **Richard’s Medscape piece on Theracurmin** [1:48:45]
  - [Curcumin’s Cognitive Benefits Look Convincing](https://www.medscape.com/viewarticle/893160) | Richard Isaacson ([medscape.com](https://www.medscape.com/))
  - [Noninvasive Biomarkers of AD Will Soon Be Reality](https://www.medscape.com/viewarticle/893819) | Richard Isaacson ([medscape.com](https://www.medscape.com/))
- **Study suggesting curcumin, when swallowed, did not reduce Alzheimer’s risk**: [Oral curcumin for Alzheimer’s disease: tolerability and efficacy in a 24-week randomized, double blind, placebo-controlled study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3580400/) (Ringman et al., 2012) [1:49:30]
- **Theracurmin study**: [Memory and Brain Amyloid and Tau Effects of a Bioavailable Form of Curcumin in Non-Demented Adults: A Double-Blind, Placebo-Controlled 18-Month Trial](https://www.sciencedirect.com/science/article/pii/S1064748117305110) (Small et al., 2018) [1:51:00]
- **Recommended supplement brand**: [Jarrow Formulas](https://jarrow.com/) | ([jarrow.com](https://jarrow.com/)) [1:51:45]
- **Recommended brand of methyl folate**: [Jarrow Formulas Methyl B-12 & Methyl Folate Lemon](https://jarrow.com/product/661/Methyl_B-12_&_Methyl_Folate_Lemon) | ([jarrow.com](https://jarrow.com/)) [1:51:45]
- **Sleep tracker that Peter uses**: [Oura ring](https://ouraring.com/) | ([ouraring.com](https://ouraring.com/)) [1:57:15]
- **Wearable that Richard uses**: [Whoop biosensor](https://www.whoop.com/membership/) | ([whoop.com](https://www.whoop.com/)) [1:57:15]
- **Dale Bredesen’s case reports and therapeutic program in 2014**: [Reversal of cognitive decline: A novel therapeutic program](https://www.ncbi.nlm.nih.gov/pubmed/25324467) (Bredesen, 2014) [1:59:15]
- **Richard’s preferred cardio is cycling using either of these two options** [2:01:45]
  - [Flywheel](https://www.flywheelsports.com/)
  - [Peloton](https://www.onepeloton.com/)
- **Paper suggesting alcohol could be cardioprotective**: [Alcohol in Moderation, Cardioprotection and Neuroprotection: Epidemiological Considerations and Mechanistic Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2908373/) (Collins et al., 2010) [2:04:00]
- **Study that concluded, “[T]he level of [alcohol] consumption that minimises health loss is zero”**: [Alcohol use and burden for 195 countries and territories, 1990–2016: a systematic analysis for the Global Burden of Disease Study 2016](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(18)31310-2/fulltext#%20) (Griswold et al., 2018) [2:04:00]
- **Study that found a lower associated risk of initial presentation with several cardiovascular diseases, even after separation of groups of non-drinkers**: [Association between clinically recorded alcohol consumption and initial presentation of 12 cardiovascular diseases: population based cohort study using linked health records](https://www.bmj.com/content/356/bmj.j909) (Bell et al., 2017) [2:04:00]
- **Major study that modified the way Richard thinks about blood pressure management**: [NIH-funded researchers present preliminary clinical trial results suggesting aggressive blood pressure control may lower risk of cognitive impairment](https://www.nih.gov/news-events/news-releases/nih-funded-researchers-present-preliminary-clinical-trial-results-suggesting-aggressive-blood-pressure-control-may-lower-risk-cognitive-impairment) | NIH ([nih.gov](https://www.nih.gov/)) [2:07:15]
- **Blueberries and potential impact on memory**: [Blueberry Supplementation Improves Memory in Older Adults](https://www.ncbi.nlm.nih.gov/pubmed/20047325) (Krikorian et al., 2010) [2:08:45]
- **Robert Krikorian discussing blueberries**: [The Genius Life 5: Blueberries and Ketosis For A Better Brain | Robert Krikorian, PhD](https://www.maxlugavere.com/podcast/the-genius-life-5-blueberries-and-ketosis-for-a-better-brain-robert-krikorian-phd) | Max Lugavere ([maxlugavere.com](https://www.maxlugavere.com/)) [2:08:45]
- **Seth Rogen’s charity for Alzheimer’s**: [Hilarity for Charity](https://hilarityforcharity.org/) | (hilarityforcharity.org) [2:13:00]

§

§

## People Mentioned

- [Rosie O’Donnell](https://twitter.com/Rosie?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (same high school as Richard) [1:45]
- [Bob Costas](https://en.wikipedia.org/wiki/Bob_Costas) (same high school as Richard) [1:45]
- [Doogie Howser](https://en.wikipedia.org/wiki/Doogie_Howser,_M.D.) (fictional character Peter compares to Richard) [1:55]
- [Richard Gibbs](https://www.bcm.edu/people/view/richard-gibbs-ph-d/b1560782-ffed-11e2-be68-080027880ca6) (*APOE*) [4:40]
- [Bob Kaplan](https://twitter.com/bobkaplan) (Attia Medical analyst, show notes contributor) [7:15, 23:45, 2:01:15]
- [Travis Denson](https://twitter.com/tden185) (Attia Medical analyst, show notes contributor) [7:15, 23:45]
- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) (Dementia Pugilistica) [8:00]
- [Stuart Isaacson](https://www.touchneurology.com/content/stuart-isaacson-md) (Richard’s brother, Parkinson’s specialist) [8:10]
- [Jay Walker](https://en.wikipedia.org/wiki/Jay_S._Walker) (slot machine expert) [11:15]
- [Norman Geschwind](https://en.wikipedia.org/wiki/Norman_Geschwind) (pioneer of behavioral neurology) [19:15]
- Uncle Bob (Richard’s uncle, died of dementia) [19:30]
- [Robin Williams](https://en.wikipedia.org/wiki/Lewy_body_dementia#Notable_individuals) (had [Lewy body dementia](https://en.wikipedia.org/wiki/Lewy_body_dementia)) [31:30]
- [Dan Palenchar](https://www.linkedin.com/in/danielpalenchar/) (Attia Medical analyst, cognitive testing, exercise for mitigating Alzheimer’s) [38:00, 1:58:30]
- [Hollie Webb](https://directory.weill.cornell.edu/person/profile/how2005) (works with Richard at his clinic) [40:20, 1:04:15, 1:10:45, 1:48:30]
- [David Geldmacher](https://providerdirectory.uabmedicine.org/provider/David+Geldmacher/570620) (Alzheimer’s Risk Assessment and Intervention Clinic) [40:45]
- [Jim Galvin](https://med.fau.edu/home/departments/imsd/galvin.php) ([Dementia Prevention Initiative](https://www.fau.edu/newsdesk/articles/ccbh-dementia-prevention.php)) [41:45]
- [David Merrill](https://www.pacificneuroscienceinstitute.org/people/david-a-merrill-md-phd/) ([Pacific Brain Health Center](https://www.pacificneuroscienceinstitute.org/brain-health-lp/)) [42:00]
- [Doreen Rentz](https://www.madrc.org/dorene-m-rentz-psyd) ([Face-Name Memory Test](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3137730/)) [43:30] (also see: [Richard on Dr. Oz](https://www.doctoroz.com/episode/alzheimer-s-summit-new-prevention-breakthroughs-and-judge-hatchett-s-family-heartbreak?video_id=5578900458001))
- [Lisa Mosconi](https://twitter.com/dr_mosconi) (men’s brain imaging, andropause) [48:45]
- [Matthew Schelke](https://columbianeurology.org/neurology/resident/matthew-wesley-schelke-md) (collaborated on [this paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5907312/) with Peter, Richard, Dan, Bob, and colleagues) [1:16:45]
- [Roberta Brinton](https://uahs.arizona.edu/leadership-team/roberta-diaz-brinton-phd) (HRT for women) [1:18:45]
- [John Ringman](https://providers.keckmedicine.org/provider/John+M.+Ringman/205422) (curcumin and Alzheimer’s) [1:49:30]
- [Gary Small](https://twitter.com/drgarysmall?lang=en) (curcumin and Alzheimer’s) [1:51:00]
- [Randy Cohen](https://www.crystalrunhealthcare.com/providers/randy-cohen) (cardiologist) [1:53:15]
- [Nelson Mandela](https://en.wikipedia.org/wiki/Nelson_Mandela) (education) [1:57:00]
- [Dale Bredesen](https://twitter.com/dr_bredesen?lang=en) (Alzheimer’s prevention) [1:59:15]
- [Oliver Sacks](https://en.wikipedia.org/wiki/Oliver_Sacks) (neurologist and powerlifter) [2:03:15]
- [Robert Krikorian](https://med.uc.edu/psychiatry/department-directory/faculty/Index/Pubs/krikorr/) (a pioneer in the field of nutrition and Alzheimer’s) [2:08:45]
- [Seth Rogen](https://twitter.com/Sethrogen?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) ([Hilarity for Charity](https://hilarityforcharity.org/), bringing attention to Alzheimer’s) [2:13:00]

§

![](https://peterattiamd.com/wp-content/uploads/2018/09/richard-Isaacson-2x1-500x500.jpeg)

##### Richard Isaacson, M.D.

Richard S. Isaacson, M.D. currently serves as Director of the Alzheimer’s Prevention Clinic, Weill Cornell Memory Disorders Program, and Director of the Neurology Residency Training Program at Weill Cornell Medical College/NewYork-Presbyterian Hospital. He previously served as Associate Professor of Clinical Neurology, Vice Chair of Education, and Education Director of the McKnight Brain Institute in the Department of Neurology at the University of Miami (UM) Miller School of Medicine. He completed his residency in Neurology at Beth Israel Deaconess Medical Center/Harvard Medical School, and his medical internship at Mount Sinai Medical Center in Miami Beach, FL. Prior to joining UM, he served as Associate Medical Director of the Wien Center for Alzheimer’s disease and Memory Disorders at Mount Sinai.

A graduate of the accelerated 6-year B.A./M.D. program at the University of Missouri – Kansas City School of Medicine, Dr. Isaacson now specializes exclusively in Alzheimer’s disease (AD) risk reduction and treatment, mild cognitive impairment due to AD and pre-clinical AD. His AD research focuses on nutrition and the implementation and longitudinal assessment of dietary interventions for AD management. Dr. Isaacson has a family history of AD, including his Uncle Bob (diagnosed while he was in high school) and his Dad’s Cousin (diagnosed six years ago) and passionately believes in a comprehensive, multi-modal approach toward both AD treatment and prevention. He is the author of two best-selling books geared for patients and caregivers, Alzheimer’s Treatment Alzheimer’s Prevention: A Patient & Family Guide (2012 Edition) and most recently, The Alzheimer’s Prevention & Treatment Diet.

Dr. Isaacson’s career in education spans undergraduate (student), graduate (resident/fellow), and continuing (faculty) medical education, as well as patient, caregiver and community education/outreach. His recent efforts have focused on the development of Alzheimer’s Universe (www.AlzU.org) a vast online educational portal on AD, with results published in the Journal of the Prevention of Alzheimer’s disease. He has chaired the AAN Undergraduate Education Subcommittee working group in dementia and received the AAN Education Research Grant for “Evaluating the effectiveness of Continuum: Dementia as a teaching tool for medical students” published in Neurology. He recently led a collaborative education and health information technology research initiative at Weill Cornell, Harvard, UM, U. Pennsylvania, U. Rochester published in Neurology. He is the author of numerous publications, his research in neurology and medical education has been presented at scientific meetings nationally and internationally, and was awarded the 2009 AAN A.B. Baker Teacher Recognition Award. He is also a member of the Alpha Omega Alpha Medical Honor Society. [[weillcornell.org](https://weillcornell.org/risaacson)]