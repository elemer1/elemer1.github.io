# #367 – Tylenol, pregnancy, and autism: What recent studies show and how to interpret the data

**Source:** [https://peterattiamd.com/tylenolandautism/](https://peterattiamd.com/tylenolandautism/)

---

In this special episode of The Drive, Peter addresses the recent headlines linking acetaminophen (Tylenol) use during pregnancy to autism in exposed children. Recognizing the confusion these claims have sparked among patients, listeners, and the broader public, Peter uses this episode to provide a framework for thinking critically about complex conditions and the research related to them. He highlights the dramatic rise in autism diagnoses over recent decades, noting that multifactorial conditions rarely have a single cause, and emphasizes the importance of resisting oversimplified explanations. Peter also stresses that humans are not naturally wired for scientific thinking, making disciplined frameworks like the Bradford Hill criteria essential for evaluating causality in epidemiology. Ultimately, he uses this framework to explore the evidence surrounding acetaminophen use during pregnancy and its potential link to autism.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/tylenolandautism/the_Drive_public.png)

Play

#367 - Tylenol, pregnancy, and autism: What recent studies show and how to interpret the data

#367 - Tylenol, pregnancy, and autism: What recent studies show and how to interpret the data

1x15s30s

0:001:27:09

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Laying the groundwork for this discussion, the rise in autism rates, and the value in using frameworks [A: 1:00, V: 0:09];
- The FDA pregnancy drug categories, where Tylenol falls within that framework, and a structured method for evaluating scientific evidence and causality [A: 6:00, V: 5:33];
- What exactly are the claims being made about acetaminophen and autism? [A: 13:45, V: 14:13];
- The increase in autism rates and why so many things are being linked to autism: the multiple comparisons problem [A: 15:00, V: 15:27];
- Evaluating the review paper that triggered the recent concern over acetaminophen and autism [A: 21:45, V: 22:34];
- Breaking down the largest studies on prenatal Tylenol exposure and autism: is there a causal link? [A: 35:00, V: 36:20];
- Why observational studies can’t prove causality, the role of confounding variables, and the importance of frameworks like the Bradford Hill criteria [A: 43:30, V: 45:08];
- Applying the Bradford Hill criteria: testing the case for Tylenol and autism [A: 45:45, V: 47:48];
- Putting it all together to answer the question: Does acetaminophen use during pregnancy increase the risk of autism? [A: 56:15, V: 59:03];
- If autism risk is overwhelmingly genetic, what explains the dramatic rise in autism diagnoses? [A: 59:15, V: 1:02:09];
- Other risk factors for autism: parental age, maternal health, environment, and where Tylenol fits in [A: 1:09:15, V: 1:12:41];
- Medication use during pregnancy: balancing risks, benefits, and FDA categories [A: 1:15:15, V: 1:19:01];
- Considerations for taking Tylenol during pregnancy [A: 1:19:30, V: 1:23:48];
- Final thoughts: critical thinking, balanced risk assessment, and the importance of context when evaluating medications like Tylenol during pregnancy [A: 1:22:30, V: 1:26:53]; and
- More.

---

## Show Notes

## Laying the groundwork for this discussion, the rise in autism rates, and the value in using frameworks [A: 1:00, V: 0:09]

- If you’ve been following the headlines recently, you may have seen stories linking [acetaminophen](https://en.wikipedia.org/wiki/Paracetamol) (or Tylenol) use during pregnancy to [autism [ASD]](https://en.wikipedia.org/wiki/Autism)
- Not surprisingly, those headlines have generated a lot of questions, a lot of controversy, and a lot of confusion
- Peter has heard about this a lot from every direction: his patients, listeners of the podcast, friends, family members, people writing in through the website
- Like many people in this space, we’ve all been inundated by it

> “*The more I thought about it, the more I realized this was a great opportunity to put forth a framework for how to think about these things critically.*”‒ Peter Attia

- While we initially thought we would just do this in the newsletter last week, once we got into it, we realized now this doesn’t really lend itself to an article or even a short video
- It really commands effectively the discipline of what we do in the AMAs (the Ask Me Anything episodes)
- Unlike a normal AMA, this is going to be made available to everybody

**Groundwork before we dig in**

- We’re going to unpack some of the points in more detail that Peter is going to lay out below, but he wants to make sure we’re starting from a place of reference

*Peter wants to start out with a few important observations*

1 – Autism rates have risen dramatically over the past generation

- Now we’re going to talk about why that might be
- But it’s very important to state upfront that there is unlikely to be a single cause. Why?
- Because complex conditions usually don’t have simple explanations
  - This is true of obesity, despite what some people would have
  - You believe that it’s just this one thing or just this one thing or whatever, but the reality of it is complex conditions require multiple things typically

***Anytime we look at a possible contributing factor, we need to resist the temptation to assume it’s the sole cause***

- Now that doesn’t diminish the interest in identifying a bunch of potential causes

2 – Science is supposed to be apolitical

- Unfortunately, that’s not the case and for reasons Peter doesn’t think he’s smart enough to understand, autism happens to be one of those examples
- But so are many other topics we’ve discussed like nutrition or protein, which has become remarkably political

***Peter’s goal here is not to have a political debate, but rather to examine the evidence as carefully and objectively as he can***

- 3 – We do need to realize something that is very hard to accept, and that is that as humans, we are not wired to think scientifically
- Peter wants to restate that because it sounds condescending, but it’s simply an observation of how we have evolved

***We are not wired for critical and scientific thought***

- This is something Peter has written about
  - This [piece](https://peterattiamd.com/wired-think-scientifically-can-done/) from over 10 years ago synthesizes that point really well
- It really comes down to the fact that we should understand that both the scientific method and critical thought are human inventions
- They’re wonderful inventions, and Peter would argue they are the single most important invention our species has ever put forth
  - And without this, nothing else would exist
  - Without this, we’d still be living in caves
- But that doesn’t mean that it comes naturally, and it doesn’t mean we’re wired to do it

Peter adds, “*Just keep that in mind as you catch yourself (as I catch myself) falling into non-scientific thought. We’re going to rely on a framework at some point during this discussion, which is very helpful.*”

4 – The branch of science we’re going to be talking primarily about today is [epidemiology](https://en.wikipedia.org/wiki/Epidemiology), and when considering epidemiology the Bradford Hill criteria are key

**⇒** The [Bradford Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) are 9 principles that were laid out in the mid-60s to help us determine whether an observed observation is likely to be causal [summarized in the figure below]

- This framework looks at things like strength of association, consistency across multiple studies, biologic, plausibility, temporality and things like that
- They’re not a checklist per se, but they provide a disciplined way to try to make sense of correlations and interpret which ones have a higher probability of being causal from those that don’t

![](https://peterattiamd.com/wp-content/uploads/2025/10/f1-tylenol.png)

**Figure 1. The Bradford Hill criteria**. Summarized from: [*European Journal of Epidemiology* 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8206235/)

- Another thing to point out is we’re going to be talking about medications; we’re going to be talking about pregnancy

5 – Anyone listening to this or watching this who has gone through pregnancy will understand that the bar is very high when we are talking about medications to be used during pregnancy

- Most physicians (Peter included) don’t treat very many pregnant women
- We think about drugs and supplements very differently in the setting of pregnancy, of course, because we are typically not treating patients with life-threatening conditions

Peter explains, “*Our mantra is during pregnancy, women should basically stop all medications and supplements beyond the obvious ones (such as prenatal vitamins or hormones such as thyroid hormone, which can be essential), but anything that’s even in a gray area or probably okay, we tend to just avoid*.”

## The FDA pregnancy drug categories, where Tylenol falls within that framework, and a structured method for evaluating scientific evidence and causality [A: 6:00, V: 5:33]

- Now since the late 70s, the FDA has used a very simple letter system to [classify drugs by their risk during pregnancy](https://en.wikipedia.org/wiki/Pregnancy_category#United_States)
  - These categories go by A, B, C, D, and X, and basically each letter refers to a level of evidence, mostly from animal and human studies about the potential harm of the drug to the fetus
  - For more than 35 years or so, this was the framework physicians relied on
- About 10 years ago, the FDA replaced with a framework that is called the [Pregnancy and Lactation Labeling Rule (PLLR)](https://www.fda.gov/drugs/labeling-information-drug-products/pregnancy-and-lactation-labeling-resources)
  - The idea was to move away from single letters and instead provide a more descriptive guidance
- And in theory, that’s an improvement, but in practice it’s been kind of slow to roll out and frankly
- Peter is a little guilty of generally thinking about it in the ABCDX category, and that’s what he’s going to refer to a little bit (he’s going to stick with that older category)
  - And while it’s imperfect, it’s widely understood, it is still a clear framework, and he wants to share with you as we begin this so you have a broad sense of how drugs fit into this
  - [summarized in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f2-tylenol.png)

**Figure 2. FDA pregnancy categories**. Adapted from: [Wikipedia](https://en.wikipedia.org/wiki/Pregnancy_category#United_States)

- **Category A** means that there is no demonstrated risk in well controlled human studies
  - That’s pretty unusual because that’s a hard thing to do, and that’s reflected in the proportion of total drugs and supplements out there that fit in this category (2-5% of drugs)
  - That means it’s completely safe ‒ we have definitive evidence that women can take these things during pregnancy
  - Virtually nothing fits into this category
  - But the examples Peter gave earlier of thyroid hormone and prenatal vitamins do fit in this category
- **Category B** says there is no evidence of risk in humans, but animal data might show signals in some studies
  - These are generally thought of as safe, but exercise caution
  - This is 15 to 25% [of drugs]
- **Category C** says risk cannot be ruled out
  - We don’t have evidence that there is risk, but we don’t have evidence that it’s safe
  - Most drugs sit here, somewhere between 60-75%
- Peter will come back and give examples of drugs that sit in this category
- You might say, “*Why would a woman ever take a drug if there’s some evidence of risk to the fetus?*”
  - That is only if the risk to the mother not taking it is greater
  - The classic example here is seizure medication [in category C]
  - If you have a woman who is going to be debilitated by seizures and this is the only treatment she can have, then a physician will typically make that decision
  - And again, very few drugs fit in category C: typically 5-8%,
- **Category X** are drugs that have definitively been proven (as much as you can prove anything in biology) to cause significant harm to the fetus regardless of benefit to the mother
  - Again, these are pretty rare: 1-3%.

**Where does Tylenol or acetaminophen fit into that? It fit its into category B**

- And to be clear, for the last 10 years there has been some concern about: Does Tylenol belong in category B?
  - Should it belong in category C?
- The other thing to keep in mind with Tylenol is you always have to ask yourself about the switching cost or the alternative choices
- A very common alternative choice for Tylenol would be something like ibuprofen or an [NSAID](https://en.wikipedia.org/wiki/Nonsteroidal_anti-inflammatory_drug)

**⇒** [Ibuprofen](https://en.wikipedia.org/wiki/Ibuprofen) (Advil, Aleve, for example) are considered category B in the first 2 trimesters, but bump to category D in the third trimester

- For those who are interested, it has to do with the premature closure of a very small blood vessel that connects the aorta and the pulmonary artery, and if that closes prematurely, it leads to premature delivery and all sorts of things like that
- Keep in mind the reason we’re walking through all of this now is to just sort of set the stage for this discussion

**The goal today** is not just to look at the potential link between acetaminophen and autism, but also to put it in context so that we can hopefully end with the question that some of you are asking, “*Okay, science aside Peter, what’s the bottom line? If a woman is pregnant, should she be taking Tylenol?*”

- Of course, to answer that question, you have to not only take into account the possible effective Tylenol exposure on the baby
  - But also the health and the wellbeing of the mother
  - And also the possible effects of going without Tylenol in the case of fever or inflammation, which is also associated with negative health outcomes for babies that are exposed to those conditions in utero

**Peter’s framework**

- We’re going to take the same structured approach that Peter tries to recommend and utilize any time he’s confronted with an **association between exposure X and condition Y**
  - And that’s true if condition Y is positive or negative, good or bad

1 – The first thing you want to be able to do is confirm that there is indeed an association statistically

- A lot of times people say there’s an association, but there might actually not be
- So you actually want to document that statistically there is an exposure (verify that)

2 – The second question you’re asking is the hardest one: If there is a statistical association, you want to determine the likelihood that the association is causal

- Included in this would be [sensitivity analysis](https://en.wikipedia.org/wiki/Sensitivity_analysis), [falsification tests](https://en.wikipedia.org/wiki/Falsifiability), and things of that nature

Peter adds, “*Now notice I said you’re not trying to prove if the association is causal. Why? Because as I’m sure many of you heard me say before, there are no proofs in biology. It’s not like mathematics. You don’t get to write QED at the end of your work here.*”

- What we’re really dealing with here is probabilities and we’re trying to determine the likelihood of causality
- Now, if the association is believed to be more likely causal than not, then we have to ask the final question [listed next]

3 – We have to understand the [effect size](https://en.wikipedia.org/wiki/Effect_size)

- The final question factors into: What do you do?
- So you could have things that are causal, but the effect size is so small that it doesn’t matter
  - In which case your behavior is going to be quite different

**Final point**: it’s a very important to remember that we’re discussing the state of science today

- And science is not about being right or wrong in an absolute sense
- It’s really about constantly updating our priors, understanding the probability of something as new evidence becomes emergent
- That’s how we should really work ‒ as more and more data come online, we might have to revise our views and conclusions
  - Doing so is not a weakness
  - Although tragically it has become viewed as a weakness
  - Certainly if politicians change their mind about things that’s viewed as waffling
- As scientists or as communicators of science, we shouldn’t be afraid of that

***We should be open and acknowledge that as of today, this might be how we view things and in the presence of new information, and we should be very receptive to changing that mind***

- Peter knows that was a lot of background, but it’s really important to have a shared foundation of knowledge and an understanding of the framework before we wade into a topic that is not only scientifically complex, but obviously very emotionally and politically charged
- That’s the lens he is hoping to use for this discussion
- With all of that said, rather than just continue a monologue, it would be great to have our co-host, Nick Stenson from the AMAs join and basically lay out this discussion in the form of a Q & A

## What exactly are the claims being made about acetaminophen and autism? [A: 13:45, V: 14:13]

**First lay the foundation of the claims being made about acetaminophen and autism**

- The basic gist of the scientific claim is that maternal use of acetaminophen during pregnancy is associated with an increased risk of autism in the exposed child
  - Tylenol being the most common and the most familiar to reflect the possible risk during pregnancy
- And this has prompted the government to respond by asking the FDA to issue warnings to physicians and change the labels on acetaminophen products

**⇒** It’s important to note that both the FDA and the scientific community agree that we don’t yet have evidence to assert that the apparent correlations between prenatal acetaminophen exposure and autism risk reflect a *causal* relationship

- In other words, no authoritative sources are claiming that we can conclude from the existing body of evidence that acetaminophen actually causes an increase in autism risk
- Though some argue that a causal relationship is plausible and others argue that a causal relationship is very likely and that acetaminophen should therefore be avoided during pregnancy (or used at most with strong precaution)

## The increase in autism rates and why so many things are being linked to autism: the multiple comparisons problem [A: 15:00, V: 15:27]

**You mentioned there could be a lot of reasons why we’re seeing autism rates increase and not just a single thing. What do we know about why there are so many things being linked to autism these days?**

- There’s 2 parts to this question

1- You’re asking why autism rates are going up?

- We can’t deny that

2 – The second question is why are there so many things being linked to autism these days?

- This is the more jugular question at the moment, but Peter will get to #1 later
- It comes down to a very understandable, rational and logical desire, a very strong motivation to look for the triggers of autism
  - We are looking for culprits
- Autism rates have risen dramatically both nationally and even globally over the past few decades

**⇒** According to the [CDC](https://www.cdc.gov/autism/data-research/index.html), the prevalence of autism increased from 6.7 cases per thousand children in the year 2000 (just 25 years ago) to 32.2 cases per thousand children just 3 years ago [in 2022]

- That’s a 5-fold increase
- There are lots of explanations for this, which we’ll get to
- That is not a subtle increase, and while some of that increase is due to an expanding diagnostic definition and increased awareness (which we’ll get into more later), there is no doubt that some residual increase is out there, even after accounting for these changes
- Therefore, in an effort to find these potential causes, a lot of research has been done to find potential associations between autism and countless other variables

Now, all of that sounds great and all of that makes sense, but it poses a significant statistical problem

- And this is known as the [multiple comparisons problem](https://en.wikipedia.org/wiki/Multiple_comparisons_problem): if you look at enough variables, you are bound to find statistically significant associations

Peter points out, “*This is the first example that I’m going to pull forth from what I stated at the outset, which is we are not wired to think scientifically if anybody out there thinks they are smart enough that they can understand* [*p-values*](https://en.wikipedia.org/wiki/P-value) *out of the womb, more power to you.*”

- Peter majored in mathematics, and spent his life doing mat and stats
- This idea is not that intuitive until it is explained to you
- So it’s understandable why what he’s about to say doesn’t necessarily jump to your mind as the explanation for this

An example to understand the multiple comparisons problem

- Imagine if you’re trying to detect if someone has psychic powers by having them guess the outcome of coin flips
- You create the rules such that if they guess correctly on at least 7 out of 10 flips, they will be declared a psychic
  - Which by the way, that’s a 5% chance somebody would do that based on pure luck with a fair coin
  - If you flipped a coin 10 times, each of those has a 50-50 shot of heads or tails
  - But if you can guess correctly, 7 out of 10, 8 out of 10, nine out of 10 or 10 out of 10, there’s only a 5% chance of doing that
- That game is basically like a single hypothesis test with a significance level of 0.5
- You see where Peter is going with this
  - He’s setting this up like a [single hypothesis test](https://en.wikipedia.org/wiki/Statistical_hypothesis_test) with a significance level of 0.05 or a *p-*value of 0.05
- Now suppose instead of just testing 1 person, I’m going to test 100 random people all with fair coins
- And let’s assume for the purpose of illustration, there are no real psychics
- By chance alone, I’m going to identify 5 people out of 100 who are going to pass the psychic test and they’re going to look like psychics

**⇒** But the probability that at least 1 person passes the test isn’t just 5%, it’s much higher because randomness can hit anywhere across that group

- So if you keep scaling this up to 1000s of tests
  - Like scanning genes for diseases and links
  - And running marketing experiments

**⇒** Anytime you’re running massive amounts of experiments, the odds of finding at least 1 false hit approaches near certainty

***You’re essentially trolling through noise until patterns emerge by accident like seeing faces in clouds or winning a lottery if you buy enough tickets***

- There’s a great website called [spurious correlations](https://www.tylervigen.com/spurious-correlations)
  - Peter has been playing with this website for a long time and went back to it recently
- It shares examples of how easy it is to find significant correlations, even very strong correlations between variables that clearly have nothing to do with each other, provided you’re willing to look at enough different combinations of variables
- One very silly example is a 98.5% correlation between the per capita consumption of margarine and the divorce rate in Maine [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f3-tylenol.png)

**Figure 3. An example of a spurious correlation**. Image credit: [TylerVigen.com #5,920](http://tylervigen.com)One of Peter’s personal favorites: if you look at the number of physicists in the state of California and the ranking of [Michael Schumacher](https://en.wikipedia.org/wiki/Mick_Schumacher) when he was driving in F1 between the year 2003-2012, the correlation was 0.971 (97.1%) [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f4-tylenol.png)

**Figure 4. Another example of a spurious correlation**. Image credit: [TylerVigen.com #3,705](https://www.tylervigen.com/spurious/correlation/3705_the-number-of-physicists-in-california_correlates-with_michael-schumachers-formula-one-ranking)

***But what’s most interesting about this is that the site also demonstrates how easy it is to come up with plausible sounding stories for why too clearly unrelated variables might be related***

- So they ask AI to come up with a train of logic linking the variables
  - If you consider the example of the California physicists and Michael Schumacher’s success, AI explains that by saying that the rising number of physicists in California drive innovation in the automotive industry, which leads to faster and more effective race cars that propelled Michael Schumacher to higher rankings
  - Which of course is ridiculous

**What do we know about why these ideas about associations with autism tend to persist even if the evidence can be shaky?**

- It comes down to the fact that it is literally impossible to disprove the link between any variable and autism the way that you can disprove other things such as the earth being flat
- Or even things that are really complicated like [resveratrol](https://peterattiamd.com/resveratrol-and-metabolic-health/) extending mammalian life where you have the luxury of doing randomized controlled experiment after experiment after experiment, all of which fail
  - Where you have such a high degree of probability that you’ve effectively disproved it
- But we can’t do that in epidemiology, and Peter thinks that’s why these ideas persist

## Evaluating the review paper that triggered the recent concern over acetaminophen and autism [A: 21:45, V: 22:34]

**Going back to the recent news, was there anything in particular that triggered the recent concern around acetaminophen and autism?**

- Not really other than a publication that we’ll talk about
- But the idea that autism might be linked to prenatal acetaminophen exposure isn’t new
- A handful of studies have reported very small associations between that exposure and outcome over the past decade, more or less
- The recent alarm was triggered by a systematic review of earlier research, which was [published](https://pubmed.ncbi.nlm.nih.gov/40804730/) in late August in a journal called *BMC Environmental Health*
- Peter was surprised to see this publication was not a meta-analysis
  - They didn’t pool the data from the studies to reevaluate the overall association or perform any new statistical tests
  - The authors of this paper just collected all the relevant studies they could find on the relationship between prenatal acetaminophen exposure and the risk of autism
  - They also looked at ADHD and some other neurodevelopmental disorders in non-overlapping human cohorts
  - And they shared the basic study details and results in one place and added some additional commentary
  - You can think of it as a review article

**Breakdown this** [**paper**](https://pubmed.ncbi.nlm.nih.gov/40804730/) **in more detail: what did it show?**

- In the case of autism, there were 6 observational studies that met their criteria for inclusion
- The authors reported that these 6 studies, “*Consistently reported a positive association between prenatal acetaminophen use and ASD (autism spectrum disorder) with an exposure response relationship observed in 4 of the 5 studies that evaluated the relationship.*”

But this isn’t actually true

- 2 of the 6 studies showed no significant association between use of acetaminophen used during pregnancy and the risk of autism in the offspring
- And only 3 of the included studies directly examined the potential dose-response relationship
- While the 4th [(by authors Ji and others)](https://doi.org/10.1001/jamapsychiatry.2019.3259) attempted to assess dose: dividing the participants into tertiles (groups of thirds) based on acetaminophen detected in a single blood test
  - This method had the advantage of using a quantitative biomarker instead of potentially biased patient questionnaires that try to get a recall
  - But since the measurement was based on just one sample taken during birth, it’s a very poor indicator of overall exposure during pregnancy
  - Acetaminophen is almost completely eliminated from the body within 24 hours
  - So all the blood tests from the Ji study really tell us is whether or not a woman happened to take Tylenol in the 24 hours leading up to delivery
  - Of course, a woman who had none before delivery might have taken Tylenol for weeks on end earlier in her pregnancy, or a woman could have taken Tylenol with delivery, could have had none up until that point
- We’re going to look at all of these studies in a moment, but Peter wants to point out 2 major limitations:
  - Most of these studies rely on questionnaires
  - The Ji study attempted to look at this biomarker, but it has significant limitations [which he just explained]
- The [largest study](https://jamanetwork.com/journals/jama/fullarticle/2817406) examining a dose response relationship was a study by lead author Ahlqvist (the senior author on that was Lee)
- Dr. Lee was [interviewed](https://jamanetwork.com/journals/jama/fullarticle/2839562) this week by *JAMA*: the dose response was only present in a partially adjusted statistical model where it disappeared in what was called the “fully adjusted model”
  - Peter will talk about this in a moment

***This suggests that the dose-dependent association between acetaminophen and autism (which is actually very important) was actually due to confounding variables that weren’t accounted for in the partially adjusted model, but were accounted for in the fully adjusted model***

- To take a look at this, the figure below is an analysis that Peter’s team pulled together by plotting the risk ratios from the studies included in this analysis

![](https://peterattiamd.com/wp-content/uploads/2025/10/f5-tylenol.png)

**Figure 5. Risk ratios from studies included in the** [**analysis**](https://pubmed.ncbi.nlm.nih.gov/40804730/) **pooled into a weighted summary to show the overall association based on all of the included data**.

- Peter was surprised that this figure was *not* in the paper because almost all review articles would do this (certainly a meta-analysis would’ve), but nevertheless, they didn’t
- And so we’ve done this and you can feel free to check us if you like, but we’ve taken all of the data out of their tables and simply put them into a pooled table
- Then the one thing we did at the end was pool it ‒ that’s what’s shown in red here

To orient you to this figure

- You’ve got all the names of the studies [on the left]
- The [Ahlqvist study](https://jamanetwork.com/journals/jama/fullarticle/2817406) is referred to as the Swedish study
  - At the very top, you’ve got the sibling controlled version of the Swedish study followed by the full cohort of the Swedish study, followed by a set of other studies
- Then the [Ji study](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2753512), you’re seeing 2 versions of this
  - You’re seeing the third tertile compared to the first tertile
  - And the second tertile compared to the first tertile
- You then have a couple of these other studies

**⇒** And then you can see that summary in red is where we’re showing the pool data

**Walk people through what this chart is showing us**

*What are the big insights that you and the team had from this chart*

**⇒** In this chart you can see that the overall association between acetaminophen use and autism is very small, corresponding to just ***a 5% increase in relative risk*** between exposed and unexposed children

- But there are a few other details that jump out at you when you’re looking at this
- The most obvious feature is that there is a very strong association coming from 1 very small study
  - In fact, the smallest study here, which is the [Ji study from 2020](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2753512)
  - But as discussed a minute ago, this study was done very different from the others: instead of comparing the risk between children who were versus were not exposed to acetaminophen during gestation, they then just divided the participants into 3 groups (or tertiles) based on the concentration of acetaminophen that was detected in the samples of umbilical cord blood
  - So then you could compare the risk in the first to the second and the first to the third tertiles respectively
- Measuring the concentration of acetaminophen in samples of umbilical cord blood might eliminate the issue of recall bias (which of course is a real issue as well where you have to ask a woman after she has the baby, how much Tylenol did you take during your pregnancy and when, etc.)

**⇒** But it still has a pretty big issue, which is acetaminophen does not stick around very long in the blood, and therefore we don’t really know how much the acetaminophen levels identified in cord blood at the time of delivery really tell us anything about the amount of acetaminophen that the woman took during pregnancy

- Now, some have pointed out that this isn’t a concern since the [study](https://pmc.ncbi.nlm.nih.gov/articles/PMC11705965/) published this past January by another group reported a positive correlation between 3 levels of self-reported acetaminophen use throughout pregnancy
  - The levels were: non-use, <14 days, or >14 days
  - And the level of acetaminophen detected in cord blood at birth

***However, the correlation was not that great. It was 72% and involved a completely distinct cohort.***

- There’s certainly a lot of room for error based on that
- Additionally, the Ji study mentions that all cord blood samples contained detectable levels of acetaminophen, but they don’t actually report how those levels differed across the tertiles (either averages or thresholds)

***So we have no idea how much acetaminophen we’re actually talking about here***

- However, they do report that 70% of the samples had no detectable levels of acetaminophen metabolites
  - Which would strongly suggest that the majority of participants had very minimal levels of acetaminophen exposure such as what you might see through drinking water

Peter explains, “*This essentially means that the comparison between the second and first tertiles was comparing subtherapeutic exposure to subtherapeutic exposure (telling us virtually nothing).*”

- And as further evidence of this, that [paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC11705965/) Peter just mentioned that looked at comparing cord blood levels to recall, it divided them into nothing up to 14 days, more than 14 days: it found acetaminophen in all cord blood samples, yet it showed that tertiles 1 and 2 were statistically identical

**⇒** The suggestion here is there’s some low level of hermetic Tylenol (or Tylenol metabolite) that we’re probably all exposed to that doesn’t really constitute an exposure

Another issue (and Peter actually thinks this is the single biggest issue) seems to be the **biased participant inclusion**

- The participants in the [Ji study](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2753) were enrolled in 1998 and followed for another 20 years, and anybody who dropped out before the end of that 20 year mark was excluded
  - Think about that for a moment: people are more likely to stay in an extended longitudinal study if they have a personal interest in the results
  - For instance, if they find their child has autism
- This is likely to affect studies on this subject, but it seems especially pronounced in the Ji paper as this study which was based in the US reported rates of autism in the participants at roughly 11%
  - Meaning when you look at all the participants who completed that study, 11% of the kids had autism
  - But for context, the general population currently (at that 5x increase) is 3%
  - And at the time of enrollment it was 0.7% (the enrollment was between 98-2004)
- The cohort used for this, the Ji study was the [Boston birth cohort](https://pubmed.ncbi.nlm.nih.gov/37745944/), which originally enrolled almost 9,000 mother child pairs, but among them preterm births were quite overrepresented over 35%
- By 2018, approximately 3000 dyads remained in the active follow-up cohort, presumably due to loss on follow-up
- And of those eligible dyads, slightly <1000 had available umbilical cord plasma samples and complete outcome data

***We have kind of a concentration, it would seem of [autism] cases due to all the reasons just stated***

Peter makes the point, “*One of the most important things to take away from this graph is the fact that the risk estimates summarized from all the studies what we’re sort of calling the pooled one here in red is virtually identical to the risk estimate derived solely from the 2024 Ahlqvist study, which was done in Sweden*.”

**⇒** The [2024 Ahlqvist study](https://jamanetwork.com/journals/jama/fullarticle/2817406) is commonly referred to as the Swedish cohort study

- The reason these studies are essentially identical is that the Swedish study included more than 10x the number of participants than all other studies combined

It’s actually worth just summarizing that again before we move on to the Swedish study…

- If you looked at this graph that we put together, you could very easily come to the conclusion that the Ji study is indeed the smoking gun
- But again, you have to remember the limitations of this:
  - Sample size is incredibly small relative to the others
  - You have the concentration effect where based on the nature of the study you concentrated and disproportionately counted cases of autism versus non
  - Then of course you have the collection methods where using this single sample of cord blood, which may have some association with maternal use during pregnancy, but is very unlikely to account for the actual nuanced differences in dose and exposure during pregnancy
- Think about that through the lens of any other thing:
  - If I could only measure how many donuts you ate on your birthday, it would be very difficult for me to impute how many donuts you eat over the course of a year
  - *Would it have a correlation?*
    - Probably, but it wouldn’t be strong enough to take to the bank if I was trying to use donut consumption as a marker of predicting heart disease

***So again, it’s very tempting when you look at these meta-analyses or in this case even just a review article to think more is better, but remember “a thousand sows ears makes not a pearl necklace”***

- (quoting the great James Yang who used to be one of Peter’s mentors in the lab)

## Breaking down the largest studies on prenatal Tylenol exposure and autism: is there a causal link? [A: 35:00, V: 36:20]

**Can you walk people through the Swedish study and what it found in more detail?**

- The [Swedish study](https://jamanetwork.com/journals/jama/fullarticle/2817406) was a very large prospective cohort study, and the general results indicate a small correlation between acetaminophen use by the mother during pregnancy and later life [ASD](https://en.wikipedia.org/wiki/Autism) in the offspring
- There were just under 2.5 million Swedish children included in the full cohort
- And the primary exposure metric was ever use of acetaminophen in pregnancy with dose serving as a secondary metric
  - So the primary outcome is binary: either you ever used acetaminophen or you did not
- Acetaminophen use was determined through a combination of prescriptions
  - Because in a single healthcare system, they have access to all the prescriptions and also through maternal interview with midwife or physician throughout the pregnancy
  - They don’t specify the number of interviews, and it probably varied across participants
- The median follow-up was about 13.5years

**⇒** The general cohort showed a very small but statistically significant positive association between prenatal acetaminophen exposure and autism

- The [hazard ratio](https://en.wikipedia.org/wiki/Hazard_ratio) was 1.05 and the confidence interval was 1.02 to 1.08
  - That means it showed a 5% increase in relative risk and the confidence interval of 95% confidence was significant because it did not cross the unity line
  - So anytime the error bars do not cross the unity line, it’s statistically significant
- Going back to the goal of studying study stuff: we always like to calculate an [absolute risk](https://en.wikipedia.org/wiki/Absolute_risk) exposure if we can

**⇒** The relative risk was a 5% increase; the absolute risk increase was 0.09% increase at 10 years

***That’s a very small absolute risk increase, less than 1/10th of 1%***

- The researchers then examined risk specifically in a cohort subset that was composed of matched sets of full biologic siblings

**⇒** They examined sibling pairs that were [discordant](https://en.wikipedia.org/wiki/Twin_study#:~:text=The%20presence%20of%20a%20given%20genetic%20or%20phenotypic%20trait%20in%20only%20one%20member%20of%20a%20pair%20of%20identical%20twins%20(called%20discordance)%20provides%20a%20powerful%20window%20into%20environmental%20effects%20on%20such%20a%20trait.) in acetaminophen exposure and found no significant difference in risk for autism between exposure and lack of exposure

- So why do this?
- The logic here is similar to any matched cohort study, but instead of merely matching based on general characteristics like age or sex, each exposed individual is matched to an unexposed sibling
- This means that exposed and unexposed groups on the whole should be relatively evenly matched in terms of several **confounding variables** related to home environment, and even many genetic factors
  - Each person in one group could be mirrored by somebody in the control group, so there shouldn’t be any systematic differences between the groups

**Walk people through what happened when they did the more detailed sibling analysis**

- When they did that concordant-discordant analysis, the correlation was entirely abolished when they compared and controlled for family, environment and genetics
  - This was not an identical twin comparison, it was just siblings, but obviously this is the best control you could get

***This suggests that the apparent link observed in the full cohort was likely due to confounding factors***

- Given these results, the authors of the Swedish study came to the same conclusion and they stated, “*The results of this study indicate that the association between acetaminophen use during pregnancy and neurodevelopmental disorders is a non-causal association. Associations observed in models without sibling control may be attributable to confounding.*”
- Now it’s important to note that the [review article](https://pubmed.ncbi.nlm.nih.gov/40804730/) that came out in August, in their analysis they state that the Swedish study only included siblings that were discordant for both exposure and outcome
- But this was *not* the case according to the Swedish study’s senior author

**⇒** Such a design would introduce what’s known as a [collider bias](https://en.wikipedia.org/wiki/Berkson%27s_paradox), where the selection criteria create a situation where the exposure and outcome are already related in some way

To illustrate why this double discordance selection doesn’t work, consider a very extreme example

- Imagine autism can only occur with acetaminophen exposure, but that acetaminophen exposure does not guarantee autism
  - So in biological parlance, we would say acetaminophen is necessary but not sufficient
- If you select only pairs that are discordant for both the exposure and the outcome, you would exclude all cases in which acetaminophen exposure did not result in autism
- Even if those sibling pairs accounted for the majority of sibling pairs discordant for the exposure
- In other words, you would falsely conclude 100% risk

Therefore, Peter believes that Lee (the senior author of the Swedish study) is correct in his assessment: ***once you correct for genetics and home environmental exposures, the risk of autism as it pertains to acetaminophen exposure is not causal***

> “*Stated another way, acetaminophen exposure prenatally in the Swedish cohort does not appear to be causally related to autism.*”‒ Peter Attia

**Do people who argue in favor of a potential link between acetaminophen and autism have anything to say about those results?**

*Is there any reason to question those results and question what that study said?*

- Yes, you should question everything
- One of the criticisms that’s been leveled against the Swedish study is that the overall rates of acetaminophen use in that study were much lower than what is observed here in the US or elsewhere in the world

**⇒** Only about 7.5% of the participating mothers in the Swedish study were consumers of acetaminophen, whereas some studies have reported up to 50% of mothers using acetaminophen during pregnancy

- Given this discrepancy, some have argued that the generalizability of the Swedish study is limited

**A Japanese study was just published**

- As it happens, [another large cohort study](https://pubmed.ncbi.nlm.nih.gov/40898607/) with a similar nested sibling analysis was just published a couple of weeks ago
  - This was after the August publication of the review article
  - And it supports the findings of the Swedish study
- The new study was conducted in a nationwide Japanese population and consisted of almost 220,000 children
- Of which almost 40% were exposed to acetaminophen during gestation
  - So very similar to the rates we see in the United States and in some of the other high exposure studies

**⇒** The associations reported from this Japanese cohort were similar to those in the Swedish study

- In the general cohort (so un-adjusting for siblings), prenatal exposure to acetaminophen was associated with a 6% uptick in autism rates
  - Recall in the Swedish study it was 5%
- This association did not reach statistical significance
  - The confidence interval was 0.98 to 1.15
  - The 95% confidence interval crossed the unity line
- When they did the sibling analysis, even this small trend towards an increased risk was completely abolished

***So when you take this Japanese study of nearly 220,000 children and pair it with the Swedish study of 2.5 million children, and both of them when done by this method abolish any causality, it’s very difficult to make a strong case for causality***

## Why observational studies can’t prove causality, the role of confounding variables, and the importance of frameworks like the Bradford Hill criteria [A: 43:30, V: 45:08]

**Can you walk people through why it’s so hard to make assumptions about causality based on just observational data?**

- You can think back to the sort of [spurious correlation site](https://www.tylervigen.com/spurious-correlations) that Peter was talking about earlier

***It really comes down to the potential influence of confounding variables that we are blind to***

- Dr. Lee, the senior author of the Swedish paper, was [interviewed](https://jamanetwork.com/journals/jama/fullarticle/2839562) by *JAMA* this week
  - It’s a great interview; it’s worth reading
- He talks about a great example many people have heard before, but it’s worth repeating

It’s the example of the strong correlation between ice cream consumption and drowning

- As we see rates of ice cream consumption go up, we see drowning deaths go up; and as one falls, the other falls
- Obviously, if you were being cheeky, you would say somehow eating ice cream is causing people to drown
- But of course, there’s a confounding variable, and the **confounding variable** is heat

Peter explains, “*The warmer it gets, the more people are likely to eat ice cream and separately, the more people are likely to swim. And therefore it’s this confounding variable that isn’t immediately obvious that explains both of these things.*”

- That’s really **the challenge of epidemiology**, and Peter doesn’t say that as a knock on epidemiology (it’s a legitimate challenge)
  - It’s that you can never, ever, ever identify all of the confounders
  - And therefore you are always at the mercy of wondering, “*Is there something I’m not seeing here that is what is actually explaining the causality?*”

**⇒** The only way to show causation unfortunately, is through randomized trials

- That’s the only way you can really be as close to 100% sure that you’ve established causality by doing a well controlled randomized control trial [RCT]
- But unfortunately, some questions do not lend themselves to that for either ethical or logistical reasons
- And clearly this question (the use of acetaminophen and autism) is one of those tricky questions
- So we’re not going to get an RCT to do this, and instead we’re going to have to glean what we can as best we can from epidemiology
- And that’s where we get to this set of guidelines that Peter talked about at the top of the show called the [Bradford Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria)

## Applying the Bradford Hill criteria: testing the case for Tylenol and autism [A: 45:45, V: 47:48]

**The Bradford Hill criteria are a set of 9 principles used to assess whether an observed association is likely to reflect a true causal relationship**

- Sir Austin Bradford Hill in 1965 put forth these criteria to help epidemiologic researchers examine their data when RCTs were not available
- They consider factors like: strength, consistency, specificity, temporality, biological gradient, biological plausibility, coherence, experimental evidence, and analogy
  - [summarized in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f6-tylenol.png)

**Figure 6. The Bradford Hill criteria**. Summarized from: [*European Journal of Epidemiology* 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8206235/)

**Let’s just go through the state of evidence for each of those criteria**

*So looking at acetaminophen and autism, what’s first on the list?*

**1 – Let’s start with strength. How large is the effect?**

- And the larger the effect, the more likely it is to be causal

Let’s start with a few obvious and famous examples

- The example of smoking is perhaps most notable
- Peter has never met a person who doesn’t understand or disputes the exposure relationship between cigarette smoke and lung cancer
- There’s nobody out there making the case that we need an RCT to determine that
- We don’t have an RCT. And why is it?
- It’s because if you run the smoking lung cancer data through the Bradford Hill criteria, it pops on many levels, but effect size is probably the biggest

**⇒** We’re talking about an effect size of 10x [on the association between smoking and lung cancer]

- 10X is a magnitude beyond what we normally would find in most biologic associations

**⇒** By comparison, the effect size here is 1.05x (that’s what a 5% relative risk increase is) [for the association between acetaminophen exposure in utero and autism]

- So this is smaller than associations that have been reported for many other things that we actually know are probably almost assuredly, *not causal* based on more data, such as
  - 1 – The [association](https://pubmed.ncbi.nlm.nih.gov/39174161/) between red meat consumption and type 2 diabetes, which is a 1.10 or a 10% relative risk increase per 100 gram per day increase in red meat
  - Of course, we’ve argued ad nauseam that those associations are almost assuredly picking up a confounder, which is [healthy user bias](https://en.wikipedia.org/wiki/Healthy_user_bias)
  - 2 – The [association](https://pubmed.ncbi.nlm.nih.gov/39174161/) between poultry consumption and the risk of type 2  diabetes 1.08

***Again, both of these examples are stronger associations [than the association reported for acetaminophen use and autism, which is 1.05]***

- 3 – An even clearer example would be the [meta-analysis](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2521826) of observational studies that reported that a higher leisure time physical activity was linked to a 5% higher increase in prostate cancer
- Again, we know that that is completely nonsensical, but that is what you get when you go trolling for signal in a sea of noise, you will eventually find it

***In other words, for this, the effect size is very weak***

- Here we’re defining weak as a subset of the type of epidemiology we’re looking at
  - And in this case, we’re looking at pharmacoepidemiology versus say, nutritional epidemiology or toxicology epidemiology
- Weak is generally regarded as 1.5 for pharmacoepidemiology, and the reason for it is just based on the pervasiveness of bias throughout these studies

**⇒** So when you’re showing up at 1.05 and the threshold for interesting is 1.5, you’re well below it

**2 – How consistent are the data linking autism and acetaminophen?**

- Actually they’re reasonably consistent
- Consistency just means how often does this show up across multiple studies and maybe even across multiple populations and different methodologies?
- A handful of prospective cohort studies have reported this positive association
- But remember, these associations tend to go away when you control for family environment or genetics
  - As we’ve seen in the 2 largest studies here that we’ve talked about
- So in general, population studies (i.e. no sibling control), the reported associations have varied somewhat in magnitude
  - Some have shown little to no association
  - But more often there is some association

**3 – Moving on to specificity. What do we know about specificity?**

- Specificity is asking the question basically how specific is the cause-effect relationship?
- If an exposure is associated with only 1 outcome or an outcome associated with only 1 exposure, causal relationship is more likely

**⇒** Here it’s very nonspecific because there are many variables that have been linked to autism risk

- Many [exposures have] much stronger lines of evidence than acetaminophen
  - For example, advanced paternal age, premature birth, air pollution exposure, and heavy metal exposure
  - These are all variables that have much stronger associations with autism
- We’re not dealing with a 1 versus 1, and some lack of specificity also exists in the other direction
  - There’s observational studies that have also reported associations between acetaminophen use and ADHD and language development

Peter explains, “*What you really want to look for if you want to check the specificity box is a one-to-one mapping.*”

- It’s not a deal breaker not to have it
- Cigarette smoking can cause lung cancer and other cancers and heart disease, and that doesn’t necessarily by itself at all diminish the fact that it causes lung cancer

**4 – Moving next on the list we have temporality. Does the exposure precede the reported effects?**

- It does and certainly to a first order
- It does meaning acetaminophen use comes before autism, but there really hasn’t been a consensus on the impact of timing of exposure or critical windows in which gestational exposure might be more problematic than others

If you look at the 2 researchers most known for their belief that acetaminophen exposure raises the risk of ASD ([Andrea Baccarelli](https://hsph.harvard.edu/profile/andrea-baccarelli/) and [William Parker](https://www.wplaboratory.org/williamparkerbio))

- They actually have conflicting views on the critical window of acetaminophen exposure
- Baccarelli, who is the author of the [review paper](https://pubmed.ncbi.nlm.nih.gov/40804730/) that came out in August that we’ve been talking about, he believes that maternal use during any part of pregnancy increases the risk to the fetus
- While Parker believes that prenatal exposure carries relatively little risk, provided the mother has a healthy liver to process the drug
- Parker instead argues that the greatest risk comes with exposure in the neonatal period or even during birth itself
  - Basically starting from the time the umbilical cord is clamped and onward

**5 – What do we know about dose dependency in this case?**

- Dose dependency (which you could also think of as biological gradient) says: the more you have the exposure, the more you should see the outcome
- Some studies have reported modest dose dependency based on the amount of time over which the mother was taking acetaminophen during pregnancy, but ***the results again have been pretty inconsistent***

**6 – Is there a plausible biological mechanism for exposure that might cause an effect?**

- The mechanism of action for acetaminophen is generally pretty poorly understood
- It’s kind of amazing that we don’t understand how such a ubiquitous drug actually lowers temperature and alleviates pain, so therefore we don’t really have much clarity on how it might ultimately lead to autism
- That said, [its effects are mediated](https://en.wikipedia.org/wiki/Paracetamol#Pharmacology) at least in part through inhibition of the synthesis of [prostaglandins](https://en.wikipedia.org/wiki/Prostaglandin) (which are molecules that contribute to pain and the inflammatory response)
- And since prostaglandins also play a role in neurodevelopment, some researchers have argued that acetaminophen leads to autism by disrupting neurodevelopmental pathways

***There’s no clear evidence of this, but there is at least what we would call biological plausibility, even if at best it might be a little bit hand wavy***

**9 – The next criteria is analogy**

- Analogy is where we compare the current body of evidence to another similar intervention with a more established effect
- Here we can look at the effect of another prostaglandin inhibitor in the CNS, which is [aspirin](https://en.wikipedia.org/wiki/Aspirin), which has shown to have modest protective effects against autism-like symptoms in animal studies
- This potential protective effect was also seen in the [Swedish cohort study](https://jamanetwork.com/journals/jama/fullarticle/2817406) that we talked about earlier in which sibling analyses showed a small but statistically significant reduction in autism risk with prenatal aspirin exposure
  - This was about a 13% relative risk reduction

***In other words, the analogy criteria would actually argue against it based on the dual inhibition of prostaglandins between both of these drugs***

**7 & 8 – The last 2 criteria don’t really help us much**

- **#8 Experiment**: is on whether or not we have intervention-based evidence to support these conclusions, but obviously we don’t have randomized control trials that can point to sub-analyses here
- An example of where we would be able to use this: if you’re looking at exercise epidemiology or nutrition epidemiology, you might not be able to answer the meta question with epidemiology, but you could do short-term well-controlled studies to show that, for example, 6 months of exercise improved blood pressure
  - Then you’d be more likely to believe that exercise could reduce the risk of cardiovascular disease if that’s what the large epi showed

***But again, we can’t do the short-term studies here***

- **#9 Coherence**: is the final metric, which is how do we tie the observational data with the *in vitro* and *in vivo* testing?

***And while we have some data here, they’re very inconsistent to the question***

- There are some studies that involve pre or perinatal acetaminophen exposure in mice and rats that have reported a few neurodevelopmental abnormalities, but they’ve been very inconsistent in the nature of the effect, and many have aligned quite poorly with the characteristics of autism
- For example, one study showed minor alterations in spatial learning and locomotor activity (which aren’t typically associated with ASD) but not anxiety-like behaviors (which often do accompany ASD)
- Additionally, some of the studies have used extreme doses, far exceeding the therapeutic doses used in humans as adults or children

## Putting it all together to answer the question: Does acetaminophen use during pregnancy increase the risk of autism? [A: 56:15, V: 59:03]

**What I think might be helpful is if you could just quickly summarize all the information we just talked about as it relates to acetaminophen and autism in looking at the Bradford Hill criteria**

- Let’s go through them one by one
- 1 – Strength is definitely weak
- 2 – Consistency is moderate
- 3 – Specificity is weak
- 4 – Temporality is modest and probably even strong
- 5 – Biological gradient is moderate
- 6 – Plausibility is weak
- 9 – Analogy actually provides evidence against this effect
- 7 & 8 – For coherence and experiment, we don’t really have meaningful data
  - Peter would classify coherence as probably somewhat weak

**Based on that, where do you land on looking at autism and acetaminophen?**

- To the first question Peter posed (which is: Is there even a statistical association?), obviously there is in an uncorrected or unadjusted analysis
  - Peter is really trying to refer to these adjusted analyses

***He would say yes, there’s probably some association between acetaminophen and autism***

- It’s not particularly large, but let’s assume it is there

*The* ***important question****, and the only question that really matters here is what is the probability that that association is causal?*

- Based on everything we’ve just talked about, inclusive of the running of the Bradford Hill criteria Peter would say the probability that the association between acetaminophen use by a mother and the development of autism of her child is a very low probability event to be causal

**⇒** ***Peter thinks the probability that if a woman takes Tylenol during pregnancy, it’s going to increase the probability that her child has autism is very low***

Peter adds, “*I’m sorry for using the word probability twice in one sentence, but that’s the challenge of trying to talk about this thing technically and accurately.*”

**What will be helpful now is kind of stepping back. Early on you mentioned that one of the things we do know is that there is an increase in cases of autism**

- Let’s assume there is causality here

*Is it enough to explain what we opened with which is a 5-fold increase in the prevalence of autism today?*

***Peter thinks the answer is unquestionably no***

- That’s a much more confident thing that we can say that there is essentially zero chance that maternal Tylenol use is the thing “responsible” for the rise in autism
- If it plays a role, it would be a very small role and it would have to be in this setting of another susceptibility
- Again, Peter still would argue that it is not playing a measurable role based on everything we’ve discussed

## If autism risk is overwhelmingly genetic, what explains the dramatic rise in autism diagnoses? [A: 59:15, V: 1:02:09]

**When you look at autism, what are some of the most important risk factors when it comes to that?**

- This is something Peter started looking into 3 or 4 years ago; so it was nice to go back and brush up on this literature and see what had been updated
- The long and short it is: ***genetics play a much larger role in autism risk than all other variables combined*** and account for an estimated 80-90% of the inter-individual variability and autism risk
  - The term for that is [heritability](https://en.wikipedia.org/wiki/Heritability)
- The heritability of a trait can be [assessed](https://en.wikipedia.org/wiki/Twin_study) through studies that compare monozygotic twins (aka identical twins) and dizygotic twins (aka fraternal twins)
  - This can also be done comparing what are called concordant-discordant identical twins or monozygotic twins, where you take identical twins that are raised in different environments
  - There’s lots of elegant ways to do this

What do we know?

- We know that monozygotic twins are obviously genetically identical
- Whereas dizygotic twins are genetically no more closely related than any other pair of siblings
- However, all twins are exposed to the same in utero environment and in most cases also raised in the same environment
  - Peter mentioned that there are some studies that do look at identical twins raised apart, but let’s put that off to the side

**⇒** This means that you can assume that dizygotic twins differ mostly in genetics, whereas monozygotic twins don’t really differ at all. You have a very elegant what we call “natural experiment”

***So if we see that a given trait is highly correlated between monozygotic twins but is often discordant between dizygotic twins, it must have a very significant impact from genes***

- Peter wants to pause before he goes any further because so much of what he’s about to say hinges on that

More about this beautiful “natural” experimental tool that we have

- It has come up in many of the podcasts he’s done in the past where we have talked about the heritability of various things
  - [[episode #362](https://peterattiamd.com/joshspitalnick/#:~:text=Using%20concordant%20and%20discordant%20twin%20studies) ‒ Understanding anxiety: defining, assessing, and treating health anxiety, OCD, and the spectrum of anxiety disorders | Josh Spitalnick, Ph.D., A.B.P.P., after (26:30)]
  - [[episode #330](https://peterattiamd.com/trennasutcliffe/#:~:text=heritability%20is%20largely%20determined%20by%20studying%20identical%20twins) – Autism, ADHD, and Anxiety: Understanding the rise in autism and a multidisciplinary approach to diagnosis and treatment of each condition in children | Trenna Sutcliffe, M.D., after (25:45)]
  - [[episode #280](https://peterattiamd.com/arthurbrooks2/#:~:text=What%20the%20identical%20twin%20studies) ‒ Cultivating happiness, emotional self-management, and more | Arthur Brooks Ph.D., after (17:40)]
  - [[episode #268](https://peterattiamd.com/wendychung/#:~:text=You%20can%20do%20this%20by%20looking%20at%20twins%20(identical%20twins%20and%20fraternal%20twins)) ‒ Genetics: testing, therapy, editing, association with disease risk, autism, and more | Wendy Chung, M.D., Ph.D., after (1:41:15)]
  - They’re almost always neuropsychiatric: the heritability of bipolar disorder, schizophrenia, major depressive disorder

How are they figuring out [heritability](https://en.wikipedia.org/wiki/Heritability) with twin studies?

- If you have **identical twins**, they are in the mother at the same time, therefore they are exposed to all of the same things while the mother is carrying them
  - And let’s just again, limit this to all twins that are raised together (which most are), then they come out and they’re also exposed to the same environment
  - [identical twins have the same genetics and the same environment]
- If you have **dizygotic twins**, they’re just siblings, they’re genetically obviously similar but *not**identical*, but they were exposed to the exact same environment inside the mother
  - But then once they’re born, they’re exposed to comparable things outside
  - [diozygotic twins have sibling genetics and a similar environment]

**⇒** If we see that a trait is highly correlated only in the identical twins, but the correlation is nowhere near as strong in the dizygotic twins, then we know that genetics are playing the role

An example everyone will appreciate: height and body weight

- Height has approximately an 80% heritability
- This shouldn’t be surprising to people
  - We understand that on average, tall parents have tall kids and short parents have short kids
  - Is it perfect? Not at all, but it’s 80% heritable
- Body weight, also quite heritable though not as much
  - It’s about 60% heritable

Back to the question about risk factor for autism

- In one of the studies that was included in the August review paper ([the Leppert paper](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2731903)), the primary study actually focused on how acetaminophen used during pregnancy correlated with the mother’s genetic predisposition for autism
  - And they didn’t find any significant association
- But if they had, it might suggest that a woman’s genetic predisposition towards autism might be the real variable behind the apparent association between acetaminophen and autism within the offspring
  - If the mother is predisposed towards autism, then the child is also likely at a higher than average risk of autism based solely on genetics
- But if a genetic predisposition also increases the likelihood that the mother might use Tylenol during pregnancy (which is entirely possible, given that autism is related to sensory perception, which is in turn related to pain sensing), then it would appear as if acetaminophen use and the child’s risk of autism were related, even though both associations might actually be explained by genetics
  - This is what Peter referred to above when he talked about a sort of middle confounding variable
  - The example he gave earlier about the temperature being the thing that relates ice cream consumption and drowning
  - In other words, genetics would constitute a confounding variable that influences both autism risk and acetaminophen use just as temperature is the confounding variable that influences both ice cream consumption and drowning

**If so much of autism risk is genetics, what can we say about genetics explaining the increase in autism rates over the past few decades?**

- They definitely don’t because genetics do not shift enough over those kinds of time scales to explain this 5, 6 or potentially even 7-fold increase in autism diagnoses that we’ve seen over 2 generations
- Now, some cases of autism do involve [*de novo* mutations](https://en.wikipedia.org/wiki/De_novo_mutation)

***But the majority of this increase seems to be explained by the increased awareness and expanded diagnostic definitions***

Let’s review a little bit of the history of how autism is diagnosed

- Over the last 40 years, there has been a progressive expansion of the diagnostic criteria for autism
- In 1987, the DSM-III made a revision which expanded from a strict infantile autism diagnosis or definition where the symptoms must occur between 30 months of age to something called **autistic disorder**
  - Which was defined by a checklist of symptoms that could manifest well beyond infancy
- Then in the 1990s and into the 2000s, a series of revisions in the DSM-IV and the ICD-10 created something called the **Pervasive Developmental Disorder family (the PDD family)**
  - Which encompassed autistic disorder, Asperger’s disorder, something called PDD not otherwise specified (which Peter talked about on the podcast with [Trenna](https://peterattiamd.com/trennasutcliffe/), it sort of became the all else bucket), Rett’s disorder, and then something called Childhood Disintegrative Disorder
  - Childhood Disintegrative Disorder is where kids actually go on to lose an already acquired skill: so if they acquire a language skill but then go on to lose it
  - So this further expands this recognition but with very inconsistent boundaries between the subtypes
  - The age of onset was typically before 3 years of age
- Then in 2013, the DSM-V collapsed all the PDD subtypes into a single diagnosis called **Autism spectrum disorder (ASD)**
  - It also relaxed the before age 3 requirement to symptoms in the early developmental period, and it introduced certain specifiers with or without intellectual or language impairment
  - And the severity levels were based on needed support
  - Other changes that were also made to some of the checklist criteria

**⇒** The main issue is that an array of disorders are now lumped together under this ASD umbrella, which has vastly increased the number of individuals who fall under that umbrella

- The estimates for how much this dramatically increasing diagnostic aperture has contributed to the increase in prevalence vary

**⇒** The analyses that have looked and attempted to assess this directly report that the expanded criteria account for 40 to 60% of the increase, and furthermore, increased awareness accounts for 20 to 30% of the increase in diagnoses

- A [2009 study](https://pubmed.ncbi.nlm.nih.gov/19737791/) found that roughly 26% of the increase in autism diagnoses in California between ‘92 and 2005 were attributable specifically to cases in which children had previously been diagnosed with mental retardation and were then subsequently screened for autism
- So when Peter hears people say, “*Oh yes, but even the cases of severe autism are increasing,*” not necessarily
  - It could be that kids that we now think have severe autism (for example, being nonverbal) were actually previously diagnosed as something else
- Racial and socioeconomic disparities in autism diagnosis have narrowed or reversed over the last 30 years
  - Which the CDC and others suggest is evidence of more widespread awareness and screening

***If you take these 2 together (40-60% + 20-30%), that’s really the lion’s share of what explains this increase***

## Other risk factors for autism: parental age, maternal health, environment, and where Tylenol fits in [A: 1:09:15, V: 1:12:41]

**Do we know what else might be accounting for the increase, not what we just covered?**

The next clearest contributor is **advancing parental age**, both in mothers and fathers

- Although the paternal age probably seems to play a greater role
- This is seen mostly in the US and other high income countries, and v***arious studies have put this at about 5-15% of the increase in autism prevalence***
- [Average] **paternal age** has advanced in the US from 27.6 years when Peter was born [in 1973] to 31.1 years, 10 years ago [in 2015]
- The proportion of fathers with more advanced paternal age has also increased
  - So **fathers over 40** at the time of offspring birth has more than doubled, going from 4.1% to 8.9%
  - And **fathers over 50** has also doubled going from 0.5% to 0.9%
- Trends in **maternal age** have also increased during the same average period by about 3 years
- The CDC reports that between 2016-2023, the proportion of **births in women aged 35 and over** has increased from 10 to 12.5%

Furthermore, there are **other factors such as**: maternal obesity, metabolic disease, preterm birth, and air pollution that are also widely recognized to contribute to the remaining 15% of unattributable factors

Let’s talk briefly about these other factors

1 – **Maternal health**, including metabolic health is an important factor

- There’s no question that **obesity** rates among women at the time of conception have risen steadily
- A [meta-analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC12045326/) of global data reports, obesity rates in pregnancy have more than tripled in the last three decades
  - From a pre-1990 rate of 4.7%
  - To 16.3% in the decade from 2010 to 2020
  - And rates in the United States are even higher than those averages

2 – According to a [2024 CDC report](https://www.cdc.gov/nchs/data/nvsr/nvsr73/nvsr73-01.pdf), rates of **early term births** rose during that period as well

- Under 37 weeks [preterm births] and early preterm (37-38 week births) rose during that period as well
  - So **preterm births rose** from 7.74% of all singletons in 2014 to 8.67% in 2020
  - While **early term birth rates rose** from 24.31% to 29.07%
- Sources that track earlier years indicate a steady rise in preterm birth from at least 1980 to 2005, after which rates dipped slightly before beginning to rise again in the 2010s
- Some of this, of course, could be attributed to advanced maternal age, which is in and of itself a risk factor for preterm birth

3 – Globally **air pollution** has been increasing

- We’ve talked about this a lot on the podcast; we talk a lot about the [PM 2.5s](https://en.wikipedia.org/wiki/Particulate_matter#:~:text=fine%20particles%2C%20designated%20PM2.5%2C%20with%20a%20diameter%20of%202.5%C2%A0%CE%BCm%20or%20less%3B%5B5%5D)
  - [[newsletter](https://peterattiamd.com/are-safe-levels-of-air-pollution-really-safe/) on this topic]
  - Truthfully, we’ve always talked about it more through the risk of all-cause mortality and cancer mortality, but here is yet another issue
- We’ve seen a 38% increase in PM 2.5s
  - These are particles that are sub 2.5 microns in the air
  - Obviously you can’t see these things, you don’t feel these things
  - But because of how small they are when inhaled these particles can go all the way into the bloodstream because of their ability to go straight down into the most distal part of the air sacs of the lung and cross the diffusion barrier where oxygen and CO2 are transmitted
- Air pollution is driven largely by the industrialization of China and India
- And while air pollution in the US has been coming down, we’ve seen in the last decade an uptick in this mostly attributed to wildfires

**Looking at what you just covered in those 3 buckets, in that last bucket of environmental factors, is it possible that acetaminophen could be in that bucket as well?**

- Yes, it is possible

Peter makes clear, “*Nothing I have discussed today, none of the analysis we’ve done or anybody has done has shown dispositively that we can disprove the role, the causal role between acetaminophen and pregnancy and the elevated autism risk*.”

- It is impossible to disprove anything
- We can’t disprove anything here: that’s the nature of what we’re doing epidemiologically

> “*But the point here is look at how many other variables we have that have a either demonstrated (i.e. genetically) or much, much stronger associations that even if acetaminophen plays some causal role, it is going to be very, very low*.”‒ Peter Attia

- Think back to what we talked about on the **absolute risk increase:** this was a 0.09 absolute risk increase with a 5% relative increase
- So even if you assume that to be causal, this would be a very, very, very small contributor relative to other modifiable things such as maternal obesity, metabolic health, air pollution, paternal and maternal age
  - Peter doesn’t assume it to be causal because when the twin analysis was done, all of that vanished in addition to everything else we’ve talked about

**Peter’s takeaway**: there are many things we should be looking at before acetaminophen

## Medication use during pregnancy: balancing risks, benefits, and FDA categories [A: 1:15:15, V: 1:19:01]

**What advice would you give to women who are pregnant about the use of acetaminophen?**

- As a general rule, Peter would advise women to stop taking medications when they get pregnant
- But medications aren’t the only potential threat to the unborn child: the health of the mother is also important to the unborn child
- The medical conditions that these medications are intended to treat can sometimes also create problems indirectly or directly, but we have to balance that against the use of the medication and what’s already being addressed

An example: if a woman has an elevated [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B)

- Should she be taking a lipid lowering medication?
- But does she need to take that during pregnancy?
- Peter would argue no
- Why? Because 9 more months of additional apoB exposure are not a meaningful threat to a young woman’s life, whereas there may be some downside in suppressing her cholesterol synthesis if we’re talking about a [statin](https://en.wikipedia.org/wiki/Statin)

Another example: [thyroid hormone](https://en.wikipedia.org/wiki/Thyroid_hormones#)

- Conversely, when we think about something like thyroid hormone where we’ve established actually quite safe use during pregnancy
- If a woman is requiring thyroid hormone because she has [hypothyroid](https://en.wikipedia.org/wiki/Hypothyroidism), to withhold that from her during pregnancy would pose enormous risk to her and by extension to the child.

It gets interesting when we talk about other classes of drugs

- For example, [GLP-1 drugs](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist): they’re very common, and of course the question is, should women stop these during pregnancy?
- Peter doesn’t have enough data to comment
- But he can tell you how one would have to think about this
  - If a woman’s taking a GLP-1 receptor agonist is the difference between her having gestational diabetes and not, maybe it’s considered
  - Of course, we would typically turn to something like [metformin](https://en.wikipedia.org/wiki/Metformin) as a first line therapy there where we have much more ongoing safety data

***The point here is you have to be able to consider this in a nuanced way, which is the single most important thing for the healthy development of a fetus is a healthy environment in utero, and sometimes that may actually require the mother taking a medication***

**With that kind of background, it might be worth going back to the historical FDA risk categories and just walking through what they are again**

*And then even highlighting a few different medications that are included in each category so people just have a much better idea of how this is done in practice*

- The good news is you don’t have to guess here. You should be talking about this with your doctor
- [the categories are summarized in the table below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f7-tylenol.png)

**Figure 7. FDA pregnancy categories**. Adapted from: [Wikipedia](https://en.wikipedia.org/wiki/Pregnancy_category#United_States)

Category A

- This category is pretty small, we’ve only got about 2-5% of drugs here
- We have controlled studies in humans that demonstrate no risk to the fetus in any trimester
- Examples: the most obvious here are [T3, T4](https://en.wikipedia.org/wiki/Thyroid_hormones), prenatal vitamins, that kind of stuff

Category B

- Animal studies show no risk (for the most part, or animal risk is not confirmed)
- Adequate human epidemiology generally shows safety
- This is about 15-25% of drugs
- Examples: a number of antibiotics in here, things like Benadryl, as Tylenol is in here as is metformin

Category C

- Animal studies show some adverse effects, but no real adequate human studies
- These are drugs that are supposed to be used provided there’s enough benefit for the mother to justify it
- Most drugs fit in this category, 60-70%
- Examples: gabapentin, amlodipine (which is a blood pressure medication), trazodone (for sleep), GLP-1 agonists, certain SSRIs or (antidepressants), and even very short-term use of narcotic pain medication

Category D

- Here we have positive human fetal risk data, but in some cases the benefits might outweigh it
- Examples: a couple of seizure medications (valproic acid and phenytoin), lithium (which should be used to treat bipolar disorder), NSAIDs (which in the third trimester should be discontinued for the reasons discussed earlier), and even long-term use of narcotics

Category X

- Drugs where there’s simply no reason for women to take these during pregnancy
- Examples: statins, methotrexate, and drugs that are known to cause [teratogenic defects](https://en.wikipedia.org/wiki/Teratology) in the child

## Considerations for taking Tylenol during pregnancy [A: 1:19:30, V: 1:23:48]

**One of the other things you talked about early on in the beginning was not only do you have to look at the risk of taking the medication, but you also have to balance that in terms of what else could be going on during pregnancy**

*How do you think about the use of acetaminophen in terms of balancing the benefits that it can have for people who are pregnant?*

- Yes, we need to look at the other side of this equation: What’s the risk of not taking Tylenol during pregnancy?
- In many cases, maybe the trade-off is just an annoying headache or some other discomfort that the mother can sort of power through
  - And in those instances, maybe she’s just better off skipping the Tylenol and trying to get to bed

> “*We can’t discount the mother’s well-being and the importance of that as well, not just for herself but her well-being in the context of how important it’s for the unborn child.*”‒ Peter Attia

- And we certainly shouldn’t trivialize the likelihood and presence of more intense debilitating pain with pregnancy
- If the pain is bad enough that she’s unable to get out of bed for several days on end, that in and of itself poses a risk to the child
- Let’s not forget, **Tylenol is also used to reduce fever**, and for this purpose, current evidence would suggest that the scales clearly tip in favor of using Tylenol since exposure to fever itself carries a number of known risk factors to a developing fetus

Known risks of fever during pregnancy to children

- For example, children born to mothers who experience fevers during pregnancy, especially during the first trimester, are at a significantly **higher risk of certain birth defects** than children who weren’t exposed to fever in utero
  - Various [analyses](https://pubmed.ncbi.nlm.nih.gov/24567014/) have reported anywhere from 25-200% higher risk for cleft palate or neural tube defects
- In fact, prenatal exposure to fever and maternal infection are also separate risk factors for **autism** and other neurodevelopmental disorders
  - Several studies have reported that exposure to maternal infection is associated with an increase in autism risk by 25-40%
  - While exposure to maternal fever is typically associated with an even greater risk, up to 200% across most analyses

**⇒** Some [research](https://pubmed.ncbi.nlm.nih.gov/22562209/) has reported that these risks are attenuated when the mothers actually take a fever-reducing medicine like Tylenol

Peter makes the point, “*All of these associations between infection and fever exposure and autism may actually be contributing to the apparent correlation that we see between autism and autism risk*.”

- Given that acetaminophen is by far the safest option for reducing fever and pain relief during pregnancy
  - Because remember NSAIDs and opioids or category D
- If a woman does have an infection during pregnancy, there’s a good chance she might try to ease the fever or the aches with Tylenol

***In other words, it could be that it’s the infection that is the issue, and the signal we’re picking up and measuring is the acetaminophen use***

## Final thoughts: critical thinking, balanced risk assessment, and the importance of context when evaluating medications like Tylenol during pregnancy [A: 1:22:30, V: 1:26:53]

- Some people might be wondering, why did you just take so long to explain all this to us?
  - Why don’t you just give us the answer?
  - I just want the sound bite, man

Peter’s reply, “*If you just want sound bites, you’re never going to learn*.”

- Honestly, if you just want sound bites, this isn’t the podcast for you
- But if you actually want to be able to learn to think for yourself, then that’s what we’re here to do
  - And that’s the reason we killed ourselves over the past week to put together the most thorough gathering of all the data we could find and the most intense night-weekend analysis possible
- We want to help you think about this stuff because this is not going away
  - This is going to be a forever game of whack-a-mole
  - There is always going to be a bad guy
  - Peter is not going to be here every time to do a 2-hour podcast on helping you think through why exposure x leads to disease Y
- He doesn’t want to sound like a scolding teacher, but the truth of the matter is we live in a world today where people don’t want to think
  - People use stupid vehicles like social media to get their information, and they don’t want to read the fine print
  - And even if they do read the fine print, they just want to outsource thinking to somebody else
- Peter appreciates that those of you who are still watching this have outsourced your thinking for the past couple of hours to him

***But honestly, we’re never going to get out of this rut of people not knowing how to think critically unless everybody starts taking steps to try practicing this on their own***

**Peter would encourage you to go through this and follow the logic as he’s laid it out here with the help of his team**

- We’re going to include amazing show notes to this podcast like we do for every podcast
  - Although for this episode, it will be not behind a paywall
  - Normally, our show notes are only there for our subscribers
- And when the next thing comes up (because it will come up, whether it’s this drug or that drug or this intervention, it’s just going to keep happening over and over again), you’ve got to be able to kind of go through this type of thinking
  - If you don’t want to, that’s fine (it is hard)
  - But then you’ve sort of forfeited your right to have an opinion on it

**The upshot here is that any one potential risk can’t be considered in isolation**

- You have to look at the full picture
  - The risk of a given intervention like Tylenol
  - As well as the potential risks of not taking Tylenol
  - As well as the nature and magnitude of those risks
- For **minor aches and pains**, maybe it’s best to just err on the side of caution and skip the acetaminophen
- Whereas when the **pain** becomes really a nuisance and it might interfere with you doing things that are otherwise going to help you provide the best environment for your fetus then judicious use of acetaminophen can help (with the oversight of your physician)
- For **maternal fever**, the balance is clearly leaning towards the use of acetaminophen

Peter emphasizes, “I *want people to understand that the strength of these associations is very small and in many cases vanishes altogether when you apply some rigorous statistical corrections that look at the most important variables that we should be considering here, which is genetic and environmental.*”

- He hopes that this exercise has indeed provided benefit to all of you, not just as we consider this particular question, but as we consider the onslaught of questions that we’re going to see in the future

---

## Selected Links / Related Material

**Newsletter about the difficulty of thinking scientifically**: [Why we’re not wired to think scientifically (and what can be done about it)](https://peterattiamd.com/wired-think-scientifically-can-done/) | *PeterAttiaMD.com* (January 10, 2018) | [3:30]

**Newsletter on how we are not wired for critical and scientific thought**: | [4:00]

**Prevalence of autism**: [Data and Statistics on Autism Spectrum Disorder](https://www.cdc.gov/autism/data-research/index.html) | CDC (2025) | [16:15]

**Website of spurious correlations**: [spurious correlations: correlation is not causation](https://www.tylervigen.com/spurious-correlations) | [19:45, 44:15]

**Recent review of the relationship between prenatal acetaminophen exposure and the risk of autism**: [Evaluation of the evidence on acetaminophen use and neurodevelopmental disorders using the Navigation Guide methodology](https://pubmed.ncbi.nlm.nih.gov/40804730/) | *BMC Environmental Health* (D Prada et al. 2025) | [22:30]

**Studies included in the previous review that were discussed**:

- [Association of Cord Plasma Biomarkers of In Utero Acetaminophen Exposure With Risk of Attention-Deficit/Hyperactivity Disorder and Autism Spectrum Disorder in Childhood](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2753512) | *JAMA Psychiatry* (Y Ji et al. 2019)
- [Acetaminophen Use During Pregnancy and Children’s Risk of Autism, ADHD, and Intellectual Disability](https://jamanetwork.com/journals/jama/fullarticle/2817406) | *JAMA* (V Ahlqvist et al. 2024 [aka the Swedish study])
- [Association of Maternal Neurodevelopmental Risk Alleles With Early-Life Exposures](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2731903) | *JAMA* (B Leppert et al. 2019)

**Interview of Brian Lee about his study in** ***JAMA***: [Acetaminophen Use in Pregnancy—Study Author Explains the Data](https://jamanetwork.com/journals/jama/fullarticle/2839562) | *JAMA Network Medical News* (K Schweitzer September 29, 2025) | [25:30, 44:30]

**Study published in January reporting a positive correlation between acetaminophen use and adverse neurological outcomes in childhood**: [Acetaminophen Use in Pregnancy: A Comparison of Self-Reported Intake with Maternal and Newborn Biomarker Measures](https://pmc.ncbi.nlm.nih.gov/articles/PMC11705965/) | *Clinical Epidemiology* (P Guo et al. 2025) | [29:15]

**Recent Japanese study of acetaminophen use and ASD**: [Maternal Acetaminophen Use and Offspring’s Neurodevelopmental Outcome: A Nationwide Birth Cohort Study](https://pubmed.ncbi.nlm.nih.gov/40898607/) | *Paediatric and Perinatal Epidemiology* (Y Okubo et al. 2025) | [42:45]

**Episode of** ***The Drive*** **with Trenna Sutcliffe**: [#330 – Autism, ADHD, and Anxiety: Understanding the rise in autism and a multidisciplinary approach to diagnosis and treatment of each condition in children | Trenna Sutcliffe, M.D](https://peterattiamd.com/trennasutcliffe/). (January 6, 2025) | [1:07:15]

**2009 study reporting 26% increase in ASD diagnosis based on the change in diagnostic criteria**: [Diagnostic change and the increased prevalence of autism](https://pubmed.ncbi.nlm.nih.gov/19737791/) | *International Journal of Epidemiology* (M King, P Bearan 2009) | [1:09:00]

**Meta-analysis of trends in maternal obesity**: [Global trends in prevalence of maternal overweight and obesity: A systematic review and meta-analysis of routinely collected data retrospective cohorts](https://pmc.ncbi.nlm.nih.gov/articles/PMC12045326/) | *International Journal of Population Data Science* ( L Kent et al. 2024) | [1:12:15]

**Increase in rate of pre-term births**: [Shifts in the Distribution of Births by Gestational Age: United States, 2014-2022](https://www.cdc.gov/nchs/data/nvsr/nvsr73/nvsr73-01.pdf) | *National Vital Statistics Reports* (J Martin, M Osterman 2024) | [1:12:15]

**Newsletter about the risks from air pollution**: [Are “safe” levels of air pollution really safe?](https://peterattiamd.com/are-safe-levels-of-air-pollution-really-safe/) | *PeterAttiaMD.com* (March 12, 2022) | [1:13:30]

**Fever during the first trimester increases the risk of birth defects**: [Systematic review and meta-analyses: fever in pregnancy and health impacts in the offspring](https://pubmed.ncbi.nlm.nih.gov/24567014/) | *Pediatrics* (J Drier et al. 2014) | [1:22:00]

**Risk to the child from fever or infection during pregnancy is attenuated by taking fever-reducing medicine**: [Is maternal influenza or fever during pregnancy associated with autism or developmental delays? Results from the CHARGE (CHildhood Autism Risks from Genetics and Environment) study](https://pubmed.ncbi.nlm.nih.gov/22562209/) | *Journal of Autism and Developmental Disorders* (O Zerbo et al. 2013) | [1:22:45]

---

## People Mentioned

- [Andrea Baccarelli](https://hsph.harvard.edu/profile/andrea-baccarelli/) (Professor of Environmental Health and Dean of the Faculty at Harvard T.H. Chan School of Public Health, expert in epigenetics, environmental epidemiology, and effects of air pollution on human health; his work identified a link between acetaminophen and autism)
- [William Parker](https://www.wplaboratory.org/williamparkerbio) (Retired Associate Professor at Duke University; Visiting Scholar, Department of Psychology and Neuroscience at the University of North Carolina, Chapel Hill; CEO [WPLab](https://www.wplaboratory.org/), Inc. a 501(c)(3) nonprofit organization conducting research and education on the causes of chronic inflammatory disease in high-income regions; [published](https://pmc.ncbi.nlm.nih.gov/articles/PMC9056471/) on the lack of safety of acetaminophen for neurodevelopment)

---