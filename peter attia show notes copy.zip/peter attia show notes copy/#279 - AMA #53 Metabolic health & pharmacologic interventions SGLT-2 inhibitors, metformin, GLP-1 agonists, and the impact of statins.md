# #279 – AMA #53: Metabolic health & pharmacologic interventions: SGLT-2 inhibitors, metformin, GLP-1 agonists, and the impact of statins

**Source:** [https://peterattiamd.com/ama53/](https://peterattiamd.com/ama53/)

---

In this “Ask Me Anything” (AMA) episode, Peter explores various pharmacologic tools commonly utilized to improve metabolic health and treat diabetes, including SGLT-2 inhibitors, metformin, and GLP-1 agonists. He examines the available data on these drugs, assessing their comparative effectiveness and their potential in the context of lifestyle interventions. Additionally, he offers insights into whether SGLT2 inhibitors hold promise as geroprotective agents beyond their effects on glycemic control. Next, Peter analyzes the relationship between statin usage and the risk of developing insulin resistance and type 2 diabetes, investigating possible causal pathways and providing insights into strategies for risk reduction. He offers insights on monitoring adverse statin effects and evaluating the need for adjustments, ultimately weighing the trade-off between the risk to overall metabolic health against the benefits of reducing apoB levels through statin use.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #53 show notes page](https://peterattiamd.com/ama53). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Pharmacologic tools for improving metabolic health, and the relationship between statins and insulin resistance [2:00];
- SGLT-2 inhibitors: how they work and help to manage type 2 diabetes [4:15];
- The history of SGLT2 inhibitors—from discovery to the current state [10:15];
- Comparing the various FDA-approved SGLT2 inhibitors [15:00];
- Other beneficial effects of SGLT2 inhibitors outside of glycemic control [20:15];
- Exploring SGLT2 inhibitors as potential geroprotective molecules [22:45];
- The side effects and risks associated with SGLT2 inhibitors [31:45];
- Medications, lifestyle interventions, and other considerations for treating diabetes and improving metabolic health [37:45];
- Metformin as a tool for pre-diabetics, and how metformin compares to lifestyle interventions [44:00];
- How GLP-1 agonists compare to metformin and SGLT2 inhibitors in terms of glycemic control and weight loss [49:15];
- Exploring the relationship between statin use and the risk of developing insulin resistance and type 2 diabetes [52:30];
- Possible mechanisms of statin-induced insulin resistance and diabetes, and potential mitigation strategies [1:04:30];
- How to monitor for adverse effects of statin use and assess the need for adjustments [1:11:45];
- Weighing the benefits and risks of statin use: does the diabetes risk outweigh the benefits of lowering apoB with a statin? [1:15:30];
- Parting thoughts [1:20:45]; and
- More.

§

The Peter Attia Drive

Metabolic health & pharmacologic interventions: SGLT-2 inhibitors, metformin, GLP-1 agonists, and the impact of statins

§

## Show Notes

§

## Pharmacologic tools for improving metabolic health, and the relationship between statins and insulin resistance [2:00]

**Today’s conversation will be on two topics**

The first discussion will be like a follow-up to [AMA #51](https://peterattiamd.com/ama51), which was on metabolic disease

- Metabolic disease is one of the “four horsemen” with the other three being cardiovascular disease, neurodegenerative disease, and cancer
- In AMA #51, Peter explained how metabolic disease feeds those other types of diseases.
- Also discussed how to measure and evaluate your metabolic health as well as the lifestyle factors that can contribute to improved metabolic health
- However, one thing that was missing from AMA #51 was the pharmacological options for people to improve their metabolic health — this is part of today’s discussion
  - The main pharmacological options include SGLT2 inhibitors, metformin, GLP-1 agonist, and a few others
  - Peter will also cover whether any of these drugs have a geroprotective benefit for people who’s metabolic health is otherwise in good shape

The second part of today’s episode will be about the relationship between statins and insulin resistance

- Peter will cover all the issues and data on statins, not just the relationship to T2D
- But much more broadly around the relationship between statins and metabolic health
- He will, of course, put this in the broader context of net benefit vs net harm

## SGLT-2 inhibitors: how they work and help to manage type 2 diabetes [4:15]

⇒ SGLT-2 inhibitors were discussed on [episode #148 with Rich Miller](https://peterattiamd.com/richardmiller/)

\*\*\*

- SGLT2 stands for sodium-glucose cotransporter protein-2
- The nephron is the functional cellular unit of the kidney and in the proximal tubule
- The kidney is a unique organ in that it’s really a tiny organ, but it is overrun with blood
- There’s lots of plasma that’s passing through the renal arteries and the reason for that is, of course, the importance of filtration

**Analogy to help explain how the kidney works**:

- If you were a kid and your mom said, “I want you to go into your room and clean your dresser out where you have your socks, you underwear, your t-shirts, your shorts, and all that stuff”
- It’s tempting to go in there and, while everything is in the dresser, try to organize it and pull things out that you don’t need and keep what you do need in there
- The kidney doesn’t work that way
- The kidney has one way of filtering, which is it goes to the dresser and takes every single thing out, and then it simply pulls back in what it wants to keep
- That’s very different than the kidney identifying things that we don’t need/want and simply pulling them out
- Why? ⇒ Because in the case of the ladder, it assumes evolutionarily that the kidney will forever be able to recognize bad things
- But in the former, it assumes evolutionarily that the only thing the kidney needs to understand is what is good
- And obviously that’s a much better strategy because that’s a finite set of things as opposed to an infinite set of things

The way this works at the cellular level:

- As plasma rolls through the kidney, it pulls everything out—Glucose, sodium, potassium, magnesium, chloride, you name it
- As the filtrate runs through the kidney, it selectively pulls back into the circulation the things that it knows we need
- And that’s why the kidney is the *most important organ in the body for regulating our electrolytes*

Glucose

- One of those things that happens to get filtered is glucose
- And even though the kidney’s job is not really managing glucose concentration, there’s an interesting opportunity to prevent the kidney from reabsorbing all of the glucose that it immediately shunted out when the plasma came through the kidney in the first place
- in other words, even though the kidney’s goal is not interfering with glucose concentration the way it is doing deliberately with sodium, potassium, chloride, et cetera, there’s an opportunity

![](https://peterattiamd.com/wp-content/uploads/2023/11/f1-ama53.png)

**Figure 1.** Source: [White, Jr. Clin Diabetes Jan 2010](https://diabetesjournals.org/clinical/article/28/1/5/31231/Apple-Trees-to-Sodium-Glucose-Co-Transporter)

- In the figure above, you’ll see on the left-hand side of it a little purple box, and that’s called SGLT1 and 2 (we’re talking about the sodium cotransporter-2 here)
- You can see that it pulls sodium and glucose into the cell together
- If you had a way to block that purple thing, you would be able to keep more glucose in the urine
- The right-hand side is where things are returning to the plasma going back to the body
- The left-hand side is things that will be excreted in the urine
- So when you block SGLT2, you prevent sodium and glucose from being reabsorbed by the cell to then be put back into the plasma, and therefore, you will pee out more sodium and glucose
- Therefore, SGLT2 inhibitors have become a very attractive solution for people whose blood glucose is too high

Think about this: ***How do we manage the problem of type 2 diabetes?***

- You can manage it by reducing glucose, by increasing insulin sensitivity, and/or by increasing insulin itself
- With SGLT2 inhibitors, this is a strategy that says, “Here’s how we’re going to lower glucose.”
- Metformin, which we’ll talk about as well, is also a glucose-lowering strategy
- GLP-1 on the other hand tends to be probably more of an insulin-sensitizing strategy, coupled with a glucose-lowering strategy by the fact that you simply eat less

## The history of SGLT2 inhibitors—from discovery to the current state [10:15]

**The origin of SGLT2 inhibitors**

- It’s not an uncommon story in pharmacotherapy where there is a naturally occurring substance that sparks interests of a drug company/scientist
- A scientist will come in and figure out a way to make a better version of the molecule that occurs in nature (metformin and statins are naturally occurring molecules)
- Naturally occurring molecules have pros and cons, but that’s an impetus for further development

The same is true here for the SGLT2 inhibitors

- There’s a chemical called [phloridzin](https://en.wikipedia.org/wiki/Phlorizin) primarily found in apples
- It was originally isolated in the 17th century, and it was part of the botanical solutions to people with various infectious diseases like malaria and things of that nature
- However, when people were given phloridzin, they developed glucosuria (glucose in their urine)
- This became a very important early diagnostic step in the treatment of type 2 diabetes
- [Sir William Osler](https://en.wikipedia.org/wiki/William_Osler)—the father of modern medicine—used to actually taste his patient’s urine to determine if they had type 2 diabetes
- So here you took patients who didn’t have diabetes, and you could induce this idea that we saw in people with diabetes, which they’re peeing out glucose
- If we’re giving this drug to people and they’re peeing out glucose, and they’re not diabetic to begin with, then this drug is doing something that is impacting that pathway
- And that’s effectively what led to the development of these drugs

![](https://peterattiamd.com/wp-content/uploads/2023/11/f2-ama53.png)

**Figure 2.** Chemical structure of Phlorizin and Dapagliflozin. Source: [Wang et al. Chemical Papers Sept 2014](https://www.degruyter.com/document/doi/10.2478/s11696-014-0615-x/html) and [de Meira et al. Int J Analytical Chem. July 2017](https://www.hindawi.com/journals/ijac/2017/2951529/)

- We have a picture of phloridzin next to a modern-day SGLT2 inhibitor, you can see the similarity
- Phloridzin naturally occurring on the left and an SGLT2 inhibitor on the right, and you don’t have to be a biochemist to recognize that there are some similarities here
- Now, there are far fewer similarities between these two molecules than there are between the existing batch of SGLT2 inhibitors
- There are currently four of them out there and they all end in *flozin*
- The point here is all of these *“gliflozins”* have kind of a similar structure, which is this glucose ring with an aromatic group, and then they differ basically around that
- And these differences allow you to have drug companies to make different versions of drugs from an IP perspective, but they also tend to be dosed differently, and that reflects a very different potency of the drugs as well

Nature offers a head start

- Rapamycin, interestingly, is given basically in the format in which it was discovered, whereas SGLT2 inhibitors are not (they’re now basically derivatives of what exists in nature)
- Metformin is actually pretty close to the original molecule that was discovered in the lilac lilies
- The very, very weakest of all statins, which is pravachol or pravastatin, is closer to the most naturally occurring statins that are found in red yeast rice
- “*It is really interesting that nature’s given pharmacologists a headstart on drug development in many cases*.”

## Comparing the various FDA-approved SGLT2 inhibitors [15:00]

***What are the different SGLT2 inhibitors, and what do we know about the differences between them?***

- There are currently four FDA-approved SGLT2 inhibitors for managing adult patients with type 2 diabetes mellitus (DM) to improve blood sugar control along with the addition of  diet and exercise
  - 1) canagliflozin (Invokana),
  - 2) dapagliflozin (Farxiga),
  - 3) empagliflozin (Jardiance)
  - 4) ertugliflozin (Steglatro)

**Canagliflozin**

- This is the one for which we have the most data
- Two main things were observed in the data
  - So the first was that in a [dose-dependent](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3875253/) manner (meaning more drug, the more response), you saw a greater increase in hemoglobin A1C reduction, and the results were reasonable
  - HbA1c reduced by somewhere between a 0.7 and 1% in absolute terms (not relative)
    - So if your hemoglobin A1C was 6.1, you would expect it to go down to as much as 5.1
  - Interestingly, when a [second trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5118239/) was done that looked at metformin plus Canagliflozin, it found an average reduction in the hemoglobin A1C of 1.8%.
    - That’s really significant—if somebody shows up at 7.8% hemoglobin A1C (well into the territory of type 2 diabetes where the threshold is 6.5%), and that person’s going to come down to 6.0%—so they’re going to go from being in a state of raging type 2 diabetes to being pre-diabetic

**Metformin compared to SGLT2 inhibitors**

- Metformin is typically the first line likely due to cost but also efficacy
- Metformin monotherapy is pretty robust with 1.3% reduction in hemoglobin A1C after about six months
- Monotherapy metformin would be associated with slightly more weight loss than monotherapy SGLT2 inhibitor

The other important question here is, *Are there other benefits associated with be it Canagliflozin or other SGLT2 inhibitors that go beyond the glycemic control?*

- In addition to weight loss, we’re also seeing a greater reduction in blood pressure
- Why might this happen? ⇒ when you block SGLT2, you’re preventing the kidney from reabsorbing not just glucose but sodium
- As a patient is excreting more glucose and sodium in their urine, you would think they have obviously less sodium within their plasma.
- That may explain the benefits we see on the blood pressure front as well

More about the other three approved SGLT2 inhibitors:

- dapagliflozin, empagliflozin, and ertugliflozin
- They were approved anywhere from 2013, 2014, actually up until the most recent one in 2017

*Why is it that drugs have such confusing names like that?*

- The likely reason is that when a drug company develops a drug, they want the generic name to be confusing — and that’s because the molecule name is free for anybody to use.
  - So when the drug goes off patent, anybody can sell that drug,
- Now, the trade name/brand name is much easier to remember (for example, for empagliflozin, it’s Jardiance)
  - You want everybody to forever remember Jardiance, not empagliflozin
  - You want people to remember Crestor, not rosuvastatin
  - You want them to remember Lipitor, not atorvastatin
- “*So it’s just classic pharma chicanery*”

## Other beneficial effects of SGLT2 inhibitors outside of glycemic control [20:15]

***What do we know about other effects for SGLT2s outside of just the glycemic control?***

- This is where things do get a little bit interesting
- If you think about metformin, which is kind of like bread and butter of early intervention type 2 diabetes, but that’s not really the reason people are excited about it
- People are excited about metformin because the belief is that it’s doing something beyond regulating blood sugar
- With SGLT2 inhibitors, there is excited beyond managing type 2 diabetes but the majority of that excitement comes from within the scientific community
- In other words, the public is way more interested about metformin, but the scientific community sees much more promise with SGLT2 inhibitors

Why are scientists excited?

- One is just looking at the really clear differences in human clinical trials for the advantages associated with SGLT2 inhibitors in terms of major adverse cardiac events (MACE)
- So if you look at people with or without type 2 diabetes, SGLT2 inhibitors have been shown to decrease the risk of hospitalization and death for heart failure patients with reduced ejection fraction and improve basically all cardiovascular outcomes in patients with heart failure who have preserved EF

What does reduced ejection fraction mean?

- So the heart pumps, and we can measure with an ultrasound how much blood comes out of the heart with each pump
- So if you’re at rest, that number might be 40%-50%
- And if you’re under great stressor when you’re exercising, one of the tools that the body has to increase cardiac output is not just to beat faster, but also to beat with greater contractility and get more ejection of blood volume
- Well, heart failure is basically a condition in which ejection fraction goes down, and when ejection fraction gets low enough, 20%, 15%, you’re in a lot of difficulty.
- And what’s been demonstrated repeatedly, is that when patients have heart failure with or without reduction in EF, outcomes are better if they’re taking an SGLT2 inhibitor, even if they’re not patients with type 2 diabetes.
- There are lots of potential reasons why we might see that, but it probably has to do with the [reduction in blood pressure](https://www.frontiersin.org/articles/10.3389/fmed.2021.712671/full), but it may have to do with other things as well, which we could explore.

## Exploring SGLT2 inhibitors as potential geroprotective molecules [22:45]

**How Peter defines a “geroprotective molecule”**

- A geroprotective molecule is a molecule that you would take that would help you live longer, but not necessarily by addressing a specific disease
- So a statin or a PCSK9 inhibitor is geroprotective technically in that it would at least help you live longer, but it’s doing so through a very specific mechanism that is unique to cardiovascular disease
- So to use the term properly, what we’re really asking is, i*s this molecule targeting more fundamental aspects of aging biology?*
- There are these things called [hallmarks of aging](https://peterattiamd.com/preview-207-ama-35-anti-aging-drugs-nad-metformin-rapamycin/)
- And if you think about what the hallmarks of aging are, for example, deficiencies or decreases in nutrient sensing capabilities, increase in inflammation, an increase in DNA damage or inability to repair, changes in methylation, etc.
- If you have molecules that are targeting those things broadly and not just targeting specific disease issues, you would refer to them as geroprotective

One of the most important ways that such molecules are tested is in the interventions testing program (ITP)

- (See [episode #148 with Rich Miller](https://peterattiamd.com/richardmiller/))
- The ITPs are very elegant studies that use a very robust mouse model to test these various molecules
- The ITP [did NOT find a survival or longevity benefit for Metformin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/), but it did find [significant improvement with Canagliflozin](https://insight.jci.org/articles/view/140019)

**ITP** [**study**](https://insight.jci.org/articles/view/140019) **on Canagliflozin**

- In the ITP study on Canagliflozin, these mice were fed a chow that contained Canagliflozin starting at roughly half a year of age
- They were dosed at a comparable dose to what humans receive
- In the male mice, median survival increased by something like 14%—a really big number for median survival
- Maximal survival was increased by 9%
- Interestingly, in female mice, there was no significant difference in either median or maximal survival. This is not the first time we’ve seen molecules that have a differential effect on male and female mice
- [17alpha-estradiol](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/) also had a significant impact on male mice, not female.
- Conversely, [rapamycin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) has significant benefits on both and slightly more benefits on female mice
- There’s no great answer as to why that’s the case, but worth noting that there were clearly differences in the plasma concentration and the absorption of the drug

Back to the discussion with humans and SGLT2 inhibitors…

- So why did we see this undeniable and clear improvement in major adverse cardiac events in patients with and without type 2 diabetes?
- Peter thinks that it’s in part due to blood pressure reduction and maybe weight reduction
- However, he is not convinced that a 3-5 millimeter per mercury drop on systolic blood pressure, a 2 millimeter mercury drop on diastolic blood pressure, and a two-kilo loss on weight, explains the full benefit
- Peter thinks there is something else that’s going on such as lowering glucose, improving glomerular hyperfiltration, reducing the oxygen consumption of the kidney, and probably even trickling into other aspects of cellular metabolism
- Overall, Peter says based on any of the existing data, it’s not clear that SGLT2 inhibitors would extend life in an otherwise healthy human being
- In that sense, it hasn’t really demonstrated “geroprotection” in humans the way it has in mice.

Timing of intervention — Rapamycin example

- The SGLT2 inhibitor intervention in mice was at the equivalent of about a 20 year old human
- That intervention timing is not uncommon for the ITP
- Interestingly, in the very [first ITP study looking at rapamycin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/), the scientific world got very lucky
- It turns out to be very difficult to formulate rapamycin in a manner that doesn’t get destroyed in the low-pH environment of the gut
- So as they kick the study off, and they’ve got all the mice and they’re working in the three labs, and everything is rocking and rolling, they realize when they’re feeding the mice, the chow mixed with rapamycin, that none of the rapa is getting into the mice’s body, basically getting completely degraded and they can’t measure any levels of rapa in the plasma.
- So they were sort of forced to choose between aborting the whole study or continuing to run the study without giving the treatment group rapamycin.
- They just basically are giving them nothing and giving the control nothing, so they’re identical while they worked to formulate a way to get rapamycin in a type of formulation that will not be broken down by the low pH of the gut.
- And while they finally did that, the mice were about 21 months old which is the equivalent of a 60-year-old human
- That’s not to say that a 60-year-old person is very old or a 21-month mouse is very old, but it’s very old to expect to see a difference in survival when you start something
- Again, nobody would’ve planned the experiment that way
- But they did the experiment, and amazingly, it found a 9% improvement in overall survival for the male mice and 14% for the female that was replicated and reproduced
- To Peter’s knowledge, there’s not another molecule that has increased lifespan when begun at that stage of life which speaks to the interest that continues in rapamycin

## The side effects and risks associated with SGLT2 inhibitors [31:45]

The most frequently reported [adverse events](https://www.ncbi.nlm.nih.gov/books/NBK576405/) with SGLT-2 inhibitors are genital infections.

The largest [meta-analysis](https://www.nature.com/articles/s41598-017-02733-w) on this subject matter found a pretty significant relative risk for genital infections

- At the end of the day, it’s more yeast infections
- And in men, you’re going to see more inflammation of the testes, which is called orchitis.
- In women, you’re going to see vaginitis and an increase in gonorrhea
- Peter clarifies that this likely is about a greater susceptibility (and not due to a change in behavior)
- The absolute risk (AR) of an increase of genital infections is somewhere between 4% and 5%, depending on the study.
- At one year of treatment, in this particular [study](https://www.nature.com/articles/s41598-017-02733-w), there was a 4.23 relative risk increase, meaning it increased your relative risk by 300%, and at six months, it was a doubling of risk.

Another way to think about this is: *what’s the number needed to harm?*

- The answer is: very small
- It’s about 20 to 22, meaning for every 20 to 22 people that take one of these drugs, one of them is going to get a genital infection.
- While these are not life-threatening infections that are easy to treat, Peter is still surprised at the magnitude
- So this is something that needs to be obviously taken into consideration when you look at these drugs
- And as someone who might consider these drugs for geroprotective reasons, you’d certainly need to be mindful of what the trade-offs are

***Are there even less frequent side effects that could be more serious than that?***

There was initially some epidemiology that talked about acute kidney injury (AKI) as a result of these

- If that were the case, it would be very serious and put these drugs in the “no-starter category”
- However, in prospective [clinical trials](https://link.springer.com/article/10.1007/s11892-021-01442-z#Sec19), it has found that the opposite is true
- So it has found that acute kidney injury is reduced by about 30 to 40%
- The initial epidemiologic studies very likely had some confounders in it.

The other thing that is still a little bit unclear is the risk of **ketoacidosis and hypoglycemia**

- Ketoacidosis is a condition that you really only tend to see in individuals with type 1 diabetes or patients with type 2 diabetes who are insulin dependent
- And there does appear to be a [small increase](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4542268/) in the risk of ketoacidosis in people who are, believe it or not, on a carbohydrate-restricted diet, which is maybe not surprising because they’re already going down a ketone pathway
- So SGLT2 inhibitors would increase the production of ketones
- It’s unclear how clinically significant that is, but it would be something you would want to monitor
- This is an argument for using ketone and glucose measurement devices if you’re going on a ketogenic diet, because, obviously, ketoacidosis is defined by very high levels of ketones
- You would need to see ketones in the 6, 7, 8, 9 millimole region to get there and an individual who is monitoring those things would be able to pick that up
- Where one might need to be careful is in the context of a ketogenic diet, you have to be paying attention **when you get sick**
  - Usually, there has to be some sort of insult to the individual, an illness, trauma, something of that nature, that precipitates the unraveling of the acidosis
  - The fundamental problem is the reduction in pH, and that’s sort of what happens when the ketone levels get that high and when they’re not kept in check by insulin levels
  - That’s why someone with type 1 diabetes or an insulin-dependent patient with type 2 diabetes can run into danger because they’re exogenously using insulin to manage ketones
  - That’s why it’s very difficult for someone who makes their own insulin to get into this trouble because high levels of ketones are inhibited by insulin

> “This is a long-winded way of saying that SGLT2 inhibitors may slightly increase that risk, and it’s just one more thing that people need to be very aware of.” —Peter Attia

## Medications, lifestyle interventions, and other considerations for treating diabetes and improving metabolic health [37:45]

So if someone finds out they’re pre-diabetic or diabetic, how are those decisions made on, “Okay, this is the first line of defense that we’re going to try.” *And how does that typically work?*

- Peter’s issue with how the medical community is that we tend to wait until someone is too far in the process of metabolic illness to do anything
- For instance, we [medical establishment] approach type 2 diabetes by drawing this line in the sand of hemoglobin A1C of 6.5%, which corresponds to average blood glucose of 140 milligrams per deciliter
- And when people reach that threshold, people tend to act and treat it—but that’s waiting longer than we should
- So when someone becomes metabolically ill, or has T2D, it’s like “pouring gasoline on the fire of those other three horsemen”
- There is an approximate doubling of your risk of dying from heart disease, cancer, and Alzheimer’s disease if you have type 2 diabetes
- Peter’s gripe is that we wait until a person has type 2 diabetes to get activated
- And so if a person walks in with a hemoglobin A1C of 6%, which probably corresponds to an average blood glucose of 130 milligrams per deciliter, we’re not activated
  - A good doctor, of course, is doing something about that and investigate the “why”
- “But truthfully, I don’t think there’s a heck of a lot of a difference between a 6.0% and a 6.5%”

HbA1C can be misleading

- Hemoglobin A1C misleads you in both directions.
- Peter says to never rely solely on hemoglobin A1C
- We will look at it for **relative** changes, but we don’t care about it as an absolute metric
- We cannot make clinical decisions without CGM, OGTT, and other sorts of tests because the hemoglobin A1C is just too unreliable as an absolute measurement, *but directionally, it’s actually quite valuable*

***How do we think about treating people?***

- The first line therapy is indeed metformin and there’s basically three really compelling reasons for it:
  - 1 It’s quite effective
  - 2 It’s very safe
  - 3 It’s inexpensive
- That said, Peter doesn’t think metformin is perfect
- He is very cautious in his use of Metformin in people who can utilize other tools to improve glycemic control because metformin may be [blunting](https://pubmed.ncbi.nlm.nih.gov/30548390/) some of the benefits of exercise
- clearly have patients who take Metformin, but in our practice, it is not first line.
- In Peter’s practice, exercise, nutrition, and sleep are first line
- And in the “real world”, the answer is probably Metformin plus lifestyle as the first line

**The advent of the GLP-1 agonists**

- The advent of GLP-1 agonists has somewhat complicated the discussion for a couple of reasons.
- Firstly, their efficacy for weight loss is unparalleled (see more in a section below)
- The most recent GLP-1 agonist, semaglutide, goes by the name Ozempic as a diabetes drug, Wegovy as the exact same drug but just rebranded for weight loss
- Then, a follow-up drug that is called tirzepatide or Mounjaro, which is a dual receptor agonist—it’s GLP-1 agonist plus GIP
- These drugs are better than anything that’s ever been done before as far as weight loss, and they provide remarkable glycemic control
- But one big challenge is the financial cost
- It’s pennies a day for Metformin, conversely, GLP-1 agonists are insanely expensive
- It could easily be $16,000 a year of drug cost, and therefore, insurance companies are basically going to say, “Look, we would need a high enough BMI, a high enough sense of obesity coupled with diabetes to justify paying for this over other options”

**In summary…**

- The standard “algorithm” for treating diabetes is basically Metformin plus or minus lifestyle
  - Or GLP-1 pathway in a high BMI person plus lifestyle
- And then, the use of SGLT2 inhibitors basically is brought in based on a couple of other considerations, namely, is there another indication?
  - So does the patient have cardiovascular disease, chronic kidney disease, or CHF or heart failure?
  - If they do, then you’re going to be much more quick to pivot into SGLT2 use and probably even bypass a GLP-1
- That’s kind of like a real-world example of how people think about these things versus just a straight guideline algorithm

## Metformin as a tool for pre-diabetics, and how metformin compares to lifestyle interventions [44:00]

***What about the “middle ground” — such as someone diagnosed with pre-diabetes? Is Metformin something that could be effective for that person?***

The [Diabetes Prevention Program study](https://www.nejm.org/doi/full/10.1056/NEJMoa012512) looked at effectively this question 20 years ago

- It asked if you take someone in that pre-diabetes range, which is defined as a hemoglobin A1C of 5.7 to 6.4…what’s the best option for them?
  - Are you better off doing nothing?
  - Are you better off doing a lifestyle intervention?
  - Are you better off doing Metformin?

First of all, let’s define lifestyle/dietary intervention

- The lifestyle intervention in this study was not really that intensive
- It was basically getting protein intake between 10 and 20% of total calories and getting exercise to 150 minutes per week of moderate-intensity exercise, which they defined as inclusive of brisk walking
- The dietary prescription that was used in the DPP was a low-calorie, low-fat diet that, at the time, was also cholesterol-lowering
- They recommended a diet that was less than 30% of calories from fat, 50 to 60% of calories from carbs, less than 10% of calories from saturated fat, etc
- Notwithstanding the fact that Peter doesn’t actually think that’s the best diet for somebody who is insulin resistant, because in general, people who are insulin resistant are carbohydrate insensitive and they have really lousy fat oxidation
- If you can get them to lose a lot of weight doing this [low-calorie, low-fat diet], you’re going to improve insulin sensitivity
- (In Peter’s experience, those patients tend to respond better to a *hypocaloric diet that is also carbohydrate-restricted)*
- Let’s put all that aside and look at the results of the trial.

![](https://peterattiamd.com/wp-content/uploads/2023/11/f3-ama53.png)

**Figure 3.** Source: [Knowler et al. NEJM Feb 2002](https://www.nejm.org/doi/full/10.1056/NEJMoa012512)

- This is a four-year intervention study
- Your x-axis is showing you time. So 1, 2, 3, and 4 years
- You have three bars per group
  - The white bar is the placebo group,
  - The hashed bar is the Metformin group
  - And the dark shaded bar is the lifestyle group
- Figure A shows you the percent of patients with normal plasma glucose (normal defined as less than 110 milligrams per deciliter—Peter would make that cutoff closer to 90 or 100) at one year, two year, three years, and four years
- Over time, all the groups got worse, meaning all the groups found lower and lower percentages of their participants having normal blood glucose
- Interestingly, lifestyle edges out over Metformin
- The same is true when you look at post-glucose load defined as having a glucose below 140 milligrams per deciliter two hours after an OGTT challenge of 75 grams of glucose
- Yes, everybody kind of got worse over time, but the lifestyle group seemed to win the day.

What does all this say?

- Remember at the outset that Peter said he thought lifestyle is a more powerful tool than Metformin… well this is one of the most powerful demonstrations of why that’s the case
- First of all, this lifestyle intervention was about as “Mickey Mouse” as Mickey Mouse gets, and it still outdid Metformin monotherapy
- And these people were on a real dose of Metformin—850 milligrams twice a day
- So the fact that a very, very trivial lifestyle intervention made this much of a difference relative to Metformin says that if you really get into exercise paired with nutrition, you can make a sizable difference
- And, by the way, this doesn’t include sleep—“*We never want to forget about is the importance of correcting sleep deficiencies, both in quantity staging, et cetera, as far as the impact that that has on glycemic control. It is truly one of the other pillars of insulin sensitivity and glucose disposal*.”

## How GLP-1 agonists compare to metformin and SGLT2 inhibitors in terms of glycemic control and weight loss [49:15]

Previous content on GLP-1 agonists:

- [AMA #29](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/)
- [AMA #45](https://peterattiamd.com/ama45/)
- [Newsletter on 2/18/23](https://peterattiamd.com/the-downside-of-glp-1-receptor-agonists/?utm_source=weekly-newsletter&utm_medium=email&utm_campaign=230219-NL-glp1agonists&utm_content=230219-NL-glp1agonists-email-nonsubs&mc_cid=8a0318ae6f&mc_eid=146365d9b1)

\*\*\*

***If someone is using GLP-1 as it was originally approved for type 2 diabetes, how effective is GLP-1 in managing glycemic control?***

- It depends—there’s a pretty big range
- GLP-1 agonists can lead to changes of HbA1c that range from 0.8-2.6% depending on the type of GLP-1 RA and the dose
- 0.8% is kind of on par with Metformin but the low end of what you would see with SGLT2
- But on the high end, we’re really talking about 2.5% reduction in hemoglobin A1C over as little as six months or a year
- As we start to think about what the newest generations are (semaglutide and tirzepatide) we would have to say those are the gold standards today
- There’s a figure that kind of shows this over time, and it basically shows a bunch of the clinical trials that have been done to compare these

![](https://peterattiamd.com/wp-content/uploads/2023/11/f4-ama53-1024x572.png)

**Figure 4.** Source: [Trujillo et al., Ther Adv Endocrinol Metab., 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7953228/)

- Each square color represents either a different drug or a different dose of the drug used in a different trial
- All of these are pure GLP-1 agonists
- The bottom four are semaglutide. So you’ve got 0.5 milligrams subq weekly, one milligram subq weekly, and then oral semaglutide seven milligrams versus 14
- To be clear, the doses that are used for maximum effect of semaglutide are 2.4 milligrams, which is the weekly dose that’s used in Wegovy
- You’ll also see two milligrams used elsewhere
- When you look at the differences between the trials, you’ll see that, in these trials, you’re getting down to almost 2% hemoglobin A1C reduction
- These are typically six-month to 12-month trials
- What we don’t have on this figure above, because this figure is from a 2021 paper, is if you look at the [data from 2022](https://dom-pubs.onlinelibrary.wiley.com/doi/10.1111/dom.14725) with the more recent semaglutide trial and the tirzepatide trials, that’s where you’re getting those numbers that Peter cited earlier, which is down to more than 2.5% hemoglobin A1C reduction

**Weight loss**

- Regarding the impact on weight changes over comparable periods of time
- In the below figure, you’re seeing a much greater difference than what you see with SGLT2 inhibitors or Metformin
- So GLP-1s are better for glycemic control, but they’re way better for weight control

![](https://peterattiamd.com/wp-content/uploads/2023/11/f5-ama53-1024x600.png)

**Figure 5.** Changes in weight with GLP-1 RAs in head-to-head clinical studies (study duration ranged from 24-57 weeks or about 6-13 months). Source: [Trujillo et al., Ther Adv Endocrinol Metab., 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7953228/)

## Exploring the relationship between statin use and the risk of developing insulin resistance and type 2 diabetes [52:30]

***We get a lot of questions from subscribers wondering if developing type 2 diabetes is a possible side effect for taking statins…and what percent of people taking statins worry about this side effect through the increase in insulin resistance?***

- This is a very important question
- Peter says, “*The more I have dug into this in the past two years to three years, the more I’ve been surprised at the ubiquity of this finding and in some cases the magnitude of the effect*.”

Peter’s “journey of confusion”:

- If you look at the incidents of new onset type 2 diabetes in patients who are taking statins, it varies between about 9% and 12%.
- Of course, there’s a lot of variability here based on studies and based on the study population characteristics of the individuals in the study
- What Peter found most interesting is that no one has done this study yet that is powered sufficiently to unambiguously answer the question—*If you randomly take people who are statin candidates and put some on a statin and some on a placebo, what is the increase in the incidence of type 2 diabetes?*
- “We don’t have that, therefore, I can’t just give you a straight answer to this question”
- It is almost impossible to imagine that statins are not exacerbating insulin resistance in at least select individuals
- But unfortunately, because we have so many confounders in these studies, it’s difficult to i) quantify which fraction of patients are experiencing any deterioration attributable to the statin and ii if so, how significant a deterioration is that?
- Again, if you take all statin trials ever, put them all together and just look at new onset type 2 diabetes in statin users versus placebo, that’s where the [12% increased risk of T2D](https://onlinelibrary.wiley.com/doi/10.1002/pds.4020) in those patients is shown

*That said, we can double-click on certain studies…*

If you look at all the atorvastatin (Lipitor):

- If you pool all the data, amazingly, there was no significant increase in the risk of type 2 diabetes
- However, when you look at the maximum dose of atorvastatin, which is 80 milligrams, it did have a 34% increase in the risk of type 2 diabetes.

If you look at all doses of rosuvastatin (Crestor):

- Typically dosed from 5 milligrams to 40 milligrams because it’s more potent than atorvastatin
- It barely reached statistical significance with an odds ratio of 1.17—a 17% increase in the risk of type 2 diabetes

If you look at simvastatin:

- Note that this is not a drug that’s currently prescribed out of the gate
- It was a 13% increase, but the hazard ratio or the odds ratio was 0.99 to 1.12, so, technically, that’s not significant
- And the same was true at very high dose—80 milligrams—the odds ratio was 1.21, but the 95% confidence interval was 0.99 to 1.49 (not significant)

Pravastatin and fluvastatin:

- This is the weakest oldest statin, and it’s the one that occurs in nature
- They don’t seem to show any increase in the risk of T2D.

All of this begs a question: ***How much does the duration of use matter here?***

- Why this is complicated is that the patients who are taking statins in these trials are often exactly the kind of patients who you would expect to go on to develop T2D
- And therefore, it’s difficult to know how much of the effect is due to the drug versus the progression of something that would’ve happened otherwise

> “It is worth noting, and this is a very important question, that it does not appear that the effect of statins on insulin resistance is a function of lipids being lowered.” —Peter Attia

***So what is going on here?***

- Peter believes there is an actual physiologic problem where statins are causing some increase in the risk of type 2 diabetes
- We can debate, by the way, whether it’s a net benefit or negative
  - The data would suggest it’s still a net positive in terms of the significant reduction in the risk of ASCVD
  - But let’s just put that aside for a moment
- The question is, why?
- Is this happening because when cholesterol goes down, that somehow leads to physiologic changes that worsen insulin signaling (which is effectively one of the hallmarks of developing type 2 diabetes)?
  - Peter would say the answer is no
  - And the reason for that is when we look at the same line of inquiry with other lipid-lowering agents, and in particular, we look at three:
    - the PCSK9 inhibitors
    - bempedoic acid
    - Ezetimibe
    - These are three drugs that are also a big part of the workhorse family of lipid-lowering agents out there
  - We don’t see any of these similar findings
  - “*So that would certainly lead you to believe that if indeed statins are having this effect, it is a class effect. And by a class, I mean it is a statin effect, not a broader effect of lipid-lowering agents*.”

***Do we know if statins are actually the culprit for the observed increase in new-onset diabetes? (as opposed to a person taking a statin but continuing to eat poorly, gain weight, and not exercise)?***

- *Why do I think that it’s not just a progression of lifestyle?* ⇒ It’s because we don’t see it in the other trials.
- To be clear, none of these trials have ever been powered statistically to look for new incidents of type 2 diabetes—that’s why we don’t have the answer and Peter finds this infuriating
- In every other lipid-lowering trial for other drugs, we don’t see the movement, causal or not.
- So what we’re really debating here is not that we don’t see the signal in the statin trials, we do, it’s a signal clear as day, what we’re trying to figure out is causality—*Is it caused by the statin or not?*
  - Peter actually believes it IS caused by the statins because we don’t see even the non-causal signal with PCSK9 inhibitors, bempedoic acid, ezetimibe, or combinations of those drugs

Let’s look at [The Jupiter Trial](https://pubmed.ncbi.nlm.nih.gov/18997196/), a classic, very large statin trial

- This is a trial that made the case for basically rosuvastatin (Crestor) being probably the best statin on the market
- The Jupiter trial found a 25% increase in new onset diabetes with a 20-milligram dose of rosuvastatin over just a 1.9-year follow-up compared to those on placebo
- Very difficult to not say there must be something going on there

**Another reason why Peter thinks this effect is real:**

A [short study](https://www.ahajournals.org/doi/10.1161/ATVBAHA.121.316159) of 10 weeks was looking at half the maximum dose of atorvastatin, so 40 milligrams, and it was given to 71 participants who did not have type 2 diabetes

- It increased insulin resistance in just 10 weeks by 8%, insulin secretion went up by 9%, and fasting insulin went up by 7%.
- Now, none of those numbers really sound that big, but again, here you have a study that was designed to look for those outcomes, i.e., it’s powered for that outcome, and it’s only a 10-week study.
- So what does that tell us?
  - One thing about this study that is noteworthy is that the patients who had the most extreme or the largest increase in insulin resistance were the ones who were most insulin sensitive at baseline
  - So there was a 16% median increase in insulin-sensitive patients versus only a 1% median increase in those who were insulin-resistant at baseline
  - This further speaks to the mechanistic point here, which is this is not a progression of just lifestyle, this must be due to the drug itself

> “I can’t point to perfect data to say that statins are indeed increasing insulin resistance. But when you look at the collection of data, and you triangulate between them, I think it becomes quite clear, at least to me, that statins are playing a role here.” —Peter Attia

That said, what’s not knowable from the existing literature is:

- How can we predict which patients are going to respond this way and which are not?
- What are the factors that we have at our disposal to mitigate that damage or mitigate that metabolic risk?
- And ultimately, what’s the impact of this in terms of statin use?

Statins are hands down the workhorse of the lipid-modulating therapy world

- They’re relatively inexpensive, certainly compared to the most recent generations of drugs, namely the PCSK9 inhibitors and bempedoic acid
- So what do we think about all that? ⇒ “*I think it’s an open question*.”

## Possible mechanisms of statin-induced insulin resistance and diabetes, and potential mitigation strategies [1:04:30]

***If we know that there is a risk of diabetes from statins, do we know why that is? Do we have any idea what specifically is causing that?***

- We can think about it through the lens of what are statins doing that those other drugs are not doing
- If you take a really big step back and go back to kind of lipidology 101, all lipid-lowering drugs, on some level, impact LDL receptors in the liver
- The whole goal of lowering ApoB is to increase ApoB clearance from the plasma, and that is done by increasing the number or the life (duration) of LDL receptors on the liver
- And different drugs go about doing that in very different ways, but it’s noteworthy that lowering ApoB from the circulation only seems associated with this problem in statin users, but not in any other class of drugs
- Ezetimibe, for instance, is blocking a GI transporter of lipids. When the body stops absorbing or reduces its absorption of biliary cholesterol, the liver says, “Oh, I need more LDL receptors.”
- PCSK9 inhibitors block PCSK9. When PCSK9 is blocked, it cannot, as a protein, erode the LDL receptor. So the LDL receptor stays on the liver longer, ApoB goes down.
- Bempedoic acid blocks cholesterol synthesis, but it only does it in the liver because bempedoic acid is a pro-drug that is inactive when you swallow it. And therefore, can only be activated by the enzymes in the liver that turn it on. And it inhibits cholesterol synthesis in the liver, which leads to LDL expression increase

*Okay, well, what does statins do?*

- Statins use a similar trick to bempedoic acid, except they do it across the body
- So statins ubiquitously across the body inhibit an enzyme called HMG-CoA reductase.
- This disproportionately happens in the liver. So the net effect is that the liver says, “*Oh my God, I need more cholesterol. I better put more LDL receptors on and suck cholesterol as circulation*.”
- But it would seem to me that the problem must be with the HMG-CoA inhibition in the muscle
- Why the muscle?
  - A, the muscle represents an enormous part of where the statin is displaced
  - B, the muscle plays an outsized role, arguably the largest role in glucose disposal in the body
- In the [discussion with Gerald Schulman](https://peterattiamd.com/geraldshulman/), he talked about how the canary in the coal mine for insulin resistance is insulin resistance at the level of the myocyte. It’s the muscle cell.
  - Anything that interferes with the GLUT4 transporter getting across the cell of the muscle to bring *glucose* [NOTE: Peter mistakenly said ‘insulin’ instead of glucose] in is the root cause of insulin resistance
- “So my intuition is that that’s where the problem lies.” says Peter

If you look at some genetic analyses that look at loss of function of HMG-CoA reductase (the enzyme that statins inhibit), the Mendelian randomization says there are basically two genetic variants which are associated with lower LDL cholesterol and were also associated with higher weight, higher waist circumference, higher glucose, and diabetes risk

- Mendelian randomization is very good at being able to ask the question, causally, what happens if you have a loss of function of the enzyme that is inhibited by the statins?
- The answer is, well, you have lower LDL cholesterol (as expected)
- But it’s also paradoxically associated with higher weight, higher waist circumference, higher glucose, and higher diabetes risk

> “What I hope is clear is that I believe this is a statin-specific problem, and I believe it probably has to do with the effect of the statin on HMG-CoA reductase in the muscle.” —Peter Attia

***So knowing that that’s the case, are there any ideas on how you would treat/prevent this?***

- When going down this rabbit hole, Peter’s first thought was to look at CoQ10 (aka ubiquinol or ubiquinone which are two different forms of CoQ10)
- The reason being is that the most prominent side effect of statins is muscle soreness and it’s hard to imagine that that’s not occurring because of the inhibition of HMG-CoA reductase in muscles
- So there has been a back-and-forth debate for many years about whether supplementing CoQ10, which is an antioxidant and a co-factor in mitochondrial respiratory complexes, can reduce muscle soreness
- However, the data are largely negative that CoQ10 supplementation reduces muscle soreness—muscle-related statin symptoms are generally not alleviated by CoQ10 supplementation in randomized control trials
- That said, whenever a patient is experiencing muscle soreness and wants to try CoQ10 as opposed to switching to a different drug, Peter would not be opposed to that and sometimes it seems to benefit, which could be the placebo effect

However, a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6087610/) of 80 pre-diabetic patients demonstrated that eight weeks of supplementing 200 milligrams a day of CoQ10—the standard dose—was able to significantly reduce their HOMA-IR.

- HOMA-IR is just a calculation of the ratio of glucose to insulin and a pretty good proxy for insulin resistance absent more rigorous tests such as OGTTs
- This small study would suggest to Peter that if someone is in the boat where the statin’s working just fine from a lipid perspective, and bempedoic acid and PCSK inhibitors are very cost prohibitive, this might be a viable solution

## How to monitor for adverse effects of statin use and assess the need for adjustments [1:11:45]

***If someone is starting to take a new statin, how do they track to see if they need to make changes, and if they’re seeing negative outcomes with that? And a lot of people are just curious how do you do this clinically with your patients?***

- Peter does check fasting glucose, fasting insulin, and hemoglobin A1C with every blood test, so they can following changes over time
- Notwithstanding all the issues Peter has with the accuracy of hemoglobin A1C as a predictor of average blood glucose
- The frequency with which hemoglobin A1C imputes average blood glucose is in line with measured average blood glucose using a calibrated CGM is actually quite low, but the movement of the hemoglobin A1C tends to be consistent.
- In other words, those three things should give you a hint as to whether things are moving in the wrong direction or not
- So if you’ve had a hemoglobin A1C of 5.3 or 5.6%, and it’s been relatively steady the last few years, and then you start taking a statin, and before long, it’s 5.9%, that would be a very good indication that statins are playing a negative role on your insulin signaling and/or glycemic control.

***If someone’s going on a statin and they have access to a CGM, should they start wearing that? Or even should people who maybe haven’t worn one before, if they’re going to start taking a statin, use a CGM to monitor any changes in more detail?***

- Peter’s patients don’t use CGM for that purpose exclusively
- But they do use CGM liberally in the practice for many reasons
- It’s often the case that patients who are going on statins happen to be CGM users, so they have data for them off statin, and then they’ll get data for them on statin
- And in that case, it can be really easy to see—in fact, that’s probably one of the first cases where Peter saw such an unambiguous change on a patient who started Crestor
- The patient had a 10 milligram per deciliter jump in his average blood glucose, and they confirmed with many on-off, on-off statin experiments with him.
- “It couldn’t have been more clear.”
- In short, “I don’t think starting a statin is an indication to start CGM, but for a patient who’s otherwise using CGM, I think it’s just another high-resolution way to look at the problem.”

***When someone starts taking a statin, how often should they get their blood checked?***

- Hemoglobin A1C takes about three months to see a significant change because it’s based on the full life of a red blood cell
- So a red blood cell, on average, lasts about three months, so you would not expect to see a change in hemoglobin A1C in a couple of weeks, even though you would see a lipid change in that period of time.
- As a general matter of housekeeping, if you started the statin on day 1, Peter would want to see the labs 90 days later
- Peter would want to see not only the lipids, which are the whole reason you’re doing this thing, but he’d also want to see the liver function tests and the glycemic markers as well

## Weighing the benefits and risks of statin use: does the diabetes risk outweigh the benefits of lowering apoB with a statin? [1:15:30]

***If someone’s thinking about taking a statin to lower their ApoB, does the risk of developing diabetes outweigh the benefits of that lower ApoB in your mind?***

- Peter says the risk does NOT outweigh the benefit in his opinion
- The data are very clear, so we don’t have to speculate because here we can look at [all-cause mortality data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9572734/)

Again, why is all-cause mortality data so important?

- Hypothetically, if you have a drug that could eliminate your risk of cardiovascular disease, but it quadrupled your risk of cancer in Alzheimer’s disease, your all-cause mortality would actually go up even though your cardiovascular mortality came down
- So one always has to be looking at all-cause mortality
- It’s also common to see studies where you see a reduction in, say, cardiovascular mortality but no change in all-cause mortality because the study wasn’t long enough to appreciate that change

Last year, a very large [meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9572734/) sought to answer this question clearly.

- It took a look at 54 studies, which were real-world studies that also encompassed all-cause mortality, that had at least a 12-month duration of comparing people on statins to off statins
- The risk of all-cause mortality, inclusive of any other change in the statin user, was a 28% reduction
- This was a very tight confidence interval, 0.66 to 0.76, very large meta meta-analysis and very clear direction
- This means that when you lump everything in together, people who were on statins had a 28% lower risk of death
- Now, we still saw in that analysis an increase in diabetes
- So for every roughly 255 patients treated, there was one excess case of type 2 diabetes over a four-year period of treatment
- So how do you put all that into English?
  - Well, maybe one other fact to consider is that by treating every 250 people with a statin to reduce the LDL cholesterol by 38.7 milligrams per deciliter, which is just one millimole of cholesterol, prevents 5.4 coronary events (coronary death or non-fatal MI during that same period of time)

**The net benefit is still vastly in favor of statin use**

- That said, Peter predicts as the other lipid-modulating drugs become less and less expensive, statins will cease to be as prevalent as they are today
- For the time being, Peter is not saying, “Hey, if you’re on a statin, you need to stop your statin.”
- Peter says the data are very clear that that’s not necessary, but for some people, that might be necessary
- Can we find that patient who is progressing towards T2D?
  - yes, we can identify those people very quickly, i.e., within the first year of statin initiation that they’re moving in the wrong direction
  - For those patients, we have to really ask ourselves the questions, “Hey, should we be doing something different?”

⇒ For more on PCSK9 inhibitors, bempedoic acid, and ezetimibe check out [AMA #41](https://peterattiamd.com/ama41/)

## Parting thoughts [1:20:45]

- For some reason, statins are a very polarizing class of drug
- Peter says it’s probably best to discount both of the extreme views on this — meaning people who believe statins should “be in the drinking water” and people who believe that statins are “killing babies”
- It’d be good to just sort of discount both of those people as much as possible and marginalize their views.

> “And hopefully, what we’ve put forward here today is a far more nuanced approach to how to think about this class of drug that generates so much confusion.” —Peter Attia

§

## Selected Links / Related Material

**Previous episode of The Drive about metabolic health**: [#271 – AMA #51: Understanding and improving your metabolic health](https://peterattiamd.com/ama51) | Peter Attia (peterattiamd.com) [2:30]

**SGLT-2 inhibitors were discussed on episode #148 with Rich Miller**: [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) | Peter Attia (peterattiamd.com) [4:15]

**Canagliflozin studies**: [15:30]

- Study finding that there was a greater increase in hemoglobin A1C reduction with a greater dose: [Canagliflozin (Invokana), a Novel Oral Agent For Type-2 Diabetes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3875253/) (Sarnoski-Brocavich et al., 2013)
- Metformin plus canagliflozin: [Canagliflozin: Efficacy and Safety in Combination with Metformin Alone or with Other Antihyperglycemic Agents in Type 2 Diabetes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5118239/) (Qui et al., 2016)

**SGLT2 inhibitors show a reduction in blood pressure**: [Sodium-Glucose Cotransporter-2 Inhibitor (SGLT2i) as a Primary Preventative Agent in the Healthy Individual: A Need of a Future Randomised Clinical Trial?](https://www.frontiersin.org/articles/10.3389/fmed.2021.712671/full) (Xu et al., 2021) [22:30]

**Episode of The Drive that discuss the hallmarks of aging**: [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/preview-207-ama-35-anti-aging-drugs-nad-metformin-rapamycin/) | Peter Attia (peterattiamd.com) [24:00]

**ITP study showing metformin given alone did not extend life in mice**: [Longer lifespan in male mice treated with a weakly estrogenic agonist, an antioxidant, an α‐glucosidase inhibitor or a Nrf2‐inducer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/) (Strong et al., 2016) [25:00]

**ITP paper showing canagliflozin increased median lifespan in the male mice by 14%, maximum extension of 9%, but it had no effect on the females**: [Canagliflozin extends life span in genetically heterogeneous male but not female mice](https://insight.jci.org/articles/view/140019) (Miller et al., 2020) [25:00]

**Meta-analysis showing a significant relative risk for genital infections with SGLT2 inhibitors**: [Effects of SGLT2 inhibitors on UTIs and genital infections in type 2 diabetes mellitus: a systematic review and meta-analysis](https://www.nature.com/articles/s41598-017-02733-w) (Liu et al., 2017) [32:30]

**Metformin may blunt some beneficial effects of exercise**: [Metformin inhibits mitochondrial adaptations to aerobic exercise training in older adults](https://pubmed.ncbi.nlm.nih.gov/30548390/) (Konopka et al., 2019) [40:45]

**Diabetes Prevention Program study comparing metformin, lifestyle interventions, and placebo for people with pre-diabetes**: [Reduction in the Incidence of Type 2 Diabetes with Lifestyle Intervention or Metformin](https://www.nejm.org/doi/full/10.1056/NEJMoa012512) (Diabetes Prevention Program Research Group, 2001) [44:00]

**Previous content on GLP-1 agonists**: [49:15]

- [#184 – AMA #29: GLP-1 Agonists – The Future of Treating Obesity?](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/) | Peter Attia (peterattiamd.com)
- [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/) | Peter Attia (peterattiamd.com)
- [Lean mass loss on GLP-1 receptor agonists: a downside of the “miracle drugs”](https://peterattiamd.com/the-downside-of-glp-1-receptor-agonists/?utm_source=weekly-newsletter&utm_medium=email&utm_campaign=230219-NL-glp1agonists&utm_content=230219-NL-glp1agonists-email-nonsubs&mc_cid=8a0318ae6f&mc_eid=146365d9b1) | Peter Attia (peterattiamd.com)

**The Jupiter trial which found a 25% increase in new onset diabetes with a 20-milligram dose of rosuvastatin**: [Rosuvastatin to prevent vascular events in men and women with elevated C-reactive protein](https://pubmed.ncbi.nlm.nih.gov/18997196/) (Ridker et al., 2008) [1:01:30]

**Small study that found increased insulin resistance in subjects taking a max dose of atorvastatin**: [Statins Are Associated With Increased Insulin Resistance and Secretion](https://www.ahajournals.org/doi/10.1161/ATVBAHA.121.316159) (Abbasi et al., 2021) [1:01:45]

**Episode of The Drive with Gerald Shulman where he discusses how the canary in the coal mine for insulin resistance is insulin resistance at the level of the myocyte**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia (peterattiamd.com) [1:07:30]

**A study of 80 pre-diabetic patients demonstrated that eight weeks of supplementing 200 milligrams a day of CoQ10 was able to significantly reduce their HOMA-IR**: [Effect of Coenzyme Q10 on Insulin Resistance in Korean Patients with Prediabetes: A Pilot Single-Center, Randomized, Double-Blind, Placebo-Controlled Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6087610/) (Yoo et al., 2018) [1:10:30]

**Large meta-analysis looking at all-cause mortality of statin users**: [Effect of Statins on All-Cause Mortality in Adults: A Systematic Review and Meta-Analysis of Propensity Score-Matched Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9572734/) (Nowak et al., 2022) [1:16:15]

**AMA episode of The Drive that discussed PCSK9 inhibitors, bempedoic acid, and ezetimibe**: [#231 – AMA #41: Medicine 3.0, developments in the field of aging, healthy habits in times of stress, and more](https://peterattiamd.com/ama41/) | Peter Attia (peterattiamd.com) [1:20:45]

§

## People Mentioned

- [Rich Miller](https://www.richmillerlab.com/biog) [4:15, 24:30]
- [Sir William Osler](https://en.wikipedia.org/wiki/William_Osler) [11:30]
- [Matt Kaeberlein](https://halo.dlmp.uw.edu/people/matt-kaeberlein/) [30:45]
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/#:~:text=Shulman%20is%20the%20George%20R,the%20Yale%20Diabetes%20Research%20Center.&text=Shulman%20is%20the%20recipient%20of%20the%20Stanley%20J.) [1:07:30]

§