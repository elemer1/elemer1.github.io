# #376 – AMA #78: Longevity interventions, exercise, diagnostic screening, and managing high apoB, hypertension, metabolic health, and more

**Source:** [https://peterattiamd.com/ama78/](https://peterattiamd.com/ama78/)

---

In this “Ask Me Anything” (AMA) episode, Peter tackles a wide-ranging set of listener questions spanning lifespan interventions, exercise, cardiovascular risk reduction, time-restricted eating, blood pressure management, hormone therapy, diagnostics, and more. Peter reveals the single most important lever for extending healthspan and lifespan, and explains how he motivates midlife patients using the Centenarian Decathlon framework. He discusses the importance of addressing high apoB and cholesterol even in metabolically healthy individuals with calcium scores of zero, how to manage high blood pressure, and how to accurately evaluate metabolic health beyond HbA1c. Additional topics include time-restricted eating, practical considerations around ultra-processed foods, nuanced approaches to HRT for women and TRT for men, and why early and expanded screening for chronic disease—colonoscopy, PSA, coronary imaging, low-dose CT—can be lifesaving. He also offers insights into treating prediabetes, crafting exercise programs for those short on time, and safely incorporating high-intensity training in older adults.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #78 show notes page](https://peterattiamd.com/ama78). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

This is where protected show notes would go available only to paid subscribers.

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Introducing a wide-ranging AMA: practical perspectives on lifespan interventions, metabolic health, diet, hormones, diagnostics, and more [A: 2:45, V: 0:10];
- Why exercise is the most powerful single intervention for lifespan and healthspan [A: 4:15, V: 1:49];
- How Peter motivates midlife patients to prioritize exercise [A: 6:00, V: 3:48];
- Why lifespan and healthspan should not be treated as competing priorities and how choosing sustainable interventions benefits both [A: 9:30, V: 7:55];
- Why high apoB deserves treatment even in a metabolically healthy patient with a CAC score of zero [A: 14:00, V: 12:52];
- Managing hypertension: ideal targets for blood pressure, lifestyle levers, and why early pharmacology matters [A: 18:15, V: 17:56];
- Assessing metabolic health beyond HbA1c: fasting insulin, triglycerides, lactate, zone 2, and more [A: 23:30, V: 23:45];
- How to avoid common self-sabotaging patterns by choosing sustainable habits over extreme health interventions [A: 26:00, V: 26:26];
- Time-restricted eating: minimal effect beyond calorie control, implications for protein intake, and practical considerations for implementing it [A: 28:00, V: 28:50];
- Ultra-processed foods: definitions, real-world risks, and practical guidelines for smarter consumption [A: 30:30, V: 31:43];
- How women should prepare for menopause and think about hormone replacement therapy: early planning, symptom awareness, and guidance on HRT [A: 36:45, V: 39:05];
- Testosterone replacement for aging men: indications, benefits, and safe clinical management [A: 39:45, V: 42:38];
- Why Peter recommends earlier and more aggressive screening tests than guidelines suggest: colonoscopies, coronary imaging, PSA, Lp(a), and low-dose CT scans, and more [A: 43:30, V: 47:00];
- Full-body MRI screening: benefits, limitations, potential false positives, and the importance of physician oversight [A: 47:15, V: 51:17];
- Prediabetes: individualized treatment strategies using tailored combinations of nutrition, sleep, and training interventions [A: 51:00, V: 55:50];
- Time-efficient training plans for people with only 30 minutes per day to exercise [A: 53:00, V: 58:06];
- How to safely introduce high-intensity exercise for older adults [A: 55:00, V: 1:00:18];
- Timed dead hangs and ripping phone books: a playful look at Peter’s early attempts to impress his wife [A: 57:15, V: 1:03:08];
- Peter’s carve out: The Four Kings documentary about a golden era of boxing [A: 1:01:15, V: 1:07:42]; and
- More.

---

The Peter Attia Drive

#376 – AMA #78: Longevity interventions, exercise, diagnostic screening, and managing high apoB, hypertension, metabolic health, and more

---

## Show Notes


---

## Introducing a wide-ranging AMA: practical perspectives on lifespan interventions, metabolic health, diet, hormones, diagnostics, and more [A: 2:45, V: 0:10]

**Episode format**

- Answer questions from listeners on various, unrelated topics
- Rather than a deep dive into the science, this will be more about Peter’s thinking, philosophy, and approach both personally and/or clinically

**Variety of topics**:

- apoB
- blood pressure
- metabolic dysfunction
- time-restricted eating and fasting
- ultra-processed food
- HRT
- Testosterone
- screening and diagnostics
- Prediabetes
- Time-efficient exercise plans
- And more

## Why exercise is the most powerful single intervention for lifespan and healthspan [A: 4:15, V: 1:49]

***If you can only do one intervention for life span, what is the one “non-negotiable”?***

- If every lifespan intervention disappeared except one, **exercise** would remain the essential, non-negotiable intervention.
- This conclusion does not change when shifting the question from lifespan to healthspan.
- Exercise outperforms other interventions — including smoking cessation, hypertension management, lipid management, and reducing type 2 diabetes — when looking at disease-specific and all-cause mortality.
- Cardiovascular fitness provides a larger mortality benefit than other modifiable risk-reduction strategies.
- Muscular strength contributes independently to mortality reduction.
- Muscle mass also provides benefits, although it appears to have a smaller effect size than strength and fitness.
- The most significant decline in quality of life during the final decade is typically driven by movement limitations, chronic pain, poor stability, and declining physical fitness.
- Training throughout life directly addresses these determinants of reduced healthspan.
- Exercise therefore simultaneously extends lifespan and preserves functional capacity, making it the most effective single intervention across both domains.

⇒ Check out [AMA #71](https://peterattiamd.com/ama71/) for more on the importance of muscular strength, muscle mass, and cardiorespiratory fitness for longevity

## How Peter motivates midlife patients to prioritize exercise [A: 6:00, V: 3:48]

**Why future functional goals must be addressed now**

- Many people in their 30s–50s feel fully capable today and therefore assume they can delay exercise until later in life.
- The decline they will face decades later is hard to appreciate when everything feels easy in the present.

**Using the Centenarian Decathlon to make the future tangible**

- The [Centenarian Decathlon](https://peterattiamd.com/category/exercise/centenarian-decathlon/) is a structured tool/framework used to turn vague future aspirations into concrete physical goals for the last decade of life.
- Individuals are asked to identify 10 physical tasks (their Centenarian Decathlon goals) they want to be able to perform between ages 80–90.
- These tasks can include ambitious activities as well as basic activities of daily living.
- Each selected activity is broken down into component movement patterns, required strength, mobility demands, and physiological parameters.
- Years of refinement have allowed this process to evolve from a loose conceptual framework into a more systematic, semi-scientific methodology.

**Translating late-life goals into present-day training requirements**

- For each desired activity, the physical prerequisites are identified in detail (e.g., ankle mobility for hiking, stability requirements for walking 18 holes of golf, strength needs for stair climbing).
- These requirements are then projected backward by decade, estimating what level of capacity is needed at ages 80, 70, 60, and so on.
- This backward modeling creates a clear timeline showing the minimum physical capabilities required at each stage of life to still meet the target goals at 90.
- When individuals compare their current ability (at 30 or 40 or 50) against the level they would need to be at today, a significant gap almost always appears.

**Why this framework motivates earlier action**

- The framework replaces abstract motivational messages with a concrete visualization of future decline and present deficits.
- People recognize that although they can perform these activities now, age-dependent decline will outpace their current baseline unless they train.
- *The analogy is similar to financial planning*: having enough savings today does not mean it will last through retirement without accounting for ongoing expenses and future income loss.

**Key principles about timing**

- It is never too early to start training for long-term functional goals.
- It is possible to start late, but starting too late may make some goals unattainable.
- Maintaining the necessary physical capacities for late-life goals requires compounding effort over decades, not a last-minute sprint.
- Someone arriving at age 80 with low function cannot realistically expect to build the capacity needed for high-demand activities like skiing by 90.

## Why lifespan and healthspan should not be treated as competing priorities and how choosing sustainable interventions benefits both [A: 9:30, V: 7:55]

**Why separating lifespan and healthspan is a false dichotomy**

- Treating lifespan and healthspan as opposing goals is misleading because people ultimately want both: to live **longer** and to live **better**.
- When someone says, “I don’t care how long I live, I just want quality of life,” what they truly mean is they don’t want to endure prolonged decline or chronic suffering in old age.
- The interventions that improve healthspan—such as exercise, sleep, nutrition, and sensible pharmacology—almost always improve lifespan as well.

**Two different strategies for extending lifespan (as written about in Chapter 4 of** [**Outlive**](https://peterattiamd.com/outlive/)**)**

- One approach: extending life with chronic disease, which is essentially the current Medicine 2.0 model.
  - This strategy emerged from early medical successes and is understandable historically, but it does not produce the best long-term outcomes.
- A more effective strategy for longevity is extending life without chronic disease—delaying or preventing disease onset entirely; [Medicine 3.0](https://peterattiamd.com/ama41/)
  - Pursuing lifespan by minimizing chronic disease inherently enhances healthspan.

**Why most interventions support both lifespan and healthspan**

- Nearly every major lever—exercise, nutrition, sleep, metabolic health, and targeted pharmacologic therapy—improves both lifespan and healthspan when applied through a preventive framework.
- If the emphasis is on delaying chronic disease, lifespan improves and so does functional quality of life.
- If the emphasis is on improving day-to-day functioning (healthspan), most evidence-based actions still reduce long-term disease risk and improve lifespan.

**When lifespan and healthspan goals may diverge**

- Healthspan is subjective and includes physical, cognitive, and emotional components.
- The physical dimension of healthspan does not require extreme athletic performance.
- Pursuing extreme physical achievements—such as trying to win the CrossFit Games or becoming an elite MMA fighter—may conflict with long-term health because:
  - High injury risk accumulates over time.
  - Orthopedic stress, head trauma, or chronic overtraining may reduce lifespan and degrade late-life function.
- Any healthspan optimization should be evaluated through the lens of risk tolerance for future injury and chronic harm.

## Why high apoB deserves treatment even in a metabolically healthy patient with a CAC score of zero [A: 14:00, V: 12:52]

**Why a “healthy” 40-year-old with high apoB is still a concern**

- A patient who is fit, insulin-sensitive, and metabolically healthy is starting from a strong baseline; these factors protect broadly against chronic disease.
- High cardiorespiratory fitness and good metabolic markers are highly beneficial but do not eliminate the risk created by elevated [apoB](https://peterattiamd.com/ama43/).
- ApoB-containing lipoproteins are the proximate causal agent in atherosclerosis; every LDL particle is a potential atherogenic “seed.”

**Why high apoB cannot be ignored even with a zero CAC score**

- Many people with high apoB but no other risk factors still develop ASCVD and sometimes die prematurely.
- The majority of premature ASCVD deaths occur in individuals with multiple risk factors, but apoB alone is sufficient to drive disease over time.
- A zero CAC score has limitations, carrying about a 15% false-negative rate, especially for early soft plaque that has not yet calcified.
- Real clinical experience includes numerous cases where a zero CAC was followed by CTA evidence of non-calcified atherosclerosis.

⇒ Check out episodes [#52](https://peterattiamd.com/ethanweiss/) and [#247](https://peterattiamd.com/ethanweiss2/) with Ethan Weiss for more on CAC scores

***If advanced imaging is perfect, does apoB still need treatment?***

- Even if coronary CT angiography (CTA) confirms absolutely pristine arteries, the question hinges on causality.
- ApoB’s causal role in ASCVD is one of the clearest causal relationships in modern medicine.
- Because apoB is causal, elevated levels warrant treatment regardless of current imaging results.
- The intensity of treatment may vary:
  - ApoB 150 with no plaque → reasonable goal might be ~60.
  - ApoB 150 with existing plaque → more aggressive goal around ~30.

**Why early treatment of causal risk factors is justified**

- Treating causal factors reduces risk even when disease is not yet present.
- The analogy:
  - A healthy, fit 40-year-old who just started smoking would still be told to stop immediately.
  - Smoking is causal for lung cancer even though most smokers do not get lung cancer and some non-smokers do.
  - You treat causes before the damage appears, not after.

⇒ Check out [AMA #43](https://peterattiamd.com/ama43/) and [AMA #60](https://peterattiamd.com/ama60/) for more on apoB

## Managing hypertension: ideal targets for blood pressure, lifestyle levers, and why early pharmacology matters [A: 18:15, V: 17:56]

**Ideal blood pressure targets**

- The [SPRINT Trial](https://www.nejm.org/doi/10.1056/NEJMoa1511939) and similar studies demonstrate that maintaining blood pressure below 120/80 mmHg is ideal.
- Older clinical norms that allowed 130/85 mmHg are now considered suboptimal for long-term health.
- Lowering blood pressure from ~140/85 to <120/80 provides a [15–25% reduction in risk](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(02)11911-8/fulltext) of adverse outcomes.
- As long as a patient is asymptomatic, there is generally little concern about blood pressure being on the lower side.
- Overcorrection is possible with medication, so monitoring is essential.

**Why hypertension must be treated seriously**

- Hypertension is a leading driver of:
  - Cerebrovascular disease (stroke)
  - Heart failure
  - Kidney disease
  - Cognitive decline
- High blood pressure is a pervasive “silent epidemic,” in part because accurate measurement in daily life can be cumbersome.
- Despite strong evidence, clinicians and patients often delay pharmacologic treatment, hoping lifestyle alone will suffice.

**Why delaying medication can be costly**

- Early elevations (e.g., 135/85–90) often lead clinicians to recommend lifestyle changes instead of medication.
- Lifestyle changes alone typically yield minimal incremental improvements, and months or years may pass without achieving target blood pressure.
- In hindsight, beginning medication earlier while implementing lifestyle interventions would have produced better outcomes.

**Lifestyle levers that meaningfully reduce blood pressure**

- Blood pressure responds strongly to lifestyle, more so than many lipid abnormalities.
- High-impact non-pharmacologic interventions include:
  - Weight loss
  - Reduced alcohol intake
  - Exercise
  - Correcting sleep apnea or disordered sleep
- Many individuals can return to normal blood pressure through these approaches and later reduce or discontinue medications.

**Pharmacologic options and modern strategy**

- Multiple drug classes for hypertension allow combination therapy rather than pushing a single medication to higher doses.
- For dyslipidemia, older strategies relied on pushing statins to high doses, but newer approaches use add-on therapies (e.g., ezetimibe, PCSK9 inhibitors).
- Hypertension management follows the same principle: start with an ACE inhibitor or ARB, and add medications as needed without resorting to extreme dosing.
- Lower doses of multiple drugs often yield better control with fewer side effects.

**Peter’s current philosophy on treatment sequence**

- Adopt an earlier turn toward pharmacology to minimize cumulative exposure to high blood pressure.
- Implement aggressive lifestyle changes concurrently.
- As lifestyle modifications take effect (e.g., weight loss, improved sleep, increased exercise), drugs may become unnecessary and can be gradually withdrawn.
- If blood pressure remains elevated after lifestyle improvements, remaining on medication is still preferable to untreated hypertension.

⇒ For more on strategies to reduce high blood pressure, check out:

- Podcast: [AMA #48](https://peterattiamd.com/ama48/)
- Article: [All things blood pressure: from measurement to management](https://peterattiamd.com/all-things-blood-pressure/)

## Assessing metabolic health beyond HbA1c: fasting insulin, triglycerides, lactate, zone 2, and more [A: 23:30, V: 23:45]

**Limitations of relying solely on HbA1c**

- HbA1c is a useful marker but is more meaningful as a trend than as a single absolute value.
- Using HbA1c alone can miss early metabolic dysfunction due to its known limitations (e.g., variation in red cell turnover).

**Preferred approach: a more comprehensive panel**

- Assessing metabolic health is best done by looking at multiple indicators, not a single lab.
- The goal is to detect impaired glucose disposal and metabolic flexibility as early as possible.

**Oral glucose challenge as the gold standard**

- The [oral glucose tolerance test](https://peterattiamd.com/ama15/) (OGTT) with paired insulin measurements (fasting, 30, 60, 90 minutes) is considered the single best test for evaluating glucose disposal.
- This test directly shows how efficiently the body manages a glucose load, revealing dysfunction much earlier than fasting glucose or HbA1c alone.

**Valuable alternative markers when a glucose challenge isn’t possible**

- Fasting insulin + fasting glucose provide meaningful insight compared with fasting glucose alone.
- Triglycerides and HDL are informative for metabolic health; specifically:
  - If triglycerides are lower than HDL, metabolic health is generally favorable.
- Fasting/rested lactate can reflect mitochondrial efficiency and metabolic flexibility:
  - Lactate 0.5 mmol/L or lower suggests excellent metabolic health.

**Functional measures of metabolic performance**

- [Zone 2](https://peterattiamd.com/topic-guide/zone-2-training/) output—the power/wattage/METs a person can produce while keeping lactate low—is arguably one of the best practical tests of metabolic flexibility.
- Higher Zone 2 output at low lactate indicates strong mitochondrial function and superior glucose and fat oxidation capacity.

**Anthropometric and additional biomarker clues**

- A person with relatively normal total body fat but very low [visceral fat](https://peterattiamd.com/ama40/) typically demonstrates healthy metabolic function.
- Certain blood markers help reinforce the metabolic picture:
  - Low [transaminases](https://peterattiamd.com/juliawattacheril/) (ALT, AST)
  - Normal-to-low [uric acid](https://peterattiamd.com/ama62/)
- When combined, these lab values and physical measures create a more complete, reliable assessment of metabolic status.

⇒ For more on assessing metabolic health, check out:

- Podcast: [AMA #51](https://peterattiamd.com/ama51/)
- Article: [Assessing metabolic health: where HbA1c falls short, and how it compares to fasting glucose, CGM, and OGTT](https://peterattiamd.com/problems-with-hba1c/)

## How to avoid common self-sabotaging patterns by choosing sustainable habits over extreme health interventions [A: 26:00, V: 26:26]

**Why highly motivated people often fail to sustain change**

- Many people begin with unsustainable extremes, trying to overhaul everything at once.
- Unrealistic goals create a predictable trajectory toward burnout.

**Common self-sabotaging patterns**

- Crash diets or severe caloric restriction often backfire and are not maintainable.
- Excessive exercise volume or intensity early on leads to injury, overtraining, or fatigue.
- Overemphasis on supplements or “biohacking” tools (e.g., red lights, saunas, cold plunges) distracts from foundational behaviors.
- These tools may provide short-term boosts but rarely lead to meaningful long-term change.
- Spending too much time on minor interventions while ignoring major lifestyle levers results in limited real progress.

**Where people should actually focus**

- Sustainable improvement comes from consistently executing on the core pillars:
  - Nutrition
  - Exercise
  - Sleep
  - Emotional health
  - Stress management
- Real progress requires gradual behavior change rather than dramatic early targets.

**The mindset that leads to long-term success**

- The emphasis should be on getting better over time, not transforming everything immediately.
- Maintaining 80% consistency indefinitely is more effective than being 100% perfect for short bursts.
- Sustainable habits protect against the typical six-month collapse back into old patterns.

## Time-restricted eating: minimal effect beyond calorie control, implications for protein intake, and practical considerations for implementing it [A: 28:00, V: 28:50]

**Effect of** [**time-restricted eating**](https://peterattiamd.com/ama72/) **(TRE) on body composition**

- When calories and protein are held constant, time-restricted eating adds little to no additional benefit for body composition.
- Any difference between spreading calories across the day versus a restricted eating window is very small and often undetectable in controlled studies.
- The primary mechanism by which TRE leads to body composition changes is passive caloric restriction, not metabolic magic.

**Why TRE often appears effective**

- Shrinking the eating window naturally reduces overall intake for most people.
- This passive reduction—rather than timing-driven metabolic effects—is what typically produces fat loss.

**No evidence for special physiological effects**

- There is no convincing evidence that TRE meaningfully increases autophagy or provides unique metabolic advantages beyond caloric control.
- Claims about TRE-induced autophagy remain unsupported in humans under typical fasting durations.

**Pitfalls and practical considerations**

- Extremely narrow eating windows (e.g., one meal a day) may make it difficult to consume adequate protein.
- People using OMAD often rely on low-calorie protein supplements to reach protein goals.
- Eating late at night (e.g., 10 p.m. before bed) is discouraged due to negative effects on sleep and metabolic regulation.

**Optimizing timing if one chooses TRE**

- A TRE pattern is most effective when exercise occurs in the morning with larger meals earlier in the day.
- Tapering food intake downward as the day progresses is more physiologically aligned with circadian rhythms.
- Avoiding evening eating is recommended for better metabolic and sleep outcomes.

⇒ For more on TRE, check out [AMA #72](https://peterattiamd.com/ama72/)

## Ultra-processed foods: definitions, real-world risks, and practical guidelines for smarter consumption [A: 30:30, V: 31:43]

**Clarifying definitions around processed vs. ultra-processed**

- Almost all foods are processed to some degree, including milk, cheese, and yogurt.
- Ultra-processed foods represent a further step, typically appearing in packages with long ingredient lists.
- These foods are engineered for palatability, convenience, and shelf stability.
- Ultra-processed foods are generally high in fat, sugar, salt, and overall calorie density, and require little to no preparation.

**Why ultra-processed foods are linked to obesity**

- Ultra-processed foods tend to be calorie-dense and nutrient-poor, promoting overeating.
- One theory suggests people have nutrient-sensing mechanisms, leading them to continue eating when consuming nutrient-poor foods to satisfy unmet micronutrient needs.
- In practice, consuming these foods rapidly increases caloric intake due to their palatability and low satiety.

**Theoretical vs. real-world impact**

- In a strictly controlled setting with identical calorie and macronutrient intake, the difference between whole foods and ultra-processed foods would likely be small.
- Some ultra-processed foods wouldn’t even allow you to match macros (e.g., you can’t meet protein needs with Oreos).
- Food additives likely have less impact than many assume; nutrient loss may be a larger issue.
- Nutrient deficiencies from processed diets could theoretically be offset with supplementation.
- However, this theoretical framing doesn’t reflect actual behavioral patterns in the real world.

**The real-world issue: effectiveness, not efficacy**

- The primary health problem with ultra-processed foods is how people consume them, not their chemical composition.
- In free-living conditions, diets high in ultra-processed foods almost always lead to overeating and weight gain.
- The focus on whether molecules are “natural” or “synthetic” is misplaced; what matters is their biological effect.

**Practical considerations about specific ultra-processed items**

- Not all ultra-processed foods are equally problematic.
- Items like protein bars, protein shakes, and fiber supplements have useful roles and should not be equated with candy and chips.
- Treating all ultra-processed foods as identical obscures meaningful distinctions in nutritional utility.

**General guidance on including ultra-processed foods**

- A diet built primarily on whole foods is ideal, but achieving this consistently requires more time, money, and logistical effort.
- Ultra-processed foods can be used as tools or occasional conveniences, not staples.
- When included strategically and in the context of appropriate energy balance, they need not be harmful.

**Broader food-system realities**

- Completely eliminating ultra-processed foods is unrealistic given global population size.
- The current food ecosystem cannot feed 8 billion people solely with whole, unprocessed foods.
- Ultra-processed foods play a structural role in global nutrition, making the topic more complex than “processed = bad.”

⇒ Check out [episode #368](https://peterattiamd.com/davidallison3/) with David Allison for more on processed foods

## How women should prepare for menopause and think about hormone replacement therapy: early planning, symptom awareness, and guidance on HRT [A: 36:45, V: 39:05]

**Preparing for HRT before menopause**

- The transition from pre-menopause to full menopause is a long, gradual process that unfolds over years, not weeks.
- It is valuable to begin discussing hormone replacement therapy (HRT) before symptoms fully emerge.
- Treating women during this transitional window (pre-menopause → perimenopause → menopause) can be important and appropriate.

**Establishing a detailed hormonal and reproductive history**

- Understanding a woman’s contraceptive history provides important context (e.g., long-term oral contraceptive use).
- Identifying when she last had regular menstrual cycles helps gauge where she may be in the menopausal transition.
- Information about IUD use and any hormone-related issues is part of the foundational assessment.
- Establishing baseline hormone characteristics—such as whether she historically had high or low testosterone—helps tailor treatment.
- Tracking how monthly hormonal fluctuations affected her mood, sleep, or general well-being illuminates individual sensitivities to estrogen and progesterone changes.
- The goal is to understand how hormones have influenced her each month while she is still naturally cycling.

**Helping women recognize symptoms of the menopausal transition**

- Many women expect vasomotor symptoms such as hot flashes and night sweats, but they may not realize how broad the symptom range is.
- Symptoms like brain fog, irritability, sleep disruption, and changes in libido can also result from hormonal shifts during the transition.
- Identifying these symptoms early helps women contextualize their experience and seek appropriate treatment sooner.

**Correcting misinformation and reducing unnecessary fear**

- There remains widespread misinformation about estrogen therapy, especially around breast cancer risk.
- The [removal of outdated black box warnings on estrogen](https://www.axios.com/2025/11/10/fda-black-box-warning-menopause-hormone-therapy) (spearheaded by [Marty Makary](https://en.wikipedia.org/wiki/Marty_Makary)) is a positive step toward reducing fear and confusion.
- Current evidence does not support the claim that estrogen therapy increases the risk of dying from breast cancer, and women should not be misled by outdated warnings.
  - See [episode #253](https://peterattiamd.com/joannmanson/) with JoAnn Manson for more on the breast cancer evidence

**Monitoring biomarkers and knowing when to treat**

- FSH (follicle-stimulating hormone) levels are useful to track because they rise as a woman transitions toward menopause.
- Treatment does not need to wait until FSH rises; symptoms and clinical context are often more important than lab thresholds.
- Biomarker monitoring provides additional clarity but should not delay appropriate care.

## Testosterone replacement for aging men: indications, benefits, and safe clinical management [A: 39:45, V: 42:38]

**General safety profile of testosterone replacement therapy (TRT)**

- TRT is far less controversial today than it was a decade ago because earlier fears were based on poor-quality data.
- Current evidence [does not support the idea that TRT increases prostate cancer risk](https://peterattiamd.com/ama28/).
- TRT [can increase cardiovascular risk in susceptible individuals](https://peterattiamd.com/ama28/), making proper prescribing and monitoring essential.
- Poor physician oversight can lead to avoidable harm, and many problems seen in practice stem from improper management.

**Risks associated with improper TRT management**

- TRT can raise blood pressure, which requires monitoring.
- One of the most underappreciated risks of TRT is elevation in hematocrit, which can become dangerously high if not monitored.
- A case example illustrates the extreme: a patient on TRT reached a hemoglobin of ~20 and hematocrit of ~65 due to a doctor’s negligence.
- Correcting severe hematocrit elevation may require extensive therapeutic phlebotomy, demonstrating how preventable complications can become serious.

**Determining whether TRT is appropriate**

- Low testosterone on lab testing is objective, but **the key clinical question is whether a man is actually experiencing symptoms attributable to low testosterone**.
- The only way to know whether symptoms correlate with testosterone deficiency is to trial testosterone replacement and assess improvement.
- Symptom assessment before and after TRT is essential to determine true benefit.

**Expected outcomes when TRT is done correctly**

- In men who start with genuinely low testosterone levels, therapeutic response rates are high—around 80% in clinical experience.
- When testosterone levels rise from low-normal (~400 total / 8 free) to higher physiological ranges (~1000 total / 20 free), men often report substantial improvements in how they feel and function.
- Responsible management includes monitoring hematocrit, blood pressure, and other biomarkers; donating blood several times per year may be required for some individuals.

⇒ For more on TRT, check out [AMA #28](https://peterattiamd.com/ama28/)

## Why Peter recommends earlier and more aggressive screening tests than guidelines suggest: colonoscopies, coronary imaging, PSA, Lp(a), and low-dose CT scans, and more [A: 43:30, V: 47:00]

Question for Peter: *As you think about screening and diagnostics for yourself or your patients, are there any tests that you think most people should do potentially earlier than current guidelines suggest?*

**Colonoscopy timing**

- The current guideline shift from age 50 to 45 for colonoscopy is a positive development.
- Beginning screening even earlier—around age 40—is reasonable and is typically recommended in practice.

**Using coronary imaging to clarify cardiovascular risk**

- Coronary imaging is especially valuable for individuals who resist treating elevated apoB or LDL-c because they believe they are “low risk” due to age, fitness, or online misinformation.
- Many people dismiss preventive lipid management based on poor-quality advice, so objective imaging can influence decisions.
- Before ordering any diagnostic test, it is critical to ask whether the result would actually change management; if not, the test should not be performed.
- All diagnostic discussions incorporate physical risks, psychological risks, false positives, false negatives, predictive values, and how results will influence treatment decisions.

**Blood markers to include in routine screening**

- apoB should be measured to assess atherosclerotic risk.
- [Lp(a)](https://peterattiamd.com/high-lpa-risk-factors/) should be measured at least once since it is genetically determined.
- [PSA screening](https://peterattiamd.com/tedschaeffer2/) is recommended annually for all men, regardless of age or guideline recommendations.
  - For Peter’s patients, PSA is also measured during every routine blood draw (3–4 times per year) in order to build high-resolution trend lines.
  - Frequent PSA data greatly improves interpretation of PSA density and velocity, which are often more informative than a single PSA value.

**Expanding lung cancer screening beyond current guidelines**

- Low-dose CT scans for lung cancer should be considered even in people who have never smoked.
- [Lung cancer in never-smokers](https://peterattiamd.com/lung-cancer-screening/), if treated as its own category, is still the **seventh leading cause of cancer death**.
- Restricting screening only to high-risk groups overlooks a large group with meaningful risk.
- Cost is relatively low ($120–$150), reducing barriers to broader screening adoption.
- Annual screening minimizes concerns about false positives, because incidental findings—such as benign granulomas—can be monitored over time for stability.

⇒ Article to check out: [The importance of lung cancer screening — even if you’ve never smoked](https://peterattiamd.com/lung-cancer-screening/)

## Full-body MRI screening: benefits, limitations, potential false positives, and the importance of physician oversight [A: 47:15, V: 51:17]

**General context for whole-body MRI**

- Full-body MRI services are widely available, and many people are exploring them as preventive health tools.
- MRI has the major advantage of no exposure to ionizing radiation, making it safer than CT from a radiation perspective.

**Technical limitations of MRI**

- MRI is not a standardized measurement tool; unlike CT’s Hounsfield units, MRI outputs vary by machine and settings, making cross-scan comparisons unreliable.
- MRI is highly sensitive to motion and to body positioning on the table, which can distort images even when scans are performed back-to-back.
- These limitations increase the risk of misinterpretation and diagnostic error.

**Limits of MRI for cancer detection**

- MRI provides good anatomic detail in the brain but much poorer resolution in the abdomen and especially the chest.
- Whole-body MRI is unlikely to detect early lung cancers, including adenocarcinoma, which is the primary concern in never-smokers.

**Sensitivity, specificity, and downstream consequences**

- Whole-body MRI tends to be *high sensitivity, low specificity*—it picks up many findings but produces many false positives.
- Because scans are expensive and often lead to follow-up imaging or biopsies, ***false positives can be costly and emotionally stressful***.
- Over time, repeated MRIs on the same person reduce false-positive uncertainty because radiologists can compare images year-over-year.

⇒ Article on sensitivity and specificity: [How to interpret screening tests: video, spreadsheet, and primer](https://peterattiamd.com/how-to-interpret-screening-tests-video-spreadsheet-and-primer/)

**Practical and ethical considerations**

- Whole-body MRI may still be worth doing for certain people—but only if they clearly understand the limitations and potential fallout.
- Physician guidance is strongly recommended so that false-positive findings are not left for patients to navigate alone.
- If a patient undergoes a whole-body MRI without physician involvement, their doctor may be forced into managing the consequences without having been part of the decision.
- In Peter’s practice, the clinic expects that 20–25% of patients should decline getting the full-body MRI after hearing the risks
  - If almost everyone says yes, the risks likely weren’t explained sufficiently.

## Prediabetes: individualized treatment strategies using tailored combinations of nutrition, sleep, and training interventions [A: 51:00, V: 55:50]

**Why rank-ordering interventions is impossible**

- Pre-diabetes presents in many different phenotypes, and the underlying drivers vary widely from person to person.
- Some individuals are significantly overweight, while others are lean but “skinny fat.”
- Some exercise regularly but chronically overeat; others are sedentary but do not overeat.
- Some appear to be doing most things correctly but have severely disrupted sleep.
- Because the root causes differ, a one-size-fits-all ranking of interventions is not meaningful.

**The intervention “playbook”**

- Peter’s practice uses a broad set of tools:
  - Nutrition strategies (including caloric balance and macronutrient composition)
  - Sleep optimization
  - Resistance training
  - Aerobic training ([zone 2](https://peterattiamd.com/topic-guide/zone-2-training/))
  - High-intensity aerobic work
- These elements are pulled in different combinations depending on the individual case.

**Nutrition**

- Energy balance plays a role in many—but not all—cases of pre-diabetes.
- Some patients improve metabolic function without reducing calories at all
  - In those cases it’s usually a sleep + exercise problem

**The role of sleep**

- Poor sleep alone can significantly impair glucose regulation and worsen insulin resistance.
- Sleeping 5 hours per night makes it extremely difficult for the body to partition fuel properly or maintain normal glucose metabolism.
- Sleep must be corrected regardless of any other intervention.

**Resistance and aerobic training**

- Resistance training improves glucose metabolism by:
  - Increasing total muscle mass (a major glucose reservoir)
  - Increasing muscle insulin sensitivity
- Aerobic training also supports insulin sensitivity and glucose disposal.
  - Aerobic base training (zone 2) is important.
  - [High-intensity aerobic](https://peterattiamd.com/exercising-for-longevity-peter-on-zone-2-and-zone-5-training/) work adds additional metabolic benefits.
- The key is matching the right combination of training modalities to the individual’s physiology and lifestyle.

**Overall clinical approach**

- The goal is to identify which levers in the playbook matter most for the specific person in front of you.
- Pre-diabetes management is inherently individualized rather than protocolized.

## Time-efficient training plans for people with only 30 minutes per day to exercise [A: 53:00, V: 58:06]

**General framing**

- Exercise is critically important yet often constrained by time.
- Training structure should match the actual time a person can commit.
- Two scenarios are considered:
  - Someone with 30 minutes per day
  - Someone with 30 minutes three times per week

**Plan for the person with 30 minutes per day:**

–*Weekly structure*

- 2 days of resistance training
  - Full-body workouts using an upper body/lower body split.
  - 30 min sessions
- 3 days of [zone 2 training](https://peterattiamd.com/topic-guide/zone-2-training/)
  - Peter emphasizes it being “real zone 2”… i.e., not drifting into zone 1.
  - 30 minutes each session.
- 2 days of [zone 5](https://peterattiamd.com/exercising-for-longevity-peter-on-zone-2-and-zone-5-training/) work
  - Each session structured as:
    - 10-minute warmup at a zone 2 effort
    - 4 min on (90%+ of HR max) and 4 min off easy recovery
      - Repeat
    - 2-4 minute cooldown at the end
  - Provides a very time-efficient high-intensity stimulus.

–*Overall weekly outcome*

- Balanced mix of strength, aerobic base, and high-intensity work.
- Covers all pillars of fitness with limited daily time.

**Plan for the person with 30 minutes three times per week:**

NOTE: This plan assumes the person is currently sedentary; even small doses will generate large early benefits.

*-Weekly structure*

- 1 × 30-minute full-body resistance session
  - Similar approach as the daily exerciser, but only one day per week.
- 1 × 30-minute zone 2 session
  - Provides a foundational aerobic stimulus.
- 1 × 30-minute zone 5 (high-intensity) session
  - Same structure as the daily exerciser’s HIIT day.

–*Possible adjustment*

- Instead of pure zone 2, the aerobic session may drift toward zone 3 to increase the training stimulus given the limited time.
- The hope is that improved fitness and well-being motivate the person to increase weekly exercise time.

–*Overall weekly outcome*

- Minimal but meaningful dose of strength training, aerobic development, and high-intensity conditioning.
- Designed to provoke noticeable improvements that may encourage greater long-term commitment.

## How to safely introduce high-intensity exercise for older adults [A: 55:00, V: 1:00:18]

The question centers on *whether adults aged 50–60+ should perform high-intensity exercise or sprints, and how to approach this safely*.

- The answer depends entirely on the individual’s training history, current conditioning, and the modality of high-intensity work.

**Key considerations when prescribing high-intensity exercise to older adults**

- High-intensity exercise can be beneficial for people over 50.
- The decision to use it depends on “the foundation of the house”—the person’s baseline level of activity, strength, mobility, and training history.

**Risks and modality choice**

- Sprinting on foot is riskier for deconditioned individuals due to high forces and injury potential (e.g., Achilles tendon tears).
- Safer sprint-like modalities include:
  - Bike intervals
  - Pool sprint intervals
- Choosing the right modality dramatically reduces orthopedic risk.

**Baseline requirements before adding intensity**

- A person with no training or exercise history should not start with high-intensity work.
- Initial training should focus on:
  - Building foundational strength
  - Improving mobility
  - Establishing basic aerobic capacity
  - Ensuring movement competency
- High intensity is introduced only after the foundational qualities are sufficiently developed.

*Timing: how long to build the foundation?*

- There is no universal timeframe for when someone is “ready.”
- Readiness depends on:
  - Current fitness level
  - Movement quality
  - Commitment to consistent training
  - Ability to progressively handle workload
- Progression is individualized rather than time-based.

**Evidence that older adults adapt well**

- The [LIFTMOR study](https://pubmed.ncbi.nlm.nih.gov/28975661/) (see the [Belinda Beck episode](https://peterattiamd.com/belindabeck/)) shows that even women over 65 with no resistance training experience can safely and quickly adapt to heavy lifting (e.g., deadlifts) within months.
- This demonstrates that older adults are highly adaptable when programs are structured correctly and prioritize safety.

**Overall principle**

- High-intensity exercise is appropriate and beneficial for older adults if matched to their current capacity and introduced progressively.
- The goal is to leverage the body’s adaptability while minimizing preventable injuries.

## Timed dead hangs and ripping phone books: a playful look at Peter’s early attempts to impress his wife [A: 57:15, V: 1:03:08]

**Clarifying the “dead hang on the first date” rumor**

- The rumor that Peter asked his wife to perform a dead hang on their first date is false.
- The real story occurred 4–5 years ago, not during dating:
  - Jill walked into the gym, saw Peter dead hanging, and asked to try.
  - She asked what would be considered “good,” and Peter told her that a 90-second hang would be excellent for a woman in her 40s.
  - She surprised him by hanging for 3 minutes and 8 seconds, the longest he had seen from a woman.
- Peter’s follow-up dead hang and Jill’s reaction
  - The next day, with friends present, Peter shared Jill’s impressive result.
  - Peter was asked to demonstrate his own hang and held it for 4 minutes and 35 seconds.
  - Jill interpreted this as Peter showing her up and was genuinely upset for a couple of days.
  - Peter viewed it simply as giving an all-out effort each time, not as one-upmanship.

**Humorous reflection on Peter’s dating reputation**

- Nick jokes about the idea that Peter might have required “dead hang testing” on early dates.
- Peter says the reality was worse:
  - On their actual first date, he tore phone books to try to impress her.
  - They were walking in Baltimore where phone books sat on stoops, and he casually ripped them as a demonstration of strength.
  - Jill was not impressed and instead became confused, then weirded out.
- Peter’s internal logic at the time
  - He recalls wondering why she wasn’t impressed and considered repeating the stunt.
  - He rationalized that maybe she hadn’t clearly seen it or thought the phone book was unusually weak.

## Peter’s carve out: The Four Kings documentary about a golden era of boxing [A: 1:01:15, V: 1:07:42]

**Purpose of the “carve-out”**

- The carve-out is a segment where Peter shares something personally interesting and unrelated to the podcast’s main topics.

How Peter heard about the [**Four Kings documentary**](https://www.imdb.com/title/tt32542539/)

- George Perez, a friend introduced through [Tony Gonzalez](https://en.wikipedia.org/wiki/Tony_Gonzalez), mentioned the documentary.
- George is a big F1 and boxing fan, which connected him and Peter.
- Peter had surprisingly never heard of the documentary before George told him.

Peter’s lifelong connection to boxing

- Peter is a long-time boxing enthusiast, particularly obsessed with the sport from the early 1900s through the 1990s.
- He views the 1980s as the most extraordinary era of boxing, partly because he grew up during that time.
- He no longer follows modern boxing but remains deeply invested in its historical eras.

About the documentary “[Four Kings](https://www.imdb.com/title/tt32542539/)”

- The series is a four-part, four-hour documentary [available on Amazon Prime](https://www.primevideo.com/detail/Four-Kings/0P127TOEUZYEGZE40Z8KTEO3B7).
- It focuses on the four legendary boxers known as the “Four Kings”:
  - [Marvelous Marvin Hagler](https://en.wikipedia.org/wiki/Marvelous_Marvin_Hagler)
  - [Sugar Ray Leonard](https://en.wikipedia.org/wiki/Sugar_Ray_Leonard)
  - [Roberto Durán](https://en.wikipedia.org/wiki/Roberto_Dur%C3%A1n)
  - [Thomas “Hitman” Hearns](https://en.wikipedia.org/wiki/Thomas_Hearns)

Peter’s impression of the documentary

- Despite having extensive knowledge of boxing, he learned many new details and saw footage he had never encountered.
- He thought most commentary—especially from [Teddy Atlas](https://en.wikipedia.org/wiki/Teddy_Atlas)—was excellent.
- He did have criticisms of certain elements of the documentary, which he privately shared with George.

Peter’s personal relationship to the fighters

- Hagler was his childhood hero and the reason he began boxing.
- Peter strongly believed Hagler defeated Sugar Ray Leonard in their [1987 fight](https://en.wikipedia.org/wiki/Marvin_Hagler_vs._Sugar_Ray_Leonard) (scoring it 115–113), which shaped his early dislike of Leonard.
- Over time, his perspective evolved, and the documentary deepened his appreciation for Sugar Ray Leonard’s greatness.

Reflection on the era of the Four Kings

- Peter marvels at how rare it is to have four fighters of such extraordinary caliber compete in the same era—and all fight each other.
- He emphasizes how fortunate fans were to witness this convergence of talent.
- The documentary renewed his admiration for the entire group.

---

## Selected Links / Related Material

**Peter’s content related to the Centenarian Decathlon**: [Centenarian Decathlon](https://peterattiamd.com/category/exercise/centenarian-decathlon/) | (peterattiamd.com) [6:00]

**Peter’s book has a chapter on Medicine 2.0 vs. Medicine 3.0**: [Outlive: The Science and Art of Longevity](https://peterattiamd.com/outlive/) by Peter Attia (peterattiamd.com) [10:30]

**AMA episode of The Drive discussing the idea of “Medicine 3.0”**: [#231 – AMA #41: Medicine 3.0, developments in the field of aging, healthy habits in times of stress, and more](https://peterattiamd.com/ama41/) | Peter Attia (peterattiamd.com) [10:45]

**AMA episodes of The Drive discussing apoB**: [14:00]

- [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/) | Peter Attia (peterattiamd.com)
- [#306 – AMA #60: preventing cognitive decline, nutrition myths, lowering blood glucose, apoB, and blood pressure, and more](https://peterattiamd.com/ama60/) | Peter Attia (peterattiamd.com)

**AMA episode of The Drive about blood pressure**: [#258 – AMA #48: Blood pressure—how to measure, manage, and treat high blood pressure](https://peterattiamd.com/ama48/)  | Peter Attia (peterattiamd.com) [18:15]

**Peter’s article about high blood pressure and how it can be a “silent killer”**: [All things blood pressure: from measurement to management](https://peterattiamd.com/all-things-blood-pressure/) | Peter Attia (peterattiamd.com) [18:15]

**The SPRINT Trial study that demonstrates that maintaining blood pressure below 120/80 mmHg is ideal**: [A Randomized Trial of Intensive versus Standard Blood-Pressure Control](https://www.nejm.org/doi/10.1056/NEJMoa1511939) (The SPRINT Research Group, 2015) [18:45]

**Data showing that lowering blood pressure from ~140/85 to <120/80 provides a 15–25% reduction in risk of adverse outcomes**: [Age-specific relevance of usual blood pressure to vascular mortality: a meta-analysis of individual data for one million adults in 61 prospective studies](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(02)11911-8/fulltext) (2002) [19:00]

**For more on strategies to reduce high blood pressure, check out**: [18:15]

- Podcast: [#258 – AMA #48: Blood pressure—how to measure, manage, and treat high blood pressure](https://peterattiamd.com/ama48/) | Peter Attia (peterattiamd.com)
- Article: [All things blood pressure: from measurement to management](https://peterattiamd.com/all-things-blood-pressure/) | Peter Attia (peterattiamd.com)

**For more on assessing metabolic health, check out**: [23:30]

- Podcast: [#271 – AMA #51: Understanding and improving your metabolic health](https://peterattiamd.com/ama51/) | Peter Attia (peterattiamd.com)
- Article: [Assessing metabolic health: where HbA1c falls short, and how it compares to fasting glucose, CGM, and OGTT](https://peterattiamd.com/problems-with-hba1c/) | Peter Attia (peterattiamd.com)

**AMA episode of The Drive about fasting and TRE**: [#353 – AMA #72: Fasting: benefits for body composition and disease prevention, potential risks, and Peter’s updated practical framework](https://peterattiamd.com/ama72/) | Peter Attia (peterattiamd.com) [28:30]

**Episode of The Drive with David Allison where they discussed processed and ultra-processed foods**: [#368 ‒ The protein debate: optimal intake, limitations of the RDA, whether high-protein intake is harmful, and how to think about processed foods | David Allison, Ph.D.](https://peterattiamd.com/davidallison3/) | Peter Attia (peterattiamd.com) [34:15]

**Article about the removal of outdated black box warnings on estrogen (spearheaded by Marty Makary**: [FDA scraps “black box” warning from menopause hormone therapy](https://www.axios.com/2025/11/10/fda-black-box-warning-menopause-hormone-therapy) | Maya Goldman (axios.com) [39:00]

**Episode of The Drive with JoAnn Mason where she discusses the lack of evidence that estrogen increases the risk of breast cancer**: [#253 ‒ Hormone replacement therapy and the Women’s Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT | JoAnn Manson, M.D.](https://peterattiamd.com/joannmanson/) | Peter Attia (peterattiamd.com) [39:15]

**AMA episode of The Drive discussing the clear data showing that testosterone replacement therapy does not increase the risk of prostate cancer**: [#180 – AMA #28: All things testosterone and testosterone replacement therapy](https://peterattiamd.com/ama28/) | Peter Attia (peterattiamd.com) [40:15]

**Peter’s article about the importance of treating high LP(a)**: [High Lp(a) warrants intervention, even without other cardiovascular risk factors](https://peterattiamd.com/high-lpa-risk-factors/) | Peter Attia (peterattiamd.com) [45:00]

**Episode of The Drive with Ted Schaeffer about PSA screening**: [#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer2/) | Peter Attia (peterattiamd.com) [45:00]

**Peter’s article about low dose CT scan for lung cancer screening**: [The importance of lung cancer screening — even if you’ve never smoked](https://peterattiamd.com/lung-cancer-screening/) | Peter Attia (peterattiamd.com) [45:45]

**Lung cancer in never-smokers is still the seventh leading cause of cancer death**: [Lung cancer in never-smokers](https://peterattiamd.com/lung-cancer-screening/) [47:00]

**The LIFTMOR study by Belinda Beck shows that even women over 65 with no resistance training experience can safely and quickly adapt to heavy lifting (e.g., deadlifts) within months**: [High-Intensity Resistance and Impact Training Improves Bone Mineral Density and Physical Function in Postmenopausal Women With Osteopenia and Osteoporosis: The LIFTMOR Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/28975661/) (Watson et al., 2018) [56:45]

**The boxing documentary**: [Four Kings](https://www.imdb.com/title/tt32542539/) | (imdb.com) [1:01:30]

- [Available to watch on Amazon Prime](https://www.primevideo.com/detail/Four-Kings/0P127TOEUZYEGZE40Z8KTEO3B7)

**Peter strongly believed Marvin Hagler defeated Sugar Ray Leonard in their 1987 fight**: [Marvin Hagler vs. Sugar Ray Leonard](https://en.wikipedia.org/wiki/Marvin_Hagler_vs._Sugar_Ray_Leonard) | (wikipedia.org) [1:03:00]

---

## People Mentioned

- [David Allison](https://www.pcori.org/people/david-b-allison-phd) [34:15]
- [Marty Makary](https://en.wikipedia.org/wiki/Marty_Makary) [39:00]
- [Belinda Beck](https://peterattiamd.com/belindabeck/) [56:45]
- [Tony Gonzalez](https://en.wikipedia.org/wiki/Tony_Gonzalez) [1:01:15]
- [Marvelous Marvin Hagler](https://en.wikipedia.org/wiki/Marvelous_Marvin_Hagler) [1:02:15]
- [Sugar Ray Leonard](https://en.wikipedia.org/wiki/Sugar_Ray_Leonard) [1:02:15]
- [Roberto Durán](https://en.wikipedia.org/wiki/Roberto_Dur%C3%A1n) [1:02:15]
- [Thomas “Hitman” Hearns](https://en.wikipedia.org/wiki/Thomas_Hearns) [1:02:15]
- [Teddy Atlas](https://en.wikipedia.org/wiki/Teddy_Atlas) [1:02:45]