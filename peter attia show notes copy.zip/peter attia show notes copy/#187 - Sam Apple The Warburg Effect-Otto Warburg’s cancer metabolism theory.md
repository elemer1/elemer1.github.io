# #187 – Sam Apple: The Warburg Effect—Otto Warburg’s cancer metabolism theory

**Source:** [https://peterattiamd.com/samapple/](https://peterattiamd.com/samapple/)

---

Sam Apple is the author of the book *Ravenous: Otto Warburg, the Nazis, and the Search for the Cancer-Diet Connection*, published in May 2021. In this episode, Sam describes the fascinating life story of Otto Warburg, a Nobel Prize-winning scientist who, despite being both Jewish and gay, survived Nazi Germany because of his valuable research on cellular metabolism and cancer. Sam describes Warburg’s observation that cancer cells consume large amounts of glucose anaerobically – a phenomenon subsequently known as the “Warburg Effect” – and relates how Warburg’s seminal work on this topic was largely forgotten after the discovery of oncogenes, only to regain relevance decades later within the field of cancer biology. Sam sheds light on the current debate around Warburg’s interpretation of the causes of cancer, and Peter gives his personal take on the matter. Finally, Peter and Sam tie it all together with a discussion about cancer prevention, the role of hyperinsulinemia, and the link between dietary sugar and cancer.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/samapple/the_Drive_public.png)

Play

#187 - Sam Apple: The Warburg Effect—Otto Warburg's cancer metabolism theory

#187 - Sam Apple: The Warburg Effect—Otto Warburg's cancer metabolism theory

1x15s30s

0:001:48:22

## We discuss:

- Sam’s interest in Otto Warburg and work as a writer [2:30];
- Otto Warburg’s dedication to science and his complicated life in Germany [14:00];
- Warburg’s interest in cancer and early discoveries about cellular consumption of oxygen [23:00];
- The role models who fueled Warburg’s desire to make a great discovery [34:15];
- How Warburg described the primary and secondary causes of cancer [42:15];
- Warburg’s Nobel Prize in 1931 [45:45];
- Warburg’s life and work during WWII in Nazi Germany [46:30];
- Warburg’s research in hydrogen transfers and coenzymes—his best science? [59:45];
- Warburg’s decision to stay in Germany after WWII [1:03:30];
- Discovery of oncogenes in the 1970s and the decline in interest in Warburg’s ideas [1:07:30];
- The renaissance of Warburg’s ideas on cancer metabolism and a new explanation for the Warburg Effect [1:13:45];
- The argument against the Warburg Effect as a primary cause of cancer and the potential role hyperinsulinemia [1:21:15];
- Identifying primary and secondary causes of cancer for the purpose of cancer prevention [1:27:00];
- The link between sugar, fructose, and cancer [1:35:30];
- Sam’s reflections on the work that went into Ravenous [1:39:45];
- More.

§

## Show Notes

**\*Notes from intro\***

- Sam Apple is a freelance writer and author of several books, including one recently published called [Ravenous](https://www.amazon.com/gp/product/B08L6Y3W2B/ref=dbs_a_def_rwt_hsch_vapi_tkin_p1_i0) about Otto Warburg, the Nazis, and the cancer-diet connection, which will be discussed in great detail in this show
- Sam teaches in both the MA and science writing and MA and writing programs at Johns Hopkins
- Prior to coming to Johns Hopkins, Sam taught creative writing and journalism at the University of Pennsylvania for 10 years
- He holds a BA in English and creative writing from the university of Michigan and a master in fine arts in creative non-fiction from Columbia University
- This episode will focus on the life story of the life story of Otto Warburg
  - He grew up in Germany before World War II and was influenced by some of the most influential German scientists
- Discussion will focus on his seminal work prior to the second World War and the odd manner in which he was able to remain in Germany unharmed during the second World War despite being both Jewish and gay
- Much of his work would be largely forgotten by the time he died in 1970
  - It would only be about 30 years later that some of his observations would come back to be relevant within the field of cancer biology
  - It’s still not entirely clear if his hypothesis around that observation is correct
    - Peter does not personally think it was
    - But nevertheless, this makes for an interesting discussion

## Sam’s interest in Otto Warburg and work as a writer [2:30]

**Interest in Warburg**

- This story began as an article in 2016 in the [*New York Times Magazine*](https://www.nytimes.com/2016/05/15/magazine/warburg-effect-an-old-idea-revived-starve-cancer-to-death.html)
- Sam’s interest in metabolism began when he read the work of [Taubes](https://garytaubes.com/)
  - Gary Taubes was a recent guest of this podcast ([#167 – Gary Taubes: Bad science and challenging the conventional wisdom of obesity](https://peterattiamd.com/garytaubes/))
- Sam had been interested in metabolism for a number of years but didn’t think of cancer as a metabolic disease or as being lumped together with with obesity, diabetes, and heart disease
  - As he read more he began to see that these diseases clustered together and appear in the same pattern beginning in the 19th century; this sparked his curiosity
- Sam remarked that as he read about [Otto Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) “it was kind of a light bulb moment for me… I knew I was going to write about it [Warburg] and I knew I had a way to tell the story”

**Sam’s path as a writer**

- His father was a writer, though he mostly wrote fiction
- He didn’t choose to follow in his father’s footsteps exactly

> “I like to half joke that my big rebellion was moving into non-fiction” – Sam Apple

- He wasn’t sure what his career path would be in college, but he received a lot of praise for his writing
  - Praise led him to see that writing was his strength; he enjoyed doing it and was good at it
- Being a good writer is a combination of innate ability and always seeking to improve
- He doesn’t think good writing is correlated strongly with intelligence
- The ability to use language in a certain way comes naturally to some people and not others
  - For some, this ability can be developed with enough practice
- Sam teaches writing and science writing at John Hopkins
  - Reading just a paragraph of a student’s writing can tell him what kind of feel they have for language
    - Even 3-4 sentences is enough to reveal a student’s grasp of language and writing
    - He looks for extra words in sentences, tight logic, flow
  - Peter notes that it would be very difficult for him to look at the work of 100 students and rank them according to ability
    - He can read the work of [Siddhartha Mukherjee](https://en.wikipedia.org/wiki/Siddhartha_Mukherjee) and recognize it as really, really good
    - He can also recognize writing that is absolutely horrible, but he might not be able to explain why
- Sam thinks good writing comes down to clarity
  - When reading good writing, one can grasp it right away because the language is concise and clear
  - If writing has to be read 2-3 times to grasp the meaning, then it’s not very good

> “[George Orwell](https://en.wikipedia.org/wiki/George_Orwell) famously wrote about politics and the English language and how much good writing depends on clear, concise thinking” – Sam Apple

- Revision is also essential for good writing
  - Sam notes that “*everything that I write comes out pretty poorly in the first draft, even my emails; if I really care about an email, I spend a lot of time just going over and over and over it because it’s the repetition, it’s correction after correction after correction where the writing starts to improve*”
  - One difference between a good writer and a less good writer is how many times they go over the work before they are satisfied
    - Of course this comes at a cost; time spent worrying about sentences
- After graduating from the [University of Michigan](https://lsa.umich.edu/english/undergraduate/english-major.html), he took a few years off and worked at a magazine
- He then spent 2 years earning a Master of Fine Arts in creative nonfiction at [Columbia](https://arts.columbia.edu/writing)
  - He thought about journalism, but he was more interesting in storytelling and in long-form writing than rigorous reporting
  - In the MA in creative nonfiction program, every semester was essentially a writing workshop
  - They worked in groups of 15 plus a professor and submitted work 3-4 times during the semester
    - Everyone reads and critiquest all the work then discusses it
    - Critique and discussion is the heart of most writing education
      - It can be a grueling process
      - You have to listen to 15 people explaining what is wrong with the submission and often argue if they disagree
      - It’s a little crazy trying to make ones work fit everyone expectations
    - Some writers have been pushing back against this workshop approach because they feel it turns every piece into sort of a formulaic story in order to meet everyone’s expectations
      - This lacks experimental work; this is part of the debate ov writing education
    - Sam feels feedback is essential to know when ones writing is working; so much of it is trial and error
- Peter notes how amazing it is to read the works of authors such as [Atul Gawande](https://en.wikipedia.org/wiki/Atul_Gawande), [Sid Mukherjee](https://en.wikipedia.org/wiki/Siddhartha_Mukherjee), and [Azra Raza](https://en.wikipedia.org/wiki/Azra_Raza), who didn’t train in writing but write beautifully
  - Sam agrees, “*it’s beyond amazing. It’s actually really annoying and frustrating. I’ll admire all three of the people you mentioned. And not only are they exceptional writers, but they’re full-time physicians and doing these incredible things. And it just absolutely blows my mind that they have the time to do it.*”
  - They are almost unimaginably good at writing; very few people reach this level
    - One can still do good work even without reaching that level

## Otto Warburg’s dedication to science and his complicated life in Germany [14:00]

**Otto Warburg’s childhood and inspiration to pursue science**

- He was born into pretty well-to-do German family in the latter third of the 19th century
- His father was [Emil Warburg](https://en.wikipedia.org/wiki/Emil_Warburg), a very prominent physicist in Germany who worked at the University of Berlin despite being Jewish
  - His father was good friends with [Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) and provided some experimental proof for some of Einstein’s theories
    - Einstein was a regular in their house as was [Max Planck](https://en.wikipedia.org/wiki/Max_Planck) and [Emil Fisher](https://en.wikipedia.org/wiki/Emil_Fischer)
    - Warburg grew up knowing Nobel prize winning scientists
- Germany was at the top of the scientific world during Otto Warburg’s childhood and he grew up knowing titans of science
  - Warburg’s vision for himself was to grow up and be a great scientist
  - He wanted to make a world-changing discovery just like his father, Einstein, and Emil Fisher

**Seeing life as a physicist**

- In his rebellion against his father, he moved away from physics and into the realm of biology and physiology
  - But he always understood life through the lens of a physicist
  - He was always interested in energy
  - He wanted to understand biology through an understanding of energy
  - He didn’t so much move away from his father as take physics into a new realm
    - This extended to his study of photosynthesis

**World War I**

- - At the beginning of [World War I](https://en.wikipedia.org/wiki/World_War_I), Warburg was in his early 30s
  - The impact of the war was pretty remarkable on German scientists
    - Many scientists were Jewish
    - Many scientists were ready to go and fight on the front lines
    - Many signed up for the war effort to prove they were full Germans
    - Warburg went to the battlefield while others worked with [Fritz Haber](https://en.wikipedia.org/wiki/Fritz_Haber), who developed chemical warfare
      - Warburg loved horses and joined a cavalry regiment
      - His parents were desperate for him to come home and have Einstein write a letter to him

- Einstein appeals to Warburgs narcissism and wrote *“You’re just too important for science. We can’t afford to lose you.”*

- - - - Not long after, Warburg returns home; the letter from Einstein likely saves his life
- 5 years later Warburg makes his great breakthrough about cancer and fermentation

**Warburg’s pathological dedication to his science**

- Science was like a religious devotion for him
- He was like a prophet who has this fervor; he thought of nothing but science

> “Warburg used to say, “The scientist has to be prepared to die for the truth.” You get a sense of his perspective there.” – Sam Apple

- Sam’s favorite example illustrating Warburgs fervor for science is when a friend told Warburg about someone they knew who was having mental difficulties, Warburg’s advice was to tell this person to think about nothing but science
  - This person wasn’t even a scientist
  - Warburg’s advice was to “*think about science all day*”
  - This illustrates his passion for science
- Sam thinks his devotion to science was partially about narcissism and wanting to be great
  - He also thinks Warburg had a genuine love of science and curiosity about the truth
  - Warburg also had a way to avoid looking internally though
    - Maybe he was covering something up by focusing on science all the time, trying not to look inward
- Warburg was a great narcissist
  - This personality type almost always comes with a deep insecurity
  - Whenever he was criticized, he would lash out and start feuds with other scientists
- Warburg had difficult things to deal with; he had a lot of stress, a lot of psychological issues
  - Being Jewish in Germany wasn’t easy, even before the Nazis
  - He was also homosexual
    - He spent his whole life with his male partner (Jacob Heiss) but couldn’t be out at that time in Germany
    - His mother pressured him to get married and questioned his lifestyle
  - There were all sorts of rumors about him
  - He refuses public speaking during his training
    - For this, anyone else would have failed out of school
- There is no record of him meeting [Hitler](https://en.wikipedia.org/wiki/Adolf_Hitler)

## Warburg’s interest in cancer and early discoveries about cellular consumption of oxygen [23:00]

- In 1918 Warburg is given an incredible position, his own wing in the Kaiser Wilhelm Institute for Biology
  - This is the pinnacle of German science
  - Germany created the [Kaiser Wilhelm Society](https://www.mpg.de/195494/Kaiser_Wilhelm_Society), which is now the [Max Planck Society](https://www.mpg.de/en)
    - It was supposed to be the [Oxford](https://www.ox.ac.uk/) of Germany
    - The idea was to get the best scientists in the world and give them everything they needed
    - It was inspired by the Rockefeller model, the [Rockefeller Institute](https://www.rockefeller.edu/about/history/) in the United States.
- After World War I, as his lab is under construction, the wealthy funders of the Kaiser Wilhelm Society become bankrupt
- He has to write a grant proposal for one of the only times in his life
  - This is very difficult for him because he is so narcissistic
  - He finally scribbles on a piece of paper, “I need 10,000 Marks,” and he actually gets the money
- He works first on photosynthesis (before cancer)
  - When his father was trying to get him out of the war, he made the case that Warburg was needed for photosynthesis research….make photosynthesis more efficient to grow more food
    - Germans had been starving throughout much of World War I
  - When Warburg came back from the war to do research, he wanted to solve world hunger
    - This remained an interest of his throughout his life
- He was always interested in cancer
- At one point, Warburg asked a famous scientist “*Should I do photosynthesis or cancer?*” And the scientist says, “*Do cancer. Photosynthesis is working pretty well.*”
- Warburg wants to make a world-changing discovery and cancer had become a German obsession by the 1920’s
  - In the early 19th century there’s not much cancer
  - Cancer rates really increased in the 1920’s and 1930’s
    - There is a panic because so many people are getting cancer
    - The rates then still pale in comparison to today’s rates
  - Put this context, this followed the work of [Robert Koch](https://en.wikipedia.org/wiki/Robert_Koch) and [Paul Ehrlich](https://en.wikipedia.org/wiki/Paul_Ehrlich) who figured out bacteriology and infectious disease
    - [Koch’s postulates](https://en.wikipedia.org/wiki/Koch%27s_postulates) were published in 1884, this was a method to identify the microbial cause of an infectious disease
    - Paul Ehrlich developed the [first drug treatment for syphilis](https://en.wikipedia.org/wiki/Arsphenamine) and began the field of antimicrobial chemotherapy
      - He also developed staining methods
        - To distinguish blood cells
        - To differentiate types of bacteria
    - In this context, it seemed natural that scientists would figure out and cure cancer

> “Warburg worshiped Ehrlich and Koch and thought he was going to be the next one to make this great discovery” – Sam Apple

- As Warburg studies cancer he discovers that cancer cells eat differently than other cells
  - Cancer cells [ferment](https://en.wikipedia.org/wiki/Fermentation#Lactic_acid) glucose rather than breaking it down and burning with oxygen ([oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation))

> “So this cancer cell shift to fermentation is a remarkable discovery and ends up occupying his life, his thoughts, and he ends up focusing on that for much of his life.” —Sam Apple

**Warburg’s early discoveries about cellular consumption of oxygen [26:45]**

**Oxygen consumption in proliferating cells**

- Warburg was studying [sea urchin eggs](https://en.wikipedia.org/wiki/Sea_urchin)
- His early studies found eggs would increase their oxygen consumption when they were about to grow and proliferate
  - This made sense, energy is needed to grow and oxygen consumption is involved in the more efficiency way of making energy for the cell, [respiration](https://en.wikipedia.org/wiki/Cellular_respiration#Aerobic_respiration)
- In 1923 when Warburg turns his attention to cancer, he expects to see the same thing, cancer cells utilizing more oxygen
  - He takes a slice of a tumor from a rat and he attaches it to a manometer to measure changes in gas pressure
    - A [manometer](https://en.wikipedia.org/wiki/Pressure_measurement#Liquid_column_(manometer)) is U-shaped tube which can just measure changes in gas pressure
  - He doesn’t see any increase in oxygen consumption by the tumor slice culture
  - He checks the solution and finds it is full of [lactic acid](https://en.wikipedia.org/wiki/Lactic_acid)
    - This is produced from fermentation of glucose (an alternative to aerobic respiration)
  - He then tests people with cancer and finds that they have more lactic acid in their blood
- Every test he carried out points to the same conclusion, cancer cells are taking up a lot of glucose and fermenting it to lactic acid
  - Cancer cells used less oxygen than he would expect
- Warburg wasn’t the first to observe human cells fermenting glucose
  - Previously, [Otto Meyerhof](https://en.wikipedia.org/wiki/Otto_Fritz_Meyerhof) had shown that human cells can do many things microorganisms can
  - Warburg was close to Meyerhof and was familiar with his work

**Fermentation**

- Warburg didn’t know why a cell would use fermentation when oxygen was available
  - Fermentation was thought to be a compensatory mechanism used when there wasn’t enough oxygen or if there was damage to the [mitochondria](https://en.wikipedia.org/wiki/Mitochondrion)
    - See a diagram of the mitochondria below
    - The mitochondria is where [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation) takes place; this involves the electron transport chain and is the final phase of cellular respiration
      - This is the part of cellular respiration that produces the most energy ([ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate))

![](https://peterattiamd.com/wp-content/uploads/2021/12/f1-samapple.jpeg)

**Figure 1. The mitochondria, an organelle where oxidative phosphorylation takes place.** Image credit: OpenStax Biology 2e [Figure 7.6](https://openstax.org/books/biology-2e/pages/7-1-energy-in-living-systems#fig-ch07_01_04)

- What is now called the Warburg effect describes the use of fermentation by cancer cells (instead of respiration) when oxygen is present
  - This is also called [aerobic glycolysis](https://en.wikipedia.org/wiki/Aerobic_fermentation) (or aerobic fermentation); aerobic refers to the presence of oxygen

**Fermentation of glucose (aerobic glycolysis) compared to cellular respiration**

- [Fermentation of glucose](https://en.wikipedia.org/wiki/Cellular_respiration#Fermentation) uses [glycolysis](https://en.wikipedia.org/wiki/Glycolysis) plus one more [reaction](https://en.wikipedia.org/wiki/Lactate_dehydrogenase) to produce energy ([ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate)) and  lactic acid
  - This produces a net gain of 2 ATP, shown in the diagram below
  - Fermentation occurs in the cytoplasm not mitochondria
- [Cellular respiration](https://en.wikipedia.org/wiki/Cellular_respiration#Efficiency_of_ATP_production) also begins with glucose and [glycolysis](https://en.wikipedia.org/wiki/Glycolysis); then it uses the [citric acid cycle](https://en.wikipedia.org/wiki/Citric_acid), and the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain) to produce energy (ATP), CO2, and water
  - This produces a net gain of between 30-36 ATP
  - The electron transport chain performs [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation) to produce vastly more energy
  - The citric acid cycle and electron transport chain are located in the mitochondria, shown in the diagram below, labeled simply as cellular respiration
- There is a huge difference in the energy yield between fermentation and cellular respiration
  - Respiration produces on the order of 17x more ATP

![](https://peterattiamd.com/wp-content/uploads/2021/12/f2-samapple-1024x903.png)

**Figure 2. Energy produced by fermentation of glucose as compared to cellular respiration** Figure credit: OpenStax Anatomy and Physiology [Figure 10.12](https://openstax.org/books/anatomy-and-physiology/pages/10-3-muscle-fiber-contraction-and-relaxation#fig-ch10_03_05)

![](https://peterattiamd.com/wp-content/uploads/2021/12/f3-samapple-1024x768.png)

**Figure 3. Pathways used in lactic acid fermentation.** Figure credit OpenStax Biology 2e [Figure 7.16](https://openstax.org/books/biology-2e/pages/7-5-metabolism-without-oxygen#fig-ch07_05_02)

- The only reason to ferment glucose is because it produces energy more quickly
  - The pathways is shorter needing only glycolysis and 1 more reaction, shown in the figure above
  - This inefficient pathway cannot be sustained for long because lactic acid (lactate) makes the environment acidic
    - Lactic acid releases a [hydrogen ion](https://en.wikipedia.org/wiki/Acid); this lowers the pH
    - This makes it difficult for the actin and myosin filaments in muscle to release causing a burning feeling during intense exercise that is erroneously attributed to lactate
      - During [muscle contraction](https://en.wikipedia.org/wiki/Muscle_contraction) myosin in thick filaments will bind to actin in thin filaments in succession to pull the thin filaments past the thick filaments
        - The repeated binding of different actin molecules by myosin during muscle contractions is called the [cross-bridge cycle](https://en.wikipedia.org/wiki/Muscle_contraction#Cross-bridge_cycle)
        - Myosin has difficulty releasing actin in an acidic environment
- The term aerobic fermentation is a paradox
  - It refers to the choice of the cell to ferment glucose when oxygen is available
  - Fermentation is used even though a more efficient process for generating energy is available (cellular respiration)

*How did he then explain the observation? And what was his hypothesis in light of that observation?*

- Warburg thought there must be something wrong with the mitochondria in cancer cells
  - This was the only explanation he could come up with to explain their preference for fermentation of glucose
  - He didn’t have a full understanding of the mitochondria

## The role models who fueled Warburg’s desire to make a great discovery [34:15]

**Louis Pasteur**

- Warburg idolized [Pasteur](https://en.wikipedia.org/wiki/Louis_Pasteur); his library was set up so he would gaze at a portrait of Pasteur
  - On one side was a portrait of [Robert Koch](https://en.wikipedia.org/wiki/Robert_Koch) and on the other side [Paul Ehrlich](https://en.wikipedia.org/wiki/Paul_Ehrlich)
  - Pasteur discovered that microbes didn’t need oxygen to grow, they could ferment nutrients
    - This was shocking to see life without air
    - Pasteur discovered this seesaw-like relationship between cellular respiration with oxygen and fermentation; as one goes up the other goes down; this is called the [Pasteur effect](https://en.wikipedia.org/wiki/Pasteur_effect)
      - Other scientists found this trend when studying frogs
      - Everyone understood this relationship, the Pasteur effect
- Fermententation was thought of as lower and less noble than respiration
- For Warburg it was shocking to see a cell choose to use fermentation when oxygen was available
- Warburg didn’t have a good way to test the hypothesis that cancer cells were fermenting glucose because something was wrong with their mitochondria
  - The tests he performed simply showed fermentation of glucose; he couldn’t show any problem with the mitochondria
  - He didn’t seem to recognize this as a limitation either
  - His early tests showed fermentation was increasing while respiration continued at a steady pace
    - He sort of denied or explained away respiration
    - He felt it was the job of respiration to repress fermentation and if this relationship wasn’t working then it was broken
- This is ironic because there is no way to know if this observation is the cause or effect of cancer

**Robert Koch and Koch’s Postulates**

- The scientific hero of the era was [Robert Koch](https://en.wikipedia.org/wiki/Robert_Koch), the German scientist who discovers the causal relationship between microorganisms and infectious diseases
  - He starts with anthrax, then he has his great breakthrough with [tuberculosis](https://en.wikipedia.org/wiki/Tuberculosis#History)
  - He develops [Koch’s postulates](https://en.wikipedia.org/wiki/Koch%27s_postulates), a method to identify the microbe that causes an infectious disease
    - Koch’s postulates are a series of 4 steps, outlined in the figure below needed to show a microbe is a causative agent of disease
    - Prior to this microbes were relatively unknown and diseases were not successfully treated
  - Warburg grew up with Robert Koch as a model of one of the greatest men of his generation
    - Koch’s postulates are famous for showing how one thing can cause another and what conditions have to be met to show that a microorganism actually causes a disease

![](https://peterattiamd.com/wp-content/uploads/2021/12/f4-samapple-1024x739.jpeg)

**Figure 4.  Koch’s postulates are a 4-step process used to determine what microbe causes an infectious disease.**  Figure credit: OpenStax Microbiology [Figure 15.4](https://openstax.org/books/microbiology/pages/15-2-how-pathogens-cause-disease#OSC_Microbio_15_01_Koch)

> “It’s a very rigorous logic that again I think we all take for granted today, but at the time it was remarkable and it demonstrated the causal relationship between these various microorganisms and the diseases they caused” – Peter Attia

- These postulates were a key breakthrough, before it was known that one could transfer disease by taking blood, etc. from one organism to another and transfer disease
- Koch understood that first the microbe needed to be grown outside the body so that only 1 thing was transferred
  - He wanted to prove that it was the microbe itself that cause disease by growing it independently then taking some and injecting them
- Hitler also idolized Robert Koch and this idea of causality
  - He referred to himself as the “Robert Koch of politics”
  - He said Koch saved the world through science by eliminating the microbes, the microorganisms that cause disease
- This was the context where Warburg said “every disease has a prime cause and a secondary cause”
  - He used the analogy of Robert Koch that the prime cause of infectious disease is a microbe
  - There are all sorts of secondary causes: unsanitary conditions that allow a microbe to get into a person, plagues, anything that causes a microbe to get into a person’s blood

## How Warburg described the primary and secondary causes of cancer [42:15]

**Primary cause**

- Warburg said the most fundamental thing about cancer is the shift to fermentation
  - He claims this is the primary cause, although there was never proof for this
  - Today people say maybe 70% of cancers shift to fermentation
    - All cancers will shift to fermentation as oxygen becomes less available

S*econdary*

- Anything that causes fermentation can be thought of as a secondary cause
  - Anything that damages the mitochondria and causes fermentation such as a chemical or virus
  - It’s always viewed through the lens of a structural problem, whereby the seesaw-like relationship between respiration and fermentation is damaged to favor fermentation

*What did Warburg believe accounted for the significant increase in the prevalence of cancer leading up into the 1920s and 1930s as a secondary cause by his definition?*

- He was very worried about environmental carcinogens as a secondary cause of cancer
- The prevalence of cancer increases significantly in the 1920s and 1930s
- Warburg likely attributed secondary causes of increased cancer rates to environmental carcinogens
  - In Germany, he campaigns against many sources of chemicals such as smog from automobiles and busses, and food dyes
  - He becomes an organic farmer; his partner (Jacob Heiss) is the only person allowed to cook for him
  - He has his own well for water

> “I think [Otto Warburg’s] influence is much wider than many people realize… he ended up having a massive influence on American life. Just nobody knows about it.” – Sam Apple

- His hypothesis was that the chemicals in our food first and foremost were poisoning the mitochondria and causing the shift to fermentation
- [Rachel Carsom’s](https://en.wikipedia.org/wiki/Rachel_Carson) book [Silent Spring](https://www.amazon.com/Silent-Spring-Rachel-Carson/dp/0618249060/ref=sr_1_1?crid=WBIQY5AEV4OH&dchild=1&keywords=silent+spring+rachel+carson&qid=1634836621&qsid=142-0109206-4649519&s=books&sr=1-1&sres=0618249060%2CB01FGOGFP8%2C1598535609%2CB002E8JF6G%2C0190906766%2C1698901224%2C1598537059%2CB000UZQFX6%2C0143104969%2C0823431932%2CB007MGSNQI%2CB004TC14F0%2C0063088207%2C0448479591%2C1626728194%2C0897339339&srpt=ABIS_BOOK), was hugely influential; it really changed American environmental policy
  - Warburg is actually the first cancer scientist mentioned in the book
  - It’s clear that that’s exactly how she viewed cancer, she saw all these environmental chemicals as causing cancer via the damage to respiration that Warburg cited

> “I think he ended up having a massive influence on American life. Just nobody knows about it.” —Sam Apple

## Warburg’s Nobel Prize in 1931 [45:45]

- Warburg won the [1931 Nobel prize](https://www.nobelprize.org/prizes/medicine/1931/summary/) in physiology or medicine for his work on respiration and understanding how the electron passes down the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain) and reacts with oxygen
  - At the time he believes the reaction with oxygen is the only step in the electron transport chain
  - Really it’s the final step in the electron transport chain
  - He wins the Nobel prize for elucidating the involvement of oxygen in the process of respiration [discussed further later in this podcast]
- Many people think he got the Nobel prize for cancer, but that’s not true
  - He was nominated in 1926, and should have won for his cancer research, but he doesn’t

## Warburg’s life and work during WWII in Nazi Germany [46:30]

**Warburg gets his own institute and stays in Germany**

- 1931, the Rockefeller foundation built a beautiful institute for Warburg
  - He designed the institute himself after a country manor that he admires
  - He is on top of the scientific world, having just won the Nobel prize
- 1933 his colleagues begin to flee Germany; they see what’s coming but he refuses to
  - He’s not going to give up his kingdom
  - He says, “I was here before Hitler”
- Like a lot of Germans, he believed the Nazi phenomenon would be short-lived
  - Warburg thought they would be gone in maybe 6 months or a year
  - He called them Bavarian noisemakers
  - He was so arrogant and so narcissistic that he couldn’t fathom anybody telling him what to do
  - He didn’t think there was any way Nazi thugs were going to kick him out of his institute
- Sam notes, “*I think the most shocking thing about his story is he has a famous Jewish name, his father’s Jewish. So he’s Jewish by the Nazi standards. He lives with his male partner. He should have been as vulnerable as anybody in Nazi Germany.*”
  - He provokes the Nazis; he was in a dangerous situation
    - He screams at them when they come to his Institute, demanding Aryan descent forms
    - He won’t do the Hitler salute
    - He won’t put up the Nazi flag
  - The NY Times wrote an article about him being in jeopardy in 1936; he was famous enough to be written about in the Times
  - Warburg was very stubborn; he said to his sister at one point that “*It’s going to be either me or them. I’m not budging*”
    - The more pressure he got, the more he insisted on staying because he couldn’t stand to think that he would lose that battle
    - At the time it was considered shameful to leave and accept that one was somehow a lesser German
      - This was the antithesis of everything Warburg stood for
- Warburg’s sister, Lotte, kept a diary; she was a writer, and she wrote a great deal about him
  - This was one of Sam’s key sources
- Warburg didn’t keep a diary, but he wrote a lot of letters
  - Because he was famous and such a character, whenever somebody encountered him, they would often write down their impressions
  - He did scribble a few notes in the back of his notebooks at the very end of the war
    - He was dealing with guilt for not protecting certain people who worked for him, who were forced into the military
    - He began to write out his defenses a few sentences at a time
    - It gave a window into how persecuted he felt at the end and maybe even guilty
- Most of the Jewish people he was associated with left Germany
- In the Kaiser Wilhelm Society, there were around 2,500 Jews at various institutions
  - Warburg was the only one who stayed until the very end
- What a lot of people don’t realize is that German Jews, in many cases, were more likely to survive the Holocaust than other European Jews
  - Although some of his cousins were murdered in the camps; he wasn’t close to them
  - He didn’t lose many people who were close to him
  - It would be impossible for him to had not have known a lot of people who died
  - He certainly knew hundreds or thousands of people who fled for their lives
    - In the early 30’s there was the opportunity to leave Germany, but it was extraordinarily difficult because they would take all your wealth
    - A lot changed after the war started; at that point many were in great danger
    - It was very different for Eastern Europe where the Holocaust really begins; many never had a real opportunity to escape when the Germans rolled in
- Warburg was famous and the Nazis saw a propaganda value in having him around
  - The Berlin Olympics are held in 1936; they’re able to show that this guy has Jewish ancestry is still here working in Germany
  - His propaganda value is useless once the war starts
- He is in increasingly grave danger throughout the late 30’s
- [Meyerhof](https://en.wikipedia.org/wiki/Otto_Fritz_Meyerhof), who’s also a Nobel prize winner, escapes in 1938 and flees to France
  - When the Germans roll into Austria in ‘38, many Austrians Jews escape

**June 21, 194:1: Warburg is called into Nazi headquarters [54:00]**

- It comes to a head June 21, 1941 when Warburg is called into Nazi headquarters to meet withe [Viktor Brack](https://en.wikipedia.org/wiki/Viktor_Brack)
  - The war is in full swing; there’s no value in keeping Warburg alive for propaganda
  - Viktor Brack is the guy who designs the euthanasia killing program that sort of starts the mass killing
  - Warburg has received an eviction notice from his Institute
    - He had a lot of enemies in German science even before all this started
  - He’s told he will be allowed to live on one condition, he must focus on cancer research
    - German historians recorded this meeting
    - No one realized the importance of this moment in German history; at dawn, the next morning, the German tanks rolled into Soviet territory
      - It was the launch of [Operation Barbarossa](https://en.wikipedia.org/wiki/Operation_Barbarossa), which is, at the time, the biggest military invasion in history
  - This is the context when the Nazis were worrying about Warburg; the meeting was even in [Himmler’s](https://en.wikipedia.org/wiki/Heinrich_Himmler) day planner
  - In [Goebbels](https://en.wikipedia.org/wiki/Joseph_Goebbels)’ diary, he records hours before the [Operation Barbarossa](https://en.wikipedia.org/wiki/Operation_Barbarossa) that he and Hitler were talking about cancer research
    - It doesn’t mention Warburg’s name but it seems Hitler knew what was going on
    - There is evidence of Hitler’s direct involvement because Warburg applied for a [German Blood Certificate](https://en.wikipedia.org/wiki/German_Blood_Certificate)
      - This is a document for someone with partial Jewish heritage declaring them of German blood
      - Hitler reviewed these applications
      - He probably decided on June 21, 1941 to approve his application and let Warburg continue to focus on cancer
      - Warburg gets the papers he needs to continue living and working in Germany

**Hitler’s interest in cancer**

- - When Hitler was a teenager, he lost his mother to breast cancer
    - Historians say that his mother was really the only person he was capable of loving
    - Hitler is distraught; the Jewish doctor who cared for his mother wrote a reflection on the experience, “*he said in his entire life, he’s never seen anybody look as dejected as Hitler*”
    - Hitler okayed experimental treatments on his mother, which left her writhing in pain
      - And, he was there at the bedside

- *For the rest of his life, Hitler was obsessed with cancer*

- - - He talked about it constantly in his speeches, as a metaphor
    - He was also a hypochondriac who constantly had stomach problems and thought he had stomach cancer
- Trying to eliminate cancer became a huge part of the Nazi project
  - They actually did make some advances in cancer prevention, though for all the wrong reasons
- German science was very prominent going into the second World War
  - Early 20th-century, one had to speak/read German to be a scientist
  - It’s incredibly how many early Nobel prize winners were Germans
    - Warburg said he could have won a second Nobel prize during WWII but the Nazi’s wouldn’t allow it (although there’s no evidence that that was the case)
      - His work on cancer certainly deserved it, says Sam
  - There was a huge shift in German science after the war

## Warburg’s research in hydrogen transfers and coenzymes—his best science? [59:45]

**The electron transport chain, the final part of respiration**

- Warburg won the [Nobel Prize in Physiology in 1931](https://www.nobelprize.org/prizes/medicine/1931/summary/) for understanding the last stage of respiration where oxygen is utilized
  - This enzyme is now called [cytochrome oxidase](https://en.wikipedia.org/wiki/Cytochrome_c_oxidase) (complex IV of the electron transport chain)
  - The whole time Warburg had been saying this [reaction with oxygen] was the only thing one needed to know for respiration
    - This was analogous to what he said about cancer, that the switch to fermentation was all one needed to know
  - He finally accepted that respiration and what happens at the electron transport chain is actually a multi-step process, outlined in the figure below
    - Respiration doesn’t just occur directly with oxygen, but hydrogens are ripped off nutrients and passed down the electron transport chain to oxygen at the end

![](https://peterattiamd.com/wp-content/uploads/2021/12/f5-samapple.jpeg)

**Figure 5. The electron transport chain is the final part of respiration and the process that generates the most ATP.** Figure credit: OpenStax Biology 2e [Figure 7.12](https://openstax.org/books/biology-2e/pages/7-4-oxidative-phosphorylation)

- He then became interested in hydrogen transfers in respiration and understanding how the reaction takes place
  - This is his focus in the 40’s
  - Many people think this is the best science he did
  - He made huge advances in understanding the role of coenzymes and how they react with hydrogen and allow for these transfers
  - This was innovative work that set the stage for decades of enzyme research
  - This led to the discovery of [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) among other things
    - He deserved another Nobel prize for this work but Sam didn’t find any evidence that he was in the running to get one

> “But I think he fairly deserved three Nobel prizes” – Sam Apple

**His work on the coenzyme NAD**

- Warburg studied the electron transport chain and the movement of electrons and hydrogen back and forth between NAD and NADH
- Warburg’s earlier work had focused on indirect evidence using lights at different wavelengths to identify enzymes
  - This technique generates a fingerprint of cells
  - Light patterns are used to identify cellular enzymes
- In the ‘30’s he’s trying to isolate enzymes and perform chemical analysis to determine the reactive components
- He was working on what he called the “in-between ferment”, which we now know as [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide)
  - He can only isolate a small amount from horse blood, not enough for chemical analysis
  - At one point he says “To figure this out, I’m going to need to kill all the horses in Germany”
  - He asks a friend who worked in the chemical industry in Germany to see if he can find anything similar to NAD; this friend finds an exact match, [nicotinic acid](https://en.wikipedia.org/wiki/Niacin) (niacin)
    - This is a chemical that had been used in photography for decades
    - Warburg remarks, “*Wherever I’m sitting, a day ago, I couldn’t buy it for all the money in the world; and now, I can get it for two marks.*”
- Nicotinic acid turned out to be hugely important, not only for understanding respiration but for understanding the disease [Pellagra](https://en.wikipedia.org/wiki/Pellagra)
  - **Pellagra was solved** after Warburg made this discovery and someone thought to give nicotinic acid to people with this disease to see if it cured them; it did
    - Warburg wanted to make a great discovery and save lives; he actually did, but he never saw it that way

## Warburg’s decision to stay in Germany after WWII [1:03:30]

**Why Warburg stayed in Germany after WW2**

- Warburg stays in Germany after the war ends
  - He thinks about moving
  - He comes to America in the late ‘40’s and stays in a couple different labs for 6 months each
  - The Rockefellers didn’t want anything to do with him because of his connection to Germany
    - This is ironic because he hated the Nazis as much as anyone
- He makes more and more extreme statements about cancer; this alienates many people
- There’s not a future for him in America
  - In the 50’s the American’s give him back his institute in Germany; they had taken it over during military occupation of Berlin
  - He goes back to his beautiful Institute and he has, again, some propaganda value for the Germans; they can say, “*Look, we’ve given this person of Jewish descent his Institute back, and he’s living here and thriving in Germany.*”
    - He continues his research as if nothing had happened
- It’s an interesting story how he ended up in west Berlin
  - In 1943, bombs are falling near his Institute, and he’s actually moved to a new Institute that the Nazis built him
  - They refurbished this beautiful sea house for Warburg in the middle of the worst part of the war for them
    - Put this in context, his move occured in a time where there was no gasoline for anything; it was forbidden to build anything if it’s not for the war effort
    - Time was made to build something for Warburg to continue his cancer research in a safer place; and that Institute actually ended up in Soviet territory
- When the war ends, he is under Soviet rule and has to escape back to the west, meanwhile the Soviets were trying to recruit him more so than the Americans
  - A lot of great German scientists (and also Nazis) were smuggled into America for the purpose of American science; the Soviets were going after them too
- Warburg’s Institute is in west Berlin, so he ends up staying on the American side ultimately

## Discovery of oncogenes in the 1970s and the decline in interest in Warburg’s ideas [1:07:30]

- Warburg had a feud with [Sidney Weinhouse](https://www.nasonline.org/publications/biographical-memoirs/memoir-pdfs/weinhouse-sidney.pdf) in the 50’s or so
  - Weinhouse was a biochemist who also studied metabolism in cancer cells
  - Weinhouse worked in the Philadelphia suburbs; he died in 2001
  - Unlike Warburg, Weinhouse was a mild-mannered guy
  - He publicly called Warburg out and said he didn’t agree with the interpretation
    - The new headline at the time was “Cancer Theory Overthrown”
    - Though Weinhouse was deferential to Warburg in the article
    - Weinhouse said “*Look, there’s no difference in oxygen consumption between these cells. And, there is no evidence that the mitochondria are damaged.*”
  - They had a back and forth in the journal [Science](https://www.science.org/action/doSearch?AllField=on+respiratory+impairment+in+cancer+cells)
    - Warburg is a really elegant writer; Sam admires his writing
    - He makes much bolder statements and denounces his opponents in a way that Weinhouse doesn’t
    - Weinhouse is a more humble scientist
    - Weinhouse challenges the belief that cancer cells have defective mitochondria; he sees respiration occurring just fine

***What is it about the discovery of DNA that would ultimately change the course of Warburg’s discovery and this entire field of cancer metabolism for decades to come?***

**By the ‘50’s and ‘60’s Warburg is fading from prominence**

- [Oncogenes](https://en.wikipedia.org/wiki/Oncogene) were discovered in the mid ‘70’s
  - This was the first time scientists had shown that mutation of specific genes could cause cancer
  - This begins a new study of cancer molecular biology focused on genes and [signal transduction pathways](https://en.wikipedia.org/wiki/Signal_transduction)
    - The study of metabolism and enzymes in cancer seems like old world biochemistry

> “And, it’s just amazing to me how quickly Warburg gets relegated to the old world, and nobody’s interested. By the nineties, students don’t know his name.” – Sam Apple

- Warburg dies in 1970

**Fundamental traits of cancer and oncogenes**

- In the year 2000, [Robert Weinberg](https://en.wikipedia.org/wiki/Robert_Weinberg_(biologist)) co-authors a [paper](https://www.cell.com/cell/fulltext/S0092-8674(00)81683-9?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867400816839%3Fshowall%3Dtrue) on the six fundamental traits of cancer and doesn’t include the Warburg effect or mentioned Warburg or metabolism
  - They publish a [revised review](https://www.cell.com/cell/pdf/S0092-8674(11)00127-9.pdf) of the hallmarks of cancer in 2011 and include Warburgs work on altered metabolism
- By in large, Warburg is gone from cancer science, gone from textbooks
  - Weinberg’s famous [textbook on cancer](https://www.amazon.com/Biology-Cancer-Robert-Weinberg/dp/0815340761/ref=sr_1_2?crid=1S6YP47ONW9F6&dchild=1&keywords=biology+of+cancer+weinberg&qid=1634924310&qsid=142-0109206-4649519&s=books&sprefix=biology+of+cancer+weinberg%2Cstripbooks%2C85&sr=1-2&sres=0815342209%2C0815340761%2C0815340788%2CB017PNXS3U%2C0716750376%2CB011T7Q9YI%2CB012UML40A%2CB0053GT5TS%2C0198833024%2C0198779453%2C1975149114%2C1632428814%2C1107601487%2C1982115858%2C0198717342%2C303075698X&srpt=ABIS_BOOK), published in 2006 doesn’t mention Warburg
- Mukherjee’s [book on cancer](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439107955/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634924496&sr=1-1) (which Sam thinks is absolutely brilliant) also doesn’t mention Warburg, because nobody was mentioning him
- The enzymes Warburg studied were simply referred to as housekeeping enzymes (encoded by [housekeeping genes](https://en.wikipedia.org/wiki/Housekeeping_gene))
  - Cancer cells need energy to divide but it wasn’t thought of as fundamental to the process of cancer, they only supplied something cancer cells needed

> “It’s really shocking to me that something so fundamental could just get lost, but to some extent, that’s how science works. There’s an exciting new thing, and it’s hard to focus on two things at once.” – Sam Apple

- Oncogenes are discovered in the ‘70’s and [Harold Varmus](https://en.wikipedia.org/wiki/Harold_E._Varmus) and [Michale Bishop](https://en.wikipedia.org/wiki/J._Michael_Bishop) are awarded the [Nobel prize in 1989](https://www.nobelprize.org/prizes/medicine/1989/summary/) for their discovery
- Peter notes that by the time he was in medical school in the late ‘90’s he had memorized so many [oncogenes](https://en.wikipedia.org/wiki/Oncogene) and [tumor suppressor genes](https://en.wikipedia.org/wiki/Tumor_suppressor_gene), all the pathways and such

## The renaissance of Warburg’s ideas on cancer metabolism and a new explanation for the Warburg Effect [1:13:45]

**Altered metabolism in cancer cells**

- Peter first heard of Warburg in a [*Science* paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) from 2009 written by [Matthew Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) and co-authored by [Lew Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) and [Craig Thompson](https://en.wikipedia.org/wiki/Craig_B._Thompson)
  - Lew has been on the podcast ([#110 – Lew Cantley, Ph.D.: Cancer metabolism, cancer therapies, and the discovery of PI3K](https://peterattiamd.com/lewcantley/))
  - It seemed that the idea of metabolism mattered even though it was not at the forefront of the field
- Sam thinks the revival of Warburg’s ideas began in the mid to late ‘90’s in 2 key labs:
  - (1) Craig Thompson (now president CEO of [Memorial Sloan Kettering](https://en.wikipedia.org/wiki/Memorial_Sloan_Kettering_Cancer_Center))
  - (2) [Chi Van Dang](https://wistar.org/our-scientists/chi-van-dang) (who at the time was at [Johns Hopkins](https://en.wikipedia.org/wiki/Johns_Hopkins_University))
  - Both were working on understanding cancer molecular biology and tracing signaling pathways in the cell and working their way back to metabolic enzymes
  - Chi found the transcription factor, [MYC](https://en.wikipedia.org/wiki/Myc), was activating [lactate dehydrogenase](https://en.wikipedia.org/wiki/Lactate_dehydrogenase) (LDH)
    - He was shocked to find this pathway leading back to a basic fermentation reaction
    - He became very curious about Warburg and reading the old papers on enzymes and really helped launch a lot of the metabolism revival
  - Craig Thompson and Vander Heiden (who was then a student in Craig’s lab) were studying [AKT](https://en.wikipedia.org/wiki/Protein_kinase_B)
    - It was know that AKT could act as an oncogene and cause cells to proliferate, but its role in metabolism was surprising
    - [AKT acts to allow glucose into the cell](https://en.wikipedia.org/wiki/Protein_kinase_B#Metabolism) and Thompson found that its effects on proliferation are downstream of its effects on glucose uptake

**New view on increased fermentation rates observed in cancer cells**

- This [2009 paper by Vander Heiden](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) *et al.* is interesting because it a**cknowledges the Warburg effect but comes up with a different explanation** and 3 key points
  - Prior to this, the Warburg view is that fermentation occurs in cancer cells in response to defective mitochondria
    - Fermentation is a backup generator to produce energy for the cell
  - 1) This paper argues that there is not evidence for defective respiration; the mitochondria seem functional and intact
  - 2) Other reasons cells may take up a lot of glucose is to synthesize new nucleotides, lipids, etc for daughter cells; this is argued as the main reason for taking up so much glucose
    - Thus cancer cells prioritize metabolic pathways for proliferation rather than efficient production of ATP
    - Most scientists now agree with this explanation
  - 3) Cancer cells are getting some energy from respiration and some from fermentation

“*So, it makes sense that glucose uptake would increase rapidly, but the cells, they actually, they’re getting some energy, some ATP from respiration, some from fermentation, but they have enough to continue to function. What they really need are the building blocks for growth. And, so that is a sort of new way to understand the Warburg Effect*.”

**Some scientists still agree with Warburg**

- Sam interviewed [Thomas Seyfried](https://www.bc.edu/bc-web/schools/mcas/departments/biology/people/faculty-directory/thomas-seyfried.html), and he agrees with Warburg that mitochondria are defective in cancer cells and this is the reason for excess glucose uptake and the switch to fermentation

- - Review article from 2010 [*Cancer as a Metabolic Disease*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2845135/)
  - There are other smart, accomplished scientists who also think Warburg got it right
- But Sam interviewed many more people who felt that Warburg was wrong about the problem of defective mitochondria
- Through Sam’s research, he sides more with Cantley, Thompson and Vander Heiden

***What is cancer?*** **— a presentation from Craig Thompson**

- [Craig Thompson](https://www.mskcc.org/research/ski/labs/craig-thompson/overview) gave a demonstration for students explaining cancer metastasis, he shows “everybody’s first cancer experiment”, mold growing on a piece of bread (begin this [YouTube](https://youtu.be/WUlE1VHGA40) video at 12:00)
  - This goes back to [Pasteur](https://en.wikipedia.org/wiki/Louis_Pasteur) and understanding *proliferative metabolism*; this happens in lots of cells (not just microorganisms) in response to defective respiration
    - Pasteur was wrong when he thought proliferative metabolism was unique to microorganisms
    - This occurs when a cell has access to many nutrients all at once
  - Back to the moldy bread example, the mold doesn’t care how much oxygen is available, they simply eat the bread, grow and multiply
    - The availability of nutrients is the key to what causes this proliferation to take off
    - In single-celled organisms (mold) the availability of nutrients is key
    - In advanced organisms (animals) it’s more complicated, nutrients, hormones, growth factors, etc. are involved
- Cancer is a **problem of growth**
  - What causes cells to grow – nutrients and hormones
    - Had the science progressed in a different way, then this would have always been the focus
    - However, the ability to measure insulin in the blood wasn’t possible until the late ‘60’s
    - The discussion of the Warburg effect in cancer as a response to damaged respiration made sense in the context of not understanding the role of insulin and growth factors in cell division
- Sam tends to view cancer in the way described by Thompson, Cantley, and Vander Heiden ([publication](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/))
- He also thinks [Seyfried](https://www.bc.edu/bc-web/schools/mcas/departments/biology/people/faculty-directory/thomas-seyfried.html) deserves a ton of credit for sort of bringing metabolism back into the conversation
  - Everybody agrees that as a cancer progresses, blood vessels are no longer delivering oxygen in the same way, and that’s clearly playing a role in revving up fermentation

## The argument against the Warburg Effect as a primary cause of cancer and the potential role hyperinsulinemia [1:21:15]

**Is the Warburg effect a primary cause of cancer?**

- Sam’s view is that damage to respiration is not necessarily either/or in regards to the origin of cancer damage
- Peter’s view, thinking on first principles, is that the Warburg effect doesn’t make sense
  - If the primary cause of cancer is damage to the mitochondria, that is an insult to the cell that inhibits its ability to acquire energy
  - It’s great that the cell can produce energy outside of the mitochondria
  - An insult to the mitochondria doesn’t explain why the cell would then take up more nutrients; instead it explains why the cell would metabolize nutrients in a different way
    - Both normal cells and abnormal cells are exposed to the same level of nutrients and the same hormones
      - Why is only one of these going down the cancerous pathway?
    - Hormones and nutrients are simply the fuel allowing this to happen, not the spark
    - He doesn’t agree that the initial insult is insult to the mitochondria
  - Peter thinks the [oncogenes](https://en.wikipedia.org/wiki/Oncogene) are the driver initiating cancer

> “I think the metabolism allows the cancer to be even more adaptable” – Peter Attia

- Metabolism is important in for considering cancer treatment and prevention
  - From the perspective of a bedside doctor, the question of what can one do to prevent or reduce the probability of cancer is important and may be impacted by the Warburg effect

**Connecting the dots**

- Sam sees 2 components of this story:
  - 1) what’s going on inside the cancer cell; the Warburg effect, fermentation increases and glucose is rapidly metabolized
  - 2) various environmental causes of cancer; 200 years of cancer epidemiology

- As a journalist, Sam may not always understand the science but he can look at one scientific field and another scientific field and connect the dots
- In the late ‘90’s at the same time that [Thompson’s](https://en.wikipedia.org/wiki/Craig_B._Thompson) lab and [Chi Van Dang’s](https://wistar.org/our-scientists/chi-van-dang) lab are returning to Warburg metabolism there are epidemiology papers published that show elevated insulin levels and obesity are correlated with cancer

> “That in a lot of ways was my project for the end of the book; trying to understand, is the obesity story related to the overeating of glucose in the cancer cell” – Sam Apple

- Sam thinks hyperinsulinemia is the piece that puts it all together
  - This can explain obesity
  - It can explain cancer and why cancer was once a rare disease
  - Diseases of civilization have become much more common, these are diabetes and obesity; insulin is the explanation that ties it all together
  - Obviously not all cancers are caused by insulin
    - Insulin’s role may only be indirect
- To make big progress on cancer prevention, there needs to be focus on hyperinsulinemia
- It’s been 50 year since the [war on cancer](https://en.wikipedia.org/wiki/War_on_cancer) begun and little overall progress has been made in terms of prevention

## Identifying primary and secondary causes of cancer for the purpose of cancer prevention [1:27:00]

**Primary causes of cancer**

- Consider what is a primary cause and secondary cause
  - For example, when [ravenous diarrhea](https://en.wikipedia.org/wiki/1854_Broad_Street_cholera_outbreak) was ripping through London in the 1800’s
    - The *primary cause* was cholera; this is the first step in the process
    - The *secondary cause* was lack of sanitation which permitted the cholera bacteria to travel so freely from sewage to drinking water
- Consider cancer through the lens of the 2 most readily identified epidemiologic factors in terms of most people impacted in the developed world:
  - 1) smoking
  - 2) obesity

- Carcinogens that cause mutations are the evidence for the relationship between cigarette smoking and cancer
  - One could argue that the prime cause driving cancer is the mutation in the DNA
    - Or cigarette smoke is the prime cause
    - But by Warburg’s definition the mutation is the prime cause
- Another way to think about it is that the problem with cancer begins with the DNA
  - The [Seyfried](https://www.bc.edu/bc-web/schools/mcas/departments/biology/people/faculty-directory/thomas-seyfried.html) paradigm is that it begins with the mitochondria
    - Review he co-authored in 2010, [Cancer as a metabolic disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2845135/)
- Sam thinks it makes logical sense to see smoking as a prime cause of cancer
- Peter adds obesity as another primary cause
  - But the hazard ratio for obesity isn’t nearly as large as it is with tobacco
  - It’s harder to disentangle obesity from its other multivariate parameters
    - The person who is obese eats a different way, sleeps a different way, exercises a different way, etc.; all these could potentially play a role

**Secondary causes of cancer**

- If obesity is considered a primary cause of cancer, the next step is to identify secondary causes
  - Is it a growth factor associated with obesity?
    - Insulin is one such growth factor
  - It is other changes prominent in obesity, such as inflammation?
- Why is insulin a prime candidate within the obesity paradigm for driving cancer?
- Sam’s argument in the latter part of his book is that the connection between obesity and  cancer is not casual
- Instead, [hyperinsulinemia](https://en.wikipedia.org/wiki/Hyperinsulinemia) is simultaneously driving obesity and cancer cell proliferation
- Some people are ‘metabolically healthy’ and obese; they store more nutrients in subcutaneous fat and not visceral fat
  - They tend to not have insulin resistance
  - Conversely, some thin people have insulin resistance
- Sam agrees that the insulin-cancer connection isn’t as strong as the smoking-cancer connection
- Is insulin a primary cause of cancer or is it a mutation that occurs that allows the cancer cell to take advantage of hyperinsulinemia?
- Consider a  two-by-two matrix where there is chromosomal insult, yes or no; and hyperinsulinemia, yes, no

![](https://peterattiamd.com/wp-content/uploads/2021/12/f6-samapple.png)

**Figure 6. Two-by-two matrix.**

- So which one gets cancer? Is it only the double positive?
- One would think that the double negative does not
- What’s happening on the other corners: chromosomal insult without hyperinsulinemia and no chromosomal insult with hyperinsulinemia?

- These question matter a lot in terms of cancer prevention
  - Consider that both are required, then cancer prevention requires avoiding any sign of metabolic ill health and hyperinsulinemia as well as doing everything imaginable to reduce the burden DNA insult
  - Now layer on aggressive cancer screening
- There are no great answers at this point
- One hypothesis is that chromosomal insult occurs (by chance or for whatever reason) and affects the [PI3K pathway](https://en.wikipedia.org/wiki/PI3K/AKT/mTOR_pathway) thereby allowing the cell to take advantage of hyperinsulinemia
- Another speculative idea is that hyperinsulinemia and excessive glucose metabolism actually drive chromosomal insult through the creation of reactive oxygen species in the mitochondria
  - [Craig Thompson](https://en.wikipedia.org/wiki/Craig_B._Thompson) describes hypermetabolism as a way for the cell to mutagenize
- There’s new research coming about how nutrients play a huge role in epigenetics as well
- It may be that there’s just bad luck and mutation comes along, and then if the insulin is there, the cell takes advantage… if it’s not then the tumor never takes off

## The link between sugar, fructose, and cancer [1:35:30]

- A lot of people die with cancer rather than from cancer
- Maybe the immune system can kill microscopic tumors if not for the insulin
  - If not for the insulin telling cancer cells to stay alive
  - There isn’t a good answer here
- Epidemiology says there is something going on with nutrition; cancer was much more rare prior to the shift to the [Western diet](https://en.wikipedia.org/wiki/Western_pattern_diet)
  - Sam thinks it all points to hyperinsulinemia
  - It’s a growth factor and cancer cells are covered in [insulin receptors](https://en.wikipedia.org/wiki/Insulin_receptor)
- The counterpoint is that bad luck produces a mutation in AKT, then the cell no longer needs insulin and can just get all the glucose at once
  - But as he understands it, even with mutations in the PI3K, AKT, mTOR pathway, they’re still insulin-dependent, just less dependent

**Sugar**

- [Rick Johnson](https://som.ucdenver.edu/Profiles/Faculty/Profile/9426) and [Lew Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) have both spoken about non-insulin requiring nutrients such as fructose
  - Review from 2020 by Johnson *et al.,* [Fructose contributes to the Warburg effect for cancer growth](https://cancerandmetabolism.biomedcentral.com/articles/10.1186/s40170-020-00222-9)
- Sam had decided early in his writing process that sugar was a big part of this story
  - He assumed that sugar was driving fat storage in the liver and insulin resistance

> “I was writing about Warburg who always believed too strongly in his own ideas and couldn’t accept that they may be wrong. Anytime you’re writing a book that has any kind of argument in it, you fall into that trap and have to remember that science changes and not everything’s proven.” – Sam Apple

- Recent work by Cantley’s lab and Richard Johnson’s lab showed that fructose seems to drive certain cancers
  - Particularly colon cancer
    - Published in *Science* in 2020, [High-fructose corn syrup enhances intestinal tumor growth in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6487857/)
  - Fructose turns on the Warburg effect, allows ATP to go down, and allows glucose to flow in
    - Review published in *Cancer and Metabolism* in 2020, [Fructose contributes to the Warburg effect for cancer growth](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7350662/)
  - This occurs independently of the effect of insulin
    - Sam was surprised that these effects could be disassociated from insulin
      - He thought maybe sugar is worse than everyone thinks; could it cause cancer in 2 different ways?

- Peter points out that when fructose is consumed in excess, fructose metabolism leads to insulin resistance, which leads to hyperinsulinemia
- The Colon cancer work by Lew Cantley suggests that it’s an energetic issue, the lowering of ATP in the cell that occurs when fructose is metabolized that can drive hyper-influx of glucose
  - This is not necessarily an insulin-driven process
- Sam found Rick Johnson’s whole discussion of the role of fructose absolutely fascinating
  - Johnson discussed fructose with Peter in this [podcast](https://peterattiamd.com/rickjohnson/) from January 2020
  - His example of the [naked mole-rats](https://en.wikipedia.org/wiki/Naked_mole-rat) was fascinating
    - They live in a low-oxygen environment and run a lot of Warburg metabolism by converting glucose to fructose

## Sam’s reflections on the work that went into *Ravenous* [1:39:45]

- Sam grew up Jewish; he learned about the Holocause and Nazis
  - In his mind they were monsters; he never humanized them
  - In researching this book, he had to look at the personal stories of all the Nazis and not think of them in an abstract, evil way but understand them as human beings
    - Understand how they went down this path; how it happened progressively
    - How someone who might in one context be a nice friend and neighbor, go on to work on documents that lead to the murder of millions
      - It was chilling and eye-opening to think that this wasn’t an anomaly, but this had happened elsewhere and could happen again in various forms
      - It made him more politically attuned to certain extremist politics
- The book was a daunting project; it has 120,000-some words
- He didn’t speak German fluently and didn’t plan to write the book
  - The publisher came to him after his [article](https://www.nytimes.com/2016/05/15/magazine/warburg-effect-an-old-idea-revived-starve-cancer-to-death.html) in the New York Times Magazine and asked him to write it
- Through the process of writing *Ravenous*, he learned a lot about himself as a writer and trust himself more as a historian
- Writing it was a big risk but the end of the project was very rewarding

§

## Selected Links / Related Material

**Sam’s latest book on the cancer-diet connection**: [Ravenous: Otto Warburg, the Nazis, and the Search for the Cancer-Diet Connection by Sam Apple](https://www.amazon.com/Ravenous-Warburg-Search-Cancer-Diet-Connection/dp/1631493159/ref=sr_1_1?crid=2G7R5BAZXFKBB&dchild=1&keywords=ravenous+sam+apple&qid=1634321128&s=books&sr=1-1) (2021) | [

**The article that inspired the book** ***Ravenous:*** [An Old Idea, Revived: Starve Cancer to Death](https://www.nytimes.com/2016/05/15/magazine/warburg-effect-an-old-idea-revived-starve-cancer-to-death.html) | Sam Apple, *The New York Times Magazine* (May 12, 2016) | [

**Gary Taubes discussion of metabolism and nutrition**: [#167 – Gary Taubes: Bad science and challenging the conventional wisdom of obesity](https://peterattiamd.com/garytaubes/) | The Drive Podcast with host Peter Attia ([peterattiamd.com/](https://peterattiamd.com/)) | [3:45]

**Warburgs disagreement with Weinhouse on respiratory impairment in cancer cells**:

- [On the origin of cancer cells](https://pubmed.ncbi.nlm.nih.gov/13298683/) | *Science* (O Warburg 1956) | [1:09:15]
- [On respiratory impairment in cancer cells](https://pubmed.ncbi.nlm.nih.gov/13351638/) | *Science* (S Weinhouse 1956) | [1:09:15]
- [On respiratory impairment in cancer cells](https://pubmed.ncbi.nlm.nih.gov/13351639/) | *Science* (O Warburg 1956) | [1:09:15]
- [On respiratory impairment in cancer cells](https://pubmed.ncbi.nlm.nih.gov/13351640/) | *Science* (D Burk and A L Schade 1956) | [1:09:15]

**Watson and Crick’s publication of the structure of DNA**:

[A Structure for Deoxyribose Nucleic Acid](https://www.exploratorium.edu/origins/coldspring/printit.html) | *Nature* (JD Watson and FHC Crick 1953) |

[Genetical implications of the structure of deoxyribonucleic acid](https://pubmed.ncbi.nlm.nih.gov/13063483/) | *Nature* (JD Watson and FH Crick 1953) |

**Weinberg’s papers summarizing the hallmarks of cancer**:

- [The Hallmarks of Cancer](https://www.cell.com/cell/fulltext/S0092-8674(00)81683-9?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867400816839%3Fshowall%3Dtrue) | *Cell* (D Hanahan and RA Weinberg 2000) | [1:12:15]
- [Hallmarks of Cancer: The Next Generation](https://www.cell.com/cell/pdf/S0092-8674(11)00127-9.pdf) | *Cell* (D Hanahan and RA Weinberg 2011) | [1:12:30]

**Weinberg’s textbook on cancer**: [The Biology of Cancer](https://www.amazon.com/Biology-Cancer-Robert-Weinberg/dp/0815340761/ref=sr_1_2?crid=1S6YP47ONW9F6&dchild=1&keywords=biology+of+cancer+weinberg&qid=1634924310&qsid=142-0109206-4649519&s=books&sprefix=biology+of+cancer+weinberg%2Cstripbooks%2C85&sr=1-2&sres=0815342209%2C0815340761%2C0815340788%2CB017PNXS3U%2C0716750376%2CB011T7Q9YI%2CB012UML40A%2CB0053GT5TS%2C0198833024%2C0198779453%2C1975149114%2C1632428814%2C1107601487%2C1982115858%2C0198717342%2C303075698X&srpt=ABIS_BOOK) 1st Edition by Robert A. Weinberg (2006) | [1:12:30]

**Mukherjee’s book on cancer**: [Emperor of All Maladies: A Biography of Cancer](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439107955/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634924496&sr=1-1) by Siddhartha Mukherjee (2010) | [1:12:30]

**1989 Nobel prize in physiology or medicine**: The Nobel Prize in Physiology or Medicine 1989 was awarded jointly to J. Michael Bishop and Harold E. Varmus “for their discovery of the cellular origin of retroviral oncogenes.” | [NobelPrize.org](https://www.nobelprize.org/prizes/medicine/1989/summary/) (1989) | [1:13:15]

**First paper that brought the Warburg effect to Peter’s attention**: [Understanding the Warburg Effect: The Metabolic Requirements of Cell Proliferation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) | *Science* (MG Vander Heiden, LC Cantley, and CB Thompson 2009) | [1:13:45]

**Lew Cantley’s discussion of cancer metabolism on The Drive podcast**: [#110 – Lew Cantley, Ph.D.: Cancer metabolism, cancer therapies, and the discovery of PI3K](https://peterattiamd.com/lewcantley/) | The Drive Podcast with host Peter Attia ([peterattiamd.com/](https://peterattiamd.com/)) | [1:14:00]

**Craig Thompson’s lecture on cancer, including the moldy bread experiment**: [How do people get cancer](https://youtu.be/WUlE1VHGA40) | Craig B. Thompson explains the moldy bread experiment at 12:00 (Feb 11, 2011) | [1:19:15]

**Review by Seyfried in support of the Warburg effect**: [Cancer as a metabolic disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2845135/) | *Nutrition and Metabolism* (TN Seyfried and LM Shelton 2010) | [1:17:45]

**Recent work by Cantley’s lab suggests fructose drives colon cancer**: [High-fructose corn syrup enhances intestinal tumor growth in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6487857/) | *Science* (M D Goncalves *et al.* 2019) | [1:37:30]

**Johnson’s review of the role of fructose in the Warburg effect**: [Fructose contributes to the Warburg effect for cancer growth](https://cancerandmetabolism.biomedcentral.com/articles/10.1186/s40170-020-00222-9) | *Cancer and Metabolism* (T Nakagawa *et al.* 2020) | [1:36:30]

**Rick Johnson’s discussion of fructose on The Drive podcast**: #[87 – Rick Johnson, M.D.: Fructose—The common link in high blood pressure, insulin resistance, T2D, & obesity?](https://peterattiamd.com/rickjohnson/) | The Drive Podcast with host Peter Attia ([peterattiamd.com/](https://peterattiamd.com/)) | [1:39:15]

§

## People Mentioned

- [Otto Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) (German biochemist for whom the Warburg effect is named) [0:45, 1:15, 3:30, 4:30, 14:15, 17:30, 22:15, 24:30, 29:45, 33:15, 38:45, 41:30, 47:00, 50:45, 59:15, 1:05:30, 1:07:30, 1:15:30, 1:20:45, 1:36:45]
- [Gary Taubes](https://en.wikipedia.org/wiki/Gary_Taubes) (author of many books about metabolism and nutrition) [3:45]
- [Siddhartha Mukherjee](https://en.wikipedia.org/wiki/Siddhartha_Mukherjee) (oncologist and Pulitzer prize-winning author) [9:00, 13:15]
- [George Orwell](https://en.wikipedia.org/wiki/George_Orwell) (famous British writer) [9:45]
- [Atul Gawande](https://en.wikipedia.org/wiki/Atul_Gawande) (surgeon and author) [13:15]
- [Azra Raza](https://en.wikipedia.org/wiki/Azra_Raza) (Professor of Medicine and author) [13:15]
- [Emil Warburg](https://en.wikipedia.org/wiki/Emil_Warburg) (Otto Warburb’s father, prominent physicist) [14:30]
- [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) (famous German physicist, developed the theory of relativity, won the Nobel prize in 1921) [14:45, 17:45, 23:15]
- [Max Planck](https://en.wikipedia.org/wiki/Max_Planck) (famous German physicist, developed quantum theory, won the Nobel prize in 1918) [15:15]
- [Emil Fisher](https://en.wikipedia.org/wiki/Emil_Fischer) (famous German chemist, developed the Fisher projection, a way to draw asymmetric carbon atoms, won the Nobel prize in 1902) [15:15]
- [Fritz Haber](https://en.wikipedia.org/wiki/Fritz_Haber) (German chemist, won the Nobel prize in 1918, developed chemical warfare in WWI) [17:15]
- [Adolf Hitler](https://en.wikipedia.org/wiki/Adolf_Hitler) (Nazi leader who directed the Holocaust) [22:30, 38:45, 41:30, 47:15, 53:00, 55:45, 57:00]
- [Robert Koch](https://en.wikipedia.org/wiki/Robert_Koch) (famous German physician and microbiologist, developed the theory of contagion and Koch’s postulates, to identify the microbial cause of an infectious disease in the late 1800’s, won the Nobel prize in 1905) [26:00, 34:30, 39:30, 41:15]
- [Paul Ehrlich](https://en.wikipedia.org/wiki/Paul_Ehrlich) (famous German physician and scientist, developed the first drug to treat syphilis, coined the term chemotherapy, won the Nobel prize in 1908) [26:00, 34:30]
- [Otto Meyerhof](https://en.wikipedia.org/wiki/Otto_Fritz_Meyerhof) (German physician and biochemist, won the Nobel prize in 1922; studied metabolism in human cells; characterized glycolysis) [29:45, 35:15, 53:30]
- [Louis Pasteur](https://en.wikipedia.org/wiki/Louis_Pasteur) (famous chemist and microbiologist, characterized microbial fermentation, developed vaccination and pasteurization) [34:15, 1:19:15]
- [Rachel Carson](https://en.wikipedia.org/wiki/Rachel_Carson) (author of [Silent Spring](https://www.amazon.com/Silent-Spring-Rachel-Carson/dp/0618249060/ref=sr_1_1?crid=WBIQY5AEV4OH&dchild=1&keywords=silent+spring+rachel+carson&qid=1634836621&qsid=142-0109206-4649519&s=books&sr=1-1&sres=0618249060%2CB01FGOGFP8%2C1598535609%2CB002E8JF6G%2C0190906766%2C1698901224%2C1598537059%2CB000UZQFX6%2C0143104969%2C0823431932%2CB007MGSNQI%2CB004TC14F0%2C0063088207%2C0448479591%2C1626728194%2C0897339339&srpt=ABIS_BOOK)) [45:30]
- [Viktor Brack](https://en.wikipedia.org/wiki/Viktor_Brack) (Nazi leader Warburg met with in 1941) [54:15]
- [Heinrich Himmler](https://en.wikipedia.org/wiki/Heinrich_Himmler) (Nazi leader) [55:30]
- [Joseph Goebbels](https://en.wikipedia.org/wiki/Joseph_Goebbels) (Nazi leader) [55:30]
- [Sidney Weinhouse](https://www.nasonline.org/publications/biographical-memoirs/memoir-pdfs/weinhouse-sidney.pdf) (biochemist who studies metabolism in cancer post WWII) [1:07:30, 1:09:30, 1:16:45]
- [Robert Weinberg](https://en.wikipedia.org/wiki/Robert_Weinberg_(biologist)) (co-authored paper on the 6 fundamental traits of cancer) [1:12:15]
- [Harold Varmus](https://en.wikipedia.org/wiki/Harold_E._Varmus) (co-winner of the 1989 Nobel prize for discovering oncogenes) [1:13:15]
- [Michael Bishop](https://en.wikipedia.org/wiki/J._Michael_Bishop) (co-winner of the 1989 Nobel prize for discovering oncogenes) [1:13:15]
- [Matthew Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) (biochemist and cancer biologist) [1:14:00, 1:15:30, 1:18:45]
- [Lew Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) (biochemist and cancer biologist) [1:14:00, 1:21:00, 1:36:30, 1:38:30]
- [Craig Thompson](https://en.wikipedia.org/wiki/Craig_B._Thompson) ([cancer biologist](https://www.mskcc.org/research/ski/labs/craig-thompson/overview), oncologist, and president CEO of Memorial Sloan Kettering) [1:14:00, 1:18:45, 1:21:00, 1:25:15, 1:34:45]
- [Chi Van Dang](https://wistar.org/our-scientists/chi-van-dang) (cancer biologist) [1:14:45, 1:25:15]
- [Thomas Seyfried](https://www.bc.edu/bc-web/schools/mcas/departments/biology/people/faculty-directory/thomas-seyfried.html) (research scientist authored [*Cancer as a Metabolic Disease*](https://www.amazon.com/Cancer-Metabolic-Disease-Management-Prevention/dp/0470584920/ref=sr_1_3?dchild=1&keywords=Cancer+as+a+Metabolic+Disease%3A+On+the+Origin%2C+Management%2C+and+Prevention+of+Cancer&qid=1635164287&s=books&sr=1-3)) [1:17:45, 1:21:00, 1:29:00]
- [Richard (Rick) Johnson](https://som.ucdenver.edu/Profiles/Faculty/Profile/9426) (physician who studies the role of fructose in disease)  [1:36:30, 1:39:15]

§

![](https://peterattiamd.com/wp-content/uploads/2021/12/bio-image.jpeg)

##### Sam Apple

Sam teaches in both the science writing MA and MA in writing programs at Johns Hopkins. Prior to coming to Johns Hopkins, Sam taught creative writing and journalism at the University of Pennsylvania for 10 years. He holds a BA in English and creative writing from the University of Michigan and a master in fine arts in creative non-fiction from Columbia University.

Apple is the author of *Ravenous*, *American Parent*, and *Schlepping Through the Alps*. He has published short stories, personal essays, satires, and journalistic features on a wide range of topics. In recent years, he has primarily written about science and health. His work has appeared in *The New York Times Magazine*, *The New Yorker, The Atlantic, Wired, The Los Angeles Times, The Financial Times Magazine, ESPN The Magazine, The MIT Technology Review,* and *McSweeney’s*, among many other publications. *Schlepping Through the Alps* was a finalist for the PEN America Award for a first work of nonfiction. [[Amazon.com](https://www.amazon.com/Sam-Apple/e/B001HMPI0M/ref=aufs_dp_fta_dsk)]