# #34 – Sam Harris, Ph.D.: The transformative power of mindfulness

**Source:** [https://peterattiamd.com/samharris/](https://peterattiamd.com/samharris/)

---

##### Check out more content with Sam Harris:

- *(December 20, 2018)* [Sam Harris, Ph.D.: The transformative power of mindfulness](/samharris/)
- *(March 24, 2020)* [Sam Harris, Ph.D.: COVID-19—Comprehending the crisis and managing our emotions](/samharris2/)

In this episode, Sam Harris, neuroscientist, author, and host of the Waking Up Podcast, walks us through the profound, yet practical, ways that meditation can transform our lives. Additionally, he helps to define the types of meditation and clarifies potential misconceptions with terms like happiness, pain, and suffering.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/samharris/the_Drive_public.png)

Play

#34 - Sam Harris, Ph.D.: The transformative power of mindfulness

#34 - Sam Harris, Ph.D.: The transformative power of mindfulness

1x15s30s

0:002:43:32

## We discuss:

- The transformative moment that led to Peter reaching out to Sam [3:45];
- Comparing the two broad types of meditation, and Peter’s favorite meditation apps [7:45];
- The pleasure of a concentrated mind, meditating with pain, and the difference between pain and suffering [13:15];
- What it means to be happy, and how to break out of our default state [23:15];
- The disease of distraction, why humans suffer, the limitation of happiness, and letting go of anger with mindfulness [31:00];
- The challenge of learning mindfulness, the benefit of silent retreats, and Sam’s first experience in solitude as a teenager [54:15];
- Sam’s life-altering experience with MDMA [1:03:00];
- Mettā meditation a.k.a. loving-kindness, and the concept of ‘moral luck’ [1:14:00];
- Overcoming grief and dread with meditation [1:34:45];
- The wrong way to practice mindfulness, and the difference between Vipassana and Dzogchen [1:44:45];
- Sam’s commitment to never lie, honesty in politics, and Sam’s viewpoint on the Trump phenomenon [2:06:00];
- Teaching kids to be more mindful [2:18:30];
- Sam’s current book projects, the consequences of a politically correct environment, and the potential of neuroscience to cure psychopathy [2:25:30];
- How you can follow Sam’s work [2:39:00]; and
- More.

§

## Show Notes

## The transformative moment that led to Peter reaching out to Sam [3:45]

- Peter had a profound experience at a trauma recovery center called [Bridge to Recovery](https://www.thebridgetorecovery.com/)
- Very little meditation experience prior, and mostly concentration based
- On day 10 at Bridge to Recovery, he had the first moment in his life he felt present and not worrying about the future or dwelling in the past
- Wondered if this was a glimpse of how life could be with meditation
- Called up Sam and Sam gave Peter access to his beta version of his meditation app
- “And in many ways, I view that as one of the most important transitions of my life. I think of life as a handful of direction changes that you look back at the past and say, ‘Wow, that was sort of a meaningful insight that came to me.’”

Hear more about Peter’s experience at Bridge to Recovery in the [previous episode of The Drive with Paul Conti](https://peterattiamd.com/paulconti/)

## Comparing the two broad types of meditation, and Peter’s favorite meditation apps [7:45]

“Thought really is the obstacle one is overcoming when one is learning to meditate”

2 broad types of meditation

- Mantra based/concentration based
  - There is an object of focus and you’re attention is on that object to exclusion of everything else
  - Goal is to get to the point where no thoughts arise
  - This can produce extraordinarily positive states of mind such as bliss and rapture
  - You can actually use *specific states of mind* as your object of focus
  - Common example being ‘loving-kindness’, which is called [Mettā meditation](https://en.wikipedia.org/wiki/Mett%C4%81#Mett%C4%81_meditation) in the Buddhist tradition
  - “You can cultivate specific attitudes which, if you can focus on them to the exclusion of anything else, you’re inhabiting that state to a degree that most people would find unrecognizable.”
- Mindfulness meditation

- Mindfulness meditation is named after “the target state that one is trying to cultivate”
- [Vipassanā](https://en.wikipedia.org/wiki/Vipassan%C4%81) (insight meditation) is the origin of mindfulness practice
- You’re not trying to selectively notice one thing or another, *you are trying to break the spell of being distracted by thought*
- Attention can be much more choiceless than mantra based meditation
- “You’re noticing things all the time but you’re not noticing them clearly because you’re thinking every moment of the day”
- Mindfulness begins for most people as a training on one object like the breath, but very quickly it becomes something that you apply to the full range of your experience
- And apart from all the benefits of actually practicing the mindfulness meditation, this type of meditation is clearly coincident with any experience you can have in that there’s nothing that is excluded in principle from the meditation (you can be working out or watching a movie)
- “There’s no thing that in principle does not admit of mindfulness”

Meditation apps Peter personally recommends

- [Waking Up](https://wakingup.com/) – created by Sam Harris (Peter’s favorite)
- [10% Happier](https://www.10percenthappier.com/) – created by [Dan Harris](https://twitter.com/danbharris?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (no relation to Sam)

## The pleasure of a concentrated mind, meditating with pain, and the difference between pain and suffering [13:15]

Boredom = a simple lack of attention

- We are convinced that we are bored because we haven’t found something compelling enough in our experience to capture our attention
- But what you discover when you learn to meditate is that, what pleases us most in those moments when we are fully captured by experience, is the state of complete attention to the present
- So anything that you can pay attention to, to the exclusion of anything else, can suddenly disclose what it’s like to have a very concentrated mind.
- *Concentration is intrinsically pleasurable*, and it becomes impossible to be anxious or depressed or angry while in that state

**Important note**: this pleasurable feeling, while amazing, it is an *impermanent* state, and it can mislead you to believe that meditation is all about these experiences rather than something more fundamental

*Here’s a paper on this very topic*: [A Wandering Mind is an Unhappy Mind](https://www.danielgilbert.com/KILLINGSWORTH%20&%20GILBERT%20(2010).pdf)

Why should we seek to be present?

- “It doesn’t matter if you can live to a hundred. . .if you’re too miserable to appreciate it or if you’re constantly in some sort of tormented state, you might as well be dead,” says Peter
- We also have inaccurate associations with terms like happiness, and we haven’t distinguished terms that are different like pain and suffering

Meditation and the difference between pain and suffering

- Meditation will not remove physical pain
- You can actually experience surprising degrees of pain while meditating, but **pain is not synonymous with injury**
- There is a difference between pain and suffering
- With pain, you’re actually mostly worried about the future, how long this is gonna go on
- What most people call pain, it is actually *suffering*
- But you can pay attention to what is arising, the feeling of resistance, the fear about what’s gonna happen in the next moment, and keep dropping back into a position of merely witnessing all of these things arise and then pass away
- The goal should be to find a place of equanimity with pain
- In meditation, where an excruciating sensation becomes so intense that you actually don’t know whether or not you’re experiencing agony or ecstasy. . .it’s just sheer intensity

## What it means to be happy, and how to break out of our default state [23:15]

- Misconception is that happiness is being joyful all the time
- Sam says that we should instead seek well-being
- A component of well-being is “a resiliency and a way of embracing that which brings out that the wisest and most compassionate and most expansive parts of yourself”

Overcoming our default state

- Our “default state” is being lost in constant thought, and identifying with those thoughts
- One thing you discover when you learn to meditate is that negative emotion in particular, have a very short half-life.
- It’s actually impossible to maintain a negative emotion if you are no longer lost in thought about all the reasons why you should be angry or sad
- “To think that by simply being observant of that emotional state, I could have some control over it, which has always felt like the opposite, right? It’s always felt like that, the emotional state has control over me,” says Peter
- Sam concurs, “it has complete control over you as long as you’re identified with the next angry thought that’s arising in consciousness. If you have no perspective on the fact that you are thinking, well then you simply become that thought for the period that it’s captivating, and you are pushed in whatever direction it’s aimed”
- Sam compares being lost in thought to dreaming in bed, and there is a similar “waking up” sensation in both cases
- Peter frequently comes back to a video of [David Foster Wallace giving a commencement speech](https://www.youtube.com/watch?v=8CrOL-ydFMI) where he points out that our default state is part of what makes living mindfully such a challenge

In a previous episode of The Drive, Peter plays a [segment of a famous interview of David Foster Wallace](https://overcast.fm/+NmiSxdST8/1:25:30) (and here is a link to the [full episode with Paul Conti](https://peterattiamd.com/paulconti/))

## The disease of distraction, why humans suffer, the limitation of happiness, and letting go of anger with mindfulness [31:00]

“The inability to recognize how distracted we are seems to be one of the greatest drivers of misery” —Peter Attia

The “disease” of too much thinking and distraction

- Started at the [codification of language](https://en.wikipedia.org/wiki/Origin_of_language)
- Curse and a blessing ⇒ All things recognizably human due to abstract/complex thought
- Dogs and toddlers are similar in the sense that their reactions and emotions are almost exclusively tied to the present environment
- Somewhere around the preteen age we start to suffer from this “disease”
- Peter’s favorite quotes on this topic:
  - In the first century, [Seneca](https://en.wikipedia.org/wiki/Seneca_the_Younger) said, “We suffer more in imagination than in reality.”
  - In the 16th century, [Shakespeare](https://en.wikipedia.org/wiki/William_Shakespeare) wrote in [Hamlet](https://en.wikipedia.org/wiki/Hamlet), “For there is nothing either good or bad but thinking makes it so.”
  - In the 17th Century, [Pascal](https://en.wikipedia.org/wiki/Blaise_Pascal) said, “Distraction is the only thing that consoles us from miseries yet it is itself the greatest of our miseries.”

Why do humans suffer so much?

- Evolution doesn’t care about your well-being, says Sam
- Virtually everything we want is, at some level, a matter of breaking the connection to many of our evolved tendencies
- Speech becomes something where you’re narrating your own experience, and from a survival advantage, there’s no reason to ever turn it off

The limitation of conventional happiness

- Some people are very lucky and they have an intrinsic level of happiness that is just off the charts where they’re basically happy all the time
- You can be conventionally very happy and still be talking to yourself all the time and not notice it
- **But there’s significant limitation to conventional happiness**
- “This more refined way of noticing what it’s like to be you. . .what we’re calling meditation”

The advantages of practicing mindfulness, or having meta awareness

- You can still enjoy life without meditation, or “metacognition”
- Sam says, “the difference comes in how you respond to problems that arise”
- Peter agrees but says he thinks it’s BOTH helpful for dealing with unpleasant things as well as enjoying the pleasant things
- Example of being stuck in traffic, it can be a time to work on your mindfulness, “ So, in many ways, if nothing else it’s simply a hack to allow me to be less miserable”
- On the flip side, you can truly enjoy certain moments on a different level
- Example of being with his young, rowdy kids, while they might be acting obnoxious and not listening to you, you know you’ll miss these moments, “it’s basically a tool to make me a little bit more aware of where I am in a given moment and whether that produces happiness or not.”

Our default is “fast forward,” a.k.a. on to the next

- When not being mindful, we don’t fully enjoy even the moments when we are getting what we want
- “Even when you’re getting what you want, even when you’re in the very act of gratifying a desire, you’re still subtly inclining toward the next moment. You’re not actually landing on each moment of experience with full attention. And, paradoxically, you can discover that many of the things you think you want, you don’t want all that much if you pay attention to what it’s actually like to gratify those desires.”
- “And this is not to say that there’s nothing that’s truly pleasurable. . . but being able to really connect with the present moment delivers its own intrinsic pleasure”
- “Your sense of what matters can definitely change the moment you begin to pay closer attention to what experience is actually like.”

Dealing with anger in spots where you know it’s coming:

- Sam says, “Getting angry is not the measure of having lost. Obviously, you can aspire to a time where you will never get angry again or you never get angry in certain circumstances again, but the real practice is to notice, as early as possible, what’s happening and to let go of it.”
- It’s not that anger is never warranted, the energy of anger can be useful in some cases
- The key is to let go of the anger as soon as possible

**But if you can’t be mindful, you actually have no choice but to be angry**

Using framing as a hack

- The tool referred to as ‘framing’ doesn’t even entail mindfulness at all
- Yet it can be a great tool to change your perspective and avoid negative emotions
- Example, any time you’re dealing with a customer service agent just come to in knowing that their job is constantly dealing with upset people
- “You could get the benefit of that new framing without ever having heard of mindfulness”
- That said, it won’t stop anger, for example, without the awareness you need to recognize it
- **So, it is the combination of framing and mindfulness that is powerful**

## The challenge of learning mindfulness, the benefit of silent retreats, and Sam’s first experience in solitude as a teenager [54:15]

- Peter considers consistently practicing meditation and living mindfully to be more difficult than perhaps the two most difficult experiences in his life which are:
  - Back injury resulting in multiple surgeries and months of no movement at all ([he describes this experience here](https://youtu.be/LB4wRxRROfA?t=870))
  - Learning to swim as an adult
- Why is meditation it harder? Peter speculates that 1) his personality may just lend him to being a tough case and 2) that the other two experiences forced him into [total immersion learning](https://tim.blog/2008/08/13/total-immersion-how-i-learned-to-swim-effortlessly-in-10-days-and-you-can-too/) whereas it’s hard to practice meditation that way mixed into your everyday life
- For this reason, Sam recommends immersion through silent meditation retreats
- Sam says the retreat must be a minimum of 7-10 days because the first few days will be difficult and you must get through that resistance to get a real benefit

Sam’s first experience in solitude

- Age 16, 23 days of camping and hiking with [Outward Bound](https://outwardbound.org)
- Last 3 days, he was put in isolation with nothing but water, a sleeping bag, and a journal
- He found the experience intolerable, “It was just a continuous advertisement for everything that I missed. It was like a meditation on loneliness and boredom and grief, ultimately.”
- He was astonished to discover that many of the others had profoundly happy experiences
- “It was the first moment in my life that I realized that I was on the wrong side of some understanding about the nature of my own mind and then the possibility of finding a durable source of happiness in this life.”

Sam describes this experience in [his book](https://www.amazon.com/Waking-Up-Spirituality-Without-Religion/dp/1451636024) as well as on an [episode of the Tim Ferriss Show](https://tim.blog/2018/10/29/sam-harris-waking-up/)

## Sam’s life-altering experience with MDMA [1:03:00]

Sam had a life-changing moment when he took [MDMA](https://en.wikipedia.org/wiki/MDMA) (ecstasy) a few years after his unpleasant experience in solitude with Outward Bound

- Sam had previous experience with other psychedelics (psilocybin) and drugs prior to this event, but those experiences, while pleasurable (mostly), the effects were transient
- In other words, he experienced an *altered state rather than an altered trait ⇒* See book [Altered Traits](https://www.amazon.com/Altered-Traits-Science-Reveals-Meditation/dp/0399184384) (and here’s an awesome [Waking Up Podcast episode](https://samharris.org/podcasts/111-science-meditation/) with the authors of Altered Traits)
- But with MDMA, “I had this epiphany that this is what consciousness was like when it was no longer encumbered by my self-concern, by my egocentricity”

Describing his experience while on MDMA

- Felt like “I was losing concern about myself”
- Overwhelming, non-sexual, love for his best friend who was with him at the time
- Recognized that in typical interaction with his friend, his default state would be his attention would normally be wrapped up in a selfish concern about what his friend thinks about him
- His own feeling of well-being was not negatively impacted by the success or well-being of others, in fact he wished happiness upon his friend to the same degree as his own well-being ([sympathetic joy](https://en.wikipedia.org/wiki/Mudita))
- Realized that if a stranger had walked into the room he would have felt the same way about him
- “I wished nothing but happiness on every conscious system. Effortlessly.”

\*Not without caution\*

- The neurobiology is not fully understood
- MDMA is unregulated so you’re always running a risk that the drug is cut with other substances, and there’s toxicity that can be amplified as a result of that
- Anything over a frequency of about three months, you start to run a risk of serotonergic toxicities down the line
- Also, the appropriate dosage is not entirely clear

Multidisciplinary Association for Psychedelic Studies (MAPS) is doing research into the efficacy and risks of MDMA for PTSD: [MDMA-Assisted Psychotherapy](https://maps.org/research/mdma)

## Mettā meditation a.k.a. loving-kindness, and the concept of ‘moral luck’ [1:14:00]

Mettā meditation, also known as loving-kindness, is a goal-oriented practice of trying to feel this feeling of love and kindness as intensely and as durably as you can feel it

- In practice, you’re not only trying to acquire a state change, but you’re also trying to acquire a trait change in that your default attitude toward other human beings would be well wishing and good vibes
- The same faculty of mind that could become one pointedly focused on a mantra or a sight, like a candle flame, can become one pointedly immersed in the feeling of love for all humanity

Basic principles of metta practice

- Initiated by thinking thoughts about other people
- Start with someone you love, but it’s important that this is not contaminated with your notion of romantic love
- It should be an uncomplicated experience of wishing this person well, wishing them to be free of suffering, wishing them happiness
- So, you’re thinking, “May you be happy. May you be free from suffering,” or something of the sort, and you’re saying it over and over again, but then connecting with the actual energetics of the wish, that you really do wish that this person who you love be free from suffering
- Then you can move to a neutral person
- And eventually even move to an enemy

The implications of this idea of loving-kindness

- A loving-kindness practice is based on a fundamental frame change for everything you can encounter in human affairs
- You can get to the point of understanding that there is no evil person who invented himself
- He didn’t pick his parents, his didn’t pick his genes, he’s not the author of himself, and yet he’s going to become this evil person
- You can recognize that there is this capacity for love and well-wishing that really extends without limit to every conscious system

“That’s not to say you wouldn’t want to put [an evil person] in jail, because there is no cure for this problem. . .but you don’t actually have to hate them. Feeling compassion for these people isn’t incompatible with taking the steps we need to take to keep society orderly and safe.”

The concept of ‘moral luck’

- Philosopher [Thomas Nagel](https://en.wikipedia.org/wiki/Thomas_Nagel) pointed out that we rarely recognize how morally significant differences in luck are, and just how lucky you need to be to live a good moral life
- Peter spent time [visiting Kern prison with Corey McCarthy](https://peterattiamd.com/coreymccarthy/) and had a profound experience which elucidated this idea of luck’s major role in our life path
- Texting while driving, something the majority of us are guilty of, continues to ruin the lives of the person being killed as well as the offender
- Peter’s friend was killed while cycling by a person texting and driving
- At the end of the day, everyone loses and there is no upside to refusing empathy even for the person texting and driving

## Overcoming grief and dread with meditation [1:34:45]

An example of intense dreading of the future

- Peter has a patient who lost a pet, and is not only overcome with grief, but he is overwhelmed with dread about the future death of his other two dogs (who are years away from death)
- This dreading of the future is causing his cortisol number to skyrocket, “you’d think he had a cortisol-secreting tumor actually”
- Peter asks Sam for advice on how to get meditation to resonate and impart change in his perspective

Framing can help here

- So, you can say, “well, there were many experiences he had with this dog alive where the dog wasn’t physically present”
- The only way to make it intolerable to be in a room without everyone you love is to meditate on how intolerable it is that they’re not in the room with you right now
- This is why meditation is such an amazing skill because once you actually know how to meditate, it’s possible to be alone in a room for weeks and months and even years
- Solitary confinement is used as a punishment in prison because without the lessons learned through meditation, it can be so utterly intolerable to be left alone with your thoughts that you’d rather be surrounded by murderers and rapists who you might have to fight

There’s an evolutionary rationale for this

- We are clearly evolved to be social primates and a circumstance where you find yourself alone more or less forever is not an optimum in evolutionary terms
- It’s just simply a fact of the human mind that it’s possible to discover a form of well-being that not only survives contact with solitude, but is just totally undiminished by solitude

Sam says:

> “If you can discover that even for moments at a time, you can then enjoy the company of everyone you love without this feeling that your well-being is at its core predicated on being able to have them at any moment you want, or that is predicated on the totally forlorn hope that this circumstance is going to endure forever, that no one will die, that no one will leave you. We know that’s not in the cards and we need to find whatever form of well-being as possible given the fact that things are continually changing.”

## The wrong way to practice mindfulness, and the difference between Vipassana and Dzogchen [1:44:45]

Sam explaining the wrong approach to mindfulness practice

- Mindfulness should not be a goal-seeking practice
- It’s possible to be practicing mindfulness in a way that is dualistic where the goal is to recognize the selflessness of consciousness and be relieved of this sense of ego at the center of it
- The ego being the sense that there’s a meditator, a thinker of thoughts, or an experiencer of experience
- And the idea that realizing that this ego is an illusion is the ultimate goal of some incredibly laborious spiritual path that just has to be traversed by increments over years, *is the wrong idea*
- This is an error, a mistake, and it is just not true
- It’s already true of consciousness that the ego is an illusion and that can be realized directly
- Taking this goal-seeking approach can lead you to being trapped in a kind of crucible of unnecessary seeking and suffering because you have an erroneous understanding of what the path actually is

Vipassana

- This is the name of the practice in [Theravada Buddhism](https://en.wikipedia.org/wiki/Theravada), the oldest tradition of Buddhism
- You’re having insight into what are thought of as the three fundamental characteristics of all phenomenon: unsatisfactoriness, impermanence, and selflessness
- **Unsatisfactoriness**
  - This is often mistaken for meaning *suffering*, and that the Buddha taught all experience contains some intrinsic suffering
  - Instead, the message is that life is a circumstance where everything is constantly changing, so there’s no fully satisfactory basis for one’s happiness
- **Impermanence**
  - By the same token, our pleasures, however hard won, are fleeting, they’re vanishing even in the act of acquiring them
  - There’s no place to land that is secure and that’s largely by virtue of the impermanence of sensory experience
- **Selflessness**
  - The recognition that self is an illusion
  - The selflessness component is separable from those two other characteristics
- In summary, vipassana is a practice whereby you have insight into those three characteristics and **mindfulness is the tool you use to have those insights**

Mindfulness as a tool

- Training in mindfulness is a training in a kind of awareness of experience which is non-judgmental, non-reactive
- You’re not seeking to maximize pleasure, you’re not trying to make pains go away, you’re just becoming interested in a very open and focused way on the character of every experience
- If you’re feeling restless, rather than try not to feel restless, you’re becoming interested in, and increasingly aware of, the actual characteristics moment to moment of restlessness
- A pattern of energy you can suddenly recognize arising, totally on its own, and changing based on its own dynamics and you are merely the witness of that change in state
- Mindfulness is continually dropping back into merely witnessing, you’re not judging or thinking about the experience, you’re just “experiencing experience” more and more closely
- Simply feeling the raw data of experience can be pleasant

Dzogchen

- Dzogchen is a Tibetan practice tradition which is explicitly non-dualistic, meaning it goes after the selflessness of the mind very directly
- You actually can’t even start practicing Dzogchen until you’ve had the particular insight of noticing the three characteristics of insight: impermanence, selflessness, and unsatisfactoriness
- Teachers of Dzogchen seek to help you fundamentally cut through the sense that there’s even one who can be mindful
- It’s possible to have fleeting moments of intense “peak” feelings of oneness and awareness without Dzogchen (like Sam experienced in silent retreats of vipassana), but with Dzogchen you discover that all the peak experiences are no more empty of self than ordinary waking consciousness is

Vipassana vs. Dzogchen

- With vipassana, there’s an idea that you’re rubbing two sticks together, but the moment you stop, they’re cooling off and you’ve made no progress
- With Dzogchen, it’s the opposite, the framing you need for Dzogchen is that there’s something already true of consciousness, you’re not trying to produce this thing, you’re not trying to get rid of the ego, you’re not trying to change anything about what is, you’re trying to recognize a feature of consciousness that is already the case
- Dzogchen is the path of discovering that there’s no center, and then taking that insight as your only object of mindfulness, so that what you’re mindful of thereafter is that there’s no center to consciousness, so whatever is appearing—sights, sounds, sensations—you are continually dropping the implied center

**State effects vs. trait effects**

State effects

- Like the effects of a drug, it’s possible to have extremely pleasant states arise in the midst of meditation
- But none of those experiences really can be the point because they’re transitory, when they’re gone, they really are gone
- In other words, like drugs, what’s the point if it’s just a matter of getting high and you’re no better of a person in the world as a result of having had that experience
- Sam cautions that a potential downside of getting very good at so-called *concentration practices* is that they don’t have the power to give you a perspective that is a fundamental antidote to egocentricity and selfishness
- They really can be fundamentally no more interesting from a larger examined life perspective than a drug experience

Trait effects

- Trait effects, effects that last beyond the session of meditation, should be the reason one ought to consider meditation
- “It really is about having a fundamentally different relationship to experience, in general”
- In Sam’s view, mindfulness meditation is more likely to have trait effects than mantra/concentration based practices

## Sam’s commitment to never lie, honesty in politics, and Sam’s viewpoint on the Trump phenomenon [2:06:00]

“What we’re looking for to lead truly better lives across the board is something that is anchored to an ethics. . . where our spiritual or contemplative tools are actually making us better people across the board.”

Sam’s commitment to never lying

- “Not lying is a major variable for me ethically. . .having formed a commitment to being honest in basically every situation”
- By being committed to not lying, you’re closing the door to all kinds of complexity and risk both interpersonally and reputationally
- The net gain you get in a personal relationship knowing that your partner is being truthful far outweighs the possible awkwardness of an uncomfortable truth
- Think about who you would rather surround yourself with. . .
  - If you know someone is radically honest, their praise means that much more
  - If you ask for feedback on a project, you’d rather have someone who will be honest with you rather than try to protect your feelings which could lead to future failure or embarrassment
- For more on this topic, check out Sam’s book called [Lying](https://www.amazon.com/Lying-Sam-Harris/dp/1940051002)

Sam’s viewpoint on the Trump phenomenon

- Sam says, “Virtually everything that’s wrong with our politics is the result of the mismatch between interpersonal ethics of this sort, and what works, and what wouldn’t work in the public sphere.”
- “I think dishonesty should exact a massive reputational cost in politics. But now we’re in this strange mirror universe where the most dishonest person anyone has ever witnessed is the president of the country, and suffering absolutely no reputational cost among those who love him.”
- “It’s not that the people who love Trump are reliably duped by him, it’s that they’re not holding him to a standard of honesty at all.”

## Teaching kids to be more mindful [2:18:30]

In what way does Sam think about teaching his kids to be more mindful?

First, kids can be taught meditation

- Sam’s wife, [Annaka Harris](https://twitter.com/AnnakaHarris?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor), actually teaches meditation to kids starting at age 5
- They get real benefit, but perhaps not quite the same as adults

Second, he often points out to them the mismatch between their expectation of an upcoming supposedly negative event versus the actual experience of the event

- Often times it turned out not to be so awful or in some cases even a net positive (e.g., the experience of overcoming a fear)
- All of the time spent suffering in anticipation of this negative thing was wasted
- “Expectation is so often not only a bad guide, it’s no guide at all to what is going to happen. And yet, people suffer in advance over this thing that they’re expecting to be negative. Even if it’s going to be negative, you can decide to suffer once or twice.”

Overall,

- Mindfulness for a kid can be, at the first pass, just more awareness over what they’re feeling and thinking
- As they get older, they can build upon this and ultimately have a, more or less, grown-up relationship to observing what’s going on in their minds

## Sam’s current book projects, the consequences of a politically correct environment, and the potential of neuroscience to cure psychopathy [2:25:30]

Working on 2 books currently

1. Untitled book – A digest of insights from his podcast guests (comparable to [Tools of Titans](https://www.amazon.com/Tools-Titans-Billionaires-World-Class-Performers/dp/1328683788) by Tim Ferriss)
2. Making Sense (working title)
   - “A manifesto about intellectual honesty and. . .about all manner of topics, whether it’s race or gender or the opposition between science and religion”
   - “We’re paying a price for not being able to talk about the most consequential and taboo and dangerous and divisive things in a way that. . .allows for breakthroughs and changes of opinion.”
   - Watch as Sam “pays the price” with Ben Affleck during his [appearance on Real Time with Bill Maher](https://www.youtube.com/watch?v=vln9D81eO60)

Consequences of our current “politically correct” environment

- Lives and careers being ruined over misstatements
- Recent example, [Megyn Kelly losing her job](https://www.rollingstone.com/tv/tv-news/megyn-kelly-nbc-fired-blackface-747389/) over an obvious misstatement despite “as full an [apology](https://www.youtube.com/watch?v=OXCzo4wL_0s) that a person can muster”

Is there such a thing as an “ethical event horizon”?

- Defined as, “something so bad that you could do or say that no apology would be sufficient to pull your reputation back out of that singularity. An unrecoverable moral error.”
- Sam says no, there should not be such a thing, as long as there is an appropriate, acceptable, apology

What is an appropriate, acceptable apology?

- You have to stand in relationship to that thing you did in the same place where the other people who are horrified by what you did stand, and they have to be able to see how it is that you have come to stand where they are now in order to accept your apology
- So if that transformation isn’t believable for some reason, if there’s no path by which you could have had this epiphany that contextualizes your prior bad behavior. . .well then it will seem insincere or opportunistic
- “The path out of that darkness has to be intelligible to people”

Could breakthroughs in neuroscience cure cases of psychopathy?

- At some point, psychopathy could be viewed as a neurological condition whereby an individual could be cured of their condition
- Psychopathy would no longer be viewed as a moral problem, the person would simply need a “new module” to fix their condition
- Sam has hope that this could be a reality in *certain, specific* cases
- Classic example is the case of Charles Whitman who in 1964 killed 14 people at the University of Texas and it turned out he had a glioblastoma pushing on his amygdala
- Charles Whitman seems to be profoundly unlucky, and “on some level, a complete understanding of evil would reduce it to that same species of unluck.”

## How you can follow Sam’s work [2:39:00]

[Samharris.org](https://samharris.org/)

- [Waking Up Podcast](https://samharris.org/podcast/)
- [Blog](https://samharris.org/blog/)
- [Books](https://samharris.org/books/)

[Wakingup.org](https://wakingup.com/) to download the Waking Up meditation app

Social media

- [Twitter](https://twitter.com/SamHarrisOrg?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)
- [YouTube](https://www.youtube.com/channel/UCNAxrHudMfdzNi6NxruKPLw?sub_confirmation=1)
- [Facebook](https://www.facebook.com/Samharrisorg/)
- [Instagram](https://www.instagram.com/samharrisorg/?hl=en)

§

§

## Selected Links / Related Material

**Sam’s books**: [1:00]

- [The End of Faith](https://www.amazon.com/End-Faith-Religion-Terror-Future/dp/0393035158/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
- [The Moral Landscape](https://www.amazon.com/Moral-Landscape-Science-Determine-Values/dp/143917122X)
- [Lying](https://www.amazon.com/Lying-Sam-Harris/dp/1940051002)
- [Free Will](https://www.amazon.com/Free-Will-Deckle-Edge-Harris/dp/1451683405)
- [Waking Up](https://www.amazon.com/Waking-Up-Spirituality-Without-Religion/dp/1451636024) [1:00, 1:03:45, 1:39:30]

**Sam’s podcast**: [Waking Up Podcast](https://samharris.org/podcast/) | ([samharris.org](https://samharris.org/)) [1:15]

**Sam’s meditation app**: [Waking Up](https://wakingup.com/) | ([wakingup.com](https://wakingup.com/)) [1:15, 6:45, 11:45]

**Rehab facility Peter entered for help with past trauma**: [Bridge to Recovery](https://www.thebridgetorecovery.com/) | ([thebridgetorecovery.com](https://www.thebridgetorecovery.com/)) [4:45]

**Episode of The Drive where Peter discusses his experience at a rehab facility**: [Paul Conti, M.D.: trauma, suicide, community, and self-compassion (EP.15](https://peterattiamd.com/paulconti/)) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [5:00]

**Meditation app by Dan Harris**: [10% Happier](https://www.10percenthappier.com/) | ([10percenthappier.com](https://www.10percenthappier.com/)) [12:15]

**Paper that might help explain why concentration is pleasurable**: [A Wandering Mind is an Unhappy Mind](https://www.danielgilbert.com/KILLINGSWORTH%20&%20GILBERT%20(2010).pdf) | Matthew A. Killingsworth and Daniel T. Gilbert ([danielgilbert.com](https://www.danielgilbert.com/)) [13:15]

**Powerful commencement speech that Peter frequently comes back to**: [This Is Water – Full version-David Foster Wallace Commencement Speech](https://www.youtube.com/watch?v=8CrOL-ydFMI) | Jamie Sullivan (youtube.com) [30:30]

**Origin of human language**: [Origin of language](https://en.wikipedia.org/wiki/Origin_of_language) | ([wikipedia.org](https://www.wikipedia.org/)) [32:00]

**Pavlovian responses**: [Classical conditioning](https://en.wikipedia.org/wiki/Classical_conditioning) | ([wikipedia.org](https://www.wikipedia.org/)) [33:45]

**Two links where Peter discusses his personal story with back surgery**: [54:15]

- [What does lower back pain have in common with low carb eating?](https://peterattiamd.com/what-does-lower-back-pain-have-in-common-with-low-carb-eating/) | Peter Attia (peterattiamd.com)
- [Dr. Peter Attia: Healthcare Cost Containment](https://peterattiamd.com/2016-update/) | Stern Speakers (youtube.com)

**Peter explaining the ‘four stages of competence’ starting at 1:15:00**: [AMA #1: alcohol, best lab tests, wearables, finding the right doc, racing, and more (EP.04)](https://peterattiamd.com/ama01/) | Peter Attia (peterattiamd.com) [55:45]

**Retreat that Sam went on as a 16-year-old**: [Outward Bound](https://outwardbound.org) | ([outwardbound.org](https://www.outwardbound.org/)) [58:45]

**Sam describes his first experience in solitude on an episode of the Tim Ferriss Show**: [Sam Harris, Ph.D. — How to Master Your Mind (#342)](https://tim.blog/2018/10/29/sam-harris-waking-up/) | Tim Ferriss ([tim.blog](https://tim.blog/)) [59:00]

**Book which contrasts ‘altered states with altered traits’**: [Altered Traits: Science Reveals How Meditation Changes Your Mind, Brain, and Body](https://www.amazon.com/Altered-Traits-Science-Reveals-Meditation/dp/0399184384) by Daniel Goleman & Richard J. Davidson | (amazon.com) [1:04:30]

**Trials studying the efficacy and risks of MDMA for PTSD**: [MDMA-Assisted Psychotherapy](https://maps.org/research/mdma) | ([maps.org](https://maps.org/)) [1:13:15]

**Peter’s profound experience volunteering at North Kern prison**: [Corey McCarthy: Overcoming trauma, dealing with shame, finding meaning, changing the self-narrative, redemption, and the importance of gratitude (EP.12)](https://peterattiamd.com/coreymccarthy/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [1:24:00]

**Concept of moral luck**: [Moral Luck](https://web.archive.org/web/20141014002930/https://rintintin.colorado.edu/~vancecd/phil1100/Nagel1.pdf) | Thomas Nagel ([web.archive.org](https://web.archive.org/)) [1:28:00]

**Clinton presidential scandal**: [Clinton–Lewinsky scandal](https://en.wikipedia.org/wiki/Clinton%E2%80%93Lewinsky_scandal) | (wikipedia.org) [2:16:00]

**Sam has a book in the works that says may be a collection of insights from podcast guests similar to what Tim Ferriss did**: [Tools of Titans: The Tactics, Routines, and Habits of Billionaires, Icons, and World-Class Performers](https://www.amazon.com/Tools-Titans-Billionaires-World-Class-Performers/dp/1328683788) by Tim Ferriss | ([amazon.com](https://www.amazon.com/)) [2:26:00]

**An example of a career lost over a slight misstatement**: [Amid racial bias protests, Claremont McKenna dean resigns](https://www.latimes.com/local/lanow/la-me-ln-claremont-marches-20151112-story.html) | TERESA WATANABE and CARLA RIVERA ([latimes.com](https://www.latimes.com/)) [2:27:30]

**Another example, Megyn Kelly, of a ruined career over a misstatement**: [Megyn Kelly Out at NBC After Blackface Comments](https://www.rollingstone.com/tv/tv-news/megyn-kelly-nbc-fired-blackface-747389/) | Jon Blistein ([rollingstone.com](https://www.rollingstone.com/)) [2:27:45]

**Megyn Kelly apologizing**: [Megyn Kelly Apologizes For Blackface Comments: ‘I Was Wrong, And I Am Sorry’ | Megyn Kelly TODAY](https://www.youtube.com/watch?v=OXCzo4wL_0s) | TODAY ([youtube.com](https://www.youtube.com/)) [2:29:00]

**Program started by Cat Hoke that works with inmates to give them hope and a playbook for future success**: [Defy Ventures](https://defyventures.org/) | ([defyventures.org](https://defyventures.org/)) [2:31:00]

**Tragic story of Charles Whitman killing 14 people at the University of Texas, tumor pushing on his amygdala which may have lead to his violent impulses**: [University of Texas tower shooting](https://en.wikipedia.org/wiki/University_of_Texas_tower_shooting) | ([wikipedia.org](https://www.wikipedia.org/)) [2:37:15]

**Sam is attacked for his supposedly insensitive remarks during his appearance on Real Time with Bill Maher**: [Ben Affleck, Sam Harris and Bill Maher Debate Radical Islam | Real Time with Bill Maher (HBO)](https://www.youtube.com/watch?v=vln9D81eO60) | Real Time with Bill Maher ([youtube.com](https://www.youtube.com/)) [2:25:30]

§

§

## People Mentioned

- [Dan Harris](https://twitter.com/danbharris?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (meditation app [10% Happier](https://www.10percenthappier.com/)) [12:15]
- [Jeff Warren](https://jeffwarren.org/about/) (guide in the 10% Happier courses) [12:15]
- [Joseph Goldstein](https://en.wikipedia.org/wiki/Joseph_Goldstein_(writer)) (guide in the 10% Happier courses) [12:15]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) (This is Water speech) [30:30, 1:19:00]
- [Lucius Annaeus Seneca](https://en.wikipedia.org/wiki/Seneca_the_Younger) (“We suffer more in imagination than in reality.”) [36:00]
- [William Shakespeare](https://en.wikipedia.org/wiki/William_Shakespeare) (from Hamlet, “for there is nothing either good or bad, but thinking makes it so.”) [36:00]
- [Blaise Pascal](https://en.wikipedia.org/wiki/Blaise_Pascal) (“Distraction is the only thing that consoles us for miseries and yet it is itself the greatest of our miseries.”) [36:30]
- [René Descartes](https://en.wikipedia.org/wiki/Ren%C3%A9_Descartes) (a similar quote as Seneca, Shakespeare, and Pascal) [36:30]
- [Saddam Hussein](https://en.wikipedia.org/wiki/Saddam_Hussein) (evil doesn’t invent itself) [1:20:45]
- [Tim Ferriss](https://twitter.com/timferriss?lang=en) (invited Peter to a profound visit to Kern Prison with Defy Ventures) [1:24:00, 2:26:00, 2:41:15]
- [Corey McCarthy](https://twitter.com/coreymccarthyie) (guest on The Drive, visited Kern prison with Peter and Tim) [1:24:00]
- [Thomas Nagel](https://en.wikipedia.org/wiki/Thomas_Nagel) (philosophical concept of “moral luck”) [1:28:00]
- [Nick Venuto](https://www.legacy.com/obituaries/carmelvalleynews/obituary.aspx?n=nicholas-john-venuto&pid=151649433) (Peter’s friend killed in a cycling accident by someone texting and driving) [1:30:30]
- [Jean-Jacques Rousseau](https://en.wikipedia.org/wiki/Jean-Jacques_Rousseau) (story about riding in a boat and spontaneously falling into some very open and non-egocentric state of consciousness that we would not recognize) [1:43:45]
- [Ron Howard](https://profiles.stanford.edu/ronald-howard) (Sam’s professor at Stanford that shaped his thinking about honesty and lying) [2:07:00]
- [Donald Trump](https://twitter.com/POTUS) (honesty in politics) [2:12:45]
- [Bill Clinton](https://twitter.com/billclinton?lang=en) (honesty in politics) [2:16:00]
- [Monica Lewinsky](https://twitter.com/MonicaLewinsky?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (Clinton impeachment) [2:16:00]
- [Kim Jong Un](https://en.wikipedia.org/wiki/Kim_Jong-un) (amazing golfer, doesn’t defecate) [2:17:00]
- [Gary Hart](https://en.wikipedia.org/wiki/Gary_Hart) (Frontrunner in 1988 Democratic presidential nomination until he dropped out over allegations of an extramarital affair) [2:17:15]
- [Olivia Attia](https://peterattiamd.com/sneak-peek-peter-attia-drive/) (Peter’s daughter) [2:18:45]
- [Annaka Harris](https://twitter.com/AnnakaHarris?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (teaches meditation to kids) [2:20:30]
- [Megyn Kelly](https://twitter.com/megynkelly?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (fired over a misstatement) [2:27:45]
- [Catherine Hoke](https://twitter.com/catherine_hoke?lang=en) (Defy Ventures) [2:31:00]
- [Charles Whitman](https://en.wikipedia.org/wiki/Charles_Whitman) (shooter at the University of Texas in 1964 with a tumor pressing against his amygdala) [2:37:15]
- [Patrick O’Shaughnessy](https://twitter.com/patrick_oshag?lang=en) (encouraged Peter to start a podcast) [2:41:15]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/12/sam-1-500x500.jpg)

##### Sam Harris, Ph.D.

Sam Harris is the author of five *New York Times* bestsellers and the host of the [Waking Up Podcast](https://samharris.org/podcast/). His books include *The End of Faith*, *Letter to a Christian Nation*, *The Moral Landscape*, *Free Will*, *Lying*, *Waking Up*, and *Islam and the Future of Tolerance* (with Maajid Nawaz). *The End of Faith* won the [2005 PEN Award for Nonfiction](https://pen.org/2005-literary-awards-winners/). His writing and public lectures cover a wide range of topics—neuroscience, moral philosophy, religion, meditation practice, human violence, rationality—but generally focus on how a growing understanding of ourselves and the world is changing our sense of how we should live. Harris’s work has been published in more than 20 languages and has been discussed in *The New York Times*, *Time*, *Scientific American*, *Nature*, *Rolling Stone*, and many other journals. He has written for *The New York Times*, *The Los Angeles Times*, *The Economist*, *The Times (London)*, *The Boston Globe*, *The Atlantic*, *Nature*, *The Annals of Neurology*, and elsewhere. Sam Harris received a degree in philosophy from Stanford University and a Ph.D. in neuroscience from UCLA. For more, see his [publications and lectures](https://samharris.org/publications-and-lectures/). [[samharris.org](https://samharris.org/)]