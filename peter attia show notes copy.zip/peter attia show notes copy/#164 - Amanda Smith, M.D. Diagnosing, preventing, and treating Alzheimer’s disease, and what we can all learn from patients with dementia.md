# #164 – Amanda Smith, M.D.: Diagnosing, preventing, and treating Alzheimer’s disease, and what we can all learn from patients with dementia

**Source:** [https://peterattiamd.com/amandasmith/](https://peterattiamd.com/amandasmith/)

---

Amanda Grant Smith is a geriatric psychiatrist with decades of experience treating patients with dementia and Alzheimer’s disease. In this episode, Amanda shares how she developed a passion for geriatric psychiatry as a means to support dementia patients. She explains how to recognize, define, and diagnose dementia—a process that still remains somewhat elusive. They also talk about the significance of ApoE genotype and compare the various forms of dementia including differentiating between Alzheimer’s disease and Lewy body dementia. They discuss the current landscape of clinical trials, the drug pipeline, and talk about a very promising monoclonal antibody directed at amyloid beta that has the potential to be a disease-modifying drug. They conclude with a discussion about how to define “healthy aging” and reflect on how understanding dementia can shape one’s life philosophy.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/hf2ERS7MAws)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/amandasmith/the_Drive_public.png)

Play

#164 - Amanda Smith, M.D.: Diagnosing, preventing, and treating Alzheimer's disease, and what we can all learn from patients with dementia

#164 - Amanda Smith, M.D.: Diagnosing, preventing, and treating Alzheimer's disease, and what we can all learn from patients with dementia

1x15s30s

0:002:01:48

## We discuss:

- How Amanda developed a passion for geriatric psychiatry [3:15];
- Defining and diagnosing dementia and Alzheimer’s disease [13:30];
- Medical tests for dementia and their relationship to clinical symptoms [22:45];
- The pathology of dementia, and the role of the tau and beta-amyloid protein in Alzheimer’s disease [33:15];
- The significance of ApoE genotype, and differentiating Alzheimer’s disease from Lewy body dementia [43:15];
- The evolution of Alzheimer’s disease prevention, care, and medications over the last 20 years [52:45];
- Psychiatric support for dementia patients (and caregivers) with depression and anxiety [1:02:45];
- Drug pipeline, clinical trials, and major challenges to overcome [1:13:45];
- Redefining Alzheimer’s disease and designing effective trials [1:23:00];
- The promise of monoclonal antibody treatments for Alzheimer’s disease [1:34:15];
- How we should measure outcomes in dementia trials and define “healthy aging” [1:42:30];
- How understanding dementia can reshape our life philosophy [1:53:45]; and
- More.

§

## Show Notes

## How Amanda developed a passion for geriatric psychiatry [3:15]

- Peter and Amanda met at a Zoom event for [Hilarity for Charity](https://wearehfc.org/about/), a non-profit organization focused on [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease)
  - They appeared with [Richard Isaacson](https://weillcornell.org/risaacson) to discuss Alzheimer’s disease research and treatment
  - Peter was impressed by Amanda’s focus on the impact that Alzheimer’s disease has on the family as much as it does on the patient
- Amanda specializes in geriatric psychiatry
  - She grew up in Philadelphia with active grandparents who owned and operated a nursing home
  - “Seeing the vibrant lives they led even into their 70s and 80s, that to me was normal aging”
  - But in medical school, she “really saw the pathologic side of aging and the things that can go wrong as we get older”
- She noticed an attitude of ageism among physicians
  - One day she was sent in to talk to a woman who had come in from a nursing home with chest pain
  - The doctors wondered how she had obtained a history because they said the woman did not make sense, but it turned out that the EMT had forgotten to bring the woman’s dentures, but she was mentally sound
  - The doctors would have known this if they had taken the time to listen to her

> “I realized how quick people are to brush off the elderly. And it kind of lit a fire in me so to speak so that that became my passion.” —Amanda Smith

- There are many ways to interact with elderly patients, like cardiology and other subspecialties
- When Amanda was starting out, there was not much that we could do about the cognitive side of things
  - She graduated med school in 1997, the year that [donepezil](https://en.wikipedia.org/wiki/Donepezil) (Aricept) was first approved
  - has witnessed the evolution of Alzheimer’s treatments
- The behavior problems that can occur in people with dementia (e.g., anxiety, depression, psychosis) have always been treatable
  - These are common reasons to see people on the geriatric psychiatry unit (e.g., taking apart the ceiling tiles and their apartment to find these wires that weren’t really there)
  - we can control some of these behaviors so that patients can have a better quality of life and caregivers can have a little more peace of mind
- Peter wonders if the patients typically already have a dementia diagnosis or if the presenting feature of the dementia can be some of these psychotic symptoms so the doctors need to rule out schizophrenia or other forms of psychosis
  - Amanda says it’s both
  - When psychosis presents first, patients sometimes get diagnosed with schizophrenia or bipolar illness or another illness that does not have an onset in the mid-70s
  - Have a misdiagnosis for a few years until it becomes really apparent that there is an underlying neurodegenerative process
- Peter observes that the early stages of dementia can be quite unnerving and some of the behavior might be driven by legitimate and understandable fear that something is wrong
  - Amanda says that some people are blissfully unaware throughout the entire course of their illness even in the very mild stages
  - while others are acutely aware that something’s not right and know for two or three years before doctors can find any discernible changes on their testing
  - The second group suffers much more
- [Lewy body dementia](https://en.wikipedia.org/wiki/Lewy_body_dementias)
  - a type of dementia that has characteristics of Alzheimer’s, characteristics of Parkinson’s, and very prominent visual hallucinations
  - A few of Amanda’s patients are aware that their visual hallucinations are not real

## Defining and diagnosing dementia and Alzheimer’s disease [13:30]

- Dementia is an umbrella term that denotes changes in memory and other areas of cognition
  - represents a change from previous state (e.g., not born with it)
  - interferes with your day-to-day function
- There are many causes of dementia, but Alzheimer’s is the most common
- Diagnosis
  - have been advancements in many of our tests
    - more sophisticated imaging techniques
    - blood biomarkers
  - But the real crux of diagnosis is a good clinical interview with the patient and with an observer
    - Interview a family member or friend separately to get info about changes over time
  - Specific tests
    - cognitive testing to look for patterns that support one diagnosis over another
    - brain imaging to look for things like strokes or shrinking in certain parts of the brain
    - lab tests to rule out reversible causes of memory loss: thyroid disturbance, vitamin deficiencies, tertiary syphilis (very uncommon these days), etc.
  - with this info can typically figure out the right label for them
    - Sometimes we need formal neuropsych testing with a neuropsychologist
    - Sometimes we do need PET scanning to look at certain patterns
- [Frontotemporal dementia](https://en.wikipedia.org/wiki/Frontotemporal_dementia)
  - relatively preserved memory, but significant changes in language or behavior
  - It’s often the diagnosis when a relative says the patient’s memory is not too bad, BUT … they can’t really talk anymore, or they’ll get up in church and take the microphone from the pastor
  - sometimes are erroneously diagnosed with bipolar illness because of these sudden and really profound behavior changes
  - Problems with judgment: get labeled as being manic because of judgement issues like they’re spending lots of money, etc.
- Clinical story is very important for Alzheimer’s disease
  - Very unlike cancer, where the diagnosis is typically based on imaging and the gold standard is a histological diagnosis – you don’t biopsy the brain
  - A few formal tests are useful to confirm a diagnosis
    - [Lumbar puncture](https://en.wikipedia.org/wiki/Lumbar_puncture) (LP) (“spinal tap”): sampling [cerebrospinal fluid](https://en.wikipedia.org/wiki/Cerebrospinal_fluid) (CSF) to look for [amyloid-β](https://en.wikipedia.org/wiki/Amyloid_beta) or [tau protein](https://en.wikipedia.org/wiki/Tau_protein)
    - [PET](https://en.wikipedia.org/wiki/Positron_emission_tomography) to look for amyloid

![](https://peterattiamd.com/wp-content/uploads/2021/06/f1-amandasmith-1024x526.png)

**Figure 1. Amyloid-β plaques and tau protein (neurofibrillary) tangles are the microscopic signs of Alzheimer’s disease.** Amyloid-β clumps together in plaques between neurons.  Tau is a protein that normally stabilizes microtubules, structures that help transport nutrients and molecules.  In Alzheimer’s, tau detaches from the microtubules and forms tangles inside neurons.  Both plaques and tangles disrupt normal cell function and communication between neurons. *Image credit:* [*Health Jade*](https://healthjade.net/what-is-dementia/)

- Although you can’t a brain biopsy to look for amyloid until after death, we can now image amyloid in living patients
  - has allowed us to design some prevention trials targeting people who have brain amyloid but not yet memory symptoms
  - but it’s not covered by insurance and would cost $4000 out of pocket, so it’s not a real option for most patients
- There is a good correlation between PET and CSF findings
  - but as a psychiatrist and not a neurologist, Amanda doesn’t do lumbar punctures as part of her practice
  - She will occasionally refer people to neuro for an LP to look at CSF
- Some insurance will cover [MRI](https://en.wikipedia.org/wiki/Magnetic_resonance_imaging), PET, and [FDG-PET](https://en.wikipedia.org/wiki/Positron_emission_tomography) a (PET scan using the radioactive tracer 18F-FDG, a glucose analog), which measures how well the brain is using glucose as its fuel and has different patterns supporting one diagnosis over another
- Classic Alzheimer’s disease presentation is preservation of long-term memory but difficulty with short-term memory
- Peter asks how Amanda distinguishes distraction from dementia
  - Forgetting to do something or a new person’s name is not necessarily dementia – can just be that the person was distracted
  - Have to put it in context
    - some of this happens with normal aging
    - other factors like stress, a bad night’s sleep, etc. can affect it
    - frequency and intensity are also important

> “If it’s the exception rather than the rule, it’s probably not dementia. But when that becomes sort of how you are and what happens every day, then it’s more concerning.” —Amanda Smith

## Medical tests for dementia and their relationship to clinical symptoms [22:45]

- With an MRI, looking for hippocampal volume or other brain matter loss
- Ruling out vascular disease (or quantifying the amount of it)
  - We all get tiny little strokes with aging, high blood pressure, high cholesterol, smoking, diabetes, etc.
  - no symptoms and don’t notice
  - normal if they are extremely mild or scattered
  - But if they coalesce or extend into cortical areas (parts of the brain that matter for critical thinking), then they can be symptomatic

**Hippocampal volume**

- The [hippocampus](https://en.wikipedia.org/wiki/Hippocampus) is the part of the brain where short-term memories are formed
- Look at how much shrinking there is both globally and in the hippocampus
  - Hippocampal shrinking, especially out of proportion to shrinking elsewhere in the brain, can be a biomarker of Alzheimer’s disease
  - Hippocampal sclerosis: hippocampal atrophy but amyloid negative
    - from a stroke, chronic traumatic encephalopathy, or buildup of non-amyloid proteins that can affect memory as well
  - Tracking hippocampal volume over time is of limited use
    - other factors can affect hippocampal volume: chronic exposure to [cortisol](https://en.wikipedia.org/wiki/Cortisol) (the stress hormone), [post traumatic stress disorder](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder) (PTSD), etc.

![](https://peterattiamd.com/wp-content/uploads/2021/06/f2-amandasmith-1024x679.png)

**Figure 2. Gross changes in the brain of Alzheimer’s patients.** Image credit: [Health Jade](https://healthjade.net/what-is-dementia/)

- Sometimes the brains of people who are very impaired don’t really look bad, others look terrible on a scan but are functioning fine

> “So it’s again one of those things that really has to be taken in context with all of the other information and part of the reason why the clinical evaluation and interview and the intangible stuff is so important.” —Amanda Smith

- The diagnosis requires a clinical story whether or not there is amyloid
- Peter points out that there is a lot of overlap between people with amyloid and people with clinical symptoms suggestive of dementia, “but it’s not a perfect union”
  - amyloid is necessary for Alzheimer’s disease but not for other types of dementia
  - pathologically Alzheimer’s is marked by amyloid plaques and tau tangles in the brain
- [Study](https://pubmed.ncbi.nlm.nih.gov/21245183/) on utility of PET scan testing
  - used [florbetapir](https://en.wikipedia.org/wiki/Florbetapir_(18F)) (Amyvid), one of the first amyloid imaging ligands
  - people with Alzheimer’s had an amyloid imaging PET scan (using an antibody to amyloid as a tracer) and then donated their brains after death
  - the correlation between the scan and post-mortem brain pathology was ~97%
  - That is encouraging news for being able to diagnose amyloid before death
  - Peter points out that it was missing a control group of people who had amyloid in their brains (and thus go on to have amyloid on autopsy) but didn’t have Alzheimer’s disease
- We don’t know what percentage of people have amyloid in their brain on autopsy but did not have symptoms of dementia during their life
  - amyloid imaging has helped us understand that amyloid starts to build up 10-20 years before you start to have symptoms of forgetfulness and other cognitive symptoms
  - There’s still scientific debate about what the critical mass or downstream effect of amyloid buildup is
  - There’s a theory that amyloid builds up years beforehand but it’s not until you start to have tau spreading that it correlates with symptoms
  - It may be tau that serves to stage the disease
- there are a lot of people who might start to build up amyloid in their 70s but then die of something else
  - similar to coronary calcification
    - if someone dies of cancer and on autopsy you find calcification in their coronary arteries, they had atherosclerosis that never manifested clinically
    - if had not died of cancer, might have died of a myocardial infarction (MI) (a heart attack) 10 years later
- before 2011, the definition of Alzheimer’s was dementia

> “So there was no place in research for … testing these interventions in people before they had full-blown dementia. And that was very much like waiting till someone had a heart attack to say that they had coronary artery disease.” —Amanda Smith

- in 2011, with the advent of amyloid imaging, that changed because could see amyloid building up in patients before they started to have symptoms
- first used [Pittsburgh compound B](https://en.wikipedia.org/wiki/Pittsburgh_compound_B), but its clinical use was limited because it has to be made and used within minutes

- Peter discussed the progression of Alzheimer’s (preclinical phase, then mild cognitive impairment, then dementia) in his previous [podcast](https://peterattiamd.com/richardisaacson/) with [Richard Isaacson](https://weillcornell.org/risaacson)

> “[Amyloid imaging] has allowed us to then take a step back and see if we can intervene before people have the symptoms that we may not be able to reverse.” —Amanda Smith

## The pathology of dementia, and the role of the tau and beta-amyloid protein in Alzheimer’s disease [33:15]

**The 3 main categories of chronic disease**

- Peter says there are essentially 3 main categories of chronic disease:
  - Alzheimer’s disease
  - Cancer
  - Atherosclerotic diseases (both cerebrovascular and cardiovascular)
- These three legs stand on the platform of metabolic disease (hyperinsulinemia to insulin resistance, NAFLD and type II diabetes)

![](https://peterattiamd.com/wp-content/uploads/2021/06/f3-amandasmith-1024x766.png)

**Figure 3. A schematic of chronic disease.**

- We have the best understanding of atherosclerosis
  - we can stage it lesion by lesion
  - We understand [fatty streaks](https://en.wikipedia.org/wiki/Fatty_streak), [foam cells](https://en.wikipedia.org/wiki/Foam_cell), what leads to calcification, and how it progresses from soft [plaque](https://en.wikipedia.org/wiki/Atheroma) to vulnerable plaque to a ruptured plaque to an MI
  - It’s nonsensical to wait until someone has a major adverse cardiac event
    - Peter would say waiting until a person’s ten-year risk exceeds 5% to intervene is equally nonsensical, yet that is still largely the standard
    - Process begins as early as the teen years

**Various versions of dementia**

*Amyloid and Alzheimer’s disease*

- Now anyone who has dementia with amyloid is classified as having Alzheimer’s disease
  - but they may also have other diagnoses: a mixed dementia where you have Alzheimer’s and vascular disease or Lewy body and Alzheimer’s
  - [Dennis Dickson](https://www.mayo.edu/research/faculty/dickson-dennis-w-m-d/bio-00027499) at the Mayo Clinic in Jacksonville [has shown](https://pubmed.ncbi.nlm.nih.gov/12468894/) that most pathology is actually mixed
- Peter has [interviewed](https://peterattiamd.com/franciscogonzalezlima/) [Francisco Gonzalez-Lima](https://liberalarts.utexas.edu/psychology/faculty/fg), who works with [Jack De la Torre](https://alliedacademies.com/profile/jack%20de%20la%20torre) at UT Austin
  - They believe that microvascular disease is the big driver here
  - Most people have significant microvascular damage in their 60s and beyond
  - A critical mass of damage results in cognitive impairment and ultimately higher levels of impairment, such as executive function deficits
- If amyloid is also accumulating over the years, you could have dementia related to both amyloid and vascular disease
  - Addressing factors like hypertension, smoking, and dyslipidemia might affect the amyloid factor as well as vascular disease
  - Richard Isaacson stressed the importance of cardiovascular risk factors in the development of Alzheimer’s
- A protein closely related to amyloid (“normal amyloid”) is a regular component of blood vessel walls
  - The kind that builds up in Alzheimer’s (“pathological amyloid”) is abnormal in length
  - “because it is part and parcel of blood vessel walls, it’s only natural to assume there must be this interplay between the vasculature and the Alzheimer’s side of things”
  - But the relationship is still unknown

> “There are some really exciting developments in terms of looking at blood biomarkers including plasma amyloid in terms of potentially having a blood-based test for Alzheimer’s. So there has been progress there and I think that as time goes on, we’re going to be able to do these less invasive tests and really have a better sense of both risk for people who aren’t maybe symptomatic yet as well as diagnosis.” —Amanda Smith

- You can have tau without amyloid
  - Some kinds of frontotemporal dementia are characterized by abnormal tau buildup in the absence of amyloid
  - [Chronic traumatic encephalopathy](https://en.wikipedia.org/wiki/Chronic_traumatic_encephalopathy) related to sports like football and boxing shows abnormal tau often in the absence of amyloid

**What do tau and amyloid do? (41:15)**

- There is a cascade of damage

- Activation of glial cells, which help protect our brain against intruders by releasing toxins (autophagy, eating up our own tissue)

![](https://peterattiamd.com/wp-content/uploads/2021/06/f4-amandasmith-1024x283.png)

**Figure 4. Several types of glial cells in the central nervous system**.  Microglia digest foreign particles.  Macroglia include ependymal cells (which produce cerebrospinal fluid), oligodendrocytes (which manufacture and repair insulating sheaths around neuron axons), and astrocytes (which connect signal-producing neurons to other cells and help maintain permeability of the blood-brain barrier (BBB)).  Image credit: [Biology Dictionary](https://biologydictionary.net/glial-cells/)

- There is damage both inside and outside the neurons
- Eventually leads to cell death

![](https://peterattiamd.com/wp-content/uploads/2021/06/f5-amandasmith-1024x581.png)

**Figure 5. Effects of tau and amyloid on neurons and glial cells.** ([Cytokines](https://en.wikipedia.org/wiki/Cytokine) are proteins that play a role in immune cell signaling.)  Image credit: [Busche & Hyman 2020](https://www.nature.com/articles/s41593-020-0687-6?elqTrackId=c54d69181ceb42f8baa0c142b9a0e00a)

- Peter wonders whether in this particular pathology injuring the glial cells is at least to a first order approximation equally responsible for the damage as neuron death
- Amanda thinks glial cells are more responsible for the damage because they are injuring neurons as they try to protect them

![](https://peterattiamd.com/wp-content/uploads/2021/06/f6-amandasmith-1024x432.png)

**Figure 6. Overview of brain cell atrophy in Alzheimer’s disease.** Image credit: [Congdon & Sigurdsson 2018](https://www.nature.com/articles/s41582-018-0013-z)

## The significance of ApoE genotype, and differentiating Alzheimer’s disease from Lewy body dementia [43:15]

**Apolipoprotein E (ApoE) genotype (43:15)**

- Can measure ApoE in the plasma
  - [Some data suggest](https://www.atherosclerosis-journal.com/article/S0021-9150(16)31440-X/fulltext) an association between plasma ApoE level and the risk of dementia, but it has not been established as an independent biomarker
  - Amanda thinks it’s really more about the genotyping than the quantification of it

![](https://peterattiamd.com/wp-content/uploads/2021/06/f7-amandasmith-1024x224.png)

**Figure 7. Relative risk for Alzheimer’s disease based on ApoE genotype.**  There are three different alleles (variations) of the ApoE gene (ε2, ε3, and ε4) and everyone has two copies of this gene. There are 6 possible genotypes (ε2/ε2, ε2/ε3, ε2/ε4, ε3/ε3, ε3/ε4 or ε4/ε4). ε3 (the most common allele) does not affect risk, while ε2 (the least common allele) seems to confer some protection. The ε4 allele, found in 10-15% of people, increases risk.  Image credit: [The Conversation](https://theconversation.com/genetic-testing-should-i-get-tested-for-alzheimers-risk-97065)

- Homozygous ε4 (ε4/ε4 – two copies of the ε4 allele)
  - higher risk of Alzheimer’s
  - different responses to cardiovascular meds
  - different risks for other diseases besides dementia too
- It’s typically not something routinely checked for in clinical care because it’s not diagnostic: can have ε4/ε4 and not have Alzheimer’s or ε2/ε3 and still have Alzheimer’s
- has a lot more utility in the research setting
  - can study how carriers versus noncarriers respond to certain treatments
  - carriers may respond differently to different lifestyle interventions
  - may have an earlier onset compared to people who are not carriers but ultimately get same disease
- Peter thinks ApoE ε4 is great to help people identify risk early on, but it doesn’t change much clinically
  - He tells his ε2/ε3 patients they have about a 10% reduction relative to the ε3/ε3 but still not off the hook
  - Tells ε3/ε4 (or even ε4/ε4 patients) it’s not a done deal but need to take preventative measures seriously

**Comparing Alzheimer’s and Lewy body dementia**

- Classic Alzheimer’s
  - begin with short-term memory loss
  - slowly over time progress to having difficulty doing things like paying bills
  - then eventually needing supervision or assistance with activities of daily living (cooking, bathing, etc.)
  - May or may not have behavior issues or changes in walking
- Lewy body dementia
  - a diagnosis that can technically be made only post-mortem
  - but there is a classic clinical picture that is so compelling that it can be made fairly accurately in the clinic without diagnostic testing
  - classic triad of symptoms that occur within two years of one another
    - Alzheimer’s-like cognitive impairment that can notably fluctuate so that some days they seem good and on others they are very impaired
    - Parkinsonism component where they will often be stiff, shuffle, have trouble rising from a chair, don’t move arms when they walk (but unlike with Parkinson’s, often don’t have tremor with Lewy body)
    - Visual hallucinations (often accompanied by related delusions)
  - Additional supportive features, including restless leg syndrome and REM sleep behavior disturbances
    - Sometimes spouses will say they act out in their dreams, like punching their spouse
  - Both the motor and the cognitive symptoms fluctuate, sometimes dramatically
  - In Amanda’s own experience, time from diagnosis until those patients are either in hospice or incapacitated or dead is about 8-10 years
    - But many of her patients experience a precipitous decline and then hit a plateau for a while and then really drop off
    - less often as protracted as Alzheimer’s can be
- Other differences
  - Even though the average for Alzheimer’s is still also eight to 10 years, it can be significantly longer
  - There are specific genetic mutations associated with early onset Alzheimer’s
    - [Presenilin 1](https://en.wikipedia.org/wiki/PSEN1) (PSEN1) on chromosome 14
    - [Presenilin 2](https://en.wikipedia.org/wiki/PSEN2) (PSEN2) on chromosome 1
    - [Amyloid precursor protein](https://en.wikipedia.org/wiki/Amyloid-beta_precursor_protein) (APP) on chromosome 21
    - These mutations are as close to deterministic as you can get
    - but Amanda is not aware of any genetic mutations associated with Lewy body dementia

- Alzheimer’s-specific risk
  - the ApoE ε4 allele is not deterministic, but is highly suggestive for the more typical variants
  - Other known risk factors like diabetes, microvascular, disease, and dyslipidemia
- Amanda isn’t sure of the relative incidence of Alzheimer’s versus Lewy body dementia
  - but it depends if you’re looking at the autopsy confirmed versus clinic diagnosed
  - Lewy body dementia is less often diagnosed, but more often unexpectedly found on autopsy

- In Amanda’s clinic, it’s 50-60+% Alzheimer’s, ~20% true vascular, and ~20% Lewy body
  - the rest is frontotemporal dementia, some of the Parkinson’s plus syndromes, [progressive supranuclear palsy](https://en.wikipedia.org/wiki/Progressive_supranuclear_palsy), and other less common things

## The evolution of Alzheimer’s disease prevention, care, and medications over the last 20 years [52:45]

- Patients come to Amanda in a variety of ways: referred from their primary doctors, self-referred, referred by neurology
  - Peter points out the difference this makes: self-aware patients vs. a PCP suspicion vs. a neurologist who has likely made a diagnosis
  - Amanda says about half of her patients think she’s a neurologist; they just know she’s affiliated with the Alzheimer’s / memory center
- Amanda’s early career
  - Went to USF in 1997 as an intern
  - did a residency in psychiatry and then a fellowship in geriatric psychiatry
  - chose USF in part because of [Eric Pfeiffer](https://marquistopdoctors.com/2018/12/26/eric-pfeiffer/)
    - a leader in the field of geriatric psychiatry and Alzheimer’s disease
    - first president of the American Association for Geriatric Psychiatry
    - runs the Suncoast Gerontology Center
  - finished her fellowship and went to work for Eric in 2002
  - when he retired in 2008, Amanda became the director of the center and principal investigator for a lot of the center’s clinical trials
- How Amanda’s practice has changed in the past 20 years

> “The thing that’s the same, I would say, is the fear. People are terrified of losing their minds and losing their memories.” —Amanda Smith

- Seeing patients at both the older and younger ends of the spectrum
- More awareness of Alzheimer’s as a disease and treatment options
- When she first started practicing, there wasn’t much she could do about it
  - People assumed it was a normal consequence of aging
  - There has been success getting out the message that “this is not something that you have to live with and this is not a normal consequence of getting older”
  - People are seeking baseline evaluations and asking about prevention

- Peter interviewed Richard Isaacson because he runs a prevention clinic at Cornell focusing on the lifestyle modifications and other things that people can do earlier

> “I think that’s the biggest area where things have shifted. I think there’s also a better understanding that people realize that there’s more that we can do, and that early intervention is key.” —Amanda Smith

**Using medications to treat dementia patients**

- People often used to be embarrassed or isolated by this problem; now they understand that medications can slow down decline (and even help in some people)
  - there was one [study](https://agsjournals.onlinelibrary.wiley.com/doi/abs/10.1046/j.1365-2389.2003.51306.x) showing that donepezil delayed nursing home placement [59:00]
  - That’s huge even if people are still going to get worse on the medication
- the majority of Amanda’s patients have some mood or behavioral issue that requires treatment with medication
  - 90% of people will have some behavioral issue at some point in their illness
  - Often simple like depression rather than a psychotic type issue
  - depression in a dementia patient is just as treatable as depression in a healthy 25-year-old
  - Frequently prescribes selective serotonin reuptake inhibitors ([SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor))
    - some adjustments made for age and renal function and other medications and drug interactions
    - well tolerated and don’t make patients fall
  - Amanda tries to avoid [benzodiazepines](https://en.wikipedia.org/wiki/Benzodiazepine) like [alprazolam](https://en.wikipedia.org/wiki/Alprazolam) (Xanax) and [lorazepam](https://en.wikipedia.org/wiki/Lorazepam) (Ativan)
    - particularly avoids [diazepam](https://en.wikipedia.org/wiki/Diazepam) (Valium) and longer-acting ones because they can increase confusion
    - there is a dramatically high incidence of hip fracture with chronic benzodiazepine use

- It’s important to use the minimum number of drugs and stop them when possible
  - Amanda has seen patients on something like 15 or 18 multiple meds
  - “Old people … collect meds like they collect other things. … You’re like, ‘Why are you even on this?’ … So we do have to be vigilant and really target symptoms with the safest, lowest dose and the shortest treatment period that we can. But in doing so [we] can be very effective in treating these symptoms”
  - Someone might have needed 3 medications to manage their blood pressure when they were 50
    - Now they are 90 and falling because their BP is too low
    - No one ever took them off the medication

> “We do have to be vigilant and really target symptoms with the safest, lowest dose and the shortest treatment period that we can. But doing so can be very effective in treating these symptoms.” —Amanda Smith

## Psychiatric support for dementia patients (and caregivers) with depression and anxiety [1:02:45]

- Amanda guesses that a majority of Alzheimer’s patients receive complementary treatment for depression or anxiety
  - Difficult for both patients and caregivers so often “seek help for that more acutely than they will for the underlying condition”
  - Sometimes a spouse or caregiver will also become a patient

- She provides a lot of support and education

> “So I have the opportunity to share their insights with others, … to make them understand that what they’re going through is valid and real, give them pointers and tools and things that they may not have thought of in terms of handling a certain behavior. Just that one little pearl that might make their day easier.” —Amanda Smith

- For example, if they refuse to get a shower, she suggests they offer the person’s favorite snack if they’ll do it
- Caregivers sometimes interpret the patient’s behavior as intentional, and it helps to understand that the disease is making them do it

- It’s like Elisabeth Kübler-Ross’s stages of grief on the way to acceptance

![](https://peterattiamd.com/wp-content/uploads/2021/06/f8-amandasmith-1024x723.png)

**Figure 8. Kübler-Ross’s Five Stages of Grief.**  Image credit: [Primary Care Diabetes Society](https://www.pcdsociety.org/resources/details/diabetes-diagnosed-how-use-grief-cycle-provide-emotional-support)

- Peter has seen this with his cancer patients
- Amanda sees it with caregivers who are essentially grieving for someone while they’re still alive

- Amanda listened to Peter’s [podcast](https://peterattiamd.com/laurenmillerrogen-richardisaacson/) with [Lauren Miller Rogen](https://en.wikipedia.org/wiki/Lauren_Miller_Rogen) and Richard Isaacson
  - Lauren tells a compelling story about her journey in grieving her mother, who was Amanda’s patient
  - losing her hopes for what her relationship with her mother would be like as she got older
  - “I think those stages of grief apply to almost everything. They’re sort of part and parcel of our existence as human beings is that’s kind of going to happen”
- With Peter’s cancer patients, once they get to the acceptance phase the residual concern is the amount of suffering at the end and the mechanism of death
  - Everyone knows in an abstract way that they’re going to die, “but it’s kind of a vague, fuzzy, foggy thing”
  - But patients in hospice with stage four cancer think about the actual mechanism of death
  - Peter thinks “a big part of that is explaining no, actually we might not be able to save your life, but we can absolutely prevent discomfort”
- Amanda explains to patients and caregivers that as they progress, they’re going to have more difficulty with more simple, basic things like swallowing and mobility
  - Some of them will die of something else before they reach a terminal stage of dementia

> “So we have the conversation, but we also try not to focus on the end game because that’s just miserable. … And that’s one of the biggest things that I see is not focusing on the end, but focusing on the now, because the truth is with Alzheimer’s, that’s all people have.” —Amanda Smith

- But she wants her patients to know that support will be available to them when the time comes

## Drug pipeline, clinical trials, and major challenges to overcome [1:13:45]

**Clinical Trials**

- Alzheimer’s disease and drugs do not have a great track record
  - Drugs have worked well for cardiovascular disease
  - Less well for cancer, but still much better than for Alzheimer’s
  - Peter says “I think you could make the case without being hyperbolic, that there is no disease that has a worse track record relative to the inputs on the output side”
    - There are orphan diseases for which we have no drugs, but “there have been a few shots on goal”
    - But the ratio of shots on goal to goals is lower in Alzheimer’s disease than any other disease
    - On one level, it’s related to the complexity of the disease
    - On another level, we may have targeted the wrong goal, too late in the game, the wrong angle, etc.

**Current drug pipeline**

- Today there are about 120 drugs in the pipeline
- Based on clinicaltrials.gov:
  - ~27 of them are in phase I
    - really just being evaluated for safety at this point
    - some animal data that suggests it might work, no human data yet but first need to make sure it’s safe
  - ~65 are in phase II
    - Passed bar of safe enough to move on from phase I
    - Now looking for some efficacy while we continue to monitor safety
  - ~29 are in phase III
    - at a small scale, they’ve shown efficacy, typically against a placebo
    - Now we see if there’s efficacy either versus a placebo on a larger scale or ideally against a current standard in a larger trial
    - this third stage that is required for [Food and Drug Administration](https://www.fda.gov/) (FDA) approval
- By drug category:
  - 12 in cognitive enhancement
  - 12 in neuropsychiatric and behavioral improvement
  - 97 in disease modification

**Types of dementia drugs**

- All drugs currently on the market are symptomatic treatments
  - can help slow cognitive decline or help improve memory and thinking
  - but are not targeting the underlying pathology of amyloid and tau
- [Cholinesterase inhibitors](https://en.wikipedia.org/wiki/Cholinesterase_inhibitor)
  - E.g., donepezil, [galantamine](https://en.wikipedia.org/wiki/Galantamine), and [rivastigmine](https://en.wikipedia.org/wiki/Rivastigmine)
  - help the neurons communicate
- [*N*-Methyl-D-aspartate (NMDA) receptor antagonists](https://en.wikipedia.org/wiki/NMDA_receptor_antagonist)
  - E.g., [memantine](https://en.wikipedia.org/wiki/Memantine)
  - normalizes levels of [glutamate](https://en.wikipedia.org/wiki/Glutamic_acid), helping with neurotransmission
- Behavioral drugs target specific problems like apathy, agitation, psychosis, sometimes sleep issues, and sometimes appetite and eating problems
- Disease modifying treatments actually target the underlying pathology
  - [monoclonal antibodies](https://en.wikipedia.org/wiki/Monoclonal_antibody_therapy) against primarily amyloid are the biggest group of those that are in trials right now [1:18:15]
  - Eventually hope to target tau as well to improve cognition or at least halt cognitive decline

**Amyloid-β**

- Amyloid-β is made at different points along the cascade
- the amyloid precursor protein is on Chromosome 21
  - this is why people with [Down syndrome](https://en.wikipedia.org/wiki/Down_syndrome) (who have three copies of [Chromosome 21](https://en.wikipedia.org/wiki/Chromosome_21)) almost inevitably will get Alzheimer’s if they live long enough
  - they’re making a third more amyloid than the rest of us
- But amyloid-β can be made anywhere from the very beginning of our DNA all the way through some of the enzymes that cleave amyloid
- The amyloid gets cleaved at the length of 40 or 42 amino acids rather than the regular length
  - Then the abnormal amyloid folds and there are five rolls
  - the plaque itself is a conglomeration of a series of folds in the protein

![](https://peterattiamd.com/wp-content/uploads/2021/06/f9-amandasmith-1024x542.png)

**Figure 9. Normal nerve cells vs. amyloid-β pathology.** Image credit: [MDPI](https://www.mdpi.com/1422-0067/17/3/338)

- There are even differences among the antibodies as to what part of that cascade they target
- Normal amyloid is a component of blood vessel walls
- The pathologic amyloid with abnormal lengths of amyloid-β 40 and 42 could be removed with no ill effects because they have no legit function in the body
  - researchers are targeting the enzymes that abnormally cleave amyloid as a potential treatment
  - both [gamma secretase](https://en.wikipedia.org/wiki/Gamma_secretase) inhibitors and [beta-site amyloid precursor protein cleaving enzyme](https://en.wikipedia.org/wiki/Beta-secretase_1) (BACE) inhibitors have been studied, but side effects have been an issue
- Peter wonders if there has been research on using an [antisense oligonucleotide](https://en.wikipedia.org/wiki/Antisense_therapy) to target enzyme transcription with laser precision
  - Amanda notes that the downstream effects of various potential treatments are often unknown
  - might cause liver toxicity or cardiac arrhythmias or something else that makes the drug unsafe
- There are five approved drugs for Alzheimer’s disease right now and a sixth that is a combination of two others
  - But all treat symptoms of disease rather than addressing the underlying cause of the disease
- It’s encouraging that that 80% of the pipeline is actually focusing on the underlying cause as opposed to just the symptoms

## Redefining Alzheimer’s disease and designing effective trials [1:23:00]

- In 2011, a major milestone occurred when we understood that amyloid pathology building up for many years was a key factor
  - Alzheimer’s was redefined
  - Some earlier drug trials may have been unsuccessful because they targeted amyloid too late
  - An understanding of the progression through preclinical Alzheimer’s and mild clinical impairment (MCI) allowed us to then design currently ongoing trials looking at prevention by amyloid removal both before cognitive symptoms start and during the MCI period
- Earlier failed studies lasted about 18 months
  - Peter wonders if it’s like taking patients who have the most aggressive form of cardiovascular disease and giving them lipid lowering therapy for 18 months
  - Did they need to do the study earlier in the disease process and for a longer period of time?
  - Amanda says the time period doesn’t matter as much for Alzheimer’s because patients will get worse, but the earlier in disease process is key
  - 18 months is standard in Alzheimer’s trials
- Drug development is expensive
  - takes 10 to 15 years and a billion dollars (today maybe around 1.4B) for any one drug to get from development and discovery to FDA approval
    - there’s no question that the United States subsidizes the rest of the world in drug pricing
    - in exchange for having the best drugs available first, we pay a premium for the development of the drug
  - for every one drug that makes it all the way through, there’s literally 4,000 or 5,000 that don’t
- For Alzheimer’s, 18 months is a spot where progress would be very significant, staying stable would be an improvement, and getting worse means the drug is not working
- Peter points out that in oncology, there are approved drugs that add very little
  - extend median survival by two months without extending overall survival
  - but cost a hundred thousand dollars
- Peter notes that patient selection and study design are crucial

**The FOURIER and ODYSSEY trials (1:29:45)**

- Peter says the two major trials used to test the proprotein convertase subtilisin/kexin type 9 ([PCSK9](https://en.wikipedia.org/wiki/PCSK9#PCSK9_Inhibitor_Drugs)) inhibitors were “very elegant and very complementary”
- [FOURIER trial](https://www.ncbi.nlm.nih.gov/pubmed/28304224)
  - patients typically had LDL cholesterol < 70 mg/dL (~5th percentile)
  - taking the maximum dose of a [statin](https://en.wikipedia.org/wiki/Statin)
  - added a PCSK9 inhibitor
  - after 2-3 years saw improvement
  - cardiovascular trial outcomes are usually major adverse cardiac events (MACE) – heart attack, stroke, revascularization, and death
  - the point is not the biomarker (how much it lowers cholesterol) but whether it prevents a bad outcome
- [ODYSSEY trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1801174)
  - Patients equally at risk as FOURIER trial but not “heavily statinized”
  - Looked at same outcomes, including all-cause mortality

**Challenges in Alzheimer’s trials**

- Peter struggles to understand the equivalent end points in Alzheimer’s studies
  - Very unlike a heart attack, things like cognitive improvement seem subjective and hard to measure
  - it’s a harder disease to measure definitive outcomes for
- How do you think about patient selection for an Alzheimer’s trial?
  - We know it’s too late by the time a patient has significant dementia
- Amanda thinks there may be opportunity for patients with MCI as well as mild dementia to benefit from disease-modifying therapies
  - But prevention trials are key because you want to stop decline it before it starts

- Based on PET, the outcomes for anti-amyloid drugs are excellent
  - PET-measured amyloid status goes from positive to negative
  - But if the patients aren’t any better or if they’re continuing to get worse, it doesn’t matter

## The promise of monoclonal antibody treatments for Alzheimer’s disease [1:34:15]

**Monoclonal antibodies to amyloid**

- In the initial [Solanezumab](https://en.wikipedia.org/wiki/Solanezumab) [trial](https://pubmed.ncbi.nlm.nih.gov/29365294/), the group with mild disease kept progressing
  - they already had enough neurodegeneration and other brain pathology
  - whether the amyloid was there any more no longer mattered
- The FDA is considering data for [Aducanumab](https://en.wikipedia.org/wiki/Aducanumab) right now
- Eli Lilly [study](https://www.nejm.org/doi/full/10.1056/NEJMoa2100708) on [Donanemab](https://en.wikipedia.org/wiki/Donanemab)
  - Was presented at a recent Alzheimer’s Disease / Parkinson’s Disease ([AD/PD](https://adpd.kenes.com/)) meeting
  - it met endpoints on almost all of the primary and secondary outcome measures that had been set
- So although prevention is key, MCI group cannot be ruled out
- Goal is to develop a routine amyloid test everyone would have and preventive measures to avoid cognitive decline
  - hopefully we can model this after a disease where we’ve had unbelievable success like cardiovascular disease, rather than a disease like cancer, which we have to wait until you develop to treat
  - we are on the cusp of “liquid biopsies” (which Peter will discuss on the podcast in a few months)

**Aducanumab studies: EMERGE, ENGAGE, and EMBARK**

- Aducanumab is one of the most promising monoclonal antibodies
  - manufactured by Biogen
  - made it to phase III
- Two similar parallel studies, [EMERGE](https://clinicaltrials.gov/ct2/show/NCT02484547) and [ENGAGE](https://clinicaltrials.gov/ct2/show/NCT02477800)
  - study had pre-specified endpoints as it should have (“you got to call your shot before you go to bat”)
  - end point was cognitive, not imaging
- Now running [EMBARK](https://clinicaltrials.gov/ct2/show/NCT04241068), a follow-up for the patients that had previously been in EMERGE and ENGAGE
- futility analysis
  - company analyzes data to see if it’s worthwhile to continue spending their resources on the drug or to abandon it
  - they were not meeting their primary endpoints
  - After looking at a cohort of people who had dose escalated in the interim, they realized that the people in the high-dose group actually were meeting the endpoints
  - in a very unusual turn of events, they [said they were wrong](https://www.thelancet.com/journals/laneur/article/PIIS1474-4422(19)30480-6/fulltext) and the drug was helping
  - they ended up going back and putting people back in the study who had previously been on it in the new EMBARK study
- Data has been submitted to the FDA for approval
- Peter thinks the highest dose given in these studies was around 10 mg/kg
- Was also a stratification for ApoE genotype
  - Peter didn’t understand this because they were giving a lower dose to the ApoE e4 carriers
  - Amanda says one of the reasons that they give the ApoE e4 carriers a lower dose is because of the risk of [amyloid-related imaging abnormalities](https://en.wikipedia.org/wiki/Amyloid-related_imaging_abnormalities) (ARIA)
    - with amyloid drugs, often will see changes in MRI, either [edema](https://en.wikipedia.org/wiki/Edema) (ARIA-E) or micro [hemorrhages](https://en.wikipedia.org/wiki/Bleeding) (ARIA-H)
    - in previous studies there was a distinct difference between the risk of ARIA between e4 carriers vs non-carriers
    - Didn’t happen in this study, so amended the protocol for e4 subjects to go to 10 mg/kg
- On June 7, 2021, the FDA is expected to announce whether it will approve the drug or not
  - There have been conflicting advisory board reports, so it’s unclear what’s going to happen
  - Patient and family groups, noting the lack of any new treatment in 20 years, say it’s better for nothing and are pushing for approval
  - If it’s not approved, theoretically Biogen could run another phase III trial with a better protocol

## How we should measure outcomes in dementia trials and define “healthy aging” [1:42:30]

- Another issue is that the primary outcome measures for these trials aren’t very good
  - Some use the clinical dementia rating (CDR), which has a subjective component based on patient and caretaker interviews
  - Prone to bias from, for example, a highly stressed or depressed caregiver who sees everything worse than it is and over-reports symptoms
  - CDR looks at memory, judgment, hobbies, etc., which are reported by the patient and caregiver, whose responses are compared
  - There is also an “intangible part” where a scorer might say it “feels like” a 1.0 or a 0.5 – this is not an objective measure like your LDL level
- Peter suggests that because subjective evaluation is so important, we at least need biomarkers that are so predictive of clinical outcome that you can rely on them in combination with a clinical evaluation
- You can’t do a long enough study to get hard outcomes
- Two big challenges in drug development for Alzheimer’s disease
  - technical challenge of developing a good enough drug
  - operational challenge of how you actually study it
- Can use different outcome measures like the [The Alzheimer’s Disease Assessment Scale–Cognitive Subscale](https://en.wikipedia.org/wiki/ADAS-Cog) (ADAS-Cog)
  - cognitive composite score have been used in other trials
  - Some critics accused them of cherry picking, but the outcomes were predefined
  - the cognitive composite is based on years and thousands of patients’ worth of data showing what specific cognitive tests may be better predictors
  - The ADAS-Cog is very ingrained in this field and although it certainly has a lot of utility, it also has limitations
  - Finding better objective cognitive primary outcome measures in addition to biomarkers certainly will be useful for drugs moving forward

**How should we define “healthy aging”? (1:47:30)**

- The fact is that many of us are going to die with some form of cognitive impairment, even if it is not dementia

> “At the end of the day, it really has to do with how people see themselves, how people interact with the world, what kind of relationships they have, how able they are to let go of things that they’ve lost and how able they are to focus on the positive.” —Amanda Smith

- People struggle the most when they spent too much time thinking about the future and can’t enjoy the present moment
  - Two former marathon runners with Parkinson’s disease will fare differently if one focuses on how they can no longer run and the other on how they can still enjoy the sunset and try to make the most of each day (“those are the people that I think age successfully, even in the face of having illness”)
- Peter describes health span / quality of life as having 3 three broad dimensions:
  - Physical
  - Cognitive
  - Emotional
  - The first two will inevitably decline with age; we can just try to minimize them
    - A few exceptions like [Charlie Munger](https://en.wikipedia.org/wiki/Charlie_Munger)
    - But the emotional piece is not age-dependent
- Should we be tying our identity to our emotional health, which does not have to decline with age, rather than to our physical or cognitive abilities?
  - Peter thinks emotional health is most closely tied to the quality of our relationships
  - Amanda agrees that “feeling loved, feeling that there are people you can rely on, feeling that there are people who can share experiences with you” is key
- Social isolation is a big factor in quality of life

> “I definitely see the people that struggle the most are the ones that are constantly comparing themselves to their former selves. I used to be able to do this. I used to be able to do that. I used to… If I did that, I would just be hiding under my covers.” —Amanda Smith

## How understanding dementia can reshape our life philosophy [1:53:45]

- For most people, there is a far greater decline between ages 70-90 than between ages 30-50; decline is not a linear progression
- Peter says he’s “undergoing an asset reallocation” to realign his identity with things that won’t inevitably decline
- Amanda says it’s also important to do things when you still have the chance
- Aging well is also impacted by how much regret we live with

> “And so very often I see people who come in and have worked really hard throughout their lives and put off this and put off that. And we’re just about to retire and do XYZ. And then now, well now I have this devastating disease.” —Amanda Smith

- She tells them they can still do those things, but perhaps differently
  - Amanda always wanted a house on the beach where she could see the horizon from her bed
  - “But that’s something I learned from my patients. Don’t wait, don’t wait until I retire to get that beach condo because I might not be able to use it. I’m living now. So do it now”
  - e.g., still take the cruise, but have your loved one wear a tag with your cell phone number
- Peter thinks prevention is the best medicine for chronic disease, but some people will still need treatment
- Exercise is also critically important
  - A “growing body of data shows that even in people who have cognitive impairment or have full-blown dementia, aerobic activity can actually improve scores on cognitive testing”
  - intervention trials in both MCI and AD, the [SilverSneakers Program](https://tools.silversneakers.com/), and [Laura Baker](https://school.wakehealth.edu/Faculty/B/Laura-D-Baker) at Wake Forest all show the benefits of exercise even if you already have dementia

§

## Selected Links / Related Material

**Study on correlation of amyloid-β as measured by PET scan and post mortem brain biopsy**: [Use of florbetapir-PET for imaging beta-amyloid pathology](https://pubmed.ncbi.nlm.nih.gov/21245183/) | *JAMA* (Clark et al. 2011) |  [28:00]

**Peter’s podcast with Richard Isaacson**: [#18 – Richard Isaacson, M.D.: Alzheimer’s prevention](https://peterattiamd.com/richardisaacson/) | *The Drive*, Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/archive/)) (1/28/2019) | [32:45]

**Richard Isaacson answering questions about Alzheimer’s drugs**: [Q&A on Alzheimer’s disease drug therapy with Dr. Richard Isaacson](https://peterattiamd.com/qa-with-dr-richard-isaacson-on-aducanumab-alzheimers-disease-drug-therapy/) | *The Drive*, Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/archive/)) (11/22/2020) | [32:45]

**Dennis Dickson’s paper showing that mixed pathology in common in dementia patients**: [Relative frequencies of Alzheimer disease, Lewy body, vascular and frontotemporal dementia, and hippocampal sclerosis in the State of Florida Brain Bank](https://pubmed.ncbi.nlm.nih.gov/12468894/) | *Alzheimer Disease and Associated Disorders* (Barker et al. 2002) | [35:30]

**Peter’s podcast interview with Francisco Gonzalez-Lima**: [#38 – Francisco Gonzalez-Lima, Ph.D.: Advancing Alzheimer’s disease treatment and prevention – is AD actually a vascular and metabolic disease?](https://peterattiamd.com/franciscogonzalezlima/) | *The Drive*, Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/archive/)) (1/28/2019) | [36:15]

**Summary of data suggesting an association between plasma ApoE level and the risk of dementia**: [Plasma levels of apolipoprotein E, APOE genotype and risk of dementia and ischemic heart disease: A review](https://www.atherosclerosis-journal.com/article/S0021-9150(16)31440-X/fulltext) | *Atherosclerosis* (Rasmussen 2016) | [43:15]

**Article summarizing the relationship between ApoE genes and Alzheimer’s risk**: [Genetic testing: Should I get tested for Alzheimer’s risk?](https://theconversation.com/genetic-testing-should-i-get-tested-for-alzheimers-risk-97065) Troy Rohn, *The Conversation* [44:00]

**Study showing that donepezil delayed nursing home placement**: [Donepezil Is Associated with Delayed Nursing Home Placement in Patients with Alzheimer’s Disease](https://agsjournals.onlinelibrary.wiley.com/doi/abs/10.1046/j.1365-2389.2003.51306.x) | *Journal of the American Geriatrics Society* (Geldmacher et al. 2003) | [59:00]

**Peter’s podcast with Lauren Miller Rogan and Richard Isaacson**: [#138 – Lauren Miller Rogen and Richard Isaacson, M.D.: Alzheimer’s disease prevention—patient and doctor perspectives](https://peterattiamd.com/laurenmillerrogen-richardisaacson/) | *The Drive*, Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/archive/)) (11/23/2020) | [1:08:30]

**FOURIER trial**: [Evolocumab and Clinical Outcomes in Patients with Cardiovascular Disease](https://www.ncbi.nlm.nih.gov/pubmed/28304224) | *New England Journal of Medicine* (Sabatine et al. 2017) | [1:29:45, 1:30:00]

**ODYSSEY trial**: [Alirocumab and Cardiovascular Outcomes after Acute Coronary Syndrome](https://www.nejm.org/doi/full/10.1056/NEJMoa1801174) | *New England Journal of Medicine* (Schwartz et al. 2018) | [1:29:45 1:30:45]

**Early solanezumab trial with disappointing results**: [Trial of Solanezumab for Mild Dementia Due to Alzheimer’s Disease](https://pubmed.ncbi.nlm.nih.gov/29365294/) | *New England Journal of Medicine* (Honig et al. 2018) | [1:34:15]

**Eli Lilly study on Donanemab**: [Donanemab in Early Alzheimer’s Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa2100708) | *New England Journal of Medicine* (Mintun et al. 2021) | [1:34:45]

**EMERGE trial**: [221AD302 Phase 3 Study of Aducanumab (BIIB037) in Early Alzheimer’s Disease (EMERGE)](https://clinicaltrials.gov/ct2/show/NCT02484547) | *clinicaltrials.gov* #NCT02484547 (2015-19) | [1:36:30]

**ENGAGE trial**:  [221AD301 Phase 3 Study of Aducanumab (BIIB037) in Early Alzheimer’s Disease (ENGAGE)](https://clinicaltrials.gov/ct2/show/NCT02477800) | *clinicaltrials.gov* #NCT02477800 (2015-19) | [1:36:30]

**EMBARK trial**: [A Study to Evaluate Safety and Tolerability of Aducanumab in Participants With Alzheimer’s Disease Who Had Previously Participated in the Aducanumab Studies 221AD103, 221AD301, 221AD302 and 221AD205](https://clinicaltrials.gov/ct2/show/NCT04241068) | *clinicaltrials.gov* #NCT04241068 (2020-) | [1:38:00]

**Article about Biogen’s reversed futility analysis of data on aducanumab**: [A resurrection of aducanumab for Alzheimer’s disease](https://www.thelancet.com/journals/laneur/article/PIIS1474-4422(19)30480-6/fulltext) | *The Lancet* (Schnieder 2019) | [1:38:15]

**Article about the EMBARK study**: [EMBARK Trial to Again Test Safety, Efficacy of Aducanumab](https://alzheimersnewstoday.com/2021/04/23/aanam-embark-trial-to-again-test-safety-efficacy-of-aducanumab/) | Marisa Wexler, *Alzheimer’s News Today* (April 23, 2021) | [1:38:15]

§

# DRUGS MENTIONED

- [Donepezil](https://en.wikipedia.org/wiki/Donepezil) (Aricept) [7:30, 1:17:15]
- [Florbetapir](https://en.wikipedia.org/wiki/Florbetapir_(18F)) (Amyvid) [28:00]
- [Serotonin reuptake inhibitors](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) (SSRIs) [a class of antidepressant drugs Amanda frequently uses with her patients; examples include sertraline (Zoloft), citalopram (Celexa), and paroxetine (Paxil)] [1:01:00]
- [Benzodiazepines](https://en.wikipedia.org/wiki/Benzodiazepine) (a class of sedative drugs that Amanda avoids with her patients) [1:01:30]
  - [Alprazolam](https://en.wikipedia.org/wiki/Alprazolam) (Xanax)
  - [Lorazepam](https://en.wikipedia.org/wiki/Lorazepam) (Ativan)
  - [Diazepam](https://en.wikipedia.org/wiki/Diazepam) (Valium)
- [Cholinesterase inhibitors](https://en.wikipedia.org/wiki/Cholinesterase_inhibitor) (a class of drugs that prevent the breakdown of neurotransmitters) [1:17:15]
  - [Donepezil](https://en.wikipedia.org/wiki/Donepezil) (Aricept) (*see above*)
  - [Galantamine](https://en.wikipedia.org/wiki/Galantamine) (Razadyne)
  - [Rivastigmine](https://en.wikipedia.org/wiki/Rivastigmine) (Exelon)

- [*N*-Methyl-D-aspartate (NMDA) receptor antagonists](https://en.wikipedia.org/wiki/NMDA_receptor_antagonist) (a class of anesthetic drugs sometimes used to treat dementia; the example mentioned is [memantine](https://en.wikipedia.org/wiki/Memantine)) [1:17:15]
- [Monoclonal antibodies](https://en.wikipedia.org/wiki/Monoclonal_antibody_therapy) to amyloid-β (a class of immunotherapeutic drugs specifically targeting amyloid-β): [1:18:15, 1:34:15]
  - [Solanezumab](https://en.wikipedia.org/wiki/Solanezumab) [1:34:15]
  - [Donanemab](https://en.wikipedia.org/wiki/Donanemab) [1:34:45]
  - [Aducanumab](https://en.wikipedia.org/wiki/Aducanumab) [1:34:45, 1:36:15]
- [Gamma secretase](https://en.wikipedia.org/wiki/Gamma_secretase) inhibitors (a class of drugs that inhibit an enzyme that cleaves amyloid-β; side effects prevent use for Alzheimer’s patients) [1:20:30]
- [Beta-site amyloid precursor protein cleaving enzyme](https://en.wikipedia.org/wiki/Beta-secretase_1) (BACE) inhibitors (a class of drugs that inhibit an enzyme that cleaves amyloid-β; side effects prevent use for Alzheimer’s patients) [1:20:30]
- [Proprotein convertase subtilisin/kexin type 9](https://en.wikipedia.org/wiki/PCSK9#PCSK9_Inhibitor_Drugs) (PCSK9) inhibitors (a class of cholesterol-lowering drugs used to prevent cardiovascular disease) [1:30:00]
- [Statins](https://en.wikipedia.org/wiki/Statin) (commonly used cholesterol-lowering drugs) [1:30:00]

§

## People Mentioned

- [Richard Isaacson](https://weillcornell.org/risaacson) [3:30, 32:45, 38:00, 57:45, 1:08:30]
- [Dennis Dickson](https://www.mayo.edu/research/faculty/dickson-dennis-w-m-d/bio-00027499) [35:30]
- [Francisco Gonzalez-Lima](https://liberalarts.utexas.edu/psychology/faculty/fg) [36:15]
- [Jack De La Torre](https://alliedacademies.com/profile/jack%20de%20la%20torre) [36:15]
- [Eric Pfeiffer](https://marquistopdoctors.com/2018/12/26/eric-pfeiffer/) [54:45]
- [Lauren Miller Rogen](https://en.wikipedia.org/wiki/Lauren_Miller_Rogen) [1:08:30]
- [Charlie Munger](https://en.wikipedia.org/wiki/Charlie_Munger) [1:50:45]
- [Laura Baker](https://school.wakehealth.edu/Faculty/B/Laura-D-Baker) [1:58:00]

§

![](https://peterattiamd.com/wp-content/uploads/2021/06/bio-image-amandasmith.jpeg)

##### Amanda Smith, M.D.

Dr. Amanda Grant Smith is the Director of Clinical Research at the USF Health Byrd Alzheimer’s Institute in Tampa, FL, and a professor at the University of South Florida Health Morsani College of Medicine. Dr. Smith is on the University of South Florida Institutional Review Board and is a diplomate of the American Board of Psychiatry and Neurology, with subspecialty certification in geriatric psychiatry. Her work focuses on the diagnosis and treatment of memory disorders, caregiver education and support, and clinical research in Alzheimer’s disease. She did her internship, residency in psychiatry, and fellowship in geriatric psychiatry at the University of South Florida College of Medicine*.* She received her undergraduate degree from Emory University and her medical degree from Jefferson Medical College.

**Academic website**: https://health.usf.edu/medicine/psychiatry/faculty/asmith2

**Twitter**: [@AlzDoctor](https://twitter.com/alzdoctor?lang=en)