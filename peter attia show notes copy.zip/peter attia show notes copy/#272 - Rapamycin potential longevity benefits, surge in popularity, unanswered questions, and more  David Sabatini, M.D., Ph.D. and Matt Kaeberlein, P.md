# #272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.

**Source:** [https://peterattiamd.com/davidsabatini-mattkaeberlein/](https://peterattiamd.com/davidsabatini-mattkaeberlein/)

---

In this episode of The Drive, Peter welcomes guests David Sabatini and Matt Kaeberlein, two world-leading experts on rapamycin and mTOR. David and Matt begin by telling the fascinating story of the discovery of rapamycin and its brief history as a pharmacological agent in humans. They then unravel the function of mTOR, a central regulator of numerous biological processes, and they discuss the pathways through which rapamycin exerts its potential benefits on lifespan. They touch upon initial studies that suggested rapamycin may have geroprotective effects and the ongoing research that continues to shed light on this unique molecule. Furthermore, they discuss the elusive details surrounding the frequency and dosing of rapamycin use in humans, and Peter emphasizes his reservations about indiscriminately prescribing rapamycin as a longevity drug for patients.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/davidsabatini-mattkaeberlein/the_Drive_public.png)

Play

#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.

#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.

1x15s30s

0:002:50:40

## We discuss:

- David and Matt’s expertise in mTOR and rapamycin [3:00];
- The discovery of rapamycin and its first use in humans as an immunosuppressant [13:15];
- The emergence of rapamycin as a molecule with the potential to prolong lifespan [19:30];
- The groundbreaking rapamycin study on mouse lifespan extension and the open questions about the timing and frequency of dosing [26:00];
- Explaining mTOR and the biology behind rapamycin’s effects [35:30];
- Differences in how rapamycin inhibits mTOR complex 1 (MTORC1) versus mTOR complex 2 (MTORC2) [45:15];
- Reconciling the biochemical mechanism of rapamycin with its longevity benefit [49:15];
- Important discoveries about the interplay of amino acids (leucine in particular) and mTOR [54:15];
- Reconciling rapamycin-mediated mTOR inhibition with mTOR’s significance in building and maintaining muscle [1:01:30];
- Unanswered questions around the tissue specificity of rapamycin [1:08:30];
- What we know about rapamycin’s ability to cross the blood-brain barrier and its potential impacts on brain health and neurodegeneration [1:13:45];
- Rapamycin may act as an immune modulator in addition to immunosuppressive effects [1:21:30];
- Might rapamycin induce changes in T cell methylation patterns, potentially reversing biological aging? [1:34:15];
- Side effects of rapamycin and impact on mental health: fascinating results of Matt’s survey of people who use rapamycin off-label [1:42:00];
- The impact of taking rapamycin in people who contracted COVID-19: more insights from Matt’s survey [1:51:15];
- What David would like to study with mTOR inhibitors [1:54:45];
- Joan Mannick’s studies of RTB101 and other ATP-competitive inhibitors of mTOR [2:00:30];
- The impact of mTOR inhibition on autophagy and inflammation, and a discussion of biomarkers [2:10:00];
- The Dog Aging Project: what we’ve learned and what’s to come from testing rapamycin in companion dogs [2:17:30];
- Preliminary results of primate studies with rapamycin [2:24:45];
- Dosing of rapamycin [2:27:45];
- The effect of rapamycin on fertility [2:36:45];
- The outlook for future research of rapamycin and the development of rapalogs [2:39:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Guests this week are David Sabatini and Matt Kaeberlein
- Matt has been a former guest on three occasions (episode [#222](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/), [#175](https://peterattiamd.com/mattkaeberlein2/), and [#10](https://peterattiamd.com/mattkaeberlein/))
- David was on the podcast way back on episode [#9](https://peterattiamd.com/davidsabatini/)
- Not only are they two of the original guests on the podcast from our 12-part pilot experiment in the summer of 2018, they are also two of the most knowledgeable people on this planet on the topic of conversation today: Rapamycin and mTOR
- We cover the discovery of rapamycin
- We look at how mTOR, which sits at the epicenter of our existence, works and does its job
- We talk about the pathways of rapamycin that are believed to drive its impact and improvement on lifespan
- We discuss the initial studies that showed rapamycin may be geroprotective and also what studies have come out since (or are currently in progress) which provide more information and clarity around this very important question
- Finally, we discuss what is known and unknown about the potential frequency and dosing of rapamycin in humans
- Peter adds, “*I’m very excited to release this podcast because I don’t think there is a question I get asked more about from my patients than this topic*.”
  - Understandably because his patients know that he takes rapamycin, and have been doing so for about five years
- You’ll see from this discussion why Peter has reservations about just blindly putting people on rapamycin
  - And why Peter’s practice is not just a “rapamycin mill”
- Peter hopes this podcast is not just helpful for his patients, but everyone listening
  - Everyone who is interested in this question

## David and Matt’s expertise in mTOR and rapamycin [3:00]

- We’re going to try something a little different in this podcast: A three-way discussion
- Matt has been on the podcast a number of times (episode [#222](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/), [#175](https://peterattiamd.com/mattkaeberlein2/), and [#10](https://peterattiamd.com/mattkaeberlein/)), and David has also been on the podcast (episode [#9](https://peterattiamd.com/davidsabatini/))
- This topic is going to be new to many people, though they will have heard about it a lot
  - They may have read a chapter about it in [Peter’s book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1692629170&sr=8-1), which both Matt and David graciously helped fact check
- We’re going to pretend that someone coming into this discussion doesn’t really know anything about [rapamycin](https://en.wikipedia.org/wiki/Sirolimus), doesn’t really know what [mTOR](https://en.wikipedia.org/wiki/MTOR) is
- Peter hopes that by the end of this discussion, we will have provided people with arguably the most comprehensive, quasi concise explanation of all you need to know about these topics
- Peter begins by asking David and Matt to do something he doesn’t often ask guest to do, “*Toot your own horns a little bit about what it is that allows me to say you are each among the two most knowledgeable people on this topic.*”

**David has worked with rapamycin his entire scientific career**

- Going back 30+ years to his PhD and he’s still the leading authority on it
- When David was a student with [Sol Snyder](https://neuroscience.jhu.edu/research/faculty/83) at Johns Hopkins he became fascinated with rapamycin and as he tried to figure out how it works that led to the purification of the protein we now call mTOR
- [Michael Hall](https://www.biozentrum.unibas.ch/research/research-groups/research-groups-a-z/overview/unit/research-group-michael-n-hall) had identified a yeast version of this that Matt was one of the early workers on this called TORC1
- And since that time, we’ve done a lot of biochemistry try to figure out what this protein does

***What we conclude in a big picture point of view is that mTOR is the protein that links the availability of nutrients in our environment to whether we’re in a catabolic or an anabolic state***

- **Anabolism** is growth, and **catabolism** is the breakdown of material
- This function accounts for why mTOR has so many different roles
- If you think about our evolutionary history, there’s almost nothing in our physiology that shouldn’t be controlled by the availability of nutrients
  - It’s such a central thing in our lives
  - We tend to forget that now because we’re in a overeating stage
- Since that time, what we’ve done is figured out a lot of the pieces of this pathway, including what we call two protein complexes: [mTORC1](https://en.wikipedia.org/wiki/MTORC1) and [mTORC2](https://en.wikipedia.org/wiki/MTORC2)
- The work that David is the most satisfied with is how it senses nutrients and the nutrient sensors themselves (which are the actual proteins that bind the small molecules) tell mTORC1 in particular that it detects nutrients

**Matt has been on the podcast a number of times to talk about mTOR, rapamycin, protein, and nutrition**

- Matt started working on mTOR in yeast by accident
- He was really interested in understanding the genetics that control longevity
- They did an unbiased [search](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(15)00465-9?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1550413115004659%3Fshowall%3Dtrue#secsectitle0075) for new genes that would affect lifespan and happened to find mTOR
- After that discovery, Matt immediately went and looked up everything he could learn about mTOR and found out about the drug rapamycin that’s an inhibitor of mTOR
- Then they found that they could also increase lifespan with rapamycin (at this point, they were working in yeast)
- This drug appeared to affect the biological aging process, not only in yeast, but also across the animal kingdom
  - We now know even in mammals like mice and potentially in larger mammals like dogs and people

***With that knowledge, Matt got very interested in trying to understand what the mechanisms are for how rapamycin was affecting the biological aging process***

- He’s studied this in yeast and worms and fruit flies and mice, a little bit in pet dogs (which we may talk about)
- Through all of that, the one thing that has kept him excited about rapamycin as a potential longevity therapeutic is that it always works
- Without question, it is the most robust and reproducible drug (at least from preclinical studies) that we know about today, for impacting not only longevity, but to the extent that we can measure various metrics of healthspan in complex animals
- Rapamycin also seems to positively impact pretty much every aspect of healthspan that we measure
  - This is why he has continued to study it
- Probably what Matt is best known for is pushing forward a [veterinary clinical trial of rapamycin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8940555/) to really start to answer the question of all the things we’ve learned about rapamycin in the context of aging and longevity in the laboratory, how much of that will translate into the real world?
  - This trial of rapamycin is being carried out in pet dogs right now
  - He’s got some preliminary data, but it’s too early to be able to say with any level of confidence that rapamycin is going to positively impact the aging process in dogs
  - But we’ve already learned a lot about safety and maybe some hints about efficacy
- Full disclosure: A number of Peter’s patients are funders of a study that we will talk about more later

**On the continuum of understanding rapamycin and mTOR**

- David is closer to what we would call the “bench” side of things
- Matt is closer to the bedside
- People have heard this term “bench to bedside” (ie. translational research)
- We aren’t quite at the bedside of humans yet, but really more the bedside of more complex mammals
- David adds, “*Matt has been very careful… he’s taken a very scientific approach… I pretty much put Matt in one of the most respected categories of aging researchers for that reason.*”
  - Peter agrees that the field owes a lot of its credibility to the way Matt has approached this with scientific rigor (as opposed to commercialization)

**Matt and David’s research on mTOR and rapamycin**

- Much of Matt’s research on mTOR and rapamycin has been what people would typically consider preclinical or basic research and different from David’s approach
- The approach that David has taken throughout his career is quite complimentary in many ways to the approach that Matt taken, in that David has really been the pioneer and the leader in understanding detailed mechanistic aspects of the whole mTOR signaling network

***It’s useful for people to appreciate that this is an extremely complex network of biological interactions***

- David’s lab has he leading role at fleshing out from a very detailed biochemical and mechanistic perspective, how that network is working
- This has laid the foundation for people like Matt and many others who have then taken that knowledge and tried to start to move it into more applied contexts and clinical applications
- Peter adds that the field owes a lot of its credibility to the way Matt has approached this with scientific rigor being the highest priority
  - As opposed to commercialization
  - He notes there are a lot of other molecules where there is some interesting science behind it, but it seems to have almost been corrupted by a commercialization route, and we may never know if these things work or don’t work
    - They’re also very difficult to take seriously
  - Everybody should be grateful for the way this field has gone

## The discovery of rapamycin and its first use in humans as an immunosuppressant [13:15]

> “*There’s a very unique phenomenon here, which is the drug was discovered before the target and the target is named after the drug in response to that*.”‒ Peter Attia

- This story has been told before on this podcast, and there’s a chapter in Peter’s [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1694099064&sr=8-1) about the discovery of rapamycin
- David and Peter got to visit this special place where the bacteria that produced this drug was discovered (and they have plans to go back)

**The story of the discovery of rapamycin**

- There were (and are attempts) by pharmaceutical companies to collect soil samples and other biological containing samples throughout the world
- [Wyeth-Ayerst](https://en.wikipedia.org/wiki/Wyeth) did come into possession of a soil sample from [Easter Island](https://en.wikipedia.org/wiki/Easter_Island) (otherwise known as Rapa Nui) in the South Pacific
  - At one point, it claimed to be the most remote island of the world
  - This occurred maybe in the ‘60s, and [Suren](https://journals.lww.com/indianjcancer/Fulltext/2017/54040/Surendra_Nath_Sehgal__A_pioneer_in_rapamycin.24.aspx) dug into it in ‘71/’72
- In Canada, people eventually isolated bacteria from this soil sample, a bacteria called [*Streptomyces hygroscopicus*](https://en.wikipedia.org/wiki/Streptomyces_hygroscopicus)
- And from that bacteria, rapamycin was eventually isolated, and in deference to Rapa Nui was named rapamycin
  - Ironically, it turns out when people have looked for this bacteria throughout the world, it has been found in many other places.
- These molecules, these bacterial products, you really would call an antibiotic
- Some of the earlier assays using this bacteria were immunological assays, even before some of the antifungal assays
  - That led to many decades of pursuing it as an immunosuppressant
  - In the meantime, it was also found to have antifungal activity, and that’s where some of the genetics of rapamycin and some of the targets were first identified because of the ease of genetics
- [Suren Seghal](https://pubmed.ncbi.nlm.nih.gov/30082562/) championed rapamycin
- David’s advisor, Sol Snyder, wrote to Suren and asked for some
  - He sent them many grams, which David later calculated at a street value of many hundreds of thousands of dollars
  - He included a nice note wishing them luck and the entire bibliography of rapamycin at the time
    - A thin book including his papers and a couple of abstracts
- The clinical path took way too long, and that even impacted some of its utility because the patents expired before you could really capture some of the value of it
  - So we’re talking about something now that’s in the 50-year range plus
- David points out a question we could ask ourselves, “*Is rapamycin as good as it gets?*”
  - There are derivatives of rapamycin, but even in this pathway, which as Matt says is exceedingly complicated, are there other targets that we should be pursuing that may actually have equal or better impacts on the aging process?

***The clinical path not only took too long, but maybe negatively impacted the development of rapamycin and other mTOR inhibitors for other uses because it was developed clinically as an organ transplant immunosuppressant (that’s how it was first approved)***

- It was used in a dosing protocol and a patient context where there are lots of side effects

***We’re still learning what the side effect profile actually looks like for rapamycin at lower doses in patients who are not immunocompromised and haven’t had an organ transplant***

- Matt wonders whether the history of rapamycin and the rapidity at which it will be eventually tested for other endpoints in clinical trials where it may have benefits has been negatively impacted and slowed down because of the reputation that the drug got as a **dangerous drug** based on the way it was developed clinically

**Peter gives a sense of the timeline**

- Suren Seghal published the chemical composition of rapamycin in 1971, 1972
- The FDA approval for rapamycin in humans was 1999
- There was an enormous gap of time between when the chemical discovery was made, filing [IND](https://www.fda.gov/drugs/types-applications/investigational-new-drug-ind-application), and working all the way through
- As a former surgical resident, Peter was in his surgical residency taking care of transplant patients when rapamycin was in full use
  - They were giving rapamycin out constantly
  - It was a drug that was given 2-3 mg a day, every day
  - But patients were also getting three other drugs which were very toxic to shut down the immune system: [prednisone](https://en.wikipedia.org/wiki/Prednisone), [CellCept](https://en.wikipedia.org/wiki/Mycophenolic_acid), [MMF](https://en.wikipedia.org/wiki/Mycophenolic_acid)
- Peter recalls the reason David got involved in rapamycin was because of [FK506](https://en.wikipedia.org/wiki/Tacrolimus) (a cousin of rapamycin)
  - The lab was using rapa as a control that didn’t have the [calcineurin](https://en.wikipedia.org/wiki/Calcineurin) properties of FK506
- For the better part of a decade (1999 to 2009), the only experience the scientific world had with this is in the context of transplant patients
  - You’re going to see a lot of side effects, but how do you know they’re from rapamycin and how do you know that they would be the same elsewhere?

## The emergence of rapamycin as a molecule with the potential to prolong lifespan [19:30]

- At this time David had already established his own laboratory
  - He was working on rapamycin, working on mTOR probably more so than anything else, and trying to understand the nutrient sensing pathways around it

*How aware were you of the* [*ITP (Interventions Testing Program)*](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) *in the buildup to that first study in 2009?*

- David was not aware of it
- But once he started making that connection of rapamycin to nutrients (which many groups did) it was already appreciated for many, many decades before that, things like caloric restriction had an impact on lifespan
- His group thought of the idea that rapamycin could have an impact on lifespan
- This just tells you how science works
- They actually tried dosing [*C. elegans*](https://en.wikipedia.org/wiki/Caenorhabditis_elegans) (worms) or rapamycin, naively not realizing that their cuticle would not allow the way that they were giving rapamycin to have an impact
- Then there were genetics that came out in worms and Matt’s work, and a lot of other people really pioneered the aging space, not David’s group at all
- David remembers when the [*Nature* paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) came out, reporting rapamycin as one of the bigger hits in the ITP study
  - This connected Matt’s work in yeast another organisms with a mammal, and now we take that for granted because it does impact all those different animals and single cell organisms

> “*The idea that we had a molecule that spanned from a yeast to a mouse was dramatic. That was a huge, huge impact.*”‒ David Sabatini

**Are there any other molecules that have done what you just said, David?**

- Peter adds, “*The evolutionary gap from yeast to flies, worms, mammals is a billion years.*”
- David doesn’t know if there are, but certainly dietary restriction (in one form or another)
  - This was done before rapamycin, before the discovery of TOR
- People have shown the impact of **dietary restriction** on replicative lifespan as a universal intervention, even in bacteria
- Dietary restriction was considered a universal connector, and that’s why when the nutrient connection came out, David and others started thinking along the line of rapamycin as a mimetic and potentially having this therapeutic impact

***Matt points out that rapamycin for a small molecule is probably the only pharmacological intervention that has been reproducibly shown to robustly increase lifespan and healthspan across that broad evolutionary spectrum***

- But there are other things like [𝛼-ketoglutarate](https://en.wikipedia.org/wiki/%CE%91-Ketoglutaric_acid) that extend the lifespan of yeast, worm, flies, and mice
  - It just hasn’t been tested or reproduced as much
- To add context to what David was saying about rapamycin, in addition to the drug, we also have genetic inhibition of mTOR in each of those model systems that recapitulates the longevity and healthspan benefits
  - So it’s a rock solid airtight case for mTOR and longevity

**Also on the genetic side, this is a** [**study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2279244/) **that we did with** [**Brian Kennedy**](https://medicine.nus.edu.sg/bch/faculty/brian-kennedy/) **and** [**Daniel Promislow**](https://dlmp.uw.edu/faculty/promislow)

It was probably 2007 when they asked the question, “*If we looked at all of the genes at that time that were known to affect lifespan in yeast and all of the genes that were known to affect lifespan in worms, and we simply looked at orthologs, meaning the same gene in each organism, how often is genetic control of longevity shared?*”

- It turns out, pretty often
- There is a relatively high degree of evolutionary conservation at the level of genetic control of longevity across a broad evolutionary distance
  - That’s really been the whole thesis of Matt’s career ‒ trying to understand those evolutionarily shared mechanisms of longevity
- It’s important for him to say that because there’s a lot of confusion now in the field
- A lot of new people have come into the longevity field who for whatever reason aren’t familiar with a lot of this history, and they ask questions like, “*Well, how do we know that you can use worms to understand anything about aging in a mammal?*”
- Matt explains, “*Because we already know that the genetics of longevity are conserved*.”
  - Not everything’s going to be conserved, but it has been statistically shown that there is a conservation of the biology of aging
  - And that’s fundamentally important to how we think about studying the biology of aging in the laboratory and then potentially translating those discoveries into the real world
  - That’s useful to just re-emphasize because a lot of people have lost track of that
- David agrees that the biochemical, cell biological processes that are conserved amongst all these organisms are going to be the ones that are going to impact aging
- Further, David tends to dismiss those processes which are less conserved as potentially impacting the aging process

> “*I 100% agree to you that whatever is the fundamental issue that happens in cells that leads to aging is going to be conserved, and therefore the regulators of that process (or the impactors of that process) will be conserved.*”‒ David Sabatini

## The groundbreaking rapamycin study on mouse lifespan extension and the open questions about the timing and frequency of dosing [26:00]

**The broad term of geroprotection**

- When Peter talks to patients, he says, “*There are certain strategies that we take to extend your lifespan and improve your healthspan that are very disease specific.*”
- For example, attenuation of [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) is undoubtedly going to lengthen your life if implemented for a long enough period of time, and by extension, I would argue improve the quality of your life
  - But it’s doing so through two disease processes: reduction of [atherosclerotic cardiovascular disease (ASCVD)](https://peterattiamd.com/category/diseases/heart-disease-prevention/) and cerebrovascular disease, but also through all lines of [dementia](https://peterattiamd.com/category/diseases/neurodegenerative-disease-prevention/)
- But this is NOT attacking a fundamental pillar of aging
- It’s a very disease-specific hack, and it certainly wouldn’t be applied to organisms beyond ourselves

***That doesn’t mean that we shouldn’t look at disease specific tools to modulate lifespan and healthspan, but what we’re talking about here is so much more fundamental***

- There are these nine **hallmarks of aging**, Matt says there’s [12 hallmarks of aging](https://www.cell.com/cell/pdf/S0092-8674(22)01377-0.pdf) now

**The ITP mouse study**

- Matt adds some context ‒ there was a study from the [NIA interventions testing program](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) [published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) in 2009
- It was the first study to show that rapamycin treatment in a mouse could extend lifespan, and that was important

***The other, maybe more important part of that study that often doesn’t get always talked about is that this was the first time that any intervention was convincingly shown to extend lifespan when treatment was started in middle age***

- You could argue a little bit about caloric restriction (that’s kind of a tangent)
- This is about the mouse equivalent of a 60, 65 year old person biologically
- And as David said about rapamycin, we take it for granted today that that’s possible
- But in 2009, nobody expected that experiment to work
- It was actually an accident that they ended up doing the experiment that way
  - It had to do with the fact that they couldn’t formulate the rapamycin in the mouse chow any way that was stable until the mice were already about 12 months old
  - Treatment started when mice were 20 months of age
  - It was a happy accident

> “*But in my view, I’ve said this before, I think this is one of the most important studies in the field in the past 20 years, maybe 50 years for that reason that it opened up what we now consider to be routine, which is that you can actually have an impact on longevity and some metrics of health span when you start treatment in middle age*.”‒ Matt Kaeberlein

- And as we have started as a field to think about translational application, that becomes hugely important because suddenly we’re talking about treating middle-aged dogs or middle-aged people as opposed to trying to treat puppies and teenagers
  - And that’s just much more pragmatic and practical from the perspective of actually being able to implement
- Peter reminds us of what David said at the outset: ***mTOR is the master regulator of how nutrients trickle into the system and in deciding if you’re going to be in an anabolic state or a catabolic state***
- Peter got a puppy recently, and it wouldn’t make sense to inhibit mTOR in a 3 month old puppy that is purely about anabolism right now (it’s trying to grow)
  - It would be suboptimal if we had a therapy that we believed could only work if administered early in life
- This story is remarkable and speaks to the serendipity that is often part of scientific discovery
  - Peter talked about this with [Rich Miller](http://www.richmillerlab.com/) ([episode #148](https://peterattiamd.com/richardmiller/)), how they were contemplating sacking the whole study because they couldn’t get the rapamycin formulated
- David agrees, “*It is a fascinating question though, why the starting point of delivery of rapamycin does have an impact on the life extension and healthspan extension*.”
  - The biological basis of that is something he doesn’t have a great conceptualization of
  - It’s interesting to think about how one designs experiments to try to ask that question

**Outstanding questions about rapamycin [31:00]**

*Is it safe to say we don’t know when the ideal time to implement rapamycin would be?*

- This depends on what you mean by ideal

*This now gets into risk versus reward and side effects versus benefits*

- In mice, we absolutely don’t know in terms of lifespan, if we take that as the primary metric that we’re interested in
  - We don’t know when is optimal to initiate treatment or what dosing protocol is optimal
- There still has not been a full, or even what Matt would call even **dose response profile** of rapamycin across a single intervention-initiating time point
  - We probably never will simply because of the cost of doing those experiments and all the permutations that you could come up with for time that you initiate and different doses to test
  - He doesn’t think anybody would ever fund that study

**A tangent worth mentioning about the way we fund biomedical research in general**

- Matt has some real concerns
- If somebody went to the NIH before this study had been completed and said, “*We want to start an experiment with rapamycin starting at 20 months of age in mice*,” that grant never would’ve gotten funded because people would say, “*That’ll never work.*”
- It was very fortunate in this case that it happened the way that it did, but Matt would argue that a research enterprise should develop an appetite for higher risk, higher reward projects
  - Nobody’s going to disagree with that

***This is a nice case in point of an important discovery that changed a field that would not have been made, if not for just the fortuitous circumstances that happened***

- Peter can’t think of a better type of research to fund for relatively low dollars than these types of questions
- He agrees there are a lot of permutations, and we’re talking about tens of millions of dollars
  - But when you consider what’s at stake and what we could learn (we’ll come back to this)

**Rapamycin dosing**

- The ITP studies are dosing rapamycin every day
  - Rapamycin is mixed into the mouse chow, so the mice are constantly nibbling on a low dose of rapamycin
- As we start to extrapolate into companion dogs and ultimately humans is a dosing regimen that looks completely different
- For starters, Peter would like to see what a different dosing regimen looks like in the mice of the ITP
  - Not just different permutations around dosing schedules, but also different starting points
  - Peter thinks they could raise the money needed to do that project ($10 million)
    - It’ didn’t’ take too long to raise half that money to do the [Dog Aging Project](https://dogagingproject.org/)
  - He thinks there would be a real appetite to do that kind of work because the implications are enormous
  - The NIH might not fund it, which is probably what Matt meant
- Matt agrees and adds, “*There are a bunch of those kinds of fundamental questions that I would argue are relatively low hanging fruit, and then we would’ve to think about prioritizing*.”
  - They will talk about rapalogs or other classes of mTOR inhibitors
- An [ATP-competitive mTOR inhibitor](https://en.wikipedia.org/wiki/MTOR_inhibitors#ATP-competitive_mTOR_kinase_inhibitors) was recently tested in mice, “*but we really have no clue as far as I can tell, how other classes of mTOR inhibitors would perform relative to rapamycin*”
- That’s another super important questions that has been very hard to get funding to study
- From Matt’s experience, he has put in grants to study dose responsive rapamycin, different intervals of rapamycin testing, and other classes of mTOR inhibitors
  - And they have been uniformly rejected because by and large
  - NIH study sections just aren’t interested in funding those kinds of studies
    - They’re not considered mechanistic enough
  - Those kinds of studies will *not* be funded in the current structure for research funding, even though they’re super important

## Explaining mTOR and the biology behind rapamycin’s effects [35:30]

- This topic might be among the most technically challenging for a layperson to understand, but it’s important to have some understanding of the biochemistry of what rapamycin does, what this protein complex looks like, and what the cascade of events are that move on
- It’s also important to understand how nutrients work, amino acids (in particular [leucine](https://en.wikipedia.org/wiki/Leucine))

**Explain how mTOR sits at the epicenter of our existence as living entities and how it does its job**

- David adds that rapamycin is quite unique in another aspect they have not discussed yet
- Most drugs go and find their protein target and usually do something to inhibit that target
- Rapamycin gets in the cell, binds to a little protein, [FKBP](https://en.wikipedia.org/wiki/FKBP)
  - What it does to FKBP doesn’t seem to matter at all
- Instead rapamycin hijacks that protein and now takes it and makes it bind to mTOR
  - It basically uses it as this thing that it draws next to mTOR and that moving of FKBP to mTOR is actually critical for how rapamycin acts (as people like [Stuart Schreiber](https://www.broadinstitute.org/bios/stuart-l-schreiber) have pioneered)

***Rapamycin is a really a molecular glue ‒ it connects mTOR and FKBP and that interaction is absolutely critical***

*How does mTOR work?*

- When David and others found mTOR, it was this big protein
  - It looked like a [kinase](https://en.wikipedia.org/wiki/Kinase) (that’s a protein that puts phosphates onto other proteins)
  - What it did and what it’s target were were completely unclear (it’s incredibly complicated)
- mTOR probably acts on hundreds of other proteins
  - They’re either proteins that make the cell build things (this [anabolism](https://en.wikipedia.org/wiki/Anabolism) side) or break it down ([autophagy](https://en.wikipedia.org/wiki/Autophagy): The self-eating destruction of parts of the cell, sometimes aged or damaged parts of the cell; that seems to be critical on the [catabolic](https://en.wikipedia.org/wiki/Catabolism) side)
- For a long time they had mTOR but couldn’t get it to phosphorylate anything in a test tube
  - It seemed like a terrible kinase
  - Its enzymatic activity was puny
  - They even thought maybe it’s not really a kinase
  - It was like a more abundant protein
- The critical breakthrough was the idea that mTOR must work by being bound to other proteins
  - Now, this seems obvious as everyone talks about the TOR complex, but at the time, it wasn’t
  - When they would isolate mTOR, they asked, “*Does it have friends?*” and the answer was no
- They came to realize that the detergent they used to break cells apart also broke apart the mTOR complexes
  - A mammalian cell is surrounded by a lipid fatty membrane, and you have to break that to do biochemistry
    - This is why they use a detergent
  - You could never predict this, and this goes back to serendipity
- When they used other detergents and things to stabilize it, then they found these TOR complexes
- The first breakthrough was the discovery of a protein named [RPTOR](https://en.wikipedia.org/wiki/RPTOR)
  - Now there are genetics on RPTOR connected to lifespan and the aging process
  - That defined what we now call [mTORC1](https://en.wikipedia.org/wiki/MTORC1)
- Another protein named [RICTOR](https://en.wikipedia.org/wiki/RICTOR) defines what we call [mTORC2](https://en.wikipedia.org/wiki/MTORC2)
- They started building out that complex and now when you had that thing in a test tube, it did stuff
  - It could show serious activity that you could measure (phosphorylation)
  - The known substrates like [S6 kinase](https://en.wikipedia.org/wiki/P70-S6_Kinase_1) that before they couldn’t phosphoryl S6 kinase to save our life inside a test tube; but now, all of a sudden, they really could
- This opened up the door and connected mTORC1 to other things upstream
  - All the proteins that communicate to mTOR, that bring signals to it are **upstream** of it
  - The things mTOR acts on are **downstream** of it
    - Very little had been done downstream of mTOR, they were focused on the upstream
- The next big conceptual breakthrough came when they looked inside of cells and saw that mTOR was in a particular place, in an organelle called the [lysosome](https://en.wikipedia.org/wiki/Lysosome)
  - The lysosome is the recycling center, and this is where a cell takes things and breaks them down and releases nutrients
- It turned out that mTOR lived at this very interesting interface where the cell produces its own nutrients by breaking down things and also where the nutrients are coming in from the outside at that intersection
- They went on then to find lots of the pieces that allow that nutrient sensing (they’ll get into amino acids and other nutrients later)

**Approximately how many mTOR complexes exist in a typical cell?**

*What is the distribution of mTOR concentration across different cells in the body?*

- In terms of numbers, there are thousands of complexes
  - It’s not an amazing rare protein, and yet it’s not incredibly abundant
  - It’s probable in the range of a hundredfold to a thousandfold less than some of the most abundant proteins in the cell
    - There are proteins that are much, much less abundant than that
- It’s evenly distributed between mTORC1 and 2 (at least in the cells they’ve looked at in culture)
- When you look across tissues in a mouse or a rat, it’s actually pretty even across tissues as well
  - That puts it in the category of what are called “[housekeeping proteins](https://en.wikipedia.org/wiki/Housekeeping_gene)”, which are some of the most important proteins in the cell
- David and other have found that regulation of mTOR levels doesn’t happen that much
  - This is not the critical regulatory input
- Regulation of the upstream stuff is really where the pathway gets fine-tuned
  - In different cells to different inputs
  - This is where we have to start thinking about new modalities to target mTOR

*Do we have reason to believe that there is comparable mTOR concentrations within CNS tissue and peripheral tissue (except a red blood cell)?*

- There actually is some in [RBCs (red blood cells)](https://en.wikipedia.org/wiki/Red_blood_cell) which has been very confounding because RBCs don’t have things like lysosomes in them (or mitochondria)
  - There’s even some in platelets
  - David has always wanted to go and look in RBCs for this reason

***As far as they can tell, every cell has some mTOR and mTORC1 in it; mTORC1 is a very critical protein for the health of the cell***

- David is not sure if he’s 100% correct in this but would argue that mTORC1 is critical for almost every cell
  - Matt alluded to a [study](https://pubmed.ncbi.nlm.nih.gov/37269831/) where people have used catalytic inhibitors of mTOR

- David points out, “*We need to distinguish what rapamycin does.*”
  - People call it an [allosteric inhibitor](https://en.wikipedia.org/wiki/Allosteric_regulation)
  - It binds to mTOR, but it doesn’t bind in the heart of mTOR
    - If the heart is where it does its phosphorylation reaction, that’s like the central node of it. It doesn’t bind there. It actually binds close.
  - What it does, it prevents certain substrates from getting to that [kinase](https://en.wikipedia.org/wiki/Kinase) domain
    - It sterically blocks them from getting there
    - So it doesn’t fully inhibit all the activities of even mTORC1
- Analogy #1: If the amino acid is like a baseball that’s supposed to bind inside the glove, rapamycin, by blocking that, doesn’t sit right in the heart of the glove
  - It maybe binds outside the glove and closes the glove
  - It changes the shape of the glove so that the intended target [doesn’t get in]
- The thing that binds the glove here is ATP (it’s the phosphate donor)
- The substrate, let’s say [S6 kinase](https://en.wikipedia.org/wiki/P70-S6_Kinase_1)
- Analogy #2: Think of mTORC1 as a cave (a way to visualize this enzyme)
- ATP can get in there [the active site of mTORC1] no problem, it’s small
- Think of the active site like the entrance to a cave, and now you’ve put a boulder in the entrance of that cave, but you haven’t fully blocked that entrance
  - Simplistically speaking, some small things get in (smaller substrates), but bigger ones cannot
  - Peter alluded to shape changes, but the simplest way to think about it is it’s a steric block of some things but not others
- This is what happens for mTORC1 (mTOR complex 1), which is different from other classes of inhibitors which are going to affect mTOR in both [mTOR complex 1](https://en.wikipedia.org/wiki/MTORC1) and [mTOR complex 2](https://en.wikipedia.org/wiki/MTORC2)

## Differences in how rapamycin inhibits mTOR complex 1 (MTORC1) versus mTOR complex 2 (MTORC2) [45:15]

- Matt referred to a [study](https://pubmed.ncbi.nlm.nih.gov/37269831/) of the effect of catalytic inhibitors of mTOR on lifespan, and this is something David has always wanted to study because they’re extraordinarily toxic molecules when dosed at higher levels
- The catalytic inhibitors basically annihilate the activity of mTORC1 and mTORC2 if used at the right dose
- Rapamycin partially inhibits mTORC1 and over time, can also partially inhibit mTORC2
  - They’re very dramatically different

**What is it about the kinetics of rapamycin’s inhibition of mTOR complex 1 that will eventually but not immediately lead to the inhibition of mTOR complex 2?**

- David points out, the canonical substrate of mTORC1 is [S6 kinase](https://en.wikipedia.org/wiki/P70-S6_Kinase_1), and every biologist looks at S6 kinase phosphorylation as an indicator of mTOC1 activity
- The canonical substrate for mTORC2 is a protein called [Akt](https://en.wikipedia.org/wiki/Protein_kinase_B)
  - Everyone looks at Akt phosphorylation as a canonical output
- In the early 2000s, David had this postdoc [Dos Sarbassov](https://research.nu.edu.kz/en/persons/dos-sarbassov) (one of the more colorful people he had, a guy from Kazakhstan), who had discovered [RICTOR](https://en.wikipedia.org/wiki/RICTOR) and the Akt phosphorylation
  - One day he comes to David’s office and tells him, “*David, rapamycin inhibits mTORC2.*”
  - David thought this was impossible because they had tried to show that this FKBP rapamycin would bind to mTORC2 and it wouldn’t bind
    - It would bind fine to mTORC1, but it wouldn’t bind to mTORC2
  - Dos Sarbassov shows the data, and if he used rapamycin for a long period of time, it inhibited Akt and also broke apart mTORC2
    - David didn’t believe it
  - They published that [paper](https://www.cell.com/molecular-cell/fulltext/S1097-2765(06)00218-8?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1097276506002188%3Fshowall%3Dtrue) around 2005
  - David explains this is one of those cases where the trainee really is driving the story and convinces you of what turns out to be a pretty important discovery

*Why did this happen?*

- You can do an experiment where you take mTORC2 and put FKBP-rapamycin on it with phosphorylated Akt, no problem
- You do the same experiment with mTORC1 and S6 kinase and now you could really inhibit S6 kinase phosphorylation

***What they came to realize is that mTORC2 is not born as mTORC2, it’s born as mTOR and RICTOR, and they have to find each other***

- But what can happen is that FKBP-rapamycin can bind to what we call naked mTOR, and when it binds, RICTOR can’t bind, so you can t make mTORC2

***So what happens is when you incubate a cell and a mouse over prolonged periods of time with rapamycin, all your mTORs acquire an FKBP-rapamycin and therefore, you can’t form a RICTOR complex, which prevents mTORC2 formation***

- Therefore, mTORC2 inhibition is completely different than how rapamycin impacts mTORC1
- Rapamycin is basically preventing the biogenesis, the formation of mTORC2
  - You need these two proteins, mTOR and RICTOR to come together, and FKBP-rapamycin is preventing that interaction

## Reconciling the biochemical mechanism of rapamycin with its longevity benefit [49:15]

**Matt, given what David just said, does it surprise you that the ITP study (and many studies that have looked at constitutive dosing of rapamycin) still managed to find a longevity benefit?**

- No, but the reasons is that the network is extremely complicated
- The model that David laid out is our best guess for how this is working
- Matt agrees that everything David said is correct from a biochemical perspective

***What the impact is on the overall network of transient rapamycin treatment at a given dose versus chronic rapamycin treatment at the same dose (or a different dose) is much harder to really understand in a detailed way***

- Part of the reason why Matt’s not surprised is because we already knew all the longevity outcomes before we understood this biochemical mechanism
- So now, we’re trying to work backwards and say, “*How do we explain the fact that rapamycin can increase lifespan in a bunch of health span metrics given that the way it was dosed in the mice should have also impaired mTOR complex 2?*”

***Built into that is the assumption that the reason rapamycin is extending lifespan and affecting healthspan metrics is purely because of the mTORC1 inhibition, but we don’t completely know***

- The best evidence for the idea that the benefits of rapamycin come from mTORC1 inhibition is the [genetic data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3687363/)
  - Which we’ve alluded to in yeast and worms and flies and mice where you can mutate proteins or genes that code for proteins in mTOR complex 1 and see lifespan and healthspan benefits, but that’s incomplete

**Matt’s takeaway**

- This is dissatisfying to him and probably everybody else out there, but it’s true that we still don’t fully understand the mechanisms by which mTOR inhibition and rapamycin can impact the biology of aging and therefore we’re working with incomplete models
- He’s not convinced at this point that the idea that all of the benefits are due to mTORC1 inhibition and all of the side effects are due to mTORC2 inhibition.
  - It’s a model that still needs to be studied, and David agrees

**How to think about inhibition of mTORC2 and mTORC1**

- David has published [papers](https://onlinelibrary.wiley.com/doi/10.1111/acel.12256) arguing that inhibition of mTORC2 is toxic, but the reason why it is tolerated is because the amount of rapamycin used in longevity studies are relatively modest
  - Dosing is probably somewhat intermittent even though a mouse is eating them because it doesn’t eat all the time
  - This is different from studies in tissue culture where the dose of rapamycin is high and kept above a certain level 24/7
  - You can imagine that once mTOR finds a RICTOR, it’s immune to rapamycin now
    - And as soon as those two interact, you’re going to have an mTORC2
    - You need very little mTORC2 to keep Akt happy (10-15% in cell culture)
  - As soon as rapamycin levels fall below a certain amount, there’ll be escapers and you’ll make an mTORC2
    - We have to ask how relevant that activity is to the potentially beneficial effects of rapamycin
- Matt points out, “*Sometimes we get into the routine of talking about mTOR and mTORC1 and mTORC2 as if they were on-off switches, but they’re not. You can think of them as knobs.*”
- You don’t need a lot of mTORC2 activity to survive, and the same this is probably true for mTORC1

***Rapamycin is turning down mTORC1 immediately a lot, and that’s going to depend on the dose of rapamycin. Then over time, rapamycin is turning down themTORC2 knob, but it’s not going to zero.***

- That’s part of what makes it really hard to do the definitive experiment that David was saying we can’t really do given the tools we have because it’s so complicated and the tools we’ve got are not clean in that context even though they’re very biochemically clean
  - And there are tremendous feedbacks that fight all of that
    - The system is always trying to get to homeostasis

## Important discoveries about the interplay of amino acids (leucine in particular) and mTOR [54:15]

**Discoveries made in David’s lab about what amino acids are doing to mTOR**

*What do we know in particular about branched-chain amino acids or leucine in particular?*

- The backstory: when David first identified mTOR in Sol Snyder’s lab, David talked to his dad (who is a cell biologist) and he told him to localize mTOR within the cell
  - David dismissed this suggestion
  - But he did make an antibody to mTOR
  - When he added the antibody to cells it gave a very interesting [punctate](https://www.dictionary.com/browse/punctate) pattern
  - David remembers asking people at Johns Hopkins about this patter, and he didn’t get a definitive answer
  - The rabbit used to make the antibody died and the antibody was lost
  - They didn’t revisit this question for another 10-15 years
  - Later Tim Peterson in David’s lab repeating the staining and learned that mTOR was localized in the lysosomes
- [Lysosomes](https://en.wikipedia.org/wiki/Lysosome) are recycling centers, they are compartments in the cell that have a membrane
  - They contain about 60 enzymes that will break down anything that gets into the lysosome, break it down to single components
    - For example, proteins go in and amino acids come out, or polymers of sugars go in and individual sugars come out
- The critical experiment that changed everything was a simple one that Tim did, he said, “*Let me remove amino acids and look where mTOR is.*”
  - mTOR wasn’t on lysosomes anymore
  - It went off the lysosome
  - Then he added amino acids and within minutes, mTOR went back to the lysosomes

***This told us that nutrients communicated to mTOR and one of the things they did was move mTOR to the surface of the lysosome***

- Next they went and found the docking station
- You can think of mTOR as a big ship and there’s a docking like a pier
  - When it gets there, it sits on top of these proteins that hold it there
  - It turns out that those proteins are the ones that nutrients talk to
- There are about 20 proteins involved in making that communication to drive mTOR to the surface of the lysosome (we won’t go into the details)
  - Multiple large protein complexes
- This process could have been simple (one protein binds an amino acid, talks to mTOR), but it’s not
  - There’s a lot of protein real estate used to do this, which tells you the cell cares a lot about this
- The question becomes, which amino acids?
  - This was answered by [Joe Averuch](https://researchers.mgh.harvard.edu/profile/3588924/Joseph-Avruch); he had a [paper](https://www.jbc.org/article/S0021-9258(19)77495-X/fulltext) in JBC where he looked at amino acid regulation of mTOR
    - This was before the lysosomes
    - He was looking at the activity of using S6 kinase, and he basically found a couple amino acids that matter, namely [leucine](https://en.wikipedia.org/wiki/Leucine) and [arginine](https://en.wikipedia.org/wiki/Arginine)
- Leucine is a very common, [essential](https://en.wikipedia.org/wiki/Essential_amino_acid), branched-chain amino acid
  - It’s an important component of whey protein
- Arginine is a very basic amino acid with lots of nitrogen
  - Technically it’s not an essential amino acid
- Since then, they have found other amino acids

**The holy grail was the question, “*****How is leucine detected?*****”**

- They wanted to know this for decades
- There is a lot of literature in mice, humans, and big animals used on farms that leucine boosts satiety (the feeling of having fed) and boosts muscle mass
- Eventually David’s group found the receptor for leucine, a protein called [sestrin](https://en.wikipedia.org/wiki/SESN2)
- For David, seeing the crystal structure of leucine bound in sestrin was a moment that moved him, he had been hunting it for a long time
  - This showed how nature does it, how it detects leucine in the steak you just ate and goes on to talk to mTOR
- [Rachel Wolfson](https://connects.catalyst.harvard.edu/Profiles/display/Person/99263) and [Lynne Chantranupong](https://www.umassmed.edu/metnet/blog/2023/02/lynne-chantranupoing/) discovered sestrin as the sensor for leucine, and they could show that genetically biochemically
- Then [Bobby Saxton](https://vcresearch.berkeley.edu/faculty/robert-saxton) working with David’s group and [Thomas Schwartz](https://biology.mit.edu/profile/thomas-u-schwartz/), he then did the crystal structure of leucine bound
- What was beautiful about that structure was it immediately said, “*It’s got to be leucine*”
  - Which David’s group and others had shown already
  - You could try isoleucine, but it didn’t work
  - The sobering part was it’s a small little pocket; leucine is a very small molecule, so it’s not clear how you can mimic
- The immediate idea was, “*Can we mimic the anabolic effects of leucine without taking leucine? Can we make something better than leucine?*”
  - They’ve managed to make things slightly better, but nothing dramatically better
- The structure tells you why because it basically is made to fit leucine and nothing else

**How long does leucine stay in that pocket?**

- David doesn’t know
- Leucine binds [sestrin] and then there’s a lid that falls on top and literally closes the binding pocket
- Evidence suggest that getting leucine in is easy but getting leucine out is not easy
  - There may be an active way of getting leucine out
- That lid has some very interesting sequences in it that suggests that it might be phosphorylated to pop it open
  - We don’t have an answer to that question

***Data suggests that leucine is not popping in and out; it pops in but probably requires an active step to get out***

## Reconciling rapamycin-mediated mTOR inhibition with mTOR’s significance in building and maintaining muscle [1:01:30]

**Matt, how do we reconcile two things that seem a little bit at odds here?**

*Peter points out:*

- We have established that mTOR is the most important sensor we have for nutrients, and probably the most critical nutrients of them all (amino acids)
- We also understand that sarcopenia is an enormous risk to both lifespan and healthspan ([sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia), meaning low muscle mass)
- We understand the relationship between amino acids and muscle mass
- We understand anabolic resistance in an aging population

***All of these things say amino acids are good, mTOR activation (i.e., anabolic activation) is good, and yet we’ve just made a very compelling case for why blocking that extends lifespan***

*How would you start to reconcile what seems conflicting?*

- It’s going to be extremely complicated
- Remember, these are not on-off switches

***You really need to think about this in the context of what is the optimal level of mTOR complex 1 activity for whatever it is that the cell, the tissue, the organ, the organism needs to do to function or stay alive***

- Certainly, we know that you need mTOR activation to build new muscle and so the idea was that rapamycin treatment, inhibiting mTOR, turning down mTOR should lead to faster muscle loss
  - That was the prediction that was made, that rapamycin should induce sarcopenia if you were to treat animals with rapamycin as they were getting older
  - The reality turns out to be the *opposite* (certainly in rats, probably in mice, we don’t have data yet in people)

***Certainly in rodents that you can treat them with rapamycin throughout adulthood and actually preserve muscle mass into old age, and the explanation for that is still a little bit unclear***

**Part of the explanation is going to be dose**

- If you were to give too much rapamycin, you would probably accelerate sarcopenia
- But at the doses that have been used to increase lifespan, it seems like you can actually preserve muscle mass during aging
- That’s a different question though than the one that a lot of people ask, which is if you were to take rapamycin, would it prevent your ability to build new muscle mass?
  - It might if you’re a bodybuilder
  - We don’t have any data in humans on people who are just doing resistance training in the context of just wanting to maintain muscle mass or build a little bit of muscle mass as they’re getting older
  - We don’t have the data in rodents either

***In the context of the doses that extend lifespan, would that impair the ability of those animals to build muscle mass if they were put on some sort of a resistance training regimen? No one has done that experiment yet.***

**Peter thinks this is a shame because that experiment has been done with** [**metformin**](https://en.wikipedia.org/wiki/Metformin)

- There have been some studies looking at the effects of metformin on exercise (both resistance training and cardiovascular training), but the data is unclear
  - [Discussed in newsletters from [June](https://peterattiamd.com/metformin-and-exercise/) and [October](https://peterattiamd.com/metformin-and-exercise-deja-vu-all-over-again/) of 2019]
- There is some reason to think that metformin might impair what people think of as the positive response to exercise (a tangent)
- It’s a shame that this experiment hasn’t been done for rapamycin in humans and hopefully it will in the near future
- Matt’s intuition is that part of this comes down to the **effects of rapamycin on chronic inflammation**, which we know increases with aging and can impair synthesis of new muscle (as well as preservation of existing muscle)

**Some competing interests regarding the effects of rapamycin**

***Rapamycin inhibition of mTOR complex 1 might somewhat impair synthesis of new muscle even at the doses that seem to promote longevity in rodents, but it might actually preserve muscle because it’s having this more broad anti-inflammatory effect***

- This is why Matt thinks it’s hard to get to a specific detailed mechanistic answer to your question because people haven’t really started to disentangle those things
- Matt is a little bit wary of extrapolating too far from the rodent studies to humans in the context of sarcopenia
  - In particular, he’s talking about mouse studies to humans
  - These inbred mouse strains are *not* particularly prone to sarcopenia with age
    - There are some rat models that are better
  - He worries about the use of mouse models to try to say this is or is not going to have an impact on sarcopenia in humans
    - He’s not talking so much about rapamycin in this context, but more about studies of protein restriction and branched-chain amino acid restriction, which seem to have some positive effects on longevity
- Sarcopenia seems to be much more important for quality of life (probably also life expectancy) in older adults

***We need to be careful about extrapolating mouse studies to humans in the context of muscle preservation, muscle function, and sarcopenia***

- Peter agrees, this is a really important point
- One of Peter’s gripes with people who tend to over-index on **protein restriction in animal studies** is A) the model itself and B) the environment in which the model exists
  - If you’re living in a sterile environment where there aren’t curbs to step off, and places to fall and injure yourself
  - One only need look at the mortality data for people over the age of 75, even over the age of 65
    - If they fall, it’s an enormous cause of not just death, but morbidity, total destruction of quality of life

## Unanswered questions around the tissue specificity of rapamycin [1:08:30]

**Do we know from studies of mice what the tissue specificity is of rapamycin?**

*Do we have a sense that we are getting uniform mTOR blockade, or do we get the sense that no, it’s disproportionately happening in the liver or it’s disproportionately happening in the adipose tissue?*

- David adds that Matt answered the question perfectly [earlier], and it shows the complexity of the issue
- It’s not only mTORC1 versus mTORC2, it’s which cell type?
  - Is it muscle fiber? Is it inflammatory cells, immune cells?
  - At what dose?
  - Is it which process? Autophagy? Is it protein synthesis?
- Regarding Peter’s question: Certainly if you dose it high enough, in David’s experience, you’ll inhibit mTORC1 in all tissues that he’s looked at
- It takes a little bit of time if you’re talking about classic rapamycin to get in the **brain**
- Typically you need to do a little bit of a loading dose, but you’ll get it into the brain
  - Now, there’s been some discrepancies
  - Some people say immediately
  - In David’s hands, it usually takes a couple of doses without interruption to get in the brain (in a mouse dosing every 8 or 12 hours, which is aggressive)

**Based on those data, would you extrapolate that if you were taking rapamycin weekly, it’s probably not getting into the** [**CNS**](https://en.wikipedia.org/wiki/Central_nervous_system)**?**

- Probably, with classic rapamycin
- In the pharma world, people wanted to treat [tuberous sclerosis](https://en.wikipedia.org/wiki/Tuberous_sclerosis) (where you get these tubers in the brain), and they did not think rapamycin was adequate for that because of CNS penetration
  - But again, very talented people have argued differently than that
- In David’s experience the brain seemed more resistant
  - In fact, sometimes you would stain the brain, and you’d see almost a peripheral inhibition, like it had permeated a little bit from blood vessels in the dura and stuff

**The more relevant question is, at these lower doses that people take potentially for healthspan, lifespan studies in the ITP studies, what are the tissues that are most affected?**

- Matt may know, but David doesn’t know

***David’s feeling is that it’s not going to be so equal in those situations because those are very low doses***

- David bets there’s much more variation
- This would be interesting to know

**Effects of inhibiting mTOR in different tissues**

- David points out that a critical [study done in worms](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2242811/) with other modulators of aging has *not* been done in a mammal for the mTOR pathway
- The **experiment**: If we genetically inhibit mTOR in the muscle/ in the liver/ in the brain, which one has the most prolonged lifespan, healthspan impact?
- Matt adds that there is a little bit of data on hypomorphic mTOR alleles, but he can’t remember the outcome
- [Veronica Galvin](https://www.galvanlab.org/veronica-galvan-ph-d) has done some stuff for dementia, brain aging, but Matt doesn’t know about lifespan
- Maybe [Toren Finkel](https://www.isb.pitt.edu/people/faculty/toren-finkel-md-phd) may have done something
- There may have been an adipose-specific knockdown/ knockout
  - Maybe liver specific
  - Certainly not systematically looking across different tissues
- David points out , “*There’s lifespan, but then there’s also the health of all the different tissues*”
- David would bet that you want to impact all tissue
- At meetings David would ask speakers, “*Tell me a biological system that does not age. Give me one where you don’t see the impact on aging from the biochemical cell, biological to physiological level.*”
  - No one has ever told him one

**Matt agrees and adds a point about mTORC1 and mTORC2** [**substrates**](https://en.wikipedia.org/wiki/Substrate_(chemistry)#Biochemistry)

- “*There’s very little information about other mTORC1 substrates or mTORC2 substrates in the context of this question of when you look across tissues, how much inhibition do you get?*”
- It’s very likely that rapamycin doesn’t affect all of the mTORC1 substrates
- You would expect that at higher or lower doses, the relative effects on different substrates are going to be different
- There have been a few studies looking at S6 kinase and maybe mTOR phosphorylation of itself across tissues in the context of aging
  - There are some variations
  - But those studies have differed from each other because the way the experiments were done
    - Were the mice fasted and refed before you measured mTORC activity (which affects mTOR activity)? This wasn’t the same across the studies

***The real answer is we don’t know***

## What we know about rapamycin’s ability to cross the blood-brain barrier and its potential impacts on brain health and neurodegeneration [1:13:45]

**Does rapamycin penetrate the brain?**

- There are disagreements about how effectively rapamycin crosses the [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier)

*How much rapamycin do you need to get inhibition of mTORC1 in the brain?*

- Matt’s studies indicate that higher doses are needed
- He sees potent mTORC1 inhibition in the brain after repeated dosing at higher doses (using [IP injection](https://en.wikipedia.org/wiki/Intraperitoneal_injection))
  - He hasn’t compared this to lower doses where the rapamycin is in the food
- We know that with age there is a decline in the function of the blood-brain barrier, that many molecules penetrate the brain better in older animals compared to younger animals, and Matt speculates that this is probably true with rapamycin
  - But he doesn’t know of any real data to support better penetration of rapamycin across the blood-brain barrier in aged animals/ people

> “*These are all questions that I think need answers and there just isn’t much out there right now*.”‒ Matt Kaeberlein

**What is the size of rapamycin? How physically large is it?**

- It’s almost exactly 1,000 Daltons
  - A hydrogen atom is a Dalton, so it’s about a thousand hydrogen atom’s weight
- In the world of small molecules, it’s a big small molecule
  - Most small molecules are more in the 200-400 range

**What’s the size at which you can easily traverse the blood-brain barrier?**

- David thinks this is not as relevant because rapamycin is a very, very [lipophilic](https://en.wikipedia.org/wiki/Lipophilicity) molecule
- It’s more about solubility than size
- David sees a lot of rapamycin gets trapped in the membrane
  - You almost need to push it through
- The brain has a lot of things like myelin, which are all very lipophilic, so there’s almost a sink of trapping rapamycin in places that maybe it’s not so effective

**Peter’s anecdote about the biomarker** [**C2N**](https://c2n.com/)

- This is a biomarker he uses clinically (in humans) to look for [amyloid](https://en.wikipedia.org/wiki/Amyloid_beta) in the serum
- It’s very highly correlated with amyloid in the CNS, and it’s very highly correlated with amyloid PET scans
- Obviously in patients who are high risk for [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease#), if they’re in a clinical trial, you might be able to justify amyloid PET or [lumbar punctures](https://en.wikipedia.org/wiki/Lumbar_puncture) to look for amyloid in the [cerebral spinal fluid](https://en.wikipedia.org/wiki/Cerebrospinal_fluid)
  - But not only does that come with the case of a lot of radiation and potential morbidity respectively for those procedures, it’s simply not practical if you’re clinically practicing medicine
- This C2N assay was approved a couple of years ago, and it has become a really important part of how Peter manages risk in high risk patients
- This is very anecdotal, but for our very high risk patients who are showing [amyloid](https://en.wikipedia.org/wiki/Amyloid_beta) already in the plasma, Peter believes they have put two of them on intermittent rapamycin
  - Anywhere from 5-8 mg once a week
  - In both cases the C2N score has improved, meaning every three months when we are checking the amyloid concentration, it’s going down
- There are 10 leaps of faith you’d have to take there

*Does that mean the amyloid is going down in the CNS?*

- To David’s point about by definition these patients are aging, so maybe their CNS, their blood-brain barrier is not as robust, even though that’s a very low and clearly infrequent dose of rapamycin, maybe it is making its way into where it matters
  - Alternatively, it may not be making a difference where it matters and my simply only be making a difference in the periphery

**Matt’s different hypothesis**

- The periphery may matter for the brain
- There are two lines of evidence that Matt can point to that might support this
- 1 – Matt’s group has worked for many years on a mouse model of childhood mitochondrial disease called [Leigh syndrome](https://en.wikipedia.org/wiki/Leigh_syndrome)
  - It’s a [complex I](https://en.wikipedia.org/wiki/Respiratory_complex_I) deficiency in the mitochondria, but it’s a brain disease, so it causes neuro-degeneration and lesions in very specific regions of the brain
  - They did an experiment along the lines of what David was asking about in the context of longevity (which hasn’t been done), where they knocked down mTORC1
    - This was in the case of an S6 kinase knockout in different tissues, and Matt expected it would be the brain specific knockout that would lead to rescue of the disease, but it didn’t at all
    - It was a liver-specific knockout that led to partial rescue of the disease

***There could be a tissue signaling piece, and that could be metabolic***

- You could imagine inhibiting mTORC1 in the liver would lead to systemic metabolic effects
- This is a case in point where you can get effects on a brain disorder
  - He’s not saying the mechanism is the same as neurodegeneration and aging, but you can get an effect on the brain from inhibiting mTORC1 in the liver
- 2 – There is accumulating compelling data that **systemic immune dysregulation** drives dysfunction in many parts of the body including the brain
- With age, concomitant with the breakdown in the blood-brain barrier, you actually may see higher penetration of peripheral activated immune cells into the brain, and that’s driving some of the inflammation in the brain

***Matt speculates: You could easily imagine rapamycin’s effects on the peripheral immune system would then reduce the transfer of peripheral immune cells to the brain or at least inflammation caused by those immune cells***

- It would not shock him at all if you don’t really need to get high levels of rapamycin (or high levels of mTORC1 inhibition in the brain) to derive some of these benefits that people have seen at least in laboratory animals

**Peter’s rationale for treating these patients with rapamycin**

- There is no meaningful treatment for this condition [someone with elevated amounts of amyloid beta]
- We also know that once you’ve exhausted all lifestyle measures around treating people with [MCI (mild cognitive impairment)](https://en.wikipedia.org/wiki/Mild_cognitive_impairment), you’re not going to rescue everyone
- Matt’s point is an excellent one that Peter had not considered, other than just through broad reduction in inflammation
  - Less [PBMC](https://en.wikipedia.org/wiki/Peripheral_blood_mononuclear_cell) activity in the periphery should improve it
- Alzheimer’s disease is a very complicated disease with multiple pathways
  - There are these very lipid dependent pathways and there’s a lipid type of Alzheimer’s disease
  - There’s a really inflammatory type of Alzheimer’s disease
- All of this screams that more clinical research is needed

## Rapamycin may act as an immune modulator in addition to immunosuppressive effects [1:21:30]

**Pharmaceutical interest in drugs related to rapamycin**

- We’ve already alluded to the incredibly slow timeline for rapamycin’s transition into humans, and the net result of that was a drug that was not a profitable drug presumably for Pfizer for very long
- As a result of that, there has been a relative lack of interest in studying rapamycin and instead an interest in looking at other drugs

**How does everolimus differ from rapamycin?**

- [Everolimus](https://en.wikipedia.org/wiki/Everolimus) was part of the Novartis portfolio
- It’s a **rapa-log** or a simple derivative of rapamycin
- David doesn’t quite remember the modification, it was small, maybe a methyl group
- Ironically, the original patents on rapamycin did a very poor job of covering obvious derivatives of rapamycin
- More recently, there have been more sophisticated variations of rapamycin
- Matt adds that rapa-logs all work by a pretty similar biochemical mechanism
  - They all bind FKBP12 and then it’s that complex that inhibits mTORC1

***The real differences are more around bioavailability, maybe tissue distribution and how long the drug lasts before it gets metabolized***

- Matt thinks all of these things are broken down by [cytochrome P450 enzymes](https://en.wikipedia.org/wiki/Cytochrome_P450), so you’re going to get differences in peak and trough levels based on the bioavailability and clearance and then maybe some differences in tissue distribution

***Biochemically, they’re all pretty similar, and in David’s experience in cells and culture, they act identically***

**Peter’s story about treating transplant patients with rapamycin**

- Rapamycin is **expensive** even as a generic drug, and Peter thinks this speaks to the lack of alternatives
- Peter remembers April 2009, fast-forward 5.5 years to December 2014
  - He didn’t know Matt and David
  - Matt and Peter wouldn’t meet David for another year
- Peter was already obsessed with rapamycin, but was pretty distraught that it would never make sense to take as a human
  - That it would never go on to become a human geroprotective agent
- Despite how impressive all of the data were in all of these animal models, he couldn’t get out of his mind all those transplant patients
  - He was force-feeding them rapamycin like Tic-Tacs and Chiclets, and he thought it couldn’t be a good think if you’re in the business of living longer
- The day before Christmas he got an embargoed copy of a [paper](https://pubmed.ncbi.nlm.nih.gov/25540326/) by [Joan Mannick](https://milkeninstitute.org/events/fhs19/speakers/39958), [Lloyd Klickstein](https://srfcure.org/lloyd-klickstein/), and others that seemed to challenge the very foundation of that
- Matt has already made a lot of good points about why thinking about rapamycin might have been a bit premature

**Walk us through the study in Australian senior citizens that was a turning point in how we thought about rapamycin**

- David thinks the Joan Mannick [paper](https://pubmed.ncbi.nlm.nih.gov/25540326/) about rejuvenation of the immune system will be seen in the aging field as a milestone paper along with the [ITP paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/)

***As far as he knows, this is the first paper to show you can actually rejuvenate some organ system in a human***

> “*I think her study really was mind-blowing.*”‒ David Sabatini

- Matt adds, “*As people are thinking about clinical trial endpoints for gerotherapeutics, that’s a perfect case example of a functional endpoint that you can actually do a clinical trial on for FDA approval*.”
- As a conceptual advance, it’s important as well

*Matt provides some history*

- A compelling experiment: There was a [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4020596/) by [Pan Zheng](https://oncoc4.com/index.php/about/our-team/164-pan-zheng-md-phd) in 2009 that preceded the Joan Mannick paper where they showed that you could treat with rapamycin for maybe six weeks and rejuvenate the immune function of a mouse
  - They have a set of mice maybe 24 months old and they had young mice
  - Mice get either a flu vaccine or no vaccine, then they waited and gave them what would be lethal dose of influenza (lethal if they weren’t vaccinated)
  - The aged mice got either rapamycin for six weeks or they didn’t
- For young mice, unvaccinated, that get this dose of influenza, there is 100% mortality within about 8 days
- For young mice that are vaccinated, there is 100% protection
- If you’re an old mouse, no rapamycin, vaccinated, only 30% were protected
  - This shows the impact of normal biological aging
  - With aging, about 70% of the time you don’t respond to the vaccine and you then die if you get a subsequent influenza infection (interesting parallels to humans as we’ve learned over the last 4-5 years)
- Cool result: If old mice got 6 weeks of rapamycin treatment before the vaccine, they were 100% protected

***This is an amazing demonstration of immune rejuvenation in an aged animal***

- Matt thinks that study is what really set the stage and allowed Joan and the group from Novartis to be able to move forward and convince the people who had to fund this study that there was a reason to think that mTOR inhibitors might do the same thing in humans

**The Joan Mannick** [**paper**](https://pubmed.ncbi.nlm.nih.gov/25540326/)

- The design of that human study conceptually is very similar to the [mouse study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4020596/) just discussed (except of course they didn’t give people lethal doses of influenza)
- They enrolled healthy older people (maybe over the age of 65 and there were some set of preexisting disease that they would be excluded for)
  - They were considered relatively healthy for their age, and they got either placebo or [everolimus](https://en.wikipedia.org/wiki/Everolimus) for six weeks
    - In the first study they tested three different doses of everolimus: 5 mg once a week, 20 mg once a week, or 1 mg daily
    - So it wasn’t rapamycin, but we can just think about it the same as we would rapamycin based on our earlier discussion
  - Then they got the flu vaccine and looked at antibody titers
  - Matt can’t remember if it was this study or a later one where they looked at viral gene expression as well
  - They also looked at subsequent respiratory infections over the next 6-12 months (or something like that)
  - Matt recalls the first paper showed convincing data that for at least 5 mg once a week and a 1 mg daily dose there was a boost in response to the vaccine (measured by antibody titers)

***That supported the idea that similar to what had been shown in mice, you could in fact to some extent rejuvenate the ability of the aged immune system in humans to respond to a vaccine with transient dosing with a rapamycin derivative (everolimus in this case)***

- The other important thing about this paper is the study was pretty large
  - It wasn’t [phase III trial](https://en.wikipedia.org/wiki/Clinical_trial#Phases) but there were hundreds of people who got everolimus who didn’t have an organ transplant and weren’t taking other immunosuppressants
    - The side effect profile in the 5 mg once a week group was essentially no different than placebo

***This started some people in the community thinking maybe it is possible that lower doses of a rapa-log in relatively healthy older adults could be well tolerated, and maybe this idea that as a geroprotective therapeutic we might be able to give rapamycin to older people***

**Peter thinks that study shows that we shouldn’t think of rapamycin as an immune-suppressant but rather a immune-modulator**

- That was a clear example of how you take an aged immune system and make it more robust, and it very likely is the case that you can also suppress the immune system
  - Interestingly, these are the same parts of the immune system (it’s a very complicated system)
    - It is the same immune system that is there to fight a virus that is also there to reject an organ
    - These are not just T cells, but this is part of the cellular immune system

**The use of rapamycin as an immunosuppressant**

- David was living through the age of immunosuppressants at Hopkins, and he remembers how miraculous [cyclosporin](https://en.wikipedia.org/wiki/Ciclosporin) seemed, and then [FK506](https://en.wikipedia.org/wiki/Tacrolimus)
- Rapamycin to some extent got caught up in being this generic immunosuppressant, but the truth is, when you looked at the data in cells and culture, it’s actually not so easy to inhibit in some of those immune activation assays in culture
  - Rapamycin is pretty weak
  - If you look at the data in mice, it never looked like FK506 and cyclosporine, but it got caught up with that name because that was sort of that revolution that was happening
  - And that characterization of rapamycin has persisted
- Peter doesn’t think any patients are using rapamycin today except for legacy patients
  - That is someone who received a transplant 25 years ago and it’s part of their regimen, it’s working for them, and no one is willing to shift it
- He has talked to many transplant surgeons and asked if rapamycin is in their immunosuppressive regimen, and he had never heard anybody say yes
- Peter has never familiarized himself with the literature that led to the approval of rapamycin for transplant patients in 1999
- David remembers a study of people who take immunosuppressants chronically have higher rates of certain types of cancer, which of course makes sense
  - Rapamycin does not
  - It was justified at the time that the reason rapamycin did not is because it itself has anticancer properties
  - The alternative is that it doesn’t actually impact the immune system in the way that the other ones do to cause that, and that’s never actually been quite resolved
- David agrees that rapamycin is not a traditional immunosuppressant in any way, but that name has been attached to it and people say, yeah, I don’t want to get infections by taking rapamycin
  - But there’s almost no evidence that there’s actually an increase in infections at all

## Might rapamycin induce changes in T cell methylation patterns, potentially reversing biological aging? [1:34:15]

**Do you believe that if you could look at the epigenome of the T cells in those patients in the Mannick Klickstein study, do you believe that you would see a change in the methylation pattern pre and post rapamycin?**

- Matt replies, “*Absolutely, but I think what you’re really asking is would we see a change in the methylation pattern that is what people are calling a reversal of biological aging?*”
- Yes, this is what Peter wants to know, “*Is it rewriting the epigenome? Is it undoing some of the aging of the T cell, and is it writing that code via methylation onto the epigenome?*”
- Matt can’t make a strong prediction here

***There is no question that you will see a change in the epigenome, but that’s just saying everything big you to do a cell is going to affect the epigenome***

- Matt is less convinced that these [epigenetic clocks](https://en.wikipedia.org/wiki/Epigenetic_clock) are really measuring from a biological aging perspective what some people think they’re measuring
- He doesn’t have such a strong feeling that rapamycin would reverse what people are calling the epigenetic aging clock universally
  - He thinks in some contexts it will
  - He doesn’t know about T cells
    - It’s a really interesting question
    - First of all, what are the canonical age-related epigenetic changes in T-cells and how closely are those linked to the functional declines that we see with T-cells that go along with aging?
    - He doesn’t think that’s really been carefully fleshed out.

***Matt is less convinced what the epigenetic clocks are actually measuring to be able to say with any level of confidence that rapamycin is going to reverse it***

- Peter doesn’t think the current versions of the clocks are not measuring anything that’s of interest, but he wonders if we just don’t have the technology yet to actually read this at [CpG](https://en.wikipedia.org/wiki/CpG_site) resolution and therefore we don’t really know what the heck is going on
  - When we use these crappy [microarrays](https://en.wikipedia.org/wiki/Methylation_specific_oligonucleotide_microarray) to read these things when we’re sort of averaging out [methylation patterns](https://en.wikipedia.org/wiki/Epigenetics#DNA_methylation)
  - Analogy: It’s like trying to play the piano with mittens on
    - It’s totally unhelpful, but if you can take the mittens off and put your fingers on, it’s a different sport
- David has tried to look at the impact of rapamycin on specific methylation patterns, not only on the DNA itself, but also on [histones](https://en.wikipedia.org/wiki/Epigenetics#Histone_modifications) and using a variety of different tools
  - He never published this because they almost found nothing specific, and all the impacts really were from the cell cycle delay
    - Once you sort of normalize that away, you couldn’t say that mTOR inhibition is regulating K27 this or that (that signal wasn’t there)

**How would that explain what we saw with six weeks of mTOR inhibition?**

- Peter adds that six weeks in a mouse might be analogous to a year or so in a human’s life
- The point is, in a relatively short period of time, you have a log-function change in the immune system of the older mouse
- It’s hard to understand how that could be explained by something that is just cell cycle-specific and not a fundamental rewriting of the genetic code of that cell (it seems so profound)
- David points out, “*This gets to the fundamental question here is what is wrong with the aged lymphocytes and what does rapamycin do to them to fix that?*”
- We always imagine there’s a signal transduction pathway from mTOR1 to a specific epigenetic change, but David has found no change in cells in culture
- Inhibition of mTOR in a living system with lymphocytes that are impacted by many different signals coming at them will acquire a different state that’s reflected epigenetically (same as what Matt said)
- [Rick Young](https://biology.mit.edu/profile/richard-a-young/) always used to say, “*Epigenetics is the setting of the state, not the thing that gave you that state at the beginning*”
  - This is an important distinction
- Those cells will be in a different state, but how they got to that state (which in essence is what we’re asking), we don’t know
- These cells are in a different state but there is no evidence from cell culture of an altered epigenetic state

**Matt adds a couple of thoughts**

- If you go back to the **hallmarks of aging**, which there used to be [9](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/) and now there’s [12](https://pubmed.ncbi.nlm.nih.gov/36599349/) (summarized in the figure below), epigenetic changes is only one of the hallmarks of aging

![](https://peterattiamd.com/wp-content/uploads/2023/09/f1-davidandmatt.png)

**Figure 1. 12 hallmarks of aging**. Image credit: [*Cell* 2023](https://pubmed.ncbi.nlm.nih.gov/36599349/)

- You can find evidence in the literature that rapamycin impacts all 12 hallmarks of aging, but the link between rapamycin and epigenetics is much weaker than some of the other hallmarks
  - Like mitochondrial dysfunction, proteostasis, nutrient signaling
- It’s not as obvious, but Matt thinks rapamycin is going to impact epigenetic changes with aging
- This gets back to the complexity of the downstream part, which we haven’t even touched on
  - All the different things that mTOR complex 1 and mTOR complex 2 regulate
- Specifically for the immune system, Matt speculates that there’s reason to think this is partly the case (at least conceptually)
  - Immune function does not decline globally with aging
  - There is a decline in the ability of the immune system to respond to certain challenges and hyper-activation of the immune system towards other challenges it shouldn’t respond to
    - That’s why we get so much autoimmunity with aging or this sterile inflammation
  - From a very simplistic conceptual perspective, you could imagine that ***one of the things rapamycin is potently doing is knocking down this hyper-activation*** (this is something Matt has wanted to mention)
- In both the [Mannick](https://pubmed.ncbi.nlm.nih.gov/25540326/) and [Pan Zheng](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4020596/) study, the vaccine was given after the transient treatment with rapamycin was stopped
  - Matt would really like to know what happens if those mice (or people) were continuing to receive rapamycin when they got the vaccination
  - In the context of that design, you could easily imagine six weeks of rapamycin is enough to knock down chronic sterile inflammation to the point where you have a resetting of immune function, which then allows the immune system to appropriately respond in a way that functionally is like a young immune system to a vaccine
- Matt thinks, “*You don’t even have to say that this is fundamentally an epigenetic phenomenon to account for the observation functionally*.”
- We can rejuvenate the ability of the immune system to respond to a vaccine and potentially protect against a bunch of other types of infections going forward
- He also thinks that’s how you can account for the persistent effects that we see with rapamycin treatment transiently in mice in other places like the heart or the brain or the ovaries or the oral cavity where we know that 6-12 weeks of treatment is enough to apparently functionally rejuvenate those tissues and organs
  - And that that effect persists for some period of time going forward after you stop the treatment

***This begs a question: To cycle or not to cycle***

## Side effects of rapamycin and impact on mental health: fascinating results of Matt’s survey of people who use rapamycin off-label [1:42:00]

- Matt authored a [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10187519/) that came out earlier this year that surveyed over 300 people using rapamycin off-label (a completely legal thing to do; it just means there is no indication for its use)
  - He compared them to a group of nearly 200 who were not rapamycin users, but were hopefully as similar as possible in terms of their health consciousness (which would be an obvious confounder)

**Can you give us some of the highlights of what that survey discovered?**

*Demographics of the participants*

- Matt points out, “*It’s important to be cognizant of all of the limitations that go along with the study like that because it was all self-reported, all survey-based.*”
- They got lucky in the sense that the two populations (users and non-users of rapamycin) appear to be pretty similar in terms of demographics and lifestyle habits
  - They are similarly health conscious, and it’s clearly a biased cohort
- If you look at the responses that the individuals gave to the surveys (he doesn’t have the data in front of him; see the table below) in terms of lifestyle factors this is a population that is not normal for what we would think of as “middle America”
  - They are much more health conscious than I think we would see if we had a swath of just middle America

![](https://peterattiamd.com/wp-content/uploads/2023/09/f2-davidandmatt.png)

**Figure 2. Table 2** Image credit: [*GeroScience* 2023](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10187519/)

**Side effects from rapamycin**

- There really was no evidence when you looked between the people who were using rapamycin off-label and the people who’d never used rapamycin for significant side effects of any sense other than mouth sores
  - One of the surveys was a list of 30 or 40 potentially common side effects that have been associated with rapamycin or with other drugs, and the question was very simple, for people who’d been using rapamycin for at least three months, “*Have you experienced any of these in the past three months?*” (and then for people who’d never used rapamycin, same question)
  - The only thing that came out as statistically significantly more common in the rapamycin users was **mouth sores**
    - That makes perfect sense because that’s the most common side effect that organ transplant patients experience
    - Peter has [talked](https://www.instagram.com/p/CEFIyFCJyR_/) about his experience with mouth sores
    - He has a wicked one at the base of his tongue right now that he almost burnt before this podcast
  - In a sense, this side effect is a nice positive control
    - Peter agrees that it’s his only biomarker to know that he’s getting high quality rapamycin
  - Peter asks, “*What’s the frequency of mouth sores?*”
    - He recalls in the Mannick study, it was a low dose of rapamycin (5 mg weekly), and 15% reported mouth sores
    - Results from this survey were similar

*Any idea what’s happening? Are these mouth sores believed to be immune mediated?*

- Matt doesn’t have a good explanation
- David points out that you’re not looking at the rest of your GI tract, and these are epithelia that are turning over in a couple of days
  - We know from genetic and pharmacological studies that rapamycin tends to impact hyper-proliferative cells
  - For example, if you look at the impact of mTOR [hypomorphs](https://en.wikipedia.org/wiki/Muller%27s_morphs#Hypomorph) in brain development, it tends to be when you make the [telencephalon](https://en.wikipedia.org/wiki/Cerebrum), the cortex where there’s massive burst of proliferation
  - [Lymphocytes](https://en.wikipedia.org/wiki/Lymphocyte) divide every eight hours, that’s pretty atypical for a mammalian cell

***David would argue that the epithelial are proliferating fast and you’re slowing it down and perhaps losing barrier function***

- Peter notes that side effects are not seen in the fingernails and hair, which are the other places you would expect to see it based on chemotherapy
- David points out, “*If you give high dose rapamycin before you give some chemotherapy, you can actually prevent some of the hair loss you get in mice when you give chemotherapy. But then as soon as you remove it’s clear that you just arrested the cells and then they all sort of fall out afterwards, sort of in a block.*”
- For mouth sores, David has asked people in the pharma world, “*Why don’t people do* [*FK506*](https://en.wikipedia.org/wiki/Tacrolimus) *mouth washes?*”
  - [***Stuart Schreiber***](https://www.broadinstitute.org/bios/stuart-l-schreiber) ***showed this ages ago that if you occupy the FKBP with FK506, rapamycin has nothing to act on in your mouth and you’ll prevent this***
  - Or even with a benign rapamycin-like molecule
  - All you need is an FKBP binder to sop up the binding sites that rapamycin would use
- Peter thinks it probably depends on the frequency with which you do it and what FK506 tastes like
- David points out that there are rapamycin, FK506 analogs that are completely inert
  - They simply bind to FKBP, but they can’t target [calcineurin](https://en.wikipedia.org/wiki/Calcineurin) (in the case of FK506 or mTOR), and all you need to do is tie-up your FKBP
- Matt thinks this would be an interesting experiment, and David is probably right
- But this makes the assumption that the mouth sores are actually caused by inhibition of mTOR in those cells inside the mouth
  - And we don’t formally know that at this point (David agrees)

**Matt’s more interesting experiment**

- Would a rapamycin toothpaste or mouthwash (something specifically delivered to the oral cavity) be sufficient to get some of the benefits that we’ve shown in mice from systemic rapamycin treatment on periodontal disease, gingival inflammation, and bone growth around the teeth?

**Back to the side effects of rapamycin**

- There were other side effects (see the table below), but they were all *lower* in the people taking rapamycin

![](https://peterattiamd.com/wp-content/uploads/2023/09/f3-davidandmatt-678x1024.png)

**Figure 3. Table 5**. Image credit: [*GeroScience* 2023](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10187519/)

- This included things like abdominal cramps, and ***they’re harder to develop hypothesis around***

**The side effects Matt thought were interesting were depression and anxiety**

- There’s a growing body of literature on the role of mTOR and inhibition of mTOR in various types of neurocognitive behavioral aspects
- It makes Matt wonder if rapamycin could actually have what appear to be beneficial effects on things like depression and anxiety (though they may not always be beneficial)
- That is certainly worthy of further study
  - There are some people working with rapamycin sometimes in the context of ketamine for things like depression, chronic pain

**What is ketamine doing to mTOR?**

- David thought it was the opposite, that rapamycin caused depression in other trials
  - The ketamine study argued that as well
- Peter asks, “*Because ketamine is activating mTOR in the CNS, isn’t it?*”
- The clinical trial data that Matt is familiar with is in the context of **rapamycin in combination with ketamine**, enhancing the effects of ketamine
  - Both in terms of magnitude and how long they last
  - In other words, when you combine rapamycin with ketamine, you can sometimes go to a lower dose and reduce the frequency at which patients are using ketamine
  - Matt thinks a lot of this is not published
  - There are at least a couple of studies that have showed a potentiating combination effect of rapamycin with ketamine in patients with severe depression
    - But he doesn’t remember for sure off the top of his head
- Matt has talked to psychiatrists who are using this combination, and they give anecdotal reports of pretty potent outcomes in some patients who have severe chronic pain from combining rapamycin with ketamine

**Matt’s takeaway ‒** it’s pretty early and a lot of this is being done off-label and it’s not written up the way would like it to be reported in the literature to allow other people to learn from each other, but there are a lot of people using rapamycin in combination with ketamine now in clinical practice

- David recalls work from [Duman](https://www.nature.com/articles/s41593-020-0629-3) at Yale: The original ketamine [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3116441/) argued that rapamycin blocked the effect of ketamine, and part of that argument was that mTOR was involved
- David asks, “*Matt, were you’re saying that there’s some discrepancy there, and it might be blood-brain barrier access, it might be things like this that are quite different and very dose dependent?*”
- Matt thinks we need to go back to that original study and make sure we’re all on the same page
- He recalls from conversations with people who are using this now, that people are using the combination of rapamycin with ketamine and reporting pretty significant changes in outcomes, at least anecdotally

*Is ketamine given intranasal, intravenous, intramuscular? Does it matter?*

- Matt doesn’t know; this is outside his area of expertise

## The impact of taking rapamycin in people who contracted COVID-19: more insights from Matt’s survey [1:51:15]

**The population in Matt’s survey**

- One of the **confounders** that jumped out at Peter was that if you have a healthier population who is more health conscious (and that’s why they’re taking rapamycin), that could easily explain the observation that they got COVID less
  - And when they got it, they were less impacted by in
- Within the two groups (people who had ever used rapamycin and non-users), there were three categories of people in the context of COVID-19 infection
- 1 – Some people didn’t start taking rapamycin until after they had a COVID-19 infection
- 2 – Some people took rapamycin before infection, but not after or not during
- 3 – People who took rapamycin continuously throughout

***Matt tried to group them in that way and look to see if there were any differences between the groups***

**Findings**

- 1 – It made no difference in the frequency of infection (that was significant)
  - So there’s reason to believe based on our data that rapamycin impacted the likelihood that somebody would get a positive COVID-19 result
  - Remember, this is self-reported ‒ people reported a positive test but there is no laboratory confirmation
- The interesting thing was that the people who took rapamycin after they got their COVID-19 infection looked just like the people who never took rapamycin
  - That makes sense, they shouldn’t
- They were looking at two things: severity of infection (again self-reported as mild, moderate or severe, and they had specific criteria for length of symptoms and hospitalization for each of those groups) and then self-reported long COVID (as in experiencing ongoing symptoms of COVID after a three month period)
- 2 – No difference between people who started taking rapamycin after their infection and non-users
- 3 – No difference between people who took rapamycin before their infection but stopped taking it
- 4 – There was a big, statistically-significant difference between people who took rapamycin throughout and all of the other groups
  - Where people who took rapamycin throughout had lower severity of infection
  - But the numbers were really small, so Matt doesn’t want to make too much of it
  - They were significantly less likely to report symptoms associated with long COVID

***Matt thinks this is suggestive of the idea that continuous rapamycin use throughout the period of infection and resolution of symptoms may be associated with a lower likelihood of severity of outcome and lower likelihood of long COVID***

- To Matt, that might make sense in the context of how we think (at a crude level) long COVID is working in severe COVID infections ‒ there’s this hyper-inflammatory or chronic inflammatory response
  - It makes sense that rapamycin use may have benefits in the context of that prolonged inflammation or hyper-inflammatory response, and that might explain what he saw in the data
  - But it’s just suggestive and worthy of future work to really disentangle
- Matt doesn’t think there’s any reason to think this is specific to COVID-19
  - This may be a general property of rapamycin for a bunch of different types of viral infections

## What David would like to study with mTOR inhibitors [1:54:45]

**David, you mentioned a moment ago you’ve never taken rapamycin, obviously Matt and I have, say a little bit more about that**

- Peter adds, “*Obviously you’re one of the most knowledgeable people on this topic*”
- David used to joke that when he was purifying mTOR he got a huge dosing, and given that early exposure is better, he got the benefit then
  - It’s a powder and he never wore gloves
  - He remembers it would get into his nose, so he snorted rapamycin inadvertently
- David wonders, if you eat okay and you exercise, if rapamycin is a mimetic to some extent of a healthy diet
  - He knows it’s more complicated than that
- He wonders if we’re getting that extra benefit right at the doses we’re talking about
  - Dose would be his biggest question
- He’s not afraid to take rapamycin, but he wonders, “*Would it actually do anything?*”
- Peter asks, “*But isn’t there sort of a hedging or a Pascal’s wager, which is as long as you could convince yourself that it’s not harmful, would the worst thing you’re doing is wasting a lot of money because it ain’t cheap?*”
  - David agrees
  - But the laziness factor comes in for figuring out how to do it and stuff

**What David would really like to study**

- Cyclical dosing
- David is interested in, “*What can’t I do?*”
- If he starves himself, his body synthesizes certain nutrients and breakdowns other things to release them
- When you look at the metabolic state of a mouse that you’ve starved, the levels in the blood are pretty similar
- So David can’t through dietary interventions starve a cell of nutrients like he can in a dish
  - The body fights that
  - And of course eventually you run out of stores and you die, but in a normal type of starvation situation
- What David is much more curious about is, “*Can I use rapamycin or other mTOR modulators (perhaps God forbid even catalytic inhibitors) to take that system to a state that I cannot simply do of a dietary intervention whatsoever?*”
  - And obviously that is not sustainable in any chronic way (we know that)
    - If you give a catalytic inhibitor to a mouse you can kill a mouse fairly easily
    - It’s hard to kill a mouse with rapamycin

**Remind folks the difference between an allosteric and a catalytic inhibitor, and what that actually is doing in the case of mTOR**

- The **allosteric inhibitor** (rapamycin and derivatives) is going to do this partial inhibition of mTORC1
  - Going back to Peter’s cave analogy, this is the rock that partially obstructs the cave entrance
  - It will also partially inhibit mTORC2
  - There’s going to be perhaps some tissue specificity, some kinetic differences
- A **catalytic inhibitor** is a molecule that will compete with ATP, which is what mTOR uses to do all its business [also called an ATP-competitive inhibitor]
  - That will obliterate mTORC1 and mTORC2 activity when given at the right doses
  - In David’s hands, this is toxic to cells and to organisms
    - If you miss-dose by mistake with a catalytic inhibitor, the mouse will drop dead

*When you say drop dead, are you talking about the same way where mitochondrial inhibitors like cyanide immediately cease respiration and will kill an animal within seconds?*

- No, it usually takes a couple hours
- The mouse will stop moving, it gets cold, sometimes it’ll have seizures, but it will die
- Rapamycin does *not* do this
- One has to be careful with catalytic inhibitors
- Catalytic inhibitors were molecules that were initially thought to be potentially good anti-cancer agents
  - David made some of the first ones
  - But experience has shown that they have lots of side effects
- David has always wondered, “***Can those molecules in a careful way be done to very much impact this system, massively activate autophagy, massively rewire this system, maybe have epigenetic impacts very short and then come off of that?***”
  - He’s much more curious about that type of study and potential use because he feels that with diet, you can get close to rapamycin’s impact
    - This is his personal belief with some data to support it
  - But you can’t get close to with diet is what a catalytic inhibitor can do

**David said this point in a way that Matt has never thought about but is important**

- Rapamycin is very different than dietary restriction
- They’re overlapping, but they have lots of differences

> “*You can’t have the same impact on mTOR systemically in tissues with dietary restriction that you have with rapamycin*”‒ Matt Kaeberlein

***The other side of that though that’s equally important maybe, is that dietary restriction does a bunch of other stuff that rapamycin doesn’t do, and the potential benefits and negative consequences of all of that other stuff are often not weighed into the equation when people are thinking about diet and comparing it to rapamycin***

**Matt makes two points about catalytic inhibitors of mTOR**

- Most of these catalytic inhibitors are less specific for mTOR than rapamycin
  - Meaning many of them affect other kinases
  - Not all of them, but many of them do
  - And there’s this whole class of what people call **dual kinase inhibitors** that hit other kinases
  - Some of these molecules that inhibit mTOR will also inhibit other proteins

## Joan Mannick’s studies of RTB101 and other ATP-competitive inhibitors of mTOR [2:00:30]

- [Joan Mannick](https://milkeninstitute.org/events/fhs19/speakers/39958) (at Novartis, then she went on to resTORbio) published subsequent [studies](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00062-3/fulltext) on RTB101
  - ***RTB101 would fall into this class of ATP-competitive inhibitors of mTOR, but it also inhibits other kinases***
- The point is, the specificity of some of these molecules is less
- And Matt doesn’t know if we know the side effect profile, and how much of that is due to mTOR, mTORC1, mTORC2, or other kinases that these molecules inhibit
- In the studies that Joad did at resTORbio where they dosed people with RTB101, they did *not* see significant side effects
- You can ask whether they saw significant efficacy
- That trial was shut down
- But it is possible at least for that molecule to use it clinically at doses where there’s some reason to believe there might be some efficacy

**In the RTB101** [**trial**](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00062-3/fulltext)**, didn’t they combine it with another agent?**

- Yes, they combined it with [everolimus](https://en.wikipedia.org/wiki/Everolimus)
  - The study had two arms: one was a combination of RTB101 and everolimus and one was RTB101 along

**David’s take on this**

- David was confounded by this study Mannick did
- He was perplexed because they renamed RTB101 NDP103 [maybe BEZ235, mentioned in the [abstract](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00062-3/fulltext) or RAD001 mentioned in an earlier [publication](https://pubmed.ncbi.nlm.nih.gov/29997249/)]
  - This was a Novartis molecule that is a dual mTOR and [PI3-kinase](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase) inhibitor
  - It’s a very dirty molecule
  - David remembers being on advisory panels for Novartis and not understanding why this molecule even existed

***ATP competitive inhibitors are dirtier than rapamycin by far, but not all of them***

- Wyeth had made a compound under the guidance of [Bob Abraham](https://enterprises.upmc.com/team-member/bob-abraham/) (one of the pioneers in mTOR biology) which is exquisitely specific
- You can dial out PI3-kinase activity of the catalytic inhibitors
- But the kinase that was very hard to not also hit was [DNA-PKcs](https://en.wikipedia.org/wiki/DNA-PKcs) (a kinase involved in the DNA damage response)
- The molecule David made ([Torin-1](https://en.wikipedia.org/wiki/Torin-1)), we never managed to dial out DNA-PKcs, But Bob Abraham did
- So this WYETH compound is a beautiful molecule
- When Pfizer bought Wyeth, they deemphasized it in favor of dual activity inhibitors, which David did not agree with

***There are some quite good molecules (these very hyper-specific ones, the ones David uses), and they are bad news for an animal when you use it***

**This gets back to low hanging fruit that hasn’t been studied**

- Matt would love to see somebody take a panel of all of the known mTOR inhibitors in these different classes and just ask the question: “*If you look in an animal model, what’s the relative benefit and side effect profile look like in the context of longevity?*”
- Matt is confident that at least in worms, you will find things that work better than rapamycin (because he’s already done it)
  - He doesn’t know about in mice
- This seems like a really important question to understand the biology of these mTOR inhibitors in the context of aging

> “*To know is rapamycin really best in class or is it just the one that we’ve studied the most? And that seems like a completely unknown to me at this point.*”‒ Matt Kaeberlein

- Peter would guess that it’s not the best in class in the same way the the first of anything can always be perfected

**David wants to know**

- The balance between full mTORC inhibition and total mTORC2 inhibition [to understand the biology of these in the context of aging]
- One of the reasons why this hasn’t been done is that catalytic inhibitors are very challenging to use
  - They’re very [hydrophobic](https://en.wikipedia.org/wiki/Hydrophobe) molecules because the catalytic site of mTOR is a very hydrophobic site
  - So everyone who independently made these molecules ended up with very greasy molecules that are not easy to dose in a mouse, very hard to dose
    - You got to put them in detergents, all these things that the mice don’t like either
- David would do that study in an intermittent way
  - That’s the way he would want to do that to sort of mimic
  - A really strong inhibition of this system and then release and see what happens

**Why do you think they put forward RTB101 (which is probably more of a PI3-kinase inhibitor)?**

- Peter points out the problem is when that second study came out (and it was a null study), it somehow got interpreted as, everolimus doesn’t work
  - There’s no scenario under which Peter would make that interpretation
  - Matt, you wrote an [editorial](https://www.sciencedirect.com/science/article/pii/S246850112030002X) on this if Peter remembers correctly

*There were actually three studies [by Joan Mannick]*

- The [study](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00062-3/fulltext#section-7c530872-6235-4433-899c-b3f276970189) where RTB101 was used alone was actually the third, and that was their pivotal clinical trial
- There was a [second phase II](https://pubmed.ncbi.nlm.nih.gov/29997249/) in between the [2014 paper](https://pubmed.ncbi.nlm.nih.gov/25540326/) and the [pivotal paper](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00062-3/fulltext#section-7c530872-6235-4433-899c-b3f276970189) where they used a combination of everolimus with RTB101
- Matt wasn’t in the room so he doesn’t know exactly what went into the thought process of why use RTB101
  - He’s been told there are probably at least two factors that played in
  - 1 – In cell culture models there was some data that RTB101 induced antiviral gene expression
    - So there was some somewhat plausible biological rationale for the endpoint that they were going after
    - In the most recent paper, it wasn’t so much vaccine response, it was subsequent infections
    - And so the thought was if you can both boost vaccine response and enhance resistance to subsequent infections, that might be a combination that was useful
  - 2 – In the second phase II clinical trial, RTB101 showed a signal
  - RTB101 plus everolimus also showed a signal, but RTB101 alone showed a signal
  - You could speculate it might have something to do with patent life and IP around longer patent life on RTB101, clearer path to market
    - Matt doesn’t know for sure
- There was no everolimus in the pivotal phase III clinical trial

**There a couple things about that** [**trial**](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00062-3/fulltext#section-7c530872-6235-4433-899c-b3f276970189) **that are worth mentioning**

- Everolimus wasn’t in there
  - So the failure of that trial absolutely should not be interpreted as a failure of rapamycin or rapalogs because there was no rapalog in that trial
- The trial was only half completed and the decision was made halfway through to stop the trial because they were not hitting their FDA mandated endpoint, which was patient reported infections
  - Not laboratory confirmed, but patient reported
  - That was November of 2019
    - Matt remembers he was at the Gerontological Society of America Conference with Joan when that news came down
    - He was upset, and he’s sure Joan was even more upset
  - If you think about where the world was five months later, they might’ve made a different decision at that point with a drug that could potentially affect vaccine response and subsequent viral infections
- Joan went back and did a subsequent analysis on the data from that half completed phase III
  - In fact, in those patients who got the RTB101, there was a significantly lower risk of subsequent infection for certain viruses, among them influenza viruses, and coronaviruses
    - Not COVID-19, because we didn’t know about COVID-19 when this was happening
    - But coronaviruses as a class, the people who’d gotten RTB101 showed a significantly lower likelihood of a future laboratory confirmed viral infection
- The trial was a failure in the sense that they didn’t get to FDA approval and they shut it down early
- But whether it was actually a failure of the drug, Matt thinks still remains TBD
  - Which is interesting because this wasn’t a rapamycin, it was one of these ATP-competitive mTOR inhibitors
  - But it’s still a little bit unclear if the drug itself actually failed to have an impact on immune function in the population where it was tested
- David adds, “*It was a very dirty catalytic inhibitor, [it] impacts multiple PI3-kinases.*”
  - And that makes it harder from the perspective of even if it did have an impact, how is it working?
    - Is it really through mTOR? Is it through some of these other kinases? Is it a combination?
- David worries that the change in the use of molecules reflects that the original study may have had some issues that we’re not aware of

***That first study that we talked about as a milestone study was so amazing that why wouldn’t you have expanded upon that***?

- David never understood this, and he thinks what Matt said makes a lot of sense
- Matt doesn’t remember when everolimus went off patent, but it’s been a few years now
  - The patent clock was ticking and he speculates that had something to do with the decision
    - This would be Peter’s “Occam’s razor” answer to that question
- David points out that there are many rapamycin derivatives now, and they could have picked one of those
  - They’d have to go through lot of preclinical studies and things

## The impact of mTOR inhibition on autophagy and inflammation, and a discussion of biomarkers [2:10:00]

- David talked a lot about the impact of mTOR inhibition: [Autophagy](https://en.wikipedia.org/wiki/Autophagy), reduction of inflammation
- We haven’t talked a lot about the tamping down of senescent cells and potentially the reduction of the soluble or secretory factors
  - There is an impact on [proteomics](https://en.wikipedia.org/wiki/Proteomics)

**One would think that the impact on autophagy might be most responsible for the altering benefits we see**

*Which pathways would you rank order as the ones that are driving this?*

- Peter asks because it comes down to **biomarkers**
  - If we believe this is dominated by autophagy, then we need biomarkers for autophagy
  - If it is dominated by inflammation, then we need better biomarkers for inflammation
- David explains: “*When you think of things downstream of mTOR, you can do a PubMed search and find mTOR and rapamycin, literally connect it to anything you want. Why is that?*”
- Either there’s a specific signaling pathway to that process or there’s a simpler explanation, which to him is that **mTOR is a major regulator of protein synthesis**
- And if you inhibit mTOR enough, particularly if a catalytic inhibitor, you inhibit protein synthesis
  - So you will impact everything
- There is the class of downstream molecules that are impacted simply by impacting protein synthesis
  - He puts those in a very sort of broad category that he doesn’t know how to study them or think about them in any kind of specific way
- There are then a whole series of processes in which there are truly molecular connections, direct specific molecular connections that mTOR regulates
- As Peter said, autophagy (the self eating of cellular components and destruction in the lysosome) (that came up in the discussion earlier), and we know about that pathway:
  - We know how it regulates protein synthesis
  - We know how it regulates [transcription factors](https://en.wikipedia.org/wiki/Transcription_factor), like [TFIIB](https://en.wikipedia.org/wiki/Transcription_factor_II_B)
  - If you had to put in the molecular target of mTOR that’s emerged in the last 10, 15 years as very interesting and prominent, it’d be TFIIB
  - TFIIB is a transcription factor that promotes the production of lysosomes, these recycling organelles

**David’s answer:** ***If I had to pick one process that is prominently regulated by mTOR and probably accounts for some of its health benefits, I would pick autophagy***

- Part of that is based on a [worm study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2242811/) where they actually tried to look at that
  - They did mTOR inhibition, and then they looked at downstream pathways genetically and found the biggest impact of perturbing autophagy
- Part of it is based on common sense, it breaks down old things and allows their rejuvenation
- The counter to this statement is, “*Why does mTOR impact aging and why do other things not?*”
- David explains with an **analogy of an old house**: You can’t prevent the aging of an old house or much less rejuvenate an old house by having a plumber, having an electrician
  - You need a general contractor that brings in all those people because an old house has everything wrong with it
- And so David thinks to some extent, we almost can’t ask the question, “*What is important downstream of mTOR?*”
  - Because the answer is, mTOR is special because it does a lot of things and therefore we can’t find one thing that replicates mTOR, otherwise we would’ve already found those things

**David’s takeaway** **‒** ***autophagy is the major one, but the real answer as to why mTOR (and thus rapamycin) is special is that mTOR does a lot of stuff, and to impact the aging process, you have to do a lot of stuff***

- This goes back to a question David always asks aging researchers, “*Tell me one thing in a cell that’s not broken with aging.*”
  - The answer is, there isn’t one thing that’s not broken
  - Therefore, to fix or prevent that, you have to act on many processes

**Matt’s take on this**

- Matt doesn’t disagree and thinks the house analogy is a nice way to think of it
- mTOR globally regulates a lot of different things, and it’s probably multiple downstream processes that play a role
- **Autophagy** may be the most important single downstream directly regulated mTOR process for a bunch of different aging effects (broadly speaking) is not inconsistent with the idea that in a mammal or in a person, the **anti-inflammatory effects** may account for most of the functional benefits that we see when we treat an old animal

***It’s likely that the specific effects of mTOR may be different in different contexts, different tissues, different pathologies***

- For example, in hypertrophy, the effects of mTOR on cell size may be most important
- In cancers, the effects of mTOR on the cell cycle may be most important
- Both of those are tied into autophagy

***Matt doesn’t know that we’re going to be successful trying to point to one thing and say, “That’s the most important thing.”***

- David’s absolutely right that in *C. elegans* [a worm] at least, most if not all of the benefits of inhibiting mTOR can be directly attributed to activation of **autophagy**
- But you go to yeast, it seems to be mostly the effects on **global mRNA translation**
- And that may fit with the idea that context is important for which of these downstream processes are weighted most importantly for the effects we see in the context of aging
- In the last 5-10 years, Matt has very much shifted his thinking toward the **anti-inflammatory effects**
  - In the context of people and other mammals
  - Particularly the ability of rapamycin to knock down sterile inflammation in the context of an aged animal
  - A lot of the benefits that we see in terms of organ and tissue function can be plausibly traced back to that effect of rapamycin

**Peter’s takeaway** ‒ if we want to get a better handle on dosing, we should look deeper into the biomarkers of inflammation

**Biomarkers**

- Everybody gets their [C-reactive protein](https://en.wikipedia.org/wiki/C-reactive_protein) checked, but we could be looking at a whole suite of [interleukins](https://en.wikipedia.org/wiki/Interleukin) and other [cytokines](https://en.wikipedia.org/wiki/Cytokine)
- When it comes to autophagy, we’ve got a whole lot of nothing
- It’s probably been three years since Peter discussed this with [Eileen White](https://ludwigcancer.princeton.edu/people/eileen-white) (one of the world’s experts on autophagy, [episode #114](https://peterattiamd.com/eileenwhite/))
  - She agreed that we need a biomarker here because outside of a lab where you can afford to take tissue, you don’t have much to go on

## The Dog Aging Project: what we’ve learned and what’s to come from testing rapamycin in companion dogs [2:17:30]

**Can you tell us a little bit about what we’ve learned in rapamycin as we’ve pivoted to companion animals?**

- Peter asks, “*What is it about cats and dogs that are interesting?*”
  - Well, first of all, they’re a heck of a lot closer to humans than mice are, but they’re also not genetically inbred the way mice are
  - They live in our environment, not a sterile environment
  - They consume food that probably looks a little bit more like the food we would consume, at least in some cases.
- This study has occupied more than a decade of Matt’s research
- Matt adds two things about companion animals:
  - They age more rapidly than people do
    - This is super important because it means we can measure outcomes of interest in a timeframe that’s compatible with a clinical trial
  - Dogs and cats matter
    - More than 50% of people say that their pet is part of their family
    - There is an intrinsic value in developing therapies that can improve health span and longevity of companion animals from that perspective
    - Peter’s interpretation: Even if we learned nothing about the longevity of humans, this would be a worthwhile pursuit in the way nobody actually cares how long mice live or how long *C. elegans* live
- Matt would also say, “*It’s ridiculous to think we’re going to learn nothing about the biology of aging in humans from studying companion animals*.”
- Matt has been involved with the [Dog Aging Project](https://dogagingproject.org/) for a while
  - He started it with [Daniel Promislow](https://dlmp.uw.edu/faculty/promislow) and [Kate Creevy](https://experts.tamu.edu/expert/kate-creevy/) 12 years ago
- There is a good rationale for companion dogs as a model for the biology of aging, and also to be able to assess the effects of rapamycin on lifespan and healthspan metrics
- They are running a real clinical trial (double-blind, randomized, placebo controlled, veterinary, clinical trial) to answer the question, “*Does rapamycin slow aging, increase lifespan, improve multiple health span metrics in a reasonable timeframe?*”
  - It’s called the Test of Rapamycin in Aging Dogs
- They did two shorter-term pilot trials to establish safety and work out the dosing
  - Also double-blind, placebo controlled
- They started the larger clinical trial triad a few years ago, which unfortunately coincided with the beginning of COVID-19
  - That was challenging
  - They worked through that and are making progress

**Veterinary clinical trial: Test of Rapamycin in Aging Dogs (**[**TRIAD**](https://hospital.vetmed.wsu.edu/2022/03/28/dog-aging-project-triad-study/)**)**

- This is a trial that will ultimately enroll 580 dogs, half get placebo, half get rapamycin
- The treatment period is three years
- We’re looking at multiple measures of health span including cardiac function, neurological function, activity, cognitive function, there’s a few others, but most importantly, lifespan is the primary endpoint
- With that cohort size, that length of treatment, we are ***powered to detect a 9% change in lifespan***
  - Change in total lifespan
  - It’s a bigger number for remaining life expectancy
  - They settled on 9% because this is towards the lower end of what’s been reported in mice
    - The [2009 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) (discussed earlier) starting treatment in middle age in mice
- Even if rapamycin extends lifespan in dogs and in people, will the magnitude of effect translate?
  - That’s a different question we don’t know the answer to, but it makes sense to start in the right ballpark in terms of what we think might be a reasonable thing to expect for longevity
    - That’s why they went with this cohort size
- Criteria for inclusion in this study:
  - Dogs have to be at least seven years old at the time of randomization
  - Dogs can’t be sick or have any significant preexisting age-related disease
    - This is important because the vast majority of clinical trial done today (on either companion animals or people) are disease-specific trials in patients who already have a preexisting disorder
  - Dogs have to be between 40-110 lbs, for the simple reason that big dogs age faster than small dogs
    - In order to get the statistical power that they need, they are working in a population of dogs that are more rapidly aging than a smaller weight population

> “*This is a study of normative aging… Dogs are still actively being enrolled.*”‒ Matt Kaeberlein

- David remarks, “*You earlier asked me if I take rapamycin, and my friends ask me whether they should take rapamycin because they know you take rapamycin.*”
  - He always says, “*When Matt Kaberlein’s dog study reads out, if it’s positive, I’ll take rapamycin*.”
- Peter says that a lot to his patients as well
  - He has a really strong conviction, it’s modestly held
  - It will be a lot more of a strong conviction one way or the other in 2026 (which is about the time when we’ll have the readout of this study)

***A lot of people, are looking to this study potentially along with the work of*** [***Adam Salmon***](https://barshopinstitute.uthscsa.edu/team-member/salmon-adam/)

- Matt adds that even though they’re powered for lifespan as the primary endpoint, he’s not sure that is the **most important endpoint** for evaluating potential efficiency of rapamycin in dogs or people
- There may be some healthspan metrics that are positively impacted by rapamycin
- People just want to make sure there’s no negative effects on lifespan
  - Matt would be shocked if they see a shortening of lifespan from rapamycin treatment
  - Not to say that there aren’t side effects from rapamycin

**Peter’s takeaway** ‒ If you’re not seeing lifespan get shorter or an uptick in cancer or something unexpected, then these healthspan benefits in terms of ejection fraction, periodontal disease, and the like, that would probably be sufficient enough reason [to endorse use of rapamycin]

## Preliminary results of primate studies with rapamycin [2:24:45]

**The work of** [**Adam Salmon**](https://barshopinstitute.uthscsa.edu/team-member/salmon-adam/)

- There is a super interesting study in a non-human primate called a [marmoset](https://en.wikipedia.org/wiki/Marmoset)
  - They aren’t as long-lived as [rhesus monkeys](https://en.wikipedia.org/wiki/Rhesus_macaque), which typically live 30-40 years
  - Marmosets are a little bit of a moving target as people are starting to use them more in captivity and are learning about their life expectancy
    - Life expectancy seems to be in the low to mid-teens
  - They have a shorter lifespan in captivity [7-8 years] and that makes them an interesting non-human primate model to study aging
- For several years now, [Adam Salmon](https://barshopinstitute.uthscsa.edu/team-member/salmon-adam/) has had an ongoing marmoset colony in San Antonio
  - Some of whom have been getting rapamycin, but they haven’t published lifespan data yet
- They’ve [published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6415526/) some preliminary data for bioavailability, blood levels
- Adam has talked in meetings about the apparent survival benefits where it looks like rapamycin may be having positive survival effects in marmosets

**Limitations of studies using animals in captivity**

- Matt points out a big limitation from that study: It was done in captivity
  - Matt points out, “*I don’t think any of us believe that rapamycin alone at lower doses is a potent immunosuppressant. But when you’re out in the real world, and exposed to all sorts of environmental challenges, it may be the case that the effects of rapamycin are going to be somewhat different than what we see in the laboratory.*”
- For David, one of the big issues with the mouse studies of rapamycin is that these are sedentary mice who are getting fat and depressed
  - A critical aspect of studies is that they are free living animals who presumably are relatively happy
- The marmoset study sounds exciting but it has a big caveat of potentially more sedentary sad animals in a cage
- He hadn’t even thought about the potential infectious disease implication of it

***David is looking forward to results of Matt’s Dog Aging Project because these are animals living in the human environment***

## Dosing of rapamycin [2:27:45]

**What was the dosing in your study, Matt?**

- In the [Dog Aging Project](https://dogagingproject.org/), they first [tested](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/) two doses: 0.1 mg/kg 3x a week and 0.05 mg/kg (so half of the first dose) 3x a week
- Then they went to 0.15 mg once a week, and that’s what they’re using now
- Anytime you’re trying to design a clinical trial, there’s an infinite number of variations on dosing and how you deliver

***They decided to go with a dosing protocol of 0.15 mg/kg once a week for the large clinical trial based on the outcomes from the two shorter*** [***trials***](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/) ***in terms of total dose (so cumulative dose)***

**Rapamycin dosing**

- **Once weekly dosing** has become popular in the biohacking community based on Joan Mannick’s study, the observation that once weekly dosing with everolimus seemed to give similar efficacy with maybe lower potential side effect risk
- And from a pragmatic perspective, because the owners are giving the drug to their dog, they thought owners would be able to consistently remember to give the drug to their dogs once a week as opposed to three times a week (that’s speculation)
- Peter adds, “*If you try to triangulate between the everolimus study, your studies, Adam’s studies, and the ITPs, you sort of coalesce around 0.1 mg/kg weekly for a human, which is kind of putting people (someone my size maybe a bit more)… it’s probably 8-12 mg*.”
  - Matt is not sure about that
- One of Matt’s biggest concerns with the dog study is that their **dose is too low**
  - You’re trying to weigh risk reward
  - In people’s pets, the tolerance for risk is extremely low
  - Matt is concerned that they are using a dose lower than what might be the optimal dose
- At the doses they used in the two shorter [trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/), they saw evidence for beneficial effects
- Matt’s recollection of the mouse study is that the dosing works out to something close to 0.1 mg/kg/day in people (not per week)
  - He admits he needs to go back and look at these studies
- Peter agrees, in the ITP, mice were given 1.4 mg/kg/day in mice
  - There’s a conversion factor to convert that to human dosing, and it works out to 0.1 mg/kg/day
  - Mice were getting much more rapamycin [than dogs in Matt’s study]

> “*That speaks exactly to the concern we have, which is, how do you know if you’re getting enough?*”‒ Peter Attia

- Peter adds that the only reason we may still settle on this **weekly dose** is that we saw positive immune modulation with 5 **mg a week of everolimus** (that’s even less)

***The fundamental difference that David hears from this discussion is that the mouse study is really a chronic dosing***

- The Mannick study provides the best evidence for an **intermittent dosing,** having a clinical output that is beneficial

**Matt sees two questions**

- 1 – Is the dosing when you think about daily versus weekly versus every other week, that sort of intermittent dosing
- 2 – Then there’s the question of the interval of dosing, how long do you need to dose?
- Those are two different variables that are both poorly unexplored, even in the mouse studies to really tease out where you see different benefits or where you get the biggest benefits

**What doses of rapamycin are people using in** [**Matt’s survey**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10187519/)**?**

*What percentage of the rapa users were on weekly doses versus daily doses versus tri-weekly?*

*What was the range of the actual dose?*

- It was all over the place

***The vast majority were taking 6 mg once a week***

- This comes partly from Joan Mannick’s study which used 5 mg of everolimus once a week
- Many of the first people to start taking rapamycin off-label were patients of [Alan Green](https://www.doximity.com/pub/alan-green-md-2b33c2bb) out of New York, and that was sort of the standard dose that he put most people on
  - That’s Matt’s impression of how this dose became popularized
- There’s a fraction of people who are taking rapamycin **daily** (usually 1 or 2 mg), sometimes for purposes other than purely for aging
  - So people who have existing autoimmune disorders are sometimes taking rapamycin for that
- In general, among the off-label rapamycin users, the majority are once a week, and of those, the majority are 6 mg
  - It’s kind of a bimodal distribution as there is a group of people around 3 mg
  - But there’s lots of variation around that

**What were some of the higher doses you saw for the once weekly folks?**

- The highest dose was close to 20 mg once a week
- It was difficult to tell how long people had been taking rapamycin at those doses
  - The longest was 5-6 years
  - The majority was 6 months
  - People who reported taking 20 mg once a week could have just started doing that
- A lot of these are [N of 1 experiments](https://en.wikipedia.org/wiki/N_of_1_trial) with people who are changing their regimens as they go
- There are some people who are taking 6 mg once a week, but they’re trying to build it up to a higher dose to see where they start to get side effects
- There are a bunch of people who reported taking grapefruit juice with their rapamycin because grapefruit juice will inhibit [cytochrome P450s](https://en.wikipedia.org/wiki/Cytochrome_P450) and enhance bioavailability of rapamycin
- Matt says this to both illustrate the sort of nature of complexity of this population, but also because we know there’s going to be genetic variation in uptake of rapamycin, and how quickly the drug is metabolized
  - The dose that somebody is taking may or may not really reflect the total bioavailability or the [kinetics](https://en.wikipedia.org/wiki/Pharmacokinetics) (trough level, peak level)

**Downsides of compounded formulation of Rapamycin**

- Peter points out that rapamycin is not a cheap drug, the most competitive price you’ll find if you’re using [GoodRx](https://www.goodrx.com/) works out to about $5 a milligram
- [Rapamune](https://www.rxlist.com/rapamune-drug.htm) is the brand name made by Pfizer
- [Sirolimus](https://en.wikipedia.org/wiki/Sirolimus) is the generic
- A lot of compounding pharmacies will make it for you instead of giving your Rapamune, but Peter would *caution* people against using any compounded formulations
  - They are a lot cheaper,  but you have virtually no guarantee of the purity or the concentration
  - We’ll have a podcast that covers the ins and outs of compounding pharmacies
    - They’re not all bad, but you absolutely want to be able to make sure you have FDA certificates for what you’re using, and just be careful with the quality control

***Matt adds that there is some data out there on compounded rapamycin having essentially no bioavailability if it’s not in an enteric capsule***

- This actually goes back to the reason why the ITP took 20 months to start their experiment as rapamycin is unstable at gastric pH
- And so if compounded rapamycin is not in an enteric-coated capsule, you’re essentially going to get zero bioavailability

***Peter suggests you splurge and get either sirolimus or Rapamune***

## The effect of rapamycin on fertility [2:36:45]

**If Peter were a billionaire, what would he do?**

- He would set up a research institute that would fund this type of work with no profit motive because nobody would care to fund this if you were profit driven

***The fact that no one’s really looked at the impact of rapamycin on ovarian aging is really frustrating; you could also look at the impact of rapamycin on spermatogenesis***

- We are reproducing at a later and later age in life, and fertility is such an important part of that, especially as we experience population decline
- Anything we could do to better understand how to preserve the youth of sperm and egg, would be really fascinating
- Peter thinks there is someone looking at this in Brazil, and someone looking at this here in the U.S., but he hasn’t heard enough from it

**Do we know anything yet about the impact of rapamycin on fertility?**

- Matt explains: It’s pretty clear in mice (**female mice**) that you can delay or probably even reverse ovarian atrophy up to some point in life with transient rapamycin treatment
  - Actually restore reproductive capacity to sterile female mice through this sort of treatment
- It’s interesting though, in **male mice** it’s the *opposite* ‒ you actually seem to impair spermatogenesis and potentially induce sterility
- It’s worth noting that there may be differences in the male and female reproductive systems

**Why are there differences in males and females?**

- David goes back to the discussion of what cells are most impacted by rapamycin [in vivo](https://en.wikipedia.org/wiki/In_vivo) ‒ their defining set of characteristics is always the most rapidly proliferating cells
  - This is what defines [spermatogenesis](https://en.wikipedia.org/wiki/Spermatogenesis) versus [oogenesis](https://en.wikipedia.org/wiki/Oogenesis)
  - By definition, oogenesis is among the slowest processes we have
  - You need a certain rate of growth ([anabolism](https://en.wikipedia.org/wiki/Anabolism)) when you’re proliferating quickly that you just don’t need when you’re proliferating slowly, and therefore you impact those cells
- David agrees, from the studies he’s looked at, spermatogenesis (male fertility) is negatively impacted by rapamycin
- Matt recalls at least one paper showed that once mice come off rapamycin, there may actually be a preservation of sperm quality
- This gets back to dose, and duration, and transient versus continuous

***The mechanism may potentially boil down to the*** [***cell cycle***](https://en.wikipedia.org/wiki/Cell_cycle)

- What David wonders in general about the anti-aging properties of rapamycin is how much is simply a delay because you’re slowing the cell cycle and the progression of cells versus a true rejuvenation
- Matt has seen data presented at meetings (he doesn’t know if it’s published yet) showing structural rejuvenation of the ovaries from an atrophied state to what looks like true rejuvenation at a morphological level as well as a restoration of fertility
  - David finds this hard to understand because presumably when the ovary is fully atrophied, there are no oocytes left ot rejuvenate
  - Matt points out that this probably depends on how far down the path you’ve gotten, and this is not his data so he doesn’t know how carefully that’s been done

**Has anybody looked at rapamycin administration and anti-Müllerian hormone level?**

*Let’s say a woman is already in her* [*AMH*](https://en.wikipedia.org/wiki/Anti-M%C3%BCllerian_hormone) *decline, but hasn’t fully bottomed out to zero, could you rescue some of that?*

- If you look at the physiology of that, it is a monotonically decreasing function, and it is very steep, and if you could simply stop it from declining, that would be remarkable, let alone turn it in the other direction
- Again, here’s an example of something you could study for hundreds of thousands of dollars
  - These are not large sums of money
  - It would have to be paid for by somebody who’s just genuinely obsessed with knowing the answer and not realizing they can’t make a buck off this
- There are human studies that are going on now
- The one Matt is most familiar with is out of Columbia
  - [Yousin Suh](https://www.genetics.cuimc.columbia.edu/profile/yousin-suh-phd) directs the Reproductive Aging Center at Columbia
  - The [Reproductive Aging Study](https://recruit.cumc.columbia.edu/studyinfopage/2145) is a clinical trial led by [Zev Williams](https://www.obgyn.columbia.edu/profile/s-z-williams-md)
  - Matt doesn’t think they have any data yet
  - This was a grant funded by the [Impetus Grants Foundation](https://impetusgrants.org/): A small grant, but one that can actually start to answer some of these questions
  - This is a a double-blind, placebo controlled, randomized clinical trial with rapamycin looking at women with premature ovarian failure
  - Hopefully that will start to get some data around potential efficacy for ovarian function

## The outlook for future research of rapamycin and the development of rapalogs [2:39:00]

**Commentary on funding available to study rapamycin**

- Matt is extremely pleased that the Impetus Grants Foundation funded that trial
- They’re also funding a periodontal disease trial out of the University of Washington
- Matt is grateful to them for doing that from a scientific perspective, but he’s also extremely frustrated that the funding for these kinds of trials is so small and these trials are underpowered for what we really want to do
  - If you really want to answer the question, you’re not going to get there with trials of 40 people (that’s not enough)
- The researchers are doing the best they can in the system that we’re working within, but what happens is you end up with these small clinical trials that give a hint of efficacy and show no problems in terms of safety
  - But then it takes another two years, another three years, another four years to get a grant to take it to the next stage
  - And that’s why it ends up taking two decades with something like rapamycin to actually get to an answer
- Whereas if this were a rapalog, you could go out and start a company and raise money to do a more accelerated path
- Matt doesn’t want to dismiss that approach, but we have a perfectly good drug here with lots of human safety data that probably works, and it’s frustrating that things have gone so slow
- Peter agrees and points out, “*People don’t appreciate what it takes to go from* [*IND*](https://www.fda.gov/drugs/types-applications/investigational-new-drug-ind-application) *to* [*phase III*](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Phase_III) *approval.*”
  - The fact that that’s already been done for this molecule, and basically all you’re really doing is a series of new phase II and phase III trials on an approved drug is such an enormous tailwind

**What is your take today of the landscape in the arena of rapalogs?**

*David has been involved in the development of a number of rapalogs*

- It’s so funny how the winds change
- David would say 10, 12 years ago, if you wanted to target mTOR, the universal response was, “*We have rapamycin. It’s off patent, it’s cheap. No thank you. Let’s move on.*”
- Now, there’s almost been a complete reversal as Matt kind of alluded to
- You can come up with small differences in rapamycin, which you can still sort of patent-protect, and apply them to much more niche applications, and people are potentially willing to fund them
  - These are not the mega biotechs that are being started, but certainly enough to get things going

> “*There’s a general consensus that mTOR matters as a target*”‒ David Sabatini

- Rapamycin and its derivatives are great, and we should do exactly what Matt was saying, and somehow incentivize that

***David thinks there are a whole bunch of other targets in that pathway that may be more beneficial***

- One thing they didn’t get into: It’s very clear that the response to **nutrient deprivation** is *not* just mTOR
  - The nutrient sensors clearly talk to a whole bunch of other processes
  - If you want to get closer to that nutrient deprivation state, one has to go to those
- Currently, the way David reads it is people are willing to invest modestly in molecules that are rapamycin derivatives, yet they still have the mindset that mTOR is drugged
  - Therefore, there’s not really an appetite to go to other components of the pathway (which David thinks is more interesting)

**Peter has pages and pages of topics that he wanted to discuss that extend far beyond rapamycin and mTOR**

- They briefly touched on epigenetics and some of the other hallmarks of aging
- They had hints of other questions that are remarkable
  - Questions that seem so basic and fundamental, yet we don’t know the answer to them
  - Such as, why do different organisms age at different rates?
    - Why do different organisms of similar size have different lifespans?
- They should sit down collectively and do this again
  - Much sooner than the plan to go back to Rapa Nui [Easter Island] in 2026

***Stay tuned for a part two of this discussion***

§

## Selected Links / Related Material

**Previous episodes of** ***The Drive*** **with Matt Kaeberlein**: [1:00]

- [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/) (September 12, 2022)
- [#175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process](https://peterattiamd.com/mattkaeberlein2/) (September 13, 2021)
- [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) (August 20, 2018)

**Previous episode of** ***The Drive*** **with David Sabatini**: [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) (August 13, 2018) | [1:15]

**Matt’s search for genes that affect lifespan**: [A Comprehensive Analysis of Replicative Lifespan in 4,698 Single-Gene Deletion Strains Uncovers Conserved Mechanisms of Aging](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(15)00465-9?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1550413115004659%3Fshowall%3Dtrue#secsectitle0075) | *Cell Metabolism* (M McCormick et al 2015) | [7:30]

**Veterinary clinical trial of rapamycin**: [An open science study of ageing in companion dogs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8940555/) | *Nature* (K Creevy et al 2022) | [9:00]

**Rapamycin is one of the bigger hits in the ITP study**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) | *Nature* (D Harrison et al. 2009) | [21:00, 28:00, 1:27:30]

**Genetic study of longevity genes in worms and yeast**: [Quantitative evidence for conserved longevity pathways between divergent eukaryotic species](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2279244/) | *Genome Research* (E Smith et al. 2008) | [20:45]

**12 hallmarks of aging**: [Hallmarks of aging: An expanding universe](https://pubmed.ncbi.nlm.nih.gov/36599349/) | *Cell* (C Lopez-Otin et al 2023) | [27:45, 1:39:15]

**Previous episode of** ***The Drive*** **with Rich Miller discussed rapamycin ITP studies**: [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021) | [30:30]

**Catalytic inhibitor of mTOR**: [Distinct longevity mechanisms across and within species and their association with aging](https://pubmed.ncbi.nlm.nih.gov/37269831/) | *Cell* (A Tyshkovskiy et al 2023) | [34:30, 43:30]

**Rapamycin can inhibit mTORC2 and Akt signaling**: [Prolonged Rapamycin Treatment Inhibits mTORC2 Assembly and Akt/PKB](https://www.cell.com/molecular-cell/fulltext/S1097-2765(06)00218-8?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1097276506002188%3Fshowall%3Dtrue) | *Molecular Cell* (D Sarbassov et al. 2006) | [47:30]

**Genetic data from yeast, worms, flies, and mice showing the benefits of rapamycin come from mTORC1 inhibition**: [mTOR is a key modulator of ageing and age-related disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3687363/) | *Nature* (S Johnson, P Rabinovitch, & M Kaeberlein 2013) | [50:45]

**Inhibition of mTORC2 is toxic**: [Depletion of Rictor, an essential protein component of mTORC2, decreases male lifespan](https://onlinelibrary.wiley.com/doi/10.1111/acel.12256) | *Aging Cell* (D Lamming et al 2014) | [51:45]

**Worm study of genetic inhibition of mTOR shows impact on autophagy**: [A Role for Autophagy in the Extension of Lifespan by Dietary Restriction in *C. elegans*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2242811/) | *PLoS* (M Hansen et al 2008) | [1:11:00, 2:13:00]

**2014 Mannick study showing rapamycin rejuvenates the immune system**: [mTOR inhibition improves immune function in the elderly](https://pubmed.ncbi.nlm.nih.gov/25540326/) | *Science Translational Medicine* (J Mannick et al 2014) | [1:25:30, 1:40:30]

**2009 Pan Zheng study showing rapamycin rejuvenated immune response in aged mice receiving the flu vaccine**: [mTOR Regulation and Therapeutic Rejuvenation of Aging Hematopoietic Stem Cells](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4020596/) | *Science Signaling* (C Chen et al 2009) | [1:26:45, 1:40:30]

**Matt’s survey of over 300 people who use rapamycin off-label**: [Evaluation of off-label rapamycin use to promote healthspan in 333 adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10187519/) | *GeroScience* (T Kaeberlein et al. 2023) | [1:42:00]

**12 hallmarks of aging**: [Hallmarks of aging: An expanding universe](https://pubmed.ncbi.nlm.nih.gov/36599349/) | *Cell* (C Lopez-Otin et al 2023) | [27:45, 1:39:15]

**Joan Mannick’s study on RTB101**: [Targeting the biology of ageing with mTOR inhibitors to improve immune function in older adults: phase 2b and phase 3 randomised trials](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00062-3/fulltext) | *The Lancet Healthy Longevity* (J Mannick et al 2021) | [2:00:45]

**Matt’s editorial on RTB101**: [RTB101 and immune function in the elderly: Interpreting an unsuccessful clinical trial](https://www.sciencedirect.com/science/article/pii/S246850112030002X) | *Translational Medicine of Aging* (M Kaeberlein 2020) | [2:05:15]

**Joan Mannick’s three studies**: [2:05:30]

- [mTOR inhibition improves immune function in the elderly](https://pubmed.ncbi.nlm.nih.gov/25540326/) | *Science Translational Medicine* (J Mannick et al 2014)
- [TORC1 inhibition enhances immune function and reduces infections in the elderly](https://pubmed.ncbi.nlm.nih.gov/29997249/) | *Science Translational Medicine* (J Mannick et al 2018)
- [Targeting the biology of ageing with mTOR inhibitors to improve immune function in older adults: phase 2b and phase 3 randomised trials](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00062-3/fulltext) | *The Lancet Healthy Longevity* (J Mannick et al 2021)

**Dog Aging Project**: [Dog Aging Project](https://dogagingproject.org/) (2023) | [2:19:15]

**TRIAD study (test of rapamycin in aging dogs)**: [2:20:00]

- [Dog aging project TRIAD study](https://hospital.vetmed.wsu.edu/2022/03/28/dog-aging-project-triad-study/), Washington State University College of Veterinary Medicine (March 28, 2022)
- [Aging Dogs Provide Insights for Human Longevity](https://www.the-scientist.com/news-opinion/aging-dogs-provide-insights-for-human-longevity-71223) | Hannah Thomasy, *TheScientist* (July 19, 2023)

**Preliminary data on the effects of rapamycin on marmosets**: [Long-term treatment with the mTOR inhibitor rapamycin has minor effect on clinical laboratory markers in middle-aged marmosets](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6415526/) | *American Journal of Primatology* (A Sills et al 2019) | [2:25:30]

**Short trials of rapamycin in companion dogs**: [A randomized controlled trial to establish effects of short-term rapamycin treatment in 24 middle-aged companion dogs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/) | *GeroScience* (S Urfer et al 2017) | [2:27:45]

**Review of mTOR biology**: [mTOR Signaling in Growth, Metabolism, and Disease](https://www.cell.com/cell/fulltext/S0092-8674(17)30182-4?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867417301824%3Fshowall%3Dtrue) | *Cell* (R Saxton and D Sabatini 2017)

**Review of longevity drug, rapamycin**: [Rapamycin, the only drug that has been consistently demonstrated to increase mammalian longevity. An update](https://www.sciencedirect.com/science/article/pii/S0531556523000876?via%3Dihub#f0005) | *Experimental Gerontology* (Z Sharp and R Strong 2023)

§

## People Mentioned

- [Solomon (Sol) Snyder](https://neuroscience.jhu.edu/research/faculty/83) (Professor of Neuroscience Emeritus at Johns Hopkins School of Medicine) [5:00, 15:45, 54:30]
- [Michael Hall](https://www.biozentrum.unibas.ch/research/research-groups/research-groups-a-z/overview/unit/research-group-michael-n-hall) (Professor at the University of Basel and expert in TOR signaling) [5:15]
- [Suren Seghal](https://journals.lww.com/indianjcancer/Fulltext/2017/54040/Surendra_Nath_Sehgal__A_pioneer_in_rapamycin.24.aspx) (Scientist at Ayerst Research Lab who isolated *Streptomyces hygroscopicus* and initially characterized rapamycin) [15:30, 18:00]
- [Brian Kennedy](https://medicine.nus.edu.sg/bch/faculty/brian-kennedy/) (Distinguished Professor of Biochemistry and Physiology at National University of Singapore) [23:45]
- [Daniel Promislow](https://dlmp.uw.edu/faculty/promislow) (Professor of Laboratory Medicine and Pathology at the University of Washington, Co-Director and PI of the Dog Aging Project) [23:45]
- [Rich Miller](http://www.richmillerlab.com/) (Professor of Pathology and the Director of the Paul Glenn Center for Biology of Aging at the University of Michigan) [30:30]
- [Stuart Schreiber](https://www.broadinstitute.org/bios/stuart-l-schreiber) (Professor of Chemistry and Chemical Biology at Harvard University, founding member of the Broad Institute, mTOR expert) [37:15, 1:47:15]
- [Dos Sarbassov](https://research.nu.edu.kz/en/persons/dos-sarbassov) (Professor, School of Sciences and Humanities at Nazarbayev University) [47:45]
- [Joe Averuch](https://researchers.mgh.harvard.edu/profile/3588924/Joseph-Avruch) (Professor of Medicine Emeritus at Harvard Medical School) [58:15]
- [Rachel Wolfson](https://connects.catalyst.harvard.edu/Profiles/display/Person/99263) (Research Fellow in Neurobiology at Harvard) [1:00:00]
- [Lynne Chantranupong](https://www.umassmed.edu/metnet/blog/2023/02/lynne-chantranupoing/) (Postdoctoral fellow at Harvard) [1:00:00]
- [Robert (Bobby) Saxton](https://vcresearch.berkeley.edu/faculty/robert-saxton) (Assistant Professor of Immunology and Molecular Medicine and Chemistry at UC Berkeley) [1:00:00]
- [Thomas Schwartz](https://biology.mit.edu/profile/thomas-u-schwartz/) (Professor of Biology at MIT) [1:00:00]
- [Veronica Galvan](https://www.galvanlab.org/veronica-galvan-ph-d) (Professor of Biochemistry and Molecular Biology and Co-Director of the Center for Geroscience and Healthy Brain Aging at the University of Oklahoma Health Sciences Center) [1:11:30]
- [Toren Finkel](https://www.isb.pitt.edu/people/faculty/toren-finkel-md-phd) (Professor of Medicine, Division of Cardiology and Director of the Aging Institute at the University of Pittsburgh) [1:11:45]
- [Joan Mannick](https://milkeninstitute.org/events/fhs19/speakers/39958) (Co-founder of resTORbio and expert in treating aging-related diseases) [1:25:30, 2:00:45, 2:07:30, 2:28:45, 2:32:45]
- [Lloyd Klickstein](https://srfcure.org/lloyd-klickstein/) (CSO of the Scleroderma Research Foundation and expert in drug development) [1:25:30]
- [Pan Zheng](https://oncoc4.com/index.php/about/our-team/164-pan-zheng-md-phd) (Founder and CSO of OncoC4) [1:26:45]
- [Richard (Rick) Young](https://biology.mit.edu/profile/richard-a-young/) (Professor of Biology at MIT; Core Member, Whitehead Institute) [1:38:30]
- [Ronald Duman](https://www.nature.com/articles/s41593-020-0629-3) (was a Professor of Psychiatry and Professor of Neuroscience at Yale) [1:48:45]
- [Robert (Bob) Abraham](https://enterprises.upmc.com/team-member/bob-abraham/) (Executive Vice President and Head of Cancer Biology at a Odyssey Therapeutics) [2:02:30]
- [Eileen White](https://ludwigcancer.princeton.edu/people/eileen-white) (associate director of the Ludwig Institute for Cancer Research Princeton Branch, is the deputy director, chief scientific officer, and associate director of basic research at the Rutgers Cancer Institute of New Jersey; expert in autophagy) [2:17:15]
- [Daniel Promislow](https://dlmp.uw.edu/faculty/promislow) (Professor of Laboratory Medicine and Pathology at The University of Washington, and co-founder of the Dog Aging Project) [2:19:15]
- [Kate Creevy](https://experts.tamu.edu/expert/kate-creevy/) (small animal internal medicine specialist and Professor of Veterinary Medicine at Texas A&M, co-founder of the Dog Aging Project) [2:19:15]
- [Adam Salmon](https://barshopinstitute.uthscsa.edu/team-member/salmon-adam/) (Professor of Molecular Medicine and Associate Director of the Sam & Ann Barshop Institute for Longevity & Aging Studies at UT Health San Antonio) [2:23:15]
- [Alan Green](https://www.doximity.com/pub/alan-green-md-2b33c2bb) (Board Certified Pathologist currently specializing in treatment of age-related disease) [2:33:00]
- [Yousin Suh](https://www.genetics.cuimc.columbia.edu/profile/yousin-suh-phd) (Professor of Reproductive Sciences and Director of the Reproductive Aging Center at Columbia) [2:41:00]
- [Zev Williams](https://www.obgyn.columbia.edu/profile/s-z-williams-md) (Associate Professor of Obstetrics & Gynecology at Columbia, Chief of the Division of Reproductive Endocrinology & Infertility) [2:41:15]

§