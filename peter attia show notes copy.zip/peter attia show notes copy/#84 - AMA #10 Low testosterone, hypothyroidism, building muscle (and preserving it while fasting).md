# #84 – AMA #10: Low testosterone, hypothyroidism, building muscle (and preserving it while fasting)

**Source:** [https://peterattiamd.com/ama10/](https://peterattiamd.com/ama10/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a wide range of questions from subscribers. Bob Kaplan, Peter’s head of research, asks the questions. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/). You can also listen to this full episode on our website at the [AMA #10 show notes page](https://peterattiamd.com/ama10/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

We discuss:

- Does testosterone supplementation impact longevity? [2:40];
- Under what conditions does Peter decide to treat patients who have low testosterone? [8:50];
- Are there risks involved with testosterone replacement therapy? [17:10];
- How does Peter diagnose and treat hypothyroidism? [21:30];
- How might someone do time-restricted feeding while also adding muscle mass? [26:30];
- If building muscle requires higher levels of IGF-1, should we be concerned about longevity? [34:45];
- How to preserve muscle mass while fasting [41:45];
- Is it possible to simultaneously lose fat and add muscle mass? [46:30]; and
- More.

§

The Peter Attia Drive

Low testosterone, hypothyroidism, building muscle (and preserving it while fasting)

§

## Show Notes

## Does testosterone supplementation impact longevity? [2:40]

*Is Peter a “fan” of T supplementation?*

- Depends on the person and the situation, says Peter

*Does TRT increase* ***lifespan****?*

- Peter is not convinced it will increase lifespan

*Does low T lead to aggressive prostate cancer?*

- Low testosterone is associated with more aggressive prostate cancer
- But that’s probably not saying that low testosterone **causes** aggressive prostate cancer
- What it says is that *if you have prostate cancer in a low androgen environment, it is likely to be more aggressive*

*Does TRT improve* ***healthspan****?*

-There are 3 components of healthspan

1. Cognition
2. Physical “exoskeleton”
3. Emotional health

-TRT and cognition

- The literature does NOT support the idea that it improves cognition
- This [2016 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5078598/) in older men did not suggest that testosterone replacement therapy was improving cognition
- That said, anecdotal evidence says some people believe it does help them cognitively

-TRT and physical conditioning

- Improvement of and/or maintenance of lean muscle mass
- Strength
- Conditioning
- Recovery from exercise
- However… “*The magnitude that those things are improved however is not obvious and is not entirely predicted by the number.*”

-TRT and emotional health (and [libido](https://en.wikipedia.org/wiki/Libido))

- Peter admits he’s not extremely in tune with the literature on this
- But it would be “hard to miss” the improvement in mood and libido when treating patients for low T

**Summary of Peter’s thoughts on TRT and longevity**:

-There are four things we think about…

1. Living longer
2. improving cognition
3. improving physical body
4. improving emotional health

- Physical body and emotional health are positively affected by testosterone
- For cognition and lifespan, there is not as clear of an impact

-Regarding lifespan:

- Yes, there are lots of ways that having more muscle mass can also delay death.
- So notice Peter said **chronic death** when he was talking about death
- It might be the case that TRT can improve muscle mass and functional strength which can prevent accidental death later in life

–*What about bone mineral density?*

- The effects on BMD are more pronounced in women than in men, but we do see those benefits

⇒ The Endocrine Society’s [TRT guidelines](https://www.ncbi.nlm.nih.gov/pubmed/20525905/)

## Under what conditions does Peter decide to treat patients who have low testosterone? [8:50]

IMPORTANT: Peter says he only considers treating low T if it **comes with symptoms**

*What does he look for in the lab results?*

**Total T vs. Free T**:

- Testosterone is measured in nanograms per deciliter
- A bell curve looking at **TOTAL T** is typically bt 350 and 1,200 nanograms per deciliter
- That means you’re talking about 95% of the population would exist between on that scale 350 and 1,200 nanograms per deciliter.
- If you’re at a 1,000, you’re probably closer to the upper end of that
- and if you’re at 500 you’re at the lower end of that,
- The majority of your testosterone is bound to carrier proteins,
- The most dominant of them is a protein called [sex hormone-binding globulin](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) — which quite tightly binds testosterone
- The only testosterone that has any biological effect is the T that is unbound to protein (aka **FREE T**)

-Free testosterone

- Typically 97-99% of T is bound (so 1-3% is free)
- The amount that is free is inversely proportional to sex hormone-binding globulin
- *Examples*,
  - If a man had 1,000 total T and 1% free, he would only have 10 nanograms/deciliter of free T
  - Conversely, a man could have 600 total T but have 3% free giving him 18 nanograms per deciliter of free T

-What’s the normal range for free testosterone?

- About 10-14 nanograms per deciliter

**When does Peter think it’s appropriate to treat low-T?**

- He **will** treat if they have low free T in combination with symptoms
- He **won’t** treat If they have low T but no symptoms, he won’t treat
- **One exception**: If someone has low T and no symptoms but they are profoundly insulin resistant he will usually recommend giving TRT a try
  - Why? Because **testosterone impacts fuel partitioning**

*Is there a relationship between sex hormone-binding globulin and levels of insulin?*

- Sex hormone-binding globulin is heavily influenced by four things
  - Firstly, it’s genetic/hereditary
  - Then there are three hormones that heavily influence SHBG
    - Estradiol ⇒ As estradiol goes higher, sex hormone-binding globulin also goes higher.
    - T4 (thyroid hormone) ⇒ as T4 goes higher, SHBG goes higher.
    - Insulin ⇒ as insulin goes higher, SHBG goes lower
- So an endocrine response that would produce the *lowes*t SHBG would be **hyperinsulinemia, low estrogen, and low thyroid.**
- That produces a high free testosterone relative to total testosterone
- [Free Androgen Index](https://en.wikipedia.org/wiki/Free_androgen_index) = ratio of testosterone to SHBG and that’s correlated with free testosterone
  - “*But I much prefer to just actually use free testosterone since ratios can always be misleading. For example, you can have low testosterone, low SHBG and then a high free androgen index, but on an absolute level your free testosterone is still low.*”

## Are there risks involved with testosterone replacement therapy? [17:10]

-The two things that are most discussed in terms of risk with TRT:

1. Prostate cancer
2. Heart disease

-Peter already gave his quick thoughts on prostate cancer at the beginning of this podcast (Basically, he doesn’t see evidence that it plays a causal role)

–**With respect to heart disease…**

This [2016 study](https://www.ncbi.nlm.nih.gov/pubmed/27165609) looked at 10,000 men treated with TRT and 28,000 plus controls over 5 years

- After one year there was a **slight uptick in coronary events** . . .but by years two and three it had reversed
- Adjusted statistical analysis showed that, compared to controls, TRT subjects had a 10% increased risk of experiencing a cardiovascular event (Hazard Ratio [HR] = 1.10)
- The data was further analyzedby breaking TRT subjects into tertiles based on how long they were treated with T
  - Tertiles 1, 2, and 3, correspond to short, intermediate, and long-term exposure to TRT
  - This analysis showed that, compared to controls, the risk of a cardiovascular event was:
    - Increased by 26% in Tertile 1 (HR = 1.26);
    - Increased by 16% in Tertile 2 (HR = 1.16);
    - Decreased by 16% in Tertile 3 (HR = 0.84);
  - This shows that the original 10% increase in risk seen for all TRT patients is attributable only to those exposed for short and intermediate periods of time
  - Furthermore, the risk of mortality from any cause was:
    - Increased by 11% in tertile 1
    - Decreased by 10% in tertile 2
    - Decreased by 33% in tertiles 3
- But what was the **absolute risk** increase in that first year?
  - A cardiovascular event occurred in 5% of the control subjects and 6% of TRT subjects
  - This equates to an AR of 1%

-Peter’s take on the 2016 study:

- Given the small AR of 1% Peter says, “*To me that says you take a relatively high risk population, you put them on TRT, and away you go.*”
- That said, Peter is left wondering the following question…
- **What is it about TRT that would transiently (for that first year) increase the risk?**
- - Is it the dyslipidemia that can occur in some men?
  - Is there some endothelial dysfunction?
  - Is there some hypercoagulability?
  - Is there a rise in blood pressure?
  - What is it about TRT that could be driving up risk in an otherwise high risk man?

“*I don’t think I know the answer to that question, but I guess I’ve had the luxury of not having to really worry about it because our patient population is so different and these risks are far outweighed by the benefits in the way that we apply it.*”

## How does Peter diagnose and treat hypothyroidism? [21:30]

**Overview of what thyroid is doing**

- The thyroid gland produces T4, which is an inactive hormone and the same thing that Synthroid (commonly prescribed for [hypothyroidism](https://en.wikipedia.org/wiki/Hypothyroidism))
- If everything is going according to plan, the body will convert T4 or Synthroid into T3 (the active hormone)
- It does that by taking one of the iodines off
- So the conversion of T4 into T3 requires a class of enzymes referred to as [deiodinases](https://en.wikipedia.org/wiki/Deiodinase)

*How is the diagnosis made of hypothyroidism?*

- The traditional way to make it is on the basis of just the thyroid stimulating hormone

*What did Peter mean when he said he “fixed” a woman’s thyroid on a previous podcast?*

- What that probably means is Peter was able to normalize thyroid function through some administering some combination of
  - Thyroid hormones (T4 on Synthroid plus T3), and/or
  - Minerals (e.g., zinc and selenium)
    - Deficiencies in these minerals may manifest is slight thyroid malfunction

***When does Peter decide to treat?***

-In two scenarios…

1. When the labs show concerning numbers AND the patient is experience symptoms
2. Or when someone has “mediocre” numbers but their symptoms are pretty significant and those symptoms improve with treatment

> “The endocrine system is one of these things where you’ve really got to be thinking about this through the lens of symptoms mattering a little bit more than the numbers and the numbers just being kind of a guide post.”

## How might someone do time-restricted feeding while also adding muscle mass? [26:30]

> “[Milk is for babies. When you grow up you have to drink beer.](https://www.youtube.com/watch?v=pXOGS9cilKM)” —Arnold Schwarzenegger

Bodybuilding documentary Peter has seen 187 times: [Pumping Iron](https://en.wikipedia.org/wiki/Pumping_Iron)

Peter calls [Samir Bannout’s physique in 1983](https://www.reddit.com/r/bodybuilding/comments/dbd43j/samir_bannout_from_the_1983_mr_olympia_check_out/) the “apex” of the sport of bodybuilding

\*\*\*

**How might someone do time-restricted feeding but also put on muscle mass?**

- First of all, TRF is probably not the ideal strategy if your main goal is to add muscle mass
- That said, if you want the benefits of TRF and preserve (and maybe add) muscle mass, Peter suggests: **Pairing your training window with your feeding window**
- Example: If eating window is 12p-8pm, do your workout late afternoon and have your final meal of the day afterwards

**Muscle and what it takes to maintain it**

- Muscle is very responsive to growth signals and growth factors (e.g., testosterone)
- At the cellular level it comes down to **protein assimilation**
- [mTOR](https://en.wikipedia.org/wiki/MTOR) is a very important part of protein assimilation

**⇒ Leucine**

- The amino acid called [leucine](https://en.wikipedia.org/wiki/Leucine) is the [most important amino acid when it comes to getting mTOR to turn on in the muscle](https://www.researchgate.net/profile/Ken_Smith8/publication/38060403_Distinct_anabolic_signalling_responses_to_amino_acids_in_C2C12_skeletal_muscle_cells/links/54abf4f10cf2bce6aa1dd536.pdf)
- If you’re hell bent on putting on muscle mass, Peter would recommend supplementing with leucine (even above and beyond what’s in the branched-chain amino acids products)
- Best guess at the dose would be an extra five grams of leucine
- TIP: You can’t chug it… you have to slowly consume it over time (i.e., during the course of a workout)

⇒ See Bobby Saxton and David Sabatini’s 2017 paper: [mTOR Signaling in Growth, Metabolism, and Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5394987/)

⇒ See Peter’s [discussion with David Sabatini](https://peterattiamd.com/davidsabatini/) starting at [42:50] of the episode

*Where to get leucine?*

- Bob says many whey protein powders contains about 2 g of leucine per 20 g of protein (which might be “enough”)
  - Peter likes products from [BioSteel](https://biosteel.com/collections/all-products?gclid=Cj0KCQiAz53vBRCpARIsAPPsz8WSYU8v0RoHN9vAgdmbeAUsKKblGawxhG3kNHj3C6jMEQ-uV753IOwaAspOEALw_wcB)
  - Bob says [NOW Sports](https://www.nowfoods.com/sports-nutrition/sports-nutrition-all-products) has pretty good stuff
  - Peter he once tested protein powders in a lab and found [Jay Robb products](https://www.jayrobb.com/products/) stood out
- Also, you can buy pure leucine powder
  - Peter suggests commercially from a lab like [Sigma Chemicals](https://www.sigmaaldrich.com/catalog/search?term=Leucine&interface=All&N=0&mode=partialmax&lang=en&region=US&focus=product)

At the end of the day…

- Building muscle while doing time-restricted feeding probably **isn’t optima**l for adding muscle mass
- If it were optimal, you better believe the bodybuilding community would be doing it

## If building muscle requires higher levels of IGF-1, should we be concerned about longevity? [34:45]

If we presume high IGF-1 is bad for longevity (a common belief)…*What would be the best protocol to build lean muscle mass without sacrificing longevity?*

- Peter says IGF-1 being “bad” is based on a false premise
- This idea is based on [observation epidemiology](https://peterattiamd.com/ns002/)
- People like to use the [Laron Dwarfs](https://en.wikipedia.org/wiki/Laron_syndrome) as evidence that low IGF-1 is good (their [cancer incidence is lower HOWEVER their overall lifespan isn’t actually longer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3357623/))

“*I’m struggling to find any evidence to suggest that that’s correct, and in the process of struggling to find said evidence, I’m finding plenty of evidence to suggest that it’s incorrect.*”—Peter on the idea that having high levels of IGF-1 is bad for longevity

- **Example**, *Dementia and IGF-1*
  - The [risk of dementia goes down lower and lower as IGF levels get higher and higher](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4013812/)

⇒ The human data on IGF is confusing, for more on this topic check out [Peter’s discussion with Nir Barzilai starting at 1:34:15](https://peterattiamd.com/nirbarzilai/)

**The importance of cycling things like IGF levels**

- Instead of aiming for IGF levels that are constantly low (like while fasting) or constantly high (like when eating), the best approach is for **IGF levels to be cycled from low to high**
  - So should mTOR activity
  - As well as other growth factors
- IGF level could be swinging throughout the year, and that’s probably your best way to hit all elements of this within certain bands
- Peter would guess his IGF vacillates between the 20th percentile and the 90th percentile of his age group throughout each quarter, just based on his fasting and feeding
- Peter says: “*My intuition is based on a much broader look at epidemiology where again, there’s no causation that can be inferred here, but you can certainly see mortality associations. I think that’s more logical than sort of isolated examples where we try to make the case that low IGF all the time is good based on a model that I don’t think makes sense.”*

**The problem with looking at averages…**

- Looking at averages doesn’t tell us where the IGF levels actually sit
- For example, if you fast you have low IGF and when you feed you have higher IGF therefore your “average” is in the middle… but you spent very little time actually at the “average”
- There’s evidence suggesting that good things happen at both the low levels of IGF and at the higher levels of IGF
  - E.g.,
    - [Low levels, less cancer](https://academic.oup.com/jcem/article/96/9/2912/2834729)
    - [High levels, less neurodegeneration](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5713408/)
- When looking at an “average” we are missing a part of the story
- It might be these **on-off or renewing cycles that’s important**

## How to preserve muscle mass while fasting [41:45]

**Can you implement fasting and still preserve your lean muscle mass?**

- “*You absolutely can.*”

*How do we do that?*

- By **lifting weights every single day**
  - You must be sending a single to activate TOR in the muscle daily
  - You must utilize the free leucine that your body does a remarkable job preserving during the fast, and you must give it a reason to be assimilated
- If you do that, you can come very close to maintaining nitrogen balance, which means keeping nitrogen in your muscles as opposed to shedding muscle
- *Conversely*, if you fast without resistance training, you are likely to **lose** some muscle

**Exercise and testosterone preserve muscle during fasting**

-Peter and Bob recently wrote a 2-part email discussing a [study](https://www.sciencedirect.com/science/article/pii/S2352396419305018) looking at fasting/exercise/testosterone

- Part 1-[Can you preserve lean body mass during “semi-starvation?”](https://peterattiamd.com/can-you-preserve-lean-body-mass-during-semi-starvation/)
- Park 2-[Can you maintain muscle during fasting?](https://peterattiamd.com/can-you-maintain-muscle-during-fasting/)

-The study:

- During a 28-day intervention…
  - The men were exercising and eating in a fashion to put them in a calorie deficit of about ~2,000 cal/day
  - The exercise wasn’t “weight training”, but it was various exercises including running with backpacks and other weight bearing stuff
  - One group supplemented with testosterone
  - Another group did not supplement with testosterone
- Results:
  - The group that was supplemented with testosterone **added muscle mass**
  - The group without testosterone **did not lose any lean muscle** under profound caloric deprivation (actually **added** a “non-significant” amount of muscle)
  - Peter suspects that if there was a control arm that didn’t exercise at all, and didn’t use testosterone, those people would have really lost lean tissue

*So why does muscle size shrink during a fast?*

- When you fast, you lose a lot of glycogen and water
- So the muscle will actually shrink b/c each gram of glycogen is carrying about 3 g of water
- If you’re giving up let’s say a 100 grams of glycogen, you’re giving up 400 grams total and that’s one pound right there
- But this doesn’t mean you’re “losing muscle”… because the name of the game is muscle protein synthesis

## Is it possible to simultaneously lose fat and add muscle mass? [46:30]

- This is a fuel partitioning problem ⇒ To be in a caloric debt and yet to put on muscle and take off fat requires a “**very deliberate training plan”**
- Insulin is the most anabolic hormone in the body
- When you fast your insulin levels go down
- You have to really overcome that lack of an anabolic stimulus from the insulin loss by driving mTOR and that’s where **exercise becomes the key**
- You can’t overstate the importance of
  - i) meal timing,
  - ii) meal composition, and
  - iii) above all else just the importance of exercise

**What are the best movements to do?**

- Certain movements that are just more important
- Heavy pulling, pushing, and hip hinging that involve the large muscle groups

*Results will vary depending on your baseline*

- If you’re 6% body fat, been training your whole life so you have plenty of muscle, it’s going to be very difficult for you to gain muscle and lose fat when you’re trying to do a lot of fasting
- Compare that to somebody who is morbidly obese, not a lot of muscle, they’ve never trained a day in their life and you’re going to have them embark on a weight training program, they’re probably going to get better results in terms of how much muscle, how much lean tissue they can put on and how much fat they can lose at the same time

§

## Selected Links / Related Material

**Testosterone and cognition study that did not suggest that testosterone replacement therapy was improving cognition**: [The Effects of Testosterone Supplementation on Cognitive Functioning in Older Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5078598/) (Wahjoepramono et al., 2016) [5:00]

**The Endocrine Society’s recommendations for TRT were for symptomatic men with a low T to improve sexual function, improve sense of well-being, improve muscle mass and strength, and increase bone mineral density**: [Testosterone therapy in men with androgen deficiency syndromes: an Endocrine Society clinical practice guideline.](https://www.ncbi.nlm.nih.gov/pubmed/20525905/) (Bhasin et al., 2010) [8:15]

**Free androgen index looks at the ratio of testosterone to SHBG but Peter prefers to to look directly at free testosterone since ratios can always be misleading**: [Free Androgen Index](https://en.wikipedia.org/wiki/Free_androgen_index) | (wikipedia.org) [15:30]

**2016 study that looked at 10,000 men treated with TRT and 28,000 plus controls over 5 years**: [Survival and cardiovascular events in men treated with testosterone replacement therapy: an intention-to-treat observational cohort study](https://www.ncbi.nlm.nih.gov/pubmed/27165609). (Wallis et al., 2016) [17:30]

**Bodybuilding documentary Peter has seen 187 times**: [Pumping Iron](https://en.wikipedia.org/wiki/Pumping_Iron) | (wikipedia.org) [27:00]

**Arnold saying “Milk is for babies”**: [arnold – milk is for babies](https://www.youtube.com/watch?v=pXOGS9cilKM) | woody161290 (youtube.com) [27:15]

**Peter calls Samir Bannout physique in 1983 as the “apex” of the sport of bodybuilding**: [Samir Bannout from the 1983 Mr Olympia. Check out that tree!](https://www.reddit.com/r/bodybuilding/comments/dbd43j/samir_bannout_from_the_1983_mr_olympia_check_out/) | [u/therealmurraythek](https://www.reddit.com/user/therealmurraythek/) | (reddit.com)  [27:30]

**David Sabatini and Bobby Saxton’s 2017 paper looking at leucine, mTOR, and muscle mass**: [mTOR Signaling in Growth, Metabolism, and Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5394987/)  (Saxton and Sabatini, 2017) [30:00]

**Peter’s interview of David Sabatini where they talk about leucine at 42:50**: [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) | Peter Attia (peterattiamd.com) [30:00]

**Leucine is the most important amino acid when it comes to getting mTOR to turn on in the muscle**: [Distinct anabolic signalling responses to amino acids in C2C12 skeletal muscle cells](https://www.researchgate.net/profile/Ken_Smith8/publication/38060403_Distinct_anabolic_signalling_responses_to_amino_acids_in_C2C12_skeletal_muscle_cells/links/54abf4f10cf2bce6aa1dd536.pdf) (Atherton et al., 2010) [30:30]

**Lab that sells pure leucine**: [Sigma Chemicals](https://www.sigmaaldrich.com/catalog/search?term=Leucine&interface=All&N=0&mode=partialmax&lang=en&region=US&focus=product) [33:00]

**Peter’s go to supplement brand**: [BioSteel](https://biosteel.com/) [33:15]

**Another reputable source for protein powder**: [Now Foods Sports Nutrition](https://www.nowfoods.com/sports-nutrition/sports-nutrition-all-products) | (nowfoods.com) [33:30]

**Protein powder that stood out when Peter tested various brands for quality**: [JayRobb](https://www.jayrobb.com/) [34:15]

**Evidence suggesting good things happen at both the low end and the high end of IGF-1 levels**: [35:45]

- *Low levels, less cancer*: [Meta-Analysis and Dose-Response Metaregression: Circulating Insulin-Like Growth Factor I (IGF-I) and Mortality](https://academic.oup.com/jcem/article/96/9/2912/2834729) (Burgers et al., 2011)
- *Higher levels of IGF-1 can be neuroprotective*: [Neurotrophic and Neuroregenerative Effects of GH/IGF1](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5713408/) (Bianchi et al., 2017)

**Laron dwarfs have significantly less cancer and less diabetes but more accidental deaths**: [Growth Hormone Receptor Deficiency is Associated With a Major Reduction in Pro-aging Signaling, Cancer and Diabetes in Humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3357623/) (Guevara-Aguirre et al., 2011) [36:00]

**Risk of dementia decreases as IGF-1 levels increase**: [Insulin-like growth factor-1 and risk of Alzheimer dementia and brain atrophy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4013812/) (Westwood et al., 2014) [36:45]

**The human data on IGF is confusing, for more on this topic check out Peter’s discussion with Nir Barzilai starting at 1:34:15**: [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) | Peter Attia (peterattiamd.com) [37:00]

**Valter Longo did studies in mice where he talks about the period of growth after the fast is very important**: [A periodic diet that mimics fasting promotes multi-system regeneration, enhanced cognitive performance and healthspan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4509734/) (Brandhorst et al., 2015) [40:30]

**Peter’s emails about fasting and muscle mass**: [42:00]

- Part 1-[Can you preserve lean body mass during “semi-starvation?”](https://peterattiamd.com/can-you-preserve-lean-body-mass-during-semi-starvation/)
- Park 2-[Can you maintain muscle during fasting?](https://peterattiamd.com/can-you-maintain-muscle-during-fasting/)

**Military fasting, exercise, testosterone study**: [Effects of testosterone supplementation on body composition and lower-body muscle function during severe exercise- and diet-induced energy deficit: A proof-of-concept, single centre, randomised, double-blind, controlled trial](https://www.sciencedirect.com/science/article/pii/S2352396419305018) (Pasiakosa et al., 2019) [42:00]

§

## People Mentioned

- [Samir Bannout](https://en.wikipedia.org/wiki/Samir_Bannout) [27:30]
- [Lee Haney](https://en.wikipedia.org/wiki/Lee_Haney) [27:30]
- [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates) [27:30]
- [Chris Dickerson](https://en.wikipedia.org/wiki/Chris_Dickerson_(bodybuilder)) [27:30]
- [Frank Zanes](https://en.wikipedia.org/wiki/Frank_Zane) [27:30]
- [Jay Cutler](https://en.wikipedia.org/wiki/Jay_Cutler_(bodybuilder)) [27:30]
- [Phil Heath](https://en.wikipedia.org/wiki/Phil_Heath) [27:30]
- [Ronnie Coleman](https://en.wikipedia.org/wiki/Ronnie_Coleman) [27:30]
- [David Sabatini](https://twitter.com/DMSabatini?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [30:30]
- [Bobby Saxton](https://en.wikipedia.org/wiki/Bobby_Saxton) [30:30]
- [Rhonda Patrick](https://twitter.com/foundmyfitness/status/1194648699923660800) [36:45]
- [Valter Longo](https://valterlongo.com/) [40:15]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) [41:30]

§