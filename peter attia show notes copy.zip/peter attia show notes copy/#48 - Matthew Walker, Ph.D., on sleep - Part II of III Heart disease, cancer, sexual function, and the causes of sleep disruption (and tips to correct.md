# #48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)

**Source:** [https://peterattiamd.com/matthewwalker2/](https://peterattiamd.com/matthewwalker2/)

---

##### Check out more content with sleep expert, Matthew Walker, Ph.D.:

- *(April 1, 2019)* [Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, and memory](/matthewwalker1/)
- *(April 8, 2019)* [Part II of III: Heart disease, cancer, sexual function, and sleep disruption](/matthewwalker2/)
- *(April 15, 2019)* [Part III of III: The penetrating effects of poor sleep from metabolism to genetics](/matthewwalker3/)
- *(June 17, 2019)* [AMA #1: Strategies for sleeping more and sleeping better](/matthewwalkerama/)
- *(October 28, 2019)* [AMA #2: short sleep mutants, optimal sleep environment, & sleep apnea](/matthewwalkerama2/)
- *(August 31, 2020)* [Sleep & Covid-19: Sleep and immune function, chronotypes, and hygiene tips](/matthewwalker4/)
- *(September 7, 2020)* [AMA #3: Fasting, gut health, blue light, caffeine, REM sleep, and more](/matthewwalkerama3/)

In part 2 of this 3 part series, Matthew Walker, professor of neuroscience at UC Berkeley and expert on sleep, describes the preponderance of evidence linking poor sleep to cardiovascular disease, cancer, and sexual function. He also details the impact of cortisol on our nervous system contributing to sleep disturbances and insomnia as well as the efficacy and risks associated with the most common sleeping pills. Matthew also describes the sleep needs of teenagers and urgently lays the case that we should reconsider school start times. We also get into the effect of electronics at night, the efficacy of napping, the general impact of modern society on our sleep habits, and what changes we can make to course correct.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/matthewwalker2/the_Drive_public.png)

Play

#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)

#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)

1x15s30s

0:002:04:32

## We discuss:

- Sleep and cardiovascular disease [6:00];
- Fuel partitioning and dieting while sleep deprived [16:45];
- Sleep and the reproductive function: testosterone, sperm count, FSH, menstrual cycles, and fertility [19:45];
- The biological necessity of sleep, the lack of a “safety net”, sleep debt, and ways to course correct sleep problems [23:45];
- Fighting cancer and improving immune function with sleep [34:30];
- The medical profession: A culture that devalues sleep [47:30];
- The sleep needs of children, the travesty of early school start times, electronics at night, and advice for parents [1:04:45];
- How exposure to light affects sleep, and how modern society has changed our sleep habits  [1:26:15];
- Is napping helpful? [1:36:00];
- The effect of cortisol levels on sleep [1:41:15];
- Are sleeping pills doing more harm than good? [1:52:15]; and
- More.

§

## Show Notes

## Sleep and cardiovascular disease [6:00]

**Why is CVD worsened (or accelerated) by sleep deprivation?**

Example: [Daylight savings time and myocardial infarction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4189320/)

- 24% increased risk of heart attack day after daylight savings in spring
- And in Fall, there’s a 21% reduction

![](https://peterattiamd.com/wp-content/uploads/2019/04/daylight-savings-time-and-AMI--1024x352.png)

**Figure 1. Actual and predicted acute myocardial infarction (AMI) counts for the week after the spring daylight savings time (DST) time changes.** Source: ([Sandhu et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4189320/))

⇒ Other examples involving daylight savings:

- Increase in [car accidents](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5734262/)
- Increase in [suicide attempts](https://onlinelibrary.wiley.com/doi/epdf/10.1111/j.1479-8425.2007.00331.x?referrer_access_token=L1OV6WjZSC5vE30cnb2Zcota6bR2k8jH0KrdpFOxC651gRQ4KXOU_WP69zgmsGENUKn__nS8HmAbHhbImljQc4YrLmBmBnb4ilfKmcmvYdg1W1za1F_xaXZoPRbrUOmIARXysQ4_Zy_kGaJT4LiQ4ZL7gB6GZL1dwSe8bc5WE_a2Mp-YIMBOXA4-TecLTwLkoAGaJMU3kaw9fPmAMjGeTtwaTeF_4uXKy5YOqemczDohpc_W2bnWL46D6HlK9IKLwMv_Db8esBkAGKcMXB2e8vHUDk3u3e6eUCs_1O7tSyw%3D)
- And [Federal judges hand out harsher sentences](https://www.ncbi.nlm.nih.gov/pubmed/28182529) on Monday after spring and are more lenient in the fall

⇒ Furthermore…

- The effect lasts for roughly 3 days
- In the northern hemisphere, you’d predict the opposite if sleep weren’t important because more sunlight. . .but despite this, the lost hour of sleep still has big effect.

Study: [Short sleep duration and incident coronary artery calcification.](https://www.ncbi.nlm.nih.gov/pubmed/19109114)

- Study tracked healthy adults without signs of CVD
- By the end of the study, those getting 5 hrs of sleep or less had a 200-300% increased risk of coronary artery calcification
- The study controlled for factors like exercise, smoking, BMI, snoring, etc.

*⇒ What is the mechanism?*

- With lack of sleep, the body becomes much more driven by the sympathetic nervous system (the fight or flight branch of the nervous system ratchets up)
- This means more adrenaline release, high spike in cortisol levels,  and blunting of growth hormone (all factors leading to atherosclerosis)

Other disease pathways affected by sleep deprivation

- Lack of sleep increases blood pressure (hypertension)
- Having an ApoE4 gene is a risk factor for Alzheimer’s, but one study showed that if you are [normotensive](https://en.wikipedia.org/wiki/Blood_pressure) (normal blood pressure), you don’t necessarily have an increased risk of Alzheimer’s disease, but if you are hypertensive, then your Alzheimer’s disease risk is far higher
- It’s like revving an engine in neutral; eventually the gaskets will blow

> “If there is one central, common pathway through which we can understand almost all aspects of the deleterious impact of insufficient sleep, it is through the autonomic nervous system, and specifically an excessive leaning on the fight or flight branch of the nervous system.”

## Fuel partitioning and dieting while sleep deprived [16:45]

Dietary changes when you are sleep deprived:

- [Inferior fuel partitioning](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3410277/)
- [Hyperinsulinemia](https://www.mayoclinic.org/diseases-conditions/type-2-diabetes/expert-answers/hyperinsulinemia/faq-20058488)
- Impaired glucose disposal
- A tendency to probably eat more crap

⇒ Peter says: “*I’m at my worst when I am sleep deprived. It’s so hard to avoid junk food. Whereas probably the single greatest tool in my arsenal to eat well, is to sleep well.*”

Fuel partitioning

- The energy balance of organism (regulation and input) – how much to eat and how the body uses it – is affected by sleep
- RQ ([respiratory quotient](https://en.wikipedia.org/wiki/Respiratory_quotient)) [goes up when sleep deprived](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3410277/)
- Respiratory quotient going up implies that **under the same level of exertion, you would preferentially go after glycogen for ATP, as opposed to fat**
  - This signals a metabolic inefficiency

Dieting while sleep deprived

- This [great study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2951287/) showed that dieting when underslept (6 hrs or less) was much less effective in terms of fat loss
- If underslept, 70% of what you lose is from lean muscle mass (the body holds onto fat)
- A big reason for this above is the high levels of cortisol (stress hormone) and insulin

## Sleep and the reproductive function: testosterone, sperm count, FSH, menstrual cycles, and fertility [19:45]

Testosterone in men

- Men who only get [5-6 hrs sleep have testosterone levels of men 10 years older](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4445839/)
- Men who sleep 5 hrs a night have [smaller testicles](https://www.ncbi.nlm.nih.gov/pubmed/30353813)
- Men who sleep [6 hrs or less have fewer sperm](https://www.ncbi.nlm.nih.gov/pubmed/28994211) and their sperm have more deformities in the sperm

[FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) and [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) in women

- One [experiment](https://www.ncbi.nlm.nih.gov/pubmed/11937126/) showed:
  - Women who sleep 5-6 hrs have a 20% reduction in FSH (a critical part of the reproductive pathway)
  - They also have a 30% higher rate of abnormal menstrual cycles
- “From a reproductive standpoint, this is devastation.”

Fasted state

- Men don’t seem to be less able to reproduce in a fasted state
- But women do tend to be less capable of reproducing when in a fasted state ([study](https://www.ncbi.nlm.nih.gov/pubmed/23382817), in rats)
- This could be due to the rise in [FGF21](https://en.wikipedia.org/wiki/FGF21), and the inhibition of FSH in women

Ketogenic diet and fertility:

- Seems that the keto diet could also have negative side effect on women trying to reproduce by increasing FGF21
- Would not recommended fasting or keto diet if a woman is trying to conceive

## The biological necessity of sleep, the lack of a “safety net”, sleep debt, and ways to course correct sleep problems [23:45]

“*Human beings are the only species that deliberately deprive themselves of sleep for no apparent reason. You almost never see other organisms undergo sleep deprivation.*”

A couple exceptions in nature where mammals sleep less:

1. certain mammals after giving birth to care for young (killer whales break from pod, give birth, then bring calf back to pod, utilize “short sleep” during that time)
2. under conditions of starvation (to give animal ability to forage in larger perimeter)

*How come people sometimes report not needing as much sleep while fasting?*

- Presumably because evolutionarily speaking they need to be more alert to search for food
- But be cautious because this feeling is temporary and you’re still accumulating sleep debt

*Why isn’t there a mechanism or “safety net” for insufficient sleep?*

- Mother Nature has never had to face challenge of sleep deprivation, so no biological “safety nets” for any essential functions without sleep
- Fat cells, for example, developed to store a caloric credit when food is plentiful and spend it in famine, but there is nothing like the adipose cell for sleep
- Hibernation is different: it does not give animal credit to sleep less in summer, it just reduces energy expenditure because there is so little food in winter

*Can you “sleep off” your sleep debt over the weekend?*

- People think they can accumulate sleep debt during week and then make it up on weekend (“social jet lag”)
- It’s like sleep bulimia (with binging and purging)
- It’s torture on circadian biology to drag body clock by 3 hours every weekend (“It’s like flying from San Francisco to New York every weekend.”)

Peter tells a story about a patient…

- The patient was living on the west coast but dealing with eastern European financial markets (he later moved to the east coast to reduce the time difference)
- He reached a point where he could not sleep past 3 am
- This took months to course correct with the help of a professional ([Vikas Jain](https://www.nm.org/doctors/1992965156/vikas-jain-md)) employing a strategy of reverse use of melatonin and blue light

The many tools to course correct sleep problems:

⇒ “There is a whole arsenal of tools in the sleep doc kind of box that we can use, to sort of make these manipulations, either be it for people with insomnia, be it people with anxiety, be it people with jet lag, or what’s called circadian phase delay.”

- exogenous agents like melatonin
- Blue light
- regular exercise
- exposure to daylight
- even manipulations of body temperature

Body temperature and sleep

- About 2 hours before wake up, see drop in temperature
- In Peter’s patient’s case, his temp was dropping at 1am so they needed to move the temperature drop 4am

![](https://peterattiamd.com/wp-content/uploads/2019/04/body-temperature-and-sleep-1024x781.png)

**Figure 2. Typical Twenty-Four-Hour Circadian Rhythm (Core Body Temperature).** Image credit: [Why We Sleep](https://download.audible.com/product_related_docs/BK_SANS_008129.pdf)

> “When you fight biology, and sleep is one of the most conserved behaviors across all living organisms that we’ve observed, when you fight that kind of innate hard grained biology, you normally lose. And the way that you know that you’ve lost, is disease and sickness, either acute or chronic. At some point a lack of sleep will get you.”

## Fighting cancer and improving immune function with sleep [34:30]

For the development of cancer, a couple things must go wrong:

1. First, a genetic insult
2. Second, that insult must be missed by immune system (most of the time [T cells](https://en.wikipedia.org/wiki/T_cell) identify it)

*How does sleep affect the immune system?*

- Significant link between sleep and cancer of [bowel](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3021092/), [prostate](https://www.ncbi.nlm.nih.gov/pubmed/?term=Gapstur+SM%5BAuthor%5D+prostate+sleep), and [breast](https://www.biorxiv.org/content/10.1101/457572v1) (3 of top 4 cancers)
- Causal evidence so strong that [WHO has classified night shift work as a “probable carcinogen”](https://www.medicalnewstoday.com/articles/236731.php)

⇒ UCLA study: [Partial sleep deprivation reduces natural killer cell activity in humans.](https://www.ncbi.nlm.nih.gov/pubmed/7871104)

- healthy adults limited to 4 hrs sleep for one night
- They measured natural killer cells (which identify foreign elements like cancer cells and destroy them)
- One night of poor sleep caused 70% drop in natural killer cell activity;
- “imagine what it could be after months of insufficient sleep”

“*I don’t think people necessarily appreciate that we pretty much always have cancer, and our immune system is pretty much always protecting us. It’s actually the exception when the cancer develops into something clinically.*” says Peter

*Why does cancer increase non-linearly as you age? A few hypotheses…*

- 1) Is it an increase in the rate of [mutagenesis](https://en.wikipedia.org/wiki/Mutagenesis)? Do you experience, on a per unit of time basis, a greater insult to the genome?
- 2) If the rate of mutagenesis does NOT increase, is it then that over time the accumulation and the expression, the phenotype of that, becomes more problematic?
- 3) Is it that our immune system, specifically the adaptive immune system, is weakening and the balance starts tipping in favor of cancer? ⇒ Lowering the volume of natural killer cells (like the [CD4 and CD8 cells](https://www.ncbi.nlm.nih.gov/pubmed/1909592))
  - When posing this question to experts on the topic, Peter says they mostly stay that they suspect it’s all of the above, but they all agree that **the weakening of the adaptive immune system is almost assuredly playing a role in why we get cancer more as we age**

**Sleep gets worse as we age, and therefore our immune system gets worse**

> “One of the most dramatic changes with age, and the most sizable and robust physiological changes with age that we see, is that your sleep gets worse. And sleep is probably one of the most powerful regulators of your immune system.”

- Most people have had at least one situation where they could only get 4 hours of sleep for one night… but it’s **staggering to think of the compounding problem**
- We have a system to cope with excess nutrients, even if not our modern diet, but we are terrible at measuring short-term consequences of sleep deprivation
- A lack of sleep bends curve of lifespan very dramatically, but no good way to measure or cope
- Was the lightbulb a step in wrong direction? When society switched from agrarian to industrial is when problem started, but not very long ago evolutionarily

Sleep and cancer development:

⇒ [Study using mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4247537/) by David Gozal at the University of Chicago

- Two groups of mice
- Both groups have cancer
- One group got normal sleep
- Other group has their sleep restricted
- Underslept mice had **tumors 200% larger** than mice who slept normally
- Cancer in underslept mice had also metastasized
- The study also controlled for hypercortisolemia by having the adrenal glands removed, which means they removed the possibility that the tumor growth was fueled by hepatic glucose output by controlling for the metabolic response
- *The mechanism?* ⇒  [Macrophage M1 cells](https://en.wikipedia.org/wiki/Macrophage_polarization#M1_macrophages) downregulated, and [M2 cells](https://en.wikipedia.org/wiki/Macrophage_polarization#M2_macrophages) (which promote tumor growth) upregulated by lack of sleep

⇒ In humans…you would have both the M2 cells upregulated as well as a “tsunami” of cortisol impacting the body and driving tumor growth

*A current clinical tragedy in diagnosis and managing cancer:*

- A patient with cancer diagnosis has anxiety, **can’t sleep**, etc. simply due to hearing the news of their diagnosis
- We are careful with chemotherapy, and meticulous in our research into causes of and types of cancer, yet we have almost but no papers on this topic of sleep and cancer
- “Something like this seems so obvious, and yet we just seem ill equipped to deal with it.”

## The medical profession: A culture that devalues sleep [47:30]

Walker looked at medical curricula of top 20 countries –

- most medical students get 1-2 hours of instruction about sleep during medical school
- This despite the fact that sleep takes up 1/3 of your life and makes such a huge difference to the 2/3 of life spent awake

**Medicine is a culture that devalues sleep**

⇒ A stark example is medical school…

- *Peter’s residency story #1*: on call every 3rd night, most amount of sleep he got on call was 5 fragmented hours, which happened only once.  He averaged 2-2.5 hours of sleep every 3rd night that he was on call. One Monday he was pre-call, worked 5 am – 7 or 8 pm, then volunteered to cover the ER that night.  Tuesday he was on call, slept 1 hour, left to go home at 6 pm on Wed when he had been up since Mon morning. On the drive home, every time he came to a stop sign he could not keep foot on clutch and kept stalling, decided he could not get on the freeway. Went to a park that was open air drug market, slept in the park from 6 pm to 2 am and awoke with rat bites on arms
- *Peter’s residency story #2*: He took an extra shift to cover for someone else. At 2 am on the third night, he was operating, fell asleep, and face planted on the patient in the middle of surgery.  He was then told just to hold retractor instead of performing the surgery; there was no real sense of alarm

**Matthew’s article in The Lancet**: [Sleep Prescription for Medicine](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(18)31316-3/fulltext)

- “I lay out the case for why both for patient and doctor, sleep is utterly essential, but profoundly absent.”
- If attending surgeon has slept only 6 hrs of previous 24, 170% greater chance of major surgical error
- If resident works 30 hour shift vs. 16 hour shift, 178% increased likelihood of car crash
- 1 in 5 residents make error due to insufficient sleep, 1 in 20 will kill a patient
- ER docs who work a 30 hr shift make 460% more diagnostic errors
- When lobby medical organizations and lay out this case, face incredible resistance ⇒ Minds made up, don’t want to hear facts

Peter’s previous opposition to the maximum 80 work week for residents

- Peter used to be very opposed to 80 hr work week
- He felt that the horrible conditions under which doctors and med students work selects the right people for the field
- In light of the new information that Matthew has presented, he now feels that the way of selecting future doctors can’t continue, there has to be a new screening tool

Continuity of care

- Only good argument against shift limits is continuity of care, meaning the more your caretaker changes that more difficult it would be to properly care for a patient because it requires properly communicating to the next resident/doctor what needs to be done
- But Matthew uses New Zealand, Sweden and France (who limit doctors to 12-16 hour shifts) and have highly ranked systems, so hard to see a case for it
- In the U.S., the 80 hr work week did not solve problem, did not reduce errors
- *Why?* Peter’s guess is that the cultural norm in those countries has a different mentality towards handing off patients. Overnight change of rule didn’t work in US because people in charge did not train under those rules and did not know what it meant to hand off a patient in those conditions

Too important not to change

- “We’ve been able to put people on the moon, and that was non-trivial, but we solved it. I think we can also probably solve continuity of care, and protect both patient and doctor alike.”
- “I don’t mean to trivialize the problem…I really appreciate how hard that is…but what I would also love to try and just make sure that we don’t lose sight of the end outcome here…rather than get perhaps distracted by how difficult the problem is.”

## The sleep needs of children, the travesty of early school start times, electronics at night, and advice for parents [1:04:45]

> “We will look back in probably 20 years with shame that we were having schools start at 7:30 in the morning.”

- Matthew argues that school starts way to early which is impacting the sleep of children
- He understands that it is very difficult change to make with buses, parent work schedules, etc.
- But urges that we don’t lose sight of end outcome; it’s a very difficult problem but still needs to be solved – there’s too much on the line

**Evidence**

When you delay school start times:

- [Grades improve and attendance improves](https://www.everydayhealth.com/kids-health/delaying-school-start-times-improves-students-performance-health/) according to a [Seattle study](https://advances.sciencemag.org/content/4/12/eaau6200)
- [Behavior problems drop](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4824552/)
- [Life expectancy up due to reduced car crashes](https://conservancy.umn.edu/bitstream/handle/11299/162769/Impact%20of%20Later%20Start%20Time%20Final%20Report.pdf;jsessionid=2734276A2B7AFD67ED579AE292F905C8?sequence=1)
  - Changed school start time from 7:35 am to 8:55 am start time change
  - Car accidents dropped 70% among 16-18 year olds
  - As a comparison, the invention of anti-lock brakes only dropped accidents by 20-25% and were considered a revolution

> “When sleep is abundant, minds will flourish, and if our goal as educators truly is to educate, and not risk lives in the process, then I feel that we are failing our children in a quite spectacular manner, with this incessant model of early school start times.”

**The sleep needs and sleep habits of teens**

- The need to sleep to later time is *not always solved by earlier bedtime*
- Need 9-10 hrs sleep even when 16-18 years old
  - Only ~11% kids get that much sleep
- On average, teens get about 7 hrs of sleep which is a bigger relative deficit than in adults
- **Parental disconnect**: 72% of parents think their teen is getting enough sleep
- Teens need to go to bed later and sleep later
  - Go to bed between 10 pm – midnight ⇒ sleep until 8:30 to 10:30
  - But not allowed to sleep like this during week, and it’s not enough to do it on weekend

⇒ “*They’re sleeping in because naturally their biological circadian rhythm, moves forward in time so they want to go to bed later and wake up later. It’s not their choice. They don’t get a choice in that. It’s biological, it’s hard wired.*”

*From 1960 to now:*

- In 1960s schools often stared at 9am
- Now it starts much earlier in part because of *parent work schedules*
- Kids are not taking up information in school

When you delay school start times…

- SAT scores improve
- Grades in *morning classes* specifically improve greatly

**The impact of a later start time**

- A 10am start time “*is probably sweet spot*”
  - UK has proposed a bill for 10am start times
- School day doesn’t need to be as long if students could learn more efficiently (which they do)
- Possible reduction in criminal behavior
  - Much of criminal behavior happens between 3-4pm when kids are out of school and parents aren’t yet home from work
  - So cost of starting school later and getting out later limits criminal opportunity window and pays for itself

Peter suggests school year round

- Summer vacation is an artifact of agricultural world
- Eliminate summer break and allow later times and more extracurricular time too
- Matthew:
  - “I love your idea, and I do think that the data supports it empirically.”
  - “The data just keeps coming out, and it goes in no other direction. It’s so consistent, it really is.”

*What else can parents do (if later start time isn’t an option)?*

- Try to excise technology and turn off lights
- On the basic impact of light ⇒ We are “dark deprived” and we need darkness to release melatonin

**iPhone/iPad and television usage**

⇒ Biological reasons to avoid electronics…

- [This study suggests using an iPad before bed has negative effect on sleep](https://www.ncbi.nlm.nih.gov/pubmed/25535358) ⇒ 50% drop in melatonin (aka you lose 50% signal of sleep timing), and your peak melatonin will arrive 3 ”
- iPad time also reduces REM time
- Effects last 2-3 days
- Television ⇒ TV doesn’t have quite the same effect, but… it does make brain associate bedroom with TV and “*when you start to form those maladaptive associations, it can be a trigger of insomnia and anxiety*.

![](https://peterattiamd.com/wp-content/uploads/2019/04/melatonin-cycle-1024x942.png)

**Figure 3. The cycle of melatonin.** Image credit: [Why We Sleep](https://download.audible.com/product_related_docs/BK_SANS_008129.pdf)

⇒ The mental component…

- “*I think this component may be . . . stronger than the biological component*”
- **Sleep procrastination**: Devices can cause sleep procrastination (Since it’s there, I’ll check email or FB one more time)
- Dependency causing an alertness spike: Surveys suggest many [kids wake up during night to check phones to check phones](https://www.hmc.org.uk/wp-content/uploads/2016/10/Mobile-Device-Media-Brief-FINAL.pdf) or social media
  - Dependency causing an alertness spike

⇒ Anticipatory anxiety:

- Devices and technologies cause what’s called anticipatory anxiety
- Most people, the first thing that they do when they wake up in the morning unlock this world of anxiety that comes flooding in through their phone (Emails, texts, social media, etc.)
- You essentially are training your brain to anticipate that wave of anxiety every morning
- That anticipatory expectation in the morning lessens the amount of deep sleep that you get
- You end up sleeping in a shallow state, and you don’t get the same amount of deep sleep
- And the greater the anxiety that there is coming in the next morning, the greater the reduction in deep sleep that you have the night before

*Summarizing his recommendation for kids getting more and better sleep*

- Limit tech for kids is best thing to do now to maximize sleep if school starts early
- Get tech out of bedroom
- [Social media in bedroom also leads to FOMO](https://www.ncbi.nlm.nih.gov/pubmed/30360407) (fear of missing out), which leads to insufficient sleep at night
- Teenage sleep problem has no easy solution, *but we need to stop fighting biology*

## How exposure to light affects sleep, and how modern society has changed our sleep habits  [1:26:15]

*Is it harmful to read in bed with a nightlight?*

- If you struggle with sleep (either sleep onset or maintenance insomnia), you should read in different room and go to bed when sleepy
- The brain is associative ⇒ to break association, get up and go somewhere else an only go back to bed when get sleepy
- You wouldn’t sit at table waiting to get hungry, so stop lying in bed waiting to get sleepy

LED light bulbs

- LED bulbs are more deleterious in terms of suppressing melatonin
- Warm red and yellow light is best, though *all light* will interfere with melatonin
- Lower wattage light is best for reading at night

*Have there been experiments where subjects were given no limits on sleep but put in perpetually light environment?*

1 [Premature babies in NICU](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5560620/#R6)

- Infants in an environment with fluorescent lights on all the time, even though not robust circadian rhythm in babies, need signals of light and dark
- When made it dark at night, babies had 50% better oxygen saturation, put on more weight, left NICU 2-2.5 weeks earlier

2 Reverse experiment:

- Group of people who usually sleep at 11 pm and sleep about 6-6.5 hours
- Put them in no electricity or artificial light
- Started going to bed at 9 pm (felt sleepy because of darkness signal)
- Started sleeping a bit more than 9 hours

Looking at hunter gatherers:

- Many sleep “[biphasically](https://en.wikipedia.org/wiki/Biphasic_and_polyphasic_sleep#Biphasic_sleep)” which means (long night sleep and then nap in afternoon)
- Hunter-gatherer tribes go to bed at 8:30- 9 pm
- Get 7-7.5 hrs of sleep
- Then nap in afternoon to make it about 9 hours total
- Examples include:
  - [Gabra in northern Kenya](https://en.wikipedia.org/wiki/Gabra_people)
  - [San people in the Kalahari Desert](https://en.wikipedia.org/wiki/San_people)

How modern society has changed our sleep habits:

- We’ve reduced the amount of sleep
- We’ve changed the timing of sleep
- So we’re getting less sleep and perhaps at the “wrong” time
- And finally the nature in which we obtain our sleep has been changed
  - It seems as though we are designed perhaps to be sleeping biphasically, which is a long bout at night, and then a siesta like nap in the afternoon

Another model of sleep:

- Sleep 4 hours, wake then go back for another 4 hours
- Called the [“Two sleeps” or the “First sleep and second sleep”](https://www.sciencealert.com/humans-used-to-sleep-in-two-shifts-maybe-we-should-again)
- That has happened around “Dickensian” era (1800s), but seems to have been a feature of social pressure (often ate in between)
- This is not the way we’re designed to sleep
- And there’s a [great book](https://www.amazon.com/At-Days-Close-Night-Times/dp/0393329011) written on this, says Matthew

## Is napping helpful? [1:36:00]

*What is the efficacy of naps?*

- Experiments show naps benefit learning, memory, immune function, & CV health and lower systolic BP
- 20 minute naps:
  - “What we’ve found is that you can go down as low as about 20 minutes of a nap, and still see some mental benefits, in terms of things like learning and memory.”
  - In [Why We Sleep](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316), Matthew adds “*so long as they contain enough non-REM sleep*”
- 90 minutes naps:
  - “That gives the ability of the brain to go through the full 90 minutes cycle, so that the brain can go through all of the stages of non-REM sleep, stages one through four, and it gets the shot to get to REM sleep.”
- In studies, nappers showed improvements in multiple parameters compared to controls who were relaxing in bed but not asleep
  - [Improving motor skills](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1828623/)
  - [Improving learning and memory](https://www.ncbi.nlm.nih.gov/pubmed/22114672)
  - [Brain power](https://www.medicalnewstoday.com/articles/180304.php)

*Should you nap if you have trouble sleeping at night?*

- If hard to sleep at night, do not nap during day
- [Adenosine](https://en.wikipedia.org/wiki/Adenosine) builds up in body beginning when you get up
- The more builds up, the sleepier you feel
- After 16 hrs you should have enough to fall and stay asleep
- During sleep, the brain will clear adenosine away, remove 16 hours of accumulated adenosine
- If you nap during day, especially in late afternoon, harder to fall asleep because nap removed some of the adenosine
- *That said*… if you can nap regularly and are still able to fall asleep at night, naps are fine

![](https://peterattiamd.com/wp-content/uploads/2019/04/sleep-reduces-adenosine-1024x594.png)

**Figure 4. Sleep (and caffeine) reduces adenosine.** Image credit: [Why We Sleep](https://download.audible.com/product_related_docs/BK_SANS_008129.pdf)

## The effect of cortisol levels on sleep [1:41:15]

*Describing the process of sleep*

- Sleep is balance among adenosine, cortisol, and melatonin (like an orchestra)
  - Crescendo of adenosine
  - Then decrescendo of [cortisol](https://en.wikipedia.org/wiki/Cortisol)
  - Then [melatonin](https://en.wikipedia.org/wiki/Melatonin) comes in

For more on sleep related processes see [AMA #4](https://peterattiamd.com/ama04/)

**High cortisol and insomnia**

⇒ Peter’s personal anecdote:

- Peter suspects that any sleeping issues he has are due to the cortisol axis
- His reasoning for thinking this is that he measures his melatonin levels and sees no problem there
- But since he measures his glucose levels continuously (with [CGM](https://www.dexcom.com/continuous-glucose-monitoring)), and he considers glucose levels a proxy for cortisol levels, he has noticed that “*the association between high night time glucose, and poor sleep, is overwhelming. And I suspect that it’s through this cortisol axis.*”

⇒ Leading theory of [insomnia](https://en.wikipedia.org/wiki/Insomnia):

- - Matthew says that the leading theory of insomnia is that the flight or flight/parasympathetic state of the nervous system is “turned up” too far
  - In normal cases: Cortisol will rise during the day and then it drops in the evening (hits nadir when people feel like it’s bedtime), and then a few hrs before you wake up, starts to rise again
  - In cases of insomnia: Cortisol is down in evening but then right before bed it spikes again (sleep onset insomnia), sometimes spikes again in middle of night and keeping someone from falling back asleep (sleep maintenance insomnia)

- *Walker guesses that if you measured HR variability, looking at contribution of sympathetic vs. parasympathetic systems, you would see sympathetic getting revved up just before sleep onset and then again in middle of night, underlying cortisol spike, which underlies awakening, which underlies insomnia.*

![](https://peterattiamd.com/wp-content/uploads/2019/04/circadian-rhythm-cortisol-1.png)

**Figure 5. The normal cortisol cycle.** Image credit: [trmorrisnd.com](https://trmorrisnd.com/2017/03/15/adrenal-fatigue/)

The glucocorticoid pathway

⇒ Peter asks: *Do you think that the sympathetic is driving the glucocorticoid, or the other way around?*

- Matthew says that we don’t have the evidence to say which drives which, but that both are tenable hypotheses
- “But what’s nice is the fact that we know they both happen, and can be causal contributors, which means that we’ve got at least two treatment targets that we can go after.”

**Treating high nighttime cortisol**

- Peter says that clinically this very hard to treat
- Much easier to treat thyroid or sex hormone dysfunction
- Also, easier to treat *low* sympathetic and *low* glucocorticoid function rather than the reverse
- Hardest problem is high sympathetic and high glucocorticoid output

⇒ Treatment options:

1. Behavioral therapy is required: i.e. changes in mindset (meditation) and routine (less stressful activities close to bedtime such as work emails)
2. [Phosphatidylserine](https://en.wikipedia.org/wiki/Phosphatidylserine) (400-600 mg): Peter uses this for jet lag circumstances (e.g., must go to bed when it’s only 2 pm in your brain) ⇒ *“Phosphatidylserine really seems to move the needle, both in terms of your glucose response and your cortisol response.”*

⇒ Matthew’s take:

- Glucocorticoid problem is very difficult to solve
- For sympathetic drive, it is likely a *behavioral intervention*

⇒ Meditation

- In researching the data on meditation and sleep, Matthew says…
  - “*The data was very compelling*”
  - Decreases the amount of time it takes someone to fall asleep
  - Improves the continuity of their sleep
  - Meditation apps (like [Headspace](https://www.headspace.com/) or [Calm](https://www.calm.com/)) … if you were to look at their usage statistics, you will already see that people are self medicating their insomnia by way of meditating right before bed

> “But meditation, I think, is a great way to drive a parasympathetic dominance of the nervous system, which is to take you out of the fight or flight branch, and more into this quiet sort of more introspective state.”

## Are sleeping pills doing more harm than good? [1:52:15]

Peter says that in many cases medication/pills aren’t as good as the correct action or behavioral change

⇒ Example: Taking metformin specifically for weight loss

- “I think Metformin is a really powerful pill, I don’t think it’s nearly as powerful as an exceptional diet.”
- “In the end, molecules that you take intermittently aren’t really nearly as potent as molecular changes that occur over a time course, behaviorally.”

Sleeping pills

- Sleeping pills we have on the market now (e.g. Ambien and Lunesta)
  - 1) don’t produce naturalistic sleep
  - 2) higher [risk of death](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4890308/)
  - 3) higher [risk of cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4890308/)

![](https://peterattiamd.com/wp-content/uploads/2019/04/sleeping-pills-and-mortality-risk-1024x851.png)

**Figure 6. Risk of Death from Sleeping Pills.** Image credit: [Why We Sleep](https://download.audible.com/product_related_docs/BK_SANS_008129.pdf)

[Ambien](https://www.webmd.com/drugs/2/drug-9690/ambien-oral/details)

- Peter used to take Ambien to sleep on cross-country flights
- Peter had several scary lapses of memory ⇒ Would send emails he didn’t remember sending or make calls without any recollection
- Ambien isn’t like sleep, “you’re confusing sleep with lack of consciousness” Peter was once told by [Kirk Parsley](https://twitter.com/docparsley?lang=en)
- Like hitting you over head and you’re unconscious, it hardly gives the restorative rest that sleep does
- Ambien is more like a “chemical baseball bat to the head” than something that’s actually promoting restorative and restful sleep

Sedative-hypnotics

- Current sleep drugs like Ambien and [Lunesta](https://www.webmd.com/drugs/2/drug-92350/lunesta-oral/details) are sedative-hypnotics
- Sedation is not sleep, it’s knocking your cortex out
- Not awake but also not in naturalistic sleep
- [Not same quality of deep sleep](https://www.ncbi.nlm.nih.gov/pubmed/25922426)
- [Higher association with mortality risk and linked to cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4890308/)

**A** [**“stunning study” looking at brain plasticity**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2572743/) **by Marcos Frank**

- Strengthening of brain connections leads to formation of memories
- The brain can adapt and rewire itself ⇒ If cover one eye, brain “rewires” connections to other eye’s section of brain (a phenomenon known as monocular deprivation plasticity)
- The study took a group of animal and put an eye patch on them
- First he allowed them “naturalistic” sleep
- Sleep “basically doubles strengthening of plasticity” relative to if you just keep the animal awake
- Then he dosed animals with Ambien
- They slept longer, so would guess it would improve rewiring, **but made it worse**
- Led to 50% unwiring of connections that had been laid down before

> “As parents get more concerned about their kids who may have more anxiety, who are having sleep problems, they’re turning to pills . . . You’ve got a brain that is developing, a brain that need to wire itself up, strengthen connections, build and mature, it needs to learn, it needs to consolidate, and then you’re providing a form of sleep through medication that may actually be un-wiring that nervous system, and un-wiring those memories, rather than strengthening them. That frightens me, that frightens me a lot.”

§

## Selected Links / Related Material

**Increase in heart attacks the day following daylight savings time**: [Daylight savings time and myocardial infarction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4189320/) (Sandhu et al., 2014) [06:15]

**Increase in car crashes day after daylight savings**: [Impact of daylight saving time on road traffic collision risk: a systematic review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5734262/) (Carey et al., 2017) [7:00]

**Increase in suicide attempts the day after daylight savings**: [Small shifts in diurnal rhythms are associated with an increase in suicide: The effect of daylight saving](https://onlinelibrary.wiley.com/doi/epdf/10.1111/j.1479-8425.2007.00331.x?referrer_access_token=L1OV6WjZSC5vE30cnb2Zcota6bR2k8jH0KrdpFOxC651gRQ4KXOU_WP69zgmsGENUKn__nS8HmAbHhbImljQc4YrLmBmBnb4ilfKmcmvYdg1W1za1F_xaXZoPRbrUOmIARXysQ4_Zy_kGaJT4LiQ4ZL7gB6GZL1dwSe8bc5WE_a2Mp-YIMBOXA4-TecLTwLkoAGaJMU3kaw9fPmAMjGeTtwaTeF_4uXKy5YOqemczDohpc_W2bnWL46D6HlK9IKLwMv_Db8esBkAGKcMXB2e8vHUDk3u3e6eUCs_1O7tSyw%3D) (Berk et al., 2008) [7:00]

**Federal judges handing out harsher sentences the day after daylight savings**: [Sleepy Punishers Are Harsh Punishers.](https://www.ncbi.nlm.nih.gov/pubmed/28182529) (Cho et al., 2017) [7:00]

**Increase in coronary artery calcification by 200-300% with 5 hours of sleep or less**: [Short sleep duration and incident coronary artery calcification.](https://www.ncbi.nlm.nih.gov/pubmed/19109114) (King et al., 2008) [8:45]

**Benefits of IGF-1 for protection from neurodegeneration**: [Comparative signaling pathways of insulin-like growth factor-1 and brain-derived neurotrophic factor in hippocampal neurons and the role of the PI3 kinase pathway in cell survival.](https://www.ncbi.nlm.nih.gov/pubmed/15140184) (Zheng et al., 2004) [12:45]

**Studies looking at the** ***APOE ε4*** **allele and blood pressure**: [The relationship between apolipoprotein E ɛ2/ɛ3/ɛ4 polymorphisms and hypertension: a meta-analysis of six studies comprising 1812 cases and 1762 controls](https://www.nature.com/articles/hr2009164) (Niu et al., 2009) [13:00]

**Studies looking at the** ***APOE ε4*** **allele and blood pressure**: [Risk factors for β-amyloid deposition in healthy aging: vascular and genetic effects](https://www.ncbi.nlm.nih.gov/pubmed/23553344) (Rodrigue et al., 2013) [13:00]

**Sleep deprivation causes a higher RQ which leads to inferior fuel partitioning**: [Poor Sleep Quality and Sleep Apnea Are Associated with Higher Resting Energy Expenditure in Obese Individuals with Short Sleep Duration](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3410277/) (Jonge et al., 2012) [16:40]

**RQ (respiratory quotient) goes up when sleep deprived**: [Poor Sleep Quality and Sleep Apnea Are Associated with Higher Resting Energy Expenditure in Obese Individuals with Short Sleep Duration](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3410277/) (Jonge et al., 2012) [18:00]

**Under slept men on calorie restriction lost more weight from muscles instead of fat vs. men getting 8 hours of sleep**: [Insufficient sleep undermines dietary efforts to reduce adiposity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2951287/) (Nedeltcheva et al., 2011) [18:30]

**Sleep deprivation and lower testosterone**: [Effect of 1 Week of Sleep Restriction on Testosterone Levels in Young Healthy Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4445839/) (Leproult et al., 2011) [20:00]

**5 hours of sleep or less is linked to smaller testicle size**: [Sleep Duration Is Associated With Testis Size in Healthy Young Men.](https://www.ncbi.nlm.nih.gov/pubmed/30353813) (Wang et al., 2018) [20:15]

**Men who are sleeping six hours or less will have fewer sperm and those sperm will have more deformities**: [Sleep duration is associated with sperm chromatin integrity among young men in Chongqing, China.](https://www.ncbi.nlm.nih.gov/pubmed/28994211) (Wang et al., 2018) [20:30]

**Women who sleep 5-6 hrs have a 20% reduction in FSH and Women who are sleeping that little too, typically have about a 30% higher rate of abnormal menstrual cycles**: [Relationship between sleep and secretion of gonadotropin and ovarian hormones in women with normal cycles](https://www.ncbi.nlm.nih.gov/pubmed/11937126/) (Touzet et al., 2002) [21:00]

**Study on intermittent fasting and reproduction in rats**: [Intermittent fasting dietary restriction regimen negatively influences reproduction in young rats: a study of hypothalamo-hypophysial-gonadal axis](https://www.ncbi.nlm.nih.gov/pubmed/23382817) (Kumar and Kaur, 2013) [21:00]

**Breast cancer and sleep**: [Investigating causal relationships between sleep traits and risk of breast cancer: a Mendelian randomization study](https://www.biorxiv.org/content/10.1101/457572v1) (Richmond et al., 2018) [35:15]

**Prostate cancer and sleep**: [Work schedule, sleep duration, insomnia, and risk of fatal prostate cancer.](https://www.ncbi.nlm.nih.gov/pubmed/?term=Gapstur+SM%5BAuthor%5D+prostate+sleep) (Gapstur et al., 2014) [35:15]

**Colorectal cancer and sleep**: [Short duration of sleep increases risk of colorectal adenoma](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3021092/) (Thompson et al., 2011) [35:15]

**World Health Organization classifies night time shift work as a probable carcinogen**: [Night Shift Working “A Probable Human Carcinogen”](https://www.medicalnewstoday.com/articles/236731.php) | Grace Rattue (medicalnewstoday.com) [35:30]

**Sleep deprivation reduces natural killer cells**: [Partial sleep deprivation reduces natural killer cell activity in humans.](https://www.ncbi.nlm.nih.gov/pubmed/7871104) (Irwin et al., 1994) [35:45]

**Tumors grow more in sleep deprived mice**: [Fragmented sleep accelerates tumor growth and progression through recruitment of tumor-associated macrophages and TLR4 signaling](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4247537/) (Hakim et al., 2014) [43:30]

**Matthew’s article in The Lancet**: [Sleep Prescription for Medicine](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(18)31316-3/fulltext) (Matthew P Walker, 2018) [54:45]

**Grades improve with later school start times**: [Sleepmore in Seattle: Later school start times are associated with more sleep and better performance in high school students](https://advances.sciencemag.org/content/4/12/eaau6200) (Dunster et al., 2018) [1:05:00]

**Behavior improves when kids sleep more**: [School Start Times, Sleep, Behavioral, Health, and Academic Outcomes: a Review of the Literature](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4824552/) (Wheaton et al., 2016) [1:05:00]

**Car crashes by teenagers dropped 70% when school start time shifted from 7:35 to 8:55am in Teton County, Wyoming**: [Examining the Impact of Later High School Start Times on the Health and Academic Performance of High School Students: A Multi-Site Study](https://conservancy.umn.edu/bitstream/handle/11299/162769/Impact%20of%20Later%20Start%20Time%20Final%20Report.pdf;jsessionid=2734276A2B7AFD67ED579AE292F905C8?sequence=1) (Wahlstrom et al., 2014) [1:05:45]

**Using iPad at night can significantly affect sleep and reduce your melatonin**: [Evening use of light-emitting eReaders negatively affects sleep, circadian timing, and next-morning alertness.](https://www.ncbi.nlm.nih.gov/pubmed/25535358) (Chang et al., 2015) [1:18:30]

**Teenagers admit to waking up during the night to check their phones**: [Research: Teenage use of mobile devices during the night](https://www.hmc.org.uk/wp-content/uploads/2016/10/Mobile-Device-Media-Brief-FINAL.pdf) (HMC ANNUAL CONFERENCE, 2016) [1:21:30]

**Correlation between the use of social media in the bedroom and the anxiety from FOMO**: [Fear of Missing Out as a Predictor of Problematic Social Media Use and Phubbing Behavior among Flemish Adolescents.](https://www.ncbi.nlm.nih.gov/pubmed/30360407) (Franchina et al., 2018) [1:25:15]

**Better light environment for premature babies in the neonatal intensive care unit leads to better sleep and better health (such as weight gain)**: [The NICU Lighted Environment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5560620/#R6) (Rea et al., 2016) [1:30:15]

**The sleep model called “Two Sleeps” or “First and Second Sleep”**: [Humans Used to Sleep in Two Shifts, And Maybe We Should Do It Again](https://www.sciencealert.com/humans-used-to-sleep-in-two-shifts-maybe-we-should-again) | MELINDA JACKSON AND SIOBHAN BANKS (sciencealert.com) [1:34:30]

**Book about the era of “Two Sleeps”**: [At Day’s Close: Night in Times Past](https://www.amazon.com/At-Days-Close-Night-Times/dp/0393329011) by A. Roger Ekirch | (amazon.com) [1:34:30]

**90 minutes naps improve multiple parameters compared to controls relaxing in bed but not sleeping**: [1:37:30]

- *Motor skills*: [Daytime Naps, Motor Memory Consolidation and Regionally Specific Sleep Spindles](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1828623/) (Nishida et al., 2007)
- *Learning, memory, and brain power*:
  - [Sleep-dependent facilitation of episodic memory details.](https://www.ncbi.nlm.nih.gov/pubmed/22114672) (van der Helm et al., 2011)
  - [Napping Boosts Brain Power](https://www.medicalnewstoday.com/articles/180304.php) | Catharine Paddock PhD (medicalnewstoday.com)

**Meditation and sleep**: [Meditation May Be An Effective Treatment For Insomni](https://www.sciencedaily.com/releases/2009/06/090609072719.htm)a | ScienceDaily (sciencedaily.com) [1:49:15]

**The electrical signature of your sleep when you are on Ambien shows that you don’t get into the same depth of deep sleep**: [Randomised clinical trial of the effects of prolonged-release melatonin, temazepam and zolpidem on slow-wave activity during sleep in healthy people.](https://www.ncbi.nlm.nih.gov/pubmed/25922426) (Arbon et al., 2015) [1:57:15]

**Ambien and other hypnotic sedatives and the link to mortality and cancer**: [Hypnotic drug risks of mortality, infection, depression, and cancer: but lack of benefit](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4890308/) (Kripke, 2018) [1:57:15]

**Brain plasticity study by Marcos Frank at Penn and how Ambien can unwire connections**: [The Non-Benzodiazepine Hypnotic Zolpidem Impairs Sleep-Dependent Cortical Plasticity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2572743/) (Seibt et al., 2008) [1:59:00]

§

## People Mentioned

- [Vik Jain](https://www.nm.org/doctors/1992965156/vikas-jain-md) (Stanford trained sleep doc at Northwestern) [31:15]
- [Margaret Thatcher](https://en.wikipedia.org/wiki/Margaret_Thatcher) (sleep and Alzheimer’s disease) [33:45]
- [Ronald Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) (sleep and Alzheimer’s disease) [33:45]
- [Thomas Edison](https://en.wikipedia.org/wiki/Thomas_Edison) (did the invention of the light bulb start our decline in sleep time and quality?) [42:45]
- [David Gozal](https://pediatrics.uchicago.edu/page/david-gozal-md) (lead study on cancer and sleep deprivation in rats) [43:30]
- [Kirk Parsley](https://twitter.com/docparsley?lang=en) (sleep expert, told Peter Ambien was no good)  [1:53:30]
- [Marcos Frank](https://labs.wsu.edu/sprc/sleep-and-performance-research-labs/frank-laboratory/) (lead a study on brain plasticity and sleeping pills) [1:59:00]
- [George Lucas](https://en.wikipedia.org/wiki/George_Lucas) [2:01:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/04/bio-image-500x500.jpeg)

##### Matthew Walker Ph.D.

Dr. Walker earned his degree in neuroscience from Nottingham University, UK, and his PhD in neurophysiology from the Medical Research Council, London, UK. He subsequently became a Professor of Psychiatry at Harvard Medical School, USA. Currently, he is Professor of Neuroscience and Psychology at the University of California, Berkeley, USA. He is also the founder and director of the Center for Human Sleep Science.

Dr. Walker’s research examines the impact of sleep on human health and disease. He has received numerous funding awards from the National Science Foundation and the National Institutes of Health, and is a Kavli Fellow of the National Academy of Sciences.

Dr. Walker is the author of the International Bestseller, Why We Sleep. It has a singular goal: to reunite humanity with sleep.

In addition, Dr. Walker is an internationally recognized [speaker](https://www.sleepdiplomat.com/speaker), a successful [entrepreneur](https://www.sleepdiplomat.com/entrepreneur), and a Sleep Scientist for Google.

[sleepdiplomat.com]

**Twitter**: [@sleepdiplomat](https://twitter.com/sleepdiplomat?lang=en)

**Center for Human Sleep Science**: [https://www.humansleepscience.com/](https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s)

**Matthew’s publications**: <https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s>