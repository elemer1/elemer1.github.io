# #368 ‒ The protein debate: optimal intake, limitations of the RDA, whether high-protein intake is harmful, and how to think about processed foods | David Allison, Ph.D.

**Source:** [https://peterattiamd.com/davidallison3/](https://peterattiamd.com/davidallison3/)

---

David Allison is a world-renowned scientist and award-winning scientific writer who has spent more than two decades at the forefront of obesity research. In this episode, David joins for his third appearance on The Drive to bring clarity to one of the most contentious topics in modern nutrition—protein. He explores the historical pattern of demonizing macronutrients, the origins and limitations of the RDA for protein, and what the evidence really says about higher protein intake, muscle protein synthesis, and whether concerns about harm are supported by actual data. He also discusses the challenges of conducting rigorous nutrition studies, including the limits of epidemiology and crossover designs, as well as conflicts of interest in nutrition science and why transparency around data, methods, and logic matter more than funding sources. The episode closes with a discussion on processed and ultra-processed foods, the public health challenges of tackling obesity, and whether future solutions may depend more on drugs like GLP-1 agonists or broader societal changes. This is part one of a two-part deep dive on protein, setting the stage for next week’s conversation with Rhonda Patrick.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/davidallison3/the_Drive_public.png)

Play

#368 ‒ The protein debate: optimal intake, limitations of the RDA, whether high-protein intake is harmful, and how to think about processed foods | David Allison, Ph.D.

#368 ‒ The protein debate: optimal intake, limitations of the RDA, whether high-protein intake is harmful, and how to think about processed foods | David Allison, Ph.D.

1x15s30s

0:001:49:24

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- The cyclical pattern of demonizing different macronutrients in nutrition and why protein has recently become the latest target of controversy [A: 3:15, V: 0:10];
- The origin and limits of the protein RDA: from survival thresholds to modern optimization [A: 6:30, V: 4:03];
- Trust vs. trustworthiness: why data, methods, and logic matter more than motives in science [A: 13:30, V: 11:50];
- The challenges of nutrition science: methodological limits, emotional bias, and the path to honest progress [A: 17:15, V: 16:07];
- Why the protein RDA is largely inadequate for most people, and the lack of human evidence that high protein intake is harmful [A: 30:30, V: 30:53];
- Understanding the dose-response curve for muscle protein synthesis as protein intake increases [A: 45:15, V: 48:17];
- Why nutrition trials are chronically underpowered due to weak economic incentives, and how this skews evidence quality and perceptions of conflict [A: 48:15, V: 51:27];
- The limitations and biases of nutrition epidemiology, and the potential role of AI-assisted review to improve it [A: 56:15, V: 1:00:40];
- The lack of compelling evidence of harm with higher protein intake, and why we should shift away from assuming danger [A: 1:04:15, V: 1:09:41];
- Pragmatic targets for protein intake [A: 1:09:30, V: 1:15:37];
- Defining processed and ultra-processed foods and whether they are inherently harmful [A: 1:16:15, V: 1:23:44];
- The search for a guiding principle of what’s healthy to eat: simple heuristics vs. judging foods by their molecular composition [A: 1:25:00, V: 1:34:16];
- Why conventional public health interventions for obesity have largely failed [A: 1:38:15, V: 1:49:14];
- Two ideas from David for addressing the metabolic health problem in society [A: 1:42:30, V: 1:54:33];
- The potential of GLP-1 agonists to play a large role in public health [A: 1:46:30, V: 1:59:21]; and
- More.

---

## Show Notes

\***Notes from intro**:

- David Alison is returning for his 3rd conversation on *The Drive*
- David is a world-renowned scientist and award-winning scientific writer who has been at the forefront of obesity research for the last 20 years and is currently the [director](https://www.bcm.edu/people-search/david-allison-181551) of the [Children’s Nutrition Research Center](https://www.bcm.edu/research/research-centers/usda-ars-childrens-nutrition-research-center) at Baylor College of Medicine
- Peter wanted to have David on because protein has become one of the most contentious and confusing topics in nutrition today
- What was once a fairly straightforward subject has now turned into a debate full of conflicting claims, dogma, unnecessary controversy, and a whole lot of name-calling
- David brings both a deep understanding of the science and a clear-eyed perspective on how to separate evidence from opinion
- This is part one of a two-part deep dive on protein, and next week, I’ll be joined by Rhonda Patrick for part two, after which we’ll put this protein discussion to rest once and for all

In this episode, we discuss:

- The historical cycle of demonizing macronutrients and why protein has recently become the focus
- The origins and limitations for the RDA for protein and what the evidence suggests about optimal intake for health, longevity, and performance
- Conflicts of interest in nutrition science and why transparency around data, methods, and logic matter much more than funding sources
- The challenges of conducting high-quality nutrition studies, including the debate over crossover designs, the limits of epidemiology, and the underfunding of rigorous trials compared to pharmaceutical trials
- What the evidence really says about higher protein intake, muscle protein synthesis, and whether concerns about harm are supported by actual data
- How to think about processed and ultra-processed foods, including definitions, heuristics, and the question of whether they’re inherently harmful or simply a convenient villain
- The difficulty of tackling obesity through public health
- The limits of current approaches
- And whether future solutions may rely more on drugs like GLP-1 agonists or broader societal changes

## The cyclical pattern of demonizing different macronutrients in nutrition and why protein has recently become the latest target of controversy [A: 3:15, V: 0:10]

- David just got a great new gig at the Children’s Nutrition Research Center in Houston, Texas and Baylor College of Medicine in Texas Children’s Hospital
- We’re going to start by talking about something that Peter doesn’t want to talk about (he’s sick and tired of talking about it), but this is a topic that has gone from being pretty straightforward to somewhat contentious
  - He apologizes in advance to all the listeners, they’re probably sick and tired of hearing about this
  - He will do his best to refrain from speculating on the reasons why it has become contentious
- Let’s try to dive into the arguments around the macronutrient that is more in the crosshairs than any other today, which is **protein**
- That’s interesting when you consider the arc of David’s career
- It was certainly easy to understand how people demonized fat and then they demonized carbs
- Here we are today, come in full circle, we’re demonizing protein

**Where do you place the demonization of protein in the arc of the historical lens of nutrition?**

- It shows many things, but at some level, it’s almost perfectly predictable, which is: ***we all eat, we eat every day***
- Eating is part of our sustenance, but it’s part of culture, family, certainly part of economics, identity, social class, religion, and so on
- So, it’s fun to talk about and there’s lots of motivations, motivations people recognize and motivations they may not recognize
- That leads always to this attention on it

***That attention drives a big economic engine of food sales ‒ there’s lots of interest in this and lots of stakes in this (if you’ll pardon the pun)***

- People shift, and it’s not even just the macronutrients
- This week, it’s seed oils, and next week, it’s phytoestrogens and soybean feminizing youth

> “*It’s one thing after another where people look for the villains and the heroes and the angels and the demons in food.*”‒ David Allison

- There are only 3 macronutrients, so they keep looping around
- Protein has become in the last few years almost a fever pitch of enthusiasm and excitement from one part of the community, and it’s driving sales and it’s driving behavior
- Some people like David are having fun with it
- There’s always that group that sees other people having fun or making money and heaven forbid doing something that might be seen as the easy way out or the contrived or constructed way out as opposed to the so-called natural way out of doing something and then that upsets them, that offends them
  - You’re not being prudent, you’re not taking the natural course, you’re not taking the old-fashioned course, you’re having too much fun, you’re trying too hard to achieve big things (we don’t like that)
  - So, we’re going to try to pooh-pooh it or shut it down or minimize it.
  - That’s where David thinks things are
- Peter presumes at some point this will no longer be relevant and no one will talk about it and we’ll move back to fats being the bad thing
  - Although, we’re there with seed oils

## The origin and limits of the protein RDA: from survival thresholds to modern optimization [A: 6:30, V: 4:03]

**The debate around the RDA and recommendation of 0.8 g of protein per kg of body weight**

*Tell folks a little bit about where that came from?*

- To put that in perspective, Peter weighs 180 lbs, that’s probably 82 kg
  - According to the RDA he should be eating 60-65 g of protein
  - It’s the middle of the day and he has had 60 g of protein already, so he could basically stop eating protein for the rest of the day right?
- Yeah, some people would say that
- A more active proponent of the importance of not only greater amounts of protein but particular types and distributions would be somebody like [Don Layman](https://fshn.illinois.edu/directory/dlayman)
  - He might say, “*Peter, you actually need to be eating protein at least three or four times a day*.”
  - [he was the guest in [episode #224](https://peterattiamd.com/donlayman/)]
- Peter adds that he ate that 60 g of protein in 1 sitting

**⇒** David clarifies that you probably want to hit about 30 g of protein at each sitting

- He emphasizes the word “about”
- It’s not like there’s some mathematical proof that there’s some hard threshold
  - Certainly not for Peter who is 20% bigger than David, that Peter’s hard threshold would be the same as David’s hard threshold
  - But in the neighborhood of 30 g of protein
  - [[Studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC7398777/#sec4) by [Luc van Loon](https://www.maastrichtuniversity.nl/ljc-van-loon) show significant increase in muscle protein synthesis after consuming 30 or more grams of protein after exercise, shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f1-davidallison3.png)

**Figure 1. Muscle protein synthesis after consuming protein post-exercise**.Image credit: [*American Journal of Clinical Nutrition* 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7398777/#sec4)

**David’s takeaway**: right off the bat, if you follow that advice, you’d need to be having double [the RDA] amount of protein and you’d have to have it distributed differently

- If you have it distributed the way you’d currently did, it’d be more than double
- David thinks there are a lot of people who disagree with that

**⇒** The history is people at some point recognized that we needed protein to live, and the key indicator of that was nitrogen

People looked at [nitrogen balance](https://en.wikipedia.org/wiki/Nitrogen_balance)

- How much did you take in?
- How much did you excrete?
- And they found that people could achieve nitrogen balance (or at least ordinary normal people of the time at about that level) [with the RDA of 0.8g/kg]
  - No one ever proved, demonstrated or even claimed that that was the best amount or the upper limit
  - It was just that’s probably enough to maintain nitrogen balance, which probably means it’s compatible with survival

If you think about the early days (in history), that was pretty important

- Europe couldn’t reliably feed its population until 2 things were entered into Europe
  - 1 – Was guano, bat poop (fertilizer)
  - 2 – The other was potatoes
- After Columbus came back from Hispaniola, he brought back guano and potatoes (among other things)
- Suddenly, Europe could feed its population
- But it took a while for the potatoes to catch on
- Louis XV actually wore a potato boutonniere to get people to think that they were safe
- 2 Polish scientists in 1928 published a [paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC1252113/) in which for 6 months they fed 2 young people nothing but potatoes and a little bit of fat they were cooked in and a little bit of fruit to avoid deficiencies
  - They never said they were the young people, but David suspected perhaps they were one man, one woman
  - The only source of protein for practical purposes was the potato
  - What they showed was the nitrogen balance was perfectly fine
  - Despite this being what some people think of as a“bad carbohydrate,” no one got diabetes, they didn’t gain weight

Peter asks, “*How many calories did they eat a day?*”

- David doesn’t remember, but they were roughly n normal weight, thin people of the time
- He would guess it was in the neighborhood of  2,000-2,500

***Doing nitrogen balance studies and finding that they were perfectly fine is entirely different than saying, “What if they were older people or what if they were pregnant or what if they were recovering from a bicep tendon tear or what if they were bodybuilding?”***

- Or what if they were active?

The USDA-based studies on this topic

- Peter points out that when you go back and look at some of the USDA-based studies on this topic, the subjects were lean (about 150 lbs) , inactive, sedentary young men
  - He [wrote](https://peterattiamd.com/determining-optimal-protein-intake/) about it recently
  - These are guys that weighed 65-70 kg, very inactive, and it was demonstrated in that that you could easily achieve nitrogen balance at 0.8 g of protein per kg of body weight
- Let’s do the math and make it easy, say 50 g of protein was able to keep these folks in nitrogen balance

***You have to look at the population that is studied and ask the question, “How do I differ from that population? Am I bigger? Am I training? Do I have a more ambitious goal than not dying or not wasting away?”***

- This is an interesting question, and this is true of clinical research
- Peter doesn’t want to minimize those goals because David alluded to the fact that for the vast majority of human history, not dying was an amazing goal
  - Living to the next day, to the next harvest, to the next season was essential for 99.99% of human history

> “*This idea that being optimal or thriving, it’s a very, very modern luxury we have*.”‒ Peter Attia

- David agrees, there are different kinds of goals that we optimize or select for
  - This is actually the very nature of evolution, what’s being selected
- [Steve Simpson](https://www.sydney.edu.au/science/about/our-people/academic-staff/stephen-simpson.html) and [David Raubenheimer](https://www.sydney.edu.au/science/about/our-people/academic-staff/david-raubenheimer.html) from Australia study something called the “[protein leverage hypothesis](https://pubmed.ncbi.nlm.nih.gov/31339001/)”
  - ***What they’ve shown in experimental settings is that animals consume enough protein to optimize their genetic fitness***
  - Genetic fitness meaning how many of their genes they’re able to transmit to the next generation ‒ which is if you want to win the evolutionary game, that’s your goal

**⇒** Genetic fitness is different than living a lot longer

- Living a lot longer is winning the personal game, but not your “genes game”
- It may be that we now want to shift a little from one toward the other, and it may even change during the course of life
  - It may be that at one point in life my goal is to be as perhaps big and strong as I can
  - Maybe at another point in life, my goal is to slow aging
  - I may have different strategies for those 2 different things

## Trust vs. trustworthiness: why data, methods, and logic matter more than motives in science [A: 13:30, V: 11:50]

**Full disclosure**: both Peter and David are involved with a company called [David Protein](https://davidprotein.com/pages/about-us) that makes protein bars

- We’re going to be talking about protein today and unrelated but related, we’re also going to talk about processed food (which Peter thinks is a very interesting topic)
- This is a company that makes high protein bars, which are by definition processed
- Peter wants to make sure everybody listening understands that he’s involved in that company and David is an advisor as well

**Peter would like to hear David’s thoughts on the argument that says, “*****Well, Peter and David, you guys can’t really have an open and honest discussion about this topic because you have this conflict of interest.*****”**

- David points out a couple of factual points of clarification
  - 1 – Yes he has a grant from and has been a paid advisor to the David Protein company
  - 2 – The “David” in David Protein is not David Allison (he doesn’t own the company)
  - 3 – He likes the bars, eats them
  - Every time he takes one out at a meeting or something, someone will look at him and say, “*How vain are you? You have your own personalized bars with David printed in big…*”
  - He clarifies, “*No, it’s not me. It’s Michelangelo’s David. The idea is if you eat the bar, you’ll look like that David.*”

**Full disclosure**: David had a [protein conference](https://www.linkedin.com/posts/david-allison-2917963b_protein-workshop-agendapdf-activity-7288635602437083136-bFSh/) that ran about 6 months ago (it was amazingly successful)

- The degree of interest from academia and industry and others are tremendous
- They must have had somewhere on the order of 50 different companies contribute

**Full disclosure**: David has had funding from National Cattlemen’s Beef Association, Pork Producers, and other groups with interest in protein

**In terms of the idea of, “*****Does that make us trustworthy or not?*****”**

- What makes us trusted, that’s somebody else’s judgment
- Trust me or don’t trust me however much you want, that’s up to you
- Trustworthy has to do with the processes

> “*My colleagues and I, we have a saying… ‘In science, three things matter: the data, the methods used to collect the data (which give them their probative value, which shows what they mean), and the logic connecting the data to conclusions. And everything else is tangential.’*”‒ David Allison

- Some people who don’t have “the goods on an argument” will resort to other things
  - They’ll resort to ad hominem attacks
  - They’ll resort to innuendo
  - They’ll resort to quips
  - Quips are great; innuendo and ad hominem attacks, not so great
- But none of those are dispositive and you may think about things we can really declare things known or not known
- No one needs to argue about your conflicts of interest if you say that I can prove that there’s a greatest prime number, and people say, “*Well, no, you couldn’t prove there is*.”
  - I don’t have to say maybe you’re paid for by the prime number company or something
  - I can just say, “*Here’s the proof and you’re wrong and there’s no point in discussing anything else.*”
- Peter jokes, “*The prime number company. Think of the value, David, of prime numbers if they were finite.*”
  - Can you imagine how much the value of 3, 5, 7, 11, 13?
  - Those numbers would increase in value so much more if they became finite
- David compares it to Bitcoin: decoding and encoding Bitcoin

***Peter thinks that’s a very elegant explanation and reiterates the point, “At the end of the day, the three things that matter are what are the data, how were the data collected, what were the methods used to collect them, and then what is the string of logic that connects those data to their conclusions. All of these things should be quite transparent.”***

## The challenges of nutrition science: methodological limits, emotional bias, and the path to honest progress [A: 17:15, V: 16:07]

- Peter points out that nutrition science is a field of inquiry in which it can be more difficult to do all of the above than in genetics or biochemistry or particle physics

**In nutrition science the manner in which data are collected is particularly difficult**

- Peter doesn’t think nutrition scientists are at a loss for logic, but where he thinks they struggle (if they’re studying humans at least) is collecting these data can be really challenging, really expensive
  - The species of interest is not amenable to close quarters for long periods of time, which is how you would run a controlled experiment in a biological setting

*This is maybe more of a philosophical question, but what is the future of nutrition science?*

This is a tangent but Peter wants to know:

- Do you believe that there is a much brighter future, a step function and improvement in the quality of nutrition science that lies ahead with AI, synthetic data collection or creation rather?
- Is there something that could fundamentally change nutrition science in terms of how we go about gathering data? So that we could be potentially less reliant on epidemiology (which we will discuss the shortfalls of today)

***David thinks things will get better***

- Whether it’s a step function or not, he’s not so sure

**To expand and add to the branch Peter has thrown in, David thinks there are 2 reasons why nutrition science is so fraught**

- 1 – The methodologic challenge that Peter pointed out
  - Can we collect the kind of data we really want with the kind of methods we really want?
- 2 – The other part is the social aspect, which they’ve hinted at
  - Which is why is it so emotional?
  - Why do people attack each other?
  - Why do people go beyond the data?
  - David sees that in any area

> “*The more that area of inquiry is related to economics, religion, social values, personal experiences, the more you get the emotion and the deviation from logic and so on*.”‒ David Allison

- We see it in whatever people study: child-rearing, same-sex marriage

***Anything that has that emotional valence, that everyday experience and so on, leads to more bringing in of non-scientific points of view***

- That’s something we have very strongly and then the other we have is the methodologic challenge of collecting the data
- David sees benefits on both fronts, but he thinks both will be slow
- In many cases ***it’s not going to be a simple thing*** of “*if we could just fix that, if we could just figure out how to measure food intake in free-living people well and we’re on the horizon, then everything will be okay*”
- That’s important and David hopes we do figure out how to measure food intake well in free-living people, but that alone will not be a sufficient solution

***On the front of the emotional piece, it’s going to get better slowly***

- When you look at the arc of history of much of human endeavor, you look over the long haul, things are always getting better.
  - At least from David’s point of view and the point of view of people like [Steven Levitt](https://pricetheory.uchicago.edu/levitt/) and so on
  - You smooth the function a little bit: murder rates are way down, violence rates are way down, education rates are way up, lifespan is up, freedom is up, etc.
- But there are lots of ebb and flow, and we may be in a little bit of an ebb and flow now

***But David does hope that things will get better as they always have and have some more rationality***

- As scientists, we focus too much on immediate trust in science and saying, “*We need to get more trust in science and on immediate issues. How do we get trust in this issue about vaccines or drugs or what have you?*”

**⇒** Instead of saying, “*How do we get trust in the scientific process?*”

- How do we maybe risk losing a battle?
- Maybe I’m not going to convince people today that what I think about food additives or vaccines or protein or something is the “right answer” and I have to live with that
- But if I can convince them that I’m an honest broker and here’s how science works and we can work together through science, in the long run, I think that’s better

***Restoring trust in the scientific process is something we need to focus on***

**In terms of the nutrition per se, we have so many challenges**

- As a methodologist, David likes challenges (he has job security and it’s fun)
  - He likes figuring things out
- 1 – We can’t **randomize** to everything. So, how do we get **causal inference**?
- We can’t blind every aspect of diet, and if we could, we’d be missing some of what we’re trying to study because some of the effects of diet involve the effects of perceiving what you’re eating
- Some of the effects of this drink I’m drinking is how it tastes, and if you blind me to it, then you’ve taken away that potential effect
- 2 – There are **issues of measurement**: How do you know what I really ate?
- 3 – There are **issues of adherence**: If you tell me to drink one of these every day, do I actually do it?
  - Do I drink one and only one as you’ve instructed?
- 4 – There are issues of **duration**
  - Could you get me to drink it now and measure something in me 15 minutes later? Sure
  - Could you get me to drink one every day for the next 20 years and measure stuff? Difficult
- 5 – There are issues of the **model organism**
  - We’re going to talk about longevity a little bit
  - Somebody once said to David, “*You never want to study longevity in an organism that lives as long as you do*.” It’s a bit of a challenge
- If you and I at our age were to start a big study of 20-year olds and give them different nutrition and see who lives longer
  - [with the goal of:] That’ll help me figure out for myself what to eat
  - I’ll be dead long before the study is in and not be able to benefit from it and also not be able to find the answer
  - Maybe we want answers before 60 years from now
- Those are just a few of the many challenges we have in nutrition and David could go on and on

***David thinks we’re going to chip away at them, but but a lot of it’s going to have to be settling for various rough inferences and to be honest with the public about the limits***

- To say (for example), “*I need to say I haven’t shown this unequivocally, but it looks like this is the most reasonable answer now or the most supported answer now. I’m willing to accept that. But let’s be honest, that’s not demonstrated*.”

**A great example of the need to be honest with the public about the limits of scientific findings**

*The feud in the literature now between* [*Kevin Hall*](https://www.kevinhallphd.com/) *and* [*David Ludwig*](https://hsph.harvard.edu/profile/david-s-ludwig/) *on the use of crossover designs*

- [Crossover designs](https://en.wikipedia.org/wiki/Crossover_study) in which you give person, let’s say, diet A followed by diet B, and you give other people randomized to diet B followed by diet A
- They have an Achilles’ heel that is not there for let’s say parallel groups where it’s just some get diet A and some get diet B

**⇒** You can have what’s called [carryover effects](https://en.wikipedia.org/wiki/Crossover_study) in crossover studies

- David has started to study this, there’s almost no way around it
  - He tipped his hat to David Ludwig who pointed the issues out to him and he hadn’t fully comprehended them before that

Peter asks, “*Even with a washout [period] between the crossover?*”

- Not in an absolute way
- You get into what David calls “argument land”
  - You can say, “*Come on, David. It was a blinded drug I gave and I know the kinetics of it and I know it’s out of the system by this date. How could it possibly be having this?*”
  - And he could say, “*Well, Peter, you’re probably right. It’s a good argument, but the validity still depends on your argument. It’s not an absolute a priori proof.*”
  - If he said, “*Well, maybe what the drug did is it permanently changed something in that person*.”

**We should just explain for listeners why this is an important discussion in science, especially in human trials and especially in human trials with nutrition**

- Because there’s real statistical power, a statistical gift that comes from being able to do a crossover in that you can now leverage a [student t-test](https://en.wikipedia.org/wiki/Student%27s_t-test), for example
  - He doesn’t use the word “[statistical power](https://en.wikipedia.org/wiki/Power_(statistics))” in the β sense of the word

**⇒** The Student’s t-test is a very powerful statistical tool that allows you to use fewer subjects and therefore a fraction of the cost

- Peter doesn’t follow this debate, but he’s going to guess that David will say that Kevin Hall favors a crossover
  - Not to speak for Kevin
- He would bet the reason Kevin favors it is because the type of work Kevin does is insanely expensive
  - He’s putting patients in metabolic chambers and therefore the fewer patients that he needs to do that with, the easier he can do his work

*Is that basically the argument?*

- You are absolutely correct
- David agrees with the description of [power](https://en.wikipedia.org/wiki/Power_(statistics)) in the β sense
  - It is statistical power, the probability of rejecting the null hypothesis if the null hypothesis is false (which is 1-β, the [type II error rate](https://en.wikipedia.org/wiki/Type_I_and_type_II_errors))
- There’s actually a little bit more, but David thinks 90+% of the motivation is what Peter has described

Another point that Kevin pointed out to David: sometimes it’s just **throughput**

- Even if I had infinite money, I can’t put people through the procedure fast enough because there’s only so many chambers
- Someone else pointed out that it could be patient availability
  - If I wanted to study something in a rare population, I can’t get 1,000 people even if I had the $ because they don’t exist

***All of these things strongly favor the crossover, which in almost all circumstances will be much more statistically powerful***

- Meaning you can get the same amount of precision out of many fewer subjects

David explains, “*The problem is that you have this carryover and so that the difference between the 2 groups who get treatment A and treatment B in the second period could be a function of the true effect of treatment A versus treatment B in the second period or could be an effect of what treatment A and treatment B did in the first period carrying over*.”

- Now you don’t have a clean estimate of the effect of treatment A or treatment B anymore

What you can do is what you said is a [washout](https://online.stat.psu.edu/stat509/book/export/html/749#:~:text=A%20washout%20period%20is%20defined%20as%20the%20time%20between%20treatment%20periods.)

- If you said, “*I understand how this thing works and it’s a molecular effect, it’s not a social effect, it’s not learning, it’s not a surgical thing, and then cut a piece of their anatomy out that doesn’t reverse. This thing is completely reversible, it’s completely blinded. I gave a long enough washout*,” then by that argument, you can say I rule it out
  - But you can never say, “*I absolutely rule it out*.”
- If you’re dealing with things other than that where you can’t have a long enough washout or it might be a psychosocial effect or a learning effect or some permanent effect, anything from bariatric surgery to something like an allergen which may permanently sensitize the body
  - For example, people say maybe the mRNA hangs around for a while ‒ is that a permanent effect or a vaccine itself, we hope in some cases, is a permanent effect like a measles vaccine?

***All of those things, they’re not going to wash out and those are things where the crossover has a limit***

The question is, does that mean you try to do what [Ludwig](https://www.drdavidludwig.com/about-the-author/) is arguing?

- Ludwig is saying they’re just invalid
- (David hopes he’s not putting words in Ludwig’s mouth)
- Either don’t use them at all, or you can only use them in this way
  - Again, David hopes he’s  not inappropriately putting words in Ludwig’s mouth
- If you get what looks like it might be a [period-by-treatment interaction](https://pmc.ncbi.nlm.nih.gov/articles/PMC8342834/#:~:text=Analyzing%20for%20the%20period%2Dby%2Dtreatment%20interaction%20is%20used%20to%20determine%20whether%20the%20two%20treatment%20effects%20are%20different%20in%20the%20two%20periods), then discard the study, it’s invalid

Or do you accept the limitations of the study? (which David thinks [Kevin](https://www.kevinhallphd.com/) would say and he would side with)

- It doesn’t mean it’s a flawed or incorrect study
- It means it’s a limited study

***As long as you point those limitations out, you may or may not want to accept it***

- In the same sense, if you have an [observational epidemiologic study](https://en.wikipedia.org/wiki/Observational_study), most of us would not say never do one again, they have zero value
- What we’d say is they’re not invalid studies in and of themselves
- What they do is they leave open alternative explanations for findings other than causation
- It could be some bias of measurement error, it could be some bias of sampling, it could be some reporting bias, it could be some confounding, etc.

***We say as long as you acknowledge those, then the [observational] study shows what the study shows ‒ it’s weak inference, but it’s not nothing***

- David thinks the same things with crossover, and we may have to accept that with lots of stuff

> “*That’s the idea of nutrition. We may have to accept there are these limitations of our knowledge.*”‒ David Allison

For example, if you do a study of cheddar cheese made in Wisconsin versus some appropriate control

- You might say, “*Look, this is what the effects I get of this, and so therefore cheese consumption has this effect*”
- David would ask:
  - Are you sure it’s cheese consumption in general or is it just cheddar cheese?
  - Is it just cheddar cheese made in Wisconsin or is it any cheddar cheese?
  - Is it only cheddar cheese when eaten with these other things?
- That’s something that’s so hard to control in nutrition that we’ll wind up with these statements of saying it looks like it’s cheddar cheese in general and maybe we can do some other studies to suss it out
  - Or it looks like it’s cheese in general
  - But we’ll always have this saying, “***This looks like what it is. Here’s a good recommendation, but it’s not absolute knowledge.***”

## Why the protein RDA is largely inadequate for most people, and the lack of human evidence that high protein intake is harmful [A: 30:30, V: 30:53]

- [Don Layman](https://fshn.illinois.edu/directory/dlayman) and others have argued that the RDA is insufficient if you’re actually trying to optimize health
  - If you want to avoid [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia) later in life
  - If you want to achieve your peak in physical performance (that’s not the peak of physical performance)
  - If your objective is beyond survival, you might want to have more

**⇒** The numbers for that seem to converge in the ballpark of 1.2 to 1.6 g/kg if you’re trying to go for a minimum effective dose

- But it could easily be up to 2 [consuming 2 g protein per kg of ideal body weight]

**What is your best aggregation of the data on where you start to reach diminishing returns?**

- Peter hesitates to talk this way because it’s the way he things, but it’s not the way others do
- He always thinks about the concavity of a curve
  - So, the more concave down it is, the more negative the second derivative, the quicker you get to that point of diminishing return
  - It just means the curve is shaped that way
  - Most things in biology work that way
  - They’re not positive second derivatives, where the more you do, the better it gets and the rate at which it gets better goes up (that’s very rare)

*What is your gestalt on the optimal zone based on all of the above?*

- It’s important to distinguish between concave downward or a curve that doesn’t keep accelerating
  - A decelerating curve (curve with a negative second derivative) versus non-monotonic
  - Those can be non-monotonic, but it’s not the same thing
- 1 – Is the diminishing returns: it keeps going up, but it goes up ever more slowly and there may be a point at which it never reaches
  - That point that it never reaches may not be 100% of whatever it is you’re thinking about
- 2 – That’s different than saying it else actually goes down at some point
  - A lot of things go down at some point
  - Too little will kill you, too much will kill you
  - That’s actually more common in biology
  - Too little thyroid hormone is a very bad thing
  - Too few calories, too many calories
- In the case of protein, if we’re thinking about it not in an absolute sense, but as a % of calories
  - And that’s assuming your calories are at an appropriate level

What we can say with pretty good confidence is there’s some level that’s too low

David adds, “*I think we can also say with pretty good confidence that there’s* ***some level above the RDA*** *that with very, very rare exceptions perhaps is at most not worse than and in the vast majority of cases, likely better than the RDA level.*”

- Analogy: you might think of it as the real base level like “economy rental,” and then there’s the higher end, “good rental,” and then there’s something further out there where David would say there’s less certainty and that’s where probably a little more of the debate is
- So, there’s not no debate between the base level and what he’s saying is closer to a superior level
  - He doesn’t want to use the word optimal because that implies a dip

***There’s not so much debate between the base level and superior level of protein intake while there is more debate about the benefits of protein intake beyond the superior level and a lot of uncertainty there***

- David thinks the evidence is very clear that when you go from the RDA level of 0.4 ish grams per pound or 0.8 ish g/kg up until roughly double or even a little bit more of that (roughly 2 g/kg), he knows no evidence of harm in any group other than perhaps again, the very rarest folks
- And that rare case of harm would typically not be protein in general, it would be specific types
  - If you said to me phenylketonuria can’t have phenylalanine
  - Someone who’s got an allergy to whey protein can’t have whey protein, but that doesn’t mean protein in general

> “*I know of no evidence for harm even in people with chronic kidney disease or anything else.*”‒ David Allison

***There’s lots and lots of evidence for benefit in at least medium term observable phenomena like body weight, like appetite control, like bone strength, muscle and so on for people to be consuming more***

- It’s especially true in people who are recovering from injury, bodybuilding, looking for performance in athletics, looking for strength, who are older, who are growing, all of those things

**Peter thinks it’s easier to flip it and just identify all the people who don’t benefit from a higher amount of protein than the RDA**

- Peter worries that when we start to carve out a bunch of categories and say, if you’re in one of these categories, you should be consuming more ‒ you’re always going to kind of miss something or someone might not identify

*For example, most people would never identify themselves as a bodybuilder*

- Because when they think bodybuilder, they think of the caricature type bodybuilder we see on a magazine cover when you’re at the airport that doesn’t actually look anything like what you want to look like
- But the truth of the matter is, it’s hard for Peter to imagine, he doesn’t know that he can think of one of his patients

***Peter doesn’t know of one of his patients who doesn’t need to at a minimum work hard to maintain their muscle mass***

- And many of his patients are working hard to add muscle mass

*What differentiates them from a bodybuilder?*

- The difference is the bodybuilder has the benefit of using super physiologic doses of androgens and is basically training all day and doing nothing but optimizing around that

But the reality of it is we’re all sort of bodybuilders

- Everybody’s a bodybuilder if they’re really thinking about it in the lens of what are we on this earth for?
- We’re on this earth to create the most robust body we can have, and it doesn’t have to look like it’s bulging with muscles
- First of all, most of us couldn’t achieve that if we wanted to, notwithstanding the fact that most of us could never achieve it anyway

**Let’s think through who should be consuming the RDA**

- David would say with rare exceptions, “*The answer is, probably no one.*”

It goes back to goals

- You might find people (in fact not might) who say, “*I don’t care about any of those things you just mentioned. The only thing I care about is saving the planet, and my thing is I should eat as little as possible and as little protein as possible and as little animal product as possible for that.*”
- Somebody else could say, “*My goal is to be nearer to God and this gets me nearer to my God in my way*.”
- Someone else could say, “*My goal isn’t aesthetic. I want to look like a heroin addict in a doorway in Manhattan in 1970.*”
- But those people are rare

**It’s really important for people to understand that this argument around the RDA is adequate and that’s what you need to eat, and anybody who is suggesting you eat more than that is wrong**

Peter points out, “*We have to actually flip the question and say, okay, who is best served by eating at the RDA versus say, 2x the RDA?*”

- 2x the RDA is 1.6 g/kg, which for Peter would put him at 150-160 g of protein per day instead of 60
- David thinks here is where we get into that issue of recognizing the limits of our knowledge and then being able to wrangle with them rationally as opposed to irrationally
  - State the limits of our knowledge

David put up several [LinkedIn posts](https://www.linkedin.com/in/david-allison-2917963b/recent-activity/all/) about protein in the last 12 or more months

- [[PROTEIN: MIRACLE FOOD OR DANGEROUS FAD? DATA AND EVIDENCE SHOULD GUIDE OUR THINKING, ANTI-HYPE BACKLASH AND MORAL PANIC SHOULD NOT](https://www.linkedin.com/posts/david-allison-2917963b_protein-miracle-food-or-dangerous-fad-data-activity-7375623586637631488-XMj4?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]
- [[High Protein Diets: Benign or… Who Has the Burden of Proof?](https://www.linkedin.com/posts/david-allison-2917963b_determining-optimal-protein-intake-from-data-activity-7368299524093587456-7z97?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]
- [[Stuart Phillips aptly states “Science self-corrects—sometimes it just takes a decade (or more).”](https://www.linkedin.com/posts/david-allison-2917963b_protein-mortality-epidemiology-activity-7359779910032281600-aWWM?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]
- [[THE DANGER OF HIGH PROTEIN INTAKE IN NORMAL HUMANS? SHOW ME THE DATA](https://www.linkedin.com/posts/david-allison-2917963b_the-danger-of-high-protein-intake-in-normal-activity-7358769010160685056-mWak?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]
- [[“Red Meat for Food Fear and False Obesity Stories”](https://www.linkedin.com/posts/david-allison-2917963b_red-meat-for-food-fear-and-false-obesity-activity-7358377332379664385-SjtU?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]
- [[More sound science-based protein insights from Prof. Stuart Phillips.](https://www.linkedin.com/posts/david-allison-2917963b_is-there-a-minimum-yet-effective-protein-activity-7349602684770865153-pC1c?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]
- [[Gaining Muscle with Resistance Training (RT): Is Protein even a BIG Deal or Minor Player?](https://www.linkedin.com/posts/stuartmphillips_musclegain-resistancetraining-proteinintake-activity-7336532487973609473-o8Ce?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]
- [[THE HARMS OF HIGH PROTEIN INTAKE: CONJECTURED, POSTULATED, CLAIMED, AND PRESUMED, BUT SHOWN?](https://www.linkedin.com/posts/david-allison-2917963b_the-harms-of-high-protein-intake-conjectured-activity-7326466902657040384-EhyA?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]
- [[An excellent two days at the Human Dietary Protein Needs and Benefits workshop in Rosemont, IL.](https://www.linkedin.com/posts/activity-7300644494171856896-wsCY?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]

- In [one of them](https://www.linkedin.com/posts/david-allison-2917963b_the-danger-of-high-protein-intake-in-normal-activity-7358769010160685056-mWak?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg), David included a quotation from one of his old mentors in graduate school (Harold Yuker), who famously said, “*I’m a data nut.*”
  - Students gave him a t-shirt that said that, and he would say, “*Show me the data.*”
  - At that time, the [Jerry Maguire movie](https://en.wikipedia.org/wiki/Jerry_Maguire) was popular (“*Show me the money*”)
  - People kept raising these questions of harms, and David’s response is, “*Show me the data.*”
  - He was sincere, this was on open call for data
  - He set it to some of the top people in the world, including those who are a little bit hesitant on protein intake or denigrated
- David wanted anybody to send him one (or more) papers that are intervention studies (not observational ones) that are in humans, ideally randomized
  - He’ll take an intervention study even if it’s not randomized, but it’s got to be controlled (a controlled intervention study in humans): feeding different levels of protein in which the different levels of protein intake are separable from other effects that show deleterious effects on a clinically or intrinsically meaningful endpoint
- He doesn’t want to see that this molecule changed or this gut microbiota changed
  - What do I do with that? Why do I care that that gut microbiota changed?
  - Nobody cares about those things intrinsically, we care about them only insofar as if they give us heart attacks or strokes or earlier or later death or greater strength or make us better looking
  - We care about how long we live, how good we look, how we feel, our strength, what we can do
  - We don’t intrinsically care about whether this molecule in our body is higher than that molecule or this gut microbe

***Nobody sent him anything***

- Peter was on part of that thread and recalls a [paper](https://pubmed.ncbi.nlm.nih.gov/38943189/), a TPN trial ([total parenteral nutrition](https://en.wikipedia.org/wiki/Parenteral_nutrition)) in patients in the ICU
  - David thinks [Dudley Lamming](https://lamminglab.medicine.wisc.edu/dudley-lamming/) sent that and Dudley’s a great scientist and a good friend who studies protein mainly in mice and other things, but also a little bit in humans
  - He cited a couple of references, from [Luigi Fontana](https://www.sydney.edu.au/medicine-health/about/our-people/academic-staff/luigi-fontana.html) if David recalls correctly
  - And there was some short-term trials in patients with [cancer](https://pubmed.ncbi.nlm.nih.gov/28921841/)
  - He doesn’t remember all the details

**Peter is working his hardest to give this an honest look**

- He thinks what David did is the right thing to do
- We’re having religious debates on social media where people are using their Twitter platforms to lambast people they disagree with and call them names and do all this sort of nasty stuff

***Why don’t we just do this like grownups and show me the data?***

- Show me human clinical trial intervention studies that demonstrate the deleterious effects of “high protein”

**The only thing that Peter saw was studies with patients who were very, very sick in the ICU**

- So sick that they can’t consume [parenteral nutrition](https://en.wikipedia.org/wiki/Parenteral_nutrition#), which means they can’t eat because they’re probably ventilated and their guts aren’t even working, so you can’t actually put feeding tubes in them
- So, you use a central line, you put an intravenous catheter into one of the major central veins in their body, and you give them all of their nutrition through that conduit, which is called parenteral nutrition
- With total parenteral nutrition, you are chemically crafting the exact composition of what they consume, exactly how much glucose, exactly how much fat, what type of fat, how much protein, what type of protein, what micronutrients, etc.
- [recent [review](https://pubmed.ncbi.nlm.nih.gov/38184658/)]

***Peter doesn’t remember the exact study, but it showed that there was no benefit to a higher protein diet, and this was counterintuitive***

- He believes the study sought to ask the question: *Wouldn’t patients in the intensive care unit benefit from a higher protein diet because they’re very catabolic?*
- The body is incredibly catabolic in that setting, and the surprising outcome of that study was that the patients on the higher dose of protein did no better
  - They didn’t do worse

*Am I remembering that correctly?*

- If memory serves David correctly, there was ***no statistically significant effect*** on what he would call an intrinsically clinically important outcome
- There wasn’t a statistically significant effect on lifespan (and in that patient population, death/mortality is the most important outcome)
- There are other outcomes (days in the ICU days on the ventilator), and those things all matter tremendously

**⇒** You’re looking at such a sick population that’s on the precipice of death that when you look at ACM or all-cause mortality, you’re going to get some interesting and valuable insights

**David makes the point, “*****We’re also going to have to really dig into this idea of when we’ve got different sources of data and none of which are the data we really want*****.”**

- What we really want is the randomized controlled trial in tens of thousands of people so we can look at subgroups and we’d have a lot of power
  - We want perfect adherence
  - We want it free living
  - We want it in people eating foods under the circumstances about which we’re going to make claims
- Most of us are *not* asking: If I am on [TPN](https://en.wikipedia.org/wiki/Parenteral_nutrition) and unconscious and being tube-fed by a surgeon, then what?
- Most of us are saying: *When I go to the grocery store and decide what I want to bring home for dinner tonight, then what?*
- And those are not the same thing

***We won’t have that. We’ll have lousy epidemiologic studies with lousy self-reported data, followed people, large groups for long periods of time, and causal inference will be fraught.***

- We’ll have mouse studies in which we’re not sure we can generalize from the mouse to the human
- We’ll have short-term studies of people being tube-fed when we want to talk about long-term studies of people eating quote-unquote ordinary foods in ordinary ways
- And we’re going to have to sort of think about if they all line up perfectly

**Smoking is an example of that where almost everything lines up**

- You may not have the perfect study you want, but the cell stuff, the mouse stuff, the animal stuff, the epidemiology, the clinical trials
- They all line up to say, smoking’s really bad, don’t smoke
- If all the studies line up, great, then it’s easy
- If they don’t all line up, then we have to talk about how strong the evidence is

> “*We also have to start to talk about how strong is each piece of evidence, both in terms of its generalizability to what we want as well as in and of itself is it strong?*”‒ David Allison

***David thinks those studies that they just described are not especially dispositive***

## Understanding the dose-response curve for muscle protein synthesis as protein intake increases [A: 45:15, V: 48:17]

- There was a study that was referenced that looked at as you went from 0.8 to 1.0 to 1.0 to 1.2 to 1.4 to 1.6 g of protein per kg of body weight, and what did the rate of muscle protein synthesis do?
- In other words, where did you start to achieve the plateau and beyond which you were not going to get more?
  - [the first figure below is from a [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/28698222/) by Stuart Phillips and shows a dose-response for protein intake and change in fat-free mass (as a way to assess increased muscle mass)]
  - [The second figure is from a different [study](https://pubmed.ncbi.nlm.nih.gov/31618421/) that evaluates the dose-response for protein intake in resistance-trained individuals and found that trained individuals require more protein to achieve a maximal anabolic response]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f2-davidallison3.png)

**Figure 2. Linear regression between protein intake and change in fat-free mass**. Image credit: [*British Journal of Sports Medicine* 2018](https://pubmed.ncbi.nlm.nih.gov/28698222/)

![](https://peterattiamd.com/wp-content/uploads/2025/10/f3-davidallison3.png)

**Figure 3. Relation between protein intake and phenylalanine net balance (an approximation for protein synthesis) in resistance-trained men**. Image credit: [*The Journal of Nutrition* 2020](https://pubmed.ncbi.nlm.nih.gov/31618421/)

***What Peter thinks this study demonstrated was that in less trained individuals, you will achieve higher levels of MPS for lower amounts of amino acids***

2 things stand out to Peter

***1 – Be careful what patient population you’re looking at in the study and make sure it applies to you***

- So, in an individual who’s training an hour a day, Peter doesn’t think they can compare themselves to someone who went from sitting on a couch to training 90 minutes a week (that’s very different)
- If you take an untrained individual (a person who is 100% sedentary, which sadly is the majority of people in the United States) and you put them on a fitness regimen of 3, 30 minute whole body workouts a week
  - Take that sedentary person into a gym and get them to push around weights 30 minutes 3x a week (not to failure, not to profound exhaustion).
  - There is no desire to maim them or make it such that they can’t get out of bed the next day
- Will they achieve a training benefit? Will they achieve some benefit?

***2 – The untrained individual, when put on this fitness regimen will achieve unbelievable benefit; yet if you put Peter into their workouts, would he achieve any benefit?***

- Virtually none
- Why the difference?

David argues, “*Because you’re already sort of on the asymptote, right?*”

- It’s like anything else; take someone who’s never had any value of it and you get a big benefit

Other examples

- Give a mouse that has no [leptin](https://en.wikipedia.org/wiki/Leptin), just a tiny little bit of leptin, and it immediately starts to slim down quite a lot
  - Give a mouse that has a normal amount of leptin, a little bit more, and you’re going to observe almost nothing
- Give a kid who’s been **studying algebra** for an hour a day vigorously and diligently an extra 10 minutes of studying algebra, you’re probably not going to get that much benefit
  - Give a kid who’s never been exposed to algebra at all 10 minutes a day of tutoring algebra, and they’re probably start to get some real benefits soon
- Peter thinks that’s a beautiful example
  - When he hears people say you need much more protein that 0.8 because of that study it makes him think that’s like telling a kid they only need to study algebra 10 minutes a day if they want to master it

## Why nutrition trials are chronically underpowered due to weak economic incentives, and how this skews evidence quality and perceptions of conflict [A: 48:15, V: 51:27]

**One of the things that irks David about the field of nutrition is the lack of funding**

- He doesn’t know what the solution is
- This goes back to the challenges we have [in nutritional science]

***This is really an economic challenge, not an intrinsic challenge***

- Look at the sample sizes of studies in nutrition in general, randomized controlled trials of nutrition in general of things like protein intake, and then look at the sample sizes of randomized controlled statins, GLP-1 agonists, vaccines, etc.
  - They’re different by multiple orders of magnitude

**Full disclosure**: by email, Dr. Allison disclosed that he has received funding and payments from [Roman Health](https://en.wikipedia.org/wiki/Ro_(company)) and from multiple pharmaceutical companies which have interests in GLP-1 agonists

- It’s not uncommon to read these studies saying, “*Well, we’re interested in the effects of protein consumption on African-American women over age 50 with diabetes and without, so it’s 6 in each group.*”
- You had 60,000 over there in that pharma study
  - Compared to 6 in each group

***We have really weak data on this, and so it’s not surprising that often we don’t show these big effects***

**Peter wants to tie this back to the discussion they had earlier around disclosures**

- There’s a reason that virtually everybody in nutrition science is taking some money from the food industry
- Now someone who works at the NIH who is funded entirely at the NIH doesn’t need to

Peter asks, “*Is* [*Kevin*](https://www.kevinhallphd.com/) *back at the NIH by the way?*”

- Not to David’s knowledge
- Peter explains that most everybody who’s at a university is cobbling together money from both the government and industry
  - That’s demonstrated by the belt and suspenders bootstrapping approach that comes into nutrition science studies, which are not well-funded

*Explain why it is easy to fund a pharma study with 60,000 people in it, and it’s hard to get the funding to study 600 people in a nutrition study?*

***The first question is very simple: it’s the economic model of it***

- Pharmaceuticals are patentable, and the way our country works is in general, you cannot market a pharmaceutical without the FDA’s approval
- And the FDA will generally not give approval unless you’ve met their bar for having demonstrated a reasonable basis for concluding that the benefits outweigh the harms under proposed conditions of use (as the act of Congress for the FDA’s structure mandates)
  - And so the FDA says, this is what it’s going to take to convince us, and it’s going to be these big randomized controlled trials as well as a few other things
  - So the companies say, we’ve got to do it
- In most cases, sometimes the reason we don’t have certain drugs is not because they can’t be made, it’s because the pharma companies say it’s not worth it for us because we won’t make enough money to offset the development platform
  - That’s a problem there
- But in any case, in other situations like a GLP-1 agonist, it does
  - So, they develop them
- They spend hundreds of millions of dollars, they do them to the utmost rigor
- They’re probably the most rigorous human health studies done on the planet these days

***If you’re willing to spend 10 years and a $2-3 billion dollars to bring a drug to market ‒ that’s an enormous investment (but if you can recoup it, it’s worth it)***

**How do you recoup that in nutrition science?**

- You don’t
- Their margins in the food industry are much lower
- They often can’t patent stuff quite so easily
  - It’s hard to patent the grapefruit, right?
- So, if you’re the grapefruit sellers and you want to do some study, you’re not going to patent grapefruit even though you may have some benefit from it
- That creates a problem
  - Which sometimes leads to why people want supplements and things, so maybe they can get some patent protection, but even that can be limited at times

***You don’t have the economic model for it***

- David doesn’t have the numbers at his fingertips (he doesn’t know if anybody does), but if you said to me, we’re going to take all the money spent on research looking at the effects of food
  - Not how do you make food
  - Not how do you make a better chocolate bar or a better macaroni and cheese or something
  - But what are the effects of eating that chocolate bar or a macaroni and cheese?
- And if you added it up across every single commodity group, the dairy council, the egg board, every single food company, every dietary supplement company, and you added all of what they spend on research, David would be very surprised if it exceeds $1 billion dollars across the entire country

***There’s very little money relatively speaking there***

- They don’t have the economic wherewithal to do it

***They also don’t have the mandate to do it***

**David’s group, 20+years ago, did the first** [**randomized controlled trial**](https://pubmed.ncbi.nlm.nih.gov/17556685/) **ever commissioned of their products by the Frito-Lay company**

- And my gosh, were they scared about this (they didn’t know what they were getting into)
- It turned out we compared chips fried in corn oil to low fat chips and cookies and crackers and things to traditional chips and cookies and crackers that had more saturated fat, trans fat
- The idea was, is low fat better than corn oil?
  - And the answer was, no
  - Assuming you can control your calories, you’re better off eating the full fat corn oil chips

Peter asks, “*What about the saturated, the high saturated fat and the trans fat?*”

- Probably the worst
- The outcomes were CVD-type [serum lipid concentrations: cholesterol and triglycerides]
- David’s recollection is the traditional trans fat, sat were worse
  - The low fat, high carb was worse for triglycerides
  - And the high fat corn oil stuff was better for everything
  - [from the introduction of this [paper](https://www.sciencedirect.com/science/article/pii/S0002916523281046), “*Frying foods in vegetable oils such as corn, canola, or sunflower oil, all of which are rich in polyunsaturated and monounsaturated fat, low in saturated fat, and free of transfatty acids, can produce healthier high-fat snacks.*”]
- [Marie Pierre St Onge](https://mr.research.columbia.edu/content/marie-pierre-st-onge) was the first author on that study
- [Marion Nestle](https://steinhardt.nyu.edu/people/marion-nestle) was one of the few critics of this study, and it was typical, it never touched the science
  - They never said the design was wrong or the measurements were wrong
  - The criticism was: they were funded by industry,
  - This was her words, “*I call this a calorie distractor*.”
- David’s point of view: if you have something to say about the science, why don’t you stick to the science and do that instead of quips and ad hominem attacks

***The food industry traditionally has not funded a lot of this; these studies are expensive***

- This study David did cost in the neighborhood of close to $1 million dollars
  - Especially if we inflated it to today’s costs
  - He doesn’t remember the exact cost
- But that’s nothing compared to what we talked about with pharma

**The other issue is, the other big funder is NIH**

- 1 – Often NIH sees these things as something the industry should fund
  - If it’s there selling it, let them fund it
  - That’s one problem
- 2 – Sometimes it’s not seen as really deep, big science
  - Yes, it’s practically interesting, Dr. Allison, but where’s the big deep scientific hypothesis?
- 3 – The last thing is, in David’s opinion (clearly an opinion): the misprioritization of funding, and this is something that now we see the NIH addressing very vigorously
  - David agrees with some of what they’re doing, and he disagree with some of what they’re doing
  - But [Jay Bhattacharya](https://en.wikipedia.org/wiki/Jay_Bhattacharya), he’s a real smart guy and he with others are trying to say, “*Let’s repurpose some of the funding less here, more here.*”
- David looks at the observational epidemiology (which can be very expensive in nutrition) and thinks the new information yield (with emphasis on new information) is often very low
  - If somebody else comes out with a new study tomorrow that measures the food intake as carefully as possible with self-report in this population
  - If it were a million subjects
  - If they had a couple of biomarkers, and they showed with protein intake and longevity

***The studies being published about nutrition and longevity might give a little thing to scratch your head about, but it didn’t really move the needle in terms of answering the question***

## The limitations and biases of nutrition epidemiology, and the potential role of AI-assisted review to improve it [A: 56:15, V: 1:00:40]

- Let’s talk a bit about the epidemiology in this space
- Everybody listening knows what [epidemiology](https://en.wikipedia.org/wiki/Epidemiology) is, and we’ve talked a lot about the limitations of it and what a healthy user bias is [discussed in [this newsletter](https://peterattiamd.com/ns003/#:~:text=from%20the%20truth.%E2%80%9D-,Healthy%2Duser%20bias,-People%20who%20are)]

**Give us the landscape of how epidemiology has looked specifically at this question of the relationship between protein intake and outcomes of health**

*What are some of the near unique or particular circumstances of epidemiology that lend itself to confusion here?*

- The greatest limit or problem with the nutrition epidemiology in this exact context of protein consumption and things like longevity and long-term major health is the **opportunity cost**
- It’s that we’re spending the money and often a non-trivial amount of money
- These big epidemiology studies can be very expensive and we’re not spending it in the big randomized, well-done, controlled clinical trials.
- If you said to me, well, we did some epidemiology, it’s something we can glean and it’s interesting and fun and there was no cost. Okay.

***But if you say we could have done 1 really good or maybe 10 medium-sized randomized controlled trials for that [cost], that was a big loss***

David adds, “*If we just stick to the epidemiology, you and many others frequently and correctly point out the issue of confounding, we all say correlation is not necessarily causation*.”

The example of ice cream consumption and murder rates is trotted out

- We say more ice cream consumption is associated with more murder rates
- Guess what? It’s the heat
- People eat more ice cream when it’s hot, and they murder more when it’s hot

***All true, all fine; but that’s actually just a tiny piece of it (there’s so much more)***

There’s the **measurement problem**

- And that measurement is not random
- Even if it was random, it’s usually not taken into account
- If it was random and we knew it was random and we took it into account statistically we could make the problem kind of go away
- But it’s often not random; it may be correlated
  - People who eat more of this may systematically bias their reporting down than people who eat less of that
- There’s **selection bias**: people may choose to be in the study or not choose to be in the study, and that may affect things
- There’s what’s called **collider bias**: I control for something, and I think I’m doing a good thing by that, but in fact, I’ve created an inadvertent association
- David could go on and on with statistical obscura

**What do you think are the 3 most important biases that impact this particular question when asked through an epidemiologic lens?**

1 – Confounding

- Not only by culture and socioeconomic status and social class education

2 – Measurement error

- The non-system, the non-random measurement error

3 – Some selection biases that are a little hard to specify

- [Miguel Hernan](https://hsph.harvard.edu/profile/miguel-hernan/) at Harvard is perhaps one of the most thoughtful people on talking about the other ways these biases can creep in terms of when people start the study
  - *Who* gets in the study, and *when* we consider their exposure as occurring
- He does some ways to try to correct that
- He thinks that’s more important than confounding

The other one, which is very big but not intrinsic is **the honesty or sincerity of reporting** by the investigators

- David doesn’t think many investigators are lying in an explicit sense, but he does think there are both intentional and unintentional efforts at distorting [the story]
  - When people tell a story, they emphasize some things and de-emphasize others
  - They hide some things and don’t hide others
- So, it’s not an explicit lie, but there’s a manipulation of the information

**Why do you think the editors at journals are unable to address that in the review process?**

- For the majority of editors, its lack of ability, lack of resources, and lack of courage
- For a minority of editors, it’s limitations on the ability to really go in and suss it all out
- The New England Journals of the world, the Sciences of the world, the JAMAs of the World, they have the resources within reason and the sophistication and to sort of go after this, but they can’t get everything

Peer review is analogous to restaurant reviews

- Often when David thinks about the idea of peer reviewing (but also to some extent the editorial review, which has a little more teeth than the peer reviewers themselves) he looks at it like restaurant reviews
- If Zagat or whoever goes in to review a restaurant or somebody given Michelin stars, they can tell you:
  - Did they like the offerings on the menu?
  - Was the food tasty?
  - Did it look good?
  - Was the service good?
- What they’re not doing:
  - They’re not going back and doing a microbial count in the kitchen
  - They’re not checking how often the chef washed his or her hands
- Those are things you need a health inspector who’s got some authority, who can do spot checking, surprise visits, who’s got equipment and so on
- That’s what you need there
- David thinks peer reviewers are like restaurant critics now
  - Does it look good?
  - Is it interesting?
- As a peer reviewer, he can’t go back and look at everybody’s raw data
- In some cases we’ll see something that looks funny
  - And then through the journal, we will get the raw data from people, and then we often see things that are quite funny
  - And we often get a lot of fights with review authors who don’t want to let us look at their raw data and kind of tells you something

**Where is AI in this process? Why are we not or are we using LLMs to serve as peer editors?**

- The short answer is, we are
- The long answer is, we’re at the stage of infancy and amateurishness with it
- So it’s coming
- It’ll get better and better, but we can do some very simple things now
- People look for these so-called “tortured phrases”
  - When you find these phrases that kind of look like a word salad, that’s sort of a hint often that you’ve got something plagiarized or just fabricated
  - We can look in some circumstances for things that literally don’t add up
- Some people made something called the [GRIM test](https://en.wikipedia.org/wiki/GRIM_test)
  - Let’s say you have a [Likert scale](https://en.wikipedia.org/wiki/Likert_scale) and you know have a certain number of subjects, then the mean of that scale can only have certain values
  - And if you say, “*Hey, it doesn’t have one of those values,*” something must be wrong, those are examples.

Peter asks, “*Do we know if these AI agents (these peer review agents, I’ll call them) are being trained on known fraudulent manuscripts?*”

- Peter is concerned about publications that were determined to be frauds
- It would seem reasonable to start training these AI agents to identify patterns of fraud

***Yes, but it’s very much in its infancy***

*Who is leading the charge on this?*

- David doesn’t know if there’s one person who is leading it
- [James Heathers](https://www.linkedin.com/in/james-heathers-phd-63a70240/), who’s now got a position [as director of the [Medical Evidence Project](http://medicalevidenceproject.org)]
- Part of the challenge with a lot of these so-called data sleuths is it’s hard to get paid to do that
- David was a paid dean and now he’s a paid [center director](https://www.bcm.edu/people-search/david-allison-181551), and in his spare time he does a little sleuthing
- People like James Heathers where it’s more his full-time gig, it’s hard to get paid, but [Retraction Watch](https://retractionwatch.com/) set something up for him
- Tracy Weisberger over in Europe is another [she’s an [EXCELScIOR ERA Chair Team Leader](https://excelscior.uc.pt/) at the University of Coimbra in Portugal]
- [Michèle Nuijten](https://www.linkedin.com/in/michelenuijten/?originalSubdomain=nl) is a Dutch scientist who came up with something called [statcheck](http://statcheck.io/)
  - If the statistics are reported in the format of the American Psychological Association (which is a very clear format), they have software that will specifically go and make sure those all check
- Those are some examples, but there are many others that people are working on

## The lack of compelling evidence of harm with higher protein intake, and why we should shift away from assuming danger [A: 1:04:15, V: 1:09:41]

**What do you think is the most compelling piece of epidemiologic data against the idea of exceeding the RDA?**

- David doesn’t think there are any compelling observational epidemiologic data
- When he thinks of the things where you’ve got relatively hard endpoints, relatively large sample sizes
  - Usually they’ve not looked at hard, big thresholds
  - And even if they have, they’ve looked more continuously at protein intake

David adds, “*I can show you studies in either direction, studies that make it look like more protein is beneficial and studies that look the other way. And I don’t think any of them are dispositive.*”

***David’s takeaway: protein intake is highly confounded with social class as well as type of protein intake***

**Let’s flip the question now, I’m going to argue that lower protein is better**

- You’re not going to starve to death at 1 g of protein per kg of bodyweight (let’s just round up 0.8 g to 1 g)
- Let’s say Peter should be eating 85 g of protein because we know that is safe
- But we don’t know that if you double that, that you’re not going to get cancer

**What can we say about protein diets and cancer or heart disease?**

- What David thinks we can say is absolute knowledge is beyond us in this context
- But we can have reasonable degrees of certainty for practical purposes as long as we need to be open with them
- One of the things that David often gets frustrated with the nutrition science (and some other elements of scientific community) is, we say, “*Science is always evolving and the public needs to understand that it’s not something wrong when we in their view flip-flop and we change our mind, we change our mind when new data become available.*”
  - That’s true
  - But then the implication is that we were honest with the public all along in saying, “*This is what we think today. It’s not absolutely certain*.”

One example that stands out in David’s mind

- In the early 1990s, [Dr. Michael Jacobson](https://www.nationalfoodmuseum.org/board-of-director/), PhD, nutrition scientist, director of something called the [Center for Science in the Public Interest](https://www.cspi.org/about) (the word science in it)
- He came out on national TV, on camera, holding a plate of fettuccine Alfredo outside an Italian restaurant after a new report had come out on the composition of what people ate in Italian restaurants
- And as he holds it out to the camera, he says, “*This is a heart attack on a plate*.” (it got huge press)
- This was not a tempered statement that says, “*This is what I think we know today, but it could change later.*”

***David thinks we need to be more honest about that***

Peter asks, “*What was he referring to that was causing the heart attack in that?*”

- The implication was maybe the saturated fat and sodium

> “*I know of no compelling evidence for harm (that doesn’t mean there couldn’t be any)… I know of no studies showing that humans get more cancer with this [high protein diet].*”‒ David Allison

- David thinks we need to be skeptical of the mouse studies, the epidemiologic studies (for reasons he’s indicated)

- At some point we need to recognize, as people did when David put up that [LinkedIn post](https://www.linkedin.com/posts/david-allison-2917963b_the-danger-of-high-protein-intake-in-normal-activity-7358769010160685056-mWak?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg) and said, “*Show me the data. Can anybody send me one?*”
- Many people responded with something akin to, “*I can’t show you that study, David, but can you show me the complement or the opposite study that meets all your criteria and shows there isn’t harm?*”
- And the answer may be no, I’m not sure

***But at some point when you’ve looked enough and you’ve failed to see harm, where’s the burden of proof?***

- So if you don’t have a really strong *a priori* rationale
  - Now we can argue by that ‒ there probably is legitimate debate
- You might legitimately say, “*I have a strong a priori rationale there isn’t harm*.” And [Dudley Lamming](https://lamminglab.medicine.wisc.edu/dudley-lamming/) might say, “*I have a strong a priori rationale there is harm*,” and you’re entitled to your opinion
  - ***Those are opinions***
- And then we can both look and say, “*Well, neither one of you has the absolute definitive data.*”
- At what point, where’s the burden of proof?

David shares, “*I think right now the notion is the burden of proof is on those who want to argue for higher protein intake. Well, the evidence isn’t clear enough to show that the RDA is too low, to which I would reply, ‘Well, the evidence isn’t clear that it isn’t.’*”

- Now where does the needle point? Where does prudence point?
- David doesn’t think the status quo is necessarily what’s always prudent, saying, “*Leave everything the way it is*,” is always the best way
  - Sometimes it is
  - But in this case, he thinks we’ve left it alone long enough

David’s analogy: “*I think it’s time to say we’ve looked and looked and looked, if I look at a thousand swans and I cannot find a black swan, does that mean that no black swans exist? Of course not*.”

- But if I looked at 10,000 black swans, if I sent a helicopter in the air and we scoured and we looked with binoculars, if I sent teams of undergraduate students to walk around ponds and measure, look for every black swan
- If I put drones with cameras out and I have failed time after time after time to find a black swan

***At one point say, maybe for practical purposes I can say a black swan is probably not something we need to worry about***

## Pragmatic targets for protein intake [A: 1:09:30, V: 1:15:37]

- Peter agrees that is the most logical way to frame this
- He doesn’t believe we’re ever going to get a dose toxicity study for protein the way we do for figuring out what the [LD50](https://en.wikipedia.org/wiki/Median_lethal_dose) of a drug is
  - Where you push the toxicity and you figure out, okay, at this dose we will kill 50% of people

**So the real question becomes**: What would be the bracket you would put around for 90% of the population to exist within this range, as an appropriate way to interact at the grocery store?

- What’s the problem we’re trying to solve here
- Peter acknowledges, “*The people listening to us don’t care about most of what we’ve said today.*”
- They are confused because they’re reading people who have a lot of piss and vinegar in what they’re saying on this topic:
  - How much protein should I be eating?
  - What should my family be eating?
  - Should I be avoiding protein in my kids?
  - Should they not be eating snacks with… Whatever the argument is?

**Peter’s guidance to patients is pretty straightforward and it varies based on their preference**

- We have some patients who are vegetarians, who have been lifelong vegetarians who can’t stand the feel of meat
  - This is not like a belief that they have that meat is bad for them
  - They genuinely don’t like meat
- We have other patients who won’t eat any animal products, so they’re going to have a harder time reaching the upper limits of protein consumption
  - And so with those people, we’re just trying to nudge them as high as we can get them, and that’s probably not going to get much higher than about 1.2 g/kg of body weight

**⇒** The guidance we’re giving people is we really like to see you at about 1.6 to 2b [g/kg]; it’s an easy heuristic to remember because you’re basically consuming almost 1 g/lb of body weight

**How would you advise people? (you don’t need to worry about black swans argument)**

- David suggests we first separate what people ought to do depending on their goal
  - A goal most of us have is to live longer, be stronger, be healthier, etc.
  - Versus a goal of just wanting to survive

> “*If you just want to survive, the RDA is probably okay for most people.*”‒ David Allison

**⇒** But if you want to thrive in these goals that most of us share, then David would aim for in the neighborhood of 2 g/kg per day, per person, spaced out throughout the day

Peter’s analogy

- If you want to pass, you should study this many hours per day and you will get a C
- But if you want to have the best shot at getting into the best college you could get into because you want to study engineering, you should probably study this much
  - And you’re probably going to need to try to get As
- David likes this analogy
- His great uncle who was a professor from the old country and the old school and a philosophy professor, when his kids would come home in America from school, he would say, “*Good. Now playtime’s over. Now you sit down and we study Latin and math and logic, and you do the real work*.”

Another example

- You may know that in South Korea they actually chose to pass some laws recently (David forgets the details of them) that students could only study so much because they’re really starting to get worried of students just going too far
- Those are good examples

***To David, the RDA for protein intake is like what my uncle saw the American schools as: yes, it’s just enough to pass high school and do something***

- The next level up is what my uncle did, which was we’re going to really do some work and get you closer to an optimal level
- Maybe what some students do is maybe go too far

But it’s also interesting to see, in what way were they going too far?

- Did anybody ever say or show that if you study algebra or anything else 12 hours a day instead of 2 hours a day, it directly causes harm
  - David doesn’t know of anything like that
- Now, if you said that you study algebra or whatever for 12 hours a day, ipso facto, you are not exercising, you are not socializing, you may be not sleeping enough, etc., then you have a problem

***The problem is not the direct effect of the studying, it’s the substitution effect***

- David handed Peter a [drink](https://www.spylt.com/) when he came in [shown in the figure below]
- One of his favorite things is to play with these different protein products and have fun with them
- This is a drink that has 20 grams of protein and 90 calories, almost pure protein

![](https://peterattiamd.com/wp-content/uploads/2025/10/f4-davidallison3.png)

**Figure 4. SpyIt protein drink**. Image credit: [SpyIt](https://www.spylt.com/product/vanilla-milkshake)

- There are other products like this, and if you or I were to say, “*I just want as much protein as I can, so I’m just going to live on that stuff,*” there would be **no direct harm** (to David’s knowledge)
  - He’s not worried about his kidneys shutting down or something
- But he would say, “*Well, wait a minute, did you have:*”
  - Any vitamins and minerals?
  - Did you have any pleasure from eating other foods?
  - Did you have enough energy to work out hard by not having any carbohydrate? (maybe a little carbohydrate would make you able to work a little harder)

***The substitution effect may come into play when eating more protein and there are other losses, but beyond that, David doesn’t know of any risks***

- Losses like if you get a fatty acid deficiency because you don’t consume enough [α-linoleic acid](https://en.wikipedia.org/wiki/%CE%91-Linolenic_acid#Health)

**David’s takeaway on dietary protein targets**

- The RDA is for life support, basic maintenance
- Strong evidence for thriving is around two-ish (2 g/kg)
- Above 2 g/kg, you probably get more benefit but you’re starting to hit the asymptote
  - He doesn’t know if the benefit is going to come down (he doesn’t know of anything that’s not going to be monotonic, that’s going to turn around)
  - But you start to see diminishing benefit and you start getting into more economic costs of buying fancy products, the costs of devoting your time and attention to it, the cost of not eating something else you might like

Both David and Peter have wrangled with fruit

- They both like fruit and they’ve both played with diets at times where they’ve minimized the consumption of fruit for other goals
- And yet, they’ve both come back to it and said, “*I don’t want to give up fruit.*”

***Those are some examples where David thinks there’s some optimization, but he sees no harm***

- He thinks the more refined your goals are, then the more it’s reasonable to push it a little bit
- If he wanted to win the Olympics, he’s more motivated to push it
- For David, if he can lift one more pound of weight on the bench press, who cares?
  - But if he’s trying to win the Olympics, then it matters

## Defining processed and ultra-processed foods and whether they are inherently harmful [A: 1:16:15, V: 1:23:44]

- Processed foods is a very hot topic today and a lot of processed foods are optimized around protein (not just pleasure)
- Peter has read quite a bit on this topic, and he’s read some pretty compelling arguments on all sides
- 1 – If you just took processed and ultra-processed foods off the market, people would be better
  - You would force a change in the system that would lead to healthier outcomes
- 2 – The other very compelling argument is that if you correct for caloric intake, there is nothing per se that is wrong with processed foods
  - At least to the first order, second order potentially

**Let’s start with some definitions. What separates a processed food from an ultra-processed food?**

- There’s not a single accepted definition
- The most commonly used classification system is called [Nova](https://en.wikipedia.org/wiki/Nova_classification)
  - It’s very controversial for many reasons
  - Some social, some scientific, some linguistic or definitional
  - It has to do with degrees of steps and the types of steps involved and so on

***These are very popular topics because they give us a new demon***

- We talked earlier about the importance of demons
- [Kelly Brownell](https://globalhealth.duke.edu/people/brownell-kelly), who as much as anybody, has been one of the leading thinkers in the field of obesity research in the last half of the 20th century
  - He moved from Yale to Duke years ago and may be semi-retired now
  - A really good thinker
- David can remember being in a meeting with Kelly where they were both speakers
  - The meeting was convened by leaders in the food industry.
  - He was ramping up the rhetoric of a “toxic food environment,” the epidemiologic environment, the public health environment argument
- This was when data had just begun emerging: the [NHANES-III](https://wwwn.cdc.gov/nchs/nhanes/nhanes3/default.aspx) [[publication](https://pubmed.ncbi.nlm.nih.gov/30789115/)] and then the [later NHANES data](https://www.cdc.gov/nchs/products/databriefs/db536.htm) was suddenly this wake-up call for the country

David explains, “*We knew there was obesity and we knew it was getting worse. We didn’t realize how rapidly it had started to get worse in the last couple of decades*.”

- And now there was this hype, this panic, and Kelly spoke and he said, “*We need social movement here. We can’t do it on our own.*”
- He himself struggles with obesity
  - It’s not education
  - The guy’s brilliant; he’s enormously educated, but he still struggles, as did many other people of a similar degree of education and expertise
- He said, “*We’re treating this too much as an individual problem*.”
- He said, “*You’ve got companies like McDonald’s who have a goal of nobody should ever be more than X minutes away from McDonald’s if they’re driving in the United States.*”
- He explained that it’s a problem when I’m driving down the street and I’m being assaulted by all the signage and so on
  - We need to change this
  - We need a social movement
- Now he’s looking at all these executives from the food industry and he says, “*History shows us over and over that social change happens when there’s a villain. We need a villain*.”
  - And he says, “*Guess who it is? You.*”

***So that was the start of this villainization***

- This was in the mid-90’s
- Michael Mudd who was at Kraft at the time convened that meeting

***And now ultra-processed is just a great way to demonize stuff ‒ it’s just another demon***

- We’re off of soybean oil (maybe), off phytoestrogens
- We dealt with fat for a while
- We dealt with sugar for a while
- Those are still floating around

**Let’s give folks a couple of examples of processed versus ultra-processed**

- Dried fruit is processed
- Virtually everything we eat is processed

*How do you then cross the chasm to ultra-processed?*

- Even if you say there’s a single definition like [Nova](https://en.wikipedia.org/wiki/Nova_classification), David can’t recite for you the exact criteria
  - But it’s the number of steps
  - It’s the degrees of steps, it’s the types of steps
  - It’s the number of ingredients
- Most things that come in a package now are viewed as ultra-processed
- Even fruit that is cut up is processed
- Wine is processed, cheese is processed, milk is homogenized (hopefully it’s pasteurized), almost everything we eat is processed

David adds, “*And for that matter, I don’t want to eat a lot of certain unprocessed foods, there’s lots of evidence that unprocessed dairy products cause a lot of harm. So processing is good*.”

**Let’s talk about the state of the evidence**

- Peter’s view on this is a lot more nuanced than the one he’s about to lay out, but the one he’s about to tell makes sense and he gets it

*We didn’t evolve eating ultra-processed foods, let alone processed foods*

How ultra-processed foods are different

- Ultra-processed foods are engineered to be highly palatable
- And part of that engineering process also makes them calorie dense because part of making things hyper palatable is putting in a lot of sugar and a lot of fat
- It’s not that the food companies who make these things are trying to make us fat
- They’re not trying to hurt us
  - Marlboro’s not trying to hurt you with cigarettes, they just want you to smoke them forever
  - It’s an unfortunate consequence of the product
- They really want to create something that tastes remarkable that you just want to keep buying over and over again

***The problem with ultra-processed foods is you’re going to end up eating more of it in terms of calories because of the very nature of the product they’re trying to sell you***

- We can’t have these foods around because we can’t eat them in moderation
  - We’re going to overeat them
  - This is one thing we can agree on

**⇒** Over-consumption of calories always leads to bad things, relative to what your needs are

- That number [of calories] is variable by individual, but for any given individual, eating more than they require leads to physiologic harm

*By that logic, why don’t we just get rid of ultra-processed foods?*

**One thread David wants to touch on quickly: the idea that fewer calories are better**

- To a point, it’s true

***This is very dependent on ambient temperature***

- The studies of caloric restriction in general and protein restriction in particular show benefits are much more present at 22 degrees Celsius
- Which for a mouse is a thermoregulatory challenge as opposed to thermo-neutral conditions (roughly 27-30 degrees C)
- We don’t live our own lives in the chronic cold, so we’ll leave that out there and say it depends on the conditions

**There’s several threads David can pick up here, and one has to do with the idea of categories: all categories are social constructs**

- We often hear that said about things like race and it’s true
  - Race is a social construct
  - So is furniture, so is vaccines, so is medicine, etc.
- What you choose to use as a category and how you choose to define membership in that category is a judgment call, and it’s not intrinsically written in stone what that should be

***Categories are useful or not useful for your purposes. It’s the same thing as ultra-processed. There’s not a correct definition of ultra-processed.***

- That’s the first thing to point out
- You can define it any way you want: the words mean what we say they mean
- Once you’ve defined it clearly, then we can say what’s its value?
  - How can we use it?
  - What’s its utility?
- Secondly, as with any category, if it permits a lot of variabilityin that category (which ultra-process certainly does)

***It starts to get a little silly to talk about ultra-processed foods because of the great degree of variability in that overall category***

- A meal replacement shake is in the same category as a Big Gulp from 7-Eleven
- A chocolate bar is in the same category as a [TPN nutrition](https://en.wikipedia.org/wiki/Parenteral_nutrition)
- These are all arguably ultra-processed and very different things

## The search for a guiding principle of what’s healthy to eat: simple heuristics vs. judging foods by their molecular composition [A: 1:25:00, V: 1:34:16]

**What are we trying to do with the label of ultra-processed?**

- This is probably intellectually most important
- If you say, “*David, what I am looking for is* [*heuristic*](https://en.wikipedia.org/wiki/Heuristic)*.*”
- This loops back to the distinction between *how much* protein do I think somebody ought to eat for a certain goal, versus *how* would I tell them to eat it or *what* would I tell them about? (those are two different things)
- If you said, “*David, I just want something I can tell people so that when I tell them this, it has a beneficial effect.*”

***Does telling them not to eat ultra-processed foods or to eat as few of them as possible, defining ultra-processed in this way, help? And the answer is: it might help a lot.***

- It might vary depending on how you set it
- We need more studies
- David’s guess is: it won’t last long
  - You could tell them not to drink sugar-sweetened beverages
  - You could tell them not to eat fettuccine Alfredo because it’s a heart attack on a plate
  - ***All these things have a small effect for a while and usually not so much for the long term, but might help***
  - We need to study that

That says nothing, however, about the effects of the food per se

- If you said, “*No, David, my goal is to tell people about the foods they should eat, if they actually ate them, what the effects would be. Or my goal is to determine the effects of foods.*”
- Then he would go back to a statement from a wonderful book called [*A Fly in the Ointment*](https://www.amazon.com/Fly-Ointment-Fascinating-Commentaries-Everyday/dp/1550226215/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.oAdoPHrGzTSNC7KNZvt2qbFtWYDaEXjy6s33ZWtf7dKE_edJuLTj_KUERPBh3Xz7PrmvqBHr2D7_qmEvTmuhZX47MuiMuLgQzhXc85KLfqvB68pnpuMtVS2YwOnS9UamoD1KWFSP9i5bevzmktfsEBsCPs90fTtKm3uMdzNUY2ZGrpXv1VPCntYeo2b_kgCmW7B6IKIFIAM1psRNB0IfMwPLLNbG40u8BTmWCvSPHa4.0pZ0-mLHCamcyu1YJEwMCkADfZWil_bkN5GghHTdu3Q&qid=1758884293&sr=8-2), by someone named Joe Schwartz
- [Dr. Schwartz](https://www.mcgill.ca/oss/joe-schwarcz-phd-cm-director), who’s a food scientist, says something like, “*There is a motto, repeat after me, the effect of substances in the body depends on their molecular structure, not their ancestry*.”

**⇒** So if you give me this molecule or a collection of them to eat and you extracted that molecule from some berry and it’s natural, or you synthesize that molecule in a laboratory ‒ in the end it’s the same molecule

- It’s possible that you could try to synthesize it and it might have some slight difference, but let’s assume it’s literally the same molecule and it’s the same structure
- You give it to me in a liquid form or gaseous form or whatever it is

***If you say these are going to have different effects because of where they came from, it seems to me we’re in homeopathy now. This makes no sense.***

**Peter’s favorite example of this is natural sugar versus processed sugar**

- He doesn’t know if the people who say this are ignorant of what fructose and glucose are or if it’s deliberate marketing shenanigans
- David think’s it’s a mixture of deliberate marketing shenanigans, but it’s also the marketing of ideas
  - Not just food products by people with particular philosophical and other bents who are anywhere from just make themselves famous to push a philosophical thing, to push an anti-industry thing (whatever it is)
- Another example: natural vanilla versus synthetic vanilla
  - If it’s still vanilla, it’s vanilla

There’s a wonderful book by Alan Levinovitz called [*Natural*](https://www.amazon.com/Natural-Natures-Goodness-Harmful-Science/dp/0807010871/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.Kg7DA0I6btuuP-NAvmHPzD4EZG9ysacgy8U5246Ud30.V4iBOzTInM0Fj-1C93B8vLFzkoZsrTQJ1Ipi6Wv8JKU&qid=1758888980&sr=8-1), in which he will blow away every common conception of what natural is and what its value is

- He talks a lot about the idea that people want the natural vanilla
- Most of the vanilla flavoring we get in this country is not so-called natural from the vanilla plant, but if it was, it would probably have a much worse environmental impact than the other sources
- So it’s not always so simple

***In any case, David thinks Schwartz is right, it’s not the ancestry: whether you give me the molecule and it was locally grown or not locally grown, organic or not organic, ultra-processed or not ultra-processed, it’s the molecules and their structure that matter ‒ it doesn’t matter where it came from***

**In defense of the argument that ultra-processed foods must be worse**

- If you look at the ingredient list, the sheer number of molecules there would suggest we’re playing Russian roulette here
- Peter don’t recognize half the names of the things on the bag of Doritos
  - Maybe that’s a bad example because he hasn’t looked at a bag of Doritos in a while
  - They contain corn, oil, spices, [and [additional ingredients](https://en.wikipedia.org/wiki/Doritos#Ingredients), shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f5-davidallison3.png)

**Figure 5. Ingredients in Doritos (nacho cheese flavor)**. Image credit: [Open Food Facts](https://world.openfoodfacts.org/product/0028400420730/tortilla-chips-nacho-cheese-doritos)

- You could certainly find an ultra-processed food at the grocery store in which you cannot comprehend 50% of what’s in it
- And you don’t really know the **dose** either, because the only thing that the FDA requires is that you list ingredients in order of abundance
  - It could be that the first one represents 99% of it and the other 12 represent 1% of it
  - And even amongst that, there’s an uneven distribution, etc.
- It could be that these are just preservatives and color additives and they have no physical bearing, you just don’t know

***The point is, when I eat an apple, or even if I eat a processed apple in the sense that it’s been pre-cut up or it’s just a dried apple that’s dried apple chips, where I can look at the ingredient list and it says, “Apples,” I’ve got to be safer than if I’m eating 20 things of which I can’t pronounce 13 of them?***

David’s challenge

- If that’s the logic of your thinking, I have a great product I’d like to sell you
- It’s gluten-free, it’s seed oil-free; it’s not ultra-processed, it’s free of any harmful thing, it has no chemicals in it
- I call it vacuum
- And I would like to sell you this vacuum

***Basically that means nothing because we are chemicals***

- As David’s friend [Ferg Clydesdale](https://www.umass.edu/food-science/about/directory/fergus-m-clydesdale), who’s the former head of Nutrition Food Science Department at UMass Amherst, used to say, “*The whole purpose of eating is to get chemicals into the body to replace the chemicals the body loses through the process of living*.”

**⇒** All food is chemicals. We are chemicals.

- When you eat that apple and you say, I understand it, that’s apple
- Unless you have a lot of chemical knowledge (that most people don’t have), you don’t understand that any better than you understand something else that says benzoate phosphate or what have you, in it
- You just think you do because you think you understand what an apple is at a chemical level
  - You understand what it is at a fruit level maybe, but not at a chemical level
  - There are many chemicals in an apple, in an orange that you or I couldn’t pronounce, and that if someone wrote out what the chemicals are, we would say, “*What is that scary sounding thing?*”

**We also know that things that we think of as natural can be just as harmful**

- [Foxglove](https://en.wikipedia.org/wiki/Digitalis#Toxicity), [hemlock](https://en.wikipedia.org/wiki/Conium_maculatum#Toxicity)
- Socrates was killed by being forced to drink all natural hemlock ‒ it was all natural, very harmful

**⇒** poisons and drugs often come from natural things

- There’s also a **misperception that what we think of as natural is somehow [healthy]**, it has been around for thousands of years
  - And in some cases it’s true
  - In many cases it’s not
- The oranges and the apples and the grains that you’re eating today were largely not around years ago
  - They’ve been bred (even if it’s not transgenic), they’ve been bred by ordinary breeding things
- The cows, the chickens, the pigs have been bred to be different
- All the chicken, all the cow, all the pig that we eat in this country, the soybeans, none of that’s indigenous
  - They’re all invasive species
- Turkey, that’s indigenous to North America
  - Pecans and black walnuts are indigenous here, but not the other walnuts that they love so much in the Mediterranean diet over there

***David thinks this is all silliness***

> “*The only thing that’s artificial here is our creation of these categories and we should just recognize that we create the categories.*”‒ David Allison

- David suggests that we make food categories meaningful and useful

**Back to ultra-processed foods and wanting an easy heuristic to give friends or patients**

- There are heuristics that don’t require that classification
- There are lots of heuristics that work even though there might be some illogic embedded in them (or some incompleteness or some variability)

For example

- If you said to your kid, “*Look, you’re walking down the street. You’re in a big city. Someone comes up, ask you for a match, just keep walking.*”
  - They probably don’t really want a match
  - Some might and you might miss some, but it’s not a bad way to stay safe
- Similarly, if I said to you, “*You know what? Don’t eat anything from the center aisles of the grocery store. Or as little as you can. Get as much as you can from the periphery, the dairy, the produce, the meats, the fish and so on.*”
  - You might be better off
  - You will wind up eating less ultra-processed foods
  - You’ll wind up eating less energy-dense foods in many cases, etc.
- But that doesn’t mean there’s something intrinsic about the periphery of the aisles
  - It doesn’t mean if I took Twinkies and put them in the periphery and I took fat-free Greek yogurt and I put it in the middle, that suddenly it becomes bad and Twinkies become good

***It’s a heuristic and it might work for you to the extent you can stick to it and to the extent it’s correlated with these things it might work, but it says nothing about the causal effect of being in the periphery or the central aisle***

- This is the level to which we should take the category of ultra-processed foods

**Back to talking to that person about protein**

- You asked, “*How do you explain it to them?*”
- Maybe you don’t say eat 2 g/kg because that’s too hard
  - You have to use the metric system and Americans hate the metric system
  - And you have to do math and so on and you have to count stuff

***But if you just said, “Make sure you have 2 servings of lean fish per week and 1 serving of lean this and eat some egg whites and so on,” maybe that works***

**We all have our own foods**

- During WWII the federal government hired [Margaret Mead](https://en.wikipedia.org/wiki/Margaret_Mead) to try to get people to eat more organ meats because they wanted to send the steak to the soldiers overseas
  - Didn’t work
  - Even Margaret Mead couldn’t get people to eat a lot more organ meats
- David happens to love organ meats and some of his go-to protein sources are chicken gizzards
  - They have a fantastic protein to calorie ratio (he loves them)
  - A lot of people look at that and go, “*No.*”

> “*We need to figure out the way to get people to do this, but it’s the food that matters, not this.*”‒ David Allison

**Thinking about ultra-processed food, if we go back to the idea of wanting to understand the effects of the food**

***David thinks ultra-processed food is not a meaningful category***

- He wouldn’t even bother with attempts to find the right definition (it’s not even worth discussing)
- Instead, let’s talk about the substances in the food and their effects
  - What is the effect of eating dried apples?
  - Or what is the effect of eating things with this composition?
  - Or what is the effect of eating bottled wine or dried dates or grilled chicken gizzards?
  - That is where the knowledge is

**We can agree that at the individual level, the heuristic of, “*****Don’t eat ultra-processed foods,*****” is simply not helpful**

- Peter thinks the bottom line is: it’s too coarse a tool to parse out, it’s too nuanced of a subject
- There certainly could be better tools, but David doesn’t think it would be effective for the long term

***David’s view is, at the heuristic level, the category of ultra-processed food has nothing to do with causation or understanding the foods***

**If you said, “*****Give me a rule.*****”**

- It would be different for Peter because he’s very sophisticated and has a lot of knowledge
- For David’s dad (when he was alive), he was a smart man but probably intentionally not too smart about nutrition
  - Avoiding ultra-processed foods would probably work for him
  - Until he got sick of it and bored with it
  - Until good marketers were smart and marketed things that skirted the definition of ultra-processed so they could say, “*Not an ultra-processed food,*” but it still has the same degree of fat, sugar, calories, and whatever

[David Kessler’s](https://en.wikipedia.org/wiki/David_A._Kessler) said this nicely in some of his work: he made the distinction between ultra-processed and ultra-formulated

- He said ultra-processed was a waste of time as something we should focus our attention on for helping people
- He says ultra-formulated is better because then it talks about what’s in the food
- Processed talks about the process

***He doesn’t care how you got there; he wants you to care where you got to***

- And so that’s one way of making the thinking a little better

## Why conventional public health interventions for obesity have largely failed [A: 1:38:15, V: 1:49:14]

**Do you think that there are public health solutions to the metabolic situation we’re in as a country?**

- If you define public health solutions as things that exclude things we really consider clinical (like pharmaceuticals and surgery), and you say things where there’s palpable and demonstrable success at present ‒ ***David would say no***
- It’s painful to say that, but he would say that depending on your point of view, after roughly 50 years of looking at this, the answer is no
- David just put up a [LinkedIn post](https://www.linkedin.com/posts/david-allison-2917963b_these-findings-indicate-that-examined-parent-focused-activity-7373030684988403712-xybM?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg) about one of the latest [papers](https://pubmed.ncbi.nlm.nih.gov/40945528/) that came out of this Australian group that said we looked at all the parent training type stuff with kids and obesity and a big meta-analysis of study after study after study of year after year after year: ***there’s nothing there***

**Other areas where public health solutions have had some success**

Peter points out, “*You could argue that the only area in which public health has changed the course of societal health in this country, smoking cessation seems to be a success. There have been public health measures.*”

- Smoking cessation efforts at the policy level: excise taxes, advertising laws, rules for where you can smoke
  - Those have appeared to have a significant reduction in the number [of people who smoke]
- Seatbelts are another great example
- We’ve got some wins in public health

**Why do you think public health has been unsuccessful in this arena?**

*It can’t be for lack of trying*

- It may be for lack of trying in a little more intelligent and unbiased manner

David thinks there’s 2 really big reasons

- One is intrinsic to the problem
- One can never start smoking
  - For some people as difficult it is, one can abandon smoking entirely
- One can’t never start eating and one can’t for practical purposes abandon it entirely
  - So it’s a different problem
- You’ve got a very strong intrinsic push to eat; it’s linked to our survival

1 – Intrinsically it’s a hard goal to manipulate

- We like our freedom, we like our variety, and we don’t want to give any of that up
- If somebody were to say, “*If we eliminated all of these choices or you are only allowed to shop on Monday or you are only allowed to buy X calories, it’s like rationing in a war because some people are obese…*”
- Even though David himself has struggled with his weight, he would say, “*I don’t want to live in that world. I don’t want to give up my freedom of choice, even if it means I and some other people are going to struggle with our weight.*”

The problem with public health solutions for obesity

- Everything we do in the public health realm almost seems like either we can’t get it to stick or we didn’t think through enough and if it stuck, it would work
- Or it’s like whack- a-mole
  - That is you get me to consume fewer calories here or expend more energy there and then I expend less here or consume more there
- That’s the intrinsic problem

2 – The problem with the solutions we’ve tried

- The other problem is that we started off with the obvious stuff
- We looked for the keys under the lamppost because that’s where the light was best
- For example: school-based approaches, farmer’s markets, walking trails, calories on the menu, and so on
  - All good ideas
  - Nudge

***We tried them, and none of them really seemed to work meaningfully***

- At the beginning, that was fine

> “*What I think we have is a failure of courage, honesty, and creativity to say, ‘We’ve shown that none of those things have large demonstrable meaningful effects.’*”‒ David Allison

- We’ve not shown that none of them could ever have any effect under any circumstance
- But David thinks for practical purposes, we’ve shown that those things don’t have large demonstrable meaningful effects
- It’s time to stop pretending that they might and proposing and funding the next study that’s only a trivial variant on the many, many such studies that went before and were shown to not be successful

***We need to start taking radically different views and say the next time someone comes and says, “I’ve got this parent-based or school-based or community-based idea,” tell us how it’s radically different than what’s gone before (not trivially different)***

## Two ideas from David for addressing the metabolic health problem in society [A: 1:42:30, V: 1:54:33]

**Do you have any radical ideas that if you ignore the challenges or issues around implementation, you would want to implement?**

- David thinks Peter asked him this question before, and he’s going to change his answer slightly
  - [David touched on this in episode [#314 after 32:45](https://peterattiamd.com/davidallison2/#:~:text=absolutely%20not%20true-,Rethinking%20obesity%20solutions%3A%20the%20need%20for%20a%20paradigm%20shift%20%5B32%3A45%5D,-We%20need%20sub)]
- Before he said 2 things
- 1 – If you really want to decrease suffering now for some subset of the population for which we could afford it, make bariatric surgery freely available
- 2 – Then for investing in research, invest in research on the effects of general quality of upbringing and general education
  - Especially, but not only, for women and girls
- David is going to stick with the second one and say we still need that

***We need to look at what are the effects of general education, not nutrition education***

- General education, general parent training, general security, financial, and other kinds of security growing up on obesity levels

*What’s the hypothesis there?*

- The hypothesis is around general education and security so that you’re not constantly worried about, “*Can I pay the bills? Will I be able to get food at all.*”
- There’s minimal circumstantial evidence that good parenting and those things lead to reductions in obesity and diabetes decades later
  - Even though it delivers whatever psychological benefits

**The 2 best studies David knows of**

- The [Moving to Opportunity study](https://www.huduser.gov/portal/mto.html) funded by the Department of Housing and Urban Development
- The [Abecadarian Study](https://esmed.org/MRA/mra/article/view/4590) done by Craig and Sharon Ramey

Peter asks, “*But of those 3 things, isn’t education and financial well-being higher today than it was 50 years ago?*”

- He points out that parental support is probably less today
  - There are probably more broken families today
- But 2 of those 3 are better today than 50 years ago, aren’t they?
- David is not sure

***David doesn’t want to say they’re better, but he thinks there is tremendous disparity***

- The quality of the education and security and so on that some people get is very different than others
- Confucius famously said, “*We are not concerned about poverty. We are concerned about differentials of wealth*.”

David proposes, “*It’s possible that the public health solution to obesity is becoming a* [*Marxist*](https://en.wikipedia.org/wiki/Marxism)*. I’m not sure we all want to volunteer. But I think some of these things are worth looking at*.”

- We do see that there seem to be these long-term benefits in studies
  - The studies David mentioned are what he thinks are the 2 best, but they’re not the only ones, where they weren’t meant to be primarily nutrition, obesity studies

**How does that explain what you see in the Gulf nations of the Middle East, for example, where you have countries that are remarkably wealthy, there is no poverty?**

- Obviously there is disparity in wealth between the very affluent, which is effectively everybody, and then the ultra affluent
- Families aren’t broken
- Everybody is educated and yet obesity and diabetes rates are greater than even in the US

There’s at least 2 ways to look at that

1 – The idea of interaction

- The same exposures may not have the same effects in one place or another
- For example, we consistently see that in less developed countries, poorer countries, less industrialized countries: greater wealth is associated with greater obesity
- We consistently see in more industrialized wealthy countries, greater wealth and education, especially among adult women, tends to be associated with lesser obesity
- So you have the interaction

2 – The strength of evidence

- One of the things people frequently say when you say, “*Well, we think temperature has this effect.*” And they say, “*What about those people in Iceland? They don’t have…*”
  - “*Well, alcohol is this.*” “*Yes, but those people over there, they drink a lot and they don’t have…*”
  - They’re different in many ways
- We don’t know that any one factor has to explain why Qatar has this versus Samoa or something, but David thinks it’s a good hypothesis
- That’s what David would look at in terms of we think of as traditional public health

## The potential of GLP-1 agonists to play a large role in public health [A: 1:46:30, V: 1:59:21]

- As profoundly beneficial as [GLP-1 receptor agonist-related drugs](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) appear to be, David thinks it’s going to be hard not to take the question seriously of: Should these drugs be the default [solution]?
- David compares it to other questions:
  - Should it be that the default is you get this vaccine when you’re a kid?
  - Should it be the default that you get your teeth fluoridated at the dentist?
  - That it’s not, “*Hmm, maybe some people should get that.*”
- We’re at the point where we’re saying as these drugs continue to be tested and experienced, if we continue to see the effects we’re getting, are we getting to the point where we should start to say, “*You know what? That idea of the poly pill that came up decades ago where young adults, even if you don’t have obesity, hypertension, etc., you’d get a low-dose diuretic, low-dose metformin, etc., low-dose statin…*”
  - Are we at the point where we probably still should do that?
- And then allow anybody to get a low-dose GLP-1 agonist-related drug
  - We’ll roll it out and pay for it for anybody in the country who wants it
  - David thinks that may be the future

---

## Selected Links / Related Material

**Episodes of** ***The Drive*** **with David Allison**: [1:00]

- [#197 – The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.](https://peterattiamd.com/davidallison/) (February 8, 2022)
- [#314 ‒ Rethinking nutrition science: the evolving landscape of obesity treatment, GLP-1 agonists, protein, and the need for higher research standards | David Allison, Ph.D.](https://peterattiamd.com/davidallison2/) (August 19, 2024)

**Children’s Nutrition Research Center**: [USDA/ARS Children’s Nutrition Research Center](https://www.bcm.edu/research/research-centers/usda-ars-childrens-nutrition-research-center) | Baylor College of Medicine (2025) | [1:15]

**Episode of** ***The Drive*** **with Don Layman**: [#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.](https://peterattiamd.com/donlayman/) (September 26, 2022) | [7:45]

**Evidence supporting consuming 30 g protein for optimal protein synthesis**: [8:00]

- [Dose-response effects of dietary protein on muscle protein synthesis during recovery from endurance exercise in young men: a double-blind randomized trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC7398777/#sec4) | *American Journal of Clinical Nutrition* (T Churchward-Venne et al. 2020)
- [A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength in healthy adults](https://pubmed.ncbi.nlm.nih.gov/28698222/) | *British Journal of Sports Medicine* (R Morton et al. 2018)

**Study where subjects ate nothing but potatoes for 6 months**: [The value of whole potato in human nutrition](https://pmc.ncbi.nlm.nih.gov/articles/PMC1252113/) | *Biochemical Journal* (S Kazimierz Kon, Aniela Klein 1928) | [9:30]

**Newsletter**: [Determining optimal protein intake from data, not dogmatism](https://peterattiamd.com/determining-optimal-protein-intake/) | *PeterAttiaMD.com* (K Birkenbach, P Attia August 23, 2025) | [10:45]

**David Protein bars**: [David](https://davidprotein.com/pages/about-us) | [13:30]

**David’s recent LinkedIn posts about protein**: [38:30]

- [PROTEIN: MIRACLE FOOD OR DANGEROUS FAD? DATA AND EVIDENCE SHOULD GUIDE OUR THINKING, ANTI-HYPE BACKLASH AND MORAL PANIC SHOULD NOT](https://www.linkedin.com/posts/david-allison-2917963b_protein-miracle-food-or-dangerous-fad-data-activity-7375623586637631488-XMj4?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)
- [High Protein Diets: Benign or… Who Has the Burden of Proof?](https://www.linkedin.com/posts/david-allison-2917963b_determining-optimal-protein-intake-from-data-activity-7368299524093587456-7z97?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)
- [Stuart Phillips aptly states “Science self-corrects—sometimes it just takes a decade (or more).”](https://www.linkedin.com/posts/david-allison-2917963b_protein-mortality-epidemiology-activity-7359779910032281600-aWWM?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)
- [THE DANGER OF HIGH PROTEIN INTAKE IN NORMAL HUMANS? SHOW ME THE DATA](https://www.linkedin.com/posts/david-allison-2917963b_the-danger-of-high-protein-intake-in-normal-activity-7358769010160685056-mWak?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)]
- [“Red Meat for Food Fear and False Obesity Stories”](https://www.linkedin.com/posts/david-allison-2917963b_red-meat-for-food-fear-and-false-obesity-activity-7358377332379664385-SjtU?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)
- [More sound science-based protein insights from Prof. Stuart Phillips.](https://www.linkedin.com/posts/david-allison-2917963b_is-there-a-minimum-yet-effective-protein-activity-7349602684770865153-pC1c?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)
- [Gaining Muscle with Resistance Training (RT): Is Protein even a BIG Deal or Minor Player?](https://www.linkedin.com/posts/stuartmphillips_musclegain-resistancetraining-proteinintake-activity-7336532487973609473-o8Ce?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)
- [THE HARMS OF HIGH PROTEIN INTAKE: CONJECTURED, POSTULATED, CLAIMED, AND PRESUMED, BUT SHOWN?](https://www.linkedin.com/posts/david-allison-2917963b_the-harms-of-high-protein-intake-conjectured-activity-7326466902657040384-EhyA?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)
- [An excellent two days at the Human Dietary Protein Needs and Benefits workshop in Rosemont, IL.](https://www.linkedin.com/posts/activity-7300644494171856896-wsCY?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg)

**Amount of protein needed in the diet to support muscle protein synthesis**: [45:15]

- [A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength in healthy adults](https://pubmed.ncbi.nlm.nih.gov/28698222/) | *British Journal of Sports Medicine* (R Morton et al. 2018)
- [Dose-response effects of dietary protein on muscle protein synthesis during recovery from endurance exercise in young men: a double-blind randomized trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC7398777/) | *American Journal of Clinical Nutrition* (T Churchward-Venne et al. 2020, senior author: Luc van Loon)
- [Protein Intake to Maximize Whole-Body Anabolism during Postexercise Recovery in Resistance-Trained Men with High Habitual Intakes is Severalfold Greater than the Current Recommended Dietary Allowance](https://pubmed.ncbi.nlm.nih.gov/31618421/) | *The Journal of Nutrition* (M Michael et al. 2020)

**David’s study of the health effects of Frito-Lay chips fried in corn oil**: [Snack chips fried in corn oil alleviate cardiovascular disease risk factors when substituted for low-fat or high-fat snacks](https://pubmed.ncbi.nlm.nih.gov/17556685/) | *American Journal of Clinical Nutrition* (M St-Onge et al. 2007) | [53:00]

**Organizations that identify fraudulent research publications**: [1:03:30]

- [Medical Evidence Project](http://medicalevidenceproject.org)
- [Retraction Watch](https://retractionwatch.com/)
- [Meta-Research Center](https://metaresearch.nl/)
- [Statcheck](http://statcheck.io/) (and [instructions](https://mbnuijten.com/statcheck/))

**NHANES data on ultra-processed food intake**: [1:18:30]

- [Ultra-processed food intake and mortality in the USA: results from the Third National Health and Nutrition Examination Survey (NHANES III, 1988-1994)](https://pubmed.ncbi.nlm.nih.gov/30789115/) | *Public Health Nutrition* (H Kim, E Hu, C Rebholz 2019)
- [Identifying and Estimating Ultraprocessed Food Intake in the US NHANES According to the Nova Classification System of Food Processing](https://pubmed.ncbi.nlm.nih.gov/36913457/) | *Journal of Nutrition* (E Martinez Steele et al. 2023)
- [Ultra-processed Food Consumption in Youth and Adults: United States, August 2021–August 2023](https://www.cdc.gov/nchs/products/databriefs/db536.htm) | *NCHS Data Brief* (A Williams et al. 2025)

**Book supporting the idea that the molecular structure of food is important, not its ancestry**: [The Fly in the Ointment: 70 Fascinating Commentaries on the Science of Everyday Life](https://www.amazon.com/Fly-Ointment-Fascinating-Commentaries-Everyday/dp/1550226215/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.oAdoPHrGzTSNC7KNZvt2qbFtWYDaEXjy6s33ZWtf7dKE_edJuLTj_KUERPBh3Xz7PrmvqBHr2D7_qmEvTmuhZX47MuiMuLgQzhXc85KLfqvB68pnpuMtVS2YwOnS9UamoD1KWFSP9i5bevzmktfsEBsCPs90fTtKm3uMdzNUY2ZGrpXv1VPCntYeo2b_kgCmW7B6IKIFIAM1psRNB0IfMwPLLNbG40u8BTmWCvSPHa4.0pZ0-mLHCamcyu1YJEwMCkADfZWil_bkN5GghHTdu3Q&qid=1758884293&sr=8-2) by Dr. Joe Schwarcz (2004) | [1:26:30]

**Book comparing natural and synthetic vanilla**: [Natural: How Faith in Nature’s Goodness Leads to Harmful Fads, Unjust Laws, and Flawed Science](https://www.amazon.com/Natural-Natures-Goodness-Harmful-Science/dp/0807010871/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.Kg7DA0I6btuuP-NAvmHPzD4EZG9ysacgy8U5246Ud30.V4iBOzTInM0Fj-1C93B8vLFzkoZsrTQJ1Ipi6Wv8JKU&qid=1758888980&sr=8-1) by Alan Levinovitz (2020) | [1:28:30]

**Study finds parent-focused behavioral intervention for the prevention of childhood obesity ineffective**: [Parent-focused behavioural interventions for the prevention of early childhood obesity (TOPCHILD): a systematic review and individual participant data meta-analysis](https://pubmed.ncbi.nlm.nih.gov/40945528/) | *Lancet* (K Hunter et al. 2025) | [1:38:45]

**Public health interventions that reduce obesity**: [1:44:00]

- [Moving To Opportunity](https://www.huduser.gov/portal/mto.html) | HUD Office of Policy Development and Research
- [Early Childhood Education that Promotes Lifelong Learning, Health, and Social Well-being: The Abecedarian Project and its Replications](https://esmed.org/MRA/mra/article/view/4590) | *European Society of Medicine* (C Ramsey, S Ramsey 2023)

**Recent letter on the need for better scientific reporting by David Allison**: [Calling Guidance Evidence-Based When It Is Not Is Against the Ethos of Science](https://pubmed.ncbi.nlm.nih.gov/40935149/) | *American Journal of Clinical Nutrition* (E Dhurandhar et al. 2025)

**Position statement and review on protein intake**: [International Society of Sports Nutrition Position Stand: protein and exercise](https://pubmed.ncbi.nlm.nih.gov/28642676/) | *Journal of the International Society of Sports Nutrition* (R Jäger et al. 2017)

---

## People Mentioned

- [Donald (Don) Layman](https://fshn.illinois.edu/directory/dlayman) (Professor Emeritus at the University of Illinois Urbana-Champaign, expert in protein requirements for adult health) [7:45, 30:30]
- [Stephen (Steve) Simpson](https://www.sydney.edu.au/science/about/our-people/academic-staff/stephen-simpson.html) (NHMRC Leadership Fellow Professor in the School of Life and Environmental Sciences at The University of Sydney, Executive Director of Obesity Australia, developed the Geometric Framework for modeling nutrition and understanding complex systems)  [12:15]
- [David Raubenheimer](https://www.sydney.edu.au/science/about/our-people/academic-staff/david-raubenheimer.html) (Professor of Nutritional Ecology, Leonard P Ullmann Chair in Nutritional Ecology in the School of Life and Environmental Sciences at the University of Sydney, expert in nutritional ecology) [12:15]
- [Steven Levitt](https://pricetheory.uchicago.edu/levitt/) (William B. Ogden Distinguished Service Professor of Economics at the University of Chicago, where he directs the Becker Center on Chicago Price Theory; co-author of *Freakonomics*) [20:15]
- [Kevin Hall](https://www.kevinhallphd.com/) (Internationally renowned expert in human nutrition, metabolism, obesity, and neuroscience, formerly Section Chief of the Integrative Physiology Section, Laboratory of Biological Modeling at [NIDDK](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin); expert in clinical nutrition research) [23:45, 49:30]
- [David Ludwig](https://www.drdavidludwig.com/about-the-author/) (Professor of Nutrition at [Harvard](https://hsph.harvard.edu/profile/david-s-ludwig/) School of Public Health and Professor of Pediatrics at Harvard Medical School; an endocrinologist, researcher at Boston Children’s hospital, author, and Co-Director of the New Balance Foundation Obesity Prevention Center)   [23:45]
- [Dudley Lamming](https://lamminglab.medicine.wisc.edu/dudley-lamming/) (Associate Professor in the Department of Medicine Division of Endocrinology, Diabetes and Metabolism at the UW-Madison School of Medicine and Public Health, and is a Research Health Scientist at William S. Middleton Memorial Veterans Hospital) [40:45]
- [Luigi Fontana](https://www.sydney.edu.au/medicine-health/about/our-people/academic-staff/luigi-fontana.html) (Professor of Medicine and Nutrition Leonard P. Ullman Chair in Translational Metabolic Health at the University of Sydney, Scientific Director of the Charles Perkins Centre Royal Prince Alfred Clinic, Director of the ‘Health for Life’ Research, Educational and Clinical Program) [40:45]
- [Marie Pierre St Onge](https://mr.research.columbia.edu/content/marie-pierre-st-onge) (Associate Professor of Nutritional Medicine (in Medicine and the Institute of Human Nutrition) at the Columbia University Medical Center, Dept of Medicine Endocrinology; expert in identifying the causality of the association between lifestyle behaviors and cardio-metabolic risk) [54:30]
- [Marion Nestle](https://steinhardt.nyu.edu/people/marion-nestle) (Paulette Goddard Professor and Professor Emerita of Nutrition, Food Studies, ND Public Health at NYU Steinhardt; expert in examining the scientific, societal, and business influences on food choices and their health consequences with an emphasis on food industry marketing)  [54:00]
- [Jay Bhattacharya](https://en.wikipedia.org/wiki/Jay_Bhattacharya) (18th Director of the NIH, Emeritus Professor of Health Policy at [Stanford](https://profiles.stanford.edu/jay-bhattacharya), expert in the economics of health care with an emphasis on vulnerable populations) [55:30]
- [Miguel Hernan](https://hsph.harvard.edu/profile/miguel-hernan/) (Kolokotrones Professor of Biostatistics and Epidemiology at the Harvard T.H. Chan School of Public Health, expert in methodology for causal inference) [59:30]
- [James Heathers](https://www.linkedin.com/in/james-heathers-phd-63a70240/) (Director of [medicalevidenceproject.org](http://medicalevidenceproject.org), co-host of [*Everything Hertz*](https://everythinghertz.com/hosts/james?page=12), psychophysiologist and meta-scientist) [1:03:30]
- [Tracy Weissgerber](https://www.linkedin.com/in/tracey-weissgerber-444a333a/?originalSubdomain=pt) (Meta-researcher with expertise in data visualization and automated tools used to screen papers, [Excelscior ERA Chair Team Leader](https://excelscior.uc.pt/) at the University of Coimbra, Portugal) [1:03:45]
- [Michèle Nuijten](https://www.linkedin.com/in/michelenuijten/?originalSubdomain=nl) (Assistant Professor at the Department of Methodology and Statistics at the School of Social and Behavioral Sciences of [Tilburg University](https://www.tilburguniversity.edu/staff/m-b-nuijten), the Netherlands where she is part of the [Meta-Research Center](https://metaresearch.nl/); meta-scientist with expertise in identifying questionable research practices; developer of [statcheck](http://statcheck.io/)) [1:03:45]
- [Michael F. Jacobson](https://www.nationalfoodmuseum.org/board-of-director/) (Co-founder and former longtime codirector of the [Center for Science in Public Interest](https://www.cspi.org/about), Founder of the [National Food Museum](https://www.nationalfoodmuseum.org/about/), nutrition activist who coined the term “junk food”) [1:06:15]
- [Kelly Brownell](https://globalhealth.duke.edu/people/brownell-kelly) (Director of the World Food Policy Center, Professor of Public Policy, and former Dean of the Sanford School of Public Policy, at Duke University; Robert L. Flowers Distinguished Professor Emeritus of Public Policy and Professor Emeritus in the Sanford School of Public of Public Policy Affiliate at the Duke Global Health Institute; leader in the field of obesity research) [1:17:45]
- [Joe Schwarcz](https://www.mcgill.ca/oss/joe-schwarcz-phd-cm-director) (Director of McGill University’s “Office for Science and Society” which has the mission of separating sense from nonsense, author of [The Fly in the Ointment](https://www.amazon.com/Fly-Ointment-Fascinating-Commentaries-Everyday/dp/1550226215/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.oAdoPHrGzTSNC7KNZvt2qbFtWYDaEXjy6s33ZWtf7dKE_edJuLTj_KUERPBh3Xz7PrmvqBHr2D7_qmEvTmuhZX47MuiMuLgQzhXc85KLfqvB68pnpuMtVS2YwOnS9UamoD1KWFSP9i5bevzmktfsEBsCPs90fTtKm3uMdzNUY2ZGrpXv1VPCntYeo2b_kgCmW7B6IKIFIAM1psRNB0IfMwPLLNbG40u8BTmWCvSPHa4.0pZ0-mLHCamcyu1YJEwMCkADfZWil_bkN5GghHTdu3Q&qid=1758884293&sr=8-2)) [1:26:30]
- [Fergus Clydesdale](https://www.umass.edu/food-science/about/directory/fergus-m-clydesdale) (Distinguished University Professor, Department of Food Science, University of Massachusetts Amherst, and Director of the University of Massachusetts Food Science Policy Alliance; works to establish scientifically based interpretations of national and international food regulations and policy) [1:30:45]
- [Margaret Mead](https://en.wikipedia.org/wiki/Margaret_Mead) (1901-1978, cultural anthropologist and author) [1:35:00]
- [David Kessler](https://en.wikipedia.org/wiki/David_A._Kessler) (Pediatrician, administrator, author of [*The End of Overeating*](https://www.amazon.com/End-Overeating-Insatiable-American-Appetite/dp/1605297852/ref=tmm_hrd_swatch_0)) [1:37:45]

---

![](https://peterattiamd.com/wp-content/uploads/2025/10/Screenshot-2025-10-10-at-9.38.54-AM-600x600.png)

##### David Allison, Ph.D.

David Allison earned his BA from Vassar College in New York. He then earned a master’s and Ph.D. in Clinical and School Psychology from Hofstra University. Dr. Allison completed postdoctoral training at Johns Hopkins University in the departments of Pediatrics and Behavioral Psychology. He then shifted his focus to obesity and completed additional postdoctoral training at Columbia University College of Physicians and Surgeons & Saint Luke’s/Roosevelt Hospital, where he had a NIH Post-Doctoral Research Fellowship in the Department of Medicine & Obesity Research Center. After his fellowship, Dr. Allison continued there as a research scientist and Associate Professor. In 2001, he moved to the University of Alabama at Birmingham where he served as a distinguished professor and director of the NIH-funded Nutrition Obesity Research Center. In 2017, he became Dean and Provost Professor at the Indiana University School of Public Health-Bloomington. Currently, Dr. Allison is a professor, endowed chair, and director of the Children’s Nutrition Research Center at [Baylor College of Medicine](https://www.bcm.edu/people-search/david-allison-181551). He has been continuously NIH-funded as a principal investigator for over 30 years, and has authored more than 700 scientific publications.

Dr. Allison has received numerous awards and is a staunch advocate for rigor in research methods and truthful communication of research findings. In 2022 he was named a Distinguished Lecturer by Sigma Xi and received the Hoebel Prize for Creativity (Society for the Study of Ingestive Behavior). He received the 2023 Bodil M. Schmidt-Nielsen Distinguished Mentor and Scientist Award (American Physiological Society). He is currently president-elect of Sigma Xi. Elected to the National Academy of Medicine in 2012, he also serves as co-chair of the National Academy of Sciences’ Strategic Council on Research Excellence, Integrity and Trust. In July 2025, he was appointed as a Methodology Committee member and will serve on the panel through June 2029. [[PCORI](https://www.pcori.org/people/david-b-allison-phd)]

LinkedIn: [David Allison](https://www.linkedin.com/in/david-allison-2917963b/)