# #65 – Rick Doblin, Ph.D.: MDMA — the creation, scheduling, toxicity, therapeutic use, and changing public opinion of what is possibly the single most important synthetic molecule ever created by our species

**Source:** [https://peterattiamd.com/rickdoblin/](https://peterattiamd.com/rickdoblin/)

---

In this episode, Rick Doblin, founder and executive director of MAPS, discusses MDMA, a molecule that has (at a minimum) revolutionary therapeutic benefits for PTSD, but arguably could have, at the highest order, a lasting impact on humanity’s ability to peacefully coexist. Rick details the history of MDMA, what lead to its unfortunate criminalization, and his lifelong work trying to protect MDMA (and other psychedelics) from criminalization (and his subsequent attempt to decriminalize it) Through his founding of MAPS, Rick has made enormous progress in debunking many of the exaggerated risks being claimed against MDMA (neurotoxicity, memory loss, depression, Parkinson’s, etc.), and is very close to getting FDA approval for a psychotherapy technique using MDMA. Additionally in this discussion, you will learn about the history of LSD, psilocybin, and other psychedelics and how the combination of the misunderstanding of them with the crackdown on drug use in the 1970s lead to their designation of schedule 1 substances. But it’s important to note that you will also realize from this discussion just how different MDMA is compared to the average psychedelic. We end this discussion with a message of hope: there are going to be many people who are going to wonder what can they do to receive this MDMA therapy. We talk about what those clinical trials look like, what the enrollment looks like, and perhaps more importantly, what a compassionate use license would look like, such that if there are patients who are in need of this therapy (prior to its approval) they can have an understanding of the legal paths to doing just that.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/rickdoblin/the_Drive_public.png)

Play

#65 - Rick Doblin, Ph.D.: MDMA— the creation, scheduling, toxicity, therapeutic use, and changing public opinion of what is possibly the single most important synthetic molecule ever created by our species

#65 - Rick Doblin, Ph.D.: MDMA— the creation, scheduling, toxicity, therapeutic use, and changing public opinion of what is possibly the single most important synthetic molecule ever created by our species

1x15s30s

0:003:00:56

We discuss:

- Discovering MDMA, how Rick learned about it and his first experiences with it [9:45];
- The timeline of MDMA’s evolution, the reinvention in the 1970s, “ecstasy”, the criminalization of MDMA [21:10];
- Explaining the different “schedules” of drugs [30:55];
- Rick’s fight to protect it for therapeutic uses, losing to the DEA despite winning in the court, the scientific community, and the media [38:25];
- The risks involved with taking MDMA [42:30];
- An incredible MDMA-LSD case study: Rick’s story of healing a treatment-resistant PTSD patient in the 1980s [44:45];
- How and why MDMA was declared illegal on an emergency basis going against the judge’s recommendation after hearing Rick’s compelling case (and multiple appeals) in court [57:15];
- Rick’s decision to study politics to affect change from the inside out, and the recent progress being made with the DEA [1:07:00];
- Debunking the exaggerated risks of MDMA (e.g., neurotoxicity) [1:16:30];
- Rick’s unbelievable ability to play the long game [1:28:45];
- Which patients would not be good candidates for MDMA from a safety perspective? [1:34:30];
- How MDMA is different from all other psychedelics, the importance of the setting, and Peter’s experiences with MDMA [1:36:30];
- MDMA studies which lead to the crucial designation as a “breakthrough therapy” [1:40:30];
- How someone with PTSD can get treated now through “expanded access for compassionate use” [1:46:00];
- Rick’s ultimate goal and long term vision for psychedelic clinics [1:50:30];
- Trip of Compassion documentary, and how psychedelics could change the world [1:52:30];
- Rick’s early life: Resisting the draft, his feeling of wanting to change the world, and his profound experiences with LSD and other psychedelics [1:55:30];
- The history of LSD and psilocybin, and the CIA’s interest in psychedelics [2:10:45];
- Timothy Leary and the Good Friday Experiment [2:22:00];
- Rick’s follow up study to the Good Friday Experiment, and his criticism (and praise) of Tim Leary [2:33:50];
- Peter’s experience taking psilocybin [2:44:30];
- The Concord Prison Experiment, and Rick’s follow up study 34 years later [2:47:00]; and
- More.

§

## Show Notes

## Discovering MDMA, how Rick learned about it and his first experiences with it [9:45]

[Multidisciplinary Association for Psychedelic Studies (MAPS)](https://maps.org/)

- Rick is the founder and director of MAPS (founded in 1986)
- [Wikipedia page](https://en.wikipedia.org/wiki/Multidisciplinary_Association_for_Psychedelic_Studies)

[Realms of the Human Unconscious](https://www.amazon.com/Realms-Human-Unconscious-Observations-Research/dp/0285648829) by Stan Grof about his work with LSD

- This book really influenced Rick when he was in college in 1972
- “*That book that really helped me see that here is spirituality, but viewed through a scientific lens. And it had the reality check of therapy. It’s focused on how do you help these people suffering from different conditions grow.*”

In 1972, Rick dropped out of college (he was attending [New College of Florida](https://en.wikipedia.org/wiki/New_College_of_Florida))

For the next 10 years (1972-1982)…

- He did “everything that I could to try to elevate and expand my consciousness, including I have the delusion that the more psychedelics I took, the faster I would evolve, which I underestimated the whole integration process.”

In 1982, Rick re-enrolled at New College to study transpersonal psychology and psychedelic psychotherapy

**Rick learns about MDMA for the first time**

- Shortly after returning to New College, Rick took a month-long workshop by [Stan Grof](https://en.wikipedia.org/wiki/Stanislav_Grof) called the “Mythical Quest” at the [Esalen Institute](https://en.wikipedia.org/wiki/Esalen_Institute)
- And so during this month long at Esalen, he met a woman named [Debby Harlow](https://enacademic.com/dic.nsf/enwiki/11117969/Earth) who started talking about this new drug called “Adam” and how it was used in therapy
- “Adam” turned out to be what’s now called [**MDMA**](https://en.wikipedia.org/wiki/MDMA)

**Early days of MDMA**

- Used in underground therapy circles since the middle ’70s
- By 1982, it had “escaped” therapy circles and was started to be sold as “ecstacy”
- Rick said he initially underestimated the drug because people weren’t having “profound trips” and instead seemed perfectly capable of normal conversation

**MDMA is unlike most psychedelics**, it’s an [empathogen](https://en.wikipedia.org/wiki/Empathogen%E2%80%93entactogen)

- The empathogen is a really good word for MDMA, that it produces empathy
- This term was really created once we needed to legally protect the use of MDMA
- It was to try to say that it wasn’t like a traditional psychedelic
  - There is no dissociation
  - There’s no hallucination
  - You remember the experience as though you’re completely awake
- “*MDMA is a psychedelic, but it’s not a classic psychedelic.*”

**Rick’s first time taking MDMA**

First took it with his girlfriend (at the time)

“This love we’re expressing and experiencing is… It’s really us. It’s not a drug delusion. It’s liberating us to express what we really feel. I felt like the profundity and the depth of connection was genuine and also something that we could learn from.”

**Why Rick believes MDMA is so therapeutic:**

> “I think one of the things that makes this so helpful therapeutically is that because you’re not dissolving your ego, it’s easier to integrate what happened. It’s not that far away from normal consciousness. It’s a subtle shift with a reduction in fear in the amygdala, and different areas. It’s just profound, therapeutic. And so once I tried it, I thought that this was an incredible opportunity.”

[**Controlled Substances Act**](https://en.wikipedia.org/wiki/Controlled_Substances_Act)

- In 1970, this Act was the criminalization of all the psychedelics, and the effort to squash psychedelic research all over the world
- MDMA was not part of that act
- This prompted Rick to start a non-profit in 1984

**Rick was inspired by the book,** [**New Genesis: Shaping a Global Spirituality**](https://www.amazon.com/New-Genesis-Shaping-global-spirituality/dp/038518123X) **by** [**Robert Muller**](https://en.wikipedia.org/wiki/Robert_Muller)

- He read it in 1983
- Book argued for the need for a global spirituality being the key to human survival
- The only thing the book was lacking was the mention of psychedelics

Rick then wrote a letter to Robert

- Rick told Robert about MDMA and the [Good Friday Experiment](https://en.wikipedia.org/wiki/Marsh_Chapel_Experiment)
- His letter led to an introduction to [Laura Huxley](https://en.wikipedia.org/wiki/Laura_Huxley)
- This relationship led to the non-profit whose purpose was to try to figure out how to protect MDMA and keep it from becoming illegal

## The timeline of MDMA’s evolution, the reinvention in the 1970s, “ecstasy”, the criminalization of MDMA [21:10]

- However, in parallel to Rick’s learning about MDMA, it has found its way into the public as ecstacy and was being used as a party drug
- Famously used at [Starck Club](https://www.nytimes.com/2014/04/13/us/the-starck-club-documents-rise-and-fall-of-dallas-nightclub.html), in Dallas, Texas
- Ecstasy was [created by Michael Clegg](https://deadline.com/2019/02/michael-clegg-ecstasy-tv-series-mdma-origins-1202560657/)
- The drug was gaining popularity…

“*And so that was a concern to those of us that were interested in trying to protect the therapeutic use, that this public use was going to doom it.*”

**Beginnings of MDMA**

- [MDMA was invented by Merck Pharmaceutical in 1912](https://www.thedea.org/docs/2006_Freudenmann_22846_1.pdf)
- Did nothing with it at first
- Tested it in animals in 1927 but found nothing and abandoned it

**Animal studies with MDMA**

*In 2018, there was Octopus study*: [A Conserved Role for Serotonergic Neurotransmission in Mediating Social Behavior in Octopus.](https://www.cell.com/current-biology/fulltext/S0960-9822(18)30991-6)

- Notoriously anti-social, the octopuses showed much more social behavior when given MDMA
- Suggesting that whatever MDMA is doing, it is doing it in a primitive part of our brain meaning it was (i.e., it’s not exclusively acting on the cortex)

MDMA in mice: [Oxytocin-dependent reopening of a social reward learning critical period with MDMA](https://www.nature.com/articles/s41586-019-1075-9)

- They showed is that MDMA releases oxytocin, which causes neurogenesis, the birth of new neurons and new neural connections in prosocial areas of the brain
- They speculated that that’s what’s underlying the increase in the therapeutic alliance between patient and therapist
- That MDMA catalyzes this oxytocin release including hormones of love and bonding, and nurturing, and nursing mothers, and when you’re in love

\*Note: Rick compared MDMA to mescaline and methamphetamine in the following way:

- It makes you alert, but it doesn’t make you jittery like methamphetamine. You can take it and be alert, but be perfectly still.
- But it’s also similar to mescaline, but it doesn’t have the ego dissolving, sort of visual classic psychedelic properties that mescaline has
- So MDMA is kind of between mescaline and methamphetamine, but different from each end of the spectrum

**The timeline**:

- Invented in 1912
- In 1927, Merck does studies in animals, then gives it up
- In 1953 when the U.S. Army Chemical Warfare Service [tested eight different drugs for toxicity in animals](https://www.sciencedirect.com/science/article/pii/S0041008X7380016X) (This wasn’t declassified until early ’70s)
- In the 1960’s, a similar drug called [MDA](https://en.wikipedia.org/wiki/3,4-Methylenedioxyamphetamine) was independently created and used a ton and was referred to as “The miracle drug of America”
  - A bit like and MDMA/LSD combo… a “softer version of LSD”
  - This was eventually made illegal in the Controlled Substances Act

- In the 1970s, [MDMA was “rediscovered”](https://en.wikipedia.org/wiki/Alexander_Shulgin#Independent_research) by [Sasha Shulgin](https://en.wikipedia.org/wiki/Alexander_Shulgin)

**The “rediscovery” of MDMA**

After the Controlled Substance Act…

- [Sasha Shulgin](https://en.wikipedia.org/wiki/Alexander_Shulgin) began trying to modify illegal drugs into something legal for therapeutic benefits
- He was looking for drugs for consciousness change
- Eventually, he resynthesized MDMA
- He began working with [Leo Zeff](https://en.wikipedia.org/wiki/Leo_Zeff) (leader of the underground psychedelic psychotherapy movement)
  - *First book that MAPS ever published*: [Secret Chief](https://www.amazon.com/Secret-Chief-Conversations-Underground-Psychedelic/dp/0966001915/ref=sr_1_2?keywords=Secret+Chief&qid=1564158005&s=books&sr=1-2)
  - *Next came*: [Secret Chief Revealed](https://www.amazon.com/Secret-Chief-Revealed-Myron-Stolaroff/dp/0966001966) (once Leo’s family was comfortable with us talking)

- From the mid 70s to the mid 80s, secretly, chemists at MIT were making MDMA for this underground therapy community
- And it was out of that then that it leaked, and Michael Clegg turned it into ecstasy

## Explaining the different “schedules” of drugs [30:55]

- In 1984, Rick started the non-profit [Earth Metabolic Design Lab](https://enacademic.com/dic.nsf/enwiki/11117969/Earth) to protect MDMA
- Also in 1984, the DEA moved to criminalize MDMA
- Rick then went to Washington and filed for a lawsuit to try to get a DEA Administrative Law Judge hearing

**Explaining the different schedules of drugs**

- **Schedule 1** is for drugs that have a high potential for abuse, no accepted safety under medical and, no currently accepted medical use
  - Example, heroin is a Schedule 1
  - Conversely, cocaine is not…it does have one very important medically valid use, which is it’s a remarkable local anesthetic in very vascular areas
  - \*Schedule 1 doesn’t mean that the government has determined that there is no medical use, it’s just there’s no currently accepted medical use (meaning no FDA approval)
- **Schedule 2** is high potential for abuse, but it has currently accepted safety under medical supervision and it’s got a currently accepted medical use.
  - Opioids fit into this category, fentanyl, oxycodone, OxyContin, cocaine as we discussed.
  - methamphetamine (for attention deficit disorder)
  - You can’t write a prescription that’s automatically renewed for a Schedule 2 drug. Every new prescription has to be written explicitly by your doctor
- **Schedule 3** is for drugs that have less than high potential for abuse
  - Less stringent on drug refills, etc.
- **Schedule 4**
- - Less stringent than schedule 3
- **Schedule 5** where you get over the counter drugs
  - but they’re still controlled in certain ways, but minimally

**Psychedelics as Schedule 1**

- Rick is trying get MDMA (and also psilocybin) moved out of being Schedule 1 drug
- Rick ultimately would like psychedelics to be de-scheduled completely

> “I think that there’s a fundamental human right that people have to explore their consciousness, particularly when you think about it as spiritual experiences. We should have this fundamental human right. I believe we should have a system of licensed legalization.”

## Rick’s fight to protect it for therapeutic uses, losing to the DEA despite winning in the court, the scientific community, and the media [38:25]

\*Check out this [full documentation related to the court case](https://www.maps.org/research-archive/dea-mdma/#emersched) provided by MAPS

- We got a hearing and we eventually triumphed. DEA Administrative Law Judge said that it should be Schedule 3
- However, the DEA Administrative Law Judge is simply there to make a *recommendation* to the agency
- When the agency didn’t agree with the Judge’s decision, Rick then sued them in the appeals court
- The DEA was shocked that Rick was suing because they only knew MDMA as the party drug
- But they showed up with doctors, with psychiatrists from Harvard Medical School, from all over, with testimony

Winning in the court of public opinion

- Not only was Rick winning in the court, he was winning the public’s opinion as well
- The first large media article about MDMA, [Brother David Steindl-Rast spoke on behalf of MDMA and said that a monk spends his whole life trying to cultivate the mental attitude that you can get from taking MDMA](https://www.latimes.com/archives/la-xpm-1985-05-27-mn-6278-story.html)
- In a Washington Post article [Rabbi Zalman Schachter compared MDMA to the sabbath](https://maps.org/research-archive/hmma/WashPost6.85.pdf)

The DEA freaked out and declared [MDMA illegal on an emergency basis](https://www.maps.org/research-archive/dea-mdma/pdf/0196.PDF)

- This was in the middle of 1985 while the hearings were still going on
- Why were they so afraid at that moment?
  - Well, because here was a drug that was being used by A LOT of people
  - BUT… it wasn’t causing the same kind of dangerous problems that the DEA’s narrative was saying

## The risks involved with taking MDMA [42:30]

**Potential risks with taking MDMA/ecstasy**

*Hyperthermia (over heating)*

- There are cases of people that have taken MDMA and danced in hot environments and got overheated, didn’t have enough fluid replacement (some have died)
- But MDMA in therapeutic settings doesn’t cause hyperthermia
- “There’s something about MDMA combining with lots of movement and dehydration that creates this trifecta.”

*Hyponatremia*

- people drink too much water they dilute their blood
- In therapy Rick uses fruit juices or things with electrolytes
- **Harm reduction tip**: It’s better to drink stuff with electrolytes than water if you’re doing MDMA

Difficult memories may come to the surface

- Some people do get unwanted emotional traumas come to the surface
- However, MDMA reduces activity in the amygdala, it [reduces your fear response to difficult emotions](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3122379/)
- This creates an environment where difficult things are allowed to come to their awareness

## An incredible MDMA-LSD case study: Rick’s story of healing a treatment-resistant PTSD patient in the 1980s [44:45]

**Rick’s TED Talk**: [The future of psychedelic-assisted psychotherapy](https://www.ted.com/talks/rick_doblin_the_future_of_psychedelic_assisted_psychotherapy?language=en)

**The first person Rick treated for severe PTSD**

- In 1984, Rick treated a woman who was traumatized by a violent sexual assault and kidnapping (and more)
- She had taken MDMA before in a non-therapeutic setting and it had made her even MORE suicidal
- Under the influence of MDMA and then also an MDMA-LSD combination, she was able to overcome her PTSD
- This is when Rick learned about directly working with someone and seeing that MDMA could be helpful for PTSD
- This woman’s name is [Marcela Ot’alora](https://marcelaotalorag.com/about-marcela/) (and she is now a licensed MDMA therapist herself)

⇒ Other examples of MDMA’s therapeutic power

- A [veteran with PTSD](https://www.stripes.com/feel-good-drug-ecstasy-one-step-closer-to-approval-as-ptsd-treatment-1.445361)… under the influence of MDMA, was able to relax in certain ways so that the pain in his back went away to a large degree

\*These experiences and stories were a key turning point in Rick’s life\*

Before treating Marcela…

- In spring of ‘84, Rick goes to Stan and [Christina Grof](https://www.esalen.org/page/christina-grof)’s workshop called the Spiritual Emergence Network
  - Many reasons why people break down, they were arguing that often people get pathologized and people get tranquilized or they get hospitalized
  - But what Stan Grof and others were saying is that …**This can be a spiritual emergence. It can be seen as a spiritual crisis that we’re resisting so it comes in dramatic ways, but the process… What’s trying to emerge is healthy. The process is not.**

So when treating Marcela…

- Rick realized that her first MDMA experience had unexpectedly brought traumatic experiences to the surface and “destabilized her”
- In the course of her treatment, Rick did the following:
- First treated her with MDMA in a therapeutic setting
- He brought female friends with him to create a “safe” environment for Marcela
- The first MDMA treatment was progress, lots of tears and emotions
- The next experience, Rick decided to do an LSD-MDMA combination

*⇒ Quick history on LSD as a therapy*

- The first use of a psychedelic for treating PTSD was done by a [Dutch psychiatrist Dr. Jan Bastiaans](https://www.maps.org/news-letters/v08n1/08118sne.html)
  - He did LSD for what he called “concentration camp syndrome”
- **Book**: [Shivittie: A Vision](https://www.amazon.com/Shivitti-Vision-Ka-Tzetnik-135633/dp/0062508709/ref=sr_1_1?keywords=Shivitti%3A+A+Vision&qid=1563891229&s=gateway&sr=8-1) by an Israeli holocaust writer Ka-Tzetnik 135633 (real name [Yehiel De-Nur](https://en.wikipedia.org/wiki/Yehiel_De-Nur))
  - He went through LSD therapy with Dr. Bastiaans

LSD-MDMA combo for Marcela

- Two weeks after the MDMA treatment, Rick decided to switch to LSD
- (It’s really important to integrate the experience before you’re ready to do it again)

> “During the LSD experience, what happened was that she started having this vision of a double sun. She was on a foreign planet and there was a double sun and she was baking to death. It was just terrifying to her. She was stuck. She couldn’t process it. It was just overwhelming fear. I suggested that she take half a dose of MDMA. A full dose is like 125 milligrams, so about 62 and a half. I thought the MDMA would soften the LSD and might help her process it. It turned out that’s what happened.”

The root of Marcela’s suffering

- Turns out that Marcela has been a victim of a date rape drug
- She carried tremendous self-loathing and blame that she trusted this man who betrayed her
- She wasn’t able to trust her own judgment from that moment on in her life
- The MDMA/LSD therapy helped her overcome that lack of trust in herself

The breakthrough

- Marcela was on the verge of suicide
- But after **only 2 sessions** she was okay
- This happened in 1984 and that was the breakthrough, says Rick

## How and why MDMA was declared illegal on an emergency basis going against the judge’s recommendation after hearing Rick’s compelling case (and multiple appeals) in court [57:15]

Knowing his purpose at age 18

- When Rick was 18 (1972) he felt like the contribution he could make to the world…
- using this rare gift from his family, the support from my family, this multigenerational process that permitted me to look at deeper threats, this freedom to choose what I thought would be the most strategic thing I could imagine…
- …which was helping people to realize that **we have more in common than separate, and that we’re all part of one big family, and that you shouldn’t dehumanize and kill**

> “That decision at age 18, and now that I’ve recently in November turned 65, it’s always made sense. That’s why I feel incredibly lucky and fortunate that something that I stumbled on at age 18 still at this other period of my life still make sense. It has made sense continually.”

**From counterculture criminal to legally fighting the system**

- At age 18, Rick’s self identity was a counterculture drug using criminal
- Then by the 80s…
- …the transition of being politically involved with a nonprofit in ’84 and then starting MAPS in ’86, “that also changed my attitude”
- “I was sort of outgrowing this idea of myself as counterculture and seeing that you could work within and that there are opportunities for reform from inside.”

Then…

- Rick then saw breakthroughs like his work with Marcela in 1984 (and seeing her continually get better overtime)
- In parallel he watched as the demonization of MDMA increased
- National Institute on Drug Abuse funded research and purported that MDMA caused neurotoxicity

MDMA was then criminalized by the DEA on an *emergency basis*

- The judge in ’86 said that it should be Schedule 3
- The DEA rejected those recommendations
- Rick then we sued in the appeals court
- Rick won the appeal twice in the appeals court
- However, the DEA rejected the judge’s recommendation

*⇒ Why did the DEA reject the recommendation?*

- The first rationale was that the DEA said they didn’t have the authority to reschedule, only the FDA did
- Yes, the Controlled Substances Act of 1970 clearly says either the **attorney general or the HHS secretary either could reschedule**, to make the drug into a medicine

*⇒ And the FDA sits under which branch?*

- [HHS](https://en.wikipedia.org/wiki/United_States_Department_of_Health_and_Human_Services)

*⇒ And the DEA sits under what?*

- The [attorney general](https://en.wikipedia.org/wiki/Attorney_general)

“The DEA lawyers, as I’ve learned over the decades, they don’t really care if their arguments are flawed, because they delay. So delay is the same as victory to them. So, if they put out a ruling that’s wrong, it can take you years to go through the appeals court. And so, **justice delayed is justice denied.** So they don’t care about their arguments, they just want to delay.”

*New standards*

- So the first argument they made was that they didn’t have the authority
- So the appeals court said, “Yes you do.”
- Then they came up with an eight-part standard, that they said, “*You have to meet these standards in order for us to reschedule*.”
- They also tried going to the FDA
- But the FDA was rejecting all the protocols
- So this was a period of time when the backlash against psychedelic research was so strong that the FDA was rejecting every single protocol
- The courts then rejected the DEA’s new “eight-part standard” as being too equivalent to the FDA
- Then the DEA came up with a “five-part standard”, which the court accepted (which is still essentially the FDA)
- Essentially, you still need [phase III studies](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Phase_III)

*Where does it stand today?*

- A few years ago, Congress passed a law
- It was always the case that if the FDA says a drug is a medicine, the DEA must reschedule, but they didn’t have a time limit
- So now they have **90 days** that they have to reschedule

## Rick’s decision to study politics to affect change from the inside out, and the recent progress being made with the DEA [1:07:00]

- Rick has spent his whole life on track to complete a clinical psych PhD
- However, he was rejected from all programs because he made it clear he wanted to do MDMA research and the programs didn’t want that (since it was illegal)
- Rick really wanted to do the science and research into MDMA
- However, politics were in the way
- Rick then came to the realization (with the help of marijuana which “gives me a way to think about things from a different perspective”) that he needed to study politics first

Kennedy School of Government

- Rick applied and got into a PhD program at the [John F. Kennedy School of Government](https://en.wikipedia.org/wiki/John_F._Kennedy_School_of_Government) at Harvard
- From there he was able to get into the highly competitive Presidential Management Internship (now the Presidential Management Fellowship)
- In 1990, Rick applied for a job with the “Pilot Drug Evaluation Staff” (a new group that regulated psychedelics–previously the FDA)
- They actually agreed to hire Rick but at the last minute the DEA said they would refuse to work with Rick since he sued them in the past

**Rick’s changing relationship with the DEA and police**

- I have started having some sympathy for the police and how difficult their job is
- And so actually, we have a senior retired DEA ([Tony Coulson](https://sai-dc.com/our-leaders-consultants/anthony-j-coulson/)) official who is now acting as a consultant for us
- The reason is because his son went into the military and has PTSD, and uses cannabis for his PTSD
- So that changed the Tony’s mind

Tony arranged Rick to speak at the [International Association of Chiefs of Police](https://www.theiacp.org/)

- A psychologist who works for the police heard the speech
- No he wants to go through Rick’s training
- And he has
- Rick is now meeting with his police chiefs about having police with trauma volunteer for Rick’s study
- Rick’s nephew is even a police officer

“*All of these ‘us and them’ barriers are dissolving.*”

In December 2017…

- Rick had a meeting with the DEA about “Expanded Access” (compassionate use of MDMA)
- Rick made sure to mention that any traumatized police officers are encouraged to volunteer for his studies

> “I just wanted them to know that this is for them too. That I did have that level of compassion for them. And I knew it would be awkward for me to say it, but I felt like I had to say that, that this is for them too. And now I understand more and more about how police are traumatized.”

## Debunking the exaggerated risks of MDMA (e.g., neurotoxicity) [1:16:30]

*When did you guys receive the Breakthrough Therapy designation?*

- Started MAPS in ’86
- From ’86 to ’92, we had five different protocols all rejected by the FDA
- Rick was proposing to the FDA clinical trials that would necessitate the FDA to create an exemption for the use of a Schedule 1 drug
- In 1992, Rick finally got permission for the [first phase I safety study in humans](https://www.ncbi.nlm.nih.gov/pubmed/8788485/) which published in 1996
- NOTE: Back in 1985, Rick funded a 28-day [animal toxicity studies in the dog and the rat](https://www.ncbi.nlm.nih.gov/pubmed/2887476)

**Debunked claims about harms of MDMA**

- Rick was proposing a study on cancer patients with anxiety ⇒ He knew about usefulness for PTSD but there was so much exaggerated concern about neurotoxicity that he felt like asking for PTSD would be more difficult

\*Check out a [FULL TIMELINE](https://www.maps.org/research-archive/mdma/studyresponse.html) of events that starts with [this publication in Science making erroneous claims about the dangers of MDMA](https://www.ncbi.nlm.nih.gov/pubmed/12351788) and ends with a [retraction of said paper](https://en.wikipedia.org/wiki/Retracted_article_on_dopaminergic_neurotoxicity_of_MDMA)

*-Claims:*

- Neurotoxicity
- Memory loss
- Parkinson-like symptoms
- Permanent damage to the serotonin system in the brain

⇒ “*A hundred percent debunked.*” says Rick

- It turns out that the claims were from [George Ricaurte](https://en.wikipedia.org/wiki/George_A._Ricaurte) and [Una McCann](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0013297/una-mccann) who were **funded by** [**NIDA**](https://www.drugabuse.gov/)
- From the middle ’80s to near the end of the ’90s, they were focused on MDMA supposedly hurting the serotonin system, and causing functional consequences of a serious nature, so that nobody should ever get MDMA even once

Going back to the 1960s…

- Both sides were exaggerating greatly
- An exaggeration of the risks by the prohibitionists, and a denial of research, and a denial of the benefits
- Then people like [Timothy Leary](https://en.wikipedia.org/wiki/Timothy_Leary) were greatly exaggerating the benefits

Rick’s plan for MAPS ⇒ Rick wanted **MAPS to be the expert on both benefits and risks\***

**The primate study that lead to the Science paper**

\*NOTE: Rick funded this study for George Ricaurte and this is the [study that turned into the Science paper suggesting MDMA neurotoxicity](https://www.ncbi.nlm.nih.gov/pubmed/12351788)

- Working with George Ricaurte
  - For the first 6 years after starting MAPS, Rick says George Ricaurte was his first alliance
  - George was technically working for NIDA (who was Rick’s opponent)
- Rick funded a primate study for George
  - The study found **no effect level for neurotoxicity** (i.e., NOEL, “No Effect Level”)
    - Turns out that 5 milligrams per kilogram in a primate given every two weeks for four months (so eight exposures), there was some nerve terminal degeneration in the primate
    - But at 2.5 milligrams per kilogram, there was no nerve terminal degeneration
- *So what did George publish?* ⇒ just the data on the 5 mg dose
  - That’s when Rick realized that this wasn’t about the science, there was a **political agenda**

**Does MDMA harm memory?**

- There **are** claims that there are neurocognitive consequences, supposedly memory, that could be identified in ecstasy users
  - But Rick says the ecstasy users were **methodologically confounded** because these users had done all sorts of other drugs in their lifetime

*Studies showing no such effects include…*

*–*[Mormon MDMA study](https://www.ncbi.nlm.nih.gov/pubmed/15276218/)

- These people had only done ecstasy
- They found virtually nothing
- There really is no strong evidence (no weak evidence even) about neurocognitive consequences in heavy ecstasy users

-Rick looking at MDMA psychotherapy patient

- “We’ve done neurocognitive studies in people in our therapy studies who only get MDMA a few times. There’s no evidence whatsoever.”

–[Spinal tap experiment](https://bibliography.maps.org/resources/download/10332)

- Rick even got over 30 people to volunteer for spinal taps
- It showed no harm to dopamine

**So now, the serotonin hypothesis is losing steam…** but even with all this information out there… George (and NIDA) went ahead and published the [Science paper](https://www.ncbi.nlm.nih.gov/pubmed/12351788)

*How could Science publish something so outrageous??*

- Turns out [Alan Leshner](https://en.wikipedia.org/wiki/Alan_I._Leshner), who was the head of NIDA, left to become the president of [AAAS](https://en.wikipedia.org/wiki/American_Association_for_the_Advancement_of_Science), the American Association for the Advancement of Science, **which publishes Science**
- *And also… There was an editorial in Science that talked about [MDMA as being Russian roulette for your brain](https://en.wikipedia.org/wiki/Retracted_article_on_dopaminergic_neurotoxicity_of_MDMA#Press_response_to_original_publication), by Alan Leshner*

⇒ Rick and [Michael Mithoefer](https://maps.org/news/media/1472-michael-mithoefer-m-d-principal-investigator) then wrote [a critical letter to the editor of Science](https://www.ncbi.nlm.nih.gov/pubmed/12791964)

- But they stuck to their results

**Mixing up the vial, they used meth instead of MDMA**

- NIDA then spent a year trying to replicate their results (unsuccessfully)
- They were having increasing problems in replicating their results
- And they later out of frustration, after they couldn’t replicate their results, took some of the animals that had died, did an tissue analysis, and had discovered that [**they had given the animals methamphetamine instead of MDMA**](https://www.nature.com/articles/425109a)
- They ended up [retracting the Science paper](https://en.wikipedia.org/wiki/Retracted_article_on_dopaminergic_neurotoxicity_of_MDMA) (in 2003/2004)

> “That was sort of the high watermark of the fear and paranoia about MDMA neurotoxicity.”

## Rick’s unbelievable ability to play the long game [1:28:45]

- So phase I study of MDMA shows no neurotoxicity
- Rick is also starting to win over the scientific community that there may be something here
- Next step, what is the indication for MDMA?

**Returning to PTSD**

- [Michael Mithoefer](https://maps.org/news/media/1472-michael-mithoefer-m-d-principal-investigator) approached Rick in 2000 about creating a clinic “somewhere in the world” where they could work with MDMA and LSD
- But Rick knew for sure that he DID NOT want to do that as it would undercut what he was trying to do with MAPS, which is to create long term, lasting change from within the system
- Rick knew that NOW was the time to work with the FDA and push MDMA as a therapy for PTSD
- Michael, an expert in PTSD, agreed to work with Rick

**Peter rants on Rick’s amazing maturity and ability to play the long game**:

> “Again, there are so many moments in your story, Rick, where I’m sort of struck by the maturity of the hippie. Like, You’re way smarter than anybody else. I mean, I wouldn’t have had that foresight … You just played the long game at every moment, and I just, I want to applaud you for that, as someone who … I just know personally, I just wouldn’t have had the discipline or the foresight to have played that long game over and over and over again, which was, this is about the highest integrity at the policy level. This is about the highest integrity at the scientific level. And it’s a hard decision because along the way, fewer people had access to something that you felt very strongly could help them. But it was one of those examples of if it means that a few hundred people or a few thousand people are denied this opportunity today, as much as that heartbreaking, this could mean millions of people can one day have access to this and we won’t sort of taint or undermine the rigor with which we get them there.”

## Which patients would not be good candidates for MDMA from a safety perspective? [1:34:30]

The most important thing is people with compromised hearts

- MDMA [increases blood pressure](https://www.ncbi.nlm.nih.gov/pubmed/27859780)
- But we work with people that have controlled hypertension
- However, nobody ever has a heart attack, claims Rick

People who are on a lot of other psychiatric medications

- we ask them all to taper off of them
- The SSRIs blunt the effects of MDMA

Seizures

- There’s a remote chance that MDMA [could trigger a seizure](https://www.ncbi.nlm.nih.gov/pubmed/17105933)
- Also, that seems to almost never happen
- So, we will not, at least initially, work with people who are epileptic

Schizophrenia

- Exclude people with schizophrenia
- MDMA could be very helpful with schizophrenia, but it needs a different container because the typical MDMA session is done under supervision, they spend the night after the MDMA session, and then they get more integrative psychotherapy the next day, but then they go home
  - So, if somebody was schizophrenic, we would want **a longer containment window**

Bipolar ⇒ I don’t think MDMA is likely to be helpful for people with bipolar

## How MDMA is different from all other psychedelics, the importance of the setting, and Peter’s experiences with MDMA [1:36:30]

MDMA can have a vastly different effect based on the setting

- At a party scene… many people report feeling wonderful, happy, and social
- In a therapeutic setting…
  - Very emotional
  - Endless river of tears
  - Requires a lot of processing afterwards. It requires further discussion, journaling, these sorts of things

*What is it about creating that therapeutic setting that transforms something that is arguably one of the most feel good drugs at a party into a drug that is healing the deepest emotional wounds that people have?*

- Rick says your intentions matter as to what you are there to accomplish
- Also, it’s whether your focus is external or internal

> “The best way to understand these things are they’re just tools and they’re not inherently therapeutic or inherently recreational or inherently dangerous or inherently safe. These are tools and how they’re used makes all the difference. So, when you take it at a party and you’re externally focused and you’re dancing and you’re talking to other people, people still process a lot of important stuff and people have insights and can make therapeutic process. Even in recreational settings, they feel connected to this whole group. They feel less isolated. A lot of good can come from recreational settings, but in general, people who use it in a recreational setting say they want to have the good slice of experiences and if something is difficult or painful, that’s not what they’re looking for. **The thing about MDMA that’s different from the classic psychedelics is you can negotiate with the content a little bit.**”

MDMA compared to other psychedelics

- You have much more control of the direction of the experience
- This is much different than say, [psilocybin](https://en.wikipedia.org/wiki/Psilocybin), [ayahuasca](https://en.wikipedia.org/wiki/Ayahuasca), and LSD, for example
  - The essence of doing the classic psychedelics is the art of surrender, it’s the ego dissolution

With MDMA, you can decide not to let the bad stuff come into your thoughts

- In recreational settings, people will almost always choose to push away painful feelings
- It’s not until they are in a safe, therapeutic setting will they allow those inward focused thoughts and difficult feelings out so that they can deal with them
- “*this idea of welcoming the conflict instead of trying to just have the happy slice is what makes it a difference*”

## MDMA studies which lead to the crucial designation as a “breakthrough therapy” [1:40:30]

*What is the purpose of phase II studies?* ⇒ To figure out who is your population, and determine what exactly is your [indication](https://en.wikipedia.org/wiki/Indication_(medicine)), and to prepare for a [phase III study](https://en.wikipedia.org/wiki/Phases_of_clinical_research#Phase_III)

- From 2000-2016, Rick did [6 phase II pilot studies](https://www.ncbi.nlm.nih.gov/pubmed/31065731)
- Studies were done in Israel, Canada, Switzerland, and the United States

*The purpose of phase III studies ⇒* To show safety, and [**efficacy**](https://en.wikipedia.org/wiki/Efficacy) for a particular [indication](https://en.wikipedia.org/wiki/Indication_(medicine))

Getting [breakthrough therapy designation](https://en.wikipedia.org/wiki/Breakthrough_therapy)

- In Nov. 2016, the FDA finally approved a phase III study
- What happens is once you end up getting permission to go to phase III… *most* pharmaceutical companies go to phase three)
- But there’s a program called **special protocol assessment**
  - Where you can voluntarily engage with FDA, where you negotiate every aspect of the phase three design, plus all the other information that they want to see
  - And if you come to agreement, you get an agreement letter, that means that the FDA is legally bound to approve the drug if you get statistically significant evidence of efficacy using this design and if no new safety problems come up
- Rick applied for special protocol assessment
- And then a few weeks later **MAPS got official word that** [**MDMA got a breakthrough therapy designation**](https://maps.org/news/media/6786-press-release-fda-grants-breakthrough-therapy-designation-for-mdma-assisted-psychotherapy-for-ptsd,-agrees-on-special-protocol-assessment-for-phase-3-trials)

**More about breakthrough therapy designation**:

> “Breakthrough therapy designation is for the most promising drugs. And if you get this breakthrough therapy designation, the FDA partners with you to try and make it into a medicine. . .And this is pegged to an indication in this case because the indication of PTSD has no other option that is appearing to have any medical efficacy. So, it’s the absence of other treatments, a large group of treatment resistant people and breakthrough therapy we were able to get, so it’s the most important program that the FDA has. And that was the sign that now we had reached this place of legitimacy 30 years after we had started Maps.”

**Rick is trying to get the first ever FDA approved drug in combination with a specific therapy**

- The FDA is actually learning from and with us about how to regulate psychotherapy, which they don’t actually have the authority to regulate psychotherapy
- But we’ve came to them and said, “The only people that we think should be directly treating patients if this drug is approved is people that have learned the therapy as well as the drug.”
- And so, that’s what the FDA is agreed so that *everybody who will be prescribing it and will be treating patients has to go through our training program*

[**Upcoming phase III studies**](https://maps.org/research/mdma/ptsd/phase3)

- Rick is planning two separate phase III studies
- Each will have 100 participants
- Hopefully, **MDMA could be approved for PTSD by the end of 2021**

## How someone with PTSD can get treated now through “expanded access for compassionate use” [1:46:00]

**\*People with PTSD may not have to wait until 2021/2022\***

**Expanded access for compassionate use**

- The FDA has a program called expanded access, which is compassionate use
- This program says that if you have a disease that nothing has helped for you and there’s a drug being studied for that disease and if the pharmaceutical company agrees, they will set up this compassionate use program where you can have access to the drug before it’s approved while phase three is still going on

**How it works**:

- Because it’s a controlled substance, only physicians will be able to get scheduled and licensed as to work
- There’ll be therapists working with the physicians
- People have to accept the risk and they have to pay for it themselves because the FDA doesn’t use the data to approve it so the pharmaceutical company isn’t going to pay to have all these people treated
- Rick is training doctors and therapists right now for expanded access patients

*Who can become certified to administer MDMA therapy?*

- MAPS has a training system and the model is a male, female co-therapy team
- One of them needs to be licensed as a therapist or a psychiatrist
- But the other one doesn’t… it can be a student getting a license, can be a nurse, can be social worker, can be somebody without a license
- What we’re saying is that the two person team works better than one person. It’s not twice as good, but most people that are traumatized don’t develop PTSD. Those that do tend to have a history of trauma before them, often going to childhood and attachment disorders. And so, having a well functioning male/female team as people go through their traumas can recreate sort of a loving kind of a situation that they didn’t have when they were young
- But we don’t want to make it so that it’s twice as expensive. So, the idea will eventually be one person licensed therapists, the other is a student working for free to get their hours or working for lower costs or something like that.
- We are now opening up the training to people that will set up expanded access sites
- The ideal cities are where we don’t have phase III sites, but where there’s a lot of people that have PTSD

***How does someone with PTSD get treatment before 2021/2022?***

**1** [Apply for expanded access for compassionate use](https://www.fda.gov/news-events/expanded-access/expanded-access-information-patients)

- By the end of this year there will be psychedelic clinics opening around the country
- To get into expanded access you have to have treatment resistant PTSD
  - It means nothing else worked for you
- Everyone who qualifies will get treatment with active MDMA

**2** [Apply for a phase III trial](https://mdmaptsd.org/?pk_campaign=2019-07-Newsletter-July-Web&pk_kwd=text-phase3-visitmdmaptsd)

- Identify a place where there’s an ongoing phase III trial because you may be a candidate

*Does everybody in phase III get treated? Or is there a placebo group?*

- Well, in phase III, there has to be a placebo… It’s a controlled study.
- There’s a chance you’ll get the therapy without the MDMA
- You either get therapy without MDMA or therapy with active MDMA
- \***NOTE\***: *In the phase II pilot studies, it was found that 23% of the people that got the therapy without active MDMA no longer had PTSD two months after the last experimental session*.
- **However**, everybody that gets randomized to the control group, once the study is over, will get free treatment with MDMA

## Rick’s ultimate goal and long term vision for psychedelic clinics [1:50:30]

**Rick’s future vision for psychedelics**:

“The long-term vision is that these psychedelic clinics that we’re opening initially become places where people can go for therapy for MDMA or ketamine or psilocybin. But eventually we hope that they become sites of initiation where people who don’t have a clinical diagnosis can go for psychedelic therapy for personal growth or for couples therapy or for a mystical experience.

And then if it goes well in your first experience with LSD or MDMA or psilocybin, then you get a license to go buy it and do it on your own.

The future is a system of licensed legalization where people have access outside of religion and outside of medicine, but that there’s also these opportunities for medical use that insurance would pay for if you have certain diagnoses.”

**The future of LSD**:

“It all depends on resources. We’re anticipating that it’s somewhere in the neighborhood of $40 million to make a psychedelic drug into a medicine. . .In the history of Maps, we spent another $10 million on the phase two studies. We’ve spent loads of money on a lot of the political work trying to get permission, so that isn’t going to be necessary anymore.

So, if some of these billionaires out there that have the resources, and if they wanted to make LSD into a medicine [they could make it happen].”

**Rick has created a playbook for legalizing psychedelics**:

Peter says, “What you’ve done is created a playbook. I mean in many ways MDMA is far in a way the biggest lift because you had to do everything from soup to nuts, including the advocacy. Assuming MDMA is approved in 2021, there is now a playbook for how to do this with other agents and psilocybin of course is right on the heels.”

## Trip of Compassion documentary, and how psychedelics could change the world [1:52:30]

> “I’m not convinced that there is a manmade molecule that is more important than MDMA.” —Peter Attia

**Must watch documentary**: [A Trip of Compassion](https://vimeo.com/ondemand/tripofcompassion)

Trip of Compassion is about three of the PTSD patients that are in the Israeli study

- Peter’s take…
  - “I can’t think of many better uses of an hour and a half of your time.”
  - “I’m not convinced that there is a manmade molecule that is more important than MDMA.”
  - “It’s hard to imagine a world with conflict if everybody had the opportunity to experience this drug [in a supportive setting].”

*Here’s the trailer*:

**Book rec**: [The Body Keeps the Score](https://www.amazon.com/Body-Keeps-Score-Healing-Trauma/dp/0143127748) by [Bessel van der Kolk](https://en.wikipedia.org/wiki/Bessel_van_der_Kolk) (psychiatrist & PTSD expert and principal investigator of the Boston site for MAPS)

*Changing the world:*

> “[MDMA] also heals multi-generational trauma that we have conflicts that are passed on through epigenetics from generation to generation and they can keep conflicts going for thousands of years. We can break those cycles within one generation, within one session sometimes. I think that’s the real hope is how can we move from this weight of trauma that has been plaguing humanity for thousands of years in our murderous nature and how do we evolve from that to appreciate the other rather than being scared by the other and to not have to define ourselves by who we’re not, but how we’re all more connected and celebrate differences rather than be scared of them.”

§

### **NOTE FROM PETER: *This was technically the end of my interview with Rick. However, as I mentioned in the intro, we moved the first 75 minutes or so and we bumped it to what you are about to hear now. This section dives really deep into Rick’s background, his motivation for doing what he’s doing and basically what shaped Rick into becoming the complete and utter force of nature that he is.***

§

## Rick’s early life: Resisting the draft, his feeling of wanting to change the world, and his profound experiences with LSD and other psychedelics [1:55:30]

**Resisting the draft**

- Rick started college in 1971, and dropped out in 1972
- At the time, Rick was a “draft resistor” for Vietnam and believed he would likely be going to jail
- He was inspired by Tolstoy, Thoreau, Emerson, Gandhi, and Martin Luther King
- He did not go to jail after the presidential pardon by President Carter

**Rick’s foray into LSD**

He knew at that point he wanted to study LSD and become an LSD therapist

- “I felt that when I learned from LSD that I was unbalanced intellectually and emotionally. I was overdeveloped intellectually and underdeveloped emotionally and spiritually, and the world I felt was the same.”
- “But at this point I had discovered LSD and was seeing that this move beyond ego, this sense of spiritual connection, this sense of oneness, the sense of unity struck me as having incredible political implications.”
- He felt so strongly about these experiences that they could be “an antidote towards genocide, towards tribalism, fundamentalism towards fear of the other.”

**The feeling that he was in a position to help the world**

- Rick felt lucky to grow up in a good family with strong support systems
- He was affected by learning about the holocaust and the realization that he just happened to be born into a world that was kind to him (compared to so many others)
- He felt this allow him to try to tackle the “big problems” like the threat of nuclear annihilation, future prejudice
- He was also growing up during the Cuban missile crisis as well as the growing tensions with Russia

**Rick’s summer in Russia**

- Rick decided to study Russian in high school to learn about “the other”
- Rick spent the summer after his junior year in high school in Russia learning the language

> “It was just an incredible eye-opener for me to see the other . . . I started realizing these are conflicts between countries but the people aren’t really necessarily hating each other. Political systems, political leaders in conflict.”

**Book that inspired Rick**: [One Flew Over the Cuckoo’s Nest](https://www.amazon.com/One-Flew-Over-Cuckoos-Nest/dp/0451163966) by [Ken Kesey](https://en.wikipedia.org/wiki/Ken_Kesey)

- He wrote part of this book while under the influence of LSD
- He started to realize that he bought into the “propaganda” that LSD was terrible and deadly

**College life: Profound experiences with psychedelics**

- After high school, Rick enrolled in a very unique university called [New College of Florida](https://en.wikipedia.org/wiki/New_College_of_Florida)
  - It was designed as kind of an antidote to traditional education
  - The fundamental principle was that the students curiosity is the most important thing
  - There were no “grades”
  - The college was very open to (encouraged even) the use of psychedelics for personal growth
  - Rick started to experiment with LSD and found it very profound and he wanted to know more

Rick discovered the book: [Programming and Metaprogramming in the Human Biocomputer](https://www.amazon.com/Programming-Metaprogramming-Human-Biocomputer-Experiments/dp/0692217894) by John Lilly

- “*This was an incredible book about LSD to go into the unconscious*”
- From there, Rick began doing large doses of LSD in isolation environments and he started having a lot of problems with his LSD trips
- He was also experimenting (and openly selling) [mescaline](https://en.wikipedia.org/wiki/Mescaline) on campus

## The history of LSD and psilocybin, and the CIA’s interest in psychedelics [2:10:45]

**History of LSD**

*The discovery of LSD*

- LSD is a completely synthesized molecule, it doesn’t exist in nature
- [Albert Hofmann](https://en.wikipedia.org/wiki/Albert_Hofmann) was the [Sandoz](https://www.sandoz.com/) (now called [Novartis](https://www.novartis.com/)) chemist who [first synthesized LSD](https://en.wikipedia.org/wiki/Albert_Hofmann#Discovery_of_LSD) in 1938
- He was looking for drugs for stopping postpartum bleeding
- They gave it to a bunch of animals and found nothing interesting
- And in the height of World War Two in 1943 after Albert had finished some other bit of work, he had what he called a peculiar pre-sentiment that this drug that had been studied and abandoned might have some potential
- He ended up re-synthesizing LSD on April of 1943
- In the process, he accidentally ingested a tiny bit of LSD and he was seeing colors and visions that lasted for a couple of hours and went away, but it was a weird kind of experience
- So on April 19th, 1943 he did a planned experiment where he would purposefully take 250 micrograms
- The experience got stronger and stronger and stronger and he was starting to lose his normal frame of reference and worrying that he had poisoned himself, that he was going to die and he started feeling like he was going to die
- And so he ended up deciding that he would leave the laboratory and he would go home and so he rode his bicycle home
- April 19th is now known as “[Bicycle Day](https://en.wikipedia.org/wiki/History_of_lysergic_acid_diethylamide#%22Bicycle_Day%22)”
- And he goes through this whole existential crisis, but in the end he actually doesn’t die and then he has spiritual experiences
- **Book about his experiences**: [LSD: My Problem Child](https://www.amazon.com/LSD-Problem-Child-Reflections-Mysticism/dp/0979862221)

*Next, they started trying to figure out what to do with this incredible drug*

- The first research in the United States was in 1949, at Harvard
- In the mid 50s, they sent it to Czech Republic, that’s where [Stan Grof](https://en.wikipedia.org/wiki/Stanislav_Grof) ended up using it
- Military uses…
  - the military began this whole effort to study mind control drugs and what they called non-lethal incapacitants
  - And it became tangled up in the CIA, they had a project called [Project MKUltra](https://en.wikipedia.org/wiki/Project_MKUltra)
  - They thought it would be good for surreptitiously dosing world leaders and making them embarrassed when they’re giving speeches or different things, incapacitating a whole group of army people.
  - They tried to see if they could do it in aerosol sprays

*So it had this dual tract*:

- 1) Military applications which were mostly kept secret
- 2) therapeutic, or temporary voyage to insanity

**Spiritual aspect and psychotherapy**

- But more people who took it realized that it wasn’t temporary insanity
- There was this spiritual aspect to it
- In psychotherapy, it was being used for alcoholism and heroin addiction in the 50s and in the 60s.
- [Bill Wilson](https://en.wikipedia.org/wiki/Bill_W.), who started AA, actually tried LSD and thought it had tremendous potential for treatment of alcoholism
- And it helps the spiritual sense and it also brings to the surface things that people have suppressed,
- So it’s good for psychotherapy and then it’s also good for building sources of strength from these kind of spiritual experiences

**Psilocybin**

- [CIA funded some expeditions to Mexico](https://en.wikipedia.org/wiki/R._Gordon_Wasson#Ethnomycology) with [Gordon Wasson](https://en.wikipedia.org/wiki/R._Gordon_Wasson) in 1957/58 to search for mushrooms for other drugs that might be psychedelic
- Note: The word ‘psychedelic’ didn’t get developed until 1958 by [Humphry Osmond when he wrote this poem to Aldous Huxley](https://www.amazon.com/Psychedelic-Prophets-McGill-Queens-Associated-Services/dp/0773555064)
- FUN FACT: [The Doors](https://en.wikipedia.org/wiki/The_Doors) (the band) got their name from the book [The Doors of Perception](https://www.amazon.com/Doors-Perception-Aldous-Huxley/dp/0060801719) by Aldous Huxley
- Yeah, and so that was from [Aldous Huxley](https://en.wikipedia.org/wiki/Aldous_Huxley)‘s discussion about his mescaline experiences, he’s writing about that.
- The CIA was able to find mushrooms that were used as spiritual tools by the Mazatec Indians
- They sent the mushrooms to [Albert Hofmann](https://en.wikipedia.org/wiki/Albert_Hofmann)
- Albert was able to [figure out that the active ingredient was psilocybin](https://en.wikipedia.org/wiki/Albert_Hofmann#Further_research)
- The reason he said that he was able to figure it out and nobody else was is that he was willing to drink the different fractions and compare them to other psychedelic experiences he had previously

**Morning glory seeds**

- So 15 years after he discovered LSD in 1943, Albert was the one who isolated psilocybin
- And shortly after that there was this whole effort to understand other sources in nature of psychedelics
- And it turns out that [Morning Glory seeds](https://en.wikipedia.org/wiki/Morning_glory) have also been used for psychedelic properties
- Albert came to find that Morning Glory seeds have LSA, which is Lysergic Acid Amide
- LSD is Lysergic Acid Diethylamide
- Even though LSD came from [ergot](https://en.wikipedia.org/wiki/Ergot) and was modified so that it doesn’t appear in nature…
- …decades later Albert was able to figure out that there is something in nature that’s quite similar to LSD
- Not exactly the same… it is more powerful, more effective, people have had a tradition of Morning Glory Seeds for getting high in different ways

**Book rec about the history of psychedelics**: [How To Change Your Mind](https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225) by [Michael Pollan](https://en.wikipedia.org/wiki/Michael_Pollan)

## Timothy Leary and the Good Friday Experiment [2:22:00]

**Timothy Leary**

- Leary was an incredible psychologist who had written a book called [The Interpersonal Diagnosis of Personality](https://www.amazon.com/Interpersonal-Diagnosis-Personality-Functional-Methodology/dp/1592447767)
- It was heralded as brilliant, it was the most important psychology book of the year of like ‘1958/59
- He was working for Kaiser out in California as a Kaiser psychologist
- He was introduced to mushrooms by [Frank Barron](https://en.wikipedia.org/wiki/Frank_Barron_(psychologist))
- Leary was so influenced by his experience with mushrooms that he thought he learned more from them than all of his teachings in school

**Two famous studies by Leary**

1. [Good Friday Experiment](https://en.wikipedia.org/wiki/Marsh_Chapel_Experiment)
2. [Concord Prison Experiment](https://en.wikipedia.org/wiki/Concord_Prison_Experiment)

**The Good Friday Experiment**

- Done by [Walter Pahnke](https://en.wikipedia.org/wiki/Walter_Pahnke), who was a doctor and a minister, did this for a PhD as well as by Tim Leary who was his PhD thesis adviser
- They decided to look scientifically at whether psychedelics really could produce spiritual, mystical experiences (Also, whether those experiences were similar, identical, pseudo, whatever)
- And so, the first thing Walter Pahnke did was he spent a year developing a series of questionnaires that were independent of any particular religious symbols or any particular religious systems
- The basis of a mythical experience is a sense of unity and you get this from all different religions about everything’s one, everything’s united, everything is somehow one big system

*The design of the study*

- They took a group of 20 Christian Divinity students
- They all got a pill
- half got placebo ([Niacin](https://en.wikipedia.org/wiki/Niacin))
- half got psilocybin
- They were divided these people into five groups of four
- Two experimenters were assigned to each group of four
- And the experimenters also took these pills and one of the experimenters would get the placebo, one would get the psilocybin
- These were people like [Tim Leary](https://en.wikipedia.org/wiki/Timothy_Leary), [Ralph Metzner](https://en.wikipedia.org/wiki/Ralph_Metzner), [Richard Alpert](https://en.wikipedia.org/wiki/Ram_Dass) (Ram Dass), [Huston Smith](https://en.wikipedia.org/wiki/Huston_Smith), incredible people who were experts in the philosophy of religion and psychology and they were trying to break down the us/them, experimenter/subject dichotomies and that’s why they had the experimenters also took the pills

\*[Listen to the actual service heard by the study participants given by Reverend Howard Thurman](https://maps.org/news/multimedia-library/138-1962-good-friday-experiment)\*

\*Quick tangent… **Best way to do a double blind experiment with MDMA:**

**-Originally**, in Rick’s dissertation…

- The conclusion I came to was that the best way to do a double-blind experiment with psychedelics was to use low doses of the psychedelic versus full doses
- And that way everyone has the same demand characteristics
- they all think they’re getting the test drug, they just don’t know what dose
- and all the experimenters know everybody’s getting the drug.
- And I thought the real challenge was going to be to find the level of the low dose.
- Well, it has to be high enough so you would have enough confusion between the full dose but not so high that you get all the therapeutic potential.
- So I thought, you get a little bit of the therapeutic potential but you don’t want to get too much because the more therapeutic potential you got, the more difficult it would be to find differences between the two groups

**-However**…

- In his work with MDMA
- Rick looked at 0 milligrams, 25 milligrams, 30 milligrams, 40 milligrams, 50 milligrams, 75, 100, 125 and 150.
- What we discovered was the low doses did produce blinding
- But what I didn’t anticipate was that **the low doses actually made people uncomfortable**, it activated them without reducing the fear
- So therefore the therapeutic effect of “just the therapy” was compromised
- People who had therapy without any MDMA **did better** than people that had therapy with low dose MDMA (low dose being 25, 30, and 40 milligrams)
- The ideal therapeutic dose of MDMA is 75 milligrams

*–For his phase III studies*…

- Rick proposed to the FDA to do therapy with inactive placebo versus therapy with full dose MDMA
- And FDA accepted that and so has EMA (European Medicines Agency)

**Back to the Good Friday Experiment…**

What they discovered

- First they realized that the double-blind ([niacin](https://en.wikipedia.org/wiki/Niacin)) did not work
  - People were initially confused
  - But after a while this niacin flush wears off and then you’ve got these other people seeing colors and seeing sparkles in the candle flames and having all these unusual experiences. So everybody was clear by the end of the experiment who had the niacin, who had the psilocybin
- At the six month follow-up, they showed that people had reported long-term positive benefits
  - Note, the results were compromised because it was effectively wasn’t blinded
    - However, Rick did a [follow up study](https://www.erowid.org/plants/mushrooms/mushrooms_journal2.pdf) that showed a similar effect

## Rick’s follow up study to the Good Friday Experiment, and his criticism (and praise) of Tim Leary [2:33:50]

[**Rick’s Good Friday follow up experiment**](https://web.archive.org/web/20100128015718/https://druglibrary.org/schaffer/lsd/doblin.htm)

- 25 years later, Rick decided to try to track down the participants of this study
- However, the records were basically gone and nobody was cooperating with his efforts
- This was during the escalation of the drug war especially against psychedelics
- The Harvard library didn’t even have the study available, it was being hidden essentially
- Rick tracked down an alumni book and wrote over 300 letters to former students asking if they were part of the study
- After several years, Rick was able to track down 19 of the 20 participants
- Rick flew all over the country to interview these people in person

“*What I discovered was shocking to me…*”

- At a point where every cultural indication would be that these persons should deny the value of the psychedelic experience (massive escalation of the drug war, Republicans in charge, people going to jail for all this kind of stuff) … everybody who had the psilocybin experience (except for one person), **said that they had a mystical experience**
- Compared to a non-drug mystical experience, they said that psychedelic mystical experiences were more oscillating between fear and unitive experiences, and that they were deeper in some ways, but were more difficult to manage
- But they validated the importance of the experience.

*Vivid recollection*

- Everybody who had psilocybin could remember with crystal clarity some moments of their psychedelic experience
- Something about psychedelics imprint on memory
- You don’t remember everything, but some portions of it are just indelible
- And they validated that they were genuine.

“*I felt like I discovered the clue to the ’60s by doing these interviews…*”

- They talked about how that unitive experience motivated them in different ways to get involved with social justice struggles (civil rights, women’s rights, environmental movement, etc.)
- They felt that there was this connection between this spiritual experience.
- They lost a certain fear of death, so they were more willing to take risks in their lives.
- They learned the appreciation of the moment.
- They didn’t go for this idea that heaven is later after you die… it’s more they wanted to create it on Earth.
- So they used that psychedelic experience to be involved in challenging the status quo, to try to make it a more spiritual, loving world.

> “I felt that that’s where I really learned that the crackdown against the ’60s was not because of psychedelics gone wrong, but because of **psychedelics gone right**.”

*The placebo group*

- The placebo people had a hard time remembering what was going on (i.e., not as vivid as the drug group)
- Some of them were so upset by what they saw in the others that they were disoriented (One person went up and tried to be the preacher)
- It scared them and they decided never to do psychedelics
- Others decided that they were so inspired by what they saw that they wanted to do psychedelics

*One person got a tranquilizer*

- One person who had received the psilocybin had been listening to [Reverend Howard Thurman](https://en.wikipedia.org/wiki/Howard_Thurman) telling people that you need to tell people that there is a man on the cross… “*This is your obligation.*”
- One person decided he was going to tell the president of the university RIGHT THEN
- So he went outside and he was wandering down the road going towards the president
- Timothy Leary and Huston Smith and they went after him and needed to give him a shot of Thorazine, a tranquilizer, which was used at this time when people had difficult trips sometimes
- (NOTE: We would not do that today. It freezes the struggles in place. It’s not helpful at all. Better to just wait it out even if it’s terrible, because then at least you don’t get the message you can’t handle it. If you wait it out, at least you survived.)
- This part of the study was completely missing from any of the reports about the study… “***which I considered to be another key to the ’60s, in that Leary and the advocates underestimated the risks and exaggerated the benefits.***”
- It was reported in Time Magazine that everybody in the Good Friday Experiment who got the psilocybin had a mystical experience… *which was not the case*

**Praise and criticism for Tim Leary**

“*This was the height of scientific irresponsibility.*”

- Leary was irresponsible in a lot of different ways and was also delighted to be a rebel and to be against the system  and this identification as the “counterculture” was a self-fulfilling, doomed prophecy
- He saw that the propaganda for the other side, the negative exaggerations of the risks, that he justified in his own mind that he could exaggerate on the other side
- I do think he deserves a lot of criticism for what he said, but he was very much about thinking for yourself, questioning authority, challenging the system, all of which we need more of.”

**Rick’s biggest criticism of Leary**:

“What I fault him for the most was misrepresenting science. Science is holy in itself, meaning that it’s sacred. There’s something sacred about our quest for knowledge through our bias. . .The whole purpose of the double blind is to eliminate or reduce experimenter bias. We see what we want to see. So how do we actually see what’s really there. I think that’s the beauty, the holiness of science. So when Tim misrepresented the scientific findings he had, that I thought was a tremendous violation. Being a cheerleader against the drug war and for consciousness, I think he deserves a lot of credit for that. I think where he’s also wrapped up in deserving criticism is that he underestimated the risks and overestimated the benefits. So you take this drug, you get enlightened, you’re smarter than everybody else, and now you’re part of this new counterculture and all you have to do is drop the pill. That’s wrong. People don’t always have these good experiences. People do get messed up and end up worse off.”

**Final thoughts on Ricks Good Friday follow up experiment**

- What I discovered during the Good Friday Experiment follow-up was that there had been this overhyping of the results and also this hiding of a problem.
- But overall, my conclusion was that the experiment was essentially validated
  - People did have mystical experiences
  - They had subsequent experiences in their lives that were without drugs
  - Mystical experiences that they then said that made them think that the psilocybin mystical experience was legitimate
  - And it had positive benefits in their lives and had long-term impacts

## Peter’s experience taking psilocybin [2:44:30]

**Peter says the following about his experience with psilocybin**:

“I don’t think I’ve ever been under the influence of psilocybin that I can’t look back and recall with just the most vivid detail some aspects of it, positive and negative. Some incredibly positive, deeply emotional, moving beyond words and also at times … incredibly frightening with an incredible feeling of despair, but with a **degree of vividness** that I can’t remember many things.”

*What does Peter think causes this vividness?*

“I suspect that if you look at parts of the brain, the hippocampus, where we imprint memory, there must be something about these molecules that enable … during periods of the time … Because that’s a thing, it’s such a non-linear experience. It’s sort of oscillating.

But there must be moments in there where there’s an overlap. I’m putting my hands like a … You have to get an alignment of a couple of things. One, the experience itself is profound enough and two … So that’s the seed. Then the soil itself, at that moment, neurologically is fertile enough to take that seed and that produces this plant. The metaphor is this memory that is never going away.

What’s also interesting is I can still describe in some cases the feeling that accompanied that vision or that hallucination and what it connected me to, someone I cared about, or something like that. So that to me is a very powerful part of your follow-up.

Whereas, I can completely imagine that if you were getting the placebo … I mean I’ve taken niacin. I know what it feels like. It’s miserably actually if you take a high enough dose. The flush is real. I mean there’s no denying it. But if you asked me to recall a niacin flush I had two years ago, let alone 20 years ago, I’d be hard pressed to remember anything about it. So the sensory experience alone is not enough. “

## The Concord Prison Experiment, and Rick’s follow up study 34 years later [2:47:00]

[Concord Prison Experiment](https://en.wikipedia.org/wiki/Concord_Prison_Experiment)

- Tim Leary recognized that with the Good Friday Experiment you’re relying on people to tell you what happened to them, so that’s **subjective** reports
- He wanted to try to find an **objective** way to talk about the benefits of psychedelics.
- This lead him to think about prisoners at the Concord prison
- Leary thought that maybe a pro-social experience, mystical experience from psilocybin might reduce their recidivism (the objective measure of benefit)

*The design*

- 36 prisoners were treated
- 2 treatments per prisoner

*The control group*

- The control group was a base rate study of everybody that had been released from prison in the year before they did this. Then they tracked them. So they had this base rate study and then they compared against the base rate.

*Flaws in the study*

  1 **Selection bias**: People who are motivated to volunteer for this experiment might be more likely to want to stay out of prison…maybe they’re more motivated to get better

  2 **Performance bias**: The fact that they’re getting some positive attention while they’re there

- Today, you would have a control arm with an intervention that is without psilocybin, but included counseling, positive therapy, etc.
- You’re not going to be able to blind people, but at least you can try to identify that if there is a benefit in the psilocybin group, it’s much more likely to be from the psilocybin than it is from selection bias or performance bias.

**Reported results**

- They ended up saying though was this was one of the most successful experiments in the history of psychedelics showing benefit.

*What was the difference in recidivism between those two groups?*

- Well, it was substantial. . .It was a terrific, positive experiment (Or so it seemed)

**Rick’s follow up study:** [Dr. Leary Concord Prison Experiment: A 34-Year Follow Up Study](https://maps.org/research-archive/1998_Doblin_ConcordPrisonFollow-up.pdf)

- Rick was able to see the arrest records of the prisoner in that experiment
- “*The more that I looked into it, one by one and tracked people, the more I started realizing that there had been something amiss.*”
- It didn’t look like it was really working.
- The records showed the prisoners were, in fact, getting arrested again
- There was some tricks in the way that Leary and Ralph Metzner reported the data
- Basically, **it was scientific fraud** (not by Ralph but more by Tim Leary)

*Turns out…*

- The base rate study looked at 2 years following release from prison
- The study participants were followed for 10 months
- So, obviously, the more time that goes by, the more likely you are to be arrested so it was not an apples to apples comparison
- Additionally, Tim claimed that the prisoners who did get arrested, were arrested for very minor infractions (like parole violations)… but Rick found that this was not the case and in fact many arrests were due to new crimes

“*So what I concluded …* ”

- Just having a spiritual experience, which many of these people did have in prison, is not enough… you need to **integrate the experience and have support** afterwards
- This was an experiment that should be repeated with the **combination of the experience and the support afterwards**
- It showed promise, but what I really felt also was that this was Leary violating something that was sacred, which was the scientific data and presenting it in a wrong way

§

## Selected Links / Related Material

**Rick’s non-profit**: [Multidisciplinary Association for Psychedelic Studies](https://maps.org/) | (maps.org) [4:00, 10:45]

**Peter’s podcast episode with Tim Ferriss**: [#01 – Tim Ferriss: depression, psychedelics, and emotional resilience](https://peterattiamd.com/timferriss/) | Peter Attia (peterattiamd.com) [4:00]

**Stan Grof’s book about his work with LSD**: [Realms of the Human Unconscious](https://www.amazon.com/Realms-Human-Unconscious-Observations-Research/dp/0285648829) by Stan Grof (amazon.com) [11:15]

**A retreat center started by Stan Grof that Rick would visit to learn about psychedelics and therapy**: [Esalen Institute](https://en.wikipedia.org/wiki/Esalen_Institute) | (wikipedia.org) [12:45. 20:45, 31:15]

**The criminalization of all the psychedelics 1970**: [Controlled Substances Act](https://en.wikipedia.org/wiki/Controlled_Substances_Act) | (wikipedia.org) [18:45, 28:15]

**Rick’s non-profit before MAPS in 1984**: [Earth Metabolic Design Lab](https://enacademic.com/dic.nsf/enwiki/11117969/Earth) | (enacademic.com) [19:00, 31:15, 1:01:15]

**Rick was inspired by the book**: [New Genesis: Shaping a Global Spirituality](https://www.amazon.com/New-Genesis-Shaping-global-spirituality/dp/038518123X) by Robert Mueller (amazon.com) [19:00]

**Famous ‘Good Friday Experiment’ by Tim Leary looking at psychedelics (psilocybin)**: [Marsh Chapel Experiment](https://en.wikipedia.org/wiki/Marsh_Chapel_Experiment) | (wikipedia.org) [20:15, 2:21:15, 2:23:30]

**Starck Club, in Dallas, a club known for use of ecstasy**: [A Nightclub Reflecting ‘80s Dallas is Revisited](https://www.nytimes.com/2014/04/13/us/the-starck-club-documents-rise-and-fall-of-dallas-nightclub.html) | (nytimes.com) [21:15]

**MDMA was invented by Merck Pharmaceutical in 1912**: [The origin of MDMA (ecstasy) revisited: the true story reconstructed from the original documents\*](https://www.thedea.org/docs/2006_Freudenmann_22846_1.pdf) (Freudenmann et al., 2006) | (thedea.org) [23:00]

**Octopus study giving them MDMA showing increased social behavior**: [A Conserved Role for Serotonergic Neurotransmission in Mediating Social Behavior in Octopus.](https://www.cell.com/current-biology/fulltext/S0960-9822(18)30991-6) (Edsinger et al., 2018) [23:45]

**MDMA in mice**: [Oxytocin-dependent reopening of a social reward learning critical period with MDMA](https://www.nature.com/articles/s41586-019-1075-9) (Nardou et al., 2019) [25:45]

**In 1953, the U.S. Army Chemical Warfare Service secretly tested eight different drugs for toxicity in animals and MDMA was one of those drugs**: [Relationship of the structure of mescaline and seven analogs to toxicity and behavior in five species of laboratory animals](https://www.sciencedirect.com/science/article/pii/S0041008X7380016X) (Hardman et al., 1973) [26:15]

**MDMA was actually rediscovered in the 1970s by** [**Sasha Shulgin**](https://en.wikipedia.org/wiki/Alexander_Shulgin): [Alexander Shulgin: Independent research](https://en.wikipedia.org/wiki/Alexander_Shulgin#Independent_research) | (wikipedia.org) [28:15]

**Books about Leo Zeff published by MAPS**: [29:45]

- *First book that MAPS published*: [The Secret Chief: Conversations With a Pioneer of the Underground Psychedelic Therapy Movement](https://www.amazon.com/Secret-Chief-Conversations-Underground-Psychedelic/dp/0966001915/ref=sr_1_2?keywords=Secret+Chief&qid=1564158005&s=books&sr=1-2) by Myron J. Stolaroff (amazon.com)
- *Next came*: [Secret Chief Revealed](https://www.amazon.com/Secret-Chief-Revealed-Myron-Stolaroff/dp/0966001966) by Myron J. Stolaroff (amazon.com)

**Ketamine recently approved for depression**: [FDA approves new nasal spray medication for treatment-resistant depression; available only at a certified doctor’s office or clinic](https://www.fda.gov/news-events/press-announcements/fda-approves-new-nasal-spray-medication-treatment-resistant-depression-available-only-certified) | (fda.gov) [36:15]

**The first large media article about MDMA in a 1985 where Brother David Steindl-Rast compared MDMA experiences to a monk who spends his whole life trying to cultivate the mental attitude that you can get from taking MDMA**:  [Psychiatrists Defend New Street Drug for Therapy](https://www.latimes.com/archives/la-xpm-1985-05-27-mn-6278-story.html) | Miles Corwin (latimes.com) [40:30]

**The 1985 Washington Post article where Rabbi Zalman Schachter compared MDMA to the sabbath**: [Ecstasy: The Lure & the Peril](https://maps.org/research-archive/hmma/WashPost6.85.pdf) | Jane Leavy (maps.org)  [40:30]

**The DEA and declared MDMA illegal on an emergency basis in 1985**: [Temporary placement of MDMA into Schedule I (the emergency scheduling), May 28, 1985](https://www.maps.org/research-archive/dea-mdma/pdf/0196.PDF) | (maps.org) [41:15]

**Alcohol kind of blunts the MDMA experience**: [Alcohol Interactions with Psychostimulants: An Overview of Animal and Human Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4966675/) (Althobaiti et al., 2016) [44:00]

**MDMA and hyponatremia**: [The agony of ecstasy: MDMA (3,4-methylenedioxymethamphetamine) and the kidney.](https://www.ncbi.nlm.nih.gov/pubmed/18684895) (Campbell et al., 2008)  [44:00]

**MDMA reduces activity in the amygdala, it reduces your fear response to difficult emotions**: [45:00]

- [The safety and efficacy of ±3,4-methylenedioxymethamphetamine-assisted psychotherapy in subjects with chronic, treatment-resistant posttraumatic stress disorder: the first randomized controlled pilot study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3122379/) (Mithoefer et al., 2011)
- [Oxytocin modulates neural circuitry for social cognition and fear in humans.](https://www.ncbi.nlm.nih.gov/pubmed/16339042/) (Kirsch et al., 2005)

**Rick’s TED Talk**: [The future of psychedelic-assisted psychotherapy](https://www.ted.com/talks/rick_doblin_the_future_of_psychedelic_assisted_psychotherapy?language=en) | Rick Doblin (ted.com) [45:30]

**Soldier who overcame PTSD with MDMA**: [‘Feel-good drug’ Ecstasy one step closer to approval as PTSD treatment](https://www.stripes.com/feel-good-drug-ecstasy-one-step-closer-to-approval-as-ptsd-treatment-1.445361) | (stripes.com) [47:30]

**The first use of a psychedelic for treating PTSD was done by a Dutch psychiatrist Dr. Jan Bastiaans using LSD**: [The LSD Therapy Career of Jan Bastiaans, M.D.](https://www.maps.org/news-letters/v08n1/08118sne.html) | Stephen Snelders (maps.org) [51:15]

**Book Israeli holocaust writer Ka-Tzetnik 135633 (real name** [**Yehiel De-Nur**](https://en.wikipedia.org/wiki/Yehiel_De-Nur)**)**: [Shivittie: A Vision](https://www.amazon.com/Shivitti-Vision-Ka-Tzetnik-135633/dp/0062508709/ref=sr_1_1?keywords=Shivitti%3A+A+Vision&qid=1563891229&s=gateway&sr=8-1) by Ka-Tzetnik 135633 (amazon.com) [51:15]

**President Carter pardoned all the draft resistors**: [A Time for Peace: The Legacy of the Vietnam War](https://books.google.com/books?id=Dq4QiUWHrOIC&pg=PT38&hl=en#v=onepage&q&f=false) | Robert D. Schulzinger (books.google.com) [1:00:15]

**Group that funded research trying to show MDMA caused neurotoxicity**: [National Institute on Drug Abuse](https://en.wikipedia.org/wiki/National_Institute_on_Drug_Abuse) (NIDA) | (wikipedia.org) [1:01:45]

**Good Friday experiment followup**: [PAHNKE’S “GOOD FRIDAY EXPERIMENT’: A long-term follow-up and methodological critique](https://www.erowid.org/plants/mushrooms/mushrooms_journal2.pdf) | Rick Doblin (erowid.org) [1:05:45, 2:29:00]

**Harper’s Magazine publications about MDMA and spoke to Mark Kleiman about Rick’s lawsuit against the DEA**: [In the age of cocaine what is American’s drug problem?](https://maps.org/research-archive/hmma/Harpers12.85.pdf) | (maps.org) [1:07:30]

**Supreme Court case about Native Americans and whether peyote would be protected by religious freedom**: [Employment Division v. Smith](https://en.wikipedia.org/wiki/Employment_Division_v._Smith) | (wikipedia.org) [1:08:45]

**Where Rick gave a speech to police**: [International Association of Chiefs of Police](https://www.theiacp.org/) [1:11:45]

**Video by MAPS showing multiple MDMA patient success stories**: [MDMA Therapy and Healing](https://www.youtube.com/watch?v=W9iKx2MKS70) | MDMA The Movie (youtube.com) [1:14:45]

**MAPS phase one dose response safety study on MDMA (1992-1996)**: [Psychobiologic effects of 3,4-methylenedioxymethamphetamine in humans: methodological considerations and preliminary observations.](https://www.ncbi.nlm.nih.gov/pubmed/8788485/) (Grob et al., 1996) [1:17:15]

**Animal MDMA toxicity studies in the dog and the rat funded by Rick**: [Toxicity of methylenedioxymethamphetamine (MDMA) in the dog and the rat.](https://www.ncbi.nlm.nih.gov/pubmed/2887476) (Frith et al., 1987) [1:18:30]

**Science paper written (then retracted) by George Ricaurte after a primate study that Rick had helped to fund about the effects of MDMA**: [Severe dopaminergic neurotoxicity in primates after a common recreational dose regimen of MDMA (“ecstasy”).](https://www.ncbi.nlm.nih.gov/pubmed/12351788) (Ricaurte et al., 2002)[1:19:15]

**MDMA study in Mormons that Rick says “show no strong evidence about neurocognitive consequences in heavy ecstasy users”**: [Residual neuropsychological effects of illicit 3,4-methylenedioxymethamphetamine (MDMA) in individuals with minimal exposure to other drugs.](https://www.ncbi.nlm.nih.gov/pubmed/15276218/) (Halpern et al., 2004) [1:23:15]

**Spinal tap study showing MDMA does no harm to dopamine**: [RISK ASSESSMENT THE FDA AND MDMA RESEARCH](https://bibliography.maps.org/resources/download/10332) | Rick Doblin (maps.org) [1:24:30]

**Group that publishes Science, and led by Alan Leshner (formerly with NIDA and someone who was very anti-MDMA)**: [American Association for the Advancement of Science](https://en.wikipedia.org/wiki/American_Association_for_the_Advancement_of_Science) | (wikipedia.org) [1:26:15]

**Editorial in Science by Alan Leshner who said MDMA is Russian roulette for your brain**: [Retracted article on dopaminergic neurotoxicity of MDMA: Press response to original publication](https://en.wikipedia.org/wiki/Retracted_article_on_dopaminergic_neurotoxicity_of_MDMA#Press_response_to_original_publication) | (wikipedia.org) [1:27:15]

**Rick’s critical letter about the George Ricarute’s Science paper**: [MDMA (“ecstasy”) and neurotoxicity.](https://www.ncbi.nlm.nih.gov/pubmed/12791964) (Mithoefer et al., 2003) [1:27:45]

**Scientist mixed up drug vials and accidentally gave the animals methamphetamine instead of MDMA for the controversial MDMA primate study**: [Agony for researchers as mix-up forces retraction of ecstasy study](https://www.nature.com/articles/425109a) | Jonathan Knight (nature.com) [1:28:00]

**MDMA increases blood pressure**: [Effects of MDMA, MDA and MDEA on blood pressure, heart rate, locomotor activity and body temperature in the rat involve α-adrenoceptors](https://www.ncbi.nlm.nih.gov/pubmed/27859780) (Bexis et al., 2006) [1:35:00]

**A remote chance that MDMA could trigger a seizure**: [MDMA and seizures: a dangerous liaison?](https://www.ncbi.nlm.nih.gov/pubmed/17105933) (Giorgi et al., 2006) [1:35:00]

**Summary of Ricks 6 phase II pilot studies using MDMA for PTSD**: [MDMA-assisted psychotherapy for treatment of PTSD: study design and rationale for phase 3 trials based on pooled analysis of six phase 2 randomized controlled trials.](https://www.ncbi.nlm.nih.gov/pubmed/31065731) (Mithoefer et al., 2019) [1:40:45]

**MAPS gets MDMA approved as a “Breakthrough Therapy”**: [PRESS RELEASE: FDA Grants Breakthrough Therapy Designation for MDMA-Assisted Psychotherapy for PTSD, Agrees on Special Protocol Assessment for Phase 3 Trials](https://maps.org/news/media/6786-press-release-fda-grants-breakthrough-therapy-designation-for-mdma-assisted-psychotherapy-for-ptsd,-agrees-on-special-protocol-assessment-for-phase-3-trials) | (maps.org) [1:42:30]

**Two other drugs approved by the FDA for PTSD (Rick says “both of these diminish symptoms, but don’t solve the problem and don’t work in many, many people”)**: [1:42:45]

- [Zoloft](https://en.wikipedia.org/wiki/Sertraline#Medical_uses)
- [Paxil](https://en.wikipedia.org/wiki/Paroxetine#Anxiety_disorders)

**Only person from the FDA that ever won the Presidential Medal of Honor was Frances Kelsey for her work with the FDA and blocking thalidomide due to side effects (birth defects)**: [Frances Kelsey: Work at the FDA and thalidomide](https://en.wikipedia.org/wiki/Frances_Oldham_Kelsey#Work_at_the_FDA_and_thalidomide) | (wikipedia.org)  [1:44:00]

- *Decades later, thalidomide is now a medicine useful for leprosy and some other kinds of cancers*: [Thalidomide: Medical uses](https://en.wikipedia.org/wiki/Thalidomide#Medical_uses) | (wikipedia.org) [1:44:30]

**The phase III MDMA studies by MAPS**: [A Phase 3 Program of MDMA-Assisted Psychotherapy for the Treatment of Severe Posttraumatic Stress Disorder (PTSD)](https://maps.org/research/mdma/ptsd/phase3) | (maps.org) [1:45:45]

**How to apply for the Expanded Access for Compassionate Use program**: [Expanded Access: Information for Patients](https://www.fda.gov/news-events/expanded-access/expanded-access-information-patients) | (fda.gov) [1:46:00]

**How to apply to be a participant in the phase 3 trials by MAPS**: [MDMA-ASSISTED PSYCHOTHERAPY CLINICAL TRIALS](https://mdmaptsd.org/?pk_campaign=2019-07-Newsletter-July-Web&pk_kwd=text-phase3-visitmdmaptsd) | (mdmaptsd.org) [1:48:00]

**Highly recommended documentary about psychedelics**: [A Trip of Compassion](https://vimeo.com/ondemand/tripofcompassion) | (vimeo.com) [1:52:30]

**Book rec by a PTSD expert**: [The Body Keeps the Score: Brain, Mind, and Body in the Healing of Trauma](https://www.amazon.com/Body-Keeps-Score-Healing-Trauma/dp/0143127748) by Bessel van der Kolk who’s a psychiatrist, PTSD expert called The Body Keeps the Score [1:54:15]

**Book that inspired Rick**: [One Flew Over the Cuckoo’s Nest](https://www.amazon.com/One-Flew-Over-Cuckoos-Nest/dp/0451163966) by Ken Kesey (amazon.com) [2:05:15]

**Where Rick went to college**: [New College of Florida](https://en.wikipedia.org/wiki/New_College_of_Florida) | (wikipedia.org) [2:05:30]

**“An incredible book about LSD to go into the unconscious”**: [Programming and Metaprogramming in the Human Biocomputer](https://www.amazon.com/Programming-Metaprogramming-Human-Biocomputer-Experiments/dp/0692217894) by John Lilly (amazon.com) [2:08:30]

**The discovery of LSD by Albert Hofmann**:  [Albert Hofmann: Discovery of LSD](https://en.wikipedia.org/wiki/Albert_Hofmann#Discovery_of_LSD) | (wikipedia.org) [2:10:45]

**Video about “Bicycle Day”**: [What is Bicycle Day?](https://www.youtube.com/watch?v=L32mAiLXnLs) | Reactions (youtube.com) [2:14:45]

**Book by Albert Hofman on his work with LSD**: [LSD: My Problem Child](https://www.amazon.com/LSD-Problem-Child-Reflections-Mysticism/dp/0979862221) by Albert Hofmann (amazon.com) [2:15:00]

**CIA “mind control program” looking into the use of LSD for military purposes**: [Project MKUltra](https://en.wikipedia.org/wiki/Project_MKUltra) | (wikipedia.org) [2:17:15]

**CIA funded expeditions to Mexico with Gordon Wasson in 1957/58 to search for mushrooms and for other drugs that might be psychedelic**: [R. Gordon Wasson: Ethnomycology](https://en.wikipedia.org/wiki/R._Gordon_Wasson#Ethnomycology) | (wikipedia.org) [2:18:45]

**William James, the father of American psychology had experimented in 1896 with nitrous oxide, and wrote about it in the varieties of religious experience**: [Subjective Effects of Nitrous Oxide by William James](https://www.uky.edu/~eushe2/Pajares/jnitrous.html) | (uky.edu) [2:19:15]

**The word ‘psychedelic’ didn’t get developed until 1958 by Humphry Osmond when he wrote this poem to Aldous Huxley**: [Psychedelic Prophets: The Letters of Aldous Huxley and Humphry Osmond (McGill-Queen’s/Associated Medical Servic)](https://www.amazon.com/Psychedelic-Prophets-McGill-Queens-Associated-Services/dp/0773555064) by Cynthia Carson Bisbee (Editor), Paul Bisbee (Editor), Erika Dyck (Editor), Patrick Farrell (Editor) | (amazon.com) [2:19:30]

[**The Doors**](https://en.wikipedia.org/wiki/The_Doors) **(the band) got their name from the book**: [The Doors of Perception](https://www.amazon.com/Doors-Perception-Aldous-Huxley/dp/0060801719) by Aldous Huxley (amazon.com) [2:20:00]

**Albert Hofmann discovered psilocybin**: [Albert Hofmann: Further Research](https://en.wikipedia.org/wiki/Albert_Hofmann#Further_research) | (wikipedia.org) [2:20:15]

**Book rec about the history of psychedelics**: [How To Change Your Mind](https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225) by Michael Pollan (amazon.com) [2:22:00]

**Tim Leary’s book on psychology**: [The Interpersonal Diagnosis of Personality](https://www.amazon.com/Interpersonal-Diagnosis-Personality-Functional-Methodology/dp/1592447767) by Tim Leary (amazon.com) [2:22:30]

**Famous studies by Tim Leary**:

- [Marsh Chapel Experiment](https://en.wikipedia.org/wiki/Marsh_Chapel_Experiment) (aka Good Friday Experiment) [2:22:00]
- [Concord Prison Experiment](https://en.wikipedia.org/wiki/Concord_Prison_Experiment) [2:24:00, 2:47:00]

**An actual copy of the service that they listened to during Good Friday Experiment**: [1962 Good Friday Experiment (Podcast)](https://maps.org/news/multimedia-library/138-1962-good-friday-experiment) | (maps.org) [2:26:30]

**Rick’s follow up study to the Good Friday Experiment**: [Pahnke’s “Good Friday Experiment”: A long-term follow-up and methodological critique](https://web.archive.org/web/20100128015718/https://druglibrary.org/schaffer/lsd/doblin.htm) (Rick Doblin, 1991) | (maps.org) [2:33:50]

**Rick’s follow up to the Concord Prison Experiment**: [Dr. Leary Concord Prison Experiment: A 34-Year Follow Up Study](https://maps.org/research-archive/1998_Doblin_ConcordPrisonFollow-up.pdf) | (maps.org) [2:50:45]

§

## People Mentioned

- [Tim Ferriss](https://en.wikipedia.org/wiki/Tim_Ferriss) [4:00, 1:52:30]
- [Stan Grof](https://en.wikipedia.org/wiki/Stanislav_Grof) [11:15, 12:00, 13:30, 48:00, 1:29:45, 2:16:45]
- [Dick Price](https://en.wikipedia.org/wiki/Dick_Price) (co-founder of Esalen Institute) [13:30, 20:45]
- [Michael Murphy](https://en.wikipedia.org/wiki/Michael_Murphy_(author)) (co-founder of Esalen Institute) [13:30]
- [Fritz Perls](https://en.wikipedia.org/wiki/Fritz_Perls) [13:30]
- [Ida Rolf](https://en.wikipedia.org/wiki/Ida_Rolf) [13:30]
- [Christina Grof](https://www.esalen.org/page/christina-grof) [14:00]
- [Dr. Debby Harlow](https://enacademic.com/dic.nsf/enwiki/11117969/Earth) (Earth Metabolic Design Labs) [14:00, 20:15]
- [Jonathan Ott](https://en.wikipedia.org/wiki/Jonathan_Ott) [16:00]
- [Dave Nichols](https://en.wikipedia.org/wiki/David_E._Nichols) (coined term “entactogen”) [16:30, 1:18:30]
- [Ralph Metzner](https://en.wikipedia.org/wiki/Ralph_Metzner) [16:30]
- [Laura Huxley](https://en.wikipedia.org/wiki/Laura_Huxley) [19:00, 20:15]]
- [Robert Muller](https://en.wikipedia.org/wiki/Robert_Muller) [19:00, 40:00, 1:30:45]
- [Michael Clegg](https://deadline.com/2019/02/michael-clegg-ecstasy-tv-series-mdma-origins-1202560657/) (created “ecstasy”) [20:45, 30:15]
- [Sasha Shulgin](https://en.wikipedia.org/wiki/Alexander_Shulgin) [26:15, 28:15, 32:00]
- [Ann Shulgin](https://en.wikipedia.org/wiki/Ann_Shulgin) (wife of Sasha Shulgin) [28:45]
- [Leo Zeff](https://en.wikipedia.org/wiki/Leo_Zeff) [29:45]
- [Buckminster Fuller](https://en.wikipedia.org/wiki/Buckminster_Fuller) [31:15, 1:01:15]
- [Rick Cotton](https://www.washingtonpost.com/archive/lifestyle/1985/06/01/ecstacy-the-lure-and-the-peril/18e4822a-d264-4ebb-b5b2-3251b924d49c/?utm_term=.3f52fe97f460) (attorney for Sasha and Rick for DEA case) [32:00]
- [David Steindl-Rast](https://en.wikipedia.org/wiki/David_Steindl-Rast) [40:30]
- [Zalman Schachter](https://en.wikipedia.org/wiki/Zalman_Schachter-Shalomi) [40:30]
- [Ronanld Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) [42:00]
- [Marcela Ot’alora](https://marcelaotalorag.com/about-marcela/) (Rick’s first patient he treated with MDMA) [47:15, 48:30, 1:29:45, 1:39:30]
- [Jan Bastiaans](https://nl.wikipedia.org/wiki/Jan_Bastiaans) [51:15]
- [Ka-Tzetnik 135633](https://en.wikipedia.org/wiki/Yehiel_De-Nur) (real name [Yehiel De-Nur](https://en.wikipedia.org/wiki/Yehiel_De-Nur)) [51:15]
- [Jimmy Carter](https://en.wikipedia.org/wiki/Jimmy_Carter) [1:00:15]
- [Mark Kleiman](https://en.wikipedia.org/wiki/Mark_Kleiman) [1:07:30]
- [Paul Lieber](https://www.huffpost.com/entry/from-fda-to-gsk-the-dange_b_115117) (guy in charge of the division that took care of Schedule 1 drugs) [1:09:45]
- [Carl Peck](https://www.ndapartners.com/consultants/index.php?cat=partners&page=peck) (Pilot Drug Evaluation Staff, hired Rick to the FDA) [1:09:45]
- [Tony Coulson](https://sai-dc.com/our-leaders-consultants/anthony-j-coulson/) (arranged Rick to speak to the International Association of Chiefs of Police) [1:11:45]
- [Donald Trump](https://en.wikipedia.org/wiki/Donald_Trump) [1:11:45, 2:51:30]
- [Charlie Grob](https://en.wikipedia.org/wiki/Charles_Grob) [1:18:00, 1:19:00, 1:28:45]
- [George Ricaurte](https://en.wikipedia.org/wiki/George_A._Ricaurte) [1:19:15, 1:20:00, 1:21:11]
- [Una McCann](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0013297/una-mccann) [1:19:15, 1:25:30]
- [Timothy Leary](https://en.wikipedia.org/wiki/Timothy_Leary) [1:20:00, 2:22:00, 2:27:30, 2:34:15, 2:39:00, 2:41:30, 2:47:00, 2:52:45]
- [Alan Leshner](https://en.wikipedia.org/wiki/Alan_I._Leshner) [1:26:00, 1:27:15]
- [Michael Mithoefer](https://maps.org/news/media/1472-michael-mithoefer-m-d-principal-investigator) [1:27:30, 1:29:45, 1:31:45, 1:34:00]
- [Ralph Metzner](https://en.wikipedia.org/wiki/Ralph_Metzner) [1:29:45, 2:27:30, 2:45:00, 2:51:45]
- [Paul Grof](https://en.wikipedia.org/wiki/Paul_Grof) [1:31:00]
- [Frances Oldham Kelsey](https://en.wikipedia.org/wiki/Frances_Oldham_Kelsey) (won the Presidential Medal of Honor) [1:44:00]
- [Bessel van der Kolk](https://en.wikipedia.org/wiki/Bessel_van_der_Kolk) (author of The Body Keeps the Score, principal investigator of the Boston site for MAPS) [1:54:15]
- [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) [1:56:45]
- [Leo Tolstoy](https://en.wikipedia.org/wiki/Leo_Tolstoy) [1:56:45]
- [Henry David Thoreau](https://en.wikipedia.org/wiki/Henry_David_Thoreau) [1:56:45]
- [Ralph Waldo Emerson](https://en.wikipedia.org/wiki/Ralph_Waldo_Emerson) [1:56:45]
- [Mahatma Gandhi](https://en.wikipedia.org/wiki/Mahatma_Gandhi) [1:56:45]
- [Martin Luther King Jr.](https://en.wikipedia.org/wiki/Martin_Luther_King_Jr.) [1:56:45, 2:26:15, 2:28:15]
- [Donald Rumsfeld](https://en.wikipedia.org/wiki/Donald_Rumsfeld) [2:01:15]
- [Daniel Ellsberg](https://en.wikipedia.org/wiki/Daniel_Ellsberg) [2:02:15]
- [Hermann Hesse](https://en.wikipedia.org/wiki/Hermann_Hesse) {2:03:00]
- [Ken Kesey](https://en.wikipedia.org/wiki/Ken_Kesey) (One Flew Over the Cuckoo’s Nest) [2:05:15]
- [I.M. Pei](https://en.wikipedia.org/wiki/I._M._Pei) [2:05:45]
- [Marion Hoppin](https://en.wikipedia.org/wiki/Courtland_Hector_Hoppin#Personal_life) (donated pool to New College with husband, [Courtland Hector Hoppin](https://en.wikipedia.org/wiki/Courtland_Hector_Hoppin)) [2:07:00]
- [Carl Jung](https://en.wikipedia.org/wiki/Carl_Jung) [2:07:00]
- [Stewart Brand](https://en.wikipedia.org/wiki/Stewart_Brand) (The [Whole Earth Catalog](https://en.wikipedia.org/wiki/Whole_Earth_Catalog)) [2:08:30]
- [John Lilly](https://en.wikipedia.org/wiki/John_C._Lilly) ([Programming and Metaprogramming in the Human Biocomputer](https://www.amazon.com/Programming-Metaprogramming-Human-Biocomputer-Experiments/dp/0692217894)) [2:08:30]
- [Albert Hofmann](https://en.wikipedia.org/wiki/Albert_Hofmann) [2:11:15, 2:15:00]
- [Tom Roberts](https://maps.org/resources/students/182-multidisciplinary-approaches-to-psychedelic-scholarship) (professor who termed ‘Bicycle Day’) [2:14:45]
- [Bill Wilson](https://en.wikipedia.org/wiki/Bill_W.) [2:17:45, 2:24:00]
- [Gordon Wasson](https://en.wikipedia.org/wiki/R._Gordon_Wasson) [2:18:45, 2:20:15]
- [William James](https://en.wikipedia.org/wiki/William_James) [2:19:15, 2:32:00]
- [Humphry Osmond](https://en.wikipedia.org/wiki/Humphry_Osmond) [2:19:30]
- [Aldous Huxley](https://en.wikipedia.org/wiki/Aldous_Huxley) [2:20:00, 2:20:15, 2:24:00, 2:25:00]
- [Michael Pollan](https://en.wikipedia.org/wiki/Michael_Pollan) [2:22:00]
- [Frank Barron](https://en.wikipedia.org/wiki/Frank_Barron_(psychologist)) [2:22:30]
- [Walter Pahnke](https://en.wikipedia.org/wiki/Walter_Pahnke) [2:23:30, 2:24:00, 2:26:15, 2:26:30, 2:35:00]
- [W.T. Stace](https://en.wikipedia.org/wiki/Walter_Terence_Stace) [2:25:00]
- [Howard Thurman](https://en.wikipedia.org/wiki/Howard_Thurman) [2:26:15, 2:39:00]
- [Richard Alpert](https://en.wikipedia.org/wiki/Ram_Dass) (who later became Ram Dass) [2:27:30]
- [Huston Smith](https://en.wikipedia.org/wiki/Huston_Smith) [2:27:30, 2:39:00, 2:43:45]
- [Lawrence Lowell](https://en.wikipedia.org/wiki/A._Lawrence_Lowell) [2:32:00]
- [Andover Newton](https://en.wikipedia.org/wiki/Andover_Newton_Theological_School) [2:34:00, 2:34:15]
- [Nancy Reagan](https://en.wikipedia.org/wiki/Nancy_Reagan) [2:34:15]
- [Malcolm X](https://en.wikipedia.org/wiki/Malcolm_X) [2:50:45]
- [William Weld](https://en.wikipedia.org/wiki/Bill_Weld) [2:51:30]
- [Adolf Hitler](https://en.wikipedia.org/wiki/Adolf_Hitler) [2:57:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/07/rick_doblin-bio-image.png)

##### Rick Doblin, Ph.D.

Rick Doblin, Ph.D., is the founder and executive director of the Multidisciplinary Association for Psychedelic Studies (MAPS). He received his doctorate in Public Policy from Harvard’s Kennedy School of Government, where he wrote his dissertation on the regulation of the medical uses of psychedelics and marijuana and his Master’s thesis on a survey of oncologists about smoked marijuana vs. the oral THC pill in nausea control for cancer patients. His undergraduate thesis at New College of Florida was a 25-year follow-up to the classic Good Friday Experiment, which evaluated the potential of psychedelic drugs to catalyze religious experiences. He also conducted a thirty-four year follow-up study to Timothy Leary’s Concord Prison Experiment. Rick studied with Dr. Stanislav Grof and was among the first to be certified as a Holotropic Breathwork practitioner. His professional goal is to help develop legal contexts for the beneficial uses of psychedelics and marijuana, primarily as prescription medicines but also for personal growth for otherwise healthy people, and eventually to become a legally licensed psychedelic therapist. He founded MAPS in 1986, and currently resides in Boston with his wife, two dogs, and empty rooms from three children, one of whom is in college and two have graduated. [maps.org]

Twitter: [@rickdoblin](https://twitter.com/rickdoblin?lang=en)