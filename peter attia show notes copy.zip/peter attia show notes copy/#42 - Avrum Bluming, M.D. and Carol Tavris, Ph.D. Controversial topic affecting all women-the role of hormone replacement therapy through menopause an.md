# #42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer

**Source:** [https://peterattiamd.com/caroltavris-avrumbluming/](https://peterattiamd.com/caroltavris-avrumbluming/)

---

In this episode, Avrum Bluming, hematologist, medical oncologist, and emeritus clinical professor at USC, and Carol Tavris, social psychologist and author of *Mistakes Were Made (But Not By Me)*, discuss their collaboration on their recent book, *Estrogen Matters*. Their book takes on the very polarizing and confusing topic of hormone replacement therapy for women suffering with symptoms of menopause. In many ways, the story and history of HRT is in striking parallel to the bad science that led up to the dietary guidelines being set forth in 1980. Carol and Avrum make a compelling case that most women benefit greatly from being on postmenopausal hormone replacement therapy, and can do so without increasing their risk of breast cancer. We also cover the history of HRT, the impact of the Women’s Health Initiative, and take a deep dive into each of the clinical conditions for which HRT should be considered, such as cardiovascular disease and neurodegenerative disease, and osteoporosis, to name a few.

*Do you have questions about this controversial topic?* Dr. Bluming has graciously offered his email to take questions directly from fans of the podcast: **avrumzbluming@gmail.com**

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/caroltavris-avrumbluming/the_Drive_public.png)

Play

#42 - Avrum Bluming, M.D., and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer

#42 - Avrum Bluming, M.D., and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer

1x15s30s

0:002:20:37

## We discuss:

- The background of Carol and Avrum, and the impetus for writing Estrogen Matters [8:45];
- The sad early history of hormone replacement therapy, treatments for prostate and breast cancer, and the difference between the treatment of women vs. men [14:00];
- What hormones do, and why they drop off rapidly in women compared to gradually in men [20:15];
- Mistreatment of women leading to great skepticism [23:45];
- Breast cancer vs heart disease: Comparing the incidence and mortality in women [27:00];
- Case studies of women suffering symptoms of menopause [30:00];
- What are Carol and Avrum’s true motivations in this endeavor? [32:45];
- The changing perceptions of HRT, the impact of the Women’s Health Initiative (WHI), and the problems with the WHI [37:45];
- Is this one big conspiracy? The uncanny resemblance of the story of HRT and how the dietary guidelines were created [46:00];
- Why people (falsely) think estrogen causes a 25% increase in breast cancer, and a lesson in absolute vs. relative risk [57:15];
- The truth about progesterone and cancer risk, and the best types of estrogen and progesterone to be taking [1:09:00];
- The Women’s Health Initiative: the reported findings, walking back their bold claims, and their hesitance to admit they were wrong [1:17:45];
- Brain benefits of HRT, Alzheimer’s disease in women, and estrogen as a preventative treatment for AD [1:22:45];
- The impact of HRT on heart disease, the ideal time to start HRT, and the risks associated with HRT [1:26:45];
- The benefits of estrogen on bone health, and the incidence and mortality of hip fractures [1:33:15];
- Colon cancer: Can HRT reduce the risk of colon cancer? [1:38:15];
- Diabetes: Can HRT reduce the risk of developing diabetes? [1:40:30];
- The downsides of hormone replacement therapy (HRT) [1:41:30];
- How to approach your doctor who may already have a very strong point of view about HRT [1:42:15];
- What kind of research needs to be done to answer the remaining questions about the benefits and risks of HRT? [1:48:30];
- Cancer: Our evolving understanding and the future of treatment [1:59:15];
- Welcoming the critics: Avrum and Carol want to start a conversation [2:02:00];
- Are there racial differences in benefits and risks with HRT? [2:04:15];
- The reactions to Estrogen Matters, and why it is a must read [2:09:15];
- HRT after a diagnosis of breast cancer [2:13:45]; and
- More.

§

## Show Notes

## The background of Carol and Avrum, and the impetus for writing Estrogen Matters [8:45]

**Figure 1. Cover of Estrogen Matters.** Image credit: [amazon.com](https://www.amazon.com/Estrogen-Matters-Hormones-Menopause-Well-Being/dp/0316481203)

[**Dr. Carol Tavris**](https://tavris.socialpsychology.org/)**, social psychologist**

*What’s a social psychologist writing about estrogen for?*

- My lifelong interest has been in bringing good scientific research in psychology and medicine to public attention
- As a social psychologist, I have always been interested in the barriers to critical thinking and the reasons that people do not accept information when it is in their best interest to do so
- These interests culminated in her book, [Mistakes Were Made (But Not by Me)](https://www.amazon.com/Mistakes-Were-Made-But-Not/dp/0151010986/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
  - This book was about “why it is that people resist new information that is better to know, that it’s beneficial, that improves our knowledge”
  - This book is one of Peter’s all time favorites, “one of the three books I have recommended and/or gifted the most”

[**Dr. Avrum Bluming**](https://www.amazon.com/Avrum-Bluming/e/B07BD4DQ3J)**, medical oncologist**

*Why in particular has this issue become something that’s resonated with you?*

- I’ve spent over 50 years as a medical oncologist and my reason for going into the field was to help people live as long and as well as possible and helping to decide how best they should be treated
- Breast cancer constitutes about 60% of my practice and I’ve watched the progress in breast cancer very happily noting how many people we now cure (about 90% of the cases are now curable)

*However…*

- While I was making a lot of people better in terms of the cancer, I was making them worse in terms of the symptoms associated with the treatments they got. When you treat something for that long, you want to understand what it is so that you can treat it most effectively.
- It is important that I challenge every assumption on which my practice was based and I’ve done that continuously.

> “The major assumption dealing with breast cancer is that estrogen causes breast cancer, and it doesn’t. Almost everything we’ve done in the treatment of breast cancer is based on that assumption so that women have been denied estrogen for at least the last 30 years. . . and the result is that many women have been hurt by being denied that medicine.”

## The sad early history of hormone replacement therapy, treatments for prostate and breast cancer, and the difference between the treatment of women vs. men [14:00]

Carol and Avrum’s 2009 paper, [Hormone Replacement Therapy: Real Concerns and False Alarms](https://www.researchgate.net/publication/24355772_Hormone_Replacement_Therapy_Real_Concerns_and_False_Alarms), has a beautiful time course of hormone replacement therapy in women:

![](https://peterattiamd.com/wp-content/uploads/2019/02/timeline-of-HRT-history-2-938x1024.png)

**Figure 2. HRT and Breast Cancer: A timeline of relevant events and studies.** Image credit: ([Bluming and Tavris, 2009](https://www.researchgate.net/publication/24355772_Hormone_Replacement_Therapy_Real_Concerns_and_False_Alarms))

**Men vs. Women: Comparing the early history of hormone replacement therapy (HRT)**

Using the example of how we treated prostate cancer in men with breast cancer in women…

- The number of *women with breast cancer and men with prostate cancer is approximately comparable* in the United States.
- And the number of *women who die of breast cancer is comparable to the number of men who die of prostate cancer* each year.
- Therefore, the medical establishment made the false leap that testosterone is responsible for prostate cancer and estrogen is therefore responsible for breast cancer
- Prostate cancer was treated initially by castration of the testicle ⇒ it doesn’t cure it, but it helps in some cases
- So, women were castrated by removal of the ovaries to eliminate estrogen to treat breast cancer ⇒ it helps in some cases, but not many
- For prostate cancer, if the castration didn’t work, we stopped and gave palliative care
- With breast cancer, if castration didn’t help, we kept removing things…
- Adrenal glands of women (by the way, adrenal glands make a small percentages of circulating testosterone, but we never removed the adrenal glands of men)
- Once you remove the adrenal gland, you have to replace the hormones that were necessary for survival, which they did
- If the adrenal gland removal didn’t work, we then would take out the anterior pituitary gland at the base of the brain because that gland produces a hormone that stimulates either the ovary or the testicle to make the responsible hormone.
- We used to do [hypophysectomies](https://en.wikipedia.org/wiki/Hypophysectomy) and while I was in practice, we did that, says Avrum
- But again, the anterior pituitary makes many hormones that are necessary for survival so they had to replace many of those hormones
- They even started to [prophylactically remove the ovaries](https://www.ncbi.nlm.nih.gov/pubmed/10469748) of those who previously had breast cancer to try to keep it from coming back
- And even after all of this, “we didn’t really help too many women with that”

> “Let me reiterate, we did nothing like that for men and we hurt a lot of women by doing that. We did it with good intentions, but we hurt them.”

**Early history of HRT using estrogen**

A book in 1968 called [Feminine Forever](https://www.amazon.com/Feminine-Forever-M-D-Robert-Wilson/dp/B000J00XN0) by Robert A. Wilson

- The book essentially said women should take estrogen forever and it’ll be an eternal fountain of youth
- But that’s not true, that book was oversold, and the doctor who wrote that book was paid for by the drug company who made estrogen
- This book did a lot of damage to the trust of community in terms of using estrogen as a treatment

*But estrogen did do some very good things…*

⇒ First, estrogen can relieve the symptoms of menopause

- And it’s not just hot flashes and night sweats, symptoms include:
  - Palpitations
  - cognitive decline
  - joint pains
  - sleep disturbances
  - depression

> “It usually lasts about seven and a half years, not two years, and in some women it goes on for decades and women are taught to suck it up and deal with that.”

**Estrogen and heart disease**

- In 1991, an article was published: [Uncertainty about Postmenopausal Estrogen — Time for Action, Not Debate](https://www.nejm.org/doi/pdf/10.1056/NEJM199109123251108)
- It suggested that estrogen is also capable of reducing significant heart disease by up to 50%
- “That was 1991 and we now know that estrogen has been shown repeatedly to help diminish the risk for significant heart conditions.”

## What hormones do, and why they drop off rapidly in women compared to gradually in men [20:15]

**Peter hardly ever prints a physical copy of a paper, however, these two are a couple of the exceptions**:

1. [First publication of the WHI](https://jamanetwork.com/journals/jama/fullarticle/195120) and the [2003 republication](https://www.ncbi.nlm.nih.gov/pubmed/12824205)
2. **A figure showing the hormone cycle for a woman during her reproductive years**… “I started doing this about three years ago and I was surprised how many women didn’t know what estrogen was doing in their body.”

![](https://peterattiamd.com/wp-content/uploads/2019/02/hormone-cycle-revised-1024x580.png)

**Figure 3. Hormone cycle.** Image credit: [primaleye.uk](https://primaleye.uk/how-female-hormones-affect-your-diet/)

*Why do some women experience horrible PMS symptoms?*

- It has to do with the reduction of progesterone
- And in some women, the fall of progesterone during the end of the luteal phase is so rapid (for reasons we don’t understand) it produces a drastic change

**Female hormones rapidly decline (not gradual)**

- Women have hormones such as
  - luteinizing hormone,
  - follicle stimulating hormone
  - And they are coming out of the pituitary and telling the ovaries to make yet more hormones
  - Then suddenly, during menopause, their production seem to drop off a cliff
- Why? ⇒ Evolution may have wanted women to be able to reproduce up to a point and then it turns off the hormones that are responsible for allowing reproduction (i.e. this cycle of rising estrogen, progesterone falling)

> “This is a crucial thing to say, Peter. This is really important. This was something I didn’t realize until we began working on this book. I assumed that in menopause, estrogen declines. I think that’s the way women see it. It just declines the way testosterone declines in a slow, moderate way. No, estrogen plummets to 1% of what it was before menopause. I think most women have no idea that it’s that great a drop in estrogen levels and no wonder that many of the symptoms that women have, which by the way include depression which they’ve attributed to a ‘midlife crisis’. No, it could be an estrogen depletion crisis as well. I think it’s really important for women to understand that this is not just as a little fall off, it’s really a major drop.”

## Mistreatment of women leading to great skepticism [23:45]

*“What interests me is the way women have been given false information for so many years about so many aspects of their reproductive cycle and experience that it’s no wonder that many women have a great skepticism about what medicine has to offer them in reproductive issues.”*

- There was so little hesitation in cutting women up
- Removing this part and removing that part
- Things that would never have been tried with men

[Feminine Forever](https://www.amazon.com/Feminine-Forever-M-D-Robert-Wilson/dp/B000J00XN0) by Robert Wilson

- It oversold the benefits of estrogen
- Robert Wilson was paid by makers of estrogen treatments to write the book
- It created even further skepticism
- It also created a defiance in the feminist community of “the hell with all of you on this estrogen, I don’t need it, it doesn’t make me feminine forever and who dares to think that I need to be feminine forever in that traditional way!”

*“What I want our conversation to bring here is an understanding of why women have been whipped back and forth on whether estrogen is good for them or bad for them.”* says Carol

Other examples of how women were mistreated

- The [radical mastectomy](https://en.wikipedia.org/wiki/Radical_mastectomy) ⇒ [Sid Mukherjee](https://twitter.com/drsidmukherjee?lang=en) has written about this in [The Emperor of All Maladies](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439170916)
- [Pituitary resections](https://mayfieldclinic.com/pe-endopitsurg.htm) (Transsphenoidal resections)
- [Oophorectomies](https://en.wikipedia.org/wiki/Oophorectomy)
- [Resecting adrenal glands](https://www.sages.org/publications/patient-information/patient-information-for-laparoscopic-adrenal-gland-removal-adrenalectomy-from-sages/)
- The routine use of [hysterectomy](https://www.webmd.com/women/guide/hysterectomy)

> “The routine use of hysterectomy on the assumption that a woman, once she’s had her children, doesn’t need to have her uterus. And by the way, since we’re removing your uterus, let’s remove your ovaries as well because what the hell, they’re just there, let’s take them out as if they have no function. That casual attitude of let’s just get in there and get rid of.”

## Breast cancer vs heart disease: Comparing the incidence and mortality in women [27:00]

- Estrogen can significantly decrease the risk of heart disease
- However, many women believe that “old women die of heart disease, young women die of breast cancer”
- So the women often say they’d rather not take estrogen if estrogen causes breast cancer
  - First of all, estrogen does not cause breast cancer
  - But more than that, **in every decade of a woman’s life, the incidence of death from heart disease is greater than the incidence of death from breast cancer**.

**Deaths from heart disease vs. deaths from breast cancer in women**

> “Heart disease kills more women than the next 16 causes of death, including all forms of cancer, AIDS and accidents.”

![](https://peterattiamd.com/wp-content/uploads/2019/02/20-50-1024x305.png)

**Figure 4. Forward-looking projection of mortality from breast cancer and from cardiovascular disease by decade in women: Age 20-50.** Image credit: [knowyourchances.cancer.gov](https://knowyourchances.cancer.gov/custom_charts.php)

![](https://peterattiamd.com/wp-content/uploads/2019/02/30-75-1024x309.png)

**Figure 5. Forward-looking projection of mortality from breast cancer and from cardiovascular disease by decade in women: Age 30-75.** Image credit: [knowyourchances.cancer.gov](https://knowyourchances.cancer.gov/custom_charts.php)

*More stats . . .*

⇒ Risk of dying (US):

- [1-in-4 (25%) women die of heart disease](https://www.cdc.gov/dhdsp/data_statistics/fact_sheets/fs_women_heart.htm)
- [The lifetime risk of dying from breast cancer is 1-in-38 (2.6%)](https://www.cancer.org/cancer/cancer-basics/lifetime-probability-of-developing-or-dying-from-cancer.html)
- In other words, women are **10 times more likely** to die from heart disease than breast cancer

⇒ Risk of developing (US):

- [Women have a 1-in-8 (12%) risk of getting breast cancer](https://www.breastcancer.org/symptoms/understand_bc/statistics)
- [The lifetime risk for cardiovascular disease is more than 1 in 2](https://www.your-heart-health.com/content/close-the-gap/en-US/heart-disease-facts/women.html)
  - [About 56% of women](https://jamanetwork.com/journals/jama/fullarticle/1389613)
- In other words, women are **~5 times more likely** to get heart disease than breast cancer.

⇒ Almost [two-thirds (64%) of women who die suddenly of coronary heart disease have no previous symptoms](https://www.cdc.gov/dhdsp/data_statistics/fact_sheets/fs_women_heart.htm)

**Women present with heart disease quite differently than men**

- Men tend to have crushing chest pain that radiates down their left arm, starting at the shoulder
- Women, however, can often present with an upset stomach

> “And because we generally don’t think of women as suffering from heart disease, the diagnosis is initially missed quite often.”

## Case studies of women suffering symptoms of menopause [30:00]

Peter was caring for a female patient

- 47 years old
- Her labs showed what looks like completely normal levels
  - FSH  at 10
  - Estradiol at 90
- She was having symptoms
- Peter suspected she was in a perimenopausal state and that she would enter menopause in the next three or four years
- Rechecked her book 3 months later and was shocked
  - FSH up to 68
  - Estradiol was so low that it was unmeasurable
- When consulting a gynecologist friend, he told Peter, “You just happened to see her fall off the cliff. This happens all the time. It’s just we usually aren’t looking at laboratory tests that frequently”

Blog post by Katie Taylor: [Finding the positive side of menopause](https://www.thejc.com/lifestyle/features/finding-the-positive-side-of-menopause-1.438301)

- She was having all sorts of symptoms
- She was treated for her depression with antidepressants, which didn’t help
- Turns out she was in perimenopause

Unexpected symptoms

> “Many of the symptoms that women begin to develop in their 40s, they don’t associate with menopause. Muscle pain sends them to rheumatologists and depression sends them to therapists and fighting with their spouses sends them to family therapy. And they don’t think that their changes of menopause might be involved.”

## What are Carol and Avrum’s true motivations in this endeavor? [32:45]

Carol:

“Neither of us has a vested interest in this. Neither of us has taken any money from drug companies. I have been a vociferous critic of big pharma and a lot of its manipulations of research and its inflated claims. No, I don’t have a personal interest in defending HRT. In fact, as a feminist psychologist for many years, I was really critical of the kind of ‘take it for granted assumption that once a woman hits menopause, then you gotta fill her tank with hormones to get her back to being a real woman’. I was very critical of that, which was easy for me to do when I was 35.”

Avrum:

No vested interest, either.

*However, he does have a personal story to share…*

- His wife got breast cancer at age 45
- She was treated with chemotherapy and at the same time she went into menopause
- She was very symptomatic (although, she didn’t complain for two years)
  - Night sweats
  - difficulty sleeping
  - joint pains
  - Palpitations
- “But women are supposed to suck it up and take it. And she did.”
- Struggling to read⇒ *“Then she started to find that reading, which is her passion, was now being challenged, because when she’d read a book, she couldn’t remember what she had read two or three pages before.”*
- She eventually was put on HRT ⇒ *“It took about two weeks and she was back. She would never go off them.”*

Peter tells a story about how his interest was piqued:

- He met with a woman 5 years ago who had survived ER/PR-positive breast cancer which means her cancer showed sensitivity to estrogen, progesterone
- Very young, in her 40s
- She underwent a hysterectomy, oophorectomy and mastectomies
- “She basically became lost.”
- Unable to get off the couch
- She described a feeling of fog
- She was told, “Once the chemo is done, you will feel better.”
- Three years after the chemo, she felt worse
- It finally occurred to her and to her husband that maybe this had something to do with the fact that at the age of 42, overnight she lost every sex hormone in her body
- She couldn’t find any doctor on the planet who would prescribe hormone replacement therapy (HRT) to her, because as a breast cancer survivor who’s ER/PR-positive, how could you do such a thing?
- Though she did eventually find someone who was willing to give her a trial.
- She felt immediately better ⇒ Within weeks she felt like she got her life back
- By the time Peter met her, she was on a “very clever regimen”:
  - Topical estriol (not estradiol)
  - She didn’t need progesterone (because she had hysterectomy)
  - Physiologic replacement of testosterone (up to about half a nanogram per deciliter level)

“Her case interested me so much, because I started thinking, ‘Wait a minute. Isn’t she increasing her risk of breast cancer?’ I won’t get into the details of where that took me, which rabbit hole, but it obviously in some way led to a converging discussion that we’re having today.”

## The changing perceptions of HRT, the impact of the Women’s Health Initiative (WHI), and the problems with the WHI [37:45]

*Picking up in the 1950-1960s. . .*

- Robert Wilson’s book, Feminine Forever, has encouraged many women to get on estrogen
- [Premarin](https://en.wikipedia.org/wiki/Conjugated_estrogens) was the primary source of estrogen
  - Premarin, acronym for pregnant mare urine, is still the most used form of estrogen today
  - The company who makes Premarin is who paid Robert Wilson to write Feminine Forever

*In the early 1970s. . .*

- There was a sharp rise in uterine cancer
- Turns out, estrogen, given alone, [can increase uterine cancer by 5-fold](https://www.ncbi.nlm.nih.gov/pubmed/1186789), says Avrum
- So estrogen replacement fell off dramatically

*In the late 1970s. . .*

- It was learned that [progesterone together with estrogen, nullified the risk of uterine cancer](https://www.ncbi.nlm.nih.gov/pubmed/3747849), so HRT started to increase again
- It continued that way until about 2002 when it was estimated that about 16 million women in the United States were taking HRT
  - Either estrogen alone if they didn’t have a uterus, or the combination, if they did have a uterus
  - That constituted about 22% of the appropriate age population in the US

*By 2004. . .*

- HRT use was down from 22% to 10% of age appropriate population

*By 2010. . .*

- HRT use fell to 5%
- This was largely due to the [first publication](https://jamanetwork.com/journals/jama/fullarticle/195120) of the [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative)

[Nurses’ Health Study](https://en.wikipedia.org/wiki/Nurses%27_Health_Study)

- Published in 1995
- ~120,000 nurses were followed for 30 years
- Found that [women who took HRT for 5, 10, or 15 years had no increased risk of breast cancer](https://www.ncbi.nlm.nih.gov/pubmed/7753136)

**Women’s Health Initiative (WHI)**

- Study was initiated in 1996, and first published in 2002
- The theoretical rationale for the study was NOT to see whether it increased breast cancer… what they wanted to see is *did it really have a beneficial effect on the heart and the brain and the bones*

⇒ The WHI had two separate studies

- 1) [Nutritional study](https://www.whi.org/about/SitePages/Dietary%20Trial.aspx)
- 2) [Hormone replacement study](https://www.whi.org/about/SitePages/HT.aspx)

*Problems with the hormone replacement arm of the WHI:*

⇒ The study participants:

- Avg age was 63 (which is 10 years after menopause)
- 70% were very overweight or obese
- >50% were smokers
- Many had hypertension
- “This was not an ideal, healthy sample, by any means.”

> “For economic reasons, it made sense to choose an older population. But this was never a normal population, and as soon as the study came out in 2002, it was immediately extrapolated to all women everywhere.”

⇒ Exclusion of symptomatic women

- “When I first read it, I thought, ‘That can’t be right.’” says Peter
- women who were especially symptomatic were excluded
- The reasoning being is that there was a concern that if you took in women who had serious vasomotor symptoms and they were randomized to the placebo, your drop-out rate would be too high
- That would be alright, if you acknowledge that up front, says Avrum, but the WHI reported “findings” that HRT had [absolutely no benefit on quality of life](https://www.ncbi.nlm.nih.gov/pubmed/12642637/)
  - The reason they found that is because women who were significantly symptomatic were excluded
- New York Times headlined it saying, “[Hormones have no benefit, even on quality of life](https://www.nytimes.com/2003/03/18/us/hormone-therapy-already-found-to-have-risks-is-now-said-to-lack-benefits.html).”
- By the way, the **13% of the women who were symptomatic had a significant improvement**, but they were lost among the entire population

> “13% of the women who were symptomatic had a significant improvement, but they were lost among the entire population.”

## Is this one big conspiracy? The uncanny resemblance of the story of HRT and how the dietary guidelines were created [46:00]

![](https://peterattiamd.com/wp-content/uploads/2019/02/stop-the-presses-1024x310.jpg)

**Figure 6. Major headlines in response to the WHI press release.** Image credit: [blogs.plos.org](https://blogs.plos.org/absolutely-maybe/2015/09/30/the-mess-that-trials-stopped-early-can-leave-behind/)

*A scientific “no-no”*

- **Prior to the release of the actual data**… The WHI put out a huge press release: [Clinical Alert: NHLBI Stops Trial of Estrogen Plus Progestin Due to Increased Breast Cancer Risk, Lack of Overall Benefit](https://www.nlm.nih.gov/databases/alerts/estrogen_progestin.html)
  - Said another way… “We found this increased risk of hormones on breast cancer, so we have to stop our study immediately and have press conference and announce this terrifying finding”
- This is a **big no-no** in scientific communication and publication
- Additionally, the alleged increased risk of breast cancer, was **not statistically significant**

> “In my business, you don’t get to go into publication and say, ‘Gee, we didn’t get any significant results here. We found something that looks problematic or interesting and maybe we need to do more research.’ But not significant? That’s what really first gave us pause. Why are they heralding this strange finding, for what purpose? Why are we wanting to scare an audience in advance of actually offering the real data? That’s what got our skeptical neurons flaring.”

***So, was this a conspiracy?***

“You hear this and it stinks of conspiracy theory. Except that I’m the most anti-conspiracy theory guy out there. I typically attribute to incompetence, rather than malice.” says Peter

Carol’s reaction:

> “I think they were behaving just like scientists who went into this research with a strong belief that HRT is harmful to women and in particular, increases the risk of breast cancer.”

- For example, [Jacques Rossouw](https://en.wikipedia.org/wiki/Jacques_Rossouw), who was the cardiologist who led the Women’s Health Initiative, had published [an article in 1996 saying “it’s time to bring the HRT bandwagon to a halt”](https://www.ncbi.nlm.nih.gov/pubmed/8941130)
- “When you go into a research project with a belief that you really are sure of, you see in the data what you expect to see in the data.”

Avrum’s reaction:

> “The 2002 WHI paper says that this increased risk of breast cancer almost reached nominal statistical significance. I don’t know of any other article anywhere that states that. Statistically significant doesn’t mean it’s true, but it means the finding has a less than 1 in 20 chance of being a coincidence, so it’s worthy of investigation. But ‘almost reached nominal statistical significance’? That sounds like you’re straining to reach a conclusion that you didn’t reach.”

**It is unprecedented that a press release would be put out prior to the study with the data:**

“I don’t know of any other situation where JAMA or the New England Journal came out with a press release before the published article was available to doctors to read.” says Avrum

[Robert Langer](https://robertdlanger.com/) revealed the story behind this…

- There were 40 principal investigators distributed across the country
- They were summoned to a meeting to discuss the paper that was going to appear in JAMA
- They were told for the first time what this press release was going to consist of… and their reaction was “*You can’t do this*.”
- They were told, “Too late. The article’s been published in JAMA and it’s at the warehouse ready to be sent out.”

*So, how could this be a conspiracy?*

- By who exactly?
- Because most of the investigators themselves never saw that first article

**The real reason for this?**

- The pressure felt by the investigators to come up with a significant finding since so much money was spent and the stakes were so high

*⇒ Some shocking quotes:*

- [Rowan Chlebowski](https://www.cityofhope.org/faculty/rowan-chlebowski), one of the 3 writers of the WHI publication, said the following (paraphrase): “You know, this is the most expensive study ever done. By the time we’re finished, it will cost about a billion dollars. So, if we think we have found something and the results don’t quite add up, **the statistical police have to leave the room**.”
- [Garnet Anderson](https://www.fredhutch.org/en/labs/profiles/anderson-garnet.html), the statistician for the WHI, said the following (paraphrase): “Well, when it’s an issue as important to women as breast cancer, we intentionally set the bar low.”

*⇒ One more explanation offered by Carol:* **Negativity bias**

- The WHI was trying to gain attention in the media… and people are more drawn to negative news than to positive news and certainly negative news is what sells
- [Jacques Rossouw](https://en.wikipedia.org/wiki/Jacques_Rossouw) told a reporter from the New York Times that they wanted to do it this way to “break into the noisy news cycle” and get attention for the study

## Why people (falsely) think estrogen causes a 25% increase in breast cancer, and a lesson in absolute vs. relative risk [57:15]

**A very common question Peter gets from women:** *Doesn’t HRT increase the risk of breast cancer by 25%?*

*⇒ Where did this number come from?*

**2013 JAMA paper**: [Menopausal Hormone Therapy and Health Outcomes During the Intervention and Extended Poststopping Phases of the Women’s Health Initiative Randomized Trials](https://jamanetwork.com/journals/jama/fullarticle/1745676) (Manson et al., 2013)

**2015 JAMA pape**r: [Breast Cancer After Use of Estrogen Plus Progestin and Estrogen Alone, Analyses of Data From 2 Women’s Health Initiative Randomized Clinical Trials](https://jamanetwork.com/journals/jamaoncology/fullarticle/2250347) (Chlebowski, et al., 2015)

Randomization of the study:

- You had two cohorts of women
  - Cohort #1: You had women who had already undergone a hysterectomy and they were randomized to estrogen (CEE, conjugated equine estrogen) or placebo
  - Cohort #2: And women whose uterus was still in place were randomized to CEE plus MPA ([medroxyprogesterone acetate](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate)) versus a placebo
- Randomization was one-to-one throughout

Results:

- The women in cohort 1, those that were randomized to just estrogen, *had no increased risk of breast cance*r
  - They actually had a 21% decreased risk, but it was not statistically significant
- The women in cohort 2, those that received both estrogen and progesterone, *there was a reported 26% increase in risk of breast cancer* compared to placebo
  - However, it also **wasn’t statistically significant**… “So by scientific standards, we think that could have been caused by chance alone.”
  - P-value was below .05

⇒ Even though the 26% increase was ***not significant***, there was an explanation for this increase:

**This article provides the explanation**: [Menopausal hormone therapy and breast cancer: what is the evidence from randomized trials?](https://www.tandfonline.com/doi/abs/10.1080/13697137.2018.1514008?journalCode=icmt20)

- There are 2 ways you “find” there to be an increase in risk
  - 1) You can have a real increase in risk in the non-placebo group
  - 2) Or, the women who were randomized to placebo, had a lower than expected risk of breast cancer
- And in the case of this study, you find that it was in fact reason #2, the placebo had a lower than expected risk

*⇒ So, what was the explanation for this?*

- In cohort 2, **many of the placebo women had previously (before the study) been on HRT**
- And having previously been on HRT, they therefore had a lower risk of breast cancer (the opposite of what the paper was suggesting would happen to someone on HRT)

![](https://peterattiamd.com/wp-content/uploads/2019/02/Screen-Shot-2019-02-21-at-3.11.37-PM-1024x742.png)

**Figure 7. Chart showing the actual change in breast cancer risk when taking out the women in the placebo group who had previously taken HRT.** Image credit: ([H. N. Hodis & P. M. Sarrel, 2018](https://www.tandfonline.com/doi/full/10.1080/13697137.2018.1514008))

> “That’s an example of the kind of data manipulation that went on to try to create the impression of a real finding that really was not there.”

**Absolute vs. Relative risk**

- Additionally, the 26% increase was the “relative” increase
- The absolute increase in risk was 0.9 cases per 1,000, that’s 9 cases per 10,000
- That is a less than 1% absolute risk increase even it the 26% increase was shown to be significant (which is wasn’t)

Another example of absolute vs relative risk:

“Let’s say that eating a grapefruit doubles my risk of bunions. I need to know what numbers we’re talking about. If the numbers jumped from one person to two persons out of a hundred or out of a thousand, that’s not a very big thing. Let’s say it’s doubling the risk, but it’s trivial. If the numbers double from 500 to 1000 in a group of 10,000, then we might have a finding we should be paying attention to.”

The lack of reported absolute risk:

Carol laments, “Avrum and I were at pains in our book to see when we would read studies that reported an increase risk or reduced risk of something to see what the absolute number were. In many cases, we couldn’t even find what the absolute numbers were.”

## The truth about progesterone and cancer risk, and the best types of estrogen and progesterone to be taking [1:09:00]

**What about progesterone (MPA)? Does is play a role in the increase in breast cancer?**

⇒ Peter prefaces the question with the fact that when looking at WHI data, the women you got both progesterone and estrogen had an increased risk in breast cancer compared to those that just got estrogen

Avrum:

“First, let me go back to saying that the increased risks seen with the combination was not statistically significant, did not hold up, and was due largely a problem with the control group. If you accept that, anything that we say at this point is irrelevant. . .but I’ll take your question.”

“What has resulted from that is people are saying, ‘Well, the problem really isn’t estrogen. We’ll give estrogen a pass. The problem is progesterone.’”

In fact, this particular synthetic progesterone ([MPA, medroxyprogesterone acetate](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate)) is being blamed

“Well, I’m not sure there’s a problem because the numbers don’t really bear that out. If there is a problem, there are now forms of progesterone, which are not synthetic, that are now being advised and used; and thus far, have not been associated even with any finding of an increased risk of breast cancer.”

**Progesterone as a treatment for breast cancer**

**1** In a [randomized trial comparing tamoxifen to progesterone in the 1970s](https://www.ncbi.nlm.nih.gov/pubmed/483409), progesterone did a little better than tamoxifen, but because in the dosage used, it was associated with increase fluid retention, and women became nauseated, it lost out to tamoxifen, but it was used to treat breast cancer.

**2** There was a [study that came out of India that found that giving an injection of progesterone around the time of surgery to remove primary breast cancer, significantly improved the prognosis](https://www.ncbi.nlm.nih.gov/pubmed/21670457), and decreased the risk of recurrence.

**Are “bioidentical” hormones better?**

⇒ Estrogen:

- “The word bioidentical is a buzzword.” says Avrum
- Bioidentical really refers to [estradiol](https://en.wikipedia.org/wiki/Estradiol), which is the leading circulating estrogen in a woman’s body
- Bioidentical is also used for what is prepared by pharmacists based on prescriptions written by local practitioners where quality control is lacking.
- “There is no clear dose equivalency. Every responsible investigator I know wants to make the point that buying something because it’s got the word bioidentical, which sounds comforting, is a mistake.”
- [Premarin](https://en.wikipedia.org/wiki/Conjugated_estrogens) (the most common estrogen medication) is an acronym for pregnant mare urine
  - It is the longest studied form of estrogen.
  - We, now, have 60 years of data with Premarin.
  - Most of the studies that show the benefit for estrogen are studies that were done on Premarin
  - Premarin contains at least 10 different forms of estrogen, including some that are the most beneficial forms of estrogen for brain health, which is not present in “bioidentical forms” such as estradiol or estriol.
  - “My preference is Premarin because we have the most data supporting it.” says Avrum

⇒ Progesterone:

- “As far as progesterone is concerned, micronized bioidentical progesterone appears to be the safest form of progesterone administration.”

**The blanket assumption is that estrogen causes breast cancer**

- However, to the contrary, as women get older and have lower estrogen levels, the rates of breast cancer increase.
- What do you think explains the mechanism by which estrogen withdrawal and/or removal (same for progesterone) is increasing this risk of cancer?

> “The best answer I can give is we think we understand the environment that is friendly to a cancer, which is the environment in which the cancer develops. We try to change that environment to make it less conducive to the continued growth of the cancer. That means in a low estrogen environment, you might use estrogen because that is now unfriendly to the cancer. In a high estrogen environment, you might remove estrogen. Same with testosterone. Exactly how that works, I would use a lot of fancy words, and they would try to cover my ignorance.”

## The Women’s Health Initiative: the reported findings, walking back their bold claims, and their hesitance to admit they were wrong [1:17:45]

**First publication of results (2002)**: [Risks and benefits of estrogen plus progestin in healthy postmenopausal women: Principal results From the Women’s Health Initiative randomized controlled trial](https://jamanetwork.com/journals/jama/fullarticle/195120)

Reported findings:

- The combination of estrogen and progesterone increases the risk of breast cancer ⇒ “not true”
- Increases the risk of heart attacks
- Increases the risk of cognitive decline
- Decreases the risk of colon cancer
- Helps protect the bones

[2003 paper in JAMA](https://www.ncbi.nlm.nih.gov/pubmed/12824205)

- The article claimed “borderline” statistical significance for the increased risk of breast cancer.

[2006 paper](https://www.ncbi.nlm.nih.gov/pubmed/16609086)

- In 2006, a follow-up article said that that reported increased risk in that population had disappeared with continued follow up
- “That article never made the headlines, and most people aren’t even aware of it.”

**Walking back their claims:**

- [JoAnn Manson](https://en.wikipedia.org/wiki/JoAnn_E._Manson) is trying to course correct ⇒ Peter says he heard her on [NPR](https://www.npr.org/) making the point that the recommendations went too far and that “there really are a subset of women, especially those entering menopause, who have symptoms, who deserve to be treated, and we made a mistake.”

“[The smallest dose for the least amount of time.](https://www.npr.org/sections/health-shots/2015/11/09/454710392/hormones-may-help-younger-women-with-menopause-symptoms)” ⇒ this is now the “mantra” from the WHI investigators

- But, “there’s absolutely no empirical evidence to support that advice” say Carol
- “But I think it does represent a compromise in terms of the Women’s Health Initiative’s realization that HRT really was beneficial for quality of life issues for women in menopause.”

⇒ [2017 paper from JoAnn Manson](https://jamanetwork.com/journals/jama/fullarticle/2653735) that showed their original conclusions “went too far”

> “What they were not prepared to do was to consider HRT’s benefits over the long haul for women in later years and reducing the risk of osteoporosis, dementia, and heart disease. That they are not willing even yet to suggest that HRT has any prolonged benefits overtime.”

**Studies showing benefits of HRT**

- This [study by Nananda Col](https://www.ncbi.nlm.nih.gov/pubmed/9087469) showed that if every woman in the United States do hormone replacement therapy (HRT) it would **increase the median survival of women by 3.3 years** in this country
  - “There’s no other intervention I can think of that has such a great consequence for longevity.”
- This report suggests [tens of thousands of women died prematurely](https://ajph.aphapublications.org/doi/abs/10.2105/AJPH.2013.301295) as a result of being taken off hormone therapy

## Brain benefits of HRT, Alzheimer’s disease in women, and estrogen as a preventative treatment for AD [1:22:45]

**Women are two times more likely to die of Alzheimer’s disease than men**

*Why? … Peter’s hypothesis:*

- The reason is not that women live longer than men (they live ~2 years longer than men)… that data doesn’t support this being the reason
- Peter’s hypothesis is that it has to do with the fact that women have an abrupt loss of hormones whereas men have a gradual loss of hormones

What does the data say about Alzheimer’s disease and taking estrogen?

- For every woman diagnosed over 60 with breast cancer, two women are diagnosed with Alzheimer’s
- The cure rate for early diagnosed breast cancer is now approximately 90%
- The cure rate for Alzheimer’s disease is zero
- We have treatments for breast cancer
- And there is no treatment for Alzheimer’s
- The one **potential preventive medication is estrogen which can reduce the incidence of Alzheimer’s disease by between 20 and 50%** depending upon the study you look at
- [Here’s one study](https://www.ncbi.nlm.nih.gov/pubmed/12413371)

> “The findings converge from all of those directions of research to show the benefits of estrogen on the brain”

*Does it matter if HRT is “natural”?*

[Barbara Sherwin](https://www.mcgill.ca/psychology/barbara-b-sherwin), a psychologist at McGill University answer it this way, “I get so crossed when people say taking HRT is not natural. What’s not natural is for a woman to live to be 85 or 90 years old. And if estrogen is something that can help women to live with healthy mental functioning in those later years, then I am all for it.”

Peter agrees:

“If we’ve decided to live a society where we value living beyond our reproductive years, then why aren’t we entertaining things that are ‘unnatural’? It really is an asinine argument to me.”

**See chapter 5 of Estrogen Matters for more on this topic with references**

## The impact of HRT on heart disease, the ideal time to start HRT, and the risks associated with HRT [1:26:45]

**The** [**report from the 2002 WHI**](https://jamanetwork.com/journals/jama/fullarticle/195120) **suggested HRT increased risk of heart disease**

*Problems with the WHI study:*

1 The study population was not cardiovascularly healthy

- Median age was 63
- 70% were overweight
- 34% were obese
- 40% were smokers
- Many had high blood pressure

2 Estrogen is capable of causing platelet clumping

- If you already have blood vessels that are narrowed by preexisting heart disease, a platelet clumps can further narrow the blood vessel and caused a cardiac event
- As a result of that, it is recommended that women with preexisting cardiovascular disease not start on hormone therapy

**When is the ideal time to start HRT?**

- Ideally around menopause
- Starting HRT within the first 10 years of cessation of periods
- “There is no increased risk if a woman begins HRT at the time of menopause. . .with no preexisting cardiac vascular disease.”

> “If you take a woman entering the normal, perimenopausal to menopausal state, and she has no preexisting cardiovascular disease. . .the data make it pretty clear there’s no increase in her risk of cardiovascular disease ongoing.”

**Is it safe for older women to receive HRT?**

- However, that doesn’t mean that older women must never take it
- In fact, that increased risk of cardiovascular events is seen generally **only during the first year that a woman starts hormones**

*Hypothetical case:*

- 60 year old women
- She went into menopause at 50, so she has a window now that is 10 years
- There is zero evidence that she has existing cardiovascular disease
- She begins hormone replacement therapy

⇒ *How clear are the data that she is also not increasing her risk of cardiovascular disease?*

- Yes, “she’s probably okay”
- “But… we are not here trying to increase sales of hormones”

> “What we want to do is empower women so that they are not to be given some curt answer when they ask about [their doctor] about it. This is a legitimate course of action to follow, but with and after a discussion with your physician.”

**Defining the risks**

*Another hypothetical case study:*

- A woman who has never been on hormones
- more than 10 years out of menopause
- With some preexisting clinical or subclinical atherosclerosis

⇒ *Is her risk only one year after starting therapy and then it returns to baseline?*

- Her risk is highest during that first year
- And then it diminishes and diminishes and diminishes.
- So, if during the first year an event doesn’t occur, the likelihood is they will be well and won’t have one of these events later on

**How long do symptoms of menopause last?**

- Most people think a 60 year old woman who took hormones eight years ago and has not been on them anymore, can’t possibly have symptoms…
- No, they do indeed can have symptoms
- The average length of time a woman has symptoms during menopause is seven years
- For some women, it’s 10 or 12 or 15
- Avrum even has patients in their 70s who are still suffering from menopause

**Papers showing HRT is beneficial for heart disease**

- [Estrogen and coronary heart disease in women.](https://www.ncbi.nlm.nih.gov/pubmed/2005736)
- [1991 report that estrogen can help reduce the incidence of heart disease](https://www.nejm.org/doi/pdf/10.1056/NEJM199109123251108)

**See chapter 3 of Estrogen Matters for more on this topic with references**

## The benefits of estrogen on bone health, and the incidence and mortality of hip fractures [1:33:15]

> “We now know that as many women in the United States will die each year of a hip fracture as the number who will die of breast cancer.”

**Mortality and hip fractures**

- Approximately [21% of women who fracture their hip will die within a year of the hip fracture](https://www.ncbi.nlm.nih.gov/pubmed/27172936)
- That number is approximately 40,000, which is the number of women who die in this country of breast cancer every year

**Osteoporosis**

- Looking at bone mineral density is the way we currently test for osteoporosis
- However, bone mineral density a poor substitute but it’s the best we have
- The true test is how much a bone can be flexed before it snaps

Current treatments for osteoporosis:

1 Calcium and vitamin D

- These things help mostly with the outer shell of the bone
- But it is the internal girder network of the bone which is important
- In a postmenopausal women who is not on estrogen, calcium and vitamin D have no protective effect against hip fracture.

2 [Bisphosphonates](https://en.wikipedia.org/wiki/Bisphosphonate)

- They do help prevent hip fracture almost as well as estrogen does
- However, the problem is if you take them for longer than five years, you have an increased risk of fractures within the femoral shaft
- They’re called [atypical femoral fractures](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3710007/), and that increased risk has been used to say that bisphosphonates should not be used for longer than five years

3 Estrogen

- You can take estrogen as long as you take it and your bone elasticity and your bone health is preserved
- There’s nothing as good as estrogen
- [Studies show it can decrease risk of fracture by up to 50%](https://www.ncbi.nlm.nih.gov/pubmed/7421945)

> “Estrogen will decrease the risk of osteoporotic hip fracture by up to 50%. Better than any treatment available over the long term.”

**See chapter 4 of Estrogen Matters for more on this topic with references**

## Colon cancer: Can HRT reduce the risk of colon cancer? [1:38:15]

*Colon cancer mortality*

- Not as lethal as pancreatic or lung cancer
- But it is more lethal than breast cancer

**What does HRT do to increase or decrease a woman’s risk of colon cancer?**

*A number of significant studies have shown that it does indeed reduce the risk of colon cancer*

- [Estrogen protects against the growth of cancerous cells in the colon](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836673/)
- [Nurses’ Health Study showed a 20-25% decreased risk of colon cance](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4981802/)r among women taking estrogen
- But… we don’t know why

*Women’s Health Initiative*

- At the beginning with the WHI, they were claiming that estrogen reduced longevity and increased women’s mortality from all causes over the years

> “It was quite an exaggerated claim and over the years they have been walking back from that one. . .I mean, they were really looking to scare people for some reason at that point.”

## Diabetes: Can HRT reduce the risk of developing diabetes? [1:40:30]

Diabetes seems to decrease when taking estrogen

- Why?
- “Because the numbers suggested it. That’s all. I would like to see many more studies before we reach that conclusion. And you’ll note we didn’t mention diabetes in the book.”

## The downsides of hormone replacement therapy (HRT) [1:41:30]

[Pulmonary embolism](https://en.wikipedia.org/wiki/Pulmonary_embolism) (blockage of an artery in the lungs) resulting from a [venous thromboembolism](https://en.wikipedia.org/wiki/Venous_thrombosis) (blood clot)

⇒ Magnitude of risk:

- The risk is small
- With a blood clot in a vein in part of the body (the leg, for example) it is usually not very serious unless a piece of the clot breaks off, and goes to the lung
- A pulmonary embolism can be fatal
- The incidence is of this small, however…
- “It’s significant enough that if the patient has a condition or is taking something that can predispose to that kind of clot, it must be a consideration before somebody starts on hormones.”

[Gallstones](https://en.wikipedia.org/wiki/Gallstone)

- Statistically valid finding
- [Cholecystectomy](https://en.wikipedia.org/wiki/Cholecystectomy), removing a gallbladder among women who are on hormones, is a not infrequently reported finding and has to be considered

## How to approach your doctor who may already have a very strong point of view about HRT [1:42:15]

Avrum:

The reason we wrote the book with references on every chapter trying to give people the data on which our conclusions are based was to empower women and . . . to make you a better consumer of healthcare so that when you go to your physician, you and your physician together can work out the best program for you to follow.

> “And our conclusion from the book is that the benefits of hormones far outweigh the downsides and hormones have been unfairly excluded from medical regimens that women should at least be offered for consideration.”

Carol:

“The less is more movement in medicine is designed to educate the public that sometimes you don’t need to medicate every possible problem you could ever have in your life. And that we’re taking too many medications and too many drugs and so forth and so forth. And with much of this I completely agree, but the alternative to over medicalizing our problems is not to under medicalize them either. . .

. . .I think that many women influenced, properly, by feminist critiques of medicine think that there’s something unfeminist about taking HRT. Something anti woman about taking HRT. ‘I’m not enough of a woman if I need to take hormones’, or that kind of argument. And I think it’s as much a feminist argument to say what is best for women overall, what is best for a particular woman who is dealing with symptoms that are painful and difficult and complex.”

> “The issue of HRT for women is not that there’s a correct ideological stance to be taken, but rather one that needs to look at what is best for most women, and for any given woman, making this decision.”

**Estriol and testosterone**

- Estriol: We don’t have large scale studies on [estriol](https://en.wikipedia.org/wiki/Estriol), so Avrum advises to be cautious
- Testosterone: [It has been associated with the development of breast cancer](https://www.ncbi.nlm.nih.gov/pubmed/15352045)
  - “It can show some stimulation of growth of breast cancer in culture, and that too has to be looked at very carefully.”

## What kind of research needs to be done to answer the remaining questions about the benefits and risks of HRT? [1:48:30]

Peter points out that *HRT seems to have an impact on 80-85% of the diseases that lead to death in women* including, but not limited to:

- Cancer
- Atherosclerosis (all of the cardiovascular and cerebrovascular diseases)
- Alzheimer’s disease
- Bone fractures

*Will there ever be a major clinical trial looking at the benefit of HRT on these issues?*

- “No, and the reason we won’t is the idea that every truth can only be determined by a prospective double blind randomized study is simply not holding up.”
- The cost and complexity of repeating a study of the magnitude of the WHI is standing in the way

*Does the scientific community people still view this as “case closed”?*

- Not quite
- Avrum points out some of the influential people who have endorsed their book:
  - [Vince DeVita](https://en.wikipedia.org/wiki/Vincent_T._DeVita) (who wrote the [“Bible on oncology”](https://www.amazon.com/DeVita-Hellman-Rosenbergs-Cancer-Principles-dp-1496394631/dp/1496394631/ref=mt_hardcover?_encoding=UTF8&me=&qid=))
  - [Jerry Kassirer](https://en.wikipedia.org/wiki/Jerome_P._Kassirer) (editor in chief of the New England Journal of Medicine)
  - [Leslie Turnberg](https://en.wikipedia.org/wiki/Leslie_Turnberg,_Baron_Turnberg) (president of the Royal Society of medicine in England)
  - [Phyllis Greenberger](https://www.healthywomen.org/about-us/medical-expert/phyllis-e-greenberger-msw?destination=14138) (CEO of the women’s Science Cooperative)

**What kind of research needs to be done to help us answer the questions that we have remaining?**

- There won’t be anything as big as the women’s health initiative (complex, costly, and “already done”)

*Is a randomly controlled trial (RCT) the only useful way to answer these questions?*

- Carol argues that “No”, [observational studies](https://en.wikipedia.org/wiki/Observational_study) can be useful in this field

*Peter’s take on RCTs vs epidemiology:*

1 Nutritional epidemiology is effectively garbage, however, that doesn’t mean that all epidemiology is useless. Epidemiology may in fact have less of the data crisis when the intervention is simpler and certainly taking HRT is simpler than remembering what you ate over the past seven days.

2 it is impossible to eliminate [healthy user bias](https://en.wikipedia.org/wiki/Healthy_user_bias) from epidemiology and thus this must always be acknowledged

3 We are lulled into a false sense of confidence with randomized control trials, and yet virtually all of them have some measure of what’s called performance bias… “just because something is a randomized control trial, doesn’t mean it is free of bias”

**For more on the biases associated with epidemiology, check out the Nerd Safari: [Studying Studies: Part III – the motivation for observational studies](https://peterattiamd.com/ns003/)**

**The demands on researchers to publish something important leads to bad science:**

> “The demands on researchers to publish or perish has meant a proliferation of badly analyzed studies. So this is where you’re an epidemiologist, you’ve got thousands and thousands of people in your sample, and you don’t find what you thought you would find. So instead of saying, ‘we find no connection between these two things’, they then engage in these statistical practices that are no-nos for any statistician or scientist to do. Yet the results find homes in medical journals.”

![](https://peterattiamd.com/wp-content/uploads/2019/02/table-1-grapefruit-663x1024.png)

**Figure 8. Preposterous findings claiming certain activities increase the risk of breast cancer that even though the findings weren’t replicated, all of them found homes in medical journals.** Image credit: ([Bluming and Tavris, 2009](https://www.researchgate.net/publication/24355772_Hormone_Replacement_Therapy_Real_Concerns_and_False_Alarms))

## Cancer: Our evolving understanding and the future of treatment [1:59:15]

[Acute promyelocytic leukemia](https://en.wikipedia.org/wiki/Acute_promyelocytic_leukemia)

- This used to be one of the hardest malignancies to treat
- This is a condition where the bone marrow is full of very immature angry cells called [promyelocytes](https://en.wikipedia.org/wiki/Promyelocyte)
- Even intensive chemotherapy was associated with only a 2-5% possible response rate with no complete remission and everybody died

*⇒ Maturation arrest*

- About 15 years ago, several investigators found that the problem is not that these terrible looking cells are multiplying too quickly, it’s that these cells are facing a *maturation arrest*
- Immature cells multiply very quickly (That’s how we go from being two cells to being an organism in nine months)
- As cells mature, they multiplied less actively
- If there’s a maturation arrest (the cell cannot mature beyond a particular point) the cells grow very quickly and they kill the patient
- In the case of acute promyeloblastic leukemia, there’s a form of vitamin A called trans retinoic acid that can given to the patient as a treatment
- This treatment can remove the maturation arrest, and the abnormal leukemic cells proceed through normal maturation and the disease disappears and the patient is better

> “So looking at the tumor cell as the enemy instead of as the smoke behind the fire of the maturation arrest was misguided. . .I think we’re going to find in many malignancies that our understanding of cancer is going to change and we’re going to stop trying to identify the tumor cell as the enemy.”

Peter adds:

- Investigators are starting to look at [stromal cells](https://en.wikipedia.org/wiki/Stromal_cell)
- Up until recently, we have focused almost exclusively on the actual cell that has undergone the genetic alteration to render it a cancerous
- But the stromal cell that surrounds it, the environment in which it lives in cellularly, is now where people are starting to realize there’s something there
- Now how we target that for treatment becomes a second question

## Welcoming the critics: Avrum and Carol want to start a conversation [2:02:00]

Peter thanks Carol and Avrum for writing the book:

“I know you’re gonna make some enemies writing a book like this because you’re going up against effectively established medical entities that have a position, and it becomes easy [for them] to discredit people.”

Avrum has a word for the critics:

> “We welcome the criticism and the discussion. And rather than make enemies, we welcome critics, and that way we will all learn. We don’t claim to have the final answer, but we think that this book [Estrogen Matters] represents an important step forward in empowering women and helping them live longer and live better.”

## Are there racial differences in benefits and risks with HRT? [2:04:15]

When we talk about race, we know that there are different racial predispositions to breast cancer. Has anything come out of all of the reevaluations of the data that would suggest one way or another that Caucasian, African-American, Hispanic, Asian women might actually benefit or be harmed differentially from hormones?

- “To the best of my knowledge, no” says Avrum
- Although, the overwhelming majority of studies are looking at caucasians
- That said, national menopause societies in every country from India and African nations and South America and Canada and others have all endorsed the beneficial use of HRT for women

## The reactions to Estrogen Matters, and why it is a must read [2:09:15]

**The London Times put out a favorable review of the book**: [Hormone therapy: why everything you thought you knew about HRT is wrong](https://www.imsociety.org/manage/images/pdf/298c708cc7c6aea5af8d9c766b0a5a69.pdf) by Anna Maxted

**Mostly silence from any potential critics:**

- By and large, it seems like the investigators, the PIs from the WHI, have been quite silent
- They get the feeling that they do not have much incentive to respond

**Why you should read Estrogen Matters**:

- This podcast is a not substitute for people reading the book
- Peter is adamant, “I think everybody should make the effort to read this book and should actually follow up in the references. . . because what you did nicely is you laid out the time course of the literature of the studies, and I think that’s an important exercise.”
- Avrum: “Our goal was to make the book readable enough for lay readers. Certainly of course for women personally concerned about this issue so that they will understand what the evidence shows without having to read every study at hand if they don’t want to.”
- Carol: “So our goal was to make it readable for general readers, but also to provide the sources and information for those who want to know in more detail what the science shows.”

**Another paper worth reading**:

*The first paper Avrum wrote with Carol in 2009*: [Hormone Replacement Therapy, Real Concerns and False Alarms](https://www.researchgate.net/publication/24355772_Hormone_Replacement_Therapy_Real_Concerns_and_False_Alarms)

Per Avrum: “Carol took the data that I put in and she included her Carol touch. . .her personality is embedded in the paper making it witty and enjoyable to read as well as the data.”

## HRT after a diagnosis of breast cancer [2:13:45]

Still an open question without an obvious conclusion

- However, some evidence suggesting it might not be harmful, and could be beneficial:
- For example, [getting pregnant after having a diagnosis of breast cancer does not compromise the prognosis](https://ascopubs.org/doi/abs/10.1200/JCO.2017.35.18_suppl.LBA10066)
- There are approximately 15 studies on the subject and only 1 of them showed an increase in breast cancer risk

Avrum did a [study administering HRT to his patients who had had breast cancer](https://www.ncbi.nlm.nih.gov/pubmed/8296203)

- Over 14 years
- Showed no increased risks of local recurrence, contralateral breast cancer, or distant recurrence among the women who took hormones, compared to the women who didn’t, when they were matched stage for stage

**See chapter 6 of Estrogen Matters for more on this**

**Ending with a pertinent quote from JFK:**

> “The great enemy of truth is very often not the lie–deliberate, contrived and dishonest–but the myth–persistent, persuasive and unrealistic. Too often we hold fast to the cliches of our forebears. We subject all facts to a prefabricated set of interpretations. We enjoy the comfort of opinion without the discomfort of thought.” – John F. Kennedy

§

## Selected Links / Related Material

## The following table was adapted from an email from Avrum Bluming

*We want to empower women to play an active role in the life choices they make, together with their physicians, in evaluating the benefits and risks of HRT. We are concerned with the disservice done to peri and postmenopausal women who are encouraged to take the following:*

![](https://peterattiamd.com/wp-content/uploads/2019/02/Screen-Shot-2019-02-22-at-12.34.57-PM-1024x861.png)

## Top links/articles/references

1. **Carol and Avrum’s book**: [Estrogen Matters: Why Taking Hormones in Menopause Can Improve Women’s Well-Being and Lengthen Their Lives — Without Raising the Risk of Breast Cancer](https://www.amazon.com/Estrogen-Matters-Hormones-Menopause-Well-Being/dp/0316481203)
   1. And [CLICK HERE](https://www.dropbox.com/s/6gk4pil6o1plxt2/HRT_recent_reports_011219.pdf?dl=0) for a list of recent updates since the book was published
2. **2019 LA Times article written by Carol and Avrum**: [Once and for all: Hormone replacement is good for women](https://www.latimes.com/opinion/op-ed/la-oe-bluming-tavris-hormone-replacement-therapy-20190131-story.html)
3. **Avrum urges interested readers and physicians to read this important paper**: [Menopausal hormone therapy and breast cancer: what is the evidence from randomized trials?](https://www.tandfonline.com/doi/abs/10.1080/13697137.2018.1514008?journalCode=icmt20)

## All other related material

**Carol’s book that is one of Peter’s favorite books and most gifted books ever**: [Mistakes Were Made (But Not by Me)](https://www.amazon.com/Mistakes-Were-Made-But-Not/dp/0151010986/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Carol Tavris | (amazon.com) [4:15, 10:15, 49:15, 55:45]

**Carol and Avrum’s book discussed throughout the podcast**: [Estrogen Matters: Why Taking Hormones in Menopause Can Improve Women’s Well-Being and Lengthen Their Lives — Without Raising the Risk of Breast Cancer](https://www.amazon.com/Estrogen-Matters-Hormones-Menopause-Well-Being/dp/0316481203) by Avrum Bluming and Carol Tavris | (amazon.com) [4:45, 9:15, 23:00, 31:30, 44:15, 51:15, 1:22:45, 1:44:30, 1:56:45, 2:02:00, 2:08:45, 2:13:45, 2:15:45]

**Avrum was formerly a senior investigator at the**: [National Cancer Institute](https://en.wikipedia.org/wiki/National_Cancer_Institute) | (wikipedia.org) [4:45]

**The billion dollar study on women responsible for the current dogma surrounding HRT in which it claimed HRT causes breast cancer, heart disease, among other things**: [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) | (wikipedia.org) [7:30, 20:45, 39:45, 41:45, 49:45, 1:09:00, 1:39:30, 2:08:00]

**First publication of the WHI**: [Risks and benefits of estrogen plus progestin in healthy postmenopausal women: Principal results From the Women’s Health Initiative randomized controlled trial](https://jamanetwork.com/journals/jama/fullarticle/195120) (Rossouw et al., 2002)

- Here is the [PDF](https://jama.jamanetwork.com/data/Journals/JAMA/4840/JOC21036.pdf)

**2003 publication**: [Influence of estrogen plus progestin on breast cancer and mammography in healthy postmenopausal women: the Women’s Health Initiative Randomized Trial](https://www.ncbi.nlm.nih.gov/pubmed/12824205) (Chlebowski et al., 2003)

**2004 publication**: [Effects of conjugated equine estrogen in postmenopausal women with hysterectomy: the Women’s Health Initiative randomized controlled trial.](https://www.ncbi.nlm.nih.gov/pubmed/15082697) (Anderson et al., 2004)

**2006 publication**: [Effects of conjugated equine estrogens on breast cancer and mammography screening in postmenopausal women with hysterectomy.](https://www.ncbi.nlm.nih.gov/pubmed/16609086) (Anderson et al., 2006)

**The first HRT paper written by Carol and Avrum in 2009**: [Hormone Replacement Therapy: Real Concerns and False Alarms](https://www.researchgate.net/publication/24355772_Hormone_Replacement_Therapy_Real_Concerns_and_False_Alarms) (Bluming and Tavris, 2009) [8:30, 14:00, 1:57:30, 2:12:30, 2:17:45]

**Prophylactically removing the ovaries of those who previously had breast cancer to try to keep it from coming back**: [Breast cancer risk after bilateral prophylactic oophorectomy in BRCA1 mutation carriers.](https://www.ncbi.nlm.nih.gov/pubmed/10469748) (Rebbeck et al., 1999) [17:30]

**A book written in the 1940s that oversold the benefits of estrogen and essentially said women should take estrogen forever**: [Feminine Forever](https://www.amazon.com/Feminine-Forever-M-D-Robert-Wilson/dp/B000J00XN0) by Robert Wilson | (amazon.com) [18:15, 24:30]

**1991 article saying ‘time for action, not debate’ that if women took estrogen, they would live longer and healthier**: [Uncertainty about Postmenopausal Estrogen — Time for Action, Not Debate](https://www.nejm.org/doi/pdf/10.1056/NEJM199109123251108) (Goldman and Tosteson, 1991) [19:30]

**Book by Sid Mukherjee which writes about the radical mastectomy procedure**: [The Emperor of All Maladies](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439170916) by Sid Mukherjee | (amazon.com) [24:15]

**1-in-4 (25%) women die of heart disease**: [Women and Heart Disease Fact Sheet](https://www.cdc.gov/dhdsp/data_statistics/fact_sheets/fs_women_heart.htm) | (cdc.gov) [28:45]

**The lifetime risk of dying from breast cancer is 1-in-38 (2.6%)**: [Lifetime Risk of Developing or Dying From Cancer](https://www.cancer.org/cancer/cancer-basics/lifetime-probability-of-developing-or-dying-from-cancer.html) | (cancer.org) [28:45]

**Women have a 1-in-8 (12%) risk of getting breast cancer**: [U.S. Breast Cancer Statistics](https://www.breastcancer.org/symptoms/understand_bc/statistics) | (breastcancer.org) [28:45]

**The lifetime risk for cardiovascular disease is more than 1 in 2**: [What Women Need to Know About Heart Disease](https://www.your-heart-health.com/content/close-the-gap/en-US/heart-disease-facts/women.html) | ([your-heart-health.com](https://www.your-heart-health.com)) [28:45]

**Lifetime risk of heart disease in women is 56%**: Lifetime Risk and Years Lived Free of Total Cardiovascular Disease (Wilkins et al., 2012) [28:45]

**Almost two-thirds (64%) of women who die suddenly of coronary heart disease have no previous symptoms**: [Women and Heart Disease Fact Sheet](https://www.cdc.gov/dhdsp/data_statistics/fact_sheets/fs_women_heart.htm) | (cdc.gov) [28:45]

**Blog post by a woman who was having symptoms of depression related to menopause**: [Finding the positive side of menopause](https://www.thejc.com/lifestyle/features/finding-the-positive-side-of-menopause-1.438301) | Katie Taylor (thejc.com) [31:30]

**1970s report that estrogen alone can increase risk of uterine cancer**: [Association of exogenous estrogen and endometrial carcinoma.](https://www.ncbi.nlm.nih.gov/pubmed/1186789) (Smith et al., 1975) [38:30]

**Report that progesterone together with estrogen, nullified the risk of uterine cancer**: [Prevention of endometrial cancer with progestogens.](https://www.ncbi.nlm.nih.gov/pubmed/3747849) (Gambrell RD Jr, 1986) [39:00]

**Study that followed 120,000 nurses were followed for 30 years**: [Nurses’ Health Study](https://en.wikipedia.org/wiki/Nurses%27_Health_Study) | (wikipedia.org) [40:15, 1:05:15, 1:06:15]

**The Nurses’ Health study found that women who took HRT for 5, 10, or 15 years had no increased risk of breast cancer**: [The use of estrogens and progestins and the risk of breast cancer in postmenopausal women.](https://www.ncbi.nlm.nih.gov/pubmed/7753136) (Colditz et al., 1995) [40:15]

**The two arms of the Women’s Health Initiative**: [41:45]

1. [Dietary modification](https://www.whi.org/about/SitePages/Dietary%20Trial.aspx) | (whi.org)
2. [Hormone therapy](https://www.whi.org/about/SitePages/HT.aspx) | (whi.org)

**The nutrition arm of the Women’s Health Initiative**: [The Women’s Health Initiative Dietary Modification trial: overview and baseline characteristics of participants.](https://www.whi.org/about/Baseline%20Monograph/baseline_DietaryModification.pdf) (Ritenbaugh et al., 2003) [42:00]

**A study from WHI saying that HRT has absolutely no benefit on quality of life**: [Effects of estrogen plus progestin on health-related quality of life.](https://www.ncbi.nlm.nih.gov/pubmed/12642637/) (Hays et al, 2003) [44:45]

**NY Times article reporting that there was no benefit to quality of life with HRT**: [Hormone Therapy, Already Found to Have Risks, Is Now Said to Lack Benefits](https://www.nytimes.com/2003/03/18/us/hormone-therapy-already-found-to-have-risks-is-now-said-to-lack-benefits.html) | Gina Kolata (nytimes.com) [45:30]

**Prior to the release of the actual data, the WHI put out a huge press release about the “terrifying finding” that HRT causes breast cancer**: [Clinical Alert: NHLBI Stops Trial of Estrogen Plus Progestin Due to Increased Breast Cancer Risk, Lack of Overall Benefit](https://www.nlm.nih.gov/databases/alerts/estrogen_progestin.html) | National Heart, Lung, and Blood Institute – NHLBI (nlm.nih.gov) [46:00]

**Jacques Rossouw’s 1996 paper basically saying it’s time to bring the HRT bandwagon to a halt**: [Estrogens for prevention of coronary heart disease. Putting the brakes on the bandwagon.](https://www.ncbi.nlm.nih.gov/pubmed/8941130) (Rossouw, 1996) [48:45]

**Carol’s first book**: [Anger: The Misunderstood Emotion](https://www.amazon.com/Anger-Misunderstood-Emotion-Carol-Tavris/dp/0671675230/ref=asc_df_0671675230/?tag=hyprod-20&linkCode=df0&hvadid=312136634064&hvpos=1o1&hvnetw=g&hvrand=10689402871091193533&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9027583&hvtargid=pla-488053866928&psc=1) by Carol Tavris | (amazon.com) [49:30]

**2013 JAMA paper responsible for the common belief that HRT causes a 25% increase in breast cancer**: [Menopausal Hormone Therapy and Health Outcomes During the Intervention and Extended Poststopping Phases of the Women’s Health Initiative Randomized Trials](https://jamanetwork.com/journals/jama/fullarticle/1745676) (Manson et al., 2013) [57:15]

**2015 JAMA paper responsible for the common belief that HRT causes a 25% increase in breast cancer**: [Breast Cancer After Use of Estrogen Plus Progestin and Estrogen Alone, Analyses of Data From 2 Women’s Health Initiative Randomized Clinical Trials](https://jamanetwork.com/journals/jamaoncology/fullarticle/2250347) (Chlebowski, et al., 2015) [57:15]

**Article explaining how the WHI manipulated stats to show a 25% increase in breast cancer with HRT**: [Menopausal hormone therapy and breast cancer: what is the evidence from randomized trials?](https://www.tandfonline.com/doi/full/10.1080/13697137.2018.1514008) (H. N. Hodis & P. M. Sarrel, 2018) [1:00:00]

**As early as 1944, there were researchers publishing a 25% response rate among patients with measurable breast cancer who were treated with estrogen**: [Influence of Synthetic Oestrogens on Advanced Malignant Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2286289/) (Haddow et al., 1944) [1:07:30]

**In a randomized trial comparing tamoxifen to progesterone in the 1970s, progesterone did a little better than tamoxifen**: [[Endocrine treatment of metastasizing breast cancer in menopausal women. A randomized comparison between tamoxifen (Nolvadex) versus tamoxifen and medroxyprogesterone acetate (Clinovir)].](https://www.ncbi.nlm.nih.gov/pubmed/483409) (Mouridsen et al., 1979) [1:11:30]

**A study that came out of India that found that giving an injection of progesterone around the time of surgery to remove primary breast cancer, significantly improved the prognosis, and decreased the risk of recurrence**: [Single-injection depot progesterone before surgery and survival in women with operable breast cancer: a randomized controlled trial.](https://www.ncbi.nlm.nih.gov/pubmed/21670457) (Badwe et al., 2011) [1:12:00]

**2003 JAMA article showing borderline statistical significance for the increased risk of breast cancer**: [Influence of estrogen plus progestin on breast cancer and mammography in healthy postmenopausal women: the Women’s Health Initiative Randomized Trial.](https://www.ncbi.nlm.nih.gov/pubmed/12824205) (Chlebowski et al., 2003) [1:18:30]

**In 2006, a follow-up article said that that reported increased risk for breast cancer in that population had disappeared with continued follow up**: [Effects of conjugated equine estrogens on breast cancer and mammography screening in postmenopausal women with hysterectomy.](https://www.ncbi.nlm.nih.gov/pubmed/16609086) (Anderson et al., 2006) [1:19:15]

**JoAnn Manson recommending the “smallest dose for the least amount of time”**: [Hormones May Help Younger Women With Menopause Symptoms](https://www.npr.org/sections/health-shots/2015/11/09/454710392/hormones-may-help-younger-women-with-menopause-symptoms) | Patti Neighmond (npr.org) [1:20:15

**2017 paper from JoAnn Manson that showed their original conclusions “went too far”**: [Menopausal Hormone Therapy and Long-term All-Cause and Cause-Specific Mortality, The Women’s Health Initiative Randomized Trials](https://jamanetwork.com/journals/jama/fullarticle/2653735) (Manson et al., 2017) [1:21:15]

**Study that showed that if every woman in the United States did hormone replacement therapy it would increase the median survival of women by 3.3 years in this country**: [Patient-specific decisions about hormone replacement therapy in postmenopausal women.](https://www.ncbi.nlm.nih.gov/pubmed/9087469) (Col et al., 1997) [1:22:00]

**Report suggesting tens of thousands of women died prematurely as a result of being taken off hormone therapy**: [The Mortality Toll of Estrogen Avoidance: An Analysis of Excess Deaths Among Hysterectomized Women Aged 50 to 59 Years](https://ajph.aphapublications.org/doi/abs/10.2105/AJPH.2013.301295) (Sarrel et al., 2013) [1:22:15]

**HRT can reduce the incidence of Alzheimer’s disease by between 20 and 50% depending upon the study you look at**: [Hormone replacement therapy and incidence of Alzheimer disease in older women: the Cache County Study.](https://www.ncbi.nlm.nih.gov/pubmed/12413371) (Zandi et al., 2002) [1:25:00]

**Study that put unhealthy men on testosterone replacement therapy and one year after the study, the men in the testosterone group had a higher incidence of cardiovascular disease, three years after the study initiated the risk was equal, and at five years the men receiving testosterone had a lower risk of heart disease than the men on the placebo**: [Survival and cardiovascular events in men treated with testosterone replacement therapy: an intention-to-treat observational cohort study](https://www.ncbi.nlm.nih.gov/pubmed/27165609) (Wallis et al., 2016) [1:31:00]

**Paper showing HRT is beneficial for heart disease**: [Estrogen and coronary heart disease in women.](https://www.ncbi.nlm.nih.gov/pubmed/2005736) (Barrett-Connor and Bush, 1991) [1:32:45]

**Approx. 21% of women who fracture their hip will die within a year of the hip fracture**: [Hip fracture, mortality risk, and cause of death over two decades.](https://www.ncbi.nlm.nih.gov/pubmed/27172936) (von Friesendorff et al., 2016) [1:33:15]

**Studies show estrogen can decrease risk of fracture by up to 50%**: [Decreased risk of fractures of the hip and lower forearm with postmenopausal use of estrogen.](https://www.ncbi.nlm.nih.gov/pubmed/7421945) (Weiss et al., 1980) [1:36:45]

**Estrogen protects against the growth of cancerous cells in the colon**: [Molecular Pathways: Estrogen Pathway in Colorectal Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836673/) (Barzi et al., 2014) [1:38:45]

**Nurses’ Health Study showed a 20-25% decreased risk of colon cancer among women taking estrogen**: [Colorectal Cancer Epidemiology in the Nurses’ Health Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4981802/) (Hoon Lee et al., 2016) [1:38:45]

**Testosterone has also been associated with the development of breast cancer**: [Endogenous sex hormones and subsequent breast cancer in premenopausal women.](https://www.ncbi.nlm.nih.gov/pubmed/15352045) (Micheli et al., 2004) [1:48:00]

**What Peter called the “Bible on oncology”**: [DeVita, Hellman, and Rosenberg’s Cancer: Principles & Practice of Oncology](https://www.amazon.com/DeVita-Hellman-Rosenbergs-Cancer-Principles-dp-1496394631/dp/1496394631/ref=mt_hardcover?_encoding=UTF8&me=&qid=) | (amazon.com) [1:51:30]

**PREDIMED nutritional study that suffered from performance bias yet is generally regarded as the best nutritional study**: [Primary Prevention of Cardiovascular Disease with a Mediterranean Diet Supplemented with Extra-Virgin Olive Oil or Nuts](https://www.nejm.org/doi/full/10.1056/NEJMoa1800389) (Estruch et al., 2018) [1:55:45]

**Report in 2003 that said that the incidents of breast cancer has dropped precipitously**: [The decrease in breast-cancer incidence in 2003 in the United States.](https://www.ncbi.nlm.nih.gov/pubmed/17442911) (Ravdin et al., 2007) [2:05:00]

**Avrum’s response to the 2003 claim that WHI is responsible for the decrease in breast cancer**: [A Decline in Breast-Cancer Incidence](https://www.researchgate.net/publication/6168587_A_Decline_in_Breast-Cancer_Incidence) (Avrum Bluming, 2007) [2:05:00]

**The letter from a Portuguese gynecologist critiquing the WHI**: [My Dream.](https://www.ncbi.nlm.nih.gov/pubmed/15669558) (Neves-e-Castro M, 2004)  [2:09:00]

**A favorable review of Estrogen Matters in the London Times**: [Hormone therapy: why everything you thought you knew about HRT is wrong](https://www.imsociety.org/manage/images/pdf/298c708cc7c6aea5af8d9c766b0a5a69.pdf) | Anna Maxted (imsociety.org) [2:09:15]

**Some evidence suggesting HRT after a diagnosis of breast cancer might not be harmful, and could be beneficial**: [Safety of pregnancy in patients (pts) with history of estrogen receptor positive (ER+) breast cancer (BC): Long-term follow-up analysis from a multicenter study.](https://ascopubs.org/doi/abs/10.1200/JCO.2017.35.18_suppl.LBA10066) (Lambertini et al., 2017) [2:13:45]

**Avrum did a study administering HRT to his patients who had previously had breast cancer (including his own wife)**: [Hormone replacement therapy: benefits and risks for the general postmenopausal female population and for women with a history of previously treated breast cancer.](https://www.ncbi.nlm.nih.gov/pubmed/8296203) (Bluming AZ, 1993) [2:17:00]

§

## People Mentioned

- [Robert A. Wilson](https://www.amazon.com/Feminine-Forever-M-D-Robert-Wilson/dp/B000J00XN0/ref=sr_1_1?s=books&ie=UTF8&qid=1550682675&sr=1-1) (The doctor who wrote [Feminine Forever](https://www.amazon.com/Feminine-Forever-M-D-Robert-Wilson/dp/B000J00XN0) in the 1960s which oversold the benefits on estrogen therapy) [18:15]
- [Sid Mukherjee](https://twitter.com/drsidmukherjee?lang=en) (wrote The Emperor of All Maladies, includes story about a radical mastectomy, previous [guest on The Drive](https://peterattiamd.com/sidmukherjee/)) [24:15]
- [Bernard Fisher](https://en.wikipedia.org/wiki/Bernard_Fisher_(scientist)) (pioneer in the biology and treatment of breast cancer) [25:45]
- [Riley Lloyd](https://www.rileyperrylloydmd.com/) (gynecologist with interest in HRT, friend and mentor of Peter’s) [31:15]
- [Katie Taylor](https://www.thejc.com/lifestyle/features/finding-the-positive-side-of-menopause-1.438301) (wrote personal story about depression and menopause) [31:30]
- [Michael Baum](https://en.wikipedia.org/wiki/Michael_Baum) (father of Katie Taylor, a leading breast cancer specialist in England) [32:30]
- [Jacques Rossouw](https://en.wikipedia.org/wiki/Jacques_Rossouw) (who was the cardiologist who led the Women’s Health Initiative) [48:45, 53:15, 56:45]
- [Robert D. Langer](https://robertdlanger.com/) (one of the investigators of WHI who revealed the background story about how the consensus was reach on the results of the study) [51:15]
- [Rowan Chlebowski](https://www.cityofhope.org/faculty/rowan-chlebowski) (one of the 3 writers of the WHI) [53:15]
- [Garnet Anderson](https://www.fredhutch.org/en/labs/profiles/anderson-garnet.html) (the statistician of the WHI) [53:15]
- [Mark Hegsted](https://en.wikipedia.org/wiki/D._Mark_Hegsted) (dietary guideline) [54:30]
- [Basil Rifkind](https://jamanetwork.com/searchresults?author=Basil+M.+Rifkind&q=Basil+M.+Rifkind) (dietary guidelines) [55:00]
- [JoAnn Manson](https://en.wikipedia.org/wiki/JoAnn_E._Manson) (one of the leading scientist of the WHI) [1:12:30, 1:19:30]
- [Nananda Col](https://health.usnews.com/doctors/nananda-col-362379) (paper that showed that if every woman in the United States did hormone replacement therapy it would increase the median survival of women by 3.3 years) [1:22:00]]
- [Philip Sarrel](https://medicine.yale.edu/people/search/philip_sarrel.profile) (many women might have died prematurely from heart disease because they went off HRT) [1:22:15]
- [Barbara Sherwin](https://www.mcgill.ca/psychology/barbara-b-sherwin)  (studies benefits of estrogen on the brain) [1:25:30]
- [Isaac Newton](https://en.wikipedia.org/wiki/Isaac_Newton) (first president of the Royal Society in London) [1:44:00]
- [Vince DeVita](https://en.wikipedia.org/wiki/Vincent_T._DeVita) (director of the National Cancer Institute, endorsed Estrogen Matters, [wrote a book](https://www.amazon.com/DeVita-Hellman-Rosenbergs-Cancer-Principles-dp-1496394631/dp/1496394631/ref=mt_hardcover?_encoding=UTF8&me=&qid=) that Peter called “the Bible on oncology) [1:51:30]
- [Steve Rosenberg](https://en.wikipedia.org/wiki/Steven_Rosenberg) (Peter’s mentor, [wrote a book](https://www.amazon.com/DeVita-Hellman-Rosenbergs-Cancer-Principles-dp-1496394631/dp/1496394631/ref=mt_hardcover?_encoding=UTF8&me=&qid=) that Peter called “the Bible on oncology ) [1:51:30]
- [Sam Hellman](https://radonc-sites.uchicago.edu/page/samuel-hellman-md) (radiation oncologist, [wrote a book](https://www.amazon.com/DeVita-Hellman-Rosenbergs-Cancer-Principles-dp-1496394631/dp/1496394631/ref=mt_hardcover?_encoding=UTF8&me=&qid=) that Peter called “the Bible on oncology )  [1:51:30]
- [Jerry Kassirer](https://en.wikipedia.org/wiki/Jerome_P._Kassirer) (editor in chief of the New England Journal of Medicine, endorsed Estrogen Matters) [1:52:00]
- [Leslie Turnberg](https://en.wikipedia.org/wiki/Leslie_Turnberg,_Baron_Turnberg) (president of the Royal Society of medicine in England, endorsed Estrogen Matters) [1:52:00]
- [Phyllis Greenberger](https://www.healthywomen.org/about-us/medical-expert/phyllis-e-greenberger-msw?destination=14138) (CEO of the women’s Science Cooperative, endorsed Estrogen Matters) [1:52:00]
- [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis) (described nutritional epidemiology as “Effectively garbage.”) [1:54:30]
- [Anna Maxted](https://twitter.com/annamaxted?lang=en) (author of the London Times review of Estrogen Matters) [2:09:15]
- [Fadlo R. Khuri](https://en.wikipedia.org/wiki/Fadlo_R._Khuri) (friend of Avrum, chief editor Cancer) [2:13:15]
- [John F. Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy) (“we too often enjoy the comfort of opinion without the discomfort of thought”) [2:18:00]
- [Julian Barnes](https://en.wikipedia.org/wiki/Julian_Barnes) (“The more you learn, the less you fear.”) [2:18:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/02/bio-image-500x500.png)

##### Carol Tavris, Ph.D. & Avrum Bluming, M.D.

**Carol Tavris, Ph.D.**

Carol Tavris received her Ph.D. in social psychology from the University of Michigan. Her books include Mistakes Were Made (But Not by Me), with Elliot Aronson; Anger: The Misunderstood Emotion, and The Mismeasure of Woman. She has written articles, op-eds, and book reviews on topics in psychological science for a wide array of publications — including the Los Angeles Times, the New York Times Book Review, the Wall Street Journal, and the TLS — and a column, “The Gadfly,” for Skeptic magazine. She is a fellow of the Association for Psychological Science and has received numerous awards for her efforts to promote gender equality, science, and skepticism.

**Avrum Bluming, M.D.**

Avrum Bluming received his M.D. from the Columbia College of Physicians and Surgeons. He spent four years as a senior investigator for the National Cancer Institute and for two of those years was director of the Lymphoma Treatment Center in Kampala, Uganda. He organized the first study of lumpectomy for the treatment of breast cancer in Southern California in 1978, and for more than two decades he has been studying the benefits and risks of hormone replacement therapy administered to women with a history of breast cancer. Dr. Bluming has served as a clinical professor of medicine at USC and has been an invited speaker at the Royal College of Physicians in London and the Pasteur Institute in Paris. He was elected to mastership in the American College of Physicians, an honor accorded to only five hundred of the over one hundred thousand board-certified internists in this country.

Dr. Bluming has graciously offered his email to take direct questions from anyone who is interested in this topic: **avrumzbluming@gmail.com**

**Website**: [EstrogenMatters.com](https://estrogenmatters.com/)

**Twitter**: [@EstrogenMatters](https://twitter.com/EstrogenMatters)

**Facebook**: [Estrogen Matters](https://www.facebook.com/pg/EstrogenMatters/posts/)