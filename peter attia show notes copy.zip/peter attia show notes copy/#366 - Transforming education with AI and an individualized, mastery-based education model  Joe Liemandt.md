# #366 ‒ Transforming education with AI and an individualized, mastery-based education model | Joe Liemandt

**Source:** [https://peterattiamd.com/joeliemandt/](https://peterattiamd.com/joeliemandt/)

---

Joe Liemandt is a software entrepreneur turned education reformer who left Stanford in 1989 to found Trilogy, a highly profitable private software company, before pivoting to transforming K-12 learning. In this episode, Joe shares how he transitioned from leading a global software enterprise to becoming principal of Alpha School, where his focus is building a mastery-based, individualized education model that leverages AI as the missing infrastructure for large-scale change. He details the shortcomings of traditional K-12 education, explains how Alpha replaces conventional seat time with focused academics, and outlines the role of AI tutors and human coaches in helping students accelerate through material. Joe also discusses early results, the data-driven systems that track progress, and his ambitious plan to reach a billion children in the next 20 years by combining cutting-edge technology with proven learning science.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/joeliemandt/the_Drive_public.png)

Play

#366 ‒ Transforming education with AI and an individualized, mastery-based education model | Joe Liemandt

#366 ‒ Transforming education with AI and an individualized, mastery-based education model | Joe Liemandt

1x15s30s

0:001:47:22

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Joe’s early interest in AI and the story of how he quit school to build Trilogy [A: 4:45, V: 1:29];
- Joe’s first encounter with Alpha School and how it sparked his journey into education innovation [A: 8:15, V: 5:59];
- America’s declining K-12 performance and the hidden power of mastering fundamentals [A: 13:00, V: 11:47];
- How traditional time-based grade progression undermines later learning, and how mastery-focused instruction can transform student achievement [A: 20:30, V: 21:00];
- Motivation as the key to high-level learning: how Alpha School fosters motivation with its “Timeback” model and leverages AI to accelerate learning [A: 28:45, V: 30:30];
- Core principles of learning: how high standards, mastery-based instruction, and supportive struggle foster both academic excellence and personal growth [A: 35:45, V: 39:00];
- Breaking down self-imposed limitations with foundational skills, defined time requirements, and a mastery model [A: 41:15, V: 45:59];
- Using short-term extrinsic rewards to help students overcome limiting beliefs and ignite lasting intrinsic motivation [A: 46:45, V: 52:35];
- $100 for 100: a simple but powerful incentive system that helps students fill academic gaps and master fundamentals [A: 53:45, V: 1:01:00];
- How AI is the pivotal technology that can finally allow proven learning science to scale and unlock unprecedented student potential [A: 57:45, V: 1:05:53];
- The emergence of generative AI that catalyzed Joe’s billion-dollar investment in education [A: 1:09:45, V: 1:19:48];
- The path and obstacles to integrating Alpha’s AI-powered model into mainstream education [A: 1:12:00, V: 1:22:21];
- Reimagining schooling from the ground up across five key dimensions [A: 1:22:30, V: 1:35:11];
- The potential of this educational approach to reduce inequality in academic success [A:1:30:00, V: 1:44:08];
- Why the biggest challenge to scaling Alpha’s AI-driven education is cultural adoption and systemic redesign [A: 1:34:00, V: 1:48:59];
- Peter’s daughter’s experience at Alpha School [A: 1:38:30, V: 1:54:30];
- Alpha School’s expansion plans and need for people and resources for maximum impact [A: 1:42:30, V: 1:58:58]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Joe Liemandt is a software entrepreneur turned education reformer
- As we discussed in the podcast, he dropped out of Stanford in about 1989, started a company called [Trilogy](https://trilogy.com/) that’s gone on to become one of the most profitable software companies in the world that you’ve probably never heard of because it’s remained private this entire time
- Joe left Trilogy three years ago to become the principal of [Alpha School](https://alpha.school/); and his passion today and, as he discusses for the next couple of decades of his life, is going to be on transforming K-12 education
- This is something that many people have thought about before, but what is really remarkable about the way Joe tells the story is that all previous efforts to transform K-12 have been missing a critical piece of infrastructure
  - And that infrastructure is AI
- Now, you may be asking, why we’re going to have a discussion about education on *The Drive*?
  - You can’t really care about science and medicine if you don’t care about education
  - All of us listening today are one day going to be cared for by people who are in K-12 today, who are going to have to learn STEM, and hopefully be interested enough to choose a career in medicine
  - So we all have a very vested interest in this, not just for the health of our country and our economy, but also on a very deep and personal level

In this episode, we discuss:

- What it is that education research has been saying for the past 40 or 50 years that has been unimplementable because of scale
- Joe’s path from software engineer to education, why that pivot
- What’s wrong in K-12 education and the forces behind it
- In fact, just as an anecdote today, this morning in the newspaper Peter was reading something before recording this intro (which is about a week after the podcast): they just came out with a national assessment of education progress tests (which are tests that are done across the country)
  - We continue to be in a state of decline
  - For mathematics, only 55% of 12th graders were able to meet the basic level
  - And only 67% of 12th graders were able to hit that level in reading
  - These scores represent the lowest scores we’ve had in over 20 years
  - So this downhill trend of basic math and reading skills continues
- We talk about the case for mastery-based individual learning that’s grounded in learning science
  - Peter can’t say enough about this, and it’s something he doesn’t think he really understood until maybe the past year, based on his very limited insight and interaction on the fronts of education
  - This is such a core idea that it’s essential to this
- How Alpha schools actually run day to day
  - Including replacing seat time with roughly 2  hours of focused academics daily
  - How kids make up a grade in as little as 20 to 30 hours
  - Where AI tutors help most and where human coaches are essential
  - Building core skills and fluency without killing curiosity
  - Creating motivation systems goals, time back, and incentives
  - How Alpha schools track progress and use data to guide learning
  - Early outcomes, limitations, and what still needs proving
  - And of course, the road map to scale, the costs, the constraints, and how do you bring this to Joe’s ultimate goal, which is at least 1 billion kids within 20 years

## Joe’s early interest in AI and the story of how he quit school to build Trilogy [A: 4:45, V: 1:29]

**People are probably wondering, how does this tie into health and medicine?**

- This is a topic that’s a little bit outside of that, but really it’s not
- Where we’re ultimately going to go is education, and you can’t have a great system of health and medicine if you’re not educating kids today
  - The people that are learning today are going to be the ones taking care of us, so everybody should have a vested interest in this process
- Of course, also, many people listening have kids across various spectrums of learning
- But before we get into that, Joe’s story is just so interesting
  - And Peter knows that Joe doesn’t really like telling his story, because all he wants to do is talk about the work

**Where did you grow up?**

- Joe was born in Minnesota, and he moved around every couple years, mostly up and down the East Coast
- His dad worked for General Electric, and wherever they had a factory, whatever town , they’d moved there

**You obviously did very well in high school, and you wound up at Stanford. So, what’d you major in?**

- Econ
  - He mostly picked it because it was easy in the Stanford curriculum
- He did not graduate; he dropped out between junior and senior year
  - He would’ve been the class of 1990
  - He’s sure his junior year professors were like, “*He’s not really engaged, and probably  misses too many classes.*”

**A little background on Joe before he went to Stanford**

- When he was in high school, he wrote a paper on AI
  - The paper was about expert systems ‒ an old school AI, not what we know today
  - There was a part one paragraph called “Neural Nets,” which is sort of today’s AI, and it was like, “*This is decades away.*”
- Then Joe went to Stanford and literally was in a class with [Professor Feigenbaum](https://en.wikipedia.org/wiki/Edward_Feigenbaum) (who’s considered one of the fathers of expert systems and old school AI) and he’s just talking about how you can build these incredible systems, and they’d be worth millions of dollars if you could figure it out

**Some classmates and Joe dropped out and started** [**Trilogy**](https://trilogy.com/)**‒ it was the first AI company**

- They didn’t call it AI back then because it had a bad rep
- In the 90s, they sold a billion dollars of AI products
- That’s how Joe got his start, and it eventually leads to today’s story

*Peter always finds it amazing when people drop out with one year to go*

- It’s like, “*Why didn’t you finish it?*”
- He thinks Joe must have had a strong conviction to forego his Stanford degree to go and start this company (that it can’t wait a year)

There’s a famous [Forbes](https://www.forbes.com/sites/abrambrown/2018/11/19/holy-cow-no-ones-done-this/#:~:text=own%20software%20company.%20%22-,You%27re%20a%20moron,-%2C%22%20growled%20his%20father) headline, “*You’re a moron*”

- Joe’s dad was very clear what a moron Joe was being by dropping out
- The issue was Joe felt there was a time to market issue, it was a race
  - It’s that tension where you thought

> “*My market’s going to run away without me, and there’s a huge opportunity to go build this company*.”‒ Joe Liemandt

- Now, with 2020 hindsight, it took them over 3 years to build a product, and they thought they could do it much quicker
- So there wasn’t a time to market issue
- And with hindsight, he could have stayed [and finished his degree at Stanford]

***But back to that pressure: he just felt it, he didn’t want to miss it, he had to go do it***

**Did you guys come and set up shop in Austin right away?**

- Not right away
- They couldn’t raise funding
- Silicon Valley back in the late 80s was not given money to dropouts like them
- But they literally lived in a garage of had classmates who had a house
- Then in ’92 they moved down to Austin
  - [John Lynch](https://www.linkedin.com/in/jplynch1/) (who was one of the co-founders) was like, “*Look, if we’re going to be poor…*” (back then Austin was cheap, not like Palo Alto)
  - And that’s what led them to Austin

## Joe’s first encounter with Alpha School and how it sparked his journey into education innovation [A: 8:15, V: 5:59]

**When did this idea of finding your second mountain (which is this passion around education) become the next frontier?**

- Peter asks, “*Is it David Brooks who wrote that book,* [*The Second Mountain*](https://www.amazon.com/Second-Mountain-David-Brooks/dp/0812993268/ref=tmm_hrd_swatch_0)*?*”
  - If your first mountain was [Trilogy](https://trilogy.com/), this incredible business, which really we’re not going to say much more about other than the fact that it basically created an unlimited essentially war chest of capital
  - That you were then able to go and deploy to your second mountain
  - Which is this passion around education

*You always had an interest in AI, but when did these AI in education become the next frontier?*

- 11 years ago now, [MacKenzie Price](https://2hourlearning.com/founder/) started [Alpha](https://alpha.school/) in Austin
- Radical idea back then
  - One of the things Joe has learned as principal of Alpha is that parents want their kids’ education to be however they were educated
  - And he was the same way: he went to Catholic school, his kids are in Catholic school
- MacKenzie’s like, “*Look at this great new school I got, it’s going to be awesome*.”
- And Joe was like, “*That’s weird.*”
- When she started, it’s literally in some guy’s garage and Joe is her co-founder
- It took her 2 years to actually convince him to move his daughters over
- They sampled it one time, and literally loved it
  - They did it after their Catholic school got out before they went to summer camp
  - And they came back and they’re like, “*Dad, we don’t want to go to summer camp, and we want to still go to Alpha.*”
  - Joe didn’t like school enough; that sounded crazy to him
  - But it was a really good sign
- Joe moved his kids to Alpha 10 years ago
- Joe’s discussion with MacKenzie was always like, “*This is awesome, but it’s not scalable*.”

**What did Alpha look like 11 years ago when you first peered behind the curtain?**

- The other co-founder Brian had this philosophy, he had these rules
- When Joe moved his kids over to Alpha he asked, “*Brian, what are the 2 things I don’t believe about education that I need to understand?*”
- 1 – Kids must love school
  - Joe thought of it like spinach sometimes
- 2 – Your kids can do so much more than you expect
  - Joe thought he had high expectations
  - Brian was like, “*They’re going to blow you away on what they can do, and your expectations are too low*”
- It was 20 kids, they weren’t in a garage after 2 years, but it is alternative
- They would use a set of apps to do academics
- They would have teachers help academically if needed
- Then they would have all these life skills and they check charts and life skills

***It was some academics, and then workshops and life skills***

- The 20 kids were probably in the range of 2nd to 6th grade
- And they’re clustered like the one room schoolhouse
- You go in, and it is crazy
  - He’s like, “*Oh, they’re doing spelling bees*.”
  - Joe’s like, “*They’re walking on their hands, doing handstands across the room.*”
  - The kids literally would walk across the room in handstands but recite all the words on their spelling bee is doing it
  - Could they make it all across? The kids were just having a ton of fun
- Joe was always like, “*Are they really learning?*” But testing showed they were

**What was the state of educational apps 11 years ago?**

- There were things like [DreamBox](https://www.dreambox.com/) and [Khan Academy](https://www.khanacademy.org/)
  - They were static in the sense that they weren’t adaptive

> “*The problem with old ones [apps], and actually even a bunch of them today, is now we know with learning science all these much better ways to do it*.”‒ Joe Liemandt

- Their standards of mastery were too low, their implementation of learning science was too little
- But they were good enough that you could get your way through
- But back to some of the problems like when Joe’s oldest first took her 7th grade standardized test, she failed it all
- She had been in the Alpha program with those apps
  - The apps were janky and not all there
  - This was before Joe got involved (except as a parent)

***The apps have gaps and holes, and figuring out how to change that was how Joe got involved with what he’s been doing for the last 3 years***

- Joe’s foray into this is through the experience of his kids

## America’s declining K-12 performance and the hidden power of mastering fundamentals [A: 13:00, V: 11:47]

- Peter wants to step back and talk about education in general
- People are familiar with the idea that the United States is not doing well in primary and secondary education (K-12)
  - We do pretty well in college relative to the world
  - But getting to college, we’re not doing well

**⇒** The point is further made when you look at the dollars in to results out: we’re spending $1 trillion on K-12 education, which is about 1/7 of what the world spends

- Of course, we don’t have 1/7 of the population, so there’s a huge mismatch there

***But our*** [***ROI***](https://en.wikipedia.org/wiki/Return_on_investment) ***is quite low***

- It actually kind of parallels the healthcare spending thing, where on a per capita basis we spend more on healthcare than anybody else, and yet we’re actually not producing the best life expectancy
  - [the subject of [episode #327](https://peterattiamd.com/saumsutaria/)]

**Why does the United States spend so much money on K-12 education?**

*And maybe more importantly, why are we not getting the results, at least if we believe we’re measuring the results correctly?*

- If the results are to be determined by these tests that all the OECD nations take, why are we doing so poorly?
- That’s a complex answer
- But it’s true, our academic performance continues to go down

For example, there’s this test, [NWEA Map Test](https://en.wikipedia.org/wiki/NWEA)

- It’s a nationwide test
- When Joe was a kid, he took an Iowa test, this is an equivalent one
- Millions of kids take it
- And they just updated their [2025 norm table](https://www.nwea.org/resource-center/resource/2025-norms-quick-reference/)
  - The last one they did, it’s 202
  - Every 5 years they update the benchmark

***America knows less now: your average eighth grader in 2025 knows less than the average eighth grader in 2020, who knows less than average in 2015***

- You can’t just blame that on COVID; it’s a continuing trend going down
- There is one actually anomaly, which is, from ’15 to ’20, and ’20 to ’25, there’s one group who actually goes up, and that’s your 99th percentile
  - So the top 1% academically in America in K-12 continues to increase
  - Those are your Ivy League bound kids who continue to go up
- Everybody else is going down
- Things are getting easier in tests
- The [AP](https://en.wikipedia.org/wiki/Advanced_Placement) tests in high school that you take, they re-normed them in the last couple years, and they norm them against college kids
  - Because it’s like, “*Okay, if you take an AP test, that’s like a college class*.” And so they say, “*Well, what do college kids know?*” (college kids know less)
  - So now our AP test is easier
- It used to be at Alpha, if you were going to be in the honors track, you had to get a 4 or 5 on an AP [a 5 is the top score]
- Now we’re like, “*Oh, you just need a 5, because the 4s are too easy*.”

***The standards just keep going down***

**More examples of how academic standards keep going down**

- Joe just gave the “academic talk” to hundreds of families at Alpha across the country of campuses now everywhere [the school year just started in the last couple weeks]
- The kids all come in, they take a placement test
- Joe got up in front of all the parents and was like, “*Here’s the message, and it’s going to worry you.*”
- Your $40,000 private school, they’ve been lying to you

**⇒** Which is, if your student has an A, and you’ve been getting straight As on your transcript, that student in our tests is anywhere from 1 year ahead (that’s great) to 3 years behind

- This is an A student who’s 3 years behind, and when we talk about 3 years behind, they’re a 7th grader
  - They’re missing a significant number of questions on the 4th grade test
- If you’re a B student, you are from 3-7 years behind

*Peter has a great sense of this because he and Joe have gone over this before, but he wants the listener to understand tangibly what that means*

- Let’s put that in terms of something mathematical

Let’s talk about what that implies for a B student in 7 grade mathematics. What concept could they be possibly missing?

- They don’t know their multiplication tables, or division tables
- One of the things that’s happened in K-12 education is they’ve decided that memorization is bad
  - And you don’t need to memorize your multiplication tables anymore, you’re just going to use a calculator
- That’s not what learning science says
  - If you’re going to do higher level math, you need fact fluency
- And if you think of [cognitive load theory](https://en.wikipedia.org/wiki/Cognitive_load), you have a certain number of working memory slots, and the level of complexity of the math problem that you can solve is going to be based on how many slots you have and how you’re using them
- One of the few places in brain chemistry is, if you have memorized something to fluency, it doesn’t use a slot
  - And so you can do higher level math
- But if you have to use your slots to say 7 x 8 = 56, you’re now trying to do higher level math and you’re using it up on the wrong things

***If you want to do a higher level math, memorize your multiplication tables and your division tables to fluency. That’s the most simple obvious thing we could do in this country, is just change that ( go back to what we used to do)***

- The most extreme example: we had a student who had a 740 math SAT (a very good score)
  - 800 is a perfect score
  - 770 is top 1% so maybe this is top 5%
- We do what we call “**game fill**”: you review why you missed the test, why you missed the questions on the test.
  - This is common in sports
  - People don’t do this in academics for some reason
  - She would just go through it and decide, was it a careless error? Did you not know the material?
  - She’s like, after the test she could get them all done, given time

***What happened was she was overloaded and made careless mistakes***

**⇒** When your working memory slots are overloaded, it reflects in careless mistakes

- So if your student is making careless mistake
  - You’re like, grit and discipline
  - You’re like, you probably don’t have a fact fluency somewhere earlier
  - If you just go fix that, all of a sudden those careless mistakes go away
- So she literally went back to 3rd grade, learned her multiplication and division tables
- Convincing parents of that is really hard
  - Convincing students and parents, your 740 math student needs 3rd grade material
- She then got a 790 math after she memorized it, because she stopped making the careless errors

***She knew all the material before, she was overloading her working memory, and that’s our issue learning science***

- In our system, we can identify that, and fix it
- It’s seemingly crazy that you can go back and memorize your tables and get up there

**Another story of a student struggling in entry-level chemistry**

- Anybody who’s been through chemistry can empathize with that
- The first time you’re going through physical chemistry and you’re trying to balance the chemical equations
- This kid is dying, and they think the problem is chemistry
- And you come in and say, “*No, actually the problem is fractions. You didn’t master fractions in 3rd grade, or 4th grade, or whenever fractions are introduced.*”
- And you’re failing chemistry for this exact reason

***We’re going to go back and fill the gap in fractions, and this will become easy for you***

- And of course, that’s what happened

**⇒** Knowledge in math and science is hierarchical

## How traditional time-based grade progression undermines later learning, and how mastery-focused instruction can transform student achievement [A: 20:30, V: 21:00]

**This is back to mastery and why we do poorly**

- We’ve given up mastery in this country
- Why? We’re a time-based system
- At the end of 3rd grade, you’re moving to 4th grade; and at the end of 4th grade, you’re moving to 5th grade
  - We don’t hold kids back
- We’ move kids through no matter what, because it’s time
  - Because there’s all these other social issues
- The pressure on the school, to relax the standards
  - 80% of kids at Harvard get an A now ‒ grade inflation
  - Grades look like this, standardized test scores look like that
- But in a time-based system, just even grading, there’s this concept that, okay, you got a 70, you can pass, and the 80 is a B
  - That’s great. My kid’s a B student

***The problem is, if you only have 80% knowledge, you’re creating all these holes, and it all compounds where eventually and it starts to when you hit algebra or chemistry, that you think it’s the current material, but it’s your pre-recs***

**⇒** The pre-recs are your foundation

- We talk a lot about parents, because a lot of this is, we all grew up in this time-based system, and just the old system

**This new way is very different**

- The best analogies we always use that parents totally understand is sports
- Just like reviewing the game film
- We’re like, “*Review your test, figure out what’s wrong.*”
- Mastery is the same
- Analogy: if you’re the point guard and you lose the ball 20% of the time going down the court, the coach isn’t like, “*Let’s work on the advanced stuff*.” They’re like, “*Kid, let’s learn how to dribble.*”
  - We don’t need to worry about dunking yet

***Everybody in sports is like, “If you’re not doing well, go back and do the basics.” Academics is the same way***

- If you apply that same logic, but in a time-based system, with a teacher in front of a classroom, you can’t get every kid to mastery
- With Alpha, we get into the new solutions and that’s why these crazy kids can learn 10x faster

Joe explains, “*It’s because we’re able to get out of a non-mastery time-based system that has a teacher in front of a classroom.*”

- Teachers are great, teacher in front of the classroom is bad (that dynamic)

**Back to the point about hierarchy**

- Chemistry is just algebra with advanced word problems
- Physics is literally calculus with advanced word problems
- Algebra is basically advanced fraction manipulation
- You can give kids a fraction test and predict their algebra score
- And then fractions are, how’s your division and multiplication tables?
  - Do you memorize them to fluency?
- It just keeps going down the whole track, all the way down
- And so part of what you have to do to fix the system is figure out age grade, “*Oh wait, I’m an 8th grader in algebra,*”
- And knowledge grade, “*Wait, I don’t know my fractions are different*.”

**The teacher in front of the classroom, it’s not their fault**

- They teach 8th grade (8th grade material), and they have kids who don’t know some 3rd, 4th, 5th, 6th, 7th grade material
- This is why so many people hire tutors after school at private schools
  - It’s crazy, we have all these people go to private schools and hire after school tutors, because the school doesn’t teach them

***The tutor just gives them the earlier grade level material***

- When we talk about kids, all these hundreds of kids coming in, who are 3 years behind, 7 years behind, the second part of what Joe tells the parents is, “*That’s freaking you out because nobody wants their kid this far behind.*”
- But it’s so easy to fix
- The remediation on this stuff takes no time at all

> “*When you use these learning science-based AI tutors and the apps that we have, kids can learn 10 times faster.*”‒ Joe Liemandt

- When you actually look at material, there’s 180 school days, hour a day, plus homework (a couple hundred hours)

**⇒** One subject per grade level takes our Alpha kids between 20-30 hours to finish an entire grade level to mastery

- So you can take 4th grade **math** and be like, “Y*ou got 26 hours, kid. You do an hour a day of homework, you’re 26 days away.*”
- 22 hours is 7th grade, and 6th grade, 22 each for math
- The **science curriculum** in 6th, 7th, and 8th grade ‒ first of all, we don’t teach a lot

**Peter’s thought experiment**

*Would this work if each student had one teacher, the private tutor?*

- If you could put a private tutor in front of a student for 22 hours over the course of, whatever, 2 months, or 1 hour a day for 26 days, are you confident that that individual could navigate and weave that child through?
  - And of course we’ll talk about why that’s not practical

***Yes, AI can do a little bit better than most tutors***

Learning science has been around for 40 years

- There’s 10,000 papers published by all the schools of education, and Stanford, and all over the place, that is, ***we know kids can learn 2, 5, or 10x faster*** (we’ve known it)
- In [Bloom’s 2 Sigma](https://web.mit.edu/5.95/www/readings/bloom-two-sigma.pdf) (it’s a seminal paper), he just said: if everybody got a personalized tutor, was his first point, and second, they worked to mastery
  - [the figure below is from this paper and shows how much quicker students can achieve mastery when working with a personalized tutor/tutorial]

![](https://peterattiamd.com/wp-content/uploads/2025/09/f1-joeliemandt.png)

**Figure 1. Achievement distribution for students under different types of instruction**. Image credit: [*Educational Researcher* 1984](https://web.mit.edu/5.95/www/readings/bloom-two-sigma.pdf)

- Mastery-based, not tenure-based

***You have to know the material before you advance, and there’s an individual tutor to coach you. You’ll get 2 sigma better performance***

- Your leftmost part of your curve, your worst students are going to be at what today is considered the top 10%, in a 2 sigma performance [2 sigma refers to 2 standard deviations above the mean]
- Peter recalls that Joe said to him once, 4 or 5 years ago, and he’s curious if Joe still stands by it, “*At least through the end of 8th grade, there is not a single student in the United States that cannot achieve complete mastery in mathematics to score above the 90th or 99th percentile in the national test*.”
- Yes, they can get to what is considered today top 10% performance in mathematics
  - For argument’s sake, take out the bottom 5%
- Peter still doesn’t have a sense of what’s changing because we’ve always had a time-based system, not a mastery-based system

**What has gone on in the last 25 years, because that’s not the change. Why are scores getting worse?**

***Yes, the fundamental answer is standards are lowering***

Part of it is parents

- 3 years ago, when Joe became principal, he would sit down with parents and explain, “*We have this cool engine. It’s going to teach your kid twice as much in the 2-hour block, twice as much.*”
  - Now they have to use the apps and engage with it
  - And your student’s not using it right, so they’re not learning 2X
- The parents are like, “*Stop. Don’t pressure my kid to learn 2X. Don’t pressure him.*”
- Joe would be in a parent meeting and it would literally be mom, dad, and Johnny.
  - Joe explains, “*Look, when he misses a question, he doesn’t watch the video? He’s scrolling and just guessing? If he just watched the video, he’d learn twice as much*.”
  - And the parents would say, “*We’re not interested in that.*”
- Now the rest of the things parents want: life skills, community, school is a bundle of which academics is one piece

***For the most part in America fewer than 10% of parents really care about academics. 90% of parents are like, “Oh, well.”***

- That was an eye-opener for Joe
- Hundreds of parents and meetings later, we switched our pitch, which was 2-hour learning
  - The same engine, you’re like, “I*t’s 2-hour learning. And look, we’re trying to get Johnny out of here in 2 hours so we can do these cool workshops and do what he loves*.”
- Parents are like, “*Johnny, what’s wrong with you? Don’t you want to get out of here and do the cool stuff?*”

## Motivation as the key to high-level learning: how Alpha School fosters motivation with its “Timeback” model and leverages AI to accelerate learning [A: 28:45, V: 30:30]

> “*The most important part of education is a motivated student… Two-hour learning is motivational for every kid on the planet.*”‒ Joe Liemandt

- 2X learning is not a motivating idea except for the top kids
- 2-hour learning is motivational for every kid on the planet

Joe shares, “*My biggest unlock was that realization [and] the product became codename “*[*TimeBack*](https://timeback.com/)*,” give the kids their time back because that is the most precious*.”

- For 12 years we waste kids’ time

**⇒** We know that kids sitting in a lecture-based classroom retain maybe 5%

- It’s that bad
- Being 10x better, you’re like, “*I need them to remember 50%*.”
- We know [the current system is] that bad. It’s not personalized to them, it’s not to a mastery
  - We’re wasting their 12 years and you wonder why kids don’t like academics, and they’re disengaged

**With Alpha School, they’re going to learn in 2 hours**

- Now they’re still learning 2X, that’s just not the part we pitch

***They’re learning 2X in 2 hours and then you free up the rest of the day***

**We get all our kids scores at Alpha School to the top 1% academically**

**⇒** Our classes score in the top 1% in the country. There’s no school academically who’s as good as Alpha in the country.

- And the reason is using this model
- We’re just implementing all these concepts that have been written in these learning science papers for 40 years

**Is there a challenge to the intensity that’s required in those 2 hours?**

Peter’s analogy

- He gets asked all the time, “*Hey, Peter, look, I’ve read that I could just do one set to failure once a week for each body part and get most of the benefits of grinding it out for 10 to 20 sets per body part.*”
- Peter explains that there’s a little bit of an exaggeration, but there’s some truth to this
  - If you could truly do 1-2 sets to absolute failure per exercise, yeah, you’re going to get great results
- But to be honest, it’s really freaking hard to bring that level of intensity to every single set of every single workout every time you do it
- And there are a bunch of other reasons that Peter actually kind of likes being in the gym or whatever

***The point is, it’s true you can get great results in much less time, but for many people the intensity is not something they’re willing to rise to***

*The similar question is if for 2 hours a day a kid can learn what a traditional kid is learning in 6-7 hours a day and actually do it better, is there something that they have to be able to bring from an attention span perspective that is very difficult?*

***The answer is it’s not difficult, but they have to want to do it***

If you talk to an educator, there’s 2 things you need

- 1 – You need a motivated student
- 2 – You need to put them in lessons of the correct difficulty, not too easy, not too hard
- Why doesn’t EdTech work? (back to these apps)
- Test scores keep going down, but everybody keeps buying EdTech

***The answer is EdTech does that second piece, that 10% piece of put them in the right lessons very well***

Joe explains, “*Our AI tutors do it even better. It can figure out very easily what a kid knows and doesn’t know and say age grade, 8 grade, knowledge grade, 4th, give them 4th grade lessons.*”

- Now the second part is to the point of Joe’s parent meeting is: how do I get them to engage with the app?
  - Instead of spinning in the chair, not paying attention, talking to my friend, scrolling TikTok, doing anything except focusing on it

***The kid’s motivation is 90% of the solution***

- That’s why “[TimeBack](https://timeback.com/)” is so valuable
- Which is the kid has to engage with the apps for those 2 hours or they don’t get the rest of the day, they don’t get their time back
  - They’ll just sit there wasting their time
- We literally in our app have a waste meter and it just coaches the kid
- We can get into the AIs and stuff and chat bots are terrible
  - ChatGPT rolled out to America students, 90% of kids use it as a cheat bot (it’s all cheating)
- We don’t have a chat interface in ours
- But one of the things our AI does is it watches the kid’s screen and coaches them up
  - It’s like, “*Look, you’re scrolling the article and guessing, not going to learn that way. You’re skipping this*.”
  - And it’s going to coach them of how to learn better

> “*If you have a motivation for the student to actually learn better and be effective, they’re very happy to do that.*”‒ Joe Liemandt

**Joe has a sports academy, these are middle schools**

- He just opened 10 of them around Texas [[Texas Sports Academy](https://texassportsacademy.com/)]
- Kids who are D1 bound athletes come in and they do the 2 hours in the apps
- And then once they hit it, they go green where they’ve done the lessons, and they get to do sports all afternoon
- And so you can take kids who are like, “*I hate school. I skip school*.” (absenteeism is huge), and when they get to do that, all of a sudden they’re like, “*I’m totally motivated*.”
- It’s only been a couple of weeks that we’ve been open, but you get notes from all the parents who are like, “*My kid always was sick, never wanted to go, everything. Now he’s waking me up and is like, ‘Let’s not be late.’*”
  - It’s because they have the motivation to actually learn ‒ that’s the most important

***You can do that for everybody and motivation really, really does matter. And Alpha is designed around: How do we motivate kids?***

- The biggest motivator is TimeBack, and we also use a lot of other ones

**There also extra juice of the intensity**

- We measure: Do kids get through our apps 90% or 95% first time right?
  - Where we’re not making the lesson hard enough, where we want to make sure the lesson’s not too hard where you don’t have to have too much intensity

*What is the sweet spot? Is it 90?*

- Between 90-95% where the first time through, the kids get the right answers
- There’s a thing called the “**zone of proximal development,**” which is what an individual student should be, and you want to keep a student in 80-85% correct questions
  - Which is different than first time right on getting through the whole lesson
- You want to be in the zone of proximal development, which is if you’re at 99%, it’s too easy (you’re not learning)
  - If you’re getting 99% of the questions right, you’re just regurgitating what you already know
- If you’re missing half the time or two-thirds, you’re only at 50 or 60, you get disengagement
  - It’s too frustrating, you go, “*I’m out*.”

***Video game developers are the world’s experts on engagement, and they’ll tell you, always winning, always learning***

**⇒** That concept in 80-85% is where that is. So we’re measuring

**The way to maximize learning**

- The way to maximize learning is an unending stream of content, both educational questions and learning content
- That is at 80% to 85% accuracy
- And this gets into stuff that we’re building

**⇒** If you sit in a Stanford lecture, you’re going to retain 1-5 facts, ideas, and concepts per hour

***Our current learning engines, depending on what the subject we’re at 20-40***

- We have stuff that we’re working on and Gen AI is the driver of this
- We’ll get to 100 facts, ideas, and concepts an hour
- Think of an endlessly scrolled TikTok list except engaging in good content instead of the poison that that is

> “*The learning science part is we know how to get knowledge into kids’ head 10 times better than the current educational system*.”‒ Joe Liemandt

- It takes a whole rebuild
- And back to kids when they love school, they’re going to engage in the app because the whole day is great

## Core principles of learning: how high standards, mastery-based instruction, and supportive struggle foster both academic excellence and personal growth [A: 35:45, V: 39:00]

- You alluded to education science a couple of times

**Tell me something that 90% of people who study education, study the science of learning would agree with**

**⇒** 90% would agree that individualized tutoring and a mastery-based standard is the best way to teach kids

- It’s dramatically more effective than a time-based system
- The concepts in learning science, zone of proximal development, spaced repetition, you would get the testing effect that actually asking kids active learning is better than passive learning

***Retention of sitting passively in a classroom is the worst way to teach a kid***

What else are really well-normed?

- [Cognitive load theory](https://en.wikipedia.org/wiki/Cognitive_load) is a new area of learning science that started in the ’90s
  - This is the: How many working memory slots do you have:
  - And then how many reps does it take to move from working memory slot (short-term memory basically) to long-term?

Peter points out, “*It’s so interesting to me that there’s any dispute around that when you see the effects in sports. Sports illustrates that, I think, more than anything else.*”

- You look at the difference between a [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) (an exceptional quarterback) versus a very good quarterback, and it’s the **processing speed**
- It’s not how fast or how far he can throw the ball
- It’s his processing speed that sets him apart; it’s the cognitive bandwidth of what he’s doing
- It’s actually the same in Formula One
  - If you look at what separates the very best in the world from very good, it’s cognitive bandwidth
  - It’s the guy who actually doesn’t have to think at all about driving and can still drive at the limit while he can use all of his cognitive reserve for strategic decision-making

Joe makes the point, “*Like that fluency stuff, there’s nobody in learning science who’s like, ‘It’s better if they don’t memorize their multiplication tables.*’”

- Public school and private schools are bailing on it [multiplication tables]

*Why was that decision made? Parental pressure again?*

- My kid is not happy (coddling)

**Back to Alpha School, Joe has conversations with parents**

- 1 – Your kid must really love school
  - He literally measures: Would you rather go to school or on vacation? (super high standard)
- 2 – Your kid can learn in 2 hours twice as much as sitting in class for 6 hours
  - Your kid can crush academics in just 2 hours a day
- 3 – This is where the controversy starts: the key to your kid’s happiness is high standards
  - That’s the one that a lot of people don’t believe, they think the key to their kid’s happiness is low standards

Peter asks, “*Where did this virus come from? Where did this virus infect us?*”

- Part of it is the parents want to protect their kids
- It comes from parents from a good place, which is, “*I don’t want to see my kids struggle and fail on their road to success.*”
- As a principle, Joe talks about **the cycle [of successful learning or resilience and growth mindset** where]: kids struggle, fail, sometimes cry on their road to success [and succeed] if they’re supported by a caring, loving adult
- That loop, if you ask any child development expert in the planet, you can type that all in ChatGPT ‒ it is the key to kids’ development
  - The key to their self-confidence
  - The key to their resilience
  - The key to their growth

***Kids go through a cycle of struggle, fail on the road to success***

- Peter relates, “*It’s the hero’s journey. It’s woven into everything we’ve done.*”

This ties back to Peter’s earlier point about sports

- When you talk about life skills, teamwork, leadership, grit, hard work ‒ 50% of Americans say this happens in after school sports
  - My kid’s going to go through that struggle, and I went through it when I was playing sports
  - And my kid’s going to go through that, and that’s where you learn it
  - Because that’s what the coach does

***Parents have this view of that’s the only place you learn it and it shouldn’t happen in school***

**The reason it doesn’t happen in schools**

- Is because in a time-based system, everybody thinks good grades equals high IQ
- And so it’s fundamentally that IQ is what determines grades
- So parents don’t want to pressure their kid because it’s not fair

**One of the magic unlocks they have at Alpha is a mastery-based system**

- Back to everybody can get to much higher performance
- If you take the best kids
  - Who are the kids who do get in the Ivy League?
  - They’re basically the high IQ kids who also have high conscientiousness (big 5 conscientiousness), they’re grinders, they just crank through it naturally
  - And those are the kids who do well
- If we’re rebuilding education to fix it, we have to take those 2 constraints away
- A mastery-based system takes away IQ, which is every kid [has the same chance of success]…

**⇒** The conceptual leaps that are required to get through K through 8, actually by the design of common core, aren’t that big

- That does not mean everybody can go be a nuclear physicist at Stanford and design all these things
  - There are areas where you do need more cognitive

***There’s a point everybody can reach in math, and in K-8, it’s designed that everybody can do it***

## Breaking down self-imposed limitations with foundational skills, defined time requirements, and a mastery model [A: 41:15, V: 45:59]

- Peter reflects on that: think of all the kids that are in 6th, 7th, and 8th grade who are good students in other domains, but they’ve created this narrative that says, “*I can’t do math*.”

> “*We also use our motivation model to undo the conscientiousness limitation.*”‒ Joe Liemandt

- You have to use more extrinsic motivators to let people who aren’t high conscientiousness still perform like somebody who does
- Those are our magic unlocks on those two things that we think can fix education

**Diving into the math thing**

- It’s an epidemic of kids who come into middle school, predominantly girls
  - Joe has 2 daughters, who come in and they’re like, “*I’m not a math-science girl*.”
  - Society’s accepting it
- Okay, let’s go read all the learning science papers about how middle school girls can’t do math-science: there are none
  - That doesn’t exist
  - There’s no such thing
  - But it’s this total meme that they believe

Joe explains, “*Part of our job in middle or when they transfer in high school is to fix that*.”

- There’s this concept of, “*Oh, I’m an art girl or I’m an English girl or whatever it is*.”
  - Girl, boy, there’s no difference
- We have some seniors this year ‒ the first one, her big project that she does at Alpha is the first all teen-produced created musical for Broadway
  - At Alpha, you do these big Alpha X projects
  - She sourced all the songwriters off TikTok
  - She can fill 1,000 person venue
  - She’s trying to raise it up so she can do it
- So she’d be, “*I’m an arts theater girl, 790 Math SAT.*”
- We have another girl (these are seniors), she’s trying out to be Miss Teen USA, 790 Math SAT
- Third girl (Joe’s daughter), call her TikTok girl
  - She’s got millions of likes on TikTok and tons of followers
  - She’s building an app to teach teen boys how to ask girls out on dates because teen boys are terrible at that
  - She’s top 1% SAT

***There’s this concept that these people can’t learn it. You’re like, they all can.***

**Now what do you have to do when they come into middle school?**

- When they don’t know their multiplication tables; they don’t know the pre-reqs
- Let’s go back, let’s fill them up

***And all of a sudden once you fill the holes, all of a sudden they can do it***

- Then once you know algebra, you can do chemistry

**⇒** K-8 science, there’s no math ‒ it’s all just memorizing facts (igneous rocks, and planets, and stuff)

- Biology is still more memorization, less math
- But then chemistry and physics are all math-based calculus and algebra

Joe explains, “*You have to get these kids the pre-reqs, but then all of a sudden they’re like, ‘Oh, chemistry is pretty fun. Now that I know calculus and I can crush Calc BC.’*”

- All our kids in high school, if you want to be on the honors track, it’s 5 on [Calc BC](https://blog.collegeboard.org/difference-between-ap-calculus-ab-and-bc)
- Totally doable for everybody
  - Our freshmen coming in by the end of the freshman year, they’re 1410 on the SAT (1350 is top 10%)
  - These are freshmen ‒ that’s better than most juniors and seniors
  - We can get freshman there
  - Most schools don’t publish their freshman results

> “*Once it becomes this mastery-based system, how high you go becomes a decision back to your effort. It’s a decision, not an inherent capability.*”‒ Joe Lieman

- Alpha kids are just in a mastery-based system they’re like, “*Oh, it’s just more work.*” It’s not, “*I’m not smart enough.*”
- And that is the unlock that we have to have and why we have to move to a mastery-based system
  - Because you just need kids to be like, “*Oh, if you’re a normal Alpha High, 1350 is the minimum SAT (you got to get to top 10%). If you want to be in the honors track, it’s 1550*.”
  - 1550 is top 1%

***It’s just a decision. Do you want to do the work to get to 1550 from 1350?***

Joe’s youngest daughter just took the SAT and she’s top 1%, but she’s not a perfect 800

- She’s asking AI, “*How much time will it take for me to get up to the top, to a perfect 800?*”
  - At that level, it doesn’t really matter for getting into college
  - She’s like, “*Dad, all those STEM boys, they think I’m this dumb TikTok girl. And if I get an 800, I get to laude on them for the rest of their life. And I think it’s totally worth it.*”
  - It’ll probably come back with 20-ish hours (some manageable number)
- It’s just a decision: Am I going to put the reps in to get there so I can have this?
  - An ego boost basically
  - Or am I going to do something else with my time?

**When you’re in a time-based system, you’re like, “*****I don’t know how to get there.*****” (there’s no path up)**

- This is an advantage of the mastery-based model versus teacher-in-front-of-a-classroom model
- When you log in to our system, it literally tells you in 2 hours a day:
  - You’re 3 years behind (and that seems insurmountable)
  - You’re 20-30 hours per grade level
  - So you could be 60 hours behind if you’re 3 years behind, 60 hours, that’s it
  - You’re 60 hours away, and you’re like, “*So if I do an hour of homework, in 2 months I’m caught up.*”

## Using short-term extrinsic rewards to help students overcome limiting beliefs and ignite lasting intrinsic motivation [A: 46:45, V: 52:35]

**Back to incentives**

- There’s some kids who are like, “*Do I care that I’m caught up?*”
- But it’s easy to incent them to want to catch up
  - You can figure out, what do we have to do?
- One of the things Alpha is known for is we use **extrinsic motivators**: we use money, time back is the most important one
- Time back is more important than money
  - It’s the Westlake honors track, where it’s 6 hours a day and 8 zillion homework hours ‒ you can’t pay a kid enough to love school by going through that
  - Versus we’re 2 hours a day for a non-honors track
  - Alpha School is 3 hours a day for honors track to the 1550 [SAT score]
- The honors track does take more time, but we will take middle school kids, and we will pay them $1,000 to get to top 1%

Kids often have the view, “*Look, I can’t do that. I’m not the smart kid. I’m not the math-science girl, whatever it is.*”

***If you get there and do these lessons and we’re just going to keep giving you lessons and you do the work, you’re going to get $1,000***

**The point of this is what’s even more important than the academic knowledge, it’s their internal view of themselves that changes**

- Kids come in and say, “*I’m not a math-science girl. I can’t be top 1%. I can’t do this.*” (whatever limits they have)

***A lot of education when you talk about it is holistically you’re trying to take limits in kids and release them, have them understand you’re limitless, you can do all this***

- And this is the best way academically we’ve found to do it
- Kids come in and the AI’s going to say, “*Here’s all the lessons you need to do to get to top 1%. And just go through them.*”
- And that motivation will get all these kids to the top 1%

The number of stories we have, all the Alpha families

- Where their student comes back and they’re like, “*I didn’t realize I could be top 1%. And my personal self-confidence and view of myself that I had to do hard work. I had to do the work.*”
- And then once you take a middle school kid who’s top 1% as they go into high school, they’re not going to give it up and there’s this mental view of, “*Oh, I guess, I am a smart kid or I’m a capable kid*.”

***That unlock is so valuable***

- That’s when we think juicing it with money
  - We spend $20 grand a kid in this country per student
  - And in middle school, we give a kid $1,000 in order to have them realize there’s no limit

**Why would most people listening to us have an uneasy feeling about that?**

- On the one hand, we’re spending $20,000 per year per kid and we’re getting nothing for it
- Joe is proposing we give kids a couple thousand of dollars strategically to incentive half of the equation
  - To motivate kids to do this

*And yet, that is going to make a lot of people feel uneasy. Why?*

- There’s a common view that there needs to be an intrinsic love of learning for it to be pure
  - It has to be intrinsic, not extrinsic
- And that if you’re buying, it’s sullied and not good ‒ it’s fundamentally wrong

*Are there any data that would support one view being favorable to the other? How would that be studied?*

- There’s a set of papers that have been written that show that if somebody is intrinsically motivated and you pay them, they lose intrinsic motivation

Now, that’s not the case that we’re sitting with

- We have kids who aren’t motivated, who aren’t intrinsically going through it
- They need the boost

***No parent who has their kids at Alpha thinks, “My kids lost their intrinsic motivation.” If anything, it’s the opposite because now they think they’re capable***

**⇒** What those papers don’t talk about is how much of the issue was [the narrative of]: I didn’t think I was capable, I now realize I am, and I get this crazy intrinsic boost around it

**Joe’s youngest daughter is an example**

- She came into middle school, she hit top 10%
  - This is going into 7th grade
- She had been like, “*Dad, , I’m not like my older sister. I’m not top 1%. That’s just not who I am. I’m TikTok girl.*”
- Joe told her, “*You know what I know you love more than anything is shopping. I’ll bet you $1,000 that you can’t get to top 1%.*”
- She literally would fill her Amazon cart with $1,000 of stuff
- And in the morning, she’d look at the lessons she had to go through and she’d do it
  - She’d just grind through it
- We had a lot of family discussions around this because Joe’s wife was like (and most parents are like this), “*Wait, there’s two things here, (1) you’re setting top 1%. Why are you putting that pressure on the kid? And (2) it doesn’t feel right to pay $1000 to get this.*”
  - Most parents think that’s too hard
  - We were all brought up to think there’s something wrong with paying for it
- His daughter achieved top 1% and buys everything

***She sits down with her mom and is like, “Mom, know you didn’t like us doing this, but you need to understand what this has done for me, which is I never thought I was as smart as my older sister. And now I realize I can do everything that she can do. And it’s totally changed my internal view.”***

> “*That change in their view of their capability, that unlock is so valuable. And I believe we should do this for every kid in America.*”‒ Joe Liemandt

The path forward

- You then just have to decide if you can use extrinsic motivation, whatever it is, buy him concert tickets, go shopping, screen time, video game time
- Whatever it takes to get the kid to realize, “*I can go be and learn all this and be top 1% when I previously didn’t think that. And I go through that struggle, fail, sometimes cry on the road to success loop that then unlocks my human potential.*”

***The point of education beyond academics is you’re trying to unlock human potential and this is just a great easy way to do it. It’s not available in a time-based system.***

Peter points out, “*It’s not necessarily something that has to happen indefinitely.*”

- What makes sense here is that it’s an unlock that then creates a new state of awareness that therefore becomes self-perpetuating
- In many ways it’s like the kindling that leads to the fire: you don’t need kindling indefinitely, but sometimes you need kindling
- Joe agrees, that’s a great way to think about it
- He’s not paying her to decide to go get a perfect score on her SAT
  - It’s intrinsic, it’s her decision, it’s her capability
  - She just needed that kindling to jumpstart it

***Whatever block was in the mind, good coaches are like, “How do I unblock them?” And that is what this does***

## $100 for 100: a simple but powerful incentive system that helps students fill academic gaps and master fundamentals [A: 53:45, V: 1:01:00]

- Since we’re on this topic of paying kids
- The secretary of education is coming down next week to meet with [McKenzie](https://2hourlearning.com/founder/) around Alpha and stuff

***And if there’s one thing to fix education in America, what’s the simplest unlock? It would be this and it’s all around “hole filling” and paying kids***

**Hole filling**

- When Joe first started, he wanted kids to go back and “hole fill”

***Hole filling is going back and doing your prerequisites***

- Joe is sitting down with 7th graders, and you know what does not motivate a 7th grader?
  - Doing 4th grade (no kid wants to go back)
- The only people who want it less than the kid are their parents
  - Every parent in America has been trained, my kid needs to be at grade level

**⇒** Once again, the learning science says that is not right: get your kid to master the basics

- And if it’s previous material, give it to them
- Joe has tried to convince parents, “*Your kid needs to hole fill if we’re going to get this whole thing working and stuff*” And he basically ended up giving up on the parents
- So then he went to the 7th graders and was like, “*Okay, here we go guys. You could get 100 on the Texas Star.*” (the state tests), and they were like, *“No way. Mr Liemandt*”
  - He explained he would give them each a $100 bill for 100 on the test
  - They still thought it was impossible
  - He continued, “*No, no, no. There’s a catch: any grade level*.”
  - They were like, “*I can take a kindergarten Texas Star and you can give me 100 bucks?*”
  - He explained that it starts at 3rd grade
  - They’re like, “*4th grade?*” and he said, “*Absolutely.*”
- By 5th grade, they were running into trouble
  - They get 75-85
  - There’s holes

**Joe asked students if they want the AI tutor to generate the lessons for the questions they missed**

- Students wanted to know how many lessons it would be, and if they could do that in a week
- They’re in, get the 100, and that continued for 6th and 7th grade

***This brought the kids up to grade level, but more importantly, they all think and know they can get 100 on the state test***

- A score which used to be only the GT kids [gifted & talented] and smart kids get
- If you survey incoming Alpha parents and say, “*Can your kid get 100 on the Texas Star?*” Fewer than 10% say yes they can

**⇒** After we’ve been at Alpha a year, 90% of kids are like, “*I can totally get 100 on a Texas Star,*” because they’ve done it

- Our building over there gets more hundreds on the Texas Star than a school district of 100,000 kids

***It’s just because we have a mastery-based system***

- The advancement built into the system at Alpha will advance a kid if they get over 90
  - What is our **mastery standard**? It’s in the 90s
  - So you have to score >90 on the state test to move on to the next grade level material
  - But they also have $100 for 100 ‒ so the kids aim for 100

**Peter finds this to be an interesting natural experiment:** if the kid is motivated to just do the bare minimum, they’re going to take the 90

- And if you make it 100, there’s a little reality of bringing your parents and everybody along with you on this crazy journey we’re on

Joe points out

- When you get to the higher material and you’ve done 90, our app is still going to go back and fill those 10%, because it’s the best way to learn
- Earning 90% on the state test just get them advanced

***But earning 100%, the kids all just do it because they know they can. And it just gets the right mindset going***

**The mindset at Alpha School**

- Literally, for the SAT, everybody thinks you can’t get perfect scores
- Kids at Alpha are like, “*It’s just some extra work.*”
- 5 on [APs](https://en.wikipedia.org/wiki/Advanced_Placement) [the top score]: people think that seems impossible
- Kids at Alpha are like, “*Oh, how many hours is it?*”
  - It takes 75 hours to go through AP world history or AP US history
  - And they’re like, “*Oh, I got 15 hours left to get a 5*.”

***So you just change the concept***

- Now, there’s some upper bound where there is conceptual understanding and everybody can’t get there
- But K-8 curriculum, we can totally do this ‒ this is what would change education in America

## How AI is the pivotal technology that can finally allow proven learning science to scale and unlock unprecedented student potential [A: 57:45, V: 1:05:53]

**Earlier, Joe said something that Peter found remarkable, he compared education to medicine in terms of an unlock. Talk a little bit about that.**

- If you go back to the sciences, and whether it’s biology or medicine, chemistry, physics, all of these had periods in the wilderness
  - Doctors bloodletting and things like this

***But there was the invention of an instrument in each of those that allowed more precise measurement that unlocked and inflected the science***

In medicine it was the light microscope

- If you were going to talk about one instrument that took us from what Peter describes as the dark ages of medicine 1.0 into medicine 2.0 (which is where we are today)
- Without the light microscope it couldn’t have happened
- [Sid Mukherjee](https://siddharthamukherjee.com/about-siddhartha/) wrote very eloquently about this in his most recent book, [*The Cell*](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human/dp/1982117354/ref=sr_1_1?crid=3EXWP8Y3TKM47&dib=eyJ2IjoiMSJ9._qSQo8HL5-d-0Y9_OoOOHSrgciQVJfKZsSjwVhv2C7k.bu-edSrEuXN9FGxkOuRUDq3H84PKuP-9p8f7oogdGzo&dib_tag=se&keywords=Sid+Mukherjee+the+cell&qid=1757948326&s=books&sprefix=sid+mukherjee+the+cell%2Cstripbooks%2C100&sr=1-1)
- Basically, until we could actually start to see microscopic organisms, we couldn’t really handle [germ theory](https://en.wikipedia.org/wiki/Germ_theory_of_disease)
- And until we could eradicate germs, we couldn’t really live past about 40 (on average)
  - There were just too many people dying too young

***That one piece of technology unleashed an entire change in the way medicine has been practiced, which of course has spread out far beyond infectious diseases***

- It’s impossible for Peter to imagine a scenario whereby we are alive today and the way we are without that

**Papers on learning science that have been written for the past 40 years**

- They all start with this model that doesn’t work: a teacher in front of a classroom and a time-based system
- You had the conceptual solution for the last 40 years on how to fix education, but there’s been no technology to make it happen
  - You haven’t had your microscope

**AI is finally that microscope because of a couple things**

- The **effect size**, when you put an experiment into a classroom, the question is:
  - Is the teacher teaching it correctly?
  - Is it using space repetition correctly?
  - Are the students engaged?
  - Do they have the prereqs?
  - You just don’t know
- And so your environmental variables dominate your effect size

With AI you get 2  things

- 1 – You get absolutely precise teaching, you know exactly what is being told to the kid
- 2 – You have this closed loop measurement, you can measure what do they know and what they don’t know
- And then you can do science
- You can create this closed loop

**Alpha rolled out their new system (**[**TimeBack**](https://timeback.com/)**) to all their students this year (a couple weeks ago)**

- Joe believes their math curriculum this year is going to be better
- Kids will learn more in 20% less time
- And we know that because we’ve been measuring it

**Joe looked at last year’s math data and looked at what kids learned**

- Were they 95% right?
- How long did it take each kid to go through the lesson?
- What do we need to change?
- What learning science concept can we put in the lesson that’s going to then allow them to learn better and faster?
- And what’s going to change the scheme of their brain?
  - Not cramming, but really understanding this
- The kids took the standardized test ‒ oh look, it did work

**⇒** And you can just create this closed loop system where you’re able to do science

***Nobody else has that, and that’s the problem. We need to create that system.***

**But to do that, you have to give up the most treasured notion in the world**

- Which is the key to a good education is a teacher in front of a classroom
- One of the things that’s true about education: before there was tutors
  - You had Socrates and Plato and Aristotle
  - Alexander the Great and all the elite had tutors
- And then 200 years ago, we have to educate everybody
- The only way cost-effectively to do that is teacher in front of a classroom
- And that is all any of us know, our parents know, our grandparents know (we’ve all been in that)
  - It did great things, because at scale we have educated people that never would’ve been educated before
  - Peter admits that he wouldn’t have been one of the tutored ones
  - And you can go to the poorest school district in India, and there’s a teacher in front of a classroom
  - You can go to whatever private school that’s charging $50,000 and it has a teacher in front of a classroom
- That is the model we all know

**Before you get freaked out, Joe’s vision for 20 years from now is**

- Parents are going to drop their kids off at a building, and in that building are going to be other kids and adults
- And those adults, you can call them teachers, guides, coaches (whatever you want)
- We think the day will be very different, but that concept of a school with teachers and other students, that’s not going away
- We’re not moving to this AI robot terminator
- You’re going to drop the kids off at a school, and if we do our job right, you don’t sit in class for 6 hours a day and have this miserable experience

**Back to the science of it: now with AI, can have a one-on-one relationship**

- The AI knows: What does the kid know? How do I give them this lesson?
- Where we’re headed: Gen AI is changing everything
- Now you can craft personalized lessons for every kid that takes into account what goes into the LLM on the technology side
  - What are you trying to teach them?
  - What’s the curriculum?
  - What is their knowledge graph?
  - What do they know and what do they not know?
  - What is their interest graph?
  - What are they interested in?

**⇒** Because if I know your interests, I can engage it

- If you love baseball and you want to learn stats, I’m going to determine it and kids are going to get engaged
- If you’re the fashionista and I’m going to teach you fractions…

**Is the app already able to do what you just described?**

- Today in 2025, we generate static content with human review
  - Because we still have too many hallucinations

***We’re not there, but in 2026, we expect we’ll be able to do it***

**To put this in perspective ‒ Peter’s 8-year-old**

- He’s a kid who loves baseball; all he does it talk baseball stats
- He will be able to get to know his AI tutor, they will figure out in short order that the way to his heart is baseball
- And anything that you can teach in baseball terms, he’s fixated

***It will be able to give him a lesson to pursue mastery, but under the guise of baseball***

We all know that’s what teachers are always trying to do

- How do I get what the kids like and associate with it?
- But at scale, you don’t have 30 kids who like all the same things,

**Here’s an example of what you can actually do today**

- You have hallucinations and you don’t want to release those yet
- We have a dynamic reading generator, it’s called “Teach Tales,” and the goal of this is to get kids to love to read
- If you take a third grade boy who’s like, “*I hate books. I’m not a book guy*.” And you ask, “*What’s your favorite movie? The Avengers? Who are your soccer buddies?*”
- The AI generates a choose your own adventure where you’re saving the world with your soccer buddies (they have to keep clicking)
- And literally  the difficulty goes up (at the [Lexile](https://en.wikipedia.org/wiki/Lexile) level)
- It’s keeping you in the zone ‒ proximal development within 10% of what you know, your Lexile level
- Kids will sit there and click for an hour totally engaged (nonstop reading)

**⇒** We do have a reading problem in this country: people don’t read books

***This is the kind of thing where Gen AI is going to be able to suck kids in***

- Our competition is Fortnite and TikTok

> “*We need to use things like gen AI to create such compelling content for kids that’s related to what they care about, that also teaches.*”‒ Joe Liemandt

- For example, I got to teach you fractions, but we’re doing this baseball thing (you’ll love that)

A different way to try to solve it without an AI tutor

- There’s all these finance moms who teach their daughters poker in middle school
- And they’re like, I’m going to get them into poker to teach all these math skills and all the things that aren’t being taught at my school

***But with AI, we can get that engagement level where the kids are interested in it***

**A couple of examples**

- In some of Alpha’s high schools, when you transfer into Alpha High, your knowledge of **history** is very limited
  - Which is, if it’s in the musical [Hamilton](https://en.wikipedia.org/wiki/Hamilton_(musical)), you know it occurred
  - And if it didn’t occur, it’s not in a song in Hamilton, you don’t know it
  - Because we don’t teach history very much anymore.
- Kids in our US history, AP world history, they literally used AI to create songs
  - They did this on their own, it wasn’t our stuff
  - They gave it all the facts (there’s 9 units in US history), and for each unit they created a song
  - They said, “*Give me all the facts that I need to know for this unit*.”
  - They pumped it into [Suno](https://suno.com/home) (which is an available song generator), and they created their own album of songs
- They all would just sit around and sing the songs and learn the facts that way, and do it in a way they all were very interested in
- They all got 5 on their AP [exam] because you can do it to mastery

***Gen AI is going to allow us to create this awesome dynamic content that’s relatable and applicable to what kids want***

**The fastest way to learn is basically analogy**

- This is the “A” in Dean Schwartz’s book, [*The ABCs of How We Learn*](https://www.amazon.com/ABCs-How-Learn-Scientifically-Approaches/dp/0393709264/ref=sr_1_1?crid=UQF4S1QTX0YR&dib=eyJ2IjoiMSJ9.hXe2iuyYIRSfpASu3DOtDCcnc1g2YuJAuxwMyY0s1A6iZp-gtajgQKQJBln22gJKH5jm_xeor8DX4d0pjgzh6hoNVOtMXuYsg_QgRuxlq6lrBWJYO8Q5yvp-T63Wwjy_qBoXteXT5SIkxOA0zw3MU1cj0cGKVoYUCrarROE6d_bhEmzPoJlzX5I0UBkKqPmzxsVsYE8wD-Tl6r9WEPfns6rXEUaHj6aa2brO--r56JA.6eDw5YVG7TUiOdCFqtq_mdVIOSQlbTba0SOpjoMRohY&dib_tag=se&keywords=the+abcs+of+how+we+learn&qid=1757338106&sprefix=the+abcs+of+how+%2Caps%2C108&sr=8-1)
  - It goes through everything that learning science has come up with
  - [Dean Schwartz](https://profiles.stanford.edu/daniel-schwartz) is from Stanford, School of Education, one of the leaders in the field
  - A is analogies

***If you know what a kid knows, that’s actually the fastest way to have kids learn***

- We have a content team, and when Joe talks about those 100 facts, ideas and concepts per hour ‒ what they’re using as a reference is they’re using TikTok memes
  - Because kids know TikTok, and they know what’s on TikTok
- So let’s take what we’re trying to teach them and use something they already know

**To take that further, we will be taking into account the cognitive load of their brain**

- This is the part we don’t have yet but our team is working on
- We’re going to be able to create a lesson where we know how many working memory slots you have
- We know what you know to fluency and what you don’t
- And we’re not going to give you a question that’s going to overload your working memory
- We also know how many reps you need
  - And GT kids [gifted & talented] need fewer reps, and so we’re not going to bore you by giving you too many reps to memorize it
  - Conversely, we’re going to make sure you have enough reps if you need them

***This is personalized learning where you’re generating the content dynamically and it’s going to be just this crazy unlock for these kids***

- 5 years from now, we’re going to look back and be like, “*Okay, well obviously kids can learn 10 times faster.*”
- We wake up every day, it’s like Neo in [*The Matrix*](https://en.wikipedia.org/wiki/The_Matrix): that’s a physical upload
- Ours is using learning science concepts kids can learn 10 times faster
- You have 12 years to fill your kids’ head with cool stuff, knowledge

***We just need 2 hours a day at 10 times faster and all the kids can have more cool stuff about stuff they like in their heads to mastery level***

- Levels none of us as parents could ever imagine
- And still give the kids their time back for the rest of the day to do all other things

## The emergence of generative AI that catalyzed Joe’s billion-dollar investment in education [A: 1:09:45, V: 1:19:48]

**About 3 years ago you decided you got to step out of** [**Trilogy**](https://trilogy.com/)**. It’s this incredible company you’ve built. Are any of your co-founders still there?**

- No
- 3 years ago, the transition was when gen AI came out
- Neural nets are finally here ‒ that was a great unlock for Joe where he had seen MacKenzie’s great school and his kids in there
- There were issues like his daughter failing her 7th grade test and stuff, where the apps aren’t good enough, all those issues

***Joe realized that gen AI will allow us to take the magic of Alpha, make it better and scale it to a billion kids***

Joe’s realization: there’s lots of good educational things that just don’t scale (this was Joe’s light microscope)

- Joe had been doing software, and he went to his team who’ve been there for 25 years
- They run Alpha now and Joe is the Principal
- Joe’s also the chairman and he’s literally the worst shareholder you’ve ever seen
  - Because he’s like, “G*uys, I need more cash flow. I need more dividends to fund this whole thing. MacKenzie needs $300 million to open up all these schools. Where are we going to get it?*”

**How much of your own money have you spent on this now?**

- 3 years ago, Joe took a billion dollars out of Trilogy and said, “*I’m going to go use this billion dollars to figure out what I can with education, and fix as much as I can.*”
  - That was his first lump sum

***Now, what’s crazy about that is a billion dollars is not enough to fix education. It’s a trillion-dollar industry.***

- We have obviously have made incredible headway, but we have to go back to building schools
- Back to [MacKenzie](https://2hourlearning.com/founder/), she’s opening up 25 offices around the country, she needs hundreds of millions of dollars for that
  - We’re opening up these [sports academies](https://texassportsacademy.com/), which needs hundreds of millions
  - We’re opening up 500 gifted talented schools
  - The total CapEx that’s going to be required

**The second part is to get it to a billion kids and give kids their time back**

- Joe is going to do this in the next 20 years
- His job is to go fix education
- Use the light microscope, use AI to totally change the first 12 years of a billion kids [lives]

## The path and obstacles to integrating Alpha’s AI-powered model into mainstream education [A: 1:12:00, V: 1:22:21]

**At what point, Joe, did the two educational systems have to merge?**

- One of the reasons he’s having to deploy such insane amounts of capital is because you’re basically rebuilding things that are technically already there
- We have buildings, we have schools; we have guides (they’re called teachers)
- We have all those things, but you’re creating a new system of infrastructure
- Peter assumes you don’t want to have to build the scale to a billion

*At some point this way has to merge with the existing way. At what point does that merger take place?*

- Joe’s view is there’s a point of: if he had perfect randomized controlled trials, maybe he would need 10 million kids going through it for everybody to be like, “*Okay, this looks like it works.*”
- The amazing thing to Peter is that the bar is so low [for improvement of education]

**When Peter thinks about places in medicine where massive clinical trials are necessary to change the direction of something, usually when the state of play is so bad**

- He doesn’t use this example to be offensive to people that are within education, but let’s look at HIV in the 80s and early 90s
- It was a death sentence
- The bar was pretty darn low when [HAART therapy](https://en.wikipedia.org/wiki/HIV) (highly active antiretroviral therapy) came out in ’95 or ’96 [and] boom, that changed the protocol
- Of course, pharma is easier than education in the sense that it’s a simple intervention

**Who’s pushing back when you say, “*****Hey, guys, what if we just prove this out in a million kids? Why do I need 10 million kids to prove this?*****”?**

- Especially if they’re spread out over a broad enough socioeconomic background
- That is Joe’s next phase, and also why he’s doing his first podcast in 20 years
- There’s a lot of impediments to it
- 1 – Let’s go back to that discussion of parents don’t care about academics
- 2 – Believability
- There’s been EdTech pitches
  - Everybody, every 5 years: EdTech is going to solve the world
  - Technology’s always going to solve the world, and it doesn’t solve it ‒ there is good, well-earned natural skepticism
  - Evil billionaire tech guys trying to fix education…
- The skepticism should be super high, and that’s part of what the job is and why it takes a billion dollars ‒ we have to go prove it across everybody and in a broad way

**Let’s talk about some of the problems with it**

- Let’s talk about academics right here in Austin: there’s been 3 failing middle schools in Austin
- Joe clarifies, if he was a principal of a public school, that’s 100x harder job than his
  - Because he’s a product guy
  - People who come to his school are aligned with what he’s building and offering, you get selection effects
- But at public school, you get what you get
  - For 5 years they’re not educating kids
- Joe made his first proposal to the superintendent a month ago and he was like, “*Why don’t we shut these schools and we have these better schools, and the kids just go to the school where the kids are learning?*”

The protests from the parents

- It’s the mom who says, “*Look, I know that 7th grade math teacher, she’s probably not teaching math very well. But my older daughter had her, she changed her life. And my kids can walk to school and it’s a community. And so if they don’t learn 7th grade math, so what?*”
- Parents care about other things because school is a bundle
- Do parents even know what they want?
- There’s skepticism that this approach doesn’t really work

Why don’t we do randomized controlled trials or pharmaceutical caliber stuff with education?

- Because there’s all these ideas of what work
- Ideas like no multiplication tables
  - Somebody should have done a controlled trail to realize that’s a really bad idea
- There’s all these fads in education, it’s not science

**⇒** One of the scariest data points in learning science: there’s 3 million teachers in the world that are not taught learning science

- These concepts will be new to them
- How do we fix it?

***We have to go teach all the teachers about learning science***

**Do you get pushback on that point?**

*How much time do you spend talking with the teachers that are in the trenches right now?*

An analogy from Peter’s world

- He talks about this idea of medicine 3.0
- Medicine 2.0 has been amazing
  - You and I wouldn’t be alive without it
- But Peter would argue it’s time to move on; we’ve plateaued

***We’ve got to do medicine 3.0, we have to unlock the next thing***

- But when Peter says that, he’s not being critical of the doctors who practice Medicine 2.0, because he hasn’t met many of them who wouldn’t in a heartbeat say, “*Look, I wish I could do Medicine 3.0, but the system I’m in doesn’t allow it. I can’t get reimbursed to practice medicine 3.0*.”
- The entire system of billing and coding and diagnostics and prescribing, it’s all predicated on this system
  - It’s predicated on make the diagnosis for the disease
  - There’s no prevention
- Doctors don’t get paid to, nor do they have the education to learn about nutrition, exercise, all of these other things that are necessary to Medicine 3.0

Peter adds, “*But if I could wave a magic wand, my bet is 80% of them would be like, ‘If there’s a way to fix the system and the structure such that I can be balancing my practice between 2.0 and 3.0, I’d do it in a heartbeat.’*”

**Is this the same with teachers?**

- Do you have a sense?
- Have you got enough reps with teachers to understand if you had that proverbial magic wand, how many of the superintendents and the teachers would say, “*Oh, my God, I’d love to transition from being a front of the classroom teacher, to an in the classroom guide who’s helping the student with their personal AI tutor.”*?

***The answer is, at least 80% of them***

- The guides at Alpha are ex-teachers
- We got into this whole naming thing: Do you call them teachers if they’re not doing academics, and whatnot?
  - But fundamentally, when they tell their story of what they do all day [they’re a teacher]

***Let’s just talk about teachers specifically: teachers are great and critical, and teacher in front of the classroom is bad***

- But to Peter’s point, it’s the system
- Teachers got into teaching to transform kids’ lives
- They did not become a teacher to grade the 7th grade science test
- Let the AI do the 7th grade lesson and the science test, and you connect with your kid, your students

**During our 2-hour blocks, we do 25 minute pomodoros**

- Our guides (ex-teachers), they’re not in front of the class lecturing
- They literally take the kids one-on-one and say, “*Hey, don’t do your language today. Come sit down and talk to me for 25 minutes. How was your weekend? How’d the softball tournament go? Hey, you don’t seem as motivated lately. What’s going on?*”
  - And they connect with them
- Our guides, they provide motivation and emotional support
- They set high standards and high support
- They’re the ones guiding these kids through the journey
- And that’s why teachers became teachers
  - I want to write a lesson plan ‒ nobody woke up and said that’s why I’m becoming a teacher

***Teachers became teachers because they want to transform kids’ lives, and that’s what this new model does***

When teachers see it, they love it

- One, we pay more
- But also, the teachers see our model, and once they really understand it and talk to our existing ones, they’re like, “*This is awesome. I love this*.”
- And so there isn’t resistance

**At the systems level, Joe has talked to a lot of superintendents**

- They don’t know what to do with this
- What are kids supposed to do the rest of the day

***The problem is, this is a rebuild around the school day***

- It’s not 6 hours a day in class with teachers and removing kids between classrooms
- Peter proposes: 2 hours a day of learning in the screen and 4 hours of day of life skills and sports
  - All the other things that are going to be imperative to create well-balanced kids
- The life skills curriculum at Alpha is leadership, teamwork, storytelling, public speaking, relationship building, socialization, grit and hard work, entrepreneurship, financial literacy
  - And they’re doing workshops in the afternoon
- If you go to [MacKenzie’s Instagram](https://www.instagram.com/futureof_education/): kids climbing rock walls in kindergarten, or they’re running 5K’s in second grade
  - Or the fifth graders launched a food truck.
  - Running Tough Mudders, 8th graders do that stuff
  - [an example is shown below]

[![](https://peterattiamd.com/wp-content/uploads/2025/09/f2-joeliemandt.png)](https://www.instagram.com/p/DNGZ6QhxYFl/)

**Figure 2. Post from MacKenzie’s Instagram**. Image credit: [futureof\_education](https://www.instagram.com/p/DNGZ6QhxYFl/)

***The superintendents say their system is not set up for this, and there’s no demand from parents because it’s not proven***

**Outside of public school, if you talk about super high-end private schools**

- Joe has tried to convince super high end private schools telling them they can have all the flexibility they want
- There’s no vote, there’s nothing

***Their view is, “This seems like a bridge too far.”***

- That’s a view of Joe’s job

**Is that why essentially Alpha exists as an independent school at the moment. Is it that you just need to get the scale of wholly owned Alphas that build this out?**

- Peter thinks that at some point others, probably private schools have an easier time joining the model
- Eventually the hope is that public schools do so as well

> “*I got 20 years and I got to get a billion kids, 80, 90% of kids are in public school. You got to get it to public school and provide it to everybody.*”‒ Joe Liemandt

**What is the current cost?**

- Peter is sure they’re hemorrhaging and losing money at the moment

*What is the current cost to deliver the education to a child and does it vary by their grade?*

- Alpha is opening across the country in every city ‒ there’s going to be this alpha exemplar
  - This high-end of what’s possible
  - It’s also one where money is no object (it’s really expensive)

***Alpha is using the latest AI models, this is real time streaming video to coach kids ‒ it’s $10,000 bucks a kid (just in AI cost)***

- It’s too much now

Joe adds, “*I absolutely believe, and our team’s going to deliver it, where sometime in the next 3 years, maybe 5, everybody on the planet will have a tablet that’s less than a $1000 that will teach them everything they need to know in 2 hours a day or less.*”

- The compute will be local
- A lot of our stuff right now is vision models where we’re looking at stuff
  - There’s on device, all the hardware manufacturers are putting their AI chips on device
  - We’ll hit that
- Joe is sure there’ll still be some stuff in the cloud for higher end stuff

***The common core curriculum through 8th grade will be on device for less than a $1000; that’s absolutely coming***

## Reimagining schooling from the ground up across five key dimensions [A: 1:22:30, V: 1:35:11]

**The second part of what Alpha is re-envisioning what a school is from the ground up**

- We sit around brainstorming what would make a school 10x better than the old school we went to
  - We have 5 dimensions of that

**#1 – Kids must love school**, and we literally measure that as love it more than vacation

- We get about 50% of kids ‒ it depends on the vacation, and it depends on the workshop

> “*50% of kids who are like, ‘Yeah, I want to go to school instead of vacation.’*”‒ Joe Liemandt

Joe’s highlight as Principal

- It was in May this year when ⅔ of the high school kids sent him a note asking, “*Can we keep Alpha High open this summer. We don’t want to take a summer break, because we love what we’re doing.*”
- The girl doing her Broadway musical, she’s like, “*I want to keep coming to school and doing it*.”

**#2 – Kids need to learn 10x faster**

- Our AI tutor based on learning science teaches kids 10x faster ‒ between 5-10x faster and we’ll get it up
- That gives you the chance to give the time back.

**#3 – The third dimension of a school is academics isn’t everything to developing kids**

- Everybody knows that
- What are the life skills that every parent says, “*That is what I wish I knew.*” And some are behavioral traits
  - I hope they love learning and are self-driven learner
  - I want somebody who uplifts others in his classroom and is an independent person
  - Others want entrepreneurism and financial literacy
  - Or I want storytelling, public speaking
- The third thing is to have that curriculum

Joe explains, “*We actually have spent the last 3 years developing LifeCore, the common core curriculum for life skills*.”

***We have 4 hours a day to fill with all this awesome stuff the kids can do, and it’s just amazing what they do***

If you take [*Atomic Habits*](https://www.amazon.com/Atomic-Habits-Proven-Build-Break/dp/0735211299/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.f40BjO3UpSUHUPMm8WsQZJ32IF5PTOiAQHSO7rt21EoAJtppaX-BPfEEjF2D5XtO2m_xDClmIZOC-fkg7qy8UyIMsh1ZJxfx1Uo_epnBwruf_7IS6vQRJQ2FSOeulVcO_vfRXa4BO5z0GimfVpkx4F8KO2iCmQr_bQiS_qdIF_QHc6vTJJO89NOqx7jgwjRJWmWbWP9-1gom54EckuM2kHmQ6OC0M44w8LHxcL89UQc.W7gEmovoX8wtKrXiwqZ8cPBLhFvMVcLQcTjbzIXLy7E&qid=1758027680&sr=8-1), that book of 1% better

- Most people don’t read that till after college, and then they’re like, “*Oh, this is a way I can really develop.*”
- [this was the subject of [episode #183](https://peterattiamd.com/jamesclear/)]
- Last year, Faith (a 2nd grade guide) was working on her workshops for life skills and decided she wanted to teach *Atomic Habits* to all the 2nd graders
  - Because the concepts, they can all understand
- She’s like, “*I’m going to have all our second-graders run a 5k in under 35 minutes.*”
- Joe didn’t think this was a good idea
  - The parents are not going to like that
  - That’s too hard
- Back to high standards
  - They don’t want to struggle/fail
  - Where’s that road to success part and what percent are going to make it?
- She’s like, “*Don’t worry, I can do this*.”
  - She was a UT athlete and she’s like, “*We totally can do it… Everybody can do this.*”

She sits down with the 2nd-graders on the first day and asks, “*Who can run a 5k?*”

- And they’re all like, “*That’s impossible, Miss Faith*.” (the parents said the same thing)
- She’s like, “*Well, I signed you all up for the Jingle 5k at the Domain*.”
- She goes out to the track and the first day they walk 5K
- She’s like, “*Okay, so we all established you’re going to finish the race.*”
- And then the next time they ran a quarter lap, walked the rest
- Next time they ran half a lap, walked the rest

***And by December all the kids are running the race, and when they cross the finish line, just that achievement***

- Back to the key to your kid’s happiness is high standards
- That’s a really high standard

***But they loved it and they did have to struggle and go through and learn this, but they also learn that life skill, of 1% better***

- And so the second-graders were like, “*Dad, I can do anything. I can do 50 push-ups. I’ll do one today and two tomorrow and build up.*”

> “*And that life skill, we don’t teach kids in school. It’s a great life skill to have and if you have half the day you can do that.*”‒ Joe Liemandt

***Great life skills, that’s the third element of how do you build a great school***

**#4 – The fourth element gets teachers connecting with the kids**

- What would make a teacher 10 times better than what it is today?
- And the answer is not grading science tests all day and writing lesson plans
- Here’s the questions Joe asks students and parents (kindergarteners), “*Do you love your guide?*”
  - As you get older, every adult had 1 or 2 teachers who transformed their life, right back to that
  - Is your guide that for you?
- That is the expectation that they are the ones that the students are like, “*You are helping me achieve things that I didn’t think is possible. Miss. Faith, you taught me how to do the impossible.*” (that level)

On the parent side

- This gets into [Dr. Yeager’s](https://liberalarts.utexas.edu/psychology/faculty/yeagerds) book, [*10 to 25*](https://www.amazon.com/10-25-Motivating-Groundbreaking-Generation_And/dp/1668023881/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.1BcyNiO2SYzF1RAf8PhRDIqCIxWdcpEwe00k0YBe0F8EWRMFUbR3FjYMsRB-7NCVscKse8dvjBC8lrZ6xvGbcRrkqUm5POk0Y-kGmii2aAflfkNTUqYsrjkVqp7HUcR2w6GDRLLHPIh2AoFU06xDuG5V7R_pxpkHaF1kEO4N-3Qqa0zPJvOtAm9KHRnByV2_BOHPMkQ0S05-NqlNlMIpWcGIs9ufdsg-x76GfoCUN8U.uJqw68bqYi41xOWOObtlGBOOj813pbzeAs4FGmwbqZY&qid=1758028884&sr=8-1)
  - He’s a child psychologist developmental expert
  - His whole theory mentor mindset, high standards, high support
- Most parents are not high standards and high support, which is what really matters to develop kids
- They’re either low standards, high support
  - That’s what happened to all our expectations
- Or they’re the inverse, high standards, no support
  - This would be your classic tiger mom: Good luck. Figure it out.

***For child development, you need both high standards, high support; and that’s the guides at Alpha***

Back to the question of what’s a school and re-envisioning it

- The question we ask parents in middle and high school: Do you trust your Alpha guide to hold high standards for your kid, so you as the parent can provide the unconditional love and support?
- Which transforms your relationship where you don’t have to be the naggy parent for the high standards
- Joe’s oldest daughter is writing her college essay and he asked her, “*You want to let me read it?*”
  - She’s like, no ‒ not interested in that
  - She’s got someone else
- For him, he was super relaxed because he knows her daughter’s guide (Chloe)
  - She’s a Harvard grad
  - She has totally high standards for his daughter and he knows it’s going to be fine
  - And he doesn’t have to get into a fight about it; he can give his daughter a hug and be like, good luck

***That transforms what teachers can be versus I’m delivering those 7th grade lessons***

**#5 – The 5th dimension that we talk about is the C’s: character, community, classmates, and culture**

- These are also the hardest parts to measure
- But at the end they’re what parents care about the most:
  - Did I raise a good kid?
  - And is the school helping me raise a good kid?

***Those elements are what we looked at and said, “Now that you want to envision school from the ground up, here’s the dimensions.”***

**⇒** Alpha is trying to be the exemplar for all of it

**Then the question is, okay, how do we get the price point down?**

- We have opened a whole set of different schools that half the price of Alpha
- Alpha depending on its location, is between $40-75,000
- There are tons of scholarship programs
- We have a school down in Brownsville where it’s the second-poorest school district in the country
  - [SpaceX Starbase](https://en.wikipedia.org/wiki/SpaceX_Starbase) is there
  - We scholarship all the locals to come in and it’s 60/40, 50/50 between that makeup
- To be clear, they all learn 2x in two hours
  - Back to testing it out ‒ it works with all kids

## The potential of this educational approach to reduce inequality in academic success [A:1:30:00, V: 1:44:08]

- Recently, Peter read something that fits right into this from [*The New York Times*](https://www.nytimes.com/2025/08/14/opinion/trump-democrats-resistance-reform.html)

“*Before kindergarten, the children of the affluent are much more likely to be in preschool. By 6th grade students in the richest school districts are 4 grade levels above children in the poorest school districts*.”

“*By high school, richer kids, average reading skills are 5 years ahead of poorer kids. By college, according to a 2017 study by Raj Chetty, children from the richest, 1% of earners are 77 times more likely to go to Ivy League schools than children from families making $30,000 a year or less*.”

“*The academic gap between the affluent and less affluent is greater today than the achievement gap between white American and Black American kids in the final days of Jim Crow.*”

- Peter’s read of this is that there is no greater predictor of academic success and failure than the wealth of your parents

**Are you suggesting that all of that could be wiped out?**

- There’s always relative versus absolute
- Joe believes we can raise the absolute standard
  - It’s always an arms race

*Put it this way, instead of the gap being 77x, could that gap be 1.2x?*

- Yeah, 100%

Back to what happens when you’re in a rich school district

- Joe was in New York at $75,000 private schools, teacher in front of a classroom
- Every one of those parents also was spending $750 an hour on a tutor after school
  - Because the school wasn’t teaching them (back to that problem)
  - That’s an extra $75 grand ($150 grand a year)

***You need the tutor who’s going to go back and fill the holes and stuff, and if I’m in a poor school district, I don’t have access to that***

- If you look after COVID, the #1 intervention and a lot of government funding was spent this, was high dosage tutoring
- Everybody knows this (it’s not a secret): it’s expensive to give individualized tutoring
- There was a study that came out a few weeks ago or a month ago that found: it was really working and then sometimes as it expanded out it did less well
- When it was really working, the difference was: it was one-on-one and then they started to save money
- When they were tutoring 6 to 1, it becomes a class
  - Because it’s not individualized
  - It’s just cost driven

***That’s the issue with if you have 30 kids, you can’t generate an unending stream of content at 80-85% accuracy based on what the kid learns ‒ it has to be one-on-one***

> “*A personalized lesson plan is what every kid needs.*”‒ Joe Liemandt

- Joe believes that if you get all the scientists together, they will agree that AI is the light microscope

**Can we create a program that’s available to everybody?**

- Yes we can
- The software is not insurmountable

Joe was talking to, Stanford has their [Stanford Accelerator for Learning](https://acceleratelearning.stanford.edu/), and [Dean Schwartz](https://profiles.stanford.edu/daniel-schwartz) runs it

- Joe suggested, “*We could probably create an XPRIZE for an open source, available to everybody. You also need better credible people than me. You don’t need me saying this.*”
- You need Dean Schwartz and Stanford and the Ivy League, the people that everybody looks up to in education in America and saying: we know this learning science
  - We can take Stanford CS and AI department with the learning science and put that together and create this project for not that much money, that we can then get to every kid, get it into every public school

***They have the relationships with all the teachers where they don’t need the randomized controlled trial or the skepticism you’d obviously get from talking to me***

- So this is all very doable
- That is this mission

## Why the biggest challenge to scaling Alpha’s AI-driven education is cultural adoption and systemic redesign [A: 1:34:00, V: 1:48:59]

**What is the biggest risk right now?**

*Is it the equivalent of what we call market risk where it’s just adoption, it’s just the leap of faith, that we can somehow abandon the only model any of us know?*

*Or is there still technology risk embedded within the AI?*

- There is still some technology risk, but you can ratchet down and you don’t have to be the10x learner
  - We get them 3-5x today with more static versus some of the cool dynamic stuff
- The question is: Are you willing to change the motivational model for the kids?
  - Are you willing to tell the kid, “*Use this app and I’ll give you your time back.*”
  - Are you willing to say, “*You don’t have to sit in class for 6 hours a day?*”
- It’s the rebuild. That’s the problem.

Joe makes the point, “*If you take our software (our magic AI tutor, whatever it is), and you put it in a standard classroom, and the kid has to sit there for 6 hours a day, I can promise you it won’t work.*”

**⇒** That’s the issue, back to what Brian told Joe a decade ago: Are you really willing to say kids must love school?

- And then go rebuild your school system around that?
- Because if they do, they’re going to engage in the app
- You’re going to give them their time back to do stuff they love
- Is that all? Are you going to make those changes?
- Because it isn’t an EdTech solution
  - It’s not go build this EdTech, drop it and it’s going to work
  - We have that. Those apps do generally work

***To get the real revolution, you need to say, “Are we going to rebuild what we think K-12, the first 12 years of the kid’s lives are?” And if that’s true, then the sky is the limit.***

- What Joe is trying to do is say, “*Look at these examples*.”

**As a principal, Joe has learned that parents need 2 things to want to change the school**

- Remember, he was skeptical for 2 years (he’s the average parent)

1 – They need a reference from an adult they trust

- How’s it working for your kid?
- Did it work for your kid?

2 – They need to see the kid do something at the school that their kid can’t do

- And if you have that, that’s actually the magic that unlocks a parent saying, “*Okay, I’m going to go move to this new model*.”
- What it is: oh, he loves school
  - He is waking me up so he’s not late and he used to cry on the way to school
  - Or some parents are like, “*I love the academic performance.*”
  - Or those life skills I really care about
  - Or he connects with his teacher so much more as guide

**Back to choices, that’s why we’re opening all these different schools**

- A gifted and talented school
- A sports academy school
- A wilderness school (fishing and archery)
- Farming
- We’re going to be opening arts, theater, music
- Parents want different things and kids want different things

***It’s showing these things that is going to be the connection that causes parents to say, “I want this.”***

- [MacKenzie](https://2hourlearning.com/founder/) has the GT moms (gifted & talented) with Sports Academy moms, and they just look at each other like the other parent is off the rocker
  - The Sports Academy mom’s like, “*My kid was just, comes home just sweating, running around all day and I literally throw them in the shower with their clothes on*.”
  - And the GT moms are like, “*Okay. They were having a chess tournament in the afternoon and then we came home and continued it*.”

***It depends on the motivation ‒ each kid is different and all your kids are different (everybody knows that)***

**Joe sat down with the guides and asked, “*****Okay, how do we make these all better?*****”**

- On staff days, we have all the guides from all the different schools and Joe asks them, “*Okay, what’s going to make kids really love school? How do we get it from 50 to 60 to 70% of them love school?*”
- The gifted & talented guides say: they want a 3rd power hour of academics and Math Olympia
- All the other guides are groaning because their students do not want more academics
  - They want sports
  - Or a better workshop

**The key on all of this is how do we focus school on making it awesome for kids?**

- Have a great culture where it is high standards, high support
- Where you have this magic unlock of they can learn 10x faster, which then enables you to give them the time back to do all these other things
- But that’s a big lift
- That’s why it’s going to take 20 years

**For every parent, the most important thing is raising your kids**

- It’s the same at the societal level
  - The most important thing a society does is raise this next generation, and everybody cares about it
- We spend enough money in this country or globally, there’s enough money to actually rearrange this, and build an education system that’s great for the kids
- 5% of [GNP](https://en.wikipedia.org/wiki/Gross_national_income#Gross_national_product), $7 trillion

***There is recognition at both the societal or parent level that this is where we should spend money and we do***

## Peter’s daughter’s experience at Alpha School [A: 1:38:30, V: 1:54:30]

- Peter finds it amazing to think back to the spring of 1989 when Joe drops out of college to go start a software company
- Obviously there’s no way Joe could have imagined the success he would have in that company creating a multi-billion dollar company and along with it, a fortune for himself
- But then somehow deciding right at your peak that you were going to completely walk away from that, take that fortune and pour it into another endeavor that seems as far from anything as possible, relative to what you started with

Peter feels really fortunate that Joe started this in Austin

- For the listener, Peter probably should have said this at the outset that his daughter spent 2 years at Alpha
  - It was an absolutely exceptional experience for her
  - She really experienced all the things Joe talked about
- She showed up in 7th grade with the absolute negative story of, “*I love reading, I love arts. I love these things. I’m a musician. I just don’t do math and science. I know you did, Dad, that’s not me. I can’t do math. I never want to do math.*”
- Peter made the awful mistake of spending the past year trying to help her do math
  - That was a disaster that only resulted in tears
- What really appealed to Peter when he made the switch, was it just seemed so entirely logical that the reason she was struggling was because there were things in 3rd and 4th grade she never mastered
- And Peter really appreciated the compounding nature of that gap
  - It just made sense. It really clicked
- And so it wasn’t a big leap of faith
- Peter feels very fortunate that, just as Joe predicted, by the end of 8th grade she was acing math
  - And she has continued all through high school
- She did go back to public school
- That’s probably something you do encounter: there are kids that ultimately just want to be back in the big public high school
  - They want to play sports in the public high school
  - She’s at a high school with a billion kids, and she’s very happy there
- But Peter doesn’t think there’s a snowball chance in hell she would be doing as well as she is if not for the fact that she had that 2 year sabbatical to Alpha
  - Where she really got to academically create a solid foundation

**One last anecdote**

- At her 8th grade graduation, she was in tears saying goodbye to her guides
- To Joe’s point, think of what the impact of those guides were on her life
- She loved those people
- It’s not that she doesn’t like her teachers in high school, but she doesn’t have that kind of relationship with them

**Joe actually came to Alpha right then**

- Andy M, who runs her academics said she wants to give Peter’s daughter a call-out because she spent hours with him going through lessons helping figure out: Why is this not working or what is it?
- And one of the things when you’re starting these new schools, you need this concept of a founding family
- Joe adds, “*Your family was one of the most important and your support*.”
- Andy wanted to say thank you to her, because she did go above and beyond where our lessons and all this learning science and this closed loop

***Andy’s like, “I’m way better because of the feedback and the time she spent with us.”***

- It is transformative to kids
- To Peter’s point of high school, if you want to be the quarterback on the Westlake team and run track, we don’t have those in our high school
- And so we can get you prepared

**We say our middle school prepares kids for any high school**

- All our kids in middle school can get their pick of high school that they want to go
- Some want Alpha High,
- But some want the traditional play

***Hopefully we have equipped them where they know they’re a self-driven learning and can do it on their own***

## Alpha School’s expansion plans and need for people and resources for maximum impact [A: 1:42:30, V: 1:58:58]

**Peter shares one last story**

- It really doesn’t matter what corner of this planet you’re standing on, when education comes up, Joe Liemandt’s name always comes up
  - And these are people who don’t know that Peter and Joe are friends
- Peter will be literally on the opposite side of this planet and if he’s talking with anybody about education, it’s like, “*What do you know about AI and education? Have you heard of this guy Joe Liemandt at Alpha?*”
- And it comes up so often, which tells me that it is getting out there
- This is no longer just that little niche school, downtown Austin

**It’s hard to believe what has happened in 5 years**

*It went from one building, one place, to how many now?*

- We opened 12 campuses
- There will be 25 Alpha campuses
- We also have 25 non-Alpha campuses
  - We have campuses open where it’s charter, so it’s free for kids
  - We have ones where it’s $5,000 pay for the parents ($500 a month,) some at $20,000
- Back to innovating, we’re trying to figure out the right price points and everything

***We expect 12 months from now there be hundreds and hundreds of schools that use this model***

- The demand for the [Sports Academy](https://texassportsacademy.com/) is through the roof

**The big picture of why this is important**

- Peter appreciates Joe taking the time to come out today, and more than anything he appreciates what Joe is doing
- This is not something that necessarily fits into what we talk about on this podcast, but Joe is working on such an important problem

> “*I don’t think you can care about medicine, science, health, and not care about the foundation upon which it’s built and it all starts with education.*”‒ Peter Attia

**We need more talent in education**

- Joe obviously had a great career before this
- 3 years ago he moved to education
- If there’s other people out there, if you’re listening to this and you’re excited, part of his job is to go get more talent into education

Joe shares, “*I can tell you the last 3 years have been awesome, and my next 20 years is going to be better than my last 20 years. If I can convince you to come on in the water…*”

**What’s the best way for people to get a hold of you?**

- Joe’s email: [joe.liemandt@alpha.school](mailto:joe.liemandt@alpha.school)
- Joe is overloaded; the hype has gotten very high about Alpha

*What could someone who wants to get your attention put in the subject line?*

- Something like: I heard you on *The Drive* podcast

Joe is looking for all sorts of people

- Product people, engineers
- We have to go build AIs
- GT school (gifted & talented) needs 500 schools
- We need entrepreneurs who are going to go expand it like it’s a Chipotle chain
- We need AI guys going out to Silicon Valley where current chatbots aren’t good
  - We have to make the LLMs better
- We need educators, people who want to do this new thing
- If you’re one of the learning scientists that we don’t have on our team, come do it
- We’re going to need a lot of capital as well, to expand this
- Philanthropy: we need to be giving scholarships
- We’re funding a lot of it, but we need to make this available to everybody

**⇒** It can’t just be for the elite. It’s got to be for a billion kids. ***Education touches everything, and if you like the description of what Joe’s building, then come aboard because it’s awesome***

---

## Selected Links / Related Material

**Trilogy software company**: [Trilogy: Where AI Meets the World’s Best Remote Talent](https://trilogy.com/) | [1:15, 6:45, 1:09:45]

**Alpha School**: [ALPHA: A school where kids crush academics in 2 hours, build life skills through workshops, and thrive beyond the classroom](https://alpha.school/) | [1:15, 9:00]

**Book,** ***Second Mountain***: [The Second Mountain: The Quest for a Moral Life](https://www.amazon.com/Second-Mountain-David-Brooks/dp/0812993268/ref=tmm_hrd_swatch_0) by David Brooks (2019) | [8:15]

**Everybody learns faster with a personalized tutor**: [The 2 Sigma Problem: The Search for Methods of Group Instruction as Effective as One-to-One Tutoring](https://web.mit.edu/5.95/www/readings/bloom-two-sigma.pdf) | *Educational Researcher* (B Bloom 1984) | [25:30]

**TimeBack**: [timeback: learning just got schooled](https://timeback.com/) | [29:00, 1:00:15]

**Sports academy**: [Texas Sports Academy](https://texassportsacademy.com/) | [32:45]

**AI song generator**: [Suno | AI Music](https://suno.com/home) | [1:07:00]

**Dean Schwartz’s book about learning**: [The ABCs of How We Learn: 26 Scientifically Proven Approaches, How They Work, and When to Use Them](https://www.amazon.com/ABCs-How-Learn-Scientifically-Approaches/dp/0393709264/ref=sr_1_1?crid=UQF4S1QTX0YR&dib=eyJ2IjoiMSJ9.hXe2iuyYIRSfpASu3DOtDCcnc1g2YuJAuxwMyY0s1A6iZp-gtajgQKQJBln22gJKH5jm_xeor8DX4d0pjgzh6hoNVOtMXuYsg_QgRuxlq6lrBWJYO8Q5yvp-T63Wwjy_qBoXteXT5SIkxOA0zw3MU1cj0cGKVoYUCrarROE6d_bhEmzPoJlzX5I0UBkKqPmzxsVsYE8wD-Tl6r9WEPfns6rXEUaHj6aa2brO--r56JA.6eDw5YVG7TUiOdCFqtq_mdVIOSQlbTba0SOpjoMRohY&dib_tag=se&keywords=the+abcs+of+how+we+learn&qid=1757338106&sprefix=the+abcs+of+how+%2Caps%2C108&sr=8-1) by D Schwartz, J Tsang, K Blair (2016) | [1:07:30]

**Book of 1% better**: [Atomic Habits: An Easy & Proven Way to Build Good Habits & Break Bad Ones](https://www.amazon.com/Atomic-Habits-Proven-Build-Break/dp/0735211299/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.f40BjO3UpSUHUPMm8WsQZJ32IF5PTOiAQHSO7rt21EoAJtppaX-BPfEEjF2D5XtO2m_xDClmIZOC-fkg7qy8UyIMsh1ZJxfx1Uo_epnBwruf_7IS6vQRJQ2FSOeulVcO_vfRXa4BO5z0GimfVpkx4F8KO2iCmQr_bQiS_qdIF_QHc6vTJJO89NOqx7jgwjRJWmWbWP9-1gom54EckuM2kHmQ6OC0M44w8LHxcL89UQc.W7gEmovoX8wtKrXiwqZ8cPBLhFvMVcLQcTjbzIXLy7E&qid=1758027680&sr=8-1) by James Clear (2018) | [1:24:30]

**Book about motivation**: [10 to 25: The Science of Motivating Young People: A Groundbreaking Approach to Leading the Next Generation―And Making Your Own Life Easier](https://www.amazon.com/10-25-Motivating-Groundbreaking-Generation_And/dp/1668023881/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.1BcyNiO2SYzF1RAf8PhRDIqCIxWdcpEwe00k0YBe0F8EWRMFUbR3FjYMsRB-7NCVscKse8dvjBC8lrZ6xvGbcRrkqUm5POk0Y-kGmii2aAflfkNTUqYsrjkVqp7HUcR2w6GDRLLHPIh2AoFU06xDuG5V7R_pxpkHaF1kEO4N-3Qqa0zPJvOtAm9KHRnByV2_BOHPMkQ0S05-NqlNlMIpWcGIs9ufdsg-x76GfoCUN8U.uJqw68bqYi41xOWOObtlGBOOj813pbzeAs4FGmwbqZY&qid=1758028884&sr=8-1) by David Yeager (2024) | [1:27:15]

**NY Times article on education disparities**: [America’s New Segregation](https://www.nytimes.com/2025/08/14/opinion/trump-democrats-resistance-reform.html) | *The New York Times* (David Brooks August 14, 2025) | [1:30:00]

---

## People Mentioned

- [Edward Feigenbaum](https://en.wikipedia.org/wiki/Edward_Feigenbaum) (computer scientist, joint winner of the 1994 Turing Award, expert in AI often called the “father of expert systems”) [6:32]
- [John Lynch](https://www.linkedin.com/in/jplynch1/) (Co-founder of Trilogy Software, currently the CEO of LinkLive) [8:00]
- [MacKenzie Price](https://2hourlearning.com/founder/) (Co-Founder of 2 Hour Learning and Alpha Schools) [9:00, 53:45, 1:11:15, 1:36:45]
- [Sid Mukherjee](https://siddharthamukherjee.com/about-siddhartha/) (Assistant Professor of Medicine at Columbia University, cancer physician and researcher, author of [*The Song of the Cell*](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human/dp/1982117354/ref=sr_1_1?crid=3EXWP8Y3TKM47&dib=eyJ2IjoiMSJ9._qSQo8HL5-d-0Y9_OoOOHSrgciQVJfKZsSjwVhv2C7k.bu-edSrEuXN9FGxkOuRUDq3H84PKuP-9p8f7oogdGzo&dib_tag=se&keywords=Sid+Mukherjee+the+cell&qid=1757948326&s=books&sprefix=sid+mukherjee+the+cell%2Cstripbooks%2C100&sr=1-1) and other books) [58:30]
- [Dean Schwartz](https://profiles.stanford.edu/daniel-schwartz) (I. James Quillen Dean and the Nomellini & Olivier Professor of Educational Technology at Stanford Graduate School of Education, where he is also the Halper Family Faculty Director of the [Stanford Accelerator for Learning](https://acceleratelearning.stanford.edu/); author of [*The ABCs of How We Learn*](https://www.amazon.com/ABCs-How-Learn-Scientifically-Approaches/dp/0393709264/ref=sr_1_1?crid=UQF4S1QTX0YR&dib=eyJ2IjoiMSJ9.hXe2iuyYIRSfpASu3DOtDCcnc1g2YuJAuxwMyY0s1A6iZp-gtajgQKQJBln22gJKH5jm_xeor8DX4d0pjgzh6hoNVOtMXuYsg_QgRuxlq6lrBWJYO8Q5yvp-T63Wwjy_qBoXteXT5SIkxOA0zw3MU1cj0cGKVoYUCrarROE6d_bhEmzPoJlzX5I0UBkKqPmzxsVsYE8wD-Tl6r9WEPfns6rXEUaHj6aa2brO--r56JA.6eDw5YVG7TUiOdCFqtq_mdVIOSQlbTba0SOpjoMRohY&dib_tag=se&keywords=the+abcs+of+how+we+learn&qid=1757338106&sprefix=the+abcs+of+how+%2Caps%2C108&sr=8-1)) [1:07:30, 1:33:00]
- [David Yeager](https://liberalarts.utexas.edu/psychology/faculty/yeagerds) (Professor of Psychology at the University of Texas at Austin and the cofounder of the Texas Behavioral Science and Policy Institute; author of [*10 to 25: The Science of Motivating Young People*](https://www.amazon.com/10-25-Motivating-Groundbreaking-Generation_And/dp/1668023881/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.1BcyNiO2SYzF1RAf8PhRDIqCIxWdcpEwe00k0YBe0F8EWRMFUbR3FjYMsRB-7NCVscKse8dvjBC8lrZ6xvGbcRrkqUm5POk0Y-kGmii2aAflfkNTUqYsrjkVqp7HUcR2w6GDRLLHPIh2AoFU06xDuG5V7R_pxpkHaF1kEO4N-3Qqa0zPJvOtAm9KHRnByV2_BOHPMkQ0S05-NqlNlMIpWcGIs9ufdsg-x76GfoCUN8U.uJqw68bqYi41xOWOObtlGBOOj813pbzeAs4FGmwbqZY&qid=1758028884&sr=8-1)) [1:27:15]

---

![](https://peterattiamd.com/wp-content/uploads/2025/09/bio-joeliemandt-600x600.png)

##### Joe Liemandt

Joe Liemandt is a tech entrepreneur, best known for founding [Trilogy Software](https://trilogy.com/) and later building [ESW Capital](https://www.linkedin.com/company/eswcapital/), a firm that has acquired over 100 software companies. A Stanford dropout and one of the youngest-ever Forbes 400 billionaires, Joe has turned his sights on reinventing how people learn.

He is the principal of [Alpha School](https://alpha.school/), a private, tech-forward learning model that condenses core academics into just two hours per day using AI-driven tutoring. This frees up time for personalized, purpose-based skill development. Joe brings an operational, systems-driven mindset to learning — prioritizing efficiency, personalization, and confidence. [[Colossus](https://joincolossus.com/article/joe-liemandt-class-dismissed/?utm_source=newsletter)]

LinkedIn: [Joe Liemandt](https://www.linkedin.com/in/liemandt/)