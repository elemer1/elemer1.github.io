# #313 – AMA #62: Protein’s impact on appetite and weight management, and uric acid’s link to disease and how to manage levels

**Source:** [https://peterattiamd.com/ama62/](https://peterattiamd.com/ama62/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives into two important health topics: uric acid and protein, examining them from unique perspectives. For uric acid, he explores its metabolic role and connection to various diseases, focusing on the potential causal link with cardiovascular disease. He also discusses factors influencing uric acid levels, such as diet, genetics, and lifestyle, providing practical tips for effective management. Shifting to protein, Peter delves into its role in appetite and weight management, the consequences of insufficient protein, and the “protein leverage hypothesis” linking protein deficiency to obesity. He covers optimal protein intake and its impact on energy expenditure, and he compares the satiety effects of solid versus liquid protein. Finally, Peter shares his strategy for incorporating protein into a comprehensive weight management plan.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #62 show notes page](https://peterattiamd.com/ama62). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of episode topics (and an important discussion on fanny packs) [2:00];
- Understanding uric acid: its role in metabolic processes, its association with gout and kidney stones, its impact on blood pressure, and more [6:00];
- Non-modifiable factors that influence uric acid levels [11:00];
- Modifiable factors that influence uric acid levels [14:15];
- Association between high uric acid levels and cardiovascular disease [20:00];
- Evidence suggesting a causal link between high uric acid levels and cardiovascular disease [24:00];
- Inconclusive evidence about the cardiovascular benefits of lowering uric acid pharmacologically [28:15];
- Exploring the potential risks of low uric acid levels in neurodegenerative diseases [37:00];
- Managing uric acid levels: dietary interventions and pharmacological approaches [42:00];
- The impact of protein on appetite and weight management [44:00];
- The consequences of insufficient protein on eating behaviors and satiety [52:15];
- The relationship between protein deficiency and obesity: exploring the “protein leverage hypothesis” [57:15];
- The impact of protein intake on energy expenditure [1:02:15];
- Determining optimal protein intake to avoid deficiency and support health [1:05:45];
- The role of different amino acids and protein sources in promoting satiety [1:08:15];
- Comparing the satiety effects of solid vs. liquid protein sources [1:10:30];
- Peter’s framework for incorporating protein intake into a strategy for controlling body weight [1:12:00]; and
- More.

§

The Peter Attia Drive

Protein’s impact on appetite and weight management, and uric acid's link to disease and how to manage levels

§

## Show Notes

§

## Overview of episode topics (and an important discussion on fanny packs) [2:00]

**Fanny packs**

- Peter caused some “controversy” recently with his fashion choice of [sporting a fanny pack](https://www.instagram.com/peterattiamd/p/C7Hso-Puw7x/)
- Peter notes the large number of votes against the fanny pack, comparing it to other controversial health topics that require nuanced discussion.
- Peter’s rebuttal:
  - “*I would bet that the same number of people who think that the fanny pack is a faux pas are probably equal in proportion, not necessarily the same people, but equal in proportion to the number of people who think HRT causes breast cancer or TRT causes prostate cancer*…
  - …*And so it requires deep, thorough, nuanced discussion to explain the merits of certain approaches, and I think the fanny pack is no exception*.”

**Episode topics**:

- Uric Acid Discussion: Nick mentions the renewed focus on uric acid due to new information, covering its relation to diseases and metrics for Peter and his patients.
- Protein Discussion: Nick introduces the discussion on protein and its relationship to appetite, energy expenditure, and weight control, highlighting new aspects not previously covered.

## Understanding uric acid: its role in metabolic processes, its association with gout and kidney stones, its impact on blood pressure, and more [6:00]

***What is uric acid? Why should people even care about this metric?***

- Uric acid is often seen on blood tests, though not commonly ordered.
- Familiarity mainly comes from its association with gout.

*But let’s just take a step back and talk about what it is…*

- Metabolite Breakdown
  - Uric acid is a byproduct of purine breakdown.
  - Purines are DNA and RNA building blocks; their breakdown leads to uric acid production.
- Fructose connection
  - Uric acid is also a metabolite of fructose
  - In a previous [convo with Rick Johnson](https://peterattiamd.com/rickjohnson/), they talk at length and in great detail about the biochemical pathway that leads from the metabolism of fructose to uric acid.
- Evolutionary aspect: Genetic Mutation
  - A specific mutation in humans allows higher uric acid levels compared to ancestors.
  - Possibly linked to a survival advantage during extreme cold periods in Europe.

**Uric acid and pathology**

Gout

- Most of our understanding of it of course is associated with pathology and most of that pathology centers around gout.
- So when uric acid crystallizes, it can do so in joints, and because it is quite inflammatory when it crystallizes, this inflammatory condition within the joints is what is clinically known as gout.
- Commonly affects the big toe and requires potent anti-inflammatory drugs.

Kidney stones

- High uric acid levels can lead to urate-based kidney stones.
- Less common but significant in the types of kidney stones.

High blood pressure

- Hyperuricemia is [linked](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7803439/) to increased blood pressure.
- Established through experimental evidence and Mendelian randomization.

**Mendelian Randomization (MR)**

- MR is used to study causality between biomarkers and disease phenotypes.
- Helps clarify if lowering biomarkers like LDL or uric acid reduces disease risk.
- Example of causal relationships found:
  - Lowering LDL has been causally linked to reducing atherosclerotic cardiovascular disease.
  - Similar MR studies show that uric acid levels correlate with blood pressure changes.

**Confounding factors**

- All of this is confounded by the fact that things that are bad for you tend to raise uric acid and that association is a little difficult to tease out causality.
- For example, we know that patients with [fatty liver disease](https://journals.physiology.org/doi/full/10.1152/ajprenal.00140.2005#:~:text=Unlike%20glucose%2C%20the%20oral%20ingestion,acid%20has%20been%20previously%20studied.) and patients with [type 2 diabetes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2647706/) usually have very high uric acid levels and it’s unclear exactly what the direction of causality is there.

## Non-modifiable factors that influence uric acid levels [11:00]

**Non-Modifiable Factors**

Sex Differences

- Men generally have higher uric acid levels than women (0.5 to 1 mg/dL higher on average).
- Peter’s experience suggests this difference could be as much as 1 to 2 mg/dL.
- Hypothesis: Estrogen and its downstream effects contribute to lower uric acid levels in women.
- Women are more susceptible to problems from high uric acid levels at any given level compared to men.

Genetics

- Heritability of uric acid levels is about 40%.
- Nearly half of an individual’s uric acid level is genetically determined.
- Genetic variation is crucial for studying causality using Mendelian randomization.

Age

- Uric acid levels tend to increase with age, more pronounced in women.
- Increase in women often starts around menopause.
- Estrogen likely plays a significant role in regulating uric acid levels.

This figure shows the relationship between uric acid levels in men and women:

![](https://peterattiamd.com/wp-content/uploads/2024/08/f1-ama62.png)

**Figure 1.** Source: [Zitt et al. Nat. Sci. Rep. 2020](https://www.nature.com/articles/s41598-020-64587-z)

- The blue line (men) shows consistently higher uric acid levels with a modest, steady increase over time.
- The red line (women) show lower and relatively flat uric acid levels until mid-40s.
  - Significant increase in levels post-menopause, surpassing men’s rate of increase.
  - Even at age 80, women’s uric acid levels remain lower than men’s.

## Modifiable factors that influence uric acid levels [14:15]

- Epidemiologic data tell us that average serum uric acid levels have been increasing pretty substantially over the past century.
- So in addition to all of the things that we’ve talked about, the sex differences, the age progression, if you just look at the population level of uric acid, it is going up
- Therefore, the obvious question is, *Is it going up for the same reasons that certain other things are going up such as obesity and metabolic syndrome? And if so, what is it about those things that’s increasing uric acid*?

***What do we know about factors that can cause uric acid to raise that people may have control over?***

Fructose Consumption

- Fructose drives uric acid production, at least transiently, particularly in liquid form.
- It is unclear if chronic fructose consumption plays a role directly or indirectly
- Directly would mean: Does fructose consumption, which is known to unequivocally increase uric acid levels transiently, does enough fructose consumption lead to chronic elevation of uric acid?
- Indirectly would mean: High fructose intake may drive overeating, contributing to obesity.
  - What is it about fructose consumption and intracellular energy levels that lead to more consumption of food and therefore obesity, and is that the driver through energy balance?
- There have been [bidirectional Mendelian randomization](https://www.sciencedirect.com/science/article/pii/S2405844024031050) studies that have been done, and they have suggested that higher levels of adiposity can cause hyperuricemia
- So in other words, that would explain that obesity and energy imbalance is a driver of elevated uric acid and not the other way around
  - By the way, that’s done by looking at genes that are known to increase fat mass, such as the FTO gene, MC4R gene, and other genes that are clearly associated causally with obesity.

Purine-Rich Foods

- High DNA content foods like meat, sardines, and beer increase uric acid.
- Beer is particularly high due to yeast content.

Medications

- Diuretics used for high blood pressure can raise uric acid levels.
- Low-dose aspirin can also contribute to higher uric acid levels.

Ketosis and Fasting

- Ketosis, whether nutritional or from fasting, increases uric acid levels.
- Beta-hydroxybutyrate (BHB) competes with uric acid for excretion in the kidneys.
- Personal anecdote: Peter experienced gout during ketosis, but learned to manage it with medication (allopurinol).

Anaerobic Exercise

- Heavy anaerobic exercise can transiently increase uric acid.
- Hypothesized to be due to muscle ATP depletion and IMP buildup.
- Possible adaptation over time; not necessarily pathologic.
- “*I’m also not convinced that there’s anything pathologic about that. So that’s just more of an interesting aside, not like, “’Oh, don’t do intense anaerobic activity.’*”

## Association between high uric acid levels and cardiovascular disease [20:00]

***Given the relationship between uric acid and blood pressure, and we know about blood pressure’s role in cardiovascular disease, what do we know about uric acid as it potentially relates to the risk of cardiovascular disease?***

Hyperuricemia could have several mechanisms for damaging the body in cardiovascular disease

- Increased oxidative stress affecting coronary blood flow.
- Altered platelet function.
- Impaired nitric oxide synthesis.
- Anti-proliferative effects on the endothelium.
- Primary negative effect through endothelial dysfunction.

If we take a step back and ask the question, ***what is cardiovascular disease all about?***

- Three Aspects of Disease
- 1) Lipoprotein Side
  - Focus on apo B particles, LDL, and VLDL carrying cholesterol.
    - See [AMA #43](https://peterattiamd.com/ama43/)
  - Alone, these particles are not the sole issue.
- 2) Endothelial Dysfunction: Integrity of the endothelium must be compromised for apoB particles to penetrate.
- 3) Inflammatory Response: Oxidation of cholesterol within apo B particles triggers inflammation.

Role of uric acid:

- If you consider that entire spectrum of pathophysiology, it would appear that uric acid exerts most of its negative impact in the middle of those stages, in terms of endothelial dysfunction
- Well is there an observation here? And epidemiology is helpful in that response.

If you look at the [largest systematic review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6792332/) the team found,

- Done in 2019
- It looked at over 32 studies
- It included about a million patients with about a nine-year median follow-up

![](https://peterattiamd.com/wp-content/uploads/2024/08/f2-ama62.png)

**Figure 2.** Source: [Rahimi-Sakak et al. BMC Cardiovasc Disord. 2019.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6792332/)

- X-axis: Uric acid levels (2.5 to 10.5).
- Black line: Hazard ratio for cardiovascular disease.
- Purple dotted lines: 95% confidence intervals.
- Clear association: As uric acid levels increase, so does the risk.
- It is a monotonically increasing line that goes from a hazard ratio of 1.0 at uric acid level 2 (no increased risk) to a hazard ratio of 1.5 at uric acid level 7.5 (50% increased risk)
- by the time you reach 10.5, the hazard ratio is 2.5.

*Causality Questions*

- Does not prove causality but shows a strong association.
- Two ways to test causality:
  - Experimental approach: Lower uric acid and observe.
  - Mendelian randomization: Using genetic data to infer causality.

## Evidence suggesting a causal link between high uric acid levels and cardiovascular disease [24:00]

***Do we know anything about whether high uric acid is causal for cardiovascular disease?***

Explanation of Mendelian Randomization (MR)

- MR is an analytical technique, not experimental.
- It studies genetic variation to determine the impact of a trait (e.g., uric acid) on an outcome (e.g., cardiovascular disease).
- In this case, uric acid has high heritability, indicating significant genetic variation.
- Genes occur randomly, allowing for a natural randomized experiment.
- MR analyzes how genetically predicted levels of uric acid correlate with disease outcomes, independent of lifestyle factors.
- So that effectively allows us to do a randomized experiment.

When MR can be useful

- When we see different levels of uric acid in response to these different genes, we can then ask the question: *Are there different levels of the thing that we’re interested in studying, which in this case is cardiovascular disease*?
- And if the answer is yes, it makes a very compelling case that the thing you’re studying is causally related to it because you are not looking at the variable, in this case, uric acid, through the lens of lifestyle manipulation or other things that could have been moving it.
- You’re only asking the question through the lens of where did those genes arrive, at the time of your birth or prior to your birth, and what are they doing over the course of your life?

**MR Studies on Uric Acid and Cardiovascular Disease**

- Before getting into these studies, Peter points out a caveat:
- Both of these studies, which are very large, were done in Caucasians.
- And so that’s important because it in a way weakens the analysis.
- You’d feel better if you had a study that had a larger genetic diversity to it.

[2020 MR study](https://www.ahajournals.org/doi/full/10.1161/HYPERTENSIONAHA.120.16547)

- Involved around 100,000 European ancestry individuals and nearly 350,000 from the UK Biobank.
- Found that every one standard deviation increase in genetically predicted serum urate increased:
  - Cardiovascular disease risk by 19%.
  - Peripheral artery disease risk by 12%.
  - Stroke risk by 11%.
- Results were statistically significant with tight confidence intervals, suggesting causality.

A [separate Mendelian randomization analysis](https://journals.lww.com/JASN/fulltext/2015/11000/Uric_Acid_and_Cardiovascular_Events__A_Mendelian.27.aspx), which was done in very high-risk patients

- Focused on patients hospitalized for coronary angiography.
- Found that each 1 mg/dL increase in genetically predicted uric acid was associated with:
  - 77% increase in cardiovascular death.
  - 141% increase in sudden cardiac death over 10 years.
- These striking numbers highlight the potential significance of uric acid levels in high-risk populations.

> “*I would say that that’s now one more inclination that we have that maybe there is some causality between uric acid and cardiovascular disease*.” —Peter Attia

## Inconclusive evidence about the cardiovascular benefits of lowering uric acid pharmacologically [28:15]

***Do we know anything about the benefit of lowering uric acid as it relates to cardiovascular disease?***

Gold Standard: Experimental Approach

- So you have the observational epidemiology, which again, only shows you an association
- You look at the MR, which is very suggestive of causality
- So now to confirm this you want to do an experiment with a single variable intervention: reducing uric acid.

**The** [**ALL-HEART Trial**](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(22)01657-9/fulltext)

*The question*: This was designed to ask the question, if you give people a medication that blocks uric acid production, allopurinol, would you improve cardiovascular outcomes in those who have CVD relative to standard of care?

*Study Design*

- Conducted with just under 6,000 participants with ischemic cardiovascular disease.
- Mean age of 72, mostly male.
- Participants randomized to open-label standard care or 600 mg of allopurinol daily.
- Mean follow-up of nearly 5 years
- “*So this is on the surface a pretty good population to be studying because outside of the potential risk that they may be too far in their disease process, you should be able to see a signal here*.”

Study Problems

- Open-label design instead of true randomization (which means we’re telling you that we’re going to do nothing, so there’s no placebo)
- Unclear why the study was not placebo-controlled.

Study Results

- No significant difference between the allopurinol group and the control group in non-fatal MI, non-fatal stroke, or cardiovascular death (11% vs. 11.3%) — not statistically significant

Peter’s reaction:

- On the surface it’s really easy to say, well, this kind of makes the case that uric acid is not playing a role in cardiovascular disease, but you have to read the fine print here.
- Here it says that this was based on an *intention to treat, not as treated*.
- So intention to treat means the analysis is done on everybody who is randomized, not everybody who finished the study.
  - And by the way, that’s okay. It’s okay to say we’re going to do intention to treat not per protocol, which is the other type of analysis you do.
- Per protocol says we’re only going to evaluate the people that did the study.
- But both of those give you different pieces of information.
- Intention to treat is real world effectiveness, whereas per protocol is slightly artificial efficacy.
- The bigger the dropout rate, the bigger the gap you might expect there—And the dropout rate in this study was a whopping 57.4% (unclear why there was such a big dropout rate)

About the dropouts and how it affected results

- “A big problem with this study is doing it as an open label study as opposed to a placebo controlled study because the truth of it is there really aren’t side effects to allopurinol. So it’s hard for me to imagine that these 57.4% of people dropped out because of a side effect associated with the allopurinol.”
- Peter suspects they just dropped out for some other reason.
- And of course there technically were no dropouts from the other arm because they were by definition just receiving usual care.
- So none of the usual care patients withdrew from the study and more than half the treatment groups withdrew from the study and therefore **it’s very difficult to infer what is actually going on here**.
- Per protocol analysis:
- Then the authors did the per protocol analysis, which would make sense.
- Per protocol analysis showed a 34% reduction in heart failure hospitalizations, but interestingly other variables did not reach statistical significance (although there was a trend towards an improvement)

Issues with study power

- The per protocol analysis was grossly underpowered
- Study was grossly underpowered due to high dropout rate.
- Initial power analysis expected a 4% dropout rate, not over 40%.
- High dropout rate severely impacted the ability to detect true effects.

Study design limitations

- The study was not limited to people with high serum uric acid at baseline
  - Peter isn’t pointing this out to be critical of the authors, it was their intention to test whether allopurinol was beneficial for everyone with heart disease regardless of uric acid level, but you could argue that a more targeted study—and maybe a better study in addition to correcting everything Peter just said—would include *subjects only who had a high uric acid*.
  - More targeted studies should focus on individuals with high uric acid levels (e.g., ≥ 6 or 6.5 mg/dL).

Conclusion

- ALL-HEART study had significant methodological flaws and high dropout rates.
- Study was unable to conclusively determine if lowering uric acid reduces ASCVD risk.
- More targeted and better-designed studies are needed to answer this question definitively.

> “*I just don’t think the ALL-HEART study, due to all of these methodologic issues, was capable of answering this question. And therefore I would say we still don’t have an answer to the question, does pharmacologically lowering uric acid reduce the risk of ASCVD*?” —Peter Attia

## Exploring the potential risks of low uric acid levels in neurodegenerative diseases [37:00]

***Is there such a thing as too low when it comes to people trying to lower their uric acid level?***

Initial Perspective: Peter’s Evolving View

- A few years ago, Peter would have said low uric acid is not a concern.
- Today, he acknowledges the possibility that very low uric acid levels might be problematic.

**Low Uric Acid and Parkinson’s Disease (PD)**

Observational Data:

- Shows uric acid levels below 4.5 to be associated with a slightly increased risk of PD.

Experimental Evidence

- [Animal studies](https://www.science.org/doi/10.1126/scitranslmed.adg8656): Rats and mice with ischemic strokes showed improvement with intravenous uric acid administration.
- Human trial: Small [study](https://www.sciencedirect.com/science/article/abs/pii/S1474442214700547#:~:text=The%20URICO%2DICTUS%20trial%20was,patients%20with%20acute%20ischaemic%20stroke.) with around 400 patients showed better outcomes for ischemic stroke patients given IV uric acid compared to placebo.
  - there’s certainly some plausibility that uric acid could be acting as an antioxidant in this capacity, and then that might be explaining some of the salvage function during these patients.

Mendelian Randomization (MR) Analysis

- Given the obvious and wide genetic variability of uric acid, we should be able to see a signal with the Mendelian randomization.
- Mixed Results – they have not been able to establish causality
  - Observational data suggests a U-shaped curve for uric acid levels and PD risk.
  - MR studies did not find causality between low uric acid levels and PD.
  - MR analysis indicated that higher uric acid levels are associated with a 20% increased risk of PD.

**Broader Neurodegenerative Diseases (NDDs) Context**

[Prospective MR Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11088014/)

- Large study with about 380,000 participants from the UK Biobank.
- Observational data: Higher uric acid levels associated with lower risk of Alzheimer’s and related dementias.
- MR findings: No significant association between uric acid levels and any neurodegenerative disease.

[SURE-PD3 Trial](https://jamanetwork.com/journals/jama/fullarticle/2784144)

- Early PD patients randomized to receive inosine (to increase uric acid levels) or a placebo.
- Inosine increased uric acid to 7-8 mg/dL.
- No significant difference in the clinical progression of PD between the treatment and placebo groups.

**Taken together, let’s ask the question**: *What does the epidemiology show, what does the MR show, and what does the experimental data show?*

- When it comes to Parkinson’s disease, we have epidemiology that says lower might not be better.
- We have Mendelian randomization that says there’s no difference anywhere across the spectrum.
- And then we have experimental evidence that says, at least for treating PD, increasing uric acid quite substantially doesn’t make any difference.
- So taken together, Peter is not as sold on the uric acid PD link as he is on the probable role in cardiovascular disease.

## Managing uric acid levels: dietary interventions and pharmacological approaches [42:00]

***How does Peter think about uric acid levels for himself and for his patients and at what levels of uric acid raise concern?***

**Low Uric Acid Levels**

- Peter has never seen a patient with uric acid levels low enough to warrant intervention with inosine.
- Common in premenopausal women with levels in the 2 to 3 range.
- No intervention needed, and there is no concern about conditions like Parkinson’s disease.

**High Uric Acid Levels**

*Initial Approach*

- Address through dietary changes first.
- Aim to get uric acid levels below 6 mg/dL.

*Pharmacological Intervention*

- If dietary changes are insufficient, pharmacology is considered.
- Allopurinol
  - First-line treatment for high uric acid.
  - Patients are tested for HLA-B58 genotype (Peter misspoke and said HLA-B27, but he meant HLA-B58)–the gene that renders you susceptible to Stevens-Johnson syndrome–to avoid Stevens-Johnson syndrome.
  - If negative for HLA-B58 and uric acid is above 6, allopurinol is prescribed.
- Uloric
  - Alternative to allopurinol for HLA-B58 positive patients.
  - Equally effective but much more expensive.

**Optimal Uric Acid Level**: Target uric acid level is around 5 mg/dL.

## The impact of protein on appetite and weight management [44:00]

A few recent episodes about protein:

- [#299](https://peterattiamd.com/lucvanloon/)
- [#276](https://peterattiamd.com/peter-faq/)
- [#224](https://peterattiamd.com/donlayman/)

\*\*\*

***What do we know about how protein can impact someone’s appetite?***

Peter’s Overview

- While all calories might be equal in terms of adiposity and energy balance, they are not equal in terms of appetite regulation.
- Protein is consistently found to be more satiating than carbohydrates and fats.
- A higher protein diet has been shown in both humans and animals to reduce overall caloric intake relative to lower protein diets.
- And therefore, it’s probably beneficial to promote weight loss in overweight and obese humans and to increase the subjective metrics of satiety.

Evidence from Human and Animal Studies

- High protein diets promote weight loss and reduce caloric intake in both humans and animals.
- Studies typically involve overweight and obese subjects, cautioning against extrapolation to lean individuals.

[Meta-Analysis Data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3392894/):

- Comparison of higher protein diets (median 27% of total calories) versus lower protein diets (median 18% of total calories).
- Greater weight loss and BMI reduction seen with higher protein diets.

Example looking at just [one of these studies](https://pubmed.ncbi.nlm.nih.gov/15303109/):

- A six-month diet intervention study of overweight, obese subjects
- People were age 20 to 55, randomly assigned to an ad-lib fat reduced diet
- The diet is 30% of energy and fat, and then it’s going to be either high protein or low protein
- So the high protein group is 25% protein. The low protein group is 12% protein.
- After six months, the high protein group had a 3.5 kilo or 8 pound difference in weight loss from the lower protein group
- We’re not saying that protein is somehow going to magically “burn fat”… the idea is it’s more satiating and therefore those people ate less
- And they were estimated to eat somewhere on the order of 300 or 400 calories per day, less in response to the higher protein diet

**Mechanisms Behind Protein’s Impact on Appetite**

Neural and Hormonal Responses: Mechanistic studies point towards neural and hormonal responses to protein intake that promote satiety.

[Three-Way Crossover Study](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(06)00271-3?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1550413106002713%3Fshowall%3Dtrue)

- Crossover studies are very powerful because each person gets to act as their own control
  - They tend to be statistically much more rigorous if they can be done
  - If you can always use an individual repeatedly to test different interventions, it becomes powerful
- Fasted subjects given isocaloric meals (high protein, high fat, high carbohydrate) on separate days.
- Satiety measured through peptide YY levels and subjective hunger assessments.

![](https://peterattiamd.com/wp-content/uploads/2024/08/f3-ama62.png)

**Figure 3.** Source: [Batterham et al. Cell Metab. Sept 2006.](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(06)00271-3)

- you’re looking at a response of people who are normal weight in figures A and C
- and people who are obese in columns B and D
- there are three curves on each
- One curve is in response to the high protein diet, that’s the red curve
- One curve is in response to the high fat diet, that’s the blue curve
- And then one curve is depicting the people given the high carb diet, that’s the black curve.

Results:

–Let’s just look at the upper left

- This is what happened to your subjective assessment of hunger following these isocaloric meals of high carb, high fat, high protein
- at time zero, everybody is normalized to zero on the scale
- what happens 30, 60, 90, 120, 150, 180 minutes after you eat?
- there’s an enormous reduction in hunger for all of them, although it’s clearly greater for protein than for fat than for carb, and then hunger starts to return
- But what’s really interesting is three hours after the protein meal, hunger is still lower than the immediate aftermath of the carbohydrate and fat meal

–Now looking at the upper right: Now we ask the question, does the same thing hold in the obese subject?

- And lo and behold, the answer is yes.
- Everything is the same except the magnitude of hunger reduction is not the same
- it’s worth noting that the high protein meal at three hours still has more satiation than an isocaloric meal that is high in fat or carbohydrate a mere 30 minutes after the meal.

–Now let’s look at the more objective measure of hunger with the peptide YY (which goes up with hunger)

- what you see is effectively an inversion of what we saw with the subjective assessment of hunger
- In other words, peptide YY is going higher with a high protein meal than the other meals

## The consequences of insufficient protein on eating behaviors and satiety [52:15]

***What happens if someone is not getting enough protein?***

- Peter’s overview: Insufficient protein intake impacts muscle protein synthesis and increases the risk of cachexia, especially in aging individuals.
- The interesting question here is, *is there any evidence for a protein-specific appetite? Is there any evidence that if you’re deficient in protein, you’re going to continue to consume calories in search of more protein?*

Protein-Specific Appetite and Obesity

- The Protein Leverage Hypothesis is a theory suggesting that protein deficiency might drive individuals to consume more calories in search of adequate protein.
- Animal studies show a shift towards a preference for protein-rich foods under protein restriction, even if it increases total caloric intake.

[**Rat Study**](https://www.sciencedirect.com/science/article/pii/S0022316622163406?via%3Dihub):

- Study Setup
  - Rats were divided into two groups: one with very low protein intake (6% of total calories) and one with normal protein intake (14% of total calories) for two weeks.
  - On the last day, each group was further subdivided and given low, normal, or high protein meals.

![](https://peterattiamd.com/wp-content/uploads/2024/08/f4-ama62.png)

**Figure 4.** Source: [Catherine et al. J Nutr. Jun 2018.](https://www.sciencedirect.com/science/article/pii/S0022316622163406?via%3Dihub)

- The variable that’s being measured here was basically the activation of a certain part of the brain in the reward center—just know that the bigger the bar, the more of a reward the animal was experiencing.
- If you look at the **three bars on the left**
  - These are the animals that were fed a **normal protein diet** for two weeks then were randomized to either low protein, normal protein, or high protein
  - You can see that there was a slight increase in the degree of satisfaction and reward experienced by the animal as protein went up, but it doesn’t really look like that big a jump
- Conversely, when you take the **low protein animals**…
  - If you gave them low protein, their level of satisfaction is incredibly low—lower than anything on this figure
  - When you took the low protein animals and you just gave them normal protein, it went considerably up and much higher than any of the animals who were on a normal protein diet, including the one that went from normal to high
  - And then of course, the showstopper here is you took that low protein animal and you now gave it high protein and it’s off the chart
  - So again, this suggests that protein deprivation leads to a type of behavior that seeks more protein.

Hormone changes

- And in another group of rats with that same protocol, the low protein animals were found to have significantly elevated levels of the hormone ghrelin which is a pro-feeding hormone relative to the normal protein group, as well as elevated levels of NPY and CRH in the fed state
- Doing this experiment and then asking other questions about hormones that regulate hunger, you see a convergence of what we’re seeing experimentally in terms of reward as well

**Peter’s takeaway**:

- Taken together these results along with many of the other animal results, suggest that there’s a desire for the organism to optimize protein
- And if protein is restricted, there’s a higher drive towards it
- These experiments have not been extensively conducted in humans, making the data less clear, especially outside the context of obesity.

## The relationship between protein deficiency and obesity: exploring the “protein leverage hypothesis” [57:15]

***What do we know about the relationship between protein deficiency and obesity? Do we know anything about if protein deficiency can contribute in any way to obesity?***

Protein Leverage Hypothesis:

- Consistent observations suggest that protein deficiency increases total energy intake, leading to the hypothesis that protein deficiency could contribute to obesity. This is known as the protein leverage hypothesis.
- However, there is no clear evidence that protein deficiency is a primary driver of obesity.

Animal data

- Most animal data do indicate that although a protein-restricted diet can increase caloric intake, they don’t necessarily result in increased weight gain or fat mass as energy expenditure also appears to increase.
- So the results might not translate well to humans in a free living setting as the variety and palatability of human foods increases the likelihood of consuming more calories even beyond the amount necessary to obtain adequate protein.
- So again, animal studies have fairly consistently shown an increased calorie intake on protein restricted diets, excluding very, very severe restriction, like less than 3% of total calories from protein.
- But most have not shown an increased weight gain, and many have shown that animals on a low protein diet gain significantly less weight and fat mass. Again, this is counter intuitive, but we’ll use a figure here in a moment to make this point a little clearer.
- For example, in the study that we just talked about with the normal protein, low protein rats… there was no difference in weight gain between the protein restricted and the normal diets, despite the other findings

An even more comprehensive [study](https://pubmed.ncbi.nlm.nih.gov/31365786/) on this pattern:

![](https://peterattiamd.com/wp-content/uploads/2024/08/f5-ama62.png)

**Figure 5.** Source: [Zapata et al. Mol Nutr Food Res. Nov 2019.](https://pubmed.ncbi.nlm.nih.gov/31365786/)

- Setup
  - Think of it as four discrete groups going from normal protein all the way out
  - The protein is going from 15 to 10 to 5 to 1
  - The carb stays constant at 52%
  - And the fat is what is filling in the caloric deficit. So it’s going from 33, 38, 43, and 47
  - So there are now several variables of interest, which are 1) caloric intake, 2) energy expenditure, 3) body weight, fat mass, and lean mass
- Observations
  - As protein intake goes down, calorie intake starts ramping up, but then it actually plummets precipitously once you get into that 1% range.
  - What’s interesting is that energy expenditure is going up as well.
  - This is hypothesized to suggest that the animals are now looking for food more.
  - So as protein restriction is upon them, they are now searching for food more, and that is resulting in an increased energy expenditure.
  - And the net effect of this is actually a reduction in body weight that is coming both in terms of fat mass and lean mass.
  - So over the course of this 21-day study, you’re seeing that as protein is going down, there’s more adrenergic signaling, i.e., adrenal signaling, stress hormone signaling, that is also playing a role in energy expenditure and weight.
- Thoughts:
  - Peter says that this is very difficult to extrapolate this to a human study because none of these levels of protein are even within the ballpark of what we would even tolerate for a human to consume.
  - The purpose of this is to mechanistically understand the relationship between protein, caloric intake, and energy expenditure.

> “And basically, if you remember nothing else about this, remember that the body responds in pretty significant ways to alterations in protein availability.” —Peter Attia

## The impact of protein intake on energy expenditure [1:02:15]

***What do we know about whether lower protein diets always increase energy expenditure?***

- Energy expenditure increases specifically in a state of protein insufficiency, but without negative energy balance.
- The body is receiving enough calories but not enough protein to meet the basic metabolic requirements for maintaining muscle mass, connective tissue, hair, etc.
- Once you hit a threshold at which the body is getting enough protein to meet everyday demands, then energy expenditure will actually increase with increasing protein intake due to the fact that protein is more thermogenic than other macronutrients.

Thermogenesis:

- Definition:
  - Thermogenesis refers to the energy expenditure required to metabolize macronutrients.
  - Different macronutrients require different amounts of energy for digestion.
- Thermogenic costs:
  - when it comes to metabolizing macronutrients, you don’t get anything for free…You have to actually spend some energy to extract the energy from the food we eat, and that differs by macronutrients
  - Fat: Most energy-dense macronutrient with the lowest cost of energy acquisition (~3%).
  - Carbohydrate: Requires more energy to digest (~5-10%).
  - Protein: Stands alone in requiring the highest energy expenditure for metabolism (20-30%).
    - So if you consume 100 calories of protein from an energy perspective, you’re going to spend 25 calories just to extract the metabolic benefits of it.
    - These are not huge differences in energy expenditure, but you could measure this using an indirect calorimeter.

[Human clinical trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7851826/)

- This is a trial that looked at normal weight, metabolically healthy individuals
- you had them either on a high protein diet, 40%, or on an isocaloric, same number of calories, 15% diet
- they were kept in metabolic chambers for 32 hours
- These chambers can measure with pretty significant accuracy what the difference is in energy expenditure
- And you can see that there was about an 80 calorie per day difference.

![](https://peterattiamd.com/wp-content/uploads/2024/08/f6-ama62-1024x351.png)

**Figure 6.** Source: [Oliveira et al. Am J Clin Nutr. Feb 2021.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7851826/)

Considerations:

- Sample Size and Study Limitations:
  - The mentioned study had 43 subjects, and a larger sample size could provide more definitive results.
  - If conducted with 400 subjects, the effect might be confirmed, and the error bars would likely be smaller.
- Implications:
  - Above the threshold of malnutrition or protein insufficiency, a higher protein diet appears to be more satiating and potentially increases energy expenditure.

## Determining optimal protein intake to avoid deficiency and support health [1:05:45]

***Do we know anything about where that threshold is? Or in other words, how much protein would someone need in order to make sure that they’re avoiding that deficiency you just covered?***

Challenges with Current Literature:

- Most literature discusses protein as a percentage of total calories.
- Peter prefers to focus on the actual mass of protein intake.

The “textbook” answer:

- Eucaloric Conditions:
  - Under energy balance conditions (eucaloric), 15% of total calories from protein is considered sufficient to avoid deficiency.
  - This translates to 0.8 to 1.2 grams of protein per kilogram of body weight, ranging from the RDA to the higher end.

Practical Considerations:

- Active Individuals and Aging Population:
  - For active individuals and aging populations with anabolic resistance, 0.8 to 1.2 grams per kilogram may not be sufficient.
  - Goals of maintaining muscle mass as we age require higher protein intake.

Recommended Protein Intake:

- Peter suggests targeting 1.6 grams of protein per kilogram of body weight.
- This intake is well above the threshold of malnutrition and ensures adequate amino acids for muscle protein synthesis.

***Is there a role for a very high protein diet in weight loss?***

- High protein diets, making up 25% of total calories, could mean consuming 200-300 grams of protein.
- Caution is advised not to exceed 3 grams of protein per kilogram of body weight, especially if there are kidney function concerns.

- Protein maximization might not be the top strategy for weight loss but can be one of the tools.
- Restricting protein intake is not recommended for weight loss efforts.

## The role of different amino acids and protein sources in promoting satiety [1:08:15]

***Do we know which amino acids are important for satiety and if specific protein sources are better or worse at promoting it?***

- It definitely seems that not all amino acids are equal in their ability to signal protein deficiency or induce satiety
- We also know that not all proteins are equal when it comes to stimulating muscle protein synthesis.
- Certain amino acids like methionine and leucine are known for their anabolic importance.
- Arginine, lysine, and glutamic acid stand out in promoting satiety in rats
- Leucine can also reduce food intake in rats due to its potency

Peter suggests focusing on whole sources of protein:

- Cherry-picking amino acids isn’t recommended; focus should be on whole protein sources.
- Branched-chain amino acids (BCAAs) like leucine, isoleucine, and valine do not significantly influence food intake, whether supplemented or deprived.

Animal vs. Plant Protein:

- There’s no evidence that animal protein is more effective than plant protein in promoting satiety.
- While anabolic effects differ between animal and plant proteins, satiety effects do not.

**Main point from Peter**: The nuance in amino acids and protein sources is less critical than ensuring adequate total protein intake for satiety.

## Comparing the satiety effects of solid vs. liquid protein sources [1:10:30]

***What do we know about the impact of liquid versus solid protein on controlling appetite?***

Solid Protein Is More Satiating

- Solid protein is generally more satiating than liquid protein.
- This is likely because solid foods take longer to digest and stay in the GI tract for a longer period.

[Randomized Crossover Study](https://onlinelibrary.wiley.com/doi/full/10.1038/oby.2010.258)

- A small study of 10 lean adult males compared solid and liquid high-protein meals.
- The meals were equal in calories and protein content; the only difference was the form.
- Results showed greater hunger suppression with solid meals compared to liquid ones.
- Limitations
  - The study was small, and while the effect was noted, it wasn’t significant later on.
  - Larger studies are needed to confirm these findings.

Anecdotal observations:

- Anecdotally, many, including Peter, find solid protein more satiating than liquid protein.
- This suggests a reasonable assumption that solid protein sources are more effective for appetite control.

**Takeaway point**: Even in the absence of definitive data, it’s reasonable to assume that solid whole sources of protein have a greater satiating effect than liquid forms, even if both are complete in protein content.

## Peter’s framework for incorporating protein intake into a strategy for controlling body weight [1:12:00]

**Peter’s framework for thinking about protein, especially for someone interested in controlling their body weight**

Key questions Peter starts with:

- Nutritional Status: Are you over-nourished, undernourished, or adequately nourished?
- Muscle Mass: Are you adequately muscled or under-muscled?
- Metabolic Health: Are you metabolically healthy or not?

After Peter goes through all the possible permutations and combinations of the above, that’s what’s leading him to decide whether you should you be restricting energy intake or not.

- Obviously that comes down first and foremost to metabolic health and energy balance or over-nourished, undernourished.
- But what we’re always trying to do is pay attention to what we’re doing with protein intake and protein consumption during that period of caloric restriction.

A common clinical scenario

- A common scenario is patients who are over-nourished, under-muscled, and metabolically unhealthy.
- Strategy in this case:
  - These patients need to reduce total energy intake while increasing protein intake.
  - Often, such individuals consume 500 calories more than necessary and only 0.6 to 0.8 grams of protein per kilogram of body weight.
- The challenge:
  - In some ways, this is the most challenging clinical case because that person has to reduce total energy intake while increasing protein intake.
  - And it’s not uncommon for Peter to see a person like that who’s probably eating 500 calories a day **more** than they need, but they’re probably only getting 0.6 to 0.8 grams per kilo of body weight of protein.
  - And so this person phenotypically is overweight, but under-muscled and metabolically unhealthy.
  - “*It’s important to just acknowledge that and say it CAN be fixed, but it requires being really deliberate*.”
- Deliberate approach
  - In order to do this, you have to be able to increase protein while reducing calories which requires really changing a lot of the foods being eaten
  - Adding training volume is essential to stimulate muscle growth, which has metabolic and appetite regulation benefits.
  - Aim for 1.6 to 2 grams of protein per kilogram of body weight per day.
  - Break this into 30 to 60 gram meals or snacks.
  - Go for solid protein sources but include at least one liquid protein source daily.

§

## Selected Links / Related Material

**Episode of The Drive with Rick Johnson where they talk about the biochemical pathway that leads from the metabolism of fructose to uric acid**: [#87 – Rick Johnson, M.D.: Metabolic Effects of Fructose](https://peterattiamd.com/rickjohnson/) | Peter Attia (peterattiamd.com) [7:00]

**Peter’s book in which he writes about a particular mutation in a gene for an enzyme that is quite unique to our species and some very adjacent species that actually allows us to have higher levels of uric acid than many of our related species’ ancestors**: [OUTLIVE](https://peterattiamd.com/outlive/) by Peter Attia (peterattiamd.com) [7:30]

**Data that show hyperuricemia, high levels of uric acid, contribute to high blood pressure**: [Urate, Blood Pressure, and Cardiovascular Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7803439/) (Gill et al., 2021) [9:00]

**Episode of The Drive with Rick Johnson where they discuss an alternative explanation where high levels of fructose consumption are driving more eating**: [#194 – How fructose drives metabolic disease | Rick Johnson, M.D.](https://peterattiamd.com/rickjohnson2/) | Peter Attia (peterattiamd.com) [15:45]

**Bidirectional Mendelian randomization studies that have suggested that higher levels of adiposity can cause hyperuricemia**: [Associations between obesity and hyperuricemia combing mendelian randomization with network pharmacology](https://www.sciencedirect.com/science/article/pii/S2405844024031050) (Panlu et al., 2024) [16:15]

**AMA episode of The Drive discussion apoB**: [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/) | Peter Attia (peterattiamd.com) [21:00]

**Large systematic review showing a clear association: As uric acid levels increase, so does the risk of CVD**: [Serum uric acid and risk of cardiovascular mortality: a systematic review and dose-response meta-analysis of cohort studies of over a million participants](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6792332/) (Rahimi-Sakak et al., 2019) [22:00]

**A 2020 Mendelian randomization found that every one standard deviation increase in genetically predicted serum urate increased CVD risk by 19% – suggesting causality**: [Urate, Blood Pressure, and Cardiovascular Disease: Evidence From Mendelian Randomization and Meta-Analysis of Clinical Trials](https://www.ahajournals.org/doi/full/10.1161/HYPERTENSIONAHA.120.16547) (Gill et al., 2020) [26:30]

**A separate Mendelian randomization analysis done in very high-risk patients suggesting a causal link between uric acid and CVD risk and death**: [Uric Acid and Cardiovascular Events A Mendelian Randomization Study](https://journals.lww.com/JASN/fulltext/2015/11000/Uric_Acid_and_Cardiovascular_Events__A_Mendelian.27.aspx) (Kleber et al., 2015) [27:30]

**The ALL-HEART trial**: [Allopurinol versus usual care in UK patients with ischaemic heart disease (ALL-HEART): a multicentre, prospective, randomised, open-label, blinded-endpoint trial](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(22)01657-9/fulltext) (Mackenzie et al., 2022) [29:00]

**Resources from Peter discussing power as it relates to studies**: [33:30]

- [Studying Studies: Part V – power and significance](https://peterattiamd.com/studying-studies-part-v-power-and-significance/) | Peter Attia (peterattiamd.com)
- [#188 – AMA #30: How to Read and Understand Scientific Studies](https://peterattiamd.com/ama30/) | Peter Attia (peterattiamd.com)

**Animal studies showing the IV uric acid improves outcomes for mice that have had ischemic strokes**: [A multi-laboratory preclinical trial in rodents to assess treatment candidates for acute ischemic stroke](https://www.science.org/doi/10.1126/scitranslmed.adg8656) (Lyden et al., 2023) [37:45]

**Human trial comparing IV uric acid or placebo and injected it into patients following ischemic strokes**: [Safety and efficacy of uric acid in patients with acute stroke (URICO-ICTUS): a randomised, double-blind phase 2b/3 trial](https://www.sciencedirect.com/science/article/abs/pii/S1474442214700547#:~:text=The%20URICO%2DICTUS%20trial%20was,patients%20with%20acute%20ischaemic%20stroke.) (Chamorro et al., 2014) [38:00]

**A prospective MR study that looked at the risk of Alzheimer’s disease and related dementias, PD, and other neurodegenerative disease in the context of various uric acid levels**: [Serum urate levels and neurodegenerative outcomes: a prospective cohort study and mendelian randomization analysis of the UK Biobank](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11088014/) (Zhang et al., 2024) [40:00]

**The SURE-PD3 trial that took patients with early PD and randomized them to receive a molecule called inosine, which is used to increase uric acid**: [Effect of Urate-Elevating Inosine on Early Parkinson Disease Progression The SURE-PD3 Randomized Clinical Trial](https://jamanetwork.com/journals/jama/fullarticle/2784144) (The Parkinson Study Group SURE-PD3 Investigators, 2021) [40:45]

**More recent episodes of The Drive discussing dietary protein**: [44:00]

- [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/)
- [#276 ‒ Special episode: Peter answers questions on longevity, supplements, protein, fasting, apoB, statins, and more](https://peterattiamd.com/peter-faq/)
- [#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.](https://peterattiamd.com/donlayman/)

**One of the large meta-analyses of a series of RCTs that compared higher protein diets versus lower protein diets**: [Effects of higher- versus lower-protein diets on health outcomes: a systematic review and meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3392894/) (Santesso et al., 2012) [46:00]

**Study showing ​​greater weight loss and BMI reduction seen with higher protein diets**: [Effect of normal-fat diets, either medium or high in protein, on body weight in overweight subjects: a randomised 1-year trial](https://pubmed.ncbi.nlm.nih.gov/15303109/) (Due et al., 2004) [47:15]

**A three-way crossover study showing the increase in satiation with higher protein meals**: [Critical role for peptide YY in protein-mediated satiation and body-weight regulation](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(06)00271-3?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1550413106002713%3Fshowall%3Dtrue) (Batterham et al., 2006) [48:45]

**Study finding that a protein-restricted group of rats develop a preference for protein rich solution over an isocaloric glucose solution, whereas non-restricted rats don’t**: [Restriction of dietary protein leads to conditioned protein preference and elevated palatability of protein-containing food in rats](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5766754/) (Murphy et al., 2018) [53:45]

**Rat study showing the desire to optimize protein when deprived of protein**: [The Protein Status of Rats Affects the Rewarding Value of Meals Due to their Protein Content](https://www.sciencedirect.com/science/article/pii/S0022316622163406?via%3Dihub) (Chaumontet et al., 2018) [54:00]

**Study looking at energy expenditure in rats on protein diets that were going from basically normal down to increasing levels of restriction**: [Low-Protein Diets with Fixed Carbohydrate Content Promote Hyperphagia and Sympathetically Mediated Increase in Energy Expenditure](https://pubmed.ncbi.nlm.nih.gov/31365786/) (Zapata et al., 2019) [1:00:00]

**Study with normal weight, metabolically healthy individuals where a higher protein diet appears to be more satiating and potentially increases energy expenditure**: [A high-protein total diet replacement increases energy expenditure and leads to negative fat balance in healthy, normal-weight adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7851826/) [1:04:30]

**Episodes of The Drive with David Sabatini where they discussed various amino acids and their relative importance**: [1:09:00]

- [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) | Peter Attia (peterattiamd.com)
- [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) | Peter Attia (peterattiamd.com)

**Episode of The Drive with Layne Norton where they discussed how not all proteins are equal when it comes to stimulating muscle protein synthesis**: [#205 – Energy balance, nutrition, & building muscle | Layne Norton, Ph.D. (Pt.2)](https://peterattiamd.com/laynenorton2/) | Peter Attia (peterattiamd.com) [1:09:00]

**Small crossover study that compared high protein meals that were solid versus liquid**: [A Solid High-Protein Meal Evokes Stronger Hunger Suppression Than a Liquefied High-Protein Meal](https://onlinelibrary.wiley.com/doi/full/10.1038/oby.2010.258) (Martens et al., 2012) [1:11:00]

**Peter’s favorite brand of rucking gear**: [GORUCK](https://www.goruck.com/) | (goruck.com) [1:15:45]

§

## People Mentioned

- [Rick Johnson](https://peterattiamd.com/rickjohnson/) [7:00]
- [David Sabatini](https://www.davidsabatinilab.com/) [1:09:00]
- [Layne Norton](https://x.com/biolayne) [1:09:00]
- [Jason McCarthy](https://peterattiamd.com/jasonmccarthy/) [1:15:45]

§