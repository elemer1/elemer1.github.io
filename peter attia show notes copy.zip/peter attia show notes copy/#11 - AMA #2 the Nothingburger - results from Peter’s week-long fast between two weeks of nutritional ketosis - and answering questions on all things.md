# #11 – AMA #2: the Nothingburger — results from Peter’s week-long fast between two weeks of nutritional ketosis — and answering questions on all things fasting

**Source:** [https://peterattiamd.com/ama02/](https://peterattiamd.com/ama02/)

---

Consider this episode a cross between an ask me anything (AMA) and a show-and-tell. Peter discusses his fasting experiment in great detail and answers questions from listeners and readers.

![The Peter Attia Drive](images/ama02/the_Drive_public.png)

Play

#11 - AMA #2: the Nothingburger — results from Peter's week-long fast between two weeks of nutritional ketosis — and answering questions on all things fasting

#11 - AMA #2: the Nothingburger — results from Peter's week-long fast between two weeks of nutritional ketosis — and answering questions on all things fasting

1x15s30s

0:001:50:33

## We discuss:

- Why Peter did a one-week fast and the rationale for front- and back-ending it with a week-long [ketogenic diet](/ketosis-advantaged-or-misunderstood-state-part-i/) [6:30];
- What Peter’s typical diet, exercise, sleep, stress management, and supplementation looks like [11:00];
- What labs (e.g., glucose, ketones, lipids, inflammation and oxidation markers, thyroid, sex hormones) Peter checked for the experiment [22:00];
- Peter’s results after one week on a ketogenic diet [29:30];
- Peter’s results after a week on a water-only fast [48:45];
- Peter’s results after a week on a ketogenic diet following a week of fasting [58:30];
- Peter’s “Top 6” surprises from the fasting experiment [1:08:30];
- Different fasting-mimicking diet (FMD) protocols [1:29:20];
- What is the optimal protocol, frequency, and duration for fasting? [1:33:00];
- How to break a fast without GI distress? [1:38:00];
- “Am I breaking the fast if…?” [1:41:30]; and
- More.

§

## Show Notes

## Background & Rationale [6:30]

- Objective was to work out the kinks of a study Peter would like to do down the road to figure out what a signature of autophagy looks like
- During a state of deprivation the body “eats itself” (i.e., the etymology of autophagy is to eat [*-phagy*] oneself [*-auto*])
- “The process of self-digestion by a cell through the action of enzymes originating within the same cell. Often a defensive and/or self-preservation measure” [[Wiktionary](https://en.wiktionary.org/wiki/autophagy)]
- The most effective way known to induce autophagy is to completely fast
- Other things like exercise and rapamycin are also known to induce autophagy
- To develop a signature for autophagy: looking at small molecules, metabolites, proteomic changes, may provide more insight into a question that is currently unknown or not well understood: what is the optimal fasting protocol?

Practically and scientifically, when humans restrict kcals by 30% or more:

1. It’s not clear whether it produces a longevity phenotype, even in the wild; and
2. Even if it did, it’s not clear you’d want to do it (‘caloric restriction may not make you live forever, but it sure would seem like it’)

- Some amount of cycling nutrient exposure is probably the sweet spot
- Some amount of feast and famine may be optimal
- Daily intermittent fasting? Prolonged fasts at some intermittent frequency (e.g., a one-week fast per quarter)? There are almost an infinite number of variations
- A tool to measure proxies of the benefits of these types of fast may help us elucidate what’s effective
- Protocol may need to be customized (i.e., different tactics for the same strategy): would two people benefit equally or does a certain phenotype/genotype do better on a particular regimen?

**Nothingburger rationale**

**Front-end ketogenic diet (KD) rationale:**

- Going into a fast from a high-carbohydrate state is more painful
- It’s more of an abrupt shift from glucose metabolism to ramping up the process of making ketones, which is critical in starvation

**Back-end KD rationale:**

- Ward off going crazy on the on the refeed
- Peter likes symmetry

## Methods

**Baseline & Study Population (n = Peter)**

**Week 1: KD | July 8-14, 2018**

- 7-days (days 1-7)
- ~30-40 gm carbs (total, not net), ~110-120 gm protein, high fat; no attention to caloric intake
- Labs: 7/13/18
- Increased magnesium intake, bouillon supplementation as needed

**Week 2: H2O-only fast | July 15-21, 2018**

- 7-days (days 8-14)
- Some decaf tea, mostly water (including, of course, Topo Chico)
- Labs: 7/20/18
- Increased magnesium intake, regular bouillon supplementation

**Week 3: KD | July 22-28, 2018**

- 7-days (days 15-21)
- Nutrition same as week 1
- Labs: 7/27/18
- Increased magnesium intake, bouillon supplementation as needed

**Baseline measurements**

**Table 1. Baseline characteristics (6/21/18) and follow up measurements at 1 week (7/13/18), 2 weeks (7/20/18), and 3 weeks (7/27/18).** Baseline labs were taken approximately 2.5 weeks prior to start of week 1 intervention.

![](https://peterattiamd.com/wp-content/uploads/2018/08/corrected-nothingburger-kfk-final-characteristics-and-outcomes.png)

LDL-C denotes low-density lipoprotein cholesterol; HDL-C: high-density lipoprotein cholesterol; TG: triglycerides; VLDL-C very-low-density lipoprotein cholesterol [calculation: TC – LDL-C – HDL-C]; LDL-P: low-density lipoprotein particle concentration; sLDL: small (and dense) LDL-P; HDL-P: high-density lipoprotein particle concentration; hs-CRP: high-sensitivity C-reactive protein; oxLDL: oxidized LDL; BUN: blood urea nitrogen; —: data not collected; FFA: free fatty acids; TSH: thyroid stimulating hormone; T4: thyroxine; T3: triiodothyronine; DHEA: dehydroepiandrosterone; LH: luteinizing hormone; FSH: follicle stimulating hormone; SHBG: sex hormone-binding globulin; DHT: dihydrotestosterone; IGF-1 insulin-like growth factor 1; WBC: white blood cells; Hb: hemoglobin; Hct: hematocrit ; TIBC: total iron binding capacity.

Note: Cells shaded in red are outside the range Peter considers acceptable.

**Table 2. Weight, glucose, ketone, and exercise characteristics and outcomes.**

![](https://peterattiamd.com/wp-content/uploads/2018/08/kfk-nothingburger-weight-cgm-exercise.png)

BHB denotes beta-hydroxybutyrate; CGM: continuous glucose monitor

**Pictures (to loosely assess changes in body composition):**

- Baseline [picture](https://peterattiamd.com/wp-content/uploads/2018/08/PA-01-e1534854011733.jpg) (7/8/18)
- Week 1 [picture](https://peterattiamd.com/wp-content/uploads/2018/08/PA-02-e1534854042189.jpg)  (7/13/18)
- Week 2 [picture](https://peterattiamd.com/wp-content/uploads/2018/08/PA-03.jpg)  (7/21/18)
- Week 3 [picture](https://peterattiamd.com/wp-content/uploads/2018/08/PA-04.jpg) (7/27/18)

**Baseline diet:**

- Typically 14-16 hours of time-restricted feeding (TRF) on the low-end, 20-22 hours on the high-end
- 6-7 days of the week, Peter was “TRF-ing”
- Only restrictions: Peter was limiting junk most of the time, wasn’t restricting carbs, per se (e.g., eating rice, potatoes, veggies ad libitum)

**Baseline exercise:**

- Peter doesn’t train, he just exercises
- M/W/F lift—each day focuses on one heavy hip-hinge exercise and one pulling exercises; plus ancillary movements (total time about 90 min)
- Other 4 days, usually cycling ([Wahoo](https://www.wahoofitness.com/devices/bike-trainers) and [Peloton](https://www.onepeloton.com/bike)), typically 45-75 min
- Objective was to continue exercising as Peter did before

**Baseline sleep:**

- 7-7.5 hours of actual sleep time
- Low latency times and infrequent wakeups
- Good sleep score (Oura ring)
- Historically, light on the heavy (stage 3-4) and heavy on the light (stage 1-2) (via Oura ring measurement)

**Baseline stress:**

- Higher than average
- Consistent routine of mindfulness/Vipassana meditation

**Baseline supplements & medications\*:**

**Note from Peter**: I was reluctant to list my supplements and medications because I know people constantly ask me and assume it makes sense to mimic what I’m doing. Please understand, it does not. I track a number of things with this regimen and tweak it constantly based on what I measure, which goes far beyond the bloodwork shown here. What I take, now, at the time of this writing is already slightly different from what is below. Also, I spend a great amount of time determining which brands of the supplements, below, to take so know that not all supplements are created equal and, indeed, most are pure junk. I would not suggest anyone take anything on this list without a nuanced discussion with their doctor.

**Supplements (OTC)**

- Vitamin D qhs
- Methylfolate qam
- Methyl B12 qam
- Lithium qhs
- EPA/DHA qhs
- Selenium qam
- Baby aspirin qam
- NAC BID
- Curcumin qam
- Mg oxide (400 mg at baseline; 800 mg during 3 week experiment) qhs
- Slo-Mg (2 tablets at baseline; 4 slo-Mg tablets during 3 week experiment) qam

**Medications (Prescription)**

- Metformin 1 g BID
- Atorvastatin 10 mg M/W/F qhs
- Ezetimibe 10 mg Tu/Th/Sa qam

\* No change in any supplement or medication during the experiment other than the addition of bouillon and doubling the dosage of magnesium (both Mg oxide and Slo-mag)

**Body composition changes:**

- Ideally would have gotten DEXA scans in addition to blood tests, but Peter was not in one consistent location throughout the 3 weeks
- Instead, Peter took four selfies to assess observable lean tissue and fat mass changes.

## Results

#### Week 1 results & discussion [29:30]

- A little bit of the “keto flu” (more like orthostatic hypotension, some lightheadedness)
- Other than that, nothing positive or negative subjectively in terms of how Peter felt or performed
- Workouts about the same
- Sleep about the same

**Diet**

- Breakfast:
  - Skipping breakfast or had a light breakfast
  - Typically coffee with MCT powder
- Lunch:
  - Macadamia nuts
  - Avocado
  - Olives
- Dinner:
  - Salad
  - Modest protein

**Notables:**

- Triglycerides (TGs) went up, which is abnormal (in general and for Peter), though TGs are highly variable
- LDL-P went way up (50% increase): went from 10th percentile to the 55th percentile (MESA or multi-ethnic study of atherosclerosis)
- Small LDL (sLDL) went to 800 (<500 is optimal), a 45% increase from baseline (sLDL is also known as small dense LDL or sdLDL)
- Uric acid went up: Peter is maniacal because of uric acid’s effect on blood pressure and atherosclerosis (Some evidence that uric acid can crystallize inside of atherosclerotic plaque along with the sterol)
- Homocysteine was high
- Free T3 (fT3) went down, T4 (thyroxine) went up (probably converting less T4 to T3 [triiodothyronine], and more to reverse T3 [rT3])
- fT3/rT3 ratio tanked (56% decrease from baseline)
- Body wanting to slow the metabolism down, Peter assumes
- Peter lost around 4 lbs from baseline: surprised to see the deterioration of thyroid function with a weight loss that small (and probably a nontrivial amount of the weight loss was water)
- IGF-1 did not drop
  - Peter says the 70th to 8oth (201 is 80th for his age) percentile is the sweet spot for IGF-1, with periods of cycling
  - Peter is at 196-201, which is within the sweet spot, with the caveat that cycling IGF-1 may be optimal
  - When Peter was in long-term (i.e., >1 year) nutritional ketosis (NK) a few years ago, his IGF-1 did drop and remain at about 150. Not clear if this is ideal or cycling from low to high is better.
- The KD was a little more fast and loose (“smokin’ and jokin’ as Peter said) than his [previous journeys into NK](https://peterattiamd.com/what-i-actually-eat/); not obsessing over BHB levels, etc.
- Trailing CGM went down a little

Note on uric acid: one alternative explanation for the spike in uric acid is provided by Steve Phinney and Jeff Volek on [their blog](https://blog.virtahealth.com/keto-adapted/): competition between ketones and uric acid for renal excretion.

They write:

> To protect the body’s acid-base balance against too much acid from the diet or produced by our metabolism, our kidneys have the capacity to identify and actively clear organic acids from the blood. To some degree, at the onset of nutritional ketosis, this seems to be indiscriminate – it treats uric acid (which can be toxic when it builds up in the blood) and non-toxic levels of ketones all the same. So at the start of nutritional ketosis, these two organic acids compete for excretion, causing blood uric acid to rise despite no increase in its production.

![](https://peterattiamd.com/wp-content/uploads/2018/08/phinney-volek-uricacid.png)

**Figure 1. Serum uric acid levels during keto-adaptation. Image credit: Steve Phinney and Virta Health.**

Note on NMR: two ways to get an NMR (Nuclear **Magnetic** Resonance) commercially, both based on technology developed by LipoScience:

1. LabCorp
2. THD

They use different magnets: THD is considered more accurate, because they use a higher strength magnet, and the numbers tend to run higher, typically 20-30%. Peter is using THD (i.e., the higher estimate).

#### Week 2 results & discussion [48:45]

- Able to now look at trailing 7-day CGM (rather than comparing to trailing 90-day CGM from baseline): a much greater sense of what’s happening in the past week from a glucose perspective
- Bouillon more regularly, had some caffeine-free tea
- Surprised to see TGs after the fast not lower
- Oxidized LDL (oxLDL) looked great
- Uric acid elevated: getting into the gout attack range
  - Could be a signature for autophagy in here (“In humans, the final compound of purines catabolism is uric acid” [[Maiuolo et al., 2016](https://www.ncbi.nlm.nih.gov/pubmed/26316329)])
  - This may be the single most important biomarker change Peter observed in the entire “experiment,” given his interest in understanding signatures of autophagy
- BUN went down to 12 as expected (body is sparing nitrogen and wasting as little as possible, given the complete absence of nitrogen ingestion)
- Adiponectin did not go up which was surprising (adiponectin goes up when lipolysis goes up)
- fT3/rT3 ratio of 0.05 is the lowest PA has ever seen, in any patient, at any time
  - He felt very cold during the fast, indicating hypothyroidism
  - Also may explain why weight did not drop even more
- Free testosterone dropped to the 15th percentile (very low for Peter)
- IGF-1 dropped to the 10th percentile
- Hemoglobin/Hematocrit went down, very likely due to lower testosterone and perhaps some hemodilution since Peter made a great effort to remain hydrated
- Weight down about 10 lbs from baseline
- Ketones increased as expected
- 7-day trailing CGM went down to 79 mg/dL, almost 20 mg/dL during 2 weeks (Peter suspected if he continued the fast, the CGM would nadir at about 70 mg/dL)

#### Week 3 results & discussion [59:00]

- First day a little higher in carbs
- Very high TGs at the end of week 3: from 54 at baseline to 229, a 324% increase; had only seen TG this high once before (paradoxically, it was on a blood test where LDL-P was especially low—about 300 nmol/L during one blood test back in 2011 or 2012)
- Trying to understand why LDL-P would go so low after a ketogenic diet, and why TGs would get so high
- CRP >1
  - Peter said he was consuming a ton of dairy via whipped heavy cream
  - Exercise can elevate CRP (but Peter rested the day prior to labs and he never has a CRP above 1.0 unless sick, which he was not at this time)
- Homocysteine (Hcy) and uric acid returned to baseline
- Thyroid was moving back in the right direction
- Sex hormones made a comeback

#### Peter’s “Top 6” surprises from the fasting experiment [1:08:30]

1. Relatively trivial weight loss (objective) and muscle loss (subjective, based on progression of 4 pictures, above)
2. Enormous improvement in Peter’s sleep, especially delta wave (III/IV) and the feeling of being totally rejuvenated by even shorter amounts of sleep (typically only 6 hours)
3. A feeling of calmness and presentness Peter’s never experienced before in his meditation, which extended into all activity, including walking, sitting, and working
4. The most bizarre paradox of physical performance: virtually no deterioration of strength (on at least one lift—rows—Peter felt stronger than ever), but complete destruction of even low end aerobic activity (walk) and high end aerobic (Peloton)
5. Deterioration of peripheral thyroid function (biochemically with the lowest fT3 to rT3 I have ever seen in 6 years of seeing hundreds of these) and symptomatically (never more ‘cold’ in his life)
6. Complete elimination of a chronic pain in Peter’s right wrist and near-complete elimination of pain in left elbow (these had been issues for 18 and 12 months, respectively, and the left elbow was so bad it was interfering with ability to hold bow steady).

#### Different FMD protocols [1:29:20]

- Peter has done different variations of an FMD
- The [Prolon FMD](https://prolonfmd.com/) (Table 3) is relatively higher in carbohydrate than a KD (Figure 2)
- Important to remember the context: an FMD may be 47% carbohydrates, but for an 82 kg individual, it works out to ~1 gm carbohydrate/kg of body weight (days 2-5), whereas the same individual consuming 3,000 kcal/d, it would work out to 4.3 gm/kg
- One variation is a KD version of an FMD (i.e., lower in carbohydrate and higher in fat compared to Prolon)
- Another variation is a TRF-FMD: Peter has one meal a day of rice and salad, typically lower in protein than Prolon

**Table 3. The FMD (*The Longevity Diet* by Valter Longo, 2017).**

![](https://peterattiamd.com/wp-content/uploads/2018/08/FMD-overview-Longo-2017-tld.png)

\*\*\*

![](https://peterattiamd.com/wp-content/uploads/2018/08/FMD-New-longo-pie.png)

**Figure 2. Macronutrient breakdown of the clinical FMD.**

#### What is the optimal protocol, frequency, and duration for fasting? [1:33:00]

- An important tenet to longevity is exposure to nutrient cycling (autophagy and mTOR up and down)
- Frequency of the fast might be a function of the damage you do off the fast
- Frequency of the fast might be a function of your metabolic health
- Valter Longo suggests something along these lines in terms of metabolic health and frequency of FMDs (Table 4)

**Table 4. FMD frequency, according to *The Longevity Diet* by Valter Longo (2017).**

![](https://peterattiamd.com/wp-content/uploads/2018/08/fmd-frequency-bbr-longo-tld.png)

Image [here](https://www.dropbox.com/s/q7ds1c9qawv6eov/%23fmd%20frequency%20%23bbr%20%23longo%20%23tld.png?dl=0)

#### Breaking the fast without GI distress? [1:38:00]

- When you’ve been fasting, the stomach is decompressed
- You can get hiccups if you add too much volume back to your stomach

#### Am I breaking the fast if…? [1:41:30]

- Use your common sense
- Why are you fasting?
- Coffee and tea is probably majoring in the minor

§

§

## Selected Links / Related Material

**Peter’s previous foray into nutritional ketosis**: What I actually eat (circa Q4 2011) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [29:30]

**In humans, the final compound of purines catabolism is uric acid**: [Regulation of uric acid metabolism and excretion](https://www.ncbi.nlm.nih.gov/pubmed/26316329) (Maiuolo et al., 2016) [48:45]

**Meditation, calmness, and presentness**: [Tim Ferriss: depression, psychedelics, and emotional resilience (EP.01)](https://peterattiamd.com/timferriss/) | The Peter Attia Drive ([peterattiamd.com](https://peterattiamd.com/)) [1:17:00]

**Cahill’s starvation study**: [Liver and kidney metabolism during prolonged starvation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC535723/) (Owen et al., 1969) [1:23:20]

**Valter Longo’s FMD**: [Prolon FMD](https://prolonfmd.com/) | ([prolonfmd.com](https://prolonfmd.com/)) [1:29:30]

**Valter Longo’s book**: [The Longevity Diet](https://www.amazon.com/Longevity-Diet-Discover-Activation-Regeneration/dp/0525534075) by Valter Longo [1:29:30]

§

## People Mentioned

- [Sam Harris](https://twitter.com/SamHarrisOrg) (great AMA interface) [3:25]
- [Rick Johnson](https://www.ucdenver.edu/academics/colleges/medicalschool/departments/medicine/renal/Pages/RichardJohnson.aspx) (uric acid expert) [50:40]
- [Josh Martin](https://www.facebook.com/josh.martin.319) (Peter’s [body worker](https://www.kriyabodywork.com/)) [1:14:30]
- [Tim Ferriss](https://twitter.com/tferriss) (mindfulness, meditation, and psychedelics)[1:17:00]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (fasting experiments)[1:23:20]
- [Andy Coggan](https://www.peakscoachinggroup.com/DrAndrewCoggan) (cycling power zones) [1:26:30]
- [Matt Wilpers](https://www.instagram.com/mattwilpers/?hl=en) (Peloton cycling) [1:26:30]
- [Valter Longo](https://gero.usc.edu/faculty/longo/) (FMD) [1:32:00]
- [Dom D’Agostino](https://twitter.com/DominicDAgosti2?lang=en) (fasting, ketosis)[1:34:50]
- [Dave Asprey](https://twitter.com/bulletproofexec?lang=en) (may have coined “disaster pants” [1:37:50]
- [Isaac Asimov](https://en.wikipedia.org/wiki/Isaac_Asimov) (quote about discovery in science) [1:46:00]

§