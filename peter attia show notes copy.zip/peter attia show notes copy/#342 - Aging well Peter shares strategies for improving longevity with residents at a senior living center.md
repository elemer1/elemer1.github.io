# #342 ‒ Aging well: Peter shares strategies for improving longevity with residents at a senior living center

**Source:** [https://peterattiamd.com/agingwell/](https://peterattiamd.com/agingwell/)

---

In this special episode of The Drive, Peter joins a unique conversation inspired by his daughter’s volunteer experience at a senior care center, where she formed meaningful relationships with residents curious about healthspan, lifespan, and strategies for living well as they age. Peter engages directly with the residents, covering critical topics like the profound impact of exercise—particularly strength training— for maintaining mobility, preventing falls, and preserving independence later in life. He also discusses the importance of nutrition, emphasizing adequate protein intake, along with strategies for sleep optimization and preservation of brain health. Peter also underscores the importance of emotional wellness, purpose, and social connections in healthy aging, provides advice on staving off chronic disease, and much more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/agingwell/the_Drive_public.png)

Play

#342 ‒ Aging well: Peter shares strategies for improving longevity with residents at a senior living center

#342 ‒ Aging well: Peter shares strategies for improving longevity with residents at a senior living center

1x15s30s

0:0043:33

## We discuss:

- Peter’s definition of longevity [2:30];
- Why it’s never too late to invest in your longevity [5:30];
- The importance of adding “life to years” rather than just “years to life” [7:45];
- The “four horsemen”—heart disease, cancer, neurodegenerative diseases, and metabolic conditions [9:15];
- Advice for those managing chronic diseases later in life [11:30];
- Why balance declines and falls become increasingly common with age, and how to prevent them [13:30];
- Why strength training is essential (and effective) for older adults [18:30];
- The five tools in Peter’s longevity toolkit [21:00];
- Practical ways older adults can safely begin exercising despite physical limitations or health issues [23:00];
- Principles of good nutrition, and the importance of adequate protein intake [24:00];
- The importance of sleep for cognitive health, and effective sleep-improvement strategies for seniors [27:30];
- How emotional health, social connections, and a sense of purpose significantly impact quality of life and longevity [32:00];
- Why Peter decided to focus his work on longevity [33:45];
- Protein intake recommendations should be based on ideal body weight (not current weight) [34:45];
- The potential of klotho as a therapy for improving cognitive function and combating aging-related cognitive decline [35:30];
- The best types of protein supplements to consider [36:45];
- The APOE gene’s influence on Alzheimer’s disease risk, and why everyone should proactively address brain health, regardless of genetics [38:15];
- How falls can accelerate cognitive decline, and the importance of staying physically and mentally active [40:45]; and
- More.

---

## Show Notes

\***Notes from intro**:

- This is a special episode of *The Drive*
- This conversation is a bit different from our usual format
- Peter’s daughter Olivia trades places with him as the interviewer as they visit a senior living center to discuss all things longevity as it relates to an aging population
- A big of background: Olivia spent part of her summer last year volunteering at this center where she connected with a number of the residents
  - They had a curiosity about healthspan, lifespan, and strategies for living well as they age
- Through that experience, they invited Peter to speak for their audience and this is a recording of that conversation
- In this conversation we speak about all of these topics but with a particular focus around an aging population
  - What longevity really means: not just adding years to life, but life to years
  - The 4 horsemen of chronic disease
  - It’s never too late to start making changes for better health
  - The critical role of exercise, especially strength training in maintaining mobility, preventing falls, and preserving independence
  - How to approach exercise later in life
  - The importance of protein intake and nutrition principles for aging
  - Sleep optimization
  - Emotional health, social connection, purpose, and why relationships matter as much as physical health

## Peter’s definition of longevity [2:30]

- Olivia is with her dad Peter and are here to talk about longevity
- Over the summer Olivia volunteered at a senior living center called [Querencia](https://www.querenciabartoncreek.com/)
- During that time she met Sally who was very interested in Peter’s work
- Sally couldn’t join this episode because she’s sick, so this episode will be a conversation between Olivia and Peter for an audience at Querencia followed by their questions

**The word longevity means different things to different people. When you talk about longevity, how are you defining it?**

- Definitely not living forever, although understandingly that’s what some people think of when they think of longevity
- Peter is talking about it in terms of 2 things: lifespan and healthspan
- The **lifespan** part is how long you live
  - This is what most people think of
- The **healthspan** part is how well you live
- Both of these are of equal importance, and an extreme of one without the other is not ideal
  - Nobody is saying, “*I’d love to live to 100, but I want to spend the last 20 of those years unable to move*.”
  - Similarly no one would think it’s ideal to live an amazing, healthy live, but having that life cut short prematurely at 50

> “*When I think of longevity, what I’m really thinking about is maximizing both the length of life and the quality of life*.”‒ Peter Attia

*Quality could further be broken down into a physical piece*

- Am I free of pain most of the time?
- Am I able to physically do the things I enjoy doing?
  - That could range from just the activities of daily living and self-care to recreational activities
  - If you like to garden, how long do you want to be able to do that?
  - If you play golf, if you like to go for walks and hikes or swim

*Then there’s a cognitive piece*

- Peter doesn’t think anybody would fully expect that his brain (at his age) is as sharp as Olivia’s is, but he still wants to believe that his mind is pretty sharp
  - We all want that for as long as possible

*The final piece is an emotional piece*

- That deals with happiness, sense of purpose, connection to others
- You can imagine a scenario where somebody has perfect physical healthspan, meaning they can do anything they want to do physically, their brain is sharp, but they have no friends and no relationships
  - We would all agree that that’s not really an ideal life
  - Nobody would aspire to that
- When you put all those things together, that’s what longevity is

## Why it’s never too late to invest in your longevity [5:30]

***If some people here are wondering, is it too late to start caring about longevity and living longer, what would you say to them?***

- That is not the case
- On the one hand, the earlier a person begins to take steps to increase their longevity, the more opportunity they have

*It’s like investing*

- When is the best time to start saving for retirement?
- Probably the minute you start earning your first paycheck in your teens or 20s
- But does that mean you shouldn’t save money when you’re older? No, it doesn’t

*What the data say*

- Data from clinical trials that are done with seniors that demonstrate for example: people who have never lifted weights in their life before, who start lifting weights for the first time when they’re in their 60s and 70s, have a remarkable benefit
- This is not just true of weight training; it’s true of any sort of exercise

***The short answer is no, it’s never too late to really start thinking about this, but obviously the best time to plant the tree is yesterday, if not today***

Olivia asks, “*Why do they have a benefit if they haven’t done it before?*”

- There’s an effect of training
- Specifically thinking of exercise, the body is really a “use-it-or-lose-it” organ (or collection of organs)
  - And the muscles are a great example of that
- It’s actually true of young people and old people

**⇒** The greatest effect of exercise is generally seen in the person who goes from being completely sedentary to even a mild amount of training

- If you look at somebody who exercises all the time ‒ if they added 3 hours a week to their training, it wouldn’t have an enormous impact
  - Like Peter or Olivia
- If you took an individual who did zero exercise, and you took them to 3 hours a week, the impact is enormous
  - Let’s be honest, 30 minutes a day, 6 days a week, is not a huge ask

## The importance of adding “life to years” rather than just “years to life” [7:45]

***Can you talk about the importance of adding life to years rather than just years to life and what that means to you?***

- It means a lot because the metric that most people think of is life expectancy
- How many times have you heard, “*Life expectancy is increasing, life expectancy is decreasing*.”
- The reason for that is it’s just the easiest thing to measure because it’s objective, it’s quantitative, and it’s a single number
  - It’s a number that shows up and it can be measured from a death certificate
  - We know exactly how many years to the day that a person lived, and if we keep track of that, we certainly know something about them

***Peter’s argument is that is not the most important thing***

*Thought experiment: what would you choose?*

- If you could live to 80 in remarkable and perfect health, and then when your life is over, it ends very quickly and suddenly
- Versus you could live to 100, but you spend that last 20 years in a painful state of decline

***Very few people would choose the latter, even though they’re living longer***

- What most people want is quality of life over quantity, outside of these extreme examples, which are common and tragic, where people die and they’re young

***When you start to think about pushing those things, most people in Peter’s experience, are more interested in quality of life***

## The “four horsemen”—heart disease, cancer, neurodegenerative diseases, and metabolic conditions [9:15]

**When it comes to someone’s risk of dying, you characterize the biggest risks as the 4 horsemen. Could you explain what those are?**

- There’s no reason to avoid talking about the inevitable: every one of us in this room is not going to be alive at some point
- To confront the how is important
- Statistically speaking, all of us in this room are going to succumb to 1 of 4 processes or disease processes

*In rank order:*

1 – [Cardiovascular](https://peterattiamd.com/category/diseases/heart-disease-prevention/) and cerebrovascular disease

- That’s a heart attack, a stroke
- That’s the leading cause of death in the United States
- That’s the leading cause of death globally
- It’s the leading cause of death for men, and it’s the leading cause of death for women, full stop.

2 – [Cancer](https://peterattiamd.com/category/cancer-prevention/), and it’s not far behind #1

- Cancer isn’t just 1 disease, we lump it all together
  - Prostate cancer and breast cancer are as different as a pickup truck and a Corolla
  - They both have 4 wheels, but that’s where the similarity ends

3 – Diseases of dementia and the [neurodegenerative diseases](https://peterattiamd.com/category/neurodegenerative-disease-prevention/)

- There are a lot of things in here
- [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) is the most common form of dementia
- You also have lots of other types of dementia that are not neurodegenerative, such as [vascular dementia](https://en.wikipedia.org/wiki/Vascular_dementia)

4 – [Metabolic diseases](https://peterattiamd.com/category/metabolic-disease/) are a spectrum of diseases

- The most extreme version of this would be [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)
- Along the way, you have conditions like [fatty liver disease](https://en.wikipedia.org/wiki/Fatty_liver_disease) and insulin resistance, and all of these conditions form a continuum

**⇒** The most important thing to know about them is, while not that many people will die directly from those diseases, if you have anything along that continuum, it’s increasing your risk by about 50% of the other 3 horsemen

> “*We really want to think about a strategy at mitigating all four of these conditions and delaying them as long as possible.*”‒ Peter Attia

## Advice for those managing chronic diseases later in life [11:30]

**What would you say to someone that may already be navigating these chronic diseases that come with aging, and what advice would you give them on how to manage a high quality of life and keep hope during these times?**

- It would matter very specifically on which one we’re talking about
- Based on the age of everyone in this room, it’s impossible for Peter to imagine that nobody in this room hasn’t already faced some of these diseases
- If you’re sitting in this room and you already had a stent placed in your coronary arteries, that says, you’ve already had a brush with coronary artery disease
- Maybe someone in this audience has already had a heart attack, and you’re fortunate enough to have survived it
- The short answer is, the fact that you’ve survived it is great, and that means you get a second chance (many people don’t)
- Many people’s first brush with heart disease is death

**⇒** On average, about 50% of people (1 in 2 people) that have a heart attack, it’s immediately fatal

- If you’re in that group or you’ve had that heart attack, or you know somebody who has and they’ve lived to tell about it, they’re in the lucky camp

***They should be doing is everything in their power to not only prevent it from happening again, but to strengthen their body***

*Interventions*

- The first thing to ask yourself is, “*What were the conditions that I had that led to this heart attack in the first place?*”
- Some of these conditions you don’t have a lot of control over: genetics play a strong role here

***There are many things that can be controlled, such as cholesterol levels, blood pressure, smoking***

- Those would be the big 3
- And we have ways to manage all of those things

***We know that exercise plays a very important role, as does metabolic health***

- Peter has met many people who have had that near brush with death from that point of a first heart attack
  - They survive it, and what do they do?
  - They turn it around and they say, “*Look, I’m going to lose 30 pounds. I’m going to stop smoking, or I’m going to manage my blood pressure, cholesterol better. I’m going to take up exercise.*”
- Peter knows people that have gone on to live 30 years after that event
  - That might’ve happened when they were 60, and they live until they’re in their 90s
- He would always frame it through the lens of, “*Hey, am I fortunate enough to have survived this thing? And if so, what am I going to do going forward?*”

## Why balance declines and falls become increasingly common with age, and how to prevent them [13:30]

**What happens to our balance as we age? Falls seem to be so prevalent here in our senior community. Can we help keep these problems from increasing as we age?**

- Yes

***If there’s a 5th horseman, it’s accidental death***

*What constitutes accidental death varies by age*

- When we’re talking about people that are Olivia’s age, the most common cause of accidental death is going to be car accidents and drug overdose
- When you talk about people Peter’s age, the most common cause of accidental death is overdose, by far

**⇒** When you talk about people the age living at [Querencia](https://www.querenciabartoncreek.com/), it’s a total flip, and the prevalence of accidental death goes up by 5 or 6-fold, and it is virtually all related to falling

*Questions about falls:*

1. Why are falls so lethal?
2. Maybe more importantly, why do people above the age of 65 fall so much more?
3. Why do women fall disproportionately more than men?
4. Why are women more injured by falls than men?

*Starting with questions #1 & #2*

**⇒** As we age, we don’t just lose our balance, but we’re losing something else that younger people take for granted, which is called **reactivity**

- For example, the other day, Peter was in the woods because one of his kids accidentally kicked the soccer ball down into the woods and he had to go and get it
  - As you can imagine, the ground is very uneven and it’s covered in leaves and twigs and branches, so you can’t even see what you’re stepping on
  - Every step is a sprained ankle waiting to happen
  - And sure enough, at one point, Peter steps into something that wasn’t as it appeared and he got jolted
  - He had to react very quickly with his leg to put it in the right place so he wouldn’t fall
  - He did, and he’s here talking about it, and he doesn’t even remember which leg it was (that’s how insignificant this was)
- The type of muscle fiber that was necessary to do that is called a **IIa muscle fiber**
  - That is the type of muscle fiber that is responsible for explosive movement
  - It’s the type of muscle fiber that is the most powerful muscle fiber
  - [Discussed with Andy Galpin in episodes [#239](https://peterattiamd.com/andygalpin/) and [#250](https://peterattiamd.com/andygalpin2/)]
- Well, those muscle fibers start getting weaker and weaker and shrinking at about the age of 25
- Peter is long past his peak (he’s in his early 50s), but he still has enough to hold him on

***But at some point, type IIa muscle fibers really, really start to diminish, and by the time someone’s living in a senior living center, you’ve got threads of those things left***

**⇒** The good news is you can train these muscle fibers

- The only way to train them is to move very heavy weights
- Sounds crazy, counterintuitive, but that’s what we have to do
- We have to move really heavy weights, and we have to train in movement patterns like that, which means, for example: bouncing, moving side to side, jumping rope
- Things like that are necessary for our feet to have the reactivity that you had when you were young

*Regarding questions #3 & #4*

**⇒** As we age there is a reduction in bone density and a reduction in muscle mass

- This is the reason why women are more susceptible than men to these injuries
- Women have less muscle mass on average and have lower bone density on average
  - In part due to the fact that many women didn’t receive hormones after menopause, and as their estrogen levels went down after menopause, their bones got disproportionately weaker relative to men
  - Because estrogen turns out to be the most important hormone in preserving bone density

***All of these things taken together means that falling is something we have to be very mindful of at any age, but boy, does it play a bigger role above the age of 65***

- Peter would be shocked if no one in this audience knew somebody who hadn’t experienced a significant fall that resulted in a broken hip or broken femur

**⇒** The tragedy of that type of accident is that, in many cases, it’s not fully recoverable

- You have the proportion of people that will die as a result of that
- Even the people who live, often about 50% of them never regained the same level of mobility they had before

***All of this, points back to the idea that we want to be exercising as much as possible***

> “*I’m going to sound like a broken record saying this, but you’re going to want to have your body as prepared as possible because that physical piece is so important in preventing these types of injuries*.”‒ Peter Attia

## Why strength training is essential (and effective) for older adults [18:30]

**Is there anything that people of this age can do now to preserve that muscle or strengthen it, or did it have to be done while it was still in their 20s?**

- What we do to day is what matters

*For example, Peter interviewed* [*Belinda Beck*](https://theboneclinic.com.au/our_team/prof-belinda-beck/) *[*[*episode #322*](https://peterattiamd.com/belindabeck/)*] on the podcast a few months ago*

- She’s a researcher in Australia, and she did a study there that he is really fond of called the [LIFTMOR study](https://pubmed.ncbi.nlm.nih.gov/28975661/)
- This is a study that was done with a group of women, all of whom were over 65 years old, and all of whom had a disease condition of very, very low bone density
  - It was a group of 65-and-plus-year-old women who had very brittle bones, who didn’t exercise beyond yoga and walking
  - It’s not like they were inactive, but they’d never lifted weights
- These women were randomized into 2 groups
  - One that continued with that type of exercise
  - One that engaged in really, really heavy strength training
- There’s a [video](https://youtu.be/2fx_LfZFxv0?si=OPX18yoki8Xarx9v) of this on YouTube that is easily one of Peter’s 10 favorite videos of all time, because these women, who look so frail, by the end of the study, are able to, in some cases, pick up their own body weight off the ground (deadlift their own body weight)

**Osteoporosis sufferers using weight training**. Credit: [Physical Culture](https://youtu.be/2fx_LfZFxv0?si=OPX18yoki8Xarx9v)

- And they’re coached on how to do this safely, they really do hardcore powerlifting exercises, and they gain strength
  - They’re not holding the little two-pound dumbbells doing curls
  - They’re doing squats, they’re doing deadlifts, getting to pull-ups, bench press, all sorts of things
- By the end of this study, they defied something that we thought was possible
- We never thought it was possible to increase bone density
  - We thought the best you could do was maintain bone density or maybe slightly prevent the rate of decline

***Amazingly, in these women, based on the CT scans of their bones, they actually increased bone density***

- Peter finds this to be one of the most uplifting and important findings with respect to aging
- It speaks to how the ideas that lifting weights is a young person’s thing or a male thing are just incorrect

> “*Lifting weights is something every person on this planet should be doing*.”‒ Peter Attia

## The five tools in Peter’s longevity toolkit [21:00]

**Quickly walk through the tactics in your longevity toolkit**:

- Broadly speaking, there are 5 buckets of things that we have control over to impact all of these things we’re talking about
- In no particular order they are:
- 1- Exercise
  - You can probably tell Peter’s bias is that’s the single most important one for the most part
- 2 -Nutrition
  - What you eat matters
- 3 – Sleep
  - The difference between sleeping well and not sleeping well has an enormous impact on your brain, but also on your metabolic health, which then indirectly plays a great role in other diseases
- 4 – All of the medications and supplements, drugs, anything that your doctor prescribes or that you can buy over the counter
  - And these are of varying degrees of efficacy
  - Some of them are incredibly dubious
  - Some of them can be life-saving
- 5 – All the tools that we would have at our disposal to improve our emotional health and well-being

## Practical ways older adults can safely begin exercising despite physical limitations or health issues [23:00]

***For the people in this audience, how can they start to safely exercise while also managing physical limitations?***

Peter explains, “*It’s hard to provide a blanket statement on that because everybody’s going to be different, but I think it’s safe to say that people are less fragile than they believe.*”

- For example, Peter has met many people who have back injuries and think they really can’t do anything, but when you probe a little bit further, you realize that nothing tends to make their back hurt more than inactivity
- Peter doesn’t remember who made this statement, but he loves it and has paraphrased/ plagiarized it many times: ***sitting is to lower back pain what bourbon is to alcoholism***
  - Sitting make the back feel worse
  - After a long drive, it hurts worse

**⇒** For most people, actually being active makes them feel better

*There are certain activities where this is not true*

- If you have no cartilage left in your knee, more walking won’t make you feel better
  - You’re going to have to see an orthopedic surgeon; they might need to do a knee replacement
- In this day and age, in 2025, what can be done with a knee replacement, a hip replacement, even a shoulder replacement; these operations have come along so far, and they have restored so much quality of life to individuals
- Every one of these cases has to be managed individually
- If you have a really good PT or rehab professional who knows what’s fixable with more training or more conditioning versus what needs some medical attention

***The aspiration should be, what can I do to get as active as possible?***

## Principles of good nutrition, and the importance of adequate protein intake [24:00]

**People have questions about different diets being talked about, and they aren’t sure which one they should follow. Is there a diet you think is best, or does it depend on the individual?**

- Peter doesn’t think there is a diet that is best

***There are principles that matter, and everyone should find the diet that best allows them to adhere to the principles***

**⇒** The principles are not to eat too much and not to eat too little

- That sounds dumb, but it’s just the reality of it
- Everyone struggles with a different end of that spectrum
- There are some people who just don’t like to eat that much (they’re like little birds), and as they get older, that becomes a huge problem (they are too frail)
- At the other end of the spectrum, you have people (like Peter) who like to eat too much, and we will spend most of our life fighting against the urge to eat too much
- That also becomes a problem as you get older, because the heavier you are, the more weight you’re putting on each and every one of those joints
  - Not to mention other complications that come from eating too much
- We’re thinking about all these things that are working against us as we age

*In an aging population, the most important thing to emphasize is getting enough protein*

- For many people, it’s kind of hard to get enough protein in
  - Even Peter has to pay attention to it
- It’s really easy to get all the carbs in the world
- You don’t have to go out of your way to eat more fat
- But you do have to be cognizant of getting enough protein

**⇒** Enough protein is a pretty big number: 1 gram per pound of body weight

- If you weigh 150 lb, are you getting 150 g of protein a day?
  - For women, that’s even harder
- If you fall a little bit short of that, it’s okay, but if you’re at half of that, you’re really not getting the optimal amount of protein

*As we age, we develop something called anabolic resistance*

- Which means that it is harder and harder for our muscles to synthesize and grow new muscle cells with the given amount of amino acids (which are the building blocks in protein) that we get by eating protein
- Therefore, we actually need more and more protein to overcome that
- We talk a lot about obesity, we talk a lot about [osteoporosis](https://en.wikipedia.org/wiki/Osteoporosis) and [osteopenia](https://en.wikipedia.org/wiki/Osteopenia), but there’s another condition of aging called [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia)
- Sarcopenia is the condition of muscle loss, and that’s a huge problem

***There are 2 ways to address sarcopenia: consuming enough protein and doing enough resistance training***

- It doesn’t matter if you’re a vegetarian
- It doesn’t matter if you like a Mediterranean diet
- It doesn’t matter if you like steak and potatoes

***If you can adhere to those principles, that’s going to make your life easier***

- Is it harder to adhere to those principles if you’re a vegan?
  - Yeah, it’s a lot harder, but it’s not impossible
  - Lots of people have done it

**⇒** Looking at a food tracking app in your phone is a great way to spend a week evaluating how many grams of protein you’re getting

- For many of us, you’ll be surprised that we’re probably underdoing it

## The importance of sleep for cognitive health, and effective sleep-improvement strategies for seniors [27:30]

**Sleep is something Peter has written a lot about, he didn’t use to take it very seriously but now he does. Why is sleep so important?**

- Peter goes to bed around 9:00
- Until about 12 years ago, his mantra was, “*I’ll sleep when I’m dead.*”
- The evidence is pretty overwhelming, especially for both near-term and long-term function of the brain, that sleep is very important

*There are a couple of unique challenges for older adults*

- Most people over 65 or 70, they’re not fighting the will to sleep because they want to be out partying all night
- It’s more that other things are getting in the way

**⇒** We know that, as a person ages, they tend to sleep a little bit lighter, and their sleep architecture tends to change a little bit

- We also know that other things get in the way, especially for men, which is, it gets harder and harder to make it through a night without having to get up to pee
- Peter is  already at that stage where, at least 2 out of the 7 nights a week, if he is not mindful about when he had his last glass of water, he’s going to be up at 2:00 or 3:00 in the morning to pee
- And sometimes, that’s harder to go back to bed after

*What are the things that we have under our control?*

- 1 – The timing of water
- Now, water is super important, and the older a person gets, the more susceptible they are to dehydration
  - The older a person gets, the less reliable thirst is as an indicator for fluid status
- At Olivia’s age, you don’t really need to pay attention to how much you’re drinking ‒ thirst will be the guide
- But that becomes less and less true as you age

***So you’re juggling a narrow problem, which is, on the one hand, you have to be mindful about drinking enough, but at the other hand, you can’t drink too much too close to bed because that’s going to keep you awake***

- 2 – Another thing that makes a huge difference in sleep quality is timing of food

**⇒** The longer you can have between when you have dinner and when you go to bed, the better

- Peter eats dinner really early because he has young kids in his house
  - That’s why he can get away with going to bed at 9:00, because it’s still been 3 hours since he ate
- 3 – Another thing is alcohol

**⇒** The less alcohol you have in your system when you sleep, the better you’re going to sleep

4 – Having a super dark room, having a super cold room is going to make a big difference

5 – Perhaps the biggest thing to make a point about here is consistency of timing, especially on the wake-up

***If you could tether yourself to one time to wake up, and if you force yourself to wake up at the same time every day and don’t allow yourself to take a nap during the day, this is going to regulate when you end up going to bed by building up enough sleep pressure***

- If a person tells Peter, “*I’m struggling to sleep at night,*” and he finds out they’re napping during the day, the first thing he wants to do is get rid of the nap
  - 1 – Fix the wake-up time
  - 2 – Eliminate the nap
  - And let them get into a better sleep cycle that way

**Are there any good sleep supplements that you recommend taking and that are not damaging to you?**

- One has to be very careful with this stuff
- There’s certainly evidence to suggest that, as we age, [melatonin](https://en.wikipedia.org/wiki/Melatonin) levels go down, and therefore melatonin can aid at least with sleep initiation

**⇒** It’s important to know that melatonin really is only the signal to initiate sleep

- It’s not going to necessarily keep you asleep all night
- If you’re not doing all of the other things correctly, melatonin is going to be limited in its efficacy

***Before going down the route of supplements, be sure everything Peter just discussed about sleep hygiene is completely dialed in***

- If there’s an issue falling asleep, melatonin can be a viable tool
- Make sure you get the lowest dose you can buy (maybe 300 micrograms, at most twice that dose)
- They tend to sell this stuff in high enough doses to kill horses, and it’s not necessary
- You don’t need anything north of 1 mg

*One has to experiment a little bit with other things*

- Peter finds [ashwagandha](https://en.wikipedia.org/wiki/Withania_somnifera) a little bit helpful
- For others, maybe not so much

## How emotional health, social connections, and a sense of purpose significantly impact quality of life and longevity [32:00]

- A lot of people think this is not really something that matters in longevity
- Peter talked about this in the last chapter of [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.--JeJHXaTizre_2a8KUiq1QegfrPy8qjvM-fJrFyxpCIhUKt5gAD9EKSbP-3enXo5ANQ-wldMigVaH3dXR57QeNxBRHmVMC8UP8vYt3LhdgqfSnIpFoM8NnzufuElxp2b_09aR9dFc2ABA88RLhJjrGc8kAaw6aDX80PtiUMynmQE8tZKSynxCPgTMlxIiWJeLfkohugZRXj-i6RwouAb65tMf_vYUOlmVyheFnppF0.a3NLd2PidLOUfJng2unZxIQWpEqiW9NCZxXMdhafUVE&qid=1738765227&sr=8-1)
  - How it’s really important to him and that he recently discovered it

**Talk a little about emotional health and how it’s important as people are aging**

- It’s important at any age
- What is so appealing about living at a senior living center is you have a built-in system of friendship
- Peter would imagine that’s probably a great source of wellbeing that many would be missing out on if they were living alone
- Peter thinks about how little he sees his parents because they live in a different country
- Things that we take for granted when we’re young, like being close to our children or our grandchildren, aren’t guaranteed when we grow older
  - Peter jokes that Olivia signed a contract that says she can’t leave Austin, so this won’t be a problem for him

***A social support network and some sense of purpose might be the single most important part of the emotional health toolkit as it pertains to living longer***

- Every one of us knows the story of the couple that have been married for 70 years
  - One of them passes away, and then the other one dies within a year
  - Peter doesn’t think these are just anecdotal
  - There’s an understanding of why that happens

Olivia asks, “*So you can do everything right. You can eat the right diet, you can sleep right, you can exercise, but if your emotional health is lacking, then it’s like you won’t live as long?*”

- It’s possible
- Even more than that, regardless of how long you live, if it’s unhappy, why bother?
  - Let’s say you do live a long time, but you’re alone, or you’re miserable
  - In some ways, that would be the ultimate purgatory

## Why Peter decided to focus his work on longevity [33:45]

**Why did you decide to start focusing on longevity?**

- 1 – When Peter had kids (Olivia was his first), something about your mortality kicks in
- There are many stages to mortality ‒ having a kid is one, losing a parent is another
- As we gain and lose things throughout life, we become aware of its finitude
- The birth of Oliva was a moment where Peter was like, “*Huh, this is amazing. I’m not going to be around forever to be a part of her life.*”
- That got him thinking about longevity
- 2 – That coincided with Peter also coming to the realization that there are lots of things in his family history that might otherwise suggest a short life for himself
- So he wanted to get very serious about it

***Peter’s own journey into this space was actually very selfish and was strictly geared towards me figuring out things for himself***

## Protein intake recommendations should be based on ideal body weight (not current weight) [34:45]

**For the person who is overweight, should they eat 1 gram of protein per pound of ideal body weight (or actual weight)?**

- It depends on how overweight
- For example, if a person weighed 260 lbs and should weigh 200 lbs, Peter would agree with that assessment that eating closer to 200 grams of protein is probably fine

## The potential of klotho as a therapy for improving cognitive function and combating aging-related cognitive decline [35:30]

**Update on klotho**

- Last year, Peter had an amazing scientist on the podcast [[episode #303](https://peterattiamd.com/denadubal/)]
  - [Dena Dubal](https://neurograd.ucsf.edu/people/dena-dubal-md-phd) is a neurologist at the University of California, San Francisco
- She studies a protein called [klotho](https://en.wikipedia.org/wiki/Klotho_(biology))
- This is a protein that is made by the body
- It is made in response to exercise
- It’s made endogenously and declines with age for reasons we don’t understand
  - Children make 6x more of this than adults
- Any one of us can transiently increase it by exercising

**⇒** What’s special about this protein is it seems to be one of the most important proteins that protects the brain

- In both mice and monkeys, when you inject this protein, if these are animals that have signs of dementia or cognitive decline, it reverses
- If these are normal animals, they seem to get super cognitive powers

***Klotho is going to be tested over the next 3 years in humans, and if the results of that look promising, then a larger clinical trial will take place***

- The best-case scenario here would be that, in 7 to 10 years, this could be an actual drug that humans take either to prevent cognitive decline or to treat it

## The best types of protein supplements to consider [36:45]

- If it’s possible, whatever you can get from food is great
- For many people, especially for women, it’s really hard to mash through that much protein

**⇒** When it comes to foods, the 3 that stand out in terms of bioavailability the most are: dairy products, beef, and eggs

- There’s a quantitative way that you measure both the type of amino acid and the what’s called bioavailability of the amino acid
  - So how complete are the sources of amino acids?
  - And how readily can the body access them?
- You can get lots of amino acids in lots of other proteins
  - Peter is not saying don’t eat chicken or fish or vegetable proteins
  - But the big ones are dairy, beef, and eggs
- When you’re supplementing, [whey protein](https://en.wikipedia.org/wiki/Whey_protein) (which comes from dairy) tends to be the winner
- Now, [casein](https://en.wikipedia.org/wiki/Casein) is also great because it’s also from dairy

***Whey or casein probably stand out a little bit above, but so does egg protein supplement***

Peter adds, “*What I tell people to do is figure out what works best for you, because there’s some people that just can’t do dairy proteins*.”

- Remember, just because you can’t tolerate dairy doesn’t mean you can’t tolerate a dairy protein

**⇒** Most people who can’t tolerate dairy can’t tolerate the carbohydrate in the dairy [lactose], but they’re totally fine with the protein

- So give whey protein a try

## The APOE gene’s influence on Alzheimer’s disease risk, and why everyone should proactively address brain health, regardless of genetics [38:15]

**Genetic testing for the** ***APOE4*** **gene can identify a genotype associated with higher risk for Alzheimer’s disease**

*A member of the audience asks about a test they had done which showed they were not at high risk for Alzheimer’s disease*

- The [*APOE* gene](https://en.wikipedia.org/wiki/Apolipoprotein_E#) exists in 3 types: *APOE-ε2*, *APOE-ε3*, and *APOE-ε4* [often referred to as simply *APOE2, APOE3,* and *APOE4*]
- Every one of us has 2 copies of every gene, because you got one from your mom and one from your dad
- If there’s 3 types of a gene and there are 2 copies, there’s 6 combinations
  - We can go through them all: you could be a 2/2, you could be a 2/3, a 2/4, a 3/3, a 3/4, or a 4/4
- One of those types is higher risk than the other two, and that’s the *APOE4*

**⇒** People who have 2 copies of *APOE4* are at significantly higher risk for Alzheimer’s disease, about 10x higher risk

- Now, it doesn’t mean that they’re guaranteed to get it, but their risk is significantly higher

**⇒** People who have 1 copy of *APOE4* (typically a 3/4 genotype) are at about a 2x risk

- What the genetic test told you was you did not have a copy of the 4 gene (that’s the good news)
  - So you might be a 3/3
  - 60% of the population is a 3/3 [*APOE3/APOE3* genotype]

***The bad news is, it doesn’t mean you’re free of risk, because the only people who can’t get Alzheimer’s disease are people who don’t have brains ‒ everybody with a brain is at risk***

- Unfortunately, women are at almost twice the risk of men, and we don’t have a great understanding of why

**⇒** Areas where women are disproportionately affected compared to men: Alzheimer’s disease, osteoporosis, and falls

**⇒** Men have a higher risk of cardiovascular disease

- Peter is a 3/3, and the takeaway from him is to act as though he’s high risk

***Peter takes all the steps possible to prevent Alzheimer’s disease: exercise (being the single most important thing we can do to preserve brain health), managing nutrition, and sleep***

## How falls can accelerate cognitive decline, and the importance of staying physically and mentally active [40:45]

***Is there a relationship between having a fall and cognitive decline?***

*An audience member asked about her mom ‒ she fell and broke her hip, had a long, protracted recovery, managed to survive, but was never the same again and slipped into a state of cognitive decline*

- Peter’s intuition is there is a relationship there
- We don’t have the parallel universe experiment where we could see how she would’ve been had she never had that fall
- What we’re trying to understand is, is there any causality between the fall and her cognitive decline?
  - Peter’s intuition is that there is

***With that period of profound inactivity (probably not just physical inactivity but also some cognitive inactivity), it may have sped up cognitive decline (by a period of years)***

- Maybe this was something that would have ultimately happened, but now it happened sooner than it should have
  - It would be very difficult to prove that, but that’s what Peter’s intuition says

***This is another reason to think about all the things he’s talked about, as far as what are the steps we can take to minimize our risk of a fall***

---

## Selected Links / Related Material

**More content on**:

- [Cardiovascular disease](https://peterattiamd.com/category/heart-disease-prevention/)
- [Cancer](https://peterattiamd.com/category/cancer-prevention/)
- [Neurodegenerative diseases](https://peterattiamd.com/category/neurodegenerative-disease-prevention/)
- [Metabolic health](https://peterattiamd.com/category/metabolic-disease/)

**Discussion of type II muscle fibers**: [15:45]

- [#250 ‒ Training principles for longevity | Andy Galpin, Ph.D. (PART II)](https://peterattiamd.com/andygalpin2/) (April 10, 2023)
- [#239 ‒ The science of strength, muscle, and training for longevity | Andy Galpin, Ph.D. (PART I)](https://peterattiamd.com/andygalpin/) (January 23, 2023)

**Episode of** ***The Drive*** **with Belinda Beck**: [#322 – Bone health for life: building strong bones, preventing age-related loss, and reversing osteoporosis with evidence-based exercise | Belinda Beck, Ph.D.](https://peterattiamd.com/belindabeck/) (October 21, 2024)| [19:00]

**LIFTMOR study**: [19:00]

- [High-Intensity Resistance and Impact Training Improves Bone Mineral Density and Physical Function in Postmenopausal Women With Osteopenia and Osteoporosis: The LIFTMOR Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/28975661/) | *Journal of Bone and Mineral Research* (S Watson et al 2018)
- [Published erratum](https://pubmed.ncbi.nlm.nih.gov/30861219/) | *Journal of Bone and Mineral Research* (S Watson et al 2019)
- [High-intensity exercise did not cause vertebral fractures and improves thoracic kyphosis in postmenopausal women with low to very low bone mass: the LIFTMOR trial](https://pubmed.ncbi.nlm.nih.gov/30612163/) | *Osteoporosis International* (S Watson et al 2019)

**Video of women with osteoporosis weight training**: [Osteoporosis Sufferers Using Weight Training](https://youtu.be/2fx_LfZFxv0?si=OPX18yoki8Xarx9v) | YouTube (Physical Culture 2015) | [19:45]

**Peter’s book on longevity**: [Outlive: The Science and Art of Longevity](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.--JeJHXaTizre_2a8KUiq1QegfrPy8qjvM-fJrFyxpCIhUKt5gAD9EKSbP-3enXo5ANQ-wldMigVaH3dXR57QeNxBRHmVMC8UP8vYt3LhdgqfSnIpFoM8NnzufuElxp2b_09aR9dFc2ABA88RLhJjrGc8kAaw6aDX80PtiUMynmQE8tZKSynxCPgTMlxIiWJeLfkohugZRXj-i6RwouAb65tMf_vYUOlmVyheFnppF0.a3NLd2PidLOUfJng2unZxIQWpEqiW9NCZxXMdhafUVE&qid=1738765227&sr=8-1) by P Attia with B Gifford (2023) | [32:00]

**Episode of** ***The Drive*** **about klotho**: [#303 – A breakthrough in Alzheimer’s disease: the promising potential of klotho for brain health, cognitive decline, and as a therapeutic tool for Alzheimer’s disease | Dena Dubal, M.D., Ph.D.](https://peterattiamd.com/denadubal/) (May 27, 2024) | [35:15]

**Episodes of** ***The Drive*** **for older people starting to think about longevity**:

- [#307 ‒ Exercise for aging people: where to begin, and how to minimize risk while maximizing potential | Peter Attia, M.D.](https://peterattiamd.com/exerciseforagingpeople/) (June 24, 2024)
- [#311 ‒ Longevity 101: a foundational guide to Peter’s frameworks for longevity, and understanding CVD, cancer, neurodegenerative disease, nutrition, exercise, sleep, and more](https://peterattiamd.com/longevity101/) (July 29, 2024)

---

## People Mentioned

- [Belinda Beck](https://theboneclinic.com.au/our_team/prof-belinda-beck/) (Professor in the School of Health Sciences & Social Work and member of the Menzies Health Institute Queensland at Griffith University, Gold Coast campus; founder and director of [The Bone Clinic](https://theboneclinic.com.au/)) [19:00]
- [Dena Dubal](https://neurograd.ucsf.edu/people/dena-dubal-md-phd) (Associate Professor of Neurology at UCSF, expert in brain resilience in aging, neurodegenerative disease, and klotho) [35:30]

---