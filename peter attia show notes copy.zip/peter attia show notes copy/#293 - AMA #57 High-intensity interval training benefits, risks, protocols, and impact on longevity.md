# #293 – AMA #57: High-intensity interval training: benefits, risks, protocols, and impact on longevity

**Source:** [https://peterattiamd.com/ama57/](https://peterattiamd.com/ama57/)

---

In this “Ask Me Anything” (AMA) episode, Peter delves into the topic of high-intensity interval training (HIIT), starting with addressing some common misunderstandings around this type of exercise and breaking down what HIIT truly entails. He examines the correlation between HIIT and VO2 max, a vital metric for overall health and longevity, and describes the beneficial impact of HIIT on longevity when incorporated properly. Additionally, he emphasizes the importance of building a wide base of cardiovascular fitness, reveals the optimal protocols for incorporating HIIT into a balanced routine, and discusses the risk of injury and other potential drawbacks of HIIT.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #57 show notes page](https://peterattiamd.com/ama57). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Common questions about high-intensity interval training (HIIT) [1:30];
- The origins of HIIT [3:15];
- Defining HIIT training and differentiating it from sprint interval training (SIT) [5:45];
- Why HIIT is often touted as a more efficient way to exercise [14:00];
- Navigating the nuances of HIIT research: understanding limitations and the importance of a blended exercise routine [20:30];
- The four pillars of exercise [24:15];
- Using HIIT to improve VO2 max [26:00];
- HIIT training for the untrained individual: impact on VO2 max and the interplay between exercise-induced adaptations and potential weight loss [33:00];
- Sprint interval training (SIT) vs. HIIT: comparing the relative improvements in VO2 max and the impact of longer duration intervals [40:00];
- Benefits and limitations of HIIT, drawbacks of overtraining with HIIT, and the importance of a diversified routine to increase total cardiorespiratory capacity [44:15];
- HIIT protocols Peter recommends [58:45];
- The risk of injury and other potential drawbacks of HIIT [1:02:15];
- The importance of incorporating a balance of continuous moderate-intensity cardio and HIIT when aiming for longevity [1:04:00]; and
- More.

§

The Peter Attia Drive

High-intensity interval training: benefits, risks, protocols, and impact on longevity

§

## Show Notes

## Common questions about high-intensity interval training (HIIT) [1:30]

Today’s episode is going to be exercise-related, but on a topic that we get asked about a lot and we haven’t really covered, which is HIIT, or high-intensity interval training.

It’s something that people see everywhere, it’s marketed a lot, people talk about it, and so we see a lot of questions come through around people who are wondering more about it.

- What are the different types?
- How does interval training fit in?
- Where can it be used?
- Where is it limited?
- What’s the “best” protocol?
- We’ll also hopefully talk a lot about how someone can increase their VO2 max (which has a lot of importance for people who are thinking about their longevity)
- We’ll also talk about the importance of having a broad exercise program and training, and not just specifically focusing on one thing

*Anything you want to add before we hit the first question?*

- Peter says that this was a subject matter that he had been kicking down the road a little bit because he couldn’t wrap his head around the right way to present it
- But he feels like it has finally sort of come together in the last couple of weeks
- He’s glad they waited until they had the data and the right studies to look at
- And then, obviously, the implications so that we make this much more rooted in:
  - What do you need to do?
  - As opposed to making sure you understand every molecular pathway of HIIT.

## The origins of HIIT [3:15]

HIIT is such a commonly used word when people talk about exercise. ***Can you maybe set the stage of where it even comes from?***

- There is some documentation from as far back as the 1800s of athletes who would use a combination of running and walking for their training (runners or long-distance walkers)
- What it comes down to is some documentation of athletes having altered their tempo between running and walking for their training
- It wouldn’t really be until kind of the early 1900s that it would be codified more seriously
- You would originally go back to the Finnish Olympic runners that first employed this type of training
- The term [FARTLEK](https://www.raceatyourpace.co.uk/fartlek-training-for-beginners-everything-you-need-to-know-about-fartlek-training/#:~:text=Fartlek%20training%2C%20which%20translates%20to,and%20again%20with%20increased%20pace.), coined in the 1930s, is derived from the Swedish language which may translate to something like “speed play”
- When Peter was growing up, they referred to alternating between fast and slow as “speed play”

**Tabata**

- Another familiar term is Tabata training
- A Tabata interval is a very specific type of interval
- This was first described in the 1990s where a guy by the name of [Izumi Tabata](https://en.wikipedia.org/wiki/Izumi_Tabata) who was the first author on a [paper](https://journals.lww.com/acsm-msse/fulltext/1996/10000/effects_of_moderate_intensity_endurance_and.18.aspx) that first presented this
- Interestingly, though, the protocol seems to have been developed by Olympic speed skating coach Koichi Irisawa
- The interval was eight sets of 20 seconds on a bike, all-out interval with 10 seconds of rest, so you’re 20 seconds on, 10 seconds off, eight times, which gives you a four-minute duration

## Defining HIIT training and differentiating it from sprint interval training (SIT) [5:45]

**A lot of different programs, classes, gyms that call themselves HIIT training**

***Can you speak a little bit about what HIIT training actually is, and is there a way for people listening or watching to be able to differentiate between the different types or forms that they may see out there?***

- HIIT definitely has a bit of a brand issue, says Peter
- Part of the problem with everything we’re about to discuss today stems from the fact that there’s no uniform definition in what constitutes HIIT
- Peter suggests that we be a little bit more specific and we differentiate between, for example, high-intensity interval training, or HIIT, versus sprint interval training, or SIT, or things like Tabata training (which kind of are a bit of a subset of SIT)
- The reason for that is they produce very different metabolic effects, they’re carried out at very different intensities, and by extension, they have different pros and cons

**HIIT**

- Given that the majority of the literature is on what is called HIIT, we’re going to kind of start with that
- If you remember nothing else from this podcast, remember that when someone is talking to you about HIIT, ask them to stop using the language and just be specific:
  - What is the effort level?
  - What is the duration of work?
  - What is the duration of rest?
  - How often do I repeat it?
  - Etc.
- It’s really getting specific that’s going to be relevant, and obviously, that’s what we want to cover today

*Defining HIIT*

- HIITs are typically defined as submaximal efforts—generally 80 to 95% of a person’s maximum heart rate
- But that definition is not that helpful because, for example, when Peter does Zone 2, he’s doing it at 80% of his max heart rate, not because he’s targeting that, but because that’s the heart rate he ends up being at when he’s in Zone 2 (that’s clearly far from submaximal)
- Conversely, 95% of max heart rate is truly a huge effort and these efforts cover very different energy systems
- But again, the purpose of HIIT is generally to put you in your maximum aerobic training zone, but clearly the duration of the interval and the intensity will speak to how much anaerobic training you’re getting in there, as well

**Sprint Interval Training (SIT)**

- Sprint interval training is easier to understand because it is *supramaximal*, so these are efforts that would exceed the output of your VO2 max
- If you think about what VO2 max is… VO2 max is the maximal consumption of oxygen
  - This is typically performed at a very high level, but not a peak level, so an all-out 30-second sprint does not produce maximal O2 uptake — it’s typically going to need to be a duration that’s longer than that.
- Let’s just assume you have achieved the level of VO2 peak or VO2 max
  - You would then say, well, what was my power at that level or what was my speed at that level?
- And then **sprint interval training** is done at an effort that *exceeds that*, so it’s a higher power or a higher speed
- Now, here’s what’s interesting, it’s not necessarily a higher heart rate
  - The reason for that is that if you imagine what your heart rate is doing at a VO2 max, you’ve taken a while to get up to that speed or that power, whatever it is you’re using, and you’re holding it for a couple of minutes, it really gives your heart rate a chance to peak
- When Peter is doing VO2 max intervals on the bike, once a week, he’s almost hitting max heart rate by the end (probably within five beats of max heart rate)
- That’s actually a *higher* heart rate than if he’s doing 20-second all-outs on a Tabata
- The sprint interval protocols are typically 10-second, 20-second all-outs
- In fact, Peter thinks they’re defined as up to 60 seconds, however you can’t do anything “all-out” at nearly that duration
- You typically don’t get your heart rate as high, and so they’re typically pegged to a power level or a speed level that is in excess of your peak VO2 max

More about going “all out”

- There’s something very interesting that [previous podcast guest](https://peterattiamd.com/alexhutchinson/), [Alex Hutchinson](https://twitter.com/sweatscience?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor), wrote about in his book, [Endure](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866)
- He wrote that the only effort in which you can truly go “all-out” is an effort up to about 10 seconds
- if you’re doing anything over 10 seconds, you are consciously or subconsciously applying some governor to that activity that keeps you from absolutely blowing up
- Peter has found this true for himself personally: “*I can just tell you personally that there’s a very big difference in how hard I’m able to push when I do a 10-second on, 20-second off repeat versus a 20-second on, 20-second off. I’m very attentive to how much am I pushing without a limit, and anything above 10 seconds, I seem to be just holding back slightly, so keep that in the back of your mind when people talk about the term all-out. That’s a very misleading term*.”

**Max heart rate** – *How would people know their max heart rate?*

- Max heart rate is a pretty literal term — it’s the maximum achieved heart rate
- There are different ways to predict it
- The most simple formula that is generally used is the 220 minus your age formula
- So if you’re 50, your maximum heart rate would be expected to be 170 beats per minute [220-50=170]
- But the only way to really know it is to actually push yourself in submaximal efforts until you get to maximum heart rate
- This will be typically be seen if a person does a VO2 max test, and certainly will be seen if a person does a stress test if they’re pushed to failure
- Nevertheless, it is a good heart rate to know if you want to base any of your training on heart rate

## Why HIIT is often touted as a more efficient way to exercise [14:00]

**HIIT is often touted as a more efficient/effective way to exercise.** ***Why are people making that claim as it relates to HIIT?***

- There’s validity to that point, You just have to be thoughtful about what you’re defining as efficiency and what the objective is

Example: Say Peter asks you to run a mile in a workout, and you’re going to do this three times a week so your training volume is going to be three miles in a week done on three separate days

- Now we ask the question, well, what would be the most efficient way to run that three miles?
- Would it be more efficient for you to go out and do a nice, easy 10-minute mile pace three times a week?
- Would it be more efficient to run it in 50-meter bursts? –
- Would you run 400 meters all-out four times?
- There’s many different ways to do it, and clearly there are more efficient ways to do this, even though, by the way, they all produce about the same net total amount of energy expenditure
- It turns out that if we are looking at VO2 max as the metric we would care about most in terms of increasing maximum aerobic capacity, then your best bet would be doing that in intervals that are of about 400 meters to 800 meters of “all-out” effort
- When Peter says “all-out” from now on, he’s referring to maximum effort that you can hold for the duration, not your maximum without limit (A true all out maintain can only be held for 10 seconds)

From here, you might say, “I’m going to run four 400s”

- And let’s just assume you’re a reasonably fit person and you might run those in 90 seconds or 100 seconds each
- And then you would rest an equivalent amount of time and then repeat that
- The point here is if you did those intervals, you would get a far greater training effect than the person who just went out and did continuous running
- Then the question becomes, well, what if you don’t make it so extreme? What if you push the pace of the people that are doing it continuously versus the people who are doing it intermittently?

*Tangent on METs*

⇒ See [AMA #39](https://peterattiamd.com/ama39/) for more on METs

- One way to think about this is using something called metabolic equivalents (METs)
- A MET basically has a definition, which is that it is the energy expenditure of an individual sitting at rest
- Peter is utilizing one MET of energy per hour at rest
- One MET is equivalent to 3.5 milliliters per kilogram of oxygen consumption
- There is a 3.5 to 1 ratio of VO2 to MET
- If you’re exercising at 10 METs, you can be pretty confident that you are exercising at 35 times your body weight in milliliters per minute of oxygen, and therefore, one way to keep track of work is MET hours
- If you are exercising at 10 METs for 20 minutes three times a week, that would be 10 MET hours of training per week
- Many studies will try to categorize the training volume and somehow normalize it on METs
- Peter personally tends to think in kilojoules
- Anybody who’s using a cycling power meter will tend to use kilojoules because it’s the integrator of watts, and the watts are the power that you’re holding throughout time
- As you integrate watts over time, you get kilojoules
- If anybody listening to this hasn’t paid attention to their power meter at the end of a workout, you can always just toggle and say, “Well, how many kilojoules did I expend during that workout?”
- Peter finds it interesting in that sometimes he’ll do an interval workout that will have way higher peak levels of activity, but the total kilojoules might be comparable to a long Zone 2 ride

Let’s bring it back to the question: ***where do we see the efficiency gain?***

- If you look at most studies that are comparing HIIT to continuous training, the continuous training studies typically show a slightly lower improvement in overall fitness

This [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5790162/) was done in patients with metabolic syndrome and cardiovascular disease, compared RCTs that looked at HIIT to continuous training

- And if you look at all of the studies that looked at continuous training, they saw a VO2 max improvement that varied between 7 and 24%
- And the groups that were using HIIT saw an improvement between 15 and 32%.
- Takeaways:
  - The first is that you can you ever get a big improvement in VO2 max, especially if you’re untrained (These are typically like 12 weeks or 16 week studies)
  - Secondly, there’s clearly a trend towards a greater improvement in VO2 max in a well-controlled HIIT study
  - By well-controlled Peter means where your volume is not overloading or underloading.

## Navigating the nuances of HIIT research: understanding limitations and the importance of a blended exercise routine [20:30]

***Is there anything problematic that people should know when thinking about how to incorporate HIIT into their exercise programming?***

- There’s an inherent limitation to the research and that is that it is very rare that the dose of exercise is normalized between intervention arms
- It’s unclear on how to resolve that, but one way to do it would be not to resolve it based on time and maybe not even to resolve it based on METs or kilojoules, but to resolve it based on a combination of kilojoules, time, and intensity
- The metabolic demand of running all-out 400s is simply not comparable to the metabolic demand of jogging continuously, and to try to capture the similarities between them with just energy expenditure is not sufficient
- That said, it’s the best we have in the literature

By the way, anyone who’s used [TrainingPeaks](https://www.trainingpeaks.com/athlete-features/), which is a training software that cyclists use, will know that they probably do a better job of doing this with power data by incorporating average power, normalized power, where those stand in relation to your FTP, and then they’re calculating chronic stress scores, acute stress scores, and they’re trying to come up with much more clever ways to smooth the curve

- Example: Normalized power takes the fourth power difference between instantaneous power and average power and takes the fourth root of it, which means it’s really amplifying efforts that are above your average power, and that’s something that’s not going to get captured in just normalizing to energy expenditure

In the [largest of these review articles](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9104727/), they looked at 169 RCTs that compared HIIT to continuous training and 98 of those studies made an attempt to equilibrate the differences between

- In other words, most of them aren’t even attempting to do the simplest level of reconciliation
- 58 of those used kilojoules, again, total energy consumed
- 31 used total volume by time or distance
- And then 7 used RPE and 2 used duration and mean intensity

What we can say is the following:

- HIIT and SIT are clearly separate forms of exercise from continuous training, they induce totally different adaptations, and maybe trying to equalize them is not the most important question
  - It’s only important if you’re trying to be a purist in a zero-sum world where you are trying to ask the question should you be doing one or the other?
- “*What I hope to convince people of today is that’s the wrong question. The question ought to be how do I blend both continuous and interval training for the best outcome?*”

## The four pillars of exercise [24:15]

The four pillars:

- Stability
- Strength
- Aerobic efficiency (zone 2 output)
- Peak aerobic output (VO2 max)

Peter adds more context:

- “To be clear, that’s because I’m thinking about this through the lens of longevity. If I were thinking about this through the lens of performance, I would have to add many more layers.”
- “Notice I have not added a separate component to power. Power is very important and we do a lot of power training, although I kind of incorporate that into strength.”
- “Similarly, anaerobic output is very important in many sports. It’s less important in the grand arc of an aging person. And so from a cardio perspective, we instead focus on this maximum aerobic efficiency.”

Zone 2 and VO2 max

- The way we define Zone 2 is based on mitochondrial function, it is basically your place of maximum fat oxidation
- And then VO2 max is your peak aerobic output

⇒ See [AMA #55](https://peterattiamd.com/ama55/) for more on the four pillars

## Using HIIT to improve VO2 max [26:00]

***What would the best use for HIIT be in someone’s exercise programming?***

- HIIT, if done correctly, is going to be the most efficient way to increase your VO2 max
- This is not to say that you don’t increase your VO2 max by doing moderate-intensity continuous training
- If you took a group of relatively untrained individuals, tested their VO2 max, put them on a moderate-intensity continuous training program over a year, you would see their aerobic efficiency go up significantly and their maximum aerobic capacity, or VO2 max, go up modestly
- By the way, the same is going to be true of the reverse. We’ll come back to that.

**One of the best studies to look at this was a** [**study**](https://journals.lww.com/acsm-msse/fulltext/2007/04000/aerobic_high_intensity_intervals_improve_v_o2max.12.aspx) **published in 2007**

- It recruited 55 healthy, quite fit, moderately-trained male university students to a study, and randomized them into four groups and they trained with equal work, so again, this was normalized for total kilojoules
- For eight weeks, they trained as follows:
- Group 1: A long slow distance running group
  - These guys were just doing continuous running for 45 minutes per workout
  - They did this by heart rate, by the way, so they were at 70% of their maximum heart rate, so it was pretty easy (slightly below Zone 2 for most people)
- Group 2: The second group was put into a lactate threshold running group
  - These guys also did continuous running, but they did it at a higher intensity
  - They did it at 85% of their maximum heart rate, and they did it for almost 25 minutes per workout
  - So 85% of maximum heart rate, this would be above Zone 2 for most individuals, but it’s clearly far from all-out
- Group 3: 15/15 interval group
  - This was 15 seconds of very hard running and 15 seconds of active recovery, so basically walking
  - “Now, what I always find interesting about these studies is they try to provide a target heart rate and they say, “Well, the 15 seconds was done at 90 to 95% of maximum heart rate,” but anybody who’s done intervals that are below a minute will recognize you don’t have control over your heart rate.”
  - It’s different from the guys doing the long slow distance where they’re running for long enough, they can truly modulate effort to reach a certain heart rate
  - Same with the lactate threshold group
  - But if you’re doing 15 on, 15 off, you’re just kind of going for broke and your heart rate is going to be what it’s going to be
  - And then they were saying that the recovery was at 70% of max heart rate
  - Another thing to point out, your heart rate continues to rise after you stop
  - If you finish at 30 seconds, your heart rate is still going up, even if you stop and walk, and it won’t even begin to come down until about 10 seconds after, and it won’t rise again immediately when you start
- Group 4: 4 by 4 intervals (Peter’s favorite interval)—so four minutes on, four minutes off
  - And then the 4 by 4 group did four-minute intervals also at 90 to 95% of heart rate max
  - Here, Peter says he can trust that a little bit more because of the length of the interval, with the active recovery period being at about 70% of max heart rate

**Results**:

![](https://peterattiamd.com/wp-content/uploads/2024/03/f1-ama57.png)

**Figure 1.** Source: [Helgerud et al. Med Sci Sports Exerc. Apr 2007.](https://journals.lww.com/acsm-msse/fulltext/2007/04000/aerobic_high_intensity_intervals_improve_v_o2max.12.aspx)

- On the X-axis is the percent change from beginning to end at the end of eight weeks
- In the two parameters of interest, which were VO2 max, which we’ve defined, and stroke volume
  - Stroke volume is literally the amount or percent of blood that is ejected from the heart with each beat
  - Of course, stroke volume is measured in milliliters, whereas ejection fraction is corresponding to the percent of that and they’re comparable
- The two groups that reached statistical significance, meaning they had a statistically significant change in VO2 max and stroke volume, were just the two more intense groups
- Notice that the people doing the long slow distance had absolutely no change in performance over the eight weeks
  - If anything, it looks like they kind of went down a little bit
  - There was a trend towards going down, but it wasn’t significant
- The people doing the lactate threshold running, interestingly, you’d look like they were getting a little bit better, but it didn’t reach statistical significance
  - That could be a power issue… if you did this study with a large enough group of people, you would see statistical significance there, but it wouldn’t be big
- What you do see is in the 15 on, 15 off, you absolutely saw an increase in VO2 max
  - In fact, that group, the group doing the 15 on, 15 off, saw a increase in their VO2 max from about 60.5 to 64.4 mils per minute per kilogram
- The 4 by 4 group saw a slightly larger increase percentage-wise, going from 55.5 to 60.4
- These were fit people and they were looking at 5.5 to 7% increases in VO2 max in just two months, based on this type of training

## HIIT training for the untrained individual: impact on VO2 max and the interplay between exercise-induced adaptations and potential weight loss [33:00]

***What do we know about if someone went into this untrained, do we think they would have a similar change in VO2 max?***

- Intuitively, you would think that the less well-trained an individual is, the greater the training effect or benefit will be, and that’s sort of what you would take away from this [2014 meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3774727/) authored by [Mike Joyner](https://www.drmichaeljoyner.com/about/) ([previous guest](https://peterattiamd.com/mikejoyner/))
- It’s difficult to look at this meta-analysis as a single answer, and instead you kind of have to look at its parts and acknowledge that the results are quite disparate, and therefore you have to kind of go back and treat every study individually
- But what the meta-analysis does well is lay out the breadth of this
- It included 37 studies and it tried to exclude the absolute fittest people
- It looked at people aged 18 to 45, and it was hoping to find people who were untrained, kind of sedentary, all the way to recreational, and it just made a point to exclude people in basically the top 5% of VO2 max.
- The subjects had to be training at least three days a week for at least 6 to 13 weeks, and at least two, and preferably three, had to be interval training
- It did have a very clear definition of what constituted high-intensity interval training, and it had to be a work-to-recovery ratio of between 1-to-1 and 5-to-2, and those are obviously very different
- A 1-to-1 is like what we’ve been talking about, a four minutes on, four minutes off, whereas a 5-to-2 could literally be five minutes of work, two minutes of recovery
- Again, the devil’s in the details, but it really matters what that intensity is like.

![](https://peterattiamd.com/wp-content/uploads/2024/03/f2-ama57.png)

**Figure 2.** Source: [Bacon et al. PLoS One. Sept 2013.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3774727/)

- You saw a median improvement in all of these studies that worked out to be about 0.5 liters per minute in these untrained subjects
- Doing some back of the envelope math, making some assumptions about the average weight of these individuals, because notice this is giving you VO2 max in liters per minute, it’s not weight normalizing
- Because the way the studies were done, and based on starting VO2s, Peter would guesstimate that these people were seeing 10 to 15% improvements in their relative VO2 max.
- First off, that’s better than the people who we saw in the previous study, who were obviously trained
- One thing that jumps out to Peter: Why in the heck are some people all the way at one end??
- Some of these people had an improvement of one-and-a-quarter liters per minute—that’s a staggering increase
- That could easily be a 30% increase, if not a 35% increase, in VO2 max
- So we had to kind of understand what the heck was happening in that protocol—this was a brutal training protocol called the Hickson Protocol.

*About the Hickson Protocol*:

- Train six days a week
- Three of those days are going to be intervals where you are going to push at 90 to 100% of your VO2 max power, so it’s done on a bike
- Whatever you tested at the beginning of the study that was your VO2 max, you’re going to hold 90 to 100% of that power for five minutes, and then you’re going to rest two minutes, and then you’re going to repeat those intervals
- You’ll do that three days a week
- Then the best part is your three non-interval days are 40-minute time trials running, so you’re going to run as fast as you can for 40 minutes
- Not withstanding the difficulty of getting people to adhere to something like that, it clearly produced the best response in terms of VO2 max.

***What’s the big takeaway here?***

- Well, when you look at this distribution of improvement in VO2 max, what you tease out of it is the greater the improvement in the VO2 max, the longer the duration of the study and the longer the intervals of the study
- The more the intervals were closer to that four or five minute as opposed to one minute, the more you saw an increase in VO2 max.

**Exercise-induced adaptations and potential weight loss**

Nick asks, *Do you want to remind people, too, it’s a mix of, most likely if you’re untrained, you might be overnourished, and so as part of the training, you’re going to also lower your body weight, which also will increase your VO2 max?*

Because sometimes people think increasing VO2 max is just purely how much more of that oxygen you can produce, but *do you want to kind of remind people there’s those two aspects to it?*

- Yeah. In that last study, they didn’t take into account the weight loss, because they were only looking at the increase in VO2 max in liters per minute, but we almost always measure it in milliliters, so same thing, volume per weight per time
- If a person shows up and they weigh 90 kilos, and then their minute ventilation, their VO2 max, improves by 10% and their body weight comes down by 10%, they’re going to see probably a greater than 20% improvement in their relative VO2 max, which is the metric that matters.

## Sprint interval training (SIT) vs. HIIT: comparing the relative improvements in VO2 max and the impact of longer duration intervals [40:15]

***We talked earlier about SIT, sprint interval training. What is the most effective for improving VO2 max?***

- Sprint interval training is super, super, super high-intensity
  - We try to call that what an all-out is, although I’d argue anything over 10 seconds can’t be all-out
  - but these are kind of 10 to 60-second “all-outs” with more than 12 sets per workout, and a recovery period that’s typically 5x the duration
- This is not really even a Tabata
  - A Tabata is kind of a hybrid between this and a HIIT, because a Tabata is a 2-to-1 work-to-recovery, but it’s short, so it’s kind of confusing
- These are truly sprints, so you’d go out and do an all-out sprint for 15 seconds, you’d be resting for a minute-and-a-half
- Now at 15 seconds, what energy system are you using? ⇒ Well, it’s all creatine phosphate and anaerobic
  - So would you expect that that’s going to have an impact on VO2 max? … “I wouldn’t really.”

[Study](https://onlinelibrary.wiley.com/doi/full/10.1111/sms.14251)

- A study of 31 well-trained male runners, average age is 23, and average VO2 max was above 60 mils per kilogram per minute
- They put them on three interval training protocols.
  - One was basically just a standard HIIT protocol
  - And then two different sort of SIT protocols
- The HIIT protocol was the tried and true 4 by 4, so you’re running at 95% of your maximum aerobic speed, that means 95% of the speed, you run your VO2 max for four minutes, and then they were doing an active break in between
- Then you had one sprint protocol that was eight times 20 seconds at 150% of your maximum aerobic speed
  - Peter found this kind of interesting because this one was more of a sprint protocol that violated the rest phase
  - This was run like a Tabata, where they only took 10-second breaks.
- And then another SIT protocol was run at an even more intense level, which was 10 rounds of 30 seconds on at 175% of your maximum aerobic speed with three-and-a-half minutes off
  - This is a little bit more of a sprint because you have that longer recovery

*Results*:

- In the HIIT group, remember these are highly-trained individuals, the VO2 max improved by 6.5%
- But in the two SIT protocols, in the first one, it improved by 3.3%,
- And in the second one, which was the 10 rounds of 30 seconds all-out, but with long recovery, there was no change in VO2 max.
- What did they find improved it? ⇒ stroke volume
  - The stroke volume went up in the HIIT group by about 8%
  - and in the first sprint group, it went up at like 3.5%
  - Stroke volume didn’t go up in the second sprint group at all

Peter’s takeaways:

- “*I don’t think that’s surprising, and maybe some people who enjoy doing sprint workouts will be kind of upset to learn, oh my god, I’m not improving my VO2 max, but hey, guess what? You’re getting better at sprinting*.”
- The question becomes: What’s your objective?
- There’s a reason that, if you want to be really fast, you have to train really fast
- That’s why sprinters sprint and that’s why athletes who have to run really fast sprint, but we need to not confuse the stated objective of the energy system
- This just re-emphasizes the goal of the longer the duration or the closer that duration is to that sweet spot of what is generally in the 3-8 minute range, the better you’re going to be at increasing VO2 max

## Benefits and limitations of HIIT, drawbacks of overtraining with HIIT, and the importance of a diversified routine to increase total cardiorespiratory capacity [44:00]

***If someone prefers HIIT workouts, can they use it as their sole type of cardio workout, if they are agreeing that their goal with exercising is more for longevity?***

- Peter says that if the alternative is that they won’t do any cardio workouts at all, then he would be okay with just doing HIIT
- However, he would at least want to make sure they understand that they’re not training in the most effective way possible if their goal is to increase their total cardiorespiratory capacity, which is the thing that we want to do if we want to both live longer and ensure that as we age

**Importance of diversified routine**

Pyramid analogy (Peter also discusses the “pyramid” in this [episode](https://peterattiamd.com/rhondapatrick2/))

- If your aerobic efficiency, your Zone 2, is the base of the pyramid and your VO2 max is the peak of this pyramid…
- Then what you want is the biggest area of the triangle possible
  - We’re trying to maximize, the area of the triangle
- We don’t want a triangle that has a very, very, very, very wide base, but a teeny, tiny little peak, so that’s great aerobic capacity, no top-end aerobic gear
- Similarly, we don’t want a triangle that has kind of a narrow base and a higher peak
  - That would be kind of not particularly good aerobic base, but higher peak aerobic output
- If you look at athletes who have a very high VO2 max, they also have a very high aerobic base, and the total area of their triangle is huge
- The athletes who most require that high VO2 max, who most require that capacity for endurance longer than just a few minutes, are going to want to have a lot of base, and they’re going to typically spend more of their time in base
- Here’s the thing, those people might not have the highest VO2 max in the world
- If you think about it, the highest VO2 max in the world is usually recorded in endurance athletes
- You could make the case that it really belongs in an athlete whose sport is actually shorter, like someone who’s running a mile, someone who’s running two miles steeplechase, that kind of thing, because really, they don’t even have to train for the aerobic base piece
- But when you look at the amount of distance or time that those people put into running aerobic base, it’s much lower

> “*You want to broaden your portfolio of training.*” —Peter Attia

Caution against excessive HIIT

- This [study](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(21)00102-9?) sheds some light on what a lot of HIIT can do
- It evaluated 11 athletes, kind of modestly active people, reasonably fit, but not high level (six female, five male)
- It showed that HIIT had a benefit on mitochondrial function and glucose metabolism, but that an *excess* amount of HIIT could actually cause some detrimental effects on the mitochondria and glucose regulation

![](https://peterattiamd.com/wp-content/uploads/2024/03/f3-ama57-1024x487.png)

**Figure 3.** Source: [Flockhart et al. Cell Metab. May 2021.](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(21)00102-9?)

- The HIIT sessions were five intervals of four minutes at 95% of VO2 max power with three minutes of non-pedaling, so pure rest
- They were measuring heart rate, power output, VO2, CO2, et cetera, and they were also, of course, looking at all sorts of other variables
- They would alternate the workouts, so you would do five of those, or five of eight minutes at 90% of VO2 max with also three minutes of non-pedaling rest, so you were alternating between those two workouts
- Looking at the protocol: You have an intake week, so you do some pre-testing. That’s how they determine your VO2 max, get some baseline measurements
- They also do a muscle biopsy and get an OGTT
- Then you enter week one where you do light training, so you do two HIIT workouts that week.
- At the end of that week, you get another muscle biopsy and an OGTT
- Then you enter the modest training, or moderate training, week, where you do three HIIT workouts and you finish that week with another lovely muscle biopsy
- You then go into the excessive training week, which is five HIIT workouts, and you can see the alternating nature of them, which are the 5 by 4s versus the 5 by 8s, and then you do another muscle biopsy and OGTT
- And then you enter the recovery week, and this was actually longer than a week, but you do a recovery period where you do four workouts, and you close that out with a muscle biopsy and OGTT.
- What you can see on the figure is the total time spent at high-intensity per week (152 minutes)
- In the light training, it’s 36, then up to 90 (moderate), then 152 (excessive), then down to 53 (recovery)

*Confounders?*

- There are a lot of issues with this study that we should obviously just acknowledge and point out that can have some confounders
- Obviously, getting a muscle biopsy every week can alter performance a little bit. You could also argue that we’re not able to fully capture the effect that the order would have on this
- In an ideal world, you would do this with a large enough sample size that you can mix up the order in which people do these things so you can extract the training effect that’s going through the buildup
- In other words, what we don’t really know is how much of the excessive training is the issue of when it occurred in the training cycle?
- In other words, if you did that week first and then tapered from there, would you get a different result?
- It’s difficult when it’s in this order to know how much is the order versus the cumulative amount.

If you look at this graph below, you can see all the different VO2 max tests they underwent during this relatively short period of time:

![](https://peterattiamd.com/wp-content/uploads/2024/03/f4-ama57.png)

**Figure 4.** Source: [Flockhart et al. Cell Metab. May 2021.](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(21)00102-9?)

- At their baseline, they were just a little bit below 44 mils per kilogram per minute, and then you can see that that increased during the light training
- They did a couple tests during moderate, that’s where you really see that pickup
- And then during the excessive training week, it continued to go up
- And it even was up in the recovery week
- But interestingly, their maximum heart rate (or their training heart rate) which merely means the maximum achievable heart rate, went down by five beats per minute during the excessive training week, and then it recovered during the recovery week
- Peter finds that interesting because it’s good for people to understand the effect of that
- When your achieved heart rate is down by five beats per minute, that’s a general state of exhaustion
- But here’s what’s interesting: notice that VO2 max didn’t go down despite that
- What that tells us is that even though it wasn’t reported here, stroke volume must have gone up even more
- Clearly, stroke volume and heart rate are playing a role, but it appears that *more of the improvement in VO2 max here is coming from stroke volume*

**But let’s now talk about the downside here**:

- The downside is that mitochondrial respiration decreased by 40% after the excessive training week, compared to the moderate training week
- Now, these decreases in mitochondrial respiration were measured by isolating mitochondria from these muscle biopsies.
- They muscle biopsied the living crap out of these people… these are probably 16-gauge needle core biopsies
- They looked at respiration in mitochondrial complex I and complex 2
- Peter finds it super interesting how they’re doing these things, they use pyruvate, glutamate, malate, and other substrates to measure throughput
- But guess what? … Mitochondrial density went up, so individual mitochondrial respiration went down, mitochondrial density went up, and the net effect was actually positive
- It was *more* fat oxidation at submaximal effort, so at very low power outputs, to the tune of 100 watts, these people were actually oxidizing more fat.
- To be clear, when you only do low-intensity, proper low-intensity like Zone 2, you’re training Zone 2, but you’re getting some VO2 benefit
- When you do purely VO2, which these guys were doing, you mostly get that, but they also got some Zone 2 benefit
- When Peter says fat oxidation went up at 100 watts, he’s giving you the net effect of this, which was positive
- But the detail, again, is what’s super interesting: It came by *expanding mitochondrial density, and not by improving individual mitochondrial function*, which begs the question: *Can you have the best of both worlds? Can you both increase mitochondrial density and increase mitochondrial function?*
- Although there hasn’t been a study to demonstrate that, Peter would argue that this should be the null hypothesis of what would happen if you combine the right kind of training
- The “right kind of training” would be, directionally speaking, **three-quarters of the training at Zone 2, a quarter of that training at high-intensity interval training** (producing the VO2 max stimulus, i.e. in this four-minute range)

**Now let’s look at the OGTT data**:

![](https://peterattiamd.com/wp-content/uploads/2024/03/f5-ama57.png)

**Figure 5.** Source: [Flockhart et al. Cell Metab. May 2021.](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(21)00102-9?)

- Apologies for the units here: They’re doing glucose in millimole or millimole per liter, which is technically the number on the Y-axis you would multiply by about 19 to convert that into milligrams per deciliter, so round it up and call it 20
- These people are starting out with a beautiful, low glucose of about 80 milligrams per deciliter, they’re clearly very healthy, and you can see their OGTTs actually deteriorated over time
- Now, here’s what’s interesting, we’ve got to put this in context, none of these are pathologic OGTTs
- Even the worst OGTT, which is probably the one in the overload week, the excessive week, is probably the worst one by area under the curve, it’s still not pathologic
- But this was a little bit confusing to me that we saw excessive training inhibiting the performance of their glycolytic response, so their glycolytic response was blunted
- It’s possible that, given they had normal glycogen levels, that fatty acid metabolism could have impacted that
- “*I have to say, I’m a little surprised by this. I’d like to dig into this a little bit more, and I’m curious as to whether this is an artifact of the study, but given how glycolytically active these subjects were, I would have expected an improvement here*.”
- Peter might be more inclined to trust the results if it came out as a wash, but he was quite surprised that there was a slight deterioration.

*What’s the takeaway here?*

- You really want to be able to look at both of these modalities
- You’re absolutely going to optimize and maximize whole body fat oxidation with that sort of moderate-intensity continuous training
- And if you use Zone 2, what are you doing while you’re sort of stimulating the production of MCT transporters, so that’s monocarboxylate transporters, which are the transporters on cells that increase lactate clearance out of the cell
- Remember, lactate is a great fuel. You just don’t want it hanging around the cell too much, so anything that you can do that gets lactate out of the cell is a good thing, and one of the adaptations we see to training is an increase in MCT expression.

> “I would caution an individual against only doing high-intensity interval training. —Peter Attia

Another point worth making: These protocols in these studies are brutal

- And you could run into “burnout”
- Peter doesn’t think that most people would have the capacity to sustain this type of workout for long enough

> “Ultimately, if you can’t sustain the level of intensity for years, then it’s really not a longevity strategy. It could be a sport-specific strategy. But again, we’re not talking about that today. We’re talking about longevity.” —Peter Attia

## HIIT protocols Peter recommends [58:45]

***Is there a specific protocol, number of minutes on recovery, duration, number of times per week?***

***How are you utilizing HIIT with yourself and also with your patients in the practice?***

- It’s difficult to get your heart rate up high enough into a steady state using intervals below about two minutes and that’s why you’ve got to be north of three minutes
- 3 to 8 minutes appears to be the sweet spot
- Peter personally likes doing 4 to 5 minutes but he mixes it up and will sometimes go down to 2 sometimes or up to 8 minutes when he’s trying to work this energy system

A recent [meta-analysis](https://www.sciencedirect.com/science/article/abs/pii/S1440244018309198) of 53 studies

- This analysis found that only intervals that **exceeded** two minutes for 15 minutes of total work that were done at least 4 to 12 weeks showed benefits over continuous training, in terms of improving cardiovascular outcomes
- If someone came along and said, “I could only do one of these and I refuse to do much exercise, what should I do?”
- The answer is, if you have the intestinal fortitude to do intervals, do them the way we’ve described them here
- Do these 3-5 minute intervals and make sure you’re getting more than 15 minutes worth of total work in a week
- And make sure you’re doing this in perpetuity

Peter wants his patients doing:

- At least one day a week, doing somewhere between 3 and 8 minute intervals at approximately a 1-to-1 work-to-recovery ratio, and then work up the total duration
- When you’re starting out, it might be 15 minutes or 16 minutes of total duration, and if you get really, really, really fit, you might get up to doing 40 minutes of total duration.

*What about a person who is not exercising at all today, and wants to start. How would Peter advise them?*

- Peter does not like to start people with interval training until they have some aerobic base
- We have to build some muscular endurance in these people before we put them into the “pain cave”
- In that situation, which is not uncommon, Peter want them to build the habit around exercise and he doesn’t want it to be terribly unpleasant (just zone 2)
- He also doesn’t want them to be very data-driven in their Zone 2, he just wants them to learn what relative perceived exertion (RPE) feels like and just do their “zone 2” based on that
- At first, we might spend just six weeks doing that before we even begin to add intensity
- When we add intensity, we might initially just add it in the Zone 2 — e.g., how about at the end of your Zone 2 every day, you pick up the pace for the last three or four minutes until it’s really uncomfortable?

## The risk of injury and other potential drawbacks of HIIT [1:02:15]

***Are there any negatives that can come with HIIT that they should know about?***

- There are a lot of issues with purely circuit-based training, and although the focus of this AMA was talking mostly on the cardio side, everything we’ve said can really be applied to circuit strength training, i.e., moving really quickly, never resting, “go, go go”
- One has to be very mindful of those disadvantages: the increase in the risk of injury and the lack of mindfulness that exists with the exercise itself

Example: If you’re trying to be a better swimmer and you only practice kind of hard, all-out swimming, it’s very difficult to improve your swimming, because you’re not going to be able to pay attention to what you’re doing technically

- The same is true in cycling and running, but technique issues are just not as obvious
- Swimming would be the hardest of these endurance sports in terms of form, maybe skiing and rowing and then running, and cycling’s probably the least
- There are only so many degrees of freedom on the bike, but anyone can benefit from improving their technique, and that might involve improving respiratory strategies, relaxation, obviously, body position, and fluidity
- Those things are very difficult to do when you’re under duress
- In fact, that’s really a big part of why we want to use lower-intensity continuous training
  - It’s not just for the metabolic benefits, the fat oxidation, the improved mitochondrial respiration, it’s also to improve our technique and to make it more sustainable over a longer period of time.

## The importance of incorporating a balance of continuous moderate-intensity cardio and HIIT when aiming for longevity [1:04:00]

**Parting advice**:

- *Everything comes down to specificity*

- If you’re listening to this podcast and you’re an athlete and you’re training to run the 110-meter hurdles or something like that, well, discount everything Peter has said
- Just know what it is you’re training for and understand the specificity of the training tool for the desired outcome
- Everything we’ve talked about here is predicated on **living longer and living the best functional version of your life in that final decade**
- If that’s your goal, then you do need to do some amount of interval training

Then the question becomes what’s the balance of zone 2 and intervals?

- For most of us who live in a world where we’re time-constrained, it’s going to come down to probably **three-quarters of your cardio effort is at continuous moderate-intensity, and one-quarter of it must be at this kind of HIIT intensity**
- But if you don’t want to do that, if you just want to do lower-intensity, it’s much better than doing nothing
- And if you only want to do high-intensity, it’s much better than doing nothing

> “What I’m offering is if you do them both at approximately that ratio, you’re going to get the best overall outcomes, you will probably also reduce the risk of injury, and I believe increase the rate of enjoyment.” —Peter Attia

§

## Selected Links / Related Material

**Peter’s book that goes into detail on today’s topics**: [Outlive: The Science & Art of Longevity](https://peterattiamd.com/outlive/) by Peter Attia | (peterattiamd.com) [3:30]

**First paper on the Tabata protocol:** [Effects of moderate-intensity endurance and high-intensity intermittent training on anaerobic capacity and ˙VO2max](https://journals.lww.com/acsm-msse/fulltext/1996/10000/effects_of_moderate_intensity_endurance_and.18.aspx) (Tabata et al., 1996) [4:45]

**Episode of The Drive with Alex Hutchinson**: [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/) | Peter Attia (peterattiamd.com) [10:45]

**Book written by Alex Hutchinson**: [Endure: Mind, Body, and the Curiously Elastic Limits of Human Performance](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866) by Alex Hutchinson | (amazon.com) [10:45]

**AMA episode of The Drive that talks about metabolic equivalents (METs)**: [#223 – AMA #39: The Centenarian Decathlon, zone 2, VO2 max, and more](https://peterattiamd.com/ama39/) | Peter Attia (peterattiamd.com) [16:45]

**Meta analysis on HIIT vs. continuous training and impact on VO2 max**:  [High-intensity interval training versus moderate-intensity continuous training within cardiac rehabilitation: a systematic review and meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5790162/) (Hannan et al., 2018) [19:00]

**The largest review article comparing HIIT to continuous training**: [Exercise Dose Equalization in High-Intensity Interval Training: A Scoping Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9104727/) (Normand-Gravier et al., 2022) [22:45]

**One of the best studies showing the benefits of HIIT on VO2 max**: [Aerobic High-Intensity Intervals Improve VO2 max More Than Moderate Training](https://journals.lww.com/acsm-msse/fulltext/2007/04000/aerobic_high_intensity_intervals_improve_v_o2max.12.aspx) (Helgerud et al., 2007) [27:30]

**Study of HIIT training in a group of individuals that excluded the most fit people**: [VO2max Trainability and High Intensity Interval Training in Humans: A Meta-Analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3774727/) (Bacon et al., 2013) [33:30]

**Episode of The Drive with Mike Joyner**: [#217 ‒ Exercise, VO2 max, and longevity | Mike Joyner, M.D.](https://peterattiamd.com/mikejoyner/) | Peter Attia (peterattiamd.com) [33:45]

**Impact of different HIIT protocols on 31 well-trained male runners**: [Aerobic high-intensity intervals are superior to improve V̇O2max compared with sprint intervals in well-trained men](https://onlinelibrary.wiley.com/doi/full/10.1111/sms.14251) (Hov et al., 2022) [41:30]

**Study that sheds some light on how excessive HIIT has downsides**: [Excessive exercise training causes mitochondrial functional impairment and decreases glucose tolerance in healthy volunteers](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(21)00102-9?) (Flockhart et al., 2021) [48:00]

**A meta-analysis of 53 studies looking for the optimal interval protocol**: [Effects of different protocols of high intensity interval training for VO2max improvements in adults: A meta-analysis of randomised controlled trials](https://www.sciencedirect.com/science/article/abs/pii/S1440244018309198) ((Wen et al., 2019) [59:00]

§

## People Mentioned

- [Izumi Tabata](https://en.wikipedia.org/wiki/Izumi_Tabata) [4:45]
- [Alex Hutchinson](https://twitter.com/sweatscience?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [10:45]
- [Mike Joyner](https://www.drmichaeljoyner.com/about/) [33:30]

§