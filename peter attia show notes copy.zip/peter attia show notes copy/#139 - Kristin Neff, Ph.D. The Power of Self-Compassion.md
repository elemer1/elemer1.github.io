# #139 – Kristin Neff, Ph.D.: The Power of Self-Compassion

**Source:** [https://peterattiamd.com/kristin-neff-the-power-of-self-compassion/](https://peterattiamd.com/kristin-neff-the-power-of-self-compassion/)

---

Kristin Neff is a Professor of Educational Psychology at the University of Texas, author, and a leading expert on mindful self-compassion. In this episode, she shares how developing a self-compassion and mindfulness practice was the most effective tool for relieving her own suffering, and provides strategies and tactics to improve self-compassion and well-being.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/kristin-neff-the-power-of-self-compassion/the_Drive_public.png)

Play

#139 - Kristin Neff, Ph.D.: The power of self-compassion

1x15s30s

0:001:16:34

## We discuss:

- The life crisis that turned Kristin to mindfulness and self-compassion (3:30);
- How mindful self-compassion relieved Kristin’s feelings of self-judgement, and the psychology that says we all have the capacity for self-compassion (9:45);
- Peter’s history of self-criticism and his personal practice of self-compassion (17:15);
- The problem with prioritizing self-esteem over self-compassion, and how self-compassion produces a more stable version of self-worth (20:15);
- An argument for self-compassion over self-criticism for optimizing performance (26:15);
- How and when to introduce self-compassion to children (31:45);
- Learning her son had autism—a personal story of how Kristin used mindfulness and self-compassion (36:45);
- Self-compassion for cases of childhood trauma, PTSD, and overcoming a “fear of compassion” (44:00);
- The relationship between self-compassion and physical health (49:30);
- Distinguishing between self-compassion and self-pity, and the three necessary components self-compassion (52:30);
- Why self-criticism comes from a desire to be safe, the circular pattern of self-judgment, and self-compassion as the ultimate motivator (55:45);
- Potential role of a self-compassion practice for addiction and other maladaptive behaviors (58:45);
- Clinical applications and practical uses of self-compassion (1:01:30);
- Why you don’t need to meditate to learn mindfulness and self-compassion (1:04:45);
- Kristin’s personal meditation practice (1:08:40);
- Resources for learning self-compassion (1:11:45); and
- More.

§

## Show Notes

## The life crisis that turned Kristin to mindfulness and self-compassion [3:30]

**Studying cultural anthropology**

- Studied cultural anthropology at UC Berkeley under [Elliot Turiel](https://gse.berkeley.edu/elliot-turiel)
- She fell in love with the idea of thinking about how how culture impacts reasoning—Questions like:
  - How people balance concerns with autonomy and connectedness—how people balance concerns with self and other
  - How people used moral reasoning to resolve moral conflicts
- She did her dissertation research in India, a program called “Reasoning About Right to Responsibilities in the Context of Indian Family Life”
  - How gender-hierarchy, in a very traditional place like India, impacted how people resolved conflicts between their personal needs and their others’ needs
  - Turns out… you can’t really separate out power and gender and culture from the way people **think** about things—For example:
    - In India, they emphasize *duties* for wives and *rights* for husband, but the Indian women were still thinking, “*But that’s not fair. We’ll do it because we have to, but we don’t like it. It’s not fair*.”
    - The implication being: We aren’t totally dictated to by our culture, that we’re individuals who can reason despite embedded cultural norms

**Life falling apart**

- While in India, Kristin’s personal life began to unravel
- While in India, Kristin left her husband for another man — which caused internal conflict because “*I was a very moral person. I never, ever thought I would be in that situation*”
- But that relationship did not work out, and he ended up dying of brain cancer
- Furthermore, her first husband now hated her

> “I was a mess. I was feeling a lot of shame. It was very traumatic. I consider myself a very moral, honest person, and the fact that I got myself in that situation kind of was just really upsetting to me.”

**Decision to learn mindfulness meditation**

- The personal strife led Kristin down the path of learning meditation — she had heard it was good for stress and trauma
- “*I really needed something to help me deal with everything I’d been going through*.”
- She was always a spiritual person, (she’s read books like [Ram Dass’ Be Here Now](https://www.amazon.com/Be-Here-Now-Ram-Dass/dp/0517543052)), so she was naturally drawn to alternate ways of thinking about the world

*What drew her to a* ***mindfulness*** *form of meditation?*

- By happenstance, the Thích Nhất Hạnh Group—a group that followed the teachings of the Zen Master [Thích Nhất Hạnh](https://en.wikipedia.org/wiki/Th%C3%ADch_Nh%E1%BA%A5t_H%E1%BA%A1nh)—was right down the street from her
- She also thinks of Buddhism like a science of the mind, “*There’s not a lot of belief systems. You don’t have to believe in reincarnation. You don’t have to believe in a God or gods. Just basically a way of understanding the mind*.”

## How mindful self-compassion relieved Kristin’s feelings of self-judgement, and the psychology that says we all have the capacity for self-compassion [9:45]

**The immediate impact of self-compassion**

- [Thích Nhất Hạnh](https://en.wikipedia.org/wiki/Th%C3%ADch_Nh%E1%BA%A5t_H%E1%BA%A1nh) is one of the Buddhist teachers that emphasizes self-compassion
- The first night with the group, they discussed self-compassion
- “*It had an immediate impact on me. . .I had never even thought about being actively kind and supportive to myself*.”
- She began to speak to herself as if she was speaking to a friend who needed support
- An advantage to self-compassion, is that **it is much easier to learn compared to mindfulness meditation**, “*I got it almost immediately, but I did have to practice applying it to my life*.”

> “It really was like finding a superpower I didn’t even know I had. It was almost immediate, the impact it had on me.”

**Becoming aware of your subconscious self-critic**

- Peter asks Kristin about the process of first becoming aware of your subconscious critical voice: *Were you even aware at that point how degrading you could be to yourself? Or how demeaning you could be?*
- For Kristin personally, she wasn’t a particularly harsh self-critic — but she did have a lot of shame (it just wasn’t an entrenched trait)
- Many times, your inner critic can manifest in outward behaviors (e.g., depression, anxiety)
- For Kristin, that outward thing was a feeling of discombobulation, but not a deep depression

**How Buddhism helped her with the self judgment and self-concept thoughts**

- As Kristin continued her self-compassion practice, she began becoming more conscious of her thoughts around self-concept
- For example, she did this morally dishonest act of leaving her husband leading to thoughts like, “What does this mean about the type of person I am?”
- These negative self-identity thoughts were helped by Buddhism because **Buddhism is all about understanding this sense of self that causes suffering, this sense of identification with the separate self**
- As you go deeper into meditation, you can see more subtle layers of self-judgement, “*but it wasn’t necessary to get there before I could start to see the benefits of self-compassion*.”

> “A lot of people are just blown away by the simple thing of putting your hand on your heart and saying something kind and supportive to yourself.”

**Internal Family Systems—the psychology that believes self-compassion naturally exists in all of us**

- Kristin has used a type of therapy called [Internal Family Systems Therapy](https://ifs-institute.com/) for years
- The model by [Dick Schwartz](https://ifs-institute.com/about-us/richard-c-schwartz-phd) suggests that you have different parts of yourself that all kind of play a role
- Entrapped like a family, each part of you has a role—a few being:
  - Self-critical, feelings of shame.
  - Self defender, defends against the wounds of the shamed parts and maybe is really angry at others parts of the self
  - The different parts have a different function
  - However, the common, shared function amongst the parts is **safety/survival**
    - There’s a part that defends our ego as a form of survival.
    - There’s a part that defends against those feelings of shame
    - But there’s also a **compassionate part of ourselves**
- The compassionate part of ourselves:
  - The compassionate part of ourselves typically is exercised when we’re relating to others, people we care about (our children, friends, etc.)
  - The point is, we also have a compassionate part of ourselves so it’s not necessary to totally uncover all of the self-critical parts of ourselves before we can activate the self-compassionate part
  - It’s already there, and we’re already pretty familiar with it as it relates to *other people*
  - If you take that self-compassionate part and **aim it inward**, as opposed to outward, it almost immediately changes the landscape of the physiological as well as the mental landscape

> “It’s actually easier than you might think to help people get in touch with their compassionate self because for many, many people, that compassionate self is very, very well practiced. It’s an expert just aimed at others, so you don’t have to create something totally new that’s not there.”

## Peter’s history of self-criticism and his personal practice of self-compassion [17:15]

- Peter described himself as an “Olympic level self-critic”
- Peter’s friend [Ric Elias](https://redventures.com/about/leadership?modal=ric_elias) ([previous podcast guest](https://peterattiamd.com/ricelias)) suggested the following mental framework for when he is about to be self critical: “*I want you to picture that the same events occurred that are upsetting you, but now it wasn’t you that did it. It was one of your close friends that did it. How would you console him?”*
- It took Peter about 5 months before he found his groove
- When Peter underperforms at any number of activities (archery, for example), “the inner self-directed hatred is enormous and results in anger and tantrums and outbursts and feelings of total worthlessness when they don’t go well.”

*To combat this,* ***Peter’s daily practice of self-compassion*** *now includes the following*:

- First, he pulls out his phone and speaks into the audio recorder with a compassionate message to himself
  - Example: “*Hey, Peter, I know you just had a really bad day shooting and you couldn’t hit the broad side of a barn if your life depended on it, but it doesn’t mean you’re bad. It just means that you had a bad day at archery today, but you’re still a great Dad and you’re going to get another chance to come out here and do this tomorrow…*”
- Next, he sends the message to his therapist as a form of accountability
- The results have been amazing: “*It really was amazing how much it deescalated me. It was actually very quick. It used to be at the point where driving or shooting poorly could ruin my day, and it got to the point where within about three minutes, I had forgotten about it*.”

**Kristin’s takeaway**:

- That’s the power of self-compassion
- Peter had this quick positive result because he (like everyone) already had the skill of being compassionate to a friend developed
- Had Peter never had any experience in being compassionate and supportive to someone it would be much more challenging
- “*You just needed to access that part of yourself, which you weren’t accessing before*.”

## The problem with prioritizing self-esteem over self-compassion, and how self-compassion produces a more stable version of self-worth [20:15]

**Kristin’s pivot into studying self-concept**

- Studying Buddhism made her look closely at the whole idea of self-concept—*What is this thing we call self anyway?*
- She began to learn about how the sense of separate self and ego leads to suffering.
- At that point, Kristin pivoted away from moral reasoning and into understanding **how the development of our self-concept impacts things**

- She did her postdoc with [Susan Harter](https://portfolio.du.edu/SusanHarter), who studied self-concept development—
  - i.e., Your self-concept: Are you other-focused? Are you self-focused? Are you both?
  - Harter was also one of the country’s leading self-esteem researchers

**Why self-compassion is more important than self-esteem**

- Self esteem:
  - Harter’s research shows that self-esteem is not necessarily a good thing
  - It’s good to like yourself as opposed to hate yourself, but the ways we get our self-esteem can be very, very problematic—
    - A lot of social comparison
    - It’s also in many cases contingent, making it unstable
- Self-compassion:
  - Kristin began wondering what this self-esteem and ego really means and why do we invest so much in that we have to judge it positively and it can’t be negative at all?
  - From there, she began to study self-compassion, and her [research](https://self-compassion.org/wp-content/uploads/publications/NeffVonk.pdf) found it to be a lot more helpful than self-esteem

**Early days of self-esteem research**—*When did the idea of kids needing self-esteem become prominent?*

- If you actually look at the founding American psychology, [William James](https://en.wikipedia.org/wiki/William_James), he was writing in the early 1900s about [self-esteem](https://en.wikipedia.org/wiki/Self-esteem#History)
- What he *actually* identified was “**contingent”** self-esteem—
  - He defined self-esteem as perceptions of confidence in domains of importance.
  - That’s kind of the way self-esteem works, we need to be good at those things in life that we value
- Big tipping point in the push for kids to develop self-esteem:
  - Sociologist Morris Rosenberg developed the [Rosenberg Self-esteem scale](https://en.wikipedia.org/wiki/Rosenberg_self-esteem_scale)
  - People that scored higher on this scale were less depressed, less anxious, and happier
  - And this idea is true: People that have self-esteem have better mental health than people with low self-esteem

**\*The real problem with pushing self-esteem**:

- We tend to build self-esteem in a lot of unhealthy ways, e.g., like feeling better than others
- In many cases, for example, kids in middle schools start to bully others in order to feel good about themselves in comparison

**How self-compassion leads to unconditional self-esteem:**

- Peter asks: *How do we compare and contrast narcissism with self-esteem?*
- First of all, there’s nothing wrong with self-esteem—In fact, there’s a pretty strong correlation between self-compassion and self-esteem
- But the healthy form of self-esteem is what they call **unconditional self-esteem**—You feel worthy not because you’re good at something that you value, but simply because you’re a human being with an intrinsic sense of self-worth
- **Unconditional self-esteem (stability of self-worth) is what self-compassion gives you**—it doesn’t go up and down good day vs. a bad daya, because it’s less contingent on outcomes

*To summarize*: **There’s some discordance between self-esteem and self-compassion—A person with self-compassion generally has self-esteem, but not everybody with self-esteem has self-compassion.**

- For instance, if you have self-esteem *because you’re a narcissist*, you probably won’t have higher self-compassion (i.e., orthogonal relationship between narcissism and self-compassion)
- On the other hand, there is a moderate correlation between self-esteem and self-compassion

> “It’s not that self-esteem is bad. We want to feel worthy. It’s really why we feel worthy, how we feel worthy, that’s important.” —Kristin Neff

## An argument for self-compassion over self-criticism for optimizing performance [26:15]

**Downside of harsh self-criticism**

- Oftentimes, people criticize themselves harshly thinking it’s going to improve their performance.
- By the way, it does **kind of** work, (e.g., Many people have gotten through med school or law school through harsh self-criticism)
- But it works with a lot of negative side effects,
  - Example, **performance anxiety**: Knowing that if you don’t do well you’ve got the negative reinforcement of beating yourself up actually makes you more anxious, which **undermines your performance**
  - Another example, **feeling disconnected from others**: It can make you more disconnected from others if you’re really invested in doing better than other people, and that can lead to like little interpersonal behaviors that actually aren’t good at creating closeness and connection

**Self-compassion and** ***constructive*** **self-criticism works better**

- Constructive criticism in general is more effective than harsh criticism
- If you’re a professional archer, you want to do your best because that’s related to your happiness and well-being, *but what’s going to help you do your best?*
- It’s the **constructive criticism** that does best, “Okay. Well, here’s what didn’t work. You did it this way and it didn’t work. Why don’t we try it this way? I believe in you. You’ve got my support. I’m here for you.”

***Does self compassion reduce performance by giving up your edge?***

- What about someone who says, “I’m not willing to give up my edge in exchange for feeling better in the moment
- Kristin calls this question “ironic” because, studies continually show that it’s constructive criticism gives you more of an edge than *de*structive criticism

⇒ UC Berkeley study: [Self-Compassion Increases Self-Improvement Motivation](https://self-compassion.org/wp-content/uploads/publications/selfimp.motivation.pdf)

- UC Berkeley undergraduates were given an impossibly hard vocabulary test which they all failed
- They then split up the students into 3 groups
  - Group 1 was given instructions to be **self-compassionate** about the failure: “*It was a really hard test, try not to beat yourself up about it. Just try to be kind and supportive to yourself about failing this test*.”
  - Group 2 was given instructions to boost **self-esteem**: “*Don’t worry about it. You got into Berkeley. You know you’re smart*.”
  - Group 3 were given **no instructions**, which meant they were probably self-critical.
- **The finding**: People who are told to be self-compassionate about the failure **studied longer and harder** than the other two groups, and how long people studied was related to how well they did on the next exam.

**What happens when you’re** ***self-compassionate*** **about a failure…**

- When you’re self-compassionate about a failure, it allows you to learn more from the failure
- Failure is our best teacher, but if you’re full of shame and you’re just really mad at yourself, you don’t actually have the presence of mind to reflect objectively on what went wrong and how you can improve
- Self-compassion and support actually does give you that presence of mind to be able to learn from your experiences, i.e., the [growth mindset](https://en.wikipedia.org/wiki/Mindset#Fixed_and_Growth_Mindset)

> “Self-compassion leads to what they call ‘growth mindset’ where you actually learn from your mistakes, as opposed to a fixed mindset, which just means you think you’re stupid or smart, one or the other.”

## How and when to introduce self-compassion to children [31:45]

**Teaching self-compassion to children**

- Kristin recently developed a [scale for measuring self-compassion in children](https://self-compassion.org/wp-content/uploads/2020/02/SCS-Youth2020.pdf)
  - See all measurement scales [here](https://self-compassion.org/self-compassion-scales-for-researchers/)
- Kristin’s intuition is that around age seven or eight is when you can introduce the topic of self-compassion
- At that age, kids have learned about friendship, reciprocity, fairness, etc. and they can take the perspective of another.
- To be self-compassionate, you just have to take the perspective of another towards yourself
- Once kids reach adolescence, they will be better able to understand
  - you start getting meta cognition, you get more abstract thinking, it’s even more appropriate because that’s when really the self-concept formation starts kicking in — “What kind of person am I?”
  - ou can start having conversations with teenagers — “Do you really want your sense of self-worth contingent on being pretty enough or having people like you or being smart enough?”
  - Resource for teenagers: [The Self-Compassion Workbook for Teens: Mindfulness and Compassion Skills to Overcome Self-Criticism and Embrace Who You Are](https://www.amazon.com/Self-Compassion-Workbook-Teens-Mindfulness-Self-Criticism/dp/1626259844)

\*Numerous other [resources](https://self-compassion.org/resources-2/#books) on Kristin’s website

*Regarding younger kids*:

- The idea is that when they learn about friendship, you teach them they should also be **their own best friend**
- So when they learn about what it means to be a good friend, they should also learn to be a good friend to themselves

**A world of comparison with social media – problem for developing kids?**

- Peter worries about the long term impact of social media on kids, “K*ids are growing up in a world where* ***comparison*** *is at a level that you or I couldn’t imagine*.”
- Peter thinks that because of this, self-compassion is probably more important today than potentially it ever has been
- Kristin says that there may be two sides to that coin — In the past, you may only be exposed to limited perspectives, but now they can get the point of view so many diverse perspectives
- On the other hand, if you’re just looking at Instagram and followers, maybe not, “*I just don’t know what to think about it. It is a scary thought.”*

## Learning her son had autism—a personal story of how Kristin used mindfulness and self-compassion [36:45]

**Kristin personal experience with self-compassion**

*Kristin’s autistic son*

- Kristin’s son, Rowan, has [autism](https://en.wikipedia.org/wiki/Autism) (He is now 18 years old, and gaining lots of independence)
- Early on, Kristin could tell something was a bit off with her son
  - He was delayed in language development
  - He had [delayed pointing](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6794419/), which is one of the biggest indicators of some sort of delay
- But it was confusing because he was very social—the stereotype is that autistic kids are loving, or affectionate, or that they didn’t make eye contact—but that wasn’t him at all
- Once Kirstin realized that a lot of autists are extroverted and social, she realized it likely was indeed autistic

*When the diagnosis of autism finally came, how did you start to process that? How did your training in self-compassion serve you?*

- The first feeling, quite honestly, is one of **disappointment** of not getting the typical parent-child relationship
- She was overwhelmed, “It wasn’t the plan I had signed up for”

*The day after the diagnosis, she went on a meditation retreat*:

- **She allowed every single emotion to come up** — “*I didn’t say, “Okay, this emotion’s allowed and that emotion isn’t allowed.” I just let any emotion I had that come up, feelings of grief, feelings of disappointment, feelings of fear, and not only was I allowing myself to be with them without suppressing them or fighting them.*”
- **The thing that made the biggest difference..** “*I actively gave myself support. ‘This is really hard, Kristin. I know you’re disappointed. I know you’re frightened. It’s going to be okay. I’m here for you. I’m so sorry you’re struggling, but I care about you*.’”

⇒ See “[On Autism and Self-Compassion](https://www.thinkingautismguide.com/2010/07/on-autism-and-self-compassion.html)” written by Kristin

![](https://peterattiamd.com/wp-content/uploads/2020/11/neff-quote-neff-1024x688.png)

**Figure 1. Quote from Kristin Neff’s article, “On Autism and Self-Compassion”.** Credit: [On Autism and Self-Compassion](https://www.thinkingautismguide.com/2010/07/on-autism-and-self-compassion.html)

*What she found and over and over again…*

- “the more I could give myself compassion for my son’s autism, the better parent I was to him and the more I could accept him”
- “if I’d fought them and suppressed them or said, ‘I’m not supposed to feel this way,’ or, ‘I’m not going to allow myself to feel this way,’ I think it would have created a tension that would have actually made it more difficult to accept him for who he was.”

Kristin’s husband wrote a [best-selling book](https://www.amazon.com/Horse-Boy-Fathers-Quest-Heal-ebook/dp/B0023SDR02/ref=sr_1_3?dchild=1&keywords=the+horse+boy&sr=8-3) and together they made a [documentary](https://www.horseboymovie.com/Film.php) about it their story

- A magical moment happened in the documentary where Rowan for the first time said a complete sentence
- He was on a horse back and he said, “He’s a nice horse.”
- There’s some [research](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5083948/) that suggests on horses, when you continually have to find and re-find your balance, it influences the cerebellum, which helps brain integration

**More about autism**:

- One of the things that’s happening with autism is a lack of brain integration because overgrowth of white matter
- It’s hard to get cross-brain communication in autistic kids, which is one of the reasons you get kind of hyperspecialization and fixations
- Children with autism, obviously, can have remarkable outbursts—
  - They get overwhelmed, My son likes to tell me, “Autistic children, they don’t tantrum because they’re trying to get their way. We do it just because they get overwhelmed and it’s just a natural reaction, but they don’t do it to manipulate.”

## Self-compassion for cases of childhood trauma, PTSD, and overcoming a “fear of compassion” [44:00]

**There are two parts to the research on self-compassion and trauma:**

1. Early childhood trauma (e.g., sexual, emotional, physical abuse)
2. Trauma NOT caused during early childhood (e.g., PTSD in veterans)

**Early childhood trauma**

- This trauma hinders the ability to be self-compassionate as an adult mainly because of the [attachment system](https://en.wikipedia.org/wiki/Attachment_theory)
- If you have *secure* attachment, it means you think you are valuable and your needs are worth being met
- If you have *insecure* attachment, then you may not think that your needs are worthy of being met
- And if your parents were actually harshly critical or actually abusive, what can happen is the system that’s supposed to make you feel safe, the attachment system gets fused with feelings of fear because these people who are your only source of safety and comfort in life are also terrifying you.
- What happens for some people is it actually can be frightening to give themselves compassion (what [Paul Gilbert](https://en.wikipedia.org/wiki/Paul_Gilbert_(psychologist)) calls **fear of self-compassion**)
- Basically, when you’re activating the attachment system, which is supposed to make you feel safe, it actually makes you unsafe

*What to do about this?*

- **Self-compassion is one of the best ways to deal with early childhood trauma** because what you’re doing is you’re like reparenting yourself
- You need to intentionally give yourself compassion for those painful feelings of your past—feelings of shame for example—*How could I learn to relate to the pain of the trauma with some kindness?*
- You must learn how to hold the pain, any pain, with this kind, supportive stance
- Through self-compassion, you can potentially reach what’s called [Earned Secure Attachment](https://pubmed.ncbi.nlm.nih.gov/12146743/) as an adult
- \*Resource: [Compassion-Focused Therapy](https://en.wikipedia.org/wiki/Compassion-focused_therapy), created by [Paul Gilbert](https://en.wikipedia.org/wiki/Paul_Gilbert_(psychologist)), which is specifically designed for people with early trauma

**Treating trauma NOT caused during early childhood**

- Combat veterans are susceptible to PTSD
- This [study](https://onlinelibrary.wiley.com/doi/abs/10.1002/jts.21995) found that veterans who were more self-compassionate about what they’d experienced in combat were less likely to develop PTSD
- PTSD is when the trauma kind of almost gets locked in your body and you keep re-experiencing the trauma because you can’t process it
- Self-compassion towards the trauma helps you process it so it doesn’t get “locked into place”

*Is MDMA a molecule for self-compassion? [48:15]*

- Peter points to the the incredible success that the organization [MAPS](https://maps.org/) has had in testing MDMA in people with PTSD
- Peter calls MDMA “*the ultimate compassion molecule, so it basically takes a slight amount of compassion you might have and it just amplifies it tremendously*”
- Kristin’s input: Things like psychedelics, MDMA, and mushrooms, give you an experience of basically love and connectedness
- So one of the reasons probably that it works for PTSD is by increasing a little self-compassion and a sense of connectedness, and the two actually go hand in hand.

> “The three components of self-compassion are self-kindness, mindfulness, and common humanity, or kind of a sense of connectedness. The three really do go hand in hand. They operate as a system.”

## The relationship between self-compassion and physical health [49:30]

Emerging literature shows that self-compassion is [linked to better physical health](https://self-compassion.org/wp-content/uploads/2016/06/Dunne-et-al_2016.pdf)

- Self reports of colds, aches, pains, physical symptoms were decreased
- Also linked to [better immune function](https://self-compassion.org/wp-content/uploads/publications/BreinesImmunity.pdf)

Thoughts on why it’s linked to physical health:

- It likely operates through the nervous system
- For example: Kristin says that if you induce **all three** components of self-compassion—self-kindness, mindfulness, and common humanity/sense of connectedness—
  - it reduces sympathetic activity, [inflammation](https://pubmed.ncbi.nlm.nih.gov/24239953/), [cortisol levels](https://derby.openrepository.com/handle/10545/622861)
  - and also [increases heart rate variability](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5010618/) (which is the main marker we have of parasympathetic activity)
- Probably by changing the nervous system reaction that it influences physical health

**The mind-body connection**

- Peter [interviewed Robert Sapolsky](https://peterattiamd.com/robertsapolsky/) about his work on stress and its impact on physical health
- Longevity isn’t just living longer, it’s living **better**—
  - Peter says, “*That for me, I think, was the turning point in coming to accept the value of this was even if figuring out a way to become more* ***self-compassionate*** *didn’t make you live one day longer.*”

> “I think in the final analysis, quality of life matters more than length of life. But there’s no reason you can’t strive for both.” —Peter Attia

## Distinguishing between self-compassion and self-pity, and the three necessary components self-compassion [52:30]

Peter says one could easily misconstrue self-compassion for **self-pity**

***How does Kristin distinguish these?***

- We really need ALL three components self-compassion: 1) self-kindness, 2) mindfulness, and 3) common humanity/sense of connectedness

*If you just have self-kindness or self-love…*

- - It could be a self-focused state of “poor me” and feeling sorry for yourself

- *You need connectedness to others…*

- Pity feels condescending, whereas compassion is shared, “Hey, I’ve been there, man.” — and that is the whole difference between compassion and pity
- We need to include the sense of common humanity (aka interdependence or interbeing—like going beyond the separate self)
- You recognize that everyone’s imperfect, everyone leads an imperfect life—Suffering, failure, hardship, this is part of the **shared human condition**
- If you didn’t have that sense of connectedness in the experience of suffering, it may turn into self-pity

The case for mindfulness…

- Self-pity isn’t very mindful
- Self-pity tends to exaggerate and to catastrophize, “*Poor me, this is like the worst thing ever*,” and very self-focused.
- Mindfulness has more equanimity, it’s more of a balanced state of mind — seeing things as they are
- On the one hand, ignoring difficult situation and feeling isn’t helpful
- On the other hand, catastrophizing doesn’t help either
- The mindfulness component partly comes from the inherent perspective that comes from self-compassion

“*We are used to giving compassion to others. Whenever we give ourselves compassion, there’s like an inherent sense of perspective there because we’re treating ourselves as we would treat another. We aren’t lost in our drama, we’re like stepping outside of ourselves, and that perspective, it’s not exactly the same as mindfulness, but they’re very related, and actually gives us more perspective and balance in terms of how we relate to our own situation*.”

**The upshot**:

- All three need to be there to be self-compassionate and to avoid “*self-pity*”
- If you look at psychometric analyses at the [Self-Compassion Scale](https://self-compassion.org/wp-content/uploads/publications/empirical.article.pdf), they all operate as a system, all three change simultaneously, so they really do operate as a system

## Why self-criticism comes from a desire to be safe, the circular pattern of self-judgment, and self-compassion as the ultimate motivator [55:45]

**The circular pattern of self-judgment:**

- - Particularly harsh self-critics (like Peter) may find themselves being judgemental of their inability to stop being self-critical — a circular pattern of self-judgment
  - Kristin calls it, “*Beating yourself up for beating yourself up.*”
  - Peter asks, *What advice do you have for folks who want to begin this practice to pull themselves out of that spiral?*

- *Kristin says, “it’s really helpful to know why we criticize ourselves…* ***because we care****.”*

**Self criticism comes from a desire to be safe**

The reason we criticize ourselves is because…

- we want to be well
- we want to do our best
- we want to be safe
- we want people to love us and to support us
- we’re afraid that bad things are going to happen to us if we don’t do well, and good things are going to happen to us if we do do well

> “We don’t need to beat ourselves up for beating ourselves up. You need to have compassion for the reasons we beat ourselves up, which comes from a very natural desire to be safe.” —Kristin Neff

**Self-compassionate motivation**

- You want to help people move from motivating themselves with criticism to a more constructive criticism, more compassionate motivation
- If you skip the step of having compassion and inner gratitude to our inner critic for trying to keep ourselves safe, *it actually doesn’t work*
- Why it doesn’t work is because that self-critical part of ourselves is really scared for its life so it’s not really a rational part, it’s operating with emotion
- So if you just tell that inner critic to “shut up”, it’s going to shout even louder, “Life’s going to end and you aren’t listening to me. Listen, listen, listen. Life’s going to end!”
- Alternatively, we can listen to it and say, “Hey, okay. I see you’re worried about my safety. Thank you so much. I hear you. Trust me, I’ll do everything I can to keep myself safe.”
- Once you do that, then it’s much easier for the more compassionate part of ourselves to try to motivate a change
- In contrast to the self-critic, the self compassionate version of ourselves also wants to keep us safe, do our best, and change unhealthy behaviors, **but does it not because it’s afraid that we’ll be inadequate, but just because it cares. It’s a much more effective and sustainable voice of motivation.**

## Potential role of a self-compassion practice for addiction and other maladaptive behaviors [58:45]

Is there any evidence that we could use self-compassion as a tool to treat maladaptive behaviors like gambling and substance addiction?

- Not much research on self-compassion and addiction
- Cross-sectional research that shows they’re negatively correlated but we don’t know causality in that case
- Some research suggests that when [AA](https://en.wikipedia.org/wiki/Alcoholics_Anonymous) is successful, one of the reasons it may be successful is because it increases self-compassion

In terms of the two-way causality…

- For instance, if you’re really addicted, it may make it harder for you to be self-compassionate
- Once you come off the substance, it may be easier to be more self-compassionate
- So all of these things are almost kind of bidirectional.

## Clinical applications and practical uses of self-compassion [1:01:30]

Researching the efficacy of self-compassion practice in clinical settings

- Kristin has developed The [Mindful Self Compassion Training Program](https://centerformsc.org/train-msc/) — which actually isn’t designed for clinical populations but can be adapted for clinical populations
  - There’s also [compassion-focused therapy](https://en.wikipedia.org/wiki/Compassion-focused_therapy) developed by Paul Gilbert, which is similar that is designed for clinical populations
- We definitely have the tools in place right now to do the research, says Kristin
- The quickest way to see added value of self-compassion is combining it with pre existing interventions that we know work
- But there’s more tools than just self-compassion, such as *mindfulness interventions*
- As a byproduct, mindfulness training (not necessarily mindfulness **meditation**) naturally increases self-compassion

⇒ Example of using a mindful, self-compassion practice in real life:

- If something upsetting happens at the grocery store, it’s unlikely you are going to sit down and meditation, however, you can put your hand on your heart and say something supportive to yourself
- It’s very portable, it’s very scalable, and also the research shows it doesn’t require meditation to learn it, making it more accessible to a lot more people
- “*I love meditation, but it’s just that a lot of people aren’t going to meditate. That’s just the reality*”

> “I personally think if we started looking at just adding explicit self-compassion into these [existing interventions that work] to strengthen it, I suspect you would find it does.” —Kristin Neff

## Why you don’t need to meditate to learn mindfulness and self-compassion [1:04:45]

**Differentiating ‘mindfulness’ from ‘mindfulness-based meditation’**

- Peter makes the mistake of confusing “mindfulness” with “mindfulness meditation”
- Kristin clarifies:
  - Mindfulness is a necessary component of self-compassion
  - Mindfulness-based meditation, while great, is NOT a necessary component of self-compassion
- You don’t need to meditate to be mindful, says Kristin
- That said, meditation is probably the most tried and true way to increase mindfulness, and *most* mindfulness training programs base their techniques on meditation
- But being mindful is just kind of being aware—whenever you’re aware that you’re suffering, for example, you’re being mindful of your suffering
- So you can’t have self-compassion without some degree of mindfulness

A [randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/23070875/) of The Mindful Self-Compassion Program

- They found that mindfulness practice was linked to gains in self-compassion
- But it didn’t matter whether the practice was sitting down and doing self-compassion meditations or if it was just simple things like taking a self-compassion break in the middle of your day
  - Things like, when you notice you’re suffering, giving yourself kindness and support [like you would to a good friend](https://self-compassion.org/exercise-1-treat-friend/)

*On learning mindfulness without meditation*: You can learn mindfulness *without* meditation—it’s just a little trickier because mindfulness is kind of vague and abstract—so meditation helps

**The practical and scalable nature of self-compassion practice**

- Meditation is good and proven to work, it can change your neuronal pathways
- Kristin believes in meditation, and practices daily
- That said, she calls it “a little unfortunate” that so much emphasis has been placed on meditation because not everyone’s going to meditate
- Kristin calls self-compassion practice is more *scalable*

⇒ A RCT applying self-compassion training in healthcare workers: [Caring for Others without Losing Yourself: An Adaptation of the Mindful SelfCompassion Program for Healthcare Communities](https://self-compassion.org/wp-content/uploads/2020/06/Neff2020d.pdf)

- Kristin did a 6-week training program for healthcare workers working at a pediatric hospital
- They attended a training session lasting 1 hours per day during lunch
- The tools they were given were:
  - 1) some informal mindfulness practices like feel the soles of your feet and then come back to the present moment, and
  - 2) the “[self-compassion break](https://self-compassion.org/exercise-2-self-compassion-break/)”: put your hand on your heart and help people develop phrases that work for them to remind them of the three components of self-compassion
  - \*Note: there was no requirement to meditate
- They also instructed the workers to engage in self-compassion practice on the job the moment they notice a feeling of stress or sadness or have something difficult happens
- **Conclusions**:
  - Findings suggest that the SCHC program may be an effective way to increase self-compassion, enhance wellbeing and reduce burnout for healthcare professionals.
  - And a number of the workers decided to “*take the full program and learn how to meditate*”

> “I think there’s a lot of blocks to meditation that aren’t there with self-compassion.”

## Kristin’s personal meditation practice [1:08:40]

Kristin’s meditation practice

- Kristin has been on 40 meditation retreats
- She meditates daily

- She prefers to meditate while in bed (early morning or late at night)
- She admits that sometimes she falls asleep, so it may not be as “good” as doing it on a cushion while note sleepy — “*but at least I do it*”

Describing meditation:

- She describes meditation as a really focused time where aren’t doing anything else, you’re just reducing sensory input
- It’s helpful because when you meditate is you get into a certain brain state—your [default mode network](https://en.wikipedia.org/wiki/Default_mode_network) (DMN) quiets
  - It’s easier for you to see clearly,
  - It’s easier for you to pay attention.
  - There’s less chatter in the brain, *and that’s very helpful*

“*Meditation is great, but I just don’t want people to think that unless they meditate they can’t learn the skill of self-compassion and mindfulness*.”

⇒ For instance, [one study](https://www.tandfonline.com/doi/abs/10.1080/17439760.2010.516763?journalCode=rpos20) had people write a compassionate letter to themselves once a day for seven days and it reduced depression for three months and increased happiness for six months

## Resources for learning self-compassion [1:11:45]

*Kristin’s website*: [self-compassion.org](https://self-compassion.org/)

*8-week training program guided by professionals*: [The Mindful Self-Compassion Program](https://centerformsc.org/train-msc/)  (Co-developed with [Chris Germer](https://chrisgermer.com/about-chris-germer/) at [The Center for Mindful Self-Compassion](https://centerformsc.org/))

*A self-guided workbook (based on the program)*: [The Mindful Self-Compassion Workbook: A Proven Way to Accept Yourself, Build Inner Strength, and Thrive](https://www.amazon.com/Mindful-Self-Compassion-Workbook-Yourself-Strength/dp/1462526780)

*A teacher training course*: [Teaching the Mindful Self-Compassion Program: A Guide for Professionals](https://self-compassion.org/teaching-the-mindful-self-compassion-program-a-guide-for-professionals/)

**Other resources**:

*Self-compassion exercises, meditations, tips, and more:* [Self-Compassion Guided Meditations and Exercises](https://self-compassion.org/category/exercises/)

*Kristin’s first book (free on Kindle)*: [Self-Compassion: The Proven Power of Being Kind to Yourself](https://www.amazon.com/Self-Compassion-Proven-Power-Being-Yourself-ebook/dp/B004JN1DBO/ref=sr_1_2?crid=JJGQE8OEL873&dchild=1&keywords=self-compassion+by+kristin+neff&s=books&sprefix=self-compassion+by+%2Cstripbooks%2C175&sr=1-2)

*Chris Germer’s book*: [The Mindful Path to Self-Compassion](https://www.amazon.com/Mindful-Path-Self-Compassion-Yourself-Destructive/dp/1593859759)

\*Full list of resources found [here](https://self-compassion.org/resources-2/)

§

## Selected Links / Related Material

**Kristin’s book**: [Self-Compassion: The Proven Power of Being Kind to Yourself](https://www.amazon.com/Self-Compassion-Proven-Power-Being-Yourself/dp/0061733520) by Kristin Neff | (amazon.com) [0:45, 6:15,  1:13:00]

- Free on [Kindle](https://www.amazon.com/Self-Compassion-Proven-Power-Being-Yourself-ebook/dp/B004JN1DBO/ref=tmm_kin_swatch_0?_encoding=UTF8&qid=&sr=)

**Kristin’s website**: [self-compassion.org](https://self-compassion.org/)

**Kristin’s 8-week training program**: [The Mindful Self-Compassion Program](https://centerformsc.org/train-msc/) | (centerformsc.org) [1:00, 1:02:15, 1:13:00]

**Spiritual book that Kristin’s mom had when Kristin was a kid**: [Be Here Now](https://www.amazon.com/Be-Here-Now-Ram-Dass/dp/0517543052) by Ram Dass | (amazon.com) [8:15]

**The psychology by Dick Schwartz that believes we each have different parts of ourselves naturally within, including self-compassion**: [Internal Family Systems Therapy](https://ifs-institute.com/) | (ifs-institute.com) [14:30, 58:45]

**Episode of The Drive with Ric Elias (who helped Peter with self-compassion by suggesting to talk to yourself like you talk to a friend)**: [#79 – Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/) | Peter Attia (peterattiamd.com) 17:30]

**Research that suggests self-compassion is more helpful than self-esteem**: [Self-Compassion Versus Global Self-Esteem: Two Different Ways of Relating to Oneself](https://self-compassion.org/wp-content/uploads/publications/NeffVonk.pdf) (Neff and Vonk, 2009) [21:45]

**Self-esteem scale developed by sociologist Morris Rosenberg**: [Rosenberg self-esteem scale](https://en.wikipedia.org/wiki/Rosenberg_self-esteem_scale) | (wikipedia.org) [23:15]

**UC Berkeley study with undergraduates taking a difficult vocabulary test and then re-testing them after giving them self-compassion practice**: [Self-Compassion Increases Self-Improvement Motivation](https://self-compassion.org/wp-content/uploads/publications/selfimp.motivation.pdf) (Breines and Chen, 2012) [29:00]

**Self-compassion leads to what they call growth mindset**: [31:30]

- *Kristin describes this in chapter 8 of her book*: [Self-Compassion: The Proven Power of Being Kind to Yourself](https://www.amazon.com/Self-Compassion-Proven-Power-Being-Yourself-ebook/dp/B004JN1DBO/ref=sr_1_3?crid=3LZFDTUZD6L6C&dchild=1&keywords=self-compassion+by+kristin+neff&qid=1605730822&sprefix=self-compassion+%2Caps%2C244&sr=8-3) by Kristin Neff | (amazon.com)
- *Blog post about it*: [Self-Compassion and The Growth Mindset: A Potent Combination!](https://milisaburns.com/self-compassion-and-the-growth-mindset-a-potent-combination/) | Milisa Burns (milisaburns.com)
- Wikipedia page for mindset: [Fixed and Growth Mindset](https://en.wikipedia.org/wiki/Mindset#Fixed_and_Growth_Mindset) | (wikipedia.org)
- Carol Dweck’s book about mindset: [Mindset: The New Psychology of Success](https://www.amazon.com/Mindset-Psychology-Carol-S-Dweck/dp/0345472322/ref=sr_1_3?crid=27P09RDGE5L16&dchild=1&keywords=mindset+carol+s.+dweck&qid=1605730711&sprefix=mindset+c%2Caps%2C236&sr=8-3) by Carol S. Dweck | (amazon.com)

**A scale that can be used to measure self-compassion in children**: [Self-Compassion Scale for Youth (SCS-Y)](https://self-compassion.org/wp-content/uploads/2020/02/SCS-Youth2020.pdf) | (self-compassion.org) [32:00]

- See all measurement scales [here](https://self-compassion.org/self-compassion-scales-for-researchers/)

**Book recommendations on Kristin’s website**: [Resources: Recommended Reading](https://self-compassion.org/resources-2/#books) | (self-compassion.org) [33:00]

**Self-compassion resource for teenagers**: [The Self-Compassion Workbook for Teens: Mindfulness and Compassion Skills to Overcome Self-Criticism and Embrace Who You Are](https://www.amazon.com/Self-Compassion-Workbook-Teens-Mindfulness-Self-Criticism/dp/1626259844) by Karen Bluth, Ph.D. | (amazon.com) [33:00]

**Delayed pointing is one of the biggest indicators of some sort of language delay/autism**: [Low Rates of Pointing in 18-Month-Olds at Risk for Autism Spectrum Disorder and Extremely Preterm Infants: A Common Index of Language Delay?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6794419/) (Sansavini et al., 2019) [38:00]

**Book by Kristin’s husband about their experience raising their autistic son**: [The Horse Boy: A Father’s Quest to Heal His Son](https://www.amazon.com/Horse-Boy-Fathers-Quest-Heal-ebook/dp/B0023SDR02/ref=sr_1_3?dchild=1&keywords=the+horse+boy&sr=8-3) by Rupert Isaacson | (amazon.com) [41:00]

**Documentary by Kristin about her autistic son**: [The Horse Boy](https://www.horseboymovie.com/Film.php) | (horseboymovie.com) [41:00]

**Research suggesting that riding on horses helps with brain integration partly due to having to continually find and refind your balance**: [The Effects of Equine-assisted Activities and Therapy on Resting-state Brain Function in Attention-deficit/Hyperactivity Disorder: A Pilot Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5083948/) (Hyun Yoo et al., 2016) [42:30]

**Research showing you can get “Earned Secure Attachment” as an adult**: [Earned-secure attachment status in retrospect and prospect](https://pubmed.ncbi.nlm.nih.gov/12146743/) (Roisman et al., 2002) [46:30]

- *Slideshow explaining how to earn it*: [Earned-secure Attachment: Helping Clients Rewire their Brains through Creating a Coherent Narrative](https://cdn.ymaws.com/www.cpapsych.org/resource/resmgr/convention/2018/handouts_2018/Firestone_-_Attachment_Hando.pdf) | (cpapsych.org)

**Compassion-Focused Therapy, created by Paul Gilbert, which is specifically designed for people with early trauma**: [Compassion-Focused Therapy](https://en.wikipedia.org/wiki/Compassion-focused_therapy) | (wikipedia.org) [47:00, 1:02:15]

**Study finding that veterans who were more self-compassionate about what they’d experienced in combat were less likely to develop PTSD**: [Self‐Compassion as a Prospective Predictor of PTSD Symptom Severity Among Trauma‐Exposed U.S. Iraq and Afghanistan War Veterans](https://onlinelibrary.wiley.com/doi/abs/10.1002/jts.21995) (Hiraoka et al., 2015) [47:30]

**Organization that is working to get psychedelics (e.g., MDMA) approved as a treatment for PTSD**: [MAPS](https://maps.org/)  | (maps.org) [48:00]

**Emerging literature that shows that self-compassion is linked to better physical health**: [Brief report: Self-compassion, physical health and the mediating role of health-promoting behaviours](https://self-compassion.org/wp-content/uploads/2016/06/Dunne-et-al_2016.pdf) (Dunne et al., 2016) [49:30]

**If you induce all three components of self-compassion—self-kindness, mindfulness, and common humanity/sense of connectedness:** [50:00]

- It reduces sympathetic activity like inflammation ([Breines et al., 2014](https://pubmed.ncbi.nlm.nih.gov/24239953/)) and cortisol levels ([Rockliff et al., 2008](https://derby.openrepository.com/handle/10545/622861))
- And increases heart rate variability ([Svendsen et al., 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5010618/))

**Self-compassion is linked to better immune function**: [Self-compassion as a predictor of interleukin-6 response to acute psychosocial stress](https://self-compassion.org/wp-content/uploads/publications/BreinesImmunity.pdf) (Breines et al., 2013) [50:45]

**Episode of The Drive with Bob Sapolsky who describes how stress can affect the brain and body**: [#51 – Robert Sapolsky, Ph.D.: The pervasive effect of stress – is it killing you?](https://peterattiamd.com/robertsapolsky/) | Peter Attia (peterattiamd.com) [51:15]

**Research suggesting you need all 3 of the following to be truly self-compassionate: 1) self-kindness, 2) mindfulness, and 3) common humanity/sense of connectedness**: [The Development and Validation of a Scale to Measure Self-Compassion](https://self-compassion.org/wp-content/uploads/publications/empirical.article.pdf) (Neff, 2003) [55:30]

**Research showing that when AA is successful, one of the reasons it may be successful is because it increases self-compassion**: [Self-Compassion Amongst Clients with Problematic Alcohol Use](https://self-compassion.org/wp-content/uploads/publications/SCalcohol.pdf) (Brooks et al., 2012) [1:00:30]

**Pilot study looking at the efficacy of the MSC program**: [A pilot study and randomized controlled trial of the mindful self-compassion program](https://pubmed.ncbi.nlm.nih.gov/23070875/) (Neff and Germer, 2013) [1:04:45]

**Kristin’s RCT applying self-compassion training in healthcare workers**: [Caring for Others without Losing Yourself: An Adaptation of the Mindful SelfCompassion Program for Healthcare Communities](https://self-compassion.org/wp-content/uploads/2020/06/Neff2020d.pdf) (Neff et al., 2020) [1:05:30]

**Study that had people write a compassionate letter to themselves once a day for seven days and it reduced depression for three months and increased happiness for six months**: [The benefits of self-compassion and optimism exercises for individuals vulnerable to depression](https://www.tandfonline.com/doi/abs/10.1080/17439760.2010.516763?journalCode=rpos20) (Shapira and Mongrain, 2010) [1:10:00]

**Center founded by Kristin and Chris Germer**: [The Center for Mindful Self-Compassion](https://centerformsc.org/) | (centerformsc.org) [1:12:00]

**A self-guided workbook (based on their 8-week program)**: [The Mindful Self-Compassion Workbook: A Proven Way to Accept Yourself, Build Inner Strength, and Thrive](https://www.amazon.com/Mindful-Self-Compassion-Workbook-Yourself-Strength/dp/1462526780) by Neff and Germer | (amazon.com) [1:11:45]

**Chris Germer’s book**: [The Mindful Path to Self-Compassion](https://www.amazon.com/Mindful-Path-Self-Compassion-Yourself-Destructive/dp/1593859759) by Chris Germer | (amazon.com) [1:13:00]

§

## People Mentioned

- [Chris Germer](https://chrisgermer.com/about-chris-germer/) [1:00, 1:11:45, 1:13:00]
- [Elliot Turiel](https://gse.berkeley.edu/elliot-turiel) [4:30]
- [Ram Dass](https://en.wikipedia.org/wiki/Ram_Dass) [8:15]
- [Thích Nhất Hạnh](https://en.wikipedia.org/wiki/Thich_Nhat_Hanh) [9:00]
- [Richard “Dick” Schwartz](https://ifs-institute.com/about-us/richard-c-schwartz-phd) [14:30, 58:45]
- [Ric Elias](https://redventures.com/about/leadership?modal=ric_elias) [17:30]
- [Susan Harter](https://www.guilford.com/author/Susan-Harter) [20:45]
- [William James](https://en.wikipedia.org/wiki/William_James) [22:45]
- [Morris Rosenberg](https://psychology.wikia.org/wiki/Morris_Rosenberg) [23:15]
- [Rupert Isaacson](https://www.texasmonthly.com/articles/rupert-isaacson/) [40:45]
- [Paul Gilbert](https://en.wikipedia.org/wiki/Paul_Gilbert_(psychologist)) [45:15, 47:00]
- [Robert “Bob” Sapolsky](https://en.wikipedia.org/wiki/Robert_Sapolsky) [51:15]

§

![](https://peterattiamd.com/wp-content/uploads/2020/11/Kristin-Neff-bio-image-neff.jpg)

##### Kristin Neff, Ph.D.

Kristin Neff received her doctorate from the University of California at Berkeley, studying moral development. She did two years of postdoctoral study at the University of Denver studying self-concept development. She is currently an Associate Professor of Educational Psychology at the University of Texas at Austin.

During Kristin’s last year of graduate school she became interested in Buddhism and has been practicing meditation in the Insight Meditation tradition ever since. While doing her post-doctoral work she decided to conduct research on self-compassion – a central construct in Buddhist psychology and one that had not yet been examined empirically. Kristin is a pioneer in the field of self-compassion research, creating a scale to measure the construct over fifteen years ago. In addition to writing numerous academic articles and book chapters on the topic, she is author of the book [Self-Compassion: The Proven Power of Being Kind to Yourself](https://www.amazon.com/Self-Compassion-Proven-Power-Being-Yourself/dp/0061733520), released by William Morrow.

In conjunction with her colleague Dr. Chris Germer, she has developed an empirically supported training program called [Mindful Self-Compassion](https://centerformsc.org/train-msc/), which is taught by thousands of teachers worldwide. They co-authored [The Mindful Self-Compassion Workbook](https://www.amazon.com/Mindful-Self-Compassion-Workbook-Yourself-Strength/dp/1462526780) as well as [Teaching the Mindful Self-Compassion Program: A Guide for Professionals](https://self-compassion.org/teaching-the-mindful-self-compassion-program-a-guide-for-professionals/), both published by Guilford. She is also co-founder and board president of the nonprofit [Center for Mindful Self-Compassion](https://www.centerformsc.org/). [[self-compassion.org](https://self-compassion.org/about/)]

Twitter: [@self\_compassion](https://twitter.com/self_compassion?lang=en)

Facebook: [Self-Compassion by Kristin Neff, Ph.D.](https://www.facebook.com/selfcompassion/)