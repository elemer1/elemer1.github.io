# #271 – AMA #51: Understanding and improving your metabolic health

**Source:** [https://peterattiamd.com/ama51/](https://peterattiamd.com/ama51/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives deep into the critical topic of metabolic disease. He first sheds light on how poor metabolic health drives up the risk of developing other chronic diseases such as cardiovascular disease, cancer, neurodegenerative disease, and overall mortality. He explores the array of metrics and tests used to assess metabolic health, underscoring his preferred methodologies utilized with patients. Finally, Peter provides an overview of the factors one can manipulate in order to improve metabolic health.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #51 show notes page](https://peterattiamd.com/ama51). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Importance of metabolic health and a primer on metabolic disease [1:30];
- How poor metabolic health increases one’s risk for other chronic diseases [6:00];
- How useful is body weight and BMI for estimating metabolic health? [9:45];
- Overview of various tests and metrics used to understand metabolic health [12:15];
- Traditional biomarkers and how Peter’s point of view may differ from the guidelines [15:00];
- Lactate: insights into metabolic health through fasting and resting lactate levels [17:00];
- Zone 2 output: an important functional test of metabolic health [20:00];
- Cardiopulmonary exercise testing (CPET) [25:45];
- Visceral adipose tissue (VAT): what is VAT and how does it impact health? [27:00];
- Oral glucose tolerance test (OGTT): how it works and why it is such an important metric for assessing metabolic health [32:15];
- The utility of a continuous glucose monitor (CGM) [40:45];
- Liver function and NAFLD [42:15];
- Sleep as an intervention [46:00];
- Exercise as an intervention [53:15];
- Diet and nutrition [59:00];
- How reducing stress can improve metabolic health [1:05:15]; and
- More.

§

The Peter Attia Drive

Understanding and improving your metabolic health

§

## Show Notes

§

## Importance of metabolic health and a primer on metabolic disease [1:30]

The “four horsemen” of aging diseases:

- cardiovascular disease
- Cancer
- neurodegenerative disease
- metabolic disease–a range of conditions from obesity all the way to type 2 diabetes

Today, Peter will dive into metabolic disease to answer many listener questions

- what is metabolic disease?
- how do you define it?
- how does it feeds the other three main horsemen?
- and how it can cause problems for people?
- Then look at the various metrics and tests one can use to determine their metabolic health status
- Then Peter will go through the interventions one can make to improve their met. health

**Primer of metabolic disease and criteria for metabolic syndrome [3:30]**

Primer on metabolic disease

- There was a very famous, remarkable endocrinologist by the name of [Jerry Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven)
- He was Stanford for most of his career and in the 1980s he made an observation about something he called “syndrome x” which seemed very correlated with did cardiovascular disease, cancer, neurodegenerative disease
- 5 signs of “syndrome x” where things like when people have truncal obesity, elevated triglycerides, depressed HDL cholesterol, elevated blood pressure, and elevated glucose levels
  - This seems to be a remarkable predictor of all of these chronic diseases of aging
  - That terminology eventually became known as **metabolic syndrome**

The criteria for diagnosing MetSyn can vary slightly among different organizations, but the American Heart Association and the National Heart, Lung, and Blood Institute have agreed on the following criteria:

- Waist circumference of 40 inches or more for men, and 35 inches or more for women
- Triglycerides 150 mg/dL or higher, or taking medication for elevated triglyceride levels, >100 preferred
- HDL-C of less than 40 mg/dL in men or less than 50 mg/dL in women, or taking medication for low HDL-C levels
- Blood pressure of 130/85 mmHg or higher, or taking medication for high blood pressure, >120/80 preferred
- Fasting glucose of 100 mg/dL or higher, or taking medication for elevated glucose levels

Having metabolic syndrome is defined as having **three or more** of these.

> “I won’t suggest that this is the best way to evaluate metabolic health. I think there are many more nuances that we’re going to go into, but at a minimum, I think everybody should know where they stand on those things.” —Peter Attia

## How poor metabolic health increases one’s risk for other aging-related diseases [6:00]

***How does metabolic syndrome feed the other horsemen and those other diseases?***

The literature on this is “so voluminous and so one-sided that I don’t think it’s particularly interesting”

To touch on a couple of high points:

- If you look at all the meta-analyses of all-cause mortality, cardiovascular mortality, cancer mortality, cancer incidence, dementia incidence, all of these things all point in the same direction
- “*Once you have metabolic syndrome, you’re at an increased risk of everything*.”

**Cardiovascular disease**

A [systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/20863953/) of 87 studies involving 951,083 patients found that MetS is associated with a significant increase in the following:

- Risk of cardiovascular disease goes up by 135%
- Risk of cardiovascular mortality goes up by 140%
- Rick of all-cause mortality is up by 58%
- Your MI risk is up by 99%
- Stroke risk goes up 127%

**Cancer**

A [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2700189/) looking at cancer risk found:

- A 56% increase in age adjusted risk of cancer mortality if you have met syn
- In particular, there are a handful of cancers that seem especially impacted by this:
- Endometrial cancer is seven times as likely
- Esophageal cancer is almost five times as likely
- Gastric cancer is about twice as likely
- Liver and kidney is about twice as likely
- So there are a handful of cancers that even appear to be especially exacerbated by metabolic syndrome, or by obesity and being overweight

![](https://peterattiamd.com/wp-content/uploads/2023/09/f1-ama51-1024x1018.png)

**Figure 1.** Cancer risk associated with obesity, [National Cancer Institute](https://www.cancer.gov/about-cancer/causes-prevention/risk/obesity/obesity-fact-sheet)

![](https://peterattiamd.com/wp-content/uploads/2023/09/f2-ama51-951x1024.png)

**Figure 2.** [National Cancer Institute](https://www.cancer.gov/about-cancer/causes-prevention/risk/obesity/obesity-fact-sheet)

- Most people understand that smoking is an enormous driver of risk for cancer (it remains the number one environmental trigger of cancer)
- But obesity is number 2
- And if you look more closely at the data, *it’s really metabolic syndrome*, which obviously overlaps a lot with obesity

**Neurodegenerative diseases**

- For *Parkinson’s disease*, the largest [meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6103502/) on this study suggests about a 24% higher risk of Parkinson’s disease in those with metabolic syndrome compared to those without
- And just as we see in atherosclerosis, we see that having three of the risk factors for metabolic syndrome is a 31% higher risk of Parkinson’s disease, while having all five, 66% increase in risk.
- When it comes to *Alzheimer’s disease*, it’s about a [10% increase](https://pubmed.ncbi.nlm.nih.gov/34039508/) in Alzheimer’s disease for those with met syn.
  - that was actually a surprisingly low number
  - But if you look more closely at the data, you’ll realize that there actually appears to be a protective role in the abdominal obesity risk factor
- So when you do the analysis by looking at each of the metrics of met syn individually, there’s about a 16% reduction from “protective benefits” of abdominal obesity
  - \*This is likely due to reverse causality, meaning, having Alzheimer’s disease is more likely to lead to abdominal obesity
    - \*NOTE: Peter misspoke in describing this relationship. The apparent “protective effect” of obesity is likely due to reverse causality because Alzheimer’s disease typically leads to weight loss.
  - nevertheless, that’s why those numbers don’t look as big
- When you look at all forms of dementia, (remember, Alzheimer’s disease is the most prevalent form of dementia, but there are many forms of dementia that are not Alzheimer’s, vascular dementia, Lewy body dementia, frontotemporal dementia) — So all comers, vascular dementia is about a 37% increase in risk.

## How useful is body weight and BMI for estimating metabolic health? [9:45]

***How helpful is body weight and BMI to actually understand someone’s metabolic health?***

It’s such a crude tool, but it’s understandable why body weight and BMI are used as health indicators at the population level

![](https://peterattiamd.com/wp-content/uploads/2023/09/f3-ama51-1024x709.png)

**Figure 3.** Metabolic syndrome prevalence across obese and non-obese populations. Source: [OUTLIVE](https://peterattiamd.com/outlive), using data from the National Institute of Diabetes and Digestive and Kidney Diseases (2021)

- Conservatively speaking, you have 108 million obese adults in the United States and 150 million non-obese
- Obese being defined as a BMI over 30
- If you look at the people who are obese and have metabolic syndrome, it’s 62% of the obese have metabolic syndrome—that’s 67 million people are obese with metabolic syndrome
- Conversely, if you look at the 150 million people who are not obese, 22% of those people have metabolic syndrome, about 33 million
- In total, 100 million people with metabolic syndrome in the US
  - But what’s most interesting is that **a third of people with MetSyn are not obese**
- “If you think about all the things that we look at in our patients and all of the metrics we have on them, I can just tell you, I don’t know the BMI of one of my patients and I don’t care, because I’m not trying to practice medicine on a population basis.”
- Ultimately, BMI is not that helpful b/c it doesn’t account for body composition or for insulin sensitivity in any way, shape, or form

## Overview of various tests and metrics used to understand metabolic health [12:15]

Peter organizes these as functional tests, imaging tests, typical or regular biomarkers, and maybe some special tests

**Regular/ “Traditional” blood based biomarkers**:

- Uric acid
- Homocysteine
- triglycerides/HDL-C ratio
- fasting glucose/insulin,
- hemoglobin A1c
- liver function tests

**Less common blood based biomarker**:

- Resting/fasting lactate: Lactate is a product of anaerobic metabolism, and high levels can indicate a problem with the body’s metabolic processes.

**Functional tests**:

- Zone 2 output
- Cardiopulmonary exercise testing (CPET): CPET measures how the heart, lungs, and muscles respond to exercise, including a measurement of VO2 max.
- Oral glucose tolerance test (OGTT): This test measures the body’s response to glucose. It involves fasting overnight, drinking a glucose solution, and then having the blood glucose levels measured at intervals.
- Continuous glucose monitoring (CGM): A CGM device measures glucose levels in real-time throughout the day and night. It can help identify fluctuations and trends that might not be captured with traditional blood glucose monitoring.
- Whole-room respiratory suites: These instruments measure energy utilization/expenditure during sleep, rest, meals, exercise, etc.
  - You can do this to get a sense of respiratory quotient

**Imaging studies**:

- DEXA scans for:
  - Muscle mass
  - Fat mass
  - Visceral adipose tissue (VAT) assessment: Can be measured with various imaging techniques, such as CT or MRI, and DEXA scans.
    - Peter would never rely on CT scans for looking at visceral fat, although one could do it
- Liver ultrasound to detect fatty liver disease
  - One can use algorithms that combine liver ultrasound with blood tests to look at fibrosis scores which becomes very important as you want to understand the prevalence of fatty liver disease

**There are several tests that are currently used predominantly for research purposes to assess metabolic health. Some of these include**:

- C16 levels: C16 is a type of saturated fatty acid, and its levels can provide information about fat metabolism.
- Biopsy of intramuscular fat: Can provide information about how fat is stored in the muscles, which can be relevant for conditions like insulin resistance and T2D.
  - See more in the [Gerald Shulman episode](https://peterattiamd.com/geraldshulman/)

## Traditional biomarkers and how Peter’s point of view may differ from the guidelines [15:00]

**Regular/traditional biomarker tests**

*What trends you’re looking for, what are the ranges you like to see, and then ultimately, how do you improve those various metrics?*

![](https://peterattiamd.com/wp-content/uploads/2023/09/f4-ama51-1024x752.png)

**Figure 4.** Guideline-based recommended ranges for metabolic health metrics, various sources.

**How Peter’s point of view may differ from the guidelines**:

Triglyceride to HDL cholesterol ratio

- Guidelines say that should be less than five to one
- Peter believes that should be less than one to one, meaning, triglycerides should be less than HDL cholesterol.

Fasting glucose guidelines say less than 99

- Truthfully, Peter doesn’t put a lot of stock in fasting glucose b/c it can be so heavily influenced by the previous night’s meal, or cortisol, or a poor night’s sleep
- Peter tends to rely on CGM here

Fasting insulin

- Typical guidelines are less than 20
- Peter would like to see that less than eight, and maybe even closer to six

Hemoglobin A1C

- Less than 5.7 is the cutoff for pre-diabetes
- Peter relies heavily on CGM here

Transaminases

- People have probably heard him talk about transaminases before and how those ranges tend to be too broad. Again, you can see our cutoffs in the figure above

## Lactate: insights into metabolic health through fasting and resting lactate levels [17:00]

**Lactate**

- It’s important to know not just just fasting lactate, but also resting lactate
- When you’re NOT under exertion, when you haven’t just taken in a whole bolus of glucose, the lactate level should be below 1.0 millimole.
- So we would say “normal” is anything below 1.0 millimole of lactate
- A really good clue that somebody is metabolically unhealthy is when that level is elevated, and typically, it can be north of 2.0, and even in some studies, north of 4.0 in people with type 2 diabetes

The gold standard benchmark test for Zone 2 is, how much work can you do while keeping lactate below two millimole?

- If you think about the absolute fittest, most mitochondrially healthy people on the planet, cyclists, probably, these guys are putting out 3-4.5 watts per kilogram of work, but still keeping lactate below 2.0 — “*That’s how efficient their mitochondria are*”
- So an individual who, at rest, is north of 2.0, tells you that they are already having such an impaired capacity to oxidize fat in their mitochondria that even without being under any exertion, beyond breathing, they’re so insulin resistant, they’re so poor at fuel partitioning, that they’re making that transition to glycolytic phosphorylation by default

\*Quick tangent:

- This to me was one of the first signs that there was just something up with metformin, because in people taking metformin, even healthy people taking metformin, you’ll see this jump in resting, fasting lactate
- Not a surprise, given that metformin is inhibiting mitochondrial complex 1.
- Testing lactate is NOT something you NEED to do, but if you’re looking for the full suite of tools to understand metabolic health, knowing what your fasting/resting lactate is, is important

One last caveat: These lactate machines are very finicky, they have to be calibrated, your hands have to be clean, sometimes the strips don’t work, etc., you can get numbers that are quite meaningless so don’t make an assumption based on one erroneous test

## Zone 2 output: an important functional test of metabolic health [20:00]

“Zone 2 output is arguably the most important functional test we have of metabolic health.” —Peter Attia

⇒ See episodes: [AMA #39](https://peterattiamd.com/ama39/), [AMA #26](https://peterattiamd.com/ama26/), [AMA #19](https://peterattiamd.com/ama19/)

\*\*\*

**Rate of perceived exertion**

- If you’re willing to test lactate levels while doing zone 2, go for it
- But if you’re new to this, that’s fine too, you can do it based on rate of perceived exertion which is really this “talk test”
- When you’re in Zone 2, you can speak, you just don’t want to
- If you can speak easily, you’re not in Zone 2, you’re in Zone 1
- And if you can’t speak at all, or you can’t speak more than a couple of words at a time, but you couldn’t speak a sentence, you’re north of Zone 2
- For patients who show up with profound insulin resistance, Peter does not rely on lactate in those patients, because their lactate levels are so high that if he tried to rely on those, they’d be in Zone 1
- It turns out that the less conditioned you are, the more important it is to actually rely on RPE

Can you use heart rate to know if you’re in zone 2?

- Yes and no, says peter
- Peter found an app called [Morpheus](https://trainwithmorpheus.com/), which gives him 5 parameters each morning
  - How much he slept,
  - Quality of sleep
  - Heart rate variability and heart rate
  - Also, to the extent to which he’s sore from the day before
  - And his appetite to exercise that day.
- The app then spits out training zones of heart rate
  - And there were three zones, zone 1, 2, and 3
  - But the breakpoint between 1 and 2, that heart rate is a very good proxy for what ends up being Peter’s zone 2
  - So he’s been tracking that number versus his RPE number, versus his lactate and power for every day
  - And after four months of collecting those data, it’s actually a very reasonable proxy for someone who doesn’t want to do the other stuff

**Peter likes to show patients the following figure**:

![](https://peterattiamd.com/wp-content/uploads/2023/09/f5-ama51-1024x555.png)

**Figure 5.** Zone 2 output by fitness level. Source: [San-Millán, I., & Brooks, G. A., Sports Medicine, 2018.](https://pubmed.ncbi.nlm.nih.gov/28623613/)

- This is Zone 2 output normalized as watts per kilo in different types of individuals
- Far left side, you have the metabolic syndrome person, they might be at one watt per kilo
  - So if they weigh 100 kilos, they might only be able to put out 100 watts in Zone 2
- At the other end of the spectrum, you have the best cyclist in the world
  - over four watts per kilo

The aspiration is that all of Peter’s patients would be at least two watts per kilo, and probably closer to two and a half watts per kilo

- There’s almost no better example of a functional test
- VO2 max corresponds to a different side of this coin
- But taken together, it’s impossible to be metabolically unhealthy and yet have a high performance here
- Peter puts much of his emphasis with patients on: how do you perform well at Zone 2, VO2 max, and also fat oxidation (which you’ll see when we look at the VO2 max)
- Peter at his peak in cycling had a 3.2 watts per kilo
- CPET testing: a functional test Peter does with patients (more on this below)
  - Cardiopulmonary exercise testing (CPET): CPET measures how the heart, lungs, and muscles respond to exercise, including a measurement of VO2 max.

\**Advice for people when getting a VO2 max test*:

- When you go to get a VO2 max test, make sure you get the data that shows fat and carbohydrate oxidation with increasing heart rate—ideally, as a function of power
  - So on the X axis, you would have power, and then you have two y axes.
    - One is for carbohydrate oxidation in grams per minute,
    - One is for fat oxidation in grams per minute.
  - And not surprisingly, what you see is, as workload increases, fat oxidation goes down, it becomes harder and harder for the mitochondria to get enough oxygen to use fat as a more efficient substrate
  - Conversely, as you move to the right on the graph, meaning, as work increases, you’ll see carbohydrate oxidation increase
  - We’re looking for two things
    - 1) How high is their power output at peak fat oxidation (the higher that number the better)
    - 2) Peak fat mass oxidation
    - For context, a superstar endurance athlete is going to be close to 1 gram per minute of fat oxidation and 3.5 watts per kilo
    - Conversely, someone who’s metabolically unhealthy is going to have a peak fat oxidation of 0.1 to 0.2 grams per minute, and they’ll peak at the very beginning and any incremental exertion will just drive them down

## Cardiopulmonary exercise testing (CPET) [25:45]

- CPET testing: a functional test Peter does with patients (more on this below)
  - Cardiopulmonary exercise testing (CPET): CPET measures how the heart, lungs, and muscles respond to exercise, including a measurement of VO2 max.

—

- VO2 max testing, if done correctly, also gives you the fat and glucose oxidation along the way
- And that is a test that’s worth doing (but it’s difficult and painful)
- But make sure to do it on the modality that you’re used to training in
- If you’re a runner, do a treadmill
- If you’re a cyclist, do a bike
- And you want to know that number, the absolute VO2 max, which is the most highly correlated number with all-cause mortality
- You also want to get your fat oxidation number
- Peter has patients do their zone 2 testing on a different day than VO2 max as to not exhaust the person and give false data on the VO2 max test

## Visceral adipose tissue (VAT): what is VAT and how does it impact health? [27:00]

⇒ See [AMA #40](https://peterattiamd.com/ama40/)

**What VAT is, and the risks that are associated with a higher VAT than a lower VAT**:

*Bathtub analogy*:

- This analogy helps to explain how we store fat and what happens when we exceed our capacity to store a subcutaneous fat, which is the safe storage depot for excess energy
- People have different size bathtubs and the size of your bathtub is proportional to how much fat you can store safely
- A person who is thin but metabolically unhealthy is someone with a small bathtub—they fill that bathtub up with water pretty quickly, and then any additional water starts overflowing
- About a third of people who are obese are still metabolically reasonably healthy—those are people with an enormous bathtub, and while they’re storing a ton of “water” in it, it’s not spilling over and causing damage (but they could have a lot of subcutaneous fat)

*What does that spillover damage?*

- Visceral adipose tissue, along with liver fat, along with peripancreatic fat, these are relatively small amounts of fat
- But unlike subcutaneous fat, they’re not passive storage sites for excess calories, they’re actual endocrine organs that produce hormones and cytokines, referred to as adipokines
- These are highly inflammatory
- It’s really this form of fat that is the association we care about—this is the **causal relationship between obesity and disease**
- when we say someone who’s obese is at a higher risk of disease X, Y, and Z, when we say that someone with metabolic syndrome is at a higher risk of A, B and C, **what we’re doing is we’re making that link through these adipokines and the pro-inflammatory impact that they have on the immune cells and then directly on insulin signaling**.

**Three examples of how VAT is problematic from a pathology standpoint**:

1 -When  fat accumulates within the muscle cells, that is what’s playing the causal role in reducing the muscle’s capacity to respond to the insulin molecule hitting the insulin receptor

- so when insulin hits the insulin receptor, it should, under normal circumstances, quite easily lead to a phosphorylation chain inside the cell that takes a glucose transporter, which is like a cylinder that gets shot up to the surface of the muscle, and it goes across the cell membrane, and that’s what allows glucose to passively come into the cell
- That’s how we dispose of glucose
- And yet, when there is fat, diacylglyceride, triglyceride within the muscle itself, it turns that signal down.
- So insulin resistance is directly caused by this

2 – Another example of how this type of fat is problematic from a pathology standpoint is looking at intrahepatic fat

- So when fat accumulates in the liver, you see a greater amount of fat needing to be exported through the VLDLs, the very-low-density lipoproteins
- And when that happens, you have cholesterol poor, triglyceride rich VLDLs, you need more LDLs to move the same amount of cholesterol
- So you’re all things equal driving up ApoB, you’re also typically using smaller LDLs to do the work
- And so smaller LDLs have a more difficult time being cleared by the LDL receptor in the liver
- So now, you have more particles, and then these smaller particles feed on themselves by being harder to clear out of circulation
- They have an increased residence time
- you increase your risk of atherosclerosis

3 – Final example here would be peripancreatic fat

- when that fat accumulates in the pancreas, it’s inflammatory and it’s actually toxic to the beta cells
- the endocrine cells of the pancreas that produce insulin
- now, you have the cells that produce insulin, which are there in theory, to at least partially overcome the resistance of the muscle to insulin, and now they’re impaired from making as much insulin
- now you have a vicious feed forward cycle where the muscles become more insulin resistant and the pancreas is less able to make insulin

*How much VAT is needed to cause issues?*

- The total amount of fat that’s necessary to cause damage, relative to total body fat, is very low
- You don’t need much fat outside of the subcutaneous storage spots to have huge problems
- Peter wants patients below the 10th percentile (measured with [DEXA](https://peterattiamd.com/ama40/) scans)

## Oral glucose tolerance test (OGTT): how it works and why it is such an important metric for assessing metabolic health [32:15]

⇒ See [AMA #15](https://peterattiamd.com/ama15/) for more on OGTT

\*\*\*

**Background on OGTT**

- This test isn’t done as often as it used to be done
- The reason it used to be done more frequently is, it used to be the manner in which a patient was diagnosed with type 2 diabetes
- Today, that diagnosis is based on hemoglobin A1C, and that has its pluses and minuses obviously
- One of the pluses of using hemoglobin A1C is it’s a single and simple blood test as opposed to one that takes time and requires drinking glucose
- The drawback of moving away from this is doctors are less familiar with the OGTT, and the truth of it is, it’s a far, far more important test because it is a functional test and it gives much more information, including canary in a coal mine information
- In other words, it gives you information before there’s real pathology, whereas the hemoglobin A1C doesn’t

**How an OGTT works and why it is such an important metric for assessing metabolic health**

- You show up for this test fasted for 12 hours (min 8 hours)
- You draw blood to get a baseline
- Then you’ll drink something called glucola (pure glucose drink)
- The person stays sedentary, so they don’t get up and exercise, walk around and do anything else, they have to just sit there
- Then you take blood again in 30 minute intervals, for two hours, their insulin and glucose levels again.
- There’s some protocols that go out to five hours but Peter is mindful of patient’s time and made the concession to do four draws, so 0, 30, 60, 90 minutes
- In each blood draw, they are measure both glucose and insulin levels

*Important point*: Doing this OGTT test, there are times when you can catch people who effectively have type 2 diabetes even though they aren’t there by hemoglobin A1C

- hemoglobin A1C threshold is 6.5%, which corresponds to an average blood glucose of 140.
- But the way it used to be diagnosed, a better way in Peter’s opinion, is if your blood glucose is 200 milligrams per deciliter or higher at the two-hour mark, you have diabetes
- This is just another reason why having this test done is really valuable

**Studies:**

A recent [study](https://link.springer.com/article/10.1007/s00125-017-4468-z) characterized the variations in glucose levels at three different points during an OGTT and compared the rates of diabetes, cardiovascular disease (CVD), and all-cause mortality among individuals with different glucose patterns

- Side note:  the units on this are not what we’re used to seeing, but just remember that one millimole of glucose is about 19 milligrams per deciliter
- So if you look at section A in the figure below, what you’re looking at here is glucose response, so therefore, 10 would be about 190

![](https://peterattiamd.com/wp-content/uploads/2023/09/f6-ama51-slide-6.png)

**Figure 6.** Credit: [Hulman et al., 2017](https://link.springer.com/article/10.1007/s00125-017-4468-z)

- Green pattern: people that had the most normal response—starting at about below 100, going up to about 140, and then in two hours, they’re back to 100
- Light blue: slightly beyond green pattern
- Red and Purple group: Interesting to highlight that the red and the purple group both have a very high response, so they get up to 190, 200 milligrams per deciliter within 30 minutes
  - Then the purple group responds perfectly, so they end up right back at normal, whereas the red group does not
- In section B of the figure above, incidence of diabetes over the next 12 years, and you can see that that red group had a significant increase
  - that had a huge peak at 30 minutes and stayed elevated over two hours, their likelihood of getting diabetes is significant
  - whereas the other three groups, including the purple group, not nearly as high
- When you look at section C, the bottom left figure, you’re looking at cardiovascular disease
  - the red group stands alone, whereas the green group obviously in its own category at the bottom
- finally, bottom right section D, you’re looking at all-cause mortality. And here, it doesn’t seem to matter as much
  - What’s quite interesting to me, both the red and the purple group have the highest all-cause mortality, and not surprisingly, green group does not

> “A test like this to me is very valuable, it’s a functional test, and it gives you a lot more information than you get just out of hemoglobin A1C.” —Peter Attia

**The famous Kraft analysis**

- [Joseph Kraft](https://meterbolic.com/who-was-dr-joseph-kraft) identified these five patterns of glucose and insulin response
- Kraft’s analysis demonstrates the utility of insulin in showing things that glucose doesn’t always show

![](https://peterattiamd.com/wp-content/uploads/2023/09/f7-ama51-1024x555.png)

**Figure 7.** Patterns of glucose and insulin responses. Source: [Kraft Prediabetes Profile, Meridian Valley Labs](https://www.meridianvalleylab.com/kraft-prediabetes-profile-patterns-overview/)

\*Note that green is insulin; purple is glucose

- Pattern 1: normal glucose and insulin response
  - You peak at 30 minutes, and you’re basically back to normal at two hours
- Pattern 2: Totally normal fasting levels of glucose and insulin, and the two-hour glucose tracing is normal, but what you have is a delayed insulin peak
  - This turns out to be predictive of borderline insulin resistance
  - This is a person who’s not going to be in trouble anytime soon, but they’re not normal right now
  - This is obviously the time to intervene, says Peter (more on this later in the podcast)
- Pattern 3: Truthfully, 3B is only going to be valuable as something to understand if you’re going to do that four-hour test
  - This pattern is somebody with relatively normal glucose disposal, but they have a very late insulin peak at two hours (as opposed to 1 hour with pattern 2)
  - These people have well-established insulin resistance
- Pattern 4: These people now have an enormous outpouring of insulin and relatively normal glucose
  - they keep their glucose levels in check, but they require very high levels of insulin to do so
  - These people are very insulin resistant and the next step for them is indeed type 2 diabetes
- Pattern 5: This is not something typically seen in Peter’s practice
  - These are people that would have what we call islet-cell exhaustion
  - Their pancreas is no longer making enough insulin, so they have enormous glucose levels and very little insulin to speak of

## The utility of a continuous glucose monitor (CGM) [40:45]

CGMs will provide a more accurate look at average blood glucose

- Standard practice is to use hemoglobin A1C, which is measuring the amount of glucose on a hemoglobin molecule, and use that to estimate what the average blood glucose is
- But CGM allows you to **directly** calculate the average blood glucose and bypass this idea of using hemoglobin A1C
- There are a number of factors that can lead to a false implication of the A1C
  - If the red blood cells turn over too quickly or too slowly
  - If the red blood cells are too big or too small
- That being said, if anything suspicious comes out of an OGTT, i.e., that glucose homeostasis is not being met, Peter is then going to put a CGM on a patient for at least 30 days and get a better example.

In the CGM data, Peter is looking at various things

- Average blood glucose
- The number of peaks that they have
- how long it takes them to recover from peaks,
- where the peaks occur in relation to meals versus stress, versus exercise,
- how sleep impacts them,
- And more

⇒ For more, check out [AMA #24](https://peterattiamd.com/ama24/) and [AMA #26](https://peterattiamd.com/ama26/)

## Liver function and NAFLD [42:15]

**Diagnostic tools and tests that can be used to help people understand their liver function, what those tests can reveal, and ultimately, looking for non-alcoholic fatty liver disease, or NAFLD**

- The first telltale sign that somebody has NAFLD is a *slight elevation in their transaminases*
- These are the enzymes, ALT and AST, with ALT being more of an idicator
- Peter says nowadays they are pretty aggressive with just going straight to a liver ultrasound and a fibrosis score
  - These are tests that look at some other biomarkers and can come up with a better probability of the presence of fat and or fibrosis or scarring in the liver
- The goal is to catch this when it’s just liver fat, because NAFLD is 100% reversible
- We don’t want someone to get to [NASH](https://www.pfizer.com/disease-and-conditions/nash#:~:text=Nonalcoholic%20steatohepatitis%2C%20or%20NASH%2C%20is,1) — while NASH is still reversible, now you’re one step closer to getting some fibrosis in the liver
  - At that point, it’s irreversible, enough fibrosis in the liver becomes cirrhosis

**Important point**: NAFLD is the leading indication for liver transplants in the United States today

- The majority of people that have failing livers today have it because of cirrhosis brought on by the fibrosis of accumulated liver fat
- Historically, this is something we usually saw from alcohol, but now we’re seeing it more from non-alcohol sources, namely, excess adiposity
- This will show up on a CT scanner or an MRI
- Peter is seeing more and more of this now with patients doing MRI for whole body MRI for cancer screening.
- We would always do a FibroScan, which is an ultrasound, again, using a few other biomarkers that are more sensitive than simply the transaminases

> “This is a real silent epidemic…there are a lot of people walking around out there with NAFLD who are completely unaware.” —Peter Attia

- We’ve just become so habituated to looking at elevated levels of transaminases
- We see people walking around with transaminases in the 30s and we think, “well, that’s normal because it is consistent with the population”.
- But that doesn’t mean it’s optimal and it doesn’t mean that it’s healthy
- And going back to the biomarkers, we want to see those transaminases typically in the 20s, not in the 30s

## Sleep as an intervention [46:00]

**Importance of sleep**

- “*Sleep is probably the most underappreciated contributor to insulin resistance and poor metabolic health*.” say Peter
- That being said, sleep is one of the lowest hanging pieces of fruit to optimize when trying to address this

Clarifying the term “lifestyle factors”

- When we talk about “lifestyle factors” we mean non-pharmacologic interventions
- when it comes to cardiovascular disease, at the end of the day, if you really, really want to eliminate it, you’re probably going to need lipid modulating medication at some point if your goal is to make sure you never get atherosclerosis
- When it comes to cancer, bad luck plays a role in many situations, and we have to rely on early and aggressive screening to make sure that we can catch these things early
- When it comes to **metabolic health**, if you’re exercising, sleeping, and eating within the boundary conditions of what is optimal, you’re going to be metabolically healthy, you do not need a cocktail of drugs to achieve this

Sleep study: [2012 Van Cauter study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4435718/)

- A randomized crossover study in 7 adults (a crossover studies are studies where every person is their own control)
- Patients did either 4 days of 4.5 hours or 8.5 hours in bed with controlled conditions of calorie intake and physical activity (sedentary lab conditions during waking hours).
- And there’s a washout period in between
- It’s controlled conditions, so identical caloric intake, identical physical activity, sleep was assessed using polysomnography
- This is how you would measure the insulin sensitivity of a fat cell
- They biopsied fat cells, they took them out, and then they measure the amount of phosphorylated Akt
- And they have a sense of how insulin sensitive the fat cells are in response to increasing levels of insulin they subjected them to
- *Results*:
  - After a normal night’s sleep, insulin causes a dose-dependent increase in phosphorylated Akt levels in participants, whereas sleep restriction induced a significant reduction in these levels, despite constant total Akt levels
  - So by looking at phosphorylated Akt versus total Akt, you get a sense of insulin sensitivity, which decreased by 30% across this four-day period of time
  - When looking at total body insulin sensitivity, they saw after four days of sleep restriction there was a reduction in glucose disposal by 16%

In a [review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9036496/) of the literature, short sleep duration was significantly associated with insulin resistance

- Four hours and 15 minutes of sleep in 16 men who had normal unimpaired glucose control in an OGTT screen was associated with higher peripheral insulin resistance than a full night of sleep (8.5 hrs of sleep)
- A 16% higher increase in serum insulin and HOMA-IR the morning after a single night of short sleep

> “Anecdotally, this is one of the most interesting things that patients who wear CGMs report, and it was definitely one of the things that surprised me the most.” —Peter Attia

Bad sleep disrupts glucose disposal

- Personally, Peter found that a short night sleep would impair his glucose disposal the following day
- “*In other words, if I had five and a half hours of sleep versus eight hours of sleep and did the exact same things and ate the exact same things the next day, the glucose response was totally different*.”
- This is why patients who are insulin resistant, that also have hypercortisolemia, if sleep is not fixed, it’s very difficult to move the needle

> “Sleep is one of those things where. . .if you’re deficient in it, it wreaks absolute metabolic havoc.” —Peter Attia

⇒ For more, check out [AMA #42](https://peterattiamd.com/ama42/)

## Exercise as an intervention [53:15]

**Questions about exercise**:

*What role does exercise play in metabolic health?*

*What is the actual role of different types of exercise, so strength training, aerobic training?*

*What do we know about that and what have we learned from looking at people who are sedentary versus non-sedentary?*

**Overall**:

- Once you correct any glaring deficits in sleep, the more you exercise, the more latitude you’re going to have with respect to nutrition and age
- Exercise has a ton of structural benefits that pertain to health span
- But here, what we’re talking are the metabolic benefits, and the metabolic benefits come down to **glucose disposal** and **insulin sensitivity**

How it happens:

- When a person’s muscles are resistant to insulin, that is the sine qua non for the development of global insulin resistance, and the precursor to type 2 diabetes
  - The work of [Gerry Shulman](https://peterattiamd.com/geraldshulman/) and others has demonstrated what really goes wrong when fat gets into muscles.
- once fat gets into a muscle, it leads to a rise in the cytosolic level of diacylglyceride
- Diacylglyceride is like a triglyceride, except it only has two fats on it instead of three
- When this increases, it’s linked to the activation of a protein kinase, which is an enzyme involved in cellular signaling
- And this leads to a series of events that modify the insulin receptor substrate, and that disrupts the normal insulin signal processing where insulin binds to the insulin receptor, and that triggers the cascade that gets the GLUT4 transporter up to the surface of the muscle

Sedentary vs. active individuals

- When Gerry Shulman is recruiting subjects for these studies, they’re trying to look at individuals, either lean or obese, to determine insulin resistance or early signs of insulin resistance, they have to do this with sedentary individuals
- If they find sedentary individuals, even 19 and 20 years old, they’re able to identify this pattern in a way that active individuals don’t have
- It’s very important to explain that there’s several things going on:
  - First, an active individual also develops an insulin insensitive or insulin independent manner of glucose disposal
  - There is a way in which muscle contraction can produce by itself and without the activity of insulin and the insulin receptor a GLUT4 transporter moving to the surface of a muscle that brings glucose in
    - This is how patients with type 1 diabetes who don’t make any insulin, can modify their insulin demand
  - So this relationship between exercise and insulin resistance is a relationship that’s taking place at the cellular level in the muscle

Strength training vs. cardio

- advantage of strength training is you have a larger muscle, and a larger muscle is a larger reservoir for glucose
- And because glucose acutely can really only be disposed of in the muscle, the larger the muscle, the more likely you are, provided that it’s insulin sensitive, to be able to bring glucose out of the circulation.

There are numerous studies demonstrating that **exercise increases insulin-dependent glucose uptake**

- The more you’re exercising, the less you have that intramuscular diacylglyceride, the more insulin sensitive the receptors are
- A recent (2023) [systematic review and meta-analysis](https://www.nature.com/articles/s41366-023-01283-8) of 25 randomized controlled trials showed that exercising at least four weeks increased insulin stimulated glucose compared to control conditions by about the tune of 50%

*What happens during exercise vs. post exercise?*

- Insulin mediated glucose uptake is improved during exercise, but the effects persist long after exercise—again, that’s the majority of what we think of when we think of insulin sensitivity and glucose disposal
- The other example, the [non-insulin mediated glucose disposal](https://pubmed.ncbi.nlm.nih.gov/33356994/), that’s limited to the exercise period only
- In short, insulin-mediated glucose uptake rises during exercise and persists hours afterward, while non-insulin-mediated effects are limited to the exercise period

## Diet and nutrition [59:00]

Overview of nutrition as it relates to metabolic health

- The most important thing with nutrition: it’s a tool for maintaining energy balance, and it’s the most important tool for maintaining energy balance
- It gets complicated when you look at the example of the non-obese people with insulin resistant type 2 diabetes and metabolic syndrome
- To be clear, that’s about a fifth of people who are non-obese that are still metabolically sick and still at enormous risk equal, if not slightly higher risk, for metabolic disease compared to the obese people with metabolic syndrome
- Someone might say, “*Well, Peter, how can energy balance matter if those people aren’t in energy imbalance?*“
- Peter is arguing that actually they are, you just don’t really see it because they have a small “bathtub”

Bathtub analogy

- The size of your bathtub is basically how much subcutaneous fat you can store
- If you have a small bathtub…
  - The good news is you don’t get very fat,
  - But the bad news is, you are going to be very quick to damage the surrounding infrastructure of your house when the water exceeds that relatively small tub.
- Conversely, if you have a huge bathtub…
  - The disadvantage is that you’re more likely to get fatter if you eat more
  - But the good news is, you are not likely to injure yourself in the process
- And so energy imbalance is the fundamental issue.

There are two really interesting studies that highlight and allow us to uncouple the relationship between adiposity and metabolic health

The most important thing you want to take from this: it’s the ability to store fat in a subcutaneous spot is really important, and when it escapes from that, when you no longer can safely store energy, that’s where problems occur.

A [human study](https://www.nejm.org/doi/full/10.1056/nejmoa033179) from 2004

- This was conducted in a group of subjects that either had type 2 diabetes or were metabolically healthy according to normal glucose tolerance tests
- Both of these subjects underwent liposuction
- These people were removing approximately 20% of their total body fat
- The waist circumference in the people who had normal glucose tolerance test went from 110 to 95 centimeters
- In the people with type 2 diabetes, it went from 120 to about 105
- Here’s what’s really interesting
- you take all of this fat mass off these people, but there was no change in blood pressure, plasma glucose, plasma insulin, cholesterol, triglycerides, any of these metrics when they measured them again 12 weeks post surgery
- They had a significant reduction in body weight, BMI, waist circumference, but it was all subcutaneous
- Obviously, when you do liposuction, you’re not getting any of the fat out of those “dangerous spots,” and so there was no improvement in metabolic health

A [mouse study](https://www.jci.org/articles/view/7901) from 2000

- This study transplanted adipose tissue into mice with a mutation that caused a near complete absence of white adipose tissue (white adipose tissue is the safe place that you put fat)
- These animals when fed become metabolically unhealthy very quickly
- Since they can’t store that excess energy, they immediately get rid of it
- When they simply reinserted white fat cells into these patients, it reversed all of their issues

**Improving energy balance**

- Where energy balancer really matters: Energy balance matters in the liver, in the pancreas, and in the viscera
- If you have to improve energy balance, the money is on the intake side
- Don’t think of output, don’t think of exercise as the preferred tool to induce energy balance, think of it on the intake side
- Think of the exercise side as where we improve insulin sensitivity, and we rely on the intake side to achieve energy balance
- All roads lead through reduced intake

*You have three strategies to reduce energy intake*:

1. caloric restriction
2. dietary restriction
3. time restriction

⇒ For more on this check out [AMA #44](https://peterattiamd.com/ama44/)

## How reducing stress can improve metabolic health [1:05:15]

Hypercortisolemia

- The effects of hypercortisolemia is profound
- And it’s the hardest one to treat because there are lots of things that cause elevated levels of cortisol
- Sometimes they’re transient and they’re not a significant issue, sometimes they’re really elaborated
- And this tends to go very hand in hand with poor sleep
- Peter will look at things like phosphatidylserine and ashwagandha as supplements that can help reduce nighttime cortisol, improve sleep, and therefore, also improve insulin sensitivity (not backed by studies, but Peter finds it beneficial in patients empirically)

Peter talked about this a bit in the [hormone podcast](https://peterattiamd.com/endocrinesystem/) where we can look at the free cortisol pattern of an individual, and obviously, look for what elevated levels of free cortisol are doing, and how we can use adaptogens and things like that, to try to ameliorate those

§

## Selected Links / Related Material

**Meta-analysis that found metabolic syndrome is associated with an increase risk of CVD, stroke, and all-cause mortality**: [The metabolic syndrome and cardiovascular risk a systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/20863953/) (Mottillo et al., 2010) [6:30]

**Study finding that cancer risk increases with metabolic syndrome**: [Metabolic Syndrome and Risk of Cancer Mortality in Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2700189/) (Jaggars et al., 2010) [7:00]

**Meta-analysis suggests about a 24% higher risk of Parkinson’s disease in those with metabolic syndrome**: [Metabolic syndrome and risk of Parkinson disease: A nationwide cohort study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6103502/) (Eun Nam et al., 2018) [8:00]

**Study that found a 10% increase in Alzheimer’s disease for those with met syn**: [Metabolic syndrome and the risk of late onset Alzheimer’s disease: An updated review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/34039508/) (Zuin et al., 2021) [8:30]

**Episode of The Drive with Gerry Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia (peterattiamd.com) [14:30, 55:30]

**App Peter uses to assess his quality of sleep, heart rate variability, and appetite for exercise**: [Morpheus](https://trainwithmorpheus.com/) [21:30]

**AMA episode of The Drive that discussed visceral adipose tissue**: [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/) | Peter Attia (peterattiamd.com) [27:00]

**Peter’s book**: [OUTLIVE: THE SCIENCE & ART OF LONGEVITY](https://peterattiamd.com/outlive/) by Peter Attia | (peterattiamd.com) [27:15]

**A recent study characterized the variations in glucose levels at three different points during an OGTT and compared the rates of diabetes, cardiovascular disease (CVD), and all-cause mortality among individuals with different glucose patterns**: [Glucose patterns during an oral glucose tolerance test and associations with future diabetes, cardiovascular disease and all-cause mortality rate](https://link.springer.com/article/10.1007/s00125-017-4468-z) (Hulman et al., 2017) [35:00]

**The Kraft analysis which identified five patterns of glucose and insulin response**: [KRAFT PREDIABETES PROFILE: PATTERNS OVERVIEW](https://www.meridianvalleylab.com/kraft-prediabetes-profile-patterns-overview/) | (meridianvalleylab.com) [37:30]

**AMA episodes about blood glucose and CGM**: [42:00]

- [#165 – AMA #24: Deep dive into blood glucose: why it matters, important metrics to track, and superior insights from a CGM](https://peterattiamd.com/ama24/) | Peter Attia (peterattiamd.com)
- [#173 – AMA #26: Continuous glucose monitors, zone 2 training, and a framework for interventions](https://peterattiamd.com/ama26/) | Peter Attia (peterattiamd.com)

**2012 sleep study that found short sleep reduced glucose disposal**: [Impaired Insulin Signaling in Human Adipocytes After Experimental Sleep Restriction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4435718/) (Broussard et al., 2015) [47:45]

**Sleep study showing that short sleep duration was significantly associated with insulin resistance**: [Does Insufficient Sleep Increase the Risk of Developing Insulin Resistance: A Systematic Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9036496/) (Singh et al., 2022) [50:45]

**AMA episode of The Drive about optimizing sleep**: [#233 – AMA #42: Optimizing sleep – bedtime routine, molecule regimen, sleep trackers, sauna, & more](https://peterattiamd.com/ama42/) | Peter Attia (peterattiamd.com) [53:00]

**Study in people who had liposuction that showed their metabolic health did not improve despite losing weight**: [Absence of an Effect of Liposuction on Insulin Action and Risk Factors for Coronary Heart Disease](https://www.nejm.org/doi/full/10.1056/nejmoa033179) (Klein et al., 2004) [1:01:30]

**A mouse study that transplanted adipose tissue into mice with a mutation that caused a near complete absence of white adipose tissue**: [Surgical implantation of adipose tissue reverses diabetes in lipoatrophic mice](https://www.jci.org/articles/view/7901) (Gavrilova et al., 2000) [1:02:30]

**Episode of The Drive discussing hormones where they mentioned free cortisol patterns**: [#256 ‒ The endocrine system: exploring thyroid, adrenal, and sex hormones](https://peterattiamd.com/endocrinesystem/) | Peter Attia (peterattiamd.com) [1:06:00]

§

## People Mentioned

- [Jerry Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) [3:30]
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/) [14:30, 54:45, 1:02:30]
- [Inigo San Millan](https://medschool.cuanschutz.edu/deans-office/cu-med-today/profilesarchives/inigo-san-millan) [17:00]
- [Joseph Kraft](https://meterbolic.com/who-was-dr-joseph-kraft) [37:30]

§