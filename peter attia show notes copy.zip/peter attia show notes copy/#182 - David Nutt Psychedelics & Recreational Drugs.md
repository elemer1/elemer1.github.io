# #182 – David Nutt: Psychedelics & Recreational Drugs

**Source:** [https://peterattiamd.com/davidnutt/](https://peterattiamd.com/davidnutt/)

---

David Nutt is a psychiatrist, neuroscientist, and the Director of the Neuropsychopharmacology Unit in the Division of Brain Sciences at the Imperial College London. His research focuses on illicit drugs—their harm, classification, and potential for therapeutic use in psychiatry. In this episode, David discusses his framework for assessing the potential harm caused by common recreational drugs and explains how they are regulated, which is often misaligned with actual risk. He describes in detail the neurobiology, mechanisms of action, and addiction potential of alcohol, opiates, cocaine, and methamphetamine and contrasts those with psychedelics, which have been given a similar regulatory classification despite their relatively low risk of harm and their numerous potential therapeutic uses. Additionally, David explains the promise of psychedelics like ketamine, MDMA, and psilocybin for treating drug addiction and depression and discusses how political pressures have created roadblocks to future necessary research.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/davidnutt/the_Drive_public.png)

Play

#182 - David Nutt: Psychedelics & Recreational Drugs

1x15s30s

0:001:38:44

## We discuss:

- David’s early interest in the brain and experience in psychiatry [2:45];
- David’s brief work on government drug policy in the UK [10:15];
- A scale for rating the relative harm of certain drugs [13:45];
- The contrast in regulation between cannabis vs. alcohol and why research on potential benefits of cannabis is lacking [19:15];
- The opiate crisis and rise of fentanyl: the cause and potential solution [25:00];
- The science of addiction and the potential use of psychedelics for treating drug addiction [35:00];
- Cocaine: mechanisms of action and risks [41:45];
- Methamphetamine and crystal meth: mechanisms of action and neurotoxicity [48:15];
- How psychedelics came to be classified as schedule I drugs despite their numerous therapeutic uses [52:45];
- The history of MDMA and the bad science and political forces leading to its demonization [1:08:45];
- History of ketamine, medical use of esketamine, and the waning effects of psychedelics with increasing usage [1:13:30];
- Psilocybin for depression: David’s promising research and the roadblocks to more robust experiments [1:20:15];
- More.

§

## Show Notes

## David’s early interest in the brain and experience in psychiatry [2:45]

**David’s interest in the brain**

- At age 4 or 5 he realized that thinking comes out of the brain
- He did his undergrad at [Cambridge](https://www.cam.ac.uk/) in brain science
  - He wanted to be a physiologist, like [Hodgkin](https://en.wikipedia.org/wiki/Alan_Hodgkin) and [Huxley](https://en.wikipedia.org/wiki/Andrew_Huxley), to do physiology
- He realized that some single cells are interesting, but one has to put the 200 billion together and make sense of them
- He worked in neurology and found it boring because most people are dying slowly from diseases like [amyotrophic lateral sclerosis](https://medlineplus.gov/genetics/condition/amyotrophic-lateral-sclerosis/)
- Next he moved to psychiatry and found it wonderful because one sees “*every aspect of the brain in psychiatry*”
- Peter’s son (6 years old) asked about the brain and if it was where thoughts come from and how this happens
  - This is difficult to explain on a simple level
  - The brain is where memories are stored but the deep question of “how does this blob make me think” is difficult to answer
  - Peter was happy his son asked this question because he never contemplated this at such a young age
- David’s latest book is called [Brain and Mind Made Simple](https://www.amazon.com/Brain-Mind-Made-Simple-David/dp/1914603001/ref=sr_1_5?crid=2B4KX38CEMS1I&dchild=1&keywords=david+nutt&qid=1633438293&s=books&sprefix=david+nutt%2Caps%2C185&sr=1-5); it’s written for the general public to explain as David puts it, how “*lots and lots of single nerves can actually turn into all the complexity of the different forms of consciousness and the different experiences humans have*”

**David’s early impressions about the pathology of the mind**

- The first patient he saw as a psychiatrist (during medical school) kept rambling about a smell of fish in the room and didn’t make any sense for the half hour they spent talking
  - David spoke to the consultant who said simply the patient is psychotic and that’s why he doesn’t make any sense
  - He found the relationship between temporal lobe disorders interesting
    - These are the parts of the brain which are intimately involved in aspects of consciousness
    - There is a peculiar overlap between temporal lobe disorders where one can be psychotic and have these olfactory hallucinations
  - He never forgot this bizarre experience of the patient hallucinating in terms of smell
  - This made him realize he had a lot to learn

**David’s career in psychiatry and neuroscience**

- [David](https://www.imperial.ac.uk/people/d.nutt) is a professor of neuropsychopharmacology at [Imperial college, London](https://www.imperial.ac.uk/brain-sciences/research/psychiatry/)
  - Neuropsychopharmacology is really the use drugs to study the brain and to study the effects of treatments for brain disorders
- His PhD focused on the GABA system of drugs, and manipulating this system
- As an undergraduate he was extraordinarily fortunate to be at the University of Cambridge in the early ‘70’s when people are discovering that the brain is a chemical organ
  - Prior, it was thought the brain was an electrical organ similar to a complicated computer or telephone exchange
  - The concept of chemical transmission came along and now it is known that there are at least 80 different chemicals, neuro-transmitters, hormones, neuro-hormones

> “And seeing that transformation from electricity to chemistry made me realize the way you study the brain now is through drugs, which affect the chemistry of the brain.” – David Nutt

- Drugs can be therapeutic agents: antidepressants, anti-psychotics, anticonvulsants
- Drugs are also used to change the brain or recreationally: cocaine, crystal meth, psychedelics
  - They are used to deaden pain or gain insights (i.e., psychedelics)

## David’s brief work on government drug policy in the UK [10:15]

- David was asked by the British government to help them justify drug policy in the ‘90’s
  - He worked on the [Advisory Council on the Misuse of Drugs (ACMD)](https://en.wikipedia.org/wiki/Advisory_Council_on_the_Misuse_of_Drugs)
  - This is when he realized the drug policy wasn’t evidence-based in any way
  - When he tried to bring evidence to bear on drug policy he was fired
    - Drug policy was based on political decision making not evidence
  - In the ‘90’s he was asked to come up with a policy which would reduce the harms from ecstasy
    - He realized that the harms of ecstasy aren’t from the drug at all, they’re actually from **what one does when on the drug**
      - Dehydration from dancing all night
      - Hypothermia from being in an environment where one cannot cool down
    - He recommended 2 simple policies; environmental approaches drastically reduced the number of deaths from ecstasy
      - 1) Clubs that serve alcohol should provide free water

- - - - - When people choose between paying for alcohol or water they end up dehydrated from drinking too much alcohol
        - Clubs were making matters worse by turning off the taps in the bathroom so people couldn’t drink water
        - The law changed to allow people access to water
      - 2) Clubs should also provide chill out rooms
        - David notes there have been very few deaths “from ecstacy” since those policies were implemented

- - - Now however, a variety of international policies have now made ecstasy considerably more harmful than it used to be

- UK drug policy follows the United States

> “Every single British drug law until 2016 was made at the behest of the Americans. . .they say America sneezes, the world catches cold.” – David Nutt

- America defined drug policy
  - In 1934 with liberalization of drinking alcohol and attack on cannabis
  - The big inflection came when Nixon decided that the war on drugs war better at gaining votes than the war in Vietnam; he switched people’s attention to drugs

## A scale for rating the relative harm of certain drugs [13:45]

Peter says: “*the goal of frameworks is to have them be as unemotional as possible and to have them, whenever possible, to be objective*.”

**Peter says drugs can be classified according to…**

1 – how harmful they are

- To the individual
- To the society

2 – how addictive they are, and

3 – the physiologic dependence they cause

**David’s** ***multi-criteria decision analysis***

- There are **16 ways** in which drugs can do harm
  - 2015 publication [European rating of drug harms](https://pubmed.ncbi.nlm.nih.gov/25922421/)
  - 9 harms to the user & 7 harms to society
  - Societal harms range from international damage, like the US spraying agent orange in Columbia to kill cocoa plants through to economic damage, through to health costs, through to damage to families, et cetera
  - One can scale drugs on each of those 16 scales of parameters of harm
    - Not all of these scales are equally important
    - This procedure is used in Britain, Europe, and recently in Australia
    - “*you can actually very, very transparently and very reliably rate the harms of different drugs*”

*Drugs that consistently come to the top of the list for causing harm*

- *Alcohol causes the most aggregate harm*

- - It has way more social impact, more harms to others than any other drug
  - It’s also more widely used, 80% of American and British adults drink alcohol

- *Opiates, crack cocaine, and also crystal meth are the most harmful to the* ***user***

- - These drugs have very different scheduling, see the [DEA Resource Guide](https://www.dea.gov/sites/default/files/2020-04/Drugs%20of%20Abuse%202020-Web%20Version-508%20compliant-4-24-20_0.pdf)
  - Heroin would be a schedule I drug
  - Cocaine would be a schedule II drug
  - Crystal meth would be a schedule I or II drug
- Alcohol is not even scheduled with other drugs
  - It’s only regulated by the age at which one can legally consume it
  - It’s also taxed
- Tobacco is interesting, when David first used the harms list, it came in at 6 or 7
  - The anti-tobacco brigade became really agitated; they made the argument it is the most  harmful because it kills more people
    - But people often die in their 50’s or 60’s
    - Alcohol kills people in their 20’s; David thinks this is more important

- - - T*obacco does in the end kill half of the people who smoke, but this happens later in life and causes relatively little damage to other people, unlike alcoho*l

- Peter points out, there is no *moderate* use of tobacco where it provides a benefit without taking some toll on the pulmonary and cardiovascular systems
  - Benefits of nicotine are to help one cope with nerves and calm down

- - *Tobacco has no acute toxicity*

- - Alcohol in contrast, a person could drink responsibly (consume only a few drinks) without any cost to health
    - Peter could argue “*that there’s no dose of alcohol that’s healthy, but there are probably doses that don’t rise to the level of toxicity*”

- A*lcohol has both acute toxicity and chronic toxicit*y

- - It’s that acute toxicity that results in incredible loss of life, both to the individual and to society
- This framework allows drugs to be given absolute ratings and rankings on variables such as **acute toxicity versus chronic toxicity**
  - Drugs that score badly on both are opiates
    - Opiates can kill one instantly but could also kill one over time

## The contrast in regulation between cannabis vs. alcohol and why research on potential benefits of cannabis is lacking [19:15]

- Tobacco doesn’t bring many benefits *yet nicotine is the only drug known that both calms people and improves attention*

- *Alcohol is one of the most social drugs; this is why people use it*

- - It has a powerful pro-social effect
  - This is probably why it has been stable in our society for many millennia

**What is the source of the hypocrisy of why alcohol is legal and cannabis is not?**

- Cannabis is not a particularly social drug; it’s not a party drug
  - When people get stoned, they tend to be quieter

> “People are less positive towards cannabis because it isn’t so socially enabling as alcohol.” – David Nutt

- David took a different view up until now, which is “*people have been very anti-cannabis because the alcohol industry and the drug enforcement agency have seen cannabis as the enemy*”
  - The disinformation that’s driven the hatred of cannabis started with [Harry Anslinger](https://en.wikipedia.org/wiki/Harry_J._Anslinger), trying to keep the DEA functioning after alcohol prohibition was disbanded

> “90 years of disinformation has actually poisoned a lot of people’s minds to cannabis” – David Nutt

- Alcohol has been celebrated throughout history in terms of art and culture and music and television
  - David remarks on the disclaimer he has seen on may programs on Netflix “This program contains product placement”; which means the program shows people drinking a lot of wine
- Peter had not considered that the DEA needed a reason to exist and created a boogeyman, cannabis

**Absence of studies on recreational drugs**

- As an outsider, Peter has a lot of questions and finds it frustrating the lack of study of recreational drugs
  - Patients ask him questions, “*If my 16 year old son is smoking pot, is that going to have a negative consequence on his or her brain development?*“
  - There are not rigorous studies to point one way or the other
  - This is a real missed opportunity for the last 100 years, studying cannabis and other drugs
  - David points out that “*it’s worse than that. I mean, the reason that the studies have not been done is because almost all the funding for that kind of research in America comes through the government through* [*NIDA*](https://en.wikipedia.org/wiki/National_Institute_on_Drug_Abuse)”
    - [NIDA](https://www.drugabuse.gov/) has not been funded to study the benefits of cannabis
    - Even when California voted to make medical cannabis legal, federal law still made it illegal and research could not be funded
    - David notes “*it’s one of the many examples of the perverse negative consequences of this prohibitionist approach to drugs*”

## The opiate crisis and rise of fentanyl: the cause and potential solution [25:00]

**First a discussion about psychedelics like MDMA, LSD and mushrooms**

- [MDMA](https://en.wikipedia.org/wiki/MDMA) is a schedule I drug
- MDMA was on the the first drugs David was looking at in terms of policy decisions
- In 1994 David started working for the British government’s [Advisory Council on the Misuse of Drugs](https://en.wikipedia.org/wiki/Advisory_Council_on_the_Misuse_of_Drugs) (ACMD), he assumed what they told him about the harms of drugs was right
  - As he learned more details he discovered they were completely wrong – “*I’d been completely lied to*.”

- - *At the most harmful end of drugs is alcohol and at the least harmful end are magic mushrooms, LSD, and MDMA*

> “The real paradox of doing this really in-depth, multi-criteria decision analysis is it turns out that the drugs that have been most vilified and which we’ve been taught are the most dangerous, turned out to be the least dangerous.” – David Nutt

**Drugs that harm only the individual [26:15]**

1. The most harmful drugs in terms of acute risk and chronic mortality are heroin, fentanyl, and their cousins
2. Second are the cocaine derivatives
   - Crystal meth is probably more harmful than crack because it lasts longer in the body and the brain
3. Third are the amphetamine derivatives
4. Other drugs causing great harm to the user are opiates

**The opiate crisis**

- For [Opiates](https://www.drugabuse.gov/drug-topics/opioids), they kill by respiratory depression — “*You take just too much [heroin, fentanyl] and you stop breathing*.”

> “Almost nobody in America doesn’t know somebody whose life has been destroyed by alcohol. We’re getting pretty close to that with opioids. I mean, I personally know three people, is it four? Maybe four, who have lost a child or relative to an opioid overdose.” – Peter Attia

- David remarks that “*the fentanyl crisis is very much an American problem*”
- It has caused a disproportionate number of deaths in the US even when correcting for population size
  - Last year more people died of opiate overdose, than died in the whole of the Vietnam war
  - 2020 saw the most overdose deaths (from all drugs) in the history of the US
- A “perfect storm” of things have led to this crisis
  - 1) There was excessive roll-outs of strong morphine-derivative painkillers which were heavily promoted by some pharmaceutical companies
  - 2) Chronic pain is very common, affecting maybe a quarter of the country


- - - So doctors prescribe when there is no other treatment such as physiotherapy or occupational therapy
    - But prescribing opiates is not good for chronic pain
    - The states that have the highest prescription levels of opiates for chronic pain are the ones that don’t have medical cannabis
    - Medical cannabis is better than any other drug for treating chronic pain
  - 3) Dispersion of opiates into society; parents and kids were taking [oxycodone](https://www.rxlist.com/oxycontin-drug.htm) and dying


- The reaction to the crisis was to stop prescribing
  - But people are dependent on an opiate and they’re not provided with something else, like medical cannabis
    - Now users are going through withdrawal
    - They turn to the black market
    - This reaction creates a paradox where despite stopping the prescriptions, there is a rise of heroin and fentanyl deaths because this is what the black market provides

- **The rise of fentanyl – “***The most damaging part of the cycle is the rise of fentanyl*”

- - This wasn’t a big issue until demand came from people previously on oxycodone
  - The United Nations was limiting access to heroin by controlling the amount of poppies that could be grown in an attempt to prevent heroin misuse
  - The Mexican cartels realized they couldn’t make heroin because they couldn’t get enough morphine so the looked elsewhere and discovered fentanyls
- Even the simplest fentanyl is 50 times more potent than heroin and twice as cheap to make
  - Super fentanyls (like carfentanil) are 1000 times more potent

> “So you see, it’s a cycle, a series of mistakes which has actually just led to this terrible tsunami of deaths” – David Nutt

**What’s the solution to the potential solution to the opiate problem? [31:30]**

*David says “the only way to deal with it” is …*

1. Have lots of testing to allow people to take anything they’ve got and get it tested, so they know what it is; eliminate fentanyls
2. Bring in much safer treatments for people in chronic pain, like medical cannabis

**Ibogaine**

- Peter asks about [Ibogaine](https://en.wikipedia.org/wiki/Ibogaine) (a derivative of [iboga](https://en.wikipedia.org/wiki/Tabernanthe_iboga)), a plant alkaloid that seems to be efficacious in relieving people from the throws of opioid addiction
  - It’s a psychedelic
  - It has some level of cardiac toxicity, it’s not clear if this has been over- or understated
- David is in the process of trying to do a study on this
  - He’s working with a company that’s developing a derivative of ibogaine called noribogaine, which may be less cardiotoxic
  - He’s doing brain imaging to determine if it’s a normal psychedelic or not
- It’s used widely in some third world countries as a therapy for opiate withdrawal
- It’s also a licensed medicine in New Zealand but they stopped using it after 1 death
- Peter has read that the risk of a fatal arrhythmia might be one in a thousand
  - 1 in 1000 is an enormous risk but not so much compared to a person remaining addicted to opioids which may be something like 300 out of 1000
  - David points out that there are plenty of drugs that have cardiac effects and are used by cardiologists
- Giving ibogaine in a hospital setting would increase safety
  - David says it’s largely being given during withdrawal from opiates but he’s not so sure that is the right time to give ibogaine b/c it might be toxic during withdrawal
  - David points out that other treatments for opiate users have been toxic in withdrawal as well
  - [Withdrawal](https://en.wikipedia.org/wiki/Opioid_use_disorder#Withdrawal) is a serious medical problem – “*I think adding a burden to someone who’s in withdrawal is not a sensible idea*.”

> “My thinking is that, if we can restore a sensible balance with ibogaine, we could potentially use it.” —David Nutt

## The science of addiction and the potential use of psychedelics for treating drug addiction [35:00]

*David thinks psychedelics (like psilocybin or DMT) could help people overcome addiction by disrupting:*

1. Learned, persistent patterns of over-attention
2. Increased, enhanced love for drugs

**The default mode network (DMN) and its role in addiction**

- Current thinking about how psychedelics might be used in psychiatry is built from this remarkable finding that the psychedelic state is a state where you have completely disrupted the [default mode network (DMN)](https://en.wikipedia.org/wiki/Default_mode_network)
  - David describes the DMN  as “the network in the brain in which is your main sense of self, the core of you”
  - Embedded in this are any depressive thoughts, love objects, and addictions
  - It’s the part of the brain where one encodes themselves, referential memories, and plans
  - It coordinates access to memories, good and bad, use of drugs, resistance to drugs, etc.
  - If the frontal part of the DMN is damaged, a person’s personality changes
  - If the posterior part of the DMN is damaged, the person struggles with coordination and integration; they become very strange
- *The DMN can be disrupted with psychedelics*
  - In a simplistic way some elements of the DMN become misaligned or malignantly over engaged with negative thinking in depression or compulsive attitudes, seeking and use of drugs
  - If this can be disrupted with psychedelics the maybe people can restore a normal balance in that network and gain a more rational approach
- The brain has a role in determining things like addiction
- Dissociating a person from their DMN might be a way iboga could help rewire the brain to escape addiction
  - Even though people don’t want to use drugs, they often find themselves doing it because their brain is driving them that way

**Why do people become addicted?**

- Susceptibility to addiction is likely [polygenic](https://en.wikipedia.org/wiki/Polygene), there is not a single gene involved
- *Social factors are hugely important; think of downtown Baltimore* *in the TV show* [*The Wire*](https://en.wikipedia.org/wiki/The_Wire)
  - Peter did his residency in Baltimore; he took care of patients in The Wire
  - It’s a frightening place
  - When Peter learned he would do his residence in Baltimore, a friend a year ahead of him in med school already in Baltimore recommended he read the book [The Corner](https://www.amazon.com/Corner-Year-Life-Inner-City-Neighborhood/dp/0767900316/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1633457481&sr=1-1) (The Wire is based on this) with the advice that it would give Peter a sense of empathy for the patients he would be taking care of
    - It’s a riveting book
  - David remembers taking a train from Philadelphia to Washington and as they pulled out of Baltimore he thought the downtown looked like a war zone, like Hiroshima
    - He thought for people living there without a job the only thing they can do is deal drugs and take drugs

**Who becomes addicted?**

- Drugs is something that takes away the misery of one’s life; coping with life stress is one reason people use drugs
- Some very rich, successful people get into problems with opiates
  - Tatum O’Neal, youngest ever Oscar winner, marries the best, greatest tennis player, John McEnroe, they have two wonderful kids and a life that everyone envies but then she comes out of heroin treatment and says “The only time I felt whole was on heroin”

- *David sees this in patients (heroin or alcohol); the drug makes them what they want to be*

- - They feel that only when they’re drunk that they’re actually functioning normally

- *David wonders if this gap that patient’s fill with drugs could be refilled (or remodeled) with psychedelics*

- Some people use drugs to get high and find their brain becomes sensitized to drug use; they lose control, like the classic experience with cocaine or crystal meth

## Cocaine: mechanisms of action and risks [41:45]

- David gives a lecture titled “Was Freud right to give up on psychopharmacology?”
  - [Freud](https://en.wikipedia.org/wiki/Sigmund_Freud) was a great protagonist; he used cocaine himself
  - He thought cocaine was a very powerful drug for getting people off heroin
  - He didn’t realize that cocaine also caused dependence
  - In fact, Freud and his protege both became cocaine dependent
- Peter adds another [Hopkins](https://www.jhu.edu/)/ Baltimore link, the first chief of surgery at Hopkins, [William Stewart Halsted](https://en.wikipedia.org/wiki/William_Stewart_Halsted), himself became addicted to cocaine when he became obsessed with it as a local anesthetic
  - David notes that now the anesthetist gets addicted to [remifentanil](https://www.rxlist.com/ultiva-drug.htm)
- David’s impression of Freud was that he went into psychology was because he became completely terrified of pharmacology
  - Maybe Freud assumed any drug would have a problem with dependence
  - Maybe cocaine could be credited for the development of psychoanalysis

- *In the modern era, cocaine is the ultimate fun drug*

- - It gives one energy, drive, an enormous sort of sense of focus and purpose
    - This is due to the release of dopamine and noradrenaline in the brain, but it’s very spiky
  - And then it gives one a terrible crash
    - During the course of a binge over the weekend, the brain gets perturbed, and then people start to get paranoid, and withdraw

- *Problems with cocaine*

- - Some of them will get sensitized and become addicted
  - Some of them will die because of a cardiac effect.
  - Also, there’s this problem of mixing cocaine and alcohol
    - When cocaine and ethanol are both present in the blood, the liver forms cocaethylene
    - Cocaethylene is a longer acting and more cardiotoxic version of cocaine

- - *Peter doesn’t think cocaine is worth the risk, a view he shares with patients*
    - He has a simpler framework for viewing drugs, which is really only two leavers:
      - *1) What is the physical risk of this drug to an individual*?
        - ***Cocaine risks***
          - What is the true risk of cardiotoxicity?
          - What is the risk of deepening physiologic dependence over time?
      - *2) Is this a drug that only alters one’s state, or does it have the potential to alter a trait*?
        - This is borrowed from a book called [Altered Traits](https://www.amazon.com/Altered-Traits-Science-Reveals-Meditation/dp/0399184392/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1633611050&sr=1-1), that gets into this distinction

- Psilocybin for anybody who’s ever taken it, is clearly a drug that alters one’s state
  - But only altering one’s state probably wouldn’t lead someone to take a drug, because it’s really not that pleasurable

- *The real benefit is to alter a trait such as: depression, smoking cessation, or something else*

- - If a drug alters one’s state but not a trait (or how one behaves off the drug) the question becomes – is it worth it?
    - Peter doesn’t think cocaine can do this

- - - *In his mind, cocaine has 2 strikes against it – 1) a serious physical risk and 2) it’s not going to make life better when not on the drug*

- David finds this analysis of cocaine interesting; he agrees for crack but is not sure for cocaine
  - Some people can use cocaine once or twice a year without getting into much difficulty
  - But he wouldn’t be using it at his age
- Consider the story of [Len Bias](https://en.wikipedia.org/wiki/Len_Bias) in 1985
  - He was a famous college basketball recruit
  - He played basketball at the University of Maryland
  - He was a complete superstar, on the level of a Michael Jordan
  - He was drafted by the Boston Celtics, and probably would have altered the course of the NBA for the next 10 years
  - The day after the NBA draft he was back in Baltimore, celebrating with friends, using cocaine at a party in their dorm room when he has a sudden cardiac arrest and dies
    - This shocked the nation and reinforced the Nancy Reagan ‘just say no’ mantra and the war on drugs
    - Seeing the healthiest 21 year old in the country die was shocking
    - This was just cocaine, it wasn’t laced with anything
- David notes that super fit athletes may be more susceptible to sudden death
  - A star player from the European Football Championships, [Eriksen from Denmark](https://en.wikipedia.org/wiki/Christian_Eriksen), had a cardiac arrest on the pitch
  - Athletes, when they’re big and have some kind of cardiomyopathy are paradoxically more vulnerable than other people to cardiac effects

## Methamphetamine and crystal meth: mechanisms of action and neurotoxicity [48:15]

**Dangers of crystal meth**

- The Netflix series, [Breaking Bad](https://en.wikipedia.org/wiki/Breaking_Bad), brought awareness to these drugs

- *The dangers of methamphetamine are similar to cocaine*

- David remembers “as a junior doctor, my very first period as a junior doctor, giving methylamphetamine intravenously to a man who had serious status [asthmaticus](https://en.wikipedia.org/wiki/Acute_severe_asthma)”

- - *Amphetamines were developed as a treatment for asthma as an alternative to* [*ephedra*](https://en.wikipedia.org/wiki/Ephedra)

- - - Ephedra is a natural plant product discovered to have bronco-dilating properties back in the 1800s
    - The plant couldn’t supply the demand; so German pharmaceutical companies made a synthetic ephedra, called amphetamine
  - Amphetamine was used largely for the treatment of asthma
- It was during the second world war, when people realized amphetamines could actually be used to keep soldiers awake
  - The history of drugs and war because they tell us quite a lot about the consequences of drug use
  - The Brits and Americans used amphetamine sulfate
  - The Germans and the Japanese thought they were really clever because they had this super amphetamine, called methamphetamine, which lasts a lot longer

- - - *But they didn’t realize that longer is not better*

- - - The turning point of the war was during the North African campaign when the Germans were pushed back, when they got to Egypt
      - Rommel was pushed back by the [Desert Rats](https://en.wikipedia.org/wiki/7th_Armoured_Division_(United_Kingdom)), the Allied troops, the Australians
      - The Desert Rats would be up all night working around the Germans, harrying them, blowing them up, and then they’d go back or they’d be up all night on amphetamine sulfate and then they go back and they’d sleep all day
      - The Germans would take methamphetamine to stay up to defend themselves against the Desert Rats, *but they couldn’t sleep in the daytime; and eventually they became sleep deprived and paranoid* (the same with Japanese)
        - The Japanese had these *terrible sensory somatic hallucinations from using large doses of crystal meth for long periods*

- - - - - *So crystal meth is longer acting and probably more neurotoxic that amphetamine sulfate*

**Neurotoxicity of crystal meth**

- Crystal meth pushes the [dopamine system](https://en.wikipedia.org/wiki/Dopaminergic_pathways) to a point where it’s probably depleted and that seems to then lock them into a state where they can’t really function normally in the world without taking the drug
- It may also damage the dopamine pathways to the [frontal cortex](https://en.wikipedia.org/wiki/Frontal_lobe), which impairs their ability to make judgments, executive functioning, etc (though there is less good evidence for this)
- The big concern about crystal meth came after the Second World War; there were factories, crystal meth factories in Japan with barrels of this stuff; and there were a lot of Japanese soldiers who had nothing else to do

- - *Soldiers took huge doses of crystal meth, often intravenously and suffered brain damage*

- - There’s not as much evidence for brain damage as it’s used now, orally in more prolonged periods

- - *David’s not sure if crystal meth causes cortical damage but it definitely distorts the dopamine pathways in the brain*

- - - *It will affect one’s motivation and ability to get up and activated*

## How psychedelics came to be classified as schedule I drugs despite their numerous therapeutic uses [52:45]

- Schedule I drugs are viewed by the DEA as both as *dangerous* in terms of harm or risk of addiction *and as medically useless*
- **Cocaine** does not fit in schedule I (even though it is highly addictive) because it has appropriate medical use as an anesthetic, especially in the nose
- **Fentanyl** is not schedule I (even though it’s highly addictive) because it has a pain-blunting effect
- Surprisingly, **psilocybin, MDMA, and LSD** are schedule I

**Why LSD was banned**

- David notes that psychedelics were banned, not because they had any negative impact, but in the face of opposition
  - [Bobby Kennedy](https://en.wikipedia.org/wiki/Robert_F._Kennedy) (when he was Secretary of State) confronted the DEA and the FDA when they said, “We want to ban LSD” because he knew billions of dollars had been spent researching LSD, there were loads of positive results, even his wife was being treated

- - - *The DEA and CIA wanted to ban LSD because it was seen as fueling the hippie movement, and the hippie movement was opposed to the war in Vietnam*

- - - - They were trying to stop protest of the Vietnam war
      - LSD was changing the way people voted
      - So social ‘harms’ were found against LSD; absurd claims were made and LSD was banned

- - - - *LSD was banned for political and social reasons, not because of any harms*

- - - Robert Kennedy  was encouraging a fundamental change in the American way of life through using drugs
      - He popularized LSD and encouraged people to think differently about society
      - There was a genuine fear that Americans would actually cease to want to fight wars and actually want to have peace and that was just seen as being extremely bad for the American economy and of course the American presence internationally
- Prior to the scheduling of LSD, there were over 130 grants issued to study it
  - LSD was a drug manufactured in the late 1930s by the pharmaceutical company Sandoz

- - *There were 40000 patients studied and a 1000 papers published on LSD*

- - - LSD was actually very safe; it didn’t cause psychosis
    - It reduced suicide rates compared with nontreatment of depression
      - In the 50’s antidepressants had not been invented yet and there were few alternatives
    - With LSD began the dawning of real psychiatry, incorporating it into the rest of medicine with the advent of tools (other than talking) that could help people

- *LSD was used in 2 different ways in psychiatry*
  - 1) Give a large dose; cause a big, few-hour trip, then and then afterwards help the patient work out what the trip meant

- - - It was always done in the context of psychotherapy because in those days, all American psychologists were effectively Freudian analysts
    - 100-125 micrograms
  - 2) Give lower doses repeatedly to try and break down psychological resistance to actually engaging in psychotherapy

- - - 25 micrograms weekly for 10, 15, 20 treatments
    - Anything over 10 micrograms is perceptible; it’s not psychedelic but things feel different

**The scheduling of LSD and psilocybin [1:00:15]**

- Peter remarks “*it’s just an unbelievable loss to the scientific community when LSD becomes scheduled*”
  - David agrees and adds that the biggest loss relates to alcoholism

> “The founder of alcoholics anonymous, Bill Wilson… he escaped the chains of his alcoholism through a psychedelic experience” – David Nutt

- - [Bill Wilson](https://en.wikipedia.org/wiki/Bill_W.) tried LSD when it was legal and said “Wow, this drug could help lots of alcoholics escape from this belief that the only thing that matters to them is alcohol. It could give them a sense that there is more, that it is possible to change.”
    - He was instrumental in 6 trials of LSD for alcoholism, using 1 or 2 doses of LSD
    - A few years ago, a couple of Norwegians went back and they dug out the old data and they did it, put it through a modern meta analysis, collated all the data
      - 2012 publication: [Lysergic acid diethylamide (LSD) for alcoholism: meta-analysis of randomized controlled trials](https://pubmed.ncbi.nlm.nih.gov/22406913/)

- - - - *These studies show that a single dose of LSD was associated with a decrease in alcohol misuse*

- - - - - This effect is twice that of any subsequent treatment for alcoholism
        - LSD was a revolution in the treatment of alcoholism

> “LSD was a revolution in the treatment of alcoholism. Now in the 50 years since LSD’s been banned, you can make a rough calculation worldwide. Over a hundred million people have died prematurely from alcohol use disorder. And if LSD helped perhaps just 10% of them, that would be 10 million lives saved.” – David Nutt

- How many lives have been saved by banning LSD?  Maybe 50 lives per year, globally
- David thinks the ban on LSD is the worst censorship of research in the history of the world

**Harms of LSD**

- People do dangerous things when they’re taking LSD in dangerous places (this can be mitigated)
  - Put this in context, each year in Britain probably 20 to 30 people die jumping (usually drunk) from piers or bright waters or even from hotel balconies into the swimming pool
    - David  imagines it’s even worse in the States
    - Peter points out this says nothing of automotive accidents and liver toxicity and respiratory depression
  - If LSD is taken in a dangerous situation without someone to look after the user, of course there’s a risk

- - *But when LSD was used in these 40000 patients in hospitals, there was very little evidence of any harm at all*

**History of psilocybin use**

- Psilocybin has been around a lot longer; it’s present in mushrooms
  - There are about 200 species of magic mushrooms, different ones in different parts of the world
- In the beginning of the psychedelic revolution with LSD, [Hoffman](https://en.wikipedia.org/wiki/Albert_Hofmann) and [Gordon Wasson](https://en.wikipedia.org/wiki/R._Gordon_Wasson) were the American [mycologists](https://en.wikipedia.org/wiki/Ethnomycology) who discovered a tribe in Mexico that were using mushrooms for psychedelic experiences and then destroyed their culture by making them a target for tourism
- Psychedelic mushrooms have been around forever because mushrooms have been around before humans
- One of the interesting theories about Hinduism, David often wonders why Hindu gods have so many arms… well, it’s probably because the first people that became Hindus had been using this cocktail called Soma
  - The term Soma was adopted by [Aldous Huxley](https://en.wikipedia.org/wiki/Aldous_Huxley) in his book ‘[Brave New World](https://en.wikipedia.org/wiki/Brave_New_World)’
  - Soma was a powerful mixture, probably of magic mushrooms, Ephedra, and cannabis
  - David remarks “*You mix that lot together, it’s not surprising your elephants have five heads and four arms*”
- Psilocybin (the active ingredient in magic mushrooms) was discovered by Hoffman because Wasson went to him and said, “Why is this causing hallucinations like LSD?” And he said, “Oh, because it looks a bit like serotonin, a little bit like LSD.”

> “And how can you be worried about magic? It’s only a mushroom” – David Nutt

- David has been working on psilocybin for several reasons
  - 1) Psilocybin doesn’t have the stigma of LSD; politician’s don’t know what it is
  - 2) There wasn’t any good safety data on these

- - - In Britain, magic mushrooms were legal until 2005
    - He knew about a million young people a year were using mushrooms and persuaded the regulators to let him use mushrooms because that body of evidence was adequate to show safety

**What happened in 2005 to cause psilocybin to be scheduled?**

- Psilocybin was banned in ’71 alongside LSD, [DMT](https://en.wikipedia.org/wiki/N,N-Dimethyltryptamine)
- Mushrooms weren’t banned initially because there’s not much of it and no one cared
- This changed when a couple of head shops in [Camden Town, North London](https://en.wikipedia.org/wiki/Camden_Town) started selling freeze dried mushrooms
  - Freeze drying would concentrate the dose and allow magic mushrooms to be sold commercially in London

- - *The idea of youth having a psychedelic trip in London made the right-wing press go wild*

- Banning was a classic example of political expediency
  - The [Tory party](https://en.wikipedia.org/wiki/Tories_(British_political_party)) had lost the third election in a row to the [Labor Party](https://en.wikipedia.org/wiki/Labour_Party_(UK)), Tony Blair’s Labor Party and they brought in a new guy called [David Cameron](https://en.wikipedia.org/wiki/David_Cameron)
  - David Cameron spoke about his previous drug use and was in favor of drug reform; when he became the leader of the Tory party, he became anti-drugs because that’s what he was told to do
  - [Tony Blair](https://en.wikipedia.org/wiki/Tony_Blair) instead of saying, “Don’t be stupid,” he did what many liberal leaning politicians do
    - Exemplified by Clinton, he was the guy that was told the Democrats had to be harder on drugs than the Republicans and he’s the guy with the three strikes and you’re in prison forever.
    - The same happened with Labor, they were told if you’re not tougher on drugs or as tough as the Tories, you’re going to lose the election
    - Blair was goaded into making the mushrooms illegal and he did it without consulting the regulators; he actually broke the law

- - - *Now mushrooms are illegal, as well as the active ingredient*

## The history of MDMA and the bad science and political forces leading to its demonization [1:08:45]

- MDMA itself is not really a [classic psychedelic](https://en.wikipedia.org/wiki/Psychedelic_drug)
  - MDMA is more of an [empathogen](https://en.wikipedia.org/wiki/Empathogen%E2%80%93entactogen)
  - [Ketamine](https://en.wikipedia.org/wiki/Ketamine) as more of a [dissociative](https://en.wikipedia.org/wiki/Dissociative)
  - [Ibogaine](https://en.wikipedia.org/wiki/Ibogaine) is an atypical dissociative drug (discussed earlier)
- People confuse MDMA and ecstasy ([according to the DEA](https://www.dea.gov/sites/default/files/2020-06/Ecstasy-MDMA-2020_0.pdf), ecstasy usually contains MDMA plus other drugs)
  - [Rick Doblin](https://en.wikipedia.org/wiki/Rick_Doblin) has been on the podcast before and went incredibly deep on the benefits of treatment for PTSD; he talked a lot about [MAPS](https://maps.org/) (the Multidisciplinary Association for Psychedelic Studies); [episode #65](https://peterattiamd.com/rickdoblin/) is a great overview
- David notes that “*MDMA is a great American invention*”
  - Top drug chemist [Sasha Shulgin](https://en.wikipedia.org/wiki/Alexander_Shulgin) was studying derivatives of amphetamines
  - MDMA was made back in 1904 as a possible agent for blood clotting, but it never got used
  - Shulgin made it in the sixties and said, “Wow, this drug is different from amphetamines. It’s not activating. It’s not driving me like amphetamines. It’s actually giving me a clarity of thought, but also a sense of warmness and empathy.”
    - Shulgin gave it to his wife and she said *“Wow… this is empathy. This will be really useful in psychotherapy in couples counseling, it would potentially help break down those layers of irritation and grit that build up in relationships sometimes. Put people back into love.”*
      - It was widely used for about 10 years by therapists, particularly in the West Coast of the States
- Some of the worst science that has ever been done is the science proving or supposedly proving that MDMA is harmful
  - An [amazing experiment](https://www.science.org/doi/10.1126/science.1074501) that was done by [Ricaurte](https://en.wikipedia.org/wiki/George_A._Ricaurte), which is really embarrassing for Johns Hopkins, when he claimed that taking MDMA and listening to [The Pogues](https://en.wikipedia.org/wiki/The_Pogues) (Celtic punk music) overnight gave monkeys brain damage
    - Other experts in the field questioned these findings since none of the kids coming out of clubs had brain damage
  - His work was published in Science despite the fact the referee said, “This has got to be wrong.”
    - Eventually they went back and they audited what they’d done and instead of giving the monkeys MDMA, they’d given them crystal meth, which is way more toxic
    - [This study was retracted](https://pubmed.ncbi.nlm.nih.gov/12970544/) in the sense that they corrected the drug to change it from MDMA to methamphetamine
    - It’s embarrassing really because so much American science is paid for by the government
      - David heard that the editor of the magazine Science was told by Senators that the American Academy of Science, which runs a journal, would not get government funding if he didn’t put that paper in and get it published to deter young people from using MDMA
      - Of course, all that happens is in the end young people think this doesn’t make sense and then they discover they’d been lied to. So are they going to listen to anything else the government tells them?

## History of ketamine, medical use of esketamine, and the waning effects of psychedelics with increasing usage [1:13:30]

- [Ketamine](https://en.wikipedia.org/wiki/Ketamine) the only drug on this list of psychedelics that is legal

- It’s a schedule III drug, used as an anesthetic; it’s quite dissociative
- [John Krystal](https://medicine.yale.edu/profile/john_krystal/) (a professor at Yale) used ketamine to model psychosis and compared it to THC
  - Both produced altered states of consciousness, this has some overlap with psychosis
  - He noticed after drug treatment, his volunteers often felt better
    - He did a [study](https://pubmed.ncbi.nlm.nih.gov/10686270/) and found ketamine does elevate mood for a couple days
    - The problem is that effects are very short lasting, 2-3 days
- Jansen decided to pursue this because this was the first real breakthrough in the treatment of depression for 50 years
- Ketamine couldn’t be patented because it was used back in the Vietnam war
  - Instead they took the [S-enantiomer](https://en.wikipedia.org/wiki/Enantiomer) and called it [Esketamine](https://en.wikipedia.org/wiki/Esketamine), now sold as [Spravato](https://www.rxlist.com/spravato-drug.htm)
    - It is formulated for nasal inhalation

- - - *Esketamine works; patients take it a couple times a week and gradually dose less and less as they recover from depression*

- - - When taken twice a week patients don’t develop [tachyphylaxis](https://en.wikipedia.org/wiki/Tachyphylaxis) or tolerance
    - Some patients can get off the drug and retain the antidepressive benefits
- The advantage of Esketamine over ketamine is nasal administration; ketamine is taken intravenously or intramuscularly
  - Ketamine is also a dependence producing drug
    - It’s a popular recreational drug
    - Tolerance tachyphylaxis is a problem when it’s used regularly
    - It is relatively safe at doses used for depression (500 milligrams)

- *People taking ketamine recreationally take up to 2 grams a day which causes* [*problems*](https://en.wikipedia.org/wiki/Ketamine#Side_effects)

- - Severe chronic cystitis, which can cause bladder atrophy needing bladder resection
  - It causes a psychological state of severe cognitive impairment, which actually rather mimics schizophrenia
  - It can cause brain damage

- - *Heavy use of ketamine should be avoided*

**How much ketamine is too much?**

- Daily use is too much
- Addicts use ketamine 4-5 times a day, maybe 5 grams a day placing them at serious risk for brain damage
- Twice a week seems to be okay; studies with Esketamine at this frequency found no enduring problems

- *It is not known why people using the S-enantiomer (Esketamine) twice a week don’t develop tachyphylaxis tolerance but people taking ketamine (a* [*racemic mixture*](https://en.wikipedia.org/wiki/Racemic_mixture)*) do*

- - [Tachyphylaxis](https://en.wikipedia.org/wiki/Tachyphylaxis) is a subcategory of [drug tolerance](https://en.wikipedia.org/wiki/Drug_tolerance); this describes a sudden decrease in response to a drug after taking it
    - When taking the same amount of medication produces a lesser and lesser effect; or when more and more of a medication is required to produce the same effect
  - One can increase the dose of ketamine a little bit and stay ahead of tachyphylaxis
    - Like with heroin and fentanyl, one can overcome the tolerance
    - But with psychedelics, the tolerance cannot be overcome
      - It probably has to do with downstream mechanisms in cells

- - - - *There is almost a complete absence of effect of psychedelic effect after 2-3 doses*

- - - - - This was discovered by the US government in the 50’s; they studied this after becoming concerned that Russians may spray LSD on US troops
        - The US government studied how to protect their troops from LSD and discovered on the 3rd day of giving troops LSD, it produced no effect anymore
        - So taking 250 micrograms of LSD *daily* at some point, people stop responding

- - - - - *This effect disappears in 1-2 weeks, depending on how much is taken; it’s a temporal tachyphylaxis (not lifelong)*

- - - - - It’s not clear why taking a bit more of ketamine at each dose will overcome tachyphylaxis

## Psilocybin for depression: David’s promising research and the roadblocks to more robust experiments [1:20:15]

- Published in the New England Journal of Medicine in April 2021, [Trial of Psilocybin versus Escitalopram for Depression](https://www.nejm.org/doi/full/10.1056/NEJMoa2032994)
- [Peter has written about this](https://peterattiamd.com/psilocybin-for-depression/) at length, the comparison between psilocybin and Lexapro
  - [Lexapro](https://www.rxlist.com/lexapro-drug.htm) (escitalopram)  is a very popular, commonly used, reasonably well tolerated [SSRI](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) used to treat depression
- First David did an open trial with 20 people who had resistant depression
  - Study published in 2018, [Quality of acute psychedelic experience predicts therapeutic efficacy of psilocybin for treatment-resistant depression](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5776504/)
  - Patients were given a single psilocybin trip and they felt good for 1-2 months
  - Depression came back for many of them
- David did some theoretical work with [Robin Carhart Harris](https://www.imperial.ac.uk/people/r.carhart-harris), who was at the [Imperial College London](https://www.imperial.ac.uk/brain-sciences/research/psychiatry/) (he’s now moved to [UCSF](https://neuroscape.ucsf.edu/psychedelics/))

> “We came to the conclusion that psychedelics treat depression in a different way to antidepressants.” – David Nutt

Published in 2017, [Serotonin and brain function: a tale of two receptors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5606297/)

- This paper conceptualizes 2 ways medication can lift depression
  - [1) SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) (such as [Lexapro](https://www.rxlist.com/lexapro-drug.htm), *generic name escitalopram*) enhance [serotonin](https://en.wikipedia.org/wiki/Serotonin) in the [limbic system](https://en.wikipedia.org/wiki/Limbic_system)

- - - They block the stress response; this allows the limbic system to received
    - It’s like putting a cast on a broken leg; add the cast, give it some time and the bone heals itself
    - Over 6-8 weeks SSRIs can help one to heal and get over depression
    - SSRIs act through a subtype of serotonin receptors called the serotonin 1A receptor, which is expressed in the limbic system
  - 2) Psychedelics

- - - Psychedelics work in the cortex and they disrupt cortical processing
    - It is thought that they can disrupt the deep persistent ruminations, the negative thoughts of depression

**David’s recent study published in The New England Journal of Medicine in 2021:** [Trial of Psilocybin versus Escitalopram for Depression](https://www.nejm.org/doi/full/10.1056/NEJMoa2032994)

- [fMRI](https://en.wikipedia.org/wiki/Functional_magnetic_resonance_imaging) can be used to image the brain and look for changes in depressed people
- David would expect to see cortical differences in fMRI scans of patients on Lexapro versus psilocybin
  - He expects the [cortex](https://openstax.org/books/anatomy-and-physiology/pages/13-2-the-central-nervous-system?query=cerebral%20cortex&target=%7B%22index%22%3A0%2C%22type%22%3A%22search%22%7D#fs-id1476424) to be changed by psilocybin and the [subcortical regions](https://openstax.org/books/anatomy-and-physiology/pages/13-2-the-central-nervous-system?query=subcortical&target=%7B%22type%22%3A%22search%22%2C%22index%22%3A0%7D#fs-id793857) to be changed by escitalopram

- *The aim of the* [*study*](https://www.nejm.org/doi/10.1056/NEJMoa2032994?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) *was to see if there were differences in brain mechanisms*

- - First he needs to know if there are differences in outcome
  - They compared mood changing effects of Lexapro and psilocybin in a blinded fashion
- It’s difficult to blind patients who are taking psychedelics
  - They told everyone they were going to get psilocybin but half the group got a low dose (a placebo dose, a one milligram dose) and half got a high dose  (a 25 milligram dose)
  - They all went through the same psychotherapy; it didn’t matter what dose they got, they all got all the same preparation and the psychotherapy that goes with a high dose of psilocybin
  - Then they all got pills, but the escitalopram group got escitalopram, the psilocybin group got the placebo
  - The point of that is to achieve what’s called [clinical equipoise](https://en.wikipedia.org/wiki/Clinical_equipoise)
    - People have to believe that they’re getting the best they can
- Subjects are getting 2 doses of psilocybin (whether high or low), one at the start and one after 3 weeks to see how long the effect would last
- They measured changes in mood and side effects
- Rather than just looking at depression scores, we also looked at things like wellbeing, which is a different way of looking at how people are feeling
  - They used self-report measure called the [QID-SR16 self-report](https://narr.bmap.ucla.edu/docs/QIDS-SREnglish16item.pdf)

- - In the end, on the primary measure, there was no difference

- - *Psilocybin at six weeks was as good or equal to escitalopram on that particular measure*

- Peter pauses to note “I *think that the paper was undersold a little bit. It reads as a negative study, as opposed to a non-inferiority study. Why do you think that happened? Do you think that there was a mistake in the way that either the journal treated that, or even the way you treated that as the authors?*”
- David points out that this study wasn’t powered for non-inferiority
  - To run a proper non-inferiority study in psychiatry, takes 150 patients in each arm
  - They could never afford to do that
  - Few studies have done this, except those run by companies
  - They could not statistically do a non-inferiority study, so they had to just do a kind of comparison
  - They pre-specified 2 outcomes: the QIDS and wellbeing
    - The QIDS was used as a primary for statistical analysis
    - With statistics, if the results don’t meet the primary then reporting of the secondary outcomes are not allowed
      - [Examples of primary and secondary data](https://www.deakin.edu.au/library/research/manage-data/plan/primary-versus-secondary-data)

- - *There was not a single measure that favored escitalopram (Lexapro)*

- - Peter is very familiar with Lexapro (side effects and baggage that comes with it)
    - Usually Lexapro (generic name escitalopram) is given at 2 doses: 10 mg or 20 mg
      - Going from 10 to 20 mg brings a sizable increase in efficacy but also increase in side effects (many of the side effects are sexual; the patient doesn’t want their libido destroyed)
      - Some patients can’t tolerate these drugs despite their benefit as an [antidepressant](https://en.wikipedia.org/wiki/Antidepressant) or [anxiolytic](https://en.wikipedia.org/wiki/Anxiolytic)
  - Peter read this study with enormous optimism

> “Which is, if there is a way to give somebody 25 milligrams of psilocybin and get the same antidepressive benefits, but without these other side effects, this is very exciting. This needs to be explored a heck of a lot further. “ – Peter Attia

- People have asked David why he didn’t push the journal to feature his study in a more positive light

> “From my perspective, being the first ever psychedelic study in the New England Journal of Medicine tells the world that psilocybin is a medicine; and it’s as good as Lexapro.” – David Nutt

- Anyone who reads the paper can see that psilocybin does do better on sexual dysfunction, and better on many of the other issues that Lexapro has a problem with
- These results fit with the theory that one of the things… The reason Lexapro and other SSRIs dampen down sexual activity is because they dampen down the limbic system, which is a part of the brain which drives these behaviors
- People on these drugs often say, “Yes, I don’t feel depressed anymore. I don’t cry. I don’t have the distress that comes from seeing sad things on the TV.” But they also say also, “I don’t enjoy life as much because I’m kind of… My pleasures are blunted.”

- *SSRIs blunt the highs and lows of feelings whereas psilocybin stops the thinking and allows the rest of the brain to work normally*

**Microdosing of psilocybin**

- Typically when people take psilocybin, they take the whole mushroom which is around 5 g
- This study used a dose of 25 mg of psilocybin; this would be on par with 4-5 g of magic mushrooms, a truly psychedelic experience

- *What is known about the imperceptible dose, 100 mg of magic mushrooms or 1-2 mg of pure psilocybin?*

- - This is  hard to study because of the schedule I status
    - This means that a single mushroom is just as illegal as a bunch of mushrooms or pure psilocybin
  - An example for comparison, 4 years ago David got ethical permission to do a micro dosing study with LSD, but every micro dose had to be given in hospital
    - They added up what it would take to buy all that time in hospitals to do six weeks of micro dosing and realized they couldn’t afford it

- - *Cost is why there has never been a proper controlled micro dosing study of any psychedelic*

- *From a mechanism of action standpoint, microdosing wouldn’t be as good; a single microdose won’t be remotely as good as a macro dose*

- In the [NEJM 2021 study](https://www.nejm.org/doi/full/10.1056/NEJMoa2032994), patients were given a macro dose twice, 3 weeks apart
  - How would this compare to microdosing 3-4 times a week at 1-2 mg over the course of a year?
    - David thinks this would be a great experiment
    - It’s ethical to do that because I think it is plausible that micro dosing over a long period might
      - Protect people against a lowering of mood
      - He would be surprised if it elevated mood in depressed people
- The fundamental question he has now as a result of his 2 depression studies is, can this treatment keep people well

- - *There’s no question about it, people get better with psilocybin*

- - One of the great things we know about the SSRIs is that if you take them continuously, they do protect against depression
    - They do protect against the stresses of life causing depression, at the cost of blunting
  - *The question is,* *what could we do other than give them an SSRI after the psychedelic treatment?*
    - Maybe micro dosing would work, but until we get it out of schedule one and get it available, it’s impossible to do those studies
- Peter asks *“Where do you think will be the thin end of the wedge to make that happen? Obviously,* [*Roland Griffiths*](https://hopkinspsychedelic.org/griffiths) *has done great work at Johns Hopkins…looking at psilocybin in end of life depression”*
  - There’s obviously efficacy using psilocybin to aid in smoking cessation and alcohol cessation; and now David’s work with depression
  - Which of these will be the first domino to fall, to change the scheduling of psilocybin?

**Study of psilocybin by biotech**

- David explains that a company called [Compass Pathways](https://compasspathways.com/) is doing a multicenter study in Europe and  the US, a dose finding study
  - Hopefully these results will be available by Christmas or the New Year; they’re testing
    - 1) 25 mg (high dose)
    - 2) 1 mg (placebo dose)
    - 3) 10 mg (in between dose)

- - If they have positive results, David thinks the floodgates of funding for this type of research will open

- Peter remarks that Compass Pathways has come under great scrutiny for their effort to do a land grab of intellectual property on a molecule that should be in the public domain

- *How can this need to make something widely available be balanced with an economic incentive for the company doing these studies?*

- - David has been working with Compass Pathways since his first depression study
  - The company took his data and tried to do research with it
  - They began trying to raise money as a not-for-profit, but this didn’t work out
  - [Rick Doblin](https://en.wikipedia.org/wiki/Rick_Doblin) is a phenomenon, but it has taken him 25 years to raise enough money to do the [MAPS](https://maps.org/) phase three
    - After a year or so Compass Pathways realized that they didn’t have the resources or the skill or the personalities that Rick has

> “I think if we want to see psilocybin with enough evidence in my lifetime to make it a medicine, then I think that they’re the people that are most likely to deliver that. But on the other side, you’ve got Oregon, which voted in November last year to make mushrooms a medicine in two years time. So it’s actually a bit of a race now to see who’s going to win.” – David Nutt

§

## Selected Links / Related Material

**David’s recent book to explain the brain**: [Brain and Mind Made Simple](https://www.amazon.com/Brain-Mind-Made-Simple-David/dp/1914603001/ref=sr_1_5?crid=2B4KX38CEMS1I&dchild=1&keywords=david+nutt&qid=1633438293&s=books&sprefix=david+nutt%2Caps%2C185&sr=1-5) by David Nutt (2021) | [5:30]

**Rating harm caused by recreational drugs**: [European rating of drug harms](https://pubmed.ncbi.nlm.nih.gov/25922421/) | *Journal of Psychopharmacology* (J van Amsterdam *et al.* 2015) | [14:15]

**Drug scheduling in the US**:

- Simple website [Drug Scheduling](https://www.dea.gov/drug-information/drug-scheduling) | (dea.gov) [16:30]
- Pdf has more info [Drugs of Abuse, A DEA Resource Guide (2020 Edition)](https://www.dea.gov/sites/default/files/2020-04/Drugs%20of%20Abuse%202020-Web%20Version-508%20compliant-4-24-20_0.pdf) | 2020 (dea.gov) [16:30]

**The book the TV show The Wire is based on**: [The Corner: A Year in the Life of an Inner-City Neighborhood](https://www.amazon.com/Corner-Year-Life-Inner-City-Neighborhood/dp/0767900316/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1633457481&sr=1-1) by David Simon and Edward burns (1998) | [39:00]

**Book distinguishing between alteration of traits and alteration of state of mind**: [Altered Traits: Science Reveals How Meditation Changes Your Mind, Brain, and Body](https://www.amazon.com/Altered-Traits-Science-Reveals-Meditation/dp/0399184392/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1633611050&sr=1-1) by Daniel Goleman and Richard J. Davidson (2018) | [45:15]

**Meta-analysis of alcoholism treatment with LSD**: [Lysergic acid diethylamide (LSD) for alcoholism: meta-analysis of randomized controlled trials](https://pubmed.ncbi.nlm.nih.gov/22406913/) | *Journal of Psychopharmacology* (T S Krebs and P O Johansen 2012) | [101:15]

**Podcast with Rick Doblin on MDMA**: #[65 – Rick Doblin, Ph.D.: MDMA — the creation, scheduling, toxicity, therapeutic use, and changing public opinion of what is possibly the single most important synthetic molecule ever created by our species](https://peterattiamd.com/rickdoblin/) | host Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:09:15]

**Ricuarte’s retracted study claiming MDMA causes brain damage in monkeys**: [Severe Dopaminergic Neurotoxicity in Primates After a Common Recreational Dose Regimen of MDMA (“Ecstasy”)](https://www.science.org/doi/10.1126/science.1074501) | *Science* (G A Ricaurte *et al.* 2002) | [1:11:45]

- [Retraction links in PubMed](https://pubmed.ncbi.nlm.nih.gov/12970544/)

**Study showing ketamine boosts mood**: [Antidepressant effects of ketamine in depressed patients](https://pubmed.ncbi.nlm.nih.gov/10686270/) | *Biological Psychiatry* (R M Berman *et al.* 2000) | [1:14:30]

**David Nutt’s recent work with psilocybin and depression**: [Trial of Psilocybin versus Escitalopram for Depression](https://www.nejm.org/doi/full/10.1056/NEJMoa2032994) | *The New England Journal of Medicine* (R Carhart-Harris *et al.* 2021) | [1:20:15]

**Peter’s summary of using psilocybin for depression**: [Psilocybin for depression? The psychedelic drug goes head-to-head with Lexapro in a recent trial](https://peterattiamd.com/psilocybin-for-depression/) | Peter Attia, peterattiamd.com (May 23, 2001) | [1:20:15]

**David’s first open trial treating resistant depression with psilocybin**:  [Quality of acute psychedelic experience predicts therapeutic efficacy of psilocybin for treatment-resistant depression](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5776504/) | *Frontiers in PHarmacology* (L Roseman, D J Nutt, and R L Carhart-Harris 2018) | [1:20:45]

**Psychedelics treat depression in a different way than antidepressants**: [Serotonin and brain function: a tale of two receptors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5606297/) | *Journal of Psychopharmacology* (R L Carhart-Harris and D J Nutt 2017) | [1:21:15]

**Books authored by David Nutt**

- [Drugs without the hot air](https://www.amazon.com/Drugs-without-hot-David-Nutt/dp/0857844989/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1633438293&sr=1-4) by David Nutt (2021)
- [Nutt Uncut](https://www.amazon.com/Nutt-Uncut-David/dp/1909976857/ref=sr_1_3?crid=2B4KX38CEMS1I&dchild=1&keywords=david+nutt&qid=1633438293&s=books&sprefix=david+nutt%2Caps%2C185&sr=1-3) by David Nutt (2021)
- [Drink?: The New Science of Alcohol and Health](https://www.amazon.com/Drink-New-Science-Alcohol-Health/dp/030692384X/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1633438293&sr=1-2) by David Nutt (2020)
- [Search and Rescue](https://www.amazon.com/Search-Rescue-David-Nutt/dp/0473505452/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1633438293&sr=1-7) by David Nutt
- [The Great American Suction](https://www.amazon.com/Great-American-Suction-David-Nutt/dp/0999218638/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1633438293&sr=1-6) by David Nutt (2019)
- [Addiction (Oxford psychiatry library series) 2nd edition](https://www.amazon.com/Addiction-Oxford-Psychiatry-Library-David/dp/0198797745/ref=sr_1_19?crid=2B4KX38CEMS1I&dchild=1&keywords=david+nutt&qid=1633439376&s=books&sprefix=david+nutt%2Caps%2C185&sr=1-19) by David Nutt and Liam Nestor (2018)
- [Sleep Disorders (Oxford Psychiatry Library) 2nd edition](https://www.amazon.com/Sleep-Disorders-Oxford-Psychiatry-Library-dp-0199674558/dp/0199674558/ref=mt_other?_encoding=UTF8&me=&qid=1633439376) by Sue Wilson and David Nutt (2013)
- [Addiction medicine (Oxford specialist handbooks) 1st edition](https://www.amazon.com/Addiction-Medicine-Oxford-Specialist-Handbooks-dp-0199539332/dp/0199539332/ref=mt_other?_encoding=UTF8&me=&qid=1633438293) by E J Marshall, D Nutt, *et al.* (2009)
- [Understanding depression: A translational](https://www.amazon.com/Understanding-depression-translational-Randolph-Nesse/dp/0199533075/ref=sr_1_11?crid=2B4KX38CEMS1I&dchild=1&keywords=david+nutt&qid=1633438293&s=books&sprefix=david+nutt%2Caps%2C185&sr=1-11) approach edited by C M Pariante, R M Nessee, D Nutt, and L Wolpert (2009)
- [Drugs and the future: brain science, addiction and society 1st edition](https://www.amazon.com/Drugs-Future-Science-Addiction-Society-dp-0123706246/dp/0123706246/ref=mt_other?_encoding=UTF8&me=&qid=1633438293) by David Nutt *et al*. (2006)

**David Nutt’s podcast**: [The Drug Science Podcast](https://www.drugscience.org.uk/drug-science-podcast/) | host David Nutt (drugscience.org.uk)

**David’s commentary on therapeutic use of mind-altering drugs**:

- [Mind-altering drugs and research: from presumptive prejudice to a Neuroscientific Enlightenment?: Science & Society series on “Drugs and Science”](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3989684/) | *EMBO reports* (D Nutt 2014)
- [Psychedelic Psychiatry’s Brave New World](https://www.cell.com/cell/fulltext/S0092-8674(20)30282-8) | *Cell* (D Nutt *et al.* 2020)

**Interactive timeline of psychedelics**: [Psilocybin vs escitalopram phase II trial inconclusive](https://psychedelicreview.com/timelines/featured-events/?era=0) | April 2021 (Psychedelic Science Review)

**Non-profit David founded in 2010 to provide evidence-based information on drugs**: [Our Story](https://www.drugscience.org.uk/about/) | drugscience.org.uk

- [DrugScience](https://en.wikipedia.org/wiki/DrugScience) | wikipedia.org (May 30, 2021)

§

## People Mentioned

- [Harry Anslinger](https://en.wikipedia.org/wiki/Harry_J._Anslinger) (US government official and early proponent of the war on drugs) [22:00]
- [Sigmund Freud](https://en.wikipedia.org/wiki/Sigmund_Freud) (founder of psychoanalysis) [42:00, 59:15]
- [Len Bias](https://en.wikipedia.org/wiki/Len_Bias) (famous basketball player who died from sudden cardiac arrest while using cocaine) [46:30]
- [Christian Eriksen](https://en.wikipedia.org/wiki/Christian_Eriksen) (famous European football player who suffered cardiac arrest during a game) [48:00]
- [Robert F. Kennedy](https://en.wikipedia.org/wiki/Robert_F._Kennedy) (as secretary of state questioned the DEA and FDA on banning LSD) [54:00]
- [Bill Wilson](https://en.wikipedia.org/wiki/Bill_W.) (co-founder of alcoholics anonymous) [1:00:30]
- [Albert Hoffman](https://en.wikipedia.org/wiki/Albert_Hofmann) (first to isolate and synthesize psychedelic compounds in magic mushrooms) [1:04:15, 1:05:15]
- [Gordon Wasson](https://en.wikipedia.org/wiki/R._Gordon_Wasson) (ethnomycology who discovered a tribe in Mexico who used magic mushrooms) [1:04:15, 1:05:15]
- [Aldous Huxley](https://en.wikipedia.org/wiki/Aldous_Huxley) (author of Brave New World) [1:04:45]
- [Tony Blair](https://en.wikipedia.org/wiki/Tony_Blair) (former Prime Minister of the UK and leader of the Labor Party) [1:07:15]
- [David Cameron](https://en.wikipedia.org/wiki/David_Cameron) (former Prime Minister of the UK and leader of the Conservative Party) [1:07:30]
- [Rick Doblin](https://en.wikipedia.org/wiki/Rick_Doblin) (previous podcast guest discussed MDMA) [1:09:15, 1:34:30]
- [Alexander “Sasha” Theodore Shulgin](https://en.wikipedia.org/wiki/Alexander_Shulgin) (American chemist who characterized MDMA in the ‘60’s) [1:09:30]
- [George A. Ricaurte](https://en.wikipedia.org/wiki/George_A._Ricaurte) (reported brain damage in non-human primates given MDMA) [1:11:45]
- [John Krystal](https://medicine.yale.edu/profile/john_krystal/) (professor at Yale, studied ketamine) [1:14:00]
- [Robin Carhart Harris](https://www.imperial.ac.uk/people/r.carhart-harris) (collaborated with David to study treatment of depression with psilocybin) [1:21:00]
- [Roland Griffiths](https://hopkinspsychedelic.org/griffiths) (has done great work at Johns Hopkins with psilocybin, etc.) [1:32:45]

§

![](https://peterattiamd.com/wp-content/uploads/2021/10/David-Nutt-1x1-1-500x500.jpg)

##### David Nutt, DM, FRCP, FRCPsych, FSB, FMedSci

David Nutt is currently the Edmond J. Safra Professor of Neuropsychopharmacology and director of the Neuropsychopharmacology Unit in the Division of Brain Sciences. He is also the host of [The Drug Science Podcast](https://www.drugscience.org.uk/drug-science-podcast/).

After 11+ entry to Bristol Grammar School, David was awarded an Open Scholarship to Downing College Cambridge and then completed his medical training at Guy’s Hospital London, continuing in neurology to MRCP.  After completing his psychiatric training in Oxford, he continued there as a lecturer and then later as a Wellcome Senior Fellow in psychiatry. He then spent two years as Chief of the Section of Clinical Science in the National Institute of Alcohol Abuse and Alcoholism in NIH, Bethesda, USA. On returning to England in 1988 he set up the Psychopharmacology Unit in Bristol University, an interdisciplinary research grouping spanning the departments of Psychiatry and Pharmacology before moving to Imperial College London in December 2008 where he leads a similar group with a particular focus on brain imaging especially PET.  In 2010 he founded the non-profit Drug Science to provide evidence-based information on drugs.

David is currently Chair of [Drug Science](https://www.drugscience.org.uk/support-drug-science/) (formally the Independent Scientific Committee on Drugs (ISCD) and President of the European Brain Council. Previously he has been President of the European College of Neuropsychopharmacology (ECNP), the British Neuroscience Association (BNA) and the British Association of Psychopharmacology (BAP). In addition he is a Fellow of the Royal Colleges of Physicians and of Psychiatrists and a Fellow of the Academy of Medical Sciences. He is also the UK Director of the European Certificate and Masters in Affective Disorders Courses and a member of the International Centre for Science in Drug Policy. He has edited the Journal of Psychopharmacology for over two decades and acts as the psychiatry drugs advisor to the British National Formulary. He has published over 400 original research papers, a similar number of reviews and book chapters, eight government reports on drugs and 27 books. [[Imperial College London](https://www.imperial.ac.uk/people/d.nutt)]