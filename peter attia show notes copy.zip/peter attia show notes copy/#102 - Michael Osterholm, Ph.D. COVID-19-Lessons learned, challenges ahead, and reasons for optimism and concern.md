# #102 – Michael Osterholm, Ph.D.: COVID-19—Lessons learned, challenges ahead, and reasons for optimism and concern

**Source:** [https://peterattiamd.com/michaelosterholm/](https://peterattiamd.com/michaelosterholm/)

---

In this episode, Michael Osterholm, Director of the Center for Infectious Disease Research and Policy at the University of Minnesota and author of [Deadliest Enemy: Our War Against Killer Germs](https://www.amazon.com/Deadliest-Enemy-Against-Killer-Germs/dp/0316343692), provides an overview on the COVID-19 pandemic in regards to what has happened to date, what we’ve learned about how the disease spreads, and his optimism and pessimism about what potentially lies ahead. Michael gives his take on the true case fatality rate, why it differs around the world, and which underlying conditions, such as obesity, impact risk of severe illness and death. We also discuss the outlook regarding vaccines, repurposed drugs/antivirals for treatment, and Michael’s growing concern about supply chain limitations with respect to drugs, vaccines, n95 masks, and testing kits.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/michaelosterholm/the_Drive_public.png)

Play

#102 - Michael Osterholm, Ph.D.: COVID-19—Lessons learned, challenges ahead, and reasons for optimism and concern

#102 - Michael Osterholm, Ph.D.: COVID-19—Lessons learned, challenges ahead, and reasons for optimism and concern

1x15s30s

0:001:22:23

## We discuss:

- Recapping the brief history of COVID-19 and what potentially lies ahead [2:15];
- Some positive news about immunity and reinfection [10:45];
- Case fatality rate—the challenge in finding the true rate, difference by country, and the impact of age, underlying conditions, and obesity [13:00];
- What has to be true for less than 100,000 Americans to die from COVID-19? [24:30];
- How do we best protect healthcare workers? [29:45];
- Concerns about testing capability—reagent shortfall and a supply chain problem [39:30];
- Vaccines and antivirals—The outlook, timing, and challenges [47:45];
- Long term health of survivors of COVID-19 [56:45];
- The impact of comorbidities—Diabetes, obesity, and immunosuppressed patients [59:30];
- Understanding R0 and how the disease spreads [1:01:30];
- The challenge of forecasting with so many unknowns [1:08:00];
- What explains the difference in cases and fatalities in different parts of the world? [1:14:30];
- Repurposed drugs/antivirals being considered for treatment options—any optimism? [1:16:45];
- A parting message from Michael about what lies ahead [1:18:30]; and
- More.

§

## Show Notes

## Recapping the brief history of COVID-19 and what potentially lies ahead [2:15]

⇒ Michael’s [recent appearance](https://www.youtube.com/watch?v=E3URhJx0NSw) on the Joe Rogan Podcast which might as well be a year ago in terms of this virus epidemic

⇒ “*If you don’t know where you are going, any road will get you there.*” -Lewis Carroll

**Brief history of COVID-19**

- Appeared in December 2019 in China
- It’s different that SARS and MERS because…
  - Those don’t become becoming highly infectious until the fifth or sixth day of illness whereas COVID-19 can be transmitted before symptoms occur much more like influenza
  - And there’s about 5 days from getting the virus to showing symptoms
- These characteristics lead Michael to predict this would be a pandemic in early February

**Will it be seasonal or spread year round?**

- Unclear, but the other coronaviruses (SARS and MERS) are NOT seasonal
- MERS for example transmitted just fine in 100 degree heat in Abu Dhabi

**How long will COVID-19 be around?**

- Michael says it’s unlikely to “go away” until 60-70% of the population gets infected
- In the US, we’re unlikely to be able to forcibly lock people down like they did in China (nor should we)

> “It won’t stop transmitting in any meaningful way till we get 50 or 60 or 70% of the population infected.”

**Pessimistic**

- Michael is pessimistic about the fact that we really just don’t have an “easy way out”
- We can’t stay in lock down for while we wait for a vaccine and destroy the economy
- But we also can’t just do nothing which would bring down the healthcare system

> “How do we find a way to have those people who are at lowest risk of having serious disease. ..be in our workforce, be more public, and handle the issues? So if we can do that, that’s good news.”

**A second wave?**

- Until there’s a vaccine, it’s hard to see how this virus doesn’t hit a majority of the US population (60-70%) because once we come out of sheltering it might spread again (like people speculate is happening in China)
- Quick math:
  - 300 million people
  - 60% infection = 180 mil people get COVID-19
  - 20% of those need hospitalization = 36 mil in hospital
  - 1.5% of infect end up dying = 2.7 mil deaths

> “It will go until it finds enough immune people that shut it down.”

## Some positive news about immunity and reinfection [10:45]

This [study](https://www.biorxiv.org/content/10.1101/2020.03.13.990226v1.article-info) showed that macaque monkeys could not get reinfected after they recovered from the virus

This suggests that it’s possible that once you get COVID-19, you will be immune from getting or spreading it after you recover

> “This study really gave us more hope that there really is durable immunity, at least in the short term . . . I know that if you have short term immunity, oftentimes that bodes well for a long term immunity picture.”

## Case fatality rate—the challenge in finding the true rate, difference by country, and the impact of age, underlying conditions, and obesity [13:00]

**[Lancet paper](https://www.thelancet.com/journals/laninf/article/PIIS1473-3099(20)30243-7/fulltext) with update case fatality information from China**

- The revised CFR now looks to be 0.66%
- This was down from 1.38% before they added a bunch more people to the denominator that were previously in the unconfirmed bucket

**Michael’s response**:

- we’re also missing the number people in the numerator
- In other words, there are people dying at home that never get diagnosed
- And this adds people to the numerator
- “The numerator is actually more sensitive in terms of impacting the rate than is the denominator. And so one of the challenges that we’ve had is ‘what is that overall numerator?’ and ‘How many cases were missed?’”
- See Michael’s take on what the real CFR is below …

**Underlying conditions and comorbidities**

- In China, many males over 65 were dying, but women weren’t
  - The difference? Smoking is prevalent in 70% of men and only 2% of women

–*Other risk factors*:

- Hypertension
- Renal disease
- **Obesity** may be the highest risk factor for younger people who die

> “We’re seeing an increased number of severe illnesses and deaths in people between the ages of 25 and 50…and the risk factor appears to be obesity.”

**What is Mike’s estimate of the actual CFR?**

- Some people hope the CFR is as low as 0.1-0.5%
- Mike says that’s a pipe dream
- Mike thinks it’s likely to be in the **1.0-2.5% range**

–*Why so high?*

- US has a large population over 65
- And we have a lot of obesity in young people

## What has to be true for less than 100,000 Americans to die from COVID-19? [24:30]

We’re currently at about 2,000 deaths in the US

*What has to happen for the death total to stay under 100,000?*

**Two things**, says Miks:

1—We have to basically suppress transmission as much as we can

- “which I don’t think is doable [long term]…as a country we can’t sustain that.”
- This would destroy the economy
- Mike’s [op ed](https://www.nytimes.com/2020/03/27/opinion/coronavirus-trump-testing-shortages.html) in the NY Times, he wrote about how this is not a choice between saving lives and costing the economy…it’s a combination of both

2—We have to make sure the supply of critical care supplies and drugs are available

- China makes most of our generic drugs in for hospitals and ICUs
- Mike is concerned that we will have shortage of those things leading to unnecessary death

## How do we best protect healthcare workers? [29:45]

- The main thing is we need all healthcare workers supplied with an n95 mask
- There is some confusion that a surgical mask is sufficient (not the case)
- An n95 mask stops aerosols
- But we don’t have nearly enough to match the demand despite 3m trying to ramp up production

> “We don’t send our soldiers into war without some kind of protective equipment or without bullets in their guns. . .We send healthcare workers into this viral battle and we’re going to be sending them in without bullets or without protective equipment. And that to me is really sad.”

Ways to get more out of the n95 masks:

1—One…We should start forming wards, large wards where basically we have 18 or 20 patients.

- You never leave the contaminated zone so you never throw away your mask

2—Secondly, can we reuse the n95 somehow?

- Mike and his team is working on a technique to make that possible

**One more solution**: What can we do to get infected healthcare workers back?

- “I’d like to test as many healthcare workers as I could for antibody and making, having the discussion we just had on the ability to know that somebody’s likely protected”
- Once they are immune they won’t require a mask

## Concerns about testing capability—reagent shortfall and a supply chain problem [39:30]

- The US has tested about 800,000 people so far
- For the PCR tests (which look at whether you are currently infected), the test kits are mostly being provided by Roche

“***Supply chain, supply chain, supply chain.***”

- Mike is very concerned about the supply chain of the test kits and just as importantly, the reagents which are needed to get the results of the test
- China was a big manufacturerAnd now they are obviously dealing with their own issues with the virus
- Plus the whole world needs the tests, not just the US

**Abbott tests**

- Some good news it Abbot is developing a new COVID-19 test
- But Mike still remains concerned that we will have a **shortfall of reagent water**
- So we might have plenty of tests but no way to get the results

## Vaccines and antivirals—The outlook, timing, and challenges [47:45]

In Peter’s discussion with biotech companies (off the record), nobody seems confident a vaccine will be ready any sooner than 12 months from now

-Mike explains a bit about why it’s so challenging to develop:

- The effectiveness of a vaccine would be the easier part to solve
- What will hold us up is the safety component

Another issue ⇒ the supply chain

- We might have the vaccine ready but not have the capability to meet the demand

**Antivirals**

- Even more challenging than a vaccine might be creating an antiviral for treatment
- Over the last 60 years, only ~5,000 antiviral drugs that we being approved, only about 90 were approved (and 40 were for HIV)
  - This tells us that T cell biology is so robust…T cells are so amazing at what they do that they save us from all these viruses that otherwise we’d be dead from already
  - “In other words, if not for the fact that we had a competent immune system that could fight off most viruses, we’d be doomed because our, our hit rate of developing drugs to stop viruses is actually pathetic compared to our ability to stop bacteria.” -Peter Attia
- Mike says, the HIV research can help us
  - But… “I worry about the fact that we’ve already made judgements to a certain degree about what works and doesn’t work.”
- The 2 kinds of drugs being explored to tread COVID-19:
  - Immunologic modulators (i.e., chloroquine)
  - “But if we have people dying from a myocarditis type picture, well that’s a whole different situation and we may actually cause problems using chloroquine.”

## Long term health of survivors of COVID-19 [56:45]

Unfortunately, we know little about the possible side effects of having gotten and recovered from COVID-19

For example:

- We don’t understand how much lingering myocarditis is out there.
- We don’t understand how much lingering kidney disease is out there.
- We don’t understand how much lingering lung disease remains in terms of fibrosis or maybe even **permanent** destruction of a subset of the pneumocytes

*Does Mike have any insight on this from his work with SARS and MERS?*

- Again, not much research has been done with this health of survivors
- The one good news is that humans do not seem to get reinfected with MERS once they’ve had it even if they are re-exposed to it

## The impact of comorbidities—Diabetes, obesity, and immunosuppressed patients [59:30]

- Type 2 diabetes and obesity are both risk factors
- Type 1 diabetes patients also seems to be at higher risk but it’s unclear why that’s the case

**What about immunosuppressed people?**

The data is all being revealed on this but as of today it does not appear that immunosuppressed people are at higher risk (e.g., HIV patients don’t seem at higher risk)

The data from China and Italy doesn’t show anything that would indicate that immunosuppression puts you at higher risk

**Compared to influenza…**

- Peter points out that this is another differentiation from influenza which attacks immunosuppressed people
- Another thing… there is pretty compelling evidence now out of studies that were done in China that the kids do get infected at the same rate that the adults do, but they just don’t show clinical signs and symptoms and which is just the opposite with the flu where kids have major symptoms and spread it very easily

## Understanding R0 and how the disease spreads [1:01:30]

**R0 (aka R naught)**

- Mike alluded that average R0 is between 2 and 2.4
- Peter wonders is symptomatic vs asymptomatic would have a different R0 and if we should be thinking about those cases differently
- Mike says they are currently having that debate right now so it’s unclear

**Looking at MERS and SARS for answers**

- Mike says R0 isn’t really relevant to MERS and SARS and the reason being the existence of “super spreaders”
- In other words, it’s possible that for 10 people who had the virus, 9 of them didn’t give it to anyone, but there would be 1 super spreader who would spread it to multitudes of people
- With the “super spreader” … this is a property of the **host**, *not the virus* because it’s the same virus
- “*So to say that the R0 in a situation like that, it’s kinda like saying your head’s in the freezer, your feet are in the oven, but on average, your temperature is just right. You know, it doesn’t make sense.*”
- So with MERS and SARS, Mike always challenged the relevance of R0

**So what about COVID-19?**

-With this disease, Mike says we have a “hybrid”

-Example of super spreader event: [Choir practice turns fatal.](https://www.latimes.com/world-nation/story/2020-03-29/coronavirus-choir-outbreak) (from the LA Times)

- 60 people in the choir showed up to practice, 45 have gone on to test positive, and 2 have died, 3 more in the hospital
- “Something about that” says Peter
- “*We have these events like that and I think that we’ve had more of those than we care to realize. But on the other hand, we also have, I think the ‘regular’ transmission.*”

-Transmission could occur even with little to no symptoms:

- The virus found in a throat swab of people showing the very early signs of COVID-19 found that the virus level was 1000x what they see with SARS
- They think it’s possible that the virus could be even higher in the days before the symptoms are showing
- So even if a person isn’t coughing or sneezing, the higher volume of virus in the throat means that the virus could be spread just by breathing and pushing out aerosols

*-Understanding aerosols*:

- The next time in your house and sunlight is peering through a window and you see all that dust floating in the air and you think, ‘Oh, my house is dusty., those are aerosols. That’s just from us talking. That’s from us breathing. That’s what goes on in your house.
- The second thing is next time you’re in a shopping center and you are in a department store and you’re three aisles away from the perfume section but you can still smell it… that’s an aerosol.

> “The breathing and just the talking would put [the virus] out there.”

-”*Presymptomatic” instead of asymptomatic*

- we kind of call this presymptomatic
- meaning that they’re going to get sick
- but they may be infectious beforehand they are sick

–*What about truly asymptomatic people?*

- Mike says he’s been looking at PCR and culture data for truly asymptomatic people in China data…
- “they were pretty loaded, too” says Mike but he’s not sure how much they are driving the outbreak

> “How much [asymptomatic people] are driving the outbreak, I don’t know, but I think we can’t ignore that they have to be there. And I do believe we have SARS-like super spreader events just like with the choir event. But there’s a lot of just efficient transmission.”

## The challenge of forecasting with so many unknowns [1:08:00]

- Forecasting would be great to know in order know where we need to allocate resources
- I.e., which 5 cities after NYC will need the most help
- But the models are so challenging to put together
- The models are inevitably wrong because we don’t know the simplest things that the model is incredibly sensitive to like R0
- “We don’t know what the probability distribution looks like of these things.”

*What does Mike think we should be doing here?*

- “I ascribe very much to the fact that all models are wrong. Some just provide helpful information.”
- In the 2014/2015 Ebola outbreak, the CDC model said the cases could reach 1 million, but it only ended up being 20,000
- The variability in the output of a model is so huge because we don’t know some of the variables
- So it’s incredibly challenging
- On the other hand, you can theoretically say without knowing everything things like:
  - If you are able to suppress 85 or 90% of the transmission events, you can have this happen.
  - Or if you do this, you can have that happen.
  - But it can’t tell you that’s what it’s going to be. It can just tell you within the framework of what might it look like.

**Mike on his predictions so far**:

- “We were right on with this thing all along to this point, even to picking hotspots.”
- “But now we can’t … because it’s beyond the scope of our experience.”

> “I can tell you, I can paint the whole United States, we have a hundred percent chance to have a COVID-19 problem. But I can’t tell you exactly much more than that right now.”

## What explains the difference in cases and fatalities in different parts of the world? [1:14:30]

- Globally, the communication has not be great to this point
- China doesn’t seem to reveal all the information
- Right now, for example, China isn’t saying it publicly but it appears that are closing movie theaters again and potential dealing with more spreading since they removed their strict lock down procedures

**What might explain the variations in cases and fatality rates in different parts of the world?**

- Each country is fighting for the same supplies that are critical and in shortage so the lower income countries will likely not be able to get the same stuff
- However, lower income countries will have less older people with underlying issues (who are the most susceptible to die from this) simply because of the fact that those people have already died in the country since the country doesn’t have the healthcare that we have in the US, for example
  - This implication is that the lower income country may have less fatality rate because of that
- Obesity and age
  - The countries will more obesity in the younger population may see an uptick
  - The countries with older populations will see an increase

**Comparing Italy and Spain to Germany**

- Italy and Spain are more similar and Germany seems better
- Mike says the difference in results is largely just artificial
- He says that most parts of the world will end up in a similar results when we look back 2 or 3 years from now

> “I hate to say this, but every week is like a snapshot. It’s not the whole movie. And if we could play the whole movie out for the next two to three years, I think there’ll be a lot more similar kinds of pictures that will over time bear that out. That where the risk factors were for comorbidity, associated severe disease, we’re going to see higher case fatality rates. When you age adjust and when you adjust on risk factors, I don’t think there’s a lot of difference here that we’re going to see around the world.”

## Repurposed drugs/antivirals being considered for treatment options—any optimism? [1:16:45]

Peter asks Mike… “Is there any of the sort of repurposed drugs that are currently being thrown around in non RCT manners that you have any optimism around?”

- Some examples: Remdesivir, Camostate, Hydroxychloroquine, etc.
- There was a [study that was published out of France](https://khn.org/morning-breakout/new-more-carefully-controlled-study-shows-that-buzzy-malaria-drug-might-not-actually-help-in-fighting-coronavirus/) looking at hydroxychloroquine showing promise
  - But studies like these don’t have the luxury of being randomly controlled so it’s hard to take much from them
- Mike admits that this is not his expertise but that he feels optimistic

> “I do believe we’re going to have much more information on therapies much sooner than vaccines and that could be really important.”

## A parting message from Michael about what lies ahead [1:18:30]

**First, this is serious**: “*This is real and more people are going to know somebody in the next couple of weeks that are going to be seriously ill or die*”

**Secondly, it’s going to be okay**: “*we’re going to get through this*”

§

![](https://peterattiamd.com/wp-content/uploads/2020/03/bio-image-michael-osterholm.jpeg)

##### Michael Osterholm, Ph.D, MPH

Dr. Osterholm is Regents Professor, McKnight Presidential Endowed Chair in Public Health, the director of the Center for Infectious Disease Research and Policy (CIDRAP), Distinguished Teaching Professor in the Division of Environmental Health Sciences, School of Public Health, a professor in the Technological Leadership Institute, College of Science and Engineering, and an adjunct professor in the Medical School, all at the University of Minnesota. He is also a member of the National Academy of Medicine (NAM) and the Council of Foreign Relations. In June 2005 Dr. Osterholm was appointed by Michael Leavitt, Secretary of the Department of Health and Human Services (HHS), to the newly established National Science Advisory Board on Biosecurity. In July 2008, he was named to the University of Minnesota Academic Health Center’s Academy of Excellence in Health Research. In October 2008, he was appointed to the World Economic Forum Working Group on Pandemics. [[unm.edu](https://directory.sph.umn.edu/bio/sph-a-z/michael-osterholm)]

Dr. Osterholm is the author of [Deadliest Enemy: Our War Against Killer Germs](https://www.amazon.com/Deadliest-Enemy-Against-Killer-Germs/dp/0316343692),