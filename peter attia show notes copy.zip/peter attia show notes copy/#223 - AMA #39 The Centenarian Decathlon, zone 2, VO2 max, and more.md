# #223 – AMA #39: The Centenarian Decathlon, zone 2, VO2 max, and more

**Source:** [https://peterattiamd.com/ama39/](https://peterattiamd.com/ama39/)

---

In this “Ask Me Anything” (AMA) episode, Peter describes what it means to exercise with the goal of longevity in mind, including his personal goals, exercise framework, and how he is optimizing for what he refers to as the “Centenarian Decathlon.” He explains the various types of cardiovascular training and how to partition your time between intensity levels (i.e., zone 2 training vs. zone 5 training) to optimize cardiorespiratory benefit. Additionally, Peter dives deep into questions around VO2 max, such as why it’s critical for longevity, how to improve it, and the value in starting VO2 max optimization early in life.

If you’re not a subscriber and are listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #39 show notes page](https://peterattiamd.com/ama39). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Exercise topics to be discussed [1:45];
- Peter’s exercise goals, and the Centenarian Decathlon [4:00];
- Peter’s exercise framework, and how he tracks his MET hours [8:30];
- How to partition your time between low and high intensity exercise to optimize results [13:15];
- Zone 2 exercise: ideal training methods and how to determine your zone 2 level [23:15];
- Rucking as a versatile mode of exercise [31:45];
- Zone 5 exercise: modalities of training, time per week, and other considerations [34:30];
- The importance of knowing your VO2 max, and methods for estimating it [38:15];
- Training methods for improving VO2 max, and realistic targets for improvement [46:00];
- Relationship of VO2 max with age and the required fitness levels for daily life activities and exercise [52:30];
- The training necessary to maintain an elite VO2 max throughout life [58:45];
- The value in starting early: the compounding nature of fitness [1:01:45]; and
- More.

§

The Peter Attia Drive

The Centenarian Decathlon, zone 2, VO2 max, and more

§

## Show Notes

§

## Exercise topics to be discussed [1:45]

- There have been a lot of follow up questions after the recent exercise content on The Drive
- Today will be some rapid fire questions going a little deeper on exercise topics
- If all goes to plan we’ll cover all four pillars of questions that have come in
- It should be a good well rounded AMA on all things exercise

## Peter’s exercise goals, and the Centenarian Decathlon [4:00]

The [Centenarian Decathlon](https://docs.google.com/document/d/1DyE9UJBcbs0TAun1Lpv1up3DPgU_qg8HbMyTvX-iykY/edit#50%20%E2%80%93%20AMA%20#5:%20calcium%20scores,%20Centenarian%20Decathlon%E2%84%A2,%20exercise,%20muscle%20glycogen,%20keto,%20and%20more) is simply a mental model for how Peter thinks about training

- In Peter’s long experience with training, something became very clear: **Specificity matters**
- But people confuse specificity with narrow, that’s not the case
- You can be broadly trained and broadly conditioned, but with specificity and focus—that’s really what the Centenarian Decathlon is all about
- You can be narrowly focused with great specificity, that’s what certain types of athletes are doing.
  - For instance, if you’re the best golfer in the world, there are some really, really specific things that you need to be doing
  - You’re training is basically focused on enhancing those very, very specific movements and probably some training to counterbalance the asymmetry there
- So it’s very difficult to be successful in a physical endeavor if you are not pursuing some sort of objective
- The “I’m just going to work out” strategy doesn’t really produce great results over the long haul
- And we’re going after a really hard problem—which is to be in the last decade of your life, what we call the marginal decade, and be incredibly robust physically

***What does that look like to be physically robust in the marginal decade?***

- Imagine a 90 year old who’s functioning like a 70 year old, but that is going to require a lot of preparation
- When you think about the inevitability of decline of muscle mass, strength, cardiorespiratory fitness, you have to be training for that with the same degree of focus and specificity that a person is training for to be an exceptional athlete in their 30s or 40s
- The Centenarian Decathlon basically forces us to be specific in what our metrics are in that last decade of life, and it allows us to “[backcast](https://peterattiamd.com/annieduke/)” from there
  - Forecasting from wherever you are today will almost without exception fail to get you where you need to go, because you’ll end up missing the mark by slipping underneath it
  - Instead you want to start with where you need to be at the very end and work your way backwards

## Peter’s exercise framework, and how he tracks his MET hours [8:30]

**How Peter’s training has changed over the years**:

- If you look at how he exercises today and compare it to how he exercised 8 years ago (time trialing on a bike) or 15 years ago (marathon swimming), there is no overlap compared with today
- Today’s training is really focused on something different which are these 4 o 5 buckets:
- Zone 2
- Zone 5
- Strength
- Stability
- Rucking (“*I include rucking in there because it is so physical…and the psychological benefit of it*”)

*Energy expenditure per week*:

You can identify energy expenditure by how many METs are required for each activity

How much time you spend in each gives you MET hours per week.

And then you can get a sense of where your energy is going

That’s probably the purest way to understand energy expenditure across those domains, says Peter

![](https://peterattiamd.com/wp-content/uploads/2022/09/F1-ama39-1024x446.png)

**Figure 1. Peter’s MET hour per week.**

- Zone 2 is cycling for Peter — zone 2 is somewhere between 220 and 235 watts
  - You can use a calculator to tell you how many METs that is, so that’s 11 METs
  - If I spend four hours a week there, 11 x 4 = 44, so that’s 44 MET hours per week
- Zone 5 is done by cycling or stair climbing, and that’s about 16 METs
  - That’s really pushing the intensity, but he’s only spending half an hour a week at that intensity therefore METs is 8 MET hours per week
- Strength is lifting weights and that’s about an average of five METs but it depends greatly on what type of lifting being done
  - Peter’s best estimate is he’s probably averaging about 5 METs, which is really not that labor intensive, but you multiply that by 6 hours per week there’s 30 METs
- Rucking – Peter puts 55 or 60 lbs in his rucking pack
  - At a 0% incline grade that is about 4.8 MET
  - 5% grade is about 7.5 METs
  - 10% grade is about 10 METs
  - Peter estimates he’s averaging 6.5 METs, and he does 3 to 4 hours per week for a 20 MET per week score
- Total METs is about 100 MET hours per week of activity
- NOTE: Notice the relative amount of zone 2 to zone 5 — much more time spent in zone 2 than zone 5

## How to partition your time between low and high intensity exercise to optimize results [13:15]

***What do we know about whether moderate intensity exercise is as good as vigorous intensity exercise?***

- The reality is both are important
- And Peter notes that he is now talking about this through the lens of assuming a person’s objectives are somewhat in line with his
- This is a big assumption, which is do you want to be 84 years old and kind of able to do anything?

*Silly example to explain his goals*:

- Peter and his wife just visited Italy (Rome and Tuscany) for a wedding
- They had 4 suitcases that they had to lug all around and load them overhead into planes and trains
- It was very hot, walking 7 miles per day, and overall it was a very physical trip
- As a 50 year old, that trip didn’t phase Peter – but Peter wants to have this same vacation at 75 years old
- If you actually look at the energy requirement, the VO2 requirement to do all the stuff I talked about, we’re abutting into the 30 mls per minute per kilogram range
- And so there’s a certain amount of strength, stability, and fitness you would need to be able to have that same vacation when you’re later in life
- “*If what I just described is aspirationally, directionally where you want to be, you will need a combination of high and low intensity aerobic training, plus a lot of strength training*.”

***How much time should people spend on low-intensity versus high-intensity to produce optimal results? [18:30]***

- Most people are surprised to learn that even the world’s absolute best of the best are spending on average probably 70 to 80% of their training volume in low intensity training
- When you’re talking about cardiorespiratory fitness, the best of the best are professional cyclists, cross country skiers, and they are distance runners (and perhaps swimmers)
- If you look at their training periods, you have to understand that they’re all broken up into different phases
  - If you’re [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) and you’re training for a grand tour win, your preseason is the winter into the spring, you’re in season the summer, and then your postseason is in the fall.
  - It’s safe to say that athletes at that level are spending about 80% of their time, if not slightly more in what we call zone 2 — meaning lactate below two millimole
  - Sometimes people have a hard time understanding this because zone 2 isn’t that physically challenging, however, their zone 2 is really at a higher level
  - To put this in perspective… where Pogačar or any of the top cyclists in the world are in zone 2, which means their lactate is below two millimole, and they can stay there for hours and hours and hours at a time
    - And when Peter was at his fittest as a cyclist, he could only spend one hour in that zone
    - And where today he’s probably have a hard time spending 10 to 15 minutes in that zone
  - So their ceiling is so much higher, but again, to their physiology, they’re spending most of their time at a very low place

**What Peter advises his patients**:

- Peter tells patient that basically 80 to 90% of their training volume from a cardio standpoint should be at zone 2, with the remainder being at zone 5
- And you can do as much time in zone 1 as you’d like, but we’re not counting that towards your training volume, because you don’t need the active recovery the way the athletes do.
- **An age old adage that applies:** “*If you want to build a really big pyramid, you have to have a really wide base*.”
  - The **base of the pyramid is your zone 2 capacity**, the wider the base of your pyramid, the higher your zone 2 capacity
  - Your **VO2 max**, which is your maximum aerobic output, is the **peak of the pyramid**
  - if you want to have that high peak, if you want that massive engine, you have to have a huge base
  - 80/20 is kind of the rule of thumb, which is 80% of your time building the base, 20% shaping the peak

> “*If your objective is to live longer and live healthier, you just can’t go wrong with an 80/20 split of zone 2 to zone 5*.” —Peter Attia

## Zone 2 exercise: ideal training methods and how to determine your zone 2 level [23:15]

**Modes of zone 2**

- Peter says bike is his preference, however, treadmill is best for most people starting out
- “We have some patients whose backs and necks won’t really in the short run at least allow them to sit on a bike for that long”
- Rowing is a great exercise, but truthfully it’s quite technical. So if you don’t have the technique, you’re going to hurt yourself on a rowing machine for 45 minutes
- Typically Peter would suggest if people have access to a treadmill, that’s the easiest way to go
- The biggest impediment to zone 2 is that it’s much easier to do indoors than outdoors and therefore it’s nowhere near as enjoyable
- But the reality of it is the efficiency with which I can do this on a trainer is unparalleled
- Walking outdoors, generally, isn’t going to cut it because for most people you need some elevation change, meaning an increase, you need to be walking uphill to make it work
  - So I’m basically just trying to manipulate weight and elevation change on a treadmill
- For a person who is just starting, the treadmill is probably the safest and easiest.
- Peter likes the bike the most because it has even less impact, but again, for some people they’re so inefficient in that position that it becomes counterproductive
- At the outset, the goal is just to increase compliance and get some of that muscle memory going

*Beginners can estimate the right pace on a treadmill as such*:

- Generally have people get to the velocity that is going to be their maximum efficiency, and you’ll know you’re past that, when you feel like you want to start running.
- When you feel like to walk any faster, I might as well start running, that’s your maximum point
- We don’t want you running just because of the impact—it’s 8:1 versus 3:1 application of body weight force to knee
- Once you get to that maximum point, you increase the grade or elevation of the treadmill
- We can do this off rate of perceived exertion (RPE), heart rate, and lactate

**How to know if your in zone 2 without a lactate meter [26:30]**

- There’s the RPE test, and then there’s the heart rate guidance
- Use heart rate as the boundary conditions, but ultimately until you get lactate tested, you’re probably going to have to rely on rate of perceived exertion
- Heart rate guidance we provide people is triangulating between a couple of numbers

*For those who don’t know their true max HR*:

- If a person doesn’t know anything, they don’t know what their maximum heart rate is, they’ve never done anything before, then Peter likes for them to use [Phil Maffetone](https://philmaffetone.com/)‘s guidance which is 180 minus your age ([The MAF 180 Formula](https://philmaffetone.com/180-formula/))
  - You’re 50 years old, 130 is probably your zone 2
    - if you’re really deconditioned, you might be subtracting 10 from that
    - If you’re superbly conditioned, you might be adding 10 to that.
- Using himself as an example, Peter’s 180-age puts him at 130 but he adds about 10 to 15 to make his zone 2 HR approx. 140-145

⇒ See [episode of The Drive with Phil Maffetone](https://peterattiamd.com/philmaffetone/) for more

*If you know your maximum heart rate*:

- you’ve had a CPET or VO2 max test. Or you’ve exercised enough to know
- Then another rule of thumb is if you’re pretty deconditioned, I would say start at about 70 to 75% of maximum heart rate
- If you’re relatively well conditioned probably start at closer to 78 to 80% of maximum heart rate.

*Using rate of perceived exertion*:

- ultimately you default into this RPE state, which is once you lose the ability to talk out loud, not whisper, literally have a discussion with somebody on the phone, you’re out a zone 2
- if you’re speaking to somebody on the phone or standing next to you with great ease, you’re below zone 2

**For very deconditioned patients**:

- So a person who is wildly deconditioned will have a resting lactate that’s almost two
- lactate is actually a useless proxy for someone who’s very deconditioned, because the minute they start moving their lactate will go from 1.5 to 2.5, but yet they’re barely feeling it
- So in those patients we actually don’t want to use lactate. Lactate doesn’t really kick in until a person’s quite fit

**How your zone 2 threshold changes with conditioning [29:30]**

Basically, when you first start doing zone 2 consistently, you will see improvements in your efficiency and therefore your zone 2 threshold may be at a higher output of work

However, at some point you will plateau and the only way to meaningfully increase your efficiency is to add more and more volume of zone 2 work

## Rucking as a versatile mode of exercise [31:45]

- In terms of what zone you are in while rucking, Peter says “it’s above and below and in.”
- For example, Peter is in zone 1 when on flat areas, he’s above zone 2 when walking on a hill, and when going downhill he’s probably zone 1
- At the end of the ruck, his average HR might have been a 130 (therefore zone 1), but that exercise was anything but zone 1 — it’s more like interval training

**importance of staying in zone 2 without interruption [33:00]**

If you go out for a four hour bike ride and your bike computer comes back and tells you spent one hour of that four in zone 2, that’s not the same as spending one hour straight in zone 2

There’s something about that form of exercise that requires staying in that zone and just letting the body crank through that metabolic pathway without interruption

***Rucking indoors?***

- Rucking on the treadmill is a fantastic way to get zone 2 and do so at a lower speed, frankly
- If you’re challenged by speed or challenged by elevation, by all means put a little poundage on

## Zone 5 exercise: modalities of training, time per week, and other considerations [34:30]

**Modes of zone 5**

- Doing your zone 5 via the same modality you do your zone 2 will lead to better crosspollination
  - if you’re doing the majority of your zone 2 on a bike, then doing your zone 5 on a bike will make you better
- That said, Peter likes to do zone 5 on the stair climber
- For the purposes of what we’re talking about, Peter likes to get people off the bike for at least some of what they’re doing, because life is basically handled off a bike
- If your only form of fitness is on a bike or a rowing machine, you’re missing a little bit of the necessary impact
- Therefore, I also think doing some of your zone 5 in that capacity as well, which again could be done on a treadmill with a ruck
- Could be done with a ruck sack outdoors, if you can find a long enough hill or could be done on a stair machine
- Peter does zone 5 once per week on Saturday

***Can you do zone 2 and zone 5 on the same day?***

- Peter recommends you do your zone 2 first and then your zone 5 on the same day
- Zone 2 makes for a great warmup for your zone 5 (it’s hard to do zone 5 without a big warmup)

Note: Peter’s zone 2 protocol is four days per week, and it’s 45 to 60 minutes depending on the day

## The importance of knowing your VO2 max, and methods for estimating it [38:15]

⇒ For more on VO2 max, check out [AMA #27](https://peterattiamd.com/ama27/)

***How to determine your VO2 max?***

Gold standard is [indirect calorimetry test](https://en.wikipedia.org/wiki/Indirect_calorimetry#:~:text=Indirect%20calorimetry%20calculates%20heat%20that,from%20their%20consumption%20of%20oxygen.)

- You’re in a lab and they’re putting a mask over your face, and they’re measuring with as much precision as is possible
- This is still an inexact science of course, but they’re measuring the rate of oxygen consumption and CO2 production
- Those two metrics are what allow you to calculate all the variables of interest.
- O2 consumption of course is all you need to calculate VO2 max
- But CO2 production gives you not just how much CO2 you’re making, but it allows you to calculate the [respiratory quotient](https://en.wikipedia.org/wiki/Respiratory_quotient), which then allows you to understand fuel partitioning and total energy expenditure

But just as with zone 2, **there are other ways to estimate your VO2 max**:

- If you have a really advanced sports watch, they’ll often have a feature on there that will sort of estimate your VO2 max based on how fast it thinks you’re moving, what your heart rate is, and then how much your heart rate recovers when you stop (not sure exactly how accurate these are)
- Running based tests are also common such as where you run a given distance and then take the time that you ran that distance in, multiply, divide it by something and that’ll give you a VO2 max.
  - How fast you can run a mile, assuming you’re running it all out, can be used to predict your VO2 max.
  - And those running based tests are reasonably accurate

-So do you have to go and do a test? “No”

-Is it something that’s worth doing a couple of times? “Yeah”

-But is it something you should be doing a couple times a year? “No”

*Using METs for VO2 max*:

- Some of the machines (treadmill or a good stair climber) will tell you how many METs you’re working at
- So they’ll tell you you’re at X many watts or  X METs and once you know how many METs you’re at, you can multiply that number by 3.5 and that tells you your VO2
- If you get to a point where you’re like, “This is my maximum MET, I can hold this for a minute.” Well, if you know that number, if that number is 15, you multiply 15 by 3.5, that would be an estimate of your VO2 max

![](https://peterattiamd.com/wp-content/uploads/2022/09/Ftk.-Vo2-max-estimate-ama39-784x1024.png)

**Figure 2.** Methods to estimate your VO2 max.

Looking closer at one method: **The Cooper method**

- This has a pretty high Pearson correlation coefficient, the R squared is about 0.93, meaning it’s pretty close to an actual measured VO2 max
- This one’s one of the easiest to calculate (not actually do)
- Run as far as you can in 12 minutes
- Measure the distance that you cover in 12 minutes, so you do it in miles, multiply that by 36 and subtract 11.3
- So if you can run two miles in 12 minutes, so you’re able to run a six minute mile times two, multiply that by 36 is 72, subtract 11.3, your VO2 max is about 61 milliliters per minute per kilogram
- These are pretty accurate ways to assess your VO2 max

**\*One other point about testing your VO2 max**:

- You have to do the test in an activity that you are comfortable doing.
- whatever you pick to do this test in whether it be at the lab or whichever one of these metrics you use, make sure it’s the thing that you’re used to doing
- When we send our patients to the lab, unfortunately, you only have two choices, it’s treadmill or bike
- We really make sure that they are in the one that they are more comfortable in. Otherwise, the test can also grossly underestimate their capacity.
- If you’re going to go through the hassle of doing the test, spend a bit of time doing that thing before the test
- Get comfortable being at full level of exertion

## Training methods for improving VO2 max, and realistic targets for improvement [46:00]

⇒ For more, see [episode of The Drive with Mike Joyner](https://peterattiamd.com/mikejoyner/)

Here we have pretty clear evidence

- There’s a sweet spot in the intervals that you want to be using—you want them to be longer than what most people think of as hit intervals
- If you do something like a Tabata, you will increase your VO2 max, however it’s not the “best” for Vo2 max
  - So what is a Tabata? It’s an interval that looks as follows:
  - It’s about 20 seconds of all out work followed by 10 seconds of rest repeated eight times
  - So it’s a single four minute interval where you do 20 seconds of work, 10 seconds of rest repeated that for four minutes
  - So this is the quintessential high intensity interval workout
  - And those types of workouts absolutely increase VO2 max
- By the way, rucking increases VO2 max
- There are infinite way to train to increase VO2 max

That said, nothing does it better than about the **four to six minute interval at about a one to one ratio of rest to recovery**

- Peter typically prescribes four by four intervals for patients
- You do four minutes of about as hard as you can go for four minutes, followed by 4 minutes rest in between
- The goal is to roughly maintain intensity and a lot of times even try to slightly increase what you can do for each 4 minute interval
- Think about doing these on a bike, you’re always doing it by wattage: So you’d go four minutes at basically as high a wattage as you could hold for four minutes, and then you’re doing completely nothing for four minutes
- And then you just repeat 4 to 6 times
- Peter would do this for six sets, twice a week

**Studies showing longer interval training increases VO2 max**:

- [Linear increase in aerobic power induced by a strenuous program of endurance exercise](https://pubmed.ncbi.nlm.nih.gov/838658/) | Journal of Applied Physiology (RC Hickson et al. 1977)
- [VO2max Trainability and High Intensity Interval Training in Humans: A Meta-Analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0073182) | PLOS ONE (AP Bacon et al. 2013)
- [High-intensity interval training in patients with lifestyle-induced cardiometabolic disease: a systematic review and meta-analysis](https://bjsm.bmj.com/content/48/16/1227.long) | British Journal of Sports Medicine (KS Weston et al. 2014)
- Meta-analysis of the impact of interval training on VO2 max: [VO2max Trainability and High Intensity Interval Training in Humans: A Meta-Analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0073182) | PLOS ONE (AP Bacon et al. 2013)

***What is a realistic target for increase in VO2 max that someone could get? [48:45]***

*Let’s say you have a patient who comes in. They haven’t been really exercising. They’re at 35, is it realistic in a year they could maybe get to 45, 55. How do you talk through that with patients?*

The answer to this question depends on a couple things:

- When we talk about VO2 max, the implicit thing we’re baking into this is that we are talking about it normalized per weight
- All the numbers these calculators are spitting out, they’re all weight adjusted, that’s totally baked into them
- Meaning it’s in milliliters of oxygen per minute per kilogram
- But it’s important to understand when you sit on that bike and do the test or when you’re in the treadmill doing that test, that indirect calorimeter doesn’t care how much you weigh—It’s giving you liters per minute of oxygen consumed

So when you’re trying to boost your VO2 max, technically you’re trying to do two things:

- 1 – You’re trying to increase how many liters per minute of oxygen you can consume while 2 – minimizing your body weight
- And so when Peter says his VO2 max 8 years ago was 70, it’s also important to understand he was 10 kilograms lighter than he is today
  - “*Even if today I could do the same volume of oxygen, call it 5.2, 5.3 liters. My VO2 max would be much lower than it was before, just on the basis of the fact that I’m 10 kilos heavier*.”

Peter likes to separate these metrics for people:

- “How much can you increase in absolute amounts in the oxygen consumption in liters per minute?”
- “And how much weight could you lose while doing that?”

***So how much can you expect to boost your VO2 max?***

- Like all things, the lower you start at, the more you can increase it
- If you took the fittest cyclist in the world at their peak, a year late you’re going to get much more VO2 max out of them
- If you take someone who’s completely deconditioned, you can squeeze a lot of juice out of that
- One study ([Hickson et al. 1977](https://journals.physiology.org/doi/abs/10.1152/jappl.1977.42.3.372)) had an average VO2 max pre-training ~38 ml/kg/min, and after 10 weeks of training was ~ 55 ml/kg/min (approximately 17 ml/kg/min change in 10 weeks under very strenuous dedicated training)
  - At the end of their 10 week training program , VO2max was continuing to increase, but the training was so arduous that all of the participants declined to continue (**6 days/wk – 3 days of cycling HIIT 5\*5 mins at VO2max followed by 2 mins of active recovery at 50-60% VO2max and 3 days of 40 mins of running**)
  - It’s a small study of healthy, relatively young participants (ages 20-42), who were mostly not training in any dedicated way
  - Ceiling on VO2max will be age and training dependent
- [Mike Joyner talked about this in the podcast](https://peterattiamd.com/mikejoyner/)—he said you could get 10 to 20% of a VO2 max boost if you train specifically and consistently
- The weight loss/fat loss component also can increase your VO2 max

## Relationship of VO2max with age and the required fitness levels for daily life activities and exercise [52:30]

![](https://peterattiamd.com/wp-content/uploads/2022/09/ftk.-vo2-for-daily-activities-849x1024.png)

**Figure 3. Relationship of VO2max with age and the required cardiorespiratory fitness levels for daily life activities and exercise.** [Data compiled by [Jayson Gifford](https://twitter.com/JaysonGifford/status/1537185279781482496) from the 2020 ACSM’s guidelines for exercise testing and prescription]

- On the Y axis here, you’re looking at VO2 max
  - Again, whenever you see numbers that are so big like 10, 20, 30, 40, 50, 60, 70 you know you’re looking at it normalized by weight
  - If you’re looking at absolute VO2 max in liters per minute, you’re going to look at two, three, four and five liters
- On the X axis you see age
- And then you see three curves, a green one, a black one, and a red one
  - The green one shows a high fitness individual
    - Someone who is in the top 5% of VO2 max for their age
  - In the black curve you look at somebody right in the middle of the bell curve.
    - This is somebody at the 50th percentile of fitness for their age
  - And the red curve is the lowest level of fitness.
    - These are people at the 5th percentile, so the bottom 5%
- It now shows various activities and explains what VO2 is necessary
  - Remember VO2 is ventilation rate of oxygen, VO2 max is what is the maximum ventilation rate of oxygen
- What this is showing is what is the VO2 for various activities
  - At the top it’s showing you to run at 10 miles per hour, which is a six minute mile and it’s telling you that’s about a 57 VO2 max
  - Now, knock that down to running six miles per hour, which is a 10 minute mile—now you’re at about a VO2 of 35
  - If you want to be able to walk three miles an hour on a flat, that’s about a VO2 of call it 12
  - If you want to be able to do that on an incline somewhere between 20 and 25, depending on the steepness of it
  - If you want to climb stairs slowly it’s a VO2 of 32
  - If you want to be able to go upstairs pretty quickly, that’s closer to 45

\*It’s important for people to understand where activities lie in the broader scope of life

- Peter has picked out all the activities that matter to him late in life (aka the Centenarian Decathlon)
- Peter has come to the following conclusion: “***I’m going to be frustrated if my VO2 max ever falls below 32***.”
  - So when he can’t reach a minute ventilation of 32 milliliters of oxygen per minute per kilogram, his life will begin to be physically compromised
  - Peter’s objective is to always make sure his VO2 max remains above 32 mls per minute per kilogram.
- According to these data, the average person exceeds that limit by about the age of 50
  - In other words, the average 50 year old is already at that threshold of fitness that I’m saying I don’t ever want to be below
- Note that the people in the bottom 5% are already below that, and they were below it even at the age of 25
- By the way, the top 5% of the population will get there by about 80
- Peter is planning to live beyond 80 which means he needs to have an even higher VO2 max than the green line on this curve
- “*And it might sound stupid to want to do that at 85 or 90. I certainly want the optionality*.” says Peter

> “Just line up for me all the 90 year olds who are saying, ‘I wish I had less muscle mass. I wish I was less strong. I wish I was less fit. I wish I could climb fewer stairs.’ These words have never been uttered in the history of our species.” —Peter Attia

## The training necessary to maintain an elite VO2 max throughout life [58:45]

***For someone wanting to have an elite VO2 max (i.e., top 2.5 percentile), can you do that if you’re not training more than 75 MET hours per week?***

- Peter says he doesn’t think you need to be training 75 MET hours per week to just have a VO2 max that’s on that top, top trajectory
- HOWEVER, you will need to be training at least 75 MET hours per week, if in addition to training to have that level of cardiorespiratory fitness, you also want to have the strength/stability that matters
- “*If I’m mapping out the time and energy that goes into the stability training, the strength training, the aerobic base and the peak, it’s hard for me to see doing this under 75 MET hours per week*.” says Peter

You can get a sense as to why VO2 max decreases with age when you think about the three things that contribute to VO2 max:

- 1 – Maximum heart rate, which is a huge contribution to cardiac output
  - So cardiac output is heart rate times stroke volume. So with each beat of the heart, you’re pumping that stroke volume out around the body, and that’s a big part of what’s delivering oxygen to the muscle
  - Maximum heart rate declines with age, it’s reported to drop roughly linearly
- 2 – Lean body mass of course is a contributor
- 3 – Then of course cardiovascular training

We’ve definitely looked at [studies](https://journals.physiology.org/doi/abs/10.1152/jappl.1977.42.3.372) where under 75 MET hours per week, you can achieve very high VO2 maxes.

- Internally, the team looked at this and did some analyses looking at some of the studies. And we’re looking at people that are achieving top 5% VO2 max, training 60 MET hours per week total

The amount of time this take really just comes down to how much other training do you want to put in for these other activities (strength/stability)

- Peter says, “In my view, the answer is it’s pretty hard to get there below 75 [MET hours per week}, if you’re going to devote 60 [MET hours per week} to your cardiorespiratory fitness.”

## The value in starting early: the compounding nature of fitness [1:01:45]

**Value in starting early**

- There’s no area in which compounding plays a greater role than in this arena
- It’s even more relevant than in wealth accumulation
- Everybody understands if you want to retire at 65 and live a life of leisure that follows, you have to work really hard before you’re 65 and save a lot of money AND that money needs to be compounded (i.e, you need to generate a return on that money)
  - If you start saving at 25, it’s a very different proposition than if you start saving at 45 or 55, if your goal is to retire at 65
- And what that example doesn’t even take into account is a windfall
  - if you’re thinking about this through a financial lens to say, “Well, okay, I’ll save probably not as much as I should save, but maybe I’ll work a little bit later, or maybe I’ll win the lottery, or I’ll get an inheritance
- But the reality of it is with exercise here is no lottery equivalent. There is no inheritance of money or equivalent. Everybody is on the same footing.
- Everybody is going to have to grind their way through the savings return compounded over time formula to get the benefits when they’re done

> *“Time, intensity, and specificity are going to be necessary components to give you the optionality to be able to be as physically active as possible when you’re in the final decade of your life.*” —Peter Attia

§

## Selected Links / Related Material

**Previous AMA discussing the Centenarian Decathlon**: [#50 – AMA #5: calcium scores, Centenarian Decathlon™, exercise, muscle glycogen, keto, and more](https://peterattiamd.com/ama05/) | Peter Attia (peterattiamd.com) [4:00]

**AMA episode about bone health**: [#214 – AMA #37: Bone health—everything you need to know](https://peterattiamd.com/ama37/) | Peter Attia (peterattiamd.com) [8:00]

**AMA discussing MET hours**: [#218 – AMA #38: Can you exercise too much?](https://peterattiamd.com/ama38/) | Peter Attia (peterattiamd.com) [8:30]

**Phil Maffetone’s method for determining zone 2**: [The MAF 180 Formula](https://philmaffetone.com/180-formula/) | (philmaffetone.com) [27:00]

**Episode of The Drive with Phil Maffetone**: [#144 – Phil Maffetone: Optimizing health and performance through maximal aerobic function](https://peterattiamd.com/philmaffetone/) | Peter Attia (peterattiamd.com) [27:00]

**Episode of The Drive with with Mike Joyner**: [#217 ‒ Exercise, VO2 max, and longevity | Mike Joyner, M.D.](https://peterattiamd.com/mikejoyner/) | Peter Attia (peterattiamd.com) [46:15]

**Studies showing longer interval training increases VO2 max**: [51:45]

- [Linear increase in aerobic power induced by a strenuous program of endurance exercise](https://pubmed.ncbi.nlm.nih.gov/838658/) | Journal of Applied Physiology (RC Hickson et al. 1977)
- [VO2max Trainability and High Intensity Interval Training in Humans: A Meta-Analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0073182) | PLOS ONE (AP Bacon et al. 2013)
- [High-intensity interval training in patients with lifestyle-induced cardiometabolic disease: a systematic review and meta-analysis](https://bjsm.bmj.com/content/48/16/1227.long) | British Journal of Sports Medicine (KS Weston et al. 2014)
- **Meta-analysis of the impact of interval training on VO2 max**: [VO2max Trainability and High Intensity Interval Training in Humans: A Meta-Analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0073182) | PLOS ONE (AP Bacon et al. 2013)

§

## People Mentioned

- [Tom Morello](https://en.wikipedia.org/wiki/Tom_Morello) [16:15]
- [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin) [16:30]
- [Jack Dorsey](https://en.wikipedia.org/wiki/Jack_Dorsey) [16:30]
- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) [19:45]
- [Phil Maffetone](https://twitter.com/drphilmaffetone?lang=en) [27:00]
- [Iñigo San Millán](https://peterattiamd.com/inigosanmillan/) [40:00]
- [Mike Joyner](https://docs.google.com/document/d/1DyE9UJBcbs0TAun1Lpv1up3DPgU_qg8HbMyTvX-iykY/edit#217%20%E2%80%92%20Exercise,%20VO2%20max,%20and%20longevity%20%7C%20Mike%20Joyner,%20M.D.) [46:15]
- [Tim Ferriss](https://en.wikipedia.org/wiki/Tim_Ferriss) [58:15]
- [David Goggins](https://en.wikipedia.org/wiki/David_Goggins) [58:15]

§