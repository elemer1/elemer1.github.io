# #154 – Steve Levitt, Ph.D.: A rogue economist’s view on climate change, mental health, the ethics of experiments, and more

**Source:** [https://peterattiamd.com/stevelevitt/](https://peterattiamd.com/stevelevitt/)

---

Steven Levitt is a professor of economics at the University of Chicago and the co-author of the bestselling book Freakonomics and its two sequels. In this episode, Steve discusses his unlikely path to a career in economics and his view of the current state, and limitations, of the field. He also gives his unique perspective on contemporary issues including climate change, mental health in education, how to evaluate whether an experiment is ethical, decision making, horse racing, and much more.

[\*WATCH PODCAST ON YOUTUBE\*](https://www.youtube.com/watch?v=kGZi3OxitKk)

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/stevelevitt/the_Drive_public.png)

Play

#154 - Steve Levitt, Ph.D.: A rogue economist's view on climate change, mental health, the ethics of experiments, and more

#154 - Steve Levitt, Ph.D.: A rogue economist's view on climate change, mental health, the ethics of experiments, and more

1x15s30s

0:002:00:19

## We discuss:

- How Steve ended up in economics (2:45);
- Current trends in the field of economics: macro vs. micro, usefulness of models, and the relationship between data and theory (8:45);
- Revisiting what Steve wrote about climate change in SuperFreakonomics, and why it’s unlikely to be solved with behavioral change (18:45);
- The consequences of a blurred line between climate science and advocacy (27:30);
- Answering climate questions with a “Manhattan Project for climate change” (31:45);
- Steve’s reflections on his career path and how he found his way by being himself (40:00);
- How Steve came to write Freakonomics (and its sequels), and the topics which caused the most controversy (53:00);
- How Steve came to appreciate mental health through parenting, and the need to emphasize mental health into the education system (1:10:15);
- Why people are bad at making decisions (1:26:45);
- Deliberating on why horse racing times haven’t advance much in decades (1:34:30);
- Reducing the impact of negative emotions by observing the world free of language (1:44:00);
- Changing our thinking about what it means to conduct experiments ethically (1:49:00); and
- More.

§

## Show Notes

## How Steve ended up in economics [2:45]

- Steve was not interested in economics
- At Harvard, he sought out the courses most students took because they were easy, and the introductory economics course was one
  - During a lecture on comparative advantage, Steve was annoyed because he thought it was so obvious
  - But the same lecture had confused his friend, so he realized that way of thinking came naturally to him

> “It became clearer and clearer to me that I was just born thinking like an economist” —Steve Levitt

- Did management consulting but hated it, so got PhD in economics
- He feels lucky because his career ended up being the result of “a series of mistakes, miscalculations and ignorance”

## Current trends in the field of economics: macro vs. micro, usefulness of models, and the relationship between data and theory [8:45]

**Macroeconomics vs. microeconomics**

- Macroeconomics
  - What most people think of when they hear “economics”
  - Things like inflation, banking, unemployment, economic growth
  - Very complex and economists haven’t done a good job of understanding it
- Microeconomics
  - Study of individual decision-making
  - E.g., how people decide how to spend income, how one chooses a job and how many hours to work, etc.
- Can analyze with formal model based on rationality or newer models like behavioral economics that takes more psychology and mistakes into account
  - Econ has traditionally been a theoretical discipline
  - But now also econometrics, analyzing “messy” data

> “Macro in the end is really complicated. . .very self-referential models because the problems are so hard that you need to abstract so greatly to try to deal with the macro problems that I think we don’t have a good handle on them. So I’ve really steered clear of the macro problems to focus on the individual decision-making, which is, I think, … much more relevant.” —Steve Levitt

**Current trends in economics**

- Two big prizes in econ are Nobel Prize and the [John Bates Clark Medal](https://en.wikipedia.org/wiki/John_Bates_Clark_Medal) (given to the most influential American economist under the age of 40)
  - Steve [won](https://www.aeaweb.org/about-aea/honors-awards/bates-clark/steven-levitt) the Clark medal in 2003
  - In the last 20-30 years, the Clark medal has gone to people who address the *intersection* of theory and data

*Economics at a crossroads…*

- New challenges in econ
  - data analysis helped shed light on causality
  - empirical aspect became key
  - But… all of the “easy” stuff has been done
- What comes next?
  - Want to build new models to try to predict what would happen if change parameters
    - For example, what if the US had been a dictatorship instead of a democracy?

> “What economists do now is they’re asked not just to estimate parameters really well, but to embed those parameters into models, which then have enough degrees of freedom that you can start to imagine: if I turn this dial to that dial, what would happen?” —Steve Levitt

- Steve thinks this is a bad direction because “fanciful” models are too complex to yield useful estimates
- Peter says it’s like the famous quote “***All models are wrong. Some are useful.***”
  - Peter says coronavirus models were grossly inaccurate because “the sensitivity around so many variables was so great that you couldn’t even begin to extrapolate”
  - showed how impossible making a good prediction would be
  - Rate of spread and length of dormancy were critical parameters
  - Focus was on how many might get it and how many die rather than setting up earlier and more aggressive testing

Steve has a “very strong view about the relationship between data and theory”

- Must be clear about the differences between data and theory
- Can’t determine causality or other factors from data alone
- If can agree on facts, various models can be understood and evaluated by other economists
  - When have a debate, must ask if people disagreeing about the facts **or the implication of the facts**
  - Would help journalism to lay out the facts articles are based on, then can evaluate those first
  - Establishing agreement about facts is critically important

> If they disagree about facts, then we’re in a very different situation than if we disagree about the implications of those facts. And somehow. . .That distinction, I’ve never really heard anyone talk about it except for me. . .but it strikes me as being really, really important.” —Steve Levitt

## Revisiting what Steve wrote about climate change in *SuperFreakonomics*, and why it’s unlikely to be solved with behavioral change [18:45]

[*SuperFreakonomics*](https://en.wikipedia.org/wiki/SuperFreakonomics) was the second book Steve wrote with co-author [Stephen Dubner](https://en.wikipedia.org/wiki/Stephen_J._Dubner) about 10 years ago

**Upshot of what they wrote about climate change**:

- At the time, there was evidence that planet getting warmer (although not open and shut)
- Steve and Dubner argued people were asking wrong question:  It’s not how to reduce carbon emissions, but rather, what is the best way to cool the planet
  - Example he uses: kids and poop on the floor — The question is not how to stop them from pooping but how to keep poop off ground
  - Answer to second question is a diaper, different answer than trying to prevent poop from existing
  - Don’t necessarily have to reduce carbon emission if find another way to cool planet
- Starting with that premise, they talked to geoengineers who had ideas like putting sulfur dioxide into the stratosphere
- Steve’s favorite idea was “Cloud theory”:
  - Certain clouds could reflect back sunlight
  - GPS-controlled solar-powered dinghies would extract salt from the ocean, creating a layer of these clouds
  - Based on simulations, scientists claimed that 10K of these dinghies could offset climate change
- “In retrospect, I regret that we wrote about it in such a lighthearted way”
  - Some environmentalists reacted angrily without evaluating argument
  - Now, 10 years later, agreement that geoengineering will some part of the solution
  - [*The Atlantic*](https://www.theatlantic.com/) [had](https://www.theatlantic.com/culture/archive/2009/10/superfreakonomics-on-global-warming/341861/) [implied](https://www.theatlantic.com/business/archive/2009/10/superfreakonomics-author-your-job-is-to-attack-us/29163/) that their climate change arguments were not evidence-based, but it later published an [article](https://www.theatlantic.com/science/archive/2015/11/its-time-to-start-talking-about-geoengineering/414283/) discussing solutions very similar to those in the book chapter without mentioning them

> “I think it’s good not to worry about whether you’re right or you’re credited for it. I think you just have to be happy that the movement, although way too slow, has been in the right direction” —Steve Levitt

**Why climate change will not be solved by behavior changes**:

- Climate change not likely to be solved with behavioral changes
  - Why? ⇒ Because it’s all about what economists call [externalities](https://en.wikipedia.org/wiki/Externality)—when an individual’s own behavior has almost no effect on the individual but a negative effect on the rest of the world
  - No problem about externalities has ever been solved by encouraging people to change their behavior
- Is there an example where people do the right thing, even if inconvenient, to help others?
  - Maybe social norms on the roads, but even that is based more on avoiding angry reactions from other drivers
  - Big problems that have been solved were solved by technology / inventions / discoveries, not through behavior change

Smoking—a case study on behavioral change

- Even though overwhelming evidence, it still took 40 years for people to cut down and some people still smoke
- Peter says it wasn’t the knowledge that tobacco killed you that led to reduction
- Interesting case study of behavior change
  - After [1964 Surgeon General’s Report](https://profiles.nlm.nih.gov/spotlight/nn/catalog/nlm:nlmuid-101584932X202-doc), harm was clear
  - Peter points out that the hazard ratio was about 14: “There’s nothing in biology that produces a hazard ratio of 14 times outside of parachuting without parachutes”
  - But first real change (5-6 year later) was due to anti-tobacco advertising
  - Other laws like requiring products to be behind the counter, taxes, smoking bans on airplanes, etc.
  - Change wasn’t as much about behavior change as it was changing the default environment
    - Steve says it used to be cool to smoke and that has changed
    - The costs / benefits changed dramatically
    - “If anything, it’s surprising how little behavior change has followed that as opposed to how much” says Steve

## The consequences of a blurred line between climate science and advocacy [27:30]

- Peter says climate change is “*like nutrition, where there’s a very gray area between true scientific expertise and propaganda*”
- Peter has some sympathy for lay people who are losing faith in the scientific process
- Science has been used as an ideological weapon and people feel misled
- Steve says climate science is similar to macroeconomics because it’s based on models that are too complex to have much specificity
  - For example, considered carbon dioxide but didn’t factor in water vapor
  - Measurements of ocean temps and levels have been done well
- Blurring of line between measuring climate change and advocating for specific public policies to address it: “as a scientist, you want to be very careful about moving from one role to the other”
  - If you are a climate change scientist, you are very likely to believe that we should be doing something about it
  - it’s different from physics, where they are unlikely to have an opinion about whether the universe should be expanding or a particular particle should exist
- With climate change, haven’t considered things like economics or the difficulty of behavior change
  - Costs of “zero carbon” world are very high and we pay them right away
  - Doesn’t necessarily mean we shouldn’t do it, but have to be realistic about practical aspects
  - Many have either ignored these costs or even said that humans “deserve” to suffer because they are ruining the planet
  - Statements made by environmentalists like [Al Gore](https://en.wikipedia.org/wiki/Al_Gore) often have an odd religious or moralistic feel; not everyone is willing to suffer or convinced we should

## Answering climate questions with a “Manhattan Project for climate change” [31:45]

Steve says that if he could do one thing in this world, it would be to “*have a sensible approach to figuring out whether there is a cheap solution to climate change*”

- We should have a [Manhattan Project](https://en.wikipedia.org/wiki/Manhattan_Project) for climate change
  - capitalist structure has not worked well
  - gather scientists together and give them resources to work on it
  - People would be a lot more willing to impose onerous policies if knew reducing carbon emissions was the only answer
  - If gave a group of top scientists 5 years to work on it, we’d either figure out a cost effective way to deal with it or realize that we can’t solve it

> “I think if we had the best 1,000 scientists, within five years, we would come up with a reasonably cost effective way to deal with carbon. We’d pull it out of the air in some way, shape or form, and we’d kind of have the thing solved. Or we’d know we’re never going to solve it and those are two important things to know.” —Steve Levitt

Peter reiterates something Steve said:

- “If we were going to list the 10 human failures, just as a species, it’s that we are not wired to differentiate between objectives, strategies, and tactics”
- Climate advocates have lost sight of the objective: to slow warming
- Peter’s biggest concern is not whether we could figure out a solution, but whether we could actually implement it from a policy perspective

Discussing tactics:

- Reduction of carbon as a tactic
  - Steve’s discussion of geoengineering was an alternative tactic, but he was lambasted for discussing it
  - What he was trying to do was step back and focus on the objective, which is slow global warming using whatever tactics make sense
- Peter agrees that in about 5 years a well-staffed team given proper resources could come up with a picture of what solutions could look like
  - but he doubts that their policies could be implemented
  - Scientists think that “next gen” nuclear will be important to generate electricity, but it’s not “politically palatable”

*Taking a* ***preemptive approach*** *to potential world catastrophes*

- Steve points out that another challenge is to do it now rather than when we are dealing with a catastrophe
- 6-7 years ago on Steve’s podcast, [Moncef Slaoui](https://en.wikipedia.org/wiki/Moncef_Slaoui) suggested having a vaccine bank so there would be both a small supply and the knowledge of how to make it
  - He was criticized because of the cost (~$500 M)
  - But now US is “is bleeding $6 billion a day in deficits” and the vaccine bank could have been “the best investment of all time”
- Steve thinks worth it to work on these things even in today’s policy world because even if can’t implement them now they can serve as an insurance policy for when we do need them
- Peter agrees because of asymmetric risk: high uncertainty but nonlinear so very serious if goes wrong
- Ten+ years ago, a study looked at how much people would pay to avoid bad outcomes
  - Steve was shocked by the results
  - To avoid a 1% chance of dying today, people were willing to pay not 1% but about 10-15% of their total wealth
  - As risk of dying went up to 5%, people were willing to pay up to 50% of their wealth to avoid it
  - It’s counterintuitive and changed how he thought about climate change
- Research and development (R&D) costs are low compared to implementation and disaster costs, so doing R&D is a “no brainer”
  - Could fund the climate change Manhattan Project for about $1 B per year
  - could be funded by philanthropists rather than government
  - Very expensive to implement solution but relatively cheap to work out solution
  - Similar to COVID vaccine: took Moderna a few days to come up with vaccine, the real costs were in production and testing

> “The actual R & D part is so cheap compared to everything else, that to not invest in it just seems a first order mistake to me.” —Steve Levitt

## Steve’s reflections on his career path and how he found his way by being himself [40:00]

- While working as a consultant he learned to look at the world strategically from his colleague [Jeff Thomas](https://www.linkedin.com/in/jeff-thomas-66bb098/) and carried that with him into grad school
- He didn’t know the math and was outmatched by his classmates
  - His classmates, including [Austan Goolsbee](https://en.wikipedia.org/wiki/Austan_Goolsbee), decided he’d be the least likely to succeed
  - But he understood that he needed to be a producer rather than a consumer of knowledge
- He eventually found his place in **data analysis**
  - Started in macroeconomics at MIT but quickly realized he lacked the intuition for it
  - Then he tried being a theorist but that was also not his strength
  - Then moved to data analysis, which was a good match for him
  - When he was about 9 he would plug baseball stats into a calculator and calculate the partial correlation among the variables
  - Was too focused on status to realize data analysis was a natural choice for him
  - He was far behind others when he started
    - but not being the best felt liberating to him
    - pressure was gone and he could do what he wanted
  - Couldn’t compete with the others so found his own space — he was shocked when people actually liked it and he was published in good journals

> “Honestly, I look back and I say, ‘I’m so lucky to have been so far below the bar that I didn’t try to do what I think most people do.’ … I just was myself and it was such a great lesson. … But the great thing about life is when things don’t work, you can take a different path. So I just try to be myself and I stop doing stuff when being myself isn’t a good recipe for it.”  —Steve Levitt

- He went to Chicago to “get to know the enemy”
  - found that [Gary Becker](https://en.wikipedia.org/wiki/Gary_Becker) had been unfairly portrayed
  - Becker asked great questions and became a mentor to Steve
  - At Chicago, there is a deep and powerful way of thinking about economics that Steve never fully mastered
  - At that time it was rare to choose Chicago if you had other options, but it turned to be the right thing for him
- Elite programs are now more homogenous
  - [Milton Friedman](https://en.wikipedia.org/wiki/Milton_Friedman) lamented that [Chicago](https://bfi.uchicago.edu/initiative/price-theory/) [Price](https://www.investopedia.com/terms/t/theory-of-price.asp) [Theory](https://www.youtube.com/channel/UC54kFKpGsjpyAgNSce-mR6Q) was dying out
    - [Casey Mulligan](https://en.wikipedia.org/wiki/Casey_B._Mulligan) pointed out that this was a contradiction
    - suggested Friedman didn’t actually believe in markets when they didn’t move the way he hoped
  - Peter says medicine was similar
    - difference between east and west coast and among cities
    - led to innovations
- Steve says diversity of approaches is good because generates useful data
  - especially in dynamic fields where radical change can happen and one model is better suited to respond
  - The Chicago style of macroeconomics won, but Steve wishes there were more diversity in thinking to deal with emerging challenges

## How Steve came to write *Freakonomics* (and its sequels), and the topics which caused the most controversy [53:00]

- Meeting [Steve Dubner](https://en.wikipedia.org/wiki/Stephen_J._Dubner), his [*Freakonomics*](https://www.amazon.com/Freakonomics-Economist-Explores-Hidden-Everything/dp/0060731338) co-author
  - Dubner is a journalist who approached Steve to write a [NYT article](https://www.nytimes.com/2003/08/03/magazine/probability-that-real-estate-agent-cheating-you-other-riddles-modern-life.html)
  - Steve was not enthusiastic, but he agreed
  - Dubner had read numerous academic articles
  - They talked for 25 hours over 3 days though Steve had thought it would be about 3
  - At first found the experience excruciating, but then began to ask Dubner questions back and heard fascinating stories
  - Thought Dubner portrayed him as a genius who solves problems in an hour, which Steve says is not accurate but benefitted his public image
- Ended up writing [*Freakonomics*](https://en.wikipedia.org/wiki/Freakonomics) together
  - Steve says it was for money and not out of passion
  - Steve [interviewed](https://freakonomics.com/podcast/pima-suzanne-gluck/) their agent, [Suzanne Gluck,](https://wnba-nyc.org/meet-our-panelists-the-intersection-of-literary-and-commercial-fiction/) on his [podcast](https://freakonomics.com/archive/) about how she negotiated a lucrative book deal but they had no idea what the book would be about
  - They assumed few people would read the book so had fun writing about whatever they wanted without much fear of judgment or professional consequences
- Came out in 2005 and Peter read it then; couldn’t put it down even though he had no time to read anything non-medical

**Some topics in the Freakonomics book**:

*-Car seats*:

- There was only about a paragraph on car seats, but that created the most negative feedback

*-Abortion and crime:*

- Steve assumed that would be the most controversial part of book
- In 2001, the media had misportrayed Steve’s [academic work on the topic](https://pricetheory.uchicago.edu/levitt/Papers/DonohueLevittTheImpactOfLegalized2001.pdf), oversimplified it
- Was easy to parody, made them look stupid or crazy
- Public discussion about abortion usually controlled by people who have a stake in it, but they didn’t
- Data was imperfect because not a controlled experiment, but after abortion was legalized the crime rate was similar for about 15 years and then began to diverge depending on the comparative ease of abortion access in different states
- Steve found it odd that people from both sides of the abortion debate felt that he had affirmed their view

*-How realtors are similar to the KKK*:

- He actually got invited to speak at National Realtors Association even though had joked about realtors being like the KKK
- After the first book, they were sort of known as “fun-loving economists” who poked fun at everyone

**Second book was** [***SuperFreakonomics***](https://www.amazon.com/SuperFreakonomics-Cooling-Patriotic-Prostitutes-Insurance/dp/0060889586)

- Garnered a lot of criticism
- Steve says topics like climate change “hit a little closer to home”

**Third book was** [***Think Like a Freak***](https://www.amazon.com/Think-Like-Freak-Authors-Freakonomics/dp/0062218344)

- “by that time we had alienated everyone”
- Stopped writing because public was now hostile

**Considered a 4th book about the Freakonomics approach to golf**

- About 6-7 years ago Steve tried to convince Peter to be the protagonist
- At around age 40, Steve tried to apply data to make himself a professional golfer, but he never got good enough although his game improved a lot
- Had developed set of tools to improve golf game
- Wanted someone with strong drive and physical talent who had never played golf before to see how far they could get in a year
  - Peter considered it but was afraid he’d develop an obsession with golf
- Steve was asked to join a gathering with [Larry Summers](https://en.wikipedia.org/wiki/Lawrence_Summers) when he visited Chicago
  - Summers wanted Steve to help him with golf game and take his handicap from 20 to 5
  - But Summers was a bad student and wouldn’t follow the plan or practice

Where the title “Freakonomics” came from:

- Steve’s sister made up the Freakonomics title
  - Publisher was against it, but Steve and Dubner eventually convinced them
  - Publisher had suggested bad titles like “e-Ray Vision” (e for economics)
  - Lucked out that chose right title to sell

Many lucky occurrences made book sell

- Good [review](https://www.wsj.com/articles/SB111334626457705169) in the WSJ
- Steve [appeared](https://www.cc.com/video/vra7sa/the-daily-show-with-jon-stewart-steven-levitt-pt-1) [on](https://www.cc.com/video/64us5h/the-daily-show-with-jon-stewart-steven-levitt-pt-2) the Daily Show with Jon Stewart
- There are many good books that no one reads: the correlation between how good something is and how much attention it gets is much lower than people think

## How Steve came to appreciate mental health through parenting, and the need to emphasize mental health into the education system [1:10:15]

Peter and Steve have a shared appreciation of mental health: See [Peter’s appearance on Steve’s podcast](https://freakonomics.com/podcast/pima-peter-attia/)

\*\*\*

**How Steve came to appreciate mental health**

- Steve’s father opposed therapy and he was not allowed to cry
- Steve’s grandfather committed suicide at age 90 (although Steve pointed out that his sucide was actually not related to mental illness, but rather his grandfather was seemingly mentally well and decided to take his own life when he became ill as to not be a burden on his family)
- Steve got divorced and his current wife Suzanne got him thinking about these issues about 7 years ago
- Reevaluated the idea that just had to fight through it and not seek help for mental health issues

> “I somehow shook off a lifetime of teaching which told me that mental health was a joke and you just got to fight through it and came to appreciate it. . .I’ve come to believe now that they are dramatically more important than our education system or our society has traditionally given them credit for.” —Steve Levitt

**Parenting**

Steve’s daughter has an eating disorder

- He understood the serenity prayer and knew he could not control her disorder
- He believes that staying calm and understanding that there was little he could do about her anorexia helped her be comfortable with him
- Steve understands that with his adult children he’s an observer who can offer advice but has no control
  - On that note, Peter remembers that his friend [Ric Elias](https://www.redventures.com/about/leadership?modal=ric_elias) (who has been on the [podcast](https://peterattiamd.com/ricelias/)) said something like “*raising children is playing a game of tug of war that you have to lose*”
  - You’re winning when they’re 5, starting to slip when they’re 13, and when they’re 18, it’s their rope

Steve’s first son died of meningitis when he was one year old

- Was “a thousand times harder than anything I’ve ever experienced” because he had not been able to keep him safe
- Affected his parenting of his other 6 kids
  - You can be fearful and overprotective like Marlin, the dad in the movie [*Finding Nemo*](https://en.wikipedia.org/wiki/Finding_Nemo)
  - Or you can accept that the world is full of uncertainty, loss, and risk
  - Steve took the second path and accepted that he can’t mold or shape his children the way he’d like to

Steve values autonomy and independence

- Believes a good way for his 4-year-old daughter to learn about control is to have some control in her interactions with him
- Opposite of way he was raised and probably would have done the same if he had not lost his son Andrew

**The benefit of “radical acceptance”**

- One of the core tenets of [dialectical behavioral therapy](https://en.wikipedia.org/wiki/Dialectical_behavior_therapy) is radical acceptance, where one must accept things even when they are devastating
- Steve says he did it unconsciously, wasn’t something he thought about or worked on
- Thinks it might be easier with big things because lack of control is so obvious

**Grief**

- Grief is real and lasts, but is separate from how he deals with other situations
  - Steve thinks about his son Andrew’s death all the time
  - but he never tried to make any sense of it and has not talked about it or reflected on how he processed it

**The education system and mental health**

Importance of including mental health in education

- If we reflect on what children should be taught, “try to teach them the set of skills that will make them happy and able to resolve conflict with other people and to just get along in the world”
  - Knowing oneself and making good choices is more important than whether they can do calculus
  - But 100 years ago the curriculum was designed very differently
  - Goal should be to raise well-adjusted kids who have tools to help them cope with life
  - Adults wouldn’t have to invest in tools later in life if taught much earlier
- Challenges
  - Have to cut something out of curriculum to make time for this
  - No one really knows how to do it well
  - Very difficult to scale
  - Need to try different models to see what works
- Steve talked to Biden transition team about education but they did not respond to his suggestions about incorporating mental health

**Steve’s father and how Steve changed the way he raised his kids**

- Steve has not talked about mental health issues with his dad, but is considering interviewing him for his podcast
  - he thinks it might be easier to ask him questions he otherwise wouldn’t in the context of a podcast
  - has not talked to his father about the deaths of his sister or grandparents
  - do not discuss those things or use the word “love” in his family
  - In contrast, Steve and his kids use the word “love” all the time, which was a self-conscious decision on Steve’s part

## Why people are bad at making decisions [1:26:45]

Peter asks: *What’s the best decision you’ve ever made in your life and what’s the worst decision you’ve ever made in your life?*

- Steve says his worst decisions were inaction rather than things he did, while Peter’s have been bad actions
- Steve thinks one of his best decisions was not caring what people think of him because it frees him of a burden
- Best decisions free you of burdens, even trivial ones
  - Steve says he used to be cheap worrying about every expense, now he refuses to worry about any purchase under a certain amount
    - Liberating to free himself of worry
    - Says he might waste tens of thousands of dollars a year making wrong purchase decisions, but worth it because frees up 10% of his time to do what he likes
  - Don’t worry about getting things exactly right

**Humans and decision making**

- Behavioral economics for the last 40 or 50 years shows how bad humans are at making decisions
  - some of the worst decisions makers are the people who study it
  - [Daniel Kahneman](https://en.wikipedia.org/wiki/Daniel_Kahneman), who studies behavior, has said he’s still bad at making decisions despite his expertise
- Humans can use to tools (economics, psychology) to help them
- Steve has trouble quitting, which is another common problem
- The choices humans made when they were evolving are very different from kinds of choices they must make now
  - humans have not necessarily evolved to make good decisions
  - Like with nutrition: the evolutionary triggers humans get are the wrong ones, so they make bad food choices
  - But humans were facing life and death decisions all the time as they evolved
- People react to trauma and get stuck in trauma mode
  - made sense when facing very serious short-term risks
  - But this is not the best way to handle the chronic and complex issues humans face today

**Learning from evolution**

- Evolutionarily, it was probably fantastic to react to trauma because the kind of challenges we faced when we were evolving were short-term, incredibly intense risks that you needed to marshal everything in your body and your mind to fight
- Now those aren’t typically the kind of risks or challenges we’re facing, and so people end up using the wrong set of tools
- Case study: Aboriginal life in Australia has not significantly changed in about 5,000 years
  - Don’t need much innovation in that situation — if 1% innovation per year, everything is transformed after 5000 years
- The idea of progress, innovation, and doing better than the previous generation is very modern; was not a part of human existence until post-industrial time

## Deliberating on why horse racing times haven’t advance much in decades [1:34:30]

**Horse racing example**

- Steve wrote undergrad thesis on thoroughbred breeding
- Went to see [Secretariat](https://en.wikipedia.org/wiki/Secretariat_(horse)), horse who won the triple crown (Kentucky Derby, Preakness, and Belmont)
  - 3 races that get longer in six weeks
  - won in 1973 and still holds the record for the fastest time in each
  - It’s remarkable how well Secretariat’s record has stood the test of time
  - This begs the question of why?

So why hasn’t it gotten better?

- Steve has spent some time deliberating whether there is a better way to breed horses
  - Currently they just mate the best with best to breed horses
  - But, says Steve, “my hunch is that it’s not particularly well done”
- In contrast to human sports, no obvious advances in training techniques for horses in the last 40 or 50 years
  - Steve says this is probably the best explanation for why horse racing times haven’t improved
  - Steve wants to train an average thoroughbred and see if he can make it excel
  - Horses can’t run all the time due to fragile legs
  - Steve would put them in a pool with a strong current running against the horse to build aerobic capacity and mitochondrial efficiency

**Training knowledge is key**

- It’s the difference between [Roger Bannister](https://en.wikipedia.org/wiki/Roger_Bannister) and today’s collegiate runners
  - Bannister was trying for 4-minute mile
  - That time is now routinely accomplished among top runners
  - “I*n the case of humans we can definitely say that the biggest difference between Roger Bannister and a good collegiate runner today is knowledge of training, much more than equipment or nutrition for sure*,” says Peter
- Another example is that the swimmer ranked 100th today is probably better than the best swimmer in the world 50 years ago in terms of times

Was Secretariat an outlier?

- Secretariat may have had an usually large heart (about twice the size as normal)
- That large heart has been linked to an X chromosome, which may partially explain why Secretariat’s immediate male offspring weren’t that special
- Because his male offspring would have got his Y chromosome, his female would have got the X and only if that X made it into a male two generations later, would that have been a particularly fast horse
- This gets to Steve’s point about the lack of sophistication around breeding

## Reducing the impact of negative emotions by observing the world free of language [1:44:00]

- Concepts from [Sam Harris](https://en.wikipedia.org/wiki/Sam_Harris)’s book [*Waking Up*](https://en.wikipedia.org/wiki/Waking_Up:_A_Guide_to_Spirituality_Without_Religion)
  - Left side of brain controls speech
  - right side can’t express itself through speech
- Speech is central to our lives, including our inner lives
  - Relegates right side to subsidiary role, but what would happen if we could get to know the right side of our brain?
  - Steve tried to observe the world with all his senses but without language (i.e., “free of language”)
  - He was better at it than he thought
  - “I find that it’s very difficult for me to be unhappy or angry without words.  … It’s not that I don’t feel angry, but I feel it very, very differently in the absence of words than with words”

## Changing our thinking about what it means to conduct experiments ethically [1:49:00]

**RCTs in economics**

- The random controlled experiment (RCT), the gold standard of medicine, is virtually never available to economists
  - Our lack of understanding in economics isn’t due to a lack of resources
  - But more data and experiments unlikely to make a big difference in knowledge

**COVID and ethical experimentation**

- We used RCTs to determine that vaccines were effective
  - But we did not do *challenge trials*: give people vaccine, then COVID
  - “I think we were foolish given the stakes not to do that”
- There are too many facts about COVID that we don’t know – six feet distance is just random
- Was a bad idea to tell people masks wouldn’t work at first because frontline workers needed them more

“*The real missed opportunity in COVID was not to take the approach that I think is 100% accepted, which is, the best way we are able to learn, given the constraints of society, about COVID is by doing clever little natural experiments*.”

- Example: Put people on airplanes, some of who have COVID and some don’t, and see who gets it
  - But people think we can’t do experiments like that
    - Peter points out that could people would be willing to take the risk to be the COVID-negative people on the plane if **paid them enough**
    - Might not be traditionally medically ethical, but could say desperate times call for desperate measures
- [Moncef Slaoui](https://en.wikipedia.org/wiki/Moncef_Slaoui), who ran [Operation Warp Speed](https://en.wikipedia.org/wiki/Operation_Warp_Speed), said this type of experiment is not helpful because most people in the airplane example experiment would be healthy and at low risk
  - But Steve counters that instead we could use sick people and offer to take care of their family if something were to happen

> “I know I’m completely out of step with the mainstream medical ethics on this, but I think medical ethics gets it really wrong.” —Steve Levitt

- Ethicists think about **small** amounts of money, which is probably the wrong approach
  - When stakes are high, as with COVID, we could offer people $10,000 or $100,000 instead of $100
  - “*When everyone is volunteering to do it because you’re paying enough money, then … almost every issue of medical ethics fades away when you got a surplus of people volunteering*.”
- Peter says Steve has a point
  - [Institutional review boards](https://en.wikipedia.org/wiki/Institutional_review_board) (IRBs) won’t allow large payments because they’re considered coercive
  - “But the irony of it is it ***is*** coercive if it’s low and it disproportionately targets the most vulnerable”

**Organ donation raises similar ethical issues**

- People are terrified of market for organs, fear would be exploitative because price too low
- Steve thinks a **high price** should be enforced
  - For example, dialysis and associated suffering are [exorbitantly](https://pharm.ucsf.edu/kidney/need/statistics#:~:text=Hemodialysis%20care%20costs%20the%20Medicare,a%20total%20of%20%2428%20billion.) [expensive](https://www.scielo.br/pdf/ramb/v64n12/1806-9282-ramb-64-12-1108.pdf)
  - And the value to society of a healthy, live kidney is a least hundreds of thousands of dollars
  - Could pay $100K for a good kidney and get millions of donors
- With organ donation, medical ethics is turned upside down
  - Steve says no one will take the idea seriously
  - Hopes one country will try it
  - He thinks it would work well and set example for rest of world to follow
  - But no one is willing to try this kind of system

> “And the weird thing is I cannot get anyone to take that scenario seriously, even though to me it seems completely and totally obvious. … I bet it would work great.” —Steve Levitt

§

## Selected Links / Related Material

**Explanation of macro vs. microeconomics**: [Microeconomics vs. Macroeconomics: What’s the Difference?](https://www.investopedia.com/ask/answers/difference-between-microeconomics-and-macroeconomics/#:~:text=Microeconomics%20studies%20individuals%20and%20business,it%20a%20bottom%2Dup%20approach.) | Charles Potters, *Investopedia* | [9:00]

**American Economic Association’s summary of the work for which Steve won the 2003 John Bates Clark medal**: [Steven Levitt, Clark Medalist 2003](https://www.aeaweb.org/about-aea/honors-awards/bates-clark/steven-levitt) | (aeaweb.org) [12:15]

**The three books Steve wrote with Stephen Dubner**:

- [*Freakonomics*](https://en.wikipedia.org/wiki/SuperFreakonomics) by Steven Levitt and Stephen J. Dubner | [53:00, 58:00, 1:02:30]
- [*SuperFreakonomics*](https://en.wikipedia.org/wiki/SuperFreakonomics) by Steven Levitt and Stephen J. Dubner  | [18:45, 1:02:00]
- [*Think Like a Freak*](https://www.amazon.com/Think-Like-Freak-Authors-Freakonomics/dp/0062218344) by Steven Levitt and Stephen J. Dubner | [1:02:00]

***The Atlantic*** **on climate change** [22:15]:

- C*riticizing Steve and Dubner for the climate change section of SuperFreakonomics*:
  - [SuperFreakonomics on Global Warming](https://www.theatlantic.com/culture/archive/2009/10/superfreakonomics-on-global-warming/341861/) | Heather Horn, *The Atlantic*
  - [SuperFreakonomics Author: “Your Job is to Attack Us.”](https://www.theatlantic.com/business/archive/2009/10/superfreakonomics-author-your-job-is-to-attack-us/29163/)  | Derek Thompson, *The Atlantic*
- L*ater discussing the same type of geoengineering solutions Steve and Dubner had mentioned*:
  - [Will Our Grandchildren Say That We Changed the Earth Too Little?](https://www.theatlantic.com/science/archive/2015/11/its-time-to-start-talking-about-geoengineering/414283/)  | Ross Andersen, *The Atlantic*

**1964 Surgeon General’s Report establishing the link between smoking and cancer**: [Smoking and Health](https://profiles.nlm.nih.gov/spotlight/nn/catalog/nlm:nlmuid-101584932X202-doc) by the Office of the US Surgeon General | [25:00]

**Materials on how people assign economic values to risks** [37:45]:

- [The Value of Life](https://www.law.harvard.edu/programs/olin_center/papers/pdf/Viscusi_517.pdf?fbclid=IwAR0LfvKUZ9KvQi_VKs1QDoheQ7TnNHxiwEK11PeXlOOHvbsFlzz1H_7G2D0) (W. Kip Viscusi 2005)
- [The Value of a Statistical Life: Economics and Politics](https://strata.org/pdf/2017/vsl-full-report.pdf?fbclid=IwAR0IQuCa4ur78NEUwhfftFoH0vXIv-i-rKLvBrlrUpnQCIhHJiumKXIpVpE) (Bosworth et al. 2017)

**Overview of the economic thinking associated with UChicago**: [Chicago school of economics](https://en.wikipedia.org/wiki/Chicago_school_of_economics) | (en.wikipedia.org) [47:30]

**Information about Chicago Price Theory** [49:45]:

- [Price Theory Initiative](https://bfi.uchicago.edu/initiative/price-theory/) | *University of Chicago*
- [Chicago Price Theory lecture series](https://www.youtube.com/channel/UC54kFKpGsjpyAgNSce-mR6Q) | (youtube.com)

***NYT*** **profile that Stephen J. Dubner was interviewing Steve for when they first met:** [The Probability That a Real-Estate Agent Is Cheating You (and Other Riddles of Modern Life)](https://www.nytimes.com/2003/08/03/magazine/probability-that-real-estate-agent-cheating-you-other-riddles-modern-life.htmlt%20Is%20Cheating%20You%20(and%20Other%20Riddles%20of%20Modern%20Life)) | Stephen J. Dubner, *New York Times* | [53:00]

**Steve’s conversation with** ***Freakonomics*** **literary agent Suzanne Gluck** **about how she negotiated a lucrative book deal when they still had no idea what the book would be about**: [Suzanne Gluck: “I’m a Person Who Can Convince Other People to Do Things”](https://freakonomics.com/podcast/pima-suzanne-gluck/)  | People I (Mostly) Admire (Ep. 10), Steve Levitt ([freakonomics.com](https://freakonomics.com/)) **|** [55:30]

**Steve’s early (pre-*****Freakonomics)*** **work on abortion and crime that was oversimplified by the media**: [The Impact of Legalized Abortion on Crime](https://pricetheory.uchicago.edu/levitt/Papers/DonohueLevittTheImpactOfLegalized2001.pdf) (John J. Donohue III & Steven D. Levitt 2001) | [58:00]

***Wall Street Journal*****’s positive review of** ***Freakonomics*** **that Steve believes helped the book sell well**: [When Numbers Solve a Mystery](https://www.wsj.com/articles/SB111334626457705169) | Steven E. Landsburg, *Wall Street Journal* [1:09:00]

**Steve’s appearances on** ***The Daily Show*** **to discuss his books** [1:09:00]:

- [*Freakonomics* Part I](https://www.cc.com/video/vra7sa/the-daily-show-with-jon-stewart-steven-levitt-pt-1)
- [*Freakonomics* Part II](https://www.cc.com/video/64us5h/the-daily-show-with-jon-stewart-steven-levitt-pt-2)
- [*SuperFreakonomics*](https://www.cc.com/video/r1izco/the-daily-show-with-jon-stewart-steven-levitt)

**Peter’s guest appearance on Steve’s podcast in which they discuss mental health issues:** [Peter Attia: “I Definitely Lost a Lot of IQ Points That Day”](https://freakonomics.com/podcast/pima-peter-attia/) | People I (Mostly) Admire (Ep. 8), Steve Levitt ([freakonomics.com](https://freakonomics.com/)) **|** [1:10:15]

**Episode of** ***The Drive*** **where Peter interviewed Ric Elias**: [Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/) | The Drive (#79), Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:14:45]

**Information about dialectical behavioral therapy and “radical acceptance”**: [Dialectical behavioral therapy](https://en.wikipedia.org/wiki/Dialectical_behavior_therapy) | (en.wikipedia.org) [1:18:00]

**Sam Harris book that discusses right vs. left (speech) brain**: [Waking Up: A Guide to Spirituality without Religion](https://en.wikipedia.org/wiki/Waking_Up:_A_Guide_to_Spirituality_Without_Religion) by Sam Harris | [1:44:00]

**Materials on the high costs of dialysis and renal disease** [1:55:00]:

- [Global costs attributed to chronic kidney disease: a systematic review](https://www.scielo.br/pdf/ramb/v64n12/1806-9282-ramb-64-12-1108.pdf) (Bezerra da Silva Jr. et al. 2018)
- [The Kidney Project: Statistics](https://pharm.ucsf.edu/kidney/need/statistics#:~:text=Hemodialysis%20care%20costs%20the%20Medicare,a%20total%20of%20%2428%20billion.) | UCSF Department of Bioengineering and Therapeutic Sciences (pharm.ucsf.edu)

§

## People Mentioned

- [Stephen Dubner](https://en.wikipedia.org/wiki/Stephen_J._Dubner) (American journalist who was Steve’s co-author on *Freakonomics, Superfreakonomics*, and *Think Like a Freak*) [18:45, 53:00, 53:45, 1:06:30]
- [Al Gore](https://en.wikipedia.org/wiki/Al_Gore) (Former US Vice President and environmental activist) [30:30]
- [Moncef Slaoui](https://en.wikipedia.org/wiki/Moncef_Slaoui) (Scientist who led Operation Warp Speed to develop a COVID vaccine) [36:15, 1:51:45]
- [Jeff Thomas](https://www.linkedin.com/in/jeff-thomas-66bb098/) (Steve’s colleague at Corporate Decisions Inc. who taught him to think strategically; currently CEO of Westminster Lane Capital) [39:45]
- [Austan Goolsbee](https://en.wikipedia.org/wiki/Austan_Goolsbee) (Economist and professor at UChicago who worked in the Obama administration; former classmate of Steve’s) [39:45]
- [Gary Becker](https://en.wikipedia.org/wiki/Gary_Becker) (Nobel-Prize-winning economist whom Steve calls “one of the most influential economists of the last 50 years;” Steve’s mentor at UChicago) [45:30, 46:45]
- [Milton Friedman](https://en.wikipedia.org/wiki/Milton_Friedman) (Nobel-Prize-winning American economist and major figure in the Chicago school of economics) [49:45]
- [Casey Mulligan](https://en.wikipedia.org/wiki/Casey_B._Mulligan) (Economist and professor at UChicago who worked in the Trump administration) [49:45]
- [Suzanne Gluck](https://wnba-nyc.org/meet-our-panelists-the-intersection-of-literary-and-commercial-fiction/) (Influential literary editor who negotiated *Freakonomics* book deal) [55:30]
- [Larry Summers](https://en.wikipedia.org/wiki/Lawrence_Summers) (American economist who worked for the World Bank, served in both the Clinton and Obama administrations, and was President of Harvard University) [1:04:30]
- [Ric Elias](https://www.redventures.com/about/leadership?modal=ric_elias) (Founder and CEO of Red Ventures, philanthropist) [1:14:30]
- [Daniel Kahneman](https://en.wikipedia.org/wiki/Daniel_Kahneman) (Nobel Prize winning Israeli economist and psychologist who studies behavioral economics) [1:29:45]
- [Roger Bannister](https://en.wikipedia.org/wiki/Roger_Bannister) (British runner who was the first person to run a mile in less than 4 minutes) [1:37:45]
- [Sam Harris](https://en.wikipedia.org/wiki/Sam_Harris) (American philosopher and neuroscientist who wrote *Waking Up*) [1:44:00]

§

![](https://peterattiamd.com/wp-content/uploads/2021/03/1x1-levitt-500x500.jpeg)

##### Steve Levitt, Ph.D.

Steven Levitt is the William B. Ogden Distinguished Service Professor of Economics at the University of Chicago as well as the Director of the Becker Center on Chicago Price Theory.  In addition, he is the founding partner of The Greater Good Group (TGG) consulting firm.  The co-author of the bestselling book *Freakonomics* and its two sequels, he won the John Bates Clark Medal (one of the highest honors in the economics field) in 2003.  In 2006, Steve was named one of Time Magazine’s 100 People Who Shape Our World. He received his undergraduate degree from Harvard and his PhD from MIT.

**Twitter:** [@Freakonomics](https://twitter.com/Freakonomics?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

**Facebook:** [Freakonomics](https://www.facebook.com/watch/freakonomics/)

**Website (including podcast):** [freakonomics.com](https://freakonomics.com/)

**Academic website:** <https://economics.uchicago.edu/directory/steve-levitt>