# #252 ‒ Latest insights on Alzheimer’s disease, cancer, exercise, nutrition, and fasting | Rhonda Patrick, Ph.D.

**Source:** [https://peterattiamd.com/rhondapatrick2/](https://peterattiamd.com/rhondapatrick2/)

---

Rhonda Patrick, Ph.D., is a scientist with expertise in the areas of aging, cancer, and nutrition who translates complex scientific topics into actionable insights on her podcast, Found My Fitness. In this episode, Rhonda provides her latest thinking as it relates to Alzheimer’s disease including the possibility of a vascular hypothesis as well as the factors that can impact disease risk such as type 2 diabetes, blood pressure, omega supplementation, exercise, sauna, and more. She also touches on cancer risk including the relationship between cancer and exercise as well as the link between alcohol consumption and cancer. Additionally, Rhonda explains her new focus on exercise and protein consumption as well as how her perspective has shifted as it pertains to fasting and time-restricted feeding.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/rhondapatrick2/the_Drive_public.png)

Play

#252 ‒ Latest insights on Alzheimer's disease, cancer, exercise, nutrition, and fasting | Rhonda Patrick, Ph.D.

#252 ‒ Latest insights on Alzheimer's disease, cancer, exercise, nutrition, and fasting | Rhonda Patrick, Ph.D.

1x15s30s

0:002:29:31

## We discuss:

- Alzheimer’s disease: Rhonda’s evolved thinking on neurodegenerative diseases [2:30];
- The breakdown of the blood-brain barrier in neurodegenerative disease [8:45];
- An explanation for the observation that type 2 diabetes increases risk of Alzheimer’s disease [15:45];
- The role of omega-3 fatty acids (EPA and DHA) in brain health and prevention of neurodegeneration [19:45];
- Comparing the preventable nature of type 2 diabetes, atherosclerosis, cancer, and dementia [32:15];
- Blood pressure: an important modifiable lifestyle factor that can affect Alzheimer’s disease risk [35:15];
- Rhonda’s outlook on “precision medicine” as it pertains to one’s genetic predispositions [38:45];
- Possible mechanisms by which exercise reduces the risk of Alzheimer’s disease [45:45];
- Building your aerobic pyramid: neurobiological effects of exercise, benefits of lactate peaks, and more [53:45];
- Maximizing mitochondrial biogenesis: alternative training approaches and strategies [58:45];
- Possible brain benefits of sauna, and Rhonda’s personal protocol [1:09:30];
- The relationship between cardiorespiratory fitness and dementia risk [1:15:30];
- How exercise may reduce the risk of cancer [1:20:30];
- The overarching impact of exercise of health, and the importance of focusing the factors that matter most [1:33:15];
- Impact of alcohol consumption on breast cancer risk and overall health [1:37:15];
- Exercise as an intervention for poor sleep habits [1:42:30];
- The longevity benefits of consuming adequate protein and strength training to preserve muscle mass and strength [1:46:30];
- How to get enough of the right kind of protein in your diet [2:05:15];
- Fasting: weighing the risk vs. reward [2:12:15];
- How Rhonda’s views have shifted on diet and exercise [2:15:30];
- How to follow Rhonda’s work and more about the benefits of lactate for the brain [2:21:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- The guest this week is Rhonda Patrick; she was one of the original guests on the pilot series of *The Drive* back in [July 2018](https://peterattiamd.com/rhondapatrick/) when we were trying to figure out if we really wanted to do a podcast
- It is awesome to have Rhonda back
- Rhonda also hosts her own podcast called [*Found My Fitness*](https://www.foundmyfitness.com/episodes)
- In this episode, we focus the conversation around a few important concepts and we talk about Rhonda’s current interests along with areas where her perspective has either shifted or evolved over the years
- We start the conversation with a deep dive into Alzheimer’s disease
  - We talk about the possibility of a vascular hypothesis for Alzheimer’s disease
  - We talk about the different factors that can affect Alzheimer’s disease: type 2 diabetes, omega supplementation, blood pressure, exercise, sauna, and more
- We then go on and talk about the relationship between exercise and cancer and also the relationship between alcohol and cancer
- We end with a discussion about protein and aging, and we talk about fasting, time-restricted feeding
  - These are two areas where Rhonda and Peter have had different points of views over time, and both of their views have evolved to where in some ways they are now converging at about the same place

## Alzheimer’s disease: Rhonda’s evolved thinking on neurodegenerative diseases [2:30]

**How Rhonda’s thinking about Alzheimer’s disease has evolved in the past five years**

- Peter and Rhonda last sat down to do a podcast five years ago, and both have evolved a lot in their thinking since then
  - Peter remarks, “*That’s the nature of science, that’s the nature of what we do and we’re trying to learn*”
- Rhonda has neurodegenerative disease on her mind a lot because [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) and [Parkinson’s disease](https://en.wikipedia.org/wiki/Parkinson%27s_disease) both run in her family and she has a genetic predisposition
- It’s paramount for her to understand everything she can do with diet, with lifestyle, limiting exposure to certain things, etc.,
- The Alzheimer’s disease field has been on quite a rollercoaster with regards to the dominating hypothesis (the [amyloid hypothesis](https://en.wikipedia.org/wiki/Biochemistry_of_Alzheimer%27s_disease#Amyloid_hypothesis))
- The major pathologies of Alzheimer’s disease are:
  - 1 – [Amyloid plaques](https://en.wikipedia.org/wiki/Amyloid_plaques) in the brain
  - 2 – [Tau tangles](https://en.wikipedia.org/wiki/Tauopathy)
  - 3 – [Glucose hypometabolism](https://en.wikipedia.org/wiki/Biochemistry_of_Alzheimer%27s_disease#Glucose_consumption) where glucose uptake into the brain is impaired, and perhaps even the utilization of glucose as well
- These are three major pathologies of Alzheimer’s disease, and it seems as though the majority of science and scientists have decided to target Alzheimer’s disease is through this amyloid/ anti-amyloid hypothesis
- There have been quite a few failed trials, though more recently, possible success

***Generally speaking, are we trying to treat a symptom or are we too far downstream?***

- Rhonda started reading some studies by [Berislav Zlokovic](https://keck.usc.edu/faculty-search/berislav-v-zlokovic/) at USC and [Axel Montagne](https://www.research.ed.ac.uk/en/persons/axel-montagne), who was trained with Dr. Zlokovic and now has his own lab at the University of Edinburgh in Scotland
  - Rhonda recently had [Axel on her podcast](https://www.foundmyfitness.com/episodes/axel-montagne), and when she started reading some of this literature, she gained a new understanding of Alzheimer’s disease

***She began to question the underlying causes of dementia***

**There are three major types of dementia**

- Alzheimer’s disease (the most common), [cerebral small vessel disease](https://pubmed.ncbi.nlm.nih.gov/33768739/), and [vascular dementia](https://en.wikipedia.org/wiki/Vascular_dementia)
  - Is there a common underlying denominator between those?

> “*What sort of lifestyle factors and genetic factors do we know really increase the risk of Alzheimer’s disease and dementia?*”‒ Rhonda Patrick

- We know that people who have the [*APOE-ε4* allele](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms) have a twofold increased risk of Alzheimer’s disease
  - If you have two copies (one from your mom and one from your dad), the risk could be up to tenfold
  - This isn’t early-onset Alzheimer’s; it’s late-onset, the normal, age-related aggression of Alzheimer’s disease
- We also know that 50-80% of people with Alzheimer’s disease have [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes), “*There is definitely something going on.*”

**Preventive neurology is still on the outskirts of this field**

- The premise of Rhonda’s interest is her increased risk of disease
- The NIH doesn’t acknowledge the idea of prevention as a strategy within this field
- Peter notices, “*Most people are thinking about what to do when you have Alzheimer’s disease. Not as many people are thinking about the question that you’re asking and that a few other people are asking, which is what’s in our control?*”

**If you can prevent type 2 diabetes, does this suggest the possibility of preventing or delaying Alzheimer’s disease?**

- Rhonda agrees, this is the question we should be looking at
- Understanding the underlying cause of Alzheimer’s disease opens up new avenues for prevention and treatment
- With respect to *APOE-ε4* and type 2 diabetes, is there something common going on here that we can understand as a foundation to what are the initial things going wrong to lead to Alzheimer’s disease?
  - Is where vascular dysfunction fits in?

***Dysfunction in the blood vessels and capillaries that line the blood-brain barrier seem to be a really, really early event that is common between all types of dementia and between type 2 diabetes and APOE-ε4***

## The breakdown of the blood-brain barrier in neurodegenerative disease [8:45]

**What is the blood-brain barrier (BBB)?**

- Rhonda is not a neuroscientist, but she is a scientist and has done a lot of reading in this field
- There are a combination of different cell types that make up the [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier) and a lot of vasculature
- Blood flow brings things to the BBB and oxygen, glucose, other nutrients are transported across the BBB
- But, as the word barrier implies, the BBB provides a barrier to things that you don’t want to get into your brain
  - We don’t want red blood cells getting into our brain
  - We don’t want a variety of other molecules, proteins that are floating around in our circulation to get into our brain

**When the blood-brain barrier begins to break down**

- People are a lot more familiar with when the gut barrier starts to break down; it has become a common theme that people are focused on gut health
  - You hear the word “leaky gut,” (a term Rhonda doesn’t like) and this refers to [intestinal permeability](https://en.wikipedia.org/wiki/Intestinal_permeability)
  - The [tight junctions](https://en.wikipedia.org/wiki/Tight_junction)/ proteins holding endothelial cells together in the gut open up
- In the brain you also have endothelial cells and tight junctions, and when those tight junctions also break apart, that leads to permeability of the blood-brain barrier; two things happen:
- 1 – It allows things from circulation to get in the brain, which wreaks havoc on the brain and leads this vicious cycle of neuroinflammation (inflammation in the brain)
- 2 – It disrupts the transport of important nutrients, oxygen, glucose to the brain
  - Blood flow is disrupted to the brain

**Maintaining the integrity of the BBB is very important, and both** ***APOE-ε4*** **and type 2 diabetes lead to its permeability**

- People with type 2 diabetes have elevated blood glucose levels, and over time that leads to [advanced glycation end-products](https://en.wikipedia.org/wiki/Advanced_glycation_end-product)
  - Sugars cross-link proteins and a variety of other things in the vasculature, and that damages the BBB and leads to permeability (other mechanisms happen too)
- You can measure the permeability of the BBB by looking at a variety of [biomarkers](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6338083/) and proteins in the cerebral spinal fluid and also in the plasma
- Dr. Zlokovic and Dr. Montagne have shown these changes occur decades before the onset of cognitive impairment
- You can find impairment of the BBB in more than 50% of all dementias ([2018 Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5829048/))
  - It’s happening independent of amyloid accumulation and tau tangles
- The BBB is essential for removing toxic compounds from the brain and a variety of different processes happen to allow this to occur
  - You activate the [glymphatic system](https://en.wikipedia.org/wiki/Glymphatic_system) during sleep; your brain swells during sleep and the glymphatic system pushes the cerebral spinal fluid through the brain, clearing out debris, amyloid plaques, things like that
  - It makes sense that BBB permeability would allow the accumulation of amyloid
- Peter had never thought of this, “*If your blood-brain barrier can’t hold the back pressure, which is what would be the case if it were permeable, you would not have the back pressure to maintain the glymphatic flow*”
  - This is a very interesting mechanistic tie to that problem
- Rhonda is not familiar with all the ways stuff is cleaned out of the brain (the [parenchyma](https://en.wikipedia.org/wiki/Parenchyma#Brain) is involved), but all of those things are not working as good when the BBB is dysfunctional
- Peter adds another point about BBB permeability, “*The ability of things to interrupt and get into the brain that shouldn’t*”
  - One of the things everybody learns in pharmacology (or medical school) is that there are certain drugs that cannot penetrate the BBB
    - The implication being that certain molecules can pass through while others cannot
  - Presumably, the leakier that barrier is, the more that things we evolved to not allow into the brain can get across
  - Perhaps this increase in inflammation is coupled with a decreased ability to clear out debris

**Problems with a leaky BBB**

- [Work](https://headachejournal.onlinelibrary.wiley.com/doi/10.1111/head.14088) from [Dr. Montagne](https://www.research.ed.ac.uk/en/persons/axel-montagne) has shown that [fibrinogen](https://en.wikipedia.org/wiki/Fibrinogen) in the brain of people with a leaky BBB
  - If you do an inflammatory biomarker panel, [fibrogen](https://en.wikipedia.org/wiki/Fibrinogen#Laboratory_tests) is a marker of inflammation; it’s also a protein involved in blood coagulation
  - Fibrinogen is not supposed to be in the brain
  - Fibrinogen is toxic to a cell type in the brain called [oligodendrocytes](https://en.wikipedia.org/wiki/Oligodendrocyte) ‒ they make myelin, a fatty, white structure that’s important for electric signals being fired throughout the brain
- Lesions in the white matter of the brain ([white matter hyperintensities](https://en.wikipedia.org/wiki/Hyperintensity)) are very common in small vessel disease, and you can see that in people with Alzheimer’s

**The BBB prevents stuff from getting into your brain that you don’t want in there, but it is also important for transport**

- Transporters are on endothelial cells that make up the BBB, and when you start to disrupt the BBB, those transporters become dysfunctional
- When you have permeability of the BBB things like glucose are not getting into the brain
  - The [GLUT1 transporter](https://en.wikipedia.org/wiki/GLUT1) that transports glucose is dysfunctional, the number of transporters go down
  - Now you’re talking about not getting enough glucose into the brain which is one of the pathological features of Alzheimer’s disease

## An explanation for the observation that type 2 diabetes increases risk of Alzheimer’s disease [15:45]

**Less glucose gets into the brain when the BBB is disrupted**

- Peter points out a subtle point Rhonda made, she mentioned the [GLUT1 transporter](https://en.wikipedia.org/wiki/GLUT1) as opposed to the [GLUT4 transporter](https://en.wikipedia.org/wiki/GLUT4), and GLUT1 is insulin-independent
- This seems a bit counterintuitive that a condition that leads to insulin resistance (type 2 diabetes) would produce a hypometabolic state in an organ whose glucose transporters are *insulin independent*
  - The problem is *not* insulin resistance of the GLUT1 transporter (as it is for the GLUT4 transporter in muscle)

***Instead it’s the mechanical disruption of the GLUT1 transporter because it is presumably no longer held in place by the barrier that allows glucose to get across it (across the BBB and into the brain)***

- Rhonda adds, “*This isn’t dogma; this is definitely known*”

**It’s time to explore the term “**[**type 3 diabetes**](https://en.wikipedia.org/wiki/Type_3_diabetes)**” and how people think about the brain being insulin resistant**

- Type 2 diabetes is disrupting the BBB through a variety of mechanisms, including the advanced glycation end-products

- Vasculature disruption in type 2 diabetes is well known
  - This includes tiny, tiny blood vessels that are smaller in size than the diameter of a hair
  - This is disrupted at the BBB resulting in a decrease of blood flow and transporters
- Fixing the diabetes would be the downstream thing to do, but it’s a new mechanism, a new way of understanding it

**There is an observation that type 2 diabetes doubles your risk of Alzheimer’s disease**

- So if you have two copies of the *APOE-ε3* allele, having type 2 diabetes means you might as well have a copy of the *APOE-ε4* allele, from a risk perspective
- It’s not clear why type 2 diabetes would impact the brain through the lens of  traditional thinking of GLUT4 transporters (which are insulin dependent)
  - It isn’t just an insulin resistance problem
- Peter realizes, “*I think these two other things matter, what you said about the microvasculature*”
  - People don’t realize how destructive type 2 diabetes is to the kidneys
  - People are familiar with amputations that occur in the digits because of those tiny, tiny blood vessels
  - 1 – So there is this vascular path and changes in small blood vessels.
  - 2 – It’s also this disruption of glucose transport directly across that transporter (GLUT1)
  - This is a very compelling thesis for how type 2 diabetes could be acting via those two prongs to ultimately result in hypometabolism in the brain
- Then there is the cascade of inflammation that happens after that
- Talking about type 2 diabetes has very big implications for the prevention of Alzheimer’s disease
  - There is a lot you can do to prevent and treat type 2 diabetes with diet and lifestyle changes

## The role of omega-3 fatty acids (EPA and DHA) in brain health and prevention of neurodegeneration [19:45]

**The role of the omega-3 DHA transporter MFSD2A in the brain**

- Rhonda was on this trail years ago and published an [integrative review](https://faseb.onlinelibrary.wiley.com/doi/full/10.1096/fj.201801412R) on the role of the [omega-3 DHA](https://en.wikipedia.org/wiki/Omega-3_fatty_acid) transporter in the brain, [MFSD2A](https://en.wikipedia.org/wiki/MFSD2)
- In [animal studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4134871/), when this transporter is disrupted, it causes 50% breakdown of the BBB and >50% loss of omega-3 in the brain
- There is [human evidence](https://www.mdpi.com/1422-0067/21/1/70) that MFSD2A transporters decrease with age
  - This happens rapidly in Alzheimer’s disease and with *APOE-ε4*
- There are genetic abnormalities and mutations that occur in MFSD2A transporters where people have lower levels and they have microcephaly (smaller heads) and cognitive dysfunction

***This suggests that APOE-ε4 carriers need a higher level of EPA and DHA***

- It’s as if aging itself could create some resistance to dietary [EPA](https://en.wikipedia.org/wiki/Eicosapentaenoic_acid) and [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid) so that more is required as time goes on
  - Similar to amino acid/ protein resistance (anabolic resistance) as a person ages, whereby they need more and more protein to get the same effect

**Do you think there are genetic differences within the “normal/ non-pathological” person where they would need more EPA and DHA to afford them the same benefit of protection as another person?**

- Yes, and at least a couple examples are known
- Some people have certain gene variants where they respond better to omega-3 supplementation, while other people would need a higher dose
- This is an area that needs to be explored by the scientific community

***Omega-3 really hits home the preventative role that we can have in our Alzheimer’s disease risk***

**MFSD2A transporters and pericytes are lost**

- There is a type of cell called a [pericyte](https://en.wikipedia.org/wiki/Pericyte) (not to be confused with parasite), and they serve two very important roles
- Pericytes have these big feet that wrap around the endothelial cells at the BBB (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/04/f1-rhondapatrick2-1024x435.jpg)

**Figure 1. Cell types associated with the blood-brain barrier**. Image credit: [*Nature Cardiovascular Research* 2022](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9017393/)

- 1 – Pericytes regulate the flow of blood to the brain by constricting/ helping to squeeze the flow of blood and dilating
- 2 – They are also important for the BBB
- Pericytes start to fall off with age, and inflammation plays a big role in that
- 3 – MFSD2A transporters are concentrated on pericytes

***You’ll see hotspots where the pericytes start to fall of, and that is when immune cells and everything starts going into the brain***

- This is the start of a viscous inflammation cycle in the brain of the leakage, amyloid accumulation
- There’s something there with those transporters of omega-3 that are right at the same site of where you lose those pericytes, which is also really interesting
- A lot of [animal evidence](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4134871/) that suggests the role of that transporter in BBB integrity

**The role of omega-3 in the integrity of the blood brain barrier**

- Rhonda joined the [Fatty Acid Research Institute](https://www.faresinst.org/about.html) (founded by [Dr. Bill Harris](https://www.faresinst.org/our-team.html)) as a research associate
  - They secured a small grant to look at the role of omega-3 with BBB integrity and biomarkers in a variety of people that have small vessel disease that perhaps go on to get Alzheimer’s disease

***More research in this area is needed because the implication are really important***

**Lifestyle interventions**

- 1 – Fixing type 2 diabetes
- 2 – Addressing omega-3 intake
  - Most people in the US are not eating enough fatty fish and are not supplementing with omega-3 (the marine type of omega-3, not the plant AOA)

***Low omega-3 intake from fish is one of the top six preventable causes of death, after smoking, blood pressure, obesity, and being sedentary***

- Around 84,000 deaths per year can be [attributed](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1000058) to low omega-3 intake from fish

![](https://peterattiamd.com/wp-content/uploads/2023/04/f2-rhondapatrick2-1024x545.png)

**Figure 2. Deaths attributable to effects of risk factors by disease**. Image credit: [*PLOS Medicine* 2009](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1000058)

- Peter wonders if low omega-3 intake from fish is a marker for poor health
- With smoking, the causality is pretty obvious, as with blood pressure
- But you can argue that never has there been a person who has a high omega-3 index who eats junk food and fast food all day (those can’t coexist)

**Is the transporter (MFSD2A) only for DHA and its phospholipid form? If so, what is the importance of EPA in this?**

- The MFSD2A transport Rhonda has been referring to is specific to [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid), specifically lysophosphatidylcholine DHA
- We make lysophosphatidylcholine DHA when we take in DHA from fish or a supplement; we add the lysophosphatidylcholine group to the DHA
- We also have DHA in free fatty acid form bound to albumin
  - Albumin doesn’t get into the brain, but it take it to the BBB where the free fatty acid can diffuse passively across the BBB
  - [EPA](https://en.wikipedia.org/wiki/Eicosapentaenoic_acid) is also bound by albumin and can diffuse into the brain at the BBB

**So because of the phospholipids on the DHA, it needs a dedicated transporter, whereas the unphosphorylated form doesn’t need a transporter?**

- Exactly

**What do you see as the relative importance of DHA and EPA?**

- The conventional thinking is that [EPA](https://en.wikipedia.org/wiki/Eicosapentaenoic_acid) is more important in the heart and [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid) in the brain, but that’s probably a gross oversimplification
- Rhonda doesn’t know if this is really known
- There are a variety of metabolites of DHA that are involved in **resolving inflammation**: [resolvins](https://en.wikipedia.org/wiki/Resolvin), the [maresins](https://en.wikipedia.org/wiki/Maresin), the [SPMs](https://en.wikipedia.org/wiki/Specialized_pro-resolving_mediators), [protectins](https://en.wikipedia.org/wiki/Protectin_D1)
  - EPA also has some of those metabolites as well
  - They play a direct role in inflammation through dampening [prostaglandins](https://en.wikipedia.org/wiki/Prostaglandin), [leukotrienes](https://en.wikipedia.org/wiki/Leukotriene), and other inflammatory processes
  - It’s a multipronged approach affecting inflammation in multiple ways
- [Fibrinogen](https://en.wikipedia.org/wiki/Fibrinogen) is measured as a marker of inflammation; it’s an inflammatory protein and is involved in coagulation
- [Studies](https://www.sciencedirect.com/science/article/pii/S0735109719338033?via%3Dihub) show that fibrinogen goes up in people exposed to particulate air matter, but if they have a higher intake of omega-3, it blunts that affect through modulating inflammation
- In Rhonda’s mind, both DHA and EPA are important for the brain
- Some [studies [in mice]](https://pubmed.ncbi.nlm.nih.gov/34219360/) have looked at depression
- You can induce expressive symptoms in a person by injecting them with [lipopolysaccharide (LPS or endotoxin),](https://en.wikipedia.org/wiki/Lipopolysaccharide) which is a component of the outer cell membrane of gram-negative bacteria
  - We have billions of those in our gut, where there’s about 1 gram of LPS
  - If you inject a person with LPS with a dose equivalent to someone with intestinal permeability, it causes depressive symptoms and you can blunt those symptoms with EPA (probably because of the blunting of the inflammatory response)
- This is a field that is understudied and underfunded, but there is some preliminary evidence, [small randomized controlled trials](https://pubmed.ncbi.nlm.nih.gov/36005883/) that show supplementation with EPA can help with depression
- Peter finds this frustrating ‒ if you took the cost of just one of the Phase III anti-amyloid failed drug trial (there’s been dozens of them) and put that money into a preventive trial that looks at something with real feasibility (like optimal supplementation of DHA in the right patient population), we might have an answer
  - But there’s not a financial incentive to study these other things
- This is particularly problematic for a disease like Alzheimer’s disease unlike cardiovascular disease (CVD) where prevention is still the best strategy
  - You can come in late in the game and still make a difference for CVD but that’s not true for Alzheimer’s disease
- Rhonda agrees, “*It’s hard to fix those leaks in the brain once they’re started*”
  - This is why there have been failed trials with omega-3 supplementation, you’re giving people who already have Alzheimer’s disease 500 mg-2 g at the most
    - Peter gives patients with high triglycerides or cardiovascular problems 4 grams
- Rhonda adds, “***At least four [grams]. This [omega-3] is something that has the safety of a nutrient, but literally acts like a pharmacological drug, at higher doses.***”

## Comparing the preventable nature of type 2 diabetes, atherosclerosis, cancer, and dementia [32:15]

**What happens after leaks occur in the brain?**

- When you get to the level of amyloid accumulation, it’s going to be challenging to fix
- It’s not just fixing the amyloid, multiple angles need to be addressed in order to get some improvement
- Peter thinks that fixing the amyloid and BBB leaks, maybe at the same time with a cocktail may help a little bit

> “*Prevention is the way to go… It’s so much better to not get Alzheimer’s disease, than to try to fix it once you have it because it is a very, very complicated disease with lots of things going on*.”‒ Peter Attia

- Peter talks a lot about **type 2 diabetes** ‒ there’s no reason someone should have it
- He does not believe that type 2 diabetes is inevitable to our species whereas, he does believe **atherosclerosis** is inevitable (but most people don’t need to die from it)
  - This is a start contradiction
  - Atherosclerosis is inevitable, “*In as much as humans will have lipoproteins that carry ApoB, we will get atherosclerosis. But again, we have the technology to delay the onset of that disease, to the point where it should not be the cause of death. We should be dying with it, but not from it.*”
- He would also argue that **cancer** is inevitable to our species
  - It is simply a stochastic problem where, if you live long enough and if you accumulate enough genetic mutations
  - We can do lots of things to reduce the risk of and delay the onset of cancer
  - We can detect cancer early and be more successful in treating it
  - But the incidence of cancer seems inevitable with enough age
- He doesn’t feel this way about type 2 diabetes ‒ we don’t have to eventually get it
  - This makes it much more tragic to watch how many people are suffering from this disease
  - How it is such an amplifier of what Peter calls the horsemen, “I*t’s what it does to your risk of cardiovascular disease, cancer, and Alzheimer’s disease is actually why the death toll for Type 2 diabetes is so grossly underappreciated*”
- Rhonda agrees, it accelerates the aging process

> “*It’s gasoline on the fire of aging… I can’t think of a process that accelerates aging more than Type 2 diabetes*”‒ Peter Attia

- The good news is we know what it takes to prevent and treat type 2 diabetes
  - Not that it’s easy
  - But it doesn’t look like the strategies are being deployed

## Blood pressure: an important modifiable lifestyle factor that can affect Alzheimer’s disease risk [35:15]

**Hypertension and hyperlipidemia post an enormous risk for both cardiovascular disease and Alzheimer’s disease. Do either of those act specifically through the BBB?**

- Blood pressure is another really important modifiable lifestyle risk factor that can affect Alzheimer’s disease
- You want to keep your systolic below 130
  - The [SPRINT trial](https://www.nejm.org/doi/10.1056/NEJMoa1511939) would say 120
- Getting blood flow to the brain and the BBB is so important; when blood isn’t able to get to the BBB well enough, those tiny little vessels start to fall off
  - This is one of the reasons why exercise is so important
- Even though observational data is never able to establish causation, it’s still interesting to look at in combination with other types of data

**The epidemiology around exercise and blood pressure is different from the epidemiology around nutrition**

- The epidemiology around nutrition has very low hazard ratios, and it’s always changing the direction it’s moving in (suggesting that whatever’s being studied probably doesn’t matter)
- Yet, the epidemiology of smoking, blood pressure, dyslipidemia, and exercise has much bigger hazard ratios and is virtually always pointing in the same direction (suggesting that it is more likely to be a signal)
- The stats on hypertension are crazy
  - 50% of adults in the US, have hypertension
  - About 20% of young adults (age 18 to 39) have hypertension
- High blood pressure is associated with dementia risk, particularly when you get it before the 50s or midlife
  - Once you start to get high blood pressure in older age (age 70, 80), it’s not as much associated with the Alzheimer’s disease and dementia risk
  - It really does seem like cumulative exposure is the key factor there
- High blood pressure is a lifestyle factor that’s easily modifiable

***The two low-hanging fruits of lifestyle interventions to improve blood pressure are exercise and sauna***

- Some people do have gene polymorphisms, where they’re very sensitive to salt intake and sodium intake; for them higher sodium intake really seems to skyrocket blood pressure
- In nutrition studies it’s important to look at the combination of genes and diet
  - Most nutrition studies don’t do that
  - There is an interaction going on, and that’s why some of the sodium intake blood pressure literature is all over the place

## Rhonda’s outlook on “precision medicine” as it pertains to one’s genetic predispositions [38:45]

**How optimistic are you that in the next decade we will have more of a sense around what precision nutrition looks like, as it pertains to genes and polymorphisms of them?**

- People talk about, “*I did this test, and it told me I should be eating this, that, and the other thing,*” but there is nothing available today that comes close to offering that type of insight
- Rhonda does think in 10 years we are going to know a lot more about precision nutrition
  - Precision medicine as well, because there’s also an interaction between pharmacological treatments and genes

> “*This is always the problem… the incentive for funding to study those things that aren’t necessarily going to be super profitable*”‒ Rhonda Patrick

- The NIH will provide a certain amount of funding, often to study one sort of thing
  - In nutrition, where there’s multiple things involved, it’s just too complicated for NIH funding
- There is a lot of funding from the pharma industry
  - They are incentivized when there is a drug
  - But diet-gene interaction is more on nutrition
- This is a growing field of research, and technology is advancing, so Rhonda is optimistic that in 10 years it’s going to be a lot easier to delineate what a person should eat based on their genetic makeup (versus what we generally think is healthy)

**Do you think that will be at the level of macronutrients or micronutrients? How much heterogeneity do you think there is among people, as it pertains to factors like that?**

- She thinks both
- There are differences in the response to macronutrient intake and the response to micronutrient intake
- And there are people, there’s vitamin D polymorphisms
- Some people have to supplement with high doses of omega-3 to be able to convert… we don’t know the cause
- Other micronutrients of concern are: selenium, magnesium, B vitamins

**Differences between drugs and micronutrients, and important considerations for nutrition studies**

- Generally, when you give someone a drug, and they’re starting with zero levels of that drug in their body, when you give them a dose, it’s clear that your giving it to them (they’re different from people getting a placebo
  - It’s going from zero to something
- Whereas, when you do this nutrition study with a micronutrient (you give a vitamin or mineral), nobody is starting with zero
  - Your placebo group could have high levels of that micronutrient, and unless you measure it, you’ll never know
  - All of these trials are trying to mimic the gold standard of a randomized controlled trial with a pharmacological drug
  - You have to put in so much more effort with nutrition
    - With the drug, you don’t have to start doing blood samples of this and that and measure the drug and make sure people aren’t deficient in that drug

**Two examples to highlight why this is important**

- If you look at how a blood pressure trial is done, it’s titrated
  - It’s done in a way that a pharma trial is not normally done
  - They bring in a whole bunch of people with high blood pressure and one group gets a placebo (or low treatment management to a blood pressure of 140-90) while the other group gets the treatment (and management to 120/80 or better)
  - The outcome is managed, not the drug; it’s agnostic to whether the person needs a higher dose or a lesser dose
- If you did a vitamin D trial that way, it would be a very different trial
  - This is one of Peter’s biggest criticisms of vitamin D trials and why we don’t have an answer as to whether supplemental vitamin D is valuable
  - Instead they take people and divide them into groups: placebo and a low dose of vitamin D (2-4,000 IU daily)
    - You don’t know what the level of vitamin D actually goes to
  - A better vitamin D trial would take a bunch of people whose vitamin D is <30 and give one group a placebo and the other group whatever it takes to raise their levels to 80 (hypothetical number)

***This is something that listeners need to be aware of when they’re scrutinizing trials of this nature ‒ a negative trial doesn’t mean the thing doesn’t work if the trial wasn’t designed correctly***

- This is often a matter of money because it’s cheaper to just give someone the vitamin D supplement and look at the outcome than to measure all those things
- The other confusing piece of the literature is that people say, “*vitamin D supplements do nothing*”

## Possible mechanisms by which exercise reduces the risk of Alzheimer’s disease [45:45]

**What do you think the mechanisms are by which exercise reduces the risk of Alzheimer’s disease?**

- Peter notes, “*The evidence is overwhelming that a person who exercises, especially at the right amount, we’re talking not just 30 minutes a week-type thing, but if you’re really doing the work, you’re having a greater impact on the reduction of risk of Alzheimer’s disease than any other intervention you can take*”
- There are lots of interventions that matter: sleep, nutrition, type 2 diabetes
- But the risk reduction that comes from exercise is enormous
- Rhonda is very focused on neurodegenerative disease and specifically designs her workout routine based off what she thinks is going to give her the biggest brain benefits

> “*I’ve come to the conclusion of is that intensity does make a difference, with respect to the neurobiological effects*”‒ Rhonda Patrick

- The health recommendation is 150-300 minutes per week of moderate-intensity exercise, defined as 50-70% of maximum heart rate
  - Or 75 minutes per week of vigorous intensity exercise (75-85% max heart rate)
- Rhonda like to go to higher intensity
- She asks Peter, “*How do you measure your estimated [maximum] heart rate?*”
- Peter points out, “*The more fit you are, you could be doing a more vigorous-intensity exercise, but your heart rate doesn’t go as high as someone who’s not fit*”
- Rhonda is very interested in [lactate](https://en.wikipedia.org/wiki/Lactic_acid#Exercise_and_lactate); she wants to get her lactate levels high for neurobiological benefits
- Lactate was once thought to be a metabolic byproduct that was harmful to performance, that was causing muscle soreness
  - Now we know it’s not lactate; it’s the proton build-up
  - Lactate is in homeostasis with lactic acid, and neither of them are responsible for muscle soreness (it’s the microtrauma)
  - The soreness and the burn from the hydrogen ion is gone minutes after you stop exercising
- You’re generating lactate when you’re basically are pushing your [mitochondria](https://en.wikipedia.org/wiki/Mitochondrion) inside your muscle cells to a point beyond where they can generate enough energy in the form of [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate)
  - This is where [glycolysis](https://en.wikipedia.org/wiki/Glycolysis) comes into play; it’s happening outside the mitochondria
  - Lactate is generated from metabolism of glucose outside of the mitochondria [in the cytoplasm] when you reach that threshold of pushing your muscle cells harder than the mitochondria can keep up with producing enough energy
- Studies from the 70s showed that lactate gets into circulation and is used by other organs as an energy source (fuel) ‒ the brain especially
  - [Dr. George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) was one of the first to propose this [lactate shuttle theory](https://en.wikipedia.org/wiki/Lactate_shuttle_hypothesis)
- In the brain, lactate is both consumed as a fuel and acts as a signaling molecule
- As lactate increases at the BBB, it is responsible for the production of [VEGF (vascular endothelial growth factor)](https://en.wikipedia.org/wiki/Vascular_endothelial_growth_factor), and this stimulates the growth of new blood vessels and repair of damaged ones
  - It also increases [BDNF (brain-derived neurotrophic factor)](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor) at the BBB and in the brain

**Where is BDNF produced?**

- Many places
- It’s produced in capillaries in the vascular system, in the heart, in muscle, in the brain
- There is some evidence that the shear force of blood flow on endothelial cells lining the blood vessels is a signal to increase BDNF
  - So the more vigorous you are exercising, the more your heart is pumping and your blood is moving faster
  - It also increases BDNF in the muscle, which plays a role in repairing damaged muscle
- BDNF can cross the BBB (there is a little controversy about this), and it is also produced in the brain
- BDNF is important for [long-term potentiation](https://en.wikipedia.org/wiki/Long-term_potentiation) and [neuroplasticity](https://en.wikipedia.org/wiki/Neuroplasticity)
  - Long-term potentiation is basically strengthening the connections of the synapses that are connecting neurons; it’s involved in long-term memory retention
  - Neuroplasticity is your brain’s ability to reshape and restructure with the changing environment
    - This is also something that decreases with age
- Rhonda is now training for higher lactate, and based off Peter’s recommendation, she got a lactate meter from [Nova](https://www.novabiomedical.com/lactate-plus/)

## Building your aerobic pyramid: neurobiological effects of exercise, benefits of lactate peaks, and more [53:45]

**Training to increase mitochondrial capacity**

- Peter notes, “*What we want to do is increase our mitochondrial capacity to maximize aerobic metabolism, and there are two ways to do that.*”
- Your aerobic capacity is a pyramid, and the area of that pyramid is your total aerobic capacity
- To have the largest area of a pyramid, you need the widest base and the highest peak
  - A pyramid with a narrow base and a high peak, not as good
  - A pyramid with a very wide base and a shallow peak, also not great
- The base is your **zone 2 threshold**; this is how much work you can do while keeping lactate at that threshold that [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) and [Iñigo San Millán](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) talk about (2 mmol, discussed in [this previous podcast](https://peterattiamd.com/inigosanmillan2/))

**What differentiates the best aerobic athletes from someone with type 2 diabetes (opposite ends of the spectrum)?**

- It’s a four-fold difference in watts-per-kilo output
- In type 2 diabetes there is real mitochondrial dysfunction
- You have to train to get to a high level
- Peter adds, “*You have to get to that threshold and train right there*.”
- This morning he did a zone 2 ride and was riding right at a lactate level of 1.9 mmol
- You have to do pyramid-building
- To build the peak of that pyramid, you do **VO****2** **max sets**
  - ***Generally, the sweet spot for building those is 3-8 minutes of all-out effort***
    - So what you can do for 3 minutes (and no more) is harder than what you might be able to do for 8 minutes (and no more)
  - Peter’s favorites are 4 minutes
- On Sunday, Peter did an hour of zone 2 (2 mmol lactate), and then did 4-minute awful repeats
  - He worked at much higher power for 4 minutes then rested for 4 minutes (then repeated it)
  - At the end of those 4-minute blocks, his lactate was at 15-16
  - But after a 4-minute rest, his lactate might be down to 6-7
  - Then he repeats the set again and again

**Peter’s summary ‒ “*****You want to build that pyramid to be as wide and as tall as possible. What I don’t think I appreciated, though, was that the brain is getting a benefit from those lactate peaks.*****”**

- An amazing athlete would clear lactate even more quickly; they’d go from 10 mmol to 2 mmol in minutes
- Rhonda notes that she’s back at her 0.9 mmol baseline 20 minutes later

**Brain benefits of lactate**

- Lactate also is important for neurotransmitter synthesis (in humans and animals)
  - You’re making [glutamate](https://en.wikipedia.org/wiki/Glutamic_acid), the major excitatory neurotransmitter in the brain
  - It’s important for making precursors to that, [norepinephrine](https://en.wikipedia.org/wiki/Norepinephrine)
- Rhonda does a lot of [Tabata training](https://en.wikipedia.org/wiki/High-intensity_interval_training#Tabata_regimen)
  - That’s even more intense because you’re only doing 20 seconds on and 10 seconds off
  - She does 16 of those on a Peloton, and her Apple watch beams her estimated heart rate and zones onto her screen
    - She does 8 separated by a 30-second break, and then she does another 8
    - It’s a total of about 10 minutes
    - In the first minute, she’s in zone 2; by then end of that minute, she’s in zone 3; and then she goes into zone 4
  - She does this 5 days a week

> “*I’m trying to maximize the neurobiological effects for me with exercise, and I find pretty compelling evidence that intensity is really important for the brain*.”‒ Rhonda Patrick

- There is benefit for lower intensity exercise
  - Doing a moderate intensity, putting more time in (the volume of training) will likely reach some equivalent
- Lactate is a consequence of intensity, and that’s what she is trying to maximize for
  - Lactate is transient, it’s cleared quickly
  - Rhonda wants a lot of it each day, she wants to keep doing it

## Maximizing mitochondrial biogenesis: alternative training approaches and strategies [58:45]

**Other ways to train**

- Peter suggests doing Tabata two days a week, then do a longer, slower cardio in zone 2
- Zone 2 is not trivial; Peter’s heart rate is still around 140 during his zone 2 workout
- Peter suggests using [blood flow restriction](https://en.wikipedia.org/wiki/Blood_flow_restriction_training) when lifting weights on other days, “*That will get your lactate through the roof*”
  - He discussed blood flow restriction on a [previous podcast](https://peterattiamd.com/jeremyloenneke/)
- Four days a week, Peter does blood flow restriction at the end of the workout
  - Two days will be upper body and two days will be lower body
  - He will use blood flow restriction cuffs on the upper part of the thighs and do leg presses, leg extension, leg curl, and finish up on an AirBike
  - By the time you take those cuffs off, the lactate has been pool in in your legs for 10 minutes and it will flush through systemically
    - Your systemic lactate level surges
    - It’s not as  high as he would get with an all-out sprint, but he will hit the mid-teens
    - His highest lactate was about 18-19 mmol

**An anecdote about an athlete who could reach very high levels of lactate**

- Peter used to coach an Olympic swimmer, and this swimmer could get to 26 mmol of lactate and still be conscious
- He said half jokingly, “*Not that too much lactate would render you unconscious, but the pain that you must be in when your lactate is 26 is comical to me*”
- This athlete would finish a 400 individual medley with a lactate of 24-26 mmol, and four minutes later, jump in the pool (with a lactate level of maybe 6 mmol) and do another race
  - The 400 individual medley is probably the highest lactate-generating race because it’s all out upper body, lower body assault

***Peter’s point is that Rhonda could diversify her training a bit ‒ she could still get that lactate hit, and it’s hard to make performance gains if you’re doing an all-out Tabata five days a week***

- It’s hard to make gains within the Tabata itself, to make gains on the power output your generating
  - Those are “match-burning workouts,” you’re burning all the matches that day

**Rhonda asks, “*****Have you ever tried doing an aerobic or high intensity workout with mouth tape where you’re just breathing through your nose?*****”**

- Peter notes, “*I can’t do my all-out best without mouth breathing at the end. Once I reach 215 to 220 watts, I can’t sustain… I need to start breathing through my mouth.* “
- Rhonda recently started this this and it was odd because she PR’d the first time and she wasn’t going as hard on her all-outs
  - She thinks she was going harder on her 10-second rests; she was not really bringing the resistance down

**Peter asks, “*****Have you tried doing it where you do nothing on the off, a pure off?*****”**

- So 20 seconds all-out, then 10 seconds not spinning at all
- She’s never tried that
- The goal is to make the hard as hard as possible and being truly off for 10 seconds will make it more likely you can deliver the maximum wattage during the 20 seconds
- She has been trying to do the opposite ‒ keep in zone 3 when she’s off
- Peter thinks this is good too
- He used to call that “sweet spot” workouts where you would go: zone 3, zone 5, zone 3, zone 5, 3, 5
- For Tabata you probably want to be doing: zone 6, zone 1, 6, 1, 6, 1
  - Zone 6 is maximal
  - The literature suggests we are only able to hold full maximal effort for 10 seconds, for anything longer, we’re applying some governor to the system
  - So even at 20 seconds, you don’t realize it, but you’re somewhat pacing yourself
- Rhonda knows she’s not doing maximal, no way
  - That makes sense to Peter because he doesn’t think anyone could do that five days a week, “*You would fry yourself*”
- Rhonda has noticed that by the 4th or 5th day, she’s PRing (she’s always competing against herself), but her lactate will be lower
  - She uses the Peloton, so it’s not as scientific as measuring wattage
- This doesn’t surprise Peter, because the way to get maximal wattage is to hold your highest constant maximum wattage and go
  - Zone 4 held indefinitely will produce a much higher average wattage than zone 3 alternating between 5 (or 6) and 1
- If your metric of success is total average wattages is over the course of the workout
  - This is what’s called **FTP (functional threshold power)**, and that is what the Peloton uses to estimate your zones
  - This is a steady-state workout not a Tabata

**Have you ever done the FTP test on the Peloton?**

- No
- On the Peloton, there is something called the “fitness test” and it will have you pick two 8-minute all-outs separated by some rest, or one 20-minute all out
  - Peter thinks the 20 minute all-out is a better test
  - It will average your wattage over 20 minutes and multiply it by 0.9 to calculate your FTP
- The FTP is defined as the maximum power you can hold for one hour, and the Peloton uses this as the metric to set the zones
  - Zones 1-7 are a function of power, not heart rate
  - They are all a function of that FTP number
- None of this is necessary for Tabata; you don’t need to know your zones for Tabata
  - It’s not about titrate to a given heart rate
  - It’s simply, go as hard as you humanly can for 10 seconds and then do nothing for 10 (repeated for a total of 8 times)
- Rhonda is using a slightly different protocol; it’s high-intensity interval training
  - She’s going much harder during the rest and not as hard during the workout

**How high are your lactates? Do you check your lactate at the end of both sessions?**

- She gets a 30-second rest period between the two, sessions of 8
  - She’s not resting, she’s going too hard
  - She’s probably in zone 3
- At the end of that she’s around 7-8 mmol
- She’s a “committed exerciser” not an athlete like Peter
- Peter points out that world-class athletes like [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) and [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) both put out relatively low lactate levels
- Rhonda might be one of those people who is so efficient that she doesn’t make much lactate
- Peter doesn’t think Michael Phelps has ever hit a lactate above 10 mmol, even when smashing world records
- With this type of high-intensity interval training (HIIT), you’re forcing adaptations on your mitochondria
  - You’re making more mitochondria
  - Several studies have show you can increase mitochondrial biogenesis in humans ([2020 review](https://www.mdpi.com/2076-3921/9/8/656))
  - Aerobic training can do this as well; it’s really a question of time

***If someone only has 10 minutes a day to devote aerobic training, then HIIT is type of training it needs to be***

- If someone wants the **maximum result**, to build the biggest pyramid, you would need an hour a day
- But some people don’t have the time or desire to do that, in which case 10 minutes a day of cardio and 30 minutes a day, 4x a week of strength training can provide amazing results
  - But you have to be laser focused (no messing around)
- Peter is sure there is no ambiguity about how hard Rhonda worked when she is done with that 10 minute workout
- Rhonda also uses the Peloton for strength training
  - There are a lot of paired sets and supersets
  - It’s nonstop training but not that long of a session
  - She’s putting in about 40-50 minutes of strength training a week, a minimum amount, but she used to not do any, so that’s progress (Peter is going to try to talk her into doing more over dinner)

## Possible brain benefits of sauna, and Rhonda’s personal protocol [1:09:30]

**Do you do sauna right after your workout? Do you dissociate (in timing) sauna from exercise?**

- It varies
- She does a lot of steam sauna and also uses a jacuzzi
  - She likes to do sauna during the day and the hot tub at night
- Both of those forms of heat stress have been [shown](https://pubmed.ncbi.nlm.nih.gov/28378983/) to increase [heat shock proteins](https://en.wikipedia.org/wiki/Heat_shock_protein) (a biomarker of [heat stress](https://en.wikipedia.org/wiki/Heat_shock_response))
- They may to increase [brain-derived neurotrophic factor (BDNF)](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor) as well
- She likes to read scientific papers or listen to podcasts (*The Drive* or [Tim Ferriss’s show](https://tim.blog/podcast/)) in the sauna; that’s her only time to listen to podcasts
- She does her workout in the morning and will have the sauna warmed up and ready to go so she can get right in after her workout
- She started using a sauna as a graduate student, and she realized if she went over a talk she was going to give, went over it in the sauna, she remembered it better

> “*It was very clear that there was something going on with my memory and very, very consistent*”‒ Rhonda Patrick

- When she dove into the literature she found that certain growth factors you make in the sauna in response to heat stress affect memory, so there is a plausible hypothesis there

**What’s your protocol? What’s your temperature and duration in the sauna?**

- This will depend on how hard she went on her workout, if she’s doing it right after the workout or later, midday as a break from working at the computer
- If she goes in the sauna right after her Tabata session, she probably stays in there 20-25 minutes with the temperature set to 175o F
- If it’s not right after a training session, she’ll stay in a little longer (30 minutes)
- She uses humidity too, which makes it feel hotter
- She used to do it really hot (190o F) but found she was getting more headaches and didn’t feel good

**How long did you sauna during your pregnancy?**

- She first found out she was pregnant when she was touring saunas in Finland
  - She did a lot of saunas and cold plunging
- When she came back home, sauna was out
- She talked to women in Finland who used the sauna throughout pregnancy, but she erred on the side of caution
  - Most of the evidence comes from using a hot tub, and it’s common knowledge that pregnant women shouldn’t get in the hot tub
- She waited until her daughter was six months before getting back into saunaing
- She continued to exercise through pregnancy

**Rhonda’s heat stress protocol at night**

- She uses the hot tub at night with her husband
  - He wants to do it every night because it helps him sleep tremendously
  - She doesn’t have much of an issue with sleep latency; she goes to bed at 9:30 and is asleep in 10 minutes
- Sometimes she will do sauna and the hot tub in the same day, it depends
- It is most important for her to get vigorous exercise

## The relationship between cardiorespiratory fitness and dementia risk [1:15:30]

- Looking into the literature on dementia risk/ cognitive impairment, the theme she has found is the more effort you put in (time), the bigger the benefit
- For example, there was a [longitudinal study of women](https://n.neurology.org/content/90/15/e1298') who were at twofold higher risk for Alzheimer’s disease
  - They were studied for decades beginning in their 70s, up until 2010 or something
  - Their fitness was measured on an exercise bike 5-7 times over the course of 40 years or something
- The women who were the most fit had something like 9x reduction in Alzheimer’s risk
- The women who had moderate cardiorespiratory had 4-5x reduction in Alzheimer’s risk
- Other studies use a questionnaire to measure fitness (not VO2 max), and they find no association between physical activity and dementia risk
  - You’ll also find questionnaire studies that show a benefit for people that are physically fit

***There’s a linear response between the volume and intensity of exercise and greater benefit in reducing risk of dementia***

- Peter points out that the studies that measure [VO2 max](https://en.wikipedia.org/wiki/VO2_max) are unambiguous ‒ it takes out the training component because it captures that benefit
  - “*People on this podcast have heard it too many times because I can’t stop talking about the benefits of having a high VO**2* *max*”

**Are women more responsive to the benefits of exercise than men because they are at a higher risk genetically (of Alzheimer’s disease)?**

- Women have twice the risk of Alzheimer’s disease as men
- For Parkinson’s disease, it’s flipped with men at higher risk
- Rhonda hasn’t seen the studies looking at the response to exercise with respect to the sex differences
- There is definitely differences with respect to their Alzheimer’s disease risk
- Women have a different metabolic response to exercise; maybe the hormonal response is different
  - She doesn’t know if this has been studied
  - There could also be immune system effects and exercise is affecting the immune system
  - There may be differences in myokines produced

**Myokines**

- [Myokines](https://en.wikipedia.org/wiki/Myokine) are molecules secreted by our muscles
- They talked about lactate, but that’s not a myokine, that’s a metabolite
- Engaging in physical activity, when we force our muscles to work hard, we make myokines
  - Sometimes it’s referred to as an exerkine
  - Examples include: [irisin](https://en.wikipedia.org/wiki/Myokine#Irisin), [IL-6](https://en.wikipedia.org/wiki/Interleukin_6), there are others

***Myokines affect the brain and cancer risk***

- There may be differences [in women] in respect to myokines that are being secreted in response to the stress of exercise

## How exercise may reduce the risk of cancer [1:20:30]

**The relationship between cancer risk and exercise**

- Many things are obvious problems with respect to dementia, it’s hard to make the case that they put you at risk for cancer
  - For example, disrupted sleep, poor exercise, etc.
- It’s hard to make the case that bad sleep is related to cancer (though Peter thinks it is); the data are not clear
- You can certainly make the case that poor sleep would lead to a weakened immune system
  - This would easily lead to an increase in cancer propagation (not necessarily initiation)

> “*I just don’t see how one could not be at this point convinced of the benefit that exercise poses to the brain. It seems much harder to make the case for cancer.*”‒ Peter Attia

**How compelling are the data?**

- Peter hasn’t gone as deep here as he has on cardiovascular disease and neurodegenerative disease
- This is another area Rhonda is very interested in
- As you get into your fourth decade of life, you have experienced a friend or family member who has come down with cancer, and you see how terrible it is to get cancer
- The best hope is to prevent cancer
- They mentioned elite athletes earlier, people who won the Tour de France or are Olympic medalists
  - You have to be quite an athlete just to get into the Olympics
- Rhonda has seen observational [studies](https://pubmed.ncbi.nlm.nih.gov/32727712/) of athletes who entered the Olympics between 1912-2012 and it compared all-cause mortality and cancer-related mortality between them and the general population
  - They saved 1-1.5 years of life from not getting cancer, and they had 5-6 years of lifespan extension compared to the general population
- This was the same as the [French Olympians](https://pubmed.ncbi.nlm.nih.gov/29730745/), they lived on average 5 years longer than the general population, and 2 years were attributed to not getting and dying from cancer
- What’s funny is that Rhonda remembers her postdoctoral mentor ([Bruce Ames](https://www.bruceames.org/)) telling her, “*I once read of all the things that you can do, if you prevent cancer, you’re really only save about two years of your life*.”
- Cancer mortality is not necessarily the same thing as not getting cancer; that just means you’re not dying from cancer
- Studies looking at **cancer prevention** really seem to focus on a specific type of exercise, and that is **aerobic exercise**
  - For whatever reason, there’s not a lot of literature on strength training and cancer prevention
  - You can find studies on strength training and cancer related mortality
  - But with prevention, it’s focused for whatever reason, on aerobic exercise
- A woman’s lifetime risk of **breast cancer** is about 1 in 8
  - Many different lifestyle factors play into that and exercise is one
- The lifetime risk of colon cancer for the average woman is 1 in 23; for a man it’s around 1 in 25
- Compare this to other cancers where the lifetime risk is low
  - Such as esophageal cancer where the chance is 1 in 500
  - You’re more likely to die in a car wreck than get that cancer

***Prevention of breast cancer, colon cancer, and a few other types of cancer are quite responsive to exercise ‒ up to 50% reduction in mortality and recurrence in those who exercise***

**The question is how much physical activity?**

- The data suggests you need to do more exercise to reap the cancer preventative benefits than you do the cardiovascular benefits, even some of the metabolic benefits
- This gets into the upper limit of what committees are recommending ‒ 300 minutes a week of moderate intensity exercise or 150 minutes a week of vigorous exercise
  - Their definition of vigorous is a little below Rhonda’s definition

> “*It seems like the amount of exercise… you actually have to put in a little bit more time and effort for the cancer [risk reduction], but any amount is beneficial*”‒ Rhonda Patrick

- - In the [observational data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6527123/), you can find anywhere between a 10% to 20% reduction of breast or colorectal cancer in people who exercise
    - When you’re talking about a type of cancer with a higher lifetime risk, it’s more compelling
  - Peter adds, “*I’d be curious to see if the data line up with the cancers that are known to increase in risk due to obesity*”
    - Obesity is the second leading modifiable risk factor associated with cancer, after smoking
    - He always thought it was an oversimplification to use obesity as a proxy; he thinks it’s probably [insulin resistance](https://peterattiamd.com/geraldshulman/)
    - For breast and colorectal cancer, obesity amplifies the risk while there are other cancers where obesity doesn’t seem to play as much of a role.

- ***It would be interesting to align the exercise data with the obesity/insulin resistance data and see if exercise is disproportionately reducing risk in those cancers for which obesity is a risk***

- - - Rhonda thinks there is some data to suggest this is correct
- There are 13 or so cancers for which obesity increases the risk of ‒ breast and colorectal cancer on on that list ([reviewed in 2018](https://pubmed.ncbi.nlm.nih.gov/30445141/))
  - Endometrial, esophageal, renal and pancreatic adenocarcinomas; hepatocellular carcinoma; gastric cardia cancer; meningioma; multiple myeloma; colorectal, postmenopausal breast, ovarian, gallbladder and thyroid cancers

**Rhonda thinks there’s a direct mechanism by which aerobic exercises decreases the risk of these cancers**

- Via [myokines](https://en.wikipedia.org/wiki/Myokine) produced during aerobic exercise
  - Some of these myokines have been shown to decrease the production of growth factors secreted from cancer cells
  - Also, they are killing cancer cells through a variety of other mechanisms
- There is also the anti-inflammatory effect of exercise
- Exercise improves insulin sensitivity, particularly in combination with dietary strategies
- Weight loss itself is an important component of the reduced cancer risk
- It’s the combination of these things that are direct effects from exercise
- The data is more and more compelling that exercising seems to be very important for reducing cancer metastasis and also dramatically decreasing cancer recurrence
  - An interesting mechanism which this is likely occurring is literally through that shear force mechanism Rhonda was describing for the brain
  - When cancer cells, tumor cells escape the site of the tumor, and they make their way into circulation they’re called a circulating tumor/ cancer cell
  - These circulating tumor cells are traveling throughout the vascular system to distant sites, and they are the seed of a new tumor forming in another tissue
  - It’s interesting because cancer cells are so messed up, they’re very, very sensitive to any type of stress
  - Cancer cells have these mechanoreceptors on their cell surface that are responsive to shear force, so die because they can’t stand just the shear force of the blood flow through the vascular system ([*in vitro* data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5215453/))

> “*So when you get your blood pumping, it’s like a hurricane that wipes it [circulating tumor cells] out*”‒ Rhonda Patrick

- There have been [randomized trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6192582/) showing it dramatically decreases circulating cancer cells in people compared to whatever their other standard treatment that they’re being given
- Paring that data with other [data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7273753/) where exercise is prescribed to patients and it’s benefit with respect to their cancer metastasis reduction and also mortality reduction (50% mortality reduction) versus recurrence as well

***There is substantial evidence to suggest that being physically active is a good measure for cancer prevention***

**There are also lots of differences in the response to exercise**

- There are sex differences ‒ women respond better
- Certain cancer types respond better
- There are covariates ‒ obesity, insulin resistance, age

## The overarching impact of exercise of health, and the importance of focusing the factors that matter most [1:33:15]

**General interventions to reduce risk of disease**

***I do think that you can make the case that what can I do in my life to reduce my risk of getting cancer, reduce my risk of dying from cancer, reduce my risk of getting Alzheimer’s disease, reduce my risk from getting dementia, reduce my risk from getting cardiovascular disease, reduce my risk for type two diabetes? The only panacea there is exercise.***

- Unfortunately, exercise is the thing you have to put the most effort in
  - It would be a lot easier to take a supplement or a pill
- Getting yourself to a good **omega-3** status (and defining what that is) is still being investigated
  - That’s a low hanging fruit that should not be ignored
- But exercise is the king, and that’s the thing you should focus on
- For someone who is obese, they need to lose weight, and exercise is part of that program
  - They shouldn’t be worried about all the other things yet
  - Calories in, calories out matters to some degree

**Peter’s take on this**

- Exercise matters not just on the **energy balance side**, but for example, exercise makes you more sensitive to **satiety hormones**
- The person who is overweight and clearly eating more than they should isn’t doing that by choice (for the most part)
  - They’re struggling with hunger
- Peter asks, “*Why is it that a person who is not in energy balance is not responding to the normal satiety signals?*”
  - On the food science side, we could talk about a whole bunch of reasons why our food has been hijacked
    - Our food is void of nutrients; it’s hyper-palatable; it’s far too available
  - One thing that doesn’t get enough attention is that ***“An exercising person has a better sense of nutrient requirement. Their body physiologically is more in tune with their appetitive needs.”***
  - Exercise matters as much on the energy balance side as it does on reducing input via the feedback loop that exercise brings

**Focusing on the important things:**

- So many women are so petrified of hormone replacement therapy because of this awful study by the [Women’s Health Initiative (WHI)](https://jamanetwork.com/journals/jama/fullarticle/195120), which was completely misinterpreted
  - Some of the people who ran this study still maintain that conjugated equine estrogen plus MPA (the synthetic progesterone) increase the risk of breast cancer, even those people will acknowledge it did not increase breast cancer mortality
  - If you take the most favorable WHI reading that conjugated equine estrogen plus MPA increased the incidence of breast cancer by 0.1% in absolute risk but did not increase breast cancer mortality

***So here, you have basically a non-event that has most people panicked senseless, most women panicked senseless when confronted with taking hormones during the perimenopausal period, and yet at the other end of that spectrum, we have a treatment [exercise] that has more than a log-fold benefit in the other direction [in reducing risk]***

## Impact of alcohol consumption on breast cancer risk and overall health [1:37:15]

- Peter wishes people would allow their attention to be allocated proportionate to the size of the impact
- Rhonda agrees 100%
- There are [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4453639/) of women who engage in moderate drinking (3 drinks a day, which is a lot) and that translates to a lifetime risk of breast cancer around 1 in 6
  - That’s significant, but you don’t hear about women petrified of drinking two glasses of wine a night, which is not uncommon

**What’s the most important thing to focus on for reducing the risk of breast cancer?**

- 1 – Obesity absolutely impacts breast cancer
- 2 – Physical activity impacts it in the opposite direction; it has really enormous benefits
- 3 – Alcohol consumption (even mild alcohol consumption) impacts breast cancer

> “*There is no amount of alcohol that is healthy. The J curve is a misnomer*.”‒ Peter Attia

- There’s not much of an increase in risk somewhere between zero and one drink, but there is *not* a reduction in risk (for mortality in general)
- There is a J-curve where complete alcohol abstinence is a greater risk than one drink a day, but the Mendelian randomization makes clear that that’s not true
- Secondly, when you look at all the confounders of the people who are drinking zero drinks and what confounds their mortality, Peter feels very comfortable saying, “*There is no dose of alcohol that is healthy*”
- But at a very low dose, probably four to seven drinks per week, you probably can’t quite quantify the harm
  - He feels that things like the [French paradox](https://ifh.rutgers.edu/highlight/modern-myths-of-aging-red-wine-and-the-truth-behind-the-french-paradox/) have far better explanations
- Rhonda agrees that the data is a mess and asks, “***Can you have your weekend glasses of wine?***”
  - Absolutely yes
  - The only evidence Rhonda has seen against mild drinking (less than 1 drink a day)is on the National Cancer Institute site where for one of those cancers the risk is like 1 in 500
    - It’s for a cancer that you already have a lifetime risk of 1 in 500
    - It’s less than 1% of an increase, but your lifetime risk goes up
    - Peter doesn’t see the point because you can’t measure it
- Peter adds, “*It’s a classic example of ‘the dose makes the poison’, but don’t confuse that the poison is a poison.*”
- Cigarettes is another example ‒ if you smoked one cigarette twice a week your risk of cancer would go up, but you wouldn’t be able to measure it
  - That doesn’t change the fact that cigarettes are harmful
  - Humans don’t live long enough to see the separation of those [Kaplan Meier curves](https://en.wikipedia.org/wiki/Kaplan%E2%80%93Meier_estimator), maybe if our natural lifespan was 500 years
- Focusing on cancer, it really comes down to establishing causality
  - Is tobacco causally related to disease? Yes, it’s a harmful thing to take, but the dose matters
- Peter probably has anywhere from zero to four drinks a week, but when he’s drinking those four drinks across two or three days, he’s not thinking it is healthy
  - It’s a hedonic pleasure that’s not good for him, but it’s enjoyable
- Rhonda asks, “***How do you feel about*** [***APOE-ε4 carriers***](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms) ***and alcohol consumption?***”
  - They are more susceptible to the deleterious effects of alcohol
  - In general, they are more susceptible to the deleterious effects of poor sleep, and this is one of the ways Peter think’s alcohol is disproportionately hurting the brain
    - Especially since most people who drink do so in the evening
    - Poor sleep is causally driving Alzheimer’s risk and cardiovascular disease risk
    - Peter is less clear on cancer
- If you’re going to have a drink, there are some principles for how you might minimize the damage ‒ the number of drinks you have and how long you have it before bed

## Exercise as an intervention for poor sleep habits [1:42:30]

**Continuous glucose monitoring revealed the effects of disrupted sleep**

- Rhonda started wearing a continuous glucose monitor largely because of Peter
  - She began when she was a new mom, five years ago
  - Peter replies, “*That can’t be a good time to wear a CGM, although it must have been interesting.*”
- She thought she was going to learn about how her body responds to the food she eats
- Her biggest take away was the effect sleep interruption had on both her fasting blood glucose and [postprandial](https://en.wikipedia.org/wiki/Prandial) glucose levels
  - She could get to what you would call a pre-diabetic level; it was insane
  - And the effect lasted about 48 hours or so
- When she was able to workout, she was doing a lot of high-intensity interval training (an hour-long spin class), and this completely blunted that effect of sleep interruption
  - This crazy glucose dysregulation was almost completely blunted by exercise
- Rhonda’s takeaway, “***I have to work out no matter what, no matter what. No matter how I feel, it doesn’t matter. It’s beneficial****.*”
- There was an interesting [study](https://pubmed.ncbi.nlm.nih.gov/34187783/) looking at sleep habits and people who had poor sleep (interrupted sleep or didn’t sleep as long), and they had higher all cause mortality, **but only in the people who weren’t physically active**
  - With all the caveats of observational data, reverse causation

> “*Exercise can forgive a lot of sins in many ways*”‒ Rhonda Patrick

- Rhonda has one of those [*APOE-ε4* alleles](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms), and it’s a burden, you have to calculate things and be very specific in the action you take
  - If she’s having a party and they’re going to have some mimosas, she’s going to exercise no matter what
    - That might take off some of the stress
  - She hardly ever drinks mostly because she is E4
  - She’s come to the conclusion that her brain cannot repair damage as well as her husband’s, who doesn’t have an E4 allele
  - But she will occasionally have a glass or two of wine (last time she drank was Valentine’s day)

***In terms of sleep, exercise does seem to forgive a lot of sins***

- She borrowed that phrase from [Stuart Phillips](https://www.science.mcmaster.ca/kinesiology/component/comprofiler/userprofile/phillis.html); Peter remembers him saying that on her [podcast](https://www.foundmyfitness.com/episodes/stuart-phillips)

## The longevity benefits of consuming adequate protein and strength training to preserve muscle mass and strength [1:46:30]

**Effects of a low protein diet**

- Peter and Rhonda have talked about this a lot; the last time they were together was pre-COVID
- They were both struggling with **two competing ideas** in geroscience that seemed at odds with each other
  - 1 – There’s a body of mostly animal literature that suggests lower protein intake is associated with a longer life
  - 2 – On the other hand, there’s this literature that says lower protein intake is associated with more frailty in humans, and that’s associated with a shorter life

***Peter’s thinking 3.5 years ago was that they simply needed to find the minimum effective dose of protein needed to not undergo mandatory catabolism; since then, his thinking has evolved so much***

**Rhonda’s thoughts on this today**

- There’s a large body of animal evidence, coupled with epidemiological data about vegetarians who are taking in lower amounts of protein and their all-cause mortality and their cancer mortality
  - These vegetarians had lower all-cause mortality, but cancer mortality was only lower in individuals who were *not* sedentary or smokers (or didn’t have some other unhealthy lifestyle factor)
- Then, people taking in higher animal protein who were basically healthy had a similar all-cause mortality/ cancer-related mortality as these vegetarians
- Additionally, in studies where they normalized for fruit and vegetable intake, high protein versus low protein, they found no difference in early mortality

***It seemed that a lot of the data that were espousing low protein were confounded by lifestyle choices, and high protein was also negatively confounded by high calories***

- Rhonoda wasn’t of the opinion that vegetarian diets were superior to meat eating or healthy omnivore type diets
- The field of longevity science was dominated by animal studies of restricting protein intake to make a mouse live longer and not get cancer, but there has been some pushback on this
  - Including the work of exercise physiologist [Stuart Phillips](https://www.science.mcmaster.ca/kinesiology/component/comprofiler/userprofile/phillis.html), and [Don Layman](https://fshn.illinois.edu/directory/dlayman) ([previously on *The Drive*](https://peterattiamd.com/donlayman/))
  - [Brad Schoenfeld](https://www.lehman.edu/academics/health-human-services-nursing/health-promotion-nutrition/fac-schoenfeld.php) is another one looking at protein intake
  - They’re looking at strength training and its effect in humans on muscle protein synthesis, and also looking at data with respect to muscle mass and all-cause mortality and Alzheimer’s disease, dementia
    - Strength training also can modify that risk and also cancer mortality
- Peter adds that a [strong grip](https://peterattiamd.com/avoiding-injury-part-ii-grip-strength/) versus weak grip (monotonic change in grip strength) are associated with a 70% reduction in incidence and mortality from dementia
  - Remember, people don’t understand you can’t reduce risk more than 100%
    - So it’s not like increasing risk, which can be 100, 200, 300
  - When you’re talking risk reduction, 70% is staggering

***Strength matters and there are two important signals for your muscles: physically working them and protein intake***

- Stuart Phillips made the point that the animals being studied are in a sterile environment, they’re not benign exposed to influenza and all these infectious diseases
- If you’ve ever had a parent or relative that has gone into the hospital and had bedrest then come out… Rhonda had a grandparent who literally couldn’t walk after back surgery, forever, that was it
  - Their trajectory just went completely down from losing muscle at an older age

***Building up a bigger reserve of muscle mass in youth and middle adulthood is very important***

- But the animals that people are using to study protein restriction, they’re not being exposed to that
  - They’re not losing some percentage of muscle mass
- It’s pretty intense how much you can lose from three weeks of bedrest
- Also, mice are dying from cancer and not the same types as humans or the other diseases humans die from
  - [Matt Kaeberlein](https://kaeberlein.org/) discussed this [previously on *The Drive*](https://peterattiamd.com/mattkaeberlein3/)
  - People get a lot of epithelial tumors (solid tumors), but mice are dying from lymphomas
- Rhonda believes in the importance of animal studies, they provide important mechanistic data and things you won’t ever get from humans

***But at the end of the day, Rhonda started to realize that looking at mice in a sterile environment where they’re not being exposed to the same stimuli as humans, and things are very different in terms of aging***

- This is where it started to fall apart for her
  - The animal studies didn’t make any sense

***She realized that animal studies were not the thing to look at to focus on healthy aging for herself, for everyone else; the tipping point was the realization of the importance of muscle mass***

- In these animal studies, there is a little bit of improvement in their cardiovascular health, but is it better than exercise?
  - Exercise also does that
  - ***Rhonda wasn’t convinced that she needed to adopt a low-protein diet***
- Peter adds, “*I’m still waiting for somebody to demonstrate for me that if there is an increase in the risk of cancer associated with higher protein intake in humans, I’d like to see that quantified.*”
  - Is that increase in risk greater than the offset of sarcopenia
  - There is no ambiguity about the devastation of [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia) on an aging population

**Longevity, IGF-1, and lifestyle interventions [1:55:00]**

*To avoid sarcopenia in an aging population you need two things:*

- 1 – Adequate protein intake, which gets larger and larger as you age
- 2 – Strength training
- This story got confounded by work in [*C. elegans*](https://en.wikipedia.org/wiki/Caenorhabditis_elegans) roughly 30 years ago when seminal work was [published](https://pubmed.ncbi.nlm.nih.gov/8247153/) on the [*DAF-2*](https://en.wikipedia.org/wiki/Daf-2) mutation (the homolog of the [IGF receptor](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1_receptor))
  - If you knocked out that gene, you could double the lifespan of *C. elegans* (a worm) from roughly two weeks to four weeks
  - ***The implication was profound, and Peter doesn’t want to downplay the more important takeaway ‒ lifespan is malleable***
  - Somehow knocking out this gene was tantamount to dropping [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) to zero, and this became the key to longevity
    - A story that is incorrect but became dogma
- Rhonda did those experiments with her own hands when she was at the Salk Institute in [Andy Dillin’s](https://vcresearch.berkeley.edu/faculty/andrew-dillin) lab
  - Andy trained with [Cynthia Kenyon](https://profiles.ucsf.edu/cynthia.kenyon), who made the [discovery](https://pubmed.ncbi.nlm.nih.gov/8247153/) back in the early ‘90s
  - And it was very exciting to watch this worm go from a 15-day lifespan to at 30-day plus lifespan
    - It has a gene homologous to one we have (*DAF-2* and the *IGF-1 receptor*)
    - Their healthspan was remarkable; the worms were youthful
  - ***But then you also realize the worms go into this*** [***dauer state***](https://en.wikipedia.org/wiki/Dauer_larva) ***where inorder to get that lifespan extension, they’re going into this metabolic stasis and this is something that humans don’t do***
    - It’s a completely separate pathway that is required for that lifespan extension
    - [IGF-1](https://en.wikipedia.org/wiki/Daf-2#IGF-1_signal_pathway) and the [insulin pathway](https://en.wikipedia.org/wiki/Insulin_signal_transduction_pathway) are both tied to that

**IGF-1 is a growth factor**

- Growth factors in the context of a tumor can allow tumor cells to override cell death mechanism so they can continue to survive when they otherwise might have been signaled to die

- There can be a problem with too much IGF-1 in the context of a tumor
  - What causes that high IGF-1 is up for debate
  - But at the end of the day, IGF-1 doesn’t necessarily cause the tumor

**There are things you can do in your lifestyle**

- Exercise causes [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) to go [up in] muscle, where you’re repairing damaged muscle
  - It’s helping muscle repair
- IGF-1 goes [up in] your brain and is important for neurogenesis
  - There are multiple [studies](https://www.sciencedirect.com/science/article/abs/pii/S0889159112004837) showing that you can take an older adult, train them for a year, and their hippocampus will grow by 1% to 2%
  - Another study shows this with the subventricular zone
  - These are two regions of the brain where data says that growth of new neurons is occurring in adults

**Do you think that part of the vehicle for exercise to do that is through IGF-1?**

- Yes, absolutely
- Animal studies have shown that
  - There are caveats about how this translates to humans
- Oftentimes, you have to take the whole body of evidence, the human evidence coupled with mechanistic data from animal studies and put together the story to the best of your ability

***You always hear, “I want to lower IGF-1,” but it is important for the brain and important for muscle, and the way to get it to the brain is through exercise***

- That has been shown in human studies as well

**There is some really impeccable animal research, but when you translate that to humans, consider who you are talking to**

- Is the person overweight who needs to focus on weight loss?
- Is the person healthy and active who is now terrified to take in protein because they read about some animal study where too much protein increases mortality?
  - Are they getting enough protein?
- Some scientists and health science communicators (including Rhonda) have been guilty of not disentangling who they’re talking to
- Peter adds that age is an important part of this
- There was a [study](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(14)00062-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS155041311400062X%3Fshowall%3Dtrue) that looked at the relationship between protein and IGF-1
  - They stratified by protein intake, low, medium, high, low, medium high
  - They looked at middle-aged people (50 to 65), and then people over 65
  - In people aged 50 to 65, there was a relationship between protein intake and IGF where higher protein intake was associated with higher IGF-1
    - Now it wasn’t a huge difference, and this gets overstated constantly, but it was statistically significant
  - What often gets ignored is in the people over 65, there was no statistical difference whatsoever between protein intake and IGF-1 (shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/04/f3-rhondapatrick2-1024x873.png)

**Figure 3. Serum IGF-1 levels in people with a low, moderate, or high protein intake**. Figure credit: [*Cell Metabolism* 2014](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(14)00062-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS155041311400062X%3Fshowall%3Dtrue)

***It is taken as dogma that the more protein you have, the higher your IGF-1, but in people >65 this is not the case***

- Peter harps on this because this is the population he is most concerned with sarcopenia
- If the message that’s getting translated to somebody 65 or older is “*I shouldn’t be eating protein… somehow high protein is going to give me cancer,*” through the lens of IGF-1 the answer is , “*No it’s not.*”
  - The greatest risk they face is going to be the results of low muscle mass and low strength
- Even if we believed (and Peter does not) that younger people eating more protein leads to more IGF, which is bad, he would argue that the absolute difference in mortality between the younger and the older in the presence of high protein is no comparison because the absolute risk of death is so much lower in the younger person
  - So higher-protein across the board is going to save more lives than it would ever harm in younger people (if you could convince yourself that a higher protein intake was associated with increased mortality)
  - Peter talked with [Matt Kaeberlein](https://kaeberlein.org/) about this in a [previous podcast](https://peterattiamd.com/mattkaeberlein3/)
- Many people are focused on the recommended daily allowance of protein, but these are old studies that were not done correctly, using the wrong tracers
  - What is this telling you about how much protein you should take in?
  - Considering this was a turning point for Rhonda because she knew nothing about how the recommended dietary analysis was determined
    - She knows everything about micronutrients and RNAs but knew nothing about protein
- Once she talked to [Stuart Phillips](https://www.science.mcmaster.ca/kinesiology/component/comprofiler/userprofile/phillis.html) ([on her podcast](https://www.foundmyfitness.com/episodes/stuart-phillips)), he explained that he and others repeated those studies using different tracers and they determined the ***minimum level of protein intake was more like 1.2 grams per kilogram of body weight*** (not 0.8 g/kg)
- The big difference is you don’t store protein
- On top of that, when you start to get into the physically active people or elderly population where their muscle isn’t getting that signal as well to increase muscle protein synthesis from the same amount of protein that their younger self would ([anabolic resistance](https://pubmed.ncbi.nlm.nih.gov/29389741/#:~:text=Anabolic%20resistance%20describes%20the%20reduced,declines%20in%20skeletal%20muscle%20mass.)), they actually need more protein
  - On the order of 1.6, 1.8 g/kg

***Peter tells people to aim for 1 g of protein per 1 lb of body weight, which would be 2.2 g/ kg***

## How to get enough of the right kind of protein in your diet [2:05:15]

**The other thing that complicates it is not all protein is created equal**

- If you’re getting a reasonable amount of your protein from plants, you’re getting a lower bioavailable amino acid
  - You’re also not getting the same quantity of [leucine](https://en.wikipedia.org/wiki/Leucine), [lysine](https://en.wikipedia.org/wiki/Lysine), and [methionine](https://en.wikipedia.org/wiki/Methionine), which are probably the three most important amino acids
- One of the things [Don Layman](https://fshn.illinois.edu/directory/dlayman) talked about (on a [previous podcast](https://peterattiamd.com/donlayman/)) was if you really want to be rigorous about this, you probably want to track those amino acids
  - You want at least 1 g of methionine per day
  - 2-4 grams of leucine and lysine per serving

***Once you go through the math a couple times with things you eat repeatedly, you’ll realize that’s probably more protein than you’re used to eating***

- When you start to factor in those other two categories, more demand from high intensity workouts where you’re ripping apart muscle fibers, lifting weights, rucking, etc
  - You’re demanding more amino acids for the turnover
- Peter thinks [**anabolic resistance**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8131552/) is the biggest issue, and this is something he wasn’t paying enough attention to up until two years ago
  - He wasn’t appreciating that his older patients had an additional problem that younger patients didn’t have with respect to that signal
- Rhonda notes that for her to get 1.6 g/kg she has to supplement with [whey protein](https://en.wikipedia.org/wiki/Whey_protein)
- Peter divides the 2.2 g/kg up over four meals
  - Two meals and two protein snacks
  - He makes a whey protein shake with frozen berries and almond milk and eats five [venison jerky sticks](https://mauinuivenison.com/collections/venison-snacks/products/all-natural-venison-stick-24-pack)
    - Full disclosure, Peter is an investor in the company that makes venison jerky
  - A lot of times the meals are an omelet and then protein dinner
  - It’s work, it probably consumes more of his dietary planning and attention than anything else

> “*I don’t pay any attention to how many carbs and fat I eat anymore. I’m just paying attention to protein intake.*”‒ Peter Attia

***Rhonda never really paid attention to her protein intake until last June/ July when she started focusing on strength training, both for muscle mass and bone mineral density***

- **Bone mineral density** is another thing where you want reserves, especially as a female
- Focusing on strength training and protein intake has been challenging as she always focused on micronutrients
- She takes supplements in addition to eating leafy greens and veggies
  - It’s either roasted veggies or salad
- The protein intake has been challenging; she typically does three meals
  - One is a protein snack
  - Salmon or a homemade turkey burger
  - She doesn’t consider a protein shake a meal, but it’s satiating
- As they discussed, when you workout your satiety hormones go up and your not hungry
  - She doesn’t necessarily want to eat
  - There’s all these competing things where she’s trying to eat enough protein, but she’s not really hungry

**Does someone who is overweight or obese need to focus so much on protein intake?**

- Peter observation is that most people are undernourished and adequately muscled, so it would be okay for them to lose lean mass in the short run

> “*It’s very difficult to lose heaping amounts of body fat while preserving lean mass*”‒ Peter Attia

- Peter tends to focus more on caloric restriction coupled with training
  - Training is used as a way to offset some of that lean mass loss
- For people who are using caloric restriction, Peter recommends setting a protein target that is at 2 grams per pound of body weight
  - This has satiating benefits
  - There is also the thermogenic effect and benefit of protein over fat and carbohydrate

**Meeting this protein target while cutting calories via dietary restriction or time restriction (DR/TR) can be overwhelming**

- Sometimes when you force high protein, you end up getting high calories with it
- This is where Peter advises to simply focus on the DR/TR approach
- Patients who are taking [GLP-1 agonists](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1_receptor_agonist) ([semaglutide](https://en.wikipedia.org/wiki/Semaglutide) or [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide)) are another group where Peter pays a lot of attention to protein intake
  - Especially in people just trying to lose 10 lbs
    - People trying to get their beach body for a wedding
  - It’s different if your a hundred lbs overweight and you’ve tried everything ‒ here the benefits clearly outweigh the risks
  - These drugs are so effective at squashing appetite that he’s seens people who basically just want to drink alcohol when they’re one it, and they lose weight like crazy because they’re not getting that many calories
    - They just like wine, and they’re losing muscle drinking wine
- Rhonda has noticed the same thing in some acquaintances
  - A stay-at-home mom who wants to lose 10 lbs and has the means to get one of these drugs; they look like their muscle is wasting

## Fasting: weighing the risk vs. reward [2:12:15]

- Rhonda also notices that Peter used to do a lot of fasting, and he doesn’t do it as much or for as long
- Fasting and time-restricted eating is another area where she has had a shift in her understanding
- A lot of people use time-restricted eating; they practice it by skipping meals
- But when you’re skipping a meal, ***you’re skipping your protein***
  - Your losing muscle mass because you’re not getting that important signal, especially if you’re not resistance training
    - This is a disaster
    - It wasn’t something Rhonda had thought about a lot previously

**Peter’s take on why fasting can be at odds with adequate maintenance of muscle**

- He agrees, the greatest drawback is that patients get protein deficient
- Time-restricted feeding as a strategy for weight loss vis-a-vis caloric restriction is very effective with a small enough feeding window
  - With 16/8 you can eat your way into obesity
  - Once you get down to 22/2 or one meal a day, really restrictive, you’re going to lose weight

***The problem is even if you managed to eat 1 g of protein per lb of body weight in a single meal, you wouldn’t be able to utilize those amino acids because you tap out at 40-50 g of amino acids (protein) per meal***

- So if you just ate 160 g of protein in that one meal, you basically flushed a bunch of them down the toilet
  - Protein is coming out as urine, coming out of the [urea cycle](https://en.wikipedia.org/wiki/Urea_cycle)

***Peter counsels patients using time-restricted eating to have protein snacks outside of their feeding window***

- If someone is going to have lunch at 2:00 and dinner at 7:00, have two protein snacks outside of that
- That becomes challenging because those protein snacks can’t really have much else in them
  - They have to be very low calorie otherwise you’re not doing time-restricted feeding
- People get upset and say, “*But oh my God, that’s outside of my feeding window. Will that impair autophagy?*”
  - Peter argues you’re not getting [autophagy](https://en.wikipedia.org/wiki/Self-cannibalism) doing a single day time-restricted feeding anyway
- You may also think about cycling periods of time-restricted eating just so you are able to get in those amino acids
- As Peter gets older (age 50), maintenance of muscle is a very high priority

## How Rhonda’s views have shifted on diet and exercise [2:15:30]

**Benefits of exercise for aging**

- Rhonda notes that you can see the difference as people age when people work out (do aerobic and strength training)
- A study was recently published reporting the biological markers of aging, and people looked at pictures and ranked participants age
  - According to all these biomarkers, their chronological age may be older than their biological age
- Peter feels like excess exercise can prematurely age you as well
  - He doesn’t know how much of that is sun damage because if you exercise outdoors, the sun can play a horrible role in that

**Are there any other things that you believe today that you didn’t believe three or four years ago?**

- The most important are muscle mass and protein intake
- Also fasting and the effects of time-restricted eating on weight loss
  - Specifically attributed to caloric restriction
- There are benefits to eating within your [circadian rhythm](https://en.wikipedia.org/wiki/Circadian_rhythm)
- If you eat late at night when you’re making [melatonin](https://en.wikipedia.org/wiki/Melatonin) two to three hours before bed, you’re basically inhibiting insulin secretion and there’s data showing that glucose levels will be higher with the same exact macronutrient intake as if you ate it earlier
- There are benefits to resting the gut/ digestion
  - DNA repair mechanisms, [autophagy](https://en.wikipedia.org/wiki/Autophagy)
- Rhonda is not sure that the sensitive assays we have to measure autophagy reflect all the times it’s happening
  - She personally think there’s some amount of autophagy occurring in between meals

**Is autophagy that occurs between meals clinically more significant than what exercise would induce?**

- No
- Peter’s point is how long would you need to fast to get the [benefits](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5538402/) of an amazing workout?
  - He thinks it’s probably a long time
  - You might have to go a full day without food or a couple of days without food to get the benefits of that
- He agrees, that without biomarkers for autophagy, a lot of this stuff is very difficult to speculate on because we can’t really extrapolate from mice on this
- It’s non-linear, and Peter has not heard a compelling argument for what the ‘answer’ is
- Rhonda thinks it’s better to eat within a circadian window
  - There is a cumulative effect on metabolism
- It’s also better to *not* eat within a 15-hour window, which most people in the U.S. do
  - Maybe this doesn’t matter if you’re exercising
  - Peter thinks this is important for sleep
- The benefits of **nighttime food restriction** in terms of who was the least insulin sensitive and the negative impacts of thermogenesis and other things on **sleep**
  - A late night meal is a great way to destroy good sleep
  - This is probably the most compelling reason for nighttime food restriction
  - It’s also clear how alcohol impairs sleep

> “*My perspective has shifted as any scientist that’s following data should*”‒ Rhonda Patrick

- When new data comes out, you have to reassess things
  - We have new tools (they’re always getting better), so you have to reassess things
- Rhonda reassesses the supplements she’s taking
  - What she takes now versus five years ago is totally different
  - There are some base things that are the same, vitamin D and omega-3 are super important

## How to follow Rhonda’s work and more about the benefits of lactate for the brain [2:21:00]

**Follow Rhonda**

- At her podcast [Found My Fitness](https://www.foundmyfitness.com/episodes)
  - It’s on [Apple](https://podcasts.apple.com/us/podcast/foundmyfitness/id818198322) and [Spotify](https://open.spotify.com/show/5QjpaU0o1Q2MkVZwwG3y7d)
- There are topic articles on her website, [Found My Fitness](https://www.foundmyfitness.com/topics)
  - She covers the [blood-brain barrier](https://www.foundmyfitness.com/topics/blood-brain-barrier) more in-depth
- Short points can be found on her [Instagram](https://www.instagram.com/foundmyfitness/?hl=en) and [Twitter](https://twitter.com/foundmyfitness) accounts (Found My Fitness)
  - You can’t go in-depth and into the nuance on these platforms
- Peter was talking to Andrew Huberman on a [recent podcast](https://peterattiamd.com/andrewhuberman/) and were singing praises to Rhonda as truly the OG health podcaster

**When did you start your podcast?**

- In 2014
- She had just started her postdoc in Oakland at UC Berkeley
  - [Ron Krauss](https://profiles.ucsf.edu/ronald.krauss) and [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) were down the hall
- Her second [podcast was with George Brooks](https://www.foundmyfitness.com/episodes/george-brooks) on lactate
  - They went into detail on the brain, the importance of lactate, and the intensity of exercise

> “*That whole podcast shifted my thinking of intensity of exercise and the importance of lactate*”‒ Rhonda Patrick

- Rhonda began her podcast as a weekend thing, it took off, and she loved it so much

**The importance of lactate**

- Rhonda’s training was in mitochondrial metabolism
  - In grad school, she looked at the role of mitochondria in cancer
  - She was thinking about lactate in a completely different frame of mind
- Peter adds that lactate is an important signaling molecule in addition to all the other things they talked about
- At least one previous guest ([Iñigo San-Millán](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) on [episode #201](https://peterattiamd.com/inigosanmillan2/)) has suggested that George Brooks is deserving of a Nobel prize
- Rhonda hates that his [lactate shuttle theory](https://en.wikipedia.org/wiki/Lactate_shuttle_hypothesis) is called a ‘theory’ because people question it because of that work
  - But it’s been proven
  - People were looking at lactate getting in the brain in response to physical activity even before he proposed the lactate shuttle
- Lactate is like [beta-hydroxybutyrate](https://en.wikipedia.org/wiki/Beta-Hydroxybutyric_acid), it’s a signaling molecule
  - Lactate activates [BDNF](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor) (like beta-hydroxybutyrate)
  - Lactate and beta-hydroxybutyrate go through the same transporter ([monocarboxylate transporter](https://en.wikipedia.org/wiki/Monocarboxylate_transporter), the [MCT1](https://en.wikipedia.org/wiki/Monocarboxylate_transporter_1) transporter) to get into the brain
    - MCTs are also those in mitochondria
  - There are a lot of similarities, the effects on [TBI](https://en.wikipedia.org/wiki/Traumatic_brain_injury)
- George Brooks did some [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4321351/) looking at victims of TBI, and giving them lactate improved their Glasgow rating scores
- Rhonda thinks there was some evidence about beta-hydroxybutyrate with TBI
  - She remembers [Dom](https://health.usf.edu/medicine/mpp/faculty/ddagosti) talking about that ([Found My Fitness episode #74](https://www.foundmyfitness.com/episodes/dominic-dagostino-2))
- It’s also interesting with respect to Alzheimer’s disease, there is some interesting [preliminary data](https://alz-journals.onlinelibrary.wiley.com/doi/10.1002/alz.12206) that giving beta-hydroxybutyrate (BHB) to people with Alzheimer’s disease can help improve their cognition
  - It’s similar with lactate

***As with lactate, you can make beta-hydroxybutyrate from exercise as well***

- You can push yourself into [ketosis](https://en.wikipedia.org/wiki/Ketosis)
- It would be interesting if there is synergy there, neurobiological effects of lactate and beta-hydroxybutyrate
  - Rhonda likes talking about it because she know scientists/ researchers/ physicians listen to this podcast, and it’s good to spread ideas (creativity)

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Rhonda Patrick**: [#02 – Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more](https://peterattiamd.com/rhondapatrick/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (July 2, 2018) | [0:45]

**Rhonda’s podcast**: [Found My Fitness episodes](https://www.foundmyfitness.com/episodes) | Rhonda Patrick (2023) | [1:00, 2:21:45]

**Rhonda’s podcast with Axel Montagne**: [#79 Axel Montagne, Ph.D. on Blood-Brain Barrier Dysfunction in Alzheimer’s Disease and Dementia](https://www.foundmyfitness.com/episodes/axel-montagne) | Host Rhonda Patrick, [Found My Fitness](https://www.foundmyfitness.com/episodes) (February 27, 2023) | [5:00]

**Biomarkers of blood-brain barrier permeability**:

- [Vascular dysfunction – the disregarded partner of Alzheimer’s disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6338083/) | *Alzheimers & Dementia* (M Sweeney et al. 2019) | [11:30]
- [Blood-brain barrier breakdown is an early biomarker of human cognitive dysfunction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6367058/) | *Nature Medicine* (D Nation et al. 2019) | [11:30]

**The blood-brain barrier is impaired in 50% of neurodegenerative disorders**: [Blood–brain barrier breakdown in Alzheimer’s disease and other neurodegenerative disorders](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5829048/) | *Nature Reviews Neurology* (M Sweeney, A Sagare, & B Zlokovic 2018) | [11:45]
**Increased fibrinogen in the cerebrospinal fluid of people with a leaky blood-brain barrier**: [Evidence that blood–CSF barrier transport, but not inflammatory biomarkers, change in migraine, while CSF sVCAM1 associates with migraine frequency and CSF fibrinogen](https://headachejournal.onlinelibrary.wiley.com/doi/10.1111/head.14088) | *Headache* (R Cowan et al. 2021) | [14:00]

**Rhonda’s review of omega-3 DHA brain transporter in Alzheimer’s disease**: [Role of phosphatidylcholine-DHA in preventing APOE4-associated Alzheimer’s disease](https://faseb.onlinelibrary.wiley.com/doi/full/10.1096/fj.201801412R) | *FASEB* (R Patrick 2018) | [19:45]

**Role of MFSD2A transporters in BBB integrity**: [MSFD2A is critical for the formation and function of the blood brain barrier](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4134871/) | *Nature* (A Ben-Zvi et al. 2014) | [20:00, 23:30]

**Expression of MFSD2a transporters decreases with age**: [Decreased Blood Level of MFSD2a as a Potential Biomarker of Alzheimer’s Disease](https://www.mdpi.com/1422-0067/21/1/70) | *International Journal of Molecular Sciences* (M Sanchez-Campillo et al. 2019) | [20:15]

**Deaths attributable to low omega-3 intake from fish**: [The Preventable Causes of Death in the United States: Comparative Risk Assessment of Dietary, Lifestyle, and Metabolic Risk Factors](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1000058) | *PLOS Medicine* (G Danaei et al. 2009) | [25:00]

**Omega-3 blunts effects of exposure to particulate air pollution**: [Cardiovascular Benefits of Fish-Oil Supplementation Against Fine Particulate Air Pollution in China](https://www.sciencedirect.com/science/article/pii/S0735109719338033?via%3Dihub) | *Journal of the American College of Cardiology* (Z Lin et al. 2019) | [28:45]

**EPA alleviates depression by regulating neuroinflammation in mice**: [Dietary EPA-Enriched Phospholipids Alleviate Chronic Stress and LPS-Induced Depression- and Anxiety-Like Behavior by Regulating Immunity and Neuroinflammation](https://pubmed.ncbi.nlm.nih.gov/34219360/) | *Molecular Nutrition & Food Research* (C Wang et al. 2021) | [29:00]

**RCT using EPA supplementation to treat depression**: [Omega-3 Fatty Acids for Major Depressive Disorder With High Inflammation: A Randomized Dose-Finding Clinical Trial](https://pubmed.ncbi.nlm.nih.gov/36005883/) | *The Journal of Clinical Psychiatry* (D Mischoulon et al. 2022) | [30:00]

**Previous episodes of** ***The Drive*** **with Iñigo San Millán**:

- [#85 – Iñigo San Millán, Ph.D.: Zone 2 Training and Metabolic Health](https://peterattiamd.com/inigosanmillan/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 23, 2019) | [54:45]
- [#201 – Deep dive back into Zone 2](https://peterattiamd.com/inigosanmillan2/) | Iñigo San-Millán, Ph.D. (Pt. 2) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (March 28, 2022) | [54:45]

**High-intensity exercise increases mitochondrial biogenesis**: [The Molecular Adaptive Responses of Skeletal Muscle to High-Intensity Exercise/Training and Hypoxia](https://www.mdpi.com/2076-3921/9/8/656) | *Antioxidants* (J Li et al, 2020) | [1:07:45]

**Sauna increases heat shock proteins**: [Effects of sauna bathing on stress-related genes expression in athletes and non-athletes](https://pubmed.ncbi.nlm.nih.gov/28378983/) | *Annuals of agricultural and environmental medicine* (M Zychowska et al. 2017) | [1:09:45]

**Tim Ferris’s podcast**: [The Tim Ferris Show](https://tim.blog/podcast/) | [1:10:15]

**Cardiorespiratory fitness reduces risk of dementia in women**: [Midlife cardiovascular fitness and dementia: A 44-year longitudinal population study in women](https://n.neurology.org/content/90/15/e1298) | *Neurology* (H Horder et al. 2018) | [1:16:00]

**Olympic athletes live longer than the general population and have a lower risk of cancer**: [Female and male US Olympic athletes live 5 years longer than their general population counterparts: a study of 8124 former US Olympians](https://pubmed.ncbi.nlm.nih.gov/32727712/) | *British Journal of Sports Medicine* (J Antero et al. 2021) | [1:22:45]

**French Olympic athletes live longer than the general population and have a lower risk of cancer**: [The heart of the matter: years-saved from cardiovascular and cancer deaths in an elite athlete cohort with over a century of follow-up](https://pubmed.ncbi.nlm.nih.gov/29730745/) | *European Journal of Epidemiology* (J Antero-Jacquemin et al. 2018) | [1:22:45]

**Breast cancer and colorectal cancer reduced in people who exercise**: [Physical Activity in Cancer Prevention and Survival: A Systematic Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6527123/) | *Medicine and Science in Sports and Exercise* (A McTiernan et al. 2019) | [1:27:45]

**Obesity increases the risk of 13 cancers**: [Obesity and cancer risk: Emerging biological mechanisms and perspectives](https://pubmed.ncbi.nlm.nih.gov/30445141/) | *Metabolism* (K Averinos et al. 2018) | [1:29:00]

**High shear stress of blood flow during exercise may kill circulating tumor cells**: [High Shear Stresses under Exercise Condition Destroy Circulating Tumor Cells in a Microfluidic System](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5215453/) | *Scientific Reports* (S Regmi, A Fu, \* K Qian Luo 2017) | [1:31:45]

**Exercise may reduce circulating tumor cells**: [Effects of exercise on circulating tumor cells among patients with resected stage I-III colon cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6192582/) | *PLOS ONE* (J Brown et al. 2018) | [1:31:45]

**Exercise reduces cancer metastasis and mortality**: [Effect of Exercise on Mortality and Recurrence in Patients With Cancer: A Systematic Review and Meta-Analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7273753/) | *Integrative Cancer Therapies* (S morishita et al. 2020) | [1:32:15]

**Moderate drinking raises lifetime risk of breast cancer to nearly 1 in 6**: [Alcohol consumption and site-specific cancer risk: a comprehensive dose–response meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4453639/) | *British Journal of Cancer* (V Bagnardi et al. 2015) | [1:37:15]

**Exercise may mitigate ill effects of poor sleep**: [Sleep and physical activity in relation to all-cause, cardiovascular disease and cancer mortality risk](https://pubmed.ncbi.nlm.nih.gov/34187783/) | *British Journal of Sports Medicine* (B Huang et al. 2022) | [1:44:45]

**Rhonda’s podcast with Stuart Phillips**: [#76 Stuart Phillips, PhD, on Building Muscle with Resistance Exercise and Reassessing Protein Intake](https://www.foundmyfitness.com/episodes/stuart-phillips) | Host Rhonda Patrick, [Found My Fitness](https://www.foundmyfitness.com/) (June 29, 2022) | [1:46:30]

**Episode of** ***The Drive*** **with Don Layman**: [#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.](https://peterattiamd.com/donlayman/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 26, 2022) | [1:51:00, 2:05:30]

**Episode of** ***The Drive*** **with Matt Kaeberlein**: [#222 ‒ How nutrition impacts longevity](https://peterattiamd.com/mattkaeberlein3/) | Matt Kaeberlein, Ph.D. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 12, 2022) | [1:53:15, 2:03:45]

***DAF-2*** **mutation in** ***C. elegans*** **doubles its lifespan**: [A *C. elegans* mutant that lives twice as long as wild type](https://pubmed.ncbi.nlm.nih.gov/8247153/) | *Nature* (C Kenyon et al. 1993) | [1:55:45]

**Neurobiological benefits of exercise**: [Neurobiological markers of exercise-related brain plasticity in older adults](https://www.sciencedirect.com/science/article/abs/pii/S0889159112004837) | *Brain, Behavior, and Immunity* (M Voss et al. 2013) | [2:00:00]

**Relationship between protein intake and IGF-1 levels**: [Low Protein Intake Is Associated with a Major Reduction in IGF-1, Cancer, and Overall Mortality in the 65 and Younger but Not Older Population](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(14)00062-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS155041311400062X%3Fshowall%3Dtrue) | *Cell Metabolism* (M Levine et al. 2014) | [2:01:30]

**Recent episode of** ***The Drive*** **with Andrew Huberman**: [#249 ‒ How the brain works, Andrew’s fascinating backstory, improving scientific literacy, and more | Andrew Huberman, Ph.D.](https://peterattiamd.com/andrewhuberman/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 3, 2023) | [2:22:00]

**Rhonda’s podcast with George Brooks**: #[2 Dr. George Brooks on Lactate Shuttle Theory, Relevance for Traumatic Brain Injury, & More](https://www.foundmyfitness.com/episodes/george-brooks) | Host Rhonda Patrick, Found My Fitness (December 3, 2014) | [2:22:30]

**Study on giving lactate to TBI patients**: [Cerebral metabolism following traumatic brain injury: new discoveries with implications for treatment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4321351/) | *Frontiers in Neuroscience* (G Brooks & N Martin 2015)| [2:23:45]

**Beta-hydroxybutyrate improves cognition in people with Alzheimer’s disease**: [A ketogenic drink improves cognition in mild cognitive impairment: Results of a 6-month RCT](https://alz-journals.onlinelibrary.wiley.com/doi/10.1002/alz.12206) | *Alzheimer’s & Dementia* (M Fortier et al. 2020) | [2:24:15]

§

## People Mentioned

- [Berislav Zlokovic](https://keck.usc.edu/faculty-search/berislav-v-zlokovic/) (Director of the Zilkha Neurogenetic Institute and Professor and Chair of the Department of Physiology & Neuroscience at the Keck School of Medicine of USC) [4:45, 11:45]
- [Axel Montagne](https://www.research.ed.ac.uk/en/persons/axel-montagne) (Chancellor’s Fellow, Deanery of Clinical Sciences at the University of Edinburgh Centre for Clinical Brain Sciences) [5:00, 11:45]
- [William (Bill) Harris](https://www.faresinst.org/our-team.html) (Founder of the Fatty Acid Research Institute, expert in omega-3 fatty acids) [24:00]
- [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) (Professor of Integrative Biology at the University of California, Berkeley) [50:45, 54:45]
- [Iñigo San Millán](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) (Professor in the school of Medicine at the University of Colorado – Colorado Springs, expert in exercise metabolism) [54:45, 2:23:00]
- [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) (most successful Olympic swimmer of all time) [1:06:45]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (won the Tour de France 7 consecutive times between 1999-2005) [1:06:45]
- [Tim Ferris](https://en.wikipedia.org/wiki/Tim_Ferriss) (entrepreneur, podcaster, author, lifestyle guru) [1:10:15]
- [Bruce Ames](https://www.bruceames.org/) (Professor of Biochemistry and Molecular biology Emeritus at the University of California, Berkeley) [1:24:00]
- [Stuart Phillips](https://www.science.mcmaster.ca/kinesiology/component/comprofiler/userprofile/phillis.html) (Professor in Kinesiology and Research Chair in Skeletal Muscle Health at McMaster University) [1:46:30, 1:51:00, 2:04:15]
- [Don Layman](https://fshn.illinois.edu/directory/dlayman) (Professor Emeritus of Food Science & Human Nutrition at the University of Illinois Urbana-Champaign) [1:51:00, 2:05:30]
- [Brad Schoenfeld](https://www.lehman.edu/academics/health-human-services-nursing/health-promotion-nutrition/fac-schoenfeld.php) (Professor of Exercise Science and Director of the Human Performance and Fitness program at Lehman College in the Bronx, New York) [1:51:00]
- [Matt Kaeberlein](https://kaeberlein.org/) (Professor of Pathology at the University of Washington, expert on aging) [1:53:15, 2:03:45]
- [Andrew Dillin](https://vcresearch.berkeley.edu/faculty/andrew-dillin) (Professor of Molecular & Cell Biology at the University of California, Berkeley; HHMI investigator; expert on aging) [1:57:15]
- [Cynthia Kanyon](https://profiles.ucsf.edu/cynthia.kenyon) (Emeritus Professor of Biochemistry and biophysics at the University of California, San Francisco; member of the National Academy of Sciences; expert in aging) [1:57:30]
- [Andrew Huberman](https://med.stanford.edu/profiles/andrew-huberman#bio) (Professor of Neurobiology and, by courtesy, of Psychiatry and Behavioral Sciences at Stanford University) [2:22:00]
- [Ronald Krauss](https://profiles.ucsf.edu/ronald.krauss) (Senior Scientist and Dolores Jordan Endowed Chair at Children’s Hospital Oakland Research Institute, Professor of Medicine at UCSF, and Adjunct Professor of Nutritional Sciences at UC Berkeley)  [2:22:30]
- [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) (Professor of Integrative Biology at UC Berkeley) [2:22:30]
- [Dominic D’Agostino](https://health.usf.edu/medicine/mpp/faculty/ddagosti) (Research scientist at the University of South Florida, ketosis expert) [2:24:00]

§

![](https://peterattiamd.com/wp-content/uploads/2023/04/bio-rhondapatrick2-500x500.png)

##### Rhonda Patrick, Ph.D.

Rhonda Patrick earned her BS in biochemistry/ chemistry from the University of California, San diego. She earned her PhD in biomedical science at the University of Tennessee Health Science Center, St. Jude Children’s Research Hospital. In her graduate work she investigated the link between mitochondrial metabolism, apoptosis, and cancer. She discovered a protein critical for cell survival which has two distinct mitochondrial locations with disparate functions. Her work linked the role of this protein in inhibiting apoptosis to a previously unrecognized role in mitochondrial respiration and maintenance of mitochondrial structure. Her dissertation findings were published in the 2012 issue of [*Nature Cell Biology*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3401947/).

Dr. Patrick did her postdoctoral training at Children’s Hospital Oakland Research Institute with Dr. Bruce Ames where she investigated the effects of micronutrient inadequacies on metabolism, inflammation, DNA damaging, and aging. She investigated whether supplementation can reverse such damage. Additionally, she studied the role of vitamin D in brain function, behavior, and other physiological functions.

Dr. Patrick. also spent time at the Salk Institute for Biological Sciences where she investigated the role of insulin signaling in protein misfolding, a common characteristic of neurodegenerative disease. In 2012, she co-founded [FoundMyFitness Science Podcast](https://www.foundmyfitness.com/episodes) with the goal of encouraging the public to think about health and longevity using a proactive, preventative approach. [[FoundMyFitness](https://www.foundmyfitness.com/about-dr-rhonda-patrick)]

Twitter: [@foundmyfitness](https://twitter.com/foundmyfitness)

Instagram: [@foundmyfitness](https://www.instagram.com/foundmyfitness/?hl=en)

Facebook: [FoundMyFitness](https://www.facebook.com/foundmyfitness/)

YouTube channel: [FoundMyFitness](https://www.youtube.com/user/FoundMyFitness)

Rhonda’s podcast: [FoundMyFitness](https://www.foundmyfitness.com/episodes)

Rhonda’s website: [FoundMyFitness](https://www.foundmyfitness.com/)