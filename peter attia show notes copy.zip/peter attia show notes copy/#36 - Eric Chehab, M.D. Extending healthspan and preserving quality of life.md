# #36 – Eric Chehab, M.D.: Extending healthspan and preserving quality of life

**Source:** [https://peterattiamd.com/ericchehab/](https://peterattiamd.com/ericchehab/)

---

In this episode, Dr. Eric Chehab, orthopedic surgeon and sports medicine specialist, explains the measures we can take to live better and maintain our physical health through exercise and the avoidance of common injuries that prove to be the downfall for many. He also provides valuable insight for those weighing their treatment options from physical therapy to surgery to stem cells.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ericchehab/the_Drive_public.png)

Play

#36 - Eric Chehab, M.D.: Extending healthspan and preserving quality of life

#36 - Eric Chehab, M.D.: Extending healthspan and preserving quality of life

1x15s30s

0:002:38:31

## We discuss:

- Favorite bands, musicians, and concerts [3:30];
- Eric’s upbringing, biggest influences, college life, and teaching overseas [12:45];
- Eric’s training, fellowship with the New York Giants, and the risk vs. reward of playing football [39:15];
- The knee joint: common injuries, knee replacements, and proper exercise [1:00:00];
- Best exercise for orthopedic health and bone density [1:10:00];
- Most common injuries: knee, hip, shoulder, elbow, ankle, foot [1:20:45];
- Physical therapy vs. surgery, and the meniscus surgery controversy [1:28:30];
- PRP, stem cells, sham surgeries, and the placebo effect [1:41:00];
- Back injuries: when does surgery make sense? [1:54:15];
- How to find the right orthopedic surgeon for you [2:01:45];
- How to cope with complications and maintain quality of life through adaptation [2:09:15];
- Dr. Bukk Teef [2:26:45]; and
- More.

§

## Show Notes

## Favorite bands, musicians, and concerts [3:30]

[Bruce Springsteen](https://en.wikipedia.org/wiki/Bruce_Springsteen)

- Eric’s favorite singer
- Been to numerous concerts
- Saw Bruce in ’84 at [Brendan Byrne in New Jersey](https://en.wikipedia.org/wiki/Brendan_Byrne_Arena,_New_Jersey_1984), he was kicking off the [Born in the USA](https://en.wikipedia.org/wiki/Born_in_the_U.S.A.) tour
- Saw him play in the soccer stadium in Verona, Italy on Easter Sunday
- Saw him the [Tenth Avenue Freeze-Out at Wrigley Field](https://www.youtube.com/watch?v=aKQskkbHfPc) for the tribute to [Clarence Clemons](https://en.wikipedia.org/wiki/Clarence_Clemons)

[Tom Morello](https://en.wikipedia.org/wiki/Tom_Morello)

- Peter’s twin
- Peter’s son Reese refuses to believe that Tom Morello isn’t actually his  daddy, “why do you know how to play the guitar, but you never play at home?”
- Watch [Bruce and “Peter” play at Madison Square Garden](https://www.youtube.com/watch?v=n-mq0uJ7rlM) where “Peter”/Tom Morello plays a [three-minute guitar solo](https://youtu.be/n-mq0uJ7rlM?t=397) at the end that is out of control

![](https://peterattiamd.com/wp-content/uploads/2019/01/Screen-Shot-2019-01-11-at-11.43.47-AM.png)

**Figure 1. “Peter” playing guitar with Springsteen.** Image credit: [YouTube: Zarastro1040](https://www.youtube.com/watch?v=n-mq0uJ7rlM&feature=youtu.be&t=397)

[Pearl Jam](https://en.wikipedia.org/wiki/Pearl_Jam)

- One of Peter’s favorites
- Peter almost caught a [Mike McCready](https://en.wikipedia.org/wiki/Mike_McCready) guitar pick once in D.C.

Eric sang at Peter’s wedding

- He sang the song [Fire](https://en.wikipedia.org/wiki/Fire_(Bruce_Springsteen_song)), written by Bruce Springsteen
- While wearing [Dr. Bukk teeth](https://www.drbukk.com/en/) (more to come later)
- Eric has a little [Dan Finnerty](https://en.wikipedia.org/wiki/Dan_Finnerty) in him

## Eric’s upbringing, biggest influences, college life, and teaching overseas [12:45]

- Attended undergrad at a “little school back east” aka Harvard
- Exposed to medicine growing up (mom was a nurse, father was a physician in Lebanon)
- After college, taught high school chemistry and physics for 3 years split between Milan, the US, and then Bulgaria
- “Teaching was a great experience. It was a great way to see the world. It was a great way to learn how to become an adult . . . so that time off between college and medical school, for me, was invaluable in terms of maturation.”

![](https://peterattiamd.com/wp-content/uploads/2019/01/unnamed.jpg)

**Figure 2. Little School Back East t-shirt.**

Med school at Stanford

- Fun Fact: When Eric was a med student at Stanford, he was actually Peter’s “student interview” when Peter was applying to Stanford
- Considered both internal medicine and orthopedics (an unusual 2 paths to consider) but decided ortho at the last minute
- Are all orthopedics dumb jocks?
- “It’s a definite stereotype. [Many] guys in orthopedics are athletes or had been athletes at one point. But it’s a pretty thoughtful specialty. It’s not simply bone broke, me fix, and that’s that. And I’m really glad I made the decision I did.”

Who is Bill?

- Bill was a neighbor that became a friend and father-figure of Eric (Eric had no relationship with his biological dad until age 16)
- Bill’s influence on Eric was so great that he was the subject of Eric’s essay in his med school application
- Bill’s health began to fail in his late 70s, so Eric chose to do his training in New York so that I could be closer to Bill
- Bill needed a CABG (Coronary artery bypass graft) which is a bypass surgery of the heart

Bill’s late-life injury

- Bill fell and broke his hip, a **late-in-life injury** that proved to be his downfall
- After this he was scared of falling again and became weak
- Came down with HEC (liver cancer), a cellular carcinoma
- Died shortly thereafter

Eric’s biological father

- His parents divorced and father moved to Lebanon when Eric was 3, didn’t hear from again until he was 16
- His dad is an OB/GYN, currently living in Spain
- He lived through a war (in Lebanon) and suffers from PTSD having to treat many war victims
- Actually trained at Johns Hopkins in the US as a foreign medical grad
- Eric not very interested in a relationship with his dad at this point in life
- After becoming a doctor, and having 4 kids, he left his family for Beirut, Lebanon
- Eric has a hard time understanding this decision

Peter’s take on the consequences of a bad decision

- Peter is more and more empathetic to sort of the situations people are in based on an initial bad decision
- “You start to realize that there are other bits of baggage that people are carrying with them that, you know, you can make a wrong decision in a moment.”
- “ Two people can make the same sort of wrong decision, but one comes with far greater consequences.”
- See episode of [The Drive with Corey McCarthy](https://peterattiamd.com/coreymccarthy/) for more about how a few bad decisions can derail your life

Eric’s disastrous (and hilarious) first date with his now current wife

- Eric canceled dinner to feed his friend some ham
- They instead met at a dive bar called [The Dutch Goose](https://www.dutchgoose.net/) (also the first place Peter ever ate at Stanford)
- Eric had bad gas on the date
- Drove her home in his clunker of car (1983 Honda Civic sem-station wagon)
- After asking if he could kiss her, they had a super awkward kiss
- On his way home, Eric felt so bad about the date that he turned the car around to go back and tell Lynn how he felt
- She opened the door and he said, “I think you’re hot as shit”
- Somehow, it all worked out after that

## Eric’s training, fellowship with the New York Giants, and the risk vs. reward of playing football [39:15]

Trained at HHS – [Hospital for Special Surgery](https://www.hss.edu/) in NY

- Best ortho place in the world
- Some of the giants in the field of joint replacement, Chip Ranawat, Tom Scocca, Philip Wilson
- Every field within every subspecialty within orthopedics, HSS had a major player in that field
- Patients come from all over the tri-state area to get their orthopedic work done at special surgery
- The ethic of the place was you just took care of people

Eric’s mentors

- [Russ Warren](https://www.hss.edu/physicians_warren-russell.asp), godfather of sports med, current physician for the NY Giants
  - earlier developers of ACL reconstruction, and he was a pioneer in arthroscopy and arthroscopic reconstruction.
  - Always working, if not surgery, reading and writing research papers
  - “All I’ve got is time, and I’m not wasting it for anybody.”
- [Paul Pellicci](https://www.hss.edu/physicians_pellicci-paul.asp), he’s a joint replacement surgeon
  - Was the most gifted joint replacement surgeon I’ve ever seen
  - He could do a total hip replacement in 45 minutes to an hour.
- [Tom Wickiewicz](https://www.hss.edu/physicians_wickiewicz-thomas.asp), who was the director of Eric’s fellowship
- [Scott Rodeo](https://www.hss.edu/physicians_rodeo-scott.asp), who’s the head team physician for the NY Giants now, who’s a phenomenal research clinician

Eric’s fellowship with NY Giants

- Crash course in sports medicine: “you’re really seeing the finest tuned machines under the greatest destructive forces”
- “The first thing you do realize is that these guys are freak athletes. . .they’re so physically gifted it is beyond belief.
- Razor thin margin between guys at the very top of the league vs the guys who are trying to just make the team
- Peter’s friend [Ryan Flaherty](https://ryanjflaherty.com/) trains NFL players and says the players *focus in training* switches from:
  - Peak performance (such as when trying to make the team) to…
  - Longevity and avoiding injury because it’s such a violent game
- “These guys are under a tremendous amount of stress to just perform, keep their job, not get hurt, and it’s an intensely difficult situation,” says Eric

Injuries from playing football

- Prevalence of injury in football is great
- Median tenure only 3-4 years for NFL players
- “These guys leak oil, and they leak oil relatively quickly because of the violence of the game.”
- Even the best, young players showing up at the NFL combine have a list of injuries and previous surgeries
- “They’re all injured because they’re the best guys coming through, and they play.”

Weighing the pros and cons of playing football

- Eric’s youngest son plays high school football
- Does he worry? Of course
- But he’s getting so much out of it
- Eric references the [Curtis Martin Hall of Fame speech](https://www.youtube.com/watch?v=eCYpF1OsklA)
- The punchline of the speech: “You have to weigh the pros and cons for your own kid and decide whether or not it’s worth it, but if football can do for your kid what it did for me, there’s no question that I’d let you play.”
- For Eric and his wife, Lynn, they are worried sick during every game, but “being fully aware of the risks in playing because in the end, we felt the benefits outweighed the risks.”

## The knee joint: common injuries, knee replacements, and proper exercise [1:00:00]

- *What is the knee best at?* ⇒ Good at bearing weight
- *If Eric could magically change one thing about the knee joint, what would it be?* ⇒ “I would make the cartilage immortal because the cartilage wearing down in the knee is fundamentally what will slow people down.”
- Why save the cartilage over the ligaments (i.e., ACL)?
- The cartilage wearing down is what gives people the most pain
- And it’s possible to live without an ACL (Eric tore his ACL at 12 and never had it fixed) however, an unfixed ACL will lead to instability which ultimately causes wearing down of cartilage
- And once the hard cartilage starts going, the knee pain is real, knee swelling, and you have limitations in your mobility

![](https://peterattiamd.com/wp-content/uploads/2019/01/knee-joint-anatomy-guide.jpg.pagespeed.ce_.v53jgpR8v2.jpg)

**Figure 3. Knee Joint Anatomy.** Image credit: [knee-pain-explained.com](https://www.knee-pain-explained.com/knee-joint-anatomy.html)

- The tibia has a plateau where the cartilage sits
- And then the other end of the joint is the sort of bottom end, or the distal end of the femur which is kind of roundish
- It has two condyles which looks like two knuckles almost

MCL

- The medial collateral ligament is on the inside zone of the knee
- A ligament that we consider extra-articular
- It’s outside the joint capsule
- A very stout ligament that controls the knee from swaying side to side
- So if you can imagine, your tibia swaying out towards your hip, or back towards your other foot, the MCL controls that

LCL

- The lateral collateral ligament is on the other side of the knee
- On the outside zone of the knee
- It has the same function as the MCL but just in the opposite direction

ACL (and PCL)

- The cruciate ligaments are crossing ligaments that are directly in the center of the knee
- ACL is crucial for rotational control of the knee.
- When people tear their ACL, it’s usually a rotational injury that does it, and it’s almost a near dislocation of the knee that occurs

Why does the ACL tear more than PCL?

- PCL is a direct blow injury from falling specifically on the tibial tubercle and it’s not easy to do that
- But people do very well with a full PCL tear as long as they don’t have any other ligament injury to the knee… it doesn’t have the same rotational implications

![](https://peterattiamd.com/wp-content/uploads/2019/01/meniscus.jpg)

**Figure 4. Menisci and cartilage.** Image credit: [orthoinfo.aaos.org](https://orthoinfo.aaos.org/en/diseases--conditions/discoid-meniscus)

**The menisci (plural of meniscus)**

- The menisci sit on top of the plateau and they basically contour the flattish plateau into a more rounded femur
- It allows for the contact pressures within the knee to be distributed more evenly
- They’re critical tissue structures as it turns out and it’s become very clear that losing the meniscus is the beginning of the end for most people’s knees once they start having meniscal tears

⇒ A knee replacement ([cool video of the procedure here](https://www.webmd.com/osteoarthritis/knee-replacement-18/video-inside-look-knee-replacement)) even has a curvature built into the top of the tibial piece to mimic the meniscus

- - This is critical because completely losing that meniscus will lead to swelling and pain and difficulty walking and feelings of instability, and all the things that slow people down as they’re trying to live a long life
- *“That’s where their healthspan and their lifespan starts separating”*

⇒ When will you lose your hard cartilage?

- Everyone is going to lose their hard cartilage. . .it’s a matter of when
- Things that influence the loss of cartilage:
- Genetics
- exposure to injury
- Trauma
- But also things that are *modifiable*: your weight and exercise

How long does a knee replacement last?

- Knee replaces due fail over time because of loosening of the prosthetic from the bone due to things like particulate wear, causing inflammation, leading to a cascade that eventually results in failure of the knee
- And unfortunately, the second knee replacement doesn’t work as well as the first
- Hard to predict the life of a knee replacement because of so many variables
- The younger a patient is, the more active they’ll be and the more likely they will loosen at an earlier age
- So for the people who need the knee replacements the longest, people in their 40s and 50s, will have the shortest life span of the knee
- But it’s a significant difference in longevity for the 50-year-old getting a knee replacement than the 65-year-old
- Doctors tend to try to push back the knee replacement surgery until it is absolutely necessary

What can you modify to push back the need for a knee placement?

- #1 is body weight
- Every pound of weight loss. . . is four pounds of weight loss to the knee with just walking, six pounds for climbing stairs, and eight pounds for running
- Eric has developed a program at his practice called Ortho Health to help patients with these modifiable factors for their knee, in particular, their weight
- It’s designed to help patients sleep better, trying to help them manage their stress better, trying to help them eat better, and try to help them exercise more efficiently

## Best exercise for orthopedic health and bone density [1:10:00]

Common mistakes Eric witnesses with exercise

- People  exercise way too much
- People think it’s all about burning all the calories, as opposed to activating their metabolism

Exercise for bone density

- Is running hard on the knee? ⇒ Yes, but… the body does react to this, says Eric
- [Wolff’s law](https://en.wikipedia.org/wiki/Wolff%27s_law) says the body reacts to stress, so the more stress that’s on it, the more bone that’s laid down for it
- That’s why Eric does emphasize weight-bearing exercise for patients in their 30s, in particular, before they start losing bone, so that they can build up their bone density
- When do we lose ability to build bone density?
- Around 30
- After 30, weight-bearing exercise is about *slowing down* the bone loss

What is driving the bone loss after 30?

- No clue, says Eric
- Osteoclastic is the breaking down of bone
- Osteoblastic is the building up of bone
- Pharmacologically, there are drugs to help slow down bone loss such as [Fosamax](https://www.webmd.com/drugs/2/drug-1273-7174/fosamax-oral/alendronate-oral/details) and [Boniva](https://www.rxlist.com/boniva-drug.htm)
- But it’s not necessarily *building* great bone
- It may be building denser bone, but there are concerns that there may be fault lines in the bone so you see tension sided failure of bone with the long use of [bisphosphonates](https://en.wikipedia.org/wiki/Bisphosphonate) (Those are some of the atypical femur fractures that you see, people get foot fractures with this)

Anything in the pipeline to build bone better?

- Currently, most of it is focused on osteoclastic inhibition, and there are thoughts about bumping up osteoblastic production with magnetic fields and that’s what’s the technology behind bone stimulators for when patients have hard to heal fractures
- Can you just use a bone stimulator?
- Yes but always concern that when you stimulate the osteoblasts, that you may be provoking a cancer
- Eric completely avoids using bone stimulators in patients with cancer to avoid stimulating out of control growth

**Exercise**

People exercise incorrectly, leading to repetitive/strain type injuries

Why? ⇒ 2 main reasons

1. There seems to be such an emphasis on volume of exercise
2. **BAD FORM:** They do too much repetition with poor form is exposing themselves to injury.

- - “There’s no question that repetitive bad form will lead to injury.”
  - *Especially under load*

Is walking enough?

- Eric says walking is good and safe, cites [Harvard School of Public Health,](https://en.wikipedia.org/wiki/Harvard_T.H._Chan_School_of_Public_Health) has done an awful lot of work at looking at walking and cardiovascular risk, and near 30 to 40% risk reduction with walking
- Peter pushes back, “you won’t find many people that are more critical of the Harvard School of Public Health…there may be too many healthy user biases within those studies”
- Peter’s hypothesis about the association with walking and better health
- “The less time you are sitting around, the better, and I think in part it’s not just the benefit you get from walking around, it’s the damage that’s done by shortening the hamstrings, by tightening the psoas and the hip flexors. That stuff starts to translate into these other things that set you up for orthopedic failure when you actually are doing your one hour of activity, or whatever it is.”

**What is the right kind of exercise?**

*⇒ Eric:* Consistent movement is what leads to better orthopedic musculoskeletal health, and it’s not necessarily having to do an hour of exercise a day, I think it’s more generalized movement for the majority of hours of the day

*⇒ Peter:* “The way I think about exercise. . .there’s a Venn diagram, but there are certain exercises that we are doing where the emphasis is on the exoskeleton, so maintaining muscle mass, maintaining functional movement, maintaining bone density, and doing so free of pain. . .

. . .Then there are some aspects of exercises you alluded to where really what we’re doing is talking about physiologic benefits. . .about what it’s doing to the microvasculature, what’s it’s potentially doing to the mitochondria, what it’s doing with other hormones, for example, BDNF, and the role that that plays in the brain. . .

. . .I think you can make a pretty compelling case that there is no intervention that has shown a larger impact in mitigating cognitive decline than exercise…and all avenues seem to flow through BDNF and increase microvascular composure”

There are two main goals with exercise:

- - 1) Exercise to reduce the risk of disease
  - 2) Exercise to increase health span

- **Sweetspot is when they overlap**

![](https://peterattiamd.com/wp-content/uploads/2019/01/Screen-Shot-2019-01-11-at-12.13.12-PM.png)

**Figure 5. The sweet spot of exercise.**

So, what is the best exercise?

- Hard to say bc so many other variables (genetics, sleep quality and nutrition, etc.)
- Eric: But I do give the advice to patients, because I see a lot of injuries from people trying to overdo it, that I mean, it really is important to start in increments when you’re just stating.
- “Rule number one of exercise is you can’t get injured.” says Peter

## Most common injuries: knee, hip, shoulder, elbow, ankle, foot [1:20:45]

Most common injury Eric sees? ⇒ Knee pain and swelling from excessive squats and lunges

- Peter says lunge form is a bit counterintuitive, “the front knee should be under no load. The front leg should be all glute based loaded. “
- “They come in with an overloaded knee, anterior knee pain from not using their glutes, from overly relying on their quadriceps.”

Eric’s take on weight training safely:

⇒ “The ultimate weight training would be to activate the muscle without loading the joint. You can do that, you can activate the muscle and not load the joint when you use very light weights, but enough weight that that muscle gets challenged. Just even the most minor degree. Because once it’s challenged, you can then [voluntarily] overflex that muscle. So you need just enough weight to initiate the muscle activation and contraction, and that’s usually not very much at all. Then the joint is not being loaded, the muscle is being activated, and you’re getting a much safer workout.”

Shoulder injuries

- Mostly over the plane of the neck?
- I think so. Pushing overloads joints more so… When patients are recovering from shoulder injuries or have sustained a shoulder injury, my generic advice, sort of take home advice is, “Try and emphasize more the pulls than the presses as you’re recovering.”

**What are the most common injuries for…**

*Elbows and wrists:*

- Elbows and wrists are typically [tendinopathies](https://en.wikipedia.org/wiki/Tendinopathy)
- Why? ⇒ Could happen because of inflammatory changes, or just biologic and age related changes, blood flow related changes
- The elbow in the 40s and 50s, I see endless  [epicondylitis](https://en.wikipedia.org/wiki/Epicondylitis), which is tendinitis around the forearm muscles that flex your wrist and straighten your hand, or bend your wrist and curl your hand.
- Those tendinopathies, whether they occur in the wrist, the shoulder, the elbow, the knee, the ankle, I’m absolutely certain have the same biologic mechanism
- I don’t consider elbow lateral epicondylitis or tennis elbow, golfer’s elbow, that much different from shoulder tendonitis or impingement, or that much different from patellar tendinitis, or Achilles tendinitis.
- The common pathway is probably loss of microvasculature to the tendons

*Ankle and foot:*

- For the ankles, the Achilles tendon is the key
- With the foot, the most common sort of acquired problem is [posterior tibial tendon deficiency](https://orthoinfo.aaos.org/en/diseases--conditions/posterior-tibial-tendon-dysfunction/), where there’s attenuation and stretch of the tendon that supports the arch, and over time, that just starts getting stretched out
  - it’s a mechanical issue, and unless it can keep itself in prime shape, it’s going to stretch out over time, just due to the forces that it’s under.
  - Ways to fix it?
  - 1) Orthotics can help
  - 2) Reconstruction surgery: very invasive and you’re non weight bearing for six weeks strictly, and then gradually weight bearing. So you’re taking a big chunk out of your life, and you’re definitely knocking yourself down to build yourself back up again.

*Hip:*

- A simple ball and socket joint that tends to just wear down over time
- It tends to just wear down and that labral cartilage, which is the soft cartilage of the hip, can get frayed, but it’s the articular cartilage that really makes a difference (like the hard cartilage in the knee)
- [Femoroacetabular impingement](https://en.wikipedia.org/wiki/Femoroacetabular_impingement) is a condition which can be improved by reshaping the hip which can make a difference in terms of long term outcomes of those patients by reshaping the hip to some degree

*Labral tears in hip:*

- Everyone has some labral tearing in everyone (~90%)
- This makes it a challenge for doctors because hard to tell if surgery will help since they don’t know if the tear is the source of the hip pain
- Peter on labral tears: “It strikes me as one of those things that’s a little bit like lumbar disk herniation, where someone can have hip pain. You do an MRI, they’ve got a labral tear. You’re no further ahead than you were before. You don’t know if that’s the cause [of the pain]”

## Physical therapy vs. surgery, and the meniscus surgery controversy [1:28:30]

Meniscus injuries

- Nearly everyone will show some meniscus injury in an MRI so this finding isn’t very meaningful
- Who should consider surgery?
- If a meniscus issue is suspected, first thing is to give it time to see if the pain dissipates
- You can also try some physical therapy
- If pain persists, then those people will typically benefit a lot from a procedure

Surgery vs physical therapy for meniscus tear

⇒ Important paper: [Surgery versus physical therapy for a meniscal tear](https://www.ncbi.nlm.nih.gov/pubmed/23506518)

- The finding was misinterpreted by many people that there’s no difference in outcome between PT and surgery
- Gina Kolata, for example, wrote a piece that basically said, “Hey, it doesn’t matter whether you do surgery or therapy, so why are we doing surgery at all? We should just do therapy for everybody.”
- But it turns out in one of the arms of the physical therapy group, there was a crossover to surgery for those patients who weren’t getting better, but it was an intention to treat model, so they were still counted
- So the take home message of the study was NOT, “Hey, it doesn’t matter if you do therapy or surgery, you’ll end up in the same place.”
- The take home should have been “It’s reasonable to try both. To start with physical therapy and start conservatively, but there are some set of patients that will benefit from crossing over [and getting a scope]”
- How long a period of time do you want to give them on the conservative approach
- “A month or two… but… if they start feeling better they will try to ride it out more or less”

Scoping for dollars?

- Are there doctors out there that are “scoping for dollars”? ⇒ “None of us like to think we’re the ones doing it, but the fact of the matter is that it has to happen [sometimes]”
- The data is pretty clear that someone walking in your office with a degenerative meniscus tear probably shouldn’t be scoped as a first line of treatment
- It may not always be a malicious or greedy intent, it might be a subconscious decision based on outside factors
- Peter uses an example in his practice where he could choose to sell drugs but doesn’t fully trust himself to be completely unbiased if one drug makes him more money (so he chose not to sell drugs)
- “The fact of the matter is most, if not the highest percentage of doctors are really looking out for the best interest of their patient. But they’re human. . .and they may be influenced by other factors that have nothing to do with the best interest of their patient”

*Peter’s advice:*

⇒ Don’t just talk to a surgeon, try to meet with a nonoperative sports medicine doc as well

*⇒ Look for the true origin of pain*

- Peter’s labral injury in his shoulder.  . .
- Years of swimming marathons, his shoulder was getting worse and worse
- Weeks away from surgery
- But his body work guy convinced him that the pain he was feeling is most likely not the tear itself but due to the fact that the labral tear caused him to move differently, and over the past four years, changed the way  he used his arm, and now it’s actually in his tricep, deltoid, subscapularis and infraspinatus
- In 3 months, Peter was back to 80% of baseline
- And today, close to 100% with no limitations
- Peter had a similar experience using PT to fix an [IT band](https://en.wikipedia.org/wiki/Iliotibial_tract) situation those arose during his biking

## PRP, stem cells, sham surgeries, and the placebo effect [1:41:00]

**What is** [**platelet-rich-plasma**](https://en.wikipedia.org/wiki/Platelet-rich_plasma) **(PRP)?**

- Take some blood from you, put that tube of blood into a centrifuge to separate out the platelet-rich plasma and inject it into a knee, a shoulder, a tendon for healing purposes
- The idea is that the platelets are rich in healing factors, and [VEGF](https://en.wikipedia.org/wiki/Vascular_endothelial_growth_factor), growth factors that would promote growth and accelerate healing

The [studies about PRP](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5687544/) are somewhat imperfect

- So many different types of preparation, one PRP injection isn’t equivalent to another
- It doesn’t seem to be regrowing articular cartilage when you inject it into a knee or a shoulder or an ankle or a hip
- It *may* be helping to stimulate tendon injury, but that’s a very hard endpoint to measure
- It might be getting better in the tendon because of the PRP injection itself  or…
  - it might be because there’s a placebo effect
  - Or it might be because you’re resting
- Again, you don’t really know the answer why
- Tested against what in the studies? ⇒ Either saline (placebo), or cortisone, or an intra-articular injection with the viscosupplements, the hyaluronic acid injections

Main issue with PRP studies

- PRP studies are too heterogeneous, not only in the different preparations in it but patient populations
- Because in medicine, it all comes down to the more homogeneous the population you can treat in the study, the better your outcomes are going to be
- We’re probably at a 3 out 10 in our understanding of PRP, very early on

**For more on PRP see a previous [episode of The Drive with Brett Kotlus](https://peterattiamd.com/brettkotlus/)**

**Stem cells**

- The big issue: we don’t know *why* it works for the people who it does work
- But it’s pretty clear that it is not working by regrowing cartilage
- It might be working as an anti inflammatory or as a placebo

Stem cells for arthritis

- Stem cells have some promise for arthritis
- But some doctors are taking advantage of this perception that stem cells can cure arthritis and pushing it hard on their patients
- We do have some ways of *managing* arthritis, maybe *slowing down* the pace of worsening arthritis, but we do NOT have anything that reverses the course of arthritis (i.e. turn an older knee into a younger knee)

Stem cell literature

- Stem cells have promise, but the literature is unclear *how much benefit and why*
- Doctors can charge thousands for one injection of stem cells (“Talk about incentives”)
- After injections, there are some reports that patients feel better, but…
- Are they feeling better because of the placebo effect?
- Are they feeling better because there’s an antiinflammatory effect?
- You might be able to get this same benefit from a $25 cortisone shot
- Animals vs humans
- The studies that showed some benefit in rats and small animals, it’s about 10 to 20 million
- In human injections, it’s only a couple hundred
- We are “orders of magnitude off”
- Randomized trials for stem cells going on?
- Yes, and most of the time they show *some* clinical subjective benefit, but not a single radiograph or MRI showing reconstituted cartilage

Risk vs reward of stem cells

- Risk of physical harm (probably not much)
- Rick of financial harm (very expensive so depends on the person’s financial situation)
- Reward of procedure (possible benefit, unproven, and we don’t know why it works when it does, but it is definitely not “regrowing” cartilage)

**Placebo effects and sham surgeries**

- The larger a procedure, the bigger the placebo effect
- On average, there is typically a 15% placebo effect with procedures, meaning patients may feel 15% better simply because they had surgery

*Shoulder decompression procedure vs sham surgery*

- There is a common procedure to relieve shoulder pain (from tendinitis and impingement) called [subacromial decompression](https://www.bupa.co.uk/health-information/muscles-bones-joints/subacromial-decompression)
- The results from this surgery are pretty good in most cases
- A [recent paper](https://www.bmj.com/content/362/bmj.k2860) looked at subacromial decompression vs a [sham procedure](https://en.wikipedia.org/wiki/Sham_surgery):
  - The results were the same between a sham surgery and the decompression
  - So is the decompression procedure worthless?
  - Perhaps, except that *both groups got better*

Should sham surgeries be offered?

- The problem is if you tell the patient it is a sham surgery, you might lose the benefit
- How much of the benefits of sham surgery are the post op stuff like physical therapy and rest?
- Because people generally take rest and PT much more seriously when after surgery
- Eric: “But then so I will say that the patients sometimes with meniscal injuries, ‘Hey, let’s cut out the middle man. It’s probably the rest and the therapy that’s helping you, so why don’t we do that?’”
- But you are also withdrawing the placebo effect of the procedure, or what seems to be a placebo effect.

**To further explore the placebo effect, start with Peter’s [weekly email](https://us15.campaign-archive.com/?u=21bc5f75235505c27ce465f90&id=1ce39b914d) on this topic**

## Back injuries: when does surgery make sense? [1:54:15]

*“Back pain is the number one reason people go to the doctor. Not the orthopedist, but the doctor.”*

**Peter’s back injury and surgery**

- Peter had a devastating back injury during med school ([listen to Peter tell the story here](https://www.youtube.com/watch?v=LB4wRxRROfA&feature=youtu.be&t=870))
- L5-S1 free fragment stuck in the canal
- Complicating the situation, the surgeon *operated on the wrong side*
- Doc did a right-sided decompression, and dinged the right-sided nerve, leaving Peter with a so I came out with a right-sided foot drop (even though I went in with a left-sided injury)
- Peter needed several re-do surgeries
- Peter basically spent a year of life recovering, three months of which he was debilitated
- Still partially traumatized, but “it was the best worst thing that ever happened to me”
- *Worst thing because*. . . the sheer pain, a year of being hooked on opiates, and all this other crap that comes with it
- *Best thing because*. . . it hurt for so long that learned how to redo everything that you wouldn’t be able to relearn if you only had two weeks or a month of pain, never really had a back issue ever since
- He learned how to do all [ADL](https://en.wikipedia.org/wiki/Activities_of_daily_living) in the most protective way possible
  - Sneezing
  - Brushing teeth
  - Bending down to pick things up
- When people hurt their back “it’s usually the tiniest insult that does it. It’s not always the. . .400 pound deadlift”

**Should you consider back surgery?**

- Peter NOT convinced that surgery is the way to go
- Of course, there are some [spinal stenosis](https://en.wikipedia.org/wiki/Spinal_stenosis) cases that surgery is life-changing immediately following the operation. . .
- However, more often than not, Peter says, patients probably would get better without doing a [lumbar discectomy](https://www.mayfieldclinic.com/PE-LumDiscectomy.htm) (for example)
- “We see some of the very poor outcomes that can happen with spine surgery, and the difficulty that people can have with it, and lower back pain is ubiquitous.”

What is causing back pain? ⇒ Usually it’s either a mechanical issue or a slipped disc (the majority of which will resolve with time)

**When is surgery the best option?**

- When patients have neurologic compromise and weakness (especially cervical)
- Because it can affect people’s balance, people’s ability to walk, not just their hands
- Example, Eric’s friend had a massive disc herniation combined with [myelomalacia](https://en.wikipedia.org/wiki/Myelomalacia), which means that he’s getting an injury to his spinal cord and will lose neurologic function in short order
- He underwent a successful [cervical decompression infusion](https://en.wikipedia.org/wiki/Spinal_fusion)
- “Those type of spine surgeries are life altering and life saving.”

**Asymmetric risk and back surgery**

- Eric said Peter introduced him to the concept of asymmetric risk (Peter describes this starting at 1:58:00 in this [Tim Ferriss podcast episode](https://tim.blog/2016/10/20/my-life-extension-pilgrimage-to-easter-island/))
- Outside of emergency situations, back surgery is often a bad idea
- Example,
  - A person is functioning at 70%
  - They get a dramatic spine operation
  - That person *could* go from 70% to 90% or. . .
  - They could also go from 70% to 20%
  - And when things go awry in your spine, things go awry for your entire body

**The great thing about joint replacement**

*“It’s why I think joint replacement is such a successful subspecialty in orthopedics. You have people who are 20 to 30% functional, they can’t walk more than four or five blocks without pain, they have pain all day long where they’re sitting and none of the anti inflammatories are working, their life is completely dominated by their hip or their knee pain. You do a joint replacement and you make them 70% functional, and they’re the happiest people you’re going to meet because you made them from 20% functional to 70% functional, and you have an incredibly wide margin to improve them.”*

## How to find the right orthopedic surgeon for you [2:01:45]

**1) Pick a surgeon who does high volume**

- “The best surgeons won’t need your business” so they will be happy to tell you if you don’t need surgery
- Knee replacement example, what’s a good volume? ~4 per week, 200+ per year

**2) Testimonials**

- Ask previous patients about their outcomes with that doctor
- Get a referral from someone you trust

**3) Pick a surgeon who will discuss complications**

- “[Every surgeon] has had complications, and the surgeon you want to have is someone who steps up when there is a complication.”
- Basic questions to ask…
  - What’s your infection rate?
  - What’s your re-op rate?
- If the surgeon can’t answer those or doesn’t want to answer them, that’s a bad sign
- but for anybody who’s had a complication, you try to create zero barriers. I try to make it as seamless as possible. You want to have a surgeon who has a reputation of being someone who will deal with complications, and I don’t know how you find that other than by word of mouth.

**4) Pick a surgeon who welcomes a second opinion**

**In summary**: *“Volume, the humility to answer questions about complications, the willingness to participate and have second opinions, those are three pretty good rules of thumb.”*

\*Note: Peter and Eric do NOT recommend using a service like [Healthgrades.com](https://www.healthgrades.com/find-a-doctor)  ⇒ Eric compares Healthgrades.com to the [South Park](https://en.wikipedia.org/wiki/South_Park) episode about Yelp reviewers: [You’re Not Yelping](https://en.wikipedia.org/wiki/You%27re_Not_Yelping)

## How to cope with complications and maintain quality of life through adaptation [2:09:15]

*“Our role as physicians is to help patients adapt and cope with their new reality.”*

**Role of the physician**

- Eric believes helping patients cope with their new reality might be the most important job of a physician
- Doctors should help patients focus on what they’re *able to do as opposed to what they’re unable to do*
- Whether it’s with an illness, an injury, or surgical complication, it’s the doctor’s job to help patients manage their new reality and help them to continue to live their lives
- [See speech by Dr. Eric Winer](https://vimeo.com/195039402) ⇒ “*I think anybody who is receiving medical care, has an ongoing issue should listen to this.*”

**Knee purgatory**

- Patient has degeneration and pain but aren’t ready for joint replacement
- They have, say, 60% functio, and surgery would only get them to 70%
- The treatment and management of knee purgatory, *“the emphasis in on coping”*

⇒ Example…

- - The 45 year old who has knee degeneration causing pain which no longer allows them to run
  - Eric wants to get that person to about 65 before a knee replacement

- *“Coping is somewhat of managing the expectations of what you will be capable of doing, but also not setting limits. Allowing patients to try the running and allow the joint or their problem to limit them, as opposed to you imposing any artificial limits on them.”*

**Pain thresholds**

Eric will draw a graph for patients, *“above this threshold if you’re developing pain or swelling, and below this threshold you’re not, you want to be up against that threshold with your activity level as much as you can be.”*

You can modulate your paint threshold:

- You can strengthen your leg
- You can lose weight ⇒ Even the person who weighs 100 pounds who loses five pounds, is going to benefit from weight loss if they have a painful lower extremity join
- Getting educated ⇒ *“The more you learn about your condition, your illness, your injury, the better you’ll be able to cope with it. Period.”*
- Trying other activities (runners can try swimming or biking)
- Focusing on what you can do as opposed to what you can’t do

*People can still live and move better by focusing on what they are still capable of doing, as opposed to focusing on what they’ve lost. . . and that mindset makes a huge difference in managing and coping*, says Eric

**Don’t stop moving!**

Peter: *“One of the fears that I have in that type of a patient, is they stop running because it just becomes simply too difficult, but they don’t replace it with something else, and all of a sudden they have a really precipitous decline in their physical quality of life. Now look, for a 45 year old to get sedentary doesn’t mean that much. But by the time they’re 65, the difference between them having pivoted to a new sport or having done nothing, becomes enormous.”*

Problem that keeps Peter up at night:

- Once you reach a certain point in life and your mobility is severely hampered
- What you wouldn’t give to go back to age 45 and try to start preparing for your future?
- Peter thinks a lot about what those things that you should be doing actually are
- At least part of the answer is this idea of “adaptability” ⇒ “Hey, you can’t run? Great. You’re going to learn how to ride a bike. Can’t do that? That’s fine. You’re going to learn to do x, y, or z.”

## Dr. Bukk Teef [2:26:45]

*You introduced me to probably one of the three most important parlor tricks in my life, which are the Dr. Bukk’s.”* -Peter Attia

![](https://peterattiamd.com/wp-content/uploads/2019/01/bukk-teef-original.jpg)

**Figure 6. Bukk original.** Image credit: [drbukk.com](https://www.drbukk.com/en/)

*“I had convinced the entire pediatric tower at Hopkins hat there were two Dr. Attia’s. One with good teeth and one with bad, and we were twins”*

![](https://peterattiamd.com/wp-content/uploads/2019/01/unnamed-1.jpg)

**Figure 7. Cowcatcher teef.** Image credit: [drbukk.com](https://www.drbukk.com/en/)

*“I found the dental clinic. I went in with my teeth, and I said, ‘Hi. My name’s Peter Attia. I’m the new dental fellow. Did you guys get my records?’ You cannot believe the discomfort in that room.”*

![](https://peterattiamd.com/wp-content/uploads/2019/01/speed-teeth.jpg)

**Figure 8. Speed teef.** Image credit: [drbukk.com](https://www.drbukk.com/en/)

Eric’s favorite were the Gnarly teef⇒ *“There is a specific look you must master, the ‘shy quay’”*

![](https://peterattiamd.com/wp-content/uploads/2019/01/unnamed-2.jpg)

**Figure 9. Gnarly teef.** Image credit: [drbukk.com](https://www.drbukk.com/en/)

Peter wore them when meeting his wife’s family for the first time: *“Her dad was beside himself in discomfort.”*

![](https://peterattiamd.com/wp-content/uploads/2019/01/unnamed-3.jpg)

**Figure 10. Chikklets teef.** Image credit: [drbukk.com](https://www.drbukk.com/en/)

To Peter’s delight, his wife Jill actually sported the Youdaman teef at their rehearsal dinner

![](https://peterattiamd.com/wp-content/uploads/2019/01/unnamed-4.jpg)

**Figure 11. YouDahMan teef.** Image credit: [drbukk.com](https://www.drbukk.com/en/)

Sadly, through Peter’s N=1 social experimentation, he found that he was treated differently when wearing the teeth versus not, we have a long way to go as a society. . .

**Stay tuned for a second podcast with Peter and Dr. Eric Chehab solely discussing Dr. Bukk Teef culture**

§

§

## Selected Links / Related Material

**A world-renowned hospital for orthopedics where Eric trained in surgery**: [Hospital for Special Surgery](https://www.hss.edu/) | ([hss.edu](https://www.hss.edu/)) [1:00, 39:15]

**Where Eric practices in Wilmette, IL**: [Illinois Bone and Joint Institute](https://www.ibji.com/) | ([ibji.com](https://www.ibji.com/)) [3:45]

**Bruce Springsteen and Tom Morello (aka Peter) play at Madison Square Garden**: [Bruce Springsteen w.Tom Morello – Ghost of Tom Joad – Madison Square Garden, NYC – 2009/10/29&30](https://www.youtube.com/watch?v=n-mq0uJ7rlM) | Zarastro1040 ([youtube.com](https://www.youtube.com/)) [4:45]

**Springsteen’s tribute to Clarence Clemons at Wrigley Field**: [Bruce Springsteen @ Wrigley Field, Chicago 9/7/2012](https://www.youtube.com/watch?v=aKQskkbHfPc) | zoonotic ([youtube.com](https://www.youtube.com/)) [7:45]

**The song Eric sang at Peter’s wedding**: [Fire by Bruce Springsteen](https://en.wikipedia.org/wiki/Fire_(Bruce_Springsteen_song)) | ([wikipedia.org](https://www.wikipedia.org/)) [11:15]

**Peter’s interview with Paul Conti, a mutual friend from med school**: [Paul Conti, M.D.: trauma, suicide, community, and self-compassion (EP.15)](https://peterattiamd.com/paulconti/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [18:00]

**Rehab center where Bill got sober**: [Carrier Clinic](https://carrierclinic.org/) | ([carrierclinic.org](https://carrierclinic.org/)) [23:00]

**Peter’s interview with Corey McCarthy on how a few bad decisions can lead you down an entirely different path**: [Corey McCarthy: Overcoming trauma, dealing with shame, finding meaning, changing the self-narrative, redemption, and the importance of gratitude (EP.12)](https://peterattiamd.com/coreymccarthy/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [34:00]

**Bar/restaurant near Stanford where Eric took his wife on their first date**: [The Dutch Goose](https://www.dutchgoose.net/) | ([dutchgoose.net](https://www.dutchgoose.net/)) [36:00]

**Bill took Eric to his first NFL game in 1982 where the Giants lost at the very end**: [MOSELEY’S RECORD KICK WITH :004 LEFT BEATS GIANTS](https://www.nytimes.com/1982/12/20/sports/moseley-s-record-kick-with-004-left-beats-giants.html) | ([nytimes.com](https://www.nytimes.com/)) [46:00]

**Peter’s Jerry Rice poster he had as a kid**: [ORIGINAL 1995 JERRY RICE GOAT NIKE “JUST DID IT” #139 POSTER 2ND EDITION 23 X 35](https://thumbs.worthpoint.com/wpimages/images/images1/1/0216/08/1_b0937527a4e66f81e31726c75dfb87f3.jpg) | ([worthpoint.com](https://www.worthpoint.com/)) [48:15]

**Curtis Martin’s Hall of Fame acceptance speech**: [Curtis Martin Hall of Fame Enshrinement Speech](https://www.youtube.com/watch?v=eCYpF1OsklA) | Pitt LiveWire ([youtube.com](https://www.youtube.com/)) [57:00]

**Eric’s program for his patients based off a lot of Peter’s work**: [OrthoHealth](https://www.ibji.com/services/orthohealth/) | ([ibji.com](https://www.ibji.com/)) [1:10:00]

**Two common bisphosphonates, drugs designed to prevent the loss of bone density**: [1:12:30]

1. [Fosamax](https://www.webmd.com/drugs/2/drug-1273-7174/fosamax-oral/alendronate-oral/details) | ([webmd.com](https://www.webmd.com/))
2. [Boniva](https://www.webmd.com/drugs/2/drug-92884/boniva-oral/details) | ([webmd.com](https://www.webmd.com/))

**NYT article by Gina Kolata critical of surgeons**: [Why ‘Useless’ Surgery Is Still Popular](https://www.nytimes.com/2016/08/04/upshot/the-right-to-know-that-an-operation-is-next-to-useless.html) | Gina Kolata ([nytimes.com](https://www.nytimes.com/)) [1:29:15]

**Study comparing surgery vs physical therapy for meniscus surgery**: [Surgery versus physical therapy for a meniscal tear and osteoarthritis.](https://www.ncbi.nlm.nih.gov/pubmed/23506518) (Katz et al., 2013) [1:29:30]

**PRP studies showing marginal benefit**: [1:42:15]

- [Efficacy of platelet-rich plasma injections for symptomatic tendinopathy: systematic review and meta-analysis of randomised injection-controlled trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5687544/) (Miller et al., 2017)
- [PRP Treatment Efficacy for Tendinopathy: A Review of Basic Science Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5004020/) (Zhou et al, 2016)

Eric referring to stem cells… There’s no question that there’s promise in it, and the animal studies really demonstrate it … but animals are getting 10-20 million in stem cells and humans only get a few hundred… orders of magnitude off [1:47:00]

**Stem cell meta-analysis looking at only RCTs**: [Clinical efficacy and safety of mesenchymal stem cell transplantation for osteoarthritis treatment: A meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5407776/) (Yubo et al., 2017) [1:49:15]

**A recent paper showing subacromial decompression surgery no better than a sham procedure**: [Subacromial decompression versus diagnostic arthroscopy for shoulder impingement: randomised, placebo surgery controlled clinical trial](https://www.ncbi.nlm.nih.gov/pubmed/30026230) (Paavola et al., 2018) [1:51:15]

**A study comparing meniscus surgery to placebo/sham surgery**: [Arthroscopic partial meniscectomy versus placebo surgery for a degenerative meniscus tear: a 2-year follow-up of the randomised controlled trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5867417/) (Sihvonen et al., 2018) [1:53:30]

**Eric says Peter introduced him to the concept of asymmetric risk which Peter describes in this Tim Ferriss podcast episode starting at 1:58:00**: [My Life Extension Pilgrimage to Easter Island](https://tim.blog/2016/10/20/my-life-extension-pilgrimage-to-easter-island/) | Tim Ferriss ([tim.blog](https://tim.blog/)) [1:59:15]

**The rating system for doctors that Peter and Eric do NOT recommend using**: [Healthgrades](https://www.healthgrades.com/) | ([healthgrades.com](https://www.healthgrades.com/)) [2:07:25]

**Episode of South Park that Eric uses to describe the Healthgrades service for rating doctors**: [You’re Not Yelping](https://en.wikipedia.org/wiki/You%27re_Not_Yelping) | ([wikipedia.org](https://www.wikipedia.org/))  [2:07:45]

**Eric Winer’s lecture on breast cancer**: [Eric P. Winer, MD: The McGuire Lecture](https://vimeo.com/195039402) | Harborside ([vimeo.com](https://vimeo.com/)) [2:12:00]

**The greatest parlor trick ever**: [Dr. Bukk Teef](https://www.drbukk.com/en/) | ([drbukk.com](https://www.drbukk.com/en/)) [2:26:45]

§

§

## People Mentioned

- [Russ Warren](https://www.hss.edu/physicians_warren-russell.asp) (Eric’s mentor, godfather of sports medicine) [1:15, 42:00]
- [Bruce Springsteen](https://en.wikipedia.org/wiki/Bruce_Springsteen) (Eric’s favorite singer) [4:45]
- [Guns N’ Roses](https://en.wikipedia.org/wiki/Guns_N%27_Roses) [6:00]
- [Lynn Chehab](https://www.northshore.org/apps/findadoctor/physicians/lynn-g.-chehab) (Pediatrician, Eric’s wife) [7:15]
- Mike Owen (Eric’s roommate, marine, Dr. Bukk connoisseur) [8:20, 2:27:30]
- [General Jim Mattis](https://en.wikipedia.org/wiki/Jim_Mattis) (Mike Owen worked for him) [8:45]
- [Pearl Jam](https://en.wikipedia.org/wiki/Pearl_Jam) (one of Peter’s favorite bands) [9:00]
- [Eddie Vedder](https://en.wikipedia.org/wiki/Eddie_Vedder) (Pearl Jam) [9:30]
- [U2](https://en.wikipedia.org/wiki/U2) (opened for Pearl Jam in Verona in 1992) [10:00]
- [Mike McCread](https://en.wikipedia.org/wiki/Mike_McCready)y (Pearl Jam, Peter almost caught his guitar pick) [10:20]
- [Paul Conti](https://www.pacificpremiergroup.com/meet-our-team/) (mutual friend from Stanford, [previous guest on The Drive](https://peterattiamd.com/paulconti/)) [11:30]
- [Jason Pyle](https://www.linkedin.com/in/jason-pyle-551127/) (mutual friend) [11:45]
- [Dan Finnerty](https://en.wikipedia.org/wiki/Dan_Finnerty) (The Dan Band, sang in movie Old School, Eric’s sings like him at Peter’s wedding) [12:30]
- [Mathias Bostrom](https://www.hss.edu/physicians_bostrom-mathias.asp) (one of the greatest guys at Special Surgery in NY, did Bill’s hip surgery) [25:00]
- [Corey McCarthy](https://twitter.com/coreymccarthyie?lang=en) (wrong decisions can lead to devastating consequences, [previous guest on The Drive](https://peterattiamd.com/coreymccarthy/)) [34:00]
- [Chitranjan S. Ranawat](https://www.hss.edu/physicians_ranawat-chitranjan.asp) (giant in the field of joint replacement) [40:00]
- [Tom Sculco](https://www.hss.edu/physicians_sculco-thomas.asp) (giant in the field of joint replacement) [40:00]
- [Phillip Wilson](https://www.hss.edu/physicians_wilson-philip.asp) (giant in the field of joint replacement) [40:00]
- [Dr. Paul Pellicci](https://www.hss.edu/physicians_pellicci-paul.asp) (most gifted joint replacement surgeon I’ve ever seen, could do a total hip replacement in 45 minutes to an hour) [44:15]
- [Bon Jovi](https://twitter.com/jonbonjovi?lang=en)  [44:45]
- [Tom Wickiewicz](https://www.hss.edu/physicians_wickiewicz-thomas.asp) (director of Eric’s fellowship) [44:45]
- [Scott Rodeo](https://www.hss.edu/physicians_rodeo-scott.asp) (head team physician for the Giants) [44:30]
- [Lawrence “LT” Taylor](https://en.wikipedia.org/wiki/Lawrence_Taylor) (greatest linebacker ever for NY Giants) [45:45]
- [Scott Brunner](https://en.wikipedia.org/wiki/Scott_Brunner) (former QB for the NY Giants [46:00]
- [Phil Simms](https://en.wikipedia.org/wiki/Phil_Simms) (QB who hurt his knee) [46:00]
- [Ronnie Barnes](https://nygunderground.com/2018/07/30/ronnie-barnes-most-powerful-man-in-the-giants-organization/) (trainer for NY Giants) [47:30, 55:00]
- [Byron Hansen](https://www.pfats.com/directory/byron-hansen/) (trainer for NY Giants) [47:30]
- [Steve Kennelly](https://www.pfats.com/directory/steve-kennelly/) (trainer for NY Giants) [47:30]
- [Jerry Rice](https://en.wikipedia.org/wiki/Jerry_Rice) (Peter had a poster of Jerry Rice on his bedroom wall as a kid) [48:15]
- [Ryan Flaherty](https://ryanjflaherty.com/) (trains NFL players) [49:30]
- [Barry Sanders](https://en.wikipedia.org/wiki/Barry_Sanders) (HOF running back) [50:30]
- [Chris Snee](https://en.wikipedia.org/wiki/Chris_Snee) (all pro guard for Giants who laid a massive hit on a defensive back, felt like a “sonic boom”) [50:45]
- [Tom Coughlin](https://en.wikipedia.org/wiki/Tom_Coughlin) (former NY Giants head coach) [50:45]
- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) (long tenure in NFL) [53:45, 2:08:00]
- [Curtis Martin](https://en.wikipedia.org/wiki/Curtis_Martin) (Hall of Fame acceptance speech) [57:00]
- [Paul Attia](https://twitter.com/PapaAlphaBlog) (recreational mountain biker, Peter’s brother) [58:30]
- [Gina Kolata](https://twitter.com/ginakolata?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (wrote an article about how surgeons are addicted to useful surgery)[1:29:15]
- [Robert Brophy](https://www.ortho.wustl.edu/content/Patient-Care/2793/Find-a-Physician/Physician-Directory/Robert-Brophy-MD/Bio.aspx) (wrote paper comparing PT to meniscus surgery) [1:29:30]
- [John Healey](https://www.mskcc.org/cancer-care/doctors/john-healey), who is an orthopedic oncologist at Sloan Kettering [1:31:15]
- [David Altchek](https://www.hss.edu/physicians_altchek-david.asp) (shoulder surgeon at HSS, Peter almost had an operation before opting for PT) [1:35:15]
- [Josh Martin](https://www.facebook.com/josh.martin.319) (Peter’s bodyworker) [1:38:45]
- [Todd Henderson](https://www.law.uchicago.edu/faculty/henderson) (sham surgery conversation with Eric) [1:52:00]
- [Eric Winer](https://en.wikipedia.org/wiki/Eric_Winer) (primary role of physician is helping patients cope, leader in breast oncology) [2:12:00]
- [Earl Campbell](https://en.wikipedia.org/wiki/Earl_Campbell) (HOF running back with extreme mobility limitations now) [2:21:15]
- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) (extreme physical complications and limitations from boxing) [2:21:45]
- [The Beatles](https://en.wikipedia.org/wiki/The_Beatles) [2:21:45]
- [Carlos Corvera](https://surgery.ucsf.edu/faculty/general-surgery/carlos-u-corvera,-md.aspx) [2:32:45]

§

§

![](https://peterattiamd.com/wp-content/uploads/2019/01/Chehab640x640-500x500.jpg)

##### Eric Chehab, M.D.

Dr. Eric Chehab is a board-certified orthopedic surgeon, fellowship-trained in sports medicine. He provides general fracture care and specializes in the treatment of sports-related injuries, in particular to the knee and shoulder. Dr. Chehab provides advanced treatments for anterior cruciate ligament injuries, shoulder injuries including rotator cuff tears and shoulder instability, and soft tissue and bone trauma. A graduate of Harvard and Stanford, he completed his orthopedic surgery residency at the Hospital for Special Surgery in New York City – recognized by U.S. News and World Report as the nation’s #1 hospital for orthopedics. He completed his advanced training in sports medicine at the Hospital for Special Surgery Sports Medicine and Shoulder Service, where he apprenticed with the head team physician and the medical staff for the New York Giants. Dr. Chehab has served as a faculty member at Northwestern University, as assistant team physician for Northwestern University, team physician for Glenbrook South High School, and is currently an Assistant Clinical Professor at the University of Chicago. At NorthShore University HealthSystem – where he serves as an Attending Surgeon – Dr. Chehab was the co-recipient of the Charles S. Neer Award from the American Shoulder and Elbow Surgeons for excellence in shoulder research. An All-American rugby player in college and captain of the Harvard squad, Dr. Chehab understands the commitment required to achieve at the highest level. He feels privileged to help those in their pursuit of excellence by providing the highest level of compassionate care. [[ibji.com](https://www.ibji.com/doctors/chehab-eric-md/)]