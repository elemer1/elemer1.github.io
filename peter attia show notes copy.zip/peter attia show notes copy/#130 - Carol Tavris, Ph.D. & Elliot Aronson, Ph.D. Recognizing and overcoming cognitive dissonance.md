# #130 – Carol Tavris, Ph.D. & Elliot Aronson, Ph.D.: Recognizing and overcoming cognitive dissonance

**Source:** [https://peterattiamd.com/caroltavris-elliotaronson/](https://peterattiamd.com/caroltavris-elliotaronson/)

---

Renowned social psychologists Carol Tavris and Elliot Aronson are the co-authors of [Mistakes Were Made (But Not By Me)](https://www.amazon.com/Mistakes-Were-Made-But-Not/dp/0151010986/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), a book which explores the science of cognitive biases and discusses how the human brain is wired for self-justification. In this episode, Carol and Elliot discuss how our desire to reconcile mental conflicts adversely affects many aspects of society. The two give real-world examples to demonstrate the pitfalls in attempts to reduce mental conflict, or dissonance. The examples reveal that no one is immune to dissonance reduction behavior, how intellectual honesty can be trained and lastly, how to think critically in order to avoid engaging in harmful dissonant behaviors.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/caroltavris-elliotaronson/the_Drive_public.png)

Play

#130 - Carol Tavris, Ph.D. & Elliot Aronson, Ph.D.: Recognizing and overcoming cognitive dissonance

#130 - Carol Tavris, Ph.D. & Elliot Aronson, Ph.D.: Recognizing and overcoming cognitive dissonance

1x15s30s

0:001:59:44

## We discuss:

- Carol and Elliot’s respective background, collaboration history, and their decision to write Mistakes Were Made (But Not By Me) [4:00];
- The theory of cognitive dissonance, and real examples of dissonance reduction in action [11:15];
- How Elliot advanced the theory of cognitive dissonance [23:00];
- The evolutionary reason for dissonance reduction, and cultural differences in what causes cognitive dissonance [30:30];
- The great danger of smart, powerful people engaging in dissonance reduction [35:15];
- Two case studies of cognitive dissonance in criminal justice [39:30];
- The McMartin preschool case study—The danger in making judgements before knowing all the information [43:30];
- How ideology distorts science and public opinion [56:30];
- How time distorts memories [58:30];
- The downside of certainty [1:05:30];
- Are we all doomed to cognitive dissonance?—How two people with similar beliefs can diverge [1:09:00];
- Cognitive dissonance in the police force [1:21:00];
- A toolkit for overcoming cognitive dissonance [1:27:30];
- Importance of separating identity from beliefs, thinking critically, & and the difficulty posed by political polarity [1:30:30];
- How to impart the lessons from their work into future generations [1:48:00]; and
- More.

§

## Show Notes

## Carol and Elliot’s respective background, collaboration history, and their decision to write Mistakes Were Made (But Not By Me) [4:00]

**How Peter met Carol**

- When Peter read [Mistakes Were Made (But Not By Me)](https://www.amazon.com/Mistakes-Were-Made-But-Not/dp/0151010986/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) in 2012, “*It was love at first sight*.”
- Peter immediately Googled Carol and found a phone number and cold called her
- He somehow cajoled her into coming down to San Diego for dinner for a discussion on cognitive dissonance which began their friendship

**Carol and Elliot’s collaboration**

- They have been collaborating for ~50 years after meeting at an American Psychological Association convention
- Elliot was receiving an award for his book, [The Social Animal](https://www.amazon.com/Social-Animal-Elliot-Aronson/dp/1464144184)
- And Carol was tasked with writing an article about his work for the magazine, Psychology Today
- They found that they both shared a love for social psychology, and a love of communicating social psychology to the public

*Their work together*:

- They have made documentary film called “Prejudice” in 1973 published by CRM Learning (CRM was the parent company of Psychology Today)
- And wrote [Mistakes Were Made (But Not By Me)](https://www.amazon.com/Mistakes-Were-Made-But-Not/dp/0151010986/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)

*Carol says their partnership was an “interesting harmony”*—

Elliot took [Leon Festinger’s theory of cognitive dissonance](https://en.wikipedia.org/wiki/Leon_Festinger#Cognitive_dissonance) and made it into a focus on **self-justification**

⇒ Example, The [Iraq War](https://en.wikipedia.org/wiki/Iraq_War) and how it came to be

- Elliot told Carol, “*I think that George Bush was* ***not*** *lying to the American people. I think he was doing what all of us do, which is make a decision and then justify it by cherry picking the evidence to show that we were right in making that decision*.”
- Elliot makes an important distinction:
  - The term “cherry picking” implies consciously cherry picking
  - But cognitive dissonance reduction is an unconscious process — “*it flies just below the level of awareness*”
  - In the case of George Bush, Elliot says,
  - “*He simply was hell bent on invading Iraq so that he downplayed the importance of the evidence that would have cautioned him not to invade. . .And I think* ***that is something we all do if we’re not careful***.”

> “In so many domains of our lives, the way we think can really get us stuck, and it’s hard to get out of the mistakes we’ve made.” —Carol Tavris

## The theory of cognitive dissonance, and real examples of dissonance reduction in action [11:15]

**An explanation of cognitive dissonance and dissonance reduction**

⇒ [Leon Festinger](https://en.wikipedia.org/wiki/Leon_Festinger)’s smoking example: *What happens when a person who smokes two packs of cigarettes a day starts to see the evidence that smoking can cause cancer and other diseases?*

- That person now experiences **cognitive dissonance**, “I am a smart, sensible person, yet I’m smoking cigarettes even though I know it causes cancer.”
- *What does he do with this cognitive dissonance?*
- - Dissonance is a negative state — It feels terribly unpleasant, like being extremely hungry or extremely thirsty, but it takes place in the mind
  - The simplest thing to do is to give up smoking
  - If a person tries to give up smoking and can’t, he now has to deal with the cognitive dissonance in another way
  - You might try to convince yourself that it’s really mostly correlational evidence and therefore not really definitive,
  - You could convince yourself that obesity is a health risk and by smoking two packs a day, I’m keeping myself from eating all of those rich desserts,
  - You could say, “well, it’s debonair to fly in the face of danger and smoke a cigarette like Humphrey Bogart in the movies” … i.e., I would rather live a shorter but more interesting life than one where I was forever being cautious
  - All of these together can be used together as a way of allowing someone to smoke and still feel good about themself
  - They can be used to help you “sleep at night” — The ability to reduce dissonance is what allows us to say, “I’m doing something stupid, but look, here are all the reasons that I justify it.”

**A** [**study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4248080/) **looking at pregnant women who smoke and** ***rationalize their dissonance***

- Pregnant women have a double knowledge of smoking being bad not only for their own health, but for the baby’s health
- What did the smokers say when explaining why they were going to keep smoking?
  - “W*ell, I’ve cut down. Now the amount of cigarettes I smoke every day isn’t really as hazardous as would have been before I cut down*.”

> “That’s the benefit of our ability to reduce dissonance. But, you know what? Sometimes some sleepless nights are called for.” —Carol Tavris

\*\*\*

**The origin of the theory of cognitive dissonance [16:00]**

*How did this theory of cognitive dissonance breakthrough in psychology?*

- Psychologists, for a long time, had the notion of rationalization—that people often rationalize their own behavior (a pale version of cognitive dissonance theory)

**How Leon Festinger came up with and advanced the theory of cognitive dissonance:**

*1—First of all, he was studying rumor transmission*:

⇒ In India, there was a major earthquake—

- In one area of the country, a lot of people got killed
  - The rumors that spread in that area were very reasonable rumors, “Don’t worry. Help is on the way. People are coming, they’re going to rescue us. They’re going to bring food. We’re starving, but things are going to be okay.”
  - Those were the kinds of rumors that made sense. They were comforting rumors.
- In another city 15 miles away, there wasn’t a great deal of damage, but there was enough damage and enough people got mildly injured that they were really anxious and really scared
  - the rumors that spread in that area was that there was a typhoon coming, hurricane, huge flooding
  - And Festinger scratched his head and said, “*Why in the world would people spread rumors that would increase their anxiety?*”
  - He realized that the earthquake made them feel extremely anxious, but they had very little to be anxious about because hardly anyone got hurt and hardly any destruction occurred
  - So the people invented future things that were going to happen and spread rumors about them **in order to justify their anxiety**

*2—Secondly, he thought up several interesting experiments showing that cognitive dissonance reduction works in ways that are often counterintuitive*

⇒ Best example is one of the early experiments by [Leon Festinger](https://en.wikipedia.org/wiki/Leon_Festinger) and [Merrill Carlsmith](https://en.wikipedia.org/wiki/Merrill_Carlsmith)—

- People participated in an extremely tedious and uninteresting task
- After coming out of that task, the person was given either $20, or $1, to lie to the next person in line to do the task and tell them it was a very interesting task
- what happened was that the students who were given $1 for doing it actually came to believe that the task was more interesting than the students who were paid $20 for doing it.
- This is completely upside-down from what would be predicted by the dominant theory of the time, the [behaviorist theory of reinforcement](https://en.wikipedia.org/wiki/Reinforcement) (That the more you’re paid for something, the more you like it)
- What cognitive dissonance theory predicts is the less you’re paid for it, the more you have to add justifications of your own.
- In other words,
  - if you’re paid $20 for telling a simple lie, you can say to yourself, “Well, I sold my soul, but $20 is a pretty good price for my soul.
  - But if you’re paid only $1, in effect, you’re asking yourself, “Now, why did I do that for a lousy dollar?” And so what they did was **convince themselves** that the task wasn’t so bad

## How Elliot advanced the theory of cognitive dissonance [23:00]

- Carol says, “*When I was a graduate student, [psychological science] was almost an oxymoron. Everybody joked about it. Psychology? What are you talking about? It’s not a science. It’s not research-based. It’s not empirically-based.*”
- When Elliott was first doing his work, the dominant paradigms in psychology were **psychoanalytic** or **behaviorist** which were devoted to explaining how human beings operate, and how they think, and what motivates them.

What Elliot was doing in terms of cognitive dissonance was two things—

- 1) Looking into the black box of the mind which behaviorists were ignoring completely
  - Behaviorists were says, “We just have to observe behavior, it’s all a matter of rewards and punishments”
  - But Elliot was saying, “No, no. There’s something happening in there that affects our behavior most profoundly.”
- 2) He was questioning the qualitative observations being made
  - These were the non-scientific observations of the psychoanalytic approach to understanding behavior, “*which were lively, and popular, and* ***wrong***.” says Carol
  - Then comes cognitive dissonance and the cognitive revolution, and the world of psychological science changed

**Freud’s notion of catharsis—How cognitive dissonance explains a counterintuitive finding**

*The experiment*:

- In 1959, a Freudian psychologist named [Michael Kahn](https://www.legacy.com/obituaries/marinij/obituary.aspx?n=michael-kahn&pid=172024369) was doing an experiment for his PhD dissertation to test [Freud’s notion of catharsis](https://study.com/academy/lesson/catharsis-in-psychology-theory-examples-definition.html#:~:text=Lesson%20Summary-,Catharsis%20is%20the%20process%20of%20venting%20aggression%20as%20a%20way,spent%20more%20time%20on%20psychoanalysis.)
- Catharsis says that when you feel angry at someone, you need to “get it out of your system” by punching a punching bag (or even punching the person)
- Trying to demonstrate Freud’s theory of catharsis, Kahn’s experiment had someone acting out on their aggressive feelings to see if it would make them feel better and less aggressive
- What he found was just the *reverse* — When a person expressed his anger by getting his tormentor fired job, it actually **increased his negative feelings about his tormentor**

Kahn was really confused, “*How can this be?*”

- **The answer is cognitive dissonance.**
- In other words, if you retaliate and harm the person (perhaps to a greater degree than they harmed you), you now have to **justify it**  — e.g., “*My God, I really hurt that guy. Well, he must have really deserved it. He’s a terrible person anyway.*”
- (This also explains the phenomenon of blaming the victim, says Elliot)
- The fundamental heart of the reason that we so often reduce dissonance is to **preserve how we see ourselves as a good, reasonable person** (i.e., our “self-concept”)

## The evolutionary reason for dissonance reduction, and cultural differences in what causes cognitive dissonance [30:30]

**Cultural differences in what causes people to feel dissonance**

- It’s not like everybody always will feel dissonance (e.g., a good scientist will use information that counters their hypothesis to adjust their thinking)
- Example, [studies](https://pdfs.semanticscholar.org/c99c/c784701ef52d9d15f6d7616caa0be4b8e0b1.pdf) have compared what causes dissonance in Japan or the United States
  - In the United States, we feel a state of dissonance if we ourselves, personally, are ashamed or embarrassed or humiliated by something that we’ve done.
  - In Japan, people are more likely to feel the need to reduce dissonance if they’ve behaved in a way to harm, hurt, or embarrass other people in their group, because they are typically a more other oriented culture.

> “While we can appreciate what is universal about dissonance, let’s not make the corresponding error that we all automatically and forever behave exactly the same way.” —Carol Tavris

\*\*\*

**The evolutionary reason for dissonance reduction**

*Why would dissonance reduction have been a conserved feature of our evolution?*

- Elliot believe cognitive dissonance is hard-wired, because it has survival value

*One Example*: Thinking back to a time where humans lived in small tribes as hunter-gatherers

- Scenario #1:
  - A hunter did something that hurt one of his fellow tribesmen
  - He then lays awake all night, worrying about it
  - The next morning you get up bright and early to go hunting and you get pounced on by a tiger because you didn’t sleep at night and you’re not as vigilant as you normally would have been
  - Then chances are your genes are less likely to get into the gene pool.
- Scenario #2:
  - Another hunter uses dissonance reduction to convince himself that what he did wasn’t so bad and he sleeps soundly
  - He gets up early and goes hunting and everything is fine

“The ability to reduce dissonance is hardwired, precisely because it has survival value in that.”

As we’ve evolved…

- We’ve created new technologies, agriculture emerged, economies grew, and now people have way more beliefs to defend as being the right ones
- Whereas if you’re living in a little band, you may never meet anybody from another band with a different point of view

## The great danger of smart, powerful people engaging in dissonance reduction [35:15]

> “It’s to the extent that a belief is really deeply important to us, that’s when we become most tenacious in holding onto it.” —Carol Tavris

*Do only dumb people feel the need to reduce dissonance?*

- Absolutely not
- In fact, dissonance reduction is very dangerous precisely because even the smartest, most powerful people feel the need to reduce dissonance.
- “*The* ***greatest danger*** *comes from smart people who refuse to accept the evidence that they have done something foolish.*”

**Example —** prosecuting attorneys when faced with new evidence

- Let’s say a prosecuting attorney worked hard on a murder case and he gets a conviction and the person goes to prison and is in prison for 25 years
- Then, DNA evidence shows up that proves beyond a shadow of a doubt that the convicted person was actually innocent
- W*hat happens to the typical prosecuting attorney in that situation*?
  - In many cases, instead of changing his position he will say, “That can’t be true. The DNA evidence has to be wrong.”
  - He will hold this position even if it means keeping the person in prison for another 25 years
- W*hy does he do that*?
  - Not because he’s an evil guy
  - But because he thinks of himself as a good and competent guy—someone who would never make a terrible mistake like that.

⇒ See the case of [Amanda Knox](https://en.wikipedia.org/wiki/Amanda_Knox) case (discussed in Mistakes Were Made)

## Two case studies of cognitive dissonance in criminal justice [39:30]

**Case #1:** [**Duke lacrosse case**](https://en.wikipedia.org/wiki/Duke_lacrosse_case)

- The guys from the Duke lacrosse team had a stripper at a party
- The stripper later claimed that she had been raped
- This story seemed to fit the narrative that athletes/fraternity guys/young males who party are all racist, rapists, sexists, etc.
- About 80 faculty members at Duke even took out an ad in the school paper about the “toxic masculinity” of the lacrosse team, and men in fraternities in general
- However, it turned out that the district attorney (DA) was not giving the [exculpatory evidence](https://en.wikipedia.org/wiki/Exculpatory_evidence) to the defense
- The DA was eventually disbarred
- It was a scandalous case involving race and gender that **the DA saw it as a way to really make name and fame for himself**
- “*It’s a particularly egregious example, but it’s not uncommon.*”

**Case #2:** [**Central Park jogger case**](https://en.wikipedia.org/wiki/Central_Park_jogger_case)

- This was a case of aggravated assault and rape of a white female jogger in central park
- Five youth defendants were falsely convicted, and even confessed to the crime
- They served out their sentences, before all were eventually exonerated following the confession of another inmate
- It turned out that the DNA evidence *never matched* the kids who were convicted.
- The prosecuting attorney, [Linda Fairstein](https://en.wikipedia.org/wiki/Linda_Fairstein), insists to this day that she was right
- She refused to overturn the evidence so it had to be overturned by the district attorney who oversaw the case
- Subsequently, the city of New York paid a huge compensation amount of money to those kids who spent several years in prison
- When asked about the new DNA evidence, Fairstein said the typical thing that prosecutors say, “*We always knew there was a sixth man.* . . .*our guys were just holding the woman down while the other guy actually raped her.*” (paraphrased)
- The folks with the [Innocence Project](https://en.wikipedia.org/wiki/Innocence_Project) call this the “[unindicted co-ejaculator theory](https://scholarlycommons.law.northwestern.edu/cgi/viewcontent.cgi?article=7572&context=jclc#:~:text=The%20unnamed%2Dlover%20theory%20is,with%20a%20lengthy%20record%20of)” — which is basically a term that describes the ability to come up with any explanation of why you can still be right, even though you’re wrong

## The McMartin preschool case study—The danger in making judgements before knowing all the information [43:30]

> “We sacrificed our skepticism at the altar of outrage.” —Elliot Aronson

**What happens when we see a news story and we jump to a conclusion:**

*Here’s what happens all too often*—The minute there is a sensational story in the news, somebody is accused of something, the public will jump to a conclusion

*What dissonance theory would predict*:

- The minute we make a decision (i.e., believe this person, or believe the other person), we will now make our belief **conform to the evidence** we’re prepared to hear as things go forward.
- That belief will then harden rather than become more open to disconfirming evidence

*Your first decision is very crucial*

- We often then find evidence to justify that belief and it becomes harder to change our mind
- It’s our active self-justifications for the beliefs we have, that take us down sometimes what turns out to be a wrong path.

⇒ “*A perfect demonstration of dissonance*” — A [video of Sarah Silverman](https://www.youtube.com/watch?v=_WKFDqxiL80&feature=emb_logo) talking about her friend, Louis CK, who was accused of inappropriate behavior

\*\*\*

Case study: [**McMartin preschool trial**](https://en.wikipedia.org/wiki/McMartin_preschool_trial)

*Backstory*:

- A mother and her two adult children were suddenly accused of what turned out to be utterly preposterous assaults on the children at their daycare center
- But, sanity and common sense generally goes out the door when you have a sentence with the words, *children and sex*
- It was hysterical news, and *the prosecutor was convinced* that this was really happening

*Controversy about how the kids were interviewed*:

- No psychological research at the time was looking at how to interview children or how children respond to repeated/leading questions
- A the time, there was a developmental psychologist who argued that **if you don’t ask children leading questions, the child won’t tell you what happened**
- That seemed to justify the tactics that the social workers and police were doing with these little kids
- Carol, to her great embarrassment now, wrote an op ed for the Los Angeles Times called, [Do Children Lie? Not About This](https://www.latimes.com/archives/la-xpm-1990-01-19-me-112-story.html)
- But that was the psychological science as we knew it at that point, says Carol, that kids needed to be asked “leading questions” in order to get them to tell the truth about what happened

*Public and media perception*:

- People were so disgusted by the story, it was easy to interpret everything in a certain way
- For example:
  - there was a copy of Newsweek magazine with a picture of Mrs. McMartin sticking her tongue out
  - If you think she is guilty, this was easy to see as a bizarre and gross reaction by someone who committed a heinous crime
  - In reality, she got angry at a photographer for harassing her — But once we have the belief that she’s guilty of child molestation, then we can’t see her as an innocent person being angry at a harassing photographer

**\*Important takeaways from the McMartin case:**

- McMartin was the first of a wave of hysterical cases across the country in which daycare workers were accused of [ritual, sexual molestation of children](https://therevealer.org/michelle-remembers-and-the-satanic-panic/)

![](https://peterattiamd.com/wp-content/uploads/2020/09/Ms.-Magazine-cover-788x1024.png)

**Figure 1. Cover of Ms. Magazine saying “BELIEVE IT!” about the existence of ritual child abuse cults.** Image credit: Twitter: [@kittypurroz](https://twitter.com/kittypurrzog/status/1181696163893796864)

- Hundreds of daycare workers went to prison
- The lesson is not simply that many people were wrong about McMartin
- **The lesson is that many people’s** ***first reaction*** **to the accusation happened when nobody knew anything**

*Examples of information* ***not known*** *before the public reacted to the news* —

- i) the first allegation was made by a woman who was so psychotic,
- ii) police were then showing up at the home of parents who of course were panicking,
- iii) the children were being asked questions in a way that led to incorrect recollections

*Other examples of* ***bad information*** *shaping the perception*:

- Social workers were testifying in court that they KNEW if a child had been molested based on how the kid was playing with a naked doll
  - Experiments have since shown that there’s no difference between how a sexually abused child and a non-abused child play with dolls
- Therapists with no psychological scientific training were testifying with assurance that they knew that this kid had been molested based on their own observations and hunches and biases
- Since the time of these many daycare cases, much research has been done to transform how we understand children’s testimony so that we can *help the children* who have been molested, but *not destroy the lives of innocent adults* either

**Carol atoning for her role in the McMartin case**:

- Carol felt dissonance about her own participation and what I wrote about McMartin
- Rather than digging her heels in for dissonance reduction, she’s began atoning for this by writing about what was happening in the other daycare cases across the country
- Example being the [Amirault case](https://en.wikipedia.org/wiki/Gerald_Amirault) in Boston, which was almost a mirror image of McMartin

## How ideology distorts science and public opinion [56:30]

> “There’s a very subtle difference between always believe the victim versus always be skeptical and take the accusation seriously.” —Peter Attia

**The backdrop**:

- In today’s discussion, there seems to be a lack of nuance — everything is binary (e.g.., good or bad) and it’s based on preconceived notions
- “In science, whenever ideology interferes, it can distort the science and it certainly can distort public opinion.”

**“Believe all women”**

- When we talk about sexual harassment in this climate–there is a prevalent ideology that exists that says we should **always believe the accuser**
  - Afterall, *why would a woman come forward if she wasn’t telling the truth?* . . . **But that’s an** ***ideological*** **conclusion**.
- Rather than *always believe* the accuser, Elliot would say, *always listen*, but *keep some skepticism* in mind
- Some of the radical feminists are saying, “It doesn’t matter, so what if some guy is falsely accused and falsely loses his job?”
  - But that’s “never a reasonable position”, says Elliot

## How time distorts memories [58:30]

**Recovered memory therapy**

Carol has [written about the pitfalls of recovery memory therapy](https://www.skeptic.com/reading_room/persistence-of-recovered-repressed-memory-movement/) and gotten a lot a heated criticism

Carol says, “*I have always been skeptical of the believe X group (whatever group that is) uncritically. What’s the evidence? What’s the best explanation for it?*”

- In the case of sexually abused women, there have been many abused women
- HOWEVER…“if someone is bringing up an allegation that occurred six months ago, six years ago, or 35 years ago, we’re entitled to talk about what we understand about memory” says Carol

*How memories can change*:

- In many cases, our interpretation of the original event changes over time in our memory of it
- Events that happen to us 25 years ago, that at the time we thought were benign, we can come to see as being malevolent and traumatic and oppressive

Social psychologist Deborah Davis has [written](https://scholarlycommons.law.northwestern.edu/cgi/viewcontent.cgi?article=7571&context=jclc) that …

- A person doesn’t have to be lying to be wrong in making an allegation,
- And a man, for example, doesn’t have to be lying, he can be self-justifying in responding to an allegation

> “This is a different level of understanding that I think is important, especially when charges involve the possibility of ruining someone’s life.” —Carol Tavris

**Memory is not as accurate as you think**

- Peter read the book by Kathryn Schulz, [Being Wrong](https://www.amazon.com/Being-Wrong-Adventures-Margin-Error/dp/0061176052), and was struck by how feeble memory is
- And when memories are wrong, it’s not always a case of self-justification or dissonance reduction—it can simply be just randomly wrong in a sort of *harmless way*
- Elliot says, “*The common idea is that we have a little tape recorder inside our brain, and all we have to do is press the button and it’ll all come out,* ***is wrong****.*”

## The downside of certainty [1:05:30]

> “We can learn to have passionate beliefs that give our lives color and meaning . . . but to hold them lightly enough so that if the evidence comes along . . . we can finally have to say, ‘You know what? I was wrong on that one.’” —Carol Tavris

**Doubt vs. certainty**

- Society doesn’t really reward doubt as much as it rewards arrogance and certainty
- As a society, we love certainty which can easily morph into arrogance

Elliot gives the example of a time when he was serving as an expert witness in a murder case—

- When presenting evidence, Elliot said, “*All other things being equal…*”
- This was met by the prosecuting attorney exclaiming “In the real world, Professor, all other things are hardly ever equal.”
- Elliot points out that “all other things being equal” is simply the credo of experimental science—It means that you control extraneous variables which could distort the data
- It’s a good thing to hold all of the things equal, not a bad thing about science
- Elliot says, “*Many people prefer the pseudosciences where somebody gives you a certain answer, whereas scientists have the irritating habit of talking in probabilities*.”

> “If someone really is certain about something, they have almost certainly frozen their ability to change their minds when they need to.” – Carol Tavris

## Are we all doomed to cognitive dissonance?—How two people with similar beliefs can diverge [1:09:00]

**The pyramid metaphor**

- Carol and Elliot use the visual of a pyramid to explain how two people can start out at the top with a very similar set of beliefs
- And then a pivotal moment comes along where they make a single decision (which they continue to reinforce over time)
- That decision then leads them to very different places after a long enough time

**Example 1**: Two college freshmen who have never before cheated on a test

- The two students have pretty much the same attitude about cheating — i.e., Not a good thing to do, but it’s not the worst sin in the world
- During their exam, they draw a blank on a crucial question which will not only determine their grade on the exam, but perhaps have larger (perceived) consequences of not getting into med school (for example)
- Suddenly, they are given the opportunity to cheat
- **This is the pivotal moment** — One student cheats, and one student doesn’t cheat
- *What happens next?*
  - They now have to put their behavior and their attitude toward cheating into consonance with their respective decision
  - The one who cheated will now modify their original point of view on cheating to now say, “Cheating isn’t such a bad thing. It’s just a victimless crime.”
  - The one who resisted cheating will now feel even more strongly that cheating is wrong and unfair—”It’s not a victimless crime. What about all the people who don’t cheat and work hard and learn the material?”
  - Over time, their attitudes about cheating and their self-justifications for their own behavior will keep reinforcing

*The pyramid metaphor*:

- They start out at the top side by side, but by the time they have finished justifying, one step at a time, their own behavior… they now stand at the bottom of the pyramid **very far apart** from each other
- It also illustrates how hard it is to go back to the top and say “That first decision was the wrong one” after all that time justifying your decision

A visual representation of the pyramid metaphor:

![](https://peterattiamd.com/wp-content/uploads/2020/09/pyramid-1-1024x769.png)

![](https://peterattiamd.com/wp-content/uploads/2020/09/pyramid-2-1024x770.png)

![](https://peterattiamd.com/wp-content/uploads/2020/09/pyramid-3-1024x772.png)

**Figure 2. A visual of the pyramid metaphor.**

*Are we doomed to cognitive dissonance*?

- No matter which way you choose, you cannot escape cognitive dissonance — which is then followed by self-justification which changes the attitude enormously
- For the student who cheats, the dissonance is, —
  - “I am an honest person, and yet I’m committing a dishonest act” …
  - Therefore, to reduce dissonance, he must think, “That act isn’t so very important because everybody would do it.”
- For the person who resists the temptation to cheat, the cognitive dissonance is, —
  - “*I could have gotten a really good grade in this course, and that would have allowed me to go to medical school, and I chose not to do it.*” …
  - Therefore, he must now think to himself, “*It would have been a horrible crime if I had cheated*”

*Real life example*: 71 students were [caught exchanging exam answers](https://www.nytimes.com/2012/09/26/education/stuyvesant-high-school-students-describe-rationale-for-cheating.html)

- They gave the New York Times reporter a litany of perfect self-justifications, which allowed themselves to keep seeing themselves as smart students of integrity.
- Self-justifications included—
  - Redefining cheating as taking a risk — “You can study for two hours and get an 80, or you can take a risk and get a 90.”
  - Calling cheating was a “necessary evil”.
  - Or making it into a way to help others — e.g., they were just helping classmates in need

\*\*\*

**Example 2: “Testilying” – cops planting evidence [1:17:00]**

A cop can make a decision to plant evidence in a scenario where the person was obviously guilty, but that decision can lead to planting evidence on people who are clearly innocent down the road

- Here’s how:
  - **Cop A** breaks into a known crack house
  - After the battering ram goes through the door, he can see the plume of smoke
  - Cop A chases a guy who runs into the bathroom and he watches as he shovels the drugs into the toilet as he flushes it
  - In that situation, when Cop A is certain they did have the drugs, he makes the decision to plant that cocaine right on that guy, and he makes the arrest and he finally has his bad guy
  - Carol says,
    - “*Because of what I know about how the human mind works, I also know that once he takes that step of planting cocaine that he didn’t actually find there, it makes the next step and the step after that a lot easier*.”
    - “*The next thing you know, there’s a totally innocent person who has been framed for a crime he didn’t commit*.”

⇒ See [Mark Fuhrman](https://en.wikipedia.org/wiki/Mark_Fuhrman) from the OJ Simpson trial

\*\*\*

**Explaining puzzling behavior**:

- We look at people very often who are at the bottom of the pyramid and we don’t think about all the time and effort that they put into justifying their behavior along the way
- This is why their behavior seems really puzzling to us at a distance, but it makes far more sense when we see it in terms of this one step at a time

**\*Upshot**: People are much more likely to go down the wrong path and continue reinforcing their beliefs when they have tied their **identity** to those beliefs

⇒ Check out one of Elliot’s great experiments: [The effect of severity of initiation on liking for a group](https://www.fpce.uc.pt/niips/novoplano/mip1/documentos/newAronson/aronson&mills1959.pdf) (Aronson and Mills, 1959)

## Cognitive dissonance in the police force [1:21:00]

**Cognitive dissonance in police departments**

- In police forces during interaction with the public, the presence of somebody who is behaving ethically is **dissonant** to someone who is not behaving ethically.
- The “bad cop” will think, “*I don’t like you. You’re reminding me that I’m doing something that I shouldn’t be doing if I were an ethical person*.”
- Because people don’t like the feeling of cognitive dissonance, these “ethical guys” can get ostracized by the culture of some police departments
- The consequences of this were seen in the [George Floyd case](https://en.wikipedia.org/wiki/Killing_of_George_Floyd) where fellow officers may have been afraid to interfere with the most brutal cop for fear of being ostracized by their fellow cops

*How much does this culture figure into police racism and police brutality?*

- Elliot says he thinks racism in the police department is a very complex issue
- But it begins with a false correlation—
  - Since most street crimes happen in poor neighborhoods containing minorities, many policemen have learned that those dangerous neighborhoods with a lot of street crimes are often caused by black people
  - They become suspicious of ALL black people which can lead to “brutal” behavior toward them
  - Elliot says, “*It’s understandable, but not justified, that they behave that way.*”

> “Cognitive dissonance can get us into trouble, because each step you take down that pyramid, you justify it until, by the time you reached the bottom, you don’t recognize yourself anymore. —Elliot Aronson

*How our social network shapes our behavior*:

- Seattle study carol mentions—The drug crime definition resulted in many more African Americans being arrested compared to whites
- This law/definition has powerful racist consequences
- But at the level of an *individual officer*, he’s just doing his job and thinking to himself, “*By arresting this guy for crack, I’m not personally a racist*.”

> “Every individual is embedded in a social network, taking their cues from that network and justifying their behavior in order to remain a part of that network.” —Carol Tavris

## A toolkit for overcoming cognitive dissonance [1:27:30]

**Examples of “success stories” where people have recognized their cognitive dissonance**

*Space Shuttle Columbia Disaster*

- [Wayne Hale](https://en.wikipedia.org/wiki/Wayne_Hale) is the guy who made the “go” decision on the [Space Shuttle Columbia Disaster](https://en.wikipedia.org/wiki/Space_Shuttle_Columbia_disaster)
- After the crash, his initial response was defending the decision, “Look, no launch is perfect. There are always little problems, and you have to learn which ones to ignore.”
- But, he literally stopped himself in mid-sentence and said, “But, you know, when I look at it, I have to say at this point I wish I had been more cautious. The weight of the evidence was to abort the launch just before it started, but I made the wrong decision and I’m dreadfully, dreadfully, sorry.”
- Elliot calls this act by Hale as courageous
- Carol adds,
  - “*It’s immensely powerful when one is able to catch themselves*.”
  - Generally speaking, “*the reaction of those around you is not going to be critical, it’s going to be grateful.*”

**How understanding cognitive dissonance helps us**

- The minute we make a tough decision (buy a car, to get married, etc.), we’re going to be motivated to throw support for that decision and ignore evidence that we’re wrong
- If we understand this about ourselves, in return you get a whole new toolbox of ways of dealing with our own beliefs and attitudes.

> “The more people understand about how cognitive dissonance operates, and how we are all susceptible to it, the more helpful it is in understanding our own behavior.” —Carol Tavris

\*\*\*

**The toolbox for dealing with cognitive dissonance**:

- First, the ability to not only recognize you made a mistake
- Secondly, to know that mistake doesn’t make you a stupid or immoral person
- Finally, to learn from that mistake, and make amends if that mistake harmed someone

\*\*\*

When you do make a decision that might look be wrong… the key is to apply **self-reflection** rather than **self-justification**

- *Self-reflection*
  - The more difficult process
  - It requires thinking, “What kind of a person am I who has done this particular thing?”
- *Self-justification*
  - The easier route to take
  - It means digging in your heels and justifying your decision at all costs
  - But as we’ve seen, one step at a time, that can lead us down the wrong path to a place you didn’t know you could ever get to

> “Self reflection is, ‘I did a stupid thing. Why did I do that? How could I learn something from that?’ That’s our recommendations for the way to go.” —Elliot Aronson

## Importance of separating identity from beliefs, thinking critically, & and the difficulty posed by political polarity [1:30:30]

**Carol and Elliot’s 2007 book,** [**Mistakes Were Made (But Not By Me**](https://www.amazon.com/Mistakes-Were-Made-But-Not/dp/1491514132)**):**

- In Elliot’s memoir, [Not by Chance Alone](https://www.amazon.com/Not-Chance-Alone-Elliot-Aronson/dp/0465031390), he said clinical psychology (i.e., therapy) is about repair, whereas social psychology is about change.
- Carol calls that the “**guiding principle**” of their book, Mistakes Were Made (But Not By Me)—
  - It’s an examination and indictment of so many institutions here (the therapy world, criminal justice, family relationships)
  - **By understanding the psychology of cognitive dissonance, we realize that we do have the power to change**.

*Fast forward to 2020…*

- With what’s going on in terms of populism, racism, and a greater polarization within our political system…
- *Are Carol and Elliot more or less optimistic today?*
- *And how much is cognitive dissonance factoring into what really looks upsetting and ugly in today’s discourse?*

*Carol’s take on the current environment*:

1 — One problem is the **hard polarization of the political parties**

- In the introduction to the [book revision](https://www.amazon.com/Mistakes-Were-Made-but-Third-dp-0358329612/dp/0358329612/ref=mt_other?_encoding=UTF8&me=&qid=), they quote Bob Dole [saying](https://www.youtube.com/watch?v=EOAOmQA-77s), “*Bill Clinton is my opponent, not my enemy*.”  —  a concept that is lost in the discourse of 2020

2 — Another problem is that **political identity** has come to have a primary importance for people

- By making the views of a particular political party part of your personal identity, it makes it incredibly hard to change your point of view if evidence warrants it

> “If political parties have become the central part of people’s identities, then by definition it makes it very hard to accept any evidence that somebody from the other party might have a good idea.” —Carol Tavris

*Optimism*:

- Readers of their book have produced meaning changes for people
- Often after really digesting the information in the book, readers realize their own biases and cognitive dissonance

> “The ultimate blind spot is the belief that ‘I don’t have a blind spot. And if only people would see it my way, then they could arrive at the reasonable solution to any problem.’ But what people often discover is that the blind spot is in me.” —Elliot Aronson

**Importance of separating identity from beliefs and the use of critical thinking**

- Peter likes the work of [Marsha Linehan](https://behavioraltech.org/about-us/trainers-consultants/marsha-linehan-phd-abpp/) and her work on [Dialectical Behavioral Therapy](https://www.psychologytoday.com/us/therapy-types/dialectical-behavior-therapy) (DBT)
- Her message: **The more we can distance our identities from our actions, the easier it is to hold and sit in the discomfort**.

*Peter’s personal practice:*

- Peter speaks to himself daily as a tool for uncoupling his achievements from his feeling of self worth and identity
- Peter says it has been “*a powerful tool for me to uncouple what I do from who I am.*”

*The pitfalls of identity politics*:

- When our political identities become our personal identities, we lose the ability to think critically when information is presented
- Instead, we start to think that whatever the “other” person says is wrong, and any action they take can be seen in a negative light
- The antidote to this may be the standardization of **formal logic and scientific methodologies**

\*\*\*

Watch Richard Feynman’s beautiful explanation of the scientific method:

\*\*\*

Elliot adds the following…

- There is “*beauty in rooting for the null hypothesis, which is really hard to do, but it’s what we have to do*”
- Our public educational system has failed us
- Critical thinking has to be taught in junior high school and high school in this country
- “People have to learn how to separate bullshit from facts.”

## How to impart the lessons from their work into future generations [1:48:00]

*What is it from your work that I could impart to my daughter who is 11 years old to give her the best shot at having a tool of being the kind of person that is* ***comfortable sitting in discomfort****,* ***making these hard decisions****, and* ***being able to change her mind*** *when the facts call for it?*

Elliot’s primary tip**: Modeling**

- In the home, you behave in a way that you want your child to behave when your child is your age

*Elliot’s personal story about modeling*:

- Growing up, his father would often explode in rage and storm out of the house when their mother would bring up any grievances
- When Elliot grew up and got married he found himself modeling that same exact behavior (which he detested in his father)
- He gradually taught himself that getting angry and raising his voice was not the best way to deal with these scenarios
- Instead, he’s adopted the process of…
  - Letting go
  - Using reasonable, rational discussions
  - Stating of feelings (both positive and negative) whenever they become apparent
- “*That became a model for our kids, because the way we relate to each other is now pretty standard in our family*.”

**What can we do to make thinking scientifically more interesting to children?**

- As human beings, we think in stories, says Carol
- Storytelling is our way of understanding the world, explaining the world and making the world interesting.
- Science tells us **which stories are better than others**.
- But when science is presented as a series of findings, it loses its interest
- But when it’s told as a story in which the discovery is something that changed us, it’s more compelling

⇒ Carol’s favorite example—The story of [Ignaz Semmelweis](https://en.wikipedia.org/wiki/Ignaz_Semmelweis) and his observations about why the women in his hospital were dying of childhood fever

- He made the simple observation that students might be carrying something deadly on their hands having just done autopsies on women who died the day before (which ended up being correct)
- What was fascinating to Carol was not just that Semmelweis had found the reason that the women were dying, it was that his fellow doctors ridiculed him and claimed he was crazy
- The other docs and scientists couldn’t accept such a simple explanation—A perfect example of the theory of cognitive dissonance
- Semmelweis was eventually put into an insane asylum where he died never being vindicated

Carol says the story of Ignaz Semmelweis is an amazing story, with all of the elements —

- the psychological story of his fellow scientists who didn’t want to believe him (which is really the story of history – think how Galileo’s theories were perceived)
- It presents both the excitement of scientific discovery and the challenges

> “Whether you are conscious or unconscious of this thing, it is with you. So we are probably better off being conscious of it and having some measure of control and thought around it than we are ignoring it.” —Peter Attia

⇒ See this beautiful [commencement speech](https://www.youtube.com/watch?v=8CrOL-ydFMI) by [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace)

§

## Selected Links / Related Material

**Carol’s previous appearance on The Drive discussing hormone replacement therapy**: [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) | Peter Attia (peterattiamd.com) [1:00]

**Carol and Elliot’s book**: [Mistakes Were Made (But Not by Me): Why We Justify Foolish Beliefs, Bad Decisions, and Hurtful Acts](https://www.amazon.com/Mistakes-Were-Made-but-Third-dp-0358329612/dp/0358329612/ref=mt_other?_encoding=UTF8&me=&qid=) by Carol Tavris and Elliot Aronson | (amazon.com) [1:00]

**Elliot’s book**: [The Social Animal](https://www.amazon.com/gp/product/1429233419/ref=dbs_a_def_rwt_bibl_vppi_i6) by Elliot Aronson | (amazon.com) [6:15]

**A study looking at pregnant women who smoke and rationalize their dissonance**: [A qualitative analysis of messages to promote smoking cessation among pregnant women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4248080/) (Hoek et al., 2014) [14:45]

**Study showing that simply using fMRIs in a lecture makes people think your research is more scientific**: [The Seductive Allure of Neuroscience Explanations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2778755/) (Weisberg et al., 2008) [28:45]

**Study showing what was going on in the brains of people confronted with dissonant information about someone from their own political party**:  [Neural Bases of Motivated Reasoning: An fMRI Study of Emotional Constraints on Partisan Political Judgment in the 2004 U.S. Presidential Election](https://birc.jaredjustus.com/assets/publications/Westen,%20Kilts%202006%20J%20Cognit%20Neurosci.pdf) (Westen et al., 2006) [29:00]

**Studies comparing what causes dissonance in Japan or the United States**: [On the Cultural Guises of Cognitive Dissonance: The Case of Easterners and Westerners](https://pdfs.semanticscholar.org/c99c/c784701ef52d9d15f6d7616caa0be4b8e0b1.pdf) (Hoshino-Browne et al., 2005) [31:00]

**Case studies of cognitive dissonance in criminal justice**:

- [Amanda Knox](https://en.wikipedia.org/wiki/Amanda_Knox) | (wikipedia.org) [38:30]
- [Duke lacrosse case](https://en.wikipedia.org/wiki/Duke_lacrosse_case) | (wikipedia.org) [39:30]
- [Central Park jogger case](https://en.wikipedia.org/wiki/Central_Park_jogger_case) | (wikipedia.org) [41:30]

**Non-profit fighting for innocent people put in prison**: [The Innocence Project](https://www.innocenceproject.org/) | (innocenceproject.org) [43:00]

**The child abuse case study revealing the danger in jumping to conclusions based on preconceived notions**: [McMartin preschool trial](https://en.wikipedia.org/wiki/McMartin_preschool_trial) | (wikipedia.org) [43:30]

**Sarah Silverman video that shows the pain of dissonance**: [Sarah Silverman Comments on Sexual Harassment](https://www.youtube.com/watch?v=_WKFDqxiL80&feature=emb_logo) | I Love You, America (youtube.com) [46:30]

**Carol’s regrettable op ed for the LA Times during the McMartin trial**: [McMARTIN TRIAL: The Search for Credibility : Do Children Lie? Not About This](https://www.latimes.com/archives/la-xpm-1990-01-19-me-112-story.html) [49:45]

**An article by Carol about the pitfalls of recovered memory therapy**: [The Persistence of Memory… and of the Memory Wars](https://www.skeptic.com/reading_room/persistence-of-recovered-repressed-memory-movement/) | Carol Tavris (skeptic.com) [58:30]

**The hysteria that swept the country in which daycare workers were accused of ritual, sexual molestation of children (and appeared on the cover of Ms. Magazine)**: [Michelle Remembers and the Satanic Panic](https://therevealer.org/michelle-remembers-and-the-satanic-panic/) | Megan Goodwin (therevealer.org) [59:00]

**A case very similar to the McMartin case which Carol tried to atone for her wrongdoings related to the McMartin case**: [Gerald Amirault](https://en.wikipedia.org/wiki/Gerald_Amirault) | (wikipedia.org) [1:00:15]

**Social psychologist Deborah Davis has shown that a person doesn’t have to be “lying” to be wrong in making an allegation**: [Remembering Disputed Sexual Encounters: A New Frontier for Witness Memory Research](https://scholarlycommons.law.northwestern.edu/cgi/viewcontent.cgi?article=7571&context=jclc) | Deborah Davis and Elizabeth Loftus, 2015, Journal of Criminal Law and Criminology (northwestern.edu) [1:01:45]

**Book that Peter read resulting in him being struck by how feeble his memory could be**: [Being Wrong: Adventures in the Margin of Error](https://www.amazon.com/Being-Wrong-Adventures-Margin-Error/dp/0061176052) by Kathryn Schulz | (amazon.com) [1:02:30]

**The wonderful children’s book that Carol mis-remembers her father reading to her**:: [The Wonderful O](https://www.amazon.com/Wonderful-York-Review-Childrens-Collection/dp/1590173090) by James Thurber | (amazon.com) [1:04:30]

**71 students were caught exchanging exam answers and justified their behavior**: [Stuyvesant Students Describe the How and the Why of Cheating](https://www.nytimes.com/2012/09/26/education/stuyvesant-high-school-students-describe-rationale-for-cheating.html) | Vivian Yee (nytimes.com) [1:16:00]

**Elliot’s “initiation experiment”**: [The effect of severity of initiation on liking for a group](https://www.fpce.uc.pt/niips/novoplano/mip1/documentos/newAronson/aronson&mills1959.pdf) (Aronson and Mills, 1959) [1:19:30]

**Elliot’s memoir**: [Not by Chance Alone: My Life as a Social Psychologist](https://www.amazon.com/Not-Chance-Alone-Elliot-Aronson/dp/0465031390) by Elliot Aronson | (amazon.com) [1:35:30]

**The autobiography of George Bush which Peter read**: [Decision Points](https://www.amazon.com/Decision-Points-George-W-Bush/dp/0307590631) by George W. Bush | (amazon.com) [1:36:30]

**Bob Dole saying, “Bill Clinton is my opponent, not my enemy.”**: [USA: PRESIDENTIAL ELECTIONS: BOB DOLE CONCEDES DEFEAT](https://www.youtube.com/watch?v=EOAOmQA-77s) | AP Archive (youtube.com) [1:38:00]

**Richard Feynman’s beautiful lecture explaining what an experiment means**: [Richard Feynman on Scientific Method (1964)](https://www.youtube.com/watch?v=0KmimDq4cSU&feature=emb_title) | Soccer Man (youtube.com) [1:45:30]

**Beautiful commencement speech by David Foster Wallace**: [This Is Water – Full version-David Foster Wallace Commencement Speech](https://www.youtube.com/watch?v=8CrOL-ydFMI) | Jamie Sullivan (youtube.com) [1:56:15]

§

## People Mentioned

- [Avrum Bluming](https://peterattiamd.com/caroltavris-avrumbluming/) [1:00]
- [Leon Festinger](https://en.wikipedia.org/wiki/Leon_Festinger) [1:45, 11:45, 17:00]
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) [7:45]
- [Merrill Carlsmith](https://en.wikipedia.org/wiki/Merrill_Carlsmith) [20:15]
- [Michael Kahn](https://www.legacy.com/obituaries/marinij/obituary.aspx?n=michael-kahn&pid=172024369) [24:45]
- [Drew Westen](https://psychology.emory.edu/home/people/faculty/westen-drew.html) (fMRI brain studies) [28:45]
- [Amanda Knox](https://en.wikipedia.org/wiki/Amanda_Knox) (wrongly accused of murder) [38:30]
- [Linda Fairstein](https://en.wikipedia.org/wiki/Linda_Fairstein) [41:30]
- [Sarah Silverman](https://en.wikipedia.org/wiki/Sarah_Silverman) [46:30]
- [Louis C.K.](https://en.wikipedia.org/wiki/Louis_C.K.) [46:30]
- [Stephen Ceci](https://www.human.cornell.edu/people/sjc9) [50:00]
- [Deborah Davis](https://www.unr.edu/psychology/faculty/deborah-davis) (social psychologist) [1:01:45]
- [Judson Mills](https://www.legacy.com/obituaries/washingtonpost/obituary.aspx?n=judson-r-mills&pid=109101008&fhid=3368) [1:15:15]
- [Mark Furhman](https://en.wikipedia.org/wiki/Mark_Fuhrman) [1:18:30]
- [Jeb Stuart Magruder](https://en.wikipedia.org/wiki/Jeb_Stuart_Magruder) [1:19:00
- [George Floyd](https://en.wikipedia.org/wiki/George_Floyd) [1:23:45]
- [Wayne Hale](https://en.wikipedia.org/wiki/Wayne_Hale) [1:28:45]
- [Shimon Peres](https://en.wikipedia.org/wiki/Shimon_Peres) 1:33:00]
- [Ronald Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) [1:33:00]
- [Bob Dole](https://en.wikipedia.org/wiki/Bob_Dole) [1:38:00]
- [Bill Clinton](https://en.wikipedia.org/wiki/Bill_Clinton) [1:38:00]
- [Marsha Linehan](https://behavioraltech.org/about-us/trainers-consultants/marsha-linehan-phd-abpp/) [1:42:00]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) [1:45:30]
- [Ignaz Semmelweis](https://en.wikipedia.org/wiki/Ignaz_Semmelweis) [1:53:30]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) [1:56:15]

§

![](https://peterattiamd.com/wp-content/uploads/2020/09/tavris-and-aronson-sidebyside-800x600-1-500x500.png)

##### Carol Tavris, Ph.D. & Elliot Aronson, Ph.D

Carol Tavris, Ph.D.

Carol Tavris received her Ph.D. in social psychology from the University of Michigan. Her books include Mistakes Were Made (But Not by Me), with Elliot Aronson; Anger: The Misunderstood Emotion, and The Mismeasure of Woman. She has written articles, op-eds, and book reviews on topics in psychological science for a wide array of publications — including the Los Angeles Times, the New York Times Book Review, the Wall Street Journal, and the TLS — and a column, “The Gadfly,” for Skeptic magazine. She is a fellow of the Association for Psychological Science and has received numerous awards for her efforts to promote gender equality, science, and skepticism.

Elliot Aronson, Ph.D.

Elliot Aronson is an American psychologist who has carried out experiments on the theory of cognitive dissonance. He is the only psychologist to have won the American Psychological Association highest awards in all three major academic categories: Distinguished service in writing in 1973, distinguished teaching in 1980, and distinguished research in 1999. And in 2002, he was listed among the 100 most eminent psychologists of the 20th century.