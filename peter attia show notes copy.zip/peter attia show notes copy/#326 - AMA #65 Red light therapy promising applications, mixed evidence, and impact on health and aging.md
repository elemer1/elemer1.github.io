# #326 – AMA #65: Red light therapy: promising applications, mixed evidence, and impact on health and aging

**Source:** [https://peterattiamd.com/ama65/](https://peterattiamd.com/ama65/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives into the world of red light therapy in response to frequent questions from listeners. Peter provides a comprehensive exploration, starting with the basics of red light therapy and why it’s getting so much attention. The conversation examines the latest data on various applications, including aging, skin health, acne, wound healing, hair loss, eye health, exercise performance, metabolic health, weight loss, inflammation, injury recovery, and menstrual cramps. Peter analyzes the scientific literature on each use case and concludes with a summary table that provides an easy-to-follow breakdown of the potential benefits of red light therapy across these areas.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #65 show notes page](https://peterattiamd.com/ama65). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of topics and the motivation behind exploring red light therapy [1:45];
- The basic science of red light therapy [3:15];
- The unique penetration properties of red light [6:00];
- What happens when tissue is exposed to red light [9:30];
- Exploring red light therapy’s potential to combat aging [11:00];
- Red light therapy for treating acne [13:00];
- Red light therapy for aiding in wound healing [18:45];
- Red light therapy for hair loss: promising benefits and practical advice [24:15];
- Analyzing the evidence of a positive or negative effect of red light therapy on the eyes [28:00];
- Red light therapy’s impact on performance and recovery [30:30];
- Red light therapy’s impact on metabolic health: analyzing the limited evidence for improved glucose metabolism [32:45];
- Red light therapy for weight loss and targeted fat reduction [36:45];
- Red light therapy for inflammation, chronic pain, and injury rehabilitation [41:00];
- Red light therapy as a treatment for menstrual cramps [43:45];
- Summary: promising applications of red light therapy, unsupported claims, and costs to consider [46:45]; and
- More.

---

The Peter Attia Drive

#326 – AMA #65: Red light therapy: promising applications, mixed evidence, and impact on health and aging

---

## Show Notes


---

## Overview of topics and the motivation behind exploring red light therapy [1:45]

In today’s AMA, we are going to focus on a single topic: red light therapy

- The plan is to cover:
  - what red light therapy is
  - how it can work
  - dive into some various claims out there around red light therapy such as:
    - potential effect on skin health
    - wound healing
    - hair loss
    - Eyesight
    - Exercise
    - performance and recovery
    - metabolic health
    - fat loss
    - Inflammation
    - chronic pain
    - and a lot more.

## The basic science of red light therapy [3:15]

**Introduction to Light and Wavelengths**

- Light as waves:
  - Light exists as waves, which are generally very short compared to other waves, like sound.
  - Sound waves are relatively long, while light waves are much shorter.
- Shorter wavelengths mean higher energy:
  - As wavelength decreases, the energy of the wave increases.
  - For example:
    - UV light has shorter wavelengths and thus more energy than visible light.
    - X-rays and gamma rays are even shorter and carry even more energy.

![](https://peterattiamd.com/wp-content/uploads/2024/11/f1-ama65-1024x601.png)

**Figure 1.** *Source:* [*Apni Physics*](https://apniphysics.com/electromagnetic-spectrum/)

**Visible Light Spectrum**

- Range of visible light:
  - Visible light spans wavelengths from approximately 380 to 780 nanometers.
  - Different colors correspond to different wavelengths within this range:
    - 380 nm: Violet (shortest wavelength in the visible spectrum)
    - 780 nm: Red (longest wavelength in the visible spectrum)
- Red light in context:
  - Red light is found at the longer end of the visible light spectrum, around 620-780 nanometers.
  - Red light therapy utilizes this specific narrow range of red light.

**Red Light Therapy and Phototherapy**

- Definition of Red Light Therapy:
  - Red light therapy specifically refers to light in the 620-780 nm range.
  - This red wavelength is more narrowly focused than white light, which includes a mixture of all visible wavelengths.
- Phototherapy:
  - Phototherapy broadly includes treatments across the full range of visible light.
  - It may also use near-infrared (NIR) light, which falls just outside the visible spectrum.

**Near-Infrared (NIR) Light**

- Characteristics of NIR:
  - Near-infrared light has wavelengths between approximately 790 and 1400 nanometers.
  - Unlike red light, NIR is invisible to the human eye.
- Role in red light therapy:
  - Near-infrared light is often used in conjunction with red light for therapeutic purposes.
  - NIR wavelengths are slightly longer than red light, providing different penetration and effects.

**Safety Considerations and Visibility**

- Visibility and potential risks:
  - The fact that NIR light is invisible can present safety challenges.
  - Invisible light might carry risks that are less obvious, as users cannot see its intensity or presence.

## The unique penetration properties of red light [6:00]

**Penetration Depth and Wavelength**

- Comparison to UV Light:
  - Like with UVA and UVB in ultraviolet light, red light therapy’s effectiveness depends on its penetration depth.
    - [See AMA #61 for more](https://peterattiamd.com/ama61/)
  - Longer wavelengths, like red light, can penetrate more deeply than shorter wavelengths, though with less energy.
- “Sweet Spot” of Red Light:
  - Red light occupies a “sweet spot” in the spectrum where it penetrates more than other visible light forms but still has limited energy.
  - This balance makes red light potentially interesting for certain therapeutic applications.

**Factors Influencing Light Penetration**

- Coherence:
  - Coherence refers to how well the light waves align in phase, with their peaks and valleys synchronized.
  - Higher coherence increases penetration, making the light more focused and effective in reaching deeper layers.
- Collimation:
  - Collimation describes how parallel the light rays are.
  - When light is highly collimated, it doesn’t spread out and instead directs energy precisely, increasing penetration depth.
- Intensity:
  - The strength or intensity of the light, often measured in watts or joules, also plays a role in penetration.
  - Watts measure power, while joules measure the total energy delivered over time.

**Practical Penetration Depths by Light Source**

![](https://peterattiamd.com/wp-content/uploads/2024/11/f2-ama65-1024x363.png)

**Figure 2.** LASER (A), Single-LED (B), or Multiple-LED Array (C) comparison. The laser beam is shown as a coherent and collimated beam that loses these properties when it enters the tissues, while the LEDs lacks these characteristics. The LED array emphasizes the increased beam intensity (which partly overcomes LED lack of tissue penetration) and larger area of tissue coverage that significantly improves its utility compared with the more efficient laser LLLT device.*Source:* [*Mosca et al., Advances in skin & wound care 2019*](https://journals.lww.com/aswcjournal/FullText/2019/04000/Photobiomodulation_Therapy_for_Wound_Care__A.3.aspx)

- LED Red Light: LED red light can penetrate only about 2-3 millimeters into the skin.
- Infrared Light: Infrared, with a longer wavelength than red light, can penetrate slightly deeper, reaching 5-10 millimeters.
- Laser Red Light: Laser-delivered red light is more focused and can penetrate much deeper, ranging from 1 to 4 centimeters.

![](https://peterattiamd.com/wp-content/uploads/2024/11/f3-ama65.png)

**Figure 3.** Penetrating depth of various electromagnetic wavelengths into skin. Even the red, near infrared, and infrared wavelengths penetrate only a few millimeters into skin. *Source:* [*Cios et al., Int J Mol Sci. Feb 2021*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7957604/)

**Implications for Therapeutic Applications**

- Superficial Effectiveness:
  - Due to its limited penetration, red light therapy is more likely to affect superficial tissues rather than deeper structures.
  - Applications targeting skin or other surface-level issues may see some benefit from red light therapy.
- Limitations for Deeper Impact:
  - Claims suggesting significant effects on deeper tissues are less plausible, as even deeper penetration of 10 millimeters or 1 centimeter is unlikely to reach internal organs or major muscle groups effectively.
- ***General Rule of Thumb***: The closer the target is to the surface, the more feasible red light therapy may be as a treatment option.

## What happens when tissue is exposed to red light [9:30]

Absorption by Chromophores:

- For red light to produce any biological effect, it must be absorbed by photosensitive molecules within the cell, known as chromophores.
- This absorption triggers a localized chemical or photochemical reaction.

Role of Cytochrome c Oxidase (CCO)

- Cytochrome c oxidase (CCO) is a component of the electron transport chain within mitochondria and is critical for cellular energy production.
- CCO is one of the primary chromophores targeted by red light therapy.
- Effect of Red and Near-Infrared Light on CCO:
  - Red and near-infrared light appear to stimulate or “excite” CCO, enhancing its activity.
  - This excitation of CCO leads to increased production of ATP, the cell’s main energy source
- In contrast to red and near-infrared light, blue and green wavelengths are shorter, less penetrative, but more powerful.
- These shorter wavelengths tend to decrease CCO activity and subsequently reduce ATP production.

“*Most people who are proponents of red light therapy point to cytochrome c oxidase, or CCO, as the main target, and therefore the mediating effect of the biologic impact of red light*.” —Peter Attia

## Exploring red light therapy’s potential to combat aging [11:00]

**Overview of Red Light Therapy and Aging**

- The Question of Anti-Aging:
  - The broad answer is that red light therapy is unlikely to combat aging in humans as a whole.
  - While certain cellular studies show potential, these findings don’t translate effectively to whole-body benefits in humans.

**Cell Culture Studies on Red Light Therapy and Aging Markers**

- [Study 1](https://link.springer.com/article/10.1186/s12964-023-01152-x): Stem Cells from Adipose Tissue:
  - Stem cells derived from adipose (fat) tissue were exposed to red light wavelengths of 630-635 nm and 660-670 nm.
  - Result: Cells showed reduced expression of genes associated with cellular senescence, a hallmark of aging.
- [Study 2](https://www.nature.com/articles/s41598-021-92584-3): Mesenchymal Stem Cells from Mouse Bone Marrow:
  - These cells, treated with near-infrared light (just over 800 nm), exhibited:
    - Improved mitochondrial respiratory capacity.
    - Reduced markers of cellular senescence.
    - Enhanced proliferation, or cell growth.
- [Study 3](https://pubmed.ncbi.nlm.nih.gov/31981991/): Cultured Human Fibroblasts:
  - Human fibroblasts exposed to 660 nm red light showed:
    - Improved inflammatory signaling, which can contribute to healthier cell function and reduced aging markers.
- Limitations and Practical Implications
- Localized Effects in Cell Cultures:
  - These studies involve cultured cells in controlled environments, which allows red light to reach all cells directly.
  - Positive results in cell cultures do not guarantee similar effects in human tissues.

Challenges for Whole-Body Impact:

- For most tissues within the human body, red light from external sources cannot penetrate deeply enough to produce significant anti-aging effects.

Conclusion on Whole-Body Efficacy:

- While these findings in cell studies may look promising, they do not imply that red light therapy could produce anti-aging effects on a whole-body level in humans.

## Red light therapy for treating acne [13:00]

**Overview of Red Light Therapy for Skin Health**

- Best Characterized and Most Promising Effects:
  - Red light therapy shows the most promise and best-documented effects when applied to skin health.
  - Given that red light can penetrate up to 4 millimeters, it is well-suited for treating surface-level conditions like acne and skin wounds.
- Limitations for Deeper Tissues:
  - While red light therapy can be effective for the skin, it’s impractical for deeper tissues, as it cannot reach internal organs, such as the heart.

**Red Light Therapy for Acne**

- Combination with Blue Light: Red light therapy is often combined with blue light therapy for acne treatment, as this combination has proven effective in several randomized controlled trials (RCTs).
- Benefits over pharmacologic treatments: May serve as a safer alternative to systemic drugs like Accutane, which carry significant side effects and contraindications, especially for pregnant women.

*Mechanism of Action for Acne Treatment*

- Bacterial Targeting:
  - Acne is caused by bacteria containing photosensitive molecules called porphyrins, which absorb light within the 400-700 nm range.
- Photoexcitation Process:
  - When exposed to blue and red light, porphyrins undergo photoexcitation, releasing free radicals and reactive oxygen species that kill the acne-causing bacteria.
- Why Both Blue and Red Light Are Used:
  - Blue Light: Primarily targets bacteria due to its higher absorption by porphyrins.
  - Red Light: Penetrates deeper than blue light, reaching below the skin’s surface and improving overall treatment effectiveness.

*Typical Protocol for Acne Treatment:*

- Light Wavelengths:
  - Red light: 630-670 nm
  - Blue light: 415-425 nm
- Light Source Types:
  - Most RCTs use lasers for maximum penetration, which are administered in-office by a dermatologist.
  - LED devices, such as home-use masks, are available but offer less penetration and may have variable effectiveness.
- Session Frequency and Duration:
  - Protocols vary widely in session length and frequency:
    - Ranges from 2 to 20 minutes per session, with some studies recommending weekly sessions and others suggesting twice-daily sessions.
  - In-office laser treatments are less frequent, while shorter, more frequent sessions are more feasible with home-use LED devices.

**Efficacy of Red and Blue Light Therapy for Acne**

- Clinical Results:
  - One [RCT](https://academic.oup.com/bjd/article-abstract/168/5/1088/6614346) demonstrated significant efficacy:
    - A 75% reduction in inflammatory acne lesions.
    - A 55% reduction in non-inflammatory lesions over a 12-week period.
    - Comparisons to control groups showed that light therapy significantly outperformed sham treatments.
- Comparison to Topical Treatments:
  - Light therapy was [found](https://academic.oup.com/bjd/article-abstract/142/5/973/6689980) to perform comparably to traditional topical treatments like benzoyl peroxide, making it a viable alternative for those who prefer non-pharmacologic options.

![](https://peterattiamd.com/wp-content/uploads/2024/11/f4-ama65-1024x512.png)

**Figure 4.** Results from a 12-week RCT comparing blue light therapy, combined blue-red light therapy, white light therapy, and 5% benzoyl peroxide for acne vulgaris. *Source:* [*Papageorgiou et al., The British journal of dermatology 2000*](https://pubmed.ncbi.nlm.nih.gov/10809858/)

## Red light therapy for aiding in wound healing [18:45]

**Overview of Wound Healing Process**

- Stages of Wound Healing:
  - Hemostasis: Initial stage where blood clotting occurs to prevent bleeding.
  - Inflammation: Inflammatory cells arrive to clear out damaged cells and bacteria.
  - Proliferation: New tissue, mainly collagen and extracellular matrix, forms to repair the wound.
  - Remodeling: Collagen organizes to increase tensile strength, restoring tissue to its original state.

**Role of Red Light Therapy in Wound Healing**

- Impact on Key Healing Stages:
  - Red light therapy seems beneficial during the inflammatory, proliferation, and remodeling stages.
- Cellular Mechanisms Enhanced by Red Light Therapy:
  - Macrophage Activity: Supports immune response and clearance of dead cells.
  - Fibroblast Proliferation: Increases fibroblast activity, promoting tissue formation.
  - Growth Factor Release: Enhances cell growth and repair.
  - Collagen Synthesis and Keratin Production: Strengthens new tissue.
  - Angiogenesis: Stimulates the formation of new blood vessels to support healing.

**Types of Wounds that May Benefit from Red Light Therapy**

- Burn Wounds:
  - Red light therapy may [aid in healing](https://pubmed.ncbi.nlm.nih.gov/29199384/) both the burn site and donor sites for skin grafts, such as from the thighs to hands or face.
- Chronic Non-Healing Wounds:
  - Common in diabetic patients, these wounds have [shown improvement](https://pubmed.ncbi.nlm.nih.gov/29668397/) with red light therapy.
- Post-Surgical Wounds:
  - Red light therapy can [support recovery and reduce healing time](https://pubmed.ncbi.nlm.nih.gov/30483937/) for wounds after surgery.

**Evidence and Limitations in Research**

- Historical Use and Recent Studies:
  - While phototherapy has been used anecdotally for wound healing for 40 years, only a few controlled human trials have been conducted in the last decade.
- Effectiveness in Clinical Studies:
  - Studies consistently show significant improvement in wound healing for chronic, post-surgical, and burn wounds compared to standard treatments.
- Need for Medical Supervision:
  - Due to varying protocols and energy dosages, red light therapy for wound healing should be supervised by a qualified medical professional, such as a dermatologist or plastic surgeon.

**Understanding Treatment Protocols and Dosage**

- Dosage Units and Measurement:
  - Dosages are often specified in watts per centimeter squared (W/cm²) and joules per centimeter squared (J/cm²).
  - Example Calculation:
    - If a study uses 100 mW/cm² for five minutes, this equals 30 J/cm² (100 mW × 300 seconds = 30 J).
- Importance of Correct Dosage and Expertise:
  - Proper dosage and understanding of energy units (watts vs. joules) are essential for effective treatment.
  - Inconsistent protocols mean that an experienced practitioner is crucial for customizing treatment to the specific wound type.

Caution Against DIY Red Light Therapy for Wound Healing

- Professional Application Recommended:
  - Due to the need for precise protocols and potential risks, DIY red light therapy is discouraged.
  - Ideal practitioners include dermatologists or plastic surgeons who have experience with these devices.

## Red light therapy for hair loss: promising benefits and practical advice [24:15]

See [AMA #63](https://peterattiamd.com/ama63/) for more about hair loss ftk

\*\*\*

**Overview of Red Light Therapy for Hair Loss**

- FDA Approval: Red light therapy is FDA-approved for treating androgenic hair loss in both men and women.
- Treatment Devices: Typically involves a laser light helmet or similar device positioned close to the scalp to deliver light directly to the hair follicles.

**Mechanism of Action**

- Stimulating Hair Follicles:
  - Red light therapy is thought to stimulate hair follicles by moving them from their resting phase (telogen) to their growth phase (anagen).
  - This shift is achieved by increasing cellular energy production within the hair follicles.

**Treatment Protocols and Dosage**

- Wavelength and Energy:
  - Effective wavelengths typically range from 630 to 690 nm.
  - Energy levels are around 1 to 10 joules per cm², with power density between 3 to 90 mW/cm².
- Frequency and Duration:
  - Standard protocol involves 15 to 20-minute sessions, three times per week over a six-month period.
  - Some studies suggest slightly longer sessions, such as 25 minutes every other day, can also be effective.

**Clinical Evidence and Effectiveness**

- Study Findings:
  - In one [16-week RCT](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7373546/), participants using red light therapy saw:
  - An increase of 42 hairs per cm².
  - An average increase in hair thickness of 7.5 microns.
- Perspective on Results:
  - For context, a person with 150-300 hairs per cm² is considered to have full hair density.
  - A noticeable difference is often observed when hair density drops below half this amount, making the 42-hair increase meaningful for those with hair loss.
- Combining Treatments:
  - Peter suggests combining red light therapy with other topical or systemic hair restoration treatments for optimal results.

**Potential Side Effects**

- Mild and Rare Side Effects:
  - Some patients may experience scalp irritation or redness, but side effects are generally rare.
- Considerations of Time and Cost:
  - Professional sessions range from $100 to $500 each, potentially adding up with frequent treatments.
  - Home devices are available for $200 to $2,000 but may vary in effectiveness compared to professional treatments.

**Advice on Choosing a Device**

- Professional vs. Home Use:
  - Peter advises consulting with professionals to ensure an integrated approach to hair restoration.
  - For those considering at-home devices, he recommends asking professionals to suggest a high-quality device that closely replicates the protocols used in clinics.
- Time Efficiency:
  - For individuals with limited schedules, an effective home device can be more practical than frequent clinic visits.

## Analyzing the evidence of a positive or negative effect of red light therapy on the eyes [28:00]

**Lack of Direct Evidence**

- No Controlled Trials (RCTs):
  - There are no randomized controlled trials specifically evaluating the effects of red light therapy on eye health.
- One Small [Study](https://www.nature.com/articles/s41598-021-02311-1#Tab1) on Color Sensitivity:
  - A study with 24 participants using 670 nm red light examined changes in color sensitivity.
  - Results showed a slight improvement in color sensitivity, allowing subjects to better discriminate between colors.
  - The study indicated that timing may play a role, with morning exposure (between 8-9 AM) being necessary to observe improvements in color sensitivity.
  - Afternoon exposure showed no effect, suggesting that the time of day could influence any potential benefits.
  - Peter’s take on this study: “*I’m not convinced that this is something I’d be out there chasing, morning red light therapy in the eyes to improve my color contrast detection*.”

**Risks of Direct Exposure to Red Light LEDs**

- Eye Protection Recommendations:
  - Most red light therapy device manufacturers recommend using eye protection to prevent direct exposure.
- Intensity Concerns:
  - The low-intensity light used in some studies is much weaker than the commercial red light therapy devices, such as red light beds, which are about 10 times more intense.
- Potential Risks of High-Intensity Light:
  - Looking directly at high-intensity red light sources, like those in red light beds, can pose a risk of eye damage.
  - Peter emphasizes not to assume that high-intensity red light exposure would be safe for direct viewing, as it may be harmful.

**Key Takeaway on Eye Health and Red Light Therapy**

- Minimal Evidence for Eye Benefits:
  - Although there are minor findings related to color sensitivity, these are not compelling enough to warrant red light therapy as an eye health treatment.
- Caution with Eye Safety:
  - Given the lack of evidence and potential risks, using red light therapy for the eyes is not advised without proper eye protection.

## Red light therapy’s impact on performance and recovery [30:30]

**Claims About Red Light Therapy for Performance and Recovery**

- Theory of ATP Generation:
  - Red and near-infrared light may boost ATP production, theoretically increasing energy availability for muscle performance.
- Cell Culture vs. Whole Body Application:
  - While ATP increase is observed in cell cultures, translating this to effective benefits in large muscle groups through external application is less plausible.

**Recent Research and Findings**

- Randomized Placebo-Controlled Trial on 5K Running Performance:
  - Recent [study](https://pubmed.ncbi.nlm.nih.gov/38819613/) on recreational runners tested red light therapy at different energy doses (300, 900, 1260 joules) using near-infrared LED.
  - Method:
    - Crossover design where participants received both control and treatment, with a two-week washout in between.
    - Red light was applied to the quadriceps, hamstrings, and calves.
    - Measurements included mean velocity, total time, and perceived exertion (RPE) for a 5K run.
  - Result: No significant differences were found between the control and treatment groups.
- Meta-Analysis of Exercise Performance Studies:
  - A recent [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/38758297/) examined various studies on red light therapy’s impact on exercise performance.
  - Findings:
    - Statistically significant but clinically insignificant improvements were noted.
    - Minor benefits were observed in inactive individuals and athletes, but not in those already physically active.

**Peter’s Overall Perspective on Red Light Therapy for Performance**

- Peter considers the claims of red light therapy’s benefits for performance and recovery to be a “stretch.”
- He finds the literature on this application much less convincing than for other uses of red light therapy.

## Red light therapy’s impact on metabolic health: analyzing the limited evidence for improved glucose metabolism [32:45]

**Theoretical Basis for Metabolic Benefits**

- Mechanism of Action:
  - The theory suggests that red or near-infrared light, by increasing ATP production in the mitochondria (via cytochrome c oxidase), could improve glucose disposal.
- Potential Impact:
  - This enhanced glucose disposal could, in theory, help regulate blood sugar levels and improve metabolic health.

[**Study**](https://onlinelibrary.wiley.com/doi/10.1002/jbio.202300521) **on Red Light Therapy and Glucose Disposal**

- Study Design:
  - 30 non-diabetic participants with borderline blood sugar levels underwent an oral glucose tolerance test (OGTT).
  - Participants returned within a week for either 15 minutes of red light therapy on their backs or a sham therapy, followed by another OGTT.
- Results:
  - Peak Glucose Reduction: Peak glucose levels decreased by 12%, from 195 mg/dL to 172 mg/dL, a statistically significant change but still high.
  - Glucose Area Under the Curve (AUC): AUC was reduced by about 7.3%, indicating a significant difference in overall glucose response.

![](https://peterattiamd.com/wp-content/uploads/2024/11/f5-ama65-1024x650.png)

**Figure 5.** *Source:* [*Powner and Jeffery, Journal of biophotonics 2024*](https://onlinelibrary.wiley.com/doi/10.1002/jbio.202300521)

**Peter’s Interpretation and Skepticism**

- Lack of Long-Term Effect:
  - Peter suggests that the glucose-lowering effect of red light therapy may be temporary and unlikely to persist over time.
- Comparison with Exercise:
  - He proposes that exercise, such as 15 minutes of zone two cardio or VO2 max intervals, would likely yield a greater and more consistent improvement in glucose homeostasis.
  - Exercise provides broader health benefits beyond glucose disposal, unlike red light therapy.

**Critique of “Quick Fix” Mentality**

- Caution Against Over-Reliance:
  - Peter is skeptical about relying on red light therapy as a shortcut for metabolic health, particularly for those with elevated glucose levels.
- Reality Check:
  - For those with peak glucose around 195 mg/dL, red light therapy alone would likely be insufficient for effective glucose management.

## Red light therapy for weight loss and targeted fat reduction [36:45]

**Red Light Therapy and General Weight Loss**

- ATP and Metabolic Rate:
  - The theory is that if red light therapy increases ATP production, it could theoretically speed up metabolism and contribute to weight loss by “wasting” ATP.
- Limitations of Red and Near-Infrared Light:
  - Unlike longer wavelengths, such as those in saunas, red and near-infrared light don’t create a temperature increase that would cause sweating or raise core body temperature.
- Conclusion: No valid studies currently demonstrate that red light therapy alone leads to weight loss.

**Red Light Therapy for Spot Fat Reduction**

- Laser vs. LED:
  - Claims about spot fat reduction often involve laser therapy rather than LED devices, as lasers offer more coherent, targeted light.
- Mechanism in Adipose Tissue:
  - In vitro studies suggest that 635 nm laser therapy can cause adipocytes (fat cells) to emulsify, releasing triglycerides.
  - The idea is that this released fat could either be absorbed by other fat cells or used as energy
  - This process might ease the removal of adipose tissue during liposuction, therefore, it might be that this is a more viable way to i**ncrease the efficacy of liposuction**.
- Protocol for Spot Reduction Therapy
  - Typical Dosage:
    - Red light (650 nm) or near-infrared (800 nm) laser panels target specific areas for 10-20 minutes, 2-3 times a week over several weeks to months.
  - Clinical Results:
    - Results are modest; one RCT reported a one-inch reduction in waist circumference, though most studies show even smaller results.
  - Long-Term Efficacy:
    - These studies are short-term and lack follow-up, leaving unclear whether results are sustainable.
- Study Example: [Split-Abdomen Trial](https://www.researchgate.net/publication/304991629_Low-level_laser_therapy_LLLT_does_not_reduce_subcutaneous_adipose_tissue_by_local_adipocyte_injury_but_rather_by_modulation_of_systemic_lipid_metabolism)
  - Lipolaser Study:
    - In a split-abdomen study with non-obese participants, the Lipolaser (650 nm) failed to show a significant reduction in abdominal fat and even increased fat thickness in some cases.
    - Limitations: This trial wasn’t randomized or blinded and reported side effects such as redness and ulceration, suggesting potential risks like hyperthermia.

**Cost, Risks, and Practical Considerations**

- High Cost:
  - Professional spot reduction therapies can cost between $2,000 and $4,000 for a six-session package, often incomplete for results.
- Risk of Aesthetic Issues:
  - Anecdotal reports indicate that these treatments can sometimes cause skin deformation or fail to achieve desired aesthetic results.
- Limitations on Targeting Metabolically Harmful Fat:
  - Spot reduction doesn’t address visceral fat (internal fat), which is more relevant to metabolic health.

**Peter’s Recommendation**

- Due to limited and modest results, high costs, potential risks, and lack of effect on metabolically significant fat, Peter advises against using red light therapy for weight loss or spot fat reduction.

## Red light therapy for inflammation, chronic pain, and injury rehabilitation [41:00]

**Red Light Therapy Claims for Pain and Inflammation Relief**

- Potential Applications:
  - Red light therapy is often promoted for reducing inflammation, managing chronic pain (e.g., arthritis), and aiding in rehabilitation from injuries such as elbow, knee, or other acute and long-term injuries.
- Peter’s Perspective:
  - He humorously suggests that instead of “squinting” at weak evidence, it’s better to examine the practical effectiveness of red light therapy for these claims.
  - Peter expresses skepticism, noting that while numerous studies attempt to find benefits, the evidence is often weak or limited to superficial applications.

Surface-Level Treatment Effectiveness

- Localized Superficial Benefits:
  - Red light therapy might offer some benefit for pain and inflammation relief when used on areas close to the skin’s surface.
- Example [Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10082920/) on Chronic Neck Pain:
  - One study showed a reduction in chronic neck pain after 12 sessions of 15 minutes, three times per week.
  - Both the treatment and sham groups showed pain improvement, but the red light therapy group experienced a slightly greater reduction.

**Challenges for Deeper or Long-Term Conditions**

- Osteoarthritis and Rheumatoid Arthritis:
  - A 2019 [meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6830679/) found no durable, long-term improvements in osteoarthritis pain with red light therapy.
- Limitations for Chronic Conditions:
  - The lack of sustained effects is particularly disappointing for individuals with rheumatoid arthritis, as systemic treatments can have significant side effects and red light therapy could have been a valuable alternative.

**Overall Assessment**

- Temporary Relief for Surface Pain:
  - Red light therapy may provide temporary relief for conditions close to the skin’s surface but does not appear effective for deeper, chronic pain or inflammation.
- Lack of Long-Term Benefit:
  - For long-term conditions such as osteoarthritis, the therapy lacks lasting impact and is unlikely to serve as a replacement for more established treatments.

## Red light therapy as a treatment for menstrual cramps [43:45]

**Marketed Claims and Proposed Mechanism**

- Marketing Focus:
  - Many red light therapy devices target women for menstrual cramp relief, though supporting evidence is minimal.
- Proposed Mechanism:
  - The claimed mechanism suggests red light therapy increases blood flow to the uterus, relaxing its smooth muscles.
- Penetration Limitations:
  - Peter notes that it’s physically impossible for red light to penetrate deeply enough to reach the uterus, as it only affects tissue close to the skin’s surface.

**Evidence and Limitations**

- Main Supporting Study: A 2012 study is frequently cited in advertising for these devices. Cktk
  - Study Details:
    - Small sample size with methodological issues; participants matched only by subjective pain without other baseline characteristics.
  - Results: Women in the treatment group reported a significant pain reduction from an 8/10 to a 1/10 in pain intensity.
  - Replication Attempts:
    - Follow-up studies have been unable to replicate this dramatic result, achieving only slight pain reductions if any.

**Peter’s Interpretation of the Study**

- Peter suggests a possible performance bias in the original study, where the treated subjects might have felt they received special attention, leading to perceived pain reduction.
- The inability to replicate the seven-point pain reduction casts doubt on the reliability of the study’s findings.

**Practical Considerations for Consumers**

- Device Cost:
  - Red light devices marketed for menstrual cramps generally cost $200 to $300.
- Possible Use for Non-Responders to Other Treatments:
  - Peter suggests that women with severe menstrual pain unrelieved by standard treatments (like NSAIDs or oral contraceptives) might consider trying red light therapy, acknowledging that the primary downside is the potential financial cost without guaranteed relief.

**Overall Assessment**

- Limited Evidence and Lack of Replication:
  - Red light therapy’s effectiveness for menstrual cramps remains unproven, with only one flawed study supporting its efficacy.
- Low Risk, Potentially Worth Trying:
  - For individuals struggling with menstrual pain and lacking alternatives, trying red light therapy may be an option, albeit with modest expectations.

## Summary: promising applications of red light therapy, unsupported claims, and costs to consider [46:45]

**Overview of Key Red Light Therapy Applications**

![](https://peterattiamd.com/wp-content/uploads/2024/11/f6a-ama65-pt1-1024x939.png)

**Figure 6a.**

![](https://peterattiamd.com/wp-content/uploads/2024/11/f6b-ama65-pt2-1024x951.png)

**Figure 6b.** Continuation of table above.

- Summary of Main Points**:** Peter plans to focus on the applications where red light therapy has the most potential benefits, based on current data.

*Applications with Promising Data*

- Acne:
  - Rating: 3/5.
  - Red light therapy is effective for acne, though less costly alternatives like topical treatments are available.
- Wound and Burn Healing:
  - Rating: 3–4/5.
  - While limited, data are growing, especially in rodent studies. Peter suggests it as a possible option for wound care under professional supervision.
- Hair Loss:
  - Extensive, consistently positive data support red light therapy for hair restoration, though it is costly.

*Moderately Supported Applications*

- Local Fat Loss:
  - Rating: 2/5.
  - Modest results suggest potential for pre-liposuction preparation, but long-term effects are uncertain.
- Menstrual Cramps:
  - Rating: 0–1/5, with an exception for one 2012 study showing dramatic results, though not replicated in other studies.

*General Low Efficacy of Other Indications*

- Zero-to-One Ratings:
- Most applications (like cognition, metabolic health) have minimal evidence of benefit, with inconsistent or insufficient data.

**Practical Usefulness of the Table**: Peter recommends the summary table for those interested in a quick reference of red light therapy’s potential benefits.

**Opportunity Cost Considerations**

- Financial and Time Costs:
  - Peter emphasizes that investing time and money into red light therapy comes with opportunity costs, especially when alternatives may offer more significant and lasting benefits.
  - Example: He questions spending 20 minutes twice daily on red light therapy when this time could be spent on activities with proven benefits, like exercise.

**Final Takeaway**

- Critical Evaluation of Time and Resources:
  - For many indications, there are more effective uses of time and resources than red light therapy.
- Personal Approach:
  - Peter advises anyone considering red light therapy to carefully evaluate the potential benefits against the opportunity cost, particularly if other health strategies could yield better results.

---

## Selected Links / Related Material

**AMA episode of The Drive about UV light and skin health**: [#308 – AMA #61: Sun exposure, sunscreen, and skin health: relationship between sun exposure and skin cancer, vitamin D production, and photoaging, how to choose a sunscreen, and more](https://peterattiamd.com/ama61/) | Peter Attia (peterattiamd.com) [6:00]

**Red light study in which cells showed reduced expression of genes associated with cellular senescence**: [Photomodulation alleviates cellular senescence of aging adipose-derived stem cells](https://link.springer.com/article/10.1186/s12964-023-01152-x) (Zhang et al., 2023) [11:45]

**Red light study showed that mesenchymal stem cells derived from mouse bone marrow treated with near-infrared light improved mitochondrial respiratory capacity, reduced cellular senescence, and improved proliferation**: [Photobiomodulation has rejuvenating effects on aged bone marrow mesenchymal stem cells](https://www.nature.com/articles/s41598-021-92584-3) (Eroglu et al., 2021) [11:45]

**Cultured human fibroblasts irradiated with 660 nanometer light demonstrated improved inflammatory signaling**: [Photobiomodulation and the expression of genes related to the JAK/STAT signalling pathway in wounded and diabetic wounded cells](https://pubmed.ncbi.nlm.nih.gov/31981991/) (Jere et al., 2020) [11:45]

**Red light therapy for acne: Comparing red light to sham therapy, after 12 weeks of this, there was about a 75% reduction in inflammatory and about a 55% reduction in non-inflammatory acne lesions, and that’s compared to the control group which had no observable difference**: [The clinical and histological effect of home‐use, combination blue–red LED phototherapy for mild‐to‐moderate acne vulgaris in Korean patients: a double‐blind, randomized controlled trial](https://academic.oup.com/bjd/article-abstract/168/5/1088/6614346) (Kwon et al., 2013) [17:30]

**Red light therapy for acne: RLT was found to perform comparably to traditional topical treatments like benzoyl peroxide**: [Phototherapy with blue (415 nm) and red (660 nm) light in the treatment of acne vulgaris](https://academic.oup.com/bjd/article-abstract/142/5/973/6689980) (Papageorgiou et al., 2000) [18:00]

**Burn Wounds: Red light therapy may aid in healing both the burn site and donor sites for skin grafts, such as from the thighs to hands or face**: [Low-intensity LED therapy (658 nm) on burn healing: a series of cases](https://pubmed.ncbi.nlm.nih.gov/29199384/) (de Oliveira et al., 2018) [21:00]

**Chronic Non-Healing Wounds treated with red light therapy had improvement in healing**: [Phototherapy with LED Shows Promising Results in Healing Chronic Wounds in Diabetes Mellitus Patients: A Prospective Randomized Double-Blind Study](https://pubmed.ncbi.nlm.nih.gov/29668397/) (Frangež et al., 2018) [21:00]

**Post-Surgical Wounds: Red light therapy can support recovery and reduce healing time for wounds after surgery**: [Photobiomodulation Improved the First Stages of Wound Healing Process After Abdominoplasty: An Experimental, Double-Blinded, Non-randomized Clinical Trial](https://pubmed.ncbi.nlm.nih.gov/30483937/) (Ramos et al., 2019) [21:00]

**AMA episode of The Drive about hair loss**: [#316 – AMA #63: A guide for hair loss: causes, treatments, transplants, and sex-specific considerations](https://peterattiamd.com/ama63/) | Peter Attia (peterattiamd.com) [24:15]

**Red light therapy for hair loss: In a 16-week RCT, participants using red light therapy saw an increase of 42 hairs per cm² and an average increase in hair thickness of 7.5 microns**: [Low-level light therapy using a helmet-type device for the treatment of androgenetic alopecia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7373546/) (Yoon et al., 2020) [26:00]

**One Small Study on Color Sensitivity: A study with 24 participants using 670 nm red light examined changes in color sensitivity. Results showed a slight improvement in color sensitivity, allowing subjects to better discriminate between colors**: [Weeklong improved colour contrasts sensitivity after single 670 nm exposures associated with enhanced mitochondrial function](https://www.nature.com/articles/s41598-021-02311-1#Tab1) (Shinhmar et al., 2021) [28:30]

**Recent study on recreational runners tested red light therapy at different energy doses**: [Acute dose-response effect of photobiomodulation therapy on 5-km running performance in trained runners: a randomized, double-blind, placebo-controlled, crossover study](https://pubmed.ncbi.nlm.nih.gov/38819613/) (Nascimento et al., 2024) [31:45]

**A recent meta-analysis examined various studies on red light therapy’s impact on exercise performance**: [Can pre-exercise photobiomodulation improve muscle endurance and promote recovery from muscle strength and injuries in people with different activity levels? A meta-analysis of randomized controlled trials](https://pubmed.ncbi.nlm.nih.gov/38758297/) (Li et al., 2024) [32:45]

**In a split-abdomen trial, Lipolaser therapy failed to show a significant reduction in abdominal fat**: [Low-level laser therapy (LLLT) does not reduce subcutaneous adipose tissue by local adipocyte injury but rather by modulation of systemic lipid metabolism](https://www.researchgate.net/publication/304991629_Low-level_laser_therapy_LLLT_does_not_reduce_subcutaneous_adipose_tissue_by_local_adipocyte_injury_but_rather_by_modulation_of_systemic_lipid_metabolism) (Jankowski et al., 2016) [40:00]

**Red light therapy for chronic pain: One study showed a reduction in chronic neck pain after 12 sessions of 15 minutes, three times per week**: [Efficacy of Low-Level Laser Therapy for the Treatment of Nonspecific Chronic Neck Pain: Low-Level Laser Therapy vs. Sham Laser](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10082920/) (Momenzadeh et al., 2022) [42:45]

**A 2019 meta-analysis found no durable, long-term improvements in osteoarthritis pain with red light therapy**: [Efficacy of low-level laser therapy on pain and disability in knee osteoarthritis: systematic review and meta-analysis of randomised placebo-controlled trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6830679/) (Stausholm et al., 2019) [43:45]