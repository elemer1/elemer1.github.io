# #55 – Jocko Willink, retired Navy SEAL, Part I of II: objective, strategy & tactics, leadership, protocols, dealing with death, and applying the many lessons learned from war

**Source:** [https://peterattiamd.com/jockowillink1/](https://peterattiamd.com/jockowillink1/)

---

In part 1 of this 2 part series, Jocko Willink, retired Navy SEAL, discusses some of his most important lessons learned from his time commanding some of the world’s most expert special forces operators including the importance of understanding the objective and strategy (and then tactics) of a mission, why humility is the greatest trait a leader can have (and certain times when it’s not), as well as the necessity of having proper protocols in place to deal with whatever comes your way. We also talk about how Jocko prioritizes his military and family obligations with his love for jiu-jitsu, as well as how to decipher what really matters in life. Finally, we go through the US history with respect to various wars from World War I, all the way forward, and much much more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jockowillink1/the_Drive_public.png)

Play

#55 - Jocko Willink, retired Navy SEAL, Part I of II: objective, strategy & tactics, leadership, protocols, dealing with death, and applying the many lessons learned from war

#55 - Jocko Willink, retired Navy SEAL, Part I of II: objective, strategy & tactics, leadership, protocols, dealing with death, and applying the many lessons learned from war

1x15s30s

0:002:39:08

## We discuss:

- Objective, strategy, and tactics [6:00];
- Training compared to actual combat [20:30];
- The importance of humility in leadership, business, and life [33:00];
- The dichotomy of human traits: Can you be too humble? [49:00];
- Why many leaders lack humility [52:30];
- Why Jocko wanted to be a Navy SEAL [55:00];
- Jocko’s attitude toward death, and dealing with the death of a soldier [58:45];
- The vital importance of protocols [1:03:45];
- Protocol for losing a child (or anyone close to you) [1:15:00];
- Protocol for getting dumped, and some relationship advice [1:18:00];
- How to differentiate between things that matter and things that don’t [1:24:30];
- Jocko shares his experience during BUD/S [1:35:45];
- How Jocko prioritizes his family and SEALs obligations: Would Jocko come out of retirement and go back to war? [1:48:30];
- America’s lost sense of connectedness and purpose since WWII [1:59:00];
- How warfare has evolved over the decades since WWI [2:05:40];
- Obeying orders and the obligation to dissent [2:09:00];
- WWI and WWII, the beginnings of “decentralized command” [2:15:00];
- The American warrior mentality, and the impact of freedom on a society [2:20:45];
- What impact can an individual president really have? [2:25:00];
- The Korean war [2:29:15];
- Lessons learned from Vietnam [2:31:10];
- First Gulf War, Iraq War, and The War in Afghanistan [2:35:45]; and
- More.

§

## Show Notes

## Objective, strategy, and tactics [6:00]

- Peter credits [Denis Calabrese](https://www.americanconference.com/speakers/mr-denis-calabrese/) for his current way of differentiating between objective, strategy and tactics
- Denis’s framework for solving hard problems:
  - First, defining your objective
    - Must be really clear
    - Most people actually miss that step
  - Next, you must put a strategy in place
    - Your strategy is the framework, a “scaffolding” upon which you will hang tactics
    - \*Too many people go from objective straight to tactics\*
  - Lastly, develop your tactics
- *In summary:* **Objective ⇒ Strategy ⇒ Tactics**

How Jocko developed a similar technique

- Realized as a leader of troops that if the front-line troops didn’t understand things at a little bit higher level than the tactical level, then they couldn’t make decision on their own
- This inhibits the ability to operate with [decentralized command](https://campusrecmag.com/decentralized-command/)
- A mistake that you make on a *tactical level*, can have a *strategic negative impact*

⇒ Classic example: [Abu Ghraib prison scandal](https://en.wikipedia.org/wiki/Abu_Ghraib_torture_and_prisoner_abuse)

- A small group of US soldiers mistreated some prisoners of war and took photos
- This was then used as propaganda by the enemy to rile up their support and paint all American soldiers as the evil enemy
- The strategy was actually the opposite… to show US soldiers as the good guys to the local communities
- So this is a massive strategic negative impact, because these front-line soldiers didn’t fully understand the strategic situation that they were in

Decentralized command

- With “centralized command”, the front-line soldiers typically just know the tactics and are not well informed to the strategy
- If they get separated from centralized command, they are then totally “lost” as to what to do
- And you don’t even have to get separated… as an extreme example, a sniper will have to make a decision in a split second whether to kill someone without the time or ability to ask his boss… without the understanding of the strategy, he cannot make the right decision

In health and nutrition

- People get so focused on the tactics (i.e. should I be keto? Vegan? Paleo?)
- “I try to discourage that kind of discussion because it’s very tactical. And if you ask tactical questions, or questions that demand tactical answers, you’ll never get the bigger picture.”
- Nutritional information will change over time ⇒ “So instead of pegging yourself to, ‘What’s the right thing to eat today?’, peg yourself to the principle of nutritional biochemistry. And then you can sort of evolve over time.”

Why people always focus on tactics?

- “It makes life easy. It takes the decision out of their hands.” say Jocko
- Jocko says it also removes the blame if the decision is wrong
- But ignoring strategy and focusing on tactics doesn’t work in the long run because you can’t prepare for every single possible situation

⇒ Example,

- in Iraq, he had a situation where 4 suspicious guys pulled over and opened their trunk
- The first thought is that they were about to pull out mortar and launch them as US soldiers
- But turns out they were just jacking up their car to change a flat tire

> “So, those are situations that you can’t predict. And if people don’t understand what the strategic vision is, then they can’t make decisions out there.”

## Training compared to actual combat [20:30]

> “Everybody has a plan until they get punched in the mouth.” — Mike Tyson

**SEAL training**

- Jocko says the training has evolved (thankfully) since he was first starting his SEAL career in the 90s
- They would use blanks in their land warfare training
- Used a system called [MILES](https://en.wikipedia.org/wiki/Multiple_integrated_laser_engagement_system) (like laser tag)
- But for several factors, this training wasn’t great (meaning it didn’t simulate real life well enough)
- They then moved to using live bullets but only against paper targets (which unlike real people, they don’t maneuver or shoot back at you)

Paintballs

- Towards the late 90s, technology allowed them to put paintball barrels on the end of their actual guns ([Simunition](https://www.simunition.com/)) which allowed for the SEALs to train against real people
- The paintball technology exposed some of their weaknesses

⇒ Classic example: Hallway stacking

- - To move through a building, we would all just stack in a hallway, and then we’d go down the hallway, putting people in the rooms. You take this room on the left. Next two guys take the room on the right. Next two guys take the room on the left. So there you go. You’ve got 20 guys in the hallway, and then you move down the hallway, and you clear the rooms as you go down the hallway.
  - What we didn’t realize, because those paper targets never popped out of the door and shot back at us. As soon as we started using Simunition, you are all stacked up in the hallway. So you’ve got 20 guys in the hallway, and somebody way down at the end of the hallway sticks their Simunition gun around the corner. They don’t even expose themselves at all, and they spray off a magazine of rounds. 25 rounds comes down the hallway. And guess what? Eight guys are hit. And there’s this pushback against that. There was actually some pushback against that, which was, “That’s not realistic. That guy didn’t even take a sight picture. That guy didn’t expose himself, so it’s not realistic.” And my thought was, well, wait a second. It just happened. And believe me, an AK-47 would’ve been even worse in a Simunition gun.
- These insights lead to changes in tactics

Upgraded laser tag system

- Simunition was only accurate to 10-20 meters away (whereas in real life you could get shot at 500-700 meters)
- Eventually moved over to a very good laser tag system for external movement for land warfare
- And it had little speakers next to your shoulders
- So as you were getting shot at it would make noises like there was rounds going over your head
- Punishment for getting “shot” is your buddies had to carry you and all your gear for 2 kilometers

Training vs. actual combat

- With more and more “force on force” training, we got better, and better, and better, and more prepared for what combat was really going to be like
- However, still many discrepancies:
- For example, as good as the evloved training was… the SEALs knew they couldn’t actually die
- So risks were likely taken in training that may not be taken in real life
- Hard to know for sure

Jocko’s first combat experience

- In convoy in Baghdad in a humvee
- He saw sparks flying off the side of the humvee in front of them and he thought someone was smoking a cigarette
- Turns out that humvee was taking fire and he didn’t even realize it
- His first 6 months
  - Says he got “lucky” in the sense that the intensity of combat for him sort of slowly escalated over time
  - First 6 months included many confidence building operations that were successful

## The importance of humility in leadership, business, and life [33:00]

- Jocko trained for 13 years before he actually shot his weapon at an enemy in combat
- Very different from, for example, an enlisted person in the Army in 2003 immediately thrust into the war in Iraq

Humbling experience

- When Jocko first got to Ramadi, he has zero combat experience
- The guys on the ground were [National Guard](https://en.wikipedia.org/wiki/United_States_National_Guard) troops (aka “part-time soldiers”) who has been fighting for 14 months
- Objectively, the National Guard guys have much less training and expertise as the SEALs yet they had done in incredible job
- Jocko knew it was important to stay humble and try to learn as much as possible from these guys
- About the National Guard troops:
  - “*These guys were teachers and electricians, and plumbers, and lawyers and doctors. And one day they get told, hey, you’re going to go to Iraq. And you know what they do, they get their gear on and they go to Iraq and they do a hell of a job over there, and make just incredible sacrifices for the mission*…
  - …*they were hardened combat warriors by the time we showed up, and they definitely helped us and kept a lot of us alive because they were able to share with us the way that they operated.*”
- Jocko also gives credit to the guys in his unit (Task Unit Bruiser) for being humble and willing to listen to the National Guard guys

**Importance of humility in business (and life)**

> “Humility is the most important attribute or characteristic for a leader to have.”

- In the business world, in any leadership position, when you don’t have humility or you think you already know everything is a recipe for disaster
- Even someone who’s been in an industry for 20+ years should be willing to learn from others
- Classic example: Blackberry phones
  - Blackberry had ~80-90% of the market share
  - [Research in Motion (RIM)  stock price (now Blackberry Ltd)](https://www.google.com/search?q=Research+In+Motion&tbm=fin#scso=_rZrZXMuNKI7u-gSstbaoDQ2:0) was up over $140 per share in mid-2008 (now it’s under $10)
  - Didn’t believe the trend of smart phones of today (aka unwilling to be humble and listen)
- Another example: Blockbuster
  - Unwilling to believe DVDs were becoming obsolete
  - It’s a kind of arrogance

Great book on humility: [Being Wrong](https://www.amazon.com/Being-Wrong-Adventures-Margin-Error/dp/0061176052)

- This book goes into how often we are wrong in times when we are convinced we are right
- Peter says … “it’s on the list of 15-20 books I’ve read that I can’t freaking stop reading once I’m into it”

**There are a few fundamental truths**

- In moments of teaching troops or business leaders, Jocko will very seldomly and strategy tell someone he is 100% certain about something
- He is extremely careful with this statement: “*If I’m telling you that I know something 100%, you should listen to me because I don’t play around with that statement.*”

*Fundamental truths:*

⇒ Combat example: Cover and move

- “You and I have to work together, one of us has to put down cover fire and the other one has to move. If we decide guess what, you and I are just going to go for it together at the same time, and there’s no cover fire, that’s wrong, it’s just wrong. What’s going to happen is, we’re both going to die. What we should do is, if you want to get across the street, I’m going to get in a good position on the lay down cover fire and then you’re going to move. While I’m shooting at the bad guys and they can shoot back.”

⇒ Biology example: DNA codes for RNA, codes for protein

- In biology, there aren’t many things that we are so confident in that we say [we’re 100% sure]
- But one of them is DNA codes for RNA, codes for protein
- It’s just an axiom of biology

**How did Jocko learn to be humble?**

- Peter says arrogance is something he battles with and he has to “*work staggeringly hard to pause in my tracks and consider the world through another person’s lens*”
- Jocko credits his bosses and leaders setting great example of what to do (and what not to do)

Jocko explaining a good role model:

- “I had a boss that I worked for, who was the most experienced guy that I ever worked for. He was the most tactically savvy guy I’ve ever worked for. He was the most experienced guy I’d ever worked for. And he was the most humble guy ever worked for. He was our platoon commander, and all of us in the platoon, we wanted nothing more, nothing more, than to make that guy look good, to not let him down. I felt that, I was a young SEAL. I was 21 or 22 years old. And here’s this guy who has all this experience, combat experience in the 90s, which not many people had. And we, me, the rest of the guys, we just wanted to make this guy look good and we didn’t want to let him down. And it was because he was so humble.”

Jocko has also experienced the opposite:

- We had a mutiny against the previous platoon commander
- We went before our commanding officer and said, ‘we don’t want to work for this guy’
- He was not humble

> “I got to see this incredible contrast between these two guys. One who was extremely arrogant and inexperienced which is a horrible combination. The other guy who’s extremely experienced and super humble. The contrast between those two guys painted a very clear picture in my mind as a young guy.”

## The dichotomy of human traits: Can you be too humble? [49:00]

- In [Dichotomy of Leadership](https://www.amazon.com/Dichotomy-Leadership-Balancing-Challenges-Ownership/dp/1250195772), Jocko writes about the how there can be a division is certain principles
- Are there times where people be **too humble**? ⇒ “*Yes, absolutely they can.*”

Example,

- Jocko spoke with underprivileged kids up in LA
- They were smart kids (8-13 years old)
- They had been selected as kids that had some potential even though they were in these underprivileged situations
- Jocko has planned to go talk to them about the things he had learned (one of which is the importance of being humble)
- But the kids were “already broken”… shoulders folded forward, heads and eyes down… so Jocko had to change his tactics
- The immediate change was to talk to them about confidence (and not talk about humility
- **NOTE**: great example of understanding strategy allowing for the ability to adjust tactics

Can leaders in business be too humble?

- Yes
- If an employee comes to a leader barking about something and the “over humble” leader always goes with it instead of standing up and confidently saying he disagrees, that’s not good leadership

**Every human trait can be good and bad**

> “Every trait that a human being can have can be negative and positive. You can take something too far, any of them.”

Thought experiment: What’s the most positive quality you can think of a leader to have?

- “Poise”
- A leader can have so much poise it can appear that he’s disconnected from the situation
- He can appear robotic

What about stoicism?

- Not showing emotion is generally a good thing
- But sometimes leaders need the people to know that you hurt

> “If you have no emotions, you’re a robot and people don’t follow robots. You won’t have any connection with them. Having control over your emotions is one thing. But not having any emotions at all, is not going to make you into a good leader, it’s just not.”

## Why many leaders lack humility [52:30]

Working for a humble leader:

- The people under this leader will really want to make that person look good
- Never want to let them down

Working for an arrogant leader:

- There are more people on this extreme compared to the extremely humble leaders
- In many cases you are actually hoping that person will fail
- It creates the worst morale of a team imaginable

**Jocko explains why many leaders lack humility:**

“*It’s a total disaster. And this is why I always answer that question with humility being the most important characteristic for a leader to have. Because, in most situations, the reason that the leader ended up in a position is because they have some level of confidence already. So it’s not normal for a leader to end up in a leadership position, but they lack confidence and they’re overly humble. That’s not normal. It does happen occasionally. But it’s not normal. The normal cases, you’ve got someone that’s an alpha, you’ve got someone that’s fought their way to get up through the ranks, you’ve got someone that was confident enough to be like, hey, I’ll take control of this. Hey, I’ll run this. People elevate to that position because they’re confident, and that’s why it tends to be the greater percentage of the time there’s a problem with humility. It’s because they lack humility, not because they have too much money.*

*Occasionally, you get a tech company with a startup, we had some really humble guy that figured something out and he started a little company, and all of a sudden, he’s the CEO and he totally lacks confidence and he’s overly humble. He doesn’t think he can make any decisions. That’s a different situation. That’s a more rare situation. The more common situation is, I’m at the top because I deserve to be, I made it here. And that’s why everyone should listen to me and that’s why I’m not going to listen to anyone else. The minute you’re in that situation, you’re going in the wrong direction. It needs to get balanced out.*”

## Why Jocko wanted to be a Navy SEAL [55:00]

- Jocko joined the Navy straight out of high school in 1989
- He had recently seen the 4 SEALs had died in the invasion in Panama
- “*I couldn’t believe a war happened and I wasn’t in it.*”

Early career in the Navy

- Checked in at 174 pounds (Graduated Navy at 185 pounds)
- Boot camp in Orlando, FL
- “The coolest thing about going to Navy boot camp for me was it was a clean slate. Nothing else matters. They don’t care what your high school, they don’t care what your grades were, they don’t care what sport you play, they don’t care how good you were in any sport, they didn’t care about anything. What they did care about is, could you do what we’re telling you to do?”

Did Jocko pick the Navy because of the SEALs?

- Liked water
- Wanted to get out of New England
- Loved to surf (SEAL teams are based in Virginia Beach and San Diego)
- Living in CA was like going to “live on Mars”

What attracted him to the Navy SEALs?

- Heard that the Seal teams had the hardest training
- Heard the SEALs had a casualty rate of 50% (may not have been totally accurate)

## Jocko’s attitude toward death, and dealing with the death of a soldier [58:45]

*Why did the high casualty rate of the SEALs appeal to Jocko?*

- “I wanted to fight wars… I didn’t want to die. . . when you’re young, you don’t think it’s going to be you.”
- It was the the highest stakes thing he could do

**Attitude toward death**

- Jocko says as young guy, you doing think you can be killed (he still think if he was in a plane crash he would be the one person to survive)
- At some point though, you must accept that death is possible and you must be okay with that
- If you’re afraid of death, you’re going to have a real hard time doing your job

*Did having kids change his attitude toward death?*

- Yes, but not in the way you’d think
- After having kids, Jocko didn’t feel more pressure to survive
- Instead, he felt like at least I have kids to carry on my genes
- And they will see that I died doing what I love to do

*What about getting married? Before kids, did having a wife increase the pressure to survive?*

- “No, not really.”

Movie recommendation: [Taking Chance](https://www.imdb.com/title/tt1019454/)

*Jocko on soldiers getting killed*:

“Every one of those guys has a family, has a wife, has a mom, has a dad, has brothers and sisters has dreams, has goals in their life, has things that they want to do, has inherent ideas and knowledge and thoughts and wisdom, that is completely and utterly unique to them. And we never get to see that. We never get to see what would have manifested from these kids, it’s awful.”

Dealing with the death of a buddy in battle:

- Peter points out that in civilian life, when we lose a loved one we have the opportunity to grieve and retreat away from the world
- But in battle, you don’t have that luxury
- Jocko: “No, as a matter of fact, you’re saying hey, in 48 hours, we’re going to go back and put our gear on and lock and load and go do what we’re supposed to do.”

## The vital importance of protocols [1:03:45]

**Protocol for losing a loved one**

- Jocko feels that in America specifically, we are lost as to what to do when it comes to death
- He say many cultures have specific rituals that helps people move on
- He believes that a proper protocol could be part of the solution

⇒ In general: When bad things happen (death, house burned down, etc.), it is very important to have a protocol

⇒ In business: Many businesses are high risk in the sense that given enough time, something “bad” will happen

**Jocko’s protocol for losing a SEAL brother**

- Jocko says that in his first deployment to Ramadi, they did not have a protocol in place for when someone was killed
- To clarify, there was a procedure in place ([CACO](https://www.public.navy.mil/bupers-npc/support/casualty/caco/Pages/default.aspx)) for the next steps following a casualty
- However…
  - What happens within the platoon?
  - What happens in your head after losing your best friend?
  - There was no protocol for that

*So Jocko created one…*

“Letting your mind be idle, letting your mind sit there and think about what just happened to me, that’s not a good protocol.”

- When they lost a loved one, the protocol was:
  - We’re not going to do anything tonight
  - We’re going to do a service tomorrow
  - The day after that, we’re going to say goodbye
  - “Then we’re going to get on our gear, we’re going to lock and load and weapons, and we’re going to go back to work. Because that’s what our brothers would want us to do in this situation.”
- SEALs lost: [Marc Lee](https://en.wikipedia.org/wiki/Marc_Alan_Lee) (first in Iraq), [Mikey Monsoor](https://en.wikipedia.org/wiki/Michael_A._Monsoor), and [Ryan Job](https://www.azcentral.com/story/ejmontini/2015/02/07/chris-kyle-american-snyper-ryan-job-warriors-faith-book/22985089/)

**A book on protocols**

- Jocko is considering writing a book of protocols for some of the common things we face
- Examples,
  - Getting dumped
  - Getting sick with a disease
  - Losing a spouse or a child
  - Losing a job
- Without a protocol, people can spiral down a dark path

Suicide

- Peter points out that many (maybe most) cases of suicide is triggered by an acute issue
- It’s very upsetting to think that someone would make that huge decision to end their life which could have been avoided had they been prepared with a procedure to follow instead

> “When you’re caught up in something psychologically, one of the best things you can do is do something, take some kind of action that moves you forward. What you don’t want to do is stay stagnant and dwell on what’s happening. You want to say, ‘Okay, this horrible thing happened. Let me get out the book and follow the protocol because that’s going to move me in some direction and it’s going to start to get me to the point where I can move past this.’”

***The protocol to follow when you don’t know what to do****:*

1. Take a step back
2. Look around
3. Make sure you assess everything that’s happening
4. Think about what your possibilities are
5. What decisions could you make right now
6. And what would the general outcomes of those decisions be?
7. Next, take a iterative/reversible step towards what you think is the best decision (i.e. Not a full commitment just yet)

Peter sees a parallel between Jocko’s protocol concept and Jordan Peterson’s book called [12 Rules for Life](https://www.amazon.com/12-Rules-Life-Antidote-Chaos/dp/0345816021)

## Protocol for losing a child (or anyone close to you) [1:15:00]

On a [recent episode of Jocko’s podcast](https://jockopodcast.com/2018/12/26/157-when-to-play-the-game-when-to-break-the-rules-ultimatums-making-co-workers-shape-up-coping-with-loss/), a father wrote in with a question about how to overcome and move on from the loss of a child, this is the advice Jocko gave him:

- First, you’ll feel a tidal wave of sorrow that you think will never subside
- Next, the feeling will subside, just a tiny bit
- People feel really guilty about the sorrow subsiding and they fight it
- But this is normal, you’re not a bad person
- Even after the sorrow subsides, you’ll still have moment where someone or something will trigger your grief and you’ll cry uncontrollably (this is very scary for people)

> “What I try to explain to people, it’s like… No, that’s not what it’s going to be like from now on. This is what it’s like right now, but those waves of sorrow are going to diminish over time. That’s not bad. That’s not bad. It’s good actually. It’s good and you should look when the sorrow diminishes, when the wave is a little bit weaker, you should be like, ‘Okay, cool. I’m starting to process it, I’m starting to get through it, I’m starting to accept the situation I’m in.’”

- Then the final thing:
  - When you get to that point of diminishing waves of sorry
  - Then what you do is you’re going to write a letter to your child
  - Explain to them how much they meant to you, how much you love them, how much you cherish the time you were together, and how you are going to move forward
  - You’re going to live a beautiful life and you’re never going to stop thinking about them, but you’re going to move near to do incredible things with your life to honor them
  - Then you’re going to take that to where they’re buried and you’re going to give it to them
  - You’re going to read it to them, and then you’re going to walk away and you’re going to move on because you have to, because otherwise, what are you doing?

> “You’re burdening this soul with your own sorrow. You’re ruining your life on account of them. They don’t want that. They don’t want that. They want you to move on. They want you to be happy. Go and move on and be happy.”

## Protocol for getting dumped, and some relationship advice [1:18:00]

Step one after getting dumped:

- “When someone dumps you, the main thing you have to consider to get through that is . . . to recognize that the person that dumped you is not the person that you thought they were.”
- You may have had that person in an elevated position ⇒ “she’s an angel”
- Guess what? She’s not an angel
- She’s not the person who you’re supposed to spend your life with
- While there are other parts to the protocol, that is the key factor you have to first recognize

> “That’s a hard reality to face, but it’s a better reality than the person that was my forever person doesn’t want me forever.”

*Jocko’s two cents on relationships:*

- Jocko suggests taking ownership of the issues (and even more so once you’re married with kids)
- But you also should submit to every issue
- At the same time you shouldn’t blame your partner all the time
- Take ownership of the situation you are in:
  - I have feelings for this person that I shouldn’t actually have. . .they’re actually unrealistic feelings
  - Maybe I’ve done a bad job selecting this situation
- Once married with kids, there are better approaches than others, for example:
  - Say your wife oversleeps and forgets to make the kids lunches
  - Bad action to take: Ask wife, “Why didn’t you make the sandwiches??”
  - Better approach to take: “‘Hey, I noticed you didn’t get to make sandwiches, is there anything I can do to help?’ Maybe it’d be better if I made the sandwiches in the morning and that’s going to move your relationship in the right direction for sure. So, **get some.**”

Peter two cents on relationships:

- In college/med school, Peter would keep a two lists list during his relationships
- One list had the things he thought were absoutely essential in a partner
- The other list were things that under no circumstance would he ever be willing to tolerate in a person
- Every relationship would add something to each list

## How to differentiate between things that matter and things that don’t [1:24:30]

Powerful speeches that Peter highly recommends:

- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace)’s [commencement speech](https://www.youtube.com/watch?v=8CrOL-ydFMI&feature=youtu.be)
- Ric Elias [TED Talk](https://www.youtube.com/watch?v=8_zk2DpgLCs)

**Peter’s takeaways from Ric’s near death encounter**

- Ric nearly died in a plane crash and he talks about what it’s like to “know” you’re going to die
- Peter’s friendship lead him to another person with a similar experience who survived a helicopter crash
- They both described their experiences similarly:
  - Time slows down to a degree you can’t imagine
  - It’s not scary
  - How sad your last moments are
  - Surviving these encounters have given them an incredible gift
  - You suddenly realize **how much time you’ve wasted on all the things that just don’t matter**

Peter still struggles:

- Despite this knowledge gleaned from Ric and Dan (and David Foster Wallace), Peter still finds himself dwelling on crap that make no difference
- Example, a stupid comment on Twitter, a snippy email from a patient, etc.
- He will catch himself mentally wandering when he should be in the moment with his family

*Peter: “****Can you come up with a protocol for that? Because we have lost track of what problems really are.”***

- Jocko says he’s lucky to feel an incredible sense of gratitude to be alive
- He says he feels it everyday, in large part due to seeing the incredible sacrifice of his military friends
- And realizing that luck played a role in giving him the gift to survive

> “You realize life is a gift without question. Without question, it’s a gift.”

**Jocko’s protocol for not dwelling on things that don’t matter**

- In Jocko’s time in the SEAL teams, he acquired the ability to *detach from what’s going on*
- In other words, the ability to take a step back and remove yourself emotionally from the situation and ask, “does this really matter”?
- Good leaders also have this quality
- A bad leader will get wound up about things that don’t matter (this person disobeyed me, this person wronged me, etc.)

Analogy: Training in [jiu-jitsu](https://en.wikipedia.org/wiki/Brazilian_jiu-jitsu)

- Someone’s grabbing your hand, your arm here, that doesn’t matter
- What matters is what you’re doing over here with your hips, that’s what matters
- The more advanced you get jiu-jitsu, the more you realize what’s important, what matters and what doesn’t matter

> “It’s the same thing with life, the better you get at life, the more you’re able to detach from inside your own just storm, emotion filled, ego filled, crazy brain. The more you can get out of that thing and you can take a step back and look at what’s actually occurring, the better decisions you’re going to be able to make.”

**Focus on what you can control**

- You should not be devoid of emotions
- But you should try to step out of the emotional brain in order to make better decisions
- You should mitigate risk to the best of your ability and accept that you’ve done your best
- Don’t dwell on the things you can’t control

*Don’t be nervous, be aggressive*

> “When you’re hiding, and you’re not shooting, guess what the enemy’s doing? They’re maneuvering on you, they’re going to kill you. I think about that, to this day. Some situations happening to me, I don’t hide from it. I’m going to go after it. I’m going to get aggressive. I’m going to default aggressive, that’s going to be my mode because to sit back and allow and wait things to happen to you, the more you do that, the more defensive you are, the more defensive your mindset is, the worst things are going to turn out.”

## Jocko shares his experience during BUD/S [1:35:45]

Jocko’s path to the SEAL teams

- Straight out of high school he went to an 8-week Navy boot camp in Orlando
- Next he went to [BUD/S](https://en.wikipedia.org/wiki/United_States_Navy_SEAL_selection_and_training#Basic_Underwater_Demolition/SEAL_(BUD/S)_Training_(24_weeks)) (nowadays, after boot camp you first complete a 2-month BUD/S prep course before going to BUD/S)
- In Jocko’s time (1989), he was not prepared for the physical training needed (as opposed to now where everyone knows what to expect)

Basic BUD/S

- 26 weeks (6 months)
- Attrition rate is about 70-80% in those first 6 months (most coming at the beginning)

Hell Week

- When jocko went through BUD/S, Hell Week was the ~5th week
- This is when the majority of attrition occurs

What happens during Hell Week?

- Jocko downplays it a little bit: “*You do a bunch of working out for five days.*”
- Cold ocean water
- Basically no sleep
- It’s mostly about mental fortitude, “do you really want to be there?”
- They are trying to weed people out in 2 ways…
  - One, they are waiting for you to quit b/c you don’t have mental strength
  - Two, there are physical metrics you much hit
- Run, swim, and obstacle course
- Then other things designed to “crush you”
  - Underwater knot tying
  - Saving a drowning person (the instructor pretending to be drowning who will make your life suck)
- The Runs ⇒ Three phases (all in boots on soft sand)
  - Phase 1: Four miles in 32 minutes
  - Phase 2: Four miles in 30 minutes
  - Phase 3: Four miles in 28 minutes (~7 min mile)
  - Here’s the catch though: “*You’re in sand, you’re in boots, you, the night before, did literally 1000 eight-count bodybuilders, which is like a burpee with another movement in there. You slept for three hours. You’re on the beach. It’s cold. And the run that’s supposed to be four miles is actually 4.42 miles or whatever. You have no idea*.”
- Jocko says he wasn’t particularly good at any metric
- He failed one run b/c he decided to “pace himself”
  - And you’re not wearing a watch either
  - You basically just have to run all out the whole time

> “Here’s the deal with BUD/S. You work out a bunch for six months. That’s the deal. You compare BUD/S to being in a convoy, getting ready to roll out in the city of Ramadi, or getting ready to patrol out of one of the forward operating bases there. The mentality is not even close. It doesn’t compare.”

*Does BUD/S accomplish its goal of weeding out the physically and mentally “weak” candidates?*

- Jocko says it does to about a 90% solution
- But you still end up with “weak” SEAL guys that nobody wants to work with
- “BUD/S has almost zero prediction of what someone’s going to be like as a SEAL because you can be a great athlete.”
- It doesn’t test leadership, intelligence, or teamwork at a high level

## How Jocko prioritizes his family and SEALs obligations: Would Jocko come out of retirement and go back to war? [1:48:30]

- Jocko retired from the Navy in 2010
- What was the hardest part about the transition?
- When he first came home from Ramadi, he described a time of “decompression” in which he and his buddies were mourning losses of buddies by “celebrating life” and “living hard”

Impact on his wife and family

- “My wife is a saint”
- While Jocko was deployed his wife not only took care of the kids but also visited wounded soldiers and attended funerals of SEALs (and since Jocko was deployed he could never be there with her)
- His kids were too young to fully comprehend what was happening
- He now does take his oldest son to funerals when a SEAL gets killed

*Jocko’s “not normal”*

- His wife has pointed this out to him on more than one occasion
- He would work all day (from 5am to 7pm) then when he got home he’d go train jiu-jitsu (“I’m a total jerk when it comes to jujitsu”)
- His wife almost never complained

**The SEAL team is his top priority**

Jocko even once told his wife the following… “*The teams is my number one priority. The SEAL teams is my priority in my life. You are up there, but that’s my number one priority.*”

⇒ Jocko explains why it *has* to be this way…

- “If I’m going to be in a combat situation, the best thing that I can do for our family is be completely and utterly as prepared as I possibly can so that when things happened, I’m ready so I can come home. . .
- . . . I got 40 guys that are counting on me to make the right decisions at the right time so they come home too.
- . . . That’s my tactical priority right now, so that strategically, in the long run, I’ll be here in the future and so will my friends.”

*Would Jocko go back to war if he could?*

- Jocko: “*Yes.*”
- Peter: “*But you have [four] kids. You have a wife. . . And yet, you would be willing to go out there and make that sacrifice. I have to tell you, I wouldn’t.*”
- Jocko: “*Understood.*”

*⇒ How many SEALs would do the same thing?*

- A decent amount, Jocko says
- Jocko does point out that it isn’t a totally angelic thing… in fact… most guys love it
- But at the same time they are willing to make the ultimate sacrifice for it, which is an incredible thing

> “The US military is filled with men and women that are willing to set aside everything that they have, including their life, because they believe in a higher ideal. . .That’s why it’s so incredible to have been part of that in any way. It’s incredible.”

## America’s lost sense of connectedness and purpose since WWII [1:59:00]

- Peter wonders if we have lost a sense of connectedness, a sense of pride, a sense of relational connectivity since then end of WWII

Book rec: David Brooks describes this in the book, [The Road to Character](https://www.amazon.com/Character-Thorndike-Press-Large-Print/dp/1594139377)

- The whole country experienced some sacrifice for that war (the front line soldiers all the way to the women working day and night to make ammunition)
- We seem to have become disconnected to that feeling of purpose and a higher calling and connectedness (especially when you compare WWII to Vietnam)

*So why does Jocko seem to still feel that? And why is he willing to make the ultimate sacrifice?*

- He feels an extreme sense of purpose
- He has a “*connection in my blood to the guys that I’ve worked with, from the guys that raised me in the SEAL teams*”

Peter’s powerful experience at Normandy

![](https://peterattiamd.com/wp-content/uploads/2019/05/normandy-cemetary-1024x768.jpg)

**Figure 1. White crosses representing fallen American soldiers at Normandy.** Image credit: [commentarymagazine.com](https://www.commentarymagazine.com/articles/americas-regiment/)

- Peter once visited the [Beaches of Normandy](https://en.wikipedia.org/wiki/Normandy_landings) during December (so the weather was very similar to when the D-Day attack occurred)
- Peter was awestruck by the many white crosses lining the fields to represent fallen soldiers
- He was brought to tears looking at the ages of the young men (how many dreams were never realized?)
- He found himself pondering the question of… “Would we have lost the war if ‘John Smith’ hadn’t died on that day?” (an admittedly circular question)
- Jocko: “*No, we wouldn’t have lost the war if ‘John Smith’ didn’t die on that day. But if we didn’t have hundreds of thousands, millions, of ‘John Smiths’ that were ready to go and make the ultimate sacrifice, darkness would have prevailed.*”

==> Peter highly recommends the movie, [Saving Private Ryan](https://en.wikipedia.org/wiki/Saving_Private_Ryan)

## How warfare has evolved over the decades since WWI [2:05:40]

*How much of an evolution took place between* [*World War II*](https://en.wikipedia.org/wiki/World_War_II) *and the* [*Korean War*](https://en.wikipedia.org/wiki/Korean_War) *from the military, strategic and tactical point*?

- Pretty similar
- Except toward the end of the Korean War, it turned into almost like a [trench warfare](https://en.wikipedia.org/wiki/Trench_warfare) scenario
- They were in trenches and trying to push the Koreans trench back 100 yards
- But fortunately, the US learned from the nightmare trench warfare and high casualties sustained in WW1

World War I

- “The ultimate just nightmare of a war.” says Jocko
- [Battle of the Somme](https://en.wikipedia.org/wiki/Battle_of_the_Somme) ⇒ 60,000 casualties in the first 24 hours (For perspective, there has been less than 10,000 US casualties since 9/11 until today)
- “*The thing that I hate about World War I is it didn’t really matter how good you were with tactics, with leadership, with your skill level.*”
- It was a battle of attrition
- You would sit in a trench and wait your turn to charge and get mowed down by the enemy

> “It’s incredible that no senior leader called bullshit on it. No one said, ‘You know what, this is the dumbest thing I’ve ever heard. I’m not going to send my 700 man battalion to die tomorrow. I’m not going to do it. You can shoot me.’”

## Obeying orders and the obligation to dissent [2:09:00]

> “If something is not a good plan, then I’m not going to obey it. I’m not going to obey orders just for the sake of obeying orders.”

**When and how to disobey orders**:

- Not cut and dry
- If you just say “no” then the boss will find a yes man to do it
- An alternative is to say you disagree for reasons x,y,z and propose a different plan
- What if he still says, “I don’t care. Just do it.”?
  - You can either,
    - Mitigate risks to the best of your ability
    - Or you can stand your ground and say “You can find someone else.”
- Will the boss/leader actually listen to you?
  - It will depend on 2 things
    - One, your track record (i.e. have you always disobeyed order or is this rare)
    - Two, the humility of the leader

Book rec: [Where Men Win Glory](https://www.amazon.com/Where-Men-Win-Glory-Odyssey/dp/030738604X)

- A big part of the book is about the complete and utter futility of the mission that caused [Pat Tillman](https://en.wikipedia.org/wiki/Pat_Tillman) his life
- Jocko and Peter say this is an example of a time when someone should have stepped up and refused to obey an order

**Obligation to dissent**

- Jocko tells business and military leaders that there are times when you have an obligation to step up and say “I don’t think this is a good idea.”
- This is what makes leadership hard
- And it all stems from a lack of humility up the chain of command

Taking ownership of relationships

- As a subordinate leader, your goal is to gain the trust of those above you so that when you do speak up, they will listen
- You have to take ownership of that relationship
- Otherwise, you’re at the whim of some random person that you don’t know that doesn’t listen to you

## WWI and WWII, the beginnings of “decentralized command” [2:15:00]

About 20 years passed between WW1 and [WW2](https://en.wikipedia.org/wiki/World_War_II)

*What changed about the warfare strategy?*

- “Maneuver warfare”
- Towards the end of World War 1, the Germans started to employ decentralized command (i.e. allowing lower level people to make decisions)
- The concept of decentralized command came from Napoleon
- When the Germans, the Austrians, the Prussians got beat up by Napoleon and they started to say, “Why are we getting beat by Napoleon?” And what they realized was they had **too much centralized command**

**WW2**

- Jocko says the Germans began moving to decentralized command ([Blitzkrieg](https://en.wikipedia.org/wiki/Blitzkrieg)) and they would have continued to be successful had Hitler not reverted back to centralized command by trying to make decisions and telling the generals what to do

⇒ [Erwin Rommel](https://en.wikipedia.org/wiki/Erwin_Rommel)

- Decorated German general, eventually killed by Hitler bc Hitler thought Rommel was trying to kill him
- Book Peter read: [The Rommel Papers](https://www.amazon.com/Rommel-Papers-B-H-Liddell-Hart/dp/0306801574)
- Famous tactical book by Rommel: [Infantry Attacks](https://en.wikipedia.org/wiki/Infantry_Attacks)

*What lead to Germany/Hitler’s downfall?*

- Hitler’s arrogance in North Africa
- His arrogance to think he could fight on two fronts in the west and in the east
- The [Battle of Stalingrad](https://en.wikipedia.org/wiki/Battle_of_Stalingrad) (see Jocko’s [podcast episode #109](https://jockopodcast.com/2018/01/17/109-what-are-you-doing-that-you-know-you-shouldnt-be-stalingrad-memories-of-hell/)) where Hitler proclaimed the “great sacrifice” of the german soldiers while they were still alive

*If the Japanese had not attacked Pearl Harbor, would the US have gotten involved in WW2?*

- Eventually, says Jocko
- Perhaps it may have been too late, though

## The American warrior mentality, and the impact of freedom on a society [2:20:45]

Famous quote (Jocko can’t remember where it came from):

“When the Germans attack, they yell. When the British attack, they scream. When the French attack, they sing. When the Americans attack, they’re silent and they just keep coming. They will not stop.”

This quote stuck with him as a young kid

**The American warrior**

- Jocko says America has a warrior culture
- “We’re war fighters. We’re revolutionaries.”
- Jocko worries that we are losing that mentality a bit… “…we’ve lost it a little bit. We still have it, but there’s no doubt there is an American culture of fighting which is deep.”

*How to create peace*?

- Give people a taste of freedom ⇒ “*that’s the ultimate peacemaker*”

*Who doesn’t want freedom*?

- The people that don’t want freedom are the people that fear that their status will come undone because they’ll be judged on their performance

> “If you take a country where there’s no freedom and freedom starts to manifest itself, the people that will be scared of the freedom are the people that think ‘I’m going to be tested against everyone else and I’m going to fail so I’m just going to keep everyone under the heel.’”

*Does “benevolent freedom” work*?

- Egypt, for example…
- Does Jocko buy the argument that benevolent dictatorship is a better model than freedom or do you say that freedom can be included within benevolent dictatorship?
- Jocko: “*I think that those types of situations can be good to usher in true freedom over time. . . . [in Egypt], you’ve got the Muslim Brotherhood that is scared of freedom because they’re going to end up in the situation that they don’t have any control over, that they’re going to have to compete with other people, that they’re going to be judged on their merit rather than just being judged on their force. And so they want to stop that. Then you have the government come in and say, ‘Okay, you know what? We’re going to instill, we’re going to impose freedom. We’re going to impose discipline on the situation, get rid of people that feel that way’ and hopefully that creates a culture where we can eventually evolve to truly free society.*”

## What impact can an individual president really have? [2:25:00]

Peter’s daughter recently asked him who his favorite president was…

- Peter told her “probably Lincoln”
- But if you asked 10 people, half of them would probably say Teddy Roosevelt of FDR

Her follow up question was, “*what about recent presidents?*”

- Peter says it very tough to judge a presidency that has taken place in the last 40 years
- “By definition, any decision a president makes is brutal. Any book you read on presidents, no easy decisions come to them. So by definition, they’re only dealing with the world’s worst decisions and maybe part of me getting a little older is realizing the humility of that which is it’s a very long arc of history to be able to truly judge what another person did. And I think if anything, I’ve got more empathy for things that at the time, I felt very strongly about.”

Making decisions with the current info at hand

- They were making decision with the available insight at the time
- We have the benefit of hindsight
- So not only does it take time to pass to see if that was the right decision or not from a presidential standpoint, but you’ve got to look and say, “What did they actually know at that time?”
- And at the same time, you can “make a great decision and things can go horribly wrong and you can make a bad decision and things can be fine.”

Finally, there is the question of how much of an impact can a president really make?

- All presidents like to take credit for a good economy
- But the reality is there are so many factors that come in to play for everything that happens it’s hard to give credit or put blame on any one person

## The Korean war [2:29:15]

- Not much time passed between WW2 and the Korean War
- Many WW2 veterans also fought in Korea

[Dick Winters](https://en.wikipedia.org/wiki/Richard_Winters) (the famous WW2 commander featured in the [Band of Brothers series](https://en.wikipedia.org/wiki/Band_of_Brothers_(miniseries)))

- He actually made the choice NOT to go back to war
- “There was an example of a guy whose commitment and whose leadership is impeccable . . . he saw infinitely more, infinitely more, combat than I ever even came close to seeing. He came home, started a farm in Pennsylvania whatever and started doing his thing, carrying on with his life and got recalled and they said, “Hey, if you don’t want to go, you don’t have to.” He said, “Yeah, I’m going home.” Then he did. He went home. . . no one would ever question his patriotism, his willingness to sacrifice, his leadership.”

The Korean war featured war strategy similar to WW2, but then stagnated into WW1 style trench warfare

## Lessons learned from Vietnam [2:31:10]

The introduction on a large scale to guerrilla warfare

- Very challenging war
- On the one hand, we’re bigger, stronger, more well equipped, technologically more advanced against a foe that is inferior in all those ways; technology, industry, capability
- But we came up against someone that knew how to fight against us

***What lessons came from that war?***

The importance of winning over the populace

- The big thing in a counterinsurgency is you have to win over the populace and we didn’t do that… the Vietcong did that
- And that’s because they are the ones who protect you, who allow you to be camouflaged, who you mingle …
- Aside from winning hearts in the rebuilding, it seems like that’s also important in combat
- If you don’t win the populace over, they will, at a minimum, *passively* support the insurgents which is basically what happened in Vietnam

⇒ Jocko’s favorite book: [About Face](https://www.amazon.com/About-Face-Odyssey-American-Warrior/dp/0671695347) by Colonel David Hackworth

- He writes about guerrilla type war trying to win the hearts and minds of the people
- He had success doing it but the idea did not spread

Using the wrong metrics for deciding who’s winning the war

- We decided to use was body count as the metric ⇒ If we’re killing more of the enemy than they’re killing of us, then we’ll beat them in a war of attrition
- Example: [Battle of Ia Drang](https://en.wikipedia.org/wiki/Battle_of_Ia_Drang)
  - The kill count was ~173 to 1 (i.e. every one American that was dead, we suspected that we killed 173)
  - Americans thought that no one is going to put up with that
  - But guess what? The Vietcong was willing to put up with that
  - And the US won’t put up with losing a single man
  - “*There it is. There’s the answer.*”

***Relating this to business***

- Many companies are looking at metrics really hard
- They bring in a consulting company who will then use metrics to tell them what to do next
- But you’ve got to balance out what’s going on, the human side, the human factor, the leadership.
  - What’s unfolding inside the company?
  - What’s the culture inside the company?
- Because if you don’t have the right culture inside the company, the metrics aren’t going to matter.

> “You can’t drive your strategy based on pure metrics. And if you do that, you absolutely have problems.”

Documentary on Vietnam war: [The Fog of War](https://en.wikipedia.org/wiki/The_Fog_of_War)

## First Gulf War, Iraq War, and The War in Afghanistan [2:35:45]

The First Gulf war

- The biggest technological leap in warcraft
- Advances included:
  - “Smart bombs”
  - Stealth
  - Night vision (in Vietnam that had no night vision giving the enemy a great advantage)
- “*There is probably no greater delta in the technologic advantage between two entities than that war*.”

Iraq and Afghanistan

- Peter says that as a civilian, he had a hard time understanding the difference between what was going on in Afghanistan versus Iraq.
- *How interchangeable were the troops between those two war zones*?
  - All services were going back and forth
  - Marines, Army, special ops… all were going to both

[End of Part 1 — Part 2 will be released 6/3/19]

§

## Selected Links / Related Material

**Jocko was the commander of**: [SEAL Team 3’s Task Unit Bruiser in Iraq during the 2006 Battle of Ramadi](https://en.wikipedia.org/wiki/Jocko_Willink#Military_career) | (wikipedia.org) [4:15]

**Jocko’s leadership consulting company**: [Echelon Front](https://echelonfront.com/) | (echelonfront.com) [4:15, 2:34:30]

**Books written by Jocko**: [4:30]

- [Extreme Ownership](https://www.amazon.com/Extreme-Ownership-U-S-Navy-SEALs-ebook/dp/B00VE4Y0Z2) [44:00]
- [Dichotomy of Leadership](https://www.amazon.com/Dichotomy-Leadership-Balancing-Challenges-Ownership/dp/1250195772) [49:15]
- [Discipline Equals Freedom](https://www.amazon.com/Discipline-Equals-Freedom-Field-Manual/dp/1250156947)
- [Way of the Warrior Kid](https://www.amazon.com/Way-Warrior-Kid-Wimpy-Novel/dp/1250151074) (children’s book)
- [Marc’s Mission: Way of the Warrior Kid](https://www.amazon.com/Marcs-Mission-Way-Warrior-Novel/dp/1250156793) (children’s book)
- [Mikey and the Dragons](https://www.amazon.com/Mikey-Dragons-Jocko-Willink/dp/1942549431) (children’s book)
- [Way of the Warrior Kid 3: Where there’s a Will…](https://www.amazon.com/Way-Warrior-Kid-Where-theres/dp/1942549482) (children’s book)

**Podcast hosted by Jocko**: [Jocko Podcast](https://jockopodcast.com/) | (jockopodcast.come) [4:45]

**Episode of Jocko Podcast with Peter as his guest**: [56: OVERCOMING STRESS, SLEEP DEPRIVATION, AND THE DARKNESS WITH PETER ATTIA](https://jockopodcast.com/2017/01/04/56-overcoming-stress-sleep-deprivation-and-the-darkness-with-peter-attia/) | (jockopodcast.com) [4:45]

**Co-founder of Victory MMA in San Diego**: [Victory MMA and Fitness](https://www.victorygyms.com/) | (victorygyms.com) [5:00]

**Abu Ghraib prison scandal**: [Abu Ghraib torture and prisoner abuse](https://en.wikipedia.org/wiki/Abu_Ghraib_torture_and_prisoner_abuse) | (wikipedia.org) [9:15]

**“Great book” about humility**: [Being Wrong: Adventures in the Margin of Error](https://www.amazon.com/Being-Wrong-Adventures-Margin-Error/dp/0061176052) by Kathryn Schulz | (amazon.com) [40:15]

**George W. Bush speech standing at the base of the Twin Towers on 9/11**: [From CBS News archives: Bush visits ground zero days after 9/11](https://www.youtube.com/watch?v=xQuePDvlbDA) | CBS (youtube.com) [52:00]

**Invasion in Panama when four SEALS were killed on Punta Paitilla Airfield**: [Operation JUST CAUSE: Navy SEALs in Panama](https://www.navysealmuseum.org/about-navy-seals/seal-history-the-naval-special-warfare-storyseal-history-the-naval-special-warfare-story/operation-just-cause-navy-seals-panama) | (navysealmuseum.org) [55:15]

**Kevin Bacon movie about a soldier killed in action being taken home**: [Taking Chance](https://www.imdb.com/title/tt1019454/) | (imdb.com) [1:01:30]

**Getting past the loss of a loved one**: [How to Triumph Over Tragedy & The Loss of Good People – Jocko Willink](https://www.youtube.com/watch?v=NeXYq-2XPtw) | Jocko Podcast (youtube.com) [1:10:00]

**Book that Peter says reminds him of Jocko’s concept of “protocols”**: [12 Rules for Life: An Antidote to Chaos](https://www.amazon.com/12-Rules-Life-Antidote-Chaos/dp/0345816021) by Jordan Peterson | (amazon.com) [1:14:45]

**Episode of Jocko Podcast where Jocko tells a father how to deal with the loss of his son**: [157: WHEN TO PLAY THE GAME, WHEN TO BREAK THE RULES. ULTIMATUMS. MAKING CO-WORKERS’ SHAPE UP. COPING WITH LOSS.](https://jockopodcast.com/2018/12/26/157-when-to-play-the-game-when-to-break-the-rules-ultimatums-making-co-workers-shape-up-coping-with-loss/) | (jockopodcast.com)  [1:15:00]

**One of Peter’s favorite TED Talks where Ric Elias discusses the feeling of “knowing” you’re going to die**: [3 things I learned while my plane crashed](https://www.youtube.com/watch?v=8_zk2DpgLCs) | Ric Elias | TED (youtube.com) [1:25:15]

**David Foster Wallace commencement speech**: [This Is Water – Full version-David Foster Wallace Commencement Speech](https://www.youtube.com/watch?v=8CrOL-ydFMI&feature=youtu.be) | Jamie Sullivan (youtube.com) [1:25:30]

**Jocko using jiu-jitsu to explain how to figure out what really matters and what doesn’t**: [Don’t Get Caught Up in Things That Don’t Matter – Jocko Willink](https://www.youtube.com/watch?v=WAiZqtxbvYQ) | Jocko Podcast (youtube.com) [1:31:45]

**Book that describes WW2 as the last war in America where everyone felt conected and understood sacrifice**: [The Road to Character](https://www.amazon.com/Character-Thorndike-Press-Large-Print/dp/1594139377) by David Brooks (amazon.com) [1:59:30]

**Movie recommendation by Peter which vividly depicts that madness and sacrifice by the soldiers who stormed the beaches of Normandy on D-Day**: [Saving Private Ryan](https://en.wikipedia.org/wiki/Saving_Private_Ryan) | (wikipedia.org) [2:03:00]

**Book about Pat Tillman’s death by friendly fire**: [Where Men Win Glory](https://www.amazon.com/Where-Men-Win-Glory-Odyssey/dp/0385522266/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Jon Krakauer (amazon.com) [2:11:15]

**Peace treaty that brought WW1 to an end**: [Treaty of Versailles](https://en.wikipedia.org/wiki/Treaty_of_Versailles) | (wikipedia.org) [2:16:15]

**Book about Erwin Rommel that Peter read**: [The Rommel Papers](https://www.amazon.com/Rommel-Papers-B-H-Liddell-Hart/dp/0306801574) by B. H. Liddell-Hart (amazon.com) [2:17:00]

**Famous book written by Erwin Rommel**: [Infantry Attacks](https://en.wikipedia.org/wiki/Infantry_Attacks) by Erwin Rommel (wikipedia.org) [2:17:15]

**Episode of Jocko Podcast where he discusses the Battle of Stalingrad**: [109: WHAT ARE YOU DOING THAT YOU KNOW YOU SHOULDN’T BE? “STALINGRAD MEMORIES OF HELL”](https://jockopodcast.com/2018/01/17/109-what-are-you-doing-that-you-know-you-shouldnt-be-stalingrad-memories-of-hell/) | (jockopodcast.com) [2:18:45]

**Show depicting Dick Winters leading a mission to liberate Nazi concentration camps**: [Band of Brothers (miniseries)](https://en.wikipedia.org/wiki/Band_of_Brothers_(miniseries)) | (wikipedia.org) [2:29:30]

**Episode of Jocko Podcast about Dick Winters**: [75: GUIDELINES FOR LEADERSHIP ARE HONESTY, DEPENDABILITY, DISCIPLINE AND FAIRNESS. “CONVERSATIONS W/ DICK WINTERS”](https://jockopodcast.com/2017/05/17/75-the-guidelines-for-leadership-are-honesty-dependability-discipline-and-fairness-conversations-w-dick-winters/) | (jockopodcast.com) [2:29:45]

**Jocko’s favorite book**: [About Face: The Odyssey of an American Warrior](https://www.amazon.com/About-Face-Odyssey-American-Warrior/dp/0671695347) by Colonel David Hackworth (amazon.com) [2:33:00]

**Documentary on Vietnam war**: [The Fog of War](https://en.wikipedia.org/wiki/The_Fog_of_War) [2:35:15]

§

## People Mentioned

- [Kirk Parsley](https://twitter.com/docparsley?lang=en) (former SEAL, sleep expert, mutual friend) [5:00]
- [Olivia Attia](https://peterattiamd.com/sneak-peek-peter-attia-drive/) (Peter’s daughter, big fan of Jocko) [6:15]
- [Denis Calabrese](https://www.americanconference.com/speakers/mr-denis-calabrese/) (Peter credits him for his current way of differentiating between objective, strategy and tactics) [8:00]
- [Josh Martin](https://www.facebook.com/josh.martin.319) (Peter’s body work guy) [10:30]
- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) [16:30]
- [Kathryn Schulz](https://en.wikipedia.org/wiki/Kathryn_Schulz) (author of Being Wrong) [40:15]
- [Bill Clinton](https://en.wikipedia.org/wiki/Bill_Clinton) (amazing memory with names) [40:30, 2:28:30]
- [Chris Sonnenday](https://www.uofmhealth.org/profile/1426/christopher-john-sonnenday-md) (Peter says example of a humble leader, “best senior resident I ever had”) [52:45]
- [Kevin Bacon](https://en.wikipedia.org/wiki/Kevin_Bacon) ([Taking Chance](https://www.imdb.com/title/tt1019454/) movie) [1:01:30]
- [Marc Lee](https://en.wikipedia.org/wiki/Mark_Lee) (first seal killed in Iraq, SEAL Team 3) [1:18:00]
- [Mikey Monsoor](https://en.wikipedia.org/wiki/Michael_A._Monsoor) (second seal killed in Iraq, SEAL Team 3) [1:18:00]
- [Ryan Job](https://www.azcentral.com/story/ejmontini/2015/02/07/chris-kyle-american-snyper-ryan-job-warriors-faith-book/22985089/) (killed in Iraq, SEAL Team 3) [1:18:00]
- [Jordan Peterson](https://twitter.com/jordanbpeterson) (author of 12 Rules for Life) [1:14:45]
- [Ric Elias](https://www.ted.com/speakers/ric_elias) (one of Peter’s favorite [TED Talks](https://www.youtube.com/watch?v=8_zk2DpgLCs)) [1:25:15]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) (delivered a powerful commencement speech) [1:25:30]
- [David Brooks](https://en.wikipedia.org/wiki/David_Brooks_(commentator)) (author of The Road to Character) [1:59:30]
- [Pat Tillman](https://en.wikipedia.org/wiki/Pat_Tillman) (soldier killed in friendly fire) [2:11:15]
- [Napoléon Bonaparte](https://en.wikipedia.org/wiki/Napoleon) (“obligation to dissent”) [2:14:00]
- [Adolf Hitler](https://en.wikipedia.org/wiki/Adolf_Hitler) (leader of the Nazi party) [2:17:00]
- [Erwin Rommel](https://en.wikipedia.org/wiki/Erwin_Rommel) (famous German general who wrote fascinating books about war) [2:17:00]
- [George C. Scott](https://en.wikipedia.org/wiki/George_C._Scott) (played Patton in the movie) [2:18:00]
- [Abraham Lincoln](https://en.wikipedia.org/wiki/Abraham_Lincoln) (Peter’s favorite president) 2:25:00
- [Teddy Roosevelt](https://en.wikipedia.org/wiki/Theodore_Roosevelt) (popular past president) [2:25:00]
- [FDR](https://en.wikipedia.org/wiki/Franklin_D._Roosevelt) (popular past president) [2:25:00]
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) (war in Iraq) [2:26:15]
- [Lyndon B. Johnson](https://en.wikipedia.org/wiki/Lyndon_B._Johnson) (president with influence on Vietnam war) [2:27:00]
- [John F. Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy) (president with influence on Vietnam war) [2:27:00]
- [Harry Truman](https://en.wikipedia.org/wiki/Harry_S._Truman) (president with influence on Vietnam war) [2:27:00]
- [Dick Winters](https://en.wikipedia.org/wiki/Richard_Winters) (commander of Easy Company of the 2nd Battalion, 506th Parachute Infantry Regiment, depicted in Band of Brothers series, chose not to go back to war in Korea) [2:29:30]
- [Colonel David Hackworth](https://en.wikipedia.org/wiki/David_Hackworth) (author of Jocko’s favorite book [About Face](https://www.amazon.com/About-Face-Odyssey-American-Warrior/dp/0671695347)) [2:33:00]
- [Robert S. McNamara](https://en.wikipedia.org/wiki/Robert_McNamara) (Fog of War documentary) [2:35:15]
- [William Westmoreland](https://en.wikipedia.org/wiki/William_Westmoreland) (commander of United States forces during the Vietnam War from 1964 to 1968) [2:35:15]

§

![](https://peterattiamd.com/wp-content/uploads/2019/05/jockowillink02-1x1.jpeg)

##### Jocko Willink

Jocko Willink is a retired U.S. Navy SEAL officer, co-author of the #1 New York Times bestseller Extreme Ownership: How U.S. Navy SEALs Lead and Win, host of the top-rated Jocko Podcast, and co-founder of Echelon Front, where he serves as Chief Executive Officer, leadership instructor, speaker and strategic advisor. Jocko spent 20 years in the SEAL Teams, starting as an enlisted SEAL and rising through the ranks to become a SEAL officer. As commander of SEAL Team Three’s Task Unit Bruiser during the battle of Ramadi, he orchestrated SEAL operations that helped the “Ready First” Brigade of the U.S. Army’s First Armored Division bring stability to the violent, war-torn city. Task Unit Bruiser became the most highly decorated Special Operations Unit of the Iraq War.

Jocko returned from Iraq to serve as Officer-in-Charge of training for all West Coast SEAL Teams. There, he spearheaded the development of leadership training and personally instructed and mentored the next generation of SEAL leaders who have continued to perform with great success on the battlefield. Jocko is the recipient of the Silver Star, the Bronze Star, and numerous other personal and unit awards.

Upon retiring from the Navy, Jocko co-founded Echelon Front, a premier leadership consulting company, where he teaches the leadership principles he learned on the battlefield to help others lead and win. Jocko also authored the Discipline Equals Freedom Field Manual, a New York Times Bestseller, and the best selling children’s books: The Way of the Warrior Kid, and The Way of the Warrior Kid: Marc’s Mission.

[echelonfront.com]