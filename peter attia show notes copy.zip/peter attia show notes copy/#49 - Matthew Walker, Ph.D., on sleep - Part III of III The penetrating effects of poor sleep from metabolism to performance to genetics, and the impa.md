# #49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep

**Source:** [https://peterattiamd.com/matthewwalker3/](https://peterattiamd.com/matthewwalker3/)

---

##### Check out more content with sleep expert, Matthew Walker, Ph.D.:

- *(April 1, 2019)* [Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, and memory](/matthewwalker1/)
- *(April 8, 2019)* [Part II of III: Heart disease, cancer, sexual function, and sleep disruption](/matthewwalker2/)
- *(April 15, 2019)* [Part III of III: The penetrating effects of poor sleep from metabolism to genetics](/matthewwalker3/)
- *(June 17, 2019)* [AMA #1: Strategies for sleeping more and sleeping better](/matthewwalkerama/)
- *(October 28, 2019)* [AMA #2: short sleep mutants, optimal sleep environment, & sleep apnea](/matthewwalkerama2/)
- *(August 31, 2020)* [Sleep & Covid-19: Sleep and immune function, chronotypes, and hygiene tips](/matthewwalker4/)
- *(September 7, 2020)* [AMA #3: Fasting, gut health, blue light, caffeine, REM sleep, and more](/matthewwalkerama3/)

In the final part of this 3 part series, Matthew Walker, professor of neuroscience at UC Berkeley and expert on sleep, discusses the omnipresent effects of insufficient sleep on everything from metabolism, appetite, athletic performance, decision-making, productivity, leadership, mental health, genetics, memory, and more. We also discuss the impact of caffeine and alcohol on sleep quality, the efficacy of sleep aids such as THC and CBD, and much more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/matthewwalker3/the_Drive_public.png)

Play

#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep

#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep

1x15s30s

0:002:01:06

## We discuss:

- Sleep and insulin resistance [6:15];
- Epigenetic changes with insufficient sleep, and the reversibility of lost sleep [18:00];
- Sleep’s impact on exercise performance, appetite, and food choices [28:15];
- Decision making, workplace production, leadership qualities, physical attractiveness, and more [43:15];
- The broken water pipe analogy [49:30];
- The negative effect of caffeine, alcohol, and high carb meals on sleep quality [53:30];
- The efficacy of THC and CBD as sleep aids [1:05:30];
- Sleep and mental health: A two-way street [1:16:45];
- How sleep impacts memory, and Matthew’s current and upcoming projects [1:24:00];
- Sleep’s impact on athletes: Looking at Formula One drivers [1:32:45];
- Translating the science to clinical application [1:57:00]; and
- More.

§

## Show Notes

## Sleep and insulin resistance [6:15]

**[Paper](https://www.ncbi.nlm.nih.gov/pubmed/10543671/): U of Chicago**

- Group of subjects measured by euglycemic clamps (keep glucose level steady by titrating insulin levels measure how well you dispose of glucose, primarily in muscle)
- Got 4 hrs of sleep a night for 2 weeks (study now replicated with 4, 5, 6 hrs for one week)
- 50% reduction in ability to put glucose into their muscle – (Peter says: 1 of 5 most important physiologic functions)
- Normal blood glucose is ~100 mg/dL (that is about 5 g of glucose/5 mmol/1 teaspoon of sugar in the blood)
- Diabetic person has 200 mg/dL (10-11 mmol/2 teaspoons)
- After one week of sleep deprivation, these previously healthy people are now looking pre-diabetic (“*You’re writing them a Metformin prescription.*”)

In other words…

- Bloodstream levels of glucose are trivial compared to the amount in the muscles and liver
- And if the body can’t clear that glucose, it affects everything
- Peter, reflecting on his own metabolic dysfunction following med school, says poor sleep likely played a big role in his weight gain, insulin resistance, hypogonadism, low testosterone, etc.

*What is the mechanism of how lack of sleep makes everything go awry?*

Two major parts in the regulation of glucose:

- First, [beta cells](https://en.wikipedia.org/wiki/Beta_cell) (β cells) in pancreas sense spike in blood glucose and then release insulin
- Secondly, to absorb blood glucose, tissues must be sensitive to insulin

Either, or both, can be affected

- There can be a deficit in one of those two pathways (for example, in pregnancy, cells can become less sensitive so pancreas releases more insulin)
- With sleep deprivation, you have a deficit in BOTH
- β cells become insensitive to spike in blood glucose
- And the cells become insensitive to signal of insulin
- Now you have an **inability to clear glucose on both sides of glucose equation**

*Why are the cells so mute to the signal of insulin?*

*⇒* [Study showing impaired insulin signaling](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4435718/)

- Biopsied cells around umbilicus from healthy adults after 4-5 hours of sleep vs. 8 hrs of sleep
- Looked at adipocyte cells taking up insulin
- A critical process for getting glucose uptake is that [Akt](https://en.wikipedia.org/wiki/Protein_kinase_B) gets phosphorylated, which helps the GLUT4 transporter to go to surface of the cell, which then allows the cell to bring glucose in
- Amount of **insulin required to phosphorylate Akt almost doubled** when subjects did not get enough sleep
- **This seems counterintuitive to Peter**: “*You’d think that the adipocyte would be even more sensitive to insulin as the body works harder to undergo esterification and put fat away given that the muscle becomes more resistant to insulin. Of course, this speaks to why many hormones are necessary to drive the metabolic derangement, because also the cortisol level would maybe even oppose that. In isolation, what you just described would actually oppose re esterification of fatty acid.*”
- **Matthew**: “*Yeah, but in my mind, I think what’s striking though it starts to tell you that individual cell types need sleep.*”

*What is the communication vehicle telling the phosphorylation to be less efficient?*

- We don’t know the intracellular mechanisms making this happen
- But *extracellular* signals are clearly making intracellular functions maladaptive or less efficient

## Epigenetic changes with insufficient sleep, and the reversibility of lost sleep [18:00]

> “We often think of the impact of a lack of sleep on things like behavior, like driving, or making food choices. . . but there is something about a lack of sleep that will get even into cells themselves and alter intracellular functioning. If a single factor (sleep) can have its impact all the way from complex cognitive issues like decision making, all the way down to something like intracellular function, my goodness you need to look out if you’re depriving yourself of that one function.”

**Epigenetic changes**

[PNAS paper](https://www.pnas.org/content/110/12/E1132)

- Group of healthy adults limited to 6 hours of sleep a day for 1 week (About the typical sleep adults get on avg.)
- They found a **change in the activity of 711 genes** compared to when the subjects got 8 hrs of sleep (epigenetic change in 3% of their genome, only about 20,000 genes in our genome)
- About half of the genes were upregulated and half downregulated
- Downregulated (impaired) genes were ones associated with the immune system
- The ones upregulated genes were associated with tumor production, long-term chronic inflammation, and stress / cardiovascular disease

*⇒ Losing sleep is like doing a genetic test on yourself*

- People feel uncomfortable about genetically modified embryos, [CRISPR](https://en.wikipedia.org/wiki/CRISPR), GMO, genetically modified foods, etc.
- But you’re performing a similar experiment on yourself by not getting enough sleep
- And if you don’t let your children get the sleep that they need, *you may be inflicting inadvertently a genetic manipulation on them as well*

**Are sleep deprivation effects reversible with adequate sleep?**

- Sleep is not like a debt that you can repay (can’t make it up later, e.g., on weekends)
- The damage from lack of sleep doesn’t seem to be reversible
- However, that doesn’t mean that from this point forward, it’s a waste of time to start sleeping better

*Evidence that fixing sleep (even in later life is a great thing):* [Sleep apnea study in older adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4433459/)

- Adults with sleep apnea were given a CPAP to ensure they got enough oxygen
- Roughly half of the group complied with treatment and the other half did not
- The ones who complied held off Alzheimer’s disease by 10 years
- So correcting your sleep can actually change your risk of dementia
- It’s a hopeful message: **it’s never too late to start sleeping better**
- It’s hard to know what sleep was the direct cause of the slowing of cognitive decline
- It could be that sleep is the influencing factor ⇒ because you’re sleeping, that you start to eat better, exercise more and better, have more energy to make healthier choices, etc.

## Sleep’s impact on exercise performance, appetite, and food choices [28:15]

**Physical activity and food choices**

- When you are underslept, you are less likely to be motivated to be physically active
- And when you do convince yourself to exercise,
  - Less force pressure you can generate
  - A [reduction in the time it takes you to reach physical exhaustion](https://www.ncbi.nlm.nih.gov/pubmed/7199438) up to 30% (E.g. if you normally reach physical exhaustion at 10k then you’ll reach it at 7k)
- With enough sleep…
  - you will make better food choices
  - lower your caloric intake
  - increase calories expended
  - more motivated to be active
  - and work out more intensely
- All of these things benefit cognitive decline, so if sleep is not ultimately the thing that is transacting the cognitive benefits, maybe is it the *root cause*
- That said, it may be playing some direct part, though, given what we’ve found about sleep and protein pathology in Alzheimer’s

It’s never too late to start sleeping better

- If you have been sleep deprived in the past, don’t think that your fate is sealed
- Just like people with T2D can improve by making changes to diet and exercise
- And how long-time smokers can improve just by quitting (also parallels because people who quit smoking may then be motivated do make other positive health changes)

No hope for a randomized, prospective trial

- Unethical to majorly deprive people of sleep
- Also can even ethically deprive people with sleep apnea of CPAP

*So how can we show benefits of correcting sleep?*

- Only way we’re going to be able to show the importance of sleep in kids is by having them sleep more
- Kids of all ages sleep about 2 hours less per night than they did 50 years ago (no ethics committee would approve a study that would make kids lose 2 hours of sleep for a month yet we did it as a society)
- Future studies will probably not be of sleep restriction but of **sleep interventions and extensions**

Diabetes and sleep apnea

- People with untreated sleep apnea have far higher rates of diabetes
- When they are treated, their diabetic profile improves markedly
- But so do their food choices, their exercise, etc. so unclear if it’s a direct benefit of sleep improving cellular processes or if it’s more a higher-order issue (when well-rested, you eat better, etc.).

**Sleep and appetite regulation**

- [This paper](https://www.ncbi.nlm.nih.gov/pubmed/17308390/) shows that subjects limited to 4-6 hours of sleep per night for 1 week will have:
  - Downregulated [leptin](https://en.wikipedia.org/wiki/Leptin) (the satiety hormone that signals to your brain that you are full and don’t need to eat anymore) is turned down
  - Upregulated [ghrelin](https://en.wikipedia.org/wiki/Ghrelin) (a hunger hormone signaling the body to eat more) is ramped up
- People sleeping 6 hours a night [will eat extra calories](https://www.ncbi.nlm.nih.gov/pubmed/20357041/) during the next day

![](https://peterattiamd.com/wp-content/uploads/2019/04/sleep-loss-and-obesity-1024x789.png)

**Figure 1. Sleep loss and obesity.** Image credit: [Why We Sleep](https://download.audible.com/product_related_docs/BK_SANS_008129.pdf)

*Peter struggles with food choices when sleep deprived*

- When flying from NYC to California, he has to wake up at 4am
- “That is unquestionably one of the worst eating days of my life **if I let it be**.”
- Takes a ton of planning a brief moments of discipline to overcome the crazy cravings he has under those sleep deprived conditions (i.e. wants pizza for breakfast)
- Tricks he’s learned
  - Will make sure to have a good filling breakfast before getting on the plane
  - Do not eat ANYTHING on the plane
  - When land in CA he will have a filling snack (avocado and macadamia nuts)
  - Won’t eat again until dinner which he will have early at 5pm
  - Then goes to bed at 8pm
- **Matthew**: “*So imagine someone like you [Peter] who has the knowledge that they have about sleep and then has this maniacal discipline to be able to fast for long periods of time. Even you with that arsenal of benefit in place can struggle under the weight of sleep deprivation. No wonder the majority of us non-demigods of control will implode so quickly.*”

Jocko Willink

- Peter: “I’d love to see what Jocko would do under sleep deprived conditions with respect to food.”
- Matthew: “I would love to have a conversation, just an honest frank conversation about sleep with him.”

**Type of food**

- It’s not just that you overeat when you are underslept, it’s also the food profile that suffers

[*Study looking at food choices*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3763921/) *when sleep deprived*:

- Subjects sleep 4-5 hours a night for a week
- Let them eat anything they want from a buffet, they not only eat more calories but also worse foods (pizza, cookies, and ice cream instead of protein, nuts, and leafy greens)

[*Brain scan study*](https://www.ncbi.nlm.nih.gov/pubmed/21430147/) *looking at reactions to food*

- Subjects with restricted sleep were shown pictures of different food while in a brain scanner
- The prefrontal cortex of the brain, which keeps hedonic desires in check, is impaired by sleep deprivation
- And the more primitive areas of the brain like the amygdala “erupted” in response to desirable foods

## Decision making, workplace production, leadership qualities, physical attractiveness, and more [43:15]

> “Essentially, you’re losing impulse control networks within the brain.”

There are places where controlling impulsivity is critical yet sleep deprivation is common:

- The military
- Aviation
- Stock markets (Michael Lewis has talked to Matthew about how common sleep deprivation is on Wall Street)

[Work from Chris Barnes at University of Washington](https://foster.uw.edu/faculty-research/directory/christopher-barnes/) suggests that employees who are sleeping 6 hours or less:

- First, these employees select less challenging problems
- Second, they produce fewer creative solutions to the problems they do select
- Third, employees working in teams just slack off and let others work (social loafing)
- Four, they became more deviant and less ethical (they falsified data and reimbursement claims, they claimed they’d done work other people had actually done)

Study looking at [leadership qualities and sleep deprivation](https://www.ncbi.nlm.nih.gov/pubmed/27159583)

- Looked at the sleep of a business leader
- Found that less sleep he had, **the less inspiring and charismatic his employees found him**
- “*Even though they knew nothing about the sleep of that leader, it was evidential in their behavior*.”

**Sleep’s impact on physical appearance, dating, and mating**

⇒ [Sweden study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5451790/) of the perceived attractiveness of people in a rested state vs. a sleep deprived state

- Took a picture of people under two conditions, full night sleep and sleep deprived
- Then they asked neutral judges to rate their appearance
- The unslept picture was consistently rated as less attractive, more sickly and tired looking
- So there’s some scientific proof of “beauty sleep.”
- If you are trying to find a mate or be intimate, you won’t look your best if you’re sleep deprived

## The broken water pipe analogy [49:30]

> “There is truly no aspect of a human being’s wellness that isn’t eroded by a lack of sleep. Lack of sleep is like a broken water pipe in your home. . .it will leak down into every nook and cranny of your physiology.”

- Sleep impacts the macro (complex diseases, leadership qualities, and physical appearance)
- Sleep impacts the micro (intracellular pathways, phosphorylation of AKT)
- Like leaking water, sometimes it’s gushing, and other times it’s a slow drip.
- “There are few things in your biology or your psychology that can retreat at the sign of sleep deprivation and get away unscathed.”

*Evolution didn’t prepare us for sleep deprivation*

- In an evolutionary sense, we’ve kept this strange thing around for half a billion years
- Sleep is a ridiculous proposition and makes no sense on the surface
- While you’re sleeping you can’t get food or mate or protect yourself or care for your children
- We’ve had time to prepare for starvation (ketosis) and excess food as we evolved as a species
  - See [this paper by Rick Johnson](https://www.pnas.org/content/111/10/3763) on genetic changes in metabolism of fructose allowed us to fatten up in the fall when fruit was sweeter, which was a little bit of preparation for what we do with excess nutrients in the modern era
- But only in the last 150-250 years (and particularly the last 40) has there been a new pressure to reduce sleep

## The negative effect of caffeine, alcohol, and high carb meals on sleep quality [53:30]

> “We know for a fact that 10 million American adults in the past month have swallowed some kind of a sleep aid.”

**Alcohol**

- Alcohol is probably the most misunderstood “sleep aid”
- But alcohol does 3 things to sleep:
  - 1) it’s a sedative so works like sleeping pills… you might lose consciousness more quickly, but you’re not “falling asleep” faster
  - 2) alcohol [fragments sleep](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2775419/) so you wake up many more times during the night; often so brief that you don’t remember but they have an impact on your physiology
  - 3) alcohol [blocks REM sleep](https://www.ncbi.nlm.nih.gov/pubmed/23347102), so you wake up unrefreshed and unrestored

**Caffeine**

- People often take caffeine (“adenosine-reducing substance”) to stay awake
- Should not need caffeine before midday ⇒ your peak alertness should be around 11 or 12
- Matthew notices that many people sleep on a plane at 10am when they should be getting to their most alert state

*How caffeine works*:

- Adenosine builds up like a sleepiness signal and when you have a lot, it tells you to go to sleep
- Caffeine blocks adenosine receptors in the brain ⇒ it’s hitting the “mute button” on sleepiness

*How long does caffeine last in your system?*

- Caffeine has a half-life of 6 hours
- And a quarter life of 12 hours
- So if you drink a full cup of coffee at noon, quarter of that caffeine is still in the brain at midnight
- It’s like drinking a *quarter of a cup of coffee* right before bed
- Even for people who say they sleep just fine after consuming caffeine, one study showed that 200 mg of caffeine before bed resulted in a 20% reduction in deep sleep (the same as aging you 20 or 30 years to get the same drop)

*Are there variations in people’s responses to caffeine?*

- Peter says caffeine has no effect on him, when he’s tired, it will NOT wake him up
- Some people are more sensitive to it than others ⇒ There is variation in the genes that are associated with the enzyme that decomposes caffeine
- But… **it is unclear whether people who are less sensitive to caffeine also have less reduction of their deep sleep**.

**Using the** [**Oura ring**](https://ouraring.com/) **to see the effects of alcohol**

- [Peter discloses that he is an investor and advisor in Oura]
- “*There is no greater behavioral tool to show you the deleterious effects of alcohol than this ring.*”
- Most people’s sleep is affected with *just one or two drinks*
- For Peter…
  - A single drink 4-5 hours before bed does *not* have an effect
  - But, 2 drinks 4-5 hours before bed, or just a single drink a couple hours before bed and “my sleep is shot”
    - Resting heart rate 6-8 beats higher
    - Heart rate variability is compressed by 20%
    - Respiratory rate is increased by 2 breaths/minute
    - Body temperature up by .3-.6 degrees

![](https://peterattiamd.com/wp-content/uploads/2019/04/oura-ring-HRV-576x1024.png)

**Figure 2. Oura ring results from Peter showing HRV**

⇒ This is bad news for people who enjoy a night cap

- You need your heart rate to decrease
- You need to drop your core body temp by 2-3 degrees F to initiate sleep
- But alcohol raises your core body temperature, so you get more fragmented sleep, more awakenings, and you disrupt REM sleep
- “On every one of those levels, that’s exactly what we see in a scientific evidence.”

⇒ Alcohol makes you have to pee more in the night

- Alcohol inhibits [vasopressin](https://en.wikipedia.org/wiki/Vasopressin)
- So you urinate disproportionately more than you’re consuming because it inhibits an anti-diuretic hormone

⇒ High carb meal before bed

- A meal high in “bad” carbohydrates (i.e. bowl of cereal) can have a harmful effect on sleep quality similar to alcohol
- Peter has seen this consistently in himself

## The efficacy of THC and CBD as sleep aids [1:05:30]

**Review of the literature on THC and CBD** ⇒ [Cannabis, Cannabinoids, and Sleep: a Review of the Literature.](https://www.ncbi.nlm.nih.gov/pubmed/28349316)

**THC**

- THC is not a good sleep aid for a teenager (because their brain is still developing)

*Does THC help sleep in adults?  ⇒* “No. I don’t think I’d feel comfortable in suggesting that it’s a pro sleep compound.”

*What about different strains (sativa vs. indica)?* ⇒ Not enough data to differentiate among strains

*What does THC do for sleep?*

- THC does make you [fall asleep faster](https://www.ncbi.nlm.nih.gov/pubmed/15118485) (reduces sleep latency)
- But like alcohol, it [blocks REM sleep](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2442418/)

*THC tolerance*

- With regular use of THC…
  - you start to lose the sleep latency benefit
  - And if you try to quit using it, many people get “[rebound insomnia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4446186/)”

[**Cannabidiol**](https://en.wikipedia.org/wiki/Cannabidiol) **(CBD)**

- There’s not enough data yet on CBD as a sleep aid, although the data is more promising than THC
- But it’s very hard to get studies funded because of the “moral” factor
- Matthew would love to do a study on CBD (is considering something like [Kickstarter](https://www.kickstarter.com/) to crowdsource the funding)

What the early data on CBD is showing:

- Falling asleep faster with CBD
- Early tentative preliminary evidence suggests it *does not* have the same negative impact on REM
- Also fewer dependency issues and don’t get insomnia rebound
- CBD might also benefit some sleep disorders
  - Might reduce severity of sleep apnea
  - Might also help [PTSD-related sleep problems](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5101100/)
- Caveats
  - It’s dose dependent, and it’s not clear at this point what the optimal dose is
  - There **may be other doses that are actually detrimental to sleep** and we need to stay away from them
  - So it might that there is a U-curve with a “sweet spot” for dosing with other doses being detrimental to sleep

*Does CBD increase your deep sleep?*

- Not enough evidence to say it *definitely* increases the amount of deep sleep
- But there is *some promising data (one single, small study)*

*By what mechanism is CBD potentially improving sleep?*

- Lowering core body temperature
  - One hypothesis is that CBD may decrease your core body temperature, leading to better sleep
- Anxiety
  - Another is indirect benefits through its reduction of anxiety, for which evidence is strongest right now
  - Anxiety is a major cause of insufficient or poor sleep
  - If you lower the “fight or flight” response, you get a more parasympathetic state and/or your core temperature drops

Peter has seen some anecdotal evidence of impressive results with CBD

- Seems to especially work for people with existing sleep issues
- For those who sleep well already, CBD doesn’t seem to improve it
- And it does not work for everyone
- But Peter has seen patients for which medications won’t work for them but CBD oil does, it’s not clear why

## Sleep and mental health: A two-way street [1:16:45]

**Case study of Peter’s patient:**

- Sleep quality was suffering even though they had tried everything…
  - Control the room temperature
  - Control the light
  - Control the nutrients and diet
  - Eliminate the alcohol
  - Eliminate the caffeine
  - Hour of meditation a day
  - 50 milligrams of [Thorazine](https://en.wikipedia.org/wiki/Chlorpromazine) to just try to shut off the ruminative properties
- But the patient was facing a difficult personal struggle
- He ended up using [MDMA](https://en.wikipedia.org/wiki/MDMA) (under clinical supervision) to deal with some of the underlying issues (trauma, anxiety, depression, etc.)
- The *next day*, and for several months now, he sleep has been fixed
- Peter’s take:
  - “I think that is an outlier situation, but sometimes these outlier situations provide an insight into a mechanism.”
  - “To see this one thing, this one intervention work, and the patient would describe this as a transformational life experience, was just another example of the power of the mind and how the mind can get in its own way at times.*”*

**The bi-directionality of sleep and mental health**

> “The rise in anxiety has walked in lockstep with a rise in insomnia. I think we’ve got enough evidence to suggest that those two are probably not coincidental, but are significantly interrelated.”

- It goes both ways ⇒ Mental health affects sleep, but poor sleep also affects mental health
- Deprive people of sleep…
  - People without psychological problems can develop depression, anxiety, poor mood, etc.
  - One [single night of sleep loss can induce clinical anxiety](https://abstractsonline.com/pp8/#!/4649/presentation/38909) in a person who does not normally have it
  - “In the past 25 years, I have not been able to discover a single psychiatric condition in which sleep is normal.” says Matthew
  - “Sleep is essentially mental first aid.”
- Give someone anxiety…
  - Their sleep suffers
  - Like Peter’s patient above, curing mental problems and you can correct sleep problems
- Psychiatrists used to think poor sleep was a symptom of a disorder, but maybe they should have considered whether it was a cause

*How long does it take to develop issues?*

- It may take some issues a long time to develop (dementia)
- But others not long at all (memory consolidation and anxiety)
- After about *16 hours of being awake* many things start to go wrong, but **mental health seems to be one of the quickest to fall apart**

## How sleep impacts memory, and Matthew’s current and upcoming projects [1:24:00]

*What have you been doing during your sabbatical year?*

- Still the Director the [Center for Human Sleep Science](https://www.humansleepscience.com/) at Berkeley
- After book published, been doing public speaking and media appearances

**Check out Matthew on CBS This Morning**:

- Brain simulation company that has just gone public
- There is research showing that you can [boost the size and amplitude of deep sleep brain waves with electrical stimulation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5810920/)
- Hoping to do that for the elderly and people with dementia to see if we can retain some of their learning and memory by increasing deep sleep
- You place a device on your head that measures the brain waves and then sends electrical voltage into the brain
- It’s essentially trying to “sing in time” with the deep sleep waves, trying to boost the size of the slow waves ([which are diminished 50 to 80% in older adults](https://www.ncbi.nlm.nih.gov/pubmed/27325209))
- Matthew has already been able to demonstrate in young healthy adults that it can almost [double the amount of memory](https://www.nature.com/articles/nature05278) benefit that you get from sleep
- This this [Berkeley News article](https://news.berkeley.edu/2017/12/14/sleep-rhythms/) for more about the mis-timed brain waves of older adults

![](https://peterattiamd.com/wp-content/uploads/2019/04/OldYoungSleepWaves400.jpg)

**Figure 3: Compared to young adults (left), image shows how sleep spindles in older adults (right) peak too early in the slow wave cycle, leading to forgetting.** Image credit: [news.berkeley.edu](https://news.berkeley.edu/2017/12/14/sleep-rhythms/)

**Considering writing a second book**

- Unclear exactly what it will be about
- There’s “probably three candidates”

**Raising funds for the Sleep Center**

- We need to raise philanthropic donations to “fund science in ways that typical funding mechanisms will never do.”
- The University has just granted a philanthropic donor the ability to name the Sleep Center  (shameless plug if anyone out there wants to have a legacy name)

⇒ About some of the studies we’re doing:

- There’s a “strange cluster of outliers” of people in their 70s and 80s whose sleep patterns seem resistant to the usual age-related decline in sleep so we would love to find out why
  - But you can’t get funding for looking at why things go right, *only for when things go wrong*
- National Geographic coined the term, [Blue Zones](https://en.wikipedia.org/wiki/Blue_Zone), as places throughout the world where people live longer
  - Some of the data is controversial, but questions have been asked about social factors, diet, exercise.
  - But **no one has asked about sleep** in the Blue Zones, and that would be extremely difficult for me to get funding to study
- In general, Matthew wants to raise money for the center to look at some fundamental questions that are typically hard to get funding for but could make a real impact.

*Which branches of the* [*NIH*](https://en.wikipedia.org/wiki/National_Institutes_of_Health) *deal with sleep?*

- Lots of them
- Nation Institute on Aging, Neurology, CVD, Metabolism, Glucose, NAIDA (drug abuse).

*Should sleep have its own institute?*

- It seems like it should have its own institute, but it doesn’t
- Exercise, nutrition, and sleep are the three most fundamental things that keep humans alive longer and well
- Yet they are spread across NIH entities instead of standing on their own
- That could be good in the sense that they shouldn’t be separated out, but we might need a matrix
- NIH has supported a lot of sleep research, including some at Matthew’s center, however there are other fundamental questions that are just not going to get funded under government institutional mandates

**Advisor for Google/Verily**

- Scientific advisor for [Verily](https://en.wikipedia.org/wiki/Verily) (formerly Google Life Sciences)
- His goal is to shape their mission for sleep

⇒ About his experience working with Verily:

“You’ve got incredible people there, and the way in which they see problems is different. The time course over which they want to solve those problems is different. And the solutions and the expertise that they bring to those health problems are different. When I got the chance to work at Google Life Sciences, or essentially be an advisor there, I jumped at the chance. It was great to try and help shape that mission.”

## Sleep’s impact on athletes: Looking at Formula One drivers [1:32:45]

Sleep really matters in [Formula One](https://en.wikipedia.org/wiki/Formula_One) car racing (or any high speed car racing, really)

- F1 drivers are subject to incredible jet lag having to travel across the globe for races
- Sleep deprivation is going to affect margin of error and reaction time, which are essential in racing
- If there is one gold standard measure of insufficient sleep, it’s not only just your response time, your basic reaction time, but it’s the **number of times that you miss a response**
- This is called a lapse, or an error of omission (You omitted a response that should have been happening)
- Six hours of sleep for a week can drop your reaction time by as much as 300-400 milliseconds which in F1 racing can be the difference in being first and out of the race completely

*Peter’s observations in his racing simulator*

- Even after one alcoholic drink, he drives worse in a simulator
- Not legally drunk (.02-.03 BAC) even though I am not drunk and my blood alcohol is very low
- And not just reaction time ⇒ His spatial coordination goes down, “*which I think is a bigger problem*”

**Things affected by insufficient sleep in drivers/athletes**

- *Spatial attention*: Matthew says something called “spatial attention” goes down very quickly under conditions of sleep deprivation
- *Quick decision making*: When other racers are on the track, it becomes strategic and you have to make multiple decisions in split seconds, and sleep affects critical components of that
- *Judgement*: It’s incredible how much your judgment can be impaired when others are on the track probably due to sleep’s impact on impatience and impulsivity (can lead to irrational thinking)
- *Physical fitness*:
  - It’s a physical sport too, and when your physical performance is mismatched to your natural circadian rhythm (like with jet lag) you will not be able to perform your best
  - [Most world records are broken at the Olympics during the peak of most circadian rhythm](https://abcnews.go.com/Health/science-best-time-day-break-olympic-record/story?id=41266207) (about 1 or 2 in the afternoon)
- As an F1 driver, if you’re shifting dramatically among time zones, you are losing a competitive advantage
- We may be at maximum saturation with engineering and technology; it’s humans themselves that are important.  Athletes are paying attention to diet, nutrition, and mental health, but sleep is a factor too.

> “A team could spend 10 million on trying to shave off .1 of a second in a car, which would be heroic as an engineering accomplishment, yet you could be shaving off point .4 or .5 by way of human error by way of this thing called insufficient sleep, or mismatched circadian rhythm.”

*What separates the top professional athletes?*

- Peter says it’s **the ability to be consistently exceptional**
- Peter, for example, can have one exceptional lap in a racecar
- But the pros must do 70+ in a row for more than 2 hours without making a single error
- That is a ton of focus and concentration for a long period of time (more so than most other sports) ⇒ in neuroscience they refer to this as the “time on task effect”

**Time on task effect**

- The longer you do something, your sustained attention will wane for *pretty much any cognitive task*
- The longer you apply yourself to a task, the more insufficient sleep shows
- For example, for the first 30 seconds they perform as if they are rested, but at about 4-5 minutes in you really see a difference in performance if they are sleep deprived
- The biggest effect of sleep deprivation in terms of time on task is in *sustained attention and sustained spatial attention* so paying attention to these effects would be a benefit to racers

![](https://peterattiamd.com/wp-content/uploads/2019/04/NBA-performance-and-sleep-1024x774.png)

**Figure 4. NBA player performance.** Image credit: [Why We Sleep](https://download.audible.com/product_related_docs/BK_SANS_008129.pdf)

## Translating the science to clinical application [1:57:00]

**Peter:**

*“[An understanding of sleep] is probably the single biggest deficit within the toolkit of most physicians.”*

*“Few people are more critical of the absolute dearth of rigor in the nutrition field, but I think this is worse. It’s not the dearth in the quality of the research, it’s the dearth in the translation of that research to clinical application.”*

*“I think your work has had a greater impact here than anything I’m aware of, and I wish you all the continued success. I think you could argue part of our humanity depends on it.”*

**Matthew:**

*“I am on a mission to try to reunite humanity with the sleep that it is so desperately bereft of. . .but the research has not been translated to the clinical practice. . .and that’s part of the work that I do with trying to be a sleep advocate.”*

*“Early on in my career, I don’t think I did a very good job at communicating science, the importance of sleep to the public through the science, and that’s what I’ve been desperately trying to course correct with [Why We Sleep].”*

§

## Selected Links / Related Material

**U of Chicago paper about the impact of insufficient sleep on muscle’s sensitivity to insulin**: [Impact of sleep debt on metabolic and endocrine function.](https://www.ncbi.nlm.nih.gov/pubmed/10543671/) (Spiegel et al., 1999) [6:15]

**Study suggesting fat cells become insulin resistant during sleep deprivation**: [Impaired Insulin Signaling in Human Adipocytes After Experimental Sleep Restriction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4435718/) (Broussard et al., 2012) [14:15]

**PNAS paper showing 711 genes impacted by insufficient sleep**: [Effects of insufficient sleep on circadian rhythmicity and expression amplitude of the human blood transcriptome](https://www.pnas.org/content/110/12/E1132) (Möller-Levet et al., 2013) [18:45]

**Evidence that use of a CPAP for sleep apnea can stave off Alzheimer’s**: [Sleep-disordered breathing advances cognitive decline in the elderly](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4433459/) (Osorio et al., 2015) [26:30]

**Limited sleep decreases time to physical exhaustion**: [Effect of sleep deprivation on tolerance of prolonged exercise.](https://www.ncbi.nlm.nih.gov/pubmed/7199438) (Martin BJ, 1981) [29:15]

**Sleep affects appetite regulation and decreases leptin and increases ghrelin**: [Impact of sleep and sleep loss on neuroendocrine and metabolic function.](https://www.ncbi.nlm.nih.gov/pubmed/17308390/) (Van Cauter et al., 2007) [34:30]

**Sleep deprived people will eat extra calories the following day**: [Acute partial sleep deprivation increases food intake in healthy men.](https://www.ncbi.nlm.nih.gov/pubmed/20357041/) (Brondel et al., 2010) [36:15]

**People will choose unhealthy foods more often when sleep deprived**: [The impact of sleep deprivation on food desire in the human brain](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3763921/) (Greer et al., 2013) [40:15]

**Brain scanner studies showing the brain’s reaction to desirable foods in a sleep deprived state**: [Sleep deprivation amplifies reactivity of brain reward networks, biasing the appraisal of positive emotional experiences.](https://www.ncbi.nlm.nih.gov/pubmed/21430147/) (Gujar et al., 2011) [41:45]

**Effect of sleep deprivation on leadership**: [Too tired to inspire or be inspired: Sleep deprivation and charismatic leadership.](https://www.ncbi.nlm.nih.gov/pubmed/27159583) (Barnes et al., 2016) [45:30]

**Sweden study of the perceived attractiveness of people in a rested state vs. a sleep deprived state**: [Negative effects of restricted sleep on facial appearance and social appeal](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5451790/) (Sundelin et al., 2017) [47:30]

**Rick Johnson’s paper about the genetic changes in fructose metabolism that really saved us and enabled us to fatten up in the fall when the fruit were sweeter**: [Evolutionary history and metabolic insights of ancient mammalian uricases](https://www.pnas.org/content/111/10/3763) (Kratzer et al., 2014) [52:00]

**Alcohol will fragment your sleep**: [Disturbed Sleep and Its Relationship to Alcohol Use](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2775419/) (Stein et al., 2005) [55:00]

**Alcohol blocks REM sleep**: [Alcohol and sleep I: effects on normal sleep.](https://www.ncbi.nlm.nih.gov/pubmed/23347102) (Ebrahim et al., 2013) [55:00]

**Caffeine and sleep**: [Sleep to Remember: The brain needs sleep before and after learning new things, regardless of the type of memory. Naps can help, but caffeine isn’t an effective substitute](https://www.jstor.org/stable/27858801?seq=1#page_scan_tab_contents) (Walker, 2006) [58:30]

**Peter’s recommended sleep tracker (disclosure: he is an investor)**: [Oura ring](https://ouraring.com/) | (ouraring.com) [1:00:45]

**Review of the literature on THC and CBD**: [Cannabis, Cannabinoids, and Sleep: a Review of the Literature.](https://www.ncbi.nlm.nih.gov/pubmed/28349316) (Babson et al., 2017) [1:06:15]

**THC will decrease the amount of time it takes you to fall asleep**: [Effect of Delta-9-tetrahydrocannabinol and cannabidiol on nocturnal sleep and early-morning behavior in young adults.](https://www.ncbi.nlm.nih.gov/pubmed/15118485) (Nicholson et al., 2004) [1:06:45]

**THC is a very robust blocker of your dream sleep (REM sleep)**: [Sleep Disturbance in Heavy Marijuana Users](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2442418/) (Bolla et al., 2008) [1:07:15]

**Insomnia due to the quitting of marijuana (THC) usage**: [Cannabinoid abuse and addiction: Clinical and preclinical findings](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4446186/) (Panlilio et al., 2015) [1:07:45]

**Potential benefits of CBD on sleep (fall asleep fasting, increase in REM sleep, no dependency issues, PTSD-related sleeping issues)**: [Cannabis, Cannabinoids, and Sleep: a Review of the Literature.](https://www.ncbi.nlm.nih.gov/pubmed/28349316) (Babson et al., 2017) [1:12:00]

**CBD oil for sleep problems related to PTSD**: [Effectiveness of Cannabidiol Oil for Pediatric Anxiety and Insomnia as Part of Posttraumatic Stress Disorder: A Case Report](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5101100/) (Shannon et al., 2016) [1:12:30]

**CBD as wake-promoting**: [Potential Effects of Cannabidiol as a Wake-Promoting Agent](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4023456/) (Murillo-Rodriguez et al., 2014) [1:12:30]

**Different doses, different deep sleep (in rats)?** [Hypnoticlike effects of cannabidiol in the rat](https://link.springer.com/article/10.1007/BF00497858) (Monti, 1977) [1:13:00]

**THC & CBD and body temperature (in mice)**: [Absence of interaction between δ9-tetrahydrocannabinol (δ9-THC) and cannabidiol (CBD) in aggression, muscle control and body temperature experiments in mice](https://link.springer.com/article/10.1007%2FBF00421075?LI=true) (Ham and Jong, 1975) [1:13:30]

**CBD and anxiety**: [Cannabidiol Reduces the Anxiety Induced by Simulated Public Speaking in Treatment-Naïve Social Phobia Patients](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3079847/) (Bergamaschi et al., 2011) [1:14:15]

**CBD and anxiety**: [Inverted U-shaped dose-response curve of the anxiolytic effect of cannabidiol during public speaking in real life](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5425583/) (Zuardi et al., 2017) [1:14:15]

**CBD and anxiety**: [Cannabidiol in Anxiety and Sleep: A Large Case Series](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6326553/) (Shannon et al., 2019) [1:14:15]

**One single night of sleep loss can induce clinical anxiety in healthy person**: [Under slept and Overanxious: The neural correlates of sleep-loss induced anxiety in the human brain](https://abstractsonline.com/pp8/#!/4649/presentation/38909) (Simon et al., 2018) [1:20:45]

**Literature indicating deep sleep brain waves diminishes over time and how electrical stimulation may boost the amplitude and the size of deep sleep brain waves to enhance memory:** [1:24:30]

- [Sleep and Human Aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5810920/) (Mander et al., 2018)
- [Prefrontal atrophy, disrupted NREM slow waves and impaired hippocampal-dependent memory in aging.](https://www.ncbi.nlm.nih.gov/pubmed/23354332/) (Mander et al., 2013)
- [Sleep: A novel mechanistic pathway, biomarker, and treatment target in the pathology of Alzheimer’s disease?](https://www.ncbi.nlm.nih.gov/pubmed/27325209) (Mander et al., 2016)

**Brain stimulation treatment that uses direct electrical currents to the brain can double memory in young healthy adults**: [Boosting slow oscillations during sleep potentiates memory](https://www.nature.com/articles/nature05278) (Marshall et al., 2006) [1:25:45]

**Most world records are broken at the Olympics during the peak of most circadian rhythm**: [What Science Says About the Best Time of Day to Break an Olympic Record](https://abcnews.go.com/Health/science-best-time-day-break-olympic-record/story?id=41266207) | GILLIAN MOHNEY [1:52:00]

§

## People Mentioned

- [Eve Van Cauter](https://biomedsciences.uchicago.edu/page/eve-van-cauter-phd) (sleep and metabolism and appetite) [6:15]
- [Jocko Willink](https://twitter.com/jockowillink?lang=de) (wakes up at 4am daily) [39:30]
- [Michael Lewis](https://en.wikipedia.org/wiki/Michael_Lewis) (famous author told Matthew about the lack of sleep on Wall Street) [43:30]
- [Christopher Barnes](https://foster.uw.edu/faculty-research/directory/christopher-barnes/) (sleep studies) [44:15]
- [Rick Johnson](https://www.ucdenver.edu/academics/colleges/medicalschool/departments/medicine/renal/Pages/RichardJohnson.aspx) (genetic changes in fructose metabolism) [53:00]
- [Gary Taubes](https://twitter.com/garytaubes?lang=en) (trying to fund good science with NUSI) [1:26:45]
- [Bruce McLaren](https://en.wikipedia.org/wiki/Bruce_McLaren) (F1) [1:37:30]
- [Jim Clark](https://en.wikipedia.org/wiki/Jim_Clark) (F1) [1:37:30]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) (F1) [1:37:45]
- [Ron Dennis](https://en.wikipedia.org/wiki/Ron_Dennis) (mastermind behind McLaren) [1:38:15]
- [Alain Prost](https://en.wikipedia.org/wiki/Alain_Prost) (F1) [1:41:40]
- [Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill) (F1) [1:41:30]
- [Nigel Mansell](https://en.wikipedia.org/wiki/Nigel_Mansell) (F1) [1:41:45]
- [James Hunt](https://en.wikipedia.org/wiki/James_Hunt) (F1) [1:42:00]
- [Murray Walker](https://en.wikipedia.org/wiki/Murray_Walker) (F1) [1:42:30]
- [Lewis Hamilton](https://en.wikipedia.org/wiki/Lewis_Hamilton) (F1) [1:44:30]
- [Sebastian Vettel](https://en.wikipedia.org/wiki/Sebastian_Vettel) (F1) [1:44:30]
- [Lionel Messi](https://en.wikipedia.org/wiki/Lionel_Messi) (soccer) [1:50:30]
- [Roger Federer](https://en.wikipedia.org/wiki/Roger_Federer) (tennis) [1:50:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/04/matthew-walker-image3-box-500x500.png)

##### Matthew Walker Ph.D.

Dr. Walker earned his degree in neuroscience from Nottingham University, UK, and his PhD in neurophysiology from the Medical Research Council, London, UK. He subsequently became a Professor of Psychiatry at Harvard Medical School, USA. Currently, he is Professor of Neuroscience and Psychology at the University of California, Berkeley, USA. He is also the founder and director of the Center for Human Sleep Science.

Dr. Walker’s research examines the impact of sleep on human health and disease. He has received numerous funding awards from the National Science Foundation and the National Institutes of Health, and is a Kavli Fellow of the National Academy of Sciences.

Dr. Walker is the author of the International Bestseller, Why We Sleep. It has a singular goal: to reunite humanity with sleep.

In addition, Dr. Walker is an internationally recognized [speaker](https://www.sleepdiplomat.com/speaker), a successful [entrepreneur](https://www.sleepdiplomat.com/entrepreneur), and a Sleep Scientist for Google.

[sleepdiplomat.com]

**Twitter**: [@sleepdiplomat](https://twitter.com/sleepdiplomat?lang=en)

**Center for Human Sleep Science**: [https://www.humansleepscience.com/](https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s)

**Matthew’s publications**: <https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s>