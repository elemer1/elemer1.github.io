# #156 – Jake Muise: Humanely harvesting axis deer while alleviating its impact on Hawaii’s vulnerable ecosystems

**Source:** [https://peterattiamd.com/jakemuise/](https://peterattiamd.com/jakemuise/)

---

Jake Muise is an avid hunter, environmentalist, and advocate for the preservation of Hawaii’s natural resources. He is the founder of Maui Nui Venison, a company which actively manages Hawaii’s imbalanced population of axis deer by harvesting them as a food resource. In this episode, Jake tells his unbelievable backstory growing up in Northern Alberta before landing in Hawaii on a volleyball scholarship where he fell in love with the islands and the people. Jake explains how axis deer—a non-native species—were brought to the islands and how they have since become imbalanced to the detriment of Hawaii’s precious ecosystems. He goes on to explain the incredible lengths that his company has taken to ensure the most humane harvesting techniques imaginable resulting in a food source that is as clean and healthful as can be. Additionally, Jake and Peter examine what makes meat from axis deer one of the most nutrient-dense red meats on the planet.

\*[WATCH PODCAST ON YOUTUBE](https://www.youtube.com/watch?v=Fy1dMjULbXo)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jakemuise/the_Drive_public.png)

Play

#156 - Jake Muise: Humanely harvesting axis deer while alleviating its impact on Hawaii's vulnerable ecosystems

#156 - Jake Muise: Humanely harvesting axis deer while alleviating its impact on Hawaii's vulnerable ecosystems

1x15s30s

0:002:19:52

## We discuss:

- Upbringing in Northern Alberta, a diet of moose meat, and learning to surf in Nova Scotia (3:35);
- How volleyball brought Jake to Hawaii where he met the Molokai people (14:00);
- Jake’s introduction to axis deer (26:30);
- Pro volleyball in Europe, missing the Olympic team by one spot, and his return to Hawaii (29:00);
- History of axis deer in Hawaii—how a non-native species came to the islands, and the superpowers that make them so hard to hunt (34:00);
- A potential catastrophe avoided on The Big Island—The amazing story of how Jake tracked and found axis deer that were secretly brought to The Big Island (52:15);
- Jake’s work helping ranchers on Maui (1:08:15);
- The detrimental impact of an imbalanced axis deer population (1:10:30);
- The incredible evacuation of farm animals from lava-locked land due to a volcano eruption (1:17:00);
- The creation of Maui Nui Venison—going above and beyond USDA requirements (1:27:00);
- The most humane way to harvest an animal—the unmatched standards Maui Nui Venison uses to harvest axis deer (1:32:00);
- Why meat from axis deer is nutritionally superior (and tastes better) than other meats (1:46:00);
- Why axis deer meat is the best option for those reluctant to eat meat: True nose-to-tail nutrition and ethical harvesting (1:58:15);
- What a truly balanced population of axis deer on Hawaii would look like (2:06:15);
- Maui Nui Venison’s charitable work during the COVID crisis (2:12:45); and
- More.

§

## Show Notes

## Upbringing in Northern Alberta, a diet of moose meat, and learning to surf in Nova Scotia [3:35]

**Upbringing**

- Jake grew up in a small town called [Rainbow Lake](https://en.wikipedia.org/wiki/Rainbow_Lake,_Alberta) in northwest Alberta, Canada—technically in the Arctic Circle
- Ice fishing was a big activity — once his dad drilled down 6 feet into the ice without hitting the water
- “Lots of resilience comes from living in a place like that” says Jake
- Dad was in the oil industry so they moved around a lot, but it was mostly in Northern Alberta
- Part of that isolation meant his dad was a subsistence hunter
- They would shoot a moose and that’s what they ate all winter long long
- In the winter, they would move down to a place closer to Calgary, and in preparation for the move his mom had to essentially pack for 9 months—collecting groceries all summer long
- Other things they ate as kids — Pheasant [pablum](https://en.wikipedia.org/wiki/Pablum)

Chores as a kid

- Cleaning the bathrooms when it was too cold to go outside
- Another regular chore was shoveling the roof to reduce the weight of the snow collapsing the roof
- Several winters, the snowbank connected to the roof and as kids they were able to snowboard off the roof into the snowbank
- It was so cold you would stop moving and you’d have to worry about hypothermia—as kids they would have to go in the house and get warmed and then go back outside

**More about what they ate**

- For 8 to 10 months, there’s not a single leafy green available
- The vast majority of their diet was meat
- They called moose “swamp donkeys” because moose meat had a distinct taste as moose would spend their time in swamps eating lily pads or whatever was floating around
- In the summer, everything would melt and the whole area was a muddy mess

**Moving to Nova Scotia**

- When he turned 16 his family moved to [Nova Scotia](https://en.wikipedia.org/wiki/Nova_Scotia)
- Going from northwest Alberta to Nova Scotia, you might as well be moving to the Artic to the Caribbean, but it’s still freezing cold water with slush that forms in the seawater during the winter

*Picking up surfing*

- He picked up surfing in Nova Scotia (despite the freezing water)
- The biggest waves were these wind waves
- The first thing they did when they arrived in Nova Scotia was go to the beach which is where they saw people surfing and he and his brother said, “*We need to do that*.”
- It started a long and semi-dangerous career in surfing in Nova Scotia given the freezing cold water and the huge swells during the winter months
- They couldn’t afford good wetsuits so they used to tuques
- Without wetsuits, they would surf as late into the season as possible (September/October) until it was literally too cold to enter the water
- Being on a budget, the first surf board they made was using styrofoam and duct-tape
- To up their budget, he and his brother started a grass cutting company and they were able to buy a real wetsuit and surf board
- “*I just fell in love with the ocean*.” says Jake

## How volleyball brought Jake to Hawaii where he met the Molokai people [14:00]

**Beginning of his volleyball career**

- The last year in Northern Alberta, Jake and his older brother Josh started playing volleyball and they picked it up pretty fast
- When they moved to Nova Scotia when Jake was 16, they used volleyball to integrate into the new community and volleyball just stuck
- He competed at a really high level—including Canada’s Youth Olympic Program and then Junior Olympic Programs
- When he was at a Junior Olympic Program, the University of Hawaii saw him play
- It turns out that when deliberating on whether to recruit Jake to U of Hawaii, [Tino Reyes](https://hiloathletics.com/sports/womens-volleyball/roster/coaches/tino-reyes/63) (the assistant coach) saw pictures of Jake surfing with icebergs in the background
- He was about 6 feet tall (short for volleyball) but they said, “If this kid can do this, whatever we’re going to get… The level of resiliency we’re going to get out of him, it’s going to be worth it. Even if we’re losing a couple of inches.”

> “Volleyball’s taken me all over the world. It’s been amazing.” —Jake Muise

**Arriving in Hawaii**

*Minor culture shock*

- The initial shocks were tiny
- Funny example:
  - On his recruiting trip they first showed him the university and the volleyball facilities and next they took him to the beach and gave him a pair of boardshorts
  - Having never seen board shorts before, he put “tighty whities” on underneath them since there was no liner
  - So I put the tighty whities on underneath the boardshorts, tie them up, head out to He headed out to Kaiser Bowls ane when paddling out his tighty whities were hanging out the back

**Meeting the Molokai people—An awesome accident**

- When he got to the University of Hawaii for the fall, they messed up him dorm assignment, “*which turned out to be the best, probably the best thing in my life*”
- They put him in the dorm for all of the local kids that didn’t have good enough grades so they were taking this summer program to get into school
- He happened to get placed in the wing with all the kids from [Molokai](https://en.wikipedia.org/wiki/Molokai)
- Jake was astounded how big these people were
- Jake was pretty obviously out of place but in true Molokai fashion, they quickly accepted him into their “family”

> “It was the best thing that ever happened in my life. They took me under their wing, and all of the best parts of my life have come from walking into the wrong dorm.” —Jake Muise

**More about Molokai—geography and culture**

- The island is only 10 miles by 30 miles, roughly 180,000 acres
- There are only 7,000 people, most of which are true locals
- What makes it so special is they have fought for years and years and years to keep Molokai the exact same way it has always been—no stoplights, no major resorts, etc.
- The people are very active in maintaining the community—no poverty, no homelessness, etc.
- Food they eat
- About half the food they eat comes from the ocean or the land
- They do a lot of subsistence hunting—deer, black buck, goats, and pigs
- They have the longest standing reef in Hawaii, on the south shore of Molokai which is still teeming with fish
- “*They fought to protect all of these natural resources. They fought to protect their way of life, because Molokai’s beaches are extraordinary*.” says Jake
- There was actually a failed attempt to put up a fancy resort on the north shore at La’au Point

**Getting “adopted” by a local family**

- Getting back to Northern Alberta was too far away so he spent every long weekend, Christmas break, holidays in Hawaii
- In Hawaii, the term for adoption is [hānai](https://en.wikipedia.org/wiki/H%C4%81nai#:~:text=H%C4%81nai%20is%20a%20term%20used,h%C4%81nai%22%20someone%20into%20the%20family.) — Jake got hānai-ed by a Molokai family along with a friend of his named Mike

> “I’ve been a part of that family as long as I’ve a part of my family in Canada. . .just so lucky and so fortunate to get to be a part of that place, and part of my adult life. I grew up as a function of that place, and the cultural values it has.” —Jake Muise

**Volleyball career at Hawaii [25:30]**

- Jake had a very successful career at the University of Hawaii
- They won the title in one of his 4 years but some rules get changed after the title is won—for political reasons—they take the title away. “It was a mess.”
- They were top three in the country every single year

![](https://peterattiamd.com/wp-content/uploads/2021/04/volleyball-1-muise.jpg)

**Figure 1. Jake playing volleyball.**

## Jake’s introduction to axis deer [26:30]

- While in college, being able to go to Molokai and learning more about that culture, learning more about axis deer, it was an amazing experience
- As an athlete, he started to realize something, “*I feel so much better when I have deer meat in my freezer*.”
- Being broke college, he says he would have “starved” without axis deer
- He would go hunting for axis deer, filling up coolers that were way overweight and then bargaining with people on our floor for freezer space
- In college, he was building strength and lifting weights and he remembers thinking, “*Man, I feel so much better when I have axis deer here*.”

![](https://peterattiamd.com/wp-content/uploads/2021/04/axis-deer-1024x591.png)

**Figure 2. Axis deer in Maui.** [[source](https://www.mauinews.com/)]

**Basic understanding of axis deer**

- Peter asks: How much did you understand the history of how they got there? And what the true significance ecologically was? Did you know any of that at the time?
- “I honestly didn’t. It was entirely recreational.”
- It was only later when I saw the detrimental impact of axis deer on the native lands of Hawaii
- But the axis deer is revered by the people on the island of Molokai—Nobody in Molokai calling it an invasive species
- It’s been part of that culture for a hundred plus years and they find extreme value in it
- They do understand the detriment that it’s there, and they hope for management options in the future
- But when the family introduced Jake to axis deer, they didn’t introduce it as the idea of it’s an invasive pest
- It was introduced as, “This is an amazing resource that we get to utilize and something we really enjoy recreationally.”
- *“It wasn’t until I experienced or saw some of those things that started to kind of put it together.*” says Jake

## Pro volleyball in Europe, missing the Olympic team by one spot, and his return to Hawaii [29:00]

**After college**:

- Jake was playing professional volleyball in Europe
- He tried out for the Canadian Olympic team and was the last guy to get cut
- “*I was devastated…thought I had like an incredible tryout*.”

*Now what?*

- Jake had zero plans for not making the olympic team
- First thought was to return to Moloka’i

**Deciding what to do after volleyball**

- In college, Jake has written a business plan to mimic the model of New Zealand to domesticate axis deer
- And near the end of college, he has started to formulate these ideas of what could he do that was a better option for Hawaii
- In his two years in Europe, he started a nonprofit called the Axis Deer Institute
- The reasons or starting the nonprofit was because nobody would give him access to studies out of India when he was attempting to collect population and biological information on axis deer
- After starting the nonprofit called the Axis Deer Institute the studies started to flood in because it gave him credibility  (i.e., “*Hey, this is Jake Muise, I’m executive director of the Axis Deer Institute*.”)
- After volleyball the plan became: ***What can we do to better manage axis deer?***
- He flew back to Moloka‘i, and four days later he met his
- He spent the summer there, then played another year of volleyball in Europe, before retiring and returning to Hawaii to start a life with his wife

## History of axis deer in Hawaii—how a non-native species came to the islands, and the superpowers that make them so hard to hunt [34:00]

**Explaining what these axis deer are, how they got to Hawai’i, how many of them there are, etc.**

- Peter says, “*my attraction to axis deer can only be described as a love at first sight…breathtaking*”
- But this is not a species of deer that is native to Hawaii.

*So how did they get there? And where did they come from?*

- In 1868, [King Kamehameha V](https://en.wikipedia.org/wiki/Kamehameha_V) hired the Matheson Trading Company to get axis deer out of India to bring to Hawaii [[Hawaiian Gazette, 1867](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACc81uljEpjd5GG_sCRPoTna/pre-1900s?dl=0&preview=1867-Hawaiian+Gazette.pdf&subfolder_nav_tracking=1)]
- Jake notes that only 5% of Hawaii’s newspapers are translated so 95% of their history is buried in there
- His wife helps to translate newspapers for Jake such as articles that explain how they came down the Yangtze River on a boat called the Lochnagar before arriving on Moloka’i with two bucks and five does (a baby buck was born and they named it King Kamehameha the Fifth) [[Honolulu Star Bulletin, 1972](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1972-2-Honolulu-Star-Bulletin.pdf&subfolder_nav_tracking=1); [Honolulu Advertiser, 1961](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1961-Honolulu-Advertiser.pdf&subfolder_nav_tracking=1); [Honolulu Star Bulletin, 1936](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AAD5Dok6u-L-TNlDT7Jkh9_aa/early%201900s?dl=0&preview=1936-Honolulu-Star-Bulletin.pdf&subfolder_nav_tracking=1)]
- These axis deer are originally only put on the Island of Molokai
- And they put a “kapu”—a restriction—on harvesting axis deer for the local people there
  - They were, at that point, “the King’s deer”, but it’s still unclear as to why the king sought this particular animal
- Once on the small island of Molokai, they start to proliferate very quickly
- They found articles estimating there were 7,000 deer and they were already decimating what they were describing in the “upland forest” [[Honolulu Star Bulletin, 1950](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1950-1-Honolulu-Star-Bulletin.pdf&subfolder_nav_tracking=1)]
- There’s an article about them hiring “sharp shooters” from California, and the sharp shooters from California recorded killing 5,000 deer [[Honolulu Star Bulletin, 1950](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1950-1-Honolulu-Star-Bulletin.pdf&subfolder_nav_tracking=1); [Hawaii Tribune Herald, 1964](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1964-Hawaii-Tribune-Herald.pdf&subfolder_nav_tracking=1)]
- Not too long after there starts to be arguments over how to manage the axis deer [[Evening Bulletin, 1909](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AAD5Dok6u-L-TNlDT7Jkh9_aa/early%201900s?dl=0&preview=1909-Evening-Bulletin.pdf&subfolder_nav_tracking=1)]
  - Two Hawaiian reps were saying, “*we have to do something about this. . .they’re going to continue to destroy our upland forests.*”
  - In other words, as far back as a hundred years ago, people were already recognizing the negative impacts axis deer were having on the communities

![](https://peterattiamd.com/wp-content/uploads/2021/04/depiction-of-axis-deer-1837-946x1024.png)

**Figure 3. An 1837 depiction of axis deer from a Hawaiian newspaper.** [[source](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACc81uljEpjd5GG_sCRPoTna/pre-1900s?dl=0&preview=1837-Ke-Kumu-Hawaii.pdf&subfolder_nav_tracking=1)]

**Replication cycle of axis deer**

- Gestational period is 238 days
- They average three fawns every two years
- Most male, *non-axis* deer lose their ability to mate when they cast their antlers every year – their testosterone levels drop so low that their sperm becomes non-viable (typically during winter time)
- An axis deer, however, is a tropical animal and even when they cast their antlers, **their testosterone stays high enough to allow them to breed year round**
- Axis deer’s population dynamics look like those “hockey stick curves” once they get started and they’re extraordinarily healthy
- Data on harvested axis deer show that 89% of female deer are lactating or pregnant at the time of harvest

> “You put [axis deer] in Hawai’i where there’s obviously no predators, perfect feed, they can jump six to eight foot fences and move wherever they need to to maintain their own health, and you’ve got a pretty astounding, invasive species, but also a resource.” —Jake Muise

**Axis deer superpowers:** ***Why are axis deer so hard to hunt?***

- Oftentimes, people will ask, *How hard can it be to shoot a deer with a bow and an arrow?*
- But every animal does have a superpower, says Peter
- For example, with pigs, their super power is smell. They can smell you at a very great distance. And so if you are not downwind of them, they will sniff you out.
- For axis deer, they have at least 3 “superpowers”
  - Their sense of smell, their vision, and their hearing.
  - “*This animal is so superior to us on at least those three senses, that it’s about as hard as any animal to get within a hundred yards of*.”
- And to get a shot with a bow, you have to get much much closer than 100 yards
- Just think, this is an animal that spent a billion years evolving to escape tigers and jaguars (some of the most efficient predators on the planet)
- Furthermore, axis deer had to evolve all of these evasive skills in **thick jungle**
- **A potential fourth superpower**: To evade tigers in dense brush and foliage and like, they would have had to have such incredible observational skills
  - In India, for example, axis deer team up with monkeys and birds to use them like alarms
  - “They are relying on third party information…not just their own. They’re so tuned in to their environment.”
- Furthermore, when axis deer find places that are safe, they stay there

> “If you can successfully harvest an axis deer with a bow, you can do almost any other animal on the planet.” —Jake Muise

**How axis deer got to Lanai and Maui**

*How and when did that happen relative to the 1860s with the initial introduction to Molokai?*

- [**Lanai**](https://en.wikipedia.org/wiki/Lanai)**:** In the 1920s, the then owner of the Island of Lanai chose to introduce axis deer from Molokai to Lanai
  - Lanai is half the size of Molokai so the deer very quickly became fully established at “carrying capacity” — meaning the overall population of deer is only going up and down each year with available feed and or how many fawns are surviving
  - A survey five years ago showed there was 21,000 axis deer on this very, very small island
- [**Maui**](https://en.wikipedia.org/wiki/Maui): In the next phase, axis deer are introduced to Maui in the 1960s, but not without controversy
  - You would think by now there’s common knowledge that there are issues with this animal
  - For example, there was this huge outcry on the Big Island that said “No way. We’re not bringing this animal to the Big Island, it’ll be detrimental.”
  - Long story short, the Big Island says no, but they got approved to be introduced to the island of Maui which ia about 460,000 acres
  - The axis deer population on Maui is still what we consider an “emerging population”—so they’re continuing to grow, but they haven’t reached carrying capacity
  - This year, it’s estimated that the population of deer on Maui to be about 60,000
  - But the population will max out at 210,000 deer (unless we’re able to get ahead of that)
  - **On Molokai**, by comparison, it’s about 70,000 deer (and only about 7,000 people)

*How does that compare to the density of populations in other parts of the US?*

- By comparison, Texas Hill Country had the densest deer acreage or densest number of deer per acre at about [6 per 100 acres](https://tpwd.texas.gov/publications/pwdpubs/media/pwd_rp_w7000_0828.pdf)
- Hawaii, in established areas, has 25 deer per hundred acres—at least 3X whatever the densest deer populations on the continent are

## A potential catastrophe avoided on The Big Island—The amazing story of how Jake tracked and found axis deer that were secretly brought to The Big Island [52:15]

**How they got to** [**The Big Island**](https://en.wikipedia.org/wiki/Hawaii_(island))

- In 2010/2011, axis deer were brought to The Big Island by private individuals (not the state)
- They trapped a few deer on Maui, flew them to The Big Island via helicopter, and drop them off secretly
- Nobody finds out about it until about a year and a half when a rancher saw them on his camera trap
- The ranchers immediately called Jake and Mike because everybody said, “*if you got any chance of  finding these things, here are the two guys to ask*”
- The area which was thought to be where they were located was the size of Moloka’i—70 square miles
- “*I just remember thinking, ‘How the hell are we going to find these animals?*’” says Jake

**Partnering with Mike**

- Jake partnered with Mike to try to find the deer
- Mike grew up on Molokai and has been hunting and eating this animal every day
- *“This is the closest human to an axis deer*” says Peter (tongue in cheek) “*He just knows where they go*”

**Potential catastrophe**

- The state knows at this point that there is at least three axis deer on the Big Island and if they go unchecked, it’s going to be a catastrophe (millions of deer)
- it started a three year project and it took us three years to find those animals

**The journey to find the deer on The Big Island**

*At the beginning*:

- Mentally exhausting, Jake and Mike literally hunted almost every single day for a year and a half without seeing an animal
- Setting the scene: The area to search was just so big — It’s very, very windy so there’s wind blown trees over the vast majority of the area. — “Literally it was like doing yoga all day long. Like you were crawling in and through all of these trees, which deer love. So it was like physically exhausting, but then it was mentally exhausting because you were only covering a certain amount of acres. You’re looking for like a single piece of scat or like deer feces. You’re looking for like a single rub. You’re looking for like anything that would tell you that they’re there.”
- In the end, they figured out that the deer has found a safe space of less than 100 acres

*Game changing tools*

- Eventually, they got a chance to start using military grade [FLIR](https://en.wikipedia.org/wiki/Forward-looking_infrared#:~:text=Forward%2Dlooking%20infrared%20(FLIR),camera%20that%20senses%20infrared%20radiation.) equipment
- The equipment picks up infrared or heat signatures from bodies that get translated into an electrical optical image for you to be able to view with binocular units
- Over a period of a couple of months, they were able to start chunking off huge areas of land in being able to view with great detail these areas from a thermography standpoint

**Finally finding the deer**

- It was in the middle of the night, because you can only really use FLIR effectively in the middle of the night
- Mike take his eyes off the binocular unit and he looked like he’d seen a ghost
- Mike had seen a velvet antler (it has so much blood in it, so it’s hot)
- The deer was about 5 miles away
- Over the next four hours, Jake guided Mike in closer via binocular unit
- While going down there, they saw several other deer
- Mike was eventually able to find and get one buck (male deer) and he just missed the doe that was with it

*How many deer were there at the time?*

- It ended up being five, but at the time there were only four that they knew of

*How long until they got the rest of the deer?*

- It took another **year and a half** to capture them all
- What happened was they “bumped” their home range and so they moved several miles away so they had to restart their search

**What were the expectations from the state of Hawaii?**

Jake says that most didn’t think they would be successful at finding the deer for a couple reasons:

- First, Invasive species are a prolific issue in Hawaii—Everything evolved here over millennia, anything we introduce is such a disaster, it doesn’t matter if it’s a frog or a plant
  - And nearly all of the projects related to stopping invasive species are not successful
- Secondly, it was well known how impossible it seems to be to find axis deer
- Plus, they really had just a minuscule budget (Mike’s shoes have duct tape all over them)

*After finding the first deer*

- Funding boosted pretty quick after we got the first deer
- Honestly, had it not been for just some of the resiliency of Jake and Mike’s partnership, it would not have worked out
- After finding that first deer, and knowing that there were more deer, “*we could have took 10 years we were going to find the rest of those deer*”
- We didn’t understand how much more active they were at night, we didn’t understand all of the behavioral cues of what was happening at night
- The nightly repetition eventually paid off — they were able to spot many more animals (pigs, etc.)
- They were getting significantly more confident in what they were (and weren’t) seeing
- They started narrowing down hundreds of thousands of acres and developing survey procedures (which didn’t exist anywhere else)

> “I remember finding and removing that last deer, and me and Mike looking at each other, and we knew, we were like, ‘Oh shit, we got them all.’” —Jake Muise

**How did you know that was the last one?**

- “We were confident that was the last one in that area”
- “There’s no way I can say there’s no deer on the Big Island, I can confidently say at the time we were done that project.”
- They spent 300+ hours in a helicopter scouring 10,000 acres every hour
- “We believe it was 95% accurate in detection rates…we were marking beehives as our detection protocol.”
- 8 years later, there hasn’t been another siting of deer in the area

> “Talk about life lessons. So the second half of the project, waking up every night at 6 AM, eating dinner with your family, and then rolling out for 12 hours of using that FLIR equipment, not knowing what you’re going to find, for a three-year hunt. Apart from athletics I think any level of resiliency I have probably came from that project.” —Jake Muise

## Jake’s work helping ranchers on Maui [1:08:15]

**The axis deer situation in Maui**

- At this point in time, it’s safe to say there’s no real concerted strategy around what to do in Maui
- And the destruction is much greater
- The people there are much less fond of them — calling them “spotted rats” for instance
- The deer were dropped off in the central area for all ranching — and they now directly compete with cattle for feed, they break fences, etc.

**Why they went to Maui**

- Jake made the move from The Big Island to Maui primarily because of opportunity
- The ranchers on Maui are begging for Maui for help in many cases saying things like, “We’ve got tens of thousands of deer over here, we don’t care what you do with them, just come and shoot them.”
- But Jake can’t just shoot them – there had to be a better way: “*All of the learnings and experience and cultural values that came from Molokai we’re still very much a part of who we were*.”
- On Lanai, they have essentially resorted to just shooting deer out of helicopters

## The detrimental impact of an imbalanced axis deer population [1:10:30]

**Damage to the ecosystem from land to water**

- For one, they are competing for the same resources as the cattle which is a big business in hawaii
- But the bigger impact is the impact on the ecology of the ocean

*Looking at evolution…*

- Hawaii is the most isolated land mass on the planet—everything here has evolved over millennia to be best suited for its environment right here which included **no large mammals**, and certainly **no grazing herbivores**
- Today, Hawaii is the endangered species capital of the world
- 30% of the endangered species list in the US is all plants & birds from Hawaii and **that is a function of the introduction of non-native species and how they affect biodiversity**

**Biggest negative impact of axis deer**

- The impact of axis deer is probably the most influential at the very top of the mountains
- Water is one of the most important things to the community
- The Hawaiians knew this, the word for wealth was “waiwai”, it was water for native Hawaiians
- Watersheds are the most important resource—they’ve developed to capture all fog and rain and they go directly into aquifers
- For deer in Hawaii’s forests, “it might as well be a salad bar” — those plants have developed no protections for themselves
- And once those animals affect the efficiency of our watersheds, they affect how much water they capture at a significant rate
- Axis deer’s most profound effect is in the mountains and **affecting how that ecosystem collects water**

**Impact on ranchers**

- As deer come down the hill, that’s when they start interacting with ranchers and farmers because they directly compete for feed at a rate of about 7 to 1 (every seven deer equates to about one cow)
- A lettuce farmer can lose 10 acres of lettuce overnight when a herd of a thousand deer come in

**Regarding the water and soil and fish**:

- When there are large rain events, all of the soil that has taken tens of thousands of years to form on this tiny Island (especially coming from lava rock), all of this incredibly valuable top soil will run off into our oceans
- Additionally, deer scat (poop) is extremely high in nitrogen — so the downstream effect of not only the soil depositing on our reefs, but also the impact of the nitrogen from thousands of deers feces starts to bleach our reefs as well
- But more than anything, thousands of pounds of sediment come down in these events
- When you fly over the island, you can see crazy plumes miles and miles wide of this red dirt that is just going out and covering the reefs

**Losing reefs and fist**

- Furthermore, Hawaii has lost significant amounts of reef and the fish that then go along with them
- In short, there’s a major downstream effect of having an imbalance population of axis deer and it’s hard to fully equate the cumulative impact

**Impact on food security**

- While axis deer are indeed a good food resource, they’re are significantly impacting the food security
- When they’re imbalanced, their impact is **not a net positive** for our communities when you’re at such imbalance in these populations
- “*They’re impacting our food security here as the most isolated land mass on the planet*.” says Jake

## The incredible evacuation of farm animals from lava-locked land due to a volcano eruption [1:17:00]

**Volcano eruption**

- In 2018, there was a [large volcano eruption](https://en.wikipedia.org/wiki/K%C4%ABlauea#2018_eruptive_episodes) on [Kīlauea](https://en.wikipedia.org/wiki/K%C4%ABlauea) on The Big Island
- The lava flow was ~500 yards wide moving at 50 miles an hour
- It ended up completely destroying an entire community
- In the process, two lava flows formed and they cut off a huge portion of a ranching area, including homes and a bunch of things

![](https://peterattiamd.com/wp-content/uploads/2021/04/lava-1-muise-1024x683.jpg)

**Figure 4. Lava-locked land.**

- The ranchers were already losing much of their land and homes to the lava flows, and now much of their livestock were trapped
- Jake and his team developed a net to capture and lift out live cattle via helicopter
  - It was a large metal circular frame with a triangle net
  - Attached to the tip of the net to the top of the comb, it was attached to the frame of the circular structure
  - Via helicopter, they would put the cone over the animal, release top of the net, and the net would fall down
  - The animal would walk out to the end of the net, and then they would pick up the frame and it would be sitting in this perfect cradle
  - “*A little hammock ride.*”

![](https://peterattiamd.com/wp-content/uploads/2021/04/cow-in-hammock-muise-1024x629.png)

**Figure 5. A cow taking a hammock ride.**

**Day of the rescue**

- Having nearly zero context, Jake and his team were like “We can go and do that.”
- Driving out early in the morning, “*it looked like Armageddon*”
- The entire sky in the middle of the night was red and roiling,
- The heat was creating its own weather system, including lightening

> “It was such an odd experience to be driving towards it with the idea that we were going to fly around and pick these animals up, flying over these 50 mile an hour lava flows.” —Jake Muise

- Once onsite, they used the FLIR equipment to figure out how many animals were there and where they were
- They rushed back to hook up the net

**The first rescue**

- They hover the helicopter over the first cow
- It’s a 100 foot line
- The cone is hanging under the cow, and you’re eye level with lava flows
- You’re seeing chunks of magma going everywhere and you’re seeing the ground heat up on two sides
- The cows had moved themselves into the internal area between the two flows
- Flying over the first lava flow, there was so much heat coming off of flow, it was tossing the helicopter 300-400 feet in the air almost instantly
- Once in the inside of the 2 lava flows, they find the first cow which happens to be a 2,000 lb bull (max capacity for the helicopter)
- Next, they have to fly the cow out over the lava flow to safety, but the cow is so heavy it was going to be difficult
- The pilot decided to use the heat from the lava to help lift the helicopter up high enough as to now “barbeque the cow”
- This cow is flying under the helicopter at a hundred feet, and they were flying at 250 feet above the ground
- Sure enough, the heat lifts the helicopter right up just as the pilot predicted
- Looking down at the cow, it appears there is smoke coming off the cow — Jake thought, “What did we just do? We just burnt this cow.”
- Turns out that it was raining and the cow had water all over it so as they got over the flow, it was just steam coming off the cow, and the cow was perfectly fine sitting in it’s hammock
- Once out of the lava flow, they set the frame down and the cow walks right out and starts eating some feed

\*Clip from the cow rescue:

**Reaction of the community**

- Over the course of a couple weeks, they pulled out 40-50 cows
- “*To the rancher that was potentially going to lose it all, and to communities that were seeing all of this loss, it became this really interesting rallying point for the local community*.”

> “We just had a knack of figuring it out as we go. . .with very limited math experience between the three of us, and we’re looking at this huge cargo net and these pipes, and I think we argued for like three hours before we built this thing.” —Jake Muise

## The creation of Maui Nui Venison—going above and beyond USDA requirements [1:27:00]

**Maui Nui Venison**

- Jake started a company called [Maui Nui Venison](https://mauinuivenison.com/) which is effectively an unbelievably efficient, humane way to operationalize the harvesting of access for food at a USDA certification
- Important for people to understand: An individual can go out and hunt Axis deer, but that meat can’t be sold to anyone (at a store or restaurant, for example) for food safety issues

**How the idea came**

- After finishing the project on The Big Island, they were getting those inquiries from Maui and the light bulb went off
- Jake understood what they were dealing with from an animal standpoint (population needed management, etc.)
- The question was, “***Why can’t we eat these things?***”
- As a non-native invasive species in Hawaii, the ownership of the axis deer on private land falls to the owner (where he can decided how to manage it)
- The state isn’t responsible to manage that animal on private property
- When he started working with ranchers in Maui, Jake decided to call the USDA

*Learning about USDA requirements*

- He told them he was managing axis deer on private land and wanted to know “What rules would we have to follow in order to have this animal be USDA inspected?”
- The USDA representative basically laughed at the question and said, “Here’s the Meat Inspection Act from 1930. It’s the Federal Meat Inspection Act. If you can follow these rules, somehow, we’ll give you guys a shot.”
- Jake scoured the documents, and realized that it was potentially doable to humanely harvest and animal by the USDA standards
- Given the amazing equipment that allows them to see the animals, he knew they could render these animals humanely
- One of the most important rules of a brick and mortar facility, **is how that animal dies**
- The terminology is: *rendered immediately unconscious* — shot in the skull cap so it dies immediately
- So if they could do that do these axis deer, they would be shut down immediately
- The other part of that document was that they needed a USDA certified slaughter facility — which wasn’t really possible to use the current facilities on Maui

*So there were two major hiccups to start*:

- 1-Can we do this efficiently enough?
- 2-Will my wife let me remortgage my house to buy a slaughter facility, a mobile slaughter facility?
- At the beginning, both those answers were “no”

**Getting started in Maui**

- They moved forward with managing axis deer in Maui to help the ranchers and they turned the deer meat into pet food
- That processed allowed them to test the theory that they could do this we were able to test a lot of these theories

**Reaching back out to the USDA**

- After 6-8months of keeping data every single night on proficiency rates and miles and occurrences
- Once he could finally justify the requirements for the USDA, he called them back
- The USDA reps came out and they were blown away by Jake’s process

## The most humane way to harvest an animal—the unmatched standards Maui Nui Venison uses to harvest axis deer  [1:32:00]

\*WARNING: Graphic

**Peter on Jakes process of harvesting axis deer**: “*When you contrast how that piece of steak showed up [at the grocery store] with the work that you guys are doing in the field, you get a real sense of the difference and why a USDA inspector can show up and say, ‘I’ve never seen anything like this ever in the history of the USDA*.’”

**How animals are harvested in a typical brick and mortar facility:**

- Typically, the live health inspection is done in a corral (in the case of a farmed cow)
- A whole bunch of cows that get trailered
- They’re sitting in a corral system
- The inspector is able to look at these animals, very closely view them and determine that they’re safe for human consumption
- Then that animal goes into a shoot system, goes into a press, or sometimes it’s hung up alive
- Then that animal is rendered immediately unconscious with a stunner or a bolt gun shot to the head
- In most cases, that animal is very stressed

**How Jake’s harvesting process is different**

*100% natural environment*

- They don’t pen the deer
- They don’t bait the deer
- Translation, the animals they harvest are 100% in their natural environment
- Not even in a high fenced area, let alone a pen
- They’re literally just out in the evening roaming about

*Not stressed*

- If the deer hear or see Jake and his team and get spooked, those animals are now in a stressed state and they are not able to harvest them
- However, if they come upon a group of deer and they don’t move away, that’s the indicator that they are able to start the ante-mortem process (observing them to make sure they look healthy)
- They use the same FLIR binocular unit that can pick up a deer at six miles to inspect the living deer with extraordinary detail
- You can see abscesses, old scarring, if they’re pregnant, etc.
- The level of detail is actually better than an inspector looking at an animal in a corral to determine whether or not it’s healthy
- The inspector will give the go ahead to shoot them once he does his inspection

*Taking the perfect shot*

- The deer must be rendered immediately unconscious
- That means you must shoot it in the head
- If done properly, that animal is in a zero stress situation and dies immediately

*Comparing that to bow hunting…*

- In archery, a perfect shot is lung, heart, lung
- But that animal doesn’t die immediately, it takes probably 10 seconds even with perfection
- That an animal will die from hemorrhagic shock (i.e., blood loss)
- When you’re putting a high power ballistic (a bullet) into the head, that’s a central nervous system death, meaning the animal die due to brain swells (an immediate and instantaneous death)

**The most human harvest imaginable**

- By definition, there is simply no more humane way to die than a bullet to the head
- The animal has absolutely no knowledge that that is happening and the moment it happens, they cease to have awareness of anything
- Not only are they not aware, but most of the time the animals that are with them in a herd don’t even scatter  — The animal that was shot in the head literally drops straight down and the deer around it don’t suspect anything
- In most instances, in a herd of 10, they’ll typically harvest three or four of them

**Accuracy/efficiency of proper harvesting**

- The FLIR equipment is so good that the friction from the bullet passing through the air creates a tracer.
- So the inspector is actually able to see the bullet path and it hitting the head
- One thing to be clear: Jake’s hunters are not perfect
- However, they have trained to imperfect in a way to not injure any animals
- Typically, where the perfect target would be central to that brain cap system, Jake trains his team to miss 30% of the time
- So a perfect evening of shooting is at 70% efficiency
- The miss is **always high** – so there’s never any consequence of missing (the bullet goes over the animal)
- There’s so much pressure that surrounds shooting each evening so they‘ve had to train themselves to understand that imperfection was actually the best way to go about harvesting this animal
- In that case, that imperfection is what allows them to meet the proficiency level of a brick and mortar for the rendering process
- There has only been one bullet that hit the animal somewhere other than the skull
  - It was a shot to the neck, which still resulted in an immediate death.
  - So for all intents and purposes, it was the exact same, but it was off the target

**\*Effect of sleep on shooting accuracy\***

- On Mondays, the hunters are making the conversion from being awake to working nights — and in that situation Jake’s expectations are for the guys to shoot at 50% accuracy
- What that does is it increases their margin of error for something bad not to happen because we now know through poor sleep, it absolutely affects our nervous system and our reaction time
- Jake learned a ton from [Peter’s podcasts with Matthew Walker](https://peterattiamd.com/category/sleep/)

**Jake’s team compared to brick and mortar facilities**

- A brick and mortar facility is asked to operate at a 95% efficiency
- Jake’s team is operating at 99%
- Furthermore, an animal that comes into a pen is stressed out and is moving around so even at point blank range it is challenging
- For a trained hunter, it’s actually easier to be efficient when the deer is at rest and just unaware of what’s happening
- That said, the axis deer hunter must have an intimate understanding of their behavior
- For example, a right ear starts to dip and you know the head is going to go.
- A nose starts to go up and you know it’s going to start nosing
- There are half millisecond instances that you have to understand

> “This isn’t something where I could bring in a military sniper and you can operate at this efficiency. I need a military sniper plus an [axis deer] expert in order to take those shots. . .It requires a very specific skill set.” —Jake Muise

**What’s the typical range?**

- The typical range of the shot is at 100-200 yards using a [.308](https://en.wikipedia.org/wiki/.308_Winchester)
- But that range is restricted NOT because the hunters are not effective past that range
- It’s actually because they are only given a three-hour window to harvest at night
- The hunters carry almost every single one of these deer on their backs
- It’s an awesome way for the guys to connect with each animal as we’re doing the process
- But it’s also very technical in that, we don’t want any bruising or anything to affect carcass quality after all of that work
- So you’re carrying a 200 pound animal on your back over extremely varying terrain
- They have developed the perfect way to pick up a deer which took hundreds, if not thousands, of animals to figure that out
- So at 200 yards with a 200 pound animal, you’re getting back to the bike or truck exhausted
- What they have learned is that they can actually harvest more deer in a given night if they skip the animals past 200 yards

## Why meat from axis deer is nutritionally superior (and tastes better) than other meats [1:46:00]

**Peter’s take on axis deer meat**

- Something that’s very different about Axis deer
- It seems infinitely cleaner, healthier. The animal itself seems to be very clean. There seems to be something about its meat that’s unique
- As I’ve gotten to learn over time, a big part of that has to do with the intramuscular fat content
- Most people who have tried venison say, “Oh, it’s okay, but it’s a little bit gamey.”
- But Axis deer sort of exists in its own camp, which is not particularly gamey at all
- It’s basically 0.4% intramuscular fat — it’s a very unique animal in that regard

**What contributes to the meat quality**

*Humane way they are killed*

- The humane way they are killed instantly contributes to why they don’t have these high levels of cortisol and lactate at harvest which definitely contributes to some of the taste that you can have in wild animal typically
- But there’s also something that plays a much longer term role in the development of the muscle
- That conversion of glycogen stores as that animal goes through rigor mortis that muscle trying to continue to do something so pulling on ATP and a function of that process being lactate
- That lactate is so important as that rigor mortis process gradually takes place over 16 to 24 hours
- The pH level of that meat completely changes the color and texture in animals that are stressed and don’t have that gradual process to go through

*Eating habits of axis deer*

- Using camera to watch them, Jake has learned a lot about how they eat
- What was astonishing was that they are primarily grass eaters, which is not the case for most deer species, which are primarily browsers
- Browsers being that they’re always looking for for legumes and shrubs and trees — They’re constantly pulling on different plant species
- But axis deer are primarily grass eaters
- When you talk about what little intramuscular fat they do have, there’s high Omega-3s in there because they’re eating so much leafy greens

**Acute senses**

- They also seem to be very intelligent eaters with crazy acute senses
- For example, after walking three miles down a hill with dew all over our boots, we walk through an Axis deer trail, which for all intents and purposes, there should be no scent on our boot
- Yet an axis deer without even being in that specific spot, but five yards away, that deer is picking up the scent from that boot mark which was three hours earlier

**Picky eaters**

- They are so picky in what they’re eating and not even between different plant species, but within the same species
- They’re going up to one of their favorite little legumes is called glycine
- They’re going up to a particular group of glycine and they’re smelling, smelling, smelling before deciding to eat one particular patch over another
- What we don’t understand, is an animal that is that intelligent in what it eats, how that impacts its nutritional value, and how that plays into how extraordinarily healthy they are
- The vast majority of other animals, a pig for example, plows through a field and just bulldozes its way through the entire thing

**Peter has been changed since eating axis deer meat**

- “*It’s hard to be healthier than the animal you’re eating. And it’s hard for the animal to be healthier than what it’s eating. Like this is not an accidental process*.” says Peter
- Since having axis deer, “*my appetite for store-bought meat has never been the same since that trip*.”

> “I just realized, even if I’m buying the most organic grass fed beautiful steak, it didn’t have the same stress-free existence that that Axis deer had or that elk had.” —Peter Attia

![](https://peterattiamd.com/wp-content/uploads/2021/04/peter-with-deer-muise-1024x768.jpg)

**Figure 6. Peter cleaning his deer.**

**How axis deer meat helped to transform Jake’s body and performance [1:54:45]**

> “When I started eating it the right way, I started noticing it. And I think at the age of what would have been like 20, I started getting stronger and I was really challenging my body.” —Jake Muise

- Third year of college Jake started to realize something
- He was used to dumping seasonings like teriyaki sauce with a bunch of sugar on his meats
- He stopped doing that and I started eating it like just straight steaks every night
- Jake had a peak vertical of 43 inches

![](https://peterattiamd.com/wp-content/uploads/2021/04/high-jump-muise.jpg)

**Figure 7. Jake showing off his vertical leap at the net.**

- He started to notice he was recovering better from workouts such as when he did “gravity drops” with the Olympic Sprinting Team
- At some point, it was hard to make physical gains and he remembers making this transition to just needing more food
- He started eating the right way, he got stronger, and went from 190 pounds to 220 and it was all muscle
- Jake says it was a function of his workouts and the quality food he was eating

## Why axis deer meat is the best option for those reluctant to eat meat: True nose-to-tail nutrition and ethical harvesting [1:58:15]

With Maui Nui Venison, Jake has taken this notion of nose to tail to a whole new level

- The harvested axis deer is made into steaks and other strips of meats and jerkeys
- They make pet food and pet chews
- And now they make bone broth which Peter high recommends

**Bone broth**

- The bone broth was sent to the USDA labs for testing
- When looking at the first batch of bones the USDA thought that they had adulterated the bones because they tested so high in protein per ounce (a statistical anomaly)
- The second batch they sent came back the same
- It tested **33% higher in protein per ounce than the best regenerative beef bones on the market**
- Regenerative beef when compared to “conventional beef” is about 3% higher in the amount of protein per ounce (whereas the axis deer bone broth was **33% higher**)
- Axis deer bone broth is essentially at about 25 grams of protein per 16 ounces

“*I think their level of intelligence in what they eat is translating to their nutritional value and we’re just starting to see that.*”

***One of Peter’s greatest joys…***

“*One of the great joys I have is introducing people to [axis deer meat]*.” says Peter

- The nanny who works for Peter’s family is (was) a vegan to a large degree because of the treatment of animals
- After seeing Peter’s family eat axis deer night after night, she finally asked some questions about what it was and where it came from
- She ended up trying the meat and loved it

> “I respect whatever choice a person makes with respect to what they want to eat and don’t want to eat and what the reasons are, but it’s also important to understand not all meat is created equal.” —Peter Attia

**Jake says…**

- [We go to] crazy lengths to make the process technically humane
- But we love these animals, the relationship with them started in this place where there was nothing but respect for them
- Now with Maui Nui, we’re seeing these testimonials where people are staying things like, “*It’s been 20 years and I decided to have meat after watching your video.”*
- “Something along the way told them it was no longer okay to eat meat and it’s been such an amazing experience for them to see our process and I think the intent in what we’re trying to do and be like, ‘Wait, this is an opportunity to eat meat again.’”

“That’s the big part of this is our mission is to balance populations. Our mission isn’t to get rid of these animals, we find them as an incredible resource for our communities when balanced, and the only way we do that is people need to eat them.” —Jake Muise

## What a truly balanced population of axis deer on Hawaii would look like [2:06:15]

**Current state of axis deer**

- There is basically axis deer dying on the side of the roads in Malokai
- Maui has 60,000+ and it’s on the way to 200k+

**What does sustainability/balance look like?**

- It’s a super nuanced subject because they don’t have the capacity to manage deer on public lands
- They also don’t ever want to affect resource availability for a subsistence hunter
- And anecdotally, on public lands on Maui, it’s pretty hard to find a deer
- There’s a scenario where subsistent hunters play a huge role in what balance looks like, but Jake also doesn’t get to dictate balance on a private landowner’s property
- What Jake is able to do is say, “Here’s how many animals you have. Look, we understand what they’re doing as a liability, as a function of dry feed or watersheds or fencing, or like our roadways. . .This is how many animals you have, how many do you want?”
- The land owners might say, “Let’s try and bring this from 6,000 to 2000 and see what it looks like.”
- Jake’s team is able to manage them with such precision via these aerial surveys, so they are able to toggle that balance

**Changing ranchers’ perspective**:

“*One of my absolute favorite things is we walk into a meeting with a rancher that is calling an animal spotted rat and it only presents liability to them. And by the time we leave that room, that animal has value because our harvesting process*.”

- Maui Nui pays the rancher a small amount per pound for each animal harvested
- In other words, it’s more valuable for them to let you harvest it humanely than for them to just shoot it and leave it sitting there
- At balance, the rancher is happy because he has optimal soil health and no runoff, and he’s not losing feed
- But he’s also seeing a small amount of additional value from this animal

**A ways to go**

- Many ranchers have reached out for help, but Maui Nui is yet large enough to help them all
- Maui Nui needs to grow and hire more harvesters
- But also there needs to be more people to eat these animals
- In that scenario, Jake believes they will be able to achieve balance by both growing the company, working with all these private landowners, and then having people eat the harvested meat
- “*If we’re able to grow large enough and we are able to operate on most of the private lands between all of them, we can find a population level that is also best suited for our community*.”

**True balance is challenging**

Molokai is a great example—

- Everybody on that place is driving 10 miles an hour on the roads
- There are so many deer on the road, the risks to hitting a deer is at those densities is profound
- Maui you can do 55, 65 miles an hour

*Other points*

- The deer due enormous damage to watersheds and sediment
- But it doesn’t make sense to eradicate them since they are a good food source
- This is a hard conversation too because Hawaii is also the endangered species capital of the world so there’s a very real conversation
- “*If I was a conservationist, as I would say get rid of all of these invasive species and let’s work to bring back or rehabilitate the endangered species in these same spaces*.”

**Is it even technically feasible to eradicate axis deer from Hawaii if that was desired?**

- No way, they’re too smart
- Only able to accomplish that on the Big Island because they were in such low numbers
- So there’s no choice but to find balance

*One way to look at balance…*

- To at least say, “I support the idea that there shouldn’t be deer shit in our watersheds.”
- There’s nothing more valuable to an isolated landmass and a community trying to be self-sufficient
- We’ve donated 50,000 pounds of venison, over a hundred thousand meals through COVID because food banks were empty.

> “Hawaii’s economy teeters on absolute disaster because we’re so dependent on tourism and when COVID hit and we shut the door, the vast majority of our community was in trouble.” —Jake Muise

*Nuance…*

- Yes, there’s ecosystems and ecology we have to respect, and every native species has a right to exist in its own place, but there’s also **economics and food security**
- It’s finding a balance for where these animals should be in the long run and that’s where we produce food, it’s not in our mountain where we depend on water
- But the conversation of balance isn’t just like, “What’s the deer density in this particular place?”
- The conversation of balance is like, “How do you interact with all of these things across your communities and ecosystems and all of these other things?”

## Maui Nui Venison’s charitable work during the COVID crisis [2:12:45]

**Donating food during COVID**

- Part of why Maui Nui has been in such high favor with local people because they gave away an enormous chunk of their product (right in the middle of the time when they were trying to grow as a company)
- About 50,000 pounds of food in eight months
- Bu at the same time, it was a no-brainer, says Jake
- They had to delay the growth of the company by donating all this food but it served the same mission which is you’re feeding people and you’re managing a population
- To everybody’s credit on the team who knew they needed to grow to be profitable, everyone agreed this was the right decision

§

## Selected Links / Related Material

**Jake’s company**: [Maui Nui Venison](https://mauinuivenison.com/) | (mauinuivenison.com) [2:30, 1:27:00]

**Non-profit started by Jake**: Axis Deer Institute [31:30]

**In 1868,** [**King Kamehameha V**](https://en.wikipedia.org/wiki/Kamehameha_V) **hired the Matheson Trading Company to get axis deer out of India to bring to Hawaii**: [Hawaiian Gazette, 1867](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACc81uljEpjd5GG_sCRPoTna/pre-1900s?dl=0&preview=1867-Hawaiian+Gazette.pdf&subfolder_nav_tracking=1) | [35:30]

**Axis deer were brought downthe Yangtze River on a boat called the Lochnagar before arriving on Moloka’i with two bucks and five does (a baby buck was born and they named it King Kamehameha the Fifth)**: [[Honolulu Star Bulletin, 1972](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1972-2-Honolulu-Star-Bulletin.pdf&subfolder_nav_tracking=1); [Honolulu Advertiser, 1961](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1961-Honolulu-Advertiser.pdf&subfolder_nav_tracking=1); [Honolulu Star Bulletin, 1936](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AAD5Dok6u-L-TNlDT7Jkh9_aa/early%201900s?dl=0&preview=1936-Honolulu-Star-Bulletin.pdf&subfolder_nav_tracking=1) | [35:45]

**Old articles estimating there were 7,000 deer and they were already decimating what they were describing in the “upland forest”**: [Honolulu Star Bulletin, 1950](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1950-1-Honolulu-Star-Bulletin.pdf&subfolder_nav_tracking=1) | [37:15]

**Old Hawaiin articles about them hiring “sharp shooters” from California, and the sharp shooters from California recorded killing 5,000 deer**: [Honolulu Star Bulletin, 1950](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1950-1-Honolulu-Star-Bulletin.pdf&subfolder_nav_tracking=1); [Hawaii Tribune Herald, 1964](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AACxP4wzz-UgjaS4r5oivEHqa/1950s-1970s?dl=0&preview=1964-Hawaii-Tribune-Herald.pdf&subfolder_nav_tracking=1) | [37:30]

**Articles about how not too long after introducing axis deer to the islands there starts to be arguments over how to manage the axis deer**: [Evening Bulletin, 1909](https://www.dropbox.com/sh/7myqsb5lfov1q2b/AAD5Dok6u-L-TNlDT7Jkh9_aa/early%201900s?dl=0&preview=1909-Evening-Bulletin.pdf&subfolder_nav_tracking=1) | [37:45]

**Texas Hill Country has the densest number of deer per acre at about 6 per 100 acres**: [White-tailed Deer Management in the Texas Hill Country](https://tpwd.texas.gov/publications/pwdpubs/media/pwd_rp_w7000_0828.pdf) | (tpwd.texas.gov) [51:45]

**Jake learned about the impact of sleep deprivation on performance from episode of The Drive with Matthew Walker**: [1:42:00]

- [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/) | Peter Attia (peterattiamd.com)
- [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/) | Peter Attia (peterattiamd.com)
- [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/) | Peter Attia (peterattiamd.com)
- [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/) | Peter Attia (peterattiamd.com)
- [#77 – AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/) | Peter Attia (peterattiamd.com)
- [#127 – AMA #3 with sleep expert, Matthew Walker, Ph.D.: Fasting, gut health, blue light, caffeine, REM sleep, and more](https://peterattiamd.com/matthewwalkerama3/) | Peter Attia (peterattiamd.com)

**Peter tells about how he picked up archery on the podcast episode with John Dudley**: [#109 – John Dudley: The beauty in archery, the love of practice, and a model system for life](https://peterattiamd.com/johndudley/) | Peter Attia (peterattiamd.com) [1:52:00]

§

## People Mentioned

- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [6:00]
- [Mark Messier](https://en.wikipedia.org/wiki/Mark_Messier) [6:00]
- [Tino Reyes](https://hiloathletics.com/sports/womens-volleyball/roster/coaches/tino-reyes/63) [16:00]
- “Mikey” [24:45, 45:00]
- [Matthew Walker](https://twitter.com/sleepdiplomat?lang=en) [1:42:00]
- [John Dudley](https://twitter.com/nockontv?lang=en) [1:52:00]

§