# #100 – Sam Harris, Ph.D.: COVID-19—Comprehending the crisis and managing our emotions

**Source:** [https://peterattiamd.com/samharris2/](https://peterattiamd.com/samharris2/)

---

##### Check out more content with Sam Harris:

- *(December 20, 2018)* [Sam Harris, Ph.D.: The transformative power of mindfulness](/samharris/)
- *(March 24, 2020)* [Sam Harris, Ph.D.: COVID-19—Comprehending the crisis and managing our emotions](/samharris2/)

In this episode, Sam Harris, neuroscientist, author, and host of the Making Sense Podcast, joins Peter to discuss this unprecedented coronavirus (COVID-19) crisis. The discussion includes the important distinction between COVID-19 and influenza, the impact on the economy, the dire situation in New York, and the challenge of creating a safe and effective vaccine. Additionally, Sam brings insights from his extensive meditation practice to help those struggling with stress, anxiety, and fear in this extraordinary situation.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/samharris2/the_Drive_public.png)

Play

#100 - Sam Harris, Ph.D.: COVID-19—Comprehending the crisis and managing our emotions

#100 - Sam Harris, Ph.D.: COVID-19—Comprehending the crisis and managing our emotions

1x15s30s

0:001:32:25

## We discuss:

- A time unlike any other—why many people don’t seem to fully grasp the magnitude of this situation [2:00];
- Why comparing COVID-19 to influenza is a bad analogy [10:45];
- The impact on the economy of measures like shelter-in-place—Is the “cure” worse than the disease? [16:45];
- Why are some places, like New York, getting hit so much worse? [24:45];
- The trickle down effect of an overrun healthcare system on non-COVID related health issues [34:45];
- How to calm our minds and manage our emotions during this craziness [38:00];
- Talking to kids about this situation without burdening them with undue stress [50:15];
- Insights from meditation practice—Recognize and unhook yourself from a heightened emotional state [52:00];
- How to make the most of a situation where you let your emotions get the best of you [59:15];
- What are some potential positive things that Sam hopes could be learned from this crisis and applied to the future? [1:09:30];
- The unfortunate politics being layered on top of this crisis [1:15:30];
- The challenge of creating a safe and effective vaccine for COVID-19 [1:20:00]; and
- More.

§

## Show Notes

## A time unlike any other—why many people don’t seem to fully grasp the magnitude of this situation [2:00]

> “This has been a period of time unlike any other in our lifetimes. . . there’s really no analogy.”

- Between SARS, MERS, and now COVID-19, these coronavirus are not something that will just go away
- It seems like we should have known something like this could happen, yet as a society we are so fundamentally surprised
- 2015 TED Talk by Bill Gates: [The next outbreak? We’re not ready](https://www.ted.com/talks/bill_gates_the_next_outbreak_we_re_not_ready/up-next?language=en)
- Sam’s worried that after we come out of this, we will eventually fall back asleep on it until it blindsides us again

People are having a tough time grasping the magnitude of the situation

- Sam has spent a lot of time trying to convince smart people to take this seriously
- But there really is no good analogy to this situation
- “*It’s just been very interesting to see the layers of denial and obfuscation present themselves and to have to kind of punch through them. . . .it’s just psychologically, it’s very interesting to watch.*”

The challenge of communicating this crisis to the public

- Peter says the communication has been too binary — e.g., people saying we “know” this or that will happen
- A better way to communicate things that would less alienating to the people who are naturally skeptical would be to use confidence intervals — e.g., “we’re 90-95% sure that this or that will happen”

## Why comparing COVID-19 to influenza is a bad analogy [10:45]

- Many people have been outwardly comparing this to the seasonal flu to sort of downplay the crisis
- But Sam and Peter say this is not a good analogy
- Nobody is discounting the severity of influenza
- However, influenza comes in a very predictable wave and the infection and mortality is spread out over the course of a year
- But CV is still in **exponential growth** in new cases and there’s no evidence yet that we are on the back side of that curve where that has stabilized
- And we don’t yet know what the absolute potential for mortality from coronavirus really is because it’s still in its infancy
- If we could somehow “freeze” the new cases in their tracks, this CV situation would indeed look way less harmful compared to the flu
- So the point is… **what steps can we take to freeze this thing from spreading?**

## The impact on the economy of measures like shelter-in-place—Is the “cure” worse than the disease? [16:45]

- It’s hard to say what we could do differently to protect the economy without a vaccine
- There are many people that are really worried about how the “lock down” or “shelter in place” strategy might crush the economy and lead to a depression
- Sam says many of the policymakers are also concerned but may not be expressing it properly
- At the same time, nobody is saying there’s nothing to worry about from an economic standpoint
- Sam is concerned that people aren’t fully grasping the importance of stamping down the spread of this virus
- Sam also acknowledges that even after just one week, the “shelter in place” order is beginning to unwind as people grow more restless
- And this fact makes it pretty clear that the idea that sheltering for weeks, much less months, is a farfetched idea

*Why haven’t we been able to communicate this idea of shelter in place to eradicate this virus?*

*How long would it take?*

- It will be very hard to enforce “stay at home” in a free society like the US
- But Sam doesn’t feel like this idea that it will take a few weeks and we could nearly eradicate the virus hasn’t been communicated properly
- Peter says it would likely take about 4 weeks of total lockdown to burn this thing out

## Why are some places, like New York, getting hit so much worse? [24:45]

See [this video](https://www.youtube.com/watch?v=F2EK-XRBsSo) by Peter that explains why NY is in a dire situation and why we can’t think of Italy or the US as a whole:

- It’s important to understand that even within Italy, the statistics are drastically different among areas (Milan vs. Rome vs. Sicily)
- New York is looking to be in a much more dire situation compared to other cities in the US
- Even with the most conservative estimates, Peter says it’s **unlikely that NY will not get overwhelmed with ICU cases**
- Why?
  - NY got a bad head start (i.e., they pumped the brakes too late)
  - They live in close quarters
  - Lots of public transit

> “We think that there needs to be a really important strategy of mitigation in New York and that every other city like Miami, like San Francisco, like Los Angeles and like Seattle who are next in the cross hairs, needs to be pushing the brakes a little harder.”

## The trickle down effect of an overrun healthcare system on non-COVID related health issues [34:45]

- When the healthcare system gets overwhelmed, other health issues people have may also go untreated potentially leading to death
- In Peter’s practice, there are patients needing blood work done but won’t get it for some indefinite period
- Less drastic things like root canals and other more minor procedures will be affected as well
- Tip: Be careful not to get injured because you won’t want to have to go to an urgent care for treatment and risk getting and spreading CV

## How to calm our minds and manage our emotions during this craziness [38:00]

-Many people are experiencing elevated stress, anxiety, and fear at this moment

*-How does Sam handle this?*

> “If you understand the mechanics of your own mental suffering, if you understand how anxiety arises from the first person side. . . just actually able to witness it as a matter of experience, moment to moment, that allows you to get off the ride whenever you can remember to.”

-Sam says it starts with being able to recognize your thoughts and emotions and suffering

- The recognition is a skill that needs to be learned
- Then it needs to be practiced
- Overtime you become more skilled
- It’s not that you can stop negative feelings from arising…
- …It’s that you can drastically shorten the amount of time it takes to untether yourself from them

> “You want to feel fear when it’s appropriate and useful to feel it and you want to be able to release it the moment there is no point to it.”

## Talking to kids about this situation without burdening them with undue stress [50:15]

Sam practices **honesty** as a core ethic in his home

- But just because you are not lying to your kids, it doesn’t mean you have to tell them everything
- If his daughter, for example, were to ask a question for which the answer will cause her to be anxious…
- …”I’ll basically just acknowledge in that moment that there’s a door that’s locked that she’s trying to open, but there’s no point in opening it. I’ll tell her what she needs to know there. And that’s not the same thing as saying, ‘Oh, there’s nothing to worry about’ or giving her some dishonest answer.”

> “It’s a stronger foundation for a relationship . . . because she knows now that when I say something is not worth worrying about. . .she knows I’m not bullshitting her.”

## Insights from meditation practice—Recognize and unhook yourself from a heightened emotional state [52:00]

- Sam says that he isn’t immune to getting emotional or angry or letting emotions get a hold of him
- The difference is…
- Through mindfulness practice, Sam has the ability to “put on the brakes and get off the ride” quickly

⇒ [Waking Up App](https://wakingup.com/)

## How to make the most of a situation where you let your emotions get the best of you [59:15]

- Peter recently [shared on social media](https://www.instagram.com/p/B975Rqvg_9H/) an embarrassing moment where he lost his temper on his kids and felt subsequent shame about it
- Sam points out that you can turn moments where you screw up into a positive
- That feeling of shame could serve an important purpose
- For example, that feeling of shame might compel you to give a sincere apology
- That apology could then show your kids that it’s okay to sometimes lose control of your emotions as long as you recognize when it happens and try to improve it

## What are some potential positive things that Sam hopes could be learned from this crisis and applied to the future? [1:09:30]

- Sam is hopeful that this crisis might help separate out the experts from the rest who might be just making stuff up
- He hopes that the anti-vaccine community will recognize the importance of vaccinations and perhaps slow the anti-vax movement
- He’s hopeful that people will start to place more value in the scientific community who are invaluable in moments like the present
- Sam hopes that people (especially those with extreme libertarian views) will recognize the essential role of government
- Peter adds that he hopes people will see that a public-private partnership is essential
- Peter also says he’s optimistic that in the future, cities will take on some more of  the risk stratification and planning such that they aren’t waiting on the federal government or the CDC
- Overall, Sam is hopeful that we’ve learned many lessons from the many things that have gone wrong in this crisis so that WHEN it happens again, we are more prepared

## The unfortunate politics being layered on top of this crisis [1:15:30]

- Sam says that the political layering has distorted everything
- Sam uses the example of the controversy around the term “Chinese virus”
- Sam says many are caught up in criticizing the president for using this term
- And the president is surely using the term to bait his opponents into getting caught up in it
- But the reality is that this virus did originate in China
- And it was born of bizarre and unacceptable cultural practices of eating bats
- And the Chinese authoritarian government did conceal the gravity of this outbreak and failed to give the world adequate warning
- However, Democrats might be right to be worried about how Chinese people might be treated because most of them have nothing to do with this and are equally horrified by the practice of eating bats

> “You can hold these truths in buffer simultaneously and not be deranged by it, but we don’t have a politics, or a journalistic community, frankly, that is showing much aptitude for that.”

## The challenge of creating a safe and effective vaccine for COVID-19 [1:20:00]

- This is harder to vaccinate that things like polio, measles, or smallpox
- The coronaviruses behave a bit more like RSV viruses which, to create enough immunity, you have to create a larger exposure
- And the risk of the vaccine is higher—anytime you vaccinate somebody there’s a risk that they get sick from the vaccine
- The perfect vaccine would be the vaccine for which you have no risk from the vaccine and you get perfect immunity…
- …But the reality if you may never get there
- In discussions with virologists, Peter says “*we have to sort of caveat our optimism around how long it will take to make a vaccine for this and how safe it will be.*”
- “*This mirrors the type of virus for which vaccines have historically not been a great alternative because of the risk reward trade off*.” says Peter
- This brings up the important point that we have to be able to discuss this stuff openly and not get bogged down in unreasonable positions
  - I.e., the anti-vax movement which is largely based on a [retracted paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2831678/)

§

![](https://peterattiamd.com/wp-content/uploads/2020/03/Screen-Shot-2020-03-24-at-11.52.38-AM.png)

##### Sam Harris, Ph.D.

Sam Harris is the author of five *New York Times* bestsellers and the host of the [Waking Up Podcast](https://samharris.org/podcast/). His books include *The End of Faith*, *Letter to a Christian Nation*, *The Moral Landscape*, *Free Will*, *Lying*, *Waking Up*, and *Islam and the Future of Tolerance* (with Maajid Nawaz). *The End of Faith* won the [2005 PEN Award for Nonfiction](https://pen.org/2005-literary-awards-winners/). His writing and public lectures cover a wide range of topics—neuroscience, moral philosophy, religion, meditation practice, human violence, rationality—but generally focus on how a growing understanding of ourselves and the world is changing our sense of how we should live. Harris’s work has been published in more than 20 languages and has been discussed in *The New York Times*, *Time*, *Scientific American*, *Nature*, *Rolling Stone*, and many other journals. He has written for *The New York Times*, *The Los Angeles Times*, *The Economist*, *The Times (London)*, *The Boston Globe*, *The Atlantic*, *Nature*, *The Annals of Neurology*, and elsewhere. Sam Harris received a degree in philosophy from Stanford University and a Ph.D. in neuroscience from UCLA. For more, see his [publications and lectures](https://samharris.org/publications-and-lectures/). [[samharris.org](https://samharris.org/)]