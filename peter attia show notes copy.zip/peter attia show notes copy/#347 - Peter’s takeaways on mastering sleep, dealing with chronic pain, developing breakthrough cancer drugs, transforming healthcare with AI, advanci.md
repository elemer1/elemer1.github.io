# #347 – Peter’s takeaways on mastering sleep, dealing with chronic pain, developing breakthrough cancer drugs, transforming healthcare with AI, advancing radiation therapy, and healing trauma | Podcast Summary #5

**Source:** [https://peterattiamd.com/qps5/](https://peterattiamd.com/qps5/)

---

In this podcast summary episode, Peter summarizes his biggest takeaways from the last three months of guest interviews on the podcast. Peter shares key insights from his discussions with Jeff English on the journey to healing from trauma; Ashley Mason on improving sleep and CBT-I; Sanjay Mehta on misconceptions around radiation and its use in cancer therapy and treating inflammatory conditions (such as arthritis and tendonitis); Sean Mackey on understanding and treating acute and chronic pain; and Susan Desmond-Hellmann on insights from her extraordinary career that pertain to the use of AI in medicine, understanding cancer, and the development of cancer therapeutics. Additionally, Peter shares any behavioral changes he’s made for himself or his patients as a result of these fascinating discussions.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [episode #347 show notes page](https://peterattiamd.com/qps5/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Summary of episode topics [1:45];
- Jeff English episode: how trauma shapes behavior and identity, and the value of understanding personal adaptations and working through unresolved emotional wounds [3:45];
- Practical behavioral changes and emotional tools Peter has applied since the Jeff English episode [13:00];
- Ashley Mason episode: treating insomnia using CBTI and practical behavioral techniques for improving sleep quality [19:15];
- When to seek professional care for sleep issues [30:30];
- Sanjay Mehta episode: radiation therapy’s evolution, its underused potential in treating inflammatory conditions, and the cultural misconceptions surrounding radiation exposure [33:45];
- Peter’s predictions and insights for the upcoming Formula 1 season [43:15];
- Sean Mackey episode: the neuroscience, classifications, and treatment strategies for chronic pain, and the importance of personalized care [57:45];
- Susan Desmond-Hellmann episode: how AI is revolutionizing medicine through advancements in drug development, biomarker discovery, and the potential of training models on private clinical data [1:05:45];
- More from Susan Desmond-Hellmann: why cancer is so difficult to treat with drugs, the promise of immunotherapy, and the long-term hope for systemic treatments [1:14:00]; and
- More.

---

The Peter Attia Drive

#347 – Peter’s takeaways on mastering sleep, dealing with chronic pain, developing breakthrough cancer drugs, transforming healthcare with AI, advancing radiation therapy, and healing trauma | Podcast Summary #5

---

## Show Notes


---

\***Notes from intro**:

- In today’s podcast summary episode, Peter will discuss what he learned from some of the recent episodes of *The Drive*
  - Focusing on what he thinks were the most important insights
  - As well as any changes in his behavior as a result
- This shouldn’t be seen as a replacement for listening to or watching any of the original episodes
- This may be a great way to reinforce things that you already saw or point you back to an episode you missed

**Topics covered in the past quarter**

- [Jeff English](https://peterattiamd.com/jeffenglish/) – trauma, therapy, mental and emotional health
- [Ashley Mason](https://peterattiamd.com/ashleymason/) – insomnia, cognitive behavioral therapy for insomnia (CBT-I), and improving sleep
- [Sanjay Mehta](https://peterattiamd.com/sanjaymehta/) – radiology, radiophobia, common misconceptions around radiation, and radiation therapy
  - Not just for cancer therapy but also for treating inflammatory conditions (such as arthritis and tendonitis)
- [Sean Mackey](https://peterattiamd.com/seanmackey/) – pain, chronic pain, and how to treat them
- [Susan Desmond-Hellmann](https://peterattiamd.com/susandesmondhellmann/) – discussions around oncology, cancer drug development, and how AI is impacting medicine now and possibly in the future
  - This was an interesting episode looking over her career

## Summary of episode topics [1:45]

**REMINDER**: These podcast summaries are a way listeners can hear from Peter about insights he took from guest episodes such as where Peter’s behaviors have changed and how his thinking may have changed, but these episodes are not necessarily a replacement for listening to the full episodes.

**Overview of Episodes to be Discussed**

1. Jeff English [episode](https://peterattiamd.com/jeffenglish/)

- Topic:
  - Mental and emotional health
  - Trauma therapy
- Key Area:
  - Psychological well-being and healing

2. Ashley Mason [episode](https://peterattiamd.com/ashleymason/)

- Topic:
  - Sleep improvement
  - Insomnia treatment
  - Cognitive Behavioral Therapy for Insomnia (CBT-I)
- Key Area:
  - Practical approaches to enhancing sleep quality

3. Sanjay Mehta [episode](https://peterattiamd.com/sanjaymehta/)

- Topic:
  - Radiology and radiation
  - Applications in cancer treatment
  - Surprising use case: arthritis treatment
- Key Area:
  - Medical imaging and therapeutic radiation

4. Sean Mackey [episode](https://peterattiamd.com/seanmackey/)

- Topic:
  - Pain management
  - Chronic pain
  - Strategies for recovery
- Key Area:
  - Understanding and overcoming long-term pain

5. Susan (Sue) Desmond-Hellmann [episode](https://peterattiamd.com/susandesmondhellmann//)

- Topic:
  - Career in medicine and leadership
  - Cancer treatment and oncology
  - Drug development
  - Artificial Intelligence (AI) in medicine
- Key Area:
  - Intersection of medical innovation, biotech leadership, and emerging tech

## Jeff English episode: how trauma shapes behavior and identity, and the value of understanding personal adaptations and working through unresolved emotional wounds [3:45]

[#339 – Unpacking trauma: How early wounds shape behavior and the path toward healing | Jeff English](https://peterattiamd.com/jeffenglish/) (March 10, 2025)

\*\*\*

- This was an episode Peter really looked forward to doing
- He has known Jeff for many years and owes him a great debt of gratitude
- This is one of those episodes where between the time we recorded it and the time it came out was probably 8-10 weeks
- During that period of time, Peter sent the unedited straight audio file of it to no fewer than 15-20 people

> “*I couldn’t even wait for this episode to come out to be sharing it with people*.”‒ Peter Attia

- That will be a record that will last for some time
  - There’s no scenario he can think of where he’s taken a podcast before it comes out and shared it with so many people
- Most of the people he shared it with not only found it to be incredibly valuable, but actually wanted to sort of engage with Jeff on a professional level after that
- It’s one of those podcasts where if it resonates with you, it’s really important, you’re going to share it a lot

**This was a great episode about understanding trauma**

- It’s such a loaded word; it’s understandable why people might have some skepticism around that
- The word does get used a little bit too much
- Jeff has a great **definition** for it: ***trauma is a moment of perceived helplessness that activates the limbic system***
  - This can be a wounding event, a major event, or maybe a series of smaller events, and those typically get referred to as “big T” and “little t traumas”
  - A “big T” trauma is something really obvious, being the victim of a violent crime, for example
  - A “little t” traumas are like a thousand paper cuts, a parent that was there but just really wasn’t paying attention to their kid, and those can be damaging in different ways

***With trauma, too often people focus on the “what happened” part of the equation, but he thinks that it’s more important to focus on the “how did I adapt” part of the equation***

**⇒** The [sine quo non](https://en.wikipedia.org/wiki/Sine_qua_non) of trauma is that there’s a disconnected version of a person that shows up to life relying on maladaptive strategies to replace connection with something else

- Peter thinks that is a remarkably succinct way to explain things
- It’s not judgmental, it’s just saying that something happened, a series of things, and there have been adaptations
- Those adaptations have led to disconnection and maladaptive strategies
- This could be things that are perceived of as “bad” like alcohol, drugs, gambling, but it could be also things that are “good” such as work or perfectionism

**Peter’s most important takeaway**: All of those things replace the sense of connection

- This is an episode that you have to go back and listen to

**Jeff spoke about implicit and explicit memories**

- People can explicitly remember an event and think objectively, it didn’t really impact me, but implicitly it is impacting them through anxiety or some other type of discomfort

Jeff had a great saying, which is “*If it’s hysterical, it’s historical.*”

- Peter thinks about this often when he overreacts emotionally
- When he calms down, he  usually asks himself, “*What was that really about?*”
  - Was it really about the thing that you blew up over, or was there something deeper that this is reminding you of in terms of a vulnerability or something like that?

**Very important distinctions were made between guilt and shame**

- He described guilt as about making a mistake
- Whereas, shame is about being a mistake
- Some people refer to this as healthy shame and unhealthy shame
- Again, it’s not necessarily one way to think about this

**Jeff talked about the trauma tree**

- Peter has heard so many different people talk about trauma in so many different ways
- Peter thinks this is one of the better models
- It’s a tree because it has roots and it has branches
  - The roots are below the ground and the branches are above the ground

***That is a metaphor for the fact that the roots or the causes are not necessarily visible while the adaptations, the branches are indeed visible***

It’s very important to understand in this model that **intention is not a requirement** for the roots of a tree

- What does that mean?
  - Sometimes the wounding events (i.e., the roots) are not intentional
  - They’re not driven by people who are intending to hurt
- Peter thinks this is a very important thing for people dealing with trauma to understand because it’s very easy to minimize an event that had an impact on you as a child
  - For example, if you believe that the person who was responsible for this wasn’t trying to hurt you, and that’s often the case

*The 5 roots are broken down as*

- 1 – Abuse (which can be physical, emotional, or sexual) typically is deliberate
  - Or religious (there’s an example where it might not be with a malintent, but it has bad outcomes)
- 2 – Abandonment (literally being abandoned by a parent, or emotional)
- 3 – Neglect (the care provider is still present but is not paying attention to the child)
- 4 – Enmeshment (which is a boundary violation, emotional incest)
  - This happens when kids have to grow up far too quickly to be emotional caregivers or peers with parents typically
- 5 – Tragic events (war, violent events)

*The branches are adaptations*

- The important thing to remember here is that adaptations typically work very well for the child that has been wounded
  - Peter uses the word wounded as kind of a broad emotional term
- The problem is they tend to become maladaptive later in life
- Jeff gives a great example of a father who is physically abusing the mother of his child
  - And whenever this happened, the child would run into his bedroom out of fear because dad is getting violent, he’s hurting mom
  - One day the child’s fear that his mother was going to be hurt was so great that he ran into the bathroom and pretended that he was sick as a way to distract the father
  - So the father screams at the mother and says, “*Look what you’re doing. Your hysterical whining has made your son sick*.”
  - And this temporary distraction actually prevented his father from injuring the mother
  - So that was an amazing adaption
  - That child basically learned that he could be deceptive and manipulative and it actually worked
  - It was a really good adaptation and it probably will serve that child well for some time
  - The problem is it will not serve that child well as an adult

***Jeff describes these adaptations as old friends that serve you well but lose their utility and become destructive as you age***

The 4 branches

- 1 – Co dependency (which he calls an outer reach for inner security)
- 2 – Addictive patterns (substances, but could also be work, process obsession, things of that nature)
- 3 – Attachment issues (where the common thread is insecurity)
  - There’s anxious attachment, avoidant attachment, disorganized attachment
- 4 – A bucket for all other maladaptive strategies

![](https://peterattiamd.com/wp-content/uploads/2025/05/f1-qps5.png)

**Figure 1. The trauma tree is a metaphor for wounding events (roots) and adaptations that cause problems (branches)**.

- Peter has learned a lot about this over the past 7-8 years and thinks Jeff sums it up well
- He’s seen this over and over in himself and in patients

> “*When you’re working through trauma or if you’re on the fence about whether or not you should work through trauma, it’s worth remembering: you are either going to deal with it or it’s going to deal with you. These things cannot be buried*.”‒ Peter Attia

- It’s like a wack-a-mole, it always shows up at some point and you can’t play whack-a-mole indefinitely

**The first step is**

- Accepting that that’s the case and that there’s a better way to be
- Understanding that these coping strategies, while incredibly valuable, are probably not helping you
- That you may indeed be passing on maladaptive behaviors to your kids if you’re a parent
- Dealing with something that Jeff describes as putting the “adaptive child” out of the driver’s seat and into the back of the car

**Peter doesn’t think this summary even remotely serves as a substitute for listening to that episode**

- If you missed that episode and anything he said even remotely piques your curiosity, you’ve got to go back to it

## Practical behavioral changes and emotional tools Peter has applied since the Jeff English episode [13:00]

**Are there any behaviors that you changed from your relationship with Jeff prior to this or behaviors that people could start to apply in their own life if they are trying to figure this out for themselves?**

- 1 – Practicing or understanding what your practice looks like to expand your distress tolerance window
- Peter writes about this quite a bit in the final chapter of [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0)
- It’s sort of knowing the things that you do that give you a greater operating window
- For example, for many people, meditation is a great tool to increase the probability of responding as opposed to reacting when something happens
- 2 – Learning the language of “I statements,” basically taking ownership for what you think, what you feel, what you do
- 3 – Working through this triad that he describes as the “triangle of vulnerability:” sadness, shame and fear
  - Trying to be curious about where you are on that triangle, and being more responsive to your own emotional vocabulary around these things
- 4 – Noticing what your coping skills are
  - Peter talks about and often jokes about some of his that still exist to this day
    - E-shopping is an enormous coping skill for stress
    - He just can’t stop buying stupid things online when he is stressed out
  - He feels fortunate in some ways and is really glad that it’s not drinking too much alcohol
  - But it’s still a distraction (even if the worst thing it does is set him back a few dollars), and it’s preventing him from connecting
    - Preventing him from accepting and dealing with what it is that’s happening

**What advice do you have to encourage people to take the first step and figure out this journey for themselves?**

- Peter just can’t say enough about this
- It’s one of the things he enjoys talking about with patients more than anything because even though patients come to his practice because they want to improve their lifespan, they also care about healthspan and it’s easy to forget that emotional health is a piece of healthspan
- When a person is sort of caught in the vicious cycle of what’s often the response to and the adaptation to traumatic events (not necessarily exclusively as children, but often as children), they’re not living this connected life that Jeff talks about

***Peter can just share from personal experience that being disconnected versus being connected is all the difference in living***

- And it’s not like you flip a switch and everything is fine; it’s a process; it’s a journey

> “*I’ve never met a person who’s addressed their negative adaptations and come out on the other side and said, ‘I wish I didn’t do that.’*”‒ Peter Attia

**A question commonly asked on the website: Peter has openly talked about going to two centers to do in-depth work on this. What are those called?**

- Obviously these aren’t the only 2
- 1 – The first place was called [The Bridge to Recovery](https://www.thebridgetorecovery.com/), and Peter went there in 2017
  - That is where he met Jeff English (he talked a lot about that in the podcast)
- 2 – In 2020 Peter went to a place called [PCS (Psychological Counseling Services)](https://pcsintensive.com/)
- He would recommend both of these places very highly
- PCS focuses on more than just trauma, but it’s very trauma focused
- The Bridge is really a trauma-based residential program, and Peter is sure there are others out there that are equally wonderful

*Peter has encouraged a number of people to go to these locations and many have*

- Everyone acknowledges as he did up front like, “*Are you kidding me? How about I just keep working with my therapist for an hour twice a month?*”
- That can work, but sometimes it doesn’t and sometimes you actually need to undergo immersive therapy

*A metaphor to understand the utility of these places*

- If you want to learn a language one hour a week tutoring in a class is good, but sometimes moving to that country and being forced into that is how you’re going to learn better

**Last question, have you ever bought anything in one of those shopping stints and you’ve thought a week later like,** ***“Oh, this was actually awesome, I’m glad I did,*****” and if so, what was the best thing that came out of that?**

- Truthfully (and this is just terrible rationalization), he’s pretty happy with most things he buys in his eShopaholic bursts
  - Not all of them; he has bought some really stupid things
- What he tends to do is give them away so that he doesn’t see them again
  - Which is actually counterproductive because he should keep more of those things as a reminder of his bad behavior (the consequences of those actions)
  - It’s a horrible selection bias: he keeps the things that are awesome and gives away the things that are not awesome

Nick asks, “*Does that mean anyone who’s ever gotten a gift from you should think that this is actually Peter getting rid of stuff that he doesn’t want? Or it doesn’t quite work that way?*”

- Peter gives away much more than just his non-awesome stuff

## Ashley Mason episode: treating insomnia using CBTI and practical behavioral techniques for improving sleep quality [19:15]

[#341 – Overcoming insomnia: improving sleep hygiene and treating disordered sleep with cognitive behavioral therapy for insomnia | Ashley Mason, Ph.D.](https://peterattiamd.com/ashleymason/) (March 24, 2025)

\*\*\*

- Ashley Mason was a great episode on sleep, insomnia, CBT-I, how to improve your sleep
- We have already talked about wanting her to come back for part two because we didn’t get through everything we were hoping to
- We sketched out a lot of things we were going to talk about, but we never got out of insomnia and CBT-I because Peter felt like it was just too important to stay there and gather all that information
- Peter learned a lot, and what he came away with is thinking that he feels like he almost knows enough to help people through part of the CBT-I playbook without even having to refer out to CBT-I

> “*The takeaway from this episode should be that you can do a lot of CBT-I on your own, which is not to say you shouldn’t reach out to a practitioner if you’re struggling, but the good news is so much of the heavy lifting was covered here*.”‒ Peter Attia

**Start with the semantics**

- Insomnia must persist for months, it must interfere with life, and it must cause distress
- This isn’t just a few nights of bad rest
  - We don’t want to over pathologize this
- We’re really trying to focus on a meaningful reduction in sleep

*CBT-I (or cognitive behavioral therapy for insomnia) is one of the most effective tools for addressing serious insomnia*

- 50-60 people who utilize this achieve a complete remission and 70% show improvement

*There are lots of contributing factors to the development of insomnia*

- 1 – Predisposing factors include genetics, past experiences
- 2 – Precipitating factors can be a life crisis, divorce, enormous stressful experiences at work
- 3 – Perpetuating factors or coping strategies are what you do when you are in the state of insomnia

***CBT-I only focuses on the latter; it does not concern itself with what your predisposing factors are***

- CBT-I doesn’t even care what the precipitating factor is and doesn’t try to stratify people based on those things
- It basically says “*You’re here, you’re having significant insomnia, what are you doing to cope with it and how do we address that?*”
- In that sense, the treatment is independent of the first two

Before we go on, Peter points out, “*You do need to address any sleep pathology, like restless leg syndrome or sleep apnea before engaging in this. So you have to rule out that kind of stuff.*”

**CBT-I is really about addressing this triangle of thoughts to feelings to behaviors**

![](https://peterattiamd.com/wp-content/uploads/2025/05/f2-qps5.png)

**Figure 2. CBT-I can intervene in any of these three connected processes**.

- In this triangle of thoughts, feelings, and behaviors ‒ each one is influencing the next
- The discussion with Ashley was really a great way to go through all of the behavioral changes to mitigate insomnia, which fall under the buckets of:
  - 1 – Sleep hygiene
  - 2 – Stimulus control
  - 3 – Time in bed restriction
  - 4 – Cognitive techniques
  - 5 – Relaxation techniques

*1 – Sleep hygiene*

- These include things like keeping the room temperature cold in the mid-60s, even if you need to wear socks
- Keeping the room as dark as possible, and using an eye mask if that’s necessary
- Not drinking too much fluid after dinner to reduce the probability that you need to get up and pee at night
  - This means addressing prostate issues, if you’re a male
- It means getting rid of down comforters and heavy blankets which disrupt the circadian temperature rhythm
  - Remember, when we’re in bed, we’re supposed to get into bed and rapidly begin a process of cooling to get into our deepest sleep before we begin to warm a couple of hours before we wake up
  - She said anything with duvet in it should be banned
  - Basically anything that’s going to keep too much heat in is a bad idea

*2 – What is stimulus control?*

- Stimulus control means limiting the bed to only 2 things: sleep and sex
- Everything else happens somewhere else
- That means no phone, that means no reading
- The other thing she made a really clear point about was no worrying
  - And you might say, “*Well, who sets out to worry in bed?*”

> “*What she really means by that, and I think this is very important, is that you don’t want to spend time laying in bed awake*.”‒ Peter Attia

**⇒** So if you’re laying in bed and you’re awake, especially if you’re worrying, you need to get out of bed and do something else

- She talks about people who suffer from insomnia
- One of the important things you have to do is get them out of bed for 20-30 minutes to do something really low key
- She had a funny description: get out of bed and do something that you would be embarrassed if your colleagues at work saw you doing it
  - In other words, don’t get out of bed at 3 in the morning to go and work for 30 minutes
  - Get out of bed for 30 minutes to read a trashy magazine or watch some silly sitcom
  - Something that’s not really activating to allow yourself to get a little bit sleepy and then come back to bed

Peter rarely experiences insomnia, but not long after this podcast, he went through  couple of days when he jolted up at 2 or 3 in the morning and could not get back to sleep

- His inclination was to sit there and fight it
- Finally on the 3rd night, he was like, “*Why am I not just doing what Ashley said?*”
- He went out to the couch in the family room, threw down an episode of Silicon Valley
  - Which he talks about all the time
  - It’s one of the greatest shows of all time,
- Then, he just went back in and went to bed
- That’s an example of something that’s super low key that allowed him to get back to sleep

*3 – Time in bed restriction*

- This is something that can be really hard for people to wrap their heads around
- Previously people refer to this as sleep restriction (the name of that is obvious)

Why would you do such a thing?

- The problem is for many people with insomnia, they’re actually spending too much time in bed and their **sleep efficiency is really low**
- They’re spending a lot of time in bed because they’re tired because they’re not sleeping, and it becomes a vicious cycle
- Anybody who’s used a wearable for sleep or uses anything that measures sleep probably notices a calculation that gets spit out called sleep efficiency

**⇒** Sleep efficiency is time sleeping divided by time in bed

- You want to be able to hit at least 85%
- If you’re hitting 95%, you’re not giving yourself enough time in bed
- If you’re hitting 75%, you’re probably spending too much time in bed
- To restrict time in bed, you want to first understand your typical time asleep with a **sleep diary** and then you add a 30-minute buffer to get your target time in bed
- You can also determine the ideal wake-up time and base your time in bed off this wake-up time

**⇒** Getting your wake-up time right is key, and this is the thing that you want to be fixed

- Once your wake-up time is fixed, your bedtime starts to take care of itself
  - As you build up sleep pressure over time

***The more consistent your wake-up time is, even on weekends, the easier it is to control sleep hygiene***

- It’s understandable if you let your sleep schedule move on the weekends (and sleep in a lot later)

**⇒** The problem is that process of social jet lag is devastating for your circadian rhythm

Ashley describes focusing on **process S** (which is sleep pressure) to standardize what she calls **process C** (or circadian rhythm)

- We talked a little bit about **sleep trackers**: she does not recommend using them if you’re struggling with insomnia
  - Peter couldn’t agree more from his practice
  - When patients are struggling with sleep, we get them to take their sleep trackers and at best put them away, at worst, throw them out
  - Once this kind of gets in your head, it becomes a brutal cycle
  - You don’t need a sleep tracker to fix the problem

*4 – Peter found the discussion of cognitive techniques to be very interesting*

Schedule time for worrying

- For many people, the waking up part then triggers the set of ruminating thoughts
- Insomnia sometimes arises from not processing information enough during the daytime and spending too much time in bed ruminating

**⇒** She has her patients **schedule worry time** by intentionally putting something on the calendar where they literally write down all the things that they are worried about; they might have 20 minutes a day to do that, and then they don’t have to feel the need to process this at night

- During this time, you think about the things that you would normally think about laying awake in bed; and all of a sudden it gets a lot better

She does something called **tracking the degree of belief**

- This means asking yourself, “*How much do I believe this is true?*”
  - [ask yourself the same question at different times throughout the day]
- A lot of times people will find the things that seem absolutely certain in the evening may turn out to be unlikely during the day
- They just feel more certain of it before bed, which increases worrying

**Peter won’t go through all the other stuff**

- There’s some stuff she talks about on relaxation, which is helpful
- She also talked about A-B testing

*She talked about other things that are probably less effective*

- She wasn’t a huge proponent of blocking out blue light, but she said it’s always worth trying
  - If wearing red light or blue light glasses in the evening helps, by all means, great, give it a shot
- Obviously experimenting on timing of caffeine, medication, supplements all great, but her view is just to test those things out

**Did she talk about anything on sleep supplements, sleep prescription drugs that people should think about potentially using if they’re going through this?**

- She typically tries to get people off all sleep medications with the exception of [trazodone](https://en.wikipedia.org/wiki/Trazodone)
- She certainly shares Peter’s belief that trazodone is probably the best prescription sleep medication out there and the only one that she would consider for long-term use
- She doesn’t like people being on daily doses or nightly doses of [melatonin](https://en.wikipedia.org/wiki/Melatonin) or anything else
  - Peter agrees with this and reserves melatonin for jet lag and things of that nature

***Her view is you should really be able to do this without medication, perhaps with the exception of Trazodone***

## When to seek professional care for sleep issues [30:30]

**When do you recommend people start to get professional help as it relates to sleep?**

- When insomnia has been going on for a couple of months and you can’t work it out doing all these things

> “*In this podcast we outline so much more that I think will hopefully help people fix this on their own*.”‒ Peter Attia

- In this podcast she goes into much more detail on the strategy around sleep restriction
  - Peter is deliberately only covering it conceptually because the actual examples of this in the podcast (and show notes) are really where you can do this stuff on your own
- People should be able to troubleshoot a lot of this stuff on their own
- Peter refers out more to rule out sleep pathology like [apnea](https://en.wikipedia.org/wiki/Sleep_apnea) or [RLS](https://en.wikipedia.org/wiki/Restless_legs_syndrome) probably 3, 4, 5x more commonly than he’s referring to CBT-I

Peter emphasizes, “*We’ve had nothing but success with CBT-I for the patients who do the work.*”

- Some patients who just don’t want to do it, they don’t even want to get on the phone with the therapist
- But boy, the patients who go through this

*Peter recalls one patient in particular*

- A guy whose sleep was so destroyed that Peter was not sure this was going to get fixed
- Within 6 months this guy has normal sleep
- This stuff works

**This episode didn’t focus on** [**sleep apnea**](https://en.wikipedia.org/wiki/Sleep_apnea)**, and oftentimes people don’t know they have it. If you’re working with a patient and trying to figure out if they have sleep apnea, what are you having them do?**

- There’s a simple survey called the [Stop Bang survey](http://www.stopbang.ca/osa/screening.php), which anybody can find online
  - It asks 5 or 6 simple questions and gives you a probability score
    - If your spouse tells you that you’re snoring
- A lot of wearables will even suggest to you if it thinks you might have sleep apnea
- Any of these things that are suggestive and/or just the feeling of not being well rested

**⇒** If you have enough of the characteristics and you don’t feel well rested, that might be a reason to get evaluated for sleep apnea

- A lot of times when people have hypertension that might not be otherwise explained

***Peter has a pretty low threshold to refer out for a sleep study to look at apnea because it’s such a treatable condition, and the consequences of missing it are pretty high and the cost of ruling it out is pretty low***

## Sanjay Mehta episode: radiation therapy’s evolution, its underused potential in treating inflammatory conditions, and the cultural misconceptions surrounding radiation exposure [33:45]

[#343 – The evolving role of radiation: advancements in cancer treatment, emerging low-dose treatments for arthritis, tendonitis, and injuries, and addressing misconceptions | Sanjay Mehta, M.D.](https://peterattiamd.com/sanjaymehta/) (April 7, 2024)

\*\*\*

- Peter noticed that Nick didn’t mention that the last part of the podcast was all about cars

**One of the interesting things we talk about in this podcast is the very US centric radiophobia cultural milieu**

- It’s a very American thing to be very concerned with radiation and there are reasons for that:
  - Nuclear accidents, obviously Chernobyl and Three Mile Island being
  - The Radium Girls ‒ these were female factory workers who contracted radiation poisoning from painting radium dials onto watches
  - Then obviously just kind of the Cold War fears
- But if you actually look at the data
  - This is something Peter had looked into a lot before this podcast; this wasn’t the first time he got hit with this

**⇒** Very low or moderate dose exposures to radiation seem to be completely negligible in terms of long-term health risks and may be even beneficial through hermetic pathways

- It’s interesting is that this is a uniquely American issue
- We linked to a [podcast](https://creators.spotify.com/pod/show/radmed/episodes/The-Trilogy-of-Radiation-Supervision-Welcome-to-Modernity-e2conpk) in the show notes that tells more about this story

*The net of this is that*

- In the US, we think about radiation therapy as almost exclusively for the treatment of cancer
- But if we look to what’s going on in Europe (and especially in Germany), we see that low-dose radiation therapy for inflammatory conditions such as arthritis, tendonitis, bursitis, even plantar fasciitis, has been widely used for many years and produces remarkable results
  - And Sanjay himself has been doing a lot of this therapy
  - A lot meaning hundreds of cases, and he has seen really amazing results

**We begin this podcast by explaining all the different forms of radiation**

- From microwaves to cell phones, distinguishing between non-ionizing and ionizing
- Of course microwaves and cell phones are completely harmless despite what some people might tell you because they don’t have the energy to emit an electron
  - The next time someone tells you that you shouldn’t stand next to a microwave, you might have to give them a little bit of a physics lesson on what electrons are
- However, ionizing radiation (such as x-rays and ultraviolet light) have higher energy and can indeed damage DNA
  - That’s the type of energy that we were here to talk about

**We did a pretty thorough exploration of how radiation is used to treat cancers**

- Particularly breast cancer, prostate cancer, and brain cancer
- Peter came away from this realizing that the field has evolved so much in even the last 20 years, let alone the last 40 years, that it’s actually pretty remarkable

> “*Radiation is really a gift to patients today because it allows for much smaller surgeries where you can create much more local control of disease and actually use less toxic chemotherapy*.”‒ Peter Attia

*The one we probably talked about the most is prostate cancer*

- Right now radiation is really approaching surgery for cure rates with one big caveat, which is it requires androgen deprivation therap
- Peter probably still comes out on the side of surgery
  - He would take surgery over radiation for prostate cancer if both were offered because of the androgen deprivation therapy
- Peter hopes we learn over time which patients do and don’t need androgen deprivation therapy and for what period of time after surgery
  - In other words, today a patient could have his prostate removed and then go straight back to either you wouldn’t remove his androgens to begin with, or if they were low you could replace them
  - Whereas the patient undergoing radiation therapy would need to go androgen suppression
  - Eventually they could go back on replenishment, but there’s still a long period of time where they’re hypogonadal

**We talked a lot about whole brain radiation**

- The difference between intensity modulated radiation therapy where you can protect certain parts of the brain
  - Obviously there’s certain parts of the brain that are going to be much more susceptible to radiation
- How stereotactic radio surgery is now really the standard for this

**Sanjay went through doses of radiation**

- Why things like mammograms and dental X-rays are just so low in radiation that nobody should ever be avoiding these for fear of radiation
  - The risk of missing that cavity or that breast cancer or even [DCIS](https://en.wikipedia.org/wiki/Ductal_carcinoma_in_situ) far outweigh the risk of radiation

**The most interesting stuff was really diving into how we could use low-dose radiation**

- Using the same machines that are used to treat cancer patients
- Sanjay explained how low-dose radiation can be used to treat things like keloid scars and to treat Achilles tendonopathy, hamstring injuries, high hamstring tendonopathy, and the ischial tuberosity
- Low doses of radiation reduce the inflammation that is part and parcel with so many of these things
- This is not something that you’re going to see a lot of in the US because those machines are primarily being used for cancer treatment
- Sanjay in his practice in Houston has begun using some of his downtime to treat these patients for inflammatory conditions
- Peter is trying to talk him into moving to Austin
- Peter has sent 3 patients to him already
  - 1 with an Achilles injury, 1 with a high hamstring injury, and he forgot what the third one was

***This type of therapy really works and it’s certainly something Peter will personally keep in mind both for himself and his patients***

*The other interesting thing about this is you technically don’t need anywhere near the power of the machine to produce the radiation because you’re using lower doses than you’re treating in the case of cancer*

- Economically this is an easier thing to do
- It requires far fewer safety standards because the radiation is so low

> “*I’m just hopeful that at least in part due to this podcast, people are more and more interested in exploring this type of therapy as opposed to just sitting there endlessly suffering with plantar fasciitis for years*.”‒ Peter Attia

**Would low-dose radiation be effective for treating a broken bone in an adult (as a way to give you a little something extra for healing)?**

- Peter doesn’t think so because when a bone is repairing, you actually want the inflammation
  - The inflammation is part of the repair
- If you think back to the example of the keloid scar, you wouldn’t want to put radiation on a wound that’s healing because you actually need the inflammatory response to heal the tissue
- But if that response becomes so extreme (which is what a keloid is), that’s where the radiation becomes helpful

***The short answer about healing a bone is no, you wouldn’t want radiation***

- But if you found yourself in a situation where there was an enormous amount of deformation due to an overabundance of some sort of healing pathology then it could be helpful
  - Peter thinks this would be far more common in scars than it would be in bone

**You mentioned that radiation has come a long way as it relates to treating cancers. How much more is there to go?**

*Will this field continue to evolve, and do you think there’ll be even more applications?*

- That’s a really good question and one Peter wishes he had thought to ask Sanjay because he doesn’t know where the field is on this curve
  - He doesn’t know enough about what is holding the field back
- He would assume that the more radiation you can apply to tissue in a focused way without applying it to areas you don’t want to apply it to the better
- But he would also assume that at some point you are very limited by what even the local application can be

***Peter’s guess is it’s going to get better through more and more focused application of ionizing energy, but he doesn’t imagine that there’s a step function change in the field the way we could see a step function change in systemic therapy (i.e., chemotherapy)***

- There is still an opportunity through immunotherapy and chemotherapy to have a step function change in the treatment of cancer
- Peter’s not convinced based on the little bit he knows that we could see that in radiation therapy

## Peter’s predictions and insights for the upcoming Formula 1 season [43:15]

- We recorded this episode at the end of February when pre-season testing just happened
- The new season of [*Drive to Survive*](https://en.wikipedia.org/wiki/Formula_1:_Drive_to_Survive) comes out in a week
- The F1 season starts mid-March

**What are your predictions for the season knowing that by the time people listen a lot will have happened. But at the recording date, we’re still flying blind.**

- Peter thinks it’s going to be a 4 car season: McLaren, Ferrari, Mercedes and Red Bull will be a class above the other 6
- He thinks Williams takes a big step forward this year of the bottom 6
  - Both because he has enormous faith in James and also because of the arrival of Carlos
  - Now you’ve got two very good drivers, a brilliant team principal
  - It won’t be until 2026 that we could expect to see Williams take a step into the midfield, but they could leap to the front
- Peter doesn’t know if anything that Adrian’s been able to do at Aston is going to really play a role in this year
- He suspects that Adrian has been working on the 2026 car, so we might see more of the same at Aston
- Honestly, he just doesn’t hold out a lot of hope for the other 6 cars

**Where did the big 4 end last year?**

- We saw that the best car was the McLaren
- The second-best car was Ferrari
- Third-best car was Red Bull
- And Mercedes was not far behind in the fourth-best car
- If you look at form at the end of the season, Peter would argue that Mercedes was closing the gap much more than that

**What’s exciting for this year**

- Mercedes has taken an enormous gamble in bringing a very, very young 18-year-old rookie into the hot seat
- For people who don’t follow Formula 1, most people would agree (even though they don’t want to admit it), Max Verstappen is the generational talent of F1 today
- Peter was just on the phone with Damon Hill two days ago
  - Damon Hill, 1996 F1 World Champion
  - They were talking about Max and he was like, “Yeah, there’s just no denying it, whether you like him or not, whether you think he’s a good sport or not.”
  - Damon described him as a once in a two generation talent
- Max came into the sport at the age of 17, won his first race on his first drive with Red Bull after being in Toro Rosso for a very short period of time
- Most people would argue that that is an impossible formula to replicate, and yet Mercedes is going to try to do it with Kimi Antonelli

*When Peter thinks of all of the exciting storylines of this year, watching how Kimi progresses is going to be one*

- He’s met Kimi Antonelli ‒ amazing kid, so likable
- He’s going to root for this guy like you cannot believe
- But if Peter is being brutally honest, he doesn’t know what to expect
  - It’s so much pressure
  - He only had one season in Formula 2 and having never driven an F2 car or an F1 car
  - But having talked to many people who have, they’ve all told me that it is the biggest jump you will ever make
  - The electronics of the car, the pressure of the race weekend is such a big jump
- If anybody can handle it besides Max, it’s going to be Kimi
- It’ll be very interesting to see what happens at Mercedes
- Peter expects their car to be very good, and he suspects that Kimi has some really amazing races
  - But he’s going to probably make some pretty big mistakes and have some shunts
  - Peter predicts that he will win at least a race this year (which will be amazing)

*The biggest storyline of the year is Lewis going to Ferrari*

- Peter thinks their car is going to be really good and k it’s going to be exciting to see Charles and Lewis race
- Charles is so good in qualifying
  - Honestly, this is not a popular point of view because obviously Lewis is one of the most successful drivers in the history of F1
- It might be hard for Lewis up against Charles with how good Charles is at qualifying
- Now Lewis is really good at racing ‒ if you’re always starting behind your teammate you get into the Oscar Lando problem at McLaren (that’ll be interesting)
- Ferrari is a different culture
  - Lewis spent 10 years at Mercedes where he really understood that culture
  - Ferrari is totally different
- It’s not as dysfunctional an entity as it used to be, and it used to be a really dysfunctional place before Fred Vesser arrived
  - Every indication is that he’s made it a much better place
  - That’ll make it easier for Lewis than it would’ve been if he showed up 3 years ago
- But again, it’s going to make for really exciting racing

*Over at McLaren, Big year for Lando*

- Most people feel he let the championship slip away last year
- He had the better car, but he made too many mistakes when it counted most
- Ultimately Max was able to squeak out the championship despite being in the inferior car
  - Really worth people understanding just what that says about Max
  - Peter knows a lot of people don’t like Max (and he doesn’t understand why personally, he thinks he’s so incredible)

> “*What Max did in Brazil last year in an inferior car in the rain is why he’s the greatest driver of this generation*.”‒ Peter Attia

- People who don’t understand that or refused to accept that probably don’t understand the sport very well (and that’s fine)

***Peter would say would say Lando is the preseason favorite to win the championship this year***

- Unless something really dramatic has happened in the off season where Red Bull has figured out how to fix some of the aerodynamic issues that they had
- Because this is really what it came down to last year is McLaren at about the Miami race really figured out the arrow under this reg and Red Bull just took a step backwards and only through the ability of max were they able to keep it close and ultimately win
- Peter is such an Oscar Piastri fan

Peter asks, “*By the way is anybody still listening to this? Are you even here?*”

- Nick was just thinking to himself, “*How many times have we recorded these and let me ask questions. This might be the longest answer you’ve ever given to one question*.”
  - He didn’t tell Peter he was going to ask about F1 (this was just on the fly)
  - Peter mentioned the racing piece with Sanjay (it wasn’t in the notes)

Peter adds, “*Maybe in the show notes for this, we just let people know how much they need to skip this part. I don’t want people to not hear what we’re going to talk about with Sean Mackey and Sue and all that stuff.*”

- *Peter jokes, “*I’m giving a Ted Talk on F1 right now.”

**Peter is such an Oscar Piastri fan**

- The biggest issue right now between Oscar and Lando is Oscar is struggling in Q3, and that means he is consistently starting the race at a disadvantage based on his qualifying position
  - Lando is obviously an amazing driver
- Peter is really curious to see if this is the year he figures it out
- Remember, he’s only in his 3rd year coming up, so he’s had 2 year
- For the casual observer watching qualifying in Formula 1, it’s hard to appreciate what is required to get your dinger lap in Q3
  - Q3 is the third and final qualifying session for the 10 fastest cars
  - It’s one lap
  - That is the single most important lap you will do in the entire 4 days
  - You must get the tire temperature right, you must have the balance right in the car
  - You must have the battery perfectly charged when you cross the start line on that flying lap and you are taking all of the risk at every corner
  - You are at the limit of the tire every second of that lap, and that is an art
- That’s why Ayrton Senna, the greatest driver of all time, no one came close to his qualifying efficiency, pole position in over 40% of his starts
  - That’s a stat no race driver will ever come close to because that is truly the mark of exceptional demon speed
- If Oscar can get his Q3 performance on par with Lando, Peter thinks it’s going to be an insane battle within McLaren, and that team will not pick sides
- There will not be team orders unless it becomes clear that one of them is the favorite
- Lando’s gunning to win this year
  - The bookmakers probably have him as the favorite

**Over to Red Bull**

- Obviously Sergio out, Liam in
- Not sure what to expect
- Liam’s pretty young, hasn’t spent a lot of time in the car, but everything thus far looks like he’ll do okay
- Peter still thinks that entire team rides on Max
- It does seem in the offseason that the drama over at Red Bull has quieted down a little bit
- It seems that there’s been a truce between the warring factions, the Singapore side, the Austrian side, and between Helmut and Christian and Yoss
  - There seems to be at least an agreement that, hey, let’s not put knives in each other’s backs so that we can focus on trying to win this championship for a 5th time

***Peter thinks they’re not going to be in the best car and it’s just going to come down to scrappiness***

- He thinks Max will actually enjoy the challenge of having to be at his best
- He knows he sounds like a broken record, but he doesn’t think there’s anyone on the grid that’s actually quite at Max’s level right now in terms of the absolute dearth of mistakes that he makes
  - You go back to 2018 and 2019 when Max was young, he made mistakes
- He was always fast, he was wickedly fast, but it was just that he made mistakes here and there, and this is what we just don’t see anymore in Max
  - Even Max in 2021 was still making too many mistakes
  - He still won, but he was making mistakes

*Where in the last 2 years have we seen the greatest improvement in Max?*

- It comes down to: the mistakes aren’t getting made
- During Lewis’s dominant years, that was also the thing that I think that set Lewis apart: his unbelievable consistency

***What does Peter think is going to happen this year? He honestly doesn’t have a clue.***

Nick points out, “*Can we just appreciate that you just said, I would beg someone to ask me this question and then you just ask yourself that question so you could then answer it as you continued on the path.*”

**Back to prediction, and a first, second constructors prediction**

**⇒** First, second constructors, Peter is going to go with McLaren Ferrari

- Which is the same as last year for constructors
- The reason for that is as good as he thinks Kimi is and will be
- And even though he thinks that the Mercedes in 2025 will be better than it was in 2024 (and it was getting pretty good last year)
  - And obviously George is great

***Peter thinks it’s just going to be very hard to bet on our rookie being able to deliver consistent points, enough points for Mercedes to be in the top 2***

- Again, he could be completely wrong
- This is impossible stuff; the constructors is going to be tough
- Unless their Red Bull car is a total disaster
  - And that is possible
  - He just doesn’t think it’s going to happen

***He thinks it’s going to come down to Max and Lando again***

- Although he could spend another hour giving you a bunch of caveats
- It’s kind of a coin toss for Max and Lando for the drivers

***Then he thinks it’s McLaren Ferrari on the constructors***

- What really matters is next year having this discussion as we embark on the new regulation change

**Who is #1 in the driver at the end of the year? (You gave us the top 2)**

- Max won it last year in the 3rd-best car
- He won it because he got such a head start at the beginning of the year when he was indeed in the better car for the first 6 races

*There’s a long history of amazing drivers not winnin*g

- Ayrton Senna’s greatest season in driving was 1993
  - Anyone who objectively understands the craft will look at his entire 10-year career and say he was at his best in 1993, the year before he died
  - So he died at his peak
  - He was in an inferior car
  - He won some very big races that year, but didn’t win the championship
- Alain Prost driving the far superior Williams car won the championship

**⇒** So the best driver will always lose if their car is too many steps beneath the best car

***Peter will say Max***

- Not that max is the best driver
- He’s basically saying he doesn’t think the Red Bull will be 3 or 4 steps below McLaren
  - It might be only 1 step
  - And that’s a gap that Max with his ability can close

Peter predicts, “*I’ll go Max then Lando again, which is a very contrarian view I think for this year.*”

**You mentioned Damon Hill**

*For those who haven’t listened,* [*episode #86*](https://peterattiamd.com/damonhill/) *back from 2019, Peter sat down with* [*Damon*](https://www.formula1.com/en/information/drivers-hall-of-fame-damon-hill.5Cwo2Aog5nHCR1eduIkq3y)*, and it was really fascinating even if you don’t like or follow F1*

- Amazing episode
- It was so great to talk to Damon about his incredible career
- Peter could spend another hour just talking about Damon’s amazing career

## Sean Mackey episode: the neuroscience, classifications, and treatment strategies for chronic pain, and the importance of personalized care [57:45]

[#345 ‒ Chronic pain: pathways, treatment, and the path to physical and psychological recovery | Sean Mackey, M.D., Ph.D.](https://peterattiamd.com/seanmackey/) (April 21, 2025)

\*\*\*

- Talking about what pain is ‒ not necessarily intuitive

**Pain is not a signal from the body but an experience that’s influenced by many factors**

- It’s influenced by consciousness
  - If you’re unconscious, you don’t experience pain in the way that you would if you were conscious
  - That’s why we have anesthesia
- It’s influenced by your state of emotions and prior experiences
- There’s a physical stimulus and then there’s a how the brain processes it (or doesn’t process it)
- You can’t have pain without the conscious perception of pain

***Factors that contribute to the perception of pain: variability in genetics, psychological factors, the brain’s processing***

**We talk about the nerve fibers that transmit pain signal**

- It’s important to understand there’s something called a [nociceptor](https://en.wikipedia.org/wiki/Nociceptor), and that is a nerve fiber that transmits a pain signal
  - But nociception per se is not pain
  - Nociceptors are specialized transducers that convert different forms of energy related to potential injury into an electrochemical impulse
- If you think about what pain arises from
  - It can arise from pressure
  - It can arise from heat, cold
  - It can arise from a chemical change
- Any of these things are potential sources of energy, and they get transmitted into an electrochemical impulse
- These signals are transmitted up a nerve fiber
- You have some of them that go through what’s called an [Aδ](https://en.wikipedia.org/wiki/Group_A_nerve_fiber) fiber (that’s very fast) and a [C fiber](https://en.wikipedia.org/wiki/Group_C_nerve_fiber) (that is really slow)
- To illustrate the difference in these fibers: Have you ever been to a restaurant where the waiter brings you something and tells you not to touch the plate because it’s super hot?
  - Are you the idiot (like Peter) who still wants to touch it?
- You don’t have to think about pulling your hand off that plate ‒ that’s the Aδ fiber
  - It is an immediate response that is not even going to your brain for you to process
  - It’s going right up to the spinal cord and running out the motor unit
- In theory, the C fiber should be going to your brain where you’re going through the process of that so that you don’t do it again
- Peter shares, “*This is why only once as a child, did I ever stick my mother’s keys in the electrical socket. She had told me not to do it a million times, Nick. But as a very curious three-year-old, I just thought it looked really good to do until the day I finally did it. And I don’t even really have a memory of how bad I got shocked, but it’s amazing and that I never wanted to do it again after*.”
  - The Aδ fiber is what got him to let go of those keys
  - The C fiber is what made him realize, let’s not do that again

**There are different types of pain**

- 1 – **Nociceptive pain** is the pain that originates from the activation of these nociceptors
  - This is kind of think of sharp pain like stubbing your toe
- 2 – Another type of pain called **visceral pain**, which is also a form of nociceptive pain, but it’s really diffuse
  - If anybody listening to this has ever had appendicitis or an intersusception or even just like you have really, really bad GI upset where the parts of your bowel are swelling even just slightly, this is incredibly painful, but it’s actually kind of a diffuse pain
- 3 – Then you have **neuropathic pain**, which is caused by injury or dysfunction of a peripheral nerve or even a part of the central nervous system
  - Anybody who’s experienced this, and this is something that you might experience after you’ve had a disc herniation in either your neck or your back, is typically a burning, sharp, shock-like pain
- 4 – There’s actually another type of pain that’s kind of like “all else” pain that Peter hadn’t even heard of, called **nociplastic pain**
  - This is dysfunction in central processing without any identifiable peripheral cause
  - The example here is [fibromyalgia](https://en.wikipedia.org/wiki/Fibromyalgia)

**Another important concept: there’s no single pain center in the brain**

- Pain is generated by a distributed network of regions that work together
- You experience this in the thalamus, the anterior cingulate cortex, the insular cortex
  - The prefrontal cortex is also involved here
- A lot of this can be identified with functional MRI, and that can be used to predict pain and treatment outcomes

**The gate control theory of pain explains one way to reduce pain**

- This suggests that non-painful inputs can close these gates to painful inputs that prevent painful sensations from traveling to the CNS
- The example that we talked about was when you accidentally hit your thumb with a hammer by immediately applying pressure to your thumb, you actually reduce the pain
  - Anybody can relate to this because it’s something we do

> **“***One of the most important takeaways from this is to plan ahead for pain management.*”‒ Peter Attia

**Pain management**

- We talk a lot about how pain management has evolved in large part because of the over correction of the healthcare system and obviously the bad acting of some of the pharma system when it came to the over-prescription of opioids
- Sean does give a very nuanced response around opioids, which is also worth understanding

*Advice for meeting with a pain consultant*

- This is typically provided through the anesthesia service before surgery
- This meeting can be a very effective way to say, “*Hey look, I don’t want to be on opioids at all. Can we come up with a strategy for me to get through my perioperative period of time without too much pain, but without potentially risking exposure to opioids?*”

**⇒** This is especially important for an individual who has struggled with addiction (Peter can’t overstate the importance of this enough)

*Everybody responds really different to pain treatments*

- It’s important to know what works for you
- Understand that **chronic pain** requires a very personalized approach and that many people with chronic pain are going to have to go through several iterations before they find something that works
  - Therefore, if you’re 2 or 3 treatments in and it’s not working, don’t be discouraged
  - Keep seeking out the experts who are going to continue to work on novel approaches

*Effective treatments*

- 1 – The use of [NSAIDs](https://en.wikipedia.org/wiki/Nonsteroidal_anti-inflammatory_drug) can be very helpful in recovering from surgery along with [acetaminophen](https://en.wikipedia.org/wiki/Paracetamol)
  - If we’re trying to avoid opioids
- 2 – The use of [low-dose naltrexone](https://en.wikipedia.org/wiki/Low-dose_naltrexone) and even [tricyclic antidepressants](https://en.wikipedia.org/wiki/Tricyclic_antidepressant) can be very helpful in the management of pain along with gabapentin and pregabalin
  - These are not typical pain drugs, but boy, they can be really effective
- It all comes back to working with somebody who kind of understands pain and how to prescribe these things

*Non-pharmacologic strategies*

- Things like acupuncture and dry needling can be very helpful
- Peter has personally experienced a lot of pain relief through these things

Peter’s view is you still have to find out what’s at the root of the pain

- So if you’ve got tennis elbow, dry needling can help it, but you have to find out why you have tennis elbow
- You don’t want to really rely on any sort of pain strategy

**The story of how Peter and Sean met when Peter was in medical school was interesting**

- It’s cool to see that come full circle from that initial reaction to now Sean being on the podcast
- If anyone hasn’t listened to this episode, they definitely should

## Susan Desmond-Hellmann episode: how AI is revolutionizing medicine through advancements in drug development, biomarker discovery, and the potential of training models on private clinical data [1:05:45]

[#346: Scaling biotech and improving global health: lessons from an extraordinary career in medicine | Susan Desmond-Hellmann, M.D., M.P.H.](https://peterattiamd.com/susandesmondhellmann/)

\*\*\*

Peter explains, “*Sue’s one of these people who’s just had a remarkable career… you just talk about putting the right person in the right place at the right time.*”

- There are not many people who have experienced and done more than Sue has
- This was such a treat for Peter to understand that
- When Peter met Sue last year, it was in a pretty cool setting where he got to hear her talk
- Afterwards he went up to her and introduced himself, and he was surprised she knew who he was
- He just said, “*Hey look, I don’t know if you’ve ever been on a podcast before, but I’d love to have you on mine*.” And we just left it at that
  - She didn’t even say, “*What do you want to talk about?*”
  - Peter didn’t even know what he wanted to talk about
- This was a podcast where there wasn’t some huge amount of preparation ‒ Peter just wanted to go where the story went in her career
- We ended up talking a lot about oncology and AI
- She’s on the board of [OpenAI](https://openai.com/our-structure/#:~:text=results%20with%20everyone.-,Our%20board,-OpenAI%20is%20governed)
- We talked about ways that AI is going to impact medicine, and what it’s doing already
- We riffed on some cancer stuff that Peter thought was interesting

**Walk people through some ways that Sue thinks that AI can make a big improvement as it relates to medicine**

- Last fall, the [Nobel Committee](https://www.nobelprize.org/prizes/chemistry/2024/press-release/) recognized an enormous AI breakthrough in protein folding
  - [AlphaFold](https://deepmind.google/technologies/alphafold/) in addition to another scientist outside
  - That was a really big deal
  - We talked about that previously on the podcast [[episode #323](https://peterattiamd.com/fengzhang/#:~:text=solution%20called%20AlphaFold2-,AlphaFold2,-is%20an%20AI)], where AI was able to predict just from an amino acid sequence what the secondary, tertiary, quaternary structure of a protein would look like

**⇒** That’s an enormous deal because now you can really, really shortcut the period of time between figuring out what amino acids you need to make a protein that’s shaped in a certain way to fit perfectly into a receptor

*Peter puts this in perspective, explaining the role in drug development*

- This is step zero
- This is preclinical, figuring out what molecules are even pursuing
- There’s so much left to do
- We still need to evaluate outcome measures

**One of the things that we talked about in light of Sue’s extensive experience with HIV was that it’s easy to forget why the treatment for HIV was so successful**

- In the mid-90s with the introduction of what’s called [HAART therapy (highly active antiretroviral therapy)](https://en.wikipedia.org/wiki/Management_of_HIV/AIDS), basically within a span of a year took HIV from being a lethal condition to a chronic condition
- It was very predicated on having an exceptional **biomarker called viral load** that you could measure
- This is how you could measure the effectiveness of therapy without having to wait years to see if the thing actually worked based on survival
- Imagine if we didn’t have viral load, and we had to test all of these different drugs on patients with HIV
  - Wait 5-10 years to see which ones progressed to AIDS and which ones didn’t
  - We might still be in the dark ages of that disease
- But by having viral load right away, having a biomarker, scientists were able to very quickly figure out this worked, this didn’t

***Imagine if we could do that with cancer, with Alzheimer’s disease***

> “*I think that’s one of the most important things that I would hope AI is going to bring from a basic and translational science approach to medicine*.”‒ Peter Attia

**Other areas of medicine where AI can help**

- AI help us design better experiments
- AI can help us analyze data better

**Peter thinks a lot about this biomarker thing**

- The holy grail of this would be all-cause mortality and so-called “longevity biomarkers” (which we clearly don’t have)

***We don’t have any biomarkers for geroprotection, and if we did it would be a total game changer for human health and civilization***

**Where has your mind changed the most as it relates to AI and its potential for advancements in medicine based on the growth of AI in the last year or two?**

- What’s impressed Peter the most is the rate of change of AI
  - It’s the first and the second derivative (the rate of change and the rate of rate of change)
  - They’re both higher than he would’ve ever predicted when it started out
- Peter remembers when the first version of [ChatGPT](https://en.wikipedia.org/wiki/ChatGPT) came out
  - He was so unimpressed with it
  - Yeah,  it did a lot of cool stuff, but he could stump it all day every day
    - Why is this not that good?
  - This was still long after the development of the transformer, so you’d had that huge step forward
- When he plays with [ChatGPT](https://chatgpt.com/) today (or [Grok](https://x.ai/)), he’s pretty impressed

When Peter looks at how quickly it got there, he thinks, “*Where is it going to be in two years? Where’s it going to be in four years?… That’s a big part of where I’ve changed my mind.*”

**Another thing is believing now that we will be able to train AI agents on non-public data**

- People who follow AI are familiar with the idea that most publicly available data has already been incorporated into what we see in these chatbots
- But public data is a real small fraction of the total data that’s available out there

*Let’s use Peter as an example*

- There’s a lot of publicly available Peter data
  - You’ve got hundreds of podcasts, thousands of hours of him speaking in public
  - Millions of words written between newsletters, books and stuff like that
- If you said, here is all the public data of Peter, let’s train an AI agent on that, would you get a pretty good AI agent?
  - Yeah, probably better than what you would for most people, because most people don’t have as much public data of them out there

***What’s occurred to Peter is how valuable the private data is***

- In other words, if you were training an AI agent on everything Peter was saying, you’d learn 10x faster
  - In every internal meeting that he was having
  - In every patient discussion he was having
  - Because that’s really where Peter’s learning at his most as an example, right?
- Last week, Peter and one of his docs ran a couple of their hardest cases by Ralph DeFranzo
  - [He was the guest on [episode #337](https://peterattiamd.com/ralphdefronzo/)]
  - That’s 45-60 minutes of going through these labs and talking about these super, super nuanced aspects of truly cutting edge thinking on stuff that’s private
- But you can train an AI on that ‒ there’s very easy ways to contain that and train

>  “*I would say that my mind has been blown as I’ve realized what is actually inclusive in the training set of data and what we could, because this isn’t just true for Peter (it’s very true for Peter), but it’s very true for every doctor. We could be training AI agents on far more nuanced interactions.*”‒ Peter Attia

## More from Susan Desmond-Hellmann: why cancer is so difficult to treat with drugs, the promise of immunotherapy, and the long-term hope for systemic treatments [1:14:00]

- Right after Peter’s residency, he spent some time at the National Cancer Institute
  - If anyone wants to know more on that, the podcast with Steve Rosenberg [[episode #177](https://peterattiamd.com/stevenrosenberg/)] is really good
- He knows this area pretty well based on his work there
- In [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=3TBRWCCK9TRF7&dib=eyJ2IjoiMSJ9.o13kqcTHfhfBoNSJ5Lib3jJG5BmkAW1UwtP4utZ8-JlApx6h7360AFBmrMErIWYkg5OpM17KdMOdLdFwSKbsSikjVz2rFFYhLuryRPE8AUdJZIuhJBF6Asq1lnJs-Rqd6rvPrsNCn6wAHKMizS20TUE9kRfVCn_p_zk5PF7nmpmfMN_1Fp728J5-Ba_htIHWSisEWhVk1FTvs4BHGzbYhGJz8BuWUmK4vvE9eoZ2V9A.-J2CFRTAp7bA05pBWh7JIRKk02cP9yY8O2RkNgzEMNc&dib_tag=se&keywords=outlive+peter+attia&qid=1743434479&sprefix=outli%2Caps%2C96&sr=8-1), Peter talked about how the rate at which we’ve come up with drugs to “cure cancer” has not progressed much in recent decades (since the initial “war on cancer”)
- Sue talked a little bit about how it’s hard for these drugs, because even if you have breast cancer, you can have all these different nuances where it almost makes it impossible

**Walk through (in simplest terms) why creating drugs and creating “cures to cancer” to date has been so hard**

 1 – It’s not a single disease

- There are features that are similar across all cancers
  - Mutation
  - Uncontrolled cell growth that is no longer responsive to normal cell signaling
  - Most cancers acquire the ability to leave the site of origin, metastasize to another site and take up residence there
    - Not all cancers, because for example, brain cancers don’t do that
    - Probably because of a blood-brain barrier, brain cancers end up just staying there
    - Peter doesn’t really know why a [GBM](https://en.wikipedia.org/wiki/Glioblastoma) doesn’t spread to the lungs
- It turns out that treating based on the knowledge of those things has proved illusory
- We don’t have an anti-metastatic drug
  - We don’t have a drug that prevents metastasis of colon cancer, prostate cancer, breast cancer
  - Because frankly, we don’t even understand why it’s happening
- Instead, what we have to humbly appreciate is: colon cancer, breast cancer, and prostate cancer don’t have a lot in common (outside of the features that Peter just mentioned)

2 – Even within the same histology (like breast cancer, all coming from breast tissue), there is so much variability

- The deeper you go, the more variability you see
- You might start with it’s all ductal breast cancer
  - Then we can classify them by hormone receptor sensitivity, and that offers some treatment opportunity
- But we know those things can change ‒ they can acquire mutations that can change that
  - Peter had a friend whose breast cancer started out as estrogen receptor positive and it then became estrogen receptor negative after many years

*Outstanding questions*

- What does that mean? What does that tell us about that cancer?
- How deep do we need to go into the types of mutations it has to really define it?
- How many cancers are genetically the same?
- When we’re dealing with the genetic disease, how important is it that we stratify treatments across genetic similarity?

> “*Part of the problem is that even when you identify a treatment for a cancer, that cancer is always evolving*.”‒ Peter Attia

- In Peter’s podcast with Bob Gatenby [[episode #181](https://peterattiamd.com/robertgatenby/)], he talks about this pulse-push treatment for cancer
  - His argument is basically, look, we might be thinking about this incorrectly in that we might need to think about calling a truce with cancer
  - Which is creating more the HIV model of how do we get cancer into an equilibrium where we get a low enough burden of cancer
    - We never try to eradicate it
    - We just try to live with cancer as long as possible
    - Just like a person today can live a completely normal life with HIV, we’re not trying to eradicate the virus
    - As long as you keep the viral load very low, you’re never going to progress to AIDS, you’re going to be just fine

***It might be that in this desire to push cancer to complete and total eradication, we spur the mutations that ultimately become unmanageable because there are no treatments that can address them***

- The one exception to this is [immunotherapy](https://en.wikipedia.org/wiki/Cancer_immunotherapy)
  - This appears to be the only systemic treatment outside of a few edge cases like certain types of testicular cancers and things like that, where solid organ or epithelial tumors are indeed fully responsive to a systemic therapy in a durable way
  - Peter thinks that speaks to the marvel of the immune system
  - He remains optimistic that immunotherapy is indeed the future of oncology

**Peter’s prediction on advancements in cancer treatment**

- Peter doesn’t think advances in surgery or radiotherapy are going to be what changes

***It’s going to be advances in early detection, and it’s going to be advances in systemic therapy that are going to bend the curve in oncology (he hopes this is in our future***)

*Within systemic therapies, he really believes it’s going to be immunotherapy*

- It’s going to be doing a better job identifying those 80% of epithelial solid organ tumors who produce antigens that are recognizable as non-self by the immune system
- It’s going to be creating a way to amplify those T-cells such that they can attack and destroy permanently the cancer cell without causing collateral damage of attacking and destroying normal cells

*Tying it back to AI, where does AI help in that process?*

- That’s something Peter hasn’t explored deeply enough, so he’s not sure
- But he’s positive that there are people using AI to solve that as well

**If you look at immunotherapy advances, how long is that for us to understand how impactful it can be?**

- Immunotherapy tends to be quite binary: it either works or it doesn’t
- You find out pretty quickly
- There are times when of course it works, but the side effects are too severe
  - So the immunotherapy is doing a great job eradicating the cancer, but it’s also destroying normal tissues
  - And depending on the tissues, that might be acceptable
  - For example, if it’s destroying the melanocytes of the skin, giving you [vitiligo](https://en.wikipedia.org/wiki/Vitiligo), that’s okay, keep at it
  - If it’s destroying your pancreas, you’d probably tolerate it because you could just go on insulin for the rest of your life, if the choice is dying of cancer
  - If it’s eradicating your liver, your lungs, your small bowel, unfortunately we have to stop the therapy no matter what
- That’s the state of the art with checkpoint inhibitors, which are the most successful, broadly applicable immunotherapies
- But there’s still cell therapy ‒ we talked about [CAR-T cells](https://en.wikipedia.org/wiki/CAR_T_cell) on the [podcast with Steve Rosenberg](https://peterattiamd.com/stevenrosenberg/) (very successful for B cell lymphomas)

*The question is*

- Can we expand the efficacy of CAR T therapy to breast cancer?
- Can we expand it to colon cancer?
- Can we expand it to these far more common solid organ cancers?

Peter is optimistic that we will expand the efficacy of CAR T cell therapy, adding, “*I don’t know if it’s going to happen in the next 10 years, but I think it’s going to happen*.”

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Jeff English**: [#339 – Unpacking trauma: How early wounds shape behavior and the path toward healing | Jeff English](https://peterattiamd.com/jeffenglish/) (March 10, 2025) | [3:00]

**Episode of** ***The Drive*** **with Ashley Mason**: [#341 – Overcoming insomnia: improving sleep hygiene and treating disordered sleep with cognitive behavioral therapy for insomnia | Ashley Mason, Ph.D.](https://peterattiamd.com/ashleymason/) (March 24, 2025) | [14:00]

**Episode of** ***The Drive*** **with Sanjay Mehta**: [#343 – The evolving role of radiation: advancements in cancer treatment, emerging low-dose treatments for arthritis, tendonitis, and injuries, and addressing misconceptions | Sanjay Mehta, M.D.](https://peterattiamd.com/sanjaymehta/) (April 7, 2024) | [24:15]

**Episode of** ***The Drive*** **with Sean Mackey**: [#345 ‒ Chronic pain: pathways, treatment, and the path to physical and psychological recovery | Sean Mackey, M.D., Ph.D.](https://peterattiamd.com/seanmackey/) (April 21, 2025) | [41:00]

**Episode of** ***The Drive*** **with Susan Desmond-Hellmann**: [#346 ‒ Scaling biotech and improving global health: lessons from an extraordinary career in medicine | Susan Desmond-Hellmann, M.D., M.P.H.](https://peterattiamd.com/susandesmondhellmann/) (April 28, 2025) | [52:15]

\*\*\*

**The Bridge to Recovery, residential treatment center**: [The Bridge to Recovery](https://www.thebridgetorecovery.com/) | [12:15]

**PCS counseling center**: [PCS Psychological Counseling Services](https://pcsintensive.com/) | [12:30]

**Sleep apnea screening questionnaire**: [STOP-Bang Questionnaire](http://www.stopbang.ca/osa/screening.php) (2025) | [23:30]

**Episode of** ***The Drive*** **with Damon Hill**: [#86 – Damon Hill: Overcoming loss, achieving success, and finding one’s identity](https://peterattiamd.com/damonhill/) (December 30, 2019) | [40:15]

**Episode of** ***The Drive*** **that discussed AlphaFold (after [1:00:15])**: [#323 – CRISPR and the future of gene editing: scientific advances, genetic therapies, disease treatment potential, and ethical considerations | Feng Zhang, Ph.D.](https://peterattiamd.com/fengzhang/) (October 28, 2024) | [48:00]

**Episode of** ***The Drive*** **with Ralph DeFronzo**: [#337 – Insulin resistance masterclass: The full body impact of metabolic dysfunction and prevention, diagnosis, and treatment | Ralph DeFronzo, M.D.](https://peterattiamd.com/ralphdefronzo/) (February 24, 2025) | [51:45]

**Episode of *The Drive* with Steven Rosenberg**: [#177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancer](https://peterattiamd.com/stevenrosenberg/)s (September 27, 2001) | [52:30, 54:45]

**Episode of *The Drive* with Robert Gatenby**: [#181 – Robert Gatenby, M.D.: Viewing cancer through an evolutionary lens and why this offers a radically different approach to treatment](https://peterattiamd.com/robertgatenby/) (October 25, 2021) | [54:45]

---

## People Mentioned

- [Jeff English](http://jeffenglishgrit.com/)

- [Ashley Mason](https://osher.ucsf.edu/patient-care/patient-care-team/ashley-mason)
- [Sanjay Mehta](http://drsanjaymehta.com/)
- [Sean Mackey](https://seanmackey.people.stanford.edu/)
- [Susan Desmond-Hellmann](https://history.library.ucsf.edu/desmond_hellman.html)
- [Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill)
- [Feng Zhang](https://www.broadinstitute.org/bios/feng-zhang)
- [Ralph DeFronzo](https://directory.uthscsa.edu/academics/profile/defronzo)
- [Steven Rosenberg](https://en.wikipedia.org/wiki/Steven_Rosenberg)
- [Robert Gatenby](https://peterattiamd.com/robertgatenby/)