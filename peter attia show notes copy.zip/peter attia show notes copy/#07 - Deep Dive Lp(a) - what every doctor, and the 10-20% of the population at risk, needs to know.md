# #07 – Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know

**Source:** [https://peterattiamd.com/lpa/](https://peterattiamd.com/lpa/)

---

This is our first “deep dive” episode that goes into detail on one topic. Pronounced, el-pee-little-a, this lipoprotein is simply described as a low-density lipoprotein (LDL) that has an apoprotein “a” attached to it…but Lp(a) goes far beyond its description in terms of its structure, function, and the role that it plays in cardiovascular health and disease. Affecting about 1-in-5 people, and not on the radar of many doctors, this is a deep dive into a very important subject for people to understand.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

#### **\* If you would like us to do a deep dive on a particular topic, please submit your request to the comments section of this post. Please look at the existing comments before posting, and “upvote” the topic (or topics) you want us to cover. \***

![The Peter Attia Drive](images/lpa/the_Drive_public.png)

Play

#07 - Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know

#07 - Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know

1x15s30s

0:001:16:09

Note: this podcast gets technical at times. The figures in the show notes are your friends. They truly speak more than a 1,000 words apiece. I can’t emphasize enough how helpful it is to look at the figures before, during, and/or after I try verbally walk you through things like kringle repeats, molecular weight isoforms, lysine-binding domains, and plasminogen homology, as a few examples. If you stick with it, I think you will be rewarded.

## We discuss:

- A quick primer on lipoproteins [7:30];
- Intro to Lp(a) [11:00];
- Lab tests for Lp(a) and reference ranges [20:00];
- The physiologic functions of Lp(a) [31:00];
- The problems associated with high Lp(a) [34:15];
- Lipid-lowering therapies of Lp(a) [44:45];
- Lp(a) modification through lifestyle intervention [1:00:45];
- High LDL-P on a ketogenic/low-carb-high-fat diet [1:05:30]; and
- More

§

## Show Notes

##

## A quick primer on lipoproteins [4:30]

- What standard lab tests tell you (and what they don’t)
- The difference between lipoproteins and cholesterol
- The functions of lipoproteins and cholesterol

![](https://peterattiamd.com/wp-content/uploads/2018/07/Lp-a-isoform-variability.jpg)

**Figure 1. Apo(a) isoform variability on Lp(a) particles.** Image and illustration credit: [Tom Dayspring](https://twitter.com/Drlipid).

![](https://peterattiamd.com/wp-content/uploads/2018/07/figure-lpa-molecule-lpcaredotcom.jpeg)

**Figure 2. Lp(a).** Lipoprotein(a) is composed of an LDL-like particle and an additional apolipoprotein called apolipoprotein(a) [apo(a)] that is bound to apolipoprotein B (apoB) by a disulfide bridge. Image and caption credit: [lpacare.com](https://lpacare.com/).

## Intro to Lp(a) [11:00]

- What makes Lp(a) different than LDL
- Kringle domains and homology to plasminogen
- The functions of lipoproteins and cholesterol

## Lab tests for Lp(a) and reference ranges [20:00]

- Lp(a) mass
- Lp(a)-C
- Lp(a)-P
- apo(a) isoform mass (not commercially available)
- Two SNPs identified for high Lp(a)
  - rs10455872 (G is the affect allele)
  - rs3798220 (C is the affect allele)
- oxPL (normalized for apoB)

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-1-tsimikas-2017.png)

**Figure 3. Composition of Lp(a). Examples of different apo(a) “tail” lengths.** Lipoprotein [Lp(a)] is composed of apolipoprotein B-100 (apoB-100) covalently bound to apolipoprotein (a) [apo(a)], which is derived from kringle IV (KIV) and KV, and the protease domain of plasminogen. Plasminogen has 1 copy each of KI to KV and an active protease domain. Apo(a) contains 10 subtypes of KIV repeats, composed of 1 copy each of KIV1, multiple copies of KIV2, and 1 copy of KIV3-10, KV, and an inactive protease-like (P) domain. In these examples, apo(a) isoforms of 4, 8, 24, and 40 KIV2 repeats are shown, representing 13, 17, 33, and 49 total KIV repeats. Oxidized phospholipids (OxPL), represented here by 1-palmitoyl-2-oxovaleroyl-sn-glycero-3- phosphocholine (POVPC), are present covalently bound to apo(a), and also dissolved in the lipid phase of apoB-100. Image and caption credit: [Tsimikas, 2017](https://www.ncbi.nlm.nih.gov/pubmed/28183512).

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-1-tsimikas-2007.png)

**Figure 4. Association of Lp-PLA2 and oxPL with Lp(a) in normal plasma as well as in plasma of patients with CAD.** Image and caption credit: [Tsimikas et al., 2007](https://www.ncbi.nlm.nih.gov/pubmed/17626905).

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-3-tsimikas-2007.png)

**Figure 5. Scavenging (binding) of oxPL by Lp(a) and detoxification (degradation) of oxPL by Lp(a)-associated Lp-PLA2.** Image and caption credit: [Tsimikas et al., 2007](https://www.ncbi.nlm.nih.gov/pubmed/17626905).

**A**

![](https://peterattiamd.com/wp-content/uploads/2018/07/kiechl-fig-oxplapob-lpa-lp-pla2-A.png)

**B**

![](https://peterattiamd.com/wp-content/uploads/2018/07/kiechl-fig-oxplapob-lpa-lp-pla2-B.png)

**Figure 6. Relationship between OxPL/apoB (A) and Lp(a) (B) tertile groups and CVD risk according to tertiles of Lp-PLA2 activity (P=0.018 and P=0.008 for interaction of OxPL/apoB and Lp(a), respectively).** Image and caption credit: [Kiechl et al., 2007](https://www.ncbi.nlm.nih.gov/pubmed/17541022).

## The physiologic functions of Lp(a) [31:00]

- Wound repair (from childbirth to acute damage throughout life): hypercoagulability
- Acute phase reactant
- Amazing scavengers (scooping up oxPL: see Figure 5)
- The problem might be one of environment: we moved from acute inflammation and oxidative stress (effects of Lp[a] may confer an advantage) to chronic inflammation and oxidative stress (effects of Lp[a] may become problematic)

## The problems associated with high Lp(a) [34:15]

- Increased risk associated with more atherosclerosis, aortic stenosis, and venous thrombosis with high Lp(a)
- Are high levels of Lp(a) the result of atherosclerosis and not the cause? Lp(a) levels can go up post-MI
- In other words, is Lp(a) a big member of the damage response team?
- The relative and absolute risks for atherosclerosis, aortic stenosis, and venous thrombosis

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-2-tsimikas-2017.png)

**Figure 7. The atherogenicity of Lp(a) can be broadly classified in 3 categories: proatherogenic, proinflammatory, and potentially antifibrinolytic.** The major individual mechanisms within each category are listed. EC = endothelial cell; IL = interleukin; MCP = monocyte chemoattractant protein; PAI = plasminogen activator inhibitor; SMC = smooth muscle cell; TFPI = tissue factor pathway inhibitor. Image and caption credit: [Tsimikas et al., 2007](https://www.ncbi.nlm.nih.gov/pubmed/17626905).

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-central-tsimikas-2017.png)

**Figure 8. Lp(a) cutoffs signifying increased CVD risk and effect of therapeutic agents in achieving these targets.** Image and caption credit: [Tsimikas, 2017](https://www.ncbi.nlm.nih.gov/pubmed/28183512).

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-1-noma-1994.png)

**Figure 9. Typical patterns of time sequence of plasma interleukin 6 (IL-6), C-reactive protein (CRP), α1 antitrypsin (α1-AT) and Lp(a) levels in a patient with abdominal aortic aneurysm subjected to surgical operation.** Image and caption credit: [Noma et al., 1994](https://www.ncbi.nlm.nih.gov/pubmed/7514505).

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-2-noma-1994.png)

**Figure 10. SDS-PAGE patterns of nine plasma samples (Apo[a] isoforms in serum) taken on the day indicated from an AMI patient with Lp(a) double-band phenotype.** Image and caption credit: [Noma et al., 1994](https://www.ncbi.nlm.nih.gov/pubmed/7514505).

## Lipid-lowering therapies of Lp(a) [44:45]

- Apheresis
- Niacin
- Statins
- PCSK9i
- Menopausal Hormone Therapy
- Antisense oligonucleotides (ASOs)

#### **Niacin**

[UptoDate on niacin](https://www.uptodate.com/contents/low-density-lipoprotein-cholesterol-lowering-with-drugs-other-than-statins-and-pcsk9-inhibitors?sectionName=NICOTINIC%20ACID%20(NIACIN)&topicRef=4566&anchor=H3691238451&source=see_link#H3691238451): “Niacin lowers lipoprotein(a) (Lp(a)) levels by an average 25 percent [[Stein and Raal, 2016](https://www.ncbi.nlm.nih.gov/pubmed?term=26861250)], and thus it is used for patients with Lp(a) excess and hypercholesterolemia who have elevated LDL-C levels on treatment with maximum tolerated statin therapy plus ezetimibe [[Stein and Raal, 2016](https://www.ncbi.nlm.nih.gov/pubmed?term=26861250)].”

[Kotani et al., 2016](https://www.ncbi.nlm.nih.gov/pubmed/27173621): “Both the American Heart Association (AHA) / American Stroke Association (ASA) and the European Society of Atherosclerosis (EAS) guidelines recommended 1–3 g nicotinic acid (niacin, vitamin B3) daily for the treatment of increased Lp(a) concentrations ([Nordestgaard et al., 2010](https://www.ncbi.nlm.nih.gov/pubmed/20965889); [Goldstein et al., 2011](https://www.ncbi.nlm.nih.gov/pubmed/21127304); [Kotani et al., 2017](https://www.ncbi.nlm.nih.gov/pubmed/26980774)).

“In a randomized, crossover trial of 12-weeks, it has also been reported that extended-release niacin (1–2 g) daily may be effective to reduce Lp(a) concentrations via reducing apo(a) and apoB100 production in statin-treated men with type 2 diabetes mellitus ([Ooi et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/26515419)).

“A simvastatin–niacin combination was found to be effective to reduce Lp(a) concentrations up to 21%, but such a reduction was not associated with lower CVD events in the Atherothrombosis Intervention in Metabolic Syndrome with Low HDL/High Triglycerides: Impact on Global Health Outcomes (AIM-HIGH) study ([Albers et al., 2013](https://www.ncbi.nlm.nih.gov/pubmed/23973688)).

“Another recent 24-week, prospective, open-label clinical trial evaluated the impact of extended-release (ER) niacin on plasma Lp(a) concentrations in function of apo(a) phenotype ([Artemeva et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/25936305)). Indeed, high-dose ER niacin decreased plasma Lp(a) concentrations only in male subjects with low-molecular-weight apo(a) phenotype ([Artemeva et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/25936305)). However, different adverse effects have been noticed in clinical practice through increased production of prostaglandin D(2) and E(2) after niacin therapy that limits the widespread use of this drug ([Lippi and Targher, 2012](https://www.ncbi.nlm.nih.gov/pubmed/22276844)).”

#### **Statins**

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-8-tsimikas-2017.png)

**Figure 11. Demonstration of increased risk of events in patients with elevated Lp(a) and on statin therapy in the AIM-HIGH, LIPID, and JUPITER trials.** Image and caption credit: [Tsimikas, 2017](https://www.ncbi.nlm.nih.gov/pubmed/28183512).

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-9-tsimikas-2017.png)

**Figure 12. Effect of statin therapy on oxPL-ApoB and Lp(a)**. Image and caption credit: [Tsimikas, 2017](https://www.ncbi.nlm.nih.gov/pubmed/28183512).

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-take-home-pirillo-2018.png)

**Figure 13. Possible mechanisms of statins and monoclonal antibodies (mAbs) against PCSK9 on Lp(a) metabolism.** The LDLR seems to be involved in Lp(a) catabolism, but other receptors may also play a role. (A) Under physiological conditions, LDLR surface expression is regulated by the content of intracellular cholesterol and the amount of extracellular PCSK9. (B) Statins reduce cholesterol biosynthesis, leading to the up-regulation of both the LDLR and PCSK9. LDL-C levels are decreased. Under this condition, the LDLR is not available for a lower affinity binding with Lp(a) as it is mainly engaged in the removal of LDL. Other receptors possibly involved in Lp(a) uptake might be controlled by PCSK9. The increased levels of PCSK9 may lead to an increased formation of PCSK9–Lp(a) (and/or LDL) complexes. (C) In the presence of anti-PCSK9 mAb, extracellular PCSK9 is sequestered; thus, LDLR is recycled to the surface and available for new binding. The reduction of PCSK9 reduces the production of Lp(a) particles through several mechanisms. Lp(a)–PCSK9 complexes may be recognized by the anti-PCSK9 mAb, promoting an alternative removal pathway. (D) In the presence of statin and mAb to PCSK9, both LDLR expression and recycling are increased, leading to a massive reduction of LDL particles. This increases the number of free LDLRs, which are thus available for low affinity binding with Lp(a), leading to an increased Lp(a) uptake. Other receptors may contribute to removal of Lp(a). Image and caption credit: [Pirillo and Catapano, 2018](https://www.ncbi.nlm.nih.gov/pubmed/29868825).

**Statins work via two mechanisms. Direct and indirect.**

**Direct**. They inhibit HMG CoA reductase, which is an enzyme that catalyzes one of the early steps in cholesterol synthesis. If you’re making less cholesterol, you have less cholesterol to carry around, and therefore have fewer lipoproteins to transport it.

**Indirect**. The main way it works. The liver, in response to the statin, upregulates SREBP2 (sterol regulatory element binding protein). When this gets upregulated, it puts more LDLRs on the surface of the liver. It basically says, hey, the liver’s getting less cholesterol, and it wants more cholesterol, so I’m going to put more of these LDLRs on my surface to pull more cholesterol in.

#### **PCSK9 Inhibitors**

One of the other things that SREBP2 does is, it actually produces more PCSK9. PCSK9 is a protein that degrades more LDLR. So it’s a check and a balance. You have more LDL clearance because of more LDLRs. But you also speed up the rate in which those LDLRs are degraded (by PCSK9). … The net is an enhanced clearance of the LDL particle (the apoB particle) and therefore a lowering of the LDL cholesterol.

But it doesn’t lower Lp(a). Why wouldn’t the LDLR clear the Lp(a)? If LDLR clears Lp(a), it should go down. The reality is Lp(a) can and will get cleared by LDLR, but it’s the last in line. Behind the LDLs, in particular.

If you combine a statin with a PCSK9i, you see a reduction in Lp(a), and that’s what the [Pirillo and Catapano (2018) paper](https://www.ncbi.nlm.nih.gov/pubmed/29868825) showed. (PCSK9i alone, lowers Lp[a].)

#### **Menopausal Hormone Therapy**

[UpToDate](https://www.uptodate.com/contents/lipoprotein-a-and-cardiovascular-disease?search=Lp(a)&source=search_result&selectedTitle=1~150&usage_type=default&display_rank=1): “Estrogen replacement therapy (ERT) reduces Lp(a) levels by up to 50 percent [[Sacks et al., 1994](https://www.ncbi.nlm.nih.gov/pubmed?term=8185424); [Kim et al., 1996](https://www.ncbi.nlm.nih.gov/pubmed?term=8694668)], an effect that was somewhat mitigated by concomitant progesterone therapy in some reports [[Sacks et al., 1994](https://www.ncbi.nlm.nih.gov/pubmed?term=8185424); [Kim et al., 1996](https://www.ncbi.nlm.nih.gov/pubmed?term=8694668); [Grodstein et al., 1996](https://www.ncbi.nlm.nih.gov/pubmed?term=8672166)] but not the PEPI trial [[Espeland et al., 1998](https://www.ncbi.nlm.nih.gov/pubmed?term=9529266)]. However, the clinical role for hormone replacement therapy is uncertain and it is not recommended for cardiovascular disease risk reduction.”

[Kotani et al., 2016](https://www.ncbi.nlm.nih.gov/pubmed/27173621): “There has also been data concerning the role of hormonal drugs on Lp(a) reduction. A recent meta-analysis of 12 randomized controlled trials (RCTs) with 1009 participants revealed that tibolone, a synthetic steroid with estrogenic, progestogenic, and weak androgenic actions, was found to effectively decrease plasma Lp(a) concentrations by over 25% in postmenopausal women ([Kotani et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/26186655)).

“A modest reduction of Lp(a) concentrations have also been observed with aspirin treatment ([Akaike et al., 2002](https://www.ncbi.nlm.nih.gov/pubmed/12194922)).

“Cholesteryl ester transfer protein (CETP) inhibitors also decrease plasma LDL-cholesterol and Lp(a) concentrations, but the recent disappointment generated by evacetrapib (October 2015) raised significant doubts over the efficacy of drugs in treating increased plasma Lp(a) concentrations ([Sheridan, 2016](https://www.ncbi.nlm.nih.gov/pubmed/26744957)). However, the Defining the Safety of Anacetrapib in Patients at High Risk for Coronary Heart Disease (DEFINE) study showed an essential reduction of Lp(a) by 36.4% after 24- weeks of treatment on 2757 patients recruited from 20 countries using anacetrapib ([Lewis, 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3769953/)).”

#### **\* NOTE \* Some constructive feedback from [Tom Dayspring](https://twitter.com/Drlipid), MD, FACP, FNLA, NCMP, regarding Menopausal Hormone Therapy and Lp(a) after listening to the episode:**

- The estrogen story is way more complicated and not everything said was 100% accurate. I am afraid listeners with elevated Lp(a) might start demanding estrogen as an Rx.
- Also, do not confuse physiologic ranges of Lp(a) mass and changes (or variance within that range) and pathologic.
- Lp(a) mass does go up at menopause (but does not go from normal physiologic ranges to pathologic ranges).
- Interestingly in women with the highest estrogen levels, namely pregnancy, Lp(a) increases and although such com­plexities make it difficult to predict the consequences of the transient pregnancy-induced increase in Lp(a) mass, it has been linked to intrauterine growth restriction, pre­eclampsia and recurrent pregnancy loss defined as three or more consecutive pregnancies miscarried at less than 20 weeks gestation.
- [Jenner et al., 1993](https://www.ncbi.nlm.nih.gov/pubmed/8462142): Effects of age, sex, and menopausal status on plasma lipoprotein(a) levels. The Framingham Offspring Study: “After controlling for age, Lp(a) values were 8% greater in postmenopausal women than in premenopausal women, but this difference was not statistically significant.”
  - So an Lp(a) of 10 mg/dL would go to 10.8 not 100.8.
- Quoting the 50% reduction Bob mentioned [see “UpToDate” above], be careful – if you gave such a woman estrogen her Lp(a) would go from 10 to 5 (a 50% reduction) – who cares?
- In WHI [Women’s Health Initiative], Lp(a) values were lower among women taking [Hormone Therapy] (**median 9.4 mg/dl vs. 11.6 mg/dl**, p < 0.0001).

![](https://peterattiamd.com/wp-content/uploads/2018/07/fig-10-tsimikas-2017.png)

**Figure 14. Mechanism of ASO targeted to Apo(a) to reduce Lp(a) levels.** Image and caption credit: [Tsimikas, 2017](https://www.ncbi.nlm.nih.gov/pubmed/28183512).

## Lp(a) modification through lifestyle intervention [1:00:45]

LDL-P and ApoB are affected by four things:

1. The amount of cholesterol you synthesize
2. The amount of cholesterol (or sterol) that you reabsorb
3. The amount of triglycerides (TGs) you have to carry around
4. Your clearance of the particles (which is primarily driven by the LDLR on the liver)

Looking at Lp(a) in terms of two things driving it:

1. How much you make
2. How much you clear

## High LDL-P on a ketogenic/low-carb-high-fat diet [1:05:30]

- A number of cases where higher saturated fat leads to higher LDL-P and replacing the SFA with MUFA were associated with a lowering of LDL-P
- Some hypothesize that elevated LDL-P in this context is not necessarily a bad thing
- Are there ways in which you can lower LDL-P while preserving the other benefits conferred with LCHF
- Replacing SFA with MUFA has been reported to do this
- Sometimes oxLDL, CRP go up in addition to the LDL-P
- Looking at things like oxLDL, oxPL, Lp-PLA2, Hcy, hs-CRP, fibrinogen, insulin, ADMA and SDMA (i.e., looking at endothelial health and function, and inflammation, in addition to lipoproteins) and other factors, can help get a better picture of risk

![](https://peterattiamd.com/wp-content/uploads/2018/07/kiechl-fig-oxplapob-lpa-1024x562.png)

**Figure 15. Plots of hazard ratios for incident CVD according to oxPL/apoB (A) and Lp(a) (B) sextile groups.** Image and caption credit: [Kiechl et al., 2007](https://www.ncbi.nlm.nih.gov/pubmed/17541022).

§

§

## Selected Links / Related Material

- **Anahad O’Connor’s article on Lp(a) in the NYT**: [A Heart Risk Factor Even Doctors Know Little About](https://www.nytimes.com/2018/01/09/well/heart-risk-doctors-lipoprotein.html) | Anahad O’Connor (nytimes.com) [11:00]
- **Apo(a) “tails” and scooping up oxPL**: [New insights into the role of lipoprotein(a)-associated lipoprotein-associated phospholipase A2 in atherosclerosis and cardiovascular disease](https://www.ncbi.nlm.nih.gov/pubmed/17626905) (Tsimikas et al., 2007) [20:00]
- **Apo(a), oxPL, apoB, oxPL, and Lp-PLA2**: [Oxidized phospholipids, lipoprotein(a), lipoprotein-associated phospholipase A2 activity, and 10-year cardiovascular outcomes: prospective results from the Bruneck study](https://www.ncbi.nlm.nih.gov/pubmed/17541022) (Kiechl et al., 2007) [20:00]
- **Lp(a) as acute phase reactant**: [Lp(a): an acute-phase reactant?](https://www.ncbi.nlm.nih.gov/pubmed/7514505) (Noma et al., 1994) [35:00]
- **UpToDate on niacin and Lp(a)**: [Low density lipoprotein cholesterol lowering with drugs other than statins and PCSK9 inhibitors](https://www.uptodate.com/contents/low-density-lipoprotein-cholesterol-lowering-with-drugs-other-than-statins-and-pcsk9-inhibitors?sectionName=NICOTINIC%20ACID%20(NIACIN)&topicRef=4566&anchor=H3691238451&source=see_link#H3691238451) (Rosenson et al., 2018 — literature review current through: 6/18; Topic last updated: 3/20/18) [47:00]
- **Niacin and Lp(a)**: [Future Directions to Establish Lipoprotein(a) as a Treatment for Atherosclerotic Cardiovascular Disease](https://www.ncbi.nlm.nih.gov/pubmed?term=26861250) (Stein and Raal, 2016) [47:00]
- **Niacin and Lp(a)**: [Lipoprotein(a) as a cardiovascular risk factor: current status](https://www.ncbi.nlm.nih.gov/pubmed/20965889) (Nordestgaard et al., 2010) [47:00]
- **Niacin and Lp(a)**: [Guidelines for the primary prevention of stroke: a guideline for healthcare professionals from the American Heart Association/American Stroke Association](https://www.ncbi.nlm.nih.gov/pubmed/21127304) (Goldstein et al., 2011) [47:00]
- **Niacin, statins, and Lp(a**): [Lipoprotein(a) Levels in Patients With Abdominal Aortic Aneurysm](https://www.ncbi.nlm.nih.gov/pubmed/26980774) (Kotani et al., 2017) [47:00]
- **Niacin, statins, and Lp(a) in diabetics**: [Effects of extended-release niacin on the postprandial metabolism of Lp(a) and ApoB-100-containing lipoproteins in statin-treated men with type 2 diabetes mellitus](https://www.ncbi.nlm.nih.gov/pubmed/26515419) (Ooi et al., 2015) [47:00]
- **Niacin and Lp(a)**: [Relationship of apolipoproteins A-1 and B, and lipoprotein(a) to cardiovascular outcomes: the AIM-HIGH trial (Atherothrombosis Intervention in Metabolic Syndrome with Low HDL/High Triglyceride and Impact on Global Health Outcomes)](https://www.ncbi.nlm.nih.gov/pubmed/23973688) (Albers et al., 2013) [47:00]
- **Niacin and Lp(a)**: [Lowering of lipoprotein(a) level under niacin treatment is dependent on apolipoprotein(a) phenotype](https://www.ncbi.nlm.nih.gov/pubmed/25936305) (Artemeva et al., 2015) [47:00]
- **Niacin and Lp(a**): [Optimal therapy for reduction of lipoprotein(a)](https://www.ncbi.nlm.nih.gov/pubmed/22276844) (Lippi and Targher, 2012) [47:00]
- **Statins, Lp(a) and PCSK9i**: [PCSK9 inhibition and Lp(a) reduction: another piece of the puzzle?](https://www.ncbi.nlm.nih.gov/pubmed/29868825) (Pirillo and Catapano, 2018) [51:00]
- **UpToDate on Lp(a) and HRT**: [Lipoprotein(a) and cardiovascular disease](https://www.uptodate.com/contents/lipoprotein-a-and-cardiovascular-disease?search=Lp(a)&source=search_result&selectedTitle=1~150&usage_type=default&display_rank=1) (Rosenson et al., 2018 — literature review current through: 6/18; Topic last updated: 3/29/18) [57:00]
- **HRT studies and Lp(a**): [Effect of postmenopausal estrogen replacement on plasma Lp(a) lipoprotein concentrations](https://www.ncbi.nlm.nih.gov/pubmed?term=8185424) (Sacks et al., 1994) [57:00]
- **HRT studies and Lp(a)**: [Effect of hormone replacement therapy on lipoprotein(a) and lipid levels in postmenopausal women. Influence of various progestogens and duration of therapy](https://www.ncbi.nlm.nih.gov/pubmed?term=8694668) (Kim et al., 1996) [57:00]
- **HRT studies and Lp(a)**: [Postmenopausal estrogen and progestin use and the risk of cardiovascular disease](https://www.ncbi.nlm.nih.gov/pubmed?term=8672166) (Grodstein et al., 1996) [57:00]
- **HRT studies and Lp(a)**: [Effect of postmenopausal hormone therapy on lipoprotein(a) concentration. PEPI Investigators. Postmenopausal Estrogen/Progestin Interventions](https://www.ncbi.nlm.nih.gov/pubmed?term=9529266) (Espeland et al., 1998) [57:00]
- HRT studies and Lp(a): [Evidence-based assessment of lipoprotein(a) as a risk biomarker for cardiovascular diseases – Some answers and still many questions](https://www.ncbi.nlm.nih.gov/pubmed/27173621) (Kotani et al., 2016) [57:00]
- **HRT studies and Lp(a)**: [Tibolone decreases Lipoprotein(a) levels in postmenopausal women: A systematic review and meta-analysis of 12 studies with 1009 patients](https://www.ncbi.nlm.nih.gov/pubmed/26186655) (Kotani et al., 2015) [57:00]
- **Aspirin and Lp(a)**: [Effect of aspirin treatment on serum concentrations of lipoprotein(a) in patients with atherosclerotic diseases](https://www.ncbi.nlm.nih.gov/pubmed/12194922) (Akaike et al., 2002) [57:00]
- **CETP inhibitors and Lp(a)**: [CETP inhibitors boost ‘good’ cholesterol to no avail](https://www.ncbi.nlm.nih.gov/pubmed/26744957) (Sheridan, 2016) [57:00]
- **CETP inhibitors and Lp(a)**: [Defining the Safety of Anacetrapib, a CETP Inhibitor, in Patients at High Risk for Coronary Heart Disease: the DEFINE study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3769953/) (Lewis, 2013) [57:00]
- **Antisense oligonucleotide (ASO) mechanisms**: [A Test in Context: Lipoprotein(a): Diagnosis, Prognosis, Controversies, and Emerging Therapies](https://www.ncbi.nlm.nih.gov/pubmed/28183512) (Tsimikas, 2017) [58:00]
- **ASO studies**: [Antisense oligonucleotides targeting apolipoprotein(a) in people with raised lipoprotein(a): two randomised, double-blind, placebo-controlled, dose-ranging trials](https://www.ncbi.nlm.nih.gov/pubmed/27665230) (Viney et al., 2016) [58:00]
- **Tom Dayspring’s article on hyper-synthesis of cholesterol with high ingestion of saturated fat for some people**: [Lipidaholics Anonymous Case 291: Can losing weight worsen lipids?](https://www.lecturepad.org/dayspring/lipidaholics/pdf/LipidaholicsCase291.pdf) (Dayspring) [1:03:30]

§

§

## People Mentioned

- [Anahad O’Connor](https://twitter.com/anahadoconnor) (wrote an article about Lp[a]) [11:00]
- [Sam Tsimikas](https://twitter.com/Lpa_Doc) (Lp[a] researcher) [20:30]
- [Tom Dayspring](https://twitter.com/Drlipid) (lipidologist) [51:30]
- [Fletch](https://www.youtube.com/playlist?list=PLZbXA4lyCtqp4qeqOToagEWwrJn_o90-r) (“counts” that are out of range) [1:04:00]
- [Nassim Taleb](https://twitter.com/nntaleb) (Venetian proverb) [1:05:30]

#### **\* If you would like us to do a deep dive on a particular topic, please submit your request to the comments section of this post. Please look at the existing comments before posting, and “upvote” the topic (or topics) you want us to cover. \***

###### Featured image credit: [National Institutes of Health (U.S.)](https://openi.nlm.nih.gov/detailedresult.php?img=HMD101453819_C04620&query=heart+diseases&it=xg&coll=hmd&req=4&npos=28). Medical Arts and Photography Branch. “Higher levels of Lp(a) have been linked to higher risk for the onset of coronary artery disease,” [Dr. Steve Nissen, chairman of the department of cardiovascular medicine at Cleveland Clinic in Cleveland] says. “In fact, back in the 1980s, the tennis great Arthur Ashe had normal cholesterol levels but was found to have very high Lp(a) concentrations when he was diagnosed with coronary disease.” [[usnews.com](https://health.usnews.com/health-news/patient-advice/articles/2015/05/14/nonstatin-cholesterol-lowering-drugs-show-promise)]

§