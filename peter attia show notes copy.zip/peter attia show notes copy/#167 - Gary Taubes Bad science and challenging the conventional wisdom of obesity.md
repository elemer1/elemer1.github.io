# #167 – Gary Taubes: Bad science and challenging the conventional wisdom of obesity

**Source:** [https://peterattiamd.com/garytaubes/](https://peterattiamd.com/garytaubes/)

---

Gary Taubes is an investigative science and health journalist and a best-selling author. In this podcast, Gary explains how he developed a healthy skepticism for science as he was transitioning from being a physics major to beginning as a science journalist. He talks about how he was particularly drawn to sussing out “pathologic science,” telling the stories behind his books on the discovery of the W and Z bosons and cold fusion, emphasizing the need for researchers to perform a thorough background analysis. Gary then describes how his work came to focus on public health, nutrition, and obesity.  He provides a great historic overview of obesity research and provides his explanation for why the conventional wisdom today is incorrect.

\*[WATCH PODCAST ON YOUTUBE](https://www.youtube.com/watch?v=8js28V95flc)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/garytaubes/the_Drive_public.png)

Play

#167 - Gary Taubes: Bad science and challenging the conventional wisdom of obesity

#167 - Gary Taubes: Bad science and challenging the conventional wisdom of obesity

1x15s30s

0:002:36:49

## We discuss:

- Gary’s background in science and journalism, and developing a healthy skepticism for science [2:20];
- Gary’s boxing experience, and the challenge of appreciating behavioral risk [8:40];
- How Gary developed his writing skills, and what the best science writers do well [16:45];
- Example of how science can go wrong, and the story behind Gary’s first book, Nobel Dreams [25:15];
- Theoretical vs. experimental physicists: The important differentiation and the relationship between the two [36:00];
- Pathological science: research tainted by unconscious bias or subjective effects [40:30];
- Reflecting on the aftermath of writing Nobel Dreams and the legacy of Carlo Rubbia [49:45];
- Scientific fraud: The story of the cold fusion experiments at Georgia Tech and the subject of Gary’s book, Bad Science [53:45];
- Problems with epidemiology, history of the scientific method, and the conflict of public health science [1:09:00];
- Gary’s first foray into the bad science of nutrition [1:26:45];
- Research implicating insulin’s role in obesity, and the story behind what led to Gary’s book, Good Calories, Bad Calories [1:36:15]
- The history of obesity research, dietary fat, and fat metabolism [1:46:00]
- The evolving understanding of the role of fat metabolism in obesity and weight gain [1:55:15]
- Mutant mice experiments giving way to competing theories about obesity [2:04:00]
- How Gary thinks about the findings that do not support his alternative hypothesis about obesity [2:08:00]
- Challenges with addressing the obesity and diabetes epidemics, palatability and convenience of food, and other hypotheses [2:14:45];
- Challenging the energy balance hypothesis, and the difficulty of doing good nutrition studies [2:25:00]; and
- More.

§

## Show Notes

## Gary’s background in science and journalism, and developing a healthy skepticism for science [2:20]

- Gary began in the hard sciences
  - majored in applied physics at Harvard
  - Growing up in the 1960s, he read science fiction and wanted to be an astronaut
  - Was also competing with older brother who studied physics
  - But “[Hamiltonian](https://en.wikipedia.org/wiki/Hamiltonian_(quantum_mechanics)) was beyond my ability to comprehend,” so he did not pursue physics after college
  - Instead he got a Master’s in aerospace engineering at Stanford
    - Realized he wouldn’t be chosen as an astronaut over shorter, lighter candidates who were in better shape
    - Also realized that he “wouldn’t survive very well in any kind of military hierarchy that required blind acknowledgement to superiors”

*Where was that seed planted of insatiable skepticism and a refusal to bend to authority?*

- He switched from science to journalism
  - When his son plays basketball, Gary notices that the best players are the ones who have older brothers who play
    - On some level, Gary’s competition with his brother started his skepticism
  - he went to journalism school at Columbia to become an investigative journalist
    - Was fascinated by [All the President’s Men](https://en.wikipedia.org/wiki/All_the_President%27s_Men) by [Bob Woodward](https://en.wikipedia.org/wiki/Bob_Woodward) and [Carl Bernstein](https://en.wikipedia.org/wiki/Carl_Bernstein)
  - After journalism school he took a job at [Discover Magazine](https://www.discovermagazine.com/)
- He did a piece on the [Shroud of Turin](https://en.wikipedia.org/wiki/Shroud_of_Turin)
  - the supposed burial shroud of Christ appeared in the historical record right around the 11th or 12th century when there a big market in fake religious artifacts
  - Researchers from Los Alamos took their high-tech imaging equipment to Turin to examine the shroud
    - they said they didn’t understand how it was made, even though it had been carbon-dated to the 11th and 12th century
  - He thought their conclusions were not supported by the data

> “There’s nothing fundamentally different about somebody who goes into science and somebody who goes into journalism, other than we have sort of different mechanisms of wanting to understand what truth is.” —Gary Taubes

- If they were unable to determine how the shroud was created, don’t have to conclude it was made by supernatural means
- it could mean that the equipment used was simply inadequate

- Today, we’re almost having the same debate about the cause of obesity:
  - *Are you doing the right experiments?*
  - *Have you refuted the hypothesis, or are the experiments flawed?*
  - *And that’s always a fundamental issue in science*

## Gary’s boxing experience, and the challenge of appreciating behavioral risk [8:40]

**The challenge of appreciating behavior risk**

- Gary started smoking in 1978 when he was depressed
  - struggled with the transition from undergrad to grad school where no one knew him
  - Took him 20 years to quit
- As he and Peter discussed in their work with the [Nutrition Science Initiative](https://nusi.org/) (NuSI), kids rarely think in terms of the things they do being dangerous
- He and Peter both boxed, but Peter never considered it dangerous (“I had this true mental block”)
- When he was 20, Peter suffered a very severe concussion from boxing
  - hospitalized for two days, had significant bruising and cerebral contusions, and a headache that lasted for three months
  - took him that long to realize how dangerous it was
- Gary’s college friend was killed in a boxing match their senior year
  - Nevertheless, Gary still started to box 3 year later
  - “I never thought that what happened to him could happen to me until I got knocked out in the Golden Gloves. . At which point, there’s this awareness when you get knocked unconscious, when you wake up that some people never wake up from that.”

> “I always thought it was fascinating that the less life we have left to live, the more risk adverse we become.” —Gary Taubes

**Lessons in boxing**

- It’s hard to make young people understand prevention of chronic illness, disease, and addiction
  - Gary is sure behavioral psychologists like [Daniel Kahneman](https://en.wikipedia.org/wiki/Daniel_Kahneman) and [Amos Tversky](https://en.wikipedia.org/wiki/Amos_Tversky) would have something to say about that
  - In his house, Gary has a framed photo of himself lying prostrate in the ring that he refers to as “hubris protection”

*Gary’s experiences with amateur boxing*

- There were a number of high-profile deaths in boxing in the early 80s
  - [Duk-Koo Kim](https://en.wikipedia.org/wiki/Kim_Duk-koo) was killed by [Ray Mancini](https://en.wikipedia.org/wiki/Ray_Mancini)
- At Discover Gary worked with [Denise Grady](https://www.nytimes.com/by/denise-grady), who now works for the *New York Times*
  - Denise did a [story](https://www.newspapers.com/newspage/462665838/) on what happens to the brain in boxing
  - She would slip articles under Gary’s door about boxing-related brain injuries
- Gary would box with [Norman Mailer](https://en.wikipedia.org/wiki/Norman_Mailer)’s nephew in a group Mailer had that boxed each other on Saturday mornings
- Gary got the idea to box in the [Golden Gloves](https://en.wikipedia.org/wiki/Golden_Gloves) and write an [article](https://peterattiamd.com/wp-content/uploads/2021/07/eightcountarticle.pdf) about it
  - He was too old by a few months
  - *Sports Illustrated* pulled it because he’d have to fake his birth certificate
  - Ended up writing it for *Playboy* instead
    - His SIL was angry that he wrote an article for a magazine that portrayed women in a bad way
    - Though he acknowledges that she had a point, he said that some of the best writers were writing for that magazine “and maybe later I’ll have the platform by which I can be too good for this approach”
  - He won his first fight against a police officer who “beat the crap out of me in the first round” when he realized he needed to punch back and knocked him out in the second round
  - In his second fight, he got knocked out in 1 minute and 37 seconds
- Gary had only been boxing as an amateur for 4 months, but he had a [James Bond](https://en.wikipedia.org/wiki/James_Bond_(literary_character)) complex
  - Getting knocked out was a reminder of his limits and that “there are things I should stay away from if I want to have a long and healthy life”
  - He never boxed again

## How Gary developed his writing skills, and what the best science writers do well [16:45]

**Peter praises Gary’s writing**

- Peter notes that Gary writes very well
  - Peter thinks Gary helped his own writing
  - When they were at NuSI, Gary did a lot of editing and revising of what Peter wrote
  - Peter also says that Gary can write about science in a way that’s very readable

**How Gary learned**

- Peter asks how Gary learned the craft of writing
  - Gary always had a sense that he was a writer
- After Stanford, took night writing classes at Harvard
  - One was with a science writer from the *Boston Herald* whom Gary later worked with at *Discover Magazine*
  - The other was taught by [C. Michael Curtis](https://www.theatlantic.com/magazine/archive/2005/06/the-man-behind-the-stories/304143/), a famous fiction editor from *The Atlantic*
    - He had been a roommate of [Thomas Pynchon](https://en.wikipedia.org/wiki/Thomas_Pynchon) and [Dick Fariña](https://en.wikipedia.org/wiki/Richard_Fari%C3%B1a) at Cornell in the early 1960s
    - Curtis wrote the word “puerile” on Gary’s first article, and Gary had to look it up to find out that Curtis thought his writing was childish, amateurish, and thoughtless
    - Curtis began to “hammer me into being a functional writer by constant and relentless criticism of what I did”
  - In contrast, the *Boston Herald* writer was a nice man who never criticized students’ writing, but Gary “gained absolutely nothing from being in his class”
- In journalism school, he learned to write in report form and says “it’s a steady learning process”
- He started as a reporter at *Discover*
  - Back then reporters gather the info and wrote files, which were then given to the writers, who were “true craftsmen”
  - Writer friends would read his drafts “and then relentlessly critique it until I ended up with something that was worth submitting to the editors, and then the editors would do the same thing before it would be published”
  - As Gary got older and became a writer, he did the same for reporters under him
  - “There are a few very well-respected journalists who, I think, benefited from me being relentlessly critical”
- The famous New Yorker writer [Calvin Trillin](https://en.wikipedia.org/wiki/Calvin_Trillin) called the first draft the “vomit out”
  - Just focus on getting everything down
  - Then keep rewriting and rewriting it
  - “Because I read a lot and I read a lot of very talented authors, I know what good writing looks like and feels like, and then you just continue to revise and edit until it gets there”

**Gary’s take on the best science writers [21:00]**

- Peter asks Gary who the best living science writer is
  - Gary says that’s like trying to say who the best basketball player is: was [Wilt Chamberlain](https://en.wikipedia.org/wiki/Wilt_Chamberlain) better than [Steph Curry](https://en.wikipedia.org/wiki/Stephen_Curry)?  They were different
  - Gary likes [Ed Yong](https://en.wikipedia.org/wiki/Ed_Yong), a young writer for *The Atlantic*
    - He “writes a thoughtful, well-reported article on a different subject every three or four days”
    - Gary doesn’t think he could have done that while working 70-80 hours a week at his age
  - Gary says when he was growing up the best science writer was [Jim Gleick](https://en.wikipedia.org/wiki/James_Gleick), who wrote [*Chaos*](https://en.wikipedia.org/wiki/Chaos:_Making_a_New_Science) and a [biography](https://www.amazon.com/Genius-Life-Science-Richard-Feynman/dp/0679408363/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) of [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman)
- There was also a good group of science journalists who came of age in the 1980s
  - [Charles “Cam” Mann](https://en.wikipedia.org/wiki/Charles_C._Mann), [Steve Hall](https://jem.utk.edu/2012/07/16/stephen-s-hall-award-winning-new-york-times-magazine-writer-2012-hill-lecturer), [and John Tierney](https://en.wikipedia.org/wiki/John_Tierney_(journalist)) were among them
  - Science magazines (like *Science* and *Discover*) were first starting
  - Wrote books like Hall’s [*A Commotion In The Blood*](https://www.amazon.com/Commotion-Blood-Immune-System-Technology/dp/0805037969)
  - In Cam’s work, “the writing is so painfully beautiful that I feel inadequate when I read them”

*What makes great science writing?*

- Great science writing is a combination of comprehensive, rigorous reporting and a prose style that tells a story around the complicated subject
  - Writing that people want to read, keeping the story and diversions interesting, and simultaneously getting the details of the lives and the times right while making the story bigger than that
  - The inherent challenge of science writing is dealing with a very complex subject
- Gary says [*The Ghost Map*](https://www.amazon.com/Ghost-Map-Londons-Terrifying-Epidemic/dp/1594489254/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by [Steven Johnson](https://en.wikipedia.org/wiki/Steven_Johnson_(author)) is an extraordinary book
  - The book is about the cholera epidemic in England in 1864
  - [John Snow](https://en.wikipedia.org/wiki/John_Snow) figured out that cholera was an infectious agent in the water supply
  - It’s also about “the birth of modern cities, urbanization, and the problems that cities faced coming together”
  - And it’s about the scientific process itself
- “You start with a small story and you turn it into something large and intricate, meaningful”

## Example of how science can go wrong, and the story behind Gary’s first book, *Nobel Dreams* [25:15]

**Gary’s first book:** [***Nobel Dreams***](https://www.amazon.com/Nobel-Dreams-Deceit-Ultimate-Experiment-dp-0394545036/dp/0394545036/ref=mt_other?_encoding=UTF8&me=&qid=)

- In the 1960s and 70s, it was a great step forward when electricity and magnetism had been united with [electroweak theory](https://en.wikipedia.org/wiki/Electroweak_interaction)
  - Theory mostly confirmed by about 1973
  - It predicted the existence of two particles that carry the electroweak force
- An international team of physicists ran the [Underground Area 1 (UA1) experiment](https://en.wikipedia.org/wiki/UA1_experiment) that discovered the “weak” [W and Z bosons](https://en.wikipedia.org/wiki/W_and_Z_bosons)
  - UA1 was headed by a Harvard physicist, [Carlo Rubbia](https://en.wikipedia.org/wiki/Carlo_Rubbia), who was working at the European Center for Nuclear Research (CERN) in Geneva
  - they built an accelerator that had the power to detect the WNC particles
  - published their work on the two bosons around 1983
- Discover decided to do a “Scientists of the Year” feature and chose Rubbia, who was expected to get the Nobel Prize
  - Gary got to go to Geneva to interview Rubbia and his friends (“my life has been downhill ever since”)
  - *Discover* flew Rubbia to the Explorers Club in NY to give him the award
  - Rubbia was the co-recipient of the [Nobel Prize in 1984](https://www.nobelprize.org/prizes/physics/1984/summary/)
- Around April of 1984, Rubbia came to Washington and gave a presentation announcing that he was now doing physics beyond the standard model
  - It was the biggest discovery in physics in 40 years
  - it’s rare that anyone predicts a great discovery in advance
  - Gary proposed to Rubbia that Gary come to CERN and document the process as it happened and Rubbia agreed
    - The *Atlantic* rejected Gary’s proposal because Charles Mann and a co-author at the time, [Bob Crease](https://en.wikipedia.org/wiki/Robert_P._Crease), had just proposed doing a piece on high energy physics
    - Then [Shelly Glashow](https://en.wikipedia.org/wiki/Sheldon_Lee_Glashow), a Nobel Laureate at Harvard, recommended Gary to his publisher and it agreed to fund the book
- Gary was “embedded” with the physicists for 9 months
  - “*I thought I was going to write about a great discovery and pretty quickly realized that this was far less compelling*”
  - But Gary soon realized that the data were not as strong as Rubbia had claimed in Washington
- Team used a particle accelerator
  - collides subatomic particles together at speeds as close as possible to the speed of light
  - The faster the particles go, the greater the energy
  - Monitoring the collisions for signs of particles that the standard model of physics does not predict
  - as the accelerators are able to put more and more energy into these collisions, can test your predictions of the standard model further and further out

**Gary’s reflections on Rubbia and the UA1 experiment [31:00]**

- The particle accelerator was around 4 miles in circumference
  - Back then cost hundreds of millions of dollars (today billions)
  - There are detectors at the points on the accelerator where the two beams collide together
  - The detectors are 3-4 stories high, the size of mansions
  - detect various particles that will result from the collisions ([protons](https://en.wikipedia.org/wiki/Proton), [muons](https://en.wikipedia.org/wiki/Muon), etc.)
- But of the billions of collisions, you’re looking for **maybe one collision that creates one particle that your standard model doesn’t predict**
  - Maybe 20 a year are relevant
  - Peter says “just think about the signal-to-noise ratio there”
  - Make a prediction of the mass effect of that collision
  - have some conservation of mass and charge
  - Trying to coalesce all of these different things to look for discrepancies that are occurring (or not occurring) at almost an infinitesimal fraction of the number of collisions
  - Peter says “it’s very hard to wrap your mind around”
- Must detect everything that comes out of that collision and factor in conservation of energy
  - If a certain amount of energy goes off in one direction, you need to get the same amount of energy going off in the other direction
  - “If it’s not balanced, does that mean that your detector failed or that a particle was created that your detector couldn’t see because it’s beyond the standard model?”

> “Science is about signal-to-noise. You have to be able to predict the noise almost perfectly. … This is a repeating theme in everything.” —Gary Taubes

- Gary talked about signal-to-noise problems all the time in his work with NuSI
- It’s critical to understand the standard model predictions of what you would expect to see if there’s nothing new out there and what you would expect to see from the understood flaws of the equipment
  - Looking at effects in parts per billion or trillion, so must understand the flaws in your detector beyond that level
  - As [Donald Rumsfeld](https://en.wikipedia.org/wiki/Donald_Rumsfeld) would say, you have your known unknowns and your [unknown unknowns](https://www.scientificamerican.com/article/rumsfelds-wisdom/)
  - Gary says you never fully figure out your unknown unknowns
- Sigma is a measurement of the [standard deviation](https://en.wikipedia.org/wiki/Standard_deviation)
  - Want to see a [five sigma](https://blogs.scientificamerican.com/observations/five-sigmawhats-that/) or 6 sigma effect to “make a lot of room for the unknown unknowns”
  - Need to see an event that’s so fundamentally outside the range of what you think you know that the unknown unknowns can’t explain it and it looks like new physics

> “There’s going to be stuff that’s going to fool you that you don’t know. So you want to have an event that’s so absolutely fundamentally freakin’ outside the range of what you think you know, that you can confidently assume that what you don’t know—the unknown unknowns—can’t explain it either and it’s new physics.” —Gary Taubes

## Theoretical vs. experimental physicists: The important differentiation and the relationship between the two [36:00]

- Physics is a collaboration between theory and experiment
  - Some develop the theories, which make predictions that can be tested
  - Then the experimentalists test the theories through experimentation
- [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) was a theorist
- [Arthur Eddington](https://en.wikipedia.org/wiki/Arthur_Eddington), who did the seminal test of the theory of relativity, was an experimentalist
- Gary says: “There’s got to be a crosstalk between the theorist and the experimentalists, because the experimentalists have to know precisely what they’re looking for. They need the help of the theorists to tell them how this might manifest itself”
- Experimentalists must be aware of how their equipment could fool them
- Gary explains:
  - “In fields in biology and medicine, … I think [it] is a problem … [that] the theorist and the experimentalist are merged into one person
  - “I think they are two entirely different skill sets. … I don’t think one person could encompass both aspects … They’re almost different endeavors.”

**How this relates to the CERN experiment**:

- Need multiple detectors to provide independent replication
  - The Large Hadron Collider at CERN now has four or five different detectors
- Once Rubbia had published his work on the W and Z bosons, everyone wanted to work with him
  - All the young physicists discuss what’s happening with the data
- The physicists and technicians who built the detector “don’t come from Harvard and Stanford and Oxford and Cambridge. They work at the red brick universities in the Midland and UK”
  - But because they built the detector they are very aware of its limitations
  - They recognize that we do not understand the flaws in the detectors well enough for Rubbia to make the claims he is making
- But Rubbia disregarded them
  - He had gone out on a limb with his announcement in Washington in 1984
  - Only wanted to hear about results

## Pathological science: research tainted by unconscious bias or subjective effects [40:30]

- Physicists use the term “[pathological science](https://en.wikipedia.org/wiki/Pathological_science),” which is research that appears to follow the scientific method but is “[tainted](https://en.wikipedia.org/wiki/Irving_Langmuir) by unconscious bias or subjective effects”
  - People commit themselves publicly to a result based on premature evidence
  - There’s still a chance they could be wrong and they don’t understand the likelihood of that chance
- When you get very good at this, you realize that chance is enormous
- In science you are supposed to form a hypothesis and then test it to try to prove yourself wrong
  - Richard Feynman said the first principle of science is “You must not fool yourself, and you’re the easiest person to fool.”
  - Your assumption should be that you’re wrong, that somehow your equipment is fooling you
  - You present to colleagues, who suggest ways you might be wrong
- If you still haven’t found a flaw, you publish the paper with a question mark: “Evidence for particle X?”

> “But if you claim that you did and you published the paper first, now what you’re doing, instead of that exercise of trying to find out how you assuredly screw it up, you’re trying to collect evidence for how you got the right answer. So you go from paying attention to the negative evidence to paying attention to the positive evidence.” —Gary Taubes

- Everyone is susceptible to doing this: when a study comes out that confirms what you believe, you don’t question it the same way you would a study that challenges your beliefs
  - Rubbia had gotten to the point where he was predicting a discovery, so all he wanted to hear was supporting evidence
  - He resisted listening to those who wanted to tell him about potential problems

> “This happens in all of science. It’s what we’ve seen in an extreme way in COVID. It goes on in climate change. It goes on in nutrition and chronic disease. Once you decide you know what the truth is, you tend to stop listening to the people who disagree with you. … This is also classic group think theory.” —Gary Taubes

- Rubbia was enormously self-confident
  - Gary was close to him, and once Gary realized that there were serious issues with the experiment, he expressed his skepticism and would challenge Rubbia
  - Gary thinks Rubbia was a bit of a pathological liar who “defined truth as what was convenient for him”
  - When Gary challenged him, Rubbia would say “good point” but then keep going and say other things

> “It never got to the point where I felt from him any awareness that what I was going to write was not the story he wanted to tell. I think this is a classic problem with people of his quality and strength of ego, which is he couldn’t imagine that I could see the universe differently than he did.” —Gary Taubes

- After the book came out, Rubbia wanted to sue Gary and asked physicists from collaborating institutions to join him
  - They declined
  - most of them had critiqued drafts of Gary’s book as a favor to him, which Gary did not say in the book to avoid professional consequences for them
- Gary thinks the story in the book is interesting, but “my 29-year-old prose still makes me cringe”
- When *Nobel Dreams* came out, Gary’s publisher got it mentioned in [Page Six](https://pagesix.com/), the gossip column of the *New York Post*
  - The headline was something like “Eggheads Squabble Over Nobel Prize” and in the article Rubbia called Gary an asshole
  - Gary thought, “I’m never going to eat lunch in this town again and my career in journalism is over”
- In pathological science, you’re knowingly trying to fool other people by manipulating the evidence
  - there are two ways you can manipulate
    - Fudge or move a signal
    - inadequately studying the background
  - If you ignore the background, you’ll still end up with a big signal-to-noise ratio and you haven’t technically committed active fraud
    - That’s what Rubbia did – **he was fooling himself**

> “Doing a background analysis is the hard, relentless, rigorous grunt work of science. It’s endless and thankless, because if you do it right, all you’ll do is prove that you were wrong all along.” —Gary Taubes

## Reflecting on the aftermath of writing Nobel Dreams and the legacy of Carlo Rubbia [49:45]

- Peter asks how to reconcile Rubbia doing bad science with his earlier discovery of the two bosons that led to the Nobel Prize
  - “It suggests that even at the upper most echelon of science, you can have people that are committing these omissions”
  - Gary guesses that the papers that won Rubbia the Nobel Prize may be wrong too because they were rushed
    - The discovery had already been made in the 1970s
    - The particles had to exist with the characteristics he was looking for
    - No one asked if they were really W particles
    - “In retrospect, most to all of them probably were detector flaws that they didn’t understand yet, that they still had to work out over the next year”
- He got the award so soon because, since World War II, all the major discoveries in physics had been made in the U.S.
  - This was Europe’s (and CERN’s) opportunity to achieve relevance again
- When Gary was interviewing physicists for the book, he was “trying to rationalize what they told me with who he was and who I thought he was”
  - “There are people from the experiment who Rubbia ground up and chewed up and spit out, whose careers basically came to an end because of him”
  - In the introduction of the book, Gary said there were three types of physicists
    - those who were at Rubbia’s level and told me he was brilliant
    - those who knew Rubbia well and said he was very smart guy, but they want to work for him
    - those who worked for him
  - some young French physicists were reduced to tears by Rubbia’s bullying
    - “Bullying can be very beneficial in science because you’re really trying to force someone to think critically and force any sloppiness out of them”
    - Nonetheless, Gary sometimes wanted to punch Rubbia instead of writing the book
- Some critics did not like Gary’s book
  - [Christopher Lehmann-Haupt](https://en.wikipedia.org/wiki/Christopher_Lehmann-Haupt) wrote a critical [review](https://timesmachine.nytimes.com/timesmachine/1987/01/29/556387.html?pageNumber=77), as did [Jeremy Bernstein](https://en.wikipedia.org/wiki/Jeremy_Bernstein)
  - They thought a young journalist like Gary had no right to take on a physicist of this level
  - They were less interested in character flaws and more interested in the “glorious cathedral of knowledge”

## Scientific fraud: The story of the cold fusion experiments at Georgia Tech and the subject of Gary’s book, *Bad Science* [53:45]

**Career switch**

- Time sold *Discover* to a low budget publisher
  - the readership was often teenage boys with little money to support ad revenue
  - Gary moved to LA to write screenplays

**How Gary came to write a book about the cold fusion experiments**

- When cold fusion burst into the news in 1989, Gary’s publisher asked him to write a book about it
- It was supposed to take a year, but it took 3 and left Gary $40,000 in debt to his dad (“I bonded with many writers over the years … about how much money we owed our parents by the time we were done with our first book”)
- Chemists [Stan Pons](https://en.wikipedia.org/wiki/Stanley_Pons) (University of Utah) and his mentor, [Martin Fleischmann](https://en.wikipedia.org/wiki/Martin_Fleischmann) (Southampton University in the UK) said they had created nuclear fusion in a test tube
- It was front page news all around the country
- When Gary found out that there was a competing group at Brigham Young University, he assumed Pons and Fleischmann were wrong
  - The desire to establish reliable knowledge beyond reasonable doubt can be compromised by the motivation to get there before the other team
  - This happened at CERN with Rubbia and UA1
  - The competing group [UA2](https://en.wikipedia.org/wiki/UA2_experiment)’s research was better because once they knew they wouldn’t win the race, they did better science

**The story behind Gary’s book** ***Bad Science***

- Gary’s investigation of Pons and Fleischmann led to his book [*Bad Science*](https://www.amazon.com/Bad-Science-Short-Weird-Fusion/dp/0394584562)
- Pons and Fleischmann [published](https://www.sciencedirect.com/science/article/abs/pii/0022072889800063?via%3Dihub) their findings in 1989
  - said they put [heavy water](https://en.wikipedia.org/wiki/Heavy_water) in a test tube with an electrode made of [palladium](https://en.wikipedia.org/wiki/Palladium)
  - plugged it into the wall and the [deuterium](https://en.wikipedia.org/wiki/Deuterium) got sucked into the palladium
  - They claimed it was net energy positive
- The concept was to compress it so much that it fuses and generates neutrons, gamma rays, or other signs of radioactivity
  - would indicate that there was a nuclear reaction going on or at least a lot of heat
  - one of the cold fusion cells exploded, which they took as a sign of nuclear fusion
- A physicist at BYU ([Steve Jones](https://en.wikipedia.org/wiki/Steven_E._Jones)) had studied something called muon-catalyzed fusion
  - He had read Pons and Fleischmann’s proposal and started working on it afterwards, and they felt he was trying to steal it from them
  - The president of the University of Utah at the time, [Chase Peterson](https://en.wikipedia.org/wiki/Chase_N._Peterson), reflected that once Pons and Fleischmann believed the people at BYU were trying to steal it from them, they decided it must be right
- After their announcement, “everyone in the world tries to replicate it because it seems it holds the promise of infinite free energy” – the wealth of OPAC
- It costs about $3000 worth of materials to put together a cold fusion cell, so anyone can study it
- *The Wall Street Journal* ran an article about it written by a science reporter named [Jerry Bishop](https://www.nasw.org/article/memoriam-jerry-e-bishop)
  - Bishop scooped the story but it may have been premature given the implausibility
  - He later lived across from Gary on the Upper West Side of Manhattan
- Around the world, people were trying to replicate Pons and Fleischmann’s work
  - Most correctly concluded that cold fusion doesn’t exist, but maybe 6 labs (for reasons that tended to be different for each lab) got it wrong
  - the phenomenon keeps going because of the signal being generated from these six labs
  - It would have been a major discovery if it were true
- Gary had the opportunity to embed himself with scientists while they tried to replicate the experiment
  - In effect, they did the background analysis that Pons and Fleischmann and Steve Jones at BYU hadn’t done
  - Within 2-3 months it was clear that Pons and Fleischmann had been wrong and then the story died out
- Gary was fascinated by the fiasco and became obsessed with how it happened
  - Gary saw it as a case study in bad science and the price of doing so of claiming something to be true that later turns out not to be
  - It’s an example that grad students should be required to read so they could see all the different ways you’re going to fool yourself
  - He applies it today when he’s writing about nutrition, chronic disease, obesity, and diabetes

“The question is how do people establish conventional wisdom, dogma, the ruling theory in any science and on what evidence?”

- [Irving Langmuir](https://en.wikipedia.org/wiki/Irving_Langmuir), a Nobel laureate chemist, [presented a colloquium](https://www.cs.princeton.edu/~ken/Langmuir/langmuir.htm) in 1953 on pathological science
  - He said it’s was not about fraud or manipulation of data but about the scientists not realizing how easily they can be fooled
  - The effects tend to be at the level of the equipment’s ability to detect them
  - He listed criteria and a sensitivity analysis as well (small perturbations)
- If you create nuclear fusion in a test tube, it should be generating gamma rays and neutrons and should be radioactive

**Georgia Tech experiments**

- Chemists at a research institute at Georgia Tech put together cold fusion cells
  - Borrowed neutron detectors from physicist colleagues (“think of them as [Geiger counters](https://en.wikipedia.org/wiki/Geiger_counter) from the physics department”)
  - The detectors go off when held over the cold fusion cells but not when moved away, so they were clearly detecting neutrons
- Wrote up a paper and had a press conference
- A physicist asked the chemists if they realized that neutron detectors are humidity sensitive
  - Cells were bubbling and humid
  - So used a control with water instead of deuterium and the detector went off over the control too
  - Chose the wrong control – weren’t controlling for humidity

> “That’s back to understanding your background. What are all the other possible causes of what we’re seeing? And we have to go through methodically and this is what takes time, time, time, and you need the help of every smart person you know to point out all the different things that you might’ve thought for that you now have to design an experiment to control for.” —Gary Taubes

- Every place that claimed it had seen signs of cold fusion did something like this – involved an aspect of the background that they didn’t understand
- Physicists doing chemistry and chemists doing physics
- If the cells are really creating nuclear fusion, they would be generating more heat than they’re taking in from the wall
  - calorimetrists were capable of doing these experiments right because they understood the background
  - they knew that there would be some feedback going down the cord so you’d get energy coming back into the cell from the power source
- Pons and Fleischmann never acknowledged their error

**A discussion about the changing of one’s convictions**

- At a debate in England, Gary was once asked if he would ever change his mind about the uselessness of the energy balance equation for obesity
  - he said he doubted it
  - people say it’s useless to debate him because he has already made up his mind
  - but he said that because of situations like the one with Pons and Fleischmann

> “It takes a kind of superhuman intellect to be able to say something I believe beyond reasonable doubt and have staked my reputation on is actually wrong. It’s always easier for somebody to believe personally that all the other experiments screwed up.” —Gary Taubes

- Gary would likely never be able to change his mind about cold fusion now

> “The day that my neighbor buys a cold fusion power car, I’m going to have to start believing it or I’m in trouble. Until then I think an enormous amount of skepticism, if not closing my mind, is perhaps a correct thing to do.” —Gary Taubes

## Problems with epidemiology, history of the scientific method, and the conflict of public health science [1:09:00]

**How Gary transitioned from writing about physics to writing about public health (1:09:00)**

- Gary interviewed about 300 people for *Bad Science*
- [Freeland Judson](https://en.wikipedia.org/wiki/Horace_Freeland_Judson), one of the great science writers of the late 20th century, wrote a [book](https://www.amazon.com/Eighth-Day-Creation-Revolution-Biology/dp/0879694777/ref=tmm_hrd_title_0?_encoding=UTF8&qid=&sr=) about the history of the molecular biology revolution
  - Judson told Gary that he had done more research on the stupidest scientific subject than any human being alive
- Gary was drawn in by pathological science: the sociology and flawed decision-making process, how mistakes happened
  - He had made friends in the physics world who respected and appreciated his work
  - Some were involved in a debate about whether or not electromagnetic fields from power lines can cause cancer

*Cancer and power lines [1:10:00]*

- From a physics standpoint, their wavelengths are too big to interact with something as small as cells
- But epidemiology could find an association between the field strength around power lines and the levels of cancer in people living near the power lines
  - His scientist friends “were horrified at the level of science they were seeing” and suggested he write a book about it
  - Gary wrote an [article](https://peterattiamd.com/wp-content/uploads/2021/07/Fields-of-Fear-The-Atlantic-1993.pdf) for *The Atlantic* on the power line – cancer connection

> “But I had spent the previous … years learning about how hard science is to get right, and being schooled and tutored and lectured into believing that you have to be extraordinarily rigorous and methodical and relentless, or you’ll get the wrong answer.” —Gary Taubes

- But in epidemiology they were assuming an association was causal and thought “doing the kind of rigorous testing of hypotheses to be a luxury that they couldn’t afford”
- [Alvan Feinstein](https://en.wikipedia.org/wiki/Alvan_Feinstein) from Yale, and later also Gary, used to be the best-known critics of the field
  - Gary wrote a [piece](https://www.youtube.com/watch?v=0YGao5cRWQo) on epidemiology in the journal Science which was “infamous”
  - Now he and Feinstein are dwarfed by [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis)
- In epidemiology, you can’t conduct experiments to test a hypothesis as they could with cold fusion
  - It’s a field of science built around hypotheses

“As more and more people see the same phenomenon, but without using the rigorous experimental techniques of an experimental science, they start to believe that this hypothesis is true”

- In epidemiology, there has never been significant work on the background noise
  - For example, the [Nurses’ Health Study](https://en.wikipedia.org/wiki/Nurses%27_Health_Study) gave questionnaires to 110,000 nurses about what they eat
  - Follow them and then look back to see of there was a difference in what those who got sick and those who did not were eating
  - You might find an association between diet and disease, but it does not tell you whether it’s causal
  - “There’s no way to rigorously test, so the process of science breaks down”

**The scientific method is a recent phenomenon [1:14:00]**

- Peter points out that the concept of rigorous scientific thinking is only about 400 years old, so it’s not intuitive
  - [Francis Bacon](https://en.wikipedia.org/wiki/Francis_Bacon) published [*Novum Organum*](https://en.wikipedia.org/wiki/Novum_Organum), the first text about the scientific method, about 400 years ago
  - Gary read it about 20 years ago to reassure himself he wasn’t crazy
  - But Peter reflects that ability to recognize patterns and make an inference must have been critical to success (“I saw Larry doing X. Larry has more mating opportunities than me. Doing X must be the reason that Larry has more mating opportunities than me”)
  - Evolution would favor this kind of reasoning, but Peter says “we didn’t codify it. I think that’s the difference. We didn’t live long enough to see the result because the arc of the information coming back is too long. … Evolution did follow the experiment but at the individual level we never go to learn from it”

**Correlation does not necessarily mean causation**

- Many people understand that correlation is not the same as causation, but it’s still not always clear why control and randomization matter and how common bias is

**The importance of background analysis [1:16:15]**

⇒ *The power line example*:

- Have to understand the background to see all the ways you can be fooled
- “We see more cancers close to the power lines than we see far away. Can we explain that as something other than the power lines cause cancer? … What else could explain this?”

> “The probability that your hypothesis is correct has gone down enormously as soon as you accept the reality that there are an infinite number of other possibilities that you have to rule out.” —Gary Taubes

- first order factors are the factors that are very likely
- second order factors are less likely, etc.
- that’s why physicists want to see a five sigma effect – want to leave room to account for leave a lot of room for the fourth, fifth, sixth order variables
- Alternative possibilities
  - maybe people who live closer to power lines are poorer than people who live farther away
    - power lines are ugly and make noise, so people choose to life farther from them if they can
    - Gary thinks a lot of what the epidemiologists publish are false positives that might be explained by socioeconomic status
    - Would need to look at household incomes
  - Maybe people who answered the phone during typical working hours to consent to being in the study are more likely not to be employed
  - It can also be bias: people with health problems are more likely to want to participate and find out about potential causes
- This kind of background analysis is the part that Rubbia did not like to do
  - At a meeting in the Aosta Valley in Northern Italy, a physicist named [Guido Altarelli](https://en.wikipedia.org/wiki/Guido_Altarelli) suggested multiple other explanations for the data
    - maybe the muon comes off and but is in the infinitesimal dividing line between the two detectors so you don’t see it
    - Maybe a neutrino comes off and it bounces off the side of the tau detector and you don’t see it
  - In his book Gary called it the “Altarelli cocktail” – suggested that it’s not even a one sigma result
- The labs testing cold fusion accepted results that confirmed their preconceptions
  - “you’re always going to pay less attention to the things you don’t want to see”
  - in epidemiology, you’re looking for 95% confidence level
  - willing to claim a causal effect based on two sigma
  - if they used the same standard as physicists, it would likely be a false positive

***So how would you answer the power line/cancer question?***

- Peter points out how difficult it would be to design the right experiment for the power line situation
- Can’t randomize people to live near or away from power lines
- But we need an answer to the question, so *what should we consider good enough?*
  - Conventional thinking has been the idea of [prudent avoidance](https://en.wikipedia.org/wiki/Prudent_avoidance_principle)
    - in the power line example, minimize whatever fields are being emitted from these power lines
    - with COVID, wear masks
    - but avoiding harm comes with its own costs – the effects of COVID shutdowns, power companies raising rates due to the cost of being more heavily regulated
  - Evaluating the positives and negatives of an action taken (like prudent avoidance) has become a social value judgement
  - The question is also what’s the incumbent on the researchers

**The conflict of public health science**

- At the beginning of his book [*Good Calories, Bad Calories*](https://www.amazon.com/Good-Calories-Bad-Controversial-Science/dp/1400033462), Gary quotes [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) saying something like  “what you need fundamentally in good science is to be honest about what you know and what you don’t know”
  - In a 1974 commencement [speech](https://calteches.library.caltech.edu/3043/1/CargoCult.pdf) at Caltech, Feynman said that investigators are obligated to talk about all the limitations in their research
  - Gary thinks that ideally the limitation section should be longer than the results section in a published journal article
- Some critics have said that Gary doesn’t do that
  - “I try to do that the best I possibly can, because I think that’s the ethical, moral obligation of doing science or writing about science is not over-exaggerating it”
- We never did a randomized control trial to determine if smoking causes lung cancer
  - but it’s like a six sigma effect
  - Hard to imagine an alternative explanation for why smokers have such a hugely increased risk
- The problem is that if scientists are honest about the limitations of their research, they have fulfilled their obligation but people won’t change their behavior

> “And that’s the conflict of public health science. How do we get people to change their behavior when we really don’t know if they should?” —Gary Taubes

## Gary’s first foray into the bad science of nutrition [1:26:45]

**How Gary ended up writing about nutrition**

- Around 1998-99, he was freelancing and needed rent money so asked editors at *Science* if they had something he could write
- The first data on the [Dietary Approaches to Stop Hypertension (DASH)](https://en.wikipedia.org/wiki/DASH_diet) diet to stop hypertension was about to be published in the *New England Journal of Medicine*
  - A was a low fat diet with lots of fruits and vegetables
  - It was supposed to be a one-page article, for which a reporter would typically call the principal investigator (PI) if the article was not yet published and maybe two other people who could comment
- Gary didn’t know that the article had been leaked to *Science* in advance along with a list of researchers they could interview
- He called the PI, [Larry Appel](https://www.hopkinsmedicine.org/profiles/details/lawrence-appel)
- Then he calls a former president of the American Heart Association at the University of Alabama Birmingham
  - she says she can’t talk about the paper or she’ll lose funding
  - He asks her to tell him off the record what’s wrong with the paper so the article can be accurate, but she refuses
- Calls another researcher, who yells at him that there’s no controversy over salt and blood pressure even though that was not the topic of the article
- Gary spent the next 9 months looking into the salt / blood pressure debate
  - interviewed about 85 people
  - discovered that it was “one of the most vitriolic controversies in the history of medicine”
  - By 1998, Americans had been eating low-fat diets for 15-20 years, but randomized control evidence never really supported it
  - Involved a lot of bad epidemiology with questionable associations and no established causation
- The researcher who had yelled at him when he was writing the original article was a character who sounded exactly like [Walter Matthau](https://en.wikipedia.org/wiki/Walter_Matthau) over the telephone
  - It became clear to Gary that he “was one of the worst scientists I’d ever interviewed in my life”
  - He took credit for the reduction in both salt and fat in American diets
- Gary decided to write about dietary fat next because he “if the dogma was based in any substantive way on this fellow’s work, there’s a story there”
  - “I’ve been living in LA eating my egg whites and probably a 15% fat diet. [Dean Ornish](https://en.wikipedia.org/wiki/Dean_Ornish) would have been proud of me”
  - He interviewed 145 people for that article, [*The (Soft) Science of Dietary Fat*](https://science.sciencemag.org/content/291/5513/2536)
- That piece and the salt article, [*The (Political) Science of Salt*,](https://science.sciencemag.org/content/281/5379/898.summary) both won National Association of Science Writers Science and Society Awards

**Obesity**

- Gary wrote his biggest and most controversial [article](https://www.nytimes.com/2002/07/07/magazine/what-if-it-s-all-been-a-big-fat-lie.html) for the *New York Times Magazine*
- He wanted to write a book about whatever was happening in medical science that could lead to these kinds of mistakes
  - Nutrition seemed like an interesting vehicle through which to explore this question
  - But he was in debt and married and knew would not be able to get an advance large enough to cover the time it would take to write a book
- He and an editor at the *NYT* wanted to explore what caused the obesity epidemic
- When he was working on the fat story for *Science*, an NIH administrator told him that when they recommended low fat diets in 1984 there was no evidence of an association between fat and heart disease
  - In his article, Gary argued that the evidence never materialized
  - when people stopped eating fat and ate more carbohydrates, their weight increased
- Gary says the obesity epidemic coincides with two fundamental changes in the American diet
  - One is low fat, high carb diets being considered heart healthy (carbs had been considered fattening up until about the 1960s)
  - Second is high fructose corn syrup (HFCS), which became prevalent in the late 1970s
    - HFCS 55 was used to replace sugar in Coke and Pepsi and had saturated the beverage industry by about 1984
    - people like [Michael Pollan](https://en.wikipedia.org/wiki/Michael_Pollan) had suggested that high fructose corn syrup was the cause of the epidemic [1:36:00]

## Research implicating insulin’s role in obesity, and the story behind what led to Gary’s book, Good Calories, Bad Calories [1:36:15]

**Gary’s** ***NYT*** **article about obesity**

- In his [article](https://www.nytimes.com/2002/07/07/magazine/what-if-it-s-all-been-a-big-fat-lie.html), Gary discussed several not-yet-published studies
  - all found that people on the Atkins diet (low-carbohydrate, high-fat, unrestricted calories) lost more weight and had improved heart disease risk factors compared to those on the AHA’s recommended low-fat, calorie-restricted diet
  - The studies included [Eric Westman](https://medicine.duke.edu/faculty/eric-charles-westman-md)‘s [paper](https://pubmed.ncbi.nlm.nih.gov/12430970/) from one of his first trials
  - Two hypotheses of weight gain:
    - people get fat because they eat too much
    - people get heart disease because they eat high-fat foods
  - but neither of these fundamental hypothesis held up in the first 1-6 clinical trials
  - After Gary’s article came out, m,uc of the data he cited were published over the next 2-3 years
- Gary began to struggle with his own weight when he turned 30 and moved to California
  - At the same time, he was writing an article for *Discover Magazine* on the mathematics of the stock market
    - Was interviewing MIT economists about whether people like [Warren Buffett](https://en.wikipedia.org/wiki/Warren_Buffett) are brilliant or just lucky
    - “looking for the signal of talent over the signal of luck over the background of luck”
  - The MIT professor told him if he was writing about fat he had to try Atkins
    - He was Asian and lost 40 lbs giving up white rice
    - his collaborator’s father had lost 200 pounds on Atkins
  - Gary did Atkins as an experiment and lost 25 pounds in six weeks
  - But he eventually drifted off the diet
- “There’s a line in [the NYT article] that says overweight, of course, is caused by taking in more calories than you expend, which today I think is … both wrong and meaningless”
- Gary accepted the idea that these diets would not raise the risk of heart disease and felt that there was no compelling evidence to avoid saturated fats
- That article got Gary a large book advance for [*Good Calories, Bad Calories*](https://www.amazon.com/Good-Calories-Bad-Controversial-Science/dp/1400033462)
- He was accused of making controversial conclusions to sell books, but he says his advance only supported him for 4 years and it took 5 to write the book
- Gary says his thinking on the topic is still evolving: “I still wake up at three in the morning thinking, why didn’t I say that 13 years ago?”

In the book, Gary goes after two issues which are not mutually exclusive but they are related:

1– dietary saturated fat drives atherosclerosis

2 — the cause of obesity being calorie imbalance

- The dietary fat/heart story is that we get heart disease because the saturated fat content of the diet elevates LDL cholesterol
  - So seems like should replace fats with carbohydrates which should minimize your risk of heart disease
  - The flip side argument is the carbohydrate insulin model, which posits that carbs are fattening
    - Replace carbs with either protein or fat (a diet that should in theory kill you according to conventional thinking)
    - In real food, protein comes with fat, so you increase your fat consumption either way
    - One of the many arguments against Atkins is that people worried that the Atkins diet would trigger heart disease
- Gary’s book *Good Calories, Bad Calories*
  - The first third is about the evolution of the theory that dietary fat is the problem
    - doing the research, Gary realized that there had always been a competing hypothesis that the chronic diseases associated with modern diets are driven by the carbohydrate content
  - the second third is about this hypothesis
    - idea started with a British nutritionist, then work on insulin resistance by [Jerry Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) and others
    - factors include the quality and the type of carbohydrates we’re eating, the glycemic index, and the fructose content
  - The last third to half of the book is about the question of what causes obesity
    - It’s clearly tied to whatever causes heart disease and diabetes
    - pre-World War II European research indicated that obesity was a hormonal regulatory disorder rather than an energy-balance problem
    - post-World War II research found that hunger is driven by fuel availability
      - If your liver thinks there’s enough fuel available, you will not feel hungry
      - If the liver thinks you need fuel, it will promote food-seeking
    - This work all **implicated insulin** as the primary hormone determining fuel availability

## The history of obesity research, dietary fat, and fat metabolism [1:46:00]

- Evolution of our knowledge about fat
  - until 1930, no one studied fat tissue, which was assumed to be inert and used for padding and cushioning
  - Beginning in 1933, the German emigre [Rudolph Schoenheimer](https://en.wikipedia.org/wiki/Rudolph_Schoenheimer) at Columbia began to study it
  - Became aware that your body is constantly depositing and mobilizing calories as fat
  - By the mid-1960s, science of intermediary [metabolism](https://en.wikipedia.org/wiki/Metabolism) (how the body uses proteins, fats, carbohydrates, etc.) is well established
- The science of obesity focuses on energy imbalance
  - There’s an association between hunger and obesity
  - we assume causality while ignoring the entire science of fat metabolism
- Obesity research in the 1960s was dominated by psychiatrists and psychologists trying to get fat people to eat less
  - people like [Mickey Stunkard](https://en.wikipedia.org/wiki/Albert_Stunkard) were only trained in psychology
  - did not consider that obesity could be a hormonal dysregulation of fatty acid oxidation and storage
- In physics, there are too many bright people arguing about the data and not enough people outside the field to care, but in medicine, single individuals can wield a lot of power
  - [Elliott Joslin](https://en.wikipedia.org/wiki/Elliott_P._Joslin) opened the first dedicated diabetes clinic in the US around 1900
    - Wrote his first textbook, *Joslin’s Diabetes Mellitus*, in 1916 and we’re now on the 14th edition
    - This book, written by one doctor, became the arbiter of truth in the diabetes world
    - He was a wonderful doctor but not a great scientist
  - Another example is [William Halstead](https://en.wikipedia.org/wiki/William_Stewart_Halsted), the breast cancer surgeon from Johns Hopkins who developed the radical mastectomy procedure
- We can observe a connection between overeating obesity
  - Shakespeare’s character [Sir John Falstaff](https://en.wikipedia.org/wiki/John_Falstaff) is a classic example
  - But to assume causality from an association is classic pathological science
- Another theory is hormonal dysregulation: some people will get fat regardless of how much they eat
- In 1930, [Louis Newburgh](https://en.wikipedia.org/wiki/Louis_Harry_Newburgh) from the University of Michigan tested the hormonal hypothesis
  - He was like the [Issac Newton](https://en.wikipedia.org/wiki/Isaac_Newton) or Eddington of the field
  - Published a series of papers in the early 1930s in which he starved both lean and obese people and found that they lost weight at roughly the same rate
  - Concluded that obesity was caused by overeating and thought his experiment refuted the hormonal regulatory hypothesis
  - Newburgh’s papers begin to be taken as gospel
- In Europe, pioneers of the science of endocrinology like [Julius Bauer](https://geschichte.univie.ac.at/en/persons/julius-bauer-ao-univ-prof-dr) at the University of Vienna [question Newburgh’s conclusions](https://jamanetwork.com/journals/jamainternalmedicine/article-abstract/547135)
- In 1938, [Stephen Ranson and Albert Hetherington](https://books.google.com/books?id=p7v_nsdQaNkC&pg=PA50&lpg=PA50&dq=Ranson+Hetherington&source=bl&ots=dLSMtxfm5g&sig=ACfU3U3h11lD5f9hcJg3lwNz0JZqABhZWw&hl=en&sa=X&ved=2ahUKEwjxudS2x5rxAhUfVzABHQs-CwIQ6AEwDnoECBkQAw#v=onepage&q=Ranson%20Hetherington&f=false) develop the first animal model of obesity
  - Use a stereotaxic instrument that directs a needle into the animal’s brain
  - Show that a lesion in the [ventromedial hypothalamus](https://en.wikipedia.org/wiki/Ventromedial_nucleus_of_the_hypothalamus) (VMH) of a rat’s brain reproducibly results in obesity
- In 1939, [John Brobeck](https://www.med.upenn.edu/asef/dr.-brobeck.html) at Yale discovers when he calls hyperphagic obesity
  - A rat with a VMH lesion had an insatiable appetite, trying to eat even as they’re coming out of anesthesia
  - but have to wait for anesthesia to fully wear off because they would choke to death

## The evolving understanding of the role of fat metabolism in obesity and weight gain [1:55:15]

- Peter clarifies a point about the obesity experiments:
  - It’s undeniable that if there is a lesion in the VMH, the animal eats in an uncontrolled manner
  - if your hypothesis is that overeating leads to obesity, you will interpret it as: lesioning that part of the brain leads to overeating
  - If your hypothesis is that dysregulated fat accumulation leads to obesity, you would interpret it as: lesioning that part of the brain leads to dysregulated fat accumulation, which then causes overeating
  - Need to have the proper controls
- Hetherington, Ranson, and Brobeck all had animals that became obese independent of the hyperphagia
- Brobeck did an experiment where he pair-fed a lesioned and a non-lesioned animal
  - 3 of 12 got fatter, which Brobeck assumed meant something was wrong with those 3, so he left them out of the analysis
  - “But they’re the evidence for this counter-hypothesis [that] something about the lesion dysregulates fat accumulation”
  - What explains the other 9?
    - We could dysregulate the fat tissue of an animal that is otherwise normal so that it will now store excess fat
    - But if we’re also restricting calories, you might not see that effect
  - The counter-argument to the hyperphagia causes obesity evidence is obesity being caused in the absence of hyperphagia
- Ranson had been studying [diabetes insipidus](https://en.wikipedia.org/wiki/Diabetes_insipidus), which can be deliberately caused by lesioning a different part of the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus)
  - Makes animals extremely thirsty and peeing constantly
  - Conventional wisdom might say they’re peeing so much because they’re so thirsty
  - the counter-hypothesis is that the lesion causes them to pee constantly, so they’re losing body water and that makes them thirsty
  - We now know that diabetes insipidus is the result of the loss of a hormone called [antidiuretic hormone](https://en.wikipedia.org/wiki/Vasopressin), aka arginine vasopressin (AVP)
  - The hyper-drinking is an attempt to replenish the water they’re losing because they can’t concentrate urine
- Ranson wondered if fat issues was similar to drinking in diabetes insipidus
  - the animals might be losing energy into their fat tissue and eating more (or exercising less) in response
  - changes in energy balance are a response to the fat tissue being driven to accumulate calories or fat calories
- Ranson and Hetherington published a [paper](https://onlinelibrary.wiley.com/doi/abs/10.1002/cne.900760308) on this in 1942
  - Then Ranson died and Hetherington left to fight in WWII, leaving the research to Brobeck, who dismissed their hypothesis without really understanding it
  - “He still thinks they’re trying to blame obesity on sedentary behavior because he’s trapped in this energy balance thinking. He doesn’t realize that they’re trying to blame both the sedentary behavior and the hyperphagia on the drive to accumulate fat, which is the fundamental[ly] different paradigm”
- Thanks to Newburgh and Brobeck, by the 1950s the conventional wisdom is that people are fat because they eat too much
- By the 1960s, the leading figures in the field are psychologists and psychiatrists who are trying to explain why fat people eat too much and how to stop them
- physiologists and biochemists are studying the regulation of fat metabolism
  - discover that the deposition and mobilization of fat go on independent of the nutritional state of the organism
  - Some researchers pointed out that what should be studied is not how much people eat and exercise but why they accumulate so much fat
- Peter wonders how a lesion to a very specific narrow part of the brain results in such a broad, peripheral consequence of fat hoarding within all of the adipose tissue throughout the body
  - The first observable effect from the VMH lesion is hypersecretion of insulin resulting in hyperinsulinemia
  - the insulin is inhibiting [lipolysis](https://en.wikipedia.org/wiki/Lipolysis) and signaling fat tissue to take up fat and to store it for food
  - It’s also inhibiting the [oxidation](https://en.wikipedia.org/wiki/Redox) of [fatty acids](https://en.wikipedia.org/wiki/Fatty_acid) in the muscle tissue to the [malonyl-CoA](https://en.wikipedia.org/wiki/Malonyl-CoA_decarboxylase) pathway
- Animals wake up from surgery very hungry because they are unable to oxidize dietary fat and have no carbohydrate supply
  - “It’s as though you’ve created a starvation state in the animal instantaneously”
  - Increase in insulin was enormous, but Gary does not know the specific numbers
- After 1960, you had radium assays
  - could accurately measure insulin levels from blood samples
  - Showed that VMH lesioned animals were hyperinsulinemic

## Mutant mice experiments giving way to competing theories about obesity [2:04:00]

- Mutant mice strains
  - The ob/ob mouse, developed at the Jackson Laboratories in Maine, is a mutant that develops dramatic obesity
  - The db/db mouse is diabetic as well as obese
- Often make assumption that they’re missing some kind of satiety hormone
- Hypotheses about eating too much
  - the [lipostat hypothesis](https://quizlet.com/208556096/obesity-iii-flash-cards/#:~:text=Lipostat%20Hypothesis%3A%20regulation%20of%20weight%20around%20a%20set%20point.&text=Liposat%20resists%20body%20weight%20changes%20by%20balancing%20food%20intake%20and%20energy%20expenditure.&text=The%20set%20point%20is%20determined,to%20long%2Dterm%20weight%20gain.) (body has a set weight point it seeks to maintain through balancing of food intake and energy expenditure) proposed by [Gordon Kennedy](https://www.ssib.org/web/classic15.php)
  - the [glucostat hypothesis](https://diabetes.diabetesjournals.org/content/diabetes/65/9/2473.full.pdf) (blood glucose acts on hypothalamic glucose-sensing neurons as a satiety signal) proposed by [Jean Mayer](https://en.wikipedia.org/wiki/Jean_Mayer)
  - a [thermostat hypothesis](https://www.sciencedaily.com/releases/2015/03/150318144843.htm) (body heat)
  - but none of these is right, as you can show by pair feeding two animals the same amount
- this experiment has been done in the ob/ob mice
  - ob/ob mice given half of what a lean mouse eats become obese anyway
- The work of [Douglas Coleman](https://en.wikipedia.org/wiki/Douglas_L._Coleman), and later [Jeff Friedman](https://en.wikipedia.org/wiki/Jeffrey_M._Friedman) building on it, identified [leptin](https://en.wikipedia.org/wiki/Leptin) as the dysfunctional hormone in the ob/ob animal
  - Jeff Friedman hypothesized that a signal from the fat tissue to the brain, telling the brain not to eat too much, was missing
  - He deemed leptin “the satiety hormone”
  - Books like [*The Hungry Brain*](https://www.amazon.com/Hungry-Brain-Outsmarting-Instincts-Overeat/dp/125008119X) assume that the absence of leptin makes a brain hungry
  - But we know from experiments that the animal gets fat even when it’s half starved
- Gary wondered why the absence of a leptin receptor would cause diabetes in db/db mice
  - [Rudy Leibel](https://en.wikipedia.org/wiki/Rudolph_Leibel) told him it would depend what background you breed the animal onto
  - Douglas Coleman discussed this in his work
  - Both ob/ob and db/db animals are hyperinsulinemic from weaning onward
  - in the db/db animals, the background strain can sustain the hyperinsulinemia, so its pancreas fails and it manifest frank diabetes
  - ob/ob strain can continue to keep producing the necessary insulin
- leptin is essentially triggering hyperinsulinemia, bringing us back to the Bauer-Ranson-Hetherington hypothesis
  - but everyone was used to the Brobeck-Newburgh “eating too much” hypothesis
  - This influenced how virtually every experiment afterwards, including the leptin work, was interpreted
  - A lot of evidence supports the alternative hypothesis, but it hasn’t been considered for 60-70 years

## How Gary thinks about the findings that do not support his alternative hypothesis about obesity [2:08:00]

- Gary’s work led to a number of studies testing the Bauer-Ranson hypothesis
  - But the results have not been what the carbohydrate insulin model would predict
  - Gary says you have to consider the value and rigor of the experiments and the biases and preconceptions of the researchers
- NuSI funded two groups of researchers
  - One had a hypothesis that dietary fat and fat balance was a driver of obesity
  - The other had a carbohydrate insulin model like we did

“And the researchers who believe the conventional wisdom interpreted their results as supporting the conventional wisdom and refuting the carbohydrate insulin model, and the researchers who believed the carbohydrates insulin model interpreted their results as supporting that model”

- Peter wonders how this field can make any progress when everyone seems to be doing experiments that confirm their point of view
- He also points out that biology is inherently messy
  - we don’t have a standard model of biology the way we have a standard model of physics
  - there are more unknown unknowns in biology
  - in addition, the experiments are far more difficult to control
    - there’s more “noise” in the biologic experiments
- We’re still having the same arguments 8-10 years after NuSI started
- Around 2009 after *Good Calories, Bad Calories* came out, Gary gave a lecture at the [Pennington Biomedical Research Center](https://www.pbrc.edu/), the largest obesity research center in the country
  - He said that the that the energy balance hypothesis was (borrowing a phrase from [Wolfgang Pauli)](https://en.wikipedia.org/wiki/Wolfgang_Pauli) “not even wrong”
  - A faculty member asked him if he thought they were all idiots

> “I think the problem here is that when you entered the field, there was a paradigm, a way of thinking about obesity. It seemed so intuitively obvious, this idea that it’s an energy balance disorder, that you never questioned it. … You assumed this had been well tested and well-proven and unambiguous and that it deserved to be dogma, and it hadn’t been, and it didn’t. And that’s been a problem ever since.” —Gary Taubes

- 40-50 years later “we have to get a huge proportion of the community to entertain the possibility that their fundamental belief system is wrong”

- How does Gary know he’s not a quack? He pointed out to his old colleague [Mark Friedman](https://nusi.org/about-us/leadership/) that every quack thinks they’re right
- Peter points out that the application of the current model is failing, which is a compelling reason to continue to question it
  - If we believed that the Earth was the center of the universe but every attempted rocket launch failed, we ought to ask, “what if the Earth is actually moving even though it doesn’t feel like it?”
  - The obesity and diabetes epidemics are out of control, so we need to question these fundamental hypotheses
- Also problem of people having a hard time sticking with a diet long term
- The NIH is now leaning towards precision nutrition (individualized nutritional therapy)

## Challenges with addressing the obesity and diabetes epidemics, palatability and convenience of food, and other hypotheses [2:14:45]

- Obesity and diabetes result in $1 billion a year in direct medical costs
  - We must figure out where we failed to control these epidemics and not reject any reasonable hypothesis
  - But hard to say who would do this research since obesity researchers and nutritionists all have biases
- So much effort and money was put into COVID – we need to do that for diabetes and obesity-related diseases that kill 10 times as many people

> “We have to question our assumptions. Who actually does that job? There’s a lot of very intelligent critical thinkers out there. The question is, how do you get them to care?” — Gary Taubes

- Peter says that some people would argue that palatability, availability, and affordability of food are driving this equation, as well as the conveniences of modern life reducing physical activity
- The solutions to those problems would be through policy, not scientific research
- Two examples
  - As Peter was binging on Cool Ranch Doritos, he was jokingly thinking that the crunch, taste, etc. were “almost as impressive as the Apollo 11 program from an engineering perspective”
  - Gary had the opposite experience: a $170-per-pound Wagyu sashimi steak that was about 80% fat and was so filling he couldn’t finish an 8-oz steak
  - Gary wonders if he dysregulated his fat tissue by eating the steak the way Peter might be doing eating the Doritos
  - Was Peter’s hyperphagia driven by the palpability of the Doritos or the peripheral response to the macronutrient composition (or central response to an expected peripheral change)?
  - Gary thinks it’s much more than a Dorito-induced effect
- Some theories hold that we’re just going to get fat no matter how much we eat
  - [George Bernard Shaw](https://en.wikipedia.org/wiki/George_Bernard_Shaw) had his own opinion on this issue: [“No diet will remove all the fat from your body because the brain is entirely fat. Without a brain, you might look good, but all you could do is run for public office](https://www.inspiringquotes.us/quotes/xI7s_U0pafckg)”
  - If we’re pre-programed to get fat, Gary would argue that Doritos would trigger it but the Wagyu, which has far more calories, does not
- [Michael Moss](https://en.wikipedia.org/wiki/Michael_Moss) has written [two](https://www.amazon.com/Salt-Sugar-Fat-Giants-Hooked/dp/1400069807/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) [books](https://www.amazon.com/Hooked-Food-Giants-Exploit-Addictions/dp/0812997298/ref=pd_bxgy_img_1/139-2451850-0250862?pd_rd_w=K051W&pf_rd_p=fd3ebcd0-c1a2-44cf-aba2-bbf4810b3732&pf_rd_r=SRABQRRH1EY1JQ1EE1E3&pd_rd_r=4ab65ef4-cd5c-4ff2-9a05-f04d4f98fa2e&pd_rd_wg=90Ejz&pd_rd_i=0812997298&psc=1) that got a lot of publicity because he blames industry, which Gary says is easy to do
  - “When I was blaming the industry, people love what I do. As soon as I shift to blaming the scientific community for doing unacceptable science, then I have trouble getting the message heard”
- It’s an ongoing challenge and Gary does not know how to get those who fund research to question their assumptions
  - Problems with how we fund research in this country
  - Award small R01 grants of $500,000 a year for five years to what [Thomas Kuhn](https://en.wikipedia.org/wiki/Thomas_Kuhn) would have called “[normal science](https://en.wikipedia.org/wiki/Normal_science)”

> “There is no method by which paradigms are questioned and research programs can shift. There’s an assumption that it could happen naturally … but the way we fund research in this country doesn’t actually allow that to happen.” —Gary Taubes

- If there’s money in it, then you can take advantage of the opportunities that other people might be missing
  - [Virta Health](https://www.virtahealth.com/), advocating using nutritional ketosis to treat type 2 diabetes
  - [Diet Doctor](https://www.dietdoctor.com/)
- But Gary does not know how to get NIH Director [Francis Collins](https://en.wikipedia.org/wiki/Francis_Collins) or even local podcasters to care or how to get the NIH to do anything about it
- A very recent *Science* [article](https://science.sciencemag.org/content/372/6542/577) by [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) and [Kevin Hall](https://irp.nih.gov/pi/kevin-hall) argued that this carbohydrate insulin model of obesity has been tested and failed
  - Gary says they are only looking at a fraction of the evidence and left out other studies with different results
  - But even if the article is right, it avoids addressing the elephant in the room, which is our failure to address the obesity and diabetes epidemics
- Peter thinks the article was not a public health paper and focused more on trying to understand the mechanistic aspects of obesity
  - Kevin Hall came in as more of an outsider, which does allow him a fresh perspective

## Challenging the energy balance hypothesis, and the difficulty of doing good nutrition studies [2:25:00]

- - Gary was introduced to Kevin Hall by [Mitch Lazar](https://en.wikipedia.org/wiki/Mitchell_Lazar) at Penn because he thought they saw the problem in similar ways at the time
  - Gary later introduced Kevin to to Peter
  - Their views became more complicated through the course of their interactions with the [Energy Balance Consortium](https://nusi.org/research/energy-balance-consortium-pilot-study/)
    - Kevin’s model discounted Gary’s theory
    - “One of the fundamental problems with pathological science is you establish what you believe based on premature data”
    - Gary thinks that Kevin did not consider multiple hypotheses as a possible explanation for his results, and he ended up trying to support rather than test his hypothesis
    - As Gary and Kevin conflicted, they each might have locked in their biases more
  - Peter says some of the critique has been around the different types of methodologies used to measure energy expenditure

- [*Indirect calorimetry*](https://en.wikipedia.org/wiki/Indirect_calorimetry)

- - - - sit inside of a medical grade, hermetically sealed chamber that can measure inhaled carbon dioxide at very minute levels and calculate the consumption of oxygen
      - the ratio of those things allows us to calculate very precisely the amount of energy consumed

- [*Doubly labeled water*](https://en.wikipedia.org/wiki/Doubly_labeled_water) *(DLW)*

- - - drink two types of water: heavily labeled oxygen and deuterium
    - by collecting urine over a period of days following that ingestion, you can estimate energy expenditure in a free-living environment
- [Different experiments](https://nusi.org/research/energy-balance-consortium-pilot-study/) have been done through NuSI
  - The energy balance hypothesis experiment used calorimetry, which is more precise
  - The carbohydrate insulin model was tested with a longer study using doubly labeled water
- But the method of doubly labeled water is not valid in people who are carbohydrate restricted, which could explain the otherwise irreconcilable results
  - the researchers doubted they’d be able to see an effect on fat mass in the course of four weeks, so measuring fat mass directly by [dual-energy X-ray absorptiometry](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry) (DXA) wasn’t a possibility
  - so measured energy expenditure instead
  - In any case, DXA was going to be confounded by water loss, so it might not have been valid when someone was transitioning from a low fat to a very low carbohydrate diet
  - But that measurement has been used in recent NIH papers
- Calorimetry and DLW give you two different results, one of which is more consistent with each hypothesis
  - Results not robust of comparing results measured two different ways
  - It’s possible that the chamber is the gold standard, but also possible that the divergent results indicate an experimental problem
- This is probably not a resolvable debate at this point

> “I keep doing what I’m doing because I’m hoping I can motivate people to think more deeply about this and to resolve this issue. I don’t think meaningful progress will be made on obesity without understanding the fundamental cause and without elucidating how treatments are working.” —Gary Taubes

- Gary thinks the [glucagon-like peptide-1 receptor (GLP-1) agonists](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1_receptor_agonist) are are an interesting potential treatment
- Obesity is both a public health and a scientific issue
- When Gary started 20 years ago, conventional wisdom was that low carb, high fat diets were deadly, causing heart disease and making you fatter
  - But today the American Diabetes Association recommends these diets for type 2 diabetics (~10% of the public)
  - Many people acknowledge that they can be beneficial for weight control
- clinicaltrials.gov lists over 200 trials studying the effects of ketogenic diets on epilepsy, diabetes, cancer, Alzheimer’s, and even traumatic brain injury
  - people are now more aware that ketogenic diets are an option and that they won’t kill you
  - researchers also find the clinical efficacy of these diets worth studying
  - today they make statements that would have been considered unacceptable 20 years ago, including the acceptance that insulin plays a major role in fat accumulation and obesity
- But many argue that it’s just not the role that Gary and [David Ludwig](https://en.wikipedia.org/wiki/David_Ludwig_(physician)) think it is
- Peter thinks it’s interesting that Gary stumbled into health sciences almost accidentally and believes that a lot of good has come of it

§

## Selected Links / Related Material

**Gary’s books:** [Intro]

- [The Case for Keto: Rethinking Weight Control and the Science and Practice of Low-Carb/High-Fat Eating](https://www.amazon.com/Case-Keto-Rethinking-Practice-Low-Carb/dp/0525520066/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2020)
- [The Case Against Sugar](https://www.amazon.com/Case-Against-Sugar-Gary-Taubes/dp/0307946649/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1623682218&sr=1-1) (2016)
- [Why We Get Fat: And What to Do About It](https://www.amazon.com/Why-We-Get-Fat-About/dp/0307272702/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1623682286&sr=1-1) (2010)
- [Good Calories, Bad Calories: Challenging the Conventional Wisdom on Diet, Weight Control, and Disease](https://www.amazon.com/Good-Calories-Bad-Challenging-Conventional/dp/1400040787/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1623682373&sr=1-3) (2007) | [1:24:45, 1:41:45, 1:44:45, 2:10:45]
- [Bad Science: The Short Life and Weird Times of Cold Fusion](https://www.amazon.com/Bad-Science-Short-Weird-Fusion/dp/0394584562) (1993) | [47:30, 56:45, 1:08:30, 1:32:00]
- [Nobel Dreams: Power, Deceit, and the Ultimate Experiment](https://www.amazon.com/Nobel-Dreams-Deceit-Ultimate-Experiment-dp-0394545036/dp/0394545036/ref=mt_other?_encoding=UTF8&me=&qid=) (1987) | [25:15, 46:15, 54:00, 1:19:30, 1:32:00]

**Book that inspired Gary’s journalism career**: [All the President’s Men](https://en.wikipedia.org/wiki/All_the_President%27s_Men) by Carl Bernstein and Bob Woodward (1974) |  [5:45]

**Gary’s colleague’s article on the dangers of boxing**: [Death by Boxing](https://www.newspapers.com/newspage/462665838/) | Denise Grady, *San Francisco Examiner* (January 9, 1983) | [14:00]

**Gary’s article on competing in the Golden Gloves boxing competition**: [Life as a standing eight count](https://peterattiamd.com/wp-content/uploads/2021/07/eightcountarticle.pdf) | Gary Taubes, *Playboy* (July 1984) | [14:30]

**Books for which James Gleick is known**: [22:00]

- [Chaos: Making a New Science](https://en.wikipedia.org/wiki/Chaos:_Making_a_New_Science) (1987)
- [Genius: The Life and Science of Richard Feynman](https://www.amazon.com/Genius-Life-Science-Richard-Feynman/dp/0679408363/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (1992)

**Stephen Hall’s book**: [A Commotion in The Blood](https://www.amazon.com/Commotion-Blood-Immune-System-Technology/dp/0805037969) by Stephen S. Hall (1997) | [22:30]

**Book Gary praises as exemplary scientific writing**: [The Ghost Map](https://www.amazon.com/Ghost-Map-Londons-Terrifying-Epidemic/dp/1594489254/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Steven Johnson (2006) | [23:00]

**Guide to understanding the concept of sigma in particle physics**: [5 Sigma: What’s That?](https://blogs.scientificamerican.com/observations/five-sigmawhats-that/) | Evelyn Lamb, *Scientific American* (July 17, 2012) | [35:20]

**Christopher Lehmann-Haupt’s critique of** ***Nobel Dreams***: [Books of the Times: Nobel Dreams](https://timesmachine.nytimes.com/timesmachine/1987/01/29/556387.html?pageNumber=77) | Christopher Lehmann-Haupt, New York Times (January 29, 1987) | [53:15]

**Pons and Fleischmann’s original announcement about cold fusion**: [Preliminary Note: Electrochemically induced nuclear fusion of deuterium](https://www.sciencedirect.com/science/article/abs/pii/0022072889800063?via%3Dihub) | *Journal of Electroanalytical Chemistry and Interfacial Electrochemistry* (Fleischmann and Pons 1989) | [56:45]

**Original WSJ story on cold fusion**: Breakthrough in Fusion May Be Announced | Jerry Bishop, *Wall Street Journal* (March 23 1989) | [59:45]

**Langmuir’s talk on pathological science**: [Colloquium on Pathological Science](https://www.cs.princeton.edu/~ken/Langmuir/langmuir.htm) | Irving Langmuir (December 18, 1953) | [1:02:45]

**Judson’s history of the molecular biology revolution**: [The Eighth Day of Creation: Makers of the Revolution in Biology](https://www.amazon.com/Eighth-Day-Creation-Revolution-Biology/dp/0879694777/ref=tmm_hrd_title_0?_encoding=UTF8&qid=&sr=) by Horace Freeland Judson (1979) | [01:09:30]

**Gary’s article on power lines and cancer**: [Fields of Fear](https://peterattiamd.com/wp-content/uploads/2021/07/Fields-of-Fear-The-Atlantic-1993.pdf) | Gary Taubes, *The Atlantic Monthly* (November 1994) | [1:10:45]

**Richard Feynman’s commencement speech at Caltech**: [Cargo Cult Science](https://calteches.library.caltech.edu/3043/1/CargoCult.pdf) | Richard Feynman, *Caltech* (1974) | [1:25:00]

**Gary’s article on dietary salt**: [The (Political) Science of Salt](https://science.sciencemag.org/content/281/5379/898.summary) | Gary Taubes, *Science* (August 14, 1998) | [1:32:45]

**Gary’s article on dietary fat**: [The (Soft) Science of Dietary Fat](https://science.sciencemag.org/content/291/5513/2536) | Gary Taubes, *Science* (March 30, 2001) | [1:32:45]

**Gary’s article on obesity for the** ***NYT Magazine***: [What if It’s All Been a Big Fat Lie?](https://www.nytimes.com/2002/07/07/magazine/what-if-it-s-all-been-a-big-fat-lie.html) | Gary Taubes, *New York Times Magazine* (July 7, 2002) | [1:33:11]

**Paper mentioned in preprint form in Gary’s** ***NYT*** **article**: [Very-low-carbohydrate weight-loss diets revisited](https://pubmed.ncbi.nlm.nih.gov/12430970/) | *Cleveland Clinic Journal of Medicine* (Volek & Westman 2002) | [1:33:11]

**Julius Bauer’s paper questioning the energy theory of obesity**: [Obesity: its pathogenesis, etiology and treatment](https://jamanetwork.com/journals/jamainternalmedicine/article-abstract/547135) | *Archives of Internal Medicine* (Bauer 1941) | [1:52:45]

**Ranson and Hetherington’s influential paper**: [The relation of various hypothalamic lesions to adiposity in the rat](https://onlinelibrary.wiley.com/doi/abs/10.1002/cne.900760308) | *Journal of Comparative Neurology* (Hetherington & Ranson 1942) | [1:53:00]

**Book framing hunger as an absence of leptin**: [*The Hungry Brain*: *Outsmarting the Instincts That Make Us Overeat*](https://www.amazon.com/Hungry-Brain-Outsmarting-Instincts-Overeat/dp/125008119X) by Stephan J. Guyenet (2017) | [2:06:30]

**Michael Moss’s books**: [2:20:45]

- [Salt Sugar Fat: How the Food Giants Hooked Us](https://www.amazon.com/Salt-Sugar-Fat-Giants-Hooked/dp/1400069807/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2013)
- [Hooked: Food, Free Will, and How the Food Giants Exploit Our Addictions](https://www.amazon.com/Hooked-Food-Giants-Exploit-Addictions/dp/0812997298/ref=pd_bxgy_img_1/139-2451850-0250862?pd_rd_w=K051W&pf_rd_p=fd3ebcd0-c1a2-44cf-aba2-bbf4810b3732&pf_rd_r=SRABQRRH1EY1JQ1EE1E3&pd_rd_r=4ab65ef4-cd5c-4ff2-9a05-f04d4f98fa2e&pd_rd_wg=90Ejz&pd_rd_i=0812997298&psc=1) (2021)

**Science article arguing against the carbohydrate insulin model of obesity**: [Carbohydrates, insulin, and obesity](https://science.sciencemag.org/content/372/6542/577) | *Science* (Speakman & Hall 2021) | [2:24:15]

§

## People Mentioned

- [Bob Woodward](https://en.wikipedia.org/wiki/Bob_Woodward) [5:45]
- [Carl Bernstein](https://en.wikipedia.org/wiki/Carl_Bernstein) [5:45]
- [Daniel Kahneman](https://en.wikipedia.org/wiki/Daniel_Kahneman) [13:00]
- [Amos Tversky](https://en.wikipedia.org/wiki/Amos_Tversky) [13:00]
- [Duk-Koo Kim](https://en.wikipedia.org/wiki/Kim_Duk-koo) [13:30]
- [Ray Mancini](https://en.wikipedia.org/wiki/Ray_Mancini) [13:30]
- [Denise Grady](https://www.nytimes.com/by/denise-grady) [14:00]
- [Norman Mailer](https://en.wikipedia.org/wiki/Norman_Mailer) [14:15]
- [C. Michael Curtis](https://www.theatlantic.com/magazine/archive/2005/06/the-man-behind-the-stories/304143/) [18:30, 19:00, 19:30]
- [Thomas Pynchon](https://en.wikipedia.org/wiki/Thomas_Pynchon) [18:30]
- [Dick Fariña](https://en.wikipedia.org/wiki/Richard_Fari%C3%B1a) [18:30]
- [Calvin Trillin](https://en.wikipedia.org/wiki/Calvin_Trillin) [20:30]
- [Wilt Chamberlain](https://en.wikipedia.org/wiki/Wilt_Chamberlain) [21:15]
- [Stephen Curry](https://en.wikipedia.org/wiki/Stephen_Curry) [21:15]
- [Ed Yong](https://en.wikipedia.org/wiki/Ed_Yong) [21:30]
- [James Gleick](https://en.wikipedia.org/wiki/James_Gleick) [22:00]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) [22:00, 41:15, 1:24:30]
- [Charles Mann](https://en.wikipedia.org/wiki/Charles_C._Mann) [22:30]
- [Stephen S. Hall](https://jem.utk.edu/2012/07/16/stephen-s-hall-award-winning-new-york-times-magazine-writer-2012-hill-lecturer) [22:30]
- [John Tierney](https://en.wikipedia.org/wiki/John_Tierney_(journalist)) [22:30]
- [Steven Johnson](https://en.wikipedia.org/wiki/Steven_Johnson_(author)) [23:14]
- [John Snow](https://en.wikipedia.org/wiki/John_Snow) [23:30]
- [Carlo Rubbia](https://en.wikipedia.org/wiki/Carlo_Rubbia) [25:30, 26:45, 27:45, 30:00, 32:15, 38:15, 39:00, 43:30, 48:15, 51:15]
- [Robert Crease](https://en.wikipedia.org/wiki/Robert_P._Crease) [29:00]
- [Sheldon Glashow](https://en.wikipedia.org/wiki/Sheldon_Lee_Glashow) [29:15]
- [Donald Rumsfeld](https://en.wikipedia.org/wiki/Donald_Rumsfeld) [34:45]
- [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) [36:24]
- [Arthur Eddington](https://en.wikipedia.org/wiki/Arthur_Eddington) [36:24]
- [Christopher Lehmann-Haupt](https://en.wikipedia.org/wiki/Christopher_Lehmann-Haupt) [53:15]
- [Jeremy Bernstein](https://en.wikipedia.org/wiki/Jeremy_Bernstein) [53:15]
- [Stanley Pons](https://en.wikipedia.org/wiki/Stanley_Pons) [53:45, 55:30, 57:15, 1:01:15, 1:06:45, 1:07:40]
- [Martin Fleischmann](https://en.wikipedia.org/wiki/Martin_Fleischmann) [53:45, 55:30, 57:15, 1:01:00, 1:06:45, 1:07:40]
- [Steven Jones](https://en.wikipedia.org/wiki/Steven_E._Jones) [57:45, 1:01:15]
- [Chase Peterson](https://en.wikipedia.org/wiki/Chase_N._Peterson) [58:30]
- [Jerry Bishop](https://www.nasw.org/article/memoriam-jerry-e-bishop) [59:45]
- [Irving Langmuir](https://en.wikipedia.org/wiki/Irving_Langmuir) [1:02:59]
- [Horace Freeland Judson](https://en.wikipedia.org/wiki/Horace_Freeland_Judson) [01:09:30]
- [Alvan Feinstein](https://en.wikipedia.org/wiki/Alvan_Feinstein) [1:11:30, 1:12:00]
- [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis) [1:11:45]
- [Francis Bacon](https://en.wikipedia.org/wiki/Francis_Bacon) [1:14:01]
- [Guido Atarelli](https://en.wikipedia.org/wiki/Guido_Altarelli) [1:19:45]
- [Lawrence Appel](https://www.hopkinsmedicine.org/profiles/details/lawrence-appel) [1:28:45]
- [Walter Matthau](https://en.wikipedia.org/wiki/Walter_Matthau) [1:31:15]
- [Dean Ornish](https://en.wikipedia.org/wiki/Dean_Ornish) [1:32:30]
- [Michael Pollan](https://en.wikipedia.org/wiki/Michael_Pollan) [1:36:00]
- [Eric Westman](https://medicine.duke.edu/faculty/eric-charles-westman-md) [1:38:00]
- [Gerald Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) [1:44:30]
- [Rudolph Schoenheimer](https://en.wikipedia.org/wiki/Rudolph_Schoenheimer) [01:46:30]
- [Albert “Mickey” Stunkard](https://en.wikipedia.org/wiki/Albert_Stunkard) [1:48:30]
- [William Halstead](https://en.wikipedia.org/wiki/William_Stewart_Halsted) [1:50:15]
- [Louis Newburgh](https://en.wikipedia.org/wiki/Louis_Harry_Newburgh) [1:51:00, 1:52:15, 1:55:15, 2:00:45, 2:04:45, 2:04:45, 2:07:45]
- [Julius Bauer](https://geschichte.univie.ac.at/en/persons/julius-bauer-ao-univ-prof-dr) [1:52:15, 2:07:45, 2:08:00]
- [Stephen Ranson](https://books.google.com/books?id=p7v_nsdQaNkC&pg=PA50&lpg=PA50&dq=Ranson+Hetherington&source=bl&ots=dLSMtxfm5g&sig=ACfU3U3h11lD5f9hcJg3lwNz0JZqABhZWw&hl=en&sa=X&ved=2ahUKEwjxudS2x5rxAhUfVzABHQs-CwIQ6AEwDnoECBkQAw#v=onepage&q=Ranson%20Hetherington&f=false) [1:53:11, 1:55:15, 1:56:30, 1:58:00, 1:59:00, 2:07:45]
- [Albert Hetherington](https://books.google.com/books?id=p7v_nsdQaNkC&pg=PA50&lpg=PA50&dq=Ranson+Hetherington&source=bl&ots=dLSMtxfm5g&sig=ACfU3U3h11lD5f9hcJg3lwNz0JZqABhZWw&hl=en&sa=X&ved=2ahUKEwjxudS2x5rxAhUfVzABHQs-CwIQ6AEwDnoECBkQAw#v=onepage&q=Ranson%20Hetherington&f=false) [1:53:11, 1:55:15, 1:56:30, 1:58:00, 1:59:00, 2:07:45]
- [John Brobeck](https://www.med.upenn.edu/asef/dr.-brobeck.html) [1:53:30, 1:55:00, 1:56:45, 2:00:00, 2:07:00]
- [Gordon Kennedy](https://www.ssib.org/web/classic15.php) [2:05:00]
- [Jean Mayer](https://en.wikipedia.org/wiki/Jean_Mayer) [2:05:00]
- [Douglas Coleman](https://en.wikipedia.org/wiki/Douglas_L._Coleman) [2:05:45]
- [Jeffrey Friedman](https://en.wikipedia.org/wiki/Jeffrey_M._Friedman) [2:05:45]
- [Rudolph Leibel](https://en.wikipedia.org/wiki/Rudolph_Leibel) [2:07:00]
- [Wolfgang Pauli](https://en.wikipedia.org/wiki/Wolfgang_Pauli) [2:11:00]
- [Mark Friedman](https://nusi.org/about-us/leadership/) [2:12:30]
- [George Bernard Shaw](https://en.wikipedia.org/wiki/George_Bernard_Shaw) [2:20:30]
- [Michael Moss](https://en.wikipedia.org/wiki/Michael_Moss) [2:20:45]
- [Thomas Kuhn](https://en.wikipedia.org/wiki/Thomas_Kuhn) [2:22:30]
- [Francis Collins](https://en.wikipedia.org/wiki/Francis_Collins) [2:23:15]
- [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) [2:24:15]
- [Kevin Hall](https://irp.nih.gov/pi/kevin-hall)  [2:24:15]
- [Mitchell Lazar](https://en.wikipedia.org/wiki/Mitchell_Lazar) [2:25:00]
- [David Ludwig](https://en.wikipedia.org/wiki/David_Ludwig_(physician)) [2:37:00]

§

![](https://peterattiamd.com/wp-content/uploads/2021/07/bio-garytaubes.jpeg)

##### Gary Taubes, M.S., M.J.

Gary Taubes is an investigative science and health journalist and co-founder of the non-profit Nutrition Science Initiative (NuSI.org). He is the author of numerous books, including *The Case For Keto* (2020), *The Case Against Sugar* (2016), *Why We Get Fat: And What to Do About It* (2010), *Good Calories, Bad Calories* (2007), *Bad Science* (1993), and *Nobel Dreams* (1987).  Taubes is the recipient of a Robert Wood Johnson Foundation Investigator Award in Health Policy Research and has won numerous other awards for his journalism, including the International Health Reporting Award from the Pan American Health Organization. He also received the National Association of Science Writers Science in Society Journalism Award in 1996, 1999 and 2001, becoming the first print journalist to win this award three times. Taubes graduated from Harvard College with an undergraduate degree in applied physics, received an master’s degree in engineering from Stanford University, and earned a degree in journalism from Columbia University.

Website: <https://garytaubes.com/>

Twitter: [@garytaubes](https://twitter.com/garytaubes?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)