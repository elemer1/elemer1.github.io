# #159 – Peter Hotez, M.D., Ph.D.: Evolution of the anti-vaccine movement, the causes of autism, and COVID-19 vaccine state of affairs

**Source:** [https://peterattiamd.com/peterhotez3/](https://peterattiamd.com/peterhotez3/)

---

Peter Hotez is an internationally recognized physician-scientist in neglected tropical diseases and vaccine development. In this episode, they first follow up on the [podcast episode (#158) with Brian Deer](https://peterattiamd.com/BrianDeer/) (the investigative journalist who exposed the complex and disturbing story behind the infamous 1998 Lancet paper by Andrew Wakefield linking the MMR vaccine and autism) with a broader discussion about the origin and evolution of the anti-vaccine movement. They explore some of the specific claims being made around vaccine additives, the timing of when vaccines are given, and claims about issues with the HPV vaccine specifically. Next, Dr. Hotez shares his own journey as a parent of an autistic child and speaks of the challenges of diagnosing autism, what could account for the seeming increase in the prevalence, and whether there is any support for the notion that environmental triggers play a role. They close out with a discussion on the state of affairs with respect to COVID-19 vaccination, comparing the various vaccines as well as the challenges that emerging variants of the virus may present. This episode was originally recorded on April 2, 2021.

\*[WATCH PODCAST ON YOUTUBE](https://www.youtube.com/watch?v=eAD0XIYd-Bs)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/peterhotez3/the_Drive_public.png)

Play

#159 - Peter Hotez, M.D., Ph.D.: Evolution of the anti-vaccine movement, the causes of autism, and COVID-19 vaccine state of affairs

#159 - Peter Hotez, M.D., Ph.D.: Evolution of the anti-vaccine movement, the causes of autism, and COVID-19 vaccine state of affairs

1x15s30s

0:001:54:36

## We discuss:

- The stubborn persistence of anti-vaccine sentiment (3:00);
- A closer look at claims about thimerosal and vaccine spacing causing autism (12:00);
- The Hib vaccine: An example of the profound difference a vaccine can make (23:30);
- The controversy surrounding the human papillomavirus (HPV) vaccine (30:45);
- The growing anti-science sentiment, COVID vaccine hesitance, and the basis of the anti-vaxx movement (39:00);
- The origins of autism, and Hotez’s personal story as a parent of an autistic child (1:02:45);
- The challenge of diagnosing autism, increasing prevalence, and a potential parallel to Alzheimer’s disease (1:14:15);
- Comparing the various COVID-19 vaccines and the impact of emerging variants of the virus (1:30:00);
- Global vaccination challenges and “vaccine diplomacy” (1:40:45); and
- More.

§

## Show Notes

## The stubborn persistence of anti-vaccine sentiment [3:00]

- [Brian Deer](https://en.wikipedia.org/wiki/Brian_Deer), who is not particularly a vaccine advocate but an advocate for good science, [was recently on](https://peterattiamd.com/briandeer/) *The Drive*
- There is so much deceit in the work of [Andrew Wakefield](https://en.wikipedia.org/wiki/Andrew_Wakefield), who claimed that the MMR vaccine caused autism
- Peter wants to discuss: *Why, after Wakefield was debunked, is this still an issue?*
- A 2015 [poll](https://www.vox.com/2015/1/31/7954725/vaccines-autism-young-adults) showed that more than 20% of millennial-age Americans still think vaccines cause autism

**The anti-vaccine lobby keeps moving the goalposts (4:30)**

- Began in 1998 with now the now-retracted [Wakefield paper](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(97)11096-0/fulltext) asserting that the [MMR vaccine](https://en.wikipedia.org/wiki/MMR_vaccine) causes autism by the live virus replicating in the colon
  - robustly refuted by scientists
  - large cohort studies showed not linked, sound epidemiological data debunked the claim
- Then switched claims
  - [Robert F. Kennedy Jr.](https://en.wikipedia.org/wiki/Robert_F._Kennedy_Jr.) said it was [thimerosal](https://en.wikipedia.org/wiki/Thiomersal)
  - then to spacing vaccines to close together
  - Then it was the [alum](https://en.wikipedia.org/wiki/Aluminium_hydroxide) in vaccines
  - now away from autism to “chronic illness”
  - Added claim [that the HPV vaccine](https://en.wikipedia.org/wiki/HPV_vaccine) causes infertility and miscarriages
- Each time the scientific community responds, they keep shifting arguments to maintain momentum and re-energize the movement

**The focus has now shifted from pseudoscience to politics (4:30)**

- Beginning around 2014-15, latched onto the [Tea Party Movement](https://en.wikipedia.org/wiki/Tea_Party_movement) to make it a politicized movement around concepts of health and medical freedom
- Hotez decries the “craziness on [Fox News](https://www.foxnews.com/)”
  - [Tucker Carlson](https://en.wikipedia.org/wiki/Tucker_Carlson) [questioned](https://www.washingtonpost.com/politics/2021/03/16/dangerous-game-tucker-carlson-is-playing-vaccines/) vaccines
  - [Laura Ingraham](https://en.wikipedia.org/wiki/Laura_Ingraham) criticized both [Hotez himself](https://www.houstonchronicle.com/news/houston-texas/health/article/Dr-Peter-Hotez-return-to-normal-covid-summer-gray-16087488.php) and [also](https://www.huffpost.com/entry/laura-ingraham-fauci-donald-trump-rally_n_5ee8661dc5b6b735a648667c) [Tony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci)
- “They create these versions 1.0, 2.0, 3.0 of the anti-vaccine movement, but the autism piece never entirely left. That’s still its legacy fake assertion that still haunts us today”
- Peter urges listeners to [listen](https://peterattiamd.com/briandeer/)/[watch](https://www.youtube.com/watch?v=icJtTHgR_Ds) the podcast with Brian Deer and to read Brian’s [book](https://www.amazon.com/Doctor-Who-Fooled-World-Deception/dp/1421438003) for detailed information about the lack of association between the MMR vaccine and autism

> “I don’t know how to say this delicately, but I think if after assimilating all of that work, you still believe that there’s a relationship between that vaccine and autism, there’s probably nothing that can be said that can dissuade you from that.” —Peter Attia

- It was helpful that Deer was able to show not just the Wakefield’s scientific fallacy but also his nefarious intent
- The movement has grown much larger than Wakefield
  - Have national anti-vaccine groups like [Children’s Health Defense](https://en.wikipedia.org/wiki/Children%27s_Health_Defense) and the [Informed Consent Action Network](https://www.icandecide.org/) (ICAN)
  - Also have local [political action committees](https://en.wikipedia.org/wiki/Political_action_committee) (PACs) linked to far right-wing extremism
- Now also spreading beyond the US
- Discussing the science “won’t stop the momentum of the anti-vaccine movement because they light a fire, they cause damage and then they move on and that’s their *modus operandi*”
- Peter says this podcast episode is not going to stop the anti-vaccine movement but that his goal is to “help parents, who frankly are inundated with information and can’t distinguish between signal and noise”
  - Peter says it’s worth discussing thimerosal and increasing autism rates and other claims to help parents who are confused
  - He doubts he can dissuade the 20% of people who think vaccines are evil, but he wants to reach those in the middle who are undecided
- By 2007-08, Wakefield’s claims had not only been debunked scientifically but also it was clear that he and [John O’Leary](https://briandeer.com/mmr/oleary-pcr.htm) had lied and manipulated data
  - [*The Lancet*](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(97)11096-0/fulltext) [retracted](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(10)60175-4/fulltext) Wakefield’s paper in 2010
  - Said results were no longer valid
  - referred to the medical council panel but did not mention Brian Deer’s work
  - The journal had published an [institutional defense](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(04)15711-5/fulltext) of the work in 2004
- Peter says the lawsuits were the most damning because Wakefield couldn’t produce evidence to maintain any legal argument

## A closer look at claims about thimerosal and vaccine spacing causing autism [12:00]

**Thimerosal**

- Thimerosal is no longer in most childhood vaccines
- If have a multidose vial of vaccine, risk of introducing bacteria every time you’re introducing a needle into the vial through a rubber stopper
  - Need a preservative that’s nontoxic to humans but will kill the bacteria
  - Was an advance that allowed vaccination of large populations
- It was taken out of vaccines because of all the bad publicity swarming around it
  - There was no scientific evidence that it is harmful, but the thinking was that it was unnecessary because single dose vials could be used instead, so take it out to increase vaccination rates
  - Thimerosal is still in some flu vaccines in US, although they can also be given as a single dose
- No association between thimerosal and any adverse health effect was ever established
  - Bobby Kennedy made thimerosal his cause
  - He is an environmental lawyer who probably thought of [Minamata Disease](https://en.wikipedia.org/wiki/Minamata_disease) when he saw that thimerosal contained mercury
    - Decades ago, Japanese people were exposed to high levels of methylmercury in fish
    - Developed neurological symptoms that came to be called Minamata Disease
  - Thimerosal does not cause autism, which is associated with prenatal events
  - But Kennedy got involved and a couple of books made that claim
- Gained momentum as Wakefield’s claim had
- Hotez addressed these claims in his book [*Vaccines Did Not Cause Rachel’s Autism*](https://www.amazon.com/Vaccines-Did-Not-Cause-Rachels-Autism/dp/1421426609)
- Peter clarifies the difference between thimerosal and methylmercury
  - Thimerosal is ethyl mercury, an organic mercury
  - Methylmercury, which causes the toxicity we get from eating fish, is also an organic mercury
  - Minamata disease resulted from the industrial release of methyl mercury, a different compound from thimerosal / ethyl mercury
  - Methyl mercury accumulated in fish and caused a congenital neurologic disease with gait and motor disturbances and other problems including coma and death
- In 2001, a journal called [*Medical Hypotheses*](https://www.journals.elsevier.com/medical-hypotheses) published a [paper](https://www.sciencedirect.com/science/article/abs/pii/S0306987700912817) suggesting that thimerosal could be linked to autism
  - Thimerosal was a common preservative but was eventually removed from vaccines
  - But after it was taken out, the rates of [autism](https://www.fda.gov/files/vaccines,%20blood%20&%20biologics/published/Understanding-Thimerosal--Mercury--and-Vaccine-Safety.pdf) [did](https://www.cdc.gov/ncbddd/autism/data.html) [not](https://www.sciencedaily.com/releases/2008/01/080107181551.htm) [decrease](https://pubmed.ncbi.nlm.nih.gov/12949291/)
- Large cohort studies [did not show any link](https://www.nap.edu/catalog/10997/immunization-safety-review-vaccines-and-autism) between autism and thimerosal
- Peter points out that the 2001 paper was not unreasonable at the time; it was formulating a hypothesis by looking at plausible associations
- The problem comes later “after the scientific community goes to great lengths and great attempts to seek the truth and publishes paper after paper after paper in mainstream scientific journals” when anti-vaccine groups don’t acknowledge that work and “cling to their debunked hypothesis”
  - Say that scientists or journals must be paid off by pharmaceutical companies
  - Resort to conspiracy theories instead of showing intellectual curiosity about what actually causes autism
- “continually discount the massive amount of scientific work that’s gone into really uncovering what autism is”
- Peter says there are people who are “very influenced by data, they can think probabilistically, they can think in terms of uncertainty, they can accept and reason their way through these things” and others who “cling to a belief in the presence of emerging data that refute that hypothesis and they’ll continue to come up with an excuse”
- Anti-science sentiment is growing
- The process of removing thimerosal from vaccines began around 1999

**Vaccine Spacing (19:45)**

- Next goalpost was “antigen overload” and vaccine timing
  - make vaccines more eco friendly
  - getting too many vaccines in a short period of time was overwhelming the immune system
- But Hotez says the brains of kids with autism do not show excess inflammation like is seen in [herpes encephalitis](https://en.wikipedia.org/wiki/Herpesviral_encephalitis), so it’s not clear how this theory originated
- A pediatrician named [Bob Sears](https://en.wikipedia.org/wiki/Robert_Sears_(physician)) wrote a [book](https://www.amazon.com/Vaccine-Book-Decision-Parenting-Library/dp/0316180521/ref=sr_1_1?dchild=1&keywords=robert+sears+books&qid=1618106211&sr=8-1) about the need to space vaccines further apart
  - His book is still a best seller on Amazon’s [top vaccination books list](https://www.amazon.com/gp/bestsellers/books/13922584011)
  - At least some plausible explanation with thimerosal, but none with spacing
- Current vaccine schedule is “based on years and years of studies confirming immunogenicity and protection” and showing that there’s no immunological interference (when one vaccine interferes with another)
- When change schedule without scientific data, it’s “unclear whether they’re going to be just as effective or safe as that very carefully orchestrated dance that was developed jointly by the FDA and CDC”
- Peter’s patients sometime ask if they should vaccinate their kids on the delayed schedule
  - The parents often wonder if the logic behind the current vaccine schedule is just based on the fact that it is convenient to vaccinate babies during the first year when they are going to the doctor often
  - For example, most kids are not at risk of getting Hep B so they might think ‘why are we having to vaccinate babies for this?’

## The Hib vaccine: An example of the profound difference a vaccine can make [23:30]

- Hotez brings up [*Haemophilus influenzae* type B](https://en.wikipedia.org/wiki/Haemophilus_influenzae) (Hib), which causes a type of bacterial [meningitis](https://en.wikipedia.org/wiki/Meningitis)
  - When he was doing his residency in 1987/1988  he’d admit a child with Hib meningitis every few weeks
  - The child then had a high likelihood that kid was going to have permanent neurologic injury or might not even survive
  - back then there was a vaccine targeting the polyribosyl ribitol phosphate (PRP) capsule of Hib that might help a handful of older kids who could still mount an immune response
  - but no vaccine that worked in infants
- [John Robbins](https://en.wikipedia.org/wiki/John_B._Robbins) and [Rachel Schneerson](https://en.wikipedia.org/wiki/Rachel_Schneerson) of the [National Institute of Child Health & Development](https://www.nichd.nih.gov/) at the [NIH](https://www.nih.gov/) [figured out](https://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.285.5943&rep=rep1&type=pdf) that it had to be [haptenized](https://en.wiktionary.org/wiki/haptenize) (the antigen had to be joined to a carrier protein for vaccine to work)
  - Developed a [conjugate vaccine](https://en.wikipedia.org/wiki/Conjugate_vaccine) that worked in infants
  - But when Hotez was training, there was only a prophylactic antibiotic, [rifampicin](https://en.wikipedia.org/wiki/Rifampicin), which turns urine orange
    - Hotez was worried about bringing Haemophilus B home to his infant son, so he took rifampicin for about 2 years
  - Robinson, Schneerson, and [David Smith](https://www.nytimes.com/1999/03/01/nyregion/david-h-smith-67-developer-of-vaccine-against-meningitis.html) and [Porter Anderson](https://en.wikipedia.org/wiki/Porter_W_Anderson_Jr.) in Rochester figured out that if the PRP capsule was haptenized, the vaccine could stimulate a T cell response in infants

![](https://peterattiamd.com/wp-content/uploads/2021/04/fig-1-hotez3-1024x647.png)

**Figure 1. Using a conjugate vaccine to stimulate an immune response in infants**.  Image credit: Peeters et al., [Preparation of Polysaccharide-Conjugate Vaccines](https://link.springer.com/protocol/10.1385/1-59259-399-2:153)

- Vaccine was licensed in 1989 as Hotez was finishing his training
  - By the time he was a junior attending at Yale Children’s Hospital **2 years later, the disease was gone**
  - “*I taught the house staff about it purely for historical interest, just like the old guys at Mass General taught me about diphtheria and tetanu*s”
- It’s very expensive to get a vaccine approved
  - license from the [FDA](https://www.fda.gov/) to file a biologics license application
  - then go through an extensive review during license process: [Vaccines and Related Biological Products Advisory](https://www.fda.gov/advisory-committees/blood-vaccines-and-other-biologics/vaccines-and-related-biological-products-advisory-committee) (VRBPAC) committee at the FDA and the [Advisory Committee on Immunization Practices](https://www.cdc.gov/vaccines/acip/index.html) (ICIP) committee at the [CDC](https://www.cdc.gov/vaccines/acip/index.html)
  - Committees consider health benefits, cost effectiveness, etc.
- Peter asks if part of the vaccine schedule isn’t based on the probability of having contact with the health care system
  - Peter got his own Hep B vaccine as an adult in medical school because exposure was so great during medical training, it’s transmitted just like HIV
  - Hotez got his when he traveled to China
  - But now common to vaccinate infants, which was not done before
- Parent might ask if too much too soon
  - Is this necessary?  Infants only at risk if parent is at high risk (works in health care, IV drug user) and not vaccinated
  - Could make a case that Hep B vaccine is not needed until at least school age
- Hotez says it’s clear that Hib vaccine was necessary
- No vaccine is given for a trivial reason whether it’s apparent or not
  - There may have been enough at risk populations that it made sense to vaccinate everyone
  - The Hep B vaccine is very low risk: a recombinant protein vaccine produced in yeast that’s been around for almost four decades and been given to hundreds of millions of children
  - Hotez says another way to think about it is: what are we losing by vaccinating infants? (i.e., what’s the downside?)

## The controversy surrounding the human papillomavirus (HPV) vaccine [30:45]

- At least 3 strains of HPV (including 16 and 18) are associated with cervical cancer
- Women have died or become infertile from the cancer
- So the development of the HPV vaccine was fantastic news

**Controversy**

- But it was controversial not only from a scientific perspective but also from *moral, ethical, religious, and political* standpoints
  - HPV might be one of the best examples of the intersection of all of these forces
- Roughly 16% of all cancers are caused by infectious disease agents (about 33% in Africa)
  - HPV-induced cancers like cervical cancer and laryngeal cancers are predominantly sexually-transmitted cancers
- Developed by [Doug Lowy](https://ccr.cancer.gov/Laboratory-of-Cellular-Oncology/douglas-r-lowy) at the [National Cancer Institute](https://www.cancer.gov/) (NCI)
  - Initially showed that the vaccine could prevent infection by the virus
  - Now studies also show that it prevents cervical cancer
- The Australian government has now launched a program to eliminate cervical cancer by 2030
- “That’s really exciting to actually eliminate a cancer through the vaccination process”

**Controversy around vaccinating young girls**

- Originally was focused on cervical cancer and recommendation was to vaccinate girls around age 9 or 10 before they become sexually active

> “I think that [the HPV vaccine] did not go over well with a lot of people because they now realize their nice little 9- or 10-year-old girl is one day going to be a woman who is sexually active. … but in fact, it has a remarkable ability of saving lives and preventing cervical cancer.” —Peter Hotez

*Issues around the HPV vaccine in the US*

- In the US, there’s an access issue in rural areas and among underrepresented minorities
- The vaccine has been targeted by the anti-vaccine lobby, which has “come up with fake assertion after fake assertion that’s not supported by the scientific data”
  - Claimed it was causing autoimmune problems and reproductive problems like infertility and miscarriage
  - Scientists had to do large cohort studies to refute these claims
- Related to parental struggles with kids growing up
  - Peter recently saw a video of his 12-year-old daughter when she was 7 and her little brother was 1 playing on the beach and it was nostalgic
  - “There is nothing to me that is both simultaneously amazing and sad as the natural loss of a game of tug of war that goes on between a parent and a child”
    - Peter’s friend [Ric Elias](https://www.redventures.com/about/leadership?modal=ric_elias) described it as something like “you’re playing tug of war, and you have to lose by the time the kid’s about 18”
  - Peter understands that no one wants their daughter to be sexually active at a young age, but not getting her vaccinated is an asymmetric bet where the risks outweigh any perceived benefit
- Also need to explain that the vaccine has benefit to both males and females

*Anti-vaxx groups are specifically targeting HPV vaccine & COVID vaccines*

- Hotez says that anti-vaccine groups are specifically targeting HPV
  - Robert Kennedy [has been suing Merck](https://twitter.com/robertkennedyjr/status/1353024319228694535?lang=en) on behalf of patients who claim to have been injured by the HPV vaccine
  - Hotez is not aware of any evidence to support an association between HPV and infertility, miscarriages, or autoimmunity
- The anti-vaccine groups are now using the exact same arguments against the COVID vaccines; they recycle the claims
- The US is not even close to developing a cervical cancer elimination strategy
- laryngeal cancer is another risk
- many upper airway cancers are on the rise – soft palate, head and neck
  - Peter thinks head and neck cancer is the second or third largest growing cancer in young men because of sexually transmitted disease
  - Have to do devastating and aggressive surgeries

## The growing anti-science sentiment, COVID vaccine hesitance, and the basis of the anti-vaxx movement [39:00]

**Anti-vaxx movement**

- Why do 20% of the population and an entire cottage industry of lobbying groups, PACs, etc., come out so hard against this one class of drug?
  - Why not against antibiotics or exogenous insulin?
  - Peter says there’s no greater example of drug companies doing wrong and profiteering than with insulin: “the economics of insulin are an embarrassment to how pharma works”
  - Where is the rage about what Novo Nordisk is doing?

> “What is it about vaccines in particular that brings out so much ire, so much skepticism and so much anti-science rhetoric?” —Peter Attia

- Hotez believes vaccines are targeted for two reasons:
  - 1) vaccines are given to healthy people so it’s not as intuitively obvious that they need it
  - 2) vaccines are often required to enroll in school, so it feels like they are being forced on parents
  - easy for anti-vaccine groups to emphasize these two things to gain support and provide answers for parents who wonder how their child got autism
  - these two factors “are a toxic mix that get some people upset about vaccines, particularly in this environment which now dominates the internet”
- Anti-compulsory-vaccine leagues started in both the US and UK in the 1900s
  - but back then, you would go to the doctor, who would explain why the leagues were wrong and you should get vaccinated
  - now social media takes over the messages
  - Amazon is the largest promoter of anti-COVID vaccine conspiracy books
  - A lot of the information online is actually anti-vaccine and anti-science

**Growing sentiment of distrust in science**

- Peter is “still trying to understand why the disdain for science is so prevalent”
  - He says if you oppose the president’s infrastructure bill, you oppose it through legislative action and lobbying
  - He understands the medical freedom argument about not being forced to be vaccinated for a disease you don’t have because you can have a discussion about how to balance the needs of the individual versus society
  - But as a scientist, it’s hard for him to understand the anti-science part, though he tries to put himself in their shoes rather than being dismissive
- Hotez says all of the scientific efforts to debunk the anti-vaccine claims took some steam out of the movement
- But in some locations, like Orange County in CA, still had enough vaccine-resistant parents that Disneyland had a [measles outbreak](https://www.npr.org/sections/health-shots/2015/01/22/379072061/disneyland-measles-outbreak-hits-59-cases-and-counting) in 2015
  - The CA legislature responded by [eliminating the exemption clause](https://en.wikipedia.org/wiki/California_Senate_Bill_277) from its vaccine law
  - Measles is serious – has significant mortality and can cause permanent disability, like deafness and other things
- Anti-vaccine movement saw the CA response as an opportunity to rebuild and reinvent itself as a political movement based on medical freedom
  - Movement was strong in TX: created political action committees like [Texans For Vaccine Choice](https://www.texansforvaccinechoice.com/)
  - The PAC started getting other PAC money, a lot of money was flowing in and they were able to convince the Texas Tea Party, a powerful group, to adopt vaccine choice as a platform issue
  - Then PACs grew in Oklahoma and other western states

**The role of politics**

> “Your political allegiance, your identity actually became tied to not vaccinating your kid or to be skeptical of vaccines.” —Peter Hotez

- Same groups then began opposing masks and social distancing when pandemic hit based on medical freedom
  - Became a full-on anti-science movement
  - Expanded to the south and upper midwest as people felt they had to show allegiance to the Republican party by defying masks and social distancing
- A [nurse was interviewed](https://www.washingtonpost.com/health/2020/11/16/south-dakota-nurse-coronavirus-deniers/) telling the story of patients who died saying “COVID-19 is a hoax” [47:00]
- “what was a fringe group around … medical freedom in 2015 had now become a major platform of the Republican party going up against science”
  - Began to target scientists like [Tony Fauci](https://www.theguardian.com/us-news/2021/apr/05/fauci-rightwing-republican-criticism-bizarre) and [Hotez himself](https://www.nytimes.com/2019/06/02/opinion/vaccines-peter-hotez.html) as well as [criticizing](https://www.cnbc.com/2021/01/27/bill-gates-was-very-surprised-by-crazy-covid-conspiracy-theories.html) [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates)
  - Tucker Carlson has also [questioned vaccines](https://www.washingtonpost.com/politics/2021/03/16/dangerous-game-tucker-carlson-is-playing-vaccines/)
  - Laura Ingraham [criticized Hotez](https://www.houstonchronicle.com/news/houston-texas/health/article/Dr-Peter-Hotez-return-to-normal-covid-summer-gray-16087488.php)
  - They claimed the scientists misled the public, were incorrect, and didn’t understand the epidemic
  - Promoted the [Great Barrington Declaration](https://gbdeclaration.org/) by a group of scientists who opposed lockdowns
  - Said the scientists wanted to lock everyone down and were hurting the economy
- tied back to 2015 when the anti-vaccine sentiment was first linked to far-right political extremism

> “What started out as an anti-vaccine movement is now a movement against any kind of public health intervention and demonizing scientists and basically calling us the boogeyman.” —Peter Hotez

- Began to see anti-mask and anti-vaccine protests across Europe that used American anti-vaccine language
  - [*New York Times*](https://www.nytimes.com/) reported that it was linked to [QAnon](https://en.wikipedia.org/wiki/QAnon) and other far right-wing extremist groups
  - Now there are [allegations](https://www.nytimes.com/2020/04/13/science/putin-russia-disinformation-health-coronavirus.html) that [Vladimir Putin](https://en.wikipedia.org/wiki/Vladimir_Putin)’s government is promoting “weaponized health communication” to destabilize democratic countries
  - All this evolved from a fringe group that grew out of the Texas Tea Party
  - “I’m concerned about the fact that it continues to build”
- Peter wonders if this really represents the Republican party or just a vocal minority
- Hotez points out that the Republican party has not historically been anti science
  - the [National Academy of Sciences](https://nasonline.org/) was started during the [Lincoln](https://en.wikipedia.org/wiki/Abraham_Lincoln) administration
  - [Eisenhower](https://en.wikipedia.org/wiki/Dwight_D._Eisenhower) launched [NASA](https://www.nasa.gov/)
  - [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) launched the [President’s Emergency Plan for AIDS Relief](https://en.wikipedia.org/wiki/President%27s_Emergency_Plan_for_AIDS_Relief) (PEPFAR)
- This seems new but has become a major component of Fox News evening coverage
  - As recently as last year, Hotez regularly appeared on Fox
  - But then there was “a very deliberate disinformation campaign coming out of the [Trump](https://en.wikipedia.org/wiki/Donald_Trump) White House” saying COVID was like the flu and the deaths were from other causes
  - [Kayleigh McEnany](https://en.wikipedia.org/wiki/Kayleigh_McEnany) questioned masks and said the hospitalizations were catch-up and elective surgeries
  - [Scott Atlas](https://en.wikipedia.org/wiki/Scott_Atlas) also spread misinformation
- Hotez says he was one of the first to “call out” the misinformation because he has been fighting the anti-vaccine movement for years and has become a default expert in anti-science disinformation campaigns

**The scope of vaccine resistance today [51:30]**

- More pervasive now than it’s even been
  - A [PBS NewsHour](https://www.pbs.org/newshour/) / [NPR](https://www.npr.org/) / [Marist](https://maristpoll.marist.edu/#sthash.Y8nZfZpg.dpbs) [poll](https://www.pbs.org/newshour/show/why-41-percent-of-republicans-dont-plan-to-get-the-covid-vaccine) found that 41% of Republicans do not plan to get vaccinated against COVID-19, making them the most vaccine hesitant group in the US
  - Hotez did a [poll](https://today.tamu.edu/2021/01/04/study-black-americans-women-conservatives-more-hesitant-to-trust-covid-19-vaccine/) with Tim Callahan at the [School of Public Health at Texas A&M](https://public-health.tamu.edu/) that found the same thing among a group designated as Trump voters
  - Two [Kaiser Family Foundation](https://www.kff.org/coronavirus-covid-19/poll-finding/kff-covid-19-vaccine-monitor-march-2021/) polls got [similar](https://www.kff.org/coronavirus-covid-19/poll-finding/kff-covid-19-vaccine-monitor-february-2021/) [results](https://www.kff.org/coronavirus-covid-19/poll-finding/kff-covid-19-vaccine-monitor-march-2021/)
- While the greatest predictor of vaccine hesitancy is Republican party association, African-Americans [are also vaccine hesitant](https://www.nytimes.com/2021/03/15/us/politics/joe-biden-vaccine-republicans.html)
  - Hotez says this was true but resistance is now coming down among African Americans while remaining high among white Republicans
  - Hotez has been reaching out on podcasts and radio shows that target racial minority audiences
  - The pastor of a Baptist church in Richmond, VA told Hotez that his parishioners are less resistant to the vaccine now because of outreach by people like Hotez and also because Black clergy have created an informal network to push the need to be vaccinated
- Initial resistance may have been related to structural and historic racism and the horrible legacy of [Tuskegee](https://en.wikipedia.org/wiki/Tuskegee_Syphilis_Study)
  - But may also be related to the deliberate targeting of African-American groups by the anti-vaccine lobby
  - There is a video on the internet that attempts to link the COVID vaccine to Tuskegee
- “I’m worried that now you’ve got, again, people tying their allegiance to the Republican party or their identity to being against scientists and science, and this is not good for the country”
- There was a large [measles outbreak](https://www.washingtonpost.com/national/health-science/anti-vaccine-activists-spark-a-states-worst-measles-outbreak-in-decades/2017/05/04/a1fac952-2f39-11e7-9dec-764dc781686f_story.html) in the Somali community in Minnesota
  - Peter says it’s even worse than the Orange County outbreak because it was “a deliberate targeting of a community of immigrants not facile with the language”
  - Every time a community gets targeted about the MMR vaccine, there is a measles outbreak
    - [Paul Offit](https://en.wikipedia.org/wiki/Paul_Offit) calls measles the canary in the coal mine
    - Measles has a high [reproductive number](https://en.wikipedia.org/wiki/Basic_reproduction_number) (12-18), so get outbreaks when vaccination rates go down
  - the first time the anti-vaccine groups targeted a specific ethnic group
  - In 2017, [Lena Sun](https://www.washingtonpost.com/people/lena-h-sun/) at the [Washington Post](https://www.washingtonpost.com/) [reported](https://www.washingtonpost.com/national/health-science/anti-vaccine-activists-spark-a-states-worst-measles-outbreak-in-decades/2017/05/04/a1fac952-2f39-11e7-9dec-764dc781686f_story.html) that Wakefield had been spotted again at town hall meetings after being out of the public eye for a while
    - Brought down vaccination rates in the Somali community from 92% to 42%
    - ¼ of the kids who contracted measles ended up being hospitalized
- In 2018-19, targeted Orthodox Jewish groups in New York and New Jersey
  - Offensive tactics: used Jewish yellow stars with the word “vax” written in Hebrew-like letters
  - Compared vaccines to the Holocaust
  - Massive measles epidemic in Monsey, NY, and Brooklyn
  - Around 50 hospitalizations and 18 people in the ICU
- In 2019, organized vaccine forums in Harlem
  - One was held at the [Riverside Church](https://en.wikipedia.org/wiki/Riverside_Church), an iconic civil rights church in Manhattan where [William Sloane Coffin](https://en.wikipedia.org/wiki/William_Sloane_Coffin) was the minister in the 1970s and 80s

> “I’m very concerned. … You’ve got the health freedom component expanding out across the Republican Party, now into western Europe. You’ve got the Russians fueling this with their systematic weaponized health communication. Now, you’ve got the specific targeting of racial and ethnic groups and causing a lot of damage” —Peter Hotez

- Takes a long time to explain and can’t be captured in a 30-second commercial
- It makes people very uncomfortable
- When Hotez was on CNN and MSNBC he did not want to specifically call out the White House
  - fear of undermining his scientific credibility by being political
  - But being targeted made him an expert in anti-science disinformation campaigns
    - On Instagram Robert F. Kennedy Jr [called](https://www.npr.org/sections/coronavirus-live-updates/2021/02/11/966902737/instagram-bars-robert-f-kennedy-jr-for-spreading-vaccine-misinformation) Hotez the OG (original gangster) villain
    - [Peter Navarro](https://en.wikipedia.org/wiki/Peter_Navarro) [claimed](https://www.thedailybeast.com/peter-navarro-cites-conspiracy-theory-to-claim-fauci-is-father-of-the-coronavirus-on-fox-news) there was a conspiracy to allow China to  engineer the virus
    - Seemed like gaslighting
- Hotez told his wife Ann it was taking him “to a very dark place” and she told him he would regret not combatting the messages if there was a massive loss of life due to COVID
  - After that he decided to forcefully combat the anti-vaccine movement
  - He did not get support from the academic and professional societies because they are reluctant to stake political stands
  - He felt alone until it later became “safe” for others to support him
  - “I’m glad I did it, but emotionally, it really knocked the crap out of me, it was very tough to do that because the truth is I’m not that ideologically driven politically”
- Hotez was chair of microbiology at [George Washington University](https://www.gwu.edu/) in DC for a decade and learned that if you want to get anything done, you must reach across the aisle
  - He got neglected tropical disease legislation passed
  - Would speak to both [Sam Brownback](https://en.wikipedia.org/wiki/Sam_Brownback), a conservative Senator from Kansas, and [Patrick Leahy](https://en.wikipedia.org/wiki/Patrick_Leahy), a liberal Senator from Vermont, and back then it was common to do that but isn’t now [1:00:00]
- People perceived him as a Democratic partisan because he criticized the Trump administration, but now colleagues tell him not to criticize [Joe Biden](https://en.wikipedia.org/wiki/Joe_Biden)
- “If your focus is only on saving lives and doing whatever you can to save lives,” you will spread your message wherever you can
  - he’ll appear on on [Newsmax](https://www.newsmax.com/) and Fox News as well as media that reach racial minorities
  - It’s not easy to do
- Peter wonders whether there has been this level of distrust of science in the last two centuries
  - Hotez says there has been resistance in the past (when [Cotton Mather](https://en.wikipedia.org/wiki/Cotton_Mather) tried to vaccinate the Massachusetts colony against smallpox, [his house was firebombed](https://www.massmoments.org/moment-details/dr-boylston-experiments-with-smallpox-inoculation.html))
  - but the mainstreaming of anti-science belief has not been this systematic before
  - The internet and social media contribute to the problem

## The origins of autism, and Hotez’s personal story as a parent of an autistic child [1:02:45]

**Rachel’s story**

- She has autism and is now 28
- Peter’s wife Ann noticed that Rachel wasn’t as “huggy” as their two older kids
- When she was 19 months old, developmental delays were clear
  - Hotez was running a lab at Yale and had to travel frequently to a lab in China
  - He had to reconfigure program and give up going to China now that he had a special needs child
- Rachel was seen at the Yale Child Study Center, a leading autism center with experts like [Fred Volkmar](https://en.wikipedia.org/wiki/Fred_R._Volkmar), [Donald Cohen](https://en.wikipedia.org/wiki/Donald_J._Cohen), [Linda Mayes](https://medicine.yale.edu/profile/linda_mayes/), and [Wendy Levine](https://health.usnews.com/doctors/wendy-levine-620801) [1:04:00]

**Autism in girls**

- A bit harder to diagnose girls because they tend to be more verbal
  - Rachel was verbal, although some of it was [echolalia](https://en.wikipedia.org/wiki/Echolalia)
  - Her language skills are reasonably normal but she has a low performance IQ and has intellectual disabilities related to autism
  - autism is 10:1 boys to girls but may be because boys have a much more obvious presentation while girls mask it better because they are better verbally
  - autistic girls have high rates of comorbidities like [obsessive compulsive disorder](https://en.wikipedia.org/wiki/Obsessive%E2%80%93compulsive_disorder) (OCD) or [attention deficit hyperactivity disorder](https://en.wikipedia.org/wiki/Attention_deficit_hyperactivity_disorder) (ADHD) or eating disorders like [bulimia](https://en.wikipedia.org/wiki/Bulimia_nervosa) in teens
  - as we get better at diagnosing girls, ratio now closer to 3:1 and may reach closer to parity like 1.5
  - [Alison Singer](https://en.wikipedia.org/wiki/Alison_Singer) at the [Autism Science Foundation](https://autismsciencefoundation.org/) has been supporting efforts to improve diagnosis in females [1:05:30]

**The origins of autism in the brain**

- CDC website used to say that most children on the autism spectrum are diagnosed between 18 – 24 months of age
- [Joseph Piven](https://www.med.unc.edu/psych/directory/joseph-piven/) at UNC Chapel Hill [showed](https://www.nature.com/articles/nature21369) that that clinical expression of autism coincided with a big increase in brain volume expansion that could be followed with serial MRIs
  - Particularly with the regressive form of autism, kids actually lose milestones they had reached and parents remember that they got vaccine around that time
  - But you can go back much earlier and show brain changes in infancy or even prenatally
- [Eric Courchesne](https://profiles.ucsd.edu/eric.courchesne) at UCSD and researchers at the [Broad Institute](https://www.broadinstitute.org/) of Harvard and MIT [have](https://www.nature.com/articles/s41380-018-0056-y) [identified](https://www.cell.com/cell/pdf/S0092-8674(19)31398-4.pdf) about a hundred genes linked to autism spectrum disorder
  - all involved in early fetal brain development
  - Some are involved in neuronal communication like neuronal cytoskeleton genes
- Hotez did whole exome sequencing on Rachel at [Baylor Genetics](https://baylorgenetics.com/) and identified a neuronal [cytoskeleton](https://en.wikipedia.org/wiki/Cytoskeleton) gene ([non-red cell spectrum](https://www.hindawi.com/journals/bmri/2015/382641/))
- Certain genes are activated in early fetal brain development, but full clinical expression does not occur until around 18-19 months
- That’s not unusual for neuropsychiatric conditions; kids with [schizophrenia](https://en.wikipedia.org/wiki/Schizophrenia) are often not diagnosed until adolescence or even young adulthood

Coping with Rachel’s diagnosis

- Peter wonders if Hotez was able to think about Rachel’s diagnosis through a scientific lens, even though it was very personal
  - Much less was known back in the 90s
  - Rachel was about 5 when the [Wakefield paper](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(97)11096-0/fulltext) came out, but it did not make sense to him — but Hotez says, “*to me, it never made sense*”
- Previously it had been called [pervasive developmental disorder](https://en.wikipedia.org/wiki/Pervasive_developmental_disorder) (PDD) and many affected children were [macrocephalic](https://en.wikipedia.org/wiki/Macrocephaly) (had enlarged heads), so it was clearly a **neuroanatomical condition**
  - there were structural alterations in the brain of kids with autism
  - it didn’t make sense that a vaccine given at a year old could cause that
- Peter wonders if a part of Hotez wished it were the vaccine, because then the problem could be solved by simply giving MMR as three separate shots, helping others even if not Rachel
  - While Hotez would have wanted a simple, logical solution, he didn’t think that way because the vaccine-autism connection never made any sense to him
  - He suspected a genetic or [epigenetic](https://en.wikipedia.org/wiki/Epigenetics) basis
  - Very hard to discuss epigenetics (things like [microRNAs](https://en.wikipedia.org/wiki/MicroRNA) and [histone deacetylation](https://en.wikipedia.org/wiki/Histone_acetylation_and_deacetylation)) with lay audiences
- It had to be prenatal, but he did not think immunization during pregnancy would be the cause and this was later confirmed

**Autism spectrum, neurodiversity, and exome sequencing [1:12:00]**

- Today we recognize that autism is a spectrum
- Hotez notes that our understanding is now complicated by the concept of neurodiversity and accepting differences rather than describing autism as a pathology
- In Rachel’s case, it’s not her autism but her intellectual disability that’s incapacitating
  - she struggles with reading and simple math
  - She cannot make change, but the local merchants know her and are good to her
- Special services are an issue when children become adults and there is no long-term plan for Rachel right now
  - A residential facility did not work because she was not cooperative with the staff
  - Texas is not strong with those types of social services, northeastern states like MA and NY might be better

> “There’s no roadmap for what you do with an adult with intellectual disabilities. And that really worries me, … Trying to work that is a huge, huge, heavy burden on us.” —Peter Hotez

## The challenge of diagnosing autism, increasing prevalence, and a potential parallel to Alzheimer’s disease [1:14:15]

- Typical symptoms that a parent would notice would be language delay, changes in behavior, emotional regulation, and lack of eye contact
- It’s still listed in the [Diagnostic and Statistical Manual of Mental Disorders](https://en.wikipedia.org/wiki/Diagnostic_and_Statistical_Manual_of_Mental_Disorders) (DSM), the widely used classification system for psychiatric diagnoses
  - The DSM criteria are not as strong as they could be for girls, especially younger girls
  - a child with symptoms would typically be referred to an early intervention program called Birth to Three
    - typically get referred to a behavioral pediatrician or child psychiatrist
    - There is a huge need for more child psychiatrists and Hotez encourages his medical students to go into that field
  - Criteria include limited social interactions and lack of speech, although it can be a bit different for girls and women
- Autism is not like [Down Syndrome](https://en.wikipedia.org/wiki/Down_syndrome) where there is a clear [phenotype](https://en.wikipedia.org/wiki/Phenotype) and [genotype](https://en.wikipedia.org/wiki/Genotype)
  - Autism Spectrum Disorder (ASD) is much more nuanced, it’s more a [diagnosis of exclusion](https://en.wikipedia.org/wiki/Diagnosis_of_exclusion)
  - There are other possibilities on the [differential diagnosis](https://en.wikipedia.org/wiki/Differential_diagnosis)
- In the future, can use [exome](https://en.wikipedia.org/wiki/Exome) sequencing to identify and target specific genes
  - In some cases pharmacological intervention might be possible
  - with whole exome sequencing, get the full sequence of every expressed gene
    - identifies rare mutations that you wouldn’t pick up just by looking at chromosomes
    - right now find a mutation in autistic patients only about 40% of the time
    - if could screen the entire genome including non-expressed genes, might be able to find additional ones too
  - some children’s hospitals are considering doing whole exome sequencing on every child they admit
- But for now have a somewhat rudimentary list of criteria from the DSM
  - When Hotez was in med school at Cornell in the 1980s, a child psychiatrist told him that the DSM was anachronistic and out of touch for child psychiatry
  - He’s curious what a child psychiatrist today would think
  - The whole concept of neurodiversity is not reflected in the DSM like it needs to be
- Adding in whole exome sequencing and developments in neuropsychiatric medications will make things look very different 10 years from now (and again 10 years from then)
- In 2020, it was estimated that [1 in 54 American children](https://www.autismspeaks.org/press-release/cdc-estimate-autism-prevalence-increases-nearly-10-percent-1-54-children-us) will have autism
  - Hotez says could be more like 1 in 30 if girls and women aren’t undercounted
  - It was much more rare in, say, 1980 because the criteria changed
  - Used to focus on nonverbal boys with certain repetitive behaviors, has now greatly expanded
  - Also a question about at what point neurodiversity becomes a DSM diagnosis
- Hotez’s older daughter [Emily](https://www.linkedin.com/in/emilyhotez/) has a PhD in developmental psychology and is an assistant professor at UCLA

**A potential parallel to Alzheimer’s disease**

- Peter notes that the prevalence of [Alzheimer’s Disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) (AD) has increased over the past 50 years
  - people are living longer and there are many more tools to make the diagnosis
  - but also other factors that may be increasing the incidence
  - for example, vascular disease and metabolic disease are rising, [insulin resistance](https://en.wikipedia.org/wiki/Insulin_resistance) and abnormal lipid levels increase and get more neuropathology
- [David Corry](https://www.bcm.edu/people-search/david-corry-19841) at Baylor and Hotez are collaborating with others on a project to look at fungal (and even [candida](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6320369/)) involvement in AD
  - Some [beta amyloid plaques](https://en.wikipedia.org/wiki/Amyloid_plaques) have fungal sequences
  - Looking at the role of [aspergillus](https://en.wikipedia.org/wiki/Aspergillus) and yeast-forming fungi
- Peter suspects AD is the final common path for many health problems
- There might also be a toxic version related to infectious agents or environmental toxins
- Hotez says researchers are looking at whether a fungal vaccine could help reduce neurodegenerative disease

**Does this have a parallel to autism? (1:21:45)**

- We are making the diagnosis more, but might there also be a separate increase in incidence
  - Could be an environmental trigger that interacts with genes or independently
  - Can have an environmental trigger that triggers a condition for which there’s a genetic susceptibility that does not alter the genome (epigenetics)
  - or an environmental trigger that does alter the genome
- A group at [Geisinger](https://www.geisinger.edu/education) in Pennsylvania has been looking at a number of psychiatric conditions
  - Researchers [identified](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2484485) groups of families that have the same genetic mutation, yet one individual has autism, another schizophrenia, and another some other kind of brain disorder
  - genetics is dominant, but epigenetic factors could play a role
  - likely occurring during pregnancy
- structural changes in the brain are already well underway before birth
  - [Work](https://www.nature.com/articles/s41380-018-0056-y) from Courchesne and others shows that this is going on in fetal brain development (maybe as late as the second trimester, but *in utero*)
  - environmental influences are most likely something occurring during pregnancy
  - Peter says this adds to the anxiety about the baby’s health many parents feel during pregnancy
- Hotez points out that saying “genetic susceptibility” is too simplistic
  - there might be some environmental influences that could affect expression through epigenetics
  - We don’t know how [deterministic](https://en.wikipedia.org/wiki/Biological_determinism) it is (can’t say to what extent having the gene means that you have the condition vs. might have it if exposed to certain environmental conditions)
- Rachel’s case seemed to be caused by a single gene, but the [Broad Institute paper](https://www.cell.com/cell/pdf/S0092-8674(19)31398-4.pdf) identified about a hundred genes
  - all are involved in early fetal brain development, all but one are in the cortex of the brain, most related to early excitatory and inhibitory neurons, and many affect the neuronal cytoskeleton
  - The genes are dominant, but there might be epigenetic influences that can affect whether it’s full-on expression of autism or schizophrenia
  - “I think it’s overwhelmingly the genetics is the dominant factor and yes, deterministic, and maybe there are some epigenetic influences”
- Hotez believes that the rising incidence of autism is due to better awareness and an expansion of the definition
  - We now realize that kids who might have been labelled “mentally retarded” in another era are on the autism spectrum
  - In addition, having an autism diagnosis allows a child to access special services that they would not otherwise be eligible for, so there may be a tendency to seek the diagnosis
  - And girls are now being diagnosed more as better awareness that it can look different in females
- It’s unclear how heritable autism is
  - Some may be spontaneous mutations, others not
  - It is common to see undiagnosed parents with autistic traits
  - There’s a theory that it’s more common among highly intelligent people, but this has not been established
- Peter thought there had been a true increase in the incidence of autism, though not as significant as increased awareness and broader diagnostic criteria (for example, what used to be called Asperger’s is now a part of ASD)
- Hotez says it’s difficult to sort out – don’t yet have specific genetic markers to track to see if increasing

## Comparing the various COVID-19 vaccines and the impact of emerging variants of the virus [1:30:00]

- We’re on the path to a point where all Americans who want to be vaccinated against COVID can get vaccinated
- Right now 3 vaccines are available (Moderna, Pfizer, Janssen) and could have as many as 5 (e.g., Novavax) soon
- Hotez has concerns about AstraZeneca, but they haven’t applied for [emergency use authorization](https://www.fda.gov/vaccines-blood-biologics/vaccines/emergency-use-authorization-vaccines-explained#:~:text=An%20Emergency%20Use%20Authorization%20(,COVID%2D19%20pandemic.) so it’s not currently available in the US
- Pfizer [just released data](https://www.businesswire.com/news/home/20210331005503/en/) showing 100% efficacy in adolescents 12 to 15
  - but the study numbers were very small so the efficacy is unlikely stay that high
  - Virus neutralizing antibody titers in the adolescents were much higher than in older adults
- [correlates of protection](https://en.wikipedia.org/wiki/Correlates_of_immunity/correlates_of_protection): high levels of virus neutralizing antibody seem roughly to correlate with efficacy
  - perhaps more B-cell mediated, although T-cells likely have a role
  - but papers are often comparing virus neutralizing antibodies to convalescent serum titers (antibody levels in people who had and recovered from COVID-19), which vary very widely
- A recent [pre-print paper](https://www.medrxiv.org/content/10.1101/2021.03.09.21252641v1) used calculations to try to standardize the values
  - rather than give absolute values of [geometric mean](https://en.wikipedia.org/wiki/Geometric_mean#:~:text=In%20mathematics%2C%20the%20geometric%20mean,mean%20which%20uses%20their%20sum).) titers, calculated the ratio of the virus neutralizing antibody titers against the vaccine versus the convalescent virus neutralizing antibody titers
  - showed that to get a high level of protection from the vaccine, the level of virus neutralizing antibodies has to be at least as high as the convalescent and preferably about 1.5 of the convalescent value
  - this is not a true correlate of protection, but closer than other data

**Differences among vaccines (1:33:00)**

- Headlines about J&J (Janssen) vaccine said it was less effective, but if you look at the [absolute rather than relative risk reduction](https://www.statisticshowto.com/calculate-relative-risk/#:~:text=Absolute%20risk%20is%20different%20from,relative%20risk%20increase%20of%2025%25.), it seems to work at least as well as Pfizer and Moderna
  - But it’s hard to compare a single dose to two doses
  - J&J may become two doses if get a booster for one of the variants
  - virus neutralizing antibody titers are very high after two doses and it will offer as much protection as Pfizer and Moderna
  - single dose J&J might be slightly better than a single dose Pfizer and Moderna
- “The bottom line is they’re all good. They’re all good vaccines”
- We will likely need a booster for all of them (third dose of Moderna or Pfizer or second dose of the J&J)
  - Will elevate virus neutralizing antibody titers and create more durability of protection
  - May need to reconfigure the boosters to cover the South African and Brazilian variants which are not yet common in the US
  - We do have the B117 UK variant in the US, but all of the [Operation Warp Speed](https://en.wikipedia.org/wiki/Operation_Warp_Speed) vaccines work well against it

**The UK Variant (1:35:00)**

![](https://peterattiamd.com/wp-content/uploads/2021/04/fig-2-hotez3-1024x787.png)

**Figure 2. Spike protein amino acid substitution in the UK variant**. Image courtesy of Peter Hotez

- The UK variant has a single amino acid substitution that creates an aromatic amino acid, which seems to reduce the level of virus neutralizing antibody
  - In the spike protein, there’s an amino acid substitution in the 501 position from asparagine (N) to tyrosine (Y) (*see figure above*)
  - Tyrosine has an aromatic ring
  - With an additional tyrosine, there is a ring-ring interaction and a hydrogen bond
  - The pi electrons are interacting with each other
- Cases in Michigan in younger people with higher mortality and morbidity is related to the interactions between these two rings
- A certain combination of three nucleotides code for an amino acid
  - If change one nucleotide, it changes the amino acid from asparagine (in the original “wild type” lineage) to tyrosine
  - This changes the shape and also creates a new electrochemical attraction
- Now the spike protein has a stronger attraction to the [angiotensin-converting enzyme 2](https://en.wikipedia.org/wiki/Angiotensin-converting_enzyme_2) (ACE2) receptor
  - presumably makes it easier for the virus to enter cells and possibly allows better viral replication
  - Disease now more severe and affecting younger people too
- The good news is that the virus neutralizing antibodies to the original spike protein stimulated by the vaccines seem to still work well against the B117 variant

![](https://peterattiamd.com/wp-content/uploads/2021/04/fig-3-hotez3.png)

**Figure 3. Images of trimeric spike proteins on the surface of the SARS-CoV-2 virus**. Image courtesy of Peter Hotez

- In the image above, what look like purple flowers (*see arrow*) are the trimeric spike proteins
  - Each one has its own receptor binding domain
  - Only one of the receptor binding domains flips up and binds to the ACE2 receptor (*see figure below*)
  - The original type would look the same, it just has a lower affinity
  - the antibodies to all of the original lineages from the vaccines can still neutralize this interaction

![](https://peterattiamd.com/wp-content/uploads/2021/04/fig-4-hotez3-1024x579.png)

**Figure 4. Visual comparison of the UK and South African variants**. Image courtesy of Peter Hotez

**Brazilian and South African variants**

- The P1 variant from Brazil and B1351 from South Africa are different from UK variant
- B1351 has the same mutation in the 501 position as the UK variant (*shown in yellow in the figure above*), but there is a second amino acid substitution creating a lysine in the 484 position (*shown in purple in the figure above*)
  - Get extra levels of electrostatic interactions and the binding is potentially even tighter
  - Interferes with the ability of antibodies to neutralize, the titer goes down and decreased efficacy

![](https://peterattiamd.com/wp-content/uploads/2021/04/fig-5-hotez3-1024x744.png)

**Figure 5. Comparison of COVID vaccine effectiveness**. Image courtesy of Peter Hotez

- On the slide above, one can see the efficacy going way down
  - For Novavax and J&J, this shows published efficacy data
  - For Pfizer and Moderna, this shows the decline in levels of virus neutralizing antibody *in vitro*
- The original level is high enough that there is probably good protection from the residual
  - Recent Pfizer [press release](https://www.pfizer.com/news/press-release/press-release-detail/vitro-studies-demonstrate-pfizer-and-biontech-covid-19) suggests that in a small set its vaccine may work against the South African variant
  - makes sense given high levels of virus neutralizing antibody to start with

## Global vaccination challenges and “vaccine diplomacy” [1:40:45]

**The AstraZeneca vaccine**

- A [study](https://www.nejm.org/doi/full/10.1056/NEJMoa2102214?query=featured_home) had shown it only ~10% effective against the South African variant (*see figure above*)
  - But the vaccine was only tested against mild and moderate disease, might be effective against severe illness
  - Might see numbers like J&J, which tested against severe illness, if also tested against the severe version
- Bigger issue is public perception of the cerebral thrombosis being reported in Europe
  - German agency [Paul Ehrlich Institute](https://en.wikipedia.org/wiki/Paul_Ehrlich_Institute) reported six cases of sinus venous thrombosis and vaccine was [suspended](https://www.pei.de/EN/newsroom/hp-news/2021/210315-pei-informs-temporary-suspension-vaccination-astra-zeneca.html)
  - Several other European countries did as well, which had large ramifications for Africa
- Was a concern because AZ vaccine “was supposed to be a workhorse vaccine for low- and middle-income countries”
  - The European Medicines Agency has [stated](https://www.ema.europa.eu/en/news/astrazenecas-covid-19-vaccine-ema-finds-possible-link-very-rare-cases-unusual-blood-clots-low-blood) that this side effect is rare and the benefits still outweigh the risk
  - [Gretchen Vogel](https://www.sciencemag.org/author/gretchen-vogel) and [Kai Kupferschmidt](https://pulitzercenter.org/people/kai-kupferschmidt#:~:text=Kai%20Kupferschmidt%20is%20a%20science,a%20book%20about%20the%20subject.) [concluded](https://www.sciencemag.org/news/2021/04/hard-choices-emerge-link-between-astrazeneca-vaccine-and-rare-clotting-disorder-becomes) that some cases of cerebral venous thrombosis could be linked to the vaccine as a rare side effect
  - Not clear what will happen in the US especially in light of all of the very aggressive anti-vaccine activity here
  - Hotez hopes the US will authorize it for emergency release even if it is never used here because otherwise there could be a chilling effect on Latin America and Africa

**Global challenges**

- Not many choices for low- and middle-income countries, so Hotez and others have developed a recombinant protein vaccine they hope can be used there
  - Can’t scale up the two mRNA vaccines (Moderna and Pfizer) for Africa and Latin America
  - Great that [Pfizer donated 102,000 doses to Rwanda](https://www.unicef.org/press-releases/340000-doses-covax-vaccines-due-rwanda-today), but will need 4 billion doses of vaccines to cover 1.1 billion people in Sub-Saharan Africa and 650 million people in Latin America
  - Can’t cover that with mRNA vaccines and the freezer requirement is onerous
- J&J is having issues scaling up production
  - Focused a lot on innovation and not enough on durability for scale-up
  - when you use a brand new technology, it’s really hard to move to 4 billion doses
- After his [previous](https://peterattiamd.com/peterhotez/) [appearances](https://peterattiamd.com/peterhotez2/) on Peter’s podcast, Hotez got funding from several donors to adapt his existing coronavirus vaccine program for SARS and MERS to a recombinant protein vaccine for COVID-19
  - It’s recombinant protein in yeast like the Hepatitis B vaccine
  - capacity for producing 100 million doses a month
  - clinical trials and non-human primate trials have been promising

> “It was so hard to get funds for what was so obviously needed, which is a low cost unfussy, durable vaccine for low- and middle-income countries.” —Peter Hotez

- Hotez’s research group got “game changing” funding from the [Kleberg Foundation](https://www.klebergfoundation.org/), the [JPB Foundation](https://www.jpbfoundation.org/), the Austin-based company [Tito’s Vodka](https://www.titosvodka.com/), an anonymous donor, and others

- The P1variant in Brazil has the same two amino acid changes as the South African variant, so hopefully addressing one with also address the other
- Global policy makers created the brilliantly-designed [COVAX collaboration](https://www.who.int/initiatives/act-accelerator/covax)
- Equity issue because didn’t ensure there was enough vaccine available for COVAX

> “If we don’t figure out a way to vaccinate the rest of the world, if we only vaccinate North America and Europe, it’s going to be a catastrophe. This virus is going to continue to circulate and cause tremendous humanitarian destruction.” —Peter Hotez

- Could also see other variants develop if inadequate global vaccination

**Viral mutations (1:47:15)**

- Saw more mutations than expected in a coronavirus
  - One theory (which Hotez does not believe is strong) is that an immunocompromised individual had high levels viral replication and perhaps received [plasma convalescent therapy](https://en.wikipedia.org/wiki/Antiserum), putting selective pressure on the virus
  - Don’t really know why it has mutated
- A lot of the viruses seem to be converging on the same mutations
  - A booster for the South African/P1 Brazil variant may be enough to contain it
  - We may not even need a booster for the South African variant because our vaccines seems to produce good levels of virus neutralizing antibody for it
- Hotez hopes we will only need a one-time booster, but it’s too soon to tell
  - He’s guessing it won’t be annual like a flu vaccine
  - The flu is different – wholesale [antigenic shifts](https://en.wikipedia.org/wiki/Antigenic_shift) make it like a new virus
  - System in place to monitor strains and communicate with pharmaceutical manufacturers
- Hotez’s colleague [Patrick Soon-Shiong](https://en.wikipedia.org/wiki/Patrick_Soon-Shiong) in Los Angeles is interested to see if can we build out vaccine development capacity in Africa and Latin America
  - No vaccines are currently being made in Africa and not enough in Latin America and the Middle East
  - Even with COVAX, if you only rely on multinational companies they won’t make new vaccines for the world, and least not quickly
  - [Gavi Alliance](https://www.gavi.org/) for vaccinating the world’s children depends heavily on the multinational companies
  - They do a great job, but we need parallel mechanisms in place like local vaccine development production facilities in Africa and Latin America
- Need to work on “[vaccine diplomacy](https://en.wikipedia.org/wiki/Vaccine_diplomacy)”

**Wrap up**

- Peter laments that they only got through half of what he wanted to cover
- Hotez says he appreciates Peter’s “amazing talent for asking the right questions”

§

## Selected Links / Related Material

**Peter’s podcast interview with Brian Deer**: [#158 – Brian Deer: A tale of scientific fraud—exposing Andrew Wakefield and the origin of the belief that vaccines cause autism](https://peterattiamd.com/briandeer/) | *The Drive*, Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/archive/)) (4/19/2021) | [3:30]

**Brian Deer’s book telling the story of Wakefield’s deception**: [*The Doctor Who Fooled the World: Science, Deception, and the War on Vaccines*](https://www.amazon.com/Doctor-Who-Fooled-World-Deception/dp/1421438003) by Brian Deer (2020) | [3:30]

**Summary of MMR vaccine / autism controversy**: [MMR vaccine and autism](https://en.wikipedia.org/wiki/MMR_vaccine_and_autism) (en.wikipedia.org) | [3:30]

**Poll finding that 20% of young Americans think vaccines cause autism**: [1 in 5 millennials think vaccines cause autism](https://www.vox.com/2015/1/31/7954725/vaccines-autism-young-adults) | German Lopez, *Vox* (January 31, 2015) | [4:30]

**Wakefield’s infamous paper in the** ***Lancet*** **reporting on a case series of children which suggested that the MMR vaccine was linked to autism (later retracted)**: [Ileal-lymphoid-nodular hyperplasia, non-specific colitis, and pervasive developmental disorder in children](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(97)11096-0/fulltext) | *The Lancet* (Wakefield et al. 1998) | [5:00]

**Robert Kennedy’s anti-vaccine organization**: [Children’s Health Defense](https://en.wikipedia.org/wiki/Children%27s_Health_Defense) [4:30, 8:00]

**Article about Tucker Carlson’s critiques of vaccines**: [The dangerous game Tucker Carlson is playing on vaccines](https://www.washingtonpost.com/politics/2021/03/16/dangerous-game-tucker-carlson-is-playing-vaccines/) | Aaron Blake, *The Washington Post* (March 16, 2021) | [4:30]

**Hotez referencing Laura Ingraham’s criticism of him**: [Dr. Peter Hotez: We’ll be ‘pretty damn close’ to normal by summer](https://www.houstonchronicle.com/news/houston-texas/health/article/Dr-Peter-Hotez-return-to-normal-covid-summer-gray-16087488.php) | Lisa Gray, *The Houston Chronicle* (April 9, 2021) | [4:30]

**Laura Ingraham’s criticism of Tony Fauci**: [Laura Ingraham Calls Anthony Fauci ‘Medical Deep State’](https://www.huffpost.com/entry/laura-ingraham-fauci-donald-trump-rally_n_5ee8661dc5b6b735a648667c) | Lee Moran, Huffington Post (Jun 16, 2020) | [4:30]

**Announcement of retraction of Wakefield’s 1998 Lancet paper**: [Retraction — Ileal-lymphoid-nodular hyperplasia, non-specific colitis, and pervasive developmental disorder in children](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(10)60175-4/fulltext) | *The Lancet* (Editors of *The Lancet* 2010) | [11:15]

**Earlier institutional defense of Wakefield’s paper**: [A statement by The Royal Free and University College Medical School and The Royal Free Hampstead NHS Trust](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(04)15711-5/fulltext) | *The Lancet* (Hodgson 2004) | [11:15]

**Hotez’s book about vaccine science and his daughter**: [Vaccines Did Not Cause Rachel’s Autism: My Journey as a Vaccine Scientist, Pediatrician, and Autism Dad](https://www.amazon.com/Vaccines-Did-Not-Cause-Rachels-Autism/dp/1421426609) by Peter J. Hotez (2018) | [13:45]

**Paper suggesting a link between thimerosal and autism**: [Autism: a novel form of mercury poisoning](https://www.sciencedirect.com/science/article/abs/pii/S0306987700912817) | *Medical Hypotheses* (Bernard et al. 2001) | [15:45]

**Data showing that autism rates did not decline after thimerosal was removed from vaccines**: [15:45]

- [Understanding Thimerosal, Mercury, and Vaccine Safety](https://www.fda.gov/files/vaccines,%20blood%20&%20biologics/published/Understanding-Thimerosal--Mercury--and-Vaccine-Safety.pdf) (FDA 2011)
- [Data & Statistics on Autism Spectrum Disorder](https://www.cdc.gov/ncbddd/autism/data.html) (CDC 2020)
- [Autism: Removing Thimerosal from Vaccines Did Not Reduce Autism Cases in California, Report Finds](https://www.sciencedaily.com/releases/2008/01/080107181551.htm) (Science Daily 2008)
- [Thimerosal and the occurrence of autism: negative ecological evidence from Danish population-based data](https://pubmed.ncbi.nlm.nih.gov/12949291/) *Pediatrics* (Madsen et al. 2003)

**IOM report concluding that research has shown no link between thimerosal and autism**: [Immunization Safety Review: Vaccines and Autism](https://www.nap.edu/catalog/10997/immunization-safety-review-vaccines-and-autism) (Institute of Medicine 2004) | [15:45]

**Summary of the removal of thimerosal from vaccines in the US**: [Thiomersal and vaccines](https://en.wikipedia.org/wiki/Thiomersal_and_vaccines) (en.wikipedia.org) | [18:45]

**Vaccine book by Robert Sears**: [The Vaccine Book: Making the Right Decision for Your Child (Sears Parenting Library)](https://www.amazon.com/Vaccine-Book-Decision-Parenting-Library/dp/0316180521/ref=sr_1_1?dchild=1&keywords=robert+sears+books&qid=1618106211&sr=8-1) by Robert W. Sears (2011) | [19:45]

**Article showing that Haemophilus B vaccine must be conjugated**: [Preparation, Characterization, and Immunogenicity of Haemophilus B Influenzae Type B  Polysaccharide-Protein Conjugates](https://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.285.5943&rep=rep1&type=pdf) | *Journal of Experimental Medicine*  (Schneerson R, Barrera O, Sutton A, & Robbins JB 1980) | [25:00]

**Article about Disneyland measles outbreak**: [Disneyland Measles Outbreak Hits 59 Cases and Counting](https://www.npr.org/sections/health-shots/2015/01/22/379072061/disneyland-measles-outbreak-hits-59-cases-and-counting) | Lisa Aliferis, *NPR* (January 22, 2015) | [44:00]

**Information about 2015 CA bill that removed the personal belief exemption from its vaccination laws**: [California Senate Bill 277](https://en.wikipedia.org/wiki/California_Senate_Bill_277) (en.wikipedia.org) | [44:00]

**Nurse talking about patients who died of COVID denying that it exists**: [South Dakota nurse says many patients deny the coronavirus exists — right up until death](https://www.washingtonpost.com/health/2020/11/16/south-dakota-nurse-coronavirus-deniers/) | Paulina Villegas, *The Washington Post* (November 16, 2020) | [47:00]

**Discussion of anti-vaccine advocates targeting** **Tony Fauci, Peter Hotez, and Bill Gates:** [47:00]

- *Tony Fauci*: [Fauci hits back at rightwing criticism and says attacks on him ‘bizarre’](https://www.theguardian.com/us-news/2021/apr/05/fauci-rightwing-republican-criticism-bizarre) | Adam Gabbatt, *The Guardian* (April 5, 2021)
- *Peter Hotez*: [When Defending Vaccines Gets Ugly](https://www.nytimes.com/2019/06/02/opinion/vaccines-peter-hotez.html) | Janeen Interlandi, *The New York Times* (June 2, 2019)
- *Bill Gates*: [Bill Gates was ‘very surprised’ that ‘crazy’ Covid conspiracy theories targeted him and Dr. Fauci](https://www.cnbc.com/2021/01/27/bill-gates-was-very-surprised-by-crazy-covid-conspiracy-theories.html) | Tom Huddleston Jr., *CNBC* (January 27, 2021)

**Statement by a group of scientists who opposed lockdowns**: [Great Barrington Declaration](https://gbdeclaration.org/) (October 4, 2020) [47:45]

**Article about Putin deliberately spreading health misinformation**: [Putin’s Long War Against American Science](https://www.nytimes.com/2020/04/13/science/putin-russia-disinformation-health-coronavirus.html) William J. Broad, *The New York Times* (April 14, 2020)

**Surveys identifying vaccine hesitancy among subgroups**: [50:15]

- - *PBS/NPR/Marist poll finding that 41% of Republicans do not plan to get a COVID-19 vaccine*: [Why 41 percent of Republicans don’t plan to get the COVID vaccine](https://www.pbs.org/newshour/show/why-41-percent-of-republicans-dont-plan-to-get-the-covid-vaccine) | Yamiche Alcindor, *PBS* (March 19, 2021)
  - *Texas A&M poll finding that Trump voters were vaccine hesitant:* [Study: Black Americans, Women, Conservatives More Hesitant To Trust COVID-19 Vaccine](https://today.tamu.edu/2021/01/04/study-black-americans-women-conservatives-more-hesitant-to-trust-covid-19-vaccine/) | Callie Rainosek, *Texas A&M Today* (January 4, 2021)

- *Kaiser Family Foundation polls:*

- - [KFF COVID-19 Vaccine Monitor: February 2021](https://www.kff.org/coronavirus-covid-19/poll-finding/kff-covid-19-vaccine-monitor-february-2021/) | Liz Hamel, Grace Sparks, and Mollyann Brodie, *KFF* (February 26, 2021)
  - [KFF COVID-19 Vaccine Monitor: March 2021](https://www.kff.org/coronavirus-covid-19/poll-finding/kff-covid-19-vaccine-monitor-march-2021/) | Liz Hamel, Lunna Lopes, Audrey Kearney, and Mollyann Brodie, *KFF* (March 30, 2021)

**Discussion of vaccine hesitancy among both Republicans and African Americans**: [As Biden Confronts Vaccine Hesitancy, Republicans Are a Particular Challenge](https://www.nytimes.com/2021/03/15/us/politics/joe-biden-vaccine-republicans.html) | Annie Karni and Zolan Kanno-Youngs, *The New York Times* (March 15, 2021) | [52:30]

**Infamous unethical experiments that affected the trust of African Americans in the medical system**: [Tuskegee Syphilis Study](https://en.wikipedia.org/wiki/Tuskegee_Syphilis_Study) [52:45]

**Article about Wakefield encouraging Somali immigrants not to vaccinate**: [Anti-vaccine activists spark a state’s worst measles outbreak in decades](https://www.washingtonpost.com/national/health-science/anti-vaccine-activists-spark-a-states-worst-measles-outbreak-in-decades/2017/05/04/a1fac952-2f39-11e7-9dec-764dc781686f_story.html) | Lena H. Sun *The Washington Post* (May 5, 2017) | [55:30]

**Instagram bans Robert Kennedy for spreading falsehoods about vaccines**: [Instagram Bars Robert F. Kennedy Jr. For Spreading Vaccine Misinformation](https://www.npr.org/sections/coronavirus-live-updates/2021/02/11/966902737/instagram-bars-robert-f-kennedy-jr-for-spreading-vaccine-misinformation) | Bill Chappell, *NPR* (February 11, 2021) | [58:00]

**Cotton Mather and resistance to vaccination in colonial America**[: Dr. Boylston Experiments with Smallpox Inoculation](https://www.massmoments.org/moment-details/dr-boylston-experiments-with-smallpox-inoculation.html) | *Mass Moments* | [1:01:30]

**Joseph Piven’s work on autism and brain volume expansion**: [Early brain development in infants at high risk for autism spectrum disorder](https://www.nature.com/articles/nature21369) | *Nature* (Hazlett … & Piven 2017) | [1:06:15]

**Example of Eric Courchesne’s work on autism-related genes**: [The ASD Living Biology: from cell proliferation to clinical phenotype](https://www.nature.com/articles/s41380-018-0056-y) | *Molecular Psychiatry* (Courchesne et al. 2019) | [1:07:00]

**Broad Institute paper identifying 100+ genes implicated in autism**[: Large-Scale Exome Sequencing Study Implicates Both Developmental and Functional Changes in the Neurobiology of Autism](https://www.cell.com/cell/pdf/S0092-8674(19)31398-4.pdf) | *Cell* (Satterstrom et al. 2020) | [1:07:00, 1:24:15]

**Estimates of autism rates in the US**: [CDC estimate on autism prevalence increases by nearly 10 percent, to 1 in 54 children in the U.S.](https://www.autismspeaks.org/press-release/cdc-estimate-autism-prevalence-increases-nearly-10-percent-1-54-children-us) | *Autism Speaks* (March 26, 2020) | [1:18:30]

**Article Hotez and his daughter wrote about the COVID vaccine and people with disabilities**: [Prioritizing COVID-19 vaccinations for individuals with intellectual and developmental disabilities](https://www.sciencedirect.com/science/article/pii/S2589537021000298) | *EClinicalMedicine* (Hotez E, Hotez PJ et al. 2021) | [1:18:45]

**Paper on fungal involvement in Alzheimer’s disease**[: Microglia and amyloid precursor protein coordinate control of transient Candida cerebritis with memory deficits](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6320369/) | *Nature Communications* (Wu … & Corry 2019) | [1:20:15]

**Geisinger paper on genes common to autism, schizophrenia, and other disorders**: [A Cross-Disorder Method to Identify Novel Candidate Genes for Developmental Brain Disorders](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2484485) | *JAMA Psychiatry* (Gonzales-Mantilla et al. 2016) | [1:22:30]

**Pfizer data showing 100% efficacy in adolescents**: [Pfizer-BioNTech Announce Positive Topline Results of Pivotal COVID-19 Vaccine Study in Adolescents](https://www.businesswire.com/news/home/20210331005503/en/) | *BusinessWire* (March 31, 2021) | [1:30:00]

**Pre-print article standardizing and comparing virus neutralizing antibody titers**:  [What level of neutralising antibody protects from COVID-19?](https://www.medrxiv.org/content/10.1101/2021.03.09.21252641v1) | *medRxiv* (Khoury et al. 2021) | [1:32:00]

**Recent Pfizer press release about effectiveness against South African variant**: [*In vitro* studies demonstrate Pfizer and BioNTech  COVID-19 vaccine elicits antibodies that neutralize SARS-CoV-2 with key mutations present in UK and South African variants](https://www.pfizer.com/news/press-release/press-release-detail/vitro-studies-demonstrate-pfizer-and-biontech-covid-19) | (Pfizer.com) (January 27, 2021) | [1:40:30]

**Study showing that the AZ vaccine was not effective against the South African variant**: [Efficacy of the ChAdOx1 nCoV-19 Covid-19 Vaccine against the B.1.351 Variant](https://www.nejm.org/doi/full/10.1056/NEJMoa2102214?query=featured_home) | *New England Journal of Medicine* (Madhi et al. 2021) | [1:40:45]

**European Medicines Agency statement on the AZ vaccine**: [AstraZeneca’s COVID-19 vaccine: EMA finds possible link to very rare cases of unusual blood clots with low blood platelets](https://www.ema.europa.eu/en/news/astrazenecas-covid-19-vaccine-ema-finds-possible-link-very-rare-cases-unusual-blood-clots-low-blood) | *European Medicines Agency* (April 7, 2021) | [1:42:15]

**Article about cerebral venous thrombosis and the AZ vaccine**: [Hard choices emerge as link between AstraZeneca vaccine and rare clotting disorder becomes clearer](https://www.sciencemag.org/news/2021/04/hard-choices-emerge-link-between-astrazeneca-vaccine-and-rare-clotting-disorder-becomes) | Kai Kupferschmidt and Gretchen Vogel, *Science* (April 11, 2021) | [1:42:30]

**Hotez’s previous interviews on the podcast that allowed him to secure funding for his vaccine project**: [1:45:00]

- [#97 – Peter Hotez, M.D., Ph.D.: COVID-19: transmissibility, vaccines, risk reduction, and treatment](https://peterattiamd.com/peterhotez/) | *The Drive*, Peter Attia (<https://peterattiamd.com/podcast/archive/>) (March 14, 2020)
- [#99 – Peter Hotez, M.D., Ph.D.: Continuing the conversation on COVID-19](https://peterattiamd.com/peterhotez2/) | *The Drive*, Peter Attia (<https://peterattiamd.com/podcast/archive/>) (March 20, 2020)

§

## People Mentioned

- [Brian Deer](https://en.wikipedia.org/wiki/Brian_Deer) [3:30, 7:30, 8:00, 11:15]
- [Andrew Wakefield](https://en.wikipedia.org/wiki/Andrew_Wakefield) [3:30, 4:30, 8:00, 11:00, 14:45, 55:30, 1:08:45]
- [Robert F. Kennedy Jr](https://en.wikipedia.org/wiki/Robert_F._Kennedy_Jr.). [4:30, 13:45, 37:00, 58:00]
- [Tucker Carlson](https://en.wikipedia.org/wiki/Tucker_Carlson) [4:30, 47:00]
- [Laura Ingraham](https://en.wikipedia.org/wiki/Laura_Ingraham) [4:30, 47:00]
- [Anthony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci) [4:30, 47:00]
- [John O’Leary](https://briandeer.com/mmr/oleary-pcr.htm) [9:45]
- [John Robbins](https://en.wikipedia.org/wiki/John_B._Robbins) [25:00]
- [Rachel Schneerson](https://en.wikipedia.org/wiki/Rachel_Schneerson) [25:00]
- [David Smith](https://www.nytimes.com/1999/03/01/nyregion/david-h-smith-67-developer-of-vaccine-against-meningitis.html) [25:00]
- [Porter Anderson](https://en.wikipedia.org/wiki/Porter_W_Anderson_Jr.) [25:00]
- [Doug Lowy](https://ccr.cancer.gov/Laboratory-of-Cellular-Oncology/douglas-r-lowy) [31:45]
- [Ric Elias](https://www.redventures.com/about/leadership?modal=ric_elias) [34:45]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) [47:00]
- [Vladimir Putin](https://en.wikipedia.org/wiki/Vladimir_Putin) [48:00]
- [Abraham Lincoln](https://en.wikipedia.org/wiki/Abraham_Lincoln) [50:00]
- [Dwight Eisenhower](https://en.wikipedia.org/wiki/Dwight_D._Eisenhower) [50:00]
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) [50:00]
- [Donald Trump](https://en.wikipedia.org/wiki/Donald_Trump) [50:00]
- [Kayleigh McEnany](https://en.wikipedia.org/wiki/Kayleigh_McEnany) [50:00]
- [Scott Atlas](https://en.wikipedia.org/wiki/Scott_Atlas) [50:15]
- Tim Callahan [51:30]
- [Paul Offit](https://en.wikipedia.org/wiki/Paul_Offit) [55:15]
- [Lena Sun](https://www.washingtonpost.com/people/lena-h-sun/) [55:30]
- [William Sloane Coffin](https://en.wikipedia.org/wiki/William_Sloane_Coffin) [55:30]
- [Peter Navarro](https://en.wikipedia.org/wiki/Peter_Navarro) [58:00]
- [Sam Brownback](https://en.wikipedia.org/wiki/Sam_Brownback) [1:00:00]
- [Patrick Leahy](https://en.wikipedia.org/wiki/Patrick_Leahy) [1:00:00]
- [Joe Biden](https://en.wikipedia.org/wiki/Joe_Biden) [1:00:00]
- [Cotton Mather](https://en.wikipedia.org/wiki/Cotton_Mather) [1:01:30]
- [Fred Volkmar](https://en.wikipedia.org/wiki/Fred_R._Volkmar) [1:04:00]
- [Donald Cohen](https://en.wikipedia.org/wiki/Donald_J._Cohen) [1:04:00]
- [Linda Mayes](https://medicine.yale.edu/profile/linda_mayes/) [1:04:00]
- [Wendy Levine](https://health.usnews.com/doctors/wendy-levine-620801) [1:04:00]
- [Alison Singer](https://en.wikipedia.org/wiki/Alison_Singer) [1:05:30]
- [Joseph Piven](https://www.med.unc.edu/psych/directory/joseph-piven/) [1:06:15]
- [Eric Courchesne](https://profiles.ucsd.edu/eric.courchesne) [1:07:00, 1:23:30]
- [Emily Hotez](https://www.linkedin.com/in/emilyhotez/) [1:18:45]
- [David Corry](https://www.bcm.edu/people-search/david-corry-19841) [1:20:15]
- [Gretchen Vogel](https://www.sciencemag.org/author/gretchen-vogel) [1:42:30]
- [Kai Kupferschmidt](https://pulitzercenter.org/people/kai-kupferschmidt#:~:text=Kai%20Kupferschmidt%20is%20a%20science,a%20book%20about%20the%20subject.) [1:42:30]
- [Patrick Soon-Shiong](https://en.wikipedia.org/wiki/Patrick_Soon-Shiong) [1:49:30]

§

![](https://peterattiamd.com/wp-content/uploads/2021/04/1x1-hotez3-500x500.jpeg)

##### Peter Hotez, M.D., Ph.D.

Peter J. Hotez, M.D., Ph.D., is Dean of the National School of Tropical Medicine and Professor of Pediatrics and Molecular Virology & Microbiology at Baylor College of Medicine. He is also the Co-director of the Texas Children’s Center for Vaccine Development (CVD), Texas Children’s Hospital Endowed Chair of Tropical Pediatrics, and holds numerous other positions as a professor and fellow at both Baylor and Texas A&M. He is an internationally-recognized physician-scientist in neglected tropical diseases and vaccine development.  As head of the Texas Children’s CVD, he leads a team and product development partnership for developing new vaccines for numerous diseases, including SARS/MERS/SARS-2 coronaviruses, while championing access to vaccines globally and in the United States. In 2006 he co-founded the Global Network for Neglected Tropical Diseases to provide access to essential medicines for hundreds of millions of people. Dr. Hotez has authored more than 500 original papers and is the author of four books. He has won multiple awards, served in government in several capacities, and appears frequently in major media outlets.  In 2017, he was named by FORTUNE Magazine as one of the 34 most influential people in health care. He obtained his undergraduate degree in molecular biophysics from Yale University, a Ph.D. degree in biochemistry from Rockefeller University, and an M.D. from Weil Cornell Medical College.

Website: [peterhotez.org](https://peterhotez.org/)

Twitter: [@PeterHotez](https://twitter.com/PeterHotez?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Facebook: [Peter Hotez](https://www.facebook.com/peter.hotez.3)

Instagram: [@peterhotez](https://www.instagram.com/peterhotez/?hl=en)