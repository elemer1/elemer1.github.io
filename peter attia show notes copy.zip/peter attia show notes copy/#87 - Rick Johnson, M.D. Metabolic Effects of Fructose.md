# #87 – Rick Johnson, M.D.: Metabolic Effects of Fructose

**Source:** [https://peterattiamd.com/rickjohnson/](https://peterattiamd.com/rickjohnson/)

---

##### See more content from Rick Johnson, M.D.:

- - *(January 6, 2020)* [Metabolic Effects of Fructose with Rick Johnson, M.D. | Part I](/rickjohnson/)
  - *(February 6, 2022)* [How Fructose Drives Metabolic Disease with Rick Johnson, M.D. | Part II](rickjohnson2/)

In this episode, Rick Johnson, professor of nephrology at the University of Colorado, explains how his research into the causes of blood pressure resulted in a change of research direction to focus more on how fructose has such profound metabolic effects. Rick begins by talking about the relationship between salt and high blood pressure, then provides a masterclass into uric acid, and then expertly reveals the mechanisms and pathways by which sugar (specifically fructose) can profoundly impact metabolic health. From there, he explains how he applies this information to real life patients as well as touches on some of the most promising ideas around pharmacotherapy that are being developed in response to the epidemics of fatty liver, insulin resistance, diabetes, and obesity. Furthermore, Rick gives his take on [artificial sweeteners](/tag/sugar-artificial-sweeteners/) compared to real sugar, discusses cancer’s affinity for fructose, and much more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/rickjohnson/the_Drive_public.png)

Play

#87 - Rick Johnson, M.D.: Fructose—The common link in high blood pressure, insulin resistance, T2D, & obesity?

#87 - Rick Johnson, M.D.: Fructose—The common link in high blood pressure, insulin resistance, T2D, & obesity?

1x15s30s

0:001:50:47

We discuss:

- The connection between blood pressure and fructose that shifted Rick’s professional focus [4:00];
- The relationship between salt and blood pressure (and the role of sugar) [5:45];
- Defining fructose, glucose, and sugar [19:30];
- An ancient mutation in apes that explains why humans turn fructose into fat so easily [23:00];
- The problems with elevated uric acid levels, and what it tells us about how sugar causes disease [31:30];
- How sugar causes obesity—explaining the difference in glucose vs. fructose metabolism and the critical pathway induced by fructose [40:00];
- Why drinking sugar is worse than eating it [50:00];
- Unique ability of sugar to drive oxidative stress to the mitochondria, insulin resistance, and diabetes [54:00];
- Why cancer loves fructose [1:00:20];
- The many areas of the body that can use fructose [1:05:00];
- Fructokinase inhibitors—a potential blockbuster? [1:07:15];
- Treating high uric acid levels—Rick’s approach with patients [1:10:00];
- Salt intake—what advice does Rick give his patients? [1:16:30];
- How excess glucose (i.e., high carb diets) can cause problems even in the absence of fructose [1:21:00];
- Artificial sweeteners vs. real sugar—which is better? [1:29:15];
- Umami, MSG, alcohol, beer—do these have a role in metabolic illness? [1:33:45];
- Fructose consumption—Is any amount acceptable? Is fruit okay? Where does Rick draw a hard line? [1:38:45]
- How does Rick manage the sugar intake of his young kids? [1:43:00]; and
- More.

§

## Show Notes

## The connection between blood pressure and fructose that shifted Rick’s professional focus [4:00]

- It started with looking into the cause of high blood pressure
- The running theory for years was that the kidney has a defect in its ability to excrete salt and so that you end up retaining salt and that leads to elevated blood pressure
- Rick then figured out that [when you raise uric acid in animals, they developed high blood pressure](https://www.ncbi.nlm.nih.gov/pubmed/11711505)
- So *what made uric acid go up? ⇒* Sugar, and particularly [fructose](https://en.wikipedia.org/wiki/Fructose), raised uric acid

> “We started studying fructose and pretty soon we were so excited about what we were finding that we just kind of changed our research direction to focus more on how fructose has all of its metabolic effects.”

## The relationship between salt and blood pressure (and the role of sugar) [5:45]

*Does salt raise blood pressure?*

- The prevailing thought is that too much salt elevates blood pressure
- And the advice would be to restrict the amount of salt intake
- But it isn’t really the salt amount that makes a difference, but the salt **concentration**
- When you eat salt, your **serum osmolality** goes up
- If you drink water in combination with eating salt, you can avoid this rise in serum osmolality and avoid the rise in blood pressure
- Rick’s [2018 study](https://onlinelibrary.wiley.com/doi/full/10.1111/jch.13374) showed that drinking water with a salty meal will prevent a rise in blood pressure

*Why it would be better to have a lower blood pressure?*

- When your blood pressure is high, you have an increased risk for heart failure and stroke.
- As your blood pressure increases, you get a gradual increase in risk
- But when the blood pressure gets around **160 to 180,** the risk for stroke goes significantly up and the risk for mortality goes up (like a vertical line, says Rick)
- Today, 120 over 80 is seen as the “optimal” blood pressure for an older person because [too low blood pressure can lead to kidney failure](https://www.sciencedaily.com/releases/2013/08/130819185346.htm)

**What is “essential hypertension”?**

-Peter points out that “essential hypertension” is sort of a waste-bucket term which we use because we don’t know what so many people have hypertension

-Rick says there have been **two major breakthroughs** in the last 5-10 years:

- **#1 – Inflammation**
  - The [key discovery](https://www.ahajournals.org/doi/full/10.1161/01.hyp.0000028589.66335.aa) was that the kidneys normally handles salt just fine, but they develop or acquire a change in the kidneys that lead them to hold onto sodium due to **inflammation** that occurs in the kidney
  - The inflammatory response mediated by both T cells and macrophages injures the kidney ischemically (resulting in reduced blood flow and tissue damage due to reduced blood flow and reduced oxygen)
  - And it’s that injury that then leads to aberrant (increased) retention of sodium

> “Inflammation in the kidney can be a mechanism for triggering persistent elevations and blood pressure and probably has a big role in the cause of primary hypertension.”

- **#2 – Autoimmune response to heat-shock proteins**
  - The inflammation in the kidney, in many cases, is due to an [autoimmune reaction to heat shock proteins](https://www.ncbi.nlm.nih.gov/pubmed/29679484)
  - Heat shock proteins are involved in the clearance of mis-folded proteins and they’re helping keep a clean system
  - But what happens is when you trigger injury to the kidney, for example, these heat shock proteins get produced to help fix problems, but the immune system can sometimes get confused and make an immune response that actually is against the heat shock proteins
  - And when that happens you can develop high blood pressure
  - *H**ow prevalent is this*?
    - Very major, says Rick
    - There are [genetic polymorphisms](https://www.ncbi.nlm.nih.gov/projects/gap/cgi-bin/study.cgi?study_id=phs000585.v2.p1) that link with the development of primary hypertension and most of them are involved with the immune response to heat shock protein
  - **NOTE**: [Heat shock proteins](https://en.wikipedia.org/wiki/Heat_shock_protein) are not necessarily bad
    - many of the benefits we get out of sauna or exercise may be transmitted through these
    - You should NOT stop exercising because the net effect of exercise is still going too far outweigh the potential downside

> “One of the big breakthroughs has been the discovery that inflammation in the kidney can be a mechanism for triggering persistent elevations in blood pressure and probably has a big role in the cause of primary hypertension.”

**The role that sugar plays in hypertension**

*-In the process of developing high blood pressure there are 2 players*:

1. There’s the **initiators**
2. And then there’s the things that make it **persistent**

- The *inflammation* in the kidney is involved in the **persistence**
- In the *initiation*, turns out that **sugar** has a major role

-Rick’s [2013 study](https://www.nature.com/articles/ncomms3434) showed that when you give a high salt diet to animals…

- It increases the **serum sodium** which then activates an enzyme that converts glucose to fructose
- This fructose is made in the body, not coming from the diet
- The fructose then gets metabolized and raises blood pressure
- In animals, [when you block the metabolism of fructose, you actually block the rise in blood pressure](https://www.ncbi.nlm.nih.gov/pubmed/29507217)

## Defining fructose, glucose, and sugar [19:30]

⇒ Check out [Peter’s discussion with Rob Lustig](https://peterattiamd.com/roblustig/) for a deeper dive on this topic

*The different types of sugar*:

**Glucose**

- Blood sugar is glucose
- It’s the primary sugar that our body uses to make energy
- When that’s too high we call it diabetes
- When the blood glucose is too low, it’s hypoglycemia
- It can be stored in the tissues as glycogen
  - In the muscles (once in there it can’t get out)
  - In the liver (about ¼-⅓ of total glycogen) and that’s mostly there to buffer the blood supply in particular to the brain
  - In the kidneys – kidneys store glycogen and produce glucose too
- What does glucose tastes like? A pure drink of glucose?
  - People like it, animals like it, but it isn’t as sweet as classic sugar
  - You can buy dextrose pops (dextrose is another name for glucose)

**Fructose**:

- Fructose is a natural sugar found in fruit
- Fructose is the sugar that is involved in **energy storage** rather than energy production.
- When you eat *glucose*, you use that to produce energy…
- …but when you eat *fructose*, it will actually trigger changes in the body that will favor the storage of energy
- This is the sugar that animals use to store energy.
- You store it in the way of
  - Fat
  - Glycogen; and
  - Anything that will facilitate storing energy is done by fructose
- *The biochemistry*…And fructose and glucose look almost identical biochemically with exception of a couple of bonds but that small difference can have quite different properties
- Taste:
  - Fructose tastes a lot sweeter than glucose
  - Found in honey and fruits

**Table sugar** (aka sucrose) = glucose + fructose at 50/50 ratio

- You get this when they are bound together
- Occurs in nature in sugar cane, beets, and maple syrup

**High fructose corn syrup** = typically 55% fructose, 45% glucose in soft drinks

## An ancient mutation in apes that explains why humans turn fructose into fat so easily [23:00]

- The [proconsul primates](https://en.wikipedia.org/wiki/Proconsul_(mammal)) lived in Africa ~22 million years ago
- They are part of the homosapien lineage
- They ate primarily fruit
- About 17 million years ago, there was a change in a global cooling that created a land bridge that allowed many of these apes to migrate from Africa to Europe
- A few million years later, global cooling made it too cold in Europe to have year round fruit
- And many of them starved to death
- However, a small subset of them developed a **mutation in uric acid metabolism** that gave them a superpower
- That superpower was that they could be **much more efficient at turning fructose into fat**
- They had this little by-product which they would also make a boatload of uric acid along the way
- Those apes with that mutation returned to Africa and ultimately seeded the rest of the species
- Ultimately, that’s why we as humans are among the very rare animals that have uric acid levels that are quite high relative to other animals (cats and dogs, for example)

⇒ Check out Rick’s article in Scientific American: [Ancient Mutation in Apes May Explain Human Obesity and Diabetes](https://www.scientificamerican.com/article/ancient-mutation-in-apes-may-explain-human-obesity-and-diabetes/)

## The problems with elevated uric acid levels, and what it tells us about how sugar causes disease [31:30]

- The classic story told is that human’s get gout because of too much uric acid
- And we increase our uric acid by eating too much meat and protein
- But the story is more nuanced, says Peter

**How we get gout**:

-First, what are purines?

- We have proteins, we have fat, we have carbohydrates
- But we also have things like RNA and DNA which are what we call nucleic acids
- Nucleic acids are in the nucleus of cells that help drive gene formation and help dictate the production of proteins
- When DNA and RNA are broken down, they’re made up of purines
- Uric acid is a purine and it’s basically the ultimate breakdown product of DNA and RNA

-So the way we get gout…

- The way you get gout from protein is from the DNA and RNA in the protein
- That relates to some extent to how dense the nuclei are.
- If you have a very cellular thing like a anchovies that have lots of DNA and RNA, you can get gout from that much easier than from other types of meat
- Beer, for example, has brewer’s yeast and that is filled with RNA and so that’s why [beer can precipitate gout](https://www.ncbi.nlm.nih.gov/pubmed/15094272)

*Uric acid levels in men vs. women*:

- Men have higher levels of uric acid, generally
- Estrogen helps keep uric acid levels down (so after menopause, uric acid levels go up)
- Also, men may eat more meat

**Gout increased by sugar**

“*Gout is also increased by sugar*” says Rick

- In fact, [Sir William Osler observed this](https://www.amazon.com/Principles-Practice-Medicine-William-Osler/dp/1230431888) in the 1890s
- The reason is because of the fructose content and when the fructose is metabolized, it generates uric acid
- In the 1800s, the wealthier populations were drinking beverages sweetened with sugar
- Rick wrote a [paper](https://academic.oup.com/rheumatology/article/52/3/421/1776400) where he reviewed how much sugar was put in alcoholic drinks back in the 1800s and it was much more than today

![](https://peterattiamd.com/wp-content/uploads/2020/01/sugar-loaf-pub-rickjohnson-1024x531.png)**Figure 1. *The Crown and Sugar Loaf.*** **Sugar and fruits were commonly added to alcohol-containing drinks in 17th- to 19th-century England. This is a pub in the vicinity of St Paul’s Cathedral in London that dates back to at least the early 1800s. Sugar or fruits were commonly added to a wide variety of drinks, including sack and sugar, punch, hippocras and beer.** Image credit: [Rivard et al., 2013](https://academic.oup.com/rheumatology/article/52/3/421/1776400)

**The effect of uric acid on blood pressure**

-Peter credits Rick for making him aware that uric acid can lead to high blood pressure

*-How did Rick discover this?*

- Originally, they were studying what causes high blood pressure and some epidemiologic studies linked uric acid with high blood pressure
- We also knew that there were subtle changes going on in the kidney associated with high blood pressure
- And people with gout often have low grade kidney disease
- So the thought was, “*Maybe uric acid could have a role in causing kidney disease through causing high blood pressure through its ability to cause kidney disease*”

Next, Rick did a [study](https://www.ncbi.nlm.nih.gov/pubmed/11711505) in rats…

- Gave rats uricase inhibitor to raise the uric acid of an animal,
- And the animals developed high blood pressure
- Then, Rick could lower their blood pressure by lowering their uric acid
- The original thought was that it was the crystals of uric acid in the kidney, but they looked in the kidney there weren’t any crystals there
- So then we realized it was an effect of **soluble uric acid**
- Rick then started putting soluble uric acid on cells and saw that it was causing **pro-inflammatory** effects

-Rick began to think “*if fructose/sugar raises uric acid, maybe sugar could have a role in blood pressure.*”

- Next, Rick did another [experiment](https://www.ncbi.nlm.nih.gov/pubmed/16234313) where he gave rats fructose…
  - And the animals developed high blood pressure
  - They then gave them allopurinol (a drug to lower uric acid by blocking its formation) and it made their blood pressure go back to normal
  - “*It was like this big discovery.*” says Rick
  - Even more exciting was these animals also developed
    - Insulin resistance
    - Elevated triglycerides in their blood
    - Fatty liver
      - And when they lowered uric acid, there were benefits in all of those parameters

> “As we studied this, we started realizing that the process by which uric acid is generated is important in how sugar causes disease.”

## How sugar causes obesity—explaining the difference in glucose vs. fructose metabolism and the critical pathway induced by fructose [40:00]

**Difference in metabolism of glucose vs. fructose**

- Although they look alike, the metabolism of fructose is extremely different from the metabolism of glucose
- When fructose is metabolized, there’s this process that causes **the energy in the cell to fall** before it goes up
- Normally when you eat a calorie, we use it to **make** energy
- But when you eat fructose, the energy in the cell **falls** *before* it goes up

> “Fructose is the only nutrient that lowers energy in the cell.”

*-How does that fall in energy happen?*

- Whenever you metabolize any kind of calorie, we try to break down the food and we use it to make energy, that energy is called [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate).
- ATP is the currency in our body that we use to make us run, walk, think, talk, everything
- But to make ATP, you have to **spend a little of it to make it** ⇒
  - The process of breaking down and metabolizing food or glucose or fructose requires spending a little bit of ATP before you make it more of it
- When metabolising **glucose**… you do spend some ATP, but the body has a system whereby it feeds back to stop the process (via an enzyme called [phosphofructokinase](https://en.wikipedia.org/wiki/Phosphofructokinase)) before any significant ATP depletion occurs
- But when **fructose** is metabolized… the enzyme that metabolizes fructose is called [fructokinase](https://en.wikipedia.org/wiki/Fructokinase)
  - And when that metabolizes fructose, it consumes ATP in an *unregulated* way
  - So if the cell sees a lot of fructose, the ATP levels can plummet by 40 or 50% in the cell
  - And that produces a “May Day” signal, “*we’re under attack, we’re running out of energy!*”
  - So it switches the animal into a condition in which they’re trying to preserve their energy
    - They reduce their metabolism
    - They reduce their resting energy expenditure
    - They push the calories eaten into fat and glycogen as opposed to making more ATP as a way to protect the body by putting you into a system where you try to store fuel
    - Additionally, it triggers **hunger and thirst** that makes you want to eat more so you eat more to restore the energy but at the expense that you’re shunting much of it into fat and into fuel storage

> “Fructose turns out to be used by animals as a mechanism to store fat.”

–*Weight regulation*:

- Normally animals will regulate their weight beautifully
- *If you force feed* an animal to make it gain weight, the animal will go right back to its normal weight when you stop
- *If you starve* an animal until it’s below its normal weight and then you let it just eat, it will eat back to its regular weight
- **But when it wants to gain fat**… it will do so usually through a mechanism that involves fructose
- A hibernating animal or a migrating bird, for example, will start eating a lot of fruit in to increase its weight
- It gets hungry, it drops its metabolism so that most of the energy it eats goes into fat.
- “*And so this is a very common pattern and it’s driven by that ATP depletion.*”

*In summary:*

- Fructose cause a depletion of ATP
- This depletion triggers a series of reactions
- The **key reaction** is that…
  - a) not only does ATP decrease in the cell, but…
  - b) **intracellular phosphate** also falls
- And that activates an enzyme called [AMP deaminase](https://en.wikipedia.org/wiki/AMP_deaminase) (AMPD) that takes the broken down product of ATP (which is AMP) and it converts it to **uric acid**
- And that process has multiple steps, and those steps are involved with the generation of:
  - Increase in body fat
  - insulin resistance
  - fatty liver
  - elevations in blood pressure
- And that pathway is what seems to be **critical for inducing obesity from sugar**

![](https://peterattiamd.com/wp-content/uploads/2020/01/fructose-to-obesity-rickjohnson.png)

**Figure 2. An oversimplified visual of the process by which sugar consumption can lead to obesity.**

**Further explaining the AMPK vs. AMPD pathway**

The pathway discussed below is a big part of Rick’s book, [The Fat Switch](https://www.amazon.com/Fat-Switch-Richard-Johnson-M-D/dp/0615648002/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)

-Adenosine triphosphate = ATP

- The T stands for “tri” meaning 3 phosphates
- The liberation of a phosphate is the production of energy
- That liberation create [adenosine diphosphate](https://en.wikipedia.org/wiki/Adenosine_diphosphate) (A**D**P)
- Another phosphate can be donated to the production of energy which creates [adenosine monophosphate](https://en.wikipedia.org/wiki/Adenosine_monophosphate) (AMP)
- This is where there is a “fork” in the road…

…Next, it can either:

- go down a path that is driven by something called [AMP kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase) (AMPK)
- or it can go down the pathway of AMPD

-If it goes towards AMPK pathway…

- Burns energy, **burns fat**

-If it goes towards AMPD pathway…

- It does the opposite, it **stores energy**

-If you stimulate AMPD…

- you can cause insulin resistance and eventually diabetes

-Whereas if you stimulate AMPK…

- you can actually use that like metformin to actually treat diabetes

*What drives the switch to tell it which pathway to go?*

- The switch towards AMPD is the **fallen intracellular phosphate**
- And the reason that phosphate falls is because it’s taken up by fructose
- The fructose gets phosphorylated by the ATP and it becomes fructose one phosphate that sequesters phosphate.
- This is the process where both ATP levels fall and intracellular phosphate falls and that triggers this AMPD pathway
- And if you interrupt the AMPD pathway, you can **block a lot of the metabolic effects**

⇒ Here’s [Rick’s study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4391924/) showing hibernating squirrels will activate the pathway for AMPD when it wants to gain weight in prep for hibernation and when it’s ready to burn fat it will activate AMPK

**Back to uric acid**:

- Part of the pathway through which AMPD is working involves the generation of uric acid
- When the uric acid is going up inside the cell it’s doing all kinds of biologic effects and the **AMPD is driving that**
- Our uric acid mutation compounds our issue
  - Interesting fact: Dinosaurs also had this mutation and “[Sue the dinosaur](https://en.wikipedia.org/wiki/Sue_(dinosaur))” actually [had gout](https://www.ncbi.nlm.nih.gov/pubmed/9163417)

## Why drinking sugar is worse than eating it [50:00]

> “Sugar is much more likely to cause obesity if you drink it rather than if you eat it.”

**Drinking sugar**

- Drinking sugar is much more likely to cause problems compared to eating sugar, says Rick
- The reason is that **when you drink a drink that has fructose in it, we tend to drink a lot in a short period of time**
- And when fructose gets to the liver, it’s the **concentration** that triggers this reaction
- If the concentration of fructose is really low, the ATP depletion may not be significant to drive dramatic metabolic effects
- In other words… **equal amounts of fructose can produce a different effect if both the speed and the concentration are different**

*It’s really about the* ***rapidness of absorption***:

- So drinking a sugary soda on an empty stomach will be absorbed faster … and that fast absorption really triggers the AMPD
- But slowly eating a high protein meal with the same amount of sugar as that soda, may not deplete the phosphate enough to really trigger AMPD

## Unique ability of sugar to drive oxidative stress to the mitochondria, insulin resistance, and diabetes [54:00]

-Signs of metabolic syndrome include:

1. Elevated blood sugar
2. Elevated blood pressure
3. Elevated waist circumference
4. Elevated triglycerides
5. And low HDL

- Fructose does all five, says Rick
- Although he’s not as clear about the mechanism regarding lowering HDL

**How fructose leads to high triglycerides**

- Uric acid generated by fructose
- Fructose also generates a lot of lactate
- Fructose also preferentially decreases mitochondrial function and stimulates glycolysis
- All those things cause **big oxidative stress to the mitochondria**

–*Why is oxidative stress to the mitochondria a bad thing?*

- There’s an enzyme in the mitochondria that drives fat oxidation called [enoyl-CoA hydratase](https://en.wikipedia.org/wiki/Enoyl-CoA_hydratase)
- The oxidative stress inhibits enoyl-CoA hydratase so fatty acid oxidation goes down (**aka you block fat burning**)
- In addition, an enzyme called [aconitase](https://en.wikipedia.org/wiki/Aconitase) gets blocked with oxidative stress of the mitochondria
- Inhibition of aconitase increases citrate which drives fat generation
- So you end up with **fatty liver** that’s driven by both
  - i) increased fat synthesis and
  - ii) a block in fat burning
- Mitochondrial oxidative stress also is very much [linked](https://www.ncbi.nlm.nih.gov/pubmed/19805130) with the development of insulin resistance

**Uric acid’s effect on the pancreas**

- The generation uric acid is also causing oxidative stress to the pancreatic islets, says Rick

**Rick’s** [**study**](https://www.ncbi.nlm.nih.gov/pubmed/16234313/) **giving rats a high sugar diet:**

- One group of rats were getting a low-calorie diet but one that was **high in sugar**
- As a control, they gave rats that got the same number of calories but **without the sugar**

-Results

- Both groups maintained their weight
- In other words, despite getting 90% of typical calories, they *slowed their metabolism* enough to maintain their weight
- However, the high sugar rats developed fatty liver, hypertension, insulin resistance, and diabetes
- The high sugar rats got 20% of their calories from fructose

-More observations:

- They first became insulin resistant with high serum insulin levels (what we see in early **type 2 diabetes** patients)
- Over time, the rats serum insulin levels began to fall, resembling **type 1 diabetes**
  - This is just like humans do

-Additionally…

- There was low grade inflammation in the pancreatic islets and it was associated with big time upregulation of uric transport proteins on the islet
- When we put uric acid on the islets, it induced oxidative stress and over time caused a **drop in insulin level**

“*What we think is going on is that sugar causes diabetes through this pathway that we’ve been talking about and it involves initially insulin resistance,* ***but over time it will cause islet cell dysfunction as well****.*”

**Could removing fructose solve all our metabolic problems?**

- **Peter**: *If we were to remove fructose completely from our diet, would all the bad things that happen to us metabolically simply go away*?
- **Rick**: *Yeah, I think that’s true*.

## Why cancer loves fructose [1:00:20]

For cancer cells… **fructose can be an incredible survival nutrient in the setting of near starvation**

*Rick explains…*

-Many animals get fructose from 2 sources:

- From their diet; or
- They **make it** in their body

-They use fructose to help them survive

- *For example*, animals use fructose to become insulin resistant as a **survival mechanism**
- Insulin resistance can be a survival mechanism whereby it increases blood glucose and prevent glucose from taken up in the muscle in order to **preserve it for the brain**
- This is exactly what you want to do if you don’t have enough food around, you want to be able to think so you can escape predators, find food, etc.
- So it was a survival tool to increase energy

-Additionally, fructose also can protect animals from a **low oxygen state**

- Fructose will reduce mitochondrial function and stimulate glycolysis which allows the animal to survive with a lower oxygen state
- **For example**, the naked mole rat lives in very low oxygen burrows
  - They [make fructose to survive](https://phys.org/news/2017-04-naked-mole-rats-oxygen.html) when they’re in those burrows
  - So the fructose goes up in their blood
  - They use it to survive the low oxygen tension there because they **switch from mitochondrial metabolism to glycolysis**

*-Why can’t animals just rely more on glucose for which we have such an abundant apparatus to store it at large amounts?*

- A lot of the fructose is converted to lactic which it can then be converted to glucose
- Then it’s driven through this glycolysis pathway
- It turns out though that what happens is when you metabolize glucose, a lot of it will go through mitochondrial metabolism.
- And so if we can inhibit mitochondrial metabolism (which uses oxygen), we can live off glycolysis (which doesn’t require oxygen)

*-But isn’t fructose stored as fat which is the* ***worst*** *fuel for a low-oxygen environment?*

- Well, fructose is increasing glycogen *and* lipid, but it’s also reducing mitochondrial use
- When you’re eating fructose, you actually are not burning the fat, you are storing the fat
- And when coming the fructose, your metabolism switches to a glycolytic state which is helping them to survive low oxygen environments

**Back to cancer…**

- Unfortunately, cancers also live in the low oxygen state
- So cancers love fructose as their fuel because it helps support them surviving in the low oxygen state
- Many cancers (colon, liver, kidney, breast, brain, all these cancer cells, intestinal) tend to like fructose as their preferential fuel

-If you block fructokinase, many cancers don’t do as well

- If you take intestinal colon cancer, for example, and [you put high fructose corn syrup on it](https://www.sciencedaily.com/releases/2019/03/190321141924.htm), they love it, they grow, they metastasize…
- …But if you block fructokinase and block fructose metabolism, you can block a lot of the growth of those cancers by 50+%
- Furthermore, we know **it’s the fructose and NOT the glucose** because the glucose metabolism pathway was not blocked at all in that experiment
- “*They were able to show that this was driven by that shift from a mitochondrial based metabolism to a glycolytic metabolism.*”

## The many areas of the body that can use fructose [1:05:00]

**Fructose and lactate**

-The more fructose given to a cell, the more lactate will increase

- This is counterintuitive, says Peter…
- …*Isn’t the liver the only organ that really has interaction with fructose*?
  - Rick says no…
    - About 20% of fructose is used by the intestine
    - Maybe 40% by the liver, and
    - At least [10 to 20% can escape into the circulation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2653686/) and cause problems to the kidney for example (The larger the dose, the more that will escape)
      - And the kidneys is a big target once it passed the liver and intestine
    - There’s fructokinase in the brain
    - There’s fructokinase in the islets
    - There’s fructokinase in the adipose tissue
    - And maybe even a very low amount in the skeletal muscle
    - The heart can even create it when needed

⇒ There was a [paper in Nature](https://www.nature.com/articles/nature14508) showing that the heart can even use fructose under some circumstances

- The heart normally doesn’t have fructokinase
- But when you have a heart attack, the low oxygen state  induces the fructokinase
- And there’s probably endogenous production of fructose
- And it seems to be involved in cardiac remodeling

*Can the brain actually use fructose?*

- In theory the brain could actually use free molecules of fructose to make ATP in addition to the mainstay of its energy metabolism, which is glucose and lactate
- There is actually [some evidence](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5420427/) that fructokinase is in the brain and that the brain can make fructose
- And there’s [increasing evidence](https://www.ncbi.nlm.nih.gov/pubmed/19625744) that insulin resistance can occur in the brain which might be an explanation for the development of Alzheimer’s disease
- There are [reports](https://www.ncbi.nlm.nih.gov/pubmed/9880040) that AMP deaminase is high in the brains of Alzheimer’s patients

## Fructokinase inhibitors—a potential blockbuster? [1:07:15]

*Are there any people with naturally occurring mutations in fructokinase that render it less capable?*

- There’s a condition called the [essential fructosuria](https://en.wikipedia.org/wiki/Essential_fructosuria) where they are born without active fructokinase and they live normally
- These people don’t get type 2 diabetes or obesity
- It’s a rare condition but that are basically immune to the harmful effects of sugar

*Is there any benefit to having fructokinase if you’re not hibernating or in a world where famine is potentially come in your way?*

- Fructokinase was an evolutionary thing that allowed us to survive long periods without food
- So in the Western world where we have an abundance of food it’s really not necessary
- In fact, Rick thinks “*living without fructokinase would probably solve a lot of the world’s health problems*”

**Fructokinase inhibitors**

- There are fructokinase inhibitors that are being [developed by Pfizer](https://www.bloomberg.com/news/articles/2019-03-27/pfizer-s-midstage-nash-study-finds-improvement-to-fatty-liver)
- It was quite successful at treating fatty liver and so now they’re taking that drug to phase three
- Peter says “*wow, that’s a potential blockbuster*”

## Treating high uric acid levels—Rick’s approach with patients [1:10:00]

**Lowering uric acid**

*-If patients have high uric acid levels but are not yet experiencing gout, does Rick still lower it?*

- Yes he does, typically with [allopurinol](https://www.webmd.com/drugs/2/drug-8610/allopurinol-oral/details)
- Side effects of allopurinol
  - Some people get severe rashes ([Stevens-Johnson Syndrome](https://en.wikipedia.org/wiki/Stevens%E2%80%93Johnson_syndrome))
    - About 3% to 4% of Asians
    - About 2% in African Americans
    - About 0.5% in Caucasians
  - You can test for the allergy to allopurinol — [HLA B58 test](https://www.google.com/search?sxsrf=ACYBGNTp1xpLICU5htfm1DaNKyC9GaIa6g:1577569314669&q=HLA+B58+test&spell=1&sa=X&ved=2ahUKEwjN0e_Up9nmAhVOU80KHSK1DQIQBSgAegQIDBAn&biw=727&bih=695&dpr=2)

–*Reasons other than gout to lower uric acid:*

- It may [improve insulin sensitivity](https://www.ncbi.nlm.nih.gov/pubmed/19933411)
- It may benefit kidney disease
- Improves blood pressure (Rick’s [JAMA paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2684336/) showed improvement in blood pressure in adolescents with hyperuricemia)

–*What is the target uric acid level?*

- Risks start to go up when the **serum uric acid is over 5.5** for prediabetes, insulin resistance, hypertension, kidney disease, etc.
- Many labs, like the one Peter uses, doesn’t flag levels of uric acid until it hits 7.5 (but this is only through the lens of gout)
- Rick will always treat it if the level is 8 or higher
- If it’s between 5.5 and 8, he generally has the discussion with the patient about the pros and cons of treatment
- For those with kidney disease, he recommends treatment even at 6.5

–*Alternative to allopurinol?*

- [Febuxostat](https://www.webmd.com/drugs/2/drug-151868/febuxostat-oral/details) probably works just as good as allopurinol, says Rick
  - But some people are concerned about an increased risk of cardiovascular mortality after the [CARES trial](https://www.ncbi.nlm.nih.gov/pubmed/29527974/) when compared to allopurinol
    - But the problem with that study was that there was no placebo group
  - Plus Febuxostat is more expensive than allopurinol

## Salt intake—what advice does Rick give his patients? [1:16:30]

**Salt and blood pressure**:

- In general, salt does play a role in blood pressure
- However, it’s NOT just about the total amount of salt
- It’s the **combination of salt and water**
- You want to avoid an increase in serum sodium and you can reduce that by drinking water BEFORE eating a salty meal
- *Example …* If you eat something salty and then you get really thirsty, that’s a sign that you’ve already raised your serum sodium
- When you eat salt, you’re making fructose in your body
- And the fructose is then driving a lot of effects

**Salt and obesity and diabetes**:

- But high salt diets aren’t just about blood pressure…
- High salt diets are associated with obesity and the development of diabetes
- And high **salt looks like it works by producing fructose**

> “What we’ve tried to do is to tell [patients] to drink a lot of water and to reduce their salt, but it isn’t the amount of salt, it’s the balance of salt and water.”

**Salt and kidney disease**:

- People with kidney disease have to be **more** conscious of reducing salt consumption
- However, increased [water intake may slow the progression of kidney disease](https://www.ncbi.nlm.nih.gov/pubmed/23673384)

***Can drinking water help keep you skinny?***

- Many animals use fructose to make fat as a means for making water
- When you make fat, although there’s no water stored in the fat, when you **burn** the fat, it makes water
- Whales, for example, don’t drink saltwater, they drink “metabolic water” by breaking down their fat
- Fructose drives fat production in part to preserve water (not just energy)
- If you take an animal that’s consuming high fructose, you can suppress some of the obesity and metabolic syndrome by giving it a lot of water

> “And so the old wives tale that ‘drinking six glasses of water a day is good to help keep you skinny’ is true. It turns out that water suppresses some of the effects of fructose.”

## How excess glucose (i.e., high carb diets) can cause problems even in the absence of fructose [1:21:00]

*What advice does Rick have to “healthy” people?*

1 | Reduce fructose

- If we could reduce our fructose intake, it would have a HUGE effect
- Unfortunately, this is easier said than done b/c sugar and high fructose corn syrup are in almost everything (especially processed foods)

2 | Secondly, be careful with other things that are used to MAKE fructose

- We can make fructose from a **high salt diet**
- We can make fructose if we get **dehydrated**
- High **uric acid** stimulates fructose production
- And in all these situations, we’re **MAKING fructose from glucose**

**The glucose-to-fructose conversion**

-If you give high amounts of glucose to an animal… as the glucose hits the liver it induces an enzyme called [aldose reductase](https://en.wikipedia.org/wiki/Aldose_reductase) which converts glucose to fructose

*-Rick’s* [*experiment*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3833672/) *showed that when feeding mice high glucose it can convert to fructose endogenously*

- Rick took mice and overfed them glucose in liquid form
- The hypothesis was that they weren’t going to see much since they believed fructose was the culprit
- But over time these animals got really fat and insulin resistant
- When looking at the portal vein, which goes into the liver, the glucose levels were high and that activated aldose reductase and it started to make fructose
- So even though these animals were eating *zero fructose*, they were *producing fructose* in their liver
- Furthermore…when they **blocked their fructose metabolism**, even though they’re eating the **same amount of glucose…**
  - They’re not getting as fat
  - They have no fatty liver
  - They’re not insulin resistant

*-Does this suggest that you get fatty liver from excess glucose even if it’s not high in sugar?*

- Yeah, absolutely, if you have that enzyme induced
- A young person, for example, this aldose reductase enzyme is really not present in the liver, so glucose will not be nearly as problematic
- Once you’re eating enough sugar, though, it will induce that enzyme

–*Fast forward and says that you eat a lot of sugar and you get obese*

- Normally, you could reverse the induction of this aldose reductase enzyme within a few weeks by restricting sugar…
- …but once your uric acid goes up that will keep it elevated (regardless of sugar intake)
  - Another reason potentially to use allopurinol in addition to fructose restriction to keep uric acid low and mitigate the induction of aldose reductase

*-What happens if a skinny health person lives primarily on potatoes?*

- If you give a starch or potatoes to a skinny person who does not have aldose reductase induced, they can eat the potatoes they want
- In Ireland back in the 1700s, for example, potato was basically the main thing they were eating and there wasn’t a lot of obesity
- But a high starch diet becomes a much bigger problem AFTER you get metabolic syndrome
- Because once you have metabolic syndrome…
  - Let’s say you stop eating sugar but you continue to eat carbs
  - The carbs are going to continue to activate through the same pathway
  - This is why **a low carb diet is really great for metabolically ill people**

> “A low carb diet. . .is removing the high glycemic carbs that are driving the disease, but it’s through fructose.”

**How much fructose can be produced in a fructose free intake environment just from glucose?**

- It probably takes a lot if you are starting with a young, healthy person
- However, if you’ve already triggered the production of the aldose reductase enzyme, you probably don’t have to give a lot

**Is excess carbs really the problem? Or it is just excess energy (like from fat)?**

- It’s *definitely* about a particular carbohydrate, says Rick
- The way fructose works is **it works by making you eat more** and that’s how you gain weight
- A [high fructose diet causes leptin resistance](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2584858/) where you want to eat more
- But when using pair feeding in rats…
  - You can control for the calorie intake
  - And it’s true in that scenario, the animals won’t gain weight
  - But the high fructose, calorie controlled diet will still cause
    - Fatty liver
    - Insulin resistance
    - Metabolic syndrome
    - And so on
- The sugar industry will do these studies to say “*See! A calorie is a calorie when it comes to weight gain*”
  - But in real life…
    - People can’t put a clamp on their food consumption nearly as easily in a controlled environment
    - Eventually leptin resistance causes animals to lose the ability to control their appetite leading to weight gain
    - AND… even without weight gain you can get metabolic syndrome, fatty liver, etc.

## Artificial sweeteners vs. real sugar—which is better? [1:29:15]

*Is a diet Coca-Cola better than a regular Coca-Cola?*

- Yeah, says Rick
- We have taste buds that sense sweet
- When we eat sugar, the taste buds are activated and it stimulates this dopamine response in the brain that tells us that we like this sugar
- If you [genetically knock out the sweet taste buds in animals](https://www.sciencedirect.com/science/article/pii/S0896627308001190)…
  - They still like sugar and they will still eat a lot of it
  - But they won’t like artificial sugar
  - In other words, the artificial sugar is driven by the sweet taste but what makes animals like real sugar is through its metabolism
- So even though but artificial and real sugar have the sweet taste and the dopamine response, the real sugar gives us some pleasure in the periphery where the metabolism takes place
- Animals will tend to eat a little bit less sugar when their taste buds are gone, but **they still eat enough to develop metabolic syndrome**

*What about weight gain with real vs. artificial sugar?*

- If you give a mouse artificial sugar, they don’t gain weight
- But if you give them regular sugar, they do

**Studies looking at aspartame and sucralose**

- Peter says aspartame has been studied more by the FDA than any other molecule ingested by humans
- So the idea that we “just don’t know” the full safety profile of these things is a little silly to say
- There are some studies suggesting risks such as…
  - Like Saccharin, for example, has been [associated with little bladder tumors in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1637197/)
  - [Aspartame can generate tiny concentrations of formaldehyde](https://www.ncbi.nlm.nih.gov/pubmed/18627677)
- HOWEVER… those studies were really based on rodents consuming **doses that simply couldn’t be replicated by humans**

> “If a person says to me, ‘Oh doc, I’m afraid to drink this diet Coke because it’s got chemicals in it, I want to drink regular Coke because of that.’ That’s an error. **Regular Coke is more dangerous than a diet Coke.**”

## Umami, MSG, alcohol, beer—do these have a role in metabolic illness? [1:33:45]

***What is umami?***

- It is the savory taste in food
- There are five basic tastes: sweet, salty, sour, bitter and savory (umami)

**Weight gain and the basic tastes**

- Sweet and salty tastes are the most associated with weight gain
- Rick says that for a lab animal to gain weight, it takes…
  - 2 months with sugar
  - 4 months with salt (slower conversion to fructose)
  - And then it takes progressively longer in this order…
    - Umami
    - Bitter
    - Sour

**Facts about umami**

- Umami is driven by glutamate but it’s markedly enhanced by purines like [IMP](https://en.wikipedia.org/wiki/Inosinic_acid) and even [uric acid](https://en.wikipedia.org/wiki/Uric_acid)
- Umami is sort of a taste receptor for uric acid type foods (i.e., Foods that raise uric acid)
- *Example*, MSG is the purest form of Umami that we eat (found in chinese food)
  - MSG is the primary stimulant and people put it in foods to encourage food intake

**Umami and obesity**

- Some link of umami with obesity in epidemiologic studies
- Some situations where you can induce obesity with umami (especially in liquid form)
- *Peter’s take*: He thinks the idea that umami (or MSG) is harmful is largely unfounded in the literature

*-What common foods have umami?*

- Shrimp
- Caesar Salad

*-Is umami healthy?*

- Many websites promote umami as if it’s very healthy for you
- But Rick says it may not be as safe as we think
- For instance… if umami foods have a lot of purines which enhance the umami flavor, it actually may **raise uric acid and kind of bypass the sugar pathway**

*-Does Rick add the MSG-containing/high umami foods to the playbook for ways to reduce metabolic disease?*

- Yes, says Rick
- Foods like shrimp, if you eat a lot of them, they probably activate this pathway too

**Ranking some contributing factors to metabolic disease**:

- 1) Number one is sugar (everything else is less)
- 2) High glycemic carbs can be converted to sugar
  - The big four high glycemic food to reduce:
    - 1) Bread
    - 2) Potatoes
    - 3) Chips
    - 4) Rice
- 3) Really salty foods (which can be mitigated by drinking water prior to eating salt)

**Beer and umami**

- What makes beer so much more dangerous than other alcohols for inducing obesity is because **beer has a ton of brewers’ yeast which basically is activating the umami pathways** (which is one of the reasons we like beers)

*-Beer belly syndrome*:

- People who drink a lot of beer don’t just get abdominal obesity…
  - they get fatty liver
  - they get high blood pressure,
  - their triglycerides go up.
  - They basically have metabolic syndrome

> “Alcohol, especially beer, can also mimic sugar and it’s probably because of the umami component coupled with the alcohol.”

**Peter’s take**:

“*This is the part that can sometimes drive a person insane when they’re trying to think about all of these things…*

*…It’s very difficult to provide clear advice to people because there’s so many caveats that are required because the dose makes the poison, the speed of delivery, what it’s combined with all of these things, but I’m using that as a preface to ask a question that I’m sure you get asked a lot, which is really a dose question around fructose.*”

## Fructose consumption—Is any amount acceptable? Is fruit okay? Where does Rick draw a hard line? [1:38:45]

**Liquid fructose:**

*In the form of fruit juices, sports drinks, and sodas, where does Rick draw the line?*

- “Personally, I would not drink **any liquids that have sugar** in it or fructose or high fructose corn syrup.”
- He draws a hard line at liquid sugar

**What about eating fructose in the form of fruit?**

- Rick has [shown](https://www.ncbi.nlm.nih.gov/pubmed/21621801) that patients on a low fructose diet, that then added in a single fruit to their diet, did just as good as the no fruit group

*-What are some low fructose fruits?*

- Kiwi and lime and lemon have almost no fructose
- Blueberries, raspberries, strawberries are very good
- “*You can eat a big bowl of blueberries, no problem.*”

–*In contrast*, grapes have a lot of sugar

- A bowl of grapes are likely going to raise uric acid and trigger the activation of the this pathway

> “What I would recommend is to try to not eat too many fruit at one time.”

- If you eat a huge amount of fruit and get all that fructose it will start to overwhelm the good things in fruit
- Good things like vitamin C, epicatechin, flavonols, and potassium and all these things that help fight the effects of fructose.

**What Peter recommends to patients**: “*For patients that have a non-alcoholic fatty liver disease, we tend to restrict them to 10 grams a day of fructose, only in the form of whole fruit.*”

- This means no grapes, no bananas, no large apples, etc.

## How does Rick manage the sugar intake of his young kids? [1:43:00]

**How does Rick handle sugar consumption for his kids?**

- First of all, things like birthdays, he lets them have birthday cake
- If they make a cake at home, they will try to sub out some sugar for splenda
- Absolutely no fruit juice or regular soft drinks
- But they can have a diet soft drink now and then
- Rick says he wants to make sure they understand WHY, rather than just be an authoritarian

> “What we try to do is not to be so restrictive that it’s disruptive but we try to be encouraging them to understand that sugar is playing a big role in obesity and diabetes and that it’s unhealthy to eat a lot.”

**Teaching kids about sugar**

- Rick is involved with the [Living Closer Foundation](https://www.livingcloser.com/) which tries to teach children how to look at labels on foods to understand the amount of sugar
- One experiment they do with kids is to demonstrate that if you put the same sugar in a coke into a cup of tea, it is nearly unpalatable to drink
- But the carbonation in soda masks this to some degree

**What is Rick’s take on dried fruit?**

Dried fruit is the fructose of fruits without the good things in it

“*…it’s like pure fructose.*”

⇒ Check out Rick’s many publications [here](https://www.ncbi.nlm.nih.gov/pubmed/?term=Johnson+RJ%5BAuthor%5D)

§

## Selected Links / Related Material

**Rick’s book**: [The Fat Switch](https://www.amazon.com/Fat-Switch-Richard-Johnson-M-D/dp/0615648002/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Richard J. Johnson | (amazon.com) [1:20, 46:00]

**When you raise uric acid in animals, they developed high blood pressure**: [Elevated uric acid increases blood pressure in the rat by a novel crystal-independent mechanism.](https://www.ncbi.nlm.nih.gov/pubmed/11711505) (Mazzali et al., 2001) [5:00]

**Rick’s 2018 study showed that drinking water with a salty meal will prevent a rise in blood pressure**: [Acute effects of salt on blood pressure are mediated by serum osmolality.](https://onlinelibrary.wiley.com/doi/full/10.1111/jch.13374) (Kanbay et al., 2018) [8:00]

**If blood pressure is really low, it increases the risk for kidney failure**: [Too-low diastolic blood pressure can be deadly for CKD patients](https://www.sciencedaily.com/releases/2013/08/130819185346.htm) | (sciencedaily.com) [11:15]

**Kidneys normally handles salt just fine, but they develop or acquire a change in the kidneys that lead them to hold onto sodium due to inflammation that occurs in the kidney**: [Uric Acid, Hominoid Evolution, and the Pathogenesis of Salt-Sensitivity](https://www.ahajournals.org/doi/full/10.1161/01.hyp.0000028589.66335.aa) (Watanabe et al., 2002) [12:30]

**Kidney inflammatory (leading to high blood pressure) can be an autoimmune reaction to heat shock proteins**: [The role of autoimmune reactivity induced by heat shock protein 70 in the pathogenesis of essential hypertension.](https://www.ncbi.nlm.nih.gov/pubmed/29679484) (Rodriguez-Iturbe et al, 2019) [14:45]

**Genetic polymorphisms that link with the development of primary hypertension and most of them are involved with the immune response to heat shock proteins**: [International Consortium for Blood Pressure](https://www.ncbi.nlm.nih.gov/projects/gap/cgi-bin/study.cgi?study_id=phs000585.v2.p1) (Genome-Wide Association Studies, 2011) [16:30]

**A high salt intake in mice increases serum sodium and activates an enzyme that converts glucose to fructose**: [Endogenous fructose production and metabolism in the liver contributes to the development of metabolic syndrome](https://www.nature.com/articles/ncomms3434) (Lanaspa et al., 2013) [18:30]

**Rick’s paper showed you can block the rise in blood pressure from a high salt intake when you block the metabolism of fructose**: [High salt intake causes leptin resistance and obesity in mice by stimulating endogenous fructose production and metabolism.](https://www.ncbi.nlm.nih.gov/pubmed/29507217) (Lanaspa et al., 2018) [18:30]

**Peter’s podcast episode with Rob Lustig discussing fructose**: [#14 – Robert Lustig, M.D., M.S.L.: fructose, processed food, NAFLD, and changing the food system](https://peterattiamd.com/roblustig/) | Peter Attia (peterattiamd.com) [19:45]

**Rick’s article in Scientific American about the mutation in apes that migrated from Europe to Africa millions of years ago**: [Ancient Mutation in Apes May Explain Human Obesity and Diabetes](https://www.scientificamerican.com/article/ancient-mutation-in-apes-may-explain-human-obesity-and-diabetes/) | Richard J. Johnson and Peter Andrews (scientificamerican.com) [29:00]

- *And here’s the 2011 paper*: [Fructose, uricase, and the Back‐to‐Africa hypothesis](https://onlinelibrary.wiley.com/doi/abs/10.1002/evan.20266) (Johnson and Andrews, 2011)

**Beer has brewer’s yeast that is filled with RNA and so that’s why beer can precipitate gout**: [Alcohol intake and risk of incident gout in men: a prospective study.](https://www.ncbi.nlm.nih.gov/pubmed/15094272) (Choi et al., 2004) [33:45]

**The book in which Sir William Osler pointed out that sugar (from sweet fruits) increased the risk of gout**: [The Principles and Practice of Medicine](https://www.amazon.com/Principles-Practice-Medicine-William-Osler/dp/1230431888) by Sir William Osler | (amazon.com) [35:00]

**Rick’s paper that reviewed how much sugar was put in alcoholic drinks back in the 1800s and it was much more than today**: [Sack and sugar, and the aetiology of gout in England between 1650 and 1900](https://academic.oup.com/rheumatology/article/52/3/421/1776400) (Rivard et al., 2013) [36:00]

**Rick’s study showing that inflammation was part of the reason that uric acid raises blood pressure**: [Elevated uric acid increases blood pressure in the rat by a novel crystal-independent mechanism.](https://www.ncbi.nlm.nih.gov/pubmed/11711505) (Mazzali et al., 2001) [37:30]

**Rick’s study showing fructose elevated uric acid which raised blood pressure, insulin resistance, increased TGs, caused fatty liver, but all of those parameters would improve by lowering uric acid with allopurinol**: [A causal role for uric acid in fructose-induced metabolic syndrome.](https://www.ncbi.nlm.nih.gov/pubmed/16234313) (Nakagawa et al., 2006) [38:00]

**Rick’s study showing hibernating squirrels will activate the pathway for AMPD when it wants to gain weight and when it’s hibernating and burning the fat, it activates the AMPK pathway**: [Opposing Activity Changes in AMP Deaminase and AMP-Activated Protein Kinase in the Hibernating Ground Squirrel](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4391924/) (Lanaspa et al., 2015) [48:30]

**The tyrannosaurus rex that had gout**:  [49:45]

- [Sue the dinosaur](https://en.wikipedia.org/wiki/Sue_(dinosaur)) | (wikipedia.org)
- [Tyrannosaurs suffered from gout.](https://www.ncbi.nlm.nih.gov/pubmed/9163417) (Rothschild et al., 1997)

**Mitochondrial oxidative stress also is very much linked with the development of insulin resistance**: [Insulin resistance is a cellular antioxidant defense mechanism.](https://www.ncbi.nlm.nih.gov/pubmed/19805130) (Hoehn et al., 2009) [55:45]

**Rick’s study giving rats a calorie restricted, high sugar diet which induced diabetes (without weight gain) and inflammation to the pancreatic islets**: [Sucrose induces fatty liver and pancreatic inflammation in male breeder rats independent of excess energy intake.](https://www.ncbi.nlm.nih.gov/pubmed/16234313/) (Nakagawa et al., 2006) [56:30]

**Naken mole rats survive in very low oxygen burrows by metabolising fructose**: [Naked mole-rats turn into plants when oxygen is low](https://phys.org/news/2017-04-naked-mole-rats-oxygen.html) | University of Illinois at Chicago (phys.org) [1:01:30]

**Putting high fructose corn syrup intestinal colon cancer will cause the cancer to grow and metastasize and if you block fructokinase and block fructose metabolism, you can reduce the growth**: [High-fructose corn syrup boosts intestinal tumor growth in mice](https://www.sciencedaily.com/releases/2019/03/190321141924.htm) | (sciencedaily.com) [1:04:15]

**Findings show that at least 10 to 20% of fructose can escape into the circulation which can cause kidney problems**: [Ketohexokinase-Dependent Metabolism of Fructose Induces Proinflammatory Mediators in Proximal Tubular Cells](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2653686/) (Cirillo et al., 2009)  [1:05:30]

**Paper that showed that the heart (which normally doesn’t have fructokinase) induces fructokinase and for production of endogenous fructose when in the low oxygen state of a heart attack and it seems to be involved in cardiac remodeling**: [HIF-driven SF3B1 induces KHK-C to enforce fructolysis and heart disease](https://www.nature.com/articles/nature14508) (Mirtschink et al., 2015) [1:06:00]

**Evidence that fructokinase is in the brain and that the brain can make fructose**: [Specific regions of the brain are capable of fructose metabolism](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5420427/) (Oppelt et al., 2018) [1:06:45]

**Evidence that insulin resistance can occur in the brain which might be an explanation for the development of Alzheimer’s disease**: [Effects of insulin and octreotide on memory and growth hormone in Alzheimer’s disease.](https://www.ncbi.nlm.nih.gov/pubmed/19625744) (Watson et al., 2009) [1:06:45]

**Paper reporting that AMP deaminate is high in the brains of Alzheimer’s patients**: [Elevated adenosine monophosphate deaminase activity in Alzheimer’s disease brain.](https://www.ncbi.nlm.nih.gov/pubmed/9880040) (Sims et al., 1998) [1:06:45]

**Fructokinase inhibitors that are being developed**: [Pfizer Study Finds Progress in Combating Fatty Liver](https://www.bloomberg.com/news/articles/2019-03-27/pfizer-s-midstage-nash-study-finds-improvement-to-fatty-liver) | Riley Griffin (bloomberg.com) [1:09:00]

**Study shows an improvement in insulin resistance with lowering uric acid in humans**: [Uric acid-lowering treatment with benzbromarone in patients with heart failure: a double-blind placebo-controlled crossover preliminary study.](https://www.ncbi.nlm.nih.gov/pubmed/19933411) (Ogino et al., 2010) [1:11:30]

**Rick’s paper showing uric acid could improve blood pressure in adolescents with hyperuricemia**: [Effect of Allopurinol on Blood Pressure of Adolescents With Newly Diagnosed Essential Hypertension: A Randomized Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2684336/) (Feig et al., 2009) [1:11:50]

**Severe rash which some people can get if they are allergic to allopurinol**: [Stevens-Johnson Syndrome](https://en.wikipedia.org/wiki/Stevens%E2%80%93Johnson_syndrome) | (wikipedia.org) [1:13:50]

**The flawed CARES trial suggesting Febuxostat was more risky than allopurinol in terms of cardiovascular death from events**: [Cardiovascular Safety of Febuxostat or Allopurinol in Patients with Gout.](https://www.ncbi.nlm.nih.gov/pubmed/29527974/) (White et al., 2018) [1:15:00]

**Drinking more water can potentially slow kidney disease progression**: [Impact of fluid intake in the prevention of urinary system diseases: a brief review.](https://www.ncbi.nlm.nih.gov/pubmed/23673384) (Lotan et al., 2013) [1:19:15]

**Mice given high glucose developed diabetes despite no fructose by converting glucose to glucose via aldose reductase**: [Endogenous fructose production and metabolism in the liver contributes to the development of metabolic syndrome](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3833672/) (Lanaspa et al., 2014) [1:23:00]

**When you give sugar to animals they become leptin resistant over time and they lose their ability to control their appetite**: [Fructose-induced leptin resistance exacerbates weight gain in response to subsequent high-fat feeding](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2584858/) (Shapiro et al., 2008) [1:29:00]

**Animals will still like sugar even after their taste buds are knocked out**: [Food Reward in the Absence of Taste Receptor Signaling](https://www.sciencedirect.com/science/article/pii/S0896627308001190) (Araujo et al., 2008) [1:29:45]

**Saccharin has been associated with little bladder tumors in mice**: [Carcinogenicity of saccharin.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1637197/) (M D Reuber, 1978) [1:32:45]

**Aspartame can generate small concentrations of formaldehyde**: [Formaldehyde, aspartame, and migraines: a possible connection.](https://www.ncbi.nlm.nih.gov/pubmed/18627677) (Jacob et al., 2008)  [1:32:45]

**Patients on a low fructose diet, that then added in a single fruit to their diet, did just as good as the no fruit group**: [The effect of two energy-restricted diets, a low-fructose diet versus a moderate natural fructose diet, on weight loss and metabolic syndrome parameters: a randomized controlled trial.](https://www.ncbi.nlm.nih.gov/pubmed/21621801) (Madero et al., 2011) [1:40:00]

**Cheryl Knott showed orangutans go on a feeding binge in fruit massing season as a way to gain weight and increase body fat to survive when food is less plentiful**: [Changes in Orangutan Caloric Intake, Energy Balance, and Ketones in Response to Fluctuating Fruit Availability](https://www.researchgate.net/publication/226346240_Changes_in_Orangutan_Caloric_Intake_Energy_Balance_and_Ketones_in_Response_to_Fluctuating_Fruit_Availability) (Cheryl D Knott, 1997) [1:41:30]

**Foundation that Rick worked with to teach school kids about eating healthy**: [Living Closer Foundation](https://www.livingcloser.com/) | (livingcloser.com) [1:44:30]

§

## People Mentioned

- [Robert Lustig](https://en.wikipedia.org/wiki/Robert_Lustig) (fructose expert; previous [podcast guest](https://peterattiamd.com/roblustig/) [19:45]
- [William Osler](https://en.wikipedia.org/wiki/William_Osler) (linked sugar to gout in the 1800s) [35:00, 1:08:00]
- [Cheryl Knott](https://www.bu.edu/anthrop/people/faculty/c-knott/) (anthropologist who studied orangutans) [1:41:30]

§

![](https://peterattiamd.com/wp-content/uploads/2020/01/bio-image-rickjohnson-500x500.jpg)

##### Rick Johnson, M.D.

Rick is a professor of medicine in the Department of Nephrology at the University of Colorado since 2008 and he’s spent the last 17 years being a division chief across three very prestigious medical schools. An unbelievably prolific author, Rick has well over 700 publications in JAMA, New England Journal of Medicine, Science, et Cetera. He’s lectured across 40 countries, authored two books, including The Fat Switch, and has been funded extensively by the National Institute of Health (NIH). His primary focus in research has been on the mechanisms causing kidney disease, but it was in doing this that he became really interested in the connection between fructose (and fructose metabolism) and obesity, diabetes, heart disease, hypertension, and metabolic disease.