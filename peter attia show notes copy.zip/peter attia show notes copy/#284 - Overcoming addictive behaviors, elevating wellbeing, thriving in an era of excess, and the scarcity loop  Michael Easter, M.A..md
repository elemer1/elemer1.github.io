# #284 ‒ Overcoming addictive behaviors, elevating wellbeing, thriving in an era of excess, and the scarcity loop | Michael Easter, M.A.

**Source:** [https://peterattiamd.com/michaeleaster2/](https://peterattiamd.com/michaeleaster2/)

---

Bestselling author Michael Easter returns to The Drive to discuss his new book, [*Scarcity Brain*](https://www.amazon.com/Scarcity-Brain-Craving-Mindset-Rewire/dp/0593236629). In this episode, Michael explores the evolutionary backdrop that molded human beings, a setting characterized by scarce food, limited information, and few possessions. He contrasts that with the modern era, marked by abundance and comfort, and the ensuing repercussions on our physical and mental well-being. Michael introduces the concept of the “scarcity loop,” a three-part behavior cycle which helps explain modern challenges such as overeating, addiction, gambling, and materialism, and offers practical strategies to break free from its cycle. The episode culminates in a thought-provoking exploration of happiness, drawing on Michael’s experiences with monks and underscoring the value of boredom, exploration, and discomfort as transformative elements that elevate awareness, presence, and the will to live.

\*Try Michael’s **14-Day Tsimane Diet Challenge** at [eastermichael.com](https://eastermichael.com/)

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/michaeleaster2/the_Drive_public.png)

Play

#284 ‒ Overcoming addictive behaviors, elevating wellbeing, thriving in an era of excess, and the scarcity loop | Michael Easter, M.A.

#284 ‒ Overcoming addictive behaviors, elevating wellbeing, thriving in an era of excess, and the scarcity loop | Michael Easter, M.A.

1x15s30s

0:001:57:21

## We discuss:

- Inspiration for Michael’s latest book, Scarcity Brain [2:15];
- Evolutionary adaptations to the scarcity of food contrasted with the modern obesity crisis [4:00];
- Lessons learned about diet and nutrition from living with hunter-gatherers [9:30];
- The impact of ultra-processed foods on energy balance [20:30];
- Michael’s experience with attempting the hunter-gatherer diet at home [27:30];
- The roots of excess: factors that contribute to overeating and the varied vulnerabilities among individuals [34:00];
- The scarcity loop: how the components of the scarcity loop are illustrated in gambling and addiction [39:45];
- Using knowledge of the scarcity loop to break the cycle [50:45];
- The evolutionary drive to acquire material possessions [58:15];
- The benefits of boredom and value of exploration [1:07:00];
- The consequences of an attention economy driven by negativity bias [1:16:30];
- Navigating the world of endless information and the value in “slow information” [1:23:00];
- Defining happiness, and the downward trend in reports of happiness [1:33:00];
- Purpose, austerity, self-reliance and other missing elements of happiness gleaned from the study of monks [1:38:30];
- The value in uncomfortable activities that increase your awareness, presence, and will to live [1:48:45]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Michael Easter is a returning guest, last appearing on [episode #225](https://peterattiamd.com/michaeleaster/) in October 2022
- Michael is a professor in the journalism department at the University of Nevada at Las Vegas and a co-founder and co-director of a think tank at UNLV called the [Public Communications Initiative](https://www.unlv.edu/urbanaffairs/pci)
- He is also the author of the best-seller [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767)
  - This is one of the few books Peter is always giving away to people
- In this episode we speak about Michael’s latest book, [*Scarcity Brain*](https://www.amazon.com/Scarcity-Brain-Craving-Mindset-Rewire/dp/0593236629/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1700500971&sr=8-1)
  - This is also an exceptional book
  - Peter puts it right up there with *The Comfort Crisis* in terms of its implications for how we can live better lives
- Throughout this conversation we discuss what the scarcity loop is and how it affects our way of life in many ways
  - This includes look at it through the lens of food, gambling, drugs, our need to accumulate more and more possessions
  - The stimulation we receive from our phone
  - Boredom
  - The influx of information we have in our lives
- Finally, we look at happiness

## Inspiration for Michael’s latest book, Scarcity Brain [2:15]

- Last time we were here, we were talking about [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767), which is a book people have heard Peter talk about over and over again
  - It’s on the short list of books he recommends regularly
- Peter wants to understand how Michael went from the lessons he learned in *The Comfort Crisis* to thinking about the particular problem that feeds into [*Scarcity Brain*](https://www.amazon.com/Scarcity-Brain-Craving-Mindset-Rewire/dp/0593236629/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1700500971&sr=8-1)
- Michael finished *The Comfort Crisis* right as the pandemic was taking off (March 2020)
- Now when the pandemic takes off, *what does everyone do?*
  - They go to the grocery store and they hoard as much stuff as they can
  - This is a rational decision at that point, but it made him realize when we think that resources are scarce, our reaction is to hoard them and gather them
- What was interesting about the pandemic is you had this initial spike in that sort of behavior
- But then as it drew out, you saw everything from drinking and drug use increase
- You saw purchasing increase
- You saw a lot of people gain weight from eating food and exercising less

***You saw all these behaviors that can be damaging just increase over time, and so that made Michael wonder about questions of scarcity, how it affects us, how our environments have changed***

- Because that’s what [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) is ultimately about
- And one of the elements underlying that is that we live in a world where we have an abundance of all these things we’re built to crave, and managing that can be difficult

## Evolutionary adaptations to the scarcity of food contrasted with the modern obesity crisis [4:00]

- There are so many sections in this book, each of which dive into seemingly disparate topics of scarcity
  - Scarcity of information, scarcity of food
- Lets begin with scarcity of food ‒ it’s the one for which there is the most obvious evolutionary link
- There are scholars out there who would argue that the greatest superpower of the *Homo sapiens* are their ability to tell stories
- Peter has always felt that our superpower as *Homo sapiens* was energy storage
- It’s probably the case that there are many superpowers that we have that coalesced around where we are today and how we leapfrog ahead of every other species about 250,000 years ago

**What we know about scarcity with respect to nutrition and how that evolved us as a species**

- Until very recently, food was scarce and it was hard to find
- Prehistorically, there wasn’t a lot of food
  - Not to mention, in order to get it, you weren’t going down to the 7-Eleven
  - You would have to hunt, you would have to gather, you’d have to put in energy to get energy
  - It wasn’t always easy to come by
  - It depended on where you lived
- Recently, within the last 100 years, we’ve been able to produce an abundance of food
  - And we’ve engineered our food to be as delicious as possible
  - We have so much food now that in America, we throw out about a third of the food that we produce
- We’ve gone from being these creatures who evolved to eat if you had the opportunity to eat, and maybe a little more than you needed (because food was scarce and hard to find)
  - That would give you a survival advantage because you could store that energy and then the next time that you can’t find food, you’re going to survive that
- We still have that drive to eat a little more than we need, but we live in a world where food is rarely scarce
  - So it’s a evolutionary mismatch

**Peter has talked about the default food environment**

- Earlier they talked about the challenges of their pantries, and what Peter talks to patients about their default food environment
- When you’re changing a habit that requires subtraction, the strategy is **changing the environment**
  - When you’re changing a habit that requires addition, there’s a whole different strategy
- But the default food environment is incredibly palatable, incredibly calorie dense, incredibly non-perishable (and therefore portable), and incredibly cheap
  - If you just think about the dollar per kilojoule, you can’t fathom how remarkable this is
  - And Peter doesn’t believe that any of that is particularly nefarious on the part of industry
    - It’s solving a problem and the solution happened to produce those things that we now have that meet those criteria
    - It’s just that making food healthy was not one of the criteria on the list
    - Make it such that if you consumed it at any level, it would not harm you (that is obviously not one of the criteria)

**What do we know about the most contentious topic of them all, which is what is at the root of the obesity crisis?** [7:15]

- There’s really no debate about the state of our excess nutrition
- Even globally, the state of over-nourishment exceeds that of malnourishment (fourfold)
- 40 some odd percent of Americans are now obese

**We used to spend all of our time getting food and preparing it**

- For example, before we created production lines to make tortillas, Mexican women used to spend five hours a day hand grinding corn to make tortillas
- When we get in food production lines and we start to process our food more, that frees up a lot of time for people
- It makes food more abundant, it makes it easier to come by, it makes it cheaper

> “*The average American spends about 8% of their income on food. In the past, we used to spend more than 40%*.”‒ Michael Easter

***This is a good problem to have, but we now have so much food that it does become hard to manage***

- As Peter has talked about plenty on this podcast, obesity is linked to so many of the diseases now that end up cutting our lives short
  - Not only that, they cut into our health span
- They make us immobile and that that leads to some downstream consequences like depression, anxiety and so it becomes pernicious over time

***One of the issues is that food will always be rewarding in the short term, it’s a hard battle to fight***

- Michael has a lot of empathy for people who are obese
  - It’s very challenging because we do live in a food environment where you can make that decision for that thing that’s going to be delicious, feel good in the short term, but too much of it can cause some long-term problems

## Lessons learned about diet and nutrition from living with hunter-gatherers [9:30]

**When Michael wanted to look into this question, he decided to go and live with some hunter-gatherers**

- The [Tsimané](https://en.wikipedia.org/wiki/Tsiman%C3%A9) in Bolivia

*How did you select them over others that could have been easier to reach, such as the* [*Hadza*](https://en.wikipedia.org/wiki/Hadza_people)*?*

- Michael came across this [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6028773/) which reported that this tribe does not get heart disease
- When you look at what kills the average person, what’s the #1 killer of Americans (and worldwide), it’s heart disease
- When you look at what people worry about health-wise, it’s not heart disease
  - People worry about cancer
  - People worry about terrorism and violence
    - You’ll have people who stock tons and tons of guns and bullets because they don’t want to get killed, and yet they’ve also got a pantry full of junk food
- Michael’s background is in investigative journalism, so he talked to two researchers on the paper and decided to go down and see it for himself
- He flew to La Paz and took at 12-hour car ride to a town called Oruronabake in Bolivia
- From there he got in a canoe called a Peke Peke boat
  - They’re these long boats (30 feet), really thin, and they’ve got these motors on them called Long Tail Motor
  - They took that about six hours up a feeder river of the Amazon
    - All you can see is jungle the entire time, it’s all green, it all looks the same and then the boat driver just essentially pulls over and tells them to get out
    - The tribe was there

**The Tsimané are not true hunter-gatherers, they’re hunter-horticulturalists**

- What was interesting with them is that some point in a given day, they’re going to offend some fad diet
  - They eat meat, they eat plain white rice, their diet isn’t necessarily low-fat, it’s not necessarily low-carb
  - They’re eating things like corn, that’s off limits in so many diet books
- But the commonality behind their food is that it all has one ingredient: they’re basically not getting access to **ultra-processed food**
  - And that seems to be one of the key reasons they’ve been able to avoid disease

**Tell me about the population, how large is it?**

- There might be 4,000 to 20,000 spread throughout the Bolivian Amazon
- But the group that Michael saw was about 50, in a small village

**And what does the distribution of their lifespan look like? What is the median survival?**

- Peter adds, “*I imagine there’s a skew down on the median, based on no access to antibiotics and the things that we take for granted here, where what I call medicine 2.0 has done a remarkable job of extending human lifespan*.”
- Michaels guide from another tribe said they die of accidents
  - There’s snakes out there that if you get bit, you’re screwed
  - They live into their 70s on average if they managed to sidestep a snake or some other accident

**Explain how the claim that they don’t have coronary artery disease has been validated**

- Researchers got a bunch of the tribe members and they took them into the village to do CT scans of their heart
  - They basically didn’t have a lot of the markers that they look for in that scan
  - [The [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6028773/) reported coronary artery calcium scores]
- Michael’s takeaway was that their hearts looked about 30 years younger
- They don’t seem to get what Peter refers to as the “four horseman”
  - They’re going to die from other problems
- Peter thinks there’s a lot of things that are different for them
  - They’re probably not under chronic stress
  - They’re probably quite active
  - They probably have a really good circadian rhythm and sleep well
  - They don’t have electronics
  - And obviously they eat a very different diet

**How much does Michael think the diet specifically played a role in this?**

- Peter points out that we can’t answer that question prospectively
- Michael thinks it plays a pretty large factor, but it’s not everything
- There’s another tribe called the Mozatan that Michael spent some time with
  - They were an hour away from the Tsimané village
- The Mozatan will go into town and get ultra-processed food
  - Things like oil to fry their plantains
- According to the scientists Michael talked to, the Mozatany seem to have an elevated risk of heart disease
- In contrast, the Tsimané bake their plantains in a fire
  - They’re just not doing all these things that make the food a lot more appealing and in turn lead them to overeat

**What the Tsimané eat in an average day**

- For breakfast, it’s probably something like white rice, maybe some plantains with some protein
  - The protein could be fish, it could be chicken, it could be an Amazonian deer called a taper that they hunt (a red meat)
- For lunch, it’s very similar: a pile of white rice, maybe some fish, a little bit of vegetables
- One thing that was interesting too is that they’re not eating a ton of vegetables
  - If you and I go to Sweetgreen’s salad chain or whatever, that single salad that we would get there is probably the amount of vegetables they’re eating across a day
    - The way we think of vegetables, greens, cabbage, things like that
- For dinner, it’s the same deal: more carbs, it’s sweet potatoes, it’s maybe some meat, fish

***It’s just very simple foods repeated over and over and over, and that’s what it was probably like for humans most of the time***

**Contrasting the diet of hunter-gatherers and Americans:**

*One of the fascinating things about today is that we have more options for food to eat than ever before*

- Think of your average grocery store: it’s got 10,000 things that you can choose from
  - And that is very new in the grand scheme of time and space
- Michael thinks we haven’t necessarily learned to navigate that well
- We know that the more options people have to eat, the more things they can eat, the more that person will eat
  - This is called the “buffet effect”

**The real raging debate within the obesity community**

- Many interesting theories are put forth and it might be that no one theory is wholly complete
- 1 – One theory is food availability
  - It’s simply the quantity of food that is available
  - There are certainly examples of where that seems to work, but then there are other counter examples where you can find in places of either high or low food availability, and you get the opposite to what you would expect based on the theory
- 2 – Palatability, food today is hyper palatable
- 3 – Carbs
- 4 – Fats

**Where do you think pleasure from eating fits into this landscape?**

- We all take for granted the idea that eating is often very pleasurable because we have choice
  - If your at a restaurant, presumably you’re going to order something you enjoy eating

*Do you get the sense that the Tsimané enjoy eating?*

- As someone coming from Las Vegas (where buffets are everywhere), their food was not enjoyable
  - It’s very plain
  - They’re not salting it
  - You’re eating plantains and fish that have been baked in a fire, and it is what it is
  - Same with the chicken
- Their chickens are much different than ours
  - Ours are bred to be giant; they could never live in the wild
  - Their chickens are wild and weight about three pounds
    - There’s not much meat on them, and the meat is very tough
    - It was not enjoyable compared to our chicken

***You eat it because you need to***

- But at the same time, they don’t have access to Las Vegas buffets, so for them it’s pretty good

**How long did it take (if at all) for your taste buds to down-regulate and for you to actually taste the sweetness in the plantains and sweet potatoes?**

*Did you go through a re-sensitization as you stayed with them?*

- You start to enjoy it more, and it could just be that you’re hungry now
- You’ve come from the city where you’ve had all this great food and now you’re shoveled into this world and your reaction to the first meal is, “*Okay, I’m just going to have a little bit of this because it doesn’t taste good.*”
- You do that for a few days, and then all of a sudden you go, “*Okay, well I’m actually hungry now. I’ve got to eat.*”

> “*I do feel like hunger is the best sauce. If you’re hungry, a lot can taste good. If you’re deprived of something and then you get it, it becomes more enjoyable.*”‒ Michael Easter

## The impact of ultra-processed foods on energy balance [20:30]

- In the US, in the developed world, we’re thinking about our weight and playing this game of , “*How much should I eat?*”
- There are all these great models like:
  - Always get up from the table when you’re still a little bit hungry
  - Count your calories
  - Limit you carbs
  - Limit your fat
- We always have heuristics that we try to use to regulate caloric balance

**Do the Tsimané do any such thing or do they literally eat as much as they want of these bland foods, but their “off-switch” just comes so much sooner because presumably nothing in their brain is being hijacked?**

- There was an interesting [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7946062/) from [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) at the NIH and they basically took a group of people and for two weeks they fed them a diet that was ultra-processed food
- Peter loves this study, and Kevin was a real skeptic going into this study

**Background on this study by Kevin Hall**

- A group from Brazil had basically come out and said that one of the reasons for the obesity crisis is that food is ultra-processed
  - The nature of the ultra-processing itself is leading people to eat more
- Kevin called them up and asked them what evidence they had and why they though this
- Peter knows Kevin very well and explains that he is an empiricist whose view to the best of his knowledge is based on his data
  - He generally has access to the most controlled studies because he runs a metabolic ward
  - His takeaway‒ it’s the energy content of the food that is driving weight gain, and it is independent of the quality of the food
    - So 1000 calories of broccoli is as fattening as 1000 calories of potato chips
- The group from Brazil said, “*Well, ultra-processed food has more sugar, it’s got more salt.*”
- Kevin decided to study this because he’s a skeptic
- Kevin’s [studied](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7946062/) a group of people: for the first two weeks, they ate an **ultra-processed diet**, and for the next two weeks, they ate a diet that is matched for everything, carbs, salt, all that for the other two weeks, but the food is **minimally processed**
- For example, on one night of the ultra-processed diet, you might be getting the Swanson Meatloaf with the mashed potatoes that have the butter and all that kind of stuff
  - On the unprocessed night, that version might be a cut of beef and some plain potatoes
- It was an ad-lib feed study: the participant eats as much of the food as they want

***What he finds is that when people are on the ultra-processed diet, they end up eating about 500 more calories a day and they start to gain weight***

- When they’re on the minimally processed diet, they eat less and they start to spontaneously lose weight

**Michael thinks one of the reasons for this is that speed becomes a factor**

- When you process a food to the extent that it becomes an ultra-processed food (junk food), it becomes a lot faster to eat and you simply end up eating more of it and there’s more triggers to continue eating more of it because it is so hyper-palatable and enjoyable
- Obviously there’s a lot of potential reasons
- Michael talked to a guy in the food industry and he explained the **three V’s of snacking**, if you want a snack food to sell
  - 1 – Value: it’s got to be relatively affordable
  - 2 – Variety: there’s got to be a variety of flavors, and flavors have to be intense
    - Don’t just make one original Pringles, make 20 Pringles
  - 3 – Velocity: it has to be fast to eat
- Snacking was not a cultural thing until about 1970
- This is a concerted movement by the food industry to sell more food
- Michael thinks you start to see the rise in obesity in our country (and then it trickled out across the world) in 1970

**There’s a lesson in that**

- If you’re trying to eat less, *how can you do that?*
- The lesson from the Tsimané suggests that people don’t overeat when foods are minimally processed
  - Foods that are ingredients rather than have ingredients
  - It’s a lot slower to eat foods that are unprocessed
- Back to the example of 1000 calories of brownie versus 1000 calories of broccoli
  - They may make you equally fat, but Michael would love to see a person try to eat 1000 calories of broccoli
    - It’s never going to happen
    - It takes up so much volume in your stomach
    - It’s slow to eat
  - It’s relatively easy to eat 1000 calories of brownies; it’s enjoyable
- Peter gets asked this all the time about the carnivore diet and people say, “*What do you think of this? Does this really work?*”
  - As someone who’s never done it, but who thinks about this problem a lot, it doesn’t surprise him that if a person were limited to rib eyes (despite how calorie-dense it is), they would lose weight
  - If you’re sticking to one food, you would wither away, regardless of what it is…

## Michael’s experience with attempting the hunter-gatherer diet at home [27:30]

- Michael learned what the Tsimané tribe was eating and went back to Las Vegas and decided to try it for a month
- Literally every food he eats has just one ingredient
- He mimicked their diet as closely as he could

**How many foods in your pantry and refrigerator already fit that description?**

- Probably 8 foods in a pantry that has 200 items
- He has some apples
- He as some plain rice
- Things that people would normally consider healthy like whole wheat bread, it has a long list of ingredients
- He ends up going to Costco to try and solve for this problem

> “*There’s literally entire aisles that are just off limits*.”‒ Michael Easter

**You’re left with a very basic diet every single day**

- In the morning, he might eat something like oatmeal
  - He might eat some eggs with that
- At lunch, he might air fry some plantains and have some fish
- At dinner, he would have maybe a sweet potato with some green beans and some elk (luckily both Michael and Peter hunt)

***It was not as exciting as his normal diet, but at the same time, he started dumping weight pretty fast***

- Michael didn’t necessarily want to lose weight; he weighed about 180 lbs

**He realized if he wanted to stay at 175 lbs, he was going to have to up his caloric intake**

- Michael explains, “*Gosh, it became so much food*.”
- He was force-feeding himself
- He did some rough math of calories ‒ it became a mountain of plantains
- It became tough to eat all that food

**Did you restrict yourself in any other way? Did you not snack deliberately or were you just never hungry between meals?**

- If he wanted a snack, he would usually have a piece of fruit
- The jungle out there is filled with fruit
  - That was the one food they had that was good
- Peter responds, “*That doesn’t sound like an impossible to follow diet if you have control of your food environment. Where I think a diet like that becomes challenging is the moment you venture out of your own preparation bubble.*”

**How did you navigate situations when you went to someone’s house for dinner or out to a restaurant?**

- That was absolutely challenging
- The reality is he couldn’t be perfect then
  - He wasn’t going to be the guy to say, “*Okay. Well, I got this food list from this tribe in the Amazon, please just fry me up some plantains. Air fry though, only air fry.*”

**Do you have a sense of what your macros broke down into?**

- Heavier on the carbs, more than 50%, and up to 70% some days

*What else did you have for protein besides fish?*

- Elk

*Would you season the elk?*

- He would put some salt on it
- It makes it easier to eat, and if something’s easier to eat, you’re going to eat more of it
- Michael thinks that sometimes we discount how much protein comes from grains, depending on what the grain is
  - A giant bowl of oatmeal in the morning might have 18-20 g
- He would sometimes put berries on the oatmeal

**Doesn’t that violate the rule?**

- Yea, no
- They were all single ingredients
- Peter wants to try this diet

**Michael followed-up with** [**Trevor Kashey**](https://www.instagram.com/drkashey/?hl=en)**, a biochemist who’s into nutrition**

- He wrote about Trevor in *The Comfort Crisis*
- He told Trevor what was happening, and he said basically a lot of good things can happen
- Even if you have a very low level allergy to a food that you’re not aware of, by cutting out a lot of the foods Michael did, it could be that maybe he was to some extent allergic to a food that he wasn’t aware of
  - And that helped him lose weight
  - Or might’ve made him end up feeling better

**Would Michael tell anyone to eat that way for the rest of their life?**

- No

***But he thinks it’s something worth trying so you can learn what foods work for you***

- He tends to feel more full on fewer calories when he’s eating foods like this
- From there, you can make a general plan of what to eat 80-90% of the time
- We do live in an amazing world where you can have that 1000 calories of brownies, and if Michael brings 1000 calories of brownies to the Tsimané, they’re going to be like, “*Oh my God, this is amazing.*”
  - They’re going to eat it

**Michael is not saying we should never eat ultra-processed food, the question is, how do we manage that?**

- We live in a world that’s incredible where we can have brownies and 15 different flavors of Doritos, but if we’re eating those foods too often, we’re going to have issues
- Research suggests that 60-70% of the American diet is ultra-processed

***Thinking of a diet of ultra-processed foods along with snacking and it starts to make sense why you see the scales start to get higher over time***

## The roots of excess: factors that contribute to overeating and the varied vulnerabilities among individuals [34:00]

**Do you have a sense of why some people are more or less immune to those effects?**

- Some people who, even when presented with ultra processed food, don’t eat to excess
- Yet there are others, and Peter would put himself far on this scale, where the only way he’s not going to eat to excess in the setting of hyper-palatable, hyper-processed food is enormous self-discipline
  - Peter has to use hacks and tricks to get around it, whereas he knows people who can sit in front of a plate of freshly made cookies and eat one, while the entire plate sits there in front of them for the next hour
- Michael doesn’t think there is a perfect answer

**Sometimes food can be used for things other than nutrition, for example, stress relief, dealing with emotions**

- Especially today, people eat for emotional reasons
- A study that Michael had in *The Comfort Crisis* suggested that 80% of eating today is driven by reasons other than true hunger
- There’s a lot of things it could be:
  - It’s a certain time of day
  - Food is around so you just eat it
  - Stress eating
    - Stress eating is a thing that works; eating food will solve your stress in the short-term

**Where do you think that comes from?**

- Peter could walk into a casino, and it wouldn’t even occur to him to play a slot machine
  - We’ll come back to talk about gambling
- Yet, there are some addictions (such as food) that Peter will struggle with indefinitely
- There are some people who drugs, whether it be that first time they take a painkiller, it puts a hook into them that is very difficult for them to escape
- Alcohol is the same thing, it never occurs to Peter to get drunk
  - Alcohol scratched an itch for some that it’s never scratched for him, and he feels very grateful for that

***In other words, Peter doesn’t think there’s a moral difference between us, he think there’s a biochemical difference***

**Do you have a sense of why each of us have different vulnerabilities when it comes to the scarcity loop?**

- Michael doesn’t think there’s a specific answer
- Why does Peter like F1 and Michael like basketball? Who knows?

***Probably exposure during vulnerable periods sets the table***

- Here’s a good example from addiction research: if a person drinks at 15 or younger, they have a coin flips chance of becoming an alcoholic
  - If they drink after age 21, they have a 10% chance
- Why is that? It’s because your brain is developing in such a way from puberty till you’re about 25, where you’re trying to figure out:
  - How do I find comfort?
  - How do I navigate the world?
  - How do I deal with stress?
  - How do I deal with my problems?
- And if that gets set in, with alcohol (for example) in at that age, and you go, “*Oh, this is what works for me.*”
  - Maybe at a young age food helped you deal with your problems
  - For Michael, the first time he drank (at age 15) he was like, “*Wow, the world is way better after this.*”
    - It was a very deep learning experience

**Peter remembers his first time drinking**

- He was 13, he worked at his dad’s restaurant
- It was New Year’s Eve, he was a busboy, and at the end of the night, he went around and drank all of the remaining drinks on the table of everything that was there
  - This was back when you could even have a can of beer
  - He was pouring it out, and cigarette buts are coming out, and he’s drinking the beer
- He got so drunk that no only did he vomit throughout the night, he was drunk the next day

*Is it just the case where that was such an unpleasant experience, versus your experience?*

- On a side note, [Matthew Perry](https://en.wikipedia.org/wiki/Matthew_Perry) died, and Peter remembers reading an article about him where he talked about the first time he drank
  - He drank a bottle of wine, laid in a field and was like, “*This is the greatest feeling in the world.*”

***Peter proposes that maybe it comes down to not just age of exposure, but the reward that comes from that exposure; and maybe if there’s no reward, but there’s a punishment physiologically, it could have the opposite effect***

- Michael agrees: for Peter it was like putting your hand on the stove (he was never going to do that again), but for Michael, it was like he flipped on the stove and the best meal of his life appeared
  - It’s very much a **learned behavior**

> “*That’s how humans learn, that’s why we do what we do, ‘cause we get rewarded for it*.”‒ Michael Easter

- Michael thinks this gets set-in at a young age
- Going back to that study, by the time you’re 21, you’ve figured out these other ways to navigate the world and what you get rewards from
  - By the time you’re 21, you’ve figured out other self-soothing tools

## The scarcity loop: how the components of the scarcity loop are illustrated in gambling and addiction [39:45]

- Michael wrote about the three components of the scarcity loop and how they get exploited in our lives everywhere we go

**What are the components of the scarcity loop and how do they feed off each other?**

- For context, the reason Michael started thinking about this is that he lives in Las Vegas
- Peter talked about his experience with slot machines, and he doesn’t say that with any judgment of moral superiority
  - He truly believes there is a biological difference between himself and that person in Vegas who could throw their life away
- Michael made the observation that slot machines are all over Las Vegas, and people play all the time
  - They’re in the grocery stores, they’re in the gas stations, they’re in the restaurants, the bars, they’re in the airport
- When he goes to the gas station he’ll see people in there at 7:00 AM playing the slot machine
- And he wonders, “*Why would anyone do that? It doesn’t make any sense, ‘cause everyone knows the house always wins.*”
- When the house wins in blackjack and poker, it’s only slightly, it’s 51/49
- The odds are not far off of those for slot machines
  - In the past, slot machines used to be called one-armed bandits
  - Now, slot machines return about 85 cents for $1 you spend, on average
    - Which is smart for reasons that Michael is going to explain

**Michael started wondering how does a slot machine work**

- How can this thing get people to be down at the 7/11 and sit for hours and hours, and play this thing where you’re going to lose
  - Play it long enough, you’re going to lose, that’s just how it works
- He goes into journalist mode, and what was fascinating is, the first people that he calls are people who are gambling researchers, but they have a very anti-gambling bent
  - They’re looking at all the reasons why gambling hurts us, why people get hooked on slot machines
  - These people tell him all sorts of things that are like the myths you hear about casinos
    - Such as, slot machines only play in the key of C, and that is very pleasing to people, it relaxes them and in turn their wallets
    - Casino’s don’t use right angles, because right angles activate the decision-making part of your brain, and that’ll slow down your rate of gambling
    - Casinos don’t have clocks, so you lose track of time
    - Casinos don’t  have clocks, but neither does Costco, Walmart, or any normal business
- Michael calls up a slot machine audio composer who lives in Vegas, and he explains, “*I use all keys. I’m just trying to make the best little jingle that I can, I’m just trying to have fun*.”

***Michael realized that his inherent problem is that he’s talking to people who want us all to stop gambling, and he needs to talk to the people who want us to start gambling; he’s got to follow the money on this thing***

- Long story short, through some different contacts, he ends up at this place on the edge of town in Vegas, and it’s this new cutting-edge casino
  - But it is not fully open to the public like a normal casino would be
  - It’s a casino laboratory, so it’s used entirely for research on human behavior
  - And the people invested in this are the big gambling companies (Boyd, Caesars, whatever), but also a lot of tech companies
    - There’s 73 different companies that are invested in this place, and it is very much like a twilight zone of casinos
- There’s a lot of people with PhDs doing studies, and Michael ends up talking to a guy who designed slot machines, and he explains how a slot machine works
- Michael talked to other people who talk about it in different ways, and this is what he calls the “scarcity loop”

**A slot machine works on this three-part system that Michael calls the “scarcity loop”**

- 1 – Part one, the first condition, is opportunity
  - You have an opportunity to get something of value, and in the case of a slot machine, it’s money
- 2 – Part two is unpredictable rewards
  - You know you’re going to get the thing of value at some point, but you don’t know when and you don’t know how valuable it’s going to be
  - With the slot machine, once you play a game and those reels are rolling, they could all land and you get nothing, they could land and you win, $2 on your $1 bet, or you could win $20,000 on your $1 bet
  - There’s a crazy range of outcomes every single game
- 3 – Part three, is quick repeatability (this is important)
  - Once those reels land, you can immediately repeat the behavior, you can play again
  - The average slot machine player plays 16 games a minute
    - Which is more than we blink

***The reason this is important is that this system can get people to do a lot of other behaviors that are seemingly irrational too***

- It’s what makes a lot of different systems like **social media** work
  - You post something, you got an opportunity to get some likes (some status)
  - So you check and recheck, ‘cause you don’t know when those likes are coming in
    - You don’t know if your post is going to go viral, you might get canceled, you might get a message from someone that you think is great, on and on and on
- It’s in dating apps, it’s in different financial apps
- One of the reasons that [Robinhood](https://www.robinhood.com/us/en/) really took off is because they increased the quick repeatability by removing fees for trades
- It’s in online shopping
  - A lot of advertisers are using casino like features in their ads to drive profits, and that’s led to a sevenfold increase in conversion rates when they put a spinning wheel for a discount

***Michael thinks when you start to look at the behaviors that people have a hard time moderating, a lot of them rely on this system***

**How can one use that information to break the cycle**

*You chose an interesting place to go to investigate drug use*

- The reason Michael went into Baghdad is because you had nothing and now you have something
- And it really stands for what he thinks the conditions are that you need for an addiction epidemic to rise

*To give some context*

- For most of the time, Iraq didn’t have a drug problem
  - A lot of that was for political reasons, Saddam ruled with an iron fist around that
- Then, the US invades, and it destabilizes the country, so you have a big population that has lived through a war
- Soon after, Syria falls, Syria effectively becomes a narco state and they start producing a drug that is called [Captagon](https://en.wikipedia.org/wiki/Fenethylline), and it’s analogous to methamphetamine
  - They start sending this drug all throughout the Middle East
- You’ve got three things
- 1 – You have a population who is in a lot of pain
- 2 – You have few ways to deal with that pain that are more productive, not a lot of options
- 3 – You have a substance that solves that pain, that problem, in the short-term, immediately
- Michael thinks that leads to that rise in addiction, and you see it here in the US as well

**Why did the opioid epidemic start in states where the factories had moved out?**

- When factories move out, our lives change, we don’t have a lot of resources, things have gotten really dark, and now we have this flood of pills that can take away those problems in the short-term, that can allow us to escape from that life we live
- The reason for going to Iraq instead of a place in the US is simply that this is happening now on the ground, and it is just booming, and it is a new substance

**What are the two models for drug addiction?**

- 1 – It’s a moral failing, i.e. the drug user/ addict is a bad person
  - They’re making this very specific choice to just mess over other people and putting themselves ahead of everyone else
  - An extension of that is they simply don’t have the self-management, self discipline
    - Even if they’re not deliberately doing this to sabotage their life, they’re so lacking in moral character that they can’t manage themselves
- 2 – Brain disease model
  - Effectively, drugs change your brain in such a way that removes your capacity to make any decisions around the behavior, and that drug addiction is a chronic and relapsing disease

**The counter to both of those models**

*What do we know about Vietnam vet’s use of heroin when they were in Vietnam, versus when they returned?*

- About 20-25% of US soldiers who were in Vietnam were addicted to heroin, regular frequent users of heroin
- President Nixon, he decides he doesn’t want to let all these heroin addicts back into the United States, so he started a program that is called [Operation Golden Flow](https://en.wikipedia.org/wiki/Operation_Golden_Flow)
  - The deal is this, if you want to come back into the United States as a soldier who’s been in Vietnam, you have to produce a clean urine test
  - If you do not produce a clean urine test, you will be left in Vietnam

***If addiction basically obliterates the capacity to make any choices, any decisions, you would expect that 25% of soldiers in Vietnam would be left in Vietnam***

- What actually happened is that nearly every single one provided clean urine, and when they got back into the United States, the vast majority of them (95%) managed to stay clean
- The 5% that relapsed, they tended to be people who had used drugs before the war

***This suggests that people aren’t necessarily a slave to chemicals, that maybe it’s a little bit more nuanced than it being purely a brain disease where choice is completely obliterated***

## Using knowledge of the scarcity loop to break the cycle [50:45]

**How can we extrapolate from that to where we are today?**

- We’re sitting in the midst of an unbelievable epidemic
- Peter’s even done a podcast on this [[episode #243](https://peterattiamd.com/anthonyhipolito/)], and it’s a little outside of his area of expertise, and he has argued that it does impact longevity, because mortality rates for the US population are actually in a small state of decline
  - Being driven almost exclusively by the death of people aged roughly 25-55, where we’ve seen the deaths of despair increase at a rate we’ve never seen before
- The biggest of the three deaths of despair, so we count accidental overdose, that includes:
  - Poisoning, so fentanyl in a drug that you don’t think has fentanyl
  - Alcohol related deaths
  - And suicides
- Those three are collectively expanding, but the greatest of the three by far is the **non-suicide overdose**
- It’s no longer just in the old steel mill town, which Peter thinks probably explained the thin edge of the wedge in the late ‘90s and early 2000s
- Here we are, 25 years later, and this is an epidemic in any and every city, including Peter’s city of Austin

**What do you think explains that?**

- If you’re looking at it purely from a death statistics perspective, that goes back to fentanyl
  - That fentanyl is being put in drugs that are all over the country now, and people aren’t necessarily aware that they’re getting a drug
- Michael thinks we also have to back up and ask, why do people use drugs?
- Why would people use a drug knowing that there’s a risk that there’s fentanyl in something that they weren’t expecting fentanyl to be in?
- When you look at drugs from a historical perspective, humans have always used psychoactive substances as tools to accomplish something
  - If you think about chewing coca leaf in South America, the coca leaf was used to enhance focus on long hunts, to kill hunger on long hunts when you couldn’t find food
    - The same with tobacco
- You tend to see that substances have always been used as a tool to accomplish something, because they benefited the person’s life somehow

***Now, what has changed between today and 100,000 years ago is that we’ve taken our substances and we have distilled them into something where the psychoactive component is so strong and pure that it really can become almost an obliterant in a way; and over time, the availability has risen as well***

- When you think about something like fentanyl being placed into things, Michael thinks there’s a lot of people who can use drugs and be okay
  - Would he recommend that? No
  - But can people use drugs recreationally?
    - He thinks there are plenty of people who can and do
    - The work of [Carl Hart](https://psychology.columbia.edu/content/carl-hart), for example, gets into this a lot

***What happens when you start getting fentanyl in drugs that people who are using it recreationally get, you start to see people who die***

- Recently in New York City, there was a bad batch of cocaine that had fentanyl in it, and you had five people die in Manhattan in a single night
  - These are not people living on the street
  - These are people who have an apartment in Midtown
  - These are white collar people who use cocaine recreationally
- Michael thinks this accounts for the rise in overdose deaths

**You’re not necessarily thinking that we’re seeing an increase in the epidemic of catastrophic drug use, or drug use that is commensurate with no function in life outside of drug use?**

- We might be, because the substances today are strong enough that they can have more extreme consequences
- But what Michael is talking about is deaths being spread around the country today; he thinks fentanyl in drugs people use recreationally is the cause of death
  - Deaths of despair may be overcounting because some of those people dying might not be addicted to drugs

**The pushback to that would be, should anybody really be using cocaine?**

*What does it say about us if we need to be using cocaine?*

- Going back to the example Michael mentioned earlier, we clearly evolved to enjoy the rush of norepinephrine, but the coca leaf never produced the concentrated high

**In many ways, the drugs of today are the equivalent of a bag of peanut M&Ms**

- They’re simply so concentrated in bliss that there’s nothing that compared to it
  - It’s not that you couldn’t eat a peanut before, or even have some cacao, but nobody imagined the crunchy shell with the sugar and the chocolate and the this and that and the other thing
- That’s sort of what the cocaine and the heroin are to their predecessor
- That same logic though also applies for alcohol, which we culturally accept
- In the past, our proclivity as humans for alcohol is probably because alcohol used to help us find food
  - When you think about we’re searching the land for fruit, fruit would fall from trees, it would ripen on the ground, it would begin to ferment, and it would put off this funky smell from the alcohol that would help us find the food
  - When we actually got the fruit, that low level of alcohol in the fruit would help us eat more of it, it’s the [aperitif effect](https://en.wikipedia.org/wiki/Ap%C3%A9ritif_and_digestif)

*Currently, how many bottles of liquor have the same amount of alcohol that fermented fruit would have?*

- Pretty much zero
- Bourbon is 120 proof or whatever

> “*I think that the more that you scale up and concentrate the psychoactive substances, I think probably the more problems you can get into.*”‒ Michael Easter

- There’s this debate: if alcohol is okay, should the government regulate cocaine?
  - And that way, we don’t have to worry about fentanyl being in it
  - That’s an entire can of worms that’s probably best left for policymakers

**What does the use of** [**methadone**](https://www.samhsa.gov/medications-substance-use-disorders/medications-counseling-related-conditions/methadone) **tell us about how to at least address one of the issues in the scarcity loop if you’re trying to help a person who’s opioid addicted?**

- One of the things that makes drugs so compelling and attractive to people is the element of the scarcity loop of **unpredictability**
- When you think about getting and using any street drug, there’s a lot of unpredictable elements in that
  - Are you going to be able to find the drug?
  - Are you going to get in trouble as you try and find the drug?
  - Once you get the drug, how strong is it going to be?
  - Is it going to be really good?
  - Is it going to be really bad?
  - Then, you use it, and a lot could happen from there
- With [methadone](https://en.wikipedia.org/wiki/Methadone), you find that once you make the drug predictable in the sense that the environment becomes predictable, the timing of when you get it becomes predictable, the dose becomes predictable, you start to see people be able to wane off of drugs
  - In fact, people who use methadone often won’t get high from the drug
- You see this in a lot of pharmaceuticals as well

***The addiction rate for prescribed drugs that are controlled, where the dose and the timing is controlled, the addiction rates for those are way lower, simply because there’s no unpredictability, there’s no game behind it***

## The evolutionary drive to acquire material possessions [58:15]

- You mentioned how during the pandemic, many of us increased our e-shopping
- It seems in all addictions, there’s an adaptive component
- At the beginning of the pandemic (March and April of 2020) there was a pretty good reason not to go out
  - We had no idea what we were dealing with
- The fact that Amazon could deliver things to your door, that you used to go out for, made complete and total sense

**Why is it that I probably still buy as much on Amazon now as I did then if not more?**

- There are evolutionary reasons for having more items
- If you could get more tools as a person, that probably gave you a survival advantage
- Having more items was probably a better idea than having less, especially when you’re trying to survive
- We still have this drive to accumulate stuff, but the difference, of course, is that now we live in a world where we manufacture so much stuff and it’s cheaper than ever before
- Even just a couple hundred years ago, the average person, for example, owned about three outfits
- Now, the average person owns 104 outfits and they also only wear 10% of the clothes that they own
- The stats are something like 20% of the stuff in our closets, we don’t wear it all
  - Another stat (Michael is going to get the math here wrong) is we think about 40% or something of what we have is okay, we don’t really love it
  - There are a few items that we wear sometimes
  - We’re left with 10% that we actually repeatedly wear all the time
- This tracks with Michael’s experience

***The difference today is that we’ve always had this itch to own things, to possess things, but we can never scratch it that often***

- Because things took time to make and because of that, they were more expensive
  - It was harder to get the resources to make them
- Once the industrial revolution happens, we start cranking out stuff at an amazing rate
- Again, this goes back to the food thing where it’s like, “*Well, this is a good problem to have*.”
- You tend to see people collect and collect and collect items
- Now the average house, according to one estimate, has anywhere from 10,000 to 40,000 items in it
- Peter adds, “*We clearly can see a direct and negative consequence to our wellbeing due to the scarcity loop’s impact on food, which is, for 70% of us, it results in overweight or obesity.*”
  - For that subset of the population, there’s a nearly doubling of risk in other chronic diseases
  - You might not feel the pain immediately, but there is a real and clear threat to your longevity

**What are the downsides of stuff accumulation outside of the extremes?**

- Clearly, there are people who have hoarding diseases and then clearly there are people who could buy so much stuff that it would financially ruin them in the same way a gambler could be ruined
- Peter suspects that most people listening to this are more like him, where they have too much stuff but it doesn’t seem to pose a direct risk to them
  - Yet Peter suspects that there’s something harmful about it
- Michael has seen some interesting research that suggests being around too much clutter impacts your ability to focus
  - It seems to be related to **anxiety**
- He doesn’t think it’s a direct threat like heart diseases

**There are basically four reasons to explain why people buy things**

- 1 – Items are tools, and we use them to accomplish a greater goal
  - This is probably how people would’ve used things for most of time
- 2 – We can use items to get status
  - You’re buying something in order to display something about yourself to others
  - It’s a status play
  - No one buys a Rolex because they want to know what time it is
- 3 – We can use goods to belong
  - You wear your F1 shirt when you go to the F1 race, and it’s like you’re part of this community and it pulls you into the community
  - You see that practically beyond sports: certain types of people wear Patagonia, certain types of people wear the Black Rifle Coffee Company shirt
  - We get these tribes that we can identify with via a thing to buy
- 4 – People are bored
  - This was a powerful one during the pandemic
  - Today we have a much faster, easier opportunity to purchase stuff than we ever have before
    - Even 20 years ago, if a person wanted to buy something, if they’re bored, they had to go out to do it
    - Get in your car, go to the store, and walk the aisles (a time-consuming process)
  - Now, we can do it online, search Amazon
- When you look at how algorithms have evolved, anyone who’s ever spent 10 seconds on Instagram, they know that that machine knows what they want to purchase more than they do themself
  - Peter agrees that usually when Instagram suggests something, it’s good

**Boredom [1:04:45]**

- If you are bored, you might first get bored and you feel that discomfort
- The boredom that Michael talked about on the [podcast](https://peterattiamd.com/michaeleaster/) last time and in [*The Comfort Crisi*s](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767): ***boredom is this evolutionary discomfort that basically just tells us whatever you’re doing with your time right now, the return on your time is worn thin so go do something else***
- Now, in the past, that something else was often **productive**
  - If you think about hunter-gatherers, if no animals are coming through when they’re hunting, they could switch and go fishing, or maybe pick potatoes, or pick berries

***Today, when we feel that discomfort, we have a lot of very easy, effortless, hyper-stimulating escapes from it in the form of cell phones, in the form of TVs***

- Now when you pull out your cell phone and open Instagram, you’re scrolling, you’re still bored
  - You see a T-shirt you love or that exercise contraption, and then it’s like, “*Yeah, I guess I’ll buy it.*”
- You start to see purchases really up when we can repeat the behavior faster

***As a general rule, the faster any animal can repeat the behavior, the more likely they are to repeat the behavior***

- This is something that came up in slot machines in the ‘80s as we alluded to
- Peter has thought a lot about what you just said with respect to boredom from our first discussion and he’s tried to be more cognizant of it, and in particular, how uncomfortable he is when he’s bored
  - There aren’t that many times he gets to be bored
- This idea that just going places without your phone, Peter thinks is a good practice
- There was a day when he did this before, and then you find yourself in the line at the store without a phone
  - It’s really weird
  - It’s five minutes where there’s nothing to do
  - ***You can train yourself to realize that’s an opportunity***
  - It’s a beautiful opportunity to just observe your thoughts, to observe some element of the surrounding
    - It’s why Peter loves rucking: it’s a no phone zone that is great
    - There’s something different about rucking in that you can make it so physically challenging that the lack of music or stimulation is okay

***There’s something about stillness and otherwise boredom that Peter thinks can be challenging***

- To think that if we didn’t have that drive, our species might not have survived
  - That’s a very cool thought

## The benefits of boredom and value of exploration [1:07:00]

**How things change when you adapt to boredom**

- Peter asked Michael earlier if he adapted to the Tsimané food, and he thinks you can adapt to boredom
- For example, in *The Comfort Crisis*, Michael spent all this time in the Arctic
  - The boredom was most intense early on in the trip
- After you’ve removed yourself from the incoming emails, the screens, the million things that you’re normally doing, things start to slow down
- You start to calm down and you start to become more observant
- Probably the most mentally well Michael has ever been in his life was after a couple of weeks up in the Arctic
  - You’re just dialed in
  - You just feel so much calmer
- Michael thinks we live in a world now of hyperspeed
  - Anytime we want to be stimulated, we can do that, and it’s going to be TikTok coming at you fast

***There’s a case for finding time in your life for removal from all that, to lean back into boredom***

**Michael has had issues with a lot of the messaging around how people need to use their cell phone less**

- Yes, this is important
- What tends to happen is when people take an hour off their phone screen time, they go, “*Okay. Well, I’m bored. What do I do now?*”
  - They turn on Netflix and there’s no difference

> “*I advocate for trying to think, ‘How can I infuse boredom back into my life?’*”‒ Michael Easter

- For Michael, that’s go out and take a walk for 20 minutes
  - See what happens to your thoughts, be willing to sit with that, and see where it leads you beyond the screen, because on the screen is what everyone else is getting
- This is particularly great for ideation
  - One of the reasons why people have their best ideas in the shower is because you’re not focused on anything
  - You’re just letting your mind wander, do its thing, and then, bam, that’s the angle, whatever it is

**Kids have more toys than ever**

- Peter and his wife talk about this a lot because he lives vicariously through them when it comes to Lego
  - He just can’t stop buying Lego because he loves building it with them, watching them build it, creating a huge Lego city

*Peter wonders, is there a downside of this?*

- His kids are good kids, and he doesn’t feel like they’re spoiled brats
- But he only had one Lego that he had to take it apart, and put it together (repeat)
- The truth of it is, he sees them getting bored of Lego
- They’re so conditioned that anytime a new one comes out, dad goes and gets it because he can’t wait to see it
- Peter wonders, “*Am I doing them a disservice in the long run? Am I depriving them of a scarcity that I had?*”

**Michael came across an interesting study when writing this book**

- It had groups of people and it had them solve a problem
  - One group was told they had abundant resources to solve it
    - They could do all these different things to solve a problem
  - The other group had scarce resources, and so they had to come up with different uses for tools
- What ended up happening is that the group that was faced with more scarce resources, they not only solved the problem, but they got more rewards from solving the problem by “MacGyvering” it
- Thinking about this, applied to Legos…

**In the book, Michael lays out a good way to think about making a purchase**

***One of the things that he argues for is framing purchases through the lens of gear, not stuff***

- Gear is an item that is allowing me to accomplish something that is life-giving, it’s adding to this experience that adds meaning into my life
- Whereas stuff is often just a purchase to fulfill an impulse
  - I’m buying something because I think it’s going to make me this other person
  - If I buy this shirt, I’m going to look like this, and it’s going to be awesome
    - My life’s going to whatever
- When Michael thinks about Peter’s experience with Legos, that does seem to be adding a real enhancement to your life
  - You’re getting this time with your kids where you’re building Legos
  - At the same time, it might be interesting: now that you’ve got this pile of Legos from all these killer kits, “*What could we make with these guys? We’re not following the plan here anymore*.”
    - What would a castle look like with the resources we have?
    - That would probably lead them to exercise creativity
- Peter and his kids have already learned that when you buy the kit, they love to build the thing, but then they like to keep it and play with it as is, but where they get far more enjoyment is the loose Lego pile
  - You go to Lego store, you can buy loose Lego
  - There’s a store called Bricks & Minifigs, it’s just a free for all
  - They spend 80% of their time building a city that is huge
    - It’s taken up our basement.
    - Every month, we go get more pieces, and they add another floor to the condo
  - They must be getting more enjoyment out of that because it’s where they’re putting more time

**In the book, Michael talks about the value of exploration**

- Humans have a desire for information
- In the past, if you were the person who had more information, if you could crave information and try and get it, try to cure these uncertainties, that would give you a survival advantage
- Now, we’re still wired to crave information
- For example, anytime you get an itch in your side and you’re going, “*Oh my gosh, am I dying?*” You’re going down WebMD
- Twitter wouldn’t work if people weren’t information hoarders
- The difference between how we acquired information in the past and how we acquired it today is that, in the past, you had to go there in the present moment to learn something
  - It was a mind, body, effort to get a piece of information
  - Is there greener grass over there?
    - You have to go to the other side to see if there is greener grass and it’s very up in the air
    - There’s a lot of uncertainties
- But by going through that mind, body, process, outdoors, that real roll of the dice, you get more value from that when you realize, “*Oh, we found this greener grass. This is great.*”
- Today, because we can Google so much, we still have this information itch, but we scratch it online
- Nowadays people’s experiences of their day-to-day life oftentimes get mediated by information from other people
- When was the last time that you just picked a random restaurant?
  - You didn’t read the Yelps from five different people
  - You didn’t look at the menu. You didn’t go
    - By doing that, when you get to that restaurant, your experience in there has totally changed because you now have expectation from “JimSmith99 on Yelp” because he told you to get the trout but “hold the almond sauce” or whatever it is

***Michael thinks that changes us and there is a case for trying to re-explore the world like we used to***

**You go into situations totally cold, and what will that be like?**

- What value will you get from that internally by doing this thing that no one told you about?
- You don’t have any expectations going in
- You are just having this totally unadulterated moment that is in the present moment
- Of course, not just restaurants: it’s watching a movie, reading a book, listening to an album, going to a different part of town
- There’s all these different ways that you can have these more momentous occasions in your life without necessarily needing to follow the metaphorical Lego plan (to the point of your kids)

**Michael writes about how** ***homo sapiens*** **were really the break off point to true exploration**

- In terms of distance traveled, risk taken, etc.

*Why didn’t Neanderthals do the same?*

- Neanderthals were bigger than us, stronger, had bigger brains, and could walk upright

*Do we have a sense of what changed?*

- Humans are fascinating in that about 50,000 years ago, we took over the world
- Neanderthals were around a long time and they just were in the same place most of the time.
- Once we take over the world, we go on to build highways, a launchpad for a spaceship and go up into outer space, a submarine

*Was it just something that randomly got selected for in the change to homo sapien and then it just got rewarded and rewarded?*

- There’s a little bit of evidence of this gene, that is nicknamed the “exploration gene,” that seems to be around in populations that move a lot more
  - It’s far more prevalent in nomads
  - It’s far more prevalent in societies that would’ve traveled farther from our origins in East Africa
- There’s some inherent reason why we would’ve kept moving, and maybe it’s just that we get internal rewards from that

## The consequences of an attention economy driven by negativity bias [1:16:30]

**Do we owe** [**Benjamin Day**](https://en.wikipedia.org/wiki/Benjamin_Day_(publisher)) **gratitude or despair?**

- Before 1830, newspapers cost 6 cents
- They tend to cover business and politics
- They’re weekly
- Benjamin Day comes in and he wanted to create a paper that gets a lot of readers, because 6 cents was a lot of money back then
  - He wanted to sell a newspaper for 1 cent (at a loss)
- To make up for his loss, he went to companies and said, “*Hey, I will publish stuff about your brand in my newspaper. People will see it and they’ll buy your stuff.*”
- This guy really started the advertising model
- Once he does that, you can charge more money for your advertisements and you get more readers
  - Because the more readers we have, the more money we can make off each ad
- The ads are how we’re making our money
- Then he changed the content
  - Business is boring so he starts covering murder, mayhem, affairs, fights, all these different things that attract attention

*This is when you start to see the real shift in what newspapers were covering*

- He literally ran a headline that was bathed in blood; it was about this murder suicide in New York City

***He starts to publish every single day for one penny and the headlines are always crazy gore, and this is when you start to see the “attention economy” take off***

- In order to make money off an ad model, you have to get as many eyes as possible
- The way you do that is often by running **information that is negative**, that is lured, that is going to capture as much attention as possible
- Still today, 90% of news tends to be negative
  - Now, this holds whether or not the world is improving or not
  - Things could be much better than they were 100 years ago, but our papers are still 90% negative news

**Evolution selected for a negativity bias**

- Peter points out, “*There’s an evolutionary basis for negativity bias. You could make the case for how we are far better off evolutionarily to pay attention to negative signals rather than positive signals. The negative thing is what could kill you that demands your attention. The positive thing is great, but it doesn’t need as much attention in the moment.*”
- If you’re the person who’s looking at how beautiful the flowers are as the saber-tooth tiger walks up this way, you’re not going to live that long
- It’s incredible to think that natural selection could have no appreciation for what would come with modernity and how it would render so many things maladaptive

An example of this: social media companies and how their algorithms work

- If you let those things run their course, things that get the most traction tend to be the most lurid crazy things
- One of the main reasons we’re so polarized as a country today, is that moral outrage is particularly great at capturing attention
- Those things get upvoted because they’re going to get more eyes
- While that is good for bringing in eyes and making money for a social media company, it’s not necessarily good for society

**You wrote in the information chapter about a study that was done on the social media use of politicians. What did you learn?**

- This goes back to quantification and how there are some downsides to quantifying everything and gamifying everything
- In this [study](https://journals.sagepub.com/doi/10.1177/19485506221083811), scientists use an AI algorithm to analyze all of the tweets from politicians of about 10 years, and what they found is
  - When politicians would first get onto Twitter, it was nice things like, “Hey, we’re having a fundraiser, blah, blah, blah,”
  - But once they would tweet something negative that was attacking another person, they would start to get more likes and retweets, and that, in turn, would feel good
    - This told them what works on this platform and how to get points

***From there, you started to see the number of negative tweets from them increase over time because that’s what gets rewarded on social media***

- These tweets probably aren’t an accurate reflection of who these people really are or what we really want in society
  - Do we want our politicians being terrible human beings on Twitter?

**Peter’s thought experiment**

- Twitter and social media run exactly the same as now, except the person who was commenting was blinded to the feedback from others (for example, likes and retweets)
- If you put out something, you could put it out and everybody could still see it just as they do, but if they liked it or retweeted it, you wouldn’t see that

*How do you think that would change things?*

- To back up, the algorithm trains us how to behave and use the social media platform
- There’s not a huge difference between when Michael stands by the treat jar and says, “S*top and sit*,” his dog puts his butt on the floor and he gives him a treat (he knows to do that)
  - When he goes on social media and tweets some crazy thing and all you other humans go like, like, like
    - That tells me, if he wants the good thing, whether it’s his dog with a treat with the likes on social media, he’s got to do that thing
    - Whether it’s sitting or writing, “*Donald Trump is an idiot. Hillary Clinton’s an idiot, so-and-so’s an idiot*”

***You get trained based on how the system is set up with likes and retweets and followers, and that’s a long way of saying you’d probably see less of that training occur [in this experiment]***

## Navigating the world of endless information and the value in “slow information” [1:23:00]

**We have evolved to want information. Have we evolved to want the truth?**

- Michael talked to a philosopher at the University of Utah named T. Wynn [[John Wynne](https://faculty.utah.edu/u6020310-John_Wynne/hm/index.hml)]
- He talked a lot about how we evolved to trust when we feel like we’d gotten the right information
  - It gives us this “aha moment”
  - We have a question, we find what we believe is the answer, and we go, “*Aha, that feels good. This makes sense*.”
    - Things were probably pretty clear in the past ‒ you either got the food that was going to lead you to survive or you didn’t
    - You either found shelter or you didn’t
    - You could trust that, “*Aha, here’s the food.*”

***In today’s age, whenever we have a question, we can go seeking out information from a lot of different sources, and we can get that “aha moment” whether or not the information is factually correct or not***

**For example, why are conspiracy theories compelling?**

- Because they give you an “aha moment”
- Conspiracy theories, they might seem complicated and they often are
- But at the end of the day, you have a very specific answer for why this thing is the way it is
  - It clears up any ambiguity
- In reality, most things in life are very uncertain; they’re very ambiguous
- We don’t fully understand why a certain thing has ever happened

***But if you can provide someone with an “aha”, that is going to give them a feeling of clarity, a feeling of certainty, and they can rely on that to make decisions whether or not the information is actually accurate***

- Peter adds, “*I think people also find conspiracy theories appealing when they provide a grand narrative to something to which the truth is insignificant.*”

**A good example of this (and one where Peter has gone down the rabbit hole on) is the assassination of JFK**

- Peter is sure he will enrage a subset of the listeners
- Every available shred of reasonably good evidence, if you actually understand ballistics, everything points to a single shooter
  - Peter’s training in surgical residency taught him a lot about what bullets do when they hit people
- Everything points to three shots being fired by [Lee Harvey Oswald](https://en.wikipedia.org/wiki/Lee_Harvey_Oswald)
- By the way, it wasn’t hard shooting
  - These were the easiest three shots in the world
- He killed JFK

**Why do we have to have so many conspiracies?**

- Because how can we accept that such an insignificant, irrelevant human being like Lee Harvey Oswald, could alter the course of history?
  - That’s impossible for most of us to wrap our minds around
- It’s much easier to think that the CIA had to do this because of “pick your favorite Oliver Stone idiotic reason”
  - Michael wonders how that factors into us as storytellers and the need to have information
- Some conspiracy theories turn out to be true
- It’s not always that the first answer is right or the first answer is wrong

**This gets to another issue that** [**Nguyen**](https://faculty.utah.edu/u6021584-C._Thi_Nguyen/hm/index.hml;jsessionid=F529420980D3B3929D6914A2571388F4) **brings which is the idea that we should think of food and information as analogous**

- Where too much fast food is bad for you, and too much loose information without nuance is bad for you
- He compared information to food, where, if you give up on a food’s nutritional quality, it’s very easy to make very delicious tasting food, seductively good food

***The same is with information: if something just feels really good, really tasty, you should probably use that as a sign to maybe investigate the issue further, to look at what the other side is saying***

- Peter agrees and thinks it’s a beautiful analogy, “*If you’re willing to sacrifice truth and nuance, you can have the most seductive information possible. Yeah. If you’re willing to sacrifice nutrition, nutritional quality, you can have the most delicious food possible.*”
- It is so easy to find anything online today
- In the book, Michael talks about how there’s answers to the most mundane questions that we could have in daily life, like:
  - Product reviews, “*What is the best pillow case?*”
    - This is the epitome of a first world problem, but here, I’m going to spend 800 words of my time reading this story about what is the best pillow case

***We have so many experts, we have so much information, we have maybe more knowledge in the world, but we don’t necessarily have more understandin***g

- We don’t have more of an understanding of, “*How should I actually spend my time?*”
  - Do I want to go down the hour-long review sites on pillow cases or whatever the item might be?
- And you can apply this to so many different things
- Does WebMD ever really help a person figure out what’s going on?
  - Or does it just lead them to go, “*Oh, definitely stage four cancer?*”
- Peter thinks that’s a fair comparison

**What tool would you recommend for the person listening who is a bit of an information addict**

- Peter admits he’s a bit of an information addict
  - He’s at a point where his innate desire for information is becoming maladaptive, just as his natural and adaptive behavior to seek food has become maladaptive; he’s in the same place information wise
- Michael thinks that information falls into that scarcity loop that he talked about
  - You’re looking for this piece of information that you think is going to improve your life, but you don’t know where it is
  - And so, you search and search the web, and then, when you find it’s like, “*Bingo, great. I found it*.”
  - And then, you can quickly repeat

***One strategy to use for any behavior you do in excess is to slow it down or reduce the frequency***

- There’s this interesting study that Michael writes about in the book, involving two groups of students who have to figure out the answer to a question
  - The first group could use the internet
    - So they go online, they search it, they find it really fast
  - The second group could not use the internet, so they had to use books
    - They got to go to the library, they got to walk the stacks, they got to find the book, and then, they got to open to figure out where the information is in the book
  - This second group, not only did they have slightly better information, but more importantly, they were better able to recall it
    - Later on, when they were tested on it, they did better

***There is an argument for a shift to slow information when you really want to understand something, because these people were better able to put it into context***

- Most people are going to listen to that and say, “*It makes sense, but I’m never going to get up off my desk and go to the public library and look at the stacks*.”

**Is there a way that you can toggle between fast and slow information, still using the internet, for example?**

- If you do really want to understand something, realize you’re probably going to have to put in a little bit more work
  - It can’t be a quick Google search
- This is how Peter justified the existence of this podcast
  - If you really want to understand a topic
  - He tries not to make too many apologies for the fact that we have three hour episodes

**Michael suggests a useful heuristic**

- If you have a random everyday questions, and it’s not of much consequence in your life, try to make the decision in 60 seconds
  - How do I get to Arby’s?
  - What pillowcase should I buy?
- Just pick something, because eventually, you’re wasting time

**In the book, Michael writes about when he was an intern at Esquire and he got an assignment to find out how much money the Pope makes**

- He searched online and called up some Catholic academic and came up with an amount
- He sent the research file to his editor and got an email back to meet in the conference room in five minutes
  - This was at the Hearst building in New York, which is where Esquire is, and so, we’re looking down the barrel of Eighth Avenue, and he’s sitting at this long table
  - He goes, “*Sit down*.”
  - He just looks at me, starts shaking, his head, leans back, and he goes, “*No, no, no, no. If you want to know how much money the Pope makes, you call the fucking Vatican*.”
- The point is, Michael had totally missed the most obvious answer: if you want to know something about a person, ask the person
  - But instead, we’d have now all these sort of kooky ways to go around it

***If you can really go to the source***

- If you hear someone online say, “*Oatmeal is totally toxic and blah, blah, blah.*”
- You’re probably going to have to **learn to read the study**
  - Michael points out about Peter, “*Luckily, you provide information like that, that is useful*.”
- If you want to know what a person thinks, maybe **ask them**, look at what they’ve written on a thing, watch the full interview in context
- You see someone say something that seems crazy in a 30 second Instagram clip; maybe we should get the first five minutes and the last five minutes after that, so we kind of **know what the context is**
  - You’ll probably find that it’s taken out of context and it’s being used against the person

***It is so easy to get such quick seductive information; you want to do a little more work for the things that you really want to understand and not jump to conclusions***

- For example, media outlets get in trouble because they publish all these op-eds about a 30 second Instagram clip
  - Like with the Covington Catholic student — and now, they owe the kid $250 million, because we jumped to conclusions on a 30 second video clip

## Defining happiness, and the downward trend in reports of happiness [1:33:00]

- The last section of the book is on happiness, and this is the chapter that Peter thinks about the most

**How do you define happiness?**

- Michael had the same question (and still does)
- The dictionary says it’s a feeling of joy, and maybe felicity
- Then you look up joy and it says, “*A feeling of happiness*”
  - So it’s circular
- People define happiness in all different ways
- [Seneca](https://en.wikipedia.org/wiki/Seneca_the_Elder) said happiness is not having anxiety about the future, feeling okay in the moment
- [John Lennon](https://en.wikipedia.org/wiki/John_Lennon) in his famous song said, “[*Happiness is a warm gun*](https://youtu.be/vdvnOH060Qg?si=R2n1FRfPcXSnHWT_)”
- It’s hard to define, and it’s also one of those things where maybe we don’t even know it when we are happy, but we can look back and be like, “*Oh, that was a happy moment in my life*.”
- It’s this very, very murky thing, and yet, we all want to be happy
- That is sort of the capital G goal of most of the things we do
  - We take a drink, because we think it’s going to make us happy
  - We make this purchase, because we think it’s going to make us happy
  - We seek out that information on WebMD, because we think that, if we know what this thing is, that’ll give us some relief
- But it is a very confusing topic, and maybe we know a little bit less about it than we think

**Where does happiness fit on** [**Maslow’s hierarchy of need**](https://en.wikipedia.org/wiki/Maslow%27s_hierarchy_of_needs)**?**

- Peter knows that self-actualization is about the 4th rung
- Michael doesn’t think it actually fits into it, but he hasn’t looked at it in a very long time

![](https://peterattiamd.com/wp-content/uploads/2024/01/f1-michaeleaster2.png)

**Figure 1. Maslow’s hierarchy of needs, represented as a pyramid with the more basic needs at the bottom**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Maslow%27s_hierarchy_of_needs)

- It seems odd that happiness is not there, because depending on how you define happiness, it does seem like a very high-order goal
- Peter guesses Maslow is not defining it as a need, and maybe that’s why it doesn’t belong there

**What made Michael write this chapter was realizing that we all want more happiness**

- This book looks at the things that we all want more of, and how they have changed over time
- While most of the chapters say, “*We have a scarcity of this thing. Now we have a massive abundance of it,*” that hasn’t necessarily held for happiness in a lot of ways
- For example, from 1979 to 1999, you saw real income grow by about 43% among Americans, but we didn’t actually become any happier
- If we think that progress and money is always going to make us happier, Michael doesn’t think that that is the case

**When do you think peak happiness occurred?**

- Peter often thinks, on his worst day, “*I’m so happy to be alive today and to have not have been alive 200 years ago or 2000 years ago or 20,000 years ago.*”
  - Now, that’s a bit of a dumb thing to say because he has no idea what it was like to be alive 20,000 years ago, when you don’t know what today feels like
  - In other words, when you were getting eaten alive by mosquitoes and ants every day, while you scavenge for food, if you don’t know what this is

*Do the people who attempt to study this have a sense of when peak happiness occurred for our species?*

- Not that Michael has come across
- He does know that we are seeing decreases in happiness in the data

***A lot of the data suggests that people are becoming less happy***

- Michael would imagine that as we’ve gotten more **technology**, the technology improves your life and happiness to a certain point, and then it begins to constrain you, and that could potentially make you more unhappy
- [Arthur Brooks](https://arthurbrooks.com/meet-arthur) has written a lot about happiness, and Peter has found the way Arthur writes about it to be the best ways to think about it
  - Because he doesn’t write about happiness as a feeling
    - That’s the problem with the dictionary definition and why it’s circular, because happiness points to a feeling of joy and joy points to a feeling of happiness
- Arthur really writes about components of happiness, what he describes the **macronutrients of happiness**: **enjoyment** being one of them, and really having this essential component of being **shared** with others
  - Enjoyment being a much deeper thing than pleasure, pleasure being purely sensory, enjoyment being more cerebral
  - He talks about **satisfaction**, which of course, is the most fleeting of them, but is highest when there is a struggle
    - This goes back to many of the examples Michael has already given, which is, if you get something easily, it’s not very satisfying; and if you have to work very hard to achieve something, it’s more satisfying
    - Probably for very important evolutionary reasons, we can’t keep satisfaction, and that’s what keeps us striving
  - The final what he calls macronutrient is **sense of purpose** ‒ without that, we can’t have true happiness
  - To date, this is the best model Peter has encountered

## Purpose, austerity, self-reliance and other missing elements of happiness gleaned from the study of monks [1:38:30]

**To study this, you continued your incredible journey of going and doing really hard things. What did you seek out in the pursuit of happiness?**

- Long story short is Michael spent **a week at a Benedictine monastery** in the mountains of New Mexico
- He went there because we live in a world where there’s a lot of these different things we’re supposed to be doing for our happiness, and they’re often backed by research
  - You’ve got to meditate, you’ve got to gratitude journal, you’ve got to have as many friends as possible, blah, blah, blah, and that all seems great

**What Michael finds so fascinating about these Benedictine monks, is that they go against a lot of the happiness research that’s in pop culture right now**

- They live a pretty hard life
  - They get up at 3:00 AM, start to pray
  - They don’t eat a lot of food, so they’re not getting pleasure from meals
  - They’re also in silence most of the time
  - They do hard labor for four hours every single day
  - They’re not entirely social, because it’s the silence and they often work alone
  - They’re celibate; there’s no relationships
  - There’s no real access to the outside world, in terms of they’re not on Facebook and keeping up with the news that way
- Their motto is “*Ora et labora*,” which is pray and work
- The researcher [Alex Bishop](https://experts.okstate.edu/alex.bishop/about) has done a lot of research on them and their happiness levels, and they seem to be happier than the average American
  - Despite all these hardships that they face in their life, despite all these sort of crazy, unnecessary things they seem to be doing

***They wind up significantly happier than us, when we have access to all these things that should make us feel great in the moment***

- Michael lived with the Benedictine monks for a week
- His main takeaway really goes back to what Arthur was saying is that, ***if something is challenging to get, we get more rewards from that***

> “*My main takeaway for them [the Benedictine monks]… is that, if something is challenging to get, I think we get more rewards from that*.”‒ Michael Easter

- That also makes sense from an evolutionary perspective
- Michael talked to a guy named [Thomas Zentall](https://psychology.as.uky.edu/users/zentall), and he explained that the reason for this is probably, if you had to search and search and search for food and you weren’t finding it, but you persisted and persisted and persisted, and then, you find the food
  - That situation has to be inherently more rewarding than the food that was very easy to come by, in order to incentivize future searches

***It’s doing hard work and not necessarily having everything given to you that becomes rewarding for humans***

- Michael’s other takeaway ‒ they’re not necessarily in it for themselves
- They’ve given their lives over to this higher ideal, even though it does require a lot of sacrifice
  - For them, that higher idea is God
  - They’re trying to get out of themselves, they’re trying to help others and help this greater idea, and it doesn’t ultimately all come back to them

*The lesson in there for the average person is, what sort of thing can you do to get out of yourself and find some greater meaning and purpose, beyond just your next desire?*

**What element of happiness is missing for most of us? [1:41:45]**

*Reading this part of the book made Peter feel uncomfortable*

- The idea that you were going to wake up at 3:30 every morning, do your first prayers, go and work, go and do your second prayers, go and eat, go and do your next prayers, go and work
- He was like, “*I would kill myself.*”
  - The work part, he would get
  - The prayer part would kill him, he would lose his mind
- Clearly, this is not what Michael is proposing, but it’s an interesting contrast and example

***Peter wonders which element is missing for most of us***

- Peter has met some people who have an amazing sense of purpose
  - They’re very mission-driven to their work, to their technology, to their company, whatever it is they’re doing
  - They struggle and strive and succeed, and that’s short-lived
  - And then, they do it again and again and again
  - They also seem to enjoy themselves
  - They do lavish things and they share the company of others
  - Yet, ostensibly, they don’t seem that happy
- You could argue their sense of purpose is not really serving the world
- If every one of these monasteries went away, the world would continue to turn on its axis
  - You can’t say that for many professions
    - If every janitor went away tomorrow, the world would grind to a halt
  - Even if your job is cleaning, you have a really significant purpose
  - Not to disparage the monks, but it’s like they’re in their own bubble, where they’re self-sufficient

**The monks do everything for themselves, but is that the purpose?**

- Is it that they help each other?
- Peter is still struggling to understand how they’re happy
- Yeah, Michael thinks they help each other
- They do a lot of work in the community
- Michael even wonders about the pace of their life
  - It’s definitely slower than how we live now

***This suggests that there is no perfect plan for happiness***

- In fact, by trying to be happy, that’s not a great way to be happy
- If you google how to be happy, and it says, “*This study said this. You need to start a gratitude journal*.”
  - That might help a few people

***The reality is that it’s so much more complicated that something that can be distilled down to quick actionables***

> “*The commonality you see is that people who tend to be happy, they tend to be do something that they believe is of service and is going to a greater good… but maybe they believe what they’re doing has consequence in some afterlife*.”‒ Michael Easter

**For happiness, it’s useful to find something that is greater than yourself**

- If you’re doing the next thing to fulfill your next impulse, that’s probably not going to be good for you over the long run

**Austerity sometimes is a key to being happy**

- The best way to feel grateful for something is to be deprived of it for a while
- And these monks really practice that, for example, with food (they do not eat a lot)
- Every now and then (like on a Saint’s birthday) they get these festivals where they have a lot of food, and this becomes a moment where they’re like, “*Oh, I really appreciate this food that I worked hard to bring to us*.”

***Without having to put in effort or never being deprived of anything, you just normalize to whatever you have ‒ it doesn’t matter if you have a base model 2001 Honda Civic or a brand new Ferrari, that’s what you’re going to normalize to***

**How much do you think the following cycle is on an inevitable loop in society?**

*Cycle: hard times make hard men, hard men make soft times, soft times make soft men, soft men make hard times*

- Michael thinks this is reasonable and you see it historically

**What is so interesting about now is that things change faster than ever ‒ people are changing**

- How we spend our time is changing faster than ever
- Michael wonders how that’s affecting us
- He’s a [professor at UNLV](https://www.unlv.edu/news/expert/michael-easter), and he’s seen changes in his students over the past seven years
- You would normally think that a big change in behavior would probably take generations to pop up, but he’s definitely seen changes
- He thinks it is simply because of ***how we spend our time and attention more online***
  - You are the product of your attention
  - Fewer in-person interactions

**What do you make of the difference between solitude and loneliness, as you gathered it from this experience?**

- There’s a lot of information out about how it’s good to have friends, to be social (probably for a good reason)
- Michael thinks what you need is what’s called anticipatory support, which is basically someone or some bigger idea that you can count on
- But in terms of having this big bevy of friends, he doesn’t think that that is necessary for happiness
  - Having certain people that you can count on basically and having maybe one good relationship is better than a bunch of mediocre ones
- When it comes to being alone and being in solitude, he thinks the difference with **loneliness** (or aloneness) is that you didn’t necessarily choose that
  - You want to be with people, but you’re not able to
- Whereas **solitude** is using this time, you’re consciously taking this time to be alone with yourself and use it maybe to get to know yourself better

**When you look at people who we consider the happiest and most enlightened in history, a lot of them spent a lot of time alone**

- Jesus walked out into the desert for 40 days
- The Buddha walked the earth for six years, or whatever it was
- And when you look at a lot of those writings, they don’t say, “*Oh, this whole 40 days or six years was entirely blissed out*.”

***It’s hard to be alone, but by going through that and thinking about, “Why is it hard?” you can get to know yourself and get deeper revelations about yourself***

- That’s a narrative that you see across different faiths and history, that, sometimes, people need to go through solitude as a way to gain insight into themselves
  - And once they do that, you can then come back into society and you’re better able to function in it, because you’re now more self-reliant
- Michael thinks what makes a good human is someone who can be reliant on themself and can, in turn, help others

## The value in uncomfortable activities that increase your awareness, presence, and will to live [1:48:45]

**Michael writes that our will to live is no longer really a vital part of our existence**

- This was in the epilogue and in the context of learning survival skills prior to going into Baghdad
- This resonated with Peter because he can certainly think of times when he has exerted his will, but he doesn’t really think about it in terms of will to live
- Yet, for all of human history, that was a thing
  - Think about that snake jumping out of the jungle or think about the complete lack of food or the dysentery you just got
- There’s so many areas where the will to live must have been one of the strongest selective features of our existence, and yet, today, it’s never put to the test

*What is the implication of that?*

- Michael thinks it’s easy to just sort of exist, not live

**Michael’s trip to Baghdad**

- Before he went to Baghdad, he realized he should probably learn some skills, should things go south
- He went and met a friend, [Mike Moreno](https://evonexus.org/profile/michael-moreno/), who is a VC guy
  - Before that, he spent years in the CIA in Baghdad running operations
- Mike took him out into the desert, outside of San Diego and went through all these different skills he would need to know, in order to survive, should something go wrong
  - They spent eight hours on all the ways you could die
- At the end of the day, we’re sitting on the tailgate of his SUV, and he looks over at Mike and he goes, “*Man, I’m really jealous that you’re going there.*”
  - He explained, “*What I miss most about my time there is because it was austere, it was dangerous, you did have to be present and focused on what was around you. I found that extremely life-giving. You were thrust into the moment, and you really had to exercise this will to live.*”
- When Michael got back from Baghdad, he totally understood that
- He will remember every moment of being there because you can’t just zone out
  - You’re looking around at everything; you’re aware
  - Every interaction becomes important
  - You have to make judgment calls in the moment
- Michael explains, “*There is some underlying level of danger, and that uncertainty, forces me into presence and awareness and makes my time consequential. And I think that is life-giving*.”

***We do not have that in a way (which is a good problem to have)***

- But when you think about the context, of how humans evolved
  - We lived like that all the time, because we didn’t know where our next meal might come from
  - We didn’t know what the weather would bring
  - We didn’t know what was happening next
  - And we were having to really work and struggle to survive

***There is probably something rewarding to that and to be in the moment and to have to work on a deep level (just be in it) to get the things that you get***

- The takeaway for the average person is not to go to Baghdad

**How can you do things in your life that maybe reflect that a little bit?**

- Michael gets that from hunting
  - You have to be present, you have to be focused, you have to be aware
  - It’s not exactly comfortable

- People can get that from all sorts of things that they can do outdoors
- Could be from volunteering and helping others

***Something that puts you in the moment and makes you aware, is important for happiness***

§

## Selected Links / Related Material

**Think tank at UNLV**: [Public Communication Initiative](https://www.unlv.edu/urbanaffairs/pci) | UNLV (2023) | [1:15]

**Michael’s previous book and subject of prior podcast**: [The Comfort Crisis: Embrace Discomfort To Reclaim Your Wild, Happy, Healthy Self](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) by Michael Easter (2021) | [1:15, 2:30, 32:00, 35:00, 1:04:45]

**Michael’s most recent book**: [Scarcity Brain: Fix Your Craving Mindset and Rewire Your Habits to Thrive with Enough](https://www.amazon.com/Scarcity-Brain-Craving-Mindset-Rewire/dp/0593236629/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1700500971&sr=8-1) by Michael Easter (2023) | [1:30, 2:15, 39:45, 1:09:45, 1:33:00]

**Previous episode of** ***The Drive*** **with Michael**: [#225 ‒ The comfort crisis, doing hard things, rucking, and more | Michael Easter, MA](https://peterattiamd.com/michaeleaster/) (October 3, 2022) | [2:30]

**The Tsimané tribe does not get heart disease**: [Coronary atherosclerosis in indigenous South American Tsimane: a cross-sectional cohort study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6028773/) | *Lancet* (H Kaplan et al 2017) | [10:15]

**2 weeks on an ultra-processed diet**: [Ultra-processed diets cause excess calorie intake and weight gain: An inpatient randomized controlled trial of ad libitum food intake](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7946062/) | *Cell Metabolism* (K Hall et al 2019) | [21:15]

**Previous episode of** ***The Drive*** **on the epidemic of drug addiction**: [#243 ‒ The fentanyl crisis and why everyone should be paying attention | Anthony Hipolito](https://peterattiamd.com/anthonyhipolito/) (February 20, 2023) | [51:00]

**Political tweets become more negative over time**: [Incivility Is Rising Among American Politicians on Twitter](https://journals.sagepub.com/doi/10.1177/19485506221083811) | *Social Psychological and Personality Science* (J Frimer et al 2022) | [1:20:15]

§

## People Mentioned

- [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) (Section Chief: Integrative Physiology Section, Laboratory of Biological Modeling at the National Institute of Diabetes and Digestive and Kidney Diseases) [21:15]
- [Carl Hart](https://psychology.columbia.edu/content/carl-hart) (Professor of Psychology at Columbia University, expert in psychoactive drugs) [53:45]
- [John Wynne](https://faculty.utah.edu/u6020310-John_Wynne/hm/index.hml) (Adjunct Associate Professor of Philosophy and Associate Professor of World Languages and Cultures at the University of Utah) [1:23:15]
- [C. Thi Nguyen](https://faculty.utah.edu/u6021584-C._Thi_Nguyen/hm/index.hml;jsessionid=F529420980D3B3929D6914A2571388F4) (Associate Professor of Philosophy at the University of Utah) [1:26:15]
- [Arthur Brooks](https://arthurbrooks.com/meet-arthur) (Professor at Harvard Business school, best-selling author on happiness) [1:37:00]
- [Alex Bishop](https://experts.okstate.edu/alex.bishop/about) (Professor of Human Development & Family Science, researched happiness in Benedictine monks) [1:39:45]
- [Thomas Zentall](https://psychology.as.uky.edu/users/zentall) (Professor of Psychology and Cognitive Neuroscience at The University of Kentucky) [1:40:30]
- [Michael Moreno](https://evonexus.org/profile/michael-moreno/) (expert in VC and startups) [1:50:15]

§

![](https://peterattiamd.com/wp-content/uploads/2024/01/bio-michaeleaster-500x500.png)

##### Michael Easter, M.A.

Michael Easter earned his B.A. at Wheaton College and M.A. in Health Journalism at New York University.

Michael Easter teaches journalism, with a special emphasis on health media at the University of Nevada, Las Vegas.  Michael hosts *Nevada Health*, a weekly health radio show on KUNV, and his writing appears in *Men’s Health*, *Outside*, *Vice*, *Cosmopolitan*, *Scientific American*, *Men’s Journal*, and *FiveThirtyEight*.  Michael authored the best-sellers [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) and [*Scarcity Brain*](https://www.amazon.com/Scarcity-Brain-Craving-Mindset-Rewire/dp/0593236629/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1700500971&sr=8-1).

Michael’s work and ideas have appeared in over 60 countries. They’ve been endorsed by directors of the CIA and Navy SEALs, gold medal-winning Olympians, leading physicians, Pulitzer Prize-winning authors, Buddhist and environmental leaders, and more. His writing has appeared in *Men’s Health*, where he’s a Contributing Editor, and *Outside*, *Men’s Journal*, *Cosmopolitan*, *Vice*, *Esquire*, *Scientific American*, *FiveThirtyEight*, and *Women’s Health*. He’s also talked about his work and ideas on the world’s largest, most influential podcasts, like *The Joe Rogan Experience*, *Art of Manliness*, *Impact Theory*, *NPR*, *EconTalk*, and more.

When he’s not on the ground reporting, Michael is a professor in the journalism department at UNLV. He co-founded and co-directs the [Public Communications Institute](https://www.unlv.edu/urbanaffairs/pci), a think tank at the University of Nevada Las Vegas (UNLV). [[UNLV](https://www.unlv.edu/news/expert/michael-easter) and [eastermichael.com](https://eastermichael.com/about/)]

Michael’s website: [ME](https://eastermichael.com/)

Instagram: [michael\_easter](https://www.instagram.com/michael_easter/?hl=en)

Twitter: [@Michael\_Easter](https://twitter.com/michael_easter?lang=en)

Facebook: [Michael Easter](https://www.facebook.com/pages/category/Writer/Michael-Easter-225875898170585/)