# #379 – AMA #79: A guide to cardiorespiratory training at any fitness level to improve healthspan, lifespan, and long-term independence

**Source:** [https://peterattiamd.com/ama79/](https://peterattiamd.com/ama79/)

---

In this “Ask Me Anything” (AMA) episode, Peter brings together his most up-to-date thinking on cardiorespiratory fitness into a single, practical guide designed to help listeners structure training for maximal impact on healthspan, lifespan, and long-term independence. He explains why cardiorespiratory fitness is one of the strongest modifiable predictors of longevity, clarifies what zone 2 training actually represents and how it differs from higher-intensity work, and addresses persistent confusion around exercise volume, intensity, and time constraints. The discussion covers how to measure and track progress in zone 2, VO₂ max targets and age-adjusted goals, planning for the marginal decade, and how to balance zone 2 with higher-intensity training across different weekly volumes. Peter also outlines how cardio training should be tailored for beginners, experienced trainees, and older adults, with special considerations for women and guidance on avoiding the most common cardio-training mistakes.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #79 show notes page](https://peterattiamd.com/ama79/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Rational for discussing cardiorespiratory fitness, zone 2, and VO₂ max despite having covered the topic extensively [A: 2:30, V: 00:10];
- Why cardiorespiratory fitness and VO₂ max are powerful and modifiable predictors of all-cause mortality compared with other health metrics [A: 7:30, V: 5:55];
- How age-related declines in VO₂ max constrain healthspan and everyday physical function [A: 12:30, V: 11:40];
- The cardiorespiratory fitness triangle: how different training intensities contribute to building the aerobic base, the aerobic peak, and overall aerobic capacity [A: 14:15, V: 13:25];
- The cellular mechanics of cardiorespiratory fitness: mitochondria, lactate, muscle fiber recruitment, and intensity thresholds [A: 18:45, V: V: 18:50];
- The debate over whether zone 2 training has unique benefits or whether higher-intensity exercise alone is sufficient [A: 27:15, V: 28:33];
- Balancing intensity and sustainability as training volume increases, and the important role of zone 2 training [A: 32:15, V: 34:20];
- How to identify your zone 2 training intensity [A: 34:45, V: 37:25];
- How to measure and track improvements in zone 2 fitness [A: 40:00, V: 43:10];
- How to accurately measure VO₂ max: lab testing, field tests, and the limits of wearables [A: 45:15, V: 49:12];
- How to set meaningful VO₂ max targets based on age, sex, long-term decline, and desired physical capabilities later in life [A: 51:15, V: 56:10];
- How to structure and execute a zone 2 workout [A: 59:45, V: 1:05:53];
- How strictly should zone 2 be maintained during a workout? [A: 1:04:00, V: 1:10:54];
- How to design a VO₂ max training session: interval length, intensity, recovery, and progression strategies [A: 1:07:00, V: 1:14:30];
- Why heart rate is not a reliable metric for titrating VO₂ max interval intensity [A: 1:12:00, V: 1:20:23];
- Practical ways to monitor VO₂ max improvements [A: 1:13:30, V: 1:22:05];
- How to balance zone 2 and VO₂ max training [A: 1:15:30, V: 1:24:10];
- How to structure training for someone limited to 150 minutes per week of total exercise [A: 1:19:00, V: 1:28:15];
- How to allocate 150 minutes per week of dedicated cardiorespiratory training between zone 2 and VO₂ max work [A: 1:23:00, V: 1:32:50];
- How to structure training for someone with substantial available time who wants to maximize cardiorespiratory fitness [A: 1:24:30, V: 1:34:16];
- Why spreading aerobic training across the week beats compressing volume into one session [A: 1:26:15, V: 1:36:25];
- How beginners and metabolically unhealthy individuals should start cardiorespiratory training safely [A: 1:28:00, V: 1:38:18];
- How “training age” determines the intensity and workload needed to continue improving cardiorespiratory fitness [A: 1:31:15, V: 1:41:58];
- Why zone 2 training still matters for women (including postmenopausal women) [A: 1:32:45, V: 1:43:53];
- How cardiorespiratory training should adapt with aging [A: 1:35:45, V: 1:47:22];
- The most common mistakes people make when training cardiorespiratory fitness and how to avoid them [A: 1:37:45, V: 1:49:31];
- How to break through a VO₂ max plateau [A: 1:40:45, V: 1:53:30];
- The main takeaways about cardiorespiratory fitness and longevity [A: 1:41:30, V: 1:54:16];
- Peter’s carve out: oral hygiene and Peter’s two-toothbrush system [A: 1:43:00, V: 1:55:40]; and
- More.

---

The Peter Attia Drive

#379 – AMA #79: A guide to cardiorespiratory training at any fitness level to improve healthspan, lifespan, and long-term independence

---

## Show Notes


---

## Rational for discussing cardiorespiratory fitness, zone 2, and VO₂ max despite having covered the topic extensively [A: 2:30, V: 00:10]

**Purpose and scope of the episode**

- The episode focuses on a single overarching topic: cardiorespiratory fitness.
- Cardiorespiratory fitness is framed in practical terms as zone 2 training and VO₂ max.
- This topic has been covered across many previous podcasts, guests, and articles.
  - Previous content on [zone 2](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/)
  - Previous content on [VO2 max](https://peterattiamd.com/category/exercise/vo2-max/)
- Despite extensive prior coverage, it remains the most frequently asked-about topic.
- The interest stems largely from cardiorespiratory fitness being one of the strongest modifiable predictors of both healthspan and lifespan.
- Cardiorespiratory fitness represents a lever people can meaningfully act on to influence long-term outcomes.
- The episode is intended to function as a one-stop guide for measuring, tracking, and improving zone 2 and VO₂ max through training.

*Who is this episode designed for?*

- The discussion is structured to apply to all types of people:
  - Those with a wide range of available training time.
  - Those with very limited time to exercise as well as those with ample time.
  - Beginners who are just starting to train.
  - Those who have been training consistently for many years.
- Considerations for older adults are explicitly included.
- The discussion examines whether training recommendations differ for women.
- The episode aims to be broadly applicable rather than tailored only to athletes or highly trained individuals.

**Key themes and questions the episode will address:**

- How zone 2 and VO₂ max training should be understood in practical terms.
- How recent debates and discussions around zone 2 and lactate influence current thinking.
- How to balance training volume and intensity effectively.
- Why sustainability matters more than short-term performance spikes.
- How to avoid patterns where training intensity leads to burnout or abandonment.
- How to think about long-term training consistency rather than short-lived motivation.

**Rationale for creating a consolidated guide**

- There is already an enormous amount of existing content on this topic.
- Aggregating all prior discussions would require hundreds of hours of listening (unrealistic for most people to consume or synthesize)
- Prior content is valuable but fragmented across many formats and conversations.
- A practical guide is more useful for most listeners than a purely theoretical overview.
- The episode is intentionally structured to tell a cohesive story rather than repeat isolated insights.
- The goal is to reduce cognitive overhead for listeners trying to apply the information.

**Intent and tone going forward**

- The episode is designed to synthesize, not replace, previous discussions.
- The emphasis is on clarity, practicality, and application.
- The conversation is meant to guide listeners toward actionable understanding.
- The episode sets the stage for a deep dive into training principles rather than surface-level advice.

## Why cardiorespiratory fitness and VO₂ max are powerful and modifiable predictors of all-cause mortality compared with other health metrics [A: 7:30, V: 5:55]

**Why cardiorespiratory fitness is foundational to lifespan and healthspan**

- Cardiorespiratory fitness is one of the most important modifiable predictors of both how long you live and how well you live.
- Modifiable predictors matter most because they represent levers individuals can actually act on.
- When examining predictors of all-cause mortality, [cardiorespiratory fitness outperforms every other commonly measured variable](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428).
- Cardiorespiratory fitness exceeds blood pressure, cholesterol, BMI, smoking status, and even chronological age as a predictor of mortality.
- Cardiorespiratory fitness reflects how efficiently the heart, lungs, blood vessels, and muscles work together to deliver and utilize oxygen.
- Greater efficiency in this system translates to greater physiologic reserve.
- Physiologic reserve determines the body’s ability to tolerate stressors such as infections, surgery, and everyday physical demands.

⇒ Check out this article by Peter: [The [almost] unbelievable effects of a high maximal aerobic capacity on all-cause mortality](https://peterattiamd.com/all-things-vo2-max/)

**VO₂ max as the primary measurement of cardiorespiratory fitness**

- Cardiorespiratory fitness has most often been measured using VO₂ max.
- VO₂ max represents the maximum rate at which the body can utilize oxygen during maximal exercise.
- VO₂ max is expressed as milliliters of oxygen per kilogram of body weight per minute.
- VO₂ max can also be expressed in metabolic equivalents (METs).
- One MET is defined as 3.5 milliliters of oxygen per kilogram per minute.
- VO₂ max and METs are commonly used interchangeably in the scientific literature.
- The popularity of VO₂ max stems from its standardized nature, which makes it easier to study and compare across populations.
- Standardization does not guarantee accuracy, as VO₂ max testing can be performed incorrectly.
- Consistent and accurate VO₂ max measurement depends heavily on proper protocols and trained technicians.
- The heavy reliance on VO₂ max and METs in the literature contrasts with zone 2, which is harder to define and standardize.

**Why zone 2 is harder to define than VO₂ max**

- VO₂ max is a maximal effort, making it relatively straightforward to elicit during testing.
- Maximal effort testing is conceptually simple because it requires pushing until exhaustion.
- Zone 2 represents an intermediate intensity rather than a maximal one.
- Intermediate intensities are inherently harder to define, measure, and reproduce consistently.

**VO₂ max, quartiles, and mortality risk**

![](https://peterattiamd.com/wp-content/uploads/2026/01/f1-ama79.png)

**Figure 1.** Adjusted hazard ratios (HRs) for comorbidities and between performance groups. Error bars indicate 95% CIs. [[Mandsager et al.](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428)]

- Individuals in the bottom 20–25% of the population for VO₂ max have a [four- to five-fold](https://pmc.ncbi.nlm.nih.gov/articles/PMC6324439/#_ad93_) higher annual risk of all-cause mortality compared to those in the top 2–3%.
- This represents a dramatic gradient in mortality risk across fitness levels.
- Even modest improvements in VO₂ max produce large benefits.
- Moving from the second quartile to the third quartile is associated with a 50–75% reduction in all-cause mortality risk.
- Meaningful health benefits do not require elite-level VO₂ max values.

**Why VO₂ max is such a powerful predictor**

- VO₂ max is an integrator of long-term work rather than a single isolated variable.
- Improving VO₂ max requires sustained effort over years and hundreds of hours.
- Adaptations must occur across multiple systems simultaneously.
  - Cardiovascular system
  - Pulmonary system
  - Hematologic system
  - Muscular system
  - Metabolic system
- Improvements in VO₂ max reflect coordinated, system-wide physiological adaptation.
- This type of adaptation is fundamentally different from modifying a single biomarker with medication.
- Pharmacologic improvements in markers like cholesterol can improve outcomes but generally do not match the magnitude of benefit seen with improved cardiorespiratory fitness.
- Certain edge cases exist, such as familial hypercholesterolemia, where medication has an outsized benefit.
- In the general population, interventions that improve cardiorespiratory fitness and strength exert some of the largest effects on mortality risk.

## How age-related declines in VO₂ max constrain healthspan and everyday physical function [A: 12:30, V: 11:40]

**Healthspan versus lifespan**

- The relationship between cardiorespiratory fitness and healthspan is just as strong as its relationship with lifespan.
- Healthspan is inherently less objective than mortality because it depends on individual goals and values.
- What defines good healthspan varies from person to person.
- Functional aspirations differ across individuals, even at the same age.

**Age-related decline in VO₂ max**

- VO₂ max declines in a relatively predictable manner with aging.
- The typical rate of decline is approximately [10% per decade](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428).
- This decline occurs regardless of individual preferences or goals.

![](https://peterattiamd.com/wp-content/uploads/2026/01/f2-ama79.webp)

**Figure 2.** How VO2 max declines with age and its relation to every-day tasks. Image credit: [Jayson Gifford](https://x.com/jaysongifford/status/1572279059371151361)

**Mismatch between capacity and demand**

- The oxygen cost of everyday activities does not decrease with age.
- Activities such as climbing stairs, lifting objects, playing sports, or chasing children require the same oxygen demand over time.
- As aerobic capacity declines while task demands remain constant, a crossover point is eventually reached.
- Once capacity falls below demand, individuals lose the ability to perform those activities.
- Loss of function emerges not suddenly, but as a consequence of shrinking physiologic reserve.

**Preserving physical optionality**

- The core objective of training is to preserve optionality around physical activity.
- Maintaining higher aerobic capacity delays the point at which functional loss occurs.
- Preserving healthspan requires maintaining as high a VO₂ max as possible.
- You also need to be strong: Strength and VO₂ max together determine long-term physical independence.

> “*Our objective is to be able to maintain optionality around being physical for as long as possible, and that is tantamount to having as high a VO2 max as possible, in addition to being as strong as possible*.” —Peter Attia

## The cardiorespiratory fitness triangle: how different training intensities contribute to building the aerobic base, the aerobic peak, and overall aerobic capacity [A: 14:15, V: 13:25]

**The cardiorespiratory fitness triangle**

- Cardiorespiratory fitness can be conceptualized as a triangle with a base and a peak.
- The base represents the ability to sustain submaximal effort for long durations.
  - The base reflects activities that can be maintained for hours.
- The peak represents maximal aerobic output.
  - The peak reflects efforts that can be sustained for roughly five to ten minutes.
- Between the base and the peak are intermediate intensities, such as functional threshold power, which reflects what can be sustained for about an hour.
- Total aerobic capacity is best represented by the total area of the triangle.
- Maximizing aerobic fitness **requires both a wide base and a high peak.**
- Building the base and raising the peak require different training emphases.

> “The goal here—if you’re trying to maximize your total aerobic capacity—is to maximize the area of this cardiorespiratory triangle. And of course to do that, you want to have the widest base and the highest peak possible, and these require different forms of training.” —Peter Attia

**Training at a single intensity**

- Training exclusively at one intensity level will improve both base and peak if enough volume is performed.
- Single-intensity training is not the most effective or time-efficient way to maximize aerobic capacity.
- High-level endurance athletes do not train at a single intensity.
- Optimizing aerobic fitness requires deliberate variation in training intensity.

**Physiology of the aerobic base**

- The aerobic base is built through adaptations that improve oxygen utilization efficiency.
- Base-focused training enhances the conversion of fuel into ATP.
- Fat is the primary fuel optimized during base development.
- Base adaptations increase mitochondrial density and efficiency.
- Base training improves:
  - Fat oxidation, and
  - Lactate utilization.

**Physiology of the aerobic peak**

- The peak reflects VO₂ max and represents the ceiling of aerobic capacity.
- Peak performance is limited primarily by oxygen delivery rather than utilization.
- Oxygen delivery to mitochondria is the primary bottleneck at VO₂ max.
- Peak adaptations are driven by the body’s ability to transport oxygen efficiently.

**Determinants of oxygen delivery**

- 1) Oxygen delivery depends on diffusion from the lungs into the bloodstream.
- 2) Oxygen delivery depends on cardiac output (heart rate and stroke volume)
- 3) Oxygen delivery depends on the oxygen-carrying capacity of blood, primarily hemoglobin.
- 4) Oxygen delivery depends on the muscle’s ability to extract oxygen.
- **Main driver**: Cardiac output (stroke volume + heart rate) is the [dominant determinant](https://pubmed.ncbi.nlm.nih.gov/10647532/) of VO₂ max.
  - Stroke volume (how much blood comes out of the heart with each pump) is the [most important contributor](https://pubmed.ncbi.nlm.nih.gov/10647532/) to cardiac output
  - Maximum heart rate is reached during VO₂ max efforts.
  - Between 70% and 85% of the variability in VO₂ max is explained by cardiac output alone.

**Clarifying misconceptions about training**

- The idea that zone 2 exclusively builds the base and high-intensity training exclusively builds the peak is an oversimplification.
- Zone 2 training alone will widen the base and also raise the peak.
- High-intensity training alone will raise the peak and also widen the base to a lesser degree.
- Base and peak systems interact rather than operate independently.
- The key training question is how to optimally allocate time across intensities.
- Total training volume is the single biggest determinant of cardiorespiratory adaptation.
- Optimizing training requires solving a balance between volume, intensity, and recoverability.
- This balance represents a practical min-max problem rather than a single formula.

## The cellular mechanics of cardiorespiratory fitness: mitochondria, lactate, muscle fiber recruitment, and intensity thresholds [A: 18:45, V: V: 18:50]

**Why cellular mechanisms matter for zone 2**

- Terms like fat oxidation, mitochondria, and lactate are often misunderstood or reduced to buzzwords.
- Understanding these concepts helps explain why different exercise intensities produce different adaptations.
- A basic cellular framework makes zone 2 and higher-intensity work easier to interpret.

**Mitochondria and ATP production**

- Mitochondria are the primary site of ATP production in cells.
- ATP is the body’s energy currency.
- Energy is released when ATP donates one of its phosphate groups.
- Sustained cardiorespiratory work depends largely on mitochondrial ATP production.

**Fuel pathways and metabolic trade-offs**

- ATP can be generated from fatty acids or from pyruvate.
- Pyruvate is produced from glucose through glycolysis.
- Both fat and glucose metabolism occur at all times, with the balance shifting by intensity.
- Oxidative metabolism produces more ATP per unit of fuel but at a slower rate.
- Glycolysis produces ATP much faster but with lower efficiency.
- As energy demand rises, the body sacrifices efficiency to increase ATP delivery speed.
- This shift allows higher output but cannot be sustained indefinitely.

**Muscle fiber recruitment by intensity**

- At lower intensities, work is dominated by slow-twitch fibers (type I):
  - These fibers are slow to fatigue and well suited for endurance.
  - They contain a high density of mitochondria.
  - They excel at fat oxidation and efficient ATP production.
- As intensity increases, fast-twitch fibers (type II) are progressively recruited:
  - These fibers generate more force but fatigue more quickly.
  - They contain fewer mitochondria.
  - They rely more heavily on glycolysis occurring outside the mitochondria.

**Lactate production and local recycling**

- Lactate is a normal byproduct of glycolysis and is not inherently harmful.
- Lactate produced in fast-twitch fibers can be transported to neighboring slow-twitch fibers.
- In slow-twitch fibers, lactate is converted back into pyruvate.
- Pyruvate then enters the mitochondria for oxidative ATP production.
- This process is known as the lactate shuttle.
- At lower intensities, lactate production and clearance remain balanced locally.
- Blood lactate may stay low even while local lactate production increases.

⇒ Check out the [episode with George Brooks](https://peterattiamd.com/georgebrooks/) for more on lactate

**Systemic lactate clearance**

- As output increases, local mitochondrial clearance becomes insufficient.
- Excess lactate spills into the bloodstream.
- Other tissues begin clearing lactate systemically:
  - The heart can use lactate as fuel.
  - Inactive muscles can oxidize lactate.
  - The brain can utilize lactate for energy.
  - The liver can convert lactate back into glucose via gluconeogenesis.
- These processes establish a new steady-state blood lactate level.

**First lactate threshold and zone 2**

- The first lactate threshold occurs when lactate becomes detectable in the blood.
- At this point, systemic clearance matches systemic production.
- In metabolically healthy and flexible individuals, this occurs around 2 millimoles of lactate.
- This threshold corresponds to zone 2.
- Metabolic flexibility reflects the ability to shift between fat and glucose utilization.
- In metabolically inflexible individuals, resting lactate may already exceed this level.

**Higher lactate thresholds and fatigue**

- At higher intensities, lactate production overwhelms systemic clearance.
  - See [episode with Olav Aleksander Bu](https://peterattiamd.com/olavaleksanderbu/)
- Blood lactate rises rapidly beyond this point.
- Rising lactate is accompanied by hydrogen ion accumulation.
- Hydrogen ions, not lactate itself, impair muscle function.
- Increased acidity interferes with actin-myosin relaxation.
- For most people, this threshold occurs around 4–5 millimoles of lactate.
- The exact value varies significantly between individuals.

## The debate over whether zone 2 training has unique benefits or whether higher-intensity exercise alone is sufficient [A: 27:15, V: 28:33]

**Framing the zone 2 versus high-intensity debate**

- The value of zone 2 versus high-intensity training depends heavily on context.
- Much of the confusion comes from treating zone 2 as either uniquely special or completely unnecessary.
- High-intensity training can produce equal or greater adaptations in certain frameworks.
- The shorter someone’s available training time, the stronger the case for prioritizing high-intensity work.

**Time availability as the primary constraint**

- Maximizing aerobic capacity ultimately depends on training volume.
- Walking or very low-intensity activity does not provide sufficient stimulus.
- Zone 2 represents the first intensity where meaningful aerobic adaptations begin.
- When training time is abundant, how volume is distributed across intensities becomes important.
- With very high weekly training volumes, nuanced intensity distribution matters more.

**Implications of general exercise guidelines**

- Public health guidelines recommend approximately 150 minutes of total exercise per week.
- Most people do not consistently meet this minimum threshold.
- At this level of time constraint, zone 2 alone is not an efficient use of limited training time.
- Total exercise time must also include resistance training.
- After accounting for resistance training, remaining cardio time is often very limited.
- Under these constraints, higher-intensity cardio is more effective for driving adaptation.
- Training programs should be explicitly tailored when total weekly time is restricted.

**Long-term optimization versus minimum adherence**

- Recommendations change when the goal shifts from minimum compliance to long-term optimization.
- Achieving maximal healthspan and lifespan benefits requires more than 150 minutes per week.
- Greater training volume necessitates the use of multiple intensity zones.
- Zone 2 occupies a unique position where lactate enters the bloodstream but remains systemically manageable.
- This intensity level stresses the system enough to recruit glycolytic fibers without overwhelming clearance.
- Fatigue remains low enough to allow prolonged and repeatable sessions.

**Why zone 2 dominates high-volume training**

- Endurance athletes training 15–20 hours per week spend the majority of time in zone 2.
- Lower intensity allows accumulation of large volumes without excessive fatigue.
- Even though per-minute stimulus is lower than zone five, total adaptive load can be higher.
- Zone 2 activates both fat oxidation and glycolytic pathways.
- Lactate is produced and shuttled without triggering the severe fatigue associated with higher intensities.
- Training volume can be accumulated safely and consistently at this intensity.

**Additional benefits of zone 2**

- Zone 2 improves movement efficiency, particularly relevant for athletes. (There are other benefits to zone 2, by the way, if you’re an athlete, which is it comes with the benefits of [improved movement efficiency](https://peterattiamd.com/olavaleksanderbu/))
- Improved efficiency reduces energetic cost at submaximal workloads.
- This contributes to better endurance performance over long durations.

## Balancing intensity and sustainability as training volume increases, and the important role of zone 2 training [A: 32:15, V: 34:20]

**Shifting constraints as training time increases**

- Once training time exceeds the minimum 150 minutes per week, different constraints emerge.
- Fatigue, recoverability, and adherence become the primary limiting factors.
- These constraints become more pronounced with age.
- What is tolerable in the 20s and 30s becomes harder to sustain in the 40s and 50s.

**Role of high-intensity training**

- High-intensity work, including zone five efforts, remains essential.
- The total amount of high-intensity work that can be tolerated declines with age.
- Performing high-intensity sessions three or four times per week is unrealistic for most middle-aged adults.
- Excessive reliance on high intensity increases fatigue and injury risk.

**Volume as the main driver of adaptation**

- Training volume is the dominant driver of aerobic adaptation.
- Volume only produces meaningful benefits when performed at sufficient intensity.
- Zone 2 represents the minimum intensity where key aerobic adaptations begin.
- Below this threshold, increasing volume alone is insufficient.

**Why lower-intensity work enables higher volume**

- High-intensity training carries a higher physiologic cost.
- This cost includes greater fatigue, longer recovery time, and increased burnout risk.
- Sustaining higher volumes requires operating at a lower physiologic cost per session.
- Zone 2 allows accumulation of substantial training volume without overwhelming recovery systems.

**Adherence and sustainability**

- High-intensity work is more painful and mentally demanding.
- Greater discomfort reduces long-term adherence for many people.
- Zone 2 training is easier to sustain psychologically.
- Lower cognitive demand allows activities like listening to podcasts or audiobooks.
- This makes zone 2 more compatible with long-term consistency.

**Reframing the zone 2 critique**

- Critics are correct that high-intensity training delivers greater adaptation per unit time.
- This advantage becomes less relevant as total training volume increases.
- Zone 2 is not valuable because it is special or magical.
- Its value lies in practicality and sustainability.
- Zone 2 enables consistent, high-volume training across years and decades.
- This makes it foundational for long-term athletic capacity and health.

## How to identify your zone 2 training intensity [A: 34:45, V: 37:25]

**Lab-based measurement of zone 2**

- Blood lactate testing is the most precise way to identify zone 2 in metabolically flexible individuals.
- Zone 2 corresponds to the first systemic lactate threshold, where lactate production and clearance are balanced.
- Metabolically healthy individuals typically have resting lactate around 0.4–0.6 mmol.
- During exercise, zone 2 is usually reached at approximately 2 mmol of lactate in these individuals.

*Limitations of lactate testing*

- Metabolically inflexible individuals may have resting lactate at or above 2 mmol.
- Elevated resting lactate reflects heavy reliance on glycolysis even at rest.
- Insulin resistance often corresponds with a high respiratory quotient near 0.95–1.0.
- In these cases, lactate testing is not useful for defining zone 2.
- For most patients, lactate testing is unnecessary unless they want a highly detailed, technical assessment.

**Practical zone 2 identification without lab testing**

- Zone 2 is best identified by combining one objective and one subjective measure.
  - Heart rate provides the objective anchor.
  - Rate of perceived exertion provides the subjective anchor.

*Heart rate as a starting point*

- A commonly used estimate is the [Maffetone formula](https://philmaffetone.com/180-formula/): 180 minus age.
  - See [episode with Phil Maffetone](https://peterattiamd.com/philmaffetone/)
- Adjustments are made based on training status and health:
  - Subtract 10 for illness or severe deconditioning.
  - Subtract 5 for inconsistent training.
  - Use the base number for regular training.
  - Add 5 for consistent training with performance goals.
  - Add 10 for very high fitness.
- This approach can result in a wide heart rate range, sometimes spanning 20 beats per minute.
- Day-to-day zone 2 heart rate can vary by approximately 10 beats even in trained individuals.
- Heart rate alone is therefore an imperfect tool.

*Rate of perceived exertion as the primary guide*

- Perceived exertion becomes more reliable with practice.
- The simplest heuristic is the “talk test.”
  - Zone 2 allows speaking in full sentences but without comfort.
  - Inability to finish sentences indicates intensity above zone 2.
  - Effort that allows easy, relaxed conversation indicates intensity below zone 2.

**Refining effort using the RPE scale**

- RPE 4: breathing is steady, conversation is easy, and effort could be sustained for hours.
- RPE 5: breathing deepens but remains controlled, conversation is possible but uncomfortable, and effort can be held for 90–120 minutes.
- RPE 6: conversation becomes fragmented, breathing is heavy, and effort can only be sustained for 30–40 minutes.
- Zone 2 corresponds most closely to RPE 5.
- RPE 4 and 6 define the lower and upper boundaries.
- Heart rate can guide initial targeting, but RPE ultimately determines accuracy.

## How to measure and track improvements in zone 2 fitness [A: 40:00, V: 43:10]

**What improvement in zone 2 actually means**

- Improvement is defined by producing more external work while staying at the same zone 2 heart rate and perceived exertion.
- The goal is not to push harder, but to push more efficiently at the same physiologic threshold.

**Preferred modalities for tracking progress**

- Bikes and treadmills are ideal because they allow steady, uninterrupted work.
- These modalities make it easier to quantify output precisely.

**How to track progress by modality**

- On a bike:
  - Wattage is the primary metric.
  - Progress is reflected by higher watts at the same heart rate and RPE.
- On a treadmill:
  - Speed and grade are the key variables.
  - A consistent walking speed is recommended for most people, typically around 3.3–3.6 mph.
  - Grade is then adjusted upward over time to increase workload.
- Improvement is shown by sustaining higher grades at the same zone 2 effort.

**Why zone 2 performance reflects mitochondrial health**

- Zone 2 output is a direct proxy for mitochondrial efficiency and density.
- Improvements indicate:
  - Greater fat oxidation capacity.
  - Better lactate clearance.
  - Enhanced metabolic flexibility.
- Increases in zone 2 performance are driven more by improved lactate clearance than reduced lactate production.

**Mechanisms behind lactate clearance improvements**

- Adaptations involve increased expression of monocarboxylate transporters (MCTs).
- These transporters shuttle lactate into mitochondria for oxidation.
- Improved lactate shuttling allows sustained work at higher outputs without accumulating fatigue.

*Example benchmarks for zone 2 performance (cycling)*

- Metrics are best expressed as watts per kilogram to normalize for body weight.
- Approximate reference points:
  - Type 2 diabetes: <1.0 W/kg.
  - Recreational cyclist: ~2.5 W/kg.
  - Very strong amateur cyclist: ~3.8–4.0 W/kg.
  - Elite professional cyclist: ≥5.0 W/kg.
- These values illustrate the wide range of mitochondrial function across populations.

**How to interpret benchmarks**

- Absolute numbers matter far less than direction of change.
- The key question is whether watts, speed, or grade are increasing over time at the same physiologic effort.
- Progress should be gradual and sustained, not forced.

**Elite example for context**

- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) can reportedly sustain ~330–340 watts for hours at zone 2.
- Given his body weight, this equates to roughly 5.5–5.7 W/kg.
- This level of performance reflects extreme mitochondrial capacity and aerobic efficiency.
- The example is meant to illustrate human potential, not set expectations.

⇒ see [episode with Tadej Pogačar](https://peterattiamd.com/tadejpogacar/)

**Primary takeaway**

- Zone 2 progress is about steadily raising the ceiling of sustainable work.
- The correct focus is long-term upward trends, not comparison to others.
- Consistent training that nudges these numbers higher over months and years is the real objective.

## How to accurately measure VO₂ max: lab testing, field tests, and the limits of wearables [A: 45:15, V: 49:12]

**Gold standard measurement of VO₂ max**

- The only definitive way to measure VO₂ max is through indirect calorimetry performed during a maximal exercise test
- Indirect calorimetry directly measures oxygen consumption and carbon dioxide production rather than estimating them.
- The test is typically conducted in a laboratory using either a treadmill or stationary bike.
- A sealed mask ensures that all inhaled and exhaled gases pass through sensors.
- Oxygen and carbon dioxide concentrations are sampled frequently as exercise intensity increases.
- VO₂ max is calculated from the difference between inhaled and exhaled oxygen.
- Carbon dioxide measurements are required to determine fuel partitioning.
- These tests are widely available and are usually about $150–$300 and can be done at universities, hospitals, sports medicine clinics, and some fitness centers.

**Importance of testing protocol quality**

- Test accuracy depends heavily on proper execution and technician experience.
- Adequate warm-up is required to ensure the body is physiologically prepared.
- A protocol that truly takes the individual to exhaustion is necessary for valid results.
- A roughly 15-minute warm-up before the ramp portion helps stabilize physiology.
- A short rest before the final ramp test can improve test reliability.
- Variability between labs is one reason some clinics choose to perform testing in-house.

⇒ check out [Olav Aleksander Bu’s second appearance](https://peterattiamd.com/olavaleksanderbu2/) on the podcast for more

**Field-based alternatives when lab testing is not available**

*Cooper test:*

- The most validated self-administered alternative is the [Cooper test](https://www.verywellfit.com/fitness-test-for-endurance-12-minute-run-3120264) which estimates VO2 max based on the distance covered in 12 minutes using a validated equation
- The Cooper test involves a 12-minute all-out run after a proper warm-up.
- Total distance covered is entered into a validated equation to estimate VO₂ max.
  - **For kilometers**: VO2max = (22.351 x kilometers) – 11.288
  - **For miles**: VO2max = (35.97 x miles) – 11.29
  - Here’s an [online 12-minute test results calculator](https://exrx.net/Calculators/MinuteRun)
- This test has one of the highest correlations with lab-measured VO₂ max.

*A cycling-based alternative—the* [*revised Ekblom-Bak protocol*](https://pubmed.ncbi.nlm.nih.gov/27311582/):

- A cycling-based alternative uses an ergometer with progressively increasing resistance.
- Cycling tests estimate VO₂ max by maintaining a fixed cadence as resistance increases.
- These field tests are reliable enough for reproducible tracking when lab access is limited.

**Limitations of wearable-based VO₂ max estimates**

- Wearables do not measure VO₂ max and instead generate algorithmic estimates.
- Gas exchange cannot be inferred accurately without direct oxygen and carbon dioxide measurement.
- Algorithms rely on heart rate, pace, power, and demographic variables rather than physiology.
- Wrist-based optical heart rate sensors introduce significant measurement noise.
- Heart rate accuracy is affected by strap tightness, sweat, skin contact, and movement.
- Small errors matter because meaningful VO₂ max changes are often only 5–10%.
- Wearables usually do not allow users to initiate a true maximal VO₂ max test.
- Estimates are often derived from submaximal outdoor workouts rather than controlled tests.
- Frequent zone 2 training can artificially depress wearable VO₂ max estimates.
- Individual devices can differ by 10–20 points in reported VO₂ max.
- Wearable-derived VO₂ max values are not reliable for absolute measurement or trending.

## How to set meaningful VO₂ max targets based on age, sex, long-term decline, and desired physical capabilities later in life [A: 51:15, V: 56:10]

**How to think about VO₂ max goals**

- The most appropriate goal for VO₂ max is to make it as high as possible within the time and effort someone is willing to devote to training.
- There is no meaningful downside to being fitter, stronger, or having a higher VO₂ max.
- VO₂ max inevitably declines with age, while the oxygen cost of daily activities remains constant.
- A higher starting VO₂ max provides more physiologic reserve as aging progresses.

**Minimum and aspirational benchmarks**

- The absolute **minimum target** is to be in the top quartile for age and sex.
- The **preferred target** is to reach the top 1–2% for age and sex.
- For highly motivated individuals, the goal is to reach the top 1–2% of people who are two decades younger.
- Achieving elite fitness relative to a younger cohort provides long-term protection against functional decline.
- Being in the top 1–3% for age and sex is sufficient for nearly all activities across the lifespan.

![](https://peterattiamd.com/wp-content/uploads/2026/01/f3-ama79-performance-group-by-vo2-max.png)

**Figure 3.** Performance group by vo2 max. Classification of Cardiorespiratory Fitness by Age and Sex reproduced from [Mandsager et al.](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428) Subjects (n=122,007) were patients undergoing stress testing at the Cleveland Clinic between the years 1991–2014. VO2 max in ml/kg/min of oxygen consumption, estimated with METS: metabolic equivalents, with 1 MET equaling 3.5 ml/kg/min of oxygen consumption. Classification (percentile range) is as follows: low (<25th percentile), below average (24th-49th percentile), above average (50th-74th percentile), high (75th-97.6th percentile), and elite (≥97.7th percentile).

**Planning for long-term decline**

- VO₂ max declines predictably over time, even with consistent training.
- Training intensity and volume can alter the slope of decline.
- Periods of inactivity or injury accelerate the rate of decline.
- Planning should account for future loss of capacity rather than current performance.
- Targets should be set based on desired abilities in later decades of life, not just present-day function.

**Using modeled projections to guide goals**

![](https://peterattiamd.com/wp-content/uploads/2026/01/f4-ama79-decline-with-desired-activity.png)

**Figure 4.**

- Age is plotted on the x-axis and VO₂ max on the y-axis to model future decline.
- Individual VO₂ max values are placed on percentile curves based on age and sex.
- These models show when specific physical abilities are likely to be lost.
- Increasing VO₂ max earlier in life shifts the entire curve upward.
- A meaningful increase in VO₂ max can preserve functional abilities for many additional years.
- Raising VO₂ max from a moderate level to a higher level is achievable within 12–18 months with consistent training.

**Linking VO₂ max to real-world activities**

![](https://peterattiamd.com/wp-content/uploads/2026/01/f5-ama79-example-decline-with-age-and-common-activities.png)

**Figure 5.** Example decline in VO2 max with age, as related to VO2 required for common activities. Reproduced from [Mandsager et al.](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428) and the 2024 Compendium of Physical Activities.

- Specific activities have minimum VO₂ max requirements to be performed at all.
- Higher VO₂ max thresholds are required to perform activities comfortably or at a high level.
- Planning involves matching desired future activities with the VO₂ max needed to sustain them.
- Maintaining higher VO₂ max preserves optionality and independence later in life.

**The concept of the marginal decade**

- Quality of life declines once VO₂ max falls below certain thresholds.
- For some individuals, meaningful functional loss begins when VO₂ max drops below 30 ml/kg/min.
- This threshold is personal and depends on individual goals and values.
- Longevity planning requires deciding how long one might live and working backward from that endpoint.
- Similar to financial retirement planning, physiologic capacity must be budgeted over time.

**Personal framing and motivation**

- Maintaining a VO₂ max above age in ml/kg/min can serve as a motivating benchmark.
- Tracking the point at which VO₂ max drops below chronological age can be gamified.
- Training capacity decreases with age, but sufficient adaptation remains possible well into later decades.
- Early and sustained effort makes long-term preservation far more achievable.

## How to structure and execute a zone 2 workout [A: 59:45, V: 1:05:53]

**Starting a zone 2 training practice**

- Zone 2 sessions can be implemented without lactate testing by using heart rate targets derived from the Maffetone formula and rate of perceived exertion (RPE).
- A practical starting point for people new to cardiorespiratory training:
  - Three 30-minute sessions per week.
  - This volume is sufficient to produce meaningful adaptations in individuals who are deconditioned or new to endurance work.
  - This approach is also valuable for people who previously focused only on high-intensity training and are willing to increase total training time.

**Progressing volume over time**

- Session duration can be increased gradually as zone 2 work becomes more manageable.
- Sessions can progress from 30 minutes to 45 minutes and eventually to 60 minutes.
- Once sessions reach approximately 45 minutes, adding a fourth weekly session is reasonable.
- *Progression should prioritize duration* before frequency or intensity.

**Structure of a well-formulated zone 2 session**

- Sessions should begin with a gradual ramp-up to avoid abrupt physiologic stress.
- A typical ramp includes 5-10 minutes of very easy effort.
- This can be followed by a transitional period at slightly below zone 2 before settling into the target intensity.
- The main portion of the workout consists of 30–40 minutes sustained at zone 2.
- The goal is uninterrupted, steady-state work rather than fluctuating intensity.

**Regulating intensity during the session**

- Day-to-day adjustments are expected and normal.
- RPE is often a more reliable guide than heart rate once familiarity with zone 2 is established.
- Heart rate targets provide a reference point but should not override perceived exertion.
- Backing off intensity on days when effort feels higher helps preserve consistency and recovery.
- The ability to adjust intensity supports long-term sustainability rather than rigid adherence to numbers.

**Modality selection for zone 2 training**

- The most important requirement of a modality is the ability to maintain a relatively constant level of exertion.
- Minor fluctuations are acceptable, but frequent interruptions or large intensity swings should be avoided.
- Indoor modalities often work best because they eliminate stops and environmental variability.
- Common effective options include:
  - stationary bikes
  - treadmills with incline
  - stair climbers
  - rowing machines
- Peter’s preference:
  - Peter prefers a bike
  - He uses a program called [Trainer Road](https://www.trainerroad.com/), it’s an ERG and it’s just spitting out the power to the bike on the [Wahoo KICKR](https://www.wahoofitness.com/devices/indoor-cycling/bike-trainers/kickr-buy)

**Individual differences in modality suitability**

- Modality choice depends on movement efficiency and skill.
- Poor technical efficiency in a modality can push intensity above zone 2 even at modest workloads.
- Some individuals can jog in zone 2 comfortably, while others exceed zone 2 at similar speeds.
- Selecting a modality where fatigue accumulates slowly improves adherence and consistency.
- Sport specificity matters, and the best modality is the one that allows steady effort at low physiologic cost.

## How strictly should zone 2 be maintained during a workout? [A: 1:04:00, V: 1:10:54]

**Consistency versus fluctuation in zone 2 sessions**

- The importance of staying strictly in zone 2 depends largely on how much total training time a person has.
- When training volume is very high, occasional excursions above or below zone 2 are less consequential.
- Long endurance sessions can still be effective even if intensity fluctuates, as long as the overall session is clearly an “easy day.”

**How training time changes the need for precision**

- With ample training time, intensity does not need to be managed rigidly minute by minute.
- Short periods above zone 2, such as climbing a hill, do not negate the value of a long endurance session.
- Brief periods below zone 2, such as descents or coasting, are also inconsequential in high-volume contexts.
- The primary consideration in these cases is the average power and heart rate across the entire session.

**The asymmetric nature of zone 2 adaptations**

- Time spent below zone 2 does not meaningfully drive aerobic adaptation.
- Riding well below the zone 2 threshold produces minimal training stimulus, even if done for long periods.
- Time spent above zone 2 continues to produce adaptation, even if lactate production exceeds clearance.
- Higher-than-zone-2 work cannot be sustained indefinitely, but it still contributes to fitness gains.

**How to account for mixed-intensity sessions**

- Outdoor sessions naturally include intensity variability due to terrain and conditions.
- Total training benefit should be evaluated by how much time is accumulated at zone 2 or higher.
- A session with mixed zones can still be effective if a meaningful portion of the time is spent at or above zone 2.
- Volume at or above zone 2 is more important than perfect zone purity.

**Why zone 2 remains foundational**

- Zone 2 allows the accumulation of large training volumes with relatively low fatigue.
- Lower fatigue improves recovery, adherence, and long-term sustainability.
- Staying close to the zone 2 threshold maximizes training stimulus without excessive physiologic cost.
- Indoor training environments make it easier to maintain steady zone 2 effort without interruptions.

**Practical application across training types**

> “*If there’s anything that’s ‘magical’ about zone 2, it is that you can accumulate the most volume with the least fatigue, and therefore the closer you can stay to that threshold in a dedicated workout for it. . .the better off you’re going to be*.” —Peter Attia

- Zone 2 sessions are often best performed indoors to allow precise control of effort.
- High-intensity sessions are better suited to outdoor environments where maximal efforts can be expressed naturally.
- Separating steady zone 2 work from high-intensity work helps optimize both volume and performance.

## How to design a VO₂ max training session: interval length, intensity, recovery, and progression strategies [A: 1:07:00, V: 1:14:30]

**How VO2 max training depends on starting point**

- VO2 max training needs to be tailored to a person’s current fitness level and total available training time.
- Someone limited to 150 minutes per week and with little training history may need to prioritize high-intensity work simply to build basic fitness.
- That scenario differs from someone with an established aerobic base who wants to deliberately raise VO2 max.
- VO2 max–focused training assumes an existing foundation built through lower-intensity aerobic work.

**Core structure of an ideal VO2 max session**

- VO2 max intervals are best performed in the range of roughly 3-8 minutes per effort.
- **A common and effective starting protocol**:
  - Warm up: 10-20 minutes of zone 2 work
  - Four intervals of 4 minutes
  - Each followed by 4 minutes of recovery.
  - Cool down: 5-15 minutes of decreasing effort (zone 2 for a few minutes, then zone 1 for the rest)
    - The goal is to decrease intensity and have HR be under 100-110 bpm by the end of the cool off phase.
- Sessions should always begin with a proper warm-up to avoid premature fatigue and injury.
- A zone 2 warm-up lasting approximately 10–15 minutes prepares the body for maximal work.

*Intensity execution during intervals*

- Each interval should be performed at a constant output from start to finish.
- Effort should feel progressively harder over time despite maintaining the same power or pace.
- The goal is to avoid starting too hard and fading before the interval ends.
- Proper pacing allows sustained exposure to maximal oxygen utilization throughout the interval.

**Physiologic experience during VO2 max intervals**

- Early in an interval, breathing may still feel controlled and partially nasal.
- Midway through, breathing shifts fully to mouth breathing as intensity accumulates.
- Near the end of the interval, discomfort becomes severe even though output remains constant.
- Maintaining steady output despite rising discomfort is central to VO2 max adaptation.

**Recovery between intervals**

- Recovery periods should involve very light but continuous movement rather than complete rest.
- On a bike, recovery power should be extremely low and feel almost effortless.
- On a treadmill or running modality, recovery typically consists of slow walking.
- Active recovery allows partial physiologic reset while preserving session momentum.

**Interval duration trade-offs**

- Shorter intervals require higher intensity but limit total time spent near VO2 max.
- Longer intervals allow slightly lower intensity while accumulating more total high-intensity minutes.
- Total time under VO2 max stress is more important than the number of intervals completed.
- Tracking total minutes at high intensity provides a better metric than counting repetitions.

⇒ In the [podcast with Olav Alexander Bu](https://peterattiamd.com/olavaleksanderbu2/), he talked about one of the advantages of doing slightly longer intervals is you go slightly lower intensity but you can accumulate a little bit more volume.

**Progression strategy over time**

- Initial *progress should come from adding intervals* rather than increasing weekly frequency.
- Increasing volume within a session improves adaptation before adding another VO2 max day.
- Once tolerance improves, a second VO2 max session per week can be introduced cautiously.
- Training should always be adjusted based on measurable improvements in output.

**Time-efficient modifications for constrained schedules**

- A full VO2 max session can be completed in roughly one hour including warm-up and cooldown.
- When weekly training time is extremely limited, shorter intervals can be used to fit multiple sessions.
- One-minute-on, one-minute-off intervals allow high-intensity exposure within tight schedules.
- VO2 max training can be scaled to nearly any time budget while preserving effectiveness.

## Why heart rate is not a reliable metric for titrating VO₂ max interval intensity [A: 1:12:00, V: 1:20:23]

**Using heart rate to guide VO2 max intervals**

- Heart rate should not be used to titrate or control VO2 max intervals.
- Relying on heart rate during VO2 max work leads to systematic misinterpretation of effort.

**Lag between heart rate and metabolic demand**

- Heart rate responds with a meaningful delay relative to metabolic intensity.
- VO2 max intensity is reached before heart rate climbs into traditional zone 5 ranges.
- By the time heart rate reaches 90–95% of maximum, the athlete has already been operating at VO2 max for a significant portion of the interval.
- Heart rate lag can be on the order of two to three minutes during hard intervals.

**Consequences of chasing heart rate**

- Using heart rate as the primary guide can make it seem like intervals are too short or ineffective.
- Athletes may incorrectly believe they are failing to reach VO2 max intensity.
- This misunderstanding can lead to unnecessary changes in interval duration or intensity.
- The result is confusion about whether training is actually working.

**Distinguishing zone 5 from VO2 max**

- Zone 5 is a heart rate–based classification.
- VO2 max describes a physiological and metabolic state, not a heart rate zone.
- The two overlap but are not interchangeable.
- Confusing zone 5 heart rate with VO2 max effort leads to poor training decisions.

**Proper way to approach VO2 max intervals**

- VO2 max intervals should be controlled by external workload, not heart rate.
- Power, pace, or resistance should remain constant across the interval.
- Perceived exertion and the ability to sustain output are more reliable guides.
- Heart rate can be observed after the fact but should not drive real-time decisions.

## Practical ways to monitor VO₂ max improvements [A: 1:13:30, V: 1:22:05]

**Practical ways to monitor VO2 max progress between lab tests**

- VO2 max does not need to be formally tested frequently to know whether training is working.
- Day-to-day and week-to-week progress can be tracked using performance metrics from VO2 max intervals.
- The most useful signal is whether external output is increasing at the same interval duration.

**Tracking performance during VO2 max intervals**

- Improvements can be tracked by measuring average wattage during intervals on a bike.
- Improvements can be tracked by measuring pace during intervals when running.
- Any consistent resistance metric can be used as long as it is measured under similar conditions.
- The key question is whether more work is being done at the same interval length over time.

**Heart rate recovery as a secondary indicator**

- Heart rate recovery can provide useful day-to-day feedback about readiness and adaptation.
- Heart rate recovery is measured as the drop in beats per minute during the first 60 seconds after an interval ends.
- Faster heart rate recovery generally correlates with better performance in subsequent intervals.
- Heart rate recovery is directionally useful even if measured during active recovery rather than full rest.

**Limitations of heart rate–based signals**

- Heart rate recovery is not a direct measure of VO2 max.
- Heart rate recovery is influenced by fatigue, hydration, sleep, and overall stress.
- Heart rate recovery should be viewed as supportive information rather than a primary outcome metric.

**Best proxy for VO2 max improvement**

- The strongest practical proxy for VO2 max improvement is the ability to sustain higher power or pace during VO2 max intervals.
- Averaged power across a four-minute interval is one of the closest correlates to VO2 max.
- Improvements in interval output reflect improved oxygen delivery and utilization capacity.

**Aging and heart rate considerations**

- Maximum heart rate tends to decline with age.
- Reduced maximum heart rate contributes meaningfully to age-related declines in VO2 max.
- Achieving higher heart rates during intervals becomes progressively harder over time.
- Performance improvements may still occur even when peak heart rate no longer increases.

## How to balance zone 2 and VO₂ max training [A: 1:15:30, V: 1:24:10]

**Balancing zone 2 and VO2 max training**

- Zone 2 and VO2 max training are complementary and should not be done in isolation.
- The goal is to balance lower-intensity volume with higher-intensity work to build a durable aerobic system.
- The commonly cited 80/20 framework is a guideline, not a rigid rule.
  - 80% zone 2; 20% VO₂ max training

**Factors that determine the ideal split**

- The optimal balance depends heavily on total available training time.
- Age and training history also influence how much high-intensity work can be tolerated.
- Someone training three hours per week will necessarily look very different from someone training 10 or more hours per week.

**Why high-level athletes gravitate toward an 80–20 split**

- Athletes training many hours per week must spend most of that time at zone 2 to manage fatigue.
- Data across endurance sports shows a remarkably consistent pattern of high-level athletes spending the majority of time at zone 2.
- This pattern holds across running, cycling, swimming, and cross-country skiing.
- Attempting to train 20–25 hours per week at higher intensities would be unsustainable due to excessive fatigue.

**Zone 2 is still extremely demanding at elite levels**

- Zone 2 for elite athletes is far more intense than zone 2 for recreational athletes.
- Elite athletes can sustain outputs at zone 2 that most people can only hold briefly.
- The difficulty of zone 2 scales with fitness, even though it remains below maximal effort.
- High volume does not mean easy training, even when intensity is relatively lower.

**Adjusting the split for limited training time**

- For people with limited training time, the classic 80–20 split becomes impractical.
- With only three hours per week, a higher proportion of intensity is required to drive adaptation.
- The split may shift closer to 70–30 or even 60–40 as total volume decreases.
- Practical programming may involve blending intensities within a single session.

**Practical examples for lower-volume training**

- A single workout might include a block of zone 2 followed by zone 3 work.
- Zone 3 can be approximated at roughly 80–85% of maximum heart rate.
- Including zone 3 improves lactate tolerance and increases total effective volume.
- VO2 max intervals can be added at the end of a session without excessive fatigue.
- Combining zone 2 with a small amount of VO2 max work allows meaningful adaptation in limited time.

**Real-world application across weekly training volumes**

- At three hours per week, higher intensity must make up a larger fraction of training.
- In the three-to-six-hour range, the split often fluctuates between 70–30 and 80–20 depending on fatigue.
- At eight hours per week or more, the 80–20 framework becomes increasingly realistic and effective.
- Weekly variability in fatigue should influence how strictly the split is applied.

## How to structure training for someone limited to 150 minutes per week of total exercise [A: 1:19:00, V: 1:28:15]

**Reframing the 150-minute guideline**

- Moving from zero exercise to 150 minutes per week is a major health intervention that will change your life
- Achieving this minimum level of activity is associated with roughly a [15% reduction](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428) in all-cause mortality.
- The goal at this stage is not optimization but consistency and habit formation.
- People following this guideline should not feel discouraged by higher-volume training discussions.

**Overall training priorities at 150 minutes per week**

- Resistance training must be included alongside cardio for long-term health.
  - Muscle mass is critical for metabolic health and physical function, not just aesthetics.
  - Strength and cardiorespiratory fitness should be developed in parallel, even at low volume.

**Recommended weekly structure:**

- Two short, whole-body resistance training sessions per week.
  - Each session can be approximately 30 minutes.
  - The focus is on maintaining or building muscle mass and strength.
- The remaining time should be devoted to cardiorespiratory training.
  - This can be structured as either two days of 45-minute sessions or three days of 30-minute sessions.
  - Choice depends on personal schedule and preference.

**Cardio session framework**

- Each cardio session should begin with a zone 2 warm-up (10-15 minutes) to prepare the aerobic system before higher-intensity work.
- High-intensity intervals should follow the warm-up:
  - Intervals can range from short (2 minutes on, 2 minutes off) to longer (4 minutes on, 4 minutes off).
  - The emphasis is on engaging the correct energy systems rather than maximizing volume.
- Each session should end with a brief 5 minute cool-down.

**Practical flexibility in implementation**

- There is no single “correct” way to divide the time as long as key elements are included.
- The first decision is whether to train cardio two days or three days per week.
- Longer sessions allow more flexibility in warm-up and interval structure.
- Shorter sessions prioritize efficiency and intensity.

**Expected outcomes with consistency**

- When done correctly, this structure can drive large physiologic adaptations.
- Meaningful improvements can occur within six months.
- Individuals following this approach should expect noticeable gains in fitness and resilience.
- The focus should remain on adherence rather than perfection.

## How to allocate 150 minutes per week of dedicated cardiorespiratory training between zone 2 and VO₂ max work [A: 1:23:00, V: 1:32:50]

**Framing the scenario**

- This structure assumes resistance training is already handled separately.
- The full 150 minutes per week are dedicated exclusively to cardiorespiratory training.
- The goal shifts from minimum viability to meaningful aerobic and VO2 max development.
- Time is sufficient to clearly separate zone 2 work from VO2 max work.

**Overall cardio allocation strategy**

- The weekly time should be deliberately split between zone 2 and VO2 max training.
- Zone 2 provides aerobic base and volume with manageable fatigue.
- VO2 max work provides the high-intensity stimulus necessary to raise the ceiling of aerobic capacity.
- A roughly 60/40 split between zone 2 and VO2 max is practical at this volume.

**Zone 2 session structure**

- Two dedicated zone 2 sessions per week.
- Each session should last approximately 40–45 minutes.
- These sessions are steady-state and uninterrupted.
- The primary goal is accumulating quality aerobic volume with low fatigue.
- Slightly shortening these sessions can create more flexibility for VO2 max work elsewhere in the week.

**VO2 max session structure**

- One dedicated VO2 max session per week.
- Total session duration is approximately 60 minutes.
- The goal is to accumulate about 30 minutes of VO2 max work.
- Interval structure options:
  - Five minutes on, five minutes off.
  - Four minutes on, four minutes off.
- Interval selection should prioritize accumulating total time at VO2 max rather than maximizing intensity.
- Adequate warm-up and cool-down are essential and must be included in the total session time.

**Key training emphasis**

- Total time spent at VO2 max intensity matters more than the exact interval format.
- Interval duration can vary as long as the work-to-rest ratio allows sustained output.
- This structure balances aerobic development with high-intensity stimulus without excessive fatigue.
- The plan is simple, repeatable, and scalable as fitness improves.

## How to structure training for someone with substantial available time who wants to maximize cardiorespiratory fitness [A: 1:24:30, V: 1:34:16]

**Framing the “unlimited time” scenario**

- This scenario applies to someone who has significant flexibility and commitment, but not a professional athlete training full-time.
- The goal is maximizing long-term benefit rather than squeezing adaptations into minimal time.
- Fatigue management, sustainability, and balance across training modalities become the primary constraints.

**Overall training philosophy at higher volumes**

- Training should move closer to an 80/20 distribution, with the majority of time spent in zone 2.
- The exact split does not need to be rigid, but zone 2 becomes the dominant foundation.
- Higher volumes allow for aerobic gains without excessive physiological or psychological stress.

**Zone 2 training structure**

- Approximately three zone 2 sessions per week.
- Session duration can vary based on availability and tolerance:
  - Shorter sessions around 45 minutes.
  - Longer sessions extending up to 90 minutes.
- The primary objective is accumulating substantial aerobic volume with minimal fatigue.
- Zone 2 sessions should remain steady-state and predictable.

**VO2 max and interval training structure**

- One to two interval days per week, depending on fatigue, travel, and life stress.
- At least one dedicated VO2 max session is considered non-negotiable.
  - The goal is accumulating roughly 30 minutes of very high-intensity work.
- A second interval day can be added if recovery allows.
  - This session may differ in modality or interval duration.
  - Examples include mixing swimming and cycling or varying interval lengths.
- Total VO2 max work across the week may reach 40–45 minutes when volume is higher.

**Variation and modality selection**

- Intervals can be diversified to reduce monotony and overuse.
- Mixing modalities can help distribute mechanical stress while preserving metabolic stimulus.
- Interval duration can vary between shorter efforts (e.g., two minutes) and longer efforts (e.g., five minutes).

**Integration with resistance training**

- Resistance training is assumed to be part of the program.
- A minimum of two resistance training sessions per week is recommended.
- Three sessions may be appropriate when time allows and recovery is adequate.
- Strength training supports metabolic health, resilience, and long-term function.

**Example weekly structure**

- Resistance training and endurance training are alternated to manage fatigue.
- A sample structure might include:
  - Resistance training on multiple weekdays.
  - Zone 2 sessions interspersed between strength days.
  - Interval training placed on a day with adequate recovery before and after.
- Stability or mobility work can be layered into lighter aerobic days.

## Why spreading aerobic training across the week beats compressing volume into one session [A: 1:26:15, V: 1:36:25]

**Central question: single long session vs. multiple shorter sessions**

- A common question in aerobic training is whether it is better to concentrate volume into one long session or distribute it across multiple days.
- This question applies regardless of total weekly training time, including zone 2–focused programs.

**Primary driver: total weekly volume**

- Total weekly aerobic volume is likely the largest driver of aerobic and mitochondrial adaptation.
- Accumulating sufficient volume remains the first-order priority for improving aerobic fitness.

**Importance of training frequency**

- Spreading training across multiple days is generally superior to concentrating all volume into a single day.
- *Frequency of aerobic stimulus plays an independent role beyond total volume*.
- Multiple training bouts provide repeated biological signals that promote adaptation.

**Molecular mechanism underlying frequency benefits**

- Each aerobic training session triggers a temporary rise in mRNA for PGC-1α.
- PGC-1α functions as a master regulator of mitochondrial biogenesis.
- The increase in PGC-1α mRNA persists for roughly [24 hours](https://pmc.ncbi.nlm.nih.gov/articles/PMC3010147/) following a training bout.
- This window corresponds to increased signaling for mitochondrial development and adaptation.

**Implications for weekly structure**

- Distributing aerobic sessions across the week allows repeated activation of mitochondrial biogenesis pathways.
- Even if total weekly volume is matched, spreading sessions may lead to greater cumulative adaptation.
- This suggests a second-order benefit of frequency layered on top of total volume.

**Practical takeaway**

- When possible, aerobic training should be spread across multiple days rather than consolidated into a single long session.
- This approach maximizes both total training stimulus and the number of adaptive signaling events across the week.

## How beginners and metabolically unhealthy individuals should start cardiorespiratory training safely [A: 1:28:00, V: 1:38:18]

**Starting cardiorespiratory training for beginners and metabolically unhealthy individuals**

*Core principle: sustainability and adherence*

- The primary objective at the beginning is to create a routine the person will actually repeat the next day.
- The most important success metric early on is consistency, not intensity, performance, or discomfort.
- Avoiding excessive soreness or pain is critical, as discomfort dramatically reduces adherence in new or metabolically unhealthy individuals.
- High-effort or maximal work is inappropriate at this stage and increases injury risk and dropout.

*Why intensity must be kept very low initially*

- Individuals who have trained their whole lives often tolerate and even enjoy discomfort, but this is not true for beginners.
- For someone older or previously sedentary, intense exertion and muscle soreness can be psychologically and physically jarring.
- The goal is to avoid the sensation of muscle damage or extreme fatigue that discourages future participation.

*Initial phase: building the habit*

- Training should begin with the simplest possible movement that gets the person out of a sedentary state.
- Walking is the default starting point for most people.
- A typical starting prescription might be a dedicated 30-minute walk, repeated five times per week, depending on how total weekly time is allocated.
- The focus is on showing up consistently rather than optimizing fitness outcomes.

**Progressing after initial consistency is established**

*Selecting a sustainable modality*

- Once a basic habit is established, training begins to anchor around modalities the person enjoys or tolerates well.
- Options include:
  - Brisk walking
  - Incline treadmill walking
  - Stationary cycling
  - Outdoor cycling
  - Swimming or pool-based movement
- The specific modality matters far less than the person’s willingness to continue doing it.

*Managing intensity during early progression*

- Intensity remains intentionally low during this phase.
- There is no need to introduce formal concepts like zone 2 early on.
- The objective is continued movement with minimal perceived exertion and minimal recovery cost.
- Intensity language and metrics are introduced only after consistency and confidence are established.

**Introducing structure and intensity over time**

*Gradual introduction of zone 2*

- Once consistency and enjoyment are present, intensity concepts such as zone 2 can be introduced.
- Education focuses on what zone 2 feels like, rather than rigid numerical targets.
- Progression is individualized and based on readiness rather than a fixed timeline.

*Eventual introduction of VO2 max work*

- After several months of consistent aerobic training, a single higher-intensity session may be added.
- These sessions are introduced conservatively, described as “burning a match or two.”
- VO2 max training is layered on top of an existing aerobic base, not used as an entry point.

**Guiding philosophy for beginners and metabolically unhealthy individuals**

- The overriding goal is to ensure the person continues training tomorrow.
- Enjoyment, habit formation, and low recovery cost take precedence over optimization.
- Progression is gradual, individualized, and responsive to both physical and psychological readiness.

## How “training age” determines the intensity and workload needed to continue improving cardiorespiratory fitness [A: 1:31:15, V: 1:41:58]

**How “training age” influences required intensity**

*Definition and importance of training age*

- Training age refers to the cumulative amount of training an individual has performed over their lifetime.
- Training age, rather than chronological age alone, strongly determines how much intensity and volume are required to stimulate adaptation.

**Adaptation in beginners versus trained individuals**

*Low training age: rapid adaptation at low intensity*

- In beginners, almost any increase in duration or intensity is sufficient to drive adaptation.
- Improvements can occur even with modest increases in effort, such as moving from roughly 40% to 60% of VO₂ max.
- Aerobic capacity and mitochondrial function improve readily at relatively low workloads in untrained individuals.
- This responsiveness is not present once a person becomes reasonably trained.

*Higher training age: diminishing returns at low intensity*

- As fitness improves, progressively higher intensity and/or longer duration are required to continue driving adaptation.
- Workloads that once produced gains eventually become maintenance-level stimuli.
- Simply “doing more of the same” at low intensity becomes insufficient over time.

**Zone 2 as a relative intensity concept**

*Relationship between zone 2 and VO₂ max*

- Zone 2 represents a relative intensity rather than a fixed workload.
- For most people, zone 2 corresponds to approximately 65–75% of VO₂ max.
- The key question is not whether someone is in zone 2, but how much external work they can produce while staying there.

*Measuring progress within zone 2*

- Progress is tracked by increases in external workload at the same relative intensity.
- For example:
  - A novice may start walking at 2–3 miles per hour on a 4–5% incline.
  - Over time, improvements are reflected by increases in speed, incline, or both at the same physiologic effort.
- The same principle applies on the bike, where increasing wattage at the same perceived and physiologic intensity indicates adaptation.

**Shifting physiologic landmarks with training**

*Lactate threshold progression*

- In untrained individuals, the first lactate threshold (zone 2) typically occurs around 50–60% of VO₂ max.
- With training, this threshold shifts upward.
- In well-trained individuals, zone 2 can occur at 75–80% of VO₂ max.
- As fitness improves, zone 2 moves closer to VO₂ max, reflecting greater metabolic efficiency and endurance capacity.

*Implications for advanced trainees*

- More trained individuals must work at higher absolute intensities to remain in zone 2.
- The closer zone 2 moves toward VO₂ max, the more demanding even “aerobic” training becomes.
- This upward shift explains why elite athletes can sustain workloads that are unattainable for less-trained individuals at the same relative intensity.

## Why zone 2 training still matters for women (including postmenopausal women) [A: 1:32:45, V: 1:43:53]

**Do recommendations differ for females?**

*The emerging narrative around women and zone 2*

- A growing narrative on social media suggests that women, particularly postmenopausal women, should not prioritize zone 2 training.
- The argument claims women have a higher proportion of oxidative Type 1 muscle fibers and higher baseline fat oxidation.
- Based on this, women are assumed to have more efficient mitochondria and therefore derive less benefit from zone 2 training than men.

**Hormonal changes and resistance training emphasis**

*Muscle loss concerns during and after menopause*

- Loss of estrogen makes it harder for women to maintain muscle mass.
- Lower testosterone levels further contribute to challenges in preserving lean tissue.
- Because of this, some argue that limited training time should be devoted primarily to resistance training to protect Type 2 fibers and muscle mass.

*Partial truths, but flawed framing*

- There are legitimate concerns about sarcopenia risk in peri- and postmenopausal women.
- Resistance training is essential and should not be sacrificed in favor of excessive low-intensity cardio.
- However, framing the issue as zone 2 versus resistance training is an oversimplification of exercise physiology.

⇒ Check out Peter’s premium article on zone 2: [A guide to Zone 2 training: its profound impact on health, detailed training instructions, addressing male and female differences, and more](https://peterattiamd.com/guide-to-zone-2-training/)

**Why the “either/or” framing is incorrect**

*The correct question is “why not both?”*

- Zone 2 training, resistance training, and high-intensity interval training all play important and complementary roles.
- The minimalist argument often starts as a narrow recommendation but becomes overgeneralized in public discourse.
- Eliminating zone 2 entirely based on time constraints or sex-specific arguments misses the broader physiologic picture.

*Time constraints apply equally to men and women*

- If total available exercise time is extremely limited, higher-intensity training may deliver more adaptation per unit time.
- This principle is not unique to women and applies equally to men.
- The issue is total training volume, not sex-specific physiology.

**Evidence for aerobic training benefits in women**

*Cardiorespiratory fitness improvements in peri- and postmenopausal women*

- [Data](https://link.springer.com/article/10.1007/s42978-025-00343-x) shows that both moderate continuous exercise (including zone 2) and interval training improve cardiometabolic health in peri- and postmenopausal women.
- Aerobic training remains an important contributor to healthspan and longevity in women across the lifespan.

*Resistance training remains non-negotiable*

- Resistance training is essential for women, particularly during menopause, due to increased vulnerability to muscle loss.
- The priority is to ensure resistance training is included, not to eliminate aerobic training.
- Women should not compromise resistance training in order to add more cardio, but cardio should not be removed altogether.

**Clarifying the takeaway**

- What the critique gets right
  - Women should not spend all of their training time doing low-intensity cardio.
  - Resistance training and higher-intensity work are critical, especially as women age.
- What the critique gets wrong
  - Suggesting women should avoid zone 2 entirely is categorically incorrect.
  - Zone 2 provides meaningful physiologic benefits and supports the ability to accumulate training volume with manageable fatigue.
  - Eliminating zone 2 risks losing important adaptations that support long-term health and functional capacity.

## How cardiorespiratory training should adapt with aging [A: 1:35:45, V: 1:47:22]

**How aging changes training recommendations**

*The fundamentals do not change with age*

- The core physiology of training adaptation remains intact as people age.
- Improvement still requires consistent exposure to effort and some form of progressive overload.
- Progressive overload does not necessarily mean absolute performance increases over time.
- Over decades, progressive overload may still occur even as overall performance declines due to reduced physiologic reserve.

**What does change with age**

*Slower adaptation and recovery*

- Recovery takes longer as people age.
- Tissues tolerate load less readily, increasing sensitivity to rapid progression.
- Pushing intensity or volume too quickly raises injury risk.

*Adjusting training variables*

- Intensity, frequency, and duration all need to be more carefully managed.
- Training plans should prioritize sustainability and recovery over aggressive progression.
- The sequencing and spacing of hard sessions becomes more important.

**Modality considerations in older adults**

*Shifting toward lower-impact activities*

- High-impact activities such as running may need to be reduced or replaced.
- Lower-impact modalities are often better tolerated for cardiorespiratory training.
- This shift is supported both by published data and clinical experience.

**Capacity for improvement later in life**

- Adaptation remains possible at older ages
- VO2 max can improve even when training begins late in life.
- Muscle strength, muscle mass, and endurance can also improve.
- The rate of improvement is slower, but the direction of change is still positive.

**The importance of early-life training without fatalism**

- Building a higher ceiling earlier in life
  - Training hard when young can meaningfully expand cardiorespiratory capacity.
  - Developing a high ceiling earlier provides more reserve later in life.
- Avoiding the “missed window” mindset
  - The absence of early training does not mean adaptation is no longer possible.
  - Older adults should not assume the opportunity for improvement has passed.
  - Training later in life still delivers meaningful gains in function and quality of life.

## The most common mistakes people make when training cardiorespiratory fitness and how to avoid them [A: 1:37:45, V: 1:49:31]

**Overcommitting to one end of the intensity spectrum**

- A frequent mistake is focusing exclusively on one intensity domain while ignoring the other.
- Some people do only zone 2 work and never train at higher intensities.
- A subset of this group mistakenly believes long, easy walks qualify as zone 2 when they are actually at or below zone 1.
- At the opposite extreme, some people do almost exclusively high-intensity training.
- Excessive high-intensity work limits endurance development and increases injury and burnout risk.

**Training at the wrong intensity**

- Under-shooting or over-shooting effort—Many people are not actually training at the intensity they think they are.
- In zone 2 training, the most common issue is being *below* the correct intensity.
- As fitness improves, what was once zone 2 can drift into zone 1 if workload is not increased.
- Failure to progress wattage, pace, or resistance leads to stagnation despite improved fitness.
- The same issue can occur with VO2 max work, where people may not push hard enough.
- In other cases, people push too hard too often, which also leads to stalled progress.
- A lack of improvement is often the clearest indicator that intensity is miscalibrated.
- Stagnation may reflect insufficient stimulus or excessive fatigue from overtraining.

**Mismatching training to available time**

- Not adjusting training to real-world constraints
  - Training plans often fail because they do not adapt to weekly time limitations.
  - When time is constrained, prioritization becomes essential.
  - High-intensity sessions are preserved when volume must be reduced.
  - Lower-intensity zone 2 sessions are the first to be trimmed during busy or travel-heavy weeks.
  - Effective training requires ongoing weekly decision-making rather than rigid plans.

**Neglecting sustainability**

- Short-term intensity over long-term consistency
  - A major mistake is prioritizing short-term performance over long-term adherence.
  - Early focus on crushing workouts can undermine consistency.
  - This is especially relevant for beginners, older individuals, or those returning from injury.
  - Long-term success depends on building a routine that can be maintained for years.
  - The primary goal is staying in the game rather than maximizing output in the first few months.

## How to break through a VO₂ max plateau [A: 1:40:45, V: 1:53:30]

**Addressing VO2 max plateaus**

- Understanding why progress stalls
  - Initial improvements in VO2 max often come relatively quickly with structured training.
  - As fitness increases, further gains become harder and require disproportionately more work.
  - Plateaus are a normal part of adaptation rather than a sign that training has failed.

**What it takes to keep pushing VO2 max higher**

- Increasing training stimulus over time
  - Continued improvement in VO2 max requires progressively increasing both intensity and duration.
  - These increases must be applied gradually rather than all at once to avoid injury and burnout.
  - High VO2 max values demand sustained exposure to very demanding training loads.
- *Context from elite endurance athletes*
  - Elite endurance athletes often appear to follow an 80/20 intensity distribution.
  - That distribution exists within the context of extremely high total training volumes.
  - When training 15–20 hours per week, even 20% high-intensity work represents many hours.
  - Achieving VO2 max values above ~80 ml/kg/min requires a level of intensity and volume far beyond what most people can realistically sustain.

**Practical takeaway for non-elite trainees**

- Chasing marginal VO2 max gains comes with rapidly increasing time and effort costs.
- Expectations should be calibrated to available training time and recovery capacity.
- There is a point where further increases may not be worth the trade-offs for most people.

## The main takeaways about cardiorespiratory fitness and longevity [A: 1:41:30, V: 1:54:16]

***If people remember one thing about cardiorespiratory fitness as it relates to longevity, what would it be?***

- The single-word answer: Train.

**More detail:**

*1 Rejecting oversimplified frameworks*

- Cardiorespiratory fitness cannot be reduced to simple rules like using zone 2 only to build a base and VO2 max only to build a peak.
- Zone 2 and VO2 max training both contribute to base and peak adaptations in overlapping ways.

*2 The real challenge: balancing variables*

- Effective training requires balancing volume, intensity, adaptation, and age.
- These variables interact dynamically rather than following fixed formulas.
- The complexity of training does not mean it has to be confusing or paralyzing.

*3 Using rules without becoming dependent on them*

- Formulas and rules of thumb are useful starting points.
- Training guidance should empower independent thinking rather than blind adherence.
- The goal is to understand how to structure training and how to adjust it over time as life circumstances change.

*4 Long-term adaptability as the real objective*

- The most important outcome is developing the ability to adapt training across different seasons of life.
- Longevity-focused fitness depends on flexibility, not rigid programming.
- Knowing how to modify training as time, recovery, and priorities shift is as important as any specific protocol.

## Peter’s carve out: oral hygiene and Peter’s two-toothbrush system [A: 1:43:00, V: 1:55:40]

**Framing the carve-out**

- This carve-out sits somewhere between a legitimate longevity tool and something that is admittedly unnecessary.
- Oral hygiene is treated as a non-negotiable daily practice.
- Electric toothbrushes are preferred over manual brushes.

**Electric toothbrush preferences**

- Peter has been dissatisfied with traditional options
- Common electric toothbrushes are perceived as cheap and poorly designed.
- Aesthetic and tactile quality matter, not just functionality.

**Peter’s two-toothbrush system**

- Two different electric toothbrushes are used daily.
- One toothbrush is used exclusively in the morning.
- A different toothbrush is used exclusively at night.
- Both toothbrushes travel together to maintain the routine.

**The specific toothbrushes**

- Brand: [Suri](https://www.trysuri.com/en-us/products/suri-2-sonic-toothbrush-uv-c-led-case)
  - Designed with a sustainability-focused aesthetic.
  - Marketed around eco-friendly materials.
  - Provides a distinct vibration feel compared to other brushes.
- Brand: [Laifen](https://www.laifentech.com/collections/electric-toothbrush)
  - Designed with a minimalist, Apple-like aesthetic.
  - Includes app-based customization of vibration patterns.
  - Offers multiple programmable vibration modes.
  - Delivers a noticeably different brushing sensation than Suri.
- NOTE: Peter has no affiliation with any of these companies

*Shared features between the two*

- Extremely long battery life.
- Charging may only be required roughly once per month.
- Build quality and user experience feel elevated compared to mainstream options.

*Why use two toothbrushes?*

- Having two toothbrushes reduces the risk of being without one while traveling.
- Both toothbrushes are packed to preserve consistency.

*Sensory and performance hedging*

- The vibration patterns are meaningfully different.
- There is uncertainty about which brush is objectively better.
- Using both is a way to hedge against missing out on superior performance.

*Psychological motivation*

- Curiosity and experimentation drive continued interest.
- There is openness to adding a third toothbrush if a compelling option appears.
- Fear of missing out plays a role in exploring new tools.

**Closing tone**

- The carve-out exemplifies an extreme version of optimization.
- Moderation itself is not applied moderately.
- The segment ends as a humorous but revealing glimpse into Peter’s personal habits.

---

## Selected Links / Related Material

**When examining predictors of all-cause mortality, cardiorespiratory fitness outperforms every other commonly measured variable including blood pressure, cholesterol, BMI, smoking status, and even chronological age**: [Association of Cardiorespiratory Fitness With Long-term Mortality Among Adults Undergoing Exercise Treadmill Testing](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428) (Mandsager et al., 2018) [7:30]

**When it comes to delivering oxygen to the mitochondria, cardiac output that is the main driver**: [Limiting factors for maximum oxygen uptake and determinants of endurance performance](https://pubmed.ncbi.nlm.nih.gov/10647532/) (Bassett and Howley, 2000) [16:45]

**Episode of The Drive with George Brooks all about lactate**: [#312 – A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond | George A. Brooks, Ph.D.](https://peterattiamd.com/georgebrooks/) | Peter Attia (peterattiamd.com) [23:15, 40:45]

**Episode of The Drive describing how at higher intensities, lactate production overwhelms systemic clearance**: [#294 ‒ Peak athletic performance: How to measure it and how to train for it from the coach of the most elite athletes on earth | Olav Aleksander Bu](https://peterattiamd.com/olavaleksanderbu/) | Peter Attia (peterattiamd.com) [26:15]

**Zone 2 helps athletes improve movement efficiency**: [#294 ‒ Peak athletic performance: How to measure it and how to train for it from the coach of the most elite athletes on earth | Olav Aleksander Bu](https://peterattiamd.com/olavaleksanderbu/) | Peter Attia (peterattiamd.com) [31:30]

**A commonly used way to estimate your zone 2 effort is the Maffetone formula**: [The MAF 180 Formula: Heart-rate monitoring for real aerobic training.](https://philmaffetone.com/180-formula/) | Phil Maffetone (philmaffetone.com) [36:45]

**Episode of The Drive with Phil Maffetone**: [#144 – Phil Maffetone: Optimizing health and performance through maximal aerobic function](https://peterattiamd.com/philmaffetone/) | Peter Attia (peterattiamd.com) [36:45]

**Improving zone 2 threshold depends on more lactate clearance rather than reduced lactate production**: [#312 – A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond | George A. Brooks, Ph.D.](https://peterattiamd.com/georgebrooks/) | Peter Attia (peterattiamd.com) [40:45]

**Episode of The Drive with Olav Aleksander Bu (second appearance) where he walked through the exact protocol for test VO2 max**: [#331 ‒ Optimizing endurance performance: metrics, nutrition, lactate, and more insights from elite performers | Olav Aleksander Bu (Pt. 2)](https://peterattiamd.com/olavaleksanderbu2/) | Peter Attia (peterattiamd.com) [46:30]

**The best way to test VO2 max on your own is the Cooper test**: [Using the Cooper Test 12-Minute Run to Check Aerobic Fitness](https://www.verywellfit.com/fitness-test-for-endurance-12-minute-run-3120264) | ([verywellfit.com](http://verywellfit.com)) [47:30]

**A cycling-based alternative for testing your VO2 max is the revised Ekblom-Bak protocol**: [Validity of the revised Ekblom Bak cycle ergometer test in adults](https://pubmed.ncbi.nlm.nih.gov/27311582/) (Björkman et al., 2016) [48:15]

**Tools Peter uses for his cycling zone 2 workouts**: [1:01:00]

- [Trainer Road](https://www.trainerroad.com/)
- [Wahoo KICKR](https://www.wahoofitness.com/devices/indoor-cycling/bike-trainers/kickr-buy)

**In the podcast with Olav, he talked about one of the advantages of doing slightly longer intervals is you go slightly lower intensity but you can accumulate a little bit more volume**: [podcast with Olav Alexander Bu](https://peterattiamd.com/olavaleksanderbu2/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com)) [1:10:45]

**Each aerobic training session triggers a temporary rise in mRNA for PGC-1α which persists for 24 hours**: [Repeated transient mRNA bursts precede increases in transcriptional and mitochondrial proteins during training in human skeletal muscle](https://pmc.ncbi.nlm.nih.gov/articles/PMC3010147/) (Perry et al., 2010) [1:27:30]

**A premium article by Peter about zone 2 which specific info as it relates to women**: [A guide to Zone 2 training: its profound impact on health, detailed training instructions, addressing male and female differences, and more](https://peterattiamd.com/guide-to-zone-2-training/) | Peter Attia (peterattiamd.com) [1:33:45]

**Data shows that both moderate continuous exercise (including zone 2) and interval training improve cardiometabolic health in peri- and postmenopausal women**: [Effect of Physical Activity on Cardiorespiratory Fitness and Markers of Cardiovascular Disease Risk During Menopause: A Systematic Review and Meta-Analysis of Randomised-Controlled Trials](https://link.springer.com/article/10.1007/s42978-025-00343-x) (Woodward et al., 2025) [1:34:45]

**Peter’s electric toothbrushes:** [1:43:00]

- Brand: [Suri](https://www.trysuri.com/en-us/products/suri-2-sonic-toothbrush-uv-c-led-case)
- Brand: [Laifen](https://www.laifentech.com/collections/electric-toothbrush)

---

## People Mentioned

- [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks)
- [Olav Aleksander Bu](https://www.instagram.com/olavaleksander/?hl=en)
- [Phil Maffetone](https://philmaffetone.com/about/)
- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar)
- [Eliud Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge)
- [Shane Gillis](https://en.wikipedia.org/wiki/Shane_Gillis)
- [Layne Norton](https://www.instagram.com/biolayne/?hl=en)