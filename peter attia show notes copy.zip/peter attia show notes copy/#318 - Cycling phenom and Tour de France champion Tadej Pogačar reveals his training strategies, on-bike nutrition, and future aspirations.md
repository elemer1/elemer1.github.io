# #318 ‒ Cycling phenom and Tour de France champion Tadej Pogačar reveals his training strategies, on-bike nutrition, and future aspirations

**Source:** [https://peterattiamd.com/tadejpogacar/](https://peterattiamd.com/tadejpogacar/)

---

Tadej Pogačar is a three-time Tour de France champion and one of the most dominant cyclists of his generation. In this episode, he shares insights into his 2020 Tour de France victory, his historic 2024 season winning both the Giro d’Italia and Tour de France, and the struggles he faced in 2022 and 2023. He also dives into his training regimen, nutrition, and the key metrics he tracks, like power, VAM, and heart rate variability. Tadej offers a glimpse into his goals for the future and what it takes to stay at the top of the sport.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tadejpogacar/the_Drive_public.png)

Play

#318 ‒ Cycling phenom and Tour de France champion Tadej Pogačar reveals his training strategies, on-bike nutrition, and future aspirations

#318 ‒ Cycling phenom and Tour de France champion Tadej Pogačar reveals his training strategies, on-bike nutrition, and future aspirations

1x15s30s

0:0045:44

## We discuss:

- 2020 Tour de France win [4:30];
- Learning from previous mistakes [8:45];
- Training: simulating steep climbs and other challenging race conditions [10:30];
- Tadej’s historic 2024 season and what contributed to his success [12:30];
- Nutrition for optimal performance: offseason diet and carbohydrate intake during intense training sessions [15:30];
- Training metrics: heart rate, power output, VAM, and HRV, and his approach to zone 2 training [18:15];
- Epic climbs in the Tour de France, mindset after challenging stages, and rebuilding confidence after the 2023 Tour [25:45];
- Racing dynamics, media criticism, and Tadej’s reflections on racing records [32:15];
- Training in the off-season [39:00]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Tadej Pogačar is a professional cyclist and three time winner of the [Tour de France](https://en.wikipedia.org/wiki/Tour_de_France) (2020, 2021, and 2024)
- For those of you who may not know his story, Tadej who is just 26-years-old has already been compared to the most legendary all-around cyclist of all time, [Eddy Merckx](https://en.wikipedia.org/wiki/Eddy_Merckx)
  - He’s generally referred to as the second coming of Merckx, whose nickname was “the cannibal” (from the manner in which he devoured the competition)
- Tadej was a very successful junior rider, winning some of the most prominent races prior to his breakthrough year in 2019 when he signed on with the [UAE team](https://www.uaeteamemirates.com/team/)
  - He won the [Tour of California](https://en.wikipedia.org/wiki/2019_Tour_of_California) that year and won 3 stages of the [Vuelta a España](https://en.wikipedia.org/wiki/2019_Vuelta_a_Espa%C3%B1a#), one of the 3 grand tours on route to an overall 3rd place finish as well as the young rider title
- In 2020 he was the unexpected winner of the [Tour de France](https://en.wikipedia.org/wiki/2020_Tour_de_France)
  - This is something that we will discuss in detail
- Since that time, Tadej has basically rewritten the record books
  - He’s done things that people have generally thought impossible in the modern era of cycling, largely because of the specialization of the sport
    - Typically, cyclist will focus on 1 type of race
- Tadej has demonstrated an appetite to conquer everything he does
  - That means he’s competing not just in grand tours and shorter stage races, but also some of the most grueling 1-day races of all time
    - There are 5 such races and he has already won 3 of them
    - We discuss his aspirations around the others
- 2024 was a momentous year ‒ he first one the [Giro d’Italia](https://en.wikipedia.org/wiki/2024_Giro_d%27Italia) and the [Tour de France](https://en.wikipedia.org/wiki/2024_Tour_de_France)
  - A double feat that has not been accomplished for nearly 30 years
  - He set a record winning 12 stages across both of these races
- He’s currently the #1 ranked cyclist in the world
  - A record that he’s held for about 170 weeks and counting
- In a week, he’s going to attempt to do something that many people thought would never be possible in the modern era of cycling: complete something known as “the triple crown”
  - Winning the Giro, the Tour, and the [World Championship Road Race](https://en.wikipedia.org/wiki/UCI_Road_World_Championships_%E2%80%93_Men%27s_road_race)
- Peter has wanted to interview Tadej for some time
  - The opportunity of him racing at the GP in Montreal, just 2 weeks out from the World Championship was remarkable and fortuitous (Peter was very grateful to have his time)
- In this conversation we talk about
  - His remarkable 2020 season, where he took the world by storm and won the Tour de France in one of the most dramatic finishes that race has ever seen
  - The highs and lows of his career since that time
  - How he trains
  - How nutrition has evolved on the bike, and why that allows cyclists today to do things that were previously thought impossible
- This is a bit of an interesting podcast if you are not a cyclist because some of the things he talks about are difficult to wrap your mind around
  - Hopefully Peter’s reaction to those things (for example, his power numbers) will give you a sense of the fact that Tadej is one of most fit human beings on the planet at this moment

## 2020 Tour de France win [4:30]

- Tadej raced yesterday, has a race tomorrow, and we’re 2 weeks out from the World Championships
  - For him to make time for this podcast is amazing
- A lot of people listening will know everything about Tadej (like Peter or super fans), but there’s also probably a number of people listening who might not appreciate the magnitude of what he’s accomplished in a very short period of time
- Peter learned about Tadej in 2019 as the most promising young cyclist that was coming up
- Not many people (Peter included) expected what happened in [2020 at the Tour de France](https://en.wikipedia.org/wiki/2020_Tour_de_France)

**What were your expectations going into the 2020 Tour de France?**

- Tadej was not expecting at all to win; it was a COVID year
- He had pretty good training, not too many races, so not too much to prove
- 2019 was the breakthrough year for him
- 2020 was a long period of doing nothing, just training
- He and [Fabio](https://en.wikipedia.org/wiki/Fabio_Aru) went into the Tour as two leaders
- In the last week, he was fighting for the podium, for second place (he was really happy about that)
- The final time trial turned the table around and won the Tour

> “*It was unbelievable. I think still a lot of people don’t believe it happened.*”‒ Tadej Pogačar

- At the time of that final time trial, people said, “*We haven’t seen a race like this since* [*LeMond*](https://en.wikipedia.org/wiki/Greg_LeMond) *and* [*Laurent Fignon*](https://en.wikipedia.org/wiki/Laurent_Fignon) *in I think it was* [*’89*](https://en.wikipedia.org/wiki/1989_Tour_de_France) *when he had that come behind*.”

**At what stage in 2020 did you realize you were going to be on the podium?**

- On the [stage Col de Rousset](https://en.wikipedia.org/wiki/2020_Tour_de_France,_Stage_12_to_Stage_21#Stage_17), he was sure he was going to be second
  - This was the queen’s stage and he was just 15 seconds behind [Roglic](https://en.wikipedia.org/wiki/Primo%C5%BE_Rogli%C4%8D)
  - [Lopez](https://en.wikipedia.org/wiki/Miguel_%C3%81ngel_L%C3%B3pez_(cyclist)) won that stage on the high mountain

Tadej explains, “*I also think Roglic thought that day that he’s going to win, so yeah, you never know.*”

**Going into that** [**last time trial**](https://en.wikipedia.org/wiki/2020_Tour_de_France,_Stage_12_to_Stage_21#Stage_20)**, what was your team telling you in the radio at the time checks (or even before the time checks) in terms of your delta per** [**Roglic**](https://en.wikipedia.org/wiki/Primo%C5%BE_Rogli%C4%8D) **on a kilometer basis?**

- Roglic was studying behind him 2 time checks on the flat before the final climb
- He didn’t know who was leading that time
- On the flat section, he got that time and even how much he was behind
- Then when the climb came, there were so many people, he did not hear a word in the radio; he just went

Tadej explains, “*I just went full gas to the top*.”

**Did you feel anything different that day?**

*Did it feel better than some of the other stages, or was it simply a matter of he had deteriorated more than you across 20 days?*

- Because it was the last hard stage
- The next day is [Mantes-la-Jolie](https://en.wikipedia.org/wiki/2020_Tour_de_France,_Stage_12_to_Stage_21#Stage_21) (“you just roll through”)
  - Tadej shares, “*It’s still a hard race, but eh. If everything goes normal your GC stays the same, yeah, it was okay*.”
- In the [final time trial](https://en.wikipedia.org/wiki/2020_Tour_de_France,_Stage_12_to_Stage_21#Stage_20), he just needs to be relaxed; he thought he has earned the [white jersey](https://en.wikipedia.org/wiki/White_jersey) and was going to end up 2nd place (but he ended up winning)

**Tadej shares,** ***“It was a dream, no?”***

Peter asks, “*You didn’t feel the pressure?*”

- Tadej didn’t feel nothing; he was really chilled out
- He knew the park course really well because he did recon before with [Allan Pieper](https://en.wikipedia.org/wiki/Allan_Peiper) and [Mikkel Bjerg](https://en.wikipedia.org/wiki/Mikkel_Bjerg)

Tadej explains, “*Everybody was happy around and there was no tension, no stress, nothing, and we just rolled with it and then it was one of the best days I ever had*.”

**Do you remember what your average power was over that time trial?**

- On the flat, he had a power meter; but on the climb, he had nothing because he wanted to have a 6.8 kilogram bike (as light as possible by regulations)
- On the flat, he thinks he went 380-390 (nothing crazy)

**What was your weight by that point in the Tour? Were you 60 kilos?**

- Tadej thinks he was 66 even [145.5 lbs.]

Peter asks, “*What did you weigh this year?*”

- He came to the Tour with 64.5 and then 65, then 65.5, and was jumping around 65 throughout the tour [142-144 lbs.]

## Learning from previous mistakes [8:45]

**More recently in the Tour de France**

- Peter comments that ‘21 was another amazing year
- In ‘22 and ‘23 Tadej had a great race, but it goes wrong in a couple stages

*In ‘22 stage 16 was a struggle [*[*week 2*](https://en.wikipedia.org/wiki/2022_Tour_de_France#Week_Two)*]*

- Yeah, Col du Granon, Laurent, Telegraphe, Galibier, down Briancon, almost to Briancon [[week 2](https://en.wikipedia.org/wiki/2022_Tour_de_France#Week_Two)]
- [Visma](https://en.wikipedia.org/wiki/Visma%E2%80%93Lease_a_Bike_(men%27s_team)) attaching was constant
- Tadej’s mistake was that he shouldn’t have followed [Roglic](https://en.wikipedia.org/wiki/Primo%C5%BE_Rogli%C4%8D) immediately there on Telegraphe
  - It was [Tiesj Benoot](https://en.wikipedia.org/wiki/Tiesj_Benoot) and then [Laporte](https://en.wikipedia.org/wiki/Christophe_Laporte) with him on the downhill, and they just flew down and when we started the Galibier they just go one by one
  - Tadej had to respond to 8 or 9 attacks
- Peter thinks he looked very strong
- Tadej was, but if you do 8 or 9 sprints, it takes too much
- Then he tries to drop everybody from the wheel on Galibier
  - Which was stupid because he knew that [Wout van Aert](https://en.wikipedia.org/wiki/Wout_van_Aert) was also in the front and is checkmate anyway

**From a nutritional standpoint, did you feel depleted?**

*Did you feel like you didn’t have enough? Were you short a bottle on that stage or something?*

- Tadej thinks he ate enough
- But you cannot eat enough when you do so much power, so much attacking
- He thinks he had a good nutrition plan, but if you do too much with our body, you cannot replace that

## Training: simulating steep climbs and other challenging race conditions [10:30]

**When you’re training, do you try to simulate that extent of attacking and recovering?**

- Since Tadej was junior, even before he knew what it’s going to be per course, he finds around his home a similar type [of course] and just does repetitions of one climb
  - He still strings this way
- For example, in [Montreal](https://en.wikipedia.org/wiki/Grand_Prix_Cycliste_de_Montr%C3%A9al) tomorrow is around a 4-5 minute climb and 2 short ones

***He just tries to do as many possible repetitions in training as well as trying to simulate the race***

**What kind of climb do you like the most? What kind of climb do you like the least in terms of grade and duration?**

- It depends on the shape
- He really like 20 minute climbs, quite steep

*10-12% steep?*

- Yeah
- And also 7-8% because they go really fast
- It’s already a lot of drafting
- When it’s more than 9%, there’s not much draft, so you can do what you want (which Tadej thinks is pretty cool)

**Do you have many climbs near you that replicate where you can do 20 minutes at 8%, 9%, 10%?**

- No, not really
- He does 5-10 minutes at 9%, 10%
- In Slovenia, around 10 minutes with steep ones
  - A 20 minute climb is quite rare

**How much does the heat factor into it, and how much are you able to replicate that in training?**

- Heat training has become a thing now in cycling, especially in the last 2-3 years
- We try to overheat the body in a training session or at home on a trainer

Tadej explains, “*It is a big factor, especially for me. I felt always that I struggle when it’s super hot, but yeah, if you try to train this, you can be better.*”

## Tadej’s historic 2024 season and what contributed to his success [12:30]

- Peter thinks 2024 has been a remarkable year for Tadej
  - Winning both the [Giro d’Italia](https://en.wikipedia.org/wiki/2024_Giro_d%27Italia) and [Tour](https://en.wikipedia.org/wiki/2024_Tour_de_France) so comfortably

![](https://peterattiamd.com/wp-content/uploads/2024/09/f1-tadejpogacar-1024x609.png)

**Figure 1. Tadej Pogacar crossing the finish line to win the final stage of the ‘24 Tour de France**. Image credit: [Tim de Waele/Getty Images](https://www.theguardian.com/sport/article/2024/jul/21/tadej-pogacar-wraps-up-tour-de-france-victory-to-seal-historic-double)

- People said, “*Well,* [*Jonas*](https://en.wikipedia.org/wiki/Jonas_Vingegaard) *crashed yearly in the season*,” but Jonas’s times were pretty remarkable
- Peter thinks it seemed to be just as much a function of Tadej riding even better this year than Jonas come in injured

**Do you feel that is the case?**

- Jonas had a beginning to this year
- Tadej doesn’t know how exactly his recovery went because they kept it quite quiet
  - Once got on the bike, he could start immediately training quite normal now for sure, at first a little by little
- It had an effect on the [week 3 stage](https://en.wikipedia.org/wiki/2024_Tour_de_France#Week_three) of the race
  - It affects that preparation
  - You don’t have the capacity to go 3 weeks
  - You have the power, 5-10 minutes of best power output
  - You can do 20 minutes one day, but then maybe your body is not used to going another day

***Tadej thinks that was the case with Jonas this year: he had a great power, he got great numbers, but then maybe he lacked this 3 week extent to perform***

Peter points out, “*I feel like every cycling fan just feels that we have this incredible treat where we have both of you as these remarkable cyclists. You’re both so young, we’re going to have many more years of you guys racing each other.*”

**Do you feel you’re going to continue to race the Tour for many, many more years?**

- The Tour de France is the biggest race of cycling, so yeah, to keep being on the top you need to do the Tour de France

> “*I think battling between me and Jonas pushing each other and always the Tour is the test who is better now*”‒ Tadej Pogačar

***Tadej will keep riding the Tour until he doesn’t enjoy the stress anymore***

Peter points out, “*Something seemed different in you this year. You seemed stronger.*”

**What changed in your training between ‘23 and ‘24?**

- He didn’t change only training on the bike
- He also implemented core training more and more stuff outside the bike
- As well, he got more into the details of nutrition
  - He’s getting older, so he’s not so obsessed anymore with just going cake on cake or just eating shit

Peter asks, “*Wait, does that mean that 5 years ago, you weren’t paying much attention to your nutrition and you were eating as much as you wanted?*”

- Yeah

## Nutrition for optimal performance: offseason diet and carbohydrate intake during intense training sessions [15:30]

**Do you need to watch your weight in the off-season  now?**

- Tadej’s whole year looks more or less the same
- He never restricts too much
  - He never says he cannot eat cake or chocolate because if you restrict too much, then one time you’ll break and go crazy

***That’s not a good relationship with food ‒  you need to have a balance also with the bad food***

- Then in the off-season, he doesn’t have the craving
- He is able to go on vacation and have nice quality food and not crazy amounts so he doesn’t gain so much weight

**What’s the heaviest you’ll be in the off-season?**

- 69 maybe 70 [kg, or 152-154 lbs] when waking up after a party or a big dinner when you just eat a lot
  - A lot of times that’s just water weight

***Around 69 kg would be the maximum***

**Do you have a sense of how many grams of carbohydrate you consume in an hour when you’re training?**

- In his drink, he has either 30 or 60 grams per bottle (not a strong dilution)
- Tadej likes 30 grams of carbs because then he can eat more
- But when it’s a  hard stage, it’s better to have 60 grams in a bottle and then you can eat less

***For a hard stage, you need to get around 120 grams per hour; for easier stages, 60-90 is enough***

**Was that easy for you to get to, or did you have to train your gut to be able to eat that much?**

- 5 years ago, 120 grams per hour was impossible, but with good food/nutrition

*What do you like to eat and drink?*

- His sponsor ([Enervit](https://www.enervit.com/en/)) with nutritionists designed really good gels and drinks that are easy on the gut
- With this he doesn’t have any stomach problems

Tadej shares, “*5 years ago I would always go shit my pants after the stage races or long races, and now even eating 120 grams, no stomach problems.*”

**Do you think that’s more because you’ve gotten used to it, or do you think it’s more because your nutritionist has figured out a recipe that works for you?**

- There needs to be a good ratio between glucose, fructose, and all the other stuff in gels
- It needs to be good quality so you get used to it

## Training metrics: heart rate, power output, VAM, and HRV, and his approach to zone 2 training [18:15]

**When you’re preparing for the Tour, how do you define your energy systems?**

*Do you define them more by heart rate, by power, by how you feel?*

- Tadej has been training with heart rate monitors since he was 10-years-old
- He knows how his heart rate responds when he’s tired or when he’s good

***He could go by heart rate only, but it’s always good to compare heart rate to power***

*However, power meters are not so reliable these days*

- He uses a [Shimano power meter](https://bike.shimano.com/en-EU/technologies/component/details/power-meter.html)
- You always need to be careful with the temperature outside, the calibration, everything
- In Tadej’s experience, it can be off sometimes

***The best is to train on your home roads where you can also look the speed, the*** [***VAM***](https://en.wikipedia.org/wiki/VAM_(bicycling))***, how fast you’re moving***

**What kind of VAM are you able to reach when you’re training?**

- 7.5%
- If you go all out, it’s around 1,700-1,800 of VAM for 15 minutes
  - It depends on the gradient

Peter reacts and explains, “*That’s just incredible. I know that people listening might not appreciate that. I’m not going to take time to explain what VAM is. If they know what it is, they understand how crazy that is. If they don’t, they can look it up. I’m happy when I hit a thousand by the way, just for comparison.*”

**Tadej is using these other metrics: speed, heart rate, and power**

> “*You see all these three things, the speed, heart rate, and power. Then you see how you feel and in which zone are you really in.*”‒ Tadej Pogačar

**How much time are you spending in** [**Zone 2**](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/) **(low intensity aerobic training)?**

- Tadej loves riding in Zone 2
- Around where he lives in Monaco, it’s really hard to get into Zone 2 because there’s a lot of climbing and then all the downhills
- He tries to hit really high Zone 2 on the climbs for 20-40 minutes and then recover on the downhill
- When he goes home to Slovenia or somewhere else in Spain when he’s training in Calpe or somewhere it’s more flat, he likes to stay in zone 2 for 5 hours
- He would love to do just Zone 2 and going nonstop

**What is your heart rate in Zone 2, approximately?**

- When he’s fatigued, it’s 140, 145
- When he’s more fresh, it’s 150-155

**How many watts are you putting out at that heart rate?**

- 320-340

Peter explains, “*320-340 watts for 5 hours, keeping lactate below 2, keeping heart rate at 140, is really remarkable*.”

**Cycling in Monaco you cannot stay in Zone 2**

- There are climbs, and you recover after
- It’s too much up and down
- If you’re doing a 5-hour ride, your Zone 2 after 5 hours may not be your Zone 2 anymore

Tadej explains, “*You always need to know at what time this Zone 2 will not be your Zone 2 anymore because on the flat, you’ll not recover and five hours of riding of 320 to 340 for me is also next day I’m not riding the bike so when I go on flat for longer, I drop power to 290 to 300.*”

**Do you track your heart rate or** [**heart rate variability (HRV)**](https://en.wikipedia.org/wiki/Heart_rate_variability) **in the morning?**

*Do those numbers give you any indication of how you’re going to train that day or race?*

- He started tracking this in 2020, but he did not find it really interesting or helpful
- This year he started tracking HRV in the night and he likes to track it, but it can be misleading

Peter notes, “*It’s almost better for somebody else to look at it and tell you after*.”

- Tadej’s girlfriend doesn’t open it in the morning, she opens it after the race
  - This way, if it’s really low, it doesn’t mess with her mind
  - She doesn’t want to be stressed out and then it would mess with the race

*When you do look at your heart rate variability, how much variation do you have between a high day and a low day of HRV?*

- On a good day, his HRV would be 120, 130
- Maximum days it can be up to 150
- On the lower end, it could be 35

Peter asks, “*Is that from drinking alcohol the night before?*”

- Yeah
- In races (the Tour and Giro), it was quite stead around 80-110 on average, every day
  - Peter finds that amazing

**Do you care about resting heart rate or how much heart rate range you have?**

- The lowest Tadej has hit since he’s been tracking is 37
- His nightly average is 43, 42; but on some days he could wake up with 48, 49
- If he’s sick or really fatigued it might even be over 50

*In terms of max heart rate*

- When he was a junior, he could hit 213 in shorter races
- Yesterday, he hit 203 (still pretty high)

**How often do you guys test VO****2** **max?**

- It’s been a while since he tested

**Do you do an FTP test out of season just as a way to track it, like a true 20-minute test?**

- It’s been a while since he’s done one
- This year he did a **fatigue test** where you repeat 8 minutes of one power, going to a higher and higher power, and then all out
- Normally, they do a **home trainer test** in the camp in December
  - It’s long, from 1 hour to 1 hour 30 [minutes]
  - Depends on how long you want to test, to which zone you want to test
  - For Tadej, it’s normally around 1 hour 20 min
    - 10 steps on the home trainer, and every 5 minutes you take a lactate [reading] from the ear to check for the zones
    - He and his girlfriend test each other
- Tadej’s girlfriend is also a professional cyclist
- Peter comments, “*If you guys have kids one day, look out.*”
- Tadej doesn’t want to put them in cycling

## Epic climbs in the Tour de France, mindset after challenging stages, and rebuilding confidence after the 2023 Tour [25:45]

- For Peter, 3 of the most epic climbs in the Tour de France would be [Ventoux](https://en.wikipedia.org/wiki/Tour_de_France#Notable_stages:~:text=Mont%20Ventoux%20is%20often%20claimed%20to%20be%20the%20hardest%20in%20the%20Tour), [Alpe d’Huez](https://en.wikipedia.org/wiki/Tour_de_France#Notable_stages:~:text=The%20climb%20of%20Alpe%20d%27Huez%20has%20become%20one%20of%20the%20more%20noted%20mountain%20stages), [Galibier](https://en.wikipedia.org/wiki/Col_du_Galibier)

**What would be the most epic climbs, and how do they compare in difficulty?**

*Assuming you’re equally fresh on all days, same situation*

- Of those 3, Galibier is the easiest, Alpe d’Huez is second, and Ventoux is the hardest

![](https://peterattiamd.com/wp-content/uploads/2024/09/f2-tadejpogacar-1024x405.png)

**Figure 2. Gradient of Mont Ventoux**. Image credit: [PJAMM Cycling](https://pjammcycling.com/climb/40.Mont-Ventoux-Bedoin)

![](https://peterattiamd.com/wp-content/uploads/2024/09/f3-tadejpogacar-1024x393.png)

**Figure 3. Gradient of Alpe d’Huez**. Image credit: [PJAMM Cycling](https://pjammcycling.com/climb/118.Alpe-dHuez)

![](https://peterattiamd.com/wp-content/uploads/2024/09/f4-tadejpogacar-1024x380.png)

**Figure 4. Gradient of Col du Galibier**. Image credit: [PJAMM Cycling](https://pjammcycling.com/climb/112.Col-du-Galibier-Valloire-Cycling)

- Ventoux is the hardest because of the nature: the wind, heat
- Alpe d’Huez is hard but it’s shorter
- Galibier from Briancon’s side is dragging up in the valley and then when you turn right, it’s quite high altitude, but it’s still quite a regular climb
  - From the other side you have Telegraphe and then small downhill and climbing again

***They’re all more or less the same; these are almost identical climbs***

> “*Alpe d’Huez is just mythical. You have way harder climbs than Alpe d’Huez, for sure.*”‒ Tadej Pogačar

**What is the hardest climb in the modern tour?**

***For Tadej, Col de Rousset is the hardest***

![](https://peterattiamd.com/wp-content/uploads/2024/09/f5-tadejpogacar-1024x388.png)

**Figure 5. Gradient of the route for Stage 17 of the 2023 Tour de France**. Image credit: [PJAMM Cycling](https://pjammcycling.com/climb/5987.Col-de-la-Loze--%257C--2023-TDF)

- He had a very difficult day there in ‘23, the “Queen’s Stage” ([stage 17](https://en.wikipedia.org/wiki/2023_Tour_de_France,_Stage_12_to_Stage_21#Stage_17))
- Tadej did it twice and the first time he did good, but then he felt really tired after it
- Last year he did [Loze](https://en.wikipedia.org/wiki/Col_de_la_Loze#Appearances_in_Tour_de_France) and then small downhill and to Altiport in this town Courchevel; it was brutal

Peter notices, “*This is something about you, Tadej, that is very interesting. I’ve never seen a cyclist who in defeat is so gracious*.”

- Peter remembers after that stage, Tadej just thanked his team saying, “*Thank God I had a great team around me today, or I would’ve come off the podium*.”

**That’s remarkable sportsmanship. How are you able to do that?**

- It’s not individual sport, it is the team sport
- Guys sacrificed everything to be there in the Tour to help one guy to win the Tour
- On that day, he could really see how the guys reacted to him when he dropped
  - They helped him, supported him emotionally, physically, whatever

***Tadej felt like he let them down and he was feeling just devastated***

> “*I was upset, angry, but I couldn’t change it so I just went with it*.”‒ Tadej Pogačar

**What did you think about after the ’23 Tour?**

- It was frustrating
- He was anxious, stressed
- But he evaluated what went wrong, what were the mistakes, what he could do better
- It all went back to the [crash](https://www.bicycling.com/tour-de-france/a44589183/im-gone-im-dead-tadej-pogacar-cracks-on-stage-17-of-the-tour-de-france/) from Liege, preparation to the Tour and everything else

*Psychologically, did you have to get some confidence back?*

- He got some confidence back already when he won stage 20
- 3 days after that, the [World Championship](https://en.wikipedia.org/wiki/2023_UCI_Road_World_Championships#) was just a small patch on the wound
  - Great racing, but 3rd place didn’t feel enough
- Winning [Lombardy](https://en.wikipedia.org/wiki/2023_Il_Lombardia) was big

Peter explains, “*There are these 5 huge classic races that normally, the people who win the Tour de France do not win those races and vice versa. This is a totally different sport. It’s sort of like, I don’t know, the person who wins the marathon winning the 10K, even though that’s not even remotely the right comparison, but yes, you’re both on a bike, but it’s different and you’ve now won 3 of the 5 classics.*”

- Lombardy is the closest one that a Grand Tour winner can win
- The other 4, they’re really unlikely
  - Maybe there’s [Bastogne-Liege](https://en.wikipedia.org/wiki/Li%C3%A8ge%E2%80%93Bastogne%E2%80%93Li%C3%A8ge)
  - But also it’s really hard for a Grand Tour contender to win those races

**Other cycling races**

- [Paris-Roubaix](https://en.wikipedia.org/wiki/Paris%E2%80%93Roubaix) and [San Remo](https://en.wikipedia.org/wiki/Milan%E2%80%93San_Remo)
- Tadej has a feeling that San Remo is going to send him to the grave, trying to win that
  - He’s getting so close, but so far it’s unbelievable

Peter asks, “*To be clear, this is a goal. You want to win all five?*”

- Yeah, he want to wind firs the World Championships, San Remo, and then see if there is a space for Roubaix

*The* [*Vuelta*](https://en.wikipedia.org/wiki/Vuelta_a_Espa%C3%B1a)*?*

- Getting to the podium in the Vuelta in 2019 was a breakthrough for Tadej
  - With 3 stages, [white jersey](https://en.wikipedia.org/wiki/White_jersey), he wanted to come back and seal the deal with the [red jersey](https://en.wikipedia.org/wiki/Red_jersey)
    - Peter thinks he will

**Where do the Olympics rank on your goals?**

- It’s in Los Angeles in 4 years, and he really hopes for a hard climb like in Tokyo
- Olympics is cycling is hard timing, right on the heels of the Tour
  - For other sports, they train for 4 years just for the Olympics, and this is the peak of career
  - In cycling, the peak of your career needs to be the Tour de France every year
- It’s not as high a priority a the [Worlds](https://en.wikipedia.org/wiki/UCI_Road_World_Championships)

## Racing dynamics, media criticism, and Tadej’s reflections on racing records [32:15]

**Have you seen any of the Netflix specials on the Tour?**

- Yeah, he watched the [first season](https://en.wikipedia.org/wiki/Tour_de_France:_Unchained#)
- He didn’t watch the second season because he was in training camp
- Tadej explains, “*For people like us when we are there, it’s not so fun to watch.*”
- It’s fun for Peter to watch it with his wife or with friends if they’re not cycling fans
  - They’re not going to watch the Tour de France with him
- One of the things people cannot believe is how you guys are able to ride while fans are encroaching the roads

**What’s the closest call you’ve had with a fan?**

- The fans are amazing
- When Tadej was a kid, he always wanted that feeling to ride through the group of fans like this, and now he enjoys it the most
- In Col de Rousset in 2020 he had some close calls with a Slovenian fan
- Normally you need to watch the flags, and the flags are really tricky because they are waiting in the middle of the road and sometimes they move the flag differently
- When Peter watches this with his wife, she gets mad
  - She’s screaming at the TV for the fans to get out of the way
- Tadej thinks they help
- Peter would think the opposite
  - If he tries to put himself in a cyclist’s shoes, he feels like he would subconsciously be holding back a little bit for fear of hitting them and falling
- Tadej agrees, you sometimes let off the throttle a little bit
- But when you see the fans, the adrenaline is so high and the noise is incredible

> “*The noise is so loud and you’re just riding and you don’t actually lose any momentum and it’s crazy. It’s hard to describe*.”‒ Tadej Pogačar

- For Peter, it looks like one of the craziest things he’s ever seen
- This year in the Tour, he was very surprised that certain commentators were almost expressing disappointment when Tadej was winning stages after he had already secured the [yellow jersey](https://en.wikipedia.org/wiki/General_classification_in_the_Tour_de_France)

**Does that mean anything to you that people are saying, “*****He shouldn’t be winning so much?*****”**

- Tadej doesn’t see so many people saying this
- The ones that hate him will say that, but obviously they hold something against him (it’s normal)
- The media and the commentators and journalists, they like to say these things just so they have something controversial to say
- Tadej doesn’t see so much controversy in this
- The other day,  he counted how many stages he won: 12 stages in grand tours this year and 7 stages
  - It’s a little more than half (not so bad)

**Do you even think about equaling or bettering the mark now of** [**Merckx**](https://en.wikipedia.org/wiki/Eddy_Merckx) **and** [**Cavendish**](https://en.wikipedia.org/wiki/Mark_Cavendish) **in Tour stage wins?**

- Tadej doesn’t want to think so much ahead because you never know when your last winn is
- If it’s there, you take it
- If you feel good, you go for the stage, you win
- Cavendish won 35 stages ‒ it’s an incredible achievement

**Have you met Eddy Merckx?**

- Tadej has met him a few times
  - They met for dinner; it was nice
- One of Peter’s favorite books about cycling is the story of his life and career; it’s called [*Half Man, Half Bike*](https://www.amazon.com/Half-Man-Bike-William-Fotheringham/dp/1613747268/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.l46k9j7x19g7jZFiPNEzI815IoXGrEX6-xATTyXRJ-CZ9-_2pwO3tKtu6VoKKxGVdZk0V0dycVSK2Db5b9_lrsp-XF24V30zxjEYBTBdUD3cIsME3KQR9r17ZYqaFLYr7lx8qYbr3K6IE1kMaHB2dngWpao1NOpx-gb1Y6wSUQmXvvFKX6SI8uTFiM-OvWXUffSK6BUjqQqVpycMApsHXNT1it9QV-C4jQA_CTglgRw3GLM_HZr1vA-vXxb2PrjmF8YEnnHAM1bv6YmTikrvqcPh6v3XTAlw3JZXolHZaHs.0LT-HFyW_ODqYKCI0p-vNoZAHOaG4lqgw1S4joYlziU&qid=1726612068&sr=8-1)
- Peter has read that Mercks has considered Tadej the second coming of him
- Tadej doesn’t know how to respond to that
- He was one of the greatest
  - It was incredible how he won the races
- Tadej never saw any of his racing, but when you read his [Palmarès](https://en.wikipedia.org/wiki/Glossary_of_cycling#P:~:text=A%20list%20of%20races%20a%20rider%20has%20won.%20(French%2C%20meaning%20list%20of%20achievements%20or%20list%20of%20winners.)), it’s just unbelievable
  - It’s something you cannot imagine to achieve in this era

**Do you think that the** [**one-hour record**](https://en.wikipedia.org/wiki/Hour_record) **is something you would even entertain in terms of making the effort forward and training for it, setting aside time?**

- Tadej was until [Ganna](https://en.wikipedia.org/wiki/Filippo_Ganna) did it and then [Bigham](https://en.wikipedia.org/wiki/Daniel_Bigham); now, not so much
- Ganna was fast, incredible

**What is the difference between your power when you are climbing, so your femurs are not kinked down, versus when you’re in a time trial position?**

*How many watts do you lose being in a time trial position for the same period of time?*

- Tadej doesn’t know
- He’s still trying to figure this one out
- On the time trial, he has some good days and some bad days
  - He’s not as consistent as on the road bike
- But when it matters, he can push more or less the same numbers on the TT bike as on the road bike
- It’s coming all along now with biomechanics, wind tunnel testings, and so many trainings, so many intervals doing that you’re trying to figure out the best position to be possible to do this power

## Training in the off-season [39:00]

**You mentioned that you did some more strength work in the off-season coming into ’24 as part of the reason why you seemed even stronger than before**

*Were you doing any strength training for your legs?*

*Were you doing any weights?*

- Yeah, a little bit weights
- He does strength training throughout the season, but with less weights
  - Still legs, core, glutes, hips

**When you were growing up, did you run or swim or do any other endurance sports?**

- When he was younger in [Ljubljana](https://en.wikipedia.org/wiki/Ljubljana), in the winter his team would run up the mountain 3-4 times per week
- After school, they had a training meeting and would go up and down a mountain that was close by, 2-3 times
- They swam for a few years, 1 time per week for a hour or something

***He tried different sports in the winter ‒ cross-country skiing was his favorite***

- In the last 2 years, he tries to put running into the off-season
  - But it didn’t work out this year

**In your off-season, what is the most number of days you’ll go without being on a bike at all (no stationary bike, no outdoors)?**

- A stationary bike is a no-go for him, especially in the off season (he doesn’t do it)
- There is a 6-day team camp in the UAE
  - For example, last year, they went running in Abu Dhabi 2 times, played paddle something, and went off on vacation
- On vacation, you get bored and go for a run, paddle, or go swimming

Tadej explains, “*I cannot say that I do 2 weeks without a bike or without any training at all because I really enjoy doing other stuff and other sports.*”

***Maybe 3 days of doing nothing, then do something for 1 day, and then another 3 days of doing nothing***

- By mid-November he’s always on the road bike again

**How old were you when you knew you wanted to be a professional cyclist?**

- He was a junior when he thought he had a chance to be a professional in the World Tour Team, 16, 17-years-old
- Second year, juniors he realized he could definitely be in the World Tour
- 2 years after, he had signed with the [UAE team](https://www.uaeteamemirates.com/team/) pre-contract for 2019 (under age 23)

In closing, Peter adds, “*Everybody’s excited to see you at the* [*Worlds*](https://www.uci.org/competition-details/2024/PAR/72420) *in a couple of weeks. And again, not to put pressure on you, but just so people understand the significance of that, to be able to win two Grand Tours in a year is really unprecedented.*”

- If there’s a chance to add a world title to that, it’s kind of unbelievable
- At the other end of that, should it not happen this year given that you’re not yet 26, most people would take the bet that you’re going to have another shot at that

§

![](https://peterattiamd.com/wp-content/uploads/2024/09/bio-tadejpogacar-500x500.png)

##### Tadej Pogačar

Tadej Pogačar (nickname Pogi) is a professional cyclist from Slovenia who currently rides for UCI WorldTeam UAE Team Emirates. In 2019, at age 20, he became the youngest cyclist to win a UCI World Tour race at the Tour of California. He is a three-time winner of the Tour de France (‘24, ‘21, ‘20); in ‘24 he won six stages including the last three. He placed second in the tour in ‘22 and ‘23. He won Il Lombardia three times (‘23, ‘22, ‘21). He his a two-time winner of several races: Liège–Bastogne–Liège (‘24, ‘21), Tirreno–Adriatico (‘22, ‘21), UAE Tour (‘22, ‘21), Grand Prix Cycliste de Montréal (‘24, ‘22), and Strade Bianche (‘24, ‘22). He won the Paris-Nice stage race in ‘23. He won six stages of the Giro d’Italia in ‘24 and finished as the overall winner. In ‘24 he became the first person to win both the Giro d’Italia and Tour de France in the same year since 1998. [[PCS](https://www.procyclingstats.com/rider/tadej-pogacar), [Wikipedia](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar)]

- X: [@TamauPogi](https://x.com/tamaupogi)
- Facebook: [Tadej Pogačar](https://www.facebook.com/p/Tadej-Poga%C4%8Dar-100071160199033/)
- Instagram: [@tadejpogacar](https://www.instagram.com/tadejpogacar/?hl=en)
- Website: [tadejpogacar.com](http://tadejpogacar.com)