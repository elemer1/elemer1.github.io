# #354 – What the dying can teach us about living well: lessons on life and reflections on mortality | BJ Miller, M.D. and Bridget Sumser, L.C.S.W.

**Source:** [https://peterattiamd.com/bjmillerandbridgetsumser/](https://peterattiamd.com/bjmillerandbridgetsumser/)

---

B.J. Miller, a hospice and palliative care physician, and Bridget Sumser, a licensed social worker specializing in serious illness and end-of-life care, join Peter to share insights from their decades of work supporting people at the end of life. In this episode, they explore the emotional and physiological processes of dying, the cultural barriers that prevent meaningful conversations about death, and how early engagement with mortality can lead to greater clarity and connection. The conversation highlights the distinctions between hospice and palliative care, the nature of suffering beyond physical pain, and the transformative role of honesty, forgiveness, and relational awareness in the dying process. Through stories and reflections, B.J. and Bridget reveal what truly matters in the end—and how the dying can teach the living not only how to face death but how to live more fully.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/bjmillerandbridgetsumser/the_Drive_public.png)

Play

#354 – What the dying can teach us about living well: lessons on life and reflections on mortality | BJ Miller, M.D. and Bridget Sumser, L.C.S.W.

#354 – What the dying can teach us about living well: lessons on life and reflections on mortality | BJ Miller, M.D. and Bridget Sumser, L.C.S.W.

1x15s30s

0:002:16:00

## We discuss:

- The personal journeys of BJ and Bridget into end-of-life care, and the connection between living and dying [3:30];
- What dying looks like: the physical, cognitive, and emotional realities at the end of life [13:15];
- How historical perspectives on death contrast with modern experiences of dying [25:30];
- The difference between palliative care and hospice care [30:45];
- The systemic challenges surrounding hospice care: why patients often enter it too late to receive its full benefits [35:30];
- How delayed hospice referrals and unspoken preferences often prevent patients from dying where and how they truly want [39:30];
- The realities of home hospice: challenges, costs, and burdens placed of families [43:45];
- How proactively engaging with the reality of death can avoid unnecessary suffering and promote a more peaceful ending [53:30];
- How palliative care is misunderstood and underutilized—especially in cancer care [1:02:45];
- Palliative care in the case of Alzheimer’s disease: emotional support, future planning, and family involvement [1:12:15];
- The importance of having an advance directive: defining what matters most before it’s too late [1:23:00];
- The differences between how young and old individuals experience dying from cancer [1:30:15];
- The difference between pain and suffering, role of medicine in pain relief, and why emotional healing is essential at the end of life [1:35:45];
- Dying well: the power of self-honesty and human connection at the end of life [1:47:00];
- How psychedelics like psilocybin can unlock emotional breakthroughs and deepen connection for patients near the end of life [1:55:15];
- Lessons from the dying on how to live well [1:57:30];
- The physical process of active dying, and the emotional and practical considerations for loved ones [2:09:30]; and
- More.

---

## Show Notes

\***Notes from intro**:

- The guests this week are Dr. BJ Miller and Bridget Sumser
- BJ is a hospice and palliative care physician with expertise in serious illness, end of life issues, and death
- He is the cofounder and president of [Mettle Health](https://www.mettlehealth.com/) ‒ an organization providing support to patients and families living with illnesses
- BJ was a previous guest on *The Drive*, all the way back to November of 2020
- Bridget is a licensed social worker who specializes in helping people with serious illnesses, promoting connection and wellbeing, and working with patients and their families during end of life periods
- In addition to her private practice, she is a provider at Mettle Health and the [Palliative Care Program at UCSF](https://palliativemedicine.ucsf.edu/patient-care)
- Peter wanted to have BJ and Bridget on to have a conversation about the insights gained from working with people at the end of their lives
  - What do they reflect on
  - What do they find most important
- What Peter really wanted to understand: What can the dying teach the living?

In this episode, we discuss

- The physiological and emotional processes of dying
- What happens as the body shuts down, and how families interpret those changes
- Why cultural aversion to discussing death leads to unnecessary suffering
- How acknowledging mortality earlier in life can be empowering
- The differences between palliative care and hospice
- How our healthcare system often delays comfort-focused care until it’s too late
- What suffering really means
  - How it’s not just physical pain, but a threat to one’s identity and reality
- The importance of honesty and emotional courage at the end of life
- How dying can bring profound emotional, spiritual, and relational clarity
- Insights from decades of working with people who are encountering their death
- What patients regret, how they grow, and what really matters in the end
- We talk about this idea of how people die the way they lived
  - Why cultivating emotional, spiritual, and relational awareness while we are alive shapes how we die, probably more than anything else
- We talk about the role of forgiveness, acceptance, and connection in dying
  - Especially self-forgiveness and the ability to be with what we can’t control
- Ultimately, we talk about what the dying can teach the living
  - Not just in terms of how to die
  - But perhaps more importantly, about how to live

## The personal journeys of BJ and Bridget into end-of-life care, and the connection between living and dying [3:30]

- BJ was a previous guest on the podcast he spoke a little bit about some of the topics we’re going to get to today [[episode #135](https://peterattiamd.com/bjmiller/)]
- When Peter reached out to him a few months ago to talk about this podcast, he immediately suggested bringing Bridget along
- Peter wanted to understand more about living and thought we could learn a lot from people who are dying
  - People who listen to this podcast know that Peter thinks the quality of life matters as much, and potentially more than the length of life
- A big part of that comes down to things people think about during their life and during the end of their life
- Maybe there are regrets that people have that only surface at the end of life

**Why is this a great three person discussion as opposed to a two person?**

- BJ loves the setup for this conversation
- It’s not quality of life versus quantity of life (kind of false dichotomy)
- BJ has worked with Bridget in a myriad of ways over the years
- They are going to thwart the idea that there’s an objective, an approach to death that is the way to go
- They’re not going to cite much data, it’s not an easily studied phase of life
  - What data exist tends to be qualitative

***With all that subjectivity, it feels really important to have other voices sharing their point of view of a similar outlook (thats in part why he wanted to include Bridget)***

- BJ’s work in the last four years has pulled him farther away from being at a bedside
- Both BJ and Bridget have spent many countless hours in hospital bedsides and other places that they’ll be drawing from

**To get to the questions that Peter is interested in answering, so much of the work preparing for dying begins earlier in life (one way in another)**

- For the audience to imagine deathbed scenes that in the final moments there’s this great epiphany or climax ‒ that can happen, but that’s really not the norm
- A lot of the action is in the days, weeks, months, years preceding the death moment
- Death is a moment
- One thing they want to get across is we need to bring dying and living together
  - They are part of a whole, they’re not at odds
- And so when do we begin dying?
  - The second we are born
- So in some ways, all of us have some access to this subject already
- Bridget and BJ are just a little bit closer to it on some level

**Bridget, what drew you to this space? It is an uncomfortable place to stand, what’s drawn you to it?**

- We all have our places in the world, and while this is an uncomfortable place maybe from the outside, for Bridget, it is a pretty comfortable place, and that was what got her there
- She had many people in her life die
  - She was in pretty close proximity to those deaths and she wasn’t freaking out
- She looked around and a lot of other people were freaking out, and she was sort of like, “*Oh, this is weird. Am I unaffected? Am I guarded in a way that makes it some kind of numb?*”
  - No

***Actually it was more just that there was something in her that was okay around dying and also really curious about it***

- That’s how she got to this work

*What were some of the experiences you had growing up?*

- Bridget’s cousin Kristen died when she was 13 and Bridget was 18
- She had pulmonary primary hypertension
- Bridget was with her the day she died
- As you can imagine, a 13-year-old dying is a pretty chaotic scene
  - She was not in an official dying process that anyone was recognizing
  - It was crisis-y and traumatic and there was just a stillness in Bridget
  - Bridget was very affected, there was a lot of emotion
    - She felt fear and overwhelm, but she also felt really able to be there
- Bridget was 18 and the adults around her were all over the place
- It was less about others, although she felt quite connected to Kristen

Bridget shares, “*It was more about being able to stay in my own body and be in my own experience and pay attention to what was happening, make contact with what was happening.*”

- It was a pretty internal experience and awareness
- It wasn’t until later experiences with one of her best friend’s moms a few years later that Bridget felt that capacity in relationship to others as a main supporter
- That first imprint was really like, there’s something in this experience for Bridget

**People who listened to the earlier episode with BJ will be familiar with his story**

*For those who aren’t, can you give the super “Reader’s Digest version” of your story and how it probably shaped a lot of what you do today?*

- For sure it did
- BJ went into medicine very simply because he had been a patient
- At age 19, a sophomore in college, around the time Bridget was having her experience at the bedside one way or another, he was in the bed thanks to an electrical injury at Princeton
- He was screwing around on a commuter train and climbed up on top
  - He had a metal watch on his left wrist and the electricity arced to the watch
  - That was that, and he became very close to death
  - You could say part of his body died
  - He lost both legs and one arm (part of them)
  - That was a really big wake-up call
- Peter points out the magnitude of the burns BJ sustained, the skin grafts that required

*How long were you in the hospital?*

- BJ was in the burn unit for about 3 months
- Burn units are horrible ‒ these are houses of pain of a certain kind
- He was on the edge for about 3 months

Peter asks, “*Did you lose kidney function?*”

- BJ doesn’t recall
- He remembers looking over at the monitors many weeks in and his heart rate was 190 and just sitting there
- There’s a lot of fallout from an injury like that, and it takes a long time for the body to settle in and declare what’s going to live and what’s not
- The amputations were sequential
  - They take a little bit, see what tissue’s viable
  - All the while the risk of infection…
- The way generally people die from burns is infection
  - Because you lose immediate defenses through your line of defense of your skin
  - So [you live in] a hyper sterile environment, no windows, nothing natural about it at all
- It was a long time until he was “out of the woods,” and it was clear he was going to survive

*Then becomes this longer work of learning to cope with this new body*

- It entailed a lot of mourning, a lot of grief, a lot of effort, a lot of creativity on his behalf, as well as a lot of people around him
- It took many, many months to get out of that setting from the burn unit, into a step-down unit, then into a rehab unit, and then outpatient
- Then begins the work of re-entering the world
- That’s its own challenge with a visible disability
  - BJ used to be so ashamed of the skin grafts; he used to cover it up
- There was the work of getting used to it and being comfortable in his own skin, literally, again
  - That took about 2 years before he was willing to show anybody this
- After 5 years, he hit another milestone: inhabiting his own life again on some level
  - Being anything other than an object to glare at

***It’s a very slow process and it’s ongoing***

- BJ recently had a procedure that’s a fallout from a central line that was being placed in his neck that got botched and clotted off (35 years ago)
- He gets new legs every 2 years or so, and that’s its own process

## What dying looks like: the physical, cognitive, and emotional realities at the end of life [13:15]

- A moment ago, BJ alluded to the idea that movie deathbed scenes are probably the exception and not the rule
- Peter wants to explore this idea a little bit more
- He also wants to help people understand at the population level, what death really looks like
- On this podcast we talk a lot about causes of death
  - The 4 horsemen
  - We know about cardiovascular disease, and we know about cancer, and we know about neurodegenerative disease, and we can talk forever about these things
- But we don’t really talk about the very, very end, perhaps with the exception of a fatal [myocardial infarction](https://en.wikipedia.org/wiki/Myocardial_infarction)
  - About 50% of MIs are fatal
  - But about 50% are not, and they’re just setting you up for maybe heart failure or something else

**Explain the mechanics of death ‒ the moments leading to death, as the body is shutting down**

- We can start with the more common cause of death, which is cardiopulmonary death
- We can talk about brain death after
- Describe what’s happening both medically, socially, cognitively to the individual through that process

*BJ explains the medial physiology*

- Anatomical physiological things happen as a body is trying to die
  - BJ likes that phrase, “Trying to die,” because we often find ourselves intervening in a body that’s trying to die
- Living things die
- A lot of us absorb a notion of death that it’s some foreign invader or something that comes out of the woods and grabs us, otherwise we were just fine and then not
- As you know, there are all sorts of things we can do to promote life, and there are a lot of ways we’re wired to hang onto life and to run from anything that’s a threat to us
  - Those are all true and all natural
- But included on the list of natural things that we do is die
  - That’s what a body’s supposed to do

BJ explains, “*There’s nothing wrong with you for dying. This is the way it’s supposed to go, so your body knows how to do this*.”

- In general, depending on the cause of death, there’s a final common pathway of a body shutting down, and it tends to shut down by organ system
  - Whether the pathway might be cancer, or heart disease, or neurodegenerative diseases
- It doesn’t follow a neat and tidy pathway
- It can happen spontaneously, in a moment, they’re here and then they’re gone
- But very often (especially these days), >80% of us will die of chronic illness
- We will meet the thing that eventuates our death well in advance of the death
  - We’ll get that diagnosis that someday will be the thing that ends our life
    - We could talk about that, that’s its own ball of wax that comes with that fact
- Whereas in the old days, most of us died more spontaneously
  - You’re very alive and you’re very dead
  - Not a lot of in-between
- This in-between thing is this shutting down phenomenon
- Oftentimes if we’re trying to prognosticate, help a person or a family **get a sense of how much time is left**, we’re looking at things like are they in and out of bed much?
  - Are they getting up and out of bed?
  - If you’re asleep on the couch or in the bed 50% of the day, that’s a progressive process (more and more fatigued)

**⇒** Progressively increased fatigue in the context of chronic illness tells us we’re heading towards the end

- An interest in food and fluid is a big one
  - When a body is trying to die, a GI tract that’s on its way to shutting down will stop sending hunger signals

BJ emphasizes, “*This is a big one for the audience to hear because [for] a lot of us, food equals nutrition equals nourishment equals life. So if we see someone we love or ourselves not eating, the impulse would be, well put some food into us. That’s life. We don’t want someone to starve to death.*”

- It’s also about love ‒ that’s how we show our care

**⇒** The body is sending a signal: don’t put food (or fluids) in me because it will hurt

- If a gut is not able to process the food, it sits in place and can cause pain
- Same with fluids
  - If we’re forcing fluid into a body that’s trying to die, that fluid will pool and cause trouble
- The judgment of call when to push the food and fluid and when not is up to really a dialogue (and response) with the patient
  - You might try a little bit of fluid, and if that ends up in their lungs or ends up swelling, then we pull back

***As a body’s trying to die, it will stop sending signals for food and fluid, and that’s to be generally respected, not pushed past***

Mental status changes as a body is trying to die

- People often get really fuzzy in their thinking
- Delirium is very common
- Oftentimes they’ll be disoriented, think it’s 1912 and they’re in a forest somewhere when they’re in a hospital bed
- Peter points out that delirium is not uncommon in the hospital
  - A lot of times with otherwise very healthy patients who are in the hospital to get surgery, the loss of circadian rhythm, the use of narcotics and other medications can easily induce delirium in a person who’s otherwise not going to die

Peter asks, “*Is this a different form of delirium and what is really underpinning it?*”

- BJ doesn’t know that it’s a different form of delirium, per se
- It’s a similar pathway in that it looks the same
- You can have a **hyperactive delirium**, which are very easy to spot
  - Someone’s jumping up and down on their bed and going nuts and acting in a way that’s not comporting with the context of sitting in a hospital bed
- Very often it’s **hypoactive delirium**, which we often miss, especially in the hospital setting
  - It might just be a little tangential thinking or not quite clear on what day it is, something that’s not so obvious
  - Very often the person’s just silent at the end of life
  - It may be hard to spot and the person’s been sleeping a lot anyway, so you might miss it

> “*One reason to bring it up is because if you don’t know what to look for, I think a lot of family members and loved ones will be at the bed trying to eke out every last moment with this person and looking for clues about what’s going on for them, and last relational moments and exchanges*.”‒ BJ Miller

- BJ has heard a lot of reports from people who are traumatized because a loved one’s last words were something vulgar or harsh

**⇒** Please keep delirium in mind because the person who is delirious is not themself

- You cannot really take what they’re saying literally

*Bridget talks about some of the social stuff*

- Delirium at the end of life we take as seriously as we would in a more acute setting where someone’s in the ICU with expectation to recover
- We think about environmental factors that influence delirium like lighting and noise and interruptions
- Because if we can minimize delirium, we want to
  - We want to treat it and care for it

The other thing to point out is that we enter into the rich and nuanced and complicated space of interpretation and the meaning that’s being made around what’s happening

*Bridget was sitting at a bedside once with two daughters and their mom who was dying*

- The mom hadn’t really talked in a couple of days
- They were sitting there talking about her and telling stories
- Her kids are telling Bridget about her
- She opens one eye and she kind of sits up and she says to her daughter, “*I love your jacket.*”
- Bridget looks to the daughter and the daughter just bursts into tears
  - Bridget was thinking this was so nice
  - The daughter’s like, “*She’s never complimented my clothes before. If anything, she always looked at my dress in this critical eye. This is so off.*”

***That could be one of those projections, we’re going to get to the end and mom’s going to say the thing that we never heard them say, and that might not feel good***

- It’s complicated and so interpersonal and personal and subjective

*It’s one of the reasons why Bridget and BJ are here together and why this work is done often in teams*

- Because we could both be in the room with the same person and have very different hits or interpretations around what’s happening, what’s most important in the room, what needs to be tended to

*In this state of delirium (altered consciousness) and what people are saying*

- Sometimes deep dark secrets get revealed
- So much  needs to be interpreted and held lightly

> “*These are final moments, you may never get the clarity of what mom or dad or that person actually meant in that comment*.”‒ BJ Miller

***Another trick to holding death is to hold it lightly***

BJ explains, “*We will find ourselves wanting to apply a story of meaning on all of this stuff, as a human it’s what we do, but one of the great lessons around this work is just to hold that carefully and lightly. It’s not always what we think it is*.”

- As a medical person, BJ was taught that delirium is inherently a kind of suffering
  - That to be confused, to be disorient is itself uncomfortable
  - It’s certainly problematic for the loved ones
- We always medicated it with antipsychotics, [haloperidol](https://en.wikipedia.org/wiki/Haloperidol), [Thorazine](https://en.wikipedia.org/wiki/Chlorpromazine), and others, just shut it down
- BJ is not so quick to shut that down
- There may be something vital happening for that person in the bed to express whatever’s in there, and it may be something that’s helpful for the person to hear
- Earlier, BJ gave the counterpoint that it’s hurtful for a loved one to hear in a decontextualized wa

**⇒** But one of the meta messages here is dying can’t always be so tidy and immaculate and clean and perfect

- BJ and Bridget both like to disabuse that notion of that that’s a good death, a quiet death

**BJ would not medicate a delirium unless he had a conversation with the patient beforehand**

- He’d say, “*Peter, hey, there might be moments where you can get a little confused, etc. If that happens, would you rather?… Would you like us to err on the side of medicating that and help you sleep through it or talk to family about that?*”
- The bottom line here is it’s not such a one-to-one thing
  - When we see delirium, that means suffering, that means medication
  - It’s much more mysterious than that

## How historical perspectives on death contrast with modern experiences of dying [25:30]

- One thing Peter has been thinking a lot about lately is how people died hundreds, thousands of years ago, before the advent of any medicine at all
- Admittedly, they weren’t living that long
  - Life expectancy would’ve been into the mid to late 30s, but people always confuse that for meaning
  - Of course, it’s not true that nobody lived beyond that
  - It just means so many people died young
  - Infant mortality was through the roof
  - Tons of trauma and infection
  - But clearly there were people that were living into their 60s, and some of them were dying of cancer

**Peter wonders, absent any medicalization of death, what death looked like then. Do we know anything about this?**

- BJ doesn’t from the books, but he can imagine
- We knew that people died more acutely
- But that’s probably because they didn’t know they were harboring a tumor or atherosclerosis, whatever else
- BJ thinks the average human had a different relationship to the day-to-day suffering and pains that went with being alive

> “*I think modern life has tempted us with the idea that we could always be comfortable and that pain is a problem to root out and fix quickly, get back to the norm, which is comfortable always, which is just crazy talk*.”‒ BJ Miller

- Part of it is we’ve induced people’s pain by offering these fixes to them
- By virtue of having something to offer your suffering, we might be more primed to tune into our suffering and seek that fix for it
- Back in the old day, BJ doesn’t imagine that people were so distracted by their daily aches and pains

***BJ doesn’t think we know from a historical perspective; he couldn’t tell you factually what used to be the case***

- But watching patterns and knowing that human nature hasn’t probably changed so much in the last couple hundred years, he thinks that people lived closer to death and lived closer to pain
  - So in some ways they suffered less because it wasn’t tainted by a sense of injustice or why me
  - BJ shares, “*I’m projecting*.”
- Peter thinks this is an irony because as he thinks about a person dying in their 80s today, he thinks of that as a remarkable privilege that we could be alive in this period of time where we could make it into such an old age
- But yet at the same time, it feels like a tragedy, even though ironically the tragedy is those people that were dying thousands of years ago

*Let’s take an example of an individual who is cognitively completely intact but is faced with a terminal illness*

- Somebody that’s got something as debilitating as [Lou Gehrig’s disease](https://en.wikipedia.org/wiki/ALS), where their mind is completely intact and they’re suffering a neurologic disease that’s going to kill them
- Versus an individual with a cancer that has metastasized and is just a matter of time
- When talking to somebody about the decision to enter hospice care or palliative care

Peter asks Bridget, “*What are their greatest fears when they come to you, and where does physical pain and discomfort rank on that list?*”

- The path that gets you to the intersection where you are thinking about entering hospice (or able to tolerate that idea) is very different if you’re facing neurologic illness or cancer or heart failure
- The experience that patients and the folks around them have had may be quite short, may be a decade (with really successful treatments)
- It may be this downward feeling slope the whole time
- You’re primed in different ways depending on what this last chapter has been like
  - Have you been in and out of the hospital, in this endless cycle?
  - You’re holding very different experiences, and people have honed their muscle of adjusting and adapting and adjusting and adapting very differently depending on their experience of the illness they’ve had
- It’s also really colored developmentally, depending on where that person is in their life
  - Are they 42 with two young kids?
  - Are they 85 having lived a life they feel pretty good and full about?
- Those are a few of the layers of context that really inform

## The difference between palliative care and hospice care [30:45]

- Peter realizes how much there is to unpack here and wants to go into all of that in a moment

**⇒** Bridget thinks of palliative medicine as the big umbrella, and hospice care is the very end of the umbrella

***Palliative care is a medical specialty usually provided by a team for folks with a serious illness***

- Serious illness can be defined lots of ways
- It is defined differently in different health systems depending on how they’re staffed and how their palliative care programs are created to function
  - What purposes they’re serving
- Some of the big differences is that **with palliative care** generally, there’s no limitation around any disease-directed or modifying therapies you might be pursuing
  - You don’t have to be dying inherently or even clear that you’re facing death
  - You could be diagnosed with a very serious cancer that actually has pretty robust treatments, and you could live for quite a long time

Peter asks, “*So in that situation, what is the objective of the palliative care team?*”

- To think really holistically about who is this person?
- Where are they in their lives?
- How do they make sense of what’s going on?
- What do they understand about their illness?
- Who’s supporting them?
- Are there ways that we can help this person feel as well as possible, to treat the symptoms related to serious illness, to treat the symptoms related to the treatments of different serious illnesses, but in the context of a whole life?
  - Which means on a clinic day you could be seeing two people that seem on paper generally the same, similar age, demographic backgrounds, diagnoses
  - And be dealing with really different things when you walk in the room

> “*No matter how you slice it, the focus is quality of life, period, whether it’s palliative care or hospice*.”‒ BJ Miller

- It’s inherently **interdisciplinary**, and that’s why Bridget is a social worker and BJ is a medical doctor, but they work with chaplains, nurses, music thanatologists, potentially art therapists, volunteers
- When the subject matter is suffering and quality of life, there’s no one discipline that has a lock on that stuff

***Whether it’s palliative care or hospice, the focus is really on helping someone feel as well as possible, and that is an inherently holistic question because it gets at their identity***

- For someone that could mean very aggressive pain management
- For someone else, they could have a different relationship to the experience of pain and they wouldn’t put that at the top of the priority list
  - They might put more concrete or relational supports higher up on their list

Bridget explains, “*The beauty of our jobs and our work is to meet this person in this moment in time and identify what’s up for them, what’s most important, and where it is that we get to meet them to work towards quality of life as defined by them*.”

**What is the transition then for an individual from being under the broad umbrella of palliative care into a more narrow, defined level of care that is hospice?**

- There is the world of ideals in that, and then there’s what actually happens
- The reality in this country is that folks are admitted to hospice very, very late

**⇒** The length of stay on a hospice program in this country is something like a 3-week average (very short)

*When Bridget thinks about when hospice is a good fit for folks*

- She thinks about wanting to stay out of the hospital
- Being in a place where they are ready to or being forced to grapple with the reality that there is not anything left to do to change what is happening in their body
  - To change the cancer
  - To delay the neurologic illness
  - Folks that are more explicitly ready to be supported in their end of life care or in their transition
- To be done with chasing the treatment
  - Done with the chemo
  - Chemo might have something more to offer them in terms of life spent, but they are just electing to be done with that
  - There may be nothing left to try, or they feel done with what’s left to try

## The systemic challenges surrounding hospice care: why patients often enter it too late to receive its full benefits [35:30]

**3 paths to hospice**

- 1 – Hospice in your home
  - Where you go back to your home and a hospice team comes there and cares for you in your home
- 2 –  A palliative care ward inside a physical hospital that provides hospice care, but it’s still within a hospital
- 3 – Outpatient hospice facilities
  - Dedicated facilities for hospice that are not hospitals

*Would those 3 encompass how hospice care is delivered, or is there another one?*

- This is where it starts to get really wonky and complicated
- There’s so many tributaries

**BJ clarifies a few points about palliative care and hospice care**

- He agrees that palliative care is the larger umbrella

***Hospice is the subset of palliative care devoted to the final months of life***

- They have the same philosophy in a lot of ways

**⇒** But by insurance and reimbursement lines and by policy designation you can get palliative care alongside curative intended care; you cannot do so in hospice

- When you go on to hospice, you have to give up that curative intended care
- Generally in hospice, you can’t have an IV line

*The way it’s set-up is a crossroads*

- Dying and living look a lot alike, but in the man-made world of policy and healthcare structure, there are some important forks in the road

To go into hospice

- 1 – You no longer have access to or don’t want curative intended care and things that go with it
- 2 – Someone somewhere has to certify that should nature run its course, you likely have 6 months or less to live

***Those are the 2 forks in road to qualify for hospice, and neither of those applies for palliative care (that’s a really important distinction)***

*While palliative care is the larger umbrella, hospice is the older one*

- We started in this country with hospice
- And since the 1982 (when Medicare got in the business), we had those restrictions
- Then people in the ‘80s and ‘90s realized, “*Why are we waiting until the final weeks and months of life to deliver this kind loving care?*” And so that palliative care was born

**Peter’s takeaway**

- Hospice was the original care and people entered it when they had 6 months of life expectancy
- Today, we’re at a point where the mean is 3 weeks of hospice care
- When we think about what an individual looks like when they have 3 weeks left of life
  - This is usually a person who’s already in delirium
  - They are already in the early stages of organ failure
  - They are probably already spending more than 50% of their time sleeping

Peter asks, “*Should they have been moved into hospice sooner? Have they been unnecessarily discomforted by pursuing therapeutic intent until that three week mark on average?*”

***In broad strokes, the answer is yes***

- We know that patients and families wait too long
- They’re suffering more than they need to and taking on treatments that are no longer helping them for a longer period of time
  - That can feel like a charade portion of care
- There’s a lot of reasons
  - Patients and families not wanting to look at that piece of the puzzle yet (denial)
  - Referring physicians perhaps is the bigger reason that they are not seeing the writing on the wall
  - It’s very often that the physicians don’t bring up hospice until way late in the game

***We wait too long based on our own stated goals of feeling peace and having some comfort towards the end and not wasting our time doing things that don’t help us***

## How delayed hospice referrals and unspoken preferences often prevent patients from dying where and how they truly want [39:30]

**Peter’s wife told him a story about one of her very close friends who died in 2018**

- She had an abdominal cancer, and her wish was to die at home
- She was readmitted for a bowel obstruction, and she was never able to get out of the hospital, so she died in the hospital
- This is also probably not an uncommon situation where Peter thinks back to patients he took care of
  - Where heroic measures were done
  - Maybe someone had an aortic dissection or a ruptured abdominal aortic aneurysm
  - They’re old, they already have organ failure, you go ahead and do it
- But this is a person who was cognitively completely intact when they came in, 3 weeks later, they’re intubated, they’re on dialysis
  - You can’t transfer that person to hospice because they can’t have the ventilator, you can’t have the dialysis
  - The moment you turn those things off, the person expires
- So they’re going to expire in an ICU
- Never what they wanted probably

**How often in your experience are people in that no man’s land where they now have missed the window to go into hospice?**

- It’s not uncommon
- BJ doesn’t have numbers to cite
- That’s why the second he hears someone say, “*I never want to die in a hospital,*” his ears go up as a potential referrer like, “*We should really look to get this person to hospice as soon as possible*.”
- Peter has never met anybody who wants to die in a hospital
- He doesn’t want to die in a hospital
  - He hopes his death is 35, 40 years away (if he’s lucky)
- He’s watched too many people die in a hospital

Peter shares, “*It’s never, ever, ever what you imagine it should be or could be. The goddam beeping, the smells, the noise, the chaos. It is awful*.”

- If BJ was in any way involved in Peter’s care, he would just pull up a chair and say, “*Peter, I heard you say that buddy. And first of all, I might ask you, is that a throwaway comment? Do you mean that today?*”
  - Really get behind with what Peter is saying there and to see how durable a choice that is
- Then he might say to Peter very explicitly, even in the abstract, “*Peter, someday as you know, there’s going to be something that’s going to come along that’s going to eventuate your death. So you and I are going to keep a real hawk’s eye on this together, and there’s going to be crossroads along the way around treatment decisions*.”
  - What your oncologists or cardiologists or whoever Dr. may not share with you is what it means to take on this treatment and what might happen
  - Together you and I will interrogate all these decisions and really dig in to see what might land you unexpectedly in a hospital in ways that you’re going to feel stuck
- BJ would also say, “*Peter, part of dying well is also letting go of all the things you can’t control and there’s only going to be so many things that we can dictate*.”
- Peter agrees and adds that he could get into a car accident tomorrow that sends him to an ICU where they struggle valiantly to save him, but he still dies
  - That means he’s dying in a hospital
- BJ would disabuse Peter of some absolutism around this
- But Peter has just given them marching orders as the thing to look out for him as Peter Attia
  - To not suffer more than he needs to
  - Where Peter is when death comes is a huge point for him, so that’s noted
  - So we’ll wrap that into our care together as we move through time and we’ll make decisions with that in mind
  - That is because he was explicit about it

***Most people don’t want to die in a hospital but that conversation rarely happens ‒ that goal needs to get added into the care plan***

## The realities of home hospice: challenges, costs, and burdens placed of families [43:45]

**Examples where that discussion has relevance**

*When a person is still in palliative care before transitioning to hospice, are you sometimes waiting to have that discussion about where to go to hospice for the first time?*

- It depends on the kind of clarity or adamance a person comes into
- It might be one of the first conversations you have
  - If somebody’s had a really visceral experience in their own life, it could be the first thing they’re thinking of with the diagnosis of an advanced cancer or something
- It may be a conversation that’s happening weeks into hospice depending on how things have evolved with the family and/or how they’re changing

Bridget steps back and shares, “*I have seen very beautiful hospital deaths*.”

- Peter is jaded because where he came from, you’re running codes on people who are dying
  - They’re dying while you’re doing chest compressions on them and you’re shocking them, and you’re breaking ribs
  - That’s a very narrow point of view
- Bridget is not a physician so she hasn’t had this experience
- She thinks coding someone while they’re dying is potentially an incredibly painful experience for the team providing that care
- She has seen beautiful hospital deaths
  - People very clear in their sense that not dying at home is the goal
  - That to die in their living room with their kids watching is intolerable to them to know that they’re leaving their family with that imprint
- Because it is an experience that we’ve plucked out of our living rooms, and most people don’t have a familiarity or comfort with it
- Plenty of people, especially younger people who are dying, are very clear like, “*No, no, I’m not going to do that at home. And if that means I’m in an acute care setting, okay, that’s fine with me and preferred.*”
- Peter thinks from an insurance perspective, that must factor into this

**Is there a fundamental difference in what an insurer, either CMS or otherwise will provide based on those options?**

- The lion’s share of hospice is what they call and reimbursed for as **residential hospice**
  - Which means in a place someone is living ‒ their home, their assisted living, in a car sometimes
  - It could include hospice facilities like the hospice residences
    - Which are uncommon in this country

**⇒** 80% of hospice happens where people live

- The remaining 20% is either in a hospital hospice unit, a dedicated hospice facility, or a nursing home
- Peter would have assumed that the most economical and desirable place to provide hospice care would be in a dedicated facility

**Being a social worker, Bridgen has had hundreds of conversations to describe hospice and give hospice education**

- The assumption is hospice is a place that you go to die
  - Overwhelmingly, that is not true

**⇒** Hospice is a service that comes to you where you are

- There’s a lot of people that feel if you’re suggesting hospice, you’re going to send me away to die
  - And that is a barrier because people don’t want to be sent away
- But then there’s also disappointment of, “*Oh, there aren’t a plethora of choices of places for me to go, we actually have to figure out how to hunker down and make this happen at home.*”

**What does that mean in terms of resources? What is provided?**

*For example, an elderly couple live alone and one of them becomes terminally ill and elects hospice*

- Let’s assume the husband is sick, and the wife is not physically able to do much
- She was able to care for him before he had one critical last event
- He is sick, but then he falls, and that’s the straw that breaks the camel’s back

Does the home provision cover full-time support?

- No, nothing even remotely close

Peter asks, “*So how would she care for him if he is now bedridden, requiring pain medication, requiring medication for sedation, and any other form of comfort care? How would she clean him?*”

- This is point to one of the biggest systemic issues we have in this space

**⇒** There is little to no reimbursement for caregiving

What does home hospice mean then if you’re not giving that?

- It means an expert team that’s available 24 hours a day, and they come to you basically as needed
  - That could be once a week, that could be once a day
  - The goal is often a couple of times a week

***This is part of why hospice is underutilized, because it doesn’t always have the resources that people need to manage care at home***

- The reality is that when somebody goes home, it’s usually a communal effort
- Folks are coming in and out when they’re not working, they’re taking off time working, they’re pulling in friends
- If there’s the resources, they’re hiring caregivers, which is quite expensive thing to do

> “*It’s a huge lift on caregivers, care partners and families to have someone die at home.*”‒ Bridget Sumser

***If a person elects home hospice care and they need full-time support, they’re paying for that out of their own pocket***

- That’s can’t be cheap

**There’re multiple ways to hire caregivers**

- In the Bay Area for example, the hourly range would be something like $20 to $55 an hour, kind of depending on if you’re hiring privately in your community or agency
  - That’s not a  nurse
  - That’s a home health aide

BJ shares that a lot of us in the abstract would say, “*I want to be at home when I die.*”

- But then when it comes down to it, when weeks turn into months and the family is burning out
  - Because at least 23 hours of the day is family and friends doing the work
- When it comes down to it, that is not always necessarily the easiest place or possible

**Back to the question about why are there not more hospice houses**

- If they’re not willing to pay to have someone come to your own house, they’re certainly not going to pay for you to have a facility

Bridget explains, “*The medical system separates the social services from medical services. So the room and board of a facility, the infrastructure of the house, those will not be considered medical issues, so therefore are exempted from coverage.*”

Bridget worked at one of the very few hospice houses in the country

- This sweet little six-bed hospice was known all over the world
- It couldn’t make it because there was no financial pathway
- It’s complicated
- There should be more of these places
- To note around Peter’s very reasoned incredulity there, because it’s much less expensive when the alternative is to go back to an acute care hospital
- But this is not a rational system per se

**Back to the example of the elderly couple**

- Where he’s dying and she’s home and she can’t bathe him, she can’t deal with his bedpan
- It’s why you see in those stories, people go into the hospital, go to subacute rehab, max the Medicare days, go home, then go back into the hospital
  - The effect (though not always explicitly intended) is how do we maximize the benefits that are here?

**Peter’s response**

- It’s one of those examples where the payer experience, the provider experience, and the patient experience would all be better with a different system
- Unfortunately, medicine is full of these, especially in the US
  - He has a lot of great things to say about the healthcare system here
  - There’s probably nowhere he’d rather live with respect to healthcare
- It’s more expensive, it’s worse for the patient, it’s worse for the care team to have the patient do what they have to do now to game the system
- It’s a real shame that even if you didn’t care about the quality of an individual’s life, if you just acted economically

Bridget agrees and adds, “*That’s part of the joy and craziness of working in this part of the healthcare system. You get a line of sight, as you say, there could be this alignment where it’s better care for everybody involved and costs less money… This stuff works, but it’s still not routinized in the system for all sorts of reasons.*”

- The whole palliative care and hospice world has done a really good job over the last 40 years of gathering data
- We’ve saved the health system lots of money, we improved care
- The 6-month prognosis component of the hospice benefit was really an arbitrary choice in some ways that was about getting it funded
- Originally, it was thought to be a year
- But the fact that it’s 3 weeks on average tells you how many resources are being drawn out of the highest price provider

## How proactively engaging with the reality of death can avoid unnecessary suffering and promote a more peaceful ending [53:30]

**Thinking about the last weeks and months of life**

- The swirl that’s happening because you’re getting sicker
- All of these things are changing in your life
- Your touch with the healthcare system is really high
- That is also a time to get really sober (maybe for the first time) about what’s important to you
  - Where do you want to be? Can you see this thing clearly?

***It’s almost an impossible time to do that***

**This strikes Peter as a cultural issue**

Peter observes about Bridget, “*You two live in this world. I would say I’m adjacent to the world, but I don’t live in it and most people aren’t even adjacent to it. So death is a really foreign thing*.”

- The reason he suspects this gets kicked down the road so much…
- After all that kicking, people get to the end of their life, and there’s no road, there’s just a pile of cans

*What is it culturally that prevents us from talking about this when we’re 50, when we’re 60, when we’re 70? (when we’re 30?)*

- It’s just something we don’t want to talk about
- It’s 3 weeks and you fall off a cliff kind of thing

*Do we know anything about other cultures? Do we know anything about how end of life functions there?*

- Culturally, there’s a lot to study
- It’d be fun to take a couple years and really study the anthropology around dying and how cultures do this differently

Scandinavian cultures and Japan are places that venerate its elders and aging and dying are different, but they bump into each other a lot

- BJ’s armchair read on life in Japan where the comfort of being in old skin might be a different experience, but you’re still left with this sort of natural phenomenon, culture phenomenon of aging, bumping into this healthcare system idea
- The cognitive dissonance, we have
- These systems that are engineered and wired in such a way that are so at odds with mother nature on some level and so blind to cultural issues in the name of science in so many sort of reductive ways

***Even still, if you were in Japan, you’d still find a healthcare system that struggles with this question even as the culture maybe doesn’t as much***

- Similar probably in Scandinavia
- In the Scandinavian model, one of the things that comes up for people at the end of life is other living issues like housing, like your relationships
  - They’re still there

***One of the things that makes dying harder in this country is the social determinants of health in society are not cared for***

- You still have your housing issues when you’re trying to die
- You still got bill paying things that are…
- That’s the stuff that makes dying extraordinarily hard in many cases

Peter asks, “*So you’re saying the wider net of the social safety net… presumably just adds one more stressor to an already stressful situation?*”

- Largely
- And in any one sense doesn’t do it justice because the healthcare systems in these places can also do amazing work
- BJ doesn’t want to just blindly categorically denigrate a healthcare system in any country
  - There’s some good things happen
  - But it’s such a mixed bag
  - As many problems as it solves, it creates some other ones especially around issues that people struggle to look at

**Thinking about the reality that we will die someday**

- To Peter’s point, we do have a problem and that is why Bridget and BJ came this far to talk about this
- It allows an audience as large as yours to begin to think about this before it’s too late

> “*This is I think all of our work as citizens, to begin to rope this part of reality into our view so that we can prepare ourselves for it and we can live with these realities and not be so surprised by the fact that we die someday.*”‒ BJ Miller

We need to

- 1 – Learn how to advocate for ourselves versus
- BJ would love to see our health system mature around these issues
- 2 – The bigger note for the audience is what can each of us do to prepare ourselves in ways that the health system is not?

**⇒** To die well in this country, at some point you kind of have to say “no thanks” to medicine

- 3 – You need to appreciate that the default modes of our healthcare system would be just do more stuff, prop your body up, anything to give you a pulse
  - This is why [advanced directives](https://en.wikipedia.org/wiki/Advance_healthcare_directive) are so helpful
  - Unless you’ve written or stated otherwise, we’re going to try to protect you (keep you having a pulse)
  - Most of us don’t equate having a pulse with actually really being alive and that becomes a problem at some point
  - We’re in this carnival where we can really prop up a body almost indefinitely

BJ explains, “*You have to find a way to say no to that and unwind what that hospital can do. You have to get out of the way of that to die peacefully in this country*.”

**Peter reflects on the internal struggle that most nurses and doctors experience**

- They don’t talk about it much
- He remembers during residency, the pride he took in how heroic they could be
  - What they could do for a patient in the ICU
  - How many central lines he could put in a patient
  - How he could look at all the different [bacterial] cultures and figure out the 5 antibiotics a patient needed
  - How good he was at managing a patient’s dialysis and getting that CCVHD to manage the pressure and this and that
  - How he could alter the intraaortic balloon pump to keep your heart
  - There was a sense of awesomeness in this technology
- But then you take a step back and you’re thinking, what am I doing?
  - This is a physiologic experiment, it’s not a life anymore

*The important question is: Is there a chance that this person is going to recover?*

- Of course there’s always a chance
- But how big does that chance need to be for the expected outcome to justify what you’re doing?

There’s two ways to answer this question

- 1 – Economically
  - That’s an easier way to answer it because expected outcomes are probabilities
  - What is the expected outcome of this survival multiplied by the cost of this intervention?
  - You take the dot product of those, you add them all up, there’s the cost of your healthcare system with respect to end-of-life care
  - Let’s put that aside
- 2 – The human one: How many people are spending their last weeks or months in an ICU where they are for all intents and purposes, no longer there?
  - The amount of sedation you have to put on a person to keep them in that state is extreme
  - They’re now swelling into a Michelin man and is this what we want their family’s final memories to be of them?

**As Peter is talking, Bridget has such visceral memories of sitting in those family meetings in the ICU where the person in the bed is unrecognizable**

- The expectation that physicians and nurses and social workers (the healthcare teams) should be able to have some of the expertise knowledge that Peter just outlined
- And also the very nuanced interpersonal capacity to ask some of the biggest philosophical questions (with a relative stranger) in a moment of crisis

***That is in some ways beyond human expectation of physicians***

- And many do it with profound grace and beauty even when it really doesn’t feel like it to them
- That’s where the patient side is like “Come in”
  - Not because you were given a diagnosis of a serious illness
  - Because we all die

**⇒** This is hard because it’s kind of impossible to imagine not existing anymore

- To actually psychologically, spiritually, philosophically grapple with:
  - I’m here and I won’t be
  - My children are here and I won’t be
  - My spouse is here and I won’t be
  - Maybe I can kind of wrap my head around that being true for my grandparents

> “*This is a fundamental contemplation of being human and it’s a good muscle. It’s a life-giving muscle I think, to start to flex when you are healthy, when you feel good.*”‒ Bridget Sumser

- When you’re like, “*It is actually true that I don’t know when I’m going to die. It could be because I’m hit by a bus. It could be from some unexpected instantaneous physiologic thing or it could be some process when I’m 85*.”

***We don’t know, and collectively we have a hard time talking about and being in spaces together when fundamentally we don’t know***

## How palliative care is misunderstood and underutilized—especially in cancer care [1:02:45]

**Hypothetical role for Bridget as an advisor for oncology patients**

- These are patients that are in all stages of oncology
- Let’s assume that this is a breast cancer clinic, and that means you are dealing with women who have just been diagnosed with pre-cancer, ductal carcinoma in situ (DCIS), all the way up to women who have progressed through every intervention and are now facing completely unresponsive stage IV cancer [metasized cancer]

Patient: Jody Smith, 42-years old, mother of 2, recently diagnosed with stage III breast cancer

- She has a mass in her breast that they have removed and at surgery they also found [cancer in the] lymph nodes under her arm, but the workup of the rest of her body found no evidence of cancer
- She is now going to undergo chemotherapy plus or minus radiation
  - There’s a 50% chance that this is never going to come back
  - There’s a 50% chance it will come back
  - If it comes back, she will die from this
    - It will go on for years, but it will come back in a distant organ

*What would you say to her when you introduce yourself?*

- Let’s just assume she understands why you’re there and what you do
- If she says to you, “*Do I really need to meet you? Shouldn’t I be meeting my cancer doc?*” What would you say?

***Bridget would want to know what this experience has meant to her so far***

- Let’s say this has been the most jarring, terrifying thing she has gone through in her life
- She’s 42 and has a 7-year-old and a 5-year-old that are her world
- It has never crossed her mind that she wouldn’t be a grandmother, and she’s now being told there’s a 50% chance she won’t be a grandmother
- But she’s a fighter and has faith that these are amazing doctors and it’s a coin flip, she’s going to get heads
  - Bridget would join her in that
  - She would want to normalize the fact that she has never imagined anything other than being a grandmother
- So much about those initial encounters or meeting of somebody is about rapport building
  - You have to get into a back and forth so that they feel you as another person there that’s curious about their experience
  - The process of someone feeling comfortable to say, I’ve always imagined being a grandma, and I’m going to be a grandma
- People are sometimes caught off guard by the relational component and also really welcome it
  - Because they have been having this experience and nobody’s had the time to say, “*How are you?*”
    - What does this mean to you?
    - Oh, you’re waking up at night
    - What are you thinking about when you wake up at night?
    - What is the biggest worry that this brings up for you?
    - Has it crystallized something into greater clarity?

***She would be a great candidate for palliative care***

- She’s still getting treatment
- It doesn’t seem that she needs someone to manage her pain
- She probably needs someone to talk about what she thinks about when she wakes up at 4:00 in the morning, scared to death
- She may need somebody to learn about other impacts of the treatment and how that’s affecting her life, and is there anything to do to mediate that?
  - Maybe her interest in sex or her sexual function has changed, and nobody’s asked her about that
  - Nobody’s thought with her about what can you do to adjust and adapt to still have access to that part of your life, even though you have stage III breast cancer

Peter asks, “*How many of the theoretical patients that I just described, of which there are tens of thousands in this country, if not hundreds of thousands, how many of those patients are in palliative care right now?*”

- A fraction

*Why?*

- People conflate hospice and palliative care, and so people say, “*I’m not ready for palliative care,*” or “*I’m not ready to think about dying yet*.”
  - The idea that once you’re in palliative care, we’re not fighting, we’re not treating ‒ which is untrue
- Once Bridget gets into the room and says what palliative care is and people meet her, they’re like, “*Who wouldn’t want this?*”

> “*Palliative care is just good healthcare. It is just whole person…*”‒ Bridget Sumser

- Palliative care needs rebranding
- Oftentimes, BJ and Bridget are doing these very basic things, which feel very elemental
  - Sitting down and saying, “*Hi, Peter, I’m BJ.*”
  - Introducing yourself is some of the magic palliative care.
  - Often what Bridget is doing or our colleagues are doing, is just some very elemental work that gets skipped over at everyone’s expense.
- The work of palliative care, while often is very rhetorical
  - Not just the prescription pad for the MD
  - We don’t value the psychological elements as much, the relational elements, the existential elements
  - BJ doesn’t want to say the work of palliative care is easy
  - It does tend to the fundamentals of care in ways that the rest of healthcare doesn’t, but it doesn’t stop there
- There is a real skill set that Bridget has for meeting you, timing her questions
  - How she hears you, when she calls this conversation and saves it for the next time
  - When she decides to bring up the potential for suffering
  - When she introduces mortality
  - That’s a real felt experiential thing that doesn’t just happen haphazardly

***There’s a real skill set to this work that often gets short-sighted, which is another reason why palliative care doesn’t get invoked very often***

- You’ll hear physicians, especially in other health systems say, “*Oh, I don’t need palliative care. I’ll do that.*”

- Or they’re not ready
- Because they’re saying, “*I care about my patient, I treat their pain.*”
- That may be true to a point

**Very often why people don’t get palliative care**

- 1 – A misunderstanding of what palliative care is
- 2 – An underestimating the work that goes into this relational stuff
- And so therefore a lot of people pretend or think they’re delivering palliative care when they’re not
- 3 – Capacity: we don’t have enough of people who are trained to do this work

**Back to this hypothetical patient with stage III breast cancer**

- Let’s say you get to know her better, and she says, “Y*ou know, I really love being able to talk with you about this stuff because I’m scared. And by the way, this treatment’s hard. My hair is falling out, I’m sick, I don’t have the energy to play with my kids right now. There’s a lot of stuff in life that is really difficult even as I am hopefully going through this journey to come out on the other side healed.*”

*How often would she get to interact with the palliative care team? Is this an insurance-based question again?*

- It’s a health system staffing question
- It’s also a question about in any given system, what are the named priorities of palliative care in that system?
  - Which can be quite different
- So there isn’t a great way to answer that question
- It depends on staffing, it depends on if she has other supports, if there’s a way to connect her to other supports
- This is where our work at mental health folds in because the health system is not staffed or primed or any other number of adjectives to support people in the ongoing way that most would benefit from

***That’s really a community-based resource issue or intervention***

- Where people are actually living their lives with this illness is where that support is going to come from
  - Most people find that in their lives, from their spiritual community or church community or friend group
- Most would benefit from having somebody outside of their lives
  - Sharing your fears with Bridget is very different from sharing your fears with your friend who’s having their own very personal, “*You can’t die. How would I live without you? You’re supposed to be a grandma with me. Don’t talk about that*.”
  - They’re bringing all of their own myriad protections and guards from this subject into their caring for that person

Bridget shares, “*I think so often when we meet people in this counseling space, we might be the first person who hasn’t (with all of the love and all of the good intent) minimized what the person is sharing because it’s hard to tolerate our people’s fears*.”

- We want them to feel better
  - We want that to stop for them
  - And so we say things like, “*Oh, but you’re going to be fine. Look how well you’ve done so far. It’s going to be okay.*”

## Palliative care in the case of Alzheimer’s disease: emotional support, future planning, and family involvement [1:12:15]

- Now we have people who show up with cognitive impairment, but they’re actually still okay
- They’ve now had that amyloid PET scan that demonstrates the buildup of amyloid in their brain
- Certainly to the eye of a skilled neurologist, the diagnosis is unambiguously clear
  - It’s a clinical diagnosis
- They’ve now been given the diagnosis, “*You are in the early stages of Alzheimer’s disease. We don’t know the speed at which this is going to progress, but we know that it’s more or less monotonically going to get worse.*”

**What are you asking that person?**

- This is a very beloved space that Bridget has gotten to spend more time in  over the last few years
- One of her first questions is, “*What have the doctors told you? What do you understand?*”
  - Because a person may have had many visits with their neurologist and the neurologist has given clear information…

**Hypothetical patient**

- Let’s say this person watched their parent die of [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) and there’s a strong hereditary component here
- Let’s say they’ve been in denial for the last year while they are were in the throes of noticing some changes, and now they understand
  - They were like, “*Oh, I’m probably just a little tired. It’s probably just a little distracted*.”
  - But now they’ve been confronted with the amyloid PET scan, there’s the [C2N](https://c2n.com/) blood test, and the results of the cognitive test
  - They know they are on the same path as their mom or dad
  - And they remember what it was like for the last 4 years of that person’s life
  - Let’s assume that there’s not a lot of ambiguity in their mind about what’s happening and what’s going to happen
- Bridget would want to know more about their experience with their parent
- She’d want to  know the things they are most worried about

*The patient’s hypothetical response*

- Let’s say she’s most worried that she will not be able to care for herself
  - That the people she cares about are going to need to take care of her and it’s going to inconvenience them
- She’s not ready to lose her mind
  - She’s young; let’s say she’s 68-years-old
  - This is on the verge of being early onset
  - She realizes that in another couple years, she might not be sentient
  - This is a highly functioning individual ‒ a person who is still working, still contributing, who loves their life
    - They’re basically mourning the loss of that
- Bridget would not interrupt their mourning
- She would ask her to, “*Tell me more about how much you don’t want this to happen. Why? What’s the worst case? What happens between now and there?*”

***There’s a certain amount of creating (and allowing for) space for people to say the things that they’re catastrophizing in their minds, that they’re so scared of, that they don’t want to have happen***

- To lay that land in order to come back to in a trajectory of yes, you’ve laid out like a path
  - But also there’s so much uncertainty actually for how the progression will happen and when and what the changes will be
  - Just how hard it is to not know what that will actually really look like

*BJ wants to double click on what Bridget is saying*

- Whether it’s a cancer patient or someone dealing with Alzheimer’s, the early work is so much of relational, getting to know the person
- Laying out a safe place for them to fall apart, share their fears without being shushed ‒ that’s really key
- And that might take all of the first visit
  - You may ask no questions about the diagnosis
- It might take 5 visits before you get to anything for the reason you’re supposedly there

***We know there’s some magic in a person being seen, bearing witness; them getting to express themselves is its own therapeutic value***

- As the provider, you are learning about what makes this person tick?
  - What inspires them?
  - What turns them off?
  - Where their fears lie, etc.
- You’re gathering all this knowledge that’ll help you as you go down the road with them over time to be able to spot and to look around the bend a little bit for this person and see what might be coming up for them
  - Then you can sidle up to them and say, “*Hey, remember last time we talked about this or that thing? Or remember you told me how much this or that thing is a source of fear? I just want you to know I’m going to be here with you*.”
  - It lends a much more specific ability for you to accommodate and accompany this person
- So much of the work is really is an accompaniment and looking around the corner with someone, before we move off that into other things
  - That’s the foundation

**What are the things you want to understand before you’re so far gone?**

*This person is in palliative care, and they’re going to try all sorts of therapies*

- Deep down they know that the therapies in this space are far less efficacious than the woman you met earlier with breast cancer where she’s really got a shot
- The most these therapies are going to do is slow things down
- But look, if you slow them down enough, maybe something experimental comes along

Let’s fast-forward a year or two, and things are getting worse

*Walk me through the things you need to do to help them and their family prepare for what is effectively inevitable*

- Bridget points out that just because somebody saw their parent die of Alzheimer’s and they’ve been diagnosed with Alzheimer’s, it’s not inherently true that it will end up being the worst thing that they could imagine

**⇒** As a massive generalization, we don’t tend to anticipate our ability to adapt very well, especially when the worst case thing is happening

- Sometimes having been intimately involved in this worst case thing, you surprise yourself or your kids surprise you
- There’s these things that unfold that you wouldn’t have guessed would be a part of the experience
- Bridget encourages patients to really try to hold space for that, to stay curious about
  - Instead of being very sure of what this is experience is going to look like
  - See what it actually looks like and feels like

In this instance, let’s say that this person was also married or partnered

- Bridget is acutely aware of that spousal or care partner experience

Peter asks, “*But are they also a patient? Or is there a patient confidentiality thing where you can’t really be there to support them because your patient is the spouse?*”

***In palliative care, the unit of care is the patient and family***

- This is one way palliative care is unique in medicine
- They still bump into the Western autonomy, individualistic, the patient is the patient
- They are not documenting in the chart about their spouse
  - Or if they are, they’re doing it very carefully
- They’re really thinking about the unit (the family)

***This allows more latitude because you can think of the entire unit of support that a patient would define as their support***

- In the experience of Alzheimer’s, their experience is central to their well-being
- We have to start getting better at this in a major way

**How far into this relationship are you broaching medical decision-making, power of attorney, things like that?**

- Early

Peter asks, “*Are those difficult discussions in that they require a cognitive acceptance?*”

- You’re actually putting medical decision making into the hands of someone else
  - Because in the future, you’re going to lose the capacity to make those decisions

*How difficult a decision is that?*

- It really depends on the person
- Have they really truly managed all of those decisions by themselves?
  - Or are they used to some back and forth?
  - Or do they have a different model that’s quite intertwined?
- For some people that’s really hard to imagine
- In Bridget’s experience in the neurologic illness space, so often if a patient has someone, (which not all do), that person is coming to visits
  - Because the patient has been showing signs where they’re not remembering or they couldn’t get to the doctor’s office on their own or get the Zoom up by themselves, etc.
  - So they’re often presenting with somebody else and there’s immediately another person to engage with their experience

The number of times spouses, adult children are immediately brought to tears with the question, “*How has this been for you?*”

- Because no one has asked them
- Not because they didn’t want to, but usually because they don’t have time
- The neurologist is mostly there to think about the patient

**More about the importance of creating an advanced directive**

BJ adds, “*And this gets complicated. All of these things are such tips of icebergs… And one of the reasons why we started* [*Mettle*](https://www.mettlehealth.com/) *outside of healthcare is to make good on that promise: yes, the unit of care is patient, family.*”

- When BJ was working in the medical system (in the cancer center or anywhere in the medical), there was no way to bill for the spouse
  - We’d sneak that family into the side door sometimes to have an appointment with them, or we would dovetail it in the appointment with the patient
- So yes, there is at least intellectual and emotional space preserved for the family members, but very often it’s still short shrift because of the billing issues
- That’s another reason why he co-founded Mettle
- Probably 60% of their clients are the family members
  - Because there’s no place for them
  - No one’s asking about their experience

## The importance of having an advance directive: defining what matters most before it’s too late [1:23:00]

**What are some questions you’re going to ask that patient as their cognition is declining and things that you need clarity on from them, their wishes? What do you want to understand?**

- Spend a moment on advanced directives and advanced care planning

> “*If you’re 18 in this country, you should have an advanced directive.*”‒ BJ Miller

- Virtually nobody who is healthy (young or older) has one
- Maybe 20% of people have an advanced directive even though many people think it’s really important
- This is a deferrable thing like life insurance

BJ’s public service announcement, “*An advanced directive is very important*.”

- You don’t need a lawyer to do this
- You can [download](https://prepareforyourcare.org/en/advance-directive) a form online

**⇒** The most important thing to come out of an advanced directive is the proxy ‒ who do you want speaking on your behalf if you are in an accident and doctors cannot ask you

*Why a young, healthy person should think about creating an advanced directive*

- Bridget’s first advanced directive was created in her late 20s
  - Even though she had been in these conversations for a long time
- One day she imagined something unexpected happening, not being able to participate in a conversation, lying in a hospital bed
- She imagined her parents (who do not speak to each other) trying to make decisions for her while her casual partner at the time was sitting there, trying to figure out how they belonged in the scene
- She didn’t want that for them
- She thought of the choices they would default to
- She didn’t want them to be in the throes of totally unexpected grief and trying to negotiate that relationally

Peter shares, “*It’s an awesome responsibility. I’m very honored to say the number of people that have asked me to be the decision maker for them… there are more than a dozen friends who have asked me this and I say the same thing to all of them, which is, ‘It’s an honor to do it, but we have to sit and talk.’ You can’t hand me that stick and just sign my name on there.*”

- You really need to understand what a person wants and doesn’t want
- BJ points out that a lot of people don’t do that
- This job is not for you to insert what you think

***The job is for you to honor the other person’s wishes, speak on their behalf, and to do that well you have to know the person’s wishes***

- To do that well, you need to ask more than a couple of questions
  - That’s a big conversation
- As providers, you may be sharing intimate details as part of intimate things to happen

**The conceit part of the advanced directive is problematic right out of the chute**

- You’re asking someone to put in themselves in this future-oriented position where they’re in a situation that they can’t imagine, where they can’t speak
- And so what will they want then?
- It’s a problematic tool

⇒ As people move through life with illness or disability, their realization of what they can or might like to live with shifts

*We have data around this*

- You ask a bunch of healthcare providers, “I*f you were brought into your own emergency department as a quadriplegic from an accident, would you want your colleagues to save your life?*”
- Most providers say, “*Hell no. I could never live like that.*”
- Go ask most people who live with quadriplegia if they’re happy to be alive, they’ll say, “*Yeah, I couldn’t have imagined this*.”
- The same is true for BJ ‒ he lost 3 limbs
  - If you asked him initially, “*Hey, we’re okay going to lop three limbs off. Are you cool with that?*”
  - He’s like, “*No.*”

> “*But as it goes in this life, we are adaptive, we have capacities that we don’t know until something comes along to pull them out of us*.”‒ BJ Miller

***Part of this mind bender of an advanced directive is to allow room for a person’s sense of themselves and their capacity to change in any direction***

**⇒** All of that is a preamble to say you have these conversations over time multiple times and let the person change over time

**What to focus on with the advanced directive**

- This is one of those places where you want to focus on the things that are important to you
  - The experiences that are central to good days to meaningful time
- Having counseled a lot of people actually in the acute moments of having to make these decisions, Bridget has been able to reorient them towards, “*You know what I’ve heard you say is that your dad was always in his garden. He wanted to be at home. If he could hear your voice, that’s what was important to you… The ventilator doesn’t get us there. What are we moving towards is much more motivating than not doing X, Y, and Z. Not intubating, not resuscitating*.”
- Those things for most people exist from scenes from TV shows and are still pretty far away
- But it is easier for people to choose the scene that we’re going towards that they can square against how they knew their person
- There are people who are very clear about A, B and C interventions being something that they would never want
  - Bridget certainly honors that
  - Maybe she holds it with a little bit of a grain of salt
- She’s more interested in understanding what makes this person’s life
  - Not because it’s going to perfectly translate ‒ if I can’t dance under the full moon in Bali, my life is not enough
  - What if you could see the full moon from your bed?
  - We adjust

*Peter thinks this is a really important point, and he’s never thought of it that way*

- He has the bias toward, what are the things we don’t want to do
  - Thinking about medical lingo: [DNR](https://en.wikipedia.org/wiki/Do_not_resuscitate), [DNI](https://en.wikipedia.org/wiki/Do_not_resuscitate#:~:text=patients%20with%20DNR/-,DNI%20(do%20not%20intubate),-orders%20want%20CPR), no chest pounding, no intubation, etc.

***He likes the framework of: What are the minimum set of requirements you need to have to still hold some delight in life?***

- What do we need to do to get you there?
  - Those are the steps we’ll take

**There was a movement to change DNR to AND (allow natural death)**

- To get away from things we’re not doing
- To make a point of things we are doing

***The point is to have a sense of what we’re moving towards ‒ what’s the goal?***

- Even if we have to be very flexible and allow our mind to change en route
- That’s just a much more deliberate path
- It’s also very helpful for those around us to know what to do versus just not to do

## The differences between how young and old individuals experience dying from cancer [1:30:15]

**What are the differences that you have both experienced in dealing with dying cancer patients between those that are, “old,” and those that are young?**

- Of all the chronic diseases, cancer disproportionately strikes the young
  - People in their 40s and 50s don’t really have to worry about heart disease and neurologic disease for the most part
  - But they’re far from clear of cancer
- An [article](https://pubmed.ncbi.nlm.nih.gov/39095135/) came out recently that even suggests that the incidence of cancer is rising in young people
- Everybody agrees the 40, 50-year-old dying of cancer is tragic versus the part of life when someone is in their 80s and 90s and dies of cancer

*Peter is curious as to what they’ve learned about living and dying through the lens of cancer*

- BJ has seen some kids die, and this is a whole new level of sorrow and sense of tragedy for the parents
- There is potentially a very different level of engagement or awareness

BJ points out, “*We want to be very careful to not be judging and grading deaths. This is why the problem of good death is a really problematic construct.*”

- In terms of something instructive to learn from, BJ has seen some younger people die so beautifully and adapt so remarkably to the reality that they’re living
  - It’s just stunning
- You could say that’s because they haven’t yet been around on this planet long enough to develop such concrete notions of identity
  - I am this
  - I am not that
- It’s about expectations

Peter asks BJ, “*When do you think that kicks in?*”

- It’s a spectrum
- Something like late teens, early 20s is when we individuate and our identity set up as something relatively independent compared to our earlier years
- BJcertainly feels different about himself now than he did when he was 19

**Dying is a natural thing, we’ll all do it. Hey, what’s the problem?**

- The problem is that it’s really hard
- If there’s a problem around dying, it’s the social pressures or the expectations from ourselves or others that make us feel that we’re doing it wrong
  - Or that there’s something wrong with me for dying
- A kid may just have a much more fluid sense of themselves in the world
- They may not have seen enough of the planet to attach so firmly to it
- Those are just guesses
- They have a colleague ([Chris Adrian](https://www.mettlehealth.com/counselor-chris-adrian)), who’s a pediatric palliative care doc at Mettle, and it would be interesting to talk to him
- That’s BJ’s experience with younger people
- Now it’s a very different conversation with their

**Bridget points out, “*****The anticipatory grief of a dying person is very different than the anticipatory grief of the people that will go on to live without them.*****”**

- That’s the space that we’re trying to negotiate these decisions and make plans
- These are 2 very different developmental tasks overlaid in the experience of children
- In those experiences of children who are clear on, “*I think I’m dying, nobody’s willing to talk to me about that.*”
  - They’re looking around for another sober person to engage with them

*Peter pauses on this amazing thought*

- He has never really spent much time thinking about it because in pediatric surgery you saw some children who died, but they were usually on a medical or pediatric service by that point
- He doesn’t really understand what the metacognition is of a dying child

For example, a 10-year-old child who’s got cancer

- They’re aware that something’s happening, I suppose?
  - More often than not
  - Sometimes with a more direct shoot to the truthiness of what’s happening than adults (including the physicians and clinicians)
- There’s an arc for our development where we know a lot as kids and we go out in the world as adults and we try on all these other outfits for size and do the things we’re supposed to do and shoulds and stuff
- Then there can be this return to a playfulness and a lightness within old age that would have you thinking that our wisdom was never higher than when we were kids
  - We just didn’t get seduced into thinking that someone else outside of ourselves knew more than we did and started externalizing
  - We could draw lots of fanciful narratives around that

Bridget shares, “*The fluidity with which my 3-year-old and 6-year-old will, sometimes they’ll wake up and be like, ‘Do you think Nana died last night? When are you going to die?’ There is a curiosity that they have without the attachment actually to the deep meaning that we may as adults get into anticipating and then because we’re anticipating feeling it.*”

- They can just ask the questions, “*Will you be alive when I die, mom? Will you be old?*”
- They’re just trying to figure it

## The difference between pain and suffering, role of medicine in pain relief, and why emotional healing is essential at the end of life [1:35:45]

**The anticipation of loss and death versus the actual event and loss once that person is gone**

- Those 2 states exist for the surviving
- Only one of those states exists for the dying

*Tell me about the experience for the person who’s going to die*

- What are the things that they express to you as their greatest fears?
- How often is it, again, physical pain?
- How often is it not existing?
- How often is it leaving someone behind and their suffering?

*Similarly, what is the anticipated versus realized experience of the loved ones?*

- For many people there’s real fear about the physiologic experience of dying, of pain and other symptoms
- One of the beautiful parts of Bridget’s and BJ’s work is in the nature of people being linked to palliative care or hospice care, there’s some ability to comfort that
  - Bridget explains, “*That we are here, we are watching those symptoms, we’re working with you*.”

Peter asks, “*Could we say that nobody in the year 2025 needs to actually suffer during death?*”

- For example, is there a pain that is so deep that it can’t be reached by the most potent narcotic?
- Is there a shortness of breath that is so significant that it can’t be offset and palliated by probably a narcotic as well?
- From a medication, yes, no one needs to die suffering
  - As long as you include the potential for sedation
  - It may take so much narcotic to quell your pain or your shortness of breath that we are actively putting you to sleep

Bridget’s note on the use of narcotics in this setting

- Narcotic is a term of law enforcement
- The medicines that are being used at this time are [opioids](https://en.wikipedia.org/wiki/Opioid)
- It’s an important distinction because opioids are often one of the central medicines in managing the symptoms related to dying and related to serious illness at a certain point
- People in 2025 in the setting of how opioids exist in our culture are scared (and for good reason)
- Peter recently did a podcast with [Sean Mackey](https://med.stanford.edu/profiles/sean-mackey) (who’s a pain specialist) [[episode #345](https://peterattiamd.com/seanmackey/)], and they talked a lot about opioids because on the one hand they are a very important part of the toolkit of a pain specialist
- And they have been the most widely abused class of drugs in the history of modern medicine
- Those 2 statements can be simultaneously true, but it doesn’t detract from the former

**⇒** There is a fair amount of work [to do] if opioids are being used to manage people’s symptoms with serious illness

- We need to pause and ask the questions:
  - How do you feel about this medication being prescribed?
  - Do you have experience with it?
- Because everyone comes with some imprint around the meaning of these medicines
- And if we want to help people use the medicines correctly to get to that place where they might be as comfortable as we’re able to get them, we’ve got to peel back the layers on the relationship to the medicines being used

**Is that a common phenomenon where people show up with a belief about opioids?**

*Do people think it’s cheating? Do people think there’s some nobility in suffering through death?*

- Certainly some people do
- Some people feel that pain is redemptive, that they don’t want their experience blunted or muted
- Or that they have such a commitment to a, “natural experience”
- Or they have been a person that never took pharmaceutical medicines or drugs anyway, that this could be a real diversion from how they’ve understood or been comfortable in relationship to medicines

***Often there’s a need for conversation in this space***

- At this point, unless you’re living with no access to media, everybody has some touchpoint reaction and bias about these medicines
- A lot of people are worried about addiction
- People who are sober are wondering how this impacts their sobriety

*That’s a super interesting question that Peter had never thought about. If you give me fentanyl and morphine, is that violating my sobriety?*

How do you answer that question?

- Bridget usually answers that question with more questions around their sobriety
  - What has that experience been like?
  - Where are they with it now?
  - Has it been important that there has been absolute abstinence?
  - It exists differently from different people
- You might put some of these questions in the camp of identity
  - Are they telling you, there’s no nobility in you suffering unnecessarily (being in pain unnecessarily)?
- If the patient says, “*Absolutely no opiates or no benzos,*” they will listen
  - It’s your call
- It will be back to more questions, and they can change their mind anytime
- BJ an Bridget always know the “social clouds” around some of the issues, and they go out of their way to say, “*You’re not going to get addicted to these medicines. We’re going to be using them judiciously*.”
- A lot of people when they hear, “*Get the morphine,*” they think it’s a euphemism for essentially euthanizing a patient
  - It’s not legal to do that anywhere

***We’re going to use only as much medicine as it helps your symptoms***

**⇒** There’s a lot of room to clarify how we would use these medicines, what they mean and what they don’t mean

- Even if someone doesn’t ask BJ those things, he usually finds an excuse to say those kinds of things

**Clarification on how they’re using the words suffering and pain**

- It’s not correct
- Someone can have all of their symptoms pretty well managed and feel pretty comfortable physiologically, and have an extraordinary amount of suffering

Bridget adds, “*To say in 2025, nobody needs to suffer at the end of life. I think that’s impossible*.”

- For the most part we can say we will do everything we can to help you be as comfortable as possible
- Can we say we can do that perfectly?
  - No; not outside of the sedation

*There’s a difference between pain and suffering*

- Pain we understand
  - We understand shortness of breath, nausea, vomiting, and things of that nature
  - And those things can all be managed physiologically

*Talk about the residual of suffering once you’ve addressed those, receptor bound physiologic things*

*How much of this is sadness? How much of this is grief?*

- This is one of the reasons why precise nuanced symptom management is so important
- When the noise and the volume of the pain often is turned down, then we get to learn about the stories someone is telling
  - Or the things that are replaying in their heads
  - About not getting to see their kids grow up
  - Or not getting to finish that piece of work that felt so important to them
  - Or the ways in which they wish they hadn’t taken something for granted
- When symptoms are loud, it is really hard to get into the places of suffering that are about incompleteness
- They’re about what we won’t get to do, or what we won’t get to do with our person or our people
- There’s a whole pot spiritually, existentially around faith and relationship to God potentially (or what that is for you), and if that has stayed whole in this experience of illness
- If you’re nauseous, you’re not going to tell me how you’re feeling other than the nausea
  - Turning the volume down on some of the physical stuff really can open up the space to [this discussion]

**⇒** One of the misconceptions around their work is that it’s just about symptom management

- The first thing to do is turn down the symptoms, to a degree possible so that the rest of you is present
  - That’s the starting line

***Once we get you comfortable enough so you can think about anything but your pain or your nausea, that’s when the real work begins of getting to know you and evincing your fears and your hopes and your dreams***

- And that’s the stuff that’s really the meaty stuff that we want to

*What do we mean when we say the word suffering?*

- For BJ, pain is a stimulus
  - There’s safety to it
  - It tells us to stop doing what we’re doing
- There’s this sensation, it’s complicated
  - The pain pathway is not as simple one, there’s not a pain pathway
  - It always involves emotion, always involves cognitive stuff (it’s just a matter of degree)
- But that degree is so when we tip into something where your pain or other symptoms are causing a threat to your identity, a threat to your sense of self, a threat to what you see as real in the world ‒ that’s when we get into suffering
- Suffering is a mosaic of physical, emotional, spiritual, existential
  - The whole panoply of the human experience goes into suffering
- Someone may have inordinate pain, but if they believe that that pain is redemptive, it’s going to bring them closer to God or is burning off some bad karma, they’re not suffering
  - They might be very uncomfortable
  - It’s not threatening their sense of self in the world
- And someone might have a very, what looks to be a mild cause of pain, but be suffering extraordinarily because that has undone their sense of being
- It’s not just the sort of physiological signaling cue

## How to have a “good” death: the power of self-honesty and human connection at the end of life [1:47:00]

- BJ and Bridget have had decades of being at the bedside for experiences that Peter is sure they look back upon and think, that was really a wonderful experience
  - That patient passed out of this world and their family escorted them out in the best way they can imagine
  - And Peter is sure they have seen the opposite: things that made them cry, and made them weep for all parties involved

**What are some lessons we can take away from that?**

*What are some of the dos and don’ts of this process of dying and a person’s loved ones?*

*Tell me things you’ve learned that people should know, that increase the probability of it being as positive as it can be, versus the opposite*

- That’s a tough question
- This subject just really thwarts much objectivity or anything that smells reductive
- While we talk about a body or a person in decline, that’s our medical bias towards the physiology and the bodily

**⇒** It’s also very possible that people can be having this incredible emotional and social spiritual growth even as their body is in decline

***Part of it is our naming and overcoming the biases we’re born into (in this particular culture, in this particular world)***

- BJ adds, “*For me these days, the word honesty comes up for me a lot*.”
- The bullshit that we tell ourselves, the partial truths that we tell ourselves, the pieces of ourselves that we don’t look at
  - That we don’t allow in because we’re either ashamed of or whatever it is, or blind spots
  - Or we’ve bitten this sort of autonomy independence thing so much that we don’t let any social reflection in

*Dying can be, is this sort of great accounting*

- It’s all coming out in the wash there

***If each of us can take into perhaps our responsibility but also our privilege to know ourselves over time and to dare to look and to see, and to be true to ourselves***

- If you asked BJ this question 5 years ago, he probably would’ve said something different

> “*If you want to be ready to die, well, get real with yourself (as sooner the better). Because one of the things you’ll allow in, is a richer life*.”‒ BJ Miller

*One of the reasons why we would encourage people to think about death earlier in life is*

- Not just to avoid the defaults of a medical system that doesn’t think about these things
- You also allow in the idea that both your bigness and your smallness
  - I’m one of a zillion people who’s ever lived
  - I’m a drop in the ocean
- But also allow in that the ocean would be different without your drop in it
- That work of placing yourself in the world and feeling in right size to it all, requires a lot of dynamic honesty
  - And that takes effort
  - You need to dare to look at yourself, and that is a big do (if you do that well)

***So much of what we talked about today is, it’s not the problem of dying so much, but the difficulties of uncertainty is so much of what we’re guarding against or working with***

- Living with uncertainty, and that’s something that we all do all the time

BJ adds, “*My answer to all that is get real with yourself and be as honest as you can one moment to the next. And allow yourself to move and change with reality*.”

Peter finds that to be profound

- Because on the one hand it seems so easy, so self-evident
- But on the other hand it’s so difficult, and it’s something that anybody with a modicum of introspection struggles with

BJ continues to explain

- As relational beings, whatever’s coming tomorrow, might yank all the sorts of other things out of you that you didn’t know were there
- The sense of self, this identity thing is a biggie

*For Bridget, when she thinks about those beautiful experiences, the word for her is “connection”*

- Whether you are the person who’s dying, your ability to connect to self, to the environment, to the people around you, if there are other people there
- If you’re a person around supporting, can you be connected and in contact with what’s happening
- When there’s a lot of connection or connectivity in this time, the circumstances matter
- But a lot of different circumstances, a lot of different storylines can actually feel quite alivening or even nourishing or validating, because ***it is being in touch with what is real***

**What fraction of patients that you experience in the final days and weeks of life have the ability to be in that state?**

- Meaning, they aren’t constrained by their symptoms of medications (needed to either sedate or control pain)
  - They talked earlier about delirium

***Bridget things many are, if the state is any level of connection to what’s happening***

- She’s  not talking about moving towards totally conscious death
- Even in delirious states, there can be moments of real connectivity
- Maybe we don’t understand cognitively, totally what’s happening, but your kid is sitting there telling you stories about the things that were important to them and their experience of you
- Or there’s some sensation in your hand that’s receiving input from your spouse or the light
- We just don’t know what that experience is
- If we work towards environments and a focus on promoting the idea of connection, Bridget  believes that translates regardless of mental status or mental clarity

*To the statement said earlier (that most people withing 3 weeks of death probably experience delirium) ‒ Bridget doesn’t think that’s true*

- It is common days before death

**⇒** But there’s opportunity for connection the whole time

- Especially if you include to yourself and to other parts of yourself
- And also if you include inanimate objects and non-human things
  - Some of BJ’s most connected experiences in his life have been with dogs
- Once you broaden the scope of what you can connect to, Bridget’s points are really well-placed
- You may also allow connection to a perfect stranger (surprisingly)
- That has happened to BJ
  - He has felt like his life has been saved by strangers many times one way or another
  - BJ remembers earlier days feeling despondent, so alone, so in pain

- But the kindness of a person walking by giving just a little bit of eye contact, a little wink of, “*Hey, I see you, you see me*.”
- Maybe they hold the door open

***Just a little connectivity and the realization that it is an illusion to say you’re alone***

- It can feel very real, but none of us is actually alone
- As you head towards the cosmos, you are, there’s room, to feel connected to all sorts of things you can’t name, but you feel that connection
  - This comes up with psychedelic work

## How psychedelics like psilocybin can unlock emotional breakthroughs and deepen connection for patients near the end of life [1:55:15]

**How much of either of you followed the** [**psilocybin**](https://en.wikipedia.org/wiki/Psilocybin) **work,** [**Roland Griffith**](https://hopkinspsychedelic.org/griffiths)**s work (the end-of-life stuff), and what is your take on (again, notwithstanding the regulatory challenges of that) that literature and its efficacy?**

- Anecdotally, Bridget has seen psychedelic experiences be incredibly helpful to folks that have run into a place in themselves, where they’ve just hit a wall in their own imagination
  - Hit a wall in their own mind as to what this experience is or what it can be
  - That there’s just this opening that can happen sometimes incredibly subtly that allows for just some slightly different insight not generated by the brain that you know so well
  - It can be amazing
- In BJ’s experience (and people he’s worked with), it’s easy to start feeling evangelical and think, “*We should be putting psilocybin (and other psychedelics) in the water*.”

> “*On the whole, these substances, these medicines have been able to achieve in a session with a patient what months or years of talk therapy other things haven’t accomplished*.”‒ BJ Miller

- It’s not necessarily about learning something in those experiences, it can be
- From BJ’s time with it, it’s more that he gets past his thoughts and gets into this embodied felt thing
  - It’s not an epiphany, it’s just he feels the power of that epiphany or that idea in his bones, in his flesh
  - It’s a different kind of knowing
  - Which then allows for a super sense of connectivity
  - And the therapy of that
  - You get to see how silly our minds can be, and learn the bumper sticker truth of, “*Don’t believe everything you think*.”
  - You come out of there with a new relationship to how you hold your thoughts
- People can get to that by other means: through meditation, through prayer, through deep transcendent communal experiences

## Lessons from the dying on how to live well [1:57:30]

**You have spent a lot of time with people in the final stage of their life. What have you learned that changes the way you want to live your life?**

- This is a huge, beautiful question
- BJ reflects that *many of us would say* we’d love to be fearless and go into our death unafraid
  - Or live a life so conscious that we have no regrets
- Patients have taught BJ to undo those strangleholds a little bit

***Instead, change your relationship to fear, your relationship to regret***

- The mark of living with no regrets
  - There may be something for you in that
  - BJ is not sure how, if you’re being really honest with yourself, how possible that is

> “*The lesson has something to do with coming around to accepting everything that’s in you, including the gnarly stuff like regret and fear and even suffering.*”‒ BJ Miller

**Are there certain regrets that people have shared with you more often than others?**

***The common thread they all seem to have in common is they regret not letting themselves feel***

- Or not letting themselves be true to what they actually felt
- Whether it’s, “*I worked too much, [or I] didn’t tell my kids I loved them*.”
- **Shame** or something else wedged in themselves and separated themselves from themselves
  - Or separated themselves from other people they love

***And the regret has something to do about artificially or accidentally putting a wedge between you and anything***

- You could spend a lifetime running from fear
- And if you watched a lot of people come around to when they finally got the cue, that fear was just a natural part of being in a body
  - They became okay with fear
  - They took away that secondary shaming of fear and it was defanged
- The same with regret
- The *commonality* has something to do with not being quite true to themselves or trying to keep something out of their experience
  - And all the work they did
  - And when they come to realize that it’s all got to go anyway, welcome [feeling] (even pain)

**⇒** To feel anything is wild and magical

**Do people need to be really close to the end to typically come to that near inevitable realization?**

*Or is that something people are realizing 6 months out where they can do something about it, where they still have all their faculties and they can still mend a bridge or mend a relationship?*

- Yeah, absolutely: that can happen anytime
- Back to kids, they’re not gumming their own works up ‒ they can do that

***Yes, we can learn to do this***

- This is another reason why we would invite this subject into our daily lives
- If you look out your window, death and life are happening all the time
  - You see it on your windshield, it’s all over the place

*If you can really be aware, let these messages in, then you let these lessons in too*

- Towards reconciliation or why hold a grudge?
- Why would you ever cause suffering in another person knowingly (and you’re self-included)?
- Buddhism was sort of founded around this question and to give you a life of practice around meditation
  - How do you hold your mind so that you don’t suffer unnecessarily, so that you can be okay with the fact of your death

***Your scholarship bodies of thought and just your own personal experience of living daily life; if you let it in, you can gain these lessons anytime along the way of life***

- Bridget thinks about her own learning ‒ she doesn’t hang out in this space a lot
  - She doesn’t wrestle with the reality that we don’t know when we’re going to die
  - Which means, this is her life as a management strategy: she’s got 2 young kids

Bridget explains, “*There’s also a tether to the reality that this moment is what I have*.”

- It may start to sound trite, but it is not
- Tomorrow is not promised to me
- 10 years is not promised to me
- And if that is true, can I use that as this reminder, this moment
  - The way that I speak to you
  - Being tender when I do things out of my value system

***Staying really connected to now, is the invitation that comes next to in being so aware of mortality***

- You do not have to be sick
- You do not have to be facing the end of your life
- No one in your life has to be dying right now to just take pause and be like, this is my life, this moment and then the next
- Do I remember that all the time?
  - Absolutely not
  - But it is a very available reminder
  - I intentionally stay connected to it
- Bridget intentionally makes it something her kids can be connected to, because it’s inarguable
  - It is inarguable that we are always living in the reality that we don’t know when we’re going to die

**That gets back to the dos and don’ts**

- Do have a relationship with mystery, with not knowing
- Do have a relationship with the present moment
  - This is not light or easy
  - It does not make you not afraid
- Bridget feels very aware of how much she wants to be alive and how long she hopes her life is
- She is humbled by the fact that what she has influence over and control over really inarguably is right now
- Not being ashamed of your fear
  - What people often experience is the shame of being fearful

*The word “control” comes up a lot, and it’s a big one*

BJ adds, “*If we’re going to remotely dispense any advice, the* [*serenity prayer*](https://en.wikipedia.org/wiki/Serenity_Prayer)*, it comes up a lot one way or another. I think a lot of your listeners will know this, the ability to discern what you can control and focus some efforts there and let go of all the things you can’t control.*”

- And maybe in the middle identify that even though there are some huge things we can’t control, ***there is a lot we can influence***
  - Those are different
  - And that there’s that spectrum between control, influence and surrender, and how do we build our flexibility?
  - How do you learn to sit with it?

**⇒** One message of the serenity prayer: focus your attention on what you can control

- People often have a lifetime of focusing their line of sight in one direction
- What we let go of is the other half of that message is: don’t give a shit about it because you can’t control it

***Learn, sit with all that you can’t control. Practice not being in control. That will serve you very well as you head to your death.***

**What about the role of forgiveness?**

*How often do you encounter the dying who are wrestling with needing the forgiveness of someone or needing to forgive someone?*

- It’s a big theme
- The focus is saying out loud:
  - I love you
  - I forgive you
  - Please forgive me
  - Thank you
- These are tried and true messages that seem to cut across culture and stand up pretty well

***More commonly, what BJ sees people needing to learn how to do is forgive themselve***s

- BJ sees people being at odds with themselves when there is no boogeyman
  - They’re just not comfortable with themselves
  - They’re self-loathing, self-critical
- We have a bias
- All the people BJ has seen have had the benefit of hospice and palliative care involved
  - So they’ve been loved on, they’ve been heard
  - There’s an inborn bias to our experiences
- Bridget doesn’t have a good answer about the forgiveness piece
- She doesn’t know that it comes up a lot

- BJ thinks that might be the bias of people that he’s spent time with overtime
  - Those things have been gotten to, there’s no need for a deathbed [forgiveness]
- There are not a lot of truisms in this space that Bridget generally vives with
  - She’s pretty allergic to most of them
- Bridget doesn’t thinking there’s something to the saying that “people die the way that they live”
  - Those who live in love, die surrounded by love
  - If you’re a person that dug into your life and really investigated your mind and you did that relationally and you shared your reflections, that’s also more likely to happen when you’re dying

**Bridget’s advice**

- If there’s an experience you would like to happen, if you’re imagining into the future, you’re like, “*I think dying in this way would be okay or more tolerable or nice or beautiful,*” start doing it now
- If you’re worried about forgiveness, investigate that now
- If you want to feel more connected, how do you do that?
- If you want to be in your body more, how do you do that?

***Building those muscles is the best way to get there***

- Some people do 180s with a big diagnosis or the awareness that they’re dying
- But mostly we lean on the places that we have hyper-developed because they’re comforting, because they’re familiar in the face of this vast thing

**Peter’s takeaway**

> “*That might be the single most important insight of them all. Which is, we die how we lived and we will, what’s the expression? We rise to the level of our training*.”‒ Peter Attia

- In sports we talk about that
  - That fatigue
  - You rise to the level of your training
- And so we will default to our regular strategies
  - The strategies that got us through life are probably the strategies that will get us through death

***And so what we should all be doing is imagining the death we want, and begin practicing that at life and make that our scaffolding today***

- BJ thinks that’s good advice
- Especially if you throw in the caveat that along the way learn to deal with things when they don’t go as planned
  - So that you don’t have this sense of failure at the end
- One of the saddest things BJ sees is people who feel like they’re failing at dying
  - He doesn’t want to set it up as an achievement per se, but Peter’s advice sounds really good to him

Bridget adds, “*We can’t control for the outcome with certainty, but we can build the muscles and the capacities that are going to help us land in that place.*”

- If you’re a person who builds new coping skills or new ways of being in high stress adversity, you’ll probably do that then

**BJ’s insights about active dying**

- You don’t become a different person when you’re dying
- When do we begin dying?

*That active dying, we never finished answering that question*

- Active dying has its own frame, but everything up to that is some form of living
- You can begin practicing this dying thing today

## The physical process of active dying, and the emotional and practical considerations for loved ones [2:09:30]

*What goes on in the final 24-48 hours, when the body’s really shutting down*?

- BJ uses the phrase “active dying” to distinguish it from the rest of living
- The body is actively shutting down: system by system, you’ll stop
- Your kidneys will shut down
  - You’re not making as much urine in part because you stopped drinking probably a few days ago, because your body couldn’t handle the fluids
  - So thanks to kidney shutting down, you get a buildup of toxic metabolites and you get a little intoxicated, a little dreamy
  - That may be the mechanism of your delirium
- You’re not eating, you’re not drinking as a general rule, you’re probably a little fuzzy or entirely asleep
  - The 2 biggies, those can happen anywhere along the way

BJ explains the 2 biggies that tell you death is close

- 1 – Modeling of the skin, a sort of lacy bluish experience where your body’s just not moving blood effectively
  - You’ll see skin changes, especially the extremities
- 2 – Breathing patterns change
  - Oftentimes you get apneic: long periods of no breath at all
  - You often hear the death rattle, which often is sort of a gurgling sound with breathing
  - That’s just because your oropharynx reflexes are dying out
  - So you’re no longer moving fluids as they pool in the back of your throat
  - If your reflexes are no longer functioning, you’re not likely feeling it
  - A death rattle sounds pretty gnarly, but it’s generally probably harder for the audience than the person dying
- That’s only going to last for hours or at most, a day or two

**Bridget describes the experience for the people around the dying person**

- She has counseled a lot of people and there’s a feeling of preciousness
- We don’t know when that last breath is going to come
- Maybe we really want to be there, maybe we feel like we can’t

***Often for someone watching and waiting, it can be really hard to stay connected to our own experience***

- People won’t get up and go to the bathroom
  - Because they don’t want to miss that moment
- People don’t eat
  - Maybe their appetite is low, which is fine

**⇒** It is a time to be thinking about really basic needs and basic comforts for everyone in this space

- Because that influences the space and the environment for all
- Most people feel like this is the dying person’s experience, and all of the focus is there
  - We’re watching every respiration, we’re even matching their breathing
  - We’re creating anxiety in our own bodies because of that
- If we can invite attention to everyone’s experience and give permission to things like, you need to take a walk, go take a walk
- It may mean that they die when you’re not in the room, and maybe that’s okay
- Maybe they die in the one minute you’re going to the bathroom for the first time in 6hours
  - It may just be that way

BJ agrees that Bridget is pointing to such an important point

- A lot of loving families keep these vigils and don’t sleep, don’t do anything so that they can be there for the death
- Thinking that’s what it means to be there when someone dies
  - Is to be there in that exact moment when they take their last breath

***This is a lived experience for everyone***

- You got to sleep

BJ shares what many who work in hospice have seen, “*It seems to be that a lot of people need to be alone for the final moments on the planet, to really let go…it is a thing.*”

**⇒** So you going to the bathroom or taking a walk or stepping out of the room may be exactly the thing that that person needs to finally let go

- The message is don’t leave, and therefore the person will never let go
  - You’re just potentially can make it harder and harder for that person to actually finally let go
- So go to the bathroom, take a walk, kiss the person goodbye, drink some water

***And know that not only they may be gone when you come back, but that may be exactly what they needed to finally let go (it’s a hard one for families to take in)***

**Final thoughts on the topic of dying**

- It’s slippery, it’s huge, it’s windy, it’s an inherently messy conversation
- It’s not just us struggling to articulate something as much as we are articulating messy, this inherent complexity of something

---

## Selected Links / Related Material

**Mettle Health**: [Mettle Health](https://www.mettlehealth.com/) (2025) | [1:15, 1:22:15]

**Episode of** ***The Drive*** **with BJ Miller**: [#135 – BJ Miller, M.D.: How understanding death leads to a better life](https://peterattiamd.com/bjmiller/) (November 2, 2020) | [1:15, 3:30]

**Palliative care program at UCSF**: [UCSF Palliative Care Medicine](https://palliativemedicine.ucsf.edu/patient-care) (2025) | [5:00]

**BJ’s recommended advanced directive forms**: [1:23:45]

- [Prepare Advance Directive](https://prepareforyourcare.org/en/advance-directive) (2025)
- [Five Wishes](https://www.fivewishes.org/for-myself/) (2025)

**Increased incidence of cancer in young people**: [Differences in cancer rates among adults born between 1920 and 1990 in the USA: an analysis of population-based cancer registry data](https://pubmed.ncbi.nlm.nih.gov/39095135/) | *The Lancet, Public Health*(H Sung et al. 2024) | [1:30:45]

**Episode of *The Drive* with Sean Mackey on pain**: [#345 ‒ Chronic pain: pathways, treatment, and the path to physical and psychological recovery | Sean Mackey, M.D., Ph.D.](https://peterattiamd.com/seanmackey/) (April 21, 2025) | [1:38:15]

---

## People Mentioned

- [Chris Adrian](https://www.mettlehealth.com/counselor-chris-adrian) (Palliative care physician at Mettle Health) [1:33:15]
- [Sean Mackey](https://med.stanford.edu/profiles/sean-mackey) (Redlich Professor, Professor of Anesthesiology, Perioperative, and Pain Medicine (Adult Pain) and CHief of the Division of Stanford Pain Medicine) [1:38:15]
- [Roland Griffiths](https://hopkinspsychedelic.org/griffiths) (1946-2023, Professor of neuroscience, psychiatry, and behavioral science and founding director of the Center for Psychedelic and Consciousness Research at Johns Hopkins; expert on psychotropic drugs) [1:55:15]

---

##### BJ Miller, M.D. and Bridget Sumser, L.C.S.W.

BJ Miller earned an undergraduate degree in art history from Princeton University. He earned his medical degree from UCSF and completed an internal medicine residency at Santa Barbara Cottage Hospital, where he was chief resident. He completed a fellowship in hospice and palliative medicine at Harvard Medical School, working at Massachusetts General Hospital and the Dana-Farber Cancer Institute. [[Family Action Network](https://www.familyactionnetwork.net/speaker/bj-miller-m-d/)]

Dr. Miller was an Assistant Clinical Professor and palliative care physician at UCSF for over 13 years. He has counseled over 1,000 patients and family members on dealing with difficult health situations. His 2015 TED talk, [*What Really Matters at the End of Life*](https://www.ted.com/talks/bj_miller_what_really_matters_at_the_end_of_life?language=en), has been viewed over 11 million times. He co-authored the book, [*A Beginner’s Guide to the End: Practical Advice for Living Life and Facing Death*](https://www.amazon.com/Beginners-Guide-End-Practical-Advice/dp/1501157213/ref=sr_1_1?crid=1TIRLCKIIW8DL&dib=eyJ2IjoiMSJ9.llrBuFyfqj9RCt5CxB0CxSNt0dL-NQny6LO7TkgpSHPxGZ5MlGzGAjg5w0BkJbPm.tnQ_a0A8hDEhxlKjCnHt-ThcgDNypjaWsPZ8q70RcQE&dib_tag=se&keywords=A+Beginner%E2%80%99s+Guide+to+the+End%3A+Practical+Advice+for+Living+Life+and+Facing+Death&qid=1743517764&sprefix=a+beginner+s+guide+to+the+end+practical+advice+for+living+life+and+facing+death%2Caps%2C74&sr=8-1). Dr. Miller is the co-founder and President of Mettle Health, an online palliative care service that provides support to patients and families living with illness. [[Mettle Health](https://www.mettlehealth.com/founders)]

Bridget Sumser earned an undergraduate degree from Mills College. She earned a Master’s in Social work and completed a Zelda Foster fellowship in palliative and end-of-life care at the New York University Silver School of Social Work. She also completed a palliative care social work fellowship at Beth Israel Deaconess Medical Center in New York. She is a member of the Social Work Hospice and Palliative care Network, and was honored as an emerging leader in Palliative Social Work in 2015. Bridget Sumser is a licensed clinical social worker who specializes in helping people living with serious illness. She works as a social worker with the [Palliative Care Program for adults at UCSF](https://palliativemedicine.ucsf.edu/patient-care) , a counselor at [Mettle Health](https://www.mettlehealth.com/counselor-bridget-sumser), and has a [private practice](https://www.bridgetsumser.com/practice). She co-edited the book [*Palliative Care: A Guide for Health Social Workers*](https://www.amazon.com/Palliative-Care-Health-Social-Workers/dp/0190669608/ref=sr_1_1?crid=1PM4LABUD6Q67&dib=eyJ2IjoiMSJ9.4yS1d3a02OIkN7kTohmFD6Vn_Oq-V4Fc0GuKTyD-By87D2UJaRzVYmMQEzLtYspen7nFiMkdaEQzffDAxwo8Ww.QDgmKMsrljeW2X1LFPjUN3KqUGrJ3DCyVzXT-W4ekLo&dib_tag=se&keywords=Palliative+Care%3A+A+Guide+for+Health+Social+Workers&qid=1743515862&sprefix=palliative+care+a+guide+for+health+social+workers%2Caps%2C72&sr=8-1). [[UCSF](https://palliativemedicine.ucsf.edu/people/bridget-sumser)]