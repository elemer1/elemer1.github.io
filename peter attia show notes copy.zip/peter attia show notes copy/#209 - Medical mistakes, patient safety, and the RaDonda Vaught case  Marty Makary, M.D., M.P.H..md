# #209 ‒ Medical mistakes, patient safety, and the RaDonda Vaught case | Marty Makary, M.D., M.P.H.

**Source:** [https://peterattiamd.com/martymakary2/](https://peterattiamd.com/martymakary2/)

---

##### Check out more content with expert, Marty Makary, M.D., M.P.H.:

- *(Aug 26, 2019)* [Ep #68 – The US healthcare system: why it’s broken, steps to fix it, and how to protect yourself](/martymakary/)
- *(Jan 3, 2022)* [Ep #189 – COVID Part 1: Current state of affairs, Omicron, and a search for the end game](/covid-19-current-state-omicron/)
- *(Jan 24, 2022)* [Ep #192 – COVID Part 2: Masks, long COVID, boosters, mandates, treatments, and more](/covid-part2/)
- *(Jun 6, 2022)* [Ep #209 ‒ Medical mistakes, patient safety, and the RaDonda Vaught case](/martymakary2/)

Marty Makary is a surgeon, public policy researcher, and author of the New York times best-sellers [Unaccountable](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198367/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) and [The Price We Pay](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=). In this episode, Marty dives deep into the topic of patient safety. He describes the risk of medical errors that patients face when they walk into the hospital and how those errors take place, and he highlights what amounts to an epidemic of medical mistakes. He explains how the culture of patient safety has advanced in recent decades, the specific improvements driven by a patient safety movement, and what’s holding back further progress. The second half of this episode discusses the high-profile case of RaDonda Vaught, a nurse at Vanderbilt Hospital convicted of negligent homicide after she mistakenly gave a patient the wrong medication in 2017. He discusses the fallout from this case and how it has in some ways unraveled decades of progress in patient safety. Furthermore, Marty provides insights in how to advocate for a loved one in the hospital, details the changes needed to meaningfully reduce the death rate from medical errors, and provides a hopeful vision for future improvements to patient safety.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/martymakary2/the_Drive_public.png)

Play

#209 ‒ Medical mistakes, patient safety, and the RaDonda Vaught case | Marty Makary, M.D., M.P.H.

#209 ‒ Medical mistakes, patient safety, and the RaDonda Vaught case | Marty Makary, M.D., M.P.H.

1x15s30s

0:001:45:27

## We discuss:

- Brief history of patient safety, preventable medical mistakes, and catalysts for major changes to patient safety protocols [3:00];
- Advancements in patient safety and the dramatic reduction in central line infections [16:45];
- A surgical safety checklist—a major milestone in patient safety [26:00];
- A tragic case stimulates a culture of speaking up about concerns among surgical teams [28:00];
- Studies showing the ubiquitous nature of medical mistakes leading to patient death [32:30];
- The medical mistake of over-prescribing of opioids [36:30];
- Other types of errors—electronic medical records, nosocomial infections, and more [38:00];
- Importance of honesty from physicians and what really drives malpractice claims [43:15];
- A high-profile medical mistake case involving nurse RaDonda Vaught [50:15];
- Investigations leading to the arrest of RaDonda Vaught [1:02:30];
- Vaught’s trial—a charge of “negligent homicide” [1:08:00];
- A guilty charge and an outpouring of support for Vaught [1:15:00];
- Concerns from the nursing profession over the RaDonda Vaught conviction [1:21:00];
- How to advocate for a friend or family member in the hospital [1:23:15];
- Changes needed for meaningful reduction in the death rate from medical errors [1:29:30];
- Blind spots in our current national funding mechanism and the need for more research into patient safety [1:34:30];
- Parting thoughts—where do we go from here? [1:38:30];
- More.

§

## Show Notes

## Brief history of patient safety, preventable medical mistakes, and catalysts for major changes to patient safety protocols [3:00]

**M&M Conferences in hospitals discuss things that go wrong and any deaths**

- Peter and Marty have been talking privately now for about 2 months about the issue of patient safety
- Marty has worked tirelessly on this issue for as long as Peter has known him
  - They met in 2002
- Many of Marty’s colleagues have also taken up the mantle on this, such as [Peter Pronovost](https://www.uhhospitals.org/about-uh/leadership/uh-system-leadership/peter-pronovost)
- When Peter thinks back to his medical training, a lot of changes happened in those 5 years
  - Something as simple as a [time-out](https://bulletin.facs.org/2017/06/time-outs-and-their-role-in-improving-safety-and-quality-in-surgery/) did not exist before he entered his residency
  - When he was an intern, there was no surgical [time-out](https://bulletin.facs.org/2017/06/time-outs-and-their-role-in-improving-safety-and-quality-in-surgery/) in the operating room
  - Then by the time he left residency, you couldn’t do an operation without a time-out

> “*The culture of medical safety is something that the field of medicine has been struggling with for a couple of decades*”‒ Peter Attia

- Marty recalls, when they were residents, any errors or adverse outcomes were entirely blamed on the individual
- He remembers an example from the [Surgical M&M Conferences (morbidity and mortality conferences)](https://en.wikipedia.org/wiki/Morbidity_and_mortality_conference)
  - This is a weekly (or monthly) conference in hospitality focused on things that go ary or any death
  - It’s part of internal quality improvement
  - It’s legally protected under a special clause so that it’s not discoverable in court
    - This allows everyone to have the liberty to discuss things honestly

> “*It’s an amazing conference*”‒ Marty Makary

- Marty remembers listening to these stories at the M&M Conferences of the perfect storm of how this and that happened, and the patient was ultimately hurt by it or had a near miss
  - He realized this could have happened to him
  - Initially he was blown away by these stories
  - But by the time he became an intern he was totally numb to it and thought, “*That stuff happens, and you should try to do better*”

***M&M is an incredible conference because you hear the discussions of what we could have done better***

**Honesty and humility**

- Marty loved the intense humility he would see at the conference, exerted by these powerful names in American surgery
  - Giants in the field would say with all honesty, “*I didn’t look carefully enough at the CAT scan before the case, I should have recognized that there was an aberrant artery in that location that I ended up getting into trouble with. I feel bad*.”
  - Marty thought this was healthy for the field
- When they were residents, it was common that the resident presenting was completely fried for things that were out of their control
  - Marty suggests, “*You don’t want to blame your weak medical student who dropped something. You try to present it in a neutral way and you jump on the grenade for the team*.”
- Marty remembers a trauma patient who died; this guy was basically dead on arrival
  - There was nothing they could have done medically
  - He was not in the case, but the chief resident felt bad and said, “*I should have pushed harder. I should have just pushed everybody harder*.”
  - Marty remembers thinking he was beating himself up in this spirit of individual responsibility

**Improvements in safety and preparation**

- Now, we’ve matured to recognize we need to have safe systems
  - We need to have the chest tubes in the operating room or in the trauma bay, so you can get to them quickly
  - We need to value non-technical skills as doctors, not just the technical skills of doing procedures, but effective communication and inspiring confidence in people around you and organizational skills
- Doctor’s generally haven’t valued that kind of teamwork and communication skills
- But they’ve matured not to recognize that when something goes tragically wrong, they need to ask, “*How can we do better?*”

> “*But how can the system, how can the hospital be set up differently?*”‒ Marty Makary

- A system’s approach is entirely novel in the last 20 years of medicine
  - How can the NICU be moved to be closer to the labor and delivery ward?
  - How can the elevator be held for the trauma team so they don’t have to wait for it

**Patient safety‒ the size of the problem**

*Was there a single catalyzing event that initiated advances in patient safety or was it a general progression?*

- One example that comes to mind for Peter is how the 80-hour work week came to be how residents trained
  - This came out of a singular event
  - A woman, [Libby Zion](https://en.wikipedia.org/wiki/Libby_Zion_Law) went to a NY hospital
  - She was in an ER and a resident took care of her and prescribed her a medication without realizing she was on another medication
    - There was a huge contraindication to this and she died of hyperthermia or something like that; a tragic outcome
  - Her death became a rallying cry around residents working too hard and not getting enough sleep
  - Her family carried the torch on and many years later, that resulted in the changes with the [ACGME (Accreditation Council for Graduate Medical Education)](https://en.wikipedia.org/wiki/Accreditation_Council_for_Graduate_Medical_Education)
- Marty agrees, the push for safety was inspired by the Libby Zion case
- This happened in 1984
- Libby’s father was a *New York Times* reporter, and he showed to the world that ***you can die not just from the illness that brings you to care but you can die from the care itself***
  - And that can occur at a rate that may be higher than we appreciate
- Libby was given  medication that should not have been given to her
  - She had an interaction that should have been recognized

**⇒ Out of this case came a ruling that you can’t have people work 48 straight hours**

- This was in the 1990s; there was tension around this
- NY state set up a commission to make sure you don’t have people doing procedures and making critical decisions when sleep exhausted
- In 1999 they issued a groundbreaking [report](https://nap.nationalacademies.org/resource/9728/To-Err-is-Human-1999--report-brief.pdf) where they reviewed records independently and ***found that an estimated 44,000-98,000 people die from medical mistakes each year in the US***
  - Sometimes, it was sloppy handwriting
  - Sometimes, it was ordering something that should have been done on another patient
  - Sometimes, it was forgetting something
  - Sometimes, it was the patient falling through the cracks, but they identified what is now known as a preventable adverse event
    - Known on the street as a medical mistake
  - *People were blown away*
  - This report came out of a highly respected [Institute of Medicine, now called the National Academy of Medicine](https://en.wikipedia.org/wiki/National_Academy_of_Medicine)

***This report put into stone the idea that dying from medical mistakes, if it were a disease, would rank as the 8th leading cause of death***

- There was protest and anger
- The residents thought this was BS

- [Lucian Leape](https://www.hsph.harvard.edu/profile/lucian-l-leape/) (one of the co-authors) wrote a dissenting commentary afterwards, where he argued the death rate is much higher
  - The methodology used simply reviewed charts, not every mistake is documented
  - *He thought it was an underestimate*

**Let’s say 100,000 people die a year in hospitals because of medical errors. Is there any way to determine how many of those are deaths in people who were going to probably die during that admission anyway?**

*Think of it as people who are on the edge of the cliff for whom a medical error pushes them over the cliff versus people who are 30 feet away from the cliff, for whom the medical error picks them up over the fence and shoves them over the cliff*

- This is a great point
- The study did not distinguish between these 2 scenarios
- People in the hospital tend to be older and many times the medical error hastened death, but was really not the primary cause of death

***But any medical error that resulted in death, even if it hastened an imminent death was counted as a medical mistake***

- This is difficult, and is as it should be

**One story sticks with Peter**

- This was the 1st or 2nd month of his internship, maybe July or August
- He was out at Sinai, one of the satellite hospitals of Hopkins
  - So the same quality of support staff was not there
- A resident wrote an order for a patient who was in the ICU, but was going to be transferred out
  - She was not ventilated but just waiting for a bet to move to the floor
  - She was having a hard time sleeping
  - So the resident wrote an order for 1 g of [Ativan](https://en.wikipedia.org/wiki/Lorazepam), instead of 1 mg
- Ativan is a benzodiazepine that would normally be dosed somewhere between 0.5 mg and 2 or 5 mg

***The resident meant to write 1 mg, not 1 g***

- The patient got a 1000x dose‒ that was **mistake #1**
- **Mistake #2** – Any nurse would immediately recognize this as an error, but the nurse on staff was brand new
  - The nurse took the order from the chart exactly as it was written and sent it to the pharmacy
- **Mistake #3** – A pharmacist with any experience would recognize this as a super physiologic dose, enough to kill a stadium of people
  - The pharmacist was also new; it was a night shift where typically there’s less action
  - So, the pharmacist sent up all the Ativan he had in the system (20-30 mg) and said he would reach out to another hospital to get the rest and send it up later
  - This should have been a red flag, but it wasn’t
- The nurse administered this dose of Ativan to the patient who very shortly after stopped breathing
- Fortunately this happened in an ICU and therefore, the nurse was able to see that the patient had stopped breathing, called the doctor, they intubated the patient and the next morning, she was ultimately extubated and fine

 **⇒ This was a near miss but a huge medical error**

- It did not result in death, but had this occurred on the floor, the patient would have died

***This story illustrates the horrible Swiss cheese effect of‒ how many pieces can you line up and still fit a pencil through?***

- Marty adds, “*When we look back and review these catastrophic errors, oftentimes every single thing is a little off. And what happens is, sometimes we refer to it as a comedy of errors, sometimes we call it the perfect storm, but it happens. So that’s the terminology we’re using now is if it avoids a patient harm, it’s a* ***near miss****. And if it involves patient harm, it’s called a* ***preventable adverse event***.”

## Advancements in patient safety and the dramatic reduction in central line infections [16:45]

**From the early 2000s until now, what have been some of the biggest advances and do we have metrics to objectively talk about whether or not improvements have come along?**

- Sitting in those M&M conferences made Marty realize every error appears to be unique, but there are certain basic principle root causes
  - 1 – The physician is burnt out
  - 2 – They physician didn’t have the support they needed
  - 3 – Maybe the physician had alert fatigue, meaning they’re being pinged with a lot of unnecessary alerts so that when a real alert comes along, it’s easy to ignore
    - For example, they may feel like the pharmacy is crying “Wolf” in that every time they prescribe something, there’s some alert
    - Sometimes you’re prescribing a therapy for someone and you have to override 5 or 6 alerts just to prescribe 1 treatment path

**Central line infections**

- In 2006, their friend [Peter Pronovost](https://www.uhhospitals.org/about-uh/leadership/uh-system-leadership/peter-pronovost), who was at Johns Hopkins tackled one form of preventable adverse event‒ central line infections
  - We had known for a long time there was a protocol that would reduce the risk of infecting the central line
  - A [central line is an intravenous catheter](https://en.wikipedia.org/wiki/Central_venous_catheter), but it goes into one of the very deep veins
    - Typically either a deep vein in the neck (jugular) or chest (subclavian vein) or in the groin (femoral vein)
    - This procedure is a big deal in terms of both risk of infection and risk of hitting an artery or puncturing the lung
- During their time as residents in medicine, they saw many central line complications
  - The lines would get infected or clotted
  - You had to change them frequently
  - Many people had lines they did not need
- Peter Pronovost and the nurses in the ICU developed a [protocol](https://pubmed.ncbi.nlm.nih.gov/15483409/) to minimize infection; they suggested:
  - Avoid the groin whenever possible
  - Use a full-length drape
  - Wash your hands extensively
  - Use sterile technique
  - Wear a mask and face shield

***When this protocol was rigidly adhered to, there was a dramatic reduction in central line infections***

- Peter had a relationship at the Michigan Hospital Association, which then adopted this protocol broadly in an ICU collaborative of dozens of hospitals
  - They got the median central line infection rate down to just below 0.5%
    - Down from a rate of 3-5%
    - This was a huge reduction, a log-fold reduction
- A rate of central line infections of 3-5% was consistent with what Marty and Peter saw as interns; taking care of infected central lines was routine

**This reduction in central line infections was celebrated as a milestone in patient safety**

- They succeeded in tackling one form of preventable harm
  - Granted it was less than 1% of all the preventable harm in healthcare
- They standardized this protocol and got broad compliance
- It was rapidly adopted
  - Not the typical 17-year lag between evidence and broad adoption in practice that is seen with other things introduced

**Peter noticed a change in the culture of safety from the beginning to end of his medical training**

- When Peter was a medical student, it was the wild west
- He was putting central lines in people as a medical student
  - Always with a resident supervising
  - But he thinks it was pretty unusual for a 3rd and 4th year resident to be putting in central lines
  - By the time he finished medical school, he’d probably put in 25 central lines
    - This was partially due to his stint at the NIH, in clinical service in oncology
  - By the time he was an intern, he was pretty good at putting in a central line
- He probably put in 100 central lines unsupervised as an intern
- He probably put in 400 central lines in all of residency
- He had 1 [hemopneumothorax](https://en.wikipedia.org/wiki/Hemopneumothorax) that showed up 4 days afterwards
  - He never saw the original x-ray
  - To miss that was his mistake
- He has not idea what his infection rate was
- All he knew is he wasn’t causing [pneumothoraces](https://en.wikipedia.org/wiki/Pneumothorax)
- By the time he was in his 5th year, that wild west was gone
  - Interns were not allowed to put in central lines
  - Only 2nd year residents in the ICU were putting in central lines, and always under the supervision of the ACS in a fluoro lab
    - This allowed them to immediately get an image right after
- He wonders what the protocol on central lines is now at teaching hospitals

**The work of** [**Peter Pronovost**](https://www.uhhospitals.org/about-uh/leadership/uh-system-leadership/peter-pronovost) **and others fixed central line infections and brought a greater appreciation to the seriousness of this procedure**

*Did anyone follow up and notice any changes in the rate of pneumothorax?*

- There was a move towards dedicated teams by the time Marty and Peter finished their residency
- The central line team matured into a dedicated team
- Then it turned into a rule that you really were not supposed to put in central lines at all
  - Only the dedicated team should do it
- Then they started using ultrasound so they don’t take 10, 20 probes until they aspirate blood
- The team of course used the protocol that [Peter Pronovost](https://www.uhhospitals.org/about-uh/leadership/uh-system-leadership/peter-pronovost) introduced

***The fact that we could conquer something like central line associated infections (that nobody thought you could ever tackle), and the cost savings and the avoidable harm associated with that, that was a major milestone in patient safety***

- 2 years after the [Pronovost publication](https://www.nejm.org/doi/full/10.1056/NEJMoa061115) on the central line toolkit in 2008 (which within 3 years was becoming standard in many ICUs around the country), ***Medicare decided they’re not going to pay for a catastrophic medical mistake***
  - This is what we call a **never event**, *something that should never happen regardless of the circumstances*
  - For example, you should never leave an instrument or a sponge behind during surgery unintentionally
    - Up  until then, if you had to go back and do an operation to remove a retained foreign object, you were paid for that procedure as well
    - Medicare basically said, why are we rewarding this financially
    - They and other insurance companies began not paying for this stuff

*Now it’s accepted that’s on the hospital if you have a catastrophic medical mistake*

## A surgical safety checklist—a major milestone in patient safety [26:00]

- In 2009, the WHO organized a committee to address patient safety

> “*At this time, patient safety was the hottest thing in healthcare*”‒ Marty Makary

- Marty had just [published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1570547/) at Hopkins, the surgery checklist with Peter Pronovost as his mentor.
- They put out a bunch of articles and the WHO invited Marty to present his checklist
  - [Atul Gawande](https://atulgawande.com/about/) was chair of the committee
  - Initially, he was not that interested in the idea, but warmed up to it

![](https://peterattiamd.com/wp-content/uploads/2022/06/f1-makary3-825x1024.png)

**Figure 1. Marty’s surgical safety checklist.** Image credit: [*Annuals of Surgery* 2006](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1570547/)

- Atul Gawande eventually saw the great story in the checklist and wrote the book [*The Checklist Manifesto*](https://www.amazon.com/Checklist-Manifesto-How-Things-Right/dp/0805091742/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1653480169&sr=8-1)
- Initially, Atul presented a competing idea at the WHO
  - Called the surgery Apgar score, which nobody adopted
  - It was not risk adjusted
  - This is an old school score; a rapid test is done after a baby is born that is used to predict its survival
  - The idea was you could do a rapid assessment in a matter of seconds and assess a prognosis
  - People said this should be adjusted for the severity of a surgery‒ a breast biopsy is different from heart surgery
  - The committee voted unanimously against this proposal
- The committee saw the success of checklists in aviation and liked the simplicity of it
- This is how their checklist became known as the [WHO surgery checklist](https://en.wikipedia.org/wiki/WHO_Surgical_Safety_Checklist), shown in the figure below
  - To this day it hands on the operating room walls of most operating rooms in the world
  - It was adopted in 2009

![](https://peterattiamd.com/wp-content/uploads/2022/06/f2-makary3-1024x740.png)

**Figure 2. WHO Surgical Safety Checklist**  Image credit: [WHO](https://www.who.int/teams/integrated-health-services/patient-safety/research/safe-surgery/tool-and-resources)

- Atul Gawande did a [study (published in 2009)](https://www.nejm.org/doi/full/10.1056/NEJMsa0810119) and showed the checklist reduced adverse events and had an impact
  - This was an important moment in patient safety

## A tragic case stimulates a culture of speaking up about concerns among surgical teams [28:00]

**Do you remember the story of the heart transplant at Duke where they failed to do a crossmatch?**

- That was also a major milestone in patient safety and a lot of good came out of the lessons learned there
- They were doing a heart transplant on a young girl at Duke University
  - Duke is in the top 3 or 4 for this surgery
- They did not check a [crossmatch](https://en.wikipedia.org/wiki/Cross-matching)
  - This is part of blood compatibility testing
  - You mix blood from the donor with blood from the recipient and look for an allergic reaction, a hyper acute rejection signal
    - If this is observed, they abort the transplant
  - It’s a standardized procedure
  - It’s done before even a blood transfusion
  - If you need a blood transfusion and you have type A+ blood, it’s not enough to go to the blood bank and get any bag of A+ blood
    - They still have to do a crossmatch
- The crossmatch was not checked and the heart failed
- The hospital doctors felt terrible
- They did everything they could to prioritize her as a status level 1, the highest priority to get a second heart transplant
- They attempted a second heart transplant, and that transplant failed; and the woman died
- Peter remarks, “*You could effectively argue two other people died, who didn’t get a chance to have the heart that would’ve worked for them*.”
- In terms of financial cost, this was well over a million dollars
- Even more concerning was the lost years of life in a young, promising human being

*Where was the Swiss cheese on that one?  What went wrong to prevent the crossmatch?*

- It turns out that a nurse in the operating room sensed something was not right
  - But she didn’t feel comfortable speaking up
- Marty doesn’t know if it’s known why the crossmatch wasn’t done
- He has certainly seen patients go into the operating room where something should have been done beforehand and it wasn’t

***So the idea of creating a culture of speaking up or an atmosphere in the operating room where people feel that there’s collegiality, teamwork and they would feel comfortable voicing a concern, that no longer was a soft science***

- The lack of this culture undermined a gigantic operation in a young girl and had catastrophic consequences
- This was another major step
- All of the sudden, standardizing what we do became more of a science

## Studies showing the ubiquitous nature of medical mistakes leading to patient death [32:30]

- The ubiquitous nature of medical errors got documented in a 2014 [survey by the Mayo Clinic](https://www.mayoclinicproceedings.org/article/S0025-6196(18)30372-0/fulltext#%20), where in a survey of 6,500 doctors

***10.5% of doctors surveyed say that they had made a major medical mistake in the last 3 months***

- Marty comments, “*I might have felt like that in the lowest points of my residency, but I was surprised when I saw that*”
- Maybe some of these mistakes were caught and were what they call a near-miss

**Doctors have a crazy life; they’re getting pulled in all these directions**

- There’s pressure and stress
- And this is assuming that everything at home is fine
- People are dealing with external pressures

**In** [**2015, Mass General Hospital had a study**](https://www.fiercehealthcare.com/healthcare/medication-errors-occur-half-surgeries-mgh-study-finds) **done by researchers there**

***It showed 1 in 20 medications administered in the operating room involved an error***

- Most of their studies get put out in a communication sort of press release
- They’ve taken this study down from their website

**⇒ A mistake or adverse event occurred in 50% of operations**

- Mass General is one of the 3 best hospitals in the world
  - They like to call it “*Man’s greatest hospital*”

**Has the number of people that die from medical mistakes changed in the last 25 years?**

- In 2016, Marty’s research team at Johns Hopkins put out a [report](https://www.bmj.com/content/353/bmj.i2139.full) about deaths from medical mistakes (see the figure below)
- They wanted an updated number from the [1999 Institute of Medicine report](https://nap.nationalacademies.org/resource/9728/To-Err-is-Human-1999--report-brief.pdf) that about 100,000 people die a year from medical mistakes
- They did a review and showed a broad range where the median point of that range was 250,000 deaths
  - This would surpass the current #3 cause of death (stroke), and would put it after cancer and heart disease (which are far higher at 650,000 a year)

![](https://peterattiamd.com/wp-content/uploads/2022/06/f3-makary3-965x1024.png)

**Figure 3.  Medical errors were the third leading cause of death in 2013.**  Image credit: [*BJM* 2016](https://www.bmj.com/content/353/bmj.i2139.full)

> “*Medical error, if it were a disease, would rank as the number three cause of death using this estimate*”‒ Marty Makary

- It’s not a perfect estimate; they didn’t do autopsies on every death; they don’t have good numbers
- They found that the current number of deaths might be higher than what was reported in 1999

- But the CDC does not collect vital statistics on medical errors
  - Because you cannot record a death as a medical error because there’s no billing code for error
  - And the billing code system how we record our national vital statistics

*How would we put a 95% confidence interval around this estimate? Could it also be a lot lower?*

- 125,000 to 350,000
- Just before, Joe Johns put out a study saying this number was [400,000](https://journals.lww.com/journalpatientsafety/Fulltext/2013/09000/A_New,_Evidence_based_Estimate_of_Patient_Harms.2.aspx)
- They would argue that Marty’s estimate was low
  - Marty didn’t do any original research
  - They pulled together the existing studies, which are not perfect
- [Don Burwick](https://hcp.hms.harvard.edu/people/donald-berwick) commented on the study‒  *whether it’s the 3rd leading cause of death or 7th or 9th, it’s a major problem*
- There was a lot of heated discussion about this estimate, their review article
- A survey of doctors showed that ⅓ believed the estimate
  - ⅓ didn’t know
  - ⅓ didn’t believe the estimate

## The medical mistake of over-prescribing of opioids [36:30]

- Then the opioid epidemic hit, and opioids emerged as the #1 cause of death in the United States among people under 50
- Opioid deaths were a form of medical error when doctors were prescription opioids
  - Marty is guilty of this; he gave opioids out like candy; he feels terrible about it
- This year we just surpassed 100,000 opioid deaths in a 12 month period for the first time
- So the estimate of 300,000 deaths is before the opioid epidemic; it doesn’t include that 100,000 deaths

- The 107,000 deaths in the last 12 month period was for any opioids
  - A lot of that is fentanyl
  - Heroin is also included
- We don’t know the estimate of prescription opioids
  - We think this number has come down because we’ve gotten smart
- Prescription opioid abuse is probably way down because it’s more regulated
- Fentanyl-laced products are driving a lot of the opioid deaths now
- Marty puts previous opioid prescription rates in perspective, “*But we were prescribing, let’s say mid-career for me, one opioid prescription for every adult in the United States*.”
  - People didn’t need it
  - It was the medicalization of ordinary life for some people with mild pain
  - This was an American problem
  - A lot of countries only gave opioids to people with second degree burns
    - Or end of life cancer
    - Or in the perioperative period of major surgery

***Normal complications of unnecessary medical care is a form of medical error***

## Other types of errors—electronic medical records, nosocomial infections, and more [38:00]

> “*People don’t just die from disease, they die from the care itself*”‒ Marty Makary

**Marty’s historical perspective on patient safety**

- Before the modern era of patient safety (discussed from their residency onward), no one ever talked about patient safety
- If you were on rounds and thinking of giving a blood transfusion to a patient with a borderline indication you have to consider the fact that 1 in 80,000 blood transfusions can result in the wrong blood type being passed on from the lab and hurting a patient

***They used to never consider the role of human error in the care of patients***

- Now they ask, “*Do we need to keep people in the hospital for a week after surgery?*”
  - There is the added risk of falling from a new environment, tripping over the gown, wearing hospital slippers
  - The risk of getting an infection in the hospital

> “*There are risks to being in the hospital that we have to weigh*”‒ Marty Makary

**Where does** [**nosocomial infection (hospital-acquired infection)**](https://en.wikipedia.org/wiki/Hospital-acquired_infection) **rank in the causes of medical errors?**

- This is a difficult number to come up with because some people consider any infection after surgical care to be a nosocomial infection
  - But not all are preventable
  - So even a wound infection after surgery would be considered nosocomial

*So nosocomial meaning you’re getting it from the hospital may not necessarily be preventable*

- We’re not going to eradicate bacteria from the planet
- Knee replacement surgery is pretty good; the risk of infection is 0.8-0.9 of 1%
- Maybe this is the level that we have to accept
- Some people say we have to achieve zero harm
  - Peter worries that this creates an unrealistic expectation
- Orthopedics have really figured out how to do joint replacement in the most sterile manner imaginable, what about other areas

**Medication errors, errors from electronic medical records**

- There still are medication errors
  - Patients falling through the cracks
  - Normal complications of intervention they don’t need
- These medical errors aren’t from sloppy handwriting anymore; they’re from a lack of visual cues in the patient’s chart
  - So now you’re entering an order and you don’t have a binder in front of you with the patient’s name (so you know exactly whose chart you’re in)
  - You’re flipping screens, you’re in different tabs and you write an order for somebody who didn’t need it or the wrong person or something like that
- Peter adds, “*This happened to me about a month ago. So we use an electronic medical record in our practice. And I was in one patient’s chart, looking at a bunch of labs and looking at a bunch of things. And we had just switched to a new* [*EMR*](https://en.wikipedia.org/wiki/Electronic_health_record)*. We used one EMR for many years, and then we just switched to a new one, which has a completely different look. And when you switch to a new patient, it’s not entirely obvious*.”

> “I was blown away at how long it took me to recognize that I was in another patient’s chart”‒ Peter Attia

- For Peter’s practice, this is a low stakes scenario, because they don’t prescribe through this EMR (electronic medical record)
- With written charts there used to be all these visual cues that told you where you were
  - You recognized your handwriting
  - It was a miserable system and head a lot of problems, but this is one thing it had going for it over an EMR
  - And it was cyber secure
  - The old fashioned docs who had very good handwriting said that people need to write more effectively

## Importance of honesty from physicians and what really drives malpractice claims [43:15]

**Saying I’m sorry**

- Another healthy movement that came out of this patient safety endeavor has been the idea that “*Sorry*” works
- And what drives malpractice claims is your honesty with patients, not whether or not you make a mistake
- Marty has found that to be true in his practice
  - If you’re very honest with people, they’re incredibly forgiving
- He remembers ordering a CAT scan
  - He was busy
  - It was between operations
  - It ended up getting done on a wrong patient with a similar name
  - He doesn’t know if he mixed up the names or the nurse made a clerical mistake in entering the order
  - They we do a lot of verbal orders as attending physicians and this patient was already angry at him
    - This patient had a pancreatic leak
    - They just were frustrated with their care
    - Their expectations were unreasonable
    - Now Marty realizes this patient got a CAT scan they didn’t need
  - The patient was recovering, Marty goes to his room and says, “*Look, sir, I want to tell you something, you got a CAT scan you did not need, it was not intended for you. I’m not going to sugar coat it and say we wanted to make sure and look for something. It was a clerical mistake. I take full responsibility. I’m sorry. If you want the results. I haven’t even seen it yet. I just heard about this and I wanted to tell you first. I’ll get the results and share the results with you*.”
  - The patient who was pissed smiled and thanked him for his honesty
    - He  never sued him
    - Their bond grew and they are Facebook friends today

> “*People are hungry for honesty… We see it with so many aspects of medicine*”‒ Marty Makary

**Peter’s counterpoint to that story‒ a botched surgery**

- This is already known publicly
- Eddie Margain is a close friend of Peter’s in Austin
- One night over dinner he brought up the story of his wife Lorena, some medical issues
  - He didn’t know it at they time, but she wrote a [book](https://www.amazon.com/Way-Casa-Lotus-Memoir-Forgiveness/dp/1736390503/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1653491729&sr=8-1) about this
- She had a big workup and they found a mass on her adrenal gland
  - The [adrenal gland](https://en.wikipedia.org/wiki/Adrenal_gland) sits on top of each kidney, shown below

![](https://peterattiamd.com/wp-content/uploads/2022/06/f4-makary3.png)

**Figure 4. The Adrenal gland**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Adrenal_gland)

- The adrenal gland is incredibly important
  - It produces all sorts of relevant hormones‒ cortisol, epinephrine, norepinephrine
- The treatment for this tumor on her adrenal gland is to have it removed
  - You can live with 1 adrenal gland
  - This is a relatively straightforward operation
- She had the operation in Austin
- In the weeks that followed she went from bad to worse; she felt horrible
- She eventually went back to the doctor only to discover that he had taken out the wrong adrenal gland
- Now she needed another surgery and now she is a person who has no adrenal glands
  - You can’t live without your adrenal glands
  - She is dependent on exogenous forms of glucocorticoids
- The story gets even more difficult because there were more complications and things like that
- Lorena was about the sweetest person you’ll ever meet, and she only wanted 1 thing (not money)‒ she wanted an apology
  - And the surgeon wouldn’t give it; he had a million excuses
    - The egos, the arrogance, the hubris

**Hospital lawyers**

- Marty adds that the lawyers don’t help
  - Oftentimes they tell doctors not to talk to patients or the family
  - They often quickly negotiate a settlement and gag everybody
- Hospital lawyers make a lot of policy for doctors
- A lot of COVID policies have been driven by hospital lawyers or general counsels of businesses

> “*We have not had an honest conversation about patient safety in America because of that [gag orders]*”‒ Marty Makary

- - This is why Marty wrote the book [*Unaccountable*](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198367/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), about the issue of patient safety and how we can do better
    - He wrote “*We should ban all gagging in medicine. This should be an honest profession. No gagging*.”

- Lorena and Eddie are incredibly successful, well off; she said out of the gate, “*We’re not here to sue. There’s no amount of money you can give us that’s going to change our lives. We just want to make sure this never happens to anybody again*.”

- - This is a honest, reasonable request
- Other industries have achieved high levels of reliability
- In aviation over the last 25 years, how many plane accidents have we seen?
  - A [crash in 2009](https://en.wikipedia.org/wiki/Colgan_Air_Flight_3407) of a flight going to Buffalo, 50 people died
  - A [flight in 2018](https://en.wikipedia.org/wiki/Southwest_Airlines_Flight_1380), there was a woman partially ejected through a window who died
  - In the interim 9 years from 2009-2018, 6 billion passengers flew without a single fatality rate

*Pilots have a systematic way to use checklists and pathways and have safety nets; and they’ve created a crew resource management that encourages people as part of the discipline to voice any concern about safety and not to ridicule anyone who brings up that concern*

- That’s a life lesson that can be used in any setting

***You want people to ask questions and even challenge some deeply held assumptions you may have without ridiculing them***

- If you make fun of them once, if you mock a nurse once or yell at them for bringing something up because you’re busy, they will never feel as comfortable voicing a concern to you and your patients suffer
- You suffer from that lack of safety culture

## A high-profile medical mistake case involving nurse RaDonda Vaught [50:15]

- Peter notes, they wouldn’t be having this discussion if it weren’t for the [recent Vanderbilt case](https://en.wikipedia.org/wiki/RaDonda_Vaught_homicide_case) that took place in 2017

> “*This is an amazing story on so many different levels*”‒ Marty Makary

- RaDonda Vaught is a 36 year old nurse who was hired at Vanderbilt in 2015
- On Christmas Eve, 2017, she was taking care of a patient named Charlene Murphy, a 75 year old woman who was admitted for a subdural hematoma (a brain bleed)
  - The patient actually improved quickly, and 2 days later she was ready to leave and the doctors ordered one last scan while she was in the hospital
- The nurse RaDonda took her to the scanner and ordered some [Versed](https://en.wikipedia.org/wiki/Midazolam)
  - This is a sedative to help people stay still during the scan
- Presumably the physician who was caring for her ordered the Versed
  - But nurses will often ask for an open order of Versed if they need to use it in the  CAT scanner
  - Every now and then the radiologist will order it when they’re at the scanner if the patient is having trouble staying steady
  - This is a commonly used medication in that scanner
- The nurse goes into a system, it’s a relatively new system that’s got automated dispensing
  - There have been many complaints that there are too many alerts and you often have to override the system because there was not good coordination between the electronic health records and the pharmacy
  - So in this system you frequently had to override alerts
- She types in VE and the computer auto populates VEC ([vecuronium](https://en.wikipedia.org/wiki/Vecuronium_bromide)) instead of VER (Versed)
  - This is a paralyzing agent; it’s a potent paralyzing agent
  - She doesn’t see vecuronium instead of VER (Versed) and doesn’t realize the mistake
  - What is she carrying? A [little mobile Pyxis device](https://en.wikipedia.org/wiki/Pyxis_Corporation)?
  - She clicks on it and vecuronium comes out
- She gives vecuronium to the patient
- There was an alert
- And the vecuronium came up as a powder when most people would know Versed is a liquid
- But there are other things that come up as powders and you just have to inject some saline to suspend the powder
- Back to the Swiss cheese model‒ she reportedly was distracted and she suspends the powder into a solution
- Peter explains that vecuronium is only used on patients who are on a ventilator
  - This is really only something that can be used when a patient is either in surgery (and they’re fully anesthetized and on a ventilator), or in the ICU under the same conditions
- Presumably this patient was in the ICU, because otherwise you shouldn’t even have vecuronium in the Pyxis system
- The cap of vecuronium routinely has a emergency drug warning on it
  - Marty wants to be very careful about this because he didn’t see documentation that the bottle she had contained this warning

***Because vecuronium is a potent paralytic agent, the patient became paralyzed and then died***

- They were not in the ICU so the patient could not immediately be resuscitated
- It’s a tragedy, the woman was 75 and otherwise ready to go home
- Vanderbilt had documentation where 2 neurologists listed the cause of death as basically a brain bleed
  - It was deemed a natural cause of death
  - This was reported to the medical examiner

**So she dies on the scanner and the cause of death was stated as cerebral hemorrhage or subdural hematoma?**

- That’s right
- And the family has been gagged and is not speaking about the case
  - One member of the family told the media that they wanted to see the maximum penalty given to the nurse
  - The grandson said that the woman who died would have forgiven the nurse
- The nurse feels horrible and says exactly what she did
  - She recognized her mistake as the patient was deteriorating and admits that she may have caused this
  - She has been 100% honest

***She has even said subsequently that her life will never be the same, that she feels that a piece of her has died***

- Marty relates, “*I think we’ve all been a part of medical mistakes where we still think about that*.”

***The medical examiner does not investigate the case because the report is a brain bleed***

- The woman stops breathing on the scanner, then they attempted a full resuscitation
- When they cease to resuscitate her and/or when they declare end of life, usually at this point a resident fills out a death certificate
  - These are filled out very carefully
  - You have to write the primary cause of death, a secondary cause of death
  - 2 Vanderbilt neurologists issued this report and this came up later
- 2 years later, the medical examiner changes the cause of death to accidental after they get tipped off
- A month later, an [investigative report in the *Tennessean*](https://www.tennessean.com/story/news/health/2020/03/03/vanderbilt-nurse-radonda-vaught-arrested-reckless-homicide-vecuronium-error/4826562002/) reports‒ ***Vanderbilt took several actions to obscure this fatal error from the public***
- The error was not reported to state or federal officials
  - The law requires you to report it to the state and the [CMD, Centers for Medicare and Medicaid Services](https://en.wikipedia.org/wiki/Centers_for_Medicare_%26_Medicaid_Services)
- Anything called a sentinel event must be reported
  - This is clearly a preventable, adverse event related death
  - Not reported to the joint commission. You could argue that’s an accrediting body. It’s private. You can break their rules. It’s not a violation of the law. But
- Vanderbilt immediately negotiates an out-of-court settlement with the family
  - The family is gagged from saying anything about it
    - Except for the grandson who was legally not included in the gag order, he speaks up later
- When the hospital is asked about the case they say, “Oh, we can’t discuss it because of this legal settlement that we have.”

**Peter clarifies:** ***a month after this woman dies, the death certificate and the neurologists all agree she died of a subdural hematoma. But clearly the family has been told the truth, which is why they’re receiving a large settlement and asked to sign a gag order, and the nurse is being fired.***

**Fast forward a couple months**

- The nurse, RaDonda Vaught gets a job at another hospital (Centennial in Nashville) as a bed coordinator
  - All hospitals have bed coordinators
- Now it’s October, remember, this happened on Christmas Eve, so it’s almost a year out
- An anonymous person reports to the state NCMs (nurse case managers) that there was an unreported medical error
  - They got tipped off by an anonymous whistleblower
- Then the Tennessee Health Department, is tipped off formally
  - They state that they’re deciding not to pursue any action on this tip off
  - The agency actually said in a letter that the event did not constitute a violation and therefore, they’re not going to do anything
- As an interesting side note, many of these state medical boards are basically sleepy organizations… if you know the story of Dr. Death

**The story of Dr. Death**

- [Dr. Death](https://en.wikipedia.org/wiki/Christopher_Duntsch) was a neurosurgeon in Texas, multiple horrific catastrophic outcomes, all believe to be sentinel events, catastrophic, avoidable, medical mistakes
  - Negligence and people dying in his practice over many years documented by Laura Beil in a [famous podcast](https://en.wikipedia.org/wiki/Dr._Death_(podcast))
- Basically everyone knew of this doctor’s problems
- The residency program knew, but they just graduated him to get rid of him
- He had problems at numerous hospitals, but nobody would say anything
  - *This kind of speaks to this problem of the old culture of patient safety*
- Finally, there is something so egregious that happens that he gets arrested and goes to jail
- The state medical board didn’t want to touch it for the longest time
  - That’s typical of state medical boards; they generally don’t want to touch anything
  - Ironically, you can be Dr. Death and kill people and they don’t touch it, but if you prescribe [Ivermectin](https://en.wikipedia.org/wiki/Ivermectin), all of heaven and earth is coming down on you
    - Marty clarifies, “*I don’t believe Ivermectin has any activity against COVID*”
    - It has no downside, but he doesn’t recommend it

## Investigations leading to the arrest of RaDonda Vaught [1:02:30]

**Back to the Vanderbilt case‒  it’s late 2018**

- Almost a year after the event, the Tennessee Department of Health put out a statement
- The nurse was under orders by Vanderbilt to never speak to the family, but she had said through the media several times that she takes full responsibility
  - She even said in her trial that she was 100% at fault
  - Marty adds, “*I think she’s beating herself up over something that was probably a combination of her mistake and a system”*
- CMS starts investigating
- Medicare take whistleblower complaints seriously
  - They do a surprise investigation at Vanderbilt at the end of October/ early November
  - They spend about a week there
  - They’re pissed that Vanderbilt did not report this; it’s clearly a violation
- About a year after the event this becomes public
  - Vanderbilt would not discuss it
  - But a journalist was able to get a hold of this report from Medicare because it’s public document, it’s a public agency
    - It was not through a [FOIA (Freedom of Information Act)](https://en.wikipedia.org/wiki/Freedom_of_Information_Act_(United_States))
    - This was public information, but no names were in there
- The CMS told Vanderbilt, if you cannot show that you have taken system-wide actions to prevent this in the future, we are going to suspend all Medicare payments to Vanderbilt University Medical Center

> “*This may be the biggest threat in healthcare in the modern era*”‒ Marty Makary

- Vanderbilt gives CMS a so-called plan of correction to show what they’re doing, that they’re taking this seriously
  - This is not released to the public
  - A journalist got this plan through a FOIA request, after they tried to get it from Vanderbilt directly but were denied
- Then on February 19th, the name RaDonda Vaught became public information when she was arrested for reckless homicide and impairment abusing an adult

**Why was she arrested?  How often does the DA press charges for a medical mistake?**

- Marty has been in the field of patient safety  his entire career, and he’s never heard of charges being filed against a nurse
- He’s heard of outright fraud resulting in arrests
  - Dr. Death is an example
  - There’s a doctor in Michigan who was was giving chemotherapy to people who didn’t have cancer; that’s cold-blooded fraud
- If you exclude 2 types of errors‒ fraud/ financial crimes and doctors who are raping patients, *how many arrests have been for a medical error th at was not made deliberately?*

> “*Never heard of an arrest for an honest medical mistake*”‒ Marty Makary

- One of the principles of patient safety that has been advocated throughout the entire 25, 23 years of the Patient Safety Movement in America has been the concept of a culture, which is a doctrine that says, ***honest mistakes should not be penalized***
  - They should be penalized if there was mal-intent or substance abuse
  - Or somebody should be suspended from their role if they are an ongoing threat
- But honest mistakes should not be penalized, and that is a doctrine that has enabled people to speak up about this epidemic of medical mistakes in the US
  - This has been celebrated as a giant milestone of the American Patient Safety Movement
  - It’s a worldwide concept

***The arrest of RaDonda Vaught undid 23 years of advancement in patient safety. It undermined the very fundamental doctrine of “just culture”***

- She had documents the entire time, that show she immediately admitted what happened at the moment this woman died
- One of the victim’s family members said the patient would have forgiven her

## Vaught’s trial—a charge of “negligent homicide” [1:08:00]

**When did the trial start?**

- March 21-25, 2022
- In the interim, there was a meeting of the Tennessee Board of Licensure, basically the Department of Health
  - Remember they had said they’re not going to pursue this; then they flipped
- The Executive at Vanderbilt University, [C. Wright Pinson](https://www.vumc.org/surgical-sciences/person/c-wright-pinson-md-mba), is actually a pancreato-biliary surgeon, Marty knows him
  - He sort of admits to this board that looks into Vanderbilt‒ yes, the death was not reported, and our response at Vanderbilt was too limited
- Now at this point, RaDonda Vaught is getting a lot of national attention and she’s got big legal bills
  - She goes on a GoFundMe campaign, raises over a $100,000
  - She basically says in the GoFundMe campaign that she made a mistake and she needs legal costs

> “*This woman could not have been more honest about what happened*”‒ Marty Makary

- Around that time nurses nationwide take notice
  - There’s millions of nurses in the United States
  - They start getting very emotionally connected to this
  - They start showing up at some of these hearings in front of the Department of Health and they say, ***“I am RaDonda.”‒ that becomes a slogan that nurses around the country take on***
  - They put it on social media; hundreds of them stand outside at the time of her trial with signs: I am RaDonda
- Marty was talking with [Zubin Dabani](https://zdoggmd.com); he had the same reaction, “*Gosh, that could have been me*.”
- Look at the study from [Mayo Clinic](https://www.mayoclinicproceedings.org/article/S0025-6196(18)30372-0/fulltext#%20), 10.5% of people admit to a major medical mistake in the last 3 months
- RaDonda Vaught made her court plea in February of 2019, just about a year after the incident
  - She pleads not guilty
- Her lawyers argue that Vanderbilt shares part of the blame
- Several months later, the Tennessee Department of Health, which said they’re not going to pursue action against her, they flip
  - They reverse their position and they go after her
  - They use the argument that they must immediately investigate what they describe as a threat to the public
- Her lawyer, knowing that they’re going to go to trial for the criminal of homicide, he asks the judge to postpone the Tennessee Department of Health hearing

**Why was she charged with homicide, not manslaughter?**

- She was charged with reckless homicide and abuse
- She has 2 hearings and 2 legal proceedings ahead of her, about a year after the incident
- A year and a half out, she’s got the Tennessee Health Board and she’s got the criminal case to go
- Marty paraphrases, “*Her lawyer says, look, Tennessee Health Board, they’re acting like a bunch of clowns. They said, they’re not going to take any action, and then over a year later, they suddenly reverse their position. What’s going on?*”
  - They ask the judge to postpone the hearing
  - They refuse to postpone it until after the criminal trial because she may pose an “urgent threat to the public”
- At the same time, Vanderbilt is just hanging out arguing they can’t say anything about the case
  - This *Tennessean* investigation says that they’ve obscured the circumstances of her death
- And this grandson is so frustrated
  - He makes a statement around then that says that Vanderbilt is engaged
  - Remember he’s not under the gag order
  - He says, “*There’s a coverup that screams*.”
- [COVID](https://en.wikipedia.org/wiki/COVID-19) comes, hits this country
  - That’s a coronavirus that resulted in two pandemics
  - It tragically killed about a million Americans
  - Followed by a subsequent pandemic called a pandemic of lunacy

**The department of health hearing is first**

- She says “*This is completely my fault*.”
- Her license is revoked even though the board says things that we would sympathize with
  - The Vice-Chair of the board says, “*We all make mistakes*.”
  - And there have been many mistakes and failures in this case suggesting basically that Vanderbilt as part of the blame
- The board also says, “*Our role is just to evaluate the role of the nurse here*.”

**The criminal trial in 2022**

- Then 3 months ago [February 2022], it goes to the criminal trial and the Davidson County DA, Glenn Funk, has his 3 assistant DA’s go to the mat in court and they aggressively and viciously went after her
  - These 3 assistant DAs are Debbie Housel, Chad Jackson, and Brittani Flatt
  - It was a new job for them

> “*They go viciously after her and argue that there was negligent homicide*”‒ Marty Makary

- RaDonda does everything she can to try to defend herself

**How does the DA argue this is homicide?**

*Peter compares this to a driver hitting a cyclist with their car and killing them*

- Assume the driver is not under the influence of alcohol or anything; they’re not driving recklessly
- They’re driving safely and kill a cyclist
- He can’t think of any instance in California (where he used to live) of a driver in this circumstance facing criminal charges
  - Unless there was reckless behavior or alcohol involved
- Peter asks, “*What rises to the level of even manslaughter, vehicular manslaughter… is that when you’re driving recklessly and another person dies as a result of it?*”

## A guilty charge and an outpouring of support for Vaught [1:15:00]

**RaDonda’s 10 mistakes**

- She was charged with “negligent homicide and abuse of an impaired adult” and found guilty of both of those charges
- In the arguments that they made, they had cited [10 mistakes](https://www.tennessean.com/story/news/health/2019/03/27/radonda-vaught-vanderbilt-nurse-homicide-trial-vecuronium-versed/3216750002/) that she had made
- It was kind of the Swiss cheese model that we had talked about with patient safety

> “*This is the perfect storm, if you will*”‒ Marty Makary

- 1 – She was distracted
- 2 – She overrode the warning alert, even though nurses at that hospital say that they do that every day
- 3 – The drug was a powder and not a liquid
- 4 – The cap should have said it was a paralyzing agent
- There’s so many things that they point to
  - You can frame somebody, you can make somebody look like they are doing something
- Marty notes, “*Can you imagine if they had the insights that we have at our M&M conference, it would just look really bad on the outside.*”
- These are aggressive young lawyers
- Glen Funk is the DA
  - He’s getting a lot of attention around this time because his office that is bringing the charges against a Vanderbilt nurse for a medical mistake that was an honest mistake that she admitted to immediately
  - He had 2 others running against him, condemning this saying, “*This is a farce. What’s going on. Something is fishy here*.”
- There are rumors, conspiracy theories in Nashville that maybe there was some entity behind this oddly aggressive action against this nurse
  - A competing health system, Vanderbilt University itself to bring tension away from its error in not reporting and other errors related to this case
  - Marty doesn’t know, has no opinion on any of those

***To have a DA so aggressively go after a nurse for an honest mistake with such a significant charge, it is odd. Now, she was found guilty and sentenced very recently.***

- She was found guilty, negligent homicide

**What was the possible range of sentences she could receive?**

- The judge had considered 3 years of jail time
  - Of course the judge could have said whatever the judge wanted to say
  - They could have said 20 years or a lifetime
  - Negligent homicide is not something where there’s a ceiling on how many years you can give somebody
- Marty has not heard any experts comment on what was expected

*At every stage in this entire case, people expected the thing to end*

- The DA would say, “*She’s been through the ringer now. We’re going to basically slap her on the wrist and do a settlement or something like that*.”
  - But it never happened
- And so as this grows, nurses around the country are finding they connect with her
  - There are a bunch of letters that came out just after this sentencing

**The sentence**

- The judge was merciful to give her 3 years of probation
- Peter notes, “*But she’s a convicted felon for the rest of her life*”
- Maybe not for the rest of her life because she got something called [judicial diversion](https://en.wikipedia.org/wiki/Diversion_program#In_the_United_States)
  - This means that they can expunge her criminal record if she serves the probationary period on good behavior

*The prosecution must have been upset with that sentence*

- Yes
- These letters of support started coming out of the public
  - A Vanderbilt physician wrote, “W*e cared (referring to the nurse that he worked with, RaDonda Vaught) for so many patients together. What was notable was the consistent high level of attention I saw her to provide to so many of our patients and their families when we worked together. She was very conscientious and aptly cared for many complex patients*.”
  - All these letters of support of people she worked with at Vanderbilt come out
- Lots of Vanderbilt physicians are pissed off at what’s happening
  - They’re not happy that their impeccable medical care is getting characterized nationally by the actions of their administration
- The DA’s office released a letter in response saying, “*I am sickened by those who rallied around her as a hero. I thought she was a horrible anomaly, but now I think there are hundreds of thousands of nurses who must also be dangerous practitioners since they defended the indefensible so readily.*”
  - That was Lisa Burgelco,  an assistant professor of nursing at Newman University
  - She wrote that letter in support of the DA’s prosecution, which they put in the public domain

**Marty’s takeaway:** *We have about 23 healthy years of significant improvements in the culture of safety, in the way we approach safety, undone with a single group of assistant young district attorneys that decide to go after one individual at the exclusion of doing anything about a hospital that, unlike the nurse, did not admit to anything initially and broke the law*.

## Concerns from the nursing profession over the RaDonda Vaught conviction [1:21:00]

**Have you spoken with nurses or doctors in the interval since the conviction explicitly about this, and do you have any anecdotal evidence that’s going to change the culture of reporting and open and honest dialogue around medical mistakes?**

- There’s a preliminary statistic that 1 in 5 nurses in the profession are quitting during the pandemic
  - Some of that is pandemic burnout
  - But a lot of nurses are leaving the profession and there’s this feeling that they don’t feel valued

> “*This has been a bit of a smack in their face*”‒ Marty Makary

- Hospitals around the country who are dealing with real critical nursing staffing shortages are trying to pay attention to the concerns that nurses have about this case
  - To make it clear that this is not their approach.
- Marty has talked to lawmakers at the state level in different states who are thinking about passing protections for nurses to try to encourage people in nursing
- If you look at the protection that police officers have, they have an immunity intrinsic to their jobs, and should that immunity be extended to people like RaDonda Vaught
  - *It’s delicate, but this is now a new conversation that has surfaced*
- RaDonda reached out for help to their friend [Zubin](https://zdoggmd.com), and he passed this information on to Marty
  - Marty gets so many requests from people benign sued or going to court asking for help that he honestly did not see this email
  - He felt horrible once he realized his missed this, after the case blew up
- Marty reached out to her and offered to be an expert witness or help in any way
- He found her to have an incredible spirit, a good attitude
- Marty feels bad for her
  - She was crying at the trial when she was found guilty

## How to advocate for a friend or family member in the hospital [1:23:15]

**Is it a fair assessment to say that the majority of medical errors take place inside of hospitals?**

- Yes
- Peter replies, “*It makes for a frightening experience when you’re going to a hospital, because usually if you’re going to a hospital, even if it’s electively, you’re going to have an elective surgery, or you’re going there non-electively (which is even more frightening), the medical side of it is bad enough in terms of what you’re worried about and what could happen. But I think this discussion we’ve had over the last whatever 90 minutes speaks to another threat that might even rival that threat. My personal view is it’s less than that, but we’ll never know that answer potentially*.”
  - They run the gamut from incorrect medicine administration to unnecessary procedures
  - There’s no end to what these mistakes look like

**What can a person do if they or their loved ones are going to be admitted to the hospital to reduce the odds of any of these medical errors?**

- Marty notes, things are much better, hospitals are safer now
  - There’s more awareness when you bring up these questions or issues
  - There’s attention to them
  - Every hospital has a p**atient relations department**
    - This is the department to contact if things just don’t seem right, if you feel that you’re not communicating effectively with your care team, if you feel care is not coordinated, if you have a concern, or if there was an error,
    - It’s standard in the hospitals now
    - They’ve got somebody on call 24.7
- It’s important to have an advocate with you anytime you get medical care
  - When you have a loved one in the hospital, it’s amazing how it seems that the care is just overall much better, holistic, comprehensive, and coordinated when there’s a family member or loved one there
  - It could be a friend, but they’re there taking notes, asking questions
  - They’re asking to talk to the doctor who’s in charge of the care at least once a day
- Sometimes your advocate can set an appointment to talk to the doctor
  - They can communicate this often through the nurse or the nursing assistant to say, “*Is there a time I can plan to be here where I can speak with the doctor caring for so-and-so?*”
- It’s important to ask about alternatives
- Marty notes, “*We’ve generally had this sort of burnout mode response to any questions in medicine as residents, where if they ask any question, you just tell them they could die if they don’t have something done and you don’t get into the details*.”
  - If a resident is told this person needs a CAT scan on rounds, they are supposed to see that it gets done
  - Residents may not have a good breadth of knowledge as a young trainee of the alternatives
- Some people do a good job presenting alternative options, others may not be able to do this well
- If you ask the right questions and ask about alternatives…
  - For example, suppose you are having a filter put in your large vein, the [vena cava](https://en.wikipedia.org/wiki/Venae_cavae)
  - Typically the doctor decides on rounds when this needs to be done
  - The intern may note even explain it
  - Sometimes patient transport shows up to take the patient for this procedure, and the patient’s not really in the loop
    - They’re getting medications, they don’t know what they’re getting

***The more they can be aware of what’s happening, ask about the reason for those and the alternatives, the better the care is going to be***

- Peter points out, “*That’s a hard ask though, Marty. Medicine really is a foreign language.*”
  - Patients are intimidated to ask
- Marty explains the current protocol is that “*Nurses are supposed to explain to the patient every medication that they give them*.”
  - So, let’s say it’s time for your twice a day [Lasix medication](https://en.wikipedia.org/wiki/Furosemide)
    - Lasix is a medication that’s given to move body fluid from the third spaces in your body into your urinary system
    - So, if you’ve got too much fluid in your body, it’ll cause you to urinate some of that fluid out
  - The nurses will actually explain to the patients, “*I’m injecting some Lasix medication. This is a medication to address the swelling in your body and it will cause you to urinate more*.”

*This is actually a big effort right now in patient safety*

- There was a protocol for a while where one of their doctors, actually [Peter Pronovost](https://www.uhhospitals.org/about-uh/leadership/uh-system-leadership/peter-pronovost), say on the closed circuit television in the patient rooms, “*Ask us questions. Ask about the medication that’s being given to you. You should know what it is and what it’s for, and you should ask your doctor or whoever walks in the room, nurse, if they’ve washed their hands*.”
- It became this sort of partnership where we want you to ask, “*Hey, have you washed your hands?*”
  - Before it was kind of like, “*How dare you ask me? Of course I washed my hands.*” Of course, we didn’t always do it
  - Marty explains, “***This is the sort of new dialogue that we are trying to promote to make the patient a participant in their care and not just a bystander. And when you do it, what I’ve noticed, the more educated they are or their surrogate, the better the care is.***”
- Marty sees improvements, a change in the culture, an awareness and this effort to educate people

**⇒ You are in the middle of a very complicated system of care when you’re in the hospital; the more you can be aware of what’s happening, the safer the care**

## Changes needed for meaningful reduction in the death rate from medical errors [1:29:30]

**What are the biggest 3 things that need to be changed in the next 10 years for us to cut the medical error death rate down by 50%?**

*#1 – Payment reform*

- There’s not a great financial incentive for better safety
- We know there’s an altruistic moral reward and we know people generally like that, but a lot of times the CFOs are making the decisions
  - They want to see an [ROI (return on investment)](https://en.wikipedia.org/wiki/Return_on_investment)
- For example, if you bring in something to a hospital that, say, is going to reduce the number of misses in radiology
  - Let’s say there’s a software program that will take a second look at chest x-rays and chest CAT scans to look for lesions that the radiologist missed, and if it’s identified with the AI that can pick up lesions now pretty sensitively, but that lesion is not noted in the report by the radiologist (this is all digital, all computers are doing this)
    - This is a real product begin used at [Sutter Health](https://en.wikipedia.org/wiki/Sutter_Health)
  - AI is used to look at the scans as a second check
  - The same thing has been done with EKGs
  - Then they look for discrepancies in the reports
  - Next, that list of that patient having an unreconciled difference goes to the radiologist and they’re to review that list of non-reconciled differences between the AI and the radiologist
- Marty points out, “*What is the ROI to the hospital on adopting that technology? Zero. Negative. It’s a cost that’s not rewarded*.”
  - What we’ve done is we’ve relied on the values of executives to adopt technologies that they believe
  - And many times the doctors are the champions for this; the head of radiology says, “*I know this is not going to be great for our bottom line, but we’re doing well financially. Let’s adopt it*.”

> “*Many hospitals had their most profitable year last year*”‒ Marty Makary

- Some hospitals have so much cash reserves that they have investment arms.
  - Some medical centers are basically hedge funds with hospitals on the side at this point
- So, we rely on individuals and innovators to say, “*There’s no formal ROI that you’re going to see on the bottom line immediately, but we believe this is better care*.”
- Marty is seeing that adoption very sporadically and very haphazardly

**Marty’s takeaway:** ***There’s a lot of the patient safety innovations that make sense, but they have a tough time getting in… we’ve got to change the payment model***

- Peter points out that CMS was already saying, “We’re not going to reimburse for cases where there are errors.” That’s a stick more than it is a carrot, but *has that changed the culture?*
- Yes, but it’s only not reimbursing 3 specific types of errors, of what we call **never events**
  - 1 – Death of an ultra-low-risk person in the operating room at the time of surgery
  - 2 – A retained sponge or a retained foreign object
  - 3 – There’s an airway never event, which nobody should die of a lack of an airway exposure
  - These are very narrow/ rare events

**Progress has been made in attention to safety**

- Yes, CMS not paying for it has put a ton of attention on these issues
- Further, the reporting to the state on these issues has created a ton of scrutiny around these events
  - The counting process we do now coming out of surgery is intense.
  - It started off when they were residents like, “Y*eah, I think we got all the sponges and instruments out. Okay*.”
  - Then it went to the nurse, “*Do we have all the sponges and instruments out on the set?… Yeah, we’ve got them all*.”
  - Then it was, count them to make sure it’s the same number we started with
  - Then it was a formal count that was recorded
  - Now it’s an RFID or barcode scan system
    - We’ve matured a lot with that  because of this intense scrutiny around this particular type of mistake
- Now, if you overprescribe opioids after an uncomplicated vaginal delivery
  - OB doctors will tell you, “You should not be giving opioids, uncomplicated vaginal delivery.”
  - And yet women will go home with a bottle
  - Or after other minor procedures
- And so if you prescribe 30 opioids when we know best practices would never allow more than 10 opioid pills in a narcotic naive adult, *that’s an error*

⇒ *But are we even measuring it?*

- Hopkins just began the measurement and data feedback process for that type of error

## Blind spots in our current national funding mechanism and the need for more research into patient safety [1:34:30]

**The COVID pandemic response is an example of bias in research funding that hinders progress**

- During COVID he saw this intense bias towards laboratory research
  - That the only real serious type of research is laboratory, research done at places like the NIH, and that’s how we solve disease
- That all this other stuff, the stuff he’s interested in, is not really science
  - Systems change, standardizing processes, hospital culture, speaking up
- What you have is all of our health agencies entirely focused on laboratory medicine
- And what happens is you get young investigators [doctors], faculty, they can’t get grants to do research on this stuff
  - They’re not rewarded they don’t get promoted
  - They’re told by their department directors they got to have a lab or do something lab-related
- There’s one small government agency that funds this kind of stuff called the [Agency for Healthcare Research and Quality](https://www.ahrq.gov/)
  - It’s massively underfunded
  - There’s a fair amount of cronyism in how they fund their grants as well
- But during COVID we wanted to know the behavioral aspects
  - How does it spread?
  - When are you most contagious?
  - Do masks work?
  - *None of those questions were answered with good evidence*
- Instead, we had massive efforts going on in the lab
  - This is appropriate, Marty’s not downplaying that; we need that
- But we need both
- The NIH or CDC never did a study to ask, “*Is it airborne or surface transmission?*”
- Instead, they let that debate linger in the public domain for months (from January until April), letting people argue on TV
  - *They could have done that study in 24 hours*
- Other examples are‒  natural immunity, cloth masks, N95 masks, the reduction in transmission
  - All those studies could have been done immediately
- They didn’t because they were entirely focused on laboratory pathways and medications and pharmaceutical solutions
  - We need those

> “*But you saw it come at the complete exclusion of basic clinical research*”‒ Marty Makary

- Marty saw the the same thing with patient safety
- That bias towards laboratory research is hurting us badly

*Where’s the NIH research for food as medicine in the inflammatory state, and environmental exposures that cause cancer, and school lunch programs?*

- Instead, we’re talking about bariatric surgery and throwing insulin at people and second line antihypertensives

*Where’s the science of sleep medicine at the NIH?*

- These are the giant blind spots in our current national funding mechanism
- And patient safety is one of those blind spot areas

*Peter notes, even if you consider medical errors to be the 8th leading cause of death (and not 4th), presumably this would justify a more systems-based approach to problem solving*

- There’s a well understood playbook for how you go from idea to grant, funding cycle results, publications, et cetera, within the sphere of the type of research that they’re currently funding [laboratory research]
  - Both translational and basic and clinical for that matter
- But **basic clinical research** is different
  - *It’s a very different type of research and it’s not really the type of thing that they’ve mastered*

**Peter’s takeaway:*****He’s not optimistic that either the system is going to get that much better or that an individual can do much to protect themselves***

- Peter feels lucky that if they were in the hospital with a friend or family member, they would know what questions to ask and can probably reduce the damage a little bit
- He thinks back to this case at Vanderbilt
  - Even if this was his grandmother, it’s unlikely he would have been in the scanner with her
  - He would have been waiting back in the ICU
  - There’s nothing he could have done to prevent that mistake

## Parting thoughts—where do we go from here? [1:38:30]

**Where do we go from here? Where is the innovation?**

- Peter asks, “*What would make it impossible to give vecuronium to a person who is not intubated?*”
- The movement is formalized into a group called the [Institute for Healthcare Improvement](https://en.wikipedia.org/wiki/Patient_safety_organization#Institute_for_Healthcare_Improvement)
  - This was started by [Don Berwick](https://en.wikipedia.org/wiki/Donald_Berwick), a hero of patient safety
    - He has spoken at every major medical center probably in the United States, talking about the culture of safety and all these issues
- Marty notes, “We talk about safety on rounds and now almost every hospital has a chief quality officer. And their job is to oversee these root cause analyses. That’s routine now for any sentinel event, if the hospital is honest, which most are. Our hospital doesn’t let things slip because they settled with a family who had a 75-year-old parent die in a scanner. It doesn’t matter where or when, if there’s a catastrophic or a sentinel event, it’s going to get a root cause analysis at Johns Hopkins. I think that’s the case at most hospitals.”

***But to have a C-suite level executive focused only on quality and safety within an institution… that’s progress***

- Safety is now part of the conversation
- Marty is optimistic about the current direction
- Many hospitals are also sitting on tens of millions of dollars of surplus now every year
  - Not half the rural hospitals and not all hospitals

***W*****hat do you do with that money?**

- When you’re a nonprofit, you’ve got to reinvest it into something
- He’s seeing more willingness now to invest in safer technology
- Patients love it when they come into a hospital and they hear, “Hey, we do this, this and this for safety.”

**Marty’s observation:** ***A fundamental problem in healthcare is that we have non-competitive markets and the hospitals are competing basically on billboards and NFL advertisements and not on quality and safety***

**Progress is being made toward improving accountability and safety**

- Now with more public reporting that is starting to change
- When Marty wrote [*Unaccountable*](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198367/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) 10 years ago, he called for public reporting of sentinel events and other infection rates and complication rates and readmission rates
  - It’s since turned into the TV show [*The Resident*](https://en.wikipedia.org/wiki/The_Resident_(TV_series))
- Much of the medical establishment replied, “No way. This absolutely will never and should never happen.”
  - Now, we accept it
  - Nobody challenges or questions it
  - We have public reporting of those adverse events

**And when readmission rates became publicly reported, guess what happened to them?**

- They plummeted across the board because hospitals went to their doctors and nurses and said, “What do you need to ensure that your patients don’t bounce back after you discharge them?”
- And we started having discharge coordinators and clear instructions sheets written at a sixth grade English level

**The improvements are mixed**

- In some areas we haven’t made much improvement
- In other areas we see an army of people now dedicated to quality and safety that we never saw before

**Peter’s takeaway:** ***I guess we’ll be cautiously optimistic here. But I really am… deeply troubled by what took place in Tennessee at all levels. At the level of the nursing board, at the level of the hospital, and certainly at the level of the DA. I think it’s all a bad precedent. If your objective function is to improve outcomes, none of this was in service of that.*** 10.5

- Marty agrees, it was a tragedy
- The silver lining is the groundswell of opposition to what happened to her
  - This is encouraging
  - He hopes people keep speaking up about this case

§

## Selected Links / Related Material

**1999 Institute of Medicine report on deaths from medical errors**: [To Err is Human: Building a safer Health System](https://nap.nationalacademies.org/resource/9728/To-Err-is-Human-1999--report-brief.pdf) | *Institute of Medicine* (1999) | [11:15, 34:15]

**Protocol for reducing central line infections, developed by Peter Pronovost and ICU nurses**: [Eliminating catheter-related bloodstream infections in the intensive care unit](https://pubmed.ncbi.nlm.nih.gov/15483409/) | *Critical Care Medicine* (SM Berenholtz *et al.* 2004) | [20:00]

**Peter Pronovost’s protocol reduces central line infections**: [An Intervention to Decrease Catheter-Related Bloodstream Infections in the ICU](https://www.nejm.org/doi/full/10.1056/nejmoa061115) | *The New England Journal of Medicine* (P Pronovost *et al.* 2006) | [25:00]

**Marty’s surgical safety checklist**: [Patient Safety in Surgery](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1570547/) | *Annuals of Surgery* (MA Makary *et al.* 2006) | [26:00]

**Atul Gawande’s book about checklists**: [The Checklist Manifesto: How to Get Things Right](https://www.amazon.com/Checklist-Manifesto-How-Things-Right/dp/0805091742/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1653480169&sr=8-1) by Atul Gawande (2009) | [26:30]

**Atul Gawande study of the effectiveness of a surgical safety checklist**: [A Surgical Safety Checklist to Reduce Morbidity and Mortality in a Global Population](https://www.nejm.org/doi/full/10.1056/NEJMsa0810119) | *The New England Journal of Medicine* (AB Haynes *et al.* 2009) | [28:00]

**Mayo Clinic survey of doctors find 10.5% have made a major mistake in the last 3 months**: [Physician Burnout, Well-being, and Work Unit Safety Grades in Relationship to Reported Medical Errors](https://www.mayoclinicproceedings.org/article/S0025-6196(18)30372-0/fulltext#%20) | *Mayo Clinic Proceedings* (DS Tawfik *et al.* 2018) | [23:40, 1:09:50]

**2015 Mass General Hospital study documents medical errors in surgeries**: [Medication errors occur in half of surgeries, MGH study finds](https://www.fiercehealthcare.com/healthcare/medication-errors-occur-half-surgeries-mgh-study-finds) | by Aine Cryts, Fierce Healthcare (October 26, 2015) | [34:00]

**Marty’s 2016 report on medical errors**: [Medical error—the third leading cause of death in the US](https://www.bmj.com/content/353/bmj.i2139.full) | *BMJ* (MA Makary and M Daniel 2016) | [34:30]

**John’s study of deaths due to medical errors**: [A New, Evidence-based Estimate of Patient Harms Associated with Hospital Care](https://journals.lww.com/journalpatientsafety/Fulltext/2013/09000/A_New,_Evidence_based_Estimate_of_Patient_Harms.2.aspx) | *Journal of Patient Safety* (JT James 2013) | [35:45]

**Lorena’s book about her botched adrenal gland surgery**: [On the Way to Casa Lotus: A Memoir of Family, Art, Injury and Forgiveness](https://www.amazon.com/Way-Casa-Lotus-Memoir-Forgiveness/dp/1736390503/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1653491729&sr=8-1) by Lorena Junco Margain (2021) | [45:30]

**Marty’s book about patient safety**: [Unaccountable: What Hospitals Won’t Tell You and How Transparency Can Revolutionize Health Care](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198367/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Marty Makary (2012) | [48:00, 1:41:00]

**Article in the** ***Tennessean*** **about the Vanderbilt case**: [The RaDonda Vaught trial has ended. This timeline will help with the confusing case](https://www.tennessean.com/story/news/health/2020/03/03/vanderbilt-nurse-radonda-vaught-arrested-reckless-homicide-vecuronium-error/4826562002/) | by Brett Kelman, *Tennessean* (March 2, 2020) | [58:15]

**Other news articles about the Vanderbilt case**:

- [RaDonda Vaught made at least 10 mistakes in fatal Vanderbilt medication error, prosecutors say](https://www.tennessean.com/story/news/health/2019/03/27/radonda-vaught-vanderbilt-nurse-homicide-trial-vecuronium-versed/3216750002/) | by Brett Kelman and Adam Tamburin, *Tennessean* (March 27, 2019)
- [RaDonda Vaught: Key players in the case against former Nashville nurse](https://www.tennessean.com/story/news/crime/2022/03/30/radonda-vaught-district-attorney-glenn-funk-nurse-vanderbilt-nashville-prosecutor/7219820001/) | by Kirsten Fiscus, *Tennessean* (March 30, 2022)

**TV show based on Marty’s book** ***Unaccountable***:

- [*The Resident* (TV series)](https://en.wikipedia.org/wiki/The_Resident_(TV_series)) | Wikipedia (May 21, 2022) | [1:41:00]
- [The Resident](https://www.fox.com/the-resident/) | Fox | [1:41:00]

**Marty’s recent book on healthcare reform**: [The Price We Pay: What Broke American Health Care–and How to Fix It](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Marty Makary (2019)

**Marty’s website**: [Marty Makary MD](https://www.martymd.com/)

§

## People Mentioned

- [Peter Pronovost](https://www.uhhospitals.org/about-uh/leadership/uh-system-leadership/peter-pronovost) (patient safety champion, critical care physician and researcher at University Hospitals) [3:30, 19:00, 24:30, 1:28:15]
- [Lucian Leape](https://www.hsph.harvard.edu/profile/lucian-l-leape/) (visiting scholar at the Harvard School of Public Health, expert in health policy and management) [12:45]
- [Atul Gawande](https://atulgawande.com/about/) (Surgeon and public health leader, former Professor at Harvard University) [26:15]
- [John T. James](https://en.wikipedia.org/wiki/John_T._James) (chief toxicologist at NASA and patient safety advocate) [35:45]
- [Donald (Don) Berwick](https://hcp.hms.harvard.edu/people/donald-berwick) (former President and CEO of the Institute for Healthcare Improvement) [36:00]
- [C. Wright Pinson](https://www.vumc.org/surgical-sciences/person/c-wright-pinson-md-mba) (Deputy Vice-Chancellor for Health Affairs at [Vanderbilt University Medical Center](https://www.ihpba.org/52_C-Wright-Pinson.html) and CEO) [1:08:30]
- [Zubin Dabani](https://zdoggmd.com) (UCSF/Stanford trained internal medicine physician and founder of Turntable Health) [1:09:45, 1:12:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/08/marty-makary-1x1.jpeg)

##### Marty Makary, M.D., M.P.H.

Dr. Marty Makary is a surgeon, public policy researcher, and professor at Johns Hopkins University. He writes for *The Washington Post* and *The Wall Street Journal* and is the author of two New York Times bestselling books, [*Unaccountable*](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198367/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) and [*The Price We Pay*](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)*.* Dr. Makary served in leadership at the World Health Organization Patient Safety Program and has been elected to the National Academy of Medicine.

Clinically, Dr. Makary is the chief of Islet Transplant Surgery at Johns Hopkins. He is the recipient of the Nobility in Science Award from the National Pancreas Foundation and has been a visiting professor at over 25 medical schools. He has published over 250 peer-reviewed scientific articles and has served on several editorial boards.

Dr. Makary is the recipient of the 2020 Business Book of the Year Award by the Association of Business Journalists for his most recent book, *The Price We Pay*. It has been described by Don Berwick as “A deep dive into the real issues driving up the price of health care” and by Steve Forbes as “A must-read for every American”.

Dr. Makary has been elected to the National Academy of Medicine and named one of America’s 20 most influential people in health care by Health Leaders magazine. His current research focuses on the underlying causes of disease, public policy, health care costs, and relationship-based medicine. Dr. Makary was the lead author on the *Surgical Checklist* and later served in leadership with Atul Gawande on the World Health Organization Surgery Checklist project. Makary has published more than 250 scientific articles, including articles on health care transparency, vulnerable populations, and guidelines for prescribing opioids. As a gastrointestinal surgeon, he is also an advocate for healthy food and lifestyle medicine. [[John Hopkins Medicine](https://www.hopkinsmedicine.org/profiles/details/martin-makary)]

Website: [Marty Makary MD](https://www.martymd.com/)

Twitter: [@MartyMakary](https://twitter.com/martymakary)

Facebook: [Dr. Marty Makary](https://www.facebook.com/people/Dr-Marty-Makary/100050604544241/)