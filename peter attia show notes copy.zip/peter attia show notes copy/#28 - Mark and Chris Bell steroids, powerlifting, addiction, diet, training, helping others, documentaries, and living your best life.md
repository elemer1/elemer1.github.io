# #28 – Mark and Chris Bell: steroids, powerlifting, addiction, diet, training, helping others, documentaries, and living your best life

**Source:** [https://peterattiamd.com/brothersbell/](https://peterattiamd.com/brothersbell/)

---

In this episode, Mark and Chris Bell discuss their love of powerlifting, their unbelievable personal records, and what prompted the making of their now iconic film, Bigger, Stronger, Faster. They also very openly discuss steroid use, their tragic family history with addiction, the many inspirations that lead to their multifaceted success, and their dedication to having a positive impact on others in fitness and life.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/brothersbell/the_Drive_public.png)

Play

#28 - Mark and Chris Bell: steroids, powerlifting, addiction, diet, training, helping others, documentaries, and living your best life

#28 - Mark and Chris Bell: steroids, powerlifting, addiction, diet, training, helping others, documentaries, and living your best life

1x15s30s

0:002:11:23

**We discuss:**

- The impact of Bigger, Stronger, Faster, how it got made, and how it challenged Peter’s set of beliefs regarding steroids [4:45];
- Chris’s personal story of addiction and how he’s using his experience to help others [17:30];
- Importance of sharing your struggle, and the danger of comparing yourself to others [28:00];
- Early life, their love of pro wrestling and what motivated Brothers Bell to be great? [33:45];
- How they got started lifting weights, powerlifting vs Olympic lifting, and personal records [43:30];
- Lifting weights: the importance of challenging yourself, how to avoid injury, monitoring progress, and staying motivated [1:02:30];
- Chris on how changing his diet changed his performance and life [1:09:15];
- Best resources for those wanting to get started lifting weights effectively and safely [1:14:00];
- Teaching kids strength training early in life, the negative impact of sitting and how we can minimize it [1:18:30];
- Benefits of bodybuilding, Mark’s prep for his first competition, and the role of the ketogenic diet [1:27:15];
- The steroid controversy: Mark’s use of them and Peter’s perspective [1:42:15];
- Testosterone: Peter’s approach to improving it in patients, and the impact of sleep, cortisol, and statins on production [1:51:00];
- Upcoming nutrition documentary [2:03:00];
- Parting advice from Mark [2:05:00];
- Kratom, a powerful plant with the potential to help opioid addiction and more [2:06:15];
- The many resources and ways to follow Mark and Chris [2:07:45]; and
- More.

§

## Show Notes

## The impact of Bigger, Stronger, Faster, how it got made, and how it challenged Peter’s set of beliefs regarding steroids [4:45]

The impact Mark and Chris’s movies have made

- Many people credit their films for helping them with addictions or simply improving their life
- They are frequently given unsolicited hugs by fans
- Peter surmises the impact of the films are at least partially due to the authenticity and vulnerability shown by the Bell family

What lead up to the making of [Bigger, Stronger, Faster](https://en.wikipedia.org/wiki/Bigger,_Stronger,_Faster*)

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-1.jpeg)

**Figure 1. Bigger, Stronger, Faster**. Image credit: [imdb.com](https://www.imdb.com/title/tt1151309/)

- Chris felt there was something magical going on inside Gold’s Gym Venice
- The ubiquity of steroid use
- Chris saw the documentary [Bowling for Columbine](https://en.wikipedia.org/wiki/Bowling_for_Columbine) and decided he wanted to make a documentary on steroid use modeled after Bowling for Columbine
- Once they started working on it, the editors and producers realized that the Bell brothers (Mark, Chris, and Mike) were the ones who needed to be filmed and they decided to focus on the Bell family
- Mark and Mike were both on steroids, but Chris wasn’t but he was conflicted about whether he should or not
- The producers realized that telling that story with honesty, about what’s actually going on, was the way to go

Peter is struck by the empathy shown by Chris in the film

- A young boy, who was taking steroids, passed away
- Chris was interviewing the father of the boy, who blamed steroids
- Even though Chris disagreed that his death was caused by steroid use, he didn’t take a “cross-examination” approach
- “I was just trying to figure out ways to not be mean-spirited to the guy but yet . . . make some points to him and hopefully like it’ll sink in with him. . . that’s sort of my approach is to like not really go in there with a mindset of ‘I’m going to destroy this person’ because . . . we are all human beings we’re all in this big soup together . . . we all have to function together so like to pick a side and stand there just doesn’t seem to make any sense”
- “So I think that that’s my philosophy. . . to try to keep the peace so that after the film we can still continue to have a relevant and smart intelligent conversation about the subject matter”

Peter credits Bigger, Stronger, Faster for getting him to revisit his set of beliefs regarding steroids

- Always assumed steroids must be terrible for you and dangerous
- He remembers the [Sports Illustrated cover with Lyle Alzado](https://vault-cdn.si.com/SI_ISSUE_IMAGES/Sports%20Illustrated/1991/07/19910708/Sports_Illustrated_711063_19910708-001-775-cover.jpg)
- After watching the documentary, Peter describes his realization as follows: “It was an opinion that had been passed down and passed down but I hadn’t actually submitted myself to the discomfort of thought”
- Peter also quotes JFK, “For the greatest enemy of truth is very often not the lie, deliberate, contrived, and dishonest but the myth, persistent, persuasive, and unrealistic. Too often we hold fast to the cliches of our forebears. We subject all facts a prefabricated set of interpretations. We enjoy the comfort of opinion without the discomfort of thought.”

## Chris’s personal story of addiction and how he’s using his experience to help others [17:30]

- Chris’s credits his dad for recognizing something and calling him out, “I don’t know what’s wrong with you but you’re a drug addict or an alcoholic or something. . . you’re not right”
- Caused Chris to break down in tears, “worst feeling you could possibly have is that you let your father down”

Mark’s perspective on Chris struggle

- Chris and Mark had an older brother (Mike) that they had already lost to substance abuse
- Mark comments that the battle with addiction is never over, compares it to strength training, you will never reach a spot where you think ‘this is perfect, where I want to be’
- He is amazed at where Chris is today, “like he restarted his like at 40 years old”

Mark tells the story of the turning point

- Got a frantic call from Chris’s girlfriend that Chris was passed out and wouldn’t wake up
- Convinced Chris to fly to Sacramento and be with the family
- Sent him to detox (zero contact for 3-4 days)
- Rehab for 60-70 days
- Best thing they did as a family is they had an intervention and Chris revealed, “I feel alone”
- They made the point to surround him with family, his parents playing a huge role
- Family support is what made (and is making) the difference

Helping others

“I never wanted to be a drug addict or an alcoholic but thank God for it, because I think that it’s helped me to really help other people,” says Chris

- Chris feels like he has an ability to inspire people to take initiative in their lives, to get involved with something and go for it
- He stresses the importance of surrounding yourself with a support group
- Chris’s goal is to simply help people lead a healthier lifestyle, physically and mentally
- Mark and Chris say their first prescription for everyone who is struggling is simply to get up and start moving, even if it’s just a 10-minute walk, just start

## Importance of sharing your struggle, and the danger of comparing yourself to others [28:00]

Sharing your struggle

- Not only is it helpful to you, but it can have an amazing impact on others because feeling *alone*, as Chris did, can lead people to dark places
- “Once you start to let down your barriers you can . . . communicate this vulnerability about your own struggle . . . it’s amazing what that does for other people because many many of us kind of go around thinking we’re the only ones struggling with problem X or problem Y,” says Peter
- Referring to the message spread by the late, [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace), Peter says, “every single one of us is only experiencing the world from our own vantage point, I only know what’s in our head, we only know what we see and it’s so easy to think you are alone”
- Peter suspects that their authenticity and **willingness to share their struggle** helps convey their good intentions (as opposed to many of the inauthentic figures in the fitness industry)

For more on the importance of sharing your struggle see a previous episode of The Drive with [psychiatrist Paul Conti](https://peterattiamd.com/paulconti/)

Stop comparing yourself to others

- It’s easy to judge someone else when you don’t know where they started
- Everyone has a different starting point which makes an enormous difference on where they currently stand
- Peter says, “don’t judge a man by where he stands. . . judge him by how far he’s traveled to get there”
- The bottom line is you should only look at your own progress, not other’s endpoints

## Early life, their love of pro wrestling and what motivated Brothers Bell to be great? [33:45]

- Peter is fascinated by what drove Brothers Bell to be extraordinary because their story is NOT what he would have expected, which is that some childhood trauma drove them to work hard which resulted in mostly positive things but sometimes goes off the rails (addiction), but it’s kind of the opposite
- Bell brothers say they had a tremendous childhood, very loving
- Mark says, “We had the ability to dream because our dad provided and mom provided that for us. That’s all we had to worry about as kids were to dream big. That’s it.”

The things that inspired their course in life

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-1.png)

**Figure 2. Hulk Hogan pins The Iron Sheik in 1984**. Image credit: [hulkhogan.com](https://hulkhogan.com/hulk-hogan-vs-iron-sheik-legendary-story/)

- Huge fans of pro wrestling (WWE)
  - The day that changed their life: [Hulk Hogan beat the Iron Sheik January 23, 1984](https://hulkhogan.com/hulk-hogan-vs-iron-sheik-legendary-story/), and from that point on all they could imagine for their future was being inside the wrestling ring
  - Mark, Chris, and Mike would never miss [WrestleMania](https://en.wikipedia.org/wiki/WrestleMania) and would always choose going to Madison Square Garden as the one “special thing” they got to do with their dad every year
- Inspired by their dad
  - Dad worked for IBM and gave his everything to the company for 20 years
  - Stuck in “corporate America”. . . job, family, job, family, repeat
  - Just before he reached a milestone that would have given him a large payoff, he was let go
  - But they were inspired because he picked himself up and became even more successful on his own as an accountant and real estate investor
  - They wanted to pave their own path after this experience

Peter interjects with an important observation about their father, “He still gave you guys everything. . .you never were without a hug, there was never a moment when you wanted to play with your dad and he wasn’t there. And so my guess is that would make it a lot more palatable when you get shit on by the man because can you imagine the guilt that would rest upon you if you’re doing all this stuff in service of your family right? You’re working this hard to provide for your family obviously but in the process, you’ve got to make these hard sacrifices to not spend time with your family and then, in the end, you get the shaft.”

## How they got started lifting weights, powerlifting vs Olympic lifting, and personal records [43:30]

They first witnessed the raw strength of their older brother [“Mad Dog”](https://en.wikipedia.org/wiki/Mike_Bell_(wrestler)) (Mike) who was squatting 400 lbs at age 16

How Chris got started:

- In 10th grade, Chris had bone spurs in his knees and needed surgery
- His chiropractor/strength coach said you need to learn to squat to help your knees (counterintuitive to Chris)
- Started with broomstick learning to squat properly
- Slowly moved up in weight and 6 months later squatting 315 lbs for 8 reps
- Ended up squatting over 500 lbs while still in high school
- Chris was squatting 675 by 19 years old

Mark points out their strength gains responded really well to heavy lifting but not a lot volume

- One heavy lift and leave
- Coaches thought they were lazy
- They looked up to [Mike Mentzer](https://en.wikipedia.org/wiki/Mike_Mentzer) who used this approach

How it started for Mark:

- When Mark was about 13 years old, their cousin (who was about 19) came over and challenged Mark to a “bench off”
- Up until that point, Mark had never really “maxed out” so was unsure how much he could lift
- They kept adding weight, and his cousin fails at 205 lbs, but Mark got 240-250 lbs at age 13!
- It’s in their genes: their mom benched 135 lbs never having benched in her life

Steroid use in high school

- Steroid use at their high school was pretty rampant
- Chris, who was against steroids back in the day, would wear a weightlifting belt with “Roids Suck” written across it
- This would piss people off since most of them were on steroids, yet Chris was still stronger than them
- Chris laughs about the irony that he made a movie later in life suggesting that maybe steroids are not all that bad for you

Olympic lifting vs. Powerlifting

- Olympic lifting:
  - 2 lifts, the snatch, and the clean and jerk
  - 3 attempts at each lift
  - the highest score of each lift is taken and summed together to get your total score
- Powerlifting:
  - Not an Olympic sport
  - Consists of 3 lifts, squat, bench, deadlift in that order
  - 3 attempts at each lift
  - Sum up best lift of each for a total score
- Powerlifting is hard because it’s hard to have leverage on each of those lifts
- Olympic lifting is more about being more mobile and athletic around the weight
- Mark and Chris practiced powerlifting more so than Olympic lifting

Personal records in powerlifting

Peter’s PRs:

- Peter used powerlifting for boxing in high school
- Weighing about 160 lbs
- Bench = 275 lbs
- Squat = 495 lbs
- Deadlift = 505 lbs

Mark’s PRs:

- Using powerlifting gear (which gives you an advantage):
  - Squat = 1080 lbs
  - Bench = 854 lbs
  - Deadlift = 766 lbs
- Raw (without any gear or knee wraps):
  - Squat = 700 lbs
  - Bench = 578 lbs
  - Deadlift = 715 lbs
- Mark says, “I was as strong as I could be. I don’t think I could have squeezed any more out of that. I pushed it as hard as I could. I got as big and as heavy as I could.”
- But wishes he would have put more emphasis on his sleep habits

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-2.jpeg)

**Figure 3. Mark Bell: 556 lb Raw Bench Press.** Image credit: [Jim McDonald (YouTube)](https://www.youtube.com/watch?v=efP6y0W-3wU)

Chris’s PRs:

- Squat = 675 lbs (assisted with gear)
- Bench = 585 lbs (in a “bench shirt), 500 (raw)

For context:

- Peter points out that they could likely lay under the back of a car and bench press it off the ground
- Mark says that typically, the strongest guys at “commercial gym” is maybe doing a 400 lb bench

## Lifting weights: the importance of challenging yourself, how to avoid injury, monitoring progress, and staying motivated [1:02:30]

- Peter’s life revolves around getting his lifting in
- Especially the main lifts like squat, bench, deadlift
- *Peter’s #1 rule: Don’t get hurt*

Mark agrees about the importance of safety, but if you are a young person first starting out, he would change the order:

- Rule #1: Challenge yourself
- Rule #2: Don’t get hurt
- Important note: As you age, you might want to reverse that order
- “If you’re not challenging yourself, then you’re missing out on the big piece of the puzzle because you’re never going to get the results you’re looking for.”
- “It sounds foolish but. . .we’ve all been hurt in the gym and we’ve all learned a lot from it”

Importance of warming up to avoid injury

- Peter says, “One of the most important realizations of my life was you can’t squat or deadlift until your [glute med](https://en.wikipedia.org/wiki/Gluteus_medius), your [TFL](https://en.wikipedia.org/wiki/Tensor_fasciae_latae_muscle#Structure), are working”
- Mark adds that at a minimum, you have to move around
- For upper body get the elbow and shoulder warm
- For lower body, walk forward, backward, side to side, do some hip hinging, etc.
- Mark and Chris sell a product called the hip circle which helps warm up the lower body

For more information about warming up your glutes and TFL, see [this video series](https://www.youtube.com/watch?v=7Z3uAFJgehw) by Peter showing his warm-up routine.

Challenging yourself to make progress

- The more you grow in fitness, the harder it becomes to continue to make progress
- But you have to find a way because to challenge yourself because, “Without progress…I don’t believe you can even have happiness,” says Mark

Mark on how to use small progress to keep yourself motivated

- There is always something to chase, says Mark
- Start with low, attainable goals
- Favorite advice to give people, “do you know a way to get a PR every single time you set foot in the gym?”
- Try something you’ve never done before and then just keep working that up until you plateau
- You can always try different rep ranges, “what’s your max set of 3 sets of 7 reps with one-minute rest on incline dumbbell press?”

## Chris on how changing his diet changed his performance and life [1:09:15]

“The number one thing for me that really changed my life altogether is my diet. . .what I put in my mouth affected what I did in the gym”

- When he was younger he would just eat like crazy and lift heavy
- Moved to California in 1993 and met up with [Mike O’Hearn](https://www.instagram.com/mikeohearn/?hl=en) and [Ron Fedkiw](https://en.wikipedia.org/wiki/Ronald_Fedkiw)
- Ron told Chris he was “too fat to be a good powerlifter”
- Chris had never been able to lose weight until he explored the ketogenic diet
- Ron told Chris to eat nothing but “red meat and water”
- Chris followed the advice for about 3 weeks and lost over 20 pounds, but was still able to win the powerlifting competition
- Peter asks, how much strength did you lose when you lost weight?
- “I got stronger”
- But for some reason he stopped doing it because he was “afraid” of the “weird” diet, he thought he needed carbohydrates
- He recently got back into the ketogenic/carnivore diet in the last couple of years
- “I feel like those years in-between we’re lost. I feel like I ruined them. I feel like, because I wasn’t optimizing my training along with my diet, that I kind of wasted those years.”

## Best resources for those wanting to get started lifting weights effectively and safely [1:14:00]

Peter likes to recommend [Mark Rippetoe](https://twitter.com/CoachRippetoe?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) for those needing instruction for strength training

- YouTube: [Starting Strength](https://www.youtube.com/channel/UC5FaqTBy0c1jlRUHKu4SuXQ)
- Book: [Starting Strength: Basic Barbell Training](https://www.amazon.com/Starting-Strength-Basic-Barbell-Training/dp/0982522738/ref=sr_1_1?ie=UTF8&qid=1541437708&sr=8-1&keywords=mark+rippetoe%27s+starting+strength)

Mark’s YouTube channel: [Mark Bell – Sling Shot](https://www.youtube.com/user/supertraining06)

- Over 3,000 videos
- Including instructional videos such as:
  - [Videos with Ed Coan](https://www.youtube.com/user/supertraining06/search?query=ed+coan), the “best squatter ever”
  - [Videos with Stan Efferding](https://www.youtube.com/user/supertraining06/search?query=stan+efferding), the “strongest raw powerlifter ever”

CrossFit

- Mark believes [CrossFit](https://www.crossfit.com/) is a great place to start
- Mark says “There has never in the history of the world has been a better fitness program than what Crossfit puts out. Nobody spends more time and more money on what they put together.”

Powerlifting

- Powerlifting will help improve your fitness in many different sports
- By powerlifting, you will not only learn valuable mechanics but you’ll also improve in your sport

## Teaching kids strength training early in life, the negative impact of sitting and how we can minimize it [1:18:30]

“I would love it if each of my kids at least spends some time powerlifting because whatever you go to do later in life you will have correctly learned the mechanics of the most important movements in the human body,” says Peter

- Jeff Martin (San Diego) has a program for kids called [The Brand X Method](https://thebrandxmethod.com/speaker/jeff-martin-2/)
- Mark did a seminar there and was blown away with how the kids were able to move
- Their form on everything was impeccable
- Adults are harder to teach, less flexible, tighter in the hips, mental blocks due to a bad experience with lifting in the past
- Peter says his 4-year-old boy (not in school yet so doesn’t sit) and his squat form is great, but his daughter who is now 10 years and used to have great form but now it is horrible

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-2.png)

**Figure 4. Ayrton Attia demonstrating a proper squat.** Image credit: [Peter Attia (Instagram)](https://www.instagram.com/p/Bp7Je3YgKYz/)

- Peter says that we are born with the ability to hip hinge and we lose it over time and would argue that “Sitting is the thing that cripples us”
- He believes we can minimize this negative impact on kids with 2 things:
  - Standing desks in school
  - Teaching kids the types of exercises to do
- Mark adds that we should be putting more of an emphasis on a “real” physical education in schools

## Benefits of bodybuilding, Mark’s prep for his first competition, and the role of the ketogenic diet [1:27:15]

- You can see rapid changes with bodybuilding
- Mark laments the state of the country and the bogus studies that he’s seen around training, “We’re in a country that’s so fat that there are studies that show that cardiovascular training is bad for you because it increases your estrogen and your cortisol so much you can’t release fat.”
- But for years, bodybuilders have done things in very specific ways and it works time and time again
- Mark believes the discipline you develop from sticking to a bodybuilding regimen is a powerful trait to have in your toolbox

[Jay Cutler](https://twitter.com/mrojaycutler?lang=en) is the example of discipline

- 4 time Mr. Olympia champion
- He eats seven times a day, all meals are prepared, the same food at the same time every single day
- He did his cardio at the same time
- He does weightlifting at the same time
- He would go tanning at the same time
- Hot tub get a massage at the same time
- Consistent sleep
- All those all these things were regimented out so that way he never skipped a beat and he could be the best

**Mark transitions from powerlifting to bodybuilding at age 41**

He was already in the process of adjusting his diet to lose fat and was convinced by [Hany Rambod](https://www.instagram.com/hanyrambod/?hl=en) (nutritionist for [Phil Heath](https://twitter.com/PHILHEATH?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)) on his [Power Project podcast](https://www.youtube.com/watch?v=1kj7k3Tj90c) to go ahead and sign up for his first bodybuilding competition

NOTE: Since this recording, Mark has already competed and [won his first ever bodybuilding competition](https://fitnessvolt.com/27615/mark-bell-bodybuilding/)

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-3.png)

**Figure 5. Mark wins bodybuilding competition**. Image credit: [Mark Bell (Instagram)](https://www.instagram.com/p/BnAembRAnQG/)

From Mark’s YouTube channel: [BEFORE AND AFTER BODYBUILDING TRANSFORMATION ft. Hany Rambod](https://www.youtube.com/watch?v=sAmU54of9iw)

Bodybuilding diet:

- Mark’s diet for his upcoming competition
  - 7 meals per day
  - 350 g protein (50 g protein per meal)
  - 150 g carbs
  - 65 g fat
- Mark points out that this might look like a lot but the average person eats 15 times per day (due to all the snacking)
- “You can actually handle eating a lot less than you’re currently eating is one thing to know and you can actually handle a lot more training. Now I’m not trying to suggest that you just get in this crazy mode of overtraining and develop body dysmorphia and all these things but I do think you could probably push yourself a lot further than you know…and when you go from not implementing bodybuilding stuff to implementing bodybuilding stuff it makes a huge difference.”
- How much protein to eat?
- Chris says when he increased his protein intake he saw major changes
- Chris’s interpretation of the science is that you need 1.7 grams of protein per kilogram of body weight to elicit muscle growth
- For bodybuilders, it’s important to get protein in at every meal (as opposed to all of it in one meal), because presumably amino acids have a relatively short residence and you’ve got to keep the exposure high to get the muscular hypertrophy

Mark’s starting and ending weight for the competition

- Started around 245 lbs
- Ending weight probably around 215 lbs
- Mark says after only losing about 10 lbs he could see a major difference when practicing posing ([Posing video](https://www.youtube.com/watch?v=-TTu-dhr_XY))
- “I actually think the lower that I weigh. . . the bigger that I’ll probably look”

Mark’s team and mentors

- [Hany Rambod](https://www.instagram.com/hanyrambod/?hl=en) – nutrition
- [Charles Glass](https://www.instagram.com/thecharlesglass/) – posing
- [Mike O’Hearn](https://www.instagram.com/mikeohearn/?hl=en) – training

Mark’s macros:

- 2,600 total calories
- Protein = 54%
- Carbs = 23%
- Fat = 23%

**Mark’s experience with the ketogenic diet and how it fits into bodybuilding**

Mark’s experience: *“The ketogenic diet has always worked really well for me because it’s allowed me to keep control over the amount of food that I eat. It’s one of the few things that has burned off my hunger. It’s one of the few things that have burned off my cravings. It’s the only thing that has ever done that before.”*

In bodybuilding:

- For the pro bodybuilder, the ketogenic diet likely doesn’t play much of a role
- However, the ketogenic diet could really help somebody like myself, “a former fat kid”, in that it will “help me to continue to tighten up and it will also give me some mental freedom”
- If you stick with that exact same regimen all the time it tends to become less effective
- So with a ketogenic diet, you could theoretically become more sensitive to carbohydrates by scripting in a ketogenic diet at certain points and changing up the style of exercise that you do for a while

*“I think one of the worst things you can ever do, whether it’s business or any aspect of your life. . . is get stuck in one thing because. . .you’re focused in on that one thing and you can’t see anything else”*—Mark Bell

![](https://peterattiamd.com/wp-content/uploads/2018/11/null-4.png)

**Figure 6. Mark’s total transformation (over 10 years) from powerlifter to bodybuilder**. Image credit: [Mark Bell (Instagram)](https://www.instagram.com/p/BnOqsiwg-yR/)

## The steroid controversy: Mark’s use of them and Peter’s perspective [1:42:15]

What do steroids actually do for you?

- Mark, who is currently using steroids, says there’s a lot of confusion around this:
- “I think people think that steroids automatically make you strong [but] what they do in most cases is they allow people to gain more weight. Now there’s some cases where people don’t gain a whole lot of weight and they do gain strength. But if you don’t continue to gain weight at some point that strength will only level up so much. So when you introduce steroids, steroids don’t multiply on top of themselves. They only work to a certain level. So you’re on level 1 with your lifting and you progress and your genetics allow you to get to level 4. You take steroids and maybe over a period time it’s like level 6 but you’re still not going to be able to get to level 8, 9 or 10 like guys like Jay Cutler”
- Peter points out that steroids alone do not produce the type of results you see in professional bodybuilders, “[I could inject] the world’s supply of anabolic steroids into me [and I] couldn’t look one-tenth of what [Phil Heath] looks like.”

Steroids in bodybuilding:

- Still very much a part of the sport
- Even the different levels, such as “Classic Physique”, is not drug-free
- Chris points out that it does kind of “cloud the sport” but this is mainly due to the misconception that the drugs are producing the majority of the results

Peter’s perspective on anabolic steroids:

- “Once I really spent like five years learning everything there was to learn about anabolic steroids I came to the conclusion that while I can’t speak to what happens in bodybuilding because I think that takes it to a different level, but certainly within the levels of how they’re used in cycling or you know more physiologic levels of use, I can’t see any evidence of harm.”
- Chris points out a scenario where steroids may have caused an injury: he tore his tricep and he thinks he was lifting too heavy because while his muscles were capable, his tendons weren’t capable of handling the load
- But from the perspective of how it affects your liver, kidney and cardiometabolic health, Peter and Chris agree that there’s little evidence of harm
- The problem is when people abuse them and don’t understand how to use them properly or within physiologic levels

## Testosterone: Peter’s approach to improving it in patients, and the impact of sleep, cortisol, and statins on production [1:51:00]

Peter says the purpose of increasing testosterone (endogenously or exogenously) is to:

- Resolve insulin resistance
- Preserve muscle mass

Peter’s approach to diagnosing and improving low testosterone in patients *without* injecting exogenous testosterone

- Starts with the final thing he cares about: free testosterone
- To be diagnosed with low testosterone, Peter says you have to 2 things:

1. Free testosterone that is one or two standard deviations below the mean, and

2. Have symptoms, such as trouble maintaining muscle mass, insulin resistant, low libido

- If they meet both criteria, the next question is, “is free testosterone low because testosterone is low, or because [sex hormone-binding globulin](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) is high? Because free testosterone, which is what matters, is proportional to testosterone and inversely proportional to sex hormone-binding globulin”

If [sex hormone-binding globulin](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) is high, there are 4 possible reasons:

1. Insulin
2. Thyroid hormone
3. Estrogen
4. Genetics

If testosterone is low, you try to figure out why:

- Are they siphoning too much testosterone into either [dihydrotestosterone](https://en.wikipedia.org/wiki/Dihydrotestosterone) (DHT) or [Estradiol](https://en.wikipedia.org/wiki/Estradiol)? If yes, you can correct those with [5-alpha-reductase inhibitors](https://en.wikipedia.org/wiki/5%CE%B1-Reductase_inhibitor) or [aromatase inhibitors](https://en.wikipedia.org/wiki/Aromatase_inhibitor)
- Or are they simply not producing enough? If yes, which of these is the reason why?
- Not enough [Dehydroepiandrosterone](https://en.wikipedia.org/wiki/Dehydroepiandrosterone) (DHEA)
- Don’t have the pituitary signal that your [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) or [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) is too low => There are things you can give someone that stimulates LH or FSH production

“There are actually nine steps in understanding someone’s testosterone and free testosterone level and we can actually impact every single one of those steps pharmacologically”

“But now you’re seeing this stuff published in the medical literature that says, ‘Hey there are really reasonable safe ways to increase a person’s testosterone without even giving them testosterone.’”

**Sleep deprivation**

Peter gives an example of a common patient:

- Low free testosterone
- Estradiol not too high
- Sex hormone-binding globulin not too high
- DHT is not too high
- DHEA is not too low
- He’s not making enough testosterone, but his FSH and LH are also low
- So what does this mean? It means that this guy’s brain isn’t making the signal to tell his body to make more testosterone despite the fact that his testosterone is low so that tells you where the problem is the problem is
- The number one diagnosis for the lack of brain signal is **sleep deprivation**

**Hypercortisolemia (high cortisol)**

- So if you have too much cortisol you start to “steal” precursors of testosterone to make more cortisol
- Perhaps the more sinister issue is these high levels of cortisol impair you from entering what’s called Delta Wave sleep which is where you make the FSH and LH to make the testosterone
- You only make this stuff when you’re sleeping

**Statins**

In theory, you could make the argument that when you take a statin it is inhibiting cholesterol synthesis, and given that you need cholesterol to make sex hormones, that should be depleting them

- But we don’t actually see that in the data
- The body will prioritize its use of cholesterol for two things above all else: 1) forming cellular membranes and 2) hormone production, particularly [glucocorticoids](https://en.wikipedia.org/wiki/Glucocorticoid) and sex hormones
- “At the levels that most people are taking [statins] the evidence would not actually suggest that we’re inhibiting endogenous testosterone production”

For more on statins, see [this episode of The Drive with Dr. Ron Krauss](https://peterattiamd.com/ronkrauss/)

*“That’s the takeaway to me, a statin, a carbohydrate, or whatever, it’s a tool. And the key to me if you want to be a great carpenter in life. . .is to have the most tools, know how to use each tool, and know when to use each tool.”*—Peter Attia

## Upcoming nutrition documentary [2:03:00]

- What is it about and when is it going to be ready?
- “I don’t know either answer at all. I have no idea. So every film that I do is a journey. I never know when it’s going to end.”
- The documentary will be loosely based on the world of nutrition and will likely include Mark’s journey into bodybuilding at age 41
- In general, they are planning for the film to be out “next year”

## Parting advice from Mark [2:05:00]

“What I want to encourage everybody to do is really simple. . .just try to start walking. You know almost all of us are lucky enough to have the ability to put one foot in front of the other. Try to go for a 10-minute walk every day. . . do it after lunch, do it after dinner, preferably it’d be great if you can do it more than once a day. But it’s just a great place to start. A great way to clear your mind, there’s a lot of shit going on nowadays. If you have an hour and a half or whatever it might be to be on Instagram all day. You certainly can carve out 10 minutes for yourself every day to go on a walk. Really, really simple easy thing to do.”

## Kratom, a powerful plant with the potential to help opioid addiction and more [2:06:15]

A Leaf of Faith

- Chris made a film called [A Leaf of Faith](https://www.netflix.com/title/81009815) that explores the [kratom plant](https://en.wikipedia.org/wiki/Mitragyna_speciosa) and its purported benefits including getting people off opioids and relieving pain
- Find it on [iTunes](https://itunes.apple.com/us/movie/a-leaf-of-faith/id1367790093), [Google Play](https://play.google.com/store/movies/details/A_Leaf_of_Faith?id=i6Fa9bEu9_4&hl=en_US), [YouTube](https://www.youtube.com/watch?v=i6Fa9bEu9_4), [Amazon](https://www.amazon.com/Leaf-Faith-Joe-Rogan/dp/B07D9WGBZX), and [Netflix](https://www.netflix.com/title/81009815)

Mind Bullet

- Mark and Chris developed a product using kratom called [Mind Bullet](https://www.mindbullet.com/)
- They use it as a pain reliever, pre-workout, and Mark claims it can even give you some euphoria
- Find it at [mindbullet.com](https://www.mindbullet.com/)

## The many resources and ways to follow Mark and Chris [2:07:45]

Chris:

- Instagram: [@bigstrongfast](https://www.instagram.com/bigstrongfast/)
- Twitter: [@bigstrongfast](https://twitter.com/bigstrongfast?lang=en)

Mark’s YouTube channel

- [Mark Bell – Sling Shot](https://www.youtube.com/user/supertraining06)
- Mark says they spend nearly $250,000 per year on his YouTube channel just to get information out there to arm people with information they need

Mark:

- Instagram: [@marksmellybell](https://www.instagram.com/marksmellybell/?hl=en)
- Twitter: [@marksmellybell](https://twitter.com/MarkSmellyBell?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)
- Website: [markbellslingshot.com](https://markbellslingshot.com/) (Find his products including the [Sling Shot](https://markbellslingshot.com/collections/top-sellers/products/original-sling-shot) and the [Hip Circle](https://markbellslingshot.com/collections/top-sellers/products/hip-circle))
- Podcast: [Mark Bell’s Power Project](https://www.youtube.com/channel/UCXEj4RFUC44sHoBLvi4G1XA/videos)
- Podcast (ended): [Mark Bell’s PowerCast](https://thepowercast.libsyn.com/)

Super Training Gym

- Mark’s gym in Sacramento that is free (if you’re willing to work hard)
- Instagram: [@supertraininggym](https://www.instagram.com/thesupertraininggym/?hl=en)
- Facebook: [Super Training Gym](https://www.facebook.com/SuperTrainingGym/)

§

§

## Selected Links / Related Material

**Chris and Mark’s documentary**: [Bigger, Stronger, Faster\*](https://en.wikipedia.org/wiki/Bigger,_Stronger,_Faster*) | (wikipedia.org) [1:15, 6:00]

**Chris and Mark’s follow up film to Bigger, Stronger, Faster\***: [Prescription Thugs](https://www.imdb.com/title/tt4505666/) | (imdb.com) [1:30, 6:00, 1:59:15]

**Mark Bell’s YouTube channel**: [Mark Bell – Sling Shot](https://www.youtube.com/user/supertraining06) | (youtube.com) [4:15, 1:14:00]

**Oscar-winning documentary that Brothers Bell used as a template for Bigger, Stronger, Faster\***: [Bowling for Columbine](https://en.wikipedia.org/wiki/Bowling_for_Columbine) | ([wikipedia.org](https://www.wikipedia.org/)) [7:00]

**Story that shaped Peter’s original belief that steroids were all bad**: ‘[I’M SICK AND I’M SCARED’](https://www.si.com/vault/1991/07/08/124507/im-sick-and-im-scared-the-author-a-former-nfl-star-has-a-dread-disease-that-he-blames-on-his-use-of-performance-enhancing-drugs) | Lyle Alzado (si.com) [13:45]

**JFK’s Yale commencement speech in 1962 that contains a favorite quote of Peter’s**: [JFK’S SPEECH AT YALE UNIVERSITY (JUNE 11, 1962)](https://www.youtube.com/watch?v=PznXIiGe9rI) | David Von Pein’s JFK Channel ([youtube.com](https://www.youtube.com/)) [14:15]

**The day Hulk Hogan beat Iron Sheik changed Chris’s life**: [Sheik HULK HOGAN® VS IRON SHEIK: THE LEGENDARY STORY](https://hulkhogan.com/hulk-hogan-vs-iron-sheik-legendary-story/) | ([hulkhogan.com](https://hulkhogan.com/)) [34:45]

**First ever WrestleMania in 1985 with Hulk Hogan and Mr. T**: [WrestleMania I](https://en.wikipedia.org/wiki/WrestleMania_I) | (wikipedia.org) [35:45]

**Chris compared his grandparent’s house (on mom’s side) to this movie**: [The Fighter](https://en.wikipedia.org/wiki/The_Fighter) | (wikipedia.org) [42:00]

**Mark’s gym in Sacramento**: [@thesupertraininggym](https://www.instagram.com/thesupertraininggym/?hl=en) | (instagram.com) [59:00, 2:09:00]

**Mark’s product for dynamic warm-ups**: [The Hip Circle](https://markbellslingshot.com/collections/top-sellers/products/hip-circle) | ([markbellslingshot.com](https://markbellslingshot.com/)) [1:03:00]

**Peter recommends Mark Rippetoe’s YouTube channel for those learning to lift weights properly**: [Starting Strength](https://www.youtube.com/channel/UC5FaqTBy0c1jlRUHKu4SuXQ) | (youtube.com) [1:14:00]

**Peter also recommends Mark Rippetoe’s book for those learning to lift weights properly**: [Starting Strength: Basic Barbell Training](https://www.amazon.com/Starting-Strength-Basic-Barbell-Training/dp/0982522738/ref=sr_1_1?ie=UTF8&qid=1541437708&sr=8-1&keywords=mark+rippetoe%27s+starting+strength) by Mark Rippetoe | (amazon.com) [1:14:00]

**Docudrama about pro bodybuilding**: [Pumping Iron](https://en.wikipedia.org/wiki/Pumping_Iron) | (wikipedia.org) [1:18:30]

**Jeff Martin (San Diego) has a program for kids teaching weightlifting**: [The Brand X Method](https://thebrandxmethod.com) | ([thebrandxmethod.com](https://thebrandxmethod.com/)) [1:20:15]

**Mark’s company**: [Mark Bell Sling Shot](https://markbellslingshot.com/) | (markbellslingshot.com) [1:20:30, 2:06:00]

**Story about Mark’s first bodybuilding show**: [Mark Bell Wins His First Ever Bodybuilding Show](https://fitnessvolt.com//fitnessvolt.com/27615/mark-bell-bodybuilding/#vtctAqqDvu4t) | Aiman Zubair (fitnessvolt.com) [1:27:30]

**Peter on Joe Rogan’s podcast**: [Joe Rogan Experience #1108 – Peter Attia](https://www.youtube.com/watch?v=gP1NA5f4LfE&t=194s) | PowerfulJRE (youtube.com) [1:32:00]

**Chris and Mark on Joe Rogan’s podcast**: [Joe Rogan Experience #1101 – Chris & Mark Bell](https://www.youtube.com/watch?v=0JWjwJS_XZk) | PowerfulJRE (youtube.com) [1:32:00]

**Mark’s podcast episode with Hany Rambod when Mark is convinced to try bodybuilding**: [Mark Bell’s Power Project EP. 67 Live with Hany Rambod](https://www.youtube.com/watch?v=1kj7k3Tj90c) | Mark Bell’s Power Project (youtube.com) [1:35:00]

**Ronnie Coleman’s documentary**: [Ronnie Coleman: The King](https://www.imdb.com/title/tt7217214/) | (imdb.com) [1:35:30]

**Guinness record goes to Arnold Schwarzenegger for best physique**: [Arnold Schwarzenegger had Guinness record](https://www.getbig.com/boards/index.php?topic=512750.0) | (getbig.com) [1:46:15]

**Dorian Yates blood and guts workout**: [Dorian Yates’ Blood & Guts Training Program](https://www.youtube.com/watch?v=afqHMID-VEQ) | Bodybuilding.com (youtube.com) [1:46:30]

**Episode of The Drive about statins**: [Ron Krauss, M.D.: a deep dive into heart disease (EP.03)](https://peterattiamd.com/ronkrauss/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [1:59:30]

**Chris’s Instagram page**: [@bigstrongfast](https://www.instagram.com/bigstrongfast/?hl=en) [2:05:00]

**Chris’s film about the Kratom plant**: [A Leaf of Faith](https://www.netflix.com/title/81009815) | (netflix.com) [2:06:15]

**Kratom supplement created by Bell brothers**: [Mind Bullet](https://www.mindbullet.com/) | (mindbullet.com) [2:07:30]

§

§

## People Mentioned

- [Mike “Mad Dog” Bell](https://en.wikipedia.org/wiki/Mike_Bell_(wrestler)) (older brother who passed away, pro wrestler nickname “Mad Dog”) [3:20, 44:15,
- [Michael Moore](https://twitter.com/MMFlint?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (directed Bowling for Columbine) [7:00]
- [Brian Singbiel](https://www.imdb.com/name/nm1466103/) (editor of Bigger Stronger Faster that they brought over from Bowling for Columbine) [7:40]
- [Alex Buono](https://twitter.com/alexbuono?lang=en) (producer of Bigger Stronger Faster) [8:45]
- [Lyle Alzado](https://en.wikipedia.org/wiki/Lyle_Alzado) (NFL star who blamed steroids for his fatal illness) [13:45]
- [John F. Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy) (Yale commencement in 1962) [14:15]
- [Joe Rogan](https://twitter.com/joerogan?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [25:15, 1:32:00, 1:47:30]
- [Donald Trump Jr](https://twitter.com/DonaldJTrumpJr?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (gets squatting advice from Mark) [25:15]
- [Greg “GB” Young](https://www.imdb.com/name/nm1226661/?ref_=ttfc_fc_dr3) (Chris’s partner on Prescription Thugs) [26:20]
- [Peter Billingsley](https://en.wikipedia.org/wiki/Peter_Billingsley) (producer on Prescription Thugs, also played “Ralphie” in Christmas Story) [26:45]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) (late philosopher that Peter admired) [29:45]
- [Michael O’Hearn](https://www.instagram.com/mikeohearn/?hl=en) (current training partner of Chris and Mark) [31:50, 1:10:00, 1:32:30, 1:36:15]
- [Paul Attia](https://twitter.com/papaalphablog?lang=en) (Peter quotes Paul as saying never judge a man by where he stands but by how far he’s traveled to get there) [32:15]
- [Hulk Hogan](https://en.wikipedia.org/wiki/Hulk_Hogan) (Hulk beating Iron Sheik in 1984 changed Chris’s life) [34:50]
- [Iron Sheik](https://en.wikipedia.org/wiki/The_Iron_Sheik) (Hulk beating Iron Sheik in 1984 changed Chris’s life) [34:50]
- [Mr. T](https://en.wikipedia.org/wiki/Mr._T) (popular pro wrestler and TV star in the 1980s) [36:00]
- [Big John Studd](https://en.wikipedia.org/wiki/Big_John_Studd) (WWE, body slam challenge) [36:30]
- [Chief Jay Strongbow](https://en.wikipedia.org/wiki/Chief_Jay_Strongbow) (WWE, body slam challenge) [36:45]
- [Andre the Giant](https://en.wikipedia.org/wiki/Andr%C3%A9_the_Giant) (WWE, body slam challenge) [37:00]
- [Mike Mentzer](https://en.wikipedia.org/wiki/Mike_Mentzer) (less training stimulus approach followed by Bell brothers, favorite bodybuilder of the 70s/80s) [46:00, 1:46:30]
- [Jeff Bezos](https://twitter.com/JeffBezos?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (example of someone making it look easy but actually very hard to be them) [1:05:50]
- [Elon Musk](https://twitter.com/elonmusk?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (example of someone making it look easy but actually very hard to be them) [1:05:50]
- [Dwayne Johnson “The Rock”](https://www.instagram.com/therock/?hl=en) (example of someone making it look easy but actually very hard to be them) [1:05:50, 1:47:30]
- [Ron Fedkiw](https://en.wikipedia.org/wiki/Ronald_Fedkiw) (powerlifter and now a professor at Stanford) [1:10:00]
- [Mark Rippetoe](https://twitter.com/CoachRippetoe?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (Peter recommends his videos for learning to strength train) [1:14:00]
- [Ed Coan](https://www.instagram.com/eddycoan/?hl=en) (“best squatter ever”) [1:14:30, 1:47:45]
- [Stan Efferding](https://www.instagram.com/stanefferding/?hl=en) (“strongest raw powerlifter ever”) [1:14:30]
- [Robb Wolf](https://twitter.com/robbwolf) (exercise and nutrition) [1:16:45]
- [Lee Haney](https://www.instagram.com/lee_haney_official/?hl=en) (bodybuilder, Peter has his poster on his wall growing up) [1:18:30]
- [Jeff Martin](https://thebrandxmethod.com/speaker/jeff-martin-2/) (owner of The Brand X which trains kids to lift weights) [1:20:15]
- [Kelly Starrett](https://twitter.com/mobilitywod?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) ([MobilityWOD](https://www.mobilitywod.com/), stand up desk for kids) [1:24:00]
- [Juliet Starrett](https://twitter.com/mrsmobilitywod) ([MobilityWOD](https://www.mobilitywod.com/), stand up desk for kids) [1:24:00]
- [George Washington](https://en.wikipedia.org/wiki/George_Washington) [1:25:00]
- [Olivia Attia](https://peterattiamd.com/sneak-peek-peter-attia-drive/) (Peter’s daughter who he taught to practice increasing her dead hang time on a pull-up bar) [1:26:30]
- [Jay Cutler](https://twitter.com/mrojaycutler?lang=en) (bodybuilder, example of discipline, 4 time Mr. Olympia) [1:28:50, 1:44:00, 1:47:30]
- [Arnold Schwarzenegger](https://twitter.com/Schwarzenegger?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (bodybuilder) [1:29:15, 1:46:15]
- [Daniel Orrego](https://www.google.com/url?q=https://www.youtube.com/watch?v%3DWzmldVWdIXc&sa=D&ust=1541766137597000&usg=AFQjCNH6a3x_N9wQP02R0aCHJ7dTGqWkgw) (part of Bell brothers team, keto diet expert, ketopetsanctuary.com) [1:32:30]
- [Hany Rambod](https://www.instagram.com/hanyrambod/?hl=en) (nutritionist for Phil Heath, convinced Mark to compete in bodybuilding) [1:35:15]
- [Phil Heath](https://www.instagram.com/philheath/?hl=en) (2018 champion of Mr. Olympia) [1:35:15, 1:44:30]
- [Ronnie Coleman](https://www.instagram.com/ronniecoleman8/) (bodybuilding) [1:35:30]
- [Charles Glass](https://www.instagram.com/thecharlesglass/) (helping Mark with posing, “Godfather of bodybuilding”) [1:36:00]
- [Dexter Jackson](https://www.instagram.com/mrolympia08/?hl=en) (bodybuilder) [1:36:00, 1:42:00]
- [Brian Shaw](https://www.instagram.com/shawstrength/?hl=en) (4-time world’s strongest man) [1:41:45]
- [Danny Hester](https://www.instagram.com/dannyhester/?hl=en) (winner of the new bodybuilding category of Classic Physique) [1:45:30]
- [Frank Zane](https://www.instagram.com/officialfrankzane/) (bodybuilder of the 70s/80s) [1:46:30]
- [Dorian Yates](https://www.instagram.com/thedorianyates/?hl=en) (Blood and Guts workout, 90s bodybuilder) [1:46:30]
- [Stone Cold Steve Austin](https://twitter.com/steveaustinbsr?lang=en) (WWE, someone Bell brothers met that exceeded their expectations) [1:47:30]
- [Joey Diaz](https://en.wikipedia.org/wiki/Joey_Diaz) (thinks former steroid users look like a “bag of shit”) [1:49:30]
- [Dr. Ron Krauss](https://www.chori.org/Principal_Investigators/Krauss_Ronald/krauss_overview.html) (statins) [1:59:30]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/11/chris-and-mark-bell-beach-profile-500x500.png)

##### Mark and Chris Bell

**Mark Bell** is an American professional powerlifter, patent holder, owner of Super Training Gym, and a former professional wrestler. His best lifts in competition (in powerlifting gear) include a 1,080 lb (490 kg) squat, an 854 lb (387 kg) bench press, and a 766 lb (347 kg) deadlift; he has also managed a 578 lb (262 kg) raw (unequipped) bench press. He is the younger brother of Mike Bell and Chris Bell (Director of Bigger, Stronger, Faster\*). [[everybodywiki.com](https://en.everybodywiki.com/Mark_Bell_(powerlifter))]

Mark on YouTube: [Mark Bell – Sling Shot](https://www.youtube.com/user/supertraining06)

Mark on Instagram: [@marksmellybell](https://www.instagram.com/marksmellybell/?hl=en)

Mark on Facebook: [Mark Bell](https://www.facebook.com/marksmellybell/)

Mark on Twitter: [@MarkSmellyBell](https://twitter.com/MarkSmellyBell)

**Chris Bell** (born November 3, 1972) is an American director, producer and writer, known for his documentaries Bigger, Stronger, Faster\* (2008 as Christopher Bell), Trophy Kids, and Prescription Thugs (2015). In 1997, Bell obtained his Bachelor of Arts in Film Production from the University of Southern California. Bell currently resides in California. He founded his film production company Bigger Stronger Faster Inc, which is devoted to producing educational documentaries, films, and TV shows. [[wikipedia.org](https://en.wikipedia.org/wiki/Chris_Bell_(director))]

Chris on YouTube: [Chris Bell](https://www.youtube.com/channel/UCEP8hF8oKlv9Ey5wtt1DjYw)

Chris on Instagram: [@bigstrongfast](https://www.instagram.com/bigstrongfast/?hl=en)

Chris on Facebook: [Chris Bell](https://www.facebook.com/boar.bell)

Chris on Twitter: [@BigStrongFast](https://twitter.com/BigStrongFast)