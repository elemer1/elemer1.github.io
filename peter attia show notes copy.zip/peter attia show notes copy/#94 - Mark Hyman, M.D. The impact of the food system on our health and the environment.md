# #94 – Mark Hyman, M.D.: The impact of the food system on our health and the environment

**Source:** [https://peterattiamd.com/markhyman/](https://peterattiamd.com/markhyman/)

---

In this episode, Mark Hyman, M.D., director of the Cleveland Clinic Center for Functional Medicine and the author of Food Fix, discusses that if we can fix the food system, we can solve many big problems—namely the chronic disease/obesity epidemic, the rising costs of healthcare, as well as the big problems facing the environment. Mark first briefly lays out the health consequences of processed food with a focus on the gut microbiome. From there, Mark discusses the environmental consequences of industrial farming and lays out how we can affect change on the individual level, through policy and regulations, and perhaps most importantly through regenerative agriculture. Additionally, Mark talks about the potential health risks of consuming GMO foods, herbicides, and other chemicals used in industrial farming as well as the environmental consequences, such as the loss of soil, caused by those same fertilizers and methods of farming.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/markhyman/the_Drive_public.png)

Play

#94 - Mark Hyman, M.D.: The impact of the food system on our health and the environment

#94 - Mark Hyman, M.D.: The impact of the food system on our health and the environment

1x15s30s

0:001:50:28

## We discuss:

- The negative consequences of the existing food environment [3:25];
- What makes processed food so unhealthy? [9:00];
- The gut microbiome: Inflammation from gut permeability, and how to measure gut health [18:30];
- Steps to fixing a bad gut—The Five R’s [24:30];
- Some staggering health statistics, and which races might be more genetically susceptible [27:15];
- An argument for government regulations and policies to fight back against a massive food industry with unlimited resources (and what we can learn from the tobacco story) [29:00];
- Industrial farming and climate change: The degradation of soil and use of fertilizer [41:45];
- Regenerative agriculture: Could it be the answer to food waste, our health problems, and the environment? [51:45];
- Comparing the “Impossible Burger” to regeneratively raised beef [1:06:00];
- GMO and Roundup—The potential health risks of consuming GMO foods sprayed with Roundup (glyphosate) and other herbicides and pesticides [1:08:15];
- How the livelihood of farmers are being affected by big ag companies and the current industrial farming system [1:16:30];
- The loss of biodiversity in our food, and what “organic” really means [1:19:00];
- What can people do on the individual level to protect themselves as well as affect change to the toxic food system? [1:25:00];
- What role does the USDA play in this “toxic” food environment? And how do we fix it? [1:30:15];
- The top 3 changes Mark would make if he was “food czar” [1:35:15];
- Mark’s rebuttal against the argument that it’s best for the environment if stop farming animals and move to a fully plant-based diet (and his argument for “agriculture 2.0) [1:36:30];
- What is Mark’s overall mission with the work that he’s doing? [1:40:30];
- Bread in the US vs. Europe: Why does bread (and wheat products) taste different and potentially cause less health problems in Europe versus the US? [1:42:00]; and
- More.

§

## Show Notes

## The negative consequences of the existing food environment [3:25]

**Why did Mark decide to go into food research?**

- As a doctor seeing patients day after day for 30 years, as a functional medicine doctor, my focus is on **why are my patients so sick?**
  - The majority of them, it has some relationship to food.
  - I had to figure out **why are they eating the food they’re eating**?
  - The food system we have is the problem
- **–Why do we have this food system?**
  - It’s because of the food policies.
- **–Why do we have our food policies?**
- - It’s the food industry that influences our government policies through lobbying and other influences that they do across the spectrum of society to drive their products to the market and sell them.

> “There’s 11 million people that die every year from eating ultra processed food and not enough of the good food. And I think it’s an underestimate.”

**The answer as to why Mark decided to focus on this issue**: “*I realized I couldn’t fix my patients in my office or in the hospital, or the clinic I had to go to where the source of the problem was.*”

*Was the evolution of farming all bad?*

- No, in fact, Mark says that, “**agriculture is a solution, if we do it right.**”

**The main pillars making the current food environment “toxic”**

- **Chronic disease**: Food is the biggest driver of [chronic disease affecting six out of 10 people](https://www.cdc.gov/chronicdisease/resources/infographic/chronic-diseases.htm)
- **Economic crisis**: It’s clearly the biggest driver of economic stress in this country, in our $22 trillion debt.
  - [One third](https://www.kff.org/medicare/issue-brief/how-much-does-medicare-spend-on-insulin/) of all Medicare expenses are for diabetes alone
  - [One third](https://www.nationalpriorities.org/budget-basics/federal-budget-101/spending/) of all of our federal budget is Medicare
  - And if it was a company, it would be the biggest company in the world at $1 trillion annually.
- **Climate change**: It’s also driving climate change.
  - A food system, end-to-end, is the number one cause of climate change more than fossil fuels, says Mark
  - It’s causing massive environmental degradation including loss of bio-diversity (plant species, animal species, livestock species)
  - And of course that leads to massive political instability because of our food system of climate refugees, because the food system is driving climate.
    - The UN estimates that within a decade or few decades we’re going to have 200 to a billion climate refugees
- **Social injustice**: It’s driving social injustice in many ways through how it affects our kids’ cognitive development and ability to learn (And there’s huge academic achievement gaps)
  - It leads to massive health disparities because poor communities are more affected by these foods and are more targeted by them.
- **Cognitive behavioral issues:** Violence, conflict, depression, suicide
  - And I think our diet has changed so radically, not just in the last 10,000 years, but in the last 40 years with the advent of massive amounts of **ultra processed food** and that’s driving cognitive behavioral issues, violence, suicide, conflict, etc.
- **National security**: It even threatens our national security because [70% of military recruits are unfit to fight](https://time.com/2938158/youth-fail-to-qualify-military-service/) and they are rejected

**The good news?**

- All these issues are connected by food, they can all be solved by going to the root and fixing our food system.

## What makes processed food so unhealthy? [9:00]

**Is there really anybody who does NOT believe that processed food is terrible for us?**

- Mark says you’d be surprised, “There’s $12 billion spent by the food industry on nutrition ‘research’ that confuses peoples, muddies the waters, declares that Gatorade is a great sports drink and that sugar doesn’t cause obesity.”
- Academics, doctors, health professionals have no clue how powerful food is to heal disease.
- Most people just think that if you eat too much, you’re going to get fat
- We have a real lack of understanding of the power of food to cause disease and the power of food to cure disease.
- Something like **medicare for all** would bankrupt the country, says Mark, “*because everybody’s sick and it’s going to bankrupt the country unless we fix why they’re sick in the first place.*”

**What do you think it is about processed foods that are particularly difficult metabolically for our species?**

- Historically we ate ~800 different species of plants
  - We at almost 100 g of fiber per day
  - Now we average about 8 grams of fiber per day
- Sugary foods are so easy to get (in contrast to what the [Naaplese honey hunters](https://www.nationalgeographic.com/magazine/2017/07/honey-hunters-bees-climbing-nepal/) must endure)
- The development of industrial agriculture was a huge positive in the post-war world and created an abundance of calories that solved hunger issues around the world
- HOWEVER… the unintended consequence of the intensive chemical agriculture with intensive fertilizer use and the commodity products (wheat, corn and soy and rice) was the obesity epidemic
- Our biology isn’t adapted to eating highly refined foods
  - Yet, it’s ~60% of our calories
  - And every 10% of your calories that’s ultra processed food, your [risk of death goes up by 14%](https://www.ncbi.nlm.nih.gov/pubmed/30742202)
- And that’s not to mention other stuff in processed foods and industrial farmed produce that may be problematic like:
  - refined soybean oil
  - food additives
  - chemicals
  - BPA from plastics
  - Other metabolic toxins
  - pesticides and glyphosate affecting our microbiome

> “Sugar and starch and flour are the big drivers, but there’s all these other components. And then who knows what’s happening with pesticides and glyphosate affecting our microbiome. I mean it’s such a complex web of different factors that alter our metabolic pathways that drives disease.”

**Energy balance (too much) vs. void of nutrients (too much junk food)]**

*How much of the problem with processed food is about a lack of nutrients and fiber vs. an energy balance problem?*

- Probably both, says Mark
- It’s well known that if you are looking for nutrients, you’re just going to eat anything (e.g., kids with [Pica](https://www.webmd.com/mental-health/mental-health-pica) will eat dirt)

-Refined starches and sugars affect your biology:

- They raise insulin, which has a cascading effect of fat storage in your belly, which is a dangerous fat.
- It leads to increased hunger, affects your brain chemistry.
- It actually locks the fat in the fat cells so that can’t get out.
- It slows your metabolism.
- So you’re in this cascade of vicious cycles.

-In terms of energy balance…

- Most people think about calories in, calories out
- But it’s more complex than that
- There’s different effects of food on your biology, independent of calories.
- 750 calories of Coke is NOT the same as 750 calories of broccoli, for example, they have profoundly different effects on your biology
- But we don’t really appreciate that medicine and most of our current thinking about weight loss is focused on calories in, calories out.

-The Food industry loves to push the “calories in, calories out” narrative:

- They say, “it’s all about moderation. There’s no good or bad calories. It’s exercise more, eat less.”
- But the truth is that these foods affect our brain chemistry and create all sorts of metabolic issues that are incredibly difficult.
- Neurologist [David Perlmutter](https://www.drperlmutter.com/) just wrote a book called [Brain Wash](https://www.amazon.com/Brain-Wash-Thinking-Relationships-Happiness-ebook/dp/B07RKW2PPH), which explains the prefrontal cortex and the amygdala are uncoupled with an inflammatory diet
  - The prefrontal cortex, which is the decision maker, understands the consequences of his behavior, is not talking to the amygdala which is the impulse part of your brain (the fight or flight part of your brain, the pleasure seeking part of the brain)

> “We have so much bad behavior and conflict and so forth because we’re eating this inflammatory diet that’s literally dysregulating our brains. So the adult in the room is asleep.”

**What is it about processed food and sugars that could cause inflammation?**

- There is a lot of genetic variability from person to person in terms of their tolerance
- But anyone will do better when eating a whole foods, unprocessed diet
- You can actually measure inflammation in response to diet through various biomarkers through CRP or [SED rate](https://www.google.com/search?q=sed+rate&oq=SED+rate&aqs=chrome.0.0l7j69i60.1024j0j7&sourceid=chrome&ie=UTF-8)
- Insulin is another inflammation driving hormone
  - Processed foods drive up insulin which leads to visceral belly fat
  - Mark calls this a “metabolic fire” that starts in these cells and it spreads inflammation throughout the body

–*What if tests for CRP and interleukins came back normal? Could there still be an inflammatory response?*

- Mark says our current tools for assessing the immune response to food are “pretty crappy”
- Fortunately, there’s this whole new panel of inflammatory biomarkers that are much more specific and much more sensitive and it enables us to really look at the inflammatory response that’s happening in the body (see [Buck Institute of Aging](https://www.buckinstitute.org/lab/campisi-lab/))

## The gut microbiome: Inflammation from gut permeability, and how to measure gut health [18:30]

**Peter’s take on inflammation and the gut**:

- Peter admits that there current protocol for trying to fix subtle elevations in fibrinogen and/or C reactive protein or at least two of the interleukins is “crude”
- It’s basically a elimination diet where you take thing away and keep an eye on the biomarkers
- And the real problem is we don’t know exactly the mechanism by which we are seeing these inflammatory markers rise
- One possibility is gut permeability

**Does Mark think gut permeability is a prevalent source of inflammation?**

- It’s a huge source, says Mark
- “All our guts are messed up”
- There’s a well-studied phenomenon called [metabolic endotoxemia](https://restorativemedicine.org//wp-content/uploads/2017/09/Krishnan_Metabolic-Endotoxemia.pdf)

-The gut microbiome has a huge role in regulation of weight (independent of calories)

- ⇒ This [experiment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4995824/) shows you can take the poop out of a obese rat and put it into a skinny rat and make it fat

–**Your microbiome is regulated by what you eat**:

- The amount of (or lack thereof) fiber, prebiotics, the phytonutrients, phytochemicals, the polyphenols all affect the **quality of the “garden” you have growing inside of you**
- And you can get a lot of “nasty weeds” in there

-Additionally…

- Our low fiber, high sugar, high processed food diets increase bad bugs in the gut
- Antibiotics, acid blockers, antiinflammatory drugs, hormones all screw up our gut as well
- And environmental toxins, such as glyphosate, is super toxic to the microbiome

-When all this starts to happen…

- They start to disrupt the gut microbiome
- They disrupt the lining of the gut.
- They cause what we call “leaky gut”
- This allows the absorption of bacterial products, bacterial toxins as well as food antigens
- And they start to create an inflammatory response
- This is partly a problem because about *60% of your immune system is in your gut*

–*An interesting discovery*:

- At least a third of our metabolites in our blood may be from microbiome
- And these non-human bacteria that are regulating your immune system, activating your mitochondria, regulating your DNA, affecting your brain chemistry (mood), and affecting all sorts of diseases.

> “This is like a really exciting area and I think getting people’s microbiome sorted often happens when you shift to a whole-foods, plant-rich diet.”

**How does one measure gut health?**

“It’s a challenge because you are looking at a moving target, an ecosystem” says Mark

*-Many different biomarkers to assess what’s going on in the gut*:

- Is there adequate pancreatic enzyme function looking at pancreatic elastase?
- Are there absorption issues?
- Looking at fecal fats, are there inflammatory markers in there?
  - For example, calprotectin or eosinophil protein X, which are standard markers to look at inflammation in the gut.
- What’s your IGA levels, your antibody levels?
- Indicators of dysregulated gut microbiome – such as low levels of short chain fatty acids
  - Short chain FA are essentially produced by good bacteria that are the fuel for the gut
  - They have anticancer & antiinflammatory properties
  - Example would be having low levels of butyrate
- You can also look for different **microbiome characteristics** using DNA, or PCR analysis through the microRNAs
  - For example, levels of Akkermansia
- You can also look at gut culture for parasites (PCR testing)

> “There’s a lot of things that we look at and get a gestalt. It changes over time, but you can see if someone’s got a good gut, or okay gut, or a terrible gut.”

## Steps to fixing a bad gut—The Five R’s [24:30]

1. REMOVE
2. REPLACE
3. REINOCULATE
4. REPAIR
5. RESTORE

Step 1: **Remove**

- Remove foods that may be triggering a problem like:
  - Gluten, which affects permeability
  - Dairy
  - Grains for some people
- Remove “bad bugs”
  - Some people have a parasite (Mark recently gave a woman [Alinia](https://www.alinia.com/), antiparasitic medication, for six days and she felt better after suffering for 20 years)
  - Other people may have bacterial overgrowth or yeast overgrowth that needs to be removed

Step 2: **Replace**

- Replace what might be missing
- Fiber, [prebiotics](https://en.wikipedia.org/wiki/Prebiotic_(nutrition)), enzymes, various things that may be needed to support the system.
- You can take supplements or eat prebiotic foods like plantain and artichokes

Step 3: **Reinoculate**

- Provide [probiotics](https://en.wikipedia.org/wiki/Probiotic) where necessary.
- And that can be through foods like fermented foods or can be through probiotic supplements.

Step 4: **Repair**

- The body may need certain nutrients to heal:
  - Glutamine
  - Vitamin A
  - Fish oil
  - Butyrate
  - Polyphenols from food (pomegranate, cranberries, green tea, etc.)
    - “*We thought it was prebiotics and probiotics, but turns out the polyphenols in plant foods are super helpful for the gut microbiome.*”

Step 5: **Restore**

- Restore your nervous system, says Mark
  - For example, high stress levels can cause a leaky gut
- This [article](https://www.jbsnourishwell.com/what-are-the-5-rs-of-gut-restoration/) also adds…
  - Be mindful of: Sleep, The way you approach and eat food, Your emotions, Exercise, and Stress ⇒ These can all affect the GI tract
  - Also, activate your [vagus nerve](https://en.wikipedia.org/wiki/Vagus_nerve) for digestive health

## Some staggering health statistics, and which races might be more genetically susceptible [27:15]

**Some staggering statistics**: ([ref](https://www.cdc.gov/chronicdisease/resources/infographic/chronic-diseases.htm))

- 6 out of 10 Americans [have a chronic disease](https://www.cdc.gov/chronicdisease/resources/infographic/chronic-diseases.htm)
- 4 out of 10 have [two or more chronic diseases](https://www.cdc.gov/chronicdisease/resources/infographic/chronic-diseases.htm)
- In 10 years, [83 million Americans with have 3 or more](https://www.cdc.gov/chronicdisease/resources/publications/factsheets/diabetes-prediabetes.htm)
- 1 in 2 Americans has [prediabetes or type 2 diabetes](https://www.cdc.gov/chronicdisease/resources/publications/factsheets/diabetes-prediabetes.htm)
- 75% of us are [overweight](https://www.cdc.gov/nchs/fastats/obesity-overweight.htm)
- Most states now have [40% obesity rates](https://www.cdc.gov/nchs/fastats/obesity-overweight.htm)

> “These are massive things that are happening at a scale that we’ve never seen in history, that we haven’t been equipped to deal with, that we haven’t really thought of how to address. And it’s like we’re trying to scramble to fix it.”

**Are there genetic differences that make certain races of people more susceptible?**

- Genetically, there’s certain segments of the population that are more susceptible to getting obesity and diabetes when they’re in an abundance of sugar and flour
- That includes
  - Native Americans (probably the most susceptible)
  - African Americans
  - Latinos
  - South Pacific islanders
  - People from India, China, and Asians people often are at [much higher risk even at lower body rates](https://peterattiamd.com/roneshsinha/)

## An argument for government regulations and policies to fight back against a massive food industry with unlimited resources (and what we can learn from the tobacco story) [29:00]

Is there any country or government in particular that seems more attuned to this problem than the American government?

- “Many. In fact, most.” says Mark

⇒ Chile, for example, is attempting to [address the massive obesity rates in kids and adults](https://www.npr.org/sections/thesalt/2016/08/12/486898630/chile-battles-obesity-with-stop-signs-on-packaged-foods) and the staggering healthcare cost in the following ways:

- [Taxing soda](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6029775/)
- [Warning labels](https://www.npr.org/sections/thesalt/2016/08/12/486898630/chile-battles-obesity-with-stop-signs-on-packaged-foods) on bad food
- [No cartoon characters](https://www.nytimes.com/2018/02/07/health/obesity-chile-sugar-regulations.html) can be used to advertise to kids
- eliminated any processed foods from school lunches
- eliminated any advertising on junk food from 6am until 10pm
- the restriction of food marketing and the warning label and so forth had a fourfold increased benefit compared to the soda tax

**What can we learn from the successful campaign against smoking cigarettes?**

- - Some might argue the marketing restrictions would violate the First Amendment
  - The US has faced an analogous situation with smoking
  - Smoking ads weren’t outright banned, but they were forced to run a counter-ad about the dangers of smoking immediately following the advertisement
  - The counter ad was so devastating to tobacco companies that they basically volunteered to stop running ads at all
  - Prior to the Surgeon General saying publicly that cigarettes are causing lung cancer, about 55% of the people over 18 years smoked
  - That has dropped to about [16% currently](https://www.cdc.gov/tobacco/data_statistics/fact_sheets/adult_data/cig_smoking/)
  - Peter brings this up as a “work around” rather than going down the fight against the First Amendment
  - It would almost be like a drug commercial⇒ “*You can eat this soda, but it’s going to cause obesity, diabetes, cancer, dementia, and kill you early.*”
- *Perhaps the successful fight against the tobacco industry offers a playbook that can be followed?*

**The food industry is stalling the regulations**

- Mark says that the food industry is actually copying the *tobacco industry’s playboo*k to slow or stall or stop this

–*Example #1*: Subversive tactics to avoid the [soda taxes that passed in California](https://news.berkeley.edu/2019/02/21/three-years-into-soda-tax-sugary-drink-consumption-down-more-than-50-percent-in-berkeley/)

- The American Beverage Association went to California and put in a ballot measure, which was designed to prohibit local taxes unless it was a *two thirds majority*
  - Meaning you couldn’t fund your school, your police department, your fire department, your cleanup, road clean unless there was a two thirds majority. That would hamper local governments dramatically.
- And they spent millions of dollars pushing this ballot measure even though it had nothing to do with food.
- Next, at the last minute before the election, they went to Governor Jerry Brown and told him, “*Look, we’ll pull this measure, but you have to put in place a preemptive law that prohibits any future taxes on soda or junk food*.”
- This is exactly what tobacco did.

–*Example #2*: An initiative called the [Global Energy Balance Network](https://en.wikipedia.org/wiki/Global_Energy_Balance_Network), GEBN

- The GEBN’s mantra was that all calories were the same and it was simply about moderation and calories in/calories out
- Rhona Applebaum (VP at Coca-Cola) ran GEBN and she found a bunch of scientists (like [James Hill](https://www.norc.uab.edu/people/jhill)) who she could co-op, [paid them lots of money](https://www.denverpost.com/2015/12/26/cu-nutrition-expert-accepts-550000-from-coca-cola-for-obesity-campaign/), and funded research to actually promote the idea that all calories are the same
- Eventually it was discovered what they were doing and the NY Times reported it
- After the NY Times article came out they shut down the GEBN

⇒ Here’ is the NY Times article by Anahad O’Connor: [Coca-Cola Funds Scientists Who Shift Blame for Obesity Away From Bad Diets](https://well.blogs.nytimes.com/2015/08/09/coca-cola-funds-scientists-who-shift-blame-for-obesity-away-from-bad-diets/)

> “It just goes to show how these food companies are co-opting scientists co-opting professional associations, co-opting social groups, co-opting the government, putting forth front groups and spinning all kinds of misinformation in a very coordinated strategic strategy to disrupt public opinion, to confuse the public, and to allow their shenanigans to keep going.”

**Should we try to solve this on the individual level instead of the government level?**

*-Why not focus all of the efforts on helping individual people understand the harm of this food so that they can make the informed choice?*

*-Do we really believe that this has to be solved at the level that seems almost unwinnable, which is fighting an unethical opponent with infinite resources?*

- Mark points out it worked against the tobacco industry
- Peter: “*But you don’t need tobacco to live, right?…The advantage that you would have as an anti-tobacco crusade person is the ground is not muddied by the notion that tobacco is part of a group called food that you need to live.*”

–*Would we be better off putting more effort into sort of the grassroots campaign to inform individuals versus using public policy?*

- Mark says that we must do both
- People are starting to change some of their eating habits and forcing companies to create healthier product lines
- “*But that alone is not enough because there are structural problems that are not solvable unless we change how we grow food, what we grow, how we process, distribute, market, sell, eat and waste it*.”

## Industrial farming and climate change: The degradation of soil and use of fertilizer [41:45]

> “Does fixing food fix climate? It does. It’s actually one of the only ways to really reverse climate change.”

**Some climate change stats:**

- A million acres flooded in the Midwest, crop land, it’s destroying farmer’s livelihood
- Increasing weather patterns of hurricanes and wildfires in Australia and California.
- Melting of three trillion tons of ice from Antarctica

–*Peter’s two cents*:

- I think the term climate change, global warming, were not the best ways to describe this phenomenon
- Climate *volatility* would have been a better way to have explained it because i) it’s actually more accurate, and ii) it provides a better explanation for what you are describing

**Why is it happening and what’s the cause of it?**

- Most people think it’s fossil fuels taking up all the carbon that was stored in the Earth’s crust and burning it and releasing that carbon
- That’s about ⅓ of the reason, says Mark

-Half of climate change comes from our **food system** through all sorts of different mechanisms:

   1—Deforestation, you lose the carbon capture from the trees

   2—Soil destruction from destructive agriculture

- The industrial growing of food tills the soil and which disrupts the normal organic matter and causes soil erosion which releases carbon in the environment

**More about the soil**

> “[Soil is] probably the biggest cause and the biggest solution to fixing climate change”

- A third to 40% of all the carbon in the atmosphere today that’s causing climate volatility is from the **loss of soil**
- When soil is alive, meaning it has living organic matter (including carbon) in it… It can hold three times the amount of carbon that’s in the atmosphere today (It can hold 3 trillion tons of carbon)
- The UN [estimated](https://www.bloomberg.com/news/articles/2019-10-23/how-to-halt-global-warming-for-300-billion) that if we take 2 million of the 5 million degraded hectares of land around the world and we intensively use [regenerative agriculture](https://en.wikipedia.org/wiki/Regenerative_agriculture) to restore the soil, we could stop climate change and delay that progression for about 20 years and it would cost $300 billion
  - By comparison, $300 billion is essentially what we pay every year for diabetes in America through Medicare
- “*So this is a solvable problem.*”

**The difference between soil and dirt**:

- Soil is alive ⇒ it has all kinds of bugs in it, mycorrhizal fungi, bacteria, and carbon in it from the plants
- It also holds a huge amount of water
  - For every [1% organic matter can hold 27,000 gallons of water](https://www.nrcs.usda.gov/Internet/FSE_DOCUMENTS/stelprdb1082147.pdf), which would prevent floods and droughts and create more resilient farms
  - Soil is like a sponge, so when it rains instead of the rain running off or running through, it gets stored like a sponge in the soil so that you don’t need to irrigate, that you don’t have to worry about floods and droughts.
  - Now the reason we had so much of these floods in these flooded farm fields in the Midwest was because the soils are just dead and the have to use more and more fertilizer.
- We’re killing the soil

- We’re killing the soil by using … fertilizer, pesticides, herbicides, tilling, not using cover crops, not using crop rotations, not using animals in an integrated way to actually create more soil, and more

-Soil holds carbon dioxide**:**

- Plants to suck out carbon dioxide from the atmosphere and it gets pulled through the plants into the soil and it stays there
- You’ve got this incredible root system that goes down into the soil which delivers carbon to be eaten by bacteria, like this massive mycorrhizal fungi,
- This creates a lot of necrotic, dead, but like actually organic matter
- It’s an incredibly rich living organism

-Dirt is dead, by contrast:

- It doesn’t hold water, it doesn’t have much carbon in it, and it doesn’t have much nutrients
- Since we are growing food in dirt, we see [50% less nutrient density](https://www.ncbi.nlm.nih.gov/pubmed/14653505) in food (even healthy food)
  - E.g., broccoli has less minerals than it did 50 years ago

**Fertilizer is driving the destruction of our soil**

- There’s 400 billion pounds of fertilizer used everywhere in the world
- It’s a seven fold increase over the last 40 years because they are only two thirds as effective as they used to be
- The process of making fertilizer is itself very chemically intensive and uses energy
  - It’s the number one utilizer of fracking-produced natural gas, says Mark, and fracking releases methane into the atmosphere
  - Fertilizer companies, like Yara and Mosaic, they [use more natural gas than Exxon](https://www.grain.org/article/entries/5976-emissions-impossible-how-big-meat)
  - A methane leak in Ohio was recently so big you could [see it from space](https://www.nytimes.com/2019/12/16/climate/methane-leak-satellite.html)
  - The methane from fertilizer uses to growing plants is a quarter of all methane released gas in the environment today (which is as much as factory farm cows)

–*What percent of oil usage is from food production/transport/consumption?*

- [One fifth of all our oil consumption is for the food system](https://web.mit.edu/dusp/dusp_extension_unsec/reports/polenske_ag_energy.pdf)
- That’s more than all cars, planes, boats, transportation combined

***What is the purpose of fertilizer?***

- The purpose of fertilizer is to provide nitrogen, phosphorus, and other nutrients to the plants

-Peter says, “I don’t think people appreciate the significance of carbon fixation.”

- It’s a complicated chemical reaction to take carbon and join it to carbon like a plant can do
- First, it requires sunlight for this photosynthetic thing
- But basically plants need carbon, which they’re getting from the air
- Then they need nitrogen and phosphorus, which they’re getting from their soil.
- And they need energy and water, which they’re getting from the environment
- And then they make biomass.

*-So the fertilizer is where we give them the nitrogen and the phosphorous, correct?*

- Yes, says Mark, but most of the fertilizer that was growing plants historically came from either nitrogen fixing plants like the lagoons or from the animals.
- The reason we have 50 feet of top soil in some areas in this country, 150 years ago is because of all millions of bison running around.
- They’d be like bison and elk and all these ruminants that were running around in big herds, chomping things down, moving on to the next spot, peeing and pooping, saliva makes the grass grow.
- So it was this beautiful symbiotic system that built literally tens of feet of topsoil
- Today, **the problem is not that we have too many cows, it’s how we’re growing and farming them**

## Regenerative agriculture: Could it be the answer to food waste, our health problems, and the environment? [51:45]

**Explosion in crop yield—was it the GMO?**

- Today, the only metric that really “matters” is bushels per acre, per year.
- It all comes down to yield.

-Using corn as the example…

- Basically from the Civil War to about the end of World War II, if you look at crop yield and you see the plot, it was about 20 bushels per acre per year
- At the end of World War II, yield began rising up to **200 bushels per acre, per year**
- Most people erroneously assume it was the GMO that was the reason for this
- But in fact, GMO didn’t really even kick in until that number was 160 bushels per acre per year

–*The explosion in crop yield was a combination of the following*:

- Nitrogen-based fertilizer
- Crop rotation
- Industrial farming (meaning the ability to actually use machines to not just have a farmer out there)
- selective breeding (e.g., crossing)
- So it was a bunch of things that came and then basically GMO has put like a ~10% plus up on that from a yield perspective

–*The point is*…

- this really began in earnest about 70 years ago and prior to 70 years ago it’s been remarkably flat
- But post World War II we had to figure out how to feed a bunch of people and 20 bushels per acre per year was not cutting it.
- We’re now 10 times the yield, but it came at **quite a cost** (to health and climate, for example)

**Regenerative ag and the fallacy that it doesn’t produce as much yield**

-Mark says, “*there’s sort of a fallacy in the idea that we can’t produce the same amount of food using regenerative methods*”

*⇒ The story of farmer,* [*Gabe Brown*](https://brownsranch.us/welcome/):

-Gabe is a North Dakota farmer who has a 5,000 acre farm that was devastated by hail, devastated by weather, and was about to go bankrupt

- He decided to try regenerative agriculture
- He has now built 29 inches of soil
- He uses no chemical inputs
- He makes his own fertilizer from the animals as well as from the “nitrogen fixing” plants that he plants
- The results?
  - He produces more food, better quality food, and makes **20 times as much money** as his neighbor.

> “There’s this fallacy that we need green revolution, or that we need industrial agriculture to feed the world. . .That’s really what Monsanto (now Bayer) and a lot of these big agrochemical companies are saying because they are trying to push their products on the marketplace.”

**Could regenerative ag fix climate change?**

-Not only does regenerative ag increase production… but it “*interrupts all these problems that are actually driving* ***climate change***”

⇒ *Just ONE example is the issues related to factory-made fertilizer…*

- It damages the soil and it [releases nitrous oxide](https://www.ncbi.nlm.nih.gov/pubmed/24927583) which is 300 times more potent than greenhouse gas than carbon dioxide
- Plus to make it you need natural gas from fracking
- Additionally, all that runs off into the rivers, streams and lakes and goes in into the oceans and it’s created dead zones and 400 areas around the world the size of Europe
- One [dead zone in the Gulf of Mexico](https://gulfhypoxia.net/gulf-of-mexico-dead-zone-mitigating-the-damage/) kills 212,000 metric tons of fish every year

*Why is that not a problem when the fertilizer is coming from an* ***organic nitrogen source versus an inorganic source****?*

- With an **organic** nitrogen source…
  - Animal poop goes into the soil and then”nitrogen fixing” plants as well
  - And it *stays* in the soil as opposed to running off through this degraded soil into the river stream.

-Is the issue the fertilizer? Or is it the nature of the soil that can’t hold it?

- It’s both, says Mark
- In order to get **dirt** to produce plants, you need to put on more and more amounts of fertilizer
  - Fertilizer is seven fold compared to 40 years ago

–*The problem with fertilizer*:

- It allows us to be lazy and rely less on healthy soil because you can dump fertilizer on dirt and eventually grow what you need.
- But if you actually want the *healthiest soil possible*…
- …you will need to **get your nitrogen contribution from an element that stays within the ecosystem of the soil because it’s a part of it and therefore you’re not going to have the runoff**

> “If you actually want the healthiest soil possible…you will need to get your nitrogen contribution from an element that stays within the ecosystem of the soil because it’s a part of it and therefore you’re not going to have the runoff.”

**Other climate damaging factors from industrial farming**:

- Deforestation
- Soil damage
- Then there’s other energy costing things like…
  - Transportation
  - Refrigeration
  - Processing
  - Distribution
- And then there *food waste*… “which is a big cost.”

**Food Waste**

- The UN [estimates](https://www.fao.org/news/story/en/item/262504/icode/%20/) that humans waste 30-40% of our food

-Peter asks: *What’s the methodology by which one calculates that?*

- I don’t know the answer to that question, but that’s a good question, says Mark

-We waste food in the developed world via…

- we throw out food in our kitchen
- We lose food in the food chain because of lack of storage and transportation, refrigeration.

**Mark summarizes the great benefit of shifting to regenerative ag**:

- All these food production processes add up to **about 50% of climate change**, says Mark
- Mark says that [*regenerative agriculture*](https://en.wikipedia.org/wiki/Regenerative_agriculture) techniques “*could be easily applied and are done in literally millions of acres around the world with great benefit and high productivity and mitigating climate at the same time.*”

*-So what’s the obstacle to moving towards regenerative ag?*

- A $15 trillion food industry that’s **dependent on the products of industrial farming**
  - They’re actually selling the seeds, the fertilizer, the pesticides and herbicides

***Is regenerative ag the answer for the struggling farmer?***

- The average farmer LOSES $1,600 per year
- They do have write offs and subsidies and so forth
- President Trump just [bailed them out for $20 billion](https://www.npr.org/sections/thesalt/2019/12/31/790261705/farmers-got-billions-from-taxpayers-in-2019-and-hardly-anyone-objected)
- Farmers are caught between basically the big ag and the government who is telling them “*you need to produce these foods, here’s the money to support you to do it*”
- But that money then goes to buy the seed, the glyphosate, and other agrochemicals from Monsanto and fertilizer from Yara.

> “They’re just the pass through of the money from the government to big ag and the industry. And that’s the problem.”

–[*Gabe Brown*](https://brownsranch.us/welcome/)*, by contrast…*

- He doesn’t have to buy seed, fertilizer, glyphosate, pesticides, etc.
- He also doesn’t need a lot of irrigation because the soil holds so much water
- He has a diverse ecosystem of animals and plants that he can grow and sell and make a profit that’s more than the others

–*How long to make the transition to regenerative ag?*

- Three to five years
- “*We need a massive effort for supporting and transforming our agricultural system to regenerative ag.*”

-Groups that are working on this:

- [Kiss the Ground](https://kisstheground.com/)
- [Carbon Underground](https://thecarbonunderground.org/)

-From the UN: A huge report called [Climate Change and Land](https://www.ipcc.ch/site/assets/uploads/2019/08/4.-SPM_Approved_Microsite_FINAL.pdf) laid these problems out and how when we are degrading our land that’s contributing to climate

**The climate solution is multifaceted, but it includes** **restoring degraded lands**

-People try to argue that it is not scalable and too expensive

-Mark says that is just not true:

> “*If you look at degraded lands that aren’t being used properly, if you look at land that’s used to grow corn and soy for factory farm animals, that could be converted and we can literally double the amount of cows we produce every year and regenerative farms than we do now. Not that we should, not that we need all that meat, but I’m just saying the argument, that it’s not scalable, that it’s not cost effective, it’s just not true. And the truth is you can say you can be vegan, fine, but we should all grow more plants. But there’s a lot of land on the planet, about 40% of the arable land, you can’t grow food for humans. So these animals up cycle inedible food and put it into a form that we can eat that’s extremely nutrient dense. There’s a beautiful symbiotic ecosystem here, and you don’t have to eat the animals, if you don’t want to, I don’t care, but they’re needed for the regeneration of soil.*”

**Is regenerative ag the top solution to climate change?**

- Mark says that regenerative ag is the top solution to climate change and it’s being overlooked
- The degree to which you could reduce CO2 emissions is not something Mark knows but recommends Paul Hawken’s new book, Regeneration, which isn’t out yet but you can learn more on [medium.com](https://medium.com/@driesenaar/the-next-book-paul-hawken-is-working-on-will-be-called-regeneration-b650bcb774b2)
- It’s been [estimated](https://science.sciencemag.org/content/304/5677/1623) by some that we could draw down anywhere from [30 to a 100%](https://rodaleinstitute.org/wp-content/uploads/rodale-white-paper.pdf) of all the carbon that’s been released since the industrial revolution, if we can scale this up

**What’s the biggest counter argument to regenerative ag?**

- One is that we NEED industrial agriculture to feed the world
- Another counter comes from the vegan community who says this won’t fix the climate
  - Pat Brown from Impossible Foods, for example, has been really clearly stating that we need to get rid of all meat
    - And that even regenerative meat doesn’t work in terms of protecting the environment
    - Mark says that Pat quotes various studies that were flawed and miss a lot of the data

**Regenerative ag ADDS value back into the earth rather than taking value**

- It takes time, but there’s an incredible value chain that gets put in place.
- We take out of the earth [about $125 trillion in natural capital](https://community-wealth.org/sites/clone.community-wealth.org/files/downloads/article-costanza-et-al.pdf) (more than global GDP)
- We don’t put it back and it’s running out
- There’s a lot of people working on this
  - For example, [Farmland LP](https://www.farmlandlp.com/)
    - Private equity company that’s buying up conventional farms, converting them to regenerative agriculture, and moving those farms from single digit profits to high double digit.
    - They are leveraging “ecosystem services”
    - And their first fund had a 67% return
    - They ADD $21 million of value on their farms versus a conventional farm which would actually steal $8 million of value from the earth
- Another example is Costa Rica
  - They are [paying for ecosystem services](https://www.iied.org/payments-for-ecosystem-services-costa-rica-s-recipe) for their farmers in order to produce more soil, conserve water, increase biodiversity, etc.

## Comparing the Impossible Burger to regeneratively raised beef [1:06:00]

The Impossible Burger

- [Pat Brown](https://en.wikipedia.org/wiki/Patrick_O._Brown) is the founder of [Impossible Foods](https://en.wikipedia.org/wiki/Impossible_Foods)
- Pat is a prominent scientist who actually was one of Peter’s professors in med school
- The Impossible Burger is a GMO, soy-based product
  - (Not to be confused with another company called Beyond Meat which is pea-based “meat”)

**Impossible burger vs. regeneratively raised beef burger vs. factory farmed burger**

- [Quantis did an analysis](https://quantis-intl.com/heres-how-the-footprint-of-the-plant-based-impossible-burger-compares-to-beef/) looking at the impossible burger compared to regeneratively raised beef burger
  - The impossible burger was far better than a conventional factory farm burger, but it **added three and a half kilos of carbon** for every burger you ate
  - The factory farmed burger **added about 50 kilos of carbon**
  - But Mark says that for a *regeneratively raised burger…* all the inputs **took out three and a half kilos of carbon**

> “But still, it’s not the only answer when you think about scaling up impossible burgers on a GMO monocrop soy field using tons of glyphosate, which has all sorts of harmful consequences causing soil erosion, the way it’s farmed, damaging the waterways, damaging everything. I mean, it doesn’t even add up. Right. So let’s do it right.”

## GMO and Roundup—The potential health risks of consuming GMO foods sprayed with Roundup (glyphosate) and other herbicides and pesticides [1:08:15]

-GMO stands for “Genetically modified organism”

-For some context, there are 4 things that matter when growing food…

1. Yield
2. Product profile
3. Harvestability
4. Crop protection

- GMO falls under the category of crop protection
- Many crops, corn for example, can be genetically modified so that they are resistant to the effects of glyphosate (Roundup) which is an herbicide (weed-killer)
- That way, the plants will survive getting sprayed but the weeds will die

**Why might GMOs be problematic?**

**-First**, it MIGHT be harmful to be eating an organism that now has a gene that looks different from the gene that we evolved to consume it.

- In other words, it now makes different proteins that it didn’t make that are foreign.
- Mark says, “food is information. So how is that different information affecting your biology and how’s it regulating the different body functions? I don’t think we know much about that.”
- The USDA and the National Association of Scientists actually tell us that GMO is safe and that we can feel free to consume it liberally
- **Mark, however, cautions**: “*First is it’s a large uncontrolled experiment on humanity. Just like Crisco was invented in 1911 as this great new invention was in our food supply for, I don’t know, 80 or 90 years more before people were like, wait a minute, this isn’t good for us. It’s killing hundreds of thousands of people a year. Let’s get it out. So we don’t know. I think there’s animal studies that looks concerning. There’s various issues.*”

**-Secondly**, it enables the use of chemicals (e.g., RoundUp/glyphosate) in a higher concentration than you would be able to use them in the absence of genetic modifications to the plant

- In other words, the food is getting exposed to Roundup (glyphosate) and it may be harmful for people to be consuming that
- Mark sees this point as the *bigger problem*

**How harmful is it to consume glyphosate?**

- The weeds are increasingly mutating to be resistant to these substances.
- So you need **more pesticides and more glyphosate to do the same job**
- Glyphosate is now ~70% of the agrochemicals used on the planet
- And it’s increasingly being linked to harmful human effects

-Peter pushes back, “***Do we [really] know this?***”

- Mark says…
- There’s [14,000 lawsuits](https://www.npr.org/2019/03/27/707439575/jury-awards-80-million-in-damages-in-roundup-weed-killer-cancer-trial) around glyphosate and there has been billion dollar settlements
- “*I think the effects on animal studies are really clear*”
  - [Link](https://www.nature.com/articles/s41598-019-42860-0)
  - [Link](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5972442/)
  - [The effect of glyphosate on potential pathogens and beneficial members of poultry microbiota in vitro.](https://www.ncbi.nlm.nih.gov/pubmed/23224412)

⇒ He recently read a [study on epigenetics and glyphosate](https://www.nature.com/articles/s41598-019-42860-0) where rats were affected in multiple ways including prostate disease and cancer

- Peter rebuts, “*But we’ve seen this before, Mark. I mean we’ve seen lots of things where in the lab they’re using doses that are significantly higher than the human exposure and/or laboratory animals behave differently than humans*.”
- Mark, “*Okay, fine. But are we willing to take that risk?*”

⇒ Another [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5972442/) where glyphosate disrupts the microbiome in significant ways in animals

- And in [one impossible burger there is 110 times the dose](https://www.momsacrossamerica.com/gmo_impossible_burger_positive_for_carcinogenic_glyphosate) that was used in the animal studies to totally disrupt the microbiome of the rats
- Peter rebuts, “*But do we know how bioavailable it is and how much it remains?*”
- Mark, “*Well, it’s on the food.*”

**The takeaway on glyphosate**:

- Peter wants to point out that while there is mounting evidence that glyphosate is dangerous, it is **not as clear** as the case of tobacco and lung cancer in terms of causality

–*Mark, however, prefers to take a precautionary approach*:

- **First**, there’s enough suggestion that this could be harmful through animal models and other things
  - He even did some self-testing through Great Plains Lab and found that he was on in the 50th percentile glyphosate in his urine ⇒ “I was shocked.”
  - “*I think most of us are sort of walking toxic dumps. And if you looked at average fat biopsy of a human that’s full of DDT, dioxin, pesticides, it’s like it’s pretty bad. So I think we are still in an uncontrolled experiment.*”
- **Secondly**, “If it was the only way to grow food, fine, we deal with the risks. It’s not, it’s not the best way. It’s not the most effective way and there is potential risk and there’s real concern about our industrial agricultural system on the earth.”

⇒ Check out [Great Plains Lab](https://www.greatplainslaboratory.com/glyphosate-test) for self testing glyphosate levels

## How the livelihood of farmers are being affected by big ag companies and the current industrial farming system [1:16:30]

- Many farmers are getting squeezed by these big ag companies that are coming in and saying they’re going to improve their livelihood, but then forcing them to buy their seed, force them to buy their chemicals and
- There’s [increasing suicides](https://time.com/5736789/small-american-farmers-debt-crisis-extinction/) and terrible economic consequences from these farmers around the world because they’re not able to maintain a livelihood doing what they’re doing

⇒ Time magazine article: [The Newest Audience for Democrats’ Climate Change Plans: Iowa Farmers](https://time.com/5649768/climate-change-iowa-democrats-farmers/)

- Farmers desire to try regenerative ag “*not because they’re hippies who want to go back to the land. It’s happening just from an economic imperative.*”

*Do farmers feel captive now to Monsanto and Pioneer and these other companies?*

- They do. They have a system and they don’t have a way to get out of it. So they’re in a vicious cycle. They’ve got all this capital in their equipment, they’re stuck in this vicious cycle of growing the same crops and they have no way out.
- So we do need a bridge for these people and we do need mechanisms through government and private equity and others to actually help fund the transition.

⇒ The [UN estimated](https://www.bloomberg.com/news/articles/2019-10-23/how-to-halt-global-warming-for-300-billion) that $300 billion could solve the problem of climate change and give us 20 years more runway to solve the bigger issues.

## The loss of biodiversity in our food, and what “organic” really means [1:19:00]

**Some alarming stats about biodiversity**:

- We’ve [lost 90%](https://www.fao.org/3/y5609e/y5609e02.htm) of our edible plant species
- Basically 60% of our calories comes from corn and wheat and rice and soy and mostly from 12 species
- We’ve lost [half our livestock species](https://www.fao.org/3/y5609e/y5609e02.htm)
- There’s a lot of weird animals all over the place and you travel to the foreign countries, you see these weird cows and weird pigs and weird goats and they all look different and now they’re all the same that we produce in this country.
- We have lost [75% of our pollinator species](https://go.skimresources.com/?id=38395X1559467&isjs=1&jv=13.26.4-stackpath&sref=https%3A%2F%2Fwww.huffpost.com%2Fentry%2Fthe-hidden-costs-of-food_b_11492520&url=http%3A%2F%2Fwww.springer.com%2Fcda%2Fcontent%2Fdocument%2Fcda_downloaddocument%2F9789400777958-c1.pdf%3FSGWID%3D0-0-45-1451709-p175484893&xguid=654b684dd59a76f308b53e16c08aaba3&xs=1&xtz=360&xuuid=ceb036355afd49a1fc9882a0dee058d9) (e.g., bees) on which are agriculture depends
  - Butterflies, pollinators, all damaged also by these pesticides and chemicals that are indiscriminate in what they kill

*-Chemicals killing the soil:* The chemicals that we use in the soil and the farming methods we use is destroying the soil which is an incredible diverse ecosystem: mycorrhizal fungi, the bacteria, the nematodes, the worms, all these different animals that live in the soil that are necessary to actually create food and to create sustainable agriculture.

> “And so I think we’re sort of asleep to the idea that we’re sort of running out of soil. We’re running out of these bio-diverse animals that are essential for our health and our survival.”

*-What can we do to bring back biodiversity?*

- As he wrote about in Food Fix, it’s about…
  - Individual choices
  - business innovations
  - Policy

**What does organic mean?**

- Organic is a certification that’s delivered by the government which means no antibiotics, no pesticides, no herbicides
- **However**, it doesn’t certify the *method* of growing the food
- In Michael Pollan’s book, [Omnivore’s Dilemma](https://www.amazon.com/Omnivores-Dilemma-Natural-History-Meals/dp/0143038583), he talked about how “industrial organic” is better than industrial farming, but it’s not fully regenerative
- **Regenerative** is the method of farming that actually includes organic but goes beyond it

⇒ There is now a [proposal to create a regenerative organic certification](https://regenorganic.org/pilot/) which may eventually be turned into a food label

**The Environmental Working Group has a really great guide called, [The Dirty Dozen and The Clean 15](https://www.produceretailer.com/article/news-article/2019-dirty-dozen-and-clean-15-lists-released)**

![](https://peterattiamd.com/wp-content/uploads/2020/02/dirty-dozen-markhyman.png)

**Figure 1. Dirty dozen.**

![](https://peterattiamd.com/wp-content/uploads/2020/02/clean-15-markhyman.png)

**Figure 2. Clean 15**

**What about organic meat?**

- Organic meat generally means no hormones or antibiotics were used AND that it’s not using the chemical inputs on the corn fed to the animals
- However, organic doesn’t necessarily mean that the animals weren’t fed “orangic” food that is grown in ways that are destroying the soil
- That’s why **regenerative is sort of organic plus**
- Unfortunately, there isn’t a “regenerative” label put on food like they have the “organic label”
- There are places, like [Mariposa Ranch in California](https://mariposaranchmeats.com/), where you can buy half a cow with a bunch of friends and it’s eight bucks a pound, which for a four ounce serving is less than you pay for McDonald’s hamburger, so you can, with a little ingenuity and effort, you can actually start to sort of find how to get these things.
- The demand for this type of thing is going to increase
  - For example, [General Mills](https://www.generalmills.com/en/Responsibility/Sustainability/Regenerative-agriculture), Danone, Nestle, and [Pepsi](https://www.pepsico.com/docs/album/sustainability-report/2018-csr/pepsico_2018_csr.pdf) even are looking at how to make their supply chain to be more regenerative

## What can people do on the individual level to protect themselves as well as affect change to the toxic food system? [1:25:00]

**Things people can do**:

- Being really focused on **what** you eat and **where** it comes from
- Buy from a local farmer’s market
- Joining a community support that supports agriculture
- Looking for regenerative sources online
- Bulk buying things together with friends
- Maybe you should have a compost pile
- Make a compost box (They have them on Amazon. You can buy them and have them shipped to you)
- You might consider being politically active…
  - You can go in your municipality and say to your local government and say “let’s have a composting law”
  - You can push for creating economic incentives related to food waste

*Resources for this?*

- Many resources will be featured in Mark upcoming book, [Food Fix](https://foodfixbook.com/)
- Mark has a video called [5 Steps to Seal the Planet and Your Health](https://foodfixbook.com/claim-your-free-gifts/)
- The [Food Policy Action Group](https://foodpolicyaction.org/) rates your senators and congressmen on their voting records on food and ag policy.

**More about food waste**:

- Many dairy farmers are making less money and struggling.
- One dairy farmer created these anaerobic digesters which gets food waste every week from grocery stores, mix it with the manure from the animals, and this “digester” combusts and produces electricity for 1,500 homes and makes the farmer an extra a hundred grand a year

–*This is important because…*

- Food waste is an incredible problem
- [30 or 40%](https://www.fao.org/news/story/en/item/262504/icode/%20/) of all food producers wasted
- The average family throws out about a pound a day or about [$1,800 a year of food](https://www.pennlive.com/news/2020/01/penn-state-study-finds-average-household-throws-away-30-percent-of-food-it-buys.html)
- This much food in a landfill would create greenhouse gases that would be the [third largest emitter of greenhouse gases](https://www.ncbi.nlm.nih.gov/pubmed/24927583) (after the US and China)

⇒ The Trump Administration has already created a [food waste initiative](https://www.usda.gov/media/press-releases/2018/10/18/trump-administration-launches-winning-reducing-food-waste) where the EPA, FDA, and the USDA are going to actually deal with the food waste issue

## What role does the USDA play in this “toxic” food environment and how do we fix it? [1:30:15]

At the high level, the USDA is responsible for a number of different food and ag policies that are “messed up”:

- Our dietary guidelines
- Our school lunch guidelines
- [SNAP](https://en.wikipedia.org/wiki/Supplemental_Nutrition_Assistance_Program) program (aka Food stamp program)
  - 75 billion a year
  - Feeds 46 million Americans (1 in 4 kids)
  - $7 billion a year just in soda (about 30 billion servings a year)
  - There’s no nutritional guidelines
  - In fact, you can buy anything except **alcohol** and **cooked food**
  - So you can buy a two liter bottle of soda, but you can’t buy a rotisserie chicken in the grocery store!
  - [75% of the food stamps goes towards junk food or soda](https://www.npr.org/sections/thesalt/2018/10/29/659634119/food-stamps-for-soda-time-to-end-billion-dollar-subsidy-for-sugary-drinks)!

–*Then you have* ***crop insurance*** *and* ***agricultural supports*** *that support harmful a industrial agricultural system*

- For example, if you have a big soy and corn farm and you want to grow a whole bunch of veggies, you can’t, even if you want to because you will get penalized and not get your crop insurance
- So farmers are *disincentivized* from growing fruits and vegetables
- The gov is simultaneously telling us to eat half our food as fruit and veggies yet less than half a percent of agricultural supports from the government are for fruits and vegetables

> “The government tells us on the one hand, eat half of our plate as fruits and vegetables, but less than half a percent of agricultural supports from the government are for fruits and vegetables. It’s like basically if we were eating what the government actually funded in agricultural supports, we’d be having a giant corn fritter, deep fried in soybean oil. And it’s like, that’s not exactly what we should be eating.”

**-The FDA**

- The FDA that has confusing food labels or that allows antibiotics in our animal feed
- It allows substances that are banned in other countries that are toxic to be in our food supply
  - Example being [azodicarbonamide](https://en.wikipedia.org/wiki/Azodicarbonamide), which is basically a softener for flour products for bread
    - In Singapore, you get a $450,000 fine and you go to jail for 15 years for using azodicarbonamide

**-The FTC**, which regulates the airwaves, allows all this unrestricted marketing to kids

**What do we need to do to address this?**

- We need a national food policy
- We need activism to change some of these food policies
- We need support for regenerative ag
- We need to reform food stamps and school lunches
- And we need to help advance the health care system to promote “food is medicine.”

*Why Mark is hopeful…*

- All of these things can be done, says Mark
- Mark’s working with people to launch a nonprofit and an advocacy group to start to work on these issues in Washington.
- And I think there are a lot of these issues are bipartisan issues.
- There’s a movement and a readiness around the country and even in Washington to address these issues.
- Big food companies like [Nestle](https://www.nestle.com/csv/impact/tastier-healthier/sugar-salt-fat), Danone, Unilever, [General Mills](https://www.generalmills.com/en/Responsibility/Sustainability/Regenerative-agriculture) are actually starting to take on these issues.

> “But I do see room for hope. I see business innovations, food and ag tech companies, billions and billions are flowing into these areas for innovation, which is all a good thing.”

## The top 3 changes Mark would make if he was “food czar” [1:35:15]

1 | Immediately transform healthcare reimbursement to focus on **food as medicine** through paying for food

- Reimbursing fruit and vegetable prescriptions
- Making food a central part of the government such as having them only purchase food that is going to promote health and not disease

2 | Reform these dysfunctional food policies

- Transform SNAP
- Transform school lunches
- Transform the dietary guidelines to be science-based

3 | Support regenerative ag in every way possible

- Through government policies
- Business innovations
- Economic incentives

## Mark’s rebuttal against the argument that it’s best for the environment if stop farming animals and move to a fully plant-based diet (and his argument for “agriculture 2.0”) [1:36:30]

**Is plant-based diets the best for the climate?**

- Some people argue that we need to completely get rid of factory farming animals

-Recently published was the [EAT-Lancet Report](https://www.thelancet.com/pdfs/journals/lancet/PIIS0140-6736(18)31788-4.pdf?utm_campaign=tleat19&utm_source=HubPage)

- A very well intentioned report with plenty of good science in it
- It discussed how we link climate and diet and food
- In the report that suggested solutions such as…
  - Needing to grow more plants, more grains and more beans
  - And use a process called “sustainable intensification” or “climate-smart agriculture”
- Mark says, “these are just buzz words”
- But when you look behind the curtain, who funds those organizations?
- 60% of the members of climate-smart agriculture are the **fertilizer companies**
- *Sustainable intensification* means using more and more chemical inputs on farms in developing world to grow more grains and beans. ⇒ “*That’s not the solution.*”

**We need animals for the soil (even if you don’t eat them)**

- Without animals integrated into regenerative agricultural systems, you cannot restore soil in the way we need to restore it as fast as we need to restore it
- Pooping, peeing, digging, and even their saliva makes the plants grow
- With proper management (aka holistic management, or managed grazing, or adaptive multi-paddock grazing)… “*you can dramatically increase soil”*, says Mark
- Some say it takes a thousand years to get three centimeters of soil naturally
- But [Gabe Brown](https://brownsranch.us/welcome/) in North Dakota got 29 inches of soil just through these methods that are sort of “**supercharged”** methods

**We need Agriculture 2.0**

- “*It’s not about going back to old ways, it’s about inventing new ways, using all the science to actually grow soil.*”
- Most of human history we were destructive ⇒ We would grow food on land and we’d deplete the land the move to the next plot of land

> “The problem now is we’re running out of land. There’s no more place to go. So I think we absolutely need to actually scale this regenerative agriculture model in order to solve all these global issues.”

*-Can regenerative ag be superimposed on* [*fallow land*](https://www.yourdictionary.com/fallow)*?*

- Yes, says Mark
- People are basically taking degraded land, which is almost desert and turning it back into lush fields and lush agricultural practices.
- So when those people say we have to be vegan to save the planet, it’s actually not accurate.
- Whether or not you believe in eating meat, from an environmental or a climate standpoint, we must have animals integrated into the process in order to restore soil, which is the biggest carbon sink.

**Take home message**:

“*There are a lot of ways to fix climate change, but the quickest, fastest, and most effective and scalable way is using an ancient carbon capture technology . . . is free. It’s called photosynthesis. It’s basically sun and carbon dioxide in the air. We can solve a lot of the global issues that we have.*”

## What is Mark’s overall mission with the work that he’s doing? [1:40:30]

-Mark wears many hats

-But he summarizes his high-level goal as follows:

“*I’m trying to end the suffering through the power of functional medicine, systems thinking, and sort of restoring communities and behavioral change through that. And this is just part of that story. Like I said, there’s so much suffering that’s unnecessary, whether it’s chronic disease or poverty or mental illness or kids struggling with learning in schools or violence. These are all needless suffering.*

*If we have the solutions, then we need to focus on them. . .and unless we deal with the systems issues, unless we go upstream, we’re just going to be treading water or bailing a sinking boat. And the acceleration of these problems is so big that I feel like I’m focusing more and more on these bigger issues in order to solve them.*

*At the end of the day, this is an existential threat and once you’ve seen it, you can’t unsee it. I just was researching the book for the last two and a half years. I was shocked by a lot of things that I learned that are not really common knowledge and even when the really educated people.*

*If I go into a room of highly educated people and say, what’s the number one source of climate change? They’re not going to say food, but when you actually unpack it, that’s the biggest threat*.”

## Bread in the US vs. Europe: Why does bread (and wheat products) taste different and potentially cause less health problems in Europe versus the US? [1:42:00]

*Peter recently made an observation while in Europe*:

- The bread, the pasta, and much of the food that he ate in Europe did not seem to produce the same negative effect as those same foods in America
- Peter made the same observation about breads and pitas in Egypt compared to the middle Eastern bread here in the US… “it tastes very different”

*What might explain this?*

-Mark says that it’s a complex web of factors

1 | In the US, we’ve hybridized the wheat to make it extremely drought resistant and hardy and it’s called **dwarf wheat**

- And the guy who invented it, [Norman Borlaug](https://en.wikipedia.org/wiki/Norman_Borlaug), won the Nobel prize because it increases yields
- However, there is a “super starch” in there called **amylopectin** A
  - It [raises your blood sugar](https://www.ncbi.nlm.nih.gov/pubmed/7782895) more than regular sugar

2 | The way we breed plant creates **gliadin proteins**

- There’s extra proteins that are formed such as [gliadin proteins which are inflammatory](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3705319/) and more active in terms of causing disruptions in the gut (i.e., more likely to cause leaky gut)

3 | In the US, **we spray wheat with glyphosate at harvest** (even though it’s not a GMO)

- - Doing this de-foliates the plants and gets rid of all the leaves and stuff so it makes it easier to harvest.
  - Your [Cheerios have more glyphosate than vitamin A and vitamin D](https://www.ewg.org/release/tests-reveal-more-weed-killer-some-vitamins-kids-cereals) in their per amount of weight
- *What about “organic” wheat?*
- - Organic wheat is not sprayed with glyphosate
  - However, it could still be the dwarf wheat

4 | **Calcium procreate**

- This is a preservative which is added to the wheat in US
- It’s known to cause toxic neurological effects, behavioral hyperactivity, and has been linked to autism (at least in animal models like [this](https://www.ncbi.nlm.nih.gov/pubmed/20405543/) and [this](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5814017/))

5 | **Quick rising** bread in the US

- In the US, our breads rise in a couple hours
- In Europe, it can take 12 hours to 14 hours
- It tastes very different and it’s a very different structure
- It does different things to the gluten

6 | There’s **no GMO** in Europe

**Can one make bread here in the US on their own using wheat, like an actual wheat that comes from Europe?**

- Sure you could, says Mark

-Better wheats include:

- Heirloom wheats
- Einkorn wheat
- There’s a new forms of wheat being developed:
  - One is [Kernza grain](https://landinstitute.org/our-work/perennial-crops/kernza/) by The Land Institute
    - It has incredibly deep roots, it’s a perennial wheat, it’s super nutrient dense, “really amazing, amazing product”
  - Another is Himalayan buckwheat
    - Apparently it is one of the most protein rich, low-glycemic, phytochemical dense hardy super foods on the planet

> “So there’s a lot of stuff out there that we could use that’s much better for us, but we just kind of homogenized our food supply . . .And our bodies need all those different phytochemicals and nutrients and minerals and vitamins to actually run itself. And we’re now just in this sort of nutrient devoid diet. Even if we’re eating organic stuff, if it’s not grown in good soils, if it’s hybridized plants, it’s just not great.”

§

## Selected Links / Related Material

**Mark is the Director of the**: [Cleveland Clinic Center for Functional Medicine](https://my.clevelandclinic.org/departments/functional-medicine) | (clevelandclinic.org) [00:50]

**Mark’s new book**: [Food Fix: How to Save Our Health, Our Economy, Our Communities, and Our Planet—One Bite at a Time](https://foodfixbook.com/) by Mark Hyman | (foodfixbook.com) [1:00, 53:45, 1:21:00, 1:25:20]

**11 million people that die every year from eating ultra processed food**: [One in five deaths worldwide linked to unhealthy diet](https://www.reuters.com/article/us-health-diet/one-in-five-deaths-worldwide-linked-to-unhealthy-diet-idUSKCN1RF2SV) | Kate Kelland (reuters.com) [5:00]

**One third of all Medicare expenses are for diabetes alone**: [How Much Does Medicare Spend on Insulin?](https://www.kff.org/medicare/issue-brief/how-much-does-medicare-spend-on-insulin/) | Juliette Cubanski et al., 2019 (kff.org) [6:50]

**One third of all of our federal budget is Medicare**: [Federal Spending: Where Does the Money Go](https://www.nationalpriorities.org/budget-basics/federal-budget-101/spending/) | (nationalpriorities.org) [6:50]

**70% of military recruits are unfit to fight and they are rejected**: [Pentagon: 7 in 10 Youths Would Fail to Qualify for Military Service](https://time.com/2938158/youth-fail-to-qualify-military-service/) | NOLAN FEENEY (time.com) [8:00]

**The UN estimates that within a decade or few decades we’re going to have up to a billion climate refugees**: [Climate Migrants Might Reach One Billion by 2050](https://www.ipsnews.net/2017/08/climate-migrants-might-reach-one-billion-by-2050/) | Baher Kamal (ipsnews.net) [8:15]

**Food is Medicine working group in Congress**: [Bipartisan nutrition group kicks off in House](https://www.politico.com/story/2018/01/22/bipartisan-nutrition-group-kicks-off-in-house-354850) | HELENA BOTTEMILLER EVICH (politico.com) [10:30]

**Article about the Nepalese honey hunters having to climb up a hundred feet in the trees**: [he Last Death-Defying Honey Hunter of Nepal](https://www.nationalgeographic.com/magazine/2017/07/honey-hunters-bees-climbing-nepal/) | Mark Synnott (nationalgeographic.com) [11:45]

**Study suggest that for every 10% of your calories that’s ultra processed food, your risk of death goes up by 14%**: [Association Between Ultraprocessed Food Consumption and Risk of Mortality Among Middle-aged Adults in France](https://www.ncbi.nlm.nih.gov/pubmed/30742202) (Schnabel et al., 2019) [12:30]

**Condition that sometimes leads to kids eating dirt due to an iron deficiency**: [Pica](https://familydoctor.org/condition/pica/) | (wikipedia.org) [14:15]

**David Perlmutter’s upcoming book talks about how the prefrontal cortex and the amygdala are uncoupled when a diet is producing inflammation**: [Brain Wash: Detox Your Mind for Clearer Thinking, Deeper Relationships, and Lasting Happiness](https://www.amazon.com/Brain-Wash-Thinking-Relationships-Happiness/dp/0316453323/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by David Perlmutter | (amazon.com) [16:00]

**The nature of eating sugar and processed food drives up inflammation because insulin drives  visceral belly fat “which is a basically metabolic fire that starts in these cells and it spreads inflammation throughout the body”, so just the nature of eating sugar and processed food drives up inflammation**: [Chronic Inflammation in Obesity and the Metabolic Syndrome](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2913796/) (Rosário Monteiro  and Isabel Azevedo, 2010) [17:15]

**Mark says the Buck Institute of Aging is developing new panels that are much more specific and much more sensitive and it enabled us to really look at the inflammatory response that’s happening in the body related to aging or diet**: [Campisi Lab](https://www.buckinstitute.org/lab/campisi-lab/) | (buckinstitute.org) [18:00]

**A phenomenon called metabolic endotoxemia can possibly be fixed via the gut microbiome**: [The spectacular role of the human microbiome in preventing metabolic endotoxemia, the number one cause of mortality worldwide](https://restorativemedicine.org//wp-content/uploads/2017/09/Krishnan_Metabolic-Endotoxemia.pdf) | Kiran Krishnan (restorativemedicine.org) [19:30]

**It possible to take the poop out of a skinny rat and put it into a fat rat and make them skinny (and vice versa)**: [Prolonged transfer of feces from the lean mice modulates gut microbiota in obese mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4995824/) (Kulecka et al., 2016)  [19:30]

**Glyphosate is super toxic to the microbiome**: [20:30]

- [The effect of glyphosate on potential pathogens and beneficial members of poultry microbiota in vitro.](https://www.ncbi.nlm.nih.gov/pubmed/23224412) (Shehata et al., 2013)
- [Glyphosate based- herbicide exposure affects gut microbiota, anxiety and depression-like behaviors in mice](https://www.sciencedirect.com/science/article/abs/pii/S0892036218300254) (Aitbali et al., 2018)
- [Glyphosate and cancer risk](https://www.ncbi.nlm.nih.gov/pubmed/30060078)

**60% of your immune system is in your gut maybe this will do**: [Allergy and the gastrointestinal system](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2515351/) (Vighi et al., 2008) [20:30]

**Cleveland Clinic got a $12 million grant from the NIH to study the microbiome and heart disease**: [NIH Awards Cleveland Clinic $12 Million to Study Link Between Gut Microbes, Heart Disease](https://newsroom.clevelandclinic.org/2019/11/19/nih-awards-cleveland-clinic-12-million-to-study-link-between-gut-microbes-heart-disease/) | (clevelandclinic.org) [22:30]

**An anti-parasitic medication that can sometimes be used to resolve stomach issues from bacterial overgrowth**: [Alinea](https://www.rxlist.com/alinia-drug.htm#description) | (rxlist.com) [25:45]

**6 out of 10 Americans have a chronic disease, 4 out of 10 have two or more**: [Chronic Diseases in America](https://www.cdc.gov/chronicdisease/resources/infographic/chronic-diseases.htm) | (cdc.gov)  [27:20]

**One in two Americans has prediabetes or type two diabetes**: [Diabetes and Prediabetes](https://www.cdc.gov/chronicdisease/resources/publications/factsheets/diabetes-prediabetes.htm) | (cdc.gov) [27:20]

**75% of Americans are overweight and most states now have 40% obesity rates**: [National Center for Health Statistics: Obesity and Overweight](https://www.cdc.gov/nchs/fastats/obesity-overweight.htm) | (cdc.gov) [27:30]

**Data about the prevalence of type 2 diabetes in different racial groups**: [Racial and Ethnic Disparities in Prevalence and Care of Patients With Type 2 Diabetes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5241767/) (José E. Rodríguez and Kendall M. Campbell, 2017) [28:15]

**South Asians are at a susceptible to get metabolic syndrome even at lower body weights**: [#69 – Ronesh Sinha, M.D.: Insights into the manifestation of metabolic disease in a patient population predisposed to metabolic syndrome, and what it teaches us more broadly](https://peterattiamd.com/roneshsinha/) | Peter Attia (peterattiamd.com) [28:15]

**80% of the world’s type 2 diabetics is found in the developing world**: [Is Diabetes Becoming the Biggest Epidemic of the Twenty-first Century?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3068646/) (Syed Amin Tabish, 2007) [28:30]

**Chile’s regulatory actions in response to the massive obesity rates and kids and adults and staggering healthcare cost**: [Chile Battles Obesity With Stop Signs On Packaged Foods](https://www.npr.org/sections/thesalt/2016/08/12/486898630/chile-battles-obesity-with-stop-signs-on-packaged-foods) | Eileen Smith (npr.org) [29:00]

- *The 18% soda tax*: [Evaluating the 2014 sugar-sweetened beverage tax in Chile: An observational study in urban areas](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6029775/)
- *They put on warning labels on bad food*: [Chile Battles Obesity With Stop Signs On Packaged Foods](https://www.npr.org/sections/thesalt/2016/08/12/486898630/chile-battles-obesity-with-stop-signs-on-packaged-foods) | Eileen Smith (npr.org)
- *They eliminated cartoon characters from all the kids food promotions*: [In Sweeping War on Obesity, Chile Slays Tony the Tiger | Andrew Jacobs](https://www.nytimes.com/2018/02/07/health/obesity-chile-sugar-regulations.html) (nytimes.com)
- [Chile’s law](https://www.leychile.cl/Navegar?idNorma=1041570) | (leychile.cl)

**Percentage of US adults that smoke cigarettes is ~16%**: [Current Cigarette Smoking Among Adults in the United States](https://www.cdc.gov/tobacco/data_statistics/fact_sheets/adult_data/cig_smoking/) | (CDC.gov) [32:00]

**1989 was also a big step when secondhand smoking became well enough understood that they banned tobacco in airplanes**: [Inflight Smoking](https://en.wikipedia.org/wiki/Inflight_smoking) | (wikipedia.org)  [34:00]

**Soda taxes in California passed in 2016**: [Three years into soda tax, sugary drink consumption down more than 50 percent in Berkeley](https://news.berkeley.edu/2019/02/21/three-years-into-soda-tax-sugary-drink-consumption-down-more-than-50-percent-in-berkeley/) | Kara Manke (berkley.edu) [34:15]

**The behind the scenes deal between Governor Jerry Brown of California and the sugar industry where they “completely co-opted the government and pressured them to do something that they didn’t want to do”**: [California, of All Places, Has Banned Soda Taxes. How a New Industry Strategy Is Succeeding.](https://www.nytimes.com/2018/06/27/upshot/california-banning-soda-taxes-a-new-industry-strategy-is-stunning-some-lawmakers.html) | Anahad O’Connor and Margo Sanger-Katz (nytimes.com) [35:30]

**The failed initiative by the sugar/soda industry that did sham science to try to push their agenda**: [Global Energy Balance Network, GEBN](https://en.wikipedia.org/wiki/Global_Energy_Balance_Network) | (wikipedia.org) [36:15]

**NY Times article that exposing GEBN for what the sham that it was**: [Coca-Cola Funds Scientists Who Shift Blame for Obesity Away From Bad Diets](https://well.blogs.nytimes.com/2015/08/09/coca-cola-funds-scientists-who-shift-blame-for-obesity-away-from-bad-diets/) | Anahad O’Connor (nytimes.com) [36:15]

**Scientist James Hill was a legitimate scientist but completely “co-opted” by the soda industry and was paid to run studies for GEBN that showed soda wasn’t bad**: [37:00]

- [CU nutrition expert accepts $550,000 from Coca-Cola for obesity campaign](https://www.denverpost.com/2015/12/26/cu-nutrition-expert-accepts-550000-from-coca-cola-for-obesity-campaign/) | David Olinger (denverpost.com)
- [Emails Reveal Coke’s Role in Anti-Obesity Group](https://apnews.com/1fd235360ac94dcf893a87e3074a03a5/apnewsbreak-emails-reveal-cokes-role-anti-obesity-group) | CANDICE CHOI (apnews.com)

**NY Times article noting the disbanding of GEBN**: [Research Group Funded by Coca-Cola to Disband](https://well.blogs.nytimes.com/2015/12/01/research-group-funded-by-coca-cola-to-disband/) | Anahad O’Connor (nytimes.com) [37:30]

**General Mills will commit a million acres to regenerative ag**: [Regenerative Agriculture](https://www.generalmills.com/en/Responsibility/Sustainability/Regenerative-agriculture) | (generalmills.com) [40:30, 1:24:45]

**Nestle reformulating their products to be healthier**: [Reducing sugars, sodium and fat](https://www.nestle.com/csv/impact/tastier-healthier/sugar-salt-fat) | (nestle.com) [40:30]

**UN estimates that we could take 2 million degraded hectares of land around the world and using regenerative agriculture to restore the soil, we could stop climate change and delay that progression for about 20 years and it would cost $300 billion**: [How to Halt Global Warming for $300 Billion](https://www.bloomberg.com/news/articles/2019-10-23/how-to-halt-global-warming-for-300-billion) | By Adam Majendie and Pratik Parija (bloomberg.com) [44:00]

**Every 1% organic matter can hold ~27,000 gallons of water**: [Soil Health Key Points](https://www.nrcs.usda.gov/Internet/FSE_DOCUMENTS/stelprdb1082147.pdf) | (nrcs.usda.gov) [45:15]

**There is ~50% less nutrient density and minerals in food compared to 50 years ago**: [A study on the mineral depletion of the foods available to us as a nation over the period 1940 to 1991.](https://www.ncbi.nlm.nih.gov/pubmed/14653505) (Thomas D., 2003) [47:45]

- *Another source*: [Declining Fruit and Vegetable Nutrient Composition: What Is the Evidence?](https://journals.ashs.org/hortsci/view/journals/hortsci/44/1/article-p15.xml) (Donald R. Davis, 2009)
- *Another another*: [As CO2 levels climb, millions at risk of nutritional deficiencies](https://www.sciencedaily.com/releases/2018/08/180827180806.htm) (sciencedaily.com)

**Fertilizer companies today use more natural gas than Exxon**: [Emissions impossible: How big meat and dairy are heating up the planet](https://www.grain.org/article/entries/5976-emissions-impossible-how-big-meat) | by GRAIN and the Institute for Agriculture and Trade Policy (IATP) | 18 Jul 2018 (grain.org) [48:30]

**Ohio methane leak that you could see from space**: [49:00]

- [A blowout turned an Ohio natural gas well into a methane ‘super-emitter’](https://www.washingtonpost.com/climate-environment/a-blowout-turned-an-ohio-gas-well-into-a-methane-super-emitter/2019/12/16/fcbdf622-1f9e-11ea-bed5-880264cc91a9_story.html) | Steven Mufson (washingtonpost.com)
- [A methane leak, seen from space, Proves to Be Far Larger Than Thought](https://www.nytimes.com/2019/12/16/climate/methane-leak-satellite.html) | Hiroko Tabuchi  (nytimes.com)

**One fifth of all our oil consumption is for the food system—more than all cars, planes, boats, transportation combined**: [Energy Use in the U.S. Food System](https://web.mit.edu/dusp/dusp_extension_unsec/reports/polenske_ag_energy.pdf) | Patrick Canning, Ainsley Charles, Sonya Huang, Karen R. Polenske, and Arnold Waters (mit.edu)  [49:30]

**Gabe Brown is a North Dakota farmer with a 5,000 acre farm devastated by hail and weather, and was about to go bankrupt then used regenerative agriculture build 29 inches of soil**: [Brown’s Ranch](https://brownsranch.us/) | (brownsranch.us) [54:30, 1:00:40, 1:38:45]

**Fertilizer put in soil damages the soil and releases nitrous oxide which is 300 times more potent than the greenhouse gas carbon dioxide**: [Global metaanalysis of the nonlinear response of soil nitrous oxide (N2O) emissions to fertilizer nitrogen.](https://www.ncbi.nlm.nih.gov/pubmed/24927583) (Shcherbak et al., 2014) [55:45]

**it’s created dead zones and 400 areas around the world the size of Europe**: [Declining oxygen in the global ocean and coastal waters](https://science.sciencemag.org/content/359/6371/eaam7240) | Breitburg et al., 2018 (sciencemag.org) [56:00]

**A ocean dead zone the size of New Jersey in the Gulf of Mexico that kills** [**212,000 metric tons of fish**](https://www.scientificamerican.com/article/oceanic-dead-zones-spread/) **every year**: [Gulf of Mexico Dead Zone: Mitigating the Damage](https://gulfhypoxia.net/gulf-of-mexico-dead-zone-mitigating-the-damage/) | Chris Watts (gulfhypoxia.net) [56:00

**UN estimates we waste about 30 to 40% of food**: [New online platform fosters efforts to curb food losses through information sharing](https://www.fao.org/news/story/en/item/262504/icode/%20/) | (fao.org)  [57:45]

**This study estimates that the average family throws away $1,800 worth of uneaten food per year**: [Penn State study finds average household throws away 30 percent of food it buys](https://www.pennlive.com/news/2020/01/penn-state-study-finds-average-household-throws-away-30-percent-of-food-it-buys.html) | Rachel McDevitt (pennlive.com) [57:45]

**Trump administration just bailed out farmers for about $20 billion**: [Farmers Got Billions From Taxpayers In 2019, And Hardly Anyone Objected](https://www.npr.org/sections/thesalt/2019/12/31/790261705/farmers-got-billions-from-taxpayers-in-2019-and-hardly-anyone-objected) | Dan Charles (npr.org) [1:00:00]

**Groups working to push forward support for the transition to regenerative ag**: [1:01:00]

- [Kiss the Ground](https://kisstheground.com/)
- [Carbon Underground](https://thecarbonunderground.org/)

**A huge report called Climate Change and Land  that came out in August 2019**: [Climate Change and Land](https://www.ipcc.ch/site/assets/uploads/2019/08/4.-SPM_Approved_Microsite_FINAL.pdf) | (ipcc.ch) [1:01:00]

**Book that Mark describes as “*****a wonderful explanation of the top solutions that exist today that don’t need to be invented that can draw down carbon out of the environment*****”**: [Drawdown: The Most Comprehensive Plan Ever Proposed to Reverse Global Warming](https://www.amazon.com/Drawdown-Comprehensive-Proposed-Reverse-Warming/dp/0143130447/ref=sr_1_1?keywords=Drawdown&qid=1581437399&sr=8-1) by Paul Hawken | (amazon.com) [1:03:00]

**Paul Hawken’s next book is going to be called “Regeneration” and it’s about how we regenerate our health, regenerate the soil**: [Desiree Driesenaar via medium.com – 1/7/20](https://medium.com/@driesenaar/the-next-book-paul-hawken-is-working-on-will-be-called-regeneration-b650bcb774b2) | (medium.com) [1:03:15]

**It’s been estimated that we could draw down anywhere from 30% to a 100% of all the carbon that’s been released since the industrial revolution if regenerative ag can be scaled up**: [1:03:25]

- [Soil Carbon Sequestration Impacts on Global Climate Change and Food Security](https://science.sciencemag.org/content/304/5677/1623) (R. Lal, 2004)
- [Regenerative Organic Agriculture and Climate Change](https://rodaleinstitute.org/wp-content/uploads/rodale-white-paper.pdf) | (rodaleinstitute.org)

**Company that makes “burgers” out of a GMO, soy-based product**: [Impossible Foods](https://en.wikipedia.org/wiki/Impossible_Foods) | (wikipedia.org) [1:04:15]

**We take out of the earth about $125 trillion a year of resources in soil and everything else that we steal from the earth**: [Changes in the global value of ecosystem services](https://community-wealth.org/sites/clone.community-wealth.org/files/downloads/article-costanza-et-al.pdf) (Costanza et al., 2014) [1:04:50]

**Private equity company that’s buying up conventional farms and converting them to regenerative agriculture**: [Farmland LP](https://www.farmlandlp.com/) [1:05:15]

**Quantis did an analysis looking at the impossible burger compared to regeneratively raised beef burger**: [Here’s how the footprint of the plant-based Impossible Burger compares to beef](https://quantis-intl.com/heres-how-the-footprint-of-the-plant-based-impossible-burger-compares-to-beef/) | (quantis-intl.com) [1:06:45] #askmark

**The comparative analysis of agriculture in US versus Europe showed no difference in yields and far less use of pesticides and herbicides in the EU**: [U.S.-EU Food and Agriculture Comparisons](https://www.ers.usda.gov/webdocs/publications/40408/30650_wrs0404_002.pdf?v=0) | (usda.gov)  [1:12:30]

**Thousands of lawsuits against glyphosate with billions of dollars in settlements**: [Jury Awards $80 Million In Damages In Roundup Weed Killer Cancer Trial](https://www.npr.org/2019/03/27/707439575/jury-awards-80-million-in-damages-in-roundup-weed-killer-cancer-trial) | Richard Gonzales (npr.org) [1:13:30]

**Study on epigenetics and glyphosate where grand rats got prostate disease, cancer, and more**: [Assessment of Glyphosate Induced Epigenetic Transgenerational Inheritance of Pathologies and Sperm Epimutations: Generational Toxicology](https://www.nature.com/articles/s41598-019-42860-0) (Kubsad et al., 2019) [1:13:50]

**Other studies where glyphosate disrupts the microbiome in significant ways in animals**: [1:14:00]

- [The Ramazzini Institute 13-week pilot study on glyphosate and Roundup administered at human-equivalent dose to Sprague Dawley rats: effects on the microbiome](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5972442/) (Mao et al., 2018)
- [The effect of glyphosate on potential pathogens and beneficial members of poultry microbiota in vitro.](https://www.ncbi.nlm.nih.gov/pubmed/23224412) (Shehata et al., 2013)

**The dose that’s in one impossible burger is 110 times the dose that was used in the animal studies to totally disrupt the microbiome of the rats**: [GMO Impossible Burger Positive for Carcinogenic Glyphosate](https://www.momsacrossamerica.com/gmo_impossible_burger_positive_for_carcinogenic_glyphosate) | (momsacrossamerica.com) [1:14:00]

**Great Plains Lab has a test available where you can check your glyphosate levels**: [Glyphosate Test](https://www.greatplainslaboratory.com/glyphosate-test) | (greatplainslaboratory.com) [1:14:45]

**Increasing suicides and terrible economic consequences from these farmers around the world because they’re not able to maintain a livelihood doing what they’re doing**: [‘They’re Trying to Wipe Us Off the Map.’ Small American Farmers Are Nearing Extinction](https://time.com/5736789/small-american-farmers-debt-crisis-extinction/) | Alana Semuels (time.com) [1:16:45]

**Time article where emocratic candidates in Iowa spoke to farmers about their livelihoods being destroyed**: [The Newest Audience for Democrats’ Climate Change Plans: Iowa Farmers](https://time.com/5649768/climate-change-iowa-democrats-farmers/) | Justin Worland (time.com) [1:17:55]

**We’ve lost 90% of our edible plant species and half of all our livestock species**: [WHAT IS HAPPENING TO AGROBIODIVERSITY?](https://www.fao.org/3/y5609e/y5609e02.htm) | (fao.org)  [1:19:05]

**We have lost ~75% of our pollinator species on which are agriculture depends**: [1:19:30]

- [The environmental risks of neonicotinoid pesticides: a review of the evidence post 2013](https://link.springer.com/article/10.1007/s11356-017-9240-x) (Thomas James Wood and Dave Goulson, 2017)
- [The Hidden Costs Of Food](https://www.huffpost.com/entry/the-hidden-costs-of-food_b_11492520) | Peter Lehner (huffpost.com)

**About 500 billion people depend on these coral reefs for food**: [Coral Reefs](https://www.oceanhealthindex.org/methodology/components/coral-reefs-area) | (oceanhealthindex.org) [1:20:40]

**Book by Michael Pollan that discusses how “industrial organic” is better than industrial farming, but it’s not fully regenerative**: [The Omnivore’s Dilemma: A Natural History of Four Meals](https://www.amazon.com/Omnivores-Dilemma-Natural-History-Meals/dp/0143038583) by Michael Pollan | (amazon.com) [1:22:00]

**There is now a proposal to create a regenerative organic certification**: [ROC Pilot Program & Participants](https://regenorganic.org/pilot/) | (regenorganic.org) [1:22:15]

**Pesticide exposure in children may result in loss of IQ points**: [Prenatal Exposure to Organophosphate Pesticides and IQ in 7-Year-Old Children](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3237357/) (Bouchard et al., 2011) [1:22:30]

**The Dirty Dozen and The Clean 15 guide via The Environmental Working Group**: [2019 “Dirty Dozen” and “Clean 15” lists released](https://www.produceretailer.com/article/news-article/2019-dirty-dozen-and-clean-15-lists-released) | (produceretailer.com) [1:23:00]

**Where you can buy half a cow with a bunch of friends**: [Mariposa Ranch in California](https://mariposaranchmeats.com/) | (mariposaranchmeats.com) [1:24:30]

**Pepsi making strides towards more sustainable farming**: [Helping to build a more sustainable food system](https://www.pepsico.com/docs/album/sustainability-report/2018-csr/pepsico_2018_csr.pdf) | (pepsico.com) [1:24:45]

**Video of Mark explaining the five steps to heal the planet and yourself**: [5 Steps to Seal the Planet and Your Health](https://foodfixbook.com/claim-your-free-gifts/) | (foodfixbook.com) [1:25:30]

**The average family throws out about a pound a day or about $1,800 a year of food**: [Penn State study finds average household throws away 30 percent of food it buys](https://www.pennlive.com/news/2020/01/penn-state-study-finds-average-household-throws-away-30-percent-of-food-it-buys.html) | Rachel McDevitt (pennlive.com) [1:29:00]

**To fight food waste, the Trump Administration has created a food waste initiative**: [Trump Administration Launches “Winning on Reducing Food Waste” Initiative](https://www.usda.gov/media/press-releases/2018/10/18/trump-administration-launches-winning-reducing-food-waste) | (usda.gov) [1:29:30]

**Website that rates your senators and congressmen on their voting records on food and ag policy**: [Food Policy Action Group](https://foodpolicyaction.org/) | (foodpolicyaction.org) [1:30:00]

**75% of the food stamps (SNAP program) is junk food or soda**:  [Food Stamps For Soda: Time To End Billion-Dollar Subsidy For Sugary Drinks?](https://www.npr.org/sections/thesalt/2018/10/29/659634119/food-stamps-for-soda-time-to-end-billion-dollar-subsidy-for-sugary-drinks) | Allison Aubrey (npr.org) [1:31:00]

**70% of the military recruits unfit to fight**: [Pentagon: 7 in 10 Youths Would Fail to Qualify for Military Service](https://time.com/2938158/youth-fail-to-qualify-military-service/) | Nolan Feeney (time.com) [1:34:30]

**70% of the evacuations from Afghanistan and Iraq were not for war injuries, but we’re for obesity related injuries in the soldiers**: [Unhealthy and Unprepared](https://www.strongnation.org/articles/737-unhealthy-and-unprepared) | (strongnation.org) [1:34:30]

**The EAT-Lancet Report was well intentioned but Mark says it used “buzz words” and didn’t offer the best solution**: [Food in the Anthropocene: the EAT–Lancet Commission on healthy diets from sustainable food systems](https://www.thelancet.com/pdfs/journals/lancet/PIIS0140-6736(18)31788-4.pdf?utm_campaign=tleat19&utm_source=HubPage) (Willett et al., 2019) [1:37:15]

**Norman Borlaug won the Nobel prize for his part in developing methods to increase production of grains and breads**:

- [Norman Borlaug: The Researcher](https://borlaug.cfans.umn.edu/about-borlaug/researcher) | (borlaug.cfans.umn.edu) [1:43:40]
- [Norman Borlaug: Nobel Peace Prize](https://en.wikipedia.org/wiki/Norman_Borlaug#Nobel_Peace_Prize) | (wikipedia.org) [1:43:40]

**Wheat has gliadin proteins which are inflammatory and more active in terms of causing disruptions in the gut, so they’re more likely to cause leaky gut inflammation**: [The Dietary Intake of Wheat and other Cereal Grains and Their Role in Inflammation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3705319/) (Karin de Punder and Leo Pruimboom, 2013) [1:44:00]

**Cheerios have more glyphosate than vitamin A and vitamin D**: [Tests Reveal More Weed Killer Than Some Vitamins in Kids’ Cereals](https://www.ewg.org/release/tests-reveal-more-weed-killer-some-vitamins-kids-cereals) | Alex Formuzis (ewg.org) [1:44:30]

**The potential autism-inducing effect of the calcium propionate, a preservative added to the wheat**: [1:44:45]

- [Altered brain phospholipid and acylcarnitine profiles in propionic acid infused rodents: further development of a potential model of autism spectrum disorders.](https://www.ncbi.nlm.nih.gov/pubmed/20405543/) (Thomas et al., 2010)
- [Pathophysiological and neurobehavioral characteristics of a propionic acid-mediated autism-like rat model](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5814017/) (Choi et al., 2018)

**New form of wheat being developed**: [Kernza grain](https://landinstitute.org/our-work/perennial-crops/kernza/) (Landinstitute.org) [1:46:00]

§

## People Mentioned

- [David Perlmutter](https://www.drperlmutter.com/) (Brain Wash book) [16:00]
- [Michelle Bachelet](https://en.wikipedia.org/wiki/Michelle_Bachelet) (politician in Chile who enacted soda taxes) [29:15]
- [Barry Popkin](https://en.wikipedia.org/wiki/Barry_Popkin) [30:15]
- [Michael Bloomberg](https://en.wikipedia.org/wiki/Michael_Bloomberg) [30:15]
- [Governor Jerry Brown](https://en.wikipedia.org/wiki/Jerry_Brown) [35:30]
- [Anahad O’Connor](https://en.wikipedia.org/wiki/Anahad_O%27Connor) [36:15]
- [Rhona Applebaum](https://www.bizjournals.com/bizwomen/news/latest-news/2015/11/coca-cola-exec-retires-after-health-research.html) (chief science and health officer at Coca-Cola) [36:30]
- [James Hill](https://www.norc.uab.edu/people/jhill) (co-opted scientist who did sham studies for GEBN) [37:00]
- [Gabe Brown](https://brownsranch.us/) (farmer who used regenerative techniques to rebuild his farm) [54:30, 1:00:40]
- [President Trump](https://en.wikipedia.org/wiki/Donald_Trump) [1:00:00]
- [Paul Hawken](https://en.wikipedia.org/wiki/Paul_Hawken) (Drawdown book) [1:03:00]
- [Pat Brown](https://en.wikipedia.org/wiki/Patrick_O._Brown) (founder of Impossible Foods) [1:04:15, 1:06:00]
- [Earl Butz](https://en.wikipedia.org/wiki/Earl_Butz) (go big or go home) [1:17:30]
- [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) (if we lose bees from the face of the earth, humans have four years left to live) [1:19:40]
- [Timothy McVeigh](https://en.wikipedia.org/wiki/Timothy_McVeigh) (bombed building by going to like a farm store and buying nitrogen fertilizer and turning into a bomb) [1:20:00]
- [Michael Pollan](https://en.wikipedia.org/wiki/Michael_Pollan) (Omnivore’s Dilemma) [1:22:00]
- [Dariush Mozaffarian](https://nutrition.tufts.edu/profile/faculty/dariush-mozaffarian) (dean of Tufts School of Nutrition Science and Policy) [1:32:40]
- [Tim Ryan](https://en.wikipedia.org/wiki/Tim_Ryan_(Ohio_politician)) (Ohio representative) [1:32:40]

1. [Norman Borlaug](https://en.wikipedia.org/wiki/Norman_Borlaug) [1:43:40]

§

![](https://peterattiamd.com/wp-content/uploads/2020/02/bio-pic-markhyman.jpg)

##### Mark Hyman, M.D.

Dr. Hyman is the Head of Strategy and Innovation for the Cleveland Clinic Center for Functional Medicine, and founder and director of The UltraWellness Center. He is the bestselling author of numerous books, including *Food: What the Heck Should I Cook?*, *Food: What the Heck Should I Eat?*, *Eat Fat, Get Thin*, and *The Blood Sugar Solution 10-Day Detox Diet*.

Dr. Hyman believes that food has the power to change our most important global issues – transforming individual, environmental, economic, societal, and global health, and everything in between. [foodfixbook.com]