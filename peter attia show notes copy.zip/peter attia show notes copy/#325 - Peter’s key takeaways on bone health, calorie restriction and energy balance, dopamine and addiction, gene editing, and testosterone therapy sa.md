# #325 ‒ Peter’s key takeaways on bone health, calorie restriction and energy balance, dopamine and addiction, gene editing, and testosterone therapy safety with a prostate cancer diagnosis | Podcast Summary #3

**Source:** [https://peterattiamd.com/qps3/](https://peterattiamd.com/qps3/)

---

In this podcast summary episode, Peter summarizes his biggest takeaways from the last three months of guest interviews on the podcast. Peter shares key insights from his discussions on diverse topics such as dopamine and addiction with Anna Lembke, the current state and exciting future of CRISPR-mediated gene editing with Feng Zhang, how to build and maintain strong bones from youth to old age with Belinda Beck, how calorie restriction may influence longevity and metabolic health with Eric Ravussin, and the role of testosterone and TRT in prostate cancer with Ted Schaeffer. Additionally, Peter shares any personal behavioral adjustments or modifications to his patient care practices that have arisen from these engaging discussions.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [episode #325 show notes page](https://peterattiamd.com/qps3/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of topics to be covered [1:45];
- Anna Lembke episode: addiction, dopamine’s role in pleasure and pain, and managing addictive behaviors [4:15];
- Follow-up questions about addiction: heritability, cold therapy, exercise, and strategies for breaking addictive behaviors [14:45];
- Feng Zhang episode: the potential of gene editing with CRISPR technology for treating diseases and the challenges ahead [21:00];
- Feng Zhang’s impactful education experience, and how early exposure and curiosity-driven learning can develop scientific interest for kids [28:30];
- The future of CRISPR: weighing the scientific potential to combat complex diseases against ethical considerations around genetic modification [33:45];
- Belinda Beck episode: how to build and maintain strong bones from youth to old age [37:30];
- How both nutrition and exercise are crucial for bone health at all ages, and why it’s never too late to start [54:45];
- Eric Ravussin episode: calorie restriction, energy expenditure, exercise for weight maintenance, and more [59:00];
- Measuring energy intake and energy expenditure: techniques and challenges [1:09:45];
- Ted Schaeffer episode: the nuance role of testosterone in prostate cancer, TRT, and the need for better cancer biomarkers [1:14:30];
- Peter’s favorite bands [1:25:45]; and
- More.

§

The Peter Attia Drive

Peter’s key takeaways on bone health, calorie restriction, gene editing and more

§

## Show Notes

§

\***Notes from intro**:

- Welcome to another AMA episode of *The Drive*
- This is the 3rd of what we’re calling the podcast summary
- The feedback has been very positive on these, so we’re going to continue to do them
- In this conversation, what Peter does is take the interviews he’s done over the preceding quarter and note the most important insights that he’s gained personally along with any changes that have resulted in his practices
- This shouldn’t be seen as a replacement for listening to the podcasts, but Peter hopes they serve as a primer
  - Or if you’ve listened to them, maybe they direct you to go back and listen to something that you missed
- This episode covers interviews with
  - Anna Lembke
  - Feng Zhang
  - Belinda Beck
  - Eric Ravussin
  - Ted Schaeffer
- In this discussion we speak about topics such as
  - Dopamine
  - Addiction
  - CRISPR
  - Gene editing
  - Bone health
  - The importance of exercise at any age
  - Energy balance
  - Caloric restriction
  - Prostate cancer
  - Testosterone
  - And much more
- If you’re a subscriber and you want to watch the full video of this podcast, you can find it on the show notes page
- If you’re not a subscriber, you can watch a sneak peak of the video on our [YouTube page](https://www.youtube.com/@PeterAttiaMD)

## Overview of topics to be covered [1:45]

- Our podcast summaries are still relatively new, and what we’re doing is going over Peter’s notes from previous episodes
  - We won’t necessarily summarize these episodes as much as talk about Peter’s biggest takeaways
  - We’ll also have a conversation on how that’s affected either his behavior or how he deals with patients
- Today we’re going to talk about
  - Dopamine through Anna’s podcast
  - CRISPR, which is super interesting through Feng’s podcast
  - Bone mineral density and lifting in females with Belinda
  - Calorie restriction with Eric
  - Prostate cancer with Ted (a shorter episode)
- This is not a substitute for going back and listening to the podcast
- Peter is not attempting to provide the full context of everything
- What he’s trying to do is capture what he’s taking away in real time as he’s having these discussions
  - He shares what he’s making notes on and what he’s pulling out as the most interesting stuff
  - Sometimes that comes with an assumption that other content is heard and understood
- The hope is that you’re listening to this after you’ve heard these podcasts, or that you listen  to this and maybe go back and listen to a podcast that you skipped because the insight is particularly interesting

## Anna Lembke episode: addiction, dopamine’s role in pleasure and pain, and managing addictive behaviors [4:15]

[#321 – Dopamine and addiction: navigating pleasure, pain, and the path to recovery | Anna Lembke, M.D.](https://peterattiamd.com/annalembke/) (October 14, 2024)

\*\*\*

**Start with your main takeaways from that episode**

- Peter read Anna’s book [[*Dopamine Nation*](https://www.amazon.com/Dopamine-Nation-Finding-Balance-Indulgence/dp/152474672X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.CbGRT43DDyCX0BQVGMrdXbKXsA7IDRGK2hMTVkr21qQAzR3EU9VJZIpv8U0mG-whfzeFeZcT1TTaQeimIxrIenephG-pCFDuM2bvUpdf3v-xM_K2T8y2g77UWgvaUo2me7sUD0DelW6VN7e74jux90KME4M0pzMyYCxjQuoMp96PrYZCXSGuCAxVKmC6ZFZRmkN1oaeavHJ3T9RMI1pxQ4IzDTxlQU57lbI5KfyEgBM.8WXBwWmqsCkLnJN5xF-Xeen_X6yo4-bOwWOMZ78ZGpU&qid=1721135059&sr=8-1)] before interviewing her and enjoyed it a lot
- He was looking forward to talking about this and had a lot of questions about what really constitutes addiction
- The book is really about addiction more than it is about dopamine
- [Dopamine](https://en.wikipedia.org/wiki/Dopamine) is one of the most important neurotransmitters in the reward system (and therefore in the addiction system), but it’s not the only one
- Peter’s interest was less about the nuts and bolts of dopamine and more around the science of addiction
- We started with defining the traditional aspects of what defines addiction
  - Out of control compulsive use
  - The cravings
  - The continued use despite consequences
  - Tolerance to the stimulus
  - Ultimately withdrawal when the stimulus is removed
- You can view that through the traditional lens of how people think of an addiction like alcohol ‒ all of those things check-off
- And there are behavioral addictions that show up as well
  - Everything from gambling to sex to workaholism

**What are the factors that influence an addiction?**

- Peter wanted to understand how heritable addiction is
  - Meaning how much is this written into the genetic code?
  - It turned out quite a bit according to the heritability data
- This came up in the [podcast with Karl Deisseroth](https://peterattiamd.com/karldeisseroth/) where we talked about eating disorders, depression, schizophrenia
- The typical way that these **twin studies** are done is they look at the prevalence of a certain condition in identical twins that were raised apart
  - That’s really the best tool we have to **understand how much of a role do genes play?**
  - You take 2 people with identical genes raised in a completely different environment,

> “*Based on that, Anna said that addiction is about 50 to 60% heritable… it’s a big enough amount that it can’t be ignored, but it’s not so big an amount that the die is cast.*”‒ Peter Attia

- Meaning just because you come from a line of people who have an addiction to one thing or another doesn’t mean that your fate is sealed

*Other things that play a role in addiction*

***She described them as nature, nurture, and neighborhood***

- 1 – Nature is your genes
- 2 – Nurture is how you’re raised
- 3 – Neighborhood is the environment you’re in
- If heritability is 50-61%, 40-50% comes from how you were raised (obvious things and subtle things)
  - Are you raised around people that are engaging in a certain behavior?
  - Do you have experiences in life, for example, trauma that might predispose you to certain addictive behaviors?
- This idea of **neighborhood** is very important and has a lot to do with anybody who’s ever considered trying to break a bad habit
  - If you struggle with gambling, it’s really hard to break a gambling habit if all your friends are gamblers
  - You either have to get a bunch of new friends or somehow just decide you’re going to hang out with a bunch of people who gamble but not do it yourself
  - Very difficult

**Why do some people have a certain lock and key configuration for certain addictions?**

- This is another topic that Peter found incredibly fascinating, and we don’t know the answer
- Peter used himself as an example: he really enjoys alcohol
  - He enjoys the taste but doesn’t think he could be an alcoholic if he tried
  - If you surrounded him with alcoholics, it would never appeal to him to drink in the morning or drink in a manner that would lead to excessive use
    - It’s not clear why that is
    - It’s not moral superiority
  - There’s something in his brain that doesn’t get enough of that cycle from alcohol; it doesn’t work that way for him
- The same is true with gambling
  - Peter was in Vegas giving a talk a  little while ago and had to walk through a casino 25 times to and from where he was going
  - Not to be disparaging of people who are in casinos at 7 in the morning…
  - If someone offered Peter a job to sit in the casino and play blackjack and they’ll pay him a million dollars a month to do this and cover all his losses and he can keep all the winnings
    - He couldn’t do it
    - He couldn’t imaging something less appealing
  - Yet there are people who ruin their lives doing this, why?
- Similarly, there are things Peter is addicted to that most people would look at and say, “*Who could do that?*”

> “*This ‘why’ question I don’t think we have an answer to yet. And yet it totally fascinates me. To me, that’s the most interesting question in this space.*”‒ Peter Attia

**How Anna works with clients**

- She’s a psychiatrist, and one of the first steps that she does is a **4-week dopamine fast**
  - Which means a 4-week total abstinence from the behavior that one is trying to rid themselves of

***Peter thinks this 4-week dopamine fast is valuable for any of us that are trying to cope with our own addictions***

- She said that 80% of her patients will feel better after the 4-week fast
- Now she also noted some of those people need medications to help them through that
  - For example, if a person is trying to do a dopamine fast around alcohol, they may actually require [benzodiazepines](https://en.wikipedia.org/wiki/Benzodiazepine) medically to help with that transition
    - Of course, that’s not always the case
- We also discussed a woman that was basically smoking pot 24/7 and was doing it because of her anxiety
  - It turned out the anxiety was coming from smoking all that pot, but this wasn’t realized until she was able to abstain from it

**Peter found the nuance around pain and pleasure interesting**

*Cold plunging is one example*

- Peter is a huge fan of cold plunging, although he firmly maintains that its has no longevity benefit, but it has 2 distinct benefits
- 1 – A reduction in inflammation and muscle soreness
- 2 – Improvement in mood for select people
  - Anna talked about how she’s tried cold plunging many times and has never experienced an improvement in mood
  - Peter has heard many people say this, and just as many people share his experience
    - If he gets into a 40-degree bathtub (buries himself up to his neck) for 10 minutes, he feels insanely good afterward
- This is not unlike the issue just discussed:  why do some people have the key to go in the lock for alcohol  while other people don’t have it?

***What it really comes down to is endogenous dopamine production from pain***

**Anna talked about how we live in a state of homeostasis**

- This is true all across biology
  - Examples include maintaining regular glucose levels, pH, body temperature
  - All of the core things that allow us to live require homeostasis
- The body has remarkable tools for adjusting up and down to keep us in that window, and dopamine is no exception

> “*When we do something that is difficult, that induces pain (and the two examples that she gave were cold immersion and exercise), the body has to offset that pain somehow, and it does so by increasing the endogenous production of dopamine.*”‒ Peter Attia

**What’s different about these examples**

- It’s not a huge rush of dopamine that you get for free
- It’s this dopamine that you kind of had to work for to offset something you are doing that’s actually causing pain
- So, when you remove the painful stimulus i.e, when you get out of the cold plunge or when you stop the workout, you have this lingering effect of that heightened dopamine
- But again, it’s a physiologic level and it hasn’t been a hijacked level

**There is a line in Anna’s book that she credits to the person who said it (which Peter loves), “*****Our brains are like cactuses that now reside in a rainforest*****.”**

- We evolved in an environment where stimulation was relatively modest and our brains had normal tools for coping with the up and down swings of dopamine
- And now we live in the most stimulating environment imaginable, and obviously we just didn’t have enough time to adapt
- Anybody can sort of follow the logic there
- Peter thinks that makes a lot of sense and it probably speaks to his big takeaways from this

**A big takeaway, especially if you’re a parent**

- Ask the question, “*What are we doing to prevent our kids’ brains from being hijacked by this?*”
- Whether you grew up in the ‘70 or the ‘80, we still grew up in a relatively stimulation-free world

- The pinnacle of stimulation in those days was watching reruns of [*Happy Days*](https://en.wikipedia.org/wiki/Happy_Days) on a cheap cathode rate tube TV

*2 things stand out: social media and pornography*

- When Peter was a kit pornography was a [*Playboy*](https://en.wikipedia.org/wiki/Playboy) magazine
- Today, it’s [VR](https://en.wikipedia.org/wiki/Virtual_reality)
- As a parent, you have to be the one that’s in charge of saying, “*We’re absolutely going to minimize, avoid these things to the best of our ability.*”
- Everybody already knows how much you need to limit use of a smartphone, social media, all of those things

## Follow-up questions about addiction: heritability, cold therapy, exercise, and strategies for breaking addictive behaviors [14:45]

**The heritability of addiction is large (50-60%), when you do a patient history, are you now having them also include addictions?**

- This is a good question
- We don’t have dedicated questions around it, but it almost always comes up thorough detailed questioning around everything else
- The reason is it’s very difficult for a person to struggle with an addiction to alcohol or drugs and not have it creep into their health
- It’s very common that we hear Uncle Jimmy, he died of heart disease when he was 60, but truth be told, he had a real drinking problem etc.
- We usually emerge from the family history knowing about additions, but this is a good point
- We could be more deliberate about it
- We obviously pay a lot of attention to this when it comes to mental health as well, because when you go through the family history and you see a number of family members with mental illness, you just realize that there’s a greater susceptibility as well

**About cold therapy, do you use it routinely or do you have days when you’re in a terrible mood and use it when you need a break?**

- Peter will occasionally used it as a total reset
- He doesn’t know that it needs to be the most extreme version of a cold plunge
  - Even having your face dipped in a bowl of cold water can stimulate the mammalian dive reflex
    - Trigger an autonomic response that upregulates the parasympathetic system via the vagus nerve, and that can tone down the sympathetic system
- This goes back to a previous [podcast with Joel Jamieson](https://peterattiamd.com/joeljamieson/) where we talked about HRV
  - He did a good job explaining that you don’t want to think about one system being “on,” one system being “off,” between parasympathetic and sympathetic
  - You just really want to think about them always both being “on”, and it’s just a question of the balance
  - Are you revving one up more than the other?

**You mentioned Anna talked about how exercise can be a mood stabilizer for people. Do you see that for you?**

- Yeah
- If you deprive Peter from exercise, it’s noticeable within a day

**When you work with patients on addictions, when do you recommend trying a new behavior versus going to see a specialist to work on it in more nuanced detail?**

- Obviously, there’s a huge spectrum of addictions
  - It can be as simple as, “*I’m not going to look at my phone an hour before bed;*” while others can be deep addictions

***For the most part, Peter likes to see people try to solve this on their own using their own neighborhood as the tool***

**Example: excessive phone use**

- If peter is sitting around holding his phone, he’s looking at it frequently
  - He’s going to be checking emails and texts, reading the news quite often
- If he wants to avoid that, he has to come up with an alternative
- This is where his “bat phone” is a good alternative
  - If he’s going somewhere and he needs a phone to make phone calls (but nothing else), he brings his bat phone, which doesn’t have email on it
  - Nobody knows the phone number so he never gets texts on it
  - It’s just a device that makes calls and has podcasts on it if he wants to listen to a podcast

***He’s going to look at it less because he’s “fixed” the neighborhood in a sense***

*This is what Peter tries to get patients to think about*

- How do you not have your phone in your room?
- How do you not have your phone with you an hour before bed?
- Not because you’re white knuckling it, but because you’ve come up with another thing in your routine that wouldn’t have a phone with you
- If you go and do a sauna, cold plunge before bed, it’s easy to displace the phone
- It’s a tougher task to ask you to sit there and stare at the wall without your phone

**When you go hunting, you’re off the grid hiking deep in the woods. Is that a natural dopamine fast?**

- No, it’s not long enough
- He does enjoy that, and just came back from a trip bow hunting in a very remote area where there was no wifi, no cell service
- You don’t have to go hunting to experience this; you could be camping in the right spot
- Everything from waking up super early, going to bed once the sun goes down, and not being inundated with anything was great
- Also, he didn’t experience withdrawal
  - It probably made him feel a bit better knowing that he doesn’t have an addiction
  - He was quite happy to not have the device

## Feng Zhang episode: the potential of gene editing with CRISPR technology for treating diseases and the challenges ahead [21:00]

[#323 – CRISPR and the future of gene editing: scientific advances, genetic therapies, disease treatment potential, and ethical considerations | Feng Zhang, Ph.D.](https://peterattiamd.com/fengzhang/) (October 28, 2024)

\*\*\*

- This is an interesting episode, pretty technical at times, but it’s a topic you hear about so much: CRISPR and gene editing
- We’ve [written about PCSK9 gene editing](https://peterattiamd.com/pcsk9-gene-editing/) and how that can have an impact in cardiovascular disease

***This is a podcast for the layperson who is interested in understanding CRISPR technology***

- We went deep enough that if you’re an investor, if you’re a biotech investor and you’re trying to get deep in the weeds of what CRISPR technology can do, can’t do, where the opportunities and limitations are, you’re also going to get the master’s level thesis on that

**Instead of focusing on any of the technical stuff, Peter gives a short summary of what we’re talking about**

- [CRISPR](https://en.wikipedia.org/wiki/CRISPR) is a tool for gene editing
- Gene editing was around before CRISPR, but it was very, very crude

> “*CRISPR has created a very high fidelity way to edit—at the base pair level—frankly, in a way that is easier and more reproducible than any other technique.*”‒ Peter Attia

**It’s worth noting how this was discovered**

- This was discovered on the basis of understanding how bacteria fight off viruses
- So, we fight off viruses using an immune system that consists of B-cells and T-cell and relies on antibodies sometimes and relies on helper T-cells and killer T-cells and all these other things
- Bacteria being far simpler organisms, single cell organisms have this trick for remembering a virus that has infected them by copying their DNA such that the next time it happens, they can quickly recognize it and cut the virus into pieces and dismember it

***Feng is one of the pioneers in this space and arguably the person on the front of what is happening in CRISPR***

- Many of Peter’s notes were super technical, on details of Cas13 versus Cas9, and that’s not the direction he wants to go here

**It’s more important to communicate the scope of what’s available and when**

*Feng had a great way of describing this, which is to think about payload creation and payload delivery as 2 parts of the problem*

- 1 – **Creating the payload** is modifying the gene, which you can do *ex vivo* or *in vitro*, so you can actually do that outside the body
  - For example, if you are born with a disease where one of the genes responsible for metabolism in your liver is defective (there are lots of these)
  - Take [PKU](https://en.wikipedia.org/wiki/Phenylketonuria) as an example, if you don’t have the enzyme that metabolizes an amino acid ‒ you can live, but you can’t ever touch that amino acid (it’s a huge inconvenience)
  - CRISPR makes editing that gene outside the body a piece of cake
  - Easier than any other gene editing technology that came before it

***The question is how do you then deliver that gene into the cells of the liver, the hepatocytes?***

- 2 – How you deliver that gene into specific cells is called **payload delivery**
  - For that particular case [editing a gene in the liver], you can use [lipid nanoparticles](https://en.wikipedia.org/wiki/Solid_lipid_nanoparticle)

***Tiny lipid nanoparticles turn out to be a very effective way to deliver edited genes into the liver because the liver disproportionately takes up lipids***

- But if we’re dealing with a gene in your brain, kidney, cardiac muscle ‒ we are very limited in our ability to select and target tissues

> “*It turns out we are still very limited in our ability to select and target tissues using vectors or payload delivery systems to get those genes there, and that’s probably going to be the bigger bottleneck than just being able to make the edits.*”‒ Peter Attia

**3 places where gene therapy is immediately applicable**

- 1 – The **liver**, where you can deliver it with lipid nanoparticles
- 2 – The **eye** or even the scalp, where you can deliver it topically
  - Epigenetic therapies could be applied to the top of the scalp
    - For example, if you were trying to block an enzymes like [5𝛼-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase)
- 3 – In **blood cells** where you can take the blood out, make a modification and put it back in
  - Or do the same through bone marrow
- Outside of those 3 places, it gets pretty difficult

**Limits to what we know**

- Even within those places, there’s another big stipulation: ***we’re still not at the point where we know what most genes do***
- When we think about most chronic diseases, the 4 horsemen (cardiovascular disease, cerebrovascular disease, cancer, neurodegenerative and Alzheimer’s disease, and metabolic disease), *how many times does a monogenic (single gene) become the cause of one of those diseases?*
- In neurodegenerative diseases there are a handful of examples
  - [Huntington’s](https://en.wikipedia.org/wiki/Huntington%27s_disease) may be the most prevalent, whereas a [single gene](https://en.wikipedia.org/wiki/Huntingtin) drives it
  - There are very rare examples where genes cause early [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) ([*PSEN1*](https://en.wikipedia.org/wiki/PSEN1)*,* [*PSEN2*](https://en.wikipedia.org/wiki/PSEN2)*,* [*APP*](https://en.wikipedia.org/wiki/Amyloid-beta_precursor_protein)), but remember that’s less than 1% of people
    - For most people, they might have a predisposition through [*APOE4*](https://en.wikipedia.org/wiki/Apolipoprotein_E#Alzheimer's_disease), but it’s a very polygenic condition
- Cardiovascular disease is also a very polygenic condition
  - [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)) may be a single gene and it’s probably the most heritable form of heart disease
- There are certain cancers that clearly appear linked to heritability, but most don’t
  - Probably 90-95% of cancers don’t result from heritable mutations nor even single gene mutations

***It’s important to understand that when we think about the diseases that kill most people, CRISPR does not appear to offer a solution in its current form because if the solution is to edit genes, we have to know what the genes are***

**Where we’re going to see CRISPR have its greatest effect in the coming decade is going to be on these monogenic conditions**

- Conditions caused by a single gene and we know the gene (how to fix it)
- The greater challenge is to deliver the new gene to the tissue of interest

## Feng Zhang’s impactful education experience, and how early exposure and curiosity-driven learning can develop scientific interest for kids [28:30]

**One of the things Peter loves about Feng’s story is what a childhood prodigy he was**

- Here you have this immigrant kid who’s come over from China, grows up in the middle of the country

***Yet the experience that he had in school was so transformative and impactful on who he would become, and a lot of it can be traced back to the experiences that he had in school***

- Feng is arguably one of the greatest scientists alive today; 1 of the 10 most revered and impactful scientists under the age of 45

- He had very early exposure to science and amazing opportunities to do preceptorships and shadowing experiences and internships
- Even in high school when he took an interest in biology
  - Which by the way he didn’t out of the gate, his interest was math and physics
  - He sort of had this negative view of biology as just memorizing a bunch of facts and anatomy and things like that
- Once he got really exposed to biochemistry and to genetics, his interest shifted and then again, he had these opportunities
- You can overstate that

> “*I think that exposure means so much and it clearly matters more than how smart you are or anything like that.*”‒ Peter Attia

- We may have even discussed the example of [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) and [Paul Allen](https://en.wikipedia.org/wiki/Paul_Allen) who just happening to be in a high school that had such early exposure to computers

***There’s no shortage of stories of tech entrepreneurs today who have gone on to do great things and you trace a lot of it back to where they went to school***

- They went to a school that happened to have a lab that allowed them to do a bunch of coding when they were 10 years old, and that’s what created the thing

**If you’re listening to this and you’re a parent**

- What you want to think about is “*How do I get my kid exposed to science? How do I get my kid exposed to people who are going to get them passionate about something and light a fire under them through pure bliss?*”
- Kids don’t work hard because they’re forced to
- Kids work hard because they find something exciting

**Oftentimes in school science, it can be rote memorization that feels a bit boring. How can parents show their kids science in a way that is more enjoyable for someone under 12-years-old?**

- It might depend on the parents’ own knowledge of science
- Peter came from a STEM background, so it’s easier for him to do this himself
  - He’s always looking for an angle and always trying to weasel into understanding what they’re doing and looking at the world around them and asking them questions
- For example, when one of his kids was interested in [The Flash](https://en.wikipedia.org/wiki/Flash_(DC_Comics_character)), that became an amazing opportunity to talk about speed
  - What is speed? How is it measured?
  - Okay, if Flash moves at the speed of sound, do you actually know how fast that is? Let’s go out and do an experiment so you can actually see what the speed of sound is
- There are insane resources on YouTube explaining to kids how things work and getting kids excited, maybe showing experiments they can do
- It requires work, and some kids are fortunate enough to be in schools where that’s just a natural part of the curriculum
  - The assumption should be that it’s probably not
  - It’s probably the case that much of what kids do in school is checking the box, getting ready for the standardized test and learning some important stuff along the way

***In school, you’re learning foundational pieces of information, but you’re missing the application, you’re missing the, “Why is this interesting?”***

- One of Peter’s kids is going through chemistry where they’re leaning about unit conversions
  - Which sounds like the driest most boring thing in the world
  - But it’s a great opportunity to talk about things like velocity and density, and if you’re converting from meters per second to kilometers per hour, it’s a great opportunity to talk about when one might be the thing you measure and why you might want to measure the speed of one object in this unit and another in the other unit
- Nick remembers from his childhood the [*Magic School Bus*](https://en.wikipedia.org/wiki/The_Magic_School_Bus_(TV_series)) and Ms. Frizzle
  - A cartoon, and she was a science teacher and they would go on their magic school bus and drive in through your nose to learn about mucous and the body

Peter jokes, “*We’ve talked about how we need* [*LNPs*](https://en.wikipedia.org/wiki/Solid_lipid_nanoparticle) *to deliver gene vectors to the liver, but why wouldn’t we just use the Magic School Bus if it can go up your nose? We could probably get right through the olfactory plate and into the brain. Did anybody ever think about gene editing with the Magic School Bus?*”

## The future of CRISPR: weighing the scientific potential to combat complex diseases against ethical considerations around genetic modification [33:45]

**With CRISPR, 20-30 years down the road, are we ever going to get to a place where we can target the horsemen that affect more people as opposed to specific genes?**

- Consider a disease like **cardiovascular disease**, Peter doesn’t know what the heritability of it is, but wouldn’t be surprised if it’s 50-60% (just like he talked about with addiction)
- You have to believe then that you can identify all the genes that are responsible for the trait of interest, whether it be hyperlipidemia, hypertension, etc.

> “*But then you have to ask the question, how much of those traits have to be turned on by the environment?*”‒ Peter Attia

- And what happens if you’re absent the trait, but you don’t fix the environment?
  - How much are you attenuating the issue?

*Put this in perspective*

- The human genome was sequenced almost 25 years ago
- We’ve made alarmingly little progress in the last 25 years on which genes are responsible for what
- The next 25 years are going to be a lot better
- Not to fall back on the old adage of AI, but clearly AI is going to play a role in this

**We have a deeper question at hand, which is where will we draw the ethical line?**

- We talked about this a little bit on the podcast, maybe not as much as Peter would’ve liked to
  - Just for the sake of time, and also because Feng’s not an ethicist
- This is really more of an ethical question: **what do we do about modifying germ lines for genes that don’t immediately cause a disease or a problem?**
- Should we eradicate the [APOE4](https://en.wikipedia.org/wiki/Apolipoprotein_E#E4) gene?
  - That seems like a no-brainer
  - APOE clearly had benefits during evolutionary times, prehistoric times, probably protective from a number of infectious conditions
    - That might’ve been a greater cause of morbidity than obviously Alzheimer’s disease was 10,000, 20,000 years ago
  - But most people, if confronted with the data would say, not having APOE4 around today would be a net positive
- But then where do we stop?
- If you read [Walter Isaacson’s book about Jennifer Doudna](https://www.amazon.com/Code-Breaker-Jennifer-Doudna-Editing/dp/1982115858), which talked a lot about this, he goes much deeper into this topic, and it’s very fascinating
  - He talks about: would we get rid of [autism](https://en.wikipedia.org/wiki/Autism)?
    - It’s polygenic condition, lots of suffering, but not every kid with autism is suffering terribly, right?
    - It’s a spectrum of disease
  - Would we get rid of depression?
  - Would we get rid of all of these conditions?
  - And what kind of a society are we trying to make and how homogeneous do we want to make the population?
  - And what happens when you get rid of heterogeneity?
- Peter doesn’t want to be the one to be trying to answer those questions, because he can’t come up with answers, but he suspects that that will be the challenge of the next decade or two

***The challenge will be less about what is technically possible and more about what is ethically defensible***

## Belinda Beck episode: how to build and maintain strong bones from youth to old age [37:30]

[#322 – Bone health for life: building strong bones, preventing age-related loss, and reversing osteoporosis with evidence-based exercise | Belinda Beck, Ph.D.](https://peterattiamd.com/belindabeck/) (October 21, 2024)

\*\*\*

- This is a topic that Peter loves: how lifting affects bone mineral density in females as we age
- We had talked about Belinda through the [study](https://pubmed.ncbi.nlm.nih.gov/28975661/) she was doing even before we interviewed because it was a huge interest
  - [Episodes [#307](https://peterattiamd.com/exerciseforagingpeople/) and [#235](https://peterattiamd.com/laynenorton3/)]
- This episode has huge applicability for not just women, but everybody

> “*This is obviously about middle and older age women, but the truth of it is it’s relevant for everybody*.”‒ Peter Attia

**The big takeaway for parents, the most amazing statement of that entire episode was when Belinda said, “*****Osteoporosis is a childhood disease*****.”**

- What she meant was the disease begins in childhood because it is during **adolescence** that you are on the trajectory to achieve your maximum bone density
- You have the ability to achieve your genetic potential to hit your genetic ceiling during childhood and adolescence
- And if you do not achieve your ceiling, you are setting yourself up for failure later in life

*There are many people listening who have kids and can think about what do our kids need to be doing?*

- What kind of sports do they need to be playing?
- How do we have to think about their nutrition to make this happen?

**There’s this thing called** [**Wolff’s Law**](https://en.wikipedia.org/wiki/Wolff%27s_law)**, which says bone will adapt to the nature of the load that it’s exposed to**

> “*If you listen to the podcast, just remember that feature: bone is highly, highly adaptable.*”‒ Peter Attia

- You think a bone is just a fixed structure, but that’s not true
  - It’s a living organ, and just as a muscle adapts to external loads, so too do bones
- Genetics play a pretty significant role in bone mineral density
- The **heritability** analysis here suggests that genetics are 70-80% responsible for the genetic ceiling that you can reach by the time your bone plates fuse
- So, for females, this is typically about aged 18 (late teens), and for males, this is typically in the early 20s that we’ll see the fusion of the plates
  - And that basically locks in bone density

**We get into fundamental differences between males and females**

- Males tend to get to a higher levels to start with than females
- As people go through that period of late teens, early 20s into midlife, there’s not really much of a decline in bone density

**Then something really profound happens in the life of a woman, which is menopause**

- [Menopause](https://en.wikipedia.org/wiki/Menopause) removes from women the most important hormone in bone health, which is estrogen
  - That’s also true for men
  - But of course, men aren’t losing estrogen suddenly in the middle of life the way women are
- And so what estrogen does is it plays a really important role inhibiting what are called [osteoclasts](https://en.wikipedia.org/wiki/Osteoclast)

A*t the risk of oversimplifying, you have these two types of cells that exist in an equilibrium, osteoblasts and osteoclasts, and they are responsible for bone remodeling*

- The [osteoblasts](https://en.wikipedia.org/wiki/Osteoblast) are the ones that are building the bone, and the [osteoclasts](https://en.wikipedia.org/wiki/Osteoclast) are the ones that are breaking away the bone
  - You have to have both of these in check
  - If you only had osteoblasts, you would have these deformed bones that actually wouldn’t be functional, would be quite weak

***Estrogen’s role is to keep the osteoclasts at bay and removal of estrogen leads to basically a disproportionate amount of bone reabsorption***

- And that’s why while men and women arrive at menopause, relatively constant (men being slightly higher, but they’re sort of changing at the same rate), ***women experience quite a precipitous decline, and over the next 5-8 years, they will lose significant bone mineral density***

**Belinda describes the triple threat of bone health for women**

- 1 – Women develop less bone mass during the maturation phase [in adolescence]
- 2 – Profound bone loss during menopause
- 3 – Women have less muscle mass than men in general, so later in life they are more susceptible to falling
  - The less muscle mass you have, the more you tend towards [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia), the greater your risk of falling

***Women are hitting 3 strikes there, and that’s why we see a far greater incidence of falls and far greater severity of falls in women***

**We talked about the big modifiable behaviors**

- It largely comes down to **nutrition** and **activity**

*With nutrition we focused a lot on its role in kids*

- Most people would not be surprised to hear that **calcium** and **vitamin D** are very important
- Both of these are things you get in dairy

***Belinda made the point that dairy is by far the best source of calcium (milk, yogurt, cheese)***

- Peter was a bit surprised at what it took to get the **right amount for kids**: 3 8-oz. glasses of milk (which is 750 mL, that’s three quarters of a liter)
  - That is what’s necessary for a kid to get on a daily basis to get their adequate amount of calcium
- As far as vitamin D levels, she didn’t have a clear view on the consensus whether vitamin D above 50 or above 75 was ideal
- But either way, nobody’s walking around with a vitamin D level that high if they’re not outdoors or supplementing
- Clearly we would prefer that we be getting outdoors to get that vitamin D because you’re going to kill 3 birds with 1 stone on that front

**What was really interesting was the type of activity most important for** [**BMD**](https://en.wikipedia.org/wiki/Bone_density)

- If Peter asked to compare someone who’s sedentary to someone who swims to someone who cycles to someone who runs, and asked you to rank those people, he would bet you could come up with the correct order with 1 exception
- It wasn’t just the order that surprised Peter, it was the magnitude
- We discussed a study done with collegiate athletes in those sports (collegiate cycling, swimming and running) and compared them to college students who were sedentary

***The lowest bone density of all of these people was in swimming***

- The swimmers had lower bone density than the sedentary people
- The cyclists and the sedentary people were the same
- The runners were the highest, but not much
  - They were just slightly above the sedentary people
- There was 1 other group of athletes: gymnasts were off the charts

***To summarize, the group with the lowest BMD was swimmers, then sedentary people and cyclists above them, runners just above them, and gymnasts were off the chart***

- This is epidemiology and to be fair, it doesn’t allow us to completely infer cause and effect
- One could argue that people with low bone density might choose to participate in a sport like swimming because they have more buoyancy
- While there may be some degree of reverse causality here, given what we know about [Wolff’s law](https://en.wikipedia.org/wiki/Wolff%27s_law), it’s not a stretch to see that that’s the case

*The only one here that Peter thinks is a bit surprising for most people is why would running not be higher?*

- The adaptation is relatively minor because the movement is identical
  - Running is doing the same thing over and over again in the same plane, in the same direction, with the same force
- Conversely, when they’ve done studies looking at soccer players and basketball players, the bone density is much higher than in runners
- A couple reasons for this
  - There might be differences in nutrition between runners, especially at the elite level who are trying to be as light as possible and therefore are probably malnourished to some extent
  - It might also be that in basketball and in soccer, you have far more explosive movements that therefore mimic more what you’re seeing in gymnastics and it’s multi-directional
    - You’re moving in all directions, and that is putting the bone under much greater stress and causing for much greater adaptation

> “*A big takeaway for me as a parent here is I want to make sure my kids are getting tons of dairy… Your kids are outside, they’re getting vitamin D, and they’re playing kind of ruckus sports*.”‒ Peter Attia

- If your kids are intolerant to dairy, you’re going to have to supplement

- Luckily, Peter’s boys love jiu-jitsu
  - Watching them do jiu-jitsu, Peter can see what that would lead to a lot of bone remodeling given the stresses that the bones are under
- Although we didn’t talk about that, wrestling and jiu-jitsu are also sports that demonstrated really high bone mineral density
  - Mentioned in [AMA #37](https://peterattiamd.com/ama37/)

**Peter asked Belinda, “*****Can kids lift weights?*****”**

- The old adage is that kids cannot lift weights because it will stunt their growth
- Peter looked into this for a newsletter 2-3 years ago, but they didn’t find much on it
  - He doesn’t remember why they didn’t write it

***She felt pretty strongly that there was no evidence at all that lifting weights stunted a child’s growth, and that kids could lift weights at any age ‒ what was important is that they do it safely***

*Your approach to a kid lifting weights should be the same as your approach to anybody lifting weights*

- They have to learn how to do it with correct form
- They have to be able to do the movement under their own body weight before they can do it under load
- Peter really likes it when his boys come in the gym because he’s teaching them how to do [kettlebell deadlifts](https://youtu.be/hinonqqzatk?si=W14qkP8CJg8uN-th)
  - It’s a really easy movement for a kid to learn
  - You’ve got a big fat kettlebell between their legs
  - They get into a sumo position, grab the kettlebell, and you teach them how to stand up and you teach them how to do it with the correct curvature of the spine
    - Peter’s boys have learned that you don’t want to do it with what’s called turtle back, where you’re hunched over forward (you don’t want to do this when you’re in thoracic flexion)
    - You want to be in a mild degree of extension

**We talked a little bit about** [**corticosteroids**](https://en.wikipedia.org/wiki/Corticosteroid)

- This is a relevant issue for both adults and kids
- Corticosteroids such as [prednisone](https://en.wikipedia.org/wiki/Prednisone) are obviously medically necessary and life-saving under many situations
  - Short bouts of these things have no impact whatsoever on bone health, but protracted use can

Peter explains, “*Protracted use of systemic corticosteroids like prednisone or long-term use of inhaled corticosteroids for asthma, the point here is if it’s medically necessary, so be it, but always strive for the minimum effective dose and for the shortest duration possible*.”

***Corticosteroids are very hard on bones, and in Peter’s practice, this is the most common cause he sees of osteoporosis and osteopenia in young people***

- When 30- and 40-year-olds show up in Peter’s practice (especially males) and they have really low bone density as defined by their T-scores, almost without exception, they were exposed to high doses of steroids for long periods of time growing up
  - There was one case, that was not the case, and we still don’t actually know why bone density was so low

**Another thing that blew Peter’s mind ‒ Belinda doesn’t believe that age-related BMD reduction is physiologic**

- [Luc van Loon said [episode #299]](https://peterattiamd.com/lucvanloon/) the exact same thing about lean mass and movement
- If you look at figures of age on the X-axis and then pick your favorite Y-axis (muscle mass, spontaneous movement, bone density: they all have these curves that very smoothly go down and they go down faster as more time extends
  - They have a negative second derivative and a negative first derivative
  - [as demonstrated in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/11/f1-qps3.png)

**Figure 1. Bone mineral density (BMD) by decade of life**. Image credit: [*Scientific Reports* 2023](https://pubmed.ncbi.nlm.nih.gov/37938240/)

- Luc in our podcast said, “*I don’t think this is physiologic*” (meaning I don’t think it’s inevitable)
- He explained, “*I think what you’re looking at is the averaging of a bunch of step function drops that occur due to inactivity*.”
- Belinda effectively said the same thing about bone mineral density
  - She said, “*I don’t think this is a necessary thing that has to go down over age. I think it goes down with age because of use* ‒ *you use less, you load less, and it becomes a vicious cycle.*”

***Less loading means less muscle mass, which means less loading, which means less bone density, and this whole thing sort of spirals forward and now we’re at the opposite end of the spectrum***

**What is the implication for those of us who are listening and thinking about the second half of our life?**

***You’ve got to avoid injury and you have to stay active and you have to keep loading***

Peter explains, “*You have to find safe ways to load because clearly some of the things I used to do to load myself in my 20s, I’m not going to do in my 50s. I sure as hell I’m not going to do in my 60s, but I can’t get to the point where I’m not loading*.”

**How to measure bone mineral density**

- Peter’s not going to summarize that here because the podcast made it very clear what the Z-score and T-score tell us

**Peter’s takeaway from the discussion of the LIFTMOR study [52:45]**

- This is a [study](https://pubmed.ncbi.nlm.nih.gov/28975661/) that Peter has talked about a lot even before he had Belinda on the podcast (he loves everything about it)
- They took a group of women who were over the age of 58 or 60 who had osteoporosis, who didn’t have a lot of experience lifting weights
  - That had to be one of the criteria because the control group and the treatment group were going to be exposed to weight training
- One group was assigned mild weight training and the other group did 5 x 5s
- Women who have never done deadlifts, squats, overhead press, bench press, and they put them on a 5 x 5
  - They taught them how to do these movements
  - 5 x 5s means you’re doing 80, 85% of 1-rep max
- In addition to doing all these compound movements, these women were doing jumping pull-ups
  - This is an exercise where they stand on a box, they pull their arms on the chin-up bar, they jump up to get themselves up (because many people can’t do a pull-up), and then they let themselves down slowly and jump down to the floor
  - Think about the stress they’re putting the bones in their hands and wrists

Peter explains, “*We often think about BMD through the lens of the hips and the lower back because that’s where the diagnosis is made, but let’s be clear it’s all bones*.”

- Think about how many times a person falls and breaks their wrist and how much of a devastating injury that is
- The fact that they’re strengthening those things, doing the pull-up and then they do the little jump at the end to get the little plyometric benefit
- This is an incredible study
- There’s a great video we linked to in the show notes [shown below] where you see some of these women, women who have never lifted weights in their 60s are deadlifting their body weight

Peter shares, “*I just couldn’t get enough of this. And after 8 months, the changes were remarkable.*”

- On the surface, the changes seemed okay
- The women in the lifting group had a slight increase in BMD on [DEXA](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry) while the women in the control group had a significant decline
  - The gap between them was huge

**Belinda pointed out something: the DEXA didn’t tell the whole story**

- You had to look at the CT scans and MRIs and other studies to see that the thickness of the cortical structure went up dramatically in those who lifted, and that won’t necessarily get captured in the DEXA scan

Peter explains, “*This was a bit of an aha moment for me, which made me realize that we’re a little bit limited in how we evaluate BMD in patients because… DEXA… might not actually capture everything that’s going on. And so for me, this is one of those things where I hope in the future we have better and better tools to give us clinical insight into measuring more of these factors.*”

## How both nutrition and exercise are crucial for bone health at all ages, and why it’s never too late to start [54:45]

**When you’re thinking about kids reaching their peak BMD, what’s the breakdown of nutrition versus exercise?**

- You can’t have one without the other

**If we’re dealing with kids, let’s minimize the amount of steroids that are being used in any form**

- For example, if your kid has [asthma](https://en.wikipedia.org/wiki/Asthma), speak to their doctor and find out if they can get similar or better results using [beta agonists](https://en.wikipedia.org/wiki/Beta-adrenergic_agonist) instead of corticosteroids
- And if it’s corticosteroids, can we just figure out what the minimum dose that they need is to kind of get them through Asthma
- A lot of kids will grow out of asthma, so let’s just try to minimize that

***Peter’s takeaway for kids: optimizing nutrition and making sure they’re really active***

**Belinda called osteoporosis a childhood condition, and if you’ve missed your childhood window to maximize BMD, it’s all about managing the decline**

- 100%
- Anybody listening to this has already reached their genetic ceiling
- Analogy: think of that as your glider has already reached its peak height
- You don’t necessarily have the control to make the glider go much higher, but you can slow the rate at which the glider comes down
- As long as you’re currently sitting above the treetops (Peter’s defining the treetops as a T-score of -3, -4), you’re fine

***How long can you keep the glider above the treetops? That’s where activity and nutrition matter***

**Is it ever too late to start exercising?**

- No

**You mentioned turtle back; it reminded Nick of another word that rhymes with that: Nickelback. You’ve been rocking some Nickelback shirts recently. Ironic or serious?**

- Very serious, Peter makes zero apology for how much he loves [Nickelback](https://en.wikipedia.org/wiki/Nickelback)
  - Since the beginning
  - He’s always been a huge fan
- He’s upset that he missed them when they were in Austin
  - He was traveling when they were here

## Eric Ravussin episode: calorie restriction, energy expenditure, exercise for weight maintenance, and more [59:00]

[#324 ‒ Metabolism, energy balance, and aging: How diet, calorie restriction, and macronutrients influence longevity and metabolic health | Eric Ravussin, Ph.D.](https://peterattiamd.com/ericravussin) (November 4, 2024)

\*\*\*

- Eric and Peter go way back and he is the head of an organization called the [Pennington Biomedical Research Center](https://www.pbrc.edu/about/)
  - It’s a biomedical research facility that studies metabolism

**We spent the first part of the podcast talking about technical stuff: how is energy expenditure measured**

- If you’re trying to understand **energy balance**, you have to understand how to measure 3 things: energy intake, energy storage, and energy expenditure
  - This is the first law of thermodynamics: energy can neither be created nor destroyed, only stored
  - Therefore you have to be able to measure those 3 things
- This is complicated, but the most complicated by far is measuring the energy expenditure of a human being
- While there is technically a way to do it directly through measuring the dissipation of heat ([direct calorimetry] or heat that comes off an individual from a practical purpose), that method leaves a lot to be desired
- Instead, the second best way to do this is using a method called **indirect calorimetry** where you measure very, very accurately the amount of oxygen that the person is consuming and the amount of carbon dioxide they are exhaling
  - And together those two things will tell you exactly what their energy expenditure is in real time
  - As a bonus, the ratio of those things, what’s known as VCO2 to VO2 will tell you very precisely what their **substrate utilization** is at any moment in time
    - This can be done of course with a [mask](https://vo2master.com/)
- Peter uses a [mask](https://vo2master.com/) to measure [VO2 max](https://peterattiamd.com/category/exercise/vo2-max/), that is also measuring CO2 production, and that can tell you total energy and the fuel partitioning as well
- As you exercise with greater and greater intensity, you’re moving less from fat oxidation and more to carbohydrate glycolysis
- There are a handful of places around the country including Pennington, where they have a room [a **metabolic ward**] that has those sensors built into it where a person can be in that room and whatever it is they’re doing, you are measuring their energy expenditure
  - You measure it while they’re sleeping, you measure it while they’re awake
  - As discussed on the podcast, Peter has spent many days in several of these chambers
    - He’s done full workouts, both modest and super intense workouts, really trying to push the envelope of what is measurable (it was cool)

**We talked a lot about the** [**CALERIE study**](https://pubmed.ncbi.nlm.nih.gov/32940695/)

- It was inspired by the biosphere experiment of the early 90s

***What Eric and colleagues set out to do was kind of understand the impact of caloric restriction on primary and secondary markers of aging***

- Prior to the [biosphere study](https://pubmed.ncbi.nlm.nih.gov/11010936/), Eric didn’t really have a huge interest in aging (now he does)

*Eric made a great point distinguishing between primary and secondary markers of aging*

- And this is something everybody should just have in their mind when they’re paying attention to studies
- The **primary markers of aging** are basically what people think of maybe when they talk about the hallmarks of aging
  - There used to be [9 of them](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/); now there’s 14 or 15 [the figure below shows [12](https://pubmed.ncbi.nlm.nih.gov/36599349/)]
  - Peter did a [podcast on this with Matt Kaeberlein [episode # 222]](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/)
  - It’s more senescence cells, more inflammation, decreased nutrient sensing, genetic mutation, epigenetic alteration, telomere attrition, and many other things as well

![](https://peterattiamd.com/wp-content/uploads/2024/11/f2-qps3.png)

**Figure 2. 12 hallmarks of aging**. Image credit: [*Cell* 2023](https://www.cell.com/cell/fulltext/S0092-8674(22)01377-0)

- Measuring the primary aging phenotype is a little bit difficult
  - We don’t have great tools to measure those things
- There are certain things we can measure indirectly
  - Like mitochondrial efficiency can be measured through Zone 2, but it’s not a biomarker in the same way that you can order a blood test
  - Inflammation you can measure
  - Senescence, you can sort of measure a little bit
  - Decreased autophagy is harder to measure
  - Certainly a lot of these things can be more invasive
- The **secondary measures of aging** are the ones that relate to the horseman
  - Even though Eric didn’t describe it that way
  - What are the diseases of aging and how do we measure changes in the factors that drive those?

*In the* [*CALERIE study*](https://pubmed.ncbi.nlm.nih.gov/33957841/)*, the treatment group was undergoing a pretty significant caloric restriction, about 30% caloric restriction, and they were able to measure both primary and secondary markers of aging*

- Remember, this was in a healthy population, so these people were starting with normal markers on the primary side and many on the secondary side

*Results of the* [*CALERIE study*](https://pubmed.ncbi.nlm.nih.gov/32940695/)

***Across the board, [with caloric restriction] all things got better***

- Primary and secondary markers of aging got better

Peter explains, “*What was really interesting on the primary side was they saw an increase in mitochondrial biogenesis in skeletal muscle with the caloric restriction. That’s pretty interesting to me. Again, I think of that as a really important thing that we want to manage as we age. They also saw a reduction in reactive oxygen species, certain inflammatory markers and thymic fat*.”

- We don’t know if reduction in thymic fat would play a role in immune health (maybe, maybe not)
- The thymus does most of its heavy lifting when you’re young, and then it largely becomes involuted
  - It’s mostly an organ that’s there for immune tolerance
  - Not sure what to make of that result

> “*The secondary aging stuff was mostly around markers of insulin resistance, body competition and cardiovascular risk markers. And of course all of those got better*.”‒ Peter Attia

**We talked about the broad topic of metabolic efficiency**

- This speaks to how efficiently a person can utilize food stuff for energy
- Basically you have 2 fates for calories
  - 1 – You can either turn them into ATP for use
  - 2 – You store it for later use
  - 3 – Some of it’s given off by heat as you do work
    - And some of that work is deliberate and non-deliberate

***Something Peter had never contemplated until discussing this with Eric was people that are really, really of high metabolic efficiency probably go on to be much better performers, especially when you look at world-class endurance athletes***

- A big part of it is metabolic and it just comes down to substrate utilization
- For example, how much can they utilize carbohydrates
- If a person is expending 1,500 calories per hour, how close to 1500 calories per hour can they put in their system for a long enough period of time to make this work?

***The answer is on long events, this becomes a rate-limiting factor: how much energy they can consume***

- So, the less energy they need to use to get the ATP, someone who can do the same amount of work for 1,200 calories as another person for 1500 is going to be a better athlete

***But paradoxically, they might struggle more with weight gain later in life, because they’re so efficient at movement, they’re actually going to store more energy that they don’t need***

> “*We talked about a couple of the theories around obesity. What’s pretty clear is that there’s no one theory that explains everything*.”‒ Peter Attia

**Theories around obesity**

- This is probably a topic we’ll explore in more detail with another guest, hopefully next year
- For example, we talked about the **protein leverage theory**
  - Which is that we might all be seeking out a certain amount of protein, and as foods become more protein dilute, we tend to over-consume calories in order to hit our protein targets
  - There are models in which this seems to be the case, but it’s just not clear that it’s the only driving factor
- We talked obviously about **the role of hunger hormones** and [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) being the most interesting of thes
- We have already talked about GLP-1 recently on an [AMA #64](https://peterattiamd.com/ama64/)
  - That’s probably the most exciting thing we have going on right now as far as the science of hunger

**The last thing that Peter took away from this was that exercise doesn’t appear to be a great tool for weight loss**

- Peter knew this was the case, but it was good to have Eric reinforce this

***Weight loss really comes down to caloric deficit***

- The CALERIE study did this deliberately with a 30% or 25% haircut on total calories
- It can also be done indirectly by restricting certain foods, what we call **dietary restriction**
  - If you make that restriction high enough or severe enough, you’re going to reduce calories
- Then **time restriction** limits the window in which you can eat
- Eric is particularly interested in time restriction, and we’ll have him back to talk about that because he’s in the midst of a study that’s trying to answer some of the important questions about time restriction

*However, it seems that exercise really does matter for weight maintenance*

- If you look at studies of people that are exercising and not exercising, but calorie restricting, they’re both going to achieve similar amounts of weight loss
- But when you look at people who exercise versus don’t exercise, once they’ve achieved that weight loss, the people who exercise are far more likely to maintain it than the non-exercisers
- Peter is not sure if that has been replicated in a randomized control trial
- But epidemiologically this is true
  - The risk there is that there’s something else you’re missing
    - Maybe the exercisers have better habits and that’s why they’re more able to achieve weight maintenance

## Measuring energy intake and energy expenditure: techniques and challenges [1:09:45]

**You mentioned 3 aspects of energy balance: intake, storage, and expenditure. Why was energy expenditure the most complex to figure out?**

*If we were able to learn more about that, what does it teach us?*

- We didn’t really talk about it in the podcast, but there’s another way to measure energy expenditure in the free-living world
- Earlier, Peter described the complexity of measuring VO2 and VCO2
- In the free-living environment, you can drink what’s called [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water)
  - Peter also did with Eric way back in the day
  - You drink water that isn’t just H2O, it’s D2O and H2O-13
    - [Peter misspoke, it’s deuterium (2H) and oxygen-18 (18O)]
    - It’s 2 different isotopes of hydrogen and oxygen
  - Drinking that and collecting your urine over the subsequent 2 weeks, they can estimate how much carbon dioxide you’ve breathed out during a 2-week period of time
  - It’s kind of an amazing calculation and that allows you to estimate total energy expenditure
  - Of course, this assumes that your weight was constant during those 2 weeks, and that we know what you were eating from a macronutrient perspective
    - A couple of big assumptions
- It’s probably more accurate than asking people to estimate what they eat
- Most of us could do weight maintenance for 2 weeks
  - Peter’s weight hasn’t changed in 2 years
- Knowing the macronutrient breakdown of what you eat for a couple of weeks and the number of calories per day, that would make it easier to know how many calories to cut to lose 10 lbs. over the next 6 months

**We need a technology to help us track energy intake**

- Something that takes a picture of everything you put in your mouth and it tells you how many calories it is and how many grams of each macronutrient
- Peter thinks AI will help us with
- That’s what he’s way more excited about than anything else in the next decade

**Is that because you think  humans have a hard time estimating their actual intake?**

- Yeah, it’s too hard

**You’ve done some weird studies, going to live in a box for a few days. Was that the one that almost killed you?**

- No, that was an **insulin suppression test**

*What was the point of doing that?*

- There are 2 ways that are the laboratory gold standard to measure insulin resistance/sensitivity
- One is called a [euglycemic insulin clamp](https://en.wikipedia.org/wiki/Insulin_resistance#Hyperinsulinemic_euglycemic_clamp) and the other is called an [insulin suppression test](https://en.wikipedia.org/wiki/Insulin_resistance#Modified_insulin_suppression_test)
- In both tests, you’re being administered intravenous glucose and insulin
- The difference is in one test, they’re clamping the glucose level In the other one they’re not
  - In the other, they’re giving you a fixed amount of insulin and figuring out what your steady state glucose is
- The test went awry when Peter ended up being more insulin sensitive than predicted, and therefore the amount of insulin he had really dropped his glucose
  - It happened very quickly, and by the time it was apparent, the IV delivering the glucose had blown so it wasn’t working
  - So when they injected a bolus of glucose, it didn’t go into his arm, it went into his skin (incredibly painful)
  - Peter was too gunked out to be able to tell them what was happening, even though he knew that the glucose wasn’t getting into his system
- Once they figured it out and put the glucose into the other arm, his glucose went from 30 something to 200 in minutes

## Ted Schaeffer episode: the nuance role of testosterone in prostate cancer, TRT, and the need for better cancer biomarkers [1:14:30]

[#310 – The relationship between testosterone and prostate cancer, testosterone replacement therapy, and tools for predicting cancer aggressiveness and guiding therapy | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer3/) (July 22, 2024)

\*\*\*

**This episode grew out of an email thread, Ted and Peter had a back and forth after the TRAVERSE trial came out**

- We’ve had Ted on a few times and this was a shorter episode to follow-up on 1 specific thing: the role of testosterone in prostate cancer
- There are a lot of men who end up on [testosterone replacement [TRT]](https://en.wikipedia.org/wiki/Androgen_replacement_therapy)
  - Whether it’s directly on testosterone or on something like [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin) which increases testosterone
- They talked about the [TRAVERSE trial](https://pubmed.ncbi.nlm.nih.gov/38150256/), that’s covered in other [podcasts](https://peterattiamd.com/tedschaeffer3/) and [newsletters](https://peterattiamd.com/traverse-trial-and-trt-in-men/)
- The TRAVERSE trial set out to ask the question: what is the impact of testosterone administration, supplemental TRT, in men with respect to prostate cancer and cardiovascular disease?

***The short answer is, it didn’t find that testosterone replacement therapy increased either prostate cancer or cardiovascular disease***

*But there’s a big caveat: they studied men at low risk for prostate cancer and the replacement was really quite paltry*

- These men were taken from being very low to being 50th, 60th percentile
- Peter doesn’t think this really reflects what he would call “real-world” testosterone replacement
- When most men get TRT, we don’t take them to the 50th or 60th percentile, we take them to the 80th or 90th percentile
- Therefore we don’t really have a great sense of this

**This podcast really focused on the role of testosterone in the prostate**

*We learned that benign prostate cells are far more androgen sensitive than cancer cells*

- It’s a very important takeaway
- It means that when you give a man TRT, you are far more likely to over express benign cells than cancer cells
  - Which means you are far more likely to see [BPH (benign prostatic hyperplasia)](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia) than you are to see cancer

*This probably explains the relationship we see between androgen sensitivity and cancer aggressiveness*

> “*The more aggressive a prostate cancer, the less androgen sensitive it is, the less aggressive a prostate cancer, the more androgen sensitive it is.*”‒ Peter Attia

**Walk people through what you mean by androgen sensitive**

- Testosterone is an [androgen](https://en.wikipedia.org/wiki/Androgen)
- Prostate cancer is a very hormonally dependent cancer
- The prostate itself is an androgen sensitive gland
- Just like we talk about breast cancer being estrogen sensitive, that’s an androgen sensitivity

*Remember how testosterone works*

- We talked about this in a previous podcast [[AMA #28](https://peterattiamd.com/preview-ama-28-all-things-testosterone-and-testosterone-replacement-therapy/)]
- Testosterone binds to an [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor)
- The androgen receptor goes into the nucleus and increases DNA expression (or alters transcription)
- And therefore, if you have something that’s very androgen sensitive, it has a high affinity for that
- If you have something that’s not very androgen sensitive, it’s not really going to respond to testosterone

**This point is very counterintuitive for people**

- 1 – The prostate cancers that kill are *not* very androgen sensitive
- 2 – The prostate cancers that don’t kill tend to be more androgen sensitive
  - The benign conditions are the most androgen sensitive

**The other thing Ted points out: testosterone concentration varies dramatically by tissue**

- In general the prostate is more androgen sensitive than a lot of other tissues
- Because of this, we’re grasping at straws in terms of our understanding of the biology here
- When most guys are taking testosterone, they’re not taking it because of their prostate
  - They’re taking it because they want to increase muscle mass and strength and libido and mood

Peter explains, “*This is all dependent on androgen sensitivity of those tissues, which can be completely different from the prostate*.”

***Ted argues that you probably end up saturating the prostate with testosterone long before you saturate some of those other tissues***

**How does all this factor into cancer?**

- This is where it’s pretty interesting
- Ted developed an **androgen receptor activity score** (not something that you’re going to go and get off your shelf): it’s a sum of the expression of 9 genes that are downstream from the androgen receptor complex
- This kind of answers the question. “*What is the activity for this cancer?*”

***This is important to know: if a guy develops prostate cancer, you want to know out of the gate how androgen sensitive it is***

- If it’s really, really androgen sensitive, it might be and it’s otherwise aggressive enough, it might be a candidate for [androgen deprivation therapy](https://en.wikipedia.org/wiki/Androgen_deprivation_therapy)
- But if it’s not, you really wouldn’t want to subject a patient to androgen deprivation therapy because you’re getting not much upside and a lot of downside
  - Because androgen deprivation therapy comes with a ton of negative consequences outside of the prostate

**Peter was amazed by and found very useful the discussion around when do you use TRT and when do you not?**

- You’ll have to go back to this [podcast](https://peterattiamd.com/tedschaeffer3/)
- We talk about the scoring system for prostate cancer and it’s a [Gleason score](https://en.wikipedia.org/wiki/Gleason_grading_system)
  - It’s a marker of basically how aggressive the cancer is
- A **Gleason 3+3** is a cancer that is not very aggressive
  - You diagnose someone with prostate cancer, you do the biopsy and you get a Gleason 3+3, that’s a “watch and wait” cancer
  - It means you have prostate cancer, but it is not shown us that it is going to spread
  - And given the morbidity of this operation, we’re not going to do anything about this
  - We’re going to continue to watch you
- If it progresses to a **Gleason 3+4**, now it’s time to do something
  - We’re going to take that out
- If it’s a **4+4**, we’re definitely going to take that out, no questions asked

*The question might be, if you had a guy with a Gleason 3+3 and he has low testosterone, is it a given that testosterone is contraindicated in him?*

- Peter would’ve assumed the answer is yes
- Ted said, “*No, not at all. If we have a guy with a Gleason 3+3 and his testosterone is 250-300 ng/dL and he’s symptomatic, we’ll give him testosterone*.”
- Ted made the obvious point: if that man had normal testosterone (700 ng/dL), would we suppress it?
  - Of course not
  - We would watch him
  - And so, we’re doing the same thing

***The only time you’re not giving a guy testosterone is the day you find out he’s got a Gleason 3+4 or 4+4 while you’re waiting for treatment***

*Here’s the other point: once the guy has his prostate out, they’re giving him testosterone again*

- Why do we feel comfortable doing that?
  - Take out your high-grade prostate cancer, take you to a PSA or zero, and give you testosterone
- We feel comfortable doing that because we have a biomarker ([PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen))
- We’re going to track that guy’s PSA every 3 months, and if it bumps, we’re going to hold the testosterone while we investigate

**Peter’s takeaways**

- If you’re a Gleason 3+3 (low-grade cancer), you’re in an observation period; and if you need testosterone, you take testosterone
- If you convert to a 3+4 or 4+4 and it comes out and your PSA is now zero; if you need testosterone, you take testosterone

**This got Peter thinking about how much of a benefit it is to be able to track PSA**

- He wishes we had an equivalent biomarker for breast cancer

> “*The biggest takeaway from this whole podcast for me, was the tragedy of all of these women that are out there unnecessarily receiving anti-estrogen therapy because we don’t have a biomarker to track breast cancer.*”‒ Peter Attia

- To be clear, there are absolutely women who need to be on [estrogen deprivation therapy](https://en.wikipedia.org/wiki/Estrogen_deprivation_therapy) (something like [tamoxifen](https://en.wikipedia.org/wiki/Tamoxifen) or [anastrozole](https://en.wikipedia.org/wiki/Anastrozole) or things like that)
- Because they have a very aggressive estrogen-sensitive breast cancer
- And just as if a guy has a testosterone-sensitive cancer that we’re going to go down the [androgen deprivation therapy](https://en.wikipedia.org/wiki/Androgen_deprivation_therapy), we don’t want him to be on androgens
- Similarly, there’s a subset of women for whom we don’t want them having estrogen in their body, but there’s a huge price you pay for estrogen removal
- Peter can’t give you a number, but he would bet that most women receiving estrogen deprivation don’t actually need it
  - Or would be better managed with a biomarker that we can track to see the moment this cancer is an issue and we need to stop the estrogen and address the treatment solution
- Unfortunately today you have many women who have very low-grade tumors ([DCIS tumors](https://en.wikipedia.org/wiki/Ductal_carcinoma_in_situ), which are not even full cancers), they’re still basically buying into at least 5 years of estrogen deprivation
  - They’re not invasive, but they express some amount of estrogen sensitivity
  - This is in addition to doing the definitive treatment, which may be a lumpectomy, may be radiation, maybe more advanced treatments or more aggressive treatments

*The importance of estrogen for bone health*

- If you think back to the last podcast we talked about (with Belinda Beck)
- Think about how many of these women are going through this at the most critical period in their life when they’re still estrogen dependent for bone health
- Not only are they experiencing all the symptoms of estrogen depletion, they’re also experiencing bone loss

Peter says, “*If I could wave a magic wand, the next biomarker I would create would be the liquid biopsy equivalent of a PSA for breast cancer*.”

**Is that a possibility in the future?**

- Peter thinks it’s going to be a genetic test
- We could probably do this now if we had unlimited resources
- It’s not a technology question
- Just as [GRAIL](https://grail.com/) looks for shedding fragments of DNA in the blood
- Just as we talked about with [Max Diehn [in episode #213]](https://peterattiamd.com/maxdiehn/), if you knew a tumor sequence out of the gate, you could create an individual liquid biopsy for a given patient
- The problem is it’s going to be different for every patient, therefore it’s going to be very expensive
- Whereas with the PSA, it’s the same for every patient
- PSA is like a standard $4 test you can order, whereas if you had to do this for every single woman and find out what her mutations were and then build the sequences that would search for that in her blood, it’s just going to be more costly
  - But technically it’s doable as it is

## Peter’s favorite bands [1:25:45]

**If you had to give an elevator pitch on why people should listen to Nickelback, what is it?**

- It’s great music
- How can you be in the gym listening to [Nickelback](https://en.wikipedia.org/wiki/Nickelback), not lifting better?

**Did you ask Belinda to make that part of the LIFTMOR 3 study?**

Peter replies, “*If they do LIFTMOR 3, I think I would do everything they did in the first one and I would just add Nickelback.*”

**What are the top 5 bands for you?**

*Is Nickelback on there?*

- That’s tough; Peter would have to give that some thought
- There are bands like [AC/DC](https://en.wikipedia.org/wiki/AC/DC), [Led Zeppelin](https://en.wikipedia.org/wiki/Led_Zeppelin) that are just such an important part of his existence, and yet he probably doesn’t listen to them as much as he would listen to Nickelback, for example
  - Zeppelin is not great gym music, but if he’s on the airplane, he’ll listen to Zeppelin
- Nick adds, “*Probably a lot of people just smashing their phones listening to this conversation right now.*”

*Who’s the #1 top band of all time?*

- Peter can’t stop watching that video he forwarded Nick and Tyler of [Metallica](https://en.wikipedia.org/wiki/Metallica) playing in Moscow in 1991 for 1.7 million people
  - This is a couple years after the fall of the [Berlin Wall](https://en.wikipedia.org/wiki/Berlin_Wall), right after the Soviet Union collapsed and Russia becomes it own country
  - It’s the first time an American band is allowed to do this, and you pick the best band of that era

**There’s a Metallica lyric called** [**deathstyle**](https://en.wikipedia.org/wiki/Led_Zeppelin)**. Have you heard it?**

- Nick thinks this is a 100% a Peter Attia lyric
- It’s Metallica, ahead of their time

§

## Selected Links / Related Material

**Anna Lembke episode**: [#321 – Dopamine and addiction: navigating pleasure, pain, and the path to recovery | Anna Lembke, M.D.](https://peterattiamd.com/annalembke/) (October 14, 2024) [4:15]

**Episode of** ***The Drive*** **with Karl Deisseroth**: [#191 – Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.](https://peterattiamd.com/karldeisseroth/) (January 17, 2022) | [5:45]

**Episode of** ***The Drive*** **with Joel Jamieson**: [#305 ‒ Heart rate variability: how to measure, interpret, and utilize HRV for training and health optimization | Joel Jamieson](https://peterattiamd.com/joeljamieson/) (June 10, 2024) | [17:00]

**Feng Zhang episode**: [#323 – CRISPR and the future of gene editing: scientific advances, genetic therapies, disease treatment potential, and ethical considerations | Feng Zhang, Ph.D.](https://peterattiamd.com/fengzhang/) (October 28, 2024) [21:00]

**Newsletter about PCSK9 gene editing**: [First Case of Human PCSK9 Gene-Editing](https://peterattiamd.com/pcsk9-gene-editing/) | peterattiamd.com (2022) | [21:15]

**Walter Isaacson’s book about Jennifer Doudna**: [The Code Breaker: Jennifer Doudna, Gene Editing, and the Future of the Human Race](https://www.amazon.com/Code-Breaker-Jennifer-Doudna-Editing/dp/1982115858) by Walter Isaacson (2021) | [36:30]

**Belinda Beck episode**: [#322 – Bone health for life: building strong bones, preventing age-related loss, and reversing osteoporosis with evidence-based exercise | Belinda Beck, Ph.D.](https://peterattiamd.com/belindabeck/) (October 21, 2024) [37:30]

**AMA on bone health**: [#214 – AMA #37: Bone health—everything you need to know](https://peterattiamd.com/ama37/) (July 18, 2022) | [47:45]

**Episode of** ***The Drive*** **with Luc van Loon**: [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) (April 22, 2024) | [51:15]

**LIFTMOR study**: [High-Intensity Resistance and Impact Training Improves Bone Mineral Density and Physical Function in Postmenopausal Women With Osteopenia and Osteoporosis: The LIFTMOR Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/28975661/) | *Journal of Bone and Mineral Research* (S Watson et al 2018) | [52:45]

**Eric Ravussin episode**: [#324 ‒ Metabolism, energy balance, and aging: How diet, calorie restriction, and macronutrients influence longevity and metabolic health | Eric Ravussin, Ph.D.](https://peterattiamd.com/ericravussin/) (November 4, 2024) [55:00]

**CALERIE study, review**: [1:02:15]

- [Effects of caloric restriction on human physiological, psychological, and behavioral outcomes: highlights from CALERIE phase 2](https://pubmed.ncbi.nlm.nih.gov/32940695/) | *Nutrition Reviews* (J Dorling, et al 2021)
- [Beyond weight loss: current perspectives on the impact of calorie restriction on healthspan and lifespan](https://pubmed.ncbi.nlm.nih.gov/33957841/) | *Expert Review of Endocrinology & Metabolism* (M Kebbe et al. 2021)

**Episode of** ***The Drive*** **with Matt Kaeberlein**: [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/) (September 12, 2022) | [1:03:00]

**AMA on GLP-1**: [#320 – AMA 64: New insights on GLP-1 agonists (Ozempic, Wegovy, Mounjaro) – efficacy, benefits, risks, and considerations in the rapidly evolving weight-loss drug landscape](https://peterattiamd.com/ama64/) (October 7, 2024) [1:07:45]

**Ted Shaeffer episode**: [#310 – The relationship between testosterone and prostate cancer, testosterone replacement therapy, and tools for predicting cancer aggressiveness and guiding therapy | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer3/) (July 22, 2024) | [1:14:30]

**Episodes of** ***The Drive*** **with Ted Schaeffer**: [1:14:30]

- [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) (February 4, 2019)
- [#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer2/) (October 2, 2023)

**TRAVERSE trial**: [1:15:00]

- [Prostate Safety Events During Testosterone Replacement Therapy in Men With Hypogonadism](https://pubmed.ncbi.nlm.nih.gov/38150256/) | *JAMA* (S Bhasin et al 2023)
- [Cardiovascular Safety of Testosterone-Replacement Therapy](https://pubmed.ncbi.nlm.nih.gov/37326322/) | *NEJM* (M Lincoff et al 2023)

**Newsletter on the TRAVERSE trial**: [Is testosterone replacement therapy both safe and effective in men with higher cardiovascular risk factors?](https://peterattiamd.com/traverse-trial-and-trt-in-men/) | PeterAttiaMD.com (S Lipman, K Birkenbach, P Attia 2023) | [1:15:30]

**Episode of** ***The Drive*** **that explains how testosterone works**: [#180 – AMA #28: All things testosterone and testosterone replacement therapy](https://peterattiamd.com/preview-ama-28-all-things-testosterone-and-testosterone-replacement-therapy/) (October 18, 2021) | [1:17:30]

**Episode of** ***The Drive*** **with Max Diehn**: [#213 ‒ Liquid biopsies and cancer detection | Max Diehn, M.D. Ph.D.](https://peterattiamd.com/maxdiehn/) (July 11, 2022) | [1:25:00]

§