# #106 – Amesh Adalja, M.D.: Comparing COVID-19 to past pandemics, preparing for the future, and reasons for optimism

**Source:** [https://peterattiamd.com/ameshadalja/](https://peterattiamd.com/ameshadalja/)

---

In this episode, infectious disease and pandemic preparedness expert, Amesh Adalja, M.D., puts the current pandemic into context against previous coronaviruses as well as past influenza pandemics. Amesh also provides his interpretation of the evolving metrics which have contributed to big variations in modeling predictions, whether this will be a seasonally recurring virus, and perhaps most importantly—how we can be better prepared for the inevitable future novel virus. Finally, Amesh explains where he sees positive trends which give him reasons for optimism.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ameshadalja/the_Drive_public.png)

Play

#106 - Amesh Adalja, M.D.: Comparing COVID-19 to past pandemics, preparing for the future, and reasons for optimism

#106 - Amesh Adalja, M.D.: Comparing COVID-19 to past pandemics, preparing for the future, and reasons for optimism

1x15s30s

0:0044:24

## We discuss:

- Amesh’s background in infectious disease [2:40];
- When did the virus actually reach the US? And when did Amesh realize it would pose a real threat to the US? [4:00];
- Comparing and contrasting COVID-19 to previous pandemics like the Asian flu of 1958 and the Spanish flu of 1918 [8:00];
- Will COVID-19 be a recurring seasonal virus every year? [14:00];
- Will a future vaccine be specific to this COVID-19 or will it also cover previous coronaviruses as well? [15:15];
- What does Amesh think might be the true case fatality rate of SARS-CoV-2? [16:15];
- Why did early models over predict infections and deaths by order of millions? [18:30];
- Role of government—How does Amesh view the role of local versus central government in dealing with a future pandemic? [21:50];
- What went wrong with testing and how could we have utilized it more effectively? [25:15];
- Future pandemic preparedness—why Amesh is cautiously optimistic [27:30];
- Should there be different policies and restrictions for places like New York City compared to less populated and less affected places across the US? [30:15];
- Why mass gatherings might be disproportionately driving the spread of the virus [32:30];
- Learning from HKU1, a lesser-known novel coronavirus from 2005 [34:00];
- Thoughts on Sweden’s herd immunity approach [36:10];
- The efficacy of masks being worn in public and what role they will play as restrictions are slowly lifted [37:20];
- What are some positive trends and signs of optimism? [39:15]; and
- More.

§

## Show Notes

## Amesh’s background in infectious disease [2:40]

- Amesh is an infectious disease emergency medicine and critical care physician
- His entire career is focused on the issue of pandemic preparedness, pandemic prediction, infectious disease and national security, and emerging infectious disease
- He’s worked on H1N1, Ebola, and agents of bio-terrorism

> “This is an outbreak that had been on my radar before it hit headlines.”

## When did the virus actually reach the US? And when did Amesh realize it would pose a real threat to the US? [4:00]

**Back in December…**

- He was trying to take what the Chinese were saying at face value
- However, the Chinese were originally reporting this to only be animal to human (and not human to human)
- Amesh was skeptical
- Eventually a [Lancet paper](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)30607-3/fulltext) came out which showed someone who got ill had no contact with a wet market suggesting human to human transmission was possible
- This false reporting by the Chinese gave the virus a “very big headstart” in spreading across the planet

**Do you think it’s possible that this virus was in the United States? Potentially even within an individual prior to December 31st?**

- Won’t rule out the possibility
- May have been sporadic cases
- But the data don’t show that there were widespread cases prior to January

**At what point was Amesh becoming convinced that this was going to enter the US in a manner that was going to pose real difficulty for the country?**

- “I knew it was going to enter the United States almost from the onset.”
- Once it was clearly possible to transmit human to human (Just like H1N1), it wasn’t going to be containable, says Amesh

–*What Amesh did NOT realize was…*

- How difficult it would be to contain in the US
- And that was because our testing capability wasn’t as good as Amesh assumed
- Secondly, many people had mild to no symptoms so it was hard to know who has it much less do contact tracing

> “That became completely unmanageable because we basically were allowing this virus to have about two months of unabated spread in the United States, and that’s something that most of us did not think would happen because we thought that we were much more resilient to these types of infections than we really were.”

## Comparing and contrasting COVID-19 to previous pandemics like the Asian flu of 1958 and the Spanish flu of 1918 [8:00]

- In 1958, a novel flu virus spread in the US killing about 100,000 people
- The worst flu season since then was 2017-2018 which killed ~80,000 people
- Flu has a lot of similarities with coronavirus:
- They both are transmitted through the respiratory route
- They both have symptoms that include coughing and sneezing and sore throat and muscle aches and pains and fever.
- However…
  - This is in ADDITION to the flu
  - In the 50s, people were used to the flu so they sort of took it in stride
  - In 2009 with H1N1, it spread like crazy to 61 million people and started to stress the healthcare system but it has a case fatality rate of less than seasonal flu

*An influenza pandemic still remains the biggest pandemic threat that we face…*

- Some avian influenza has a CFR of 65%
- For example, if [H7N9](https://en.wikipedia.org/wiki/Influenza_A_virus_subtype_H7N9) even figured out how to efficiently go human to human we’d be in a MUCH more dire situation

*With COVID-19…*

- We are fortunate that COVID-19 CFR is less than 1% (maybe as low at .3%)
- “But we didn’t do that great of a job within, in terms of diagnostic testing and hospital capacity and personal protective equipment. So that’s magnified this and that’s the human factor that’s magnified what the virus could do.”

> “I’m a little more worried about our pandemic resiliency based on how badly we’ve handled a 1% case fatality rate, pandemic virus, where you’ve got cascading decisions by governors in States and countries all around the world that really have magnified the damage that the virus has done.”

**It’s better to think about different cities separately than to just look at the US as a whole…**

- Depending on density of population
- When they began social distancing, etc.

## Will COVID-19 be a recurring seasonal virus every year? [14:00]

There are currently 4 types of coronaviruses that recur seasonally

- They cause about 25% of the colds we get
- They are quite mild
- Amesh thinks that SARS-CoV-2/COVID-19 will be a fifth strain of seasonal coronavirus with “intermediate” severity

Why are SARS and MERS not seen seasonally?

- They are **mostly** animal to human

**Summarizing why this will likely be recurring seasonally**:

> “When you look at their outbreaks, they’re very specialized. They’re happening in healthcare facilities have poor infection control and it doesn’t really sustain itself in the human population. Whereas if you look at the other four coronaviruses, the ones that cause common colds, they are ubiquitous. They transmit very easy. They have a mild spectrum of illness which allows people to go about their daily life and spread, and this new novel coronavirus does appear to be more like them in terms of their transmissibility. So that’s why I think that this will be the fifth seasonal coronavirus until there’s a vaccine.”

## Will a future vaccine be specific to this COVID-19 or will it also cover previous coronaviruses as well? [15:15]

- Probably not the first vaccine we get
- But it’s possible that one down the road will cross protect against other types of coronaviruses

## What does Amesh think might be the true case fatality rate of SARS-CoV-2? [16:15]

- It’s been hard to calculate because we have a “severity bias”
- South Korea and Germany has done more testing so Amesh looks at their data
- Germany just showed it to be 0.37%, for example
- Amesh estimates the true CFR to be **between 0.3% to 0.66% range**
- But this is an AVERAGE
- Things like age and underlying conditions make the CFR different

> “Some people will have much, much higher risks and some people have lower risks, and I think that’s sometimes lost in nuance when you try to come up with one number.”

## Why did early models over predict infections and deaths by order of millions? [18:30]

- Some of the earliest predictions from models suggested 200+ million people would get infected and 2-4 million Americans would die
- Those seems to now look like wild over predictions

*What contributed to this?*

- The models have many assumptions
- Each small adjustment in the assumptions can make a huge impact on the end number

*⇒ One example, hospitalization rate*

- **Hospitalization rate was probably overstated**
- There clearly is a severity bias in who gets tested… which leads to a number like 15 to 20% getting admitted to the hospital
- Amesh says the real hospitalization rate is **probably closer to 5%**

“[They were] using the wrong denominator, I think, to come up with what their case fatality ratios are, what their ICU bed needs would be, and what their mechanical ventilation needs would be.”

## Role of government—How does Amesh view the role of local versus central government in dealing with a future pandemic? [21:50]

- US government is unique in healthcare where power is vested at the local and state level and the federal government is more of a coordinator
- Amesh is generally supportive of this set up given that local health departments are the ones running it because they actually know their community, they know their capacities, they know where their gaps are, and they’re able to really be on the ground with the people and able to do great things when it comes to stopping an outbreak
- However, often they are under resourced during a pandemic
- “What you need to really do is have those local health departments actually operating the way that they should be and thought of as part of the whole pandemic response apparatus. Whereas many people think of just the CDC, the NIH and parts of the health and human services department as the main pandemic apparatus.”
- Amesh says that confusing part for the public is that there were some conflicting recommendation from federal to state to local areas

> “I do think that when the process works well with local, state and federal government all in step, all doing the appropriate roles, I do think it works pretty well. You have a locally managed federally coordinated response, which I think is the best way to think about how it would be ideally done.”

## What went wrong with testing and how could we have utilized it more effectively? [25:15]

-The CDC put out guidance that was too restrictive as to who could get tested

- Originally that was…
  - Only people that had traveled to China in the last 14 days
  - Had to have lower respiratory tract symptoms or pneumonia
  - We weren’t testing mild cases and we weren’t testing people that hadn’t come from China

-A better way to do this would have been…

- This is a respiratory virus and as many overlapping symptoms with common colds and flus
- you should think about this in your patients and we are going to allow testing to be done if you have certain risk factors for this
- And they shouldn’t just be restricted to you having severe disease or having traveled to China
- “*That would have changed the way that the general public and clinicians would have thought about this*.”

-We also had a scarcity of testing and reagents and nasal swabs

-AND it was all compounded by bureaucratic hiccups such as the CDC test having to go through FDA emergency use authorization before it could be distributed to the US

## Future pandemic preparedness—why Amesh is cautiously optimistic [27:30]

- Amesh thinks that since this pandemic has impacted so many people from a health perspective but perhaps even more so an economic perspective…
- …that this one will not be forgotten
- In the past, we’ve sort of “reacted” to things like anthrax in 2001, bird flu in 2005, H1N1 in 2009, Ebola in 2013, and then Zika after that
- But once those were gone it sort of faded
- Amesh is optimistic that the people will now prioritize pandemic preparedness and demand that their politicians take the proper steps

## Should there be different policies and restrictions for places like New York City compared to less populated and less affected places across the US? [30:15]

Amesh definitely thinks we should be implementing different strategies across the country

- There are places that can start to think about lessening restrictions
  - Less social distancing
  - Opening up more businesses
  - Opening up schools

**Definitely need to start considering opening up medical centers for non-COVID patients**: “*In places where they’re not inundated because you’re going to get other health consequences that are not captured by the models which are really measurable and will pay for down the road.*”

All this will depend on what’s happening locally:

- How much transmission do you have?
- What is the antibody status of your population?
- What’s your hospital capacity?
- What is your ability to do diagnostic testing?
- Do you have the new rapid tests available in many different places?
- “*All of that can help condition how we get back to normal.*”

Until we have vaccine… the one place where we need to be the *most careful* is **mass gatherings**

> “We can start taking steps and I hope that we start doing it because this cost is something that is measurable and it increases every day and I do think that they’re going to be [other] consequences that are not captured by our models, which are really only focused on coronavirus.”

## Why mass gatherings might be disproportionately driving the spread of the virus [32:30]

- German data recently suggested that mass gatherings that are disproportionately driving the spread
- A mass gathering brings people from wide geographic areas
- At an NFL game, for example, people are close to each other and they are screaming and yelling which results in particles coming from their mouths
- We saw [what happened at a choir practice](https://www.latimes.com/world-nation/story/2020-03-29/coronavirus-choir-outbreak) recently
- Mass gatherings are going to be a challenge until a vaccine comes out because…
- The density
- The fact that people come from different geographic regions and then just disperse
- Mass gatherings are a particular problem when it comes to communicable infectious diseases

## Learning from HKU1, a lesser-known novel coronavirus from 2005 [34:00]

Hong Kong University found a novel coronavirus ([HKU1](https://en.wikipedia.org/wiki/Human_coronavirus_HKU1)) in 2005

- Coronavirus was on their radar because of the 2003 [SARS](https://en.wikipedia.org/wiki/Severe_acute_respiratory_syndrome) situation
- They found HKU1 in some people who had pneumonia that tested *negative* for SARS
- They then looked in other countries and found it in Cleveland in the proportion of patients that were hospitalized for Coronavirus—HKU1 is disproportionately in patients who died or were on ventilators
- “*And it was basically everywhere you looked.*”
- It flew under the radar because we do a poor job of testing for respiratory viruses
- While Amesh doesn’t think SARS-CoV-2 was widespread prior to January in the US, he would not be surprised if there were undiagnosed cases that were “hidden” in our cold and flu season as early as December

“I do think that’s an important lesson to think about with a virus that can spread surreptitiously and you don’t know about it because our **diagnostic curiosity is so bad** for many infectious disease syndromes.”

## Thoughts on Sweden’s herd immunity approach [36:10]

Sweden has sort of elected to not shut down to the extent that other European and Scandinavian countries have.

Peter asks, *Have you paid attention to the transmissibility in Sweden or do you have any comments on it?*

- They’re trying to pursue a herd immunity strategy
- You’re going to see more cases there, which is what they’re aiming for.
- Amesh is a bit worried because their per capita ICU bed numbers are not very high and that’s what we’re really worried about is…
  - Do you put an ICU into crisis?
  - Do you have problems with ventilators?
- Amesh says it will be instructive to learn how they do but thinks it will be a challenge to sort of cocoon the high-risk people

> “It’s all going to depend upon **who** is getting sick and how well they can sequester their high risk groups, which I think is very daunting and challenging.”

## The efficacy of masks being worn in public and what role they will play as restrictions are slowly lifted [37:20]

This is a controversial topic, says Amesh, but he does NOT believe masks are very helpful to the public

“*I tend to be someone who’s not supportive of masks being worn by the public and especially not n95 masks, which I think are in short supply, unclear whether the public can actually bear wearing them for a long period of time because they’re not comfortable to wear*.”

**For those with clear symptoms (e.g., coughing/sneezing)…**

- They should definitely wear a mask in public

**The question is…**For people who are asymptomatic (having no symptoms), *how transmissible are they if they don’t wear a mask?*

- This is an open question, says Amesh
- The CDC made a recommendation to wear homemade masks
- However, Amesh is not sure not sure how well those homemade masks prevent you from spreading it even if you ARE someone with symptoms because they don’t even stop the coughs and sneezes very well based on some studies that have been published.

**Summary of Amesh’s take on the public wearing masks**:

*“I’m someone who doesn’t necessarily think that these masks are going to be very beneficial and they could be paradoxically negative because people may then refrain from washing their hands as much. They may not social distance as much, they may contaminate other people with their mask if they don’t store it properly or wash it…*

*…So I have a lot of concerns about mass, but I think that this is a, a decision that’s going to be made on a political basis and there is enough scientific controversy that I think politicians may use it as a way to move forward in a way that allows us to open schools, open businesses up if they have people wearing masks. But I’m not sure if we’ll get much benefit from them.”*

## What are some positive trends and signs of optimism? [39:15]

Most optimistic about…

- Plateauing numbers in New York, Seattle, California.
- California, for example, is taking ventilators and giving them to other states
- Washington State is dismantling their field hospital that did not see any patients and returning ventilators

–*We hear a lot about the bad places like New York, New Orleans, Chicago, Detroit…*

- But there are places that were preparing for a surge are now downsizing their nursing staff
- Many field hospitals are closing down
- Many ventilators are going back to the national stockpile
- It’s important to know that it’s not going to be doom and gloom and every place

> “All of that makes me very optimistic that we will be able to meet the challenge of this virus without putting any of our hospitals into crisis, that this is going to be a severe challenge for this country, but it’s not something that that is going to break the country.”

§

![](https://peterattiamd.com/wp-content/uploads/2020/04/bio-pic-amesh-500x500.png)

##### Amesh Adalja, M.D.

Dr. Adalja is a Senior Scholar at the Johns Hopkins University Center for Health Security. His work is focused on emerging infectious disease, pandemic preparedness, and biosecurity.

Dr. Adalja has served on US government panels tasked with developing guidelines for the treatment of plague, botulism, and anthrax in mass casualty settings and the system of care for infectious disease emergencies, and as an external advisor to the New York City Health and Hospital Emergency Management Highly Infectious Disease training program, as well as on a FEMA working group on nuclear disaster recovery. He is currently a member of the Infectious Diseases Society of America’s (IDSA) Precision Medicine working group and is one of their media spokespersons; he previously served on their public health and diagnostics committees. Dr. Adalja is a member of the American College of Emergency Physicians Pennsylvania Chapter’s EMS & Terrorism and Disaster Preparedness Committee as well as the Allegheny County Medical Reserve Corps. He was formerly a member of the National Quality Forum’s Infectious Disease Standing Committee and the US Department of Health and Human Services’ National Disaster Medical System, with which he was deployed to Haiti after the 2010 earthquake; he was also selected for their mobile acute care strike team. Dr. Adalja’s expertise is frequently sought by international and national media.

Dr. Adalja is an Associate Editor of the journal *Health Security*. He was a coeditor of the volume *Global Catastrophic Biological Risks*, a contributing author for the *Handbook of Bioterrorism and Disaster Medicine*, the *Emergency Medicine CorePendium*, *Clinical Microbiology Made Ridiculously Simple*, UpToDate’s section on biological terrorism, and a NATO volume on bioterrorism. He has also published in such journals as the *New England Journal of Medicine*, the *Journal of Infectious Diseases*, *Clinical Infectious Diseases*, *Emerging Infectious Diseases*, and the *Annals of Emergency Medicine*.

Dr. Adalja is a Fellow of the Infectious Diseases Society of America, the American College of Physicians, and the American College of Emergency Physicians. He is a member of various medical societies, including the American Medical Association, the HIV Medicine Association, and the Society of Critical Care Medicine. He is a board-certified physician in internal medicine, emergency medicine, infectious diseases, and critical care medicine.

Dr. Adalja completed 2 fellowships at the University of Pittsburgh—one in infectious diseases, for which he served as chief fellow, and one in critical care medicine. He completed a combined residency in internal medicine and emergency medicine at Allegheny General Hospital in Pittsburgh, where he served as chief resident and as a member of the infection control committee. He was a Clinical Assistant Professor at the University of Pittsburgh School of Medicine from 2010 through 2017 and is currently an adjunct assistant professor there.

He is a graduate of the American University of the Caribbean School of Medicine, and he obtained a bachelor of science degree in industrial management from Carnegie Mellon University.

Dr. Adalja is a native of Butler, Pennsylvania, and actively practices infectious disease, critical care, and emergency medicine in the Pittsburgh metropolitan area, where he also serves on the City of Pittsburgh’s HIV Commission and on the advisory group of AIDS Free Pittsburgh. [[centerforhealthsecurity.org](https://www.centerforhealthsecurity.org/our-people/adalja/)]