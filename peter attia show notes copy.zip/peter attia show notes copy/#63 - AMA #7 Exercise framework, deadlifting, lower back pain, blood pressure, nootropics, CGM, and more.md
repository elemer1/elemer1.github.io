# #63 – AMA #7: Exercise framework, deadlifting, lower back pain, blood pressure, nootropics, CGM, and more

**Source:** [https://peterattiamd.com/ama07/](https://peterattiamd.com/ama07/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a wide range of questions from subscribers. Bob Kaplan, Peter’s head of research, asks the questions. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/). You can also watch (or listen) to this full episode on our website at the AMA #7 [show notes page](https://peterattiamd.com/ama07). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- What can I do to prevent/reduce interruptions in sleep due to needing to get up to urinate at night? [2:15];
- Peter’s note card system for organizing his to-do lists [6:15];
- How do I get smarter at reading/understanding the studies (or the media’s interpretation of them) that get the headlines on health and/or disease? [10:30];
- How can I obtain a continuous glucose monitor (CGM) as a non-diabetic individual? [11:55];
- What is the most effective way to bring blood pressure down? [15:00];
- Does Peter use any nootropics? [28:10];
- Peter’s thoughts pertaining to concussions and head trauma [33:00];
- Does Peter structure his exercise plan for lifespan or healthspan? [36:45];
- How did Peter rebuild his lower back strength after his devastating injury during med school? [38:15];
- Peter’s approach to deadlifting with a bad lower back [43:25];
- Did Peter cave and buy a dog? [51:50]; and
- More.

§

The Peter Attia Drive

Exercise framework, deadlifting, lower back pain, blood pressure, nootropics, CGM, and more

§

## Show Notes

## What can I do to prevent/reduce interruptions in sleep due to needing to get up to urinate at night? [2:15]

Step 1: Don’t drink water too close to bed (captain obvious)

Step 2: Avoid alcohol

- Alcohol inhibits a hormone called ADH, antidiuretic hormone, also known as [vasopressin](https://en.wikipedia.org/wiki/Vasopressin)
- Alcohol disproportionately will drive you to want to pee

If you’ve taken those first two steps and you’re still having trouble, you may want to contact your doctor and

- Investigate **prostate size** (men); and/or
- Measure a “post void residual” for [urinary retention](https://en.wikipedia.org/wiki/Urinary_retention) (men and women)

## Peter’s note card system for organizing his to-do lists [6:15]

- Peter carries note cards in a pouch made by [Levenger](https://www.levenger.com/)
- He uses 3” by 5” cards

The system

1. First card (green or white)=daily to do list
2. Second card (pink)=weekly to do list
3. Third card (orange)=patient specific to do list
4. Fourth card (usually white)=long-term “random” things (that sometimes get transferred to the weekly list)

Each item on the to-do list has a “box” next to it to check off items completed:

- Double hash=completed
- Single hash=in progress
- Blank=not yet started

**One final card**=Stupid things he likes to do

- “[Egg boxing](https://peterattiamd.com/egg-boxing-blog/), tearing phone books, counting forks and knives, doing my TSA voice, playing the ‘what if’ game, and pretending to be in a little bit of a rush, and every time I think of another dumb thing I like to do, it goes on that list.”
- “I don’t even know why I carry this.”

## How do I get smarter at reading/understanding the studies (or the media’s interpretation of them) that get the headlines on health and/or disease? [10:30]

Read the five-part Studying Studies blog post written by Peter:

- [Part I – relative risk vs. absolute risk](https://peterattiamd.com/ns001/)
- [Part II – observational epidemiology](https://peterattiamd.com/ns002/)
- [Part III – the motivation for observational studies](https://peterattiamd.com/ns003/)
- [Part IV – randomization and confounding](https://peterattiamd.com/ns004/)
- [Part V – power and significance](https://peterattiamd.com/studying-studies-part-v-power-and-significance/)

> “You want to think of this the way you’d think of taking a course in college, which is you’re not going to master freshman calculus in a week. So you have to sort of put in the time, and the time allows you the reps, and the reps are practicing that. . . That series was designed so that you get to a point where you’re going to become a pretty good armchair critic of the nonsense that is mostly being published and written about.”

## How can I obtain a continuous glucose monitor (CGM) as a non-diabetic individual? [11:55]

**3 CGM devices in the US**

- [Medtronic](https://www.medtronicdiabetes.com/products/guardian-sensor-3)
- [Abbott FreeStyle Libre](https://www.freestylelibre.us/)
- [Dexcom G6](https://www.dexcom.com/g6-cgm-system)
  - Check out [Peter’s conversation about CGM technology with the CEO of Dexcom](https://peterattiamd.com/kevinsayer/)

Note: Any *over-the-counter* CGM device will be a limited version in terms of the information it gives you… *Why?*

“It doesn’t give you real-time information about the glucose. And the reason for that is the FDA, at least as the time of this recording, does not want people to be able to make dosing information about insulin or … Well, actually specifically about insulin for patients with type 1 diabetes without a prescription. In other words, they want to know that someone has prescribed this device to you if you’re in a position where you might make a decision about that. So by not giving you real time glucose information, you would not have that.”

\*NOTE: It might be possible to buy a fully capable version of CGM device on Ebay\*

**The “legit” way to acquire a fully capable CGM:**

- Must come via a prescription from a doctor
- So the issue is not **HOW** someone without diabetes would get a CGM
- It’s the issue of… *do you have to pay for it?*
  - Whether you have type 1 diabetes, type 2 diabetes, or none of the above, *you will still need a prescription for this device*
    - T1D patients usually are covered by insurance
    - T2D patients are sometimes covered by insurance
    - Non-diabetics will not be covered… but they can **pay cash for a CGM**
      - It costs about $8-10 per day to run a CGM
      - So for the non-diabetics, **step 1 is finding a doctor that understands the value in having a CGM**

The future of CGM:

- The future of CGM is to come up with devices that are more consumer-facing
- If you can satisfy the FDA’s requirements on having a device that can’t be used to hurt yourself… then there probably are ways to partition this into less expensive products that are purely for consumers
- As an individual, you’ll just need to decide on the trade-off
  - Are you willing to trade something?
    - You’ll give up accuracy.
    - You’ll give up the real-time nature of feedback
    - (or something along those lines)

For more on CGM and other wearables, check out [Peter’s post on the topic](https://peterattiamd.com/my-view-on-wearables/)

## What is the most effective way to bring blood pressure down? [15:00]

“*This question has plagued the practice of medicine for such a long time.*”—Peter Attia

*What is essential hypertension?*

- Fancy way of saying we don’t know what’s causing it
- “It might be the case that hypertension is so ubiquitous without an obvious cause that to say idiopathic hypertension to describe 80% of the cases of hypertension would just seem wrong, so we can put a whole new word called essential.”

**Hypertension=**any blood pressure with a systolic above 120, a diastolic above 80

The kidneys

- There’s no organ that is more sensitive to hypertension than the kidney
- Kidney function is one of the ways that we track our ability to help patients maintain their blood pressure

Glomerular filtration rate

- GFR is a measure of kidney function
- It’s a scale that goes up to about 120
- Normal is above 90
- If you’re at 75, you’re certainly in no danger of needing dialysis anytime soon,
- However, if you have a GFR of 75 and you’re only *50 years old* that is a bad sign
- By the time your GFR is 20 to 30, you do need dialysis

**How to measure blood pressure:**

*The proper way to measure blood pressure*

- Person has to be sitting down for 10 minutes
- You have to be able to elevate the arm to the level of their heart
- **Papers**: [Blood-Pressure Measurement](https://www.nejm.org/doi/full/10.1056/NEJMvcm0800157) (and here’s [another one](https://www.ahajournals.org/doi/10.1161/HYP.0000000000000087))

*Blood pressure device*

- The [Omron device](https://omronhealthcare.com/blood-pressure/?gclid=Cj0KCQjwyLDpBRCxARIsAEENsrKRC6Fe9fh3v9F4hjkaOfeBg8PF-LwfxT8C922CU9MUwsIcwU9MwTkaAg5kEALw_wcB) very accurate
- Peter requires the patient to be checking their blood pressure at home a couple times a day for a couple of weeks using this method with this device

**⇒ Example of a patient:**

- Average blood pressure is 137 over 89
- He has hypertension
- First thing I look at is actually the **uric acid level**
- The relationship between uric acid and hypertension is one of the least well known facts by physicians
- Peter, for example, says **it doesn’t make sense to try to medically correct hypertension if a patient has a uric acid level of above ~5**

*Treating uric acid levels*

- Dietary methods
  - Lowering fructose intake
  - Lowering ethanol intake
  - Lowering meat intake

*What are the reference ranges for uric acid?*

- The reference range on Peter’s lab is about 2.1 to 6.9
- And that’s what’s considered “normal”
  - That said, just being inside the range doesn’t mean you should pay attention
  - If you are a 6.5, you still want to push it down to 5 or so
  - “*There’s nothing about being within the lab range that we consider ideal.*”
  - Remember that the normal range is usually calculation looking at the overall population (many of which are unhealthy, obese, diabetic, etc.)
  - Reference ranges on uric acid (and liver function tests, and many others) are not optimal. . .**Optimal is not “normal”**
- Peter’s target is for patients is below 5
- G*enetics effect on uric aci*d

- Uric acid levels are heavily influenced by genetics
- Sex difference: if you take the population mean of men versus women, it’s probably different by a full two points and that is NOT reflected on the reference ranges

**Nutrition, body weight, and blood pressure**

- In parallel with correcting uric acid, Peter is correcting nutrition in patients with the goal of weight loss/fat loss

*What is the relationship between excess body weight/fat and blood pressure?*

The conventional thought is…

- Excess body fat drives blood pressure, so therefore losing weight leads to a lower blood pressure
- At the zeroth order that is true.
- There is no denying that the more weight you put on, the more your blood pressure goes up, and the reverse, is correct.

Where you could push back…

- The weight loss may be a proxy for *something else* that’s going on
- In other words, when a patient starts eating better and exercising and sleeping better, they will lose weight and their blood pressure will improve
- “It’s not entirely clear to me that it’s the reduction of weight that’s driving it”

⇒ [Sam Klein paper looking at liposuction patients](https://www.nejm.org/doi/full/10.1056/NEJMoa033179)

- You suck 30 pounds of fat off somebody and they’ve lost 30 pounds
- Yet their blood pressure, nor any of their other metabolic markers get better

**The medical option for treating blood pressure**

- After all of those things, there’s still a subset of patients who don’t meet their goal
- And in those cases, there are different classes of drugs to treat medically:
- Beta blockers to calcium channel blockers to ACE inhibitors to angiotensin receptor blockers technicall to diuretics, and so on
- There’s an entire algorithm for figuring out what combination of drugs will work best in a particular individual

**Fasting and blood pressure**

Bob says a couple papers ([this one](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5819235/) and [this one](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0209353)) showed how quickly fasting could correct blood pressure

- After just a few days of fasting, patients were seeing their systolic and diastolic numbers were coming down

*⇒ Peter’s take*:

> “Fasting is the most important tool in the body…there is nothing that will lower insulin faster than a fast. Ketogenic diets, low carb diets, not a chance. Fasting will lower insulin more than anything.”

**20% of people may have “essential/idiopathic” hypertension (Peter’s intuition)**

- Peter says the term essential hypertension should only be used once you’ve checked everything else off the box.
  - Once the uric acid is normalized
  - weight is normalized
  - diet is corrected
  - sleep is corrected
  - once they’re exercising
- The patients left after all that with high blood pressure… **\*That\* is essential/idiopathic hypertension.**

*Do you look at fasting insulin? Does that correlate in general?*

- It does correlate
- However, he hasn’t done the multivariate regression analysis to know if it’s an independent predictor
- But even if it was a predictor, that doesn’t necessarily say it’s causal
- Here are a few papers that explore the relationship between hyperinsulinemia and hypertension and whether there is a **causal** role (high insulin ⇒ hypertension)
  - [Park et al., 2013](https://www.ncbi.nlm.nih.gov/pubmed/23122695)
  - [Xun et al., 2013](https://www.ncbi.nlm.nih.gov/pubmed/24132974)
  - [Christlieb et al., 1985](https://www.ncbi.nlm.nih.gov/pubmed/3908323)
  - [Bönner, 1994](https://www.ncbi.nlm.nih.gov/pubmed/7898093)

⇒ Bob mentions [paper by Phinney and Volek](https://blog.virtahealth.com/potassium-sodium-ketogenic-diet/) where they talk about  angiotensin and how the kidney reabsorbs water and what happens when you lower insulin levels

**Fasting and low carb diets combined with blood pressure medicine**

- A big part of that weight loss is water loss and the water loss itself drops blood pressure
- This might explain why sometimes people who start off with normal blood pressure, when they go on ketogenic diets, they get quite lightheaded
- Diabetics, or someone on an anti-diabetic …
  - they are basically hyperglycemic, they’re hypertensive
  - So it’s actually somewhat dangerous for them to either fast or go on a low carbohydrate diet without the doctor watching the medication

## Does Peter use any nootropics? [28:10]

In general,

- He doesn’t take almost anything for nootropic purposes
- Peter says he is recalcitrant to almost every drug ever created (doesn’t have much effect in him good or bad)
  - Example, caffeine, he can pound espresso and you wouldn’t know this difference

[Modafinil](https://en.wikipedia.org/wiki/Modafinil) (brand name Provigil)

- It’s a medication made to treat sleepiness due to narcolepsy
- Peter will use this for jet-lag purposes 3 or 4 times a year

⇒ For more detail, listen to [Peter’s “jet lag protocol” in AMA #4](https://peterattiamd.com/ama04/)

- He also used it a ton in med school to stay alert for crazy long shifts on minimal sleep
- In short, modafinil keeps you awake and alert
- Some people will use it on days that need to feel their sharpest (e.g., for a big presentation)
- Modafinil is a drug that is typically dosed from 100 to 600 milligrams
- Most people don’t need more than 200 mg (Peter needs 400 mg)

Low-dose [adderall](https://en.wikipedia.org/wiki/Adderall)

- \*Peter has never tried this
- Some people he knows take about 5 grams for the nootropic benefits

[Lion’s Mane](https://en.wikipedia.org/wiki/Hericium_erinaceus)

- Peter knows people who says this gives them adderall-like effects

In general,

- It’s very user-specific with all these things
- And some may produce results simply through the [placebo effect](https://us15.campaign-archive.com/?u=21bc5f75235505c27ce465f90&id=1ce39b914d)

*Do we know the mechanism of action of these nootropics?*

- Adderall in an amphetamine, so we know why it’s working
- With modafinil, there is very little known about how it works, but it’s been used for so long (e.g., in the military) without long term side effects that it appears to be very safe

*Does modafinil appear habit forming? Do you build a tolerance for it?*

- No, it certainly doesn’t appear habit-forming
- And once a patient finds what their dose is they generally can stick with that
- Amphetamines, by contrast, is the opposite (addictive and a need to up the dosage over time)

## Peter’s thoughts pertaining to concussions and head trauma [33:00]

Peter’s tells the story of his brother’s head trauma

- Years ago, Peter’s brother was on a bike and collided head to head with a pedestrian
- They both suffered devastating head injuries
- Peter’s brother suffered a TBI that affected his sensitivity to light and noise
- To this day, he can hardly hear you speak if there is too much ambient noise around
- “He describes it probably as the most difficult thing he’s ever been through certainly in the first 12 months after that.”

*Are exogenous ketones protective?*

- Reasonable evidence that in the very, very, very short term insult the ability to use exogenous ketones to mitigate some of the impact (been looked at in the DOD for head trauma in combat)

\*See [Peter’s interview with Dom D’Agostino](https://peterattiamd.com/domdagostino/) for more on ketones and head injuries

*APOE genotype*

- The literature would suggest that different APOE genotypes could predispose people differently
- So an [E4 gene might have a greater sensitivity than an E3 or an E2](https://www.ncbi.nlm.nih.gov/books/NBK299179/)

## Does Peter structure his exercise plan for lifespan or healthspan? [36:45]

- These don’t have to be mutually exclusive
- Peter trains for both lifespan and healthspan

Peter’s approach to exercise has four broad categories

1. Stability
2. Strength
3. Aerobic efficiency
4. Aerobic performance

They build upon each other, they’re integral to your fitness, not just your fitness in the way people think about it, but your overall ability to function as you age.

\*Of the four categories, the one that is *most lacking* is **stability\***

- Stability=Peter works on something in stability **every single day**
- Strength=three days a week
- Aerobic=three hours a week (i.e., three or four sessions that total three hours)
- Anaerobic work=twice a week

“The ‘WHY’ will come out of the [future] video.”

## How did Peter rebuild his lower back strength after his devastating injury during med school? [38:15]

> “*The single greatest risk to my longevity is my lower back.*”

==> Here is [Peter’s post about his lower back injury](https://peterattiamd.com/what-does-lower-back-pain-have-in-common-with-low-carb-eating/)

- In med school, a surgeon operated on the wrong side of this back (and subsequent surgeries were required to fix the error)
- Peter needed [complete laminectomies](https://en.wikipedia.org/wiki/Laminectomy) at the [L5-S1 level](https://www.slippeddisctreatments.com/spinal-disc-problems/according-to-location/lumbar-disc-problem/l5-s1-disc-problem/)
- The lamina are the pieces of the vertebral bodies that actually provide a second layer of support
- You have vertebral bodies that are sandwiching these discs
- but then you have the lamina and the facets (the bony prominence of the spine) behind it
- So when you fully transect the lamina at a level, you now all of a sudden have created a huge instability there

*Did Peter need a fusion?*

- A fusion is how you would “fix” it if that instability becomes too great
- That did not appear to be the case, but to this day if you look at an MRI of my back you can actually see a sagittal section of my back
- But Peter’s back is currently in pretty horrible shape

⇒ See [Peter’s instagram post](https://www.instagram.com/p/BwVyo4ZgpRA/) with results from his full-body MRI

**Pain is a powerful tool**

> “Pain is a very powerful tool to change behavior because it’s there to correct a movement pattern.”

- After the injury, Peter was “out of commission” for about a year due to back pain
- He had to “relearn” how to do simple tasks that we take for granted in a way that didn’t hurt his back
- Example,
  - Had to figure out how to brush his teeth a new way
    - He could no longer lean over the sink because leaning over the sink created too long a moment arm on the torso and it created too much strain on the lower back
    - In that process he realized how important it was to be able to stabilize his torso
  - Also, same goes for getting out a car, putting on pants, etc.

## Peter’s approach to deadlifting with a bad lower back [43:25]

> “If you load a bar correctly and you do a deadlift and you experience pain, that doesn’t mean deadlifts are bad, that doesn’t mean that you are bad or that you are injured or that there’s something wrong with you. It just means that in that moment you are not loading your body correctly.”

**Why does Peter do deadlifts?**

Two reasons:

   1) It’s the ultimate test of whether he is loading correctly

- If it’s hurting, he knows he’s doing some incorrectly, so he better fix it
- Because if he doesn’t fix it, he will undoubtedly do another movement wrong and hurt himself at some point
- **The deadlift is like a hot oven**: When it hot and you touch it, it hurts, and that’s a good thing… because imagine if there was something just as damaging as the hot oven but it didn’t hurt?

   2) If done correctly, if becomes *therapeutic* to your back

\*See Peter’s recent [instagram post about deadlifting as a tool for auditing your movement](https://www.instagram.com/p/Bzxu2fXga0-/)

**Deload your spine with deadlifting?**

- When the [ischial tuberosity](https://en.wikipedia.org/wiki/Ischial_tuberosity) is in the right position, when the [lumbar spine](https://en.wikipedia.org/wiki/Lumbar_vertebrae) is in the right position, when the [thoracic spine](https://en.wikipedia.org/wiki/Thoracic_vertebrae), the shoulders, everything is in the right position **you actually deload the spine doing a deadlift**… *you don’t compress it*

*Straight bar or hex bar?*

- Back in the day, it was all straight bar, narrow stance, reverse grip
- Today, he uses a hex bar

*Why hex?*

- It is absolutely, positively, hands-down easier
- It allows for much more flexibility of foot placement

*Why use a straight bar?*

- The reason you want to do a *straight bar* deadlift is because you’re competing in a sport called powerlifting because that’s the rule of the sport
- Not really any example in athletics that requires you to be that low to initiate your force

*Are you getting low enough with a hex bar?*

- For all the purists who want to knock the hex bar…
  - They might say, “*You don’t get low enough.*“
  - Peter’s rebuttal would be… “*Okay, tell me why I need to be lower? Because for the sport that I’m training for, which is just life, I don’t need to be lower*.”

**Squatting**: *Do you really need to be parallel?*

- Peter says, no.
- And it’s especially unnecessary to go “ass to grass”
- It’s fine too if your body permits it, but you don’t need to
- Whether you can go that low will depend on the flexibility of your ankle joints, knees, and hips
- The bigger reason that I don’t like going ass to grass …
- It’s very unlikely that a person can do a squat like that and maintain a neutral lumbar spine under load
- It absolutely puts you in the worst spine position
- “I see no upside to doing that under load. . .I think you are inviting an unnecessary strain on your back.”

*Mechanics ⇒ consistency ⇒ intensity*

- Bob says that only after you’ve got the mechanics down, and you are consistent, then and only then should you add weight/intensity
- Peter agrees, and says that he has dropped the Tabata deadlifts (225 lbs on the hex bar and you do as many as you can for 20 seconds, rest 10 seconds, and do it 8 times)
- He dropped it because fatigue deteriorates form and 225 lbs might not have been heavy enough for Peter to feel the pain signal of bad form

**Prepping your body for a deadlift**

- Peter does 3 things in prep for a deadlift (see future video for more detail)
- They all center around stabilizing his pelvic floor, stabilizing his hips, and learning to basically fire directly up using a single leg with the hip, the sit bone, the ischial tuberosity down.

## Did Peter cave and buy a dog? [51:50]

- Despite pressure from his Olivia, Peter has managed to resist buying a dog
- For the record, Peter likes dogs
- Peter is worried about how the work related to the dog will get distributed amongst the family
- He is willing to do 5% of the work, that is it
- Realistically, he sees his daugther undertaking 15% of the work
- So, where’s the other 85% coming from? *The chickens???*
- For now, it’s in the best interest of the family (and the dog) to hold off for now (in Peter’s humble opinion)

§

## Selected Links / Related Material

**Sleep AMA episode with Matt Walker**: [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/) | Peter Attia (peterattiamd.com) [2:00]

**Woman dies from drinking too much water in a “Hold your wee for a Wii” contest**: [US woman dies after water contest](https://news.bbc.co.uk/2/hi/americas/6261509.stm) | (news.bbc.co.uk) [6:00]

**Peter’s note card pouch was made by this company**: [Levenger](https://www.levenger.com/) | (levenger.com) [6:45]

**People to Kill scene from Billy Madison**: Steve Buscemi | Curtis Bouvier (youtube.com) [10:15]

**The Studying Studies article series for learning how to read and critique papers**: [10:30]

- [Part I – relative risk vs. absolute risk](https://peterattiamd.com/ns001/)
- [Part II – observational epidemiology](https://peterattiamd.com/ns002/)
- [Part III – the motivation for observational studies](https://peterattiamd.com/ns003/)
- [Part IV – randomization and confounding](https://peterattiamd.com/ns004/)
- [Part V – power and significance](https://peterattiamd.com/studying-studies-part-v-power-and-significance/)

**CGM devices**: [12:00]

- [Medtronic](https://www.medtronicdiabetes.com/products/guardian-sensor-3)
- [Abbott FreeStyle Libre](https://www.freestylelibre.us/)
- [Dexcom G6](https://www.dexcom.com/g6-cgm-system)

**Episode of the Drive about CGM technology with the CEO of Dexcom**: [#54 – Kevin Sayer, CEO of Dexcom: Continuous glucose monitors – impact of food, sleep, and stress on glucose, the unmatched power of CGM to drive behavioral change, and the exciting future of CGM](https://peterattiamd.com/kevinsayer/) | Peter Attia (peterattiamd.com) [12:00]

**Video of Peter discussing why CGM is so valuable**: COMING SOON in 2019! [14:00]

**How to properly measure blood pressure**: [18:00]

- [Blood-Pressure Measurement](https://www.nejm.org/doi/full/10.1056/NEJMvcm0800157) (Williams et al., 2009)
- [Measurement of Blood Pressure in Humans: A Scientific Statement From the American Heart Association](https://www.ahajournals.org/doi/10.1161/HYP.0000000000000087) (Muntner et al., 2019)

**Blood pressure measurement device Peter says is very accurate**: [Omron](https://omronhealthcare.com/) | (omronhealthcare.com) [19:00]

**Study showing liposuction does not improve blood pressure**: [Absence of an Effect of Liposuction on Insulin Action and Risk Factors for Coronary Heart Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa033179) (Klein et al., 2004) [23:45]

**The papers on fasting that Bob mentioned**: [25:00]

- [Is fasting safe? A chart review of adverse events during medically supervised, water-only fasting](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5819235/) (Finnell et al., 2018)
- [Safety, health improvement and well-being during a 4 to 21-day fasting period in an observational study including 1422 subjects](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0209353) (de Toledo et al., 2019)

**A few papers that explore whether there is a causal relationship between hyperinsulinemia and hypertension**: [27:00]

- [Park et al., 2013](https://www.ncbi.nlm.nih.gov/pubmed/23122695)
- [Xun et al., 2013](https://www.ncbi.nlm.nih.gov/pubmed/24132974)
- [Christlieb et al., 1985](https://www.ncbi.nlm.nih.gov/pubmed/3908323)
- [Bönner, 1994](https://www.ncbi.nlm.nih.gov/pubmed/7898093)

**Phinney and Volek paper discussing angiotensin and how the kidney reabsorbs water and what happens when you lower insulin levels**: [The Importance of Managing Potassium and Sodium as Part of a Well-Formulated Ketogenic Diet](https://blog.virtahealth.com/potassium-sodium-ketogenic-diet/) (Phinney, Bailey, and Volek) [27:00]

**The movie loosely based around the drug, modafinil**: [Limitless](https://en.wikipedia.org/wiki/Limitless_(film)) | (wikipedia.org) [29:30]

**AMA where Peter explains his jet lag protocol**: [#45 – AMA #4: sleep, jet lag protocol, autophagy, metformin, and more](https://peterattiamd.com/ama04/) | Peter Attia (peterattiamd.com) [29:45]

**Dom D’Agostino on The Drive discussing exogenous ketones used to mitigate some of the impact on a brain injury**: [#05 – Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer](https://peterattiamd.com/domdagostino/) | Peter Attia (peterattiamd.com) [36:00]

**APOE genotypes could predispose people differently to the impact of a head injury, E4 gene might have a greater sensitivity than an E3 or an E2**: [Evaluating the Effects of APOE4 after Mild Traumatic Brain Injury in Experimental Models](https://www.ncbi.nlm.nih.gov/books/NBK299179/) (Rebekah Mannix and William P Meehan, III., 2015)  [36:15]

**Peter’s video explaining his philosophy for exercise**: COMING SOON in 2019 [37:00]

**Peter’s blog post about his lower back injury**: [What does lower back pain have in common with low carb eating?](https://peterattiamd.com/what-does-lower-back-pain-have-in-common-with-low-carb-eating/) | Peter Attia (peterattiamd.com) [38:15]

**Peter’s instagram post showing results from his full-body MRI**: [@peterattiamd](https://www.instagram.com/p/BwVyo4ZgpRA/) | (instagram.com)  [40:30]

§

## People Mentioned

- [Matt Walker](https://twitter.com/sleepdiplomat?lang=en) ([sleep AMA)](https://peterattiamd.com/matthewwalkerama/) [2:00]
- [Tim Ferriss](https://twitter.com/timferriss?lang=en) (encouraged Peter to write down all the stupid things he likes to do) [9:30]
- [Rick Johnson](https://www.cudoctors.com/Find_A_Doctor/Profile/9426) (uric acid expert) [20:00]
- [Bradley Cooper](https://en.wikipedia.org/wiki/Bradley_Cooper) (actor in Limitless) [29:30]
- [Paul Attia](https://twitter.com/papaalphablog?lang=en) (head injury, Peter’s brother) [33:00]
- [Dom D’Agostino](https://twitter.com/DominicDAgosti2?lang=en) (TBI and exogenous ketones) [36:00]

§