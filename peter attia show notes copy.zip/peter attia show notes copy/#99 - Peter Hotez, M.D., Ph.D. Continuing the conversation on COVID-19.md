# #99 – Peter Hotez, M.D., Ph.D.: Continuing the conversation on COVID-19

**Source:** [https://peterattiamd.com/peterhotez2/](https://peterattiamd.com/peterhotez2/)

---

In this episode, Dr. Peter Hotez M.D., Ph.D., Dean for the National School of Tropical Medicine Baylor College of Medicine, returns to continue the conversation on COVID-19. Dr. Hotez informs us on how we can gauge the number of infected people, behaviors to reduce the probability of becoming infected, and the inconsistency of hospitalizations among young adults between different countries. Dr. Hotez underscores the continued uncertainty in many virus-related developments, but ends with some points of optimism.

Disclaimer: This is information accurate as of March 19, 2020, when it was recorded.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/peterhotez2/the_Drive_public.png)

Play

#99 - Peter Hotez, M.D., Ph.D.: Continuing the conversation on COVID-19

#99 - Peter Hotez, M.D., Ph.D.: Continuing the conversation on COVID-19

1x15s30s

0:001:06:21

## We discuss:

- How to gauge true number of infected people [5:45];
- Reducing the probability of getting infected [22:45];
- Inconsistency by country in infected young people [27:15];
- Conferred immunity, seasonality, and repurposed therapeutics [30:30];
- Vaccine development [39:30];
- Practical behaviors to reduce risk of transmission [46:00];
- Mental health resource and funding [51:00];
- Points of optimism [56:00]; and
- More.

## Show Notes

## How to gauge true number of infected people [5:45]

- ~13k cases confirmed in US as of midafternoon time of recording PST on March 19 2020

*How does that translate to an estimate of actual people infected?*

- Every day there is a large increase because there is testing underway
- We don’t have a real sense of % population infected and we are just beginning to pick up existing transmission
- Physicians in major hospitals are seeing a lot of cases and feeling overwhelmed meaning:
  - Despite number of tested cases, there is still a ramp increase
  - Creates concerned for system threshold to care for the sick

**Distribution of total U.S. cases is where we should focus concern**

- The *distribution* of absolute case numbers in the US is more insight-producing rather than total case numbers

Evaluating confirmed infected case multiplier (estimation):

- - Takes into consideration:

1. What is the assumed number of days to a fatality
2. What is the assumed fatality rate?

**The status of U.S. healthcare delivery**

- Unclear how CDC made decisions around testing
- Peter has deflected these questions because there were missteps made and a committee will have to retrospectively evaluate to make sure the same mistakes are not made in the future
- It is a matter of figuring out how we rapidly fix the problem around hospital system stress

**Rate limiting step in healthcare delivery**

- New York City as a case example ….
  - Doctors and nurses are demoralized: initial breakdown of trust
  - Seeing colleagues get sick and inadequate support and preparation
  - Disconnect between state and federal government management

 **No longer a disease of young adults**

- Destabilizing for young physicians
- Front line healthcare workers are getting sick

*What is the solution for staff workers getting sick?*

- Heavily-hit Covid19 areas are likely experiencing understaffed medical support
- The whole healthcare system was fragile to begin with due to high demand on physicians
- There is no clear solution

*Could we expand the U.S. public health service?*

- Bring in individuals to train as medics who are currently under Furlow?

## Reducing the probability of getting infected [22:45]

**How much insight do we have about transmissibility?**

- There is not a lot of new information about virus survival time on various surfaces
- We know that it can live on cardboard but how relevant is that?
  - CDC came out with guidelines that loosened criteria of exposure
  - A desperate move to have people remain in the workforce
  - Convalescent serum could help people remain in the workforce as a form of prophylaxis
- White House came out with press report to create convalescent serum

- The recent study of blood type and susceptibility: not clear how relevant it is yet
  - Study out of china showing that type O blood type had reduced risk
  - Protective antibodies but not immunity like a convalescent serum

## Inconsistency by country in infected young people [27:15]

- Younger age group in Italy getting ill but not seen in China
- High number of hospitalized people between 20-40 years old, accounting for ~33% of hospitalizations in the U.S.
- ~50% in the U.S. are under the age of 54 years old – very different than what was observed in China
  - Individuals aren’t dying at as high rates as older population groups but they are still hospitalized
  - Could this be due to vaping?

- Require good epidemiology on young patients to identify differences

## Conferred immunity, seasonality, and repurposed therapeutics [30:30]

- Non-human primates show that once exposed, the infection should confer immunity
- The federal government thinks that the pandemic should last 18 months
  - Operating under the assumption that the virus comes back in the fall
  - Or could be anticipating that there is a vaccine in 17 months, but Peter does not think this is realistic
  - Peter hopes that the model is not dependent on vaccine development

Repurposed drugs…

- Published Kaletra paper interpretation: drugs administered when viral progression is too far gone is not helpful
- Didier Raoul preliminary work has looked at hydroxychloroquine (HCQ)
  - Small study reveals HCQ potential but has yet to be rigorously tested

We are on a steep learning curve around ARB and mechanistic action …

- ARBs have the ability to block viral entry but on the other hand, it may upregulate ACE2 receptor
- They may have anti-inflammatory effects
- Preliminary look on camostat out of Japan seems promising

## Vaccine development [39:30]

*Should we be considering a universal coronavirus vaccine rather than SARS or Covid-19 specific?*

## Practical behaviors to reduce risk of transmission  [46:00]

- Peter Hotez does not believe receiving mail to be an issue
- Real risk is close, personal contact with someone infected

## Mental health resource and funding [51:00]

> “The psychological devastation on the United States […] is going to be almost as big as the damage of the infection.” —Peter Hotez, M.D., Ph.D.

## Points of optimism [56:00]

- We are seeing scientists put at higher esteem
- At times of stress, people are looking to scientists and in leadership roles
- Science communication and data sharing has improved

> “The heroism we are seeing of physicians of nurses… there is going to be a new awakening behind the medical community…” —Peter Hotez, M.D., Ph.D.

§