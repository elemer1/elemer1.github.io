# #171 – Steve Austad, Ph.D.: The landscape of longevity science: making sense of caloric restriction, biomarkers of aging, and possible geroprotective molecules

**Source:** [https://peterattiamd.com/steveaustad/](https://peterattiamd.com/steveaustad/)

---

Steve Austad is a distinguished professor of biology at the University of Alabama and director of one of the Nathan Shock Centers of Excellence in aging biology. Steve’s current research seeks to understand the underlying causes of aging, specifically with a long-term goal of developing medical interventions that slow the age-related decay of human health. In this episode, Steve tells Peter about his unusual childhood and stints as a cab driver and lion tamer. He goes on to describe what led to his focus on studying aging and some of the major challenges and limitations of working with laboratory animals. Steve and Peter talk about the relationship between caloric restriction and lifespan, including some of the most important studies exploring this question. Additionally, they hypothesize what might explain the sex-related differences in longevity between men and women, explain the importance of finding longevity biomarkers, and discuss the most promising molecules as potential longevity agents.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/WNKRSiSGvGE)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/steveaustad/the_Drive_public.png)

Play

#171 - Steve Austad, Ph.D.: The landscape of longevity science: making sense of caloric restriction, biomarkers of aging, and possible geroprotective molecules

#171 - Steve Austad, Ph.D.: The landscape of longevity science: making sense of caloric restriction, biomarkers of aging, and possible geroprotective molecules

1x15s30s

0:002:26:54

## We discuss:

- Steve’s background and unusual childhood [2:30];
- Steve’s adventures driving a cab in New York City [9:00];
- How Steve drove to LA and accidentally became a lion tamer [13:30];
- How Steve’s early graduate school experiences led him to study longevity [23:00];
- The challenges and limitations of working with lab mice [30:45];
- The connection between caloric restriction and lifespan [43:00];
- Mice vs. rats and rodent aging experiments [51:15];
- The impact of dietary composition and the harm of sucrose: Comparing two caloric-restriction studies in monkeys [56:00];
- Challenges of studying animals due to major differences in the lab animal vs. wild animals [1:10:00];
- Human studies of calorie restriction [1:24:45];
- Better dietary protocols for humans: Alternatives to long-term caloric restriction [1:33:45];
- The protective effect of fasting [1:38:00];
- Reflecting on the sex differences in human lifespan, and why women have more neurodegenerative diseases [1:45:45];
- The importance of identifying longevity biomarkers and which ones show the potential to change the landscape of longevity research [2:03:30];
- Molecules showing the most promise as longevity agents [2:14:00]; and
- More.

§

## Show Notes

## Steve’s background and unusual childhood [2:30]

- Peter says his learning “increases at a geometric rate” when he talks to Steve and any discussion about longevity needs to begin with Steve’s background
- In high school everyone thought Steve would be a mathematician
  - He didn’t believe his high school bio teacher who said he would be a biologist
  - But he didn’t enjoy math in college at UCLA and switched to English, thinking he would write a great novelist
- When Steve was growing up, his family spent about 6 years traveling around in a trailer (4:51)
  - He went to ~20 different grade schools
  - His dad was a newspaper pressman with a union traveling card that meant any major city newspaper would hire him for a short period of time (5:26)
  - They went to El Paso, Dallas, Atlanta, Miami, Virginia, New York, Detroit, and other places and he read books on his own while they traveled
- Peter wonders if any kid could thrive in such a disruptive setting with no continuity, constantly changing schools and starting over again socially (6:22)
  - Steve was an only child and used to being thrown on his own resources (7:08)
  - As the smallest kid in the class (5’4” and 105 lbs when he graduated from high school), he quickly figured out that he could avoid being beaten up by the bigger kids if he helped them with their homework
  - Steve got injections in high school (perhaps [growth hormone](https://en.wikipedia.org/wiki/Growth_hormone) or [testosterone](https://en.wikipedia.org/wiki/Testosterone_(medication))) and then started puberty and had his growth spurt in college (8:12)

## Steve’s adventures driving a cab in New York City [9:00]

- Steve wanted to pursue writing so he went to NY because the publishing industry was there
- He wanted to “accumulate a lot of experiences in a hurry” to have material for his books (9:18)
  - Frequently hitchhiked around the country (including from LA to NY)
  - Decided to be a cab driver for the experience of it – he drove a cab in NY in the mid-1970s
    - He worked from about 4 pm to midnight or 2 am (10:32)
    - One guy asked him to stop in every bar along the way.  He said he was looking for his wife and would shoot her when he found her. Steve asked him to pay the fare at that point
- NY was much more dangerous then (12:11)
  - Steve would take fares to Harlem but many others wouldn’t (12:43)
  - He was the only driver from his garage who was never robbed, which he attributes to luck (13:07)

## How Steve drove to LA and accidentally became a lion tamer [13:30]

- He eventually moved back to Portland, OR, where he had lived from grades 6-10 (13:42)
  - He was working as a newspaper reporter and taking karate from a teacher who kept African lions at his ranch out in the country
- He agreed to help the karate teacher take a lion to Hollywood to be in a movie
  - He expected there to be a trailer on the car, but the lion rode in back with “no screen, no window, nothing between the front and the back seat”
  - He was supposed to control the lion with a cattle electric prod, but the battery ran out after one use and the lion got restless
  - They walked the lion on a leash in the dark along a country road to tire it out
- At one point the police pulled them over, the lion stepped on the horn, and the cop just wanted them to leave because he had no idea what to do
- When they got to LA, the movie producer offered him a job as a lion tamer even though he was a reporter with no experience (18:18)
  - The guy wanted Steve to live at his house where he was raising lions to take care of them
  - He said the only other people there would be his daughter and his wife Tippi
  - Steve had a crush on the actress named [Tippi Hedren](https://en.wikipedia.org/wiki/Tippi_Hedren) from [*The Birds*](https://en.wikipedia.org/wiki/The_Birds_(film)), and she turned out to be the producer’s wife, so Steve took the job (19:12)
- He had given up on being a writer by then and found that he loved the job and the animals (20:14)

> “I’d almost feel like I’d been given this gift of something that I was always meant to do, but just by luck, it’s just stumbled into it.” —Steve Austad

**What prompted Steve to go back to graduate school?**

- One day Steve was attacked by a lion – it pinned him down and sank its teeth into his leg (20:53)
  - Some people pulled over to look into the compound (in Acton, CA) and see if they could see any wild animals
  - They saw him under the lion and told the front office and other trainers came to rescue him
  - He spent weeks in the hospital and months recovering
- He loved the animals but was bored with Hollywood and the movie business, so he decided to go to graduate school

## How Steve’s early graduate school experiences led him to study longevity [23:00]

- He went to graduate school hoping to study lions in East Africa
  - He did not arrive in east Africa quickly enough to take over the [Serengeti Lion Project](https://www.legendsandlegaciesofafrica.org/serengetilionproject.php)
  - Combined his math ability with his interest in animals and did his PhD on theoretical models of animal combat (why animals very seldom fight to the death)
  - He did a post-doctoral fellowship at a biological station in South America studying social birds
- A colleague was trying to study foxes but kept catching [opossums](https://en.wikipedia.org/wiki/Opossum) in his traps, so he and Steve thought of a project on opossums
  - In the course of the work, they discovered that the [opossums aged very quickly](https://www.uab.edu/reporter/people/awards-honors/item/9250-what-is-the-answer-to-aging-35-years-into-his-research-austad-is-still-asking)
  - They look like cats, but instead of living 10-20 years like cats, they had cataracts and muscle loss by 18 months
- The bird project he was working on originally was eventually published in a prestigious journal, but by then Steve had lost interest in that project and wanted to study aging

**Life after his postdoc in South America**

- He got his first faculty position at Harvard and switched from behavioral evolution to aging (26:16)
  - His first aging study was a field study of North American opossums comparing the way they aged on an island compared to the mainland
  - There was a theory that animals that evolve in low risk environments (without predators) also evolve slow aging
  - Because opossums grow in a pouch, unlike with most wild animals, you can know their birth date
  - He found about a 20% difference in life span in the two groups of opossums (28:10)
  - It was ~1990 so he couldn’t yet sequence the genome of the two groups
  - It turned out to be related to cortisol
- Wanted to do a swap and let them breed
  - He wanted to release island possums on the mainland rather than the other way around to avoid contaminating the island population if it was genetically unique
  - Couldn’t get funding for the study, so he kept possums in the lab, but they don’t do well there and got a flesh-eating infection
  - He went back to the island ([Sapelo Island](https://en.wikipedia.org/wiki/Sapelo_Island) off the coast of Georgia), but armadillos had since been introduced and he worried that the population of possums had been contaminated (30:00)

## The challenges and limitations of working with lab mice [30:45]

- Steve’s experience was in field biology when he started doing laboratory biology, so he had a very different perspective from most people
- Lab animals were very different from the same species in the wild, so he became interested in laboratory evolution (31:39)
  - There is very strong evolutionary pressure on laboratory animals
  - The [B6 mouse](https://en.wikipedia.org/wiki/C57BL/6) is the model used for cancer biology research
    - Many people argue that we should not use B6 strain as the model for cancer therapeutics because the results you get are not likely to apply later on (32:52)
    - Lab mice came from what were called “fancy mice,” bred for various coat colors and textures not unlike the [Westminster Dog Show](https://en.wikipedia.org/wiki/Westminster_Kennel_Club_Dog_Show) (33:37)
    - In the early 20th century, scientists thought these mice would be useful for studying [Mendelian genetics](https://en.wikipedia.org/wiki/Mendelian_inheritance)
    - Inbred them with brothers and sisters mating for hundreds of generations so that they’re genetically identical to one another
  - Became commercially valuable, so selecting for bigger litters, faster growth, and more rapid reproduction
- A friend of Steve’s calls it a “mouse-like object” – it’s genetically identical to the other mice and is called a strain
  - because of inbreeding, it’s [homozygous](https://en.wikipedia.org/wiki/Zygosity#Homozygous) at every locus (exactly the same two genetic variants at every single place in the genome)
  - This makes it very different from humans or any wild animal
- For experiments studying everything from cancer to aging to Alzheimer’s disease, we use this same mouse strain

> “I used to say to people, this is like if we only tested drugs in the same set of twins time after time after time after time.” —Steve Austad

- Our data should not depend on such a bizarre creature
  - They’re at least twice as big as a wild mouse, reach sexual maturity about twice as fast,  have much larger litters, etc.
  - Some strains become blind or deaf at a few months old, others have convulsions if they hear a loud noise
  - “*And this is the fundamental basis of our biomedical research enterprise as it applies to mammals*”
- There are 4,500 species of mammals, and the fact that we’ve had one bizarre species stand in for all others (including ourselves) is a strange approach

> “The culture of evolutionary biology has never really soaked into the laboratory biology. And I’ve kind of made it my goal to try to help with that over my career.” —Steve Austad

**How the ITP program is changing the process of using mice in studies**

- [Interventions Testing Program](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) (ITP) (37:58)
  - The ITP is a program run by the [National Institute on Aging](https://www.nia.nih.gov/) (NIA) at the [National Institutes of Health](https://www.nih.gov/) (NIH)
  - It is a series of studies conducted at multiple institutions to investigate potential treatments to extend lifespan and delay disease and dysfunction in mice
  - Peter recently [interviewed](https://peterattiamd.com/richardmiller/) [Rich Miller](https://medicine.umich.edu/dept/dcmb/richard-miller-phd) on the podcast to talk about the ITP
  - Steve has worked with Rich on projects with different kinds of mice (38:13)
- The ITP creates genetically [heterogeneous](https://en.wikipedia.org/wiki/Homogeneity_and_heterogeneity) mice (every single mouse is genetically unique)
  - But they’re all siblings, so you can recreate the population (but not specific individuals)
  - their ancestors are inbred mice, so they’ve been selected for strange genetic alleles
  - Steve thinks **this mouse model is a huge step in the right direction**
- However, one problem with the ITP mice is that because of the way they are bred, no matter how genetically diverse the mice are, they all have the *same mitochondria* (39:08)
  - Because it interacts closely with the nuclear genotype, the mitochondrial genotype can have a huge impact
  - Steve’s colleague [Scott Ballinger](https://www.uab.edu/medicine/diabetes/genetics/72-scott-ballinger) created mice that have different mitochondria in the same nuclear background and they have very different characteristics
- because all of the current laboratory mice come from a relatively small number of fancy mouse ancestors, they all have the same mitochondria except what has evolved slowly by drift over the last 100 years
  - His colleague’s two mice mitochondria only differ at five individual nucleotides out of 16,500, which is maybe 20-25 genes
  - So we may be missing out on a huge amount of variability from mitochondria
  - Humans have incredibly variable mitochondrial genome

- W*hy don’t we use genetically heterogeneous wild mice bred naturally rather than inbred lab mice*? (40:50)
  - Steve points out there would be a lack of genetic control in that situation (41:16)
  - wild mice don’t seem to breed as well in captivity, so their genes are gradually lost
  - reasonable alternatives are being developed, but “it’s going to take a big change in the culture of the way we do laboratory medicine, I think, before people will accept that”
  - It might not be apparent to some lab scientists how genetically far removed lab mice are from their predecessors, but it’s more obvious to Steve because he came from field biology (42:08)

> “Even the best mouse is still a mouse. It’s still one species, and it’s a very different species than we are. And so even the best mouse model is not going to be enough. We need to know more about general mammalian biology if we’re going to understand our own biology better.” —Steve Austad

## The connection between caloric restriction and lifespan [43:00]

**Earliest work on CR and lifespan**

- Many people are aware of the reported ability of caloric restriction (CR) to extend life span (43:08)
  - Many scientists are working on mimicking caloric restriction through pharmacology, dietary intervention, etc.
- [Clive McCay](https://en.wikipedia.org/wiki/Clive_McCay), a nutritionist at Cornell, was the first person to formally study this beginning in the 1930s (43:54)
  - He was interested in how to make animals grow faster for agricultural purposes
  - he noticed that his animals (fish, dogs) seemed to be staying healthy longer and living longer when he fed them less
  - when he tried it with rats, CR made only females live longer, not males
  - He did not follow up, not appreciating the significance of his own work because he was never really focused on longevity (45:20)

**Steve’s inadvertent realization that CR made spiders live longer**

- After WWII, others started looking more closely at rats and mice (45:57)
- Some people working on invertebrates did it by accident, like Steve himself
  - For his PhD, he was testing mathematical models of animal combat in a small spider
  - He was feeding groups of spiders various amounts
  - When he went back and looked at his data, he found that the less he fed the spiders, the longer they lived

**Work by Walford and Masoro**

- [Roy Walford](https://en.wikipedia.org/wiki/Roy_Walford) and [Ed Masoro](https://barshopinstitute.uthscsa.edu/about-us/edward-joseph-masoro-ph-d/) did research with rodents to try to figure out why CR was associated with a longer lifespan
  - Walford, an immunologist, was convinced it was related to the immune system
- [Biosphere 2](https://en.wikipedia.org/wiki/Biosphere_2) (which Steve wrote about in his [book](https://www.amazon.com/gp/product/0471148032/ref=dbs_a_def_rwt_hsch_vapi_taft_p1_i0)) became an inadvertent experiment in dietary restriction (48:31)
  - people were sealed in a dome for 2 years, but they couldn’t grow as much food as they thought
  - Roy was the doctor in the Biosphere
  - They looked emaciated when they came out

![](https://peterattiamd.com/wp-content/uploads/2021/08/f1.-roy-after-biosphere-2-steveaustad-1024x680.png)

**Figure 1. Roy Walford after 2 years of CR in the biosphere** ([source](https://boingboing.net/2011/10/19/the-biosphere-2-starvation-diet.html))

- Roy died not long after they came out
- In the Biosphere, they did not realize initially how little oxygen they had
  - it was like living at 17,000 feet, so they had to refresh the air in the environment
  - That was likely a bigger problem than the caloric restriction which is what Roy attributed to his health problems later in life (rather than the CR)

## Mice vs. rats and rodent aging experiments [51:15]

- All of the traditional laboratory mice strains came from this small handful of weird ancestors (51:41)
- Rats were used earlier in biomedical research and have been domesticated multiple times all over the world
  - mitochondrial diversity in rats is far greater than in mice
  - Steve wants to use rats more in aging research because we can now do genetic manipulations just as easily in rats as in mice
  - In a rat he’s working with, the two mitochondria differ at 100 nucleotides (DNA letters) instead of 5 with the mouse
  - Much more similar to real-life diversity in mitochondrial genomes
- Steve would like to see something like Rich Miller’s ITP in rats as well
  - “I think I’d have a lot more confidence that something we found in mice might have relevance to people if we found the same thing in rats”
  - we also can do a lot more sophisticated cognitive studies with rats, which are trainable, than we can with mice

**Contrasting results from experiments in mice vs. rats**

- If you disable growth hormone activity in mice, the mice stay healthy and [live](https://pubmed.ncbi.nlm.nih.gov/8900272/) [longer](https://www.pnas.org/content/98/12/6736.short)
  - But a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1850833/) looking at the effect of reduced GH in rats found reduced lifespan
  - Are we getting a biased picture of something like growth hormone because we only really know a lot about its mechanism in mice?
- If you compare dozens of rat and mouse studies, the effect of dietary restriction on life extension is larger in rats (54:48)
  - growth hormone is suppressed by dietary restriction
  - But in an experiment with a natural genetic mutation that disabled growth hormone in rats, they didn’t live longer
  - mice with the same natural mutation did
  - Why is the effect bigger in rats than mice for DR? we don’t know and there are many fewer rat studies than mouse studies
- the biggest effect we’ve ever seen in a mouse and the biggest effect we’ve ever seen in a rat are not that different
- Although it may be true, we don’t yet have enough data to conclude that dietary restriction works better in rats generally than it does in mice

## The impact of dietary composition and the harm of sucrose: Comparing two caloric-restriction studies in monkeys [56:00]

**The basis of the Wisconsin and National Institute of Aging (NIA) experiments**

- Largest aging experiments in non-humans, started in late 1980s
- There were two groups doing the studies, one at the NIA in Bethesda, MD, and one at the University of Wisconsin (56:38)
  - [Rick Weindruch](https://www.nuskinops.com/content/dam/corpcom/Expert%20biographies/Richard%20Weindruch%20BIO.pdf) was involved in both
  - the idea was to see whether the results from lab rodents were replicable in [rhesus macaque monkeys](https://en.wikipedia.org/wiki/Rhesus_macaque) (which were animals that had not gone through laboratory inbreeding and selection and were more closely related to humans)
- The [Wisconsin study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) was published in 2009 and the [NIA study](https://www.nature.com/articles/nature11432) in 2012
- Used rhesus macaque monkeys, which can live up to 40 years
  - another study on squirrel monkeys (which live about 25 years) was abandoned because they did not lose weight when their diet was restricted
- Steve says we learned something very different from each of the studies
- Interestingly, the *New York Times* ran a [story](https://www.nytimes.com/2009/07/10/science/10aging.html) about the Wisconsin study the day after it ran a [story](https://www.nytimes.com/2009/07/09/health/research/09aging.html) about an ITP [study](https://pubmed.ncbi.nlm.nih.gov/19587680/) on [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) (58:22)
  - The monkey study was front page news, but the rapamycin study was buried in the back

**Wild monkey vs. laboratory monkeys**

- virtually all captive animals are obese relative to their wild cousins (59:17)
  - This includes humans: in the late ’80s, early ’90s, Steve did research in Papa New Guinea studying humans who were still hunting with spears and arrows (1:00:00)
  - Even if they are not frankly obese, captive animals have a lot more body fat

**Comparing the different methods and results of the Wisconsin study versus the NIA studies**

- The [Wisconsin study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) approach
  - first measured how much each individual animal ate *ad libitum* (when food was unrestricted)
  - The control group got to continue eating *ad libitum*
  - The other group ate a diet that was 30% less than each individual’s unrestricted amount
  - 35 years later, the animals that ate less lived substantially longer and were healthier by all kinds of disease metrics (pretty much replicating the laboratory experiments)
- Steve started to think about how you would translate the laboratory rodent experiments into human experiments
  - A rat or mouse spends its life in a cage with little opportunity for physical activity
  - The Wisconsin study was a replication of this situation with primates
- But the [NIA study](https://www.nature.com/articles/nature11432) was set up differently
  - The control group was not fed *ad libitum* but only enough to keep them at a healthy body weight
  - The experimental group animals got 30% less than that
  - Animals in both groups were much leaner than the Wisconsin animals
  - Essentially, the NIA was trying to ask “*If you take a healthy human and you restrict the healthy human, what kind of effect are you likely to see?*”
  - In the NIA study, the *restricted group* did not live any longer than the controls
  - But the *NIA controls lived longer than the Wisconsin controls*, which is not surprising because they were at a healthy body weight while the Wisconsin controls were frankly obese (1:03:53)
- But there was also a critical difference in the diets
  - The gross macronutrients (carbohydrates, fats, protein, etc.) were similar
  - But the NIA study used natural ingredients
  - The Wisconsin study used “purified ingredients” because they could be tightly controlled (e.g., instead of cornmeal that might slightly differ in nutrients, use albumin that can be specifically measured)
  - But this diet is not palatable, so they added sucrose (diet was about 28.5% sucrose)
  - The NIA study diet was about 3% sucrose

![](https://peterattiamd.com/wp-content/uploads/2021/08/f2.-steveaustad.png)

**Figure 2.**

- Peter and Attia Medical’s Head of Research [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) did an [analysis](https://peterattiamd.com/calorie-restriction-part-iia-monkey-studies/) that showed the Wisconsin control monkeys were “effectively eating three Big Macs, two large fries and two jumbo Cokes a day” (1:05:55)
  - But in the NIA study “it was basically like a whole food pescatarian diet with 3% sugar in it”
  - Both NIA animal groups lived longer than the Wisconsin CR group

![](https://peterattiamd.com/wp-content/uploads/2021/08/f3.-steveaustad-1024x712.png)

**Figure 3. Comparison of data on animals from the Wisconsin and NIA studies**. ([source](https://www.dropbox.com/s/q8h6crtf6dicmw0/191215%20%23CR%20CR%20Studies%20%23monkeys%20%23uw%20%23nia.xlsx?dl=0))

- In the abandoned squirrel monkey study, the animals were living longer than any squirrel monkeys had ever been reported to live
  - The same happened with the rhesus macaques
- The NIA and Wisconsin experiments seemed the same but they really weren’t, which can explain the different conclusions
  - They looked at the weights of the control animals in Wisconsin and Bethesda compared to all rhesus monkeys in research facilities in the country
  - The Wisconsin control monkeys were about 10% heavier, while the NIA control monkeys were about 10% lighter
  - The Wisconsin study is really showing that eating less junk food is good for you; it’s really about the harmfulness of sucrose

**Concluding thoughts on these studies**:

- Dietary restriction (DR) – manipulating or reducing components of the macro or micronutrients – is at least as important as caloric restriction
- This was basically an experiment demonstrating the harm of sucrose
- Control animals had massive glucoregulatory problems whereas the restricted animals had none
  - Peter recalls reading a later analysis which showed that the control animals in Bethesda, i.e. the fully fed animals in Bethesda, had less diabetes than the calorie-restricted animals in Wisconsin
    - The analysis referred to by Peter was not able to be located (though it may exist), however, here is some further information on that topic:
      - In the UW study, monkeys presenting with insulin resistance were clinically treated to prevent the transition to diabetes.
      - Not only that, in the UW study, they actually excluded deaths that they deemed from “non-age-related-causes.” When they looked at all-cause mortality [in 2009](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/), there was no significant difference, but they reported in the abstract, “moderate CR lowered the incidence of aging-related deaths.”

> “I think what we learned is the worse the diet, the more beneficial the caloric restriction, the better the diet, the less of an impact caloric restriction has.”  —Peter Attia

## Challenges of studying animals due to major differences in the lab animal vs. wild animals [1:10:00]

- We haven’t really ever worked out the best diet for mice or rats, so it’s hard to evaluate the significance of past studies in this context
- The monkeys were individually housed to control their diets, but they are a very special species like humans (1:10:59)
  - They had no opportunity for physical exercise: letting them mingle outside of feeding times might result in fighting
  - “Cognitively I’d have to think it’s terrible. I mean, they were in a room where they could see each other, they could hear each other, they could smell each other, but they couldn’t touch each other” (1:11:41)
- The Wisconsin animals were all monkeys of known ages from India that were born in captivity
- The NIA added monkeys of various ages as they obtained them; some were wild with estimated ages, some were from China

> “I always say that humans are the worst animal to study that you could imagine because they don’t do what you tell them to do and they’ll lie about what they do.” —Steve Austad

- Humans can be difficult to study: timescale, difficulty with interventions, and the lack of biomarkers that to assess geroprotection (1:13:29)
- But even so, for these kinds of nutritional studies, Steve thinks you really do have to study humans because humans have their own unique characteristics
- What would happen if you calorie restrict wild mice?
  - Steve [did this in the lab](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2923404/) – brought wild mice into a lab and restricted calories
  - because he wondered if lab mice may have become gluttonous because they grow and reproduce rapidly (1:14:03)
  - Steve let the wild mice reproduce for several generations to get rid of all the contaminants of being in the wild, then he restricted their diet (1:14:37)
- There was generally no difference in how long they lived
  - but a number of the restricted ones died very early in the experiment
  - and the last 20% of mice lived longer, and all of the longest-lived ones were in the restricted group
  - Maybe genetic makeup determines whether dietary restriction is good for you, has little impact on your health, or is bad for you
- It’s not easy to do good necropsies on mice because their bodies cool off so quickly and their tissues start to degenerate so quickly
  - So Steve doesn’t know what caused the early deaths
  - They were able to do necropsies on some of the longer-living mice, and about half of them had cancer (a lower rate than lab mice)
  - This was not unexpected because they were so long-lived
    - Lab mice live 2.5 years on average, longest-lived ones ~3 years
    - Wild mice live 3-4 months on average, longest-lived ones ~1 year
    - Wild mice brought into a lab live ~20% longer because they are free from predators and have guaranteed food

**Bring wild mice into the lab**

- To someone used to lab mice, wild ones seem like a different species (1:18:08)
  - The rotor rod test for coordination and balance (like log rolling)
    - The rod is about 18 inches off the floor
    - Lab mice are afraid to fall, so they’ll try to stay on the circulating rod
    - Wild mice immediately leap off and run away
  - The wire hang test for grip strength
    - See how long a lab mouse can hang on before it falls
    - Wild mice do a pull up and then run off the wire
    - It’s like comparing the most sedentary overweight person to a trained athlete
  - Wild mice are also not used to being around people, so will bite and run away and you can’t do the same kind of cognitive tests that you can on lab mice
- Peter asks: if you could keep wild mice in their natural environment, remove predators, and then somehow calorie restrict half of them, does Steve believe that the CR group would live longer? (1:20:22)
  - No, Steve thinks they might actually die sooner
  - This experiment would be hard to do, but the opposite has been done by supplementing the food of animals in the wild
  - They don’t get obese and die sooner, instead they live longer because they are foraging less so less exposed to predators
  - If you calorie restricted mice in the wild, they would have to forage more and be more exposed to predators, might take chances to go after food they don’t normally eat that could be toxic
  - Also, CR slows wound healing and makes animals more susceptible to certain kinds of pathogens, which is not a problem in the lab but would be in the wild
- When Steve started in this field, he wondered why wild animals did not eat less if CR extends life
  - It’s because the animals with the genes that have survived for millions of generations out there are the animals are the best at reproducing
  - They are not optimized for the longest life but for the most reproduction
  - they probably eat more than is perfectly healthy because that helps them reproduce faster (1:23:38)
  - nature has not designed any of us to live as long as possible (“nature was fine with us when we were living 35 years”), so it’s up to us to figure that out
- When mice that had been genetically altered to live longer in the lab were released into a field enclosure with normal mice, they lived shorter lives than the controls
  - 18 months later, the altered mice were almost all gone
  - But later data showed that mice with that genetic mutation don’t necessarily live longer in the lab either

## Human studies of calorie restriction [1:24:45]

There are only a few human studies worth mentioning…

- **Biosphere 2**: The first was [Biosphere 2](https://en.wikipedia.org/wiki/Biosphere_2), but we don’t know much about what happened because most participants were pretty young
  - Roy Walford was the exception (he was 66-68 during that time period)
  - All had good CV risk factors, BP, blood glucose, etc., but they are not typical subjects because they all went into it exceptionally healthy from the start
- [**CALERIE**](https://calerie.duke.edu/publications) **studies**: Pennington, Washington University, and Tufts ran the [CALERIE](https://calerie.duke.edu/publications) studies
  - Published both [short term](https://pubmed.ncbi.nlm.nih.gov/16595757/) (6 months) and [long](https://pubmed.ncbi.nlm.nih.gov/26187233/) [term](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(19)30151-2/fulltext) (2 years) data
  - In both studies the goal was to reduce calorie intake by about 25%, but they never got anywhere close to that
    - It’s too hard to do calorie restriction in humans
    - In the longer study they made it down to 11-12%
    - is not affordable to provide all subjects with all their food every day
    - they provided meals initially for a short term, but they didn’t monitor whether people ate anything additional
    - the average person cannot restrict their caloric intake that much
  - in these studies the subjects had improved CV risk factors, BP, insulin, and glucose, but they also had lower bone mineral density and strength loss
  - **One major issue with these kind of studies**:
    - if you look at a dietary-restricted mouse, it’s got almost no body fat
    - But with human experiments, most people are overweight or obese in the U.S.
    - What that means is if you could only achieve 10% dietary restriction, you’re going to get people that are on the verge of being overweight or obese and getting them down to a healthy body weight

> “If you could only achieve 10% dietary restriction, you’re going to get people that are on the verge of being overweight or obese and getting them down to a healthy body weight. I don’t think it’s a surprise to anybody that that’s good for your health. That’s pretty much what they found. They never got people to that extreme leanness.” —Steve Austad on the CALERIE studies

- [**CRONies study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC404101/): Study on members of the Calorie Restriction Society, called CRONies
  - Based on the rodent studies, assume that CR will allow them to live longer
  - Actually eat a highly restricted amount of calories as we have done in lab mice
    - They have good cardiovascular risk factors, less inflammation, and will probably have less cancer (1:30:00)
    - But they have low bone mineral density, negligible sex hormones, and very little muscle mass
    - Hard for them to exercise to build muscle mass because they have very little energy
    - Have low thyroid hormone levels and always feel cold
  - They typically have a BMI of 17-20
- Steve guesses only 30% of the society members are actually following the diet, while the rest aspire to it
- Peter notes that their diet will benefit them in terms of cardiovascular disease and cancer
  - but it’s not clear if they will benefit with respect to dementia or immune function (1:31:34)
  - And they will be much more susceptible to the diseases of frailty
- The members of the society are eager to participate in studies, but it’s an uncontrolled experiment
  - They were not likely average people with average health habits before beginning CR
  - It’s an example of [healthy user bias](https://peterattiamd.com/ns003/) in epidemiology – can’t learn anything from it without randomization (1:32:27)
- Steve notes anecdotally that they don’t often get colds or the flu

> “It’s a very, very, very rare subset of the population that is going to be able to adhere to 30% caloric restriction every minute of every day. And I would argue that even if you could, the quality of life might not justify the trade off.” —Peter Attia

## Better dietary protocols for humans: Alternatives to long-term caloric restriction [1:33:45]

**Caloric restriction is not practical**

- Severe CR is not a realistic solution for most people interested in some form of geroprotection
- Peter calls the standard American diet “a cesspool of nutrition” where food is “infinitely abundant, infinitely cheap, infinitely palatable, and infinitely transportable” (1:34:05)

**Alternative solutions to caloric restriction**

- Time restricted feeding (intermittent fasting): eating only within a certain time window that can eventually be narrowed
  - Variations include pure fasting (only water) for a short period of time (e.g., 3 days every month or every quarter)
  - Also can be partial (750 calories per day for 5 days)
  - Scientists working with mice and rats noticed how they eagerly raced over to get the food at feeding time
    - They would eat everything in a half hour
    - so maybe the timing is the important thing – they are fasting for 23.5 hours a day
  - In studies of rapamycin, we’ve learned that suppressing a gene called [mTOR](https://en.wikipedia.org/wiki/MTOR) has multiple health benefits
    - it doesn’t take much fasting to suppress mTOR
    - mTOR gives us a molecular mechanism for understanding how a period of fasting might have benefits
  - Short-term fasts seem to have multiple benefits for both mice and humans
- DR – not reducing but rather changing the mix or quality
  - Examples are paleo, vegan, and keto / low carb diets
  - Not necessarily eating less, but restricting the kinds of food eaten
  - Steve doesn’t think we have a lot of empirical data for any of these yet, and the data we do have is mostly from people who already had health issues  (1:36:17)
  - But the logic is compelling

## The protective effect of fasting [1:38:00]

- [Jay Mitchell](https://www.cell.com/cell-metabolism/pdf/S1550-4131(21)00065-6.pdf), who died about a year ago, did a groundbreaking [study](https://onlinelibrary.wiley.com/doi/10.1111/j.1474-9726.2009.00532.x)
  - He showed that a mouse that fasted for two or three days recovered much faster from a lethal injury
  - Had 3 groups: (1:38:35)
    - Mice calorically restricted since birth (or for weeks prior to surgery)
    - mice fed *ad lib* their whole lives
    - Mice fed *ad lib* but then severely calorically restricted 3 days prior to surgery
  - all of them then had a surgery in which they clamped off all the blood supply to the kidneys
    - just before the animal is about to die, let the blood flow again)
    - But because of all of the ischemic damage to the tissue (from lack of oxygen), the animal is severely injured
    - All or most of the *ad lib* animals died, but the other two groups survived
  - suggests that a small period of caloric restriction produce a benefit as great as a longer one
  - They did a similar experiment cutting off blood supply to the liver and got a similar result
  - It changed Steve’s thinking about dietary restriction (1:40:50)
- There are two macronutrients to consider here
  - Amino acids, specifically methionine, tryptophan, or leucine
  - mTOR is an amino acid sensor
  - Sugar – the Wisconsin experiment suggested that sucrose could play a large role, but can’t disentangle it from the weight loss and other factors
- Steve doesn’t think animal experiments will help us resolve diet composition questions
  - need to do research in healthy people (1:42:10)
  - Also hard to do long-term studies if one turns out to be bad for human health
- Really need biomarkers
- We need to be able to do an experiment for a few weeks or a few months and have the answer long-term
- The study subjects need to be different ages
  - Many studies were done on subjects in their late 30s, but that doesn’t necessarily apply to people in their 60s
  - It’s surprising how late in life, you can start some kind of intervention and still have a dramatic improvement in health
- The median age of patients in Peter’s practice is late 30s (range is maybe 29 to 82)
  - Steve says this is the age when people realize they are aging and may need to make lifestyle changes
  - The moment when Steve realized he was aging (1:44:56)
    - He was playing basketball when he was about 32 and he was used to blowing by people, but a larger guy was repeatedly blowing by him

> “And I realized I lost the step. .. It was a shocking moment to me because before then never entered my mind that my body was going to change in a way that would make it less good at things I used to do.” —Steve Austad

## Reflecting on the sex differences in human lifespan, and why women have more neurodegenerative diseases [1:45:45]

- In the US today, women live about 5 years longer than men
- Steve says there are a few myths about it, such that women survive better in old age – this is true, but they survive better at every age (1:46:15)
  - They also survive better in both good times and bad times like epidemics and famines
  - There are no circumstances in which men survive better than women
- There’s something about women’s biology that allows them to survive better, but we don’t yet know what it is

**Sex hormone theory**

- What have we learned about hormone replacement therapy (HRT) for postmenopausal women that might be relevant?
  - The [Women’s Health Initiative](https://www.nhlbi.nih.gov/science/womens-health-initiative-whi) study has been controversial with some results that have been found not to be accurate
    - Subjects didn’t start HRT until on average 10 years after menopause
    - Starting earlier and then stopping might provide a benefit
    - But in any case, there wasn’t a difference in mortality by the time they stopped the study due to an increase in risk of blood clots and strokes
    - one could make the case that they shouldn’t have stopped it
- There are at least [two](https://pubmed.ncbi.nlm.nih.gov/5362349/) [studies](https://pubmed.ncbi.nlm.nih.gov/23017989/) showing a major increase in longevity in men who had been castrated
  - But not clear how relevant it is because of the unique population
  - The castration studies suggest that it has more to do with testosterone than estrogen and progesterone (because castrated men would have less estradiol)
- But testosterone replacement data [show](https://pubmed.ncbi.nlm.nih.gov/26482385/) that it doesn’t affect mortality either way, at least beyond 2-3 years
  - Steve notes that many analyses of testosterone data were done post hoc, there were lots of complications, and the studies were not designed to answer questions about longevity
  - But they are provocative because the difference in longevity was ~20 years
- Maybe it has something to do with prenatal exposure
  - Steve notes that because females have better survival from ages zero to five, it suggests there’s something already in place at birth (1:50:06)

**Risky behavior theory (1:50:45)**

- Males engage in riskier behaviors
- Peter says, “If I compare my sons to my daughter, it’s literally like they wake up every day trying to figure out how to hurt each other and hurt themselves”
- It’s unclear how to explain this genetically
  - There are men who do not have the normal male sex chromosomes (XY)
  - instead have no X chromosome but an extra Y (YY)
  - But they are no more aggressive than normal XY men
- Peter and Steve both say they did stupid and risky things when they were young
  - Steve used to shoot arrows straight up in the air and then watch where they came down and he and his friends would shoot arrows at each other and try to dodge them; once he got one stuck in his leg
  - “I call this testosterone dementia. And I think probably most men go through it at some point probably in their adolescent years”
  - When Peter was in high school, he and his friends would dive under the above-ground GO train in Toronto to put coins on the track and then jump out before the train started moving to see who could get the most flattened coins
  - There are few examples of girls engaging in his type of stupid risky behavior

- But that does not explain infant mortality or lower rates of death from things like influenza, COVID (45% vs. 55% mortality), etc. (01:53:53)
- For all the major causes of death, women die at a lower rate, even if you adjust for age
  - Alzheimer’s disease is the exception
  - Steve suspects it has an autoimmune component because women seem to be more susceptible to some of the autoimmune diseases than men

**The role of chromosomes in determining sex differences [1:54:45]**

- Another theory is that because women have two X chromosomes (XX), if they have a defective gene or genes on one of the X chromosomes, the other one can compensate for it to a certain extent
  - But men with [Klinefelter syndrome](https://en.wikipedia.org/wiki/Klinefelter_syndrome) also have an extra X chromosome (XXY instead of XY) but they have a shorter life span (the disease is not common enough to get much data)
  - And women with [Turner syndrome](https://en.wikipedia.org/wiki/Turner_syndrome), who have only one X chromosome (XO), also have shorter life spans
- In women, one of the X chromosomes tends to be deactivated in each cell
  - Early in life, it seems to be random, so in half the cells the maternal X is deactivated and in the other half the paternal X is
  - But as women age there seems to be a preference for one X or the other
- We need to learn a lot more about X inactivation, because it is not complete and not every gene on the second X is inactivated
  - Peter says it would be interesting to identify women who partition more into a dominant maternal X and those more into a dominant paternal X
  - See if the father of the paternal-X-dominant woman lives longer than other men
  - Unfortunately this could not be done as a random experiment
- It could also be related to the mitochondrial genome
  - mitochondrial genomes are only passed from female to female
  - could be an issue of compatibility with mitochondrial and nuclear genomes
  - Male mitochondria are at an evolutionary dead end, so perhaps the male nuclear genome is just not as compatible with the mitochondrial genome as the female nuclear genome
- We have always assumed that the Y chromosome controlled sexual characteristics (probably “the first time in the history of medicine that men get less attention for anything than women”)
  - but we now know there are at least nine genes on the Y chromosome that are expressed in every tissue
  - We do not know what those genes do
- With humans we can really only look in the blood, can’t look at the brain or liver until after death (although we could try muscle biopsies)

> “My feeling is that we have yet to really explore the sex differences in any depth and that we may end up having somewhat different therapeutics in women and men once we start looking into exactly how these things work out between the sexes.” —Steve Austad

- The ITP has consistently found that drugs like rapamycin and [17 𝛼-estradiol](https://en.wikipedia.org/wiki/Alfatradiol) disproportionately favor the male mice over the female mice (1:59:56)
  - Is it simply because they have a higher bar to clear with the females?
  - Steve suggests that the drugs might have more of an effect in male mice because the female ITP mice live longer
- For rapamycin, the sex bias is dependent on dose
  - At the lowest dose, the effect is substantially bigger in females than in males
  - But the difference gradually goes away as you use higher doses
  - One [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4996648/) showed that at a high dose, rapamycin had a big effect on males but none on females
  - Steve wonders if the females have been overdosed at that stage
- In a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4032600/) done by Rich Miller, the females had a much higher plasma level than the males despite consuming the same amount (2:01:09)
  - But they are not sure why
  - Peter wonders if maybe at a lower dose females live longer because their plasma concentration is higher, but that gap disappears at a higher dose
  - The study wasn’t related to blood levels of rapamycin or its metabolites
  - They are metabolized quickly so it could be something downstream
- Steve does not think longevity studies in mice are ideal for studying sex differences
  - Even in mice of the same genotype, in some studies females live longer, in some males, and in others it’s equal – it’s all over the place and we don’t know why
  - Mouse sex chromosomes are also very different from human ones
    - In humans, ~15% of genes on the inactive X chromosome are not inactivated
    - In mice it’s 3-4%
    - There are also genes on the Y chromosome in humans that are not on the Y chromosome in mice, and vice versa
  - It’s like having the limited perspective of looking with one eye closed

## The importance of identifying longevity biomarkers and which ones show the potential to change the landscape of longevity research [2:03:30]

*Peter asks: why hasn’t there been a greater effort in identifying better biomarkers of aging? Or has there been an enormous effort and it’s just been too difficult?  (2:03:43)*

- Steve thinks we’ve tried but haven’t found answers
  - We don’t know how long a human needs to fast to achieve a significant enough inhibition of rapamycin to get benefits
  - In the 1990s, the NIA put millions dollars into developing biomarkers of aging and got no results
  - It may have been that we didn’t have the right tools then
- “I think we’re really on the verge of something big here so that we can have biomarkers that will tell us exactly this kind of thing”
- These biomarkers will probably be in the [metabolome](https://en.wikipedia.org/wiki/Metabolome), the [proteome](https://en.wikipedia.org/wiki/Proteome), and the [epigenome](https://en.wikipedia.org/wiki/Epigenome)
- The epigenome is the most exciting one right now
  - Peter says he’s not impressed with the epigenomic research
    - Peter has measured his patients’ epigenetic age, then they do a three-day fast and their epigenetic age goes down by 10% or more, but a week later it’s back to normal
    - Those results don’t tell you anything
  - Steve says he is impressed by the epigenetic data, but he thinks it’s a longer-term effect that might only show up over the course of years
  - But Peter says this kind of data varies widely from moment to moment – things like Vitamin D and glucose are easy to manipulate and have a lot of volatility over time
  - Steve says they may never turn out to be clinically useful because they’re integrating things over a timescale that’s not clinically meaningful (2:06:30)
- It’s more likely that we’re going to find something in the proteome or the metabolome
  - If you want to measure changes from, say, fasting for a certain amount of hours, you look in the proteome or the metabolome
  - But it’s going to be computationally complex and the tools to do it are expensive, making it impractical in the clinic

*What would you do if you had a billion dollars to put towards a “*[*Manhattan Project*](https://en.wikipedia.org/wiki/Manhattan_Project) *of longevity”? (2:07:28)*

- Peter would put 25% of it into finding biomarkers
- The computational tools are getting better all the time, but the money has not been invested because it’s not commercially interesting enough
  - Venture capitalists are more excited by new therapeutic models than new diagnostic tests
  - Peter thinks you’d need a heavily funded government project, “an entity that is so large commercially that they understand that this is an important tool that needs to be developed in research to foster the development of molecules down the line”
  - [Craig Venter](https://en.wikipedia.org/wiki/Craig_Venter) tried to do that, but the company went nowhere (2:09:12)
- The key is there somewhere with all the processes going on in the body
- Looking in the blood may be key

> “I think part of the problem is that … there’s a very small group of people that are interested in making other people live longer, but most of the time it’s trying to prevent them from getting a specific disease. There’s a lot more money that goes into obesity, I think, than that goes into longevity.” —Steve Austad

- It’s still money well spent because obesity is a huge problem
- ~20 years ago Steve and [Jay Olshansky](https://en.wikipedia.org/wiki/S._Jay_Olshansky) made a bet about when a human would first live to be 150 years old
  - Steve bet that the person had been born by the year 2000
  - One term of the bet was that the person had to be mentally competent enough to have a coherent conversation
  - that was 20 years ago, but no one yet has lived as long as the longest life person had lived at that point (about 122.5 years)
  - Nobody has even reached 120 since then

> “I never thought this was going to happen because we got better at treating cancer or we got better at preventing heart disease. I always thought it was going to happen because we would develop something or some things that would fundamentally change the rate of aging. And we haven’t developed that yet. We’ve got a lot of clues and I think we’re getting closer and closer and closer.” —Steve Austad

- He still thinks the person could have been born by 2000 – it might not happen until they reach 50, but it could still extend their life
  - Steve does not think 150 will become a normal life expectancy, only that an outlier will live that long (his guess is a Japanese woman)
  - The limit of overall life expectancy is probably about 100
- But if we discover what we need to do to live that long, the key would be to get people to actually do it
- The model Jay used did a number of calculations like if we completely eradicated cancer, we would increase life expectancy by X years, if we completely eradicated disease Y, we would increase it by Z years, etc.
  - But the models reply on several assumptions, one of which is that these factors are independent of each other, which we know (e.g., from metabolic syndrome) is not true

> “Eliminating a single cause of death is not the same as delaying 20 causes of death.” —Steve Austad

## Molecules showing the most promise as longevity agents [2:14:00]

*Peter asks Steve which of the molecules we know about today he thinks has the most potential for geroprotection?*

- *17* 𝛼*-estradiol, which is not FDA-approved but has had “unbelievable success” in male mice in the ITP?*

- [*Canagliflozin*](https://en.wikipedia.org/wiki/Canagliflozin)*,* [*acarbose*](https://en.wikipedia.org/wiki/Acarbose)*, rapamycin,* [*metformin*](https://en.wikipedia.org/wiki/Metformin)*?*

- Steve’s guesses
  - Based on mouse data, rapamycin
  - Based on human data, metformin
  - But he would add major qualifications to both of these
  - The most helpful thing might end up being combinations of these molecules

**Metformin**

- The most compelling data on metformin come from human studies
  - Metformin was not successful in mice in the ITP studies
  - All the human data comes from diabetic patients, so it might not be as beneficial for healthy people
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai), who [has](https://peterattiamd.com/nirbarzilai/) [been](https://peterattiamd.com/joanmannick-nirbarzilai/) a guest on this podcast, would argue that many of metformin’s benefits go beyond glucose regulation
  - But Steve says he is more skeptical because most clinical trials fail, especially if they’re based on mouse data
  - As of right now, we know it can affect dementia and cancer and heart disease, and it may have a negative impact on muscle function
  - But we still need a lot more data
  - We at least know that metformin is safe

**Rapamycin**

- We’re still not sure if rapamycin is safe
- Steve thinks we should prioritize figuring out what low dose rapamycin does
- But the FDA is not going to sign off on giving drugs to healthy people, so we have to do trials on people with underlying illness
- How would you dose rapamycin in a longevity trial? (2:17:17)
  - In all of the ITP mouse studies, the mice were fed rapamycin in their chow
  - we think that the benefits of rapamycin come not from global inhibition of mTOR, but from the specific inhibition of mTOR complex 1 rather than mTOR complex 2
  - there might even be negative consequences of inhibiting mTOR complex 2
  - But when we take rapamycin as organ transplant patients do, we are suppressing both
  - So how would you design a trial whose goal was to investigate its effect on longevity?
    - start off with a dose whose effects have already been tested in humans (2:18:24)
- The [rapalog](https://en.wikipedia.org/wiki/MTOR_inhibitors#Rapamycin_and_rapalogs) (rapamycin derivative) [everolimus](https://en.wikipedia.org/wiki/Everolimus) was [found](https://pubmed.ncbi.nlm.nih.gov/25540326/) to enhance the vaccine response to influenza
  - 5 mg/week and 20 mg/week both enhanced the response equally effectively, but the lower dose caused fewer side effects
  - Drug companies are looking for a rapalog that doesn’t inhibit complex 2
- Need to do more studies like the vaccine one, which was in healthy people who were 65+
- There was an NIH clinical trial to study whether rapamycin could prevent the recurrence of kidney cancer
  - people are seemingly cured after having the cancerous kidney removed, but they have a higher than average rate of relapse
  - Tried a year of rapamycin to see if it would reduce the recurrence rate
  - Steve wanted to measure lots of parameters (e.g., inflammation, muscle strength) in the subjects in this study, which was already going on, but his project did not get funded
  - Although it may have been too high a dose since it was being used for immunotherapeutic purposes

**Other drugs**

- It’s too early to know if [SGLT2 inhibitors](https://en.wikipedia.org/wiki/SGLT2_inhibitor) (e.g., canagliflozin) or [nicotinamide adenine dinucleotide](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) (NAD) precursors will turn out to be useful (2:20:56)
  - Steve says he “really needs to see the data” before he will get excited
  - Peter thinks the human data on the SGLT2 inhibitors is “remarkable” (02:21:39)
  - Have good outcomes in ITP studies, but they are not looking at longevity and are only being done in a subset of the population
  - but the impact on kidney failure, all-cause mortality, and heart failure is pretty impressive
- ITP studies on both canagliflozin and acarbose suggest that the benefits might be unrelated to reducing caloric intake
  - Steve is disappointed that the ITP dropped the pair-fed arm of that study, so we know only about body weight and not food consumption
  - Would be useful to be able to do a 5-year study and say specifically what it can do
  - Don’t want to boost the immune system too much or can get autoimmune diseases

> “We’re going to make real progress when we have human biomarkers.” —Steve Austad

§

## Selected Links / Related Material

**Peter’s podcast with Rich Miller on the ITP**: [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) [| *The Drive*](https://peterattiamd.com/podcast/), Peter Attia (February 8, 2021) [|](https://peterattiamd.com/podcast/) [38:00]

**Masoro discussing calorie restriction in rats**: [Overview of caloric restriction and ageing](https://pubmed.ncbi.nlm.nih.gov/15885745/) [|](https://peterattiamd.com/podcast/) *Mechanisms of Ageing and Development* (Masoro 2005) [|](https://peterattiamd.com/podcast/) [47:15]

**Article about Biosphere 2**: [The Lost History of One of the World’s Strangest Science Experiments](https://www.nytimes.com/2019/03/29/sunday-review/biosphere-2-climate-change.html) [|](https://peterattiamd.com/podcast/) Carl Zimmer, *New York Times* (March 29, 2019) [|](https://peterattiamd.com/podcast/) [48:30]

**Roy Walford’s paper on CR in Biosphere 2**: [Calorie Restriction in Biosphere 2: Alterations in Physiologic, Hematologic, Hormonal, and Biochemical Parameters in Humans Restricted for a 2-Year Period](https://academic.oup.com/biomedgerontology/article/57/6/B211/564317) [|](https://peterattiamd.com/podcast/) *The Journals of Gerontology* (Walford et al. 2002) [|](https://peterattiamd.com/podcast/) [48:30]

**Research on growth hormone and rodent lifespan** [53:45]

- *In mice*

- - - [Dwarf mice and the ageing process](https://pubmed.ncbi.nlm.nih.gov/8900272/) [|](https://peterattiamd.com/podcast/) *Nature* (Brown-Borg et al. 1996)
    - [Lifespan extension and delayed immune and collagen aging in mutant mice with defects in growth hormone production](https://www.pnas.org/content/98/12/6736.short) [|](https://peterattiamd.com/podcast/) *PNAS* (Flurkey et al. 2001)

- *In rats*

- - [Life Span Extension by Reduction in Growth Hormone-Insulin-Like Growth Factor-1 Axis in a Transgenic Rat Model](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1850833/) [|](https://peterattiamd.com/podcast/) *American Journal of Pathology* (Shimokawa et al. 2002)

**Wisconsin study**: [Caloric restriction delays disease onset and mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) [|](https://peterattiamd.com/podcast/) *Science* (Colman … Weindruch 2009) [|](https://peterattiamd.com/podcast/) [56:15]

**NIA study**: [Impact of caloric restriction on health and survival in rhesus monkeys from the NIA study](https://www.nature.com/articles/nature11432) [|](https://peterattiamd.com/podcast/) *Nature* (Mattison et al. 2012) [|](https://peterattiamd.com/podcast/) [56:15]

**ITP study on rapamycin**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://pubmed.ncbi.nlm.nih.gov/19587680/) [|](https://peterattiamd.com/podcast/) *Nature* (Harrison et al. 2009) [|](https://peterattiamd.com/podcast/) [58:30]

**NYT articles published within a day of each other about the rapamycin study and the Wisconsin study** [58:30]

- [Antibiotic Delayed Aging in Experiments with Mice](https://www.nytimes.com/2009/07/09/health/research/09aging.html) [|](https://peterattiamd.com/podcast/) Nicholas Wade, *New York Times* (July 8, 2009) [|](https://peterattiamd.com/podcast/) [58:30]
- [Dieting Monkeys Offer Hope for Living Longer](https://www.nytimes.com/2009/07/10/science/10aging.html) [|](https://peterattiamd.com/podcast/) Nicholas Wade, *New York Times* (July 9, 2009) [|](https://peterattiamd.com/podcast/) [58:30]

**Additional NYT articles on the monkey aging studies**: [58:30]

- [Severe Diet Doesn’t Prolong Life, at Least in Monkeys](https://www.nytimes.com/2012/08/30/science/low-calorie-diet-doesnt-prolong-life-study-of-monkeys-finds.html) [|](https://peterattiamd.com/podcast/) Gina Kolata, *New York Times* (August 29, 2012) [|](https://peterattiamd.com/podcast/) [56:15]
- [Diet’s Link to Longevity: After 2 Studies Diverge, a Search for Consensus](https://www.nytimes.com/2014/04/02/science/a-new-salvo-in-debate-over-caloric-restrictions-and-longevity.html) [|](https://peterattiamd.com/podcast/) Nicholas Wade, *New York Times* (April 1, 2014) [|](https://peterattiamd.com/podcast/) [56:15]

**Analysis of the Wisconsin and ITP monkeys’ diets**: [Calorie restriction: Part IIA – monkey studies](https://peterattiamd.com/calorie-restriction-part-iia-monkey-studies/) [|](https://peterattiamd.com/podcast/) Peter Attia (April 16, 2018) [|](https://peterattiamd.com/podcast/) [1:06:00]

**Steve’s experiment with wild mice and CR**: [Does caloric restriction extend life in wild mice?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2923404/) [|](https://peterattiamd.com/podcast/) *Aging Cell* (Harper, Leathers & Austad 2006) [|](https://peterattiamd.com/podcast/) [1:14:00]

**CALERIE study**: [1:25:30]

- - *Comprehensive list of CALERIE publications*: [Publications](https://calerie.duke.edu/publications) [|](https://peterattiamd.com/podcast/) Duke University, CALERIE website

- *Short-term data*

- - - [Effect of 6-month calorie restriction on biomarkers of longevity, metabolic adaptation, and oxidative stress in overweight individuals: a randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/16595757/) [|](https://peterattiamd.com/podcast/) *JAMA* (Heilbronn et al. 2006)

- *Long-term data*

- - [2 years of calorie restriction and cardiometabolic risk (CALERIE): exploratory outcomes of a multicentre, phase 2, randomised controlled trial](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(19)30151-2/fulltext) [|](https://peterattiamd.com/podcast/) *Lancet Diabetes and Endocrinology* (Kraus et al. 2019)
  - [A 2-Year Randomized Controlled Trial of Human Caloric Restriction: Feasibility and Effects on Predictors of Health Span and Longevity](https://pubmed.ncbi.nlm.nih.gov/26187233/) [|](https://peterattiamd.com/podcast/) *Journals of Gerontology, Series A* (Ravussin et al. 2015)

**CRONies study**: [Long-term calorie restriction is highly effective in reducing the risk for atherosclerosis in humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC404101/) (Fontana et al., 2004) [1:28:45]

- - **Articles about research on the CRONies**:
    - [Making Ageing Healthier and Younger – An Interview with Professor Luigi Fontana](https://youth-time.eu/making-ageing-healthier-and-younger-an-interview-with-professor-luigi-fontana/) Martina Advaney, YouthTime Magazine (May 22, 2020)
    - [Eat Less, Live Longer: Reducing calories may lead to a longer, healthier life](https://outlook.wustl.edu/2012/apr/calories/) Jim Dryden, Outlook – Wash U. in St. Louis School of Medicine (April 2012)
    - [Human Study Shows Benefits of Caloric Restriction](https://www.technologyreview.com/2006/06/06/229009/human-study-shows-benefits-of-caloric-restriction/) Emily Singer, Technology Review (June 6, 2006)

- **Studies on human CR and longevity using data from the CRONies:**

- - [Long-Term Calorie Restriction Enhances Cellular Quality-Control Processes in Human Skeletal Muscle](https://www.cell.com/cell-reports/pdf/S2211-1247(15)01483-7.pdf) Cell Reports (Yang … Holloszy & Fontana 2016)
  - [Effects of long-term calorie restriction and endurance exercise on glucose tolerance, insulin action, and adipokine production](https://pubmed.ncbi.nlm.nih.gov/19904628/) Age (Fontana, Klein & Holloszy 2010)
  - [Caloric restriction in humans](https://pubmed.ncbi.nlm.nih.gov/17482403/) Experimental gerontology (Holloszy & Fontana 2007)
  - [Long-term calorie restriction is highly effective in reducing the risk for atherosclerosis in humans](https://www.pnas.org/content/101/17/6659/tab-article-info) PNAS (Fontana, Meyer, Klein & Holloszy 2004)

**Jay Mitchell’s paper**: [Short-term dietary restriction and fasting precondition against ischemia reperfusion injury in mice](https://onlinelibrary.wiley.com/doi/10.1111/j.1474-9726.2009.00532.x) [|](https://peterattiamd.com/podcast/) *Aging Cell* (Mitchell et al. 2010) [|](https://peterattiamd.com/podcast/) [1:38:00]

**Studies indicating that castrated males have increased longevity** [1:47:30]

- [Mortality and survival: comparison of eunuchs with intact men and women in a mentally retarded population](https://pubmed.ncbi.nlm.nih.gov/5362349/) *Journal of Gerontology* (Hamilton & Mestler 1969)
- [The lifespan of Korean eunuchs](https://pubmed.ncbi.nlm.nih.gov/23017989/) *Current Biology* (Min, Lee & Park 2012)

**Data on testosterone replacement therapy and longevity**: [Testosterone therapy and mortality risk](https://www.nature.com/articles/ijir201429) [|](https://peterattiamd.com/podcast/) *International Journal of Impotence Research* (Eisenberg et al. 2015) [|](https://peterattiamd.com/podcast/) [1:49:45]

**Study showing that high-dose rapamycin affects male but not female mouse lifespan**: [Transient rapamycin treatment can increase lifespan and healthspan in middle-aged mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4996648/) [|](https://peterattiamd.com/podcast/) *eLife* (Bitto et al. 2016) [|](https://peterattiamd.com/podcast/) [2:00:45]

**Study showing higher plasma levels of rapamycin in female mice**: [Rapamycin-mediated lifespan increase in mice is dose and sex dependent and metabolically distinct from dietary restriction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4032600/) [|](https://peterattiamd.com/podcast/) *Aging Cell* (Miller et al. 2014) [|](https://peterattiamd.com/podcast/) [2:01:00]

**Study showing that everolimus enhances the influenza vaccine response**: [mTOR inhibition improves immune function in the elderly](https://pubmed.ncbi.nlm.nih.gov/25540326/) [|](https://peterattiamd.com/podcast/) *Science Translational Medicine* (Mannick et al. 2014) [|](https://peterattiamd.com/podcast/) [2:18:15]

**Peter’s podcasts with Nir Barzilai** [2:15:45]

- [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) [| *The Drive*](https://peterattiamd.com/podcast/), Peter Attia (January 7, 2019)
- [#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19](https://peterattiamd.com/joanmannick-nirbarzilai/) [| *The Drive*](https://peterattiamd.com/podcast/), Peter Attia (August 10, 2020)

§

## People Mentioned

- [Tippi Hedren](https://en.wikipedia.org/wiki/Tippi_Hedren) [19:30]
- [Richard Miller](https://medicine.umich.edu/dept/dcmb/richard-miller-phd) [38:00, 53:00]
- [Scott Ballinger](https://www.uab.edu/medicine/diabetes/genetics/72-scott-ballinger) [39:30]
- [Clive McCay](https://en.wikipedia.org/wiki/Clive_McCay) [43:00, 44:00]
- [Roy Walford](https://en.wikipedia.org/wiki/Roy_Walford) [47:00, 47:30, 47:45, 1:25:15, 1:28:45]
- [Edward Masoro](https://barshopinstitute.uthscsa.edu/about-us/edward-joseph-masoro-ph-d/) [47:15, 47:30]
- [Rick Weindruch](https://www.nuskinops.com/content/dam/corpcom/Expert%20biographies/Richard%20Weindruch%20BIO.pdf) [56:45]
- [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) [1:06:00]
- [Jay Mitchell](https://www.cell.com/cell-metabolism/pdf/S1550-4131(21)00065-6.pdf) [1:38:00]
- [Craig Venter](https://en.wikipedia.org/wiki/Craig_Venter) [2:09:00]
- [Jay Olshansky](https://en.wikipedia.org/wiki/S._Jay_Olshansky) [2:10:00, 2:10:30, 2:13:00]
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) [2:15:45]

§