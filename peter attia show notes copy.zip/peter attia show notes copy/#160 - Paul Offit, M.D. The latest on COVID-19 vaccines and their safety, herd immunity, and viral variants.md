# #160 – Paul Offit, M.D.: The latest on COVID-19 vaccines and their safety, herd immunity, and viral variants

**Source:** [https://peterattiamd.com/pauloffit2/](https://peterattiamd.com/pauloffit2/)

---

Paul Offit is a pediatrician specializing in infectious diseases and an expert in virology and vaccine development. He currently serves on the FDA committee evaluating COVID-19 vaccines. In this episode, Paul’s second appearance on The Drive, he provides an update on all the SARS-CoV-2 vaccines currently deployed, explains why the concerns raised around the mRNA vaccines are not legitimate, and offers his view on the prospects and timeframe of reaching herd immunity. He also takes a deep dive into immunology, explaining the short-term and long-term immune response to both natural infection and vaccination and how these two can function together to provide durable immunity. Additionally, they discuss the theories on the origins of this virus, what impact the new COVID-19 variants might have, and the recent pausing of the J&J vaccine. Finally, they discuss how we can be better prepared for an inevitable future outbreak of a novel virus. This episode was originally recorded on April 14, 2021.

\*[WATCH PODCAST ON YOUTUBE](https://www.youtube.com/watch?v=da2AuPN1ehI)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/pauloffit2/the_Drive_public.png)

Play

#160 - Paul Offit, M.D.: The latest on COVID-19 vaccines and their safety, herd immunity, and viral variants

#160 - Paul Offit, M.D.: The latest on COVID-19 vaccines and their safety, herd immunity, and viral variants

1x15s30s

0:001:25:39

## We discuss:

- Overview and current status of the SARS-CoV-2 vaccine strategies [4:10];
- Addressing concerns about mRNA vaccines [9:00];
- How the failure to make an effective HIV vaccine aided the development of a COVID-19 vaccine [16:45];
- Where SARS-CoV-2 falls on the spectrum of its ability to mutate and what that means for immunity and vaccination [21:30];
- How the combination of short-term and long-term immune response to SARS-CoV-2 work together to provide durable immunity [28:00];
- Importance of understanding relative vs. absolute risk reduction [38:15];
- Implications of pausing the J&J vaccine due to reports of blood clotting in the brain [42:45];
- What constitutes herd immunity and the concerns of rising vaccine hesitancy [47:45];
- When we might reach herd immunity, future vaccines for children, and long-term outlook for maintaining population immunity [58:45];
- Theories about the origins of SARS-CoV-2 [1:07:00];
- Preparing for the possibility of a future pandemic and how we can learn from our mistakes [1:10:40]; and
- More.

§

## Show Notes

## Overview and current status of the SARS-CoV-2 vaccine strategies [4:10]

This interview includes a discussion of several different kinds of vaccines. Here is an overview of the various types of vaccines:

![](https://peterattiamd.com/wp-content/uploads/2021/05/fig-1-offit2-1024x427.png)

**Figure 1. Overview of vaccine types.** Image credit: [McGill University COVID19 Vaccine Tracker](https://covid19.trackvaccines.org/how-do-vaccines-work/)

- Tens of millions of people have now been vaccinated against SARS-CoV-2

**Specific types of SARS-CoV-2 vaccines**

- [Messenger RNA](https://en.wikipedia.org/wiki/Messenger_RNA) [(mRNA) vaccine](https://en.wikipedia.org/wiki/RNA_vaccine)
- [Adenovirus](https://en.wikipedia.org/wiki/Adenoviridae) [vaccine](https://en.wikipedia.org/wiki/Viral_vector_vaccine#Adenovirus)
- [Purified protein vaccine](https://www.globalhealthprimer.emory.edu/targets-technologies/recombinant-purified-protein-vaccines.html)
- [Live attenuated virus vaccine](https://en.wikipedia.org/wiki/Attenuated_vaccine)

![](https://peterattiamd.com/wp-content/uploads/2021/05/fig-2-offit2-1024x724.png)

**Figure 2. Types of COVID-19 vaccines.** Image credit: [Wellcome](https://wellcome.org/news/four-reasons-why-we-need-multiple-vaccines-covid-19)

- 1) mRNA is the farthest along in the US
  - FDA granted EUA to Pfizer on Dec 10 and Moderna on Dec 17
  - 120 million have received at least one dose of one of these
- 2) Adenovirus
  - Uses adenovirus as a vector to deliver viral DNA
  - Jenner Institute/Astra Zeneca (AZ): [replication-defective adenovirus vector](https://pubmed.ncbi.nlm.nih.gov/16364753/)
    - Tens of millions of AZ in UK and Europe
  - Janssen / Johnson & Johnson (J&J): replication-defective adenovirus type 26
    - 200K in west Africa for [Ebola](https://en.wikipedia.org/wiki/Ebola)
    - more than 6 million in US for SARS-CoV-2
  - 20 million + doses of these vaccines
  - Russian vaccine is also a replication-defective adenovirus vaccine (human Ad26 followed by human Ad5)
- 3) Purified protein
  - Made by Novavax
  - insert gene for spike protein into [baculovirus](https://en.wikipedia.org/wiki/Baculoviridae)
  - grown in [*Spodoptera frugiperda*](https://en.wikipedia.org/wiki/Fall_armyworm) cells (same way we make [Flublok](https://www.rxlist.com/flublok-drug.htm#description))
  - Novavax has been slow to get approval
- 4) Live attenuated
  - still in the works
  - Paul doesn’t think one has been approved anywhere
- 5) Whole killed viral vaccine
  - Used in China on 10+ million people
  - Similar to how we make vaccines for polio, rabies, Hep A, etc.
  - some question how well it works against SARS-CoV-2
  - Whole killed virus was first used in late 1800s by [Louis Pasteur](https://en.wikipedia.org/wiki/Louis_Pasteur) against rabies
- The first vaccines were live *non-human* viruses
  - Used cowpox in late 1700s
  - The virus was close enough to [human smallpox](https://en.wikipedia.org/wiki/Smallpox_vaccine) that produced immune response
  - but they didn’t understand the science behind it back then

## Addressing concerns about mRNA vaccines [9:00]

- People say mRNA is experimental and like science fiction
  - Peter has tried to point out it’s not as experimental as people think and has been around for decades
    - See Peter’s newsletter: [mRNA vaccine technology](https://peterattiamd.com/mrna-technology/)
  - Now is just the first time we did the final step of sequencing and putting it into clinical practice
- Four prior eras of vaccinology
  - [Animal strains related to human ones](https://en.wikipedia.org/wiki/Smallpox_vaccine)
  - [Inactivated](https://en.wikipedia.org/wiki/Inactivated_vaccine)
  - live attenuated
  - purified protein
  - in all of these, you are giving the viral protein you’re interested in (whole virus or live attenuated virus or just a purified protein itself)
  - Then the vaccinated person makes antibodies to the protein
- [mRNA vaccines](https://en.wikipedia.org/wiki/RNA_vaccine) are the 5th era of vaccinology
  - you are giving the gene that codes for the protein
  - your body makes the viral protein first and then the antibody response
  - It’s a genetic strategy, concerns people about altering your genes
  - It’s clear there is no short-term toxicity, but there is genuine concern that we don’t have data on long-term effects

**Can mRNA vaccines alter your DNA? (12:30)**

- mRNA is carried in [lipid nanoparticles](https://en.wikipedia.org/wiki/Solid_lipid_nanoparticle), which are taken up by [dendritic cells](https://en.wikipedia.org/wiki/Dendritic_cell), the major antigen-presenting cells
- mRNA enters the [ribosome](https://en.wikipedia.org/wiki/Ribosome) and is translated into protein
- After a period of days the mRNA breaks down and no longer makes protein
- These vaccines cannot alter our DNA:
  - Can’t cross nuclear membrane into the [cell nucleus](https://en.wikipedia.org/wiki/Cell_nucleus) (where our genome is located) without a nuclear access signal that it lacks
  - It’s RNA, not DNA, so it must be converted to DNA but lacks an enzyme like [reverse transcriptase](https://en.wikipedia.org/wiki/Reverse_transcriptase) that could convert it
  - Would then have to insert itself into DNA, which requires an [integrase](https://en.wikipedia.org/wiki/Integrase) enzyme that it also lacks

> “You have a better chance of developing X-ray vision if you’ve gotten [an mRNA vaccine] than you have of the mRNA in any way altering your DNA.” —Paul Offit

**Long-term effects of mRNA vaccines (14:15)**

- In the past, serious adverse effects of vaccines have become apparent within 2 months
  - One of the [squalene](https://en.wikipedia.org/wiki/Squalene) [adjuvant](https://en.wikipedia.org/wiki/Immunologic_adjuvant) influenza vaccines ([Pandemrix](https://en.wikipedia.org/wiki/Pandemrix)) used against [H1N1](https://en.wikipedia.org/wiki/Influenza_A_virus_subtype_H1N1) during the [2009 swine flu pandemic](https://en.wikipedia.org/wiki/2009_swine_flu_pandemic) could cause [narcolepsy](https://en.wikipedia.org/wiki/Narcolepsy), very rare but real side effect (1 per 55K) within 6 weeks
  - [Albert Sabin](https://en.wikipedia.org/wiki/Albert_Sabin)’s oral polio vaccine could cause polio – always within 6 weeks (1 in 2.4 million)
  - Influenza vaccine: can cause [Guillain–Barré syndrome](https://en.wikipedia.org/wiki/Guillain%E2%80%93Barr%C3%A9_syndrome) (an ascending paralysis which can be severe and occasionally fatal) within 6 weeks (1 per million)
  - Yellow fever vaccine can cause [yellow fever](https://en.wikipedia.org/wiki/Yellow_fever) (viscerotropic disease) within a week or so (1 per million)
- These all became apparent within 2 months after 10 million + doses
- We have not seen anything like this with the mRNA vaccines
- We need to understand how mRNA is translated into a protein and that we don’t have the machinery to allow the reverse

## How the failure to make an effective HIV vaccine aided the development of a COVID-19 vaccine [16:45]

**The human immunodeficiency virus (**[**HIV**](https://en.wikipedia.org/wiki/HIV)**) as a counterexample to SARS-CoV-2**

- We could not develop a vaccine for HIV, which taught us some useful things
- HIV is one of the worst viruses
  - you make an antibody response that kills the virus
  - but it continues to evolve during a single infection, mutating again and again
  - We have to adjust the influenza vaccine each year because it changes, but HIV does that in a single infection
- Reproduces primarily in [T helper cells](https://en.wikipedia.org/wiki/T_helper_cell), major orchestrators of immune system
  - help [B cells](https://en.wikipedia.org/wiki/B_cell) make antibodies
  - stimulate the cytotoxic [T cells](https://en.wikipedia.org/wiki/T_cell) that kill viral-infected cells
- paralyzes immune system at the same time that it’s mutating, so immune system never catches up to it
- in the late ’90s, finally developed a highly active [antiretroviral therapy](https://en.wikipedia.org/wiki/Management_of_HIV/AIDS) as a treatment and made HIV a chronic disease
  - but [still no vaccine](https://en.wikipedia.org/wiki/HIV_vaccine_development)
  - Merck put several billion dollars into developing an adenovirus vector vaccine that was not successful
  - It didn’t work in any sense and [in some ways it was actually worse](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2234358/) for those who were vaccinated
- Peter thinks of HIV as an army that can specifically target another army’s general to prevent the chance of developing a coherent strategy to fight back
- We have learned from past studies
  - The [Merck HIV vaccine trial](https://en.wikipedia.org/wiki/STEP_Study) (using human Ad5) [provided insight](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2234358/) into replication-defective adenoviruses, as did Ebola vaccine trials
  - There was also an Ebola vaccine with a [replication-competent viral vector](https://en.wikipedia.org/wiki/Viral_vector) using the [vesicular stomatitis](https://en.wikipedia.org/wiki/Indiana_vesiculovirus#Vesicular_stomatitis) virus, which is like a harmless cousin of rabies
- [Jonas Salk](https://en.wikipedia.org/wiki/Jonas_Salk)‘s strategy was to try and take the whole virus and kill it
  - but that had very limited applicability
  - Paul considers it as impractical idea like the universal flu vaccine
- Paul trained at the [Wistar Institute](https://wistar.org/) in Philadelphia in the early 1980s
  - Got to work with brilliant scientists like [Jon Yewdell](https://irp.nih.gov/pi/jonathan-yewdell) and [Walter Gerhard](https://www.researchgate.net/profile/Walter-Gerhard-2): “I don’t think I realize how lucky I was at that time to be around such amazing scientists”
  - The head of the lab told Paul, “If you want a research career that lasts for the rest of your life, study influenza”

## Where SARS-CoV-2 falls on the spectrum of its ability to mutate and what that means for immunity and vaccination [21:30]

- SARS-CoV-2 is in the middle of a spectrum
  - on the one end of the spectrum is influenza, which has so much [genetic drift](https://en.wikipedia.org/wiki/Genetic_drift) that every year you have to get a new vaccine
  - At the other end of the spectrum are polio, smallpox, pertussis, etc., whose mutations don’t seem to impact our immune system reaction
  - SARS-CoV-2 is in the middle
    - does not appear to have genetic drift like influenza where seems like a new virus every year
    - but it also appears that a “one and done” vaccine strategy won’t work
- The UK variant ([B.1.1.7](https://en.wikipedia.org/wiki/Lineage_B.1.1.7)) might be covered by current vaccines, but the Brazilian and South African [variants](https://en.wikipedia.org/wiki/Variants_of_SARS-CoV-2) might not be given significant changes in their binding properties
- Paul is on the FDA’s Vaccine Advisory Committee
  - meets in the first week in March to look at data and predict which flu strains the vaccine needs to cover that year
  - “it’s amazing we usually get them right given how much this virus mutates”
- Mutation frequency
  - Flu is a single-stranded RNA virus that constantly mutates
  - Measles is a single-stranded RNA virus that mutates in such a confined way that vaccines developed in the 1960s are still effective
  - SARS-CoV-2 is in the middle
- Viruses mutate to become more contagious but not necessarily more deadly, which would slow their ability to reproduce themselves
- The virus that left China was the first variant, [D614G](https://en.wikipedia.org/wiki/Variants_of_SARS-CoV-2#D614G), that swept through Europe and the US and is covered by current vaccines

**The critical question**: *To what extent will it drift away from immunity caused by vaccination?*

- But several new variants have now appeared
- B.1.1.7 seems close enough to D614G to be covered by the vaccine
- But… the other variants (South African, Brazilian, New York, etc.) are different, but so far aren’t “critically” different — meaning natural infection or vaccination still protects against hospitalization, ICU admission, and death
- We haven’t yet “crossed the line” to the point where vaccinated people are hospitalized or killed by a variant virus
- Peter wonders:
  - W*hen a vaccinated person is hospitalized with a variant, how will we know that it’s because their existing immunity was incapable of responding versus they simply had lost immunity*?
  - A*re we also checking for some quantitative or qualitative assessment of their existing immunity*?
  - Paul says if you had a strain that *should have been* susceptible to the vaccine, we really can’t tell if you had an adequate immune response and lost it OR… if you never really developed an adequate response at all.

## How the combination of short-term and long-term immune response to SARS-CoV-2 work together to provide durable immunity [28:00]

- Short-term antibody-mediated response ([humoral immunity](https://en.wikipedia.org/wiki/Humoral_immunity))
  - Isolate the variants
  - test the B cell response by seeing if they are neutralized in the lab by sera from people who are adequately immunized or people who are naturally infected
- Longer-term memory response ([cell-mediated immunity](https://en.wikipedia.org/wiki/Cell-mediated_immunity))
  - Testing B cells doesn’t take into account the T-helper cell responses
  - T cells tend to offer broader immunity

![](https://peterattiamd.com/wp-content/uploads/2021/05/fig-3-offit2-1024x722.png)

**Figure 3. Cell-mediated and antibody-mediated immune responses.** Image credit: [Boston University](https://sites.bu.edu/covid-corps/projects/science-communication/types-of-vaccines-infographics/)

- Testing humoral immunity is still useful
  - If the variants pass the B cell test, we don’t need to take action
  - we don’t know about T cell response, but we can’t depend on it
  - so if it’s failing the B-cell test, we’re going to take action
- [Shane Crotty](https://en.wikipedia.org/wiki/Shane_Crotty) and others at [La Jolla Institute](https://en.wikipedia.org/wiki/La_Jolla_Institute_for_Immunology) [found](https://science.sciencemag.org/content/371/6529/eabf4063) that people who were naturally infected and then re-infected were still protected
  - antibody responses can fade 5-7 months later
  - but memory B-cells, T-helper cells, and cytotoxic T-cells were still there
- Incubation periods
  - SARS-CoV-2 incubation period (from the time of first exposure to development of symptoms) is about six days
  - infections like rotavirus or influenza have very short incubation periods (1-2 days)
  - Others like [measles](https://en.wikipedia.org/wiki/Measles), [rubella](https://en.wikipedia.org/wiki/Rubella) (German measles), or [chickenpox](https://en.wikipedia.org/wiki/Chickenpox) have incubation periods of 10 to 14 days
  - Easier to eliminate a virus if a long incubation period
    - Measles was eliminated by 2000 and rubella by 2005
    - Measles only came back because if vaccine refusal
    - With long incubation periods, there is plenty of time for activation and differentiation of memory B-cells to become [effector cells](https://en.wikipedia.org/wiki/Effector_cell) ([antibody](https://en.wikipedia.org/wiki/Antibody)-producing cells)
  - With shorter incubation periods, best you can do is modify disease
- Can still stimulate long-lived memory cells to become antibody producing cells
  - but because the incubation period is so short, replication has already started
  - Takes 3-5 days to get activation and differentiation of memory cells
  - This is true of flu, [respiratory syncytial virus](https://en.wikipedia.org/wiki/Respiratory_syncytial_virus) (RSV), and [rotavirus](https://en.wikipedia.org/wiki/Rotavirus)
- But with a disease like measles (long-incubation period), as long as you have memory cells, you have plenty of time for activation and differentiation of those cells to become antibody-reading cells
  - So in that case can eliminate rather just modify disease
- SARS-CoV-2 is in between
  - has a 6-day incubation period
  - virus in the bloodstream is really not an important part of pathogenesis, so [IgG](https://en.wikipedia.org/wiki/Immunoglobulin_G) memory is a bit less important
  - Paul thinks that we can control this infection
  - Our choices are immunization or natural infection

**How the cellular immune system comes into play (32:30)**

- At first contact, neutralizing antibodies can provide immunity in the weeks and months following an infection
  - But 6-18 months later, neutralizing antibodies may not be there in sufficiently high enough titers
- Upon reinfection, virus is broken down into small (10- to 15-[mer](https://www.researchgate.net/post/What_is_the_meaning_of_mer_regarding_peptides_For_example_21-mer_peptide#:~:text=The%20%22mer%22%20refers%20to%20the,decapeptide%20or%2010%2Dmer%20peptide.&text=The%20%22mer%22%20nomenclature%20is%20also,of%20residues%20in%20the%20polymer.) [peptide](https://en.wikipedia.org/wiki/Peptide)) fragments on the surface of major antigen-presenting cells: dendritic cells, macrophages, and to some extent B-cells

![](https://peterattiamd.com/wp-content/uploads/2021/05/fig-4-offit2-1024x539.png)

**Figure 4. Types of antigen-presenting cells.** Image credit: [Akiko Iwasaki and Ruslan Medzhitov, Biorender](https://app.biorender.com/biorender-templates/figures/5c65c7b6bce1963300935374/t-5f7c7d573b9a9000abcfa12e-different-types-of-antigen-presenting-cells)

- The presentation of the antigen stimulates T-helper cells to do two things:
  - stimulate B-cells to make antibodies
  - stimulate cytotoxic T-cells to kill virus-infected cells

![](https://peterattiamd.com/wp-content/uploads/2021/05/fig-5-offit2.png)

**Figure 5. Helper T cells stimulate both antibody-producing B cells and cytotoxic T cells.**  Image credit: [Gertrud U. Rey, Virology Blog](https://www.virology.ws/2020/11/05/t-cell-responses-to-coronavirus-infection-are-complicated/)

- As long as you have immunological memory, you will get activation and differentiation of
  - memory B cells to become effector (antibody producing) cells
  - cytotoxic T-cells to become cells that kill virus infected cells
- Crotty’s work suggests that memory cells for natural SARS-CoV-2 infection is fairly long-lived
- Data on mRNA viruses suggest that there is stimulation of T-helper cells and cytotoxic T-cells after the second dose (implying a longer-lived response)
- Paul hopes both infection and vaccines will be protective for 3-4 years

> “But the good news about the mRNA strategy is this is a powerful immunogen. . .I’m amazed at how effective it is.” —Paul Offit

- With both this vaccine and smallpox, can get ipsilateral lymphadenopathy (enlargement of the lymph node enlargement under the arm the shot was given in)
  - Antigen-presenting cells travel to the local lymph node and then stimulate enough response that the lymph node actually enlarges
  - Not common with most vaccines
  - Peter and his wife had whole-body MRI scans after mRNA vaccines
    - the radiologist found that extensive lymphadenopathy
    - was enough that, out of context, it would have raised a concern of breast cancer in his wife
    - But he is seeing this response frequently in people who have had RNA vaccines (Moderna and Pfizer)

**Why is it that the J&J virus is able to provide such a benefit after only one injection whereas the RNA viruses needed that second injection?**

- Required number of doses
  - replication-defective adenovirus vaccines like J&J (human Ad26) induce cellular immunity after a single dose
  - one dose of mRNA vaccine gives you 80% effective protection whereas the second dose gives you 90% or 95%
  - Paul worries that people will skip the second dose – “the choice not to get that second dose is a choice probably to get less storable immunity, less complete immunity and likely less effective immunity against these variants”

## Importance of understanding relative vs. absolute risk reduction [38:15]

- Peter thinks the vaccine companies have not communicated clearly the difference between relative risk reduction and absolute risk reduction
  - Media said that Pfizer is 96% effective, Moderna 95% effective, but J&J is only 66% effective
  - Would lead you to ask why you would take J&J (or why not take 2 doses)
- Peter [wrote a post](https://peterattiamd.com/ns001/) about the difference between absolute risk reduction and relative risk reduction that explains this in detail
- Have to consider absolute risk reduction here
  - J&J vaccine has a 1.7% absolute risk reduction
  - Moderna has 1.2% absolute risk reduction
  - Pfizer may be less than 1%
  - All great vaccines, but J&J gets “the most bang for its buck”
- Why is there a discordance between the lowest relative risk reduction (in the mid-60s) and the highest absolute risk reduction (1.7%)?
  - The Pfizer and Moderna vaccines may have been tested on less susceptible populations
  - while J&J was tested on a sicker population that was therefore going to benefit more greatly
- In the [Pfizer trial](https://pubmed.ncbi.nlm.nih.gov/33301246/), there were 162 cases per 20,000 in the placebo group and 8 cases per 20,000 patients in the vaccine group
  - The absolute difference is much less dramatic than the relative risk
  - the absolute risk difference was ~0.9% and the difference was something along the lines of 8 versus 165
- makes Peter suspect that the Pfizer subjects were either less exposed or healthier
  - There was something in these populations that differed dramatically from the J&J population where there were 500 versus 100 infections
  - So the relative reduction wasn’t as high, but the absolute reduction was1.7%, which means the [number needed to treat](https://en.wikipedia.org/wiki/Number_needed_to_treat) (NNT) to prevent a negative outcome is very low, maybe around 60
- Paul suggests an analogy to think about it:
  - you have a certain risk of being hit by a car when standing on your front lawn
  - that risk increases if you cross the street
  - But you cross the street all the time without getting hit
  - The absolute risk of getting hit as you cross the street is very small, even though the relative risk is much higher than if you were standing on the lawn

## Implications of pausing the J&J vaccine due to reports of blood clotting in the brain [42:45]

- At the time of this podcast, the J&J vaccine had been given to ~6.9 million people in the United States
  - There were 6 serious clotting episodes and one person died
  - interestingly, all in women, which is probably not a coincidence although but it’s too soon to tell
  - saw the same with AstraZeneca, but is not clear whether that’s a coincidence or not
- Data for the J&J vaccine referenced in the [JAMA paper](https://jamanetwork.com/journals/jama/fullarticle/2777172)
  - Didn’t give [NNT](https://en.wikipedia.org/wiki/Number_needed_to_treat) but Peter estimated based on the reciprocal of the [absolute risk reduction](https://en.wikipedia.org/wiki/Risk_difference) (ARR)
  - NNT = 100 / 1.7 = ~60
  - That applies to all adverse reactions, including hospitalizations and death
- For this discussion, assume there’s about one case of [cerebrovascular sinus thrombosis](https://www.hopkinsmedicine.org/health/conditions-and-diseases/cerebral-venous-sinus-thrombosis) (blood clot in a cerebral vein) per million people who get the vaccine
  - ~ 1,850 people would be prevented from dying per million people who get the vaccine
  - So there’s a trade-off of about 2000:1 to prevent death
- Peter thinks the we overreacted by pausing the J&J vaccine
  - At least we have other vaccines, but that reaction might stop people from getting vaccinated
  - Paul says, “The minute you pause that vaccine, you sent a chill through people in this country. I think that it would affect not only this vaccine, but I think even it would spill over to any COVID vaccine, which is, I think, what worries me the most about this pause.”
- It’s appropriate to make sure physicians know about it
  - normally you’d treat thrombosis with heparin and that’s the worst thing to do in these cases (intravenous immunoglobulin may be the best treatment)
  - alert physicians so if within 2 weeks of getting the J&J vaccine a patient had a severe headache, chest pain, shortness of breath, leg pain, etc. they know to pay attention to that
- Many cities and states are no longer distributing the vaccine
  - might not matter in one sense because we have other vaccines available
  - but on the other hand, it might make people scared

> “If you ask me the question, ‘What do I fear most about this whole pandemic?’ it’s actually not the variants. … It’s that there would be a significant percentage of the population that is going to choose not to vaccinate so much so that we can’t get to that 80+% of population immunity we need to slow this virus.” —Paul Offit

- A nurse at Paul’s doctor’s office told him she was not going to get vaccinated
- Some specific groups say that [they will not get a vaccine](https://www.kff.org/coronavirus-covid-19/poll-finding/kff-covid-19-vaccine-monitor-march-2021/):
  - 29% of Republicans
  - 28% of white Evangelicals
  - 10% of Black Americans

## What constitutes herd immunity and the concerns of rising vaccine hesitancy [47:45]

- Paul defines herd immunity the same for both mucosal viruses like rotavirus and for non-mucosal, systemic viruses where the virus spreads into the bloodstream (like polio, measles, and rubella), even though rotavirus cannot be eliminated and the others can

![](https://peterattiamd.com/wp-content/uploads/2021/05/fig-6-offit2-835x1024.png)

**Figure 6. Representation of herd immunity.** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Herd_immunity)

- For SARS-CoV-2, as with rotavirus, it will not be eliminated, but we can aim to significantly slow the spread
  - When rotavirus vaccine was introduced, every year there were several million cases, ~75,000 hospitalizations, and roughly 60 deaths
    - no child got to age five without being infected
  - Rotavirus came into the US in 2006
    - within a few years, dramatic drop in the spread
    - It’s still out there, but it’s much, much less
    - many medical residents today have never seen a case of rotavirus-induced diarrhea and dehydration, which was common during Paul’s residency
- “So, you can control it, but you’re not going to eliminate it”

- There is a formula that considers the contagious index and the efficacy of the vaccine
  - You probably would need at least 80% of the population to be immune either from natural infection or immunization to slow the spread of SARS-CoV-2
  - It would slowly get under control if we can get all 194 countries to get a significant percentage of their population vaccinated
- We will have to give SARS-CoV-2 vaccines continually until other countries have gotten it under control
  - The US hasn’t had a case of natural polio since the 1970s
  - But we still vaccinate kids against polio because it still exists in places like Pakistan and Afghanistan
  - As long as it exists, it could always come back
  - That’s going to be true for SARS-CoV-2 too
- But we can control this virus if we can get at least 80% of the population immune
  - Peter accepts medical freedom and supports a person’s right to choose to not get a vaccine
  - He thinks we can get to herd immunity when enough healthy people who have refused vaccination survive the infection
  - Maybe 30% of American adults are going to refuse vaccination
- The COVID tracker reports 32 million people have been infected with SARS-CoV-2
  - but that’s only people who have been tested and found to be infected
  - The CDC estimates 85 million, and Paul guesses it’s probably closer to 100 million people who are now naturally immune
  - But we don’t know the overlap between those people and those who have been vaccinated – it’s a [Venn diagram](https://en.wikipedia.org/wiki/Venn_diagram)
    - People who have been infected and know it
    - people who have been infected but are unaware, and
    - A subset of the people who will refuse vaccines and then get infected

**Vaccine hesitancy:** ***how much does it matter?***

With all of these groups having natural immunity, and many others being vaccinated, are vaccine refusers a concern?

- Paul says this question is assuming that natural infection induces a durability and completeness of protection that is the same as the vaccine
- There have been cases where the vaccine was more effective than natural immunity (for example, [human papillomavirus](https://en.wikipedia.org/wiki/Human_papillomavirus_infection) (HPV), [tetanus](https://en.wikipedia.org/wiki/Tetanus), and the conjugated [Haemophilus influenzae b](https://en.wikipedia.org/wiki/Haemophilus_influenzae) (Hib) [pneumococcal](https://en.wikipedia.org/wiki/Pneumococcal_vaccine) vaccines)
- It might be reasonable to give those with natural immunity one shot of mRNA vaccine, like a booster strategy

Paul does not agree that people should be able to refuse vaccination in this case

- If you refuse a tetanus shot, it only affects you
- But if you refuse the SARS-CoV-2 vaccine, “you are making a choice potentially to catch and transmit a potentially fatal infection. And see, I don’t think that’s your choice”
- “If you’re going to stay in your house and the only time you ever walk outside you’re going to be really good about wearing a mask and making sure you’re 4 or 6 feet away from somebody else, great, but that’s not the way it’s going to play out”
- Paul’s hospital is discussing mandating the vaccine for people who work there
- He believes that people who work in a hospital with vulnerable hospitalized children have a responsibility to get vaccinated

Peter agrees that vaccines should be required in some cases

- working in healthcare is a privilege, not a right: “If you’re going to work in a hospital and take care of patients, I do not believe you should have the right to refuse vaccination”
- Peter supports mandated MMR vaccines, for example, to protect children from the negative impact of a parent’s bad decision
- Peter also thinks that society will have to make decisions about other privileges like who can fly on an airplane or enter a country
- “I’m sure every statement I’m making is making a newer and newer faction of people irate”
- Peter does support allowing private citizens who don’t work in jobs that put others at risk to refuse vaccines if they don’t lie about it and bear the consequences of their decision

**Reasons everyone should get vaccinated**

- Peter knows that his chances of dying if he contracted COVID are lower than being in a car accident, but he would still choose the vaccine because there appear to be non-trivial, long-term consequences from infection
  - An [article in JAMA](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2778090#:~:text=Respiratory%20and%20gastrointestinal%20symptoms%20are,seizures%2C%20and%20even%20suicidal%20behavior.) discussed some of the long-term neuropsychiatric complications that are being seen in up to 25% of people 6-12 months after infection
  - it’s a no-brainer to vaccinate when you weigh the risk of these types of complications against the risk of the vaccine
- Paul sees the hospital as a “microcosm of society”
  - may be 500,000 people who can’t be vaccinated because they take biologicals for their chronic disease or are getting chemotherapy for cancer
  - They are dependent on others to get protection from the virus
- When there was a measles epidemic in California, a Democratic State Senator (and pediatrician) named [Richard Pan](https://en.wikipedia.org/wiki/Richard_Pan) successfully lobbied for the elimination of the philosophical exemption to CA’s vaccine law
  - the state did not have a religious exemption, so that left only medical
  - A 7-year-old boy had been treated with chemotherapy for leukemia
    - He [came to hearings on eliminating the exemption](https://abcnews.go.com/Health/boy-battled-leukemia-lobbies-vaccinated-students/story?id=28919133) and told officials that he depended on them for protection
  - “*And I think that that’s how I see the hospital in some ways as society. And you don’t know who you’re running into when you’re getting on a subway or a bus or whatever. … If it’s a contagious disease that’s where I … draw the line*.”

## When we might reach herd immunity, future vaccines for children, and long-term outlook for maintaining population immunity [58:45]

**Vaccine mandate?**

- Whether or not it is the right thing to do, it’s very unlikely the authorities will mandate everyone get vaccinated
- More likely to use incentives
  - Such as universities may require a vaccine to return to in-person classes
  - Also, travel restrictions may ease up only for those who are vaccinated
- But Peter says we’ll never be able to have the societal equivalent of saying “you can’t attend school unless you are vaccinated”

***How long is it likely to be before we achieve herd immunity in the US? (59:45)***

- - First, let’s estimate 25-30% of the population is naturally infected
  - 22-23% of adults have been fully vaccinated now
    - There is overlap between these two groups
  - If assume close to 40% have immunity, need to fully immunize another 120 million people to get to 80%
    - We are currently administering more than 3 million doses of vaccine a day, but mostly two-dose vaccines
    - If we continue to administer 3 million doses a day, we could vaccinate that other 120 million people within 3-4 months
    - Around midsummer there will be enough vaccine for everyone, and that is when we will find out what percentage will refuse to be vaccinated

- **We’ll know whether or not we’ve succeeded with herd immunity when we see what happens next winter**

- - This is largely a winter respiratory virus, so next winter we will find out whether or not we’ve succeeded with herd immunity
  - Last year numbers shot up in early March (2000-2500 deaths a day) but came down April – June
  - In the summer there were hundreds of deaths a day
  - By November-December, took off again with 2000 deaths a day and rose to in the 4000s
  - then started to come down again
    - maybe because more people had either natural immunity or had been vaccinated
    - also probably related to weather
  - if we’re not at effective population immunity, we’ll see another surge this coming winter
- We’ll likely need to continue vaccinating for SARS-CoV-2, including children
  - now have a vaccine for 12 and up
  - by early 2022 should be 6 and up
- Kids are at risk from [multisystem inflammatory disease in children](https://en.wikipedia.org/wiki/Multisystem_inflammatory_syndrome_in_children) (MIS-C)
  - not uncommon and Paul has seen it up close
  - many of the kids had no symptoms when they were infected
  - about a month later, they come in with
    - high fever
    - involvement of heart, liver, lung, and kidneys
    - heart enzymes spilling out into the bloodstream
  - The kids test negative with a [polymerase chain reaction](https://en.wikipedia.org/wiki/Polymerase_chain_reaction) (PCR) test but they are antibody positive
    - their immune system has been induced to make an inflammatory response against themselves, primarily against the cells that line blood vessels
    - It’s largely a vasculitis, which can affect every organ’s blood supply
  - Paul thinks some of these kids are going to have long-term problems
  - Like [Kawasaki disease](https://en.wikipedia.org/wiki/Kawasaki_disease), it could be another multisystem inflammatory disease that causes long-term heart issues
- We will have a lot more data in about a year and will see one of two scenarios:
  - enough people refuse vaccination that we never truly achieve herd immunity
    - the real tragedy is for the vulnerable people who can’t be immunized because of their cancer treatment or rheumatologic treatments
  - we get to herd immunity because enough people are naturally infected and/or vaccinated
    - going down to age 6 for vaccines should be enough for herd immunity; maybe not even that young given that ~ 20% of the population is less than 18 years old
- In Michigan there has been a surge of cases but not deaths
  - Likely because 55-57% of people over 65 now have been vaccinated fully and ~75% have gotten at least one dose of vaccine
  - People over 55 account for 92% of COVID-19 deaths, so deaths are starting to drop as that age group is vaccinated

**Booster shots**

- In about 2 years we should have a better understanding of the need for booster shots
- Prior to COVID-19, [there](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1843247/) [have](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2271881/pdf/epidinfect00023-0213.pdf?fbclid=IwAR3U9u2pdzYOEystLSxjyaCLPrG57zNenxcVq81QhLBENQZjwt8wAd-gTsw) [been](https://pubmed.ncbi.nlm.nih.gov/15016880/) [challenge studies](https://en.wikipedia.org/wiki/Human_challenge_study) with other coronaviruses
  - Subjects were infected with one of the coronavirus serotypes and then a year later re-infected to measure the protective effect
  - [One study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2271881/pdf/epidinfect00023-0213.pdf?fbclid=IwAR3U9u2pdzYOEystLSxjyaCLPrG57zNenxcVq81QhLBENQZjwt8wAd-gTsw) found that a year later, antibody titres were still slightly raised but not always protective
- Paul thinks we might be protected for a few years, but not probably not decades

## Theories about the origins of SARS-CoV-2 [1:07:00]

**Where did SARS-CoV-2 come from?**

- Two theories about origin of SARS-CoV-2:
  - virus came from a bat or a bat via some intermediary mammal and made its way to humans
  - escape of a virus in a lab that happened to be near Wuhan
    - three labs near Wuhan did this type of research
    - not believed to be deliberate, but perhaps an accidental breach in protocol
- Laboratories have done [gain-of-function](https://en.wikipedia.org/wiki/Gain_of_function_research) studies to see what would happen if they alter a virus so it can do things it cannot do naturally
  - for example, rabies is a universally fatal virus that is not easily transmitted, so if it were made contagious in a lab it could be more easily studied
  - In the movie [Contagion](https://en.wikipedia.org/wiki/Contagion_(2011_film)), a fatal [Nipah](https://en.wikipedia.org/wiki/Nipah_virus) virus was made highly contagious and killed [Gwyneth Paltrow](https://en.wikipedia.org/wiki/Gwyneth_Paltrow) and other characters
- Paul is actually not sure humans are smart enough to have engineered this virus given how many things it can do
  - To confirm the story we’d need to compare sequences of those early strains as well as sera from people in China from before this virus was said to have spread
  - We’re dependent on a whistleblower from Wuhan
- We determined the origin of HIV using sequencing
  - When compared all the sequences, we found that HIV evolved from the [simian immunodeficiency virus](https://en.wikipedia.org/wiki/Simian_immunodeficiency_virus) (SIV) in Cameroon in the 1930s
  - Not clear how it was transmitted to humans – maybe a hunter injured a chimp and ended up infecting himself
- Paul’s theory it that it jumped from a bat to humans
  - presumably from an intermediate host that remains unidentified (maybe [pangolins](https://en.wikipedia.org/wiki/Pangolin))
  - China has not let us have access to the information we’d need to figure it out

## Preparing for the possibility of a future pandemic and how we can learn from our mistakes [1:10:40]

**If not when**

If it occurred naturally, it’s a question of if (not when) this will happen again

- Within about 20 years we’ve had [SARS-1](https://en.wikipedia.org/wiki/Severe_acute_respiratory_syndrome_coronavirus) (~2002), [MERS](https://en.wikipedia.org/wiki/Middle_East_respiratory_syndrome) (~2012), and now SARS-CoV-2
- Paul says we should assume this will happen again
- We need a level of international collaboration … an international surveillance system where all countries are open to this, where we can identify it, do the kinds of works we need to do not just to make a vaccine, but to have personal protective equipment and ventilators or anything else that you’re going to need, so that we’re not overwhelmed by this

**Possible future scenarios**

- No one alive has lived through something like this as an adult (and only a very few as infants in 1918-19)
- If the new virus is either more virulent with the same degree of transmissibility as SARS-CoV-2, or it’s similar in virulence with an even greater transmissibility, the next pandemic could be worse
  - Peter says we got lucky with SARS-1 and MERS because if their biology – for example, MERS was so deadly that it didn’t spread well
  - Paul agrees: both SARS-1 and MERS did not have the level of asymptomatic transmission that SARS-CoV-2 has
  - Those diseases also caused moderate to severe disease, so it was easy to identify who was infected
- SARS-CoV-2 is more likely to be like polio
  - As a child of the 1950s, Paul remembers the horrors of polio
  - only about one of every 200 people who was infected with polio virus was paralyzed
  - a lot of asymptomatic transmission occurred
- Peter uses the analogy of driving a race car
  - the worst thing you can do is brake too late. Then you have to brake much harder than you want to and you’re probably going to crash
  - Peter says,“I sort of feel like that’s what happened in the United States, which is we didn’t brake soon enough and when we did brake, we had to brake way harder than we should have and we crashed”

> “At the heart of that question is how much do I have faith in human nature that we can learn from these things, that we will have … international collaborations and more open borders regarding sort of scientific inquiry. We haven’t been very good at that so far. If we don’t learn our lesson here, I mean, we’re never going to learn it. So, I don’t know. I don’t have an enormous amount of faith in human nature that we’re going to learn from this.” —Paul Offit

**Paul’s ideas for preparing for the next pandemic (01:15:15)**

- Need international collaboration for surveillance and sequencing
- Then need to make sure everyone has what they need, because “we’re only as strong as the weakest nation”
  - even with the vaccines there has been a certain level of nationalism
  - Paul respects and admires Dr. Fauci, whom he calls a “phenomenal science communicator” and a “brilliant man,” but he was disappointed when Fauci said the US did not need to approve any more vaccines because it had enough

> “I think our country has a responsibility to all countries in this world who are economically and technologically advanced to provide vaccine for everyone if we can – and we can.” —Paul Offit

- The mRNA vaccine doses are measured in micrograms (µg or mcg) – that’s a millionth of a gram (10-6)
  - The vaccine can be produced in kg (103), so there’s a nine-log difference
  - Paul says we can and should make billions of doses of an mRNA vaccine for the world, even if it means restricting intellectual property rights, because it’s the right thing to do

**Taking a global perspective: international vaccine hesitancy and what the US needs to do better during the next global pandemic (1:17:15)**

*Global vaccine hesitancy*

- The [Vaccine Confidence Project](https://www.vaccineconfidence.org/)
  - Run by [Heidi Larson](https://www.lshtm.ac.uk/aboutus/people/larson.heidi) at the [London School of Hygiene & Tropical Medicine](https://www.lshtm.ac.uk/aboutus/people/larson.heidi)
  - She is the author of [Stuck: How Vaccine Rumors Start — and Why They Don’t Go Away](https://www.amazon.com/Stuck-Vaccine-Rumors-Start-They/dp/0190077247)
  - Data shows that France is the least vaccine confident country in the world
- There are two groups of vaccine refusers:
  - Skeptics
    - Want to see the data to make sure that what they’re putting into their bodies has been adequately tested and vetted
    - Paul considers himself a skeptic
    - But at this point (120 million people in the US), he says it’s clear that the mRNA vaccines are highly effective and don’t appear to have a rare serious side effects
    - Last September only about 30% of people said they would get vaccinated, then by December it was around 40%, and a [recent survey](https://www.pewresearch.org/science/2021/03/05/growing-share-of-americans-say-they-plan-to-get-a-covid-19-vaccine-or-already-have/) found it was at 70%
  - Cynics
    - don’t trust the government, pharmaceutical companies, or the medical community
    - Paul is amazed that some of them work in the medical profession
    - [Neil deGrasse Tyson](https://en.wikipedia.org/wiki/Neil_deGrasse_Tyson) has a great [quote](https://twitter.com/neiltyson/status/1311127369785192449?lang=en) about this: “You can’t use reason to convince anyone out of an argument that they didn’t use reason to get into”
  - raises hard questions about using carrots and sticks if they are putting others at risk

**Where did things go wrong in our response to the most recent pandemic? (1:19:00)**

- Peter says that the greatest single failure in the past year, mostly on the part of the government, was how long it took to get testing up and running
  - Too many things weren’t in place: reagent for PCR tests, PCR machines, and other critical infrastructure were lacking
  - If we were prepared, as soon as we had the sequence, we would have been able to rapidly deploy tests
  - Other things went well, like the speed with which the vaccine has been developed, and “the evolution of insight into critical care has actually been pretty darn impressive”
  - But testing speed fits Peter’s analogy of waiting way too long to hit the brakes and then slamming on the brakes and crashing the car
- Paul agrees: we had the sequence by January of 2020 and the virus started to kill Americans two months later
  - We “put all our eggs in the CDC basket” and needed many more groups making and quality controlling the tests
  - The CDC messed up the test – their negative control ended up being positive so those tests were useless
  - by the time that all got sorted out, South Korea had done 500,000 tests when we had done fewer than 5,000 (although we are a much more diverse population and are less “cower-able”)
- we did not have great federal leadership: we would have been much better off if we’d focused on getting testing in place, quarantining, and restricting national travel

> “We are roughly 4% of the world’s population and 20% of the world’s deaths when we have a technologically and economically advanced society. So, there’s really no excuse for doing it as badly as we did it.” —Paul Offit

§

## Selected Links / Related Material

**Peter’s newsletter addressing the concerns about mRNA vaccines**: [mRNA vaccine technology](https://peterattiamd.com/mrna-technology/) | Peter Attia (peterattia.com) [9:15]

**Article about the unsuccessful Merck trial of an HIV vaccine:** [The failed HIV Merck vaccine study: a step back or a launching point for future vaccine development?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2234358/) | *Journal of Experimental Medicine* (Sekaly 2008) | [20:00]

**Paper on lasting immunity to SARS-CoV-2**: [Immunological memory to SARS-CoV-2 assessed for up to 8 months after infection](https://science.sciencemag.org/content/371/6529/eabf4063) | *Science* (Dan … Crotty 2021) | [28:45]

**Peter’s post about the difference between absolute risk reduction and relative risk reduction**: [Studying Studies: Part I – relative risk vs. absolute risk](https://peterattiamd.com/ns001/) | (peterattiamd.com) (January 8, 2018) | [39:15]

**Pfizer trial**: [Safety and Efficacy of the BNT162b2 mRNA Covid-19 Vaccine](https://pubmed.ncbi.nlm.nih.gov/33301246/) | *New England J Med* (Polack et al. 2020) | [40:30]

**Explanation of the number to treat (NNT) concept**: [The NNT, explained](https://www.thennt.com/thennt-explained/) (thennt.com) | [41:45]

***JAMA*** **paper on the J&J vaccine**: [The Johnson & Johnson Vaccine for COVID-19](https://jamanetwork.com/journals/jama/fullarticle/2777172) | *JAMA* (Livingston et al. 2021) | [43:45]

**J&J vaccine “pauses” recommended or implemented by**: [45:00]

- **The federal government (CDC and FDA)**: [Joint CDC and FDA Statement on Johnson & Johnson COVID-19 Vaccine](https://www.cdc.gov/media/releases/2021/s0413-JJ-vaccine.html) (April 13, 2021)
- **States and several pharmacies**: [States swiftly pause the use of Johnson & Johnson’s vaccine after a U.S. advisory](https://www.nytimes.com/2021/04/13/us/states-johnson-vaccine-pause.html) | Eileen Sullivan, Michael Gold, and Giulia McDonnell Nieto del Rio, *The New York Times* (April 13, 2021)
- **California**: [COVID: California puts J&J vaccine on hold](https://www.mercurynews.com/2021/04/13/covid-contra-costa-county-puts-jj-vaccine-on-hold/) | Nico Savidge and John Woolfolk, *The Mercury News* (April 13, 2021)

**Kaiser Family Foundation poll finding that 29% of Republicans, 28% of white Evangelicals and 10% of Black Americans do not plan to get a COVID-19 vaccine***:* [KFF COVID-19 Vaccine Monitor: March 2021](https://www.kff.org/coronavirus-covid-19/poll-finding/kff-covid-19-vaccine-monitor-march-2021/) | Liz Hamel, Lunna Lopes, Audrey Kearney, and Mollyann Brodie, *KFF* (March 30, 2021) | [47:30]

**Article about long-term neuropsychiatric complications of COVID-19**: [How COVID-19 Affects the Brain](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2778090#:~:text=Respiratory%20and%20gastrointestinal%20symptoms%20are,seizures%2C%20and%20even%20suicidal%20behavior.) | *JAMA Psychiatry* (Boldrini et al. 2021) | [56:45]

**Young boy with leukemia who testified against California vaccine law exemptions**: [7-Year-Old Cancer Patient Makes Adorable Argument for Vaccines](https://abcnews.go.com/Health/boy-battled-leukemia-lobbies-vaccinated-students/story?id=28919133) | Gillian Mohney, *ABC News* (February 12, 2015) | [57:45]

**Pre-COVID-19 challenge studies with coronaviruses**: [1:05:45]

- [Effects of a “new” human respiratory virus in volunteers](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1843247/) | *British Medical Journal* (Bradburne et al. 1967)
- [The time course of the immune response to experimental coronavirus infection of man](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2271881/pdf/epidinfect00023-0213.pdf?fbclid=IwAR3U9u2pdzYOEystLSxjyaCLPrG57zNenxcVq81QhLBENQZjwt8wAd-gTsw) | *Epidemiol. Infect.* (Callow et al. 1990)
- [Prior infection and passive transfer of neutralizing antibody prevent replication of severe acute respiratory syndrome coronavirus in the respiratory tract of mice](https://pubmed.ncbi.nlm.nih.gov/15016880/) | *J Virology* (Subbarao et al. 2004)

**Heidi Larson’s book about vaccine hesitancy**: [Stuck: How Vaccine Rumors Start — and Why They Don’t Go Away](https://www.amazon.com/Stuck-Vaccine-Rumors-Start-They/dp/0190077247) by Heidi J. Larson (2020) | [1:17:15]

**Survey indicating that about 70% of Americans are now willing to get the vaccine**: [Growing Share of Americans Say They Plan To Get a COVID-19 Vaccine – or Already Have](https://www.pewresearch.org/science/2021/03/05/growing-share-of-americans-say-they-plan-to-get-a-covid-19-vaccine-or-already-have/) | Cary Funk & Alec Tyson, *Pew Research Center* (March 5, 2021) | [1:18:15]

§

## People Mentioned

- [Louis Pasteur](https://en.wikipedia.org/wiki/Louis_Pasteur) [8:45]
- [Albert Sabin](https://en.wikipedia.org/wiki/Albert_Sabin) [14:15]
- [Jonas Salk](https://en.wikipedia.org/wiki/Jonas_Salk) [20:45]
- [Jonathan Yewdell](https://irp.nih.gov/pi/jonathan-yewdell) [21:00]
- [Walter Gerhard](https://www.researchgate.net/profile/Walter-Gerhard-2) [21:00]
- [Shane Crotty](https://en.wikipedia.org/wiki/Shane_Crotty) [28:45]
- [Richard Pan](https://en.wikipedia.org/wiki/Richard_Pan) [57:45]
- [Heidi Larson](https://www.lshtm.ac.uk/aboutus/people/larson.heidi) [1:17:15]
- [Neil deGrasse Tyson](https://en.wikipedia.org/wiki/Neil_deGrasse_Tyson) [1:18:45]

§

![](https://peterattiamd.com/wp-content/uploads/2020/11/2x1-offit-500x500.jpg)

##### Paul Offit, M.D.

Dr. Paul Offit is a pediatrician specializing in infectious diseases and an expert on vaccines, immunology, and virology. He is the co-inventor of a rotavirus vaccine that has been credited with saving hundreds of lives every day. Offit is the Maurice R. Hilleman professor of vaccinology, professor of pediatrics at the Perelman School of Medicine at the University of Pennsylvania and director of The Vaccine Education Center at  Children’s Hospital of Philadelphia (CHOP). Dr. Offit is currently a member of the National Institutes of Health (NIH) working group on vaccines, a subgroup of the Accelerating COVID-19 Therapeutic Interventions and Vaccines (ACTIV) project that is planning a strategy to combat COVID-19. He is also a member of the FDA’s Vaccines and Related Biological Products Advisory Committee (VRBPAC). Previously, he was a member of the Centers for Disease Control and Prevention’s (CDC) Advisory Committee on Immunization Practices. Dr. Offit is a board member of Vaccinate Your Family and Autism Science Foundation and the author of eleven books.

Website: [paul-offit.com](https://www.paul-offit.com/about-paul-offit-md)

Twitter: [@DrPaulOffit](https://twitter.com/drpauloffit)

Facebook: [Paul Offit](https://www.facebook.com/paul.offit)