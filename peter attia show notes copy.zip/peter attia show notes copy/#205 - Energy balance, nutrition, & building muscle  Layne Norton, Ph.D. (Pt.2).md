# #205 – Energy balance, nutrition, & building muscle | Layne Norton, Ph.D. (Pt.2)

**Source:** [https://peterattiamd.com/laynenorton2/](https://peterattiamd.com/laynenorton2/)

---

##### Check out more content from Layne Norton, Ph.D.:

- - *(May 24, 2021)* [#163 – Building muscle, losing fat, and the importance of resistance training](/laynenorton/)
  - *(May 2, 2022)* [#205 – Energy balance, nutrition, & building muscle](/laynenorton2/)

Layne Norton holds a Ph.D. in nutritional sciences and is a physique coach, natural bodybuilder, and [previous guest on The Drive](https://peterattiamd.com/laynenorton/). In the first half of this episode, Layne dives deep into the topic of energy balance, including the role that macronutrients and calories play in weight loss. He describes how many people struggle with tracking food and calories on their own across a variety of diets and how all of this can impact nutritional habits and behaviors. In the second half of the episode, Layne discusses the importance of protein and weightlifting for improving one’s body composition and increasing muscle mass. He explains how he would prescribe different training and nutrition programs for two hypothetical clients—a 50-year-old female who is entering menopause and wants to improve her health, and a 40-to-50-year-old male who wants to maximize muscle mass. Additionally, Layne discusses a number of supplements that could potentially benefit a training program including whey protein, branch chain amino acids, creatine, nitric oxide boosters, and more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/laynenorton2/the_Drive_public.png)

Play

#205 - Energy balance, nutrition, & building muscle | Layne Norton, Ph.D. (Pt.2)

#205 - Energy balance, nutrition, & building muscle | Layne Norton, Ph.D. (Pt.2)

1x15s30s

0:002:55:43

## We discuss:

- Defining energy balance and the role of calories [2:30];
- Defining a calorie, whether they are all created equal, and how much energy you can extract from the food you eat [8:00];
- Factors influencing total daily energy expenditure [12:15]:
- The challenge of tracking energy expenditure accurately, and the thermic effect of different macronutrients [23:30];
- Challenges of sustained weight loss: metabolic adaptation, set points, and more [34:45];
- Weight loss strategies: tracking calories, cheat meals, snacks, fasting, exercise, and more [40:45];
- Sitting in discomfort, focusing on habits, and other lessons Layne learned as a natural bodybuilder [52:15];
- Commonalities in people who maintain long-term weight-loss [1:01:15];
- Does a ketogenic diet result in greater energy expenditure? [1:03:15];
- The metabolic benefits of exercise, muscle mass, and protein intake [1:15:00];
- The impact of lean muscle and strength on lifespan and healthspan [1:20:00];
- Hypothetical case study #1: Training program for 50-year-old female [1:27:45];
- Muscle protein synthesis in a trained athlete vs. untrained individual following a resistance training program [1:31:30];
- Protein and amino acids needed to build and maintain muscle mass [1:37:15];
- Nutrition plan for the hypothetical 50-year-old woman starting a program to build lean muscle [1:42:45];
- Dispelling myths that excess protein intake increases cancer risk through elevations in mTOR and IGF [1:55:30];
- Hypothetical case study #2: Training program for a 50-year-old, trained male wanting to increase muscle mass [2:04:00];
- Maximizing hypertrophy while minimizing fatigue—is it necessary to train to muscular failure? [2:11:30];
- Ideal sets and reps for the hypothetical 50-year-old male interested in hypertrophy [2:16:15];
- Maximizing hypertrophy by working a muscle at a long muscle length [2:22:15];
- Recommended lower body exercise routines and tips about training frequency [2:24:00];
- Nutrition plan for the hypothetical 50-year old male wanting to add muscle [2:29:00];
- Cycling weight gain and weight loss when building lean muscle mass, and expectations for progress over time [2:33:30];
- Supplements to aid in hypertrophy training [2:38:30];
- More.

[fusebox\_full\_player social\_twitter=”true” social\_facebook=”true” social\_linkedin=”true” social\_pinterest=”true” social\_email=”true” ]

§

## Show Notes

**\*Notes from intro**:

- Layne was a previous guest on [episode #163 back in May of 2021](https://peterattiamd.com/laynenorton/); in that discussion, we only got through about half of what we wanted to
- In this episode, we really dive into 2 major topics
- 1) Energy balance and what role macronutrients and calories play in weight loss
  - This really gets into the energy balance equation and what it means, what it doesn’t mean
  - Is a calorie a calorie? And what does this mean in different diets?
  - We also speak about the struggle people have with tracking food and calories on their own across a variety of diets and how all of this can impact someone’s nutritional habits and behaviors
- 2) The importance of protein in weightlifting through two different hypothetical case studies
  - The first is Layne’s work with a 50-year old female who wants to improve her health through nutrition and exercise
    - She was more interested in cardio than lifting weights
  - The second is a 40-50-year old male who want to focus on maximizing muscle mass
  - These 2 cases are illustrative of what many people war going though
- We end this conversation by looking at a number of supplements, including whey protein, branch chain amino acids, leucine specifically as one of the branch chain amino acids, creatine, and nitric oxide boosters
- Layne is a bodybuilding figure and physique coach, a natural pro-body builder, and a professional powerlifter
- He received his undergraduate degree in biochemistry and a Ph.D in nutritional sciences from the University of Illinois

## Defining energy balance and the role of calories [2:30]

- Most people think [energy balance](https://en.wikipedia.org/wiki/Energy_homeostasis) is about tracking calories in and calories out
  - If I burn 250 calories a day and eat 2000 calories then I should lose 1 lb a week
  - When this doesn’t happen they say, “*this doesn’t work*”, and there’s a lot of different reasons for this (we’ll come back to later)
- Energy balance is calories in versus calories out (energy consumed and energy spent)
- What is energy?
  - A lot of people say calories don’t exist, you can’t see them under a microscope
- We’re talking about energy stored in the chemical bonds of food
  - When food is broken down these molecules go through metabolism: glycolysis, the Krebs cycle (shows in the figure below)
    - Energy is liberated in these cycle but captured mostly as ATP
    - ATP is our high-energy phosphate

![](https://peterattiamd.com/wp-content/uploads/2022/04/f1-laynenorton2-1024x731.png)

**Figure 1. Metabolism: glycolysis and the Krebs cycle**  Image credit: [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:CellRespiration.svg)

**How energy is stored**

- But you can’t store a bunch of [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate) because it is an unstable molecule
- We have evolved to store fat in adipose tissue; this is a store of excess energy
- You can store some energy in glycogen
- Layne argues that you can’t really store energy as protein
  - Some claim that you can break down lean tissue but to him this is like saying, “*Let’s build a house so it’s a reservoir for wood*”
- The contribution of [glycogen](https://en.wikipedia.org/wiki/Glycogen) to your relative energy stores, it’s actually really small
  - About 1500 to 2000 calories of energy
- So your adipose tissue is by far the biggest energy store
  - It’s economical for space because you can fit a large amount of lipid/fat in a small area
  - It’s energy dense
  - It’s relatively easy to convert fat to ATP
- Glycogen has to track with a lot of water; it’s not an efficient way to store energy

## Defining a calorie, whether they are all created equal, and how much energy you can extract from the food you eat [8:00]

- [Calories](https://en.wikipedia.org/wiki/Calorie) are literally a measurement of energy
  - It’s just a unit of measurement
- When people ask, “*Aren’t all calories created equal?”* That’s like saying, “*Are different notches on your speedometer different?*”
- Think of calories as the energy stored in chemical bonds that can be transferred through various metabolic processes
  - Metabolism is simply trying to capture the metabolizable energy in food
- One important caveat— not everything in food is metabolizable, especially with regards to [fiber](https://en.wikipedia.org/wiki/Dietary_fiber) and specifically insoluble fiber
  - It used to be thought that insoluble fiber can’t be digested at all, that it contributes zero calories
  - Now there is some evidence that our gut microbiome can extract some calories from insoluble fiber
    - Work by [Suzanne Devkota](https://www.devkotalab.com/research) shows this, maybe 1-4 calories per gram
    - 4 calories per gram is the normal amount found in carbohydrates

|  |  |
| --- | --- |
| Food component | Calories/ gram   (or kcal/g) |
| Polyols (sugar alcohols, sweeteners) | 2.4 |
| Organic acids | 3 |
| Carbohydrate | 4 |
| Protein | 4 |
| Alcohol (ethanol) | 7 |
| Fat | 9 |

- So the big C (calorie) = 1000 little c (calories) or kcal (kilocalories)
  - Most people say they eat 2000 calories but in realities this is 2000 kcal
- [A calorie is defined as](https://en.wikipedia.org/wiki/Calorie) the energy needed to heat 1 gram of water from 14.5 to 15.5-degrees Celsius at 1 atmosphere
- Normally we would think of a [joule](https://en.wikipedia.org/wiki/Joule) as a unit of energy
- It’s also important to point out the [conservation of energy](https://en.wikipedia.org/wiki/Conservation_of_energy) as it changes forms
  - The energy in food is stored in its chemical bonds (chemical energy)
  - This is turned into electrical energy via the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain) (shown in the earlier figure)
  - Then we turn it back into chemical energy with the generation of [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate) (at the end of the electron transport chain)
    - ADP + Pi + free energy → ATP + H2O
    - The phosphate bond created between ADP and inorganic phosphate (Pi) stores energy
    - This energy is transferred to a hydrocarbon with the production of fatty acids; reactions are coupled to ATP hydrolysis to transfer energy to another bond
    - ATP hydrolysis releases energy, ATP + H2O → ADP + Pi + free energy
    - Carbon-hydrogen bonds are the most energy dense bonds in our body, more so than carbon-oxygen bonds
    - [Fatty acids](https://en.wikipedia.org/wiki/Fatty_acid) are long chains of carbons and hydrogens; this is why fatty acids have more calories per g than carbohydrates
      - [Carbohydrates](https://en.wikipedia.org/wiki/Carbohydrate) have more oxygens; see the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/04/f2-laynenorton2-1024x469.png)

**Figure 2. Comparing the composition of a fatty acid to the carbohydrate glucose.** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Fatty_acid)

- Fats, through [beta-oxidation](https://en.wikipedia.org/wiki/Beta_oxidation) are broken down in 2-carbon units to directly create Acetyl-CoA which goes directly into the Krebs cycle
- For glucose, there’s a lot more involved to generate ATP
- Glucose does have benefits in terms of the amount of oxygen required [is less] to generate the same ATP
- Peter notes, “*you can really liberate different amounts of energy from the same foods, depending on many things, but presumably based on your gut microbiome. That’s probably one of the things that’s going to create a pretty sizable delta when it comes to how much food you’re capturing. In other words, how much of that chemical energy you are able to recoup and repurpose into electrical energy.*”
- Layne agrees, there is evidence that the gut microflora in people prone to obesity are better able to extract energy from the foods they eat
  - This could be reverse causation, that the diet these obese people eat causes these types of gut microfloa to grow and so forth
  - You have to be careful about establishing correlation versus causation
  - It is possible to assess how much energy is lost in fecal matter
    - It’s usually 5-10%; this accounts for 95% of people but there is variation
  - So for the vast majority of people, differences in calories extracted by gut microflora isn’t going to cause a significant difference (only for a few outliers)
- There is some variability in the amount of energy you can extract from the food you eat

## Factors influencing total daily energy expenditure [12:15]

**Basal metabolic rate (BMR)**

- The [BMR](https://en.wikipedia.org/wiki/Basal_metabolic_rate) is usually about 50-70% of the energy people expend per day
  - This is basically the cost of keeping the lights on
- BMR can be measured by putting someone in a metabolic chamber and having them lie there awake but not moving
  - This is slightly different from the energy expenditure while sleeping (the resting metabolic rate, RMR)
- When Layne had his BMR measured it was between 1,900 – 1,950 calories per day
- Peter notes when most people have their BMR measured it’s usually not done with [indirect calorimetry](https://en.wikipedia.org/wiki/Indirect_calorimetry) (which is very rigorous)
  - It usually relies on on heart rate and respiratory rate
  - This can probably give some approximation, but it’s important to understand that there’s an enormous error that’s introduced when you make that approximation
- Layne agrees; [direct calorimetry](https://en.wikipedia.org/wiki/Calorimetry) is the most rigorous way to measure one’s metabolic rate
  - For this you’re in a metabolic chamber and how much heat you’re generating is measured
  - From the heat generated it’s possible to determine your total daily energy expenditure then determine your BMR using an equation based on your oxygen consumption versus your CO2 production (this is also done for indirect calorimetry)
  - You’re inside a hood, you’re breathing into a tube essentially
  - Your metabolic rate is very closely associated with how much oxygen you consume
  - How much oxygen you consume versus how much CO2 you expire will give a good idea of your metabolic rate
    - Because the end products of metabolism are CO2 and water
    - This is also why one can use [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water) to estimate energy expenditure (he’ll come back to this later)
    - There is a constant for water, knowing these constants and making assumptions can tell how much energy is being generated and you can come up with a relatively accurate estimate of your metabolic rate
  - The [Weir formula](https://en.wikipedia.org/wiki/Weir_formula) is used, energy expenditure = (3.94)(VO2) + (1.11)(VCO2)
    - This is heavily weighted toward oxygen, about 4x oxygen used plus 1 times the carbon dioxide produced
    - For anyone who has ever had a [VO2 max](https://en.wikipedia.org/wiki/VO2_max) test, ask the lab to give you the raw data; they will usually provide the VO2 and VCO2 in 15-second intervals
    - Plug the VO2 and VCO2 into the Weir formula to get how many calories per minute you’re consuming when your energy output is at your max
    - A highly trained individual will easily get to 20 calories per minute of energy demand

**Factors influencing energy expenditure [16:38]**

> “*Lean mass is by far the biggest correlate to total daily energy expenditure and resting metabolic rate.*” —Layne Norton

- Lean mass requires quite a bit of oxygen compared to adipose tissue
- Also when you start doing activity, it requires a lot of oxygen
- All the energy you expend in 1 day is called the **TDEE** (total daily energy expenditure)
  - The biggest portion of this for most people is the BMR
  - An exception would be an elite athlete who trains for 6-8 hours a day; this would push the energy needed for physical activity higher than the BMR
- Next to consider is the **TEF** (thermic effective food or diet induced thermogenesis)
  - For most people this is anywhere from 5-10% of the total daily energy expenditure
  - This is very hard to measure
  - Usually it’s expressed in terms of calories per minute because it’s only measured over the course of a couple hours
  - This is not a big contributor but should be considered
  - This is also macronutrient-dependent (he’ll come back to this later)
- The last component is physical activity
  - When people hear this, they think exercise; but this is all physical activity
  - For most people, the biggest component of their physical activity is something called **NEAT** (non-exercise activity thermogenesis)
    - This is extremely modifiable
    - People who are resistant to obesity tend to fidget a lot
    - Obese-prone individuals tend to have a very low NEAT
- A study done by Levine in 1999 where they overfed people by 1000 calories per day and looked at their total energy expenditure in a metabolic ward and how much weight people gained
  - Published in Science, [Role of nonexercise activity thermogenesis in resistance to fat gain in humans](https://pubmed.ncbi.nlm.nih.gov/9880251/)
  - Some people gained more weight than expected
  - 1 person did not have significant weight gain; they did gain weight but not enough to reach significance
- It is important to distinguish between NEAT and exercise
  - Exercise is purposeful and not part of NEAT
- NEAT seems like nothing, a fidget, but thousands of those movements over the course of a day actually add up
  - Whenever you try to do something that also requires your brain, you’re going to stop doing that because you actually can’t really do two things at once in terms of thinking about it
  - NEAT truly is spontaneous energy expenditure
  - It appears to be modifiable by about 500 – 600 calories per day
    - This is seen in both overfeeding and underfeeding studies
    - People who lose 10% of their body weight, they’ve seen up to a 500 calorie reduction in NEAT
      - This is a bip portion of it; then you consider purposeful exercise
- When people want to invalidate energy balance he says, “*Listen, you ate those carbons. Something must happen to them. They don’t flutter off into oblivion and you don’t create them out of nothing. Something has to happen to them*”
- A lot of metabolic tracer studies show what happens to them

## The challenge of tracking energy expenditure accurately, and the thermic effect of different macronutrients [23:30]

**Sources of error when tracking calories** [21:30]

- The confusion arises when someone tracks their calories, sees a 500 calorie deficit but doesn’t lose weight
- There are several sources of error
  - People often weigh themselves sporadically
  - It’s virtually meaningless to weigh yourself only once a week
    - Layne is very regimented about this: weigh yourself first thing in the morning after voiding your bladder and bowel (if possible) before eating
    - Take that weight every single day and average it for the week
    - Compare week to week averages
    - Weight can easily fluctuate 2% per day; so if you’re 200 lbs you could be 204 or 196
    - You don’t want just 1 isolated data point
    - A shift in fluids can make a difference but weekly and monthly changes in weight are dictated more by your actual body mass

**Wrist devices that measure energy expenditures are not particularly accurate**

- The other thing that confuses people is tracking their energy expenditure
- A study of wrist devices found they overestimate exercise energy expenditure from 28-93%
  - 20 different devices were compared
  - Published in the *Journal of Personalized Medicine* in 2017, [Accuracy in Wrist-Worn, Sensor-Based Measurements of Heart Rate and Energy Expenditure in a Diverse Cohort](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5491979/)
- This is a problem when you’re exercising and the device says you burned 500 calories when in reality you probably burned around 260-400 calories
- Layne often tells people, “*What do you think is more likely? That you have found a way to violate the laws of thermodynamics or that this watch might not be accurate? Because I’m going to go with the latter*.”
- It is also difficult to accurately track calories because there is up to a 20% error allowed in food labels
- People also have trouble estimating their energy intake
- There was a study in the 90s of people who self-reported as resistant to weight loss
  - Published in *The New England Journal of Medicine* in 1992, [Discrepancy between Self-Reported and Actual Caloric Intake and Exercise in Obese Subjects](https://www.nejm.org/doi/full/10.1056/NEJM199212313272701)
  - These people claimed they ate 1200 calories a day and didn’t lose weight
  - They put them in a metabolic ward and used [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water) as well as direct calorimetry
    - Doubly labeled water is a free living way of determining energy expenditure
  - They had the people track and report their food and found the average under reporting was 50%
    - This is in line with other studies, most overweight people under report by 30-70%
    - Lean people on average under report by 10-18%
  - Layne doesn’t think people are lying but simply horrible at estimating their food intake

> “*If I put a salad in front of you and I dump 50 grams of oil on it versus 20 grams of oil, you will have absolutely no idea of the difference*”— Layne Norton

- Layne often tells people, “*If you really believe that you are not able to eat calorie deficit and lose weight, I want you to, just for one week, track every single piece of food you put in your mouth*”
  - Usually when people come back their mind in blown
  - They thought they were eating 600 calories but counted 2,700
  - They didn’t realize they grabbed a handful of nuts or chips or whatever it is
    - In isolation none of that stuff is a big dial but when you accumulate it throughout the day, it can be a big deal

**Peter’s experiment tracking energy expenditure with a metabolic chamber** [27:30]

- 8 years ago Peter had the luxury of being able to spend 6 days inside a metabolic chamber, in 2-day blocks
- He loved it because he got to be in a room where nobody could bug him and he had it arranged so he could do all his exercising
  - He had his bike on a fluid trainer
  - He had a ton of weights, a plyometric box, and a bed
  - He had amazing food prepared by a metabolic kitchen who measured everything to the gram
- Afterwards he did a 10-day [doubly labeled water (DLW)](https://en.wikipedia.org/wiki/Doubly_labeled_water) experience
  - Water is H2O (2 hydrogens and 1 oxygen)
  - There is a heavy form of water called [deuterium](https://en.wikipedia.org/wiki/Deuterium)
  - There’s another form of water where oxygen doesn’t have 16 neutrons, instead it has 18 ([oxygen-18](https://en.wikipedia.org/wiki/Oxygen-18))
  - So water can be labeled with a different isotope of hydrogen or different isotope of oxygen, heavy hydrogen or heavy oxygen
- First you drink D2O then you drink H2 heavy O
- When you collect your urine, you’re measuring the hydrogen that’s coming out without measuring the carbon that’s coming out
  - This allows you to calculate your VCO2
  - You collect urine serially and over the course of 10 or 12 days to get an estimate
- The only instruction to Peter when doing this was try to keep his weight stable for that period of time, which he was able to do
  - This was a time in his life when he was tracking his ins and outs pretty well, mostly out of curiosity
- By his calculations he was taking in 4,400 calories (this would imply an expenditure of 4,400 calories)
- The DLW (doubly labeled water) showed an expenditure of 4,200 calories
  - He was amazed to be so close in his estimate
- Peter did this with [Eric Ravussin](https://www.pbrc.edu/research-and-faculty/faculty/Ravussin-Eric-PhD.aspx) at the Pennington Biomedical Research Institute
- He wishes this analysis was available commercially
- Eric and his staff were amazing; they allowed him to do this in a research lab

**Difficulties of tracking normal food intake**

- Layne comments that since you are supposed to be weight stable, most people could do this
  - By default at the end of the day you’re weight stable within a reasonable amount
  - Add up whatever you’re eating to determine your total daily energy
- Peter notes this is hard unless people are going to carry a food scale everywhere with them
  - Then the act of measuring everything creates a sort of [Hawthorne effect](https://en.wikipedia.org/wiki/Hawthorne_effect)
  - People won’t take an extra bite of a candy bar or that handful of nuts because they don’t want to measure it
  - Or people will want to eat normally and not measure anything and keep their weight constant
- Layne agrees, measuring changes behavior
- He and his coaches at [Team Biolayne](https://www.biolayne.com/) encourage clients to track what they’re already doing, to enlighten them
  - If they lose weight while tracking he comments that they didn’t take that extra bite of snacks
- Peter notes with his patients when they do their intake, they realize nutrition is going to be an important thing to modify
  - He wants to see what people normally do, what their baseline is but it’s impossible when they start measuring

**Thermic effect of different macronutrients**

> “*All calories are equal. Because again, calories are just a unit of measurement. All sources of calories are not equal in terms of their effects on energy expenditure and metabolizable energy.*”— Layne Norton

- He already discussed fiber and insoluble fiber
- Consider the [TEF (thermic effect of food)](https://en.wikipedia.org/wiki/Specific_dynamic_action) of various foods
- The TEF is the amount of energy your body has to put in to extract chemical energy out of food
- Fat has the lowest TEF; it’s between 0-3 calories per 100 calories of fat
  - So you net about 97-100 calories from 100 calories of fat
- People will say, “*Well celery is a negative calorie food because your body has to put more in*”
  - But Layne points out, “*Unless you’re talking about tree bark, there is no energy negative food. Even celery has like 50 calories. Or it might be five calories per hundred grams. So very, very low, but still not negative*.”
  - We would not have lived long as a species if we had energy negative foods
- Carbohydrates have a TEF of 5-10%
  - So if you eat 100 calories of carbohydrate, you net 90-95 calories
- Protein has a TEF of 20-30%
  - So if you eat 100 calories of protein, you net 70-80 calories
- When people hear this they make a much bigger deal of it than it actually is
  - Consider how much of a proportion of your overall energy expenditure this is

## Challenges of sustained weight loss: metabolic adaptation, set points, and more [34:45]

**Metabolic adaptation**

- Peter notes one challenge of sustainable weight loss over a long period of time is how much is enough on a daily basis before an adaptation takes place that would correct it

- Consider a patient who is 50 pounds overweight
  - If this patient lost 50 pounds in a year
  - If they could create an energy debt of 75 calories per day by a macronutrient shift to more protein over a long enough period of time, could this be relevant
    - Layne says it could but this neglects metabolic adaptation
- People think energy in, energy out
  - That these are static things that do not affect each other
  - In reality, they are intrinsically tied to each other
- If you went on a 500 calorie deficit per day (a pretty significant deficit), do you lose linearly 1 lb per week until you no longer exist and you die because there’s no more body weight?
  - No, we all know that weight loss plateaus
  - Part of this is because you have less body mass
    - So your body has to expend less energy to maintain upright posture, etc
  - There is also the NEAT component
    - As you lose weight, you become spontaneously less active
  - For people going from average-size to lean, their exercise will go down
    - If you look at their BMR, there is a reduction in BMR above what you would expect based on the loss of lean tissue and fat tissue
  - Your body is fighting to get back to homeostasis
- John Speakman had a really good paper on this; this gets into [set point theory](https://en.wikipedia.org/wiki/Set_point_theory_(body_weight))
  - Published in the *Annual Review of Nutrition* in 2013,  [Evolutionary perspectives on the obesity epidemic: adaptive, maladaptive, and neutral viewpoints](https://pubmed.ncbi.nlm.nih.gov/23862645/)
  - This is the idea that the body has this native set point of weight that it likes to be at
  - Now, what is regulating the ends of that set point?
    - If we get too lean and lose too much fat mass, we die
    - At the higher ends, there are things that work against obesity
    - When you overfeed NEAT goes up, so does BMR
    - Obviously society is shifting towards adiposity so the regulations for going up are not as strong as for going down
- Think about it from an evolutionary perspective, obesity is not going to kill you in the short term
  - Research suggests it will be the difference in dying at 70 versus 80
  - The risk in the short term is predation of a physical altercation where you can’t defend yourself very well, or you can’t run away
  - The risk of predation after man learned how to use tools pretty much went to zero

- The risks of starvation are very real, even now in some parts of the world

> “*It makes sense that the regulatory mechanisms were more powerful on that bottom end to prevent people from becoming too lean, than they are on the top end*”— Layne Norton

- You have to think of energy balance, like a car that changes its gas efficiency based on how full the tank is
  - So think about if you had a car that when you have the gas tank filled all the way up, it gets horrible gas mileage
  - But as that gas tank starts to go down (think about your gas tank as your body’s adipose stores, your energy stores), you become more and more and more efficient
  - So by the time there’s very little gas left, it’s just sipping gas
- The biggest thing to take away is, we cannot know
  - We can know at a snapshot in time what your energy expenditure probably is
  - But it’s likely to change
  - And it’s a sliding scale, and it depends on a lot of variables

## Weight loss strategies: tracking calories, cheat meals, snacks, fasting, exercise, and more [40:45]

**Tracking calories is like keeping a budget**

- Energy expenditure depends on a lot of variables and is likely to change
- This has led people to think that we can’t accurately track calories in or out so there’s no point in tracking calories
  - This is like throwing the baby out with the bath water
  - You don’t have to track calories to lose weight
- But this is like saying, “*Keeping a budget is worthless, because I have multiple streams of revenue and I have investments. And so I can’t exactly how much income I’m getting. And also things pop up, like your car breaks down, you have repairs to your house. So you can’t exactly know what your expenses are going to be. So therefore keeping a budget is worthless.*”
  - You don’t have to keep a budget to same money, but it’s a useful tool
  - A budget gets you in the ballpark and to a baseline; the same is true of tracking calories
  - The act of keeping a budget prompts you to think twice before making a frivolous purchase
  - The average person under reports their debt by 155%
    - There are a lot of parallels between this and tracking calories
- Layne asks if Peter was maintaining his weight on 4,400 calories a day
  - Peter notes he was training a lot more than he does now
  - He was probably exercising 3 hours a day
  - Layne note this is a very large budget
- If you have a large budget you can pay your mortgage, utilities, and all of your responsibilities and still have some leftover to buy that sports car
  - But if you make $50,000 a year and want to buy a $70,000 sports car; that’s a bad idea unless you have a ton of money stored in the bank
  - Similarly when people see the flexible dieting Layne uses they think we’re just eating junk food all the time
- People seem shocked that some can eat junk food and lose weight
- Layne responds “*Everything is on a continuum here. There’s a big difference between somebody having like a small bowl of ice cream that they fit into their budget for the day, that allows them to feel less restricted and feel like they’re not missing out. That prevents them from having a huge binge session down the road when their willpower eventually breaks*.”
  - This doesn’t work for everyone
  - But some people can have a little ice cream if they’re getting enough dietary fiber, hitting their protein, and not going over calories

**A question Peter is commonly asked**

“*Do you think it is better to be completely restrictive or to have frequent cheat meals, like one meal a week or one day a week where you go completely off the rails or just to have a little bit of stuff that is an indulgence every single day?”*

- Peter doesn’t have a great answer, even for an individual this might change
- Consider Peter’s experience, he was on a ketogenic diet for 3 years (with the exception of 1 day)
  - The only time he deviated was at his wife’s birthday, when he had 7 pieces of cake
  - This was from 2011-2014
  - He could never do this again; it would be hard for him to go on a ketogenic diet for more than 2 weeks now
  - He can definitely get away with a daily indulgence or weekly indulgence because it’s very easy for him to get back on track

> “*I basically follow a very simple rule, which is never do two bad things back to back*”— Peter Attia

- If you ever miss a workout, the single most important thing is making sure on the next day that you work out
  - Similarly, if you ever have a complete blowout meal, the single most important meal is the next one
- Realize too that many people do very well in a highly, highly restricted environment
  - And when they deviate from that restricted environment, it sets them off on a path that doesn’t make sense

**How does someone predict which path is going to work for them?**

- Part of it depends on this person’s personality and their individual psychology
- If you want to lose weight, you are going to have to use some form of restriction: calorie counting, points, carb restriction, fat restriction, unprocessed food, fasting, time restriction, etc.
  - Counting calories works because it restricts calories

**You should pick the form of restriction that feels least restrictive to you as an individual**

- This is where people get really crossed up
- People will find a form of restriction that feels un-restrictive and then they think this approach is right for everyone
- He often hears, “*I tried intermittent fasting. It felt like I wasn’t even dieting. I lost 50 pounds and it wasn’t even hard.*”
- This is why you’ll hear people make crazy claims about low carb or any diet, which are all excellent tools

> “*I just am not a fan of insane claims about those particular diets*”— Layne Norton

- People think he doesn’t like ketogenic diets or intermittent fasting but that’s not true
- Part of the problem is people try restricting calories and it doesn’t work
  - Then they go on a ketogenic diet and think they are eating more and losing weight
    - Maybe they felt like they were eating more, but unless you’re weighting everything out
    - Ketogenic diets have really limited food choices; there are not many options for snacking

**Snacks**

> “*A very vigorously present characteristic of people who lose weight and keep it off, is they don’t really snack. They have defined meals*”— Layne Norton

- Snacks do not appear to be as satiating, not just because of the food, but because of the mindset
  - When you snack, you tend to do it and not being mindful about it so it doesn’t have the same satiety effect
- Layne tells clients to stop snacking
  - If they like snacks and they can fit them into their calories, it’s fine
- When people stop snacking they realize they don’t feel hungry
  - Now they are losing weight because they cut out 300-400 calories
- Peter agrees at least empirically, that when people eliminate eating between meals they have improvement of: body weight, body composition, and biomarkers
  - People aren’t snacking on the most healthy foods to begin with

**Lessons learned from fasting**

- This is where he has found fasting to be a valuable tool
  - If you put somebody through a 3 day, 5 day (or even longer) water-only fast, they learn a very important lesson
    - I’m not going to die if I’m acutely hungry
  - Even if you do it only once, it teaches you a couple things
    - 1) That you can do it
    - 2) Hunger comes in waves
    - In that 5 day period of eating nothing, there will be periods of time when you literally want to eat your arm
    - And you will have periods during that 5 days when you have forgotten that you’re fasting
  - After going through 5 days of difficult fasting you can accept a regimen of not eating any snacks
    - Eating nothing from noon – 6, even when you feel really hungry at 3
    - You’ll realize you are going to eat in 3 hours and you can make it to 6
  - You don’t have to be a fasting guru or do a quarterly fast to experience this

> “*People confuse hunger and appetite a lot*”— Layne Norton

- People think they don’t get hungry on certain diets (ketogenic, plant-based, etc.)
  - This can be true
  - But there are a lot more reasons why people eat than hunger
    - Societal cues, stress, boredom, lots of things

**Exercise**

> “*One of the reasons exercise works so well, is one, it sensitizes you to satiety signals*”— Layne Norton

- Exercise has a powerful effect on weight loss for several reasons
  - 1) Becoming more sensitive to your satiety hormones
  - 2) Spending an hour doing something physical is an hour your not bored and eating

## Sitting in discomfort, focusing on habits, and other lessons Layne learned as a natural bodybuilder [52:15]

- Layne tells his clients, “*Listen, if you want to lose weight, you’re going to be hungry at some point, physically hungry. You will be*.”
  - As someone who has been stage-lean as a bodybuilder with absolutely minimal amounts of body fat, he knows about this hunger
  - The level of discomfort is all consuming, you cannot think about anything else other than when you’re going to eat next
  - When you finish your meal, you’re hungry 5 minutes later and already thinking about your next meal
  - The level of fatigue is so high; it’s a monumental effort

**Getting lean for competition, reducing body fat**

- When Layne was competing as a bodybuilder he calipered at 2% body fat
- [DEXA (Dual-energy X-ray absorptiometry](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry)) is the gold standard for measuring body fat
  - But unless your a cadaver and someone is excising your adipose tissue, you’ll never really know what your % fat is because all these measurements make assumptions
  - Thinking of his DEXA measurement, he probably had 5-6% fat
    - This is what a lot of stage-lean bodybuilder have
- Measuring with calipers, he can get to about 7% fat
  - Coming down from 14-15%
- If he’s 230 lbs he will be 14-15% fat; more like 15% on calipers
  - To get down to 7% is no problem; it hardly phases him because he’s done it so many times
  - To get from 7% to 2-3% is exponentially more difficult
  - This will probably take 12-16 weeks
  - It’s not just losing the weight but also maintaining the lean mass

> “*Maintaining the lean mass as a drug free athlete is extremely difficult*”— Layne Norton

- Without drugs, getting down to 2% fat and maintaining lean mass is going to take more than 12 weeks
  - Unless you’re already extremely lean
- The best natural bodybuilder he ever coached, his name was [Brian Whitacre](https://www.brianwhitacre.net/) (see the picture below)
  - He won the [WNBF Lightweight World Title](https://www.worldnaturalbb.com/judging-criteria/) 6 times
  - He is the only man to win the WNBF Overall World Title and the IFPA Overall World Title
    - These are the two biggest federations
    - He’s the only man to ever unify them
  - And this guy, at 12 weeks out, would look ready, and then he would lose 10 more lbs
    - Probably 6-7 lbs of that would be fat

![](https://peterattiamd.com/wp-content/uploads/2022/04/f3-laynenorton2-684x1024.png)

**Figure 3. Brian Whitacre, professional natural bodybuilder.** Image credit: [brianwitacre.net/gallery](https://www.brianwhitacre.net/)

**The problem is the loss of fat** ***and*** **lean mass** [54:45]

- An overweight/ obese person can lose almost 100% fat tissue
- But adipose is actually about 13% lean tissue
  - So it’s very normal to see about a 13% to 20% loss of lean tissue when dieting
  - Water and adipose also has protein in it, and part of that is lost during the remodeling of the tissue
- It’s important to make the distinction of what happens in a drug-free bodybuilder because [steroids](https://en.wikipedia.org/wiki/Anabolic_steroid) change the physiology and tilts thing toward retention of lean mass (if not building lean mass)
- As you get leaner and leaner, you are going to have a progressive shift to losing more lean body mass for a few reasons
  - 1) Your body is sending out hormones to try and conserve fat tissue
    - From this perspective, if you are 200 pounds and 190 of that is lean body mass (5% body fat), that last little bit of fat is the biggest energy reservoir
    - The body is in emergency mode and will start to tear the house down to keep this fat instead of a massive amount of lean tissue
    - This is very interesting

> “*The best way to look as muscular as possible, is to be as lean as humanly possible*”— Layne Norton

- Look at the picture of Brian Witacre (above)
  - He’s one of the greatest natural bodybuilders of all time
  - A lovely person and a very smart guy
  - He’s a [professor of economics at Oklahoma State](https://experts.okstate.edu/brian.whitacre)
  - It’s incredible, he’s so lean that he has veins in his glutes and striations that look like fingers
    - Peter remembers the first bodybuilder he ever saw this in; he was maybe 13 years old
    - He was amazed to see [Samir Bannout](https://en.wikipedia.org/wiki/Samir_Bannout), who was the 1983 [Mr. Olympia](https://en.wikipedia.org/wiki/Mr._Olympia)
    - To think that one could achieve striations in his lower back and in his glutes without steroids and diuretics is pretty amazing
  - Brian was about 160 to 165 pounds on stage; and he’s 5’9”
    - If you saw him in his shirt you would think, “*Oh, he’s nothing. He looks athletic*.”
    - If you saw him with his clothes off, you would think he weighs at least 200 lbs
  - Brian is also very strong
    - He and Layne did a 3x bodyweight deadlift challenge at Oklahoma State University

**==> Check out this [video](https://video.okstate.edu/media/3X+Bodyweight+Deadlift+Rep+ChallengeA+Dr.+Layne+Norton+vs.+Dr.+Brian+Whitacre/0_ayufrzb5): 3X Bodyweight Deadlift Rep Challenge: Dr. Layne Norton vs. Dr. Brian Whitacre**

- In Brian’s off season he weighs 180/185; this still looks very lean

> “*I think bodybuilders can really teach important lessons about physiology in terms of energy metabolism*”— Layne Norton

- Peter agrees, bodybuilding is an underappreciated discipline
  - It’s very easy to dismiss bodybuilders as drug using
  - But when it’s natural, Peter is “*blown away at how dialed in they are on their nutrition. Insane*.”

**Strategies to accept feeling uncomfortable and push toward your goal**

- One of the things Layne tells his clients and has heard so many times from different competitors is, “*You have to learn to sit with your discomfort*”
  - This can apply to many things, even in business
  - He’s sitting with his discomfort right now because he’s expanded his business and his expenses are way higher
    - He’s making good revenue but the 20-year old voice of Layne in his head says, “*It would just take one bad month, and these expenses will crush us.*”

> “*So it’s talking yourself through, and sitting with that discomfort*”— Layne Norton

- When it comes to food, ask yourself, “*Okay. Am I actually hungry? Or am I just queued up to eat right now?*”
  - If it is actual hunger, ask yourself:
    - What are your goals?
    - If you eat now, is it going to make it more difficult later?
  - There is not right or wrong answer
  - But most people can handle a lot more discomfort than they think they can
- Just because you’re uncomfortable doesn’t mean you have to do anything about it
  - You can sit with that; a lot of people haven’t done this
- That internal conversation is important
- This is why obesity is so difficult
  - People want to make it about the Xs and Os
  - It’s not about eat this protein, carbs, fats, or any of that
  - It’s that stress and trauma and hardwired habits and behaviors are so difficult to change

> “*It really is more about changing people’s habits and behaviors than it is about the Xs and Os*”— Layne Norton

- This is true in sports too, what matters for a head coach is leadership
  - Communicate and get everybody on the same page
  - This person came in and they changed the culture of this team
  - That’s not Xs and Os; that’s habits and behaviors

## Commonalities in people who maintain long-term weight-loss [1:01:15]

- Marie Spreckley published a great systematic review on sustained weight loss
  - Published in the *International Journal of Qualitative Studies on Health and Well-being* in 2021, [Perspectives into the experience of successful, substantial long-term weight-loss maintenance: a systematic review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7833027/)
  - She actually messaged Layne and told him that reading his book is what inspired her to do her PhD

- What did they have in common?
- What was difficult?
- What did they find motivating?
- The things that came up weren’t dietary
  - 1) It was their environment
  - 2) It was their habits, their behavior
  - 3) One of the big things that came up was support, either good or bad
    - Support to have someone to say, “*I believe in you.  I know you can do thisHow can I help you?*” made a big difference
    - This was better than the criticism, micromanaging type of support
  - 4) Stress was a big factor, trauma, and binge eating
- The binge eating component is underappreciated
  - A lot of people struggle with this
  - Many people will do great Monday-Friday
    - But they get to the weekend and eat pancakes in the morning and drink all day
    - Alcohol is really calorie-dense and it encourages you to make poor food choices
    - A lot of people eat 1500 calories through the week then easily eat 4000 calories on the weekends
- Much of sustainable weight loss is reprogramming habits and behaviors instead of a particular diet
  - No one diet came up up as being superior
  - What came up repeatedly was these series of habits and behaviors that helped people lose weight and sustain that weight loss

## Does a ketogenic diet result in greater energy expenditure? [1:03:15]

- Peter goes back to the energy balance question; we know a lot more now than we did 10 years ago
- Before there was still an open question about the impact of different macronutrients on energy expenditure, both deliberate and non deliberate
- Peter used to be part of an organization that funded 2 really big studies in this space
  - [1 out of Boston Children’s Hospital](https://www.bmj.com/content/363/bmj.k4583) by [David Ludwig](https://www.hsph.harvard.edu/profile/david-s-ludwig/)
  - A [2nd one](https://academic.oup.com/ajcn/article/104/2/324/4564649) was by a consortium of people that included [Rudy Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md#areas-of-expertise-conditions-treated), [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) (was the PI), [Eric Robinson](https://www.liverpool.ac.uk/population-health/staff/eric-robinson/publications/), [Steve Smith](https://www.adventhealthresearchinstitute.com/team/steven-smith), etc.
    - Layne notes, “*That’s the heavy hitters name of metabolism*”
- This second study was very rigorously done
  - It was a pilot study; it wasn’t perfect
  - It was designed to work out the kinks in preparation for an enormous study that never got funded
  - It was still a very good study, and it compared a relatively clean standard American diet to a ketogenic diet
  - It’d be hard to make the case that there was more than 50 to 150 calorie difference in energy expenditure at an isocaloric swap
    - Some would say this could be significant over a long enough period of time
    - There has been a significant debate about the validity of doubly labeled water in a ketogenic diet
    - John Speakman and Kevin Hall wrote a review about this suggesting that doubly labeled water really doesn’t apply, that there’s an artifact in a ketogenic diet
    - So it’s unclear if this calorie difference really matters
    - Published in the *International Journal of Obesity* in 2019 [Do low-carbohydrate diets increase energy expenditure?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8076039/)
    - Regardless, this difference wasn’t 250-500 kcal per day and this was a very important insight
      - The [overfeeding study](https://dm5migu4zj3pb.cloudfront.net/manuscripts/106000/106570/JCI71106570.pdf) by Ethan Sims in Vermont in the 1960s and [work](https://en.wikipedia.org/wiki/Minnesota_Starvation_Experiment) of [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) didn’t have metabolic chambers
  - Peter’s view of the evidence is that a ketogenic diet results in weight loss through reduction of calories eaten not an increase in energy expenditure
    - Layne agrees

**Difficulties measuring energy expenditure in people eating a ketogenic diet**

- Layne notes it’s important that direct calorimetry measurements are accurate
  - He’s going to ignore energy expenditure for  ow
  - Peter adds that the 57 kcal per day was probably right at the limit of detection so it could’ve been 0-100 kcal
- The carbohydrate insulin model of obesity would predict a much bigger change in energy expenditure
  - So therefore, at least that version of it has to be falsified based on that
  - And even with the 150 calories, that would not explain the difference.
- If we look at studies that assess loss of body fat under controlled environments, we just don’t see differences between low carb and low fat when calories and protein are controlled
  - There’s actually very small favoritism towards low fat
  - But that’s probably a data artifact and not a real difference
- [David Ludwig](https://www.childrenshospital.org/research/researchers/l/david-ludwig) published a recent meta-analysis that made the assertion that there doesn’t appear to be much difference in the short-term data in low carb diets
  - But longer-term (after 17 days), there appears to be a large difference in energy expenditure on the order of 150-300 calories per day
  - Published in the *Journal of  Nutrition* in 2021, [Do Lower-Carbohydrate Diets Increase Total Energy Expenditure? An Updated and Reanalyzed Meta-Analysis of 29 Controlled-Feeding Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7948201/)
  - This meta-analysis was very well done; the statistics are very good
  - But when there was metabolic chamber data available or doubly  labeled water, they used doubly labeled water
  - To Layne this is like saying “*I’ve got caliper data available, and DEXA data available, but I’m going to use the caliper data*”
    - Keep in mind that DEXA is what calipers are validated against, so you’re talking about a primary measure versus a secondary measure
- Peter remembers that he got Kevin Hall and John Speakman’s primary criticism of DLW (doubly labeled water) in a KD (ketogenic diet)
  - The gist of their thesis on where the artifact comes from is there’s more CO2 produced than is accounted for in the constant of the equation
    - The 1.11 is probably too low a number [Weir formula = (3.94)(VO2) + (1.11)(VCO2)]
- Layne reasons that overproduce CO2 compared to what the prediction would be based on that equation
  - Basically what that means is that in a low carb setting, you’re probably getting an artificial increase in energy expenditure
  - So Peter realizes that 1.11 would actually be too large a coefficient
- Layne considers if this isn’t an artifact of differences in measures, and with direct calorimetry on a standard diet, the association with doubly labeled water is an R of 0.8
  - This is good for free living
  - Peter agrees that 0.8 is good but not exceptional
- But then low carb is 0.8 which is a big difference from 0.8
  - It basically just means it’s not as tightly correlated

**Refocus on losing body fat**

- Layne went through every single study that Ludwig looked at
  - He looked to see if they measured body composition and what this data said
  - Because what do we care about?
    - Do we care about what energy expenditure says on a read out?
    - Or do we care about losing body fat?

> “*Not one study saw a difference between the low carb conditions, or the low fat, or balanced diet when calories and protein were equated”—* Layne Norton

- This is great news for Layne because it says, do whatever diet you prefer and still lose body fat
  - Low carb, low fat, a balanced diet, etc.
- A balanced diet can be harder for some people to moderate unless you’re doing some kind of portion control

**Layne’s perspective on interpreting studies**

- This simply shows the effect of changing the inputs for a study
- People ask him, “*How can I get better at reading this stuff?*”
  - Go to grad school
  - Layne can’t tell you how many times in about studies with his PI (Don Lehman) that his hypothesis were crushed
    - Don would ask “*What if you consider this?*”’
    - This was very enlightening for Layne
  - The best part of grad school was sitting around a table with graduate students and Don, and just rapping back and forth with studies
    - This gave him a good idea for how to look critically at this stuff

> “*I don’t get excited about 1 study. Wake me up when there’s 10*.”— Layne Norton

- Even with 10 studies, he’s going to look at how it was done with a critical eye
- He hears people say, “*I don’t trust science because this study says this thing, and this study says that thing*”
  - He points people to the methods and results
  - You need to understand what you’re looking at, understand statistics, understand research design

“*Don’t read the conclusions of the authors. Look at the actual results. Look at the methods. And you can usually understand why they seemingly found different results.*”*—* Layne Norton

- Peter agrees, he has a [series on the blog called studying studies](https://peterattiamd.com/tag/studying-studies/) where he goes through all this methodology
  - It’s not a substitute for getting reps on the field
  - It’s like reading everything about playing a sport, but you actually have to play
  - He’s toyed with the idea of putting together a journal club
    - This is what Layne is describing and how you learn to read studies
    - Doing this every week allows you to get good at reading the fine print
- The media has a need to put out the most punchy headline
  - A great example was an article on something to the effect of smelling your partner’s farts might help prevent cancer
    - The research actually showed that 1 volatile fatty acid produced by the gut microbiome in response to fibe may have a protective effect on breast cancer when given to animals in a high dose
    - That’s a long way from you taking a sniff of your partner’s fart and preventing cancer
    - But this is what confuses people

## The metabolic benefits of exercise, muscle mass, and protein intake [1:15:00]

- No one ever says, I wish I had less muscle

> “*If you want to be metabolically healthy, the best thing you can do is have lots of lean body mass*”— Layne Norton

- Muscle/ lean body mass is a metabolic sink
- Obese powerlifters may have some elevations in blood lipids and whatnot, but usually their insulin sensitivity and blood glucose are okay

**Benefits of exercise**

- Exercise is one of the only things that we know of that without even weight loss improves metabolic health substantially, really substantially
- Layne was on the Rogan podcast a few years ago and made the point that people get caught up in carbs and fat but they’re not even exercising
  - This is like stepping over dollars to pick up fractions of pennies
  - [#1176- Dom D’Agostino & Layne Norton (September 2018)](https://open.spotify.com/episode/1G5UGm5BqnbAFoefA20zx1)
  - A high dose of exercise is not required
  - Just going and being sedentary to walking 100 minutes a week, and you will see improvements in health markers
- Layne had his blood work done a while back; he has familial hypercholesterolemia so his LDL tends to run a little high
- People were speculating that he would have really high inflammation because he eats 70-80 grams of sugar a day
  - But he’s also getting 60-70 grams of fiber along with that
  - His [CRP (C-reactive protein)](https://en.wikipedia.org/wiki/C-reactive_protein) was hardly detectable
  - This speaks to the fact that there is a big difference between somebody who is an athlete, training hard, who has a lot of muscle mass, versus somebody who’s sedentary with excess adiposity
    - It’s just not even comparable when you talk about food choices and whatnot

> “*You have a lot more you can get away with, with a lot of muscle mass*”— Layne Norton

- Older and frail people don’t think about this [muscle mass]
  - People say, “*You do all that heavy lifting, you’re going to be in pain when you’re older*”
  - But you’re going to be in pain when you’re older regardless
    - Do you want to be in pain and strong or in pain and weak?
    - Peter agrees, when he asks people who have experienced activity and inactivity they will recall being in more discomfort when inactive

> “*Sitting is to lower back pain what bourbon is to alcoholism*”— Peter Attia

- The worst thing you can do is be immobile

## The impact of lean muscle and strength on lifespan and healthspan [1:20:00]

**Hypothetical case study #1— a 50-year old, mother of 3 whose never lifted weights**

- A 50-year old, mother of 3, going through menopause, putting on a little bit of weight
- She’s never lifted weights but thinks she needs to do more cardio, be more active
- Her DEXA shows she is 30% body fat, but it’s a skinny fat
- Her ALMI (appendicular lean mass index) is 6; this puts her at the 10th percentile of muscle mass
- What would Layne prescribe?
- Layne notes, “*Muscle is a lot like bone in that you want to lay down as much as possible because eventually, it’s going to start receding. But it is still possible to add muscle*.”

**It’s never too late to add muscle**

- The lab across the street from  Layne at the University of Illinois did a study on 80-year old frail individuals
  - They started with a squat to a high chair and come up
    - Squat down into a parallel chair
    - Gradually, they put the chair down and squat with weight
  - This was a 16-week study
  - In talking to graduate students working on this study, they were amazed because by the end of it,these people increased their lean body mass (as a percentage of their body weight) pretty much the same amount that a 20 year old does
    - The relative increase was similar
  - Their weight was lower to start with so they had less overall mass
  - But by the end, some of them were able to add weight
  - It’s never too late to get active
- Going back to the finance metaphor, it’s never too late to start saving
  - If you can be one of those fortunate people who starts saving right away, there is zero downsides to this
- In his practice Peter see’s 50-year old women going through menopause and the composition of their bodies is really changing to more fat and less muscle mass
  - He looks at what they are eating, 50-60 g protein a day on a good day
  - Assessing their strength show they are incredibly weak

**The importance of muscle in older people**

- He talks to these patients about the cause of death by decade
  - The level of accidental deaths, is very interesting because it is the same across age groups
    - Unlike cardiovascular disease, cancer, and Alzheimer’s disease which are all very age dependent
    - What differs dramatically is the type of accident
      - Young people die in automobile accidents
      - The oldest people die in **accidental falls**
  - Peter notes, “*I’ve never seen a person who doesn’t just stop in their tracks because they cannot believe how much morbidity and mortality results from falling and frailty once you reach about the age of 70, 75*.”
- Layne agrees, there was a review by [Bob Wolfe](https://uams-triprofiles.uams.edu/profiles/display/126430) that essentially showed that after age 65, you could tie the majority of deaths to some kind of lack of muscular strength or lack of muscle
  - Published in the *Journal of Nutrition, Health, & Aging* in 2008, [The danger of weight loss in the elderly](https://pubmed.ncbi.nlm.nih.gov/18615231/)
- Meta analyses of mortality show that lean body mass is inversely proportional to your risk of mortality after age 50
- Peter adds that the [hazard ratio](https://www.statisticshowto.com/hazard-ratio/#:~:text=The%20hazard%20ratio%20is%20a,than%20those%20not%20receiving%20treatment.) for being strong to not strong is about 3.2 for all cause mortality
  - That’s a staggering hazard ratio
  - It’s higher than smoking; smoking is about 2
  - End stage renal disease is about 3
  - The only thing higher that Peter has discussed is VO2 max, comparing the top 2.5% to the bottom 25%
    - This hazard ratio is 5.1

> “*These are not mutually exclusive. So why not have remarkable cardiorespiratory fitness, muscle mass, and strength?*”— Peter Attia

- Layne notes one of the barriers is that people don’t want to get to bulky or too muscular
  - As someone who’s spent their entire adult life trying to get too muscular, and basically just looks really fit in a T-shirt, he doesn’t worry about this
  - If you do start to get too muscular, you can always just back off
- Peter brings this back to the financial comparison; he’s worried about getting too rich
- Layne notes the benefit gained from spending 30-40 minutes resistance training, 3x a week is unbelievable in terms of your level of fitness and ability to live a long, healthy life
  - It doesn’t have to be crazy intense training, just an amount that forces your body to adapt

> “The amount of benefit you will get from three times a week, 30 to 40 minutes of resistance training. . .will be unbelievable in terms of your level of fitness and your ability to live a long, healthy life.” —Layne Norton

## Hypothetical case study #1: Training program for 50-year-old female [1:27:45]

- A 50 year old female, mother of 3
  - She’s not completely unfit
  - She does yoga and walks but has never lifted weights
  - She’s going through menopause and putting on a little weight

**What should she do for her 1st 4-month program?**

- First consider what is reasonable for her lifestyle, what can she do?
- Let’s say she will commit to 40 minutes, 3x a week in the weight room
- Lower body strength is a little bit more important than upper body strength in terms of preventing falls
  - He always think about falls from a bone density perspective
  - He doesn’t want people to fall and break their hip because that specific fall is pretty much a death sentence if you’re over the age of 65
  - Bone density is increased by lifting weights much more than anything you’d ever get through your diet
- Spend 2 days doing lower body and 1 day doing upper body
  - You could even flip flop this on alternating weeks if you wanted
- Focus on machine stuff that’s easy to do
  - Since she has never trained before, everything’s going to cause an adaptation, and that’s the goal
  - He’s not going to have her come in and try and free squat, or deadlift; that’s a really horrible idea
  - Start with a leg extension, a leg curl, a leg press
- Peter asks, “*Would you have her do anything that’s a little more compounded and complicated, for example, holding dumbbells and stepping up onto a bench where now she has to manage grip strength with a bit of balance, and also getting the leg load?”*
  - Not in the initial weeks, just because the soreness is going to be so high it’s going to impede a lot of that movement

**Soreness**

- People tend to think about soreness in the wrong way; it’s correlated with muscle growth and strength
  - But it’s not causative
  - If you’re sore all the time, you’re probably training incorrectly
  - If you’re never sore, you’re also probably training incorrectly
  - If you’re doing an appropriate amount of volume and intensity, there probably should be some soreness from time to time, but if you’re getting sore all the time, then your programming is pretty bad
- What he’s trying to do in the initial stages is work just enough to adapt and not cause enormous amounts of soreness
  - Soreness can be discouraging and impede subsequent sessions

**Expectations for the first 4-6 weeks**

- Layne wants to get her through 4-6 weeks
- The data on muscle protein turnover doesn’t show increases in hypertrophy during the 1st 6 weeks of resistance training
  - Discussed in his first appearance on the podcast, [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training](https://peterattiamd.com/laynenorton/)
  - During this time the tissue is remodeled to become stronger, more resilient, and it starts protecting itself against damage
  - This is where muscle protein synthesis goes up, but muscle protein degradation also goes up
    - It’s a cycle where the muscle tissue is simply turned over
- After about 6 weeks, muscle protein degradation tends to go down while muscle protein synthesis stays up
  - This is where you start seeing those increases in hypertrophy and lean mass

## Muscle protein synthesis in a trained athlete vs. untrained individual following a resistance training program [1:31:30]

- Peter asks how this female’s progress compares to a trained athlete
- There’s a paper from [Damas](https://www.researchgate.net/profile/Felipe-Damas-2) that looks at myofibrillar protein synthesis in response to resistance exercise
  - Published in *Sports Medicine* in 2015, [A review of resistance training-induced changes in skeletal muscle protein synthesis and their contribution to hypertrophy](https://pubmed.ncbi.nlm.nih.gov/25739559/)
  - They see that **the amplitude of muscle protein synthesis in trained people is a little bit lower than untrained** so you don’t have quite the same response
  - It depends on when you measure
  - If you measure at 16 hours post, they’re about the same; there’s about a 40% increase
  - If you measure at 4 hours post, the increase in the trained athlete is still about 40%, but for the untrained, it is about 70%
    - There’s a little bit of difference in amplitude
  - But what really is the difference is the duration
    - In trained people, it’s back down to baseline about 10 to 20 hours after the initial bout of resistance training
    - In untrained people, they still have elevated rates of protein synthesis 2-3 days later
- Peter asks if this protein synthesis could be offset by degradation
  - It could; unfortunately degradation is much more difficult to measure
  - Unfortunately you can’t really measure all 3 things at 1 time
  - You can measure the net balance with an [AV balance (arterio-venous balance)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4073993/)
    - Infuse a labeled amino acid then sample the arterial of a muscle bed and then the venous of the muscle bed
    - Depending on how much of that label shows up in the vein versus the artery, we know how much is being retained in muscle and we know what the net is
  - You can infuse a second label to presumably get synthesis as well and then you can figure out the difference of degradation
    - But the problem with this is it requires a steady state
    - You can’t do it when you’ve trained or had a meal or anything like that so it has to be done while fasting
  - The problem with degradation is how you’re measuring it
    - For example, out of every amino acid that’s used for protein synthesis, 7-8 of them are recycled from protein degradation
    - Peter recalls learning about this in his earlier podcast with Layne and often wonders after finishing a workout how many amino acids in protein shake versus amino acids eviscerated from deadlifting are going to be the ones used for net myofibrillar synthesis
      - Layne doesn’t think about it this way

> “*If you want to maximize muscle mass, you want to maximize protein synthesis (obviously) and maximize deposition*”—Layne Norton

- The first theory was that you can only really deposit about 5-10 g of amino acids per day in muscle
  - If it’s 10 grams a day then this is 8.5 lbs a year
  - But muscle tissue is about 70% water so to get to the actual protein content divide 8 lbs by 0.3; so it’s 26 lbs
    - That’s a lot of lean body mass even for a novice trainer
    - We know the max is about 5-10 g in a drug-free person
    - He’s not sure how much this would increase with [anabolic steroid](https://en.wikipedia.org/wiki/Anabolic_steroid) use
    - It’s hard to get IRB approval to do research with steroids
    - Magazines exaggerate a lot of stuff, even 30 lbs of skeletal muscle wet tissue would be a ton for someone on drugs (look in the grocery store at 30 lb of beef)

**A recent patient of Peter’s who began an exercise program**

- Peter just had a female patient who went from being not very active to getting very active
- She had a [DEXA scan](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry) separated by 5 months (simply through circumstances of having the scan at different facilities)
  - This suggested she gained 6 lbs of lean tissue
  - One of these scans must have been wrong
  - She probably did gain some lean tissue
  - Layne says if you do a DEXA scan then drink a gallon of water and scan again, you’ll have gained 8 lbs of lean tissue
  - This result could simply be due to a hydration artifact but she probably gained some lean muscle

## Protein and amino acids needed to build and maintain muscle mass [1:37:15]

**RDA (recommended daily allowance) for protein**

- You need just 50 g of protein to meet the requirements in terms of having a positive nitrogen balance
- You can’t just add 10 g of protein and assume that every amino acid goes straight to lean tissue
  - Protein is also oxidized
- In order to maximize your deposition to get that 5-10 grams, you need to maximize protein synthesis
- But to maximize protein synthesis requires a disproportionate amount of total protein
  - Layne thinks it’s around 1.6 to 2.4 grams per kilogram of body weight
  - This kind of winds up with that old 1 gram per pound of body weight number
  - You need a disproportionate amount of protein to maximize the deposition
- One of the ways that protein needs are assessed is what’s called the indicator amino acid method; this is the gold standard
- You could also look at direct amino acid oxidation
  - If you eat increasing levels of protein and look at the oxidation levels of a specific amino acid, it’ll be flat and then you’ll hit an inflection point where it’ll go up linearly
  - That inflection point is where amino acid oxidation increases, and eating protein beyond this point doesn’t increase muscle synthesis
  - This is an association not causation
    - From an evolutionary perspective it would make sense that at the point where you use protein for energy (oxidize it) you could also start building extra tissue
    - This is the point where there is a surplus of protein
    - This is around 1 g protein intake per kg of body weight (even at this low level)
- Layne notes that you’ve got to eat a lot more protein to get out what you want; it’s an inefficient system
  - Some amino acids can be directly oxidized after they are deaminated [the first step of [protein catabolism](https://en.wikipedia.org/wiki/Protein_catabolism) removes the amino group]
  - Some amino acids can enter the Krebs cycle
    - The figure below shows amino acids that are *only* glucogenic (can be used in gluconeogenesis) in red
    - Those that are *only* ketogenic (can be converted to Acetyl-CoA) in green
    - Most amino acids can be directed into *either* glucogenic or ketogenic pathways; these are shown in purple

![](https://peterattiamd.com/wp-content/uploads/2022/04/f4-laynenorton2-1024x719.png)

**Figure 4. How amino acids are broken down and enter metabolism.** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Protein_catabolism)

- Some amino acids can be oxidized pretty quickly, by entering into the Krebs cycle directly
  - Such as alpha-ketoglutarate
- 60% of amino acids are glucogenic, fewer are ketogenic
  - [Glucogenic amino acids](https://en.wikipedia.org/wiki/Glucogenic_amino_acid) feed into gluconeogenesis, where the liver uses them to make glucose to supply the body
  - [Ketogenic amino acids](https://en.wikipedia.org/wiki/Ketogenic_amino_acid) can be converted to acetyl-CoA or enter the Krebs cycle at different intermediates and oxidized to produce energy
- Branch chain amino acids are the ones that can be oxidized in muscle
  - Leucine, valine, and isoleucine
    - These can all feed into the Krebs cycle for oxidation

## Nutrition plan for the hypothetical 50-year-old woman starting a program to build lean muscle [1:42:45]

- For the 1st 6 weeks, the goal is don’t get hurt or too sore
  - Build the habit, find some enjoyment, get the tissue resilience
  - Don’t expect to add lean mass
- Let’s say at her intake analysis she weighs 135 lbs (60ish kilos)
  - She’s eating 50 g of protein a day
  - She’s eating 2300 calories per day, of which 200 calories is protein
- How should she change her macros, with protein being the most important?
- Layne uses his [app Carbon Diet Coach](https://joincarbon.com/) when he trains people
  - This is a nutrition coaching app
  - Put in your metrics and it will give you macros to follow
  - It has a food tracker
  - Every week you check in with the coach (an algorithm) and it will adjust your macros based on your progress
  - This is for people who have a little more independence or feel they can’t afford a 101 coach
- To increase protein, pump up your portion size of lean cuts of meat
  - For most people, their protein comes from fatty cuts of meat
  - You’re not aiming to increase calories but shift the macros more to protein
  - People can lose fat and gain muscle at the same time
- Let’s assume she has a BMI of 25, but we would love to see her at 22% body fat in 2 years instead of 35% body fat
  - Let’s aim for her to gain 10 lbs of muscle
- Layne focuses on the portions of meat she is eating and what he can get her to eat
  - He would want her to eat 110-120 grams of protein a day, just under a gram per lb of her body weight

**Breakfast**

- Breakfast is where most Americans eat a very low protein meal
- Peter adds that she has been doing [time-restricted eating](https://en.wikipedia.org/wiki/Intermittent_fasting), eating only 2 meals a day (lunch and dinner)
- First Layne would ask her why she is doing this
  - Because she wants to maintain her weight
- Layne notes that you can still get the majority of benefits of time-restricted eating by having a lean protein or shake for breakfast
  - Breakfast is an opportunity to get another 25-30 g of protein to stimulate protein synthesis
- High protein diets actually mimic some of the things that go up during fasting
  - Adding a protein shake in the morning is not going to mess up benefits of time-restricted eating
- What about [mTOR](https://en.wikipedia.org/wiki/MTOR) and low [IGF](https://en.wikipedia.org/wiki/Insulin-like_growth_factor), the pillars of longevity?
  - Isn’t eating extra protein at odds with that?
  - mTOR is responsive to amino acids
    - Though you could argue you’re not getting much mTOR suppression with an overnight fast and skipping breakfast
  - We’ll come back to this question
- Layne wants to make small changes to meals so she doesn’t feel this disrupts her current lifestyle
- Research shows that the less you change, the better people will adhere to the new diet

**Lunch and dinner**

- At lunch, increase the lean protein in a sandwich or on a salad or whatever she eats
- At dinner is where most people get about 65% of their protein
- Let’s assume she eats 20-30 g of protein at breakfast, 20-30 g at lunch, and the rest (60-70 g) at dinner
- If she’s been having the fattier cuts of meat (rib eye or T-bone) and if calories are a consideration, switch to sirloin or filet or chicken breast
  - You can get pork chops that are really lean and tasty
  - Venison is also lean, a venison rib eye has only 4 g fat per serving
  - By simply changing the cuts of meat, you can pump up the protein, reduce the fat, and the calories will stay about the same
- Layne likes to use shakes
  - Especially as people get older, they tend to have less appetite for protein; they just don’t like to chew as much

> “*Instead of milk on your cereal, just put a protein shake… and boom, you’ve got 30 grams of protein instead of 8*”— Layne Norton

- Protein shakes have come a long way, they are a lot tastier now

**Should she track fat and carbohydrates?**

- Peter notes that this diet change has doubled her protein intake, which is almost an isocaloric switch
  - Should we pay attention to what % carb versus fat this woman is eating when hypertrophy is the primary goal over the next 2 years?
- The research on hypertrophy leads Layne to think as far as carbs and fats go, it mostly doesn’t matter as long as you’re not at the extreme of either
  - If you are very, very low fat, it can impair testosterone levels
  - This has not been shown to impair accrual of lean mass, but it hasn’t been well studied either
  - Fat is a difficult question when considered as a % of calories
    - If you’re eating 5,000 calories and 10% fat, this is probably enough fat
    - As you eat more calories you can spare fat from oxidation by utilizing more carbohydrates
    - 20% calories from fat is probably safe
    - At a minimum you want to eat 40 g of fat a day
  - He doesn’t want to be dogmatic about these numbers

**Discussion of a ketogenic diet**

- A ketogenic diet does appear to impair lean body mass accrual
  - But probably through a few different mechanisms
- Even though carbohydrates aren’t stimulatory for muscle protein synthesis, they do inhibit muscle protein degradation and fat doesn’t appear to have the same effect
  - It’s probably an insulin effect
  - Insulin does inhibit muscle protein degradation
- It’s almost impossible to be on a ketogenic diet and eat the amount of protein Layne’s talking about
  - It would be very difficult for to get high levels of beta hydroxybutyrate with the amount of protein that you would need to be in a positive nitrogen balance
- Also notice that resistance training is anaerobic for the most part
  - So her glycolytic capacity goes down
- Research about ultra endurance or even endurance (in terms of under 65-70% of a [VO2 max](https://en.wikipedia.org/wiki/VO2_max)) shows that a ketogenic diet is fine
  - But once you start getting over 65% VO2 max, there does seem to be a significant impairment in performance
  - A couple of 12-week studies looked at lean body mass accrual and showed an impairment with the ketogenic diet
    - Layne’s guess is it’s (1) through not inhibiting muscle protein degradation as much
    - (2) just through not performing as well and they did show lower strength accrual in the ketogenic diet group
  - Relevant studies:
    - [Efficacy of ketogenic diet on body composition during resistance training in trained men: a randomized controlled trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6038311/)
    - [Effects of a ketogenic diet on body composition and strength in trained women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7146906/)
    - [Effects of resistance training combined with a ketogenic diet on body composition: a systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/33624538/)
- Peter notes nothing extreme about her carb to fat ratio
- For some people, carbs really increase their appetite, it creates brain fog, all sorts of things
  - For people in that camp, can they still go low carb?
- For someone who tolerates carbohydrates very well, could they eat more carbs?
- Does the carbohydrate content of the diet become secondary after the primary bucket of protein is filled?
  - Absolutely; protein and calories are the 2 most important things
  - How carbs and fat are distributed should be based on what you can adhere to and enjoy
- Layne could argue that brain fog or appetite might depend on the type of carbohydrate or might be placebo
- There’s nothing wrong with low carb as long as it’s not extreme; it’s a balancing act

> “*This is where nutrition communication really requires nuance*”— Layne Norton

- Someone may hear, “*Layne’s saying you can’t gain muscle on the ketogenic diet*”
  - But what he’s saying is you can’t gain as much, you can absolutely still gain muscle on a low carb/ketogenic diet
  - The same is true with intermittent fasting
    - Are you going to build as much lean muscle?  Probably not

**What to track in your diet**

- If your primary goal is gaining muscle mass, focus on protein, calories, and making sure you have enough carbohydrates
- If your primary goal is to maintain body composition, you will put on a little less muscle mass on a low carb diet
- This will really boil down to the individual and what you like best
- When people get overwhelmed with protein, carbs, and fats he recommends just tracking protein and calories
  - Protein and calories are the big buckets
  - If you want to get more granular (with carbs and fats) you can
- Layne gets more granular because he doesn’t want his performance to fluctuate
  - He wants to be consistent in the amount of carbs and fats he eats [in addition to protein and calories]
  - He doesn’t want his body weight to fluctuate a ton
- Most people are getting *99% of the benefits by tracking just calories and protein*

## Dispelling myths that excess protein intake increases cancer risk through elevations in mTOR and IGF [1:55:30]

- Layne knows that many people have heard that [mTOR](https://en.wikipedia.org/wiki/MTOR) and [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) are bad
- [David Sinclair](https://sinclair.hms.harvard.edu/people/david-sinclair) said, “*I really try to limit mTOR and IGF-1*”

> “*It will never cease to amaze me how many scientists do not understand the difference between a short-term, truncated acute response to a stressor versus dysregulated signaling that persists indefinitely*”— Layne Norton

- mTOR elevations that lead to cancer and whatnot, those originate mostly via insulin resistance
  - Elevations in insulin result in [insulin signaling](https://en.wikipedia.org/wiki/Insulin_signal_transduction_pathway) through [AKT](https://en.wikipedia.org/wiki/Protein_kinase_B) (shown in pink in the figure below), which can then transmit to mTOR (shown in purple at the bottom of the figure)
  - This is pushing that button on a chronic, low level (as opposed to a pulsatile stimulus)

![](https://peterattiamd.com/wp-content/uploads/2022/04/f5-laynenorton2.jpg)

**Figure 5. Insulin signaling stimulates mTOR.** Image credit: [*Endotext*](https://www.ncbi.nlm.nih.gov/books/NBK378978/)

- There’s a big difference between a dose of protein that causes mTOR to rise and go back down in a natural rhythm [and a chronic stimulus]
- This is also tissue-specific; we’re talking about in skeletal muscle, not liver, not brain necessarily, those sorts of things
- The same is true for IGF-1
- Layne asks, “*Where are all the resistance-trained people that are getting cancer by the droves?*”
  - The amplitude of response from mTOR due to resistance training dwarfs what protein does
- If we look at the meta-analyses on cancer incidence amongst resistance trainers, we see lower levels of cancer in people who resistance train
  - This tells Layne there’s a difference between these 2 signals
- Peter points out that people would say the difference is a healthy user bias
  - But instead, lifting doesn’t increase mTOR to the point of it being detrimental to your health
  - Or this increase in mTOR is tissue-specific; this is an important part of it

**Viewed in a certain light, exercise seems unhealthy but we know it is not**

- Consider exercise in general and suppose you knew nothing about exercise
- If I told you I’m going to do something that’s going to make you elevate your heart rate, elevate your inflammatory markers, elevate your reactive oxygen species, raise your blood pressure, increase hepatic glucose output…. What would you say?
  - You’d think this couldn’t be good for you; don’t do it
- But exercise is good for us
- Exercise is a **short-term stressor**, it’s a controlled dose of a stressor that your body can handle
- There’s a difference between an acute response and a chronic response
- If you look at people with elevated inflammation, their inflammatory markers are not super high but are elevated all the time
  - It’s the chronic pulse that’s the problem
- For the argument that there is a healthy user bias for people who have high rates of IGF-1 and mTOR
  - There is no evidence that they have a higher incidence of cancer
  - There are some confounding variables because people who have high levels of mTOR activation and IGF-1 typically have insulin resistance
    - They typically have poor dietary habits and lifestyles
    - These things are tied together
- Layne is not saying that mTOR plays no role, but it can’t be the cart before the horse sort of thing
  - People will say [Rapamycin](https://en.wikipedia.org/wiki/Sirolimus) is an mTOR inhibitor and that’s a cancer treatment drug
  - But is it a good idea to use chemotherapy to prevent cancer?
- Peter adds that Rapamycin has never been a particularly successful cancer therapeutic used constituently
  - It does show benefits for longevity in basically all animal models
  - So the extrapolation would be pulsatile rapamycin is probably beneficial
    - But in that application, it’s not really being taken to constantly suppress mTOR
    - If you took it all the time, you’re suppressing [mTOR complex 2](https://en.wikipedia.org/wiki/MTORC2) and [mTOR complex 1](https://en.wikipedia.org/wiki/MTORC1)
- Peter agrees with the point that tissue specificity and time course are very difficult things to infer from the outside, which is sort of the meta view of all things equal
  - IGF levels have a J curve with mortality and therefore very, very high levels of IGF must be problematic
  - And high protein increases IGF and therefore must be bad

**Diet**

- Layne points out, “*we have this idea that like, there’s this perfect diet out there. That’s going to be the one diet that’s going to reduce cancer and cardiovascular disease and mortality and all that. And the fact is that there’s probably trade offs for everything*.”
- There are people that will say that protein increases cancer
  - There’s a ton of cofounders to that
  - Meta-analysis looking at cancer and protein content of the diet look at above 70 g protein per day (1.2 g / kg body weight)
  - Most Americans eat high protein according to the [RDA definition](https://health.gov/our-work/nutrition-physical-activity/dietary-guidelines/previous-dietary-guidelines/2015/advisory-report/appendix-e-3/appendix-e-31a4) but where is this from?
    - Burgers, hot dogs, and processed meat
  - What is the incidence of cancer in people who just have a high protein, but overall healthy diet?
    - Here’s the thing, most people who eat high levels of meat eat low levels of fruits and vegetables
  - Layne notes, “*What they found was that at the highest levels of meat intake, but also with the highest levels of fruit and vegetable intake, there was no difference in cancer incidents between the lowest level of meat intake and even with the highest level of fruit and vegetable intake*”
    - So high protein is not an issue in a healthy diet
    - He doesn’t want to extrapolate too much on 1 study (even though it was a large one), but it suggests that the quality of the overall diet is what is important

> “*You can achieve good diet quality on a whole host of different diets*”— Layne Norton

- You can have a ketogenic diet that is very poor quality or high quality
  - The same is true for plant-based, intermittent fasting, etc.
- A lot of it boils down to: What are the food choices you’re making on balance?
  - Are you getting enough fruits and vegetables and minerals and micronutrients?
- Every time we try to say, fruits and vegetables have these benefits on health that we see pretty consistently, so let’s try and take out these isolated micronutrients and give them in the supplements
  - We’re always disappointed with the results
  - We have to eat the whole food to get those benefits
- If the mTor story were true in terms of dietary protein, we would’ve expected in that study to see a linear increase in cancer, especially at each level of fruit and vegetable intake
  - But we didn’t
  - What we saw was more of a linear inverse association with fruit and vegetable intake

## Hypothetical case study #2: Training program for a 50-year-old, trained male wanting to increase muscle mass [2:04:00]

- Hypothetical case study #2— a 40-50 year old male who wants to maximize his muscle mass
- This male has a background in training and realizes that he is going to start losing muscle at a pretty good clip once he’s in his 50’s (and certainly by age 65) so he wants to build up as much reservoir as he can
- This person has always been an athlete but never really thought about muscle mass
- They have been consistently training
  - But they’re not in a [progressive overload](https://en.wikipedia.org/wiki/Progressive_overload) mindset
  - They’ve become comfortable in their training and haven’t really increased the weight in anything they’re doing in 5 years
- They are lifting weights 3x a week for 1 hour each session
  - They squat, they deadlift, they do a whole body split every day for those 3 days
- Let’s say their DEXA scan is 20% fat
  - So they’re probably 25th percentile actually for a 50 year old
- Their BMI is 27; technically, they’re a little bit overweight and have a little extra body fat
- They want to know if they can be10% body fat in 2 years

**Layne’s prescription for strength-training**

- For his resistance training, he is doing 3 sets of 10 on everything
  - Slap a plate on, slap 2 plates on and continue with the same thing
- When you want muscle to grow, you’re trying to induce adaptation
  - Adaptation is never comfortable

> “*Muscular hypertrophy is an adaptation to a stressor placed on the body*”— Layne Norton

- The stressor is volume and mechanical load
  - So either increase the weight, the repetitions, or the number of sets
  - This is going to be uncomfortable
    - You need to mentally gear-up for this discomfort
- It sounds like he’s been doing big compound movements, Layne would continue this
  - He would like to get video feedback to see what his form is like
- At this age it’s also about knowing when do we build in some tapers so that he can actualize those gains and recover as well
- The thing about adaptation, at a certain point, if you’ve been training for long enough and you’re old enough, the amount that you need to cause adaptation versus what is going to cause you to overreach is going to become closer and closer and closer
- When you first get into training, you need almost nothing to adapt
  - You come in and do one set of leg extensions you will get an adaptation from that if you do it consistently for several weeks
- After you have been training 5 years, 1 set of leg extensions is going to do absolutely nothing
  - This might maintain what you have, but that’s it
- If you want to push adaptation, you have to push harder, which is going to create more of a recovery deficit
- Recovery capacity is going to increase as you get older and have a greater training experience
  - It’s not going to increase as much as the amount of stress that you’re going to have to apply to adap
- Having built in tapers is really important and whether you do them responsibly in terms of monitoring this person’s progress or  whether you build them in systematically to try and get ahead of that curve, either way can work

**Typical duration of a build cycle, taper cycle [2:09:00]**

- The taper cycle will get closer together the more advanced you get
- Layne’s situation is kind of unique
  - He gets his kids 1 week on, 1 week off
  - He’s noticed the week he has the kids, he gets less sleep and has a little more stress
    - His performance goes down a bit
    - He tracks bar velocity as well using a device called [RepOne](https://www.reponestrength.com/)
    - RepOne is an accelerometer; it’s about $400; it’s nerd stuff if you’re really dialed in
    - He tracks his performance in terms of strength, RPE, and speed
    - All these measures consistently show he’st not quite as good (he’s about 90 to 95% as good) on the weeks the kids are with him
  - This has built in micro cycles of tapering for him
- Overall through these micro cycles, we’re trying to walk up the volume and the progressive overload.
- After probably 4-8 weeks, he’ll do a much bigger taper where we pull back on everything
  - But we do micro tapers in between
  - So taper after about 4-8 weeks with this guy (hypothetical case study #2)
- For this guy, split the difference and have him push for 6 weeks then back off
- Layne recommends backing off of both the volume and intensity a little bit
  - Maybe he’s up to a 7, 8, 9 RPE on most sets
    - RPE is the rate of perceived exertion (relative perceived effort)
    - An easy way to think about it is if it’s a 7 RPE on a set, then that person could’ve done 3 more reps before they hit absolute failure
    - So most RPEs to Layne (or advanced people) should be close to 7 or 8, with a few sets pushing into a 9; and very rarely should you push to a 10
    - There’s quite a bit of literature out there to show that you get basically the same hypertrophy training close to failure that you do going to absolute failure
    - It’s not necessarily that failure is bad; it’s just the amount of recovery deficit it creates is disproportionate to the stimulus

## Maximizing hypertrophy while minimizing fatigue—is it necessary to train to muscular failure? [2:11:30]

- Layne wants to maximize hypertrophy and stimulus while minimizing fatigue
  - Sure, you can get a similar stimulus by going to failure and maybe even just a little bit more
  - But if it then causes you to have decreased performance the following week or not be able to push as hard overall, we have to think about this as an overall training program and not just isolated workouts
- [Dr. Mike Israetel](https://renaissanceperiodization.com/team-member/mike-israetel-phd) has talked about training shy of failure a lot on [Instagram](https://www.instagram.com/drmikeisraetel/?hl=en)
  - People will say this isn’t hard
  - Layne replies, “*one of my most impressive squat sets is I did 480 pounds for 14 reps and I’ve done 405 pounds for 21 reps before. I couldn’t move afterwards. First off it probably took me five minutes just to get my breath back, just to breathe enough to like be a functional human after that. Then as far as like going to do another set, first off when I hit that 480 and I grinded out that last rep, that 14th rep, I was so fatigued I couldn’t rack the right side of the barbell… And then I laid down for five minutes just trying to get my breath back. And then when I got up, if you told me I had to go squat 480 again, I’m telling you I couldn’t have gotten a single rep. Even after resting 10, 15 minutes. There’s not a chance in hell. So you’re telling me if I stopped two reps shy of that, that that would’ve felt easy. You’re insane*.”

> “*With compound movements specifically, you don’t have to get as close to failure to get the benefits*”— Layne Norton

**Stimulus for muscle growth [2:14:45]**

- Research shows that what was popular a few years ago was the effective reps hypothesis
  - The idea is that the majority of the stimulus for muscle growth occurs in the last 5 reps before failure
  - If you’re doing 20 reps, this means you need to get to at least 15 reps to get a similar stimulus
- In terms of volume and progressive overload, you really need to think about volume in terms of just the number of hard sets within a 5 RPE (rate of perceived exertion)
- But the research shows this is much more accurate for isolation stuff than it is for compound
- So compound lifts are kind of their own beast

> “*You can train at a sub-5 RPE and still get maximal EMG recruitment and quite a bit of hypertrophy*”— Layne Norton

- In contrast, with isolation, you have to train close to failure
- Also note, the exercises are not equivalent
  - Compare a 5 RPE squat and a 9 RPE leg extension
    - Layne can do 9 RPE on leg extension all day
    - Peter agrees, this is infinitely less painful
    - A squat is a big compound movement that requires core and stabilization and breathing and creating intraabdominal pressure, all that kind of stuff factors into fatigue

## Ideal sets and reps for the hypothetical 50-year-old male interested in hypertrophy [2:16:15]

- Our guy is more interested in hypertrophy than strength; he’s not going to powerlift
- Layne suggests variety; research shows that from 1 rep to 30 reps, you can build very similar amounts of muscle
  - Peter notes this is amazing, conventional wisdom says doing fewer than 6 reps would only add to strength and not hypertrophy
  - Layne notes, “*There are benefits to being in that hypertrophy rep range of six to 15 reps, that’s kind of like traditional*”
- Benefits of doing 6-15 reps
  - One of the nice things about the 6-15 reps is you can accumulate quite a bit of metabolic fatigue
  - You can use relatively heavy loads
  - You can get quite a bit of volume in that rep range
- If you’re doing really heavy weights for under 5 reps
  - Peter asks if you would have to double your number of sets jut to get the volume right
  - No because it’s more about the number of hard sets
  - But doing a hard set of 5 is not the same as doing a hard set of 10
  - But some people don’t like training with a high number of reps; it gets boring
- Training adherence is #1
- If he likes lifting heavy weights but isn’t worried about creating strength he can:
  - Do 1 set under 5 reps
  - And the rest at 6-10 reps for compound exercises
  - On isolation exercises he’ll do 15-20 reps, just for variety
- Research for short term gains (12 weeks) indicates he won’t see a difference in hypertrophy between low reps up to 30 reps as long as the number of hard sets are equated

> “*So really it says, is do what you like, do what you enjoy*”— Layne Norton

- The **sweet spot for hard sets** is probably about 6 to 10 sets in a session (per body part)
  - They don’t really see improvements above 10 sets
  - Now this gets a little bit complicated because if you **rest longer**, each set actually becomes more effective as a stimulus for hypertrophy
    - Presumably because you perform better and you can use more weight and do more reps on that individual set
- [James Krieger](https://weightology.net/about-james/) did a good meta-regression
  - Published in the *Journal of Sports Sciences* in 2017, [Dose-response relationship between weekly resistance training volume and increases in muscle mass: A systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/27433992/)
  - If you’re resting more than 3 minutes between sets, 6 sets (resting 1-2 minutes) might be more like 10 sets
  - Keep in mind, you don’t have to just jump to 10 sets immediately per body part, that’s a lot of sets
- You should probably use whatever is allowing you to adapt at the time
- If you are relatively new to training, you start doing 10 sets per body part
  - 1) What’s going to happen once you plateau? That’s a lot more sets you’re going to have to add on top of that
  - 2) You’re probably going to outpace your recovery capabilities.
  - If you are squatting and deadlifting every day, you better be in very good physical condition to do that; and even then there is an expiry date on that
- Peter has never tried to do squats or deadlift every day
  - He’s not willing to give up so many other things exercise-wise to do so
  - What he’s noticed is people who do this are being very clever; every day is not a crushing set
    - Some of those days, it’s a very, very low volume, low intensity that functions effectively as a recovery day where they’re basic working on the muscle memory in the form
- For case study #2, he’s currently doing 3, 60-minute workouts a week, but he’s willing to do more
  - His form is decent
  - You’re not concerned about overuse
- If he’s not looking to power lift, Layne doesn’t care about exercise selection
  - He’s probably not going to be doing a lot of free squatting and deadlifting even though that’s Layne’s personal love
    - Those create a very high recovery debt; and they’re very mentally taxing

## Maximizing hypertrophy by working a muscle at a long muscle length [2:22:15]

- It’s also very important to work a muscle at a long muscle length
  - There was a recent meta-analysis looking at partial range of motion, but partial range of motion at different muscle lengths
  - Published in the *European Journal of Sport Science* in 2021, [Partial range of motion training elicits favorable improvements in muscular adaptations when carried out at long muscle lengths](https://pubmed.ncbi.nlm.nih.gov/33977835/)
  - See also, [Effects of range of motion on resistance training adaptations: A systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/34170576/)
  - They found that while partial range of motion at shortened muscle lengths does not produce the same hypertrophy as full range of motion
  - Partial range of motion at lengthened muscle lengths produce similar hypertrophy as full range of motion
- Consider the biceps, because it is lengthened when your arm is straight
  - Is a partial rep from straight to say 90 degrees is more effective than if you just do the top of the bicep, with the same range of motion?
    - Presumably you wouldn’t see as much adaptation or muscle recruitment with a shorter range of motion
  - Layne notes that the bicep might be a little bit different because you would actually have to be on an incline bench to truly get the stretched range of motion
    - In a traditional dumbbell curl, the top end is actually the more difficult component of the rep
    - If you pre-stretch it, now you can make that bottom part a little more difficult
- If you think about something like a squat, a partial range of motion squat
  - If you’re doing a partial range of motion in the bottom half, that is not going to be easy
- It’s more about working the muscle in the difficult regions, but the stretch component does seem to be important

## Recommended lower body exercise routines and tips about training frequency [2:24:00]

- Layne is a big fan of something like a hack squat for leg development
  - If you don’t care about being strong on free squats,
- If you get a good machine, you can take it through a really full range of motion; you can really get a good stimulus for the quadriceps and some of the rest of the leg muscle
- There’s also really good pendulum squats
  - It’s kind of like you sit in a seat, it’s on an arm
  - As you’re getting lower, it gets a little bit easier because of the pendulum
  - And then as you get higher, it gets harder, which actually works on your strength curve
    - Because the hardest part of the squat is near the bottom and the easiest part is near the top
- With these 2 exercises you can really work through a nice full range of motion and create a lot of stimulus
  - He usually likes to have 2 main exercises for a big muscle group like that

> “*I think full range of motion or training in that stretched position is very, very important*”— Layne Norton

- You probably don’t need 2 exercises; you probably could just do hack squats for 5 or 6 set
- But people like variety; Layne would keep those between a 6-8 RPE and then go to a leg extension and leg curl and those sorts of things
- Additionally, he’d probably do some sort of [RDL](https://en.wikipedia.org/wiki/Deadlift#Deadlift_variations) because it’s not as fatiguing as a deadlift, but you’re still activating similar muscles
  - Keep that between a 6–8 RPE
- Peter asks, “*Are you going to coach that with one leg? Are you going to do Ipsi or ISO grab on the kettlebell?*”
- Layne would probably do a barbell, do both legs
  - If there was some imbalance or you wanted variety, you could do single let
  - If muscular hypertrophy is the primary goal, you can create more stimulus using both legs at the same time
- Follow this up with some isolation stuff, low-rest periods, higher reps, 10 to 20 repetitions going to a little bit higher RPE (8-9 RPE).
- If you’ve just got to take a set to failure, take the last out of the last exercise of an isolation to failure
- The bigger compound exercise is a little bit lower reps can be used, maybe 5-10
  - Then as you progress through more isolation, go into the higher end of the rep range and maybe taking some a little bit closer to failure

**How many days per week should case study #2 strength-train?**

- In terms of frequency
  - Meta-analysis hasn’t been sensitive enough to pick it up
  - So far as we know, for legs, it doesn’t matter; 1 time a week is enough
  - For upper-body, 2 times a week
  - Multiple times a week is probably beneficial for both
- Peter notes [Layne’s PH3 program](https://www.bodybuilding.com/workout-plans/about/ph3-layne-nortons-power-and-hypertrophy-trainer) is 5 days a week
  - Yes: 3 days of squatting, 2 days of deadlift, 3 days of bench pressing (and accessory on those days too)
- Frequency is more of a tool to distribute volume than it is an individual hypertrophy stimulus
  - It makes sense to Layne that if you have a muscle protein synthesis response (especially in trained individuals,) that’s only 16, 20, 24 hours, then multiple doses of that are probably better than just doing one dose and thinking you’ve got it all
    - We don’t have enough studies yet and we don’t have the sensitivity to detect that
    - Studies are also so heterogeneous in terms of the population studied, training status, types of exercises used, how RPE is measured, how intensity is measured, how volume is measured
- Layne notes, “*The amount of hypertrophy research that’s come out in the last five to 10 years is literally an explosion compared to pre 2010*”
  - He read just 1 meta-analysis on hypertrophy from resistance training in the entire time he was in graduate school

**Recommended reading**

- Peter asks what meta-analysis he would recommend for those who want to wade through the research
- Studies by James Krieger look at set number and volume
  - Published in the *Journal of Strength and Conditioning Research* in 2010, [Single vs. multiple sets of resistance exercise for muscle hypertrophy: a meta-analysis](https://pubmed.ncbi.nlm.nih.gov/20300012/)
  - Published in the *Journal of Strength and Conditioning Research* in 2017, [Strength and Hypertrophy Adaptations Between Low- vs. High-Load Resistance Training: A Systematic Review and Meta-analysis](https://pubmed.ncbi.nlm.nih.gov/28834797/)
- But putting out an actual program day to day is difficult because a lot of it boils down to personal preference

## Nutrition plan for the hypothetical 50-year old male wanting to add muscle [2:29:00]

- Let’s say our 40-50 year old male weighs 175-180 lbs
- He’s 20ish% body fat by DEXA
- He’s eating 120 g protein a day
  - This is a little light on protein
  - He is willing to eat anything you say

> “*I would say you’re not having any downsides to having 200 grams a day. And that’s a nice number to shoot for*.”— Layne Norton

- Layne also wants to make sure his calories and carb intake are adequate for facilitating recovery
- This guy wants to gain lean mass, Peter asks, “*How do you think about cycling him in terms of making him hyper caloric?*”
  - What should his target be for energy balance?
  - How much weight should he gain?
- Since he’s been training for a long time and he’s older, the likelihood that he’s going to be able to gain lean mass without at least some body fat is probably pretty low
  - If this were the lady in the first case study who had never trained before, this would be no problem
    - She’s going to gain some muscle and lose some fat
  - When you’ve been training for a long period of time, you have to have everything lined up just to gain ounces of lean body mass
    - Part of lining that up is a slight caloric surplus
- There is a new meta-analysis that came out that showed that an energy deficit (it’s not quite the same thing) impairs lean body mass accrual
  - Published in the *Scandinavian Journal of Medicine & Science in Sports* in 2022, [Energy deficiency impairs resistance training gains in lean mass but not strength: A meta-analysis and meta-regression](https://pubmed.ncbi.nlm.nih.gov/34623696/)
  - This makes sense because in an energy deficit there are decreased rates of basal protein synthesis
  - From a mechanistic perspective, it activates AMP-kinase, which is an inhibitor of mTOR
  - From a teleological perspective, if you don’t have excess energy, muscle remodeling is extremely energy expensive
- Peter rephrases this, “*if you’re going to eat 1,000 calories a day, you could probably better off having them be as much protein as possible, but just because you have 200 grams of protein in your diet, if the calories are exceptionally low, you’re probably losing lean mass*.”
  - Layne isn’t worried about 1 day of energy deficit
  - But if someone ate just 1,000 calories a day, virtually all protein in an effort to get as lean as possible without losing lean mass
    - Layne notes you might be able to not lose lean mass
    - But the likelihood you would gain lean mass is very, very low for someone who has been training for a while

> “*The more advanced you get, the more things you have to have lined up correctly to continue to push*”— Layne Norton

**Layne’s experience powerlifting**

- Layne was in the 230-pound class for powerlifting back in 2019, and he just started to drop back down to his original weight class of 205 pounds
  - He did that over the course of about a year
  - But that was taken in sprints
  - He would do fat-loss sprints
    - For example, he would do 2 or three 3 of a pretty aggressive deficit, 750 to 1,000 calories a day to lose 5-6 lbs
    - Then he would shift to maintenance for the same amount of time
    - He built this into his lifestyle
- Peter asks what body fat is best for his performance, surely not 7%
  - Layne can maintain pretty well and perform at 7%
- Layne and his coaches use diet breaks, where people are eating at maintenance
  - So if you’re going on vacation, have a diet break for 2 weeks then do a fat-loss sprint

## Cycling weight gain and weight loss when building lean muscle mass, and expectations for progress over time [2:33:30]

- This man should eat a slight caloric surplus for about 8 weeks to gain 3 lbs of body weight
- Next maintain this for a little while to make sure he doesn’t put on extra fat
  - Let his body adjust
- Then do another 6-8 weeks
- Fat loss should be slow for people who are well trained
- Weight gain should occur at a snail’s pace
- As a rule of thumb, if he’s going to gain 5 lbs of total body weight, aim for 3 lb to be lean
  - This will probably take 12 weeks
  - But it might be more like 6 months
    - At 12 weeks he’s up to 5 lbs but then he works on reducing a bit of fat and comes back down to a gain of only 3 lbs
    - This could be followed by another gaining cycle
- With each cycle, the composition of lean tissue to fat gets a little bit better
  - This is Layne’s anecdotal experience from coaching
- When trained people put on weight it is often 50-50, lean mass to fat mass
  - Sometimes it’s 40-60, if you’re really well trained (40% lean, 60% fat)
- Peter notes, it’s important to tell this guy, “*Hey, if you’re going to be rigorously following body comp, don’t be disappointed if your body fat goes up in that cycle*”
- Layne compares it to investing, and playing the long game
  - Your taking money away from this immediate moment so hopefully you have more money later

**Is there a limit to the amount of muscle that can be gained?**

- The good thing is that when we lose body fat for resistance training, loss of body fat get a little better each cycle
  - Now, there are limits to this, your genetic limit
  - You never really know if you’re at your genetic limit
- Layne shows people a picture of himself at 21 years old, where he had been resistance training hard for 3-4 years
  - Most people would say he was at his genetic limit
  - Then he shows a picture of himself now, at age 40
  - The difference in his leg musculature and overall musculature is enormous (from age 21-40)
  - But if you looked year by year, you would see very little difference

> “*You might think you’re at your genetic limit, but you’re probably not; and it’s probably more like a asymptote*”— Layne Norton

- You never really hit a hard limit, rather the gains become some minimal it’s almost not measurable
- This male should focus on making sure they can do a lot of resistance training
  - Because it’s going to take quite a big stimulus to get in there, focusing on stimulus versus fatigue
  - Do high stimulus, low fatigue movements so that they can accumulate enough volume without overreaching all the time
  - If they can train for 12 weeks without needing a taper versus six weeks, that’s more stimulus
- Eat a slight caloric surplus, 200 calories a day over maintenance
  - This means there will be weeks where he doesn’t gain anything
- Weight gain tends to come on in chunks
  - Just like weight loss occurs in chunks
- What tends to happen is people get really frustrated because the weight comes on so slow that they end up just throwing down a bunch of calories so that they can say they gain the weight
  - And this doesn’t go well
- Layne notes, “*You can be stable, stable, stable, even though you’re in a calorie surplus. Then all of a sudden, boom, your weight’s up 2 pounds randomly and it sticks*.”
- He should look at the month to month average during the  gaining phase to see if he’s hitting his milestones

## Supplements to aid in hypertrophy training [2:38:30]

**Protein powder**

- How does [whey protein](https://en.wikipedia.org/wiki/Whey_protein) stack up in the hierarchy of proteins?
  - What other sources should we look at?
- Whey protein is high in [leucine](https://en.wikipedia.org/wiki/Leucine), [branched amino acids](https://en.wikipedia.org/wiki/Branched-chain_amino_acid) [the ones that can be utilized by muscle], and [essential amino acids](https://en.wikipedia.org/wiki/Essential_amino_acid)
  - It generally tastes good and is well tolerated
  - People will have difficulty tolerating a straight whey concentrate but a blend of concentrate and isolate is what is mostly out there (and is tolerated well)
- Whey comes from cow’s milk
  - Centrifuge off the fat, take what is left over and precipitate out the casein (the non-soluble fraction of milk), and the soluble portion that is left over is whey
- Whey mostly consists of proteins called [lactalbumins](https://en.wikipedia.org/wiki/Lactalbumin)
  - It’s a high-quality, easily digestible, very bioavailable source of protein
  - It’s top in terms of muscle protein synthesis; it always scores highest in his research
    - There was no statistical difference from egg protein
    - Maybe if you had a higher subject number you could pick out some statistical difference between whey and egg
    - But people like whey a little bit better
- Peter asks what brand he thinks is best
- Shameless plug— Layne has his own supplement line, [Outwork Nutrition](https://outworknutrition.com/)
- He has a whey protein isolate ([outward nutrition build](https://outworknutrition.com/products/build-whey)); isolates are a little bit more expensive than a concentrate isolate blend, but it is better for sensitivities
  - There are people with lactose intolerance
  - There are people with sensitivity to the lactalbumins
  - An isolate is generally well tolerated
  - Some people with really high sensitivity to the lactalbumins can’t tolerate an isolate
    - If that’s the case, they could probably do a hydrolyzate, which is a little more expensive and doesn’t taste as good, but still a good option for those that with a really sensitive GI
    - So it’s just low carbohydrate, low lactose, low fat, high protein, high leucine. So I think our leucine contents over 11 per, I think it’s actually 12%, which is very high. And then the carbohydrate content, depending on vanilla or chocolate is like one to four grams. And then the fat content is less than a gram of fat. In fact, the vanilla is zero.
- Other brands Layne trusts include: Legion, Optimum, EAS

**Recommendations for reading labels**

- He recommends avoiding proprietary blends

> “*Proprietary blends are usually just a way for people to hide stuff*”— Layne Norton

- You also want to avoid products that are doing what’s called nitrogen spiking
  - You can pump up the protein and nitrogen content by adding individual amino acids that cost less than just the whey protein itself
    - Such as [glycine](https://en.wikipedia.org/wiki/Glycine)
  - Sometimes [creatine](https://en.wikipedia.org/wiki/Creatine) is added; not that creatine isn’t good but you’re taking away protein
    - This is another way to cut costs and increase the protein content

**Branched-chain amino acids**

- Peter asks, “*Is there utility in using branched-chain amino acids specifically in workouts where these are typically coming as far lower doses, right?”*
  - They’re typically 5 g per serving
  - [Branched-chain amino acids](https://en.wikipedia.org/wiki/Branched-chain_amino_acid) are the only ones muscle can oxidize for energy, they are: leucine, isoleucine, and valine

> “*So this was something that I’ve changed my mind on*”— Layne Norton

- Layne did his PhD on leucine
- He used to think branched chain amino acids are useful, but he can’t support that anymore
- If you’re getting enough total protein in, it doesn’t seem to be benefit to supplement with branched-chain amino acids
- They may have a role in reducing muscle soreness
  - But this has never been compared with a similar amount of whey protein
- Maybe branched-chain amino acids would be good for someone who cannot get enough high quality protein in
  - Maybe if you’re a vegan or on a plant-based diet
- Layne did a study where he looked at whey protein versus wheat protein
  - He saw that whey protein triggered a bigger response in muscle protein synthesis compared to wheat protein
  - Published in the *Journal of Nutrition* in 2009, [The leucine content of a complete meal directs peak activation but not duration of skeletal muscle protein synthesis and mammalian target of rapamycin signaling in rats](https://pubmed.ncbi.nlm.nih.gov/19403715/)
  - Gram per gram, isonitrogenous difference in muscle protein synthesis when rats ate whey versus wheat protein
  - When he added leucine [to the wheat protein] to match the leucine content of the whey, he got the exact same response
- Peter asks about supplementing with leucine, 5 g [leucine](https://en.wikipedia.org/wiki/Leucine)
  - By the way it tastes horrible (Layne agrees)
  - Layne doesn’t see any benefit in this; he wished he did
  - He did his PhD on leucine and was hoping to find the secret anabolic trigger and get enough protein

**Creatine**

- [Creatine](https://en.wikipedia.org/wiki/Creatine) monohydrate used to be very popular
  - 30 g a day for loading, and then a maintenance phase of 5 g a day
- What you want to do is saturate your [phosphocreatine stores in muscle cells](https://en.wikipedia.org/wiki/Phosphocreatine)
  - You can do that through loading; it will saturate in 5-7 days
    - The downside to loading is GI discomfort, bloating
  - If you do it through maintenance, it will take about 3-4 weeks
- The benefits of creatine are boosting strength, hypertrophy, and recovery
  - It increases lean body mass, strength, and exercise performance
  - There may be cognitive benefits
- Don’t get caught up in the hype of other forms of creatine
- Creatine monohydrate has been shown to saturate the muscle cell 100%
  - You cannot get more than 100%
  - Other forms of creatine are simply in existence to remove more money from your wallet
  - Everybody has creatine in their supplement line; the margins are so thin; nobody makes money on straight creatine
- Layne has a supplement called [Recovery](https://outworknutrition.com/products/recovery) and creatine is one of the ingredients there
  - It has 5 g of creatine monohydrate
- You probably don’t need to take creatine on your off-days from lifting
- Peter asks, “*If you’re doing cardio on a non-lifting day, do you benefit at all from creatine there?*”
- This hasn’t been studied
- Creatine is very cheap so your not missing out on anything by having an extra dose
  - He would take it daily
  - If your budget is really thin, take it only on days you train

**Nitrates and nitric oxide**

- [Nitrates](https://en.wikipedia.org/wiki/Nitrate), [nitrites](https://en.wikipedia.org/wiki/Nitrite) do appear to enhance exercise performance
  - Beetroot juice and those sorts of things and sources of nitrites
- There was a recent meta-analysis looking at the effect of dietary nitrates and the effect size was actually pretty impressive for power
  - Published in the *Journal of the International Society of Sports Nutrition* in 2021, [Effect of dietary nitrate on human muscle power: a systematic review and individual participant data meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8501726/)
  - They found an average increase in muscle power of 5%
    - 5% is the difference between first and last, if you’re talking about the Olympics
  - The effect size was a 0.42, which isn’t considered a large effect size, but it’s approaching a modest effect size
    - For supplements, this is really impressive; it’s got to be close to the effect of creatine
- A lot of supplements appear to not have in them what they say they have in them in terms of these nitrates

**Citrulline**

- Also, something like [citrulline malate](https://en.wikipedia.org/wiki/Citrulline) can be recycled into [arginine](https://en.wikipedia.org/wiki/Arginine) and then into [nitric oxide](https://en.wikipedia.org/wiki/Nitric_oxide)
  - So citrulline malate or citrulline specifically, actually increases blood nitrate levels more than arginine itself
    - This is because citrulline is much more [bioavailable](https://en.wikipedia.org/wiki/Bioavailability)
    - Arginine is mostly extracted by the [splanchnic tissues](https://en.wikipedia.org/wiki/Splanchnic)— the gut, liver
- If you’re looking at citrulline specifically, take 6-8 g per dose
  - His [pre-workout powder](https://outworknutrition.com/products/pre-workout) has 6 g
- Citrulline is taken more to increase performance than hypertrophy
  - Presumably if your performance goes up, you have more stimulus; you might see the gains there
  - There is some evidence that citrulline can actually stimulate mTOR, but I’m not sure it’s enough to actually create hypertrophy on its own

**Timing of supplements**

- Pre-workout— citrulline
- Post-workout— whey protein
- When should creatine be taken?
  - The timing doesn’t seem to be important
  - Thinking about the mechanism, it shouldn’t matter because it’s a long term thing
- Layne included creatine in the recovery product and not pre-workout for a couple reasons
  - 1) There is not an immediate effect from creatine; it might have a little bit better effect post workout
  - 2) Some things in the pre-workout product are semi gut-irritants for some people and creatine can be a gut irritant, so they didn’t want to compound that effect
    - A lot of pre-workout mixes do contain creatine
    - When creatine is paired with a large dose of caffeine, it can cause a lot of GI discomfort
- Peter asks what he drinks during the workout
  - Gatorade Zero ro something similar, and water
- If you’re working out for 2-3 hours at a time, maybe it’s useful to get some glucose and carbohydrate in to maintain performance
- Bodybuilders or weightlifters tend to overestimate how difficult their workouts actually are
- You only need to worry about the speed of glycogen resynthesis if you’re doing multiple events per day
  - If you’re a bodybuilder, it’s going to be 24 hours until your training; you’re going to resynthesize that glycogen as long as you get enough total carbohydrates
- He’s not real huge on intra-workout nutrition, as long as we’re not talking about really long workouts or multiple sessions per day

§

## Selected Links / Related Material

**Previous podcast with Layne**: [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance](https://peterattiamd.com/laynenorton/) | Host Peter Attia,  [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (May 24, 2021) | [0:45, 1:31:00, 1:334:00]

**Study by Levine in 1999 overfeeding people and observing their total energy expenditure and weight gain**: [Role of nonexercise activity thermogenesis in resistance to fat gain in humans](https://pubmed.ncbi.nlm.nih.gov/9880251/) | *Science* (JA Levine, NL Eberhardt, and MD Jensen 1999) | [19:00]

**Accuracy of wrist devices that track energy expenditure**: [Accuracy in Wrist-Worn, Sensor-Based Measurements of Heart Rate and Energy Expenditure in a Diverse Cohort](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5491979/) | *Journal of Personalized Medicine* (A Shcherbina *et al*. 2017) | [23:30]

**Tracking energy expenditure of people who self-report as resistant to weight loss**: [Discrepancy between Self-Reported and Actual Caloric Intake and Exercise in Obese Subjects](https://www.nejm.org/doi/full/10.1056/NEJM199212313272701) | *The New England Journal of Medicine* (SW Lichtman *et al.* 1992) | [24:45]

**Layne’s website Team Biolayne**: [Biolayne: Layne Norton. Bodybuilding. Coaching. PhD.](https://www.biolayne.com/) (2022) | [31:30, 54:00]

**John Speakman’s paper on BMR**: [Evolutionary perspectives on the obesity epidemic: adaptive, maladaptive, and neutral viewpoints](https://pubmed.ncbi.nlm.nih.gov/23862645/) | *Annual Review of Nutrition* (JR Speakman 2013) | [38:00]

**Marie Spreckley’s review on sustainable weight loss**: [Perspectives into the experience of successful, substantial long-term weight-loss maintenance: a systematic review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7833027/) | *International Journal of Qualitative Studies on Health and Well-being* (M Spreckley, J Seidell, and J Halberstadt 2021) | [1:01:15]

**Layne’s book**: [*Fat Loss Forever: How to Lose Fat and KEEP It Off*](https://www.amazon.com/Fat-Loss-Forever-Lose-KEEP/dp/1794510109/ref=sr_1_3?crid=2AJL0ZS93L5YM&keywords=layne+norton&qid=1646335823&sprefix=layne+norton%2Caps%2C105&sr=8-3) by Layne Norton and Peter Baker (2019) | [1:01:30]

**The validity of doubly labeled water studies in a ketogenic diet is questionable**: [Do low-carbohydrate diets increase energy expenditure?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8076039/) | *International Journal of Obesity* (KD Hall, J Guo, and JR Speakman 2019) | [1:05:15]

**Meta-analysis of energy expenditure during low carb diets**:  [Do Lower-Carbohydrate Diets Increase Total Energy Expenditure? An Updated and Reanalyzed Meta-Analysis of 29 Controlled-Feeding Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7948201/) | *The Journal of Nutrition* (DS Ludwig *et al.* 2021) | [1:07:15]

**Series on the blog on how to analyze scientific studies**: [Studying studies](https://peterattiamd.com/tag/studying-studies/) | [1:12:15]

**Layne’s appearance on** ***The Joe Rogan Experience***: [#1176- Dom D’Agostino & Layne Norton](https://open.spotify.com/episode/1G5UGm5BqnbAFoefA20zx1) | Host Joe Rogan, [The Joe Rogan Experience](https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk) (September 2018) | [1:16:15]

**Review of links between lack of muscle strength and mortality in elderly**: [The danger of weight loss in the elderly](https://pubmed.ncbi.nlm.nih.gov/18615231/) | *Journal of Nutrition, Health, & Aging* (SL Miller and RR Wolfe 2008) | [1:25:15]

**Effects of resistance on protein synthesis in trained and untrained individuals**: [A review of resistance training-induced changes in skeletal muscle protein synthesis and their contribution to hypertrophy](https://pubmed.ncbi.nlm.nih.gov/25739559/) | *Sports Medicine* (F Damas *et al*. 2015) | [1:31:45]

**Layne’s diet coaching app**: [Carbon: Simple. Scientific. Sustainable. The smart, adaptable diet coaching app that will help you achieve long lasting results](https://joincarbon.com/) | (2022) | [1:43:45]

**Adding lean body mass impaired on a ketogenic diet, 12-week studies**:

- [Efficacy of ketogenic diet on body composition during resistance training in trained men: a randomized controlled trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6038311/) | *Journal of the International Society of Sports Nutrition* (S Vargas *et al.* 2018) | [1:52:45]
- [Effects of a ketogenic diet on body composition and strength in trained women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7146906/) | *Journal of the International Society of Sports Nutrition* (S Vargas-Molina *et al.* 2020) | [1:52:45]
- [Effects of resistance training combined with a ketogenic diet on body composition: a systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/33624538/) | *Critical Reviews in Food Science and  Nutrition* (D Ashtary-Larky *et al.* 2021) | [1:52:45]

**James Krieger’s meta-analysis about number of sets for resistance exercise**: [Dose-response relationship between weekly resistance training volume and increases in muscle mass: A systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/27433992/) | *Journal of Sports Sciences* (BJ Schoenfeld, D Ogborn and JW Krieger 2017) | [2:19:00, 2:28:30]

**Meta-analysis on partial range of motion**:

- [Partial range of motion training elicits favorable improvements in muscular adaptations when carried out at long muscle lengths](https://pubmed.ncbi.nlm.nih.gov/33977835/) | *European Journal of Sports Science* (GF Pedrosa *et al.* 2021) | [2:22:30]
- [Effects of range of motion on resistance training adaptations: A systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/34170576/) | *Scandinavian Journal of Medicine & Science in Sports* (JG Pallares *et al.* 2021) | [2:22:30]

**Layne’s Ph3 program**: [Ph3: Layne Norton’s Power Hypertrophy 13-Week Trainer](https://www.bodybuilding.com/workout-plans/about/ph3-layne-nortons-power-and-hypertrophy-trainer) |  [bodybuilding.com](https://www.bodybuilding.com/) (2022) | [2:27:00]

**James Krieger’s meta-analysis of low-vs. high-load resistance training**: [Strength and Hypertrophy Adaptations Between Low- vs. High-Load Resistance Training: A Systematic Review and Meta-analysis](https://pubmed.ncbi.nlm.nih.gov/28834797/) | *Journal of Strength and Conditioning Research*  (BJ Schoenfeld *et al.* 2017) | [2:28:15]

**New meta-analysis showing that an energy deficit impairs lean body mass accrual**: [Energy deficiency impairs resistance training gains in lean mass but not strength: A meta-analysis and meta-regression](https://pubmed.ncbi.nlm.nih.gov/34623696/) | *Scandinavian Journal of Medicine & Science in Sports* (C Murphy and K Koehler, 2022) | [2:30:30]

**Layne’s line of supplements**: [Outwork Nutrition: Science-Backed Supplements: For serious athletes](https://outworknutrition.com/) | (2022) | [2:40:15]

**Dietary nitrate increases muscle power by 5%**: [Effect of dietary nitrate on human muscle power: a systematic review and individual participant data meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8501726/) | *Journal of the International Society of Sports Nutrition* (AR Coggan *et al.* 2021) | [2:49:15]

§

## People Mentioned

- [Suzanne Devkota](https://www.devkotalab.com/research) (Professor at UCLA studies gut microbiome) [7:15]
- [Eric Ravussin](https://www.pbrc.edu/research-and-faculty/faculty/Ravussin-Eric-PhD.aspx) (Director of the Nutrition Obesity Research Center at the Pennington Biomedical Research Institute) [30:00]
- [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) (Professor at the University of Aberdeen, expert in energy balance) [38:00, 1:05:00]
- [Brian Whitacre](https://www.brianwhitacre.net/) (the best natural bodybuilder Layne ever coached; [professor of economics at Oklahoma State](https://experts.okstate.edu/brian.whitacre)) [54:15]
- [David Ludwig](https://www.hsph.harvard.edu/profile/david-s-ludwig/) (Professor of Pediatrics and Nutrition at Harvard School of Public Health) [1:03:45]
- [Rudy Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md#areas-of-expertise-conditions-treated) (Professor at Columbia University  Institute of Human Nutrition) [1:04:00]
- [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) (Section chief at the National Institute of Diabetes and Digestive and Kidney Diseases) [1:04:00, 1:05:00]
- [Eric Robinson](https://www.liverpool.ac.uk/population-health/staff/eric-robinson/publications/) (Studies the psychology of obesity at the University of Liverpool) [1:04:00]
- [Steve Smith](https://www.adventhealthresearchinstitute.com/team/steven-smith) (Obesity expert, Chief Scientific Officer, Senior Vice President of AdventHealth) [1:04:00]
- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) (20th century physiologist who studied impact of diet on health) [1:05:30]
- [David Ludwig](https://www.childrenshospital.org/research/researchers/l/david-ludwig) (Professor of Nutrition at the Harvard School of Public Health) [1:07:15]
- [Bob Wolfe](https://uams-triprofiles.uams.edu/profiles/display/126430) (Professor of Geriatrics at the University of Arkansas) [1:25:15]
- [Felipe Damas](https://www.researchgate.net/profile/Felipe-Damas-2) (Postdoctoral researcher who studies muscle physiology) [1:31:45]
- [David Sinclair](https://sinclair.hms.harvard.edu/people/david-sinclair) (Professor in the Department of Genetics and co-Director of the Paul F. Glenn Center for Biology of Aging Research at Harvard Medical School) [1:55:30]
- [Dr. Mike Israetel](https://renaissanceperiodization.com/team-member/mike-israetel-phd) (professor in the strength and hypertrophy masters program at Lehman College) [12:12:15]
- [James Krieger](https://weightology.net/about-james/) (founder of weightology, published on exercise and nutrition)  [2:19:00, 2:28:30]

§

![](https://peterattiamd.com/wp-content/uploads/2021/05/1x1-laynenorton-500x500.jpeg)

##### Layne Norton, Ph.D.

Layne Norton is a natural pro bodybuilder, professional powerlifter, and a bodybuilding / figure / physique coach.  He has won numerous bodybuilding and powerlifting competitions and currently holds the world record for the IPF 93 kg class squat (303 kg, 668 lbs).  He is the co-author of several books, including [*Fat Loss Forever: How to Lose Fat and KEEP It Off*](https://www.amazon.com/Fat-Loss-Forever-Lose-KEEP/dp/1794510109/ref=sr_1_3?crid=2AJL0ZS93L5YM&keywords=layne+norton&qid=1646335823&sprefix=layne+norton%2Caps%2C105&sr=8-3), as well as several research publications. He has a degree in biochemistry from Eckerd College and earned his PhD in nutritional sciences from the University of Illinois.

Website: [Biolayne](https://www.biolayne.com/)

Podcast: [Physique Science Radio](https://www.biolayne.com/media/podcasts/)

Twitter: [@BioLayne](https://twitter.com/BioLayne?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Facebook: [Layne Norton](https://www.facebook.com/LayneNorton)

Instagram: [Biolayne](https://www.instagram.com/biolayne/?hl=en)