# #196 – AMA #32: Exercise, squats, deadlifts, BFR, and TRT

**Source:** [https://peterattiamd.com/ama32/](https://peterattiamd.com/ama32/)

---

In this “Ask Me Anything” (AMA) episode, Peter shares his current workout regimen and how he incorporates blood flow restriction (BFR). He walks through the mechanics and fundamentals of some of his favorite lifts including squats, deadlifts, and hip thrusters and stresses the relative importance of each in the context of longevity. He touches on the relative importance of muscle size vs. muscle strength and discusses the impact of fasting on muscle mass and the potential tradeoffs during aging. Peter then dives into the topic of testosterone replacement therapy (TRT) for both men and women, starting with a clinical discussion around how he actually replaces testosterone in patients. He explains the targets of this therapy as well as the risks and benefits, and he gives his interpretation of current data on the association between TRT and heart disease.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #32 show notes page](https://peterattiamd.com/ama32). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Peter’s current exercise routine [2:25];
- How Peter incorporates blood flow restriction (BFR) into his workouts [5:45];
- Relative importance of muscle size vs. muscle strength [16:45];
- Comparing squats to deadlifts and why both are important [22:00];
- Squatting technique and fundamentals [31:15];
- Important cues to look for while lifting weights [38:30];
- Proper mechanics of a deadlift [42:00];
- Hip thrusters as an alternative to the squat or deadlift [44:00];
- Split-leg work for simulating activities of daily living [47:00];
- The impact of fasting/calorie restriction on muscle mass and the potential tradeoffs to consider [49:45];
- Testosterone replacement therapy: Considerations when contemplating TRT and Peter’s approach with patents [54:30];
- Data on the association between TRT and heart disease [1:04:15];
- TRT for women—risks and benefits [1:06:45];
- Impact of fasting on testosterone levels [1:13:45]; and
- More.

§

The Peter Attia Drive

Exercise, squats, deadlifts, BFR, and TRT

§

## Show Notes

§

## Peter’s current exercise routine [2:25]

**A few previous podcasts on exercise:**

- [Jeremy Loenneke episode](https://peterattiamd.com/jeremyloenneke/)
- [AMA #19](https://peterattiamd.com/ama19/)
- [AMA #21](https://peterattiamd.com/ama21/)
- [AMA #26](https://peterattiamd.com/ama26/)
- [AMA #27](https://peterattiamd.com/ama27/)

\*\*\*

**Peter’s current exercise routine**

*Cardio* – Tuesday, Thursday, Saturday, Sunday are cardio days

- Tuesday, Thursday, & Sunday are [zone 2](https://peterattiamd.com/ama19/) on a bike (for 45 minutes)
- Saturday is either:
  - A) Zone 2 followed by [Zone 5](https://peterattiamd.com/peter-attia-on-zone-5-anaerobic-training-protocols/) (separate workouts)
    - So a 45 minute zone 2 and then a 30 minute zone 5 done immediately after zone 2
  - B) Alternatively is just a longer bike ride on Saturday and make it more of an anaerobic workout

*Lifting* – Monday, Wednesday, Friday, Sunday

- About 9 months ago he switched to an upper body, lower body split (Previously he was lifting three days a week and would do upper body, lower body every day)
- Nowadays, lower body is Mon and Fri
- Upper body is Wed and Sun

***What happens if you miss a day?***

- He will never miss a lifting day
- Sometimes he’ll have to miss a cardio day

> “I will always get those four lifts in during the week, no matter what. And sometimes it just means moving the days around or doubling up on a different day.” —Peter Attia

*Time of day*

- Little more flexible on weekends, but Monday through Friday, pretty much no flexibility
- He always lifts weights in the morning around 7:15 or 7:30 AM

## How Peter incorporates blood flow restriction (BFR) into his workouts [5:45]

\*See [Jeremy Loenneke episode](https://peterattiamd.com/jeremyloenneke/) for more on BFR

\*\*\*

**How Peter incorporates blood flow restriction (BFR) into his workouts**

- Peter loves using the [SmartCuff](https://www.smarttoolsplus.com/detail.cfm/id/398/name/smartcuffs) as opposed to the bands
- He does BFR on every lift day for one to two exercises depending on the muscle group
- Examples:
  - At the end of a leg session, he might do a BFR leg press set
  - At the end of an upper body session, he might do a bicep set and a tricep set.
- The BFR protocol:
  - Using a weight that is 30 to 40% of your one rep max…
  - 30 reps, rest 30 seconds, 15 reps, rest 30 seconds, 15 reps, rest 30 seconds, 15 reps
- To calc one rep max ⇒
  - your best 10 rep weight is about 75% of your one rep max
  - Example of getting to proper BFR weight:
    - If your best 10 rep of curls is 40 pounds, you would divide 40 by 0.75.
    - That takes you up to 53
    - And then you would multiply that by somewhere between 0.3 to 0.4 and that becomes the weight that you’ll use for the BFR (in this case it about 20 lbs)

**The goal of blood flow restriction**:

- The goal is to operate at about 30% of the arterial occlusive pressure
- This is hard to know with just bands (unless using a Doppler signal to your distal extremities) which is why Peter prefers SmartCuffs
- These cuffs that come with an inflation device, they’re actually measuring the occlusive pressure
- “*So the first time you do it, it takes a little longer. And then it says, ‘Okay, now I know what it is for your arms and your legs’. Do you want to go at the highest level of intensity, medium level intensity, or a lower level of intensity?’ Which basically just adjusts the pressure*.”

**Cheap bands**

- you would wrap them around your arm and your leg
- Peter’s guide was once it hit 7 out of 10 pain, that was probably the right spot (very inaccurate)

![](https://peterattiamd.com/wp-content/uploads/2022/02/cheap-cuffs.png)

**Figure 1.** Cheap cuffs.

**SmartCuff**

- much more rigorous cuff
- A little device hooks onto the cuff and connects to a little pump where you program the level of occlusive pressure
- Peter says he was never really doing BFR for his legs when using the cheap bands but with the SmartCuff you really are getting the true occlusive effect

![](https://peterattiamd.com/wp-content/uploads/2022/02/smartcuff.png)

**Figure 2.** SmartCuff arm band.

*When doing BFR, what are you using to measure the difference there? Or how do you know it’s working? How can you tell?*

- Subjectively
- “*It’s not hurting where the band is compressing me. I’m feeling that sensation of basically lactic acidosis throughout the entire leg, as opposed to just the pain of being constricted where the band is when it’s a thin band*”
- It’s interesting to note the pressure of occlusion is much higher than systolic pressure because it’s a function of how wide the band is
- He noticed today when he did legs, the occlusive pressure was 158 millimeters of mercury and that’s way above my systolic pressure (he tends to run super low in blood pressure)
- His upper body occlusive pressure with those cuffs is about 94 millimeters of mercury
- “*But again, it’s also a function of the width of the cuff. So that’s why I realized just knowing your blood pressure isn’t enough to do this*.”

*Doing BFR at the END of a workout*

- “*For me personally, I just think when I’m doing my heaviest, most neurologically demanding component of exercise, I want to be a little fresher and I don’t want to be as taxed*”
- He likes using BFR as sort of a finisher of a workout

**Dead hangs and finger pull ups [14:00]**

- Dead hangs
  - Peter likes to work on grip strength with a dead hang workout (just hanging full extension from a pull up bar)
  - His PR is about 3 minutes 10 seconds
- Finger pull ups for grip strength
  - Pull ups with 4 fingers
  - Then goes to 3 fingers

**BFR and zone 2 [15:45]**

*Does Peter ever use BFR in his zone 2 training?*

- Not really, but he’s played around with it
- The closest thing he does is while on the [Airdyne bike](https://www.schwinnfitness.com/schwinn-airdynes/) –
  - His trainer has him doing some exercises once in a while where he puts the leg cuffs on and then do two minutes of whatever power he can hold for two minutes.
- He will do this with varying amounts of  leg pressure — “*when I do the highest occlusion, which is probably 40% of total occlusion, I’m really lucky to be able to hold 200 watts for two minutes, which is lower than my zone 2 power*“
- “If I go on the medium setting, which maybe is 35% out of occlusive force, I can probably be a little over 200 watts”
- The lower you put the occlusive pressure, the more you can do
- So it’s interesting to think how little wattage you would have to be able to push to still technically keep it as a zone 2

## Relative importance of muscle size vs. muscle strength [16:45]

**How important is muscle size compared to muscle strength?**

*And based on that, has it changed the way you train in any way? Has it changed how you look to build muscle? How have you actionized it?*

- The BFR literature that Peter and Bob discussed in [AMA #27](https://peterattiamd.com/ama27/) makes it pretty clear that muscle strength and muscle size are both important, but **muscle strength matters more**.
- That said, they’re so tightly interwoven
- So all things equal, a bigger muscle is a better disposal unit for glucose than a smaller muscle
  - That’s not necessarily true, but that’s all things equal
- That’s an argument in favor of why size matters
- Strength probably matters just from the objective data that look at the outcomes of strong people versus weak people
- So then the question becomes, *Can you disentangle them?*

[**BFR study**](https://academic.oup.com/biomedgerontology/article/70/8/950/2947617)

- In the study, the people did bicep curls and tricep press downs, but just with bands
- Super small study — roughly 10 people in each group, but they were older (age 60 to 85)
- The BFR group obviously was using nice BFR bands and they would use rubber stretch cords and do bicep curls and press downs
- They would do the same protocol we described. So the training set was the 75 reps. The 30, 15, 15, 15 separated by 30 second
- One group did it with the constriction
- One group did it without the constriction

The important question: *How much of the benefit of BFR is just the volume of training versus the specific metabolic environment that’s created?*

![](https://peterattiamd.com/wp-content/uploads/2022/02/yasuda-triceps-1024x595.png)

**Figure 3.** Triceps press down (a) and arm curls (b). Credit: [Yasuda et al., 2014](https://academic.oup.com/biomedgerontology/article/70/8/950/2947617)

- So in this figure, if you look at muscle cross section area determined by MRI
- it says BFR training versus control training
- This is basically looking at bicep measurement and then the elbow extender is looking at tricep measurement

*You can see pre versus post the change in muscle size in the figure below*:

![](https://peterattiamd.com/wp-content/uploads/2022/02/yasuda-1-ama32-1024x468.png)

**Figure 4.** Muscle cross-sectional area (CSA) [using MRI] in the elbow flexors (a) and the elbow extensors (b) pre- and post-training period. Values are means and SD. \*\*Different from pretraining, p < .01. Credit: [Yasuda et al., 2014](https://academic.oup.com/biomedgerontology/article/70/8/950/2947617)

- It’s actually pretty unambiguous here that you do see — even though these people were doing the exact same load, the people that were doing it under BFR were indeed seeing a change in muscle size as measured by cross-sectional surface area of MRI

*Then if you look at* ***strength*** *(figure below), you can also see a difference*:

![](https://peterattiamd.com/wp-content/uploads/2022/02/yasuda-2-ama32-1024x498.png)

**Figure 5.** Maximum isometric strength (MVC) [by dynamometer] of the elbow flexors (a) and the elbow extensors (b) pre- and post- training period. Values are means and SD. \*\*Different from pre-training, p < .01. Credit: [Yasuda et al., 2014](https://academic.oup.com/biomedgerontology/article/70/8/950/2947617)

- This was looking at a forced generation, maximum isometric strength.
- You can again see a difference so there is something about the lactate generation that you’re having to work through that goes beyond the fact that you’re doing so many reps at such high volume
- Very interesting results says Peter but notes it was a VERY small study and he would also like to see this in a much younger population
- So lots to be done here, but it **certainly suggests that BFR is valuable**

*The other question is*: ***Can you gain strength without gaining size?***

- The answer here is also very clear, says Peter
- Peter says he’s also seen this empirically — If you look at different training regimens where you focus on never doing more than four or five reps, you’re going to get stronger and stronger but you won’t necessarily get bigger and bigger
- Think about bodybuilders — these guys know more about hypertrophy than virtually any person on the planet and they’ll tell you if you’re not north of eight reps, it is hard to put on size.
- You can get stronger, but you’re not going to really put on size
- Furthermore, if you want to take that one step further, if you really want to put on strength without size, drop the eccentric part of the rep
- Example: if doing a trap bar deadlift, where you do the concentric (you pick it up) but then you just drop it
  - By dropping the weight you’re not going through the importance of lowering it slowly, which is of course utilizing your brakes, which is in some ways just as hard as picking it up.
  - Doing this means you’ll pick up that strength, but you won’t necessarily get into the tearing of muscle fibers that’s going to ultimately result in size.

## Comparing squats to deadlifts and why both are important [22:00]

***How does Peter think about squatting as a potential alternative to deadlifts in the Centenarian Decathlon?***

- They’re both important, says Peter
- Peter first points out how his approach to squatting and deadlifting is drastically different today than it was when he would much younger (teen years)
- Back then he was doing power lifting with as much weight as he could handle (which is what the sport of power lifting is all about)
- Nowadays, he has zero desire to be as strong as age 19
- In all of those activities now, he doesn’t even lead with those in my workouts
- For instance, when deadlifting, he’s doing it after heavy hip thrusters or something like that

So then the question is: ***Why do I still think they’re both very important?***

- Does everybody need to do them? “Absolutely not.”
  - In fact, you can get by with a lot of single leg work
  - Hip thrusters are also an amazing and a very safe way to get heavy, heavy hip extension
- Advantages of learning squats and deadlifts:
  - They really teach you a lot of complex things
  - how to release your ribcage
  - how to wedge
  - how to find your feet
  - In a case of a deadlift, how to tie your upper body basically to your lower body.

**The deadlift**

> “If you can learn to [deadlift] correctly, and you understand the biomechanical principles that go into it, you’re going to be so much stronger at everything you do in life.” —Peter Attia

- Peter says that the deadlift is the “ultimate example of being completely able to lock something from your hands, which are holding a bar, all the way to your feet, which are the only points of contact with the ground when you’re holding that bar”
- That turns out to have an amazingly complicated kinetic chain
- And if you can learn to do that correctly, and you understand the biomechanical principles that go into it, you’re going to be so much stronger at everything you do in life.

*Why it matters:*

- Activities of daily life is the point here
- It’s going to Home Depot and having to pick up thousand pounds of mulch and salt and all sorts of stuff
- With proper training, you now know how to safely transfer load
- Lifting bags of mulch, for example, is in some ways a harder lift because you’re picking something up, you’re rotating, you’re bending down at an awkward angle
- That’s why doing squats and deadlifts are important, they serve as an audit

When Peter chooses not to squat or deadlift:

- He does not do them every day, and even passes up days when something feels off
- “Today I squatted, but there’s days when I get there and I think, ‘Hmm. I don’t feel great after my warmup.’
- Same thing with a deadlift — “I really feel crappy. Not going to do this today. Or I’m going to stay really, really light.”
  - For instance, he might stay at 185 pounds only do 8-10 reps
  - But when going light he’s going to focus on something very specific
    - I.e., “just focus on my feet and make sure I can really feel the difference between where my heels have pressure on the ground and where my toes have pressure on the ground”
- When Peter was younger, he was really just doing a lot of lifting with sort of neurologic strength
- He’s not nearly as strong today, but he’s got much better technique, it all feels much safer, and he’s starting to feel these very subtle things

**fundamental difference between a squad and a deadlift [27:15]**

- With a uneducated glance, you might think they are the same movement more or less
- Let’s for a moment put aside trap bar deadlift, which is kind of a hybrid movement and we’ll just focus on a straight bar deadlift
- Personally, Peter likes deadlifting more, just psychologically — “I think I like that I get to involve my upper body in it in a way that I don’t get to do it as much with a squat.”
- The other thing about a deadlift that makes it slightly different is that the deadlift uses a little bit more of the back of the body
- you’re using the hamstrings more to assist you in the deadlift

Why you can generally lift more weight with a deadlift vs. a squat:

- Part of the reason the deadlift is a bit easier is if you normalize for knee angle, you’re still generally going to be stronger in a deadlift
- The other reason is the concept of tension
- Take the example of bench pressing:
  - One can lift more weight when your feet are planted on the floor than if your knees were bent and your feet were on the end of the bench
  - The reason for that is you could generate more tension in your body. You could anchor to the ground.
  - Similarly, look at how much tension they have in their upper body before they lift the bar.
  - That’s this kind of wedging idea
- Thinking about tension in the deadlift vs. squat:
  - When you’re getting ready to do a deadlift, before you lift the bar up, you’re trying to bend the bar up — Like bend it into a U shape
  - That’s how much tension you’re trying to put into the bar using your lats
  - And similarly when squatting, you’re trying to break that bar around your back. That’s again, just another way to capture tension within your upper body.
  - Just based on those two examples, it’s way easier to generate tension on a deadlift than it is on a squat.
  - So I think that’s a fundamental issue with these two lifts and why one of them is easier than the other

***Why do Peter think they’re both important?***

- “*I think you need to be able to generate tension in any position you’re in in life.*”
- “If you’re picking up a bag of groceries, if you’re picking up your child, you have to be able to find that tension from the abdomen all the way out to the extremity”

## Squatting technique and fundamentals [31:15]

**Beth figures**

![](https://peterattiamd.com/wp-content/uploads/2022/02/Heels-raised-squat-680x1024.png)

**Figure 6.** Peter using a “safety squat bar”. Yellow arrows: Action; Black arrows: Path; Peter “falls back” through his rib cage to be able to load the heels. This allows for more access to the legs (hamstring co-contraction) with less shear on the lumbar and allows the feet to push down so the bar path can be straight up.

- Peter is using a “safety squat bar” — Beth had asked him to try something different
- Normally Peter squats barefoot on a flat floor, but in this case, Beth wanted to put 10 lb plates under his heels so he put on shoes to not hurt his heels (Peter now uses “wedges” that he bought on Amazon so he can go barefoot)
- “*I couldn’t believe how much better I felt in this position [heels raised] … than the way I felt a week earlier when I was just doing my normal barefoot squatting*.”
- The better feeling from raised heels highlights a couple of things:
  - First, it really enables one to get more of that hamstring co-contraction
  - The heel is up in a way that’s probably generating a little bit more tension in the hamstring
  - And that hamstring tension allows him to feel something in his upper back.
  - The feeling you want in your upper back when squatting is to feel like your pushing it back through your ribcage — “it’s a very subtle movement”
- What you don’t want to be doing:
  - don’t want to be doing is overarching this way and using my lumbar spine
  - That’s when your back starts hurting when you’re squatting
  - Instead, what I want to be able to do is push back this way
  - what gives me the ability to do that is having something to push against in my hamstrings
  - So the whole point of a squat is having that tension in the back of the leg, which again, having an elevated heel makes it easier so that I’m pushing back through space as I’m lifting up
  - truthfully, that is a very uncomfortable position for most people if they don’t have the ribcage flexibility to do it
  - So if you’re in a high locked ribcage position, which unfortunately a lot of people are, you’re already in a position of a lot of lumbar extension. And now when you put a load on that person, it’s a disaster.

Who shouldn’t be squatting:

- Peter says “I just wouldn’t let somebody squat who can’t get their ribcage down and who doesn’t have the ability to sense the difference between pushing back this way versus arching this way”
- Does that come easily? No, it doesn’t
- Is it fixable? It absolutely is. But it might mean you’re just squatting with your body weight for some period of time or you just have a bar on your back

The other point to make about the figure above:

- Peter likes using this safety bar
- You can’t really see it from the picture, but it’s a very heavy bar—much more heavy bar than a standard Olympic bar
- It kind of bends over your neck and it has these handles in the front. And the handles are just another great reminder of a trick that you can use to get that back push.
- The trick is pull them out a little bit and lift them up just slightly. And that makes it so much easier to just drive your entire back so that you put more of the flexion higher into the thoracic spine, as opposed to concentrating every little bit of it in the lumbar spine

**Importance of form and video taping your form [35:35]**

- Injuries from squatting typically don’t happen suddenly, instead they are the result of bad form and technique and eventually cause pain and issues
- Peter recommends video taping all your squat and deadlift workouts (Peter personally does this every single workout)
- Peter watches himself between every set while resting before the next set — “*This has become a very important skill for me personally to work on over the past couple of years, which is becoming better at being able to coach myself*.”
- He recently caught himself doing something wrong on the trap bar when watching videos of himself
  - I had a tendency to initiate with my quads. And so just as I was getting ready to lift the bar up you would see my knees move an inch forward before I went up, only on the first rep
  - And then what that told me was I didn’t have enough tension in and I wasn’t moving back. I was just trying to go up as opposed to back
  - So now it’s like if I do trap bar, which these days I’ve been doing trap bar more for the past couple of weeks, it’s just so great. Even during those warm sets, I’m just watching it. I’m just locking in on it.

**Importance of being your own coach**:

- It might sound unpopular, On some level you don’t want a trainer sitting there just telling you what to do so that you can turn your brain off and just check your email in between sets
- You want to learn how to be your own coach. And this is something our patients get forced into and a lot of them get frustrated

> “If we’re your trainer, you’re not getting better. You’re not getting smarter. You’re not learning the proprioceptive clues to become strong.” —Peter Attia on the importance of being your own coach

- Obviously you need some direction at the outset
- And a lot of this can be done with someone who really knows what they’re doing over video
- The goal should be to, as quickly as possible, get to the point where you can be videotaping yourself and you can see,
  - “*You know what, I was all lumbar extension there and that’s why that felt horrible.*”
  - Or… “*My elbows were a little bit bent on that deadlift and I was therefor completely losing tension*.”
- That’s the kind of stuff you want to be able to do

## Important cues to look for while lifting weights [38:30]

*How can someone train that in a better way so that they’re just not showing up and mindlessly doing weights, not thinking about it, being distracted, things of that nature?*

- A lot of it has to do with knowing with what the right cues are and those will change based on something you’re working on or struggling with

Personal examples from Peter:

- Last week during squat, Peter was focused on hand position, just yanking those bars out and up
- Today, he was really focused on the pushing back and it just felt great
  - it was low weight and a very slow eccentric—three count down, one count up—And everything I thought about was just how much can I get that position back such that my whole back is moving back this way, as opposed to a kink in the lumbar spine
- There’s other days when all I’m thinking about is my foot pressure—how do my feet feel and am I feeling the pressure move from one part of my foot to another?

Being deliberate:

- So I do think you have to be deliberate with this stuff
- Note that the people who are really exceptional at this, they have so much muscle memory, so like the strongest guys in the world aren’t doing it this way. That’s obviously very different.
- But when you’re learning a new skill, I think you have to be very deliberate.

***How does Peter know if things aren’t going well?***

Squat days

- On squat days, he’s warming up with tons of spinal extension work like the segmental cat cow
- “If that doesn’t feel good, chances are I’m not going to feel good squatting”
- “In other words, if I can’t completely segmentally go from flexion to extension for the entire length of my spine, I’m going to probably default into the thing that is easiest to do, which is just lock it all in at one hinge point”
- This doesn’t mean he can’t squat that day, it just means it’s a red flag and he may want to think through what’s going and why he’s struggling

Deadlift days

- For warm ups he will get on his back and using his feet on the ground or on the wall to get hamstring pressure
- “If I can’t tilt my pelvis back while using my feet on the wall and one hamstring at a time pull down, I might be struggling to deadlift that day”
- “Because if I can’t feel that, it’s going to be very difficult for me to get tension on the bar and fall backwards, which is what you have to be able to do with the deadlift.”

## Proper mechanics of a deadlift [42:00]

![](https://peterattiamd.com/wp-content/uploads/2022/02/beth-deadlifting.png)

**Figure 7.** Beth doing a deadlift. Yellow arrows: Action; Black arrows: Path; Beth is pulling up on the bar (finger/grip strength) and falling back, which allows tension into the bar and the rock back from the forefeet to mid foot/heels. Pressure straight down into the floor allows the bar path to go straight up in sync with the hips extending.

- Beth doing a regular straight bar deadlift
- Peter says, “Sumo is my favorite where my legs are a bit wider and I’m holding the bar between my legs, but the principal’s very similar”
- There’s an amazing amount of tension she is generating between her hands and her feet
  - Her hands are pulling on that bar and her feet are pushing into the ground so hard
- You can see the arrow that she’s drawn on her upper back — When she lifts this up, the bar goes straight up. That’s the path of the bar
- But on the way down she is going to fall backwards — To be clear, the pressure that she is applying, if she weren’t holding 225 pounds she would fly backwards and land on the floor — that’s how much she is pulling back, as opposed to just thinking about standing up
- Her hips are going to extend, she’s going to stand and you can see (It’s hard to see in this picture) but the pressure in her feet is so important
- She’s going to basically rock back from the forefeet right into the mid foot and heels
- So at the top you want to keep the toes down at the top
  - So sometimes you can overcook this and you lift the toes at the top. You don’t want to do that
  - But that’s the slight subtlety I was talking about earlier where you want to be able to feel that weight move more from the front of the feet to the back of the feet as you stand.

## Hip thrusters as an alternative to the squat or deadlift [44:00]

**Hip thrusters**

![](https://peterattiamd.com/wp-content/uploads/2022/02/hip-thrusters-1024x625.png)

**Figure 8.** Peter doing hip thrusters. Yellow arrows: Action; Feet push straight into the floor, knees reach forward as he pushed the bar forward  (helps facilitate a posterior tilt via hamstrings and internal obliques). By keeping the chin tucked, he is preventing max hip extension because of DNF so hyper extension of the lower back is prevented. At the bottom, the is less ROM so less lumbar extension is required.

- The hip thruster is a very safe way to get a lot of load into hip extension
- Peter will use even more weight than he does when deadlifting
- This is something where the technique is easier and once you understand the basics, you’ll work up quicker here and you have less risk (Not no risk but less risk)

Many variations (there’s no one right way to do this)

- For some people, they like to have their back on a flat bench
- Other people will put their back on the floor, but put their feet elevated on a bench (Peter doesn’t like this version, finds it less effective)
- Peter does it the way you see in the photo — back is on a decline bench
- Beth likes to do it with her back on the flat ground

Form

- The most important cue is drive your knees forward and that will get your hips up
- when the weight gets heavier, you start tucking my chin
- When it’s very lightweight, you can keep a more neutral head shape
- You don’t want to be doing the opposite though. You don’t want the chin going up. You don’t want to go into neck extension — it’s a slight tuck of the chin, a push of the bar away, and a knees forward
- Then of course you’re really feeling those feet drive in
- And there’s really no conscious feeling of your back on that bench
- “*All I feel is feet into the ground. That’s where I feel like all the pressure is when I’m doing this*.”

*80% of the value of deadlifting?*

- Peter’s wife has mild scoliosis
- Peter was encouraging her to do deadlifting but Beth said to just do hip thrusters
- The reasoning? ⇒ Beth said ‘we’re going to get 80% of the value of her deadlifting by learning how to do these well and it doesn’t create any the axial load on her’
- Peter has a perfectly straight spine so he doesn’t have that issue
- But if you do have some scoliosis, look, it’s just one more thing that adds to that sheer out of that plane
- That’s an example of how you don’t have to always do the squat and the deadlift.
- Single leg stuff becomes an amazing substitute as well

## Split-leg work for simulating activities of daily living [47:00]

***Why consider doing split-leg work?***

- You don’t live your life always doing squats, always doing deadlifts, most of life is using one leg at a time
- Activities of daily living (ADL) is primarily single leg
- Think walking up stairs and down stairs (totally different than going up)
  - The latter being primarily an eccentric activity, the former being primarily a concentric activity

**Single leg work**

- Peter says about 60% of his leg workouts is still single leg stuff
- It allows you to be using less weight
- He does exercises like single leg pressing, split squats with rear foot elevated and/or front foot elevated, sliders, walking lunges, etc.
- Single leg work also allows you to iron out any deficiencies that you have between the legs

**Start with single leg work if you’re not experienced with squats/deadlifts**

- Peter recommends starting with split leg work before squats and deadlifts
- It’s safer and you can use less load
- By the way, it’s not that it’s easy
- Doing a proper lunge or split squat is just as technical and it’s very easy to do those incorrectly.
- The difference is t*he stakes are a lot lower*.

## The impact of fasting/calorie restriction on muscle mass and the potential tradeoffs to consider [49:45]

*How do you think about the tradeoffs between calorie restriction/fasting and muscle building for a person from a longevity perspective?*

- The older you are, the more important it is to emphasize anything that’s going to allow you to maintain and build strength and maintain muscle mass
- Peter is very reluctant to put an excess fasting routine in place for somebody that’s not very heavy
- That gets to the second equally important consideration, which is the big, big part of this is body composition
  - If you’re talking about somebody who’s got 35% body fat, insulin resistance, I think fasting’s a very effective tool and it’s okay that they’re going to probably lose a little bit of lean mass, because they’re probably going to lose more fat mass along the way
  - If you’re talking about somebody who’s kind of lanky, Peter would lean towards not fasting so much and if you’re going to fast do it intermittently — e.g., maybe once a quarter you do a short fast for three days
    - But most of the time should be really focused on building

> “As you get older, I think building becomes more important. The leaner you are, building becomes more important.” —Peter Attia

**Importance of getting enough protein in the context of fasting/building muscle**

Nick asks Peter: *A lot of times people interchange the word fasting with other things. So when you said earlier you went to an excess fasting regimen, what is that? Are you talking 12 hours, 24 hours, 72 hours? How do you think about that?*

- we really don’t know what’s long and what’s short for a fast, but we do know the extremes
  - For instance, we know 12 hours is not a fast and we know that five days is a fast
- Does one meal a day constitute fasting? ⇒ “I don’t think so”
  - The problem with one meal a day for most people, if they’re trying to put on muscle mass, it’s pretty darn hard to eat two grams per kilo of protein in one sitting
  - OMADs and things like that are generally going to come at the expense of muscle mass—Not because muscle protein synthesis can’t take place if you’re smart about where you target and time your exercise, but because I simply think most people are protein deficient when they do it
  - it becomes a bit of a protein sparing diet
  - Again, OMAD is a great idea if you’re overweight and insulin resistant, not a great idea if you’re lean.

*Timing protein around workouts- does it really matter?*

*⇒ See* [*episode with Layne Norton*](https://peterattiamd.com/laynenorton/) *for more on this topic*

- Peter has looked into the question of: *Is there a magical window in which you need to consume protein following a workout to optimize muscle protein synthesis?*
- The punchline answer is “no”
- There is actually quite a big window for that so it’s not like you have to be cramming down protein the nanosecond you finish that workout
- But you want to get it in at some point that day of a workout
- Generally speaking, heavy time restricted feeding probably hurts muscle mass more because it simply limits the volume of protein you take in

> “The heavy, heavy time restricted feeding probably hurts muscle mass more because it simply limits the volume of protein you take in.” —Peter Attia

## Testosterone replacement therapy: Considerations when contemplating TRT and Peter’s approach with patents [54:30]

⇒ *See* [*AMA #28*](https://peterattiamd.com/ama28/) *for a deep dive into TRT*

\*\*\*

**Normalizing testosterone without TRT**

-There are other ways to normalize testosterone beyond testosterone

-Peter will typically try HCG (analog of luteinizing hormone) with patients before trying testosterone—

- He’ll do this especially in men who are still unclear about whether they really want to go on TRT or have some concern about fertility or things like that
- HCG is the same hormone that women make when they’re pregnant and what you’re actually measuring in a pregnancy test
- “if I see a guy who has a very high LH and FSH, so luteinizing hormone and follicle stimulating hormone, which are made by the pituitary, they tell the testes to make testosterone”
- “If a guy has low testosterone and very high LH and FSH, it tells me, wow, everything is working except the testes”
- “The brain is sensing that he has low testosterone. It’s telling the body, “Hey, make as much of this as you can.” And it’s simply not responding. That’s a person I usually will not waste time with HCG on because I know the result. It’s not going to work”
  - Note that it’s all empirical, it depends how high and how low
- Sometimes Peter will try a “mega dose”… “But for the most part, those patients don’t tend to respond as well.”
- “But conversely, if you see a guy with low testosterone and low FSH and LH, and you try all the other usual stuff first, so you fix sleep, insulin resistance, all of the things that can also interfere with that pathway and nothing really gets better, I like to give HCG a try.”

**TRT regimen with patients**

- Peter likes to use testosterone cypionate with patients
- Typically start out at a dose of somewhere between 80 and a 100 milligrams weekly in the form of two injections (e.g., two doses of 40 to 100 mg per week)
  - By doing it twice a week, you’re getting a more steady state by using a lower dose twice a week
- Injected sub-Q with about the smallest needle you can get the oily testosterone cypionate out of which is about a 25 gauge (usually in the butt)
- Note: Lotions and creams are an alternative esp. For patients uncomfortable with giving shots, however, he finds that there’s less compliance and variable absorption rates
- There’s no oral substitute for this — testosterone orally is toxic to the liver

***How are we measuring the results?***

- Tracking everything to free testosterone
- Different men have very different amounts of sex hormone binding globulin so therefore they’re going to have different amounts of free testosterone
- Typically, Peter is targeting someone to be about the 80th percentile for what we can represent as their age for free testosterone to justify the intervention and to see if symptoms are improving

*When the decision is made to use TRT on a patient:*

- If someone is **above** the 50th percentile for free testosterone and they’re complaining of symptoms, they’re probably not attributed to the testosterone
- For instance, if a guy’s testosterone is 16 nanograms *[note: Peter mistakenly said milligrams]* per deciliter (~55th or 60th percentile for a middle aged guy), and he says he’s having a hard time putting on muscle mass — Peter’s first thought is NOT low T
  - Peter’s first thought is nutrition (protein) and training — “Until we confirm that he is progressively overloading his muscles, he’s doing the right stuff, he’s got the right volume, he’s got the right intensity, he’s got the right amount of protein…they almost assuredly are not in this situation where giving him more testosterone’s going to fix the problem”

*TRT for libido?*

- Similarly, there are certain symptoms that probably improve but in isolation I think are bad excuses or bad reasons to use testosterone and one of them is libido
- Let’s say a guy says “Everything’s fine, except my libido is low,”
  - Peter says that unless his testosterone is really low, 5th or 10th percentile, in Peter’s experience testosterone is not a fix all to libido
  - Now, if his testosterone is 4 nanograms per deciliter, it’s worth trying

***How long do you usually work with patients to try and improve testosterone levels through nutrition and exercise before going the testosterone route?***

- It really depends on what we see, says Peter
- There’s many times when it’s pretty clear looking at the patient that this is NOT attributed to insulin resistance or poor sleep or hypercortisolemia or all those other things
- Then there’s other cases where it really looks like it is those thing
- So in the latter, you’ll probably spend a little bit of time trying to make that correction
- In the former, you just wouldn’t spend any time on it, you’d go with TRT

**How quickly do you like to see results? And how to cycle TRT?**

- Biochemically you’ll see the benefits very quickly, especially with testosterone
- With HCG, It takes a little bit longer but you’ll see the benefits within weeks, meaning the correction of the number
- Peter subscribes to the “addition, subtraction, addition” method for how he likes to think through this
- So a reasonable course of action is 8 to 12 weeks in each of those cycles to really give him a chance to experience the up and the down

**The best cycling strategy so you can get the benefits of TRT without negative consequences [1:02:15]**

- Continuous use of TRT for 2 years is kind of the conventional wisdom for the max time
- Peter doesn’t like to stretch it that far – he likes to revisit the discussion after 6 months
- “I don’t think we’ve ever let somebody stay on testosterone for a year without a total confirmation that they aren’t having side effects”
- Testicular atrophy is a side effect in some cases, but if reproduction’s not an issue then the patient may elect to continue

> “If you’re as a patient thinking about this, I would not wait two years to have that discussion with your doctor.” —Peter Attia

## Data on the association between TRT and heart disease [1:04:15]

***Long term risk of heart disease with TRT?***

- - Some people have heard from their doctor or media or elsewhere that there’s a long term risk of heart disease with TRT
  - Peter points out that the doses being used in a medical setting is way way below some bodybuilders use where you might see heart issues

- *“I think you have to disaggregate what might be happening in people using super physiologic levels…*

- *…Certainly everybody hears the story of the bodybuilder who is having premature heart disease…*

- - *…the doses of this stuff that are being used in that setting have no bearing on the doses that we’re talking about for medical replacement of normalization of physiologic levels of testosterone*”

**Studies**

- There are several reviews that claim TRAVERSE (a trial underway) is going to be the first adequately powered trial to evaluate the incidence of cardiovascular events with testosterone replacement therapy
  - “*I haven’t seen the actual power analysis, but given its large sample size of something like 6,000 people over five years, I think we’re going to get a definitive answer there. I hope we will*.”

***Existing evidence to date –*** [2018 meta analysis](https://pubmed.ncbi.nlm.nih.gov/29803351/)

- With almost 100 RCTs in the analysis—admittedly some of them long, some of them short duration—”i*t’s very difficult to make the case that TRT is harmful*”
- There’s even some cases to suggest it’s beneficial
- “Personally, I’m not convinced by that either. I would just say it’s a wash”
- Peter says that with the TRAVERSE study, it might be the case that they find a slight increase in events
- However, it could end up like the [first iteration of the WHI study](https://jamanetwork.com/journals/jama/fullarticle/195120) found for estrogen and NPA in women for breast cancer
- Found a statistically significant increase of 24% in relative terms
- But the absolute term was 0.01%, which is clinically irrelevant
- (See [The Drive episode #42](https://peterattiamd.com/caroltavris-avrumbluming/) for more on this)

> “You have to differentiate between signal and noise here and I would say at this point it’s easy to say testosterone causes heart disease just like it’s easy to say estrogen causes breast cancer. But if. . .you’re actually going to go through all of the data. . .I think it becomes very difficult to make that case.” —Peter Attia

## TRT for women—risks and benefits [1:06:45]

***What do we know about TRT in women? What are the risks? What are the benefits?***

- “*This is a tough one*” says Peter
- First of all, there’s no approved testosterone formulation for women
- Because the doses that women would take are so small compared to men that it’s not that they can’t inject testosterone the way a man can
- The easiest way to give women testosterone replacement therapy is you have to have it compounded in a cream (which Peter doesn’t like to use in patients)

*The data*

- There was a [2019 meta analysis](https://pubmed.ncbi.nlm.nih.gov/31353194/) that only included RCTs of at least three months duration looking at TRT for women and it found 36 trials slightly under 10,000 participants.
  - It did find that it increased sexual function, self-image, significantly reduced sexual concerns and distress in post-menopausal women
  - “I would say empirically that’s pretty obvious”
- I also think we see it as an easier way for women who are really struggling to put on muscle mass and increase bone mineral density to do so
- But it’s difficult to disentangle that from estrogen, which I think plays a very important role there as well
- The problem with these trials or these meta analyses is they’re all over the place
  - Some of them are using implants where you put a little teeny, tiny pellet of testosterone, usually in the sub-Q fat in their gluteal space. And the advantage of that is you only have to do it every six months. The disadvantage of that is it’s sometimes high, sometimes low level.
  - One of the studies I think was using very small doses of an injection intramuscularly
  - There’s even sprays, gels, creams, patches
  - Even one study that talked about oral, but I think that’s insane. I would never give somebody oral testosterone

*Side effects for women*

- It’s also important to understand in women, the side effect profile
- You have a way narrower area to operate and you have to be very careful of it
- In the few women Peter has given TRT, the only side effect he’s observed is acne on the chin
- When you talk about the other extreme symptoms (e.g., hair growth), it’s easily reversible by lowering the dose
- Then, the kind of stuff that you see with female bodybuilders doesn’t really apply here because clitoral enlargement, voice deepening, they’re probably taking as much testosterone as a man would take

*TRT and breast cancer? [1:10:18]*

- Peter would like to search research looking into whether there is a chance testosterone is altering the risk of breast cancer
- He’s heard people hypothesize on this subject that testosterone would **further reduce the risk of breast cancer**—they’re very elegant arguments but they’re very theoretical
- A study on this would need to be for at least five years.
- It should be menopausal women
- The study size would have to be a large enough sample size to see if standard HRT plus or minus testosterone versus a placebo
- So you’d have three arms to the study and you’d ask “What was the impact on breast cancer?”

**Interesting studies relevant to the breast cancer question:**

[2018 study](https://ar.iiarjournals.org/content/38/12/6615.full)

- Study looking at what happened when you took estrogen and progesterone therapy and combined it with a topical patch of testosterone
- They looked at 88 postmenopausal women
- In a placebo group (half of them) they were just given estrogen and progesterone
- In the treatment group, they were given estrogen, progesterone, and a topical testosterone patch
- In the placebo group, there was a 5-fold increase in breast cell proliferation from their baseline,
- Conversely, in the group that also had the testosterone patch, there was no increase detected from their baseline

*Why is that interesting?*

- It’s interesting because you could make the case that breast cell proliferation is in some way a sign of ultimately:
  - Maybe metaplasia? – “Not really.”
  - Dysplasia? – “I’m not sure”
  - But are those things necessarily a cancer precursor? – “I’m not sure that it is.”
- “Again, I don’t think this study tells us one thing one way or the other, because I’m not convinced that estrogen and progesterone therapy increase the risk of breast cancer.”
  - So a fivefold increase in proliferation doesn’t mean much.
- Put it this way: When a woman goes through puberty, she has an enormous increase in breast cell proliferation. She’s not getting breast cancer. So breast cancer to be clear is not because you have more cells, *it’s because the cells are dysplastic*.
  - The cells are not responding to cell cycle signaling and the cells have the potential to spread.
  - So this is a grossly oversimplified way to think about this question

*Testosterone mitigating proliferative effects?*

- That said, at least it suggested that for some reason the testosterone mitigated all of the proliferative effects of estrogen and progesterone.
- Long winded way of saying…
  - “I don’t think we know.”
  - “I haven’t seen any evidence that testosterone is increasing the risk of breast cancer. That is for sure.”

Using common sense: “*When you are inside narrow physiologic bands, it’s very different than if you’re doing things in the wild west where you’re taking people to levels they’ve never experienced physiologically. And at that point, I think you have to be careful whether you’re dealing with men or women*.”

***When you use testosterone and TRT with the women in your practice, is it still the same as with men where you’re trying to dial in nutrition, exercise, sleep, everything prior to doing it?***

- No. It’s less so.
- With women, when you’re doing this, they’re in menopause and this is really about not making hormones anymore
- It’s a much more sudden reduction of testosterone that they’re experiencing

## Impact of fasting on testosterone levels [1:13:45]

***What about fasting and testosterone? Are there any benefits or risks to someone’s testosterone from fasting? Is that a tool that you can use to increase, decrease it? Do you use it at all with patients?***

- In any patient that Peter has doing longer fasts, if he happens to be measuring labs right after, testosterone generally plummets
- But you get to completely hypothyroid, completely hypogonadal — But this is very transient
  - You shouldn’t be doing those types of fasts that frequently that this would really move the needle
- The more relevant question is what are the things that chronically deplete testosterone?
  - Hypercholesterolemia, poor sleep, insulin resistance
  - “Those are the things that I would be a bit more worried about as the chronic depleter of testosterone, rather than the odd fast here and there.”

***If someone is doing those types of fasts like once a quarter, once every six months, how long do you recommend that they wait to run their labs after a longer fast?***

- It totally depends on why we’re doing the fast and why we’re measuring the labs
- So in some patients, for example, if we have a patient who is profoundly hyperinsulinemic, we might actually want to draw the labs before they even refeed
- So if they’re doing a five day fast, we’ll draw the labs on that fifth day before they break the fast
- And the purpose of that is specifically to see how low is that insulin and glucose in the most favorable state possible?
- This is the best case scenario for now

*But in the case that Nick described his question above…*

- It just depends
- If the goal is not to see abnormal labs that are impacted by the fast, then Peter would wait two to three weeks post fast, and that should more than return everything to normal
- If the goal is to see just how jacked your labs can get after you fast, do it before you break the fast.

***What’s the funniest result from labs you’ve seen from fasting? Because I know you run labs all the time. Any things that you saw that were really interesting or you didn’t expect to happen?***

- Mainly just how high uric acid gets probably due to how high the ketones get and maybe due to some autophagy breaking cells down
- Obviously how low the test testosterone gets and how profoundly hypothyroid you get

Peter personally sees some odd things in himself:

- For instance, his triglycerides don’t plummet to zero when would’ve expected triglycerides to go very low
- I’ve had some fasts where my triglycerides actually go up a little bit and I suggest that that might be due to just that’s my working currency
- I’m far less glucose dependent, far more ketone and fat dependent and maybe that’s why.
- Again, it’s not that triglycerides are going from 50 to 300, but they might go from 50 to 110 or something and I found that kind of strange

§

## Selected Links / Related Material

**Jeremy Loenneke podcast about BFR**: [#179 – Jeremy Loenneke, Ph.D.: The science of blood flow restriction—benefits, uses, and what it teaches us about the relationship between muscle size and strength](https://peterattiamd.com/jeremyloenneke/) | Peter Attia (peterattiamd.com) [2:50]

**Brand of BFR cuffs Peter uses**: [SmartCuff](https://www.smarttoolsplus.com/detail.cfm/id/398/name/smartcuffs)  [6:25]

**Stationary bike Peter uses**: [Airdyne](https://www.schwinnfitness.com/schwinn-airdynes/) [16:00]

**AMA episode comparing the importance of muscle mass to muscle strength**: [#176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity](https://peterattiamd.com/ama27/) | Peter Attia (peterattiamd.com) [17:15]

**BFR study looking at impact of BFR on muscle mass and strength**: [Effects of Low-Load, Elastic Band Resistance Training Combined With Blood Flow Restriction on Muscle Size and Arterial Stiffness in Older Adults](https://academic.oup.com/biomedgerontology/article/70/8/950/2947617) (Yasuda et al., 2014) [18:15]

**Episode of The Drive with Layne Norton discussing strength training**: [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training](https://peterattiamd.com/laynenorton/) | Peter Attia (peterattiamd.com) [54:00]

**Previous AMA on testosterone**: [#180 – AMA #28: All things testosterone and testosterone replacement therapy](https://peterattiamd.com/ama28/) | Peter Attia (peterattiamd.com) [54:30]

**TRAVERSE – Ongoing trial looking at TRT**: [A Study to Evaluate the Effect of Testosterone Replacement Therapy (TRT) on the Incidence of Major Adverse Cardiovascular Events (MACE) and Efficacy Measures in Hypogonadal Men (TRAVERSE)](https://clinicaltrials.gov/ct2/show/NCT03518034) | (clinicaltrials.gov)[1:05:00]

**2018 meta analysis looking at TRT**: [Testosterone and Cardiovascular Risk: Meta-Analysis of Interventional Studies](https://pubmed.ncbi.nlm.nih.gov/29803351/) (Corona et al., 2018)[1:05:45]

**First iteration of the WHI study that found HRT to increase breast cancer risk**: [Risks and Benefits of Estrogen Plus Progestin in Healthy Postmenopausal Women: Principal Results From the Women’s Health Initiative Randomized Controlled Trial](https://jamanetwork.com/journals/jama/fullarticle/195120) (Rossouw et al., 2002) [1:06:15]

**Episode of The Drive arguing that HRT does NOT increase breast cancer risk**: [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) | Peter Attia (peterattiamd.com) [1:06:30]

**2019 meta analysis looking at TRT in women**: [Safety and efficacy of testosterone for women: a systematic review and meta-analysis of randomised controlled trial data](https://pubmed.ncbi.nlm.nih.gov/31353194/) (Islam et al., 2019) [1:07:45]

**Study relevant to the breast cancer question looking at what happened when you took estrogen and progesterone therapy and combined it with a topical patch of testosterone:** [Does Transdermal Testosterone Increase the Risk of Developing Breast Cancer? A Systematic Review](https://ar.iiarjournals.org/content/38/12/6615.full) (Gera et al., 2018) [1:11:30]

§

## People Mentioned

- [Jeremy Loenneke](https://twitter.com/jploenneke?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [2:50]
- [Layne Norton](https://twitter.com/BioLayne?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [54:00]

§