# #355 – Skincare strategies, the science of facial aging, and cosmetic-intervention guidance | Tanuj Nakra, M.D. & Suzan Obagi, M.D.

**Source:** [https://peterattiamd.com/tanujnakraandsuzanobagi/](https://peterattiamd.com/tanujnakraandsuzanobagi/)

---

Tanuj Nakra and Suzan Obagi, two leading experts in aesthetic medicine, join Peter to explore the science of facial aging and skin health as well as the responsibilities physicians face in the world of cosmetic procedures. In this episode, they examine the biological and hormonal drivers of facial aging, the evolutionary and psychological foundations of attractiveness, and the impact of modern media on beauty standards. They discuss the rise in cosmetic procedures among adolescents and the ethical responsibilities of physicians in these cases. The conversation then shifts to a practical, evidence-based guide to skin health—covering the use of mineral sunscreens, retinoids, vitamin C, and tailored skincare routines, as well as the management of acne and the psychology behind aesthetic consultations. The episode culminates in a candid, personal assessment of Peter’s own face, offering a revealing look at what aesthetic medicine can achieve and how to think critically about pursuing it.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/tanujnakraandsuzanobagi/the_Drive_public.png)

Play

#355 – Skincare strategies, the science of facial aging, and cosmetic-intervention guidance | Tanuj Nakra, M.D. & Suzan Obagi, M.D.

#355 – Skincare strategies, the science of facial aging, and cosmetic-intervention guidance | Tanuj Nakra, M.D. & Suzan Obagi, M.D.

1x15s30s

0:002:57:05

## We discuss:

- Tanuj’s and Suzan’s training and expertise, and the evolving field of aesthetic medicine [4:00];
- The biology of the aging face [10:45];
- Why facial fat atrophies with age while body fat tends to accumulate [17:00];
- How chronic stress accelerates facial aging [20:30];
- The evolutionary biology of beauty, and how modern lifestyle, culture, and medicine interact with these ancient aesthetic instincts [25:30];
- How social media and influencers have rapidly shifted aesthetic trends toward exaggerated features and unrealistic beauty standards [36:45];
- The ethical challenges, financial incentives, and social pressures shaping modern aesthetic medicine [42:00];
- The concerning trend of teenagers seeking cosmetic enhancements: the ethical and cultural impact of early beauty pressure [51:45];
- Protecting the skin: UV damage and sunscreen recommendations [58:15];
- Strategies for minimizing skin aging: retinoids, vitamin C, and evidence-based application methods [1:09:00];
- Effective daily skincare routine: cleansing, antioxidants, retinoids, moisturization, and more [1:18:45];
- The playbook for managing acne [1:31:00];
- The 4 changes of aging and the complexities of aesthetic consultations including the anatomical, psychological, and ethical factors physicians must navigate [1:39:00];
- The 5 R’s of rejuvenation [1:50:15];
- A facial aging analysis and cosmetic strategy using Peter’s face as a real-time case study [1:53:00];
- The decision-making process between fat grafting and dermal fillers for facial rejuvenation [1:56:30];
- How self-image, eye aesthetics, and fleeting photos drive the desire for cosmetic enhancement [2:01:45];
- Advice for wrinkles, causes of dark circles under the eyes, and the importance of facial symmetry [2:05:45];
- Considerations that shape clinical decision making around fat grafting and other procedures to address the eye area [2:11:00];
- The evolution of facial cosmetic surgery techniques, the serious risks involved, and how physician skill and procedure selection greatly impact outcomes [2:21:30];
- How patients can make informed and safe choices when selecting a cosmetic surgeon [2:27:15];
- A comparison of ablative versus non-ablative skin resurfacing treatments, laser vs. peels, and more [2:38:45];
- How treatments are chosen and customized based on patient-specific factors [2:48:00];
- The lifelong human desire to align physical appearance with self-identity [2:52:45]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Tanuj Nakra and Dr. Suzan Obagi are two highly respected physicians in aesthetic medicine
  - Tanuj is triple board-certified in facial and ophthalmic plastic surgery, faculty at the Dell Medical School, and the Director of the Cosmetic Surgery Fellowship at TOC Eye and Face Institute in Austin
  - Suzan is double board-certified in dermatology and cosmetic surgery, she is an Associate Professor at the University of Pittsburgh, and the Director UPMC Cosmetic Surgery and Skin Health Center, where she leads advancements in cosmetic and laser surgery on a global health scale

In this episode we talk about:

- The biology of facial aging
- How hormonal changes impact facial bone structure and skin integrity, and the critical role that hormone replacement therapy (HRT) plays in a youthful appearance
- What makes a face attractive from an evolutionary perspective, and a psychological perspective, and how modern media and social media filters are warping and distorting those standards
- The troubling rise in cosmetic procedures among teenagers, and how physicians can navigate difficult decisions around these things

Then we really get to the substance of this podcast:

- We talk through a practical and science-backed approach to skin health
- Including, the essentials: sunscreen, retinoids, vitamin C, and many more things
- Why mineral sunscreens are likely superior to chemical or organic sunscreens
- How to use retinoids correctly based on skin type and sensitivity
- What a personalized morning and evening skincare routine should look like
  - Including cleanser type and application order
- The medical management of acne, especially cystic acne
- The psychology behind aesthetic consultations; and why trust, motivation, and emotional readiness are critical before undertaking procedures

Finally and most importantly, at the end of this podcast, we turn the tables and Peter is the patient:

- Peter is sitting across from them and he’s asking them to be as brutal as they need to be and offer an assessment of what would truly be possible if someone in his shoes wanted to take all the steps of aesthetic medicine and apply them to their own appearance from the neck up
- This was the most illuminating discussion
- While Peter realizes that listening to it might sound like they’re being overly harsh and critical, but you have to understand that this is exactly what Peter wanted
  - He wanted to understand these things
  - He came away from this realizing there was more “wrong” with his face than he ever imagined
- Will Peter do anything about it?
  - Truthfully, beyond the new skin regiment he has adopted, probably nothing
- Nevertheless, he was intrigued by this and thinks many of you who have been thinking about these things will come away deciding
  - Either there are things you want to do from an aesthetic standpoint
  - Or at a minimum, just taking care of your skin might be the right thing to do, and clearly, you’ll come away from this with a great regiment to do this

## Tanuj’s and Suzan’s training and expertise, and the evolving field of aesthetic medicine [4:00]

- This is a topic that Peter gets asked a lot about and one that he knows even less than the general public about
- It’s super helpful to have not one but two experts on this topic because they each have a different specialty

**Tell us a little bit about your training, your background, and what you focus on**

*Dr. Tanuj Nakra*

- Tanuj’s core specialty is oculofacial plastic surgery
- He trained mostly  at UCLA in eye surgery and in facial surgery
  - His original background is ophthalmology
  - Then he did fellowships in ophthalmic plastic surgery and another fellowship in facial cosmetic surgery
- His practice is limited to eye and face plastic surgery
  - That ranges from reconstruction of children, cancer reconstruction for elderly, and all the cosmetic surgeries that we can perform on the face
  - This includes the nose and neck
- Tanuj moved to Austin 16 years ago after training at UCLA and joined a large group here [[TOC Eye and Face](https://toceyeandface.com/physician/dr-tanuj-nakra/)], and he is also faculty of the [Dell Medical School](https://dellmed.utexas.edu/directory/tanuj-nakra)
- He is actively involved with academics, teaching, and residents
  - The practice has two [fellowship programs](https://toceyeandface.com/fellowship-programs/)

> “*It’s a real pleasure to be involved in academics because it’s the cutting edge of science, and we like to perform clinical research and in the academic community (which is how I know Suzan) there’s a lot of collaboration amongst specialties, and we have an opportunity to dialogue and further the specialty that we care so much about*.”‒ Tanuj Nakra

*Dr. Suzan Obagi*

- Suzan is a dermatologist by training, she did a fellowship in cosmetic surgery
- She is in academic medicine at the [University of Pittsburgh](http://dermatology.pitt.edu/people/suzan-obagi-md)
- She’s been there about 24 years ‒ she’s gotten to see the evolution of this entire field
  - They used to do surgeries and a few collagen injections
  - Now they have a plethora of tools at their disposal
- She trains residents, medical students, and visiting physicians from all over the world
- She loves the multi-specialty collaboration
- Both guests belong to the [American Academy of Cosmetic Surgery](https://www.cosmeticsurgery.org/), and they have a different approach from different specialists, sometimes even on the same procedure
- Suzan’s practice focuses on everything with regards to skin rejuvenation, peels, lasers
  - She does a lot of fat grafting
  - She does body liposuction, mini face lifts, eye lifts

> “*Everything when it comes to the face is about really enhancing the appearance of the skin first, because my feeling is that’s the most important thing that everyone sees*.”‒ Suzan Obagi

- When a patient comes in who has not had anything done or doesn’t know about the field, Suzan actually likes that because she can take that opportunity to really educate them and pick the right things for them

Peter jokes, “*I appreciate you noticing I’ve had nothing done.*”

**Before the podcast, they were discussing the strategy Peter has taken towards his appearance**

- There is something about this field of medicine that Peter has such a block in his brain to understanding
- He has met Tanuj before: Tanuj helped him with a scar
  - Peter’s friend [Brett Kotlus](https://www.drkotlus.com/about/) [guest on [episode #13](https://peterattiamd.com/brettkotlus/)] introduced them
  - Peter face planted one morning due to some hypotension and sustained a pretty nice scar that for the most part is largely invisible today (probably in part because his face is leather to begin with)
  - In part that’s because he did some [5-FU](https://dermnetnz.org/topics/5-fluorouracil-cream) [microabrasion](https://en.wikipedia.org/wiki/Dermabrasion) along with a whole bunch of stuff, and Peter was actually pretty diligent about staying out of the sun for the period of time afterwards
  - He’s also done a [Botox](https://en.wikipedia.org/wiki/Botulinum_toxin#Cosmetic_uses) treatment, which certainly reduced the wrinkles (obviously it’s long gone)
- Peter has taken a strategy towards his appearance that is probably illogical: he ignores it because he doesn’t understand it
  - He focuses on things he understands

Peter adds, “*I would view it as an enormous win of this podcast if in a few hours, I decided to do something that was sustainable and going to help me look a little better at 62 than I should look. (I’m 52 today).*”

- Peter looked at a picture of himself 10 years ago before this podcast, and what a difference 10 years has made
  - He looks so much worse today
  - That’s probably not uncommon and would guess that 42 to 52 is a big reduction in appearance
- It made him realize that the reduction in the next 10 years will be greater if he doesn’t do something proactive
- Peter admits, “*I can’t even bring myself to wash my face before bed.*”
  - Which his wife finds disgusting
- Tanuj and Suzan have their work cut out for them because if Peter can be educated on this, they can change the world

## The biology of the aging face [10:45]

- We’re going to limit our discussion to the neck up

**Why did Peter look better at 42 than 52?**

- That’s exactly how Suzan’s patients come in; they say, “*I feel like I look tired. I don’t know exactly what’s going on…*”
- She uses diagrams of the face of someone who’s 20 and someone who’s in their late 60s to explain the changes
- If you look at a diagram of the face with the skin peeled off, you’ll see about 11 different fat compartments in the youthful face [shown in the figure below]
  - On each side of the face that are plump, they’re robust, they’re giving volume, and they’re giving a padding between the skin and the muscle and the underlying bones

![](https://peterattiamd.com/wp-content/uploads/2025/06/f1-tanujandsuzan-1024x758.png)

**Figure 1. Superficial fat compartments of the face**. Image credit: [MAIPS](https://www.maips.com/facial_volume_loss_aging.html)

- Then you look at someone who’s in their late 60s, and you peel the skin away, and you see a dramatic atrophy in all those fat pads
  - A few might increase in size, but the vast majority undergo atrophy
  - [the figure below depicts changes in facial fat that occurs from age 35-55]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f2-tanujandsuzan-1024x421.png)

**Figure 2. Atrophy of facial fat that occurs with aging**. Image credit: [Dr. Gail Humble](https://drgailhumble.com/882/)

- Suzan also shows what the bones are doing at that age too [one representation is shown in the figure below]
- We look at the bony vault of a 20-year-old:
  - The opening around the eyes are nice and tight
  - The cheekbones are nice and wide
  - The jawline has a really good definition
- Then you look at someone who’s in their 60s, and all of the sudden:
  - The opening around the eyes are wider
  - The cheekbones are less wide
  - The jawbone is less wide, less height

***So now you’ve got that scaffolding that’s diminished, and all the skin looks like it’s just hanging*** Suzan explains, “*It starts early… the first change is around the eyes… basically, what’s happening is you’re getting more bone loss around the eyes, more fat atrophy around the eyes, so you’re starting to see the underlying anatomy (which was padded before).*”

![](https://peterattiamd.com/wp-content/uploads/2025/06/f3-tanujandsuzan-1024x656.webp)

**Figure 3. Bone loss that occurs with aging**. Image credit: [Sparrow, MD](https://sparrowmd.ca/facial-aging/)

Peter’s reaction, “*This is completely news to me.*”

**Is this loss of bone comparable to what we would see in the reduction of bone density in a person’s hips as they age?**

- A lot of it is hormonal, especially in women
- They’ll start to identify aging changes in their early 40s

*Is this another reason why women would benefit from hormone replacement therapy because maintaining estrogen levels would maintain bone health?*

- Absolutely
- And that’s something we need to stress more and more because it probably starts in the early 40s, and then it just accentuates over time

**If you compare a group of 50 year old women to guys who are 50**

- The men are holding up pretty good
  - Their facial bone structure is good, their fat volume’s good, their muscle thickness and skin thickness is good
- Women from 50 to 60 or 70 will age about 20 years faster than men, in the lower face especially
  - They will get so much atrophy in the [mandible](https://en.wikipedia.org/wiki/Mandible), and that’s why women start to say, “*I hate my neck. I hate the loose skin in my neck.*”

**⇒** Because if the mandible’s retracting, the skin on the neck becomes looser

*Peter finds this remarkable because Suzan is bringing it back to the one thing he knows about bone*

- When you look at men and women aging from a skeletal system, they’re both going through a comparable decline starting in their 20s
  - Both men and women peak in the early 20s
- But at about 50, women fall off a cliff, whereas men just continue a linear decline, and so the gap really widens
- It’s interesting to realize that the exact same thing is happening in the face

*When women come in and say, “I hate my neck.”*

- Suzan thinks we jump to try to surgically correct it or to augment it with fillers or neuromodulators to keep the muscle from pulling down

***Instead, we have to have a talk about hormone replacement ‒ you have to catch those women before they’re far along into menopause***

> “*Again, I’m blown away by that fact*.”‒ Peter Attia

**Tanuj doesn’t know if people realize how much science there is about the aging process**

*Changes in bone that occur with aging*

- There were some [seminal studies](https://pubmed.ncbi.nlm.nih.gov/18176221/) by Rohrich and Pessa in the ’90s and 2000s that delineated a lot of what Suzan’s talking about, where they looked at CT scans of the same individual over time
  - Some of those studies had a 15 to 20 year span, and there was quantitative calculations of bone density and bone projection of the [mandible](https://pubmed.ncbi.nlm.nih.gov/18176221/), the [maxilla](https://pubmed.ncbi.nlm.nih.gov/9655429/), the frontal bone

**⇒** These bone structures all recede with aging, and the bone is the foundation for the face

***When we’re talking about youthful fullness of a face, a lot of that is the bone structure***

*Changes in fat compartments that occur with aging*

- Fat compartments are a critical component of our facial aesthetics

**⇒** The reason why people start to look more skeletal as we age is we lose all that volume

- One of the most common areas that Tanuj sees in his practice is people talking about their under-eye bags and their lines that are showing up in their eyelids, in their cheek area
- It’s because we have ligaments that attach the skin down to the bone [shown in the figure below]
  - It’s called the [osteocutaneous ligamentous network of the face](https://www.liebertpub.com/doi/10.1001/archfaci.2011.1533#:~:text=Those%20fibrous%20bands%20that%20originate,%2C%20buccomaxillary%2C%20and%20mandibular%20ligaments.)
- Those ligaments are the same for every single individual, no matter what your ethnicity is
  - Of course, there’s variations on the theme
  - It’s the orbital retaining ligament, the malar ligament, the temporal ligament, the mandibular ligament, the masseter ligament

![](https://peterattiamd.com/wp-content/uploads/2025/06/f4-tanujandsuzan-1024x957.png)

**Figure 4. Ligaments of the face**. Image credit: [*Aesthetic Surgery Journal* 2013](https://pubmed.ncbi.nlm.nih.gov/23855010/)

Tanuj explains, **“*****As we lose that facial volume from fat atrophy and the bones move backwards, these ligaments are tugging on the skin, and these deep lines start to show up… that’s one of the fundamental changes we see with aging of the face.*****”**

## Why facial fat atrophies with age while body fat tends to accumulate [17:00]

**10 years ago, Peter was less fat than he is today. Why is he losing fat in his face?**

- He is the same body weight as he was 10 years ago, but would bet his body fat was 2-3% lower

*What is it about facial subcutaneous fat depots that atrophies when for virtually every other person they’re adding adipose tissue subcutaneously and often viscerally?*

- Suzan talks to a lot of her patients about that; they’ll come in in their late 30s, early 40s
- The vast majority of her patients are female
- She can guess how many kids they’ve had
  - Because what happens is, you gain weight in pregnancy (it doesn’t have to even be a lot)
  - Then most people (if they’re fit), they lose that post pregnancy weight, and they go back to the same weight they were before they got pregnant, but their face is thinner
  - More so with the second baby
  - By the third baby, the weight gain, weight loss takes a significant toll on the face

The facial fat pads are very unique metabolically

- Most of the time they’re just atrophying as we age
- There are a couple of compartments that might, in time, get thicker such as the nasolabial fat compartment
  - Which is why some people have that deep fold
- But for the most part they atrophy

Suzan explains, **“*****If you go this yo-yo change with your weight, and you’re progressively getting thinner and then gaining some weight back, it doesn’t go to the face. It goes to parts of the body we don’t want, but the face continues to undergo that weight loss or the volume atrophy***.**”**

*Do we know biologically what is happening?*

- Peter thinks it’s almost like a lipodystrophy where the fat cell becomes defective and can’t reaccumulate triglyceride or whatever form it’s going to store it in
- Like so many things in medicine, there are things that we know and a lot that we don’t know
- We’re just starting to understand the individual receptors and specific nature of different areas of fat
- For example, even in the eyelid region, when we’re doing surgery on the upper eyelid, we will see that the fat pads have different colors
  - The medial orbital fat pad is substantially lighter compared to the much yellower and more orange lateral fat pad
  - And that color will be different than the buccal fat pad
- There’s beta-carotene differences in the fat pads, and that’s probably just one of maybe a hundred differences that we will eventually find out is contributing to the differences in the fat population

***We know that facial fat is different from abdominal fat, which is different from lower extremity fat***

- And we know this also, practically speaking, because when we’re doing fat grafting procedures, the source of the fat can have a different long-term effect when it’s ejected into the face depending on what the source was
- We know that fat is not the same throughout the body and it’s not the same in the face

## How chronic stress accelerates facial aging [20:30]

**The impact of inflammation and stress on facial skin and fat**

**⇒** There is a general consensus that beta-carotene is an anti-inflammatory mediator

- Higher concentrations and lower concentrations of beta-carotene can have some effect on the metabolic health of fat, especially how it responds to stress
- In the world of longevity, there’s a lot of discussions about managing cortisol levels
  - Sleep is helpful, having lifestyles that reduce your overall stress level is good for your overall health in numerous ways
- That’s also true for the fat and the skin of the face because again, a lot of this is not fully explained, but we’re starting to get more and more details as basic science progresses in this area

***These fat compartments in the skin are exquisitely sensitive to stress that the body is experiencing cumulatively over time***

- A lot of times people feel like they’re really aging in their 40s, people have midlife crises, and they’re probably experiencing the maximum stress in their life at that stage
  - Tanuj is generalizing here, but people will have a busy career, they’ve got kids, they’ve got financial worries, and so people are under a lot of stress in their 30s and 40s
  - And that contributes to some of the more rapid facial volume loss changes, some of the skin aging changes with elasticity, collagen elastin changes that occur over time
- That’s where Tanuj thinks this conversation really plugs in quite well into the line of education that Peter is providing in terms of longevity benefits because it overlaps here with cortisol stress and inflammation

**The effect of cortisol on fat in the face**

- Peter points out that chronic elevation of cortisol in the body is actually anabolic to fat
- You accumulate fat, it’s catabolic to muscle → muscle decays, fat accumulates

Peter asks, “*It sounds like you’re saying, ‘Okay, that’s true from the neck down, but above the neck, chronic elevation of cortisol might have the opposite effect. It might actually be catabolic to fat and therefore it accentuates the fat loss.’ Am I hearing you correctly in that?*”

- Tanuj believes that’s correct

*A perfect example of this, just yesterday in Tanuj’s clinic he saw 2 patients back-to-back*

- One was 68-year-old woman who has lived a very comfortable life
  - She comes from affluence, hasn’t really had to work too hard in her life, and has maintained things
  - She uses skincare products, and she’s had a little bit of fillers and Botox, but no surgery
  - She looks 10 years younger than her stated age because of the kind of life she’s been living
- The next patient he saw was from rural Texas
  - She has been in the sun, doesn’t take care of her skin
  - She worked a blue collar job, had a difficult life, a couple failed marriages
  - She looked like she was 10 years older

***Lifestyle stress factors clearly have an effect***

**The quality of science and aesthetics has historically been pretty poor**

- Another reason why it becomes very murky to sort through the science is because a lot of the individuals, corporations, forces that are delivering science to the masses and to physicians (who are eating it up and regurgitating it to their patients)

***These sources are questionable***

- They’re profiting, as you I’m sure realize, the aesthetic industry is a very, very lucrative industry worldwide, especially in the United States
- There’s a lot of forces where those that are delivering the science have a vested interest in receiving monetary benefit from what they’re pushing out
- And that makes things murky

**The function of fat compartments in the face**

- Fat compartments in the face allow the muscle to glide and move each other as you smile, talk, chew, all of that
- Suzan doesn’t understand why they should undergo such atrophy over time for such an important function
- When we look at the metabolic activity of the fat in other areas of the body, it’s very different
- When we do [fat grafting](https://en.wikipedia.org/wiki/Fat_transfer), for example, and we take fat from the abdomen, which has the highest concentration of stem cells (preadipocytes) and put them in the face ‒ the fat starts to behave more like the fat from the abdomen when you put it in the face
- And you have to tell patients don’t try to gain more than a few pounds because it will undergo hypertrophy like it would in the abdomen if they gained weight

## The evolutionary biology of beauty, and how modern lifestyle, culture, and medicine interact with these ancient aesthetic instincts [25:30]

**Is there an evolutionary explanation for any of this?**

- Historically we didn’t need to look good beyond our 20’s, if purpose of looking good was to attract a mate
  - Peter adds, “*None of us sitting around this table need to look good in Darwinian terms because we’re not reproducing*.”
- Tanuj thinks that factors into this 100%
- The evolutionary aspects of beauty could be a whole separate podcast
- [Nancy Etcoff](https://college.harvard.edu/academics/faculty/nancy-etcoff) from Harvard wrote the definitive book [[*Survival of the Prettiest*](https://www.amazon.com/Survival-Prettiest-Nancy-Etcoff/dp/0385478542/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.f2Og853JTwZzlHn3ejMLuKlWF43Erqnhjr9it0KzNxM3XTaccr3HujfYuSStcg6csqsPheK9pNPivh347EPWQkZIokx0ZNsYW872nWU44oeznIMTCw45nUn2PK0R5_IB.ScvcORVP8NPkBYyNZIs9y8u56HTkL6Z-LNzmUr77RDE&qid=1747401045&sr=8-1)] on the psychology of beauty and it summarizes all of the evolutionary beauty science
  - Tanuj has all of his fellows read  her book because it’s a beautiful compendium

> “*The interesting fact is that we’re actually genetically hardwired to appreciate beauty*.”‒ Tanuj Nakra

**There’s a famous** [**study**](https://sites.pitt.edu/~strauss/rubenstein1999.pdf) **from the University of Texas in the 1980s by** [**Judith Langlois**](https://liberalarts.utexas.edu/psychology/faculty/jhl73)

- She did what’s called a preferential looking study of infants
  - She took newborn infants who were literally weeks old, barely able to see 6 inches away from their face
  - She showed them pictures that are considered beautiful, faces that are beautiful, and faces that are less beautiful
  - And these newborn infants who’ve not yet been influenced by society, preferentially we’re looking at the beautiful faces

***That natural drive for us to appreciate beauty is present even at birth***

*Does that suggest that there is a definition of beauty that arcs time?*

Peter asks, “*How much is the definition of beauty changing? In other words, if you took Matthew McConaughey and transported him back 10,000 years ago, would he still be a hunk?*”

- Tanuj would say that the answer is generally yes
- There’s two layers here
- The first layer is the genetic biologic drive that we have to appreciate beauty in men and women
- Then, of course, there is a societal impact that conditions us to appreciate certain versions of that beauty
- The fundamentals have been studied in the ’90s

The fundamentals are that all humans across ethnicities all over the world have been studied, and they appreciate certain features of beauty

- There are 3 categories:
  - There’s symmetry of the face
  - Facial proportion
  - They also appreciate sexual dimorphisms
- 1 – When a face is symmetric it means that this individual most likely has had good development and nourishment and is most likely going to have good genetics for to potentially connect with and pass on
- 2 – Facial proportion is similar, but averageness is really what people are looking for
  - On the surface, that doesn’t sound so attractive to be average, but if you take 100 faces of men, 100 faces of women, and average them all down to a single composite, you will average someone who has a little bit of a big nose or a small jaw or some aspect of their forehead shape
  - And all that gets averaged down into a composite that is considered universally beautiful across cultures

***From an evolutionary standpoint, that is connoting healthy genetics to be able to pass on your genetics with***

- 3 – Sexual dimorphism tend to connotate either higher estrogen levels or higher testosterone levels depending on whether you’re looking at women or men
  - In women: full lips or big eyes
  - In men: strong jaws

***That’s a subconscious communication of fertility***

- On top of that, as you’re bringing up social media in this culture, this particular way of wearing your hair is considered beautiful
  - Those are conditioned upon us based on society
  - But it overlaps on top of that underlying genetic basis that we all have

**How much can those things override?**

- Peter was talking with his daughter about Cindy Crawford ‒ look at a picture of Cindy in the mid-1990s and today, and there’s simply no way to describe beauty in any other way [shown below]
  - It doesn’t matter what your type is, everybody would acknowledge Cindy is absurdly beautiful

![](https://peterattiamd.com/wp-content/uploads/2025/06/f5-tanujandsuzan-1024x927.png)

**Figure 5. Pictures of Cindy Crawford in the mid-1990s and 2024**. Image credit: [People](https://people.com/style/cindy-crawford-throwback-photos-1990s/) and [Vogue](https://www.vogue.com/article/cindy-crawford-summer-dress-chic-and-affordable)

Peter’s takeaway, “*So you’re saying she is hitting it out of the park on those three things, independent of what the in-vogue look of the moment is*.”

**⇒** Suzan adds that if you look at beautiful people in different races, they all have similar measurements

- There are these masks that you can superimpose onto any image and really dissect down every single angle, whether it’s the cheek angle, the jawline angle, the shape of the nose, the eyes
- If you look at that across different races, they all have that same kind of measurement that they hit talking about the symmetry, the upper third, the middle third, lower third, the face, the fifths going across the face
- Now, then there are nuances, like you said, you change your hair, you change your makeup, you can transform yourself
- But if you take someone without makeup and just look at them that way, they all kind of conform to those measurements

**Doesn’t this imply that over time, beauty should be one of the most preserved concentrated traits of our evolution, given presumably the difficulty in acquiring a mate absent beauty?**

*Does it suggest that if you compared what we as a population looked like today in 2025 to what we looked like 2000 years ago, 10,000 years ago, 100,000 ago, are we monotonically getting more attractive as a species?*

- You would think so
- The selection should be ramping up
- We should be marrying or mating with someone that looks better and having our progeny look better

**What’s different is our diet**

- Back 100, 200, 1,000 years ‒ we had to chew a lot more to digest our food
- Our Palates were not as high
- Our jawline was a lot wider
- Our teeth were a lot stronger
- As we changed our diet and everything is cooked, we don’t have to make as much effort to chew our food:
  - You get more crowding in your teeth
  - Your jawline is a little bit less strong
  - Your palate changes
  - More people become mouth breathers as opposed to nose breathers

***That changes the shape of your face has been measured anthropologically***

- There’s a whole book on breath, and they go through the anthropology of all of that and the changes in the skeletons that they’ve gone back and studied
- Now we have kids that have to have teeth extracted, or we have to have palate expanders now because we realize, when we extracted teeth before, we made the faces more narrow
- And so now, the thinking is let’s preserve the teeth, expand the palate when the child is 10, allow those teeth to come in so there’s less crowding, and then that face will be better and a stronger jawline
  - That is something that we’ve changed

**Tanuj takes this to the area of sociology**

- 10,000 years ago, the genetic pool you’d be interacting with was tiny
- Somewhere around 1900, most people on this planet had not moved within 10 miles of where they were born
- Now, it’s totally different
- And with social media and the way that we can connect with people around the world, not only because we can fly all around the world, but we’re also seeing people on screens, the apparent genetic pool of faces that we’re looking at has exponentially blown up into this very strange world that we’re living in in 2025 compared to where our evolutionary biology has taken us

**Peter wonders at what point in our development did other things become a priority in finding a mate**

- For all of them, when they were looking for a mate, appearance was probably not at the top of the list
  - It was one factor
- But the main question was “*Will this person be a great spouse? Will this person be a great parent? Does this person share my goals and values?*”
- It’s hard to imagine our ancestors had the luxury of thinking about those things

***All of this is to say, it’s way more complex today***

- It’s fascinating to play the thought experiment of: transport a hyper attractive person today, back in time 10,000 years
  - Peter would be so curious as to how they would react to that individual
  - Tanuj thinks if they meet the criteria they’re defining, they would be considered a hunk or a beauty

**In terms of timing, it’s important for us to be evolutionarily attractive historically (not in the modern era) until age 20 or 25**

- Because we weren’t supposed to live this long

> “*One of the issues that comes up with longevity and trying to maximize our health span is that we were not really supposed to be living this long and healthy this long. And so evolutionarily, mother nature’s not helping us with our appearance*.”‒ Tanuj Nakra

- Our appearance was supposed to carry us through until about 20 or 25, at which point most people were procreating at 14
- Then at 25, their kids were at the point where they were getting ready to procreate and then let out to pasture at that point, basically

***Evolutionarily, what we do every day with our patients is we’re really fighting biology, we’re fighting genetics; we’re fighting unnatural existence that we have as a luxury of being born in this era***

## How social media and influencers have rapidly shifted aesthetic trends toward exaggerated features and unrealistic beauty standards [36:45]

**Speak about this through the length of your careers: how much do you see trends that dramatically change what people are asking for?**

*Suzan, 25 years ago, did men or women come into your practice significantly looking for something different in terms of an appearance and an outcome that they wanted you to shape?*

- That’s such a loaded question because 25 years ago, there was no social media
  - Television was very basic
  - Maybe there were some shows that had live people on where they would talk about beauty or fashion, but you had to actually tune in to be able to see the trends
  - Magazines came out, and that was the extent of it
- Now, you have social media and various channels on social media
- Influencers are changing what our patients are seeing and what’s driving them
  - The biggest one that Suzan can talk about is that very well-known family in California that has monetized their appearance and set a lot of trends for better or for worse

***It’s great to see that they’re making it okay to talk about enhancing your appearance or fixing something that bothers you***

Where Suzan draws the line is when they start putting out their transformations

- This trend now is something that everyone wants to emulate
- You’re talking about young women physically changing their body drastically to conform to a trend
- And trends as the word says, are not permanent
- So what happens when that trend ends?
- The celebrities have the money to go to the doctors and reverse all that
  - It will take surgery and they will have scars to show for it or hide from that
- But the patients that follow them, these young women don’t have all of that income to go back and then re-transform their body, and they don’t know the implications of that

***We have a duty, as doctors definitely, to try to educate our patients about not following trends so strongly and look beyond the monetary aspect of it***

> “*I try to really educate my patients to stay away from things that are trending and really do things that make them look and feel better, but natural for themselves*.”‒ Suzan Obagi

- Suzan sees people who want to come in for the enhanced buttocks (Brazilian butt lifts) and the small waist
- That’s something, again, that’s being undone by that family now, and you’re going to see a whole trend that’s coming out that doesn’t look like that

*What are the top above-the-neck trends?*

- Tanuj sees today as an unusual era where influencers that are affecting society are much more in our faces than they have been historically
- Their influence is quite powerful

***People are primarily exposed to influencers on social media and many of the images being posted are not real***

- They’re filtered, they’re unrealistic exaggerations of some of those 3 original factors discussed earlier: the symmetry, proportion
- People will photograph themselves in such a way where they look more proportionate
  - They will pull their jaw in a certain way to make their proportions look better

Peter adds, “*Someone has to teach me how to do this because anytime I see a video of myself, I’m like, that is the worst looking thing I’ve ever seen. I need to learn these tricks.*”

- A lot of this is subconscious posing
  - A lot of people when they walk past a shiny building will stop and look at themselves and kind of adjust themselves a little bit

**⇒** It’s becoming so much more exaggerated now to the point where we can confidently state that social media influencers are selling exaggerated forms of beauty ideals

***Trends exaggerate the sexual dimorphism we talked earlier about: larger lips or bigger eyes***

**What are the top above-the-neck trends?**

- For example, Peter sees **lip size** as something that’s getting bigger, smaller, bigger, smaller
- One of the most popular procedures in Northeast Asia is surgeries to **make the eyes wider**
  - You actually cut into the [canthus](https://en.wikipedia.org/wiki/Canthus) and perform [ptosis](https://my.clevelandclinic.org/health/diseases/14418-ptosis-droopy-eyelid) surgery to make the eye look bigger
- There is a trend to have **bigger lips**
  - Fillers are being used left and right, unfortunately, to overdo lip volume and plump up lips
- Because the social media influencers are posting it, these exaggerated gender traits are becoming normalized
- The family that Suzan mentioned in California, they normalized overdone lips to the point where people come in asking for it and Tanuj has to say, “*No, I’m sorry. This is not a good direction for us to take you in*.”

## The ethical challenges, financial incentives, and social pressures shaping modern aesthetic medicine [42:00]

Peter adds, “*One of the marks of a great surgeon is a person who is happy to say no, is happy to say, ‘I’m not going to do this, because I’m so good that I don’t need your business. I can be as selective as I want about what I do*.’”

- That allows the right patient selection to get a good outcome
- Peter had a discussion with a patient yesterday about an orthopedic surgery issue
  - The doctor said it was time to do the surgery
  - The patient thought the surgeon had a vested interest in doing the surgery
  - But Peter could speak about this surgeon in particular having watched him say no to a hundred patients because ***patient selection is the most important thing for him to drive amazing outcomes***

**Where do you think the field is on this on the whole?**

- Peter notices that Suzan and Tanuj are both at the top of their field
  - They don’t need the incremental patient
  - They’re happy to say no
- It also sounds like there is an ethical reason to say no

*Are you guys the outliers or are you the majority?*

*Is there a handful of bad actors out there that will take any money from any 17-year-old who’s being duped into thinking this is the way they need to look?*

- The vast majority of physicians are ethical
- Suzan thinks there are some out there where something is monetized, so they will mass treat patients
  - Their goal is to have surgery after surgery coming in and basically letting the patients make their own informed decision about it, to an extent
- Suzan looks at it akin to managing hypertension or diabetes
  - We never let the patients determine how much insulin to use or how much antihypertensive medication to take, and she doesn’t think we should let the patients say that they want to transform themselves to some completely different person
- Ethically that’s wrong, and that brings to mind a whole bunch of other psychological issues that might be playing there, including what we call **social media dysmorphism**
  - Where people come in with pictures of themselves with a filter and say, “*Can you make me look like this picture?*”

Peter asks, “*Is that a recognized diagnosis in the DSM-5 now?*”

- Suzan doesn’t know if it’s made it to the DSM
- Tanuj is an optimist, but he thinks the situation is worse
  - There are, unfortunately, financial incentives for physicians, nurses, and the broad spectrum of people that perform aesthetic treatments (including Botox and filler injections)
  - It’s very poorly regulated
  - There are tons of people out there, ranging from hairdressers up to surgeons, who will be happy to take your money and find a place to put the syringe of filler because they know it’s going to be revenue into their practice

Tanuj makes the point, “*I don’t want to be overly negative, but I think this is sort of a cautionary warning to people who are listening to this podcast that, when you’re delving in the area of aesthetic enhancement, you have to understand that there’s an overlay, where the person that you’re seeking out advice from has a substantial financial incentive to treat you*.”

**Peter also cautions patients when they’re seeing a “longevity doc”**

- When you go to see somebody and they’re selling a biologic clock whose treatment is this supplement and they’re monetizing those two things, he doesn’t see how you can trust that individual
  - He doesn’t see how even a person with good intentions can’t get conflicted there

**Back to the aesthetic industry**

- Peter never thought of it until now, but the entire aesthetic industry is effectively that, because you’re not just selling a procedure, you’re often selling a treatment ‒ ***you’re getting paid on both ends***

**Suzan points out that the providers have changed**

- Before, it used to be only dermatologists that would do the injectables
- Then it became dermatologists and plastic surgeons
- Then it became the RNs and the physician assistants
  - And those are still all medical providers, including dentists, who are very well-trained

***In certain states there is a lack of regulation: you’re seeing unqualified people who are not medical providers doing injectables and laser treatments that they may not be trained for***

> “*All of a sudden, you start to open up a whole Pandora’s box of complications there*.”‒ Suzan Obagi

- This is a shame because patients might not know enough to ask about qualifications
- They might see that it’s a nice storefront
  - The person’s wearing a lab coat; they look professional
  - From that standpoint, they might go in trusting that this person has their best interest

***There might not be a physician overseeing everything***

Suzan adds, “*We feel very strongly in our practices that there is a physician overseeing every treatment, whether we’re doing it, our nurses, or our PA’s are doing it.*”

- We’re overseeing all of that to make sure that if there’s a complication, that complication is ours

***No matter what, we’re going to take care of that patient***

- It is a shame, and Suzan warns a lot of young residents coming into the field to enter the field if they truly love the field and are passionate about dermatology, ophthalmology, oculoplastics
  - Because if they’re going into it thinking they’re going to be the next glamorous doctor on social media, then they’re not going to have a lot of treatments that they can offer because, at that point, all these other providers are doing those treatments

***Residents coming into the field are going to have to find a niche to make a name for themselves***

**Do you see a change in residents today?**

- When Peter was in medical school (almost 30 years ago), everybody he knew who ultimately chose plastic surgery ‒ they all had an artistic bent to them
  - He’s not saying they didn’t pick it because it was also a lucrative field, but that wasn’t their primary motivation
  - They were artists, and they really took an interest in the art of this

*Do you see the incoming residents largely of that philosophy where they’re interested in the aesthetic component of it?*

*Or do you see a trend towards, no, this is literally a cash machine and as reimbursements are going lower and lower and lower across the entire field of medicine, it is clearly more attractive to be in specialties where reimbursements either remain very high and or it’s mostly cash?*

- Tanuj takes a more optimistic tone: those coming into residency and fellowships in the world of aesthetics still have that same artistic mindset
- People who are painters or musicians, they have that artistic mind
- It’s something we actually look for in our fellowship when we’re considering candidates, because we know that they have that right brain mentality of being able to handle medical problems
- But the reality is that, as you said, medical reimbursements are going down, the lucrative nature of aesthetics is high and getting higher as time goes by
- Someone can go through all the training and then, when they see the dollars come in the door, they’re just going to want more of that
- It can distort their ethics, and they may not even realize they’re doing it

***Tanuj is not saying that there are physicians out there who are knowingly duping patients into having treatments, but he thinks it just becomes this unconscious drive because of the finances***

**The challenge of finances**

- Suzan highlights challenges: Medicare just got cut again in terms of reimbursements, and that’s sad because in our university practices, there’s a huge push for doctors to see more patients because reimbursement is dropping

**⇒** The only way that the medical centers can compensate is to increase the volume

- Still there’s only so many patients we can see in a day and offer really good care
- Suzan and Tanuj have very unique practices because most of their patients self-pay
  - They have the luxury of time
- We can talk to our patients, get to know them, to the point that a lot of our patients come to us seeking medical advice and opinions on other advice that they’ve gotten from other physicians, and we can help them decipher the facts
- Whereas their other physicians may be fabulous, but they have to see 30-40 people in a day (that’s a shame)

***That volume is burning out a lot of really good physicians who want to give good care but find themselves having to see more and more patients, and only spending 10 minutes with a patient***

Suzan adds, “*For both of us, we entered our field before all of these devices and treatments existed, so I think we did come into it with a passion for what we love.*”

## The concerning trend of teenagers seeking cosmetic enhancements: the ethical and cultural impact of early beauty pressure [51:45]

**What is the most concerning request you are getting from people that you believe is unique to the social media phenomenon?**

- Suzan is seeing a lot more teenagers coming in asking for fillers and neuromodulators in their forehead, fillers in their lips ‒ and that’s sad

Peter asks, “*Would a neuromodulator do anything when you’re at that age anyway?*”

- No, but they’re now being told at even 18, for example, it’s okay to start preventative [Botox](https://en.wikipedia.org/wiki/Botulinum_toxin)
  - You don’t need that until you’re a lot further along in age
  - That’s an abject lie that they’re being told
- Unfortunately, they’re also being made to feel very poorly about the shape of their lips
- They’re being inundated with highly filtered images
  - We know a lot of people who will take in their waist, take in their thighs (change the proportions) and then post that image

*Suzan’s advice to patients about what they see on social media*

- 1 – Images you see on social media are filtered
- 2 – They’re taken at certain camera angles to enhance someone’s appearance
- In her practice, she will never take someone’s photo they took on their phone and try to enhance them to look like their photo
  - What’s happening is you’re going to make them look very different in real life

> “*You’re only going to photograph beautifully if you’re the most symmetric person and that’s why, even the most beautiful model in a photograph, if you look at them in person, they’re very pretty, but you wouldn’t think that they’re supermodels.*”‒ Suzan Obagi

**⇒** Supermodels photograph beautifully because of their symmetry

***For us, with our forward facing cameras that we point at ourselves to take our selfies, they’re going to distort our face***

- If you tilt one way, you elongate the face
- Tilt a different way, you shorten the face
- Patients get hung up on that, and that’s really sad, because in real life they look fabulous

**Is this a 95-5, female-male problem that is arising from social media?**

- Peter’s guess is the male issue is much more on anabolic steroid abuse and things young men are being influenced by
- Tanuj agrees

**What is it that you see, Tanuj, that is most disconcerting?**

- 1 – Because [fillers](https://www.aad.org/public/cosmetic/wrinkles/fillers-faqs) are non-surgical, relatively accessible price points, low risk, and are ubiquitous, you can find a clinic within one mile (if you live in a major city), and overfilling is a serious problem
- Whether it’s the lips or the cheeks, over-volumization has become an epidemic
- It’s a serious problem, not only because it looks exaggerated and distorted and strange, but even when, as a facial surgeon, he goes in to perform surgeries, ***he will find that filler has disrupted normal anatomy decades later***

**⇒** The companies will tell you that filler only lasts one year in the face, and then you have to refill it; that’s definitely not true

- Tanuj has patients coming in who don’t mention that they’ve had fillers in the past, but then in surgery he will see filler in their cheek or in their face because they had it 8 or 10 years ago, and it’s still there
  - It’s stretching the ligaments
  - It’s changing the structure of the tissues
  - It actually makes routine surgical procedures later more challenging

Peter asks, “*Are there biologic features of the individual that would make that more or less true? Are there some people in whom fillers go away after a year, or are you saying that for the most part they last longer?*”

- That’s also another whole complex topic is the metabolism of hyaluronic acid, and some people are higher metabolizers, some are slower metabolizers
- We actually don’t have a good sense of that
  - We have some general concepts, just based on experience, but there’s very little science on that
  - We can’t really predict it
- 2 – From a surgical standpoint, there is a trend right now where people are asking for this high arched brow effect, where it’s hyper-exaggerated
  - The tail of the brow comes up very high
  - It’s called a “snatched look”
- About once every week or two, he’s got someone who seriously wants to have their face distorted with a surgical procedure with me, and he has to say, “*I’m sorry. We’re not going to do that*.”

**Is it safe to say that anyone who walks into a physician’s office to do this needs to be able to be over 18 to provide consent?**

*Or can people younger than 18 do this in less reputable places without parent consent?*

- It should be 18
- It’s like any other medical procedure: you have to be 18 years of age to consent
- There are rare instances where Suzan will treat someone who’s 16 or 17 if the parent is there,
  - For example, a patient has a hump on their nose that they don’t like, but they’re not ready to commit to a rhinoplasty, so she can use fillers in a creative way to help reduce the appearance of that
  - But that’s very far and few in between
  - And the parent is there

*Suzan had an interesting incident with an 18-year-old*

- She had just had a rhinoplasty and was coming to see Suzan for fillers and for neuromodulators
- Suzan asked her, “You’re 18. Is someone here with you, from one of your parents?”
  - And no, nobody was there with her

***The interesting thing is, she is 18, thinking that she’s an adult, but she’s only a junior in high school***

- Suzan was very conflicted and kept referring back to something along the lines of, “*You need to talk to your parents. You need to tell them what we discussed here*.”
- That really bothered Suzan for a long time: this 18-year-old, who’s still in high school, that wants to do things, and she didn’t see a parent there with her

**Peter’s view**: it’s not a huge problem probably across the board that people under 18 are getting treatments, but they’re getting fed all of this societal pressure

- He likes to use the term “beauty pressure” (like peer pressure)

> “*It’s beauty pressure that’s now more extreme because of social media. They’re getting all this beauty pressure at a very young age, 12, 13, onwards.*”‒ Peter Attia

- And so, by the time they get into their twenties, they’ve been thinking about this for years and years and years, and they’re ready to dive into it
- There’s probably not a lot of people in this audience that are particularly young, but maybe we can discuss it through the lens of preventative care

## Protecting the skin: UV damage and sunscreen recommendations [58:15]

- Maybe we can start the discussion through the lens of preventive care, so we can talk about preventive care and then move into maybe where Peter is now, where he missed the boat on pure prevention, and he now needs to start being active

**Preventative care for the person who’s listening to this, who’s still in their prime from an aesthetic perspective (in their 20s maybe even 30s)**

- The only thing Peter knows is wearing sunscreen is a net positive
  - He understands enough to say that UV damages skin

**What is it that the sun is doing that is damaging?**

*Is it damaging* [*elastin*](https://en.wikipedia.org/wiki/Elastin)*? Is it damaging* [*collagen*](https://en.wikipedia.org/wiki/Collagen)*? Or is it purely just these* [*sunspots*](https://en.wikipedia.org/wiki/Liver_spot) *that it creates?*

**⇒** The absolute minimum someone should use on their skin every day is sunscreen

- A [RCT](https://pubmed.ncbi.nlm.nih.gov/23732711/) out of Australia followed people for 4 years, and either they wore sunscreen or they didn’t

***The people who wore sunscreen every day aged better and had fewer lines, fewer wrinkles***

- And that’s in a country that has a lot of sun, so that shows you the power of using sunscreen
- Suzan takes it a step further and tells patients to use **mineral sunscreens** as opposed to chemical sunscreens because she’s not convinced of the safety of [avobenzone](https://en.wikipedia.org/wiki/Avobenzone), [oxybenzone](https://en.wikipedia.org/wiki/Oxybenzone), as hormone disruptors
  - There are some scientific studies that suggest maybe they play a role in infertility
  - You can measure them in the bloodstream
- The skin is a great portal for chemicals to enter into the bloodstream if it’s the right size chemical
  - Especially if you’re putting them over the entire body
- There have been studies done that show a huge spike in the amount of these in your bloodstream after application

Suzan adds, “*After saying this for 15 years, I think the FDA, just a couple weeks ago, finally told the companies they must do animal safety studies. It’s about time.*”

- Tanuj points out another problem with chemical sunscreens: patients think they’re covered, and then the chemicals that are actually protecting against the UV damage become inactivated over time
  - If the sun is strong, it’s going to be deactivated within an hour
  - People will burn using SPF 70, SPF 100

**⇒** There should be nothing above a SPF 50 mineral [sunscreen]

**What is the use case for the chemical sunscreen?**

*Are they less expensive? What was the rationale for them?*

- They blend in very easily
- People love it because there’s no white film when they put it on
- A mineral sunscreen takes a little bit more work to blend it in
- Or it’s going to cost more because you’re going to have to get a micronized formula of [zinc oxide](https://en.wikipedia.org/wiki/Zinc_oxide#Sunscreen) or [titanium oxide](https://en.wikipedia.org/wiki/Titanium_dioxide#Sunscreen_and_UV_blocking_pigments)
- Peter uses [EltaMD](https://eltamd.com/collections/sun-care) in SPF 30 or SPF 50, and you have to work to pot it on
  - Elta makes some mineral and some chemical ones, so just double check
- Tanu adds that companies make it confusing on purpose ‒ you have to go out of your way to find formulas that are primarily mineral
  - Because the companies want to sell you both products
  - And they know customer satisfaction is higher with chemical sunscreens

**⇒** Both Tanuj and Suzan have created skincare lines of products [[AVYA Skincare](https://www.avyaskincare.com/pages/the-founders), [SUZANOBAGIMD™](https://www.obagi.com/collections/suzanobagimd-skin-care), and [Veea Face](https://veeaface.com/collections/dr-suzan-obagis-essentials)]

- They have really dived into this world of skincare

***The marketing of skincare can really mislead consumers***

- Companies that are creating skincare are motivated by sales
  - When it’s a chemical sunscreen, they’re going to be happier with it, because it doesn’t have that white, pasty effect, but it’s just not as effective

**Skin cancer in the US is increasing**

- This includes [melanoma](https://en.wikipedia.org/wiki/Melanoma)

Suzan asks, “*Why do we have generations now of people from the late ’90s on up who say they use sunscreen all the time, and our skin cancer rates are going up?*”

- It’s two-fold
- 1 – The sunscreens degrade very quickly when they put on a chemical sunscreen
- 2 – Suzan takes it one step further: when those chemical sunscreens absorb harmful rays (whether it’s UVB or UVA), the chemicals absorb them and they neutralize those rays, but they cause [reactive oxygen species](https://en.wikipedia.org/wiki/Reactive_oxygen_species), and those reactive oxygen species damage the DNA of the cells, which then accentuates the damage that you’re getting from whatever other UVA gets through the sunscreen
- So you’re really causing more damage and probably causing these cells to become more atypical over time

*Peter points out that there is a group of people who argue that the sun and UV rays have no causal role in melanoma*

- He doesn’t agree with this at all
- The argument they put forth is sunscreen use has been increasing, and yet we see a significant increase in the incidence of melanoma
- So, they’re pointing at the same observation; they’re offering a different argument
- Peter finds Suzan’s argument far more compelling

> “*I think everyone should be using a mineral sunscreen, so that’s number one*.”‒ Suzan Obagi

**What is it that ultraviolet energy is doing to my skin that is deleterious?**

- For ultraviolet, we know there’s [UVA and UVB](https://en.wikipedia.org/wiki/Ultraviolet#Subtypes)
- UVA is the longer wavelength between the two ultraviolet rays that reach the earth
  - That’s A for aging
- UVB is the one that causes a lot of the redness and the sunburns and leaves behind a lot of the atypia in the cells
  - That’s B for burns
- UVB probably causes more skin cancers than UVA, but they’re both implicated

**⇒** We have high energy visible light, we have visible light, we have infrared light, all coming from the sun; so we have 5 different rays, and they all play a role in how we age

- We worry about UVB with regards to skin cancer
- High energy visible light, visible light, and infrared light also play a role in terms of hyperpigmentation
- Now there’s some evidence maybe suggesting that because infrared light can reach deeper into the skin, it may have a role on fat atrophy and bone remodeling
  - Suzan would like to see more studies along that
  - She doesn’t know how you could possibly do that in an ethical way
  - Peter suggests animal studies
- We could probably spend on whole podcast on UV injuries

Tanuj explains about UV, “*Not only do we know that it damages DNA and can lead to tumors, cancers, melanoma, but it also injures* [*collagen*](https://en.wikipedia.org/wiki/Collagen) *particles,* [*elastin*](https://en.wikipedia.org/wiki/Elastin) *particles.*”

- This makes up a lot of the ultra structure of cells
  - Cells have intracellular infrastructure, but also extracellular infrastructure
  - So the matrix of the subcutaneous tissues, the dermis, is built by this beautiful scaffolding [which is damaged by UV]
- If you look at an 18-year-old’s skin under the microscope: it’s this thick, beautiful blanket layer of volume because you’ve got this collagen-elastin structure that’s holding this whole thing up, and it’s filled with water molecules, have lots of space to move around in, and signals going back and forth

***All of that collagen and elastin framework also gets heavily injured by UV over time, and it becomes cumulative, and that leads to thinning of the skin, loss of the subcutaneous fat layer, loss of those intracellular connections, so that people start to get pitting and fine lines and wrinkles***

- That’s just from an aesthetic standpoint, just another area just to know from UV damage

**How much of the difference that we see in black skin versus white skin is due to less damage from UV versus other genetic differences that enhance what you’re describing?**

- It’s almost completely what you’re saying

***It’s the protection value of the increased*** [***melanin***](https://en.wikipedia.org/wiki/Melanin) ***particles that people with darker skin have***

- There’s a [Fitzpatrick scale](https://en.wikipedia.org/wiki/Fitzpatrick_scale) from I to VI
  - Fitzpatrick I is someone who’s extremely fair, blonde, blue-eyed, burns all the time, never tans
  - Then it goes all the way to Fitzpatrick VI, which is the darkest skin that you’ll see; who never tans and can’t burn
  - We’re all somewhere in that spectrum

Peter asks, “*So I’m a III?*”

- III+ maybe verging on a IV

*Is there basically a linear relationship between I and VI, in terms of how well you will age, skin-wise?*

- Generally, yeah
- The [melanin](https://en.wikipedia.org/wiki/Melanin) factor is huge
- Evolutionarily, if you actually look at what’s happening when melanin is inside the cell, it’s not just randomly dispersed

**⇒** The melanin forms a parasol over the nucleus to protect the DNA

- Evolution is showing us (microscopically) why it’s so important to protect ourselves from the UV
- When we’re a Fitzpatrick II to VI, or II to V, and you’re exposed to sunlight, we get immediate up-regulation of melanin production by the tyrosine kinase pathway, and all of that melanin doubles and triples

***That’s why we’re tanning: we tan to create more melanin to protect our DNA***

- A tan is only aesthetic in this day and age because it used to be that, if you were tan, you worked in the fields, so it was not a sign of prosperity and affluence
- Melanin is our own antioxidant (a very good one)

**Peter’s takeaway:** ***step #1 protect your skin in the sun***

## Strategies for minimizing skin aging: retinoids, vitamin C, and evidence-based application methods [1:09:00]

**What’s the next-level thing one can do for prevention?**

- Suzan recommends a [retinoid](https://en.wikipedia.org/wiki/Retinoid) of some sort
- Peter was worried she was going to say that; it’s just one more thing he has to apply

- Peter said earlier that he doesn’t wash his face at night (he admits it’s gross)
- She asks, “*Do you brush your teeth at night?*”
  - He’s a religious flosser and teeth brusher
- What Suzan tells patients is, “*Right next to your toothbrush, put your little tube of retinoid*.”

*Different categories of retinoids*

- 1 – [Retinol](https://en.wikipedia.org/wiki/Retinol) is the weakest one, and your body will put it through [2 enzymatic changes](https://en.wikipedia.org/wiki/Retinoic_acid#Biosynthesis_and_metabolism) to become [retinoic acid](https://en.wikipedia.org/wiki/Retinoic_acid) (which is what you get at the pharmacy)
  - That’s great if you’re in your late teens/early 20s, and you’re just trying to be preventative with how your skin is aging and, at the same time, maybe addressing some acne
- Once you hit late 20s into your 30s and early 40s, you need maybe something a little stronger, and that’s where retinaldehyde is a little bit better
- Retinol becomes retinaldehyde, which then becomes retinoic acid
- 2 – [Retinaldehyde](https://en.wikipedia.org/wiki/Retinal) is that middle step, and there’s more actual enzyme in your body that can convert retinaldehyde to retinoic acid, and that’s less irritating for people to use

**⇒** If you get irritated very easily and you’re going to quit, retinaldehyde is an option that is highly efficacious; it’s going to irritate the skin less because it gets converted to the active form after it’s been absorbed into the skin

- 3 – The gold standard is [retinoic acid](https://en.wikipedia.org/wiki/Retinoic_acid), and that has multiple different strengths
  - That’s for someone who’s in their mid 40s and up
  - They’re going to need it continuously to keep boosting collagen

Do you want to venture a guess as to what age we peaked in our collagen production?

- Peter would say late teens/early 20s?
- Yeah, 18
- That was when our [fibroblasts](https://en.wikipedia.org/wiki/Fibroblast) were making the most of the matrix that Tanuj was talking about
- Peter guessed that because that’s when, in women, bone density peaks, at about 18
  - For men, it’s about 20 or 21
- At age 18 we start to make less [collagen](https://en.wikipedia.org/wiki/Collagen), [elastin](https://en.wikipedia.org/wiki/Elastin), and [glycosaminoglycans](https://en.wikipedia.org/wiki/Glycosaminoglycan)

*Benefits of adding retinoid*

- 1 – We’re telling the fibroblasts to boost the production of those ingredients, those peptides and those collagen matrix
- 2 – If we are looking at the melanocytes, those retinoids also normalize the function of melanocytes, so that they’re less aggregated, less overactive, and they also help to normalize the turnover of the keratinocytes
- They’re working on the major cellular structure of the skin at the level of the DNA

*Prescription retinoids*

- Come in 3 major concentrations: 0.025, 0.05, and 0.1
- You can also get 0.04 and 0.08 as well as custom formulations

*Peter’s experience 10 years ago*

- The few times he tried to use this, he couldn’t do it every day
  - He became too red

Peter asks, “*Did that mean I was on too high a formulation, I should have gone back to the aldehyde, I was too young?*”

- Suzan takes a different approach than most of her colleagues ‒ ***tough it out***
  - If you’re trying to achieve a goal (whether it’s treating melasma (sun damage) or getting ready for a child’s wedding)
  - If you use retinoic acid every single day, your body acclimates to it very quickly

**⇒** It may take 6 weeks, 7 weeks, 8 weeks, but you get your skin used to it and then you reap all the benefits

- But some patients are always going to quit

Suzan would recommend for Peter

- Start with: 5 days a week of retinaldehyde, 2 days a week retinoic acid
- Then, maybe, as your skin acclimates to it, you can change that proportion

**Do you become more light sensitive when you take this?**

*Does it make it even more important that you’re wearing sunscreen in the sun?*

- The last thing you should do is stop taking retinoids in the summer
- Initially when you start a retinoid, you will get exfoliation at the level of the dead layer of the skin (the [stratum corneum](https://en.wikipedia.org/wiki/Stratum_corneum))
- But, after you’ve been on the retinoid for a long time, that builds back up and you become less light sensitive
  - You might always still be a little bit, but you’re a lot less light sensitive than when you first start a retinoid

**⇒** You should always have a sunscreen on and a hat

***Retinoids have been shown, even if you get sun exposure, they have the ability to repair some of that DNA damage early on, so you really want to be on a retinoid all the time***

Tanuj agrees with everything Suzan just said and adds

- He has a slightly different protocol for people who are sensitive
  - Start out 2-3x a week of [Retin-A](https://en.wikipedia.org/wiki/Tretinoin), then gradually build up to nightly use over a couple months
  - Or mix Retin-A with some over-the-counter hydrocortisone 1% cream
    - He knows people get really worked up about putting steroids on their face, but 1% hydrocortisone is such a low concentration that it’s just enough to reduce some of that annoying irritation from the Retin-A in the first few weeks or month

**The benefits of using vitamin C on the skin**

- When people are thinking about the core aspects of what should they be using on their skin now that they’re starting to notice some changes in their 20s or 30s

> “*In addition to sunscreen and retinoids, I think that vitamin C is a really important molecule to get onto the skin also*.”‒ Tanuj Nakra

Peter tried that too

- He stopped vitamin C treatment because it was mixed with ferulic acid and he hated the smell of it
- Tanuj explains that [vitamin C](https://en.wikipedia.org/wiki/Vitamin_C) is a notoriously complicated, easily reduced molecule
  - When manufacturers are formulating their vitamin C serums, it might be a year from when it leaves the factory and gets onto your skin (if we’re lucky)
  - And in that year, all of the relatively inexpensive vitamin C serums are going to degrade, and not actually have any bioavailability when that vitamin C is applied to the skin
- The relatively more expensive formulations are being produced by manufacturers that are doing all sorts of manufacturing flips and tricks to try and stabilize that
  - Tanuj guesses they used the ferulic acid to stabilize the vitamin C so that it maintains its bioavailability
- Other formulations of vitamin C will use an oil-based formula
  - It’s not aqueous, because then the vitamin C is much less likely to be reduced in that kind of formulation
  - Those products tend to be petroleum, oil-based and also have all sorts of negatives associated with it
- There are some products that will microencapsulate or find other creative ways of making sure that the vitamin C is actually bioavailable when it hits your skin

**Tanuj’s advice for Peter:** ***that product may not have worked for you, but there are other options to find a stable vitamin C***

*Tanuj’s advice for people who are price-sensitive*

- Go to Walgreen, buy a retinoid (retinol) and a sunscreen ‒ you don’t need to spend more than $10-15 on effective products
  - You can’t get retinoic acid without a prescription
- Vitamin C is something where you have to spend the money on

Peter asks, “*Is there any downside of using retinol or do you just need a lot more of it?*”

- The problem is if you try to push that enzymatic chain reaction, you’ll get dermatitis

**Peter’s takeaway**: if you can afford it, it’s better to get the prescription

- Retinoic acid has come down in price
- They realize that more and more people are willing to spend out of pocket to buy it
- It’s about $80-100 for a tube that will last about 3 months
  - If it’s lasting longer, you’re not putting enough on

**How to use retinoids**

- You have to put on the right amount; Suzan tells patients how many milligrams to put on once a day, twice a day

Suzan describes the amount to use as a fingertip unit, “*Hold up your finger and it should be from the tip of your index finger to your DIP joint*.”

- [The DIP joint is one joint away from the end of the finger, located in the diagram below between the orange and blue areas]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f6-tanujandsuzan-1024x982.png)

**Figure 6. The DIP, PIP, and MCP joints of the hand**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Interphalangeal_joints_of_the_hand)

- Peter jokes, “*I’m getting a* [*troponin*](https://en.wikipedia.org/wiki/Troponin) *leak right now, just thinking about applying that much stuff.*”
- Suzan tells clients to put it on their face, including the under-eye area because that’s the thinnest skin
  - And that’s the skin that’s going to wrinkle and age first
  - Most people are afraid to go around their eyes
  - Just don’t get it in your eyes
  - Go around, but make sure you’re getting that under-eye area
  - And once a week, maybe use it on the upper eyelid
- Once or twice a week,  use it on the neck (again this is the thinnest skin)
- We’ve got to keep that skin-building collagen and elastin

*The vitamin C and ferulic acid, would you put that on after?*

***You always put on the liquid before the thickest stuff (thinnest to thickest)***

## Effective daily skincare routine: cleansing, antioxidants, retinoids, moisturization, and more [1:18:45]

**How to wash your face**

- Peter guesses that the hand sanitizer next to his sink is not the thing to use
- There’s been a huge shift in so many areas of skincare that is now syncing more with what science is telling us
- Historically, there was a belief that you would need to strip all the oil off your face, and debris and dirt before you apply products
  - We’re talking about skincare routines from 10 or 20 years ago

***We now know that that is harmful***

- It creates inflammation, it disrupts the microbiome of the skin, it does all sorts of negative things

**⇒** A modern cleanser that we suggest is usually something that is glycerin-based

- There’s also other versions
- It’s a way of cleansing the skin without overly stripping the oils out of the skin

***Glycerin-based cleansers don’t foam and it’s a way of cleansing the skin without overly stripping the oils out of the skin***

**Tanuj recommends**

- The first step, to get the debris, superficial oils, and previously applied product  off the face;  and then as Suzan said, you go from thin to thick
- Usually, on top of that will be serums, like vitamin C serum or retinols
- And then finally, you’ll put a moisturizer on to seal it all down

*Serums*

- Any antioxidant serum
- We mentioned vitamin C, but there are so many others
- Suzan points out: there are great antioxidant serums that contain [silymarin](https://en.wikipedia.org/wiki/Silibinin), [phloretin](https://en.wikipedia.org/wiki/Phloretin)

Peter asks, “*How does one pick?*”

- That’s where you have to look and see who’s invested in doing the clinical research based behind the products that they’re promoting
- Generically speaking, Tanuj recommends a vitamin C serum that has a higher quality vehicle
  - To make sure the vitamin C is bioavailable when it gets to your skin
  - That product is going to have additional, associated antioxidants that are going to be very useful and helpful

**Brands Tanuj trusts**

- His brand [AVYA Skincare](https://www.avyaskincare.com/collections/serums)
  - These products are formulated to have medical-grade efficacy
  - We also incorporate some Ayurvedic wisdom, which is anti-inflammatory, so it has turmeric and other Eastern botanicals for anti-inflammatory care
  - We have a [vitamin C serum](https://www.avyaskincare.com/collections/serums/products/anti-aging-power-serum) that is microencapsulated that also has a retinol in it, and also has various other antioxidants, niacinamide, that are all useful to apply to the skin right after you’ve washed it
- There are other brands; they could probably name 100 of them
- [SkinCeuticals](https://www.skinceuticals.com/skincare/vitamin-c-serums/c-e-ferulic-with-15-l-ascorbic-acid/S17.html) is probably one of the most available
  - That’s the one Peter tried with ferulic acid (he didn’t like the smell)
- [OBAGI Medical](https://www.obagi.com/collections/shop-all) is a publicly owned company that Suzan formulates for them a [Suzan Obagi MD line](https://www.obagi.com/collections/suzanobagimd-skin-care), and their [vitamin C](https://www.obagi.com/products/professional-c-serum-20) serum has been around for a number of years
  - The original founder of Obagi was Suzan’s father ([Zein Obagi](https://en.wikipedia.org/wiki/Zein_E._Obagi)), but he has since left the company
  - This brand has been time-tested for 35 years now
  - It’s a vitamin C under a nitrogen vapor, so it makes it so much more difficult and challenging to produce, but it’s a very stable form of L-ascorbic acid without the ferulic acid
  - They have a study that shows that their L-ascorbic acid penetrates about 4x deeper than the one from SkinCeuticals
    - Suzan didn’t do this study
- Another brand that produces good products is [SkinBetter](https://www.skinbetter.com/shop-skincare/browse-by/?prefn1=productType&prefv1=serums)

**Peter’s takeaway**:

- This is not unlike what’s the best diet for me
  - The best diet is the one that allows you to maintain energy balance that requires the fewest amounts of neurons to stay on
- He needs to get 3 of these and figure out which one is the least annoying for him to put on
  - No offense to that company, it won’t be SkinCeuticals, because every time he’s tried it, the smell of the ferulic acid or whatever it is, has been annoying

**Why vitamin C is so important**

- Peter assumes it has to do with [proline](https://en.wikipedia.org/wiki/Proline) and [collagen](https://en.wikipedia.org/wiki/Collagen)

> “*Vitamin C is like a wonder molecule when it comes to facial aesthetics, because yes, it is a precursor for the collagen synthesis pathway and the proline synthesis pathway, but it also is a powerful antioxidant.*”‒ Tanuj Nakra

**⇒** Antioxidant application to the skin not only has the power to remove injury, oxidative injury that has happened during the day; but it also has the ability to reverse some existing damage

- Vitamin C also regulates the tyrosine kinase pathway, which is a scientific way of saying referring to complexion
  - People talk about wanting to have a good complexion
  - That means having an even skin tone, which is an even distribution of melanin
  - It doesn’t matter if you’re Black or white or brown, people desire to have their skin look even without splotchy areas of pigmentation or nearby areas of relative depigmentation

**Peter’s summary of when to use it:** ***we’re going to go from the serum to the retinoic acid, and the last thing you want to use is a moisturizer***

**More about moisturizers**

Tanuj shares, “*The cheapest trick in skincare, which actually is really true, is that deep moisturization locks down the skin barrier function. And allows the skin turgor of the skin, dermis, epithelium to thicken just by having that occlusive barrier*.”

- You can go to Walgreens and spend $6 on Aquaphor (which is basically petroleum jelly), and put it on your face nightly, and your skin will look better in 30 days guaranteed
- Because your skin will thicken and a lot of the fine lines and crinkles will actually start to disappear because your skin is being more hydrated ‒ that’s hydration
- Tanuj is saying that as sort of like tongue in cheek
  - He’s not telling people to do that

***This illustrates that good, deep hydration can be performed with an inexpensive product used regularly***

**⇒** Hydration will make a real difference because the moisturization, especially overnight while you’re sleeping, is a powerful tool for aesthetics

> “*Women age 20 years faster than guys in terms of the bone remodeling and fat atrophy of the skin*.”‒ Suzan Obagi

- Peter jokes that he is a greaseball to begin with
- Suzan explains that he has young, thicker skin

Peter asks, “*My routine would be done after the retinoic acid?*”

- Yes
- Suzan tends to give moisturizers as women become more mature because they start to make less of their natural moisturizing factor
  - That even starts to diminish at age 18

***Most people into their mid-40s and 50s even, might not always need a moisturizer with everything that they put on at night***

- The morning sunscreen and serums have some moisturizing qualities

**Suzan has patients put a super antioxidant serum (or vitamin C serum) on both in the morning and at night (before the retinoid)**

- Her feeling is that you spend the  whole day outside (or in your car or being hit by LED and ultraviolet lights), and those are damaging the skin
- So you should have an antioxidant on first thing in the morning, but it’s going to get depleted by the end of the day
- She has patients repeat the application of antioxidant serum at night because it’s been depleted during the day
- We know that the cells undergo mitophagy and autophagy at night, and we want to help the repair factor
- We want to put on an antioxidant at night again, just to replenish the skin

*The retinoic acid going on top of that only at night*

- The retinoic acid has anti-inflammatory properties to it, in addition to all the good things that it does in terms of building up collagen and elastin

**A.M. routine**

- In the shower, don’t use body soap on your face, because it’s going to strip the oils out of your face
- You need a separate facial cleanser
  - It depends on your skin type

***After cleansing, use a serum, then apply sunscreen***

- If you have clogged pores (oilier skin), you may need an **alpha hydroxy acid** or **polyhydroxy acid** before applying sunscreen

**P.M. routine**

- Begin with a cleanser
  - Soap connotates something more harsh

***Cleanser, serum, retinoic acid in the evening***

- For the minimalist ‒ use whatever you can to protect your skin and improve the aging process

[See a list of products Tanuj and Suzan like at the end of the “Selected Links” section]

**People ask, “*****Why do I need to apply an antioxidant if I’m eating a lot of antioxidants?*****”**

- The skin is the largest organ in the body, and it’s very unique
- It’s very good at keeping things out, or from the inside coming out as well
  - So outside things like water, pollution, it tries to protect that from getting in
  - And does a good job at keeping homeostasis

***The level of vitamin C that you can achieve in the skin by topical application, far exceeds what you can do by ingesting it***

- The amount you would have to ingest to get the right amount in the skin, you’d have GI issues
  - That would definitely make you quit

## The playbook for managing acne [1:31:00]

- It’s mostly something that adolescents are experiencing, but adults get acne as well
- Peter assumes it involves [spironolactone](https://en.wikipedia.org/wiki/Spironolactone) if it looks to be endocrine in nature
- He’d be very curious to hear about [Accutane](https://en.wikipedia.org/wiki/Isotretinoin)
  - He’s heard horror stories about it

> “*My number one thing I tell people is for themselves or their children, try to treat the acne before it scars*.”‒ Suzan Obagi

- Suzan cannot tell you how many times she sees patients for consults for acne scars
  - They’re in their 70s and they’re still crying about it as if it was yesterday
  - They’ve been traumatized all their life with these acne scars

**What causes acne to scar?**

- It depends on how inflammatory your acne is

There are different types of acne

- 1 – There’s [comedonal acne](https://en.wikipedia.org/wiki/Acne#Classification), which are just your run-of-the-mill, small pimples, whiteheads, blackheads
  - Those don’t typically scar unless someone picks at them

***#1 rule for patients, don’t pick at your skin***

- 2 – A little bit more inflammatory acne
  - Those tend to be the red ones that come up and there may be pustular on the skin
  - And if you don’t pick at them, those also might heal without scarring.
- 3 – [Cystic acne](https://en.wikipedia.org/wiki/Acne#:~:text=Large%20nodules%20were%20previously%20called%20cysts.) and those are a completely different type of acne where you’re getting inflammation
  - That’s [pilosebaceous unit](https://en.wikipedia.org/wiki/Sebaceous_gland#), which is the hair follicle and the oil gland feeding in there, and you get swelling deep in the dermis
  - You might get enough inflammation and rupture of that cyst, that you leave a divot at that point ‒ that causes what we call a “valley scar” (even if it’s not picked)
  - Cystic acne is a dermatologic medical emergency that you want to treat before it causes scarring
  - It’s very difficult to fix later on
  - It can cause so much psychological trauma to a child: shy to go out in public, they want to hide their face

*What percentage of adolescents will develop cystic acne?*

- Without being able to quote exact percentages, Suzan estimates about 20%
- Suzan is not a big fan of antibiotic use because she doesn’t want to alter the gut microbiome
- For cystic acne, she quickly moves to [Accutane](https://en.wikipedia.org/wiki/Isotretinoin)
  - Nothing topical is going to work; nor is [photodynamic therapy](https://en.wikipedia.org/wiki/Photodynamic_therapy)

**Say more about photodynamic therapy**

- [Photodynamic therapy](https://www.aad.org/public/diseases/acne/derm-treat/lasers-lights#:~:text=Photodynamic%20therapy%20(PDT)) is where you take a molecule like [aminolevulinic acid (ALA)](https://en.wikipedia.org/wiki/Aminolevulinic_acid) and you paint it on the skin, let it incubate for about an hour, and then you shine a red light onto the skin to activate it
- That chemical gets into the sebaceous glands and percolates down through the skin
- Then when you activate it, it causes a heat reaction and basically induces damage in that whole area that’s picking up that medication

***You’re causing the oil glands to shut down, you’re taking away the nidus for the inflammatory acne***

- And for some patients who cannot take Accutane (or isotretinoin), that’s a great alternative for them

**⇒** It does feel uncomfortable and not every doctor offers it, but it’s a great adjunct or alternative if they can’t take isotretinoin [brand name Accutane]

**Would antibiotics work, if not for the limitations and side effects of long-term, systemic antibiotic use?**

- Antibiotics will work to a small degree
- They might help shut down maybe a good proportion of that cystic acne flare

***But they won’t get to the root cause, which is sebaceous unit overproduction of oils***

- The bacteria that are in there feeding off of that and the whole cascade, and there’s something genetic
- Cystic acne tends to run in families, so there’s some kind of genetic tendency towards that milieu that causes cystic acne

**How does Accutane work?**

- Accutane is a type of retinoid, and it’s basically going to go in there and dry up the oil production that’s in these overactive sebaceous glands that are being driven by your androgens
- You take it orally
- Some topical variations have been used for psoriasis, but for acne, it’s best taken orally because you bypass a lot of the surface dermatitis

*What is the main side effect or toxicity that people are trying to avoid with Accutane? Why does it have a bad name?*

- It has a couple of bad connotations with it
- It dries everyone out ‒ so for the 5 months you’re on it, you are going to have dry lips, dry eyes
  - Some people complain that their skin is too dry
- Some people on high doses, might get shedding of the hair
- You’re not allowed to drink alcohol while you’re on it
  - That’s a whole other issue with kids and making sure they’re compliant with that, because it is metabolized by the liver
- It has a [teratogenic](https://en.wikipedia.org/wiki/Teratology) effect: it will cause birth defects
  - We have to go through this whole FDA-required modules with the patients to make sure that female patients are using two forms of birth control while they’re on it
  - Patients are not donating blood while they’re on it
- Other than that, patients, if they’re using it correctly, tolerate it very well
- It got a very bad reputation when a child or a son of a Senator committed suicide while on that medication, and they said it was a depression induced by the medication
- It turns out when people look scientifically at the rate of depression (it has junk science written all over it)
  - Depression scores in acne patients with cystic acne is significant
  - And their depression actually improves when they take something like Accutane because they feel better

*Do you have to monitor liver function tests while patients are on it the same way you do with Lamictal or any of the toe fungus type things?*

- Yes
- It could potentially be severe
- It changes your lipid profile while you’re on it
  - It can elevate your triglycerides and elevate your cholesterol
  - There are very few instances we would adjust the dose
  - We just tell people to try to eat healthier while they’re on it, especially for triglyceride elevation
  - Liver enzymes, it’s a rare patient that gets a real significant bump; but you want to watch for that because you want to stop the medication if that’s the case
    - It’s also a proxy to make sure they’re not drinking

*You mentioned taking Accutane for 5 months (a lengthy treatment). Does that imply that after this time, you’re done with this?*

- For 85% of people that take it for 5 months, they’re done
- You’ve got the small subset that need to take it again
- For Suzan’s adult patients, who might not have a lot of acne, but they’re very oily
  - She puts them on it one month out of the year just to dry them up a little bit, and it helps them feel better
  - It makes their pores look tighter, makes their skin have a better texture to it.

**⇒** We always said, “*Oh, if you have oily skin, you’re going to age better.*” That’s so not true

- Oil is inflammatory on the skin
- From that standpoint, Suzan would rather have patients use Accutane to dry them up for about a month, and then allow them to enjoy the beautiful skin for the rest of the year

**How does one know if they have oily skin?**

Peter adds, “*I’ve always thought I have oily skin, do I?*”

- Your pores would be enlarged
- Some people have to blot their face midday (Peter doesn’t have that)

**Peter wants to make sure he gets their recommendation for good products**

- [summarized at the end of the “selected links” section]
- You mentioned for the cleanser, it just needs to be glycerol-based

**Are these easy, over-the-counter things to find?**

*Should I be going to Target or Walgreens and literally just going through the skin aisle, and looking for cleansers that are glycerol-based that won’t lather when I use them?*

- That’s one way to do it
- Tanuj and Suzan will provide links to a bunch of products
- If you’re oiler, Suzan recommends a cleanser that is not quite so hydrating

## The 4 changes of aging and the complexities of aesthetic consultations including the anatomical, psychological, and ethical factors physicians must navigate [1:39:00]

- Let us move now into the really confusing realm of: I show up in your office, I can’t tell you what’s wrong, but I show you a picture of me 10 years ago and I say, “*I want to look like that.*”
  - Remove the bags under the eyes
  - Make the skin look better: better color
  - Fix the wrinkles in the forehead

**Assuming I had that photo, how would you describe them pathologically? (or maybe that’s too strong a word)**

*There are 4 basic changes that happen to every single person with aging*

- 1 – Skin changes
- 2 – Volume changes
- 3 – Gravitational changes
- 4 – Bone structural, foundational changes
- For these patients, Tanuj will spend extra time analyzing the individual nuances of skin volume, bony ligamentous anatomy, gravitational changes that are specific to their face
- Also we’ll just rely on general knowledge that we have about what types of aging changes we see at this point

*It’s a very complex process*

- As soon as Tanuj sees the patient, while he’s making some niceties and saying hello and gets to know them, he’s already analyzing
- Looking at their skin
- Looking at the bone structure
- Analyzing the facial proportion
- Looking at areas where there’s volume loss, it’s obvious
- Looking at the dynamic movement of the forehead and the face
- Analyzing how much heaviness is on the eyes
- It might be driving [frontalis muscle](https://en.wikipedia.org/wiki/Frontalis_muscle) tone that’s causing forehead wrinkles
- Looking for facial asymmetries

***A lot of the physical exam that we do in our offices happens in the first 15 seconds***

- Peter points out, “*The urologist doesn’t have this advantage. He can’t examine the prostate and the scrotal tissue during that first 15 seconds*.”

*The next step is going into the patient’s mind, and trying to understand their psychology and what their motivation is*

- The problem that we have is that the patient doesn’t know what words to say
  - For them to communicate what’s actually driving them
- Tanuj has to pull that out of them; this is a little bit of detective work
- Both of Tanuj’s parents are psychiatrists
  - He actually went to medical school thinking he was going to go into psychiatry, and then he rapidly pivoted into surgery and ended up where he is today
  - But that initial love and appreciation for what’s happening inside the neuronal processing and the subconscious, is something that we actually work with every single day in our offices
    - Peter hopes this is true but imagines there are a lot of people doing this in a coin-operated way
    - Suzan points out that many practitioners use a cookie-cutter approach, but that’s not the way we should be practicing aesthetics

Tanuj explains, “*Every single individual has a totally customized situation anatomically, physiologically and psychologically. So our job is to try and figure that out when the patient doesn’t have the ability to express.*”

- This concept overlaps into pediatrics when you are trying to do a physical exam and get history from someone who is unable to communicate what they want you to figure out

Tanuj will ask the patient

- Did you like the way you looked when you were 20?
  - If they say yes, that means that they actually like their natural facial proportions and they’re probably looking more for rejuvenation
  - If they say, “*I always had a heavy eyelid and I never could put makeup on my eye.*”
    - Then he knows they may be looking for something that’s a more substantial result in that particular area
- He gets to know them by asking about their occupation, their situation at home, do they have kids
  - Try to understand their social history
  - See if there are any red flags that would stop the process
    - Maybe they need to get their mental health in order before considering aesthetics ‒ this is something he would openly tell the patient in the consultation

Peter asks, “*If a 50-year-old woman comes in and says, ‘My husband of 25 years is leaving me for a 20-year-old.’ Understandably, she’s in duress and she’s probably comparing herself to a 25-year-old. Would that be a nonstarter in your mind?*”

- This scenario is very common; Tanuj sees it all the time
- This is why he schedules 45 min or 1 hour for initial consultations
- Once we start talking about that, tears may start flowing, and the patient is now in a safe zone talking to a medical professional who’s actually listening to them
  - Then we start to fall into the role of a therapist, and we’re letting them express because Tanuj wants to see how deep is this trauma?
  - He’s trying to understand if this is a nonstarter or what he should do
- There are scenarios where someone is in that kind of situation where we certainly would not want to make any drastic moves, or big changes or shifts
- But is it appropriate to recognize that this person is desiring something that is a reasonable goal?

***It’s not appropriate to do the procedure to get to the goal in the patient’s current emotional state***

- We can suggest doing something reversible
- The fear is that if you say no to her, she’s going to find some guy down the block who will do anything

***And it’s better that you do something small and develop a relationship with her that will ultimately serve her interests***

- But you can’t give her everything she wants at the moment

> “*We’re trying to build that trust and build that relationship on the front end, so that this individual who’s trying to get from A to B, we’re going to take them there safely*.”‒ Tanuj Nakra

- Whether it’s over a couple of months or 10 years, we’re going to try to get to that goal
- And there may be some obstacles along the way and choices that we have to make, but we’ll navigate it together
- And it’s all built on building that relationship on the front end, so the trust exists where he can tell the patient, “*We are not going to do this maneuver right now*.” And then that patient will listen
  - Because the trust has been built up enough that this individual knows that he has their best interest in mind and we’re going to get to that goal eventually

***In this scenario, the individual might be best served with explaining they can get there one day with procedures, but right now refer them to a therapist and do some simple treatments they are not going to regret***

- Like neuromodulators, fillers, some skin treatments or lasers, things that are low risk
  - They’re not going to create any scars or permanent changes, and then we can eventually get to that next step
- We are not going to do the facelift next week

**Tanuj’s summary of the goals for the initial consultation**

- The first step is we do this snapshot, anatomic, dynamic analysis
  - It’s not just a single image as we’re looking at the muscle movement
- The second step is this deep dive into their social situation, psychology
- Then presuming that everything’s moving along smoothly, now we’re getting ready to talk about what should we do now
- He’ll spend time educating the patient on their actual anatomy
  - Because they’ve never actually had that information presented to them
  - He will put the mirror in front of the patient and say, “*Let’s go through what I’m seeing on your exam today together.”* And he’ll start at the top and go through every little detail
- He’ll throw in little caveats like, “*I’m sorry, I’m not trying to make you feel bad about your features, but you’re here for me to tell you so I’m going to tell you everything. We’re going to talk about your bones, we’re going to talk about the wrinkles, we’re going to talk about the asymmetry you never noticed*.”
  - Which is almost always the case
  - People don’t notice their asymmetries
- Then after that relatively lengthy discussion about their individual anatomy, he’ll start to say, “*Okay. Now you initially told me that these are some of the areas that bother you. Here’s what we could do to fix your eye region, your cheek, your mouth, your jaw, whatever it is*.”
  - He’ll present options that go from minimally invasive to more substantial
  - And based on how the individual is responding to the conversation, he can usually dial into what is the appropriate scope for this patient
    - Relying on his 20 years of experience
    - They don’t really know whether they want a facelift or not
- He may need to explain the complications and where the incisions are
  - So they really understand what that procedure means
- If that seems like it’s too much for them, we will dial it back and I’ll have to tell them, “*Look, we’re not going to be able to get the results of a facelift without a facelift, but I don’t think you’re ready for a facelift. So maybe we should start with something smaller*.”

***Tanuj waits until the end of the consultation to give the patient his opinion***

- He won’t give them his opinion about what we should do until we’ve gone through this whole process and he’s watched their body language as we’ve talked about procedures
- Sometimes he’ll suggest something that’s minimally invasive and they seem uninterested because it’s not enough for them
- And he’ll read that body language and dial in the treatment for what he suggests for them

## The 5 R’s of rejuvenation [1:50:15]

**Suzan is glad to hear that Tanuj talks to the patient about their mental state during the consultation**

- She does a lot of what is almost psychology and therapy with patients
- She was a biology and psychology double major in school and she uses psychology a lot
- She has a similar approach with patients and tries to put things in terms they can understand

*Suzan’s 5 R’s of rejuvenation*

- Patients may not need all of them at one point in time, but at some point in their life, they’re going to need one of them
  - Then they’ll make it through all 5
- 1 – **Relax** overactive muscles
- 2 – **Refill** lost volume
  - Whether it’s through fat grafting (one of her favorite procedures) or with fillers
  - You don’t need a lot of fillers
- 3 – **Resurface** the skin
  - How the skin looks is absolutely much more important than how tight it is
- Patients sometimes come in and they’re like, “*I just want a lift here*,” and they want to lift their lower face, and their skin is terribly wrinkled and they have hyperpigmentation and sunspots
- Suzan tells them, “*If I lift you now, no one’s going to notice that you look better. But if I make your skin look better, people are going to notice you look better before I even do the surgery.*”
- 4 – **Redraping**: there are going to be times that you can’t fill enough, you have to lift
  - Either will lift with devices such as microneedling, radio frequency devices, or ultrasound devices to tighten the skin, or a facelift of some sort
- 5 – Keep **renewing**, because the aging process continues
  - The minute they leave your office, everything you just did on them looks great, and then it starts to diminish
  - The renewal is the maintenance
  - Maintain your neuromodulators and your fillers (but they have to be strategically placed)
  - You need to keep the skin priming itself and turning over

> “*People underestimate how much they can do at home with their skincare regimens, and then have to do less in the office.*”‒ Suzan Obagi

## A facial aging analysis and cosmetic strategy using Peter’s face as a real-time case study [1:53:00]

Peter tells them, “*Feel free to brutalize me. You’re not going to humiliate me.*”

**Peter asks Suzan, “*****What needs to be relaxed in my face?*****”**

- You move your eyebrows a lot in your forehead, so you’ve got a lot of forehead wrinkles
- Suzan notices the [glabella 11’s](https://orentreich.com/the-dreaded-11s/)
- Part of the reason you’re raising your eyebrows maybe now more than you did 10 years ago, is you have a little more hooding on your upper eyelids, and your eyelids are almost touching your eyelashes
  - And when that happens, you’re sending a signal to the forehead to lift so you can see better

Peter asks, “*Is that because I’ve lost elasticity in the eyelid and it’s just drooping more?*”

- No, it goes back to what they discussed earlier about the bony structure
  - We’re losing bony support, fat atrophy, including the brow fat pad
- You’ve got a descent a little bit of your brow, but a little more of the extra redundant skin there
  - He’s using this muscle more to try to keep these guys up

Suzan warns, “*If you go to someone who doesn’t evaluate you like we do, they might look at your forehead like target practice and say, ‘I’m going to use a neuromodulator across that entire forehead,’ and make it so you can’t move. And then you’re going to walk around very hooded and very heavy.*”

- You would hate that feeling ‒ it would feel very hooded and very heavy
- Suzan has done that on purpose to herself just to see what patients experience, and it’s not a nice feeling
- Secondly, you are very fit, so you don’t have a lot of fat in your face
- Like she said earlier, it doesn’t matter what you think your weight is on your body now or how much fat percentage you have on your body
  - You’ve atrophied some of the facial fat pads
  - You’ve exposed the entire orbital rim
- Peter points out a scar that has created an asymmetry in the drooping
  - This is from his teenage years when he was boxing
  - He was split to his cheek there (a very deep scar)
  - He suspects the connective tissue there is actually tethered near the bone
- Suzan could free that up with [subcision](https://dermnetnz.org/topics/subcision)
  - That is kind of similar to the microneedling Tanuj did on your other scar
  - But this is going under the scar the whole length of it, and free up that tethering and that adhesion, with or without adding fat or a filler there
- If you look at what makes the eyes look youthful, it’s definitely having a little more platform show on the upper eyelid, but also it’s reducing what we call the length of the lid-cheek junction
  - The length from your eyelash line down to where you can actually see the cheek, that’s elongating
  - You’ve lost all that volume that was up here

*The eyelid-cheek junction is what Peter is most self-conscious of aesthetically*

- The thinness here which makes him look constantly tired (even when he feels like a million bucks)
- He’s more subconscious of this than he is of his wrinkled forehead
- That is where Suzan would either use a little bit of your own fat to rebuild this area and shorten that lid-cheek junction
  - This would create more of a youthful length rather than this kind of long, hollowed area

## The decision-making process between fat grafting and dermal fillers for facial rejuvenation [1:56:30]

**When do you guys make the decision of an auto-graft of fat versus** [**Restylane**](https://en.wikipedia.org/wiki/Restylane)**, you mentioned earlier?**

- Suzan loves fat if we can do it

*Now with the advent of fillers, the volume of fat grafting we do goes down, and Suzan explains why*

- A 69-year-old lady came in and she had never had anything before, and she was hollow everywhere
- We could use lots of fillers, but she’ll spend a small fortune putting a lot of fillers in her face over time
- Personally, Suzan doesn’t like to inject more than 2-3 syringes of filler in one visit
- So it’s going to take a process to build up different areas on her, because she doesn’t want her to have a reaction
- She also wants to see where she is placing everything
- For this lady, Suzan went straight for the fat because she has a thin face, but she has a normal body mass index
  - So her fat is going to do well

**How much filler would Peter require?**

- Suzan would start with a syringe split between both under-eyelids
- Then she would do another syringe probably in about 3 or 4 months if needed

*What is the cost of each syringe? (not your cost, the patient’s cost)*

- $800-1,000 depending on the filler

*What is the cost of the fat graft procedure?*

- Peter imagines that would be much more, but it’s a lifetime (presumably)
- About $5,000

**Peter’s takeaway**: The fat graft costs 5 years worth of treatment; so it’s cheaper in the long run

- Suzan points out that she’s just talking about under Peter’s eyes

**For Suzan’s typical patient**

- They need their temples filled, they need their cheeks filled, they need chin filled, a jawline enhancement
- Yesterday, she did about 35, 40 mls of fat on a patient, and that gets very expensive

**Peter asks, “*****Are my temples too sunken?*****”**

- Yours are still good, and your cheekbones are still good
- Your jawline is still good
- Suzan would put a little neuromodulator or Botox in your [platysmal muscle](https://en.wikipedia.org/wiki/Platysma_muscle)
  - She’s starting to see some platysmal banding there
  - Suzan’s has worn off, so you don’t want to look at hers
  - But that helps to relax that muscle that does nothing but pull the lower face down
- She would possibly add a little volume right in your [malar](https://en.wikipedia.org/wiki/Zygomatic_bone)
- She would love a bio-stimulatory filler, something like [polylactic acid](https://en.wikipedia.org/wiki/Polylactic_acid#Medical) ([Sculptura](https://www.sculptrausa.com/) is the other name for it), to start building collagen and thicken your dermis thickness in here
  - Suzan is starting to see some of your buccal fat pad atrophy as well, and that just goes along with how fit you are
  - So using this to build your own collagen is a great way
- If we were treating a very thin female, we would have an issue because those patients tend to burn through their fillers very quickly
- If we can get a bio-stimulatory filler on board where they’re building their own collagen, sometimes it works a little better

**Pros and cons of doing one fat graft versus multiple fat grafts**

Peter asks, “*Do you ever look at a patient like me and say, ‘You’re most fat depleted here and here, but you’re not yet fat depleted here and here. I only want to do one fat graft on you. So cost aside, let’s use fillers until I have to do this procedure once and for all, and then I’ll literally just take a bunch of fat off you and do it’?*”

- Absolutely

*Are you afraid to do multiple fat grafts?*

- Oh no
- Suzan has patients that come for fat grafting as they need it
- She’s done some patients 3, 4 times
- She has also turned down a lot of patients who come in asking for fat grafting for lips or for under-eyes
  - She tells them since they don’t need it elsewhere, that’s it’s too much of a procedure to go through for one anatomic area
  - Suzan would do it when they need it elsewhere

**⇒** Fat grafting in the lips it doesn’t hold as long, but under the eyes it works beautifully

- Peter replies that he will probably never need lip fat grafting
  - When he was little, people made fun of the size of my lips

**Peter asks Tanuj what he would change or add, or how he would approach his face**

- Tanuj thinks Suzan’s analysis was spot on
- What he is hearing is that the biggest issue that bothers Peter is his under-eye area
- Peter explains that [Brett Kotless](https://www.drkotlus.com/about/) added [Restylane](https://en.wikipedia.org/wiki/Restylane) there several years ago (2018, 2017)
  - He was amazed at how much he bruised (this was not an unexpected complication)
  - He looked like he had 2 black eyes for a couple of days
  - Otherwise, it looked really good, and then it went away after a period of time (less than a year)
- Some fillers are longer-lasting
- Brett mentioned that this scar was problematic and it was very difficult to fill this eye

*You might ask why didn’t Peter just keep using fillers?*

- It’s the same reason he doesn’t do anything ‒ sheer laziness
- The thought of having a couple of black eyes for a couple days… he just sort of gave up

Tanuj points out, “*Bruising from fillers is a lot less these days, because we don’t use needles as much anymore. We actually use cannulas, which are blunt tipped catheters, and they don’t typically bruise hardly much at all.*”

- One big change that’s happened in the last 5, 8 years, is switching to cannulas
- And people have different philosophies on that
  - Some people use needles for specific locations

## How self-image, eye aesthetics, and fleeting photos drive the desire for cosmetic enhancement [2:01:45]

**Tanuj could list off another 10 things that are ‘aesthetically problematic’**

- Tanuj begins with a laser focus on the area that the patient is presenting to him as their major reason for making he appointment
- Since Peter is curiously interested in all the other things he could say, but has never had surgery on his face, Tanuj would not recommend massive shifts

> “*In the realm of rejuvenation procedures that we perform, surgically or non-surgically, the eye region is probably the sweet spot*.”‒ Tanuj Nakra

- Just again going back to psychology, evolution, we focus on people’s eyes in conversation
- When we talk about beauty, we’re looking at the eyes
- When people’s eyes are now starting to become further and further away from the way they remember it when they were younger, it creates this discomfort
  - It’s the [self-discrepancy theory](https://en.wikipedia.org/wiki/Self-discrepancy_theory) from psychology, where you’ve got this self-image of yourself and then you look at yourself and you’re like, “*Wait a second, that’s not me.*”
  - And then it creates this discomfort of like, “*Is that what I really look like?*”
  - And then it creates the psychological effect of maybe a little less confidence or dissatisfaction with your appearance

***That’s the big motivator for why people actually end up coming to see someone like Tanuj and Suzan ‒ that self-discrepancy theory is kicking in, and the delta between their self-view and their actual appearance is getting greater and greater***

- Peter hates being on video
  - He doesn’t mind the sound of his voice
  - On video in this type of situation, you’re always overhead lit, and it’s an unbearable appearance because the lighting makes bags under your eyes look 10x worse
- Tanuj mentions **subconscious posing** ‒ when you’re looking in the mirror, your subconscious makes you lift your cheek a little bit or angle your head
  - You smile a little bit and it pulls the cheek up and minimizes that hollow between your under-eye and your cheek
  - Everybody does this
- And that’s why people tend to be shocked by photographs that are taken of them when they weren’t prepared for it
  - They’re not prepared to pose for the picture
  - Their flat, undynamic face in a photograph that’s taken like that is shocking to them, and is often a big motivator for them to come to see providers like Tanuj and Suzan
- Peter also made the mistake of once reading some comments on social media where people were just ripping me apart for how horrible he looks
  - If you read a bunch of people saying you look horrible, you’re like, “*That sucks. I don’t like that*.”
- People will bring to the consult a picture of themselves that someone took and are like, “*Oh my God, I saw myself last week. Look at how I look.*”
  - This was one nanosecond in one way you were moving your mouth or tilting your head or a shadow
- Suzan will take their phone and take a picture of them in the exam room to show them how good they look and have them delete the other photo

## Advice for wrinkles, causes of dark circles under the eyes, and the importance of facial symmetry [2:05:45]

**Back to Peter, what about the wrinkle situation?**

- Tanuj would go through the 4 areas (discussed earlier about the skin) and laser focus on the eyes

Tanuj’s advice to Peter, “*You should start a skincare regimen. I think you’ll appreciate it as time goes by.*”

- Peter commits to try it for 3 months

*Tanuj observes*

- Uneven pigmentation in the face
- Fine lines that are more concentrated in the eye region

**⇒** The eyelid skin is the thinnest on the entire body, it’s the only place in the body that does not have a subcutaneous fat layer

Peter asks, “*What’s underneath the skin?*”

- The orbicularis muscle

*There are 4 causes of dark circles under the eyes*

- 1 – There’s visibility of the orbicularis muscle
- 2 – There’s shadowing, which is why you probably don’t like your appearance in this kind of situation, because the shadowing is visible down here
- 3 – There’s [hemosiderin](https://en.wikipedia.org/wiki/Hemosiderin) deposition
- 4 – There’s [hyperpigmentation](https://en.wikipedia.org/wiki/Hyperpigmentation)
- Peter actually has all 4 of them

***Tanuj’s advice: get onto a good quality skincare regimen, not only to reverse some changes, but for prevention purposes***

**When it comes to volume loss**

- Suzan has already picked Peter apart there
- You’ve got volume loss in the midface
- Your temporal volume loss is enough where if you are going to have some kind of volume treatment, putting a little bit in would be nice
- Your left temple sinks in a little more than the right
  - Your right temple is less hollow (which is extremely common)
- When Tanuj has patients look into a mirror and starts pointing out their asymmetries, 95-99% of the time, people are unaware of their own asymmetries
  - The reason why it’s important to point it out to them, because if I’m going to be employed to manipulate their face, they need to know where the starting point was

**Do we want to fix asymmetries all the time? Does it matter?**

- Sometimes
- We don’t want to make it worse

***If there’s a way to make it better when we’re doing maneuvers, we’ll dial that in because this goes back to the reasons why people perceive beauty; and that will make a person look more handsome or beautiful***

- Sometimes people have significant asymmetries
- Sometimes one jaw line is aging beautifully and very well-defined while the other one is a centimeter shorter in length

**Peter’s asymmetries**

- The right side of your face is the smaller side of your face
  - Imagine in utero, you were laying

*Tanuj points out another reason why people feel uncomfortable when they see photographs of themselves*

- You’re used to looking at your mirror image of yourself
- Think about this: nobody on the planet has actually ever seen themselves
  - You’ve only seen yourself in the mirror or you’ve seen a photograph of yourself
- You actually don’t really know what you look like in the flesh
- Because there’s that discrepancy between the mirror and a photograph, because the mirror is a flipped image of yourself and the photograph is not, that’s why people don’t like photographs of themselves, especially when they’re more asymmetric

*Back to analyzing Peter’s face*

- If we we measure the distance between the outside corner of your eye to your mouth, it’s about 10% longer on your left side, because the bone structure is wider
- Again, imagine you’re laying in utero, you’re in the womb, and you’re probably spending more time on one side of your face than the other

There’s so many factors we can imagine as to why we get facial asymmetry

- Is it because maybe the growth rates were different
  - Maybe there’s a slightly different cytokine difference between the left and the right at 6 weeks
  - Maybe you’re laying on one side of your face for 2 months

***These things are present at birth and they become more exaggerated as we age, because when you have that devolumization of the fat pockets, the ligaments show up more, and the underlying bone structure starts to become more visible***

**⇒** If we saw pictures of Peter when he was 20 and put them side-by-side with him right now, even though he has great jaw bone, it’s probably lost 10-15% of the volume

**Tanuj’s treatment suggestions for Peter**

- Comprehensive treatment would be to volumize either with some fillers or some fat grafting to the areas of volume we talked about
- The skincare regimen we talked about
- Put some volume along the jaw and your cheekbone because you’ve lost that projection with age
  - And we just know that someone of your age is going to have a certain degree of de-projection

Peter asks, “*How do you put volume along the jaw? How do you keep it in the area you want it to be without it looking odd and protruding?*”

- The art of fillers and fat grafting is really, truly an art
- There’s depth of placement, replacing it in the pre periosteal layer to emulate as if it were a larger bone structure
  - If you’re trying to hide jowling, then you might put it into the muscle layer, because you’re trying to plump up the valley next to the hill so that it becomes smoother looking
- Choosing the right filler

## Considerations that shape clinical decision making around fat grafting and other procedures to address the eye area [2:11:00]

**Is fat always a superior filler?**

- Not necessarily
- Suzan likes fat because it’s your own living tissue
  - It has **stem cells** in it that can become multiple different types of tissue
    - If you place it at the [periosteal level](https://en.wikipedia.org/wiki/Periosteum), it can build bone
    - If you put it in fat, it becomes fat
    - If you put it along muscle, it can turn into muscle
    - If you put it under the skin, it enhances how the skin ages
- Suzan adds something anecdotally: there are many of us that do a lot of fat grafting, and we were on a panel one day talking about it before we knew about the stem cells being in the fat
  - We’re talking 15, 20 years ago
  - We were talking about the fat-grafting patients and how they all uniformly look like they just age better and their skin ages better
  - Now we start to realize, it’s all of that [which Suzan just explained about the stem cells in fat]

*Where do you harvest the fat from?*

- Numerous areas of [preadipocytes](https://en.wikipedia.org/wiki/Adipogenesis#:~:text=as%20lipoblasts%20or-,preadipocytes,-which%20lose%20the)
- The tissue that has the most preadipocytes is the abdomen
- Suzan really likes the **flanks**, because it turns out you don’t just want the fat and the fat stem cells: ***you need all the connective tissue stem cells as well***
  - And when you go to the flanks, the reason the flanks feel so firm, even though they may have fat in them, is they have a lot of septate and [stromal tissue](https://en.wikipedia.org/wiki/Stroma_(tissue)) there
  - And when you aspirate the fat, you’re also aspirating along with it some of that stromal tissue

***When you harvest from the flank, you’re getting the matrix and the scaffolding cells that will help that fat also repopulate***

**To give a sense of volume, if you decided to go full bore on somebody and do temporal and eye and outside of the lip and jaw, how much fat are you putting in?**

*And how much fat and tissue do you need to harvest to acquire the necessary volume?*

- Suzan will typically harvest about 120 CCs of fat
  - We’re talking about an area about the size of a small cantaloupe

To put that in perspective, if a person undergoes liposuction, how much is being harvested?

- Usually, we’re filling canisters (2, 3, 4, liters of fat)
- This is not going to make a material difference in your subcutaneous fat depot
- And if we artistically do it, we can take it from both sides so that you don’t have any divots or asymmetries
  - People always have an asymmetry even on their body
  - Suzan tells them the benefit of this is she’s taking the fat and evening you out with your other hip
- After harvesting the fat, we centrifuge it to condense it down
  - That takes off all the anesthetic fluid you put in
  - We have albumin in there to restore some of the oncotic pressure as well
- And we are taking people’s own PRP: spinning their blood down to get the [PRP (the platelet-rich plasma)](https://en.wikipedia.org/wiki/Platelet-rich_plasma), adding that in along with something that we call nanofat
- It turns out if you take fat and you graft it into tissue, a certain percentage will take
- But if you take fat and then you add in extra stem cells, more of that tissue will take
- So what we do is we harvest extra fat and **extract the nanofat** from that
  - Meaning all the preadipocytes, by running it through some meshes and adding that back into supplement the fat
  - This is all autologous

Tanuj’s protocol is very similar

- He adds that when he was coming through training in 2005-2007, finishing up his fellowships, he spent a lot of time listening to Dr. Obagi’s talks at conferences
- His fat transfer technique has mirrored hers for some time
- He probably does a little less harvesting, a little less injecting
  - Because most of his fat grafting is being done in conjunction with a facelift or an upper and lower eyelid surgery called [blepharoplasty](https://en.wikipedia.org/wiki/Blepharoplasty)
  - When he’s surgically manipulating the tissues, he’s lifting and moving tissues and does not in need of as much volume to make the change that we’re looking for

**Procedures that address the upper eyelid**

Peter asks, “*Are my eyelids a problem?*”

- Tanuj explains that Peter would probably qualify for his insurance to cover upper eyelid surgery (that’s how droopy they are)

Peter reacts, “*Holy crap… I had no idea how bad I was.*”

- If we did a visual field test on you where you relax your forehead muscles and you were required to look straight ahead and hit a button every time you saw a light flash in your peripheral field, and we did the same test with your eyelids taped up, you’d probably have a 30% difference in your peripheral field

Peter asks, “*So this could be affecting my driving?*”

- Probably
- You’re probably finding yourself having to look a little harder at your blind spot because of that

It becomes a very complicated issue

- One of the most common things Tanuj sees in his [practice](https://toceyeandface.com/physician/dr-tanuj-nakra/) in Austin is that patients will come in and say, “*I think I need to have my eyelids done.*”
- And then we say, “*Yes, but*” … And the thing is, people don’t realize that the face is not isolated into individual pieces of anatomy
  - Your eyelid is connected to your eyebrow, which is connected to your forehead
- So if we’re going to do an upper eyelid surgery, because you’re constantly lifting your forehead muscle to be able to see better, your brain’s compensating for this pathology
- If we do an upper blepharoplasty (whether it’s insurance or cosmetic or whatever), all of a sudden that visual field will improve and your frontalis muscle will automatically relax and your brow will come down
- And it’ll create a new problem that you didn’t know you had
- These are some of the conversations he has with patients

***Maybe we leave your upper eye area alone unless you’re also ready to have your forehead lifted or at least have what we call a medical brow lift with Botox***

- Muscles pull the eyebrows up, muscles pull the eyebrow down
- If you preferentially inject Botox into the depressor muscles [eyebrow], naturally, the tone of the [frontalis](https://en.wikipedia.org/wiki/Frontalis_muscle) will lift the forehead a little bit, even without wrinkles showing
- Tanuj tells patients, “*Look, if we do an upper lid surgery, that’ll be fine. But we either have to commit to regular use of Botox to keep your eyebrows in check, or we have to do a brow lift at the same time*.”

**Where’s the incision for the brow lift? Do you do it through the same incision?**

- When it comes to designing surgeries, Tanuj trains fellows and residents that there is no single surgery

> “*Every single surgery is totally custom designed for the individual patient’s anatomy*.”‒ Tanuj Nakra

- There are general patterns we use, but we should always infinitely manipulate the procedure to achieve the goal of what we’re trying to do artistically
- For Peter, it’s complex, because we usually would hide incisions behind the hairline (and he doesn’t have hair)
  - It is possible for you to have an endoscopic forehead reset procedure, and we would make the incisions further back and smaller
  - That would be a more technically challenging procedure, but there’s a way to lift the forehead with incisions that would not be socially visible
  - And then those incisions can be closed in such a way that as time goes by, you can get those scars to become what Tanuj calls ‘socially invisible’
    - Especially with post-surgical treatments like microneedling with 5-fluorouracil and topical treatments

Peter reacts, “*It just to me seems like I could never commit to that much work. You know what I mean? So does that mean I’m just stuck with droopy eyes?*”

- In that case, Tanuj recommends a blepharoplasty (which is an upper lip surgery), but we’re going to under-treat you
- We’re going to do less than what you think you need
- It’s not going to make a huge shift, but on the other hand, we also don’t want to change the entire relationship neurologically that your frontalis muscle has with your eyelid

Tanuj explains, “*By taking a patient through all the potential pathways, they sometimes recognize they can’t get what they thought they were coming for, and we’re going to under-treat them so we avoid a potential problem.*”

**Similar things happen with the under-eye area**

- This is pretty complex to

*Peter has*

- Bulging fat visible in the under-eye area
  - Which is exactly the same contour that you had when you were 20
  - It’s just become unveiled because you’ve lost volume and the cheek has descended
- Now we’re looking at the orbital retaining ligament and the malar ligament
  - This line right here corresponds to when you’re looking at a skeleton and there’s a big circle where the eyes are supposed to be
  - This is that bottom half of the circle where the ligament is sticking down

**⇒** If you put your finger on the skin right below an eye bag, you’ll be touching the edge of your orbital rim bone

Tanuj recommends, “*If we’re going to do something that is definitive to treat that, it’s going to also have to treat the volume issue in your cheek. It’s also going to have to address some of the skin textural issues in the region*.”

**The malar mound under the eye**

- Some people have an issue where there’s a triangle that catches between the orbital rim (which is that hollow we were talking about in the under-eye area) and another line that exists in the cheek a little bit lower ‒ it creates a triangle where fluid can collect
  - That area is called a malar mound [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f7-tanujandsuzan.png)

**Figure 7.** Diagram of the under eye area showing the malar mound. Image credit: [*Plastic and Reconstructive Surgery* 2017](https://pubmed.ncbi.nlm.nih.gov/28027251/)

- Peter’s got that little triangle right here on both sides
- The malar mound is kind of like a sponge under the skin: it collects fluid
  - It’s worse in the mornings because we’re laying flat and we have a little more edema in our face
  - If you’ve had salty food the night before, it’ll puff up a little more
- People will use Preparation H
  - This is a time-tested home remedy to try to shrink down that swelling that’s present there

***This would have to be part of what’s addressed if we were going to address Peter’s under-eyes***

**Tanuj’s recommendations for Peter**

- Do something that would reduce the bulk of the bag [under the eye], fill volume in the cheek, smooth the skin out, and address that malar mound
- This is a common maneuver of Tanuj’s practice, we would (under anesthesia) make a hidden incision behind the eyelid and take those eyelid fat pads that are making that bag and create a pocket down in front of the cheekbone where the volume loss is occurring and where the ligaments are showing their hollowing, and then move that fat down
  - That’s called a **transposition lower blepharoplasty**

## The evolution of facial cosmetic surgery techniques, the serious risks involved, and how physician skill and procedure selection greatly impact outcomes [2:21:30]

**Tangent on the evolution of aesthetic surgery**

- One of the big changes that’s happened in aesthetic surgery from 1995 to now is back in the old days of cosmetic surgery, there was a lot of cutting fat out, cutting skin out to make eyelids look tighter, cutting skin in front of the ears to tighten the face, doing surgeries that mostly remove tissue
- Now we’re becoming much more sophisticated where we’re actually manipulating the ligamentous attachments to the bone

Peter asks, “*You don’t have to remove the skin, necessarily?*”

- You don’t have to remove as much
- Suzan adds that you can tighten the skin with lasers and peels, rather than cutting it out

**Back to Tanuj’s recommendations for Peter**

- Tanuj would transpose fat to kill two birds with one stone: reducing bulk in one area and adding volume in another area
  - It’s killing three birds, because it would basically eliminate the visibility of the ligament where there’s fat under it now, which is pushing it forward
- Then we would do something to improve the skin, as Suzan said, either a laser surfacing or a chemical peel

**There’s a new technique where we’re injecting tetracycline into areas of swelling of the face**

- It’s been around for several years now, and we’ve got pretty good experience with this technique
- [Tetracycline](https://www.aocd.org/page/Tetracycline#:~:text=Non%2Dantimicrobial%20uses%20of%20tetracyclines) is an old drug that was repurposed by the pulmonologists to address pulmonary issues where they want the pleura to stick to the lining better
- Because it has that property of basically creating fibrous attachments, it can be used to shrink that sponge down by injecting delicately into the malar mount to kind of flatten it
  - Tanuj would recommend that for Peter

**What can go wrong here**

- Many people contemplating something like this first realize that this is a cosmetic procedure, it’s not essential
- If you don’t look better when it’s done, it’s the worst possible outcome
- The face is the most visible part of your body
- Peter has heard stories of women who have breast augmentations where they have complications, and at least the breasts aren’t always visible (meaning the actual skin itself)
  - So even if you have to re-operate and it creates another scar, it’s only visible to her partner
- But here, it’s just the highest stakes game

**How do you navigate complications, risks, and mitigation strategies?**

- Earlier they discussed the importance of whoever’s doing your treatments [that they are under the supervision of a physician]

*You want to make sure whoever’s doing your treatments is*

- Well-trained and qualified to do the injections
- Can manage the complications (because everyone [provider] is going to have complications)

Some complications are vision-threatening or tissue-threatening

- When you’re treating around the eyes, for example, or even into the temples, there are reported instances of stroke and death and vision loss
  - Including treating around the nose because all of these vessels interconnect with the internal [carotid system](https://en.wikipedia.org/wiki/Internal_carotid_artery)
- So anywhere you inject a filler and you get into a vessel on the outside of the skin, you can create an embolism, and it’s going to go follow the path of least resistance
  - Once you bolus it into the tissue, it’s going to backflow
  - But then it’s going to be pushed forward again
  - It’s going to go to the ophthalmic artery
  - It may go into your central nervous system, into your brain, and the vasculature there create a stroke
- Some of the more serious strokes were caused by people injecting fat with needles, but all of these other complications really come from injecting fillers in this kind of central face area

*To avoid these complications*

- There is a technique
- There is knowledge of the anatomy
- There’s knowledge of how to do very little pressure, aspirate where you need to aspirate depending on the filler you’re using
- Watching the tissue, looking for signs of any kind of embolism that’s forming

**What about the, obviously less consequential but still troubling side effects where, hey, the person doesn’t have a good cosmetic outcome?**

- So they didn’t have a stroke
- They’re alive and their vision is fine, but they don’t look better

*What are the things that go wrong here?*

- Tanuj sees a lot of patients referred in with complications where he has to try to identify how to improve a bad outcome
- The most common reasons why bad outcomes occur in the world of cosmetic surgery are:
  - 1 – The wrong procedure was done (more common that one might expect)
  - 2 – There was a technical issue where the surgery wasn’t done correctly

Tanuj shares, “*I will certainly have patients where I’ll do my very best and one side will be a little asymmetric. And six months after surgery we might have to go to the procedure room to do a minor touch-up to kind of enhance things.*”

- But when it comes to the more substantial disfiguring situations where people have been ‘botche’, it’s usually the wrong procedure was done or it wasn’t done well
- That is a very scary topic for listeners to be thinking about if they’re even considering going down the pathway of rejuvenation or some sort of plastic surgery procedure on their face
- It can be very confusing because you’re getting so much information from marketing and social media
  - And physicians who perform cosmetic procedures are advertising and showing their best before and afters

## How patients can make informed and safe choices when selecting a cosmetic surgeon [2:27:15]

**How does someone figure out how to navigate the world of cosmetic procedures?**

- The best advice that Tanuj could give someone who’s thinking about going down this pathway is, “*You got to take the narrative into your own hands*.”
- You have to understand your own anatomy
- You have to do a deep dive in understanding all the techniques that are available to address the issues that are your particular concern
  - And that might require multiple consultations
- It might require choosing good resources online which are usually society websites; Tanuj recommends:
  - [The American Academy of Dermatology (AAD)](https://www.aad.org/public#)
  - [The American Academy of Cosmetic Surgery (AACS)](https://www.cosmeticsurgery.org/page/Patients)
  - [The American Society of Plastic Surgeons (ASPS)](https://www.plasticsurgery.org/)
  - These society websites will have accurate information on procedures
- You should avoid getting secondhand information from people you know or from social media

> “*You got to do your homework. You have to learn the anatomy, you have to understand your own situation and your choices that are available to you.*”‒ Tanuj Nakra

- It’s analogous to dating and marriage
  - How do you know when it’s the right person? You just know

**When choosing a doctor, what are the questions you’re asking and what are the red flags you’re looking for?**

*And what are the green flags that are making you say I like and trust this person?*

- It starts with your rapport ‒ you can quickly get a sense with the doctor you’re working with, if you and he or she can see eye to eye
  - In terms of what you are seeing, what they’re seeing, how knowledgeable they are describing the procedures that they’re suggesting for you
- For example, if they’re telling you you need a brow lift and you’ve seen several other people and no one mentioned a brow lift, maybe you need to think about: why did this person mention a brow lift and the other ones didn’t?
  - Or if everyone says you need a brow lift and one person says you don’t, you have to figure it out and go back and look in the mirror and try to understand what they’re trying to point out to you as to what makes sense from that standpoint
- Is it a comprehensive approach or are they just attacking basically the issue that you have that you are bothered by?
- Suzan thinks people should take a comprehensive approach and at least get that information, even if they don’t act on all of that
  - The person evaluating you should give you an overall look at everything just like Tanuj and Suzan did with Peter
    - Addressing all the different areas that maybe Peter didn’t even know to ask about
- On top of that, understanding the doctor’s strong suit
- For example, Suzan doesn’t do rhinoplasties
  - If she starts telling a patient she’s going to do a rhinoplasty on them, they should run

*Questions to ask*

- How often are you doing this?
- What are your complication rates?
- What is the re-treatment rate?
- How happy are your patients with this procedure?

*Suzan can show patients pictures of before and afters from previous patients (multiple ones)*

- For example, a face lift, she’ll show them different faces because everyone has a different shape face
  - You can’t get the same result depending on their anatomy
- She’ll show them different things and say, “*Now, this one looks more like your neck and your jawline. This is kind of the result you can hope to get.*”
- She’ll tell them what complications she sees with her hands as well as the overall complications [that are seen with a particular procedure]

*That’s exactly what Peter tells people when they’re interacting with surgeons*

- It’s one thing to know the complication rate when you’re getting a colonoscopy
- It’s another thing to know their complication rate and their patient population because it’s not always the case
- For example, if you’re having cardiac surgery, a low complication rate isn’t always a great thing
  - It might mean low complexity

*Tanuj adds*

- Having the right training and board certification is important
  - Whoever is doing a procedure should have more certification in the specific area

Peter asks, “*For eyes: what percentage of people doing eye procedures like a lift, a blepharoplasty, would be oculoplastics trained? Is that a rare thing? Is that uncommon or common?*”

- It’s the most common procedure that an oculoplastic surgeon would do primarily
- A lot of non oculoplasticians would do that procedure
- In 2025, there’s so much more overlap that’s happening than what used to exist because each field that has an aesthetic aspect to it
  - We’re talking about dermatology, plastic surgery, ENT, ophthalmology, oral maxillofacial surgery ‒ these are the most common specialties that have an aesthetic overlap
  - The aesthetic focus in these training programs has dramatically ramped up in the last 20 years where part and parcel of these training programs include aesthetic surgery
- In addition to all those certifications, experience matters

Peter asks, “*What’s the minimum number of procedures you want to see done by the practitioner in a year?*”

- It really depends
- For a rhinoplasty or a facelift, you’re going to want to have someone who’s at least doing 25 a year
- It’s also is going to matter how many other procedures they do too
  - Someone who’s doing face and body might be doing a lot of body liposuction, so they’re doing facelifts but they’re doing also body lipo
  - Maybe they’re doing eyes, all of that

Peter asks, “*Do you want generalists or do you want specialists?*”

- In Suzan’s practice, she does 5 things and she does those 5 things a lot
  - She doesn’t do only one
  - And you don’t do only one even though you’re ocular plastics and your facial plastics as well though
- Tanuj agrees and adds that he doesn’t do any body surgery, so he’ll refer that out to people who specialize in it

***Most people who do body cosmetic surgery will focus on body cosmetic surgery because facial cosmetic surgery is a different animal altogether***

- That that kind of specialization matters

Tanuj adds, “*I was a young surgeon once, and certainly going to a surgeon who’s right out of training can be fine for a limited isolated procedure. But I’m sorry to the young physicians in the audience… a few years of training is usually helpful in building your repertoire and experience to be able to handle complications*.”

- Sophisticated listeners would probably naturally end up choosing more experienced surgeons for that reason

Another important thing is that this is a creative specialty we’re talking about

- You want to choose someone who is evolving and moving with the times and preferably is helping to advance that edge of medicine
- That means that they’re constantly thinking and questioning and improving the results and not resting on laurels and not stagnating in one particular way of performing a procedure
  - That’s a very, very important aspect of trying to identify someone

**You normally wouldn’t associate cosmetic surgery with an academic affiliation**

- If you had an oncologic issue, there’s an advantage to being in an academic setting because of the research and the affiliation with other branches of oncology
- What Tanuj is saying would probably fit more neatly into the box of someone with an academic affiliation

Tanuj explains, “*The interesting thing about aesthetic surgery is that it’s a little bit of the black sheep in the world of medicine.*”

- Academic cosmetic surgery, academic plastic surgery is different from the traditional sense of what academic might mean

***In the world of facial aesthetics, you can have a single surgeon in private practice, no university affiliation, who is a 100% academic because they are publishing, they’re going to meetings, they’re lecturing***

- They are helping to move the dial in the artistic world of what we’re doing in facelifts or eyelid surgeries or brow lifting
- It might be someone who’s at university full-time, but it doesn’t have to be
- And that’s very unique to aesthetic surgery
- Suzan points out that universities don’t support their aesthetic doctors
  - A lot of times universities cannot figure out a model that works for them to profit share or to find a compensation model for an aesthetic doctor that’s appealing to them to make them not go into private practice
  - So they end up shortchanging themselves and then the doctors leave and they go into private practice
- If you can get the universities to wrap their head around how to build out a really strong academic practice like Suzan did with the [University of Pittsburgh Medical Center](http://dermatology.pitt.edu/)
  - They are rare
  - They were one of the first in the nation to purposely build an academically-based cosmetic surgery practice with the intention of training plastic surgery residents
    - With rotations in ocular plastics, facial plastics
    - Dermatology residents and people from around the world
- This makes a lot of sense to Peter because of the amazing overlap between surgery in general, especially oncologic surgery and reconstruction
  - Every time a woman undergoes a mastectomy, she should be immediately plugged into a plastic surgeon to, if nothing else, make sure that that reconstruction is as cosmetically pleasing as possible
  - Then you think about all the head and neck cancers and things like that
- There’s a clear incentive (maybe incentive is the wrong word), just if nothing else, a business case to be made for better patient care with the integration of that type of service
- Suzan points out that the universities can’t see that
- The problem is they think it’s a one-size-fits-all, and they don’t understand the differences
  - For example, your cosmetic practice has to have a more aesthetic look
    - It’s going to cost them more to build it out
    - They’re going to need the devices, they need investments
    - It’s really hard to get some of these universities to see that
  - You have to work with them and become your own business manager, and propose to them a business plan, return on investment

**Practical advice for listeners trying to find someone in the category of aesthetic surgery:** find someone who is speaking at conferences, teaching, and involved in the cutting-edge of medicine

- Another thing mentioned earlier is asking how often they are receiving complications and managing them
  - That’s probably a sign of skill and seniority in the field

## A comparison of ablative versus non-ablative skin resurfacing treatments, laser vs. peels, and more [2:38:45]

- We can’t get out of this podcast without understanding the difference between lasers, micro abrasions, micro needling, chemical peels

Peter adds, “*You mentioned resurfacing, you mentioned my skin sucks. So clearly before I go on the path of my rejuvenating anti-aging protocol, I might as well do something to fix the situation we have going on here*.”

- This is a massive subject to cover
- We could do a crash course

**The difference between ablative and non-ablative procedures**

- There are various technologies that will in a controlled manner injure the skin to harness the body’s natural healing cascade, which then will produce the aesthetic benefits we’re looking for

***The goal is more collagen production, smoother skin, less pigment issues***

**⇒** The bottom line is there’s a relationship with how aggressive the treatment is and how much of an aesthetic improvement you’re going to get

- But the more aggressive it is, the more downtime there is
  - So that’s always the balancing act
  - That’s why there’s such a confusing array of options that exist because there’s a huge spectrum going from the least invasive (which has the least result) to the most aggressive (with the best result).

***An ablative treatment means it penetrates the skin, and non-ablative doesn’t penetrate the skin***

*Non-ablative procedures (less severe, shorter recovery, less overall response)*

- Your **topical skincare regimen**
  - That is going to remodel the skin and set the stage for you to even prime it so you make more collagen
- Then you can do things such as **light chemical peels**, which are only going to affect the [epidermis](https://en.wikipedia.org/wiki/Epidermis) of the skin
  - [the figure below reviews the anatomy of the skin]

![](https://peterattiamd.com/wp-content/uploads/2025/06/f8-tanujandsuzan-1024x743.png)

**Figure 8. Anatomy of the skin**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Skin#Detailed_cross_section)

- You can do things like [non-ablative fractional lasers](https://www.asds.net/skin-experts/skin-treatments/non-ablative-laser-rejuvenation), and those are going to send tiny fractionated beams of light onto the very surface of the skin and just damage the upper layers of the epidermis

***That’s going to stimulate a cascade of cytokines to build on the collagen and texture, but it’s going to be minor and they might help with some minor pigmentation issues***

- Those are non-ablative devices for resurfacing
- We also have **non-ablative vascular lasers**: those are lasers that are going to penetrate with a beam of light to hit the dilated blood vessels in people who have [rosacea](https://en.wikipedia.org/wiki/Rosacea)

Peter asks, “*What’s the brand name of a non-ablative fractional?*”

- [Fraxel](https://www.fraxel.com/) or [Clear + Brilliant](https://www.clearandbrilliant.com/), within those there are different
  - Fraxel has multiple different ones
  - Clear + Brilliant is just superficial
- Then you have non-ablative things like a **vascular laser** that will help treat broken blood vessels, scars, texture change
  - Even though it’s shattering some of the dilated blood vessels deep in the skin, it’s not leaving an open wound on the surface

***So when we say non-ablative, there might be things happening deep down, but the surface of the skin is intact so there’s no raw wound***

Tanuj adds, “*That is probably one of the most high yield areas for someone to try out as an initial intervention with a physician or provider because the downtime is easy.*”

- For example, [intense pulse light (IPL)](https://en.wikipedia.org/wiki/Intense_pulsed_light) or [broadband light (BBL)](https://www.dukehealth.org/blog/considering-broadband-light-therapy-heres-what-you-need-know), those are in the category of non-ablative light treatments, and it’s a huge, huge category
  - There are so many devices in this category that it would be kind of silly to even list them
  - They’re very effective in that they don’t have a lot of downtime and produce improvements that are real for patients
- [Moxi](https://sciton.com/moxi/) is another non-ablative laser
  - It is semi-ablative because you’re literally piercing the skin with a bunch of needles and delivering radio frequency energy through those needles
  - And those will stimulate collagen
- Anything that generates heat in the skin to a certain temperature, will then cause a formation of something called [heat shock protein](https://en.wikipedia.org/wiki/Heat_shock_response)
  - And that causes a whole cascade of other activity within the dermis of the skin to make you produce collagen, elastin, shrink the overactive sebaceous glands and reduce some of the dilated blood vessels

**⇒** There is a lot of benefit beyond just treating the vasculature that you see

**Suzan tells patients, “*****If we treat their rosacea and they get improvement after 2 or 3 sessions. They should come every year and repeat it even if their rosacea is quiet because it really does help with anti-aging*****.”**

*Ablative procedures include deeper chemical peels*

- We’ve got the [modified TCA peels](https://www.asds.net/skin-experts/skin-treatments/chemical-peels), we’ve got [modified phenol peels](https://www.plasticsurgery.org/cosmetic-procedures/chemical-peel/deep)

**Peter’s takeaway about ablative peels**: achieve a better result, greater downtime, and treatment is needed less frequently

- You don’t need to worry about brand names at this point
- Ask the practitioner about the type of treatment (an ablative peel)
- It’s a big mistake to come in and say, “*All my friends are having Moxi. I want Moxi.*”
  - Your practitioner may have something that gives similar results or even better results
  - Maybe it’s not the right choice for you even though your friend thinks you should get it

> “*The field is so confusing to consumers (and honestly even to practitioners) because it’s a gold rush. There’s so much money to be made in this area*.”‒ Tanuj Nakra

- Every company is getting private equity money and getting an FDA approval for some kind of device because they want a piece of the action
- And they’re purposefully confusing everybody because it’s like snake oil, everybody wants to sell their product
- And some of the products work well, some don’t

**Any products you think people should just absolutely avoid just based on lack of efficacy?**

- No

**⇒** Suzan cautions patients under the age of 40 (even up to 45) to avoid things such as [ultrasound tissue tightening](https://www.asds.net/skin-experts/skin-treatments/ultrasound-therapy-for-sagging-skin), [radio frequency tissue tightening](https://en.wikipedia.org/wiki/Radio-frequency_skin_tightening) at that young of an age because there is some fat atrophy that happens (prematurely aging their face)

***Tanuj agrees that ultrasound based energy is the category that has the most hoopla with the least effect***

- There once was a time where that was the only non-surgical option for tightening the neck
  - But it didn’t do a great job, and most people have left it by the wayside
- Suzan likes it in addition to a bio-stimulatory filler
  - You inject a little sculpture under the skin and then you come over it with an ultrasound
  - Tanuj agrees that synergistic properties could exist for those devices

 Suzan adds, “*If you know your physics with all these devices, you can achieve so much with your lasers beyond what the company tries to sell you.*”

**How do you decide between ablative and non-ablative therapy?**

*Once you commit to an ablative therapy, how are you deciding between a chemical peel, a laser, a micro needle?*

- Peter vaguely remembers his wife saying something about if you had [melasma](https://en.wikipedia.org/wiki/Melasma), you couldn’t do this one but you could do this one

*What are some of the dos and don’ts as you navigate that?*

- There are a lot of nuances to this conversation, but to generalize a little bit, chemical peels are generally safe for all skin tones generally
- Ablative laser resurfacing can be riskier for higher fit spectric skin types that have more pigmentation because the melanin cells are sitting deeper in the skin
  - And the deeper the laser goes, the more it can create permanent injury to pigment cells and create permanent pigment problems
- Whereas the chemical peels, you can control that depth a little differently, and that’s the one that Tanuj thinks is worth mentioning

Peter asks, “*So I should not do a laser peel?*”

- You can have a laser, but you’re the kind of person who needs a lot of preparation and caution heading into it
- You would need to probably get onto a regimen to control your pigment cells with [hydroquinone](https://www.ncbi.nlm.nih.gov/books/NBK539693/)
- Why would Peter bother? Why take the risk?
- Because the results could be better

**The most effective non-surgical skin interventions**

- Tanuj recommends interventions in the category of ablative lasers and phenol peels because they go the deepest
- Suzan adds TCA peels
  - Deep TCA peels are something that should be done by someone who really knows what they’re doing

## How treatments are chosen and customized based on patient-specific factors [2:48:00]

*Sometimes Suzan will do all 3 on the same patient, but she will pick and choose where she does it*

- On most of their face, she may do a medium-depth TCA peel
  - Especially because she can get the ears, into the brows, she can feather onto the neck, and into the hairline
  - So she doesn’t leave any area un-resurfaced
- The medium-depth peels go the the level of what’s called the [papillary dermis](https://en.wikipedia.org/wiki/Dermis#Papillary_dermis), which is the sweet spot for tissue tightening
- These peels penetrate and they percolate into pores
- Suzan loves peels for large pores
  - The solutions sit in the pores and they’ll just go a little bit deeper just in those pores, and as the tissue heals, they’ll contract
- She may take a patient who has very deep perioral lines and use my fractionated ablative [CO2 laser](https://www.ncbi.nlm.nih.gov/books/NBK560544/) on those
- Then someone with redundant skin on the lower eyelids, she may take my [phenol peel](https://www.ncbi.nlm.nih.gov/books/NBK547752/#:~:text=Phenol%20and%20croton%20oil) and apply it there
- In some patients, depending if they don’t want an eye lift or if they had an eye lift a number of years ago, and they’re just starting to get redundant skin, Suzan may just ablate that tissue with either the laser or the phenol peel
  - This provides a mini eye lift again that might buy them 2, 3 more years

**What is the downtime from an ablative intervention?**

- Every treatment is customized to the patients, who can vary

***In general, a patient who’s going to have an ablative CO******2*** ***laser (the relative gold standard for an ablative laser), is going to have 7-10 days of requiring an occlusive dressing with some kind of ointment***

- That’s some real downtime there
- Then from weeks 1-3, their skin will be transitioning and epithelializing to start to return to normal activities

***They’ll still scare children at a grocery store for 3 weeks because they’ll be red***

- A lot of redness and swelling still
- Beyond 3 weeks, they can use concealer, and they can kind of get back to life
  - Which we actually encourage them to do because it’s a built-in UV protection

***Without makeup on, some people can have redness for months***

**How often do you expect this person to do this procedure?**

- This might be once every 5 or 10 years to have a full ablative CO2 laser

**Is it uncomfortable?**

- If they’re awake it can be
- These can be done under some sedation
- It’s also quite common these days to have these done with a [nitrous](https://en.wikipedia.org/wiki/Nitrous_oxide_(medication)) delivery device
  - There are now FDA-approved devices that mix oxygen and nitrous so that it can be done in the office without an anesthesiologist because they’re getting 50% oxygen, but yet they’re getting the benefit of the nitrous as well (like laughing gal, [Pro-Nox](https://www.pro-nox.com/))
- Peter thinks that sounds absolutely unappealing

Tanuj points out, “*I also painted the picture of the most aggressive skin laser that we do, and of course it can be dialed down like if a patient has a certain timeframe in mind*.”

- Peter thinks a week offline would be doable but tough
  - 3-4 weeks offline is not an option

**Some lasers are still ablative but are dialed down in their intensity**

- We’re talking about [fractionated lasers](https://www.ncbi.nlm.nih.gov/books/NBK557474/) at lower intensity, they can have a downtime that’s a week (more or less)
- It’s not going to produce the same results, but the effects stack over time
- So if you committed to doing a **light erbium laser**, the recovery is a little bit faster
  - The reason why Tanuj is talking about erbium laser instead of a CO2 laser is because the erbium lasers tend to burn with a little less heat thermal injury
- If you’re committed to doing this once a quarter, as time goes by, you would get a similar effect to the full ablative CO2 laser that you can do in one sitting

**You can manipulate other things**

- Suzan will take a [Clear + Brilliant](https://www.clearandbrilliant.com/) and apply a light chemical peel solution on top of that the same day (2 non-ablative therapies)
- Then you get like 3 or 4 days of peeling and then you’re done

**For someone like Peter, because you’re a male, you have thicker skin**

- You need us to push it a little more than just what the Clear + Brilliant will do or the light peel by itself
- But synergistically, they can have a nice effect
- And over time there’ll be cumulative improvement in your skin, especially if you follow your home regimen.

Suzan’s advice, “*Really think about it hard and embrace this investment in yourself because you do everything else right. You eat, you exercise, you watch the sun. It’s much, much better to do this now at your age than to wait 5 or 10 more years and say, I wish I had done it because at that point what you need might be a lot more drastic.*”

## The lifelong human desire to align physical appearance with self-identity [2:52:45]

**Tanuj brings this full circle**

- Beauty and aesthetics is an integral part of being human
- That’s why we’re even having this conversation because people really want to know how to navigate this world of aesthetics
- Choosing to make changes that are appropriate for your situation, has the potential of increasing quality of life
- Humans as we age and we live longer and longer and longer, you may have someone who’s 60 or 70 years old who’s following Peter Attia’s regimen, and they’re out there playing golf, living their marginal decade in the way they want to, but they also care about their appearance
- Tanuj and Suzan have patients who are 94 years old who are coming in for skin cancer reconstruction after [Mohs surgery](https://en.wikipedia.org/wiki/Mohs_surgery)
  - And you’re not thinking at all about putting your aesthetic hat on
  - Tanuj is a reconstructive surgeon
  - This 94-year-old woman is terribly concerned about what it’s going to look like afterwards

***That desire to limit the delta of the self-discrepancy theory for ourselves continues until we’re no longer on this planet***

\*\*\*

## SUMMARY

**General Foundational Skincare and Anti-Aging Principles**

1. UV Protection: The most important tool for preventing skin and DNA damage. Use early and consistently, ideally mineral-based, tailored to skin tone and tolerance.
2. Core Skincare Regimen: Everyone benefits from daily sunscreen, retinoids, Vitamin C, and moisturizers. Specific products and timing are best curated by an expert based on skin type, genetics, and lifestyle.
3. Longevity-Focused Lifestyle: Sleep, mitochondrial health, stress management, and DNA preservation amplify both systemic and facial aesthetic longevity.
4. Emotional Health and Self-Image: Meaningful relationships, grounded peer circles, a healthy sense of self-worth, and therapy profoundly affect one’s aesthetic satisfaction.
5. Aesthetics 3.0: A more sophisticated, long-term future-looking three-dimensional, age-appropriate, and dynamic approach to appearance – moving beyond superficial and short-term beauty.

**Advanced, Personalized, and Emerging Aesthetic Strategies**

1. Chemodenervation (Botox/Dysport and others): Effective in preventing wrinkles and reducing the signs of aging. Should be highly customized to facial anatomy, symmetry, and individual goals.
2. Periodic Professional Treatments: Intermittent chemical peels and laser therapies, delivered by experienced professionals, address texture and pigmentation changes.
3. Conservative Volume Restoration: Thoughtful, reversible filler injected by skilled practitioners can subtly address age-related volume loss without visible distortion.  Be careful of overfilling!
4. Genetic Aesthetic Proportion Optimization: Strategic interventions (filler, asymmetric chemodenervation, minimally invasive procedures) can scientifically enhance facial beauty when done tastefully and scientifically.
5. Personalized, Long-Term Aesthetic Care: Ideally guided by a trusted specialist invested in thoughtful, ongoing care- accounting for anatomy, culture, and personal preferences can provide customized tasteful non-surgical and surgical treatments.
6. Emerging Therapies: Autologous tissue technology, bioengineered aesthetic support factors and advancements in energy-based treatments show promise for future rejuvenation and optimization strategies.

---

## Selected Links / Related Material

**TOC Eye and Face fellowship programs**: [Fellowship Programs](https://toceyeandface.com/fellowship-programs/) | TOC Eye and Face (2025) | [6:15]

**Episode of** ***The Drive*** **with Brett Kotlus**: [#13 – Brett Kotlus, M.D.: How to look younger while we live longer](https://peterattiamd.com/brettkotlus/) (September 3, 2018) | [8:15]

**Loss of bone in the face with aging**: [15:15]

- [Relative maxillary retrusion as a natural consequence of aging: combining skeletal and soft-tissue changes into an integrated model of midfacial aging](https://pubmed.ncbi.nlm.nih.gov/9655429/) | *Plastic and Reconstructive Surgery* (J Pessa et al. 1998)
- [Changes in ocular globe-to-orbital rim position with age: implications for aesthetic blepharoplasty of the lower eyelids](https://pubmed.ncbi.nlm.nih.gov/10541847/) | *Aesthetic Plastic Surgery* (J Pessa et al. 1999)
- [Aging and the shape of the mandible](https://pubmed.ncbi.nlm.nih.gov/18176221/) | *Plastic and Reconstructive Surgery* (J Pessa et al. 2008)

**Book on the psychology of beauty**: [Survival of the Prettiest](https://www.amazon.com/Survival-Prettiest-Nancy-Etcoff/dp/0385478542/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.f2Og853JTwZzlHn3ejMLuKlWF43Erqnhjr9it0KzNxM3XTaccr3HujfYuSStcg6csqsPheK9pNPivh347EPWQkZIokx0ZNsYW872nWU44oeznIMTCw45nUn2PK0R5_IB.ScvcORVP8NPkBYyNZIs9y8u56HTkL6Z-LNzmUr77RDE&qid=1747401045&sr=8-1) by Nancy Etcoff (1999) | [26:00]

**Study of infants preference to look at beautiful faces**: [Infant Preferences for Attractive Faces: A Cognitive Explanation](https://sites.pitt.edu/~strauss/rubenstein1999.pdf) | *Developmental Psychology* (A Rubenstein, L Kalakanis, J Langlois 1999) | [26:45]

**Austrian study finds daily sunscreen helpful for preventing aging**: [Sunscreen and prevention of skin aging: a randomized trial](https://pubmed.ncbi.nlm.nih.gov/23732711/) | *Annuals of Internal Medicine* (M Hughes et al. 2013) | [59:00]

**Tanuj’s skincare line**: [AVYA Skincare](https://www.avyaskincare.com/collections/all) | AVYA Advanced Ayurvedic Skincare (2025) | [1:01:45, 1:21:00]

**Suzan’s skincare line**: [SUZANOBAGIMD­® Skincare Products Collection](https://www.obagi.com/collections/suzanobagimd-skin-care) | OBAGI Medical (2025) | [1:01:45]

**Society websites to understand cosmetic techniques**: [2:27:45]

- [The American Academy of Dermatology (AAD)](https://www.aad.org/public#)
- [The American Academy of Cosmetic Surgery (AACS)](https://www.cosmeticsurgery.org/page/Patients)
- [American Society of Plastic Surgeons (ASPS)](https://www.plasticsurgery.org/)

\*\*\*

**Skincare Products**

*Disclaimer*: Tanuj and Suzan each have their own line of skincare products ([AVYA Skincare](https://www.avyaskincare.com/pages/the-founders), [SUZANOBAGIMD™](https://www.obagi.com/collections/suzanobagimd-skin-care), and [Veea Face](https://veeaface.com/collections/dr-suzan-obagis-essentials)) and have curated a “perfect list” of skincare products (below) which includes products from their own lines as well as other highly effective products they are not affiliated with.

**Cleansers**

- AVYA Skincare – [Gentle Cleanser](https://www.avyaskincare.com/collections/skincare-bestseller-sets/products/gentle-cleanser)
- La Roche-Posay – [Toleriane Hydrating Gentle Facial Cleanser](https://www.laroche-posay.us/our-products/face/face-wash/toleriane-hydrating-gentle-facial-cleanser-tolerianehydratinggentlefacialcleanser.html)
- Veea Face – By Dr. Suzan Obagi- [Clarifying Gel Cleanser](https://veeaface.com/products/clarifying-gel-cleanser)

**Eye creams**

- AVYA Skincare – [Eye Bright Cream](https://www.avyaskincare.com/collections/dark-circles-or-puffy-eyes/products/eye-bright-cream)
- Neocutis – [Lumiere Firm Riche Eye Cream](https://www.neocutis.com/product/lumiere-firm-riche/)
- Skinmedica – [Instant Bright Eye Cream](https://www.skinmedica.com/us/skin-concern/aging/96379.html)
- Veea Face – By Dr. Suzan Obagi- [Revitalizing Eye Gel Crème](https://veeaface.com/products/revitalizing-eye-gel-creme)

**Serums**

- AVYA Skincare – [Power Serum](https://www.avyaskincare.com/products/anti-aging-power-serum)
- Obagi Medical – [Suzan Obagi MD – Super Antioxidant Serum](https://www.obagi.com/products/suzanobagimd-super-antioxidant-face-brightening-serum)
- Skinceuticals – [CE Ferulic](https://www.skinceuticals.com/skincare/vitamin-c-serums/c-e-ferulic-with-15-l-ascorbic-acid/S17.html)
- Veea Face- By Dr. Suzan Obagi – [Brightening Serum](https://veeaface.com/products/brightening-serum)

**SPF Moisturizers**

- AVYA Skincare – [Tinted Sunscreen SPF 40](https://www.avyaskincare.com/collections/skincare-bestseller-sets/products/hydroveda-sheer-tinted-moisturizer-spf40-1-and-2)
- Colorescience – [Total Protection No Show Mineral Sunscreen SPF 50](https://www.colorescience.com/products/total-protection-no-show-mineral-sunscreen-spf-50)
- EltaMD – [UV Physical Sunscreen Broad-Spectrum SPF40](https://eltamd.com/products/eltamd-uv-physical-broad-spectrum-spf-40-rosy-tint)
- Obagi Medical – Suzan Obagi MD – [Tinted Physical Defense SPF 50](https://www.obagi.com/products/suzaneobagi-md-tinted-physical-defense-spf-50)

**Retinol**

- La Roche-Posay – [Redermic R Retinol Cream](https://www.laroche-posay.us/our-products/face/face-serum/redermic-r-retinol-cream-3337872413063.html)
- Obagi Medical – Suzan Obagi, MD – [Retivance Skin Rejuvenating Complex](https://www.obagi.com/products/suzanobagi-md-retivance-skin-rejuvenating-complex)
- SkinBetter Science – [AlphaRet Overnight Cream](https://www.skinbetter.com/shop-skincare/product-category/anti-aging/alpharet-overnight-cream-865800000250.html)

**Deep Moisturizers**

- AVYA Skincare – [Hydroveda Moisturizer](https://www.avyaskincare.com/collections/skincare-bestseller-sets/products/hydroveda-moisturizer)
- Obagi Medical – Suzan Obagi MD – [Moisture Restore](https://www.obagi.com/products/suzanobagimd-moisture-restore-hydrating-face-moisturizer)
- Skinceuticals – [Triple Lipid Restore](https://www.skinceuticals.com/skincare/anti-aging-creams/triple-lipid-restore-2-4-2/S09.html)

---

## People Mentioned

- [Brett Kotlus](https://www.drkotlus.com/about/) (Oculofacial plastic surgeon who specializes in non-surgical and surgical cosmetic and reconstructive  procedures of the eye and face) [8:15, 2:00:15]
- [Nancy Etcoff](https://college.harvard.edu/academics/faculty/nancy-etcoff) (Assistant Clinical Professor in Psychology in the Department of Psychiatry at Harvard and author of [*Survival of the Prettiest*](https://www.amazon.com/Survival-Prettiest-Nancy-Etcoff/dp/0385478542/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.f2Og853JTwZzlHn3ejMLuKlWF43Erqnhjr9it0KzNxM3XTaccr3HujfYuSStcg6csqsPheK9pNPivh347EPWQkZIokx0ZNsYW872nWU44oeznIMTCw45nUn2PK0R5_IB.ScvcORVP8NPkBYyNZIs9y8u56HTkL6Z-LNzmUr77RDE&qid=1747401045&sr=8-1)) [26:00]
- [Judith Langlois](https://liberalarts.utexas.edu/psychology/faculty/jhl73) (Charles and Sarah Seay Regents’ Professor Emerita at the University of Texas at Austin) [26:45]
- [Zein Obagi](https://en.wikipedia.org/wiki/Zein_E._Obagi) (Dermatologist who is the founder and medical director of [ZO Skin Health](https://zoskinhealth.com/us/about/about-us.html) based in Beverly Hills, California; former head of the Obagi Skin Health Institute; Suzan’s father) [1:22:30]

---

![](https://peterattiamd.com/wp-content/uploads/2025/06/bio-tanujandsuzan-600x600.png)

##### Tanuj Nakra, M.D. & Suzan Obagi, M.D.

**Tanuj Nakra** earned his bachelor’s degree in biology, psychology, and fine arts from Washington University in St Louis. He earned his medical degree from Rush Medical College in Chicago. He completed his residence and fellowship training at the UCLA Jules Stein Eye Institute in ophthalmology and orbital & ophthalmic plastic surgery, respectively. Dr. Nakra is triple board-certified in ophthalmology, ophthalmic plastic surgery, and facial cosmetic surgery.

Dr. Nakra practices at [TOC Eye and Face](https://toceyeandface.com/physician/dr-tanuj-nakra/). He is widely recognized for his expertise in aesthetic and reconstructive surgery and has been named a Top Doctor by Texas Monthly, Austin Monthly, Castle Connolly and Who’s Who in Medicine for more than a decade. Dr. Nakra serves on the full-time faculty at [Dell Medical School](https://dellmed.utexas.edu/directory/tanuj-nakra) at the University of Texas at Austin, and directs the American Academy of Cosmetic Surgery (AACS) Fellowship at TOC Eye and Face. He has authored over 75 peer-reviewed scientific articles and book chapters. His research focuses on development of new surgical techniques such as electrocautery for treatment of facial veins, custom orbital onlay implants for Thyroid Eye Disease, and modified Weber-Ferguson Incision for Fibrous Dysplasia as well as advancing restorative surgery and techniques, such as fat transfer procedures. Dr. Nakra is the co-founder of [AVYA Skincare](https://www.avyaskincare.com/pages/the-founders), a medical-grade Ayurvedic skincare line. [[TOC Eye and Face](https://toceyeandface.com/physician/dr-tanuj-nakra/)]

Instagram: [Tanuj Nakra MD FACS](https://www.instagram.com/drnakra)

LinkedIn: [Tanuj Nakra](https://www.linkedin.com/in/nakra/)

**Suzan Obagi** earned bachelor’s degrees at the University of California, San Diego in biology and psychology. She earned her medical degree from the University of Pittsburgh. She completed an internship at the University of California, Irvine. She completed her residency and fellowship at the University of Pittsburgh in dermatology and cosmetic surgery, respectively. Dr. Obagi is double board-certified in dermatology and cosmetic surgery.

Dr. Obagi is an Associate Professor in the Department of Dermatology, with a secondary appointment as an Associate Professor in the Department of Plastic Surgery, and a tertiary appointment as an Associate Professor of Clinical and Translational Science at the [University of Pittsburgh](http://dermatology.pitt.edu/people/suzan-obagi-md). She is the director of the state-of-the-art [UPMC Cosmetic Surgery and Skin Health Center](https://www.upmc.com/services/dermatology/cosmetic-skin), where she also sees patients. Additionally, she serves as the Director of the Cosmetic Surgery Fellowship program at the University of Pittsburgh and directs the Dermatology Residency Program’s Surgery Core Curriculum.

Dr. Obagi is an internationally renowned expert in the area of cosmetic dermatology and surgery. She trains physicians from around the world on the latest in cosmetic and laser surgery. She has written many articles and book chapters on skin health restoration, autologous fat augmentation (fat transfer), Botox and soft tissue fillers, chemical peeling, dermabrasion, and lasers. She specializes in the latest technological advances in cosmetic surgery, including the use of laser and radio-frequency technologies. Her research interests include ways to improve adipocyte (fat) survival after transplantation to further enhance the results of autologous fat augmentation surgery, safety of skin resurfacing, and laser treatment for Raynaud’s phenomenon. Dr. Obagi used her expertise in skin rejuvenation and evidence-based research to develop the skincare lines [SUZANOBAGIMD™](https://www.obagi.com/collections/suzanobagimd-skin-care) and [Veea Face](https://veeaface.com/collections/dr-suzan-obagis-essentials). [[UPMC](https://www.upmc.com/media/experts/suzan-obagi)]

Instagram: [@suzanobagimd](https://www.instagram.com/suzanobagimd/p/C32w7YwKVzn/)

LinkedIn: [Suzan Obagi, MD](https://www.linkedin.com/in/suzanobagimd/)