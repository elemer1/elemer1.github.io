# #378 ‒ Women’s health and performance: how training, nutrition, and hormones interact across life stages | Abbie Smith-Ryan, Ph.D.

**Source:** [https://peterattiamd.com/abbiesmithryan/](https://peterattiamd.com/abbiesmithryan/)

---

Abbie Smith-Ryan is a leading researcher in exercise physiology whose work focuses on how training and nutrition influence body composition, metabolism, cardiovascular health, and women’s health across the lifespan, with particular attention on perimenopause and post-menopause. In this episode, Abbie explains how early exercise and play help build the foundation for bone health, muscle development, and cardiorespiratory fitness in girls, as well as how puberty and menstruation shape athletic performance, motivation, and recovery. She also explores how women can tailor training and nutrition across the menstrual cycle through smart fueling, hydration, and inflammation management; examines the evidence behind supplements such as creatine, omega-3s, and magnesium; and unpacks the metabolic and body composition changes that accompany the transition into perimenopause and menopause. Finally, she covers practical exercise programming for busy women, training and nutrition considerations during pregnancy and postpartum, and the evolving role of hormone therapy alongside lifestyle-based, evidence-driven approaches that help women better advocate for their health.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/abbiesmithryan/the_Drive_public.png)

Play

#378 ‒ Women's health and performance: how training, nutrition, and hormones interact across life stages | Abbie Smith-Ryan, Ph.D.

#378 ‒ Women's health and performance: how training, nutrition, and hormones interact across life stages | Abbie Smith-Ryan, Ph.D.

1x15s30s

0:002:11:30

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Abbie’s background in distance running and her interest in studying women’s health around exercise [A: 3:00, V: 0:11];
- The role of early-life exercise in building lifelong bone, muscle, and cardiovascular health in girls [A: 4:00, V: 1:23];
- Training principles for premenstrual girls, the risks of early specialization and delayed puberty from intense training, and how youth sport participation can shape bone and spinal health [A: 7:15, V: 5:00];
- Nutrition as fuel in young female athletes: supporting training, growth, and performance [A: 11:00, V: 9:03];
- Training and recovery across the menstrual cycle: recovery, nutrition, supplements, and practical strategies for performance support [A: 16:00, V: 14:51];
- The benefits of creatine supplementation and importance of protein intake across the menstrual cycle [A: 27:15, V: 27:31];
- How women should approach training intensity and volume across the menstrual cycle [A: 33:00, V: 33:57];
- How to identify and monitor the perimenopausal transition and why this phase represents a critical window for exercise and nutrition interventions [A: 37:15, V: 38:31];
- Case study: time-efficient exercise program for a busy, perimenopausal woman [A: 42:00, V: 43:51];
- Why improving body composition is a better goal than weight loss, and how to set realistic fat-loss targets in midlife women [A: 53:30, V: 56:50];
- How to preserve muscle and bone while using GLP-1 medications: resistance training, protein intake, and more [A: 58:15, V: 1:02:12];
- Designing a three-hour-per-week training plan for sustainable body recomposition [A: 1:03:30, V: 1:08:02];
- Abbie’s insights from her 20+ years of self-tracking: nutrient timing, injury prevention, excessive training, bone health, and more [A: 1:07:15, V: 1:12:18];
- How pregnancy and the postpartum period affect body composition, and how consistent exercise and intentional nutrition can prevent a permanent shift in body fat or muscle mass [A: 1:13:30, V: 1:19:13];
- Changes in muscle quality and metabolic flexibility during perimenopause and menopause, and how exercise may counteract hormonally driven sarcopenia [A: 1:21:45, V: 1:28:40];
- The biggest open questions about women’s health: combining menopause hormone therapy with exercise, GLP-1 drugs, minimizing injury risk, and more [A: 1:32:00, V: 1:40:26];
- How the training response differs between men and women, and the importance of type IIa muscle fibers [A: 1:39:15, V: 1:48:27];
- Training advice for the hypothetical 70-year-old woman who has never exercised deliberately [A: 1:47:00, V: 1:57:13];
- Misinformation about exercise and nutrition for women, injury risk, supplement hype, and the need for more nuanced messaging around hormones, recovery, and midlife training [A: 1:53:30, V: 2:05:05];
- Benefits of hormone therapy in midlife women and its interaction with exercise and lifestyle interventions [A: 2:00:15, V: 2:12:30];
- Peter’s overall take on how women should approach exercise volume and intensity at various life phases and time constraints [A: 2:03:00, V: 2:15:50]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Abbie Smith-Ryan is the Associate Chair for Research in the Department of Exercise and Sports Science, the Director of the Applied Physiology Lab, and the Co-Director of the Human Performance Center at the University of North Carolina at Chapel Hill
- She’s authored more than 180 peer-reviewed papers, books, chapters and has led NIH and industry funded trials on exercise and nutrition interventions
- Her research focuses on body composition, metabolism, and cardiovascular health
  - With a special attention to women’s health through the perimenopausal and postmenopausal transition
  - As well as overweight and obese populations
- She is also a dedicated mentor, educator, and advocate for empowering women with evidence-based approaches to health and performance

In this episode, we discuss:

- How early exercise and play shape bone health, muscle development, and cardiorespiratory fitness in young girls
- The impact of puberty and menstruation on athletic performance, motivation, and recovery
- How to tailor training and nutrition throughout the menstrual cycle
  - Including strategies for fueling, hydration, and managing inflammation
- The science behind supplements such as creatine, omega-3s, and magnesium in supporting women’s health and performance
- The transition into perimenopause and menopause, and how hormonal changes influence metabolism, muscle preservation, and fat distribution
- Practical exercise programming for busy women ‒ balancing resistance training and aerobic training for those with limited time
- Nutrition and training during pregnancy and postpartum
  - Including common mistakes and how to safely rebuild strength
- The evolving role of hormone therapy, and how women can better advocate for their health through evidence-based and lifestyle-driven approaches

## Abbie’s background in distance running and her interest in studying women’s health around exercise [A: 3:00, V: 0:11]

**Tell me a little bit about your background in terms of what got you interested in this space**

- Abbie was a collegiate distance runner, but she has always had a love of strength training, which is a little bit impeding for endurance goals
- She really fell in love with science, the ability to ask a question and answer it
- She started early with research and then fumbled her way in that space, really understanding: the more you know, the more you don’t know
  - As Peter’s friend Bob Kaplan used to say, “*The further you get from shore, the deeper the water gets.*”

*You’re a distance runner. In college, that’s what, 5K, 10K?*

- 3K, 5K, 1,500, 800 (if her coach was mad), she adds, “*I’m not that fast.*”
- Peter’s daughter runs track and he feels like the 800 is the worst, most painful even in the lot
  - Abbie would add the 1500: you have to do 2 more laps at a similar pace
  - There is something about that approximate 2 minute all-out effort that is really brutal

## The role of early-life exercise in building lifelong bone, muscle, and cardiovascular health in girls [A: 4:00, V: 1:23]

Peter points out, “*There are certain things that just seem obvious and true across the board.*”

- We know that exercise is a remarkable tool to delay the onset of chronic disease
- We also know that it’s a remarkable tool to improve health span or quality of life

**Peter wants to focus on Abbie’s expertise around what we can understand in terms of exercise across the life cycle of a woman**

- And he wants to start at the beginning
  - He’s pretty sure there are no teenage girls listening to this podcast, but there are probably parents of those
- A previous guest made a point that Peter thought was amazing, and it has never left him: osteoporosis is a childhood disease
  - [[episode #322](https://peterattiamd.com/belindabeck/) with [Belinda Beck](https://theboneclinic.com.au/about-us/)]
  - What she meant was that women are reaching their genetic ceiling at about the age of 19 (in terms of bone density)
  - Then from 19 until the end of life, they’re hanging on to what they’ve got
  - And then they’ve got all of these things that get in the way, such as menopause

**If you’re a 10-year-old girl, how do you think about the role of exercise across several dimensions, not the least of which being bone health but muscle health and reaching their cardiorespiratory potential?**

- That’s a big question

***Abbie would sum it up: exercise is the best medicine***

- Starting young, consider it more play and then transitioning into lots of different types of exercise
- There’s lots of literature to suggest this

> “*The earlier you start and the better base that you have, the easier it is over time to maintain that fitness*.”‒ Abbie Smith-Ryan

- When we think about young girls, the biggest conversation and even some of the research we do: **menstruation often is a turning point when women and girls leave sport**
  - Based on a number of things, of how their body changes, how their performance differs

Abbie shares part of what her lab looks at, “*Understanding how that menstrual cycle might impact performance, recovery, bloating, mental health.*”

- Abbie is here in part to have that conversation
- When she was growing up, no one talked about it

*Were you a runner growing up as well?*

- Yeah, she played all sports
  - She loved every sport you can imagine
- She grew up in a space where it was exercise more and eat less
- When you add running, it’s this ability to really see how your fitness changes
- The same with resistance training: you can see how strong you get
  - It’s a very empowering tool

Abbie makes the point, “*We don’t talk about it enough with young girls: What is menstruation? Why is it healthy?*”

## Training principles for premenstrual girls, the risks of early specialization and delayed puberty from intense training, and how youth sport participation can shape bone and spinal health [A: 7:15, V: 5:00]

**Let’s talk first about the pre-menstrual cycle**

*Are there any dos and don’ts that you think of for young girls who are playing sports in terms of what they can be doing to augment their training?*

- For example, Peter is asking about a young girl who plays field hockey or volleyball or basketball
- What should they, or should they not be doing in the weight room?
- Abbie doesn’t work a lot with young kids, she has 2 little boys
- There’s a lot of interesting data about **not specializing**, being in lots of different sports to accelerate lots of different types of muscles and movement
- Speaking to her personal experience with her favorite lift, when she was 11 or 12, it was the [Romanian deadlift](https://www.youtube.com/watch?v=0Sd1AZZ77aw&t=127s)

***Resistance training is the best prevention of injury and oftentimes coaches don’t include that***

- Total body exercises, whether we start with resistance bands or lightweights or plyometrics or med balls, those are all really great things

**Let’s talk now about this transition as a girl enters her reproductive years**

- Peter points out, “*It seems that intense exercise can delay that.*”
- The 2 athletes he tends to hear the most about are gymnasts and runners

*Does that also happen with swimmers?*

- Peter knows that they seem to have some of the highest volume [of exercise], so he would guess that’s the case

***Yes (it depends on the events), and also cyclists***

- Abbie has done some work capturing the aftermath of females in college and there is data that it negatively impacts bone Because of the delay of estrogen onset and a number of things related to caloric restriction or indirectly over-exercise
- Abbie is a big believer that [effects] are not always intentional
- The other thing we see often with things like track and field and gymnastics is every athlete we scan, they have not full on scoliosis but a **spinal curve**
  - Which really demonstrates the point Peter mentioned that [osteoporosis](https://en.wikipedia.org/wiki/Osteoporosis) is a childhood disease of setting bone and what we do with those young girls has a lifelong impact (whether that’s a straight spine or a curved spine)

*Say more about that; Peter wasn’t aware that the scoliosis component could be partially acquired*

- Abbie has been at [UNC](https://exss.unc.edu/faculty-staff/abbie-smith/) for about 15 years and when she first started doing DEXA scans (we do a lot of whole body for body composition): every high jumper and every gymnast has a very distinct curve
  - Some of them are aware (obviously it’s a very thick scoliosis), but many of them were unaware
- And it’s really important then to say, “*Okay. Well, how do we stabilize this as you age?*”
  - You’ve already got that, and you can’t necessarily change that at 18, 19, 20
  - But you can very much work on the musculoskeletal system
- Peter would guess this is a problem with pole vaulters as well, anybody who’s got an asymmetric [sport] (Abbie agrees)

*Do we see something different in male equivalent of those sports?*

- We do not have a male gymnastics team; don’t see it as much
- Peter never thought about this until Abbie brought it up (he doesn’t know)
- Although, you could make an argument that if it were less prevalent in males, that maybe males have more musculature around the spine and therefore, they’re more able to offset what’s happening
  - That might be an idea, but Peter actually doesn’t know
  - Abbie thinks the age of onset of puberty could impact it as well

## Nutrition as fuel in young female athletes: supporting training, growth, and performance [A: 11:00, V: 9:03]

**As girls get into high school and college and their training ‒ let’s talk a little about this idea of reaching your potential early**

- Peter talks a lot about [VO2 max](https://peterattiamd.com/category/exercise/vo2-max/) in adults and how important it is and how you’re trying to maintain it

*What do we know about the VO**2* *max ceiling that a person has when they’re young?*

- Abbie thinks the best part of training when you’re young is to see those training adaptations; the body is more responsive
  - For example, she joked, “*I went out for cross-country to get in shape for basketball.*”
  - Obviously very different physiological systems and she did not feel fit when she then transitioned to basketball because it’s a different energy system
  - But by the end of basketball, she was more fit

*That adaptability is there when you’re young and setting the stage, is it a ceiling effect that you can never add?*

- Abbie always views it as: exercise is one of those things you can do regardless how old you are and you can always see improvements if that’s the goal
- She wouldn’t say a ceiling, but she thinks definitely on the skeleton and definitely on our habits of understanding that you are in control and you can see these really cool physiological adaptations by changing your training

**Let’s talk a little about nutrition as well**

*What do you think are the most important things for a young woman to be thinking about?*

- We can talk about this under different circumstances
  - Under eucaloric conditions, where we’re just trying to do recomposition versus weight loss versus weight gain
- Take it however you want to talk about it
- That’s a big question

If we talk about young women, Abbie’s conversation would be all about nutrition as fuel

- It’s really getting **adequate nutrition** and that is really where she landed with some of her nutrient timing work
- Often when you’re young or let’s say midlife and busy, you want to prioritize getting enough calories, but sometimes you can offset that or take advantage of your training by what you eat before, during, and after
  - Not that it’s necessarily any better
- When she thinks about a young female athlete and this idea that there’s increased GI distress, it’s hard to exercise when your stomach is full

***Really teaching them it’s about providing nutrients, so that they can perform better, recover better. That education about what it is versus necessarily what foods to eat and not to eat.***

- Peter thinks about this through the lens of his own selfish interest around his daughter
- When she’s running cross-country, he’s always concerned she’s not eating enough because practice is first thing in the morning
  - Understandably, nobody’s really hungry in the morning
  - She’s not really eating: she has a bagel and takes a bite out of it
  - Then they run and then they’re in class and then they’re not really eating
  - Peter worries that they’re not getting enough calories

**What are the strategies you think about for young athletes to hit their caloric requirements when training and school are impediments?**

- Think about what types of foods
- In that scenario, especially into puberty, [you want] higher quality fat foods (essential fats)
  - Often it’s less food and caloric density

Abbie recommends:

- Higher-fat milk and yogurt
- Nuts and seeds
- Small swaps: instead of skim milk, whole milk and things you can pack with you
- Planning more of that consumption

A lot of people talk about intuitive eating, eating when your hungry

- But when you’re exercising you’re often blunting that response
- Or most girls and women deal with GI distress

*Why is that? Are you saying that the carbohydrate density (or concentration), they tend to have more dumping issues or things like that?*

- It’s not just dumping, it’s just the whole GI tract
- Some of it is stress induced
- Honestly, it’s a really good question
- Abbie is not a gut researcher
- Some data suggests that it aligns with the menstrual cycle
  - There’s a lot of GI distress right before menstruation and it’s not just cramping
- There’s a number of elements that go into that
- It’s not just carbohydrate driven, which is an important component because now the conversation with young female athletes is to not eat as many carbohydrates, be very protein centric

***When in reality, carbohydrates are so important for any active individual, especially our young females***

## Training and recovery across the menstrual cycle: recovery, nutrition, supplements, and practical strategies for performance support [A: 16:00, V: 14:51]

**What strategies do you recommend for any woman of any age who’s training and trying to manage her cycle?**

*Whether she’s 18 or 38, how do you think about training around the cycle?*

- Abbie has done a lot of work in this space, and what she shares is based on her data and others

***We can train at any given time in our cycle, but it’s very clear that women and girls feel worse during different phases of the cycle***

- That’s a really important point, particularly in the [luteal phase](https://en.wikipedia.org/wiki/Luteal_phase), right before menstruation
  - [the figure below puts this in context with hormone fluctuations of the menstrual cycle]
  - Often women feel more fatigued, they have more bloating
  - It can impact recovery and soreness
  - A woman can still compete (and they will), but often it’s this ability to say, “*Maybe I didn’t meet my max, my performance is not as good.*”
  - Then it’s a little bit of, “*Oh, you’re fine.*” That’s a physiological response

![](https://peterattiamd.com/wp-content/uploads/2026/01/f1-abbiesmithryan-1024x701.png)

**Figure 1. Changes in hormone levels during the menstrual cycle**. Image credit: [*Sports Medicine* 2022](https://link.springer.com/article/10.1007/s40279-022-01755-3#Fig1)

- Peter always wondered when you watch the Olympics or something where you’ve got this one shot in four years and it’s easy to look at people like [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) who have been so successful over so many Olympics, or [Simone Biles](https://en.wikipedia.org/wiki/Simone_Biles), but that’s not the norm.
  - Of course, there’s nothing about the Olympics that’s the norm
  - But the norm might be you get one shot at this in your life and it’s always struck him as the greatest injustice for female athletes if their event falls at the time of the wrong time in their cycle, that has to be impeding performance

Abbie would argue no

- It’s a question she’s thought about too
- How great would it be if we could ask our Olympians, whether they’re on their menstrual cycle (or they’re not or having their period)

**⇒** What all of the data shows is that a woman is going to compete regardless

***Abbie thinks it’s more about the recovery***

- Often, the Olympics is not just a single event, it’s repeated
- And so really bringing science in to help with recovery and inflammation and protein breakdown
  - Where we might do it differently in the luteal phase versus the follicular phase
  - Really using more tools to help with the recovery, not necessarily that peak performance

**Let’s go through the entire menstrual cycle (we’ll do it in quarters)**

- Day 0 or day 1 is when the period starts
- Peter would guess that from that point to the next week (from a hormone perspective), the hormones are quite low

*Tell me what’s happening from a performance perspective in the first quarter of the cycle*

- This is when her period is actually happening
- Probably the first 4-5 days of that, [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone), [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone), [estradiol](https://en.wikipedia.org/wiki/Estradiol), they’re all pretty low

*Walk through the strategies to maximize performance and recovery if you’re training really, really hard*

- Abbie first qualifies that it’s really important that we’re going to talk about the traditional cycle
- But it’s clear that every cycle is so very different
- In the lab, we have some cool at-home monitoring tools that can be really powerful
  - Maybe you only bleed for 3 days or your hormones are not textbook

**Follicular phase: day 0-5**

- This is the low hormone phase
- Typically, we have greater carbohydrate oxidation, we feel better, we perform better

***You just do what you need to do and eat fuel, you will burn more carbohydrate***

- There’s a lot of nuance
  - It depends on if you have a long-term event
- In general, things in the follicular phase are pretty steady
- With the loss of menstrual fluid, there’s some things to consider
  - Hydration
  - Iron: potentially there will be a transient loss but not necessarily

*What’s the relationship between the volume of blood loss during the cycle and the intensity of exercise?*

- Peter wonders if those are blood loss during the cycle and the intensity of exercise?
- Abbie’s colleague, [Claire Badenhorst](https://www.massey.ac.nz/massey/expertise/profile.cfm?stref=573450) [Abbie misspoke her last name] out of New Zealand is looking at fluid loss and the ability to capture that
- But it’s so variable; Abbie’s not sure that we know because some women lose a lot of fluid and others don’t

Peter notes: you’re dealing with they physiologic loss, you’re losing oxygen carrying capacity

- For endurance sports, that’s going to be noticeable

*Abbie pointed out the increase in carbohydrate oxidation that occurs. Does that drive an increased appetite of carbohydrates?*

- Typically not
- Going back to what Abbie said earlier, regardless of the phase of the cycle, we need to eat enough and really focus on that

***When we think about that early phase of the cycle, maybe have a little bit more carbohydrate, but she wouldn’t say it’s necessarily directly related to appetite***

- Typically, we see the majority of the changes to nutrient timing and nutrition in the luteal phase, which we haven’t got to

***Abbie’s advice: eat regularly and then obviously match it based on your intensity and volume of your exercise***

**Late follicular phase: day 7-14**

- FSH and estradiol are really going up as the woman moves toward ovulation
- Peter knows that some women can sense that they’re ovulating

*What is a woman feeling on average during this period?*

***Abbie always says this is the most important time because it’s when a woman feels their best***

- They’re also the most fertile
- If we were to measure peak performance, maybe it feels a little bit easier
  - It has a direct translation to volume, quality of exercise, potentially sleep, optimizing recovery

*Anything beyond that in terms of behaviors or changes you would make in training if you were coaching someone during that period of time?*

- In coaching you often can’t say, “*Oh, it’s ovulation, we’re going to do things differently.*”
- But that is a really good spot to understand peak performance
- Part of Abbie’s interest in this field is understanding how certain aspects change
  - So that we can do more research in females
- For instance, she often wouldn’t test in ovulation if she is trying to understand how a female’s body changes or if she is tracking changes

***For research, Abbie would capture women in the follicular phase or she would capture them in the luteal phase (not during ovulation)***

- Part of it is ovulation sometimes lasts a couple days
- Or a woman might have menses and bleed but not actually ovulate
- There’s a lot more variability
- But that’s where that technology comes in, where we can begin to narrow it down

**After ovulation is the early luteal phase [day 14-21]**

- Estrogen is coming down before it makes a second rise and progesterone is slowly rising
- For most women, Peter’s recollection is that they are not yet experiencing the progesterone crash and therefore this is not a particularly difficult week
- Abbie agrees and adds that unless you’re really paying attention, you might not know when you’re done ovulating versus the early luteal phase

*So we could treat this week like the week before?*

- Yeah

**The final week is the last week of the luteal phase [day 21-28]**

- Peter points out this is when the most dramatic things are happening: the crash in progesterone and estrogen
- He thinks it’s really the progesterone that’s driving more of the emotional changes that are being perceived

*What is the effect of that physiologically, because the emotional effects alone could be sufficient*

- The last time Peter looked into this, it was not clear why some women were more susceptible to this than others
  - There are hypotheses out there, some women have a greater density of progesterone receptors in the CNS that may render them more susceptible to that depletion
  - He doesn’t think we understand this yet, unless there’s something that’s come up in the past few years that he’s not aware of
- Abbie hasn’t looked as much at the brain aspects
- It is very individual

***This is where we see changes in anxiety, depression, but we also see things physiological: changes in thermoregulation, water retention, greater inflammation***

- Abbie goes back to what Peter said about that week prior to that, when there is a rise in progesterone ‒ one strategy is that you can prepare for that crash
  - Whether that’s prioritizing your sleep or targeting inflammation, if it’s severe

*What strategies would you recommend there?*

- Let’s say we have a female that does experience a lot of changes in anxiety, depression, and or fluid retention or painful periods
- Really going into that luteal phase, where progesterone peaks, there’s some interesting approaches

1 – Increasing omega-3 could be helpful to start down-regulating inflammation

- Slightly higher doses of 2-3 grams

2 – Potentially [supplementing with] some zinc and magnesium to help with the vasodilation

3 – Sleep

- Research says sometimes that luteal phase sleep goes down or the follicular, and for those individuals that are having more sleep disturbances, we can start to tackle that

4 – Obviously increasing fruits and vegetables, helping inflammation

When progesterone is on the rise

- There is some data that suggests that there’s an increase in protein turnover, protein breakdown, and this edema

5 – [Creatine](https://en.wikipedia.org/wiki/Creatine) supplementation

- Abbie focuses on supplements and has looked at something like [creatine](https://en.wikipedia.org/wiki/Creatine), which really pulls water into the cell
- She [evaluated](https://pubmed.ncbi.nlm.nih.gov/36678300/) what happens in the follicular versus the luteal phase

***Creatine was able to take that extracellular fluid and bring it into the cell and help put fluid in the right places, and indirectly that also supported performance***

6 – Caffiene

- There’s some interesting data that suggests caffeine might be more helpful in the luteal phase to help with those fatigue components

**Peter’s takeaways**

- A lot of these things are great ideas all around
- Maybe you would pulse omega-3 supplementation at a higher level based on [the woman’s cycle]
- Magnesium is critical all around
- His view is that creatine is quite valuable throughout the cycle
  - He never knew that creatine might benefit a woman more by reducing actual bloating and pulling the water into the cell
  - He knew creatine did that, but never made the connection that it would be of a benefit during the luteal phase (that’s interesting)
- For caffeine, if a woman didn’t want to have to manage it by cycle, it would be safe for her to enjoy all the time
  - She might get more benefit in the luteal phase

## The benefits of creatine supplementation and importance of protein intake across the menstrual cycle [A: 27:15, V: 27:31]

**How are you dosing creatine in women?**

- Abbie is running a pretty cool study right now, it’s the first with creatine in perimenopause
- Because she has a lab restriction, she often will load first to accelerate creatine saturation and then follow-up with 5 g a day

***Abbie is a big believer in 5 g of creatine a day, and for midlife women or brain benefits up to 10 g a day***

- Peter completely agrees on the loading because if you go to steady-state, it takes weeks to get there (too long)
- Recently, Peter had [Rhonda Patrick](https://www.foundmyfitness.com/about-dr-rhonda-patrick) on the podcast and he came away thinking, “*You know what? I think we should move our maintenance dose from 5 to 10 g.*” And he has done that [[episode #369](https://peterattiamd.com/rhondapatrick3/)]
- After the loading phase, Abbie typically supplements with 5 g a day
  - She loads for 5 days at 20 g a day (split into 4 doses of 5 g each)

***Peter’s takeaway for the average person who’s not trying to enter a study is to supplement with 10 g a day***

**What are women experiencing in the luteal phase**

*1 – When supplementing with creatine, Peter would love to hear if this is reducing some of the* ***edema*** *that they’re getting during the luteal phase*

- [Abbie’s [RCT](https://pubmed.ncbi.nlm.nih.gov/36678300/) looking at the effect of creatine supplementation on fluid accumulation during the luteal phase]

*2 – Talk a little about the protein issue: Are you saying that potentially during the early luteal phase,* ***muscle protein synthesis*** *is not as efficient?*

- This is a debatable topic right now
- [Earlier Abbie referred to increased protein breakdown in the luteal phase (day 21-28); discussed further in this [review](https://pmc.ncbi.nlm.nih.gov/articles/PMC8015182/#Sec12)]

**3 – First, in the luteal phase we tend to see an increased metabolic rate.** *What do you think that is driven by? Is it temperature?*

- Maybe temperature
- Maybe the luteal lining or the utero lining
- Abbie is not exactly sure; there’s a number of metabolic processes
- Maybe it’s the progesterone

*How much is it?*

- A couple hundred calories a day (increased energy expenditure)

***Abbie thinks that’s relevant (200-300 calories) because it’s often when women and girls feel their worst***

- Peter points out that they may not appreciate it on the scale because if anything, they’re retaining more water
  - The scale might suggest you’re gaining weight, but in reality you’re losing stored energy
- Abbie adds, “*And if I’m gaining weight on the scale, I have extracellular fluid, I don’t feel very good. I’m not going to eat more. Often, I eat less.*”
- This is when we see increased cravings

***Often it is this perfect storm for under consumption of food***

**Abbie has looked at different nutrients across the menstrual cycle, but it comes back to getting enough**

- The protein component: Abbie has a paper in review right now, looking at protein synthesis across the menstrual cycle in young women
- If you’re getting adequate amounts of protein, it’s not something she’s super concerned about
  - Adequate is 1.6 grams of protein per kg of body weight
- Nutrient timing around workouts is also important
  - [[2019 publication](https://pubmed.ncbi.nlm.nih.gov/30366741/) found benefits for strength, metabolism, and fat utilization after exercise]

***If you’re optimizing amino acids around training, you won’t see those negative side effects***

Peter points out that it’s not always easy to get 1.6 g/kg of protein

- He just came back from a long travel stint where he was gone for a week and all over the place
- He’s targeting 2 g/kg, and not one day did he hit it
  - The reason he always targets 2 (or slightly more) is that if he falls short, he can still be at 1.6
  - Half of those days he didn’t hit 1.6

Abbie responds, “*It’s really valuable that you say that, and I think people need to hear that.*”

***Abbie targets about 1 gram of protein per pound of body weight***

- There’s many days that she doesn’t get that, but it’s still that consistency and optimizing timing
  - She’s not going for 5 hours without getting protein
  - She has amino acids in the bloodstream, which can help her maintain
- Peter was frustrated with himself because he normally travels with protein snacks ([David bars](https://davidprotein.com/collections/shop-bars) and [venison sticks](https://mauinuivenison.com/collections/venison-snacks)), but he was in such a rush when he packed that he didn’t take any of that stuff
- He was in Asia and you’re eating these tiny quantities of amazing fish all the time

Abbie asks “*Could you tell a difference? Could your body feel a difference?*”

- Yeah
- Part of the difference was that his training volume was also so much lower
- Even though he was probably getting 1.2 g/kg of protein per day, and he did lift every day he was supposed to lift
  - But he doesn’t think the lifts were nearly as intense
  - The hotel gym is not the same as his gym
- He feels fortunate that it was just a week
- This is a bigger deal for the person who’s traveling constantly, and they’ve got to pay more attention to it

> “*It’s important to know that even when we know the right answers, it’s hard to follow it.*”‒ Abbie Smith-Ryan

***One of the benefits of exercising consistently is that a week here and there is not going to have these severe negative side effects***

- Peter points out that if a woman is getting 1.6-2 g/kg, we don’t have to worry about it
- But if for example, she’s a **vegetarian**
  - She’s going to have a real hard time hitting that

***You’re going to maybe make a note that says, “Look, right after your ovulation. This is actually a time to pay even more attention to protein intake because of this reduced MPS [muscle protein synthesis].” ‒ this is especially true with aging muscle***

- Young female muscle and male muscle is resilient
- But if we’re into our 40s, 50s, based on some of the science around anabolic resistance
  - And obviously the hormones change differently in that timeframe

***Protein intake in that luteal phase could help with soreness, recovery, injury prevention***

## How women should approach training intensity and volume across the menstrual cycle [A: 33:00, V: 33:57]

- Now let’s talk about an individual in charge of their own training
  - They’re not on a team anymore
  - This could be Peter’s wife who’s training for marathons or a woman who’s just training to stay in shape

**What guidance are you giving around changing (if any) exercise intensity and volume throughout the menstrual cycle?**

- For someone in their 40s, exercise intensity and volume would be periodized based on something else
- In other words, you’re going to change intensity and volume based on longer [mesocycles](https://en.wikipedia.org/wiki/Sports_periodization#The_mesocycle) that are around peaking and tapering for whatever the events are
- But we’re not going to do a monthly up and down based on the [menstrual] cycle, which means you are accepting the fact that you will sometimes train not feeling as good as you do during other times in the cycle

Abbie has 2 thoughts on that

- 1 – Could we align your periodized 4-week program with your period and menstrual cycle?
  - That might be something to look into
- 2 – We are going to train whenever and do that as long-term effects, but also we are going to  give ourselves some grace
  - If you didn’t hit your goals or your minute per mile, you might take a step back and say, “*Oh, where do my hormones play a role?*” Or, “*I also maybe needed a little bit longer recovery.*”

There’s some interesting data with work-to-rest ratio

- We need to empower women to ask, “*When is your menstrual cycle… What does that look like? How long?*”
- This helps us understand when it changes
  - How long are you bleeding and are you more tired based on those hormonal things, or is it something else?

Peter’s takeaway

- This might be a relief to some women to hear that because it makes them maybe accept the fact that, “*Hey, I don’t need to over-science this thing. It is what it is.*”
- As a guy, where his hormones are pretty much all the same, Peter can’t imaging what it would be like
  - If these very powerful androgens are moving up and down throughout a cycle, a lack of predictability and how you’re going to perform can be pretty frustrating

***It seems like grace with yourself is a high virtue***

**This is one of the reasons Abbie became a scientist**

- As a scientist, she has a lot of data and evidence, but how she does it in real life
- Some days she’s lucky, she’s training at 5:00 in the morning all day, we’re lucky just to get it in → ***Consistency matters***

Empowering women

- We were not taught about our bleeding patterns, our changes in hormones, what’s normal, even down to the changes in brain and mental health
- If there’s a way that we can measure that and a woman can track that, it’s really empowering
  - Versus, wow, I just feel terrible or what am I doing?
  - It allows us to tease out when there is something we need to change, whether it’s our nutrition, our meds, or whatever it may be,
- First and foremost asking, “*Well, where do my hormones play a role and how does that change as I do get older?*”

**If a woman is on an oral contraceptive without the placebo week (so if a woman is just taking the hormone throughout the cycle, obviously, completely suppressing ovulation and therefore completely suppressing a menstrual cycle), is there a performance advantage to that?**

*In other words, if you were trying to make that Olympics, would that potentially be the strategy?*

- It’s more indirect
- Based on the literature and working with female athletes: consistency and potentially over time, there’s less variability which allows for more consistency with training
- Indirectly, a lot of times women are taking hormonal contraception to help with symptoms of their cycle, whether that be mood or cramps
- In general, a lot of times females feel better not having to bleed
  - Abbie knows some women skip the placebo week so that they don’t have to deal with that, and that, in itself, is a nice thing not have to worry about

## How to identify and monitor the perimenopausal transition and why this phase represents a critical window for exercise and nutrition interventions [A: 37:15, V: 38:31]

**Let’s talk about women entering the perimenopause stage of life**

- For some women this stage can be relatively short and brief and for others can sort of drag on for a while
- We can identify this stage based on some sort of irregularity, a slowly upward drifting [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone)

*What are the ways you would advise a woman to start thinking about how she exercises and eats during that phase of her life, which again, could last for years?*

- This is where a lot of the data has led Abbie
  - She is becoming an expert on that period of life, not intentionally, but it is very much symptom-driven
- Often we don’t know when our FSH is rising or we’re not getting our measures

***First and foremost, getting blood work done is really valuable, even starting in our 30s so that we know individually when that changes***

- We have leveraged at home hormone urine analyses where you measure daily urine, which really starts to say, okay, well, maybe my hormones are changing.

*What are you measuring in the urine?*

- Abbie has used a couple of different devices
  - From a science perspective, most of them are measuring some form of estrogen, some form of progesterone, FSH, and LH ‒ all in a urine stick
  - [While Abbie doesn’t recommend any specific brand, she has used [Mira](https://shop.miracare.com/collections/mira-wands/products/mira-ultra4-wands), [Oova](https://shop.oova.life/en-US/shop/perimenopause), and [inito](https://www.inito.com/buy-now)]

*How accurate are they relative to blood?*

- They’re not telling us the exact same thing, but we are trying to work on some of that validation
- She can correlate what she sees in the urine with blood measurements
- But more importantly, we’re now able to see that **daily variation**
- This allows you to start to identify if you have a spike or a drop
  - And if you feel terrible or your feel better
  - If it’s impacting sleep or hot flashes

***Daily urine measurements provides the tool to see what is happening to hormone levels versus measuring a single time point with bloodwork***

*The estrogen that’s being measured, is it just estradiol or is it estriol or estrone and everything?*

- It’s usually one marker and it depends on the device

**Peter’s advice to women**

- Be really consistent
- We think that ***day 5 FSH in the blood is probably your best test*** because again, you really consistently know what it should be
  - Day 1 is the day your period starts
  - Day 5 is when you’re fertile
  - The FSH level on day 5 really should be low, and that’s the thing that we are watching to climb as a woman is entering perimenopause

**⇒** Once the day 5 FSH is hitting 10, we know that a woman is now entering that zone [perimenopause]; and if you look at a woman in menopause, that number’s going to very quickly rise to 25, 30, 50, etc.

Abbie asks, “*What do you do if they have an* [*IUD*](https://en.wikipedia.org/wiki/Intrauterine_device#Hormonal)*, and do you ever use* [*AMH*](https://en.wikipedia.org/wiki/Anti-M%C3%BCllerian_hormone#General_fertility_assessment) *numbers?*”

- AMH can be somewhat helpful
- It’s definitely harder if there’s an IUD that’s completely preventing that
  - Some women with an IUD will still break through and have a period, but it might only be 3 times a year, and so you just try to capture those moments
- Abbie asks because there’s so much variability happening and as a researcher, we want to capture that real time translation
  - To get some quality research
  - Abbie’s motivation for being here too is that clinical connection: How do we take clinical practice and form research and vice versa?
- She’ll have to look at day 5 numbers

**Back to perimenopause**

- Abbie has looked a lot at this space, and as a scientist, the data leads us
- She did an [initial study](https://pubmed.ncbi.nlm.nih.gov/36878186/) as a follow-up to some of the [SWAN studies](https://www.swanstudy.org/) using very sophisticated measurements of metabolism, body composition of what happens pre-menopause, perimenopause and post-menopause

***Repeatedly, we’re seeing changes in perimenopause to metabolism, muscle size and quality, bone, and even metabolic flexibility***

- This tends to be a bit more stable post-menopause

> “*Really now, we are really diving into that perimenopause window because it seems that’s the time we really need to take advantage of lifestyle behavior changes to have this lifelong impact improve healthspan. It’s coming in our late 30s to our 40s to our 50s with our exercise and nutrition.”*‒ Abbie Smith-Ryan

## Case study: time-efficient exercise program for a busy, perimenopausal woman [A: 42:00, V: 43:51]

**Case study #1: a woman who’s not exercising that much because she’s got 3 kids under 6 and she has her hands full**

*As she’s becoming perimenopausal, how do you make the case to her that exercise should be prioritized for her health beyond the usual things that you would hear (like exercise is good for you)?*

- How do you make the case that actually despite how busy you are, this is a great time to start this or reengage in this habit?

Abbie emphasizes, **“*****You’re never too late, old to start and it will literally impact your health forever. And I would say based on the data, it doesn’t have to be 150 minutes a week of exercise. It’s really consistency.*****”**

**⇒** Intensity is more important than volume and consistency is more important than volume

- Abbie knows and struggles with mom guilt, and often these women are worried about taking care of everyone else with this desire to care for them
  - Peter adds, “*It’s amazing how little dad guilt occurs in that… It’s not the same.*”
  - Peter finds that he is way less selfish that he used to be, but the truth of the matter is his wife is infinitely more selfless
  - When Abbie’s little boys say, “*Don’t go. Why are you going to run?*” She brings them into it
- The other reason Abbie is passionate about this is that we have the ability to not only change our healthspan, but also generations behind us
  - Showing that this is really important
- She jokes with her kids, “*Do you see any other mom killing you on the flag football or the baseball?*”
  - It allows her to be out there and to keep up with them as well
- She ties it back to health and longevity and quality of life

***If you want to live healthier longer, you need to put the time in now and it will ultimately help you be a better mom, wife, grandmother, etc.***

**Exercise volume and intensity**

- Peter has been looking at this a lot, and his reading of the literature is: with unlimited time, volume matters most
  - But as volume goes down, intensity becomes more important

***In other words, if a person only has 150 minutes a week to exercise, you have to prioritize intensity because you’re not really getting enough volume to maximize conditioning***

- For example, if a person is willing to train 12 hours per week (which is obviously a lot), then you have the luxury of relying on the volume for the benefits and the ratio of high intensity to low intensity is going to be a lot shorter
  - This is a slightly more nuanced view that what often gets communicated
  - It’s the difference between a professional runner or cyclist who’s out there 25 hours a week training ‒  yes, 80% of their volume is going to be really, really low intensity (but that’s none of us)
- Peter was giving a talk recently and someone said, “*If I only had,*” and they gave some incredibly low number of minutes to train a week, “*What would it look like?*”
- And the truth of the matter is if you’re trying to maximize the training effect, it’s going to mostly have to be pretty **high intensity**
- But of course, you run the risk when it’s just high intensity that:
  - You’re missing some of the other benefits
  - You’re not building a strong base

For Abbie, it goes back to what outcome we’re looking at

- She is an exercise physiologist and she loves volume
- When she first started in this space several years ago, she was an endurance runner
  - She thought we had to train until you couldn’t walk and really started looking at high intensity training
- For that sedentary woman with 3 kids, if we want improvements in [VO2 max](https://en.wikipedia.org/wiki/VO2_max):

***Volume does come into play, but we can get those changes more quickly with high intensity exercise***

There’s some fascinating data on “exercise snacks”

- Higher intensity for short periods of time
- Scott Trappe’s work: he’s [measured and tracked](https://pubmed.ncbi.nlm.nih.gov/31829806/) some pretty elite endurance athletes over time (**endurance training**)
  - Just doing volume doesn’t help maintain the integrity of the muscle size and quality
  - It’s very good at capillarization and blood flow
- We haven’t talked about resistance training, but where volume is maybe not the only way… Abbie would just tweak that a little bit of intensity ‒ it’s going to matter no matter who you are
- But depending on our performance goals, sometimes you need to do more volume

**Let’s talk a little about how you might structure that for the mom who is going to carve out 3 hours a week in total for training**

- It’s a luxury for the person who’s got 18 hours a week to train, where we can talk about how much [Zone 2](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/), how much Zone 1, Zone 3, and [Zone 5](https://peterattiamd.com/category/exercise/high-intensity-zone-5-training/)

*How much of that 3 hours are you going to want to put in the weight room versus on the treadmill?*

- It would come back to goals: Are they trying to lose fat, gain muscle, just move?
- In general, for a midlife woman, Abbie would prioritize a few days a week of whole body progressive resistance training
  - She is doing a study now where we try and get it into 2 days
  - We do a little bit higher intensity progressive
- Then 2-3 days where you’re doing aerobic exercise
  - Hopefully 2 of those might be high intensity

***In reality, you need a blend of some resistance training consistently and some exercise that elevates your heart rate versus just low to moderate intensity***

*In that example, would you say we’re going to do two 45-minute whole body resistance days?*

- Abbie doesn’t even have time for that
- Let’s say 30 minutes, this is not the only way, but just for time efficiency:
  - 6-8 reps at 60-80% [1RM](https://en.wikipedia.org/wiki/One-repetition_maximum)
  - 30 seconds in between each exercise, 2 minutes in between

*That takes an hour a week. Then of the 2 hours that are going to be left, how do you structure those?*

- To Peter, it sounds like ⅔ of that times might be high intensity, ⅓ of it might be low intensity
- Yeah, at a minimum 1 day a week of high intensity, interval style training ([HIIT](https://en.wikipedia.org/wiki/High-intensity_interval_training))
  - If you can get 2 in, it’s going to be a bigger “bang for your buck” as you’re starting

> “*I do think there’s a lot of value of just movement.*”‒ Abbie Smith-Ryan

- Maybe on that day where you have a little bit more time, whether you’re walking or doing more of that low intensity riding a bike, the freedom to just get some blood flow and get that heart rate up

*How do you structure the high-intensity days?*

- There are so many different ways
- The protocol that’s been very effective for Abbie (in very fit individuals down to cancer individuals) is: 10 sets of 1 minute on, 1 minute off
  - With that 1 minute being anywhere from 90% to 110% of max
  - Pick an intensity that you couldn’t go for a minute and 20 [1:20]
  - Pick an intensity that 1 minute is really hard and you need to take a break
- She’s done it where you measure VO2 max and very calculated, but she’s also done it where we just said, “*Hey, go do something for a minute that’s really hard and you need to take a break, and then that next minute you go again*.”
  - In other words, most people are not going to have VO2 max measured, but anywhere from 90-110% of VO2 max (or maximum heart rate) is the goal

Peter’s issue with heart rate training when it comes to anything that’s that short is the heart never gets to max heart rate until the very end

- Abbie agrees 100%
- Peter finds that the lay person when they’re training
  - Let’s say at the beginning of the interval, their heart rate has come down, now, it won’t come down that much, but let’s say it comes down to 100 beats per minute
  - And let’s say their max is 180
  - When they’re 30 seconds in, it’s only 140, they might look at that and back off a little bit (they might be a bit confused)
  - So they might try to speed up more than they should
- He’s always felt like you have to be able to teach people how to [RPE](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion) their way through those efforts
- Of course, the nice thing is on a bike or on a treadmill, if you’re doing it on some sort of ergometer, the power or the speed are locked in and that forces you into the effort
- Abbie agrees
- She also thinks the goal of the interval style training are:
  - If you’re doing it in a lab, you’ll still see benefits even if you’re not necessarily hitting that 90%, it might just take a little bit longer
  - We’ve done this where we did some at home in a family med clinic and just said, here’s some guidance so that they don’t feel like they just have to do it on a bike or a treadmill
  - They begin to feel what a high intensity feels like
  - Also, RPE and heart rate does vary day by day

*Are you suggesting 1:1 on:off for 10 rounds?*

- Up to 10, sometimes we start with 6
- It just feels like you can do anything for 1 minute
- Now, there’s a lot of good science of doing 30 seconds, and we’ve looked at different protocols (2 minutes)

***That 1 minute on, 1 minute off is something you could do on your own, and it tends to be very feasible***

Abbie adds, “*It really takes 10 minutes of work, 20 minutes total, and I love doing that.*”

- Sometimes when she doesn’t have any time to exercise or she has to get her kids to baseball, maybe it’s only 6 intervals
- You get it in, and you have not only an effect there, but that lasting effect for the day after

**Going back to the case of our hypothetical woman here**

- If she’s got 2 hours that she’s willing to put into cardio (because you’ve taken 1 hour on resistance training), would you do 2 of those [HIIT sessions]?
  - Since with warm up and cool down, let’s just say each of those is half an hour
  - So now you’re at 2 of those is another hour

*For the remaining hour, would you prescribe 1 or 2 low intensity days?*

- It all comes down to do you have a whole hour by itself?

Abbie has noticed, “*Now, as I’ve aged, I need exercise every day, otherwise I’m unwell*.”

- So that 30 minutes, it’s a bit more manageable to do and depending on intensity
- Yes, she would split it up so that more days than not, we’re doing some sort of exercise

***Abbie’s advice is to exercise on most days: prioritizing that high intensity training a couple days versus an added low intensity day***

- It does increase lean mass as well, which can be helpful for that midlife
- [[Abbie’s study](https://pubmed.ncbi.nlm.nih.gov/38442308/) found HIIT during perimenopause has benefits for body composition and menopause symptoms, and more studies are listed in the “selected links” section at the end]

## Why improving body composition is a better goal than weight loss, and how to set realistic fat-loss targets in midlife women [A: 53:30, V: 56:50]

**Do you ever differentiate between weight loss and body composition?**

- This is one of those things Abbie is passionate about
- Because most women say, “*I want to weigh less*,” or we were taught, “*Oh, I don’t want to know my body fat.*”
- When in reality you want to measure ‒ a lot of times the weight doesn’t change or goes up, and it is all about body composition (but a lot of women don’t understand that)

**How would you counsel a woman that came to you and said, “*****I want to lose weight*****,” (which would be the common statement of anyone, men and women)?**

*What they really mean is, “I want to lose fat.”*

- We would do some sort of comprehensive measurement
  - Whether it be a [DEXA scan](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry#Body_composition_measurement) or a [multi-frequency bioelectrical impedance](https://www.impedimed.com/products/research-devices/sfb7/) or an [at-home scale](https://medgrade.org/comparisons/best-smart-scales-2025-comparison/)
  - They’re all different, but most of them do a pretty good job with tracking changes
- Based on that number, Abbie would calculate ideal weight, and it tells us:
  - Our percent fat and our muscle
  - But here’s my goal percent fat and muscle based on my health goals (or my weight goals)
- A lot of times, people think they want to weigh what they did in high school, but in reality, they’d have to lose muscle for that

***And so, giving them more of a target percent fat with that to inform our weight goal***

*And how do you make a determination of what the ideal body fat percent is?*

- Depending on the device, a lot of times you can use NHANES
- Around the 50th percentile, we see a lot of cardio metabolic changes [NHANES data shown in the table below]
- Using a lower percentage, there’s normative data that Abbie would use based on the individual

***We want it down to the 25th percentile and lower; 50th is what you want to stay away from***

![](https://peterattiamd.com/wp-content/uploads/2026/01/f2-abbiesmithryan.png)

**Figure 2. Total percentage body fat in females in the US, NHANES 1999-2004**. Image credit: [CDC Vital and Health Statistics, page 18](https://www.cdc.gov/nchs/data/series/sr_11/sr11_250.pdf)

**Cast study #2**

- If a woman came in and she was 5’6, probably the average height and 150 pounds (which tells us nothing yet), but now you do a DEXA scan and she is 30% body fat, his guess is that’s probably about the 50th percentile of NHANES
  - Abbie adds that for a 40-year-old, her percentile is a little bit lower, probably 30th percentile

*If she said she wanted to lose 20 lbs. (go from 150 to 130 lbs.), how would you advise her?*

- Abbie would measure her body composition, see what her bone weighs, what her lean soft tissue or muscle and her fat, also where she stores her fat
- And then we would understand how much food she’s consuming

*In a typical 40-year-old woman, let’s say she’s a mother of two, what would be the typical pattern of fat storage on her?*

- This is tricky because it’s changed
- Most women store it in their hips, but as we age, we store more in our abdominal region
  - It’s not always [visceral fat](https://en.wikipedia.org/wiki/Adipose_tissue#Visceral_fat), but that is a lot of the conversation and why we measure it
  - A lot of women then begin to store more in their visceral region on their organs versus their hips, which comes with an increase in cardio-metabolic disease
- In the case of this woman, let’s assume that her visceral fat is actually quite low, and let’s assume that she’s also metabolically quite healthy
- Let’s just say she’s had some other blood tests and she’s metabolically healthy and that this is just mostly [subcutaneous fat](https://en.wikipedia.org/wiki/Subcutaneous_tissue#Subcutaneous_fat), whether it be on her hips or on her abdomen, but it’s not inside

- Let’s be honest, we all want to look better
  - She wants to be 20 lbs. lighter
  - If she wants to exercise, it’s great to carry 20 less lbs. around on the knees
  - Abbie would usually say that 20 lbs. is probably too much
  - Based on historical measurement, we’re probably looking at more of a 10-pound [weight loss], if she’s a 150 lbs. and 5’6” (140 pounds based on that skeleton is probably more reasonable)
- Then, it would include some follow-up measurements
- Abbie is doing a project right now where many women are ***not necessarily losing weight, but they’re replacing fat with muscle***
- That comes back to nutritional strategies

The question is: How do we get her to lose weight?

- There’s a blend of hypocaloric intake, so we need a slight calorie deficit
  - We need to understand what she’s eating

Abbie points out, “*A conversation that we’re not having in this midlife is: it’s not just taking out food, it’s adding in foods like fiber that help with satiety, enough protein and complex carbohydrates*.”

***It’s balancing that with her workout and having some of a calorie deficit***

## How to preserve muscle and bone while using GLP-1 medications: resistance training, protein intake, and more [A: 58:15, V: 1:02:12]

- A lot of women (or anyone for that matter) in this situation of being 150 lbs. could easily get to 130 with a [GLP-1 agonist](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist)

**For this woman who is going to lose 20 lbs. with a GLP-1 agonist, what are the strategies you would employ to help her lose no more than 5 lbs. of muscle (and therefore lose 15 lbs. of fat)?**

- She would go from being 35% body fat to 20-22% body fat
- In those cases, we know that our muscle quality is also changing
- Abbie would emphasize the need for resistance training

Abbie’s advice in terms of training and nutrition

- 1 – She would absolutely prioritize resistance training to help to maintain that lean mass and improve the muscle quality
- 2 – Protein has to be a conversation, particularly thinking about maintaining amino acids over the day
  - Consistently feeding with a goal of 30 grams of protein evenly spaced throughout the day
  - Abbie has done some [work](https://pubmed.ncbi.nlm.nih.gov/33369879/) with essential amino acids around exercise, which really helps optimize that maintenance of lean mass

*How much protein should she target per day?*

- Usually you use the goal weight to identify this

***130-150 grams of protein per day***

- That’s a pretty aggressive fat loss, weight loss
- If she could get to 150, that would be a good goal

The reason Peter brings this up is that many people are going to use these drugs

- They’re becoming more and more tolerable
  - [Mounjaro](https://en.wikipedia.org/wiki/Tirzepatide) (or tirzepatide) is significantly easier to tolerate than [semaglutide](https://en.wikipedia.org/wiki/Semaglutide)
- Peter wants to make sure that all the people that are out there wasting away have the insight into, “*Hey, it doesn’t have to be this way. I can still take this drug, I can still lose weight, but I also have to do something deliberate to make sure I don’t have a negative impact on my skeletal muscle*.”
- Abbie agrees, this is such an important point

> “*Most women really want to weigh less, but the loss of muscle can have a dramatic impact on our health long-term.*”‒ Abbie Smith-Ryan

- Abbie is just starting some of this work with these GLP-1s around: What is the right amount?
  - Or can we alter the dose or help us feel better if we add things like resistance training and higher levels of protein?
- There is good science on the **protein** side of things because they impact appetite
  - It’s still focusing on the nutrients
  - And that really ties into of some of her work with nutrient timing

***Abbie’s advice: if you are on a GLP-1 and are going to exercise, you absolutely want to think about having amino acids before and/or after to really maximize the effect of the workout***

**Peter was talking with someone yesterday about her experience on both semaglutide and tirzepatide**

- It was very interesting because she said that nobody had explained to her that when you’re on one of these drugs, you don’t just go about your day eating less

**⇒** You actually have to create a new diet that is lower in calories but has to be much higher in quality to compensate for the reduction in total energy

- In other words, this is exactly what Abbie is saying, but it was interesting that this person didn’t know that until she figured it out herself
  - And this is probably most people’s experience

***This makes Peter wonder how many people are not being counseled correctly to be able to use this drug***

- It’s a great drug, it’s an amazing tool, but it comes with a responsibility (for lack of a better word)
  - Which is you’re going to have to make these direct and very deliberate changes in the energy composition
  - And then, obviously, around the training

Abbie explains, “*Most people are also not measuring body composition, and so you really don’t know what type of weight you’re losing, and we see this accelerated loss of muscle and bone.*”

**What’s your theory on why the bone densities are going down?**

- This depends on who is taking these drugs
- Looking at a younger population, we’re seeing with and without these drugs: ***under consuming calories***
  - There’s this relative energy deficiency syndrome that is happening in parallel with perimenopause

***Some of the same symptoms and side effects of perimenopause are really coming from just under-fueling, which is going to only go up with these GLP-1s***

- If you’re eating less, it does impact hormones and you have the fatigue and the drop of progesterone and estrogen, but it’s not necessarily driven by your ovaries, it’s driven by the lack of caloric consumption

## Designing a three-hour-per-week training plan for sustainable body recomposition [A: 1:03:30, V: 1:08:02]

**Back to the case of this hypothetical woman, how are you going to divide her 3 hours per week where now her goal is recomposition?**

- Let’s assume that she’s showing up and she’s not really got much of a huge exercise routine
- So now you’re introducing her for the first time, and she’s got 3 hours a week she’s willing to put into this

***Abbie wouldn’t change much: two 30-minute strength training sessions a week***

- If we have more, if you’re doing high intensity resistance training optimally, you might do one additional
- It does depend on the soreness in what we’re doing
- The other thing that we need to consider is the lack of energy
  - If she’s under eating, we might not have the ability to do as high of volume and intensity on those 2 resistance training days

The other thing we want to consider is cardiovascular changes

- That’s why Abbie likes [HIIT](https://en.wikipedia.org/wiki/High-intensity_interval_training), it can stimulate an increase in muscle at the same time and still improve those vascular changes we would see
  - [she published on the ability of HIIT to [improve muscle size and quality](https://pubmed.ncbi.nlm.nih.gov/28647284/) and [benefits for cardiometabolic health](https://pubmed.ncbi.nlm.nih.gov/26934687/) in overweight and obese adults]

***Abbie would maybe do 3 resistance training days and take one of those 30-minute low-intensity cardiovascular days to add to the resistance training***

Summary of the training schedule for case study #2 (for fat loss)

- 1 low-intensity cardio day
- 2 high-intensity cardio days [HIIT]
- 3 strength training days
- Those are all 30 minutes a day
- If she’s unfit, that might be a lot for her
  - Probably change one of those HIIT days for a low intensity day

*Are those 3 days in the gym all whole body or at that point, do you start to go body type once a week?*

- Abbie likes to work the major muscle groups twice a week
- But it really depends on the individual
  - Is she tolerating it well?
  - Is she feeling good or is she run down?
  - If she doesn’t have energy, then Abbie would split it up

**Would you suggest a timeframe over which that degree of body recomposition is going to be more sustainable and therefore less dramatic in the getting there phase?**

- Abbie thinks this is a really important point
  - Especially when we think about a lot of our lab-based work, we’re looking for accelerated time or accelerated changes in a short period of time
- For more sustainable [approach], the body part over a specific,

***We’re often looking at 24 weeks, and this would be more of a concentrated push-pull, whether it be leg day, upper body, leg, upper body***

*If she came to you and said, “Look, how long would you like this to take? Would you want this to take up to 24 weeks? Would you want to make this a one-year project?*

- Peter points out that part of this comes down to how you would dose the tirzepatide
- His view in this is we want the patient to be on the lowest dose possible and take as long as necessary to get there
- So he would want this to take a year, and year on 2.5 mg or maybe 5 mg, but we want it to be long and slow so that the adaptation is gradual

Abbie is in the process of looking at this now and including a lean mass indicator before titrating the dose up

- To see how the body is responding before changing the dose
- We’re talking about a couple of different things here
- Yes, we would want that to be long-term, but on the flip side, most people want to see some effects pretty quickly
- So it’s a balance of what type of weight are we losing and are we tracking that and making sure muscle is an important component of that

## Abbie’s insights from her 20+ years of self-tracking: nutrient timing, injury prevention, excessive training, bone health, and more [A: 1:07:15, V: 1:12:18]

**You’ve done a lot of tracking in yourself, right? How many years have you been at your self-quantification?**

- >20
- She measured it in college, all the way through grad school, and now she does it every 6-9 months

*What have been your observations in yourself based on this, and how generalizable do you think they might be?*

- Initially, when Abbie was a distance runner, she had 9 stress fractures, and it was every time her body fat got below about 15%
  - Which is not ridiculously lean, but that’s an injury indicator
  - She’s 5’6” tall, and when she was 15% body fat she weighed 115, 120
  - That looks pretty normal: a lean looking person but not a bean pole
- It’s important to use these numbers and compare to your own set point
  - Not compare to someone else

**At that point you were** [**amenorrheic**](https://en.wikipedia.org/wiki/Amenorrhea)**, I’m assuming?**

- Honestly, no one talked about it, but yes, for most of her competitive career probably

*Is that a sign to a young girl that she’s either not eating enough or she’s exercising too much, or to a woman of any age?*

***Menses is a really good indicator of overall health and well-being***

- The hard part is we should catch it way before someone loses their menstrual cycle
- And there is some competition level that it might fluctuate, but you don’t want to go the entire year without having your period

**Peter’s takeaway**: at 15% body fat, you were clearly below the threshold at which your body was now catabolic, and you’re having 9 stress fractures

**When did you put that behind you, graduate school?**

- There was a lot of conversation about it being due to low bone density
- But when her bone density was measured, it was very high

***So it was very much the timing of nutrient fueling***

- Abbie went into grad school to really dive into that, and to understand the nutrition components of it
  - She had some great mentors in nutrition
- As a collegiate athlete, she did not believe in dietary supplements
- And all her early work in grad school was around [creatine](https://en.wikipedia.org/wiki/Creatine) and [beta-alanine](https://en.wikipedia.org/wiki/%CE%92-Alanine), and really understanding some of those impacts

Part of the fun part about being in this field is you are your own self-experiment, and even how you [measure composition](https://en.wikipedia.org/wiki/Body_composition#)

- Is it [DEXA](https://exss.unc.edu/applied-physiology-laboratory/lab-tour/body-composition/), is it [BodPod](https://exss.unc.edu/applied-physiology-laboratory/lab-tour/body-composition/), is it [bioelectrical impedance](https://en.wikipedia.org/wiki/Bioelectrical_impedance_analysis)?

**⇒** And knowing that those numbers are all very different

- Abbie very quickly learned that she didn’t need to train for hours a day
  - That’s where that bridge of intensity and volume come in
- Abbie always likes to face her fears, especially in grad school, and then even into her time as a professor
  - Which is why she’s here today
- She did a physique show early in her career
- How do you change the body in a way that maybe is not normal, or in a way that pushes the envelope and really dials in science
- And since then she has changed or measured before and after 2 kids

***Her translation is: science really matters***

**Back to when you were in college and you were running, were you spending time in the weight room?**

- She was and she loved it
- She was lifting and running
- Peter is struck by the point she made about how her [BMD](https://en.wikipedia.org/wiki/Bone_density) on the [DEXA](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry) was normal, but she was still having these stress fractures

*Peter is wondering if there was something that was missing because of the type of activity she was doing*

- Nope
- In the weight room, she was getting the appropriate deformation
- She’s looked at this too with some of her other athletes, and it seems to be a muscle quality issue

***This was more of a protein breakdown (catabolic) component***

*Were these stress fractures all tibial?*

- It was all her left leg and left foot
- Some of it was inside leg, on a track
- She was a D2 athlete, she competed in cross-country, indoor track, outdoor track
- Some of it was just repetitive strain
- There was twice that it happened during a race
  - She finished and she couldn’t walk

Abbie shares, “*I love to push hard and work hard, and sometimes that’s too much. It comes back to the training intensity, volume, specificity and nutrition, you can’t do one without the other.*”

**Do you remember how much protein you were consuming back then?**

- She doesn’t, but what she does remember is this was an **early sign of underconsumption**
- She had the worst **GI distress**
- She remembers having a colonoscopy, and in reality she couldn’t have a big meal before
  - She went and did 1000 repeats on the track
- She also went for extended periods of time without eating

***So, it wasn’t necessarily the total amount, it was just several hours in between that also played a role ‒ it’s the protein and the carbohydrates***

- She would train twice a day every day
  - Morning, go to class
  - Train in the afternoon, go to some sort of meeting
  - And so just gaps of long periods of time without fuel versus more frequent consumption

**When you got to graduate school, did you continue to run?**

- Yeah, she thought you had to train all the time

> “*I still train and love exercise, but I learned that you didn’t have to train as much, and I really started to learn the keys of nutrient timing and optimizing nutrition, and the impact of some dietary supplements.*”‒ Abbie Smith-Ryan

**Besides creatine, what are your other staples supplements now, you mentioned some amino acids?**

- Whey protein [and] amino acids are going to get you the same, but sometimes she doesn’t want a milky substance, and the amino acids are absorbed a little bit faster
- Omega-3
- Vitamin D
- Magnesium
- Creatine
- Multivitamin,
- She likes a probiotic (which is debatable), she uses a multi-strain based on her GI system
- [discussed in [her review from 2021](https://pmc.ncbi.nlm.nih.gov/articles/PMC8015182/#Sec13)]

## How pregnancy and the postpartum period affect body composition, and how consistent exercise and intentional nutrition can prevent a permanent shift in body fat or muscle mass [A: 1:13:30, V: 1:19:13]

**How did your body comp then change over pregnancies?**

*If you go back to prior to your first pregnancy, what was your body composition, and how did that change at your second, and then obviously following that?*

- Peter thinks this is probably something most women are very interested in
  - What should I expect is going to happen?
  - Do I have a new set point after pregnancy?
- Abbie doesn’t really need to talk about her personal numbers

***This is where science can play a really important role in tracking these changes***

- With both of her pregnancies she had about an 8% increase in body fat
  - Depending on the measurement, sometimes you can’t really tell the lean mass component
- She definitely didn’t lose muscle and she gained some fat
- As a follow-up, she usually would measure about 3 months postpartum, and it took about 6 months to get back to normal

> “*I think it’s important to say you don’t have to exercise crazy, it’s finding time when to train.*”‒ Abbie Smith-Ryan

- She’s been the same % body fat and changed muscle depending on her training for the last 15, 20 years
  - After she learned a little bit in grad school how to optimize
- A lot of her students always say, “I*t’s not fair you have science on your side*,” but we all can have that

***Meaning consistency, some high intensity and appropriate nutrition, you don’t necessarily have to have a new set point, and if you have that consistency it can really help***

**Your youngest child is how old today?**

- 8

*So, you’re 8 years post your second pregnancy, and is your body composition today approximately the same as it was prior to the birth of your first child?*

- Yes

*Not just your weight but your actual body composition?*

- Yes
- Abbie likes to periodize and sometimes she’s leaner or sometimes she’s not, as part of her training
  - But it’s not very different
- She also likes to play around, especially now when the message is, “*Oh, as a midlife woman you can’t gain mass, or you’re losing muscle mass,*” it doesn’t have to be true
  - Abbie has gained lean muscle
- Or if she’s training for something that’s more aerobic, she’s maybe lost a little muscle
- Of if your traveling, sometimes your diet is more locked in and sometimes it’s not

***It’s all about prioritizing that***

Abbie shares, “*One thing I often tell women is the times that I want to be leaner is I’m actually eating more.*”

- She is prioritizing whole foods, eating consistently throughout the day
- Versus the times when she’s not paying as much attention and may gain some fat mass

**Explain that, it seems a little counterintuitive**

*When you say you’re eating more during the periods in which you’re leaner, you mean more volume of food but lower caloric density, or what do you mean?*

- And more frequency
- She would love to talk through some of the fasting literature, but in reality, many women might wake up not eat breakfast, might have something at 11:00, and then continue on, or grab a snack, and those foods are typically not necessarily nutrient dense
  - This is not just her personally, this is based on science as well

> *“If you shoot for about 30 grams of protein and some fiber, [and] some vegetables evenly throughout the day, it stimulates metabolism, you’re getting more macro and micronutrients.*”‒ Abbie Smith-Ryan

*In other words, the mistake that you think people are making is time restriction on their feeding?*

- There’s a time and place for time restriction

***What we’ve seen right now when we’re looking at this is many women chronically time restricting, it can lower metabolism, and then there’s the aftermath on our hunger hormones***

- When they start eating, they can’t stop, or it does impact protein synthesis and metabolic rate and muscle loss
- Especially in this midlife window, Abbie thinks we need to pay a little bit more attention to food consumption

**Going back to what you said about within 6 months of your pregnancy you had returned to your pre-pregnancy body composition, were you breastfeeding during that period of time?**

- She was breastfeeding
- She does not do pregnancy research, but she did take this approach during pregnancy, “*I believe birth is one of the most athletic events you’ll do, and you should train for it.*”
  - She exercised consistently
  - She slowly increased her calories in a way that was almost like a re-feed period, so that she had a bit of a caloric surplus
- And then, postpartum, obviously it’s hard to nurse and feed yourself and all the things, but she was able to go back to a normal calorie balance

***Yes, nursing does help, but she also was exercising consistently***

- And so, there’s a bit of calorie play you can do to help with those metabolic changes

**What was your exercise in the third trimester, what were you prioritizing?**

- With her first child, she could do some running, but she really focused on resistance training
- She did a lot of squats, a lot of lats, really thinking about the muscles that are going to help with delivery
  - She squatted for the delivery of both of her children
- She worked out up until the day she delivered
- She wasn’t doing as much high-intensity work, but optimizing blood flow and muscle fatigue to help with birth

**How long after delivery were you back to exercising?**

- She had 2 natural deliveries
- She definitely started walking within a couple days
- And then she was doing resistance training within a couple of weeks, but lightweight

Abbie shares, “*That’s the benefit of being active. I could go back, I would run within a few weeks, nothing crazy*.”

**When you were pregnant, how much did you need to fight cravings?**

- Yeah, oddly she didn’t want to eat animal proteins
  - Which was really hard, and she didn’t want a protein shake, none of that sounded good
  - And so, she definitely had to prioritize plant-based proteins ‒ that’s just what tasted better
- Interestingly, she craved donuts
- She’s not a person that eats a lot of refined carbohydrates, but she ate those

***She didn’t track her macros necessarily, but she was intentional about eating consistently to fuel so that she was a bit on a caloric surplus***

**And then, once you had your children, what changed about your nutrition?**

*Did you very quickly get back to your baseline eating or was there a period in which you still had cravings?*

- She was often dealing with GI distress
- There was probably some lactose intolerance immediately post [birth]
- She remembers eating a lot of liquid foods because you’re carrying a child

***She was prioritizing and integrated protein shakes and omega-3 and creatine to help maintain when you’re not sitting down to eat full meals***

**What do you think are the biggest mistakes women are making in the pregnancy and the post-pregnancy phase with respect to training and nutrition?**

For nutrition, we either go one way or the other

- 1 – We use it as an excuse to eat whatever we want
- 2 – Or the opposite of not paying attention: it should be a key priority
- Abbie also thinks about the development of the baby
  - Of the neural development ‒ there’s a lot of nutrition that can play a role there
  - And even down to the gut health, so like fruits and vegetables, variety (really prioritizing nutrition)

It is an athletic event to deliver a baby, we should exercise

- Resistance and aerobic exercise
- If you’ve never exercised, you should include something
- And if you’ve always exercised, then you can continue that
- There’s better guidance now than there was 8-10 years ago
- And then into postpartum, it goes back to not the mom guilt, but now how do I incorporate this?
  - Especially with nursing and hydration and sleep deprivation
- Abbie thinks there’s something special that happens, somehow a mom can go with no sleep and still do all the things

***But think about exercise and blood flow, it has a big impact on that***

## Changes in muscle quality and metabolic flexibility during perimenopause and menopause, and how exercise may counteract hormonally driven sarcopenia [A: 1:21:45, V: 1:28:40]

- Women disproportionately suffer from [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia) relative to men, presumably there’s 2 things that are feeding into that
  - Genetically women have less muscle mass to begin with
  - Secondly, it seems that women are less likely to engage in resistance training than men

**Do we have data on what the differences are?**

- Abbie loves that Peter is asking compared to men
- Let’s look at women too, it’s not just the comparator
- There’s some really good [data](https://pmc.ncbi.nlm.nih.gov/articles/PMC12421175/#:~:text=Population%2Dlevel%20research%20shows%20that%20although%20only%201%20in%205%20women%20(19.9%25)%20report%20engaging%20in%20any%20regular%20muscle%2Dstrengthening%20exercise), [Bill Kramer](https://ehe.osu.edu/human-sciences/directory?id=kraemer.44) just wrote, *“About 1 in 5 women participate in resistance training (so about 19%), and it’s only 1 day a week.”*
  - This is women of all ages (all-comers)
- We’re at this really unique time because we have [Title IX](https://en.wikipedia.org/wiki/Title_IX) (which came about in 1972) ‒ so now we have this group of women that are aging, that do have more experience with exercise, and they’re aging differently than we knew before
- When we think about women in this timeframe, whether we compare them against men or not, there are key things that happen with our changes in hormones (even that impacts sarcopenia)

***Hormones and things like oxidative stress, and inflammation, and change in vasodilation, all of that can impact nutrient delivery, and blood flow, and cardiometabolic health***

**What are the most important things that a woman should do differently in menopause compared to pre-menopause with respect to training?**

*Or is the answer whatever you were doing before (assuming you were doing the right thing), is all you need to continue?*

- Yes
- We have some good data on people post-menopause in their 60s and 70s
- What we’re really missing is what’s happening in our 40s and 50s

**Abbie’s data and some other labs show that muscle quality very much changes**

- She actually did a [two-year longitudinal study](https://pubmed.ncbi.nlm.nih.gov/40353388/) and brought women back after initial measurements
  - In that initial measurement we gave them pretty comprehensive information about their body composition, their strength, their nutrition
  - And what we saw was then 2 years later: in individuals that followed some of those recommendations, there were less changes
  - It didn’t align with a lot of our SWAN data ([the study of women’s health across the lifespan](https://www.swanstudy.org/))
  - They were able to maintain some muscle size, but we saw significant changes in muscle quality
  - Abbie’s analogy: it’s very much like a ribeye versus a filet

*Did you do muscle biopsies?*

- We did muscle quality from ultrasound and [PQCT](https://en.wikipedia.org/wiki/Quantitative_computed_tomography), and that PQCT is very related to MRI
  - We have some of that data now that we’ve looked at with MRI, and it’s the same theme
- There’s also a group out of Australia, [Severine Lamon](https://experts.deakin.edu.au/2052-severine-lamon/about), they just did this long [longitudinal study](https://pubmed.ncbi.nlm.nih.gov/40296368/) looking at perimenopause and postmenopause and ***the data continues to show that muscle quality changes most in perimenopause***

*Is the muscle fat, is the marbling occurring between cells or within cells?*

- Abbie is not sure if we know, it depends on the measurement
- Peter replies, “*So, no one’s doing a biopsy because that’s obviously how we would figure it out, or are people doing a biopsy?*”
- There’s a [pre-print](https://www.medrxiv.org/content/10.1101/2025.07.21.25331955v1) that just came out from Lamon’s group, they did biopsies
  - They had pre, peri, and post, but there was only about 5 [women in] perimenopause
  - Abbie would have to go look and see exactly where the marbling was coming from
  - ***There is a really good data on neuromuscular changes, and the ability, and muscle fiber type***

**Abbie asks, “*****My question back to you would be, what’s your thought process on why it would matter?*****”**

- Peter explains that intracellular fat accumulation would contribute to [insulin resistance](https://en.wikipedia.org/wiki/Insulin_resistance), and that would be viewed as more pathologic
- Athletes often have a lot of fat between cells, but the challenge of static evaluation is you don’t know if that’s a static pool of fat (which would be a bad sign) or if it’s in flux
  - Is this fat being consumed?
  - Because obviously fatty acids are very desirable to muscles, especially a very metabolically flexible muscle, which can oxidize fat across a wider range of energy output
- Abbie is measuring that in different way, not with biopsy but with indirect calorimetry through metabolic flexibility
- She just finished a project looking at microdialysis within fat of perimenopausal women
  - It can also be done within the muscle
  - Trying to understand fat oxidation, not only during exercise but before and after exercise
  - To get at: What is the oxidative capacity and how metabolically flexible is the muscle?

**What are you finding? Are you looking at maximum fat oxidation with indirect calorimetry?**

- We’re doing that, as well as metabolic flexibility

***Some of her early work demonstrated that it was in perimenopause at moderate intensity that women were less [metabolically] flexible***

*How are you quantifying or measuring or defining metabolic flexibility?*

- Peter assumes she’s measuring their [IC](https://en.wikipedia.org/wiki/Indirect_calorimetry) across varying intensities
- Yeah; using a blend of our [RER](https://en.wikipedia.org/wiki/Respiratory_quotient#Respiratory_exchange_ratio)/[RQ](https://en.wikipedia.org/wiki/Respiratory_quotient), so oxidative metabolism from carbohydrates and fat
- Then, because of that early data, we’ve added our fat metabolism through microdialysis to understand fatty acids interstitially before and after exercise

*What are you finding in terms of, are these longitudinal studies as well, or are you only looking at women in perimenopause but you don’t have their data from prior to that?*

- Both
- Her most recent publication was a [longitudinal study](https://pubmed.ncbi.nlm.nih.gov/40353388/), then she has [one](https://pubmed.ncbi.nlm.nih.gov/36878186/) that’s more acute, which has informed her current project
  - [[2022 publication](https://pubmed.ncbi.nlm.nih.gov/35231009/) on changes in metabolism and body composition that occur in perimenopause]
  - [[findings](https://pubmed.ncbi.nlm.nih.gov/33961322/) on the contribution of lean mass and fat mass to energy expenditure]

***Abbie is now trying to understand how resistance training might modulate that [metabolic flexibility], and/or nutrition***

- We definitely need more longitudinal work, we have some

**What do you see in the perimenopausal snapshot in terms of metabolic flexibility?**

> “*I think the most important takeaway is that exercise does make us more metabolically flexible.*”‒ Abbie Smith-Ryan

Peter asks, “*Even resistance training alone, or does it have to have some cardio?*”

- This is a biased view, but we’ve really dialed in and looked at more of our **high intensity interval training** just because it accelerates lipid fat oxidation
- Obviously during exercise we’re usually mostly carbohydrate
- But post-exercise, high intensity work blunts any of our hormonal impact
  - Meaning exercise will stimulate metabolic flexibility regardless of hormones and age
- What we’re even trying to dial in now: how about fasting versus protein intake, versus carbohydrate intake
- Some of her early work right now that she’s just analyzed shows that it does seem that protein optimizes blood flow, and does not blunt insulin response post-exercise
  - So protein does seem to help with our metabolic flexibility post high-intensity work
- She has not looked at resistance training

*Are you defining metabolic flexibility on a continuum, or are you using a on-off switch where there has to be a threshold?*

- Often we’re measuring it through, not a graded exercise test, but an increased exercise intensity, using indirect calorimetry
- So, we are looking at that switch from fat to carbohydrate utilization

*And you’re defining that as your* [RER](https://en.wikipedia.org/wiki/Respiratory_quotient#Respiratory_exchange_ratio) *at 0.85. Are you asking the question at what intensity do they switch their* [*RQ*](https://en.wikipedia.org/wiki/Respiratory_quotient) *from below to above 0.85?*

- Not just 0.85, she’s using some of [Asker Jeukendrup’s](https://www.mysportscience.com/asker-as-a-researcher) work to use a mathematical model to understand that continuum, not just like an on-off

*Help me understand, what is the unit of measure for that?*

- Peter wonders, “*Is it going to be a transition from a certain number of grams per minute in total, or is it just a percentage of fat versus carbohydrate?*”
- There’s a couple different outcomes
- Sometimes the percentage is the easiest to look at, the fat versus carbohydrate

*What you’re measuring pre and post in these women is how much does their percent of fat consumption go up for a given workload?*

- We can split it based on their intensity
- So, heart rate driven: measure heart rate of low, moderate and high intensity
- And that fat to carbohydrate oxidation percentage
- And then, does that vary between pre, peri, and post [-menopause]?
- Also looking specifically at metabolic flexibility based on hormonal concentrations, early-late perimenopause

**What do you think is driving the metabolic inflexibility with aging in women?**

- It’s probably impacted by a few things
- Some of it is related to our **oxidative stress** and our **inflammation**
- We do see changes in **insulin sensitivity**

*Do we have the same literature [in women] that covers men during the same period of time where whatever effects are age-related would be the same, but the effects that are hormone-related would obviously not be present in men?*

- Peter thinks it would be interesting to disentangle those 2 (and Abbie agrees)
- One of the ways we’ve tried to do that is measure phenological age
- Because obviously aging is a really important role, but how much is [due to]: age, versus lifestyle, versus hormone-driven?

> “*More importantly is how do we use lifestyle changes to optimize that or overcome some of those hormonal components*.”‒ Abbie Smith-Ryan

- Currently, we do not prescribe or provide [menopause hormone therapy](https://en.wikipedia.org/wiki/Hormone_replacement_therapy), but that’s the next layer of then how does artificially adding hormones impact all of that?
  - It’s really what we’re trying to identify

## The biggest open questions about women’s health: combining menopause hormone therapy with exercise, GLP-1 drugs, minimizing injury risk, and more [A: 1:32:00, V: 1:40:26]

**So, you haven’t studied that, because that was going to be my next question, which is, how does hormone replacement therapy impact this change? (All things otherwise being equal?)**

- The bad thing about research is it has to be somewhat controlled
- Now, especially based on the number of women taking hormone therapy, is now we’re including individuals that are on hormone therapy or are not
- It comes back to why we need more research and dollars in this space to dial that in
- Because it would be great if adding hormones would really help overcome that, but you still have to add lifestyle
  - So, what is that combination?
- And then like you asked, what component is changing it?
  - Is it oxidative stress?
  - Is it arterial stiffness?
  - Is it blood flow?
- What are the things that are really going to optimize that so that we can really help these women as they age?
- And what should the portfolio of training look like?
  - To Peter, that is maybe the most interesting question because he just can’t imagine there is anything that is going to change metabolic flexibility more than training
  - And because virtually everybody who is going to be exercising is going to be constrained on time, figuring out what is going to give the most bang for the buck matters
- Abbie thinks that’s a really important takeaway
  - Especially now when women are getting a lot of information about what they should and shouldn’t do (it’s a little confusing)

***Abbie’s advice: first, we just need to exercise (that’s a potent stimulus)***

- Then it’s around optimizing

**Back to metabolic flexibility**

- A lot of data is around carbohydrate feeding, but when you talk about insulin sensitivity and those changes
  - Which is where Abbie’s group has focused and tried to look at: What happens when you provide amino acids to also elevate protein synthesis and breakdown?

***It seems that if we are eating our protein around training versus our carbohydrate, or changing from high to lower glycemic index, that can also optimize metabolic flexibility***

Peter responds, “*That would probably be true at any age, right?*”

- Yeah, Abbie just thinks it matters more with such a significant change

Abbie points out, “*There is a significant change in muscle size, quality, cardiometabolic health, arterial stiffness, neuromuscular changes that are happening in our 40s and our 50s, then those little tweaks do make a difference.*”

- It gives us a bigger bang for our buck when we have less time

**What do you think are the most interesting questions around women’s health that we don’t yet have a clear answer to, that could be answerable if we had the resources to study it and the will to do so?**

1 – Women ultimately want to lose weight, so how do we combine our GLP-1s with the minimal effective dose of exercise and nutrition, in a way that women can still live their lives and feel good?

- Many women are not feeling great on those drugs or they’re not feeling good off the drugs, and so there’s also a very big component of **mental health** in here, Abbie knows exercise can have a really important role in

2 – There’s much more conversation now around [menopause hormone therapy](https://en.wikipedia.org/wiki/Hormone_replacement_therapy)

- Abbie thinks there’s a lot of indirect effects on muscle and training volume, but how much?
  - For instance, adding hormones isn’t going to increase muscle directly
  - But indirectly, maybe I have more energy or I can do higher volume and intensity and I can recover better
- Then does that also put women at greater risk for injury?
  - Our tendons still change
  - Abbie’s biggest injury fear is an Achilles tendon tear
- ***How does menopause hormone therapy and training combine?***
  - There’s a new wave of very active women who are training
  - Menopause hormone therapy is helping women feel better
  - This question has application to the military, etc.
  - We need to know a lot more as we’re changing our pharmaceutical agents with our lifestyle components

*Peter’s intuition is that the answer comes down to the type of training*

- You’re less likely to tear your Achilles sitting on the couch, if you never get off the couch, you’re not going to tear that Achilles
  - Now, of course you’re going to die 1000 deaths
- So, if we give a person hormones as a part of a broader strategy around improving their health, and as a part of that, that person becomes more active, that’s wonderful, but that doesn’t prevent them from having an Achilles injury if they don’t do the type of training that would reduce the risk for that
- The good news is, we have a pretty good sense of how to do that
  - He doesn’t think we’re going to take that risk to zero
  - But if we’re doing the right things, if we really make sure the [soleus](https://en.wikipedia.org/wiki/Soleus_muscle) and the [gastroc](https://en.wikipedia.org/wiki/Gastrocnemius_muscle) are getting a strong range of motion, the bouncing exercise, maybe we take that risk down by 80%
- That’s where the education and the training specificity become really important
- Now, those things are hard to put into clinical trials
  - It’s really hard to do the clinical trial of I’m going to take 1000 people and I’m going to put half of them on a business as usual training program (which is a pump and burn program), and the other half of you are going to go on a smart program (where you’re going to do all of that stuff, but you’re also going to do all of this tissue and tendon pliability work)
  - And then we’re going to follow you guys for Achilles tears over the next 15 years
  - That study will never get done
- Peter suspects we have to be able to think through these things in terms of common sense and best practices
- He agrees with Abbie that this idea of figuring out what a world looks like where a higher and higher percentage of the population is using a [class of drug](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) that has for the first time ever really demonstrated long-term safe application of weight loss, but it does come at a cost if you’re not careful
  - Again, the knowledge is there, this is not hidden knowledge, we know what it takes to do this
- Peter would hope that more physicians are equipped to help their patients understand that we should be able to take advantage of this great drug, but it comes with a responsibility of how to incorporate it
  - And that’s unusual because a lot of times with drugs we don’t do that
  - If you need a drug for your blood pressure, we don’t have to give you a long song and dance about how to take it
  - Same thing with a cholesterol drug: you take this drug, it lowers your cholesterol, we’re going to remeasure it, it’s going to be fine

Peter makes the point, “*The* [*GLP-1*](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist)*, it’s a different class and it comes with a whole set of, if you take it great, but you got to do X, Y, and Z. And it’s just as much work.*”

## How the training response differs between men and women, and the importance of type IIa muscle fibers [A: 1:39:15, V: 1:48:27]

**What are the other misconceptions about women’s training?**

*What do you find yourself at parties having to correct people on?*

- It comes back to these absolutes that we’re hearing
  - I have to lift heavy weights
  - Or I have to do high intensity training
  - Or I have to do plyometrics

***Abbie wishes that we could just tell women: exercise and doing something is better than nothing***

- We can leverage a lot of the traditional strength and conditioning research that we have that was founded in male science
- We know the female muscle will respond
- It’s taking our program design that we know has worked, but then understanding that there might be some differences as far as recovery and rest or joint pain
  - There’s modifications that are needed

***Abbie wishes we could empower women to do the things they like to do: if we want strength, if we want hypertrophy, if we want fat loss… leverage what we have now***

**A lot of those studies have been done disproportionately in male subjects. Are you saying that to the first order approximation, the results should be the same in women?**

*Thinking about the data we have on how to optimize around hypertrophy versus strength*

- Yes, those same methods can apply
- We do see differences in detraining or percentages of loss and strength and muscle of absolutes

*Are women or men more susceptible to detraining?*

- There is some early data on this and it’s not absolutely cleary, because it’s so individual
- Abbie thinks that’s where we need to dive into
- There women that will gain more strength than men or have more muscle than men
- But when we look at the baseline fiber types (because generally women tend to have more [type I fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types)), they might change slightly differently
  - [Properties of different types of muscle fibers are summarized in the table below; they are discussed in detail in [episode #250](https://peterattiamd.com/andygalpin2/)]
- Neuromuscular aging and motor unit recruitment could vary between males and females

***Strength training works and a woman is going to gain strength and gain muscle, but not to the same absolute effect as a man***

**Are women more susceptible to the loss of type IIa fibers when they age or are men?**

![](https://peterattiamd.com/wp-content/uploads/2026/01/f3-abbiesmithryan.png)

**Figure 3. Summary of muscle fiber types**

- That’s a debatable topic
- Men tend to have more type II fibers, so then there’s a bigger area to lose or a percentage
- But with age, there’s **denervation** that happens, where properties look more hybrid or type I for males and females
  - It does seem that it maybe happens a little bit faster for females
  - But how much exercise prevents that?
- A couple of years ago, Peter had Andy Galpin on the podcast [[episode #239](https://peterattiamd.com/andygalpin/#:~:text=Changes%20in%20muscle%20fiber%20types%20associated)], and he said something that really resonates with Peter, along the line of, “*Hypertrophy of the type IIa muscle fiber is the sine qua non of aging.*”
  - The first thing you’re going to lose is explosiveness (power)
  - Strength is the next thing that starts to go
  - Hypertrophy is the last thing to go

***What Peter took away from that: if we’re losing power in our 20s (power peaks in our 20s) and it’s all downhill from there, power is the thing that he wants to fight to preserve***

- He’s never going to go and do the same insane workouts he was doing in his teens and 20s, but he’s still going to fight for power
- He’s going to do it in a more controlled way
  - Do more stuff on a [Keiser](https://www.keiser.com/science) as opposed to jumping around and dining insane box jumps
  - But he’s still jumping, he’s still bouncing
  - He’s still trying to recruit the type IIa fiber whenever he can

*Would you make the case that that’s even more true for women, given that they are losing more type IIa fibers?*

- 100%
- And women would probably say, “*Who cares about power?*”

***There’s so much relationship between [power and] health, quality of life, and injury prevention***

**Peter gives a tangible example of why every person needs to care about power**

- If you or I were to go and walk down the street right now and we were so lost in discussion that we lost our footing as we **stepped off a curb,** it wouldn’t faze either of us
- We would step off that six-inch curb and we would immediately be able to readjust our footing and prevent ourselves from falling on our faces, and we would go on carrying on talking about metabolic flexibility
- When a 65 or 70-year-old person steps off that curb and misplaces their footing, they’re very likely to land on their face because they don’t have power

***That’s the reason Peter wants everybody to care about power: it’s the difference between falling when you stumble versus regaining your footing***

- And it doesn’t have to do with if you want to dunk a basketball
  - That’s a nice ancillary benefit if you want to dunk or ski or all those other things

***It really comes down to life, and that matters more in midlife ‒ we want to do what we can right now***

- The later you go, the more it matters

> “*What we can do now is have a bigger impact over time. If I do things right now in my forties to maintain power, it will help.*”‒ Abbie Smith-Ryan

- Inevitably, we are going to lose that
- And I want to ward that off as soon as I can so that I have that ability to maintain power longer

Peter proposes, “*Maybe that is another one of the reasons that we see for potentially women suffering more falls.*”

**Abbie points out that lot of side effects happen in midlife**

- A lot of women experience **joint pain**, and now you want me to tell a woman to do plyos and bounce
- There are some intangibles we need to consider [such as]: How do I tell a woman to maintain power based on some of these things that she’s experiencing?
- There’s also central fatigue and changes to **brain health**
  - Whether it be indirectly from sleep, and that’s where some of the nuance comes in and we need more guidance

**We know what training tactics might help maintain power, but how do you do that in different scenarios for a female that are maybe unique to her?**

- It always makes Peter sad when he hears about perimenopausal and menopausal women that are complaining of **joint pain**
  - When you realize that for many of those cases, [hormones](https://en.wikipedia.org/wiki/Hormone_replacement_therapy) would probably fix those issues
- And so, it’s hard to ask somebody to train when they’re constantly in pain when we have a solution to that and we’re not giving it to them

**What about the woman who’s listening to this who’s 65, 70 years old and asking, “*****Is it too late for me? Has the ship sailed?*****”**

> “*No, that’s the beautiful part about the human body and about exercise: you literally can do it at any time*.”‒ Abbie Smith-Ryan

- If you can start sooner, that’s better
- But no, you can gain strength and muscle at any age
- Obviously, there’s some challenges and you might change your volume and intensity

***You can start and we all should be motivated to do so; it’s the way we can control our healthspan***

## Training advice for the hypothetical 70-year-old woman who has never exercised deliberately [A: 1:47:00, V: 1:57:13]

**Case study #3: What would be some specific advice for a 70-year-old woman who’s never exercised deliberately in her life?**

- She’s healthy in the sense that she’s not riddled with injury at the moment, but she’s already experiencing a dramatic reduction in stamina and strength
  - Maybe she’s struggling to open a jar
  - She can walk up a flight of stairs, but she notices it in a way she didn’t notice it 10 years earlier
- Now, she has one thing on her side, which is time

*How would you advise her to go about starting a routine for the rest of her life, and how would she titrate up?*

1 – Abbie highly recommends hiring a **personal trainer** to really teach her

*How should she look for one?*

- A referral is a really important starting point
- Maybe a physical therapist has a good recommendation or someone locally
- There are some credentials to look for, but it does depend on where she lives

*Let’s say you were her trainer or if she was lucky enough to find someone of your knowledge, how would you think about creating a program for her?*

- It’s all about adding a slightly higher stimulus than what she’s doing now

One thing we haven’t talked about is people are motivated by different things

- Is she motivated by a group?
- Is she motivated to do it on her own?
- Is she motivated to be in a gym?

A starting point will be different depending on what motivates you

- Maybe starting with resistance bands at home
- Or is she excited to go do Silver Sneakers somewhere?
- Does she need to be in a gym with machines-based controlled stimulus?
- Abbie wouldn’t start with a ton of free weights
- There’s so many options

**Let’s say she goes to a gym nearby with all the machines. How would you think about putting a program together?**

- 1 – Abbie would do a total body program focused on **glute activation** to help with the lower body and slips, trips, falls
  - A [leg press](https://www.youtube.com/watch?v=7H-KpNTYw_k) and also some neuromuscular activation standing up
  - A lot of times the leg press is not activating the glutes, so some banded work to activate the glutes to get started
  - Maybe a leg press, [leg extension](https://www.youtube.com/watch?v=Zlu2BOHPyD4)
  - Abbie wouldn’t start with a lunge for this individual
- 2 – She would **do a push and pull for every muscle group**
  - And this is not just specific to females
- 3 – Work every muscle group in the lower body
- 4 – Do something to work the **calves** to help with stability
- We haven’t talked about the shoulder joint, upper body
- 5 – There’s a lot of benefit in strengthening all aspects of the **shoulder joint** in the [deltoids](https://en.wikipedia.org/wiki/Deltoid_muscle)
- 6 – A full body-upper body exercise

**How many days a week and how many minutes a week would you have her doing resistance training?**

- That’s a tricky question
- Soreness is going to be a consideration

***Not knowing a lot about her, Abbie would want 3 days a week of resistance training***

- Most days a week, she should be doing some sort of movement ‒ start with aerobic exercise
- Obviously titrate every other day to allow for recovery

*How long would you want before you would introduce things that are not tied to a machine?*

- For example, [carries](https://www.youtube.com/watch?v=z7E_YU9P1jU): walking with dumbbells in her hands or kettlebells in her hands
- How long until you would want her testing multiple things where she’s now testing core stability, grip strength, foot reactivity?

*What do you want to see before you would engage in that?*

- Abbie doesn’t work with a lot of older adults, so she doesn’t know
- She often starts them with pretty progressive resistance training, a controlled scenario

She turns the question back to Peter and asks, “*What would you look for?*”

- Peter would look for the ability to do these things de-loaded safely
- And then if you can do something de-loaded, he would add low resistance and progress from there.
- Peter really loves carries
  - He thinks grip strength is so underrated in a
  - She could start with just holding some dumbbells (not walking)
  - Start with a lot of sub-maximal efforts: use a light enough weight that she can hold it for a minute, rest for a minute (repeat 3x) and never failing on those
- If you were talking about machines, he’d also love to see a [hip thrust](https://youtu.be/jQkKeL4Cg8M?si=Pc7_zX4A_uT1nCGG) or something like that

Abbie notices, “*Seems to be a common theme, one minute on, one minute off*.”

- One of Peter’s favorite sets is just a walk and carry hold
  - 20 sets of either 30 on 30 off or a minute on a minute off (with a little less weight)
- [Belinda Beck](https://theboneclinic.com.au/about-us/), a woman from Australia who did the [LIFTMOR study](https://pubmed.ncbi.nlm.nih.gov/28975661/) ‒ Peter was impressed that they were able to teach these women how to do barbell deadlifts and things like that (they were really throwing some weight around)

Earlier in Abbie’s career she did some [work](https://pubmed.ncbi.nlm.nih.gov/26657810/) with older adults

- They gained massive amounts of strength in 24 weeks doing things like squat and [bench press](https://www.youtube.com/watch?v=JvOJdUtx6UQ)
- Abbie doesn’t know if she’d necessarily have them do squats (we usually do a [leg press](https://www.youtube.com/watch?v=7H-KpNTYw_k))
- Absolutely, you can start at any age

**Anything else you think where there’s the most daylight between men and women in training that maybe we want women to be more aware of as they consider their own journey?**

- This is not Abbie’s area of research, but the impact on mental health is huge

> “*Exercise has a positive impact on anxiety, depression, even brain fog.*”‒ Abbie Smith-Ryan

Abbie shares her analogy, “*There’s days that I feel like I have about 20 squirrels in my brain, and it’s when I go exercise that the squirrels finally tame down.*”

- In reality, a lot of times women think that they are abnormal or it’s unique to them, but exercise (both resistance training and aerobic exercise) has a huge impact on that mental cognition, focus, anxiety, depression
- Abbie would love to continue to provide better prescription there or have women understand what they’re looking for

## Misinformation about exercise and nutrition for women, injury risk, supplement hype, and the need for more nuanced messaging around hormones, recovery, and midlife training [A: 1:53:30, V: 2:05:05]

**Do you think there are any trends that are out there today that you think are at best incorrect, at worst, potentially harmful as it pertains to things women are being told about exercise or nutrition as it pertains to conditioning?**

- Yeah, it’s harmful to say you need to only do this or not do that

***Our very black and white pragmatic thinking is harmful, because in reality, every woman is individual***

- The best part about research is it provides little tools in our toolbox, and that changes as we get an injury
- Or maybe I have lifted heavy my whole life, but I still want to gain strength
  - Well, I need to modify and adapt

***Exercise does not have to be overwhelming, neither does nutrition***

- So much of the advice now is, “*Oh, you have to do it this way, or this is the only way that’ll work now that you’re in midlife, or you have to change your training*.”

***When in reality, most of us are just trying to get something in and do it consistently. So less rules and really understanding that exercise is powerful no matter how you do it.***

**We are not giving enough conversation to injury and recovery from injury**

- This can be really impactful
- Recovery from injury takes longer as we age

Peter points out, “*One of the injuries we seem to see more in women than in men… is high hamstring injuries (and my wife has a theory about this).*”

- Her theory is after pregnancy, when the pelvis moves a little bit [it changes the gait]
- She was a runner before and after having kids and she noticed, “*I’ve never run the same post-pregnancy… I don’t feel the same. I used to float and now I don’t feel like I float.*”
- She actually runs the same time
  - She ran the Boston Marathon this year and she ran it 19 years ago, and her time this year was only 45 seconds slower than her time almost 20 years ago
- She trains a lot smarter today, and Peter thinks that’s why her running times are still really good
- But she’s had a couple of these really high hamstring tendinopathies, and he sees this a lot in women, more so than men
  - But it could be just a small “n” [sample size]

**Are there any other injuries that you’re seeing that you think women need to be aware of?**

***It does seem like women have more*** [***ACL injury***](https://en.wikipedia.org/wiki/Anterior_cruciate_ligament_injury) ***in midlife***

- This is probably because most of Abbie’s colleagues at UNC are studying knee injury
- It goes back to the caliber and the accumulation and competitive nature of women in this lifespan
  - They all played sports when they were younger, so Abbie doesn’t know if it’s necessarily a male-female thing

One area of interest for Abbie is looking at **muscle tendon stiffness** and how that changes with not just age but hormones

- And then how do we change and prevent that?
- Because a lot of times this not coming from a contact injury
  - It’s coming from someone slipped because their dog pulled them
  - And so what’s happening? Abbie is not sure
- Is it just because more women are more active, and now we’re hearing more about it?
- Peter agrees, “*That would be really interesting to understand how much of that is occurring as a result of age, in which case, you would expect it to be equal between men and women versus hormones specifically.*”
- Abbie thinks maybe some differences in inflammation and some of the neuromuscular aging that is seen with those hormonal changes
  - She would hypothesize that would have an impact
  - But not necessarily just to a knee joint, but some of those musculoskeletal injuries

Peter asks, “*You’re saying that hormone loss is increasing inflammation as the mechanism?*”

- No, not directly, but we tend to see more inflammation in perimenopause when estrogen changes
- It can be measured in the blood ‒ [high sensitivivity-CRP (hs-CRP)](https://en.wikipedia.org/wiki/C-reactive_protein) would be the key biomarker

Peter asks, “*So, you’re seeing that higher in perimenopausal women, not on hormones?*”

- Abbie can’t answer that directly
- Some of the work is showing that inflammation is changing
  - Whether it’s coming from hormones or not
  - Or if hormone therapy changes that she’s not sure we know
- Peter was not aware of that, but wants to look into it

**Is there anything else you think we’re missing in terms of trying to make sure we give women at all stages of their lives training input that they might otherwise be missing or dispelling any things that you think they’re hearing?**

*What are some of those black and white things that you think are most misleading?*

- Abbie has 2 thoughts

1 – Creatine supplementation

- She knows Peter has talked a lot about creatine on other podcasts
  - [recently with Rhonda Patrick, [episode #369](https://peterattiamd.com/rhondapatrick3/)]
  - [see also [AMA #69](https://peterattiamd.com/ama69/) and [episode #235](https://peterattiamd.com/laynenorton3/)]
- Her lab is one of the few testing creatine supplementation in women

> “*I think creatine is great and there’s a lot of benefit, but that doesn’t mean it’s magic.*”‒ Abbie Smith-Ryan

***Abbie thinks creatine can be helpful with training, but it’s not the first thing she goes to for midlife women***

2 – One of her motivating factors is to have more conversation around not just training, but physiologically and mentally around this midlife space

- How do we have a better conversation and be informed on what’s hormone driven and what we can overcome
- Versus what do I need medical help for and how do I advocate for myself?
  - Especially as we pull in science, it’s very difficult to do
  - And so many women are invalidated with their experiences
- And how do we leverage men in the conversation?
- Peter’s point of view on hormones is very well known
  - He maintains that he’s yet to find a better example of how the medical system has screwed up in the last 25 years than on this issue
    - Both in the magnitude of what it is and just the fact that it’s 50% of the population have been hurt by this
    - He’s done this analysis literally in a model, and he can’t come up with a greater negative impact
- Luckily, the tide is turning

## Benefits of hormone therapy in midlife women and its interaction with exercise and lifestyle interventions [A: 2:00:15, V: 2:12:30]

**Menopause hormone therapy**

Post-menopause

- Peter points out the unfortunate reality: there’s a generation of women now that have fallen outside of the window in which doctors (who are even starting to come around on [hormones](https://en.wikipedia.org/wiki/Hormone_replacement_therapy)) feel comfortable prescribing hormones
- Although, [Rachel Rubin](https://www.rachelrubinmd.com/drrubin) was a guest on this podcast, and she made a very compelling argument for the fact that that’s a little bit of a BS argument [[episode #348](https://peterattiamd.com/rachelrubin/)]
  - If a woman is 60 and she’s been in menopause for 10 years, that’s not disqualifying, and there’s no evidence that we can point to that we’re driving rates of breast cancer by giving that woman hormones
  - And so if she’s going to benefit from it, then she should be on it

As far as women going through menopause now

- The good news is Peter thinks there are enough doctors out there (it’s still a very small number in absolute terms) who are simultaneously willing to do this and competent to do it
- The competence is a hard piece, because there are more tools than ever before
  - In the olden days, it was [MPA](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate) and [CEE](https://en.wikipedia.org/wiki/Conjugated_estrogens) and that was it
  - And of course, today we would never use either of those hormones
  - So, you have to know more
- But look, that’s why this podcast exists: anybody who wants to understand how to safely and intelligently provide hormones and think through the nuances
  - When do we want to start with topical [estrogen]?
  - When do we want to use this variation, that variation and that?

Peter emphasizes, “*We’ve gotten more content on that than I can point to. So, it’s out there. And I would just say, look, don’t be satisfied with no.*”

- If a provider says no, then it’s time to find another provider
- And fortunately, it looks a lot better today than it did 5 years ago
  - 5years ago was pretty bleak, and Peter thinks in 5 years it’s going to be even less bleak than it is today

**Combining menopause hormone therapy with exercise**

- Abbie points out that they were talking about GLP-1s with exercise
- She notices that often when we’re talking about hormones and hormone therapy, ***we’re not talking about lifestyle behaviors and the combination of the two to help relieve symptoms***

She asks Peter, “*Do you ever see that coming into play or being an important component?*”

- From where Peter sits, it’s not really a concern because he’s always talking about all of these things all the time
- He’s probably not the right person to answer that question because he’s not seeing the other side of that

Peter adds, “*I can appreciate the fact that anytime you can take a drug, it’s easier than making a change.*”

***A lot of times those lifestyle changes end up being more powerful***

- In both of these cases, a lot of times the drug makes it easier to make the change
- In the case of [hormone](https://en.wikipedia.org/wiki/Hormone_replacement_therapy) [replacement therapy], there’s an independent benefit that also comes from it that’s unmistakable
  - Meaning independent of whether you exercise or not, you’re going to benefit from taking hormones

***The point is: Can you have an accretive benefit if you do both of these things? And Peter thinks the answer is almost assuredly yes.***

- He doesn’t think we’re going to prove that in a study
- But it’s really hard to imagine a scenario whereby combining both of those things doesn’t lead to an even better outcome than doing one by itself

## Peter’s overall take on how women should approach exercise volume and intensity at various life phases and time constraints [A: 2:03:00, V: 2:15:50]

**Abbie asks Peter, “*****Is there any key research in this area that would inform your clinical practice or do you see a gap that would be beneficial?*****”**

- With respect to hormones and exercise or midlife women
  - Obviously hormones are often a part of the conversation, but not always
- There’s the really interesting questions scientifically that often don’t matter that much in the real world
- For example, there are lots of questions Peter could imagine asking if we were talking about unconstrained or unlimited amounts of time
  - And that applies to some people
  - He knows some people who do have 8-10 hours a week to exercise
    - And in those situations we could have a very different discussion about how to optimize training
- He’s pretty interested in how you would optimize training in a resource-constraint world
  - Questions include: Are 4x4s better than 1x1s? [for HIIT]
  - He doesn’t know the answer
  - He suspects the answer comes down to which one you can do more diligently

Peter thinks the application of this stuff is what matters the most

- The unfortunate reality of training is: if you’re not providing enough training stimulus, you’re getting a suboptimal result

***What he really wants is for people to understand how potent this tool is if you can provide the right stimulus. And the shorter your volume of training, the more important the intensity of that is.***

- Therefore, if you’re only going to lift twice a week for 30 minutes
  - You can’t phone those in, you got to actually do the work
- In fact, it’s easier for Peter in the gym 6 hours a week
  - He’s making up for it in volume
  - He’ s going to 1 or 2 reps in reserve, but he has so much volume that it’s okay

***But if you told him that he only gets two 30-minute shots, he’s probably going to go to failure on every set (and that’s harder, that’s neurologically way more taxing)***

- If you told him you only have these 2 short cardio workouts per week, again: can’t phone those in, you’re showing up to push

Now, does that matter if you’re starting out from a low base?

- No, because any training stimulus matters

Peter makes the important point, “*But if it’s you or I who have a training history that is this thick, then no, we actually have to show up and crush those workouts if we’re going to get the benefit*.”

Abbie also thinks it’s maintenance as well

- You don’t want to have to go in and crush it every 4 days as we age

***It’s also understanding what’s the outcome: we’re still going to get health benefits [from exercise]***

- This is why Peter likes having volume on his side: he doesn’t really have to crush many workouts
  - These days, he really only does one workout a week that’s hard
  - Abbie agrees with this strategy

**Abbie asks Peter what exercise plan he would recommend for her if her goal was maintenance?**

*She’s in her early 40s, and most days there are literally not enough hours in the day to get in training*

- Her kids are 8 & 10
- She’s a professional, working her tail off
- Peter thinks she’s in a rare position: most people her age aren’t in anywhere near the shape she is probably in
- For her, **maintenance** would be great (he doesn’t want to minimize that)
- He also doesn’t want to minimize the importance of **avoiding injuries**

***There has to be enough training stimulus for you to maintain muscle mass and enough training stimulus for you to maintain peak cardiorespiratory fitness***

- But that still does require some intensity, and you can probably get that with the intervals Abbie described earlier
- He wouldn’t say that that she needs to be doing any more than that for sure

***She doesn’t need to crush every workout***

- And Peter doesn’t think a 40-year-old can crush every workout

Peter clarifies, “*My point is, if you’ve only got a couple of hours a week to exercise, I don’t think most people who have never exercised understand how hard they do need to push.*”

- The difference is Abbie and Peter did workouts in their teens and twenties where they were left vomiting at the end of those workouts
  - That was actually the norm.
- So compared to that, they’re not crushing anything today, but they’re still working a lot harder than most people appreciate

When someone is starting from nothing today

- You’re coming into this with very low volume
- Once you get over that early adaptation, it is going to have to be quite painful
- And it’s teaching people what that good pain is
- Sometimes it is maintenance
- There’s different phases of life where we change our goals
- To tell that 39-year-old, 40-year-old to train now
  - That can go a long way so that you don’t have to train as much over time
  - Or that you can do it differently and still see a benefit

> “*I think this is such a gift to be able to exercise. It is such a remarkable stimulus basically, and it’s one thing that I think will never be displaced by a pill.*”‒ Peter Attia

- We might figure out how to displace some myokines here and there, but Peter thinks there are far too many benefits that we get from exercise that could ever be displaced (Abbie agrees)

**Peter’s hope is that everybody finds their way to exercise**

- And if the most you can do is be at 6 out of 10, great, he’ll take 6 out of 10 on this front all day long

But maybe he’s speaking to a narrow subset of people who do exercise, who understand its importance, but maybe aren’t making progress because they have hit a plateau on training stimulus

- He sees this all the time
- He talks to a lot of people and they think they’re doing Zone 2, but they’re not
  - They’re doing Zone 1 and they’re getting actually no training effect whatsoever
  - They’re basically doing recovery workouts every single day
- People just have to understand the nuance around that
- There’s a line between those things and everyone needs to understand where it is

And what’s the outcome: Is it health, is it performance? What are our targets?

- Peter loves this topic and especially thinks it’s important for women to understand the complexity around this
- There is a lot of conflicting information, probably some incorrect information
- Luckily today, women are realizing the importance of resistance training perhaps in a way that they didn’t 20 years ago
  - Now when Peter talks to women and asks what they’re doing for exercise, even the ones who don’t resistance train will usually follow it up with something, “*But I know I probably should be*.” And he doesn’t know if he would have heard that 20 years ago
- Abbie agrees and thanks Peter for giving science some light in this space

***We can really empower women, not just to do cardio and do resistance training, but to find a time they can make space for it***

---

## Selected Links / Related Material

**Creatine supplementation throughout the menstrual cycle**: [The Effects of Creatine Monohydrate Loading on Exercise Recovery in Active Women throughout the Menstrual Cycle](https://pmc.ncbi.nlm.nih.gov/articles/PMC10459976/) | *Nutrients* (A Gordon et al. 2023) | [26:00]

**Abbie’s review of benefits of creatine supplementation for women**: [Creatine Supplementation in Women’s Health: A Lifespan Perspective](https://pmc.ncbi.nlm.nih.gov/articles/PMC7998865/) | *Nutrients* (A Smith-Ryan et al. 2021) | [26:00]

**Episode of** ***The Drive*** **with Rhonda Patrick**: [#369 ‒ Rethinking protein needs for performance, muscle preservation, and longevity, and the mental and physical benefits of creatine supplementation and sauna use | Rhonda Patrick, Ph.D.](https://peterattiamd.com/rhondapatrick3/) (October 20, 2025) | [28:00]

**Review of female specific nutritional strategies, includes a discussion of protein breakdown and muscle protein synthesis**: [Sex differences and considerations for female specific nutritional strategies: a narrative review](https://pmc.ncbi.nlm.nih.gov/articles/PMC8015182/) | *Journal of the International Society of Sports Nutrition* (K Wohlgemuth et al. 2021) | [28:30, 1:12:30]

**Effect of creatine supplementation on intracellular/extracellular fluid accumulation**: [A Randomized Controlled Trial of Changes in Fluid Distribution across Menstrual Phases with Creatine Supplementation | *Nutrients* (S Moore et al. 2023)](https://pubmed.ncbi.nlm.nih.gov/36678300/) | [29:00]

**Importance of nutrient timing around training**: [The effects of nutrient timing on training adaptations in resistance-trained females](https://pubmed.ncbi.nlm.nih.gov/30366741/) | *Journal of Science and Medicine in Sport* (A Pihoker et al. 2019) | [30:15]

**Changes in metabolism and body composition around perimenopause and menopause**: [Menopause Transition: A Cross-Sectional Evaluation on Muscle Size and Quality](https://pubmed.ncbi.nlm.nih.gov/36878186/) | *Medicine and Science in Sports and Exercise* (A Smith-Ryan et al. 2023) | [41:00, 1:27:45]

**Scott Trappe’s work on higher intensity exercise for improved muscle size and quality**: [Skeletal muscle size, function, and adiposity with lifelong aerobic exercise](https://pubmed.ncbi.nlm.nih.gov/31829806/) | *Journal of Applied Physiology* (T Chambers et al. 2020) | [50:45]

**NHANES body composition data for the US population**: [Body Composition Data for Individuals 8 Years of Age and Older: U.S. Population, 1999-2004](https://www.cdc.gov/nchs/data/series/sr_11/sr11_250.pdf) | *Vital and Health Statistics* (L Borrud et al. 2010) | [53:00]

**HIIT may mitigate changes in body composition and menopause symptoms for women in perimenopause**: [Body composition, physical activity, and menopause symptoms: how do they relate?](https://pubmed.ncbi.nlm.nih.gov/38442308/) | *Menopause* (S Moore et al. 2024) | [53:30]

**Contributions of lean mass and fat mass to energy expenditure**: [Effects of adiposity and body composition on adjusted resting energy expenditure in women](https://pubmed.ncbi.nlm.nih.gov/33961322/) | *American Journal of Human Biology* (L Gould et al. 2022) | [53:30]

**Supplementing with essential amino acids around exercise enhances muscular response in women**: [High-intensity interval training and essential amino acid supplementation: Effects on muscle characteristics and whole-body protein turnover](https://pubmed.ncbi.nlm.nih.gov/33369879/) | *Physiological Reports* (K Hirsch et al. 2021) | [59:45]

**Benefits of HIIT in overweight and obese women**: [1:04:15]

- [Effects of high-intensity interval training on cardiometabolic risk factors in overweight/obese women](https://pubmed.ncbi.nlm.nih.gov/26934687/) | *Journal of Sports Sciences* (A Smith-Ryan et al. 2016)
- [The effects of high intensity interval training on muscle size and quality in overweight and obese adults](https://pubmed.ncbi.nlm.nih.gov/28647284/) | *Journal of Science and Medicine in Sport* (M Blue et al. 2018)
- [Metabolic and physiological effects of high intensity interval training in patients with knee osteoarthritis: A pilot and feasibility study](https://pubmed.ncbi.nlm.nih.gov/36474875/) | *Osteoarthritis and Cartilage Open* (A Smith-Ryan et al. 2020)
- [Metabolic effects of high-intensity interval training and essential amino acids](https://pubmed.ncbi.nlm.nih.gov/34427732/) | *European Journal of Applied Physiology* (K Hirsch et al . 2021)

**Proportion of women resistance training**: [Evolution of resistance training in women: History and mechanisms for health and performance](https://pmc.ncbi.nlm.nih.gov/articles/PMC12421175/) | *Sports Medicine and Health Science* (W Kraemer, M Fragala, N Ratamess 2025) | [1:22:15]

**2-year follow-up on changes in body composition around menopause**: [Physiological alterations around the menopause transition-A 2-year follow-up in PRE, PERI, and POST menopause females](https://pubmed.ncbi.nlm.nih.gov/40353388/) | *Clinical Physiology and Functional Imaging* (P Baker, S Moore, A Smith-Ryan 2025) | [1:23:30]

**Longitudinal study of muscle mass in females across the menopausal transition**: [Associations Between Female Sex Hormones and Skeletal Muscle Ageing: The Baltimore Longitudinal Study of Aging](https://pubmed.ncbi.nlm.nih.gov/40296368/) | *Journal of Cachexia, Sarcopenia and Muscle* (A Critchlow et al. 2025) | [1:24:45]

**Changes in metabolism and body composition that happen in perimenopause**: [Metabolic effects of menopause: a cross-sectional characterization of body composition and exercise metabolism](https://pubmed.ncbi.nlm.nih.gov/35231009/) | *Menopause* (L Gould et al. 2022) | [1:27:45]

**Episode of** ***The Drive*** **with Andy Galpin**: [#239 ‒ The science of strength, muscle, and training for longevity | Andy Galpin, Ph.D. (PART I)](https://peterattiamd.com/andygalpin/) (January 23, 2023) [1:42:15]

**LIFTMOR studies, Belinda Beck**: [1:52:15]

- [High-Intensity Resistance and Impact Training Improves Bone Mineral Density and Physical Function in Postmenopausal Women With Osteopenia and Osteoporosis: The LIFTMOR Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/28975661/) | *Journal of Bone and Mineral Research* (S Watson et al. 2018)
- [Effects of supervised high-intensity resistance and impact training or machine-based isometric training on regional bone geometry and strength in middle-aged and older men with low bone mass: The LIFTMOR-M semi-randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/32289518/) | *Bone* (A Harding et al. 2020)

**Recent episodes of** ***The Drive*** **that discuss creatine supplementation**: [1:58:30]

- [#369 ‒ Rethinking protein needs for performance, muscle preservation, and longevity, and the mental and physical benefits of creatine supplementation and sauna use | Rhonda Patrick, Ph.D.](https://peterattiamd.com/rhondapatrick3/) (October 20, 2025)
- [#340 – AMA #69: Scrutinizing supplements: creatine, fish oil, vitamin D, and more—a framework for understanding effectiveness, quality, and individual need](https://peterattiamd.com/ama69/) (March 17, 2025)
- [#235 ‒ Training principles for mass and strength, changing views on nutrition, creatine supplementation, and more | Layne Norton, Ph.D.](https://peterattiamd.com/laynenorton3/) (December 19, 2022)

**Episode of** ***The Drive*** **with Rachel Rubin**: [#348 ‒ Women’s sexual health, menopause, and hormone replacement therapy (HRT) | Rachel Rubin, M.D.](https://peterattiamd.com/rachelrubin/) (May 12, 2025) | [2:00:30]

**Abbie recommends a healthy diet and HIIT**:

- [Sex differences and considerations for female specific nutritional strategies: a narrative review](https://pmc.ncbi.nlm.nih.gov/articles/PMC8015182/) | *Journal of the International Society of Sports Nutrition* (K Wohlgemuth et al. 2021)
- [Active Women Across the Lifespan: Nutritional Ingredients to Support Health and Wellness](https://pmc.ncbi.nlm.nih.gov/articles/PMC9521557/) | *Sports Medicine* (A Smith-Ryan, H Cabre, S Moore 2022)
- [Promoting Exercise and Healthy Diet Among Primary Care Patients: Feasibility, Preliminary Outcomes, and Lessons Learned From a Pilot Trial With High Intensity Interval Exercise](https://pmc.ncbi.nlm.nih.gov/articles/PMC8322607/) | *Frontiers in Sports and Active Living* (A Smith-Ryan et al. 2021)

---

## People Mentioned

- [laire Badenhorst](https://www.massey.ac.nz/massey/expertise/profile.cfm?stref=573450) (Associate Professor of Sport, Exercise and Nutrition at Massey University of New Zealand, expert in iron status in menstruating females and relative energy deficiency in sport) [20:30]
- [William (Bill) Kraemer](https://ehe.osu.edu/human-sciences/directory?id=kraemer.44) (Retired full professor of Human Science at the Ohio State University, he remains there as a research scientist and senior advisor in sports performance and sports science; expertise in translating sports science into different fields of practice) [1:22:15]
- [Severine Lamon](https://experts.deakin.edu.au/2052-severine-lamon/about) (Professor of Exercise and Nutrition Sciences at Deakin University, Melbourne, Australia; expert in sex-specific muscle physiology) [1:24:45]
- [Asker Jeukendrup](https://www.mysportscience.com/asker-as-a-researcher) (Former Professor in Exercise Metabolism at the University of Birmingham in the UK where he was also the Director of the Human Performance Laboratory, expert in measuring metabolism using isotopic tracers and mass spec, his work focused on the interaction between nutrition and exercise) [1:29:45]

---

![](https://peterattiamd.com/wp-content/uploads/2026/01/bio-abbiesmithryan-600x600.png)

##### Abbie-Smith Ryan, Ph.D.

Abbie-Smith Ryan earned her undergraduate degree from Truman State University. She earned her M.S. and Ph.D. in exercise physiology from the University of Oklahoma. Dr. Smith-Ryan is a [Professor of Exercise and Sport Science](https://exss.unc.edu/faculty-staff/abbie-smith/) at the University of North Carolina at Chapel Hill, where she also serves as the Associate Chair for Research, Director of the [Applied Physiology Laboratory](https://exss.unc.edu/applied-physiology-laboratory/), Co-Director of the Human Performance Center and Adjunct Associate Professor of both Nutrition and Public Health.

Dr. Smith-Ryan’s research interests center around exercise and nutrition interventions to modify various aspects of body composition, cardiovascular health, and metabolic function. Her work has a special focus on women’s health, perimenopause, post-menopause, and overweight populations. She is an active researcher in the field of metabolism, sport nutrition and exercise performance, in both healthy and clinical populations, leading projects funded by the National Institutes of Health and International and National industry sponsored clinical trials. Dr. Smith-Ryan contributes to the current body of scientific literature with over 190 peer-reviewed manuscripts; a number of scholastic books and book chapters, and international/national presentations.

Dr. Smith-Ryan is an active member of the National Strength and Conditioning Association, American College of Sports Medicine, and the International Society of Sports Nutrition. She was recognized by the NSCA as the Nutrition Researcher of the Year (2013) and the Young Investigator of the Year (2015), and the William J. Kramer Outstanding Sports Scientist of the Year (2022). [[UNC](https://exss.unc.edu/faculty-staff/abbie-smith/)]

Instagram: [@asmithryan](https://www.instagram.com/asmithryan/?hl=en)

Website: [Dr. Abbie Smith-Ryan](https://asmithryan.com/)