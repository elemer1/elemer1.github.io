# #76 – Kyle Kingsbury: Finding meaning, depression, and psychedelics

**Source:** [https://peterattiamd.com/kylekingsbury/](https://peterattiamd.com/kylekingsbury/)

---

In this episode, Kyle Kingsbury, retired UFC fighter and director of human optimization at Onnit, discusses the purpose and meaning that football and MMA gave him but which also acted as a distraction from his inner demons. Kyle opens up about his use of PEDs (steroids, testosterone, HGH) in college and talks about some of the misconceptions around them. Next, Kyle talks about his battle with depression and a close call with suicide that lead to life-changing experiences with psilocybin and ayahuasca—which really became the turning point in his own journey towards being more emotionally healthy, finding inner peace, and being a better husband and father.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

*\*DISCLAIMER: The substances spoken about in this episode are illegal and by no means are we advocating for anyone to use them or experiment with them. There are physical, physiological, psychological, and legal risks around the use of these plants. This conversation is purely informational only.*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

§

![The Peter Attia Drive](images/kylekingsbury/the_Drive_public.png)

Play

#76 - Kyle Kingsbury: Finding meaning, depression, and psychedelics

#76 - Kyle Kingsbury: Finding meaning, depression, and psychedelics

1x15s30s

0:001:41:31

We discuss:

- Growing up in a volatile home [6:30];
- Playing college football at ASU, and letting go of NFL aspirations [15:45];
- Kyle’s experience taking anabolics (steroids/testosterone), misunderstood science, and fear mongering [23:15];
- Kyle’s experience with taking HGH [35:30];
- The Whizzinator [36:45];
- Struggles with depression and drugs, and a lack of meaning after football [41:00];
- Kyle’s close call with suicide, and a spiritual experience [47:15];
- Finding refuge with mixed martial arts, and Kyle’s early success in cage fighting [52:30];
- Lessons from Kyle’s first loss in fighting, and training for the UFC [59:45];
- First experiences with psilocybin and ayahuasca, quieting the monkey mind, and finding inner peace [1:07:15];
- Overt vs. covert depression, depression in men vs. women, and the transition from adaptive to maladaptive behaviors [1:16:00];
- Peeling back the layers with ayahuasca: Kyle tells stories about the most transformative experiences with psychedelics [1:19:00];
- Does Kyle feel like he has lost his “edge” as a result of his journey? [1:26:15];
- Where would Kyle be had he not discovered the power of psychedelic medicines? [1:29:45];
- Parenting: Stopping the cycle of trauma, reconnecting to our ancestral roots, and Kyle’s opinion on ayahuasca as a potential tool for kids [1:31:40];
- Relationship with parents, blind spots, compassion, and forgiveness [1:37:15]; and
- More.

§

## Show Notes

## Growing up in a volatile home [6:30]

- Grew up outside of San Jose, CA in Cupertino and Sunnyvale
- Fell in love with football at age 10
- Played football and wrestled in high school
- Kyle says he was a terrible student in high school
- He never took it seriously
- He like the attention of being a class clown
- He would get into fights a lot in school
- It wasn’t until college that he found any curriculum to be interesting or useful
- His dad was a blue collar worker
- This is probably what Kyle would have been if he hadn’t been athletic enough to play sports in college
- At the same time, his dad really encouraged him to be “better” and go to college

**A volatile home**

- Kyle’s parents did not have a good relationship
- A ton of arguing
- One of Kyle’s favorite books is [Nonviolent Communication](https://www.amazon.com/Nonviolent-Communication-Language-Marshall-Rosenberg/dp/1892005034) by Marshall Rosenberg
  - “*Whatever [nonviolent communication] is, my childhood was not.*”
- Parents divorced when Kyle was 16
- His younger siblings did NOT want parents to divorce but Kyle knew it was for the best
- He said his dad became a gentler, kinder dad after that

Ultimately,

- his parents were psyched when he got into [Arizona State](https://www.asu.edu/)
  - (check out this [dig at ASU by The Simpsons](https://vine.co/v/MzbMgqdTthh))

## Playing college football at ASU, and letting go of NFL aspirations [15:45]

Before getting to ASU…

- Kyle went to 2 different junior colleges (because he grades were so bad in HS)
- He eventually transferred to Arizona State (ASU)

Football at ASU

- He walked on to the football team at ASU
- He played defensive line (both tackle and end)
- Kyle said he didn’t have the physical size or gifted athleticism as many other guys
- But credits his strength coaches ([Joe Kenn](https://bighousepower.com/biography/) and [Mark Uyeyama](https://www.vikings.com/team/coaches-roster/mark-uyeyama)) for pushing him far past his perceive limits

Partying at ASU

- ASU is known as a party school
- And it lives up to its name says Kyle
- In fact, Kyle participated in it much throughout his time there
- He said he would party really hard, but not in an angry way… it was more of “celebration”
- It wasn’t until later in life did he realize the destruction he was doing to himself

NFL aspirations

- Kyle said that he did have aspirations for the NFL
- But also said it was clear how much effort (and luck) it would take
- “*Everyone who makes it to college was an all-star in high school. The jump is even higher to the NFL*.”

*Who are the guys who actually make it to the NFL?*

- 1) Kyle says it was the guys who **kept improving**
  - “*…they just kept getting better. That was the difference. They were late bloomers, whatever you want to call it, but they kept improving, kept getting faster, kept learning the routes better*…”
- 2) **Injury avoidance**
  - This is an underappreciated piece of the puzzle
  - Kyle says that his strength coach, Joe Kenn (who is now an NFL strength coach), says that “injury avoidance” is the main thing they are concerned with at that level

## Kyle’s experience taking anabolics (steroids/testosterone), misunderstood science, and fear mongering [23:15]

**High school**

- Senior year in HS, Kyle started taking testosterone (specifically [Sustanon 250](https://en.wikipedia.org/wiki/Testosterone_propionate/testosterone_phenylpropionate/testosterone_isocaproate/testosterone_decanoate))
- He wanted to play college football and wanted to put on more size
- He went from 220 lbs to 230 lbs
- He was disappointed in only gaining 10 lbs
- At that point he started to focus on sleeping more and eating more

**Junior college**

- Kyle took testosterone during his 2 years in junior college
- He got up to be about 250 lbs (still relatively small for his position)

**ASU**

- Started doing growth hormone and IGF-1
- Started taking [Deca-Durabolin](https://en.wikipedia.org/wiki/Nandrolone) with testosterone (great for inflammation and just feeling better)
- He got up to 268 lbs senior year at ASU

*Doses*

- 600 milligrams of testosterone cypionate per week
- 400 milligrams of Deca-Durabolin per week

**Dose and schedule for Peter’s patients on testosterone**

- A normal starting dose is 80-100 milligrams per week
- Split between at least 2 doses b/c test-cypionate half life is 3 days

⇒ *Daily* is best though

- Daily is best (10-14 mg per day) if the patient doesn’t mind doing daily injections
- You see *no FSH, LH suppression* with a daily dosing schedule

**Did Kyle see side effects?**

- Maybe some acne
- But mentally, he said it was a positive
- He actually felt emotional well-being
- No sense of “roid rage”

Peter and Kyle both highly recommend the books by [Dr. William Llewellyn](https://www.amazon.com/William-Llewellyn/e/B001K8TZ8O/ref=dp_byline_cont_book_1)

- [Anabolics 2000](https://www.amazon.com/Anabolics-2000-Anabolic-Steroid-Reference/dp/0967930405) (Kyle’s first deep dive was when he read this in college)
- [ANABOLICS 11th Edition](https://www.amazon.com/gp/product/0999062115/ref=dbs_a_def_rwt_hsch_vapi_taft_p1_i0) (most recent edition)
  - Peter: “*one of my favorite books on the entire study of anabolics*”
  - Peter describes his books as “unemotional” and just takes a deep dive into what the molecules are doing

*Did that high dose of testosterone change your mood?*

- Kyle says no
- In fact, he felt better emotionally

*What is happening in cases where people do feel “roid rage”?*

- Kyle speculates that if you are already an angry person it could amplify that trait
- Peter agrees, “steroids are a lot like money. People talk about, “That guy’s a rich asshole,” and it’s like, I don’t think those are necessarily the same thing. He’s an asshole who then got a lot of money, and that just allowed him to amplify his assholedness.”
- If someone is already aggressive and angry, you might **amplify** that phenotype, you **do not** ***create*** that phenotype

> “When you squeeze an orange, you’ll always get orange juice to come out. What comes out is what’s inside. The same logic applies to you: when someone squeezes you, puts pressure on you. . .and out of you comes anger, hatred, bitterness, tension, depression, or anxiety, that is what’s inside.” —[Wayne Dyer](https://www.goodreads.com/quotes/849398-when-you-squeeze-an-orange-you-ll-always-get-orange-juice)

\*To be clear…

- Peter is not advocating, nor suggesting, that the doses Kyle was taking is safe
- In fact, “it’s probably not a good idea”

**Misunderstood science and fear mongering**

Lack of long-term data

- We don’t yet have the **long term** data on super physiologic data
- Peter says there are **short-term** data (studies of 8, 12, 16 weeks)
  - Put athletes on those kinds of doses 10 times the normal amount of testosterone
  - These studies do NOT find bad outcomes
- But the problem is we don’t have data longer than that so it’s hard to extrapolate

**Documentary recommendation**: [Bigger, Stronger, Faster\*](https://en.wikipedia.org/wiki/Bigger,_Stronger,_Faster*)

- Watch the full movie [here](https://tubitv.com/movies/453660/bigger_stronger_faster)

In the documentary,

- There’s a father who’s adamant that steroids killed his son, [Taylor Hooton](https://www.justthinktwice.gov/true-stories/taylor-hooton-17)
- Taylor was a high school baseball player
- After starting steriods, he fell into depression and committed suicide

⇒ But the question is…

—*Did the steroid use cause this to happen?*

—*Or is it more that people who take steroids are more likely to be someone who already has issues and may be trying to fill a void of some sort?*

- In Peter’s words: “*it’s probably that that at least increases their susceptibility to depression, and not that the testosterone is causing the depression.*”

**We need better studies**

- We need studies that are not having to rely on a person self-selecting into anabolic use
- And instead you can use the process of randomization

⇒ Check out [Peter’s interview of Chris and Mark Bell](https://peterattiamd.com/brothersbell/) for more on the topic of anabolics

## Kyle’s experience with taking HGH [35:30]

- Kyle took about 4 IUs of human growth hormone per day
- Minimal side effects (tingly fingers, some carpal tunnel)
- Kyle said it really helped in his recovery
- He once sprained his ankle really badly and felt fine the very next day, “*I was astonished*”

## The Whizzinator [36:45]

*Did Kyle get drug tested in college?*

- Yes he did
- But, fortunately, he has something called the [Whizzonator](https://en.wikipedia.org/wiki/Whizzinator)

The Whizzonator

- This was a tool to help people pass a drug test
- There was a fake penis that came in 7 different colors
- And it came with synthetic urine
- So, you would be able to “show” the tester your penis, and then “pee” out the fake urine
- [Onterrio Smith famously got caught with one](https://www.espn.com/nfl/news/story?id=2061794)

Not gonna work with more sophisticated testing

- The problem with the fake urine is that it will show zero testosterone
- So now the drug testers will know something is fishy
- Nowadays, when USADA or WADA tests you it is much more strict

*Is HGH detectable in tests?*

- Not always
- And some athletes are fighting tests that show positive HGH saying the testing for it is not accurate

## Struggles with depression and drugs, and a lack of meaning after football [41:00]

**Struggles after college**

After football season his senior year at ASU

- Kyle stopped going to school, never graduated
- Starting to really battle some personal demons
- Was taking xanax, valium, and vicodin daily (anti-anxiety meds in general)
- He also used alcohol, cocaine, and ecstasy, then he would pop anti-anxiety pills when he was coming down
  - It’s like a “*roller coaster*”

Football had been forcing him to “straighten up”

- But now he didn’t have that and was spiraling
- During football, he was “mindful of the debauchery”
- But after, it was “mindless debauchery”

**Depression and early thoughts of suicide as a child**

- At age 7, Kyle remembers having vivid thoughts about suicide
- *What was the root of those thoughts*?
  - Seeing his family fight so often
  - He remembers watching his little sister “close inside and wall off”
  - Kyle said his dad was really hard on him
  - He felt like he was trapped and like it would never end
- His parents finally divorced when he was 13 and it did get better

> “At the root of a lot of depression is this concept that it will never get better. There’s no light at the end of the tunnel. There’s no way out of this. That’s how I felt, most of my childhood.”

*What was behind his depression now after football?*

1. His life was lacking meaning
2. And from a neurochemistry standpoint, he was on a rollercoaster with uppers and downers
3. He wasn’t sleeping much

Recently,

- Kyle heard [Matthew Walker on The Drive](https://peterattiamd.com/matthewwalker1/) and read the book [Why We Sleep](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316)
- And it’s very clear to him how damaging that was… “*No shit, I was messed up in the head.*”

> “I watched the sun come up many, many nights, and the beautiful double-edged sword of an anti-anxiety pill is that you feel fucking great while you’re on it, and the second you stop taking it, all that un-worked-through stuff is still there. It’s just waiting to come up, once that chemical’s out of your body.”

## Kyle’s close call with suicide, and a spiritual experience [47:15]

**Close call with suicide and a spiritual experience**

- After a big fight with his girlfriend
- Kyle had a dark thought of, “I will never be loved”
- He took a bunch of pills
- Drove to the top of a parking garage
- Stripped naked
- And stood up on the edge of the roof
- As he was standing on the edge of the building, he has a “spiritual experience”
- He felt a warm sense rush over his body
- Then he heard a voice in his head say, “*Not yet. It’s okay.*”
- Then right after that a security guard sees him and says, “*Hey! What are you doing up there?*”
- The guard gets him off the ledge
- Next thing Kyle remembers is waking up in a hospital bed with all his family around him

**Next, he spent a week in a detox center**

- They wanted to wean him off SSRI (anti-anxiety/anti-depression) medicine by putting on Klonopin
- But first dose made Kyle feel high and he didn’t want that
- He refused them after that
- He wanted to go cold turkey
- They also tried Lithium but he didn’t like the way that felt either
- After that, his psychiatrist suggested fish oil
- Kyle saw this as a much better, holistic approach

**The most important change of all**

- Created some distance from the party atmosphere
- With that he began to see a shift
- And then he started setting goals for himself

## Finding refuge with mixed martial arts, and Kyle’s early success in cage fighting [52:30]

Kyle had the realization of what he was missing about football

- He was missing the camaraderie
- He was missing the physical interaction with others
- He was missing the purpose of having to train for something
- This realization got into mixed martial arts

MMA

- MMA gave him a goal
- Something to learn
- A place to make new friends
- He has no plans to actually fight professionally

His first fights

- A gym owner of [Rage in the Cage](https://twitter.com/rageinthecageaz?lang=en) convinced Kyle to just TRY one fight
- If he didn’t like it he could never do it again
- Instead, he won his first 2 fights in less than 30 seconds
- At that point, he was hooked

**UFC vs MMA, and the basic rules of cage fighting**

Analogy: mixed martial arts is to the UFC as tissues are to Kleenex

- UFC is just the highest level of sport that is mixed martial arts
- mixed martial arts is the practice of bringing all things together
- There are MMA leagues all over the world

The rules used to vary amongst leagues (i.e., Pride used to allow stomping a guy’s face)

- However, the rules are now more similar
- Basic rules:
  - 4 or 5 ounce gloves
  - No striking to the back of the head
  - No kicks to the nuts
  - Can’t pull hair

Genesis of MMA?

- Some say it was [Bruce Lee](https://en.wikipedia.org/wiki/Bruce_Lee) ([Jeet Kune Do](https://en.wikipedia.org/wiki/Jeet_Kune_Do))
- Another example is [Kajukenbo](https://en.wikipedia.org/wiki/Kajukenbo) from Hawaii
- Initially, it was a blood sport that brought together all styles to fight amongst each other
  - E.g., A boxer against a sumo wrestler
- Today, however, you have to be good at everything
  - If you have any weakness, it will be exploited
- Also, in parallel, you have [Brazilian jiu-jitsu](https://en.wikipedia.org/wiki/Brazilian_jiu-jitsu) and the [Gracie family](https://en.wikipedia.org/wiki/Gracie_family)

When did the UFC start?

- In 1993
- [Bob Meyrowitz](https://en.wikipedia.org/wiki/Bob_Meyrowitz) and [Rorion Gracie](https://en.wikipedia.org/wiki/Rorion_Gracie) (among others) started the UFC

*Did Kyle have any MMA training prior to his first fights?*

- He wrestled in high school
- Also, when he was 17 he trained in kickboxing at [American Kickboxing Academy](https://en.wikipedia.org/wiki/American_Kickboxing_Academy) under [Frank Shamrock](https://en.wikipedia.org/wiki/Frank_Shamrock)
- He did this for 3 months

## Lessons from Kyle’s first loss in fighting, and training for the UFC [59:45]

**Fighting for King of the Cage**

- Kyle was now 6-0 in his fights
- He was fighting for [King of the Cage](https://en.wikipedia.org/wiki/King_of_the_Cage)
- Earning $1,000 a fight
- King of the Cage was a bridge to the UFC
- (but still a HUGE gap in talent-like college football to the NFL)
- He fought about 4 times per year

Kyle’s first loss

- Kyle came into a fight over-confident
- Got his ass kicked
- TKO’d in the first round
- Compared it to [Buster Douglas beating Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson_vs._Buster_Douglas)

> “Thought I was the shit, thought I was going to just walk through people until I got to the UFC, then I’d really have to start training.”

Training at AKA

- After that surprising loss…
- At the advice of his coach, he moved to train at AKA with UFC aspirations
- [Cain Velasquez](https://en.wikipedia.org/wiki/Cain_Velasquez) (former ASU wrestler, and now the UFC heavyweight champion) was training there
- There, he spent time “largely getting his ass beat every day until I could finally hang”

*How do you spar in MMA?*

- At the time,
- we weren’t using elbows
- We wouldn’t knee to the head
- But it was “full go”
- Fight three days a week
- The sport evolve and that’s not really the case anymore
- Too many injuries happen in training that way
- Now, using [Muay Thai](https://en.wikipedia.org/wiki/Muay_Thai) as an example, it’s more about the technical training versus physically beating each other up in sparring

The most painful injuries

- Shin-to-shin was the most painful thing about fighting, says Kyle
- He would hardly feel hard rib shots, but shin to shin was the worst

You can’t have a weakness

- Today’s fighters must be extremely well rounded
- So you are constantly focusing on refining certain areas where you are weak
- Some days exclusively training on one thing (e.g., guarding against low leg sweeps)

The best fighters were experts in one area from lifelong training

- The ideal situation is you are someone who has spent a lifetime training in one area
- (e.g., wrestling or traditional MMA)
- Then you could focus all your time rounding out the other things
- Acquiring new skills and polishing them
- But you could still fallback on your lifelong specialty

## First experiences with psilocybin and ayahuasca, quieting the monkey mind, and finding inner peace [1:07:15]

Peter asks if fighting was just another addiction/distraction from some of the inner demons and trauma that Kyle hadn’t really addressed…

- “Yeah, for sure.”
- If he was feeling weird or down, he would lean on his training and his fighting to get out some of that anger and depression
- It wasn’t until he tried to address the inner demon down deep that his life changed

**Game changers**

“*There was a couple catalysts, big catalysts, that changed my life forever.*”

Quieting his monkey mind

- When fighting in the UFC, Kyle needed a way to quiet the negative monkey mind
- Knowing you have to get a cage with someone who is just as good a fighter, or better, than you creates a lot of anxiety

He began doing 2 things to address this:

- 1) **Breathwork**
  - He started using breathwork to trying to get himself to quiet his mind and finding some level of stillness
  - He used various forms of slow breathing to try to get down into [parasympathetic](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system)
    - So at least two-to-one exhale to inhale
    - Four seconds in, eight seconds out, or
    - 10-10-10 (10 in, 10 hold, 10 out)
- 2) **Traditional** [**sweat lodges**](https://en.wikipedia.org/wiki/Sweat_lodge)
  - before every fight camp started to kind of zero-in on what we wanted
  - and after every fight for healing and reflection

**Intro to psilocybin**

- Kyle began using psilocybin as a means for going deeper into the mind
- To try to further quiet it and find stillness
- That’s where I started to begin to uncover some things, say Kyle
- He began to really get direction and a **true sense of peace inside that was lasting**
- Kyle was using psilocybin while he was still fighting in the UFC
- He still uses psilocybin to this day

**Intro to ayahuasca**

> “[Ayahuasca] shifted more things in me and how I perceived the world than anything else.”

- Kyle heard about ayahuasca from a friend who went to Peru
- He subsequently did his research using [**erowid.org**](https://www.erowid.org/)
- He saw that it was referred to as “*The apex of teacher plants*” which intrigued him
- After a particularly brutal loss that resulted in a fractured orbital bone and torn labrum
- Kyle was now 4-4 in the UFC
- Was at a bit of a crossroads
- This was when he began experimenting with ayahuasca

The deep work

- All of the important things in my life were coming up, “the deep work”
- Everything from childhood stuff
- To how he treated myself with drugs and alcohol

⇒ In Columbia, getting ready for his first ayahuasca experience

- He was told, this is going to feel like 1,000 ants are biting you
- And when he feels that, he needs to think of a negative emotion he wants to remove
- Kyle chose anger
- Additionally, before the ceremony, the discussion was about alcohol and cannabis addiction
- Kyle thought, “I’m good” and “that’s not for me”
- However, a great chunk of the night was him reliving a bunch of the shameful experiences he had had with alcohol and drugs
- He also saw the destructive pattern he had been repeating which was…
  - During fight camp, he was extremely focused on doing all the right things from nutrition to training to sleep to breathwork, etc.
  - The moment the fight was over, it was “Whoppers and alcohol and blow”
- After this first ceremony, he came to the realization: “*Wow. Okay. Time to scale back, outside of camp, and really treat myself better.*”

## Overt vs. covert depression, depression in men vs. women, and the transition from adaptive to maladaptive behaviors [1:16:00]

Peter calls the book, [I Don’t Want to Talk About It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398) by Terry Real, “*One of the most important books I’ve ever read in my life*”

*The difference between covert and overt depression*:

**-Overt depression** = what most people think about when they think of depression. It’s the person who can’t get out of bed, who’s weepy, who’s unmotivated, overeating, undereating, your classic picture of depression. The visual is a person who’s sitting there morose in their psychiatrist’s office

**-Covert depression** = the same underlying pain, but it manifests itself, typically, with addiction, anger, aggression, workaholism, all sorts of other things that are numbing this discomfort.

***Depression in men compared to women*** *(stats are from the book, I Don’t Want to Talk About It by Terry Real)*:

- Mind blowing stats —
  - 93% of incarcerated people in the United States are men
  - Men are about 3x more likely to be alcoholics (about 20% of men have alcohol addiction)
  - Men are also more drug addicted and violent
- However, despite all that…
- Women are more likely to have a ***clinical diagnosis of depression***

But when looking at absolute numbers…

- What’s the absolute number of women that are receiving therapy for depression, plus women that have issues with alcohol, drugs, violence, etc.
- When you do the same exercise for men, it turns out it’s the **same number**

*What’s the difference?*

- The difference is the form in which it exists
- In other words, men’s issues manifest more commonly in drugs and violence whereas **women’s issues manifest more commonly in overt depression symptoms**

> “…so what’s underpinning that [alcoholism, drug use, violence, anger] is the same pain that, in a woman, might lead to depression…”

Kyle’s pattern of behavior resembles covert depression in men:

- The arc of vehicles to numb pain
- If it’s not this drug, it’s the pursuit of this sport, and if it’s not that, it’s this fight, etc.
- Men are particularly drawn to using their body as a shield ⇒ “*The bigger and stronger and tougher you are, the more that seven-year-old is not going to hurt.*”

**The transition from adaptive to maladaptive**

- As children, we “adapt” to the environment as a survival mechanism
- But as adults, we still carry that adaptation which then become a [maladaptive behavior](https://en.wikipedia.org/wiki/Maladaptation)
- \*The **transition from adaptive to maladaptive** is when it starts to come *crashing down*

## Peeling back the layers with ayahuasca: Kyle tells stories about the most transformative experiences with psychedelics [1:19:00]

**Psychedelics as a tool** ⇒ The ayahuasca (along with the psilocybin) became one of the first sets of tools to actually help Kyle see through the bullshit and realize that he was on a hedonic loop of one fix (football, drugs, fighting, alcohol) after another

*Peeling back the layers*

- Kyle says each ayahuasca ceremony is different:
  - “*If I give enough space between ceremonies and I come back and have a reason to be there that’s important to me, I’m going to get a lot that has to do with that…*
  - *…And that peeling back at the layers really shows such a deep reflection of what’s going on inside right now…*
  - *and it also has shown me* ***the way that I behave is due to how I was programmed.***”

- Kyle also mentions guys like [Dennis McKenna](https://en.wikipedia.org/wiki/Dennis_McKenna) and [Gabor Maté](https://en.wikipedia.org/wiki/Gabor_Mat%C3%A9_(physician)) have done hundreds of ayahuasca ceremonies and says that each experience is unique

⇒ Kyle did his most recent ayahuasca ceremonies through [Soltara](https://soltara.co/)

*Any unpleasant experiences?*

Physically unbearable:

- One night he violently puked and shit himself all night long
- “It was incredibly hard, but it was, in many ways, cleaning me out.”

Emotionally unbearable night ending with a breakthrough realization about his son:

- One night he came in with the intention to open the door to any and all emotional and mental healing going back to childhood
- “It was fucking everything. It was the entire night.”
- “I remember just begging for mercy. Like, ‘Please. I’ve seen enough.’
- To paint a picture: “Sometimes, if I was to have a vision, it’s like watching from the third person or watching a movie, and I can see from a different lens. **This was like reliving it for the first time**.”
- “All the fear of my father, my mom screaming in my face and spit flying into my mouth. . .it just kept going and going and going, and I realized, ‘Holy shit. All that’s still there.’”
- Eventually, Kyle says he just “surrendered to it” which is one of the cornerstones of working with ayahuasca
- He was then able to have a degree of gratitude for his parents, knowing they were doing the best they could with what they could at that time and seeing how hard it was for them when they were growing up
- The next thought he had was about his own son
- He realized that he had the opportunity to break the transference of trauma and “cycle of pain” that he felt, his dad felt, his granddad felt, and so on.
- “*Oh, okay. This breaks here.*”
- The second I thought that, it all washed away and I felt euphoria, and I felt gratitude, and it was for sure the **hardest night of my life and one of the most beautiful**, in the end, by far.

⇒ To dive deeper into the power of psychedelics, check out [Peter’s interview of Rick Doblin](https://peterattiamd.com/rickdoblin/)

## Does Kyle feel like he has lost his “edge” as a result of his journey? [1:26:15]

Does Kyle feel like his “edge” is gone as a result of his journey?

- Yes, but not necessarily in a bad way
- Before, he had a chip on his shoulder that drove him to constructive, and destructive, behaviors
- He recalls resonating with the [scene in Fight Club](https://www.youtube.com/watch?v=Gi54QFCv6_o) where Edward Norton’s character beat a young, handsome kid to oblivion and when someone asked, “*What the fuck is wrong with you?*”… his response was “*I just wanted to destroy something beautiful.*”
- He says that chip on his shoulder is now gone
- His attitude has shifted from “I wanted to beat the shit out of people” to “**I just want to be the best version of myself**”

## Where would Kyle be had he not discovered the power of psychedelic medicines? [1:29:45]

If Kyle had not been so lucky to meet just the right coaches, to get introduced to these medicines and plants, what might his life be different right now?

- Kyle says he would probably still be fighting
- Trying to relieve the same pain from his life
- Probably still getting injured and losing brain cells
- \*More importantly, he would have never met his wife, Natasha and had his son

Ayahuasca has improved his relationship with his wife

- They were together for about a year before they did ayahuasca for the first time
- It changed the course of their relationship, Kyle says, in the following ways:
  - It unpacked so much of the arguing that we had.
  - Allowed me to see things in myself that she could, but I could not (and vice versa)
  - As we grew as individuals, we grew together in our relationship.

> “*There’s no way that would have worked out had I just continued to fight and treat myself the way that I was.*”

## Parenting: Stopping the cycle of trauma, reconnecting to our ancestral roots, and Kyle’s opinion on ayahuasca as a potential tool for kids [1:31:40]

> “I think it’s critical that we at least try to find some rite of passage, especially for our young men, to bring them into adulthood.”

*How has Kyle’s journey changed the way he thinks about raising his son?*

- Firstly, it allowed him to realize the importance of stopping the cycle of trauma and pain
- And now, beyond that, it allows him to ask the question, “*What can I give him in this world?*”
- Kyle says that looking at the way our ancestors lived fascinates him
- The modern world is so different, it’s like a “huge test being done for the first time”

⇒ This begs the question: *What are the ways that we can reconnect to our roots and still live in the modern world?*

- Kyle looks at what [Tim Corcoran](https://www.facebook.com/timcorcoran74?__tn__=%2CdH-R-R&eid=ARAGExamdXKRBakdGGkTxcnwwj0PH4HpKUesEfA8cRNylurKepN1BEm2qMxJ_8sVu1sChZbU0PDBrWCe&hc_ref=ART_G1zBcsOTfX5j-kydQZUIVBVvYMz0i8tmnC9PNLwZt5mvcCVVWTU4KnEnG802_MQ&fref=nf) is doing with his [wilderness survival camps](https://www.twineagles.org/)
- When the kids are old enough, he takes them out there and they’re solo (or they’re in a small group) and they learn to just survive (build fires, forage for food, etc.)

Ayahuasca for children

- Kyle believes an ayahuasca experience has the potential to be “really transformative and powerful” for his son
- This might sound crazy to some, but Kyle believes with the right teachers he would benefit greatly
- There are “black belts teaching ayahuasca and white belts teaching, and there’s everything in between”
- A place that has been vetted is critical when it comes to these things because you’re basically performing psychic surgery
  - Done incorrectly can leave some really lasting damage
  - But correctly, “*it can be everything that I see in it*”
- Kids today are so narrowly focused on things like how they are perceived by their peers, popularity, and it is only **heightened by social media**
- A medicine like ayahuasca can be a tool for them to be able to unplug to see the big picture and understand what really matters in life

\*Book rec from Peter about psychedelics: Michael Pollan’s [How to Change Your Mind](https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225)

## Relationship with parents, blind spots, compassion, and forgiveness [1:37:15]

Kyle is open about his parent’s role in some of his past traumas

Peter asks how his relationship might have evolved after his journey

- I have a great deal of compassion for them
- Everyone walks their own path
- It’s not up for me to decide how or when they should learn their lessons
- And just as it was the case with me and my wife, I can’t always see what’s going on, where I’m fucking up.
- **Everyone has a blind spot**.
- I can see all the faults that my parents have that they don’t see, but it’s not up to me to decide that
- “*They will learn their own lessons at their own pace, and they may go to the grave without having learned some lessons. That’s okay. I’m for sure going to do the same thing.*”

*Kyle’s thoughts on the power of* ***forgiveness***

- Forgiveness has very little to do with the person I’m forgiving
- It has everything to do with taking that fucking weighted vest off of me, because I’m held down by that.
- Whatever anger or pain or resentment that I feel towards another person . . .they might not even fucking know. . .but I’m keeping that in me, and it’s affecting the way that I go through the world.

> “If I can release that [anger/pain/resentment], what greater gift can I give to myself, let alone the other person I’m forgiving?”

§

## Selected Links / Related Material

**Kyle’s two appearances on The Joe Rogan Experience**: [4:00]

- [Joe Rogan Experience #756 – Kyle Kingsbury](https://www.youtube.com/watch?v=Omg6sITstr0) | PowerfulJRE (youtube.com)
- [Joe Rogan Experience #1132 – Kyle Kingsbury](https://www.youtube.com/watch?v=lA18kveydd4) | PowerfulJRE (youtube.com)

**Kyle is the Director of Human Optimization at**: [Onnit](https://www.onnit.com/) | (onnit.com) [4:00]

**Peter and Kyle just went on a hunting trip together in Hawaii**: [@peterattiamd on 3/25/19](https://www.instagram.com/p/BvcVlrLA3go/) | (instgram.com) [4:00]

**Peter’s appearance on Kyle’s podcast**: [#106 Dr. Peter Attia](https://www.youtube.com/watch?time_continue=37&v=E3tUxk85kpw) | Kyle Kingsbury Podcast (youtube.com) [9:00]

**Book that Kyle recommends about healthy communication**: [Nonviolent Communication: A Language of Life](https://www.amazon.com/Nonviolent-Communication-Language-Marshall-Rosenberg/dp/1892005034) by Marshall Rosenberg | (amazon.com) [14:15]

**Simpsons episode that made a joke about how easy it is to get into ASU**: [Marxz , Jan 31, 2014](https://vine.co/v/MzbMgqdTthh) | (vine.co) [15:30]

**Book recommendations from Kyle and Peter on anabolics by Dr. William Llewellyn**: [29:00]

- *Book that Kyle read in college*: [Anabolics 2000](https://www.amazon.com/Anabolics-2000-Anabolic-Steroid-Reference/dp/0967930405) by Dr. William Llewellyn | (amazon.com)
- *Most recent edition that Peter recommended*: [ANABOLICS 11th Edition](https://www.amazon.com/gp/product/0999062115/ref=dbs_a_def_rwt_hsch_vapi_taft_p1_i0) by Dr. William Llewellyn | (amazon.com)

**Documentary by Chris Bell that contained the story of a father who believe steriods caused his son to fall into depression leading to his suicide**: [Bigger, Stronger, Faster\*](https://en.wikipedia.org/wiki/Bigger,_Stronger,_Faster*) | (wikipedia.org) [33:45]

- *Watch the full movie here*: [Bigger, Stronger, Faster](https://tubitv.com/movies/453660/bigger_stronger_faster) | ([tubitv.com](https://tubitv.com))

**The story of  Taylor Hooton who committed suicide at age 17 and his father blamed steriod use**: [Taylor Hooton At A Glance](https://www.justthinktwice.gov/true-stories/taylor-hooton-17) (justthinktwice.gov) [33:45]

**Episode of The Drive about steroids with Mark and Chris Bell**: [#28 – Mark and Chris Bell: steroids, powerlifting, addiction, diet, training, helping others, documentaries, and living your best life](https://peterattiamd.com/brothersbell/) | Peter Attia (peterattiamd.com) [33:45]

**The fake penis and bladder for passing a drug test**: [Whizzinator](https://en.wikipedia.org/wiki/Whizzinator) | (wikipedia.org) [36:45]

**Onterrio Smith famously got caught with a Whizzinator**: [Smith caught with ‘Whizzinator’ at airport last month](https://www.espn.com/nfl/news/story?id=2061794) | (espn.com) [36:45]

**The football movie which had players doing the “oil change” method for passing drug tests**: [The Program](https://en.wikipedia.org/wiki/The_Program_(1993_film)) | (wikipedia.org) [40:00]

**Episode of The Drive about psychedelics with Rick Doblin**: [#65 – Rick Doblin, Ph.D.: MDMA — the creation, scheduling, toxicity, therapeutic use, and changing public opinion of what is possibly the single most important synthetic molecule ever created by our species](https://peterattiamd.com/rickdoblin/) | Peter Attia (peterattiamd.com) [42:00]

**Kyle realized the importance of sleep after hearing episodes of Matthew Walker on The Drive**: [46:30]

- [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/) | Peter Attia (peterattiamd.com)
- [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/) | Peter Attia (peterattiamd.com)
- [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/) | Peter Attia (peterattiamd.com)
- [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/) | Peter Attia (peterattiamd.com)

**Book Kyle read about the importance of sleep**: [Why We Sleep: Unlocking the Power of Sleep and Dreams](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316) by Matthew Walker | (amazon.com) [46:30]

**The Arizona MMA circuit where Kyle got his start in cage fighting**: [Rage In The Cage](https://twitter.com/rageinthecageaz?lang=en) | (twitter.com) [53:30]

**John Hackleman on Kyle’s podcast**: [#103 John Hackleman](https://www.youtube.com/watch?v=PtAFHinq1BI) | Kyle Kingsbury Podcast (youtube.com) [55:15]

**Famous MMA training facility that Kyle trained at**: [American Kickboxing Academy](https://en.wikipedia.org/wiki/American_Kickboxing_Academy) | (wikipedia.org) [57:45]

**One of the first big time MMA fighting organizations that used to be equivalent to UFC**: [Pride Fighting Championships](https://en.wikipedia.org/wiki/Pride_Fighting_Championships) | (wikipedia.org) [59:15]

**The MMA fighting organization that is a bridge to the UFC that Kyle fought in prior to the UFC**: [King of the Cage](https://en.wikipedia.org/wiki/King_of_the_Cage) | (wikipedia.org) [59:45]

**Kyle says he was overconfident leading to his first loss in MMA fighting and compares it to Tyson’s attitude before fighting Buster Douglas**: [Mike Tyson vs. Buster Douglas](https://en.wikipedia.org/wiki/Mike_Tyson_vs._Buster_Douglas) | (wikipedia.org) [1:00:45]

**Website Kyle used to do his research about psychedelics which made him more interested in ayahuasca**: [EROWID](https://www.erowid.org/) | (erowid.org) [1:11:15]

**Book about depression that Peter calls, “*****one of the most important books I’ve ever read in my life*****”**: [I Don’t Want to Talk About It: Overcoming the Secret Legacy of Male Depression](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398) by Terry Real | (amazon.com) [1:16:15]

**Organization Kyle used for his most recent ayahuasca ceremonies**: [Soltara Healing Center](https://soltara.co/) | (soltara.co) [1:21:00]

**Scene in Fight Club that resonated with Kyle**: [“I want to destroy something beautiful”](https://www.youtube.com/watch?v=Gi54QFCv6_o) | samaelalejandro (youtube.com) [1:28:45]

**Wilderness survival camps by Tim Corcoran that Kyle says he’d like to get his son to do**: [Twin Eagles Wilderness School](https://www.twineagles.org/) | (twineagles.org) [1:33:45]

**Book about the science of psychedelics that Peter highly recommends**: [How to Change Your Mind: What the New Science of Psychedelics Teaches Us About Consciousness, Dying, Addiction, Depression, and Transcendence](https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225) by Michael Pollan | (amazon.com) [1:36:00]

§

## People Mentioned

- [Joe Kenn](https://bighousepower.com/biography/) (Kyle’s strength coach at ASU) [16:45, 23:00, 1:02:00]
- [Mark Uyeyama](https://www.vikings.com/team/coaches-roster/mark-uyeyama) (another one of Kyle’s strength coaches at ASU) [17:00]
- [William Llewellyn](https://www.amazon.com/William-Llewellyn/e/B001K8TZ8O) (books on anabolics) [29:00]
- [Wayne Dyer](https://en.wikipedia.org/wiki/Wayne_Dyer) (Kyle [quotes Wayne Dyer](https://www.goodreads.com/quotes/849398-when-you-squeeze-an-orange-you-ll-always-get-orange-juice)) [31:00]
- [Taylor Hooton](https://www.justthinktwice.gov/true-stories/taylor-hooton-17) (committed suicide while on steriods) [33:45]
- [Onterrio Smith](https://en.wikipedia.org/wiki/Onterrio_Smith) (Whizzinator) [36:45]
- [James Caan](https://en.wikipedia.org/wiki/James_Caan) (plays Coach Sam Winters in The Program) [40:00]
- [Rick Doblin](https://en.wikipedia.org/wiki/Rick_Doblin) (psychedelics, previous [guest on The Drive](https://peterattiamd.com/rickdoblin/)) [42:15]
- [Matthew Walker](https://en.wikipedia.org/wiki/Matthew_Walker_(scientist)) (sleep expert, previous guest on The Drive) [46:30]
- [Bruce Lee](https://en.wikipedia.org/wiki/Bruce_Lee) (some credit with starting MMA) [55:15]
- [John Hackleman](https://john-hackleman.mykajabi.com/pages/about-us) (created Hawaiian Kempo) [55:15
- [Bob Meyrowitz](https://en.wikipedia.org/wiki/Bob_Meyrowitz) (one of the founders of the UFC) [56:45]
- [Rorion Gracie](https://en.wikipedia.org/wiki/Rorion_Gracie) (one of the founders of the UFC) [56:45]
- [Frank Shamrock](https://en.wikipedia.org/wiki/Frank_Shamrock) (kickboxing coach) [57:45]
- [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson) [1:00:45]
- [Buster Douglas](https://en.wikipedia.org/wiki/Buster_Douglas) (famously beat Mike Tyson) [1:00:45]
- [Herb Dean](https://en.wikipedia.org/wiki/Herb_Dean) (ref of the first fight that Kyle lost) [1:01:00]
- [Dan Inosanto](https://en.wikipedia.org/wiki/Dan_Inosanto) [1:01:15]
- [Vince Perez-Mazzola](https://sharper-axe.com/martial-arts-certified-instructor/) (Kyle’s striking coach who convinced him to move back to AZ and train for the UFC at the AKA) [1:01:15}
- [Cain Velasquez](https://en.wikipedia.org/wiki/Cain_Velasquez) (Kyle trained with him getting ready for the UFC, former ASU wrestler, and now the UFC heavyweight champion) [1:02:00]
- [Daniel Cormier](https://en.wikipedia.org/wiki/Daniel_Cormier) (UFC fighter) [1:06:30]
- [Jon Jones](https://en.wikipedia.org/wiki/Jon_Jones) (UFC fighter) [1:06:30]
- [Terrence Real](https://www.terryreal.com/) (wrote book [I Don’t Want to Talk About It](https://www.amazon.com/Dont-Want-Talk-About-Overcoming/dp/0684835398)) [1:16:15]
- [Dennis McKenna](https://en.wikipedia.org/wiki/Dennis_McKenna) (ayahuasca) [1:20:15, 1:35:45]
- [Gabor Maté](https://en.wikipedia.org/wiki/Gabor_Mat%C3%A9_(physician)) (ayahuasca) [1:20:15]
- [Edward Norton](https://en.wikipedia.org/wiki/Edward_Norton) (actor in Fight Club) [1:28:45]
- [Brad Pitt](https://en.wikipedia.org/wiki/Brad_Pitt) (actor in Fight Club) [1:28:45]
- [Ben Greenfield](https://twitter.com/bengreenfield) (mutual friend of Kyle and Peter) [1:33:45]
- [Tim Corcoran](https://www.facebook.com/timcorcoran74?__tn__=%2CdH-R-R&eid=ARAGExamdXKRBakdGGkTxcnwwj0PH4HpKUesEfA8cRNylurKepN1BEm2qMxJ_8sVu1sChZbU0PDBrWCe&hc_ref=ART_G1zBcsOTfX5j-kydQZUIVBVvYMz0i8tmnC9PNLwZt5mvcCVVWTU4KnEnG802_MQ&fref=nf) ([Twin Eagles Wilderness School](https://www.twineagles.org/))  [1:33:45]
- [Aubrey Marcus](https://www.aubreymarcus.com/pages/about) (CEO of Onnit) [1:34:15]
- [Poranguí](https://en.wikipedia.org/wiki/Porangu%C3%AD) (incredible musician who used ayahuasca as a child) [1:35:00]
- [Michael Pollan](https://twitter.com/michaelpollan?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (psychedelics expert, wrote [How to Change Your Mind](https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225)) [1:36:00]
- [Ram Dass](https://en.wikipedia.org/wiki/Ram_Dass) (famous quote “If you think you’re enlightened, spend a week with your family”) [1:37:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/10/kyle-kingsbury-bio-image-500x500.png)

##### Kyle Kingsbury

Kyle is the Director of Human Optimization at [Onnit](https://www.onnit.com/), a retired mixed martial artist and UFC fighter, and the host of the [Kyle Kingsbury Podcast](https://www.youtube.com/channel/UCMV1AsT4HYXNG0pWri4Tp1Q).