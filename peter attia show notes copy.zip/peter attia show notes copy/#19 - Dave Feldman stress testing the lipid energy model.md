# #19 – Dave Feldman: stress testing the lipid energy model

**Source:** [https://peterattiamd.com/davefeldman/](https://peterattiamd.com/davefeldman/)

---

In this episode, Dave Feldman, discusses his journey from software engineer to n=1 experimenter, his experience with low-carbohydrate diets, and his hypothesis that cholesterol levels are influenced by energy metabolism.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

Note: this podcast gets technical at times and refers to many visuals during the discussion. The graphics, figures, and tables alluded to are provided in the show notes. In addition, there is commentary by Thomas Dayspring, M.D., in the show notes, providing corrections, clarifications, and amplification. Dave Feldman provided many graphics and some additional comments that are included in the show notes.

**For the transcript of this episode, [please visit this page](https://peterattiamd.com/davefeldmantranscript/), where there is more commentary from Tom Dayspring.**

![The Peter Attia Drive](images/davefeldman/the_Drive_public.png)

Play

#19 - Dave Feldman: stress testing the lipid energy model

1x15s30s

0:003:10:16

**We discuss:**

- Peter’s synthesis of Dave’s energy model [5:00];
- Dave’s lipid energy model;
- Dave’s inversion pattern experiments;
- Dave’s journey from software engineer to cholesterol enthusiast [15:00];
- Standard blood panels, sterol panels, and what moves the needle when it comes to particle numbers [18:30];
- Hyper-responders [20:00];
- Lipoprotein transport [33:45];
- The lean mass hyper-responder phenotype [47:30];
- The progression of atherosclerosis, CAC, and CIMT [52:30];
- Testing for oxidized LDL [55:30];
- All-cause mortality and clinical endpoints [1:01:15];
- What does “LDL as causal” mean? [1:05:15];
- Dave’s low carb cholesterol challenge and drug & genetic study qualifications [1:13:15];
- If all other markers are in a healthy range, but LDL-P is high, is the patient at risk? A couple of case studies, and a self-experiment [1:27:30];
- Peter’s three-day exercise and ketosis experiment [1:41:00];
- What are remnant lipoproteins? [1:45:00];
- What might cause lean mass hyper-responders to have higher LDL particle numbers? [1:53:30];
- A case study from Dave of a lean mass hyper-responder [1:56:30];
- Mass balance and cholesterol flux [2:05:30];
- Can a higher degree of cholesterol explain the lean mass hyper-responder phenotype? [2:10:00];
- Peter’s LDL during his keto-fast-keto experiment [2:13:30];
- Does substituting saturated fats with monounsaturated fats lower LDL-P and LDL-C? [2:15:45];
- Dave’s carb-swap experiments [2:22:15];
- Dave’s carotid intima-media thickness tests [2:41:15];
- Looking for studies that stratify for high HDL-C and low TG alongside low and high LDL-C [2:53:00]; and
- More

§

## Show Notes

## Peter’s synthesis of Dave’s energy model [5:00]

Ultimately Peter found Dave’s model unconvincing for three reasons, and provided them in the intro of the podcast:

1. “Dave was unable to explain the mass balance, meaning how does one account for the greater amount of cholesterol in, and the greater number of, LDL particles. No one, including Dave, is disputing that the phenotype of interest has more LDL-C and more LDL-P. There are only 3 ways this can happen (these are [collectively exhaustive, but not [mutually exclusive]): make more, clear less, transfer from other pools that we can’t see (e.g., cell membranes). I think the data make the first of these by far the most likely driver, but Dave seemed unable to address this and could not explain, to me at least, what could account for this increase in LDL-P/C. So on first principles, my doubt of this model has gone up from the start of this discussion, as the person who developed the model could not actually explain the mass balance. This is one of the most fundamental requirements of any model. And to be clear, even if this fundamental condition were met, it would not be sufficient to make the case that [lean mass hyper-responders or LMHRs] are not at risk. It’s a [necessary but not sufficient] criteria that, in my mind, has failed.”
2. “Dave argues that VLDL production is driving the LDL concentration, but the fact remains that in insulin-sensitive people (which presumably the LMHRs are), the opposite is true: there are fewer, not more, TG being exported from the liver and there is less, not more, apoC-III on the VLDL, thereby reducing, not increasing, their residence time. In other words, LMHR would have less VLDL to LDL conversion than, say, someone with T2D. So again, I can see no evidence whatsoever that his energy model, which can’t be explained on mass balance, and can’t be explained on what is known about the physiology of VLDL and LDL, is plausible.”
3. “Even if you ignore the points above—which you can’t—I am more unconvinced than ever at the notion that we should exclude the roughly 2,000 genetic mutations known to produce a phenotype of high LDL-C, high HDL-C, and low TG. We have 2,000 natural experiments. Surely at least some of these cases (e.g., PCSK9 gain of function) are excellent proxies for the key features of LMHR. Yet to ignore them for imaginary reasons (e.g., having gain of function PCSK9 is somehow toxic to endothelial cells because it impairs their ability to take up cholesterol despite there being no evidence that endothelial cells require PCSK9 to uptake LDL in a receptor-mediated fashion) is to say, in my opinion, one does not want to know the answer to this question.”

Peter emphasizes that probabilities play a very important role in diseases like atherosclerosis, and this nuance is often missing when discussing this disease.

Atherosclerosis is impacted by many things beyond the lipoproteins, but that doesn’t diminish their role in the causality of atherosclerosis, Peter argues.

**Note from Peter**: Some low carb enthusiasts argue that as long as they are insulin sensitive, have high HDL-C and low TG, their LDL-C (or LDL-P or apoB) is irrelevant. Further, many confuse imaging tests like calcium scans (CACs) as biomarkers and argue that as long as CAC = 0, there is no need to treat, despite the risk predicted by biomarkers. If you are confused by all of the noise on this topic, consider this example: A biomarker like LDL-P or apoB is predictive. It’s like saying you live in a neighborhood with a lot of break-ins. A CAC is a backward-looking assessment of damage that has already taken place. So it’s more like an investigation into a break-in that already happened. In my opinion, waiting until there is grossly visible (i.e., no longer just microscopic) evidence of disease in the artery to decide to treat for risk already predicted by biomarkers is like saying you won’t get a lock on your door—even if you live in a high-risk neighborhood—until you’ve suffered a break-in. This is bad risk management. As the saying goes, “When did Noah build the ark?”

Ultimately, it’s up to the individual, who’s LDL-P and LDL-C are very high while consuming a low-carb high-fat (LCHF) or ketogenic diet (KD), to make a decision: the hope is that the following discussion (and related references and material in the show notes) can help people think through the issues and make a more informed decision.

## Dave’s lipid energy model

![](https://peterattiamd.com/wp-content/uploads/2018/10/feldman-01-lipidEnergyModelTheory.png)

**Figure 1. Dave Feldman’s lipid energy model.** Image credit: Dave Feldman [click [here](https://peterattiamd.com/wp-content/uploads/2018/10/feldman-01-lipidEnergyModelTheory.png) for larger image]

## Dave’s inversion pattern experiments

![](https://peterattiamd.com/wp-content/uploads/2018/10/ldlc-vs-3day-fat-normal.png)

**Figure 2. Three-day average of dietary fat vs LDL-C.**Image credit: Dave Feldman

![](https://peterattiamd.com/wp-content/uploads/2018/10/ldlc-vs-3day-fat-inverted.png)

**Figure 3. Three-day average of dietary fat *inverted* vs LDL-C.**Image credit: Dave Feldman

![](https://peterattiamd.com/wp-content/uploads/2018/10/ldlp-vs-3day-fat-normal.png)

**Figure 4. Three-day average of dietary fat (with a two-day gap) vs LDL-P.** Image credit: Dave Feldman

![](https://peterattiamd.com/wp-content/uploads/2018/10/ldlp-vs-3day-fat-inverted.png)

**Figure 5. Three-day average of dietary fat (with a two-day gap) *inverted* vs LDL-P.**Image credit: Dave Feldman

## Dave’s journey from software engineer to cholesterol researcher [15:00]

- In April 2015, Dave was a software engineer that went on a low-carb high-fat (LCHF) diet and felt better than ever
- November 24, 2015: Total Cholesterol (TC): 329
- He was averaging 224 gm fat/d for the 3-days prior to the test
- He decreased the fat in his diet (still LC) to 83 gm fat/d
- December 9, 2015: TC: 424
- From this point, he started doing N=1 experiments
- Started tracking food intake and blood tests (51 tests in 15 months)
- Dave read Peter’s [Straight dope on cholesterol series](https://peterattiamd.com/?s=straight+dope+on+cholesterol) that helped him understand lipoproteins
- Dave can move his LDL-C and LDL-P count up and down without medication or supplements by finding what he believes to be the primary influencer: energy metabolism (especially fatty acid utilization for energy) (Figures 1-5)

### Primer for Dave’s Inversion Pattern and Lipid Energy Model

- [Low Carb Down Under Breckinridge 2017](https://www.youtube.com/watch?v=jZu52duIqno)
- [Low Carb Down Under Breckinridge 2018](https://www.youtube.com/watch?v=0LuKwsz9Woc)

### Selection of Dave Feldman’s podcast appearances

- **Podcast with Dave Feldman as guest**: [BH020: Cholesterol — Understanding How the Body Uses It and Are High LDL Levels Really Dangerous? With  Dave Feldman](https://drbretscher.libsyn.com/bh020-cholesterol-understanding-how-the-body-uses-it-and-are-high-ldl-levels-really-dangerous-with-dave-feldman) | Bret Scher (lowcarbcardiologist.com) [17:45]
- **Podcast with Dave Feldman as guest**: [BH024: Dave Feldman of CholesterolCode.com- Part 2 To Help Us All #RethinkLDL](https://drbretscher.libsyn.com/ep024-dave-feldman-of-cholesterolcodecom-part-2-on-why-a-mixed-diet-potentially-increases-ldl-cholesterol) | Bret Scher (lowcarbcardiologist.com) [17:45]
- **Podcast with Dave Feldman as guest**: [LCCP036: Dave Feldman Challenges Everything We Think We Know About LDL Cholesterol](https://drbretscher.libsyn.com/dave-feldman-challenges-everything-we-think-we-know-about-ldl-cholesterol) | Bret Scher (lowcarbcardiologist.com) [17:45]
- **Podcast with Dave Feldman as guest**: [Episode 400 – Dave Feldman – Cholesterol and Lipoproteins](https://robbwolf.com/2018/07/03/episode-400-dave-feldman-cholesterol-and-lipoproteins/) | Robb Wolf (robbwolf.com) [17:45]
- **Podcast with Dave Feldman as guest**: [How to Drop Your Cholesterol with Dave Feldman](https://www.nourishbalancethrive.com/podcasts/nourish-balance-thrive/how-drop-your-cholesterol/) | Nourish Balance Thrive (nourishbalancethrive.com) [17:45]

## Standard blood panels, sterol panels, and what moves the needle when it comes to particle numbers [18:30]

- Peter reviews Dave’s lipid values prior to going LCHF (Peter’s comments are bracketed)
- TC (approximately): 186 [Total cholesterol is of no interest]
- LDL-C:131 [a little over the 50th percentile (66th percentile in MESA\*)]
- HDL-C 40 [Quite a bit below the 66th percentile (probably not, for a man)]
- TG: 80 [Doesn’t give us great insight (25th percentile)]
- TG:HDL-C ratio: 2 [< 3 generally considered “acceptable”]
- Unfortunately, Dave didn’t get labs for LDL-P or apoB, and acknowledges this is important to understand more about what’s happening

![](https://peterattiamd.com/wp-content/uploads/2018/10/otvos-mesa-framingham-Cut-off-points-for-LDL.jpg)

**Figure 6. LDL-C and LDL-P percentiles from Framingham and MESA, respectively.**

## Hyper-responders [20:00]

1. Dave Feldman points out that Tom Dayspring may have coined the term *hyper-responder* for people who see their TC, LDL-C, and LDL-P go way up on a LCHF diet
2. Tom [wrote a piece on this phenomenon](https://www.dropbox.com/s/1fbzojwm4lytjss/Dayspring%20-%20Lipidaholics%20Case%20291%20-%20Can%20losing%20weight%20worsen%20lipids%3F.pdf?dl=0) in his Lipidaholics series
3. Peter says it’s essential that people get a sterol panel (Figure 7) in addition to an advanced lipid panel

Peter says LDL-P and ApoB are affected by four things:

1. The amount of cholesterol you synthesize (measure with a sterol panel)
2. The amount of cholesterol (or sterol) that you reabsorb (measure with a sterol panel)
3. The amount of triglycerides (TGs) you have to carry around (you can get a crude sense from looking at the serum triglyceride level)
4. Your clearance of the particles (which is primarily driven by the LDLR on the liver) (we don’t have an assay for this)

You can try to impute to understand clearance: if the synthesis goes down, the absorption goes down, the TGs are largely unchanged, and the LDL-C goes up, the LDL-P goes up, then you know clearance has gone down, but this is only inferred if TG, synthesis, and absorption all move in one direction, while LDL-P/C moves in the other direction. There is no assay for LDL clearance.

![](https://peterattiamd.com/wp-content/uploads/2018/10/cholesterol-synthesis-and-absorption-desmosterol-campesterol-sitosterol-cholestanol-lathosterol.png) **Figure 7. Plasma absorption and synthesis markers (and ranges) by sterol markers.**

**Case of elevated LDL-C and LDL-P on a low-carb diet**: [Lipidaholics Anonymous Case 291 Can losing weight worsen lipids?](https://www.dropbox.com/s/1fbzojwm4lytjss/Dayspring%20-%20Lipidaholics%20Case%20291%20-%20Can%20losing%20weight%20worsen%20lipids%3F.pdf?dl=0) | Tom Dayspring (PDF) [20:30]

## Lipoprotein transport [33:45]

- Lipoproteins are a boat: they are lipid-carrying proteins, Dave says: your body makes them, and they make them at numbers we can’t even imagine: they’re measured in quintillions
- It’s doing this both in the gut and in the liver. When they make it, they’re basically packing in lipids
- In particular, they pack just about every kind of lipid, not just triglycerides, which your body uses for energy, but also cholesterol, and fat-soluble vitamins: it packs all of these in the same container
- Apolipoproteins are like metadata, headers, for example, as far as where it is they’re going to go, and why
- It appears as if its primary job, more than any other job, particularly chylomicrons and VLDLs, are to deliver fat-based energy to tissues
- Fat comes in the body: you’re on a high-fat diet, you’re eating fat — it’s going to the gut.
- The chylomicron, which is its own little lineage because it has a different apolipoprotein (apoB48) (Figure 8)
- It’s the VLDL to IDL to LDL path that is described by apoB100, which differentiates them
- About 40% of LDL comes directly from the liver (Sacks, 2015)
- Unless we actually know something more than just how much cholesterol is in VLDL, Peter says, we have no way of knowing whether it’s a physiologic remnant, or a pathologic remnant
- The pathologic remnants disproportionately carry apoC-III, which increases their residence time and the same is true on LDL, Peter says

There’s de novo creation of VLDLs that can wind up as LDLs, and de novo creation of LDLs, and they form this circulating pool, but we can’t really differentiate those when you look at that snapshot, Peter says

- Peter argues that none of the LDL particles are for energy delivery
- Many of the LDLs originate as VLDLs
- Dave uses a pizza delivery analogy to explain lipoprotein transport
- The job is to deliver pizzas (i.e., triglycerides in VLDLs), and it only takes them about an hour to do
- And then the rest of the next two to four days they’re (now an LDL) actually going to be patrolling the neighborhood
- They’re going around, and they’re also helping to fix up people’s houses, or something along those lines
- Somebody who comes into the neighborhood and sees a whole bunch of these cars patrolling, they don’t know how many of those people actually delivered pizzas before they got started on that part of the shift.
- We don’t actually know how many people left the liver, how many VLDLs
- **Peter disagrees 100% with this analogy; in the insulin sensitive person, fatty acid/TG delivery is not especially high from VLDL, in fact, it’s lower than it is in someone who is insulin resistant: if this phenotype is one we see in insulin-sensitive people, then we should see less VLDL excretion from the liver, not more, and therefore less LDL**

**Note from Tom Dayspring**: *There are other sources of cholesterol in the blood, namely red blood cells (RBCs) – and cholesterol can be delivered to tissues or extracted from tissues by RBC.*

Peter points to the Sacks (2015) paper that found:

- 38% of LDLs de novo secreted from the liver
- 62% from IDL or VLDL

![](https://peterattiamd.com/wp-content/uploads/2018/10/major_lipoprotein_classes_and_pathways.png)

**Figure 8. Major lipoprotein classes and pathways.** Image credit: Dave Feldman

**About 38% of plasma LDL is secreted directly in normolipidemic individuals compared with 27% in hypertriglyceridemia**: [The crucial roles of apolipoproteins E and C-III in apoB lipoprotein metabolism in normolipidemia and hypertriglyceridemia](https://www.ncbi.nlm.nih.gov/pubmed/25551803) (Sacks, 2015) [40:15]

**Ron Krauss on the half-life of LDL**: [Ron Krauss, M.D.: a deep dive into heart disease (EP.03)](https://peterattiamd.com/ronkrauss/) | Peter Attia (peterattimd.com) [45:30]

**Half-life of LDL**: [Metabolism of apoB and apoC lipoproteins in man: kinetic studies in normal and hyperlipoproteinemic subjects](https://www.ncbi.nlm.nih.gov/pubmed/202659) (Berman et al., 1978) [47:00]

## The lean mass hyper-responder phenotype [47:30]

- Dave speculates that *lean mass hyper-responders* (LMHRs) (Figure 9), people who are athletic, lean, and very low carb, see very high levels of LDL-C and LDL-P, and very high levels of HDL-C, and low levels of triglycerides (Figure 10), would show a very high rate, proportionally, of VLDL secretion
- Dave speculates they actually are trafficking a lot more, for their energy, triglycerides in VLDL particles, and therefore have succeeding LDL particles, which would explain why their LDL-C and LDL-P would be higher
- Dave thinks it’s somewhere between 5-30% that have this hyper-response

![](https://peterattiamd.com/wp-content/uploads/2018/10/normal-hyperresponder-lmhr.png)

**Figure 9. Lean mass hyper-responder (LMHRs) pattern Dave is seeing in a subset of subjects.** Image credit: Dave Feldman

![](https://peterattiamd.com/wp-content/uploads/2018/10/lmhr-graphic.png)

**Figure 10. Lean mass hyper-responder phenotype Dave is seeing in a subset of subjects**. Image credit: Dave Feldman

**Peter’s podcast with Rhonda discussing PPARs**: [Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more (EP.02)](https://peterattiamd.com/rhondapatrick/) | Peter Attia (peterattiamd.com) [51:00]

## The progression of atherosclerosis, CAC, and CIMT [52:30]

CIMT: [Carotid Intima-Media Thickness test](https://www.healthline.com/health/heart-disease/cimt-test)

CAC: [Coronary Artery Calcium test](https://www.mayoclinic.org/tests-procedures/heart-scan/about/pac-20384686)

- A CAC is a CT scan that very quickly scans over the heart and just picks up calcification (no anatomic detail)
- A CIMT is a type of ultrasound that looks at the intimal thickness, (i.e., one of the walls of the arteries’ thickness in the carotid arteries in the neck)
- These are both tests that are used to try to gauge advanced disease
- Look at a pathology textbook, look at the autopsies, and you’ll find that long before you have luminal narrowing, which may or may not accompany a problem, you have a very clear documented path of atherosclerosis, Peter says
- The arteries have an [endothelial](https://en.wikipedia.org/wiki/Endothelium) lining (Figure 11) a very thin type of cell, forming an interface between circulating blood or lymph in the lumen and the rest of the vessel wall, meaning the part that’s closest to where the blood is flowing
- There are spaces between these and, via diffusion, lipoproteins get in there and out of there all the time
- This is relatively well understood to be a gradient phenomenon, so the more lipoproteins you have, the more of them that are going to go in, Peter says
- Other things will influence it: the residence time for example, which might be why apoC-III may be a problem, because if it allows these cells [lipoproteins] to stick around longer, bad things could happen
- HDL particles always come out of there
- The problem occurs when proteoglycans bind to the apoB on LDLs, it gets retained, all of a sudden now you have something that’s where it’s not supposed to be, Peter says
- It’s obviously in a high oxygen environment, so it’s going to undergo a chemical reaction called oxidation (phospholipids are the major oxidation target)
- It’s that oxidative reaction that then kicks off an inflammatory response in the endothelium

![](https://peterattiamd.com/wp-content/uploads/2018/10/artery-wall.jpg)

**Figure 11. Diagram illustrating the layers of the artery wall**. Image credit: [IAME](https://iame.com/online/vascular_laboratory_markers_of_cardiovascular_risk/content.php)

**Pathology textbook**: [Atlas of Atherosclerosis Progression and Regression](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?ie=UTF8&qid=1526578233&sr=8-1&keywords=stary+atherosclerosis) by Herbert C. Stary [53:15]

**Stages of atherosclerosis**: [A Definition of Advanced Types of Atherosclerotic Lesions and a Histological Classification of Atherosclerosis](https://www.ahajournals.org/doi/abs/10.1161/01.cir.92.5.1355) (Stary et al., 1995) [53:15]

**One of Peter’s post on the progression of atherosclerosis**: [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/) | Peter Attia (peterattiamd.com) [53:15]

## Testing for oxidized LDL [55:30]

- A lab test can get an estimation of the oxidative burden, the OxLDL assay
- It turns out some very small percentage of those LDLs, once they are oxidized, escape back into the circulation

**Note from Tom Dayspring**: S*ome might, but the test measures circulating MINIMALLY OXIDIZED LDLs. Any LDLs escaping would be, way more than minimally.*

- It’s important to understand that when you get a blood test, that’s not telling you what’s happening in your artery
- It’s giving you probabilities of things that are largely stochastically governed, that are going on in your artery.
- And the oxLDL is no exception

**LDL-P and vitamin E**

- LDL particles, specifically apoB100 at the LDL stage, have alpha-tocopherol
- Part of the purpose of an LDL particle is to actually provide that as a means to battle reactive oxygen species, Dave suggests

**Note from Tom Dayspring**: *Vitamin E is absorbed in the intestine, and the vast majority gets to tissues in chylomicrons – but some are on VLDL, which completes the delivery, but some are on LDL, but their function is not to deliver Vit E. Type IIIs have no LDL particles, yet have no vitamin E deficiency. VLDLs and chylomicrons transporting Vitamin E in plasma (meaning plasma is rich antioxidants) is part of the reason why there really are very few fully oxidized LDLs in plasma – only minimally oxidized.*

**Note from Tom Dayspring**: *People with abetalipoproteinemia (who have NO apoB particles) and some with severe hypobetalipoproteinemia do have vitamin E issues (But mostly it is because they do not have VLDLs) Many do supplement severe hypobetalipoproteinemia patients with vitamin E.*

- There’s the potential of the phospholipid shell of LDL particles to become oxidized.
- If you get oxidized phospholipids, that also can bring about the role Lp(a), that can cleave off the oxidized phospholipids

**Note from Tom Dayspring**: *The lysine binding domains on 1 or 2 specific kringles traffic any oxidized lipid moiety – but most are oxPL.*

- And this is the role of Lp-PLA2
- It may be why you would have a higher detection of small lipoproteins, particularly small LDLs, if you’re getting them constantly oxidized and having to constantly cleave them down to much smaller amounts

**Reference Dave provided on LDL-delivered a-tocopherol studies**: Vitamin E: Mechanism of Its Antioxidant Activity (Yamauchi, 1997) [56:45]

**Reference Dave provided on LDL-delivered a-tocopherol studies**: [The chemistry and antioxidant properties of tocopherols and tocotrienols](https://www.ncbi.nlm.nih.gov/pubmed/8827691) (Kamal-Eldin and Appelqvist, 1996) [56:45]

**Reference Dave provided on LDL-delivered a-tocopherol studies**: [Vitamin E Inadequacy in Humans: Causes and Consequences](https://academic.oup.com/advances/article-abstract/5/5/503/4565757) (Traber, 2014) [56:45}

## All-cause mortality and clinical endpoints [1:01:15]

- Most short-term studies don’t have the statistical ability to detect all-cause mortality (ACM), because of the manner in which they’re powered, Peter says
- It’s hard enough to detect cardiac mortality in a study
- The concern is, if you are less likely to die of heart disease, are you more likely to die of something else?
- It’s not uncommon in cardiovascular studies to see a reduction in coronary mortality with no change in all-cause mortality, or a non-statistical change
- Then you have to ask yourself the question, even if it looks like death went up or down of other causes, you have to go back and ask yourself, was the study actually able to detect that?
- Dave points out a paper that asks whether ACM is worth chasing, since it takes so much time and expense, should we even make that part of the criteria that are required?
- There’s a lifetime exposure problem, where atherosclerosis is a process that often takes longer than a few years, so short-term trials are inherently flawed
- FOURIER and ODYSSEY are trials that looked at two PCSK9 inhibitors
- Peter thought there’s no way they’d find a benefit, in particular, FOURIER, because it was a 2-year trial, but it did show benefits in events and revascularizations

**Nerd Safari post on statistical power**: [Studying Studies: Part V – power and significance](https://peterattiamd.com/nerd-safari/studying-studies-part-v-power-and-significance/) | Peter Attia (peterattiamd.com) [1:02:00]

**All-cause mortality paper Dave mentioned**: [Should a Reduction in All-Cause Mortality Be the Goal When Assessing Preventive Medical Therapies?](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.116.023359) (Sasieni and Wald, 2017) [1:02:00]

**Peter’s magic wand Gedanken experiment**: [The straight dope on cholesterol — Part VI](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-vi/) | Peter Attia (peterattiamd.com) [1:02:00]

## What does “LDL as causal” mean? [1:05:15]

Peter believes that the lower the LDL, the lower the risk of cardiovascular disease, all other things equal — why?

- Because LDL is [necessary, but not sufficient](https://en.wikipedia.org/wiki/Necessity_and_sufficiency) for atherosclerosis, Peter says
- Necessary, but not sufficient, is the relationship between oxygen and fire: Oxygen is necessary, but not sufficient for fire
- Can you have oxygen and no fire? Yes
- Can you have fire without oxygen? No
- The lower the concentration of oxygen, the less likely you are to spontaneously get a fire
- It’s a bit of an oversimplification because there are so many other factors, endothelial health and oxidation, and inflammation, are important

Peter argues that cardiovascular disease is primarily driven by three things (markers in parentheses):

1. Lipoproteins (Lp[a], LDL-P, small LDL-P, VLDL remnant)
2. Inflammation (nonspecific: fibrinogen, hs-CRP; specific: oxLDL, Lp-PLA2, oxPL)
3. Endothelial dysfunction (insulin, Hcy, ADMA, and SDMA)

## Dave’s low carb cholesterol challenge and drug & genetic study qualifications [1:13:15]

- Dave has a [pinned Tweet](https://twitter.com/DaveKeto/status/1029365733132722176), requesting people submit studies that can demonstrate that people with high HDL-C, low TGs, and high LDL-C
- There are two qualifications: no drug studies and no genetic studies
- Peter has an issue with the qualifications: why would you limit yourself from genetic studies, which are themselves the basis for Mendelian Randomization?
- Dave is concerned about a potential confounder: lipid malabsorption
- With gene-based studies, we’re trying to isolate just a higher gradient of LDL particle count
- We want [Peter’s magic wand](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-vi/): we can wave it, and then there’s just magically more LDL particles in some people, or for that matter, fewer LDL particles, without touching any other parts of the process
- Dave believes there might be a confounder in the Mendelian Randomization studies showing people with SNPs that are associated with high LDL-P and LDL-C: the SNPs in these studies also are associated with a lack of lipoprotein uptake by the cell
- And his concern is, particularly with endothelial cells, it could cause dysfunction, and therefore could be a reason for why you’d have higher levels of atherosclerosis in these populations
- Why do we believe patients, or a subset of patients with FH, as a result of their FH, have defective endothelial cells? Peter asks
- There are no receptors on the endothelial cell, It’s diffusion mediated, Peter says

**Note from Dave**: *I was incorrect in conceding this point. Endothelial cells have LDL receptors. [Link provided: [LDLR is expressed on lymphatic endothelial cells of collecting lymphatic vessel and its level is modulated by PCSK9](https://www.nature.com/articles/srep27862/figures/3). From: Effects of LDL Receptor Modulation on Lymphatic Function (Milasan et al., 2016)*.

**Note from Peter**: *The critical question is: are LDL receptors necessary for LDL to enter the subendothelial space of a vascular endothelial cell?*

- Not all cases of FH have receptor deficiencies, Peter says
- When people talk about genetic studies, most of the variants that lead to alterations in lipids and lipid metabolism, are completely unidentified: FH, for example, which would be the most obvious example to counter that point, Dave’s excluding because it’s a genetic condition, Peter says
- FH is a phenotypic diagnosis, not a genotypic diagnosis: FH is arguably the most heterogeneous collection of genes you can imagine, Peter says
- There are at least 2,000 vaguely identified genetic causes of FH
- Gain of function PCSK9s are a subset of FH, about 3-5%
- Those patients’ livers, will take up less LDL, because PCSK9 is a protein that degrades the LDL receptors (among other things), they are more rapidly degrading their LDL receptors on the livers, so they’re taking up fewer LDL particles, which explains why they have higher LDL
- But this, again, introduces a dysfunction on the lipid metabolism itself, Dave argues
- In the end, I don’t really care what your LDL is, I care about you not getting atherosclerosis, Peter says
- The genetic data, coupled with the pharmacologic data, coupled with the mechanistic data, gives Peter a high enough degree of certainty, that he’s willing to act in a certain direction
- Everybody has to make a decision: indecision is also a decision
- Sometimes indecision is a reasonable decision: but people have to understand they are making a decision whatever they decide to do

**Peter’s magic wand Gedanken experiment**: [The straight dope on cholesterol — Part VI](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-vi/) | Peter Attia (peterattiamd.com) [1:02:00]

**Consensus panel paper including genetic studies (Mendelian randomization) concluding “LDL as causal”**: [Low-density lipoproteins cause atherosclerotic cardiovascular disease. 1. Evidence from genetic, epidemiologic, and clinical studies. A consensus statement from the European Atherosclerosis Society Consensus Panel](https://www.ncbi.nlm.nih.gov/pubmed/28444290) (Ference et al., 2017)

**Critical review of the consensus paper positing genetic mutations in or near *LDLR* may affect receptor function (and blood coagulability)**: [A Critical Review of the Consensus Statement from the European Atherosclerosis Society Consensus Panel 2017](https://www.karger.com/Article/FullText/486374) (Okuyama et al., 2018)

## If all other markers are in a healthy range, but LDL-P is high, is the patient at risk? A couple of case studies, and a self-experiment [1:27:30]

![](https://peterattiamd.com/wp-content/uploads/2018/10/feldman-podcast-ptn-labs-01.png)

**Figure 12. Peter’s patient’s labs.** [1:28:20]

Peter provides a patient’s case as an example of a hyper-response to a LCHF diet (only thing special about this case is that it’s the most recent one he’s seen, encountering this a week before the podcast was recorded):

- This is a male patient who’s been on a low carb diet for a couple of years, and is achieving amazing success with it
- His glucose disposal is excellent, his insulin levels are very low, his c-reactive protein is 0.3
- However, his oxLDL is the highest Peter has ever seen and the same is true of his LpPLA2
- Even if this patient had a negative calcium score (which he did not), Peter would have still recommended lipid lowering therapy and/or modification of diet: Why modification of diet?
- Peter has seen about 30 cases like this
- When a patients LDL particle number is through the roof, Peter looks at the things that affect apoB and LDL-P:

1. The amount of cholesterol you synthesize
2. The amount of cholesterol (or sterol) that you reabsorb
3. The amount of triglycerides (TGs) you have to carry around
4. Your clearance of the particles (which is primarily driven by the LDLR on the liver)

- - Are his triglycerides high? No
  - Does he have an LDL receptor defect? Probably not: Peter has seen this patient’s previous labs on a ketogenic diet and the LDL-C was 125 mg/dL
  - His cholesterol synthesis (desmosterol) is through the roof, and his cholesterol absorption (campesterol, sitosterol, cholestanol) is quite high as well

- Peter thinks the explanation for this phenotype is the up-regulation cholesterol synthesis from the saturated fat: a sterol regulated binding protein issue, or some sort of regulatory path around what the body is doing with ketones and/or saturated fat
- Peter used to see patients all the time with diabetic ketoacidosis in the ER, usually patients with type 1 diabetes, usually, it’s precipitated by some acute illness
- Their glucose level becomes very high, they don’t have enough insulin, they have electrolyte abnormalities, and they present with very high levels of ketones: it’s life threatening
- It turns out a lot of these people have very elevated levels of LDL-C, TC, and TG
- Once you correct this metabolic deficit, the cholesterol returns to normal
- Dave believes it may be related to what he calls the lean mass hyper-responder phenotype
- Dave did a resistance training experiment to see if there was an effect on lipoproteins
- Dave thinks there’s a greater overall gradient of receptor mediated endocytosis for muscle repair and growth with resistance training
- If the hypothesis is true, Dave would expect that his LDL-C and LDL-P might change: more use of the product of LDL-P directly by the cells
- Peter believes this patient is at risk based on his lipoproteins results, because this is one of the three legs of the stool: **the burden of lipoprotein**, the endothelial function or health, and the inflammatory response to it

**Hypertriglyceridemia and hypercholesterolemia that gets corrected after treating diabetic ketoacidosis**: [Severe Hypertriglyceridemia in Diabetic Ketoacidosis Accompanied by Acute Pancreatitis: Case Report](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2923793/) (Hahn et al., 2010) [1:35:30]

**Hypertriglyceridemia and hypercholesterolemia that gets corrected after treating diabetic ketoacidosis**: [Severe hypertriglyceridemia in diabetic ketosis](https://www.ncbi.nlm.nih.gov/pubmed/2124781) (Fulop and Eder, 1990) [1:35:30]

**Hypertriglyceridemia and hypercholesterolemia that gets corrected after treating diabetic ketoacidosis**: [Plasma triglycerides and cholesterol in diabetic ketosis](https://www.ncbi.nlm.nih.gov/pubmed/2505705) (Fulop and Eder, 1989) [1:35:30]

**Dave’s self-experiment with exercise and lipoprotein response**: [Resistance Training Experiment – Findings – Part I](https://cholesterolcode.com/resistance-training-experiment-findings-part-1/) | Dave Feldman (cholesterolcode.com) [1:38:00]

## Peter’s three-day exercise and ketosis experiment [1:41:00]

- Peter did an experiment where he did extensive blood tests, three tests a day, for three days, doing different types of exercise
- The tests are not commercially available: Peter tested pre-workout, immediately post-workout, and four hours later, looking at LDL, VLDL, and HDL particles, both in terms of their cholesterol and triglyceride content
- There’s virtually no way to distinguish what’s going on at the VLDL level
- Peter believes the labs show that the VLDL is moving its triglyceride, and the LDL, and the cholesterol is barely moving
- You cannot infer the actual numbers that went in and out, but just the net change
- The part that surprised Peter the most, was how little the cholesterol was actually moving out of the LDL, even when the particle concentration was going down

![](https://peterattiamd.com/wp-content/uploads/2018/10/Slide1.png)

**Figure 13. Peter’s 3-day, 3-blood-draw-per-day, exercise experiment: Day 1.** [1:41:00]

![](https://peterattiamd.com/wp-content/uploads/2018/10/Slide2.png)

**Figure 14. Peter’s 3-day, 3-blood-draw-per-day, exercise experiment: Day 2.** [1:41:00]

![](https://peterattiamd.com/wp-content/uploads/2018/10/Slide3.png)

**Figure 15. Peter’s 3-day, 3-blood-draw-per-day, exercise experiment: Day 3**. [1:41:00]

![](https://peterattiamd.com/wp-content/uploads/2018/10/remnant-lipoproteins.png)

**Figure 16. Remnant lipoproteins.** Image credit: Dave Feldman [1:41:45]

![](https://peterattiamd.com/wp-content/uploads/2018/10/Slide04.png)

**Figure 17. Relationship between LDL-C and apoB in Peter’s 3-day, 3-blood-draw-per-day, exercise experiment.** [1:43:00]

![](https://peterattiamd.com/wp-content/uploads/2018/10/Slide05.png)

**Figure 18. Relationship between LDL-C and LDL-P in Peter’s 3-day, 3-blood-draw, exercise experiment.** [1:43:00]

## What are remnant lipoproteins? [1:45:00]

- There are different definitions of “remnants”
- The poor-man’s version of remnant cholesterol is TG/5, which is the estimated VLDL-C
- This is actually part of the Friedewald equation and how LDL-C is calculated on most standard panels:
  - Calculated LDL-C = TC – HDL-C – estimated VLDL-C (TG/5)
- If you have an LDL-direct lab test, you can estimate VLDL-C:
  - VLDL-C = TC – HDL-C – LDL-C
- Peter says that it’s impossible to truly know someone’s remnants: Peter looks at remnants as VLDLs that have shed their triglyceride and are now small and cholesterol-rich
- In Peter’s 3-day exercise experiment, his VLDL-C measured direct is 4 mg/dL, whereas his lipid panel (TC: 165, LDL-C: 88, HDL-C: 49, TG: 126) calculates his VLDL-C at 25 mg/dl using Friedewald (TG/5), and 28 mg/dL using TC – HDL-C – LDL-C, a difference of 525% and 600%, respectively [1:47:30]
- When Dave speaks of [remnant cholesterol](https://en.wikipedia.org/wiki/Remnant_cholesterol), he’s referring to all cholesterol that’s not in either an LDL particle or in an HDL particle: subtract HDL cholesterol and LDL cholesterol (i.e., the VLDL-C estimates above)
- Some IDL, and possibly chylomicrons remnants can also remain in the bloodstream under certain conditions
- The issue Peter has with looking at VLDL-C is it doesn’t reveal what those particles have done or where they’re going
- Peter also found in one of his experiments that his estimated VLDL-C (TG/5 and LDL-C direct method) was five and six times higher than his direct VLDL-C measurement, respectively
- Dave believes the phenotype of lean mass hyper-responders will have very low levels of VLDL cholesterol, have very high levels of LDL cholesterol, and will have very low levels of remnant lipoproteins
- Unfortunately, remnant lipoproteins can’t be accurately measured in a commercial test
- Peter shows a study where they measured the number of particles in VLDL, IDL, LDL, and HDL (Table 1)
- The more insulin resistant you get, the more your total burden of apoB goes up: what the table is showing, is where is that burden coming from
- The VLDL increased by 20 nanomoles per liter, and the LDL-P increased by 400 nanomoles per liter
- The VLDL is going up as you get more insulin resistant, but it does not appear very clinically relevant, Peter says, because the burden of disease is from the apoB bearing particles, and so the increase in VLDL particle number is not what’s driving the risk of the disease
- Dave wonders if the remnant cholesterol (that he would get from subtraction of LDL-C and HDL-C from TC) will be more relevant to all-cause mortality than LDL-C

**Table 1. NMR lipoprotein subclass particle concentrations in insulin sensitive (IS), insulin resistant (IR), and type 2 diabetic subjects**. From: [Garvey et al., 2003](https://www.ncbi.nlm.nih.gov/pubmed/12540621) [1:49:25]

![](https://peterattiamd.com/wp-content/uploads/2018/10/garvey-table-4-vldl-p-ldl-lipoproteins.png)

![](https://peterattiamd.com/wp-content/uploads/2018/10/jeppesen-ihd-copenhagen-hdl-ldl-tg-fig.png)

**Figure 19. Incidence of ischemic heart disease (IHD) according to lipid categories and smoking status.** *P* value represents statistical significance between the two groups. Image credit: Jeppesen et al., 2001

**Framingham Offspring study stratifying for high HDL-C and low TG**: [Low triglycerides-high high-density lipoprotein cholesterol and risk of ischemic heart disease](https://www.ncbi.nlm.nih.gov/pubmed/11176761) (Jeppesen et al., 2001) [1:51:30, 2:56:00]

## What might cause lean mass hyper-responders to have higher LDL particle numbers? [1:53:30]

- Dave believes that lean mass hyper-responders are powered much more by triglycerides carried within VLDL particles, and therefore having more subsequent LDL particles
- Peter believes that it is the higher degree of cholesterol synthesis, which may or may not also be matched by a higher degree of absorption, that’s driving LDL-P higher

## A case study from Dave of a lean mass hyper-responder [1:56:30]

Dave says Craig Moffitt (Figure 20) is an example of a lean mass hyper-responder:

- Very high TC, LDL-C, HDL-C, and low TG and calculated remnant cholesterol
- Calculated remnant cholesterol = TC [457] – LDL-C [335] – HDL-C [109] = 13 mg/dL
- TG / 5 = 13.4 mg/dL = estimated VLDL-C
- Where is Craig getting his energy? He’s breaking down and releasing free fatty acids (FFA)
- The free fatty acids are ultimately making it back to its liver getting packaged into the VLDLs

**Note from Tom Dayspring**: *Albumin trafficked FFA can be brought to any cell that needs it for energy*.

- What we’re talking about the target sites of the muscles for which are making use of triglycerides.
- The primary purpose of the creation of TG is to replete everything: not just to fuel the muscles, it’s also to put it back into the adipocytes that just now released it as well
- In other words, Craig Moffitt like many people who are lean mass hyper-responders, if we could install a little turnstile into their adipocytes: we would see that turnstile just spinning like crazy, Dave says
- That’s because there’s less total adipose mass overall in Craig Moffitt compared to somebody who’s a lot heavier, and therefore there needs to be more global supply of VLDLs relative to somebody else who has a lot more fat mass (i.e., local supply), Dave believes
- Peter [wrote a blog post](https://peterattiamd.com/how-to-make-a-fat-cell-less-not-thin-the-lessons-of-fat-flux/) that helps explain fat flux: which ultimately describes the mass (in this case, fat) balance, where de novo lipogenesis + re-esterification = lipolysis [DNL + RE = L] (Figure 21)
- When Craig is running, he’s in negative fat flux (or fat efflux)
- Peter also believes that the liver is the “energostat” of the body, a term borrowed from Mark Friedman
- The job of chylomicrons is to deliver fat based energy
- HDL, not to deliver energy, call it support, generally speaking
- The liver-derived lipoproteins are pulling double-duty, Dave says
- Dave believes there’s a higher secretion of VLDLs overall for lean mass hyper-responders, that lead to relatively more LDL particles remaining in the bloodstream
- Peter argues that it’s unlikely more VLDLs are secreted given that most LMHRs Dave presented have low VLDL-C, and the kinetic studies (e.g., Garvey et al., 2003) show lower VLDL particle concentrations

![](https://peterattiamd.com/wp-content/uploads/2018/10/craig-moffit.png)

**Figure 20. Craig Moffitt.** Image credit: Dave Feldman [1:56:30]

![](https://peterattiamd.com/wp-content/uploads/2018/10/fat-flux-feldman-peter-post.png)

**Figure 21. A simplified diagram of a state of fat balance, or zero net fat flux.** From: Peter Attia, [The lessons of fat flux](https://peterattiamd.com/how-to-make-a-fat-cell-less-not-thin-the-lessons-of-fat-flux/) [1:59:20]

![](images/davefeldman/major_lipoprotein_classes_and_pathways.png)

**Figure 22. Major lipoprotein classes and pathways.** Image credit: Dave Feldman [2:04:30]

**Fat flux**: [How to make a fat cell less not thin: the lessons of fat flux](https://peterattiamd.com/how-to-make-a-fat-cell-less-not-thin-the-lessons-of-fat-flux/) | Peter Attia (peterattiamd.com) [1:59:00]

**Friedman on liver and hunger**: [The physiological psychology of hunger: A physiological perspective](https://www.ncbi.nlm.nih.gov/pubmed/1005583) (Friedman and Stricker, 1976) [2:05:15]

**Friedman on liver and hunger**: [Integrated metabolic control of food intake](https://www.ncbi.nlm.nih.gov/pubmed/3801940) (Friedman et al., 1986) [2:05:15]

**Friedman 2008 chapter on the Energostatic Model**: [Control, Regulation, and the Illusion of Dysregulation](https://sandbaronfalseriver.com/epub/download/id=499409&type=file) (Friedman, 2008) (PDF) [2:05:15]

## Mass balance and cholesterol flux [2:05:30]

If an individual goes from an LDL-C of 100 mg/dL to 300 mg/dL, this increase of 200 mg/dL needs to be accounted for — he can:

1. Make more cholesterol, and/or
2. Clear less cholesterol, and/or
3. Take cholesterol from an existing pool (e.g., cell membranes)

- Peter says that, if this hypothesis were likely to be true, the LDL particle would be very high, but the LDL cholesterol should be very low, and have very cholesterol-depleted skeleton particles that were mostly used to deliver TG as VLDL
- For someone like Craig Moffitt, his LDL-C was 335 mg/dL, where is the extra cholesterol coming from?
- Dave believes it’s being recycled
- Peter asks where is Moffitt deficient in cholesterol where someone with an LDL-C of 100 mg/dL is not — in other words, is he pulling more cholesterol from his cell membranes for example?
- So, he has more cholesterol in his body, Peter says

**Note from Tom Dayspring**: *Serum LDL-C has no relationship to body cellular cholesterol.*

- Dave believes that the demand for the delivery of the triglycerides is driving the demand for more VLDLs, which can become cholesterol-containing LDLs
- Peter argues that looking at mass balance, the only way he can reconcile the hypothesis is if he’s making more cholesterol
- Dave thinks he’s recycling the same cholesterol, and he’s making more cholesterol relative to someone who doesn’t — the liver can recycle cholesterol as many times as it wants to, as Dave understands it

**Note from Tom Dayspring**: *The liver has a lot of options*, *but physiology demands when the liver has excess cholesterol it must excrete it in the bile as FC or bile acid.*

- Peter asks Dave where is there so much extra LDL-C coming from LDL particles in lean mass hyper-responders?
- Dave thinks that the amount of LDL-C is going to be relatively standard on a per particle basis in healthy individuals, so he wouldn’t expect to see discordance between the two (i.e., a high particle concentration and a low cholesterol amount)
- Dave believes the secretion level tends to be fairly standard

**Note from Tom Dayspring**: *The secretion level is not fairly standard.*

## Peter’s LDL during his keto-fast-keto experiment [2:13:30]

- Peter did a week of a ketogenic diet, followed by a week of fasting, followed by a week of ketosis, purely anecdote, Peter says
- Peter’s LDL-P went up after one week of ketosis
- Peter’s LDL-C went from 64 to 37 after the one-week fast
- The general principle seems to be under caloric deprivation, LDL goes down and under fat deprivation, LDL goes down, Peter says
- Dave adds a footnote: he wonders if the weight training impacted LDL numbers

**Peter’s keto-fast-keto experiment**: [AMA #2: the Nothingburger — results from Peter’s week-long fast between two weeks of nutritional ketosis — and answering questions on all things fasting](https://peterattiamd.com/ama02/) (EP.11) | Peter Attia (peterattiamd.com) [2:13:15]

## Does substituting saturated fats with monounsaturated fats lower LDL-P and LDL-C? [2:15:45]

- In Peter’s patients, when patients are on a high-fat diet, the ones that go on to have a hyper-response, TGs go down, TC goes through the roof, and there’s a 2-3x+ greater output of synthetic biomarkers like desmosterol

**Note from Tom Dayspring**: *There are two main cholesterol synthesis pathways: lathosterol and/or desmosterol.*

- He also tends to see at least two of their three phytosterols go up.
- This seems reversible, if you reduce saturated fat (SFA) to <25-30 g/day
- Peter [wrote a blog post](https://peterattiamd.com/random-finding-plus-pi/) about the patient lowering SFA from about 100 g/d to an average of 25 g/d
- “His LDL-P fell from >3,500 nmol/L to about 1,300 nmol/L (about 55th percentile), and his CRP fell from 2.9 mg/L to <0.3 mg/L (and for the lipoprotein cognoscenti, both desmosterol and cholestanol fell)”
- Peter’s hypothesis was that it was the saturated fat, not the ketones, driving more cholesterol synthesis, since the switch to MUFA didn’t impact his ketogenesis
- He was consuming more MUFA and PUFA
- The downside to adding more PUFA is the potential that it’s adding more peroxidation on the particle basis, Dave says

**Peter’s blog post including his patient lowering SFA on a ketogenic diet**: [Random finding (plus pi)](https://peterattiamd.com/random-finding-plus-pi/) | Peter Attia (peterattiamd.com) [2:16:00]

## Dave’s carb-swap experiments [2:22:15]

- Why would the body be so adamant about mobilizing triglycerides for fuel in a LCHF athlete, especially somebody is very lean? Dave asks
- Dave did carb-swap experiments, where he added carbohydrates to his diet to increase his glycogen stores, and his hypothesis was it would result in less VLDL secretion, and therefore less LDL
- There are very little glycogen stores on LCHF relative to a high-carb diet
- Dave switched back to the high-fat diet for the next five days, and saw LDL-C drop, and continued to remain low for the next five days, and it got to the lowest point at the end (Figure 23)

![](https://peterattiamd.com/wp-content/uploads/2018/10/energy-status-experiment.png)

**Figure 23. Dave’s energy status experiment.**Image credit: Dave Feldman

**Dave’s energy status experiment**: [Energy Status Experiment](https://cholesterolcode.com/energy-status-experiment/) | Dave Feldman (cholesterolcode.com) [2:25:30]

## Dave’s carotid intima-media thickness tests [2:41:15]

- Dave was getting a carotid intima-media test (CIMT) every six months
- And during those six months, the beginning of this diet, and through the experimentation, his LDL-C was 200 or higher, LDL-P levels of 2,000 or higher
- For four tests in a row, there was a regression on both the left and right side of the carotid arteries (Figure 24)
- Important to use the same technician and perform the test in exactly the same way when doing CIMT, Peter notes
- From a cardiovascular standpoint, Peter doesn’t think there is a single good reason to have high LDL

![](https://peterattiamd.com/wp-content/uploads/2018/10/cimt-with-ldlc-ldlp.png)

**Figure 24. Dave’s CIMT results.** Image credit: Dave Feldman [2:41:15]

**Dave’s CIMT update**: [Carotid Artery Update, SAD Diet Edition](https://cholesterolcode.com/carotid-artery-update-sad-diet-edition/) | Dave Feldman (cholesterolcode.com) [2:40:30]

## Looking for studies that stratify for high HDL-C and low TG alongside low and high LDL-C [2:53:00]

- Dave is looking for any datasets that can demonstrate that people with high HDL-C, low TGs, and high LDL-C (and high LDL-P, if available) are at increased risk for CVD
- Framingham Offspring study: they stratified for high HDL-C and low TG, and found the associated risk for people with LDL-C > 130, and with high HDL-C and low TG, their risk was the same as people with an LDL-C < 100 (Table 2)
- One study (Copenhagen Heart Study) where they stratified discreetly between below 170 LDL-C and above 170 LDL-C (Figure 25)
- And the high HDL, low triglyceride group, when compared to above and below, were nearly identical, both on the high side and on the low side (Figure 25)

**Table 2. Framingham Offspring Study: Effect sizes of Low HDL-C and High HDL-C in conjunction with varying levels of TG and LDL-C.** Image credit: Bartlett et al., 2016 [2:56:00]

![](https://peterattiamd.com/wp-content/uploads/2018/10/bartlett-framingham-table-2-hdl-ldl-tg.png)

![](images/davefeldman/jeppesen-ihd-copenhagen-hdl-ldl-tg-fig.png)

**Figure 25. Copenhagen Male Study: Incidence of ischemic heart disease (IHD) according to lipid categories and smoking status.** *P* value represents statistical significance between the two groups. Image credit: Jeppesen et al., 2001 [2:56:00]

- Unfortunately, these studies didn’t stratify by apoB, Peter says
- Peter’s not convinced that the null hypothesis should be anything other than the lipid hypothesis
- What Peter means is the “no bullshit”*LDL hypothesis*, the lipoprotein concentration, the endothelial damage, and the inflammatory changes, all of these things cascading, this is the null hypothesis
- In the end, if there’s data to counter that, Peter’s all for it

![](https://peterattiamd.com/wp-content/uploads/2018/10/MESA-LDL-P-vs-LDL-C-4-groups.jpg)

**Figure 26. Cumulative incidence of cardiovascular events in subgroups with low LDL-C and/or low LDL-P, from proportional hazards models adjusted for age and gender. Low LDL-C and LDL-P values were defined as < 100 mg/dL and <1060 nmol/L, respectively (<30th percentile).** From: [Otvos et al., 2011](https://www.ncbi.nlm.nih.gov/pubmed/21392724)

**Framingham Offspring Study**: [Is Isolated Low High-Density Lipoprotein Cholesterol a Cardiovascular Disease Risk Factor? New Insights From the Framingham Offspring Study](https://www.ncbi.nlm.nih.gov/pubmed/27166203) (Bartlett et al., 2016) [2:56:00]

**Copenhagen male study stratifying for high HDL-C and low TG**: [Low triglycerides-high high-density lipoprotein cholesterol and risk of ischemic heart disease](https://www.ncbi.nlm.nih.gov/pubmed/11176761) (Jeppesen et al., 2001) [1:51:30, 2:56:00]

**Discordance between LDL-P and LDL-C**: [Clinical Implications of Discordance Between LDL Cholesterol and LDL Particle Number](https://www.ncbi.nlm.nih.gov/pubmed/21392724) (Otvos et al., 2011) [2:58:00]

§

§

## Selected Links / Related Material

- **Low Carb conference Dave attended in San Diego**: [Low Carb USA: San Diego 2018](https://www.lowcarbusa.org/low-carb-events/past-events/san-diego-2018/) (lowcarbusa.org) [11:45]
- **Peter’s blog series on cholesterol**: [Straight dope on cholesterol — Part I](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-i/) | Peter Attia (peterattiamd.com) [15:15]
- **Podcast with Dave Feldman as guest**: [BH020: Cholesterol — Understanding How the Body Uses It and Are High LDL Levels Really Dangerous? With  Dave Feldman](https://drbretscher.libsyn.com/bh020-cholesterol-understanding-how-the-body-uses-it-and-are-high-ldl-levels-really-dangerous-with-dave-feldman) | Bret Scher (lowcarbcardiologist.com) [17:45]
- **Podcast with Dave Feldman as guest**: [BH024: Dave Feldman of CholesterolCode.com- Part 2 To Help Us All #RethinkLDL](https://drbretscher.libsyn.com/ep024-dave-feldman-of-cholesterolcodecom-part-2-on-why-a-mixed-diet-potentially-increases-ldl-cholesterol) | Bret Scher (lowcarbcardiologist.com) [17:45]
- **Podcast with Dave Feldman as guest**: [LCCP036: Dave Feldman Challenges Everything We Think We Know About LDL Cholesterol](https://drbretscher.libsyn.com/dave-feldman-challenges-everything-we-think-we-know-about-ldl-cholesterol) | Bret Scher (lowcarbcardiologist.com) [17:45]
- **Podcast with Dave Feldman as guest**: [Episode 400 – Dave Feldman – Cholesterol and Lipoproteins](https://robbwolf.com/2018/07/03/episode-400-dave-feldman-cholesterol-and-lipoproteins/) | Robb Wolf (robbwolf.com) [17:45]
- **Podcast with Dave Feldman as guest**: [How to Drop Your Cholesterol with Dave Feldman](https://www.nourishbalancethrive.com/podcasts/nourish-balance-thrive/how-drop-your-cholesterol/) | Nourish Balance Thrive (nourishbalancethrive.com) [17:45]
- **Case of elevated LDL-C and LDL-P on a low-carb diet**: [Lipidaholics Anonymous Case 291 Can losing weight worsen lipids?](https://www.dropbox.com/s/1fbzojwm4lytjss/Dayspring%20-%20Lipidaholics%20Case%20291%20-%20Can%20losing%20weight%20worsen%20lipids%3F.pdf?dl=0) | Tom Dayspring (PDF) [20:30; 1:36:15]
- **Clinical Lipidology book Dave read**: [Clinical Lipidology](https://www.google.com/url?q=https://www.amazon.com/Clinical-Lipidology-Companion-Braunwalds-Disease/dp/1416054693&sa=D&ust=1538669750009000&usg=AFQjCNGm8iMH6wpP9fOMHVy_Q85fD1kMbQ) edited by Christie Ballantyne [33:15]
- **About 38% of plasma LDL is secreted directly in normolipidemic individuals compared with 27% in hypertriglyceridemia**: [The crucial roles of apolipoproteins E and C-III in apoB lipoprotein metabolism in normolipidemia and hypertriglyceridemia](https://www.ncbi.nlm.nih.gov/pubmed/25551803) (Sacks, 2015) [40:15]
- **Ron Krauss on the half-life of LDL**: [Ron Krauss, M.D.: a deep dive into heart disease (EP.03)](https://peterattiamd.com/ronkrauss/) | Peter Attia (peterattiamd.com) [45:30]
- **Half-life of LDL**: [Metabolism of apoB and apoC lipoproteins in man: kinetic studies in normal and hyperlipoproteinemic subjects](https://www.ncbi.nlm.nih.gov/pubmed/202659) (Berman et al., 1978) [47:00]
- **Company dedicated to reversing Type 2 diabetes**: [Virta Health](https://www.virtahealth.com/) | ([virtahealth.com](https://www.virtahealth.com/)) [48:30]
- **Dave’s blog**: [Cholesterol Code](https://cholesterolcode.com/) | ([cholesterolcode.com](https://cholesterolcode.com)) [48:30]
- **Dave’s article about lean mass hyper-responders**: [Are you a Lean Mass Hyper-responder?](https://cholesterolcode.com/are-you-a-lean-mass-hyper-responder/) | David Feldman ([cholesterolcode.com](https://cholesterolcode.com)) [49:30]
- **Podcast with Rhonda**: [Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more (EP.02)](https://peterattiamd.com/rhondapatrick/) | Peter Attia (peterattiamd.com) [51:00]
- **Pathology textbook**: [Atlas of Atherosclerosis Progression and Regression](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?ie=UTF8&qid=1526578233&sr=8-1&keywords=stary+atherosclerosis) by Herbert C. Stary [53:15]
- **Stages of atherosclerosis**: [A Definition of Advanced Types of Atherosclerotic Lesions and a Histological Classification of Atherosclerosis](https://www.ahajournals.org/doi/abs/10.1161/01.cir.92.5.1355) (Stary et al., 1995) [53:15]
- **One of Peter’s post on the progression of atherosclerosis**: [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/) | Peter Attia (peterattiamd.com) [53:15]
- **Reference Dave provided on LDL-delivered a-tocopherol studies**: Vitamin E: Mechanism of Its Antioxidant Activity (Yamauchi, 1997) [56:45]
- **Reference Dave provided on LDL-delivered a-tocopherol studies**: [The chemistry and antioxidant properties of tocopherols and tocotrienols](https://www.ncbi.nlm.nih.gov/pubmed/8827691) (Kamal-Eldin and Appelqvist, 1996) [56:45]
- **Reference Dave provided on LDL-delivered a-tocopherol studies**: [Vitamin E Inadequacy in Humans: Causes and Consequences](https://academic.oup.com/advances/article-abstract/5/5/503/4565757) (Traber, 2014) [56:45}
- **Nerd Safari post on statistical power**: [Studying Studies: Part V – power and significance](https://peterattiamd.com/nerd-safari/studying-studies-part-v-power-and-significance/) | Peter Attia (peterattiamd.com) [1:02:00]
- **All-cause mortality paper Dave mentioned**: [Should a Reduction in All-Cause Mortality Be the Goal When Assessing Preventive Medical Therapies?](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.116.023359) (Sasieni and Wald, 2017) [1:02:00]
- **Peter’s magic wand Gedanken experiment**: [The straight dope on cholesterol — Part VI](https://peterattiamd.com/the-straight-dope-on-cholesterol-part-vi/) | Peter Attia (peterattiamd.com) [1:02:00]
- **Peter’s favorite beverage**: [Topo Chico](https://www.topochicousa.net/) | ([topochicousa.com](https://www.topochicousa.net/)) [1:03:30]
- **FOURIER trial looking at PCSK9 inhibitors**: [Evolocumab and Clinical Outcomes in Patients with Cardiovascular Disease](https://www.ncbi.nlm.nih.gov/pubmed/28304224) (Sabatine et al., 2017) [1:03:30]
- **ODYSSEY trial looking at PCSK9 inhibitors**: [Efficacy and Safety of Alirocumab in Reducing Lipids and Cardiovascular Events](https://www.ncbi.nlm.nih.gov/pubmed/25773378) (Robinson et al., 2015) [1:03:30]
- **ODYSSEY trial looking at PCSK9 inhibitors**: [The ODYSSEY Trial Ends Well— But Will It Be Enough?](https://www.cardiobrief.org/2018/03/10/the-odyssey-trial-ends-well-but-is-it-enough/) (2018) | Larry Husten (cardiobrief.org) [1:03:30]
- **Allan Sniderman’s lifetime exposure model**: [The causal exposure model of vascular disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3244267/) (Sniderman et al., 2012) [1:04:45]
- **Tool used for understanding LDL’s causality**: [Mendelian Randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) | ([wikipedia.org](https://www.wikipedia.org/)) [1:05:30]
- **Drug that lowers plasma cholesterol levels**: [Zetia](https://en.wikipedia.org/wiki/Ezetimibe) | ([wikipedia.org](https://www.wikipedia.org/)) [1:09:15]
- **Recently approved PCSK9 inhibitors** [1:09:30]:
  - [Repatha](https://en.wikipedia.org/wiki/Evolocumab) | ([wikipedia.org](https://www.wikipedia.org/))
  - [Praluent](https://en.wikipedia.org/wiki/Alirocumab) | ([wikipedia.org](https://www.wikipedia.org/))
- ***APOC3* variant and relationship with longevity, from Nir Barzilai’s group**: Lipoprotein genotype and conserved pathway for exceptional longevity in humans (Atzmon et al., 2006) [1:12:30]
- **Nir Barzilai discussing two genetic variants (*APOC3* and *CETP*) involved in lipoprotein metabolism and their relationship to longevity**: [Longevity Genes (1 of 5): Nir Barzilai, M.D.](https://www.youtube.com/watch?v=wnMmtr2uAcM) | Albert Einstein College of Medicine (youtube.com) [1:12:30]
- **Dave’s pinned Tweet requesting studies that stratify for high HDL-C and low TG**: [Dave Feldman on Twitter](https://twitter.com/DaveKeto/status/1029365733132722176) (@DaveKeto) [1:13:00]
- **Consensus panel paper including genetic studies (Mendelian randomization)**: [Low-density lipoproteins cause atherosclerotic cardiovascular disease. 1. Evidence from genetic, epidemiologic, and clinical studies. A consensus statement from the European Atherosclerosis Society Consensus Panel](https://www.ncbi.nlm.nih.gov/pubmed/28444290) (Ference et al., 2017)
- **Critical review of the consensus paper**: [A Critical Review of the Consensus Statement from the European Atherosclerosis Society Consensus Panel 2017](https://www.karger.com/Article/FullText/486374) (Okuyama et al., 2018)
- **Podcast with Dave Feldman discussing soft and hard endpoints(that Peter disagrees with)**: [LCCP036: Dave Feldman Challenges Everything We Think We Know About LDL Cholesterol](https://drbretscher.libsyn.com/dave-feldman-challenges-everything-we-think-we-know-about-ldl-cholesterol) | Bret Scher (lowcarbcardiologist.com) [1:21:15]
- **Statins may increase the risk of diabetes, especially in women (about 10% of the population taking statins, 30% for women) according to Ron Krauss**: [Ron Krauss, M.D.: a deep dive into heart disease (EP.03)](https://peterattiamd.com/ronkrauss/) | Peter Attia (peterattiamd.com) [1:23:20]
- **Plausibility of Alzheimer’s disease in patients with overly suppressed cholesterol synthesis**: [Loss of astrocyte cholesterol synthesis disrupts neuronal function and alters whole-body metabolism](https://www.ncbi.nlm.nih.gov/pubmed/28096339) (Ferris et al., 2017) [1:24:45]
- **Plausibility of Alzheimer’s disease in patients with overly suppressed cholesterol synthesis**: [Identification of a new plasma biomarker of Alzheimer’s disease using metabolomics technology](https://www.ncbi.nlm.nih.gov/pubmed/22203775) (Sato et al., 2012) [1:24:45]
- **Plausibility of Alzheimer’s disease in patients with overly suppressed cholesterol synthesis**: [Alzheimer’s Disease: Brain Desmosterol Levels](https://www.ncbi.nlm.nih.gov/pubmed/23042211) (Wisniewski et al., 2013) [1:24:45]
- **Friedewald Equation**: [Comparison of a Novel Method vs the Friedewald Equation for Estimating Low-Density Lipoprotein Cholesterol Levels From the Standard Lipid Profile?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4226221/) (Martin et al., 2013) [1:30:00]
- **Hypertriglyceridemia and hypercholesterolemia that gets corrected after treating diabetic ketoacidosis**: [Severe Hypertriglyceridemia in Diabetic Ketoacidosis Accompanied by Acute Pancreatitis: Case Report](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2923793/) (Hahn et al., 2010) [1:35:30]
- **Hypertriglyceridemia and hypercholesterolemia that gets corrected after treating diabetic ketoacidosis**: [Severe hypertriglyceridemia in diabetic ketosis](https://www.ncbi.nlm.nih.gov/pubmed/2124781) (Fulop and Eder, 1990) [1:35:30]
- **Hypertriglyceridemia and hypercholesterolemia that gets corrected after treating diabetic ketoacidosis**: [Plasma triglycerides and cholesterol in diabetic ketosis](https://www.ncbi.nlm.nih.gov/pubmed/2505705) (Fulop and Eder, 1989) [1:35:30]
- **Dave’s self-experiment with exercise and lipoprotein response**: [Resistance Training Experiment – Findings – Part I](https://cholesterolcode.com/resistance-training-experiment-findings-part-1/) | Dave Feldman ([cholesterolcode.com](https://cholesterolcode.com)) [1:38:00]
- **Ketogenic dieters who also weight train**: [Ketogains](https://ketogains.com/) | ([ketogains.com](https://ketogains.com/)) [1:38:30]
- **Garvey’s data**: [Effects of insulin resistance and type 2 diabetes on lipoprotein subclass particle size and concentration determined by nuclear magnetic resonance](https://www.ncbi.nlm.nih.gov/pubmed/12540621) (Garvey et al., 2003) [1:41:30, 1:49:15, 2:27:15, 2:46:30]
- **Framingham Offspring study stratifying for high HDL-C and low TG**: [Low triglycerides-high high-density lipoprotein cholesterol and risk of ischemic heart disease](https://www.ncbi.nlm.nih.gov/pubmed/11176761) (Jeppesen et al., 2001) [1:51:30, 2:56:00]
- **Fat flux**: [How to make a fat cell less not thin: the lessons of fat flux](https://peterattiamd.com/how-to-make-a-fat-cell-less-not-thin-the-lessons-of-fat-flux/) | Peter Attia (peterattiamd.com) [1:59:00]
- **Friedman on liver and hunger**: [The physiological psychology of hunger: A physiological perspective](https://www.ncbi.nlm.nih.gov/pubmed/1005583) (Friedman and Stricker, 1976) [2:05:15]
- **Friedman on liver and hunger**: [Integrated metabolic control of food intake](https://www.ncbi.nlm.nih.gov/pubmed/3801940) (Friedman et al., 1986) [2:05:15]
- **Friedman 2008 chapter on the Energostatic Model**: [Control, Regulation, and the Illusion of Dysregulation](https://sandbaronfalseriver.com/epub/download/id=499409&type=file) (Friedman, 2008) (PDF) [2:05:15]
- **Peter’s keto-fasting-keto protocol**: [AMA #2: the Nothingburger — results from Peter’s week-long fast between two weeks of nutritional ketosis — and answering questions on all things fasting (EP.11)](https://peterattiamd.com/ama02/) | Peter Attia (peterattiamd.com) [2:13:15]
- **Peter’s blog post including his patient lowering SFA on a ketogenic diet**: [Random finding (plus pi)](https://peterattiamd.com/random-finding-plus-pi/) | Peter Attia (peterattiamd.com) [2:16:00]
- **Dave’s energy status experiment**: [Energy Status Experiment](https://cholesterolcode.com/energy-status-experiment/) | Dave Feldman (cholesterolcode.com) [2:25:30]
- **Dave’s CIMT updat**e: [Carotid Artery Update, SAD Diet Edition](https://cholesterolcode.com/carotid-artery-update-sad-diet-edition/) | Dave Feldman (cholesterolcode.com) [2:40:30]
- **People with Gilbert’s syndrome have a lower risk of cardiovascular disease**: [Gilbert’s syndrome: Cardiovascular effects](https://en.wikipedia.org/wiki/Gilbert%27s_syndrome#Cardiovascular_effects) | ([wikipedia.org](https://www.wikipedia.org/)) [2:50:15]
- **Company that will test your DNA for ancestry, traits, and genetic health risks**: [23andMe](https://www.23andme.com/?myg=true) | ([23andme.com](https://www.23andme.com/?myg=true)) [2:53:30]
- **Quebec Heart Study**: [Low-density lipoprotein subfractions and the long-term risk of ischemic heart disease in men: 13-year follow-up data from the Québec Cardiovascular Study](https://www.ncbi.nlm.nih.gov/pubmed/15618542) (St-Pierre et al., 2005) [2:56:00]
- **IL-1β agonists and CVD**: [Antiinflammatory Therapy with Canakinumab for Atherosclerotic Disease](https://www.ncbi.nlm.nih.gov/pubmed/28845751) (Ridker et al., 2017) [3:04:15]
- **IL-1β agonists and CVD**: [CANTOS Validates Role Of Inflammation In Heart Disease](https://www.cardiobrief.org/2017/08/27/cantos-validates-role-of-inflammation-in-heart-disease/) | (cardiobrief.org) [3:04:15]
- **Low-dose methotrexate and cardiac events**: [Cardiovascular Inflammation Reduction Trial (CIRT)](https://clinicaltrials.gov/ct2/show/NCT01594333) | (clinicaltrials.gov) [3:04:15]
- **Low-dose methotrexate and cardiac events**: [Methotrexate and Cardiovascular Protection: Current Evidence and Future Directions](https://journals.sagepub.com/doi/full/10.1177/1179559X17741289) (Mangoni et al., 2017) [3:04:15]
- **Low-dose methotrexate and cardiac events**: [NIH Halts Large Cardiovascular Inflammation Reduction (CIRT) Trial](https://www.cardiobrief.org/2018/05/21/nih-halts-large-cardiovascular-inflammation-reduction-cirt-trial/) | (cardiobrief.org) [3:04:15]
- **Organization looking to enhance the practice of lipid management**: [National Lipid Association](https://www.lipid.org/) | (lipid.org) [3:05:30]

§

§

## People Mentioned

- [Tom Dayspring](https://twitter.com/drlipid?lang=en) [9:30, 20:00, 33:00, 40:30, 1:12:30, 1:35:15, 2:18:15]
- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) (cholesterol) [24:15, 2:29:15]
- [Tara Dall](https://www.taradall.com/) (Dave read up on her work) [33:00]
- [Frank Sacks](https://www.hsph.harvard.edu/frank-sacks/) (de novo LDL) [40:30]
- [Ron Krauss](https://www.chori.org/Principal_Investigators/Krauss_Ronald/krauss_overview.html) (half-life of LDL) [25:30, 2:37:30]
- [Michael Brown](https://en.wikipedia.org/wiki/Michael_Stuart_Brown) (Brown and Goldstein, kinetics of LDL) [46:00]
- [Joseph L. Goldstein](https://en.wikipedia.org/wiki/Joseph_L._Goldstein) (Brown and Goldstein, kinetics of LDL) [46:00]
- [Rhonda Patrick](https://twitter.com/foundmyfitness?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (previous podcast guest on [The Drive](https://peterattiamd.com/podcast/)) [51:00]
- [Allan Sniderman](https://www.cardiomuhc.ca/allan-sniderman) (lifetime exposure model) [1:04:30]
- [Craig Moffitt](https://twitter.com/tigriscraig) (Endurance runner and case study of a LMHR) [1:31:30, 1:55:30]
- [Mark Friedman](https://www.monell.org/faculty/people/mark_friedman) (work with liver and appetite) [2:00:45]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/10/dave-feldman-photo-image-300x300.jpg)

##### Dave Feldman

I’m a senior software engineer and entrepreneur.

I began a Low Carb, High Fat diet in April 2015 and have since learned everything I could about it with special emphasis on cholesterol given my lipid numbers spiked substantially after going on the diet. As an engineer, I spotted a pattern in the lipid system that’s very similar to distributed objects in networks.

I’ve since learned quite a bit on the subject both through research and experimentation which has revealed some very powerful data. With this new general theory, I’ve shifted around my cholesterol more than anyone else in the world without any drugs or special supplements of any kind. [[cholesterolcode.com](https://cholesterolcode.com/about/)]

Dave on YouTube: [Dave Feldman](https://www.youtube.com/channel/UComIr_SYmKrR6PbX2AezIJg)

Dave on Instagram: [@davefeldmanketo](https://www.instagram.com/davefeldmanketo/)

Dave on Facebook: [@DaveFeldmanLC](https://www.facebook.com/DaveFeldmanLC/)

Dave on Twitter: [@DaveKeto](https://twitter.com/DaveKeto?lang=en)