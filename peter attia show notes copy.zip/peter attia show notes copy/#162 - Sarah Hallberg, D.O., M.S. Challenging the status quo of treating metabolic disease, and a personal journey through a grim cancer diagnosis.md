# #162 – Sarah Hallberg, D.O., M.S.: Challenging the status quo of treating metabolic disease, and a personal journey through a grim cancer diagnosis

**Source:** [https://peterattiamd.com/sarahhallberg/](https://peterattiamd.com/sarahhallberg/)

---

##### Note to listener: It’s with great sadness that we report that Sarah recently lost her battle with lung cancer. As such we’ve decided to republish her episode on April 3, 2022 to honor her, her amazing work, and her courageous cancer journey.

Sarah Hallberg was the Medical Director at Virta Health and a physician who spent nearly two decades treating patients with obesity and type 2 diabetes.

In the first half of this episode, Sarah discusses how she became a huge believer in the efficacy of carbohydrate restriction for the treatment of type 2 diabetes through her research and clinical experience. Sarah challenges the common beliefs about the role of dietary fat and carbohydrate on the plasma makeup of fatty acids and triglycerides. She also expresses the importance of understanding early predictors of metabolic illness—highlighting one particular fatty acid as the most important early predictor—before finishing with a discussion about how doctors might be able to personalize patients’ metabolic management in the future.

In the second half of this episode, Sarah tells the personal story of her own lung cancer diagnosis ([skip to the second part of her episode on youtube here](https://www.youtube.com/watch?v=O_Eni8qYMlY)). She talks about dealing with her grief, deciding to continue her work while prioritizing her family, and how she devised a plan to extend her survival as long as possible.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/sarahhallberg/the_Drive_public.png)

Play

#162 - Sarah Hallberg, D.O., M.S.: Challenging the status quo of treating metabolic disease, and a personal journey through a grim cancer diagnosis

#162 - Sarah Hallberg, D.O., M.S.: Challenging the status quo of treating metabolic disease, and a personal journey through a grim cancer diagnosis

1x15s30s

0:002:21:28

## We discuss:

- How Sarah discovered the profound impact of carbohydrate restriction for reversing obesity and type 2 diabetes [3:15];
- Prediabetes and metabolic syndrome: prevalence, early signs, and the importance of treating early [16:00];
- Overview of fatty acids, how they are metabolized, and understanding what you see in a standard blood panel [29:15];
- The relationship between diet composition and metabolic markers [35:15];
- Why palmitoleic acid is such an important biomarker [48:15];
- The best early indicators of metabolic disease [1:00:00];
- Personalized management of metabolic illness [1:07:00];
- Sarah’s cancer diagnosis and the beginning of her journey [1:15:15];
- The emotional impact of a devastating diagnosis [1:27:15];
- Sarah’s plan to extend survival [1:36:45];
- Sarah’s aggressive treatment plan [1:47:30];
- Life-threatening complications and the return of her cancer [1:59:00];
- Sarah’s reflections on her approach to life with chronic cancer and balancing her time [2:11:00]; and
- More.

§

## Show Notes

## How Sarah discovered the profound impact of carbohydrate restriction for reversing obesity and type 2 diabetes [3:15]

**High-fat, low-carbohydrate diet for metabolic health**

- Some people fear that a low carb, high fat diet will lead to increased insulin resistance and eventually cardiovascular disease
  - But a therapeutic, carbohydrate-restricted diet can reduce cardiovascular (CV) risk factors including triglycerides (TGs), improve glycemic control, and even reverse type 2 diabetes (T2DM) in most cases
  - Consuming fatty acids (FAs) in the context of a carb-restricted diet shows that the old saying “you are what you eat” is not accurate
- FAs can be confusing to understand, but play an important role in both cardiovascular and diabetes risk

*What led Sarah to focus on the management of diabetes?*

- Peter and Sarah met through a company called [Virta Health](https://www.virtahealth.com/), in which Peter is an investor and former advisor
- Sarah has been treating obese patients for more than 25 years, never would have thought her career would take this direction
  - Like others trained in the 1980s, Sarah learned in undergrad/master’s in exercise physiology and in med school the best way to address obesity was to eat a low calorie, low fat diet
  - But Sarah watched her patients become worse trying to follow this advice
  - She felt discouraged about primary care because she “felt like a legal drug dealer”
- Sarah says a lot of the pivots in her career were motivated by anger, “and I was really angry at what was happening on the primary care level”
- Indiana University Health asked her to start an obesity program
  - She was able to take time off to study the literature, which docs rarely have time to do
  - Listened to lectures by [Dr. Steve Phinney](https://www.ifm.org/about/profile/stephen-phinney-md-phd/) and [Jeff Volek](https://www.virtahealth.com/people/jeff-volek)

> “I came to the conclusion … that what I had been saying for well over a decade to so many people was really not founded on good science and that the field of carbohydrate restriction, while still relatively in its infancy at the time, showed much more promise.” —Sarah Hallberg

**Sarah’s obesity clinic**

- She ended up opening the obesity clinic as a *carbohydrate restricted clinic*
  - Patients lost weight but more importantly found that their **diabetes was reversing**, with normal blood sugar levels
  - “*We were pulling them off of insulin at rates that I could never have believed had I not been the physician who was taking care of these patients. It was astronomical, hundreds of units of insulin*.”
  - Most clinic patients had some kind of metabolic disease and T2DM was the most common
- To get institutional support for the clinic, she gave presentations to all the departments in the med center explaining the scientific evidence behind carb restriction
  - Surprisingly, she got no pushback
  - even got fellow members of the ambulatory quality committee to unanimously pass an amendment saying that all patients with metabolic disease should at least be provided the option of trying a low carb diet

> “As we were seeing these huge changes of … patients just resolving their diabetes, I became really angry because I was like, ‘Where is this? Where’s this in the guidelines? How come I’ve never heard of this before?’ I mean, I hate to be overdramatic, but it truly is quite miraculous for a disease that everyone thought was chronic and progressive, to see people recover from it is quite astounding.” —Sarah Hallberg

**Early studies by Sarah**

- Conducted an early unfunded [study](https://www.lipidjournal.com/article/S1933-2874(15)00113-0/fulltext) of metabolic improvements with carb restriction
  - Also looked at economic advantages because not requiring medication saves money for both the individual and the healthcare system as a whole (expanded on in a [later paper](https://www.valueinhealthjournal.com/article/S1098-3015(18)30790-3/fulltext?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1098301518307903%3Fshowall%3Dtru))
- Sarah has discussed the results of her research at the [National Lipid Association](https://www.lipid.org/) and in a popular [TED Talk](https://www.youtube.com/watch?v=da1vvigy5tQ) that has been viewed more than 7 million times
- She met Steve Phinney at a meeting of the [Obesity Medicine Association](https://obesitymedicine.org/), which “really changed the course of my life”
  - Peter has been trying to get Steve on the podcast
  - Peter reached out to Steve when he began implementing some of the low carb principles
  - Peter had a pre-print copy of Steve and Jeff’s 2011 book [*The Art and Science of Low Carbohydrate Living*](https://www.amazon.com/Art-Science-Low-Carbohydrate-Living/dp/0983490708) (“which might have more highlights and post-its in it than any book I own”)
- Like Sarah, he kept thinking it couldn’t be true because it seems counterintuitive

## Prediabetes and metabolic syndrome: Prevalence, early signs, and the importance of treating early [16:00]

- At meetings of the [American Diabetes Association](https://www.diabetes.org/), Sarah found that doctors who treated patients for obesity understood her approach, but other specialists worried that it would cure diabetes but give the patient heart disease
  - Many doctors, including leaders, acknowledged it works but said patients could not stick with it, which was not what Sarah saw in her practice
  - Pioneering work of Steve and Jeff and [Eric Westman](https://medicine.duke.edu/faculty/eric-charles-westman-md) was valuable, but Sarah thought they needed large trials focused on patients with T2DM
  - She says T2DM patients should be the target because biggest impact on that population
- Sarah’s chance meeting with Steve at the Obesity Medicine Association led to funding for a large clinical trial that is just finishing now
  - Many papers have already come out of the trial, the [latest of which](https://pubmed.ncbi.nlm.nih.gov/33652715/) (on prediabetes) was published on the day of this this interview
  - Latest paper studied patients with prediabetes [defined as having a [hemoglobin A1c (HbA1c)](https://en.wikipedia.org/wiki/Glycated_hemoglobin) level of 5.7 to 6.4] who received remote continuous support to maintain a ketogenic diet for 2 years
  - Reach the prediabetes range when fasting glucose is over 110
  - But Sarah emphasizes that insulin resistance can cause significant problems in people who still have normal blood sugars
- In this study, subjects had insulin resistance long enough that their pancreas and the [β-cells](https://en.wikipedia.org/wiki/Beta_cell) could not make enough insulin to keep blood sugar normal, so and their blood sugar started to rise
  - Not yet to the T2DM level, but see the impact of insulin resistance as the pancreas has been overworked for far too long
- Around 10% of the U.S. population now has T2DM
  - much more concerning levels in different minority populations, which is a huge goal with improving health equity in this country
  - Level is “well into the teens” in Hispanic, African American, and Pacific Islander populations in US
- In Peter’s [podcast](https://peterattiamd.com/geraldshulman/) with [Gerry Shulman](https://medicine.yale.edu/profile/gerald_shulman/) about insulin resistance, they discussed the long-term course of diabetes
  - Can have normal fasting glucose and fasting insulin but elevated postprandial insulin, which is an early sign of insulin resistance than can lead to high postprandial glucose
  - By the time someone is labeled “prediabetic” the process has been going on for 5 to 10 years
- [More than 1/3](https://www.cdc.gov/diabetes/library/features/diabetes-stat-report.html) of Americans are either prediabetic or diabetic

> “*This should shock everyone to the core. … 88% of Americans are not in optimal metabolic health.*”

- This statistic comes from National Health and Nutrition Examination Survey ([NHANES](https://www.cdc.gov/nchs/nhanes/index.htm)) [data](https://www.liebertpub.com/doi/10.1089/met.2018.0105)
- It’s “frightening” that only 12% of Americans didn’t meet any of the criteria for metabolic syndrome

- Criteria for not having metabolic syndrome:
  - normal blood pressure without medication (< 130/80; in his practice Peter likes to see < 120/80)
  - normal fasting glucose (< 100)
  - normal triglycerides (< 150; in his practice Peter defines it as < 100)
  - normal HDL cholesterol (>40 mg/dL in men, > 50 in women)
  - no truncal obesity (< 40 inches waist circumference for men, < 36 for women)
- Sarah points out that we must take racial and ethnic differences into account when defining metabolic syndrome
  - Southeast Asians are defined as having metabolic syndrome at a much lower waist circumference
  - African Americans tend to have normal triglycerides and HDL even when they are insulin resistant
  - “We can’t be treating everybody the same, but we often do”
  - Peter remembers taking care of an African American patient with “the most uncontrolled diabetes I’d ever seen”
    - HbA1c 14%, TGs 89, close to needing limb amputation
    - But lipid panel was normal
  - “Knowing this and educating people on things like this again goes back to our working on health equities, and it’s so important and so often not something people take into account”

**Early signs and importance of treating early**

- Sarah says she is frustrated when patients’ labs show they are prediabetic but their primary doctors had told them they were fine
  - “we don’t appreciate that by the time you get to prediabetes, there’s some really serious things going on here” – affects vision, nerves, etc.
  - Must be dealt with long before they meet criteria for T2DM

“*If there are any physicians listening, … don’t ignore any elevation in blood sugar. That means there’s been a problem for a long time already*.” says Sarah

- Peter has male prediabetic patients who, after their blood glucose comes down by an average of 10 mg/dL, will say they have better erections
  - This shows that microvascular damage occurs long before you meet the criteria for diabetes
- Peter says HbA1c is far too crude a metric for metabolic disease
  - Looking at microvasculature in the eye might be a good screening tool for disease because it’s one of the earliest warning signs
  - Better to use an individualized metric rather than population-based guidelines that can be misleading in an individual
- Sarah says a key question is if can intervene at that early stage to make it better and allow patients to avoid diabetes-related eye disease

## Overview of fatty acids, how they are metabolized, and understanding what you see in a standard blood panel [29:15]

**Overview of fatty acids**

- Diving into the “nerdy” science of fatty acids, which Peter has [discussed on his podcast](https://peterattiamd.com/billharris/) many times before
  - *Saturated fats*: no double bonds, every carbon fully saturated with hydrogen
  - *Monounsaturated fats*: have one and only one double bond (un-saturation)
  - *Polyunsaturated fats*: at least two double bonds

![](https://peterattiamd.com/wp-content/uploads/2021/05/f1-hallberg-1024x657.png)

**Figure 1. Chemical Structures of fatty acid types**. Image credit: [Näak](https://naakbar.com/blogs/nutrition/lipids-in-naak-cricket-protein-bar)

**C16 saturated fat**

- What’s interesting is that you can ingest one form and turn it into another
- The PRC16 saturated fat [palmitoleic acid](https://en.wikipedia.org/wiki/Palmitoleic_acid) is a very common one in the human body
- Peter wants to discuss: *What is the fate of this very common fat found in our body?*

**Saturated fatty acids in general**

- When saturated FAs are incorporated into TGs, correlated with insulin resistance and adiposity (fat)
- Likely due to an increase in the liver making lipids on its own (*de novo* [lipogenesis](https://en.wikipedia.org/wiki/Lipogenesis)) and to an increasing amount of lipids coming back to the liver

![](https://peterattiamd.com/wp-content/uploads/2021/05/f2-hallberg-1024x471.png)

**Figure 2. Increased VLDL saturated FA content, insulin resistance, and** ***de novo*** **lipogenesis**. Image courtesy of Sarah Hallberg

- Seems like a high amount of saturated FAs in TGs would suggest an increase in saturated FA consumption

> “And this is the problem with a lot of things in science in general, and nutrition science is no different, is that just because it seems to make sense doesn’t mean it’s the way things actually work.” —Sarah Hallberg

***Peter clarifies a technical point…***

- In a standard blood panel, VLDL cholesterol, HDL cholesterol, and LDL cholesterol add up to the total cholesterol, but TGs are independent
- These amounts are all found **within the lipoproteins**:
  - VLDL cholesterol is the amount of cholesterol ester contained within the very low density lipoproteins,
  - LDL cholesterol is the total content of cholesterol ester **found within the low density lipoproteins**, etc.
  - Check these values after patient has **fasted** because we want to eliminate what’s in the chylomicron and the immediately absorbed triglyceride from the gut
- When we measure a triglyceride, for all intents and purposes, *we are basically measuring the 90% of triglycerides that are captured within the VLDL*
  - If your TGs are 150 mg/dL, 90% of that 150 mg/dL is within your VLDL cholesterol (small amount in virtually nonexistent IDLs and trace amounts in LDL and HDL)
  - When fat is made in the liver (*de novo* lipogenesis) and then exported, **the conduit is the VLDL particle**

## The relationship between diet composition and metabolic markers [35:15]

**The next important question**: *If there is a high saturated fatty acid content within the TGs in the VLDL, is it from consumption?*

**Looking at studies to help us answer this question**:

- In a [study](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0113605) by [Brittanie Volk](https://www.virtahealth.com/people/brittanie-volk), researchers provided all food to subjects with metabolic syndrome so they could keep track of exactly what they were eating
- Study had six feeding phases
  - first was < 50 g carbs/day with 84 g of saturated fat (which “blows away any guideline”)
  - Every three weeks they increased the carbohydrates in the diet
  - In 6th feeding phase, 346 g carbs/day with 32 g of saturated fat
  - Subjects ate the same amount of calories per day in each phase (isocaloric)

![](https://peterattiamd.com/wp-content/uploads/2021/05/f3-hallberg-1024x297.png)

**Figure 3. The six feeding phases used in the Volk study**. Image credit: [Volk et al. 2014](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0113605)

- Found that the saturated fatty acid content increased over the feeding phases
- It was actually higher with the lower saturated fat intake

![](https://peterattiamd.com/wp-content/uploads/2021/05/f4-hallberg-1024x739.png)

**Figure 4. Cumulative changes in (A) body mass and fat mass, (B) fasting lipoproteins, (C) insulin resistance, and (D) blood pressure in feeding phase study subjects.** Image credit: [Volk et al. 2014](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0113605)

![](https://peterattiamd.com/wp-content/uploads/2021/05/f5-hallberg-1024x783.png)

**Figure 5. Plasma fatty acid responses across feeding phases**. Image courtesy of Sarah Hallberg (adapted from [Volk et al. 2014](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0113605))

- The increases in C14 and C16-1 were [statistically significant](https://en.wikipedia.org/wiki/Statistical_significance)
- Did not have high levels of serum saturated fatty acids when these participants were consuming a high saturated fat diet
  - No increase – remained about the same with a trend to higher serum saturated fat in the low fat phase
  - You are NOT what you eat
  - Fatty acids are stored in the TGs, cholesterol esters, and phospholipids
  - Peter notes that “regardless of where you look, you see no association between dietary saturated fat and fatty acid composition with respect to saturated fat”
- C16-1 is palmitoleic acid, which significantly rises when there is less saturated fat and more carbohydrates (*refer to table above*)

**Another** [**trial**](https://pubmed.ncbi.nlm.nih.gov/18046594/) **in 2008 had similar results (41:45)**

- Composition of diets
  - Compared low saturated fat diet to a low carbohydrate, high saturated fat diet over 12 weeks
  - 12 g saturated fat a day vs. 36 g with the low carb diet
  - Both were restricted to ~1500 calories a day

![](https://peterattiamd.com/wp-content/uploads/2021/05/f6-hallberg-1024x683.png)

**Figure 6. Composition of diets in the 2008 study**. Image courtesy of Sarah Hallberg (based on data from [Forsythe et al. 2008](https://pubmed.ncbi.nlm.nih.gov/18046594/))

- Showed a significant decrease in saturated FAs with the low carb diet
  - Was also a drop in the low saturated fatty acid intake group
  - but not nearly as much of a drop as with the carbohydrate restricted group

![](https://peterattiamd.com/wp-content/uploads/2021/05/f7-hallberg.png)

**Figure 7. A low-carbohydrate, high-SFA diet decreases serum SFA levels**. Image courtesy of Sarah Hallberg (based on data from [Forsythe et al. 2008](https://pubmed.ncbi.nlm.nih.gov/18046594/))

- Palmitic vs. palmitoleic acid
  - Palmitic acid is C16:0
  - Palmitoleic is C16:1n-7
  - They look almost the same except that palmitoleic acid has a double bond at the end seven position
- Palmitoleic acid (16:1) is not a saturated FA, but it’s still important here
  - in the high saturated fatty acid group, it drops significantly, whereas in the low saturated fatty acid group, it actually increases
  - even more statistically significant than the change in the serum fatty acids

![](https://peterattiamd.com/wp-content/uploads/2021/05/f8-hallberg-1024x783.png)

**Figure 8. Palmitoleic acid decreases with a high SFA diet and increases with a low SFA diet**. Image courtesy of Sarah Hallberg (based on data from [Forsythe et al. 2008](https://pubmed.ncbi.nlm.nih.gov/18046594/))

- Looking at the results below (very low carbohydrate arm on the left and the low fat arm on the right):
  - total saturated fatty acids dropped 5% between the low carbohydrate group and the low fat group
  - between the low carbohydrate and low fat diets, a more significant decrease in palmitoleic acid with the low carbohydrate higher fat diet
  - both of these groups of patients started out with quite elevated triglycerides

![](https://peterattiamd.com/wp-content/uploads/2021/05/f9-hallberg-1024x651.png)

**Figure 9. Comparison of changes in SFA levels between a high-SFA and low-SFA diet**. Image courtesy of Sarah Hallberg (based on data from [Forsythe et al. 2008](https://pubmed.ncbi.nlm.nih.gov/18046594/))

- In the very low carbohydrate diet group:
  - average triglyceride at the start of this study was ~211 mg/dL (very high)
  - At the end of 12 weeks, decreased to ~104 mg/dL, so fell by about 50%
- In the low fat diet group:
  - average triglyceride at the start of this study was ~187 mg/dL (also very high)
  - At the end of 12 weeks, decreased to ~150 mg/dL, so fell by about 20%
- For 16.0:
  - both groups saw a slight reduction, but it was statistically more significant in one group than the other
  - The low carb group had a 12% reduction versus 5% in the low fat group
  - The difference was even greater because the low carb group also had a significant reduction in total TGs, where the FAs are
- The reverse was true for 16:1:
  - the low carbohydrate arm decreased more in the triglycerides
  - But the low fat arm decreased too even though we associate low fat with an increase in TGs
  - In this study the subjects’ diet was restricted to about ~1500 calories / day, so the drop in the low fat group makes sense in this context

## Why palmitoleic acid is such an important biomarker [48:15]

**The role of palmitoleic acid in fat metabolism**

- Palmitoleic acid (POA) is an important biomarker that’s “not appreciated as the health predictor that it really is”
  - it’s a product of stearoyl-CoA desaturase (SCD1), which controls what happens with some FAs
  - SCD1 is actually an independent marker of triglyceridemia and abdominal adiposity (things that go along with insulin resistance)
  - High levels of SCD1 activity are an early warning sign even if blood sugar is normal, which is important not to miss

> “It’s going to be really important … that we make everyone aware that a normal blood sugar doesn’t mean that you are healthy.” —Sarah Hallberg

- But can check other biomarkers as a sign of trouble before blood sugar goes up
  - The higher the POA, the higher the TGs
  - If TGs are really high, it’s very likely that POA is elevated as well due to increased activity of SCD1

![](https://peterattiamd.com/wp-content/uploads/2021/05/f10-hallberg-1024x834.png)

**Figure 10. Variation of plasma triglyceride across quartiles of palmitoleic acid levels**. Image credit: [Paillard et al. 2007](https://www.nmcd-journal.com/article/S0939-4753(07)00087-7/fulltext)

- One of the first steps in the conversion of fatty acids is the conversion of palmitic acid into palmitoleic acid
  - enzyme that converts it is SCD1 (also known as delta-9 desaturase because it de-saturates the number nine carbon from the delta end)
  - it is bundling and packaging fat to leave the liver

![](https://peterattiamd.com/wp-content/uploads/2021/05/f11-hallberg-1024x621.png)

**Figure 11. Structures of palmitic and palmitoleic acids**. Image credit: [Metagenics](https://slideplayer.com/slide/12644960/)

- Why is the body converting serum saturated fats into something else?
  - seems counterintuitive
  - saturated fat seems safer because it’s [inert](https://en.wikipedia.org/wiki/Chemically_inert), so there’s no chance a [reactive oxygen species](https://en.wikipedia.org/wiki/Reactive_oxygen_species) (ROS) can be formed out of it
  - why would the liver convert the fat before exporting it?
- Nutrition recommendations have been low fat and high carbohydrates for so long
- As carbs are absorbed in the intestine as glucose, feed into the pancreas through [glucose transporter 2](https://en.wikipedia.org/wiki/GLUT2) (GLUT2), and the pancreas produces more insulin
  - Insulin feeds into the liver via [SREBP-1](https://en.wikipedia.org/wiki/Sterol_regulatory_element-binding_protein_1), SCD1 increases
  - Fructose also comes in through [GLUT5](https://en.wikipedia.org/wiki/GLUT5), glucose through GLUT2
  - They’re all feeding into this by slightly different mechanisms to increase SCD1

![](https://peterattiamd.com/wp-content/uploads/2021/05/f12-hallberg-1024x777.png)

**Figure 12. Liver processing of carbohydrates**. Image credit: [University of Wisconsin-Madison Department of Biochemistry](https://biochem.wisc.edu/faculty/ntambi)

- Another way to look at it:
  - Have increased levels of palmitic acid in the liver
  - Get increased SCD1 activity, which increases POA and ultimately VLDL
  - If block SCD1, decrease POA and VLDL
- When you consume high carb diet, this pathway is activated, elevating saturated fat and ultimately VLDL
- If liver is taking in palmitic acid, first step is to go through SCD1, which adds a double bond
  - Ultimately increases lipogenesis
  - increasing the amount of lipid within cholesteryl ester and TG and exporting from the liver
  - Is protective in a sense because the liver is likely trying to export as much fat as it can and TGs are an efficient place to store it

![](https://peterattiamd.com/wp-content/uploads/2021/05/f13-hallberg-1024x587.png)

**Figure 13. The effect of SCD-1 on lipid metabolism**. Image courtesy of Sarah Hallberg (adapted from [Paton & Ntambi 2008](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2711665/#))

- When exceed export capacity of liver, develop [non-alcoholic fatty liver disease](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease) (NAFLD), which is “truly an epidemic at the moment”
- Peter believes that obesity is a **protective** mechanism: “I think that obesity is not the cause of metabolic illness, but the result of it”
  - Obesity-induced inflammation is a problem too
  - But Peter thinks that “everything we’re talking about here is the body’s aim to protect itself from an abundance of nutrition”
    - Liver is making too much extra fat because carb consumption exceeds the body’s tolerance
    - Most efficient response is to turn carbs into fat and send it via VLDL to the adipose tissue

## The best early indicators of metabolic disease [1:00:00]

- Sarah points out that, given this process, it would be ideal to know what each individual’s carb tolerance level is
  - Low carb works at population level, but want to tailor it to each individual
  - Increasing POA might be the marker that indicates when someone has consumed carbohydrates above their individual tolerance
- POA changes occur before someone becomes obese

> “It’s so important for other providers to be looking at themselves in the mirror and asking themselves, ‘What are the biases I hold against patients who come to me struggling with their weight? And what do I really know about the science?’ And what really one must conclude is that this is not their fault.” —Sarah Hallberg

- Obesity is a very visible consequence of things that already occurred
- It makes patients vulnerable to bias in healthcare and is part of our battle for health equity
- Peter says it’s really problematic that we’re using an HbA1c > 6.5 as the marker of when someone starts being closely followed medically
  - “that literally is happening 10, 15, maybe 20 years after there were early, early molecular warning signs”
  - We need to figure out how to use other, earlier markers like palmitoleic acid
- In Peter’s practice he uses continuous glucose monitoring (CGM) in non-diabetics to hold them to a very high standard
- The extent of the association between palmitoleic acid and TGs on African American patients is not well understood; we don’t know if they fail to synthesize C16-1 the way white patients do because there has not been a good trial

> “One of the problems that we have in research in general is that we tend to focus on white people. And actually, worse, middle or upper middle class white people. So there are a lot of questions with this in specific populations.” —Sarah Hallberg

- There are some studies coming out looking at POA as a predictor for future diabetes and other problems
  - A [paper](https://pubmed.ncbi.nlm.nih.gov/26892124/) from the Physical Activity and Nutrition in Children ([PANIC) study](https://www.panicstudy.fi/) looked at POA in children to see if it indicated future health problems
  - [Another study](https://pubmed.ncbi.nlm.nih.gov/18062827/#affiliation-1) found that POA levels at age 50 correlated with [C-reactive protein](https://en.wikipedia.org/wiki/C-reactive_protein) levels at age 70
  - Data show that POA is a predictor of future medical problems even in people who were healthy when their POA was elevated
- It’s obviously important to work with patients to help them reverse their disease, but would be even better to identify patients at high risk for future disease while they’re still healthy to help them stay that way

## Personalized management of metabolic illness [1:07:00]

**Peter’s approach**

- Peter says he thinks “the future of medicine has to be coming up with tools that allow us to take broad sweeping population-based insights and very quickly target individuals”
  - Use early biomarkers to figure out when to intervene even if glucose and insulin are still normal
  - The key is to figure out the right intervention for each individual patient
- Both Peter and Sarah have found that patients with hyperinsulinemia and elevated glucose generally respond well to carbohydrate restriction
  - In his practice, Peter focuses on the role of glucose disposal and non-insulin-dependent glucose disposal through exercise
  - Sleep, exercise, and nutrition are key, as is understanding the role of cortisol
- Peter says, “I think the good news is if you get this one right, you get a leg up on every chronic disease. So your risk of heart disease, cancer, Alzheimer’s disease, all go down. And so it’s worth this enormous effort to continue pushing on these questions”

**Sarah’s approach**

- Restricting carbs to low levels can reverse the disease process, restoring normal glycemia and getting patients off of medications
- But if widely use markers like POA, might not have to do as much restriction in some patients
  - It’s much better than telling everyone they have to eat very few carbs indefinitely
  - Sarah has seen patients who spent years on ketogenic / very low carbohydrate diets who were able to gradually re-introduce some amount of carbohydrate back in the diet without metabolic problems
  - After have reversed diabetes, can slowly reintroduce carbohydrates as long as they have functioning β-cells
- Are some β-cells only dormant while others are permanently destroyed?
  - We don’t completely understand this yet; seems like sometimes after a period of resetting the system can get functioning β-cells again
  - Would be ideal to be able to tell individuals how many dormant vs. dead β-cells they have to set realistic expectations (e.g., one will eventually get off insulin, another will not)
- Someone with no insulin production capacity can still get a lot healthier even if they can’t get off insulin
  - Not yet known why some people can start to eat some carbs again (though not anywhere near what they used to) and others cannot
  - but the answer seems to be related to β-cell function
- Peter thinks patients need to understand that insulin, “while an amazing and important hormone, is not benign”
  - Reducing the amount if insulin you need is always an improvement, even if you can’t come completely off of it
  - Even without considering economic advantages, still a huge advantage to reducing the negative effects of hyperinsulinemia
- Diabetes management leads to more and more insulin
  - People gain more weight when they go on more insulin
  - Need to tell patients that, although they need to take insulin to avoid complications, hospitalization, and death from too high blood sugar levels, they are more likely to die on insulin
- “That would have changed the approach a lot of patients want to take, and if providers were forced to look at it that way when they’re staring each individual person in the face, maybe they would treat it differently as well”

## Sarah’s cancer diagnosis and the beginning of her journey [1:15:15]

- Peter and Sarah met through Virta, a company which is scaling up a way to treat patients with T2DM remotely
  - Virta was founded by Steve Phinney, Jeff Volek, [and [Sami Inkinen](https://www.virtahealth.com/people/sami-inkinen)] in 2014
  - Sarah is the Medical Director at Virta and Peter is a small investor and at one point he was an advisor
  - About a month after seeing Sarah looking healthy at an advisory meeting in June 2017, Peter heard that she had been diagnosed with cancer

> “I’ve been someone who’s taken care of themselves to the max all my life; eaten well, I’ve kept my weight at a normal weight. Even nine months pregnant, I would have still been considered normal weight. Exercised like crazy, competed in half marathons, triathlons, Olympic distance. I did everything right. Never smoked, never drank to excess.” —Sarah Hallberg

- On June 30th, 2017, Sarah was on a business call when suddenly she couldn’t talk
  - Ended up in the trauma bay of the hospital where she works
  - It brought up bad memories of the time her daughter was there for a traumatic brain injury (although her daughter fully recovered)
- Found a large brain tumor and multiple tumors in her chest, had urgent brain surgery the next day
- Sarah was being irrational because she had always been healthy and taken good care of herself and could not believe this was happening to her
  - Sarah had treated patients with lung cancer and knew that it meant suffering
  - had the thought that she should move to Oregon because physician-assisted suicide is legal there and she wanted to spare her family
  - Her cancer had widely spread and was Stage IV even she had exercised and felt fine the day before
  - She was concerned about her family watching her suffer and wanted them to remember her as she was
- “Cancer changes you. So I’m not that person. One of the many things is sometimes, at this point in time, I mourn that person, because I liked her”
- 12 to 14% of people who get lung cancer are not smokers
- Lung cancer is broadly divided histologically into two types
  - [Small cell carcinoma](https://en.wikipedia.org/wiki/Small-cell_carcinoma)
  - [Non-small cell carcinoma](https://en.wikipedia.org/wiki/Small-cell_carcinoma), of which there are 3 subtypes:
    - [Large cell carcinoma](https://en.wikipedia.org/wiki/Large-cell_lung_carcinoma)
    - [Adenocarcinoma](https://en.wikipedia.org/wiki/Adenocarcinoma_of_the_lung)
    - [Squamous cell carcinoma](https://en.wikipedia.org/wiki/Squamous-cell_carcinoma_of_the_lung)
  - many non-smokers who get lung cancer have have the adenocarcinoma type of non-small cell carcinoma
- given the prevalence and lethality, lung cancer is the [leading cause of cancer deaths](https://www.cancer.org/cancer/lung-cancer/about/key-statistics.html#:~:text=Lung%20cancer%20is%20by%20far,breast%2C%20and%20prostate%20cancers%20combined.) in both men and women than any other cancer by far
- [Stage IV](https://en.wikipedia.org/wiki/Cancer_staging) means that a cancer has spread from its original location
  - in Sarah’s case it spread to the brain (“a particularly devastating place for this cancer to grow”)
  - median expected survival is around 8 to 12 months
- Lung cancer in non-smokers is increasing at an alarming rate
  - Hits people in their prime and is more common in Caucasian and Asian women
  - It also seems to affect people who are thin or athletic for unknown reasons
  - It’s odd that it’s impacting a population “who have presumably done everything right” and thus might think they are not at risk
  - Needs a lot more publicity beyond one [article](https://www.theguardian.com/lifeandstyle/2019/apr/26/you-do-think-why-me-the-shocking-rise-of-lung-cancer-in-non-smokers) that was published in [*The Guardian*](https://www.theguardian.com/us)
- Patients tend to have either [epidermal growth factor receptor](https://en.wikipedia.org/wiki/Epidermal_growth_factor_receptor) (EGFR)-driven cancer or echinoderm microtubule-associated protein-like 4-anaplastic lymphoma kinase [(EML4-ALK) positive cancer](https://en.wikipedia.org/wiki/EML4-ALK_positive_lung_cancer)
  - Sarah has the EGFR type, specifically the [exon 19 mutation](https://ckm.vumc.org/ckm/gl/mutation_profiles/pdfopen.php?fnp=lung_cancer/content/EGFR/Lung_Cancer_and_EGFR_Exon_19_Deletions.pdf):

![](https://peterattiamd.com/wp-content/uploads/2021/05/f14-hallberg-1024x280.png)

**Figure 14. EGFR mutation in exon 19.** Image credit: [Vanderbilt University Center for Knowledge Management](https://ckm.vumc.org/ckm/gl/mutation_profiles/pdfopen.php?fnp=lung_cancer/content/EGFR/Lung_Cancer_and_EGFR_Exon_19_Deletions.pdf). The colored circles represent amino acids.  Exon 19 is a section of the gene that codes for EGFR amino acids 729-761.  Here the amino acids in the red box are missing as a result of the gene mutation.

- for cancer driven by EGFR, you can target therapy with a class of medications called [tyrosine kinase inhibitors (TKIs)](https://en.wikipedia.org/wiki/Tyrosine_kinase_inhibitor)

![](https://peterattiamd.com/wp-content/uploads/2021/05/f15-hallberg-1024x533.png)

**Figure 15. Action of TKIs.** Image credit: [Vanderbilt University Center for Knowledge Management](https://ckm.vumc.org/ckm/gl/mutation_profiles/pdfopen.php?fnp=lung_cancer/content/EGFR/Lung_Cancer_and_EGFR_Exon_19_Deletions.pdf). The circle on the left represents a normal cell.  The circle on the right illustrates how a TKI (erlotinib) prevents EGFR from turning on other proteins and pathways, thus reducing cancer cell growth.

- These drugs do not cure the cancer (it always comes back), but they can make it go into remission

## The emotional impact of a devastating diagnosis [1:27:15]

- Sarah’s brain mass had to be removed because of the seizure risk, but they did not remove the tumors from her lungs
- As she recovered from the brain surgery she felt “overwhelming grief to the point of not being able to think”
- as a mom she thought about it through the lens of what it would mean for her children, who were 7, 12, and 14 at the time and needed her

> “And so the grief is overwhelming … What I quickly realized is, I’m going to break my children’s heart and there’s not a thing I can do about it. And to have that realization, because it comes quick and have to sit with that, is a grief I can’t even explain.” —Sarah Hallberg

- She was in denial and walked 7 miles the day she was discharged from the ICU to prove that she was healthy
- She found out later that her kids had discovered her in the basement, so there was no option not to tell them
  - All kids go through a stage of worrying that something will happen to their parents, and now their mom has been diagnosed with advanced cancer
  - Sarah and her husband decided to always tell the kids the truth so they wouldn’t be worried that they would suddenly get terrible news
  - Kids mostly chose not to discuss it, but the lines of communication were kept open
- “Over time, in grief, you learn to accept many things”
  - She had her husband dreamed of retiring to a farm and had joked about wanting to die instantly in a car crash at an old age
  - She could accept things like that she wasn’t going to retire, “but you can’t accept that you’re not going to be a mom. Impossible”
- Peter’s practice recently had a situation where a patient had been advised to have a major, risky surgery that was unnecessary
  - “And we realized, the asymmetry of knowledge in medicine is so overwhelming that it’s not even just about money or education outside of medicine. A smart person still has a hard time digesting medical literature”
- Sarah’s case really comes down to how to treat her specific mutation
- Sarah was able to, as Peter puts it, “partition her grief and problem solving brains” and go back and forth between them
- You have to accept that it’s terminal, but you can also ask what you can do to control when it’s terminal
  - She understood that she would not have a normal life expectancy
  - She was 46 at the time, and first she hoped to make it to 50
  - Now her 50th birthday is approaching and she wants to make it 11 years when her youngest child will graduate

## Sarah’s plan to extend survival [1:36:45]

- She tried to figure out a path for extending her survival
  - Need primary tumor out but she’s considered inoperable
  - TKIs work well but only for a short period of time
    - on average 8 months, longest would be 24-30 months
    - increases the risk of mutation and the tumor becoming resistant to TKIs
  - Her largest tumor was 6 cm, which is very large (but asymptomatic in her case)
  - Usually do not operate on patients with metastatic cancer (the brain is an exception because could save her life acutely)
- The TKI eliminated all of her small tumors within weeks
- Two remaining tumors in her brain were treated with [stereotactic radiation](https://en.wikipedia.org/wiki/Stereotactic_radiation_therapy)
  - Sarah did not have nausea from the radiation, but she did have side effects from the TKIs
  - Specialists were surprised by her unusual reactions, like losing all her hair when that doesn’t typically happen with TKIs
- Found a surgeon who would take out the primary tumor in her lung to decrease the risk of developing a mutation that would keep her from responding to the TKIs
  - Right lung has 3 lobes that drain into lymph nodes into an area called the mediastinum

![](https://peterattiamd.com/wp-content/uploads/2021/05/f16-hallberg.png)

**Figure 16. The lungs and mediastinum**. Image credit: [WNY Urology](https://www.wnyurology.com/content.aspx?chunkiid=239522)

- Planned to take out her right upper lobe, but she knew there was also a possibility that it had spread to the mediastinum
- If the surgeon found that any of those lymph nodes contained cancer, it would be futile because it had already escaped the lung
- So Sarah knew that there was a chance she could wake up with a huge scar and chest tubes but the cancer still there, and that’s what happened
- She doesn’t remember, but in recovery she was hysterically crying that she was a mom and this couldn’t happen to her

- Was depressed but would not give up
- Went back to work at the clinic the same month she had brain surgery
- A few weeks before her diagnosis, she had been selected to be an Aspen Health Innovator Fellow as an innovator in the healthcare
  - Had committed to four weeks of leadership sessions over the next two years
  - Wondered why she was leaving her kids for a week when she had terminal cancer
  - But when she got on the plane, she decided her kids would be better off if she chose to go out and live instead of feeling sorry for herself

> “And so that was the moment, sitting on that plane seat, crying. … Deciding, I just chose to live. This was a moment, I made my choice now I got to stick with it. And that’s how I’ve tried to live my life since then. Because I had a platform, I had done what I feel was a lot of good for a lot of people and it wasn’t finished.” —Sarah Hallberg

- Before her diagnosis, her family was joking that Sarah and her husband should buy lottery tickets so they could retire
- Her then-13-year-old son said, “‘You can’t retire, Mom, you’re doing so much good for the world. How could you even think of it?’ … That is a defining moment of my life. … That weighed heavily on my decision to get on that plane and to continue doing what I’m doing”
- She is now focused even more on health equity after her experiences as a cancer patient who is privileged: “I didn’t realize the stark differences until I became a patient”

## Sarah’s aggressive treatment plan [1:47:30]

- Peter doesn’t like language like “beat” cancer and “never give up” because it makes it sound like patients who don’t survive cancer somehow gave up
  - It’s not true and it doesn’t make sense
  - He likes Sarah’s framework of finding a way to co-exist with your cancer for as long as possible
- Sarah has exceeded all odds and Peter wonders how she has stayed in equilibrium
- After her surgery, they found another brain tumor
- The first-line TKI had failed
  - She was switched to the newest TKI, called [osimertinib (Tagrisso)](https://en.wikipedia.org/wiki/Osimertinib), right before the first Aspen leadership conference
- As a mother, she couldn’t accept just waiting for the cancer to come back, so she sought out very aggressive treatment
  - She knows she was lucky to have the means to travel around the country seeing different doctors
  - Met another physician-mom with slightly younger kids who had the same “I refuse to accept this” attitude
    - They joined together and found a medical team with a new approach
- Current thinking is to put people on the highest dose possible of one thing, keep going until it doesn’t work anymore, then do the same with the next thing
- The team’s new approach is to change up the treatment all the time to stay ahead of mutations
  - In February 2019 she went through the regular cycles of chemo
  - Began anti-estrogen therapy immediately after finishing the chemo
  - Besides the EGFR mutation, she had a very specific mutation for which there was a breast cancer medication ([palbociclib](https://en.wikipedia.org/wiki/Palbociclib)), because the mutation was the same for both
  - put into early menopause with medications like [Lupron](https://en.wikipedia.org/wiki/Leuprorelin) and [fulvestrant](https://en.wikipedia.org/wiki/Fulvestrant) and then started palbociclib
  - remained on Tagrisso / Osimertinib throughout her treatment
  - after 8 weeks of palbociclib went on a single agent, low-dose chemo called [cisplatin](https://en.wikipedia.org/wiki/Cisplatin)
    - she was tired and nauseous all the time but learned to manage
- She continued to travel for work (“I could tell you some really crazy stories of things I had to do while traveling to accommodate how I was feeling that nobody knew about at the time”)
- after 8 weeks of cisplatin she switched to [gemcitabine](https://en.wikipedia.org/wiki/Gemcitabine) (Gemzar), which is used in both lung and pancreatic cancer
- there is no standard chemo regimen for lung cancer, and nothing she tried was outlandish
- She had radiation on her primary lung tumor
  - Tagrisso had stopped shrinking her primary tumor in March 2018, almost a year before she began chemo
  - Since it couldn’t be surgically removed, it was irradiated
  - Unlike the brain radiation, she did not tolerate the lung radiation well
    - She had bad chest pain a day or two before leaving on a trip to hike the Inca trail
    - She decided not to tell anyone because “what a better place to die, than surrounded by your family on the Inca trail in all the beauty of the Andes mountains”
    - The trip was an amazing experience for her family
  - Her family returned home and she went on to Switzerland for a conference, where the pain started to get really bad and felt crushing
    - She was having a rare complication that impacted her bones
    - but she declined treatment because the only option was long-term opioid therapy
  - But after radiation she had no evidence of disease (NED) for a long time

## Life-threatening complications and the return of her cancer [1:59:00]

**Life-threatening complications from Gemzar**

- Conventional wisdom says that Gemzar is easy compared to Cisplatin
  - but Sarah had the opposite experience
  - She once threw up in a plant in her yard as she left for chemo
- Went to a conference in San Francisco and felt too short of breath to walk
- The day after she flew home she went in for chemo but her liver and kidney numbers were sky high and she had [pancytopenia](https://en.wikipedia.org/wiki/Pancytopenia)
  - Normal hemoglobin is 13 or 14, hers was in the low sixes, so she was severely anemic
  - Her platelets were 23, which means her blood was not able to clot
- Sent her home from chemo, but her physician friends admitted her
  - she had a [thoracentesis](https://en.wikipedia.org/wiki/Thoracentesis) to drain all the fluid from around her lungs that was making her short of breath
  - Transferred to the ICU in the hospital
  - Was put on [BiPap](https://www.hopkinsmedicine.org/health/treatment-tests-and-therapies/bipap) (a kind of ventilator)
- Had multiorgan failure (respiratory, liver, kidney) caused by the Gemzar
- She got great care and a year later she has no persistent failures even though she was near death
- Sarah was in the ICU for a long time
  - She was on [plasmapheresis](https://en.wikipedia.org/wiki/Plasmapheresis) and had [atypical hemolytic uremic syndrome](https://en.wikipedia.org/wiki/Atypical_hemolytic_uremic_syndrome) (aHUS), an immune system disorder with which over 70% of patients either quickly die or are on dialysis
  - she had kidney biopsies, was put on a new medication, did outpatient [plasmapheresis](https://plasmapheresis), and significantly improved
  - she got infusions every 8 weeks, so no one would put her back on chemo
- [Pharmacogenomics](https://en.wikipedia.org/wiki/Pharmacogenomics): using a patient’s genetic profile to predict their response to different drugs
  - Sarah had her genes analyzed and discovered that she had a genetic mutation that didn’t allow her body to break down Gemzar
  - If you get aHUS from Gemzar, it’s typical after months of treatment, but she got it within 4 weeks
  - Her dose was like a megadose for her because she couldn’t clear it

**The return of her cancer [2:05:45]**

- Cancer came back a year later, in September 2020

> “Here I am, a physician, able to grasp really difficult concepts, able to read and scour the literature and know what I’m looking for. Able to call … any time, someone to help me sort through something I didn’t understand or help maybe refer me to someone, I had all the resources in the world. … By the time I was diagnosed with cancer, I was an expert patient advocate, expert, hardcore. One of the other advantages I had is it didn’t take much to switch that and to … advocate for myself.” —Sarah Hallberg

- Got into a clinical trial on December 30, four months after cancer recurred
  - At the time this seemed like forever, but later she realized many without her advantages would die during that time
  - We have a good system when someone is first diagnosed with cancer, “but when that cancer comes back it’s kind of like the system seems to give up on you”
  - Sarah had to “get almost obnoxious” to get a biopsy in her upper right lobe where the cancer recurred
  - needed enough tissue to get a genomics report and make her eligible for a clinical trial
- Even though she has insurance, she has paid tens of thousands of dollars in out-of-pocket costs
  - Peter notes that health care bills are the [number one cause of personal bankruptcy](https://www.cnbc.com/2019/02/11/this-is-the-real-reason-most-americans-file-for-bankruptcy.html) in the United States is medical bills
  - Cancer diagnosis plays a large role in that
- Between the time the recurrence was diagnosed and the time she finally got treated, Sarah had compression of the bronchus and could not walk up a flight of stairs
- Many people with fewer resources would have died

## Sarah’s reflections on her approach to life with chronic cancer and balancing her time [2:11:00]

- Peter says time is the most important currency and wonders how Sarah balances her time among her family, her work with diabetics, and now cancer advocacy
  - Says that Sarah’s legacy is “living your life to the fullest regardless of its duration.  …That’s what your kids are going to remember about their mom”
  - And also advocating on behalf of future patients
- In her situation, Peter imagines himself retreating from everything outside of his family
  - Sarah says it was actually hard to be around her kids when she was deep in grief because they reminded her of everything she was going to lose
  - She has overcome that but her kids still come first
  - “They need to see me not getting knocked out by the stressors and bad things in life”

> “And I certainly am angry about this, but what do you do with it? That’s what’s going to be the important question in life. You can take anger, you can take all these things and you can get lost and buried in it. Or you can try to turn it into something else.” —Sarah Hallberg

- She will continue to advocate for diabetes because it’s important like cancer and she has a platform
- Also cares a lot about equity, which impacts both diabetes and cancer
- She is doing ok, but never good or great
  - Doesn’t sit around feeling sorry for herself but “great is hard to think about now”
  - Does not think that, as many say, cancer gave her a new perspective on life; she loved the way her life was and “it’s still a little hard to get used to who this person is now”
- Sarah says this is the first time she’s told her story and is glad she had the opportunity to do it
- Peter thanks her for trusting him and his listeners

§

## Selected Links / Related Material

**Steve Phinney and Jeff Volek explaining the science behind the ketogenic diet**: [Dr. Stephen Phinney and Dr. Jeff Volek on the Basic Science of Ketosis and Keto-Adaptation](https://www.virtahealth.com/blog/stephen-phinney-jeff-volek-science-ketosis-adaptation) | November 16, 2018 (virtahealth.com) | [7:00]

**Sarah’s initial unfunded study of metabolic improvements with carb restriction**: [Retrospective Analysis of Metabolic Control in Type 2 Diabetes with American Diabetes Association Recommendations compared with Carbohydrate Restriction](https://www.lipidjournal.com/article/S1933-2874(15)00113-0/fulltext) | *Journal of Clinical Lipidology* (Hallberg & Campbell 2015) | [14:00]

**Study of economic advantages of Sarah’s approach to T2DM care**: [Estimated Reduction in Medication Cost During First Year of a Continuous Care Intervention for Treatment of Type 2 Diabetes](https://www.valueinhealthjournal.com/article/S1098-3015(18)30790-3/fulltext?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1098301518307903%3Fshowall%3Dtrue) | *Value in Health* (Bhanpuri, McKenzie, Ma’ruf, Hallberg et al. 2018) | [14:00, 16:00]

**Sarah’s TEDx talk**: [Reversing Type 2 Diabetes Starts with Ignoring the Guidelines](https://www.youtube.com/watch?v=da1vvigy5tQ) | Sarah Hallberg, TEDxPurdueU (May 4, 2015) (youtube.com) | [14:30]

**Steve Phinney and Jeff Volek’s book on carbohydrate restriction**: [The Art and Science of Low Carbohydrate Living: An Expert Guide to Making the Life-Saving Benefits of Carbohydrate Restriction Sustainable and Enjoyable](https://www.amazon.com/Art-Science-Low-Carbohydrate-Living/dp/0983490708) by Stephen D. Phinney & Jeff S. Volek (2011) | [14:45]

**Sarah talks about low carb diets and ketosis at a conference hosted by Ohio State’s Food Innovation Center**: [Diabetes Reversal](https://www.virtahealth.com/blog/dr-sarah-hallberg-type-2-diabetes-reversal) | August 15, 2018 (virtahealth.com) | [16:00]

**Sarah’s published work on rethinking the guidelines and clinical approach to T2DM**: [16:00]

- [Improving the scientific rigour of nutritional recommendations for adults with type 2 diabetes: A comprehensive review of the American Diabetes Association guideline‐recommended eating patterns](https://dom-pubs.onlinelibrary.wiley.com/doi/full/10.1111/dom.13736) | *Diabetes Obesity and Metabolism* (Hallberg et al. 2019)
- [Reversing Type 2 Diabetes: A Narrative Review of the Evidence](https://www.mdpi.com/2072-6643/11/4/766) | *Nutrients* (Hallberg et al. 2019)

**Papers that have been published so far based on data from Virta’s clinical trial on** **nutritional ketosis and type 2 diabetes**: [16:00]

- [Improvement in Atherogenic Dyslipidemia at 70 Days Following a Reduced Carbohydrate Intervention for Treatment of Type 2 Diabetes](https://www.lipidjournal.com/article/S1933-2874(16)30067-8/fulltext) | *Journal of Clinical Lipidology* (Hallberg et al. 2016)
- [A Novel Intervention Including Individualized Nutritional Recommendations Reduces Hemoglobin A1c Level, Medication Use, and Weight in Type 2 Diabetes](https://diabetes.jmir.org/2017/1/e5/) | *JMIR Diabetes* (McKenzie, Hallberg et al. 2017)
- [Effectiveness and Safety of a Novel Care Model for the Management of Type 2 Diabetes at 1 Year: An Open-Label, Non-Randomized, Controlled Study](https://link.springer.com/article/10.1007%2Fs13300-018-0373-9) | *Diabetes Therapy* (Hallberg et al. 2017)
- [Cardiovascular Disease Risk Factor Response to a Type 2 Diabetes Care Model Including Nutritional Ketosis at One Year](https://www.lipidjournal.com/article/S1933-2874(18)30078-3/fulltext) | *Journal of Clinical Lipidology* (McKenzie, Bhanpuri, Hallberg et al. 2018)
- [Cardiovascular disease risk factor responses to a type 2 diabetes care model including nutritional ketosis induced by sustained carbohydrate restriction at 1 year: an open label, non-randomized, controlled study](https://cardiab.biomedcentral.com/articles/10.1186/s12933-018-0698-8) | *Cardiovascular Diabetology* (Bhanpuri, Hallberg et al. 2018)
- [Continuous Remote Care Model Utilizing Nutritional Ketosis Improves Type 2 Diabetes Risk Factors in Patients with Prediabetes](https://diabetes.diabetesjournals.org/content/67/Supplement_1/293-OR) | *Diabetes* (McKenzie, Hallberg et al. 2018)
- [Digitally Supported Continuous Care Intervention Through Individualized Carbohydrate Restriction Significantly Improves Liver Enzymes and Surrogate Markers of Nonalcoholic Fatty Liver Disease and Advanced Liver Fibrosis in Patients with type 2 Diabetes](https://www.gastrojournal.org/article/S0016-5085(18)33620-5/pdf?referrer=https%3A%2F%2Fwww.researchgate.net%2F) | *Gastroenterology* (Vilar-Gomez, (Athinarayanan, Hallberg et al. 2018)
- [Improvement in patient-reported sleep in type 2 diabetes and prediabetes participants receiving a continuous care intervention with nutritional ketosis](https://www.sciencedirect.com/science/article/pii/S1389945718304945?via%3Dihub) | *Sleep Medicine* (Siegmann, Athinarayanan, Hallberg et al. 2019)
- [Long-Term Effects of a Novel Continuous Remote Care Intervention Including Nutritional Ketosis for the Management of Type 2 Diabetes: A 2-Year Non-randomized Clinical Trial](https://www.frontiersin.org/articles/10.3389/fendo.2019.00348/full) | *Frontiers in Endocrinology* (Athinarayanan, Adams, Hallberg et al. 2019)
- [Post hoc analyses of surrogate markers of non-alcoholic fatty liver disease (NAFLD) and liver fibrosis in patients with type 2 diabetes in a digitally supported continuous care intervention: an open-label, non-randomised controlled study](https://bmjopen.bmj.com/content/9/2/e023597) | *BMJ* (Vilar-Gomez, Athinarayanan, Adams, Hallberg et al. 2019)
- [A Continuous Remote Care Intervention Utilizing Carbohydrate Restriction Including Nutritional Ketosis Improves Markers of Metabolic Risk and Reduces Diabetes Medication Use in Patients with Type 2 Diabetes Over 3.5 Years](https://academic.oup.com/jes/article/4/Supplement_1/SUN-LB113/5832367) | *Journal of the Endocrine Society* (McKenzie … Hallberg 2020)
- [Broad Spectrum Effects of a Ketogenic Diet Delivered by Remote Continuous Care on Inflammation and Immune Modulators in Type 2 Diabetes and Prediabetes](https://academic.oup.com/jes/article/4/Supplement_1/SAT-LB125/5833210) | *Journal of the Endocrine Society* (Phinney et al. 2020)
- [Effect of a Continuous Remote Care Intervention on Glycemic Target Achievement and Medication Use among Adults with T2D: A Post Hoc Analysis](https://www.researchgate.net/publication/342194249_725-P_Effect_of_a_Continuous_Remote_Care_Intervention_on_Glycemic_Target_Achievement_and_Medication_Use_among_Adults_with_T2D_A_Post_Hoc_Analysis) | *Diabetes* (Athinarayanan, Adams, Hallberg et al. 2020)
- [Impact of a 2-year trial of nutritional ketosis on indices of cardiovascular disease risk in patients with type 2 diabetes](https://cardiab.biomedcentral.com/articles/10.1186/s12933-020-01178-2) | *Cardiovascular Diabetology* (Athinarayanan, Hallberg et al. 2020)
- [Regression of Prediabetes following Two Years Treatment with a Continuous Care Intervention Emphasizing Carbohydrate Restriction: A Single-Arm, Prospective, Longitudinal Study](https://www.researchgate.net/publication/342185840_65-LB_Regression_of_Prediabetes_following_Two_Years_Treatment_with_a_Continuous_Care_Intervention_Emphasizing_Carbohydrate_Restriction_A_Single-Arm_Prospective_Longitudinal_Study) | *Diabetes* (McKenzie et al. 2020)
- [Type 2 Diabetes Prevention Focused on Normalization of Glycemia: A Two-Year Pilot Study](https://pubmed.ncbi.nlm.nih.gov/33652715/) | *Nutrients* (McKenzie … Hallberg 2021)

**Peter’s podcast with Gerry Schulman on insulin resistance**: [#140 – Gerald Shulman, M.D., Ph.D.:](https://peterattiamd.com/geraldshulman/)

[A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | [The Drive](https://peterattiamd.com/podcast/), Peter Attia (December 7, 2020) | [21:15]

**Data on how many Americans are either prediabetic or diabetic**:  [National Diabetes Statistics Report, 2020](https://www.cdc.gov/diabetes/library/features/diabetes-stat-report.html) cdc.gov (CDC 2020) | [22:15]

**NHANES survey showing that only 12% of Americans do not have metabolic abnormalities**:  [Prevalence of Optimal Metabolic Health in American Adults: National Health and Nutrition Examination Survey 2009–2016](https://www.liebertpub.com/doi/10.1089/met.2018.0105) | *Metabolic Syndrome and Related Disorders* ([Araújo](https://www.liebertpub.com/doi/10.1089/met.2018.0105#) et al. 2019) | [22:15]

**Study with six feeding phases gradually increasing carbs**: [Effects of Step-Wise Increases in Dietary Carbohydrate on Circulating Saturated Fatty Acids and Palmitoleic Acid in Adults with Metabolic Syndrome](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0113605) | *PLoS ONE* (Volk et al. 2014) | [35:04]

**Additional study that also showed saturated fat intake was not associated with serum levels**: [Comparison of low fat and low carbohydrate diets on circulating fatty acid composition and markers of inflammation](https://pubmed.ncbi.nlm.nih.gov/18046594/) | *Lipids* (Forsythe … Volek 2007) | [41:45]

**Study of childhood POA levels as a predictor of future health problems (PANIC study)**: [Cross-sectional associations of plasma fatty acid composition and estimated desaturase and elongase activities with cardiometabolic risk in Finnish children–The PANIC study](https://pubmed.ncbi.nlm.nih.gov/26892124/) | *Journal of Clinical Lipidology* (Venäläinen et al. 2016) | [1:05:30]

**Study of correlation between midlife POA and later C-reactive protein levels**: [Serum fatty acid composition and indices of stearoyl-CoA desaturase activity are associated with systemic inflammation: longitudinal analyses in middle-aged men](https://pubmed.ncbi.nlm.nih.gov/18062827/#affiliation-1) | *British Journal of Nutrition* (Petersson et al. 2008) | [1:05:02]

***Guardian*** **article about rising rates of lung cancer in non smokers:** [“You do think: why me?” The shocking rise of lung cancer in non-smokers](https://www.theguardian.com/lifeandstyle/2019/apr/26/you-do-think-why-me-the-shocking-rise-of-lung-cancer-in-non-smokers) | Denis Campbell, *The Guardian* (April 26, 2019) | [1:25:30]

**Guide to EGFR Exon 19 mutations and TKIs**: [Lung Cancer and EGFR Exon 19 Deletion Mutations](https://ckm.vumc.org/ckm/gl/mutation_profiles/pdfopen.php?fnp=lung_cancer/content/EGFR/Lung_Cancer_and_EGFR_Exon_19_Deletions.pdf) (Vanderbilt University 2016) | [1:25:50]

**Health care bills are the number one cause of personal bankruptcy in the United States**:  [This is the real reason most Americans file for bankruptcy](https://www.cnbc.com/2019/02/11/this-is-the-real-reason-most-americans-file-for-bankruptcy.html) | Lorie Konish, *CNBC* (February 11, 2019) | [02:09:30]

§

# DRUGS MENTIONED

- [Osimertinib](https://en.wikipedia.org/wiki/Osimertinib) (Tagrisso): (tyrosine kinase inhibitor) | [1:49:00, 1:53:30, 1:56:00]
- [Palbociclib](https://en.wikipedia.org/wiki/Palbociclib) (Ibrance): (selective cyclin-dependent kinase [CDK] 4/6 inhibitor) | [1:52:45, 1:53:15]
- [Leuprorelin](https://en.wikipedia.org/wiki/Leuprorelin) (Lupron):  (synthetic hormone) | [1:53:00]
- [Fulvestrant](https://en.wikipedia.org/wiki/Fulvestrant) (Faslodex): (selective estrogen receptor degrader [SERD]) | [1:53:00]
- [Cisplatin](https://en.wikipedia.org/wiki/Cisplatin) (Platinol): (platinum-based chemotherapeutic agent) | [1:53:45, 1:59:15]

[Gemcitabine](https://en.wikipedia.org/wiki/Gemcitabine) (Gemzar): (nucleoside analog chemotherapeutic agent) | [1:54:45, 1:59:15, 2:02:30, 2:05:00]

§

## People Mentioned

- [Stephen Phinney](https://www.ifm.org/about/profile/stephen-phinney-md-phd/) [7:00, 14:30, 16:00, 1:15:14]
- [Jeff Volek](https://www.virtahealth.com/people/jeff-volek) [7:00, 14:30, 16:00, 1:15:14]
- [Eric Westman](https://medicine.duke.edu/faculty/eric-charles-westman-md) [16:00]
- [Gerald Schulman](https://medicine.yale.edu/profile/gerald_shulman/) [21:15]
- [Brittanie Volk](https://www.virtahealth.com/people/brittanie-volk) [35:04]
- [Sami Inkinen](https://www.virtahealth.com/people/sami-inkinen) [1:15:14]

§

![](https://peterattiamd.com/wp-content/uploads/2021/05/bio-image-hallberg.jpeg)

##### Sarah Hallberg, D.O., M.S.

Dr. Sarah Hallberg is a physician and exercise physiologist. The founder and Medical Director of the Medically Supervised Weight Loss program at Indiana University Arnett, she is also the Medical Director at Virta Health and an adjunct clinical assistant professor of medicine at Indiana University School of Medicine. An expert on metabolic control and type 2 diabetes, Dr. Hallberg is also the executive director of The Nutrition Coalition, a nonprofit organization that aims to strengthen national nutrition policy. Her TEDx talk “[Reversing Type 2 diabetes starts with ignoring the guidelines](https://www.youtube.com/watch?v=da1vvigy5tQ&t=19s)” has been viewed more than 7 million times. Dr. Hallberg is board certified in internal medicine, obesity medicine, and lipidology. She received her bachelor’s and master’s degrees in kinesiology and exercise science from Illinois State University and her degree in medicine from Des Moines University.

Twitter: [@DrSarahHallberg](https://twitter.com/drsarahhallberg?lang=en)

Instagram: [@sarahhallberg](https://www.instagram.com/explore/tags/sarahhallberg/)

Facebook: [Sarah Hallberg](https://www.facebook.com/an.jana.31105)