# #296 ‒ Foot health: preventing and treating common injuries, enhancing strength and mobility, picking footwear, and more | Courtney Conley, D.C.

**Source:** [https://peterattiamd.com/courtneyconley/](https://peterattiamd.com/courtneyconley/)

---

Courtney Conley is an internationally renowned foot and gait specialist. In this episode, Courtney delves into the intricate world of foot anatomy and functionality. She explores the complexities of the foot, discussing its anatomy, common injuries, and the importance of understanding its structure in preventing issues. She covers a range of foot ailments, factors contributing to them, treatment options, and prevention strategies. She delves into the significance of loading, balance, range of motion, and posture, emphasizing the crucial role of strength in preventing both injuries and falls. Additionally, she sheds light on the interconnectedness of the kinetic chain, from the leg muscles down to the foot, and how issues within this chain can cascade downstream, leading to various injuries and pathologies. Additionally, she provides a comprehensive overview of footwear, discussing suitable options for both adults and children to promote foot health and mitigate potential problems.

*In addition to this interview, Courtney also recorded a series of videos to better explain a number of the concepts discussed such as diagnostic tests that are used to determine mobility and strength and the exercises one should perform to improve the outcomes based on the diagnostics. The interview will be available to everyone while the videos from the gym will only be available to paid subscribers (found at the end of the show notes page).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/courtneyconley/the_Drive_public.png)

Play

#296 ‒ Foot health: preventing and treating common injuries, enhancing strength and mobility, picking footwear, and more | Courtney Conley, D.C.

#296 ‒ Foot health: preventing and treating common injuries, enhancing strength and mobility, picking footwear, and more | Courtney Conley, D.C.

1x15s30s

0:002:22:01

## We discuss:

- Why Courtney chose to specialize in the foot [3:30];
- The vital role of foot strength, function, and health in human movement and well-being [6:15];
- Anatomy of the rear foot and midfoot [10:15];
- The development of flat feet, the impact of footwear, and the benefits of going barefoot [19:45];
- Anatomy of the forefoot, common injuries, and why most injuries occur in the forefoot [23:15];
- Foot musculature and its role in maintaining foot stability and preventing deformities like bunions and hammer toes [30:15];
- The intrinsic musculature of the foot, plantar fasciitis, footwear, and more [39:00];
- Plantar fasciitis: diagnosis, causes, and treatment [51:30];
- Posterior leg muscles: strength assessment methods, role in ACL injuries, and more  [59:15];
- Lateral and medial muscles: ankle stability, arch support, big toe stabilization, and exercises to strengthen and prevent injuries [1:04:15];
- Importance of strength of lower leg muscles for gait and preventing shin splints, stress injuries, and more [1:08:15];
- Tendinopathies and other common pathologies related to the anterior and lateral compartments of the foot [1:13:00];
- The importance of midfoot integrity, ankle dorsiflexion, and a discussion of gait alterations [1:19:45];
- Proximal stability and its implications for posture and movement patterns [1:27:00];
- The age-related decline in foot sensation and strength [1:32:45];
- Common toe injuries, treatment, and how to prevent further progression of the injury [1:36:30];
- Preventing falls and managing arthritis with proactive foot care and exercises [1:46:45];
- Footwear: advice for picking shoes that promote foot health [1:54:45];
- Footwear for runners [2:05:30];
- The importance of prioritizing footwear that promotes natural foot movement and strength while considering individual comfort and foot health needs [2:09:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Courtney Conley is an international renowned foot and gait specialist who teaches globally on topics related to foot function, gait mechanics, and strategies to combat foot and ankle pain
- She is the founder of [Gait Happens](https://gaithappens.com/attiapod): a group of clinicians providing high quality, online, cutting-edge foot education
- She is also the owner and operator of [Total Health Solutions](https://www.thsclinic.com/) clinic and gym in Golden, Colorado where she heads patient care with a focus on restoring gait mechanics and helping people resolve their foot problems
- She holds a B.A. in Kinesiology and a B.A. in Biology and a doctorate in Chiropractic Medicine
- In this episode we speak about all things related to the foot
- We talk in great detail about the anatomy and complexity of the foot
  - Unfortunately, you do need to understand this if you want to understand why things go wrong in the foot, as they so often do
- Many of you listen to this podcast in audio only, but this might be one of those episodes that is worth watching on video
  - Courtney uses a model of the foot quite a bit when we’re talking about anatomy, and even when we come back to some of the pathology of the foot
  - It’s easier to actually see for example, why you end up getting a bunion if you understand the biomechanics and anatomy of the foot
- We speak about loading, balance, falls, control, range of motion, posture
- We talk about common injuries including bunions, tendon issues, toe weakness, Achilles injuries, hammer toes, plantar fasciitis, and much more
- Through this conversation we do a deep dive into all the various shoes that people should be looking at (for both adults and children)
- In addition to this interview, we also recorded a video in the gym to better explain a number of the concepts that we spoke about
  - We break it down into diagnostic tests that are used to determine mobility, strength, etc.
  - We cover the exercises that you should do to improve the outcomes based on the diagnostics
  - The interview will be available to everyone, the videos from the gym will only be available to our paid subscribers (found on the show notes page)

## Why Courtney chose to specialize in the foot [3:30]

**Where did your personal obsession with the foot begin?**

- Courtney grew up as a ballet dancer and spent a lot of time in ballet pointe shoes
  - These shoes are very rigid, stiff, and you’re up on your toes
  - All through grade school and high school, she spent a lot of time on her feet
  - She always battled foot pain
- She chose this career through self-exploration
- She is a chiropractor by training, and she thought she was going to learn all of this stuff about the foot but that just didn’t happen
  - She really didn’t get a lot of education in regards to how the foot actually functions

**Why did you choose chiropractor over say podiatry or something that was purely focused on the foot?**

- She had this conversation with her father many times
- First she was going to go down the physical therapy route
  - But she wanted to create her own treatment protocols
- Her dad has always been a big fan of chiropractic
- She has always been interested in exercise and movement, and it just seemed like a good fit
- She had maybe half a semester in school on the foot, and she was fascinated
  - That’s more time than Peter would’ve guessed

***The foot has always intrigued Courtney ‒ it’s a very complex part of the body***

- With our education, the foot was always viewed as if something hurts in the foot, we’re either going to put an orthotic under it or refer them for some type of surgery
- Courtney was blessed enough to have some really good mentors around that increased her appetite for learning about that, and that’s how it started

***She ended up graduating from school and working in a couple of orthotic labs***

**Courtney went straight from school directly into specializing in the foot**

*Orthotic labs are presumably a place where people come and have custom orthotics made?*

- Yes
- She would work in the front offices and there’d be grinders in the back where they made the orthotics
- They would see patients who had foot pain, and they would cast them for orthotics and make the orthotics
- When she came out of school, her knowledge and practice was largely still based on the conventional way of putting support under the foot, hoping for the best

***Courtney has evolved leaps and bounds ahead of that to where she is today***

## The vital role of foot strength, function, and health in human movement and well-being [6:15]

**The complexity of the foot**:

- One of our superpowers is that we’re a [biped](https://en.wikipedia.org/wiki/Bipedalism)
- We have so many cutaneous receptors, muscle spindles, joint proprioceptors on and in our feet that communicate with our vestibular system so we can become upright and bipedal
- When you take away those functions, it really alters how you’re moving, how you’re interacting with your environment
- It’s always so wild because when we think about it from a rehabilitation perspective, we are very good at rehabbing the low backs
  - We do a lot of core strength, we do a lot of glute strength, we do a lot of hip strength
- But you don’t hear many people saying, “*I’m doing a lot of foot strength*,” and it’s literally our first interface with the ground
  - That’s how everything starts

> “*When we take that [foot strength] away, you’re really making it much more challenging for yourself, and I think it really can alter our survival as well as decrease our quality of life*.”‒ Courtney Conley

**Using race cars an an analogy**

- Peter is obsessed with race cars, and there are 4 things that determine the speed of a car: the engine, the chassis (the aerodynamics, the stiffness), the driver’s capabilities (what they can do in the car), and the tires
- The analogy is clearly that the tires are the feet and you can have the greatest car in the world, the most powerful engine, the most remarkable chassis, and the best driver, and if the tires are shot, none of it matters
  - Without them, you simply can’t get the power to the ground and back
- He thinks there’s a lot to be said for how it is imperative

***Peter would even go one step further: feet are even a more important part of the human body than tires are to the car***

- As we’ll discuss, the feet play a role in the suspension more than the tires play a role in the suspension of a car
- So when you now talk about force absorption, the feet are even more of a priority
  - And if you can’t absorb force in the feet, that becomes the inability to translate force all the way through the body
- Courtney’s good friend Jay Dicharry always says, “*You can’t build a jet engine on a paper airplane.*”

***We’re building all of the strength and we’re focusing on everything above the knee when in reality gait is shock absorption, it’s stance ability, it’s propulsion, and all of those things enable us to become efficient with movement***

- On a personal level, Peter’s interest in this probably didn’t start until a couple of years ago when he began to experience pain in his feet that wasn’t just fleeting (for the very first time in his life)
- Obviously like every other knucklehead, he had the odd bout of plantar fasciitis in his youth that got better with traditional means
- It was really only when his volume and poundage of rucking started to get really high that he started to experience pains in his feet that he now believes could be attributed to weakness

## Anatomy of the rear foot and midfoot [10:15]

- It would be much easier for everyone to understand the complexity of the foot if we had a better understanding of the anatomy
- Peter noticed that Courtney brought a friend [a model], and asked “*What’s his name again?*”
  - Eddie Vetter ‒ [Pearl Jam](https://en.wikipedia.org/wiki/Pearl_Jam) is one of her favorites
- When it comes to understanding how we’re treating the foot and foot pain, it’s very important to understand the anatomy of the foot

***There are basically 3 parts to the foot: you have a rear foot, a mid-foot, and a forefoot***

- There are 26 bones and 33 joints
- It’s a complex part of our bodies and that’s why a lot of rehab treatments and protocols have veered away from really understanding what’s happening here

**The rear foot, the** [**calcaneus**](https://en.wikipedia.org/wiki/Calcaneus)

- This is one of Courtney’s favorite bones, and here’s a fun fact, a 100 pound female actually has a larger calcaneus than a 350 pound gorilla

![](https://peterattiamd.com/wp-content/uploads/2024/03/f1-courtneyconley.png)

**Figure 1. The calcaneus**. Image credit: [OrthoInfo](https://orthoinfo.aaos.org/en/diseases--conditions/calcaneus-heel-bone-fractures/)

![](https://peterattiamd.com/wp-content/uploads/2024/03/f2-courtneyconley.png)

**Figure 2. Bones of the foot**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Metatarsal_bones)

- There’s 2 layers to the actual bone itself: a thin cortical layer (outer layer) and a spongy inner layer
- Think of the design like a rubber ball bouncing ‒ it was designed to absorb shock
- The other thing about the calcaneus is there’s a fat pad that sits outside the calcaneus
  - It also two chambers
  - 1 – There’s a thin *outer* chamber (a microchamber) that is not easily deformable because when we walk, most of us as in a walking gait, we graze the heel
    - That outer chamber is not designed to deform
  - 2 – There’s a macro chamber on the *inside* of the fat pad that is highly deformable
- The purpose of both the fat pad and the way the bone has been designed is to **absorb shock**
- That fat pad is 2x a better shock absorber than [sorbothane](https://en.wikipedia.org/wiki/Sorbothane)
  - A synthetic material that a lot of performance orthotics are made of, designed to dampen vibration and absorb shock

***We have a beautifully designed calcaneus that was designed to handle all of this shock, to handle what happens when our heel strikes the ground when we walk ‒ it’s a very important structure***

**The calcaneus looks like it interacts with another major bone there that sits right under the fibula and the tibia**

- The talus
- Fun fact about the talus, there is zero muscle attachment to that bone
  - It’s all ligaments
- [Benno Nigg](https://contacts.ucalgary.ca/info/kn/profiles/196-1265) did a [study](https://pubmed.ncbi.nlm.nih.gov/2210531/) that looked at sectioning the [anterior talofibular ligament](https://en.wikipedia.org/wiki/Anterior_talofibular_ligament)
  - That’s also a very common ligament when we sprain our ankle

![](https://peterattiamd.com/wp-content/uploads/2024/03/f3-courtneyconley.png)

**Figure 3. Lateral view of the ankle and the anterior talofibular ligament**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Anterior_talofibular_ligament)

- If those ligaments on the outside of the ankle get completely torn, you now have this talus that has nothing attached to it
  - What can happen is the talus can migrate (it can adduct) so the tibia will internally rotate, the talus adducts, and then what happens is it bangs into the [medial malleolus](https://en.wikipedia.org/wiki/Malleolus#) [shown in green in the figure below]
  - Patients will often present with pain along the inside of their ankle and it will be diagnosed as a tendon dysfunction (posterior tibialis) when it is an **instability at the rear foot** because that talus is shifting

![](https://peterattiamd.com/wp-content/uploads/2024/03/f4-courtneyconley.png)

**Figure 4. Bones of the ankle joint including the medial malleolus**. Image credit: [HSS](https://www.hss.edu/condition-list_ankle-fractures.asp)

**Would that patient have necessarily suffered something traumatic to have torn the AF ligament?**

- Typically when you look at ankle sprains, mild ankle sprains over and over again actually pose more of a problem from a gait perspective or a rehab perspective because people will typically sprain their ankle, shake it off, and then continue to walk or play on it
- When you have these continuous sprains, you have changes to the ligament
- But here’s the cool part: the ligament actually heals
- The issue is that the [superficial peroneal nerve](https://en.wikipedia.org/wiki/Superficial_fibular_nerve) (the nerve on the outside of the foot/ankle) gets stretched
  - Sometimes those nerves get torn, and once you start changing the neurological input, that’s the issue

***The ligament will heal ‒ the problem is when you lose sensory input***

- Courtney had a patient this week that had multiple ankle sprains when he was a kid
  - In the last couple sprains that he had, he couldn’t feel anything
  - That’s when they realized, “*Okay, we need to take care of this because he lost all sensory input.*”
- Peter wonders how much of that he has going on from his frequent ankle sprains growing up
  - They’ll figure that out when they do some of the interesting diagnostic stuff later

**What is that bone that both the talus and calcaneus look like they’re touching? Is that the navicular?**

- The [navicular](https://en.wikipedia.org/wiki/Navicular_bone) is right on the inside, this is the highest point of the medial arch [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/03/f5-courtneyconley.png)

**Figure 5. Anatomy of the ankle and arch of the foot**. Image credit: [NHS](https://www.nhslanarkshire.scot.nhs.uk/services/physiotherapy-msk/posterior-tibialis-tendinopathy/)

- The [posterior tibialis](https://en.wikipedia.org/wiki/Tibialis_posterior_muscle) is a very important inverter of the foot
  - It inverts the foot
  - It helps stabilize the arch, comes down, wraps around the navicular and inserts on the bottom of the navicular
  - It also has 8+  insertion points on the bottom of the foot
- In people that have an accessory navicular, it’s almost an extra bone that sticks off that navicular
  - You can see it when you’re looking at someone, it looks like they have a protrusion
  - Because the posterior tib has to come down and wrap around the navicular, if you have an extra bone there, the vector of force is longer
    - Courtney describes it to patients as if you were doing a chest press and instead of starting where you normally would, imagine having to start with your arms further back (it’d be more difficult)
- In those patients, when you see that they have an arch that doesn’t want to recoil or function, you have to consider **strengthening the posterior tibialis**
  - If there’s too much of a structural variant, that’s when you implement things like an orthotic, for example

*Is the navicular considered then part of the midfoot?*

- Yes
- The calcaneus makes of the rear foot

**Presumably those distinctions are based not just on their location. Do they have some functional significance?**

- When you look at the gait cycle, we look at different rockers of the foot
- When we are initially walking and our heel strikes the ground, that rear foot (the calcaneus) starts or initiates [pronation](https://en.wikipedia.org/wiki/Pronation_of_the_foot)
  - Then we go into eversion and then you have the midfoot that unlocks

**Let’s make sure people understand eversion, pronation, supination of the foot**

- Inversion would be going out [tilting outward]
  - That is also a supination
- Pronation is an unlocking of the foot
  - This is where the foot flattens and widens
  - We’ve demonized pronation
- The calcaneus, when you evert ‒ it’s basically allowing that pronation to begin
- All of these are movements that are facilitated by muscles and ligaments
- When your heel hits the ground, you have body weight, then you’re dealing with ground reaction force

***The beautiful thing about gait is that we need to have adequate range of motion, but you also have to be able to control that range of motion***

- When things get sticky is when we see people speeding through the gait cycle or they’re speeding through pronation and they can’t control it
  - Then you have the system going, “*Slow down.*”

**Presumably that comes back to eccentric weakness**

- There’s a lot of eccentric control that’s required when our foot hits the ground

## The development of flat feet, the impact of footwear, and the benefits of going barefoot [19:45]

**One more thing that is really cool ‒ the sustentaculum tali**

- The sustentaculum tali is a medial lip off the [calcaneus](https://en.wikipedia.org/wiki/Calcaneus)
- It’s fully ossified by the time we’re 7 years old

**Flat feet and the importance of sensory input**

- A research [study](https://pubmed.ncbi.nlm.nih.gov/1624509/) by Rao and Joseph looked at 2300 children,and they looked at static footprints and how footwear affected the development of their [medial arch](https://en.wikipedia.org/wiki/Arches_of_the_foot#Medial_arch)
  - That’s a pretty large cohort for a study
- They found that by the age of 13 (these were kids 4 to 13), those who did not wear shoes, less than 3% of them presented with what they considered [flat feet](https://en.wikipedia.org/wiki/Flat_feet)
  - The ones that wore shoes, 9% were considered having flat feet
- For the ones that wore shoes, they also noticed the type of shoes
  - The ones that wore closed toe box shoes had a higher prevalence [of flat feet] than even the kids that wore sandals
  - Why is that?
    - Did they kick their shoes off and run around barefoot?
    - Did they have more toe splay?
    - Was the foot able to function in a better position?
- The conclusion of this study was, the researchers said that this sensory information that was gained by their feet somehow gave them a protective tone
  - An increase in protective, muscular tone that was enabling their arch to elevate
- With research, Courtney always says, “*Let it guide you, not shackle you*.”

*How is that accomplished?*

- Peter knows that many people listening are going to immediately think about their kids, and the reality is that most of our kids are in school from a pretty young age, and therefore they have to be in shoes
  - You live in Colorado, it’s not like you’re going to send your kid to school in sandals in the middle of the winter

*Do you get a sense of the time requirement being out of shoes if indeed there’s causality between time away from shoes and improved foot health at a young age?*

- We have the opportunity with kids when they’re at home to take their shoes off
  - Be in sand, grass
  - This doesn’t have to be all the time, but even just a little bit

***Every kid on the planet, the first thing they do is take their shoes and socks off because they’re wanting to gain that sensory input, and even a little bit can go a very long way***

- We’ll get into footwear because that’s a big one for the kids

## Anatomy of the forefoot, common injuries, and why most injuries occur in the forefoot [23:15]

> “*The forefoot is where we will see most of our injuries because when we’re walking, there’s 8x our body weight that go through the forefoot with propulsion.*”‒ Courtney Conley

- Your [Achilles tendon](https://en.wikipedia.org/wiki/Achilles_tendon) experiences a force about 4x your body weight with each step, when you walk

![](https://peterattiamd.com/wp-content/uploads/2024/03/f6-courtneyconley.png)

**Figure 6. Achilles tendon and anatomy of the lower leg**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Achilles_tendon)

- The Achilles is the tendon both the [gastroc](https://en.wikipedia.org/wiki/Gastrocnemius_muscle) and the [soleus](https://en.wikipedia.org/wiki/Soleus_muscle)
- Peter clarifies that they are referring to **tendons**, and we’re talking about the attachments  of muscles to bones
  - Earlier they referred to **ligaments**, which are the attachments between bones
- The Achilles tendon is a massive tendon
- The gastroc and the soleus twist on each other and become a very robust tendon
- The soleus actually makes up larger fibers of the Achilles tendon than the gastroc
  - The soleus is a powerhouse

**Getting back to the load your tendons are under**

- It’s 4x your body weight when you’re *walking*
- When you start *running*, those numbers double
- The calcaneo-navicular area experiences loads of up to 11x your body weight when you’re running (it’s massive)

***The very cool thing is our foot was designed to handle it***

- We have all the bone structure, muscle, tendon that was designed to handle that load

***The problem is if you don’t use it, you will lose it***

**Common injuries of the forefoot**

- Courtney said earlier that the majority of foot injuries occur in the forefoot, and there are lots of bones in the forefoot: metatarsals, phalanx, distal phalanx, proximal phalanx (distal and proximal, except for the big toe)

![](https://peterattiamd.com/wp-content/uploads/2024/03/f7-courtneyconley.png)

**Figure 7. Division of the foot into forefoot, midfoot, and hindfoot, and the bones found in each region**. Image credit: [Don’t Forget the Bubbles](https://dontforgetthebubbles.com/foot-and-toe-injuries/)

- Supporting 8x our body weight at propulsion, the forefoot has to be incredibly stable at push-off because it handles so much load
- When we’re walking, one of the most common injuries at the forefoot will be a generic diagnosis of metatarsalgia or stress fracture
  - 1 is the big toe
  - 2 and 3 will typically will be your metatarsalgia area
  - 5
- You see a lot of stress fractures in 3 and 4

**Tell people what a stress fracture is**

- A stress fracture can be caused by 2 different things: tensile strain or compressive loading
- It’s when you have force going through the bone and the system just can’t handle it
- It starts to irritate the tissue
- When you look at the foot (this is important from a rehab perspective) depending upon where the fracture is, you’ll know what type of stress fracture it is
- For example, if you have patients that are hitting their heel very hot and heavy they can get a stress fracture in the calcaneus
  - They might have a rigid foot, they might have one that doesn’t have good mobility and they hit the heel heavy
- The 5th metatarsal is also a very common location for these compressive loading stress fractures because they can’t handle that compression

**On other side of the foot**

- Remember we talked about the navicular, that guy technically should never hit the ground ‒ he can get a stress fracture
  - It’s the highest part of the medial arch
- So you’re saying to yourself, “*How is that possible if they’re caused by compressive loading, not that guy, he’s caused by tensile strain?*”

***When you can’t handle the foot pronating and rotating and you can’t handle the movement of the foot, the tendon will start to tug and you’ll start to get that strain at the navicular stress reaction leading to stress fracture***

- Peter finds this interesting: we think about bones as having this great capacity for contractile force, so axial loading
  - We don’t think of them as requiring as much tensile force, but of course they’re under tremendous tensile force
  - In the opposite, we think of our skeleton as needed to support compressive load, but of course they have to do both, which actually is a pretty remarkable material
- Concrete for example, is only strong under compression
  - It’s so weak under tension
  - Without rebar, concrete would be useless
- Yet our bones have to do both

**Are you saying that lateral injuries are likely to be more compressive and medial injuries might be more likely to be tensile?**

- Peter doesn’t know that that matters necessarily other than it explains what caused the injury
- It also matters for treatment
- When you look at a compressive loaded stress fracture at the *heel*, at the *fifth metatarsal*
  - You have to **cushion** those, obviously let the tissue heal
  - That person might need something that’s going to give a little bit
- The *navicular* stress fractures, the *metatarsal* stress fractures, the *sesamoid* stress fractures, because they happened due to an instability to a tensile strain you can **boot** them
  - Your follow-up with them better be rehabbing the strength of their foot because it’s not that they landed too heavy, it’s because they couldn’t control their motion
- People with [sesamoid](https://en.wikipedia.org/wiki/Sesamoid_bone) injuries
  - The sesamoids are the two little bones under the big toe, and they’re similar to the patella
  - Sesamoid refers to a bone that is completely surrounded by tendon
    - It’s like a little joint capsule
    - None of the bone is exposed
  - Those stress fractures can be extremely painful and people stop using the big toe
  - If you offload it, put the person in a boot for 3 months and they’ll say, “*Okay, the bone’s healed. Go back to your activity.*”
    - It doesn’t work like that
    - Even though the bone is healed, the muscles are weaker and you’re more susceptible to injury
    - You also need to know how the injury happened in the first place

## Foot musculature and its role in maintaining foot stability and preventing deformities like bunions and hammer toes [30:15]

- Peter points out that the musculature is incredibly complicated and it’s related to what’s happening in the lower leg
  - We don’t think of it that way because when we look at it, we can see the bones through the skin
- Courtney explains that **intrinsic muscles** live in the foot: they start and end in the foot
  - We have 4 layers of muscle there
- The foot is the only place in the body where you can look at it and say something is going awry
  - You’ll form things like bunions and hammer toes and tailor’s bunions, and you’ll be able to look at your foot and go, “*This isn’t the way it’s supposed to look. Maybe I should pay attention to it*.”
  - You can’t do that in an knee or hip unless you take an X-ray
  - When you can get your hands on a foot where you start to see these deformities and they’re flexible, you really think about it from a **muscular imbalance**

**Some of the intrinsic muscles of the foot**

- The [abductor hallucis](https://en.wikipedia.org/wiki/Abductor_hallucis_muscle) is the big one ‒ it sits along the big toe and is responsible for straightening the big toe [shown on the left in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/03/f8-courtneyconley.png)

**Figure 8. The abductor hallucis and adductor hallucis**. Image credit: [Learn Muscles](https://learnmuscles.com/glossary/abductor-hallucis/) and [Rehab My Patient](https://www.rehabmypatient.com/toe/adductor-hallucis)

*Peter explains the difference between an adductor versus an abductor*

- Medical students always remember this as **abductors** abduct
  - They take things away, like a person’s being abducted
  - They pull *away* from the body
- An **adductor** pulls *back* towards the body
- These terms are always embedded within the names of the muscles

*Back to the muscles of the forefoot*

- The ***abductor*** **hallucis** is going to straighten the big toe
- There’s also a muscle that pulls it to the middle
- The ***adductor*** **hallucis** is kind of like a backward 7
- When these muscles get out of balance
  - For example, if you’re in a shoe, that’s going to squeeze you toes together, and now you have an *adductor* that is shortened and an *abductor* that is lengthened
  - ***You start to get this imbalance at the foot, and then you start to see changes in the foot***
- Bunions are a result of an instability in the foot

**What exactly is a bunion?**

- It’s a transverse instability, not where you see the [bunion](https://en.wikipedia.org/wiki/Bunion), but at the metatarsal medial cuneiform
  - When someone can’t control motion at the foot
  - The junction between the midfoot and the forefoot
- A bunion is this bone basically shifting to the outside
- What you notice when you’re looking down at a person’s foot is this huge outpouching in what is otherwise the widest part of the foot
  - It looks like it just got a whole bunch wider and it’s pointing out
- When you see the skeleton, it’s much easier to understand why that’s happening
- A lot of people have these surgically repaired

*What are they doing surgically to repair that?*

- A lot of these surgeries are not successful
- There is a time and a place for them, but Courtney would be very cautious about getting foot surgeries for symptoms
- Surgery will either shave part of the bone down and then realign the toe
- Oftentime, they will pin the metatarsal to the cuneiform
  - They stabilize where most people have that instability
  - Once you start pinning things together, you might take care of alignment
- But you’ve done nothing to strengthen the muscle that allowed this to get there
- In response to the conversation, “*My mom has a bunion, my grandma has a bunion.*” Courtney explains that you don’t come out of the womb with a bunion
  - You might inherit connective tissue laxity, or there might be hypermobility issues
- We know that with the earlier interventions (as discussed with kids earlier)
  - You get them in the right footwear: you make sure they’re in shoes that have a toe box where the toes can actually splay
- What’s fascinating about the big toe is if you look at your nail bed, some people that have bunions, the nail bed will be flat and it’ll just look like it’s adducting
  - When you see the nail bed and it’s actually rotated inward
  - You see some of those people right where the nail bed’s kind of turned in and it looks like it’s a rotational issue, you know for certain they can’t control rotation

***When you see that, it’s typically from footwear***

- One of the reasons Courtney got into all of this was she has bilateral bunions on both of her feet due to the fact that she was constantly in [pointe shoes](https://en.wikipedia.org/wiki/Pointe_shoe)
- Then her solution to that was to start bracing her feet because they hurt, and they just got weaker and weaker
- She realized this was not right
- Once she started strengthening them, getting in the right shoes, it’s a different ball game
- Bunions are very common

**What’s a hammer toe?**

- [Hammer toes](https://en.wikipedia.org/wiki/Hammer_toe) are basically when the toes start to hammer the ground
- The big toe can hammer, it’s just not as common as 2 through 5
- When you look at the top of the foot, we have short toe extensors, but we also have long toe extensors
  - The short toe extensors are doing a lot of work and the long toe extensors are not
  - The extensors would be pulling back, the flexors would curl forward
- Peter adds, “*This is one of those things where if you’re listening to us, this is very difficult to understand. It’s why watching what you’re saying makes a lot of sense.*”

*It seems counterintuitive to say, how can a hammer toe be in part driven by this extensor phenomenon?*

- If the short extensors, the ones that attach with a shorter moment arm are fired up and the long ones are relaxed, it actually looks like a hyperflexion
- For people who have **pain along the bottom of their foot,** so along their metatarsals, if you take out your insert of your shoe and you see a lot of wear underneath the second or third metatarsal, you’re probably walking around with too much pressure going through there
  - So on the bottom of the foot, it’s the exact opposite
  - The short flexors that aren’t doing anything and the long flexors who are

***Hammer toes are a muscle imbalance due to a weakness in the foot***

**What do you attribute the root of that to? What is the environmental trigger that is most commonly driving a hammer toe?**

- Courtney thinks it’s the same thing: we have not been paying attention to our feet for a very long period of time
- Analogy: if you were to walk around with your hands in mittens for 20 years, you shouldn’t be surprised when your hands don’t function
  - It’s the same concept at the foot really, that it is everywhere else in the body
- Peter adds that for most people, if you think back to being a kid, you could still move your fingers in mittens

*A better analogy: the problem is mittens that don’t allow you to move your fingers*

- If you were to spend 12 hours a day in that situation, it would be obviously cumbersome
- We will talk more about intrinsic and extrinsic foot stabilizers when we get into the gym

## The intrinsic musculature of the foot, plantar fasciitis, footwear, and more [39:00]

- There are a couple of key muscles that are responsible for a lot of our foot function
- 1 – The [flexor digitorum brevis](https://en.wikipedia.org/wiki/Flexor_digitorum_brevis_muscle) is one of Courtney’s favorites [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/03/f9-courtneyconley.png)

**Figure 9. Muscles along the top of the foot**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Abductor_hallucis_muscle)

- This guy runs from the heel and inserts up into the phalanx (into the toes)
- It’s a big muscle that runs parallel to the [plantar fascia](https://en.wikipedia.org/wiki/Plantar_fascia)
- He’s responsible for decelerating toe extension when we walk
  - Remember, it’s all about slowing things down: we want to control it
- If you don’t have good strength of that muscle, he shares load with the plantar fascia

***One of the biggest predictors for patients that have*** [***plantar fasciitis***](https://en.wikipedia.org/wiki/Plantar_fasciitis) ***(an acute plantar fascial pain), is a weakness of flexor digitorum brevis***

- When you look at treatment protocols on how to get people better with plantar fasciitis, it’s stretching their calves
  - That’s not bad, but you also have to look at the strength and the stability at the foot

***The flexor digitorum brevis is a very big player in the stability of the foot in decelerating pronation***

**Can you explain the anatomic structures that make up the plantar fascia?**

- This is clearly something many people listening will understand
  - They will probably have a ballpark sense of what it feels like and how there’s a real tenderness in the arch
- The plantar fascia starts at the calcaneus and it’s going to insert into the deep [transverse metatarsal ligament](https://en.wikipedia.org/wiki/Transverse_metatarsal_ligament) up at the forefoot [see the figure below]
- The plantar fascia has a very key role by the way, in stability of the foot [shown in the second figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/03/f10-courtneyconley.png)

**Figure 10. Ligaments of the foot**. Image credit: [ScienceDirect](https://www.sciencedirect.com/science/article/pii/B9780128154496000408)

![](https://peterattiamd.com/wp-content/uploads/2024/03/f11-courtneyconley.png)

**Figure 11. Plantar fascia ligament**. Image credit: [Plantar Fasciitis](https://www.fasciitis.com/what-is-plantar-fasciitis/plantar-fasciitis-scientific-discussion/)

*Courtney explains something called a* ***“tie bar mechanism”***

- This is something that we need to take advantage of
- We have a ligament that runs across the metatarsal
  - When we’re walking and we go into mid-foot loading, when all the pressure comes and our arch starts to flatten and widen, when the forefoot splays, it triggers receptors in that deep transverse metatarsal ligament
- The plantar fascia inserts into that ligament, and it forms this “T”
  - When the foot splays, it triggers this mechanism of horizontal stability as well as vertical stability
- The plantar fascia like a triangle at the forefoot now begins to spread under tension while it’s also being elongated vertically
  - It’s like a fan
- The beautiful thing about **forefoot splay**, is its this free mechanism that’s basically telling our brains, “*Hey, you’re about to push off. You better get real strong and you better get real stable because we’re about to take on 8x your body weight.*”
- You take away forefoot splay, you can forget about the receptors talking to you because you’re not getting the tug on them from the deep transverse metatarsal ligament (the splay), and your also not signaling the plantar fascia

**What would oppose that? How much compression needs to be on the foot, presumably in the form of a narrow shoe that would prevent sufficient splaying to activate the plantar fascia in that regard?**

- 3-5 mm

*A good way to look at this*

- If you were to take out the factory insert of your shoe and you place your foot on it and then stand on top of the factory insert
- If your forefoot expands wider than the insert, then it’s too narrow
  - You can be pretty certain that those toes are getting squeezed
- Peter would bet that many of his shoes don’t pass that test

**Is it safe to say that it might be tolerable if it’s a fashion shoe you’re wearing, but you certainly wouldn’t want that in an athletic shoe where you’re running or rucking or doing something under load**

- Courtney’s daughter is 12, she complains about wearing these platypus shoes when everyone else gets to wear Nikes
  - Courtney explains, “*The more time we can spend allowing our foot to be in a position where it can function like it’s supposed to, the better off we’re going to be.*”
- Peter notices that there’s nothing in the shoe industry that is aligned with that
  - Shoes are not typically designed to have that degree of width
- [Nike](https://www.nike.com/t/swoosh-1-baby-toddler-shoes-gbLvvF) just came out with a baby shoe a couple months ago, and they said, “*We’ve done the research. This shoe will help your child’s development of their foot*.”
  - For toddlers, when they first start walking
  - It has a wide toe box and a flexible thin sole to allow the child’s foot to do what it was designed to do

**Why would you not carry that through adulthood?**

- Companies are starting to realize this
- When you look at research from a shoe perspective, at the end of the day, we want something comfortable on our feet
- Courtney would argue that every single one of her patients, once she simply puts them in a shoe that allows their toes to splay, they will always say, “*It feels more comfortable.*”
- Think about it from balance: are you going to balance better like this?
  - It’s not a hard sell

**What are the most common causes of plantar fasciitis, and how do you think about treating it in the acute sense?**

*Somebody shows up for the first time and they’ve got it. What are your thoughts on the differential diagnosis for what led to it and how do you go about rehabbing it with an eye towards preventing it in the future?*

- Plantar fasciitis, “itis” refers to inflammation of the plantar fascia
- First, you have to make sure that’s what it is
  - There’s a differential diagnosis of heel pain
  - You have to rule out [calcaneal stress fractures](https://en.wikipedia.org/wiki/Calcaneal_fracture), for example, there’s [Baxter’s neuropathy](https://www.physio-pedia.com/Baxter's_Nerve_Entrapment)
- It’s a clinical diagnosis, there is not an imaging study that confirms it; you have to exclude other things
- You can also see a thickening of the plantar fascia
  - You’re not going to put somebody in an MRI for that
- There’s a difference between an “itis” (plantar fasciitis) and plantar fasciopathy or fasciosis
- By the time people come to Courtney, it’s no longer in an acute stage because in an acute stage, this is your initial injury
  - So it is treated very differently
  - Orthotics often can help in those initial stages of an acute injury because you are offloading
- The anatomy here is so complicated that Peter thinks it helps to talk about pathology to explain it

**Why are orthotics acutely helpful? Is it because it prevents the full collapse of the arch, and therefore it takes some of the stretch off the plantar fascia?**

- Yeah
- The jury is still out on exactly what an orthotic does, but we know it has something to do with force
- When the foot starts to unlock, it’s a load modifier
- An orthotic is a load modifier, so it’s going to modify the load that’s occurring at the heel
- In an acute situation, that’s great
- But if Courtney had a penny for every time one of her patients came in with their orthotics that they got 20 years ago for their plantar fasciitis, she’d be a rich woman because
  - Patients explain that the orthotic helped acutely
  - But research will say 2 weeks and at the most up to a year, and then it’s time to get out of those things

***There has to be an [orthotic] exit strategy, and while you’re planning this exit strategy, you need to be strengthening the foot***

***You have to be strengthening things like*** [***flexor digitorum brevis***](https://en.wikipedia.org/wiki/Flexor_digitorum_brevis_muscle) ***to be able to share the load with the plantar fascia***

**In an acute setting, they’re treated very differently**

- When it’s more of a chronic heel pain, this is degenerative, this is repetitive load
  - They’ve been walking around on a foot that can’t handle load, then the tissue starts to break down
    - In those cases, it is all strength
    - It’s load; it’s not deload

Peter asks, “*Even for a period of time?*”

- [Irene Davis](https://awards.research.usf.edu/profiles/?id=1363) and [Sarah Ridge](https://www.hartford.edu/directory/enhp/ridge-sarah.aspx) are looking at research, looking at patients with chronic heel pain (chronic plantar fasciosis)
  - Looking at implementing minimal footwear in these patients and seeing what happens
  - [Irene was on the podcast in [episode #128](https://peterattiamd.com/irenedavis/)]
- If you think of the plantar fascia as a connection to the Achilles tendon (it is connected)
- Think of the calcaneus as floating between the plantar fascia and the Achilles tendon
- We know that tendons need load
- So think about that from the plantar fascia perspective
  - You have to load the tissue in order for the tissue to get stronger

**Is load also necessary to heal the tissue, assuming it’s not cut?**

- Anybody who’s had a tendinopathy, we always say rest is *not good* for tendons
- It’s not that rest is bad
  - You talk to anybody who’s had an Achilles tendinopathy, if they rest for a week, they’re like, “*Yeah, it feels great*.”
  - The problem is that when they go to return to sport or they go to return to walk without having loaded the tendon, they’re going to be right back where they started from
- When we talk about loading the tendons it’s a mechanotransduction
- When you load a tendon, there’s a fascial gliding that occurs
  - This mechanical stimulus that then gets converted to a chemical stimulus, and then we start to see tendon healing
- Peter remarks, “*In that sense, it’s very similar to bones*.”
- We’ve talked a lot on this podcast about the most important thing for strengthening bones is force on the bone
  - That’s why weight training and grappling are the 2 best exercises for bone density, because they put the most stress on the bone (both compressive and tensile) and the mechanoreceptors in the bones (which sense the deformation, use estrogen as the chemical signal to signal bone building)
    - It’s of course why estrogen is arguably the most important hormone here
- Here it sounds like in tendons, mechanical deformation signals a chemical to build
  - Presumably via different chemical transduction systems
- Yeah, there’s the tenocytes that live within the fascicles of the tendon, and this mechanical gliding shears the cells
  - You get a chemical stimulus and then you start to get the changes within the tendon

## Plantar fasciitis: diagnosis, causes, and treatment [51:30]

**Back to the patient with plantar fasciitis**

- You’ve excluded other things and diagnosed them with plantar fasciitis

*What are the most typical reasons for that presentation in, let’s start within a young person, a young active person?*

- Weakness in the foot
- When they come in, Courtney has a toe dynamometer (a little device) that tests the strength of your toes

![](https://peterattiamd.com/wp-content/uploads/2024/03/f12-courtneyconley.png)

**Figure 12. Toe dynamometer**. Image credit: [Gait Happens](https://gaithappens.com/product/toe-dynamometer/)

- You put a card underneath your big toe and have the patient press their big toe into the card
  - You should be able to produce 10% of your body weight through your big toe (that’s the [flexor hallucis longus](https://en.wikipedia.org/wiki/Flexor_hallucis_longus_muscle))

![](https://peterattiamd.com/wp-content/uploads/2024/03/f13-courtneyconley.png)

**Figure 13. The flexor hallucis longus muscle**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Flexor_hallucis_longus_muscle)

- When you put the card underneath 2 through 5, you should be able to produce about 7-8% of your body weight
- When they’re pressing their toes down, there’s a couple rules
  - They can’t lift up their heel, and they can’t hammer the toes
    - The reason you’ll see people who hammer their toes is because it’s a compensation for weakness in the foot
    - That’s how they walk, clawing their way forward, and when they do that, they have to press their toes down

*When you do the big toe, do toes 2-5 (the extensor hallucis longus) need to be off the ground, or are they on the ground just not hammered?*

- On the ground

**Is this something anybody can go out and do (buy one of these)?**

- Oh yeah, you can buy them [at [Gait Happens](https://gaithappens.com/product/toe-dynamometer/)]
- The other thing that’s also easy to measure at home uses a little laser scanning device
  - You would stand close to a wall, and you’d measure from your [umbilicus](https://en.wikipedia.org/wiki/Navel) to the wall
  - Then you keep your body straight (so your hips and shoulders are straight), and you lean into the wall as far as you can
  - It’s your toe strength that stops you from smacking your face into the wall
  - That distance should be 4.5 inches or more
- Peter adds, “*We could do the trigonometry on that, but basically there’s an angle at which you’re creating a moment arm that you need to be able to resist.*”
- Correct, it’s called the **anterior fall envelope**

![](https://peterattiamd.com/wp-content/uploads/2024/03/f14-courtneyconley.png)

**Figure 14. The anterior fall envelope**. Image credit: [Human Locomotion](https://www.humanlocomotion.com/the-human-locomotion-fall-prevention-protocol-how-to-create-a-customized-treatment-program-to-maintain-strength-and-agility-as-you-age/)

> “*Toe weakness, by the way, is the single biggest predictor of falls when we age*.”‒ Courtney Conley

- When you think about **falling**, it typically occurs at the initiation of gait
- If you don’t have that anterior fall envelope, if your toes are weak, you’re going to keep going

***Not only can toe weakness be a predictor of things like plantar fasciitis fasciosis, but also toe weakness can be and is one of the single best predictors of falling (researched by*** [***Karen Mickle***](https://www.newcastle.edu.au/profile/karen-mickle)***), which is massive***

**Treatment of plantar fasciitis**

- For an athletic or active person diagnosed with plantar fasciitis, with weakness being the culpable reason for it

*What drives you towards temporary orthotic versus no orthotic and just get right to work?*

*What’s your typical strategy?*

- When Peter has had plantar fasciitis (2 bouts in his life), he’s never done an orthotic
  - It’s just been backing off the volume [of exercise], some manual therapy, ice and more footwork
- Courtney’s strategy is very individual specific
- You definitely have to meet the patient where they are
  - What is their activity level?
  - What are they willing to do?
  - What age are they?
  - Are they going to do this stuff?
- From a passive perspective, Courtney does [shockwave](https://en.wikipedia.org/wiki/Extracorporeal_shockwave_therapy) into the bottom of the foot
- Medial [gastroc](https://en.wikipedia.org/wiki/Gastrocnemius_muscle), the way the medial gastroc inserts into the Achilles tendon

**More about the gastroc**

- There’s 2 muscle bellies

![](https://peterattiamd.com/wp-content/uploads/2024/03/f15-courtneyconley.png)

**Figure 15. Anatomy of the gastroc and lower leg**. Image credit: [Foot Pain Explored](https://www.foot-pain-explored.com/gastrocnemius.html)

- The medial gastroc sits on the inside, and how it attaches into the Achilles tendon will prevent [ankle dorsiflexion](https://en.wikipedia.org/wiki/Anatomical_terms_of_motion#Flexion_and_extension_of_the_foot)

**Tell people what dorsiflexion is**

- Ankle dorsiflexion is basically this motion when I am walking ‒ pulling the toes back, pulling the foot back

![](https://peterattiamd.com/wp-content/uploads/2024/03/f16-courtneyconley.png)

**Figure 16. Dorsiflection versus plantarflexion**. Image credit: [Biology Dictionary](https://biologydictionary.net/plantar-flexion/)

**Explain what plantarflexion is**

- Pointing the toes and extend the foot
- We need about 10-15 degrees in that ankle dorsiflexion in a **walking gait cycle**
- You’d be surprised how people like to cheat the system there
- When we get to medial gastroc, we look and see how their ankle mobility is?
  - Is it something that needs to be addressed?
  - How is their foot strength? (does that need to be addressed?)
  - How is their capacity?
  - ***It’s never just a foot problem***
- When Courtney watches someone walk ‒ walking is this internal rotation when our foot hits the ground
  - She doesn’t want the plantar fascia to be down there like a dishrag
  - Not only is she assessing what’s happening at the foot, but she’s looking at the **knee** and the **hip**
    - Who’s driving the car?
  - How well can the [glute max](https://en.wikipedia.org/wiki/Gluteus_maximus) control the rotation, control pronation?
    - Is that having an effect on the structures of the foot?

***When she looks at those cases, especially with chronic heel pain, it’s never just a foot thing. She has to carry it up into the rest of the chain***

**Peter’s takeaway:** *because the plantar fascia is so long, you can have pain in many different places, and the real estate on the bottom of the foot that is susceptible to inflammation or irritation of the plantar fascia is pretty long*

**Is it typically more posterior and close to the heel?**

- Most of the fibers that were more commonly irritated are medial
- There’s different branches of it
- Most patients will get that pain at the heel, maybe more on the inside of the heel, and it can be pretty classic where it’s really painful in the morning and then as they walk on it, it gets better
- That can change its space a little bit depending upon how chronic it gets

***All roads keep pointing back to the plantar fasciitis as a canary in the coal mine, that your feet are weak***

- That tie bar mechanism that we spoke of, that free mechanism of the vertical and horizontal stability that we have at the foot, take advantage of that

***Allow the foot and the toes to splay and do a couple foot strengthening exercises, and it doesn’t have to be difficult***

- We’ll give people lot of those exercises to do when we go to the gym later on

## Posterior leg muscles: strength assessment methods, role in ACL injuries, and more  [59:15]

- As the name implies, these are muscles that originate out of the foot but presumably have tendinous attachments within the foot
- You have the medial aspect and you have the lateral aspect, and then you have the posterior aspect.
- If we were to start with posterior, and we’ve talked about that a little bit already.
- The gastroc [soleus](https://en.wikipedia.org/wiki/Soleus_muscle) communicates through the Achilles tendon down around the calcaneus and attaches right through the plantar fascia to the forefoot
- The soleus is the largest muscle of the lower leg
  - He’s the one that produces a lot of that force at the forefoot when we walk
- The soleus has more type I fibers (slow twitch muscle fibers) than the gastroc
- The soleus is really the workhorse that can keep going and going
  - Maybe it doesn’t generate as much force as the gastroc, but it has far more endurance
  - It’s very important in the prevention of [ACL injuries](https://en.wikipedia.org/wiki/Anterior_cruciate_ligament_injury)
    - Which is counterintuitive given that it’s below the knee
- When you look at any ACL protocol, it’s always hamstrings ([biceps femoris](https://en.wikipedia.org/wiki/Biceps_femoris_muscle)), all medial hamstrings, strengthen, strengthen, strengthen
- But research has shown that it’s the strength of the soleus that prevents tibial progression
  - If you can resist the tibia moving forward, you prevent the stretch on the ACL in that hit
- If you look at the capacity of the soleus, there are numbers out there regarding a seated calf raise
  - When you’re seated, the gastroc is not your big player
  - You’re focusing on the soleus ‒ it’s supporting 1.5x your body weight
- For a **single leg calf raise**, you need a [Smith machine](https://en.wikipedia.org/wiki/Smith_machine) to do the test
  - One foot is doing all the work
  - You’ve got a lot of padding on top of the lower femur so that you can load the bar from the Smith machine directly over the tibia and fibula
  - Peter wanted to do 6 reps at 1.5 times body weight
    - He got up to 1.3 times his body weight and was like, “*Is there any way a human could do 1.5 times their body weight?*”
    - Clearly there is, but he was blown away at how difficult that was
    - He generally prides himself in being able to do the metrics that are considered minimum metrics of human performance (this was a fail)
- One of the biggest assessments Courtney does with patients is determine a baseline of where they are
  - She see’s ultra runners, athletes

***Everybody fails this test, and they fail it miserably***

- Peter has talked to [Kyler Brown](https://www.sportsfitmassage.com/about-us/meet-our-staff/kyle-brown-dpt-ocs/) about this
  - He works with some of the best athletes
  - He pointed out that sometimes the better an athlete you are, the better you are at cheating

***Sometimes you see really good athletes who can do amazing things and yet they have very poor calf strength and you can’t understand how that’s the case***

**How is this the case?**

- They are very good cheaters, but eventually something’s got to give
  - And whether that’s going to be today with the athlete or it’s going to be 10 years down the road
- When you are not using your [plantar flexors](https://biologydictionary.net/plantar-flexion/) in a **walking gait cycle**, when that strength capacity isn’t there, it’s going to rear its head at some point
- You might be a fast runner, but imagine if you started to actually strengthen the muscles that made you fast
  - Some of the best marathon runners in the world have the longest Achilles tendons
  - We have the spring of the tendon, we have these gastroc and soleus that can isometrically contract very strong and then transfer this force

***The strength of the lower leg is so powerful, and to be able to take advantage of that, we have to do it***

## Lateral and medial muscles: ankle stability, arch support, big toe stabilization, and exercises to strengthen and prevent injuries [1:04:15]

- Courtney mentioned a lateral and medial set of muscles that seem to cause a lot of pain

**What are those large muscles?**

*Lateral ankle stability*

- The [peroneals](https://en.wikipedia.org/wiki/Human_leg#Lower_leg_and_foot) are the big boys on the outside
- The [peroneus brevis](https://en.wikipedia.org/wiki/Fibularis_brevis) is going to insert on the 5th metatarsal [shown in the figure below]
  - It’s a powerful evertor of the foot
  - That’s going to take us from this position towards the big toe
- The [peroneus longus](https://en.wikipedia.org/wiki/Fibularis_longus), also on the outside, wraps underneath the foot and inserts on the medius aspect of the foot
  - Down on the outside of the food, around and under to the medial, to the big toe
  - When it contracts, it flattens the arch

![](https://peterattiamd.com/wp-content/uploads/2024/03/f17-courtneyconley.png)

**Figure 17. Location of the peroneus brevis and peroneus longus in the lower leg**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Fibularis_muscles)

- When peroneus longus contracts, it pronates

***What the peroneus longus does is evert the foot, and most importantly, this is why the peroneals are a very big stabilizer of your big toe***

- Which is counterintuitive because on the opposite side of the foot
- The peroneus longus is the one that goes underneath the foot, and when he’s doing his job
  - We call it dropping the head of the 1st metatarsal
  - Basically what that means is it takes that bone, the metatarsal and it anchors him to the floor so that we have a stable position at push-off

*One of Peter’s favorite exercises*

- Is putting a band (like an elastic) under huge tension on the floor, and pulling medially such that the only part of himself he lets contact the floor is the base of the big toe, and then doing **single leg balance drills**
  - That’s actually strengthening outer leg, and this is very important
- When patients have ankle sprains, remember we’re losing sensation
- You can have dysfunction of your peroneals
- When you’re walking, because peroneus longus drops that first metatarsal down, he’s anchoring your big toe to the ground
  - If he’s not doing his job, this guy will stay elevated, so he’ll stay lifted a little bit
    - Now when you’re walking, you don’t have this stability at your first ray
    - So you’re either going to go to your outside again (which means another ankle sprain), or people will complain of a pinching on the top of the big toe
- There’s a difference between a bunion ‒ this is when it comes out (versus a bump on the top of the toe)
- If you’re walking and you don’t have that first metatarsal dropping, when your big toe tries to extend, it doesn’t have this nice rolling glide
  - It jams first, and then you get this irritation on the dorsum aspect of the toe and it’ll get red irritated
  - That’s what we would term a **functional hallux limitus** ‒ a restriction of motion at the big toe
- It all stems because there is not enough muscular force from the lateral musculature of the foot (the peroneals) to bring the base of the toe down
- Unless there’s been trauma, for instance if you’ve dropped a weight on your toe or had surf toe where’s there’s been an accelerated inflammatory response

***Functional hallux limitus is a dysfunction at that first ray, which is often caused by a weak foot***

> “*This is a common theme here: instability of the outside of the ankle (ankle sprains), and if those movement patterns are not restored and regained, then you start to have this arthritic change at the big toe… It will alter gait. It will alter movement*.”‒ Courtney Conley

## Importance of strength of lower leg muscles for gait and preventing shin splints, stress injuries, and more [1:08:15]

**Is the big meaty muscle on the outer part of your shin the** [**tibialis anterior**](https://en.wikipedia.org/wiki/Tibialis_anterior_muscle)**?**

- Correct

![](https://peterattiamd.com/wp-content/uploads/2024/03/f18-courtneyconley.png)

**Figure 18. Location of the tibialis anterior**. Image credit: [PhysioAdvisor](https://physioadvisor.com.au/injuries/ankle/tibialis-anterior-tendonitis)

- The tibial anterior comes down and then tibial anterior tendon
  - You’ll see it more on the medial aspect of the foot, it’s a dorsiflexor of the foot
- We were just talking bout the lateral compartment, and now we’re in the front of the lower leg
- In the front of the lower leg is where tibialis anterior and all of your extensors live
  - They extend the toes

**Why do we have toe extensors out of the foot?**

- With gait, we always talk about what’s happening in “stance phase”
  - There’s **stance phase** when the foot is on the ground, and then **swing phase** when the foot’s in the air
  - And the reason why a lot of us give so much attention to stance phase is because that’s where all the magic happens, all the load
  - But swing phase when we’re walking, you have to clear the ground
- When Courtney is assessing gait, she will often close her eyes and listen because you’ll **hear the scuff** where a patient can’t clear the ground
  - These will be your runners that come in and tell you, “*When I’m running, I keep tripping over rocks*.”
    - Courtney asks, “*Are you really tripping over rocks or what’s happening here?*”
    - Because if those tissues can’t extend the toes and extend the foot when they’re running or walking, they’ll scuff the ground and you can hear it
- They are responsible for a clearance and swing phase, but then also at heel strike, here’s that eccentric component
  - When my heel strikes the ground, here’s my extensors
    - They have to be very strong eccentrically because they’re going to decelerate my foot hitting the ground

***If you don’t have good control of those pre-tibial muscles, tibialis anterior and your extensors, it’s like an elephant is walking down the hallway, you’ll hear foot slap after foot slap***

- These patients will tell you they have shin splints
- They have medial tibial stress syndrome because they just can’t handle the repetitive motion of their foot slapping the ground without control of those muscles

**The medial aspect is where you’ll see a lot of injuries as posterior tibialis**

![](https://peterattiamd.com/wp-content/uploads/2024/03/f19-courtneyconley.png)

**Figure 19. The tibialis posterior muscle**. Image credit:[TeachMeAnatomy](https://teachmeanatomy.info/encyclopaedia/t/tibialis-posterior/)

![](https://peterattiamd.com/wp-content/uploads/2024/03/f20-courtneyconley.png)

**Figure 20. The tibialis posterior tendon**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Tibialis_posterior_muscle)

- The posterior tibialis comes down along the medial aspect of the foot, and it’s a very big stabilizer of the inside of the foot
- Peter notices, “*It’s very difficult to disentangle it from the gastroc, the medial head of the gastroc, isn’t it? They seem very close to each other.*”
- If you were to put your foot on your knee, point your toe and bring the sole of your foot towards the ceiling, you’ll see a tendon that kind of pops up along the medial aspect of the foot ‒ that’s post tib

***The posterior tibialis, decelerates pronation***

- If you look at EMG activity, you will see activation from that guy from the second the foot’s on the ground until propulsion

***It’s one of the only muscles where you’ll see this constant activation and therefore we need to pay attention***

- Because of its attachment, it rotates
  - That tendon has a 45 degree rotation before it inserts
- When we talk about those energy storage tendons of the Achilles and the post tib: very, very important for free energy and propulsion
- And because of how it attaches, it has to be trained in those planes, in rotational transverse planes

## Tendinopathies and other common pathologies related to the anterior and lateral compartments of the foot [1:13:00]

**What are the most common pathologies you see due to the anterior and lateral compartment?**

- We’ve discussed one of them already
- Probably the most common diagnoses that we will see is heel pain: plantar fasciopathy
- There are lots of [tendinopathies](https://en.wikipedia.org/wiki/Tendinopathy): your Achilles tendinopathies, posterior tibialis tendinopathies, peroneal tendonitis
  - We know that these tissues need movement
  - We know that these tissues need load.
  - Yes, we want strong calves, but from a tendon perspective, we want a tendon that is healthy, which means you have to load it
    - And that goes for both the Achilles as well as post tib, as well as your peroneal

*Is that predisposed by lots of ankle sprains?*

- It can be

*Is that more a function of just weakness in the musculature?*

- There’s a lot of factors you have to look at
- Do they have the integrity of the musculature?
- Have they had a history of ankle sprains that have just never been rehabilitated appropriately?
- Think of the post tib and the peroneus longus as a sling: it’s this beautiful sling that stabilizes the foot and they work together
  - And when you have one side that’s not helping out the other side, you can start to have these changes within the foot

![](https://peterattiamd.com/wp-content/uploads/2024/03/f21-courtneyconley.png)

**Figure 21. Muscles of the lower leg including the fibularis longus (aka peroneus longus) and tibialis posterior (aka post tib).**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Fibularis_brevis)

**How often does imaging play a role in diagnosis?**

- Imaging is used to rule out stress fractures, especially when you’re dealing with runners and things like that
- As far as everything else, if you look at research on doing MRIs for for tendinopathies in Achilles, it really doesn’t give you all that much information that’s valuable because you can see a tendon on an image and it’ll be like, “*Wow, what’s going on here?*”
- Peter notes this is not that different from the back where a lot of people will feel nothing but their MRI looks horrible [back pain was discussed in [episode #287](https://peterattiamd.com/stuartmcgill/)]

*What’s the diagnostic test of choice for a stress fracture?*

- A diagnostic ultrasound can be more accurate

**Injury of the Achilles tendon**

- Peter doesn’t know what it is in his old age that has made him so paranoid of an Achilles injury
- He had one bout of tendinopathy there that took probably 3 months to resolve
  - In that 3 months he didn’t really have to do anything different, he did a lot of training, but he would wake up every day in quite a bit of pain
  - It got better as the day went on, but it was uncomfortable
- He had this huge panic that at some point he was going to tear it doing some of jumping exercises

**How much of that is due to tissue pliability of aging as an additional predisposing factor? Clearly there’s a load component to this, right?**

- Yes
- Courtney explains that Pete was lucky that his resolved in 3 months

***Tendinopathies at the Achilles take years [to heal]: for 5-10 years people will still experience symptoms at their Achilles tendon***

- A lot of Courtney’s work in talking to patients with Achilles tendinopathy is the education part
  - Most people are afraid that they’re going to rupture their Achilles tendon and she has to remind them it is one of the most robust tendons that we have

***There’s less of a chance of you rupturing the Achilles tendon, but you have to be aware of that discomfort is probably going to stick around for a lot longer than you want it to***

- During rehab, often when you wake up in the morning is when you’ll feel that tendon stiffness
- Using a [VAS scale](https://en.wikipedia.org/wiki/Visual_analogue_scale), if the patient is sitting at a 5 out of 10, that’s a green light for us
  - That is not rest, that is still go
- Peter was never a 5 out of 10, but he’s a guy who’s lived at a 0 out of 10 in his Achillis
- He’s had a lot of pain in other parts of his body, but to wake up every day and be at a 5 out of 10, just walking to the bathroom, “*Good lord*.”
- Peter relates, “*That was very frightening from the standpoint of is this a harbinger of a catastrophic injury?*”

**3 types of Achilles tendinopathy (or injury)**

- Each are looked at very differently
- 1 – When most people talk about an achilles tendinopathy, it’s at the mid-tendon portion
  - If you were to squeeze your Achilles tendon right in that mid-portion, those are typically the easier ones to treat
- 2 – Then you have an insertional Achilles tendinopathy where that irritation is at the calcaneus
  - Right where it inserts those can be extremely difficult because with those, the Achilles tendon breaks down on the front of the tendon
- We know that **tendons need load**, so for #2, you have to make sure when you’re doing your calf work, that you’re getting as high onto your toes, end range plantar flexion so that you can start to load that appropriately
- Those guys don’t like to be stretched all that much
- There’s different things that you do based on the location of where that tendinopathy occurs

Peter asks, “*In that case, you would really minimize any dorsiflexion… You wouldn’t go on a super deep dorsiflex.*”

- Mild: yeah, like off the stair
- Everybody loves to do off the stair stuff and Courtney asks, “*Can you do it without? How does your form look without going into a negative?*”
  - Because when you drop that heel down into a negative, if you don’t have good midfoot stability and the whole thing just looks sloppy, and that’s game over for her

## The importance of midfoot integrity, ankle dorsiflexion, and a discussion of gait alterations [1:19:45]

- We talked about what the midfoot is anatomically
- It’s a very common movement to want to do a negative when you’re doing a toe press of some sort

**What needs to be true of the midfoot for a person to be able to do that?**

- When you are looking at someone from the back, and if I was looking at them with their heels off the back of a step: as they go into that negative, if they can maintain the integrity of their foot
  - In other words, when they drop the heel down, you don’t want to see this collapse or this excessive medial drive where the whole foot just looks like it can’t even hold itself up

*Presumably those are more intrinsic failures or are they potentially also extrinsic?*

- It could be a bunch of things
- It could be everything down to the ligaments
- If they have poor ankle dorsiflexion mobility, they’re going to steal it

**What’s the minimum angle of dorsiflexion you need to be a functional human who can walk?**

- We need about 10 degrees for a walking gait
- Running, you need a little bit more
- When Courtney is training someone, you don’t want to train minimum degrees
  - You want to give people movement variability ‒ the more movement variability someone has, the less “oh no” moments we have.
- You can assess it with your iPhone
- Courtney measures dorsiflection and she likes to see about [35 degrees](https://academic.oup.com/biomedgerontology/article/61/8/866/589349)

***If you sit in a chair or walk up and down stairs, you need ankle dorsiflexion***

**Ankle dorsiflexion is a huge lack of range in the foot, and there’s 3 big compensations that you will see for people that don’t do that**

- 1 – When they’re walking, they’ll lift their heel up early (it’s an early heel rise)
- Remember we talked about 8x your body weight going through your forefoot
  - Do I want to increase that load? No
  - Do I want to speed it up? No
- 2 – Next, what people will do is they’ll hyperextend their knee
  - It’s called a “varus thrust gait”
  - Because they can’t dorsiflex, the knee tries to help you: let me hyperextend to propel you forward
  - These patients will come in and tell you, “*My knee feels wonky. The back of my knee feels unstable*.”
    - And you have to look at the ankle because it could be feeding why they’re doing… That hyperextension at their knee could be the reason

**How do these people find you?**

- Peter points out that her fame is through treating the foot
- He wonders, “*Are they finding their way to you because they’re hearing you on a podcast talking about just that? Or are there other practitioners that are aware enough to recognize knee pain and say, actually your knee pain is a compensation for your gait?*”
- Courtney has been teaching these courses for a while, and she thinks a lot of the referrals now are coming from other physicians, other PTs, other doctors
- She works with a couple of clinics in Colorado, and it’s been really awesome to see the medical community starting…
  - We’ve had patients who have hip replacements and the feedback on the other end of this sometimes is, “*You don’t need to retrain your gait*.” And now we’re getting a lot of these referrals and going, “*Yes you do. These are all things you need to pay attention to*.”

> “*The word is spreading about the importance of what happens at the foot and how that can affect pretty much everything else.*”‒ Courtney Conley

**Back to the compensations for weak dorsiflexion**

- 3 – People will simply fall forward, they’ll bend forward at their hips and use momentum to carry them forward
  - They come into the office with low back pain, and it’s because they cannot dorsiflex their ankle

Peter asks, “*Let’s say you make the diagnosis that their range of motion on dorsiflexion is insufficient, they’re at 8 degrees or even 10 degrees (which we’ve acknowledged is kind of the bare minimum for walking). What is preventing that person from being at 20 or 30 degrees? Is there something within the bone or is it neurologic where their body doesn’t trust itself enough to appreciate a greater angle?*”

- When you are assessing any joint, you want to see consistent patterns
- So if we were to take this with a squat, for example, when people try to deep squat, if they can’t do it, they’ll go down into a deep squat and they’ll be like, “*I just can’t go any further.*”
  - When Courtney asks why, they say, “*Well, it’s my hip or my ankle. My ankles just feel stiff.*”
- She’ll say, “*Okay, I want you to go over to my squat rack and you’re going to hold on to the squat rack and I want you to deep squat again*.”
  - If they still can’t do it, then she knows there’s got to be some type of muscle or joint restriction that’s preventing them from getting to that range
    - It could be muscles that have shortened
- We might need to implement stretching protocols
- We might have to implement joint mobilizations
- Down at the ankle, remember the talus, if he kind of floats forward, you can get a pinching
  - There can be a pinching in the front of the ankle when people try to stretch
- All of those things would be a consistent pattern because there’s a muscle or joint restriction

***If they can’t squat, but they can go into a deep squat as soon as they hold onto something, that’s a sign of a neurological inhibition ‒ this person is screaming for stability***

- In that case, your wasting time asking them to stretch calves for the next 30 years
  - You’re not going to see anything because that’s not what they need

## Proximal stability and its implications for posture and movement patterns [1:27:00]

- Then it comes down to **proximal stability**: how do we create stability?
  - How do we create a safe environment for their brain and their body so that they want to go into a deep squat because they need to go into a deep squat?

**Peter’s story about body positioning under anesthesia**

- He’s shared this story before and it’s worth sharing again
- When a person is under anesthesia, they can be stretched into positions that they would never imagine if they’re not under anesthesia
- They don’t get hurt
- You can take a person who can’t touch their toes, and when they’re under anesthesia, you could almost fold them in half
  - When they wake up from anesthesia, they will not have torn a hamstring

*How is that possible?*

***It’s possible because neurologically they are being inhibited from doing that because the body says you are not stable in that position***

- When Peter was so stiff that he couldn’t touch his toes, a guy took him through a 30-min exercise of increasing intra abdominal pressure, and within 30 min, his entire palm was past his toes
  - Did he get more flexible in 30 min?
    - Of course not
    - But by generating high degrees of intra abdominal pressure, his back relaxed enough that it allowed his body to move to that spot
- For Peter, this is one of the most difficult things to both identify, but more importantly, to be able to train because in a way it is a light switch
  - The circuit has to be grooved a lot for that to become the new default

**How do you go about doing that given A) its ubiquity and B) its complexity?**

- Courtney explains, “*Assessing patients for proximal stability is mandatory.*”
  - This coming from a foot person, far away from where we consider proximal stability and creating intraabdominal pressure
- When she looks at someone, she’s always going to take this down to the foot
- If you think of your pelvis as like a bowl of water, if you were to stand and dump out all the water, you would have a **forward tilt to the pelvis**
- That also can happen when the rib cage would flare, and we call it an “open scissor posture” [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/03/f22-courtneyconley.png)

**Figure 22. Ideal postural alignment versus the “open scissors” posture**. Image credit: [Pain2Performance](https://www.pain2performancechiro.com/post/the-closed-scissor-position)

- When Courtney assesses these patients, she’s looking at, “*Can they stack their rib cage over their pelvis? Do they have good breathing patterns? Can they breathe 360 degrees around their belly? Can they expand their rib cage?*”
  - Because if they cannot do those things and they stay in this posture
  - If you were to stand up and dump all the water out, tell me what would happen to your feet?
    - You’ll feel all of this medial pressure along your big toes
    - You’ll feel your arches collapse
- Peter adds, “*This is where pronation gets a bad name.*”
- Courney agrees and adds: [genu valgum](https://en.wikipedia.org/wiki/Genu_valgum), everybody says, “*Don’t let your knees knock.*”
  - She suggests you tell that to a hockey goalie who stands there for 3 periods in a valgus position at the knee

***Courtney doesn’t believe there’s any bad posture positions***

- It’s only bad if you can’t control it and you can’t get out of it
- You have to be able to do these things: you need to control it and be able to get in and out of it
  - You have to be able to protract your shoulder
  - You have to be able to arch your back

**Peter wants to double click on this point**

- Because it’s not a mainstream view, and yet he’s heard it enough from people who he thinks are hands down the best at movement that we should reiterate the point

***There isn’t a bad posture per se, but control is what matters***

- You could argue that the best movers on the planet frequently engage in what would be viewed as “bad posture”

*We weren’t all designed to look like these robots and be in these perfect postural positions*

- It’s just not realistic
- Think of golf: Courtney’s father is a big golfer and they used to watch [Arnold Palmer](https://en.wikipedia.org/wiki/Arnold_Palmer) swing a lot
  - And if you’ve ever watched Arnold Palmer swing, you’d be like, “*How’s this guy so good?*”
  - Being able to create this stability to your system and to be able to control these different postural positions is key to being able to get in and out of [these positions]

**Back to the foot, it’s not that pronation is bad**

- We have to do it
- It’s our first opportunity for shock absorption when we walk
- We have to be able to then get out of it
- Peter points out that the person most commonly who is in the open scissor pattern, they’re stuck in that position
  - They aren’t able to get out of it, and therefore they’re equally ineffective at shock absorption

*There’s a disconnect*

- When Courtney has patients tilt their pelvis forward, she asks them, “*What do you feel at your feet?*”
  - Half of the time they say, “*Nothing*”
- There’s this disconnect between pelvic motion and what your foot should be doing
- When your pelvis dumps forward, you should feel the feet drop
- When you tuck the pelvis back, you should feel the arches lift
- That’s the dynamic motion that the foot is capable of doing

## The age-related decline in foot sensation and strength [1:32:45]

- Earlier, Courtney referred to changes in sensory appreciation and [proprioception](https://en.wikipedia.org/wiki/Proprioception) as we age

**What changes in the sensory apparatus of the foot for a 50-year-old?**

- We know these factors contribute to falls

***Weakness in toe strength***

- There’s a big change from [age] 50 to 80, a 35% decline in toe strength
- Not only does strength decrease, but we have 4 different types of receptors, a couple fast adapting and some slow-adapting receptors
  - They’re responsible for gaining information so that we can maintain our center of mass,
- At age 50, it takes 20% more pressure to stimulate these receptors (versus when you were 20)

***As we age, the sensitivity of the receptors decreases: when we go from 50 to 85, at 85, we now have 75% decreased sensitivity to these receptors (that’s a lot)***

**What is driving that? [And what we can do about it]**

- Lack of strength at the foot
- Here’s the good news: we know **exercise** increases circulation to the sensory nerves
- If we exercise, we’re going to have increased circulation to our sensory system
  - We have increased nerve fiber branching when that happens
- With increased nerve fiber branching, we have increased sensation and that has been found to decrease pain and improve sensation even in patients with peripheral neuropathies

***Maintaining strength and function at your foot will decrease the decline of toe strength, but also increase the ability for us to feel the ground, which is imperative from being able to walk upright and being able to prevent us from falling***

**This sensory decline, how much of it is superficial?**

*Meaning you can test it and assess it using the standard metrics: take an alcohol pad or a cotton swab on the cutaneous branches and how much of it is much deeper?*

- There’s a [256 frequency vibration tool](https://www.amazon.com/ADC-Medical-Grade-Instrument-Non-Magnetic-Aluminum/dp/B004ETT7UM/ref=sr_1_5?crid=FUE0OUB2VXLW&dib=eyJ2IjoiMSJ9.o0FKh0Ph8dE1QGigBT-ZgoO_ptx3kKmGdzm3OsJ_k3r1i6j27nRbliAOfjQrhd656xRxh8ddqvo8Yojb1m9r-1yWvPfgB3M2mesj8g7CV_JnWr_Nh0FF93Clt4Ti7tWsEAduS2eV-OT41gvi1u5I9D6PyfsvEv8V_-sZN-RJg_q8ZA43QG-zFPdtXCvY8UNtT1Y3tS_AMXHgvkm3VlJYO7qr6uEoaUp0-BiOrqa93Ahu71x_5H-cTpiRxSvsBDugYMDSx-5WmPACqfSO5S8RTtCVH0Kgih8nCIom426QGts.ukNSoSmM5UuALYHNTIYn4Jycgc6ka9jmrLiKCSC6ziw&dib_tag=se&keywords=256%2Btuning%2Bfork&qid=1709073007&sprefix=256%2Btuning%2Bfork%2B%2Caps%2C131&sr=8-5&th=1), and what you can do is have the patient lay down and you take this 256 tool and tap it on the ground and put it on the base of their heel
  - You get 3 chances
  - You’re changing what you’re doing to see if they can they pick up the vibration
  - The accuracy of that test has been shown to be more accurate than the nylon pricking of the foot
- Peter finds this interesting, “*Vibrational sensation, that makes sense because that strikes me as a more complete form of sensation because the nylon thing is mostly cutaneous.*”

## Common toe injuries, treatment, and how to prevent further progression of the injury [1:36:30]

**Hallucis restrictors**

- Courtney sees this a lot and a lot of it has to do with poor footwear selection
- They’ve talked about the chronic ankle sprains and the inability to allow the first metatarsal to drop
- For a functional [hallux limitus](https://www.jawspodiatry.com/hallux-limitus-definition-symptoms-causes-and-treatment/), we need about 40-45 degrees of range of motion at the big toe in order to have an efficient walking gait
- Peter thinks this is his only superpower, he has about 90 degrees at his [hallux](https://en.wikipedia.org/wiki/Toe#Hallux)
- Excess range of motion is great as long as you can control it
- If you wanted to sprint, you would need 65 degrees because you’re more on your toes
- This is where Peter has seen a lot of former NFL players get horrible turf toe
  - They have what looks like 10 degrees
- What will happen is these patients will get inflammation on top of the big toe

*Is the primary pathology just the repeated jamming of that toe?*

- Yes
- Instability at the first ray, they can’t drop the first met down, so they start to irritate the top of the joint
  - It’ll be red, it’ll be swollen, and these patients suffer
- Courtney is on a Facebook support group for [hallux rigidus](https://en.wikipedia.org/wiki/Hallux_rigidus)
  - And it’s a constant battle for these people for footwear
  - People say, “*I need a shoe that’s going to eliminate me using my big toe*,” because it hurts when they try to extend it

*Have these patients all experienced trauma?*

- No
- If they’ve had something fall on their toe, if they’ve had turf toe, then yes

***But for a lot of them: this is weakness, this is poor footwear; and that’s why Courtney thinks a lot of these diagnoses at the foot can be prevented***

- This is proactive healthcare
- Peter talks about his eggs in his book [[*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZcgbQlnqFiCOpITpGSBWWFL5h9Xc0ydYgn05Sq4rdcdFHOX3biI55RAQlhdL2mghRL5zYgbAbOsC_bOrGuPd0a-SUIrg3nmvEapygxaVPL1w1-nNNybUNvFpN987qtQ0DkYj4Cgx0cBx7JvgJhdXbjecH0NahSW-SM1MyOMIDflZDImyi7E0mjQCec2JTQ_BL2-hqwBy_kdy6bs1ElMwWE0.uCCPkqDDojzKdpCYFXXj-GXbUghx48edNsVDuKtw31s&qid=1708618302&sr=8-1)]
  - Courtney loves that story

> “*There’s no better way to stop the eggs from being thrown than by taking care of our feet from the ground up*”‒ Courtney Conley

**Let’s assume that the trauma was in the past (it’s not an acute issue). Is the treatment the same where you have to get mobility back by strengthening?**

- Early intervention is better
- Even if there’s been trauma, you do not want to immobilize something
  - When you immobilize, it starts this cascade where you start to change the neurological input to the tissue
  - It will create an environment where movement will be altered
- Even in those initial stages, we’re doing big toe ranges of motion
- Courtney always tells her patients, “*I don’t get excited about you exercising your big toe, but you have to be.*”

**Peter injured his toe 3 months ago**

- He got hit on the front of the toe, it jammed the toe back
  - The entire side of the foot was black and blue
  - He didn’t get anything X-rayed because he didn’t think anything was broken
- He thought he’d ride it out, and he knew within a few days that nothing was actually broken because he could touch the bone
- The pain all seemed to be ligament pain
- It still hurts (not as bad), but it’s amazingly sore and it’s tender to touch the side
- That first weekend the thing was black and blue, and Courtney still had him doing isometrics
  - He’s still doing them by the way

*Anytime he’s in pain, 5 minutes of isometrics actually make him feel better. Why is that?*

- Courtney calls **isometrics** pain meds for her patients
- When someone see this kind of injury they think they should rest and do nothing
- Instead, she had Peter right away put his toes in a position of a little bit of extension (something that was comfortable) and contract on both sides of the joint
  - So you’re pressing down and then you’re trying to lift up
  - You’re getting some type of movement

***Whenever you feel pain, isometrics are safe for you to do because what they do is they decrease cortical inhibition***

- When we have an injury, think of it like a race car
  - We have a cortical accelerator, so information coming from our brain, and we also have brakes
  - We want the accelerator and the brake to be in balance of one another
- When we have an injury, our foot’s on the brake
- So if your trying to change your movement or improve your movement pattern, you’ve got to let off the brake

***That’s what isometrics do, they decrease that cortical inhibition, and to be able to do that right out of the gates is extremely important***

- Before the damage sets in and you create a long-term pattern of rigidity
- When you’re doing a calf raise for someone who has pain at their big to
  - They complain that it hurts too much, it’s pinching
  - Courtney will put a band around their ankle and pull it to the outside
- Remember that’s where [peroneus longus](https://en.wikipedia.org/wiki/Fibularis_longus) lives on the outside of the leg
- She’ll challenge it a little bit so that they really have to press through their big toe to keep their big toe on the ground
- When they do that, they’re like, “*Wow, that pinching is better*”
- Peter adds, “*There is something so magical about using bands for lateral and medial tension to produce the necessary engagement of the foot stabilizing muscles when you go and do other things.*”
- Courtney thinks the kinesthetic queuing is important, especially in those planes

> “*The foot’s this multi-directional beautiful thing that we can train so many ways.*”‒ Courtney Conley

**What else are you doing for the** [**rigidus**](https://orthoinfo.aaos.org/en/diseases--conditions/stiff-big-toe-hallux-rigidus) **patient?**

*How do you get the range of motion? How do you slowly introduce that range of motion back?*

- Obviously isometrics is a big part of it
- If they are in a [functional hallux limitus](https://my.clevelandclinic.org/health/diseases/25161-hallux-limitus), which means that they can still utilize their big toe based on if you increase strength of peroneus longus
- If we work on range of motion at the big toe, all of those things are key
- If you don’t do it then, it will progress into hallux rigidus
- Courtney doesn’t consider those [functional hallux limitus and hallux rigidus] the same diagnosis
  - Hallux rigidus: there’s been so much arthritic change to the joint that now you maybe have 5 degrees ‒ the toe is almost fused

**Peter’s takeaway:** *rigidus is associated with bony arthritic changes, whereas with limitus you can still move but you are limited because of the musculature*

- On a film you may start to see an exostosis or lipping
- There is [Wolff’s law](https://en.wikipedia.org/wiki/Wolff%27s_law), and they’ll start to have changes within the bone, but it’s still a functional joint
- That’s when Courtney gets excited because I’m like, “*Let’s do this. Let’s fix this thing*.”
- Because if not, if that progresses to hallux rigidus, and it’s game over
  - Now our treatment has completely changed
  - Meaning that she has to look at putting them in a certain type of shoe that’s going to rocker them through their toe because they now have lost four foot rocker
    - They cannot rocker through their toe

**What percentage of people with hallux limitus will progress to that phase of disease?**

- Unfortunately, quite a bit
- This message isn’t quite out there as much as it needs to be because those 2 diagnoses are often married
- When people start to see arthritic change at the toe, they’re like, “*Wow, this is hallux rigidus*.”
  - But it’s not actually
  - If Courtney drops your metatarsal down and can still give you 40, 45 degrees
- Without knowing that, and you start to have pain at your big toe, the initial intervention is a carbon plate under the toe
  - They sell these little inserts where you can put in your shoe so that your big toe isn’t bending at all
  - Some type of orthotic or very stiff shoe
- Patients are like, “*Oh, this feels great*,” but it’s because they’re not moving it anymore
  - If you stay on that path too long, you’ll lose the ability forever

**What happens up the chain with hallux rigidus**

- Patient’s can’t roll through their foot
- They can’t push off at 45 degrees out of their big toe
- So now they have more knee flexion
- Then their hip has to be hiked with every step (now it’s hip flexion)

**Courtney always wants to instill hope because there’s always hope**

- Even if patients have a fusion in their big toe, even if they have hallux rigidus and you’ve lost range at one joint
- But you haven’t lost range at your ankle, and you haven’t lost range at your knee or your hip
- Those ranges of motion will be compromised, but let’s just train them
  - Let’s rocker you through the big toe
  - Let’s give you drills to give you knee extension, to give you hip extension because we know you’re not going to have access to it any longer

*That’s where Courtney thinks she wants the 2 worlds to marr*y

- Oftentimes there is a time and a place for these surgical interventions, but once that’s done, there’s so much more that can be done so that we don’t start seeing sequela of that up the kinetic chain

## Preventing falls and managing arthritis with proactive foot care and exercises [1:46:45]

**How often are you seeing people that have autoimmune forms of arthritis in the foot and ankle?**

- It’s a smaller percentage of her patient base, but they do make their way to her office
- Often she will see that they have a lot of the arthritic change at the midfoot

*Aside from obviously the medical management of that with pharmacologic agents, what are the most important things you’re doing for those patients to foster midfoot mobility and strength?*

- She’s meeting patients where they are, and you’d be surprised
- Even patients that have had 3 and 4 foot surgeries, little things like toe yoga
  - Being able to lift the big toe only, lift the 4 toes, lift all the toes and spread them
  - All of those little things are sending information to your brain that these people haven’t seen in a very long period of time (if ever)
- With midfoot issues, **isometrics**
  - If Courtney can get even a little bit of isometric activity out of them, they’re doing it

**Is toe strength mostly a midfoot intrinsic capacity?**

- [Flexor digitorum brevis](https://en.wikipedia.org/wiki/Flexor_digitorum_brevis_muscle) is a big muscle in regards to toe strength
- Later, in one of the videos, she’ll talk about the “wink sign” because that’s a sign you can see in the toes to know you’re engaging the muscle appropriately
- That forward leaning, we want to be able to feel the intrinsic muscles of the foot, so feel the arch
- A lot of that helps these patients with this midfoot instability
  - The intrinsic muscles of the foot
- You know when people do the [short foot exercise](https://thefootclinic.net/short-foot-posture-exercises/)?
  - Courtney calls it the clamshell of the foot because it’s a good place to start, but it’s not functional because the intrinsic muscles of the foot come into play when the heel comes off the ground at forward propulsion, when those toes need to be strong
    - If she was treating you for hip pain, and she asked you, “*I want you to lay on your side and do clamshells forever.*”
    - That’s great but is it functional?

***So we have to marry these treatment plans with function***

- Especially with toe strength, you got to really work on that type of movement and tissue strength

**Falls**

- Earlier, Courtney said that the measurement of **toe strength** is one of the greatest predictors of fall risk
- Falls are a huge problem
- The mortality is enormous once you reach the age of about 65

*What do you think are the most important things that we need to be training to minimize the risk of a fall?*

- 1 – First and foremost, toe strength
  - That is the single biggest predictor of falls in the elderly is a weak toe strength
- Exercises are imperative
- You know how kids get scoliosis checks?
  - We should be checking kids’ feet
  - That’s when we need to start paying attention to this stuff

***If we start training these things, once we get to this age where toe strength is a massive deficit, we’ll be ready for it***

- Peter is very worried about what his toe strength is going to be when they bust out the [dynamometer](https://gaithappens.com/product/toe-dynamometer/)
- Courtney replies, “*Neuroplasticity is a real thing, so we can train that up for you.*”
- 2 – Ankle mobility is another one that she’ll look at

**Is ankle mobility more important in the plantar/dorsi plane or in the inversion/eversion plane?**

- In both

**Courtney has a fall prevention protocol that she put together with a colleague**

- 1 – Look at ankle dorsiflection ‒ you want that to be about [35 degrees](https://academic.oup.com/biomedgerontology/article/61/8/866/589349)
- 2 – Look at inversion and eversion (which is basically going in and then going back out again)
  - A lot of the receptors on the foot live on this outside lateral aspect of the foot
- A  lot of falls occur with the initiation of gait, and the other plane where people will fall is to the outside
  - When they go to step, if they have less sensitivity to these receptors on the outside of the foot, they can’t feel where they’re going
  - That’s why we’ll look at the ability of the ankle to have a good range of motion both in and out and going forward
- 3 – The other thing we’ll look at is balance
  - For example, we look at single leg balance
- There are really cool [studies](https://pubmed.ncbi.nlm.nih.gov/28575753/) looking at vestibular function, modulating activity of [abductor hallucis](https://en.wikipedia.org/wiki/Abductor_hallucis_muscle) [another [study](https://pubmed.ncbi.nlm.nih.gov/29524635/)]
  - Remember, that’s the muscle that straightens the big toe
  - Abductor hallucis is slow twitch muscle fibers, and it’s not really good at movement coordination per se, but it can last all day
  - From a balance perspective, it’s the muscles that are receptors that can really hold our bodies up and that abductor hallucis is a big boy

**You also want to look up the chain and see how stable are the hips?**

- Courtney explains, “*When my foot is on the ground, it’s my* [*glute*](https://en.wikipedia.org/wiki/Gluteus_maximus)*. When I go to heel strike, that guy is in charge. So I want to make sure I have good capacity going up into the chain.*”

*How much of that is the* [*glute med*](https://en.wikipedia.org/wiki/Gluteus_medius) *versus* [*max*](https://en.wikipedia.org/wiki/Gluteus_maximus)*?*

- It depends on where you are in the gait cycle
- When you’re walking at heel strike, that’s all glute max
  - Think of it as a skewer
  - You have gravity at heel strike that’s causing everything to internally rotate
  - The glute max is a very big controller of torque, and he’s going to slow things down coming from the hip
- Once you get into the midfoot stance (or loading), now you need to make sure you’re not saying all over the place
  - That’s [glute med](https://en.wikipedia.org/wiki/Gluteus_medius)
- All of those tissues come into play to help stability the body and slow everything down
- Courtney doesn’t ever give people gait cues when they’re walking because it’s just too difficult,
- If you squeeze your butt when you push off, all you’re going to do is throw yourself into too much lumbar extension
  - It’s at heel strike, and that’s when we have that eccentric control

==> For more on risk factors for falls and the importance of dorsiflexion check out [this study](https://academic.oup.com/biomedgerontology/article/61/8/866/589349)

## Footwear: advice for picking shoes that promote foot health [1:54:45]

**What can you do for your kids to save them some of these challenges?**

- For kids, just let their feet feel the ground as often as they can
  - On all different types of surfaces
- There are way more shoe and footwear companies now than there were 20 years ago, and word is catching on about the importance of all this

***With the kids… and with everybody, the toes need to be able to splay ‒ a wide toe box is non-negotiable***

*Are we defining that by the “insert test,” meaning put your foot on the insert and make sure that when your weight is on your foot you can still see the insert?*

- That’s probably the easiest way to access that
- Courtney cautions: companies are getting smarter, and they’ll change the upper of the shoe so when you put your foot in there, if feels like you have all this room
  - They’ll put in mesh
  - But it’s not because the shoe is wider, it’s just because they put a material on there where your foot can actually expand in it
- There’s also a very big difference between a *wide toe box* and a *wide shoe*
  - Those are two very different things
  - A wide shoe will still taper at the toe (not what we want)
- Remember the **tie bar mechanism**: you have to have that forefoot splay to trigger the response of, “*Hey, I better get stable at push off*.”
  - That’s when you need your toes to be able to splay

> “*A wide toe box is mandatory with kids’ footwear, adult footwear, whatever*.”‒ Courtney Conley

**Would the shoes Courtney is wearing be considered a wide toe box?**

- Yes, she’s wearing [Xero](https://xeroshoes.com/) shoes, and she’s a big fan of thes shoes
- There are so many companies out there right now: [Vivobarefoot](https://www.vivobarefoot.com/us/), toeless, she could go on and on [more [recommendations](https://gaithappens.com/favorite-products/) on her website]

**The other functional thing with footwear is looking at where the heel and toe sit**

- A **“zero drop”** is where the heel and toe sit on the same plane
  - That’s how we were designed to walk
- Most shoes (including running shoes) will tell you the heel to toe drop in mm (how many mm the heel is higher)
  - In Courtney’s world, anything that is not a zero drop is a high heel
- When Peter was having all of that Achilles tendinopathy, he switched the shoes he wears for rucking to a [GORUCK shoe](https://www.goruck.com/collections/ballistic-trainers) that has an 8 mm drop
  - He’s enjoyed that shoe much more
  - He no longer wears a minimalist shoe rucking because he’s carrying a lot of weight and wants more cushion
- He brings this up because there’s something about having that little bit of drop; he’s never had pain since making that switch

*Is it a mistake to choose a shoe with a little bit of a drop?*

- No
- There’s a big craze about the whole super shoe ‒ the [Nike Alphafly](https://www.nike.com/w/alphafly-running-shoes-1tp17z37v7jzy7ok) is an example
  - It’s the shoe that has the carbon plate
  - It’s a big shoe, the super running shoe
  - Presumably it gives you more energy
  - It has a difference in the midsole
  - The research will tell you, it gives you a 4% advantage
- Courtney always says, “*You have to earn your right to get into that shoe because it does change things*.”
  - For example, because it’s going to propel you, it might cause you to stride longer
  - With longer strides, you have to consider potential hamstring and Achilles injuries
    - You better be doing lot of hamstring strength and a lot of calf work
  - It has an additional stack height on it, which can also cause that kind of longer stride
    - Again, you better be able to handle that
- When you talk about shoes like that, Courtney calls them a “performance shoe”
  - They’re fine, but save that shoe for icing on the cake: your speed workouts
- Use a training shoe for the foundational work
  - Get your foot stronger, and give yourself the best possible outcome when you put that performance shoe on
- If you’re just relying on the shoe, Courtney can guarantee you’ll probably end up at her office because she sees it all the time

**Achilles injuries when you add 50-60 lbs**

- It takes work to be able to handle that amount of load in a minimal shoe
- If you had a history of an Achilles tendinopathy, if your baseline capacity isn’t where we know it should be, then if you need to wear that change
  - There is a time and a place for everything

***Courtney’s advice: if you are going to wear a shoe that has an 8 mm heel to toe drop, just do the work when you’re out of the shoe, and make sure you have plenty of ankle mobility***

- With an 8 mm drop, you’re shortening the posterior compartment
- Make sure you’re still doing all of your **plantar flexion strength**

**Other characteristics of the shoe: the sole**

- Here Courtney will give people a little bit of leeway
- #1 a wide toe box is non-negotiable
- If you’re standing on concrete all day long, if you work at a grocery store or if you’re in an airport, then having a little bit of cushion underneath the sole of the foot is going to be more comfortable
- Consider both ends: the more stack height on the shoe (the more cushion), it changes the rate of loading, it speeds us through pronation

***We’ve been talking about that all morning: we want to slow it down, we want to control it, and now you’re going to put something underneath the foot that’s potentially going to speed it up?***

- You better have a very strong foot and very strong extrinsic muscles to control that pronation

**Consider what you’re doing in the shoe**

- If you’re standing still, it’s fine to add a little bit of **cushion**
- But know that when you start walking with that thing, adding stack height and cushion will alter the rate of loading
  - That’s where the **thinner sole** can come into play
- If you walk with a shoe on that allows you to feel things: remember we talked about that calcaneus and how beautifully designed it is to handle shock absorption
  - We also have receptors in the heel that tell us, “*Hey, don’t land so heavy because it hurts.*”
- [Steven Sashen](https://xeroshoes.com/about-us/) (who owns Xero) has this ad that Courtney loves, he’s like, “*I don’t wear comfortable shoes and you shouldn’t wear comfortable shoes either.*”
  - It’s important for people to understand that it’s okay for your feet to be giving you a signal

**The importance of negative emotions [valuable feedback]**

- Peter points out, “*We live in a world where we’ve become so sterile to this and nobody wants to feel a negative emotion. You don’t want to feel sad, you don’t want to feel anxious, you don’t want to feel depressed, you don’t want to feel angry… Understandably, we don’t want to feel those things, but there’s an opportunity to understand why am I feeling that thing? And if I can understand why I’m feeling that thing, maybe I can get to the root of what’s actually going on.*”

***Peter thinks the way Courtney described that made him make that connection: we should actually think through foot pain***

- If we’re in a shoe that we deem a correct shoe and something hurts, maybe the signal is telling us, “*What are you doing wrong?*”

> “*It gives us so much information when you can actually feel the ground. I mean, everything. The proprioception, the receptor activity*.”‒ Courtney Conley

- When you have a lot of stuff underneath the foot, you can overstride and land really heavy (you’re not going to feel it), and that’s not what you want
- Walking is a grazing of the heel, and you want to feel what happens when your heel hits the ground

## Footwear for runners [2:05:30]

**Do you recommend people run in a minimalist shoe?**

- Peter points out that very few competitive runners today will run in a minimalist shoe
- It is very patient specific
  - You look at their history of traumas and injuries
- Courtney will always implement some type of functional footwear regardless
  - It’s just a matter of what we’re going to be doing with it
- For example, if someone just wants to **walk**: she’ll put them into a wide toe box shoe, zero drop shoe, and have them start with 5-10 minutes to see how they feel
  - Then we can start to transition the stack height
  - If they’re used to wearing this big bulky cushioned shoe, you don’t want to take them into something like this too soon
    - They’ll be like, “*This sucks and I don’t want to do it*.” And then you lose them right out of the gates

**For a person to run in a shoe like that, must they give up a heel strike in running?**

- When you change your footwear, you start to change how your body feels the ground
- With **runners**, for example, everybody gets all up in arms about **heel strike**: heel striking is bad
  - It’s not that it’s bad
  - It’s just where the load is going
- When you’re running, it’s not necessarily how your foot is striking, but where your foot is striking
- **Over striding** is the enemy
  - You do not want to have your foot well in front of your body when your running
    - There’s too much ground reaction force happening there
  - You want the foot to strike as close to the center of mass as possible
    - There have been runners who have won marathons with a heel strike that’s at their center of mass ‒ they just have more knee flexion

**That would almost feel like they’re falling forward, wouldn’t it?**

- Almost
- When you’re striking with a heel strike that’s in front of your center of mass, when your heel strikes, you have a lot of ground reaction force going through knee knee, your hip, and your low back
- When you switch and run to a **midfoot or forefoot strike**, all you’re doing is taking the load out of the knee, hip, and back and putting that into the foot, into the calf

**Theoretically, it seems like that’s how it should be. What do most elite runners do?**

- You will see all across the board different strike patterns
- When you are running efficiently, when you look at cadence and you look at what Courtney calls “running fairies” (because it just looks like they can run forever)
  - Their foot will be close to their center of mass, and it is more likely that they will be at a midfoot and forefoot strike when their foot is underneath them
- If you have a heel strike when running, then you have to go to your forefoot and drop that heel down again versus just running midfoot/ forefoot
- From an efficiency perspective, Courtney thinks that running midfoot/ forefoot is a more ideal position
- With that being said, if you have a history of heel pain, Achilles tendinopathy, and you’re told, “*Hey, we’re going to take you out of this heel strike and we’re going to get you to run on your forefoot*,” you’d better be prepared
  - You need to have good capacity at your foot and at your calf or else you’re going to have more foot and calf problems

## The importance of prioritizing footwear that promotes natural foot movement and strength while considering individual comfort and foot health needs [2:09:30]

**Are there any other characteristics of a shoe besides the big three you’ve mentioned?**

- You want to put the foot in its most functional position, and that’s the rule in allowing the foot to splay and in trying to keep it on a level ground
- You can play around with the stack height based on the activity
- There are shoes now with a wide toe box that still give you a 3-5 mm heel to toe drop
  - [Topo Athletic](https://www.topoathletic.com/)
  - [Altra](https://www.altrarunning.com/homepage.html)
  - These are good for transitioning the person who has poor ankle mobility and poor foot strength
    - Put them in a wide toe box and drop them down from a 10 mm to 5 mm [heel to toe drop]
    - Then start working on their strength and continue to drop them down into a more functional shoe
- Courtney is not asking everybody to run around barefoot all the time
  - It’s not realistic for hockey players, rock climbers

**Courtney’s advice for everyone**

- Do the work outside of the shoe
- Get a pair of minimal shoes, grab some toe spacers and walk around for 30 minutes a day
  - Keep it simple

**Is a good rule of thumb that a shoe is a wide enough toe box if you can wear the toe spacers in the shoe?**

- Yes
- Peter has never seen Courtney *not* wearing **toe spacers**, and he asks, “*Do you sleep in them?*”
- No, she doesn’t sleep in them
- But she does wear them all the time
  - She wears them to run as well
- She has a history of bunions (the hallus valgus)
  - Her doctor wanted to surgically current them but she refused
    - She also sees a high rate of failed surgery for bunions
    - Most foot surgeries have a high rate of failure
- Her foot has gotten so much stronger over the last 10 years

***Courtney wears toe spacers in all of her shoes and it’s helped her immensely***

![](https://peterattiamd.com/wp-content/uploads/2024/03/f23-courtneyconley.png)

**Figure 23. Toe spacers**. Image credit: [Gait Happens](https://gaithappens.com/product/toe-spacers/)

- The toe spacers she wears is from a company called [Podiatry Essentials](https://gaithappens.com/product/toe-spacers/)
- [Peter wears toe spacers made by [Naboso](https://www.naboso.com/collections/accessories/products/naboso-splay?utm_source=google&utm_medium=cpc&utm_campaign=brand&gad_source=1)]

*Peter notices a rigid thing in there. What’s that thing for?*

- Courtney puts cork into the to spacer in between the 1st and 2nd toe if a person has a bunion
  - This gives it a little more resistance there
  - In that toe splay, it gives the foot room
  - You have all these nerves that run in between the toes ‒ they don’t want to be squished together

*What is your recommendation for a person who’s never worn a toe spacer?*

- Walk around barefoot in your house wearing them for 5 minutes
- On your weaker foot, because you don’t have toe splay, the toes rub against the toe spacer and you can get a callous (or a corn), and that can be very painful
  - That happened to Courtney
  - It probably took her 6 months before she would wear toe spacers all day long on her weaker foot
- Now it takes Courtney half a second to put the toe spacers on ‒ she spreads her toes and they slide right on
- In the beginning when you’re trying to put these on, she’ll see people trying to wrench their toes apart because they simply can’t spread their toes

***Start with 5 minutes a day and then slowly increase your time***

- Then get a shoe where you can wear the toe spacer in the shoe
  - Think of it as just doing an exercise for your foot
- [Sarah Ridge](https://www.hartford.edu/directory/enhp/ridge-sarah.aspx) did a [study](https://pubmed.ncbi.nlm.nih.gov/30113521/) looking at strength of the foot
  - There were 3 groups: a control group, a group that just did foot strengthening exercises, and a group just wore functional footwear
  - They looked at four different muscles: [flexor digitorum brevis](https://en.wikipedia.org/wiki/Flexor_digitorum_brevis_muscle) (the one we talked about that supports the plantar fascia), [abductor hallucis](https://en.wikipedia.org/wiki/Abductor_hallucis_muscle) (the one that straightens the big toe), [quadratus plantae](https://en.wikipedia.org/wiki/Quadratus_plantae_muscle) (we didn’t talk about that guy, but he helps straighten the fourth and fifth toes), and [flexor hallucis brevis](https://en.wikipedia.org/wiki/Flexor_hallucis_brevis_muscle) (the one that bends the big toe)

***At the end of the study, the foot strengthening group and the functional footwear group were almost neck and neck***

- The only muscle that didn’t get stronger in the functional footwear group was the flexor hallucis brevis

*Does that surprise you?*

- Not really

**Peter’s takeaway:** ***That’s great news for the average person who doesn’t want to do the work because you’re just saying basically all I have to do is change my shoes, and things will get significantly better***

- Courtney replies, “*Imagine if you did both, though.*”
- But when you think about meeting a patient where they are
- By the time patients come to Courtney, they’ve had foot pain and want to get the job done
  - They’re getting shoes, toe spacers, and foot strengthening exercises
- Other people may start with one factor

> “*Where am I going to get the most bang for my buck? Put them in the right shoe*.”‒ Courtney Conley

**With kids, is there anything different?**

- Peter’s boys have never owned a pair of shoes that aren’t [Xeros](https://xeroshoes.com/) and they love them
- Courtney’s daughter is the same, she’s in middle school and when she wanted a pair of Nikes Courtney was like, “*I will do pretty much anything for you, but I’m not buying you a pair of Nikes.*”
  - Her brother chose to be the “good” uncle and bought them for her
  - Courtney lets her make the decision of what to wear to school, and she walks out the door with her [Altra’s](https://www.altrarunning.com/homepage.html) on because as she says, “*It doesn’t feel good.*”

***Kids will make the right decision based on comfort***

- If you start by showing them what their foot should feel like, then it’s an easier decision
- When you see bunions and hammer toes, it should be a signal that something is wrong
  - Where is this aberrant laid coming from?

**What do you say to men and women who want to wear more fashionable shoes?**

- Peter asks, “*If you really want to wear the most pointy toed Ferragamo, then you just have to make up for it when you’re not wearing that shoe?*”
  - 100%
  - And you have a higher burden of responsibility that comes with the privilege of being able to wear that shoe
- If you have a history of any type of forefoot pain, bunions, neuromas especially, and you want to wear a 4-inch stiletto
  - #1 be my guest
  - #2 you do the work on the other end of it or else it’s… do the work before, do the work after

**Peter is excited to now go into the gym and show people a bunch of the exercises and some of the diagnostics so that folks can begin the do-it-yourself process**

§

# EXERCISE VIDEOS

#### Video 1: Intro to Assessment and Treatment of the Foot

#### Video 2: Toe Strength Assessing the Anterior Fall Envelope

#### Video 3: Beginning Foot Awareness Drills

#### Video 4: Banded Toe Exercises

#### Video 5: Intrinsic Toe Strength ToePRO exercises

#### Video 6: Assessing for Ankle Mobility

#### Note from Courtney: When assessing ankle range of motion, you can use your iPhone to measure degrees. We should have ~34 degrees of upward motion at the ankle. The iPhone can be placed in the front of the leg as the front of the tibia is vertical during static stance. If placed on the back of the leg, there may be a difference of around 10 degrees based on muscle volume.

#### Video 7: Finding Pronation and Supination

#### Video 8: Midfoot Strengthening Exercise

#### Video 9: Single Leg Calf Raise Assessment

#### Video 10: Single Leg Calf Raises

#### Video 11: Seated Calf Raise Soleus Target

#### Video 12: Tuning Fork Assessment

§

## Selected Links / Related Material

**Foot education**: [Gait Happens](https://gaithappens.com/attiapod) | [1:15]

**Courtney’s clinic**: [Total Health Solutions](https://www.thsclinic.com/) | [1:15]

**Sectioning the anterior talofibular ligament**: [Elongation and forces of ankle ligaments in a physiological range of motion](https://pubmed.ncbi.nlm.nih.gov/2210531/) | *Foot Ankle* (B Nigg et al 1990) | [13:15]

**How footwear affects the development of the medial arch**: [The influence of footwear on the prevalence of flat foot. A survey of 2300 children](https://pubmed.ncbi.nlm.nih.gov/1624509/) | *The Journal of Bone and Joint Surgery* (U Rao & B Joseph 1992) | [20:00]

**256 frequency vibration tool**: [Medical-Grade Tuning Fork Instrument with Fixed Weights](https://www.amazon.com/ADC-Medical-Grade-Instrument-Non-Magnetic-Aluminum/dp/B004ETT7UM/ref=sr_1_5?crid=FUE0OUB2VXLW&dib=eyJ2IjoiMSJ9.o0FKh0Ph8dE1QGigBT-ZgoO_ptx3kKmGdzm3OsJ_k3r1i6j27nRbliAOfjQrhd656xRxh8ddqvo8Yojb1m9r-1yWvPfgB3M2mesj8g7CV_JnWr_Nh0FF93Clt4Ti7tWsEAduS2eV-OT41gvi1u5I9D6PyfsvEv8V_-sZN-RJg_q8ZA43QG-zFPdtXCvY8UNtT1Y3tS_AMXHgvkm3VlJYO7qr6uEoaUp0-BiOrqa93Ahu71x_5H-cTpiRxSvsBDugYMDSx-5WmPACqfSO5S8RTtCVH0Kgih8nCIom426QGts.ukNSoSmM5UuALYHNTIYn4Jycgc6ka9jmrLiKCSC6ziw&dib_tag=se&keywords=256%2Btuning%2Bfork&qid=1709073007&sprefix=256%2Btuning%2Bfork%2B%2Caps%2C131&sr=8-5&th=1) | amazon.com (2024) | [1:35:45]

**Study using vibration tool**: [Deficits in foot skin sensation are related to alterations in balance control in chronic low back patients experiencing clinical signs of lumbar nerve root impingement](https://pubmed.ncbi.nlm.nih.gov/25887249/) | *Gait & Posture* (L Frost et al 2015) | [1:35:45]

**For more on risk factors for falls and the importance of dorsiflexion check out**: [Foot and Ankle Risk Factors for Falls in Older People](https://academic.oup.com/biomedgerontology/article/61/8/866/589349) (Menz et al., 2006) [1:46:45]

**Role of the abductor hallucis in balance**: [1:51:45]

- [Foot muscle morphology is related to center of pressure sway and control mechanisms during single-leg standing](https://pubmed.ncbi.nlm.nih.gov/28575753/) | *Gait & Posture* (X Zhang, K Schutte, and B Vanwanseele 2017)
- [Vestibular-Evoked Responses Indicate a Functional Role for Intrinsic Foot Muscles During Standing Balance](https://pubmed.ncbi.nlm.nih.gov/29524635/) | *Neuroscience* (J Wallace, B Rasman, & B Dalton 2018)

**Shoes with a wide toe box**: [1:57:30]

- [Altra](https://www.altrarunning.com/homepage.html)
- [Vivobarefoot](https://www.vivobarefoot.com/us/)
- [Xero](https://xeroshoes.com/)

**Courtney’s recommendations for footwear**: [All our favorite products (plus exclusive discount codes) for your optimal foot and lower extremity health!](https://gaithappens.com/favorite-products/) | Gait Happens (2024) | [1:57:30]

**Toe spacers**: [2:12:00]

- [Toe Spacers by Podiatry Essentials](https://gaithappens.com/product/toe-spacers/) | Gait Happens (2024)
- [Naboso Splay](https://www.naboso.com/collections/accessories/products/naboso-splay?utm_source=google&utm_medium=cpc&utm_campaign=brand&gad_source=1) | Naboso (2024)

**Study comparing minimalist footwear and foot exercises**: [Walking in Minimalist Shoes Is Effective for Strengthening Foot Muscles](https://pubmed.ncbi.nlm.nih.gov/30113521/) | *Medicine and Science in Sports and Exercise* (S Ridge et al 2019) | [2:14:00]

**Anatomy of the foot**: [Functional anatomy of the foot](https://www.physio-pedia.com/Functional_Anatomy_of_the_Foot) | Physiopedia (2024)

§

## People Mentioned

- [Benno Nigg](https://contacts.ucalgary.ca/info/kn/profiles/196-1265) (Professor Emeritus of Kinesiology at the University of Calgary) [13:15]
- [Irene Davis](https://awards.research.usf.edu/profiles/?id=1363) (Professor of Physical Therapy and Rehabilitation Sciences at the University of South Florida) [48:45]
- [Sarah Ridge](https://www.hartford.edu/directory/enhp/ridge-sarah.aspx) (Professor of Physical Therapy and Rehabilitation Sciences at University of Hartford) [48:45, 2:14:00]
- [Karen Mickle](https://www.newcastle.edu.au/profile/karen-mickle) (Professor of Exercise and Sports Science at the University of Newcastle) [54:30]
- [Kyler Brown](https://www.sportsfitmassage.com/about-us/meet-our-staff/kyle-brown-dpt-ocs/) (Physical therapist and orthopedic specialists at Sports Fit) [1:02:45]
- [Steven Sashen](https://xeroshoes.com/about-us/) (visionary and marketer for Xero Shoes) [2:04:00]

§

![](https://peterattiamd.com/wp-content/uploads/2024/03/bio-courtneyconley-500x500.png)

##### Courtney Conley, D.C.

Courtney Conley holds a B.A. in Kinesiology, B.A. in Human Biology, and a Doctorate in Chiropractic Medicine. Dr. Courtney Conley is the founder of [Gait Happens](https://gaithappens.com/attiapod). She is pursuing her dream: helping as many people as possible reclaim their foot function.

In addition to Gait Happens, Dr. Conley is the head of patient care at [Total Health Solutions and Total Health Performance](https://www.thsclinic.com/team/courtney-conley), based in colorful Colorado. She is also a founding member of the [Healthy Feet Alliance](https://www.healthyfeetalliance.org/), an international team of practitioners who focus on the promotion of natural footwear to prevent unnecessary surgical procedures.

Dr. Conley is an internationally renowned foot and gait specialist who teaches globally on topics related to foot function, gait mechanics and strategies to combat foot and ankle pain. She is an author, educator, and lecturer, offering credentialed courses to medical professionals all over the world. She has written numerous professional education courses, contributed to textbooks, developed foot and gait protocols and created learning communities for health professionals and “human soles” alike. [[Gait Happens](https://gaithappens.com/attiapod/)]

Instagram: [@gaithappens](https://www.instagram.com/gaithappens/?hl=en)

Website (with curated offers for *The Drive* listeners): [Gait Happens](https://gaithappens.com/attiapod)