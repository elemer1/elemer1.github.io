# #305 ‒ Heart rate variability: how to measure, interpret, and utilize HRV for training and health optimization | Joel Jamieson

**Source:** [https://peterattiamd.com/joeljamieson/](https://peterattiamd.com/joeljamieson/)

---

Joel Jamieson is a conditioning expert who developed [Morpheus](https://trainwithmorpheus.com/) to give people a smarter way to build their conditioning regimen and improve their recovery. In this episode, Joel dives deep into the world of heart rate variability (HRV), explaining its scientific foundation, how it measures the balance between the sympathetic and parasympathetic nervous systems, the various methods of measurement, and how it can guide healthier lifestyle choices and improved training performance. He explores the nuances of HRV calculation, the impact of aging on HRV, and the roles of genetics, exercise, and other lifestyle factors in this process. He also covers Morpheus, the innovative training tool that won Peter over after his initial skepticism, highlighting its practicality and effectiveness in guiding training and optimizing fitness outcomes.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/joeljamieson/the_Drive_public.png)

Play

#305 ‒ Heart rate variability: how to measure, interpret, and utilize HRV for training and health optimization | Joel Jamieson

#305 ‒ Heart rate variability: how to measure, interpret, and utilize HRV for training and health optimization | Joel Jamieson

1x15s30s

0:001:51:55

## We discuss:

- Heart rate variability (HRV): evolution, science, and practical applications of HRV in athletic training [4:00];
- Methods of measuring HRV: EKG, wrist-based sensors, and more [11:30];
- How HRV is calculated from the data [22:30];
- The role of the autonomic nervous system (ANS) in regulating HRV [25:45];
- The decline in HRV with age, and the mitigating effects of fitness and other lifestyle factors [33:30];
- The role of genetics in HRV, the modifiability of HRV, and a comparison of VO2 max and HRV as predictors of mortality [37:00];
- How aging affects HRV and sympathetic drive, and the importance of spontaneous movement and exercise in maintaining the body’s adaptability [43:30];
- How Morpheus measures HRV using RMSSD and normalizes it to a 100-point scale for easier interpretation [49:45];
- The Morpheus system: development, integration with various metrics, and personalized daily training recommendations to optimize fitness and recovery [51:30];
- The benefits of morning HRV readings for assessing daily readiness compared to overnight HRV measurements [1:03:00];
- Why Morpheus recommends using a chest strap rather than an arm band [1:10:00];
- The impact of consistent exercise, stress, alcohol, and other lifestyle factors on HRV [1:11:15];
- Optimizing zone 2 training with Morpheus [1:18:15];
- Using heart rate recovery (HRR) as an indicator of athletic conditioning and the balance between aerobic and anaerobic systems [1:22:45];
- The importance of tracking HRV trends over time rather than focusing on data from a given day [1:29:00];
- Effect of GLP-1 agonists on heart rate and HRV [1:34:45];
- Where HRV belongs in the hierarchy of health metrics [1:42:00];
- Parting thoughts [1:46:30]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Joel Jamieson is the CEO and founder of [Morpheus Labs](https://trainwithmorpheus.com/) and [8WeeksOut](https://8weeksout.com/)
- *Morpheus Labs* aims to work with trainers and individuals to maximize training results using a combination of data science and physiology
  - Primarily through heart rate and heart rate recovery training systems
  - This system is used by a number of professional sports teams: NFL, NBA, MLS, NCAA
- *8WeeksOut* is a company that helps coach athletes and fitness enthusiasts to improve their strength, conditioning, and performance
- In this episode, we speak about what sparked Joel’s personal interest in the world of heart rate variability [HRV] and the history of HRV development over time
- We break down the science of HRV, how HRV is calculated (there are many different methods), and the interplay between the sympathetic and parasympathetic nervous system affects your heart
  - The reliability of tracking HRV
  - Ultimately, what it is that HRV is telling us about these autonomic nervous systems
- We talk about the decline of HRV with age
  - What drives this change
  - How much of it is within our control versus genetically predetermined
- We then talk about Morpheus, which is a product that ultimately led to Peter meeting Joel
  - Peter’s skepticism around Morpheus when he first began to use it
  - And ultimately why he came to believe it is a really valuable tool for people when they’re training
    - Especially people who might not be as interested in using lactate testing or other advanced forms of testing to fine-tune their training zone
- We talk about the impact of lifestyle choices on HRV and its significance for overall health
- How to use the data from HRV to inform daily choices
- Finally, we talk about HRV within the broader context of other health metrics and where it sits in the hierarchy of measurable insights
- While we speak extensively about Morpheus, please understand that Peter has no financial affiliation whatsoever with Morpheus
  - He’s not an investor, not an advisor, there is no affiliate deal with them (or any company)
  - Peter is simply a huge fan of this company and he recommends it to a number of patients
    - Because of his believe in its efficacy in helping people achieve their exercise goals
- We discuss a couple of other companies in this podcast that Peter does have relationships with
  - These have been disclosed previously and they are all on his [disclosure page](https://peterattiamd.com/about/)
  - He is a scientific advisor to a company called [Eight Sleep](https://www.eightsleep.com/)
  - He is a passive investor in the company [Oura](https://ouraring.com/)

## Heart rate variability (HRV): evolution, science, and practical applications of HRV in athletic training [4:00]

- [Heart rate variability (HRV)](https://en.wikipedia.org/wiki/Heart_rate_variability) is something everybody has heard of, people have a vague sense of what it is, but once you get beyond a superficial description of it, most people don’t really understand
  - Certainly people (Peter included) don’t understand how to use the data

**Before we dive into that, give folks a bit of your background and what brought you to study this**

- Joel has been using HRV for 20 years, and it’s really interesting to see the growth of it
- He was in his early 20s when he graduated from the University of Washington
  - He interned there and did strength and conditioning
- Then he progressed to the Seahawks to work with the same coaches
  - A track coach named [Randy Huntington](https://en.wikipedia.org/wiki/Randy_Huntington) was the USA Track and Field Jumps coach
    - He coached [Mike Powell](https://en.wikipedia.org/wiki/Mike_Powell_(long_jumper)), who broke Carl Lewis’s long jump world record in 1991
- Randy was a tremendous coach and when Joel was talking to him one day, asking him general advice for a young coach, he recommended he contact a guy named Val who would then tell him all about HRV (this was 20 years ago)
- Joel met Val at a hotel by the airport where he was instructed to take off his shirt and Val proceeded to pull out a big laptop, plug in wires, attach electrodes to Randy’s chest, ask him about his birthdate and weight
  - After 3 minutes, Joel sees all this stuff happening on the computer
  - Val then tells him about his recovery status, his readiness, his metabolic profile, his central nervous system
    - He explained, “*You’re much more strength oriented and your cardiovascular system’s not very good*” (which was accurate at the time)
- 20+ years ago, HRV was not something people were aware of
- The idea that you could take something out of a laptop, connect it with the body and have any idea physiologically about the athlete was completely new and foreign to Joel
- He immediately realized that he needed this
  - There’s so much of a black box when it comes to fitness
    - Sometimes he does a workout and gets better and sometimes he doesn’t. Why?
- Val explained the history of HRV, and this is interesting because it goes way back to the 1700s (awareness of beat-to-beat intervals)
  - The Chinese have used pulse medicine for a long time

**The Russians were ahead of the game as far as application of HRV**

- In the 1950s, they were aware that from an [ECG](https://en.wikipedia.org/wiki/Electrocardiography) you could pull out these beat-to-beat intervals and get something more than just heart rate
- When they sent the first human being in space ([Yuri Gagarin](https://en.wikipedia.org/wiki/Yuri_Gagarin)), they were able to send back the ECG and some respiratory data and see fundamentally what happened to people when you shot them into space
  - They saw as soon as he went into space, his HRV went way up
    - Probably because you have changes in blood pressure, you have less gravity so you don’t have to have as much muscle activity
- They started using this in the ‘60s, which is fascinating because it wasn’t seen in Western literature until decades later
- They dominated the Olympics in 1980
  - They had a very elaborate drug program and an elaborate training program

*In the mid-80s they started figuring out how to use this tech for sport performance*

- They put together an engineering team and they started collecting data on thousands of Russian athletes of all levels from their school age kids all the way up to the Olympic athletes
  - They collected just populational norms
  - They started building the system that was meant to monitor training and be used for training
- They spent years working on this platform, but before they could finish it, the Soviet Union collapsed and the team involved dispersed
- By chance, a lot of them were involved in track and field and different sports
- They ended up reconvening at a track meet in Eugene and talking about this past project
  - They decide that they want to get together and keep working on this because they’d never brought to fruition, and they did

***That was the first system commercially available for sport and fitness, and this is what Joel was introduced to at the time***

**The first HRV system**

- It was a very research heavy, medical type system that was not easy to interpret
- Joel didn’t have $35,000 to buy it, but he convinced them to let him help them introduce it to teams across the US and gain some exposure for them
- He started using it
- It gave you 12 or 14 different metrics of heart rate variability
- It required you to connect electrodes to people before you’d measure them

Joel explains, “*That introduction to it ,where I started this whole journey and 20 years of looking at data and coaching people and trying to understand what the data was telling me and how it aligned with all these other metrics, [it] has really just led down this path of how you get to heart rate variability today.*”

- He spent the next 20 years coaching with it
- Looking at HRV, he opened a gym, he worked with lots of fighters, athletes, different teams, military groups

## Methods of measuring HRV: EKG, wrist-based sensors, and more [11:30]

- When Joel was first introduced to HRV and it was done off an [EKG](https://en.wikipedia.org/wiki/Electrocardiography), Peter assumes that 3 leads would be sufficient
  - You could get it from 3 leads but they used 6

**Is EKG still the gold standard for measuring HRV?**

- Absolutely
- If you want medical grade, research quality HRV with the cleanest signals, ECG is the way to go by far

**Explain how an EKG works: what’s happening physiologically and electrochemically that’s enabling the capture of the signal**

- Peter thinks it will be relevant to distinguish between what an EKG is doing, what a chest strap is doing, what an optical sensor is doing on the forearm, on the wrist, or on the finger
  - These are all going to be the tools the technology companies are using to measure HRV
  - But there’s a total difference in the fidelity of the signal depending on where the signal is acquired
- The electrical signal of the heart itself is what we’re measuring with an ECG or EKG or chest strap
  - You’re literally measuring the polarization, repolarization of the heart as the chambers are beating and you get this electrical signal that gives you the [QRS complex](https://en.wikipedia.org/wiki/QRS_complex) [shown in the figure below illustrating the cardiac cycle]

![](https://peterattiamd.com/wp-content/uploads/2024/06/f1-joeljamieson.png)

**Figure 1. The cardiac cycle**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cardiac_cycle)

- We’re honing in on where those beat-to-beat intervals are because ultimately to get HRV, we need the exact amount of time from one heartbeat to the next because that’s what we’re quantifying
  - [3 beat-to-beat intervals are visualized in the ECG below]

***If you have an electrical signal, you get a very clear, clean signal that you can pull out those exact beat-to-beat intervals, and that’s where we fundamentally get heart rate variability from***

![](https://peterattiamd.com/wp-content/uploads/2024/06/f2-joeljamieson.png)

**Figure 2. ECG of a normal heart showing 3 beat-to-beat intervals**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Heart_rate_variability)

*Is it always done R to R because that’s the cleanest signal?*

- Yeah, it’s always done R to R
- You just have to be able to identify where the peak of the R interval is
  - The more accurately you can identify the peak of the R wave, the more accurately you can get that

*The P is the polarization of the atria and then the QRS is the ventricular: Is it the repolarization or the contraction?*

- It’s the contraction and the T wave is the repolarization
- The R wave is giving you the peak electrical signal of the contraction of the ventricle
  - Peter is sure there is a cardiologist listing who is going to scream right now
- You’re getting this exact electrical signal that’s showing us where that peak is happening and because it’s at high resolution and it’s electrical, we can pick that out pretty easily
  - The more leads you have, the more you’re going to be able to get that

Peter asks, “*If I’m wearing a Polar chest strap (which is what I wear when I’m on my bike), how is the fidelity of that compared to an EKG?*”

- It’s very close
- As far as picking out the actual peak of the R wave, it’s going to be within a millisecond (which is more than enough)
- Now obviously if you have a full 6-lead ECG, you’re going to get even more, but you don’t need it for HRV as long as you can identify that peak of the R wave precisely within 1 or 2 milliseconds of what it’s actually at
- The gold standard is from the ECG

***A millisecond (a thousandth of a second) is the unit that HRV is typically being measured in***

**If a person is looking at their HRV and they’re seeing a number that says 60 milliseconds, you’re saying with a chest strap you would put a plus/minus of 1 or 2 milliseconds on any reading that comes out?**

- Exactly; as long as it’s a good chest strap
  - The caveat is good skin contact and those sorts of things
  - If it’s moving around or it’s not in the right place, you can lose some of that
- You have a better chance of getting the signal correct with actual electrodes
  - That is really the gold standard
  - That’s how 90+ percent of the research has been done with either the EKG or with chest straps

**The use of these** [**PPG**](https://en.wikipedia.org/wiki/Photoplethysmogram) **(or optical sensors) really have only been around for the last 5-6 years**

- Traditionally their accuracy was questionable, and they don’t get the same electrical signal
- They’re measuring changes in blood volume through the skin
- Basically electrodes shine a LED light down into the skin and it reflects differently based on the blood flow flowing through the arteries below it
  - You’re getting the pulse and they actually call it pulse rate variability
  - It’s not really heart rate variability
  - If we want to get technical, it’s **pulse rate variability**, but it’s showing us the same thing ([the cardiac cycle](https://en.wikipedia.org/wiki/Cardiac_cycle#))

**Peter has observed a big difference between the wrist and the forearm**

- When he’s on his bike he’s doubling up
  - Wearing his [Polar chest strap](https://www.polar.com/us-en/sensors/h10-heart-rate-sensor) because it pairs perfectly with the bike system he’s using outdoors
  - Indoors, he rides with his [Morpheus chest strap](https://trainwithmorpheus.com/) and [Wahoo optical sensor](https://www.wahoofitness.com/devices/heart-rate-monitors/view-all?utm_id=go_cmp-11606786084_adg-116067098351_ad-502022228053_kwd-315507960929_dev-c_ext-_prd-_mca-_sig-Cj0KCQjw0MexBhD3ARIsAEI3WHKOOZuuhibVeGhmU-XZItxFxUV2e8fJmkm87c3-4UTSkHygckDfC5QaAkzoEALw_wcB&utm_source=google&gad_source=1&gclid=Cj0KCQjw0MexBhD3ARIsAEI3WHKOOZuuhibVeGhmU-XZItxFxUV2e8fJmkm87c3-4UTSkHygckDfC5QaAkzoEALw_wcB)
  - The Wahoo sensor on his forearm is pairing with his computer and that program he’s using there in ERG mode
  - The reason he’s using the Morpheus chest strap is he’s using the Morpheus program on his phone
- Peter brings this up to say they’re perfectly in sync, the chest strap (the gold standard) and the optical sensor on his arm are never off by more than a beat, and he can see them in real time concurrently
- Conversely, when he’s rucking, he wears a [Garmin GPS watch](http://v) that measures heart rate
  - It’s a very high-end watch, about $700, and it’s categorically a piece of garbage
  - A random number generator for heart rate
  - It can’t come close to estimating Peter’s heart rate
    - There are times he looks down and it says 170 beats per minute when he knows he’s below 100
    - Conversely, there are times when he is probably at 160 beats per minute and it says 110
  - He uses it for GPS

*Both of these use optical sensors. Why the difference?*

- 1 – Location
- 2 – To get a good resolution, you need good blood flow below the surface and you need lack of movement

***The biggest problem with PPG sensors (optical sensors as a whole) is they get what are called motion artifacts***

- Any kind of movement starts introducing noise into the signal
  - Because again, we’re not getting electrical signal
  - We’re just getting this blood flow going beneath the surface that we’re using the LEDs to detect for heart rate
- When you start moving around, you get lots and lots of motion artifacts and it just becomes much more difficult for the sensors to detect it accurately
  - Particularly in acyclic movements: anything where your arm is moving around at random
- Lots of things throw off PPG sensors: higher heart rates, darker skin colors, tattoos

***Optical sensors in particular struggle with higher intensities, higher movements, higher heart rates***

Peter asks, “*My optical sensor on the bike (even though… my upper body isn’t obviously moving), is it superior because it’s less movement or is it superior because it’s on much larger blood vessels?*”

- Both
- There’s this company called [Valencell](https://valencell.com/valencell-biometrics-lab/) that Joel uses, and they’ve done a lot of research on this because they produce the sensors
  - They’ve looked at any location, bicep, arm, wrist, calf, all of the above
- You have bone movement, even if you’re not really moving, your wrist can still be flexing and extending and just that wrist movement will cause motion artifacts

***You get much cleaner blood flow on the forearm ‒  you get just much less movement and torsion as you’re moving***

- You get just a much better overall signal on the forearm in general than you’re going to get from the wrist

***They’ve looked at the accuracy of Garmin and*** [***Whoop***](https://www.whoop.com/us/en/)***, and you don’t get very good accurate data at all as you’ve seen when you’re doing exercise***

- Even when you’re doing somewhat cyclical exercise, you can still get completely garbage numbers that make no sense because the sensor just can’t pick up the blood flow very accurately

> “*In general, the chest strap is always going to be the gold standard, but if you’re going to wear an optical sensor, the forearm where you can get good blood flow is going to be by far the best place to be able to put it*.”‒ Joel Jamieson

- You can even manipulate where in the forearm you tend to get the best signal and the best results

Peter asks, “*I don’t know if I’m doing it correctly, Joel, I tend to apply it right beneath the* [*antecubital fossa*](https://teachmeanatomy.info/upper-limb/areas/cubital-fossa/) *where I know the artery is running*.”

- Yeah, that’s what you want
- Peter also puts it on pretty snug
- You want good enough skin contact that it can read, but you ou don’t want to smash it in there

**Peter’s takeaway:** ***anything on the chest is the gold standard, if you do the forearm right, the heart rate is comparable, and anything below the forearm is nonsense***

- Joel explains that anything below the forearm is garbage especially if you’re lifting weights, doing interval training, doing anything high intensity, doing change of direction
  - It might be accurate sometimes, and sometimes it’ll be way off

**The one that seems to be more accurate of this group is the** [**Apple Watch**](https://www.apple.com/watch/?afid=p238%7CsNZgeoZeS-dc_mtid_1870765e38482_pcrid_692396963514_pgrid_99322576784_pntwk_g_pchan__pexid__ptid_kwd-52218226_&cid=aos-us-kwgo-watch--slid---product-)

- They can actually have ECG
- What Joel thinks they are doing is interpolating a bunch of data, and when they see bad data, they just replace it with what they think the data should be

Peter asks, “*So you’re saying the Apple Watch might be a step ahead of other wrist-based devices based on sampling and algorithm?*”

- You can detect when the junk data is there
  - You don’t have to display it, the other ones do, but they have enough previous data to know that your heart rate didn’t go from 110 to 160 in 2 seconds
- Wearing his Garmin, Peter has noticed that his heart rate will go from 100 to 150, and that’s not even physiologically possible
  - He wonders why they wouldn’t sample that out or ask a second-order question

## How HRV is calculated from the data [22:30]

- If anybody has seen an EKG strip, you’ve got little PQRST [see the figure below], and you line up a strip of those

![](https://peterattiamd.com/wp-content/uploads/2024/06/f3-joeljamieson.png)

**Figure 3. Labeled EKG readout where the time of the R-R interval is the beat-to-beat interval**. Image credit: [Morpheus](https://support.trainwithmorpheus.com/support/solutions/articles/4000202439-intro-to-heart-rate-variability)

- Let’s pretend we have a minute’s worth of data
  - The person is lying down, resting
  - Their heart rate is at 60 beats per minute, so the approximate beat-to-beat interval is 1 second on average (or 1000 milliseconds)

**What’s happening at the physiologic level that makes it such that there is variation, and how is that measured and calculated from the raw data?**

*Let’s start with the gold standard and assume you have an EKG*

- With this gold standard, we can accurately pinpoint where these R to R intervals are
- We pull out what are called the RR intervals and we’ll plot those
- Now from there you do what’s called correction basically
  - You have to filter data for [ectopic beats](https://en.wikipedia.org/wiki/Ectopic_beat), which are beats that don’t actually arise in a sinoatrial node
  - You fill out if there is any noise in the signal or anything like that, and you end up with this clean set of RR intervals

*What if I give you 60 numbers that vary from 900 to 1100 milliseconds?*

- This is where things get interesting because when we talk about HRV, we just usually give a number and that number can be different

***But a better way of thinking about HRV is just a framework to assess variability because there are multiple ways to calculate that***

**There’s one category called time-domain where we literally just do some math**

- The most common one is RMSSD (root mean successive square differences) where they just do some basic math and they get that number of milliseconds of RMSSD
- There’s all these different, call them time domain, where they just are taking that time series, doing some math on it and giving you a number that represents the average variability
  - There’s SDNN
  - There’s pNN50

***RMSSD appears to be the most common one, and what we are measuring is the average variability across that time span***

**Relationship between HRV and the parasympathetic nervous system**

- What that represents is the input of the [vagus nerve](https://en.wikipedia.org/wiki/Vagus_nerve) (the [parasympathetic system](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system)) and its input into that [sinoatrial node of the heart](https://en.wikipedia.org/wiki/Sinoatrial_node)
  - Because fundamentally, the [autonomic nervous system](https://en.wikipedia.org/wiki/Autonomic_nervous_system) is governing that heart rhythm
- When it is at rest, the parasympathetic system via the vagus nerve is innervating that sinoatrial node in the heart and it’s pulsing in beat with respiratory processes
- If you were to cut out the autonomic nervous system, you’d have roughly an intrinsic heart rate of about 100 beats per minute (somewhere in that range)
- As we inhale that vagus is inhibited and you get this acceleration of heart rate

## The role of the autonomic nervous system (ANS) in regulating HRV [25:45]

**Broadly speaking, we have 2 nervous systems**

- 1 – The [[voluntary nervous system aka the somatic nervous system](https://en.wikipedia.org/wiki/Somatic_nervous_system)] that’s under our control: movement, speaking, voluntary control
- 2 – The [autonomic nervous system](https://en.wikipedia.org/wiki/Autonomic_nervous_system) controls what people can’t see, the many things happening without any input
  - Without it we would forget to breathe and we would die
  - All the vital functions from respiration to heart beating to regulating blood pressure to digesting, have to happen via a nervous system that we never think about
- The autonomic nervous system is further subdivided into the [sympathetic system](https://en.wikipedia.org/wiki/Sympathetic_nervous_system) and a [parasympathetic system](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system)
- Joel has already alluded to one of the most important nerves in that parasympathetic system called the [vagus nerve](https://en.wikipedia.org/wiki/Vagus_nerve) (which is a cranial nerve)
  - It originates from a very primal part of the brain
- We won’t necessarily get into all the neurotransmitters involved in these things

***Basically the heart is under the influence of both of these***

*An extreme example that gets to this point*

- After a patient has undergone a heart transplant and that vagus nerve is transected, their heart is no longer under that control, and therefore it’s just going to beat like a metronome
  - You would see a heart rate variability of basically zero

***The context for people to understand is when you’re talking about a person’s heart beating at 60 beats per minute, there is still a very fine interplay between what the sympathetic nervous system is doing and what the parasympathetic nervous system is doing***

**Backup even more to explain the reason for the autonomic nervous system**

- The whole reason that we need this autonomic nervous system is to keep us physiologically within these normal ranges that we have to be in to be able to produce energy and stay alive
- If our blood pressure goes too high or too low, if our blood glucose gets too high or too low, if our body temperature gets, all of these things have to be within physiological norms
  - We call that [homeostasis](https://en.wikipedia.org/wiki/Homeostasis), that the internal environment has to be controlled at all times regardless of the external environment
- So whatever temperatures we’re in, whatever we’re eating, whatever we’re doing, we have to be able to regulate internally and stay within these physiological norms that are necessary for survival

***And that fundamentally is what the autonomic nervous system is doing: it’s keeping us alive, and it’s trying to match the internal demands with whatever we’re trying to do given the external environment***

**People have probably heard of these 2 branches of the autonomic nervous system: the sympathetic and parasympathetic**

- 1 – The [sympathetic](https://en.wikipedia.org/wiki/Sympathetic_nervous_system): the “fight or flight”
- 2 – The [parasympathetic](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system#): the “rest and digest”
- That’s good terminology to understand, but it makes us only think of the sympathetic
  - It’s not nuanced enough
- It also makes us think the sympathetic isn’t doing anything unless you’re under stress
- These things aren’t binary
  - They’re not switches that turn on or off

***A better way to think about these is dials that the brain is constantly manipulating***

*Fundamentally, what the autonomic nervous system is doing is twofold*

- 1 – It’s sensory
  - A lot of information has to go up to the brain to process what the internal environment status is
- 2 – Then the brain has to make decisions and push motor action down to the different organs to make sure that they’re doing what they need to do given the state of the body, given its external relationship with the world
- So fundamentally, the more we can regulate our internal environment and match the demands of our external environment, the healthier we’re going to be (with better overall function)

***The interplay between that sympathetic and that parasympathetic and making sure they can do their jobs appropriately is a really big piece of making sure that our bodies are going to stay healthy as we age***

**Fundamentally, if we look at aging as a whole, we lose adaptability**

- We lose the ability to respond to workouts as quickly
- We become more likely to become injured
- When we get sick it takes longer to get over that, and that’s just the body’s ability to regulate itself declining with age

**At rest we should have very little sympathetic activity going on**

- We have a pretty low level of sympathetic activity just sitting down or laying down
- At rest that parasympathetic dial is going to be higher because we don’t need this additional energy that the sympathetic system can drive
- At rest we are primarily measuring that parasympathetic input into the heart
  - As Joel mentioned, it turns on and off with our respiration
  - It’s called [respiratory sinus arrhythmia](https://en.wikipedia.org/wiki/Vagal_tone#Respiratory_sinus_arrhythmia)
    - It turns up and down just slightly as we inhale and exhale
    - But mostly what’s happening is we are inhibiting that vagal input as we breathe in and we are letting it function correctly (or not correctly), but we’re dis-inhibiting it as we breathe out
- So you’re seeing this pulsation-type effect of that vagus nerve on the heart rate accelerating and then slowing down, accelerating and then slowing down ‒ you’re seeing that input pulsing with our respiratory cycles

***When we measure HRV, we’re ultimately trying to understand that tone (we call it vagal tone), that input of the vagus nerve into the heart rhythm, and we’re using HRV to gauge as a functional marker of what our autonomic nervous system is doing (specifically the parasympathetic nervous system)***

**We want to see**

- How is it responding to the world around us?
- How is it responding to what we’ve done in the last 24/48 hours?
- What is its resting tone?
- How much input does it actually have?
- And from that, we then try to gain all the other insights we can talk about

**Most commercial devices are probably calculating HRV using the** [**RMSSD**](https://en.wikipedia.org/wiki/Heart_rate_variability#Time-domain_methods) **algorithm**

- It’s the root mean square of successive differences
- You’re basically going to say average (or mean) value is X, standard deviation is this, and then you probably do a sum square root of
- The [Apple Watch](https://www.apple.com/watch/?afid=p238%7CsNZgeoZeS-dc_mtid_1870765e38482_pcrid_692396963514_pgrid_99322576784_pntwk_g_pchan__pexid__ptid_kwd-52218226_&cid=aos-us-kwgo-watch--slid---product-) uses what’s called [SDNN](https://en.wikipedia.org/wiki/Heart_rate_variability#Time-domain_methods) (which is the standard deviation of the beat-to-beat intervals)
  - Historically, that one has been used medically
- The Apple Watch will usually measure it for 24 hours to see if you have any autonomic variation
  - It’s a gross measure to see if the parasympathetic system functions well
  - It’s not nearly as nuanced, because we’re not measuring vagal input at a particular time, we’re just measuring across longer periods of time
  - To Peter, it seems that this would introduce a bit of noise because you’re combining begin at rest with being active
    - It also seems to penalize people for being more active, because the more you exercise, the more sympathetic tone you have during exercise, the more you’re crushing the variability
- Joel explains, “*What’s interesting is Apple is just measuring randomly for the most part.*”
- You can do a manual measurement, which is a better way to do it
- For whatever reason, the Apple Watch uses this metric that nobody else uses, and they measure it periodically when you don’t know what’s happening
  - So you don’t know where this number comes from

## The decline in HRV with age, and the mitigating effects of fitness and other lifestyle factors [33:30]

**Peter remembers a couple things from an** [**AMA on heart rate variability**](https://peterattiamd.com/ama31/) **he did a couple years ago**

- Peter doesn’t think he went into nearly this level of detail about HRV
- He talked more about the mortality data and things of that nature
- Peter remembers a couple things:
- 1 – In the literature, there is a relationship between what was measured as HRV and all-cause mortality, and even disease-specific mortality
- 2 – There is a graph that Peter will never forget [shown below]
  - On the X-axis is age, on the Y-axis is HRV
  - He couldn’t believe how steeply it declined
  - If he’s not mistaken, there was an unmistakable trend where a 50-year-old’s HRV is less than half of a 15-year-old’s

![](https://peterattiamd.com/wp-content/uploads/2024/06/f4-joeljamieson.png)

**Figure 4. Middle 50% of HRV values by age**. Image credit: [Whoop](https://www.whoop.com/us/en/thelocker/what-is-a-good-hrv/)

Peter explains, “*I suppose that speaks to what you said earlier, which is one of the hallmarks of aging is this sort of lack of resilience. And we see it on every level, but this is just a very notable example, which is even at the level of the autonomic nervous system, we lose the ability to recover from insult. And life is an insult. Everything in life is an insult*.”

- Joel agrees, and when we are younger we respond much better

**Do you have a sense of what it is physiologically, at the cellular level, that is resulting in this profound reduction in HRV as we age?**

- They’ve looked at this and we don’t have a great answer for the exact physiological mechanisms
- We know it’s tied to mitochondrial density, mitochondrial function
- We know it’s tied to elements of the immune system
- We know it’s tied to hormonal status
- And we obviously see decreases in all those things as we age

*But we definitely know that we can increase our HRV, or we can at least prevent the decline most effectively through cardiovascular fitness*

- We see people with higher VO2s have higher mitochondrial function and that correlates with greater HRV
- We know that cardiovascular fitness, in general, seems to be the most closely tied to average HRV
- There is also a strong genetic component, which we can’t ignore
- If you look at [the hallmarks of aging paper](https://pubmed.ncbi.nlm.nih.gov/36599349/), they take these buckets of things [shown in the figure below]
  - They list all these things that happen as we age, and they kind of look at this prism of what’s the output?
  - As you age, you get dysbiosis, deregulated nutrient sensing, senescent cells, stem cell exhaustion, mitochondria…

![](https://peterattiamd.com/wp-content/uploads/2024/06/f5-joeljamieson.png)

**Figure 5. 12 hallmarks of aging**. Image credit: [*Cell* 2023](https://www.cell.com/cell/pdf/S0092-8674(22)01377-0.pdf)

***2 of the major things [that happen with aging] are loss of resilience to homeostasis and lack of a stress response that’s appropriate***

- It’s tricky to say which one is causing the other, but Joel thinks fundamentally aging is this progressive loss of adaptability
- There are multiple pieces to that
- One of the things that we want to gauge of HRV, is how much of that resilience or that adaptability are we losing as we age?

Joel explains, “*And that’s something we can influence through lifestyle and training and everything else that we’re trying to do here to prevent that slowdown*.”

## The role of genetics in HRV, the modifiability of HRV, and a comparison of VO2 max and HRV as predictors of mortality [37:00]

**How much genetics plays a role in HRV**

- This is something Peter doesn’t have a great answer for
- From his patient population, even though it’s not a huge n, there is years and years of data from these patients
  - Every single one of them is using some sort of device
- Many wearables and devices (including high-end mattress covers from [Eight Sleep](https://www.eightsleep.com/)) will measure HRV quite accurately ‒ there is endless streams of data

***There is an unmistakable difference between people***

- Focusing on RMSSD for an apples-to-apples comparison, Peter has patients who live at [an HRV] of 100 and a good day for them is 120, a bad day for them is 85
  - But if you follow them for 5 years, their average HRV is 100 milliseconds
- Other patients have an average HRV of 15 milliseconds
  - A good day for them is 25-30 and a bad day is 10

Peter asks, “*How could that be explained by something other than genes?*”

- It isn’t
- Joel has looked at a bunch of research, and it’s all over the map
- They say genetics is somewhere between 15-70% of HRV

***There is such a wide range in the research that it’s hard to know where the exact number falls, but you definitely see a very strong genetic component to HRV***

- Why? We don’t truly understand that
- Joel sees people who don’t work out at all and they have a very high HRV that you would not expect
  - They clearly don’t have a very high level of cardiovascular fitness
  - But as a whole, if you start talking to those people, they tend to have a healthier family history
    - They tend to have better health markers
  - Joel thinks there’s something to that, and that higher HRV probably still correlates to a health benefit, even if it doesn’t necessarily come from exercise-derived means

**Would you put HRV in a comparable bucket to VO****2** **max, in terms of the following amount of it that is genetically determined, amount of it that is modifiable, and the role it might play in understanding overall health status?**

- For VO2 max, Peter knows the answers to all those questions
  - There’s a genetic component, but it’s not huge (closer to 15% than 70%)
  - It’s highly modifiable, but difficult to modify
- Peter has said that VO2 max is the single greatest  predictor of mortality we have
  - He always talks about VO2 max as the integrator of so much hard work
  - If your VO2 max is in the to 1%, you weren’t born there

***From what Joel has seen, he thinks HRV is more genetically based, a bit less modifiable, and less predictive***

- VO2 max is more predictive
  - If someone has an HRV of 110 and someone else has a VO2 max of 70, he will know that the person with the VO2 max of 70 is pretty aerobically fit and they’ve lived a pretty solid lifestyle and done the work to get to that level
  - Joe is more confident in that second person’s longevity than the first person who has no workout history but just a  high HRV
  - A higher HRV alone wouldn’t have the same prognostic value in all-cause mortality

***HRV is a metric that we aren’t gauging output from, we’re just measuring the internal physiological state, and while that confers benefits to someone who has a higher HRV, it doesn’t say that person is necessarily healthy or fit because of this strong genetic component***

- If Joel sees someone with a higher VO2 and a higher HRV, chances are that’s reflective of a healthy lifestyle and a lot of hard training and the physiological changes that come as a result of that
  - And we’re more confident that those numbers are going to line up with all-cause mortality

**Peter’s takeaway**: you should worry about your VO2 max more than your HRV, because you have more control over it and it’s a better predictor of all-cause mortality

- What gets measured, gets managed
- Because HRV is so ubiquitous, these data are creating a lot of stress
- Joel agrees, “*We want to look at output measures. VO**2* *max is the best output measure. We can look at something like heart rate in Zone 2, heart rate recovery*.”

> “*As we age, we need to be able to continue to move, and we need to be able to continue to be able to respond to our environment around us. And output is where we can see those metrics*.”‒ Joel Jamieson

- If you look at people that you know around you that are healthy and older, a lot of them, they’re very active, they move around, they have hobbies, they have friends, they’re social, they do things they love, and that’s a big part of keeping them healthy and resilient
- What’s the metabolic cost for us to move around?
- If we can maintain movement as we age, we can be highly active
- If we don’t have the metabolic capacity to move, we decline a lot faster

***VO******2*** ***max and heart rate at different speeds correlates to the ability to move, and that’s far more predictive than HRV***

## How aging affects HRV and sympathetic drive, and the importance of spontaneous movement and exercise in maintaining the body’s adaptability [43:30]

**Do you have kids?**

- Joel doesn’t
- Anybody with kids (especially young kids) will appreciate this comment, and Peter has become much more cognizant of a metric that ties into spontaneous movement
- Peter explains, “*I’m an old guy, and even though I’m fit for my age, I don’t waste a lot of movement. So I’m already at that stage in my life where I actually think of myself as quite lazy.*”
  - He loves to exercise and is not lazy when he’s doing that
  - But if he’s walking through the airport, he’s just walking
- His boys are 6 and 9, and the amount of spontaneous explosive movement is something Peter doesn’t remember from his childhood ‒ it’s really a remarkable thing
- They have a puppy, and this puppy is also bouncing off the walls
  - A 14-year-old dog is not doing this, even if it’s in good health
- Everywhere his boys go, they have to race
  - They’re doing sprints to and from the whole time
- Peter thinks there’s something beautiful about that, and he thinks it speaks to this idea of youth

Peter explains, “*Youth is about movement. It is converting the chemical energy of our food into the electrical energy that powers muscles, and spontaneous locomotion seems to be this.*”

- Peter would love to take this an another output metric, use a GPS to measure spontaneous movement (for no apparent good reason)

**As we age, we lose HRV, but we also lose sympathetic drive**

- We lose some of that ability to turn that sympathetic dial up as we get older, too
- And probably it’s as we’ve lost both of those capabilities, the ability to turn that sympathetic dial up and crank out more energy and produce adrenaline and cortisol

*Is that what you think explains the fall in maximum heart rate?*

- Part of it
- It’s the loss of contractility of the heart, loss of contractility of the muscular system, loss of hormonal release as a result of the sympathetic nervous system

Joel explains, “*You’re just losing, again, this adaptability, this ability to turn those two dials, as necessary, to meet whatever demand you’re placing in the body*.”

- We can’t turn that sympathetic dial up as much
- We don’t have that spontaneous energy that you just described to get up and sprint
- That dial was way slower and it probably can’t go up as high

**Analogy***:* it’s like we were born with a 0-10 rheostat or dial on both of them; and as you age that 10 goes to a 9, 8, 7, 6, 5, and you can still move them but you just can’t move them as much

- Joel would call that the **autonomic range**, and that represents what our body is capable of from an energetic standpoint
- How quickly can we turn that dial up?
- And then conversely, how quickly can we turn that dial back down, and crank up that parasympathetic side to restore homeostasis and get our bodies back to normal?
- There’s a [paper](https://apps.dtic.mil/sti/citations/ADA416090) where they looked at different Navy divers that were going through this qualification school (their equivalent of SEAL training and hell week), and they tried to pick out what are the variables that separate the people that are really good at this and succeed versus the ones that don’t
  - They measured HRV throughout the process [shown in the figure below]
  - They find this autonomic range where they could really crank up the sympathetic system when they needed to, and then turn it off as soon a the stress was over and respond in the other direction with a much higher parasympathetic response

![](https://peterattiamd.com/wp-content/uploads/2024/06/f6-joeljamieson.png)

**Figure 6. HRV of elite soldiers is significantly higher than that of general troop soldiers, measured at high frequency (HF) and low frequency (LF)**. Image credit: [*DTIC* 2002](https://apps.dtic.mil/sti/pdfs/ADA416090.pdf)

***The ability to use those dials quickly and in the right combination seems to be the key to adaptability, and if you age and both those dials lose their range, and they lose their coordination, then we have much less resilience, much less adaptability***

**The vagus and sympathetic nervous system influence behavior in a lot of ways**

- The psychosocial aspect of this is outside of Joel’s lane
- You can look up [*The Polyvagal Theory*](https://www.amazon.com/Polyvagal-Theory-Neurophysiological-Communication-Self-regulation/dp/0393707008/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.h4ZothM_53NGbc12sqg_UKUAup-K7ceSSDHkUlywML3YOSGyJ0PyMq8G5n4vVMrn3-j0LPy0TBEK3aXzJWNecMtDUL2H9i36b19oT4eR-M9UZDx_pX0QxKhhXP50dZau9m9P_aCSWqkjlR3yeUq1ErPVrDo6yrROJ5WuI9M0UMCakwQKteHt_bOJXy83uwiXaBMkt7m9NrRtqmlFyqnaSABb3pzvNVEpGSXsKeH7A4Q.GFrManh0K1YmFB6oOSDxeC5kZGDqMc7alKPLm7yE9tY&qid=1714665515&sr=1-4) by Stephen Porges: fundamentally the brain regulates emotion through autonomic function in some capacity
- The vagus is related to social behaviors, it’s related to cognitive control in different scenarios
- They call it fight, flight, freeze, all these things related to how our autonomic nervous system is influencing our emotions

***And if we don’t have the autonomic range, we probably have less drive to get up and move around as a result of that, as those nerves in the autonomic system changes what it can and can’t do***

- Peter doesn’t think that should be underestimated or understated
- In his small patient population, he sees that a lot where there’s a very clear association between an individual that, if you just look at them from a movement and exercise perspective, has a very difficult time relaxing ‒ there seems to be very high association between that and emotional stress and psychological stress
  - They can’t let their ribcage down
  - If they can’t generate intra-abdominal pressure, if they can’t go through a sequence of movements that generate some amount of motor control and compensatory relaxation contraction

*This applies to pain as well*

- When you see **chronic pain**, you could argue, “*Where’s the chicken? Where’s the egg?*”
- If you’re in pain, does that lead to more emotional stress?
  - Does that lead to an inability to regulate relaxation within the body, which further exacerbates pain?
  - It’s a very vicious cycle

*And you see a lack of sleep*

- Older people need just as much sleep, but they have a harder time getting as much sleep
- And sleep is very much tied to that vagus nerve and the parasympathetic nervous system
- Again, if we get worse quality sleep, we get less adaptability
- It is chicken and egg, but fundamentally that’s why we want to regulate ourselves correctly, and that’s where exercise comes in

> “*The biggest thing exercise does is improves our body’s ability to regulate itself*.”‒ Joel Jamieson

- Exercise improves the use of those dials, because we are exposing the body to the aerobic training that we know has some broad correlation to that
  - And we’re giving the body a stress it can adapt to in a positive way
  - If we do it in the right amounts, and that’s the caveat there

## How Morpheus measures HRV using RMSSD and normalizes it to a 100-point scale for easier interpretation [49:45]

**At Morpheus, what do you guys use to measure?**

- We use [RMSSD](https://en.wikipedia.org/wiki/Heart_rate_variability#Time-domain_methods) and then we use a log natural transform and a multiplier
- That sounds like a lot of math, but essentially, if you look at the data of RMSSD and you look at a normal bell curve, it’s skewed, it’s not normal
  - It’s all the way to the left
- You get these normal ranges of 20-80, or 100
- You can get an elite athlete who is 180, 200
- Joel sees this big bunch of data on the far left-hand side, and it’s hard to interpret
  - He’s not a statistician
- Essentially to normalize this data and make it look more naturally distributed (more like  a [normal bell curve](https://en.wikipedia.org/wiki/Normal_distribution)), you do this log natural transform, use the multiplier and Morpheus ends up on a scale that looks more like a 100 point scale
- So people with a lower HRV are going to be 50-60
- People with a more moderate HRV are 60-70
- People with a higher HRV are 70-80
- Elite athletes are going to be 90-100
- We have a more familiar relationship with this scale, the data is more normalized from a standpoint of a bell curve, and it’s easier to interpret

**When people start using Morpheus and they’re using another RMSSD device, how much discordance do they typically see between them?**

- It really depends on what they’re using
- It can be a big difference between the device that they’re using and the numbers they’re getting
- But the trends should generally line up

***You should see the directional change matching, but the actual numbers will be somewhat different depending on where you’re at in that spectrum***

- If you’re seeing Morpheus increase as a whole, you should see the other one increase as a whole

## The Morpheus system: development, integration with various metrics, and personalized daily training recommendations to optimize fitness and recovery [51:30]

**Morpheus is a product Peter has been using for about 1.5-2 years**

- Everything he does, he does for a reason
  - He is a very deliberate person
- There’s a very particular use case that is pretty narrow for how he uses it
  - He knows he’s not using it to its full potential

**Tell folks what Morpheus is about, and your involvement in this**

*That’s obviously how Peter and Joel got to know each other*

- When Joel started using the old system (in 2007 or 2008), he had to wait for people to come to the gym to measure them
- He realized he was getting a pretty small snapshot of what their life story was, because he might measure them 2-3X a week
  - Sometimes they’d come in the morning, sometimes they’d come in the afternoon, and he realized the limitations of that
- He wanted to create something that people could use with their phones and he could get more data from
- His first system was *BioForce HRV* in 2011, and that was one of the earliest HRV apps out there
  - With your phone, you could do a recording and you could get HRv on your own (without coming into the gym)
  - One of the limitations was that all Joel could look at was your HRV
    - He didn’t necessarily have any idea what else was being tied to that
    - He could look at the change and ask a bunch of questions to try to figure out where changes were coming from

***He wanted to create something that tied in training, sleep, subjective markers, and other metrics so that as a coach, he had a more complete story of what was happening ‒ that was the genesis of Morpheus (which started in 2016, 2017)***

- Morpheus tracks activity, sleep, workouts
  - You can use the Morpheus device for a lot of that, or you can use other devices
- There are a lot of apps that give you HRV, and you can either interpret that yourself as a physiological metric, or you can say, “*The apps are giving me a recovery or a readiness or some gauge that’s based on that.*”

***This comes back to the lack of standardization among devices across the HRV measurement and how that information is interpreted to generate recovery or readiness***

- These are just numbers that we are creating as a way to try to interpret the data
- Some apps do a reasonable job with it and some don’t

Joel explains, “*I created Morpheus and this idea of the recovery score based on what I had seen using HRV for 20 years, or maybe 15 years at that point.*”

- The Morpheus recovery score is a metric of what’s appropriate for you on a given day
  - Of what your body is more likely to benefit from

**What is recovery? What is readiness?**

- These are metrics that Morpheus gives you, and other devices (Oura, Whoop, Garmin)
- Every app has their own gauge of that

*The question is how accurate is it? What does it really mean?*

- That is where a lot of confusion comes in, because we’re trying to take metrics and turn them into something that’s not a physiological measure, but something we try to create
- Peter used an [Oura ring](https://ouraring.com/) for many years, but probably hasn’t used it in 1-1.5 years
  - There’s better devices to track sleep
  - There’s no reason to believe the recovery score is necessarily accurate; it’s not something you can act on
    - Let’s say you believe the number, he certainly believes that if it spits out a 90 versus a 70, there’s probably a difference there (you’re better off on the day you’re 90)

*The question is how do you operationalize that information?*

- Someone on Peter’s clinical team said, “*We’re having a hard time giving people real instruction around Zone 2, because most people don’t want to do what you do, Peter, nobody wants to check their lactate levels and go through this.*”
  - Peter understands not wanting to do a finger stick every time you do a workout
  - And relying on [RPE](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion) can be challenging
- Someone recommended the Morpheus app ‒ it gives you target zones for heart rate every day
  - The cut-off between what it’s calling zone 1 and zone 2 are a pretty good proxy for what your zone 2 should be on that day

**Peter bought the system and has recorded every single workout he’s done for the last 1-1.5 years**

- He records: the heart rate predicted by Morpheus for what his zone 2 is and the heart rate he largely end up at by RPE
  - Usually they’re quite close; sometimes they’re quite far
  - Sometimes Morpheus tells him to be at 138 but he’s gassed out at 131
  - Sometimes it’s the reverse where Morpheus says he should be at 133 but he feels fantastic and goes to 140

> “*I cannot put in words how impressed I am with that system, and how remarkably accurate it is at predicting something that is very difficult to predict. So kudos to you for doing that.*”‒ Peter Attia

- What Peter finds amazing is a day when Morpheus says he should be at 140 or 139 for zone 2, he goes on the bike and does not feel great, he decides to ride a certain wattage and his heart rate is 132
  - He checked his lactate and it was 1.1 mmol
  - He was nowhere near his limit of where he could have been that day
  - Maybe that’s all he needed that day, and maybe he should have just been following how he felt
  - But, if he’s really trying to get the right training effect, he was under-training a little bit on that day

**Morpheus spits out 3 zones: zone 1, zone 2, zone 3 (called recovery and conditioning)**

- It’s just a way to gauge low, moderate, and high intensity

Peter asks, “*Does it surprise you that the heart rate that is on the cusp between your 1st and 2nd training zones happens to correspond to this lactate of 2 sweet spot?*”

- That was the intent when Joel designed it
- With his experience as a coach for mean years, testing lactate, VO2 max, HRV, he synthesized a lot of information to create this structured system of low, moderate, and high intensity (that’s basically what the zones are)
- The biggest thing Joel realized is as people’s autonomic nervous system changes intensity, our heart rate changes
- He created an algorithm based on a lot of data collected over a number of years of what he’s seen in the gym, and the end result of that was Morpheus

***Morpheus is by far the best way to translate internal changes with changes that we should be doing in the gym***

**What Peter tells patients**

- Peter almost never bothers checking lactate, it’s RPE if you can manage it
- But if they want some guidance, a great place to start is to take the [Maffetone formula](https://philmaffetone.com/maf-test/): 180 – your age
- Once you’re getting a little more nuanced, if you want more guidance, use Morpheus and go to that heart rate

**Tell folks how Morpheus determines that number every morning**

- You have to measure your HRV, we’re also looking at other things you’ve done in the past 24 hours (if you’re recording it), and it’s based on your fitness level
- We ascertain fitness level by looking at your resting heart rate, your average HRV, some of your heart rate trends when you’re training
- Then we say:
  - Ok Peter is roughly at this level of fitness
  - Peter’s autonomic nervous system is responding in this way, and this correlates to how it’s going to react today
- Then we estimate the cutoff between low intensity, moderate intensity, and high intensity

*One way people can think about this is muscle fiber recruitment*

- Low intensity is primarily slow twitch muscle fibers doing the majority of the work
  - Zone 2 and they’re mostly oxidizing fat as much as possible
- Moderate intensity, we’re starting to recruit some of those moderate threshold fibers (we’ll explain in a minute)
  - Faster twitch, higher threshold muscle fibers
- High intensity, we’re starting to recruit all the muscle fibers and the highest intensity of muscle fibers
- Morpheus looks at different heart rates and what it thinks the level of intensity is going to correspond to low, medium, and high

***Peter reiterates why this is very valuable: it gives him the prescription every single day***

*How Peter uses it every morning*

- He was a little surprised when he got it, he didn’t understand the nuance
- Every morning he needs to lay down in bed for 2.5 minutes before he get up, to do the still test and measure his heart rate
- Morpheus at the time came with a chest strap and an arm band (he thinks it now uses just the chest strap)
- You lay in bed and answer a couple questions
  - How many hours did you sleep the night before (he pulls this off his sleep tracker, [Eight Sleep](https://www.eightsleep.com/))
  - What was the quality of his sleep (also from the sleep tracker)
  - How sore he is
  - Subjectively, how good does he feel

Peter explains, “*Those are reasonably validated markers for training performance*.”

- He will usually lay there and meditate while it measures his HRV and heart rate
- It spits out these numbers, his recovery score as a percent, and his target training zones (these come up again in the app when you train)

***So your training zones change every day***

## The benefits of morning HRV readings for assessing daily readiness compared to overnight HRV measurements [1:03:00]

**What’s the difference between what the Oura ring tells you by measuring over 8 hours of sleep versus what Morpheus tells you in the 2.5 minutes of measurement in the morning before getting up?**

- This is probably the most important part of HRV because there is so much confusion on this
- We look back historically at all the data that’s been used, these all-cause mortality studies and all the different pieces of literature out there
  - 95% of them are from spot HRV measurements that we’re measuring at a specific time
- You’re doing this in **standardized conditions** as much as you can to get a baseline because ***we want to know: where is your autonomic nervous system?***
  - You want to measure at the same time every day, in the same conditions
- We also want to know about the last 24 hours
  - You ate food
  - You worked out
  - Maybe you had alcohol
  - Maybe you had mental stress
  - Maybe you put your body in a situation where you had to respond for the majority of the day to do something and then you went to bed
  - We want to see this stress and recovery cycle that you went through yesterday because that tells us where your body’s at right now. How is it responding?
- We’ll look at changes over time and understand how your body is adapting to the world around you
  - That’s what most HRV has been built on

***As we measure HRV in standard conditions, we see where you’re at today and that informs us about what happened over the last 24 hours and maybe slightly beyond***

**Analogy**: if you were going to weigh yourself, you’d want to weigh first thing in the morning in standard conditions (not after a meal) so you can see changes

- It’s changes against yourself that’s the most informative
- So you wake up, you measure HRV, we see where you are and we see where you were, what your averages have been, what your variations have been, and that tells us where you are today
  - And that helps us make a decision about what are you ready to do right now?
  - It doesn’t mean you can’t train hard
    - It just might mean that that might not be the most beneficial thing for you, and there might be a cost associated with that
- Yeah, Peter doesn’t think he has ever not exercised as a result of what Morpheus said
  - There have been days where he’s had abysmal scores: it recommended a heart rate range of 121 which means his recover was 35 or 40%
    - That’s a night where he didn’t sleep and something was drastically off
    - He still did the workout
- You’re just aware of what the cost of that workout would be and you make adjustments tomorrow or to your plan

***If we’re measuring HRV overnight, that number is always higher at night because the parasympathetic system is turned up quite a bit because your sleeping***

- Think of it as a dial, and it’s highest when you’re sleeping
- Most people won’t see the reverse: where their RMSSD HRV overnight is lower than the log normal transform you get out of Morpheus
  - If you look at the actual RMSSD data, you’d see HRV is higher at night
  - Morpheus is different

Peter asks, “*Can we see that in the app?*”

- You can’t right now
- When they first came out with Bioforce and Morpheus, there weren’t so many other apps to compare it against
  - So it wasn’t as big a deal to to show the raw number; so they chose not to
- They will probably change this because people want to compare

**Differences between a standardized measure of HRV with Morpheus and an overnight measure of HRV**

- 1 – Overnight, that dial of that parasympathetic system was already higher, and we’re getting less of a responsiveness to see what actually is changing at rest
  - Morpheus is not measuring at rest [overnight]
- 2 – If you have arrhythmias, if you’re an athlete who has very high HRV, if you don’t have as much variability, we’re not really gauging the true responsiveness of the 24 hours before
  - We’re measuring more of what’s it doing during the recovery period
    - We’re not really seeing where are you at the end of that recovery period
- 3 – Here’s the biggest thing is if you do something (if you do a workout in the evening, if you have a few glasses of wine, if you’re doing something very mentally challenging), the first part of your sleep, you’re just responding to that
  - And so your HRV is not reflective of this whole process
  - It’s just reflective of: you just did an evening workout and your HRV is still suppressed for the first half of your sleep responding to that workout

***We don’t get a true picture of where you are right now and how does that correlate to what you should be doing for the next 12-18 hours the next day; we’re probably getting a much better gauge of sleep***

- We’re not really getting this true picture of: How did our body go through the whole process of life, sleep, recover, next?
- We don’t see that picture as well because we’re not measuring at the end of sleep
  - We’re getting this average across it

***HRV measured overnight (versus once just after sleep, in the morning) doesn’t have the same utility for telling us the most appropriate thing for us to do, from a workout perspective***

**Is it an issue if you get up to pee before you measure your HRV?**

- It just occurred to Peter that one fundamental difference from one day to another is there are some mornings when he wakes up and he has to pee so badly that he goes to the bathroom before measuring HRV
- Joel explains, “*It’s not that big of an issue if you just go up to the bathroom, you come back and you reestablish. And part of that’s actually measuring: how well can you reestablish that?*”
  - If that significantly impacted your HRV, it probably was on the lower end to begin with

**People with really high HRVs**

- This doesn’t become an issue in Morpheus until you’re in the 90s or resting heart rates in the low to mid-40s
- Your HRV is already very, very high that laying down, you’re taking some responsiveness away

***Joel’s advice if you’re in those categories: you probably want to take your HRV measurement seated***

- The challenge for most people seated is they get antsy, they move around, you introduce more **motion artifacts** and it becomes more difficult
- We really want to have as much range of that dial available as possible because we want to see how the nervous system is turning that dial
- Peter’s HRV is never above the low 80s
  - For him, Joel thinks laying down is still a good way to take that HRV measurement

***If your HRV gets up in the 90s (or higher), you want to maximize potential responsiveness and that’s where a seated measurement makes more sense (that’s a small % of the population)***

## Why Morpheus recommends using a chest strap rather than an arm band [1:10:00]

- When Peter bought the Morpheus a couple years ago, it came with an armband and a chest strap
  - He uses the armband as his morning check (it always sits right there)
  - He uses the chest strap when he’s exercising
- Now it just comes with a chest strap

**Is that because you think you’re going to get better data and it’s just better to have people using the chest strap for both (and should Peter do the same)?**

- Joel doesn’t think the data is any less accurate, as long as you’re measuring consistently and have the armband placed correctly
- The problem they ran into was that people were using the armband to train because it’s more convenient, and their workout data was not as accurate
- Secondly, the armband looked like a watch, and that caused confusion
  - People putting it on their wrist
  - People not knowing what to do with it

***At the end of the day, the chest strap is giving us the best data, and it made sense for them to standardize that and use the chest strap rather than sell 2 devices***

- If people want an arm device, the [Scosche Rhythm 24](https://www.scosche.com/rhythm24-waterproof-armband-heart-rate-monitor) uses the exact same sensor that Morpheus used in their original armband, and they can measure that way

## The impact of consistent exercise, stress, alcohol, and other lifestyle factors on HRV [1:11:15]

**Peter has been using Morpheus for a while and asks, “*****What can I be doing to improve the quality of my health in a way that is measured by this output of HRV?*****”**

- He can see his up and down level and knows when it’s higher, he’s generally going to perform better and can push a little harder
  - When it’s lower, he’s probably not going to perform as well and may need to make that more of a less hard day
- This question gets to where HRV is driven by genetics, cardiovascular fitness, and lifestyle
- Doing things in your lifestyle that make that sympathetic dial come down when you don’t need it, and doing things that turn on that parasympathetic dial when you’re not using this is going to put you in your highest level of your particular range
- Most people underestimate the **impact lifestyle has on HRV** (and training and everything else)
  - They don’t realize if you are stressed out from work 6, 8, 10 hours a day, you’re running around chasing your kids, you’re doing all these things in your daily life
  - That has a pretty significant impact on your HRV because **that sympathetic dial will be turned up** for hours on end
    - Maybe not the same degree of course as a workout

*A lot of it comes down to stuff we know in everyday life that makes us healthier*

- Eating healthier foods, making sure we’re getting enough sleep, managing mental stress effectively

***Doing things that allow us to relax and turn that parasympathetic dial back up and that sympathetic dial back down; and then build VO******2*** ***max***

Peter asks, “*Do you think it’s more impacted by peak aerobic fitness or by base aerobic fitness? Would you say it’s more impacted by a higher zone two or a higher VO2 max?*”

- They both contribute, Joel couldn’t really say how much
- For the most part, we tend to measure aerobic fitness from a peak standpoint
- **Training frequency** matters, and that is likely to translate into a higher HRV even if you didn’t do a bunch of VO2 max type work
  - Most is zone 2 training
  - You can’t do VO2 max training 5, 6 days a week

**Peter points out one of the most profound changes you see in HRV is in response to alcohol**

- He thinks one of the advantages of those overnight tests (whether it’s Oura, WHOOP, Eight Sleep) is how much an impact alcohol has on overnight HRV

- Peter would argue that a big part of the movement movement we’re seeing around people drinking less can be attributed to those devices
  - People are realizing what a profound effect alcohol can have on HRV

*Would that be out of your system the next day or would that still be there in the morning?*

- It would depend on if you had alcohol close enough to bedtime that it impacts sleep and recovery
- You can still see remnants of it in the morning, but you’ll see that more directly in the overnight measurement

> “*What we see is people become much more aware of things like alcohol, things like excessive stimulants or God forbid, smoking or massive amounts of chronic mental stress. Those things impact much more than people realize*.”‒ Joel Jamieson

**An example from measuring a college soccer team across a couple of seasons**

- During finals week, their measurements would look far worse than during tournaments (even competitive playoffs)
  - Because of the stress and not sleeping

Peter asks, “*Give me a sense of the range that you would see.*”

- There is a lot of variability there
- Most college soccer athletes that Joel sees are female athletes, and their HRV is normally in the low-mid-80s (measured with the Morpheus system)
  - You can’t compare each to other numbers
- He sees them drop into the 70s and sometimes down to the 50s during finals week
  - It’s 2, 3, 4 days of not getting much sleep, studying a lot, working out very little or sporadically (compared to normal training)
- A workout is an hour or maybe 2 hours; the rest of your life can add up to a huge amount of stress if you are very stressed
  - If you are type A, always turned on and can’t turn off your stress
  - That has a very big impact
- [Sapolsky](https://profiles.stanford.edu/robert-sapolsky?tab=bio) talks a lot about the mechanisms, and you see that frequently when you look at HIV data
  - He was a guest on [episode #51](https://peterattiamd.com/robertsapolsky/)

**Can you wear 2 chest straps?**

- Peter doesn’t utilize the Morpheus system fully because he only wears it during his zone 2 workouts
- He doesn’t wear it during his VO2 max workouts because he’s wearing a Polar system that pairs with the Garmin and power meter that he’s using
- Joel explains that you could
- Also, the Polar strap should be able to connect to the Morpheus app directly
  - If it’s got 2 bluetooth radios (which it probably does), you could pair it to 2 apps
- Peter doesn’t wear it when he’s strength training or rucking, so there’s a lot of time where he’s active but not wearing it

Peter asks, “*How much am I missing out on in terms of the fidelity of what it might be telling me? Because I want to talk about the algorithm.*”

- Peter can’t make sense of how Morpheus is coming up with the numbers
  - Even though they end up being right most of the time
- Joel explains, “*The more data you give it, obviously the better it’s going to be. Exactly how much you’re losing and it’s hard to say, but we’re measuring the output with that HRV change and with the numbers that you’re putting into it.*”
- We know the output of where you are

***We can’t always ascertain how you got there if we don’t have all the data, but as long as we have a consistent HRV measurement every morning (in standardized conditions), we’re still able to get the vast majority of what we’re trying to get***

- Which is what are you most likely to do when you work out right now, and how much is that going to impact you?
- The most important thing is that morning measurement of heart rate and heart rate variability, answering the questions: how long you slept, how sore you are, and your desire to train
  - This is telling Morpheus where you are right now (the readout state, the output)
- If we know the output, we can reverse engineer from that the input
  - We can have some more insight into that, but you’re not losing a bunch of accuracy because you didn’t get that
- We want the output and we want that as standardized and accurate as possible

***Accuracy comes from measuring consistently every morning, in the same context, same conditions***

## Optimizing zone 2 training with Morpheus [1:18:15]

- Peter’s use case for Morpheus is quite simple: predicting zone 2
  - And the day-to-day variation is really significant

**Joel explains the reason for this day-to-day variation**

- The body is dynamic
- We can do a zone 2 test and look at lactate, but if we just take 1 test, we don’t realize how much the body changes on a daily basis
- The body is not static, measuring blood pressure, testosterone ‒ these numbers change constantly

**People listening may say, “*****It’s too much data. Just go out there and do it.*****” Peter gives counter argument to that**

- When he was a competitive athlete and was training for 28 hours a week, he had the luxury of junk miles
  - He didn’t always have to be perfect
- Now he’s not a competitive athlete, he’s a competitive father, he’s running 3 businesses, and he doesn’t have time for nonsense
  - He’s only going to train for 3-4 hours a week

Peter’s perspective is, “*Every minute I’m training, I have to get the training stimulus right or at least as close to right as possible. So when I’m setting out to do zone 2, I got to do it. And if I’m out there trucking along and my lactate’s 1.1 or 2.9, I’m missing the training effect I want. So the more insight I can get to narrow that down, the better.*”

- Peter wants to be efficient and not waste his time
- Joel agrees, the more you can hone in on the right amount, type, and intensity of training to focus on what you are individually going to respond to best, the more you can do that week-in and week-out, the more you will see continual improvements
  - If you go above that amount, not so great things are going to happen (like burnout or injury)
  - If you go below that, you’re not going to get the outputs you want
- Ultimately, you want to use that information to get the most bang for your buck

***Data has a really powerful role in that it’s information you can use to make much more granular decisions around training***

- Rather than, “*Should I go do 40 minutes today?*”

> “*That’s what intrigued me so much about HRV is it felt like I could open the black box and get some real answers other than test, train for 8 weeks, remeasure, see what happened*.”‒ Joel Jamieson

- Joes doesn’t want to wait 8 weeks and potentially lose the gains that could have been made in that time

***For someone wanting to get as much out of their time as they possibly can, data can play a really strong role in that because it’s going to answer questions that can’t be answered otherwise***

- Peter thinks it only gets more significant as we age
  - Joel agrees 100%
- Peter recalls, “*When I was 40, my recovery capacity was so much greater than now, nevermind 30, 20, that’s obvious. But even the difference between 40 and 50 is significant.*”
- Joel explains that age reduces your margin of error
  - You can do a lot of things wrong in your 20s and maybe in your 30s, and you can still get a lot of benefit out of it because you’re so resilient, your metabolism will adapt
  - But the older you get, the less you can do that

***As you get older, you have to be much more acutely aware of what you body can and can’t do, and that’s part of what HRV can help you understand***

## Using heart rate recovery (HRR) as an indicator of athletic conditioning and the balance between aerobic and anaerobic systems [1:22:45]

**Going back to something Joel said 20 minutes ago, would there be any utility in measuring HRV right after a VO****2** **max interval to see how much sympathetic tone you can dial down and how much parasympathetic tone you can dial up?**

- A VO2 max interval is probably a very high sympathetic, low parasympathetic exercise
- For example, Peter monitors his [heart rate recovery](https://en.wikipedia.org/wiki/Heart_rate#Heart_rate_recovery) during VO2 max sets, and as soon as he gets to the top of the hill, he hits the lap timer and **counts how many beats his heart rate to goes down in the 1st 60 seconds** at the completion of the interval
  - That’s a great proxy for how he’s doing
  - His normal range is 30-35 on a good day
  - He was 40-45 a week ago
  - One of the worst days he’s ever had, he was 19-21 in a minute (that’s all he could recover); he was smoked
    - On that day, he didn’t sleep the night before
    - Peter made an [Instagram post](https://www.instagram.com/peterattiamd/reel/C4TX2d2uemc/) about this because it was illustrative of a great teaching point
- Joel explain that you can measure HRV during a 10-15 minute recovery, but you can’t move around if you want to get some standardization
  - It’s very specific

Peter asks, “*What if I just did it right at the top? Would that be too much?*”

- Probably
- Heart rate recovery is illustrative of what you want to get because it’s driven by tuning the sympathetic system down as quickly as possible and turning the parasympathetic system (the vagus) up as fast as possible

***Heart rate recovery is already giving you that information without having to get as granular as pulling out the beat-to-beat (you don’t necessarily have to get that level of detail)***

- You can just see the heart rate drop, and that drop is being caused by the increase in heart rate variability

**Thoughts about action of the vagus nerve during exercise**

- We used to have this idea that when your heart rate increased above 100 beats per minute, that there was really no vagus input, that there was almost no parasympathetic
  - They figured that because they would look at acetylcholine as essentially it could block it into the heart, and they’d say, “*Oh, we block acetylcholine from the vagus, and the heart still pumps just fine during exercise, so exercise must not be vagus-driven at all.*”
- But what they’ve found is that the vagus might actually be turned up a bit during exercise in some sense because it can increase coronary blood flow by increasing vasodilation in the coronary artery
- During exercise, the vagus is probably not completely inactive, probably not completely off
  - It’s this ratio
  - It could be turned up
- But the sympathetic system is turned up so much more, and it’s using a different mechanism
- We don’t see the heart rate variability high, but it’s probably more ready to turn that back up even further as soon as that sympathetic system starts turning down
  - And we’re dropping our adrenergic hormone levels (our [catecholamines](https://en.wikipedia.org/wiki/Catecholamine)), and all these things are dropping pretty quickly

***The faster we can turn that parasympathetic up, the faster our heart rate comes down***

- The other thing that’s interesting is they’ve looked at heart recovery in terms of it represents to some extent the **balance of the aerobic and anaerobic systems** that contributed to that exercise
  - So the more aerobically driven something was, the faster a heart rate drops
  - Because in a lot of ways, higher heart rates are driven by that sympathetic and by the anaerobic pieces of metabolism

**What heart rate recovery values do you see in young, exceptional athletes?**

- Peter wished he tracked this metric as a teenager, back when his peak heart rate was 205-210

***Joel explains that a really good number from a near max is 50, 60***

- He trained UFC fighters for many, many years, and he would use heart rate recovery between rounds as a really good gauge
  - They would have to fight for 3, 5-minute rounds to 5, 5-minute rounds, or even a 10-minute round
  - It’s 1-minute between rounds (the same as boxing)
  - He would have the fighter sit down between rounds and standardize the measurement of heart rate recovery

***That drop in heart rate was a very good gauge of how well conditioned the athlete is***

- A fighter would come out at 160, 180 bpm (depending on what the round was like, and Joel would want to get them to the 130s between each round
- They would simulate this in sparring rounds leading up to the fight
- They couldn’t measure this during the fight
- If they weren’t coming down below 150, 160 bpm between rounds, they’re not in good enough shape
  - They were going to have fatigue every time
  - That indicated they were having to rely on the anaerobic piece

*In a sport like fighting, you have to be really explosive, but you also have to have the endurance*

- The ratio of energy utilization matters so much
- If you don’t have enough anaerobic, you’re going to lack power and speed and ability to finish
- But if you don’t have enough aerobic, you’re not going to sustain that explosive power very long
- It’s really tricky to get that ratio right
- Often you see that the fastest, most explosive, hardest hitting athletes, fatigue the fastest
  - Because they’re generating that from the anaerobic side, and they’re relying on that
  - That’s great if they can win and they can knock the person out or submit them, but if they can’t and you get in the later rounds, that’s where they’re going to really struggle versus somebody else who’s more aerobically dominant

***A hard part about that sport is getting that ratio correct and training the right side of it, and heart rate recovery was a great way to see that***

- If the athlete could get to a high heart rate during competition and then drop it back to the 130s between each round, you knew they were in good condition
- If they weren’t doing that (especially in the early rounds), you knew they were in trouble

## The importance of tracking HRV trends over time rather than focusing on data from a given day [1:29:00]

**Walk me through the arc of HRV over time and how the undulation of the HRV matters as much as the HRV on a given day**

- This really seems to work for Peter
  - He explains, “*It’s so accurate in what it predicts. It’s like a shaman*.”

*Joel explains that we’re looking at not just what is your number, but what is your number in relation to where you’re usually at*

- How much does your number move today versus what’s a normal movement for you
- We’re looking at this manipulation of dials by the autonomic nervous system
- What Morpheus is doing is looking at your 7 days and seeing what your normal baseline number is itself, but also what’s your normal level of variability across those different time periods
- Then we look at standard deviation

***And if we see big changes greater than one standard deviation away from your average and away from your baseline, we know that that’s the autonomic nervous system responding to a greater input***

- It’s responding to more stress, and it’s having to make bigger dial adjustments
- And that tells us that you’ve been paying a higher cost because you put your body under more stress

*To illustrate this*

- Let’s say our body is at rest, and then we do a single workout
- We allow it whatever time it needs to recover
- **During that workout**, the body turns-up that sympathetic dial and it turns-down that parasympathetic dial
  - We produce more force, more energy, more power, etc.
- **After the workout**, the sympathetic system starts to come down, and the parasympathetic starts to come back up
- Now depending on the workout you did, that could happen in very different timescales
- [Stephen Seiler](https://www.uia.no/english/about-uia/employees/stephens/) (a really popularized polar trainer) showed that if you do zone 2 and below aerobic work, that recovery happens very quickly
- Within a few hours, we see the parasympathetic system turn on and come up to maybe 110, 120% of what your HRV was at rest
  - If you were a 70 and you were to remeasure it, you might be a 74 or 74
- You would see a noticeable uptick above baseline because our body has been able to shift very quickly into that restorative phase by that vagus nerve firing more forcefully and turning up the parasympathetic
- During the workout, we see suppression [of the parasympathetic system], and this curve starting to come back up
  - During lower-intensity workouts, we’ll see it come up above baseline pretty quickly
    - And then as your body went through that complete cycle and restored homeostasis, did what it wanted to do, and then it will then settle back down to where it started
    - So you’d this very clear curve, now in a much higher intensity

Peter notices, “*But the amplitudes aren’t as big*.”

- Joel agrees that the amplitudes aren’t as big in a much higher intensity, higher volume
- Even in lower intensity, to be at it for 3 hours in the heat ‒ that’s a much bigger stress
  - You’d see the same curve, but it would play out over a much longer timescale because it would take much longer for the body to restore back to where it was (from a HRV standpoint)
    - We’d see a much bigger depression (lower drop), and the we’d see a much longer timescale for it to come back up to normal, and we might see it come up above normal for some period and then restore

**There’s a big difference in the individual as well**

- People with higher HRV and people who are more fit, they’re more likely to see this increase above baseline
- Somebody who has less autonomic range, it can’t quite turn that parasympathetic dial up as much
  - They might never get up above baseline
  - They might just spend time getting back to that baseline HRV, and you never really see the peak above baseline and then the restoring afterwards

***It’s an individual thing based on fitness, but we should generally see suppression of HRV, an increase of HRV, and then kind of a back to normal HRV (that’s the process)***

![](https://peterattiamd.com/wp-content/uploads/2024/06/f7-joeljamieson.png)

**Figure 7. How HRV changes with stress and recovery**. Image credit: [Morpheus](https://support.trainwithmorpheus.com/support/solutions/articles/4000202439-intro-to-heart-rate-variability)

**The tricky thing is we have so many other things that influence HRV**

- Alcohol influences it, mental stress influences it, sleep influences it
- Joel explains, “*It’s overlapping influences that will get to where you’re seeing, but that’s the core thing of our body response to stress by dropping HRV and then by recovering HRV and then by coming back to whatever that normal range is*.”

**Peter’s takeaway**: this is why it is not intuitive to just look at the HRV that given day; you need to know the first derivative, the second derivative, and frankly even the arc that it’s on

> “*[HRV] It’s an all-cause metric that’s not just looking at one input, it’s looking at everything. And so interpreting that output is not always the easiest thing in the world.*”‒ Joel Jamieson

- It’s a little more nuanced than that because it’s this responsiveness of: it’s going to drop after pure stress, then it’s going to come back up, it might come up way above baseline, and then drop back down to normal
  - This curve is not always the most intuitive thing to understand, and that’s part of the challenge

## Effect of GLP-1 agonists on heart rate and HRV [1:34:45]

- There’s a phenomenon Peter sees in patients taking [GLP-1 agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) and the dual agonists with [GIP](https://en.wikipedia.org/wiki/Gastric_inhibitory_polypeptide) (maybe 2 dozen patients, not many): **resting heart rate goes up**
  - In all cases he has overnight information on heart rate and heart rate variability
  - It’s going up an average of 10 beats per minute with a range of about 8-12
    - This is unmistakable, it’s not subtle
  - And for patients that come off the drug (usually within a month), it goes back to normal
- We’re also seeing a compression of heart rate variability, so we see **heart rate variability come down**, although that’s less predictive
- Peter now realizes that using the Oura ring or whatever, maybe those data aren’t as accurate as using Morpheus

**If there’s something going on in a drug that is predictably driving heart rate up, would you expect it is also driving heart rate variability down?**

*Do those tend to move in that opposite direction?*

- Generally speaking, yeah
- If we were to turn-up that sympathetic dial, our hunger gets turned-down
  - We don’t want to be hungry when we’re in the middle of some stressor, right?
- But after that stressor is over, theoretically we’ve burned energy and we need to restore and eat
- The [vagus](https://en.wikipedia.org/wiki/Vagus_nerve) is very connected to the gut and to hunger centers, and it feeds up into the [medulla](https://en.wikipedia.org/wiki/Medulla_oblongata) and it’s controlled by the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus)
  - There’s a very strong vagal relationship to hunger and the desire to eat
- Joel wonders if suppressing the vagus and decreasing HRV and increasing heart rate is a byproduct of how these drugs are inhibiting appetite

This leads to another question: *If I told you that I’m going to change you in a way that your heart rate is 10 beats higher and your HRV is 10 milliseconds lower, you would say that whatever you did was negative*

- Sure, there’s a cost to that

**Peter gets asked all the time, “*****Are these drugs safe?*****”**

- Peter thinks for some people if they go from being 250 lbs to 200 lbs and their [hemoglobin A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin) goes from 7% to 5.5% ‒ that is so positive that it justifies whatever unknown exists around these drugs
  - If there’s no other way they’re going to achieve that benefit
- Peter is more interested in the marginal cases of people who don’t have diabetes and want to lose 20 lbs

Peter asks, “*Are they taking too big a risk?*”

- The question is: If these drugs raise your heart rate that much and lowers your heart rate variability, are we picking up a signal that is just a niche representation of appetite suppression via the vagus nerve or **is it actually playing a role in the parasympathetic/sympathetic dials?**
- Joel would imagine that it’s got to be
- Being in a more sympathetic state all the time is going to have a cost
  - If it’s a few weeks or a month, maybe that cost is relatively small
  - But if it’s months of living on this drug, Peter would suspect there’s a real cost to that
- If the benefit is they lose a bunch of weight, their blood markers improve, and we see health outcomes, then maybe it’s worth that cost
- But for somebody who cosmetically wants to lose weight, is that a net benefit?
  - It’s hard to say because we don’t have long-term studies on those drugs

***In general, Joel would think that if there’s a noticeable decrease in HRV and increase in heart rate: that’s a real sign that the body’s autonomic nervous system is being adjusted in an artificial way, and that’s probably not a good thing in the long run***

- Given the popularity of these drugs, there’s no shortage of opportunities to measure these things
- Joel would be curious to see what happens when they come off these drugs
  - Do we see a big rebound?
  - Does their heart rate stay suppressed? How does it change?

**Peter points out that his sample size is so small that everything he’s saying could be nothing**

- 25 people is not enough
- But in those 25 people, he’s never seen an exception
- Peter adds, “*When you don’t need statistics to measure things, you kind of need to pay a little closer attention to them.*”
- Joel thinks it’s pretty hard to modulate appetite that significantly without suppression of the vagus to some extent because it’s so closely connected
- Peter does see everything come back to normal in these patients when they come off the drug
  - Within a month or maybe even 2 weeks
- Peter doesn’t think he as enough insight to contrast the 2 most popular drugs, [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) and [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide)
- Peter guesses that a number of people on these drugs might not be aware of this because either they’re not tracking it or they haven’t noticed it

**Have you heard anything about it?**

- With **ADHD medications** you see a very suppressed HRV and a very elevated sympathetic resting heart rate
- You see it with any **strong stimulant** (including caffeine and Red Bull)

***To constantly turn that sympathetic dial up is a sign that the sympathetic system isn’t working the way that it should by itself***

- Probably because you’ve overstimulated it to begin with through stress and the lack of the ability to turn that off
- We see people reach for stimulants and artificial ways of turning that sympathetic dial up once their body’s not doing it the way that it should
- People self-medicate with stimulants to get that sympathetic response when if they had been able to manage stress more effectively, they probably would have a normal functioning sympathetic system that wouldn’t need the artificial stimulus to turn it up

## Where HRV belongs in the hierarchy of health metrics [1:42:00]

- We’ve talked about how **output metrics** tend to be preferable (think of them as **functional metrics**)
  - Peter likes an [oral glucose tolerance test](https://en.wikipedia.org/wiki/Glucose_tolerance_test) more than a [hemoglobin A1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin)
    - The first watches how you do something; it’s more functional
  - VO2 and max strength are more functional tests than resting heart rate or muscle mass
  - Muscle mass is great, it’s predictive as is resting heart rate, but when you actually put the work out, HRV is obviously a readout state
- Joel thinks it’s important to monitor HRV as you’re going along, but if all your other metrics are telling you you’re healthy and going in the right direction, 9 times out of 10, HRV would tell you the same thing
- Where he would be more aware of it is **when HRV is very low** and you don’t have a reason for that
  - You’d want to figure that out
  - Joel has seen people have arrhythmias they had no idea about or some serious heart condition

***Long-term, HRV should line-up with VO******2*** ***and your metabolic markers***

**HRV is easier to track because we can measure it on a daily basis, and that the advantage**

- You’re not getting VO2 max tests every day, every week, or every month
- You’re not doing lactate tests, these markers that are more output based frequently enough to get feedback of whether or not you’re going in the right direction

Joel explains, “*I think we can look at HRV on a more granular daily basis to just kind of say, ‘Am I going the right direction?’ And that’s probably more of a utility than a great predictor of something. And we can look at those daily changes to help us make more informed decisions.*”

- You can’t do that with VO2 max or more invasive tests

***HRV is a more narrow data point, but it gives us something we can use more actionably than the longer-term tests that are better measures of outcome***

**If you see HRV trending down significantly**

- That’s a warning that you’re doing something wrong
- Your body is not adapting the way it should and you need to make adjustments (whether it’s training or lifestyle)
- We use VO2 and output measures to see “*Are we going in the right direction?*” And we have some prognostic value specifically from them
- We use HRV to see, “*Are we more likely to be making improvements in the short term or are we heading the wrong direction?*”
  - Where if we keep doing that for long periods of time, we’re going to either see the benefit or the cost depending on which direction we’re going

Peter asks, “*Is there a number, Joel, on the log normal transformation you’re doing on the RMSSD, a number below which if it’s consistently there, I would want to inquire more?*”

- 50s, 40s: those are pretty low numbers for a Morpheus user
  - Peter points out that this is not the RMSSD number
    - The RMSSD number might be far far lower than that (10)
  - You really have to be specific when you’re talking about systems

**Joel relates an anecdote about someone with a low HRV**

- There was a guy named [Mel Siff](https://supertrainingi.wordpress.com/2010/02/23/supertraining-author-who-is-dr-mel-siff/), he was a very well-known sports scientist who wrote a book called [*Supertraining*](https://www.amazon.com/Supertraining-Yuri-V-Verkhoshansky/dp/8890403810/ref=sr_1_1?crid=2C8Q5DLTVVZG2&dib=eyJ2IjoiMSJ9.rCvoFggLFm8C8ja4A6EB7EzjQzrwcSF5bxatQ1tEK_2CBrDWWdZBeuiXPjR7cQABkelLYr-CpqBrkSDdKhu9nja0P9zSRBcdhnmor_1tHaQ.o9QGI5lwGwRwVbfXUwiHNvA8w4j0n0D7XYKKQrU9l6E&dib_tag=se&keywords=supertraining+by+mel+siff&qid=1715694642&sprefix=Supertraining+by+mel%2Caps%2C116&sr=8-1)
- Joel was at his house with the original HRV system he used, and **Mel’s RMSSD was like 5** (really bad)
- Then he had a heart attack
- Joel told him, “*Mel, this looks really concerning*.”
- But Mel brushed it off, and he died of a heart attack a few months later

***If you’re seeing a super low RMSSD or Morpheus number, it’s definitely an indication that that autonomic nervous system is not responding well to the world around it, and there could be a legitimate medical concern that’s driving that***

- If you’re Morpheus is in the 40s, 30s and you’re just not getting up, it’s something to definitely be concerned about and it’s probably worth looking into

**Do you see the opposite where really high numbers or a sudden change from low to high can indicate an arrhythmia or something like that?**

- Yeah, absolutely
- You definitely do see these weird numbers come out that could be arrhythmia, that could be medications, that could be who knows
- You see some of these things jump around from anomalies that may be an artifact
- Sometimes you see this from a medication
- You see weird type of stuff with COVID that you want to be aware of that you probably wouldn’t pick up otherwise

> “*I would say HRV is more of a leading indicator and how you feel and some of those symptoms can come days later.*”‒ Joel Jamieson

- You’ll oftentimes pick up something that looks weird, and then 2 days later you will get a cold or you get the flu or you get some sort of thing that explained it

## Parting thoughts [1:46:30]

- Peter feels like he know more about this now than even after he did the [AMA](https://peterattiamd.com/ama31/) a couple of years ago (and he learned a lot to prepare for that)
- He apologizes because on some level this probably sounds like a Morpheus commercial for some listeners
- Peter has no affiliation with Morpheus at all
- But he’s a big consumer of data, and he tests every device out there extensively
- He views Morpheus as, “*The stickiest device I’ve ever found for this use case. And so I do hope that people check it out*.”
  - You can [buy Morpheus online](https://trainwithmorpheus.com/#morpheus-customize)
- Joel explains, “*The biggest thing I’ve learned after 20-plus years of coaching is we’re all different*.”
- If you can really dig into your own physiology, how you respond to training, how your respond to diet, really learn how your physiology works, you will reap the rewards of that in the long run
- Tools like HRV and sleep monitors build awareness

***Using that data to really be your own coach and really understand your own physiology and your own biology, that’s the ultimate way to get better results and have the health outcomes you’re looking fo***r

§

## Selected Links / Related Material

**Joel’s companies**: [1:00]

- [Morpheus Training System](https://trainwithmorpheus.com/)
- [8WeeksOut](https://8weeksout.com/)

**Peter’s disclosures**: [About Peter](https://peterattiamd.com/about/) | PeterAttiaMD.com (2024) | [3:30]

**AMA episode of** ***The Drive*** **on heart rate variability**: [#193 – AMA #31: Heart rate variability (HRV), alcohol, sleep, and more](https://peterattiamd.com/ama31/) (January 31, 2022) | [33:30, 1:46:30]

**Study of HRV in Navy divers**: [The War Fighter’s Stress Response: Telemetric and Noninvasive Assessment](https://apps.dtic.mil/sti/citations/ADA416090) | *DTIC* (Amanda O’Donnell et al 2002) | [46:45]

**Book on polyvagal theory and regulation of emotions through autonomic function**: [The Polyvagal Theory: Neurophysiological Foundations of Emotions, Attachment, Communication, and Self-regulation](https://www.amazon.com/Polyvagal-Theory-Neurophysiological-Communication-Self-regulation/dp/0393707008/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.h4ZothM_53NGbc12sqg_UKUAup-K7ceSSDHkUlywML3YOSGyJ0PyMq8G5n4vVMrn3-j0LPy0TBEK3aXzJWNecMtDUL2H9i36b19oT4eR-M9UZDx_pX0QxKhhXP50dZau9m9P_aCSWqkjlR3yeUq1ErPVrDo6yrROJ5WuI9M0UMCakwQKteHt_bOJXy83uwiXaBMkt7m9NrRtqmlFyqnaSABb3pzvNVEpGSXsKeH7A4Q.GFrManh0K1YmFB6oOSDxeC5kZGDqMc7alKPLm7yE9tY&qid=1714665515&sr=1-4) by Stephen Porges (2011) | [47:45]

**Episode of** ***The Drive*** **with Sapolsky**: [#51 – Robert Sapolsky, Ph.D.: The pervasive effect of stress – is it killing you?](https://peterattiamd.com/robertsapolsky/) (April 29, 2019) | [1:16:00]

**Peter’s Instagram post about tracking heart rate recovery after VO****2** **max intervals**: [peterattiamd](https://www.instagram.com/peterattiamd/reel/C4TX2d2uemc/) (March 9, 2024) | [1:23:30]

**Book mentioned by Mel Siff**: [Supertraining](https://www.amazon.com/Supertraining-Yuri-V-Verkhoshansky/dp/8890403810/ref=sr_1_1?crid=2C8Q5DLTVVZG2&dib=eyJ2IjoiMSJ9.rCvoFggLFm8C8ja4A6EB7EzjQzrwcSF5bxatQ1tEK_2CBrDWWdZBeuiXPjR7cQABkelLYr-CpqBrkSDdKhu9nja0P9zSRBcdhnmor_1tHaQ.o9QGI5lwGwRwVbfXUwiHNvA8w4j0n0D7XYKKQrU9l6E&dib_tag=se&keywords=supertraining+by+mel+siff&qid=1715694642&sprefix=Supertraining+by+mel%2Caps%2C116&sr=8-1) by Yutri Verkhoshansky & Mel Siff (2009) | [1:45:15]

**Where to order the Morpheus Training system**: [Morpheus: Train Smarter. Recover Faster.](https://trainwithmorpheus.com/) (2024)

**Primer on HRV and heart rate**: [The Ultimate Primer on HRV and Heart Rate](https://8weeksout.com/2022/09/07/difference-between-hrv-and-heart-rate/) | 8WeeksOut (J Jamieson 2024)

§

## People Mentioned

- [Randy Huntington](https://en.wikipedia.org/wiki/Randy_Huntington) (Track and field coach, 1 of 5 rated USATF Master Coaches for jumps in the U.S.) [5:00]
- [Mike Powell](https://en.wikipedia.org/wiki/Mike_Powell_(long_jumper)) (Track and field athlete and holder of the long jump world record) [5:15]
- [Robert Sapolsky](https://profiles.stanford.edu/robert-sapolsky?tab=bio) (Professor of Biology, Neurology, and Neurosurgery at Stanford and expert in stress) [1:16:00]
- [Stephen Seiler](https://www.uia.no/english/about-uia/employees/stephens/) (Professor of Sports Science and Physical Education at the University of Agder, Norway; expert in polarized training) [1:31:30]
- [Mel Siff](https://supertrainingi.wordpress.com/2010/02/23/supertraining-author-who-is-dr-mel-siff/) (1944-2003, expert in fitness, strength conditioning, and biomechanics; Senior Lecturer in mechanical engineering at the Witwatersrand University in Johannesburg, South Africa) [1:45:00]

§

![](https://peterattiamd.com/wp-content/uploads/2024/06/bio-joeljamieson.jpeg)

##### Joel Jamieson

Joel Jamieson is an authority on strength, conditioning, and energy systems for combat sports and the author of [*Ultimate MMA Conditioning*](https://www.amazon.com/Ultimate-MMA-Conditioning-Joel-Jamieson/dp/B0884JYFS4/ref=monarch_sidesheet). He has spent the past 20 years coaching world champion athletes. He has consulted extensively for teams and organizations including the Navy SEALS, UFC champions, and professional sports teams from the NFL, NBA, MLS, and NCAA. Joel is the founder of [8WeeksOut](https://8weeksout.com/) and [Morpheus](https://trainwithmorpheus.com/). His training strategies are evidence-based, individualized, and practical to apply. [[Breaking Muscle](https://breakingmuscle.com/author/joel-jamieson/)]

Instagram: [@coachjoeljamieson](https://www.instagram.com/coachjoeljamieson/?hl=en)