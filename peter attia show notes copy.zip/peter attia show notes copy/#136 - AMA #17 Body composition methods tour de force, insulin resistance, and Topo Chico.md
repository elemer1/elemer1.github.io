# #136 – AMA #17: Body composition methods tour de force, insulin resistance, and Topo Chico

**Source:** [https://peterattiamd.com/ama17/](https://peterattiamd.com/ama17/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob discuss different methods to evaluate body composition. They explore ways of measuring body fat, delineating between subcutaneous and visceral fat, and go over best strategies for improving body composition and optimizing health. They also discuss insulin resistance using a patient case study that highlights interventions capable of reversing the condition. Finally, Peter addresses his level of concern about a recent Consumer Report finding that Topo Chico had the highest levels of a class of synthetic chemicals (PFAS) of all the carbonated bottled waters tested. Peter concludes by sharing if the finding will change his consumption habits.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #17 show notes page](https://peterattiamd.com/ama17). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Body mass index (BMI) vs. body fat percentage (BF%) (1:45);
- Methods of assessing body fat—Magnetic Resonance Imaging (MRI) (6:25);
- The different types of body fat (9:00);
- Methods of assessing body fat—Computed Tomography (CT Scan) (12:00);
- Methods of assessing body fat—Dual-Energy X-ray Absorptiometry (DEXA) (14:30);
- Methods of assessing body fat—Hydrostatic/Underwater Weighing (19:25);
- Methods of assessing body fat—Air Displacement (Bod Pod) (22:25);
- Methods of assessing body fat—Skinfold measurement (23:55);
- Methods of assessing body fat—Total Body Water (27:15);
- Methods of assessing body fat—Bioelectrical Impedance (BIA) (28:45);
- The optimal body fat percentage, muscle mass, and the best strategy to improve body composition (31:30);
- Defining insulin resistance and the steps to reverse it (40:15);
- Patient case study: Reversing insulin resistance (49:00);
- Addressing the recent finding of high levels of PFOA in Topo Chico (58:25); and
- More.

§

The Peter Attia Drive

Body composition methods tour de force, insulin resistance, and Topo Chico

§

## Show Notes

## Body mass index (BMI) vs. body fat percentage (BF%) [1:45]

Body mass index (BMI) can tell us limited information

- e.g., We know almost assuredly that 22 is better than 34
- But we know much less about the difference between 22 vs. 26
- BMI doesn’t take into account muscle mass
- Bob, for example, has a BMI of about 27, but one look at him you see he has a lot of muscle

Body fat percentage (BF%)

- If you looked at Bob’s body fat percentage, it might be 8% in reality – so his fat mass is actually quite low
- Body fat percentage is the much better metric to understand
- Although, you still want to know the breakdown in type of fat (more on this later)

## Methods of assessing body fat—Magnetic Resonance Imaging (MRI) [6:25]

**Magnetic Resonance Imaging (MRI) overview**

- *Overview*: MRI provides tomographic images with high soft tissue contrast, which enables quantification of fat and muscle compartmental volumes. Especially Dixon methods, that produce co-registered water and fat images, facilitate the separation of both adipose and lean tissue compartments. [[West et al., 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5802932/)]
- *How it works*: Exposure to a large magnetic field changes alignment of atomic nuclei. Use of radio-frequency waves allows detection of this alignment change and can be used to reconstruct tissue orientation based on concentration of a particular element, typically hydrogen.

![](https://peterattiamd.com/wp-content/uploads/2020/11/Peter-entering-the-MRI-machine-ama17-1024x960.png)

**Figure 1. Peter going into a Prenuvo MRI machine for a whole-body MRI.** Image credit: [#61 – Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology](https://peterattiamd.com/rajpaulattariwala/)

**More detail:**

- Gold standard: A whole-body MRI would produce the most accurate results
- MRIs are generally done for imaging a specific body part (knee, back, etc.)
- Given the expense and the time (4+ hours), it’s not actually practical to do a whole-body MRI for body fat outside of the research setting
- That being said, it is the gold standard for BF% — not only because of the accuracy, but more importantly because of the very clear of picture it gives of the **type of fat** present (i.e., [subcutaneous vs. visceral](https://bodysculptingspa.net/visceral-fat-vs-subcutaneous-fat/))

![](https://peterattiamd.com/wp-content/uploads/2020/11/pros-and-cons-MRI-ama17-1024x167.png)

**Figure 2. Pros and cons of the MRI method.**

## The different types of body fat [9:00]

> “*Not all fat is created equal.*”

**Subcutaneous fat** = fat between the skin and the fascia

- The inability to see the six-pack of abs is really an issue of either too small rectus abdominis muscle group and/or too much subcutaneous fat surrounding the rectus abdominis muscles

**Visceral fat** = fat beneath the fascia near the vital organs

- Fascia is the corset that is holding you together—it’s beneath your muscles and inside the fascia is where your organs exist
- Visceral fat is found around the liver, the kidneys, the spleen, and the gut.
- Visceral fat is incredibly [associated with metabolic disease](https://pubmed.ncbi.nlm.nih.gov/20703052/)
- In an ideal world, rather than tracking our BF%, we would instead track what % of our fat was visceral fat
- Although there are no standard reference ranges for visceral fat, in healthy individuals, values are generally less than 1 kg for younger individuals and between 1-2 kg for older individuals. ([source](https://pubmed.ncbi.nlm.nih.gov/31449721/), [source](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0180614), [source](https://europepmc.org/article/med/32123345)) However, these cohort study approximations.

*Using MRI*

- MRI is able to see visceral fat
- It’s also non-invasive, no radiation
- But again, not practical from a cost and availability standpoint as of today

## Methods of assessing body fat—Computed Tomography (CT Scan) [12:00]

**Computed Tomography (CT Scan) overview:**

- *Procedure*: The subject lies in a CT scanner for a partial or full-body scan.
- *How it works*: CT scanners transmit X-rays through a region of the body and detect the amount of transmission that passes through, thereby enabling reconstruction of cross-sectional anatomy. Based on differentiation of tissues by density, this reconstruction can be used to quantify fat content. Fat content of a specific body region can then be used to estimate total fat mass.

![](https://peterattiamd.com/wp-content/uploads/2020/11/CT-scan-ama17-1024x680.png)

**Figure 5. CT scanner.** Image credit: [spineuniverse.com](https://www.spineuniverse.com/exams-tests/ct-scan-computed-tomography-cat-scan-computed-axial-tomography)

**More detail:**

- CT scan is another type of scanner that you get into just like an MRI — but it is a much quicker procedure
- Like the MRI, the CT scan does a very good job of showing fat
- It’s very good anatomic study so you can see not only the total fat but where it lies (subcutaneous, visceral, etc.
- Compared to MRI, it’s much less expensive
- Radiation:
  - But CT has **far more radiation exposure**, which is why *Peter would never recommend a whole-body CT scan*
  - A whole body CT scan would be 50 millisieverts of radiation which is about the annual allotment that is recognized for a human (Peter aims for a sub 10 millisieverts **per year** exposure)
  - \*For context, according to one source, an astronaut has a radiation exposure between [12 and 28.8 millisieverts per day](https://www.forbes.com/sites/quora/2018/11/13/how-much-radiation-are-iss-astronauts-exposed-to/?sh=1af81b3e18a9) while on the [ISS](https://en.wikipedia.org/wiki/International_Space_Station)

![](https://peterattiamd.com/wp-content/uploads/2020/11/pros-and-cons-CT-ama17-1024x138.png)

**Figure 6. Pros and cons of the CT scan method.**

## Methods of assessing body fat—Dual-Energy X-ray Absorptiometry (DEXA) [14:30]

**Dual-Energy X-ray Absorptiometry (DEXA) Overview:**

- *Procedure*: The subject lies on a DEXA unit for a partial or full-body scan.
- *How it works*: Similar to computed tomography, DEXA uses X-ray transmission to reconstruct tissue orientation based on density. However, DEXA is designed to use a much lower level of radiation.

![](https://peterattiamd.com/wp-content/uploads/2020/11/dexa-scanner-ama17-1024x772.png)

**Figure 7. A Dual-energy X-ray absorptiometry (DEXA) scan being administered at the Avon Longitudinal Study of Parents and Children (ALSPAC) clinic in Bristol, UK. A man lies on the scanner while the arm of the scanner moves over him, taking a full scan of his body tissue density.** Image credit: [wikipedia.org](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry)

**More detail:**

- DEXA is the method Peter uses with most of his patients
- It’s very quick x-ray—you lay on a table and a “wand” basically goes over you from head to toe to head
- Much lower ionizing radiation than a CT scan
- You get an assessment of **bone mineral density** and you get an assessment of **lean mass and non-lean mass**
- It works by collecting electrons on the backside of you— the more electrons that get collected, the less dense the tissue that it’s been passed through.

![](https://peterattiamd.com/wp-content/uploads/2020/11/radiation-exposure-ama17-1024x767.png)

**Figure 8. Effective doses of radiation from cancer screening procedures and other sources.**

*More advantages of DEXA*:

- You can differentiate between between the subcutaneous and intra abdominal fat to some degree (though not nearly as accurately as CT and MRI)
- Very quick and relatively inexpensive (about $150)
- Very trivial amount of radiation—the [radiation from one DEXA scan](https://www.measureup.com.au/dexa-scans-radiation/#:~:text=One%20sievert%20is%20a%20very,doses%20are%20much%2C%20much%20smaller.&text=Getting%20a%20DEXA%20scan%20is,and%20not%20so%20everyday)%20sources.) is roughly equivalent to (or even less than) [one coast to coast flight](https://www.cdc.gov/nceh/radiation/air_travel.html#:~:text=and%20leisure%20travel.-,We%20are%20exposed%20to%20low%20levels%20of%20radiation%20when%20we,from%20one%20chest%20x%2Dray.)

**Important thing to know**: Your hydration level impacts the measurement so always try to do your DEXA scan in the same manner (same hydration level, same time of day, same sleep, same food eaten prior, etc.)

![](https://peterattiamd.com/wp-content/uploads/2020/11/pros-and-cons-DEXA-ama17-1024x373.png)

**Figure 9. Pros and cons of the DEXA method.**

***\*Bonus advantage*****: Ability to measure bone mineral density**

- Peter really likes to know bone mineral density (especially in my female patients)
- We see osteopenia in women more than men—especially as women start to get closer to menopause
- So, if your 35 and you’re trending toward osteopenia that’s a wake-up call
- Are we not getting enough impact? Are we missing some essential mineral?
- The best thing you can typically do with the BMD is to stop the rate of decline.

## Methods of assessing body fat—Hydrostatic/Underwater Weighing [19:25]

**Overview**

- *Procedure*: The subject sits on a chair or platform connected to a scale, fully exhales, and is completely submerged under water.
- *How it works*: Based on [Archimedes’ principle](https://en.wikipedia.org/wiki/Archimedes%27_principle), the amount of water displaced represents the subject’s body volume. Thus, the underwater weight and the amount of water displaced allow for calculation of body density. Based on assumed constants for bone density and fat density, body density can be entered into an equation to estimate body fat percentage.

![](https://peterattiamd.com/wp-content/uploads/2020/11/underwater-weighing-ama17.png)

**Figure 10. Illustration of measurement of underwater body weight.** Image credit: [dapa-toolkit.mrc.ac.uk](https://dapa-toolkit.mrc.ac.uk/anthropometry/objective-methods/hydrostatic-underwater-weighing#:~:text=Hydrostatic%20underwater%20weighing%20is%20a,uses%20Archimedes'%20principle%20of%20displacement.)

**More detail:**

- Peter’s preferred method before he switched over to Dexa
- The problem with hydrostatic weight is you have to have a belief about what the end title volume is—
  - You have to have a very clear belief about how much air a person can expel from their lungs because that’s the point at which you’re weighing them. So the weight that you’re capturing of the person underwater is their weight when they have fully, fully, fully relieved themselves of as much air as possible but that’s not all the air.
  - But an individual that can’t tap into that will artificially have a higher looking body fat
- “*I’m not a huge fan of hydrostatic. I think it’s okay and I also think that it’s reasonable for comparison*.”

![](https://peterattiamd.com/wp-content/uploads/2020/11/pros-and-cons-underwater-ama17-1024x370.png)

**Figure 11. Pros and cons of the Underwater Weighing method.**

## Methods of assessing body fat—Air Displacement (Bod Pod) [22:25]

**Overview**

- *Procedure*: The subject is weighed, then sits in a sealed chamber that detects changes in air pressure, and afterward fully exhales into a breathing tube to estimate thoracic gas volume.
- *How it works*: Similar to underwater weighing, when a subject sits within an air displacement chamber, the amount of air they displace represents their body volume. Electronics in the chamber detect the change in air pressure, which is used to estimate volume. The chamber is typically connected to a computer, allowing for body fat percentage to be automatically estimated based on the collected data.

![](https://peterattiamd.com/wp-content/uploads/2020/11/air-pod-ama17.jpg)

**Figure 12. The Bod Pod.** Image credit: [Shaw and Kerr, 2017](https://link.springer.com/chapter/10.1007/978-981-10-5418-1_8)

**More detail:**

- This is very similar to underwater weighing
- It’s still relying on a delta, but now it’s the delta in **air pressure**
- You’re weighed, and then you sit into a chamber that detects a change in air pressure and then you fully exhale and you go through this similar type of exercise because of course air is a fluid it just happens to be a gas, unlike water which is a fluid but is a liquid.
- It’s really easy, comfortable, much less of a pain to do than underwater weighing
- It’s unlikely to be as accurate as Dexa
- In terms of accuracy, it goes MRI ⇒ CT scans ⇒ DEXA

![](https://peterattiamd.com/wp-content/uploads/2020/11/pros-and-cons-pod-ama17-1024x254.png)

**Figure 13. Pros and cons of the air displacement method.**

## Methods of assessing body fat—Skinfold measurement [23:55]

**Overview**

- *Procedure*: Using uniform pressure, calipers are used to pinch the skin in various areas of the body. The distances of the skinfolds measured with the calipers are then entered into an equation to estimate body fat percentage.
- *How it works*: The size of the skinfold created by the calipers is proportional to the amount of adipose underneath the skin, thereby allowing for estimation of body fat.

![](https://peterattiamd.com/wp-content/uploads/2020/11/skinfold-calipers-ama17-1024x736.png)

**Figure 14. Skinfold Caliper by Baseline.** Image credit: [amazon.com](https://www.amazon.com/Baseline-1249835-Skinfold-Caliper/dp/B00065X2LI/ref=sr_1_5?dchild=1&keywords=Baseline+Skinfold+Caliper&qid=1604503689&sr=8-5&tag=Runnerclickhurry-20)

**More detail:**

- Using calipers to pinch the skin fold on certain areas of the body is the “old school” way
- That said, it’s actually pretty good, but the accuracy is **highly dependent on the knowledge of the person taking the measurement**
- You want a trained technician but ideally, you would have the same trained technician because there is a little bit of an art to it.
- Furthermore, Peter is unclear as to how this tool was originally calibrated—I.e., How did they figure out that X millimeters of skinfold corresponded to X amount of fat?
- Peter says he had a “hack version” of this which was an ultrasound device that you would put on the caliper spots but it would basically using software an ultrasound tell you the thickness
- The main problem with that is you can do the measurement yourself

![](https://peterattiamd.com/wp-content/uploads/2020/11/pros-and-cons-skinfold-ama17-1024x344.png)

**Figure 15. Pros and cons of the skinfold method.**

## Methods of assessing body fat—Total Body Water [27:15]

**Overview**

- *Procedure*: The subject consumes or is injected with a predetermined amount of labeled water, typically in the form of a stable isotope such as tritium or deuterium, and the concentration of the labeled water is measured in blood, urine, or saliva to estimate total body water content.
- *How it works*: Since body fat is free of water, total body content of water can be used in conjunction with body mass and an assumed constant for the water content of fat-free tissue to estimate body fat percentage.

**More detail:**

- Truthfully, this is really just something research purposes
- You ingest radio-labeled water—water that is not hydrogen-two, oxygen-one (So you can come up with a new type of water by using deuterium or another isotope so it could be D2O, for example)
- You collect the amount of water that comes out of the person in blood, saliva, urine, et cetera and you can back-calculate how much fat they have
- And because we know that fat has no water in it, you basically get to calculate how much fat they have in a very, very indirect way

![](https://peterattiamd.com/wp-content/uploads/2020/11/pros-and-cons-total-body-water-ama17-1024x255.png)

**Figure 16. Pros and cons of the Total Body Water method.**

## Methods of assessing body fat—Bioelectrical Impedance (BIA) [28:45]

**Overview**

- *Procedure*: The subject stands or holds on to a device that transmits a small amount of current into the feet, hands, or both.
- *How it works*: Since fat is a nonconducting tissue, it opposes electrical current. In contrast, current is transferred through water by electrolytes. Therefore, passage of current through the body can be used to estimate total body water content, and with body mass can be used to estimate body fat percentage.

![](https://peterattiamd.com/wp-content/uploads/2020/11/BIA-scale-ama17.png)

**Figure 17. Example of a BIA scale.** Image credit: [nakedlabs.com](https://nakedlabs.com/bodystories/body-fat-series-bioimpedance-bia)

**More detail:**

- This is the most common one people have access to because you can buy these for your home
- You stand on a platform and then you hold something with your hands
- It’s running a small electric current through you and paying attention to 1) what’s non-conducting (and fat is non-conducting), and 2) what is conduction — water and electrolytes are conducting which is in your plasma but you also have some of that in your lean tissue (Your muscles are obviously heavily made up of water)
- Quick, easy, cheap, and no radiation
- The problem: It’s not super accurate and it’s highly sensitive to hydration status
- While it’s not always accurate, it can be good for **seeing a trend**—i.e., if you know your losing body fat over time of 12 weeks, for example

![](https://peterattiamd.com/wp-content/uploads/2020/11/pros-and-cons-BIA-ama17-1024x167.png)

**Figure 18. Pros and cons of the BIA method.**

## The optimal body fat percentage, muscle mass, and the best strategy to improve body composition [31:30]

**Optimal BF% and the genetic component**

- Mortality risk really starts to rise when BF% gets into the [35-40% range](https://pubmed.ncbi.nlm.nih.gov/26954388/)
- Worth noting that there is a strong genetic component to BF
- For example,
  - Peter says there’s people who could do “everything right” and their BF won’t go below the 15-18% range
  - Then you have others who can eat whatever they want and they’re constantly under 10%
- “S*o part of this is sort of knowing what’s the genetic path you’re on and probably trying to stay at the lower end of that but not the bare minimum*.”

**Data on muscle mass and body fat**

*With muscle mass…*

- In general, the more muscle mass the better
- [One study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4035379/) showed that skeletal muscle mass was an independent predictor of mortality
  - It was the more the better and had a 0.8 hazard ratio for the group.
  - There’s a 20% reduction in mortality and the absolute measures looked pretty compelling

![](https://peterattiamd.com/wp-content/uploads/2020/11/Srikanthan-and-Karlamangla-2014-ama17-1024x481.png)

**Figure 19. Unadjusted and Adjusted all-cause mortality risk (% mortality by December 2004) and rate (number of deaths per 10,000 person-months) as a function of sex-specific quartiles of Muscle mass index.** Image credit: [Srikanthan and Karlamangla, 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4035379/)

*With body fat…*

- The epidemiology would split up the groups in quintiles
- And when they look at the lowest body fat group and then compare it to the highest body fat group, the highest body fat percentage had a higher risk for mortality compared to the lowest
- But, worth noting that the “lowest” group, however, was in the 20-25% range
- This suggest there may even be a bigger difference if you look at the 10-15% range of BF and compared it to the higher percentage groups

\*\*\*

**Hypothetical patient with a 25-30% BF:**

- Hypothetical patient is a little chubby and lacking in muscle mass
- The question: ***What is the better strategy? Weight loss or muscle gain?***
- Peter and Bob both agree that in this particular patient they would prefer that person focus on adding lean muscle vs. strictly trying to lose weight
- And if they were losing weight, it’s very important they protect the muscle they do have

*Benefits to adding muscle*:

- First, muscle is more metabolically active so in the long run it’s going to help you
- Secondly, the structural benefits alone are essential if you’re interested in longevity
- Also, weight bearing training (e.g., squats) can add bone mineral density

\*\*\*

[**Rob Lustig**](https://robertlustig.com/) **pointed out the four things being measured when you step on a scale**:

1. Lean mass (part of which is muscle) — more is better
2. Bone mass — more is better
3. Subcutaneous fat — Rob would say more is better (or at least not bad)
4. Visceral fat — the lower the better

Note: Although there are no standard reference ranges for visceral fat, in healthy individuals, values are generally less than 1 kg for younger individuals and between 1-2 kg for older individuals. ([source](https://pubmed.ncbi.nlm.nih.gov/31449721/), [source](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0180614), [source](https://europepmc.org/article/med/32123345)) However, these cohort study approximations.

**The upshot**: Understanding what your body weight is composed of is much better than just your overall weight

## Defining insulin resistance and the steps to reverse it [40:15]

**Defining insulin resistance, and is it reversible?**

- Insulin resistance is hyperinsulinemia in the presence (or absence) of hyperglycemia
- Insulin resistance is when cells become resistant to the effects of insulin—specifically the muscles and the liver
- So when someone is insulin resistant…
  - Will have high blood sugar after consuming carbohydrates because their muscles don’t take in glucose inefficiently because they aren’t able to respond to the signal of insulin
  - They’ll also likely have high levels of glucose in the morning because overnight their liver continues to make too much glucose and isn’t responding to the signal of insulin telling them to stop making it
  - If even they do NOT have high glucose in the morning, they may have high insulin—which is just a precursor to the high glucose
- In practice, Peter could learn more specifics about a patient by performing an OGTT
  - See [AMA #15](https://peterattiamd.com/ama15/) for patient case studies involving OGTT testing
- *So is insulin resistance reversible?* The answer is **yes, almost always**.

**Ways to reverse insulin resistance**

Insulin resistance can be combated with all 5 tools in the toolkit:

- 1) Pharmacologic agents
- 2) stress/cortisol management
- 3) sleep strategies
- 4) exercise, and
- 5) nutrition

**1.Pharmacological agents—Drugs that lower glucose**

- Peter very much prefers drugs that lower glucose: [metformin](https://en.wikipedia.org/wiki/Metformin), [SGLT2 inhibitors](https://en.wikipedia.org/wiki/SGLT2_inhibitor), [GLP-1 receptor agonists](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1_receptor_agonist)
- Peter is not a fan of diabetic drugs that tell the body to rev up insulin production as a way to overcome the resistance

> “I like the drugs that tend to lower glucose. So you can think of this as an input or an output problem. I much prefer to go after the input.”

**2. Stress/cortisol management**

- When you’re under stress (physiologic or psychological), you’re producing cortisol and that’s going to exacerbate insulin resistance
- Stress (i.e., hypercortisolemia) can be addressed pharmacologically and therapeutically (e.g., psychotherapy and/or meditation)

⇒ *Patient example:*

- Peter had a patient who was dialed in on basically everything but metabolically he wasn’t responding
- This patient had never dealt with a very traumatic event in her life
- And it was only when attention was finally turned to really dealing with that with psychotherapy and the correct pharmacotherapy that all the other metabolic things got in place
- This patient was discussed in the [episode of The Drive with Paul Conti](https://peterattiamd.com/paulconti/)

> “There’s a clear mind/body connection that is not just some sort of touchy-feely nonsense. It’s completely and it can’t be discounted.”

**3. Sleep**

- Sleep is probably one of the most overlooked ways to address insulin resistance
- Research shows pretty clearly how much **you can destroy glucose disposal by interrupting sleep**
- [Experiments show](https://pubmed.ncbi.nlm.nih.gov/10543671/) that when deprive people down to 4 hours per night for a period of two weeks there’s an incredible deterioration in insulin signaling and glucose disposal
- From this, you can imagine that more spread out/chronic forms of sleep deprivation could have devastating effects on insulin resistance

> “Making sure that you’re getting the right amount of quality sleep is a wildly important part of this and it’s something we focus on obsessively.”

**4. Exercise**

- Exercise allows you to increase the size of the reservoir that takes in glucose—the reservoir being the muscle
- *Zone 2 “cardio”*—
  - Improves both the insulin-dependent, and non-insulin-dependent, delivery mechanisms
  - Zone 2 exercise is training right at that maximum efficiency of mitochondrial performance and really improves insulin sensitivity
  - \*See episodes discussing zone 2 training — [Iñigo San Millán](https://peterattiamd.com/inigosanmillan/) and [AMA #12](https://peterattiamd.com/ama12/)
- *Strength training*: This improves insulin sensitivity and improves the reservoir—the capacity—because your skeletal muscles are the greatest reservoir that you have for glucose disposal

> “Skeletal muscles are the greatest reservoir that you have for glucose disposal.”

**5. Nutrition**

- By definition, insulin resistance is a carbohydrate tolerance disorder
- Any doctor who is clinically taking care of patients will say insulin resistance patients generally respond better to carbohydrate restriction than any other form of restriction
- They respond very well to calorie restriction by definition typically includes carbohydrate restriction
- It doesn’t have to be a ketogenic diet
- Rather than tell everyone to stay under XXX amount of carbs, Peter sets a standard in terms of average blood glucose and a standard deviation from that average
- Peter uses a [Dexcom CGM](https://www.dexcom.com/) to monitor this (see podcast [episode with Kevin Sayer](https://peterattiamd.com/kevinsayer/), CEO of Dexcom)

> “As those numbers start to come down and the insulin starts to come down and all these other things start to go, that’s exactly what reversibility looks like.”

## Patient case study: Reversing insulin resistance [49:00]

**Patient X**

- Male
- 35 years old
- 5’10” and 192 lbs
- Visually, he does not appear to be overweight (though patient desired to be leaner)
- Date of initial testing: 11/17/16

**Blood panel –** “Classic pattern of insulin resistance”

![](https://peterattiamd.com/wp-content/uploads/2020/11/Patient-X-lipids-ama17-1024x551.png)

**Figure 20. Patient X lipids.**

Observations:

- TG/HDL-C ratio = 6.3
  - Ideally that ratio is below 2
  - When the ratio is this high, the only scenario that he is NOT insulin resistant is if they have a genetic disorder that’s raising triglycerides
- Very elevated Lp(a) and very strong discordance between his ApoB and LDL-C
- His inflammatory markers didn’t look too bad
- His cardiac function markers looked great

![](https://peterattiamd.com/wp-content/uploads/2020/11/patient-X-vit-D-and-uric-acid-ama17-1024x276.png)

**Figure 21. Patient X vitamin D and uric acid.**

- Vitamin D was quite low
- His uric acid at 5.6 was disconcerting but his homocysteine was normal

**Glycemic numbers —** *“this is where it starts to get a little bit interesting”*

- Hemoglobin A1C = 5.8% (pre-diabetic)
  - NOTE: Peter doesn’t put much stock in HbA1c ([see AMA #15 for why](https://peterattiamd.com/ama15/))
- *OGTT results*:
  - Fasting blood glucose = 93 — P*retty darn good*
  - Fasting insulin = 15 — Not good—ideally that number is **lower than 6**, and 8 at most.”
  - At 60 min: Insulin = 134 (ideally below 40)
  - At 120 min: Glucose is down to 109, but insulin still rising at 177

**\*Diagnosis**:

- If this person had a TSH of 0.001 and a free T3 of 6.4 we would call it hyperthyroidism
- But, in this case, the diagnosis is **hyperinsulinemia**—This is an endocrine condition of hyperinsulinemia and this is effectively insulin resistance on a full-fledged scale.

**The Intervention and Results**

*The intervention for Patient X after his initial testing was as follows:*

- A low dose of metformin
- Sleep was already good so no intervention there
- Tweaked some work/life balance
- Focused heavily on exercise and nutrition
  - For exercise, the patient began following the [Mark Rippetoe program](https://startingstrength.com/) of heavy compound movements with progressive overload
  - For nutrition, they aggressively restricted carbs–putting him on a ketogenic diet for about six months and then gradually easing in a tolerable amount of carbs

*The results:*

![](https://peterattiamd.com/wp-content/uploads/2020/11/Patient-X-results-ama17-1024x489.png)

**Figure 22. Patient X’s results after intervention.**

> “This is just a great example of slow and steady wins the race. This was not like some overnight change, but truthfully I think within a year he had most of those benefits and he’s maintained them.”

## Addressing the Consumer Report finding that Topo Chico has high levels of PFAS [58:25]

See Peter’s [recent email](https://peterattiamd.com/topo-chico/) about a Consumer Report indicating Topo Chico had the highest amount of PFOA than any other bottled water

\*\*\*

A recent [Consumer Report](https://www.consumerreports.org/bottled-water/whats-really-in-your-bottled-water/) looked at a chemical called perfluorooctanoic acid (PFOA) in a number of bottled waters and it found there were more in Topo Chico than any other bottled water that they checked

- Topo Chico had 9.76 parts per trillion
- This number is about twice the upper limit of what at least one organization had designated as the most you should see in bottled water
- Though it was far below what the EPA believes is harmful

Next, let’s examine 1) the strength of the evidence that suggests that at those levels are harmful, and 2) How should one potentially modify behavior?

- For Peter it came down to a precautionary principle and some principles around asymmetry:
  - “If I used to drink two or three Topo Chico’s a day I’ll probably drink one every other day now and continue to dig a little bit further into this literature”
    - *Why make this change?* Because the downside of being wrong and missing out on some Topo Chico is *less than* the downside of being wrong and finding out in 50 years that this amount of PFOA was really harmful
  - The counter-argument:
    - Given the ubiquity of Topo Chico and frankly, other beverages that have higher amounts of PFOAs in them, you’d think there’d be a bit of a signal beyond what we’re seeing
    - When something is really bad it’s usually not subtle (e.g., smoking and lung cancer)
    - “*If the epidemiology doesn’t really find it, it’s probably not that big an issue*”

**Peter ultimate decision**: Continue drinking Topo Chico, but to a lesser degree, and also to diversify his bubbly waters

⇒ Peter’s preferred alternative to Topo Chico: [WaterLoo](https://www.drinkwaterloo.com/) (flavor=Black Cherry)

§

## Selected Links / Related Material

**Hockey team that Mike Luit (Bob’s alias) played for**: [Hartford Whalers](https://en.wikipedia.org/wiki/Hartford_Whalers) | (wikipedia.org) [2:15]

**Podcast episode discussing whole-body MRI scanning technology**: [#61 – Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology](https://peterattiamd.com/rajpaulattariwala/) | Peter Attia (peterattiamd.com) [7:15]

**Visceral fat is incredibly associated with metabolic disease**: [Contribution of adipose tissue to health span and longevity](https://pubmed.ncbi.nlm.nih.gov/20703052/) (Huffman and Barzilai, 2010) [10:00]

**Astronauts’ exposure to radiation**: [How Much Radiation Are ISS Astronauts Exposed To?](https://www.forbes.com/sites/quora/2018/11/13/how-much-radiation-are-iss-astronauts-exposed-to/?sh=1af81b3e18a9) | (forbes.com) [13:45]

**Radiation exposure from one coast to coast flight across the US**: [Radiation and your health: Air travel](https://www.cdc.gov/nceh/radiation/air_travel.html#:~:text=and%20leisure%20travel.-,We%20are%20exposed%20to%20low%20levels%20of%20radiation%20when%20we,from%20one%20chest%20x%2Dray.) | (cdc.gov) [17:45]

**Radiation from one DEXA scan**: [DEXA scans & Radiation](https://www.measureup.com.au/dexa-scans-radiation/#:~:text=One%20sievert%20is%20a%20very,doses%20are%20much%2C%20much%20smaller.&text=Getting%20a%20DEXA%20scan%20is,and%20not%20so%20everyday)%20sources.) | (measureup.com) [17:45]

**Mortality risk begins to rise when body fat % gets into the 35-40% range**: [Relationship Among Body Fat Percentage, Body Mass Index, and All-Cause Mortality: A Cohort Study](https://pubmed.ncbi.nlm.nih.gov/26954388/) (Padwal et al., 2016) [31:45]

**Study showing skeletal muscle mass was an independent predictor of mortality**: [Muscle Mass Index as a Predictor of Longevity in Older-Adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4035379/) (Srikanthan and Karlamangla, 2014) [34:45]

**Podcast with Paul Conte when Peter gave the example of a patient who couldn’t improve her metabolic health until she dealt with a traumatic event from her past**: [#15 – Paul Conti, M.D.: trauma, suicide, community, and self-compassion](https://peterattiamd.com/paulconti/) | Peter Attia (peterattiamd.com) [44:45]

**Experiment demonstrating how much you can destroy glucose disposal with sleep deprivation**: [Impact of sleep debt on metabolic and endocrine function](https://peterattiamd.com/matthewwalker3/) (Spiegel et al., 1999) [45:30]

**Podcast episodes discussing zone 2 training**: [46:15]

- [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com)
- [#92 – AMA #12: Strategies for longevity (which don’t require a doctor)](https://peterattiamd.com/ama12/) | Peter Attia (peterattiamd.com)

**Podcast with Tom Dayspring which explains how ApoB particles would be elevated due to high levels of triglycerides needing to be trafficked**: [#129 – Tom Dayspring, M.D.: The latest insights into cardiovascular disease and lipidology](https://peterattiamd.com/tomdayspring6/) | Peter Attia (peterattiamd.com) [50:30]

**The Mark Rippetoe program which Peter recommends to certain patients that includes heavy compound movements with progressive overload**: [Starting Strength](https://startingstrength.com/) | (startingstrength.com) [55:30]

**Peter’s recent email about PFOA in Topo Chico**: [Topo Chico](https://peterattiamd.com/topo-chico/) | Peter Attia (peterattiamd.com) [58:25]

**Peter’s favorite bubbly water**: [Topo Chico](https://www.topochicousa.net/) | (topochicousa.net) [58:25]

**The DuPont case—A study of workers living near a DuPont Teflon plant found an association between PFOA exposure and two kinds of cancer as well as four other diseases**: [59:15]

- [Perfluorooctanoic acid](https://en.wikipedia.org/wiki/Perfluorooctanoic_acid) | (wikipedia.org)
- [PFOA and Cancer in a Highly Exposed Community: New Findings from the C8 Science Panel](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3855507/) (Wendee Nicole, 2013)

**Peter’s second favorite bubbly water**: [Waterloo](https://www.drinkwaterloo.com/) | (drinkwaterloo.com) [1:01:30]

§

## People Mentioned

- [Mike Liut](https://en.wikipedia.org/wiki/Mike_Liut) [1:45]
- [Rajpaul Attariwala](https://peterattiamd.com/rajpaulattariwala/) [7:15]
- [Dr. Evil](https://en.wikipedia.org/wiki/Dr._Evil) [22:20]
- [Lawrence Golding](https://obits.reviewjournal.com/obituaries/lvrj/obituary.aspx?n=lawrence-a-golding&pid=189330779) [25:00]
- [Rob Lustig](https://twitter.com/RobertLustigMD?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [39:30]
- [Paul Conti](https://www.pacificpremiergroup.com/meet-our-team/) [44:45]
- [Tom Dayspring](https://twitter.com/Drlipid?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [50:30]
- [Evander Holyfield](https://en.wikipedia.org/wiki/Evander_Holyfield) [52:15]
- [Mark Rippetoe](https://twitter.com/coachrippetoe?lang=en) [55:30]

§