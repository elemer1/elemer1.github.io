# #134 – James O’Keefe, M.D.: Preventing cardiovascular disease and the risk of too much exercise

**Source:** [https://peterattiamd.com/jamesokeefe/](https://peterattiamd.com/jamesokeefe/)

---

James O’Keefe is a preventative cardiologist and bestselling author of The Forever Young Diet and Lifestyle. In this episode, James discusses cardiac physiology and what makes the human heart susceptible to disease. He provides evidence for what supports his approach to exercise–elucidating both positive and negative kinds of exercise for heart health. He also discusses the role of nutrition, specific nutrients, and pharmacological interventions to support heart and brain longevity.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jamesokeefe/the_Drive_public.png)

Play

#134 - James O'Keefe, M.D.: Preventing cardiovascular disease and the risk of too much exercise.

#134 - James O'Keefe, M.D.: Preventing cardiovascular disease and the risk of too much exercise.

1x15s30s

0:002:09:17

## We discuss:

- James’ background and why he favors a preventative approach to cardiology [3:15];
- Understanding atherosclerosis and the misconception that it’s a “plumbing problem” [10:15];
- The danger in excessive exercise—a reverse J-shaped mortality curve [21:15];
- The story of Micah True—a case study of excessive exercise [49:15];
- The best kinds of exercise for longevity—The Copenhagen City Heart Study [53:00];
- Being a more balanced athlete and finding the right exercise intensity [58:45];
- Heart rate during exercise, resting heart rate, and other important metrics [1:04:00];
- Nutrition for cardiovascular health [1:09:45];
- Important nutrients: Magnesium, potassium, calcium, sodium, and collagen [1:19:30];
- SGLT2 inhibition for diabetes, cardio-protection, and general longevity [1:24:15];
- GLP-1 agonists for weight loss and reducing cardiovascular risk [1:34:15];
- Statins—mechanism of action, safety, and useful alternatives [1:37:25];
- A 40-year view on cardiovascular risk, and the possibility of reversing arterial calcification [1:45:45];
- Evidence for high dose EPA and DHA for the reduction of cardiovascular disease risk [1:53:30];
- The impact of omega-3, curcumin, and other compounds on mental health and dementia [1:59:00];
- James’ focus beyond cardiology [2:02:15]; and
- More.

§

## Show Notes

## James’ background and why he favors a preventative approach to cardiology [3:15]

**How Peter and James met**

- Peter first met James more than ten years ago at a conference James spoke at
- Peter was shocked to learn from James’ talk that the 20-23 hours per week of cycling he was doing may be harmful

**James’ background**

- Based on his fascination with the heart, he knew as young as age 13 or 14 that he wanted to become a cardiologist
- He started out as an interventional cardiologist, which is a cardiologist who focuses on corrective procedures such as installing stents and pacemakers and replacing heart valves
- He trained at the [Mayo Clinic](https://www.mayoclinic.org/)
- In 1988, he started working at the [Mid America Heart Institute](https://www.saintlukeskc.org/locations/saint-lukes-mid-america-heart-institute#) with [Geoffrey Hartzler](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.112.113274), who invented [infarct angioplasty](https://en.wikipedia.org/wiki/Angioplasty)
- A year or two into his career, he realized that angioplasty was not the ideal way to treat cardiovascular disease, which led to his interest in a more **preventative** approach

> “*Even though it’s the leading killer in America, [coronary disease] should be an entirely preventable, medically-managed disease. Unless you have an MI [heart attack], you don’t need to be going in having procedures, stents electively. We have the tools.*”

## Understanding atherosclerosis and the misconception that it’s a “plumbing problem” [10:15]

**Balloon angioplasty and stents**

- Coronary arteries are narrow – the [left coronary artery](https://en.wikipedia.org/wiki/Left_coronary_artery) for example is less than a half centimeter or a third of an inch wide
- During [angioplasty](https://en.wikipedia.org/wiki/Angioplasty), a catheter with a deflated balloon is inserted into the narrowing artery and the balloon is inflated with saline to restore flow
- In some cases, a [stent](https://en.wikipedia.org/wiki/Stent) is left behind to preserve the opening
- In cases of asymptomatic blockage, there is no evidence of benefit for stents (and only some evidence of benefit in an acute MI situation)
- Yet, stents are used frequently —
  - partly because of the economic incentive to do the procedure
  - But also because of this flawed paradigm: That this it’s a “plumbing” issue

*The flawed paradigm is this*: That blocked arteries are simply a plumbing issue—

- The thinking is …“You have blockages in your arteries. Well, duh. You get rid of the clog. That’s simple.”
- But in reality, “*As logical as that is, it doesn’t really turn out to be true.*”

⇒ For more on the overuse of stents, see [episode of The Drive with Ethan Weiss](https://peterattiamd.com/ethanweiss/)

**The zit analogy for explaining atherosclerosis/cardiovascular disease:**

- Similar in concept to a [pimple or pustule](https://en.wikipedia.org/wiki/Pimple), atherosclerosis starts with accumulation of oxidized triglycerides and LDL cholesterol that attracts monocytes and macrophages
- The monocytes and macrophages promote inflammation and thin the overlying collagen layer, facilitating rupture and subsequent development of scar tissue
- In response to rupture, [platelets](https://en.wikipedia.org/wiki/Platelet) and [fibrinogen](https://en.wikipedia.org/wiki/Fibrinogen) accumulate into a [thrombus](https://en.wikipedia.org/wiki/Thrombus) (blood clot)
- Calcification of the arterial tissue is part of the healing process
- Angioplasty is useful for opening a blocked artery during a heart attack, **but causes further damage in the process**
  - This is the basis for why James believes a **preventative approach** (i.e., lifestyle change) is more appropriate for asymptomatic cases

**Context around what calcification and a calcium score really means:**

*Peter’s “bars on the window” analogy:*

- One of Peter’s patients had a calcium score of ~100, which put him at the 75th to 90th percentile of risk for his age
- In the three locations primarily affected, he had 30% to 50% blockage
- Peter points out that this blockage and calcification is like bars on a window – it does not indicate that a break-in is about to happen, but rather that it is a bad neighborhood and that a break-in likely occurred in the past
- “*It’s telling us that now is the time to act and add other agents to our toolkit for how we’re going to prevent myocardial death*.”

**Assessment of coronary arterial calcification**

- James uses an inexpensive ($50 per test) and low-radiation CT scan called [CardioScan](https://www.saintlukeskc.org/cardioscan#) to measure coronary arterial calcification
- He believes that for men over age 40 and women over age 60, CardioScan is the equivalent of the mammogram for the heart (i.e., everyone should have one)
- James has seen cases where coronary arterial calcification exceeds calcification of the spine!
- Predisposition to arterial calcification is partly genetic, but in James’ words is “a highly modifiable process”

> “*We can’t make the acne scars go away. They’re there forever once you have those calcium deposits. But we can pretty much make the risk go away. That’s why prevention is just so effective and so instrumental.*”

![](https://peterattiamd.com/wp-content/uploads/2020/10/anatomy-of-the-heart-okeefe-1024x608.png)

**Figure 1. Anatomy of the heart.** Image credit: [wikipedia.org](https://en.wikipedia.org/wiki/File:Coronary_arteries.png)

## The danger in excessive exercise—a reverse J-shaped mortality curve [21:15]

**If exercise were a drug …**

- It would be *the best drug* we have for preventing heart disease, dementia, osteoporosis, depression, diabetes, and obesity
- But like any drug, the dose must be appropriate
- For decrease of serious cardiovascular disease, benefit of exercise starts at just 15 minutes of brisk walking per day and increases with an increasing amount of exercise
- At the most extreme doses of exercise, however, some of the benefit is lost

> “*If exercise were a drug, it would be the best drug we have for preventing heart disease . . .preventing dementia, preventing osteoporosis, depression, diabetes, obesity.*”

⇒ Watch Peter [swim the Catalina Channel](https://www.youtube.com/watch?v=yMQFd9q07Zo)

**The amazing pumping capacity of the heart**

- The heart is only about the size of a fist, but continuously pumps about 5 liters of blood throughout the body per minute, amounting to three to four billion beats throughout a lifetime
- During intense activity, the hearts of some athletes pump as much as 30-35 liters of blood per minute!
- Professional cyclists and cross country skiers get as high as 40 liters per minute
- In a well trained athlete, intense exercise will increase heart rate by about three-fold, say 45 to 170 bpm for example
- The volume of blood being pumped, however, increases by about six-fold (5 to 30+ liters per minute)
- Increased cardiac output, or the volume of blood pumped per beat, explains this discrepancy
- For cardiac output to increase, the internal volume of the heart must also increase. With extreme amounts of exercise, this stretching of the heart can be problematic

*Oxidative stress of exercise*

- In addition, exercise creates oxidative stress. After about 45 to 50 minutes of high-intensity exercise, the body’s antioxidant capacity to resolve the [oxidative stress](https://en.wikipedia.org/wiki/Oxidative_stress) is exhausted and [endothelial](https://en.wikipedia.org/wiki/Endothelium) function is negatively affected at this point
- This coincides with increased blood levels of [troponins](https://en.wikipedia.org/wiki/Troponin) and the [N-terminal prohormone of brain natriuretic peptide](https://en.wikipedia.org/wiki/N-terminal_prohormone_of_brain_natriuretic_peptide) (NT pro-BNP), which are both markers of heart damage

**Dial it back as you age**

- Especially after age 40 or 45, really protracted exercise will cause those small little micro damage, like overstretching and tearing
- This happens because the high levels of catecholamines and free radicals that are now unbuffered

> “*If you want to run a marathon, fine, run one or two. It’s like climbing Mount Everest, if you ever do that, do it once, but don’t do it three times a year. . . you’ve got to move on to healthier forms of exercise.*”

**Longevity versus performance**

- A Formula One car is fast and powerful – it will perform at peak levels, but is not going to last for 500,000 miles
- In contrast, a car that can last 500,000 miles is going to be more like a Honda Accord that has been well maintained and never driven faster than 70 mph.
- In short, longevity and performance are different goals
- In regard to health, James notes that if you want to run a marathon or do something similar for the sake of accomplishment, that is fine, but it should not become a regular habit
- Peter notes how some of his patients find purpose and/or comradery in extreme exercise and it is sometimes a struggle for them to embrace the tradeoff
  - It took Peter three years to embrace the tradeoff himself
- James experienced this tradeoff himself—He competed in triathlons up until his mid forties, when he started noticing concerns with his heart rhythm, including premature [ventricular](https://en.wikipedia.org/wiki/Premature_ventricular_contraction) and [atrial](https://en.wikipedia.org/wiki/Premature_atrial_contraction) contractions and [supraventricular tachycardia](https://en.wikipedia.org/wiki/Supraventricular_tachycardia)
  - Premature ventricular contractions can be caused by the high levels of catecholamines and oxidative stress produced during prolonged intense exercise, resulting in fibrosis and scar tissue that can disrupt heart rhythm and facilitate development of [atrial fibrillation](https://en.wikipedia.org/wiki/Atrial_fibrillation)
- A [Harvard study](https://www.nejm.org/doi/full/10.1056/NEJM198603063141003) by one of the “godfathers of the exercise movement” showed that the people who exercised the most lost 38% of the longevity benefit compared to those who exercised more moderately
- [Ken Cooper](https://en.wikipedia.org/wiki/Kenneth_H._Cooper), one of the founding fathers of modern aerobics once said, “*If you’re running more than 15 miles a week, you’re doing it for some other reason besides health*.”
- Further demonstrating the concerns of excessive exercise, professional cyclists [have been shown](https://academic.oup.com/eurheartj/article/29/1/71/2398434) to be more likely to develop atrial fibrillation

## The story of Micah True—a case study of excessive exercise [49:15]

**Micah True**

- He was an ultra-distance runner and is the subject of the popular book, [Born to Run](https://www.amazon.com/Born-Run-Hidden-Superathletes-Greatest/dp/0307279189)
- He frequently ran 50-100 mile races in the desert heat
- At the age of 58, he died suddenly while running
- An autopsy of his heart revealed scarring of the [atria](https://en.wikipedia.org/wiki/Atrium_(heart)) and [ventricles](https://en.wikipedia.org/wiki/Ventricle_(heart)), particularly the right ventricle and the [interventricular septum](https://en.wikipedia.org/wiki/Interventricular_septum)

**Evidence supporting the reverse J-shaped curve**

- Since it is not practical to do randomized controlled trials on longevity for humans, the supporting data is primarily epidemiological
- Experimental studies, however, have been done in dogs and mice, and they have shown excessive exercise to result in dilated heart chambers
- James recently published a [review paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7431070/) describing 10 large epidemiological studies, and all but two showed a very distinct reverse J-shaped curve for exercise dose and mortality

![](https://peterattiamd.com/wp-content/uploads/2020/10/reverse-J-curve-for-exercise-okeefe-1024x551.png)

**Figure 2. The reverse J-shaped curve for exercise dose and all-cause mortality demonstrated in 7 of 9 epidemiological studies.** Image credit: [O’Keefe et al., 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7431070/)

## The best kinds of exercise for longevity—The Copenhagen City Heart Study [53:00]

[The Copenhagen City Heart Study](https://www.sciencedirect.com/science/article/abs/pii/S002561961830538X)

- Nearly 10,000 Danes were followed for more than 20 years
- This study is the equivalent of the [Framingham study](https://en.wikipedia.org/wiki/Framingham_Heart_Study), but for exercise
- Participants were grouped based on type of physical activity, including running, cycling, swimming, “health club activities” (i.e., exercising at a gym), tennis, badminton, and soccer
- James was shocked by the [results](https://www.sciencedirect.com/science/article/abs/pii/S002561961830538X) – tennis, badminton, and soccer were associated with the greatest longevity benefit, followed by running, cycling, calisthenics, and swimming
- As demonstrated in a [meta-analysis](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1000316&mod=article_inline), research has shown that **social relationships** are as important for predicting longevity as other well-established factors such as smoking and exercise
- Based on this, **James believes that the benefits of activities like tennis, badminton, and soccer are that they “*****combine two medicines instead of one*****” by** **combining exercise with social interaction**
- A major limitation of the Copenhagen study (and any multivariate analysis) is that
  - 1) A lot of variables can’t be teased out
  - 2) You don’t have the ability to closely understand the intervention—in this case there is tremendous variation in how the activities are being carried out, particularly in the “health club activities” category

“*… if you’re training for longevity, yeah, take it down a couple of notches, but also make sure that you have some play in your life. We played as kids, we need to be playing as adults even more because it’s so important, not only for social bonding from stress relief or antidepressant.*”

## Being a more balanced athlete and finding the right exercise intensity [58:45]

**The “opportunity cost” of extreme exercise and the need for balance**

- Peter uses lost time as an argument against excessive exercise
- For example, running 50 miles per week requires so much time that does not leave adequate times for other important types of exercise such as strength training
- It also leaves less time to spend with family
- Peter notes that “*life is a pretty complicated sport and it requires strength, stability, aerobic fitness, and anaerobic fitness.*”
- James recommends things that will keep resting heart rate low, but also *some* high-intensity interval training to maintain maximal capacity, “*high volumes are really high intensity exercise is just not the ideal approach to fitness*”

“*… after 30 or 45 minutes of aerobic exercise, if you want to do more circle back home and do some yoga, do some weights, these things that don’t necessarily tax your heart the same way that the other high intensity sports do*.”

**Finding the right exercise intensity**

- Peter describes the importance of **zone 2 aerobic exercise**, which is done at a relatively low intensity, but approximately the highest intensity prior to mitochondrial capacity being exceeded and lactate accumulation increasing
- Zone 2 exercise was discussed in great depth in [podcast episode 85 with Iñigo San Millán](https://peterattiamd.com/inigosanmillan/)
- Peter also notes that most people do not spend not enough time at this intensity and spend too much time at intensities between zone 2 and maximal intensity
- A rough ratio should be 80% zone 2 and 20% zone 5 (i.e., max capacity)
- He believes **this middle area of intensity (zones 3-4) is the least important zone to be training within**

## Heart rate during exercise, resting heart rate, and other important metrics [1:04:00]

James is often asked, “*What should your heart rate be during exercise?*”

- James actually recommends that people not pay much attention to heart rate during exercise
- Instead, the most important parameters about pulse are:
  - [Resting HR](https://blog.ouraring.com/resting-heart-rate/)—We want to get that nice and low
  - [Heart rate variability](https://blog.ouraring.com/what-is-heart-rate-variability/)—
    - we want that to be more variable when you take slow deep breaths
    - This is why meditation or yoga is a really good thing to add to somebody’s fitness regimen

![](https://peterattiamd.com/wp-content/uploads/2020/10/HRV-okeefe-1024x520.png)

**Figure 3. Heart rate variability (HRV).** Image credit: [ouraring.com](https://blog.ouraring.com/what-is-heart-rate-variability/)

This [JAMA study](https://jamanetwork.com/journals/jama/article-abstract/2763292) looked at the benefits of low-intensity exercise (i.e., lower heart rate)

- It showed that simply walking 12,000 steps per day decreased mortality risk by about two thirds
- Also supporting the idea of their being a point of diminishing returns for exercise dosage, the benefit of walking steadily increased up until 12,000 steps per day, where it plateaued

![](https://peterattiamd.com/wp-content/uploads/2020/10/steps-and-mortality-okeefe-1024x701.png)

**Figure 4. Association between steps per day and all-cause mortality.** Image credit: [Saint-Maurice et al., 2020](https://jamanetwork.com/journals/jama/article-abstract/2763292)

**Interpreting resting heart rate**

*What plays a role in resting HR?*

- Peter has noticed variation in the resting heart rate of his patients and wonders to what extent genetics is a contributing factor
- At equivalent fitness levels, women tend to have higher fasting heart rates than men
- A lower resting heart rate is associated with increased longevity
- Later in life, [sick sinus syndrome](https://www.mayoclinic.org/diseases-conditions/sick-sinus-syndrome/symptoms-causes/syc-20377554) can lower heart rate
- Alcohol consumption, stress, and inadequate sleep can all increase resting heart rate

*As a marker of health status*

- James notices that lifestyle factors like overtraining, poor sleep, a lot of travel, stress, and illness will typically increase his resting heart rate by 5 or more beats per minute
- In James’ practice, it is common for his patients to lower their resting heart rate by 5-10 beats per minute through lifestyle intervention
- Greater decreases require serious commitment to losing weight, exercising, and getting fit
  - Drops in resting heart rate are often accompanied by decreases in abdominal fat, blood pressure, triglycerides, and [hemoglobin A1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin)

## Nutrition for cardiovascular health [1:09:45]

**Jame’s experience with traditional dietary recommendations**

- When he was in medical school (1980s), low-fat diets like the [Pritikin Diet](https://en.wikipedia.org/wiki/Pritikin_diet) were very popular
- This type of diet was a “disaster” for him:
  - Triglycerides increased from 80 to 300
  - HDL-C decreased from 50 to 33
  - His athletic performance declined
  - Overall, he was not feeling as well

**The Mediterranean diet**

- James believes that a Meditteranean diet emphasizing fish and minimization of refined carbohydrates, combined with intermittent fasting, is the best dietary approach for cardiovascular health
  - He recently published a [review article](https://www.onlinejacc.org/content/76/12/1484.abstract) on this topic
- He also believes that this dietary approach is also beneficial for preventing diabetes, dementia, obesity, and other common chronic diseases
- Peter and James agree that [PREDIMED](https://www.predimed.es/) is a landmark nutrition study
  - This study was a randomized controlled trial that not only found a Mediterrenean diet to decrease risk of major cardiovascular events by about 30%, but showed decreased risk of diabetes, cognitive decline, and obesity in followup studies
  - Interestingly, it was the added fat from olive oil and nuts that correlated best with the observed benefits
- James believes that a ketogenic diet should be structured more like a Mediterranean diet – it should emphasize fat from nuts, seeds, extra virgin olive oil, avocados, and oily fish over foods like cream cheese, butter, and red meat

> “*… a diet that’s moderately high in fat, very low in refined carbohydrates, almost no added sugar, and minimal white refined grains but high in nuts and extra virgin olive oil and high in fish and seafood and high in vegetables and low in processed food, and drinking mostly water tea, coffee, fasting for at least 12 hours each 24-hour period of time and preferably moving to a 14- or 16-hour fast per day, we think this is arguably the healthiest cardiovascular diet.*”

**Nuances of olive oil**

- As suggested by [Emilio Ros](https://www.researchgate.net/profile/Emilio_Ros), the primary investigator for the PREDIMED study, the benefits of olive oil depend on it being extra virgin and having high [polyphenol](https://en.wikipedia.org/wiki/Polyphenol) content
  - This type of olive oil should give a sensation at the back of the throat similar to black pepper
- One [study](https://www.onlinejacc.org/content/36/5/1455.abstract) found olive oil to have a negative effect on endothelial function, and according to James, this is because a high-polyphenol olive oil was not used
- Peter points out how consumers need to be aware – sometimes even products labeled as extra virgin olive oil are really nothing more than canola oil with some olive oil mixed in

**Saturated fat**

- Peter notes that the epidemiology is confounded by people who consume more saturated fat typically also consuming unhealthy ingredients like refined carbohydrates
- James believes that a moderate amount of saturated fat is part of our evolutionary history, but that an excessive amount is not a good idea
- That said, he believes that **sugar and other refined carbohydrates are a much greater concern**

“*… that is again, our evolutionary history. We ate a lot of red meat and we ate saturated fats. The evil white crystal in the American diet is not salt. The worst is sugar. And sugar and refined carbohydrates are by far the absolute worst dietary villain. Saturated fat… A little bit of butter is not going to kill you.*”

## Important nutrients: Magnesium, potassium, calcium, sodium, and collagen [1:19:30]

**Magnesium and Potassium**

- Peter is a strong proponent of magnesium:
  - Peter likes it in the form of oxide combined with a slow mag
  - Peter finds that supplementing magnesium on the order of two grams of magnesium a day almost always makes his patients feel better
- James points out that our evolutionary ancestors were getting about five times more magnesium and potassium (and fiber)
  - Part of the reason for this is that they ate “nose to tail”
- Magnesium is an important cofactor for many reactions in the body
- Nuts are a good source of magnesium
- James also agrees with 2 g/d of magnesium as the right amount

**Calcium**

- Eating “nose to tail” includes cooking bone, which provides [calcium hydroxyapatite](https://en.wikipedia.org/wiki/Hydroxyapatite), which James says is a more appropriate form to eat
- Standard calcium supplements are in the form of calcium carbonate and calcium gluconate, which James says “*… are rocks. We didn’t eat rocks. We ate bones.*”
- James believes that 1 g/d of calcium is a good target

**Collagen**

- Our ancestors consumed more collagen based on cooking bone and eating animal skin
- Since this is no longer common practice, James believes that collagen supplementation is valuable
- James points out that collagen is beneficial for hair, skin, nails, and bones;
- And it is even beneficial for building and maintaining muscle mass b/c of the [glycine](https://en.wikipedia.org/wiki/Glycine) and other amino acids

**Sodium**

- James notes the need to be careful with sodium intake for people with heart failure and kidney disease
- Despite this, he rarely recommends that people limit sodium to less than 1,500 mg/d and believes that 2,000 – 3,000 mg/d is a better target
- When following a diet based on whole foods, James recommends salting to taste since these foods are low in sodium

## SGLT2 inhibition for diabetes, cardio-protection, and general longevity [1:24:15]

**Background**

- [SGLT2 inhibitors](https://en.wikipedia.org/wiki/SGLT2_inhibitor) are a class of drugs that blocks [sodium glucose co-transporter 2](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_2) in the [tubule](https://en.wikipedia.org/wiki/Nephron#Renal_tubule) of kidney cells
- This basically blocks reabsorption of glucose, resulting in increased excretion of glucose through the urine
  - For this reason, SGLT2 inhibitors are used to treat diabetes

**Surprising benefits**

- [EMPA-REG](https://academic.oup.com/eurheartj/article/37/19/1526/2240594), the first large clinical trial on an SGLT2 inhibitor, showed a decrease in heart failure hospitalizations and cardiovascular deaths in type 2 diabetics
- More trials have been done, confirming this benefit and also showing decreased risk of kidney failure, **even in non-diabetics**

**SGLT2 inhibitors for longevity**

- Peter is interested in the potential of SGLT2 inhibition as an alternative to metformin for promoting longevity
- There is [evidence](https://onlinelibrary.wiley.com/doi/full/10.1111/acel.12880) of metformin impairing benefit from exercise, which does not appear to happen with SGLT2 inhibition

James adds…

- James prescribes SGLT2 inhibitors to all of his type 2 diabetic patients
- But even for a non-diabetic person, you urinate out about a hundred grams of sugar a day
- “*This basically is like pulling the plug and draining a substantial amount of sugar from your body every day.*”
- It raises ketones in your system—it taps into belly fat to get the fatty acids that then the liver turns into ketones

“*… we still don’t fully understand how it [SGLT2 inhibition] works, but it’s an important drug class that is going to only get bigger with respect to its impact on health and longevity*.”

***Why doesn’t it result in urinary tract infections?***

- By increasing urinary excretion of glucose, SGLT2 inhibition could be expected to increase urinary tract infections, but this has not been the case
- James, however, has noticed increased frequency of yeast infections in women
  - He recommends using a wet wipe after urination to help prevent this

**The role of insulin in the benefits of lowering glucose**

- Peter points out that lowering glucose in type 2 diabetics only decreases cardiovascular mortality when the decrease in glucose is achieved **without an increase in insulin**
- James refers to the [Drive podcast episode with Jason Fung](https://peterattiamd.com/jasonfung/) while describing insulin as an obesity-promoting hormone that accelerates atherosclerosis when present at high levels
  - For this reason, he considers **insulin therapy to be a last resort for type 2 diabetics**
- James co-authored a [review paper](https://www.sciencedirect.com/science/article/abs/pii/S0033062017301391) describing evidence of insulin therapy increasing cardiovascular risk in type 2 diabetics
- He also notes that part of the reason why other drugs for diabetics have cardiovascular benefit is through decreasing insulin

## GLP-1 agonists for weight loss and reducing cardiovascular risk [1:34:15]

**GLP-1 agonists**

- GLP-1 ([glucagon-like peptide-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1)) is a hormone that promotes insulin secretion and tends to decline in type 2 diabetics
- According to James, GLP-1 decreases [glucagon](https://en.wikipedia.org/wiki/Glucagon) production in the liver, thereby decreasing glucose production
- GLP-1 agonists lower fasting insulin and increase postprandial insulin
- James believes that GLP-1 agonists are great for weight loss and prescribes them accordingly
  - Constipation and/or nausea may occur initially, but are likely to disappear over time
  - In his patients, high-dose [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) results in weight loss of up to 10% of body weight
  - In non-diabetics, he combines GLP-1 agonists with SGLT2 inhibitors
- [Liraglutide](https://en.wikipedia.org/wiki/Liraglutide) is currently approved by the FDA for weight loss (for use once per day) and semaglutide is expected to be approved in the next year (for use once per week)
  - Despite the lower frequency (once per week), semaglutide has been shown in multiple studies to be more effective for weight loss and reduction of hemoglobin A1c. Cardiovascular benefit is greater as well
  - James notes that semaglutide is even an **alternative to bariatric surgery**
- James believes that **GLP-1 agonists and SGLT2 inhibitors make a great combination** because they promote weight loss and decrease cardiovascular risk through separate mechanisms (and are safe)

## Statins—mechanism of action, safety, and useful alternatives [1:37:25]

- Peter notes that although statins inhibit cholesterol synthesis, their benefit is more likely a result of increasing the LCL receptor in the liver
- As an example of statins having pleiotropic benefit, James points out a [study](https://www.ajconline.org/article/S0002-9149(20)30823-7/fulltext) showing statin use to be associated with less severe COVID-19 infection
  - This might be related to the anti-inflammatory effect statins are known to have
- Despite the large amount of evidence on efficacy of statins, Peter and James share their experience in having to defend against patients’ concerns about their use
  - This is likely driven by misinformation on the internet
  - While loss of [coenzyme Q10](https://en.wikipedia.org/wiki/Coenzyme_Q10) and associated muscle pain are legitimate concerns, they can be easily resolved through supplementation
  - James mentions [ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe) and [PCSK9](https://en.wikipedia.org/wiki/PCSK9) inhibitors as alternatives to statins that do not interfere with cholesterol synthesis (as discussed in the [latest Drive episode with Tom Dayspring](https://peterattiamd.com/tomdayspring6/))
    - The association with *decreased brain cholesterol with dementia* is a good reason to considering alternatives to statin therapy (including a diet high in omega-3 fatty acids)
    - For this reason, Peter measures [desmosterol](https://en.wikipedia.org/wiki/Desmosterol) and [lathosterol](https://en.wikipedia.org/wiki/Lathosterol) as markers of cholesterol synthesis in his patients, and is particularly cautious with patients who have one or two copies of [APOE-4](https://en.wikipedia.org/wiki/Apolipoprotein_E)

## A 40-year view on cardiovascular risk, and the possibility of reversing arterial calcification [1:45:45]

**10-year cardiovascular risk**

- If someone has a low 10-year risk calculation but has high [ApoB](https://en.wikipedia.org/wiki/Apolipoprotein_B), current recommendations are to do nothing beyond lifestyle modifications
- Based on the work of [Allan Sniderman](https://www.cardiomuhc.ca/allan-sniderman), Peter thinks it is more important to look at **30- or 40- year risk**
- James notes that ezetimibe and PCSK9 inhibitors are actually preferable to statins in this context because *statins can accelerate coronary artery calcification*
- Peter personally takes a low dose pravastatin plus PCSK9 inhibitor, but is considering doing the experiment of switching to from pravastatin over to Zetia to see what changes

**Regression of coronary artery calcification**

- Peter notes his calcium score of 6 at age 36
  - Peter suggests it was most likely attributable to a poor diet
  - James thinks that the high volume of high intensity exercise also played a role
- Peter has since decreased his calcium score to 0
  - James says you virtually never see scores go down—he has read about 150,000 calcium scores and considers this rare – calcium score usually increases by 25-30% or more per year
  - In one of James’ patients, however, he saw a calcium score over 1,000 drop by 200-300 after switching from statins to ezetimibe plus a PCSK9 inhibitor
    - A recent [study](https://www.nature.com/articles/s41514-018-0026-2) showed that using a PCSK9 inhibitor with a statin results in less coronary artery calcification than a statin alone
- Peter and James agree that re-testing calcium score is generally not necessary
  - Although it may serve as motivation for patients who are not following recommendations, it can be discouraging for patients who are doing everything right

> “…we can prevent cardiovascular events with all these strategies we’re talking about, despite the coronary calcium.”

## Evidence for high dose EPA and DHA for the reduction of cardiovascular disease risk [1:53:30]

**Background on omega-3 fatty acids**

- Similar to other nutrients, James notes that we’re eating less omega-3 fatty acids than our evolutionary ancestors, maybe by an order of magnitude
- Some people believe that access to shellfish and seafood corresponded with human brain expansion 300,000-400,000 years ago
- About twenty percent of the brain’s dry weight is made of omega-3 fatty acids, particularly [docosahexaenoic acid](https://en.wikipedia.org/wiki/Docosahexaenoic_acid) (DHA) from neuron membranes.

**Evidence supporting a decrease in cardiovascular risk from omega-3s**

- The [REDUCE-IT trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1812792) showed 4 g/d of a purified form of [eicosapentaenoic acid](https://en.wikipedia.org/wiki/Eicosapentaenoic_acid) (EPA) to decrease cardiovascular deaths and events in people with cardiovascular disease, diabetes, or risk factors including high triglycerides by 20%
- Another recent trial, the [EVAPORATE study](https://academic.oup.com/eurheartj/advance-article/doi/10.1093/eurheartj/ehaa652/5898836), showed 4 g/d of the same purified form of EPA to decrease coronary plaque by 17%
- The [STRENGTH trial](https://onlinelibrary.wiley.com/doi/full/10.1002/clc.23055), however, looked at the effects of 4 g/d of a fish oil derivative including EPA+DHA on cardiovascular outcomes and was [terminated early](https://www.astrazeneca.com/media-centre/press-releases/2020/update-on-phase-iii-strength-trial-for-epanova-in-mixed-dyslipidaemia-13012020.html) due to expected lack of effect
- A recent [meta-analysis](https://www.sciencedirect.com/science/article/pii/S002561962030985X) of 40 studies found EPA+DHA to decrease cardiovascular death and events
  - Risk of fatal myocardial infarction was decreased by 35%
  - Overall risk decreased by 5.8% for each additional gram per day of EPA+DHA (max dose evaluated was less than 6 g)
- James believes that dosage is important – 2 to 4 g/d produces impressive results while most studies that fail to find benefit have used lower doses
- Although it is not clearly known if EPA is better alone or in combination with DHA, James believes it is logical to include DHA based on its role in the brain and that we consumed EPA and DHA together throughout our evolutionary history

**Sources of omega-3s**

- Peter and James agree that diet, particularly oily fish, is the best source of omega-3s
- Peter recommends [Carlson](https://carlsonlabs.com/omega-3-fish-oils/) as a supplemental source of omega-3 based on a third party lab analysis he had done
- James is Chief Medical Officer for a company named [CardioTabs](https://www.cardiotabs.com/) that produces high-quality omega-3 supplements sourced from Scandinavia

## The impact of omega-3, curcumin, and other compounds on mental health and dementia [1:59:00]

*Potential cognitive benefits of omega-3 and* [*curcumin*](https://en.wikipedia.org/wiki/Curcumin)

- James believes that omega-3 supplementation is cheap and safe, with profound benefits that can help keep people off of antidepressant medications
- James recently published a [review](https://content.iospress.com/articles/journal-of-alzheimers-disease/jad200711) with Richard Isaacson describing the [TNF-α](https://en.wikipedia.org/wiki/Tumor_necrosis_factor)-lowering benefit of highly-absorbable curcumin ([Theracurmin](https://theravalues.com/english/business-products/theracurmin/)) for preventing Alzheimer’s disease
  - He points out that there is observational data on millions of people suggesting that TNF-α inhibition decreases Alzheimer’s risk by 60-70% (this data is reviewed in the publication above)
- The Alzheimer’s risk factors Peter has identified with Richard Isaacson (as discussed in [Drive episode 18](https://peterattiamd.com/richardisaacson/)):
  - Age above 60 years
  - Family history of Alzheimer’s disease
  - Presence of the APOE-4 gene
  - Consideration of additional genes associated with Alzheimer’s, including anti-TNF genes and [TOMM40](https://en.wikipedia.org/wiki/TOMM40)
- Consistent with James’ paper above, Peter includes Theracurmin in his approach for Alzheimer’s prevention

“*Upwards of like 90% of Americans aren’t getting enough omega-3 in their diet and it correlates with depression, ADHD, suicide, cognition, dementia, all those things … this is like a super easy way to markedly improve mental health*.”

## James’ focus beyond cardiology [2:02:15]

How James progressed from being a “cath jockey” to caring about things like curcumin and Alzheimer’s prevention

- James simply “followed his heart” and says that he loves what he does to the extent that he would still do it without pay
- For people aspiring to be medical professionals who focus on prevention, James advises that it does not have to be all or nothing – you can be involved in the more standard and reactive aspects of medicine, such as angioplasty and lipid lowering, but you can limit this to just a portion of your focus
  - James also points out that working in a large medical group makes it easier for him to carve out his own niche
- James believes that prevention will become a more important part of medicine as more people realize the payoff in regard to getting more out of life

“*… this whole world is set up to minimize activity and maximize calorie consumption, but there’s also people who are paying close attention and we have all of these powerful tools and use this information to help each other and to live not only longer, but more sort of active and fulfilling and enjoyable lives.*”

§

## Selected Links / Related Material

**Episode of The Drive with Ethan Weiss discussing the overuse of stents**: [#52 – Ethan Weiss, M.D.: A masterclass in cardiovascular disease and growth hormone – two topics that are surprising interrelated](https://peterattiamd.com/ethanweiss/) | Peter Attia (peterattiamd.com) [12:15]

**An inexpensive and low-radiation type of CT scan used by James and his colleagues for measuring coronary artery calcification**: [CardioScan](https://www.saintlukeskc.org/cardioscan#) | (saintlukeskc.org) | [18:45]

**Peter swimming the Catalina Channel**: [Peter Attia crossing Catalina Channel](https://www.youtube.com/watch?v=yMQFd9q07Zo) | Peter Attia (youtube.com) [24:45]

**A Harvard study by one of the “godfathers of the exercise movement” showing that while exercise increased longevity, the benefit was decreased with the greatest amounts of exercise**: [Physical activity, all-cause mortality, and longevity of college alumni](https://www.nejm.org/doi/full/10.1056/NEJM198603063141003) (Paffenbarger et al., 1986) | [44:15, 51:15]

**A study showing former professional cyclists to have increased risk for atrial fibrillation**: [Sinus node disease and arrhythmias in the long-term follow-up of former professional cyclists](https://academic.oup.com/eurheartj/article/29/1/71/2398434) (Baldesberger et al., 2008) | [46:15]

**A popular book about running and a Mexican tribe of incredible distance runners:** [Born to run: A hidden tribe, superathletes, and the greatest race the world has ever seen](https://www.amazon.com/Born-Run-Hidden-Superathletes-Greatest/dp/0307279189) (amazon.com) | [49:30]

**A review James and his colleagues recently published on the reverse J-shaped curve for exercise and mortality**: [Training for longevity: The reverse J-curve for exercise](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7431070/) (O’Keefe et al., 2020) | [51:45]

**A long-term prospective study on the best type of physical activity for longevity**: [Various leisure-time physical activities associated with widely divergent life expectancies: The Copenhagen City Heart Study](https://www.sciencedirect.com/science/article/abs/pii/S002561961830538X) (Schnohr et al., 2018) | [53:00]

**A meta-analysis showing the influence of social relationships to comparable to other well-established factors such as smoking and exercise**: [Social relationships and mortality risk: A meta-analytic review](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1000316&mod=article_inline) (Holt-Lunstad et al., 2010) | [56:00]

**The Drive episode on zone 2 exercise**: [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com) | [1:02:15]

**A study showing 12,000 steps per day to decrease mortality risk by about two thirds**: [Association of daily step count and step intensity with mortality among US adults](https://jamanetwork.com/journals/jama/article-abstract/2763292) (Saint-Maurice et al., 2020) | [1:04:30]

**A review James co-authored on the Mediterranian Diet and intermittent fasting in regard to cardiovascular health**: [A pesco-Mediterranean diet with intermittent fasting](https://www.onlinejacc.org/content/76/12/1484.abstract) (O’Keefe et al., 2020) | [1:11:30]

**The PREDIMED study—A large clinical trial that found the Meditteranian diet to decrease the risk of cardiovascular events, cognitive decline, diabetes, and obesity**: [Primary Prevention of Cardiovascular Disease with a Mediterranean Diet Supplemented with Extra-Virgin Olive Oil or Nuts](https://www.nejm.org/doi/full/10.1056/NEJMoa1800389) (Estruch et al., 2018)  [1:12:30]

**A study showing olive oil to impair endothelial function**: [The postprandial effect of components of the Mediterranean diet on endothelial function](https://www.onlinejacc.org/content/36/5/1455.abstract) (Vogel et al., 2000) | [1:15:15]

**A clinical trial showing an SGLT2 inhibitor to decrease heart failure hospitalizations and cardiovascular deaths in type 2 diabetics**: [Heart failure outcomes with empagliflozin in patients with type 2 diabetes at high cardiovascular risk: results of the EMPA-REG OUTCOME trial](https://academic.oup.com/eurheartj/article/37/19/1526/2240594) (Fitchett et al., 2016) | [1:25:00]

**A study showing metformin to blunt benefits of exercise**: [Metformin inhibits mitochondrial adaptations to aerobic exercise training in older adults](https://onlinelibrary.wiley.com/doi/full/10.1111/acel.12880) (Konopka et al., 2019) | [1:26:30]

**The Drive episode on fasting with Jason Fung**: [#59 – Jason Fung, M.D.: Fasting as a potent antidote to obesity, insulin resistance, type 2 diabetes, and the many symptoms of metabolic illness](https://peterattiamd.com/jasonfung/) | Peter Attia (peterattiamd.com) | [1:31:30]

**A review paper co-authored by James describing concerns associated with insulin treatment**: [Insulin therapy increases cardiovascular risk in type 2 diabetics](https://www.sciencedirect.com/science/article/abs/pii/S0033062017301391) (Herman et al., 2017) | [1:33:15]

**A study showing statin use to be associated with less severe COVID-19 infection**: [Meta-analysis of effect of statins in patients with COVID-19](https://www.ajconline.org/article/S0002-9149(20)30823-7/fulltext) (Kow & Hasan, 2020) | [1:38:45]

**The latest Drive episode with Tom Dayspring**: [#129 – Tom Dayspring, M.D.: The latest insights into cardiovascular disease lipidolog](https://peterattiamd.com/tomdayspring6/)y | Peter Attia (peterattiamd.com) [1:41:30]

**A study suggesting that PCSK9 inhibitors may decrease coronary artery calcification**: [The annual rate of coronary artery calcification with combination therapy with a PCSK9 inhibitor and a statin is lower than that with statin monotherapy](https://www.nature.com/articles/s41514-018-0026-2) (Ikemagi et al., 2018) | [1:51:45]

**James’ wellness clinic that manages risk for cardiovascular disease and type 2 diabetes**: [Saint Luke’s Charles & Barbara Duboc Cardio Health & Wellness Center](https://www.saintlukeskc.org/saint-lukes-charles-barbara-duboc-cardio-wellness-center#) (saintlukeskc.org) | [

**A clinical trial showing a purified form of EPA to decrease secondary cardiovascular risk in people with established disease or risk factors**: [Cardiovascular risk reduction with icosapent ethyl for hypertriglyceridemia](https://www.nejm.org/doi/full/10.1056/NEJMoa1812792) (Bhatt et al., 2019) | [1:54:30]

**A meta-analysis that found EPA+DHA to decrease cardiovascular risk in a dose-dependent manner**: [Effect of omega-3 dosage on cardiovascular outcomes: an updated meta-analysis and meta-regression of interventional trials](https://www.sciencedirect.com/science/article/pii/S002561962030985X) (Bernasconi et al., 2020) | [1:55:30]

**A clinical trial showing a purified form of EPA to decrease coronary plaque by 17%**: [Effect of icosapent ethyl on progression of coronary atherosclerosis in patients with elevated triglycerides on statin therapy: final results of the EVAPORATE trial](https://academic.oup.com/eurheartj/advance-article/doi/10.1093/eurheartj/ehaa652/5898836) (Budoff et al., 2020) | [1:56:30]

**Discontinuation of the STRENGTH trial for reduction of cardiovascular risk with EPA+DHA**: [Update on phase III STRENGTH trial for Epanova in mixed dyslipidaemia](https://www.astrazeneca.com/media-centre/press-releases/2020/update-on-phase-iii-strength-trial-for-epanova-in-mixed-dyslipidaemia-13012020.html) (astrazeneca.com) | [1:57:00]

**The brand Peter recommends for omega-3 supplements based on a third party lab analysis he had done**: [Carlson](https://carlsonlabs.com/omega-3-fish-oils/) (carslonlabs.com) | [1:57:45]

**A supplement company that James is the Chief Medical Officer for, and sells high-quality omega-3 supplements**: [CardioTabs](https://www.cardiotabs.com/) (cardiotabs.com) | [1:58:15]

**A review published by James and Richard Isaacson on the benefits of using curcumin for prevention of Alzheimer’s**: [Therapeutic potential of TNF-α inhibition for Alzheimer’s disease prevention](https://content.iospress.com/articles/journal-of-alzheimers-disease/jad200711) (Torres-Acosta et al., 2020) | [1:59:15]

**A highly bioavailable form of curcumin**: [Theracurmin](https://theravalues.com/english/business-products/theracurmin/) (theravalues.com) | [1:59:15]

**The Drive episode with Richard Isaacson**: [#18 – Richard Isaacson, M.D.: Alzheimer’s prevention](https://peterattiamd.com/richardisaacson/) | Peter Attia (peterattiamd.com) | [2:01:15]

§

## People Mentioned

- [Geoffrey Hartzler](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.112.113274) (invented infarct angioplasty) [7:00]
- [Ethan Weiss](https://www.ucsfhealth.org/providers/dr-ethan-weiss#:~:text=Ethan%20Weiss%20is%20a%20cardiologist,heart%20disease%20in%20the%20young.&text=Weiss%20earned%20his%20medical%20degree%20at%20Johns%20Hopkins%20School%20of%20Medicine.) [12:15]
- [Peter Schnohr](https://www.researchgate.net/profile/Peter_Schnohr) [44:15, 52:30]
- [Ralph Paffenbarger](https://en.wikipedia.org/wiki/Ralph_Paffenbarger) [44:15]
- [Ken Cooper](https://en.wikipedia.org/wiki/Kenneth_H._Cooper) (a pioneer of aerobic exercise) [44:15]
- [Hippocrates](https://en.wikipedia.org/wiki/Hippocrates) [44:15]
- [Micah True](https://en.wikipedia.org/wiki/Micah_True) [49:30]
- [Jacob Marott](https://www.researchgate.net/profile/Jacob_Marott) [53:00]
- [Julianne Holt-Lunstad](https://julianneholtlunstad.byu.edu/julianne-holt-lunstad) [56:00]
- [Iñigo San Millán](https://profiles.ucdenver.edu/display/226550) [1:02:15]
- [Emilio Ros](https://www.researchgate.net/profile/Emilio_Ros) [1:12:45]
- [Robert Vogel](https://www.ajconline.org/article/S0002-9149(04)00046-3/pdf) [1:15:15]
- [Joan O’Keefe](https://twitter.com/joanokeeferd?lang=en) (James’ wife, dietitian) [1:18:45, 1:59:15]
- [Jason Fung](https://twitter.com/drjasonfung) [1:31:30]
- [Tom Dayspring](https://twitter.com/Drlipid) [1:41:30]
- [Allan Sniderman](https://www.cardiomuhc.ca/allan-sniderman) [1:46:30]
- [Bob Peters](https://www.mrict.com/staff.asp) [1:49:00]
- [Steve Wolff](https://www.linkedin.com/in/stevendwolff/) [1:49:00]
- [Carl (“Chip”) Lavie](https://en.wikipedia.org/wiki/Carl_Lavie) [1:55:30]
- [Richard Isaacson](https://weillcornell.org/risaacson) [2:01:15]
- [Gary Small](https://www.bri.ucla.edu/people/gary-w-small-md) [2:02:00]

§

![](https://peterattiamd.com/wp-content/uploads/2020/10/1x1-okeefe-500x500.jpg)

##### James O'Keefe, M.D.

James is a cardiologist and Medical Director of the Charles and Barbara Dubok Cardio Health & Wellness Center at Saint Luke’s Mid American Heart Institute, an enormous practice of more than 60 cardiologists. He is also a Professor of Medicine at the University of Missouri, Kansas City. James has authored best-selling cardiovascular books for health professionals, including the Complete Guide to EKGs, Dyslipidemia Essentials, and Diabetes Essentials. James has also coauthored with his wife, Joan, the best-selling consumer health book, [The Forever Young Diet and Lifestyle](https://www.amazon.com/Forever-Young-Diet-Lifestyle/dp/0740754882). He is actively involved in patient care and research and has published numerous peer-reviewed articles.