# #323 – CRISPR and the future of gene editing: scientific advances, genetic therapies, disease treatment potential, and ethical considerations | Feng Zhang, Ph.D.

**Source:** [https://peterattiamd.com/fengzhang/](https://peterattiamd.com/fengzhang/)

---

Feng Zhang, a professor of neuroscience at MIT and a pioneering figure in gene editing, joins Peter to discuss his groundbreaking work in CRISPR technology, as well as his early contributions to optogenetics. In this episode, they explore the origins of CRISPR and the revolutionary advancements that have transformed the field of gene editing. Feng delves into the practical applications of CRISPR for treating genetic diseases, the importance of delivery methods, and the current successes and challenges in targeting cells specific tissues such as those in the liver and eye. He also covers the ethical implications of gene editing, including the debate around germline modification, as well as reflections on Feng’s personal journey, the impact of mentorship, and the future potential of genetic medicine.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/fengzhang/the_Drive_public.png)

Play

#323 - CRISPR and the future of gene editing: scientific advances, genetic therapies, disease treatment potential, and ethical considerations | Feng Zhang, Ph.D.

#323 - CRISPR and the future of gene editing: scientific advances, genetic therapies, disease treatment potential, and ethical considerations | Feng Zhang, Ph.D.

1x15s30s

0:002:05:40

## We discuss:

- Feng’s background, experience in developing optogenetics, and his shift toward improving gene-editing technologies [2:45];
- The discovery of CRISPR in bacterial DNA, and the realization that these sequences could be harnessed for gene editing [10:45];
- How the CRISPR system fights off viral infections, and the role of the Cas9 enzyme and PAM sequence [21:00];
- The limitations of earlier gene-editing technologies prior to CRISPR [28:15];
- How CRISPR revolutionized the field of gene editing, potential applications, and ongoing challenges [36:45];
- CRISPR’s potential in treating genetic diseases and the challenges of effective delivery [48:00];
- How CRISPR is used to treat sickle cell anemia [53:15];
- Gene editing with base editing, the role of AI in protein engineering, and challenges of delivery to the right cells [1:00:15];
- How CRISPR is advancing scientific research by fast tracking the development of transgenic mice [1:06:45];
- Advantages of Cas13’s ability to direct CRISPR to cleave RNA, and the advances and remaining challenges of delivery [1:11:00];
- CRISPR-Cas9: therapeutic applications in the liver and the eye [1:19:45];
- The ethical implications of gene editing, the debate around germline modification, regulation, and more [1:30:45];
- Genetic engineering to enhance human traits: challenges, trade-offs, and ethical concerns [1:40:45];
- Feng’s early life, the influence of the American education system, and the critical role teachers played in shaping his desire to explore gene editing technology [1:46:00];
- Feng’s optimism about the trajectory of science [1:58:15]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Feng Zhang is a professor of neuroscience at MIT as well as an investigator at the Howard Hughes Medical Institute and a core member of the Broad Institute of MIT and Harvard
- He earned his Bachelor’s degree in Chemistry and Physics from Harvard University
- He went on to earn his Ph.D. in Chemical and Biological Engineering at Stanford University where he worked with [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) in developing the technique of [optogenetics](https://en.wikipedia.org/wiki/Optogenetics)
- From there, he returned to Harvard as a research fellow before starting his own research lab and professorship at MIT in 2011
- Where he subsequently contributed mightly to the development of the CRISPR-Cas9 system for gene editing
- Feng has earned numerous honors and accolades for his work, including being selected for membership in the National Academy of Sciences, the National Academy of Medicine, and the American Academy of Arts and Sciences
- He is also a fellow of the National Academy of Inventors
- In this episode we explore the origins of CRISPR and discuss Feng’s early work in optogenetics at Stanford
- We discuss the foundations of gene editing, the challenges and breakthroughs in the field, and how CRISPR revolutionized the process
- We talk about the practical implications of CRISPR
  - The potential to treat genetic diseases
  - The importance of delivery methods
  - Current success and limitations in targeting cells, like those in the liver and the eye
- We discuss the ethical considerations of gene editing
  - Touching on the debate surrounding germline modification
- We reflect on Feng’s personal journey
  - The significance of mentorship and education
  - Where he sees potential for the future of science and genetic medicine

## Feng’s background, experience in developing optogenetics, and his shift toward improving gene-editing technologies [2:45]

- There isn’t anybody who hasn’t heard the term CRISPR, but very few people can explain it and what a powerful tool it is
- Feng earned his Ph.D. at Stanford in the lab of [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth); he was there for 5 years
- Peter and Karl were classmates at Stanford
- Karl has been on the podcast [[episode #191](https://peterattiamd.com/karldeisseroth/)]

**A quick summary of the work Feng did with Karl Deisseroth on optogenetics**

- When Feng worked with Karl, they developed a technology called [optogenetics](https://en.wikipedia.org/wiki/Optogenetics)
- It’s a way of studying brain cells in the brain, how they are connected together and how they mediate memory, mediate different types of physiological function
- The way it works is that we took a gene from a green algae, and this is a gene that senses light and converts it into electrical current in a cell
- We can put this gene from the green algae right into the brain cells in a mouse, and we can shine blue light or a yellow light and control the brain activity in these mice
- For example, if you wanted to study sleep, you can put this gene into different groups of cells in the brain and stimulate them
  - You can find out which ones of these are controlling wakefulness or which one are causing the mouse to become more sleepy
  - If you do this systematically, one by one, from one type of cell to another type of cell, you can gradually start to put together a picture of how the brain is wired together, and then also what are the different components that govern all sorts of behaviors from sleep and wakefulness to thirst and hunger to memory, and even to motivation and happiness
- Feng adds, “*It was really fun to be at Stanford and working with Karl.*”

**For Peter, the thing that always stood out about the technique was the resolution**

- Analogy: If you think about a book, it provides a resolution at the level of the word rather than the page

**Feng explains what is incredible about these algal proteins: they are very, very fast**

- You can show the way the brain cells are able to signal to each other at the action potential level
- [Action potentials](https://en.wikipedia.org/wiki/Action_potential) are these individual signals that are basically like the phonemes of the speech that one neuron speaks with another neuron, and you can control it at every single phoneme level

**What was the technique that you used to insert those algal genes into brains?**

- The way that you would put a gene into the brain is usually by using a virus
- This is a virus that exists in nature, but we have engineered it by removing everything that is pathogenic by the virus and then replacing those pathogenic genes with the gene that we’re trying to put into the brain
- In this case, it’s the gene from the green algae
- By injecting the virus into a brain area that you want to study, the virus will infect all the cells in that region and then make those cells begin to produce this algal protein
- Once the neuron starts to carry this algal protein, it becomes light sensitive, so you can turn blue light on it and then be able to stimulate it

**Feng finished his Ph.D. in 2009 and then went to Harvard for about a year, followed by MIT and the Broad**

- As he was working on optogenetics (especially towards the end of graduate school), he began to realize that one of the biggest bottlenecks facing optogenetics is our ability to insert the algal gene into specific places in the genome
- The reason for that is because in order for us to study different types of brain cells, we need to have very precise targeting of **different types of brain cells**
  - Brain cells are not just one type
  - Neurons is not a single type
  - There are probably hundreds of different types of brain cells
  - The way that they’re defined is based on their molecular property
  - Each brain cell, even though they all share the same genome, they have different sets of genes that are turned on
    - That’s why brain cells that control pain sensation versus brain cells that are involved in Parkinson’s disease are different
- The way that you would target one or another type of brain cell is by figuring out what are the molecular signatures of that cell?
- If you know that gene A is turned on in that brain cell and not in another type of brain cell, then you can insert this algal gene into the region that’s controlling gene A
  - That way, it will only get turned on in the first type of neuron

***The way to insert this gene into that precise place in the genome require gene editing, and it was really hard to do at the time***

> “*I thought maybe if I wanted to get optogenetics to become even more powerful and useful, we need to make gene editing more easy to use.*”‒ Feng Zhang

- By the time he went to Harvard, he began to focus more on trying to figure out: how do you more easily be able to modify the genome?

Peter asks, “*Why was it easy to do what you did in Karl’s lab (relatively speaking), where you’re putting an entire gene into presumably an adenovirus and letting the adenovirus infect the neurons and stick a whole gene in? Why is that a different problem than the one you just described that you started to solve at Harvard?*”

- The work he did as a graduate student with Karl was simply trying to insert a gene into brain cells ‒ we can get it into the rough area of the brain, but there are many different types of cells there
- We weren’t as precise in our ability to target those cells
- We also developed some tricks to be able to get it into a specific type of cell, but that was only limited to mice because we can genetically modify mice, and it’ll take a long time
  - It will take a year or two years to be able to make those mice available to engineer them, but it wasn’t generally applicable
    - Especially if you think about how to turn optogenetics into a therapeutic to use in humans

***We certainly couldn’t go in and use those transgenic technologies to make it work in the human brain ‒ this was a major problem***

## The discovery of CRISPR in bacterial DNA, and the realization that these sequences could be harnessed for gene editing [10:45]

**The origins of gene editing in the ‘80s**

- Gene editing stems from an observation that grew out of a discovery in sequences that existed in bacterial DNA, a certain type of repeating structure
- Feng was born in the ‘80s and back in the ‘80s, there was a group of Japanese researchers who were looking at DNA sequences of bacteria (at [*E. coli*](https://en.wikipedia.org/wiki/Escherichia_coli))
- What they found is that within some of the genomes (the DNA sequences of these bacteria) there are these regions that are very repetitive
  - They just repeat over and over and over again
  - Normally, genome sequences are not repetitive because they encode genes and different genes
  - Here, they found that there are these repeat sequences that are all grouped together (they’re clustered) and they are not tandem repeat (so it’s not repeat one next to each other), but they’re interspaced by a short fixed length gap
    - It’s basically A-B, A-C, A-D, A-E, A-G
    - It just continues to repeat itself, but in this regularly space pattern
- When they first found it, they had no idea what the sequence was all about
- These repeating sequences were also [palindromes](https://en.wikipedia.org/wiki/Palindrome#Biological_structures)
  - DNA is double-stranded; there’s a top strand and there’s a bottom strand
    - This is why they look like a double helix, so they twist and turn
  - What is interesting is that when you read these repeat sequences from the top and you read in the reverse way on the bottom, they’re almost the same (they are palindromes)

*CRISPR is really a brilliant acronym*

- C-R-I-S-P-R stands for exactly how these repeats look: **c**lustered **r**egularly, **i**nterspaced, **s**hort **p**alindromic **r**epeat
- It’s really brilliant and it’s very catchy, but this name wasn’t the name that was given to these repeats back in the ’80s
- That name didn’t come along until the early 2000s; [Francisco Mojica](https://imem.ua.es/en/about-us/francisco-juan-martinez-mojica.html) came up with the name

**How did scientists figure out what these repetitive sequences were?**

- Francisco Mojica was the first to observe that what’s interesting is not the repeating segments, it’s the sequences in between them
- CRISPR repeats have this conserved A sequence that is repeated many, many times
  - It’s the most obvious thing ‒  20-30 repeats of the same sequence
- Turns out, that’s not the interesting part
- The interesting part is actually the non-repeating sequences that’s interspaced between pairs of these three repeats
- Francisco Mojica is a spanish researcher that was looking at bacteria and looking at these weird sequences for a long time
- What he did back in the early 2000s is that he took these 9 repeat sequences and he just searched against viruses in the bacterial world
- For a few of them, he found matched virus sequences

***That was really a breakthrough because it started to highlight that maybe these 9 repeating sequences are foreign to the bacteria***

- These sequences came from somewhere else, and somehow bacteria acquired them into this repeat pattern
- That really started to launch the CRISPR revolution, because that observation and that inference allowed people to start to realize that maybe this has something to do with how bacteria and the viruses are interacting with each other
- When he tried to publish that finding, it was rejected by virtually every significant journal out there
  - The irony of science sometimes
  - It was ultimately published

**Just like us, bacteria are encountering viruses all the time**

- When a virus infects a bacteria, it’s just using its genetic machinery to replicate and it’s going to kill the bacteria
- The bacteria needs a tool to fight back
- We do it through the creation of [antibodies](https://en.wikipedia.org/wiki/Antibody)

**What did Francisco realize was happening with this artifact of viral DNA left behind in the genome of the bacteria (in these repeats)?**

- In the early days of CRISPR research, there were actually several different converging lines of work
- There’s Francisco Mojica who’s looking at these repeat sequences within the bacterial genome, but then there were also other researchers who began to zero in on a group of genes
  - These are things that are allowing the bacteria to make certain types of protein

*There are these certain genes that are right next to the repeats, and it took a while for people to begin to associate the genes and the repeat to be together as one single system*

- The people who are studying the genes realized that these genes were carrying [nucleases](https://en.wikipedia.org/wiki/Nuclease)
  - Nucleases are proteins that usually go and cut up either DNA or RNA
- They initially thought that maybe these genes were involved in DNA repair
- For example, [Eugene Koonin](https://irp.nih.gov/pi/eugene-koonin), who is a really brilliant bioinformatician, he’s been studying these genes, and he really started to zero in on what biologically these genes may be doing
- The linkage with these repeats took a little while longer to get associated
- It was really when the discovery that there are these viral sequences in the repeats, and that there are these genes that are associated with the repeat that are involved in DNA cleavage that started to really put together a framework for thinking that maybe this is a system where these viral sequences are working together with the DNA cleaving proteins to go in and recognize viral sequences and try to cleave viral sequences

**To put some names on things**

- Genes were near, but at a distance from both the palindromic repeats and the interspaced segments (that we now realize were copies of viral DNA)
- These genes coded for proteins or enzymes called [nucleases](https://en.wikipedia.org/wiki/Nuclease) (which cut DNA) and [helicases](https://en.wikipedia.org/wiki/Helicase) (enzymes that can unwind the DNA so nucleases can go in and cut)
- These were referred to as [CRISPR-associated proteins](https://en.wikipedia.org/wiki/CRISPR#CRISPR-associated_systems), which was abbreviated Cas proteins
- [Genes encoding cas proteins](https://en.wikipedia.org/wiki/CRISPR#Cas_genes_and_CRISPR_subtypes) are right next to the CRISPR repeats
- Although they underwent many different renaming over the course of two decades, eventually the community of researchers were studying **CRISPR proteins** and **CRISPR RNA**
- They came together and started to really curate these different genes (*Cas1, Cas2, Cas3,* etc.), and these things are numbered based in part on the order that they were discovered

**The most popular protein or the most widely used protein now is called Cas9**

- This is one of the Cas proteins that are found among an array of many, many different CRISPR proteins. Yeah

**These Cas proteins work with the CRISPR RNA**

- The CRISPR RNA refers to these repeats, which are encoded in DNA, but they are made by bacteria into RNA
- Those RNA are called CRISPR RNA
  - They don’t encode protein
  - ***They simply are a short guide sequence that directs the Cas protein to find the target virus sequence***

> “*Cas protein, CRISPR RNA, they together form a complex that go and provide a defense function for the bacteria.*”‒ Feng Zhang

- Whereas our defense against a virus is going to be making an antibody and/or activating another type of immune cell with an antigen receptor on it (called the T cell), the defense of the bacteria is simply to cut the genetic material of the virus to kill the virus

## How the CRISPR system fights off viral infections, and the role of the Cas9 enzyme and PAM sequence [21:00]

**Let’s walk through 2 scenarios: first infection, then reinfection**

1 – *E. coli* encounters a [bacteriophage](https://en.wikipedia.org/wiki/Bacteriophage) that it’s never seen before

- The bacteriophage injects its DNA into *E. coli*
- CRISPR is an adaptive immune system
  - It means this system can evolve with the bacteria to be able to accommodate many, many virus infections
- When the virus (which is called the bacteriophage) first infects the bacteria, it will inject its genetic information into the bacteria
- The virus is usually very powerful and very potent
  - It’ll probably wipe out most of the bacterial population

***In a very small number of bacteria (maybe 1 out of a million), the CRISPR system will successfully recognize a piece of the DNA of that virus and begin to insert it into this repeat area in the CRISPR system***

Peter asks, “*How long a piece is that typically? How many nucleotides in that piece?*”

- It’s usually 30 letters long, and that is enough for the bacteria to uniquely recognize the virus
- During the first infection, most bacteria die, but a very, very small number of them begin to acquire a snippet of the genetic information of this virus, and they insert it into the CRISPR system

***Those bacteria that survived have now acquired immunity against these viruses***

**In the process of surviving, what do they have to rapidly do to fend off that first viral infection?**

- The bacteria has many different defense systems in addition to CRISPR
- In fact, CRISPR is not the first line of defense
- There are other things that are also very powerful technologies now that are called [restriction endonucleases](https://en.wikipedia.org/wiki/Restriction_enzyme): these are proteins or enzymes that bacteria use
  - They don’t adapt, so they don’t evolve, but they recognize fixed letter sequences
  - Sometimes these will always get activated first and try to fend off the virus
- If it doesn’t, then there are a host of other defense systems, and one of these will eventually work
- Unfortunately, for the bacterial population, these things don’t come in quick enough, and that’s why most of the cells die
- The few where these things were able to keep up with the virus, that’s what allows the CRISPR systems to begin to acquire the genetic information

**2 – subsequent infection**

- Through a very Darwinian mechanism, a subset of the *E. coli* (in this case) that are able to not just survive with their first and second line defense against the bacteriophage, but now they’ve also developed the memory, so to speak
- Now, it’s a month later, and the same phage comes along, infects you, inserts its genetic material, but now you actually have interspersed between your CRISPR repeats 30 nucleotides that match a sequence within that virus

*How does the CRISPR system spring into action to resist this infection?*

- After the first infection, in a way, the bacteria has been vaccinated against this virus
- The second time when this virus comes around, it’ll inject its genetic information into the bacteria, but now the bacteria in the CRISPR repeat area has a signature of this virus
- The repeat area will get turned on and it will **start to make CRISPR [guide] RNA** that carry a 30 base pair long (or 20 base pair long) guide that’s able to recognize the incoming virus
- Feng explains, “*The Cas protein will bind to these CRISPR RNA, and they will go and try to search along all the DNA sequences in the bacteria. When it finds a match in the virus’s DNA, it will activate the nuclease and it will cut the DNA*.” [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/10/f1-fengzhang.png)

**Figure 1. CRISPR-Cas9 consists of 3 components: (1) CRISPR-RNA (crRNA) recognizes a matching region in foreign DNA and forms a guide RNA (gRNA, in the lower panel) to allow (2) Cas9 enzyme to locate foreign DNA and cleave the two DNA strands. Cleavage will only occur if the (3) PAM sequence immediately follows the targeted DNA strand. The tracrRNA holds the gRNA in place in the Cas9 enzyme**. Image credit: [Max-Planck-Gesellschaft](https://www.mpg.de/11824433/crispr-cas9-functioning)

Peter asks, “*Approximately, how many base pairs are in the viral DNA?*”

- It depends on the virus
- They can be small, maybe 10,000 letters or they can be long, 100,000 or even longer
- To put this in context, the human genome has 3 billion
  - We’re still talking about tiny amount of DNA

*Does the process differ if it’s an RNA virus versus a DNA virus?*

- It’s very similar

**Peter’s recap**: during reinfection, the bacteria make quick work of inactivating the virus

- Once the bacteria is able to make the Cas protein, which it can make really quickly in between the CRISPR segment, it makes the RNA segment to guide it and match it to the virus
- Really, that’s a CRISPR RNA, plus a truncated other version of an RNA that holds the RNA in the Cas protein
  - We call that whole thing the **guide RNA**

**How quickly can that Cas9 enzyme holding the guide RNA go through the entire sequence of viral DNA until it finds its place to land and cleave?**

- That process is probably pretty fast (Feng doesn’t know exactly how quick it is)
- It’s important to recognize that in a single bacteria, there are many, many copies of the Cas9 along with the guide RNA

***That means once the virus comes in, there are many, many copies of Cas9 that are simultaneously in parallel searching against the virus DNA to see whether or not there’s a match***

- This is why the system is so powerful because it’s able to, very quickly in a parallel fashion, find the match and then inactivate the virus within minutes

**The PAM sequence**

- There’s something else that is pretty unique about where those cuts take place
- When we bring in the viral memory, it always begins with three particular nucleotides

*What’s the significance of that?*

- P-A-M or **p**rotospacer **a**djacent **m**otif (it’s just a jargon)
- What is significant about that is that it is a sequence that is only found in the bacterial virus’s genome, but not in the bacteria’s genome
- When the bacteria acquires a piece of the virus’ sequence and sticks it into its own genome, one question is, “*Couldn’t the CRISPR system go and recognize the bacteria’s genome?*”
  - Couldn’t you turn the weapon on yourself and cut your own DNA and kill yourself?

*How does the bacteria avoid this self targeting or autoimmunity against itself?*

- This is where the PAM sequence comes in
- The PAM sequence is in the viral genome, is right next to the sequence that is acquired into the CRISPR system, but it itself is not acquired into the bacterial genome

***What you see in the bacterial genome’s CRISPR repeat is just the recognition sequence, but no PAM; Cas9 requires the PAM to activate recognition cleavage***

- Without a PAM, it doesn’t cleave itself, but it’s still able to target the virus

## The limitations of earlier gene-editing technologies prior to CRISPR [28:15]

- This brings us up to speed with the state of the art when Feng turned his attention to, “*How can I create a finer resolution for gene editing for my optogenetics problem?*”
- He started to work at MIT in the Broad Institute in 2011
- When he first started, he went to a scientific presentation and they were talking about CRISPR, and they mentioned that CRISPR are nucleuses
- Because he was thinking about nucleuses and gene editing at the time, when he heard that word, it got him interested
- He went on to Wikipedia and looked at what CRISPR is, and [Francis Mojica](https://imem.ua.es/en/about-us/francisco-juan-martinez-mojica.html) and [Sylvain Moineau](https://www.moineau.bcm.ulaval.ca/index.php?id=2) and [Rodolphe Barrangou](https://cals.ncsu.edu/food-bioprocessing-and-nutrition-sciences/people/rbarran/)
  - They had just published the very early studies on the [Cas9 system](https://en.wikipedia.org/wiki/CRISPR#Cas9) (called Cas5 at the time)
- He read all the papers on this (there weren’t too many) and pieced together the information to get a sense that ***CRISPR was an RNA-guided DNA targeting cleaving enzyme***

**At the time, there were other gene editing systems that were being worked on by researchers in the field, something called zinc finger nuclease or TALEN**

- These are systems that use proteins to recognize DNA, but not using RNA to recognize DNA
- These were state of the art up until 15 years ago

*How do these work? Why were you looking for something beyond the two techniques that already existed?*

- When Feng first became interested in gene editing in the late 2000s, there were people already developing gene editing technologies
- There’s something called [meganuclease](https://en.wikipedia.org/wiki/Meganuclease), which was very, very early
- What got Feng excited was a *New York Times* [article](https://www.nytimes.com/2009/12/29/health/research/29zinc.html) in 2009 that talked about a system called zinc finger nuclease
- There’s a company in California that’s called [Sangamo Biosciences](https://www.sangamo.com/), and they were already developing [zinc finger nucleases](https://en.wikipedia.org/wiki/Zinc-finger_nuclease) for gene therapy to be able to go and edit DNA and treat disease

**Zinc finger was a really challenging system for scientists to adapt and use because it required very sophisticated protein engineering**

- The way it works is that zinc fingers are protein domains
  - They’re just one glob of protein
- Each zinc finger can recognize three letters of DNA, and they occur in nature
  - You can find them in naturally occurring DNA binding proteins called transcriptional factors
  - They allow transcriptional factors to go and recognize different genes in the genome to modulate their activity
    - Either turn them on or turn them off, or change how much they are expressed in the cell

*How do you get specificity when you are only recognizing 3 nucleotides?*

- Nature has solved this problem by forming zinc finger arrays
  - They tether multiple fingers together to hit their target of 3 nucleotides + 3 nucleotides, etc.
- If you have an array of 3 fingers, they recognizes 9 letters
- If you have an array of 6 fingers, then that’s 18 letters
- In a complicated genome like ours with three billion letters, 18 would give us uniqueness
  - So 18 can allow you to find or define just a single position
  - That’s because 4 to the power of 18 is bigger than 3 billion
- The challenge with zinc finger is that you have engineered the fingers to recognize different combinations, three letters

***You have to make sure that when you tether them together to make a zinc finger array, they can recognize what you intend to recognize in that multiple 3 fashion; that turned out to be really cumbersome, and usually it doesn’t work very well***

**What are TALENs and why was that not necessarily going to serve your purpose?**

- T-A-L-E-N stands for **t**ranscription **a**ctivator-**l**ike **e**ffector (TALE) **n**uclease ([TALEN](https://en.wikipedia.org/wiki/Transcription_activator-like_effector_nuclease))
- These systems also came from bacteria, from a specific pathogenic bacteria called [*Xanthomonas*](https://en.wikipedia.org/wiki/Xanthomonas) [*oryzae*](https://en.wikipedia.org/wiki/Xanthomonas_oryzae) (it is a rice pathogen)
- What is really cool about TALENs or TALEs, is that they recognize DNA in a very programmable fashion
- These proteins have repeat domains, chastising fingers, that form an array, but individual domains recognize single DNA letters
- And so, you can find these TALE proteins in the bacteria that have 12, or 16, or even 20 different repeats
- They can recognize long stretches of 12, or 16, or 18, or 20 DNA letters in the plant genome
- Plant genomes are also large; they are sometimes 2-3X the size of our genome
- So recognizing long sequences is important for achieving precision, and that was the TALE system

*Ulla Bonas (a researcher in Germany) and also* [*Adam Bogdanove*](https://cals.cornell.edu/adam-j-bogdanove) *(a researcher at Iowa State) both discovered at the same time a specific code for how these TALE proteins recognize DNA*

- It turns out that within each one of these repeats, there are 2 amino acid letters that correspond with a specific DNA letter that it binds to

***And so, if you take any TALE protein and you just dial in different combinations of these 2 amino acids in each one of the domains, you can specify what DNA sequence this TALE protein is able to recognize***

- This turned out to be much more easy to use than zinc fingers
  - Zinc fingers were really hard to use; it was almost impossible for a single researcher to get something what would recognize the DNA sequence that you are trying to get it to recognize

***TALENs were much easier to use, but the repetitive nature of these proteins made it quite cumbersome to engineer new proteins to recognize the sequence you’re trying to edit***

- For example, if you wanted to be able to modify a specific gene, it could take you maybe several weeks, or even a couple months, to be able to successfully make one of these TALE proteins
- And when you do that, usually it works but not always, and sometimes it’s not very effective

*From a technical perspective, these TALE sequences are just very hard to work with*

- Because they’re very similar to each other, they’re prone to recombination
- In order to get a TALE to work, you have to, in a very precise way, put every domain in the correct order
  - Because you’re trying to recognize AGTC, you have to put it together in AGTC
  - You can’t have ACGT. It just wouldn’t work
- So to put repetitive sequences together and light them up in exactly the order you want, that is really challenging to do

## How CRISPR revolutionized the field of gene editing, potential applications, and ongoing challenges [36:45]

**The promise of gene therapy**

- The human genome was sequenced nearly 25 years ago, and the promise of gene therapy was hailed as right around the corner
- Yet more than a decade after the sequencing of the human genome, it doesn’t appear that gene therapy through gene editing is any closer than it was a decade earlier (from a practical standpoint)

*That’s a bit of a disconnect for people*

- Most people who aren’t in a lab would be surprised to understand that simply knowing what the sequence of genes are doesn’t tell us what the genes do
- We still have no idea what most of these genes do anyway
- We have no idea why there are coding segments, and the majority of the DNA is non-coding segments
- And yet, some of these non-coding segments are where mutations exist, that results in disease

*The jugular question*

- If a person has a disease like [cystic fibrosis](https://en.wikipedia.org/wiki/Cystic_fibrosis) or [sickle cell anemia](https://en.wikipedia.org/wiki/Sickle_cell_disease), where we really know the cause in unambiguous terms
  - Where on the DNA, where in the gene, the problem lies
  - We know what the substitution is
    - We know which C was turned into a G or a T, and all we need to be able to do is go in there and fix it
- That fix was something we couldn’t do 10 years ago
- For many people, that’s quite surprising
- That’s not the problem Feng was trying to solve, but it’s the world he’s created

**Talk about those steps down that road. What is the next thing in terms of CRISPR?**

- The Human Genome Project was completed in early 2000s, and with the human genome having been sequenced, and then also with DNA sequencing technology becoming cheaper and faster, scientists were able to start to sequence many, many more genome
- And so they can start to make comparisons between healthy individuals, and also people who are affected by specific diseases, to see what’s different between their genomes
- By doing that comparison, they can identify the differences that may be causal for disease

***To date, based on genetic analysis, researchers have probably identified more than 5,000 genetic mutations that have a direct causative role in disease, and these are called genetic diseases***

**Genetic [monogenic] disease**

- They usually affect a small population of individuals
  - They’re not as common as things like cancer or diabetes, or what people call complex or complicated diseases
- Nevertheless, these are the ones where we know the exact genetic cause
- The tantalizing idea is then, if you know the mutation in the genome, why not just go and fix it?
- That’s where gene genetic editing comes in
- And people have, since the very beginning, trying to realize this idea
  - They were trying to work on it using meganucleases
  - They were trying to solve this using zinc finger nucleases
  - They were certainly trying to use the TALENs to also treat diseases this way
- The challenge is that they weren’t very efficient, and it was also difficult to apply them to be able to treat the disease with sufficient amount of efficacy

***When CRISPR came along, especially with Cas9, it was much easier to be able to design strategies to edit DNA, and that made it much more feasible for many groups to really start to work on this idea***

**Feng had just started his lab at MIT**

- He had maybe 10 Ph.D. students and a couple of postdocs
- When he first started his lab, he was already focused on the gene editing problem
- So when students came to him, even though they came to him wanting to work on optogenetics, he had to convince them that there’s this other problem that is also interesting, and maybe they could try to work together and make a difference there
- He started to try to tell them about CRISPR, tell them about gene editing and all the potential applications

**It’s the early 2010s. What are the next steps that you take to develop this technology?**

- At first he was working on TALENs, and then very quickly he learned about CRISPR and started to also get CRISPR projects going in the lab
- He was working on both systems for a while at the same time, and pretty quickly realized that TALENs were difficult to use because of the cumbersome nature of how to make them

***Then because of that, the promise of CRISPR was much more apparent***

**Analogy to understand the utility of CRISPR as compared to TALENs or zinc fingers**

- We now have a mobile phone, and on a phone, there are many different apps
- Apps that help you book trips, apps that helps you send messages to your friends and family, apps that allow you to take photos
- You have a phone and a phone can do everything; you just load the app onto it

***With TALENs or zinc fingers, the analogy would be, you have to build a different device for each one of these functions***

- Meaning, you would need a different phone for each app
  - Different hardware for every gene you’re trying to target
- That is a very cumbersome and not very effective process

***With CRISPR, the promise is that CRISPR is like the smartphone***

- You can load software onto it to recognize different genes, and the software is the CRISPR RNA
- These RNAs are very easy to chemically synthesize
- And you can define the gene by reading off of the sequence of the gene, which is already completed through the Human Genome Project
- So all of that was just a step function improved over the zinc finger and TALEN technology

> “*We realized that if we can make CRISPR work, not only in a bacteria, but put it into human cell and get it to recognize genes in the human cell, that then we can have a much more powerful and much more democratized gene editing system*.”‒ Feng Zhang

**What was the breakthrough that led to the utility of this?**

- CRISPR is a natural nucleus
- In bacteria, it uses the guide RNA to recognize the virus DNA, and then once it recognizes it, it will cleave the virus DNA
  - So make a double-stranded DNA break
- And so that’s what we’re trying to make happen in the human cell

***We try to program Cas9 with a guide RNA to go and recognize a specific gene in the human genome, and then be able to cut it***

Peter recognizes, “*Which is valuable. I mean, there are certain cases where overexpression of a gene is pathologic, and if we silence a gene, we fix a disease.*”

**There were a lot of studies done on how breaks in the DNA would get repaired**

- [Maria Jasin](https://www.mskcc.org/research/ski/labs/members/maria-jasin), [Jim Haber](https://www.brandeis.edu/biology/faculty/haber-james.html), they had studied, maybe a couple of decades before that, how DNA repairs will get processed
- What they found is that when you make a cut in the DNA, so when you make a break, it will activate repair processes in our cell
- In fact, our DNA gets DNA breaks all the time, and we’ll have a robust process to be able to fix them, to prevent mutations
- What Maria Jasin and Jim Haber found is that if you make a cut in the DNA, that cut will activate 1 of 2 different repair processes
- 1 – The first [repair process](https://en.wikipedia.org/wiki/Non-homologous_end_joining) will glue the DNA together, usually correctly, but in a very, very small number of instances, it will introduce a mistake, and that mistake will **inactivate the gene**
  - So it will no longer make the protein product that it’s supposed to make
  - And this is very useful if you wanted to inactivate something in the cell
  - Sometimes there are mutations that are deleterious, and if you can inactivate that deleterious mutation, then you can make the cell healthy again
- 2 – The second repair process is called [homology-directed repair (HDR)](https://en.wikipedia.org/wiki/Homology_directed_repair), and this relies on a template DNA that carries the sequence that you’re trying to repair with
  - And so, if you make a cut and you also provide a template DNA, then the repair process will copy whatever that’s on the template into the DNA break site
  - And this is a more powerful way to be able to **change the DNA sequence** in a design fashion

Peter asks, “*Is there a risk when you cut the DNA and it repairs? That it repairs in a manner that remains pathologic, even if it’s distinct from the path that was already there?*”

- It is possible, but the probability is much, much lower

**What about the holy grail, which is to literally edit a new gene? To put something in that didn’t exist. What was required to take that leap?**

- There are different ways that you may want to change the DNA sequence
  - 1 – You may want to inactivate something
  - 2 – You may want to delete something
  - 3 – You may want to insert something
- To do each one of these, you need to have a machinery that will allow you to do that

***The holy grail would be to be able to insert a gene into anywhere you want, precisely, and also very efficiently; and to date, that ability is still not quite there yet***

- We’re still working on that, and many other groups are working on developing technologies to make that happen with high enough efficiency
- We can do it now with very low level, maybe less than 1% [efficiency], or maybe just single digit percent
- But for a big gene that we’re trying to put in, we don’t have a good way to do that yet

**Currently, is it possible to snip DNA anywhere you want with the current technology?**

- Yeah
- With CRISPR, with Cas9, we can pretty much target throughout the genome and make cuts

## CRISPR’s potential in treating genetic diseases and the challenges of effective delivery [48:00]

- There are a lot of genetic diseases where there is a mutation that is pathogenic
- Peter adds, “*In this case, overexpression if you want to deactivate it, but some would be underexpressed.*”
- Feng explains, “*These are genes that are usually important for the body, but there’s a mutation in it, and that makes the resulting protein, the mutant protein, deleterious for the patient. So if you can inactivate these genes, then you can treat disease*.”
- For example, there are diseases of the liver where there are certain proteins that cause [amyloidosis](https://en.wikipedia.org/wiki/Amyloidosis#), and that can lead to serious problems
- By using CRISPR, you can go in and cleave these genes, inactivate them so that they no longer produce these toxic gene products
- [Huntington](https://en.wikipedia.org/wiki/Huntington%27s_disease) is another example, where there are mutations that are occurring in the gene that makes the gene deleterious
- And so, if you can go and try to inactivate these deleterious mutations, it may be possible to treat the disease

Peter asks, “*Is it generally the case that* [*autosomal dominant*](https://en.wikipedia.org/wiki/Dominance_(genetics)) *diseases are an overexpression problem, or an expression of something harmful problem? Whereas, recessive diseases are the opposite, where you tend to not be producing enough or something of that nature? Is that overly simplistic?*”

- Yeah, that’s a good explanation

*Huntington’s disease ‒ why it may or may not be amenable to this type of treatment*

- We clearly know the etiology of Huntington’s disease: it’s an autosomal dominant gene, a mutation in a gene called [*Huntingtin*](https://en.wikipedia.org/wiki/Huntingtin)
- Sadly, it doesn’t present until later in life
- Many times, individuals will pass this gene on prior to the symptoms being manifest, and therefore, they go on to suffer the fate of this disease, having already passed it on
- The *Huntingtin* gene is expressed in the brain, and in mutated form, this gene accrues an expansion of repeat sequences within the gene
- The longer the repeat is, the more deleterious it is for the patient
- And so, the idea would be to try to shorten these repeats; or maybe if you can reduce the amount of repeated sequence of the RNA that’s expressed, you could also get a cell to be healthier
- The challenges are, the repeats happen within the coding region of the gene
  - The region that is important for making the protein sequence
- So in order to make the resulting edit successful, you have to do it very precisely
  - You have to do the exactly 3 letters at a time from the repeat sequence, otherwise you would [shift the frame](https://en.wikipedia.org/wiki/Frameshift_mutation)
- The gene has 1000s of base pairs; it’s a huge gene
- And these repeats can be several hundred (or maybe 1000) repeats long

***One challenge is to be able to delete them very precisely***

*The other challenge is to be able to deliver the gene editing machineries into the brain, and get it into enough cells*

- There are some virus-based technologies that are coming along, but still, we don’t have probably the most suitable method yet

**Peter’s recap of what CRISPR is**

- You have a CRISPR vehicle, it would be a Cas9 protein
- And you also have a guide RNA that is made up of both the piece you actually want to put in wrapped around another sort of tracer piece that holds it firmly in the Cas9 protein
- The Cas9 protein acts as both a helicase [to separate the 2 strands of DNA] and a nuclease [to cut the DNA]
- It’a a “one man shop” that runs up the host DNA, opening it, and waiting to find its match
  - And it waits, and waits, and waits, and then it finds its match, holds the strands of DNA at the Cas9, and then, click [it cuts both strands of DNA]

**How do you deliver the Cas9 protein to an individual?**

- That is really the big challenge
- Right now, there are clinical applications of CRISPR for treating different diseases
  - Disease in the blood, like sickle cell disease
  - Or disease in the liver, disease in the eye, and many other places
- Depending on where you’re trying to deliver CRISPR into, there are different technologies that people use
- Maybe the simplest might be in the blood

## How CRISPR is used to treat sickle cell anemia [53:15]

**Tell people what sickle cell anemia is, and why it’s amenable to this type of therapy**

- [Sickle cell anemia](https://en.wikipedia.org/wiki/Sickle_cell_disease) is caused by a mutation that causes the red blood cell to sickle
  - They form a sickle form, and they’re not able to properly function
  - And sometimes they can aggregate, and then this can cause occlusion in the blood vessel, and can cause serious problems [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/10/f2-fengzhang.png)

**Figure 2. Overview of sickle cell disease**. Image credit: [Sangamo Therapeutics](https://www.sangamo.com/programs/clinical-trials/sickle-cell-disease/)

- These red blood cells are made by progenitor or stem cells in the body that produce red blood cells
- The disease is caused by a simple [point mutation](https://en.wikipedia.org/wiki/Sickle_cell_disease#Genetics%22The%20gene%20defect%20is%20a%20single%20nucleotide%20mutation%20(see%20single-nucleotide%20polymorphism%20%E2%80%93%20SNP)%20(GAG%20codon%20changing%20to%20GTG)%22:~:text=The%20gene%20defect%20is%20a%20single%20nucleotide%20mutation) that changes 1 amino acid (based on 1 base pair change)
  - That 1 amino acid change is what leads to all of this downstream badness
- It’s an awful disease,a dn thes patients experience unbearable pain

Some might ask, “*Why does this disease exist?*”

- It turns out that if you have one copy of the sickle gene and the other one is normal, you have normal looking red blood cells, you don’t get the disease, but you actually get [protection from malaria](https://en.wikipedia.org/wiki/Sickle_cell_trait#Malaria)
- So that would keep this propagating, particularly in a malaria rich area like Africa
- This is why it’s much more prevalent in a black population than a white population, because it offered some benefit

*But if you have two copies of the gene, you get the sickling*

- Those are not the people that are passing on their genes historically
- They would have perished before reproduction, and also just perished in a great deal of pain

*You have to be able to go into the bone marrow to make this change, because there’s no point in doing this if you have to do this every week. You want to do it one and done, right?*

- That’s right

> “*One of the promises of gene editing is that it can provide a single treatment that is a cure for the disease.*”‒ Feng Zhang

- In the case of sickle cell, what happens is that the doctor will mobilize the stem cells (the bone marrow cells from the patient), get them to come out, and be able to harvest these bone marrow cells
  - They don’t necessarily do this with a bone marrow aspirate
  - They do it by giving them medications that cause them to secrete more progenitor cells into the plasma

***The current practice in the medical field is they will get the patient, harvest their bone marrow cells, and these cells are going to be modified in the laboratory***

- Researchers will take the messenger RNA for Cas9
- This will allow the cell to produce the Cas9 protein, and they will also take guide RNA

Peter asks, “*Explain really quickly for people the relationship between DNA, messenger RNA, [and] protein. It’s the* [*central dogma*](https://en.wikipedia.org/wiki/Central_dogma_of_molecular_biology)*, but that way when you say what you’re about to say, they’ll know why it works.*”

- There are different ways to get a protein to the cell
- And the way that proteins are made in the cell is that they’re encoded in DNA, and the DNA has to be [transcribed](https://en.wikipedia.org/wiki/Transcription_(biology)) into [messenger RNA](https://en.wikipedia.org/wiki/Messenger_RNA)
- Then that RNA is then [translated](https://en.wikipedia.org/wiki/Translation_(biology)) by the ribosome into the protein

***And so, if you can put into a cell either the DNA (the gene for Cas9), or the messenger RNA for Cas9, or the protein for Cas9, the cell will eventually have Cas9***

- Because if you put in the DNA, the cell will start to make mRNA based on it, and the mRNA will get translated into the protein

**How do you put it in the DNA?**

- There are different ways
- You can use a virus
- Or if you’re working with cells in the Petri dish, you can directly [electroporate](https://en.wikipedia.org/wiki/Electroporation) the DNA into the cell
  - This is done by zapping the cell with the electrical current
  - It will rupture the membrane, and when the membrane ruptures, things can leak in
  - So if you have DNA that’s outside the cell, when the cell membrane ruptures, the DNA that’s outside the cell will flow into the inside of the cell and get into the cell
  - And this is actually how people treat sickle cell disease
- When treating people, they’re not putting DNA into the cell, they’re putting mRNA

***They incubate these bone marrow stem cells that have the sickle cell mutation in the bath of mRNA for Cas9, and the guide RNA separately***

- Once those cells acquire both the mRNA for Cas9, and the mRNA that is corresponding to the guide, it will translate into a Cas9 protein
- It doesn’t translate the guide RNA into protein; it just stays there and they find each other

> “*This is really the result of the biotechnology revolution, the molecular biology discoveries that have really paved the biotechnology revolution*.”‒ Feng Zhang

- This can be quite efficient: in the laboratory or in these Petri dish settings, this can be approaching 100%

**What’s the exact thing you’re asking Cas9 to do here?**

- For sickle cell, the treatment that has recently been approved in the last year is actually different [than addressing the single base pair change mentioned earlier]
- It has been found that for some individuals who have the sickle cell mutation, if they also carry another mutation that allows them to be able to express the [fetal version of hemoglobin](https://en.wikipedia.org/wiki/Fetal_hemoglobin), then their sickle cell symptoms are much, much less

***For treating sickle cell patients with gene editing, the therapy actually goes and modifies a different gene; it modulates this expression to then allow the fetal hemoglobin gene to turn on***

Peter asks, “*Why is that an easier solution than simply changing the one amino acid that’s broken in the first place?*”

- Because the way it works is that it simply makes a cut, and it doesn’t require a change in the DNA sequence
  - It doesn’t require a template at repair

**Peter’s takeaway:** ***We’re still at the point where in vitro we’re still better off with a cleavage (just a straight cut of the DNA) than even a single base pair switch to fix one amino acid. The latter is a harder problem.***

## Gene editing with base editing, the role of AI in protein engineering, and challenges of delivery to the right cells [1:00:15]

**There is also very good progress on that front (changing the DNA sequence)**

- Feng’s colleague [David Liu](https://www.liugroup.us/) developed a technology called [base editing](https://www.nature.com/articles/s41576-018-0059-1)
- Base editing allows you to use Cas9
  - You get rid of the DNA cleaving activity of Cas9
  - Instead, it simply goes and binds the DNA
  - So you use it as kind of a guidance system to direct a different enzyme, called the [deaminase](https://www.nature.com/articles/nature24644), to be able to go and chemically modify a single base
- It’s amazing to Peter that this is easier that what we wish we could do
  - Which is, take out the C and make it a G, and that will give me the amino acid I want
  - The fact that we’re chemically having to modify it with a deaminase

**What do you think is necessary to take this to the next step function for the science fiction to start?**

- This really goes back to the division of genetic medicine: genetic medicine is very powerful
- CRISPR is part of it, but it’s really a 2 component system
- 1 – There is the medicine itself
- 2 -There’s also the delivery technology

***You need to have the right vehicle for delivery and the right payload to be able to treat the disease in the right cell; and we’re more limited on the delivery than the payload***

*More on the delivery*

- The payload technology has come a long way
- We now have mRNA, we have Cas9, we have base editing, we have [prime editing](https://www.nature.com/articles/s41576-022-00541-1)
- We have a lot of different types of editing technology, and even [epigenetic editing](https://www.nature.com/articles/s41588-024-01706-w)
- But the bottleneck is: How do we put these really powerful payloads into the right cells, in the right tissue in the body?
- We have a lot of different things that can modulate and modify cells
  - We have Cas9
  - We have base editing, prime editing
  - We have different [recombinases](https://en.wikipedia.org/wiki/Recombinase)
  - We have epigenetic modifiers that also are based on Cas9
  - We have mRNA, [snRNA](https://en.wikipedia.org/wiki/Small_nuclear_RNA)

***Epigenetic modification using Cas9 is not a payload problem, it’s a delivery problem***

- It’s also a biological problem because many disease will not be amenable to this

**Can this be used to solve cancer?**

People will say, “*Peter, we’ve heard you say that cancer is a genetic disease. Does that mean that once we solve the delivery problem, we solve cancer? Why is that not necessarily true?*”

- That is because cancer is caused by many different risk mutations in the cell
- So it’s difficult to treat cancer by correcting the mutation because you really have to be able to correct at a very, very high efficiency
- If you have a few cancer cells that have not been corrected, those cells will continue to divide and replicate and form tumors and even metastasize

*That is really challenging, but people are using gene editing in the cancer therapeutic context*

- What they’re doing is that they are using gene editing to engineer immune cells so that the immune cells are more potent at recognizing and killing cancer cells
- And this is part of what’s called [immunotherapy](https://en.wikipedia.org/wiki/Immunotherapy)
  - [For a history of immunotherapy, see [episode #177](https://peterattiamd.com/stevenrosenberg/)]

**Does AI enable this any better on either side, on the payload side or on the delivery side?**

- AI is very powerful for **protein engineering**
- In the past few years, there’s been amazing breakthrough in the use of AI for predicting protein structures
- Each protein is made of a unique sequence of amino acids, and the unique sequence allows the protein to fold into a specific shape

*One of the holy grail problems for a long time has been how do you take just the letters of a protein and predict what the shape of the protein looks like?*

- This is something that many, many scientists have worked on for a long time, but haven’t been able to come up with a good solution
- It wasn’t until 2020-21, the use of AI by this group called [DeepMind](https://deepmind.google/technologies/alphafold/) that was able to come up with a solution called [AlphaFold2](https://alphafold.ebi.ac.uk/)
- AlphaFold2 is an AI based system that has learned from all of the structures of proteins that scientists have experimentally determined
- This created a huge database of them and they were able to use AI to look at all of them and learn from that large database to then come up with a prediction system called AlphaFold2

**To explain this, pick your favorite protein. How many amino acids are in the primary sequence?**

- We can pick the [green fluorescent protein](https://en.wikipedia.org/wiki/Green_fluorescent_protein) from jellyfish, maybe 300 amino acids [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/10/f3-fengzhang.png)

**Figure 3. Green fluorescent protein in jellyfish (A) and its protein structure (B)**. Image credit: [University of California](https://www.universityofcalifornia.edu/news/how-basic-research-jellyfish-led-unexpected-scientific-revolution) and [Wikipedia](https://en.wikipedia.org/wiki/Green_fluorescent_protein)

*Protein structure*

- It has a primary structure ‒ the actual amino acids
- It has a secondary structure ‒ when does it actually form a helix or a sheet
- It has a tertiary structure ‒ which is kid of like how it starts to bend
- It has a quaternary structure ‒ which is how the whole things fits together in complicated 3D folds

![](https://peterattiamd.com/wp-content/uploads/2024/10/f4-fengzhang-1024x691.png)

**Figure 4. Levels of protein structure**. Adapted from: [Wikipedia](https://en.wikipedia.org/wiki/Protein_structure)

***If a scientist wants to make a protein and they know what it needs to look like (the quaternary structure), it’s almost a trial and error problem to go from the primary sequence to that***

- For example, if they want to design a protein that fits in a receptor

Peter asks, “*You’re saying that AI is really good at doing this thing where it knows the relationship between primary sequence and final quaternary structure. Is that just literally linear regression at a level we’ve never understood because humans can’t do it? But is it basically just solving the world’s most complicated linear regression problem?*”

- At a fundamental level, that is what is happening
- The human brain can’t process so much data very effectively
- But with AI, you can have these massive neural networks that can really process this

## How CRISPR is advancing scientific research by fast tracking the development of transgenic mice [1:06:45]

- Feng touched briefly earlier on the idea of a [transgenic mouse](https://en.wikipedia.org/wiki/Genetically_modified_mouse)
- So many amazing breakthroughs in science have come through these, and frankly, just through genetic understanding of mice making changes to a mouse gene
- We recently had [Dena Dubal](https://neurograd.ucsf.edu/people/dena-dubal-md-phd) on the podcast [[episode #303](https://peterattiamd.com/denadubal/)], and we talked about klotho
  - To Peter, this is one of the most interesting proteins out there
  - We learned the story of how klotho came about silencing a gene, found this thing, over expressed the gene, found this thing

**How does CRISPR enable that today? Has it changed the ability of people working on other problems to get there quicker using laboratory animals?**

- The transgenic mouse technology really revolutionized biology
- When the transgenic mouse technology was developed, the way it worked is that you would start with stem cells for mice, you would modify these stem cells, and then you put the stem cells back into an embryo, and then you transplant the embryo into a mouse so that the embryo can develop into fetus and then be born as a new mouse
- And then once the mouse is born, usually that mouse does not have 100% of that genetic modification
  - The mouse is called a mosaic, and then you have to take that mouse and breed the mouse again with another mouse and hoping that the mosaic part gets transmitted

***That is a very long process ‒ it can take a year or longer to generate a specific transgenic mouse***

*Now with CRISPR technology*

- What people can do is they can directly inject the gene editing Cas9 and guide RNA into a single cell embryo and then modify there
- The mouse gestation period is 21 days

***Using CRISPR in this way, after 21 days you have a transgenic mouse***

**What has this done to the field of biomedical research?**

- It has accelerated biomedical research dramatically
- Imagine yourself as a graduate student, and usually a PhD will take 5 years
- If you have to wait 2 years to get a mouse so that you can begin your experiment, that is a long time
- Now with CRISPR (or gene editing) you can get a mouse in 2, 3 months

Peter asks, “*Let’s play devil’s advocate for a moment. When you did your PhD, you had to slog through the old-fashioned way. Were there hidden benefits of that? In other words, did it give you more time to read, more time to be curious, more time to fail?*”

- Feng is not too concerned about that
- If we can accelerate the accumulation knowledge, the acquisition data, that would really help science move a lot faster

> “*I think in the future, especially with higher throughput technologies, CRISPR, DNA sequencing, and many other things together, we’re going to be accumulating new data for biology at an exponential pace.*”‒ Feng Zhang

- In the future, we’re not only going to be relying on our own ability to analyze the data, but we’re going to have AI to help us
  - These large systems that can draw much, much larger regression analysis
- And with that, biology, discovery, and disease treatment development will really accelerate
- That’s a really exciting future

## Advantages of Cas13’s ability to direct CRISPR to cleave RNA, and the advances and remaining challenges of delivery [1:11:00]

**We’ve talked a lot about Cas9, but you’ve also specifically done quite a lot with another CRISPR-associated protein called Cas13. What’s the difference and how does this potentially impact future work?**

- CRISPR is a bacterial immune system, and there are many, many different types of CRISPR
- In nature, bacteria are invaded by DNA viruses ,by RNA viruses, all sorts of different viruses
- [Cas9](https://en.wikipedia.org/wiki/CRISPR#Cas9) protects bacteria against DNA viruses, but then there also needs to be a CRISPR system that protects against RNA viruses
- [Cas13](https://en.wikipedia.org/wiki/CRISPR#Cas13) is the RNA analog of Cas9
- Cas13 uses a guide RNA to recognize the RNA virus and then cleave the RNA genome

Feng explains, “*What is really interesting about Cas13 is that unlike Cas9, it not only cleaves the recognized RNA, but once it recognizes a piece of RNA, it also turns on almost a suicidal function. It goes and cleaves any other RNA that’s in the bacterial cell.*”

- In the infection cycle, you can think of this as an altruistic system where when the Cas13 recognizes my cell has been infected by RNA virus, I’m going to shut myself down, kill the cell and save the population

Peter asks, “*Why is that the case? Why does the cell not choose to do that with the DNA virus? Are RNA viruses necessarily more lethal to bacteria?*”

- RNA is usually more abundant
- Once the RNA gets produced, there are many copies, and so it’s difficult to shut down every single copy of RNA
- Whereas with DNA, there’s usually just one copy of DNA, so if you can shut it down
- For example, when a specific bacteriophage latches on to the outside of an *E. coli*, it’s going to shoot in a piece of DNA
  - We’ve already talked at length about how that works and the role Cas9 plays in that

Peter asks, “*When a different bacteriophage comes along, you’re saying it inserts a lot of RNA or just the RNA replicates much quicker?*”

- RNA replicates quicker
  - It’s one step less [as compared to a DNA virus]
  - It’s already made the machinery to go in from of the translating ribosome, because DNA has to go to RNA to make protein

**Cas13 also has a suicide feature that is quite useful for developing diagnostic technologies**

- Especially during COVID, we use Cas13 to develop a way to [detect Coronavirus RNA](https://pubmed.ncbi.nlm.nih.gov/32848209/), and it provided a way to have a simple and rapid detection method

*How would Coronavirus RNA have been detected before and how does that compare with using Cas13?*

- The most widespread method for diagnostics is using PCR
- It checks for the nucleic acid sequence
- But PCR is a laboratory-based test, and it requires a machine called a PCR machine, which is complicated to run
  - You have to be in a laboratory environment to go through the test

***What Cas13 provided is something that’s more similar to an antigen test where you can run it at a point of care or even potentially at home***

- The Cas13-based test simply required you to take a swab to have the sample, you mix the sample into a buffer, and then Cas13 would react in that buffer to be able to detect the virus sequence
- Then you load it onto a paper strip, it will run, and then you see whether or not a band shows up

**When we think about gene editing going forward, we’ve already established that the payload is not the problem, it’s the targeting and the delivery. What are the relative advantages and disadvantages of Cas9 versus Cas13? And are there other Cas or CRISPR-associated proteins out there that might even be better than both of them?**

- Cas9 and Cas13 both have therapeutic applications, but one of the challenges is that they are large proteins
  - Cas9 is 1,300 amino acids long, and Cas13 is usually around 1,000 amino acids long
- And so in order to get Cas9 into a cell, you have to be able to fit Cas9 and the guide RNA into your delivery system
- If you’re using viral vectors to deliver, they are usually very compact and you can barely fit Cas9 in
- It would be nice to have something smaller

***Feng and many other groups have worked on trying to discover new proteins that are more compact and more easily packagable***

- There are some out there, but usually they’re not as specific or not as active as Cas9
- There are trade-offs to using some of those systems and we’re working on engineering them, and there’s a lot of good progress turning those systems into a specific and comparably active systems as Cas9

**If you could wave a magic wand, how big a Cas protein would you tolerate such that your Cas protein plus your guide RNA would easily fit into your delivery vehicle?**

- If you could shrink it down to 1000 base pairs (300 amino acids), that would be ideal; but it’s challenging to do

**Peter’s recap**:

- At the end of the day, you need a protein that has the structural integrity to hold the guide RNA in place, make its way down into the nucleus, and open the DNA
- It’s basically 2 enzymes: a helicase and a nuclease
- It has to be able to march along the DNA, recognize while holding, and then cut and eventually insert
- If you think about it on the smallest level, it’s a mechanical problem
- At some point it’s just about the limits of physics ‒  you need a certain amount of amino acids to make that structure
- It sounds like that doesn’t exist in nature

***You’re not looking for a 300 amino acid Cas protein, you’re going to use AI to help to build one***

**There are natural forms of proteins that are small and are like Cas9**

- In one of Feng’s projects trying to look for a small Cas9, they thought, “*Let’s look at the evolutionary origin of where Cas9 came from.*”
- By tracing the evolutionary history of Cas9, they found that there is a very large family protein called [IscB](https://www.nature.com/articles/s41467-022-34378-3) that is the ancestral form of Cas9

*IscB is a very small protein that does exactly what Cas9 does*

- It’s only about 450 amino acids, so it’s about a third of the size of Cas9
- It’s got a helicase activity, it’s got nucleus domains, and it also works with the RNA guide to recognize and cleave DNA

***But what is different between IscB and Cas9 is that the guide RNA for IscB is much, much larger***

- RNA is not as stable, not as robust; it’s more prone to degradation

***The holy grail is something that is the best of both worlds: a Cas-associated protein that is small and a small guide RNA***

**Feng predicts this can be achieved through engineering**

- It’s not clear that such a compact system has been developed by nature, but we can start from Cas9 or IscB as a scaffold and then begin to engineer
- Peter can’t even fathom the commercial value of that; this is a trillion dollar product
- A lot of people are working on it
  - This work is being done both in universities and biotech companies
- Feng thinks it’s going to be very, very useful

## CRISPR-Cas9: therapeutic applications in the liver and the eye [1:19:45]

- Other capabilities we want to realize include: how do you insert large genes into the genome precisely and efficiently?
- Cas9, even though it’s large, we can deliver it to some cells *in vivo* already

**What cells can be delivered in vivo using Cas9 currently?**

- Liver is a place where we can use lipid nanoparticles to deliver Cas9 and guide RNA into
- The COVID vaccine is made using mRNA and lipid nanoparticle, and so it’s a very similar approach where you formulate these lipids with the Cas9 mRNA and guide RNA

*What is it about the liver that makes it amenable to a lipid nanoparticle?*

- There’s a lot of lipid recycling happening in the liver
- Lipid nanoparticles get bound by these recycling proteins and they get taken up

Peter asks, “*Does it matter the manner in which it’s given? Intravenous? Intramuscular? Do all lipid nanoparticles end up there provided they’re not ingested orally and presumably digested?*”

- A lot of it goes to the liver because the liver is one of the areas in our body that filters out all the toxins
  - Everything gets trapped there
- Potentially CRISPR could be used to fix some of the rare inborn diseases of metabolism where children are born without a particular enzyme
- It will depend on the mutation, whether or not we can use Cas9 or base editing or prime editing to be able to fix the mutation
  - In other words, we have to figure out the payload problem

***But if it’s in the liver and it can be addressed by targeting hepatocytes in the liver, then the delivery problem is already addressable***

**What about genetic diseases of the eye**?

- There are different eye diseases that are affected by single gene mutations. For example, [LCA10](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8078118/) is one of the eye diseases that there’s already been a CRISPR strategy being [developed](https://www.ohsu.edu/casey-eye-institute/allergan-leber-congenital-amaurosis-cep290-gene-therapy-trial) for

*The way that these diseases in the eye are treated*

- Designing Cas9 and a guide RNA to be able to knock out the gene that is causing degenerative conditions in the eye
- Then using a viral vector to deliver the Cas9 gene and also the guide RNA intraocularly into the patient
- Once the virus gets into the cells in the eye, they’ll make Cas9, they’ll make the guide RNA, and then that will carry out the modification
- Peter comments, “*In that sense, it’s a bit of the old meets the new. You’re taking the oldest trick in the book that was the original gene therapy vehicle, the virus, and you’re combining it with a far smarter payload, which is Cas9 and guard guide RNA.*”

**Where do these stand in clinical trials right now? Both the liver and the eye would be the leading edge of this.**

- The eye is the first place where in the US a gene therapy was developed and approved
- This is a drug called [Luxturna](https://en.wikipedia.org/wiki/Voretigene_neparvovec)
- Luxturna puts a gene into the eye to be able to treat a disease called [LCA2](https://www.ncbi.nlm.nih.gov/gtr/conditions/C1859844/)
- Basically, the virus provides a gene that is missing in the cells in the eye, and that is able to allow the patients to regain some light sensitivity
  - That was the first gene therapy
- Patients are completely blind without this therapy, and they get some light sensitivity back to that they can move around in a room with large obstacles
- This is all done through a single injection in the eye

**What are other ocular targets?**

- LCA10 is another one that was being developed by [Editas medicine](https://www.editasmedicine.com/)
- The way this disease developed is that there is a mutation that causes degeneration in the eye.
- The idea is to use Cas9, use the same viral vector system to deliver into the eye, and have Cas9 inactivate this mutant gene so that it can slow down or stop degeneration
- LCA2, you have to put an active gene in that was missing while with LCA10, you have to deactivate a gene
- LCA10 went through phase I and II
- There was [some efficacy in phase 2](https://ir.editasmedicine.com/news-releases/news-release-details/editas-medicine-announces-clinical-data-demonstrating-proof), some improving vision, but maybe not as robust as they had hoped for
- The phenotype of this patient without gene therapy is blindness (probably in their 30s) or deteriorating vision

**Why do you think that these therapies are not fully restoring vision?**

Peter asks “*In the case of the LCA2, is it because by the time you treat these people, the neuroplasticity part of it has lost its window of development? In other words, is the problem that if you treat these people late in life, the part of the brain that receives the visual signal isn’t developed? Or is it literally that we’re just not fixing the eye?*”

- The retina doesn’t regenerate
- If it’s already degenerating, you have to deal with what is left in the retina
- And so what you can restore is really capped by whatever that’s already left there
- Plus, there’s also inefficiencies in the delivery systems
  - You’re not restoring 100% of the cells
- Then if you’re layering on gene editing on top of it, which also has some less than 100% efficiency, and we multiply that all together, that’s why you’re not getting full restoration

**What would have to be true to fully restore vision in those patients?**

- It’s very hard to fully restore vision
- If you really want to fully restore vision, you probably have to regenerate the retina
- You have to replenish cells that are missing

Peter asks, “*Could that be done epigenetically?*”

- That could potentially work, but this is not Feng’s area of expertise, so he doesn’t know all the processes involved there
- If you can recapitulate development in the eye and allow cells to redevelop the retina as it was developing during development, then potentially you can regenerate the eye

**In the liver, what has been the success rate of the Cas9 delivery system (the lipid nanoparticle delivering the Cas9 payload)?**

- In the liver, it’s quite robust, probably 80, 90%

*Is that sufficient to correct any under-expression?*

- Right
- In the liver, there’s also an interesting development where scientists are trying to target a gene called [PCSK9](https://academic.oup.com/ehjcvp/article/10/2/89/7492807) to be able to treat cardiovascular disease
- The strategy is to paralyze PCSK9 so that you can inactivate PCSK9 and then reduce cholesterol

Peter asks, “*Any idea how much a treatment like that would cost?*”

- Feng doesn’t know ‒ initially, maybe tens of thousands of dollars
- Peter thinks that would be cheap because when the drugs came out that inhibit PCSK9, they were $15,000 a year (now they’re $6,000 a year)
- This is relatively inexpensive compared to a whole lifetime of therapy

**What’s driving the cost right now? What’s making it expensive today?**

- There are a lot of factors, including development cost, and also the fact that these drugs is the first time developing these modalities of drugs
- And so the manufacturing processes need to get developed
- Cas9 and Cas13 are being made at the laboratory scale, not commercially
- If you think about a mouse is 10 grams, a human can be 40 kilograms, so that’s 1000X larger in body weight, so you need a 1000X more material
- Developing the process to scale that to that level to be able to treat human beings, that is where the expensive process is

## The ethical implications of gene editing, the debate around germline modification, regulation, and more [1:30:45]

**First gene editing of human embryos**

- Peter recalls a [controversial case in China](https://en.wikipedia.org/wiki/He_Jiankui) with a scientist who edited the embryos of kids (this was an IVF case) to render them immune to HIV
  - One of their parents was HIV positive
  - On the surface this sounds like a great idea, but there was an enormous amount of backlash from the scientific and medical community
  - The risk of HIV transmission to the child was quite low in the first place
- This was back in 2018, and scientists made a mutation in the embryos in a gene called [CCR5](https://en.wikipedia.org/wiki/CCR5#HIV)
  - A CCR5 mutation is a naturally occurring mutation in the human population (in a single-digit percent of the population), and these individuals are naturally immune to HIV infection

Peter asks, “*Is this the* [*Magic Johnson*](https://en.wikipedia.org/wiki/Magic_Johnson#HIV_activism) *mutation?*”

- Right
- Without the CCR5 protein on the surface of immune cells, HIV cannot bind and enter the cell
- The scientists edited the human embryo, to remove the CCR5 gene, but it turned out that that edit wasn’t complete
- Earlier we were talking about [mosaicism](https://en.wikipedia.org/wiki/Mosaic_(genetics))
- The result of his edit was actually 2 girls who were mosaics for the CCR5 mutation
  - Suggesting that editing wasn’t very efficient
- The edit was done very early on post-fertilization

Peter asks, “*To have guaranteed no mosaicism, would you need to do this edit at a single cell, and then proliferate only that cell, and discard the rest of the blastocytes?*”

- In theory, that’s the way to do it
- Feng doesn’t know how much of the technical details were released for this case
- For these girls, some of their immune cells have CCR5 and some don’t
  - That means those cells with CCR5 can be infected by HIV
  - But maybe they’ll never die of AIDS because they’ll always maintain a population of T cells that are not susceptible to infection

**What was the fall out for this scientist?**

- The world responded very harshly to this because there was no medical need to do this
- The scientific and medical community, everyone voiced their concern about this ethical issue that just occurred
- The scientist was put under house arrest for a while
- This incident also really motivated much more ethical discussions around gene editing
  - There was ethical discussion before, but it really focused the issue
  - There were multiple working groups that were established, multinational working groups between the different national academies, US, China, UK, as well as the WHO had several working groups
- Feng thinks in the US there is legal regulation that prevents a germline modification, but it’s certainly not the case internationally

**What do you think is being worked on outside of the US in places where there’s no regulation with respect to germline mutation?**

- Feng doesn’t know what is happening internationally, because people are not publicizing their work

***What is known is that there is international consensus that we don’t want to do these types of embryo germline editing right now***

**What about things that really matter?**

[*APOE4*](https://en.wikipedia.org/wiki/Apolipoprotein_E#E4) *and* [*Lp(a)*](https://en.wikipedia.org/wiki/Lipoprotein(a)) *aren’t necessary to correct, but what about* [*Huntington’s*](https://en.wikipedia.org/wiki/Huntington%27s_disease)*,* [*inborn errors of metabolism*](https://en.wikipedia.org/wiki/Inborn_errors_of_metabolism) *where children are probably going to die during infancy,* [*cystic fibrosis*](https://en.wikipedia.org/wiki/Cystic_fibrosis)*, things for which we  have no viable treatments?*

- There’s a lot of discussion going on, so it’s certainly not a settled issue

***What scientists have all come to terms with is that the technology still needs much more validation and development before it is ready for application in this germline editing setting***

- The efficiency, the specificity, both need to be optimized further in order for there to be any chance of a germline therapy having the intended effect

Peter asks, “*How much of that do you think is the main reason for hesitation versus the slippery slope argument of, if we do that, how far are we from doing APOE4 (which may be a little bit gray)?*

**What about identifying genes that are frankly not remotely related to lifespan or medical necessity, but instead relate to kind of the stuff that people talk about in science fiction?**

- A gene to make your kid a little bit taller
- A gene that relates to intelligence or some other physical characteristic that is completely irrelevant to their health

*Is it more about, this is dangerous, we don’t know how to do it.  Or even if we figure this out, we don’t want to open up a Pandora’s box?*

- This is very much the debate that is happening right now
- There are patient groups who are advocates for using this, using gene editing in a germline setting to treat disease
  - Assuming the technology is safe and efficacious, then we should do it, because it will alleviate suffering
- There are also people arguing the slippery slope argument, which is, if we allow for X and Y, then eventually we’re going to be getting into uncharted territories with designer babies and so forth
- Feng thinks it’s important to recognize that science is also progressing other fronts
  - There are likely advances in science that will achieve the same outcome without gene editing
- All of those things are a competition with each other in the ethical debate, and that’s why this is such a complicated issue

> “*You’re one of three or four people on the planet who not only know more about this technology, but have been personally responsible for it. As such, I can’t imagine you get to sit quietly during these debates.*”‒ Peter Attia

**Where do you think the line should be drawn in what we as a scientific or medical community permit, with respect to gene editing in the germline?**

*We’re talking about making an edit that will persist in perpetuity*

- Feng has thought about this issue a lot
- Things that are very easy to agree on is if there is an obvious and important medical benefit
  - For inborn errors of metabolism
  - If the technology is there, he thinks it’s okay to improve the lives of those patients
- There are certainly people who have not come around to that point of view
- When making a medical decision like that, it’s also important to consider what other **alternative methods** there may be
- For example, preimplantation genetic testing is another method where you might be able to screen out embryos that have those mutations
  - For IVF, all of those disease can be checked

## Genetic engineering to enhance human traits: challenges, trade-offs, and ethical concerns [1:40:45]

- Peter suggests, “*It gets to maybe a more complicated question which is, is there a role for genetic engineering within in utero, for example?*”
  - Or is that just so technically challenging that it’s much easier to focus on just the IVF side of things?
- Certainly for [monogenic](https://www.biologyonline.com/dictionary/monogenic-trait#:~:text=A%20monogenic%20trait%20is%20a,trait%20produced%20by%20a%20polygene.) genetic disorders, IVF is probably the most likely application

**Further down the road, there are some obstacles to solve**

- Feng explains, “*Further down the road, there are some obstacles to solve. One, we don’t really understand biology enough.*”
  - Nobody knows how to make your kid 30 IQ points smarter
- The biology needs to catch up
- But as society continues to develop, if the science is there, and the technology is also there, Feng thinks people will opt to do that
- Peter’s view is these problems are harder than people think

[***Polygenic***](https://en.wikipedia.org/wiki/Genetic_disorder#Multifactorial_disorder) ***nuanced traits like intelligence, athletic performance, resilience, happiness, all of those things are infinitely more complicated than we believe, and probably just as environmental as they are genetic***

- So even if you give somebody the right genetic template, if they’re not in the right environmental surrounding, they won’t necessarily even develop the way you hope
- For example, you might give somebody 30 more IQ points, and it doesn’t translate to a person being demonstrably more intelligent if they aren’t in the right environment

***It’s more complicated than any lay person is thinking about***

**Another thing is, biology has a lot of compensation**

- You might make some mutations that make the person smarter, but that could also increase cancer risk, or impair athletic capability, make a person live shorter
- Those complicated trade-offs are things that people maybe don’t fully appreciate

**Peter’s point of view**

- When it comes to **a disease that’s going to kill you** with no other treatment ‒ it seems like a no-brainer
- At the other end of the spectrum, when we’re talking about **things that are truly superfluous**, like intelligence, height, athletic performance, eye color, any sort of trait ‒those seem clearly like a horrible reason
  - Because we have no idea how complicated the system is
  - If you’re going to take huge risk, there has to be a huge payoff, and the asymmetry of that strikes Peter as too much

- Then there’s the **gray area**, and that’s where he feels a bit nuanced
- Should we just get rid of [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)) genes? Well, maybe
- But then to Feng’s point, we have antisense oligonucleotide inhibitors that are just around the corner, that effectively will get rid of Lp(a) (they shut the gene off)
  - So, why would we risk trying to eradicate this from the population, when we can just give you a drug that does the same thing with fewer side effects and less permanence?
- Feng suggests that instead of doing it in the germline, change it in somatic cells

*Then there is another area; for example, look at something like* [*autism*](https://en.wikipedia.org/wiki/Autism)

- Autism is a genetic disease despite what many people will have you believe
- The [heritability](https://en.wikipedia.org/wiki/Heritability) of autism is so high, that we know it’s largely a genetic disease, but very polygenic, very subject to other things
- Do we really want to get rid of it? Maybe.
- Certainly when you see a child that’s devastated by autism, who’s nonverbal, who’s harming themselves, it would be very logical
- But, when you start to move further from that end of the spectrum towards the end of the spectrum where people are quite functional with autism, you might say, “*Well, I don’t know. It actually comes with some benefits as well*.”
- And do we want to create a homogeneous society where everybody is the same?
- Feng doesn’t think we want to
- This is the crux of sophistication

***That diversity is important for the human race as a whole; it is what will allow the human race to be resilient in the long run***

## Feng’s early life, the influence of the American education system, and the critical role teachers played in shaping his desire to explore gene editing technology [1:46:00]

**Where did you grow up?**

- Feng moved to Des Moines, Iowa when he was 11 years old

*What brought your parents here?*

- His mother came to the US first; she was an exchange scholar in computer science
- She had a chance to visit one of the schools in Iowa, and she saw that the educational system in Iowa was much more hands-on, as opposed to visual memorization
- Because of that, she thought he would maybe benefit more from that type of instruction
- So she decided to stay in the US and immigrate here

**When did you start to become aware of your intellectual abilities, for lack of a better term?**

*Was school always easy for you? Did you ace every test?*

- Feng shares, “*I don’t think I’m all that smart. I’ve always been interested in science. I’ve always been very curious. So I think I’ve just always kind of followed my curiosity to do something that is enjoyable and fun.*”
- Interestingly, as a kid, he didn’t like biology at all
- He preferred physics, chemistry, and mathematics
  - It was more logical, things that he can understand and build a mental model for, and then be able to predict things
- Biology was very much visual memorization
- When he first moved to Iowa in 7th grade, there was life science in middle school
  - He remembers it was really about memorizing trees, and dissecting frogs, and identifying anatomical parts
  - It wasn’t so much based on logic

**During 7th grade he attended a Saturday enrichment class about molecular biology**

- He didn’t know what biology had to do with molecular things, so he went to it
- The teacher was very passionate
- In that class, he started to learn about the advances in modern biology
  - The central dogma: DNA→ RNA→ Protein
  - He did fun experiments like extracting DNA from strawberries, and putting an antibiotic resistance gene into a bacteria so that it can survive on ampicillin
- The teacher also showed us this “documentary,” but it’s actually a Hollywood movie called [*Jurassic Park*](https://en.wikipedia.org/wiki/Jurassic_Park)
  - If you put yourself in Feng’s shoes at a time where you’re learning all these molecular biology fundamentals, gene splicing, all that, and then watching *Jurassic Park* to see all those theories being so tangibly there to make a dinosaur
  - The movie really felt like a documentary, but it was also just so inspiring and exciting
- Feng became really interested in learning more about molecular biology

> “*We also learned about gene therapy, and the promise of using molecular biology to build rational designed medicine. So that really captivated my imagination.*”‒ Feng Zhang

*The teacher was amazing; his name is Ed Pelkington*

- He was a consultant for the school, and he was working with kids who were interested in science and technology
- He remembered that both Feng and also a few other students were really captivated by molecular biology
- By the time Feng started 10th grade, he came to them with an opportunity at the Iowa Methodist Medical Center gene therapy lab
  - They have a volunteer program at a hospital
  - He applied to volunteer in the gene therapy lab

**Feng and 3 other kids got admitted to the gene therapy lab and were taught how to do experiments**

- The very first experiment he did: a scientist had him put the gene for a jellyfish protein called green fluorescent protein (discussed earlier; it’s a protein that makes jellyfish glow) into a human cancer cell
  - Using just lipid: we wrapped it up with a bit of fat, and then it got absorbed by the cell
- He did that one afternoon, then the following day, he went to the lab and the scientist took him into a dark microscope room
  - There was a beam of blue light coming out of the microscope
  - They put the Petri dish with the cells on it, and he told me to look into the eyepiece and saw a field of green cells that were fluorescent
    - It looked alien to Feng
- He was in the 10th grade, and that moment made him feel so inspired about what they were doing
- The idea that we can use out knowledge and start to engineer rationally medicine

***From that moment, he though science is really cool and wanted to do more experimental science***

**Do you ever just reflect on the direction your life took in response to something as seemingly arbitrary, as where your parents chose to move, your good fortune to be in that enrichment class?**

- Peter is sure he’s heard the arguments for the remarkable set of circumstances that allowed [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) and [Paul Allen](https://en.wikipedia.org/wiki/Paul_Allen) to be in the right place at the right time from the right high school, that had a computer lab that took these people who were naturally quite brilliant, but more importantly, put them in an environment where they could sort of leapfrog ahead of the time

*Do you see a parallel there?*

- Feng thinks he’s been very fortunate
- There are a couple of things that over time he has developed more and more gratefulness and appreciation for
- 1 – The importance of teachers
  - He’s been with many teachers who care about nurturing the next generation, and teachers who really want to find as many opportunities as possible to help their students develop
- 2 – America, being able to immigrate to the US and go through the American educational system, where there’s really a merit-based system
  - Where you can work hard and be able to learn and develop, and have access to opportunities, that is really special about America

***Education and having a system, where it nurtures people who want to develop and work hard has been his great fortune***

**What did you study at Harvard for your undergrad?**

- Chemistry and physics

*Why did you choose that as opposed to biology or molecular biology?*

- He wanted a greater grounding in the physical sciences
- He knew he wanted to study biology and engineer biological systems, but he felt that biology was developing so rapidly
  - New information was accruing on a weekly basis, with new studies
- He thought it would probably be more beneficial if he studied something that’s not going to change very much from the time that he enrolled in college to the time he graduated
- Chemistry and physics were much more established fields, and it provided a scientific foundation that has been tremendously helpful as Feng continues to work in biology
- At the same time, he did work outside of classes in a biological lab, where he was practicing biological experiments, and reading the latest literature
- He thought that was a nice combination

**When you selected Stanford for your PhD, did you do so because of Karl? Or was there another reason?**

- Karl hasn’t started at Stanford yet
- When Feng was growing up, especially after moving to Iowa, he read about people like Steve Jobs, and Bill Gates, and the internet revolution that was happening
- And so, he had a special feeling about Silicon Valley
- When he applied to graduate school, he thought Stanford, being in Silicon Valley would be a really good place to be
  - He made the decision that way

**How did you then make the decision to go back to the East Coast for your postdoc, back to Harvard, MIT area, as opposed to stay in the Silicon Valley and pursue your passions there in closer approximation to industry?**

- At the time it was probably the most interesting opportunity
- [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) is a phenomenal mentor, and Feng learned a tremendous amount from him
  - Not only about doing science, but also how to just be a good contributing member of the scientific community, with sharing of information and reagents, and the transfer of knowledge to as many people as possible
  - He was also a great mentor, where he just gave me opportunity to try things
- During graduate school for many months, Feng was working on a biofuel project in Karl’s lab
  - This was 2007, 2008
  - It was during the oil crisis and biofuel was an important thing
    - Peter and [Alex Aravini](https://www.linkedin.com/in/alex-aravanis-md-phd-3a9345/)s were working at the exact same time
- Feng thought it was an interesting problem and maybe they could raise venture capital if they had something working
- But around 2008 the financial crisis hit, and a lot of those opportunities at that moment seemed to vanish
- At the same time, he was contacted  by someone from the Harvard Society Fellows, and they said, “*We liked your work as a graduate student. Would you be interested in coming to the Society Fellows, and just explore science here?*”
  - They offered him a stipend, and he was not expected to do anything specific
    - He could just go there and hang out and think about interesting things
  - So he applied and went there
- At Harvard he started to explore gene editing technology

## Feng’s optimism about the trajectory of science [1:58:15]

**You’re barely 40-years-old, you’re one of the most prominent scientists in your field. Are you optimistic about the state of science?**

*Peter points out 2 negative things*

- 1 – There’s been a clear attack on meritocracy in the US, and a lot of the opportunities that served Feng well might not have served him well today
  - They might not have been available to him for various reasons, including his race
- 2 – Despite all of the remarkable scientific advances during COVID, there was also a loss of public faith in science during COVID
  - Some of the lines between science and advocacy got blurred greatly
- What Peter is saying is, “*There are a lot of things today that don’t look as promising as they did maybe 10 years ago, vis-a-vis the field, and just sort of the state of the art.*”

*Do you remain as optimistic as ever, or do you have concerns?*

- Feng is an optimist and thinks that’s the only way to be
- Because if you are not optimistic, then there’s only downside

> “*I am optimistic about science. I am so excited about all of the rapid advances that are happening, knowledge about biology, about the human body, physiology is accumulating at a very rapid pace.*”‒ Feng Zhang

- Every week there are interesting and exciting discoveries that are being reported
- And our technologies for studying biological systems are also accelerating

***With sequencing technology development, to protein mass spectrometry, to gene editing, to new microscopy ‒ that is allowing us to collect new and more rich data cheaper and faster***

- With the **advance of AI** and larger computing platforms, we can analyze, and learn, and build models around those data that are much more powerful, and much more predictive and generative than ever before
- That combined with future advances in robotics, where we can have automation of experimentation
- And maybe even building a closed loop system, where AI and with human intervention can design and iterate our experiments rapidly

***Feng thinks it’s going to accelerate science, and medicine, and human health beyond our imagination (that’s really exciting)***

**At the same time, we need to continue to motivate people’s interest in science**

- We need to make sure that the best talent are going to science

*Do you worry that we’ve lost focus on STEM?*

- People talk about the heyday of science ‒ in the 1960 when kids growing up saw the space program, saw the Cold War, the best and the brightest wanted to do science and engineering

*How do we get the best people into STEM?*

- We can do more, for sure
- We need to get kids more excited about science
- We need the education system to support kids who are curious, and who have special interests in the sciences and technical things
- To give them opportunities like the ones that Feng had, to really explore those curiosities and interests when they’re young, they are optimistic, and they have energy

***If we can nurture that, and help them maintain that curiosity and energy, Feng think that’s how we get the best people to continue science***

- This is not an investment that pays off in a year
- You’ve got to be doing this today, and then you’ll get your payoff in a decade, in two decades
- And sometimes those investments are really hard for society to make, because it’s hard to say, “*I got to pay money now for something. And I don’t get paid back for 10 or 20 years*.”
- Peter hopes that people listening to this podcast appreciate, certainly in Feng’s case, what an enormous value it was for that investment

**In many ways, this is a great story of lots of things**

- It’s a story about immigration
- It’s a story about science education
- It’s a story about curiosity
- It’s a story about the American dream
- Peter is really glad they finally got a chance to sit down, and he’s excited to follow Feng’s undoubted continued success over the coming decades

§

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Karl Deisseroth**: [#191 – Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.](https://peterattiamd.com/karldeisseroth/) (January 17, 2022) | [1:15, and 4:00]

***New York Times*** **article about zinc finger nucleases**: [In New Way to Edit DNA, Hope for Treating Disease](https://www.nytimes.com/2009/12/29/health/research/29zinc.html) | Nicholas Wade, *the New York Times* (December 28, 2009) | [30:15]

**Use of AI to predict protein folding**: [1:04:30]

- [DeepMind](https://deepmind.google/technologies/alphafold/) (2024)
- [AlphaFold Protein Structure Database](https://alphafold.ebi.ac.uk/) (2024)
- [Highly accurate protein structure prediction with AlphaFold](https://www.nature.com/articles/s41586-021-03819-2) | *Nature* (J Jumper et al 2021)

**Episode of** ***The Drive*** **with Dena Dubal**: [#303 – A breakthrough in Alzheimer’s disease: the promising potential of klotho for brain health, cognitive decline, and as a therapeutic tool for Alzheimer’s disease | Dena Dubal, M.D., Ph.D.](https://peterattiamd.com/denadubal/) (May 27, 2024) | [1:07:00]

**Cas13 used to detect Coronavirus RNA**: [Clinical validation of a Cas13-based assay for the detection of SARS-CoV-2 RNA](https://pubmed.ncbi.nlm.nih.gov/32848209/) | *Nature Biomedical Engineering* (M Patchsung et al 2020) | [1:14:15]

§

## People Mentioned

- [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) (Professor of Bioengineering and of Psychiatry and Behavioral Sciences at Stanford University and Howard Hughes Investigator) [1: 15, 3:45, 1:56:45]
- [Francisco Mojica](https://imem.ua.es/en/about-us/francisco-juan-martinez-mojica.html) (Senior Lecturer of Physiology, Genetic and Microbiology at the University of Alicante, discovered CRISPR sequences in bacteria) [13:30, 29:00]
- [Eugene Koonin](https://irp.nih.gov/pi/eugene-koonin) (NIH Distinguished Investigator, bioinformatician focused on evolutionary genomics) [18:00]
- [Sylvain Moineau](https://www.moineau.bcm.ulaval.ca/index.php?id=2) (Full Professor of Biochemistry, Microbiology and Bioinformatics at University Laval, Quebec, Canada, expert in bacteriophage) [29:00]
- [Rodolphe Barrangou](https://cals.ncsu.edu/food-bioprocessing-and-nutrition-sciences/people/rbarran/) (Professor of Food, bioprocessing and Nutrition Sciences at NC State University, expert in CRISPR-Cas systems and probiotics) [29:00]
- [Ulla Bonas](https://www.biologie.uni-halle.de/institutsbereich_genetik/4118_3522687/prof._dr._ulla_bonas/) (Emeritus Professor of Genetics at Martin-Luther-University, Halle, Germany; expert in plant pathogens and TALES) [34:15]
- [Adam Bogdanove](https://cals.cornell.edu/adam-j-bogdanove) (Professor of Integrative Plant Science Plant Pathology and Plant-Microbe Biology at Cornell College of Agriculture and Life Sciences, expert in TALES) [34:15]
- [Maria Jasin](https://www.mskcc.org/research/ski/labs/members/maria-jasin) (Professor and Chair of Developmental Biology at Memorial Sloan Kettering Cancer Center, expert in DNA repair) [45:00]
- [James (Jim) Haber](https://www.brandeis.edu/biology/faculty/haber-james.html) (Professor of biology and Director of Rosenstiel Basic Medical Sciences Research Center at Brandeis University, expert in DNA repair)  [45:00]
- [David Liu](https://www.liugroup.us/) (Professor at Harvard, Professor and Director of the Merkin Institute of Transformative Technologies in Healthcare, Broad Institute member and vice-chair of the faculty, expert in base editing) [1:00:15]
- [Dena Dubal](https://neurograd.ucsf.edu/people/dena-dubal-md-phd) (Associate Professor of Neurology at the University of California San Francisco, expert on klotho) [1:07:00]

§

![](https://peterattiamd.com/wp-content/uploads/2024/10/bio-fengzhang.png)

##### Feng Zhang

Feng Zhang earned his AB in chemistry and physics from Harvard College and his Ph.D. in chemistry from Stanford University. Dr. Zhang is a core institute member of the Broad Institute of MIT and Harvard, as well as an investigator at the McGovern Institute for Brain Research at MIT, co-director of the K. Lisa Yang and Hock E. Tan Center for Molecular Therapeutics at MIT, the James and Patricia Poitras Professor of Neuroscience at MIT, and a professor at MIT, with joint appointments in the departments of Brain and Cognitive Sciences and Biological Engineering. Zhang is also an investigator at the Howard Hughes Medical Institute.

Dr. Zhang is a molecular biologist seeking to improve human health by discovering approaches to modulate cellular programs, including returning diseased, stressed, or aged cells to a more healthful state. These approaches include developing molecular technologies for modifying the cell’s genetic information and the delivery vehicles needed to get these tools into the right cells as well as larger-scale engineering to restore organ function. Zhang hopes to apply these approaches to neurodegenerative diseases, immune disorders, aging, and other disease contexts.

Dr. Zhang pioneered the development of CRISPR-Cas9 as a genome editing tool for human cells. Zhang has also developed new methods to deliver these tools into human cells. Zhang’s group has developed and applied CRISPR-based technologies, including large-scale screening methods, to advance our understanding of human diseases and to diagnose pathogens. Collectively, these tools, which he has made widely available, are accelerating research. In 2023, the first Cas9-based therapeutic, which is based on a design Zhang developed in 2015, was approved for clinical use to treat sickle cell disease.

Zhang is a recipient of many awards including the Lemelson-MIT Prize, the Tang Prize, the Canada Gairdner International Award, and the Merkin Institute Fellowship at the Broad. Zhang is an elected member of the National Academy of Sciences, the National Academy of Medicine, and the American Academy of Arts and Sciences. [[Broad Institute](https://www.broadinstitute.org/bios/feng-zhang)]

Website: [zlab](https://www.zlab.bio/)

X: [@zhangf](https://x.com/zhangf?lang=en)