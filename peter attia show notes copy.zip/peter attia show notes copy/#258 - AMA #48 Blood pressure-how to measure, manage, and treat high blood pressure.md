# #258 – AMA #48: Blood pressure—how to measure, manage, and treat high blood pressure

**Source:** [https://peterattiamd.com/ama48/](https://peterattiamd.com/ama48/)

---

In this “Ask Me Anything” (AMA) episode, Peter delves into the critical subject of blood pressure, which is one of the three primary causes of atherosclerosis, along with high apoB and smoking. He begins by unraveling the nature of high blood pressure, its prevalence, and why it often goes undiagnosed. Peter describes in detail the proper way to accurately measure blood pressure and what determines a diagnosis. Next, Peter discusses the actionable steps one can take in response to high blood pressure, shedding light on the extent to which factors like weight loss, exercise, and nutrition can make an impact. He also explores the pharmacological options available and offers valuable insights on how to approach them.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #48 show notes page](https://peterattiamd.com/ama48). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Blood pressure and other risk factors for cardiovascular disease [2:30];
- Defining blood pressure and the purpose and meaning of a blood pressure measurement [5:45];
- The implications of high blood pressure and the importance of maintaining an optimal level [10:30];
- The importance of accurate measurements of blood pressure and how Peter approaches the care of patients at the very top range of “normal” [21:45];
- The prevalence of high blood pressure—a hidden epidemic? [24:30];
- The consequences of high blood pressure on cardiovascular health, brain health, kidneys, and more [24:45];
- Low blood pressure: symptoms and consequences [35:30];
- How to properly measure blood pressure [37:45];
- Daily variance in blood pressure and the transient changes in blood pressure during exercise [48:00];
- Primary hypertension vs. secondary hypertension: what to look for [51:45];
- Lifestyle factors impacting blood pressure: weight loss, exercise, and sodium [57:45];
- Impact of insulin resistance and type 2 diabetes on blood pressure [1:04:45];
- How sleep impacts blood pressure [1:06:45];
- Pharmacologic options for managing blood pressure [1:08:00]; and
- More.

§

The Peter Attia Drive

Blood pressure—how to measure, manage, and treat high blood pressure

§

## Show Notes

## Blood pressure and other risk factors for cardiovascular disease [2:30]

**If you look at cardiovascular disease, three main risk factors**:

- 1) Smoking
- 2) ApoB
- 3) Blood pressure

Today’s discussion:

- So far, we hadn’t done as much of a deep dive on blood pressure
- Answering questions like: what is high blood pressure, low blood pressure, why should someone care, what does it affect, because it goes beyond just the risk of cardiovascular disease as well as how do you know where you’re at?
- Unlike apoB, you can’t give yourself an at-home blood test, but you can check your blood pressure and you can understand how it changes throughout the day

We will also discuss:

- The common terminology about blood pressure
- What can you do to control your blood pressure?
- What are the lifestyle factors that you can do to lower it? How well do those work?
- What are the most common drugs? What do we know about them? Are there factors that would make one “better” than the other?

## Defining blood pressure and the purpose and meaning of a blood pressure measurement [5:45]

***What does a blood pressure measurement actually mean, what is it actually doing and measuring?***

- The heart is pumping and what you’re feeling is the pulsatile sensation of the pressure difference in the arteries as the heart contracts
- There’s two phases of the cardiac contraction: systole and diastole

**Systole**

- The first is called **systole**—when the ventricles are contracting
- The ventricles are the larger chambers, the left one being the muscular one because it has to pump the blood against the systemic resistance of the whole body, and it’s the one that’s responsible for getting blood out to the body

\*Side note:

- Today, we’re going to talk about the *systemic circulation* and we’re NOT going to talk is a different blood pressure, which is pulmonary blood pressure
- It turns out that when people hear 120 over 80 is their blood pressure, that is talking about the blood pressure in their circulatory system of the periphery
- but if you wanted to know the blood pressure in your lungs, which is controlled by the right ventricle, those would be *pulmonary* pressures, and those would be significantly lower

*Back to systole*:

- So, when your left ventricle contracts, your in systole
- blood is leaving the heart through the aortic valve, goes out the aorta at the ascending part of the aorta, and then it immediately just starts moving to the rest of the body
- This is happening really quickly, even if your heart is beating as slow as one beat per second/60 beats per minute
- There’s a pressure in the artery that is experienced by literally the blood pushing against the walls of the artery during that phase

**Diastole**

- It’s important to remember that there is a second equally important phase of the heart, which is the relaxation of the ventricle, and that’s how they fill—that’s called diastole
- So after the heart squeezes and blood leaves the heart, the heart has to relax to have blood come back into the ventricles through the atria
- This is when the heart itself receives its blood supply, whereas all the other organs are receiving their blood supply during systole
- Even though the pressure in the arteries is lower during diastole, there is still a tonic amount of pressure within the artery wall

So when you have your blood pressure checked and it spits out two numbers like, 125 over 79, what that means is…

- when your heart is doing the squeeze and there’s the greater force as blood is leaving the left ventricle via the aorta, the pressure is 125 millimeters of mercury
- And when that ventricle relaxes and begins to fill through the left atrium, the pressure drops to 79 millimeters per mercury

## The implications of high blood pressure and the importance of maintaining an optimal level [10:30]

***when we say high blood pressure, what are the two numbers that we’re referring to so people can, as they look back at their own blood pressure results, can kind of know where they fit?***

- This has changed a little bit
- Prior to 2017, we had a little bit more leeway in the system
- But the current updates, which have been in place for about six years and which were updated after the [SPRINT trial in 2015](https://www.nejm.org/doi/10.1056/NEJMoa1511939), leave us where we are today:

![](https://peterattiamd.com/wp-content/uploads/2023/06/f1-ama48-1024x680.png)

**Figure 1.** [Source.](https://www.jacc.org/doi/epdf/10.1016/j.jacc.2017.11.006)

- Today, “normal” blood pressure is both less systolically than 120 and diastolically 80 — so 119 over 79, for instance
- “Elevated” is when the systolic pressure is between 120 and 129, but the diastolic pressure remains less than 80
- Then we get into two stages of hypertension
- Stage 1 is when systolic blood pressure is between 130 and 139, OR diastolic blood pressure is between 80 and 89
- So you could be 120 over 83, and now you’re at stage one, even though your systolic is normal.
- Stage 2 is when either systolic exceeds 140, or diastolic exceeds 90

***So where do these numbers come from?*** ⇒ [SPRINT trial in 2015](https://www.nejm.org/doi/10.1056/NEJMoa1511939)

*Overview of the study*

- The purpose of this trial was to understand: What is the benefit of aggressive blood pressure control?
- The study looked at just under 10,000 people who had a systolic blood pressure of 130 or greater, who were also at advanced cardiovascular risk, but who did not have type two diabetes
- The reason for that patient selection is that you wanted a group of people who were at a high enough risk for ASCVD that you could start to see events in a relatively confined period of time

*Subjects and randomization*

- Subjects were were randomized into two groups
- First group, which we’ll call the intensive treatment, was treated to a systolic blood pressure of less than 120
- Second group was the standard treatment group who were treated to a blood pressure of less than 140
- Note that coming in, the average blood pressure of all comers was about 140 over 78

*How they measured blood pressure:*

- This study did a pretty rigorous job of assessing blood pressure—they used an office visit where blood pressure was measured three times using the following protocol
- The patient would sit down for five minutes doing nothing, not talking, not doing anything, their back is supported, their legs aren’t crossed
- After five minutes, blood pressure was taken with an automated cuff
- Five minutes later, they would repeat the measurement
- And five minutes later, they would do it a third time
- The blood pressure for that visit was deemed as the average of all three of those readings
  - So, for example, if on day one you were 137 over 81 and you were in the “standard treatment” group, they would make no adjustment to your medication (since you were already under 140)
  - But if you were on the intensive group, they would treat you to try to get you down to 120 or lower

*Results:*

- After one year, the average systolic blood pressure in the intensive treatment group was 121.4 millimeters of mercury
- In the standard group, it was 136.2
- And at just a little over three years in median follow up, the study was halted
  - Halting a study is not uncommon in hard outcome studies when the benefits in one of the arms is so much greater that it becomes unethical to continue the study
- The primary outcome—which was a reduction in cardiovascular mortality—was significant with a 25% relative reduction and with an absolute risk difference of about 0.54% over the course of one year
  - These percentages may not sound like a lot, but you have to remember, that’s just a **single year reduction in risk**
  - That’s quite significant when you consider that blood pressure, just like lipids, are **compounding risk factors**
- At the three year mark, the total event rate (events being myocardial infarction, non-myocardial infarction, acute coronary syndrome, stroke, acute heart failure, and cardiovascular death) was about 1.6% lower in the intensive group
- Perhaps more interesting, however, was that the study also saw a benefit in **all-cause mortality**
  - Peter would not have necessarily expected this
  - While it’s not too surprising that they saw a benefit in the primary composite outcome, it’s maybe a little surprising how big the benefit was in such a short period of time
  - But what really caught people off guard was that all cause mortality was also reduced 27%, and it was a 1.2% absolute risk reduction—and this was seen in kidney disease, accidental death, suicide, homicide

![](https://peterattiamd.com/wp-content/uploads/2023/06/f2-ama48-1024x840.png)

**Figure 2.** Study results. Credit: [SPRINT trial in 2015](https://www.nejm.org/doi/10.1056/NEJMoa1511939)

- It’s possible that maybe a larger study, that wouldn’t pan out this way with the all-cause mortality
- But nevertheless, this was about as dispositive a study as you’re going to see demonstrating the efficacy of aggressive blood pressure lowering

**The takeaway**: Even over a relatively short period of time, aggressive blood pressure management to a systolic pressure less than 120 compared to standard of care, which we used to think 130 to 140 is tolerable, left very little ambiguity about the importance of that kind of recommendation.

**The nature of compounding**

- compounding is insanely powerful when it comes to this type of biology, whether it be smoking, apoB or blood pressure
- let’s just take a step back and talk about why these things pose such a risk
- ASCVD, cerebral vascular disease, you can think of them as blood vessel diseases
- and elevated blood pressure, hypertension is a mechanical disruption to the endothelium
- Smoking is a chemical disruption to the endothelium
- And of course apoB is the concentration of the lipoprotein that itself goes through that disrupted endothelium, and then causes the pathologic sequence of events that we’re very familiar with
- So it’s not surprising that these are all area under the curve problems.

## The importance of accurate measurements of blood pressure and how Peter approaches the care of patients at the very top range of “normal” [21:45]

When it comes to blood pressure, if someone is right on the border of having “normal” and “elevated” levels (e.g., 119 over 78), *would Peter be worried or content with that level?*

- Peter says he would be very happy with a blood pressure of 119 over 78
- He notes that what’s more complicated with blood pressure is the complexity associated with measurement and really making sure it’s being measured correctly
  - In other words, there’s far more heterogeneity in how you measure blood pressure than how you measure apoB
  - Once you have a lab that has a validated assay for measuring apoB, you can have much more confidence in the little bit of variability you see in that
  - But when it comes to blood pressure, there can be enormous swings in blood pressure based on erroneous measurement
- The other thing you have to think about is, with apoB, *you can’t go too low*
- With blood pressure, *you can go too low*
- In clinical practice, Peter will never make decisions on the basis of one day of measurement—he needs to see two weeks of checking it 2-3 times per day under perfect conditions
  - Only at that point would he even begin to entertain what is high or what is low

Let’s assume you’ve got two weeks of twice daily average recordings, and you come out at 123 over 79…

- Peter would be very hesitant to go straight to medication
- With blood pressure, you run a much greater risk of symptoms if you *over-medicate* somebody, especially if that’s where you’re starting
- You can get orthostasis, which means lightheadedness when you stand, and that can lead to a whole cascade of problems as well
- Peter considers blood pressure management as a “bit of an art”

## The prevalence of high blood pressure—a hidden epidemic? [24:30]

***How common is high blood pressure?***

*Do we know what percent of the population is walking around with high blood pressure, whether they know it or don’t?*

- It’s actually “staggering”, says Peter
- The overall prevalence in the United States for both stage 1 and stage 2 hypertension is about 46% based on those new categories
- This is based on surveys that collect blood pressure measurements or self-reported anti-hypertensive medications
- You could argue that’s not entirely accurate, because that’s also including people who are medicated, but clearly this is high
- The bigger issue is: How much of this is a *hidden* epidemic?
  - In other words, how many people walking around haven’t been to the doctor in five years, don’t know their blood pressure, because presumably they’re not checking it on their own, obviously aren’t taking any medications?
  - That’s a harder number for us to come to grips with, but it’s safe to say that this is a silent epidemic

**Blood pressure clearly goes up with age likely due to increased vascular stiffness and ASCVD**

![](https://peterattiamd.com/wp-content/uploads/2023/06/f3-ama48-1024x605.png)

**Figure 3.**

- If you look at young people in the 20 to 44 age range, men might have as high as a 30% prevalence of hypertension, while women would be just below 20%.
- Once into middle-aged 45 to 55, half of men would at that point present with hypertension, 44% of women, and it just goes up and up and up
- By the time you’re 75 years of age and older, it’s north of 80% effectively for both sexes, men and women

**Differences by race**

![](https://peterattiamd.com/wp-content/uploads/2023/06/f4-ama48-1024x596.png)

**Figure 4.**

- We also see this slightly playing out differently in race
- For both men and women, African-American has the highest prevalence of hypertension. In men, it’s about 59%. In women, 56%.
- in non-Hispanic white, it’s 47 and 41% respectively for men and women
- For non-Hispanic Asian, 45% and 36% for men and women
- And for Hispanic, 44 and 42% for men and women respectively
- the takeaway there is African-Americans are at higher risk, and as you age, you’re at higher risk
- Men in the younger years seem to be more prevalent than women, but as they get older, those tend to converge

**Translation** = *There’s nobody who’s not at risk*

- The importance of compounding, when you look at 20 to 44, those people have a lifespan that could easily be another 40 to 60 years
- And if 30% of men and roughly 20% of women from 20 to 44 are walking around with high blood pressure, the longer you don’t know what it is and the longer it compounds, can create staggering amounts of issues

## The consequences of high blood pressure on cardiovascular health, brain health, kidneys, and more [27:45]

***What are those consequences of high blood pressure? How does it relate to cardiovascular disease? How does it relate to everything else?***

- We’ve known about a lot of these consequences since the 1960s from literally the first iteration of the [Framingham Heart Study](https://en.wikipedia.org/wiki/Framingham_Heart_Study)
  - back then, we were using a higher definition—defining hypertension as greater than 140 over 90
  - But even reducing people to just below that from above that was associated with effectively a 35 to 40% reduction in stroke, about a 50% reduction in cardiovascular disease (64% of that in heart failure, 15 to 25% in myocardial infarction)
- More recent [meta-analyses](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(02)11911-8/fulltext) suggest that if you consider people ages about 40 to 70, each 20 millimeter of mercury increase in systolic blood pressure and each 10 millimeter of mercury increase in diastolic blood pressure are associated with a doubling in the risk of death from stroke, heart disease or other vascular disease
  - If your blood pressure is 140 over 90 as opposed to 120 over 80, you’ve doubled your risk of death
    - Not incidents, death from stroke, heart disease or vascular disease
- You can also then think about this on a yearly basis using the data in the SPRINT trial where you’re talking about 25 to 30% year-on-year reduction in relative risk
  - And that includes of course the benefits we saw in all cause mortality

[2021 STEP trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2111437)

- This study basically repeated the SPRINT trial, but in a different patient population
- This was in Chinese adults aged 60 to 80
- About 8,500 patients randomized to a slightly higher window
- So this was a systolic blood pressure target of 110 to 130 for the intensive treatment group
- And between 130 to 150 in the standard treatment group
- Coming in, these people had a mean baseline of 146 over about 83
- The primary outcome, which was similar to SPRINT, found 26% reduction in cardiovascular outcomes on a relative basis, and the death from cardiovascular disease specifically was a 28% reduction in risk.
- The absolute risk reductions were also comparable, about 1% per year

> “All of this is to say the evidence is pretty consistent that the consequences of high blood pressure, if nothing else, just on cardiovascular disease and cerebral vascular disease, are significant, and therefore if you’re serious about the business of living longer, you definitely want to make sure your blood pressure is being managed.” —Peter Attia

**Effect of high blood pressure on the brain and other organs [31:45]**

Overall:

- The brain is susceptible to high blood pressure
- In fact, there are very few exceptions of things that are good for the heart that are not good for the brain and vice versa
- The way to think about high blood pressure is, because it’s a mechanical force, anything with small vessels is going to be troubled by it.
- There are three organs that are most susceptible to high blood pressure
  - Heart
  - Brain
  - kidney

**Kidney**

- There’s a very high incidence and prevalence of end stage renal disease in patients with hypertension
- The kidneys are tiny little things—they weigh one to 2% of your total body weight, and yet they’re receiving 20 to 25% of your cardiac output with each pump of the heart
- So think about what must be true of the vascular network of that organ to accommodate such profusion, and therefore it’s highly susceptible to elevated pressures there
- People with hypertension have [faster rates of decline](https://pubmed.ncbi.nlm.nih.gov/16481878/) in their renal perfusion than age adjusted people with normal blood pressure, and this results in a stark decrease in glomerular filtration rate
  - Diabetes is also an enormous insult to the kidneys, though for a different reason which we’re not going to get into today
- Then when you consider the fact that oftentimes high blood pressure and elevated glucose go hand in hand, in fact they are two of the five metrics that define the metabolic syndrome, and therefore are proxies for insulin resistance, you realize that
- It’s an epidemic that’s not getting enough attention which is inappropriately or overly aggressive decline in glomerular filtration rate as a result of the double whammy of high glucose, high blood pressure
- In Peter’s patients, he’s very aggressive about checking a biomarker called cystatin C, which is far superior to creatinine as a way to keep tabs on their kidney function
  - It’s very common for us to see people that have “normal kidney function,” but it’s far too low for their age
  - So they might have a GFR of 60, so 60 milliliters per minute of glomerular filtration, which technically gets considered normal
  - It’s not normal till it’s below 60
  - We think normal is 100 for someone who’s 50
  - And 60 might be normal if you’re 75 years old, but we don’t think it’s normal for someone who’s 50 or 55.
  - A lot of times that immediately hints to us that they’ve got hypertension even before you put a cuff on them to just see those numbers

**Dementia**

- There’s another trial that’s similar to the SPRINT trial called the [SPRINT-MIND trial](https://jamanetwork.com/journals/jama/fullarticle/2723256)
  - Basically a subset of the SPRINT trial, but it’s looking at the impact of intensive blood pressure lowering in the state of dementia
  - it’s the same cohort, a little over 9,000 subjects, the absolute risk reduction of dementia was 0.6%. That’s pretty significant
  - A relative risk reduction about 16%, which again, this is consistent with the observational data and the other long-term prospective studies we’ve seen
  - So there’s really no data that speak in the opposite direction

> “If you care about your brain, if you care about your heart and if you care about your kidneys, you need low blood pressure. I think we can say that as confidently as we can say almost anything in medicine.” —Peter Attia

## Low blood pressure: symptoms and consequences [35:30]

***What do we know about the consequences of having low blood pressure?***

- Peter once [fainted and hit his head](https://www.instagram.com/p/CWOFMZfgCF_/) and attributes it to low blood pressure
- There is no numerical diagnosis for low blood pressure
- If you truly measured accurately, a blood pressure below 90 over 60 would probably be “low”
- But the truth of it is… low blood pressure is defined by *symptoms* more than it is by numbers
- There are people who walk around with a blood pressure of 100 over 70, and they never experience orthostasis
- Yet there are other people that if you medicated them to that level, they’d be syncopal all day long

**More about managing blood pressure and accounting for other variables**

- Again, this speaks to the “art” of managing blood pressure
- One needs to be careful when using medications for blood pressure, especially when other variables are changing
- For instance, if Peter’s patient is currently on blood pressure medication, but then they lose weight, their blood pressure’s going to start to come down
- There has to be a really clear manner in which you safely begin to reduce the dose of their blood pressure medication, or else you could indeed induce some of the symptoms such as dizziness,  lightheadedness, fainting, lack of concentration, blurred vision, etc.
- These things tend to be far more extreme, but you want to be mindful of everything

*NOTE*: A single hypotensive measurement isn’t usually problematic as long as none of the following symptoms are present

- Dizziness or lightheadedness
- Nausea
- Fainting (syncope)
- Dehydration and unusual thirst
- Lack of concentration
- Blurred vision
- Cold, clammy, pale skin
- Rapid, shallow breathing
- Fatigue

## How to properly measure blood pressure [37:45]

***Are there clear signs of high blood pressure?***

- There are no symptoms generally
- High blood pressure is often referred to as a silent killer because it really doesn’t have a warning sign.
- The reality of it is, unless you’re accurately measuring your blood pressure, there’s truly no way to know if you have hypertension.

**Properly measuring blood pressure**

- A doctor’s office is typically not optimized for the proper blood pressure testing
- For instance, many people have just climbed stairs to get to the office, or the person checking BP doesn’t put my arm in the right position
- So, to be accurate, people are going to have to do this at home and take charge of it themselves

*Tips and advice for getting an accurate reading:*

![](https://peterattiamd.com/wp-content/uploads/2023/06/f5-factors-affecting-BP-reading-ama48-1024x559.png)

**Figure 5.** Factors affecting blood pressure readings. Credit: [adctoday.com](https://www.adctoday.com/learning-center/about-sphygmomanometers/how-take-blood-pressure)

- Ensure the cuff is the right size—it’s very important to make sure the cuff fits your arm correctly
- You want to make sure the cuff fits over your skin directly—Don’t be lazy and check your blood pressure over your clothing
- Make sure your back is supported—the variance here can be somewhere between five and 10 millimeters of mercury if your back and feet are not supported (feet should be on the ground and not dangling)
- You don’t want your legs to be crossed—when you cross your legs, you can see anywhere from a five to eight millimeter per mercury increase
- Take a five minute rest prior to reading—at a minimum, need to wait three minutes (ideally 5 min), and that can easily account for 10 to 20 millimeters of mercury
- Avoid talking—Just talking during or right before your blood pressure can easily be 10 to 15 points
- Being in pain can have a significant impact on this—it could be anywhere from 10 to 30 millimeters per mercury
- Having a full bladder can raise your heart rate and raise your blood pressure by 10 to 15 points
- Arm positioning:
  - For every inch that your arm is **below** your heart, you’ll see about an average of nearly two millimeters of mercury per inch
  - Similarly, it’s about two millimeters of mercury per inch for every inch your arm is **above** your heart

> “All of these things matter, which is why I think it’s very important for people to be their own blood pressure checker, because it’s very difficult to have all of these things optimized in the doctor’s office.” —Peter Attia

**Measuring with a manual cuff**

**Video:** [How to measure blood pressure using a manual monitor](https://www.youtube.com/watch?v=lpvyCGPsVDU)

- Let’s just assume your blood pressure is 120 over 80, for this example
- You’ll need the manual cuff as well as a stethoscope
- So you’re putting a cuff over on your arm and you have a stethoscope over the brachial artery, which is a little bit on the medial side of the antecubital fossa
- More about the brachial artery:
  - if you think about where your arm bends, that little area is called the antecubital fossa
  - if you have your palm up and you put your hand in that little area and move in towards your body, so to medial, you’ll feel a pulse—that’s your brachial artery which is where you want the stethoscope sitting
- You want the cuff about an inch above the crease in your arm, and while the stethoscope is in place, you insufflate the cuff
- And you insufflate until you feel the loss of that pulse—presumably that’s approximately your systolic level
- You continue to inflate the cuff to about 30 millimeters of mercury beyond that—so let’s just assume that’s about 120, you take it up to now 150
- Now you start to slowly release the valve of the cuff…and you’re going to hear nothing, you’re going to hear nothing, you’re going to hear nothing, and then you’re going to hear your first tapping/thudding sound, and that is the systolic reading
- That is the first bit of blood that is now going through the artery, because you’ve now lowered the cuff pressure just enough so that blood can travel through
- Let’s just say in this hypothetical patient, that occurs at 117
- And that would make sense, because you approximately heard it vanish at about 120
- So that becomes your **systolic**
- As you slowly continue to release pressure, you’re going to hear these sounds change—they kind of change from a murmur into more of a swooshing sound (you likey can “feel” this change happening)
- You’ll keep kind of going down this line until at some point the sound becomes a little muffled, and then it decreases and stops
- And when it stops, that’s your **diastolic** reading, because by definition now the pressure is below that minimum pressure in the artery where the artery is feeling the expansion of the blood during the total relaxation phase of the heart
- Then you note that number—that number might be 75—and you’ll see that on the cuff on the manometer

**Measuring with automated cuffs**

**Video**: [British Heart Foundation – How to measure your own blood pressure](https://www.youtube.com/watch?v=GSNZVaW1Wg4)

- Automated cuffs have their own algorithms
- On average, they’re pretty good, but the gold standard of course is measuring manually
- But if you do measure with an automated cuff, there’s lots of good ones out there, but I would just say make sure you’re doing everything correctly

**Accuracy of manual vs. automated readings**

- Peter finds the manual readings to be more accurate
- Automated readings can be easily 10 to 15 millimeters of mercury off for Peter, personally (especially systolically)
- The automated cuffs tend to overestimate BP
- The automated cuffs are not directly measuring systole and diastole
- They tend to be measuring mean arterial pressure, and then using some algorithm to try to impute the others
- All that said, Peter is okay with patients using automated, especially at first, if the manual way it a bit intimidating

For more on how the two modalities of measurement actually work, these videos are recommended:

- [Oscillometric blood pressure measurement](https://www.youtube.com/watch?v=Y-NvovSaWTc)
- [Sound: heart sounds, Korotkov sounds and vascular doppler](https://www.youtube.com/watch?v=rCIOTkeopHs)

## Daily variance in blood pressure and the transient changes in blood pressure during exercise [48:00]

***What do we know about the blood pressure variation throughout the day?***

*Nighttime*

- The most important observation is that blood pressure should really be dropping to somewhere between 10 and 20% at night relative to daytime
- And that is just based on the fact that you’re horizontal, so the heart shouldn’t have to work as hard to get blood to your head
- We should also see a **reduction** in sympathetic tone overnight, and an **increase** in parasympathetic or vagal tone
- When people do continuous blood pressure monitoring tests, which are pretty cumbersome, this is one thing you are looking for—the 10-20% drop in BP

*Stress*

- Transient stress can also raise blood pressure significantly
- Peter personally notices his blood pressure is routinely over 140 systolically, if he’s even just slightly irritable which really speaks to the old adage that “[stress can kill you](https://peterattiamd.com/robertsapolsky/)”
- Hypercortisolemia, if left unchecked, is harmful just like hypertension
- So if you’re constantly in a sympathetic tone, there’s both mechanical and chemical reasons why that’s problematic

**BP and exercise [49:45]**

*What do we know about blood pressure and exercise? Does it go up? Why does it go up?*

*Is that something they even need to worry about, or is that just natural?*

- An increase in systolic blood pressure during exercise is completely normal
- What we’re really looking for is a rise in diastolic pressure
- The normal physiology should be: Systole goes up, diastole stays about the same (sometimes it even goes down)

![](https://peterattiamd.com/wp-content/uploads/2023/06/f6-ama48-.jpg)

**Figure 6.** Illustration depicting the normotensive and hypertensive response to dynamic physical exercise. Credit: [Schultz et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4315351/)

- The reason for that is that the vasodilation of the arterials, which is there to provide more oxygen to muscles during exercise, actually causes a reduction in systemic vascular resistance
- Peter has actually checked his blood pressure during exercise, but it could easily be 180 to 200 millimeters of mercury —
  - “It would be very interesting for me to know what my peak blood pressure is doing a heavy deadlift or squat”
  - Peter suspects it gets insanely high
  - In patients that have very dilated aortas, we would say, “hey, maybe doing very heavy valsalva type maneuvers might not be in your best interest”
    - Valsalva is just anytime you’re increasing intra abdominal pressure
    - That type of pressure is associated with pretty significant increase in blood pressure

## Primary hypertension vs. secondary hypertension: what to look for [51:45]

**Primary hypertension vs. secondary hypertension**

- [Secondary hypertension](https://www.aafp.org/pubs/afp/issues/2017/1001/p453.html) is high blood pressure that’s caused by a correctable other medical condition
- About 10% of people diagnosed with hypertension actually have a secondary cause, a driver
- That’s why it’s important to make sure that if somebody shows up with high blood pressure, you don’t automatically assume that it’s what we would just call primary or what used to be called “essential hypertension”
- Some **clues** to consider that somebody might have secondary hypertension
  - If a person’s already being treated for high blood pressure but it’s not responding to medications, we call that medication resistance
  - Also, if they no longer respond to medications that they previously responded to
  - If their blood pressure’s incredibly high, north of 180 millimeters of mercury systolically
  - If the onset occurs really suddenly or increases really suddenly, again, that’s all cause for alarm.
  - If it’s high and you’re really young, i.e., 30 year old person that otherwise have no risk factors such as family history for high blood pressure, they’re not obese, and yet they show up with high blood pressure, all of these things make you start to think of something else going on

**Extreme example about a friend with secondary hypertension**

- Peter’s friend mentioned his blood pressure was really high
- He was a really serious athlete
- He was waking up every morning with his blood pressure’s through the roof
- He would exercise, and it would go down a bit, but it was generally pretty high
- His doctors were putting him on all sorts of medications but it wasn’t really having an effect
- Peter says that every medical student will know the story of what’s called the pheochromocytoma, which is a tumor of the adrenal glands that secretes catecholamines
- Peter suggested to his friend to have his doctor check his urine for the metabolites of epinephrine and norepinephrine
- He goes and asks his doctor and his doctor says, “No, that’s a dumb test. We’re not going to do that.”
- He had surgery six months before that, and they had done an MRI of his chest, and I said, “It’s possible that that MRI also captured your adrenal glands, which sit on top of the kidneys, which can often be seen in a chest MRI.”
- And sure enough, there was an adrenal nodule on that MRI, but it didn’t get called by the radiologist
- So Peter said, “Take this to your doctor and say, look, you’ve got an adrenal nodule and high blood pressure. They really need to check for these metabolites.”
- The doctor still didn’t want to do it so Peter made his friend get a new doctor
- To make a long story short, he ended up having a pheochromocytoma, he had surgery and they removed that adrenal gland, and his blood pressure completely normalized
- “*​​Again, that’s pretty uncommon. It’s an extreme example of what you don’t want to miss*.”

***What are some other things you don’t want to miss?***

- Kidney disease
- Stenosis of the renal artery
- Thyroid conditions
- Hyperaldosteronism, which can be idiopathic, meaning it can be caused by steroids that you’re taking
  - So people that are on continuous doses of corticosteroids.
  - But it can also be caused by the adrenal gland itself undergoing hypoplasia

“*There are a lot of secondary causes of hypertension, and when you consider that in total they amount to probably 10% of cases of hypertension, and when you consider how many people have hypertension, it’s important that these things be run to ground before we just immediately assume that somebody has primary hypertension, which again is just code speak for, we don’t really know what the cause is*.”

**Family history [56:15]**

- Peter confirms that family history of high blood pressure is important to know
- Peter says that both his parents have high BP which is part of the reason he is keeping a close watch on his own BP
- Peter says he won’t be surprised if his genes eventually overcome his lifestyle and he has to go on medication at some point

> “My goal in checking my blood pressure so frequently is to make sure that I don’t spend a couple of years, or even a year, not recognizing if that transition has taken place.” —Peter Attia

## Lifestyle factors impacting blood pressure: weight loss, exercise, and sodium [57:45]

**Big impact of lifestyle**

- There’s a really big opportunity to lower blood pressure with lifestyle/behavior
- Lifestyle is a far greater hammer on blood pressure than it is on lipids
  - Lifestyle is not a great hammer for lipids because to get your apoB to the levels where it’s no longer an issue is very difficult to do without a very extreme diet that is so extreme that it comes with a whole bunch of other problems with it
    - E.g., Profound fat reduction and calorie restriction will lower cholesterol levels dramatically, but again, it comes with so many other problems that it’s simply not worth it
  - But with blood pressure, that’s not the case
    - The benefits of weight loss are dramatic
    - The benefits of exercise, reducing insulin resistance, avoiding type two diabetes and getting good sleep are pretty significant
    - In addition, the electrolyte management thing is interesting, albeit controversial

**The impact of weight loss on blood pressure**

*This* [*meta-analysis*](https://www.ahajournals.org/doi/10.1161/01.HYP.0000094221.86888.AE?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) *of RCTs studied the effect of weight loss on hypertension*

- For every kilo of weight loss, you’re going to see a reduction of 1.05 mm Hg systolic and a reduction of 0.92 mm Hg diastolic
- Weight loss is primarily going to be accomplished by reducing intake through i) calorie restriction (CR), ii) dietary restriction (DR), and iii) time-restriction (TR) or combinations thereof

**The impact of sodium and potassium blood pressure [1:00:15]**

*Sodium*

- The role of sodium on BP is a bit controversial
- It is safe to say that there is pretty significant heterogeneity in the population here—there probably are some people that are more sensitive to dietary sodium from a blood pressure perspective than others
- We [talked about this with Rick Johnson](https://peterattiamd.com/rickjohnson2/), who’s a nephrologist, and his take was:
  - Salt plays a role, but the effect of salt to raise blood pressure is blunted by drinking water with or before a salty meal
  - He points out that if you’re getting thirsty with a salty meal, it means you’ve already raised sodium, and you’re probably also getting a increase in blood pressure
  - It’s really about pairing water prior to a salty meal
- So salt sensitivity is sort of a quantitative trait in which an increase in oral sodium can disproportionately increase blood pressure

The question then becomes — *Who are the patients that are probably more sensitive to sodium?*

- The [data](https://www.bmj.com/content/346/bmj.f1325) might suggest we see this more in—
  - African-Americans
  - Older people
  - People who already have higher blood pressure
  - And in people who have metabolic syndrome, diabetes or chronic kidney disease
- We probably see it less in people who are not otherwise in those categories

*Restricting sodium*

- You can be empirical about this and experiment with “what happens if I kind of reduce my sodium intake? What bearing is that having?”
- Peter cautions that going to very extreme levels of sodium restriction, even if it might improve blood pressure, seems to be associated with worse overall health outcomes.
- Some advocate reducing sodium to as little as 1500 milligrams per day
- Keep in mind, the average American is somewhere between 3.5-4.5 grams of sodium per day so to suggest we’re going to reduce that to as little as 1.5 grams per day is pretty significant
- Now, that will very likely reduce systolic blood pressure by 5-6 millimeters of mercury in somebody who already has hypertension, but according to the most recent [meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8169157/) from the Institute of Medicine, that also increased all cause mortality

**Potassium [1:02:40]**

There’s some [evidence](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/414693) that increasing dietary potassium by eating potassium rich foods, bananas, potatoes, etc. (not through supplements) can lower blood pressure based on the relationship that we see between potassium and an aldosterone in the kidney

**Impact of exercise on blood pressure [1:02:55]**

*Aerobic exercise*

- If you look at a [meta-analysis](https://www.ahajournals.org/doi/10.1161/JAHA.112.004473?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) of RCTs that were at least four weeks in duration found that endurance exercise was very effective in patients with hypertension
- They’re looking at reductions of systolic blood pressure in as little as four weeks of aerobic training, reducing it by as much as eight millimeters per mercury, and diastolic lowered by at least five millimeters per mercury
- As far as duration and intensity goes, the takeaway of this meta-analysis was that at least 90 to 150 minutes a week at somewhere between 65 and 75% of your maximum heart rate was the sweet spot
- Note that this is right in the zone of what we would call zone 2
  - For most people, zone 2 is about 75% of their maximum heart rate, and Peter advocates for at least three hours a week of that, which would be 180 minutes
- So, if you’re getting your zone 2 in at three hours per week at roughly 75% of your maximum heart rate, you’re already capturing the benefits of much of the exercise on BP

*Dynamic resistance training*

- As far as dynamic resistance training, this is something that isn’t entirely intuitive
- While resistance training can transiently increase blood pressure, it actually reduces blood pressure slightly as well
- It reduces it not nearly as much as aerobic training, but it reduces it by about two millimeters of mercury on systolic, about three millimeters of mercury on diastolic
- And this is doing 90 to 150 minutes a week at somewhere between 50% and 100% percent of one rep max—i.e., anywhere from modest weights up to very heavy weights

*Isometric resistance training (i.e., not using weights)*

- This type of exercise showed even a greater [reduction in systolic blood pressure](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6727950/) than dynamic resistance training—about six millimeters of mercury, and diastolic of about three millimeters of mercury

## Impact of insulin resistance and type 2 diabetes on blood pressure [1:04:45]

***Why are insulin resistance and type 2 diabetes increasing blood pressure?***

- Insulin resistance does a number of things, but among them is, it [reduces the bioavailability of nitric oxide](https://www.ahajournals.org/doi/10.1161/CIRCULATIONAHA.105.563213?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed)
- And nitric oxide of course acts very locally to increase vasodilation
- Therefore with less nitric oxide, we have less vasodilation
- One of the ways that this happens, and we see this also by the way in impaired kidney function, is there’s an inhibition of one of the important cofactors in nitric oxide synthase, or one of the important variables that allows nitric oxide synthase to make nitric oxide
- So there are actually biomarkers you can measure, like one’s called SDMA and one is called ADMA, and these are typically things that we see elevated in people with high homocystine or people with impaired renal function

It’s helpful to think about these as kind of a cascade of things

- Insulin resistance, we proxy by metabolic syndrome
- Two of the five factors of metabolic syndrome are elevated glucose and elevated waist circumference or obesity
- So type 2 diabetes then in some ways just becomes this triple whammy where you have the first insult being the high glucose load, which then has the microvascular damage to all of the organs of interest, heart, brain, kidney
- You then have the blood pressure load or the blood pressure damage that comes from that
- And then of course you have the apoB burden that comes from type two diabetes
- Type 2 diabetes and insulin resistance are associated with hypertriglyceridemia, which is then associated with an increase in apoB, as you now need more low density lipoprotein particles to traffic, not just the cholesterol ester, but now the triglycerides as well

## How sleep impacts blood pressure [1:06:45]

Both sleep deprivation and insomnia will also [drive](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7127991/) hypertension

- For instance, a really lousy night’s sleep, all things equal, Peter’s blood pressure is definitely higher (just as is his blood sugar)
- Anybody who’s ever worn a CGM will tell you that if they have a horrible night of sleep, their glucose tolerance goes out the window, and so too does your blood pressure response
- So if you look at either very long or very short sleep, you’re going to see in all cases an increase in hypertension
- This can be as much as a 40% increase in the risk of hypertension if you’re sleeping less than five hours a night, or more than 10 hours per night
- You could argue of course that sleeping more than 10 hours a night is a proxy for other things that are going on, be it either chronic disease or heavily fragmented sleep.
- You want to make sure you get as far as you can on these
- It could easily be that half the people who have hypertension could manage it without the use of pharmacologic options

## Pharmacologic options for managing blood pressure [1:08:00]

**Today we have 4 first line drug categories for hypertension**:

- 1) Thiazide diuretics
- 2) Calcium channel blockers
- 3) Angiotensin converting enzyme inhibitors ([ACE inhibitors](https://pubmed.ncbi.nlm.nih.gov/18843651/))
- 4) Angiotensin II receptor blockers ([ARBs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6669255/))

For primary hypertension, all first line agents are pretty much good for about 12 to 15 millimeters reduction of systolic blood pressure, and about nine to 11 millimeters reduction in diastolic blood pressure

**ACE inhibitors**

- The blood pressure lowering effects of ACE inhibitors are pretty high at about [12.5/9.5 mmHg](https://academic.oup.com/ajh/article/18/7/935/221053)
- They are typically started at about half the recommended maximum dose—Never start somebody at the maximum dose of these thing (you don’t want to overshoot these things as you can cause some damage)

**ARBs**

- The ARBs are right there [on par](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6669255/) with the ACE inhibitors
- Consensus view is that basically across the board, the ARBs are probably slightly better drugs than the ACE inhibitors
- Tn every manner that we compare them in terms of efficacy and side effects, the ARB is as good if not slightly better than the ACE inhibitor
  - The ACE inhibitors have been around longer so they’re cheaper
  - But if ACE inhibitors are causing symptoms such as a cough, which is probably one of the more common symptoms, you want to know that you have other agents there as well

**Thiazide diuretics and calcium channel blockers**

- These are also [highly efficacious](https://www.ahajournals.org/doi/10.1161/HYPERTENSIONAHA.109.129171) — easily in the 15/10 mmHg impact on blood pressure,
- But they do tend to come with more side effects
- Peter typically does not like to rely on those as first line agents, and instead may use them as add-on agents if he’s maxed out an ACE inhibitor or an ARB and we still need more reduction

**Lifestyle vs. drugs**

- These blood pressure lowering medications by themselves are larger than any single lifestyle factor
- However, when you consider the sum total of all lifestyle factors, it can be at least on par with what we see pharmacologically

***Are there other factors that would make one medication better than another?***

- Somebody who’s got heart failure or reduced ejection fraction, you would want to avoid a calcium channel blocker, because calcium channels play an important role in contractility of the heart
  - So to give a calcium channel blocker to reduce blood pressure would be potentially problematic at reducing cardiac output as well
- The dogma says that anybody with diabetes should be on an ACE inhibitor over an ARB if you’re going down that path
  - When Peter looked at these data, he didn’t see a strong enough case for that
  - That said, the textbook answer is that for type 2 diabetes and chronic kidney disease, ACE inhibitors might offer some benefit, but Peter thinks that both of these are probably reasonable
- Be careful about somebody with renal artery stenosis
  - In the case of renal artery stenosis, you wouldn’t want to be using either of those
- People with hyperlipidemia, type 2 diabetes, or gout should avoid the diuretics because they can actually increase somewhat insulin resistance
- For ACE inhibitors and ARBs, avoid certainly in pregnancy or in somebody with a history of angioedema
- It would appear that in African-Americans, thiazide diuretics or calcium channel blockers might actually be more effective than ACE inhibitors or ARBs (or even beta blockers) when it comes to reducing cardiovascular events
- We’re not talking much about beta blockers, and certainly not about alpha blockers, but it’s not that these other categories aren’t used, but they certainly would not be considered first line today

> “[Blood pressure management] is such an important part of the longevity playbook. And it’s not sexy. It’s not like taking rapamycin or taking some little drug that’s going to whack your senescence cells or do anything like that. It’s just bread and butter primary care medicine, but it’s so needle moving.” —Peter Attia

§

## Selected Links / Related Material

**Episode of The Drive where Peter discusses his historical DEXA scan results**: [#242 – AMA #44: Peter’s historical changes in body composition with his evolving dietary, fasting, and training protocols](https://peterattiamd.com/ama44/) | Peter Attia (peterattiamd.com) [2:30]

**Episode of The Drive with Ethan Weiss where they discussed blood pressure**: [#247 ‒ Preventing cardiovascular disease: the latest in diagnostic imaging, blood pressure, metabolic health, and more | Ethan Weiss, M.D.](https://peterattiamd.com/ethanweiss2/) | Peter Attia (peterattiamd.com) [3:45, 14:30]

**SPRINT trial—study looking at the benefit of aggressive blood pressure control**: [A Randomized Trial of Intensive versus Standard Blood-Pressure Control](https://www.nejm.org/doi/10.1056/NEJMoa1511939) (The SPRINT Research Group, 2015) [11:15, 29:15]

**Study which revealed the consequences of high blood pressure**: [Framingham Heart Study](https://en.wikipedia.org/wiki/Framingham_Heart_Study) | (wikipedia.org) [28:15]

**Meta-analysis that found that for every 20 millimeter of mercury increase in systolic blood pressure and every 10 millimeter of mercury increase in diastolic blood pressure was associated with a doubling in the risk of death from stroke, heart disease or other vascular diseaseMore recent meta-analysis**: [Age-specific relevance of usual blood pressure to vascular mortality: a meta-analysis of individual data for one million adults in 61 prospective studies](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(02)11911-8/fulltext) | *The Lancet* (Prospective Studies Collaboration, 2002) [28:30]

**2021 STEP trial that repeated the SPRINT trial but in a Chinese population**: [Trial of Intensive Blood-Pressure Control in Older Patients with Hypertension](https://www.nejm.org/doi/full/10.1056/NEJMoa2111437) (Zhang et al., 2021) [29:30]

**SPRINT-MIND—Study looking at the impact of intensive blood pressure lowering in the state of dementia**: [Effect of Intensive vs Standard Blood Pressure Control on Probable Dementia](https://jamanetwork.com/journals/jama/fullarticle/2723256) | *JAMA* (The SPRINT MIND Investigators for the SPRINT Research Group, 2019) [35:00]

**Peter’s instagram post when he fainted from low blood pressure and hit his head**: [@peterattiamd](https://www.instagram.com/p/CWOFMZfgCF_/) | 11/13/2021 [36:00]

**YouTube videos explaining how to measure blood pressure at home**: [39:45]

- *Measuring with a manual cuff:* [How to measure blood pressure using a manual monitor](https://www.youtube.com/watch?v=lpvyCGPsVDU) | Drugs.com (youtube.com)
- *Measuring with automated cuffs:* [British Heart Foundation – How to measure your own blood pressure](https://www.youtube.com/watch?v=GSNZVaW1Wg4) | British Heart Foundation (youtube.com)

**For more on how the two modalities of measurement actually work, these videos are recommended**:

- [Oscillometric blood pressure measurement](https://www.youtube.com/watch?v=Y-NvovSaWTc) | BPM biosignals (youtube.com)
- [Sound: heart sounds, Korotkov sounds and vascular doppler](https://www.youtube.com/watch?v=rCIOTkeopHs) | BPM biosignals (youtube.com)

**Episodes of The Drive where Layne Norton explains how blood pressure is going to increase with exercise**: [49:45]

- [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training](https://peterattiamd.com/laynenorton/) | Peter Attia (peterattiamd.com)
- [#205 – Energy balance, nutrition, & building muscle | Layne Norton, Ph.D. (Pt.2)](https://peterattiamd.com/laynenorton2/) | Peter Attia (peterattiamd.com)

**Meta-analysis which looked at the effect of weight loss on hypertension**: [Influence of Weight Reduction on Blood Pressure](https://www.ahajournals.org/doi/10.1161/01.HYP.0000094221.86888.AE?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) (Neter et al., 2003) [59:30]

**Episode of The Drive with Rick Johnson where he discussed salt intake and blood pressure**: [#194 – How fructose drives metabolic disease | Rick Johnson, M.D.](https://peterattiamd.com/rickjohnson2/) | Peter Attia (peterattiamd.com) [1:01:15]

**Data suggesting that race plays a role in who is more sensitive to sodium**: [Effect of longer term modest salt reduction on blood pressure: Cochrane systematic review and meta-analysis of randomised trials](https://www.bmj.com/content/346/bmj.f1325) (He et al., 2013) [1:01:15]

**A meta-analysis of RCTs found that endurance exercise was very effective in patients with hypertension**: [Exercise Training for Blood Pressure: A Systematic Review and Meta‐analysis](https://www.ahajournals.org/doi/10.1161/JAHA.112.004473?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) (Cornelissen and Smart, 2013) [1:02:45]

**Insulin resistance reduces the bioavailability of nitric oxide therefore increasing blood pressure**: [Reciprocal Relationships Between Insulin Resistance and Endothelial Dysfunction](https://www.ahajournals.org/doi/10.1161/CIRCULATIONAHA.105.563213?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) (Kim et al., 2006) [1:05:00]

**Peter’s book**: [OUTLIVE THE SCIENCE & ART OF LONGEVITY](https://peterattiamd.com/outlive/) by Peter Attia | (peterattiamd.com) [1:14:45]

§

## People Mentioned

- [Ethan Weiss](https://www.ucsfhealth.org/providers/dr-ethan-weiss) [3:45, 14:30]
- [Layne Norton](https://twitter.com/BioLayne) [49:45]
- [Rick Johnson](https://som.cuanschutz.edu/Profiles/Faculty/Profile/9426) [1:01:15]

§