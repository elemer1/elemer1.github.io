# #140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications

**Source:** [https://peterattiamd.com/geraldshulman/](https://peterattiamd.com/geraldshulman/)

---

##### Check out more content on this subject

- - *(December 7, 2020)* [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance](/geraldshulman/)
  - *(February 15, 2021)* [Podcast Follow-up — AMA #20: Simplifying the complexities of insulin resistance](/ama20/)

Gerald Shulman is a Professor of Medicine, Cellular & Molecular Physiology, and the Director of the Diabetes Research Center at Yale. His pioneering work on the use of advanced technologies to analyze metabolic flux within cells has greatly contributed to the understanding of insulin resistance and type 2 diabetes. In this episode, Gerald clarifies what insulin resistance means as it relates to the muscle and the liver, and the evolutionary reason for its existence. He goes into depth on mechanisms that lead to and resolve insulin resistance, like the role of diet, exercise, and pharmacological agents. As a bonus, Gerald concludes with insights into Metformin’s mechanism of action and its suitability as a longevity agent.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/geraldshulman/the_Drive_public.png)

Play

#140 - Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications

#140 - Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications

1x15s30s

0:002:08:31

## We discuss:

- Gerald’s background and interest in metabolism and insulin resistance (4:30);
- Insulin resistance as a root cause of chronic disease (8:30);
- How Gerald uses NMR to see inside cells (12:00);
- Defining and diagnosing insulin resistance and type 2 diabetes (19:15);
- The role of lipids in insulin resistance (31:15);
- Confirmation of glucose transport as the root problem in lipid-induced insulin resistance (40:15);
- The role of exercise in protecting against insulin resistance and fatty liver (50:00);
- Insulin resistance in the liver (1:07:00);
- The evolutionary explanation for insulin resistance—an important tool for surviving starvation (1:17:15);
- The critical role of gluconeogenesis, and how it’s regulated by insulin (1:22:30);
- Inflammation and body fat as contributing factors to insulin resistance (1:32:15);
- Treatment approaches for fatty liver and insulin resistance, and an exciting new pharmacological approach (1:41:15);
- Metformin’s mechanism of action and its suitability as a longevity agent (1:58:15);
- More.

§

## Show Notes

## Gerald’s background and interest in metabolism and insulin resistance [4:30]

- Gerald has an MD and a PhD, did a residency in medicine at Duke, and a fellowship in endocrinology at Mass General Harvard
- Gerald’s father was a [diabetologist](https://www.md.com/specialties/diabetology#:~:text=Diabetologists%20are%20specialized%20endocrinologists%20who,of%20all%20forms%20of%20diabetes.), which exposed Gerald to metabolism and diabetes at a young age
- Although Gerald’s father wanted him to become a radiologist because of his physics background, Gerald ended up staying in the field of metabolism and endocrinology

*When did the idea of understanding what insulin resistance means and being able differentiate between some of these phenotypes of insulin resistance begin to intrigue Gerald?*

- Dating back to medical school, Gerald was interested in biochemistry and physiology
- While visiting a medical student at Vanderbilt in the 1970s, he became interested in in vivo metabolism – observing metabolism in living animals – particularly glucose and fatty acid turnover
- Since diabetes is a metabolic disease with significant consequences (blindness, renal disease, limb amputation, etc.), Gerald considers working in this area to be an easy transition for someone like himself who is already interested in metabolism
- Gerald’s interest in metabolism led him to [nuclear magnetic resonance spectroscopy](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance_spectroscopy) (NMR), which is a technology that can be used to observe metabolism within a cell
- At the time, this technology was being developed to look at yeast cells, but Gerald envisioned using it to look at human cells — “*In medical training, you go back to medical school, you learn how to become a good doctor, take care of patients. But then in your fellowship years, you’re back in the lab and I really wanted to get back to understand the metabolism by looking inside the cell.*”

> “I think [insulin resistance] is such an important metabolic disease, the most common metabolic disease, so if someone’s who’s interested in metabolism it’s a natural segue way.” —Gerald Shulman

## Insulin resistance as a root cause of chronic disease [8:30]

**How Peter describes the insulin resistance to people**:

- Peter sometimes describes insulin resistance to his patients as “the foundation upon which the major three chronic diseases sit”
- In addition to the direct complications of diabetes, Peter believes that the majority of diabetes-related mortality comes through amplification of **atherosclerotic disease, cancer, and dementia** – all of which are “a force multiplied in spades by type 2 diabetes”
- Peter also describes insulin resistance as a continuum starting with hyperinsulinemia and leading to impaired glucose disposal, [non-alcoholic fatty liver disease](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease) (NAFLD), [non-alcoholic steatohepatitis](https://en.wikipedia.org/wiki/Steatohepatitis) (NASH), and eventually type 2 diabetes

> “*That continuum makes up a plane upon which all chronic disease get worse. If we’re going to be serious about the business of delaying the onset of death, we have to be serious about the business of delaying the onset of chronic disease. If we want to do that, we must fix our metabolisms, and that’s my thesis.*” —Peter Attia

**Gerald’s thesis**:

- Gerald fully agrees with Peter’s “thesis” and refers to Jerry Reaven’s [1988](https://diabetes.diabetesjournals.org/content/37/12/1595) [Banting Lecture](https://en.wikipedia.org/wiki/Banting_Lectures), which was where he first generated interest in insulin resistance not only leading to diabetes but also hyperlipidemia, inflammation, elevated uric acid, [polycystic ovarian disease](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome), and cancer
- In regard to NAFLD, Gerald prefers to instead call it **metabolic-associated fatty liver disease**, or MAFLD—the most common cause of liver disease, liver inflammation, end stage liver disease and liver cancer.
- Gerald says that insulin resistance is driving the huge increase in **cancers** which are associated with obesity, such as breast, colon, pancreatic, and liver cancers and that there is strong preclinical evidence for this in animals
  - Insulin resistance is not necessarily causing the cancer, but is promoting its growth
- [Rachel Perry](https://medicine.yale.edu/profile/rachel_perry/), a former student of Gerald’s, has used insulin pumps in mouse models of breast and colon cancer to show that insulin accelerates tumor growth and insulin-sensitizing agents slow it
  - Rachel and Gerald co-authored a recent [review article](https://www.sciencedirect.com/science/article/abs/pii/S2405803319302614) describing the role of insulin in cancer growth
- Gerald says that insulin resistance is quite common—he estimates **one quarter to one half of the population** is affected by it *without* symptoms

## How Gerald uses NMR to see inside cells [12:00]

**Flux and molecular labeling**

- Simply measuring the concentration of a metabolite (i.e., glucose) does not provide any information about its metabolism or flux, or the rates at which it is produced versus consumed
- Traditionally, dating back to about 50 years, flux has been measured by “labeling” molecules, such as [radiolabeled isotopes](https://en.wikipedia.org/wiki/Isotopic_labeling)
- This approach is great for assessing flux in general, but does not give good indication of what is going on inside of cells

**Looking inside the cell**

- One approach used to look at cellular metabolism is [positron emission tomography](https://en.wikipedia.org/wiki/Positron_emission_tomography) (PET), which is commonly used to detect cancer tumors based on uptake of radioactive glucose
- The radioactive nature of this approach, however, is not appropriate for studying metabolism in healthy volunteers
- [Nuclear magnetic resonance spectroscopy](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance_spectroscopy) (NMR) is a safer alternative
- Basically, NMR can locate certain atoms based on the spin properties of their nuclei and how they align in a magnetic field
- The magnetic field produced by NMR excites these atoms, which release energy as they return to their normal state
- This release of energy enables detection of molecules containing these atoms
- Two atoms commonly used for NMR are phosphorous (pioneered by [George Rada](https://en.wikipedia.org/wiki/George_Radda) at Oxford) and the [carbon-13](https://en.wikipedia.org/wiki/Carbon-13) isotope
- Carbon-12, which comprises 99% of carbon in the body, is not visible to NMR, but carbon-13 is. Molecules like glucose can therefore be labeled with the carbon-13 isotope and tracked throughout the body with NMR
- Phosphorous in the body is visible to NMR and molecules like [phosphocreatine](https://en.wikipedia.org/wiki/Phosphocreatine) and [adenosine triphosphate](https://en.wikipedia.org/wiki/Adenosine_triphosphate) (ATP) can be detected without labeling
- In collaboration with [Doug Rothman](https://medicine.yale.edu/profile/douglas_rothman/) and others at Yale, Gerald developed a method to measure [glucose-6-phosphate](https://en.wikipedia.org/wiki/Glucose_6-phosphate) and intracellular glucose with NMR
- An example of how NMR can be used to answer questions related to metabolism and diabetes is observing how much of dietary carbohydrate ends up being stored as glycogen versus being oxidized into carbon dioxide (i.e., during energy production) or converted into lactate through [glycolysis](https://en.wikipedia.org/wiki/Glycolysis)

## Defining and diagnosing insulin resistance and type 2 diabetes [19:15]

**The difference between a diabetic and non-diabetic**

- Peter poses the scenario of a type 2 diabetic and a healthy individual each consuming a nighttime meal containing about 100-200 grams of carbohydrate
- The next morning, the healthy individual will have a blood glucose level around 100 mg/dL while the type 2 diabetic may be around 200 mg/dL, which is dramatic, but only represents about 5 grams of glucose in the blood (a small fraction of what was digested the night before)
- In a healthy individual, 80-90% of consumed glucose is stored as glycogen (in muscle and liver)
- In type 2 diabetics, there are two processes that have “gone awry,” leading to the elevated blood glucose
  - The first is that the liver produces more glucose through [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis), which involves conversion of metabolites like amino acids and lactate into glucose
  - The second is that less glucose is being taken up by muscle
  - So overall, production is up and clearance is down
  - Another contributing factor is that in some diabetics, insulin is low because of impaired production from pancreatic [beta cells](https://en.wikipedia.org/wiki/Beta_cell), which contributes to the lower amount of glucose uptake by muscle and other tissues

**Reversing insulin resistance**

- Gerald’s team conducted a study ([Petersen et al., 2012](https://www.pnas.org/content/109/21/8236.short)) showing that caloric restriction (1,200 kcal/d for 9 weeks) reversed insulin resistance in offspring of type 2 diabetics
- Gerald says that these results have been duplicated by many other investigators and that his colleague [Roy Taylor](https://en.wikipedia.org/wiki/Roy_Taylor_(scientist)) is doing it in a primary care clinic in the UK

> “*…  let’s understand insulin resistance, because if we can understand insulin resistance, then that’s going to be the best way to fix diabetes, type 2 diabetes, heart disease, we’re going to make a big impact there, fatty liver disease and slow down cancers.*” —Gerald Shulman

**When insulin resistance begins [23:00]**

- Gerald estimates up to half the people in the U.S. actually have insulin resistance, but are asymptomatic
- He has seen young, lean 20 year olds that have profound insulin resistance in the muscle, yet no problems in the liver
- The progression goes from insulin resistance in muscle, to fatty liver and insulin resistance in the liver, and then to type 2 diabetes

**Peter’s process of diagnosing insulin resistance**:

- Take a patient with a normal fasting glucose and normal fasting insulin
- Challenge them with an oral glycemic load (OGTT) and then measure insulin and glucose in 30-minute intervals
- Doing this often exposes a problem that seems most easily explained by the muscles’ inability to assimilate glycogen.
- In other words, if a person has a normal fasting insulin (e.g., 5) and their fasting glucose is normal (e.g., 90)
- But after challenging them with 75 to 100 grams of glucose, 60 minutes later their fasting glucose is 200 and their insulin is 70
- Peter calls that insulin resistance, and he can impute that something has broken down in the pathway that prevents their muscle from taking in glucose
- The question becomes: *Is the problem taking place at the GLUT4 transporter or one of the mechanisms—hexokinase or glycogen synthase?*

**Defining insulin resistance [26:30]**

- The three key insulin response organs are the muscle, fat, and the liver
- Insulin signals the muscle, liver, and fat to take up glucose
- Insulin also signals the liver to stop making glucose
- So an impaired ability to do any of those things in the presence of insulin is what we call insulin resistance
- And again, this is happening in roughly every other person here in the U.S. and in Western Europe, and it mostly goes unrecognized because it is asymptomatic and is not recognizable by a doctor using a simple fasting glucose value

*What causes resistance in the* ***muscle****?*

- Gerald considers young, lean, non-smoking individuals who are sedentary the ideal candidates to study for better understanding insulin resistance because it eliminates obesity and exercise as confounding factors
  - In these individuals, the ones who are most insulin resistant (e.g., based on a [oral glucose tolerance test](https://en.wikipedia.org/wiki/Glucose_tolerance_test) combined with measurement of insulin) have a 50% impairment in glycogen synthesis (determined with NMR)
  - These people are “resistant because they can’t get glucose into glycogen” — that’s the major pathway
  - So where’s the block in that pathway? ⇒ The block is in the **GLUT4 transport** (it’s not in glycogen synthase or hexokinase) which we know because [glucose 6-phosphate](https://en.wikipedia.org/wiki/Glucose_6-phosphate) and glucose are both reduced in the muscle cell, in vivo, in humans
  - To fix muscle insulin resistance, **your target is transport** (therefore drugs that target synthase or hexokinase are not good)

Gerald’s group conducted a series of studies on type 2 diabetics showing that during infusion of glucose and insulin ([hyperglycemic-hyperinsulinemic clamp](https://en.wikipedia.org/wiki/Glucose_clamp_technique)), concentrations of [glucose 6-phosphate](https://en.wikipedia.org/wiki/Glucose_6-phosphate) ([Rothman et al., 1992](https://www.jci.org/articles/view/115686)) and glucose ([Cline et al., 1999](https://www.nejm.org/doi/full/10.1056/NEJM199907223410404)) were lower in the muscle of the diabetics

- This is indication that the cause of impaired glycogen synthesis (and insulin resistance) is impairment of glucose transport into the cell (Note that NMR was necessary for the above studies leading to this discovery)
- Gerald likens this to a roadblock that causes traffic. In this case, impaired glucose transport into the cell is the roadblock and an increased concentration of circulating glucose is the resulting traffic

## The role of lipids in insulin resistance [31:00]

**Why Gerald started looking at lipids**

- The first abnormality found in the “healthy” 20 year-olds was the problem with the transport (as mentioned above)
- Then the question is, ***what’s wrong with the transport mechanism?***
  - This question led Gerald into the world of lipid
  - It’s well known that obesity is associated with insulin resistance—virtually every obese adult or child having some resistance
  - Gerald developed a method to measure fat inside the muscle cell and that was the **best predictor for insulin resistance in muscle** and a block in translocation

**Primer on how glucose enters a cell**

- As shown below in the simplified depiction of glucose uptake (Figure 1)…
- The first step is insulin binding to the insulin receptor, which triggers the receptor to [autophosphorylate](https://en.wikipedia.org/wiki/Autophosphorylation)
- This initiates a sequence of signaling through [insulin receptor substrate 1](https://en.wikipedia.org/wiki/IRS1) (IRS-1) and [phosphatidylinositol 3 kinase](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase) (PI3K), among other molecules
- Ultimately, this signalling results in [glucose transporter type 4](https://en.wikipedia.org/wiki/GLUT4) (GLUT4) molecules moving from inside the cell to the cell membrane which allows glucose to passively enter the cell

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-1-shulman-725x1024.png)

**Figure 1. Insulin-induced glucose uptake in cells.** Image credit: [journals.plos.org](https://journals.plos.org/plosone/article/figure?id=10.1371/journal.pone.0044701.g005)

- It is this process that Gerald and his team identified as the roadblock in insulin resistance and therefore the target of treatment
- The question is: *Why isn’t insulin causing this translocation of the GLUT4 transporter to the membrane to allow glucose to come into the cell?*

**Lipid-induced insulin resistance**

- Gerald says insulin resistance is most commonly “lipid-induced insulin resistance” — it accounts for the majority of his patients with type 2 diabetes
- Gerald uses a [proton NMR](https://en.wikipedia.org/wiki/Proton_nuclear_magnetic_resonance) to measure fat inside the cell (different from fat outside the cell)
  - Protons are the most abundant NMR visible nucleus in the body, and it’s mostly water we’re looking at
  - You’re basically getting the signal from protons and mostly protons are water and fat.
  - And so an imager gives you this three-dimensional reconstruction of proton density in water and fat, and that’s what gives you the images

⇒ Using steak as an analogy:

- There is fat both outside and inside of the muscle cells that comprise the steak. You can easily see the fat outside of the cells (marbling), but you cannot see the fat inside of the cells
- NMR enables differentiation of fat within the cell from that outside of the cell
- This enabled Gerald and his team to determine that **the amount of fat inside a muscle cell is the strongest predictor of impaired glucose transport into the cell**

Gerald’s team did a study showing infusion of triglycerides to cause insulin resistance in healthy individuals to an extent comparable to obesity type 2 diabetes ([Roden et al., 1996](https://www.jci.org/articles/view/118742)).

- (This was done in a more recent [Nowotny et al., 2013](https://diabetes.diabetesjournals.org/content/62/7/2240.short) as well)
- The lipid infusion also included [heparin](https://en.wikipedia.org/wiki/Heparin), which activates [lipoprotein lipase](https://en.wikipedia.org/wiki/Lipoprotein_lipase), thereby increasing circulation of free fatty acids by up to two-fold or about 1.5 mM and facilitating entry of fatty acids into muscle cells
- While this was not the first study to show that lipid infusion caused insulin resistance, it was **the first to show it’s due to this block in glycogen synthesis** (i.e., block in transport)
- “*It takes three to four hours before you see this, and then boom, you get very profound insulin resistance*.”
- Consistent with their previous work, they also found lower levels of glucose and [glucose 6-phosphate](https://en.wikipedia.org/wiki/Glucose_6-phosphate) inside cells suggesting it’s due to this same acquired block in transport

## Confirmation of glucose transport as the root problem in lipid-induced insulin resistance [40:15]

- This observed role of lipids in causing insulin resistance by impairing glucose transport represented a **paradigm change**.
- Prior to this, work pioneered by [Philip Randle](https://en.wikipedia.org/wiki/Philip_Randle) led to the belief that fatty acid accumulation would lead to an increase in [citrate](https://en.wikipedia.org/wiki/Citric_acid) from the [citric acid cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle), resulting in inhibition of glucose metabolism through the key glycolytic enzyme [phosphofructokinase](https://en.wikipedia.org/wiki/Phosphofructokinase) (a.k.a., the [Randle Cycle](https://en.wikipedia.org/wiki/Randle_cycle))
- Given that the Randle Cycle is focused on fat oxidation rather than glucose transport, it would be expected for glucose and glucose 6-phosphate concentrations in the cell to **increase**, but Gerald’s team consistently **found the opposite**–both concentrations to decrease, consistent with **glucose transport being the root of the problem rather than inhibition of glycolysis**

⇒ Gerald’s team conducted a series of studies ([Nowotny et al., 2013](https://diabetes.diabetesjournals.org/content/62/7/2240.short), [Szendroedi et al., 2014](https://www.pnas.org/content/111/26/9597.short))

- The studies ended up confirming in human muscle biopsies that lipid infusion impaires glucose transport and does so through the lipid intermediate [diacylglycerol](https://en.wikipedia.org/wiki/Diglyceride), which is basically a [triglyceride](https://en.wikipedia.org/wiki/Triglyceride) minus one of its three fatty acids
  - (consistent with this, diacylglycerol is sometimes referred to as a diglyceride, and triglycerides are sometimes referred to as triacylglycerol)
- In the same series of studies, lipid-induced impairment of insulin signaling coincided with decreased PI3K activation (PI3K activation was mentioned earlier by Peter as part of the insulin signaling cascade required from translocation of the glucose transporter GLUT4 to the cell membrane)

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-2-shulman-1024x439.png)

**Figure 2. Derivation from diacylglycerol (diglyceride) from a triglyceride molecule.** Image credit: [researchgate.net](https://www.researchgate.net/publication/322233018_Optimizing_Bio-diesel_Production_by_Transesterification_for_Internal_Combustion_Engines/figures?lo=1)

**A closer look at the involvement of diacylglycerol [42:30]**

- In the previous two studies just mentioned ([Nowotny et al., 2013](https://diabetes.diabetesjournals.org/content/62/7/2240.short), [Szendroedi et al., 2014](https://www.pnas.org/content/111/26/9597.short)), Gerald and his team found elevation of diacylglycerol to be associated with increased activation of the [theta isoform](https://en.wikipedia.org/wiki/PRKCQ) of [protein kinase C](https://en.wikipedia.org/wiki/Protein_kinase_C) (PKCθ)
- Since diacylglycerol is the direct byproduct of just a single fatty acid being removed from a triglyceride molecule, triglyceride levels are predictive of both diacylglycerol levels and insulin resistance, but in contrast to diacylglycerol, triglycerides are inert and do not directly cause insulin resistance
- According to Gerald, it’s the [hydroxyl group](https://en.wikipedia.org/wiki/Hydroxy_group) of the diacylglycerol molecule that interacts with PKC and causes trouble (see the “OH” that replaces the third fatty acid in the diacylglycerol molecule shown above in Figure 2)
- Diacylglycerol also activates the [epsilon isoform](https://en.wikipedia.org/wiki/PRKCE) of protein kinase C (PKCε)
- As shown in Figure 3 below, PKCε inhibits insulin signaling at the insulin receptor while PKCθ inhibits signaling somewhere between the receptor and [insulin receptor substrate 1](https://en.wikipedia.org/wiki/IRS1) (IRS-1), ultimately resulting in decreased PI3K activity and decreased translocation of the glucose transporter GLUT4 to the cell membrane
- Gerald and his team have done rigorous research in animals showing the involvement of fat metabolism and diacylglycerol in insulin resistance:
  - Mice that are altered to not genetically express PKCθ are protected from lipid-induced insulin resistance ([Kim et al., 2004](https://www.jci.org/articles/view/22230))
  - Similarly, limitation of fat transport into muscle cells by preventing genetic expression of a fatty acid transporter also protects mice from lipid-induced insulin resistance ([Kim et al., 2004](https://www.jci.org/articles/view/18917))
  - In contrast, increasing the genetic expression of lipoprotein lipase, which increases concentration of diacylglycerol in muscle, making the mice more susceptible to lipid-induced insulin resistance ([Kim et al., 2001](https://www.pnas.org/content/98/13/7522.short))
  - And causing impairment of mitochondrial fat oxidation promotes fat accumulation in the liver of mice and increased susceptibility to insulin resistance ([Zhang et al., 2007](https://www.pnas.org/content/104/43/17075.short)), but increasing mitochondrial fat oxidation is protective ([Choi et al., 2007](https://www.jci.org/articles/view/13579))

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-3-shulman-1024x574.png)

**Figure 3. Diacylglycerol and inhibition of insulin signaling in a muscle cell.** Image credit: Gerald Shulman

## The role of exercise in protecting against insulin resistance and fatty liver [50:00]

\*Gerald says exercise **reverses muscle insulin resistance** as well as **prevents fatty liver and liver insulin resistance**

- See Jerry Reaven’s [Banting Lecture](https://www.youtube.com/watch?v=TnvmEUUtoZw) in 1988

**Revisitation of insulin resistance in healthy, lean, and young (but sedentary) research participants** ([Petersen et al., 2007](https://www.pnas.org/content/104/31/12587.short))

- A shown in Figure 4 below, after feeding these healthy, lean, and young individuals a high-carbohydrate milkshake, Gerald and his team found that insulin-resistant and insulin-sensitive participants maintained **similar glucose levels**, however, the **insulin-resistant participants had much higher insulin levels** ([Petersen et al., 2007](https://www.pnas.org/content/104/31/12587.short))
- This implies that the insulin resistant individuals were remaining “healthy” by **producing more insulin**
  - “*That’s why virtually every obese insulin resistant person has normal glycemia, because the beta cells are working so hard to maintain [glucose levels].*”
- Compared to plasma insulin levels shown in Figure 4, insulin levels in the are about threefold higher in [portal circulation](https://en.wikipedia.org/wiki/Portal_venous_system), meaning that the liver is being exposed to very high concentrations of insulin

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-4-shulman-1024x572.png)

**Figure 4. Glucose and insulin levels following consumption of a high-carbohydrate milkshake.** Image credit: Gerald Shulman

- Using carbon NMR, Gerald and his team discovered that while insulin-sensitive and insulin-resistant participants were able to store similar amounts of the ingested carbohydrate as liver glycogen, the insulin-resistant participants were able to store much less glycogen in muscle (Figure 5)

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-5-shulman-1024x574.png)

**Figure 5. Glycogen storage in muscle and liver following consumption of a high-carbohydrate milkshake.** Image credit: Gerald Shulman

- As shown in Figure 6, the insulin-resistant participants also stored more fat in the liver and synthesized more fat from the ingested glucose ([*de novo* lipogenesis](https://en.wikipedia.org/wiki/De_novo_synthesis#Fatty-acid_(de_novo_lipogenesis)))

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-6-shulman-1024x575.png)

**Figure 6. Storage and synthesis of fat in the liver following consumption of a high-carbohydrate milkshake.** Image credit: Gerald Shulman

- As pointed out by Peter, a study from the 1990s ([Hellerstein et al., 1991](https://www.jci.org/articles/view/115206)) showed that *de novo* lipogenesis is not a notable source of lipid. However, a limitation of this study is that the participants were insulin-sensitive. *De novo* lipogenesis becomes more important in the context of insulin resistance and can contribute to development of fatty liver disease
- Meal content can influence *de novo* lipogenesis as well—Fructose in particular fuels this pathway
- **\*A key point:** Insulin resistance in muscle leads to de novo lipogenesis and fat accumulation in the liver, leading to **increased** [very-low density lipoprotein](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein) (VLDL) production by the liver, increased blood triglyceride levels, and **decreased** [high-density lipoprotein](https://en.wikipedia.org/wiki/High-density_lipoprotein) (HDL) levels

**The need to reset what we consider “normal”**

- Consistent with the elevated triglycerides in the insulin-resistant participants in Gerald’s study, Peter believes that **elevated triglycerides are an underappreciated warning of poor metabolic health** and that the currently accepted threshold for “normal” (150 mg/dL) is too high
- In his practice, Peter considers triglycerides above 100 mg/dL as abnormal and triglycerides that are more than twice HDL cholesterol as a “very big red flag”

> “*So you have increased [de novo lipogenesis]. That leads to this increase we just reviewed – plasma triglycerides, this reduction in HDL … that’s going to set these healthy individuals up to atherogenic dyslipidemia, heart disease in their 40s and 50s. And with time it’s metabolic associated fatty liver disease, now and again, most common cause of liver disease now in the world. It’s now the leading cause of NASH, leading cause of liver fibrosis, cirrhosis, end stage liver disease and going to be liver cancer. So it’s all going to be metabolic driven, and from that hyperinsulinemia, in my view.*” —Gerald Shulman

**Bypassing the transport abnormality with exercise [1:00:55]**

- The [Joslin Diabetes Center](https://www.joslin.org/) has found that, if you have two parents with type 2 diabetes, being insulin resistant is the best predictor of whether or not you would go on to develop type 2 diabetes yourself

Gerald and his team has studied this type of population – young, lean, and “healthy” individuals (that have insulin resistance (IR)) and diabetic parents

- These IR people in their basal state take up less than half the amount of glucose in muscle due to a block in transport (as discussed previously)
- Gerald and team asked the question: “*Can we bypass this [transport] abnormality with exercise?”*
  - And **the answer is yes**.
- As shown in Figure 7 below, just one 45-min bout of aerobic exercise (three 15 minute sets at 65% of maximal aerobic capacity, each separated by 5 minutes of rest) restored the concentration of glucose 6-phosphate and the rate of glycogen synthesis in the muscle of insulin-resistant participants to that of the baseline (pre-exercise) level of the insulin-sensitive participants ([Perseghin et al., 1996](https://www.nejm.org/doi/full/10.1056/NEJM199610313351804))
- This is indication of enhanced glucose uptake into the cell, or in simpler terms, an opening up of the roadblock
- A molecular explanation is that a protein called [AMPK](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase) gets activated with exercise which has been shown to cause more translocation (independent of PI3 kinase)
- “*So we’re kind of short circuiting that block with exercise*.”

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-7-shulman-1024x575.png)

**Figure 7. Changes in muscle glycogen synthesis following a single bout of aerobic exercise.** Image credit: Gerald Shulman

More recently, Gerald’s team conducted another study ([Rabol et al., 2011](https://www.pnas.org/content/108/33/13705.short)) in a similar population of individuals who were healthy, young, lean, and sedentary but insulin resistant

- They showed that the same ingested glucose would lead to more glucose deposition as muscle glycogen, and a significant reduction in de novo lipogenesis and a significant reduction in liver triglyceride.
- They used NMR and isotopic labeling to find that compared to resting conditions, a single bout of exercise  (three sets of 15 minutes at 75-85% of calculated maximal heart rate, each separated by 5 minutes of rest) prior to two carbohydrate-rich meals resulted in an approximately threefold increase in muscle glycogen synthesis and a ~30% decrease in *de novo* lipogenesis in the liver

![](https://peterattiamd.com/wp-content/uploads/2020/12/Fig-8.-A-single-bout-of-exercise-can-reverse-the-abnormal-pattern-of-carbohydrate-storage-in-insulin-resistant-individuals-shulman-1024x574.png)

**Figure 8. A single bout of exercise can reverse the abnormal pattern of carbohydrate storage in insulin resistant individuals.** Image credit: Gerald Shulman

Peter asks: *Do we know if that single bout of exercise, which particular piece of the pathway got released? Did it have some direct effect on the root cause, the DAG, or some of the kinases downstream? Was it even further downstream at the very last step where the transporter gets released? Where is the actual bottleneck alleviated with that single bout of exercise?*

- [AMP-activated protein kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase) (AMPK) is a contributing factor to this exercise-induced improvement in glucose uptake by increasing translocation of the glucose transporter GLUT4 to the cell membrane independently of PI3K and associated insulin signaling
- While Gerald does not know the actual mechanism of how exercise increased glucose uptake in the above studies, he believes (based on speculation) it has more to do with AMPK than insulin signaling

**The impact of chronic (not just acute) exercise**

- Gerald also believes that **chronic** exercise would decrease diacylglycerol accumulation and therefore enhance **insulin-induced GLUT4 translocation** in addition to that induced by AMPK
- Based on his experience treating **type 1 diabetics**, Peter sees exercise as a powerful tool
  - Modest intensity aerobic exercise (an hour or 2 of brisk walking per day) can result in virtually being free of insulin while maintaining reasonable glycemic control
  - “*It seems that that exercise becomes a spigot to how much glucose they can dispose in their muscle, seemingly without insulin. It’s almost like a total bypass of the system*.”

> “Being able to maximize both insulin-dependent and insulin-independent glucose uptake into a muscle really becomes a powerful tool to combat all of the metabolic dysregulation.” —Peter Attia

## Insulin resistance in the liver [1:07:15]

**Recapping so far**

- The physiological cause for insulin resistance in muscle—you can’t get glucose in the glycogen due to a block in the GLUT4 transport
- A molecular understanding of how that insulin resistance in muscle happens—which is lipid diacylglycerols block leading to activation of a novel epsilon isoform of protein kinase C (PKCε) which is blocking insulin signaling
- Muscle insulin resistance can lead to fat accumulation in the liver, atherogenic dyslipidemia, and fatty liver.
- Fatty liver is what then leads to insulin resistance in the liver
- What Gerald is about to explain is the molecular basis for how fat in the liver causes insulin resistance

**In summary**: Muscle insulin resistance leads to peripheral IR, then hepatic IR, and hepatic consequences which then basically amplifies it

> “When you get both muscle and liver insulin resistance, and increased glucose production by liver, then something happens to the beta cell and that’s when things really start to spiral where you have very profound hyperglycemia—fasting and postprandial.” —Gerald Shulman

**Sequence of insulin resistance in muscle and the liver**

- In the healthy, young, and lean individuals Gerald has worked with, they have insulin resistance in muscle, but their livers are healthy
- Insulin resistance in muscle diverts glucose to the liver, leading to fat accumulation
- At this point, insulin resistance is present in both the liver and muscle
- But Gerald has studied insulin resistance extensively in rodents as well as humans, and in rodents the sequence is the opposite – insulin resistance occurs in the liver first

**Glucose uptake and metabolism in the liver**

- In contrast to muscle, insulin is not required to stimulate glucose uptake in the liver
- Instead of GLUT4, the primary transporter for glucose in the liver is [glucose transporter 2](https://en.wikipedia.org/wiki/GLUT2) (GLUT2), which translocates to the cell membrane independently of insulin
- However, like muscle, the liver does have insulin receptors and the signaling that occurs once insulin binds to the receptor is similar
- Outcomes of this signaling in the liver include increased glycogen synthesis (through activation of [glycogen synthase](https://en.wikipedia.org/wiki/Glycogen_synthase)) and decreased gluconeogenesis (through [phosphorylation](https://en.wikipedia.org/wiki/Phosphorylation) and inactivation of a [FOXO](https://en.wikipedia.org/wiki/FOX_proteins) protein)

**The molecular mechanism of insulin resistance in the liver**

- Similar to muscle, and as shown in Figure 9 below, diacylglycerol promotes insulin resistance in the liver by activating the [epsilon isoform](https://en.wikipedia.org/wiki/PRKCE) of [protein kinase C](https://en.wikipedia.org/wiki/Protein_kinase_C) (PKCε)

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-9-shulman-1024x575.png)

**Figure 9. Insulin resistance in the liver.** Image credit: Gerald Shulman

- In a study on rats ([Samuel et al., 2007](https://www.jci.org/articles/view/30400)), Gerald’s team induced [steatosis](https://en.wikipedia.org/wiki/Fatty_liver_disease) (fat accumulation) and insulin resistance in the liver through high-fat feeding and found activation of PKCε and its subsequent binding to the insulin receptor to be what caused the insulin resistance
- Gerald’s team later discovered that PKCε interferes with insulin signaling by phosphorylating a specific spot on the insulin receptor ([Petersen et al., 2016](https://www.jci.org/articles/view/86013))
- As shown in Figure 10 below, the [catalytic site](https://en.wikipedia.org/wiki/Active_site) of the insulin receptor is normally like a closed loop. In this loop, there are three key [tyrosine](https://en.wikipedia.org/wiki/Tyrosine) molecules (Tyr1158, Tyr1162, and Tyr1163, each numbered according to their position in the amino acid sequence of the insulin receptor protein). When insulin binds to the receptor, these three tyrosines become phosphorylated, physically opening the “loop” and allowing [insulin receptor substrate 1](https://en.wikipedia.org/wiki/IRS1) (IRS-1) to enter and initiate insulin signaling

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-10-shulman-970x1024.png)

**Figure 10. Catalytic domain of the insulin receptor.** Image credit: Gerald Shulman

- What Gerald’s team determined with PKCε is that by phosphorylating a nearby [threonine](https://en.wikipedia.org/wiki/Threonine) molecule (Thr1160), it prevents phosphorylation of the three previously mentioned tyroisines, thereby preventing subsequent insulin signaling
- Confirming this role of PKCε in hepatic insulin resistance, Gerald’s team created genetically altered mice in which threonine is replaced with alanine at the location of the insulin receptor that PKCε phosphorylates, basically preventing PKCε from phosphorylating it. Consistent with the mechanism described above, this protected the mice from hepatic insulin resistance during high-fat feeding ([Petersen et al., 2016](https://www.jci.org/articles/view/86013))
- Although the high-fat feeding used in these studies was mainly just fat, Gerald notes that adding sucrose would have promoted fat accumulation and insulin resistance to an even greater extent
- Circling back to diacylglycerol, Gerald’s team just recently discovered that it is primarily just one [stereoisomer](https://en.wikipedia.org/wiki/Stereoisomerism) of diacylglycerol (sn-1,2) in the cell plasma membrane that activates PKCε ([Lyu et al., 2020](https://www.sciencedirect.com/science/article/abs/pii/S1550413120304149))

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-11-shulman-1024x828.png)

**Figure 11.** Image credit: [Lyu et al., 2020](https://www.sciencedirect.com/science/article/abs/pii/S1550413120304149)

## The evolutionary explanation for insulin resistance—an important tool for surviving starvation [1:17:15]

- Genetics determines the amino acid sequence of proteins, and the sequence of the insulin receptor that allows PKCε to phosphorylate the receptor and block subsequent insulin signaling is preserved from humans all the way to fruit flies, implying that insulin resistance has had an important role in evolution
- The [central nervous system](https://en.wikipedia.org/wiki/Central_nervous_system) requires glucose, which becomes limited during starvation
- As shown in Figure 12 below, Gerald’s team found greater accumulation of diacylglycerol and activation of PKCε in the livers of mice fasted for 48 hours, indicating onset of insulin resistance ([Perry et al., 2018](https://www.sciencedirect.com/science/article/pii/S0092867417314435))

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-12-shulman-1024x574.png)

**Figure 12. Activation of hepatic insulin resistance during fasting.** Image credit: Gerald Shulman

- Based on these factors, Gerald considers insulin resistance to be an important component of evolution that allows survival during starvation by sparing glucose for the central nervous system

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-13-shulman-1024x575.png)

**Figure 13.** Image credit: Gerald Shulman

- Consistent with this idea, there is a type of fish called the [Mexican cavefish](https://www.nature.com/articles/d41586-018-03737-w) that eats infrequently and is known to have a genetic mutation in the insulin receptor that causes profound hepatic insulin resistance, which is believed to be important for the survival of these fish
- Although Gerald’s examples here are focused on the liver, because that is the direction his research led him in, he and Peter agree that insulin resistance in muscle is also involved in this evolutionary conservation of glucose for the central nervous system

> “*In my view, insulin resistance was a protective mechanism throughout evolution that allowed us to survive…starvation which was probably the predominant environmental exposure we’ve had for the last many, many millennia. It’s only in recent years, recent decades and now we’re in this toxic environment of over-nutrition and it’s when these same pathways now are going the opposite direction—promoting disease by doing what they were at one time was protective. And now they’re actually being called metabolic disease.” —Gerald Shulman*

## The critical role of gluconeogenesis, and how it’s regulated by insulin [1:22:30]

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-14-shulman-1024x617.png)

**Figure 14.** Image credit: Gerald Shulman

**The necessity of gluconeogenesis for survival**

- The liver produces glucose from non-carbohydrate sources through a process called [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis)
- This process is necessary for survival – Peter argues that we would have a tough time surviving 10 minutes without it (unless you have continuous feeding)
- Demonstrating the necessity for gluconeogenesis is a glycogen storage disease called von [Gierke’s disease](https://en.wikipedia.org/wiki/Glycogen_storage_disease_type_I) in which the enzyme [glucose 6-phosphatase](https://en.wikipedia.org/wiki/Glucose_6-phosphatase) (the final step of gluconeogenesis) is not functional, preventing glucose from leaving the liver. People with this disease must be continuously fed to survive

> “*Without gluconeogenesis, we’re not going to wake up in the morning because it’s gluconeogenesis that supplies glucose for the CNS while we’re sleeping*.” —Gerald Shulman

**Regulation of gluconeogenesis**

- Regulation of gluconeogenesis is important in both directions.
  - For example, if gluconeogenesis was not suppressed after eating, blood glucose could go up to 400 or 500 mg/dL
- As previously mentioned and shown in Figure 9, insulin signaling leads to phosphorylation and inactivation of [FOXO proteins](https://en.wikipedia.org/wiki/FOX_proteins) leading to downregulation of gluconeogenesis
- This regulation, however, occurs through genetic expression, and since changes in genetic expression do not happen fast enough to explain the possibility of turning gluconeogenesis off within minutes, there must be another regulatory mechanism with a stronger influence
- Further supporting this, gluconeogenesis can still be shut off when insulin signaling is blocked
- And in liver samples from diabetics undergoing bariatric surgery, in which upregulation of the key gluconeogenic enzymes [phosphoenolpyruvate carboxykinase](https://en.wikipedia.org/wiki/Phosphoenolpyruvate_carboxykinase) (PEPCK) and [glucose 6-phosphatase](https://en.wikipedia.org/wiki/Glucose_6-phosphatase) (G6Pase) would be expected due to insulin resistance ([Samuel et al., 2009](https://www.pnas.org/content/106/29/12121.short)), such upregulation is not found, indicating suppression through a different mechanism
- [Glycerol](https://en.wikipedia.org/wiki/Glycerol), which is a byproduct of [lipolysis](https://en.wikipedia.org/wiki/Lipolysis) (breakdown of fat), interestingly feeds gluconeogenesis in an unregulated manner, which is related to Gerald’s team discovering that metformin decreases gluconeogenesis by inhibiting conversion of glycerol to glucose ([Madiraju et al., 2014](https://www.nature.com/articles/nature13270/); [Madiraju et al, 2018](https://www.nature.com/articles/s41591-018-0125-4?fbclid=IwAR34V1E9FRy-dCnDZF8aUXW7jjeYqOE-TqgfBJQRr46q6vOcF5JxT-ZDSFQ))
- Related to glycerol and lipolysis, [β-oxidation](https://en.wikipedia.org/wiki/Beta_oxidation) of fatty acids leads to production of [acetyl-CoA](https://en.wikipedia.org/wiki/Acetyl-CoA), which feeds the [citric acid cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle) for energy production
- Acetyl-CoA is difficult to measure, but Gerald and his team developed a method to measure it reliable, and as shown in Figure 15, they consistently find that increases in acetyl-CoA track with increases in gluconeogenesis

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-15-shulman-1024x577.png)

**Figure 15. Relationship between gluconeogenesis and acetyl-CoA.** Image credit: Gerald Shulman

- This is consistent with acetyl-CoA being known to [allosterically](https://en.wikipedia.org/wiki/Allosteric_regulation) increase activity of the gluconeogenic enzyme [pyruvate carboxylase](https://en.wikipedia.org/wiki/Pyruvate_carboxylase)
- Gerald also consistently sees insulin suppressing acetyl-CoA, which represents a mechanisms through which insulin can more acutely inhibit gluconeogenesis
- As shown in Figure 16, an important distinction here is that while insulin regulates hepatic glycogen synthesis through signaling induced through receptor binding, insulin’s influence on gluconeogenesis is primarily mediated outside of the liver, **mainly through fat cells**

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-16-shulman-1024x579.png)

**Figure 16. Distinction between insulin’s influence on hepatic glycogen synthesis versus gluconeogenesis.** Image credit: Gerald Shulman

- Insulin strongly inhibits lipolysis in fat cells, thereby decreasing the amount of fatty acids available to the liver to be oxidized into acetyl-CoA and, in turn, decreasing gluconeogenesis.
  - And given the decrease in lipolysis, there is also less glycerol to fuel gluconeogenesis

**This is going to answer Peter’s question about** ***how we distinguish insulin promoting storage as glycogen, yet keeping gluconeogenesis going for the brain***:

- Insulin binds the receptor and it has direct effects through the receptor—that is mostly to promote glucose uptake and storage as glycogen.
- The effects on gluconeogenesis (the process that keeps us going during starvation) is really mostly regulated not through the receptor in liver, but through its effect on the fat cell in the periphery.
  - It’s really insulin putting the break on peripheral lipolysis,
  - less fatty acid delivery to liver,
  - less generation Acetyl-CoA.
    - Note: the more fatty acids that flux liver track almost perfectly with Acetyl-CoA content
  - less pyruvate carboxylase activity
  - Again, there’s about 10-15% of this gluconeogenesis is simply coming from less glycerol from lipolysis to liver through sub straight push
- You have two very different processes here:
  - One is glycogen synthesis—that’s what the receptor’s doing in the liver
  - Gluconeogenesis is mostly (90%) through its effect to put the break on peripheral lipolysis
- When you have glycogen in liver (i.e., fed state), it’s really these direct effects of insulin on liver will predominate
- But as you move to the fasted state ( in human probably have to go 24 hr or longer fast) then it’s the indirect effects that will predominate
- **In other words**: As time shifts from fed to fasting, the influence of insulin shifts from the direct effect on hepatic glycogen synthesis to the indirect effect on lipolysis in fat cells outside of the liver
- Gerald believes this shift explains a lot of conflicting research results, particularly studies on dogs by [Alan Cherrington](https://wag.app.vanderbilt.edu/PublicPage/Faculty/Details/34964) and [Richard Bergman](https://bio.cedars-sinai.org/bergmanr/index.html)

## Inflammation and body fat as contributing factors to insulin resistance [1:32:15]

**How inflammation drives the transition from insulin resistance to hyperglycemia**

- Inflammatory cytokines including [tumor necrosis factor-α](https://en.wikipedia.org/wiki/Tumor_necrosis_factor) (TNF-α) and [interleukin 6](https://en.wikipedia.org/wiki/Interleukin_6) (IL-6) contribute to insulin resistance
- Although much of Gerald’s work shows that diacylglycerol induces insulin resistance independently of inflammation, inflammation is a compounding factor
- The transition from insulin resistance in muscle in liver to fasting hyperglycemia requires inflammation
- In the context of obesity and diabetes, inflammation causes insulin resistance in fat cells, which results in increased lipolysis, leading to greater delivery of fatty acids to the liver, more accumulation of diacylglycerol and, in turn, more hepatic insulin resistance and less storage of glucose as liver glycogen
- In addition, the increased lipolysis leads to increased glycerol and acetyl-CoA, leading to the increased gluconeogenesis driving hyperglycemia
- Despite this role of inflammation, diacylglycerol has an active role as well in inducing insulin resistance in fat cells

Peter asks: *Would we still say they are insulin resistant at the fat cell? Or would we say they are insulin sensitive at the fat cell? Because they are correctly undergoing lipogenesis in the fat cell. They’re at least taking up a esterified fat and they’re presumably impairing lipolysis, which is why they retain adipose cell mass. In other words, the flux through the fat cell is negative. They’re holding onto fat, correct?*

- If you do careful studies measuring rates of lipolysis, by definition they will have insulin resistance in the fat cell
- They’re holding on to fat because it’s at hyperinsulinemia—their insulin concentrations are two to three fold
- But if you brought them down to normal levels of insulin, then you might see more lipolysis
- So, there is peripheral insulin resistance
- But we’re finding actually the same mechanism that we have in liver and muscle—the diacylglycerol Epsilon pathway is also accounting for this defect and insulin action in the fat cell

**Visceral fat [1:38:00]**

- In contrast to [subcutaneous fat](https://en.wikipedia.org/wiki/Subcutaneous_tissue#Subcutaneous_fat), which is fat just beneath the skin, [visceral fat](https://en.wikipedia.org/wiki/Adipose_tissue#Visceral_fat) surrounds internal organs including the kidneys, liver, and spleen
- Visceral fat is a well-known indicator of poor health and it is strongly correlated with insulin resistance and liver fat (whereas subcutaneous fat is not)
- Gerald believes that the negative effects of visceral fat are mediated through increased delivery of fatty acids to the liver.
  - In other words, fat accumulation in the liver is the main problem, and visceral fat exacerbates it
- This is supported by [lipodystrophy](https://en.wikipedia.org/wiki/Lipodystrophy), which is a type of disorder in which someone is unable to store subcutaneous or visceral fat. Despite this, people with these disorders have a lot of liver fat and are diabetic, showing that metabolic dysfunction can certainly occur independently of visceral fat
- In general, Gerald believes that it is diacylglycerol that initially drives insulin resistance and subsequent increases in acetyl-CoA and gluconeogenesis that facilitate transition to fasting hyperglycemia and diabetes

> “*If I had to pick two molecules that are driving metabolic disease, it’s acetyl-CoA driving pyruvate carboxylase. And again, the diacylglycerols activating [PKCε]. And again, it’s the [PKCε] that drives insulin resistance – no diabetes, no hyperglycemia. Then it’s this accelerated gluconeogenesis through this mechanism, that’s taking you from just pure insulin resistance to fasting hyperglycemia and diabetes.*” —Gerald Shulman

## Treatment approaches for fatty liver and insulin resistance, and an exciting new pharmacological approach [1:41:15]

**Targeting the liver for treating metabolic disease**

- Underscoring the relevance and prevalence of fatty liver, it is becoming a problem with liver transplants because **most of the donors have fatty liver** and transplanted livers with fat accumulation do not do well
- Gerald frequently emphasises to patients that metabolic problems can be fixed with **diet and exercise**, but unfortunately, the vast majority of patients do not take the advice
- He believes that the **liver is the most important organ to target in resolving metabolic disease** and that the problem is primarily an energy imbalance (thermodynamics)
  - Too much energy coming in relative to the ability of the hepatocyte, the liver, to:
    - i) oxidize the energy and convert it the CO2; or
    - ii) export it—the liver is also able to do is export energy as a form of VLDL triglyceride
- H*ow do we fix this*?
  - While diet and exercise is the first solution, to get the patient to stay on this is challenging
  - Gastric bypass is effective for resolving metabolic concerns, but there’s no magic – the benefit is from weight loss achieved through **decreased energy intake**
  - Additionally, there are pharmacologic approaches

> “*If I had to pick one organ to target it’s the liver, as important as muscle insulin resistance is at the very beginning. If we actually want to reverse the disease and make the biggest impact, if I had to pick one organ it’s the liver. … The whole metabolic problem with the liver is this imbalance of energy. Too much energy in relative to the ability of the hepatocyte, the liver, to oxidize the energy and convert it to CO**2* *or export it*.” —Gerald Shulman

**Pharmaceutical approaches**

- Gerald has found [glucagon-like peptide 1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) (GLP-1) agonists to be effective for helping people eat less and lose weight, but they cause nausea in some people
- His experience has been that GLP-1 agonists decrease liver fat, but do not completely normalize it
- [Sodium glucose cotransporter 2](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_2) (SGLT2) inhibitors also decrease net energy intake by increasing urinary excretion of glucose, and although this may be helpful in combination with other treatments, it has *minimal effect on liver fat*
- The pharmaceutical approach Gerald is **most excited about is intentionally inducing mitochondrial inefficiency through** [**uncoupling**](https://en.wikipedia.org/wiki/Uncoupling_protein), which for the liver means more oxidation of fat to produce the same amount of energy
  - Gerald’s team has done a number of studies showing mitochondrial uncoupling agents to reverse fatty liver and associated inflammation and fibrosis ([Perry et al., 2013](https://www.sciencedirect.com/science/article/pii/S1550413113004166); [Perry et al., 2015](https://science.sciencemag.org/content/347/6227/1253.abstract); [Abulizi et al., 2017](https://faseb.onlinelibrary.wiley.com/doi/full/10.1096/fj.201700001R))
  - More recently, Gerald’s team validated the safety and efficacy of this mitochondrial uncoupling approach in non-human primates ([Goedeke et al., 2019](https://stm.sciencemag.org/content/11/512/eaay0284.short))
  - An important characteristic of this treatment, in contrast to other treatments for [non-alcoholic fatty liver disease](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease) (NAFLD), [non-alcoholic steatohepatitis](https://en.wikipedia.org/wiki/Steatohepatitis) (NASH), and liver fibrosis, this treatment is “heart healthy” because it decreases hepatic export of [very-low density lipoproteins](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein) (VLDL)
    - This is important, because most patients with diabetes and fatty liver disease end up **dying of heart disease**

**More on mitochondrial uncoupling**

- As shown in Figure 17, during [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation) in mitochondria, passage of electrons through the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain) establishes a gradient of protons across the inner mitochondrial membrane. This gradient drives [ATP synthase](https://en.wikipedia.org/wiki/ATP_synthase), resulting in energy production. Uncoupling dissipates the gradient by allowing protons to pass through the inner membrane without ATP production, thereby requiring a greater input of electrons (which are mainly obtained through the food we eat) to the electron transport chain to produce the same amount of energy

![](https://peterattiamd.com/wp-content/uploads/2020/12/fig-17-shulman.jpg)

**Figure 17. Mitochondrial uncoupling.** Image credit: [scielo.br](https://www.scielo.br/img/revistas/abem/v56n4/01f01.jpg)

- Mitochondrial uncoupling was accidentally discovered in the early 1900s because of munition factory workers who were losing weight despite not eating differently. The weight loss was eventually determined to be a result of exposure to [dinitrophenol](https://en.wikipedia.org/wiki/2,4-Dinitrophenol), which is a substance that was used in the factories and also happens to be a mitochondrial uncoupler
- In 1933, a [paper](https://jamanetwork.com/journals/jama/article-abstract/245872) was published in the *Journal of the American Medical Association* (JAMA) by [Maurice Tainter](https://academic.oup.com/bioscience/article-abstract/16/10/687/354274?redirectedFrom=PDF) describing the use of dinitrophenol for treatment of obesity
- Eventually, after creation of the FDA, dinitrophenol was pulled from the market because high doses were causing hyperthermia, and even death in some cases
- Hyperthermia is a result of uncoupling (and the subsequent heat generation) occurring throughout all organs of the body.
  - Gerald’s team has addressed this concern by using an uncoupler that only targets the liver
- They are currently still exploring pre-clinical models and hope to be testing in humans within the next year or two

> “I just think that this is the nexus from which all diseases stand. And therefore, we are really making a mistake if we want to treat chronic diseases in their silos and just think about atherosclerosis and just think about cancer and just think about Alzheimer’s disease without understanding how these diseases are fed. And unfortunately that means rolling up our sleeves and understanding insulin resistance.” —Peter Attia

## Dietary considerations when treating metabolic illness [1:56:15]

- Peter has found that although not universal, **carbohydrate restriction and periodic fasting are more effective for helping people lose weight compared to caloric restriction**
- Gerald does not have a preferred approach, but rather encourages his patients to stick with “whatever works,” because as long as they lose weight, their diabetes will improve
- He sees a lot of people regain the weight they lost and therefore considers finding a **sustainable approach** to be more important than what the approach is

> “*And so it’s a marathon. You have to find something you like, like it enough to be able to stick with, that’s most important thing. Because we’ve all seen that where people lose the weight and then few weeks, months later, right back to where they started. So everyone has to find what works for them.*” —Gerald Shulman

## Metformin’s mechanism of action and its suitability as a longevity agent [1:58:15]

- [Metformin](https://en.wikipedia.org/wiki/Metformin) effectively lowers glucose levels in people with poorly controlled diabetes, primarily through inhibition of gluconeogenesis
- Many people believe that metformin works by inhibiting [complex I](https://en.wikipedia.org/wiki/Respiratory_complex_I) of the mitochondrial [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain), but Gerald is convinced there is a more important and relevant mechanism
- Metformin is a [biguanide](https://en.wikipedia.org/wiki/Biguanide), and guanides in general are well known to inhibit complex I
- Prior to metformin, other guanide-based drugs, like phenformin have been used to treat diabetes. Even [French lilac](https://en.wikipedia.org/wiki/Metformin#History) extracts, which these biguanide drugs originated from, were used 300 years ago, prior to even knowing what diabetes is
- However, the concentration of metformin needed to inhibit complex I is in the millimolar range while the maximal dose of metformin for humans only results in a 30-50 micromolar concentration
- Even when considering that the concentration in [portal circulation](https://en.wikipedia.org/wiki/Portal_vein) to the liver may be about threefold higher, this is still tenfold below the threshold of inhibiting complex I, making this mechanism clinically irrelevant
- Gerald’s team has found that at clinically relevant concentrations, metformin inhibits the mitochondrial isoform of [glycerol-3-phosphate dehydrogenase](https://en.wikipedia.org/wiki/Glycerol-3-phosphate_dehydrogenase) ([Madiraju et al., 2014](https://www.nature.com/articles/nature13270/)), thereby decreasing [glycerol](https://en.wikipedia.org/wiki/Glycerol) availability
- They have also determined that metformin primarily inhibits gluconeogenesis by limiting the use of glycerol and lactate as substrates ([Madiraju et al., 2018](https://www.nature.com/articles/s41591-018-0125-4?fbclid=IwAR34V1E9FRy-dCnDZF8aUXW7jjeYqOE-TqgfBJQRr46q6vOcF5JxT-ZDSFQ))
- More specifically, conversion of lactate to [pyruvate](https://en.wikipedia.org/wiki/Pyruvic_acid) and glycerol to [dihydroxyacetone phosphate](https://en.wikipedia.org/wiki/Dihydroxyacetone_phosphate) (DHAP) are the two steps of gluconeogenesis that metformin inhibits by inhibiting glycerol-3-phosphate dehydrogenase
- This is why metformin rarely causes hypoglycemia – because other substrates, such as [alanine](https://en.wikipedia.org/wiki/Alanine), are still available for gluconeogenesis. It is also why [lactic acidosis](https://en.wikipedia.org/wiki/Lactic_acidosis) is a known side effect of metformin
- Gerald’s team is currently investigating the mechanism of how metformin inhibits glycerol-3-phosphate dehydrogenase, which Gerald believes to be indirect and hopes to publish within the next year
- In regard to the interest in metformin for aging, Gerald considers this “a question that remains to be answered,” but emphasizes that in order to answer the question, the correct mechanism of action must be understood

§

## Selected Links / Related Material

**Gerald’s 1988 Banting Lecture:** [Role of insulin resistance in human disease](https://diabetes.diabetesjournals.org/content/37/12/1595) (Reaven, 1988) | [9:30]

**A recent review article co-authored by Gerald and one of his former students on the role of insulin in cancer growth:** [Mechanistic links between obesity, insulin, and cancer](https://www.sciencedirect.com/science/article/abs/pii/S2405803319302614) (Perry & Shulman, 2020) | [10:45]

**A study by Gerald’s team showing caloric restriction to reverse insulin resistance**: [Reversal of muscle insulin resistance by weight reduction in young, lean, insulin-resistant offspring of parents with type 2 diabetes](https://www.pnas.org/content/109/21/8236.short) (Petersen et al., 2012) | [21:30]

**A study by Gerald’s team showing infusion of lipids to cause insulin resistance and inhibit glycogen synthesis in healthy individuals**: [Mechanism of free fatty acid-induced insulin resistance in humans](https://www.jci.org/articles/view/118742) (Roden et al., 1996) [37:00]

**A more recent study by Gerald’s team showing infusion of lipids to cause insulin resistance in healthy individuals, as well as demonstrating impairment of glucose transport in human muscle biopsy samples**: [Mechanisms underlying the onset of oral lipid-induced skeletal muscle insulin resistance in humans](https://diabetes.diabetesjournals.org/content/62/7/2240.short) (Nowotny et al., 2013) [37:00, 43:15]

**A study by Gerald’s team showing in human muscle biopsy samples that the lipid intermediate diacylglycerol is responsible for impairing glucose transport**: [Role of diacylglycerol activation of PKCΘ in lipid-induced muscle insulin resistance in humans](https://www.pnas.org/content/111/26/9597.short) (Szendroedi et al., 2014) [43:15]

**Several animal studies by Gerald and his team elucidating the mechanisms of lipid-induced insulin resistance**: [49:15]

- [PKCθ knockout mice are protected from fat-induced insulin resistance](https://www.jci.org/articles/view/22230) (Kim et al., 2004)
- [Inactivation of fatty acid transport protein 1 prevents fat-induced insulin resistance in skeletal muscle](https://www.jci.org/articles/view/18917) (Kim et al., 2004)
- [Tissue-specific overexpression of lipoprotein lipase causes tissue-specific insulin resistance](https://www.pnas.org/content/98/13/7522.short) (Kim et al., 2001)

- [Mitochondrial dysfunction due to long-chain acyl-CoA dehydrogenase deficiency causes hepatic steatosis and hepatic insulin resistance](https://www.pnas.org/content/104/43/17075.short) (Zhang et al., 2007)
- [Overexpression of uncoupling protein 3 in skeletal muscle protects against fat-induced insulin resistance](https://www.jci.org/articles/view/13579) (Choi et al., 2007)

**Gerald’s 2018 Banting Lecture**: [Critical Viewing on Insulin Resistance – Banting Medal for Scientific Achievement – Gerald Shulman](https://www.youtube.com/watch?v=TnvmEUUtoZw) | Ivor Cummins (youtube.com) | [51:15]

**A study by Gerald and his team showing healthy and lean individuals with insulin resistance to have greater fat accumulation in their muscle and livers**: [The role of skeletal muscle insulin resistance in the pathogenesis of the metabolic syndrome](https://www.pnas.org/content/104/31/12587.short) (Petersen et al., 2007) | [52:00]

**A study showing de novo lipogenesis to not be a notable source of lipids in insulin sensitive individuals**: [Measurement of de novo hepatic lipogenesis in humans using stable isotopes](https://www.jci.org/articles/view/115206) (Hellerstein et al., 1991) | [54:15]

**A study by Gerald’s team showing exercise to enhance insulin sensitivity in insulin resistant participants**: [Increased glucose transport-phosphorylation and muscle glycogen synthesis after exercise training in insulin-resistant subjects](https://www.nejm.org/doi/full/10.1056/NEJM199610313351804) (Perseghin et al., 1996) | [1:01:15]

**A study by Gerald’s team showing exercise to increase muscle glycogen synthesis and decrease hepatic** ***de novo*** **lipogenesis following carbohydrate-rich feeding**: [Reversal of muscle insulin resistance with exercise reduces postprandial hepatic de novo lipogenesis in insulin resistant individuals](https://www.pnas.org/content/108/33/13705.short) (Rabol et al., 2011) | [1:03:00]

**An animal study by Gerald’s team showing activation PKCε and its binding to the insulin receptor to cause insulin resistance in the liver**: [Inhibition of protein kinase Cε prevents hepatic insulin resistance in nonalcoholic fatty liver disease](https://www.jci.org/articles/view/30400) (Samuel et al., 2011) | [1:11:30]

**A study by Gerald’s team characterizing how PKCε interacts with the insulin receptor to block insulin signaling**: [Insulin receptor Thr1160 phosphorylation mediates lipid-induced hepatic insulin resistance](https://www.jci.org/articles/view/86013) (Petersen et al., 2016) | [1:12:15]

**A study by Gerald’s team showing that it is a single diacylglycerol stereoisomer that activates PKCε**: [A membrane-bound diacylglycerol species induces PKC](https://www.sciencedirect.com/science/article/abs/pii/S1550413120304149)ε[-mediated hepatic insulin resistance](https://www.sciencedirect.com/science/article/abs/pii/S1550413120304149) (Lyu et al., 2020) | [1:16:15]

**A study by Gerald’s team showing 48 hrs of fasting to cause hepatic insulin resistance**: [Leptin mediates a glucose-fatty acid cycle to maintain glucose homeostasis in starvation](https://www.sciencedirect.com/science/article/pii/S0092867417314435) (Perry et al., 2018) | [1:17:15]

**A type of fish that likely relies on insulin resistance for survival**: [The healthy diabetic cavefish conundrum](https://www.nature.com/articles/d41586-018-03737-w) | Sylvie Retaux, *Nature* | [1:18:30]

**A biographical review of George Cahill’s work on fasting, including the brain’s diminished but persistent reliance on glucose**: [Fuel metabolism in starvation](https://www.annualreviews.org/doi/abs/10.1146/annurev.nutr.26.061505.111258) (Cahill, 2006) | [1:20:30]

**A study by Gerald’s team showing key gluconeogenic enzymes to not be upregulated in the livers of diabetic individuals**: [Fasting hyperglycemia is not associated with increased expression of PEPCK or G6Pc in patients with type 2 diabetes](https://www.pnas.org/content/106/29/12121.short) (Samuel et al., 2009) | [1:25:30]

**Two studies by Gerald’s team showing that metformin inhibits glycerol from being a substrate for gluconeogenesis**: [1:27:45, 2:02:15]

- [Metformin suppresses gluconeogenesis by inhibiting mitochondrial glycerophosphate dehydrogenase](https://www.nature.com/articles/nature13270/) (Madiraju et al., 2014)
- [Metformin inhibits gluconeogenesis via a redox-dependent mechanism in vivo](https://www.nature.com/articles/s41591-018-0125-4?fbclid=IwAR34V1E9FRy-dCnDZF8aUXW7jjeYqOE-TqgfBJQRr46q6vOcF5JxT-ZDSFQ) (Madiraju et al., 2018)

**Three studies by Gerald’s team showing mitochondrial uncoupling to effectively reverse fatty liver**: [1:48:30]

- [Reversal of hypertriglyceridemia, fatty liver disease, and insulin resistance by a liver-targeted mitochondrial uncoupler](https://www.sciencedirect.com/science/article/pii/S1550413113004166) (Perry et al., 2013)
- [Controlled-release mitochondrial protonophore reverses diabetes and steatohepatitis in rats](https://science.sciencemag.org/content/347/6227/1253.abstract) (Perry et al., 2015)
- [A controlled-release mitochondrial protonophore reverses hypertriglyceridemia, nonalcoholic steatohepatitis, and diabetes in lipodystrophic mice](https://faseb.onlinelibrary.wiley.com/doi/full/10.1096/fj.201700001R) (Abulizi et al., 2017)

**A study by Gerald’s team showing mitochondrial uncoupling to be safe and effective in non-human primates**: [Controlled release mitochondrial protonophore (CRMP) reverses dyslipidemia and hepatic steatosis in dysmetabolic nonhuman primates](https://stm.sciencemag.org/content/11/512/eaay0284.short) (Goedeke et al., 2019) | [1:48:30]

**An early case series describing the effects of the mitochondrial uncoupler dinitrophenol on weight loss**: [Use of dinitrophenol in obesity and related conditions](https://jamanetwork.com/journals/jama/article-abstract/245872) (Tainter et al., 1933) | [1:52:00]

 **Gerald’s 2018 Banting Lecture**: [Critical Viewing on Insulin Resistance – Banting Medal for Scientific Achievement – Gerald Shulman](https://www.youtube.com/watch?v=TnvmEUUtoZw) | Ivor Cummins (youtube.com) [1:55:00]

§

## People Mentioned

- [Gerald Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) [9:30, 50:45]
- [Rachel Perry](https://medicine.yale.edu/profile/rachel_perry/) [10:45]
- [George Radda](https://en.wikipedia.org/wiki/George_Radda) [14:45]
- [Doug Rothman](https://medicine.yale.edu/profile/douglas_rothman/) [18:00]
- [Roy Taylor](https://en.wikipedia.org/wiki/Roy_Taylor_(scientist)) [23:00]
- [Lew Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) (scientist who discovered PI3K) [33:45]
- [Philip Randle](https://en.wikipedia.org/wiki/Philip_Randle) [40:15]
- [Marc Hellerstein](https://vcresearch.berkeley.edu/faculty/marc-hellerstein) [54:15]
- [Kitt Peterson](https://medicine.yale.edu/profile/kitt_petersen/) (Gerald’s wife and colleague) [56:45, 1:45:30]
- [Gianluca Perseghin](https://twitter.com/gianluperse?lang=en) [1:01:15]
- [Rasmus Rabol](https://www.linkedin.com/in/rasmus-rab%C3%B8l-71a00842/?originalSubdomain=dk) [1:03:00]
- [Varman Samuel](https://medicine.yale.edu/profile/varman_samuel/) | [1:11:30]
- [Jesse Rinehart](https://medicine.yale.edu/profile/jesse_rinehart/) | [1:12:15]
- [Max Petersen](https://endocrinology.wustl.edu/people/max-petersen-md-phd/) | [1:12:15]
- [Rachel Perry](https://medicine.yale.edu/profile/rachel_perry/) | [1:17:15]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) | [1:20:30]
- [Anila Madiraju](https://twitter.com/dranilamadiraju?lang=en) | [1:27:45]
- [Alan Cherrington](https://wag.app.vanderbilt.edu/PublicPage/Faculty/Details/34964) | [1:32:00]
- [Richard Bergman](https://bio.cedars-sinai.org/bergmanr/index.html) | [1:32:00]
- [Maurice Tainter](https://academic.oup.com/bioscience/article-abstract/16/10/687/354274?redirectedFrom=PDF) | [1:52:00]

§

![](https://peterattiamd.com/wp-content/uploads/2020/12/gerald-shulman-photo-500x500.jpg)

##### Gerald Shulman M.D., Ph.D.

Dr. Shulman is the George R. Cowgill Professor of Medicine and Cellular & Molecular Physiology at Yale. He is also Co-Director of the Yale Diabetes Research Center. Dr. Shulman has pioneered the use of magnetic resonance spectroscopy combined with mass spectrometry to non-invasively examine intracellular glucose and fat metabolism in humans and transgenic rodent models that have led to several paradigm shifts in our understanding of type 2 diabetes (T2D), including the molecular mechanisms by which ectopic lipid promotes liver and muscle insulin resistance, as well as developing new drugs for the treatment of T2D, nonalcoholic fatty liver disease (NAFLD) and nonalcoholic steatohepatitis (NASH). Dr. Shulman is the recipient of the Stanley J. Korsymeyer Award from the American Society for Clinical Investigation, the Outstanding Clinical Investigator Award from the Endocrine Society, the Solomon Berson Award from the American Physiological Society and the Banting Medal for Lifetime Scientific Achievement from the American Diabetes Association. Dr. Shulman is a Fellow of the American Association for the Advancement of Science, Inaugural Fellow of the American Physiological Society and he has been elected to the American Society for Clinical Investigation, the Association of American Physicians, the National Academy of Medicine, the American Academy of Arts and Sciences and the National Academy of Sciences. [[yale.edu](https://medicine.yale.edu/profile/gerald_shulman/#:~:text=Shulman%20is%20the%20George%20R,the%20Yale%20Diabetes%20Research%20Center.&text=Shulman%20is%20the%20recipient%20of%20the%20Stanley%20J.)]