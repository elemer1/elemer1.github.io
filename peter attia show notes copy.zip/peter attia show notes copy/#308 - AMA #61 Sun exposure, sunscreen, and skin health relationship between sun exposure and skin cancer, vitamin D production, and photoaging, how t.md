# #308 – AMA #61: Sun exposure, sunscreen, and skin health: relationship between sun exposure and skin cancer, vitamin D production, and photoaging, how to choose a sunscreen, and more

**Source:** [https://peterattiamd.com/ama61/](https://peterattiamd.com/ama61/)

---

In this “Ask Me Anything” (AMA) episode, Peter delves into two topics that have generated a lot of questions over the years: skin cancer and sunscreen. He begins by exploring the basics of UV radiation, discussing its effects on vitamin D conversion, photoaging, and its role in skin cancer. He examines various skin types, discussing their implications for sun exposure and vitamin D levels, as well as how to determine where you fall on the skin type scale. He then delves into the various types of skin cancer, with a particular emphasis on melanoma, exploring its complex relationship with UV exposure and other contributing risk factors. Additionally, he covers tanning beds, the importance of early skin cancer detection through regular skin checks, and the often confusing topic of sunscreen. He explains how sunscreen affects UV radiation and skin cancer risk, what SPF levels to choose, the differences between organic and mineral sunscreens, and what to consider when selecting the best sunscreen for your needs.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #61 show notes page](https://peterattiamd.com/ama61). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The impact of UV radiation on the skin [2:00];
- Understanding solar UV: from the electromagnetic spectrum to skin health [3:45];
- The role of sunlight in vitamin D production [8:30];
- Factors contributing to vitamin D deficiency: insufficient UV exposure, magnesium levels, and more [9:45];
- Sun exposure needs for different skin types, and the limitations of current studies in defining vitamin D deficiency [12:45];
- The acute and long-term effects of excessive UV exposure: sunburn, photoaging, and the increased risk of skin cancer [15:30];
- Types of skin cancer and associations with UV exposure [17:45];
- The complex relationship between melanoma and UV exposure [22:15];
- Why UV exposure alone doesn’t necessarily explain the risk for melanoma [25:15];
- Other risk factors for melanoma [29:15];
- Tanning beds and skin cancer risk [34:45];
- Balancing sun exposure: benefits and risks [38:15];
- Tattoos and sun exposure [40:30];
- The importance of regular skin checks, dermatologists, and emerging technologies showing promise for early detection of cancer [41:45];
- Self-skin checks: what to look for [46:30];
- Prevalence of skin cancer and the importance of early detection [49:30];
- Summary of the major risk factors for melanoma [54:15];
- The role of sunscreen in reducing skin cancer risk [55:45];
- How sunscreen works, the differences between chemical and mineral sunscreens, an explanation of SPF, and more [58:30];
- How to determine the appropriate sunscreen SPF to use based on the UV index [1:04:45];
- Choosing the right sunscreen for your individual needs [1:07:00];
- The impact of water and perspiration on sunscreen effectiveness [1:12:00];
- Chemical vs. mineral sunscreens: safety concerns and recommendations [1:14:00];
- Concerns about hormone effects from chemical sunscreens [1:19:15];
- Sunscreen summary: skin types, key considerations, recommended brands, and more [1:23:15]; and
- More.

§

The Peter Attia Drive

Sun exposure, sunscreen, and skin health: relationship between sun exposure and skin cancer, vitamin D production, and photoaging, how to choose a sunscreen, and more

§

## Show Notes

§

## The impact of UV radiation on the skin [2:00]

Today’s AMA topics:

- Focus on skin cancer and sunscreen
- There has been a high volume of questions and prevalent confusion about these topics
- The team dedicated months of work to study these topics

For the discussion on skin cancer

- Peter talks about the importance of understanding the impact of UV radiation on the skin
- Part of that will be about the key aspects of UV radiation including…
  - A brief explanation of UV radiation.
  - And the three main impacts of UV radiation:
    - 1) Vitamin D Conversion: How UV light facilitates the production of vitamin D in the skin.
    - 2) Photoaging: The effect of ultraviolet light on skin aging.
    - 3) Role in Skin Cancer: How UV radiation contributes to the development of different skin cancers

## Understanding solar UV: from the electromagnetic spectrum to skin health [3:45]

***When we say solar UV, what are we referring to?***

![](https://peterattiamd.com/wp-content/uploads/2024/06/f1-ama61.png)

**Figure 1.** Sources: [NPR](https://www.kunc.org/science/2020-07-21/long-waves-short-waves-and-heat-waves-cu-researcher-explains-weather-and-climate). [Power Electronic Tips](https://www.powerelectronictips.com/when-it-comes-to-uv-c-led-lights-buyer-beware/), [Office of the Surgeon General (US)](https://www.ncbi.nlm.nih.gov/books/NBK247164/); 2014

Electromagnetic Spectrum Overview: *What is happening when wavelengths across an electromagnetic spectrum change in size?*

Different types of waves explained:

- Sound Waves: Longer wavelengths can bend around corners, making them audible even when the source is not in direct sight.
- Light Waves: Shorter wavelengths are visible to the human eye but cannot bend around corners like sound waves.
- Visible Light Spectrum
  - The visible spectrum of light ranges from 400 to 700 nanometers.
  - This range represents only a small part of the entire electromagnetic spectrum, including everything from red light to blue light.
- Ultraviolet Light
  - Ultraviolet light exists from about 100 to 400 nanometers, just below the visible light spectrum.

**More about ultraviolet light**—it is divided into three types:

- UVA: 315 to 400 nanometers.
- UVB: 280 to 315 nanometers.
- UVC: 100 to 280 nanometers.

Characteristics of Ultraviolet Light

- Shorter wavelengths contain more energy.
- Common misconceptions about microwaves:
  - Microwaves have longer wavelengths than visible light.
  - Visible light is more energetic than microwaves, so standing next to a microwave is not more dangerous than exposure to visible light.

Ultraviolet A, B, and C

- UVA: Longest wavelength, lower energy, penetrates deeper into the skin, contributing to aging and long-term skin damage.
- UVB: Shorter wavelength, higher energy, responsible for sunburn and crucial for vitamin D conversion in the skin.
- UVC: Shortest wavelength, highest energy, but does not reach Earth’s surface due to atmospheric absorption, so it is not a concern for skin exposure.

Relevance of UVA and UVB: UVA and UVB are the primary types of UV radiation that reach Earth’s surface.

- UVA:
  - Broader band (315 to 400 nanometers).
  - Accounts for 95% of UV radiation exposure.
  - Penetrates deeper into the skin but is less ionizing.
- UVB:
  - Narrower band (280 to 315 nanometers).
  - Accounts for 5% of UV radiation exposure.
  - Higher energy, causes sunburn, and aids in vitamin D conversion.

Conclusion of UV Radiation Explanation

- UV light, visible light, and other forms of energy differ significantly.
- UVA and UVB have specific impacts on skin health, with UVA penetrating deeper and contributing to aging, while UVB causes sunburn and helps in vitamin D synthesis.

## The role of sunlight in vitamin D production [8:30]

Vitamin D Synthesis—The role of UVB light:

- UVB light converts D2 (previtamin D3) into D3 (active vitamin D)
- Additional requirement of heat
  - Heat, including the body’s natural heat, is necessary for this conversion.
  - Sunlight combined with body heat facilitates the production of vitamin D3.

**Forms and Sources of Vitamin D**

*Vitamin D3*:

- Most common form found in the body and in supplements.
- Often labeled as D3 in supplements available on the market.

*Sources of Vitamin D*:

- Sunlight: UVB exposure on the skin.
- Food: Fatty foods like fish oil, eggs, and fortified dairy products.
- Supplements: Available in various forms, typically as D3.

*Key Points*

- Molecular Consistency: Regardless of the source (sunlight, food, or supplements), vitamin D remains the same fat-soluble molecule.
- Importance of Fat Solubility: Vitamin D needs to be absorbed in a fat-soluble manner to be effective in the body.

**Overall**:

- The production of vitamin D involves a combination of UVB radiation and body heat.
- Vitamin D is essential for health and can be obtained through various means: sunlight, dietary sources, and supplements.

## Factors contributing to vitamin D deficiency: insufficient UV exposure, magnesium levels, and more [9:45]

Lack of a clear definition for vitamin D deficiency:

- Medically defined as a vitamin D level less than 15 ng/mL.
- Some labs consider it deficient if less than 30 ng/mL.
- In Peter’s practice, levels below 30 ng/mL are considered deficient.

Association with reduced sun exposure:

- There is a clear correlation between lower vitamin D levels and less time spent in the sun.

However, there are some complicating factors…

- Adipose tissue:
  - Vitamin D is a fat-soluble vitamin.
  - More adipose tissue leads to greater sequestration of vitamin D in fat cells.
  - Thus, obesity is a potential risk factor for low vitamin D levels.
- Skin Tone:
  - Higher melanin levels provide more protection from UV radiation.
  - Darker-skinned individuals convert less UV radiation to vitamin D, resulting in lower vitamin D levels.
- Magnesium levels:
  - Magnesium is essential for the enzymatic conversion of vitamin D (discussed in [AMA #54](https://peterattiamd.com/ama54/))
  - Suboptimal magnesium levels impede vitamin D metabolism.
  - Many people may not have optimal magnesium levels, affecting their vitamin D status.

Overcoming vitamin D deficiency with supplements:

- Vitamin D supplements can help address deficiencies, especially when UV exposure is insufficient.

Factors affecting UV exposure and vitamin D production:

- Variables influencing UV exposure include…
  - Skin Type: Different skin types require different amounts of UV exposure for adequate vitamin D production.
  - Geographical Location: Latitude and altitude impact UV radiation levels.
  - Time of Day: UV radiation varies throughout the day.
  - Skin Surface Area Exposed: The amount of skin exposed to sunlight affects vitamin D synthesis.

Overall:

- Vitamin D deficiency is influenced by multiple factors, including adipose tissue, skin tone, and magnesium levels.
- While sunlight exposure is crucial, supplementation may be necessary to maintain adequate vitamin D levels.
- Understanding individual needs based on skin type and environmental factors is important for addressing vitamin D deficiency.

## Sun exposure needs for different skin types, and the limitations of current studies in defining vitamin D deficiency [12:45]

**There are six skin types that are described on something called the Fitzpatrick scale**:

- A semi-quantitative scale describing skin color by basal complexion and melanin response to UV.
- Six skin types, ranging from most pale to least.

![](https://peterattiamd.com/wp-content/uploads/2024/06/f2-ama61-1024x342.png)

**Figure 2.**

- Type I:
  - Very pale, white skin.
  - Burns very easily, does not tan.
- Type II:
  - White skin.
  - Burns easily, doesn’t tan much, but can develop a light tan under the right circumstances.
- Type III:
  - White skin.
  - Might burn, but tans fairly easily.
- Type IV:
  - Light brown or olive skin.
  - Hardly burns, tans easily.
  - Example: Peter is a Type IV.
- Type V:
  - Brown skin.
  - Usually doesn’t burn, tans very easily.
- Type VI:
  - Black skin.
  - Unlikely to burn, becomes significantly darker with substantial UV exposure.

Sun Exposure Requirements for Adequate Vitamin D

- Caucasians (defined as type I-III):
  - Generally require minimal sun exposure to maintain sufficient vitamin D levels.
  - Example: A [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5946282/) noted that Types I-III need as little as nine minutes of midday sun exposure per day during the summer months in the Northern Hemisphere (March to September), with at least one-third of their body exposed, to achieve adequate vitamin D levels.
  - Note: One-third body exposure implies wearing shorts and a T-shirt.
- Darker Skin Types (Type V):
  - Example: South Asian populations.
  - Require significantly more sun exposure, approximately three to four times more, under the same conditions to achieve the same vitamin D levels as Types I-III.

Important Considerations

- Definition of Deficiency:
  - The [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5946282/) referenced defines deficiency as below 25 nanomoles per liter (10 milligrams per milliliter), which is considered highly deficient.
  - Peter considers this level to be about three times lower than what they consider deficient.
- Latitude Impact:
  - Geographic location (latitude) plays a crucial role in determining sun exposure needs.
  - Sun exposure needs can vary significantly based on one’s location.

Conclusion

- Optimal Sun Exposure:
  - It’s unnecessary to spend hours in the sun daily, but regular sun exposure is important for vitamin D production if you rely solely on sunlight rather than supplements.
  - Understanding individual skin type and geographic factors is essential for determining appropriate sun exposure for maintaining adequate vitamin D levels.

## The acute and long-term effects of excessive UV exposure: sunburn, photoaging, and the increased risk of skin cancer [15:30]

**Too Much UV and Vitamin D**: There is no such thing as excessive UV exposure resulting in too much vitamin D

**Other Effects of Excessive UV Exposure**

1 Sunburn:

- Acute and painful reaction to too much sun exposure.
- Immediate impact that can lead to further complications, including skin cancer.

2 Photoaging:

- Definition: Wrinkles and sagging skin that occur due to aging are accelerated by sun exposure.
- Mechanism:
  - UV exposure, particularly UVA and UVB, causes the epidermis to thicken as a defense mechanism.
  - Decrease in extracellular matrix proteins like collagen.
  - Likely caused by UV-related increases in the expression and activity of proteins and enzymes responsible for degrading the extracellular matrix (ECM).
- Example of Photoaging: Case study:
  - Image from the New England Journal of Medicine shows a truck driver who spent 32 years with the left side of his face exposed to the sun.

![](https://peterattiamd.com/wp-content/uploads/2024/06/f3-ama61.png)

**Figure 3.** Source: [Gordon and Brieva NEJM, Apr 2012](https://www.nejm.org/doi/full/10.1056/NEJMicm1104059)

- Observations:
  - Significant difference in the aging and appearance between the left and right sides of his face.
  - Left side, exposed to more sunlight, shows more pronounced aging.
  - Even with the window mostly closed, some UV penetration occurred, demonstrating the cumulative effect of UV exposure.

3 Skin Cancer Risk:

- This would be the most important concern
- Excessive UV exposure increases the risk of developing skin cancer, including melanoma and other types.

Conclusion—Balanced approach needed:

- While sun exposure is necessary for vitamin D production, excessive UV exposure has serious consequences, including sunburn, photoaging, and increased skin cancer risk.
- It is important to balance sun exposure with protective measures to mitigate these risks.

## Types of skin cancer and associations with UV exposure [17:45]

**Types of Skin Cancer**

- There are basically three types of skin cancer and they have to do with which cell is the cell of origin
- Squamous Cell Carcinoma: Originates from squamous cells.
- Basal Cell Carcinoma: Originates from basal cells.
  - And there are plenty of randomized control [trials](https://pubmed.ncbi.nlm.nih.gov/10475183/) that demonstrate how sunscreen can reduce the incidence of these two
- Melanoma: Originates from pigment-producing cells.

*Association with UV Exposure*

- Squamous Cell Carcinoma (SCC) and Basal Cell Carcinoma (BCC) have a clear association with UV exposure.
- Many randomized control [trials](https://pubmed.ncbi.nlm.nih.gov/17132769/) show sunscreen can reduce the incidence of these cancers.

*Incidence*:

- BCC: Accounts for about 80% of non-melanoma skin cancers.
- SCC: Accounts for the remaining 20% of non-melanoma skin cancers.

*Metastatic Potential*

- Conventional thinking is that BCC and SCC are often considered non-metastatic.
- They are generally not lethal and may only cause cosmetic issues if left untreated.
  - However, this is not entirely true
- With basal cell carcinoma, up to 0.5% can metastasize, particularly if the primary tumor is large or an aggressive subtype (e.g., infiltrative BCC).
  - And there is higher risk in immunocompromised individuals (e.g., those on immunosuppressive medications or post-organ transplant).
- With squamous cell carcinoma, the metastasis rate is potentially up to 10%.
  - Risk factors include tumor size (over two centimeters in diameter, more than four millimeters in depth), immunocompromised status, and poor differentiation on histology.
- “*So even though squamous cells and basal cells are almost never fatal, they actually pose a risk for developing melanoma*.” says Peter

**Risk for Developing Melanoma**

[New Hampshire Skin Cancer Study](https://pubmed.ncbi.nlm.nih.gov/24937304/):

- Participants with non-melanoma skin cancer (BCC or SCC) had a more than threefold increase in the risk of developing melanoma.
- The study raises the question of whether the factors causing BCC and SCC (e.g., sun exposure) also contribute to melanoma risk.
- Hazard Ratios were quite large…
  - BCC: 3.28
  - SCC: 3.62

**Explanation of Metastatic Cancer**

*Hallmarks of lethal cancer*:

- Uncontrolled growth—Normal cells know when to stop growing; cancer cells do not.
- Capacity to Spread (Metastasis)—Cancer cells can leave the site of origin and spread to other parts of the body (e.g., lymph nodes, lungs, bones).
- Metastasis is the primary reason why cancer can be lethal.

*Examples*:

- Breast Cancer—Non-lethal if confined to the breast; Lethal if it spreads to bones, lungs, brain, or other tissues.
- Brain Cancer—Can be lethal even without spreading due to local effects.

**Importance of Early Detection and Prevention**: Understanding the types and risks associated with skin cancer, especially those influenced by UV exposure, underscores the importance of prevention (e.g., sunscreen use) and regular skin checks to catch potential issues early.

## The complex relationship between melanoma and UV exposure [22:15]

**Controversy and Complexity**

- A common assumption is that the biggest risk factor for melanoma is sun exposure.
- The reality is that there is conflicting data when examined closely.
- For instance, people who work outdoors often show no increase and potentially lower risk of melanoma compared to indoor workers.

*Example Studies*:

- This [European case-control study](https://pubmed.ncbi.nlm.nih.gov/26995016/) found no association of melanoma with outdoor workers despite higher photodamage and increased risk of basal and squamous cell carcinomas.
- The [Nurses’ Health Study Part II](https://pubmed.ncbi.nlm.nih.gov/24876226/) found no association found between total UV exposure and melanoma.

*Possible Explanations for Conflicting Data*

- Sun Sensitivity:
  - Type 1 and type 2 skin who are highly likely to burn, less likely to tan.
  - Such individuals spend less time outside, avoiding jobs with high sun exposure, thus reducing melanoma risk.
- Photoadaptation:
  - Type 3 and type 4 skin who can burn and tan.
  - Consistent low-level exposure may lead to photoadaptation, increasing pigmentation and skin thickness, offering short-term protection despite long-term UV damage risks.

**Paradox of photoprotection:** Increased pigmentation may offer short-term protection, but it indicates UV radiation damage.

- The relationship between UV light and melanoma is more complicated than with squamous cell and basal cell carcinomas.
- Conflicting data make it difficult to draw clear conclusions.

## Why UV exposure alone doesn’t necessarily explain the risk for melanoma [25:15]

**Why UV exposure alone doesn’t necessarily explain the risk for melanoma**:

*There’s a model called the* [*Divergent Pathway Model*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8533762/)*, and it proposes two different manners in which people develop melanoma*:

- 1 Cumulative Solar Damage (CSD) Model: Melanomas arise from a cumulative amount of ultraviolet damage, presumably to the DNA, over time
- 2 Nevogenic Approach:
  - Melanomas arise from genetic proneness to melanocyte proliferation.
  - High mole (nevi) count individuals are at risk.
  - Typically arise on the trunk with intermittent sun exposure.

*Distinguishing features and mutations*

- CSD Model:
  - Observed in individuals with low nevi count.
  - Tend to appear on the head and trunk, areas with consistent sun exposure.
  - Associated with p53 mutations.
- Nevogenic Model:
  - High nevi count individuals.
  - BRAF mutations are common.
  - Require very intermittent sun exposure.

⇒ BRAF and p53 were discussed on the [podcast with Keith Flaherty](https://peterattiamd.com/keithflaherty2/), does a lot of research in melanoma

Genetic Susceptibilities

- Fair-skinned individuals, redheads, and those with light eyes have higher melanoma risk.
- [Genome-wide association studies](https://pubmed.ncbi.nlm.nih.gov/19578364/) have identified several gene loci linked to melanoma risk.
- Example:
  - MC1R gene mutation affects melanin production and DNA repair, increasing UV damage susceptibility.
  - That means that these individuals do not really have any protective effect of producing more melanin, i.e., adapting to and protecting themselves from the sun. So they’re actually more susceptible to DNA damage from UV

**Key Takeaways**

- Unlike squamous cell and basal cell carcinomas, melanoma has a more complex relationship with UV exposure.
- UV exposure plays a role but is not the sole factor.
- Genetic factors significantly contribute to melanoma risk, explaining why some populations are more susceptible.

## Other risk factors for melanoma [29:15]

Family History:

- A family history of melanoma significantly raises the concern for melanoma.
- A family history of basal cell or squamous cell carcinomas does not raise the same level of concern.

Skin Type:

- Lighter skin types are at higher risk for melanoma.
- Fair-skinned individuals, particularly those with blonde or red hair and blue or green eyes, are more susceptible.

Personal History of Sunburns

- A history of blistering sunburns, especially during the ages of 15 to 20, increases the risk of melanoma.
- [Nurses’ Health Study Part II](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4151553/) found a significant increase in risk for melanoma, basal cell carcinoma, and squamous cell carcinoma among women who had at least five blistering sunburns in their youth.
- [Caucasian Women Study](https://ascopost.com/News/16266#:~:text=According%20to%20a%20large%20study,cell%20carcinoma%2C%20and%20an%2080%25): Showed a 68% increase in risk for squamous cell carcinoma, 68% for basal cell carcinoma, and 80% for melanoma for those with a history of sunburns.
- [Norwegian Women Study](https://pubmed.ncbi.nlm.nih.gov/36197657/): Compared women with low and high lifetime sunburn frequency and found a 50% increase in relative risk of melanoma for those with more frequent sunburns.

Recommendations

- Avoiding Sunburns:
  - Regardless of the exact impact on melanoma risk, avoiding sunburns is advisable to reduce photoaging and potential skin damage.
- Childhood Sun Exposure:
  - Emphasize protecting children from severe sunburns to potentially reduce future melanoma risk.
- Use of hats, shirts, and UV-repellent clothing is encouraged.

## Tanning beds and skin cancer risk [34:45]

General Stance on Tanning Beds

- No Justification for Use: Peter states that there is no case to be made for the use of tanning beds.
- Tanning beds involve a paradox: while pigmentation from tanning offers some defense against UV damage, this photoprotection results from UV damage itself.

UVA and UVB Exposure from Tanning Beds

- High UVA and UVB Doses:
  - Tanning beds use a very high dose of UVA, typically 10 to 15 times higher than what is found in natural sunlight.
  - They provide a similar dose of UVB as the sun, resulting in a very high or extreme UV index.

Risk of DNA Damage:

- Both UVA and UVB can induce DNA damage, contributing to skin cancer risk.
- Indoor tanning may lead to fewer sunburns because users are more aware of their exposure time, but this doesn’t negate the risks.

[Meta-Analyses](https://pubmed.ncbi.nlm.nih.gov/34885049/) on Skin Cancer Associations

- Meta-analyses show a significant association between indoor tanning bed use and various forms of skin cancer, including melanoma.
- Melanoma Risk: Approximately a 27% increase in melanoma risk associated with tanning bed use.
- Squamous Cell Carcinoma Risk: About a 40% to 58% increase in risk.
- Basal Cell Carcinoma Risk: Around a 24% increase in risk.
- Higher Risk for Younger Users:
  - For individuals below the age of 50, the risk of early-onset skin cancer is higher:
  - Melanoma: 75% increase
  - Squamous cell carcinoma: 81% increase
  - Basal cell carcinoma: 75% increase

Conclusion

- Despite indoor tanning potentially leading to fewer sunburns, it significantly increases the risk of all forms of skin cancer.
- This elevated risk is present even when tanning beds predominantly provide UVA over UVB.

## Balancing sun exposure: benefits and risks [38:15]

***How do you think about, for you, for your patients, for your family, balancing the benefits and risks of sun exposure?***

Importance of Sun Exposure

- Peter emphasizes that the discussion should not lead to the conclusion that one should avoid sun exposure entirely.

> “*To be clear, I think the physical and psychological costs of not being in the sun are catastrophic*.” —Peter Attia

Inverted U-Curve in Sun Exposure

- Sun exposure follows an inverted U-curve, common in biology.
- Neither extreme of sun exposure—zero or excessive—is ideal.

Role of Vitamin D

- Vitamin D from Sun vs. Supplements: Solely relying on vitamin D supplements without any sun exposure is not considered healthy.
- Epidemiological Insights: Benefits associated with high vitamin D levels *might be more about the active lifestyle that accompanies sun exposure rather than the vitamin itself*.

Personalized Approach to Sun Exposure

- When advising patients, factors such as skin type, family history, and geographical location are considered.
- The goal is to achieve the benefits of outdoor activity and sun exposure while minimizing the risks.
- A tailored approach ensures patients get the benefits of sun exposure and vitamin D while protecting themselves from the potential harms of excessive UV exposure.

## Tattoos and sun exposure [40:30]

***What about the relationship between tattoos, sun exposure, and skin cancer risk, given the increased prevalence of tattoos?***

- [Studies](https://pubmed.ncbi.nlm.nih.gov/22469126/) have investigated the potential carcinogenic risk of tattoo ink, but no studies have shown an excess risk of skin cancer associated with tattoos.
- There is a challenge that tattoos pose in detecting skin cancers, especially melanomas.
- Skin cancers, particularly melanomas, are often identified by changes in moles or the appearance of new moles.
- Tattoos can obscure these changes, making early detection more difficult.
- While there’s no evidence that tattoos increase skin cancer risk, individuals with tattoos should be extra vigilant with regular skin checks in order to monitor their skin for changes to detect potential skin cancers early.

## The importance of regular skin checks, dermatologists, and emerging technologies showing promise for early detection of cancer [41:45]

**Questions around skin checks**:

- People who have moles often wonder how often they should get their skin checked by a dermatologist?
- When should they start?
- How do you operate as it relates to skin checks by a dermatologist as opposed to just even a self-skin check?

Lack of Formal Recommendations

- Unlike other cancers (breast, colon, lung), there are no formal recommendations from the USPSTF, CDC, or American Cancer Society for skin cancer screening.
- The reason cited is “insufficient evidence that the benefits outweigh the potential harms.”
- Potential Harms: Peter says he’s not entirely clear what the potential harms are except for…
  - Psychological harms
  - Maybe minimal cosmetic harms from procedures like shave biopsies.
  - Human detection variability (which plays a bigger role than say mammography or colonoscopy).

Dermatologist Visits

- Annual Check-Ups: Peter recommends at least annual screenings for his patients.
- Higher-risk patients are advised to get screened twice a year.
- Specialist Focus: It is crucial to see dermatologists who specialize in melanoma detection, not just cosmetic dermatology.

Importance of Self-Skin Checks

- Self-checks are valuable because individuals can monitor their skin more frequently than annual dermatologist visits.
- Family members can help check hard-to-see areas.

Emerging Technologies

- [Total Body Photography](https://melanoma.org.au/wp-content/uploads/2022/08/MIA22-TOTAL-BODY-PHOTOGRAPHY_update.pdf): New technology using total body photography is promising for better tracking changes in the skin.
- AI-Powered Devices like the [DermaSensor](https://www.dermasensor.com/):
  - Cleared by the FDA.
  - Uses elastic scattering spectroscopy to evaluate lesions.
  - Small [study](https://pubmed.ncbi.nlm.nih.gov/38371666/) of 300 patients with 440 lesions showed the following…
    - High sensitivity (99.5%) for detecting melanoma.
    - Lower specificity (32.5%), meaning many false positives.
    - High negative predictive value (98+%), meaning it accurately identifies non-melanomas.

> “*This is the beginning of a type of technology that I hope, over the coming decade, can make screening, especially for melanoma, to be a more effective tool*.” —Peter Attia

Future of Skin Cancer Screening

- AI shows potential in recognizing changes in lesions over time, potentially improving early detection.
- The goal is to catch melanomas early while minimizing unnecessary removals of non-cancerous lesions.

## Self-skin checks: what to look for [46:30]

Importance of Self-Checks

- Frequency: Monthly self-checks provide more monitoring than annual dermatologist visits.
- Use mirrors or enlist help from a spouse or friend to check hard-to-see areas.

A, B, C, D, E of Lesions

- A: Asymmetry:
  - Perfectly round lesions are less concerning.
  - Lesions that are uneven or bulging on one side are more concerning.
- B: Border:
  - Smooth borders are less concerning.
  - Irregular or jagged edges are more concerning.
- C: Color:
  - One consistent color is lower risk.
  - Multiple colors, especially darker in one part and lighter in another, are higher risk.
- D: Diameter:
  - Lesions larger than six millimeters in diameter are more concerning.
- E: Evolution:
  - Lesions that change over time are more concerning.
  - Lesions that remain static for long periods are generally less concerning.

![](https://peterattiamd.com/wp-content/uploads/2024/06/f4-ama61.png)

**Figure 4.** Source: [American Academy of Dermatology](https://www.aad.org/public/diseases/skin-cancer/find/at-risk/abcdes)

Additional Signs to Watch For

- Non-Healing Wounds: Moles or lesions that bleed and do not heal over time require attention.
- Pay special attention to any changes in existing moles or the appearance of new ones.

Consulting a Dermatologist

- Dermatologists will have a very low threshold to take these things off because the cost of doing so is trivial
- Removing suspicious lesions is a minimally invasive procedure
- Removal can provide peace of mind, prevent potential issues, and may even help for purely aesthetic reasons

## Prevalence of skin cancer and the importance of early detection [49:30]

**Peter’s personal experience with patients**

- In the grand scheme of things, skin cancer is not a top 10 killer.
- But Peter admits he does have an emotional reaction to it because of the time he spent at the National Cancer Institute, both as a medical student and as a fellow, where his work focused on immunotherapies for patients with melanoma
- As a result of that, Peter has witnessed many people dying of metastatic melanoma
- And many of the patients were very young
- One case of a woman who had just gotten married and, on her honeymoon, discovered a mole that looked a bit suspicious, and by the time they got to it, it was quite deep and it had spread.

**Prevalence of Skin Cancer**

- Basal Cell Carcinoma:
  - Most prevalent type of skin cancer.
  - Approximately 3.5 million cases diagnosed annually in the US.
- Squamous Cell Carcinoma:
  - Just under 2 million cases per year in the US.
- Melanoma:
  - About 100,000 new cases per year in the US.
  - Approximately 8% mortality rate.

**Impact of Early Detection**

- Lifetime Risk:
  - 2.2% for the general population.
  - Higher in Caucasians, lower in African-Americans.

![](https://peterattiamd.com/wp-content/uploads/2024/06/f5-ama61.png)

**Figure 5**. Source: [Lo et al. Annals of surgical oncology Apr. 2018.](https://pubmed.ncbi.nlm.nih.gov/29330716/)

- On the x-axis, it shows the depth of the original melanoma at the time of resection
- On the y-axis, it shows long-term survival
- You can see that for melanomas that are very thin, there’s a very high survival
- Early-stage melanoma (0.3 to 0.8 millimeters in depth) has a 90% long-term survival rate.
- Survival rates decrease significantly as melanoma thickness increases.
- At about four millimeters, survival rates drop below 50%.
- Peter points out that these data are a little bit old, and today the numbers are actually better as a result of the immunotherapies that we have

Timing for Skin Checks and a Common Sense Approach:

- If you notice something suspicious, get it checked out promptly.
- Ideally, schedule an appointment within a week or two.
- Delaying by a few weeks is generally acceptable if immediate action would disrupt your life significantly.

## Summary of the major risk factors for melanoma [54:15]

Family and Personal History

- Family History:
  - A family history of melanoma significantly increases risk.
  - Family history of any skin cancer may also be suggestive of increased risk.
- Personal History: Individuals with a personal history of skin cancer, including melanoma, squamous cell carcinoma, and basal cell carcinoma, are at higher risk.

Skin Type and Physical Characteristics

- Skin Types:
  - Types 1, 2, and 3 (lighter skin types) are at greater risk.
  - Easier to burn and harder to tan.
- Hair and Eye Color: Blonde or red hair and blue or green eyes are associated with higher risk.

Other Risk Factors

- Weakened Immune System: Individuals with weakened immune systems have increased susceptibility.
- Indoor Tanning: History of indoor tanning is linked to a higher risk of melanoma.

Recommendations

- Self-Exams: Be diligent with self-examinations if you fall into any of the higher risk categories.
- Dermatologist Visits: Even without formal recommendations, consider regular comprehensive skin exams by a dermatologist, especially if you have several risk factors.

## The role of sunscreen in reducing skin cancer risk [55:45]

***What do we know about sunscreen and if it reduces the risk of skin cancer?***

Evidence from Studies

[Randomized Control Trial in Australia](https://pubmed.ncbi.nlm.nih.gov/10475183/):

- Participants: Caucasians.
- Findings: Daily sunscreen use led to a 40% reduction in squamous cell carcinoma compared to discretionary use.
- Melanoma: [10-year follow-up](https://pubmed.ncbi.nlm.nih.gov/21135266/) showed a non-significant reduction in melanoma risk but a significant reduction in invasive melanoma risk (73% reduction, though with wide confidence intervals).

Challenges in Drawing Conclusions

- Behavioral Factors: Follow-up behavior and sun exposure habits during the study period are not well-documented, making long-term conclusions difficult.
- Multifactorial Pathogenesis: Skin cancer, especially melanoma, results from multiple factors, complicating the assessment of sunscreen’s direct impact.
- Inconsistency in Application: Variations in how people apply sunscreen (amount, frequency) add to the complexity of deriving clear conclusions.

Supporting evidence in animal models

- All that said, in animal models where the investigators have complete control over how the sunscreen is applied, they are protective
- In these models, sunscreens are indeed protective against UV-induced cell damage and carcinogenesis

Additional Benefits of Sunscreen

- Photoaging and Burning: Sunscreen is effective in protecting against photoaging (wrinkles, sagging skin) and sunburn.

## How sunscreen works, the differences between chemical and mineral sunscreens, an explanation of SPF, and more [58:30]

***How does sunscreen actually protect the skin from UV radiation? What are the mechanisms there?***

Types of Sunscreens

- 1 Chemical (Organic) Sunscreens:
  - Composition: Carbon-based molecules (hydrocarbons).
  - Mechanism: Absorb UV radiation and convert it into heat, preventing UV from reaching the skin.
- 2 Mineral (Inorganic) Sunscreens:
  - Composition: Zinc oxide or titanium dioxide.
  - Mechanism: Absorb UV radiation and convert it into less harmful forms of energy (heat).
  - Misconception: Often thought to physically block UV radiation due to their white appearance, but they primarily work by absorption.

Understanding SPF (Sun Protection Factor)

- Definition: SPF measures how much solar exposure (not time) is needed to cause sunburn on protected skin compared to unprotected skin.
- Testing: Conducted on individuals with skin types 1 to 3, using controlled UV exposure until skin reddening is achieved.
- SPF Ratings:
  - SPF 30: 1/30th of UV radiation reaches the skin.
  - SPF 50: 1/50th of UV radiation reaches the skin.

Factors Influencing SPF Needs

- UV Exposure: Varies based on time of day, geographic location, altitude, and weather conditions.
- Skin Type: Lighter skin types (1 to 3) require higher SPF for adequate protection.
- Broad Spectrum Sunscreens: Effective at blocking both UVA and UVB rays.

UPF (Ultraviolet Protection Factor) in Clothing

- Similar to SPF: Measures the effectiveness of fabric in blocking UV radiation.
- Typical Values:
  - Cotton T-shirt: UPF of 5.
  - Specialized Clothing: UPF 30 to 50, providing significant protection.

Considerations for High SPF Sunscreens

- Potential Issues:
  - False sense of security leading to less frequent application.
  - Higher SPF levels are harder to test accurately.
  - Increased reliance on organic compounds with potential health concerns.

Recommended Approach:

- Use sunscreens with SPF 30 to 50 (FDA proposes not using SPFs above 60)
- Reapply frequently rather than relying on high SPF for prolonged protection.

## How to determine the appropriate sunscreen SPF to use based on the UV index [1:04:45]

**Assessing UV Exposure**

- Importance of Knowing UV Index: The UV index provides an immediate measure of the UV radiation level at any given time and location.
- Factors influencing UV index: time of day, season, altitude, latitude, ozone layer, and cloud cover.
- UV index scale: 1 to 11+
  - Low: <2
  - Moderate: 3-5
  - High: 6-7
  - Very High: 8-10
  - Extreme: 11+

Practical Advice

- Using Technology:
  - Use geolocated apps on your phone to check the UV index daily (look at your weather app)
  - These apps provide more accurate and immediate information compared to guessing or estimating based on weather conditions.
- Skin Type Considerations:
  - Lighter Skin Types (1-3):
    - Should use sunscreen when the UV index is 3 or above.
  - Darker Skin Types (4 and above):
    - May have more flexibility but should still be cautious in high UV conditions.
- Adjust sunscreen usage based on daily UV index readings.
- Peter, with type 4 skin, starts using sunscreen at a UV index of 5 or 6.

## Choosing the right sunscreen for your individual needs [1:07:00]

**Key Considerations**

Compliance

- Compliance is the number 1 objective.
- Find a sunscreen that you don’t mind using because the bottom line is using any sunscreen is better than not

Application

- The typical guidelines don’t mean anything, it’s like two milligrams per centimeter squared
- A more helpful rule of thumb would be two tablespoons would be required to cover your total body
- for some people, spray sunscreens can be a pretty good option, however, they come with a lot of problems — Potentially, if you apply them during the wind, they can be all over the place
- For Peter, he prefers mineral or inorganic-based sunscreens that come in creams and lotions

SPF Level:

- Select an SPF that suits your sun exposure needs and skin type.
- Higher SPFs offer more protection but can give a false sense of security if not reapplied properly.

Type of Sunscreen:

- Chemical/Organic Sunscreens:
  - Lighter sunscreen and more sheer.
  - More likely to cause skin reactions.
- Mineral/Inorganic Sunscreens:
  - Tend to be a bit heavier with a white film.
  - But less likely to irritate the skin.

Personal Preferences and Compliance

- User Experience:
  - Find a sunscreen you are comfortable using regularly.
  - Factors like greasiness, odor, and ease of application matter.
- Peter’s personal favorite brand:
  - [EltaMD](https://eltamd.com/collections/sun-care)
  - Mineral-based, non-greasy, odorless, high compliance.
  - Comes in SPF 30 or 50.

## The impact of water and perspiration on sunscreen effectiveness [1:12:00]

Water-Resistant Sunscreens

- Standard for Water Resistance:
  - In the US, sunscreens claiming water resistance must maintain their SPF for 80 minutes in still water.
  - Example: An SPF 50 sunscreen must still provide SPF 50 protection after 80 minutes of sitting in still water.

Real-World Application

- Swimming vs. Still Water:
  - The real-life effectiveness of water-resistant sunscreens may differ from controlled conditions.
  - Moving through water (swimming) and having water run across the skin can reduce sunscreen efficacy.
  - Activities like toweling off or rolling in sand further reduce the effectiveness of water-resistant sunscreens.

Perspiration and Sunscreen

- Impact of Sweat:
  - No regulatory process currently quantifies the impact of perspiration on sunscreen effectiveness.
  - Sweat can move sunscreen, especially on hot days during activities like rucking.
  - Sunscreen can drip into eyes, reducing its protection on the forehead.

Practical Tips

- In addition to sunscreen, use hats, sunglasses, and protective clothing to safeguard against UV rays.
- Reapply sunscreen frequently, especially after swimming or heavy sweating, to maintain protection.

## Chemical vs. mineral sunscreens: safety concerns and recommendations [1:14:00]

***Why have there been some recent concerns as it relates to chemical sunscreen and potential negative health effects?***

- Definition and Study Findings
- Chemical Sunscreens:
  - Use organic molecules (carbon-based) as UV absorbents.
  - A study in [JAMA](https://pubmed.ncbi.nlm.nih.gov/31961417/) highlighted that these molecules were absorbed by the skin at higher rates than initially predicted.

FDA Standards and Absorption Rates

- FDA Absorption Threshold:
  - If less than 0.5 nanograms per milliliter of the sunscreen’s active ingredients enter the plasma, it is considered not absorbed.
  - The [JAMA study](https://pubmed.ncbi.nlm.nih.gov/31961417/) found absorption levels significantly higher, ranging from 3 to 200 times above this threshold.

Ongoing Safety Studies

- Safety Data Collection:
  - New safety data are being collected on seven chemical sunscreen ingredients.
  - The FDA classifies these as category three in safety, meaning more studies are needed due to uncertainties about their safety at current usage levels.
- Mineral Sunscreens:
  - Zinc oxide and titanium dioxide are classified as category one (generally regarded as safe and efficacious).
  - No evidence suggests a hazard to the public at current or expected future levels.

[2020 Study](https://pubmed.ncbi.nlm.nih.gov/31961417/)

- Involved 48 subjects using four different chemical sunscreens.
- Applied 2 milligrams per centimeter squared to 75% of the body surface area.
- Sunscreens were applied once on day one and four times at two-hour intervals on days two through four.
- 34 blood samples were collected over 21 days.
- Findings:
  - Repeated applications led to higher plasma levels.
  - Lotions had higher absorption rates than sprays.
  - Oxybenzone had the highest absorption, with levels reaching 94.2 nanograms per milliliter after one application and 258 nanograms per milliliter after three days of multiple applications.

Implications and Recommendations

- Potential Risks: While there is no definitive evidence that these absorption levels are harmful, the ongoing studies are necessary to determine long-term effects.
- Preference for Mineral Sunscreens:
  - Given the uncertainties, using mineral sunscreens (zinc oxide or titanium dioxide) may be a safer choice.
  - These are less likely to be absorbed into the skin and are generally recognized as safe by the FDA.

## Concerns about hormone effects from chemical sunscreens [1:19:15]

***Peter receives some questions wondering about hormone effects as it relates to chemical sunscreen. Is there anything he’s seen on this topic?***

- Peter says, “*I can understand why there’s some concern about this, but I think you have to look more closely at how the studies are done*.”
- Oxybenzone is the primary concern — Cited in the [JAMA study](https://pubmed.ncbi.nlm.nih.gov/31961417/) for having high concentrations in the plasma, often 8-10 times higher than other compounds.
- Animal studies have raised concerns, but the dosing in these studies often doesn’t correlate with human use.

[Example of Animal Study](https://pubmed.ncbi.nlm.nih.gov/11333184/)

- Study Details:
  - Rats were orally fed 1,500 mg/kg per day of oxybenzone for four days.
  - Resulted in enlarged uteruses in immature female rats.
- Comparison to Human Exposure:
  - Human exposure levels, even with liberal application of sunscreen, are far lower.
  - Sunscreens typically contain no more than 6% oxybenzone, and application amounts are much smaller.

Dose-Response Relationship

- Dose Makes the Poison:
  - Extrapolating animal study results to humans can be misleading.
  - Example given: toxic doses of aspartame in animal studies don’t correlate with typical human consumption.

Recent Study on Endocrine Disruption

- In Vitro [Study](https://pubmed.ncbi.nlm.nih.gov/37561120/) (November 2023):
  - Compared effects of different sunscreens on endocrine disruption.
  - Found that endocrine disruption required concentrations about 100 times higher than what is found in human plasma with maximal use.
- Oxybenzone Exception:
  - Bioactivity and plasma concentrations suggesting endocrine disruption were only 6-7 times higher than typical human exposure.

Conclusions and Recommendations

- Most chemical sunscreens do not pose a significant risk of endocrine disruption at typical use levels.
- Oxybenzone is the closest to potentially harmful levels but still not conclusively problematic.
- Given the uncertainties, it might be wise to avoid oxybenzone.
- There are plenty of alternative sunscreens that do not carry the same potential risks.

## Sunscreen summary: skin types, key considerations, recommended brands, and more [1:23:15]

Key Takeaways

- Skin Types:
  - If you have skin types ranging from type one to type five, using sunscreen is crucial to avoid sunburn, photoaging, and potentially skin cancer.
- Variables to Consider:
  - Application Method: Lotion or spray.
  - SPF Level: Choose based on your skin type and the UV exposure you anticipate.
  - Type of Sunscreen: Organic (chemical) vs. inorganic (mineral).

Importance of Compliance

- The most important factor is to choose a sunscreen you are comfortable using regularly.
  - Compliance is key to effective sun protection.
- Personal Preference: The smell and feel of sunscreen can be a major factor. Find one that you don’t mind applying frequently.

Recommended Brands

- [EltaMD](https://eltamd.com/):
  - Odorless, non-greasy.
  - More expensive but worth it for high compliance.
- [Blue Lizard](https://bluelizardsunscreen.com/):
  - Mineral sunscreen, good for water activities.
  - Can be a bit greasy.

Chemical Concerns

- Recommendation: Avoid sunscreens with oxybenzone if possible due to potential endocrine disruption concerns.
- Future Research: Current studies are inconclusive, but being cautious may be beneficial until more definitive results are available.

Final Thoughts

- Understand the need for sun protection tailored to your individual and family needs.
- Regularly reapply sunscreen, especially during prolonged outdoor activities.

Future Developments:

- Stay updated with ongoing research regarding sunscreen ingredients and their long-term effects.
- Make informed choices based on the latest scientific evidence and personal experience.

§

## Selected Links / Related Material

**9 min of midday sun provides sufficient vitamin D for certain skin types**: [Meeting Vitamin D Requirements in White Caucasians at UK Latitudes: Providing a Choice](https://pubmed.ncbi.nlm.nih.gov/29673142/) | *Nutrients* (A Webb et al 2018) | [13:00]

**Definition of vitamin D deficiency**:  [Meeting Vitamin D Requirements in White Caucasians at UK Latitudes: Providing a Choice](https://pubmed.ncbi.nlm.nih.gov/29673142/) | *Nutrients* (A Webb et al 2018) | [14:30]

**Sunscreen can reduce Squamous cell and basal cell carcinomas**: [18:15]

- [Daily sunscreen application and betacarotene supplementation in prevention of basal-cell and squamous-cell carcinomas of the skin: a randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/10475183/) | *The Lancet* (A Green et al 1999)
- [Prolonged prevention of squamous cell carcinoma of the skin by regular sunscreen use](https://pubmed.ncbi.nlm.nih.gov/17132769/) | *Cancer Epidemiology, Biomarkers & Prevention* (J van der Pols et al 2006)

**New Hampshire Skin Cancer Study**: [Non Melanoma Skin Cancer and Subsequent Cancer Risk](https://pubmed.ncbi.nlm.nih.gov/24937304/) | *PLOS ONE* (J Rees et al 2014) | [20:30]

**No association of melanoma with outdoor workers**: [Skin cancer risk in outdoor workers: a European multicenter case-control study](https://pubmed.ncbi.nlm.nih.gov/26995016/) | *Journal of the European Academy of Dermatology and Venereology* (M Trakatelli et al 2016) | [23:00]

**Nurses’ Health Study II, no association between total UV exposure and melanoma**: [Long-term ultraviolet flux, other potential risk factors, and skin cancer risk: a cohort study](https://pubmed.ncbi.nlm.nih.gov/24876226/) | *Cancer Epidemiology, Biomarkers & Prevention* (S Wu et al 2014) | [23:45]

**Divergent pathway model for melanoma development**: [Mutational Characterization of Cutaneous Melanoma Supports Divergent Pathways Model for Melanoma Development](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8533762/) | *Cancers* (D Millan-Esteban et al 2021) | [25:30]

**Episode of The Drive which discussed melanoma as well as BRAF and p53 mutations**: [#267 ‒ The latest in cancer therapeutics, diagnostics, and early detection | Keith Flaherty, M.D.](https://peterattiamd.com/keithflaherty2/) | Peter Attia (peterattiamd.com)  [27:00]

**Genome-wide association studies on melanoma**: [27:30]

- [Genome-wide association study identifies three loci associated with melanoma risk](https://pubmed.ncbi.nlm.nih.gov/19578364/) | *Nature Genetics* (D Bishop et al 2009)
- [ASIP and TYR pigmentation variants associate with cutaneous melanoma and basal cell carcinoma](https://pubmed.ncbi.nlm.nih.gov/18488027/) | *Nature Genetics* (D Gudbjartsson et al 2008)

**Blistering sunburns from age 15-20 increases risk of skin cancer (Nurses’ Health Study II)**: [Long-term ultraviolet flux, other potential risk factors, and skin cancer risk: a cohort study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4151553/) | *Cancer Epidemiology, Biomarkers & Prevention* (S Wu et al 2014) | [30:45]

**Study of Norwegian women, increased sunburns associated with increased risk of skin cancer**: [Lifetime Sunburn Trajectories and Associated Risks of Cutaneous Melanoma and Squamous Cell Carcinoma Among a Cohort of Norwegian Women](https://pubmed.ncbi.nlm.nih.gov/36197657/) | *JAMA Dermatology* (S Lergenmuller et al 2022) | [32:30]

**Meta-analysis of tanning bed use and association with skin cancer**: [Indoor Tanning and the Risk of Overall and Early-Onset Melanoma and Non-Melanoma Skin Cancer: Systematic Review and Meta-Analysis](https://pubmed.ncbi.nlm.nih.gov/34885049/) | *Cancers* (S An et al 2021) | [37:15]

**Relationship between tattoos and skin cancer**: [40:45]

- [Skin cancers arising within tattoos: A systematic review](https://www.sciencedirect.com/science/article/pii/S2666328724000531) | *JAAD International* (J Leghar et al 2024)
- [Melanoma and tattoos: a case report and review of the literature](https://pubmed.ncbi.nlm.nih.gov/29171408/) | *European Journal of Dermatology* (F Ricci et al 2018)
- [Tattoos, inks, and cancer](https://pubmed.ncbi.nlm.nih.gov/22469126/) | *Lancet Oncology* (N Kluger & V Koljonen 2012)

**Study of DermaSensor**: [Multicenter prospective blinded melanoma detection study with a handheld elastic scattering spectroscopy device](https://pubmed.ncbi.nlm.nih.gov/38371666/) | *JAAD International* (R Hartman et al 2023) | [44:45]

**Use of sunscreen reduces risk of squamous cell carcinoma, RCT in Australia**: [Daily sunscreen application and betacarotene supplementation in prevention of basal-cell and squamous-cell carcinomas of the skin: a randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/10475183/) | *The Lancet* (A Green et al 1999) | [56:00]

**Sunscreen provides a non-significant reduction in risk of melanoma**: [Reduced melanoma after regular sunscreen use: randomized trial follow-up](https://pubmed.ncbi.nlm.nih.gov/21135266/) | *Journal of Clinical Oncology* (A Green et al 2011) | [56:30]

**Comparison of 4 organic/ chemical sunscreens, chemicals absorbed from them**: [Effect of Sunscreen Application on Plasma Concentration of Sunscreen Active Ingredients](https://pubmed.ncbi.nlm.nih.gov/31961417/) | *JAMA*(M Matta et al 2020) | [1:15:00]

**Study of oxybenzone in rats**: [In vitro and in vivo estrogenicity of UV screens](https://pubmed.ncbi.nlm.nih.gov/11333184/) | *Environmental Health Perspectives* (M Schlumpf et al 2001) | [1:20:00]

**Endocrine disruption by sunscreen, in vitro study**: [Comparison between endocrine activity assessed using ToxCast/Tox21 database and human plasma concentration of sunscreen active ingredients/UV filters](https://pubmed.ncbi.nlm.nih.gov/37561120/) | *Toxicology Sciences* (D Onyango et al 2023) [1:21:15]

§

## People Mentioned

- [Keith Flaherty](https://www.massgeneral.org/doctors/18371/keith-flaherty) [27:00]

§