# #73 – AMA #9: NAD & metformin, fat-burning zone, creatine, estrogenization of men, emergency kit for cold & flu, and more

**Source:** [https://peterattiamd.com/ama09/](https://peterattiamd.com/ama09/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a wide range of questions from subscribers. Bob Kaplan, Peter’s head of research, asks the questions. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/). You can also watch (or listen) to this full episode on our website at the AMA #9 [show notes page](https://peterattiamd.com/ama09). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The story of how Peter almost worked for Theranos [2:00];
- The trend of lower testosterone and higher estrogen in men: Why is it happening and what to do about it? [10:00];
- Takeaways from Peter’s recent hunting trip in Hawaii [14:45];
- What books are you currently reading/listening to? [21:30];
- What advice would you give to the 25 year-old Peter? [24:00];
- What is your emergency protocol if you start getting sick? [27:45];
- How have your thoughts changed on NAD precursors, and also on metformin, in the past year or so? [30:30];
- What are your thoughts on “fat burning” zones for cardio workouts? — A lesson in relative vs. absolute fat combustion [34:15];
- What mental models do you use and how do you go about solving problems and approaching difficult questions? [49:00];
- Creatine supplementation—Yay or nay? Why? [49:30]; and
- More.

§

The Peter Attia Drive

NAD & metformin, fat-burning zone, creatine, estrogenization of men, emergency kit for cold & flu, and more

§

## Show Notes

## The story of how Peter almost worked for Theranos [2:00]

⇒ For a primer on [Theranos](https://en.wikipedia.org/wiki/Theranos) and why this is even interesting…

- Give the [wiki page](https://en.wikipedia.org/wiki/Theranos) a quick read
- Also, check out this [HBO documentary](https://www.hbo.com/documentaries/the-inventor-out-for-blood-in-silicon-valley)
- Or the best selling [book](https://www.amazon.com/Bad-Blood-Secrets-Silicon-Startup/dp/152473165X/ref=sr_1_2?keywords=bad+blood&qid=1568749954&sr=8-2) by John Carreyrou

An offer from Theranos

- In 2006, Peter was working at McKinsey & Company in Palo Alto
- Theranos contacted him and he was offered their Chief Medical Officer position
- He met with [Elizabeth Holmes](https://en.wikipedia.org/wiki/Elizabeth_Holmes)
- They looked at the black box machine together and discussed business and technology

Decided not to take the job for several reasons

- First, someone Peter trusts did not say anything good about one of the investors in Theranos
- Secondly, loved his job at McKinsey
- Third, wasn’t convinced that what you could test in a box that size was interesting
  - “*I knew enough about diagnostics and…chemistry that I knew that there was…not going to be anything you could do on a drop of blood, in a box that size, that was clinically interesting.*”

8 years later

- In 2014, 8 years after declining the job, Forbes valued Theranos at $9 billion
- Calculated the money he would be worth if he had taken the job, “life changing money”

In 2015

- Peter was at a fundraising event where Elizabeth was the top speaker (ahead of Mark Zuckerberg)
- Elizabeth saw Peter and remembered him from 9 years prior
- They exchanged contact info and kept in touch for a while
- 2 days after this event, [John Carreyrou](https://en.wikipedia.org/wiki/John_Carreyrou) put on an [article in the WSJ](https://www.wsj.com/articles/theranos-has-struggled-with-blood-tests-1444881901) exposing some of the fraud going on at Theranos

Cognitive dissonance

- Here is Elizabeth as the headliner at this “who’s who” event
- Simultaneously, she knows her world is about to get super messy was the WSJ article releases
- From a psychology standpoint, Peter says he doesn’t believe that Elizabeth ever *thought* she was doing anything wrong
- Which is not for a moment to say, she shouldn’t be held accountable for what happened
- She should be absolved of the responsibility of what she’s done
- But it’s a very important distinction… you can be so delusional that you really believe that the lies you’re telling are for the better good

*Did Peter ever suspect fraud from Elizabeth and/or Theranos?*

- “*I never suspected [fraud]. . .I just thought it was the world’s most uninteresting business in the history of civilization. Like point of care testing in a drug store for Chem-7, and CBC? I would have more interest in a business that specialized in removing hangnails and nose hairs.*”

## The trend of lower testosterone and higher estrogen in men: Why is it happening and what to do about it? [10:00]

Lower T, Higher E

- If you took blood samples from a group of men in the 1950s, and did the same for a similar group of men today…
- You would notice that, in today’s men, **testosterone is lower, and their estrogen is higher**

*The question is, WHY?*

**1 Increase in obesity**

- Because, obesity obviously implies more adipose tissue.
- Adipose tissue is where we’re going to see more of the enzyme called aromatase (which turns testosterone into estrogen)
- If you have more adipose tissue and potentially more aromatase, you will undergo that chemical reaction more of turning the testosterone into estrogen.

  **2** **Chemicals** that can mimic the effects of estrogen (or increase the production of estrogen)

- Lots of plastics have been proposed to do this
- Examples,

- Food stored in plastic tupperware
- Drinking coffee in cups with plastic lids
- Especially off plastics that are going to have any high temperature with them

Things Peter does personally to combat this:

- Use glass containers at home
- He also washes all plastics by hand instead of in the dishwasher

Anecdote from a patient:

- He was drinking tons of coffee from plastic cups daily
- Switched to non-plastic and reported to feel 100 times better
- (Obviously, this could be placebo)

*How much of a difference does any of the stuff make?*

- I have absolutely no idea if this is making a difference or not, says Peter

*Furthermore, when doing blood tests…*

- We don’t even know what we’re measuring
- A lab test that’s measuring estrogen, first of all, you’re usually just measuring estradiol (rarely measure estrone or estriol in men)
- And then there could be a whole bunch of pseudo estrogens that are floating around that are exerting other biologic effects, that are “estrogen-izing”
- But you can’t measure them in the serum.

*Anyone know of an expert on this topic?*

- Peter says he only knows a little bit on this topic
- All suggestions are welcome for who the expert is on the topic

## Takeaways from Peter’s recent hunting trip in Hawaii [14:45]

Peter recently [went to Hawaii](https://www.instagram.com/p/BvcVlrLA3go/) to hunt axis deer

**Takeaways from the actual hunt**

- The shot, which is incredibly difficult and takes years of practice to even have a chance, is the **easiest** part
- Being able to spot an axis deer, literally just see one, is ridiculously hard
  - Their sense of sight, hearing, and smell are preternatural (they can smell you from a hundred yards away)
- Stalking them is nearly impossible without expert guides
  - About the hardest terrain you’re going to find in North America
  - Very cool, also difficult and frustrating
- Harvest them quickly and efficiently
  - If you manage to find them, stalk them, get in position to shoot them, and accurately hit them, you then have to harvest them properly
- In summary,
  - Peter gained an enormous appreciation for the expertise that goes into being able to actually get in a position to even take this shot…
  - Without that kind of knowledge [from the guides], “*you’d be twiddling your thumbs for days, hiking 16 miles a day, not even seeing an animal*”

**Feeding on a truly wild animal**

- Many people discuss the difference between farmed cow and grass-fed cow
- There are differences, says Peter…
  - Namely their diet (farmed cow mostly corn)
  - Less antibiotics
  - Less hormones
- H*owever*…
  - The grass fed cow is not living in a natural environment
  - And it’s still subject the unnatural stress (tremendous amount of stress at the time it’s killed)
- \*This is in *stark contrast* to how the axis deer are killed

*Axis deer*

- They are not natural to Hawaii (they’re natural only to India)
- They are an invasive species to Hawaii
- These are animals that are dying instantly because of how swiftly the kill happens (and from a great distance away)
- “*To me, that’s the absolute apex of what the best meat could possibly be like.*”
- You can just taste the difference
- Venison has a reputation as being a kind of “gamey” meat, but axis deer is not remotely gamey in this fashion
- In other words,
  - you don’t have that lactate surge, which is what happens when an animal is injured
  - You don’t have that cortisol surge, which is what happens when an animal is stressed

**Peter’s new aspiration**: *Could I get to the point in life where I don’t need a single animal that I didn’t kill, or a friend of mine didn’t kill?*

## What books are you currently reading/listening to? [21:30]

[Coddling of the American Mind](https://www.amazon.com/Coddling-American-Mind-Intentions-Generation/dp/0735224897) by Jonathan Haidt and Greg Lukianoff

- As a parent, it’s good to make sure we catch ourselves from doing too much coddling, says Peter
- The book explains the harmful level of political correctness going on using the example of the bubbles existing within the 20 most elite schools in the country
- “*It just provides an incredible level of head shaking.*”

⇒ Example,

- The dean of students at Claremont McKenna College was [forced to resign](https://www.nytimes.com/2015/11/13/us/dean-at-claremont-mckenna-college-resigns-amid-protests.html) over an email that was deemed bigoted/racist
  - ([Sam Harris](https://twitter.com/SamHarrisOrg?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) did an [entire podcast on this](https://samharris.org/podcasts/137-safe-space/))
- You should feel disgust at how this woman was treated
- And then more importantly, feel a need to examine the underpinning of how it could happen

The Coddling of the American Mind talks about how this environment basically came to fruition around 2013

- And we’re now seeing the far extremes of this political correctness
- And hopefully it sort of it comes back to the middle

*Do you always listen to audiobooks nowadays or do you read paper copies as well?*

- Mostly listen
- Sometimes will also get a hard copy to take notes

*What was the last paper copy book Peter read?*

- [The Second Mountain](https://www.amazon.com/Second-Mountain-David-Brooks/dp/0812993268) by David Brooks
- Peter wrote about this book in a Sunday email: [David Brooks and the quest for a moral life](https://peterattiamd.com/david-brooks-and-the-quest-for-a-moral-life/)

## What advice would you give to the 25 year-old Peter? [24:00]

- During a recent talk Peter gave on mental health, a woman asked the question: “*What can you say to somebody who’s in need of this type of help?*”
- Peter’s answer: “*Sadly,  I don’t know what you can say to somebody who isn’t sort of cracked open a little bit and willing to hear what you have to say.*”

Change comes from the inside

- Just like someone who needs to eat better, exercise more, sleep more…
- You can’t impose that on people
- It’s the same when someone needs to “unscrew themselves emotionally”
- They have to **want** to change

Peter said the 25-year old him wouldn’t have listened to his advice

- Because the 25 year old me wasn’t broken
- He hadn’t hit a relative rock bottom
- There was no way he was going to listen…
- He’s a total stubborn, maniacal focused human being that’s not going to hear it from anybody until the pain gets great enough

[Christmas Carol](https://en.wikipedia.org/wiki/A_Christmas_Carol) analogy:

- Scrooge was only able to change when he saw the ghost of Christmas future
- You really need to **see** what is going to happen if you continue on a certain path
- It’s almost like you need a crystal ball

## What is your emergency protocol if you start getting sick? [27:45]

**Two Things Peter Keeps on Him All the Time**

**1 Tamiflu**

- In case you are coming down with the flu, you need [Tamiflu](https://www.goodrx.com/tamiflu)
- But you can’t wait until you’re in the middle of it or it’s too late
- It only works if you catch the influenza right on the update
- Peter points out that the flu vaccine isn’t efficacious every year (in 2018 it was “basically a placebo”)
- So you could still get the flu even if you get the shot
- If Peter even starts getting a fever, he will *assume* its the flu and take the tamiflu

**2 Amantadine + Aleve**

- [Amantadine](https://www.goodrx.com/amantadine) is for treating the regular, garden variety, pain in the ass cold
- The protocol is…
  - Take the given dose of amantadine in combination with two Aleve a day, for five days
  - Start taking it the second you have the onset of symptoms
- The Aleve is for SIRS (Systemic Inflammatory Response Syndrome) **which is why you feel bad with a cold**
- SIRS is the body’s immune response to:
  - The toxins that are being released by the virus, and
  - more importantly, the immune cells themselves actually gearing up each other

> “I don’t think the data would support the use of amantadine [for the common cold], but it’s a very well tolerated drug. If it gives me some placebo effect, I’ll take it.”

## How have your thoughts changed on NAD precursors, and also on metformin, in the past year or so? [30:30]

**NAD precursors**: Something Peter is more *bullish* on today versus a year ago

- A year ago I was completely dismissive of NAD precursors such as nicotinamide riboside (NR) and [NMN](/does-nmn-improve-metabolic-health-in-humans/)
- Thought it was just a great marketing story
- Anecdotally people would frequently tell Peter they have more energy, better sleep, etc.
- But Peter attributed at least some of those benefits to a placebo effect
- That said, Peter is still very convinced that **intravenous NAD** is nonsense (mostly just a scam)
- Today, Peter says that some of the oral NAD precursors (NR, NMN) may actually have some efficacy
- This is despite the fact that Josh Ribinowitz’s group [published a paper](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(18)30196-7) showing how most of that oral NR is actually being taken up in the liver
- But we still don’t know how much goes into the liver
- And it’s also unknown as to whether there is an upside to the liver itself increasing its concentration of NAD

⇒ For more on NAD

- Episodes of The Drive with David Sinclair episode ([Part 1](https://peterattiamd.com/davidsinclair/) and [Part 2](https://peterattiamd.com/davidsinclair2/))
- Episode of [The Drive with Chris Masterjohn](https://peterattiamd.com/chrismasterjohn/)

**Metformin**: Slightly more bearish on Metformin for longevity in otherwise “healthy” people

- Today, Peter says he’s a “*bit more tempered in my enthusiasm around metformin use in the healthiest of people*”
- He remains incredibly optimistic about the use of metformin in people who are metabolically anything other than very healthy
- But when you take that tiny subset of people who are like 9 out of 10 in terms of health… “*it’s possible metformin is not helping them, and it’s even possible that metformin is detracting a little bit.*”

## What are your thoughts on “fat burning” zones for cardio workouts? — A lesson in relative vs. absolute fat combustion [34:15]

==> For more on this topic, check out [Peter’s blog post](https://peterattiamd.com/my-quantified-self-part-i/) (and [lecture](https://www.youtube.com/watch?v=NqwvcrA7oe8)) from 2013

***Absolute*** **versus** ***relative*** **fat combustion**

- The [respiratory quotient](https://en.wikipedia.org/wiki/Respiratory_quotient) (RQ) is used to measure the **relative amount** of fat oxidation versus glucose oxidation
- To do this:
  - Put someone on a treadmill
  - Put a mask over their mouth (and plug their nose) that is measuring
    - i)  the oxygen leaving (computer subtracts that from the oxygen coming in) and this calc is called the VO2
    - ii) The CO2 exiting (CO2 going in is effectively zero) so we now know the VCO2
- The ratio of these things—VCO2 to VO2—is called respiratory quotient (RQ)
- And that ratio tells you *where your fuel is coming from*

The RQ range

- When that ratio is in the 0.7 range, virtually all of your energy is coming from **fat**
  - *Why?* ⇒ It’s just [stoichiometry](https://en.wikipedia.org/wiki/Stoichiometry)… it’s just telling you that when your CO2 production is only 70% of your oxygen consumption so you are producing long hydrocarbons
- When the ratio reaches 1.0, what that means is your VCO2 is equal to your VO2
  - (your production of carbon dioxide is equal to your consumption of oxygen)
  - In other words, all your energy is coming from glucose and nothing from long hydrocarbons (i.e., fat)
- W*hat does this tell you*?
  - It tells you your RELATIVE amount of fat versus glucose

At 60% of your max heart rate…

- A reasonably fit person is still closer to 0.7 versus the 1.0
- However, a highly insulin resistant person, who is both de-conditioned and highly metabolically inefficient, will have a very high respiratory quotient even (An RQ north of 0.9!)
  - That person is never going to get well without **fasting and exercise**
  - You just have to be able to **drive glycogen depletion**

**Let’s talk about ABSOLUTE fat combustion**

To understand absolute fat combustion, you must know the *absolute* level of VO2, and the *absolute* level of VCO2.

- To understand total energy expenditure, we can use the [Weir equation](https://en.wikipedia.org/wiki/Weir_formula)
- Energy expenditure equals = 3.94 x VO2 + 1.11 x VCO2

How the testing process works

- During a test, the computer can spit out your VO2 and VCO2 every 15 seconds onto a spreadsheet
- The computer will spit out at 15 second intervals into an excel spreadsheet
- We then use that to determine **total energy expenditure**
- Then you look at the **ratio of VO2 to VCO2** to determine how much of my *energy came from fat oxidation versus glucose oxidation*

Results from Peter’s self testing on a bicycle:

![](https://peterattiamd.com/wp-content/uploads/2019/09/fuel-utilization-during-Peters-vo2-max-test-1024x746.png)

**Figure 1. Results from Peter’s VO2 max test showing fuel utilization by substrate vs. power output.**

Results from the test show

- As your energy level goes up…
- Your total calories expended per minute goes up
- But your ***relative*** contribution of fat goes down
- But the ***absolute*** value of fat peaks somewhere in the middle (and then comes down)
- Where your absolute fat oxidation is peaking is a function of i) your fitness, and ii) your fuel (food)
  - On a ketogenic diet, for example, Peter’s fat oxidation will peak at about 1.6 to 1.8 grams per minute (higher than when not on a keto diet)

So…*is training at 60% of max heart rate ideal for burning fat?*

- At 60% of your maximum heart rate…
- you may be burning your *highest percentage of fat*
- but you are absolutely not even coming close to burning your *highest amount of fat*
- Looking at percentage of fat oxidation can lead to ridiculous ideas such as “you burn more fat while sleeping and than while exercising”

\*Really important point = **Exercising at 60% of maximum heart rate is** ***too low in intensity***

- This is considered being in “zone 1”
- It’s not harmful in any way, shape, or form
- It’s just not the best use of your time
- **Zone 2** is a better place to be

Heart rate zones

- Zones are based on heart rate
- Divided into five zones
- What is Zone 2?
  - 75 to 80% of maximum heart rate
  - So with a max HR of 180, your zone 2 would be a HR of 135-144
  - This is the **sweet spot to be spending your “cardio time”**
  - You are right at the threshold of the mitochondria
  - Just being on the cusp of really crossing over into anaerobic work.
  - *The fitter you get*, the higher that number gets
  - Also, it might be that when you’re starting out, 60% of your max HR is indeed your zone 2

\***Tip of the day**\*

- You can use *subjective level of exhaustion* to estimate zone 2
- In zone 2, you could carry out a basic conversation but it is a little uncomfortable
- Talking is strained enough that the person you’re talking to knows you’re exercising
- Above zone 2, it’s too uncomfortable to have a conversation
- Below zone 2, you can be “chatty Cathy”
- Your goal while doing cardio is to find that zone 2 either using a HR monitor or the “conversation” test

## What mental models do you use and how do you go about solving problems and approaching difficult questions? [49:00]

- Peter is going to “punt” this question for now
- He wants to get [Shane Parrish](https://www.linkedin.com/in/shane-parrish-050a2183/?originalSubdomain=ca) on the podcast to discuss this topic
- Check out this [NY Times article](https://www.nytimes.com/2018/11/11/business/intelligence-expert-wall-street.html) on Shane

## Creatine supplementation—Yay or nay? Why? [49:30]

*What is creatine?*

- Creatine is this molecule in our body that is a phosphate donor

*What’s phosphate?*

- ATP is a phosphate donor
- ATP has three phosphates
- Anytime you need energy, you’re basically turning ATP into ADP…it’s the liberation of the third P that is the energy that we use to do things
- We breathe to provide oxygen to the electron transport chain to generate ATP from ADP

We actually have *three* energy systems (not two)

- Most people think we have these two energy systems
  - Aerobics, where we make ATP in the presence of sufficient oxygen at a low enough rate
  - Anaerobic when we can make ATP, once we’ve exceeded the level of sufficient cellular oxygen using pyruvate and turning it into lactate
- The *third* energy system called the **creatine phosphate system**
  - We use creatine as a direct donor of phosphate
  - In an all out energy burst, this is the energy system we are using for the first 3-4 seconds

History of creatine supplementation

- About 30 years ago, it became really popular for athletes to supplementing with creatine phosphate
- At the beginning, it was common to “load” so 20 g per day for 5 days, then do a maintenance phase at 5 g per day (or something close to that)
- You would gain a ton of weight
- You definitely got stronger
- It was a legitimate performance enhancing supplement

Today, we have learned…

- Creatine *phosphate* provides no benefit… you can just use the creatine *monohydrate* and you’ll pick up the phosphates in your body
- The loading phase is unnecessary

*Current recommended way to take creatine?*

- Take [5 g per day](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5469049/) of creatine monohydrate
- \*Peter’s preferred brand: [Biosteel Creatine Monohydrate](https://biosteel.com/products/creatine)

What to expect when taking it?

- Gain some weight (mostly water weight)
- Some increase in strength

*Who would it help?*

- Peter wonders is creatine would help with performance in his tabatas on the AirDyne bike
- They decide probably not since he would burn through the creatine so quickly
  - Tabata tangent…
    - we really have no ability to go “all out” even for just 20 seconds
    - Even if you think you are going 100%, you’re actually pacing yourself
    - Check out Peter’s [tabata protocol in AMA #5](https://peterattiamd.com/ama05/)
- Sprinters? ⇒ maybe
- Competitive cyclist? ⇒ probably not, because by the time you are “sprinting” you are at the end stages of the race and you’ve already used up that creatine
- Athletes looking for strength and performance gains? ⇒ probably
- Average Joe looking to better results in the gym? ⇒ A coin toss
- [Chris Masterjohn says](https://peterattiamd.com/chrismasterjohn/) creatine might even help marathon runners

*Is it safe?*

- If you’re using a pure product (like Biosteel), it is incredibly safe

⇒ For more on creatine, check out [Peter’s interview with Chris Masterjohn](https://peterattiamd.com/chrismasterjohn/) starting at 2:10:15

§

## Selected Links / Related Material

**The HBO documentary about Theranos**: [The Inventor: Out for Blood in Silicon Valley](https://www.hbo.com/documentaries/the-inventor-out-for-blood-in-silicon-valley) | (hbo.com) [2:00]

**The book detailing the story of Theranos**: [Bad Blood: Secrets and Lies in a Silicon Valley Startup](https://www.amazon.com/Bad-Blood-Secrets-Silicon-Startup/dp/152473165X/ref=sr_1_2?keywords=bad+blood&qid=1568749954&sr=8-2) by John Carreyrou | (amazon.com) [2:00]

**The WSJ article by John Carreyrou that first revealed the shenanigans inside Theranos**: [Hot Startup Theranos Has Struggled With Its Blood-Test Technology](https://www.wsj.com/articles/theranos-has-struggled-with-blood-tests-1444881901) | John Carreyrou (wsj.com) [7:00]

**Book Peter recently finished**: [The Coddling of the American Mind: How Good Intentions and Bad Ideas Are Setting Up a Generation for Failure](https://www.amazon.com/Coddling-American-Mind-Intentions-Generation/dp/0735224897) by Jonathan Haidt and Greg Lukianoff | (amazon.com) [21:30]

**Story about overly PC culture forcing the dean of students to resign at Claremont McKenna College**: [Dean at Claremont McKenna College Resigns Amid Protests](https://www.nytimes.com/2015/11/13/us/dean-at-claremont-mckenna-college-resigns-amid-protests.html) | Ian Lovett (nytimes.com) [22:00]

**Sam Harris podcast episode where he discusses the forced resignation of the dean of students at Claremont McKenna College**: [#137 Safe Space-A Conversation with Jonathan Haidt](https://samharris.org/podcasts/137-safe-space/) | (samharris.org) [22:00]

**The last book that Peter actually bought the paper copy so he could take notes**: [The Second Mountain: The Quest for a Moral Life](https://www.amazon.com/Second-Mountain-David-Brooks/dp/0812993268) by David Brooks | (amazon.com) [23:50]

- *Peter’s Sunday email about this book*: [David Brooks and the quest for a moral life](https://peterattiamd.com/david-brooks-and-the-quest-for-a-moral-life/) | Peter Attia (peterattiamd.com) [24:00]

**Analogy Peter used to describe how Peter almost need a crystal ball to see how their future will turn out if they don’t change their actions/behavior**: [A Christmas Carol](https://en.wikipedia.org/wiki/A_Christmas_Carol) | (wikipedia.org)

**What Peter takes if he feels the flu coming on**: [Tamiflu](https://www.goodrx.com/tamiflu) | (goodrx.com) [27:45]

**What Peter takes if he feels the common cold coming on**: [Amantadine](https://www.goodrx.com/amantadine) | (goodrx.com) [28:45]

- Note he takes this in tandem with [Aleve](https://www.aleve.com/)

**Josh Ribinowitz’s paper showing how most of that oral NR is actually being taken up in the liver**: [Quantitative Analysis of NAD Synthesis-Breakdown Fluxes](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(18)30196-7) (Liu et al., 2018) [31:30]

**For more on NAD precursors**: [32:00]

- *Episodes of The Drive with David Sinclair*:
  - [#27 – David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging](https://peterattiamd.com/davidsinclair/)
  - [#70 – David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)](https://peterattiamd.com/davidsinclair2/)
- *Episode of The Drive with Chris Masterjohn*: [#46 – Chris Masterjohn, Ph.D.: Navigating the many pathways to health and disease – NAD and sirtuins, methylation, MTHFR and COMT, choline deficiency and NAFLD, TMAO, creatine and more](https://peterattiamd.com/chrismasterjohn/) | Peter Attia (peterattiamd.com)

**Peter’s blog post on RQ, ketosis, and fuel utilization during exercise**: [My Quantified Self, Part I](https://peterattiamd.com/my-quantified-self-part-i/) | Peter Attia (peterattiamd.com) [34:15]

**NY Times article about mental models by Shane Parrish**: [How a Former Canadian Spy Helps Wall Street Mavens Think Smarter](https://www.nytimes.com/2018/11/11/business/intelligence-expert-wall-street.html) | Shane Parrish (nytimes.com) [49:00]

**Peter’s tabata protocol**: [#50 – AMA #5: calcium scores, centenarian olympics, exercise, muscle glycogen, keto, and more](https://peterattiamd.com/ama05/) | Peter Attia (peterattiamd.com) [53:15]

**Paper suggesting to take 5 g per day of creatine monohydrate**: [International Society of Sports Nutrition position stand: safety and efficacy of creatine supplementation in exercise, sport, and medicine](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5469049/) (Kreider et al., 2017) [54:00]

**Peter’s preferred brand of creatine monohydrate**: [Biosteel Creatine Monohydrate](https://biosteel.com/products/creatine) | (biosteel.com) [54:15]

**For more on creatine, check out Peter’s interview with Chris Masterjohn (starting at 2:10:15)**: [#46 – Chris Masterjohn, Ph.D.: Navigating the many pathways to health and disease – NAD and sirtuins, methylation, MTHFR and COMT, choline deficiency and NAFLD, TMAO, creatine and more](https://peterattiamd.com/chrismasterjohn/) | Peter Attia (peterattia.com) [49:30]

§

## People Mentioned

- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) (a decent football player)  [1:45]
- [Elizabeth Holmes](https://en.wikipedia.org/wiki/Elizabeth_Holmes) (founder of Theranos) [4:45, 5:45, 6:00, 6:30, 7:30, 8:15, 8:45]
- [Mark Zuckerberg](https://en.wikipedia.org/wiki/Mark_Zuckerberg) (second fiddle speaker to Elizabeth Holmes at charity event) [5:45]
- [Tim Ferriss](https://en.wikipedia.org/wiki/Tim_Ferriss) (invited Peter to charity event where he reconnected with Elizabeth Holmes) [6:00]
- [John Carreyrou](https://en.wikipedia.org/wiki/John_Carreyrou) (wrote the story that revealed the fraud at Theranos) [7:00]
- [Bradley Cooper](https://en.wikipedia.org/wiki/Bradley_Cooper) (a handsome man) [8:00]
- [Adolf Hitler](https://en.wikipedia.org/wiki/Adolf_Hitler) (bad guy) [8:15]
- [Robin Hood](https://en.wikipedia.org/wiki/Robin_Hood) [15:15]
- [Rob Lustig](https://en.wikipedia.org/wiki/Robert_Lustig) [21:30]
- [Jonathan Haidt](https://en.wikipedia.org/wiki/Jonathan_Haidt) (author of Coddling of the American Mind) [21:45]
- [Sam Harris](https://en.wikipedia.org/wiki/Sam_Harris) (podcast episode about the dean of students being forced to resign at Claremont McKenna College) [22:15]
- [David Brooks](https://en.wikipedia.org/wiki/David_Brooks_(commentator)) (Canadian-born American political and cultural commentator who writes for The New York Times) [23:45]
- [Galileo Galilei](https://en.wikipedia.org/wiki/Galileo_Galilei) (Italian astronomer, physicist and engineer) [26:30]
- [Charles Dickens](https://en.wikipedia.org/wiki/Charles_Dickens) (author of Christmas Carol) [26:45]
- [Ebenezer Scrooge](https://en.wikipedia.org/wiki/Ebenezer_Scrooge) (protagonist in A Christmas Carol) [27:15]
- [Josh Ribinowitz](https://scholar.princeton.edu/rabinowitz/bio) (paper showing most of  oral NR is actually being taken up in the liver) [31:30]
- [David Sinclair](https://www.linkedin.com/in/sinclairda/) (NAD) [32:00, 32:30]
- [Chris Masterjohn](https://twitter.com/ChrisMasterjohn?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (NAD, creatine) [32:00]
- [Travis Denson](https://twitter.com/tden185) (show notes contributor for The Drive podcast) [41:00]
- [Andrew Coggan](https://www.peakscoachinggroup.com/DrAndrewCoggan) (zones for cyclists) [45:30]
- [Shane Parrish](https://www.linkedin.com/in/shane-parrish-050a2183/?originalSubdomain=ca) (mental models) [49:15]
- [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) (sprinter) [53:30]

§