# #93 – AMA with Jason Fried: Work-life balance, avoiding burnout, defining success, company culture, and more

**Source:** [https://peterattiamd.com/jasonfriedama/](https://peterattiamd.com/jasonfriedama/)

---

##### Check out more content with Jason Fried:

- *(October 7, 2019)* [Jason Fried: Optimizing efficiency and work-life balance](/jasonfried/)
- *(February 17, 2020)* [AMA with Jason Fried: Work-life balance, avoiding burnout, defining success, company culture, and more](/jasonfriedama/)

In the [first interview](https://peterattiamd.com/jasonfried/) with Jason Fried, Jason explained his overall philosophy about work-life balance and how exactly he optimizes for efficiency. For this special follow-up AMA, we’ve decided to release the full episode to everyone (including non-subscribers), so all can hear Jason answer questions from listeners that dive deeper into topics such as work-life balance, the role of luck versus hard work in success, specifics around Basecamp’s unique process-oriented approach to projects, 4-day work weeks, practical tips for people searching for the right company culture, tips on writing and parenting, and a whole bunch more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jasonfriedama/the_Drive_public.png)

Play

#93 - AMA with Jason Fried: Work-life balance, avoiding burnout, defining success, company culture, and more

#93 - AMA with Jason Fried: Work-life balance, avoiding burnout, defining success, company culture, and more

1x15s30s

0:002:07:39

## We discuss:

- If Jason had taken his own advice about work-life balance at the start of his career, would he have achieved the same level of success? [2:05];
- What is Jason’s definition of success? And what is he optimizing for? [10:10];
- Basecamp’s policy on email and expectations for a quick response, and why Jason believes in sleeping on big decisions [14:30];
- How Jason implements “true” work-life balance in his life and at Basecamp [19:15];
- Does work and life have to be separated in order to have balance? [32:00];
- How Jason makes time the fixed component to avoid the compulsion to keep pushing forward on a project perpetually [34:15];
- Jason’s tip of physicians who may be facing burnout [45:00];
- Signs of “burnout” if you do the same basic thing for work and pleasure (and tips to avoid and manage that feeling) [49:45];
- Is a 40-hour work week the correct amount? [53:45];
- How to evaluate a company’s culture when looking for a job with the right work environment [59:00];
- Jason’s take on salaries and alternate incentives like equity, profit sharing, etc. [1:06:45];
- What traits does Jason look for when hiring new employees? [1:13:45];
- Does Jason believe in process-oriented work or outcome-driven work? And Basecamp’s unique process for completing projects [1:16:15];
- How does Jason handle a project that results in a failure? [1:20:00];
- Advice for people in situations where they don’t have full control of their time and work demands [1:23:50];
- How much of success should be attributed to skill versus luck? [1:29:30];
- The importance of writing skills and tip to improve your writing [1:43:15];
- Lessons learned from parenting, and Peter’s top priority when it comes to raising kids [1:52:15];
- An important skill: The ability to say “no” to things [2:01:15]; and
- More.

§

## Show Notes

## If Jason had taken his own advice about work-life balance at the start of his career, would he have achieved the same level of success? [2:05]

-Jason says he’s never really been a super long worker other than the occasional long night when maybe he had an idea in his head that he just wanted to get out

**The two things that showed Jason that more time doesn’t always mean better results**:

  1 | Long proposals weren’t helping him get more clients

- Earlier in his career as a freelancer he would put together proposals when trying to pick up clients and they were massively thick, well thought out booklets
- One day he sort of realized that all that really mattered was the last page summary and the price and most people just skipped to that part anyway
- He started doing shorter and shorter proposals and found out that he didn’t lose any more business because of it

> “That was sort of a wake up call for me that just putting in more time doesn’t mean anything other than you’re putting in more time. You’re not guaranteeing yourself a better outcome or anything like that.”

2 | Basecamp was a side project

- Much of Jason’s success is because of his product called [Basecamp](https://basecamp.com/)
- But it was a side project that only had about 10-15% of the company’s time dedicated to building it
- (maybe about 10-15 hours per week from Jason on the design and another 10-15 hours per week on the coding done by his partner [David Heinemeier Hansson](https://twitter.com/dhh?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor))
- Took about 4 months to build the first version which ultimately set it off to become what it is today
- “***So it turns out that not having a lot of time was actually an advantage.*** *. .If we had more time, we would have made it more complicated. It would have taken longer to actually get out the door.*”

***What about the person who doesn’t have complete control of their hours?***

- Many people have demands put on them that drive the time they have to put in
- But what you can do, says Jason, is figure out, what control you DO you have over yourself, or maybe your own small team
- If you manage others, perhaps you can shield them perhaps as best you can from the onslaught from above

-Other questions to ask yourself:

- What can you carve out and what can you control?
- Are you not finishing your work during the day because you are constantly getting interrupted?
- Am I part of the problem?
- Am I just interrupting people constantly?
- Can I do something about how I’m behaving and can that influence the people around me?
- This is not a quick fix, admits Jason, but “being the change you wish to see” might ultimately be the best you can do.

> “I do think you have probably a little bit more control of your own local environment than you think and you should just do the best you can in that scenario.”

## What is Jason’s definition of success? And what is he optimizing for? [10:10]

**Jason’s take on the definition of success:**

- Most people’s first thought when they hear the word success is “money”
- Jason admits that money is important to him but that he’s just never been *driven* by it
- For Jason, success really means, “**Do I want to keep doing what I’m doing?**“

-At Basecamp, for example…

- They leave a lot of money on the table by not developing certain new things, or charging more or differently, etc.
- But that’s just **not the kind of work that he wants** to do at Basecamp
- “*I don’t want to build an organization that’s interested in squeezing every last penny out of every last customer. It’s just not interesting to me.*”

**Finding the “enough” amount**:

- Jason isn’t just searching for the “enough” amount of money
- He’s also doing that with the number of employees he has at Basecamp
- He would have 5 times the amount of people, but that comes with its own set of headaches
- More people might equal more money because they could do more things, but at what cost?

**Everything has a cost**

- Everything has a cost, and everything has a trade off

> “For me… success is not defined by revenue targets or big numbers. It’s defined by, ‘Do I want to go to work tomorrow and do the same thing I did the day before? Am I enjoying this? Do I like the people I’m working with? Am I challenging myself intellectually and creatively?” Those are the things that matter.’”

**Impact also matters**

- “Am I impacting the industry in a positive way?”
- “Are we standing for the right things?”
- Jason points out that loving what you do and making a positive impact don’t have a lot to do with time spent, rather, they have a lot to do with **what you choose to do with the time that you do have**.

## Basecamp’s policy on email and expectations for a quick response, and why Jason believes in sleeping on big decisions [14:30]

As you probably know, Peter is bothered by the nature of email and the constant bombardment and expectation of a quick response so he wants to know what Jason’s culture is around email and response expectations at Basecamp

***Do you guys have any rules, guidelines, practices around email?***

- The culture at Basecamp is that no one should expect immediate response to an email or a message
- Interruption is a really arrogant act, says Jason
- It’s saying, “Whatever you’re doing is less important than what I have to ask you, or what I have to tell you.”
- At Basecamp, you can send a message but the expectation is that people are going to get back to you when they’re ready (3 hours later, 5 min late, the next day, is all okay)
- In a literal emergency, things can be sped up but people must respect the definition of emergency
- *The phone is the elevation of attention*: “If there’s actually truly an emergency, you call them. The phone is the elevation or the escalation of the attention. So if one of us calls each other, we answer the phone.”

**Sleeping on decisions**

- Jason is a big believer on sleeping on decisions, especially if those questions come up later in the day
- Jeff Bezos (allegedly) only makes important decisions in the first half of the day, and if any important decision comes to him after noon, he won’t make it until the next day when he’s cognitively at his best and not beat down or frustrated from the day
- Peter think that is the takeaway here: **Mornings are for decisions**.

## How Jason implements “true” work-life balance in his life and at Basecamp [19:15]

> “Work-life balance is what people call it, but a lot of people don’t mean it, because what usually takes is always work. Work always eats into life. It’s very rare that life can eat back into work. So if something’s really going to be balanced on a scale or something, one side has to be able to freely move up and will move the other side, but both sides have to be able to move.”

**True balance**

- Life has to take over from time to time
- We see leaving work at 2pm to see a movie as strange
- But is that any stranger than doing work emails after dinner at home?
  - “*That’s strange too, but we’re just so used to it that we consider it to be normal.*”
- When is comes to flexibility, both sides need to be flexible and both sides need to be able to take back from the other and trade
- If only one’s acceptable, then it’s not really truly balance.

**Keeping a ledger**

- Jason likes the idea of keeping a ledger of when work eats into life
- Then you can schedule a time to let life take a little time from work

**Jason encourages daydreaming**

- I encourage people here to daydream at work. Just have nothing to do and just think.
- Just being able to sit still and just look out the window and see where your mind goes is…that to me is a healthier approach than feeling like ‘I need to cram stuff. If I have nothing to do, then I’m not being efficient or I’m slacking off.’”
- That said, most organizations view sitting around doing nothing as a problem so there’s a lot of fundamental change that has to happen
- Jason says that maybe even hiding while daydreaming is a good idea, “*I don’t think your company’s going to miss that hour that you’re just thinking for yourself. . .In fact, I think you’ll probably use that hour better in most cases than you would have if you were just doing some menial tasks.*”

**What about those that work hourly (like at a call center or something)?**

- Many people in that situation have pretty strict work-life balance already
- Once the work day is done, it’s over, it’s a clear separation
- Jason says, taking your work home with you is more of a problem for information-based jobs or jobs that are more about sitting behind a computer and doing creative work
- It’s much easier to fall into work later that evening because all the tools are right in front of you (phone, computer, etc.)
- So in some ways, like the call center example, that structure naturally creates a healthier situation

**Basecamp has a built-in feature called “Work Can Wait”**

- This feature let’s employees set their own work boundaries
- Basecamp cannot send you a notification outside of your work hours

**Peter suggests making your home office a “miserable” place to be**

- Peter points out that letting work bleed into life is about the environment
- If your home office, for example, is easy to get to and conducive to work, you will be more likely and tempted to go in there
- He dreams of a scenario where his home office is like in a hard to reach treehouse without electricity of something
- Peter’s comment is that “it’s so easy to work”
- Jason says one thing you can do it put a “mark” on the office door each time you go in there so you can see the tally mark showing you how much time you are spending in there
- “Maybe you can do something that helps you recognize and realize how often you’re doing that, and that might change your behavior, or at least make you aware of the behavior. I think we probably go around not even wondering what we’re doing. We just do these things. They’re involuntary.”

⇒ Check out the [Glass House](https://en.wikipedia.org/wiki/Glass_House), the Philip Johnson glass house in New Canaan, Connecticut

![](https://peterattiamd.com/wp-content/uploads/2020/02/glass-house-jasonfriedama.jpg)

**Figure 1. The Glass House by Phillip Johnson.** Image credit: [architecturaldigest.com](https://www.architecturaldigest.com/story/architect-philip-johnson-glass-house-modernism-article)

- Limited by nature
- No electricity or plumbing in the office

**The question you should be asking yourself is,** ***“What are you optimizing for?”***

-Technology as been optimized for impact, and it does great with that

-But the question is, ***What are YOU optimizing for?***

- Everybody has a choice
- For Peter personally, he says he is optimizing for “happiness,” or said another way, minimizing suffering
- Some people optimize for legacy or impact
- But as [Marcus Aurelius](https://en.wikipedia.org/wiki/Marcus_Aurelius), the stoic philosopher, would argue, “*Who cares? You’re not there to enjoy it. You’re dead anyway*.”

–*Technology isn’t all good or all bad*

- Tech industry pitches technology advancement as all good
- But it’s not a win-win, says Jason
- It’s up to the public to push back and say, “Hang on a second. What have we been sold and what is this doing to us?”
- One example, it’s damaging relationships (people in bed on their phones instead of being together)

> “I’m glad these things do exist in the world, obviously. I mean, we’re doing this podcast over Skype and I’m recording on my Macbook Pro, and I’ve got an iPad next to me. These are great things, but they do come with costs and I think that’s just the important thing to keep in mind.”

## Does work and life have to be separated in order to have balance? [32:00]

The full question from the listener: *“I always cringe at the phrase ‘work/life balance’. These two things should not be different. I understand that they often are, but it seems to me that the fix is not to figure out how to maintain a balanced separation, but rather to bring the two together. What are your thoughts?”*

- Jason doesn’t love the term “work/life balance” because it’s misused and it doesn’t really represent anything
- The term sort of suggests that there is a clear demarcation point between the two
- But the reality is that it doesn’t have to be like that, it can be mixed together throughout the day
- “And that’s, to me, the balance part. Not that they’re necessarily equal or that one starts in one ends kind of thing, that might be a little bit complicated.”

Jason’s typical day, for example…

- I wake up in the morning really early.
- I make breakfast for my kids
- I take them to school a few days a week
- I go to the gym the other days a week
- Then I do a little bit of work
- Then I take a little bit of a personal break and do something else around the house
- Then I do some more work and I do something else and maybe I’ll drive to the office around noon.
- “*So my day and my work or my work in my life, is sort of mixed up during the day.*”
- But I think the important part is that there’s **life mixed in there too**.
- But 12 to 14 hours of work is a lot of work and a lot of people are spending that much time at work. That’s not “together.”

“*I don’t mind these things being scattered throughout the day as long as one’s not dominating the other. That’s my main point.*”

## How Jason makes time the fixed component to avoid the compulsion to keep pushing forward on a project perpetually [34:15]

-Jason interprets this question as continuing to work longer and harder on a project that turns into a new ending project

–**Here’s how he avoids that fate**:

- “What I’ve realized is that a project doesn’t exist until it’s over. Until then it’s just work, and what turns it into a project or turns it into something to be proud of, I think, is at the end when it’s all packaged up and ready to go. . . I want to get to that point sooner rather than later.”
- “I’d rather get it out early and then iterate on it. So, what I’ve found is that there’s just diminishing returns at some point. You’re better off just taking a break and coming back to it the next day than trying to push through to the next day on things.”

**More responsibilities can be an** ***advantage***:

- In the past, when he had fewer responsibilities (no kids, family, etc.) he may have pushed harder and longer
- But he’s come to realize that those pressures are **not a disadvantage**
- Jason has observed many people who have other pressures outside of work tend to be **more efficient workers** because they know that they don’t have extra time and so they make better use of that time

> “*I want to do my work during the day, I want to stop, I want to come back the next morning, and I want to get this thing done. Which means I’m going to cut it back and not keep pushing forward, but instead draw a line, get it out there, and then continue to revise over time.*”

**You will destroy relationships with your team**

- It’s not even just the outcome, it’s the process too.
- Sometimes you can brute force something through by pushing people as hard as you can and they finished and the end product is great
- However, you may have just destroyed the team, their morale, burned people out, and messed up personal relationships
- So yeah, the outcome might be worthwhile, but that’s a very short term look at it because you’ve got to work with these people again
- ⇒ When Peter [interviewed Ric Elias](https://peterattiamd.com/ricelias/) he referenced the Simon Sinek book, [The Infinite Game](https://www.amazon.com/Infinite-Game-Simon-Sinek/dp/073521350X), which stresses that you aren’t optimizing for the short term, but rather the long term
- If you’re optimizing around the idea that there will be many future projects, the game is to give people (and yourself) the **freedom, flexibility, sanity, comfort, passion, and ability to keep doing projects**

“*There are certainly times when something had to happen at a given time for whatever reason, you just had to do it. That’s maybe fine occasionally. But I think if you do that, it’s important to tell the team, ‘This is not how it’s always going to be. This was something that we had to do for this reason and we believe we had no other choice. . .this is not how it’s going to be next time.’*”

**Time is fixed, and scope is to be adjusted**

- Jason **defines the time** he wants to work on a project, and he will **adjust the scope** to fit that time constraint
- Most people, including Peter, do the opposite which leads to never ending projects
- At Basecamp, he makes **6 weeks** the time constraint (ask discussed in the [previous podcast](https://peterattiamd.com/jasonfried/))
- And they become “ruthless” about cutting scope
- What if the project is bigger?
- They break it down into six week chunks
- That forces them to figure out what’s actually really worth doing, what’s really important, what trade offs they’re going to make

> “*Because if you just keep shoving more stuff in, it’ll never end. It’ll get really big, it’ll get really complicated and by the time it’s done, you may not like it anymore because the ground may have shifted, the market may have shifted, you may have shifted.*”

**Problem with show Silicon Valley does business…**

- Silicon Valley. . .pushes people so hard because a lot of the companies are not thinking long term
- Instead, they are just trying to survive until they can get acquired, IPO, merger
- This strategy is looked at from the outside as successful to you have more leaders and business trying to emulate that style
- Our “worst export” from Silicon Valley is that “all out constant effort” which burns people out
- It might work for SV because it’s not going to last anyway, but it’s not sustainable
- Jason, to the contrary, is trying to build a **long lasting company ⇒** “*You can’t behave that way and last for a long time. You’re going to flame out.*”

## Jason’s tip of physicians who may be facing burnout [45:00]

Peter wonders how Jason might address a big problem for physicians which is **physician burnout**

- The problem being that the way doctors are incentivised by the healthcare market to see as many patients as possible
- And then when they are not in the clinic, they’re spending their time chained to an inbox of emails and calls

Jason says unfortunately this is a systemic problem so he doesn’t have a solution

- However, he does point out that the one thing that is a little more in control is how doctors respond to patient emails, calls, etc. outside of office hours
- “That’s probably the one place that you have a little bit more control over because that’s not how you’re getting paid. It’s not what’s being measured. It’s actually what you **think** people want from you.”
- He says that many times a client (or patient) emails at 10:30pm because that’s wehn they have a free moment and NOT because they need or expect an answer at 10:31pm
- In fact, that may just be what YOU think they want, when instead they are okay with an answer the next day

**A helpful tip: Autoresponder**

- Set up an autoresponder if someone emails you with answers to the top 10 most frequently asked questions
- And then also include other resources that they can independently go through to find the answer if their specific question isn’t addressed in your top 10
- That might take care of a big chunk of questions

## Signs of “burnout” if you do the same basic thing for work and pleasure (and tips to avoid and manage that feeling) [49:45]

Many people have a job that is the same thing (or similar to) their hobby on the side which could lead to a feeling of burnout

**Signs of burnout**:

1 | One sign of burnout is that “hook” or special feeling you get when doing that thing starts to fade

- But similar to the way one might listen to their favorite song or album too many times and you start to sometimes get tired of it and start skipping songs … this can happen to the thing you love
- Once that feeling is gone … that “hook” is gone…
- … that is the thing to be looking out for

“If you’re essentially loving this thing that you do because you do it in your off hours, but at some point whatever it is that you’re working on just doesn’t seem to be as interesting as it once was, that’s like that album that you’ve played a few too many times.”

- There may not be an obvious moment when BOOM you don’t like it
- Instead, it’s more like a feeling that starts to build up

2 | Procrastination

- One of the early signs of burnout is motivation going away.
- It’s not frustration with the work, it’s just like, “Eh, I don’t want to do this.”
- At a certain point, if you get into the work and you have a hard time getting into it …
- … when before you used to sit down and you couldn’t wait to start doing that work…
- … I think that’s an interesting sign of burnout as well.
- **Procrastination** is a pretty good sign of burnout.

**Tips to avoid “burnout”**

-Example, let’s say you’re a coder

- During the day you code information systems, business software, etc.
- At night, don’t tinker in the same thing.
- Instead tinker in algorithms for creating mazes or 3D ray tracing or something totally different that,

-Example, pretend you are a baker and you bake muffins all day for work

- When you get to your “hobby” try baking bread or cakes, etc.

> “And I think that that’s the healthy way to manage the same thing that you do at night in your hobby and your professional life, but also to make them quite a bit different.”

## Is a 40-hour work week the correct amount? [53:45]

**Question from subscriber**: *As productivity has grown over the decades, many economists thought that that growth was going to be reflected in a shorter work week in our society. So 40 could be compressed into 32 and you’d have the same output. That number, 40, hasn’t really changed in 80 plus years. Why do you think that is the right number?*

⇒ Some speculate that [Henry Ford set the 40-hour work week standard](https://www.history.com/this-day-in-history/ford-factory-workers-get-40-hour-week)

**What Jason does at Basecamp**:

- In the summers (May through October), they work **32 hour weeks** (4 days, 8 hours per day)
- He likes giving people 3 day weekends to give them a summer “break” and to be able to take weekend trips with the family
  - Note: he tried to do it all year round but it didn’t feel “special” and so he prefers to make the summer a special time where you get a “break”
- Less work gets done, but not *that* much less, says Jason
- Any less work hours would be tough, because at 32 hours you **can’t waste any time** and any mistakes are magnified and are really difficult to recover from
- \*Jason believes 30-40 hours per week is the best range

> “It feels to me like somewhere between 30 and 40 is the right number. That’s not to say that 45 isn’t fine too. I’m sure it’s fine. The problem is when it gets into 60, 70, 80.”

***If Jason had to pick, would 5 days at eight hours be better or worse than 4 days at 10 hours?***

- Jason thinks both are good options

## How to evaluate a company’s culture when looking for a job with the right work environment [59:00]

> “Culture is not something that a company creates. You cannot create culture. Culture is the byproduct of consistent behavior. It’s what the company does. . .It’s not what you wish it to do. It’s not what you write down.”

***How to evaluate a company’s culture/work environment?***

*-The #1 advice*: **Talk to someone who works there**

- The best way to find out what a company’s like is simply to talk to the people who work there
- Find employees on LinkedIn and send them a message
  - “Hey, do you mind if we hop on the phone for 15 minutes? I’d like to hear what it’s like to work there. I really care about what it’s like to work at a company.”
- You can even call the customer service and ask them a question about the product or service
  - Doing this will indicate things like:
    - how much does the company value customers?
    - Is the customer service good or bad? How quickly do they answer? How coherent are they?
  - Additionally, you can then ask that customer service rep, “Hey, this is totally weird. But I’m also thinking about working there. What’s it like to work there?”

*-Be careful when evaluating company culture through these mechanisms:*

- 1) Looking at online reviews (like [Glassdoor](https://www.glassdoor.com/Reviews/index.htm)):
  - Oftentimes they’re filled with disgruntled ex employees
  - And there’s some value in there, but you don’t really get the context of just talking to somebody.
- 2) Company handbook, posters, or websites
  - You really need a person’s perspective not just company-speak

*-Other ideas:*

- Check out the company’s “terms of service”
- Just go look at those and see how they’re written to see what they are thinking about
- Are they written in language that regular people can understand? Or does it require a lawyer to decipher this stuff?

**When interviewing, is there anything that you would view as a warning sign?**

-Number one, always ask the question, “***What would this company say no to?***“

- More specifically, ask them things like,
  - “*What happens if I need a couple of days for mental health?*”
  - “*What happens if someone in my family close to me passes away*?”
  - If the interviewer is like, “I don’t even know. I don’t know. I guess you could maybe have a day off?”
  - That just means to me that they haven’t thought about these kinds of things, and these are just real human issues and I think that a good culture is going to think about those kinds of things.

**-Beware** if a company says, “*We’re just a big family here*”

- That’s code speak for, “You’re going to sacrifice for us like you would for your family, which means you’ll do anything that you’re called upon doing because we’re all a family here.”
- That often means busting your ass, long hours… i.e., “*You could never abandon the family and go home. You would never do that to your family. Would you abandon your family?”*

> “Companies are not families. They’re places to work and you have coworkers and you can do great work with coworkers, but you don’t need to fake this family BS. Real companies that care about people actually care about family and that means time away, time off, time to yourself.”

## Jason’s take on salaries and alternate incentives like equity, profit sharing, etc. [1:06:45]

**Does basecamp offer equity to employees?**

- Jason does not believe in offering equity to employees
- Equity is often unfair in that in most companies, it goes to zero. That’s just the reality of things.
- Private companies that never go public
- Other companies don’t do so well
- And often companies will give you equity in lieu of salary
- “But you can’t go to your local restaurant and pay with stock options. It’s not real money. It’s fake money.”
- It can sometimes pay off huge, but it’s really just a lottery ticket.
- Furthermore, Jason says it creates stress when you don’t pay people what they’re worth and instead you substitute some “lottery tickets”
- It also creates pressure for the company to finally help people cash out on those things otherwise employees will feel mislead

**Basecamp pays top of the market**

- They pay basically the 90th percentile San Francisco rates, regardless of where you live (many employees work remotely)
- It eliminates the employee having to wonder if they could be paid more somewhere else
- They don’t have to awkwardly ask for a raise
- They don’t have to be good negotiators

> “*There’s no reason for you to have to be great at two things at work, great at your job and a great negotiator.*”

**Basecamp** ***tried*** **sharing in profit growth**

- However, they never really paid out on it because we’ve only done it for three years and it’s all based on **profit growth**, not profit in itself
- Over the last few years they took on more employees so the margin did not increase
- Because of a lack of payouts, they eliminated it
- Told employees that, “*Look, this may not pay out, and having this system in place that’s constantly getting your hopes up and letting you down, that’s not healthy for anybody.*”
- NOTE: they told employees from the start that it was a 3 year experiment so it made it easier to take it off the table at the end.

**Basecamp DOES have a “stand in” for equity in the case of a sale**

- Most people want equity in the case of a liquidity event of some sort
- Instead of having to worry about granting equity and dealing with the options and investing in the whole thing, **Basecamp has a pool**
- In the event of a sale, they will set aside a minimum of 5% of the purchase price to distribute to the employees
- The longer you’ve been with the company, the higher % you will get

**Basecamp’s approach in a nutshell**:

“*We’re going to pay you exceptionally well. If you move up this level, you’re going to get this new salary and you’re going to be paid there. If we ever happen to sell the business one day, we don’t need to think about a day-to-day because it’s not going to happen anytime soon. But if it does, here’s the provision to handle that. And now you can focus on your work versus focusing on being a day trader.*”

## What traits does Jason look for when hiring new employees? [1:13:45]

**Basecamp prioritizes writing skills**

- Poor writers tend to perform poorly here, so we’re very careful about making sure that we hire great writers.
- So we look at a lot of writing samples during the hiring process, no matter what position they’re in

Jason has also noticed that **breaking habits** are harder for people that making them

- Many new hires come from more typical corporate structures
- So they have a lot of habits to break
- Basecamp takes responsibility for helping them through that process
- “So helping people work their way out of those habits is something we need to do and we need to be conscious of it and we have to be careful not to judge people on some of those behaviors.”

## Does Jason believe in process-oriented work or outcome-driven work? And Basecamp’s unique process for completing projects [1:16:15]

**How Jason’s mind has changed**:

- Previously, Jason just focused on outcomes
- The process didn’t matter so much

**Nowadays**:

- But nowadays, he has flipped his thinking
- Of course the outcomes have to be good too, but if the outcomes get you somewhere but morale has been destroyed, teams don’t like working with one another, employees don’t like each other, employees don’t like you, employees don’t trust you, no one trusts you … *that was not worth it.*
- “*A company is hundreds of decisions and thousands of projects over the course of its life.*”
- The idea is to come up with a process that is actually sustainable

**Basecamp’s process for projects**:

- They work in these six week cycles
- Then, they take two weeks off not off of work entirely but off of *structured* work
  - People can freelance internally
  - They can tighten something up that they saw was a little bit loose
  - They can fix some stuff that they weren’t thrilled with perhaps
  - They can explore a new idea or prototype
- Then they start another 6 week project

–*Why the 2 week gap?*

- This 2 week gap helps people recharge and get their mind off the big project and onto some smaller personal projects
- Jason says the idea of doing things back to back to back to back to back projects might work in the short-term, but you’re going to burn yourself out

⇒ Basecamp has published their process online at [basecamp.com/shapeup](https://basecamp.com/shapeup)

## How does Jason handle a project that results in a failure? [1:20:00]

- Using the typical definition of success, Jason has had countless projects that were not anywhere near as successful as Basecamp
- And so it didn’t make sense for us to spend our time with them anymore.
  - Some they’ve shut down
  - Some they’ve spun off into separate companie
  - Some they continue to maintain but don’t improve anymore (like [High Rise](https://highrisehq.com/))
- For all of these cases, the products/software where just not worth their time to keep putting energy into it
- Jason has been in business for 20 years and says, “*we’ve only had one major hit . . . I think if you get one hit in your life. . .you’re pretty lucky*.”

**How Jason views “failures”**:

- Say you’ve spent a year on something that didn’t live up to your hopes
- Is that a failure?
  - Jason says, “I just see it as an experience and we move on from it and we keep going. It didn’t take us down. It didn’t kill the business. It didn’t kill anybody here. We’re okay. It just didn’t do as well as other things. So let’s just come to terms with that.”

> “The failure would be to continue to pour effort and energy into something that you know is never going to get where you want it to get or where you want it to be. And that’s the failure. It’s not that it didn’t do as well as you’d hoped. The failure would be that you’re lying to yourself about that.”

## Advice for people in situations where they don’t have full control of their time and work demands [1:23:50]

**What advice might Jason have for people who have a job where their work hours, environment, and their success and performance is heavily influenced by forces outside their control (like salespeople)?**

- Basecamp doesn’t employ any salespeople
- But Jason can speak to the jobs that have less control on their environment and their time
- And that would be their cyber security, operations, and customer service team when there are technical problems
- “Their job in a sense is out of their control, and even more so today than perhaps ever before.”

**How Basecamp deals with a big issue like a total outage**:

- Everyone’s stressed out, we’re stressed out, the customer is stressed out.
- How do you explain what’s going on? You can’t always give an exact time when we’re going to be back because we don’t know.
- So we’ve just decided to be **extremely honest and clear with people**.

–*They have an internal writing guideline…*

- checklists that we resort to during times of duress so we don’t let our emotions get the best of us.
- We don’t use exclamation marks whenever we have to talk about downtime or uptime or issues like that.
- We just don’t want to make things emotional for people.
- We want to be very clear, very coherent, brief, but detailed, speak in terms that everyone can understand, no lingo.

## How much of success should be attributed to skill versus luck? [1:29:30]

> “Most companies don’t have anywhere near the luxury of even creating a moment for themselves. They have to live in other people’s moments and in other industries’ moments in other economies’ moments. And so I just think that luck and time is the substrate. You have to work within those things. And sometimes you’re going to hit it and sometimes you’re not.”

-A listener asks Jason whether he might be attributing too much of people’s success (and his own) to luck

-The listener then quotes [Peter Thiel](https://en.wikipedia.org/wiki/Peter_Thiel) (who quotes [Ralph Waldo Emerson](https://en.wikipedia.org/wiki/Ralph_Waldo_Emerson)), “’*Shallow men believe in luck, believe in circumstances. Strong men believe in cause and effect.*”

-Jason’s response: “*I think* ***luck and timing are sort of the substrate and everything grows on that****, and timing probably more than anything.*”

**More about Timing**:

- Whatever you’re making, whatever you’re doing, it’s got to be useful, so that has to be true…
- …but if the timing is wrong, it doesn’t matter.
- If you’re way ahead of your time or way behind your time, it sort of doesn’t matter how useful it is or how good it is or how good on paper it is.
- Timing has to be there.
- S*ome great people CAN create their own timing*:
  - [Cyber Truck](https://www.tesla.com/cybertruck) just introduced by Tesla (“From this point forward, every design group inside every car manufacturer is going to look at this thing that Tesla designed and it’s going to influence them in one way or another. So in that case, Tesla created a new time.”)
  - Apple could also fall into the category of “creating timing”
  - But these are the **exceptions**

*-It’s not that skill and execution don’t matter… they DO matter*:

- Skill matters
- execution matters
- vision matters
- communication matters
- how you treat people matters
- what kind of team you can build matters
- how you can put the right people together matters
- hiring matters
- Customer service matters

> “But ultimately, you don’t get to pick your own luck and your own timing. You ride on the wave and you’ve got to catch it. . .I think it has a huge, huge degree of influence over whether or not ideas and companies make it and some don’t.”

**Peter’s take**:

- One complicating factor is that success begets success, and therefore luck begets success, says Peter
- In other words, you must get lucky with timing for initial success but after that you have more opportunities because you had that benefit of luck in the beginning
- But it’s incredibly difficult to determine cause and effect by looking at someone’s past actions… “*retroactive, retrospective, association-based … I mean, it’s the equivalent of basically epidemiology. And I just don’t know how to extract cause and effect from that.*”

**Jason says**:

- I would bet that timing and luck have a lot more to do with someone’s success than anything.
- There will always be the extreme outlier
- But I would just say to this person, “*whatever you believe, just do your best anyway. And Hey, if luck and timing is on your side, all the better. If you create your own luck and timing, great. And if it doesn’t work because you didn’t have luck and timing, who knew anyway? Just do your best. Just do the best work you can and don’t worry about like what the reasons for success or failure ultimately are, because you probably don’t really know exactly what they are.*”

**Do we even have free will? How much credit can you r*****eally*** **take for anything?**

- This is a mind-bending topic
- But people like [Sam Harris](https://en.wikipedia.org/wiki/Sam_Harris) suggest that we don’t really have free will
- But even if you don’t fully subscribe to that theory, it’s easy to realize how much of the good fortune you’ve received has nothing to do with something you did
- Grew up in a good family, born with an ability to work hard, born with a higher IQ (e.g., Bill Gates), right place at the right time, knew the right person, etc.
- It begs the question of how much credit can you **really** take for anything?

⇒ Jason quotes Harry Truman (maybe?): “*A man may do an immense deal of good, if he does not care who gets the credit for it.*” —Harry Truman? (see [quoteinvestigator.com](https://quoteinvestigator.com/2010/12/21/doing-good-selfless/))

## The importance of writing skills and tip to improve your writing [1:43:15]

**Jason’s favorite book on writing**: [Revising Prose](https://www.amazon.com/Revising-Prose-5th-Richard-Lanham/dp/0321441699)

**Jason’s three favorite business writers**:

 1 | [Warren Buffet](https://en.wikipedia.org/wiki/Warren_Buffett)

 2 |  [Charlie Munger](https://en.wikipedia.org/wiki/Charlie_Munger)

 3 | [Jeff Bezos](https://en.wikipedia.org/wiki/Jeff_Bezos)

- Jason says they are wonderful communicators
- And says if you read their shareholder letters you’ll come away thinking, “*I understand what they’re trying to say. You couldn’t have said it any better.*”

**Tips for improving writing**:

1 | Read the work of good writers

2 | Practice writing and editing

- *A good writing exercise*: Write something that takes three pages, then write a one page version, then a three paragraph version, then a one paragraph version, a one sentence version

3 | Read your own writing out loud

- Is it flat? Is every sentence the same length? ⇒ Not good things
- You want some texture and some rhythm
- If you find you are stumbling over things (i.e., it doesn’t read how you would actually say it), then you should re-word it until there is no stumbling

**More recommended writers and works**:

- [Howard Marks](https://en.wikipedia.org/wiki/Howard_Marks_(investor)) (Peter’s rec)
  - Check out his email [newsletter](https://www.oaktreecapital.com/insights/howard-marks-memos)
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) (Peter’s rec.)
  - See his NY Times article: [Roger Federer as Religious Experience](https://www.nytimes.com/2006/08/20/sports/playmagazine/20federer.html)
- [Annie Dillard](https://en.wikipedia.org/wiki/Annie_Dillard), a short story writer (Jason rec)
  - Jason loves her essay called [Total Eclipse](https://theessayexperiencefall2013.qwriting.qc.cuny.edu/files/2013/12/total-eclipse_annie-dillard.pdf) which can be found in her book, [The Abundance](https://www.amazon.com/Abundance-Narrative-Essays-Old-New/dp/0062432966)

## Lessons learned from parenting, and Peter’s top priority when it comes to raising kids [1:52:15]

**One lesson Jason has taken from parenting**:

- “The one thing I’ve learned about parenting, that I think is true about people, is that you can’t make someone do something they don’t want to do.”

-Translating this parenting lessons to the workplace:

- “You got to figure out a way to make people feel invested in whatever it is they’re doing, and make them feel good about it, versus forcing people to do things they don’t want to do.”

**Peter’s take:**

*-Top priority when it comes to parenting:*

- “If I literally accomplish not a single thing in life other than shield them from my baggage and my nonsense, and set them up to be resilient and happy and great people, oh man, that’s the only thing that matters.”

*-Don’t beat yourself up*:

- Peter says don’t beat yourself up over one single failure, or loss of temper, etc.
- “Take some comfort in knowing that in the end, it’s a very long game…so you want to just think about being very consistently good.”

**On being more open to your kids about your mistakes**:

- At the advice of his therapist, Peter has been making a point to be more open with his kids about when he makes a mistake
- Use your judgment though, you don’t want to enmesh them with all your woes
- It’s more about admitting when you did something wrong or lost your temper

-Peter likes this process because…

- It’s a way to diffuse some of the shame of making mistakes
- Also you can make these teachable moments to the kid
- It tends to cut down on the mistakes when you bring another person in on your attempt at self-improvement
- Hopefully you model for them that they can take ownership over their mistakes also.

## An important skill: The ability to say “no” to things [2:01:15]

**Jason has come to believe that the ability to say “no” to things is a very important skill**:

“*Yes is cheap, it’s easy to say yes to anything, especially if you don’t have to do it right now. And that adds up over time. And then it turns out that by the time those things come due, you wish you hadn’t said yes.*”

**A packed schedule can be a tremendous source of anxiety**:

“*I think keeping that in mind is really important in order to help reduce the stress and anxiety of the future, and also to help reduce stress and anxiety at work. Packing your schedule in the future is a great way to never have any time to do anything else. So working on getting better at saying no is just an important thing to keep in mind.*”

§

## Selected Links / Related Material

**Jason’s company**: [Basecamp](https://basecamp.com/) | (basecamp.com) [6:45]

**Jeff Bezos only makes important decisions in the first half of the day**: [Jeff Bezos Schedules His Most Important Meetings at 10 a.m. Here’s Why You Should Too](https://www.inc.com/justin-bariso/jeff-bezos-schedules-his-most-important-meetings-before-lunch-heres-why-you-should-too.html) | Justin Bariso (inc.com) [17:45]

**The Glass House by Philip Johnson in New Canaan, Connecticut**: [Glass House](https://en.wikipedia.org/wiki/Glass_House) | (wikipedia.org) [27:30]

**Previous episode of The Drive with Jason Fried**: [#74 – Jason Fried: Optimizing efficiency and work-life balance](https://peterattiamd.com/jasonfried/) | Peter Attia (peterattiamd.com) [37:30]

Peter’s interview of Ric Elias on The Drive: [#79 – Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/) | Peter Attia (peterattiamd.com) [40:45]

**Book which stresses that you aren’t optimizing for the short term, but rather the long term**: [The Infinite Game](https://www.amazon.com/Infinite-Game-Simon-Sinek/dp/073521350X) by Simon Sinek | (amazon.com) [40:45]

**Some speculate that Henry Ford set the 40-hour work week standard**: [Ford factory workers get 40-hour week](https://www.history.com/this-day-in-history/ford-factory-workers-get-40-hour-week) | (history.com) [54:45]

**Website where you can see what current and former employees think about the company they worked for (Jason says beware because many review are disgruntled employees)**: [Glassdoor](https://www.glassdoor.com/Reviews/index.htm) | ([glassdoor.com](https://www.glassdoor.com/index.htm)) [1:02:00]

**Basecampe has published their process online describing how they break projects up**: [Shape Up: Stop Running in Circles and Ship Work that Matters](https://basecamp.com/shapeup) | (basecamp.com/shapeup) [1:18:45]

**Other software/companies/websites that Jason has been a part of creating**:

- [High Rise](https://highrisehq.com/) [1:21:30]
- [Sortfolio](https://www.sortfolio.com/) [1:23:15]
- [We Work Remotely](https://weworkremotely.com/) [1:23:15]

**The new Tesla Cyber Truck which Jason used as an example of the rare case when a person or company ‘makes their own timing’**: [Cybertruck](https://www.tesla.com/cybertruck) | (tesla.com) [1:31:00]

**The famous Apple Super Bowl ad from 1984**: [1984 Apple’s Macintosh Commercial (HD)](https://www.youtube.com/watch?v=VtvjbmoDx-I) | Mac History (youtube.com) [1:37:30]

**Jason’s favorite book on writing**: [Revising Prose](https://www.amazon.com/Revising-Prose-5th-Richard-Lanham/dp/0321441699) by Richard A. Lanham | (amazon.com) [1:44:30]

**Peter enjoys the newsletter by Howard Marks**:  [Archived Memos](https://www.oaktreecapital.com/insights/howard-marks-memos) | (oaktreecapital.com) [1:48:15]

**The “unbelievable article” by David Foster Wallace about Roger Federer in the NY Times**: [Roger Federer as Religious Experience](https://www.nytimes.com/2006/08/20/sports/playmagazine/20federer.html) | David Foster Wallace (nytimes.com) [1:48:30]

**Jason loves Annie Dillard’s essay called**: [Total Eclipse](https://theessayexperiencefall2013.qwriting.qc.cuny.edu/files/2013/12/total-eclipse_annie-dillard.pdf) | (theessayexperiencefall2013.qwriting.qc.cuny.edu) [1:49:30]

**Total Eclipse can be found in her book**: [The Abundance: Narrative Essays Old and New](https://www.amazon.com/Abundance-Narrative-Essays-Old-New/dp/0062432966) by Annie Dillard | (amazon.com) [1:49:45]

§

## People Mentioned

- [David Heinemeier Hansson](https://twitter.com/dhh?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (co-founder of Basecamp) [7:00, 1:27:15]
- [Gandhi](https://en.wikipedia.org/wiki/Mahatma_Gandhi) [9:45]
- [Philip Johnson](https://en.wikipedia.org/wiki/Philip_Johnson) (designed the Glass House) [27:30]
- [Steve Jobs](https://en.wikipedia.org/wiki/Steve_Jobs) [30:30, 1:20:00]
- [Marcus Aurelius](https://en.wikipedia.org/wiki/Marcus_Aurelius) [30:45]
- [Ric Elias](https://twitter.com/ricelias?lang=en) [40:45]
- [Simon Sinek](https://en.wikipedia.org/wiki/Simon_Sinek) [40:45]
- [Henry Ford](https://en.wikipedia.org/wiki/Henry_Ford) [54:45]
- [Peter Thiel](https://en.wikipedia.org/wiki/Peter_Thiel) [1:30:00]
- [Ralph Waldo Emerson](https://en.wikipedia.org/wiki/Ralph_Waldo_Emerson) [1:30:00]
- [Elon Musk](https://en.wikipedia.org/wiki/Elon_Musk) [1:32:00]
- [Jim Collins](https://www.jimcollins.com/about.html) [1:35:00]
- [Sam Harris](https://en.wikipedia.org/wiki/Sam_Harris) [1:38:30]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) [1:39:15]
- [Harry Truman](https://en.wikipedia.org/wiki/Harry_S._Truman) [1:43:00]
- [Warren Buffet](https://en.wikipedia.org/wiki/Warren_Buffett) [1:45:00, 2:03:00]
- [Charlie Munger](https://en.wikipedia.org/wiki/Charlie_Munger) [1:45:00]
- [Jeff Bezos](https://en.wikipedia.org/wiki/Jeff_Bezos) [1:45:00]
- [Howard Marks](https://en.wikipedia.org/wiki/Howard_Marks_(investor)) [1:48:15]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) [1:48:30]
- [Roger Federer](https://en.wikipedia.org/wiki/Roger_Federer) [1:48:30]
- [Annie Dillard](https://en.wikipedia.org/wiki/Annie_Dillard) [1:49:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/10/bio-jason-fried.jpg)

##### Jason Fried

Jason is the co-founder and CEO of [Basecamp](https://basecamp.com/), a project management software business, committed to building the best web-based products and tools with the least number of unnecessary features. He’s also the co-author of several books, Getting Real, Rework, Remote, and It Doesn’t Have To Be Crazy At Work.

Twitter: [@jasonfried](https://twitter.com/jasonfried)

Jason’s [books](https://www.amazon.com/Jason-Fried/e/B002MQ13PQ)