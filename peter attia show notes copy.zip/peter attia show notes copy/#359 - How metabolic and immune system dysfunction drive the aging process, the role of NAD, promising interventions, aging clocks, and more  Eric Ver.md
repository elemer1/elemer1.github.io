# #359 ‒ How metabolic and immune system dysfunction drive the aging process, the role of NAD, promising interventions, aging clocks, and more | Eric Verdin, M.D.

**Source:** [https://peterattiamd.com/ericverdin/](https://peterattiamd.com/ericverdin/)

---

Eric Verdin is a physician-scientist and the CEO of the Buck Institute for Research on Aging whose career has centered on understanding how epigenetics, metabolism, and the immune system influence the aging process. In this episode, Eric traces his scientific journey from studying viruses and histone deacetylases (HDACs) to leading aging research at the Buck Institute, offering insights into how aging impairs immune and nervous system function—including thymic shrinkage, chronic inflammation, and reduced vaccine response—and how these changes impact lifespan. He explores the metabolic underpinnings of aging, such as oxidative stress and insulin and IGF-1 signaling, and he discusses practical tools like zone 2 cardio, ketogenic diets, and GLP-1 drugs. The conversation also covers declining NAD levels with age, the roles of NAD-consuming enzymes such as sirtuins and CD38, and what current NAD-boosting strategies (like NMN, NR, and IV NAD) can and can’t accomplish. Eric weighs in on promising longevity interventions including rapamycin, growth hormone for thymic regeneration, and anti-inflammatory therapies, while also examining the promise and limitations of current biological age tests and the potential of combining epigenetic, proteomic, and organ-specific metrics with wearables to guide personalized longevity care.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/ericverdin/the_Drive_public.png)

Play

#359 ‒ How metabolic and immune system dysfunction drive the aging process, the role of NAD, promising interventions, aging clocks, and more | Eric Verdin, M.D.

#359 ‒ How metabolic and immune system dysfunction drive the aging process, the role of NAD, promising interventions, aging clocks, and more | Eric Verdin, M.D.

1x15s30s

0:002:11:11

## We discuss:

- Eric’s scientific journey from virology to the field of geroscience [2:45];
- How dysfunction in the immune system and central nervous system can drive aging throughout the body [5:00];
- The role of metabolism and oxidative stress in aging, and why antioxidant strategies have failed to deliver clear benefits [8:45];
- Other aspects of metabolism linked to aging: mitochondrial efficiency, fuel utilization, and glucose-modulating drugs [16:30];
- How inefficient glucose metabolism drives insulin, IGF-1 signaling, and accelerates aging [21:45];
- The metabolic effects of GLP-1 agonists, and the need to move beyond crude metrics like BMI in favor of more precise assessments of metabolic health [27:00];
- The case for immune health as a “fifth horseman” [36:00];
- How the innate and adaptive immune systems work together to build immune memory [39:45];
- Why vaccines lose effectiveness with age: shrinking of the thymus gland and diminished T-cell diversity [44:15];
- Exploring growth hormone, thymic regeneration, and the role of exercise in slowing immune aging [48:45];
- The challenges of identifying reliable biomarkers for immune function, and the potential of rapamycin analogs to enhance vaccine response in older adults [57:45];
- How rapamycin’s effects on the immune system vary dramatically by dosage and frequency [1:03:30];
- The limitations of mouse models in aging research and the need for cautious interpretation of rapamycin’s benefits in humans [1:08:15];
- NAD, sirtuins, and aging: scientific promise amid commercial hype [1:15:45];
- How CD38 drives age-related NAD decline, influences immune function, and may impact longevity [1:23:45];
- How NMN and NR supplementation interact with CD38 and NAD metabolism, and potential risks like homocysteine elevation and one-carbon cycle depletion [1:31:00];
- Intravenous NAD: limited evidence and serious risks [1:37:00];
- Interleukin-11 (IL-11) as a new target in immune aging, the dual role of chronic inflammation in aging, and the need for better biomarkers to guide interventions [1:43:00];
- Biological aging clocks: types of clocks, promise, major limitations, and future outlook [1:48:30];
- The potential of proteomics-based aging clocks for detecting organ-specific decline and frailty [2:00:45]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Eric Verdin is a physician scientist who spent two decades uncovering how epigenetics, metabolism, and the immune system drive aging
- He now serves as the president and CEO of the Buck Institute for Research on Aging

In this episode, we discuss

- Eric’s path from studying viruses and HDACs to leading the Buck Institute and focusing on aging research
- How aging changes the immune and nervous systems
  - For example: thymus shrinkage, loss of T cell diversity, chronic inflammation, and weaker vaccine response
  - Why these changes can ultimately shorten lifespan
- Metabolic drivers of aging
  - Oxidative stress
  - Fuel choice
  - Insulin and IGF-1 signaling
- Practical tips on zone 2 cardio, ketogenic nutrition, and GLP-1 drugs
- Why NAD levels fall with age
  - The role of sirtuins and CD38
- What NMN, NR, IV NAD can and can’t do
- The importance of stopping NAD loss
- Drugs that have the potential to slow aging
  - Including optimal rapamycin dosing
  - Growth hormone based thymus regrowth
  - Blocking IL-11 or IL-1
  - And how these things might compare with exercise
- Current ways to measure biologic age, and the limits of today’s epigenetic clocks
- New proteomic and organ-specific tests
- How combining multiple metrics with wearables may guide personalized longevity care

## Eric’s scientific journey from virology to the field of geroscience [2:45]

**Give folks a little bit of a sense of what attracted you to the field of geroscience and how your journey and background brought you to where you are today**

- It’s a bit of a serendipitous type of story
- Eric is an MD by training from Belgium
- He did his last year of medical school at Harvard, and this just opened his eyes to a whole world
- He was the first person in his family to go to college

Eric explains, “*Ending up at Harvard with some of the best teachers, some of the best students, was just mind-blowing. I went to medical school wanting to do research, never had that sort of a ‘doctor fiber,’ I call it, so I really wanted to research*.”

- He finished medical school and came back for a postdoc at the Charleston Clinic, working on diabetes and metabolism
- This is where the story gets circuitous
- He ended up becoming interested in the reason for the etiology of type 1 diabetes and worked on viruses and autoimmunity

***This led him to mostly a career in virology, which confuses people***

- He spent many years working on a variety of viruses including HIV, and herpes viruses, and so on
- Through that work, he ended up cloning some of the first **epigenetic regulators**, a family of proteins called [HDACs](https://en.wikipedia.org/wiki/Histone_deacetylase)
- This family of epigenetic regulators ended up being important in aging, and starting in 1995, 1996, his lab shifted toward the study of aging
- Today, he has only one postdoc in the lab who is working on HIV

***The whole lab is focused on epigenetics, immunology, and metabolism, so the interface between these variables***

Eric reflects, “*In some way, it’s the beauty of an academic career, which I’ve just followed my interest, sometimes followed the money a little bit in terms of funding*.”

- Now, Eric has another additional responsibility, which is to lead the [Buck Institute for Research on Aging](https://www.buckinstitute.org/)
- He splits his time between the lab and some more leadership type of activities

## How dysfunction in the immune system and central nervous system can drive aging throughout the body [5:00]

**You mentioned two things there, metabolism and immunology ‒ talk a little bit more about how each of those individually contributes to aging**

- Immunology is central to aging in many respects

> “*There is data showing that there are two organs that are rate-limiting in terms of your aging. It’s the central nervous system and the immune system.*”‒ Eric Verdin

- One could have predicted this based on the fact that both organs are distributed organs
  - If you think of your immune system, it’s located in pretty much throughout the whole organism, and so its activity can influence the wellbeing or the functioning of every single organ
  - The same goes for a central nervous system
- A recent [study](https://pubmed.ncbi.nlm.nih.gov/40015764/) came out from the lab of [Tony Wyss-Coray](https://profiles.stanford.edu/tony-wyss-coray) showing that those biomarkers that measure aging in those organs appears to be the most predictive of your lifespan
- There’s also incredible data showing that if you induce a specific lesion in the immune system, for example in mice model, if you [knockout ERCC1](https://pmc.ncbi.nlm.nih.gov/articles/PMC3139823/#S9:~:text=Figure%201).-,Figure%201.,-Open%20in%20a) (DNA damage repair) only in the bone marrow so that the whole immune system is affected, you actually induce accelerated aging in the whole organism and senescence in every single organ
  - It’s been done with the ERCC1 mutation
  - It’s also been done by knocking down the major TFAM (the major transcription factor for mitochondria)
  - If you induce mitochondrial dysfunction only in the immune system, you induce secondary senescence in the whole organism

Peter asks, “*Do you think that would be true in humans?*”

- It’s a million-dollar question
- It’s been shown in 2 different models in mice
  - Eric doesn’t remember the exact strain of the mouse, but there’s no reason why it should be different
- It points to the importance of the immune system
- The second wave for the immune system is through chronic inflammation, which is tied cause and effect in the whole aging process

> “*I find it fascinating, the whole idea of chronic inflammation which is induced by the aging process, which itself actually further accelerates aging*.”‒ Eric Verdin

- There’s really a lot of work that’s being conducted in this area
- The other one that you were asking is metabolism.

***Peter finds it very interesting: 2 organ systems that are going to be rate-limiting in age are the central nervous system and the immune system (both of which are distributed throughout the body)***

**Where would you put the endothelium in that list?**

- Peter notes that the endothelium is also quite distributed across the organism

*Do you think that there’s an inevitability to basically endothelial damage as a process of aging, which, of course, results in the leading cause of death, the atherosclerotic diseases?*

- It’s not sort of defined as an organ by itself
- It’s a cell type
- Eric agrees about its incredible importance, especially as it affects the heart and the cardiovascular system and the brain
- But he thinks of it more as a principle that maintains barrier function
  - Not only in the endothelium but also in the skin, in the blood brain barrier
  - These are emerging as key areas to focus on if you want to maximize your longevity

## The role of metabolism and oxidative stress in aging, and why antioxidant strategies have failed to deliver clear benefits [8:45]

**Metabolism is essential to life expectancy for a number of reasons**

- Eric is convinced even though the whole ‘oxidative stress theory of aging’ has been somewhat discredited, ***he still thinks oxygen is one of the major problems associated with the aging process***
- We have not been able to target the oxidative stress using antioxidants, that has failed
  - It doesn’t mean that the whole oxidative stress theory of aging is not valuable
- He thinks living in an oxidative environment is one of the mechanisms that leads to aging

**⇒** Not the only one, aging is pleomorphic

Peter summarizes, “*You are saying that the generation of free radicals through oxygen… Apologies to those who don’t want to go this deep, but we had to talk about what the role of the electrons are in oxygen and why free radicals form and what they do*.”

*Go a little deeper here and explain what you’re saying*

- The main metabolic reactions are dependent on oxygen, which gives its electron in the [respiratory chain](https://en.wikipedia.org/wiki/Electron_transport_chain)
- There is leakage of these electrons that are traveling down the respiratory chain
- If the process was 100% efficient, the whole energy would be transferred from metabolites such as fatty acids and glucose, but it turns out the mechanism is actually leaky

***These electrons reacting with oxygen can generate byproducts called radical oxygen species, which are highly reactive***

- They’re not chemically stable in the way we think of a normal atom of oxygen

**⇒** These radical oxygen species tend to react with proteins, with fatty acid, and they induce lesions

- The importance of this system in terms of protection against it is highlighted by the number of molecular systems that we have that are actually protecting against this

*We know that as we age, that leakage [of reactive oxygen species] increases*

- There’s something about the integrity of the mitochondria and the [respiratory electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain) degrades as we age, and therefore we see more and more of this leakage

***Out of this came the whole idea, well, let’s just suppress oxidative stress***

- There are chemicals, even some as simple as vitamin E, vitamin C, that you could imagine that, by chemical knowledge, would be predictive to be able to quench these radical oxygen species

Peter explains, “*You eat, for example, an* [*antioxidant*](https://en.wikipedia.org/wiki/Antioxidant)*, and as you said, it neutralizes that reactive oxygen species with its unstable electrons, kind of like you would throw a blanket on a fire that’s simmering.*”

- That was the hope when the theory was proposed
- A whole industry grew up out of this
  - The whole antioxidant, and the antioxidant diet, and the vitamins, and so on
  - That industry is still existing today

**⇒** When clinical trials were conducted in this area, they failed

- People who think relatively simply decided, “*Well, the antioxidant failed, therefore the theory has no validity.*”
- Eric would say “*Not so fast*”

**It turns out that these radical oxidative species also have important roles**

- They actually are inducing an inflammatory response which can be protective
- A good example is during exercise, there is some evidence of activation of oxidative stress during exercise
- If you neuter this, for example, with anti-inflammatory drugs tend to suppress some of the beneficial effects of exercise, it’s the same whole idea

***Exercise is one case in which these radical oxygen species can have a protective role and actually a signaling role***

- When you suppress it completely with these global nonspecific antioxidants, essentially, you’re not only killing the bad guys but you’re also suppressing an important signaling mechanism

Peter offers another hypothesis

- Is it possible that there’s still a net negative to the free radicals?
- There might be some benefits, but more negatives
- It could be that in the trials we’re using agents that were simply ineffective, because the problem is we don’t have a great biomarker for the state of free radicals
- It’s like saying, “*I have a hypothesis that this biological process is bad. I can’t measure it really, but I think it’s bad. I have a drug that I think will tamp it down. Let’s give the drug,*” the trial failed
- Well, do you actually know if it tamped the thing down?

***We don’t even know if we tested the hypothesis, and so those would be two distinct plausibilities***

- Eric agrees

This is quite often the case, and the whole story of vitamin D is a good example

- People will tell you vitamin D doesn’t work, because they conducted clinical trials
- But they didn’t adjust the dose, they didn’t measure the levels
- It’s a bit the same story

**⇒** There are markers that you use in a research environment (like [4-hydroxynonenal](https://en.wikipedia.org/wiki/4-Hydroxynonenal) or [protein carbonization](https://pmc.ncbi.nlm.nih.gov/articles/PMC2821144/#:~:text=Protein%20carbonylation%20is%20a%20well,which%20may%20result%20in%20pathogenesis.)) which are indirect markers of lipid or protein oxidation

Peter asks, “*How efficacious… how complete are they in the scope of understanding? And have we demonstrated that megadoses of vitamin E or vitamin C will indeed suppress those markers in humans?*”

- They’re not great
- Eric had a colleague at the Buck Institute ([Martin Brand](https://www.buckinstitute.org/research/research-professors/#:~:text=EMERITUS%20FACULTY-,Martin%20Brand%2C%20PhD,-Professor%20Emeritus)) who was one of the leaders of the whole mitochondrial field called bioenergetics
- This is the study of how the respiratory chain and energy metabolism happens in mitochondria
- He identified many of the sites where these unique radical oxygen species are generated
- He was able to generate specific inhibitors for each of the sites

***He was able to show that inhibition [of radical oxygen species] at some sites was beneficial while inhibition at other sites was not beneficial***

- This project was actually supported by pharma company, which eventually decided to drop the program
- Martin is now retired, which Eric thinks is a great loss because it is a whole program that still needs to be pursued

**Peter’s takeaway**

- There’s a much more nuanced view
- It’s not that free radicals are bad and it’s not that free radicals are good
- It’s like everything in biology, it’s the ‘Goldilocks rule’
  - You might need more of it during this circumstance in this part of the body, you might need less of it in this circumstance at this totally different part of the body
- As a result, any strategy that would try to globally suppress it could, even if successful in doing it, which we haven’t been able to measure, might actually not yield to a favorable outcome

*Eric agrees and gets frustrated by the way that people love to oversimplify or erase whole fields*

- The same thing happened with sirtuins
- There’s a lot of amazing work done and then a few negative results or things not working out
- In metabolism, it’s the same thing

> “*I always tell people, once you get into any field of study, and you go deep, and you start testing in humans, put on your seatbelt because it’s not easy and there are no magic bullets*.”‒ Eric Verdin

- But I think stopping the study and saying the whole field is BS is really, not the way to go
- We got to dig deeper, and eventually, we will get to that

## Other aspects of metabolism linked to aging: mitochondrial efficiency, fuel utilization, and glucose-modulating drugs [16:30]

**Tell me what else within metabolism you think is a hallmark of aging**

- They just talked about the central part of metabolism ‒ respiration, ATP generation, and the leakage that occurs there
  - Unfortunately, that appears to be inevitable
  - We’ll never stop the oxygen in our environment

*This is why Peter harps on his patients to do a lot of* [*Zone 2*](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/) *cardio training*

**⇒** Very specifically by definition, Zone 2 is the canonical exercise you would do to maximize fat oxidation, which implies the most efficient use of the mitochondria

- The hypothesis (because we don’t have proof of this) is: training at that level for specific periods of time throughout the week is a way to improve the health and function of your mitochondria
  - Which would hopefully imply that you’re reducing that degradation of function

**Do you think there’s validity to that at least first-order logic?**

- Yeah

***The proof is in a pudding in a way that we know that a combination of exercise is the best anti-aging intervention we have***

Peter asks, “*But do you think part of it is through that exact mechanism?*”

- Yeah, likely
- This is hard to study

**Back to the question: What is it about metabolism that really is so important?**

- Eric is convinced that it is **fuel utilization**
- Peter mentioned [fatty oxidation](https://en.wikipedia.org/wiki/Beta_oxidation) versus [glycolysis](https://en.wikipedia.org/wiki/Glycolysis), and he‘ll add [ketosis](https://en.wikipedia.org/wiki/Ketosis) to this
- Your metabolism is able to oxidize a number of different substrates: amino acids, fatty acids, glucose, ketones, and lactate
- Every one of those actually burns with different efficiency
- Both being car aficionados: it’s different to burn diesel or to burn 100-octane gas

**⇒** If you look at that hierarchy, ketones are probably the cleanest fuel to burn in terms of byproducts, oxidative stress (they seem to be very unique)

*How would you rank order from cleanest to dirtiest inclusive of lactate?*

- Eric would not be able to put lactate in this ranking; it’s probably clean
- The top would be [beta-hydroxybutyrate](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid)
- [Acetoacetate](https://en.wikipedia.org/wiki/Ketone_bodies#:~:text=These%20liver%2Dderived%20ketone%20groups%20include%20acetoacetic%20acid%20(acetoacetate)) is present at such low abundance, it’s probably not relevant as a fuel source
- Then fatty acid
- The worst is actually glucose

When you think about metabolism and aging, and a lot of the data that has emerged from the [ITP (intervention testing program)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp)

- Rich Miller has been on the podcast several times [episodes [#148](https://peterattiamd.com/richardmiller/), [#281](https://peterattiamd.com/richardmiller2/), and [#333](https://peterattiamd.com/longevityroundtable/)]

***One of the remarkable things when you look at the 7 or 10 drugs that have emerged out of 80 [tested by the ITP], they are really targeting glucose metabolism via completely different mechanism***

- Think about [acarbose](https://en.wikipedia.org/wiki/Acarbose), which is blocking absorption of glucose
- Think about [canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin) which is targeting a protein with links to glucose reabsorption in the kidney
- [Metformin](https://en.wikipedia.org/wiki/Metformin) did not actually fail, but seems to be having a very powerful effect
  - It failed unless it was paired with [rapamycin](https://en.wikipedia.org/wiki/Sirolimus)
  - There’s a study coming out in monkeys showing that it has an effect on lifespan

**Do you think rapamycin has any impact on glucose metabolism favorably?**

- Generally
- Rapamycin has been claimed to have an effect on insulin sensitivity
  - It’s not clear if that’s true at the doses being used

***Eric has taken rapamycin and has not seen any effect on his blood sugar***

- Think about acarbose, canagliflozin, metformin, and now the GLP-1 agonist (which Eric predicts will emerge as geroprotectors in the future)
- That really speaks to an important aspect, which is fuel utilization and whether you’re burning a clean fuel or whether you’re burning a dirty fuel

**Studies in mice**

- If you feed mice a pure fat diet, they live longer
  - These mice never saw a carbohydrate during their life
  - [[published in *Cell Metabolism* in 2017](https://pmc.ncbi.nlm.nih.gov/articles/PMC5609489/)]
- A lot of people don’t read the fine print very closely
  - The typical thing you’ll see is these mice were fed a high-fat diet to induce obesity so that we could test drug A, B, or C against obesity
  - In those studies, it’s not just a high-fat diet ‒ it’s a high-fat, high-sugar diet
    - They’re making some insanely hyperpalatable
    - The closest Peter can come up with is they’re making a donut

Peter thinks that’s important to point out, “*Because high-fat minus the sugar might not be the same issue.*”

## How inefficient glucose metabolism drives insulin, IGF-1 signaling, and accelerates aging [21:45]

**What do you think it is about glucose metabolism that leads to this?**

*Peter reviews the metabolic pathways needed for glucose oxidation, shown in the figure below*

- Glucose is 6 carbons, it gets broken down into pyruvate [glycolysis]
  - You get 2 pyruvates for 1 glucose
- Let’s just assume we’re doing this under aerobic conditions, so we’re not in a rush
- Those pyruvates turn into acetyl-CoAs to then enter the [Krebs cycle]

![](https://peterattiamd.com/wp-content/uploads/2025/07/f1-ericverdin-1024x727.png)

**Figure 1. Aerobic respiration oxidizes glucose for fuel**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cellular_respiration)

*What is it about that process that is not as efficient as when you are cleaving off carbons from a free fatty acid and those carbons are turning directly into the Krebs cycle?*

- Peter finds this to be a very subtle difference, yet one is so much more inefficient, dirtier
- This is a really complicated question, and Eric doesn’t know that he would be able to really explain purely as fuels whether there is a difference
- The biggest difference is in terms of the whole mechanism that they elicit
- When we think about glucose, if you were to study it in a tissue culture dish, that one would be more toxic than the other
  - Eric doesn’t think there’s any evidence for this
- Glucose, and particularly the form of glucose that we have not evolved to actually be exposed to (which is all the wheat products, this fast form of glucose) elicits [insulin](https://en.wikipedia.org/wiki/Insulin) secretion

***Eric thinks insulin and IGF-1 (particularly insulin) is the culprit in this whole process***

- Peter knows there’s a difference in ATP generation between 1 mole of glucose and 1 mole of free fatty acid
- Assuming they’re both going through the mitochondria

*Are you saying there’s a difference in free radical formation mole per mole?*

Peter adds, “*There’s another way to explain it, which is per mole of ATP, you need to run so much more glucose through that, of course, you’re going to get more leakage.*”

- The key difference is glucose is generating ATP in the cytoplasmic components
  - [The previous figure shows glucose breakdown occurs in both the cytoplasm and mitochondria]
  - This doesn’t happen with the fatty acids [all the ATP is generated in the mitochondria]
- Eric suspects there might be a difference in terms of the amount of free radicals that are generated
- There is evidence that one burns more cleanly than the other
  - He would not be able to city the paper

***Eric suspects it’s partly the cytoplasmic component of glucose; it’s also less efficient in terms of the amount of energy that’s being generated per mole of fatty acid versus per mole of glucose***

**Going back to the insulin IGF component here, what role do you think they’re playing?**

- Critical
- Through epidemiological studies we know that the insulin responds to your glucose
- Eric is not a proponent of the low carbohydrate or no carbohydrate diet, because there’s very little evidence that those diets are actually beneficial
  - He gave the example of a ketogenic diet, which he did experimentally, but these are not practical diets for anyone
    - Socially, for reasons of palatability, there are so many reasons
  - Eric went on a ketogenic diet for a couple of years, and it was very hard
    - He did not feel super healthy, which is really interesting
    - He found it socially isolating
    - He worked to remedy this with [novel ketone ester of beta-hydroxybutyrate](https://pmc.ncbi.nlm.nih.gov/articles/PMC8234448/)
  - Peter ate a ketogenic diet for 3 years
- Going back to the role of [insulin](https://en.wikipedia.org/wiki/Insulin), there is a lot happening that’s been documented
- First, your average glucose plays a role in a whole series of complications, cardiovascular
  - This is measured by [hemoglobin A1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin), but perhaps more important is the intensity of your peaks

**⇒** The intensity of the peaks of insulin is a reflection of your glucose intake, fast-absorbing glucose, and that’s reason why we advocate people to go on a CGM (continuous glucose monitor) and to really learn to understand what spikes them

***The whole idea is to mitigate these peaks of insulin secretion***

- Peter is going to play this for all of his patients
  - He has this discussion with every patient, so it’ll be nice to just play this video and let Eric do the talking

> “*The whole idea there is to, again, mitigate these [glucose] peaks, either dietarily or, for example, the GLP-1 agonists are playing a role in this as well.*”‒ Eric Verdin

## The metabolic effects of GLP-1 agonists, and the need to move beyond crude metrics like BMI in favor of more precise assessments of metabolic health [27:00]

**Possible benefit of GLP-1 agonists for controlling** [**HBA1c**](https://en.wikipedia.org/wiki/Glycated_hemoglobin) **levels**

- There is a great deal of confusion around this point
- We understand today the role that the gut plays in metabolism, and we understand that a lot of it is transduced through [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1)
- Endogenous production of GLP-1 is what’s driving 80% of beta cell activity with respect to insulin
  - According to [Ralph DeFronzo](https://directory.uthscsa.edu/academics/profile/defronzo), the world’s authority on this
  - [discussed further in [episode #337](https://peterattiamd.com/ralphdefronzo/)]
- Therefore, when we have [insulin resistance](https://en.wikipedia.org/wiki/Insulin_resistance), the GLP-1 we’re making is insufficient to generate the insulin that’s required to manage the glucose
- Makes sense if that’s the case, that giving exogenous GLP-1 you’re going to overcome the resistance at the [β-cell](https://en.wikipedia.org/wiki/Beta_cell), you make more insulin, you now have better glucose control (everybody wins)
  - You take a shot of [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide) or [semaglutide](https://en.wikipedia.org/wiki/Semaglutide), you’re going to put more GLP-1 in the system
- Now, it’s not clear that that has anything to do with the weight side of it (that’s a separate issue)
- Peter wants to actually talk about that, because there are 2 very interesting theories as to why these things cause weight loss, but the point here is *wouldn’t you expect to see higher levels of insulin in someone taking a GLP-1 agonist to achieve that better glycemic control?*
- Yes, but Eric explains that’s not what you see
  - He doesn’t have an answer for this

**Eric has been experimenting with tirzepatide**

- He’s seen the same thing personally
- His insulin is 5.0 now which is the lowest you can possibly get it
- Part of him was worried that he was going to go against his own whole theory about…

Peter asks, “*Have you checked postprandially? Have you done an oral glucose tolerance test? Because that might be something to do to see what is happening to postprandial insulin along with postprandial glucose (which, of course, will be better).*”

- No, he hasn’t
- He’s worn a CGM, and his A1c has gone from 5.4, 5.5 to 5.0
  - His insulin is down to 5.0 as well

*Did you lose any weight?*

- A little bit (6-7 lbs.), not a huge amount, and no loss of muscle mass
- That was never the goal to start with

Brian adds, “*Here’s the big bugaboo that people will have you fear, no loss of muscle mass if you are exercising.*”

- For him, it is just an experiment
  - He just wanted to see for himself what this drug is really doing
- He hasn’t decided this is something he is going to continue

*It’s been nothing short of remarkable*

- One of the surprising things has been this feeling of **satiety**
- He was never in his whole life the type of person who felt full ‒ he could always eat more
- All of a sudden, after about 2 weeks on this, he looked at my plate and said, “*I’m full*.”
  - This is really completely different
- This is not an endorsement
- This is self-experimentation and curiosity

> “*Self-experimentation, which is a long part of the tradition of our field*.”‒ Eric Verdin

**The thinking was one of the biggest advances in longevity medicine is this idea that a range is meaningless**

- Eric points out that as a practicing physician, Peter knows this
- When Eric went to medical school, they were told that your blood pressure has to be 130 over 90, and that was still a normal range
  - You could be 128 over 88, and you were still considered normal
- The same thing [is true] when Eric went to see his personal physician and told him, “*My blood sugar is creeping up every year that I’m doing it, and now it’s 96 fasting blood sugar.*”
  - He is worried, because soon, he’s going to be pre-diabetic
  - He said, below 100 is okay ‒ you’re normal, don’t worry
  - Eric asked, “*What is normal?*”

***This is where Eric thinks longevity medicine is going to make an important impact ‒ revisiting [the ‘normal’ range]***

*Peter has had this argument with people about glucose many times*

- We have literature in non-diabetics that says the lower the A1C, the lower the all-cause mortality
- It’s a monotonic reduction that knows no lower limit
  - We say that up to 5.6 is normal, and if you’re at 5.6, you’re fine
  - But 5.5 is better than 5.6
  - And 5.4 is better than 5.5
  - And 5.0 is better than 5.4
  - And 4.8 is better than 5.1

***Peter finds that we’ve simplified this problem in an effort to communicate, but we have lost the essence of where is lower better (because it’s not always true in biology)***

- When you look at [TSH](https://en.wikipedia.org/wiki/Thyroid-stimulating_hormone), for example (when you look at thyroid hormone), there is a much more narrow band in which we would say there’s optimal
  - If it’s too low or too high, it’s problematic

***When it comes to average blood glucose in a non-type 1 diabetic or someone who’s taking insulin, under natural physiologic circumstances, it’s just better to be lower, and as you age, it just keeps creeping up***

**It’s the same thing for blood pressure**

- They’re revisiting the number every 5 years in terms of making it lower

**⇒** If your blood pressure is 105 over 65, you’re better off than if you’re 115 over 75

***Provided you’re not symptomatic, lower is always better***

**The idea that everything is a J-curve, and there is a sweet spot where you want to be**

- Eric is frustrated but also excited by the fact that is is now becoming the norm in a whole new field of physicians who are more aware of what healthy actually is
- This is really interesting in the aging field

***Quite often, it’s broad enough that you can maneuver this in a way to optimize people’s health***

**Correcting for metabolic health and longevity**

- Body weight is a crude measurement
- We can even talk about it through adiposity, bodyfat

***So much of the relationship we see between body fat and poor health is really just a proxy for something that’s harder to measure, which is metabolic health***

- It’s very easy to measure body fat, and we estimate body fat from BMI, and so that’s why we have all these population data from BMI
- But if you have the luxury of working with actual patients, Peter couldn’t tell you the BMI of one person he takes care of, but he knows everybody’s: body fat, visceral fat, and oral glucose tolerance tests

**Are you convinced that adiposity per se is problematic, or do you believe that a person can have excess body fat but be metabolically healthy and confer the same longevity benefit as a metabolically-healthy lean person?**

**⇒** We know there are people who are considered overweight who are metabolically healthy (easily 20%)

- You can be overweight and metabolically healthy
- What Eric worries about is the long-term effect

Peter asks, “*Do you mean from an orthopedic perspective, would the other complications that come from excess weight? Or are you saying that they’re basically increasing their probability of eventually going off the metabolic slide?*”

- Both
- Eric doesn’t know what the data says, but his worry would be that you might be metabolically-looking healthy when you’re 40, but if you sustain this for 20 years
  - [the dangers of] visceral fat

*In some ways, BMI is not particularly helpful*

- BMI is that the border of being overweight
- Peter is overweight by BMI, by 4 lbs.
- If Peter lost 4 lbs, he would get down to a BMI of 25
- Eric has 11% body fat, so he doesn’t worry about it because he knows he’s metabolically healthy

***BMI serves a purpose at the population level, but it can’t be used to make a decision about an individual at all***

- Sometimes BMI can become a confounding variable

Eric explains, “*When people do studies and they use these numbers and they make predictions or they draw conclusions that are really not based on the fact that a high BMI fraction of the population is heterogeneous in terms of metabolic health*.”

**A recent paper** [**paper**](https://pubmed.ncbi.nlm.nih.gov/36941332/) **described biochemical BMI based on biological markers that essentially assess your metabolic status**

- Eric’s colleagues at the Buck, [Nathan Price](https://www.linkedin.com/in/nathandprice/) and [Lee Hood](https://www.linkedin.com/in/leehood111/) have actually published a [paper](https://pubmed.ncbi.nlm.nih.gov/36941332/)
  - They were in Seattle, but the Buck Institute recruited them in the last 2 years
    - Eric thinks this is transformative for the institute
    - Lee is still partially at Seattle and partially at the Buck
- They’ve established a collaboration with [Phenome Health](https://phenomehealth.org/)
- Nathan was still the CSO at [Thorne](https://www.thorne.com/) while also a faculty member at the Buck

***These tools are available, it’s a question of educating the physicians***

Peter asks, “*Do you know what makes up that biological BMI?*”

- No, but it’s in the [paper](https://pubmed.ncbi.nlm.nih.gov/36941332/)

## The case for immune health as a “fifth horseman” [36:00]

- Peter wants to go back and talk a little more about immune health
- Listeners of this podcast are very familiar with the metabolic stuff
- We haven’t had as many discussions on the immune system
- We’ve talked about it a length with respect to cancer ([Steve Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg)[episode #177](https://peterattiamd.com/stevenrosenberg/))
  - It was a fantastic discussion explaining the role of the immune system in cancer
  - Which Peter thinks we’re going to have to talk about here because he certainly feels convinced that a big part of why cancer incidence goes up exponentially with age is the declining immune system
    - Not just the accumulation of mutations, although he imagines they both play a role
- In Peter’s book [[*Outlive: The Science and Art of Longevity*](https://www.amazon.com/dp/0593236599/?bestFormat=true&k=outlive%20peter%20attia&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_de_k0_1_7&crid=124G2UOEUDVZO&sprefix=outlive)], he wrote about the **4 horsemen**, and he describes them as the 4 things that are coming for us all if you manage to outlive youth
  - This is not to diminish the role of trauma and other things that are deadly
  - For many people living in [OECD](https://en.wikipedia.org/wiki/OECD) nations, it’s going to come down to [ASCVD](https://peterattiamd.com/category/risks/heart-disease-prevention/), [cancer](https://peterattiamd.com/category/risks/cancer-prevention/), [dementing and neurodegenerative diseases](https://peterattiamd.com/category/risks/neurodegenerative-disease-prevention/), and [metabolic diseases](https://peterattiamd.com/category/risks/metabolic-disease/)
- People often say, “*Peter, is there anything you wish you’d written in the book that if you go back in time, you would do?*”
  - He replies, “*Yeah, there are probably many things if I thought about it, but the first thing that jumps out is, I really should have added a* ***fifth horseman****, and that is* ***immune health and the types of infections that ravage people in old age*** *that a young person would laugh at.*”
- Eric is glad Peter brought this up
- Immunology and aging have not been mixing very well
- One problem is that immunology is an extremely complex and advanced field
  - Along with neuroscience, one of the most complex
- So when you go to an aging meeting, there is no one talking about immunology
- You go to immunology meeting, there are very few people talking about aging
- We try to navigate, even the nomenclature is being used differently
  - People in immunology talk about immunosenescence, meaning aging of the immune system
  - They don’t mean senescence the way we talk about it in the aging field

***That yields all kinds of crazy communication problems***

- If you’re in the aging field, then you hear immunosenescence, you think of [SASPs](https://en.wikipedia.org/wiki/Senescence-associated_secretory_phenotype) and things that are being secreted by [T cells](https://en.wikipedia.org/wiki/T_cell)
- No; it just means aging of the immune system

**The reason why Eric thinks this is tragic for both fields [immunology and aging] is what happened during COVID**

- It became obvious that your risk of infection was not linked to your age ‒ the virus infected everyone

**⇒** But the outcome could be completely different with 84-fold excess mortality if you were above 75

*When we try to understand the reasons for this*

- Eric started to look at the literature and saw the exact same thing with influenza and RSV

**⇒** All of the viruses you can contract in the later years will kill you with really significant rates

- Around 30,000 people die each year from influenza

***The mortality in terms of COVID was really highly segregated into the older part of the population or in that part of the population that showed accelerated aging, obesity and so on***

*Do you think anytime we saw a gap in mortality (whether it was young versus old, whether it was obese versus non-obese, diabetic versus non-diabetic) , that it was always a difference in immune function?*

- Peter thinks it’s obvious when comparing young versus old
- Was that also true in the other comorbidities?
  - Eric would say yes

## How the innate and adaptive immune systems work together to build immune memory [39:45]

***Eric would say yes for 2 reasons***

- There are 2 broad immune systems: the [innate immune system](https://en.wikipedia.org/wiki/Innate_immune_system) and the [adaptive immune system](https://en.wikipedia.org/wiki/Adaptive_immune_system)

**Eric explains the immune system**

- Our immune system is built to recognize foreign elements ‒  that’s really is why it evolved
- It has 2 lines of defense against microbes, bacteria, viruses, fungi, all of those
  - We are constantly bombarded by those
- It is actually amazing because the evidence of this is if your immune system doesn’t function, it’s incompatible with life
- We are colonized with bacteria in and out, on our skins everywhere
- We constantly respond to them in an appropriate manner
  - And we survive everything, including disruptions to the barriers

*The 2 lines of defense that make up the immune system*

1 – The innate immune system

- This is your [macrophages](https://en.wikipedia.org/wiki/Macrophage), your [dendritic cells](https://en.wikipedia.org/wiki/Dendritic_cell), but also pretty much every cell has a whole series of mechanisms that are not pathogen specific
  - That is they will recognize an intruder, be it a virus, be it a fungi, be it bacteria, and they will activate a first line of defense
- Those line of defenses are non-specific and therefore they’re less effective
- They give time to the so-called adaptive immune system

2 – The adaptive immune system

- Which is made up of [T cells](https://en.wikipedia.org/wiki/T_cell) and [B cells](https://en.wikipedia.org/wiki/B_cell)
- And both of those cells have highly selective defense mechanisms
  - B cells make [antibodies](https://en.wikipedia.org/wiki/Antibody), which will go recognize a bacteria or a fungus or a virus, and
  - T cells which are able to actually kill the infected cell itself
    - So we’ll recognize when the cell is colonized by a foreign pathogen and will kill it
- The **time course** of these is that once you encounter a pathogen, you will activate your innate immune response
  - Typically, it can be fever, it can be all kinds of symptoms
  - But activation of this defense and this gives the whole organism a couple of weeks to actually build the defense for the specifically recognized organism

***The memory of the adaptive immune system***

*The innate immune system does not really have a true memory*

- It will always react in the same way, no matter how many times
- If your kids are ping-ponging the same respiratory virus at you from school, your innate immune system has the same playbook: fever, you’re going to get red (inflammation), you’re going to get sore
  - All of those things are going to happen regardless

*That’s in contrast to the adaptive immune system*

- Because once the initial response has been generated either via an infection or a vaccination
  - This is what a **vaccination** is, it presents you with a given fraction or the whole virus or a part of it, your body will mount a response and this will lead to the amplification of a subset of cells that are selective
- Think about your T-cells or your B cells, none of them are the same
- We have a process by which we generate so-called **diversity**, which is billions of different forms of antibodies or T cell receptors that are recognizing in principle, every chemical structure, every protein from a microorganism
- What happens during the initial encounter (either a vaccination or an infection), is those B cells or those T cells that have a receptor that is able to recognize the pathogen will become amplified and ***they will turn out large amount of the antibody or the T-cell clones***
- Once the job has been done, they will contract, but they will not contract back down to the same level

***They will become what we call memory T-cells or memory B cells, so that if you encounter the same antigen in the future, the reactivation process is shortened, the maturation happens faster ‒ that’s the whole idea of vaccination***

- How vaccination works: it gets you ready with a subset of memory T-cell clones or B-cell clones so that once the true virus comes, you will be able to mount a response within a few days or up to a week

## Why vaccines lose effectiveness with age: shrinking of the thymus gland and diminished T-cell diversity [44:15]

**⇒** Now what’s interesting during aging is, and people are not aware of this, if you’re above 70, most vaccinations do not work

- Actually, your immune system has aged and your vaccination [response] rates really decrease very strongly
  - From what Eric remembers, this might be different in different populations, but vaccination rate success is close to 30% if you’re above 70

Peter asks, “*During covid, what was the risk reduction for a person over 75, who was vaccinated versus not vaccinated?*”

- The vaccine was highly protective

*How do we reconcile those 2 facts?*

\*\*\*

[Eric shared more thoughts about this question by email after the podcast was recorded]

- Aging is associated with immunosenescence: a decline in both innate and adaptive immune function that reduces the immunogenicity of vaccines
  - In elderly individuals (>70), studies have consistently shown diminished antibody responses to vaccines (including [influenza](https://pubmed.ncbi.nlm.nih.gov/16213065/) and [SARS-CoV-2](https://pubmed.ncbi.nlm.nih.gov/33906236/)) and reduced seroconversion rates, sometimes below 30% depending on vaccine type and age group
- However, as Peter correctly pointed out, during the COVID-19 pandemic, vaccinated older adults had markedly lower rates of severe disease, hospitalization, and death than their unvaccinated peers

Giving this apparent contradiction further thought, one should consider the following:

- Partial immune responses (including low antibody titers and preserved T-cell responses) may be sufficient to mitigate disease severity.
- mRNA vaccines [elicit](https://pubmed.ncbi.nlm.nih.gov/32991794/) robust CD8+ and CD4+ T-cell responses, which are less affected by age than humoral immunity
- Real-world vaccine effectiveness against severe COVID-19 in elderly populations has been high—typically >80% after full vaccination, even in those >80 years old
  - [[*NEJM* 2022](https://pubmed.ncbi.nlm.nih.gov/35249272/) and [*MMWR* 2021](https://pubmed.ncbi.nlm.nih.gov/34437524/)]

***Thus, while older adults may mount weaker initial immune responses, clinical protection remains substantial (especially against severe outcomes) due to: residual immunity, memory responses, and the layered nature of the immune system***

\*\*\*

Peter observes, “*The COVID vaccine seems to have had a remarkable risk reduction in very old people. It didn’t seem to have an impressive risk reduction in younger people because the absolute risk was so low, it didn’t seem to matter that much. But boy, did it matter in older people.*”

- Eric questions if it mattered at the population level or the individual level
- Peter doesn’t want to go on record saying something
  - His recollection is that the older a person got, the greater the benefit they got from COVID vaccines with respect to mortality
- [This opinion piece from the [*BMJ* (2023)](https://www.bmj.com/content/382/bmj.p1662) synthesizes information from three different studies to conclude that older adults continue to benefit from COVID boosters; and a more recent article in the [*MMWR* (2024)](https://www.cdc.gov/mmwr/volumes/73/wr/mm7349a2.htm#:~:text=Thus%2C%20older%20adults%20are%20both%20more%20reliant%20on%20vaccination%2Drelated%20immunity%20and%20might%20require%20more%20frequent%20vaccination%20for%20protection%20against%20severe%20illness%20due%20to%20COVID%2D19) concludes that older adults “*are more reliant on vaccination-related immunity and might require more frequent vaccination for protection against severe illness due to COVID-19*”]

**Is this true for other vaccines used in older adults?**

- Peter is thinking about [influenza](https://en.wikipedia.org/wiki/Influenza_vaccine) and [pneumococcus](https://en.wikipedia.org/wiki/Pneumococcal_vaccine)
- Eric is not a vaccine specialist, but in general, ***the thinking is that there’s a dramatic decrease in the efficiency of vaccination against influenza, against RSV, against all of those as you age***

*The thinking then is, how does it work at the population level?*

- This is where the whole concept of [herd immunity](https://en.wikipedia.org/wiki/Herd_immunity) works is that if you limit the spread of the infection in a family, for example, you’re much less likely to infect grandpa

**Peter wonders if they looked at all-comers to the hospital vaccinated versus unvaccinated**

- Let’s try to control for all the confounders
- If the hazard ratio is 1.2 or 0.8, it means nothing
- But if the hazard ratio was 0.2 or 8, you’d say even with the confounders, there must be some high degree of protection that came from that

***Peter is sure someone listening to this knows the answer to that***

[A [2024 study](https://pubmed.ncbi.nlm.nih.gov/38701913/) of the UK Biobank examined the association of COVID-19 vaccination with hospitalizations from cardiovascular and other selected diseases]

- [Results shown in the figure below include PERR adjustment to reduce residual (unmeasured) confounding]
  - AF (atrial fibrillation)
  - CAD (coronary artery disease)
  - COPD (chronic obstructive pulmonary disease)
  - T2DM (type 2 diabetes mellitus)
  - VTE (venous thromboembolism)
  - NCP (non-COVID-19 pneumonia)

![](https://peterattiamd.com/wp-content/uploads/2025/07/f2-ericverdin-553x1024.png)

**Figure 2. Association of at least one dose of COVID-19 vaccination with hospitalization from various diseases. Significant reduction in the hazard ratio (shown on the x-axis) is shown in blue.** Image credit: [*International Journal of Infectious Diseases* 2024](https://www.ijidonline.com/article/S1201-9712(24)00151-6/fulltext)

**Why is it that as a person ages, they’re less likely to respond to a vaccination?**

*Peter wonders if is because*

- A – The adaptive immune system is less able to recognize the foreign pathogen and build up a high enough reserve of T cells and B cells that will respond?
- Or is it B – That they can do that, but the ability for those cells to stay in a memory state and be reactivated is somehow impaired?

***Eric thinks it’s both***

**⇒** There’s one aspect which is really unique (at least in terms of T-cells) is the fact that the diversity of the T cells is generated by the thymus

- T cells are really instrumental in terms of most vaccine response
- The thymus, a small organ behind the sternum

Peter asks, “*How big is your thymus and my thymus right now?*”

- Eric is 68, so his is probably very, very embryonic (there’s probably not much left)

***After age 50, in most people you find it very small***

- Whereas when you’re young, you can see it on an imaging sketch study
- Peter would imagine if he and Eric had a CT scan of the chest, you’d barely be able to pick it up

**⇒** The thymus is replaced by fat in most people as you age

- Although there is some somewhat controversial evidence that there might still be some clones that can be reactivated even in older people

**⇒** [Human growth hormone](https://en.wikipedia.org/wiki/Growth_hormone) is one of the interventions that has been shown to actually re-induced thymogenesis

## Exploring growth hormone, thymic regeneration, and the role of exercise in slowing immune aging [48:45]

**Are you referring to the** [**Fahy paper**](https://pubmed.ncbi.nlm.nih.gov/31496122/) **that looked at growth hormone with metformin and DHEA or something like that?**

- That’s the one
- That paper was inspired by Eric’s colleague (when he was at the Gladstone Institute), [Mike McCune](https://cfar.ucsf.edu/people/mike-mccune)
  - Patients chronically infected with HIV lose a lot of their CD4 T cells; and initially in infection, they lose a lot of their CD4 T cells
  - There was an attempt to actually try to see if you could regenerate these populations back to their normal level, because even though we  have great drugs against HIV, we could not bring those patients back to normal
  - They did a trial with human growth hormone and were able to show some degree of thymogenesis and an increase in naive T cells in these patients
- Eric believes the Fahy trial tried to reproduce this
- There’s a second Fahy trial ongoing, but Eric hasn’t seen the results
- Peter thinks the cocktail used in the first trial was a little suspect
  - [GH](https://en.wikipedia.org/wiki/Growth_hormone) made sense [0.015 mg/kg rhGH]
  - [Metformin](https://en.wikipedia.org/wiki/Metformin) was given at a homeopathic useless dose (500 mg)
  - Neither Peter nor Eric remember why [DHEA](https://en.wikipedia.org/wiki/Dehydroepiandrosterone) was given
    - [[50 mg DHEA](https://onlinelibrary.wiley.com/doi/full/10.1111/acel.13028#:~:text=was%20combined%20with-,50%C2%A0mg%20DHEA,-to%20evaluate%20insulin) given to evaluate potential for insulin suppression]
- Peter thinks the growth hormone was the single active agent
- It was a very small, open-label trial
- Eric has a significant problem with the readout of that trial ‒ one of the epigenetic clocks
- [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath) was the other author on that paper

*This whole story pushed Eric into a project he’s published on called ‘ancient clock’*

- In their experiment in patients, they observed some increase in the fraction of naive T cells, which tells Eric that something worked
  - The fraction of [naive T cells](https://en.wikipedia.org/wiki/Naive_T_cell) increased with respect to the [memory T cells](https://en.wikipedia.org/wiki/Memory_T_cell)
  - The naive T cells are the ones that are generated in the thymus
  - They’re naive because they have never met their cognate antigen and they sit there waiting for something to happen

***The whole idea of treating with human growth hormone was to induce thymogenesis and to restore the pool of these naive T cells, and to some degree it works at a low level***

- Then they used the clock on whole blood
- Eric’s worry when he saw the paper, is the idea when you sample the blood
  - Which is a worry that predated this
  - It’s also a worry when people were using telomere length,
  - An immunologist, he knows that the blood is a highly dynamic organ (think about the blood is an organ)
  - We enumerate at this point today with the best technology, more than 500 different populations of cells in the blood

***Suppose that these cells in the blood vary in response to any intervention and that these cells individually have a different epigenetic age, you would have the impression that you are rejuvenating (which was the claim of that Fahy paper that they had rejuvenated people), but in effect, what you would do is simply change***

Peter adds, “*It’s like you’re on a* [*sine wave*](https://en.wikipedia.org/wiki/Sine_wave) *that goes like this and you take two sample points. They could be here, they could be here, they could be here.*”

- [Matt Kaeberlein](https://www.linkedin.com/in/mkaeberlein/) purchased 4 of the commercially available aging clocks (in duplicate), and sampled them all simultaneously
  - [discussed in [episode #333](https://peterattiamd.com/longevityroundtable/#:~:text=Matt%20tested%204%20different%20direct%2Dto%2Dconsumer%20biological%20age%20kits%C2%A0) after 35:00]
  - 2 of these simultaneously take 10 samples

***Not only do all the clocks disagree with each other, but even within the same clock there was disagreement, significant disagreement***

- Peter wants to come back and talk about clocks in detail

**Outstanding questions**

- Was there genuine thymic regeneration?
- *If so, how do we reconcile a very pressing and vexing question within GeroScience, which is the role of growth hormone?*

***Could growth hormone be a strategy for mitigating decline in immune function?***

- Peter has never taken growth hormone
- He’s prescribed it in very rare circumstances for injury healing but never for ‘longevity benefits’
- There are a lot of people out there doing that, and Peter has had lots of patients come to his practice who have been taking (or are on) growth hormone
- Every single patient has said, “*I feel so much better when I take growth hormone than when I do not.*”
- Peter can’t point to any evidence that tells them it’s bad to take
- He can just say it’s doesn’t make sense to take:
  - If our goal is to reduce the risk of cancer
  - And our goal is to slow the aging process

**How would you think about weighing the risks and benefits of taking a little bit of growth hormone intermittently?**

*Is there any data you’re aware of that would lead one to think that maybe we could pulse a little bit of growth hormone here and there if we get some thymic regeneration?*

- Eric does worry about it
- He’s not a specialist on growth hormone itself
- It induces diabetes and glucose intolerance
  - So from that angle, he does worry about what it would do chronically, especially in someone young
- It’s a bit like increasing your protein intake
  - There’s clear evidence that increasing your protein intake, especially as you age becomes beneficial and the people who have higher protein intake actually do better in terms of muscle mass and so on
  - So in someone who is 65-70, who is starting to feel the effect of manifest some form of [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia), there might be a benefit for that person to actually increase muscular mass and all the benefits with this, especially if it’s not done continuously
- Peter argues, “*There’s no doubt that there’s benefits, but you’re going to get far more efficacy from testosterone or anabolic steroids when it comes to mitigating sarcopenia.*”
  - Growth hormone actually is not remarkable at inducing muscle mass
  - It’s nowhere near as effective as testosterone
  - It’s more effective at eliciting fat loss
- Peter wonders if there’s something that goes beyond that, because when people tell him they feel better on it
  - He thinks they’re talking about less aches and pains; joints just feel better
  - He wonders if that would be a reason to potentially consider an intermittent schedule of growth hormone
- He doesn’t think anybody’s saying they feel better because their thymus is more plump

**Peter’s macro thesis about this [decline in immune function]**

- He’s been harping on these four horsemen

***If we introduce a fifth horseman, what is the strategy [for combatting it]?***

- Peter can give you chapter and verse the strategy for how you will mitigate heart disease, cancer, all of these other conditions

*What is our strategy for mitigating immune decline?*

- Eric would say the same as a strategy that would mitigate decline in every other organ
- There’s clear evidence that the effect of **exercise** on immunology is the same as in every single…
  - He cannot speak to specific studies

**⇒** There’s evidence that people who exercise actually respond to infection better, respond to vaccination better

*Do you have a sense of mechanistically why that is the case?*

- It is so complex, he would not be able to tell you

***Eric thinks the whole line of investigation to induce thymic rejuvenation is an important one if we are thinking about increasing lifespan because in the future, it will become a rate-limiting step***

**It’s a bit of the same situation as the ovary**

> “*The ovary and the thymus, we call them the canary in the coal mine.*”‒ Eric Verdin

- There are specific organs that show accelerated aging way earlier than other tissues

*The question is why is the thymus involuting so early?*

- Eric thinks it’s probably because evolutionary, we were never meant to live this old
- In the long term, that’s one of the problems that we have to face
- This is something Eric is actively studying and the lab

## The challenges of identifying reliable biomarkers for immune function, and the potential of rapamycin analogs to enhance vaccine response in older adults [57:45]

**Eric just completed a study looking for novel biomarkers that are predictive of whether you will respond to a vaccination or not**

- Done in collaboration with [Mark Davis](https://med.stanford.edu/profiles/mark-davis) at Stanford using the [1000 Immunome Project](https://med.stanford.edu/1000immunomes.html)
  - Which is one of the largest studies studying aging in the immune system only in humans
- Studying people, we’ve been able to identify some metabolites that are associated with poor response to vaccination [unpublished]

***Those are not only markers, but they could also become tools that we include as adjuvant or as a pre-treatment therapy***

- Eric is sure Peter is familiar with the work of [Joan Mannick](https://www.linkedin.com/in/joan-mannick-8089a614/)
  - Peter was going to mention her and [Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/)

**Peter wants to go back to this point: biomarkers are so important**

- When Peter thinks about [cardiovascular disease](https://peterattiamd.com/category/risks/heart-disease-prevention/)
  - Even though it’s the leading cause of death, he tells patients, “*It’s the one you need to be least afraid of if you’re willing to be proactive in management*.”
  - And it comes down to the fact that, we just have such a clear understanding of how the disease works, and we have exceptional biomarkers
  - So we can measure the things that are causing the disease: apoB, VLDL cholesterol, Lp(a), blood pressure, we can measure metabolic health
  - And we know how to address those things, and we can measure whether what we’re doing is working
  - This problem is solved, basically
- When it comes to the immune system, we’re going to talk about Mannick and Klickstein in a moment, but as we saw from their [paper](https://pubmed.ncbi.nlm.nih.gov/25540326/) 10 years ago
  - They gave a rapamycin analog to people  who were in their 60s, vaccinated them, and demonstrated that you got a much better immune response
- They were able to demonstrate that using laboratory techniques
  - Did they use flow cytometry or something like that to measure it?

**How close are we to being able to do that sort of thing commercially? (By commercially, Peter means over the counter)**

- Not close
- That [study](https://pubmed.ncbi.nlm.nih.gov/25540326/) measured [antibody titers](https://en.wikipedia.org/wiki/Titer#Antibody_titer)
- In that case, they definitely showed an enhancing effect with a suspected geroprotector (a rapalog)

***They showed not only increased titers but also increased protection***

- Eventually, the clinical trial failed for a whole series of other reasons, which were in part due to the way that the FDA imposed the trial to be generated
  - It just complicated the whole picture
- Peter had a discussion about that trial with [Matt Kaeberlein](https://www.linkedin.com/in/mkaeberlein/)
  - [[Episode #272](https://peterattiamd.com/davidsabatini-mattkaeberlein/#:~:text=inhibit%20other%20proteins-,Joan%20Mannick%E2%80%99s%20studies%20of%20RTB101%20and%20other%20ATP%2Dcompetitive%20inhibitors%20of%20mTOR,-%5B2%3A00%3A30) after 2:00:30]
  - It wasn’t the [2014 trial (with RAD001)](https://pubmed.ncbi.nlm.nih.gov/25540326/) but a [later trial](https://pubmed.ncbi.nlm.nih.gov/33977284/)

***Peter doesn’t remember the reason the trial failed, it was a tragedy of bureaucracy, and it shouldn’t be viewed as a black eye on that molecule***

- What Eric has heard from anyone he’s talked to about this (including Joan), is that this was in some way bungled
  - Which is sad because things like this can put a field back for a number of years and discourage investors
- Eric had a startup that originated at the Buck () coming up with novel papalogs that are going to be revisiting that whole picture, and it raised $50 million
- The field is far from being dead

**Will we ever be able to measure this in people the way we measure hemoglobin A1c or things like that?**

- Or is it going to be one of those things where it’s a bit of a leap of faith and you’re going to have to look at the clinical trial where the outcome was there, and then you’re just going to have to say, well, even though there was probably massive heterogeneity amongst the participants in the trial, we’re going to dose this thing individually

*Peter compares it to their discussion of vitamin D earlier*

- The vitamin D trials are all garbage because they just give people a given dose
- They don’t measure the response, they don’t measure compliance

***A vitamin D trial should be done based on target level, not target dose***

- Eric agrees
- Eric points out that measuring pathogen-specific [titers](https://en.wikipedia.org/wiki/Titer#Antibody_titer) is done routinely in the clinic
- Eric just had his measles titer measured
  - He was born in 1957, and before 1957, everyone was exposed to measles
  - So typically you’re safe, but you should measure your titer to determine whether you need to be re-vaccinated
- You can have this titer measured very easily

**What do the titers by themselves tell you?**

*If you were to measure your titer to polio, shingles, do a pan titer and then start on rapamycin for 8 weeks, then stop it and re-measure your titers without vaccinating you ‒ what would you expect to see?*

- Eric would not expect them to change; he doesn’t think that has ever been done

Peter asks, “*So how do we know we are improving your immune system if indeed we have?*”

*How could we measure the improvement in immune function?*

- Eric points out that the [Mannick trial](https://pubmed.ncbi.nlm.nih.gov/25540326/) showed that
- First they did a one-month treatment with the rapalog before vaccination
- They demonstrated not an effect on existing vaccinations but it only demonstrated on *de novo* vaccinations

## How rapamycin’s effects on the immune system vary dramatically by dosage and frequency [1:03:30]

**Do you want to say a little bit more about the Mannick trial?**

*For Peter, this was a pivotal moment in his journey in this space*

- This [paper](https://pubmed.ncbi.nlm.nih.gov/25540326/) came out in December 2014
- There were roughly 300+ participants (all over age 65) divided into 4 groups
  - Placebo daily
  - 0.5 mg rapalog (RAD001) daily [Peter misspoke saying 1 mg every day]
  - 5 mg rapalog weekly (pulsed administration, once a week)
  - 20 mg rapalog weekly  (pulsed administration, once a week)
- The groups receiving 5 mg and the 20 mg weekly were nearly identical, but the group receiving 20 mg had much more side effects

***The take-away was that the group receiving a pulse of 5 mg was the sweet spot ‒ you get all the benefits without the side effects***

- This is how Eric remembers the study too
- What was remarkable about that data was the fact that this is from a drug that is supposed to be an immune suppressant

Eric explains, “*It’s been a long road for the longevity field to try to get our colleagues, who are actually using rapamycin as immunosuppressant to have them believe that this actually has an effect on immunity. And not only [is it] not immunosuppressive, but actually are promoting immunity*.”

*How do you reconcile that one molecule?*

- Rapamycin is not used that much today in transplant clinics
- Peter is blanking on the real name for FK506, but it has largely displaced sirolimus (which is also known as rapamycin)
- That said, when we used to give it out, we were giving 2-4 mg a day
- Now, let’s just assume that it was indeed contributing to **prevention of organ rejection**

**Do you think it was doing so because that’s a high enough dose of constitutively giving a drug that is suppressing the immune system, or do you think it was only suppressing the immune system because it was being given in combination with two other drugs and it was only as part of that sea of other drugs that it has the immunosuppressive effects?**

- Eric thinks there is clear evidence that it is immunosuppressive by itself
- For the period he was on rapamycin, he would take either 4, 6 mg a week (every morning, once a week)

***The biggest difference between the immunosuppressive and the geroprotective effect is really the frequency and the amount***

- The reason why people adopted this **once weekly dose**
  - 1 – To not have any immunosuppression
  - 2 – To mitigate the secondary effects, which are thought to be caused by inhibition of [mTORC2](https://en.wikipedia.org/wiki/MTORC2) (which is the second complex)
    - The glucose effect
- And it [once weekly dosing] seems to be working largely
- In Eric’s experience, what was remarkable is that every time he took a dose (of 4 or 6 mg), the next morning, he would have a pimple on his nose

***He was clearly immunosuppressed every single time [he took rapamycin] for a day or two***

- If he had a really heavy workout, he would have exactly the same thing ‒ exercise is immunosuppressive
  - You are temporarily fragilized after really heavy exercise
- Eric thinks the difference between those two worlds that it is immunosuppressive by itself, versus the beneficial effect on the immune system
  - It is a question of dosage and frequency

**Yet Peter cannot reconcile the unambiguous success of the interventions testing program where those mice were eating rapamycin in every single bite of food they took**

- In fact, they were consuming it more continuously than even the most immune-compromised patient
- And without exception, every single [ITP study of rapamycin](https://pubmed.ncbi.nlm.nih.gov/24341993/), it always worked
  - Whether they started in old mice or young mice, rapa alone, rapa with another drug, it just doesn’t matter

*How do we reconcile that?*

- Eric doesn’t have the answer but can talk about it

## The limitations of mouse models in aging research and the need for cautious interpretation of rapamycin’s benefits in humans [1:08:15]

**There’s something that worries Eric about our reliance on the mouse as a model system for studying aging**

- How relevant it is to us as a species
- We all admit that the ITP mice are the best: they are the Ferrari of mice
  - They are using mice that are crossed and not inbred
- When you’re using a [Black 6 mouse](https://www.jax.org/strain//000664), you are essentially doing the experiment on a ‘n of one’
  - 80% of the work that’s being done in mice is done in Black 6
  - We’re all studying the same person
- Obviously, when you go and try to transfer this to a human population with all of its variation
- So the ITP did the right thing, and this is not an attack on ITP
  - Eric thinks the ITP is a great program and should be funded and should continue to study this

***Eric just worries about the over-reliance on ITP alone, and he thinks we should have another system that studies primate interventions with drugs***

- There are a number of nonhuman primates that are actually much closer to us than a mouse
- The reason he worries about mice is something that [Steve Austad](https://www.uab.edu/icar/about/icar-leadership/steven-austad) said
  - Steve Austad was on the podcast [in episodes [#171](https://peterattiamd.com/steveaustad/) and [#333](https://peterattiamd.com/longevityroundtable/)]
  - Eric and Steve are good friends
- Steve came up with something called the ‘[longevity quotient](https://en.wikipedia.org/wiki/Longevity_quotient),’ which is something people do not pay attention to enough

***The longevity quotient is this idea that, if you look across the animal kingdom, the larger you are, the longer you live***

- You can take 1,000 species, and on the X axis, you have their size, on the Y axis their life expectancy [an example is shown in the figure below]
  - It largely rises to the right
  - And you can see a monotonous curve

![](https://peterattiamd.com/wp-content/uploads/2025/07/f3-ericverdin.jpg)

**Figure 3. Relationship observed between life expectancy and body size**. Image credit: [*Proceedings, Biological Sciences* 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4043093/)

- There are exceptions to this, and one exception is the [naked mole-rat](https://en.wikipedia.org/wiki/Naked_mole-rat) [labeled ‘B’ in the figure above]
  - They punch above their weight
  - Dogs tend to punch below their weight
- This correlation with size seems to hold between species, but when you look intraspecies, it gets even more complicated
  - Larger dogs live shorter lives than smaller dogs ‒ that’s driven mostly by growth hormone

**This is another reason why we should look at taking growth hormone as an anti-aging drug with some degree of circumspection**

- Because in dogs, the more growth hormone you have, the larger you are ‒ the shorter you live
- We also know in humans, the larger you are, the taller you are ‒ the shorter you live
- Are these the effects of growth hormone? Yes
- Are they only important during the growth phase?
- That’s a possibility, but it’s something that really gives Eric pause

**Back to the longevity quotient**

- Mice are also an exception
  - They punch below their weight
  - They live shorter than they should based on their size
- Humans are the biggest exception: we live 5-6x longer than we should based on our size
  - Which tells Eric that we are the naked mole-rats of primates

> “*We do incredibly well, which means that we already have optimized a lot of these pathways that are promoting aging.*”‒ Eric Verdin

- Mice are the exact opposite

**Eric doesn’t know if someone has really compared intrinsic** [**TOR**](https://en.wikipedia.org/wiki/MTOR) **activity in mice**

- Mice (especially lab mice) are engineered to reproduce and grow as quickly as possible
  - They have large litter size
  - They do everything quickly
- We know all of these activities require a lot of anabolic strength, which is driven by TOR

***The question is, are the mice examples of animals that are maximizing TOR activity to do everything they do very quickly, and are we maybe at the other end of the spectrum where we have low basal TOR activity?***

- This is where Eric worries when people just transfer everything we know from TOR, from mice into humans
  - Saying it’s going to show and work in humans

**Eric’s experience taking rapamycin & why he stopped**

- He didn’t see anything metabolically, physically, muscle strength
- In contrast to a [GLP-1 agonist](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist), where he saw all of his numbers get better (including functional strength)
- With rapamycin, he never could tell whether he was taking it or not
- Peter would say,  “*Where rapamycin acts, I don’t know that we would see anything getting significantly better.*”

***Rapamycin is going to act on*** [***autophagy***](https://en.wikipedia.org/wiki/Autophagy)***, and there’s no way you’re going to measure (or feel) autophagy***

- Does it tamp down on certain subsets of senescent cells?
  - That’s certainly plausible
  - Peter doesn’t know how we’re going to see or measure or necessarily even feel that
- Does it reduce some of the tonic, low-grade, unhelpful inflammation? Probably
  - But, again, if a person doesn’t have much to begin with, it’s going to be tough to measure

**Eric’s experience taking a GLP-1 agonist**

- Conversely, a GLP-1 agonists act directly on a thing that is so easy to measure, which is glucose metabolism, and body weight (for those who are losing weight)
- It might not be a fair comparison

**Thoughts about the environment laboratory mice live in**

- The other thing Peter would add to this interesting observation is that the ***mice in the ITP are still in a relatively sterile environment***, and it might be that, even if they incur some immunosuppression, it’s not going to be as maladaptive as it would be if they were wild animals (as we are)
- Eric agrees and adds: they live grouped in a cage with no ability to move, to exercise
- They eat a diet which makes the American diet look like the most healthy thing ever
  - Have you ever seen the pellets that these mice are eating?
  - They don’t know exactly what their diet is
  - Eric can guarantee you they’re not eating salad and fruits and vegetable

***In some way, the ITP mice are in an incredibly artificially bad environment; they are actually doing everything that is conducive to poor health. And so the fact that we see something that works in that system might have some value for the fraction of the population that has a very poor lifestyle***

**Eric worries about transferring this to someone like himself and Peter who are exercising or trying to eat well or trying to sleep and all of this**

- He takes these observations with some degree of caution, and frankly, when people ask him, “*Should I go and rapamycin?*” He worries
- Now, this is a different story if a patient comes and sees Peter at 40 years old and tells him, “*I think I want to go on rapamycin*”

**⇒** Eric would strongly argue that you should *not* do this, because even in the studies that have been conducted, they still saw an effect in mice that were the equivalent of 65 to 70 years old

- Now, if you’re 75 years old and you have the feeling you’re chronically inflamed and you have the feeling that things are not doing well, there are a number of anecdotal cases where people have described really feeling a lot better [on rapamycin] and a lot stronger very quickly

***But Eric would predict it would be the same thing with a growth hormone or some of these interventions***

Eric explains, “*My argument to people is today we have one intervention that is very profoundly anti-aging, and it is physical activity,* ***exercise, in all of its forms****. Once you have optimized this, I think let’s talk about doing something else on top of that.*”

## NAD, sirtuins, and aging: scientific promise amid commercial hype [1:15:45]

- Peter was at a talk recently and he was asked about [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide); he shared 3 facts
- 1 – NAD is completely ubiquitous throughout the body, and it is absolutely essential for the most important chemical reactions that happen in the body
  - You cannot undergo [redox reactions](https://en.wikipedia.org/wiki/Redox) (metabolic reactions) without NAD
- 2 – A class of proteins called [sirtuins](https://en.wikipedia.org/wiki/Sirtuin) rely heavily on NAD as the substrate in the process of repairing DNA
- 3 – As you age, NAD levels decline precipitously

**Is there any dispute to any of those facts?**

- No, no controversy

**How could it be that supplementing NAD does not lead to a longer, better life or some health benefit? (That’s a logical conclusion, right?)**

- Well, not completely
- Because it depends: what is the reason why NAD levels decrease
- It depends also on how you remedy the decrease (what supplements)
- Something Eric would love to talk about is [CD38](https://en.wikipedia.org/wiki/CD38)

Peter proposes, “*It could be that NAD levels go down because their consumption goes up*.’

- As we age, there’s more DNA damage, there’s more consumption [of NAD], the sirtuins need more of it

*Then the question would become is the current level of NAD that we have rate limiting to that reaction?*

- If not, then all the extra NAD in the world should have no benefit because you’re just adding more substrate to a reaction where it’s not needed
- Conversely, if NAD levels are going down because there’s a production issue, and if you provided more of it, you could actually do more good, well then, it could be the exact opposite story

**Explain a little bit what NAD is, explain what it means in redox, and obviously, let’s talk about sirtuins and the role that NAD plays there**

- There’s a lot to unpack (it could be a 2-hour podcast)
- This is the one area Eric has worked on for the last 25 years
  - He was responsible for [cloning](https://pmc.ncbi.nlm.nih.gov/articles/PMC2174009/) the human sirtuins (when he was a graduate student); after [Lenny Guarente](https://biology.mit.edu/profile/leonard-p-guarente/) published his [paper](https://pubmed.ncbi.nlm.nih.gov/10809662/) on SIR2 and yeast
- [Matt Kaeberlein](https://www.linkedin.com/in/mkaeberlein/), [David [Sinclair]](https://sinclair.hms.harvard.edu/people/david-sinclair) along with Lenny Guarente paved the way for a lot of what we know

Eric starts by saying, “*It pains me, in some way, in a field that is so rich and has generated so much data that there’s a whole cloud lying on top of sirtuins and NAD. There’s nothing there. I just tell people it is an incredibly studied system, we are still juggling the complexity, and I would argue that any field where the same degree of investigation will be conducted will have the same controversy. This is the nature of science.*”

> “*The beauty of science is that it’s incredibly messy on the way up, but eventually things are getting clarified.”*‒ Eric Verdin

***In terms of the sirtuins, we’re still right in the middle of it (so there’s some complete garbage)***

- Peter is not dismissive

**What has made this field complicated is that the leading proponents of it have all opted for a commercial pathway**

- And therefore they have opted *not* to study this in a rigorous way, but to study it in a commercial way
- Peter understands why you would do that, that’s the nature of it
- With this molecule, you’re not going to generate intellectual property in the same way that you would around a novel drug, and so it poses a limitation to how these things can be studied
- Unfortunately, that coupled with the [resveratrol](https://en.wikipedia.org/wiki/Resveratrol) fiasco
  - Peter is completely convinced that resveratrol had zero benefit whatsoever (it’s a useless molecule)

***The over-hype, complete debacle of resveratrol, coupled with the fact that all of the participants in the NAD landscape are doing it through their own commercial enterprise with their own proprietary blend, has resulted in this inability to drive forward in this field***

- Eric agrees
- Peter has identified the problems, the hype and the commercialization
- Commercialization can be helpful if the companies are actually willing to invest in clinical trials
- Eric uses the example of [Timeline](https://www.timeline.com/), [Urolithin A](https://en.wikipedia.org/wiki/Urolithin_A)
  - He’s worked with them
  - They do clinical trials, rigorous, they publish them in the best journals, and at the end, you know what you’re measuring
- That being said, for the sirtuin, so let’s try to step back

***Given the controversy [around sirtuins], Eric would encourage listeners not to just discard it all: we’re still in the middle of it, and he thinks something interesting will emerge out of it***

**NAD is a critical intermediary metabolite**

- It has 2 big roles
- 1 – It plays a key role in redox reactions
  - Reduction-oxidation reactions ‒ anytime electrons need to move around
  - It exists in 2 forms: NAD and NADH and it is critical to intermediary metabolism

**⇒** There are more than 600 of these enzymes that use NAD in the whole metabolism.

- It stands the reason that, if you losing NAD levels and you go below a certain critical level, these enzymes are going to suffer
- **⇒** We know that decreasing metabolic efficiency at all levels is one of the hallmarks of aging
- 2 – In addition to these enzymes that utilize the NAD/NADH couple, there’s a whole series of other enzymes that actually are digesting, cleaving NAD
  - These would be the [PARPs, which is poly (ADP-ribose) polymerase](https://en.wikipedia.org/wiki/Poly_(ADP-ribose)_polymerase)
  - These are enzymes mostly involved in **DNA repair** ‒ [sirtuins](https://en.wikipedia.org/wiki/Sirtuin#DNA_repair_in_laboratory_studies) play a critical role
- The 7 sirtuins are all doing different things within the cell
  - And we can go back and dig into this a little bit in terms of what are the sirtuins doing?
- There’s also another 2 enzymes called [CD38](https://en.wikipedia.org/wiki/CD38) and [CD157](https://en.wikipedia.org/wiki/BST1)
  - These are also [NAD hydrolases,](https://en.wikipedia.org/wiki/NAD%2B_glycohydrolase) and Eric’s lab is studying them a lot

Eric adds, “*One thing that your listeners should know about NAD levels and why the decrease in NAD levels are relevant to aging with respect to the sirtuins, is because sirtuins have a relatively narrow range of* [*K**D*](https://en.wikipedia.org/wiki/Dissociation_constant) *for NAD.*”

***If the NAD levels change, as we know they do during aging, it will lead to a change in the activity of the sirtuins***

- This is something that was proposed by [Lenny Guarent](https://biology.mit.edu/profile/leonard-p-guarente/)e back in the days
- It was shown, for example, even during fasting, your NAD levels will increase and this will activate sirtuins

**This is something that is really unique to the sirtuin: sirtuins present in different parts of the cell are very different**

- We know this in a really acute way because there are sirtuins that are present in the cytoplasm versus in the mitochondria versus in the nucleus, and the NAD levels in each of these organs [cellular compartments] are very different
- For example, in mitochondria, it turns out that SIRT3 has a [KD](https://en.wikipedia.org/wiki/Dissociation_constant) for NAD which is much higher than SIRT1

***And that really is the indication that sirtuins are sensors of NAD levels***

- Which goes back to the initial model that Peter mentioned
  - NAD levels change during aging, therefore, we can expect the activity of the sirtuins to change

## How CD38 drives age-related NAD decline, influences immune function, and may impact longevity [1:23:45]

- If we believe, with some conviction, that restoring NAD levels in an aging individual is beneficial, we now have to deal with the same problem you deal with any small molecule, or large molecule for that matter:

**What are the ways in which you could get NAD into the body directly or indirectly?**

- This brings Eric to another element of the biochemistry

**One thing that has emerged is this idea that the question as to why do NAD levels decrease?**

- And there’s been lots of theories, activation of the [PARPs](https://en.wikipedia.org/wiki/Poly_(ADP-ribose)_polymerase)
- That seems to be happening in *C. elegans,* in mammals ‒ this is the work of [Eduardo Chini](https://www.mayo.edu/research/faculty/chini-eduardo-n-m-d-ph-d/bio-00085601) who was the first one to [show](https://pubmed.ncbi.nlm.nih.gov/27304511/) that [CD38](https://en.wikipedia.org/wiki/CD38) appears to be the major driver of the decrease of NAD during aging
  - Eric has repeated some of his results
  - The way that he’s demonstrated this is by [studying](https://pubmed.ncbi.nlm.nih.gov/27304511/) a mouse that’s knocked out for CD38 ‒ you find that NAD levels actually do not decrease during aging

***This really brings the whole question in terms of: What should we be targeting?***

**What is CD38 doing specifically?**

- CD38 is a membrane-anchored protein
  - Some of it is facing outward, on the outside of the cells
  - Some of it, it’s facing inward
  - For example, in T-cells, it’s mostly facing outward
  - In macrophage, it’s mostly facing inward

[***CD38***](https://en.wikipedia.org/wiki/CD38) ***is an NAD*** [***hydrolase***](https://en.wikipedia.org/wiki/Hydrolase)

[the figure below shows the increase in CD38 activity and decrease of NAD levels occur with aging]

![](https://peterattiamd.com/wp-content/uploads/2025/07/f4-ericverdin.jpg)

**Figure 4. Changes in NAD and CD38 observed with aging**. Image credit: [*Cell Metabolism* 2016](https://pmc.ncbi.nlm.nih.gov/articles/PMC4911708/)

- It’s on non-immune cells as well, on endothelial cells

*It’s not entirely clear what is it doing in the immune system, why do we have it?*

- One idea is that because it is present in T-cells is that it might come up and eat up all the NAD that’s local in the extracellular fluid (although there’s not much of it), as part of the innate immune response and limits the ability of bacteria and other organisms to access these micronutrients for their own growth
- That’s one thinking, but Eric thinks it’s a lot more complicated than this, and we’re really in the middle of it
- A good part of his lab is studying the role of CD38 in the immune system, in endothelial cells, and in the brain as well

**You mentioned a moment ago that the CD38 knockouts do not see a decline in NAD with aging**

- Zero [shown in the figure below], and they live longer

![](https://peterattiamd.com/wp-content/uploads/2025/07/f5-ericverdin.png)

**Figure 5. NAD levels in wildtype (WT) mice and CD38-deficient (CD38 KO) mice**. Image credit: [*Cell Metabolism* 2016](https://pmc.ncbi.nlm.nih.gov/articles/PMC4911708/)

*What is the phenotype of a CD38 knockout? What deficiency do they have?*

- Nothing that we can tell, and they live 15% longer [[study](https://pubmed.ncbi.nlm.nih.gov/35263032/) of CD38 inhibitor]
  - That’s comparable to rapamycin

Peter asks, “*Do you think that is true and unrelated to the increased pool of NAD?*”

- That’s a key question and one that’s not been answered
- If Eric had to go out on a limb, he would say it’s not linked to the NAD decrease

**Peter’s takeaway**

- Eric’s belief is that the CD38 knockout mouse does not live longer because he has more NAD
  - That’s just another issue we’re seeing
  - There’s something else about that mouse
- Or it might be partially the NAD and partially another mechanism (that Eric is about to discuss)

**One thing that’s remarkable is that, as we age, us and mice, we see an increase in CD38 level across the organism, especially in the immune system**

- Eric published a [paper](https://pubmed.ncbi.nlm.nih.gov/33199924/) showing that the [SASP](https://en.wikipedia.org/wiki/Senescence-associated_secretory_phenotype) from senescent cells is a very powerful inducer of CD38 expression in macrophages

***That’s one mechanism by which we are linking senescence and the SASP to increase CD38 leading to a depletion of NAD and other effects***

Peter responds, “*And yet we have no idea what it’s doing other than hydrolyzing NAD.*”

- It has a cognate receptor on other cells
- They don’t seem to be immune deficient
- It’s really one of these players that people … there are hundreds of papers

*One idea about CD38 is that it plays a suppressive role in the immune response*

- Because we see it being induced late-ish in the immune response and the idea is it comes up to dampen down…
  - It’s pro-anti-inflammatory, and it can be harmful in that way, as opposed to contributing to sterile inflammation (which is the more typical problem we’re seeing in aging)
- The other side of the immune system is that it has to be incredibly balanced between reacting appropriately towards exogenous pathogens, but not reacting against the self
- As you know as a physician, there are so many conditions that are a manifestation of an excess of immune response against the individual, all of the autoimmune diseases, which increase during aging
  - Except for type 1 diabetes which occurs in the young

**Peter knows that Eric used to study type 1 diabetes ‒ why do you think that occurs in young people?**

- It’s really an interesting question
- There’s something called [LADA](https://www.ncbi.nlm.nih.gov/books/NBK557897/) that is emerging that we might have been diagnosing some [people with] type 2 that were actually late type 1 [diabetes]
- The thing that is really unique about type 1 ‒ a number of papers highlight the fact that there might be something happening during development that exposes the immune system to the developing [ꞵ-cells](https://en.wikipedia.org/wiki/Beta_cell), and that might trigger more to immunity at that time
- It could also be linked to the fact that there’s been, for many years, a discussion of the role of viruses, infection, and molecular mimicry between some of these viruses and ꞵ-cells
  - It could be that a subset of infections that happen during childhood actually puts you at risk of activating your immune system inappropriately
- That’s the whole idea, but there’s clearly an increase with autoimmunity throughout life

**Do we see the same effects with** [**CD157**](https://en.wikipedia.org/wiki/BST1)**? Do we have a CD157 knockout mouse?**

- No, it’s much less studied
- There are some interesting effects, but CD38 has garnered most of the attention

**Back to what CD38 is doing**

- CD38 is taking [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) and cleaving it into [ADP-ribose](https://en.wikipedia.org/wiki/Adenosine_diphosphate_ribose) (which is a [sugar](https://en.wikipedia.org/wiki/Ribose), and [nucleotide](https://en.wikipedia.org/wiki/Adenine)) and [nicotinamide](https://en.wikipedia.org/wiki/Nicotinamide) [the figure below shows NAD cleaved by CD38 to ADPR + nicotinamide]

![](https://peterattiamd.com/wp-content/uploads/2025/07/f6-ericverdin.png)

**Figure 6. CD38 is a NAD+ glycohydrolase**. Image credit: [*Frontiers in Immunology* 2019](https://pubmed.ncbi.nlm.nih.gov/31214171/)

- [Nicotinamide](https://en.wikipedia.org/wiki/Nicotinamide) is a precursor to NAD
- And so this nicotinamide (which is generated by CD38, by the sirtuins, by the [PARPs](https://en.wikipedia.org/wiki/Poly_(ADP-ribose)_polymerase)) normally gets recycled in a two-step reaction all the way back to NAD
  - This is called the [salvage pathway for nicotinamide](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide#Salvage_pathways)
    - [precursors used for the salvage pathway to produce NAD are shown below]

![](https://peterattiamd.com/wp-content/uploads/2025/07/f7-ericverdin.png)

**Figure 7. The salvage pathways use 3 precursors to produce NAD+**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide#Salvage_pathways)

**⇒** What’s really interesting is, if you block this [the salvage pathways]: within a few hours, your NAD levels go down to zero

***NAD levels are heavily dependent on recycling***

*There’s a specific inhibitor of this enzyme [in the salvage pathway] called* [*NAMPT*](https://en.wikipedia.org/wiki/Nicotinamide_phosphoribosyltransferase)

- You can add it to cells (Eric has done the experiment): within 4-6 hours, NAD levels are down to zero and the cell dies
- There’s an incredible churning through that whole pathway, which is a reflection of the activity of sirtuins, CD38, CD157, the PARPs, and so on

***You have a situation during aging where CD38 increases, you increase the degradation, so you decrease the pool of NAD***

- But you are increasing the metabolite nicotinamide (in theory)

## How NMN and NR supplementation interact with CD38 and NAD metabolism, and potential risks like homocysteine elevation and one-carbon cycle depletion [1:31:00]

Eric explains, “O*ne important thing is nicotinamide metabolism is either salvage (back to NAD) or methylation by an enzyme. And this is important for supplementation, because it turns out CD38 not only cleaves NAD, but it also cleaves NMN (which is one of the two precursors: NMN and NR).*”

**⇒** When you actually have increased CD38 activity and you take NMN, you churn through this pathway, and actually, you increase your nicotinamide and you increase its methylation

- NMN is also cleaved by CD38 into nicotinamide plus something that’s not ADP-ribose
- You’re increasing your level of nicotinamide to the point that it’s shunting to [methyl-nicotinamide](https://en.wikipedia.org/wiki/1-Methylnicotinamide) and it starts depleting your [one-carbon cycle](https://en.wikipedia.org/wiki/1-Methylnicotinamide#Biosynthesis)

**⇒** What you see in a number of people on NMN is their [homocysteine level](https://en.wikipedia.org/wiki/Homocysteine#Homocysteine_levels) going up (including Eric)

- Eric stopped taking NMN when he saw this
  - He was taking about a gram of NMN for a while
- He thinks the increase in homocysteine is a reflection of this pathway

**Why is it that the increased pool of nicotinamide preferentially goes down a methylation pathway as opposed to the salvage pathway to give you more NAD?**

- Eric doesn’t think it goes preferentially; it just depends on how much you put in
  - The more you put in, even if it splits stochastically, you’re going to take away one-carbon
  - Eric doesn’t know what the relative proportion is, but clearly, the more you drive the system with NMN, the more you’re going to yield [the methylated form]

**How much did your homocysteine go up?**

- From 7 to 15
- Eric measures his homocysteine every 3 months
- After 3-6 months, it had gone back to his normal level of 7-8

**How is NR (nicotinamide riboside) treated by CD38?**

- It’s not metabolized by itself
- Eventually in the cell, NR has to make it back to NMN
  - Which is on the [salvage pathway](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide#Salvage_pathways) he just discussed
- NR is less bulky, less big, than NMN, so it is able to get into the cell, but eventually it makes it into nicotinamide (NMN), and then goes back into the same pathway
  - So eventually, they all come back to the same

**Do you think that there’s no difference between the same amount of NR and NMN?**

- There are clearly some differences
- Especially in all the really complex biochemistry that happens in terms of getting them into cells
- The problem with NR and NMN is that if you think about what the approach is

**Analogy to understand the pool of NAD**

- Think about the pool of NAD as a sink full of water ‒ it’s leaking
- CD38 is the leak at the bottom of the sink
- And you keep pouring more NMN, more NR inside of it

***You’re just going to accelerate the leak; you’re not going to solve the problem basically***

- Maybe you’ll reestablish the level to something semi-normal, but the churning through is problematic

**Why is the churning through problematic?**

- [Cleavage of NAD by CD38]
- Because of some of the byproducts of CD38
- For example, there are 2 forms of ADP-ribose: [cyclic ADP-ribose](https://en.wikipedia.org/wiki/Cyclic_ADP-ribose) and [not cyclic ADP-ribose](https://en.wikipedia.org/wiki/Adenosine_diphosphate_ribose)
  - The [cyclic form activates calcium signaling](https://en.wikipedia.org/wiki/Cyclic_ADP-ribose#Function), and so there’s a whole aspect of the biology of CD38 that’s linked to calcium signaling
- Eric worries about the supplementation with the NR and NMN
- Clinical trials are ongoing, so we will soon identify something in which it has a benefit

**If you think about the metabolism of these metabolites, it’s incredibly complicated**

- There are effects on the microbiome
- There are effects on different absorption by different cells
- There are hundreds and hundreds of papers in the literature, way beyond what your audience probably wants to hear

**Eric’s key point:** most of what you can buy as supplement have doses that are so low

- This is where there’s an important discordance also

**⇒** When we do an experiment, we’ve seen amazing things in laboratory animals in terms of supplementing with NR and NMN (this is where the excitement comes from), and typically, these animals are getting 10x more than what you’re buying as a supplement

- The reason Eric thinks GRAS status is given to these companies to give a small amount
  - [GRAS](https://en.wikipedia.org/wiki/Generally_recognized_as_safe) meaning ‘generally recognized as safe’ is the FDA’s criteria for something that is naturally occurring and they don’t require it to go down the [IND](https://en.wikipedia.org/wiki/Investigational_New_Drug) pharmacologic pathway

**Follow-up on the increase in homocysteine Eric observed when taking 1 g a day of NMN (his homocysteine went from 7 to 15)**

*Has that been reported elsewhere? And, in the trials that are testing NMN, are they measuring homocysteine?*

- Eric must have read it somewhere because he was looking for it

*How would you tolerate 10 g of NMN?*

*If 1 g increases homocysteine, does that mean you would deplete all one-carbon metabolism?*

*Does that mean you wouldn’t even be able to alter your epigenome in ways that might be favorable?*

- You run all kinds of risk, and a number of people that have seen the same thing and start taking [trimethylglycine](https://en.wikipedia.org/wiki/Trimethylglycine) to try to supplement this
- Eric worries about this

> “*I want to reiterate the fact that I think the data in animal models of some of the things that we’ve seen with some of these precursors [like NMN] is really interesting, and this is why there’s so much interest*.”‒ Eric Verdin

**Did you ever try using** [**TMG**](https://en.wikipedia.org/wiki/Trimethylglycine#) **to see if it would offset the increase in homocysteine?**

- No, he didn’t
- Peter thinks that would be an interesting self-experiment

## Intravenous NAD: limited evidence and serious risks [1:37:00]

**What about intravenous NAD?**

Eric replies, “*That is one of my pet peeves. I try, in everything, to remain open-minded to things that I don’t know and don’t understand.*”

*Eric’s predictions*

- 1 – NAD is not an extracellular molecule
- It almost doesn’t exist at all in neoplasma
- NAD is an intracellular molecule
  - It is found in high concentrations in the mitochondria and much lower concentrations in the cytoplasm and nucleus
- 2 – NAD is too big to be absorbed by cells
- What’s the body going to do with it?
- There is a famous [paper](https://pubmed.ncbi.nlm.nih.gov/29685734/) by [Josh Rabinowitz](https://chemistry.princeton.edu/faculty-research/faculty/joshua-rabinowitz/) that showed if you inject NAD intravenously, most of it is catabolized by the liver into [nicotinamide [NAM](https://en.wikipedia.org/wiki/Nicotinamide#Biological_role), see [figure 7](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(18)30196-7)]
  - [Josh was the guest in [episode #216](https://peterattiamd.com/joshrabinowitz/)]

Eric explains, “*Nicotinamide is one of the fraction of* [*niacin*](https://en.wikipedia.org/wiki/Nicotinic_acid)*. You can buy this at the pharmacy for very cheap. You can go into an IV clinic and get a $700 injection of NAD.*”

- There are very few studies on IV injection of NAD

***Eric’s opinion is that intravenous administration of NAD is not something that should be done (the same is true for subcutaneous administration)***

- Eric has tried to remain open-minded, obviously we don’t know everything
- He has heard anecdotal evidence of dramatic effects in some patients with Parkinson’s: increase in motor performance right after the infusion
  - A couple friends told him this
- This has not been studied systematically

**Mechanistically, is there a reason you could explain that?**

- There’s a whole literature on the effect of NAD precursors on Parkinson’s
  - Mostly animal models
  - There are lots of clinical trials going on in Parkinson’s, but more using the standard NR and NMN
- The proliferation of these intravenous clinics, frankly, is…

**How complicated is it to produce a bag of intravenous NAD?**

- Eric doesn’t think it’s very complicated
- Making pure NMN took some effort to scale it up
- There is a major supplier out of China that pretty much everybody uses
- In terms of NAD, he doesn’t think it’s an industrial process
- It’s not $700

**If a person was going to supplement with one orally, do you think there is a case for NR being superior to NMN?**

- No
- Eric would say, take them both (if you want to add a bit of insurance)

***Eric did this for a while ‒ he took 250 mg of both NR and NMN (he’s not doing it right now)***

- This is a relatively safe dose
- Follow your [homocysteine](https://en.wikipedia.org/wiki/Homocysteine)

***You could make the case for this supplement if you are 60 or above***

- Although, this is the same thing that we see with so many of these supplements right now:
  - Which one do you take?
  - Which ones are beneficial?

**There’s one, a little bit of a dark cloud linked to NAD supplementation: the demonstration that the** [**SASP**](https://en.wikipedia.org/wiki/Senescence-associated_secretory_phenotype) **is actually dependent on NAD levels**

- So when you are actually increasing NAD levels, you might be increasing these **pro- inflammatory markers**

**Peter’s takeaway**:

- SASPs are the soluble products made by the senescent cells, that effectively are doing all the bad things that we don’t want to see senescent cells doing
- They are dependent on CD38, to some extent
- So as CD38 goes up, they go up

Peter asks, “*Are you saying as you give more NR and more NMN, you might be churning up the SASPs?*”

- Yeah

**Eric finishes his point about concerns with supplementing with precursors of NAD**

- There’s also some worry about the fact that supplementing with some of these precursors might also **accelerate tumor growth**
- This would not have an effect in someone who doesn’t have a cancer, but if it’s someone out there who has an early form of a cancer, this could lead to an acceleration
- This is something that’s been shown in animal models, and that’s giving some pause to some people in terms of recommending this to be taken by everyone
- Peter points out that folks who recommend taking this have strenuously denied that there is any validity to those animal models that have suggested that
- Some of this has been done *in vitro* as well, correct?
- Peter is not very familiar with that literature
  - He remembers seeing one study, it was very small
  - His take on it was if you had cancer, this might be a bad idea to take
  - But he didn’t find it that convincing
- Eric agrees

> “*We have a term in French, which is sort of like therapeutic, overdoing it, doing too much.*”‒ Eric Verdin

- There is such a thing as overdoing it

**In this case, the whole longevity field is embracing a whole series of these interventions**

- There’s not a week that doesn’t go by that Eric doesn’t see a new supplement being touted online
  - And he reads about all of them
- The question is, which ones should you be taking?
- Which ones are actually risky, which ones are not?
- Eric’s perspective: this is part of the whole balance of the equilibrium that he’s trying to reach

***If there’s something that really has a beneficial effect, you want to be on it as soon as possible. If not, why take the chance?***

## Interleukin-11 (IL-11) as a new target in immune aging, the dual role of chronic inflammation in aging, and the need for better biomarkers to guide interventions [1:43:00]

- There was a [big trial](https://pubmed.ncbi.nlm.nih.gov/39020175/) last fall looking at blocking interleukin 11 [IL-11] in mice, and those mice lived longer
- [IL-11](https://en.wikipedia.org/wiki/Interleukin_11) is a molecule that’s made by immune cells, and it plays an important role in inflammation. And this was done in mice, and those mice lived longer

**What do you make of that** [**study**](https://pubmed.ncbi.nlm.nih.gov/39020175/)**?**

- Eric read the paper, but he doesn’t have any inside knowledge about it
- When the paper came out, he was like “*Interleukin 11?*”
  - As an immunologist, he talks about IL-1, IL2, IL-4, IL6, IL-7
  - But never IL-11
  - Interleukins go up to 30

**⇒** IL-11 is an inflammatory marker but not on par with IL-1 or IL-6

***This paper came out of left field, but it sort of makes sense in the context of what we know about the inflammatory response linked to aging***

Eric adds the point, “*When we think about the chronic inflammation of aging, sort of inflam-aging, it is both cause and effect.*”

- We talked about how the immune response helps you to protect yourself against
- The [innate immune response](https://en.wikipedia.org/wiki/Innate_immune_system) is the first line of defense against pathogens

**⇒** The innate immune response also has another important role, is that it recognizes damage ‒ any kind of damage (if you cut yourself, if you have a wound inside of your organ, have unfolded proteins, all kinds of things)

- Any kind of damage will trigger the innate immune response (it will become activated)

***So as we age, and as damage slowly accumulates (because aging is a slow, irreversible accumulation of damage), eventually your immune system responds to this by becoming chronically activated***

- You might think, “*Well, this is great, because you are actually repairing all of this damage*.”

*The problem is, the activation of the immune response by itself becomes problematic*

- These cells, macrophages for example are a powerful tissue remodeler
- The immune system in this case is ‘Dr. Jekyll and Mr. Hyde’
  - It’s helping, but it’s facing an insurmountable amount of damage, and ***eventually its activation leads to an NAD depletion***
  - That’s one of the things that it does
  - But many other things, stem cell dysfunction, and mitochondrial dysfunction

*Back to this* [*paper*](https://pubmed.ncbi.nlm.nih.gov/39020175/)

- The whole idea here is that IL-11 might simply be, is one of the key markers of this chronically activated immune system
- This is not something you’re going to give to a 20-year-old, but in someone who is getting really in the part where chronic immune inactivation is present, it could really play an important role in the future
- What the paper showed was in mice [[treated](https://pmc.ncbi.nlm.nih.gov/articles/PMC11291288/#Sec13) with anti-IL-11 neutralizing antibody commercially made by Genovac]
  - From what Eric understands is already an existing molecule
  - Recently was contacted by a company that has another novel inhibitor of IL-11

***You can imagine this to become part of the whole armamentarium that we have against aging***

**How do you see playing that off something on the other side of the spectrum?**

- Peter points out that we’re really trying to deal with 2 sides of this system
- 1 – We want to tamp down the part that’s overactive and
- 2 – We want to ramp up the part that’s underactive
- The only example we have over here is rapamycin
- Now have IL-11 inhibition (or use knockout mice)
  - Blocking IL-11 did good things

Peter asks, “*Is this one of those things where you need to do both? By the way, maybe you have growth hormone over here, as well. Right?*”

- Yeah, anti-IL-1 is also there

**Peter’s takeaway**

- Block IL-1, block IL-11, give growth hormone, give rapamycin
- Here’s the problem: you get into this reductionist state, which is like the whole NAD world of NR and NMN
- It sounds great, but what if there’s unintended consequences we can’t see?
- Even as much as Peter loves thinking about this, and wants to do all of these things, he starts to think, “***Man, what is the probability we’re going to get this right?***”

*Eric agrees and adds*

- The immune system is an incredibly tenuous system, which is in really delicate balance
- Too much immunity
  - You might say this is good, protection against cancer, protection against microbes
  - But then you get autoimmunity
- Not enough immunity
  - You run the risk of being kicked by a pneumonia or some kind of infection
  - At least you don’t have too much inflammation

***This is a very fine balance***

**This is why Peter wishes we had a dashboard**. **What are the biomarkers we can use for these things?**

- We don’t have this problem with blood pressure
- We don’t have this problem with thyroid hormone

***We don’t have this problem with so many things that we treat, because we can measure what we care about***

**Eric points out: the immune system is so complex, there’s not going to be one single marker**

- His colleague [David Furman](https://www.buckinstitute.org/lab/furman-lab/) has this thing called [iAge](https://edificehealth.com/an-inflammatory-aging-clock-iage-based-on-deep-learning-tracks-multimorbidity-immunosenescence-frailty-and-cardiovascular-aging/), that was the first attempt at trying to measure immune aging
  - This was pioneered by [David Furman](https://www.buckinstitute.org/lab/furman-lab/) (at the Buck) and [Mark Davis](https://med.stanford.edu/profiles/mark-davis) (at Stanford)

*What does iAge measure? Is it all serum biomarkers?*

- Yeah, mostly cytokines

*How is it validated?*

- [Clinical studies](https://pubmed.ncbi.nlm.nih.gov/34888528/)

## Biological aging clocks: types of clocks, promise, major limitations, and future outlook [1:48:30]

**Where do we want to begin? There are so many of these out there**

- Some of them are commercially available, some of them are just tools of research at the moment
- Some of them aim to tell you an actual age, an actual number that represents your biologic age, as opposed to your chronologic age
- Some of them don’t aim to tell you that at all, they just want to tell you a rate of aging
- Some of them look only at the epigenetic signature
  - In other words, they look directly at the methylation sequence
- Others look at a host of markers, including some very simple serum biomarkers like glucose levels, and vitamin D levels, and things like that

*How do you make sense of all of those tools?*

- Right now we don’t

> “*They [biological clocks] are not ready for prime time in terms of patient management. They are research tools.*”‒ Eric Verdin

- Peter finds Eric’s view on this interesting because these clocks are far outside of research labs; they’re commercially available
- [Matt Kaeberlein](https://www.linkedin.com/in/mkaeberlein/) measured his clocks and Eric has done the same thing (he measures them every 3 months)
  - [Matt discussed this in [episode #333](https://peterattiamd.com/longevityroundtable/#:~:text=Matt%20tested%204%20different%20direct%2Dto%2Dconsumer%20biological%20age%20kits) after 35:00]

Eric shares, “*It’s a scatterplot, in a way. I’m between 25 and 68, which is, of course I like the clock that show me to be young.*”

- That being said, we know that, we’re learning
- For example, you alluded to the fact that they can vary the same clock
  - There’s **circadian variation**, for example your age can vary by 5 years using some of the clocks, depending on when you measure (what time of day)
- As we learn, companies will encourage you to measure, to draw your blood always at the same time of day

*Currently, the whole field is almost completely focused on DNA methylation*

- [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath) has done beautiful, pioneering work, identifying all this
- [Morgan Levine](https://www.altoslabs.com/team/morgan-levine), and others have gone
- [Dan Belsky](https://www.belskylab.com/), with [DunedinPACE](https://www.trudiagnostic.com/dunedin-pace) is another epigenetic clock that measures the pace of aging
  - This is probably Eric’s favorite, because it really seems to be responding to interventions
  - If you change your diet, or if you do something, you will see your pace of aging changing

***The problem: we don’t know how to use these tools clinically***

- They’re nice gadgets to buy, the companies are selling you supplements, and then they’re selling you the test with it
- Eric doesn’t know what to make of it
- Personally, he thinks this is not ready for prime time
- It’s something that maybe should be done in the future

Peter asks, “*Would you agree with my stern words on this? Because I’ve made a lot of enemies by saying that if as a consumer, you encounter a company that is selling you a test, especially a test that is not validated in any clinically meaningful way, and then in the same breath selling you a supplement to fix the result of that test. You need to run.*”

- Eric agrees
- Peter doesn’t have any patience for that kind of behavior
- Someone recently told Eric that for one of these tests, almost everyone who gets a result that is low (being bad)
  - The next step is the recommendation to buy this supplement to solve the problem

**It’s the same thing with the sirtuins and NAD ‒ it’s too early**

- Let’s not throw out the baby with the bath water
- There’s a whole series of these players, and Eric is not disputing their honesty or good intention

**What do you think is the biggest problem?**

*Is the biggest problem the biologic noise in the system?*

- Which means even if you had the absolute perfect tool to measure, and you knew exactly what to measure, the movement of that thing is so great that the probability that you’re capturing a meaningful value is irrelevant
- In other words, imagine that there’s a variable that moves like this, but on the small level it’s moving like this
  - For example, imagine you were measuring heart rate, but you could only sample it milliseconds at a time, and what you were actually measuring was heart rate variability instead of heart rate ‒ it would be useless; it’s too noisy
- No, Eric doesn’t think that’s the problem
- He works with [TruDiagnostic](https://www.trudiagnostic.com/?variation=1), and they use the [EPIC array](https://pubmed.ncbi.nlm.nih.gov/38455390/)
  - You get not one clock, you get dozens

***Eric finds this biological clock tends to be reproducible every 3 months, unless he makes some intervention***

**Eric’s advice on biological clocks**

- If you really are determined to use them, use all of them
- They all are different mirrors of your reality

Eric explains, “*The problem with the methylation clocks is that there’s a very tenuous link between the change of methylation at any given site, and the biology.*”

- Typically, each clock would rely on about 500 different methylation sites
- But they’re not attached to a specific gene, so you don’t really know what it means

Peter asks, “*How are they even doing that? They’re not measuring with point arrays.*”

- They’re doing this with arrays
- They have about 20 million methylation sites that they’re assessed, but each clock uses a subset 400 or 500
- They’re actually measuring point of methylation
  - They’re quantifying the level of methylation at each of these sites

**The problem with the clocks is also, where do you obtain them from?**

**⇒** Typically blood is a heterogeneous compartment

- As you age, for example, you know that your fraction of naive T cells decreases
  - Down to close to zero, if you’re 80 years old
  - Your memory T-cells increase
- Eric did a very simple experiment: we sorted all of these different T-cell subsets and measured their epigenetic age using several of the clocks
  - Memory, naïve, central memory, terminally differentiated,
  - [We found a] 20 to 25 year difference between the [naïve](https://en.wikipedia.org/wiki/Naive_T_cell) and the [central memory T-cell](https://en.wikipedia.org/wiki/Memory_T_cell#Sub-populations) (in the direction you would predict: the naïve are much younger)
- ***That was really interesting because it means any conditions where you see a shift in the relative proportion of these cells [memory cells, it could look like you’re aging]***
  - For example, you get an acute COVID infection, what happens? You have a massive expansion of your memory T-cells,
  - And then you sample, and given that these cells look much older than the other ones, you’re going to look like you’re aging
- There’s a whole literature that talks about accelerated aging and rheumatoid arthritis, in COVID and HIV, all of these conditions that are all associated with chronic immune activation
  - So that’s another confounding variable
- So with a student in the lab, Eric made a new clock that eliminated all of these methylations sites linked to differentiation
  - This clock does not vary as a function of the types of cells that are in the blood
- As a T-cell goes from being a naïve T-cell to being a memory T-cell to being a [TEMRA](https://en.wikipedia.org/wiki/Memory_T_cell#Sub-populations:~:text=TEM%20and-,TEMRA%20lymphocytes,-are%20primarily%20active), the methylation patterns changed as part of the epigenetic regulation

***So we eliminated all of those sites, made a new clock called the*** [***IntrinClock***](https://pubmed.ncbi.nlm.nih.gov/39095531/)***, which actually is impervious to your level of immune activation***

- What’s interesting is that that clock doesn’t change anymore, during COVID
- It changed very little during HIV
- It doesn’t change during a whole series of conditions where people have talked about aging acceleration
  - Including the story that we talked about earlier, on growth hormone

Peter asks, “*What does change it, then?*”

- Cancer
- Senescence (which is really interesting)

*What about short-term interventions that might be beneficial?*

- If you took an individual who is insulin resistant, and you put them on a GLP-1 agonist, and 3 months later they’re 20 pounds lighter and their insulin resistance has resolved
- Eric would not be able to tell you how that changes on the clock for individual clocks
- [Dan Belsky’s](https://www.belskylab.com/) [DunedinPACE](https://www.trudiagnostic.com/dunedin-pace) clock is the one that, repeatedly, people have shown seems to be responding to interventions (and it’s reproducible)

*The 2 qualities you want in a biological clock*

- 1 – Predictive of income, life expectancy, occurrence of disease
- 2 – Responsive to interventions and reproducible
- Reproducibility is more a question of the laboratory that’s doing it and also the biologic noise

**Peter’s gripe with these clocks**

- The [PACE clock](https://pubmed.ncbi.nlm.nih.gov/35029144/) is different because it’s trying to give you a **rate of aging**
- But these clocks that spit out, “*Hey Eric, congratulations, you’re 25.*”
- Peter would say to someone who says, “*Isn’t that wonderful?*” He’d say, “*Maybe, but do you actually believe that? You’re 68 and you’re clock said you’re 25*.”
  - Should you expect to live another 55 years?

***Are these clocks a better predictor of future life than chronologic age? To Peter’s knowledge, the answer is no***

> “*There is no clock that has a better ability to predict lifespan than chronologic age does. And until that’s the case, I worry that the biologic clocks are creating a bit of a distraction.*”‒ Peter Attia

- Maybe we ought to focus on clocks where the readout is more about, “*Is this intervention good or bad… or a net positive intervention, or a net negative intervention?*”
- Eric agrees

**Where the field of biologic clocks is going**

- The field initially focused on epigenetic clocks
- Because this is [Steve Horvath’s](https://en.wikipedia.org/wiki/Steve_Horvath) pioneering work
  - It got everybody to start thinking we can generate these tools

***The field is now moving into proteomics clocks***

**What makes up** [**Dan’s**](https://www.belskylab.com/) **clock [**[**DunedinPACE**](https://pubmed.ncbi.nlm.nih.gov/35029144/)**]?**

- It’s also methylation

*Why do you think it’s doing a better job than, maybe Horvath’s clock, at the moment?*

- It really depends on what the variable, what the cohort, what the question was
- Dan’s is the only one that’s doing it in this way
  - They’re just looking at it in a completely different way

**How much is AI facilitating these biologic clocks?**

- Machine learning is the key instrument
- Essentially, what these clocks are is a regression analysis
  - Start with the variable, which is your age
  - And you regress each methylation site onto the age
  - You do this on enough people of different ages, you’ll find an average
- Peter wonders if that’s the wrong way to do it

*Wouldn’t it be better to get biobanked data, and instead of mapping it onto age, map it onto number of years remaining in life?*

- They’ve done this in terms of life expectancy, they’ve done this in terms of morbidity
- This is like this third and fourth generation of these clocks
  - Now are looking at regression
  - The initial one was just chronological
- Steve used to go around saying, “*My correlation coefficient is 99.*”
  - Well, Eric can look at a calendar; he doesn’t need an epigenetic clock to tell him how old he is
- The next generation of clocks actually had a bigger spread
- They started to build it on a different variable

## The potential of proteomics-based aging clocks for detecting organ-specific decline and frailty [2:00:45]

- The whole idea that the field is moving on to the next stage, which is non-epigenetic clocks
- He’s still frustrated, as a biologist, trying to understand what are these clocks?
- Peter thinks the clocks should consider everything: the metabolome, the proteome, and the epigenome
  - There’s no excuse today, with the computing power, not to do that
- Eric points out we have clocks based on: [fundus](https://pubmed.ncbi.nlm.nih.gov/36975205/), the skin, facial recognition

***The clocks are going to be measured using dozens of different biological variables***

- [Ani Biome](https://anibiome.ai/) is a biotech in the Bay area using a tongue picture and machine learning to recognize patterns or discoloration

*Another exciting story was* [*Tony Wyss-Coray’s*](https://med.stanford.edu/profiles/tony-wyss-coray) *paper*

- Using proteomics, he has [shown](https://pubmed.ncbi.nlm.nih.gov/38057571/) that the proteome in plasma changes throughout life
  - In a pretty dramatic matter, which is really completely mind-boggling to see that you can be so different as you age, in terms of your whole blood proteome
- If the epigenome is changing, then gene expression is changing [leading to changes in the proteins expressed (the proteome)]
- Eric is amazed that it would change to such a degree

Peter asks, “*Do you think that most of those changes are post-translational?*”

- No, most of them are probably expression level

**People are building transcriptomics clocks**

[*Tony*](https://med.stanford.edu/profiles/tony-wyss-coray) *has a study that is coming out soon [*[*preprint*](https://pubmed.ncbi.nlm.nih.gov/38915561/)*] where they’ve gone back using this proteomics clock*

- They’ve done this, on a UK biobank, more than 40,000 different people
- What Tony did was actually remarkable: he looked at each of these proteins that are in the blood, and selected some that were predictive to be coming from unique organ
  - Imagine what you know about how you measure a [tropomyosin](https://en.wikipedia.org/wiki/Tropomyosin), for heart attack
- They went and looked in every single organ and said, “*Okay, what proteins are specific to this organ, and which ones actually can be measured into the plasma?*”
- And using this, they were able to generate what they call an organ-specific clock

***Simply from a blood draw, looking at the proteome they’re able to really determine: Do you have a frailty point? When I look at you, is there suffering happening?***

- Tony Wyss-Coray has a new startup called [Vero](https://www.verobioscience.com/)

Disclosure: Eric has joined the board of Vero because he’s really excited about what they’re trying to do

- He thinks it brings a whole new dimension to these predictive biomarkers, which is more aligned to what Eric and Peter have seen as physicians

***For the simple-minded, as the protein is released into the blood that shouldn’t be there, it might be indicating some suffering***

- Eric discussed with some colleagues who have used these clocks and have identified some abnormal aging in a unique organ, only to go back and find that there was indeed one problem, without going into what the issues were

**The reason Peter tends to be a slower adopter of these things**

- How much noise is in the system?
- If he does that test on a patient and it comes back and says there’s something wrong with the liver, your kidney is a bit too old, etc.

*Peter has 2 fundamental questions*

- 1 – Could he have figured this out another way
- If the test points to the liver: How do your [transaminases](https://en.wikipedia.org/wiki/Elevated_transaminases) look?
- If it’s saying there’s something wrong with the kidney: Would a urinary analysis pick that up?
  - Looking at [creatinine](https://en.wikipedia.org/wiki/Creatinine) clearance or [cystatin C](https://en.wikipedia.org/wiki/Cystatin_C), or something else?

***In other words, is it giving information that you can get elsewhere in a more reproducible, more validated fashion?***

- 2 – The potential for false positives
- Let’s say it comes back and says 7 things are problematic, and by standard assays, everything looks awesome
- Then Peter goes poking around and finds one of the is indeed not working, but the other 6 are perfectly fine
- That’s a whole false positive situation

Eric replies, “*That’s a whole MRI*…”

- It’s the same problem we have with cancer screening

***The buyer needs to beware of the Pandora’s box you open***

- At least with MRI, you’re dealing with imaging
- This sounds exciting and yet it’s a bit of a black box where it’s going to spit out, “*Oh my God, there’s something wrong with your left testicle*.”
- Then what do you need to do?

**Eric explains more about these assays**

- The assays are generated in a way that there are multiple [proteins analyzed for any prediction]
  - It’s not like one single protein, like a tropomyosin where we know that’s a clear indicator, there’s something, cell death, in terms of your heart

***In this case, the clocks are generated in a way that there are multiple sentinels for each organ (many)***

**The Start-up [**[**Vero**](https://www.verobioscience.com/)**] is working to deploy these [proteome-based] tests**

- These tests have the potential to highlight a **frailty point** (which in aging research is critical)

> “*You can have the best mind and the best hearts in the world, if something else is going to fail that you are completely unaware of, you want to know as soon as you can.*”‒ Eric Verdin

- These tests are in the early days, but it’s quite exciting

**Peter will probably maintain a shockingly high degree of skepticism**

- He will probably enjoy some experimentation with it
- His experience in the real world is that that’s just not how it works

***There aren’t people walking around that are insanely, remarkably healthy, where everything looks amazing, but they have some time bomb they don’t know about***

- With the exception of a few things he’s not sure it would pick up

*For example, cancer is always that thing*

- There’s an entire field of medicine that’s going around with [liquid biopsies](https://en.wikipedia.org/wiki/Liquid_biopsy), that’s exactly trying to solve that problem
  - [liquid biopsies was discussed in episodes [#213](https://peterattiamd.com/maxdiehn/) and [#290](https://peterattiamd.com/alexaravanis/)]
- You could reword the liquid biopsy industry through the lens you said, which is it’s looking for that weakest link, which in this case is the earliest signs of cancer
- Eric points out, it could be that a cancer will manifest itself in local organ suffering
- And along with a liquid biopsy, it tells you you have some cancer cell
- It might point you to one place where actually, this is actually happening

**Eric makes the same point about the yearly MRI he gets**

- He has a whole bunch of physician friends who ask about his yearly MRI, “*Why do you do this?*”
- Eric would rather know
- They say, “*Well, you’re going to find all kinds of things*.”
- He shares that he did find something: a mass behind his jaw
  - It was not a tumor, but it took 6 months of worrying what it was before it was decided not to biopsy anything

***Eric’s sense is this is a novel way to practice medicine***

- Peter is criticized heavily for being too much on the forefront of doing that, but he doesn’t go nearly as far as some

**At the end of the day, every time Peter does a test, he thinks about**

- 1 – You never do a test unless you’re willing to act on an outcome, or you have a sense of how the outcome will change your behavior
- 2 – We don’t order tests for the sake of information, we order tests to make decisions
- Therefore, you must at a minimum understand the full suite of outcomes that can come from the test, and how many of them will pose huge trouble for you?

***20% of Peter’s patients opt not to do whole body MRI, and he fully endorses that decision***

**Peter is eager to look at these proteome-based tests**

- He thinks the proteome offers a lot
- But he’s always worried about going a little too far on the clinical implication of a test
- Eric agrees in terms of being careful

**Earlier, they talked about 2 organs being rate-limiting in terms of aging: the immune system and the brain**

- They have a whole series of immune markers that are predictive of some degree of immune activation, and so on
- There’s a lot of other things Peter wanted to chat about
- He will have Eric come back and do another podcast to dive deeper into some of these topics

---

## Selected Links / Related Material

**The Buck Institute for Research on Aging**: [The Buck Institute: Live better longer](https://www.buckinstitute.org/) (2025) | [5:00]

**Biomarkers that measure aging in organs is predictive of lifespan (Tony Wyss-Coray)**: [Proteomic organ-specific ageing signatures and 20-year risk of age-related diseases: the Whitehall II observational cohort study](https://pubmed.ncbi.nlm.nih.gov/40015764/) | *The Lancet Digital Health* (M Kivimaki et al. 2025) | [6:00]

**Episodes of** ***The Drive*** **with Richard Miller**: [19:15]

- [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021)
- [#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.](https://peterattiamd.com/richardmiller2/) (December 4, 2023)
- [#333 ‒ Longevity roundtable — the science of aging, geroprotective molecules, lifestyle interventions, challenges in research, and more | Steven Austad, Ph.D., Matt Kaeberlein, Ph.D., Richard Miller, M.D., Ph.D.](https://peterattiamd.com/longevityroundtable/) (January 27, 2025)

**Mice fed a ketogenic diet live longer**: [A ketogenic diet extends longevity and healthspan in adult mice](https://pmc.ncbi.nlm.nih.gov/articles/PMC5609489/) | *Cell Metabolism* (M Roberts et al. 2017) | [20:45]

**Biochemical BMI assesses metabolic status**: | [Multiomic signatures of body mass index identify heterogeneous health phenotypes and responses to a lifestyle intervention](https://pubmed.ncbi.nlm.nih.gov/36941332/) | *Nature Medicine* (K Watanabe et al. 2023) | [35:15]

**Episode of** ***The Drive*** **with Steven Rosenberg (cancer immunology)**: [#177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers](https://peterattiamd.com/stevenrosenberg/) (September 21, 2021) | [36:15]

**Vaccine responses in people over 70 years old**: [45:00]

- [Antibody response to influenza vaccination in the elderly: a quantitative review](https://pubmed.ncbi.nlm.nih.gov/16213065/) | *Vaccine* (K Goodwin, C Viboud, L Simonsen 2006)
- [Age-dependent Immune Response to the Biontech/Pfizer BNT162b2 Coronavirus Disease 2019 Vaccination](https://pubmed.ncbi.nlm.nih.gov/33906236/) | *Clinical Infectious Disease* (L Muller et al. 2021)

**mRNA vaccines elicit robust T cell responses in older adults**: [Safety and Immunogenicity of SARS-CoV-2 mRNA-1273 Vaccine in Older Adults](https://pubmed.ncbi.nlm.nih.gov/32991794/) | *NEJM* (E Anderson et al. 2020) | [45:00]

**Vaccine effectiveness against severe COVID-19 in elderly populations**: [45:00]

- [Covid-19 Vaccine Effectiveness against the Omicron (B.1.1.529) Variant](https://pubmed.ncbi.nlm.nih.gov/35249272/) | *NEJM* (N Andrews et al. 2022)
- [Sustained Effectiveness of Pfizer-BioNTech and Moderna Vaccines Against COVID-19 Associated Hospitalizations Among Adults – United States, March-July 2021](https://pubmed.ncbi.nlm.nih.gov/34437524/) | *MMWR* (M Tenforde et al. 2021)

**Association of COVID-19 vaccination with hospitalization from other diseases**: [Association of COVID-19 vaccination with risks of hospitalization due to cardiovascular and other diseases: A study using data from the UK Biobank](https://pubmed.ncbi.nlm.nih.gov/38701913/) | *International Journal of Infectious Diseases* (Y Xiang et al 2024) | [46:30]

**Human growth hormone may rejuvenate the thymus**: [Reversal of epigenetic aging and immunosenescent trends in humans](https://pubmed.ncbi.nlm.nih.gov/31496122/) | *Aging Cell* (G Fahy et al. 2019) | [48:45]

**1000 immunomes project, study of immunology and aging**: [1000 Immunomes Project](https://med.stanford.edu/1000immunomes.html) | Stanford Medicine (2025) | [57:45]

**Rapamycin provides immune enhancement**: [59:15]

- [mTOR inhibition improves immune function in the elderly](https://pubmed.ncbi.nlm.nih.gov/25540326/) | *Science Translational Medicine* (J Mannick et at. 2014)
- [TORC1 inhibition enhances immune function and reduces infections in the elderly](https://pubmed.ncbi.nlm.nih.gov/29997249/) | *Science Translational Medicine* (J Mannick et al. 2018)
- [Targeting the biology of ageing with mTOR inhibitors to improve immune function in older adults: phase 2b and phase 3 randomised trials](https://pubmed.ncbi.nlm.nih.gov/33977284/) | *Lancet Healthy Longevity* (J Mannick et al. 2021)

**Episode of** ***The Drive*** **discussing Mannick’s trial with a rapalog**: [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) (September 25, 2023) | discussion occurs after [2:00:30] | [1:00:15]

**Episodes of** ***The Drive*** **with Steve Austad**: [1:09:30]

- [#171 – Steve Austad, Ph.D.: The landscape of longevity science: making sense of caloric restriction, biomarkers of aging, and possible geroprotective molecules](https://peterattiamd.com/steveaustad/) (August 9, 2021)
- [#333 ‒ Longevity roundtable — the science of aging, geroprotective molecules, lifestyle interventions, challenges in research, and more | Steven Austad, Ph.D., Matt Kaeberlein, Ph.D., Richard Miller, M.D., Ph.D.](https://peterattiamd.com/longevityroundtable/) (January 27, 2025)

**CD38 appears to drive decrease of NAD during aging**: [CD38 Dictates Age-Related NAD Decline and Mitochondrial Dysfunction through an SIRT3-Dependent Mechanism](https://pubmed.ncbi.nlm.nih.gov/27304511/) | *Cell Metabolism* (J Camacho-Pereira et al. 2016) | [1:24:30]

**Review on the role of CD38 in age-related decline of NAD**: [The CD38 glycohydrolase and the NAD sink: implications for pathological conditions](https://pubmed.ncbi.nlm.nih.gov/35138178/) | *American Journal of Physiology, Cell Physiology* (J Zeidler et al. 2022)

**Cytokines produced by senescent cells induce CD38 expression by macrophages leading to a depletion of NAD**: [Senescent cells promote tissue NAD+ decline during ageing via the activation of CD38+ macrophages](https://pubmed.ncbi.nlm.nih.gov/33199924/) | *Nature Metabolism* (A Covarrubias et al. 2020) | (1:27:15]

**Paper by Josh Rabinowitz shows that intravenous NAD is mostly converted to NAM**: [Quantitative Analysis of NAD Synthesis-Breakdown Fluxes](https://pubmed.ncbi.nlm.nih.gov/29685734/) | *Cell Metabolism* (L Liu et al. 2018) | [1:37:30]

**Trial blocking IL-11**: [Inhibition of IL-11 signalling extends mammalian healthspan and lifespan](https://pubmed.ncbi.nlm.nih.gov/39020175/) | *Nature* (A Widjaja et al. 2024) | [1:43:00]

**Immunological clock iAge**: [An inflammatory aging clock (iAge) based on deep learning tracks multimorbidity, immunosenescence, frailty and cardiovascular aging](https://pubmed.ncbi.nlm.nih.gov/34888528/) | *Nature Aging* (N Sayed et al. 2021) | [1:48:00]

**Clinical studies using iAge**: [1:48:00]

- [Oats Lower Age-Related Systemic Chronic Inflammation (iAge) in Adults at Risk for Cardiovascular Disease](https://pubmed.ncbi.nlm.nih.gov/36364734/) | *Nutrients* (E Dioum et al. 2022)
- [Multi-Omics Analysis Reveals Biomarkers That Contribute to Biological Age Rejuvenation in Response to Single-Blinded Randomized Placebo-Controlled Therapeutic Plasma Exchange](https://pubmed.ncbi.nlm.nih.gov/40424097/) | *Aging Cell* (M Fuentealba et al. 2025)

**DunedinPACE clock**: [DunedinPACE, a DNA methylation biomarker of the pace of aging](https://pubmed.ncbi.nlm.nih.gov/35029144/) | *eLife* (D Belsky et al 2022) | [1:50:30]

**IntrinClock**: [Development of an epigenetic clock resistant to changes in immune cell composition](https://pubmed.ncbi.nlm.nih.gov/39095531/) | *Communications Biology* (A Tomusiak et al. 2024) | [1:56:00]

**Proteome changes in the plasma correlates with organ-specific disease (Tony Wyss-Coray)**: [Organ aging signatures in the plasma proteome track health and disease](https://pubmed.ncbi.nlm.nih.gov/38057571/) | *Nature* (H Oh et al. 2023) | [2:01:00]

**Vero Bioscience**: [Vero: Pioneering Proteomics for Precision Organ Health](https://www.verobioscience.com/) (2025) | [2:03:00]

---

## People Mentioned

- [Tony Wyss-Coray](https://profiles.stanford.edu/tony-wyss-coray) (D.H. Chen Professor II of Neurology & Neurological Sciences at Stanford University and Director of the Phil and Penny Knight Initiative for Brain Resilience; expert in brain aging and neurodegenerative disease) [6:00, 2:01:00]
- [Martin Brand](https://www.buckinstitute.org/research/research-professors/#:~:text=EMERITUS%20FACULTY-,Martin%20Brand%2C%20PhD,-Professor%20Emeritus) (Professor Emeritus at the Buck Institute, expert in mechanisms of energy transformation and free-radical production and their role in the diseases of aging) [14:30]
- [Ralph DeFronzo](https://directory.uthscsa.edu/academics/profile/defronzo) (Professor of Medicine and Chief of the Diabetes Division at UT Health San Antonio, and Deputy Director of the Texas Diabetes Institute) [27:15]
- [Leroy (Lee) Hood](https://www.linkedin.com/in/leehood111/) (Founder & CEO of [Phenome Health](https://phenomehealth.org/c-suite/lee-hood-md-phd), Chief Innovation officer at [The Buck Institute for Research on Aging](https://www.buckinstitute.org/news/the-buck-institute-and-phenome-health-announce-major-strategic-partnership/), co-founder and Professor at the [Institute for Systems Biology](https://isbscience.org/people/leroy-hood-md-phd/?tab=biography)) [35:15]
- [Nathan Price](https://www.linkedin.com/in/nathandprice/) (Professor at the [Buck Institute for Research on Aging](https://www.buckinstitute.org/lab/price-lab/) and CSO of [Thorne](https://www.thorne.com/)) [35:15]
- [Steven Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) (Senior Investigator, Chief of Surgery Branch, and Head of Tumor Immunology Section at the NCI Center For Cancer Research) [36:15]
- [Joseph “Mike” McCune](https://cfar.ucsf.edu/people/mike-mccune) (Emeritus Professor of Medicine at [UCSF](https://profiles.ucsf.edu/mike.mccune), member of CFAR, and expert in HIV) [49:00]
- [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath) (PI at [Altos labs](https://www.altoslabs.com/team/steve-horvath); former Professor of Human Genetics and Biostatistics at UCLA; expert in epigenetic markers of aging) [50:45, 1:50:15]
- [Matt Kaeberlein](https://www.linkedin.com/in/mkaeberlein/) (CEO of Optispan, Affiliate Professor and Co-Director of the Dog Aging Project at at the University of Washington, expert on interventions to promote healthspan) [52:30, 1:00:15, 1:18:30, 1:49:30]
- [Mark Davis](https://med.stanford.edu/profiles/mark-davis) (Professor and Chair of Microbiology and Immunology at Stanford, expert in T and B lymphocytes) [57:45, 1:48:15]
- [Joan Mannick](https://www.linkedin.com/in/joan-mannick-8089a614/) (Co-founder and CEO of [Tornado Therapeutics](https://www.tornado-tx.com/team), expert in mTOR and geroscience) [58:15]

- [Lloyd Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/) (President & CEO at Koslapp Therapeutics, a rheumatologist and immunologist with an extensive career in the biopharmaceutical industry) [58:15]
- [Steve Austad](https://www.uab.edu/icar/about/icar-leadership/steven-austad) (Distinguished Professor and Protective Life Endowed Chair in Healthy Aging Research of the Department of Biology, University of Alabama at Birmingham; Scientific Director of the American Federation for Aging Research; and Director of the UAB Nathan Shock Center of Excellence in the Basic Biology of Aging) [1:09:30]
- [Leonard (Lenny) Guarente](https://biology.mit.edu/profile/leonard-p-guarente/) (Novartis Professor of Biology at MIT, expert in the genetics of aging and age-related diseases) [1:18:15]
- [David Sinclair](https://sinclair.hms.harvard.edu/people/david-sinclair) (Professor of Genetics at the Paul F. Glenn Center for Biology of Aging Research at Harvard Medical School; expert in aging) [1:18:30]
- [Eduardo Chini](https://www.mayo.edu/research/faculty/chini-eduardo-n-m-d-ph-d/bio-00085601) (Faculty at the Mayo Clinic in Jacksonville, FL; expert in metabolism, NAD, and aging) [1:24:30]
- [Josh Rabinowitz](https://chemistry.princeton.edu/faculty-research/faculty/joshua-rabinowitz/) (Professor of Chemistry and the Lewis-Sigler Institute for Integrative Genomics at Princeton University and Director of the Ludwig Princeton Branch; expert in metabolism and the flux of metabolites) [1:37:30]
- [David Furman](https://www.buckinstitute.org/lab/furman-lab/) (Associate Professor at the Buck Institute; expert in applied artificial intelligence and computing immunology aging) [1:47:45]
- [Morgan Levine](https://www.altoslabs.com/team/morgan-levine) (VP of computing at Altos Labs, PI at the [Laboratory of Aging in Living Systems (ALIS)](https://www.morganlevinelab.com/); expert in computational approaches to molecular mechanisms driving aging and epigenetic clocks) [1:50:30]
- [Daniel (Dan) Belsky](https://www.belskylab.com/) (Associate Professor of Epidemiology (in the Robert N. Butler Columbia Aging Center at the Columbia Mailman School of Public Health; expert in the epigenetics of aging) [1:50:30]

---

![](https://peterattiamd.com/wp-content/uploads/2025/07/bio-ericverdin-600x600.png)

##### Eric Verdin, M.D.

Eric Verdin, a native of Belgium, received his Doctorate of Medicine (MD) from the University of Liege. He completed additional clinical and research training at Harvard Medical School. Dr. Verdin has held faculty positions at the University of Brussels, the National Institutes of Health (NIH), and the Picower Institute for Medical Research. Currently, Dr. Verdin is the President, CEO, and a Professor at the [Buck Institute for Research on Aging](https://www.buckinstitute.org/lab/verdin-lab/). Dr. Verdin is also a Professor of Medicine at [UCSF](https://bms.ucsf.edu/people/eric-verdin-md) and an Adjunct Professor of Gerontology at the [USC](https://gero.usc.edu/faculty/eric-verdin-md/) Leonard Davis School of Gerontology.

Dr. Verdin studies how metabolism, diet, and small molecules regulate the activity of HDACs and sirtuins, and thereby the aging process and its associated diseases, including Alzheimer’s. In addition to understanding the epigenetic regulators of the aging process, his lab studies the relationship between aging and the immune system. He believes that chronic inflammation represents a key unifying factor underpinning the development of the chronic diseases of aging, including neurodegeneration (Parkinson’s and Alzheimer’s), cancer, type 2 diabetes, and atherosclerosis (heart attack and stroke). Further, a better understanding of the mechanisms leading to the chronic inflammation associated with aging should provide novel therapeutic targets and potential interventions against human aging.

Dr. Verdin has published more than 270 scientific papers and holds more than 18 patents. He is a highly cited scientist (top 1 percent) and has been recognized for his research with a Glenn Award for Research in Biological Mechanisms of Aging and a senior scholarship from the Ellison Medical Foundation. He is an elected member of several scientific organizations, including the American Association for the Advancement of Science, the American Society for Clinical Investigation, and the Association of American Physicians. He also serves on the advisory council of National Institute on Drug Abuse at the National Institutes of Health.

Dr. Verdin has extensive experience working with biotech companies. He is a founder of Acylin (purchased by Abbvie). He served on the scientific advisory boards of Elixir, Sirtris (purchased by GSK), Calico (Google), and Nokia, and he also served as advisor to Sofinnova Ventures. Dr. Verdin has also worked for several years as a consultant to Novartis, GSK, J&J, Altana, Roche, Pfizer, and other biotech companies. [[Buck](https://www.buckinstitute.org/lab/verdin-lab/)]

LinkedIn: [Eric Verdin](https://www.linkedin.com/in/eric-verdin-490212/)