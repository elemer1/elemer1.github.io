# #345 ‒ Chronic pain: pathways, treatment, and the path to physical and psychological recovery | Sean Mackey, M.D., Ph.D.

**Source:** [https://peterattiamd.com/seanmackey/](https://peterattiamd.com/seanmackey/)

---

Sean Mackey is a professor of pain medicine at Stanford University and the director of the Stanford Systems Neuroscience and Pain Lab, where his research explores the neural mechanisms of pain and the development of novel treatments for chronic pain. In this episode, Sean joins Peter for a wide-ranging discussion on the multifaceted nature of pain—as both a sensory and emotional experience—and its evolutionary purpose as a critical survival mechanism. He dives into how pain is transmitted through the nervous system, the different types of pain, and why different individuals perceive pain so differently. Sean shares insights into pain management strategies ranging from medications like NSAIDs and opioids to neuromodulation techniques such as transcutaneous electrical nerve stimulation (TENS). Additionally, this episode explores the interplay between sleep and chronic pain and the psychological and emotional dimensions of pain, and it includes a personal story from Peter about his own experience with pain and how Sean’s expertise helped him more than two decades ago.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/seanmackey/the_Drive_public.png)

Play

#345 ‒ Chronic pain: pathways, treatment, and the path to physical and psychological recovery | Sean Mackey, M.D., Ph.D.

#345 ‒ Chronic pain: pathways, treatment, and the path to physical and psychological recovery | Sean Mackey, M.D., Ph.D.

1x15s30s

0:002:47:06

## We discuss:

- The definition of pain, and how our understanding of pain has evolved from a simplistic body-mind separation to a nuanced biopsychosocial model [2:30];
- The biological mechanisms behind how we perceive pain [9:30];
- The role of consciousness in the perception of pain, and how nociception functions during unconscious states [14:30];
- The four types of pain [22:00];
- Using fMRI to identify objective biomarkers of pain in the brain [31:30];
- The evolutionary role of pain in human behavior and survival [36:00];
- How the brain processes and modulates pain signals, Gate Control Theory, the variability in individuals’ pain perception, and effectiveness of neuromodulation techniques like TENS [41:00];
- The brain’s influence on pain: the role of emotion, beliefs, sleep, and individual differences in perception and tolerance [53:45];
- Peter’s personal journey with chronic back pain, and how the emotional consequences of pain can be more distressing than the pain itself [1:04:30];
- The pharmacology of common pain medications—NSAIDs, COX-2 inhibitors, and acetaminophen [1:09:30];
- Muscle relaxants: benefits, drawbacks, and personalized strategies [1:20:30];
- The definition of chronic pain [1:29:15];
- The role of antidepressants in pain management [1:30:15];
- Opioids: their controversial and nuanced role in pain management [1:33:45];
- Alternative therapies: acupuncture and cannabis [1:54:15];
- Fibromyalgia and chronic pain: clinical features, brain mechanisms, and emerging treatments like low-dose naltrexone [2:01:00];
- Possible brain benefits of low-dose naltrexone (LDN) for people with mild cognitive impairment [2:15:00];
- Peter’s recovery from severe chronic pain—how he went from immobility and high-dose opioids to full functionality [2:20:15];
- Breaking the pain cycle: how physical rehabilitation and psychological recovery work together in chronic pain treatment [2:30:45];
- Sean’s struggle with cluster headaches, and the value of knowledge, preparation, and empathy in both managing chronic pain and caring for patients [2:39:15]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Sean Mackey is a Professor of Pain Medicine at Stanford University
  - He also serves as the Director of the [Stanford Systems Neuroscience and Pain Lab](https://med.stanford.edu/pain/research.html)
- His research focuses on the neural mechanisms of pain and the development of innovative treatments for chronic pain conditions
- In this episode Peter talks a little bit about how he and Sean go way back and why it is that he wanted to have Sean on the podcast
- We discuss
  - The definition of pain as both a sensory and an emotional emotional experience
  - Why pain is fundamental as a survival mechanism, and the evolutionary purpose of pain (which has been highly conserved across multiple species)
  - How pain is transmitted through the nervous system, including the different types of fibers that are involved
  - Types of pain, such as nociceptive pain, visceral pain, neuropathic pain, etc.
  - Why pain perception varies so widely from person to person, even in the face of an identical stimulus
    - How psychological and emotional factors play a role in this
  - Various approaches to pain management, including NSAIDs, opioids, and anti-neuropathic medications
  - The effectiveness of neuromodulation techniques like [TENS](https://en.wikipedia.org/wiki/Transcutaneous_electrical_nerve_stimulation)
  - How sleep deprivation affects pain sensitivity
  - Why chronic pain often leads to disrupted sleep cycles
  - And many other things
- Peter shares a very personal experience with his own pain and how Sean came to his rescue 25 years ago

## The definition of pain, and how our understanding of pain has evolved from a simplistic body-mind separation to a nuanced biopsychosocial model [2:30]

- This morning Peter’s wife asked about the topic of today’s podcast and the guest, and when he said Sean Mackey, her face lit up
- She’s never met Sean but she’s heard Peter tell a story about his own experience through this
- It was then that Peter realized he hadn’t seen Sean since medical school
- They met 25 years ago, and Sean played an unbelievable role in bringing Peter back from arguably the brink of what could have been the end of his life

**What pain is**

- There’s nobody listening to us right now who doesn’t know what pain is
  - Who hasn’t experienced pain
- Yet if you ask for a definition of pain, you’d get a lot of using the word to describe the thing, which isn’t truly a definition

*If you were trying to explain to a Martian from another planet who doesn’t experience pain, what it is, what would you say?*

**Formal definition**: an unpleasant sensory and emotional experience associated with actual or potential tissue damage

- If you think of it as an unpleasant sensory and emotional experience is usually tied to something physically happening, but it may not be

**⇒** What’s missing in that definition, is that pain is the great motivator

- Pain is one of the most primitive experiences going back to single cell organisms
  - It’s either pain or reward
  - You’re either being driven towards oxygen, food, sex, or you’re trying to get away from danger
- Pain is so wonderful because it’s so terrible
- It keeps us alive
- Without pain, we would’ve never lived as a species
  - We have these genetic issues of congenital insensitivity to pain
- Pain is an unpleasant sensory and emotional experience

To understand pain, whether you’re a Martian or you’re a human now, you have to look back in history

- [Rene Descartes](https://en.wikipedia.org/wiki/Ren%C3%A9_Descartes), 17th century French philosopher, thought to be the father of modern philosophy
- Incredible contributions: he brought Cartesian geometry to us, which led to calculus, and he had this dualistic model of pain that he put forward
- To his credit, it was the first mechanistic foundation for pain because beforehand pain was thought to be something mystical or religious
  - It was punishment of the gods
- His framework is often illustrated with this famous picture [shown below] of a little boy with his foot in the fire
  - And there’s a little string from his foot going up into his brain, and it ends up in the pineal gland, which was thought to be uniquely a human area

The idea is the fire pulls on the little string, opens up pores, and the [pineal gland](https://en.wikipedia.org/wiki/Pineal_gland) rings a bell and the boy withdraws his foot

![](https://peterattiamd.com/wp-content/uploads/2025/04/f1-seanmackey.png)

**Figure 1. Line drawing of the pain system by Louis La Forge based on Descartes’ description in** ***treatise of Man***. Image credit: [*Journal of Neurophysiology* 2013](https://journals.physiology.org/doi/full/10.1152/jn.00457.2012)

- The idea is in this **dualistic model**, there is a complete separation between body and mind
  - The body is where pain is generated
  - The mind is where it’s perceived, but the mind is simply a passive receptacle receiving these signals
- That model put forward in the 17th century stuck with us for hundreds and hundreds of years, and today it has influenced medical care
  - It has influenced policy
  - It’s influenced everything in our society about the way we think about pain

***This dualistic model is utterly completely wrong***

- Yes, Descartes got Cartesian geometry right, but he complete bollocks screwed it up when it came to pain

It’s only been in the last number of decades that we’ve appreciated the nuance of what pain really is

Sean explains about pain, “***Instead of it being under this guise of this separate mind and body, we now appreciate it as this integrated biopsychosocial phenomenon meaning that, and I think this is one of the most important things that I’d like to drive across.***”

**⇒** **Nociception** is a term referring to electrochemical injury signals that occur in the periphery, that what goes on in the body and what goes on in the brain, the experience of pain, they may have nothing to do with each other or very little linkages (and Sean’s going to unpack that)

- For hundreds of years, we’re basing our understanding of pain on Rene Descartes’ dualistic model
- We still see this in medical care right now
  - For many, many, years, when Sean talked with the surgeons, they were firmly of the opinion that the amount of pain that a patient had after surgery was related to how much the scalpel cut and how much tissue damage was done
- It’s only more in the last 20 or so years that he’s seeing surgeons really embracing this model that ***what people bring to the operating room table directly influences how much pain they have***
  - Their early life experiences, all this stuff that Sean will talk about

**The latter part of the 19th century brought a couple of other tools to pain**

- Local anesthetics (from [cocaine](https://en.wikipedia.org/wiki/Cocaine) down to [lidocaine](https://en.wikipedia.org/wiki/Lidocaine))
- General anesthetics ([ether](https://en.wikipedia.org/wiki/Diethyl_ether#Anesthesia)) ‒ allowed surgeons to cut people without having to hold them down while they screamed
- These didn’t shed any new light on understanding pain
- They were viewed as a blunting instrument; it didn’t change the model

*This has had tragic consequences in the care of people, particularly with* ***chronic pain***

- Particularly women with chronic pain who have felt stigmatized, invalidated because absent something that’s obviously wrong out in the body of the periphery, they were just labeled as being histrionic housewives or being told it’s all in their head
- Not just women, but also some men as well

***That has gotten better with the evolution of our perception or our model into a biopsychosocial model***

## The biological mechanisms behind how we perceive pain [9:30]

**Is there a pain receptor?**

- [Nociceptors](https://en.wikipedia.org/wiki/Nociceptor) are basically a transducer
  - It’s a complicated name
- If you have an engineering background, you’ll all know that a transducer is simply a device that converts one form of energy into another form of energy
  - This microphone is converting sound energy into electrical energy
  - The speakers convert electrical energy back into sound energy
- We have these nociceptors that lie in our skin, our soft tissues, our deep tissues, our viscera, and they’re specialized, and they convert different forms of energy into electrochemical impulses
  - They take pressure; they take heat, cold; they take chemical changes in the form of pH (that can occur during infection)

***Nociceptors convert those into action potentials that are then transmitted up nerves***

- These are little electrical impulses transmitting up generally 2 different nerve fiber types
- 1 -Is called a [C fiber](https://en.wikipedia.org/wiki/Group_C_nerve_fiber), which is thin and slow
  - It’s this pokey slow C fiber that transmits at about 1 meter a second
  - The frame of reference: your thumb is about a meter from your brain
  - So an impulse on a C fiber from your thumb to a brain takes about 1-2 seconds to get there
- 2 – The other nerve fiber type, it’s called an [A delta fiber (Aδ)](https://en.wikipedia.org/wiki/Group_A_nerve_fiber)
  - It’s got some nice insulation around it
  - It transmits 10 times faster, so it takes a little under a 10th of a second to get your thumb to your brain

*To give a real world sense of the difference in C fibers and Aδ fibers, think back to the last time you stepped on a tack in the carpet, you hit your thumb with a hammer, you twisted your ankle coming off a curb. What happened?*

- 1 – You get this sharp jolt of pain that goes right to your brain ‒ those are your Aδ fibers at 10 meters a second rapidly getting up to your brain, rapidly putting into play systems to protect yourself from harm
- You withdraw
- You have a reflex that’s occurring in your spinal cord
- You’re not even consciously aware of it
- Your brain is setting into play escape mechanisms
- The pain that you experience is sharp; it’s well localized
- You know exactly where you stepped on that tack
- 2 – Then about a 1-2 seconds later, you get this hot burning flooding sensation come over your thumb where you hit it with a hammer and you think to yourself, “*Oh damn, this is really going to hurt*,” and it gets hot/ burning
- Those are your C fibers (unmyelinated slow) getting up to your brain
- And what you also notice for the first time is you don’t like this
- This has an unpleasant quality to it that you didn’t get as much with that Aδ sharp pain, but you’re getting with those C fibers

The Aδ is doing 2 things

- It’s creating the spinal reflex to have you pull back without thinking
  - Sean explains it’s synapsing
  - There are synapses in the ventral or anterior (the front portion of your spinal cord), which is your motor part of that spinal cord
  - They’re making synapses and it’s causing a classic withdrawal effect

Peer asks, “*Am I perceiving the pain? If you could do a thought experiment where you could eliminate the C fiber in an individual, would they still feel pain?*”

- Yeah, they would still feel pain
- There’s still a central component to what the A fiber is doing
  - The A fibers are still going up the spinal cord, and they cross over to the other side
- There’s an afferent and an efferent to the whole thing

**⇒** The main pathway we all learn in medical school is a [spinothalamic](https://en.wikipedia.org/wiki/Spinothalamic_tract) pathway

- This goes from the spine up into your brain and we’re going to get there
- But yes, if you had no C fibers, you would still feel pain

**One of the other things that Sean thinks is important to understand about pain is we’ve been trying to knock this out for untold years and we’ve not been very successful with it**

- Part of the challenge is pain is so highly conserved from an evolutionary standpoint
  - As he alluded to earlier, back to single cell organisms, reward/ pain
- We evolved over the years to have this complex experience of pain but also redundancies
- You knock out one pathway related to pain, there’s others there, and they find their way up into the brain just about no matter what

## The role of consciousness in the perception of pain, and how nociception functions during unconscious states [14:30]

**Thinking about this through an evolutionary lens, does a goldfish feel pain?**

*Do we have a clear sense as to how far from humans (or mammals) you go where you still clearly have C fibers and* Aδ *fibers?*

- You could go pretty deep there
- There are a lot of different opinions on this
- Sean doesn’t engage in that debate
- First you have to clearly define the thing you’re debating
- Our definition of pain is a human experience of pain

What Peter is asking is a question about consciousness: *Is consciousness necessary for the internalization of this full gamut of pain?*

- Yes, Sean firmly believes it is
- Sean is a recovering anesthesiologist, and hasn’t done that for 20 years
- When he did it, and when you are operating on a patient, the patient is unconscious
  - They are not experiencing pain

**⇒** You need a conscious brain for the experience of pain

- People incorrectly made the leap of thinking, “*Well, they’re not experiencing pain, so everything’s okay.*”
- That would be a logical fallacy because all those signals are still coming from the body, still hitting the spinal cord and having their impact there
  - All those injury signals
- When you do surgery, it’s really nothing more than a controlled injury

**Peter’s recollection from 20 years ago is that an anesthesiologist was giving not just one medication, but several**

- True
- They were giving something like [halothane](https://en.wikipedia.org/wiki/Halothane), which we didn’t know how it worked then

Peter asks, “*Do we have any idea how halothane works today?*”

- Better ‒ we still are trying to unlock the whole consciousness aspect of things, but we’re inching our way there
- But halothane wasn’t enough, the anesthesiologist still had to give typically a narcotic, even though the patient was unconscious
  - Something like [fentanyl](https://en.wikipedia.org/wiki/Fentanyl)
- They were also often giving an amnesiac so that they wouldn’t have any recollection of what was going on
- We all hear the horror stories of the patient who is paralyzed but somehow conscious
  - You can miss on this state sort of thing

*In theory, a paralytic and an inhaled anesthetic should be sufficient to eliminate the perception of pain in a patient who is being cut*

- Yeah
- Part of the challenge is the levels of volatile gas anesthetic that you need to necessarily obliterate reflexes and full nociceptive impulses would be so high that it would depress one’s blood pressure, and so you augment that with an opioid (like fentanyl or morphine)
  - That’s why what the anesthesiologists do is quite magical
  - This is stepping outside of Sean’s wheelhouse, even though he was an anesthesiologist for a long time

**Peter’s takeaway on anesthesia**: you give the inhaled anesthetic just to get unconsciousness, but not to fully suppress the nociceptic system; instead, you bring on the opioid to do the remainder of that work

- They’re working synergistically and they’re working at different mechanisms
- And during that process, the patient is not feeling pain if they’re unconscious

**⇒** Because you do need a conscious, working, aware brain to feel pain

- But all of the electrical impulses coming in from the body that are slamming into the spinal cord in the brain are open full bore
  - They’re impinging on all those brain systems responsible for stress responses and autonomic control

Peter asks, “*Does that mean we are seeing a cortisol surge? We’re seeing whatever one would expect a conscious person to experience with epinephrine, norepinephrine, cortisol, all these things still surging out in response to pain?*”

***Yes and in response to nociception, independent of perception of pain***

- Notice that Sean is trying to be precise in his language here because since they’re unconscious, there’s no pain, but there’s plenty of nociception

The level of nociception in surgery

- Is arguably more than you would ever experience
- Take a scalpel and then take an electrocautery and start burning tissue
- There’s no level of nociception you could ever experience like that while being awake unless you’re in a burning car

Sean explains, “*It’s remarkable through modern medicine that we get people through all this; it’s a reflection of advancements in surgery, advancements in anesthesiology, advancements in post-operative care, but it is no different than a controlled injury*.”

- It’s done in a nice sterile environment
- But it’s a massive injury that people are undergoing
- They’re just not awake
- There is a stress response associated with that
- Most people recover well

**One of the hot topics of research these days is why do most people recover, but a certain percentage of people go on to have persistent pain after surgery?**

- That’s an area that Sean used to research years ago
- Many others are doing some great work in that space
- Turns out that a lot of the factors (he’ll get to this), is what people bring to your operating room table
  - Meaning early life events, levels of emotional health, cognitive health, and everything else
- Sean doesn’t believe there is the perception of pain without a conscious brain
  - There’s all sorts of nuances to that

- From an evolutionary perspective, pain and pleasure have been the driving factors that have been the engine of natural selection
- But clearly those things have had to work in pre-conscious models

**That means that whatever we’re defining as pain did not include a perception of pain. What does that mean?**

- That’s where it gets muddy and there’s smarter people than Sean that would probably be more articulate, but this is why he thinks on first principles, you have to define the thing that you’re talking about
- When we typically talk about pain, we’re talking about it from a uniquely human standpoint
- Does a dog experience pain?
  - Sean is a dog person, and dogs experience pain
- You move down the evolutionary [tree], at what point [does a creature not experience pain]?
- Goldfish clearly experience nociception
  - They clearly have all the classic withdrawal protection survival aspects of it
  - But at what level is there a conscious brain that is translating it?

**⇒** On top of it, remember in our human definition of pain: it’s an unpleasant sensory and emotional experience

- Does a goldfish experience emotions?
- You see how muddy it gets
- This is why Sean tends to say with humans, which is muddy enough

## The four types of pain [22:00]

**How does everything you just said differ or overlap with neuropathic pain (or that sort of burning pain)?**

*Is it simply a subset of this?*

*Are there various different types of pain that don’t have a clear cause/effect relation to tissue damage?*

- We have different ways of categorizing pain, putting it into different buckets

1 – Nociceptive pain

- You’ll note that that word nociceptive sounds very similar to [nociceptors](https://en.wikipedia.org/wiki/Nociceptor), and it’s by design
- It means that it is pain caused by activation of primary nociceptors, whether it be in your skin or soft tissues or in our viscera
- It tends to have certain qualities
  - It’s very easy to localize; you know exactly where it is
  - It has a certain intensity
  - That nociceptive pain tends to be time limited
- It responds well to short-term use of analgesic agents: acetaminophen, NSAIDs, COX-2 inhibitors, opioids
- And it tends to go away

***This is the kind of pain that occurs after typically acute injuries***

2 – Visceral pain

- This is due to activation of those primary nociceptors in our viscera

**⇒** The difference in why we bring the distinction with visceral pain that is either in our thoracic viscera or abdominal or pelvic viscera, is that the receptive fields (that means where those nociceptors serve and what we perceive) are very diffuse and wide

- When you get a stomach ache, you can’t put your finger exactly where it hurts
  - You tend to put your whole hand over it and say, it hurts here (it’s diffuse)
- That’s because the spinal cord and the brain have these diffuse receptive fields which expand the area

**⇒** The [viscera](https://en.wikipedia.org/wiki/Organ_(biology)#Viscera) don’t typically respond to the same type of stimuli that nociceptive pain does

- You’ll remember when you were taking a bovey to the bowel, the small intestine patients wouldn’t normally move because the nociceptors don’t respond to that
- But if you tug on it, if you pull that, or inflate it → blood pressure goes up, heart rate goes up
- Interesting characteristics with visceral pain is there’s something called **viscerosomatic convergence**, meaning that the afferents (the information coming in from the gut), from the thorax converge with the same sensory systems from the rest of our different parts of our body
- Remember the old medical school adage, “*C, 3, 4, 5 keeps the diaphragm alive*”
  - That means that the third, fourth, and fifth cervical nerve roots subserve our diaphragm, which help us breathe
- When the general surgeons or others are operating and they get blood under the diaphragm, it irritates the diaphragm, and what patients will typically complain of is shoulder pain because the shoulder is subserved by the fourth and fifth cervical area
  - When they had shoulder pain, the answer wasn’t something’s wrong with their shoulder, it’s they had some irritation of blood under there
  - It’s why when people have a heart attack, pain radiates out into the arm because you’ve got the upper thoracic nerves subserving the heart that overlap with the nerves that go down your arm and the nervous system gets confused, and that’s how it’s expressed
  - If you like the neurosciences, it’s all pretty cool; if you’re experiencing it, not so cool

Peter asks, “*On visceral pain, what is their response to treatments with respect to the way we saw in nociceptive pain (where [there is a] great response to these NSAIDs or opioids or whatever)?*”

- Typical analgesics can be helpful, but identifying visceral specific anti-nociceptive drugs is still an area of hot research

***These days it’s more about trying to identify the causes of visceral pain and reducing substances that are winding those nociceptors up***

3 – Neuropathic pain

- Neuropathic pain means injury to either the peripheral or the central nervous system
  - The nerve’s out in the body or the nervous system in your spinal cord in your brain
- It’s either injury or dysfunction too
- Classic [cause]: you get nerve injury from a trauma from surgery

**⇒** Classic qualities people describe burning, sharp, lancinating, stabbing, shock-like

- This is the kind of pain that some people tragically get after a thalamic stroke in their brain
  - Half their body’s just like terrible burning pain and there’s nothing going on out here
  - It’s all central
- This is the kind of pain that you get and you experienced with **radicular pain**
  - Radicular pain means, in this case, injury to a nerve root coming out of your spine
  - It’s this sharp radiating pain, if you’ve got it in your lower back, that radiates down your leg, typically below your knee into your foot

**⇒** This can be very challenging to treat with common analgesics

- We tend to draw upon different categories of medications for this: broadly speaking, anti-neuropathic pain drugs
- In this field, we steal from everybody
- There’s only a few FDA-approved medications for pain
- What we’ve learned to do is to borrow drugs from the neurologists, their anti-convulsants, their anti-seizure medications: the [gabapentinoids](https://en.wikipedia.org/wiki/Gabapentinoid), the [Tegretols](https://en.wikipedia.org/wiki/Carbamazepine), and their derivatives
- Anti-seizure medications because they tend to have mechanisms of action that also work on nerve pain
- [Gabapentin](https://en.wikipedia.org/wiki/Gabapentin): turns out it’s lousy, anti-seizure drug, terrible, but it’s a pretty good anti-nerve pain drug
  - 4 g a day
  - Peter’s had some experience with it
  - Makes you drowsy
  - Sean gives credit to [George Clooney](https://en.wikipedia.org/wiki/George_Clooney) (in the TV series [ER](https://en.wikipedia.org/wiki/ER_(TV_series))) for making gabapentin the blockbuster drug
    - A kid comes to the ER with a skateboarding injury, and George Clooney puts the kid on gabapentin
  - That all started from a case report from a couple of ED docs who had noted by putting people on gabapentin that their acute pain got better
  - It’s a very safe medication

As he talks about medications and treatments, Sean points out, “*I have zero industry relations with anybody. Nobody. I don’t take any industry money. You can go look me up on* [*Open Payments CMS*](https://openpaymentsdata.cms.gov/) *(which is a public database)*.”

4 – Nociplastic pain

- This is a newly introduced category of pain, which is thought to represent dysfunction in the central pain processing system
  - Sean is not precisely defining it, but that’s the gist of it
- It means that in the absence of an identifiable peripheral cause, there is dysfunction in the brain, in the spinal cord that is causing pain ‒ perpetuating and amplifying pain

**⇒** [Nociplastic pain](https://en.wikipedia.org/wiki/Nociplastic_pain) has been tied in with conditions like fibromyalgia, temporomandibular disorders, some aspects of chronic low back pain, irritable bowel syndrome, interstitial cystitis, and more

- It’s slowly starting to get traction

> “*When we talk about pain, both to study it, but also ideally to treat it, we put them in these categories that we just described.*”‒ Sean Mackey

- Peter thinks nociplastic pain must be a huge bucket because it’s everything for which we don’t understand
  - It’s sort of the all else bucket, which is enormous, especially for chronic pain

The question is (and the verdict is still out)

- Does nociplastic pain stick around?
- Or is the problem that in these conditions that we associate with nociplastic pain, medical science hasn’t caught up to identify a specific peripheral driver?
  - Sean thinks this is the answer
  - He thinks we’re going to find peripheral drivers for fibromyalgia
- There’s some controversy right now as to whether fibromyalgia represents a small fiber neuropathy, and just because we may not be able to identify a lesion doesn’t mean that there’s not something there

## Using fMRI to identify objective biomarkers of pain in the brain [31:30]

**There’s no objective way to measure pain, correct?**

- Sean has spent the last 15 years of his career on this topic, and we’re much further along that he ever would’ve predicted

A large chunk of his research early on was in neuroimaging and pain

- It was opening up windows into the brain to see where people were thinking, processing, perceiving, magnifying pain
- Sean has published work to understand the mechanisms of that
- Over the years, Sean migrated into the space of developing objective biomarkers of pain
- That’s why he loves working with young smart people
  - He bets against it
  - He had some young grad students and others who said that they thought they could do this
  - Sean told them how you would do it, and said, “*It won’t work. And I’m going to pay you*.”
  - He gave them money to go scan people, expecting them to learn how it doesn’t work because failure’s a great lesson in life
- They came back and they showed they could do it

**⇒** It was all through developing patterns in the brain and using machine learning models to then take that pattern, that signature, and predict in other people whether they were experiencing pain

- Sean didn’t think we could do that because of the hugely individual nature of pain (it’s so different from person to person)

***It turns out that there are core patterns in the brain that represent that experience of pain***

**How are you capturing those brain patterns?**

- Functional magnetic resonance imaging ([fMRI](https://en.wikipedia.org/wiki/Functional_magnetic_resonance_imaging))
- It is a standard MRI that people go into, but we do some fancy pulse sequences
- We play some physics tricks where we can see where nerves, the brain’s being activated

**⇒** Sean and others have taken this from being able to determine whether somebody is in a state of pain to predicting their long-term trajectory

Sean adds, “*We’re working right now to create composite multimodal biomarkers to predict their future state. We’re getting there*.”

**Imaging pain with fMRI**

- If you put me into an fMRI machine and I said to you, “*Hey guys, I’m not feeling any pain right now. I feel great.*” And then you scan me, and then someone came out and took a hammer to my thumb and I went through the classic response that you described earlier

Peter asks, “*What would my fMRI show?*”

- You’d see rather dramatic increases in activity in brain regions such as the [thalamus](https://en.wikipedia.org/wiki/Thalamus), the posterior [insular cortex](https://en.wikipedia.org/wiki/Insular_cortex), the anterior [cingulate cortex](https://en.wikipedia.org/wiki/Cingulate_cortex) to the dorsal anterior [cingulate cortex](https://en.wikipedia.org/wiki/Cingulate_cortex), and a number of other areas (including S1)

Peter asks, “*This is distinct from the part of my cortex that is the homunculus for my thumb?*”

- You’re right
- What we’ve learned through this: ***there’s no one single pain region in the brain***
- That’s another mistake that was made along the way
  - We all thought we were going to find a brain region, then we can knock it out
  - And it turns out that didn’t work

> “*It’s not one brain region that generates the experience of pain. It is a distributed network. It’s all of these regions coming together and working in harmony.*”‒ Sean Mackey

- All of the regions come together and work in harmony to generate the experience of pain and then typically generate a response to that
  - [discussed in this [commentary](https://www.jpain.org/article/S1526-5900(13)00004-7/fulltext) and [review](https://pmc.ncbi.nlm.nih.gov/articles/PMC10850311/)]
- There was a lot of controversy when Sean and others initially published this
- We are not trying to take away the autonomy of the patient and the self-report
  - We don’t need an fMRI to see a patient and know if they have pain
  - We can just ask them and use self-report measures to get it

**Another part of Sean’s research is working to build objective markers of pain**

**⇒** This objectifying pain is not to see what they’re in now, but can it give us useful information to predict treatment to a particular therapy?

- Can we use it to predict their future state?
- Can we use it to predict their vulnerability to an injury or surgery?
- Those are things that just asking a patient right now, you’re probably not going to get there

## The evolutionary role of pain in human behavior and survival [36:00]

**Back to nociceptive pain**

- Tissue injury occurs, 2 signals come up the C fiber and the Aδ fiber
- The immediate response is to get you out of pain
  - There’s an evolutionary logic to that
- The C fiber is not there to get you out of pain, because the Aδ did that

Peter asks, “*Is the C fiber there to remind you not to go back and do that again?*”

- That is basically your longer-term harm alarm saying don’t go back and do that again
  - Back in the cave people days, it would remind you, maybe it’s best to sit in the cave and let the healing occur instead of going out and fighting the woolly mammoth or the saber-toothed tiger
  - Because if you fought the saber-toothed tiger when you’re injured, you got eaten
    - You didn’t get to pass your genes along

Peter asks, “*Do we have any evidence, Sean, that there was enough genetic heterogeneity around this, that 200,000 years ago, there were members of our tribe who simply didn’t feel pain, and therefore did not pass on their genes because they made poor decisions?*”

- Great question
- Sean doesn’t know
- There was undoubtedly genetic variations that led to behaviors, led to actions that did not promote survival of the species
- And nature takes care of that: those people died out

**Peter finds it amazing to dream about how little convergence must have existed a quarter of a million years ago**

- In terms of things that ended up not being good for our species
- Like people who didn’t experience pain the same way
- Or didn’t have certain filters within themselves
- There have been lots of talk about people who couldn’t socialize ‒  you couldn’t evolve alone
- So if you didn’t have the right set of genes that allowed you to at least be part of some sort of social tribe
- We still probably have people today that have escaped
  - We clearly have some antisocial folks among us, but they’re the exception and not the rule

*Peter wonders if today we’re much more homogeneous in terms of what a human’s response to pain is versus what it might’ve been?*

- Probably
- When you go back through some of the lower animal species, what happens when one of those animals gets injured in the wild?
  - Sean is not an animal pain expert, but typically they’re set off, they’re ostracized
  - **Those animals just die out**

**What do people do?**

- We come together as a community and we help those people
- We developed empathy for pain, and that has gotten hardwired into our brains, to be able to recognize when people are in distress and pain, and to reach out and help them
  - That was clearly beneficial to our species and conserved
  - Sean did some studies on that [published in [2008](https://pubmed.ncbi.nlm.nih.gov/19015105/) and [2020](https://pubmed.ncbi.nlm.nih.gov/32733343/)]

Childbirth prior to any anesthetic was obviously brutal, both in terms of pain and mortality

- Yet there’s no evidence people were deciding not to do this
- The drive for procreation somehow overcame what must have been brutal
- Hat’s off to half the population that are women
- Sean suggests that some of the [estrogens](https://en.wikipedia.org/wiki/Estrogen) (estradiols) have an analgesic effect, and women don’t seem to remember how painful it was because they do it again

Peter jokes that he still doesn’t understand how our species is here for 2 reasons

- Women continue to go back to the well
- Remember, if your reproduction rate isn’t >2, the species would’ve collapsed
- So on average, every woman must be able to do this
- Back then, the reproduction rate had to be north of 3

Peter adds, “*How she did it the second two times, after how bad the first was, blows my mind*.”

- The second thing is, look at how stupid adolescent males are
- Peter doesn’t understand why males all didn’t die just from doing stupid, stupid things before the age of 20 (or even before the age of 15)

Sean repeatedly tells Beth, “*I sometimes wonder why I was not a* [*Darwin Award*](https://darwinawards.com/) *winner*.”

## How the brain processes and modulates pain signals, Gate Control Theory, the variability in individuals’ pain perception, and effectiveness of neuromodulation techniques like TENS [41:00]

**We have these signals of pain from the spinal cord**

- Those Aδ and C fibers
- In the spinal cord, there’s a lot of processing going on (he’ll come back to this), and the signals head up to the brain
- Then they synapse connect in a large number of brain regions

*To grossly oversimplify things*

- One of the main one is the [thalamus](https://en.wikipedia.org/wiki/Thalamus), which acts like grand central station in the brain
- It’s taking lots of sensory input from different sources and it’s sending it out to other areas
- Each of these brain regions has some functions associated with it

He alluded to the anterior [cingulate cortex](https://en.wikipedia.org/wiki/Cingulate_cortex) earlier

- It is associated with some of the **emotional aspects of pain** or the unpleasantness of it
- The anterior cingulate cortex is also a **salience detector**
  - Meaning it is taking those incoming inputs and it’s determining: Is there something wrong here? Is there an error?
- Because, in essence, our brains are prediction machines
- Everything that we’re doing, we’re forming an expected pattern of what we’re going to sense and we’re making adjustments
- Sean explains, “*When I reach out for my cup, I know where it is in space, I pick it up. If instead of cold water in that, it’s boiling hot water and I touch it, my brain is getting different signals than it was expecting.*”
- That cingulate cortex, as a salience detector, is triggering, and it’s putting into action for me to withdraw
- Other areas of the brain include the [insular cortex](https://en.wikipedia.org/wiki/Insular_cortex), which lies on this little bit of the outer edge
  - It can be subdivided into multiple components
  - The posterior, mid, and anterior insula

**⇒** Let’s just say that the back part of it is taking direct information in from the body, but then as you get more and more towards the front of the insula, it’s integrating emotional and cognitive nuance to it

- It is integrating in your emotional state and what you’re thinking

There are also connections with your [amygdala](https://en.wikipedia.org/wiki/Amygdala)

- This deep primitive region of the brain involved with both **threat detection** as well as **reward**, and it’s connected into the circuit
  - It also has outlays into other areas like the [hippocampus](https://en.wikipedia.org/wiki/Hippocampus) and the **stress response** and onward

***All that to say is, all these regions connected together generate that experience of pain***

- At this point in time, Sean really hasn’t done more than Rene Descartes has in telling this story, because first pass, the brain is still remaining a passive receptacle just taking these inputs

**Where it gets interesting is we developed descending control systems that come down from the brain that converge in the spinal cord**

- What they serve to do is turn down the signals that are heading up
- This was first described by [Ron Melzack](https://en.wikipedia.org/wiki/Ronald_Melzack) and [Patrick Wall](https://en.wikipedia.org/wiki/Patrick_D._Wall) (around 1965): the [Gate Control Theory of Pain](https://en.wikipedia.org/wiki/Gate_control_theory) (brilliant guys)

**⇒** This Gate Control Theory of Pain posits that yes, you have afferent information coming in to the spinal cord, but the spinal cord is acting like a gate of opening and closing, turning up (turning down pain), and it is altered by other fibers and systems from your brain

**Another nerve fiber type: A-beta (Aꞵ)**

- [Aꞵ](https://en.wikipedia.org/wiki/Group_A_nerve_fiber) fibers are your touch fibers
- When you touch or stroke your skin, those get activated
- When you stand up and you stand on one leg, they’re also responsible for position sense
- They have a heavy coat of insulation around them and they are wicked fast

Information travels fast

- 1 meter per second on the C fibers
- 10 m/s on the Aδ fibers
- 100 m/s on the Aꞵ fibers
  - That’s why you can dance
  - That’s why you can walk, because you’ve got those fast reacting Aꞵ fibers

**Reducing pain with neuromodulation, and more about the TENS unit**

*Let’s say that you just hit your thumb with a hammer…*

- Sharp jolt of pain goes to your brain
- Got a little delay, “*Oh, damn, this is really going to hurt*.”
- Hot burning flooding sensation comes over your thumb
- What is the next thing that you do?
  - Everybody does this a little differently
- A lot of people swear
- Then shake it or squeeze or sometimes run it under water (trying to create a distraction)
  - Sometimes its a distraction
  - Illogically trying to keep whatever humor is in there that’s hurting isolated like a tourniquet
  - Put cold on it hoping to anesthetize the area, presumably slow the circulation and take down the swelling (longer-term things that cold does)
- Cold also reduces action potential velocities and firing in those Aδ C fibers

⇒ But what you’re doing, most of all, when you rub it is you’re activating Aꞵ fibers

- You’re actually not influencing much your Aδ or C fibers, those nociceptive fibers
  - That horse has left the barn
- Where things get interesting is, the Aꞵ fibers (those touch fibers), they’re coming into a slightly different area of your spinal cord, and they’re sending over projections into where those nociceptive fibers are in your spinal cord
- They have an inhibitory role

***The Aꞵ fibers are inhibiting the signals coming in from where you hit your thumb with a hammer and preventing them from going to your brain. It’s a beautiful example of neuromodulation***

- And we’re all hardwired to do that thing

**There’s a medical device that takes advantage of that: you’re familiar with the TENS unit?**

- [TENS is Transcutaneous Electrical Neural Stimulation](https://en.wikipedia.org/wiki/Transcutaneous_electrical_nerve_stimulation)
- What it originally did (there’s been modifications of it): typically little black pads that you put over the area that hurts, you put an electrical stimulation through these pads, they’re activating Aꞵ fibers
- It’s having a neuromodulatory effect back in the spinal cord
- Pretty cool when it works

Peter asks, “*A patient comes to you and they’re experiencing some pain, what are the clues that tell you, ‘I think TENS is going to be successful here?’*”

- In other words, when will activating Aꞵ fibers be a tool to reduce the perception of pain
  - It doesn’t necessarily take away the pain
- The job of a pain doc is to help reduce the pain and help them down a path of functional rehabilitation
- So absent that second piece, it typically fails
- Docs are leading them down a road of functional rehabilitation
  - Which involves physical, psychological, social, emotional health ‒ all the things Peter beautifully talked about in [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0)

**⇒** The patient for whom TENS works: somebody with nociceptive musculoskeletal pain

- Beyond that, it’s trial and error

> “*That’s part of the frustration in pain management, and in healthcare in general, is the lack of a precision approach, and the very frustrating, laborious trial and error process until we get something that works*.”‒ Sean Mackey

**Peter’s summary of gate control**

- The idea is that 10 people could experience the exact same peripheral injury
  - If you could map the action potentials, they would look identical
- You could even see identical perceptions, but they could have 10 different gating channels within the spinal cord and therefore perceive pain differently
- This is the individual variability in pain
- They haven’t talked about the brain’s role in gate control, but will soon

**Kim did elegant** [**studies**](https://pubmed.ncbi.nlm.nih.gov/15157710/) **years ago**

- He applied a 48-degrees Celsius stimulus to 500 people [it was actually 49o C or 120o F]
- You apply it to the arm or the hand and then ask, “*What’s your pain score?*”

He found a perfect distribution from, “*Nah, this ain’t nothing,*” all the way up to “*Oh my God, you’re burning me.*” [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/04/f2-seanmackey.png)

**Figure 2. Pain intensity reported after exposure to 49****o** **C**. Image credit: [*Pain* 2004](https://pubmed.ncbi.nlm.nih.gov/15157710/)

- Sean does the same thing in a medical school demonstration when he teaches a neuroscience class around pain
  - He brings in a circulating ice water bath and asks them to dip their arm in for 15 seconds
  - Then, pull it out and whisper in our research assistant’s ear what their pain score was
  - We tabulate that all up and at the end of the class and show the medical students [Sean shared the figure below by email]
  - You got some people in the class who say, “*I could keep my hand in there all day*.”

And there were others who were like, “*Oh my God, I couldn’t even keep it in there at all (10 out of 10)*.”

![](https://peterattiamd.com/wp-content/uploads/2025/04/f3-seanmackey.png)

**Figure 3. Pain intensity reported after exposure to ice water**. Image credit: Sean Mackey

***The whole point of that is to drive home one of the key messages in our discussion: the amount of stimulus or nociception may have little to nothing to do with your experience of pain***

- This is so important for healthcare professionals to understand is because for so long we have projected our own experiences onto everybody else

*Peter suggests how to take this experiment one step further*

- Do the same thing every day and see how the score compares day to day
- Peter loves to use a cold plunge set at 42 degrees with circulating water
  - It feels like it’s somewhere in the 30s
- There are days when he can spend 10 minutes in there and it feels like nothing is wrong
- There are days when after 30 seconds, his ankles hurt so bad he wants to scream

What’s the difference?

- It can’t be that the circulation in his ankles is better one day to the next
- On one day, he knows he’s cold but his joints don’t hurt
- On another day, the throbbing in his joints feels like somebody’s hitting them with a hammer
- He’s the same person

***Sean’s point is well taken, there’s a second dimension to it, even as individuals, we can experience things differently from day to day***

## The brain’s influence on pain: the role of emotion, beliefs, sleep, and individual differences in perception and tolerance [53:45]

**Building on that and introducing more of the brain**

- Sean mentioned earlier the functions of the brain
  - The [cingulate cortex](https://en.wikipedia.org/wiki/Cingulate_cortex) being some of the more emotional, as primary somatosensory cortex
  - The [homunculus](https://en.wikipedia.org/wiki/Homunculus) being more sensory
  - The [insular cortex](https://en.wikipedia.org/wiki/Insular_cortex) has an introspective state
    - It’s like our internal awareness of our bodily state
  - The [amygdala](https://en.wikipedia.org/wiki/Amygdala)
- The [prefrontal cortex](https://en.wikipedia.org/wiki/Prefrontal_cortex) is the big thinking part of our brain
  - Both the [ventral medial](https://en.wikipedia.org/wiki/Ventromedial_prefrontal_cortex) and the [dorsolateral](https://en.wikipedia.org/wiki/Dorsolateral_prefrontal_cortex), play a key role in our modulation, our cognitive control of pain

**⇒** These systems (the prefrontal cortex, the insular cortex, the cingulate cortex) all have descending projections back down to the spinal cord

- Earlier, Sean talked about the Gate Control Theory of Pain in the context of rubbing your finger, a peripheral neuromodulation
- Where it really comes into play is when you introduce brain systems: the brain, and your emotions, your cognitions, your beliefs, your early history; and that influence on pain
- That’s where it gets really exciting
- That’s sending descending pathways down

***Sean would argue, in part, that Peter’s experience of cold water in that moment may have been driven in large part by his mental state before he got in***

- Maybe we will talk more about the intersection of sleep and pain (huge research in that space)

Other things that influence the intensity of pain

- Your state of anxiety apprehension around this
- All sorts of cognitive emotional aspects weigh into your experience of pain
- There’s also circadian rhythm aspects related to this, from hour to hour fluctuations
- Those individual differences are fascinating
- That is also an area that Sean’s group and others are going into

***Recognizing that one pain score averaged over a week may not give us a lot of information, that we need to take into account the within subject, within person, daily variations over time, and model that***

Peter asks, “*Is there kind of a moral judgment that comes to this at some level?*”

- Don’t we as a society just tend to look more favorably at people that have a very high pain tolerance?
- So when you go through that experiment you just did with the medical students, if everybody’s being brutally honest, aren’t they kind of looking at the people who score 0, 1, 2 more favorably than those that score 8, 9, and 10?
- Absolutely
- That’s what society values
- Sean came from a very working class family and growing up, that’s what his father expected
  - His father had 12 brothers and sisters fighting for whatever scraps of food
  - You just suck it up and deal with it
- Sean’s father had back pain later in life, and he would never talk about it
  - Never ask Sean’s opinion
  - And when Sean offered his opinion, he would never follow it
  - It had bad consequences in the end, but we value that (that is the way our society is)

Peter asks, “*Is that a male thing exclusively?*”

- Sean thinks it crosses
- There is a masculinity aspect of that
  - And it’s also attractive for women
  - There’s a certain attractiveness because that person may be more likely to be a good provider than somebody who is weak and sensitive
- This is a little outside of Sean’s wheelhouse

Peter thinks it’s a compatibility thing

- When he does that type of an exercise, compared to others, he tends to feel less pain
- He knows his wife does as well
- He wonders if that is a compatibility
- They both have a high threshold for that when they’re exercising
- Sean’s fiancee is a professor at Stanford ([Beth Darnall](https://profiles.stanford.edu/beth-darnall)) and she’s an ex-ultra marathon runner
- He’s always admired the fact that she can sit there in front of a computer or work on something, untold hours and not move
- She’s just like, “*Listen, I was really good with running with a pebble in my shoe, putting one foot after another and just working my way through it*.”
- Sean similarly grew up in an environment where you learn to be tough and you learn to power through life’s adversities

**What is the consequence of this?**

- We’re acknowledging that it is an attractive trait to have a high tolerance of pain
- Society rewards it
- And yet, by definition, a significant subset of the population (call it a third, call it a quarter, if it’s a normally distributed function) are going to be a standard deviation on the other side
  - These are people who are going to really perceive pain

***Looking at this through the lens of the responsibility of the medical community, there’s a pretty significant consequence to that***

It gets a little bit more nuanced ‒ consider cold sensitivities

- Some of the sensitivities are modality specific

Peter asks, “*Just because you have a high threshold for cold, you could completely flip it on hot, or pressure, or pinprick, or whatever the other modality is?*”

- As somebody who runs a pain lab, Sean has had everything done to him imaginable
- He takes heat really well
- His son Ian, takes heat really well
- Sean has had thermal devices on him and ended up with second degree burns to find his 7 out of 10
- But he hates the cold (he’s a wuss)
- Sean thinks there’s a genetic aspect to this

***On top of modality specific pain, these experimental protocols probably have little bearing on somebody’s experience of chronic pain***

**Is there any way to put together a set of experimental lab versions of this to basically generate predictive models of how people will respond to real world pain?**

*Peter thinks this would be relevant to chronic pain*

- For example, when some people have a disc herniation that leads to manageable pain, whereas for others, the exact same injury by every metric available to us produces a totally different set of consequences

*What do we do about that?*

- This is where we move out of that Descartesian model
- We appreciate the role of the brain in its modulatory capacity, its ability to turn the amplifier down

Analogy: think about a stereo amplifier

- Sean talked earlier about how some people, to a certain stimulus, might be a 0 or 1 on the dial, some might be a 10
- What he didn’t talk about are **people’s capacity to now manage their pain**, cope with their pain, their level of self-efficacy around their pain
- Athletes learn how to manage their pain and suffering
- Where they run into problems is when the sports are over, and they’re retired

**There are many factors that predict how well somebody is going to do with chronic pain**

- They align with a lot of the stuff in Peter’s [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0)
- The level of a person self-efficacy plays a role
- There is the presence or absence of whether they’ve got underlying depression, anger, anxiety, something called **catastrophizing**
  - Terrible word, very important concept
  - Probably one of the most predictive of amplified pain

**⇒** One of the biggest predictors of **diabetic neuropathic pain** is glucose control

- When Sean treats a person with diabetic neuropathy
- High blood sugar causes injury to nociceptive fibers and also the Aꞵ inhibitory fibers
- That correlates with glucose control

*Other factors that amplify pain*

- Diet plays a role, because if you’re eating things that are causing **inflammation**… we didn’t talk about all of the stuff that amplifies or winds up those peripheral nociceptors
  - We treated those as a static thing when they’re not (they’re dynamic)
- In the face of inflammation, that causes something called **peripheral sensitization**
  - You’ve turned up the amplifier on that nociceptor in the periphery
- **Sleep** is a huge topic

Peter asks, “*How much sleep deprivation does one need for there to be an increase in pain perception?*”

- After pulling an all nighter in residency, you feel awful the next day
  - Worst between 5 AM and 8 AM, then you get this second wind and then you usually feel pretty good
  - Overall though, it’s a haze and you’re just powering your way through it
  - You’re achy all over
    - It’s not because lack of sleep has changed something in your muscles

**⇒** What has changed is your set point in your brain and your spinal cord for the perception of pain (you feel like crap)

*Imagine if you’re doing that day, after day, after day and not getting sleep*

- That really messes up your central nervous system and that modulation around pain

***What happens is lack of sleep changes your set point and it impairs that prefrontal cortex and its ability to modulate pain***

- When Peter went through his bad episode of back pain, how did it impact sleep?
  - That impact on sleep ultimately further amplified his pain
- On top of it, how did you feel during that?
- And outside the pain, how was that affecting your overall life, and your thoughts, and your emotions?
  - Total disaster

## Peter’s personal journey with chronic back pain, and how the emotional consequences of pain can be more distressing than the pain itself [1:04:30]

- [Peter shared this story in [episode #287](https://peterattiamd.com/stuartmcgill/) on back pain with Stuart McGill]
- When he was a 3rd year medical student, he was having a great day, rode his bike to the gym and got off his bike to go in when he felt a pain in his back like he’s never felt before
- It was enough that he decided not to work out
  - Which says something, because he would’ve worked out through any amount of discomfort
- He limped home, laid down and tried to sleep it off
- The next day, he was in so much pain he couldn’t get out of bed
- He had to actually call his roommate (they had separate phones in the same house) to come and get me up and out of bed
- The next 2 weeks proceeded to be a really unbearable episode, where he was doing an ICU rotation
  - This is back in the wild west, where the nurses and the residents were just shooting him up with [Toradol](https://en.wikipedia.org/wiki/Ketorolac) every day, nonstop, getting him through the day
- The nights were brutal
  - It felt as though the skin on the bottom of his foot was being ripped off
  - The only way he could sleep was to put his foot into a bag of ice and take some amount of Banadryl to knock him out
- Peter now realizes what happened was he had a really significant herniation
  - He would later find out that a 5 cm piece of the L5-S disc broke off and it had extruded and was sitting on the S-1 nerve root
- This went on for another week until the Dean of Students saw him limping around and asked what was going on
  - This was a Sunday afternoon; Peter was studying
  - The dean took him to the ER where he got an MRI that showed all of this mess
- The next day Peter had surgery
- Everything went wrong in a series of surgeries
- Fast-forward 3 months, 3 trips to the operating room, multiple multiple discectomies, laminotomies, multiple levels
- In theory, his back should have been fine, but he was anything but fine

*He has a new pain, but this is unlike anything that was related to his back*

- This is where Sean comes in
- He now has a pain that is so significant
  - It sounds grotesque to explain it, but this is how it was: it felt like someone was reaching in his body from his kidneys, into his groin, and tearing his testicles out from the inside of my body
- Needless to say, he was out of commission
  - He did not move
  - He laid on a floor 24/7
- And to Sean’s point, how did he feel?
  - It wasn’t just that he was in so much pain that he couldn’t do anything
  - He watched his life disappear
  - It went from, you’re not going to graduate from medical school on time
    - To you’re not going to get to do an internship in surgery
    - To you’re not going to be a surgeon
    - To you’re never going to walk again
- The overlap was the opioids he was prescribed to control the pain tripped into, these are a tool to numb him to this entire experience
- He thinks he was up to 320 mg of [OxyContin](https://en.wikipedia.org/wiki/Oxycodone) a day
  - Which is kind of amazing, because if you took half of that today, you would die
  - He was mainlining 320 mg of OxyContin a day just to blunt the emotional pain of this
  - (He can come back to the story of how Peter met Sean and turned his life around)
- It’s still a miracle to Peter how he actually graduated from medical school on time
  - Despite all that happening from his 3rd to 4th year
  - 3rd year is tough

***The pain was unbearable, but at some point that wasn’t the most unbearable part ‒ it was the expectation of what that pain meant for the rest of his life that became much more unbearable***

- Peter calls it the best worst experience of his life
- He wouldn’t want to do it again, but it has been such a positive impact on his life (the gratitude he has)

## The pharmacology of common pain medications—NSAIDs, COX-2 inhibitors, and acetaminophen [1:09:30]

**How do NSAIDs work?**

- Everybody’s heard of [Advil](https://en.wikipedia.org/wiki/Advil), [Aleve (naproxen)](https://en.wikipedia.org/wiki/Naproxen)
- [NSAIDs](https://en.wikipedia.org/wiki/Nonsteroidal_anti-inflammatory_drug) are [cyclooxygenase [COX-2] inhibitors](https://en.wikipedia.org/wiki/Cyclooxygenase-2_inhibitor) and they do a couple of things

***They reduce inflammation (anti-inflammatory)***

- There are substances that can be released out in the periphery during injury that wind up that nociceptor and amplify it
  - [Prostaglandins](https://en.wikipedia.org/wiki/Prostaglandin), [histamines](https://en.wikipedia.org/wiki/Histamine), [cytokines](https://en.wikipedia.org/wiki/Cytokine), [interleukins](https://en.wikipedia.org/wiki/Interleukin), all of that, this inflammatory soup that occurs after every single surgery
- Every single injury that we experience, you get this inflammatory soup and it’s classically mediated by swelling, redness, temperature increases
- And [aspirin](https://en.wikipedia.org/wiki/Aspirin) and C[OX-2 inhibitor](https://en.wikipedia.org/wiki/Cyclooxygenase-2_inhibitor) NSAIDs do a nice job in reducing that inflammation

Medical science has been slowly shifting in its view of this

- We have historically thought that taking these medications for an acute injury, it knocks down that inflammation, and all is well and good
- Some of the data coming out in the orthopedic literature decades ago showed that people who were taking NSAIDs during total joint replacements were getting non-fusion of that joint to the bone (they were getting failures)
- More recently there’s been some question as to whether knocking down the inflammation is a good thing after all, that maybe that inflammation is part of the healing process, and that by giving an NSAID, aspirin, we’re delaying the natural healing effect and causing more problems
- Where’s the truth? This is tough
  - We don’t have the whole story yet on the NSAIDs
- Sean describes himself as “a gray guy,” meaning he doesn’t live in “black and white”
  - He appreciates that every medical field has their own lens that they look at in the world
  - We have to appreciate the complexity of the patient, meaning if it’s perhaps something minor and they can get by without the NSAID and it’s not going to change significantly their level of function, then maybe not taking it will improve healing
  - If the patient can’t get out of bed, they can’t go to work, but a naproxen helps them to do that thing so that they can engage with their family, with their friends, with work, well then heck yes, take the NSAID if it’s helping with that level of functional improvement

Peter asks, “*Now, are you talking about this through the lens of acute pain or only through the lens of chronic pain at this point?*”

- A little of both
- With **chronic pain**, we start to introduce all the **longer-term negative consequences** of this impact on blood pressure, your heart, impact on your kidneys
  - With long-term NSAIDs, particularly if you’re older
- In *Outlive,* Peter wrote about taking [Vioxx](https://en.wikipedia.org/wiki/Rofecoxib)
- Sean loved Vioxx
- Peter still remembers the day in December 2001 when the FDA came down and said no more Vioxx
  - He looked at his last bottle and was like, “*Oh God. No.*”
  - Sean stockpiled it
  - Peter wishes he did

Every field looks at the problem through their own lens

- Vioxx was a drug that was causing heart attacks
  - Peter clarifies, “*In the world’s most susceptible individuals at a relatively small absolute rate.*”
  - At the highest dose
- Peter has discussed this with [Eric Topol](https://www.scripps.edu/faculty/topol/) [[episode  #91](https://peterattiamd.com/erictopol/#:~:text=Topol%2C%20M.D.-,How%20Eric%20helped%20to%20elucidate%20the%20issues%20with%20Vioxx%20(and%20why%20he%20came%20to%20regret%20it)%20%5B30%3A00%5D,-What%20is%20Vioxx) after 30:00] what a mistake (a net negative) this [FDA decision] was
  - Peter explains, “*Merck’s is faulted. They should have been much more transparent about this. Put a black box label on it and we should all still have access to Vioxx.*”
- Sean agrees, instead they should have stopped using the 50 mg (use 25 mg) and don’t give it to susceptible people
- The baby got thrown out with the bath water on that one
- We all do this, we look at the world through our own particular field
- It’s like with the latest blood pressure guidelines, the cardiologists want it really low, but it screws up the kidneys
  - The cardiologists say, save the heart, screw the kidney
- Sean thinks Vioxx is a great drug, wishes it was still around

**Why do you think there hasn’t been any drug that’s come close to Vioxx?**

- [Celebrex](https://en.wikipedia.org/wiki/Celecoxib) is a joke
- Sean thinks [Bextra (generic valdecoxib)](https://en.wikipedia.org/wiki/Valdecoxib) was a little bit close
  - If he remembers correctly, it has a [Stevens-Johnson [syndrome]](https://en.wikipedia.org/wiki/Stevens%E2%80%93Johnson_syndrome) bad rash with terrible consequences
- Drug companies get scared of the lawsuits

**Sean’s recommended dose for NSAIDS**

- 800 mg ibuprofen, 3 times a day (would be 2,400 mg per day) for 1-2 weeks
- Make sure you have food in the stomach when you take it and fluids
- If you’re either older, you’ve got kidney issues, you’ve got GI issues, talk to your doc first
  - Don’t just go into this stuff blindly

Peter points out, “*It is interesting that we can buy acetaminophen and ibuprofen over the counter and yet they can cause a ton of damage if not taken correctly.*”

- Sean adds that the ER sees people with [acetaminophen (Tylenol)](https://en.wikipedia.org/wiki/Paracetamol) overdoses and it’s a cause of liver failure

**Do we understand how acetaminophen works?**

- When Peter last tried to understand it, there was no clue as to how it worked
- There’s minimally more information now
- Sean discloses that he hasn’t read up on this alot

***It has some*** [***COX-2***](https://en.wikipedia.org/wiki/Cyclooxygenase-2) ***impact [Sean misspoke when he said cyclooxygenase-1]; a lot of it is thought to be central***

- Sean saw some interesting side studies where it seems to have some impact in the brain around **emotional modulation**
  - There’s a degree of emotional blunting on acetaminophen
  - Whether it translates into a real world [effect] or if it’s just an experimental manipulation, he doesn’t know

Peter points out, “*There’s a nice synergy with acetaminophen and ibuprofen because [each has a] different mechanism of action, different organ systems are impacted, so you can take less of each when you combine them.*”

- Sean uses those in combination to get that synergy
  - The 1+1 is not 2, but 3

*How much Tylenol you can take per day*

- Historically we would say up to 4 grams a day
- More recently there’s been some push to try to reduce that to 2 grams a day
  - Clearly if you’ve got liver dysfunction, if you are drinking large amounts of alcohol, [take] less

**The combination of Advil and Tylenol is Peter’s go-to**

*Peter’s recent tooth pain*

- A year ago he had to get a crown put on a tooth that had an old filling that broke
- The crown was a little bit too high, and it’s remarkable how the teeth are at sensation
- It was the last tooth in front of his wisdom tooth
- Every time he took a bite, that one tooth was bearing the brunt of it
- His dentist ([Tony Pacheco](https://tonypdds.com/)) told Peter to come and and let him shave a little bit off
- But Peter didn’t have the time to go in for 2 months
  - He couldn’t spare 2 hours to go to the dentist even though he was willing to see Peter nights and weekends
- The pain got so bad that eventually he couldn’t chew on that side at all
- He was taking 400 of advil and 500 of Tylenol 3x a day

Sean asks, “*Does ibuprofen work better for you than naproxen?*”

- Peter doesn’t know, but the reason he prefers this combo is he can like up the dosing with acetaminophen
  - You take naproxen twice a day
- Peter also wanted something he could do [TID](https://www.rxlist.com/tid_on_prescription/definition.htm) instead of BID [3x a day instead of 2x a day]

**⇒** Sean finds a huge individual variability in the response to NSAIDs: naproxen works beautifully for him at 500 2x a day, ibuprofen is not so good (800 3x a day with food and water)

**Are there types of pains people should be thinking of where these things work especially well and other areas where that’s just not going to have much efficacy?**

- Sean doesn’t find it as effective in neuropathic pain
  - It might take a little bit of the edge off

*It works well for*

- Your nociceptive pain or your nociceptive inflammatory pain
- The kind of pain you’d see in a joint, those are your typical go-to
- Forms of back pain, particularly in acute situations, but also somewhat in chronic
- Sean gets a lot of patients that say, “*That didn’t do it for me*.”
  - But if you inquire and ask questions, you find maybe it knocked it off a little because in our game we’re trying to knock off pieces and pieces and pieces of their pain experience
- The issues with the different responses are very individually based and Sean thinks in part it has to do with a little bit of what we call [pharmacokinetics](https://en.wikipedia.org/wiki/Pharmacokinetics) (or where the drug is getting)
  - Different NSAIDs can permeate different tissues at different rates

**Peter’s takeaway** ‒ we should be empirical: try naproxen, try ibuprofen and figure out which one works (obviously, don’t take them together)

**Do you have a concern with people taking acetaminophen and consuming alcohol?**

*Do you tell people to refrain from alcohol when they’re taking Tylenol?*

- Conservatively, don’t do more than a drink a day
- Sean doesn’t know if that’s the right amount
- But if he tells them 1 drink, they’ll go do 2
  - They’re probably still okay with that
- He will look in their chart to make sure they’re not drinking 4 or 8 drinks a day (that could cause liver issues)
- Peter doesn’t drink much, maybe 4 drinks in a week (1 a day)
  - If he was taking Tylenol, he’s not going to drink even though he doesn’t have any evidence to suggest that refraining is necessary
- Sean thinks not drinking is probably the safest

## Muscle relaxants: benefits, drawbacks, and personalized strategies [1:20:30]

- One tool that has been a favorite of Peter’s is [baclofen](https://en.wikipedia.org/wiki/Baclofen)
  - It’s not a particularly potent muscle relaxant, but it seems to offer something really potent
  - Like [Valium](https://en.wikipedia.org/wiki/Diazepam) doesn’t bring all the baggage of a [Benzo](https://en.wikipedia.org/wiki/Benzodiazepine) (or even a [Flexeril](https://en.wikipedia.org/wiki/Cyclobenzaprine) where you can get the drowsiness and even nauseous)
  - Something about Baclofen at 20 mg twice a day, it actually takes the edge off
- Where Peter finds this beneficial is if he slept wrong and got a kink in his trap
  - Or he’s been on a super long drive and his QLs flare a little bit
    - He knows if he had all the time in the world, he could go and stretch his way out of that
    - But sometimes he doesn’t have that time and needs to get right back to doing something awful, like sitting

Peter explains, “*Two or three days of 20 milligrams of Baclofen* [*BID*](https://www.rxlist.com/tid_on_prescription/definition.htm#:~:text=b.i.d.%20(or%20bid%20or%20BID)%20is%20two%20times%20a%20day) *with a little NSAID and I’m as good as new and I save myself the real flare up*.”

**What is your experience with muscle relaxants?**

- Peter’s example is a beautiful case example of how Sean would use those

***Baclofen is one of the safest to use***

- Baclofen is not habit-forming like the [Somas](https://en.wikipedia.org/wiki/Carisoprodol) and others that can be like a [barbiturate](https://en.wikipedia.org/wiki/Barbiturate) can act and people can get highly psychologically dependent on them
- The [Flexerils](https://en.wikipedia.org/wiki/Cyclobenzaprine) have a tricyclic antidepressant property about them that may sometimes be helpful for people in various mixed pain states, but also can cause sedation
- Baclofen seems to be pretty benign

**⇒** Sean doesn’t typically use muscle relaxants for long-term chronic conditions

- The data hasn’t born [that] out

Peter asks, “*How many days are you comfortable with a person [taking baclofen]?*

- Sean is comfortable with a person being on baclofen all their life
- Everything he’s doing is taken in the context of the person in front of him: the cost and benefit of the treatments he’s providing them

**⇒** The costs with baclofen (not monetary cost) are sedation

- This depends on the individual and the dose
- The higher the doses, the more sedation
- Baclofen can be used intrathecally (in an [intrathecal pump](https://en.wikipedia.org/wiki/Intrathecal_pump))
  - This is a beautiful life-saving minimal surgery that we do for people with a spinal cord injury
  - [It’s used to treat] intractable spasticity because to get the spasms under control with oral doses, you just can’t get there, so we thread a little catheter into the CSF and we deliver baclofen that way
- Again, it’s is a clean, relatively safe medication, but Sean is always evaluating long-term [effects]
  - Is this person getting benefit from this?
  - Should we be talking about dialing it back and trying to wean?
  - And if they’re not getting benefit, then why should they stay on the medication?
- Sean uses it
  - Use it in acute, subacute
  - Use it in some chronic conditions as a trial
    - What’s a trial? 1-2 months, and then we monitor data on every single person

Peter asks, “*What dose are you comfortable up to, 20 milligrams three times a day?*”

- Yeah, up to 80 mg at the upper end (he usually doesn’t get there)

**Back to Peter’s recovery from a back injury**

- Earlier Sean alluded to [Neurontin](https://en.wikipedia.org/wiki/Gabapentin), that it played a role in Peter’s recovery once the big stuff was out of the way
- Peter still had a couple of years of peripheral nerve injury, and the only way to put the fire out in his foot was Neurontin
- Unfortunately initially it required 4 grams a day (1 g 4x a day)
- The good news is it worked
- The bad news is you’re pretty much always tired
  - So he was very happy over time to get that dose down and within 18 months he was completely off the Neurontin
- After that he didn’t have pain in his foot except maybe once a year he gets an enormous surge of fire into that same foot
  - Literally one shot of flame that lasts seconds and it’s gone, but essentially never again

**You alluded to other drugs like antidepressants as well in addition to a rather impotent anti-seizure med, but what else do you have at your disposal for this type of pain?**

*Is Neurontin still a very powerful tool in the use of neuropathic pain?*

- The beauty of [Neurontin (generic name gabapentin)](https://en.wikipedia.org/wiki/Pregabalin) and its cousin [pregabalin](https://en.wikipedia.org/wiki/Pregabalin) (both have the same [mechanism of action](https://en.wikipedia.org/wiki/Gabapentin#Pharmacology)) ‒ they work on the [α2δ-1 subunit of a calcium channel](https://en.wikipedia.org/wiki/Voltage-gated_calcium_channel#.CE.B12.CE.B4_Subunit) in the spinal cord and the brain
  - Pregabalin was introduced immediately after gabapentin’s patent ran out

***Think of them as agents that turn down the signals that are in the spinal cord being processed and in the brain, so they’re really not impacting your nerve out here or in your leg***

- They can be very effective
- The beauty of these 2 drugs is there’s no lethal dose
  - The only way they could kill the rats when they were studying it was to drown them in it
  - Sean would joke with patients, “*The only way you can be hurt taking this drug is if you’re struck by a truck that’s carrying it*.”
- It’s a little bit more nuanced than that because there are **side effects**: you can fall asleep while driving
  - Don’t operate heavy machinery
  - Don’t go dune buggy riding
  - Sean warns elderly patients about falls because you can get a little unstable

Peter asks, “*Pregabalin can also lead to weight gain. Doesn’t it also increase appetite?*”

- Both
- Sean sees more water retention; a little peripheral edema in both
- Peter thinks they both enhance sleep (especially pregabalin) ‒ a little bit of a benefit when taken at night
  - He thinks he saw a study where it promoted appropriate sleep architecture (Sean doesn’t know)
- Sean has taken it after surgery and finds it makes him sedated

**⇒** When Sean doses it, he’ll does it lower in the day and higher at night

- He’ll dose gabapentin during the day: 300, 300, then 600 at night
- He’s trying to titrate that so that it helps them sleep because
  - During the day we’ve got all these modulatory things we can do around our pain: distraction, for instance, other coping strategies
  - At night you’re just trying to get into this relaxed state and that is the worst time for somebody with chronic pain
  - And so the gabapentin and sometimes other agents can help with that

***Sean does use it to help people sleep [gabapentin or pregabalin]***

- There’s no lethal dose
- Gabapentin maxes out at around 900-1000 mg at a dose because it’s taken up by an active transport system in the small intestine
  - Once you take more than about a 1000 mg, the rest of it’s just passed out your backside
- Pregabalin is different: it has what’s called a linear kinetic profile, simply meaning the more you take, the more that gets in your system
- The only times Sean will typically switch somebody from a gabapentin if they’re getting benefit is when they’ve maxed out the dose
  - They’re getting benefit, but there’s no point in giving them more
  - He’ll switch to pregabalin where he can drive more into their system

***Sean uses gabapentin or pregabalin for the most recalcitrant pain in general***

- He can speak to perioperative pain, acute pain, subacute pain, and chronic pain
- Stanford is a tertiary referral center, and Sean tends to see people after they’ve seen everybody else

## The definition of chronic pain [1:29:15]

**How do you define chronic pain?**

- There’s various definitions, some put a timeframe on it
  - Which many of us believe is a little artificial
  - It’s not 3 months or 6 months

***It is pain that persists beyond the expected time of tissue healing***

- It is nuanced, it is context-specific meaning
  - If you have an inguinal hernia repair or a prostatectomy, which should heal up pretty quickly and your pain should go away pretty quickly
  - But if you’ve got pain after a few months, that’s starting to get to that point where Sean is a little worried something’s going on from a chronic pain
  - If you had a total knee replacement, that is a massive, massive surgery and you’re going to have pain for quite some time, so he wouldn’t call chronicity for a total knee
- This gets into the whole issue around opioid prescribing and these rigid timeframes for surgery

## The role of antidepressants in pain management [1:30:15]

**What is the role of antidepressants in pain management?**

- These are incredibly effective agents, not necessarily for their antidepressive properties
- They frequently work through modulating a couple neurotransmitters: serotonin and norepinephrine (to varying extent)

**⇒** Classic antidepressants, what we refer to as [SSRIs (the selective serotonin reuptake inhibitors)](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) haven’t been as effective for pain as the older dirty drugs of the [tricyclic antidepressants [TCAs]](https://en.wikipedia.org/wiki/Tricyclic_antidepressant)

- We call them dirty, which simply means they act at multiple receptors, they hit multiple systems

**⇒** These tricyclics hit the serotonin and norepinephrine systems and then they also happen to be pretty potent sodium channel blockers

- Why the sodium channel blocking property is important
  - When we talked earlier about the peripheral nerves, one of the main drivers of an action potential is activity around the sodium channels
  - You block the sodium channels, the action potential stops

Peter asks Sean, “*Do you remember how much you gave me? …How much lidocaine?*” (he’ll come back to that story)

*Which TCAs are the popular ones?*

- There are about 9
- Sean’s go-to is [desipramine](https://en.wikipedia.org/wiki/Desipramine), [nortriptyline](https://en.wikipedia.org/wiki/Nortriptyline), and [amitriptyline](https://en.wikipedia.org/wiki/Amitriptyline)
- They’re broken up into different categories based on mainly side effect profiles
- Amitriptyline [brand name Elavil) is an older tricyclic that has a lot of histamine release, a lot of sedating properties
  - Sean would never give that to an older guy with a big prostate because he couldn’t pee, and he’ll be very angry with me
  - He will never give that to a young woman who’s looking to watch her weight because she’s going to get the munchies and she’s going to put on 10 or 20 pounds and she’s going to hate me
  - He’s had both of these happen, and is still embarrassed to this day

Peter asks, “*Is it offset by GLP-1 agonists in the modern era?*”

- Sean learned his lessons and hasn’t run that experiment (that’s a great idea)

*Uses for different TCAs*

- He’ll typically use the **amitriptyline** when he needs some sedating help at night for sleep and pain because of dual action
- He likes **desipramine** because it has less of that sedating property and the **nortriptyline** and you can titrate blood levels

These drugs work in the brain and they work in the brainstem

- One of the classic areas down deep in the brainstem is a [rostral ventromedial medulla](https://en.wikipedia.org/wiki/Rostral_ventromedial_medulla) region where descending pathways are coming down
- Some of the key neurotransmitters there are [serotonin](https://en.wikipedia.org/wiki/Serotonin), [norepinephrine](https://en.wikipedia.org/wiki/Norepinephrine)

***We’re not necessarily using these drugs for their mood changing properties; we’re using them because they hit the same systems as they do in pain (and that’s the beauty of them)***

- That’s some of the messaging we have to give patients when we’ve prescribed them an antidepressant is like, “*Okay, Mrs. Jones, Mr. Smith, we’re not doing this because you’re depressed. These are great, great, great pain drugs, but they were never FDA approved.*”

Peter asks, “*Why were they not FDA approved (for pain)? Because they’re off patent, there’s no money to be made?*”

- They’re FDA approved for something else

## Opioids: their controversial and nuanced role in pain management [1:33:45]

- There’s no question that opioids have been overused and abused and there’s no question that illicit use of these things has had a devastating impact on our society
- But it would be difficult to say that the field of medicine would be better off having never had an opioid
- We just talked about surgery for example, and it’s very challenging to deliver medical care in a hospital without opioids

**The question becomes what is the most responsible case for oral opioids, which by definition are meant to be used outside of a hospital (not inside a hospital)**

- And as a pain specialist, Peter would imagine few people are better equipped to navigate the nuance of that question

Sean points out, “*It is a very nuanced question. I think a little preamble first…*”

- Sean doesn’t take money from either the opioid companies or from the litigation that’s ongoing
  - Because there are tens and tens of billions of dollars at play right now
- He is not pro-opioid
- Hi is not anti-opioid

> “*I am pro-patient. I view them as a tool.*”‒ Sean Mackey

- Sean views them as a tool much like the other medications, interventions, mind, body, physical, rehabilitative, complementary tools that we use
- They have a particular place
- Sean has a personal deep appreciation for the destruction that these agents can cause
  - He comes from a family very deep in addiction
  - He’s lost close family members to opioid overdose, to alcoholism
  - He’s personally petrified of these drugs, and he has gone through surgeries that the surgeon said, “*You can’t get through this without an opioid*.” (his approach was avoidance)
- With that said, Sean learned a long time ago not to project his personal experiences onto his patients
  - That had to come through age, wisdom, whatever

***It is true, prescription opioids were over-prescribed, they were over-marketed, they were bad actors doing bad things. But it’s not that simple a story.***

Sean sometimes gets frustrated because he feels like you can make really simple sound bites out of this complex societal issue when it was a perfect storm that hit

- Yes, you had a letter to the editor of New England Journal saying that nobody got addicted
  - Like 38 patients or some nonsense
  - And Purdue and others ran with this (they did bad things)
- You also have to put things in the context of what was going on in society: there was growing awareness of pain as there should be
- There was growing pressures to do something about it
- People have brought up pain as a [fifth vital sign](https://en.wikipedia.org/wiki/Vital_signs#Fifth_vital_signs) as an example
  - People have different opinions about that
  - Did it have bad consequences? Yes
  - Did it have good consequences? Hell yes
    - Run the counterfactual: Do you want to go back to a time when we’re not asking patients after surgery their pain?
    - Do you want your mother, your daughter, back in that time? (the answer is clearly no)
- Also there was other pressures ‒ Peter witnessed those firsthand
  - What was going on back in the 90s and the 2000s?
  - After surgery, there was this massive push to get people out of the hospital and put them in their home
  - We were replacing care in a hospital with care in the home
  - In the hospital, we had time to see their trajectory, and we could titrate their opioids or whatever, get them tuned up, dialed in, and then send them home
  - Now it’s surgery, overnight and you’re home ‒ lets give you a bucket of whatever
    - The reason for that was surgeons and docs don’t like getting called at 3:00 AM for pain control
- On top of it, docs get lousy training for pain
  - 7 hours on average in medical school
  - Vets get 40 hours of pain [training], so great if you’ve got a dog, not so great for a patient
- Now you’ve got the introduction of patient satisfaction scores
  - Doctors are coming to their senses, and one way of addressing the satisfaction [is to] give more opioids

***And there’s more, there’s many, many, many pressures that came to bear that helped create this [opioid] problem of which there were bad actors out there***

Peter’s analogy: he compares it to the mortgage crisis in 2006-2008

- It would be really easy to blame one of the entities, but it was actually a perfect storm
- Sean agrees, it was a perfect storm
- In the end, he’s going to be a little bit reductive when it comes to the docs roles in this
  - He’s going to borrow from his friend [Professor Keith Humphreys](https://profiles.stanford.edu/keith-humphreys)
  - There are 3 kinds of physicians out there
  - 1 – There are the majority of the physicians doing the right thing for the right reasons
  - 2 – There are the next group, which is a much smaller group, physicians doing the wrong thing for the right reasons
  - 3 – And at the very top of that pyramid, a little group, you got physicians doing the wrong thing for the wrong reasons
    - Those people at the top, take away their license, put them in jail

***But you had a group of people here in the middle that were doing the wrong thing for the right reasons, that they didn’t have the right education, they thought they were helping people***

- Did they contribute to the problem? Yes
- Have they gotten educated? Yes

Sean circles back to answer the question

***Sean doesn’t use opioids as a first line agent ever (usually by then they’ve tried other things before they’re getting to him; he will use it for end of life, cancer pain (liberally as needed)***

Peter asks, “*You are not taking care of somebody in the acute phase of expected pain typically. Is that correct? In other words, that guy that just had a knee replacement, he’s being managed by his surgeon, correct?*”

- Frequently there is an acute pain service in the hospital that sees about 30-50 patients a day
- People see Sean’s team most frequently when the outcome is not simple
  - When the surgeon needs some help, when the internal medicine doc needs help and it’s beyond their comfort

When Peter was in residency

- They brought pain in to be consulted for every case, it was a non-negotiable
- In a [thoracotomy](https://en.wikipedia.org/wiki/Thoracotomy), sometimes you had to actually make a huge incision under the ribs and that’s very painful
  - You cut this huge incision in the intercostal muscles, you put rib spreaders in, you crank these things open so you can do this big operation
  - We just know those patients are going to need an epidural catheter, and we want that in before surgery (it makes all the difference in the world)
  - By the time Peter was in residency, we didn’t do a thoracotomy that often ‒  we did minimally invasive surgery
- He’s sure things have changed in 20 years

**Today for a general abdominal case or a general orthopedic case, are you brought in preoperatively?**

- Yeah, these days there’s a lot of movement towards these [ERAS protocols](https://www.aana.com/practice/clinical-practice/clinical-practice-resources/enhanced-recovery-after-surgery/) and enhanced recovery after surgery
- Fortunately, the field of medicine is moving more and more towards a team-based healthcare model where surgeons, pain docs, anesthesiologists, nursing, rehab, are all working in a collaborative manner
- They’re putting together protocols to what is the best optimal approach to prehab a patient before surgery, move them through the intraoperative and then perioperative period
- It’s gotten better and better and better
- Can we still improve it? Yes
- The acute pain service does get involved, particularly as Peter alluded when we put in peripheral nerve catheters or epidural catheters
  - This is where we’re running that local anesthetic, the numbing medication, that stops the nerve impulses to provide pain relief after surgery

***Yes, we get deeply involved in that acute surgical pain space, and then also with internal medicine docs when patients are admitted into the hospital for whatever cause***

**If someone is going to have elective surgery (knee replacement, hip replacement, the cholecystectomy, etc.), should they ask their surgeon about minimizing the use of narcotics? Ask to call in a pain consultant so they can have a team of docs who are exclusively thinking about their pain?**

- The surgeon has enough to worry about
  - Making sure you don’t leak, that the  [anastomosis](https://en.wikipedia.org/wiki/Anastomosis#Medical_anatomy) is fine, making sure you’re not getting a wound infection
  - Your pain is 3rd or 4th on their list of concerns for you to have the best outcome

Sean suggests patients ask their surgeon, “*What will pain management be like? Is there an opportunity to interface with an acute pain service?*”

- This will allow you to see the pain doctors before surgery, and they will put together a pre-surgical plan
  - It will often include a regional anesthetic approach, meaning those nerve blocks or the catheters
  - Sometimes it involves intravenous ketamine to augment
  - They will put together the whole plan, communicate with the anesthesiologist, make sure there’s a good handoff after surgery, and then they will follow the patient afterwards
    - Typically follow them outside the hospital and help the surgeon out with the medication management and the pain management
  - All of this is not just solely to reduce pain, but to put that person in optimal state for rehab

**How ubiquitous is the patient-controlled analgesic device (PCA)?**

- [PCAs](https://en.wikipedia.org/wiki/Patient-controlled_analgesia) are used everywhere in the immediate post-operative phase
- They use [fentanyl](https://en.wikipedia.org/wiki/Fentanyl), [morphine](https://en.wikipedia.org/wiki/Morphine), [dilaudid](https://en.wikipedia.org/wiki/Hydromorphone)
- It puts pain control in the hands of the patient

**⇒** 2 studies have shown that using PCA delivered medication opioids, patients end up taking less than if it’s nursing-delivered

- Peter recalls that the goal was to get the patient off the opioid (even oral) before they went home

**Is the generally stated objective of the medical system now to deliver any needed opioids in the hospital and not send the patient home with them?**

- Not necessarily
- There are some surgeries that are going to clearly require prescribing an opioid after surgery

***Remember, the name of the game is get people out of the hospital and have the care take place in their home, and people are going to need some degree of pain management and analgesics***

- Those analgesics can be Tylenol, NSAIDs
- If it’s more than mild, moderate pain, it may involve an opioid

**How are you thinking about extracting the value of the opioid and minimizing the risk of long-term dependence?**

- We have learned that there are vulnerabilities people bring to an injury or surgery and being placed on opioids that set them up for more likelihood of persistent opioid use
- Some of these factors include preoperative depression and anxiety, higher levels of catastrophizing, early adverse child events
  - History of PTSD, history of physical, sexual, psychological trauma

***All of these set someone up to have a higher likelihood of persistent pain and persistent opioid use***

- Most of these things people would normally put under the psychological umbrella

Sean emphasizes, “*The key message that I want to give, I think everyone’s getting this, is when we talk about psychology and psychological factors, we’re talking about neurosciences, we’re talking about the brain, and we’re talking about specific brain systems, regions, networks.*”

**⇒** Sean did a [study](https://pubmed.ncbi.nlm.nih.gov/24964916/) several years ago and we found that higher depression scores preoperatively predicted much more likelihood of persistent opioid use after surgery

- This study was led by [Jennifer Hah](https://profiles.stanford.edu/Jennifer_Hah), and [Ian Carroll](https://med.stanford.edu/profiles/ian-carroll) was a key player/leader on this

*How are you screening for this? What tests are you using?*

- Back then, we used something called the [Beck Depression Inventory](https://www.ismanet.org/doctoryourspirit/pdfs/Beck-Depression-Inventory-BDI.pdf), which we don’t use that anymore (there’s more modern tools)
- In that original paper, we did a factor analysis on the original paper and you can break the Beck down into different components of depression, anhedonia, cognitive, etc.
- What we found is it was a particular factor that drove almost entirely that prediction of depression: **self-loathing**
  - It was feeling like really bad about yourself
  - [shown in the figure below from this study]

![](https://peterattiamd.com/wp-content/uploads/2025/04/f4-seanmackey.png)

**Figure 4. Variables influencing time to opioid cessation**. Image credit: [*Pain Medicine* 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4083472/)

![](https://peterattiamd.com/wp-content/uploads/2025/04/f5-seanmackey.png)

**Figure 5. Preoperative average self-loathing symptoms factor score ≥ 0.01 predicts prolonged opioid use after surgery**.  Image credit: [*Pain Medicine* 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4083472/)

Peter asks, “*If you have someone who just suffers from anhedonia but no self-loathing (not to say anhedonia is anything but unpleasant), would you say that the risk isn’t as high?*”

- Yeah, conceptually this argument holds

**There is a danger in drawing inferences from small population studies and generalizing that to the rest of the world**

- Especially without randomization
- Because what you really would like to be able to see is you take a whole bunch of people in, you get their incoming metrics of anhedonia, dysthymia, self-loathing, you categorize all the arms and tentacles of depression, and then you randomize within each of those to with and without opioid strategies
  - This is a very complicated thing to do, but if you want to know the answer, that’s the way you want to do it
- Unfortunately there’s not much will to do that in society

Sean was on the Institute of Medicine panel (now the National Academy panel), and we did a report called [Relieving Pain in America](https://nap.nationalacademies.org/catalog/13172/relieving-pain-in-america-a-blueprint-for-transforming-prevention-care)

- He remembers sitting around back in 2010 and we were talking about the state of pain in the country and where we needed to go to identify a perfect vision and also identify what are the biggest research questions to ask and answer?
- He remembers a really vigorous discussion
- The one that Sean put forward and others put forward is: ***we need to better understand, what is the long-term effectiveness and safety of prescribing opioids to people with chronic pain?***

> “*Meaning we need to figure out for whom opioids work. Today, we still don’t have an answer to that question and there’s very little will to do it.*”‒ Sean Mackey

**⇒** The message in the scientific community is to find non-opioid choices

- There’s not a lot of interest in funding the studies to figure out for whom opioids work
- There is a lot of active interest still mainly through data-driven studies to find out who is at risk
- But that type of study that you’re talking about and others on longer term and bigger consequences, Sean doesn’t know when they’re going to get done
  - Who’s going to fund those?

**Avoid opioid use by injecting bupivacaine at the incision site 10 minutes before surgery**

- Peter recalls when he was in residency, one of the attendings had this belief and quoted a study that said if you injected [bupivacaine](https://en.wikipedia.org/wiki/Bupivacaine) into the incision site, wait 10 minutes, then make the incision and do the surgery
- Then immediately give that patient acetaminophen and ibuprofen immediately post-operatively and keep them on it around the clock, you could eliminate opioid use
- Bupivacaine is a long acting sodium channel blocker
- The attending was convinced that the only reason surgeons didn’t want to do this was because nobody wants to inject and stand there for 10 minutes with your thumb up your ass waiting for the bupivacaine to seep into the tissues
- Maybe it’s anecdotal, but it really seemed to work
  - It seemed to work for an inguinal hernia repair or some small laparotomy
  - We might’ve used epi with lidocaine as well, so it might’ve been a little epi with lidocaine plus bupivacaine or something like that
  - And you had to be super due diligent about keeping the acetaminophen and ibuprofen levels up

*Have you ever heard of anything like that?*

- Yeah, all the time
- Sean thinks he was practicing good medicine and he was doing it ahead of his time
- Now, whether it completely eliminates any likelihood of opioids after surgery, that’s a little too strong a statement
- The idea of using a combination of [lidocaine](https://en.wikipedia.org/wiki/Lidocaine) and [marcaine](https://en.wikipedia.org/wiki/Bupivacaine) and epi,
  - Lidocaine’s short-acting, so it’s going to work pretty darn quick, and so you can get going with your surgery while the marcaine, the bupivacaine, is kicking in
  - The epi is going to not only provide hemostate, it’s going to reduce bleeding at the site, but it can keep the local contained
  - Which means you can use less bovie, which means less tissue damage

***Sean’s sense is that is becoming more and more common practice***

- There’s a greater appreciation of the role of this concept of preemptive preventative analgesia, anesthesia
- It provides some benefit
- There was a big hoopla on this 20 years ago when everybody thought we were going to find a way to basically eliminate post-operative pain through these methods ‒ it just didn’t pan out
- But a 50% reduction in opioid requirement post-operatively would be enormous

**Sean thinks we’re at an interesting crux in research and clinical care where we’re gathering more and more high quality data to better understand these vulnerabilities**

- We’re going to be moving to the point of putting these into clinical decision support tools that can inform the docs and help them to assess a risk of a patient so that you can have an informed conversation with someone
  - Like you are at likelihood of having persistent opioid use because of what you bring

Peter asks, “*Do patients receive that well? That’s a hard discussion to have with a patient, I would imagine*.”

- It’s about their expectations
- The challenge is with the patients who’ve had multiple surgeries where they have been on opioids
  - They’re expecting opioids
- In the more naive person, things go a little smoother if you’re professional and explain it to them
- But also allow them to make their own choices
  - Don’t say, “*We’re not going to give this to you.*”
  - Instead say, “*You are at an increased risk.*”

## Alternative therapies: acupuncture and cannabis [1:54:15]

**What do you know about acupuncture through the lens of chronic pain?**

- Clinically, some people get better, some people don’t get better
- Sean cannot yet predict who is going to respond and who’s not going to respond

*Is it a part of the work your department does?*

- Yes
- [Dr. Jiang-Ti Kong](https://profiles.stanford.edu/jiang-ti-kong?releaseVersion=10.9.0) does the acupuncture (she’s a pain doc)

Sean’s view of acupuncture as a treatment as a modality is, “*If you can afford the wallet biopsy and it doesn’t cause you problems, then give it a try.*”

Peter asks, “*And you say wallet biopsy because the insurance doesn’t typically cover it?*”

- They do more so now on Medicare
- Sean thinks that the rules that went into place recently helped with that for older patients
- He doesn’t honestly know if it’s translated down to the commercial carriers
- Historically, it’s been hard to get that covered

**In your experience, where do you see acupuncture being most successful?**

*What type of pain? What type of clinical presentation?*

- Sean has had some successes in back pain, musculoskeletal pain, migraines, headaches
- It’s highly variable
- He had a really large program project grant look at cortical mechanisms of this and predictors, and he’s putting in a paper now
  - A prediction model of real acupuncture versus placebo acupuncture

Peter asks, “*Puncture, but not in the appropriate spot?*”

- That’s one option

**⇒** It turns out that many of these acupuncture points overlie peripheral nerves and so when you twiddle the needle or apply electroacupuncture, are you doing a peripheral nerve stimulation?

- A **Streitberger needle** that looks for all intents and purposes like an acupuncture needle
  - It causes a little pinprick, but it doesn’t actually do acupuncture
  - It’s been shown to be a good placebo

![](https://peterattiamd.com/wp-content/uploads/2025/04/f6-seanmackey.png)

**Figure 6. The Streitberger placebo device uses a short blunt needle with a thin handle; a plastic ring covered with a plastic sheath is used to keep the needle in place**. Image credit: [*Evidence-Based Complementary and Alternative Medicine* (2013)](https://onlinelibrary.wiley.com/doi/10.1155/2013/628907#:~:text=2.1.1.%20The%20Streitberger%20Device)

*Sean doesn’t fully understand the mechanisms*

- He knows that there are increases in peripheral adenosine that is released with acupuncture that has an analgesic effect at the primary nociceptor
- He knows that cortically in the brain, there are brain systems that are modulated with acupuncture, but he doesn’t know exactly how it works

**⇒** We still don’t have good ways of predicting who’s going to respond and who’s not going to respond, but that’s rather common amongst all of our pain treatments

- Acupuncture is pretty safe absent some risk of infection
- Make sure that the facility you’re getting at practices good, hygienic approaches

**How do we think about acupuncture differing from dry needling?**

- You’ll want to ask a true acupuncture specialist
- Peter recalls that in California, it’s not legal to dry needle, but you can do acupuncture
- Peter sees acupuncture as going after a nerve specifically
  - Sean points out, “*It’s an acupuncture point*.”
- It is a Chinese medicine list of acupuncture points
- This is way out of Sean’s wheelhouse here
- When he thinks of [dry needling](https://en.wikipedia.org/wiki/Dry_needling), he tends to think of that in the context of trigger point injections
  - Which we do, physicians do
  - For that we’re taking typically a 30 or 27 gauge needle, and we’re putting it intramuscularly into a trigger point muscle
  - It’s where you get those knotty muscles, and dry needling causes relaxation of the muscle
- Acupuncture’s really quite different from that

**What is the role of** [**cannabis**](https://en.wikipedia.org/wiki/Medical_cannabis#) **for treating chronic pain?**

- This is very nuanced
- This is one where you’re liable to get some hate mail on either side of this
- The verdict is still way the heck out there
- There’s very few well-controlled randomized trials
  - Some in neuropathic pain show analgesic benefit over a short period of time with cannabis
  - Australia did a population-level study and they did not show benefit with cannabis
- Sean collects data
- He built a learning health system that captures high-quality data on every patient that comes in
  - One of his other areas of both research and clinical care
  - We deeply characterize or phenotype them and we looked at people coming in on cannabis, not on cannabis

***Bottom line, people coming in on cannabis into Stanford are worse off and they stay worse off***

- Now, there’s all these limitations to observational studies no matter how well you conduct them

*Sean distills it down to some talking points*

- 1 – There’s a huge number of cannabinoid receptors in the human brain that are playing a role in analgesia, so Sean is absolutely convinced that cannabinoids are playing a role in pain relief
- 2 – The forms of cannabis that we take are dirty, meaning we don’t know the dose, we don’t know the ratios, they’ve not been well studied, and they’ve not been studied in different groups
  - A major part of that is because it’s a schedule one drug, which means that the DEA says basically high abuse potential and no medical benefit
  - It takes basically an act of Congress to study cannabis
- Sean doesn’t prescribe it at Stanford
- He doesn’t screen people for it at Stanford
  - If he did, and if we kicked them all out, he wouldn’t have anybody in the clinic (he’s in northern California)
- Peter would assume that since it’s legal in California, if Sean was using non-federal dollars, he could study it
  - So he’s surprised that you can’t study it

Sean used to joke, “*UCSF did some nice cannabis research and the word on the street is that they would deliver the cannabis doobies in a Brinks armored truck with guys carrying M16s.*”

- It’s gotten better, but it’s been challenging to study this

Here’s where Sean is going to upset people

Sean explains, “*I firmly believe we should make it a schedule II or schedule III drug.”*

- [[schedules of controlled substances](https://en.wikipedia.org/wiki/Controlled_Substances_Act#Schedules_of_controlled_substances)]
- If for no other reason to study it with less friction

## Fibromyalgia and chronic pain: clinical features, brain mechanisms, and emerging treatments like low-dose naltrexone [2:01:00]

- There’s a condition Sean has already alluded to today that Peter is sure everyone has heard of, and yet if you asked most people to define it, they wouldn’t be able to define it: [fibromyalgia](https://en.wikipedia.org/wiki/Fibromyalgia)

**What is fibromyalgia, why might someone have it, what is the prevalence?**

*Are there false positives?*

- Historically, fibromyalgia was a garbage bag definition: a condition of widespread bodily pain that impacts people above and below the waist (the diaphragm)
- It’s associated with early morning stiffness, fatigue, mental fog, often some GI problems
- It was historically based on American College of Rheumatology definitions based on tender points in 11 out of 18 places, but that’s been replaced by now criteria which involves multiple body sites affected and a [symptom severity score](https://rheumatology.org/api/asset/bltaa2bfa7043886f9e) [see also [*StatPearls*](https://www.ncbi.nlm.nih.gov/books/NBK540974/)]

***It’s fibromyalgia syndrome and whenever the audience hears “syndrome,” what they should translate that to, the definition of a syndrome is a constellation of signs and symptoms that define a disease, but we don’t understand the mechanism***

- Fibromyalgia is a syndrome, and we do not understand its mechanisms
- We know that historically, it tended to affect women more than men, about 80%-ish or so women
- With the newer definition, we’re picking up a lot more men

The cognitive aspects of it are really a problem

- It’s also associated with sleep disturbances
  - They get this weird… what we call alpha wave intrusion into their EEG, which means alpha waves are typically in light awakefulness
  - So when you’re supposed to be in deep sleep or REM sleep, your brain is in a light alert state instead, and so they’re not getting a restful sleep
- This is a syndrome that’s caused untold problems, particularly for women

*What’s the prevalence according to the current definition?*

- Sean should know how many millions there are and he doesn’t
- [according to the [American College of Rheumatology](https://rheumatology.org/patients/fibromyalgia), it affects 2-4% of people, usually women]

To give you a frame of reference, Sean explains, “*Chronic pain, we think there’s 50-100 million Americans with chronic pain…. We know that there are about 8% of the population or a little over 20-some-odd million with something called high impact chronic pain.*”

- That’s a huge range, and it depends on the way you ask the question
  - If you ask it more stringently, it’s 50 million
  - If you ask it more liberally, it’s 100 million
- High impact chronic pain is a big one, and this is where Sean spends a lot of his research and policy work on

***High impact chronic pain describes people that have substantial restrictions to their pain in activities of daily living (really challenging)***

**⇒** Of that 50-100 million, the most common chronic pain is low back pain at about 28%; neck pain, 16%; headaches around 16%

- Societal burden of chronic pain is terrifying; it’s astounding

**⇒** We spend over half a trillion dollars a year in chronic pain

- The reason why in part it’s not more appreciated is because we have parceled it out
  - We’ve broken it into different categories
- With heart disease, we lump it into heart disease, cardiovascular disease, even though it’s all these different subcomponents
- With pain, instead we categorize it as: it’s back pain, it’s musculoskeletal pain, it’s migraines, it’s abdominal pain, and it gets diluted out
- But when you put it all together, you’re dealing with a half a trillion dollars

> “*[Chronic pain] it’s more than diabetes, heart disease, and cancer combined.*”‒ Sean Mackey

Fibromyalgia: many millions of people, huge societal burden

- It is historically a disease of histrionic housewives and how they were mislabeled tragically
- We’re having now a greater appreciation for what it is, what’s affected

**What we have learned is that there are brain systems that are clearly abnormal in the processing of pain in people with fibromyalgia**

- We find that for the same pressure stimulus, if you apply something like 4 kg/cm2
  - Healthy people will give a range of reporting in a certain range
  - People with fibromyalgia report much, much higher

**An interesting pain concept to introduce and talk about it is something called conditioned pain modulation (CPM)**

- In the animal world, we called it [diffuse noxious inhibitory controller (DNIC or CPM)](https://en.wikipedia.org/wiki/Diffuse_noxious_inhibitory_control)
- Think back to when you were a kid and your arm hurt
  - You walk up to your buddy, you say, “*Hey, man,*” and he’s like, “*How are you doing?*”
  - It’s like, “*Well, my arm’s kind of hurting a lot.*”
  - And what would he do?
  - He’d hit you in your other arm, he’d stomp on your foot, and you’re like, “*Why the hell did you do that?*”
  - He’d ask, “*Don’t you feel better?*”

***And the truth is you did because pain in another area reduces the primary pain site ‒ it’s called conditioned pain modulation***

- We’re all wired
- It is a network predominantly we think in the brain stem involving some of this periaqueductal gray, rostral-ventro-medullary regions
- [Le Bars](https://www.researchgate.net/profile/Daniel-Le-Bars) first [described](https://pubmed.ncbi.nlm.nih.gov/460935/) this in the mid-’70s in animals
- We all do it; we all have it

***It’s this endogenous tonic inhibitory tone that you can activate when you cause pain in another site (unless you have fibromyalgia)***

- If you have fibromyalgia, particularly if you’re a woman with fibromyalgia, you have impaired CPM ‒ you don’t inhibit

**Is there a high overlap with depression, anxiety, and fibromyalgia?**

*And if so, which is the arrow of causality?*

- Yeah, the chicken and egg
- We used to think that there was a high preponderance of anxiety and depression with fibromyalgia

***The current data doesn’t support that there’s any higher prevalence than particularly any other pain conditions***

- You tend to see more of the anxiety, depression, broadly speaking in things like low back pain

**⇒** What you see more of in fibromyalgia is fatigue (unrelenting fibrofog is what they call it) and sleep disturbances

**What is the management for these patients?**

*Is this a curable syndrome, or is it a syndrome that is meant to be managed like HIV?*

- Yes and no
- We don’t know exactly the mechanisms and there’s different prevailing thoughts
- 1 – It’s a disruption in your central brain processing of pain through reasons unknown
- 2 – Some believe it is a disease, a condition of small fiber neuropathy
  - Because you can do punch biopsies, little, little skin biopsies here, and what they find in some subsets of people with fibromyalgia are abnormalities of those C fibers in the skin
  - And that is synonymous with a small fiber neuropathy that neurologists typically see

Peter asks, “*That’s caused by what?… Is this infectious? What do people think is going on?*”

- That’s the thing
- Fibromyalgia is frequently preceded by some event, something traumatic
  - That traumatic can be physical, motor vehicle accident, but it could also be some emotional or sexual abuse
  - It can be an infection
  - There is some insult that people will frequently identify

**Getting back to your question on managing this**

- We frequently use the same medications that we’ve described before, but we rely on more of those brain modulatory drugs and other ones like [duloxetine](https://en.wikipedia.org/wiki/Duloxetine)
  - Which is in the class of antidepressants, but it’s a little cleaner, fewer side effects
  - It’s a [serotonin norepinephrine reuptake inhibitor](https://en.wikipedia.org/wiki/Serotonin%E2%80%93norepinephrine_reuptake_inhibitor)
  - This is actually a drug that got FDA approval for pain, and so we go to this a lot

One drug that Sean [studied](https://pubmed.ncbi.nlm.nih.gov/23359310/) with [Jarred Younger](https://www.uab.edu/cas/psychology/people/faculty/jarred-younger) (who’s now at UAB) is a drug called [low-dose naltrexone](https://en.wikipedia.org/wiki/Low-dose_naltrexone)

- This is a fascinating drug
- It’s got this underground reputation out there; it’s all over the forums.
- It’s been around for decades and is off patent
  - There is zero money for any pharmaceutical company for it

*What is naltrexone?*

- Naltrexone, when given at 50 mg, is used to block opioid receptors (it’s an opioid blocker)
- We use this in the treatment of opioid and alcohol addiction because it blocks the rewarding experiences of alcohol or opioids (50 mg)
- At 1/10th the dose (4.5 mg), it has been shown to block [toll-like receptor 4](https://en.wikipedia.org/wiki/Toll-like_receptor_4) on the [microglia](https://en.wikipedia.org/wiki/Microglia)
  - Microglia are these cells that hang around nerves but are not neurons
  - When Sean was in medical school (several years before Peter), what he was taught was these microglia were like the warm, fuzzy blanket that propped up the nerves
  - They provided structural support to the nerves
  - What he learned is that was only part of the story
  - They’re key neural immune modulators
  - In times of stress injury fever, these microglia get activated, and they release all sorts of inflammatory mediators, chemicals that sensitize the central nerves responsible for pain perception, pain transmission, pain perception

***You give low-dose naltrexone, it blocks that neuroinflammatory soup***

> “*And in some patients, Peter, this drug’s been magical. Magical. I give it in 4.5 mg.*”‒ Sean Mackey

Peter asks, “*Silly question, why not five? 4.5 has a lot of specificity to it.*”

- [Linda Watkins](https://www.colorado.edu/neuroscience/linda-r-watkins) and [Mark Hutchinson](https://researchers.adelaide.edu.au/profile/mark.hutchinson) did some of the early work in the animal studies on this and showed this microglia effect, and they did it at a certain dose
- What we did is a milligram per kilogram (70 mg per 70 kilo person), and we get 4.5 mg
  - There’s no difference between 4.5 and 5 mg

**What are the other areas where LDN [low-dose naltrexone] is just captivating the world?**

- [Complex regional pain syndrome](https://en.wikipedia.org/wiki/Complex_regional_pain_syndrome)
- It’s a very tragic pain condition that is a neuropathic pain condition ‒ we see it a fair amount
- Sean is wrapping up a [clinical trial](https://clinicaltrials.stanford.edu/trials/l/NCT02502162.html) that using low-dose naltrexone, funded by the [RSDSA Association](https://rsds.org/)
- Another is [multiple sclerosis](https://en.wikipedia.org/wiki/Multiple_sclerosis) they’ve used it in, and they found some reduction in recurrences of MS

***It’s used in these weird neurodegenerative type conditions where they’re seeing some help***

**Sean has had some wacky, really wacky, patient responses to LDN**

- One guy is dysarthric (he can’t speak); he’s got weakness; he has hemi-body pain, burning pain
  - This is that central pain
- He’s tried everything
  - He had a speech therapist, but that’s not getting any better
- He had a stroke (stabilized) and is a few years out
- He has burning pain on half his body
- Sean trials him on 4.5 mg LDN, and he comes back a few months later
  - His pain is improved
  - He’s also peaking and throwing a few words together for the first time since his stroke
- Sean bumps up his dose
  - You cannot hurt yourself on this drug
- He goes to 9 (it’s easy to take 2 capsules)
- He comes back a few months later, and now he’s talking in sentences
  - Sean asks if he’s sure this isn’t due to his speech therapist, and he swears it’s not
- He bumps the does up to 13.5

***Now this guy is having conversations, and his pain is massively better on this ‒ really remarkable effect***

The only way Sean can explain these things

- In a stroke, you’ve got dead tissue, you’ve got live tissue, you’ve got these intermediate zones
- Somehow with reducing maybe inflammation, you end up with more functional brain
- Teleologically this model makes sense to Peter
  - Something about that inflammatory zone in the middle between what was clearly gone and not is poisoning the part that is still okay

Peter asks, “*What is the downside of this? Meaning, what would one need to be mindful of in trying an approach like this?*”

- The only side effect Sean sees is 20-30% of people get vivid, technicolor dreams
  - Not bad dreams, not nightmares, their dreams just take on a more colorful nature
- Every once in a while, somebody will say it activates them
- We tell them to take it 2 hours before bedtime, and it if activators them a little bit, take it in the morning instead

**What’s the scenario in which inflammation of the glia is a good thing?**

- It’s a good thing after injury and after an infection because it mobilizes all of those repair cells to come in and clean up the mess

**⇒** The problem that we think is going on in pain, the switches don’t turn off and go back to normal

- That is one of the things we think is playing a role in fibromyalgia
  - They got an insult, activation of this neuroinflammatory system
  - In a healthy state, it turns off
  - In fibromyalgia, it never turned off

## Possible brain benefits of low-dose naltrexone (LDN) for people with mild cognitive impairment [2:15:00]

Where Peter is going with this is we think that at least a subset of people with neurodegenerative diseases that neuroinflammation is part of the pathology

- Sean mentioned multiple sclerosis
- We think this is true in some cases of Alzheimer’s disease

**Would there be any efficacy to a trial [of LDN] in either an individual with MCI (mild cognitive impairment), or, as crazy as this sounds, is there a reason to consider it prophylactically in high-risk individuals?**

- With the caveat that if you happen to get an infection, stop taking [LDN](https://en.wikipedia.org/wiki/Low-dose_naltrexone) and ride it out and get better

***Sean thinks the short answer is yes***

Longer answer

- Everything we do is weighing risks and benefits
- This is one drug he is hard-pressed to come up with significant risks
  - We have decades, and decades, and decades of experience with this drug in people with addiction (at 10x the dose)

Peter asks, “*How long are they typically on that drug?*”

- Lifetime

**Peter’s takeaway** ‒ putting them on the “party dose” of 50 mg of naltrexone keeps them free of alcohol and opioids for life because it so blunts the pleasure center

- The problem, as all the addictionologists know, is that it’s hard to keep people on this because they can just stop it and go back and use
  - You have to want to be off
- They have injectable versions of this. It’s not called [Vivitrol](https://en.wikipedia.org/wiki/Naltrexone#:~:text=Long%2Dacting%20injectable%20naltrexone%20(under%20the%20brand%20name%20Vivitrol))
  - It lasts X number of days, months
- We’ve got a lot of long-term data on this
- From a pilot standpoint with informed consent, Sean would view that as a novel treatment in patients that one could try out
  - Monitor, do some objective measures, see what you get

Sean adds, “*I want to be careful, I wouldn’t say that for a lot of the things that we do because there’s real risks with a lot of the medications that we provide, a lot of the procedures we do. Not only that, there’s big costs that come with them.*”

For LDN, Sean’s going to make a plug

- He gets this stuff out of Belmar Pharmacy in Colorado
  - He has no relationship to them
  - They’re a compounding pharmacy
  - They’ve got all the certifications
  - They’ve got good customer service, they take patients’ credit cards over the phone, and they will ship it to you immediately
  - And they’re very responsive
- You can probably find it in your local area at other compounding pharmacies
- It usually runs about $30 a month ($1 a day)
  - It’s basically a free drug, but insurance often doesn’t cover it
    - They consider it experimental
- The reason is you can’t go to Safeway or Costco and get low-dose naltrexone is it has to be compounded at 4.5 mg

***LDN is a drug Sean uses more and more because of its safety profile and its potential for getting him a home run***

**Peter is very curious to see if anybody has looked at LDN and any of the neuroinflammation stuff**

- We see the relationship between [herpes simplex virus](https://en.wikipedia.org/wiki/Herpes_simplex_virus) and [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease)
  - Between [shingles](https://en.wikipedia.org/wiki/Shingles) (especially ocular variants of it) and Alzheimer’s disease
- We know that there is some relationship between inflammation and this disease, and we know that’s obviously not all paths cross through that
  - There are lipid-mediated paths, metabolic paths, vascular paths

***Peter thinks it would be very difficult to make the case that there’s not an inflammatory path towards that condition, and so LDN is  interesting to think about***

- Sean agrees
- As a good scientist, he points out that not everybody buys into the microglial model that he’s describing
- Friends and colleagues at Michigan, [Dan Clauw](https://medicine.umich.edu/dept/cpfrc/daniel-j-clauw-md) is a brilliant, brilliant guy who is very much in disagreement with Sean
  - He believes that, even at these low doses, LDN is antagonizing the opioidergic system and in essence, resetting it in these chronic pain states so that you’re normalizing the endogenous tone
- That’s the fun thing about science and why we try to keep our egos out of it, the truth will come forward

**What’s the evidence for the inhibition of the toll-like receptor? Is that in vitro?**

- Yeah, it is in vitro
- [Linda Watkins](https://www.colorado.edu/neuroscience/linda-r-watkins), [Mark Hutchinson](https://researchers.adelaide.edu.au/profile/mark.hutchinson) did some really nice work in that
  - People have had some difficulty in replicating it
- We know the mechanism, and it seems pretty solid

***But when Sean looks at the clinical conditions that LDN has been applied to and shown benefit, he has a hard time understanding why mild antagonism of opioids is going to have an impact on those conditions***

- Multiple sclerosis, ulcerative colitis, and these weird neurodegenerative things

Peter asks, “*Why do you think UC [ulcerative colitis]? That’s an interesting one.*”

- It’s another one of these weird degenerative diseases

Peter asks, “*Through a central effect?*”

- Sean doesn’t have a good answer on that
- He’s going to look it up and see about the whole mild cognitive impairment, Alzheimer’s aspects of it
  - He doesn’t treat these patients
  - It’s an intriguing idea

## Peter’s recovery from severe chronic pain—how he went from immobility and high-dose opioids to full functionality [2:20:15]

- Peter met Sean 25 years ago

**How big was the department of pain at Stanford then?**

- 10-12 people
- This is all the physicians and nurses, the trainees
- It was tiny, and we were in this small little clinic
- Today it’s probably 130, 150
  - Today it’s larger by a factor of 10 or more
  - It’s the largest academic pain center west of the Mississippi, and one of the top NIH-funded

**The story of how Peter and Sean met**

- In medical school, Peter was in this state of total hell
- He was in incredible pain
  - He literally couldn’t stand up; he was hunched over
- At the time, Peter was dating an anesthesiology resident and she was the one that sent him to the pain clinic
  - She was in her last year of anesthesiology and maybe was doing a rotation through pain
- Peter goes to the pain clinic and sees Sean
- At this point, Peter’s mom had flown down from Toronto to take care of him
  - He couldn’t drive or do anything
- His mom drives him to the hospital where he sees Sean
- Sean hears the story
- We’d ruled out anything that required any more surgical intervention
  - He’d undergone another MRI
  - He’d had a flexion-extension film
  - He wasn’t surgically unstable
- In fact, where the original injury was didn’t even seem to be what was driving the pain now
- Sean said, “*Look, the first thing we’re going to do is we’re going to give you an IV lidocaine drip to see if we can just calm these sodium channels down*.”
  - Peter weighed 80 kg and Sean gave him 400 mg lidocaine intravenously
  - To which Peter said, “*Dr. Mackey, I just took my boards a year ago, that’s a toxic dose.*”
  - Sean replied, “*Don’t worry, we’re going to do it in a cardiac monitored room, you will be on an EKG, and we will be able to defibrillate you if you have an arrhythmia.*”
- In 20 minutes, Peter got 400 mg lidocaine and it didn’t touch the pain
- They tried something else, and it didn’t touch the pain
- By now it was 8:00 at night
- The only thing left to do was to do a series of injections at every single facet joint, every single dorsal root, every nerve root, every dorsal root ganglia, along the entire length of Peter’s spine
  - Sean explained that he would not be able to diagnose what is wrong because he’s basically going to stop all the pain
  - But then they could chip away at this over the coming months
- Peter was on board, but they couldn’t do it that night because they didn’t have an anesthesiologist
  - Sean was the only one there
- Peter said, “*You’re an anesthesiologist*,” and Sean replied, “*Yes, but I’m the one that’s doing the procedure.*”
- Peter wanted to do it anyway
- Sean said, “*Well, we won’t be able to give you any sedation, and I’m about to stick 45 needles in your back*.”
  - Peter didn’t care ‒ that’s how much pain he was in
- They go to the OR and Sean proceeded to put [hydrocortisone](https://en.wikipedia.org/wiki/Hydrocortisone), [bupivacaine](https://en.wikipedia.org/wiki/Bupivacaine), and he lit Peter up, up and down the back

***2 hours later, Peter stood up for the first time in 3 months; he was completely pain-free ‒ this was remarkable***

Peter gets home, it’s midnight, and he says to his mom, “*I’m not going to bed. I’m going to go for a walk.*”

- Because he hadn’t walked in 3 months
- He walked the campus loop of Stanford (it’s a 4 mile loop) around and around until 9:00 in the morning
- Came home and went on to develop [plantar fasciitis](https://en.wikipedia.org/wiki/Plantar_fasciitis)
  - Because when you don’t walk for 3 months and then you don’t stop walking

Sean had told him, “*Look, you’re going to probably feel okay for a few days and then the pain is going to come back.*”

- Well, it turned out to be 2 weeks that Peter was pain-free, and then the pain came back
- Over the next 3 or 4 months, Sean repeated comparable procedures but with more and more precision (i.e. narrowing in on what the problem was)
  - If Peter’s memory is correct, it was mostly in the [T12-L1](https://en.wikipedia.org/wiki/Lumbar_plexus) area
- The ultimate diagnosis was that he had lost so much disc space at [L5](https://en.wikipedia.org/wiki/Lumbar_nerves#:~:text=The%20fifth%20lumbar%20spinal%20nerve%205%20(L5))–[S1](https://en.wikipedia.org/wiki/Sacral_spinal_nerve_1) through the multiple surgeries
- If you look at Peter’s MRI today, he basically don’t have a disc at L5-S1, that he’s now developed this facet arthropathy that far up, and that’s where those nerve roots are going into kidneys and testes

*What was amazing was these injections allowed Peter to go and do rehab*

- Which he took on like a vengeance, and basically rebuilt the strength in the musculature of his back
- Within 9 months of meeting Sean, a year of the injury, he was functional
- Within 2 years, he could get to the point where he forgot about it for days at a time
  - For example, he could actually sneeze without bracing
  - For a year, he couldn’t lean over the sink to brush his teeth, that’s how weak he’d become
    - Just the moment the arm of your torso leaning over, he couldn’t do that
    - He had to fully brace and support himself to just brush teeth

*The lasting impact of that*

- Peter has told this story many times
- One of the lasting impacts is Peter’s absolute love for parking as far as possible from wherever he’s going
  - Because when he was going through this, they wanted to give him a wheelchair parking thing and he didn’t want that (just a psychological thing)
  - So now his kids know you celebrate your legs by parking far
- In many ways, that became part of this idea he had of the [Centenarian Decathlon](https://peterattiamd.com/training-for-the-centenarian-decathlon/), this idea of what are you training for
  - You’re training for life
  - Life is your sport
  - And that can be something as mundane as being able to walk to the grocery store if there’s no spot near where you need to go, and can you push the cart to the car, and all that kind of stuff

***The net for Peter has been incredibly positive***

- He’s grateful to Sean because had he not been at Stanford
  - Had Peter not had that girlfriend [who sent him to the pain clinic]
  - That story could have gone sideways
- The final part of the gratitude is that Peter would go on to Hopkins for his residency in an emergency room that serviced some of the most opioid addicted people on the planet
- And based on his own experience with that, he always had a sense of humility about what they were going through
  - He always looked at it as, “*Oh God, I feel your pain. That is awful. And I could have been there but by the grace…*”

**Sean clarifies for the audience**

- Normally, he would never approach that in a chronic situation like that
- It lacks all specificity
- You can’t learn anything from it
- Sean remembers Peter just being an extremist, and he had to do something to help him

**How uncommon (or common) is Peter’s story?**

- Peter thinks when you meet a person like he was, part of you thinks
  - We’re never going to fix this guy; his life is over
  - He’s on 320 mg of oxy
  - He hasn’t walked in months
  - He’s in so much pain
  - The lethal dose of lidocaine did nothing

*Is there a part of you that thinks, “This is a chronic pain patient,” or do you think, “No, we can fix this”?*

- Sean is usually confident we can really help them
- He doesn’t know what help means
  - Curing is a strong word ‒ every once in a while, we can cure (just eliminate the pain so it never comes back)
    - Like Peter’s case, which he honestly didn’t even know about until recently
    - Peter was lost to follow-up
- Sean doesn’t use the word “cure”
  - Maybe a surgeon would use the word
  - Because he doesn’t want to set unrealistic expectations with patients
- Sean doesn’t give up on patients
  - He’s never hit a point in his career with a patient where he’s  said, “*We’re done… I got nothing.*”

**We’ve got so many tools available to us now**

- Back when Sean first met Peter, we had a handful of procedures and medications
  - [Gabapentin](https://en.wikipedia.org/wiki/Gabapentin) was the new kid on the block
  - We had opioids, NSAIDs, some tricyclics, but that was about it
- By the way, that notion contributed to the opioid crisis because we didn’t have tools
- Now, there’s over 200 medications that have shown to have analgesic properties
- We have over 200 procedures that we do for pain
  - Scores of mind-body therapies
  - Scores of complementary-alternative therapies
  - Physical and rehabilitative approaches
- The toolbox that we can draw upon is so much larger

***Often, the problem is not with all the tools we have, it’s trying to figure out the right tool for the right patient, the right context***

> “*I frequently focus on getting people back to a good quality of life and giving them control of their life and their pain, rather than a promise to eliminate pain*.”‒ Sean Mackey

- In the acute setting, often, it’s eliminating pain
  - Because in an acute perioperative or acute injury situation, you need to eliminate or significantly reduce it before you can get people moving
- In Peter’s case, Sean’s memory of this was a little vague
  - For a moment he thought about looking up records on Epic to see what’s what, but he didn’t
  - He’s glad Peter filled in the memory gaps

## Breaking the pain cycle: how physical rehabilitation and psychological recovery work together in chronic pain treatment [2:30:45]

**Sean’s questions for Peter about this experience**

*Stuff that was going on when Peter was in distress*

- Clearly, there was a lot of catastrophizing going on
- **Catastrophizing** is this concept that was introduced by [Albert Ellis](https://en.wikipedia.org/wiki/Albert_Ellis) in 1962
  - He was a psychologist, and he also liked neologisms, so he created catastrophizing
  - He created the word, awfulizing (it didn’t stick around)
- Catastrophizing was not related to pain, but got used for pain, and has 3 factors to it
  - 1 – Amplification of pain
  - 2 – Rumination or repetitive thoughts about pain
  - 3 – Sense of helplessness or loss of control over your pain
- Catastrophizing is natural
- We get a lot of controversy in the field on this term because it has such a pejorative impact
  - And unfortunately, some of the docs have weaponized it against patient, “*Oh, you’re a catastrophizer, tragic.*”

**Catastrophizing has real neurobiologic consequences**

- When people catastrophize, when they have a loss of self-control, when they have rumination, it negatively impacts these prefrontal cortical circuits (these cognitive systems) so that they can no longer down-regulate your pain
  - They have abnormal connections to hypothalamic regions, which are key in [hypothalamic-pituitary-adrenal axis](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93adrenal_axis) (your HPA axis)
- In an acute situation, you get a release of [cortisol](https://en.wikipedia.org/wiki/Cortisol) for stress response
  - As a surgeon, it’s great, it keeps us alive
  - Chronically, terrible, and so you get this allostatic overload, and it starts to thin out that brain region
    - You’re no longer able to modulate, and it’s this worsening cycle that you get deeper and deeper in

Sean explains, “*A lot of what we do in pain is we try to break those cycles, and it’s not one thing*.”

- He uses the interventions, the procedures to help break an immediate cycle to get you on a path, and then it’s learning skills
  - We do this with other patients similarly

Peter emphasizes, “*That’s the very important point that I think shouldn’t be lost on this, breaking the cycle isn’t the cure. It sets you up to go after the cure.*”

Peter’s recovery

- He had to go through 2 hours a day of rehab for 6 months
- He had to learn how to move again correctly
- He had to strengthen the muscles that were going to make up for doing what my spine would no longer do

**⇒** But you couldn’t do that if you were in pain

- You had to learn to do that and you had to be at least pain-free enough to do it, but not push yourself too hard that you would reactivate the injury
  - There was a balancing act
  - You had to be able to sleep

***You had to be able to do all these things, and you had to be able to clear your mind and get out of that catastrophizing loop***

- Peter had the resources to do this
- Sean was reflecting on this when he was reading [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0)
  - In the early chapter, Peter described a friend’s mother
  - He told the story of this woman who had a shoulder injury and then went down this bad path: can’t golf, can’t garden, can’t do anything
- All Sean was thinking is pain

**This poor woman probably had severe pain that was untreated and it put her on a spiraling path**

*What happens in these situations*

- One thing we’re learning more and more about is **social functioning**
- We call pain a [biopsychosocial model](https://en.wikipedia.org/wiki/Biopsychosocial_model), but we tend to skip over the social (small “s”)

***Sean has done a lot of data analysis on his patients and social isolation, social functioning plays a key role in your overall pain and quality of life***

- Peter talks about this in his book from a social functioning standpoint
- Sean’s guess is this woman withdrew
  - She became deconditioned
  - She may have had a lot of fear-avoidance around moving her shoulder (which sets you up on a worsening spiral)

When Sean thinks about this woman and people as they get older

- We need to manage our sleep
- We need to manage all the things Peter put beautifully in his [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0)

> “*We also need to help them better manage their pain so that they can have the function and do all the things that you say so nicely in your book.*”‒ Sean Mackey

**Peter’s thoughts on this**

- Peter was asked recently to define healthspan [[episode #342](https://peterattiamd.com/agingwell/)]
- Healthspan is squishy to define because there’s a medical definition that Peter has repeatedly said he thinks is insufficient
  - The **medical definition of healthspan** is the period of time in which you’re free of disability and disease (so not very helpful)
- Peter prefers a more functional version of healthspan ‒ one of the lines is freedom from pain
  - It’s too long for him to rattle off

Peter explains, “*Just as it’s important to have strength, stability, aerobic efficiency, peak aerobic output, explosiveness, all of these things are going to reduce as you age. But the longer you preserve them, the better. One of them is freedom from pain.*”

- The data on elderly people who get a hip fracture and then spiral immediately downhill to death is so tragic
- Sean keeps thinking, if we could better help get their pain under control and address them from that holistic standpoint and just get them back to a level of functioning, would this story be written differently?
  - He’d like to believe it would

Sean asks Peter, “*When you went through all of this, you get through the rehab, did you feel a greater, one, understanding of your pain, what was causing it and the nature of your back, and what you could do and its safety?*”

- Yeah

**Another benefit of this experience is the ability Peter now has to help his patients**

- If you just look at the population and understand the ubiquity and frequency of lower back pain, and you realize, let’s say a third of people are going to go through some bout of lower back pain in their life
- A number of his patients have also been in the loop of chronic lower back pain

> “*For these patients, one of the most powerful messages I can deliver to them is learning that a setback is not permanent*.”‒ Peter Attia

- Remember, it’s not like, in the 9 months after Peter’s injury got better, he never had another setback, no
  - Within that period of time, he would have days where he felt bad again
  - Fortunately, he never went back to laying on the floor for days ‒ he never experienced that level of discomfort again

Peter shares, “*There were many days when I was very uncomfortable, and it would wax and wane. But over time, and with every time that I would recover from one of those cycles, my confidence would go up*.”

- The ability to know that this is going to pass
  - And I’m going to have to make some adjustments
  - I’m going to have to not sit
  - I’m going to have to change the way I lay
  - I’m going to have to do these exercises a little bit more
  - That’s okay, this will pass
- Peter just got an email from a former patient who said, “*Hey, Peter, just want to let you know, man, I have never forgotten what you said about this, and I just had a big setback last week and this would have normally taken me down the spiral to hell. And I hear your words telling me it’s okay, this will pass.*”
  - And a week later he was already on the mend

**Peter’s takeaway**

- There’s no difference
- It’s not impacting physiology; it’s impacting the psychology

***And the psychology is what goes onto impact the physiology***

**Peter tells patients**

- This is not going to be a monotonic improvement
- It’s going to look more like the S&P 500 where, if you step back 30 years, yes, it’s monotonically going up
- Look at it for a given week, not at all
  - It can go down
  - It’s quite volatile
  - Now, the volatility will decrease over time, but it never goes to zero

Sean comments, “*That’s a great story and it’s helped you be a better doc and help people.*”

## Sean’s struggle with cluster headaches, and the value of knowledge, preparation, and empathy in both managing chronic pain and caring for patients [2:39:15]

- Everybody has a story that is very different and personal
- Sean doesn’t talk about this much because he tends to be private
- He has suffered for as far as he can remember with [cluster headaches](https://en.wikipedia.org/wiki/Cluster_headache)

***It’s like a bomb going off in my brain***

- This will happen every 2-3 years
- It’s a classic fall, spring cycle
- All through his teens, his early adulthood, he’d get these 2 weeks of just terrible, the most insane pain he’s ever had
  - He’s broken a lot of bones in sports, and it was trivial compared to that
- Nothing he would do would work
- He’d occasionally go to the emergency department and they’d say it’s a sinus headache, and they give him antihistamines
  - Sure enough, they worked because it always went away in a couple of weeks

Sean remembers in residency

- Getting one of these in the midst of a cardiac anesthesia rotation and barely able to get the patient to the recovery room
- He just went into a call room and just hung out

**⇒** The thing is nobody knew what cluster headaches were

- Sean was scared
  - Every time these came on, he thought he had a brain tumor (and it was going to kill him)
  - You get really scared that it’s never going away
- He catastrophized
- After the end of a couple of weeks, he’s  like, “*What the hell am I going to do? I can’t work like this. I can’t live like this.*”
- Then he became a pain doc and I’m like, “*Oh, shit, I got cluster headaches*.”

**What a cluster headache is and how they’re treated now**

- A cluster headache typically manifests as headaches that last anywhere from upwards of a couple of hours
  - They can occur 8 times a day to every other day
  - They tend to have these weird characteristics
- They’re under a class of [trigeminal autonomic cephalalgias](https://en.wikipedia.org/wiki/Trigeminal_autonomic_cephalgia)
  - Fancy term for simply meaning that you get eye tearing, redness in your eye
- Sean gets what he refers to as a sticky eye sensation: his eyelid gets heavy and it droops
- He gets nasal congestion
- One of the major characteristics is extreme agitation
  - Meaning Beth would say, “*Well, you better to lie down*,”
  - He’s like, “*No, it doesn’t matter,*” and he just paces until it goes away

**What Sean did in the period of all this fear**

- He learned every damn thing about cluster headaches, every single thing

Peter asks, “*How many people get these? What percentage of the population?*”

- It’s one of those rare conditions that affects men more than women
- [One [study](https://www.frontiersin.org/journals/pain-research/articles/10.3389/fpain.2024.1373528/full#:~:text=The%20lifetime%20prevalence%20of%20CH%20is%20stable%3A%20approximately%201%20in%201%2C000%20persons%20suffer%20from%20CH) says the lifetime prevalence is 1 in 1,000 persons]
- It’s less prevalent than migraines

**Common treatment for cluster headaches**

- There’s abortive and preventative treatment
- Preventative treatment: [calcium channel blockers](https://en.wikipedia.org/wiki/Calcium_channel_blocker)
- Abortive treatment: the typical migraine medications, the [triptans](https://en.wikipedia.org/wiki/Triptan)
- Sean has stockpiles of triptans and high-flow oxygen

*Prodromal phase symptoms*

- Before these happen, he gets this prodromal phase with weird appetite, sleep gets disrupted, and a sticky eye sensation
- Sean was giving a talk at the Napa Pain Conference, and he knew they were coming on, so he threw a tank of oxygen in the back of the car
- If you can abort these things in time, you can save yourself several hours of absolute agony
  - You can catch it in a half an hour

**Sean’s point** ‒ through that journey of learning, he became informed and he developed self-efficacy

- So, when he got these attacks, when he knew what they were, ***he no longer had a huge amount of fear that would further amplify things***
  - He was fearful it was a brain tumor
  - He was a fearful like he was having a subarachnoid bleed
- He knew what it was
- It didn’t change the sensory dimensions of the pain, it didn’t change the agitation

***He knew even, if he didn’t catch it, it was going away in a couple of hours, and that gives you control***

- When these happen, he knows he’s prepared
- It’s going to be a shitty 2 weeks, and he buckles up, but he knows how to deal with it

> “*I know I’ll come out of it, and it makes a huge difference in quality of life, and that’s what I messages I would try to give patients is it’s about learning as much as you can about your condition, being informed and putting that to use, and ideally giving yourself a degree of self-efficacy over your health.*”‒ Sean Mackey

- When Sean listened to Peter’s story, it had parallels with his journey
- As a consequence, Sean has a lot of empathy for people

**Parting thoughts**

- We are certainly better off having a medical discipline that is devoted to pain
- It’s been 20-some years since Sean has seen Peter
- He remembers Peter was an intense guy
  - Peter replies, “*I’ve mellowed since then.*”
- Sean remembers thinking, “*This guy is either going to crash and burn, or he’s going to do something really awesome.*”
- Decades go by and Sean hears that Peter gave him a shout-out on one of his podcasts about Sean helped him
- This podcast is reaching so many people, and this is what we need more of
  - We need Peter delivering these messages that are empowering people (making a big impact)

---

## Selected Links / Related Material

**Open Payments CMS**: [Open Payments: Learn about the financial relationships that drug and medical device companies have with healthcare providers](https://openpaymentsdata.cms.gov/) | CMS.gov (2025) | [29:15]

**Sean’s studies on pain empathy**: [38:45]

- [Your pain or mine? Common and distinct neural systems supporting the perception of pain in self and other](https://pubmed.ncbi.nlm.nih.gov/19015105/) | *Social Cognitive and Affective Neuroscience* (K Ochsner et al. 2008)
- [The Decline in Task Performance After Witnessing Rudeness Is Moderated by Emotional Empathy-A Pilot Study](https://pubmed.ncbi.nlm.nih.gov/32733343/) | *Frontiers in Psychology* (G Gilam et al. 2020)

**Darwin awards**: [The Darwin Awards: Evolutionary Action](https://darwinawards.com/) (2025) | [41:00]

**Study of pain sensitivity to heat find a wide distribution**: [Genetic influence on variability in human acute experimental pain sensitivity associated with gender, ethnicity and psychological temperament](https://pubmed.ncbi.nlm.nih.gov/15157710/) | *Pain* (H Kim et al. 2004) | [50:45]

**Depression predicts likelihood of persistent opioid use after surgery**: [Self-loathing aspects of depression reduce postoperative opioid cessation rate](https://pubmed.ncbi.nlm.nih.gov/24964916/) | *Pain Medicine* (J Hah et al. 2014) | [1:47:15]

**Report on pain relief by the Institute of Medicine panel**: [Relieving Pain In America: A Blueprint for Transforming Prevention, Care, Education, and Research](https://nap.nationalacademies.org/catalog/13172/relieving-pain-in-america-a-blueprint-for-transforming-prevention-care) | *National Academies* (2011) | [1:49:15]

**RCT treating fibromyalgia with low-dose naltrexone**: [Low-dose naltrexone for the treatment of fibromyalgia: findings of a small, randomized, double-blind, placebo-controlled, counterbalanced, crossover trial assessing daily pain levels](https://pubmed.ncbi.nlm.nih.gov/23359310/) | *Arthritis and Rheumatism* (J Younger et al. 2013) | [2:09:00]

**Peter defines healthspan in this episode of *The Drive***: [#342 ‒ Aging well: Peter shares strategies for improving longevity with residents at a senior living center](https://peterattiamd.com/agingwell/) (March 31, 2025) | [2:35:45]

**Stanford Division of Pain Medicine**: [Division of Pain Medicine](https://med.stanford.edu/content/sm/pain.html/) | Stanford Medicine (2025)

---

## People Mentioned

- [Rene Descartes](https://en.wikipedia.org/wiki/Ren%C3%A9_Descartes) (1596-1650, French philosopher, scientist, and mathematician) [7:45]
- [Ron Melzack](https://en.wikipedia.org/wiki/Ronald_Melzack) (1929-2019, Professor of Psychology at McGill University and expert on pain, developed gate control theory) [44:15]
- [Patrick Wall](https://en.wikipedia.org/wiki/Patrick_D._Wall) (1925-2001, Professor at MIT and expert on pain, developed gate control theory) [44:15]
- [Eric Topol](https://www.scripps.edu/faculty/topol/) (Cardiologist, scientist, author, and founder and director of the Scripps Research Translational institute where he is a professor and chair of the Department of Translational Medicine) [1:13:45]
- [Keith Humphreys](https://profiles.stanford.edu/keith-humphreys) (Professor of Psychiatry and Behavioral Sciences at Stanford University) [1:39:15]
- [Jennifer Hah](https://profiles.stanford.edu/Jennifer_Hah) (Associate Professor of Anesthesiology, Perioperative and Pain Medicine at Stanford University) [1:47:15]
- [Ian Carroll](https://med.stanford.edu/profiles/ian-carroll) (Associate Professor of Anesthesiology, Perioperative and Pain Medicine at Stanford University) [1:47:15]
- [Jiang-Ti Kong](https://profiles.stanford.edu/jiang-ti-kong?releaseVersion=10.9.0) (Clinical Associate Professor, Anesthesiology, Perioperative and Pain Medicine, expert in acupuncture) [1:54:45]
- [Daniel Le Bars](https://www.researchgate.net/profile/Daniel-Le-Bars) (Emeritus Director of Neurosciences at Sorbonne University, Paris, France) [2:06:15]
- [Jarred Younger](https://www.uab.edu/cas/psychology/people/faculty/jarred-younger) (Professor of Psychology at the University of Alabama at Birmingham) [2:09:00]
- [Linda Watkins](https://www.colorado.edu/neuroscience/linda-r-watkins) (Distinguished Professor in the Department of Psychology and Neuroscience at the University of Colorado Boulder) [2:11:00, 2:19:15]
- [Mark Hutchinson](https://researchers.adelaide.edu.au/profile/mark.hutchinson) (Professor of Biomedicine and Interim Director of the Institute for Photonics and Advanced Sensing at the University of Adelaide, Australia, leads the Neuroimmunopharmacology laboratory) [2:11:00, 2:19:15]
- [Daniel Clauw](https://medicine.umich.edu/dept/cpfrc/daniel-j-clauw-md) (Professor of Anesthesiology, Internal Medicine/Rheumatology, and Psychiatry; Director, Chronic Pain and Fatigue Research Center at the University of Michigan) [2:19:00]
- [Albert Ellis](https://en.wikipedia.org/wiki/Albert_Ellis) (1913-2007, psychologist and psychotherapist who founded rational emotive behavior therapy, early proponent of cognitive-behavioral therapies) [2:31:30]

---

![](https://peterattiamd.com/wp-content/uploads/2025/04/sean-mackey-bio-seanmackey.jpg)

##### Sean Mackey, M.D., Ph.D.

Sean Mackey earned a Bachelor’s and Master’s of Bioengineering at the University of Pennsylvania. He then earned a M.D. and Ph.D at the University of Arizona. Then he moved to Stanford University where he completed a Residency in Anesthesiology and a Fellowship in Pain Management.

Dr. Mackey is a physician-scientist experienced in neuroimaging, psychophysics, public health, health policy patient outcomes, and medical education. He is the Redlich Professor of Anesthesiology, Perioperative and Pain Medicine and at Stanford School of Medicine. He is also the Chief of the [Division of Pain Medicine](https://med.stanford.edu/pain) and Director of the [Systems Neuroscience and Pain Lab](https://med.stanford.edu/pain/research.html). His research investigates multiple paths to understand mechanisms of pain and develop objective biomarkers. His ultimate goal is precision pair care, tailoring the best treatment to the patient at the right time and making that care broadly available. [[Stanford Medicine](https://med.stanford.edu/profiles/sean-mackey#bio)]

X: [@DrSeanMackey](https://x.com/drseanmackey)

Website: [Sean Mackey, MD, PhD](https://seanmackey.people.stanford.edu/)