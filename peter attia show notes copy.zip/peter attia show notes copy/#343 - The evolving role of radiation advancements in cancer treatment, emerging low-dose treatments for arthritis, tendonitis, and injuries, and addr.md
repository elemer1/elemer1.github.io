# #343 – The evolving role of radiation: advancements in cancer treatment, emerging low-dose treatments for arthritis, tendonitis, and injuries, and addressing misconceptions | Sanjay Mehta, M.D.

**Source:** [https://peterattiamd.com/sanjaymehta/](https://peterattiamd.com/sanjaymehta/)

---

Sanjay Mehta is a radiation oncologist with over 25 years of experience, and is currently the president of Century Cancer Centers in Houston, Texas (drsanjaymehta.com). In this episode, Sanjay explores the rapidly evolving field of radiation oncology, addressing common misconceptions about radiation exposure. He delves into radiation’s critical role in modern oncology, examining recent advancements that precisely target tumors while minimizing damage to surrounding healthy tissues and reducing side effects, with specific insights into breast, prostate, and brain cancers. Sanjay discusses fascinating international practices involving low-dose radiation therapy for inflammatory conditions such as arthritis, tendonitis, and sports injuries, highlighting its effectiveness and potential for wider adoption in the United States. Wrapping up on a lighter note, Peter and Sanjay discuss their mutual passion for cars and reveal how this shared interest first brought them together.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/sanjaymehta/the_Drive_public.png)

Play

#343 – The evolving role of radiation: advancements in cancer treatment, emerging low-dose treatments for arthritis, tendonitis, and injuries, and addressing misconceptions | Sanjay Mehta, M.D.

#343 – The evolving role of radiation: advancements in cancer treatment, emerging low-dose treatments for arthritis, tendonitis, and injuries, and addressing misconceptions | Sanjay Mehta, M.D.

1x15s30s

0:002:12:12

## We discuss:

- How radiation oncology became a distinct, rapidly evolving medical specialty [2:45];
- Defining radiation, ionizing vs. non-ionizing, and common misconceptions about radiation exposure [5:30];
- How radiation doses are measured, real-world examples of radiation exposure, and safety practices [9:00];
- Radiation doses from common medical imaging tests, and why benefits of routine imaging outweigh risks [14:15];
- Therapeutic radiation oncology: the evolution of breast cancer treatment toward less invasive surgery combined with targeted radiation [23:30];
- Modern radiation oncology treatments for breast cancer—minimizing risks and maximizing patient comfort and outcomes [27:15];
- How advances in radiation dosing, technology, and treatment precision have significantly reduced side effects [39:45];
- How breast implants affect radiation treatment [44:45];
- Radiation therapy for prostate cancer: advancements in precision, effectiveness, and patient selection criteria [48:00];
- Radiation therapy options for inoperable prostate cancer or those seeking alternatives to surgery, and a remarkable patient case study [55:15];
- How patients can effectively evaluate and select a high-quality radiation oncologist [1:05:45];
- Radiation therapy for brain cancer: the shift toward precise, targeted techniques that minimize cognitive side effects, and remaining challenges [1:08:30];
- The origins of radiophobia and how it influenced perceptions of radiation use in medicine [1:18:00];
- Treating chronic inflammatory conditions such as tendinitis, arthritis, and more with very low-dose radiation [1:23:45];
- Using low-dose radiation to treat spine injuries, scar tissue, fibrosis, keloids, and more [1:30:00];
- The current barriers preventing widespread adoption of low-dose radiation therapy for inflammatory conditions [1:35:45];
- The durability and versatility of low-dose radiation therapy in treating chronic inflammatory and arthritic conditions [1:40:45];
- Sanjay’s talent as a drummer [1:44:45];
- Peter and Sanjay’s shared passion for cars and racing [1:47:15]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Sanjay Mehta is a radiation oncologist at Century Cancer Center in Houston, TX, where he has been in practice for more than 20 years
- Peter wanted to have Sanjay on the podcast to talk about all things radiation oncology, but also to talk about the history and some of the misconceptions around radiation exposure and radiophobia
- We talk about some of the interesting applications that Peter only learned about recently that are common outside of the US that involve low-dose radiation to treat inflammatory conditions and athletic injuries
- Those of you who are interested may recall that because this podcast is called *The Drive*, Peter occasionally talks about cars
  - Peter and Sanjay met because of their shared passion for cars
  - This discussion ends with a little bit of a deep dive into cars

Back to the main point of this discussion, we talk about:

- The evolution of breast cancer [treatment], including the shift from radical mastectomies to more conservative approaches like lumpectomies and sentinel node biopsies
- We talk more broadly about the role radiation plays in modern oncology
  - How doses have changed
  - How advancements in targeting tumors while minimizing damage to surrounding tissues have rendered side effects much more rare
- Sanjay talks about the role of low-dose radiation for inflammatory conditions such as arthritis and tendonitis
  - How this approach is more widely used outside the US
  - Why it’s his hope (and Peter’s) that it becomes more adopted here in the US
- We speak about the history and misconceptions of radiation exposure, including radiophobia, nuclear accidents, and early uses of radiation

## How radiation oncology became a distinct, rapidly evolving medical specialty [2:45]

- This is the first time Peter and Sanjay are together not driving
- Peter is resisting the urge to talk about cars (until the end)
- Sanjay might be one of the most knowledgeable human beings on cars and the founder of MD Motörheads (Facebook group of doctors who are gear heads)
  - He’s always the bad on to have on the shoulder when you’re contemplating a new set of wheels or a new something for your car
- Sanjay is a radiation oncologist
- The bread and butter of what Sanjay does as a radiation oncologist is a black box to many people (Peter included)
  - Peter has much more familiarity with the medical side of oncology than the radiation side
  - It would be wonderful to understand more as that field has evolved a lot in the last 25 years
- It’s one of the youngest fields
  - It’s not steeped in some of the traditions that surgery and medicine are
  - It’s rapidly evolving and the technology has changed so much in the last decade or two

**When did radiation oncology become its own discipline, with its own set of boards and everything like that?**

- As a kid growing up in Houston, some of Sanjay’s friends were radiologists
- As an elementary school kid, he remembers CT scanning was pretty new in the 80s
- In the 70s and prior to that, it was just a fellowship
- Radiologists would have a [cobalt-60 machine](https://en.wikipedia.org/wiki/Cobalt_therapy) that they would train on for a few weeks and you’d do a few easy calculations and do some crude treatments
- Radiation oncology really came into its own starting in the 70s and more into the 80s
  - The [ACR](https://www.acr.org/Accreditation/Modalities/Radiation-Oncology) had a separate carve out
- Radiation oncology residency training is completely independent of diagnostics now
  - It’s an intern year followed by 4 years of radiation oncology
  - There’s just a little bit of overlap with diagnostics, but not a lot of diagnostic training just because there’s so much to do on the therapeutic side

## Defining radiation, ionizing vs. non-ionizing, and common misconceptions about radiation exposure [5:30]

**The idea of using low-dose radiation to heal injuries**

- A lot of people are going to be very interested in this idea
- And why aren’t we using low-dose radiation more to heal some of these nagging orthopedic injuries that people have?

**What radiation is**

- We can’t have that discussion without giving people some understanding of what radiation is
  - Peter wants to do it in a way that’s both rigorous enough that we can really get into some of the science of this
  - But also get into it gently enough that people that maybe don’t remember high school physics well enough can come along for the ride and not get lost

**⇒**[Radiation](https://en.wikipedia.org/wiki/Radiation) itself, the term itself has got a bit of a negative connotation, but basically it’s part of the [electromagnetic spectrum](https://en.wikipedia.org/wiki/Electromagnetic_spectrum)

![](https://peterattiamd.com/wp-content/uploads/2025/04/f1-sanjaymehta-1024x668.jpg)

**Figure 1. The electromagnetic spectrum**. Image credit: [NASA](https://science.nasa.gov/ems/,%20Public%20Domain,%20https://commons.wikimedia.org/w/index.php?curid=97302056) at [Wikipedia](https://en.wikipedia.org/wiki/Electromagnetic_spectrum)

- We have everything in the range of increasing energy of photons, which are just particles of light
- On the one end you have radio waves and microwaves, and the other end you’ve got ultraviolet
- And then you get into X-rays and radio waves
- In the middle of all that is the visible spectrum (you’ve got the rainbow, red, green, blue that we can see)
  - The human eye can only perceive a tiny little narrow spectrum
- These are actually wavelengths and energies, which are the very low end energies
- Both radio waves and microwaves are what they call [non-ionizing](https://en.wikipedia.org/wiki/Non-ionizing_radiation)

Discussed in previous podcasts with [Attariwala](https://cannabixtechnologies.com/about-us/management-advisors/dr-raj-attariwala/) from [Prenuvo](https://prenuvo.com/) [[episode #61](https://peterattiamd.com/rajpaulattariwala/)]

![](https://peterattiamd.com/wp-content/uploads/2025/04/f2-sanjaymehta.png)

**Figure 2. Types of electromagnetic radiation: non-ionizing versus ionizing radiation**. Image credit: [Spazturtle](https://commons.wikimedia.org/w/index.php?curid=45834629) at [Wikipedia](https://en.wikipedia.org/wiki/Non-ionizing_radiation)

**⇒** The bottom line is that the low energy stuff is non-ionizing and that cannot damage tissue

- That goes all the way up to visible light
- Then when you start going to the higher energy X-rays, that’s when you get both X-rays as well as ultraviolet light and then the higher particle stuff

**⇒** The higher you go in the energetics of the particles, the more likely it is that exposure to these packets of energy are going to cause damage to your DNA [ionizing radiation]

*Why is it that as the wavelength gets shorter, the energy gets bigger? (because that’s what’s changing as you go from radio waves to microwaves to visible waves to ultraviolet)*

- They are inversely proportional to each other
- Sanjay is not enough of a physicist to answer that question precisely
- Having said that, this is the characteristics of this
- That’s one of the big reasons why all the fallacies about your cell phone giving your brain cancer and all are fallacies
  - They’re fallacies because even having a cell phone on your ear for hours a day, it’s non-ionizing radiation
  - Standing too close to a microwave oven, again it’s non-ionizing radiation
  - That cannot damage your cells
  - The radio wave is too long; the microwave is too long (it doesn’t have the energy)
  - It can heat, but it can’t damage
  - It can excite the molecules, but it won’t actually eject an electron
    - Which is what would cause an ion to form, which is why it’s called ionizing
- The therapeutic radiologists deals with [ionizing radiation](https://en.wikipedia.org/wiki/Ionizing_radiation)
- Diagnostic radiologists deal with lower energy X-rays
- Therapeutic radiologists use the very high energy X-rays in our linear accelerators to treat cancer
  - The big difference there is kilovoltage versus megavoltage
  - But all of these are ionizing

## How radiation doses are measured, real-world examples of radiation exposure, and safety practices [9:00]

**How are these measured? How do we quantify them?**

- Peter has talked on the podcast a lot about calcium scores, CT angiograms, and PET-CT and how to dose those things [[episode #203](https://peterattiamd.com/ama34/#:~:text=over%20a%20CIMT-,Calcium%20scores%3A%20keys%20to%20understanding%20and%20interpreting%20a%20CAC%20score%20and/or%20CTA%20results%20%5B1%3A05%3A15%5D,-For%20many%20patients) after 1:05:15 and [episode #52](https://peterattiamd.com/ethanweiss/#:~:text=informed%20by%20science)-,Understanding%20CAC%20scores%2C%20and%20CT%20angiogram%20results%20%5B1%3A40%3A15%5D,-Physiologic%20test) after 1:40:15]

Radiation dosage terminology

- When talking about patient treatment, the main term is the unit called the [gray](https://en.wikipedia.org/wiki/Gray_(unit)) [symbol Gy]
  - That’s an SI unit that essentially is joules of energy per kilogram of tissue

**⇒** The gray is what they call the “absorbed dose” and that’s in tissue

- When you’re talking about exposure in the air and just in general exposure, it’s in the air, we usually use the term [sievert](https://en.wikipedia.org/wiki/Sievert) [symbol Sv]
- Both those terms for the most part are equivalent
  - It’s just that the sievert itself will take into account if you have different types of X-rays, different qualities of X-rays that have different degrees of potential to be ionizing, that they have a quality factor, you’ll multiply it by
- We use the term gray when we’re talking about, for example when treating a prostate patient: they’re going to get somewhere between 70 and 80 gray
  - But it’s fractionated into small daily doses as to be tolerable for the body

**⇒** When we talk about millisieverts (like we’re going to), that’s really just a measure of exposure, not absorbed dose in tissue per se

Peter asks, “*What’s the relationship between a gray and a millisievert? Is it a one-to-one relationship?*”

- Yeah, 1 gray = 1 sievert
- An old school term is rads (not the SI unit)
- 1 rad = 1 centigray and 100 rads = 1 gray
- And a sievert is the equivalent only it’s in air, not in tissue

Peter asks, “*So when you give 70 gray, you’re giving 70 sieverts or 70,000 millisieverts over the course of the treatment?*”

- That’s correct

**Examples of radiation levels to anchor this to things that are familiar**

- Living at sea level exposes us to 1-2 millisieverts of ionizing radiation a year
- At altitude, it could be double
  - If you live in Denver, it’s easily double or triple that
- Pilots who spends a lot of time traversing the North Pole might get another 3 or 4 millisieverts of radiation per trip
  - Which is typically how they’re going to fly, they’re not going to go all the way around the center of the earth
- Pilots don’t really have any limitation in terms of total exposure that requires them to be taken out of the air
- A lot of them, they’re forced to retire at 65
- But they don’t monitor the actual exposure to that level

***Even though pilots get a higher dose, there’s been no proven increase in cancer in those types of populations, even in flight attendants or anything like that***

- The same way that people in Denver and the people here in Texas don’t have any higher incidence of cancer

**⇒** The [NRC](https://www.nrc.gov/about-nrc/radiation.html) [recommends](https://www.nrc.gov/reading-rm/basic-ref/students/for-educators/08.pdf) that a person not be exposed to more than 50 millisieverts in a year

- That’s easy unless you’re getting a lot of diagnostic radiology or undergoing therapeutic radiation treatment

**For somebody like Sanjay who has to set patients up (or one of his techs), are you guys approaching that level of exposure?**

- Not at all
- It depends on what type of radiation we do
- Typically for [external beam machines](https://www.cancer.gov/about-cancer/treatment/types/radiation-therapy/external-beam), we’re doing it all remotely from behind a shielded wall
  - So the vault in which the machine is placed is custom-built just to shield based on the angles that the machine can move through
  - If there’s a direct angle where the machine is hitting a wall, that wall has to be built 10 times thicker than the walls where the beam can’t reach
  - So essentially our dose when treating remotely is close to zero
- We keep film badges, but it’s almost become kind of a joke that when we’re not doing brachytherapy (which is dealing with actual live radioactive sources), our exposure is super low (almost negligible really )
- But back when Sanjay was in residency doing a lot of GYN implants and things like that where you’re putting cesium or radium actually into the body cavities and you’re actually up there putting it in up close, we had a ring badge on
  - As a residence, we’d rotate every month, but if we didn’t rotate, some of the faculty actually got pretty high doses

Peter asks, “*Any idea what the sequelae of that was?*”

- Sanjay knows a couple of folks who did a lot of GYN therapy in the older days (in the 70s and 80s) where you could actually see [dermatitis](https://en.wikipedia.org/wiki/Dermatitis) on their hands from doing that just from the hand exposure
- One of his faculty members actually had a giant cell tumor of the bone in her finger
  - This is after decades and decades of doing it
  - It was a benign growth, but that was a real thing
- There was a lot of data out there, especially on people who were dealing in X-ray for dentistry and stuff like that back in the day when they didn’t have shielding or anything like that ‒ they would get dermatitis

***The most common thing you’d see is skin irritation in that sort of situation, dermatitis and even some chronic flaking and things like that***

## Radiation doses from common medical imaging tests, and why benefits of routine imaging outweigh risks [14:15]

**Peter is curious how much the radiation dose depends on the size of the individual**

*Does a person that is larger receive more radiation for the same test (like a chest X-ray)?*

***They certainly do because you have to use more energy to get into a larger person***

- Having said that, there’s 2 different things here
- What we normally deal with regarding dose to a tumor is the dose actually at that spot versus a whole body dose, which is a very different metric
- For someone who is getting 8 weeks of radiation for prostate cancer, their prostate may get 80 gray in 1.8-2 gray fractions per day
- But that’s literally only to a small volume roughly the size of the prostate gland itself

**⇒** When you even get just a few millimeters away from that, that dose gets cut in half and then it’s exponentially lower because the intensity of the radiation varies with the square of the distance

- So as you get even a couple of feet away, that goes down significantly
- Typically a patient who is getting 80 grays, if 80 gray was a whole body dose, that would obviously be lethal
- The whole body dose is more like a few milligray in that sort of situation

***We typically don’t see full-body sequelae or anything from doing even the heavy-duty diagnostic treatment***

**⇒** For the CT scan, we almost consider that negligible

- Sanjay is dealing with mega voltage, high dose cancer killing radiation
- A CT scan is going to be just a few millisieverts (or milligray), and that’s almost considered rounding error versus what they’re getting to the tumor area

**Radiation exposure from a chest X-ray**

- The NRC says to limit your annual radiation to 50 millisieverts
- You’ve got 2% of this just being alive because you go outside and are exposed to the sun
- If you fly a lot, that might get you up another 10%

*How many millisieverts is a chest X-ray for a normal-sized person?*

- It’s a fraction, probably <1 millisievert
- It’s significant
- People who are concerned about things like diagnostic **mammograms**, every year you’re still talking about maybe 1 millisievert (or less with the newer machines)
- There’s a principle we talk about, **ALARA**: **a**s **l**ow **a**s **r**easonably **a**chievable
  - That’s been the mantra for our radiation safety people, the Nuclear Regulatory Commission and whatnot
- Having said that, when you’re talking about numbers of less than 50 millisieverts, that’s kind of an arbitrary number
- Sanjay shares, “*I should have maybe gotten a chest X-ray when I had my cough last time, but I just don’t want to do it because I don’t want the exposure.*”

***But it’s so minimal in terms of biologic effect that we really don’t even really worry about those, even if it’s getting one of them a month or so***

A lot of these numbers (especially the 50 millisievert number) are extrapolated from higher exposure rates

- There’s something called a [linear no-threshold model (or LNT)](https://en.wikipedia.org/wiki/Linear_no-threshold_model), and that’s been written about extensively and that’s what we’re all taught in radiobiology and residency
- One fourth of Sanjay’s radiation training and residency was actually radiation biology in addition to clinical oncology and radiation physics
- The linear no-threshold model is what states that we know based on all the data from nuclear fallout (from Chernobyl, from Three Mile Island, of course, from Hiroshima and Nagasaki from the bombs) that at a certain dose exposure, there’s a certain risk of developing a cancer or any other end point
  - Whether it be dermatitis or bone marrow suppression
  - All these numbers are well sorted
- But when you try to extrapolate lower, so you take maybe say a dose of one full sievert (a thousand millisievert), and you start extrapolating that lower and lower to where you’re looking at 100 or 50 millisieverts, the linear model assumes that there’s some level of damage even at those lower levels

**⇒** But in reality, there’s actually a threshold [that needs to be crossed for damage to occur]

- The LNT has actually been proven to be erroneous

***And so at very low doses, it’s actually been shown that there’s almost no incidence of any sort of biological damage***

- Additionally, there’s animal studies where there may be a [hormesis effect](https://en.wikipedia.org/wiki/Hormesis) at low doses like that (it’s controversial)

**Tell people what the hormesis effect means because we’ll come back to that later in the discussion**

- Regular listeners of your podcast know all about hormesis in the exercise realm and cold plunges and saunas and whatnot
- The whole idea is about doing some degree, a small amount of cellular damage, and when the body repairs that it actually comes back stronger than it was without the exposure in the first place
- In animal [studies](https://www.nature.com/articles/s41526-019-0074-3), they’ve actually shown at very low doses (we’re talking about single digit millisieverts here) decreased osteoclasts and increased osteoblastic activity in mouse bones
  - So the bones actually heal quicker
- Some of the soft tissue as well has been [shown](https://pubmed.ncbi.nlm.nih.gov/31704228/) to actually recuperate much in the way you see in hormesis from other causes

***That’s not something that we’re claiming is widely accepted, but there is a lot of data showing that that is certainly a possibility, which goes against this classic LNT model***

- The LNT model itself, the guy [[Hermann Muller](https://www.nobelprize.org/prizes/medicine/1946/muller/facts/)] that won the Nobel Prize for it in the 1940s did this all on fruit flies, and his work was disproven over the years after that
- Alot of this low dose radiation safety stuff we have, it’s certainly a noble goal to keep the dose as low as possible

***But when we get down to these millisievert range, the safety stuff is a little bit overblown in terms of the actual negative effects on the human body***

**Exposure from at CT angiogram**

- In the past, that would easily expose a person to 25 millisieverts to do a CT scan of the heart
- You’re doing it, slowing the heart down, getting the contrast in there, etc.
- Today the best scanners (really fast) are somewhere between 1-3 millisieverts for that same procedure
  - Peter certainly favors having patients getting a scan with that
  - Though he doesn’t have amazing data to say that the 25 millisievert one versus the 2.5 millisievert one (just to make the math easy, a 10-fold difference) poses any difference in risk
    - Sanjay agrees
- Sanjay goes back to that ALARA principle [as low as reasonably achievable]

**⇒** There’s not a whole lot of data at these levels

***Sanjay certainly would strive to keep it as low as possible, but he would go with the machine that has the best resolution, and doesn’t really care if it’s 25 or 2.5 millisieverts***

- He thinks the dose is pretty negligible
- These new scanners are faster, which is why they’re giving you less radiation, and they seem to have better resolution

**It’s similar for therapeutic radiation**

- The machines are called [linear accelerators](https://en.wikipedia.org/wiki/Linear_particle_accelerator#), and there’s a similar progression as we’ve been able to focus the beams more and more precisely
  - It’s a modulation of the beam, meaning you have a lot of photons being showered in the general vicinity of a patient, but you’re blocking out everything except for a small area to treat
- In the same way the newer machines definitely have a lower exposure [of radiation] in the room in general

**What should people be thinking about in terms of extraneous radiation?**

*When should people ask their doctors if they really need this (a dental X-ray every year)?*

- There’s nothing people should be worried about

***Sanjay certainly would not skimp on dental X-rays, mammograms, cardiac workups and things like that***

- The benefits of mammograms are so proven

> “*The risk-benefit ratio is so heavily in favor of doing these studies that I don’t even think twice about them*.”‒ Sanjay Mehta

- Sanjay has been doing this for 25 years
- By the time patients see him as a cancer patient, they’ve been through so many CT scans, PET scans, radioactive isotopes being injected into them and we don’t see [ill effects]
- Nowadays we follow-up with annual PET scans after treatment

The exception

- There are certain situations where’ you are giving an intravenous therapeutic dose of radiation, for thyroid cancer or things like that
- You have to be concerned because they can get into the sievert range

**What is the radiation exposure from a PET-CT?**

***50-100 millisieverts if you’re doing a whole body*** [***PET-CT***](https://en.wikipedia.org/wiki/PET-CT)

- Up until maybe a decade ago, the PET scan was independent of the CT (they would do them separately)
- But the data is so much better when you have the anatomical CT data overlay with the PET that whatever that extra dosage is, Sanjay thinks it’s well worth it
  - In terms of the resolution of what we’re able to see and what we’re able to gain from that information

## Therapeutic radiation oncology: the evolution of breast cancer treatment toward less invasive surgery combined with targeted radiation [23:30]

**Is it safe to say that the most prevalent or common type of radiation oncology treatment would be for breast cancer?**

***Breast and prostate are the #1, #2***

- Depending on what patient population you’re talking about, prostate may even be a little bit higher
- This goes back to the 80s when the trend from doing a [Halstedian type of radical mastectomy](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/halsted-radical-mastectomy) was falling out of favor
  - Randomized data obtained in the 80s showed that a lumpectomy (breast conservation), followed by radiation has the same outcomes in terms of overall survival as a full mastectomy
- That’s when breast radiation took off in the 80s
- Around that same time is when prostate radiation started becoming a thing
  - At the time, radical prostatectomy was still king
- Now, in the 2020s prostate radiation has taken off and is probably close to matching breast radiation

Other cancers treated with radiation

- We also do tons of CNS, lung, lymphoma, GI, not colon, but more rectal and anal distal GI cancers
  - Depending on where you are in the country and what your affiliation with the hospital is
- It’s a big part of the pediatric world (although we try to avoid radiating children)

***We use radiation for treating all types of cancer, all solid tumors***

**How breast cancer treatment has changed**

- Despite training at Hopkins, Peter never once did a radical mastectomy
  - It was already long gone from clinical practice 25 years ago

*Peter points out the difference between a radical mastectomy and a mastectomy (what’s called a modified radical mastectomy)*

- The current version of a mastectomy removes all the breast tissue along with the lymphatic tissue in the [axilla](https://en.wikipedia.org/wiki/Axilla)
- He did more than his fair share of those
- The radical mastectomy (the [Halstedian procedure](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/halsted-radical-mastectomy)) removed also the entire musculature of the pec (pec major, pec minor), the whole thing
  - It basically was a disfiguring operation that left the woman with nothing but ribs
  - Imagine what it’s like to not even have pec muscles: you take for granted what you need to do to move your humerus
- To think that it’s only been 40 or 50 years that someone had the courage, it was probably [Fisher’s](https://en.wikipedia.org/wiki/Bernard_Fisher_(scientist)) big [study](https://pubmed.ncbi.nlm.nih.gov/3883168/) in the 80s

*Current treatment*

- Even now the modified radical mastectomy is relatively rare
  - There are still some advanced cases that have to go that route
- Tons of patients are so much happier

**⇒** Their quality of life is much better by just having a simple lumpectomy, a central node biopsy

- And if it’s all negative, especially if they’ve had their mammograms, you get a small T1 or T2 tumor
- We give radiation to the whole breast following that

The radiation is fractionated into small daily bits

- They’ll get somewhere in the neighborhood of about 3 weeks of treatment, maybe 40 gray and roughly 15 fractions to the full breast
- A couple of decades ago, we were giving 50-60 gray
  - It was quite a bit higher dose

**⇒** With the modern technology, we can cover the breast tissue without a significant heart or lung dose

- We can even use tangential beams, even if it’s a left-sided tumor to stay away from the heart
  - Which is things that we couldn’t do very well in the past

***The overall and disease-free survivals are pretty much comparable to someone who had a modified radical***

**⇒** Peter recommends a chapter in [*The Emperor of All Maladies*](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/B007I0L91O/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.8NcMHV6Ok0eLnDKcprnEFF9egHbxD4OL0JRIwwRFA7JERnLd6wRqsNHKxO0dGbuVmOH7WT5QN3OxEe8MA2QkxAM8AyQpcxJTlbNGbd56pdoZP67Kb7q1-eY-6Juwh1P7BZ-4FazjXUVAhQ7F-rZRnyYRw2piKUG77ZEIlNnwu14U6pDo2oNA9tYW0wAUUY7wv86g_K5ukyYm4xs0_1JdJFpJ1tsVhx_Kgg_Qivyr5OY.qOrC_84rDYBPAQf6E7aspgW_e85xcwC3OXQCvmyi0Tw&qid=1739386587&sr=8-1)by [Sidd Mukherjee](https://siddharthamukherjee.com/about-siddhartha/) on this topic [the focus of [episode #32](https://peterattiamd.com/sidmukherjee/)]

## Modern radiation oncology treatments for breast cancer—minimizing risks and maximizing patient comfort and outcomes [27:15]

![](https://peterattiamd.com/wp-content/uploads/2025/04/f3-sanjaymehta.png)

**Figure 3. Cancer stage grouping**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cancer_staging)

**Is the treatment these days moving mostly to neoadjuvant chemo before resection?**

- Yes, in a more advanced case
- But if it’s a typical T1 (or even a small T2), they may not need any neoadjuvant therapy
- For example, if it’s a 1.5 cm mass, that’s easily resectable: they’ll remove that just without any neoadjuvant treatment and we’ll do adjuvant radiation
  - Then potentially, depending on the receptor status, [give] adjuvant hormone therapy, which is the domain of the medical oncologists, but radiologists still work with them
  - It’s surgery followed by 3-4 weeks of radiation

*How long after surgery can you begin radiation?*

- We give them a little bit of time for wound healing
- Generally, we do our CT based simulation a 3D planning, maybe 2-3 weeks after their surgery
- It takes about a week to do all of our computer programming

***We’ll start the treatment within 3-4 weeks post-op***

**Treatment for a hypothetical case of breast cancer**

- Lumpectomy is performed
- Sentinel node was negative
- There’s a 5-6 cm incision
  - They probably closed it with beautiful internal sutures and some steri-strips
  - They’re off in a week and there’s a nice little scar
- A week later the patient sees the radiologist

*How many weeks after that will the radiation treatment begin?*

- Sanjay will first see patients for a consultation ahead of time, prior to anything being done
- Then we plan on doing what’s called a planning procedure or a simulation where we’re going to put the patient on the table and essentially do a dry run for their treatment

**The planning procedure usually happens a couple of weeks after surgery**

- That involves essentially positioning the patient
  - Typically, for a breast patient, they’ll be prone with their arm behind their head (called the “movie star pose”) to get the arm out the way of the axilla essentially
  - Putting them in this position and then putting them on a wing board, that’ll slightly elevate their torso
  - And there’s a lot of different geometry here that we can use
    - Back in the old days, they had all kinds of ways of doing plaster casts and things like that
  - Now we’ll use what is called a **vac loc** (essentially a bean bag with a vacuum port) and the patient sinks into the bag
    - We suck all the air out of and lock it, it becomes a rigid cast of their body, and that way they fit into the groove that we’ve made for them
    - It will actually form molded around their elbow so they’re comfortable
- Many times with patients who’ve had an axillary dissection, they may have a little bit of scarring, a little decreased range of motion to be able to get their elbow back there
  - We’ll work with them the best we can

**⇒** Whatever position we get them in, we do a CT in that position and that’s the position we have to reproduce for the daily treatment

- And the key there is that when they have their arm out of the way, we have to have room so that the machine can move around from different angles
- The actual radiation machine has a gantry that can move 360 degrees
  - It can treat from any angle you want
- But we have to be able to model tangential beams
- We don’t want a direct anterior field that’s going to radiate the breast, but the photons are going to go right into the chest
- By using an angle, we can cut across the surface and actually shape the beam to match the curvature of the chest wall
- So we cover the entire thickness of the breast tissue
- Even in the case of an advanced (maybe a T4) patient, we may even do this post mastectomy

**⇒** You’re treating the full chest wall and we go a little deeper below into the ribs into maybe the first inch of lung tissue below that

- But by using these tangential beams, that really minimizes the treatment, the photons damaging the lung tissue

***All of that is planned ahead of time when we do a CT scan***

- This happens post-resection
- You’ll see a tumor bed
- The lumpectomy cavity is clearly visible ‒ it’s a fluid pocket on the CT
- He’ll scan the whole chest
- The planning takes about a week and a whole team
  - A radiation dosimetrist helps do the computer planning
  - A radiation physicist calibrates the machine prior to starting the patient
- The CT scan is two-dimensional slices, but we have three-dimensional modeling software
  - Sanjay has a full 3D model of the patient and can look at any angle

Peter asks, “*The slices are how thin?*”

- 2-3 mm, but it varies
- This is not a diagnostic scan or anything, he doesn’t need super high resolution
- Once the scan is reconstructed, he has a nice idea of what angles to bring the beams in at
  - Because every person has a slightly different curvature to the chest wall
  - You’re going to have to customize the anatomy, different breast sizes
- We have all kinds of different techniques (Sanjay won’t go too much into the details)
  - But if someone is very large-breasted, we could even treat them prone, using a special pillow to allow the breast to hang down

Peter reasons that where the tumor is in the breast is important for how it’s treated

- If you have a large breast and a superficial tumor, definitely prone would be amazing
  - The tumor bed is so far from the patient
- Technically, what radiologists call the **clinical target volume**, that’s the area they’re trying to radiate ‒ this would include the entirety of the breast tissue and all the way down the chest wall

**There’s 2 different ways radiation is used**

- 1 – Full breast radiation (what most people get)
- 2 – Partial breast radiation (targeting the lumpectomy cavity)
  - That is usually saved for older women who have a very small tumor
  - The remainder of the breast remains untreated
  - This is used for older women because a local recurrence is a little bit more likely in someone that has not had full breast radiation
  - But in a selected subpopulation of small breast cancers in someone with a very large breast, you can do partial breasts where you’re only targeting the lumpectomy cavity

***For most of Sanjay’s patients, he actually treats the whole breast as standard of care, plus or minus the axilla***

- That’s where the pathology comes in because if they did have a positive lymph node, then we have to go after the [axilla](https://en.wikipedia.org/wiki/Axilla) and sometimes the [supraclavicular](https://en.wikipedia.org/wiki/Supraclavicular_lymph_nodes) and even intramammary nodes in some cases

***This is definitely more involved than Peter thought***

**How long does each session take?**

***When they’re actually on treatment, it’s about 15 minutes (or less)***

- Some of the newer machines can deliver the beam even faster
- Sanjay will typically have 4 patients an hour
- So in and out of the room in 15 minutes
  - That includes getting them on the table

**⇒** The key thing for accuracy and reproducibility is positioning

- That’s the reason we made that mold
- Not only did we get them in position, but he’s also got a couple of dots on their skin to use as reference marks to make sure that the patient is in the correct position

***That whole [positioning] process probably takes 5 minutes every day when the patient gets in the room, and then maybe another 5-10 minutes for the actual beam to be on***

- Sanjay’s favorite thing is to come in the room after the patient’s first treatment, and then the most common question is, “*Hey doc, when do we start?*””
  - He’s like, “*No, ma’am, that was [it]*…”
  - They’re like, “*Really? That was it?*”

**⇒** Because the patient feels nothing

- So the machine will go through its various angles; it’s preprogrammed

> “*The entire process is about 15 minutes a day, and they can leave feeling the same as when they got there just like getting any X-ray.*”‒ Sanjay Mehta

- They jump in their car and go right back to work or to the gym or the golf course

**When did this become so automated with the robotic arm and stuff?**

*Did you do this in your residency or were you the ones manually doing that in residency?*

- Sanjay was in residence in the late 90s, early 2000s
- It was a very interesting time because we were at the cusp
- His first year of residency (1998 at UTMB in Galveston) was a combined rotation with MD Anderson we didn’t even use CT planning
  - We were at the end of the old era
  - We just had a couple of orthogonal films and we were literally drawing our tumor volumes out with a grease pencil on a physical X-ray and using that cutout to go trace a styrofoam negative and make a metal or a lead alloy block, which you would slide this aperture in the path of the beam
  - That’s the way it was done for decades
- By the end of residency, we had full on CT planning where now we’re doing a full CT scan doing everything virtually
- It’s far more precise and you can model multiple different iterations
  - Do I want a beam to come in from this angle?
  - Do I want to bring in an orthogonal beam from here?
  - Do I want to block out a little bit more of the chest wall to get the heart dose down?
- By the time Sanjay finished residency, we were basically doing what we do now
  - Albeit with much slower computers and just being in the infancy of that
  - It was probably more like 20-30 minutes per patient

***To answer your question, in the last 15 years (roughly), things have been much more automated***

- Instead of having lead blocks that you’re sliding into the path of the beam, now everything is shaped in the head of the beam by our computer
- So you hit a button, and he’s already programmed the treatment planning values, the machine knows how to shape the beam to match the aperture of whatever you’re trying to do
- That’s all fully automatic now
- We have a **radiation therapist** who actually positions the patient in the room
  - They get them in position, they take a picture X-ray first, either a cone beam CT (which is a low-dose CT) or just a PA in a lateral film
  - And we actually overlay that with our planning imaging to make sure that the original reference from the planning day matches today’s image
- The machines will superimpose the daily image with the reference image ‒ everything is automatic
- Sanjay can if we are directly on
  - If everything lines up correctly, then we literally have 2 images that look identical
- The table is motorized, so the patient will be laying there and they’ll feel it move just a few millimeters this way or that way until we have perfect concordance between the daily setup and the original

***That process has really improved our accuracy; and the regional miss (the geographic miss), which was a problem in the old days when we didn’t have digital imaging, is essentially gone now***

**What is the actual radiation beam (ions) generated by?**

- That is another thing that has changed

***In the last 30 years, most machines in the US are*** [***linear accelerators***](https://en.wikipedia.org/wiki/Linear_particle_accelerator) ***‒ these are artificially generated X-rays***

- It’s essentially accelerating electrons through a long vacuum tube
  - Essentially an electron gun, and at the very end of the tube you’ve got a tungsten target
  - The electrons hammer that target and then they shower photons out
  - You’re generating the x-rays that way
- Sanjay thinks Stanford had the very first medical linear accelerator in the US

*Prior to that, they were using these for atom smashers and they had the gigantic machines that we used for physics*

- They started in London, in ’53, and then I think in the late ’50s, Henry Kaplan at Stanford had the first one
- Essentially, we’re still doing that even today, 70 years later

*The key difference now is how we’re able to shape those photons once they come out of the machine now*

- When the actual photons are coming out, they’re completely unfiltered
- It comes out in a cone shape and it diverges just as any light source would
  - You know how when you hold a flashlight to a wall, you get a nice precise circle?
  - As you pull the flashlight away, it diverges

***We have filters and we have what’s called the*** [***multi-leaf collimator***](https://en.wikipedia.org/wiki/External_beam_radiotherapy#Multi-leaf_collimator) ***that can actually shape the beam to match the anatomy of the patient***

*That’s all done automatically*

- We program it ahead of time, as opposed to the old days when we had to use lead blocks that were actually physically blocking the beam

***Basically, the*** [***LINAC***](https://en.wikipedia.org/wiki/Linear_particle_accelerator) ***has been the standard***

- Prior to that, we were using a [cobalt-60 machine](https://en.wikipedia.org/wiki/Cobalt_therapy), it’s basically just exposing a patient to a radioactive isotope and then shutting the jaws again
  - Essentially, it’s not even a machine
  - Those are still in use in most of the world
  - There’s a few left in the US, but they’ve mostly been decommissioned now because the LINACs have taken over

**A typical treatment**

- Might be about 40 grays fractionated over 15 treatments
  - Roughly 2.5, 2.6 gray per day times 15 treatments = roughly 40 gray to the breast
- And then we usually do a boost, so we’ll give what we call a tumor bed boost, where we give a little extra dose to just the lumpectomy cavity itself

**⇒** There’s a couple of French trials that showed that adding an extra 10 gray over an extra 5 days (so 2 gray x 5) just to the lumpectomy cavity itself improves local control over just whole breast radiation

- The 40 gray is distributed uniformly across the breast and you have that extra boost, customized based on the patient’s pathology
  - Occasionally the breast surgeon will tell him that there is a persistent positive margin and they can only go so far
  - In that case, instead of giving a 10 gray boost, Sanjay might give a 16 gray boost (or so) to treat the potentially macroscopic residual [disease]
- Every patient is a little different
- The [axillary nodes](https://en.wikipedia.org/wiki/Axilla) themselves are normally not treated in an early stage patient
  - But depending on the risk factors, if it’s a very large tumor or if there was a positive sentinel node, maybe an incomplete axillary dissection, in many cases we end up treating the full axilla
- In some cases when it’s advanced disease, we end up treating level II and level III, so you end up getting the supraclavical [lymph nodes] as well

## How advances in radiation dosing, technology, and treatment precision have significantly reduced side effects [39:45]

**If we go back in time to 25 years ago, 30 years ago versus today, what are the typical side effects that a woman experiences from this treatment? And was she typically getting 40 Gray 25 years ago or was that a little more?**

Sanjay explains, “*This brings up a point I need to emphasize. It’s not so much the total dose, it’s the dose per fraction, so how quickly are you getting it?*”

- The standard of care was actually 50 gray rather than today’s 40-ish gray
  - But it would usually be given in 2 gray per fraction daily doses, rather than the 2.6, 2.7 that we’re using now
- When you take into account (there’s a whole radiobiology lecture that we’re not going to bore people with) the dose per fraction and the total dose, ***the biologically equivalent dose with the BED is roughly the same now***
  - Today 39.9 gray is given in 15 treatments
  - Versus the old 50. 4 gray that was given in, say, 25 to 28 treatments

***It was a longer process***

- We still do that in some cases

This comes back to the homogeneity of the dose

- Our goal is to have 100% coverage of the whole breast, but the reality is with the way that photons are going to be interacting from different beam angles and whatnot, you’re always left with hot spots and cold spots

***The biggest difference between what we’re doing now versus the old days wasn’t so much the total dose; it was the actual homogeneity***

- The heterogeneous old way of doing things with a cobalt machine (or with a low energy X-rays) unfortunately meant that there were hot spots and cold spots in the breast
- And that, of course, could either be manifested as scar tissue (if it’s a hot spot) or, heaven forbid, a geographic recurrence if there was an area that was under-dosed

**⇒** With modern computer planning, we are much more homogeneous

***Even though you may say 50 gray was given back in 1995 and now 40 gray is given, you’re now getting 40 gray in 2.5 gray fractions (which is equivalent to the old 50 gray); plus we don’t have a 150% hot spot and a 60% cold spot***

- We have a nice 100% match all the way across
- It’s like a CAD-CAM type of thing

> “*I’m about as close to an engineer as an MD can be*.”‒ Sanjay Mehta

- We actually simulate the dose distribution of the radiation in the tissue

***In modern days, we get a nice homogenous dose***

**What does the patient experience?**

- Maybe not so much 20 years ago

***But 30, 40 years ago with the older cobalt machines, they would get a terrible dermatitis***

- Many times it was moist [desquamation](https://en.wikipedia.org/wiki/Desquamation) confluently over the whole chest wall
  - Axillary desquamation was always bad because of the friction of the arm
- But with the modern treatment now with, first of all, not using cobalt, using linear accelerators, the energy of the photons is higher, which means the skin dose is slightly lower
  - So you’re getting maybe 100% on the skin, rather than 150% like you once did
- Now, we don’t see anywhere near the skin reaction that we used to

***Now, it’s more of maybe a grade one or a grade two*** [***erythema***](https://en.wikipedia.org/wiki/Erythema) ***(mild redness or maybe sometimes a little bit of sunburn), but nothing as severe as we used to get***

- These days, patients do still get a sunburn, and we give them free samples of Aquaphor
- They can use an aloe vera plant if they have it or just normal type of skin care stuff
- As opposed to the old days when were were essentially treating burn victims with silver sulfadiazine and heavy duty narcotics and things like that

***The modern era, it’s so much better***

- A lot of the patients, especially if it’s someone that doesn’t have a very large breast, they don’t get anywhere near the skin reaction
  - There’s less energy being put into a smaller-sized person
- That’s why, if you did have **a very large patient**, we actually still use the old 50 Gray in 25 because you’re giving less dose per day and you do have a very large breast, where you’re going to have areas that are going to have hot and cold spots
  - Sometimes that’s still needed, and we have to tailor it to the individual

**Did anybody ever look when you had the very disparate hot and cold spots and follow women for recurrence?**

- Yes

*Was there any association between the cold spots and recurrences?*

***There certainly is***

- The problem was in the old days, you didn’t have computer modeling
- Actually, you’ve got to give your hats off to those old-school physicists, to those guys that had slide rules ‒ you couldn’t really tell exactly where the hot and cold spots were
  - You had to go based on the fact you choose a photon energy and you know what the dose distribution at various depths is
  - You would try to minimize that by having beams coming in from different angles, and then by using multiple angles and multiple fields, you could paint in the dose as best as you could
- There were issues where, as you get deeper into the tissue, the dose would be lower
- This is before Sanjay’s time, but there were studies showing that there were geographic misses which sometimes would lead to a salvage mastectomy or something like that
- In the modern era, that doesn’t happen so much

## How breast implants affect radiation treatment [44:45]

**What is the impact of breast implants in this type of treatment? (either saline or silicone)**

- Either way, the X-rays we use, they are not at all affected by that because it’s essentially tissue-equivalent

Peter asks, “*Are those implants typically under the pec or between the pec and the breast?*”

- We see both
- Most of them are under the muscle
- Even now, plastic surgeons have different criteria for that
- If it’s under the pec, then it’s a little farther away and it’s not a huge issue
- The radiation will still affect that area
- Typically, these implants are pretty tolerant of that
- The only issue down the road is they may have a capsule or contracture or something from fibrosis

**⇒** The bigger challenge we run into is for our post-mastectomy patients who are going to be reconstructed and they have expanders put in, and that’s where the relationship between the radiation oncologist, the surgeon, and the plastic surgeon is key

**Explain to folks what expanders are, how that works surgically**

- Essentially what’s happening is when you have a full mastectomy, if a patient wants to have their breast reconstructed later on, the breast surgeon will remove the breast, but then the plastic surgeon will come in and place some sort of a placeholder to allow the soft tissue and all that connective tissue and the skin to stretch to allow for future implant placement
- Those tissue expanders, they can actually inject saline into them with a port and gradually stretch them with time
- That’s normally what they would do if there was no radiation involved

**⇒** Again, most mastectomy patients really don’t need radiation because this gets away from what we mentioned earlier, where breast conservation is lumpectomy only

- But there are some patients with a full mastectomy who are going to get reconstructed
- When they come in for their CT scan, they have this expander in place from the breast surgeon, so we have to modulate the beams
- We treat the entire chest while we make sure we’re covering everything, but simultaneously, we have to make sure that we don’t have those hot spots in the area of the expander where potentially you could cause scarring and fibrosis and cause the expander to have to be removed
  - A situation where the plastic surgeon would have to revise it
- We have techniques now to be able to keep the dose off of them
- Whether it’s silicone or saline, it’s roughly the same density
- But some of these tissue expanders have bits of metal in them
  - They may have other artifacts
  - When they are treated with photons (with X-rays), depending on what you’re hitting, the effect is based on the density, the atomic number of that tissue
    - Metal behaves very differently
    - Bone behaves differently from air
    - But when you’re in the spectrum of saline, tissue, water, it’s all basically the same

***We can model all that very much like when we have a prostate patient with a prosthetic hip, a piece of metal right next door, we’re able to compensate for that with the modern computer treatment planning systems***

**Do women experience any systemic symptoms from radiation like nausea or vomiting?**

- No, not at all
- The only time we see radiation patients who have nausea or vomiting, a lot of times for other sites, they may get concurrent chemo radiation where the chemo could be responsible
- But for breast, we don’t do concurrent [treatment]; it’s usually sequential
- The only time Sanjay really sees radiation-induced nausea is if he’s treating an esophagus or a pancreas or something that’s treating in the abdomen or somewhere along the GI tract where nausea is more of an issue
  - Typically not for breast

## Radiation therapy for prostate cancer: advancements in precision, effectiveness, and patient selection criteria [48:00]

**Which patients are typically being radiated?**

- That has been evolving
- As recently as 20 years ago, we only treated patients who were medically inoperable
  - Where the urologist would say this is a high-risk anesthesia patient
  - That’s a big reason why a lot of the older data was not as good for radiation (because of the patient selection criteria)

***In the modern era, as we’ve gotten more and more precise and our side effects have gone down and our cure rates have gone up, now it’s pretty much wide open where pretty much anybody who’s eligible for surgery would also be eligible for radiation***

- There’s not that big of a divergence as there once was

Sanjay has gotten to know [Ted Schaeffer](https://www.tedschaeffermd.com/) who has not only been on the podcast [[episode #273](https://peterattiamd.com/tedschaeffer2/) and others] but is equally interested in cars

**2 hypothetical patients come to see Ted**

- 1 – Has a Gleason 3+4
- 2 – Another patient has a Gleason 4+4 or 4+5

![](https://peterattiamd.com/wp-content/uploads/2025/04/f4-sanjaymehta.png)

**Figure 4. The Gleason grading system of prostate cancer**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Gleason_grading_system)

- [the Gleason grading system is explained in [episode #39](https://peterattiamd.com/tedschaeffer/#:~:text=Since%20Diagnosis%20%7C%20TODAY-,Gleason%20grading%20system%20%5B1%3A43%3A45%5D,-The%20Gleason%20grading) after 1:43:45]

*How does that patient navigate their way through the system as to whether or not they need radiation, or should they undergo surgery?*

*And does androgen deprivation therapy necessarily come with radiation, or is there a scenario where you undergo radiation but you don’t require androgen deprivation?*

- For high-risk disease (Gleason 8 or higher), [androgen deprivation](https://en.wikipedia.org/wiki/Androgen_deprivation_therapy) is standard of care
- Gleason 7 is a gray zone, and so a 4+3 with high-volume disease typically will also get concurrent and adjuvant androgen suppression along with radiation

**New tests are really changing treatment now**

- With the [Decipher score](https://www.veracyte.com/decipher-prostate/) where they can look at the chromosomes of the actual cancer cells and have a much more granular view of exactly
  - Are they truly high-risk?
  - Can you say that this 3+4, is more like a 3+3?
  - Sanjay has talked a lot about this with Ted
- For a lot of the 3+4s now with the Decipher test
- And there’s also an AI test called [Artera](https://artera.ai/), and Sanjay is using that
  - That’s actually in the [NCCN guidelines](https://www.nccn.org/guidelines/guidelines-detail?category=1&id=1459) now
  - The Artera test can help us differentiate between an unfavorable and a favorable intermediate risk patient
- Sanjay treated his own father not too long ago, and he was the first person Sanjay used these tests on

**⇒** The Artera test essentially just uses the actual images of the H&E slides that were already done from the pathologist, and it’s interpreted by a machine learning computer that has been trained on hundreds of thousands of prostate images from the old RTOG studies (all the stuff that was done back in the ‘90s)

***The Artera test can now come back and say (very much like Decipher) that this is a 3+4, but it’s a favorable or an unfavorable person in that subgroup***

- Because of that, we can stratify better and actually tailor it to where maybe a 3+4 doesn’t need androgen ablation at all
  - And maybe even some 4+3s if they come back low enough on the scale
- You always have to talk about the side effects and whatnot, but the standard of care was always to give concurrent androgen ablation for intermediate risk
- But now, we’re able to really take some of those people out of the equation with these new studies

Peter asks, “*Most patients just want things taken out, ‘I have cancer, take it out.’ Is the reason that a person might select radiation therapy (especially if it comes with androgen deprivation therapy) because of the sexual function and urinary function? What’s the main advantage?*”

- Those are #1 and #2 (lack of incontinence and lack of impotence)
- But when you have androgen ablation, that clouds things a little bit

***Typically, the #1 thing we see is patients who don’t want to deal with diapers***

- Sanjay doesn’t think he’s seen a single patient who came in continent and left with anything less than that
  - There’s no pads, nothing
  - Although incontinence is still described to some degree in the literature
- As he talked about with breast cancer, we can focus very precisely on the prostate itself

**⇒** The dose to the penile bulb, the dose to the rectum, the dose to the bladder are so low now that the side effect profile is essentially zero from a radiation standpoint

- They may be having hot flashes from the androgen deprivation and decreased libido and fatigue
- But on the radiation side, because we have all these tricks now very much like with breast, the way we can avoid the heart and the lungs
  - In the case of the prostate, we can almost completely avoid the bladder and the rectum and even the penile bulb now

***The quality of life reasons are why people tend to choose radiation***

Peter recalls, “*I know we’ve talked about this before, you’re just not seeing the* [*proctitis*](https://en.wikipedia.org/wiki/Proctitis)*.*”

- Yes, almost none
- Ted had mentioned in [[episode #273](https://peterattiamd.com/tedschaeffer2/#:~:text=The%20field%20of%20radiation%20oncology%20is%20evolving%20and%20they%E2%80%99re%20doing%20a%20lot%20of%20spectacular%20things%C2%A0) after 2:53:30], there’s a gel spacer that is often inserted
  - It’s an injection that’s done transperineally and it separates the rectum from the bladder
- But in Sanjay’s years of doing this, when you’re very diligent about how you do this
  - Very much like a surgeon pays attention to the details, so do radiologists
- Sanjay can actually trim the dose off of the posterior prostate and just make sure the dose fall off between the posterior prostate and the anterior rectal wall is so rapid
  - The anterior rectal wall is always going to get some dose, but usually it’s not clinically significant
- This is a daily thing (because we’re talking about treating patients for multiple weeks), so we coach the patient to come in with a full bladder and an empty bowel
- By being diligent about that and imaging daily to double check that in fact the bowel is empty and the bladder is full, that allows those two organs to separate from the prostate

**⇒** Even a few millimeters of separation is all we need to take advantage of our modern-focused radiation beams

Peter asks, “*Does the patient need to be coached to time their breath or anything as the beam is at that most delicate edge of the rectum?*”

- Not so much for pelvic patients, but we do that for **breast cancer**, especially left-sided breasts
  - Just to go back to that, you actually have a deep breath hold, which will get the chest wall away from the heart
- We do that in the case of thoracic tumors, but in the pelvis, the diaphragmatic position doesn’t really make any difference
  - It’s more about bladder filling and rectal emptying
- Sanjay gets that question all the time
  - From a [LASIK](https://en.wikipedia.org/wiki/LASIK) standpoint, there is a worry
  - That’s probably why Sanjay is still wearing these “Coke bottles”
- In the case of prostate cancer, the dose is given over the course of several minutes, and then each of those fractions
  - We’re talking about 1 fraction out of multiple weeks
  - So even if someone absolutely had a coughing fit or something like that, first of all, we’re watching them
  - We can stop the beam at any given moment

***Slight variations day to day and the biggest variations are going to be based on bladder and rectal filling***

- We take that into account when we’re doing the treatment planning, so there should really be no adverse outcome
  - What Sanjay will do is map out where the volume of the prostate is, and we will actually purposely expand that volume and treat the full dose of radiation, even a few millimeters outside of the prostate to make sure if there is any internal organ motion or anything like that, that we take that into account

***If someone’s coughing or something like that, we’ll just hit the pause button and get them reset, and ultimately it’s not an issue***

## Radiation therapy options for inoperable prostate cancer or those seeking alternatives to surgery, and a remarkable patient case study [55:15]

**What about patients that are inoperable?**

*First of all, what leads to a patient being inoperable, and how do they show up?*

- Typically, the urologists have already screened the patient
- Everyone’s first exposure is going to be to what the urologist tells them
- Luckily in this day and age, we have people much like [Ted](https://www.tedschaeffermd.com/), who are very open and who are very open to not just doing surgery, but who actually look at the other options and present everything to the patient
- A patient who maybe was medically inoperable will certainly come to Sanjay
  - But even somebody who maybe is on the borderline who wants to see both sides of the token
  - A general urologist will send them to a surgical specialist and to Sanjay, and we’ll go through all the pros and cons of everything

***Really, it comes down to 2 things: cure rate is key, but quality of life is equally important, if not more important for most people***

**⇒** Cure rates with our modern-focused radiation allow it to get such a high dose into the prostate, we can say that they’re essentially equivalent to surgery

> “*We don’t have that deficit like we did 20 years ago when our fields weren’t as precise. It was the shotgun approach versus our sniper approach*.”‒ Sanjay Mehta

- Now, because the cure rates are better, then it really comes down to the quality of life changes
  - And that’s where there’s a spectrum of things

Peter asks, “*Is this an apples to apples comparison? Because the patient who undergoes the robotic prostatectomy today does not go on* [*androgen deprivation therapy*](https://en.wikipedia.org/wiki/Androgen_deprivation_therapy)*. They get to walk around.*”

- On the podcast, Ted explained he’ll give surgical patients [TRT](https://en.wikipedia.org/wiki/Androgen_replacement_therapy) if they’re hypogonadal [[episode #310](https://peterattiamd.com/tedschaeffer3/)]

*Why does the patient after radiation therapy still need to be androgen-deprived if in theory the radiation is as effective as the surgery?*

- That’s a key point where it’s trading one thing for another
- You don’t have the incontinence
- You don’t have the short-term risk of impotence like there is from surgery
- You don’t have the penile shortening or whatever other sort of things that they have to deal with
- But you have to deal with hot flashes and decreased libido and whatnot
- Most of the patients who are intermediate or high-intermediate risk, if they end up not having a negative margin or a seminal vesicle invasion after prostatectomy, they’re still going to come in for radiation anyway
  - And they’re still going to need to be on androgen ablation
  - There’s a significant number

Sanjay adds perspective, “*We certainly treat a lot less Gleason 6 than we used to. We observe most of them.*”

- Even still, there are a lot of Gleason 6 folks today who choose to have radiation just because it’s maybe a little bit more aggressive form of watchful waiting
  - And in that case, there is no androgen ablation and they just glide through the whole process

**Has there been a trial of Gleason 3+3 watchful waiting versus XRT no ablation?**

- No, unfortunately there’s no actual trial; there’s just observational studies
- So you can’t figure out what the biases are

*What do the observational studies show?*

- All we know is that people don’t die from Gleason 6 disease
- Because quality of life, they do so well with the radiation, there is just less of a chance of it progressing to a 7
- And when they come to Sanjay, it’s interesting the different patient populations
- He also gets a lot of transplant candidates who need a renal transplant and they cannot get their transplant unless they’re cancer-free
  - This is not mainstream
  - Even if it’s 1 core of a Gleason 6, they’re ineligible for their transplant
  - He will certainly treat those guys, and he’s been following them now for the 20-plus years that we’ve been doing it
- Quality of life, they do so well
- And this way, they don’t have to worry about androgen ablation when they do become a Gleason 7

**Peter proposes an interesting and elegant study**

- Take Gleason 3+3s ‒ medium risk people based on family history, genetics, or some other phenomenon
- Randomize them to watchful waiting versus radiate them without androgen deprivation
- This would be a very long-term study
- Outcome #1: could be conversion to 3+7 requiring surgery and/or androgen deprivation therapy
- Outcome #2: overall survival

Sanjay explains why this study hasn’t been done, “*You would need decades to do a trial like that.*”

**Until a decade ago, Sanjay treated a lot of Gleason 6 patients**

- They were mostly sent for radiation

Peter asks, “*Why were they sent?*”

- A combination of different things
- People have different levels of tolerance for watchful waiting
- In the pre-MRI days, everyone had to have an annual biopsy, and that alone is more anxiety-invoking than radiation
  - Not to mention we see a fair number of folks with urosepsis and complications from that
- Now, in the MRI era, we don’t really see that anymore, but that was done very routinely
- And because the patients had so little proctitis and cystitis (especially in a Gleason 6)
  - Where Sanjay is not worried about pelvic lymph nodes
  - Not even really worried about the seminal vesicles

**⇒** The field is very small, which really minimizes the side effects because a full bladder, when it’s actually full, it’ll move superiorly and anteriorly where the dose is close to zero

- Most of these patients, they just laugh and say, “*I’m coming in from my daily treatment and I’m right back to my normal life again.*”

***In the absence of androgen deprivation, radiation has become very simple for prostate patients now***

**What fraction of Gleason 7s can do radiation without requiring androgen deprivation therapy?**

- 5 years ago, that answer probably would’ve been zero

***Now with*** [***Artera***](https://artera.ai/) ***and*** [***Decipher***](https://www.veracyte.com/decipher-prostate/)***, a quarter of them don’t need it if it’s a 3+4 with a low Decipher, low Artera score***

- This is still an evolving area where no one has the exact answer, but that’s what most people are doing nowadays
- Even some  4+3s that have low Decipher scores are potentially candidates to avoid that

The biggest change in this has now been our ability to do [PSMA PET scans](https://en.wikipedia.org/wiki/PSMA_scan) to follow up

- Otherwise, the extra androgen deprivation was more of a Band-Aid for not being able to see what’s going on afterwards
- Now, if someone has a recurrence and you do a PSMA PET
- Sanjay has a patient that had treatment 20 years ago with radiation, now he has rising [PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen)
  - Otherwise, he’d just be stuck with [ADT](https://en.wikipedia.org/wiki/Androgen_deprivation_therapy) for years
  - But now if he sees a positive periaortic lymph node on a PSMA PET, he can just treat that area (and very successfully)

***There’s no long-term data yet, but it seems to be working really well, similarly to how we would use a FDG PET to target a lung tumor in the past***

**What about these patients that show up with two spine** [**mets**](https://en.wikipedia.org/wiki/Metastasis)**? How effective is radiation there, given that that’s a favorite spot for prostate [cancer to metastasize to]?**

*Post-treatment, 3 years later*

- Palliative radiation does work very, very well
- It would be probably 5 treatments
- You can even do what they call [SBRT (stereotactic body radiation)](https://en.wikipedia.org/wiki/Stereotactic_radiation_therapy), maybe in a single fraction
  - It definitely is very good at, we joke that we just spot-weld that spot, where it’s not going to prevent something else from popping up elsewhere

***That’s extremely well-tolerated, and usually it’ll stop the progression at that site***

- There are people who had high-risk disease, and if they had a couple of spots like that at the time of initial diagnosis
  - It’s been shown that you can treat the oligometastatic disease if it’s in the bone only at the same time as the primary lesion, and the outcomes are actually not significantly worse if it’s just limited disease

Peter asks, “*W*hat *is a more favorable presentation? Oligometastatic to bone or oligometastatic to para-aortic-*”

- Bone for sure

**Exceptional cases of prostate cancer**

Sanjay had a patient with a PSA of 1900

- He looked just as good as Peter
- Sanjay actually took him on a TV show he did many years ago
- 65-year-old guy, Mr. Macho, had never been to a doctor in his life
- He was a widower who decided that he was dating a younger woman now
- And she’s like, “*If you want to be with me, you got to go get checked out*.”
  - Colonoscopy, clear
  - Blood work, clear
  - PSA 1,938!
- You would think that means the lab made a mistake
- Except his bone scan looked like a Christmas tree
- This was in the pre-PET era
- He had disease in every bone in his body with zero symptoms

***This is an outlier situation, but in that situation, you need lifelong androgen deprivation and chemotherapy***

- Back then, it was mostly [Taxol](https://en.wikipedia.org/wiki/Paclitaxel)-based therapy
- We didn’t have all the second-generation androgen ablation drugs that we do now, like [enzalutamide](https://en.wikipedia.org/wiki/Enzalutamide)
- When we saw that, he went and got chemo and got androgen ablation

***When he came back to see Sanjay, he was a fully functional guy, perfect shape***

- His PSA was down to 1.5 with just the systemic therapy
- At that time, we presented him to the tumor board
  - The decision was made to go ahead and treat his prostate as though he was a de novo presentation because all the bone disease had resolved
  - He did great
- He’s still alive and this is 12 years out ‒ doing great with zero side effects
- He’s on androgen ablation for life, so he’s certainly going to have issues from that
  - But overall, still very functional

Peter asks, “*How is this possible? What’s the biology of that tumor that allows him to still be alive?*”

- Sanjay doesn’t necessarily think it’s just prostate
- Even in breast cancer patients, he’s seen a small subset where it’s bone-only disease with no visceral metastasis ‒ some folks can live for a very long time with bone-only disease
- He’s not sure what the answer to that is (it’s amazing)

Peter asks, “*Has he suffered any debilitating fractures?*”

- You would expect that at this point, but nope ‒ not even one
- This guy is in his late 70s and is still active, still plays golf
- Peter hopes he still has that young girlfriend

Sanjay has seen many people with 4-digit PSAs who we gent them down (NED, no evidence of disease) for some window of time

- The highest Sanjay has seen is 7,500
  - That was a person that ended up passing away

Sanjay explains about the guy who was 1,900, “*I think a lot of it is a function of, just like any other type of tumor, he had all the other risk factors that were lined up. He was young, healthy, no other comorbidities, active*.”

**Ted has told Peter about some of the most terrifying cases that are the exact opposite**

- These guys show up with a low PSA of 1.9 who have rampant metastatic disease

Sanjay adds, “*That’s the thing, you get some of these really poorly differentiated cancers that no longer resemble their prostate progenitor cells. They’re very hard to monitor, and a lot of them don’t even show up on a PSMA PET scan.*”

## How patients can effectively evaluate and select a high-quality radiation oncologist [1:05:45]

**What questions should people be asking when they’re engaging with a radiation oncologist?**

*How can somebody find out if their radiation oncologist is practicing in Sanjay’s philosophy?*

- It’s difficult in terms of actual metrics, even for the surgeons
  - Ted has excellent outcomes, but it’s not like it’s a published series
  - The best surgeons are often treating the hardest cases (that’s a handicap)

***It really comes down to finding someone who’s got the experience***

- In Sanjay’s case, because he does so much prostate
  - Close to 7,000 cases
  - Probably 10,000 when you include the pre-image-guided radiation days

**⇒** You want to find someone who specializes in the area that the cancer is located in

- Sanjay may be extremely experienced in breast and prostate, but you’re not going to come to him maybe for a pediatric malignancy

> “*You have to find the right tool for the job. But you have to just interview your doctor. I don’t think there’s anything specific to radiation*.”‒ Sanjay Mehta

**⇒** Ask about complications

- Being very open with them in discussion
- Ideally, have someone come with you (maybe a family member that has some medical background) who can ask more specific questions
  - These days with the internet, you can do all kinds of research
  - In terms of when I’m talking about matching my volume of the dose distribution to exactly conform to the tumor volume, that’s something that’s very easy to talk about
- An educated patient, they can ask to see the actual computer simulations
  - A lot of Sanjay’s engineering patients do this
  - Sanjay will pull out the graphs and show them dose, volume, histograms of area under the curve for each organ
    - This shows the prostate dose area under the curve is huge
    - The dose of the bladder and rectum is super low
    - You can quantify that
- For a lay patient, it’s hard, it’s not easy to do that

**⇒** You have to go with your gut in terms of the person’s experience, and it all comes down to the initial consultation

- In the initial consultation, Sanjay will spend an hour with the patient and go through every little nuance of what could and couldn’t happen
  - His goal is to over-prepare them and have them be pleasantly surprised maybe when the side effects aren’t as bad, rather than the other way around

***It’s hard to find right person, but there’s a lot of good doctors out there***

## Radiation therapy for brain cancer: the shift toward precise, targeted techniques that minimize cognitive side effects, and remaining challenges [1:08:30]

- Sanjay treats for both primary and metastatic [cancer], but not as much as prostate and breast

Peter adds, “*The brain is such a sink for mets, A, it’s a source of a lot of primaries, but it’s also where a lot of cancer spreads. It’s often a place where you can’t operate.*”

- You can’t operate if it’s too close to the brain stem or something vital

**Talk about the history of radiation in the brain and the spectrum of everything from whole brain radiation to gamma knife and stereotactic and all sorts of things in between**

- The main differentiating factor for brain patients is whether it’s primary or metastatic disease
- Although primary brain tumors are relatively common, they’re dwarfed by metastatic disease
  - The vast majority of what most radiation oncologists see when you’re treating CNS is going to be usually lung based brain metastatic disease (especially [small-cell](https://en.wikipedia.org/wiki/Small-cell_carcinoma))
- In those situations, the trend used to be where everyone would get whole brain radiation
- But now with the advent of [stereotactic radiosurgery](https://en.wikipedia.org/wiki/Stereotactic_radiation_therapy), which is more focused precise radiation
  - The newer data shows that you can actually just treat the area of metastatic disease as delineated on an MRI scan
  - And not necessarily radiate the whole brain like we used to
- For decades, everyone got whole brain radiation, and for the most part they did all right

**⇒** The problem was you’re looking at a patient population that maybe doesn’t have that much of a life expectancy

- Now that systemic therapy, immunotherapy, everything has gotten better, especially in the case of lung patients, they’re living longer

***We have evolved where we’ve been finding people that were previously treated with whole brain radiation were having cognitive issues years down the road (not for the short term)***

- They would tolerate it well, but maybe they’d start to have more forgetfulness, an inability to remember numbers and names and whatnot
- We’re talking about 30 gray to the whole brain, given in 10 fractions of 3 gray each
  - 3 gray x 10 was sort of a standard thing
  - Peter reacts, “*Wow. This is a staggering amount of radiation*.”

Peter asks, “*Do you need to use way more radiation because that’s what you’re delivering to the brain? Is this an example of where the sieverts and the gray are very different because you have to get through the skull?*”

- No

***The only difference between sieverts and gray, in any patient, is going to be whether we’re talking about dose in tissue or coming out of the machine***

- With brain tumors, yes, the bone certainly is going to attenuate more dose, but what Sanjay is talking about is actually 30 gray into the brain itself (the actual brain tissue)
  - A little bit more than 30 gray is coming out of the machine
- The bone doesn’t do that much
  - It’s not like they’re wearing a football helmet or something
  - Photons can still pretty much go through everything
  - It’s not metal, so it’ll still go through
- For example, in a lung patient, it’s more of an issue when you have multiple different areas, you’ve got bone, soft tissue, and air
  - In that situation, you have to modulate the dose more

**⇒** In the case of a whole brain, it’s been found that the hippocampal dose is very much related to their cognitive deficits down the road

Now we have [IMRT (Intensity Modulated Radiation Therapy)](https://en.wikipedia.org/wiki/Radiation_therapy#Intensity-modulated_radiation_therapy_(IMRT)) and the newest form of IMRT is called [Image Guided Radiation Therapy (IGRT)](https://en.wikipedia.org/wiki/Image-guided_radiation_therapy); basically, those two terms go together

- This is also the magic behind allowing us to treat a prostate without burning the bladder and the rectum

**⇒** Using IMRT is kind of like an HDTV versus this 1960s black and white blurry set, where we can treat with multiple small pixels and high definition so to speak

***Now when we do a whole brain for multiple metastases, by using IMRT, you can literally, carve the dose out***

- Sanjay can map out the hippocampus and carve the dose out of there
  - You see these 2 cold spots on the hippocampi that really have a very low dose while still treating the remainder of the brain parenchyma

Peter asks, “*Are there other parts of the brain that you carve out and protect?*”

- That is the main one
- We will not necessarily completely carve it out because when you have multiple metastases, really the whole intracranial space is at risk (you have to cover everything)

**⇒** Believe it or not, 30 gray sounds high (which it is), but for a glioblastoma, we use 60 gray

- Granted, that’s not to the whole brain, that’ll be to either the primary mass (if it’s an unresectable patient) and then we will give maybe 46 gray to the peri tumoral edema
  - Then the rest of the brain is getting much less, hopefully, zero in many cases

**Do we know what the survival difference is for an unresectable glioblastoma with and without radiation?**

- It’s certainly worse
- There’s again, multiple confounding factors there because someone who’s unresectable probably has other negative issues as well
  - If they have poor overall performance status, they have neurologic deficits, whatever the reason the surgeon can’t operate, that makes it worse

***Yes, even then in that situation, you’re measuring survival in weeks to months, but it’s probably double with radiation than without***

- A lot of our [GBMs](https://en.wikipedia.org/wiki/Glioblastoma) though are resected, hopefully, fully resected in terms of, at least radiographic, the post-op MRI not showing any enhancement

**⇒** If you have someone that’s got a fully resected primary who’s a younger patient with not a lot of neurological deficit, they can live a couple of years

**Why is glioblastoma unsurvivable?**

- That’s the key question
- Sanjay and Peter are both [Rush](https://en.wikipedia.org/wiki/Rush_(band)) fans, and [Neil Peart](https://en.wikipedia.org/wiki/Neil_Peart) was lost to GBM as well ‒ there’s so many people that it’s taken away
- Sanjay thinks it has to do with the **invasiveness** of the fingers of the tissue
  - In terms of even when you think you’ve gotten the whole thing, there’s microscopic fingers that are always on the periphery
- And you can’t just radiate it indiscriminately like you can other parts of the body because it’s the brain

***There’s always a fine line you’re walking between causing necrosis of the brain versus letting the tumor recur (that’s the #1 issue)***

**We do have a new tool now, as far as radiation oncologists, in terms of treating CNS tumors, which is called** [**proton therapy**](https://en.wikipedia.org/wiki/Proton_therapy)

- There’s several centers in the country now
- [MD Anderson,](https://www.mdanderson.org/about-md-anderson/our-locations.html) where Sanjay is in Houston, has a huge one

***With protons, you potentially can have the dose go into the brain to a certain depth and not exit out the other way like an x-ray would***

- X-rays are like light, it goes right through you
- You may have a decreasing dose, but it’s kind of like a bullet: you got an exit wound going out

**⇒** With proton therapy, this is one of the areas where protons shine because you can actually modulate what’s called the [Bragg peak](https://en.wikipedia.org/wiki/Bragg_peak) of the physics of the protons to where it’ll go a certain depth and not go out the other way

- So down the road, hopefully, we’ll start to see improved survival
- So far it really hasn’t shown to be a huge improvement
- But there’s less integral dose to the rest of the brain
  - Especially important in pediatric patients where you’ve got children with growing skull bones, if you can avoid radiating the growing bone to cause a deformity later on, that’s huge

Peter finds GMBs to be such a frightening type of cancer and wonders if it’s going to require some sort of injectable immunotherapy or something

- You have to figure out a way to treat the brain systemically
- You have to mechanically overcome the blood brain barrier and come up with some sort of systemic treatment for it

**Today, how many patients are undergoing whole brain radiation?**

- Sanjay doesn’t know what the absolute number is, but it’s probably 10% of what it was 20, 30 years ago
- The original [studies](https://pubmed.ncbi.nlm.nih.gov/9809728/) out of Kentucky, that [Patchel](https://www.linkedin.com/in/roy-a-patchell-72b6028/) had done in neurosurgery, everyone used to get whole brain radiation following resectional metastasis
  - Or even if it was unresectable
  - There was some good data back then supporting that
- Nowadays, rather than whole brain, you’re usually going to do a focus treatment just to a smaller area

**⇒** Focused treatment in the brain to a smaller area is a universal trend, to give less radiation dose to a smaller volume

- Same thing in [lymphoma](https://en.wikipedia.org/wiki/Lymphoma), you want to treat just the enlarged lymph node and not the entire lymphatic axis
- It’s the same idea where you’re trying to minimize side effects
- Whole brain, we still use it in specific cases, like for example, [small cell lung cancer](https://en.wikipedia.org/wiki/Small-cell_carcinoma)
  - Part of their regimen is going to be once the primary has been treated, if they have a complete response in the thorax, prophylactic cranial radiation, only for small cell [PCI](https://en.wikipedia.org/wiki/Prophylactic_cranial_irradiation)
    - 20 gray, 5 fractions
  - It’s been done forever; shows an advantage to have lower disease recurrence

Peter asks, “*How much of a reduction in CNS* [*mets*](https://en.wikipedia.org/wiki/Metastasis)*?*”

- It’s a lot, probably 70, 80% reduction in CNS failures because they all fail there, otherwise
- Small cell, they just all do that, and at 20 grade they really don’t have too many side effects
- The caveat is always, an extensive stage small cell lung patient isn’t going to have a long-term survival
  - But at least they won’t fail in the brain
  - It’s a quality of life issue

Peter asks, “*This is done with every small cell patient, no matter how early it’s caught?*”

- If they have a complete response to primary treatment, yes
- Maybe there’s some nuances, but for the most part

**What is the gamma knife?**

- Instead of using a [linear accelerator](https://en.wikipedia.org/wiki/Radiosurgery#Linear_accelerator-based_therapies), a [gamma knife](https://en.wikipedia.org/wiki/Radiosurgery#Gamma_Knife) is actually using [cobalt 60](https://en.wikipedia.org/wiki/Cobalt_therapy) (mentioned earlier)
- But you have multiple small sources that can actually be used
  - Very high resolution cobalt, essentially
- You’re doing the same thing, but instead of using a linear accelerator based treatment, it’s using cobalt

Peter asks, “*Is that used anymore?*”

- There still are centers that use it
- It still works very well for what it is, but the focus is very narrow
- There’s a lot of children’s hospitals that are still using it

***But the linear accelerator (which is abbreviated LINAC), the LINAC-based stereotactic radio surgery for the most part has taken over from that***

- It can do all the same things and also have more flexibility to do more than just CNS
- St. Jude’s Hospital has a fantastic [PD-CNS program,](https://global.stjude.org/en-us/programs/transversal-programs/neuro-oncology.html) and they did have a gamma knife last time Sanjay checked

## The origins of radiophobia and how it influenced perceptions of radiation use in medicine [1:18:00]

- Peter wants to use this as a bridge to talk about using radiation to enhance tissue as opposed to eradicate a subset of tissue

**Does radiophobia stem from nuclear accidents?**

- Sanjay has done a deep dive into this topic this year
- This goes along with all these benign cases that he’s treating now ‒ they’re essentially, arthritis and tendonitis

***This radiophobia is largely a US space phenomenon***

- First of all, X-rays were discovered in 1895 by [Röntgen](https://en.wikipedia.org/wiki/Wilhelm_R%C3%B6ntgen)
- In 1898, there was the first case described of, actually, radiating both arthritis type things or ankylosing spondylitis or other arthritis and also tumors

***Even back then, we had no idea how it worked, but there were cases pre-1900 where radiation was being used therapeutically***

**⇒** Now 120+ years later, we have this divergence where Germany, the UK, and all of Europe are using radiation routinely for arthritis and tendonitis

- But in the US it seems to be a basic nuclear phobia of the Cold War

There’s a guy named [Jason Beckta](https://becktamd.com/) that has a really good [podcast](https://podcasts.apple.com/us/podcast/out-of-the-basement-radiation-medicine/id1637332267) on the subject

- He’s out of Vermont where Standard Oil, the Rockefellers and all had a massive lobby group that was actively promoting oil over nuclear power plants
- The amount of spread went from just the energy industry into just the general zeitgeist of the entire country
- At that time, the radiophobia just caught on, and it was bolstered by World War II and seeing what happened in [Hiroshima and Nagasaki](https://en.wikipedia.org/wiki/Atomic_bombings_of_Hiroshima_and_Nagasaki)

You’ve probably heard about the radium dial workers

- There was a movie; it’s called the [*Radium Girls*](https://en.wikipedia.org/wiki/Radium_Girls_(film))
- These are women in the 1920s that were using radioluminescent phosphorus paint to paint the watch dials
  - That was the only source of illumination they had then
- In order to keep the brushes very fine, they were literally dipping it in the radium paint and then after each brush, they were licking the brush to keep the tip real fine, and so they were ingesting bits of radium
- Radium is metabolized like calcium, so it was actually incorporating into the mandible and they were getting an osteoradionecrosis of the jaw and things like that

***All of these different phenomena added together became a big deal***

Prior to that, people were using radiation for all kinds of crazy things

- It was in suntan lotions and waters
- There was something called Vigoridine that they were using for [ED](https://en.wikipedia.org/wiki/Erectile_dysfunction)
  - You could, topical salves that had radiation in them
- There was literally no end to it
- Then when all this sequela started to come out that they thought, “*Hey, maybe this isn’t such a good idea,*” and that’s when things took off

**Now that we look back, the reality of it is that a lot of that was really overblown**

- Even those radium dial painters, which we hear about this from day 1 in residency training, there was only a small percentage, maybe 50 out of 1500 that actually had toxic sequelae (most of them didn’t)

Peter asks, “*Is there a way to quantify how much exposure they had to radiation?*”

- That’s the thing, they may have licked in different way
- It that era, what we’re talking about was probably a couple of millisieverts to that particular area, but it was daily for decades
  - It was probably a super high exposure
  - But when you spread that out over such a long period of time, that’s why most of them, actually, did very well (as a general trend)

**⇒** It’s not just the dose, it’s the dose over time and the denominator that matters a lot

- They even used to use radium internal nasal applications in the 1920-1940s
  - Essentially, a radiation equivalent of a tonsillectomy or adenoidectomy
  - It was done to something like 0.5-2 million children in the us and even in the armed forces
  - It was done routinely back then, and there’s been very few adverse sequelae that were reported
  - Sanjay doesn’t know what the dose was, but it was high
- There’s a lot of cases where the exposure based on our 50 millisievert rule (talked about earlier) it would just make people fall out of their chair

***The actual reality of it is that many times the actual end results aren’t as bad as we had expected***

*Peter wonders what the listeners are going to be thinking because we’re all so brainwashed into believing that radiation is horrible*

**Sanjay treated a guy who was involved in nuclear testing at Los Alamos in the 1940s**

- He’s passed away now, but when Sanjay saw him, he was in his 80s
  - This was in the early 2000s, 60 years after that
- They had very little monitoring back then, but he was close enough to feel the heat from a thermonuclear bomb
- By the time Sanjay saw him, he had had thyroid cancer
- As you would expect, he’d had 1 or 2 lymphomas
- Sanjay ended up treating his prostate

***He’d had at least 4 or 5 different malignancies, but the guy was as functional as most 80 year olds are***

- The guy was still walking and talking and doing just fine.

**When you look at the population studies that were done outside the blast at Hiroshima and Nagasaki**

- With the initial concentration, everyone dies from the thermonuclear energy
- But as you get several miles out, not only are the cancer rates, actually roughly the same as the background
- You, actually see again evidence of [hormesis](https://en.wikipedia.org/wiki/Hormesis)
  - Or maybe not hormesis, but some sort of radioprotection
- Where you have some patients where you actually have lower rates of leukemia and thyroid cancer when you get a few miles farther out than you did in the general population

**⇒** It’s all very much dose dependent, time dependent

***The human body is evolved to handle this to a larger degree than we realized; it’s more resilient than a lot of people give it credit for***

- Mammalian DNA, we came from the background of the animal kingdom where there was tons of exposure from natural cosmic rays and whatnot, and then our predecessors had to be able to survive
- Our DNA had to be somewhat resilient in order to get to this point

## Treating chronic inflammatory conditions such as tendinitis, arthritis, and more with very low-dose radiation [1:23:45]

**Radiotherapy for tendonitis**

- This first came up for Peter 2 years ago because of his Achilles tendon had just a little bit of tendonitis
- At the time, he did standard therapy, and it’s fine now
- Peter has sent a few patients to Sanjay who have similar injuries
  - High hamstring tendinopathies, Achilles tendinopathies

*How prevalent is this type of treatment in Europe? How prevalent is it here?*

- Prior to probably 1970 or maybe 1980, it was very prevalent, even in U.S.
  - It was very widely done
- But now, everyone that Sanjay has talked to about it [thinks] it sounds like he’s doing something experimental and radical

***If you go over to Germany, they do something between 20 and 50,000 patients a year***

- Again, going back to [ankylosing spondylitis](https://en.wikipedia.org/wiki/Ankylosing_spondylitis) papers in 1898
- It’s mostly observational studies
- There’s very few randomized trials
- Low dose radiation for tendonitis, osteoarthritis, plantar fasciitis, all the “itises” you can think of, bursitis

> “*A low dose of radiation has a similar anti-inflammatory effect to what you would get from a cortisone injection.*”‒ Sanjay Mehta

*Define the dose*

- 50 centigrade or 50 rads given 6 times over 2 weeks
- So 3 gray (0.5 x 6 = 3 gray) to the affected joint using a very low energy machine
  - You’re talking about electron beam radiation
  - This is, especially in the case of someone who’s got a hand

Peter clarifies, “*You were giving 40 gray total to a breast, and now for the Achilles, you’re giving 3 gray (6 fractions of 0.5 gray each).*”

**⇒** All 6 fractions combined is about the dose of 1 fraction for a typical cancer

- You’re giving it in a superficial fashion
  - Especially if it’s a hand, where you only have a couple centimeters of thickness

We use what’s called [electron beam therapy](https://en.wikipedia.org/wiki/Electron_therapy)

- The same linear accelerator when the electrons go and hit the tungsten target and make photons, if you remove the tungsten target, you just get direct electrons and electron energy can be modulated to where you can treat a superficial skin cancer
- You can treat a knuckle
- Sanjay can treat a temple squamous cell and not go into the brain

In the old days before they had linear accelerators (this goes back to the turn of the previous century), they had ortho voltage machines

- And these, basically, created kilo voltage X-rays, not the mega voltage x-rays we use now
- All they could do was superficial stuff back then, and that’s where it works very well
- The dosage has changed tremendously

**⇒** These days, the biggest data comes out of Germany, 0.5 gray 3x a week (Monday, Wednesday, Friday) for 2 weeks, just to the affected joint

***It has an anti-inflammatory effect very similar to either a cortisone shot or an NSAID***

- 6 treatment are given and then the typical German protocol is to wait 12 weeks

**⇒** Depending on the joint, you usually see between 60-80% success rate where the pain is markedly decreased (if not zero)

- After 12 weeks, the German protocol allows for a re-treatment
- And at that point you get up to 90+% success in terms of reducing pain
- This is for joint arthritis, tendonitis, bursitis
- [Plantar fasciitis](https://en.wikipedia.org/wiki/Plantar_fasciitis) is a really big one now ‒ Sanjay has probably done close to 70 cases this year

**Peter finds this remarkable as he had plantar fasciitis back in med school (25 years ago)**

- He went to PT and rolled on golf balls and did the usual thing
- It took months to get better

*Of the patients that are coming to see you with plantar fasciitis, how long have they been hurting?*

- Many times, for years
- Sanjay’s biggest cohort recently (still relatively new) has a couple of surgeons that were having trouble standing and operating
  - They literally couldn’t perform their normal duties
- 6 treatments to the fascia, and they’re walking like nothing ever happened

Peter asks, “*How long after the last treatment did it take [for the patient to see improvement]?*”

***In the case of plantar fasciitis, it was almost immediate, within a week***

- In other cases, especially when we do knee arthritis, if there’s a lot more pathology going on [it takes longer]

**Sanjay treated his own Achilles and it took two months or so**

- He was almost wondering if it was going to work or not
- He was his own first patient before he offered anybody
- A colleague in Florida had posted that he did his so Sanjay literally jumped on the table
- He knew this should work in theory
  - It was never taught in residency
  - He looked at all the German data (tons of it)
- Sanjay was his own personal case control study
  - He did steroids and [PRP](https://en.wikipedia.org/wiki/Platelet-rich_plasma) in his left Achilles
  - This later this past year he did the right side with only radiation (no steroids), and now he’s walking without a limp
- On the other side, the PRP finally did [work]
  - He had 2 [cortisone](https://en.wikipedia.org/wiki/Cortisone) shots and PRP in the left
- A year later he radiated the right
- Both of them are holding up pretty well so far

[**Ischial tuberosity**](https://en.wikipedia.org/wiki/Ischial_tuberosity) **pain is very common for runners**

- Very, very high hamstring tendinopathies is an area of huge interest for Peter
- Sanjay has only treated women with that and they’ve all had tremendous results

Peter asks, “*Is it the same protocol? It’s the three gray over six treatments over two weeks.*”

- Exactly

*Mechanism of action*

- For any type of an arthritis, you’re, essentially lysing all the macrophages and you’re eliminating that cytokine storm that would’ve normally resulted

**⇒** It’s very similar to what cortisone does, but the difference is it seems to be that it’s much longer lasting than a cortisone shot

- Not to mention the fact that you’re not necessarily violating the capsule
  - And in the case of an Achilles tendon, you run the risk of rupturing it with multiple injections
- So radiation is totally non-invasive ‒ you just get up on the table

***Most of Sanjay’s patients go right back to whatever they were doing, and many of them are actually quite athletic and they don’t take any breaks during treatment***

- They’re still working out

## Using low-dose radiation to treat spine injuries, scar tissue, fibrosis, keloids, and more [1:30:00]

**Is there any literature looking at this for spine injuries?**

- Peter is thinking of all the times that people are getting spinal [epidurals](https://en.wikipedia.org/wiki/Epidural_administration) for irritation of spinal nerves, herniated discs, things of that nature
- He’s wondering if there is any reason to believe this could have any efficacy there?
  - If indeed there’s some efficacy due to spinal injections or epidural injections (which there clearly is)?

***There is some data for spinal osteoarthritis, specifically ‒ it’s less robust than all the extremities***

- Sanjay has done a few cases and it’s actually worked quite well
- Medicare actually does reimburse for these things
- The issue with the spine is, it’s such a multifactorial area where if you’ve got a nerve root compression or a disc issue (he can’t fix that part of it)
- There is limited data that he’s seen out of Europe that did show some degree of relief, but it’s not the 80-90% that we quote for the extremities (it’s probably half that)

Peter asked, *Do you think it’s because of patient selection? If you knew you were dealing with a* [*facet arthropathy*](https://en.wikipedia.org/wiki/Facet_syndrome) *that should in theory respond well.* ”

- It should and it does
- Sanjay has done a few of those
- [SI joints](https://en.wikipedia.org/wiki/Sacroiliac_joint) seem to respond quite well

***The literature shows that low-dose radiation works well for hips, SI, joint, lumbar spine, those sorts of things***

- They’re just not as routinely treated
- There’s not as the level of experience that we do have with everything else

Peter asks, “*But your ability to center the beam is remarkable. You’re using the same high fidelity equipment, you’re using for rad onc*.”

- Same equipment

Peter asks, “*You can hit a pea inside if you want to.*”

- You could, but that’s exactly what you don’t want to do because you’re, basically, trying to eliminate all the macrophages in the region
- You’re, actually, better off treating larger fields
  - Just the exact opposite of what we do with cancer therapy
- And because the dose is so low, you’re not really gaining anything by being too cute with the small fields
- You actually want to treat the region ‒ it’s almost like an [abscopal effect](https://www.cancer.gov/news-events/cancer-currents-blog/2020/cancer-abscopal-effect-radiation-immunotherapy#:~:text=the%20early%201950s.-,The%20abscopal%20effect,-occurs%20when%20radiation) for the whole area

**If you’re treating somebody that comes to you and they’ve got an Achilles tendinopathy, usually there’s a point of maximum tenderness, but it usually hurts up and down the whole Achilles. How do you position the beam and are you literally hitting from mid-calf down to heel?**

- From the insertion in the gap
- In Sanjay’s case, part of the inferior [gastroc](https://en.wikipedia.org/wiki/Gastrocnemius_muscle) was painful too, so he treated that entire region
  - All the way down to the calcaneal insertion and even onto a little bit of the plantar surface of the heel
- Because again, when you’re talking about these super low doses of radiation, if it was a sarcoma of that area, he’d be treating tiny little area
- But over here, we want to treat the whole region
- Most radiation oncologists, if we talk to their **experience treating an extremity**, it’s usually for a sarcoma
  - That’s a whole different ballgame where you’re giving 60 gray to someone who’s had a sarcoma in their leg or something, and you have to worry about things like edema
  - You can have lymphedema of the distal extremity if you’ve radiated the whole circumference of a leg or something like that
- But with these **low doses**, it doesn’t affect any of that

*You treat large fields*

- It’ll be from the insertion of the Achilles all the way down
- If it’s a plantar fascia, the entire plantar surface of the foot

**Another thing that Sanjay sees a lot is** [**Dupuytren’s contracture**](https://en.wikipedia.org/wiki/Dupuytren%27s_contracture) **(which is not arthritis) and also the foot equivalent, which is** [**Lederhose disease**](https://en.wikipedia.org/wiki/Plantar_fibromatosis)

- Essentially, palmar or plantar fibrosis
- Radiation works well there as well, very well documented
- That requires a higher dose though
  - You’re talking about 3 gray per fraction, 5 fractions, and then you do it again after a few weeks
  - So 15, 15 ‒  it’s almost palliative cancer
  - Not a high dose, but that’s for fibrosis

**It works very well for** [**keloids**](https://en.wikipedia.org/wiki/Keloid)

- Sanjay gets teenagers with big old golf balls hanging off their ear after getting their ear pierced and things like that
- You’re treating the fibroblast
- In that case, you use 4 gray times 3 treatments of 12 gray
  - A relatively large dose per fraction
  - You can totally protect the brain

*Peter has seen patients with debilitating keloids. What does it look like after the treatment?*

- The treatment has to be adjuvant after a surgical resection
- If you just radiate an intact keloid, it’s not going anywhere
- You don’t have the DNA mechanisms of a weak cancer cell that can be wiped out
- It’s kind of like doing a lumpectomy
- But if the surgeon just did the resection, the keloid is coming right back
  - The fibroblasts go crazy and they roar right back

**⇒** In order to do it right, you have to do the first treatment the same day as surgery

- So you’re just not letting those fibroblasts get a chance to have any sort of a foothold
- Sanjay would literally arrange it with the dermatologist to do the resection, send them straight to him to get the first dose in that day
- And ultimately, the cosmetic outcome is as good as if they didn’t have radiation
  - You’ll see the scar wherever it is

**Acne scars**

- Sometimes we get kids that have had acne scars all over their chest that have these bumps everywhere and they were all resected flat and you radiate them, they just stay flat
- You don’t see any sort of dermatitis from radiation

**Peter’s takeaway**

- What’s amazing is there’s too many people that don’t know this
- There’s too many people that are walking around suffering
  - Either from something that’s cosmetically upsetting: like a huge keloid, especially on a visible part of their body
  - Or some nagging injury: tennis elbow, golfer’s elbow, Achilles tendinopathy, hamstring tendinopathy
    - These things nag for years, at times

**Prevalence of these conditions**

- The data was showing some like 1 in 7 people in the country are afflicted
- The socio-economic costs are massive
- This is also going to your whole quality of life and longevity bias
- We’re talking about something that can really affect someone’s ability to exercise at all, and it can lead to exacerbation of other medical problems

**Radiation therapy is covered by insurance**

- Earlier, Sanjay mentioned that Medicare is covering some of these things
- Private insurance for the most part also covers this
- A lot of times because it’s relatively new, Sanjay will have to get on there and do a peer-to-peer with the company, but he’s had no rejections at all
  - Even for the spinal ones, where there’s less robust data, but he’s gotten everybody covered

## The current barriers preventing widespread adoption of low-dose radiation therapy for inflammatory conditions [1:35:45]

**Do we need more radiation oncologists?**

*How are you making room in your practice to treat these patients when your cancer patients are probably ringing you off the hook as well?*

- That’s a big reason why it hasn’t caught on
- There’s a component of just, you’ve got 8 hours or 12 hours a day that the linear accelerator can run and we are busy with that [oncology]
- For superficial joints (not deep hip), you can use one of those old style ortho voltage machines that Sanjay mentioned earlier, like what they use in Europe
  - They still sell those here
  - There’s a company called [Xstrahl](https://xstrahl.com/xstrahl-200/) that still makes them, and they’re perfectly acceptable for all the joint stuff except for the very deep ones, like maybe a SI or hip joint

**⇒** You could have a small center set up and those types of machines don’t even require the shielding because the energy of the photons is very, very low

***It’s highly underutilized at this point, and the Europeans have shown us the way***

- It clearly works and America just has to catch up

> “*It’s truly exciting… the amount of immediate relief we’re seeing from all these inflammatory conditions right away, it’s a night and day*.”‒ Sanjay Mehta

- Patients come in one day, they can’t grip a doorknob or lift a gallon of milk out of their fridge, and after 6 treatments they can
- They think you hung the moon ‒ it’s an amazing thing
- Sanjay loves treating cancer patients
- It’s really personal and rewarding to tell someone they’re NED (no evidence of cancer)
  - Their PSA is low, their mammograms look good
  - That’s what has kept him going this long

**How can people go about finding this treatment?**

- If 1 in 7 of them are going to experience this type of injury that would benefit from this
  - Even if it’s 1 in 10, that’s a lot
- They can’t all come to Houston to see Sanjay

***It’s an uphill battle ‒ Sanjay has been going out and trying to bring awareness to the medical community in Houston, but there has been a lot of pushback***

- You  have orthopedic surgeons, podiatrists, hand surgeons who look at him like he’s crazy and ask, “*What are you doing? What are you talking about?*”
- Even if this works, the concern about someone who’s got knee arthritis that’s been nagging them and maybe they’re going to need a total knee [replacement] at some point ‒ they’re concerned that this is taking surgery off the table
  - Which it’s not, because it’s such a low dose
  - There’s been plenty of cases of surgery after the radiation (it’s not an issue)
- There is concern that you’re taking away from the podiatrist treating plantar fasciitis
  - Billing when they do those extra corporeal shock treatment and steroids and whatever

***It’s a different paradigm that would potentially be taking away [from current treatments] ‒ most doctors are very negative about it***

> “*I think that tide is going to turn just like anything else; it’s just going to take a lot of education*.”‒ Sanjay Mehta

- At the end of the day, Peter doesn’t think people with have the patience for turf wars
  - Doctor’s need to put the patient’s interest ahead of their own

**Many times this is an adjuvant for other things**

- Sanjay thinks you can have your cake and eat it too
  - If you’ve got a podiatrist that’s doing all these PRPs and other things

Sanjay is looking at starting a protocol

- He just treated a nurse in Houston who’s a NP who does stem cells off-label, but she does them routinely, and has quite a big practice
- They’re going to look at, maybe you can do radiation with adjuvant stem cell treatment
- Because it’s such a low dose, this may be the sort of combined modality thing down the road that we haven’t really approached where there may be options to do other things still

Peter points out, “*For Medicare to approve something is a huge bar.*”

**How are you getting Medicare to approve this? Are they basically acknowledging if Europe’s been doing this for a hundred years and it’s working (what’s their bar)?**

- That’s what it looks like

*What Sanjay treats*

- He has the C61 (which is the ICD code for prostate cancer), which is in most of his patients
- He has the osteoarthritis codes now
  - They just go right through typically without any sort of a problem
  - For some of the private insurances, you have to get on a peer-to-peer call, but all does is quote them a couple of the German studies
  - Unfortunately, we got a little bit of a setback because there’s only 2 randomized clinical trials, both heavily underpowered, poorly run studies, just not well done
- The randomized data may never come just because of the nature of this sort of thing
- But that’s not the obstacle anymore
- It’s really just public awareness
  - Just like a guy that doesn’t want a radical prostatectomy and wants radiation therapy for his prostate, he’s got to be his own advocate

**The data is out there, the information is out there**

- There’s a couple of [big Facebook groups](https://www.facebook.com/groups/1622748151282109)
  - One is Only Dupuytren’s Patients
  - They literally will post up, “*I’ve got this big nodule, what do I do? My surgeon wants to cut on me*.”
  - There’s a whole network now
- There’s a lot more of that education going on
- They’ve got big PDF files of doctors all over the U.S. that will do Dupuytren’s radiation
- Dupuytren’s is a little bit more commonly accepted, but as Sanjay is slowly talking to these folks, they’re going to migrate into their arthritis space as well

***Sanjay thinks it’ll come and the general public has nothing but great positive outcomes from this***

## The durability and versatility of low-dose radiation therapy in treating chronic inflammatory and arthritic conditions [1:40:45]

**Do we have a sense of the durability of this?**

- For example, Peter has a little bit of osteoarthritis at his AC joint on the right
  - It barely bothers him, but every once in a while, if he’s doing something really violent overhead, reaching for something, or plays a ton of football with his son, it’ll bug him for 3 weeks
  - He’ll take a little bit of Advil and it’s fine

Peter asks, “*If I did a treatment there, would it be done or am I doing this treatment annually? How would it work?*”

- There’s a lot of variability there, depending on what the actual anatomy that’s causing it
- If it’s just a straight-up osteoarthritis case with no physical structural issue
- Remember, Sanjay has only been doing this about a year, so he doesn’t have the 25 years of experience that he does with cancer
- But he’s talked to a couple of doctors who have been doing this routinely for 20 years in LA
  - One of them treated his own neck, shoulder, and spine
    - Sanjay thinks he’s at 15 years out
    - Anecdotal, he’s never had to retreat himself

**⇒** Typically, the German studies allow for 2 re-treatments

- Because the dose is so low, radiobiologically, Sanjay doesn’t see any reason why you couldn’t do it every few years or something
  - He doesn’t know about annually
- A knee that’s bone on bone, it might only last a month or may not even work
- But for other cases, like the hands ‒ it seems like it’s certainly longer lasting than any sort of cortisone shot

***Sanjay thinks months are very reasonable, and probably years for most people***

**What about non-osteoarthritis, like rheumatoid arthritis and things like that, is there any reason to believe that this could help with the debilitating injuries that those patients experience?**

- Sanjay has treated 3 cases of rheumatoid arthritis and 1 guy had a gouty arthritis
- It’s a systemic disease and cannot be cured with a local treatment
- But it works great on a single knuckle that driving them nuts

Peter asks, “*If a patient has rheumatoid arthritis where they’re really experiencing a lot of deformation in the hands, you think you can help that patient with the local part of it?*”

- Yes
- It won’t reduce the deformation necessarily because a lot of that is long-standing

**⇒** From a purely palliative standpoint, it works to reduce pain

**What are some other examples of where this could be used in terms of reducing reliance on NSAIDs or opioids or other things like that?**

- [Tennis elbow](https://en.wikipedia.org/wiki/Tennis_elbow) has become a big one
  - Sanjay is doing several of those

Peter asks, “*How far down the arm do you irradiate?*”

- This is based on the patient
  - If they palpate
  - If they’re getting pain down the [brachioradialis](https://en.wikipedia.org/wiki/Brachioradialis) and if it’s radiating further down, Sanjay will treat a larger field because bigger fields are better

**⇒** He’ll treat with 3 gray locally

- It’s to an area where there’s no vital organs nearby
- The total body dose is negligible
  - It’s like getting a CAT scan initially for the rest of the body
- He would treat definitely the joint capsule, a little bit of the distal [humerus](https://en.wikipedia.org/wiki/Humerus), and the proximal [radius](https://en.wikipedia.org/wiki/Radius) and whatever else
- But if it’s hurting larger, he’ll just treat a larger field
  - In that case, we use **opposed lateral beam**, so the patient will just lay there, the beam will come in from one side and rotate around from the other side and we treat them both, because that way we get the same type of homogenous dose we do with our cancer patients
- Sanjay has treated several piano players that have [De Quervain tenosynovitis](https://en.wikipedia.org/wiki/De_Quervain_syndrome) in their wrist, from when you’re stretching to play those notes
  - Sanjay is a musician as well, and all his musician friends are coming to him
  - The wrist pain is going away very quickly

> “*My biggest patient cohort so far are former patients because they don’t have radiophobia.*”‒ Sanjay Mehta

- After going through 80 gray for their prostate, this is a joke
- They’re bringing their wife with in
  - Half the time, the wives sit there for their daily treatment anyway and they start chatting in the lobby, so we do the wife’s hand the same time we’re doing the husband’s prostate

**Time between treatment and relief**

- For the most part, the hands, the wrists, the elbows, it’s very rapid
- In the case of the tendonitis (like Sanjay’s Achilles), it was a couple of months, but that’s not outside of the window of what we’ve been conditioned to expect from all the German studies

**⇒** It may not be as immediate of a relief as a steroid shot, but it does seem to be more durable

## Sanjay’s talent as a drummer [1:44:45]

**Sanjay is a remarkable musician**

- He gets together with a couple of doctor buddies to jam every week or 2
- One of them was a professional musician before becoming a cardiologist
- Back in the day, he had a full doctor band, a full 70s rock cover band called Ultrasound
- They used to play Journey and Rush and Led Zeppelin
- Recently, Peter regrets not seeing Rush during their last tour
- Neil was a genius

*Greatest drummer of all time, are you going  with Neil, are you going with Bonham?*

- Neither because Sanjay went to college at UT and opened his eyes up to the world of jazz
  - Jazz drummers can all drum circles around those guys in terms of pure technical ability
- But yeah, Neil and Bonham are both right up there on the rock side of things
- He would put Neil first
  - He’s partial to Rush and a lot of that has to do with their music
  - Neil was obviously an innovator, but as a 16-year-old Sanjay is sitting there trying to imitate every single note on his drum solos, everything like that
- The new generation rock guys are incredible, the guys that grew up with Neil as an inspiration
  - You’ve got 12-year-olds who can do this stuff in their sleep
  - And then all these math metal bands, you got Dream Theater and things like Animals as Leaders, some of these guys are doing things
- Sanjay prides himself as a drummer and being able to analyze the music really well
  - It’s getting to the point where it’s almost more math than music
  - It’s so intricate the modulation of the time signatures and things like that, it’s actually getting beyond where even he’s having trouble understanding it now

Peter asks, “*Can you appreciate it from an auditory perspective? Does it get too technical where it’s hard to appreciate and distinguish?*”

- It’s a fine line, because when you think about it, music is just math with emotion added in
- It gets to a point where some of it is not appreciable anywhere
- That’s where the jazz side comes in where it’s all about feel
- But even the jazz guys will be extremely talented in terms of their ability to feel the beat and have it be pleasurable to the ear, but they’re doing such intricate things
- When you can balance those two things out, that’s heaven: when you can have the emotional side and also have be technically challenging and not just playing straightforward stuff

## Peter and Sanjay’s shared passion for cars and racing [1:47:15]

**Peter and Sanjay met driving**

- At the [AMG Drift Academy](https://www.amgexperienceus.com/ontrack/drift)
- Peter ended up doing it because at the last second got a phone call from his driving coach, that he was going to be there and there was an extra spot in the advanced drift school
- Peter had already been to the Drift Academy with how friend Josh Robinson
- He was like, “*Sure, I’ll go… Well, this is the last time I ever do one of these schools*.”
- Sanjay thinks Josh’s school is 100x better
  - It doesn’t compare and it’s cheaper

Peter adds, “*If you want to learn how to drift, you go to the* [*Texas Drift Academy*](https://texasdriftacademy.com/?gad_source=1).”

- Sanjay wants to go to Minnesota with him and do that ice class
- Sanjay was a member at the AMG drift academy, and he got paired up with Peter in a level 2 group
  - He was like, “*Man, how did this guy get in here without even doing the level one?*”
  - Those cars with the automatic transmissions and the turbo lag, not the greatest for drifting

**You’ve been a car nerd your whole life. What is it about cars that has you as excited as you are?**

- Sanjay thinks about it in terms of every 3 or 4 -year-old boy is enamored by cars, but normal people just grow out of it, and some of us never do
- His dad certainly liked cars
- He taught Sanjay how to change the oil and whatnot, but he wasn’t a fanatic like Sanjay
- Sanjay was that 4-year-old who could tell you a car driving by if it was an Oldsmobile that had Cadillac hubcaps on it
- It just clicked; over the years, it was always just a nice release
- Being a mechanically oriented type person, if he didn’t do medicine he would’ve done engineering, which is why it’s so impressive

**What did you study in college?**

- Biology and a BA with art
- He did a lot of jazz studies at UT ‒ he was a music guy
- Engineering just seemed fascinating to him
- He was always interested in medicine from day one
- Really the mechanical side of things, like knowing that every car’s five gear ratios and what their torque converter lockup is and what their horsepower and torque is

**What posters of cars did you have on your wall?**

- Everyone had a Countach, right?
  - Sanjay never had a Countach; he knew they were cool
- He would have like a Callaway Corvette, Miami Vice Testarossa 928
  - He’s almost done with his old 928, getting it back on the road
- He had more of the domestic stuff, the stuff that was more attainable
- Fox-body Mustangs, the five liter Mustangs of that era are really cool
- C4 Corvettes, back in that era when they were state of the art
- He loved watching Knight Rider, so he thought Pontiac Firebirds were super cool

Peter just bought his youngest his first Lamborghini poster

- He’s mostly got sports posters on his walls
- They scrolled Etsy for hours picking out a poster and went with Huracan

Sanjay asks, “*Have you driven a Countach yet?*”

- Peter has not
- Sanjay has and describes it as, “*It’s one of those don’t meet your heroes kind of things. It’s cool, but it’s kind of a POS too. The bar has moved a long way since then. It’s for the experience.*”
- It’s enjoyable because of the 80s campiness in retrospect, but even compared to its contemporaries, you look at an 80s 928 Porsche or even a Testarossa, those cars are beautifully driving, long-distance cruisers, super comfortable, compliant suspensions, you’ve got good ergonomics
  - The Countach is so awesome because it has none of that ‒ it’s awesomely bad

Peter adds, “*I’ve driven a Testarossa. Have you ever driven an F40?*”

- Sanjay has not
- It’s a race car, you’re basically just sitting on the ground with a carbon tub around you

**If you could have 3 road cars, but you can’t sell them (you’re not making the decision based on economics), what are the 3 you want?**

- These are your 3 grail cars
- It’s going to sound like a cliche, but McLaren F1, how do you not pick that?
  - If Peter could only have one, that’s the one he wants
- Peter sent Sanjay the picture of him sitting on one
  - Sanjay was jealous
- Then there’s at least 10 that Sanjay could pick from and be happy
- One that he has a lot of experience with is the Ford GT, gen one
  - One of the all-time greats
- He would probably pick stuff that’s manual and somewhat analogs
- Porsche Carrera GT with an NA V10
  - They’re unobtainable now, but they were reasonable of just a few years ago, and there’s plenty of faster cars out
  - A Carrera GT today is going for about 1.7, 1.8
  - 10 years ago it was half of that
- A F49 is going for at least 3
  - 6, 7 years ago it was half that

Peter asks, “*Do you think this is a bubble or do you think these things are not coming down in value?*”

- They’re never making any more of those, it’s limited supply, demand is never going to wane for those
- When you look at other collector cars, like some of the pre-war stuff, it’s going down because the target market is all dying off (unfortunately), and those people aren’t around who appreciate that
- That may happen at some point; we’ll probably be long gone by then
- The McLaren F1 is unattainable
  - There’s so few of them
  - That’s in a completely different league than the other cars
- Even something like the Ford GT, they made 4,000 of them, it’s not that rare
  - A lot of them are gone thanks to lack of traction control
  - Sanjay doesn’t think they’ll ever go down just because that era
  - The gen two (the current Ford GT), which is a twin turbo automatic car, will ultimately be eclipsed in value by the old one even though right now there’s still more, they’re almost double or triple
  - He thinks it’s going to go the other way

**Where would you put the 959 on this list?**

- It’s right up there
- The only downside to the 959 is that it was so ahead of its time that essentially is what a modern Porsche is now.
- It’s super cool, you’ve got the 80s campiness, the looks, but it’s basically like driving a 993 turbo for the most part
  - It doesn’t have that NA V8 or V10 sound
  - It’s a turbocharged flat 6
  - At that time, there was nothing like it

*Did they have four-wheel steering as well?*

- Sanjay thinks it did
- It was modern: sequential turbos and even water-cooled heads
  - Even though those were all air-cooled Porsches back then, they managed to water cool the heads
- And now Canepa does a really cool version, the restomod version, but those never came to the US.

Sanjay asks, “*It was the Bill Gates rule. Did you hear about that?*”

- Sanjay doesn’t know all the details, but essentially he was able to get the gray market to passage for these cars for some loophole, and only after that were they able to import them into the US
- Of course, now that they’re older, you can get anything under a 25-year rule

**Sanjay likes  the oddball stuff like that that’s just unavailable**

- The 959, he would still put a click below the Carrera GT
  - Because of that naturally aspirated F1 drive V10 that just sings and the 959s motor doesn’t have that level of character
- Peter adds, the Carrera GT would be on my list of 3 as well
  - Most people listening to us now, if they’re not car nerds, wouldn’t spot a Carrera GT if it ran over their toes
  - It’s like a bigger Boxster
  - It doesn’t stand out at all
- Whereas if you saw a McLaren F1, you don’t need to know anything about a car to know you saw something special
- The same is true of the GT, the GT is absolute head turner no matter what
- The interesting thing to Sanjay is it’s really based on a 69s design (it was a tribute)
  - Camilo Pardo, who was the designer for Ford, who basically reinterpreted it for the 21st century, kept that original character but made it aero-friendly
  - He was able to use all these hard points from the old car, but make it modern, and basically upsize the car
  - It’s like 110% size of the original that you could actually fit 2 people in, because the original GT40s were tiny and they apparently generated tremendous front-end lift in Le Mans
- The modern one, Sanjay has actually run at the Texas Mile on an airstrip over 200 mph
  - It’s dead straight, they did everything right, without resorting to the modern cars with all the big wings and all the big downforce; it’s just well-balanced

**Of the modern cars, anything that you really, really fancy?**

*Let’s define that first wave of hyper cars in the 2015*

- When the LaFerrari, the P1, and the 918 came out, which is 2014 (10 years ago)
  - They call it the holy trinity

*From that era forward, what do you fancy the most?*

- At the time, Sanjay liked those cars more than he does now
- They’re a little outdated now with the hybrid technology
- Maybe he sounds like a Porsche fanboy, but the 918 was just stunning
  - Part of it was just the design, forget about the performance
  - It had an NA V8, high revving bespoke to that car, not in any other platform
  - The electric component was just the gee whiz thing of the moment, which of course made it ungodly fast
  - But that NA V8 and the way the exhaust sticks out of the back
- Peter has a friend who has, all in silver, a 959, Carrera GT, 918
- That’s like having F40, F50 Enzo, LaFerrari, same sort of thing
- All of those cars were amazing
- Since then, the interesting thing about that era a decade ago, that was probably the inflection point after which performance doesn’t matter anymore
- We’ve saturated performance; you’re traction limited at this point
- Not only that, you can buy a used EV, you can buy a Tesla Plaid that’ll do 60 in two seconds flat ($50 grand) that’ll smoke everything

**Tell everybody about the time you took your Tesla Plaid to COTA, how long did it take you to smoke the brakes on that?**

- When it was stock, one stop

***That means he came out of the pit lane and he’s going up to turn 1; he didn’t out lap***

- The first hard brake is going into turn one
- Sanjay’s buddy was in an SF90 (which is 1,000 horsepower Ferrari hybrid), which is basically the fastest Ferrari you could ever buy
- Sanjay was catching up with him in 20
- And coming down the front straight, he caught an SF90 in his daily driver
  - But he nearly rear ended him because the car was able to stop just barely for turn one
    - The brake fluid boiled at that point
    - The car was not designed to do that, unfortunately
- What’s interesting is you would say, it’s an electric car, it’s heavy, other electric cars don’t do that
- The Lucid (the Taycan), they actually have really good brakes
- At the time Sanjay didn’t realize this because they had been advertised as being track ready
  - They were talking about how it ran so good at the Nürburgring
- But he finds out after the fact that the factory brake fluid is DOT 3, which is low boiling point
  - He just boiled it
  - The car is designed for efficiency, low drag
- Peter didn’t even use DOT 3 in his simulator; he was running DOT 4 in the sim
- Sanjay predicts Peter probably boiled the simulator
  - A 5,000 pound machine stopping from 100
- Sanjay probably did 160 on the front straight
  - That time it was limited, he didn’t have a track
- The amount of BTUs that you’re trying to shed off of those brakes, just forget about it
- Thankfully it had regen braking

Peter asks, “The *brakes are fine if you put better fluid in?*”

- They’re better, they’re less terrible

**If you want to track a Plaid, are you going to need new brakes?**

- Sanjay ended up having a full Wilwood setup-up put on the car
  - All new rotors, custom ducting
- [Mike Dussault, Dussault Designs,](https://shopdusolddesigns.com/pages/about-us) actually bought a Plaid for himself
  - He’s the guy that built the Z06 Sanjay is driving now
  - He ducted it into the front brakes (basically custom brake ducts)
  - That car is sealed, the whole front end is sealed
    - It’s not meant for that; it’s meant to just be low drag

Peter asks, “*So you weren’t getting any air on them?*”

- Nothing at all
- He made custom ducting, and after that, the car was unbelievable because you could actually late brake and do really well

**What lap time can you do in a tripped Plaid now?**

- Here’s the problem, you can only get one solid lap before it starts pulling power due to heat to the battery
- Sanjay’s best was a 224
  - That’s at a 5,000 pound car that’s no weight taken out (this is a stock car)
  - He didn’t do any mods other than the brakes
- But that one stop at turn one, and the brakes are gone
  - Thank God he has regen, so he just literally nursed it; he couldn’t turn off
  - He goes through the S’s and he’s just 30 mph, whatever he got down, so the regen is enough to keep the car from completely just going off the tracks
- 30, 40, 50; coming through 9, 10 coming into 11
  - He’s not on the throttle at all, he’s  maybe going 40 mph
  - But coming down the hill towards 11, the regen has kept him from gaining any more speed
  - His right foot is on the floor, the fluid is boiled
  - So he had to go wide in 11 into the gravel, completely around
- And then that’s when he found out about all that and the McLaren Senna both taught him where all those orange squares are spray-painted on the Armco where you can have the emergency offs
- He literally went through the gravel, came with inches of the Armco at 11, and then just hobbled in
- After that, the next time out he put DOT 4, Castrol brake fluid in it and changed the pads, then it was good for maybe a lap
- Ultimately that still wasn’t good enough, so he did the big brakes

**Peter sees guys out there with Teslas, they’re clearly not pushing as hard as Sanjay**

- Or they’re mostly Model 3s
- The Model 3 is 800 pounds lighter
  - It’s not as fast, but it’s a way better track car
- Sanjay has got dozens of laps in Model 3s
- They do fine because they’re not making 1,000 horsepower and they don’t weigh 5,000 pounds
- They still will boil their brakes, but if you just do pads and fluid, that’s actually very desirable
  - Especially if it’s a little bit damp outside
  - Not much can keep up with you in a Model 3

***Autocrossers, they won national championships with just coilovers in a 4,000 pound sedan ‒ that’s where EVs have gotten***

**To answer the previous question**

- Sanjay did the brakes on the Model S, and then once that was done, that eliminated the brakes as the weak link
- But the battery, the cooling is still not there
- You’ve got guys spending tons of money

**Sanjay was looking at doing a really heavily modified Aero Tesla Model 3**

- Like Randy Pope’s drives
- It’ll only do a lap at COTA
- It’s such a high speed and high braking

***You can hot pit and go right back out and you can keep hot pitting, but you’ll never get a full lap time***

- But it’ll do just fine if you do that

**The next gen cars, the Porsche Taycan, even the Lucid Sapphire**

- Those cars, they’re just as heavy, just as powerful, and they can do it

**Have you taken the Taycan Turbo S out?**

- Sanjay did when it first came out in 2020
- At the time I was on stock tires and everything, probably 230-ish, right around there
- He probably sent Peter a video from John John Hennessy’s track
  - Sanjay had the Taycan, the Lucid, and the Plaid all lined up on the drag strip
  - He’s in a 750 horsepower Porsche that can run tens in the quarter, and the Plaid and the Lucid walked away from him like he was on foot

Peter asks, “*You just didn’t have the traction control?*”

- No, it didn’t have the power
- 750 horsepower versus 1100
- This was the old Lucid
- The new Sapphire Lucid has more, has 1200, but this was 1100, and it’s still a 10th or 2 behind the 1,000 horsepower Tesla
- They all have great traction, and they’re all all-wheel drive
- It’s literally just power to weight at that point
- Peter didn’t realize the Taycan Turbo S was only 750
  - When you stand on a Turbo S, if there’s a Plaid next to you, he will leave you like you’re not moving
- That’s like the Audi is a super fast car in the real world, but that’s why horsepower doesn’t matter anymore
- Sanjay actually had a Turbo before the Turbo S, which had steel brakes
  - Turbo S had ceramics
  - And even the Turbo would do it on all-season tires
- When the very first Taycan that came out, this was in the early days when VW was having to respond to Dieselgate
- You remember Dieselgate, that whole deal?
  - They hey had to build these electric cars and they had to go to states that were CARB (basically the California Air Research Board emissions compliant) because of all the diesel penalties they had
  - The first cars didn’t come to Texas, they only went to New York
- Sanjay got a non-Turbo S, a regular Taycan on all-season tires out of New York and on steel brakes
  - Porsche is Porsche
  - It was squealing in the corners in an all-season tire, but it lapped 20 minutes, no problem, brakes were solid, there’s just something about the German engineering there
- Having said that, the Lucid is now equally good, if not better, despite being a brand new non-legacy company who is not trying to build a track car
- The Lucid Sapphire is faster than a Plaid now
  - It runs eights in the quarter-mile, but it can actually track
- And even his old Lucid, can run 890s in a quarter mile
  - It can crack in sub-9 now
  - It’s several car lengths ahead of a Plaid, which is beyond bonkers
- You have to warn passengers
  - These cars now you can’t just accelerate on them
  - You have to say, “*Hang on, just put your head against the headrest before I concuss you.*”

**Peter’s favorite car post the holy trinity of 2014 is the McLaren Senna**

*How does the Senna stack up for you and what was your fastest lap time in a Senna?*

- The biggest limitation is the tires
- He’s seen guys run 2 flats in the Senna GTR
- A coach of his had run a 208 just barely even trying
- The street Senna on the Trofeo R, it under steers; it’s really just not meant for that
  - And it’s got tons of downforce, tons of braking, but it just doesn’t have the grip
- The best Sanjay did was a 215
- Peter thinks that’s insane for a street car with street tires
- At the same time, Sanjay is sure a pro could do better
- He’s thinking that Armco gets really close to a car of this value it could be a really bad day

**Where were you breaking into turn 12?**

- 150 even on Trofeo R’s
- McLaren doesn’t want you to put slicks on it, and so Sanjay violated all the rules and ended up putting a set of Pirelli tires off the Ferrari Challenge cars on it
- Slicks need camber, you can’t get much camber out of a street Senna, which to him was the most disappointing thing
- Whereas the GTR, you got 4 degrees
- Even without camber, when he first stopped on that back straight, completely stock Senna with just slicks on it, at the 150 mark he almost parked it in the corner
  - It was incredible
- Even with the Trofeo R to stop at 150 in a tire that drove him to Houston and back, the bandwidth of today’s tires, that’s a whole nother topic
- It’s incredible what even on an all-season Michelin can generate 1 G

**1 G is nothing anymore**

- In Sanjay’s library of thousands of magazines, 0.8, 0.9 was a huge deal 30 years ago
- Now you’ve got minivans that do that
- Even all-season shod sports cars that are heavy can do that on a regular tire
- The chemistry of these tires these days is unbelievable
  - And that’s not even on a Pirelli
- The Pro Mazda we’re 2.3
- AMG GT3 would last Sanjay at least 2 weekends
  - And that car was running 211s on hand cooks with just him driving it, so the pros are running faster than that

**The problem with the Senna street car is it’s too track for the street and it’s too street for the track**

- A 720s, which is mechanically identical without all the downforce, is a beautiful GT car
  - Drive it cross-country, you can store stuff in it, super comfortable
  - And on Hoosiers (not on Slick) and Sanjay changed that to steel brakes
  - That’s a 216, 217 car
  - It’s not that much slower
    - Faster than his old McLaren GT4
- That one he thinks Randy Pope’s could probably run close to that
  - Driver to driver, 3 seconds probably (and that’s all in the straights)
  - Because the GT4 car has close to half the power
- Sanjay cheated with his GT4, he tuned it
  - The 570S GT4 was already detuned from the street car, but you can tune the street cars as well
  - He pushed an extra 150 wheel just by tuning it, because stock turbos can handle that.
- It would go 175 on the back straight, whereas a regular GT4 can do 20 miles an hour less than that
- Even then, the 720S and Senna are identical on the back straight
- The Senna can stop later though
- In the 720 with the aftermarket steel brakes, pads, and a Hoosier (which is still a DOT tire), you could still break it a little bit after 200
- It’s not bad at all for a car that you can go shopping at the outlet malls in because it’s got a massive frunk
- The ride compliance, that’s the biggest thing about McLaren, so the Senna is more tied down, but they all have that active suspension that doesn’t use sway bars or springs
  - It’s all hydraulic; it’s all fully active
  - There’s hydraulic lines that diagonally connect the front right to the left rear wheel so the pressure in those lines combats body roll, so you can have it be a plush highway ride or you can have it be a stiff track car
  - The bandwidth is almost unobtainable in any other car

**Do you think McLaren is somehow underperforming relative to what they should be doing given both their quality as an automotive brand and as a racing brand?**

- Underperforming in sales? Yeah, they truly are
- A big problem is the lack of reliability
  - All the jokes about British electronics they all come to bear
  - Even the Senna would go into limp mode between 9 and 10, if you floored
- There was a Senna Fest going on with 20 on the track at one time
  - Some guys were just tooling around, so they were fine
  - But if you were hauling ass between 9 and 10, when you get a little bit of suspension droop, you go into limp mode
  - If you’re accelerating through that, I would literally-
  - Not the GTR, but Sanjay hasn’t tracked one of those

Peter asks, “*Is that a mode issue?*”

- No
- That was in track  mode
- It happened to Sanjay one time when he forgot to put it in track mode (it still did it)

***It’s a g-force related to suspension droop issue that just freaked out the computer***

- They had McLaren guys on site who were working on patches
- It made it less frequent, but Sanjay thinks it still happened after the patch

**Reflections on this awesome discussion**

- Sanjay appreciates the offer to come out
- What Peter has done in this community is unparalleled
- His lectures are better than almost all the CMEs because he has quality people on
  - And the way he phrases questions and parses everything
  - It’s understandable for a wide bandwidth
  - Everybody gets something out of them, and that’s hard to do
- Peter is hopeful that they delivered a lot of insight both to people who are obviously interested in radiation therapy for cancer (which unfortunately is going to be a lot of people), and then this other application around the treatment of inflammatory conditions
  - Which, again, inflammation lies at the root of so many other things
- And just in case anybody cares about a little drumming in cars, hopefully they got something too

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with radiologist Attariwala**: [#61 – Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology](https://peterattiamd.com/rajpaulattariwala/) (July 8, 2019) | [7:15]

**Bone benefits of low dose radiation (in mice)**: [Positive impact of low-dose, high-energy radiation on bone in partial- and/or full-weightbearing mice](https://www.nature.com/articles/s41526-019-0074-3) | *NPJ Microgravity* (R Bokhari et al 2019) | [19:00]

**Wound healing benefits of low dose radiation (in mice)**: [Low dose radiation attenuates inflammation and promotes wound healing in a mouse burn model](https://pubmed.ncbi.nlm.nih.gov/31704228/) | *Journal of Dermatological Science* (B Son et al. 2019) | [19:00]

**Fisher’s studies on less radical surgeries for breast cancer**: [26:00]

- [Ten-year results of a randomized clinical trial comparing radical mastectomy and total mastectomy with or without radiation](https://pubmed.ncbi.nlm.nih.gov/3883168/) | *NEJM* (B Fisher et al. 1985)
- [Eight-year results of a randomized clinical trial comparing total mastectomy and lumpectomy with or without irradiation in the treatment of breast cancer](https://pubmed.ncbi.nlm.nih.gov/2927449/) | *NEJM* (B Fisher et al. 1989)
- [Twenty-five-year follow-up of a randomized trial comparing radical mastectomy, total mastectomy, and total mastectomy followed by irradiation](https://pubmed.ncbi.nlm.nih.gov/12192016/) | *NEJM* (B Fisher et al. 2002)
- [Twenty-year follow-up of a randomized trial comparing total mastectomy, lumpectomy, and lumpectomy plus irradiation for the treatment of invasive breast cancer](https://pubmed.ncbi.nlm.nih.gov/12393820/) | *NEJM* (B Fisher et al 2002)

**Book about the history of cancer and evolution of its treatment**: [The Emperor of All Maladies: A Biography of Cancer](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/B007I0L91O/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.8NcMHV6Ok0eLnDKcprnEFF9egHbxD4OL0JRIwwRFA7JERnLd6wRqsNHKxO0dGbuVmOH7WT5QN3OxEe8MA2QkxAM8AyQpcxJTlbNGbd56pdoZP67Kb7q1-eY-6Juwh1P7BZ-4FazjXUVAhQ7F-rZRnyYRw2piKUG77ZEIlNnwu14U6pDo2oNA9tYW0wAUUY7wv86g_K5ukyYm4xs0_1JdJFpJ1tsVhx_Kgg_Qivyr5OY.qOrC_84rDYBPAQf6E7aspgW_e85xcwC3OXQCvmyi0Tw&qid=1739386587&sr=8-1) by S Mukherjee (2010) | [27:00]

**Episodes of** ***The Drive*** **with Ted Schaeffer**: [48:45]

- [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) (February 4, 2019)
- [#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer2/) (October 2, 2023)
- [#310 – The relationship between testosterone and prostate cancer, testosterone replacement therapy, and tools for predicting cancer aggressiveness and guiding therapy | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer3/) (July 22, 2024)

**Decipher score (genomic test for grading prostate cancer)**: [Decipher Prostate Genomic Classifier](https://www.veracyte.com/decipher-prostate/) | Veracyte (2025) | [50:00]

**Artera AI test for grading prostate cancer**: [ARTERA](https://artera.ai/) (2025) | [50:15]

**RCT of treatment of brain metastasis with radiation after surgery**: [Postoperative radiotherapy in the treatment of single metastases to the brain: a randomized trial](https://pubmed.ncbi.nlm.nih.gov/9809728/) | *JAMA* (R Patchell et al 1998) | [1:15:45]

**Jason Beckta’s podcast on radiation medicine**: [1:19:00]

- [Out of the basement / radiation medicine](https://podcasts.apple.com/us/podcast/out-of-the-basement-radiation-medicine/id1637332267) | Apple Podcasts (2025)
- [Out of the basement / radiation medicine](https://creators.spotify.com/pod/show/radmed/episodes/The-Trilogy-of-Radiation-Supervision-Welcome-to-Modernity-e2conpk) | Spotify (2025)

---

## People Mentioned

- [Rajpaul Attariwala](https://cannabixtechnologies.com/about-us/management-advisors/dr-raj-attariwala/) (Radiologist and Nuclear Medicine physician, founder of Prevno, owner of AIM medical imaging in Vancouver, and Chief Scientific Officer of Cannabix technologies) [7:15]
- [Bernard Fisher](https://en.wikipedia.org/wiki/Bernard_Fisher_(scientist)) (1918-2018, surgeon and pioneer in the treatment of breast cancer) [26:00]
- [Siddhartha Mukherjee](https://siddharthamukherjee.com/about-siddhartha/) (Cancer physician and researcher, author of [*The Emperor of All Maladies: A Biography of Cancer*](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/B007I0L91O/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.8NcMHV6Ok0eLnDKcprnEFF9egHbxD4OL0JRIwwRFA7JERnLd6wRqsNHKxO0dGbuVmOH7WT5QN3OxEe8MA2QkxAM8AyQpcxJTlbNGbd56pdoZP67Kb7q1-eY-6Juwh1P7BZ-4FazjXUVAhQ7F-rZRnyYRw2piKUG77ZEIlNnwu14U6pDo2oNA9tYW0wAUUY7wv86g_K5ukyYm4xs0_1JdJFpJ1tsVhx_Kgg_Qivyr5OY.qOrC_84rDYBPAQf6E7aspgW_e85xcwC3OXQCvmyi0Tw&qid=1739386587&sr=8-1))  [27:00]
- [Ted Schaeffer](https://www.tedschaeffermd.com/) (Urologist and prostate cancer specialist) [48:45]
- [Roy Patchell](https://www.linkedin.com/in/roy-a-patchell-72b6028/) (Emeritus Professor at the University of Kentucky and previous Director of Neuro-Oncology) [1:15:45]
- [Wilhelm Röntgen](https://en.wikipedia.org/wiki/Wilhelm_R%C3%B6ntgen) (1845-1923, German physicist who discovered X-rays) [1:18:30]
- [Jason Beckta](https://becktamd.com/) (Medical Director of Radiation Medicine at Foley Cancer Center and Assistant Professor of Radiation Oncology at Larner College of Medicine, University of Vermont; host of podcast [*out of the basement/radiation medicine*](https://podcasts.apple.com/us/podcast/out-of-the-basement-radiation-medicine/id1637332267)) [1:19:00]

---

![](https://peterattiamd.com/wp-content/uploads/2025/04/Screenshot-2025-04-04-at-1.12.03 PM.png)

##### Sanjay Mehta, M.D.

Sanjay Mehta completed his undergraduate studies at the University of Texas at Austin. He earned his medical degree at the University of Texas, Southwestern Medical School at Dallas. He completed an internship in medicine/pediatrics at UT Houston Medical School, MD Anderson Cancer Center and completed his Radiation Oncology Residency at UTMB Galveston. He was an assistant professor at UTMB St. Joseph Medical Center. Dr. Mehta is currently the president of Century Cancer Centers in Houston, TX. His practice specializes in a patient-centered approach using non-invasive treatment of cancer using Image-Guided Radiation Therapy (IGRT) and Intensity Modulated Radiation Therapy (IMRT).

Website: [drsanjaymehta.com](http://drsanjaymehta.com)