# #229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB

**Source:** [https://peterattiamd.com/understanding-cardiovascular-disease/](https://peterattiamd.com/understanding-cardiovascular-disease/)

---

In this special episode of The Drive, we have pulled together a variety of clips from previous podcasts about cardiovascular disease to help listeners understand this topic more deeply, as well as to identify previous episodes which may be of interest. In this episode, Peter highlights the importance of understanding [cardiovascular disease](https://peterattiamd.com/category/diseases/heart-disease-prevention/) and why early intervention is critical. He also provides a primer on lipoproteins and explains the fallacy of the terms “good cholesterol” and “bad cholesterol.” Allan Sniderman discusses the metrics measured in routine blood work – along with the limitations of those standard panels – before explaining why apoB is a superior metric for determining risk. Additionally, Tom Dayspring explains the causal role of apoB in atherosclerotic cardiovascular disease (ASCVD) and the therapeutic goals for apoB concentration, and Peter explains how early and aggressive lowering of apoB could change the landscape of cardiovascular disease prevention.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/understanding-cardiovascular-disease/the_Drive_public.png)

Play

#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB

#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB

1x15s30s

0:001:18:54

## We discuss:

- The importance of understanding atherosclerosis early in life [2:25];
- Defining ASCVD, its causes, and the role of cholesterol [8:00];
- Why early prevention of atherosclerosis is critical [13:45];
- Preventing atherosclerosis—two fatal flaws with the “10-Year Risk” approach [16:00];
- Intro to lipids and lipoproteins: why there is no “bad” or “good” cholesterol [23:00];
- Limitations of standard blood panels [35:45];
- How Mendelian randomization is bolstering the case for apoB as the superior metric for risk prediction [39:30];
- Therapeutic goals for apoB concentration [58:15];
- How early and aggressive lowering of apoB could change the course of ASCVD [1:10:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Welcome to another special episode of The Drive
- As the podcast is now over 4 years old, we realize we’ve covered certain topics in a variety of ways across multiple episodes
- It can be hard to piece together this information
  - It can be difficult for new listeners to be able to go back and keep track of information that’s been covered in great depth in previous episodes
- As a result, we wanted to release another episode that is a compilation of clips from previous episodes
  - We did this before and it was a huge success
- For this one, we want to focus on atherosclerotic cardiovascular disease (ASCVD), cholesterol, and apoB
  - This episode includes clips on why it is important to care about ASCVD
  - We explain the role of cholesterol in ASCVD, and why no one should refer to cholesterol as good or bad
  - And why apoB is an important metric to track when looking at your lipids
- These clips are put together in what we think is the best way to listen to them from top to bottom
- Peter also provides some commentary between clips to give you a bit of context
- Our hope is that not only will you understand this topic better, but you will also be able to identify some past episodes you may want to go back to and listen to more deeply
- Lastly, some of these clips are taken from AMAs, so if you’re not a subscriber, we hope this gives you a little bit of a sneak peek of what’s covered in those episodes
- This is still a fairly new concept
  - We’ve only done this once before
  - We got great feedback on that, which is why we’re doing it again
  - So if you continue to like this, please tell us, and if you don’t tell us why

## The importance of understanding atherosclerosis early in life [2:25]

From episode [#203 – AMA #34: What Causes Heart Disease?](https://peterattiamd.com/ama34/); discussed from [2:20] – [8:00]

**Atherosclerotic cardiovascular disease (ASCVD) is ubiquitous**

- 1 – This disease is inevitable and ubiquitous
- 2 – It has a major impact on human longevity

> “*Not everybody dies from atherosclerosis, but… everybody dies with it*”‒ Peter Attia

- Cancer and dementia are both prevalent with aging, but they are not inevitable
- We know a lot about ASCVD
- Peter adds, “*The reason you really want to understand this is because the impact is huge and the tools we have are also huge*”

***Extending lifespan comes down to delaying the onset of chronic disease, and atherosclerosis is the most common chronic disease***

**2 main paths to atherosclerosis (risk factors)**

- 1 – Hypertension (high blood pressure)
- 2 – Lipid abnormalities (we’ll focus on this one)
- Smoking is a behavioral risk factor (we’ll put this aside for the moment)

**Studies of pathology show ASCVD begins at a young age**

*What is the most common presentation for a 1st heart attack?*

- Sudden death
- A 1st heart attack in over 50% of people is fatal
  - Today this number is a little less but still staggering

*What is the age distribution of people who have their 1st major adverse cardiac event?*

- Adverse cardiac events are a heart attack or a stroke (or death)
- Figure 1 shows the incidence of cardiovascular events for both males and females in the US

![](https://peterattiamd.com/wp-content/uploads/2022/10/f1-cholesterolroundup-1024x247.png)

**Figure 1.** Incidence pf cardiovascular events by age and sex.  Image credit: [*JAMA Cardiology* 2016](https://jamanetwork.com/journals/jamacardiology/fullarticle/2523465)

- The graph on the right shows total annual events
  - The 1st 2 sets of bars show the number of events for people under 65
  - Men are shown in the darker bars comprising slightly below 25% and slightly above 25% of all cardiac events
    - The implication is that 50% of men who are going to have a cardiac event in their life will have it before the age of 65
  - For women, a third of women will have their 1st cardiac event before the age of 65
- The total annual events is not the whole story; it’s important to understand how long it takes for this disease to take hold
  - Early prevention is key
- Almost 25% of these events are in men younger than 54
- When you think of someone who is 45, 50, this disease didn’t start 2 years before

***When you see these stats laid out, it creates a shift in your mind around why you should care about this***

## Defining ASCVD, its causes, and the role of cholesterol [8:00]

From episode [#203 – AMA #34: What Causes Heart Disease?](https://peterattiamd.com/ama34/); discussed from [9:00] – [15:00]

**Atherosclerotic cardiovascular disease (ASCVD) is disease state characterized by the deposition or the buildup of cholesterol (sterols) in the artery wall**

- It begins with a fatty streak that later consolidates into plaques that can ultimately lead to a reduction in blood flow
- Reduction in blood flow is called [ischemia](https://en.wikipedia.org/wiki/Ischemia)
- Ischemia results in tissue damage to the heart and this is what results in a [heart attack](https://en.wikipedia.org/wiki/Myocardial_infarction)
- A heart attack can be fatal depending on the amount of cardiac tissue that is damaged from loss of oxygenation

**Causes of ASCVD**

- You *don’t* have to be obese or have high blood pressure

“*It’s really a question of the cholesterol in your blood. That’s really what defines the disease*.”‒ Peter Attia

- Atherosclerosis is defined by the presence of cholesterol **in the artery wall**
  - This is not necessarily related to the measurement of cholesterol **in circulation**
- Patients with cholesterol in their arteries do not necessarily have to have **co-aggravating factors** such as: high blood pressure, diabetes, obesity, family history, smoking
  - All these things that exacerbate ASCVD

**Cholesterol explained**

- Cholesterol is an organic molecule, a type of [lipid](https://en.wikipedia.org/wiki/Lipid)
- It is not soluble in water
- It is a [hydrophobic](https://en.wikipedia.org/wiki/Hydrophobe) molecule
- Picture pouring oil into water and you would immediately see what it means to have a hydrophobic substance in contact with something that is hydrophilic (water)
  - They repel each other

**Cholesterol is about one of the most important molecules in the body**

- You would die without it
- Rare genetic conditions that impair the ability to make cholesterol are fatal
- Cholesterol is used for 2 main things:
- 1 – The cell membrane of every cell in the body contains cholesterol
  - Cholesterol contributes to the fluidity of the cell membrane, important for membrane channels that allow things in and out of the cell
- 2 – Synthesis of many hormones begins with cholesterol, including: cortisol, estrogen, testosterone
  - It is also essential for the creation of bile acids, necessary to digest food

**Where does cholesterol come from?**

- Most people think of cholesterol as something that comes from eating certain foods
  - This is true, eggs contain cholesterol
- *But the cholesterol in your bloodstream has little to do with the cholesterol in foods you eat*
  - The reason is, the cholesterol we eat in esterified, it has a chemical bond that swings between an intermediary oxygen and another side chain
  - This cholesterol is too large for the receptors in our gut to absorb
  - Most of the cholesterol we eat is excreted

***Most of the cholesterol we will discuss in our bloodstream is made in our body and transported between cells through lipoproteins***

## Why early prevention of atherosclerosis is critical [13:45]

From [Peter on why early prevention of atherosclerosis is critical](https://peterattiamd.com/peter-on-why-early-prevention-of-atherosclerosis-is-critical/), a clip from episode [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/); discussed from [13:15] – [15:30]

- Peter remembers from pathology class in med school something the professor said, “*No doctor has more experience with what it is to have heart attacks than pathologists because 50% of the people who have a heart attack die on their first heart attack.*“
  - 50% of people who have a heart attack, their first presentation is death
  - He doesn’t think this is true today, but it was 25 years ago
  - Maybe now 1/3 of first events are fatal, sobering nonetheless
- The [textbook](https://www.amazon.com/Atherosclerosis-Progression-Regression-Encyclopedia-Medicine/dp/1842141538/ref=sr_1_1?dchild=1&keywords=stary+cardiovascular+disease&qid=1635356511&s=books&sr=1-1) went through, in great detail, the pathological staging of [atherosclerosis](https://en.wikipedia.org/wiki/Atherosclerosis)
- It was also littered with autopsy sections of [coronary arteries](https://en.wikipedia.org/wiki/Coronary_arteries) from people who had died for other reasons
  - Notably, many of these people died from other causes, but their coronary arteries were studied in autopsy; these people were quite young
    - A 26-year-old male victim of a gunshot wound
    - A 27-year-old female who died in a motor vehicle accident, etc.

***Looking at their coronary arteries, one realizes they already have atherosclerosis***

- They have oxidized [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B)-bearing particles engulfed by [macrophages](https://en.wikipedia.org/wiki/Myocardial_infarction#Atherosclerosis) and thickened [intima](https://en.wikipedia.org/wiki/Tunica_intima)
- While they may not have calcification in their arteries yet or the types of plaque that would rupture within the ensuing weeks or days or months, they nevertheless had atherosclerosis

- Now what Peter’s professor said some 20 years earlier made sense

## Preventing atherosclerosis—two fatal flaws with the “10-Year Risk” approach [16:00]

From [Preventing Atherosclerosis: 2 Fatal Flaws with the “10 Year Risk” Approach](https://peterattiamd.com/preventing-atherosclerosis-flaws-with-the-10-year-risk-approach/), a clip from episode [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/); discussed from [5:30] – [12:30]

- Atherosclerosis, it’s a disease in the *tissue*, yet almost everything that lipid people talk about is in *plasma*
- One must understand the natural history of the disease to learn how to construct a strategy to prevent it
- Although much of Allan’s work has been on [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B), the more important part has been on understanding how the natural history of atherosclerosis should direct a prevention strategy
- What this leads to is that every major guideline in the world bases their selection of subjects for statin prevention on the 10-year risk of disease
  - This was a huge step forward in 1980 and 1990
  - *But it fundamentally makes prevention of premature disease almost impossible*

**Problems with the 10-year risk approach**

- When one plugs in the numbers to calculate a patient’s risk in any of the risk algorithms, one expects the output to be the patient’s risk of cardiovascular disease (CVD), *but it isn’t*
  - The American College of Cardiology [ASCVD Risk Estimator Plus](https://tools.acc.org/ASCVD-Risk-Estimator-Plus/?_ga=2.155406269.702326460.1635355961-1875985647.1635355961#!/calculate/estimate/)
  - The calculation is driven by the age and sex of the patient
  - Things like cholesterol and blood pressure contribute minimally to the actual calculation of ten-year risk
    - So if the patient is 35, there isn’t a risk calculator for them
    - If the patient is 40, everyone’s risk is low at age 40
    - It isn’t until age 55 or 60 that the risk gets over the threshold for the American Prevention Guideline treatment

***So prevention really starts at 55 to 60, but almost half of all infarcts and strokes occur before the age of 60***

- [Stary](https://www.medschool.lsuhsc.edu/pathology/faculty_detail.aspx?name=stary_herbert) and colleagues established that for the first 3 decades or so of life, the disease gets a foothold in the artery, but it’s only in the 4th decade that one starts to develop the lesions that can actually precipitate a clinical event
  - Risk is low, yet the event rate is high‒  *How could that possibly be?*
- Allan says the answer is “*stunningly obvious*”‒  Allan has [published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6583050/) on how this can be explained, there are 2 problems:
- 1 – There are a ton more people under 60 than over 60
  - So the *rate* of events is low, but the *absolute* number of events is high
- 2 – Say a patient gets to their 60’s without a cardiac event, but the disease was developing and extending during their 30’s-50’s
  - So by the time a doctor tries to prevent an event, the disease is well advanced in the arteries
- These are the 2 fatal flaws in the 10-year risk approach
- 1 – Risk is a good concept but Allan realized doctors should be selecting people based on *causes* of CVD
- For example, if Peter’s risk is 4.1%, what does this number mean?
  - Is *his* risk 4.1%?
  - No, it means 4.1 people out of 100 will have an [infarct](https://en.wikipedia.org/wiki/Myocardial_infarction)
    - But within this category, there is tremendous variance in real risk
    - Not everyone is at 4.1; some are higher; some are lower; some are dead on
  - The philosopher [AJ Ayer](https://en.wikipedia.org/wiki/A._J._Ayer) (known for [logical positivism](https://en.wikipedia.org/wiki/Logical_positivism)) was actually darn good on probability
- 2 – There’s a real challenge predicting singular events
  - One is either going to have an infarct in the next year or not; it’s not really a probability
  - If one algorithm said a patient has a 10% risk and another one said a patient has a 15% or 20%, whether they have an infarct or not, both algorithms were right because they said there was sort of a chance the patient would have an infarct
    - There is also a far greater chance that the patient won’t have an infarct
- When the advice is to treat patients with a risk abouve 7.5%, that means 92.5% of the time nothing will happen to these patients
  - That’s not a great incentive for helping people understand what’s truly going to happen

**A 30-year model of risk that focuses on cause of CVD**

- What Allan has done is develop what’s called a **causal benefit model**
  - Published in *Clinical Science* in 2012, [The Causal Exposure Model of Vascular Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3244267/)
  - Published in *JAMA Cardiology* in 2017, [The Benefit Model for Prevention of Cardiovascular Disease: An Opportunity to Harmonize Guidelines](https://pubmed.ncbi.nlm.nih.gov/28793137/)
- With a measure of non-HDL or apoB, risk can be projected for over 20-30 years
  - For a 30-year-old, the period of time they should care about is up to at least 60
  - For example, this model could predict that a 35-year-old has a 30% chance of stroke before age 65

> “*Now that’s a number you can deal with. That’s a number that has meaning*.”‒ Allan Sniderman

- Now a second calculation can be made to determine how much the risk can be reduced by starting treatment at age 35 or how much the patient would lose by starting at age 45 or age 55

## Intro to lipids and lipoproteins: why there is no “bad” or “good” cholesterol [23:00];

From the YouTube video [Intro to Lipids & Lipoproteins: Why there is no ‘bad’ or ‘good’ cholesterol](https://youtu.be/eod36TNGcUI)

- This next set of clips is a deeper dive into cholesterol
  - The limitations of the standard cholesterol blood panel
  - Why no one should ever refer to cholesterol as good or bad
- Peter recently [posted on social media](https://twitter.com/peterattiamd/status/1524745894783979520?lang=en) about his frustration with how the press (and even the medical establishment) writes about cholesterol, referring to ‘good’ cholesterol and ‘bad’ cholesterol
  - This imprecise language is unhelpful
- You may be new to this discussion and looking for the TL DR (too long; didn’t read) version of cholesterol

**What is cholesterol?**

- [Cholesterol](https://en.wikipedia.org/wiki/Cholesterol) is a lipid synthesized by *every* cell in our body
- Cholesterol is *essential* for creation of a cell
- A picture of a [cell](https://en.wikipedia.org/wiki/Cell_(biology)) in a textbook shows it cut open, similar to the one below

![](https://peterattiamd.com/wp-content/uploads/2022/10/f2-cholesterolroundup-1024x666.jpeg)

**Figure 2. An animal cell.**  Image credit: [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Eukaryotic_Cell_(animal).jpg)

- In reality, cells are 3-dimensional and they are *fluid*
- The cell’s membrane (aka plasma membrane)  give them that fluidity via the cholesterol in the membrane
  - This fluidity also allows transporters to go across the surface of cells
  - Transporters allow various things to traverse the membrane such as glucose, ions, hormones, etc.

> “*If we didn’t have cholesterol, we wouldn’t have cells.  If we didn’t have cells…  No cholesterol equals no life.*”‒ Peter Attia

**Why is cholesterol essential?**

- 1 – Cholesterol imparts fluidity to membranes
- 2 – Cholesterol is the [precursor for hormones](https://en.wikipedia.org/wiki/Cholesterol#Chemical_precursor)
  - Vitamin D
  - Cortisol
  - Estrogen
  - Testosterone
  - Progesterone
- 3 – Cholesterol is essential for [bile acids](https://en.wikipedia.org/wiki/Bile_acid)
  - We wouldn’t be able to digest our food without bile acids (especially fatty foods)

**Why does the story not end here?**

- Not every cell in the body can make enough cholesterol to meet its own needs
- So the body has to be able to traffic cholesterol
- Some cells tend to be net exporters of cholesterol (like the liver)
- Some parts of the body cannot make enough cholesterol to meet their needs, especially during periods of high stress
  - These parts of the body need to receive cholesterol
- This poses a problem because the circulatory system is the main way things are transported throughout the body
  - (The lymphatic system is another system used for transport)
  - Many things are transported in the circulatory system without difficulty
    - Glucose
    - Lactate
    - Electrolytes
    - All of these are water soluble
- The circulatory system (the blood) is made up of plasma (water) and proteins
- Things that are water soluble are transported easily
- Cholesterol is a lipid and not water soluble ([hydrophilic](https://en.wikipedia.org/wiki/Hydrophile))
  - It is [hydrophobic](https://en.wikipedia.org/wiki/Hydrophobe)
- Things that are hydrophobic cannot move in water
  - Think of dumping oil in water; they repel each other
- We can’t move cholesterol directly through the circulatory system
- The solution is to use a vehicle to transport cholesterol in the blood
  - This is a lipoprotein
- A [lipoprotein](https://en.wikipedia.org/wiki/Lipoprotein) is part lipid and part protein
  - It is engineered so the lipid part is on the inside
  - The protein part is on the outside, and protein is water soluble
  - This is a spherical molecule which can package hydrophobic cargo on the inside
  - The outside is hydrophilic (attracted to water) and moves effortlessly through the circulatory system

***Lipoproteins are how cholesterol is transported in the blood***

**Broadly speaking, these lipoproteins traffic in 2 families**

- 1 – A family defined by [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B), an [apolipoprotein](https://en.wikipedia.org/wiki/Apolipoprotein) that wraps around the spherical, larger lipoprotein
- 2 – a family defined by [apoA](https://en.wikipedia.org/wiki/Apolipoprotein_AI)
- Technically there are 2 apoB families, apoB-100 and apoB-48
  - We’ll ignore apoB-48 for now, it is only found on [chylomicrons](https://en.wikipedia.org/wiki/Chylomicron)
- ApoB-100 defines this lineage of lipoproteins
  - [VLDL](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein)
  - [IDL](https://en.wikipedia.org/wiki/Intermediate-density_lipoprotein)
  - [LDL](https://en.wikipedia.org/wiki/Low-density_lipoprotein)
  - [Lp(a)](https://lipoprotein)
- The ApoA lipoproteins define a totally different class of lipoproteins called [HDL](https://en.wikipedia.org/wiki/High-density_lipoprotein)

**What do these names mean? (VLDL, ILDL, LDL, HDL)**

- These names refer to another feature of the lipoprotein that is distinct from the apolipoprotein that wraps around them, their **density**
  - Think of a high school experiment‒  take different substances and see where they float in water
    - Water is a bad example because things tend to sink or float
    - But this provides a conceptual understanding of density
  - [Density](https://en.wikipedia.org/wiki/Density) is mass over volume
- A higher density object (relative to a lower density object) will sink (versus float)

***If you take all of the lipoproteins and put them in a gel in the lab, you can see a separation based on their density***

- The highest density lipoproteins are called **HDLs**
  - There is more than 1 apoA on a HDL
  - There are different subclasses of HDLs
  - HDLs are really complicated
- We don’t come close to understanding all the in’s and out’s of HDLs
  - This is why Peter gets really annoyed when people say, “*Having a high good cholesterol is good*”
    - What they mean is having a high HDL is good
- While it’s true that on average higher HDL cholesterol is associated with and traffics with good metabolic health in a way that low HDL cholesterol traffics with bad metabolic health
- You cannot tell if a person is in good shape or not by looking at their HDL level
  - That single snapshot of how much cholesterol is in the HDL tells you nothing about the functionality of the HDL
  - It’s the functionality of the HDL that matters
  - We’ll go into HDL biology in a future podcast
  - Efforts to raise HDL pharmacologically have mostly failed to improve outcomes

**More about LDL apoB**

![](https://peterattiamd.com/wp-content/uploads/2022/10/f3-cholesterolroundup.jpeg)

**Figure 3. Low density lipoprotein (LDL) contains apoB.**  Image credit: [Sigma Aldrich](https://www.sigmaaldrich.com/US/en/product/sigma/l8292)

- The most abundant apoB-100 (or apoB for short) is the low density lipoprotein (LDL)
  - That’s the one that gets called bad cholesterol
  - While on the apoA side, HDL is called the good cholesterol (high density lipoprotein)

**If someone says,** ***“What is your HDL?  What is your LDL?”*** **They’re asking for a laboratory metric, they’re asking incorrectly.  There is no laboratory metric called LDL or HDL.**

- There is HDL cholesterol and LDL cholesterol, abbreviated LDL-C and HDL-C
- There’s LDL-P and HDL-P, which is the particle member of LDL, which can be counted via electrophoresis or NMR
- The way Peter prefers to *count the number of these particles* is to look at apoB

> “*The apoB concentration to me is the most important number you want to understand to predict from a biomarker standpoint your ASCVD risk, because it captures all of the atherogenic particles*”‒ Peter Attia

- apoB counts the total of the LDLs, inclusive of the Lp(a)s, the IDLs (although they virtually never exist, they have such a short residence time) and the VLDLs (which can become problematic in people with metabolic syndrome and high triglycerides)
- ***apoB gives you the total atherogenic burden of those lipoproteins… it’s the preferred metric by which we want to assess risk***
- If you want to look at LDL, you have to look at LDL-C (LDL cholesterol)
  - And for HDL, you have to look at HDL-C (HDL cholesterol)

***Is the cholesterol in HDL any different from the cholesterol in LDL?***

- No

*Therefore, it is totally erroneous to say HDL is good cholesterol and LDL is bad cholesterol*

- Instead, what is true is that LDL as lipoproteins are bad actors because of what they do

- LDL goes into artery walls and becomes oxidized
  - Then it dumps their oxidized sterol contents into the subendothelial space
  - This elicits an immune response and lots of other things that lead to atherosclerosis

**The point here is to understand that HDL and LDL are lipoproteins, and if you want to talk about cholesterol, you talk about LDL cholesterol and HDL cholesterol**

- The cholesterol in them is exactly the same
- You have to be careful when you see things written through the lens of good/ bad cholesterol
  - What it tells you is the person writing this doesn’t understand the basics of lipids and lipoproteins
  - Because what Peter just told you is literally the 101 on this subject
  - We didn’t get to the senior level class, let alone the graduate level class, and this is complicated stuff once you get into that level
  - So if someone is butchering the 101, you can stop reading because whatever else they’re saying, they’re undoubtedly screwing it up

## Limitations of standard blood panels [35:45]

From episode [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/); discussed from [29:15] – [33:00]

**Doctors get a report of 5 numbers: total cholesterol, triglycerides, non-HDL-C, LDL-C, HDL-C**

- What can they do with that?  Everything is based on LDL
- In reality, the other 4 numbers are doing nothing

*Understanding the differences between calculated versus measured LDL, and amount of cholesterol versus number of particles*

- For example, a patient’s labs report 140 mg/dL LDL-C
  - This is an estimation; it’s almost always a calculation
  - There are at least 8 different methods to calculate LDL cholesterol
    - They don’t all give the same answer
- LDL cholesterol can also be measured directly
  - That assay has never been validated in disease patients
  - No one has ever published a paper showing that it’s more accurate in terms of disease identification than calculated LDL cholesterol

***There’s no question that the number of LDL particles is a more accurate index of risk than the LDL cholesterol***

- [VLDL-C](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein) is a cholesterol that’s in the very low density lipoprotein particles
  - These particles that come out of the liver
  - This cholesterol is atherogenic, there’s a lot of triglyceride in that particle
- High [triglycerides](https://en.wikipedia.org/wiki/Triglyceride)‒ *there’s no question that people with high triglycerides are at increased risk of heart disease*
  - The people with high triglycerides that are at increased risk of heart disease have a higher number of LDL particles and VLDL particles
  - It’s the particle
- When triglycerides are measured, what is measured is just measuring a blob of liquid in a bunch of particles, and one needs to know the number of them
- Extremely high triglycerides carry an increased risk of [pancreatitis](https://en.wikipedia.org/wiki/Pancreatitis)
- Allan hasn’t seen any solid evidence that triglyceride itself is pro-atherogenic

> “*What’s atherogenic is the cholesterol inside the VLDL particles, it’s the number of those particles that get into the wall*” – Allan Sniderman

- In general, all Allan needs to know to estimate CVD risk is the apoB level, except for 1 complication, a disorder called [remnant type III dysbetalipoproteinemia](https://en.wikipedia.org/wiki/Familial_dysbetalipoproteinemia) (or [hyperlipoproteinemia](https://rarediseases.org/rare-diseases/hyperlipoproteinemia-type-iii/))
  - This is a very specific, highly atherogenic condition
  - It manifests with high triglycerides, high cholesterol, but low apoB
- When lipids and apoB are measured, this disorder can be recognized
  - But doctors don’t routinely measure apoB
  - If you don’t measure apoB, this condition cannot be diagnosed

## How Mendelian randomization is bolstering the case for apoB as the superior metric for risk prediction [39:30]

From episode [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/); discussed from [40:15] – [58:45]

- This last set of clips will focus on why Peter thinks apoB is a superior lipid metric to LDL cholesterol or even non-HDL cholesterol for predicting risk

**Will kids in med school 10 years from now be learning about apoB instead of LDL?**

- Allan is pessimistic
- The [2019 European guidelines](https://air.unimi.it/retrieve/handle/2434/706264/1393408/European%20Heart%20Journal%202020_41_%20111.pdf) were very pro apoB
- Allan adds, “*The evidence from Mendelian randomization, the newer technologies, they’ve just been a slam dunk for apoB*”

**Explain what a Mendelian randomization is and how this points to causality of apoB for ASCVD**

- Conventional studies are [prospective observational studies](https://en.wikipedia.org/wiki/Prospective_cohort_study) (like the [Framingham Heart Study](https://en.wikipedia.org/wiki/Framingham_Heart_Study))
  - This is a conventional way of taking things apart
  - There’s a limited amount of certainty of the conclusions because of *confounding* that can’t be dealt with
  - This study takes measurements at age 20 and then follows someone for the next 30 years
  - A lot of things change in 30 years
  - The inferences are probable but *not* causal
- [Mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) allows one to come a lot closer to **causality**
  - For example, one can identify groups of genes that are associated, where changes in the gene are associated with a little lower cholesterol or a little higher cholesterol
  - When one lumps together a bunch of those different genes that have different makeups, you can see fairly substantial differences in cholesterol

***You have information on somebody that’s fixed at birth [***[***genotype***](https://en.wikipedia.org/wiki/Genotype)***], and you see if that is associated with a difference in outcome***

- With Mendelian randomization, you’ve gotten rid of a lot of stuff in the middle

***What a number of Mendelian randomization studies have shown is that apoB includes all the information in triglycerides, LDL cholesterol, and even HDL cholesterol; it sums them***

- [George Davey Smith](https://en.wikipedia.org/wiki/George_Davey_Smith) (one of the founders of Mendelian randomization) is the author of a number of Mendelian randomization [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5710502/) says apoB incorporates and therefore beats triglycerides and LDL cholesterol
  - *This is a huge level of information that isn’t even mentioned in almost any of the guidelines*

**Peter’s takeaway:**

- When following a cohort prospectively, the way the Framingham cohort was followed (or the [Framingham offspring](https://en.wikipedia.org/wiki/Framingham_Heart_Study) or the [MESA cohort](https://en.wikipedia.org/wiki/Multi-Ethnic_Study_of_Atherosclerosis), or any of these cohorts have been followed), you can take a bunch of people and measure their apoB or their LDL-C or whatever metric, and you are trying to determine if it has a *causal relationship* to the disease of interest
  - This cohort can be followed over decades
- It has been demonstrated that the people with higher apoB, higher LDL-C, higher non HDL-C, and lower HDL-C all have a *higher risk* of developing atherosclerosis over time

***It’s hard to say that that’s causal just based on that information, because over the ensuing 20 years that you follow them, they are free to make other choices that may impact those variables of interest and other variables***

- The Mendelian randomization attempts to get around that by saying at the time of conception, we all get randomized to a set of genes
- If one can identify which genes map to which [phenotype](https://en.wikipedia.org/wiki/Phenotype) (and one can figure out the genes that mapped to the phenotype of our interest, namely driving up or down a variable of interest such as apoB) then there’s no worry about the confounders that occur in between, because the genes can’t change
- Now when a difference in outcome is observed, it’s much more likely to be causally related to the phenotype of interest because the gene that underlies it has not changed

**What are some of the ways that we can get tripped up with Mendelian randomization?**

- Before we get there, Allan points out that HDL cholesterol used to be the total rage because the *epidemiological evidence* couldn’t be clearer
  - Peter recalls that the Framingham study demonstrated that low HDL-C was 4 times more predictive of cardiac events than high LDL-C
  - Allan agrees that the difference is definitely multiples
  - Further it is known from [CETP inhibitors](https://en.wikipedia.org/wiki/CETP_inhibitor), that *one can’t manipulate HDL and change outcomes*
  - That’s one of the elements of demonstrating an overall causal relationship

***The Mendelian randomization shows HDL is not causal, whereas apoB and cholesterol are causal***

- In the past 10 years, it’s an incredible technical advance in being able to examine questions and look at numbers of people that would be unimaginable in conventional studies
- The Mendelian randomization studies involve hundreds of thousands of people because they’ve got these huge data banks with genes and those numbers can *avoid* confounders
  - There are huge numbers
- But it’s like any methodology, no method is perfect
  - This one can mislead you too, particularly when you’ve got a sequence of associated variables
  - For example, people showed using Mendelian randomization (MR) that triglycerides were “*causal*” or “*associated with increased risk*”
  - But when one takes into account the non-HDL cholesterol or the apoB, the risk of triglycerides disappears
  - ***When there is a linked metabolic chain, one has to be careful to go to the end of it, to get to the real actor, not Act I leading… to get to the real*** [***personae dramatis***](https://en.wikipedia.org/wiki/Dramatis_personae)
- Peter notes his surprise that HDL didn’t demonstrate causality (at least at the first order) because there’s no doubt that phenotypically, the high triglyceride, low HDL phenotype is so associated with metabolic syndrome
  - High triglyceride and low HDL make up 2 of the 5 criteria of [metabolic syndrome](https://en.wikipedia.org/wiki/Metabolic_syndrome)
- Allan notes that HDL is an incomplete description
  - It’s like  describing yourself as 6 feet tall, not telling the weight, and not asking about BMI

> “*You cannot characterize any phenotype without the apoB*”‒ Allan Sniderman

- Allan asks, “*How can you pretend you’ve evaluated the system when you haven’t counted the number of atherogenic particles?*”
  - They could be normal, they could be high, or the patient could have a type III
  - There is no phenotype without putting apoB in there

***They’re lipoprotein particles, they’re disorders of lipoprotein particle metabolism***

- Of course the triglycerides and cholesterol are important; but this information is incomplete without apoB
- It drives Allan to distraction as to why you wouldn’t want to know a core element of knowledge (the apoB level)
  - But it doesn’t seem to bother many of his friends

**Is it true that smoking and hypertension probably carry a greater risk for atherosclerosis than apoB?**

- In terms of pathophysiology, the apoB bearing particle wreaks havoc in the artery wall many, many years before clinical events are observed
- In the last 30 or 40 years there have been almost an infinite number of basic science studies on hypertension
  - [Hypertension](https://en.wikipedia.org/wiki/Hypertension) is having higher blood pressure than what is normal
- What strikes Allan is the lack of discussion about the [pathophysiology](https://en.wikipedia.org/wiki/Pathophysiology) of hypertension
- But basic science (that goes on in rats) is healthier than ever
  - Allan doesn’t know of anything that’s come out of that basic science that’s been clinically useful in the last 30 years
- The drugs prescribed to treat hypertension work

> “*Where is the disease that produces that higher blood pressure? Is it resistance? We don’t have a clue*”‒ Allan Sniderman

- To Allan, it’s the same thing as much of the debate in lipids about apoB
  - It can be likened to the drunk looking for the key under the light because this is where the light is, not where he lost the key
- Allan thinks hypertension arises from the loss of elastins in the proximal aorta, and that causes systolic hypertension
  - He doesn’t think it’s complicated
  - Now, what could accelerate this process?
- When Allan reads the literature on hypertension he sees studies on peripheral arterial tone, complex metabolic studies in sophisticated animal models, as well as some renal studies
  - It’s all [miasma](https://en.wikipedia.org/wiki/Miasma_theory) for him

**Involvement of the proximal aorta**

- The proximal aorta is elastic; if one looks at a flow curve (a hydrostatic pressure curve) when a patient is young it’s rounded because as the left ventricle ejects blood rapidly into the aorta, the aorta expands and absorbs some of that energy
  - Recall that wind castle that they’ve mentioned in school, but the energy is partially captured, partially regained; but the wall isn’t battered; *the wall can give way*
  - Imagine if those elastic fibers start to go, then the walls stiffen; now when the left ventricle ejects blood, the pressure goes up more rapidly and it falls more rapidly in diastole
    - *This could be why systolic hypertension occurs while diastolic pressure is normal*
- He suggests looking at factors like **cardiac output** again (which used to be studied way back when) or factors that alter the behavior of the proximal aorta
  - He believes these are much more likely to be involved
- With **hypertension** there is a driving force to push particles into the wall
- With hypertension, the wall thickens up and it gets harder for particles to go through
  - The response of the wall changes, and this leads to the increase in blood pressure

**Does this damage the endothelium? Does that play a role in disease?**

- Allan doesn’t understand endothelial dysfunction, but he knows the endothelium is critically important
- It functions abnormally and how that fits into the overall pathology, he doesn’t know
- Allan bets apoB particles are part of the process inducing endothelial dysfunction, but he doesn’t know that clearly, experimentally

**Does it make sense to compare hypertension to apoB?**

- They both seem to play a causal role in CVD
- Is one more causal than another or is that a silly question because they’re not binary and static?
- Allan thinks this is not the right question
- He thinks our blood pressure goes up with age
  - Hypertension involves a large part of the population
  - It seems that hypertension is becoming part of the aging process
  - Humans are lasting a lot longer than we were probably designed to
- There is this repetitive injury to the **proximal aorta**, and it gets a little progressively less able to deal with it
  - So by the time a person is 50, somewhere around 60% have higher blood pressure (the figures are staggering)

**Does apoB rise with age?**

- It does rise with age, but not that much
- If you have high apoB at age 35, you’ve got about a 95% chance of staying high; 5% will go out of the high zone but they won’t go low, low
- If you have high blood pressure at age 35, Allan wouldn’t expect anything is going to move you down

> “*That’s why I think it’s [apoB] such a good signal for when we should start thinking about treating people*”‒ Allan Sniderman

- Some people go from low toward high, but the majority don’t
- For people with high apoB, about 90% remain high

**Is there a gender difference?**

- Peter has seen women experience dyslipidemia as they go through menopause
  - This is something men men wouldn’t experience over that same decade or even a 5-year transition
- Allan notes that apoB goes up with menopause
  - He would like to see more data on this
  - The science has been held back because people don’t measure apoB

**Are we doing a better job treating hypertension than dyslipidemia?**

- Allan has no idea
- The incidence of coronary disease is going up in the last 5 years
  - Despite statin therapy
  - It’s due to obesity and diabetes
- There are many reasons why treatment is not succeeding as well as it should
  - The complexity of the lipid phenotype of the lipid model is part of the answer

**Peter’s takeaway:**

- If in the last 5-10 years the incidence of major adverse cardiac events is rising despite our advances, you could argue that measuring LDL-C and using it as our proxy for treatment is problematic
- As dyslipidemia is growing in the metabolic context
  - Meaning if you have more medicine, more insulin resistance, more type 2 diabetes
- We know these phenotypes are associated with a greater discordance between apoB and LDL-C
- This suggests you have a greater and greater portion of the population that is being undiagnosed or underdiagnosed
  - Because you’re treating their LDL-C and believe their risk is lower when really their apoB is higher [so their risk is higher]
- Allan agrees, “*Trying to quantify lipoproteins based just on lipids is not adequate. You’re not capturing all the information that you should*.”

## Therapeutic goals for apoB concentration [58:15]

From episode [#129 – Tom Dayspring, M.D.: The latest insights into cardiovascular disease and lipidology](https://peterattiamd.com/tomdayspring6/); discussed from [21:45] – [34:15]

**The concentration of apoB matters**

- Smoking and hypertension are 2 biggest **risk factors** for ASCVD
  - Both seem to do so by weakening/ injuring the endothelium
- Peter asks, “*How ironclad is the story that it’s the apoB bearing particle in the presence of injured endothelium that is the Trojan horse that begins this destructive trajectory of taking cholesterol into the subendothelial space, becoming retained, undergoing this chemical oxidation process, which then kicks off an inflammatory response (that paradoxically as an attempt to repair the damage), and results in what can be a fatal injury?*”
- There are other hypotheses, consider this patient
  - A woman in her late 60’s has a total cholesterol of 300+
  - Her LDL-C is 220 mg/dL
  - apoB is 170 mg/dL
  - But her coronary artery calcium score is zero
  - They have elected not to treat her with lipid lowering therapy

 **How do we reconcile this exception?**

- Tom explains that not all smokers are going to come down with lung cancer or chronic obstructive lung disease
- You have to *individualize* risk factors
  - Particle number is usually a major factor, but not always
  - Endothelial function matters, but it’s hard to measure
    - Not everybody has serious endothelial dysfunction who winds up with atherosclerosis
  - More and more, we see it’s not just particle concentration but also *quality*
- Tom asks, “*What are the other attributes of any lipoprotein that might contribute to its atherogenicity?*”
  - Are there other proteins on the lipoproteins
  - Can we characterize the patient’s complex lipidome
  - There’s a lot going on
- Listener’s know atherosclerosis is a [complex, multifactorial disease](https://en.wikipedia.org/wiki/Multifactorial_disease)
- This is why Tom examines in great detail other things that might be injuring the endothelium or arterial wall to see if any of those are treatable

“*We’re getting a little bit smarter on lipoproteins, but there certainly is more to it than just particle number*”‒ Tom Dayspring

**Is there a limit to the benefit of reducing numbers?  Diminishing returns or even harm?**

- Peter has talked about this with [Ron Krauss](https://peterattiamd.com/ronkrauss/) before; the causal relationship between apoB and atherosclerosis is as strong as anything we see in medicine (for which we can’t do a perfect experiment)
- But it might not be clear what dose/response looks like
  - What do we know is about risk reduction in lowering from 60 to 40 to 20, both pharmacologically and non-pharmacologically
  - What do Mendelian randomization studies tell us?
- In studies we come across the concept that *lower is better*
  - That said, you do need a few apoB-containing lipoproteins because they traffic other lipids but [hypobetalipoproteinemia](https://en.wikipedia.org/wiki/Hypobetalipoproteinemia) is not a problem like [abetalipoproteinemia](https://en.wikipedia.org/wiki/Abetalipoproteinemia)
- Studies suggest getting a **50% reduction** as the most “bang for your buck”
  - Beyond that, you do get an incremental reduction, but it’s a much smaller increment of risk reduction

***You see the most risk reduction when you take apoB down below 50 mg/dL***

- This is the level that newborns have
- And with the pharmalogic lowering of apoB with current FDA approved drugs, there is no signal of harm
- Peter notes using [PCSK9 inhibitors](https://peterattiamd.com/genetics-of-pcsk9i-nonresponders/), he routinely sees patients who get their apoB down to 20-40 mg/dL

**How much of our cholesterol is in circulating lipoproteins vs. in cell membranes?**

- Plasma glucose represents a tiny fraction of total body glucose
- Likewise, plasma cholesterol is a small portion of total body cholesterol (most is in the cell membrane or steroidal producing tissue and the circulating amount is a very narrow part of it).
- Let’s say you measure cholesterol in the plasma at 200 mg/dL, and bring it down to 100)
  - You might worry that you have cut cholesterol half, considering the importance of cholesterol
  - *However, you have only cut the amount carried by lipoproteins in plasma by half, and that doesn’t capture the majority of the cholesterol in the body*
  - This is like looking at a person’s plasma glucose level and realizing it represents a tiny fraction of total body glucose
- Modulating lipid cholesterol metrics says nothing about *cellular* cholesterol content
- Don’t worry if LDL cholesterol is low– you still have plenty
- Realize we have different pools of cholesterol in the body, see the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/10/f4-cholesterolroundup-1024x679.png)

**Figure 4.  Cholesterol pool sizes‒ there’s more cholesterol in red blood cells than the amount in all lipoproteins combined.**

**Pools of cholesterol in the body**

- 1 – The brain
  - It’s a separate system
  - It doesn’t interact the cholesterol in your plasma
- 2 – Peripheral cells of the body
- 3 – Circulating in plasma
  - In the plasma there is an eensy-weensy amount bound to albumin
  - There’s more bound within all of the lipoproteins that are trafficking in your body, meaning your apoB and your apoA-1 particles
- Tom adds, “*If I wanted to search down blood cholesterol for you, I would suck out your red blood cells and extract cholesterol from them. Red blood cells carry far, far more cholesterol than do all of your lipoproteins put together*.”

***The other crucial point… the amount of cholesterol within your lipoproteins has no correlation with your cellular cholesterol or even your red blood cell cholesterol***

- So however you’re modulating LDL-C, total cholesterol, HDL-C, that tells you nothing about what might you be doing to the cholesterol content of your cells
- So don’t have a panic attack if you’re making LDL cholesterol 30, because Tom can assure you virtually every cell in your body, even if that’s your plasma LDL-C has more than enough cholesterol because it can *de novo* synthesize it
  - So there’s no cell that’s being deprived of cholesterol in the periphery when you are modulating lipids through lifestyle or drugs

## How early and aggressive lowering of apoB could change the course of ASCVD [1:10:45]

From [Peter on how early and aggressive lowering of apoB could change the course of ASCVD](https://peterattiamd.com/early-and-aggressive-lowering-of-apob/), a clip from episode [#202 – Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes](https://peterattiamd.com/strong-convictions-loosely-held-2/); discussed from [31:45] – [37:00]

**How Peter has changed on ASCVD**: He’s become far more aggressive on the timing and magnitude of ApoB reduction

*What are the leading causes or modifiable causes of ASCVD?*

- Big three:
- i) smoking,
- ii) hypertension, and
- iii) hyperbetalipoproteinemia
  - Fancy word for saying too many lipoproteins that have apoB on them (LDL, IDL, VLDL, Lp(a))

**Measuring apoB**

- Peter is such a fan of measuring apoB as opposed to just measuring  LDL particle number, or LDL cholesterol number because we have one single number that captures the total concentration of apoB
- While that’s pretty well associated with non-HDL cholesterol—which is a far better surrogate than LDL cholesterol—it’s still better and that’s been demonstrated
  - A [previous podcast](https://peterattiamd.com/tomdayspring3/) covered the discordance between non-HDL cholesterol and apoB

The question becomes: **“*****When should you start apoB reduction and how much should you lower it?*****”**

- Some numbers: The 20th percentile of apoB is about 80 mg/dL
- Let’s say somebody was at the 50th percentile, they’re 40 years old, their calcium score is zero, and they were ambivalent about lipid lowering therapy and let’s assume that they’re not insulin resistant and you’ve done all of the things that you can do reasonably with nutrition
- In the recent past, Peter wouldn’t push that hard to take action
- Today, he takes a very different stance which is **treat early and treat aggressively**
- *The evidence is overwhelming that infantile levels of apoB are not deleterious in any way*
- We have a dedicated [AMA on ASCVD](https://peterattiamd.com/ama34/) which goes into heavy detail about the pathophysiology for about 90 minutes on all the reasons why Peter’s stance is now, treat early and treat aggressively

**Bold statement incoming**: If you pharmacologically lower ApoB to somewhere in the 20 to 30 mg/dL range for everybody in the population while they are in their 20s, can you eliminate ASCVD?  ⇒ *I think the answer is probably yes*

- In other words, what you’re basically going to do is eliminate death from atherosclerotic causes

**How do you take that thought experiment and turn it into a practical implication?**

- Well, it’s not really practical to take every 20 year old and obliterate their apoB (although this could and should be done with patients with significant genetic abnormalities that result in familial hypercholesterolemia)
- Practically what it means is basically by the time you’re in your late 30s or early 40s, if you have any measure of apoB that’s even north of the 20th percentile, that should be completely lowered
- Peter views the “ceiling” to be ~60 mg/dL
- Peter wants everybody to be below the 5th percentile

**Parting thoughts**

- We hope you enjoyed the special episode of The Drive
- This is one of the most talked about topics, not only on previous podcasts, but also one that we write about frequently in our newsletter
- If you want to dive deeper, there’s no shortage of content, and we’ll link to it all in the show notes
- However, we hope this provided you with a little more understanding of ASCVD, cholesterol and apoB

§

## Selected Links / Related Material

**Previous compilation episodes on** ***The Drive*****:**

- [#206 – Exercising for longevity: strength, stability, zone 2, zone 5, and more](https://peterattiamd.com/exercising-for-longevity/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (May 9, 2022) |
- [#221 ‒ Understanding sleep and how to improve it](https://peterattiamd.com/understanding-sleep/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 5, 2022) |

**Episodes of** ***The Drive*** **featured here on cholesterol**:

- [#203 – AMA #34: What Causes Heart Disease?](https://peterattiamd.com/ama34/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 18, 2022) | [2:20]
- [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 29, 2021) | [13:45]
- [#129 – Tom Dayspring, M.D.: The latest insights into cardiovascular disease and lipidology](https://peterattiamd.com/tomdayspring6/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 21, 2020) | [58:15]
- [#202 – Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes](https://peterattiamd.com/strong-convictions-loosely-held-2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 11, 2022) | [1:10:45]

**YouTube video explaining LDL-C and HDL-C**: [Intro to Lipids & Lipoproteins: Why there is no ‘bad’ or ‘good’ cholesterol](https://youtu.be/eod36TNGcUI) | Peter Attia (YouTube) | [23:00]

**AMA on the pathophysiology of ASCVD**: #203 – AMA #34: What Causes Heart Disease? | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 18, 2022) | [1:13:30]

**Allan Sniderman’s app to estimate CVD risk using plasma levels of total cholesterol, triglycerides, and apoB**: [ApoB](https://apob.app/) (2022)

**Learn more about cardiovascular disease at PeterAttiaMD.com**: [Cardiovascular Disease](https://peterattiamd.com/category/diseases/heart-disease-prevention/) (2022)

§