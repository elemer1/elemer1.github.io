# #312 – A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond | George A. Brooks, Ph.D.

**Source:** [https://peterattiamd.com/georgebrooks/](https://peterattiamd.com/georgebrooks/)

---

George A. Brooks is a renowned professor of integrative biology at UC Berkeley. Known for his groundbreaking “lactate shuttle” theory proposed in the 1980s, George revolutionized our understanding of lactate as a crucial fuel source rather than just a byproduct of exercise. In this episode, George clarifies common misconceptions between lactate and lactic acid, delves into historical perspectives, and explains how lactate serves as a fuel for the brain and muscles. He explores the metabolic differences in exceptional athletes and how training impacts lactate flux and utilization. Furthermore, George reveals the significance of lactate in type 2 diabetes, cancer, and brain injuries, highlighting its therapeutic potential. This in-depth conversation discusses everything from the fundamentals of metabolism to the latest research on lactate’s role in gene expression and therapeutic applications.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/georgebrooks/the_Drive_public.png)

Play

#312 - A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond | George A. Brooks, Ph.D.

#312 - A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond | George A. Brooks, Ph.D.

1x15s30s

0:002:06:14

## We discuss:

- Our historical understanding of lactate and muscle metabolism: early misconceptions and key discoveries [3:30];
- Fundamentals of metabolism: how glucose is metabolized to produce ATP and fuel our bodies [16:15];
- The critical role of lactate in energy production within muscles [24:00];
- Lactate as a preferred fuel during high-energy demands: impact on fat oxidation, implications for type 2 diabetes, and more [30:45];
- How the infusion of lactate could aid recovery from traumatic brain injuries (TBI) [43:00];
- The effects of exercise-induced lactate [49:30];
- Metabolic differences between highly-trained athletes and insulin-resistant individuals [52:00];
- How training enhances lactate utilization and facilitates lactate shuttling between fast-twitch and slow-twitch muscle fibers [58:45];
- The growing recognition of lactate and monocarboxylate transporters (MCT) [1:06:00];
- The intricate pathways of lactate metabolism: isotope tracer studies, how exceptional athletes are able to utilize more lactate, and more [1:09:00];
- The role of lactate in cancer [1:23:15];
- The role of lactate in the pathophysiology of various diseases, and how exercise could mitigate lactate’s carcinogenic effects and support brain health [1:29:45];
- George’s current research interests involving lactate [1:37:00];
- Questions that remain about lactate: role in gene expression, therapeutic potential, difference between endogenous and exogenous lactate, and more [1:50:45]; and
- More.

§

## Show Notes

\***Notes from intro**:

- George Brooks is a professor in the department of integrative biology at UC Berkeley and is the director of the Exercise Physiology Lab
- You may recognize George’s name as it’s come up a couple of times in interviews with Iñigo San-Millán
  - Peter also wrote about George briefly in *Outlive* when he referred to his work in lactate
- George was the scientist who first proposed the “lactate shuttle” theory in the 1980s
  - Arguing that lactate was actually a fuel source rather than an unfortunate byproduct of exercise
- His research has focused on the metabolic adjustments to exercise and explores many topics surrounding exercise physiology
  - Including the pathways and controls of lactate formation and removal before, during, and after exercise
- This conversation dives deep into all things lactate
  - It’s a little bit technical, but not particularly egregious relative to the depth that we normally will cover things
  - Peter encourages you to stay with this, even if at times it seems a bit heavy on the biochemistry
    - We probably start a little bit in that direction, but Peter promises it’s a very fascinating episode
- We start with some semantics and definitions
  - We clear the air a little bit on the difference between lactate and lactic acid
- We touch briefly on a historical discussion, looking back at the work of Meyerhof and the early misconceptions around lactic acid and its role in muscle activity and fatigue
- We talk about George’s work which highlights lactate’s integral role in energy processes
  - And not just merely as a waste product
- We talk about the monocarboxylate transporters (MCTs)
  - Peter learned quite a bit in this podcast because up until this point, he had no idea that MCTs were also located on mitochondrial membranes
- We talk about some misconceptions in educational practices today (including what Peter learned)
- We discover a lot about the relationship between lactate and other disease states
  - Such as type 2 diabetes, cancer, and most surprisingly, brain injuries
- Peter emerged from this podcast with both a better understanding of what he already knew and more importantly, a new understanding of what the potential of lactate is in the therapy of human conditions
  - Ranging from cancer to traumatic brain injury

## Our historical understanding of lactate and muscle metabolism: early misconceptions and key discoveries [3:30]

- George’s colleague, [Iñigo San-Millán](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) has been a multiple-time guest on this podcast [episodes [#85](https://peterattiamd.com/inigosanmillan/) & [#201](https://peterattiamd.com/inigosanmillan2/)], and George’s name has come up many times
- Peter referenced George’s work in his [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZc3hWLITcnTc7B2P76ivh285q3LcpZmR8KEgNoEJuv1Zqxeouda-RMCf4k8e11ye-8-8baLYdnwPtSSwii3VQUlQyEAgDd_kSLgVMXkuSNhXa0XZnOvx4niMVZvo7j50qwJLAN-LzVptqJC67rNqR2vj7XvYEnkMkum6F5fYkqOIQareCM3YQ8ABta6croTyXn-WqR2sc6knnGp9Fs3nSWE.zzsFKRXtqKaubUYCWM8sabGF0asdx5aQgMO-2WAD_CU&qid=1717002766&sr=8-1)
- It’s great to sit down with him and talk about [lactic acid](https://en.wikipedia.org/wiki/Lactic_acid), which is probably a misunderstood molecule

**Should we think about this as lactate or lactic acid?**

- We can say lactate
  - The body does not make lactic acid ‒  that has been a hundred-year mistake
- Lactate is not just an innocent bystander; it’s a participant in the process of powering muscle and all cells

**100 years ago,** [**Otto Meyerhof**](https://en.wikipedia.org/wiki/Otto_Fritz_Meyerhof) **made a seminal discovery; tell us a little about what that was and how that started a chain of understanding that brought us to where we are today**

- In the early 20th centuries, people were trying to unite what was known from fermentation technology to what was coming out of studies of muscle metabolism
- Meyerhof was a great man, a great investigator, and one of the things he did was to quantify how much glycogen is in muscle
  - And how when it degrades, it produces lactate (at that time thought to be lactic acid)
- The experimental set up that Meyerhof and colleagues used was half a frog in a jar without oxygen supplementation, without any perfusion that has blood flow
  - In this half a frog, the muscles were made to contract, and they contracted until they couldn’t contract anymore
  - Then quantitatively, Meyerhof could say, well, there was X amount of glycogen and there was X amount of lactate produced

![](https://peterattiamd.com/wp-content/uploads/2024/07/f1-georgebrooks-1024x592.png)

**Figure 1**.

- That was really instrumental in developing this pathway
- But if you look at this, this is really not what we are
  - These muscles are made in nature to contract once or twice
    - The frog hops; it gets away or gets eaten
  - The muscle is not representative of us
- But in this situation, they stimulated the muscle to contract
  - It stimulated glycolysis to produce ATP
  - And at the end the muscle fatigues
  - And at the end there was a lot of lactate and there was also a lot of acid

***This is how he came to associate lactate (or lactic acid) production and oxygen lack (because there was no oxygen around here), and this led to the idea of lactic acidosis and the anaerobic threshold and the oxygen debt***

- But if you just look at this simple, simple apparatus where we have a half a frog made to contract, this is really the aegis of our **understanding of how carbohydrate is used in the body**
- Most textbooks talk about: [glycolysis](https://en.wikipedia.org/wiki/Glycolysis) goes on to make [pyruvate](https://en.wikipedia.org/wiki/Pyruvic_acid) and when there’s no oxygen → [lactic acid](https://en.wikipedia.org/wiki/Anaerobic_glycolysis) [[anaerobic glycolysis](https://en.wikipedia.org/wiki/Anaerobic_glycolysis) shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/07/f2-georgebrooks.png)

**Figure 2. Anaerobic glycolysis (produces lactate) versus aerobic glycolysis (which occurs in the mitochondrion)**. Image credit: [*Nature Reviews Cancer* 2004](https://pubmed.ncbi.nlm.nih.gov/15516961/)

- This has been a problem, and it spills over not only into muscle physiology, but it spills over into pulmonary medicine
  - It spills over into cardiology
  - It spills over into nutrition
- We know a lot of things that could not be known at that time

**Peter’s recap**

- Some folks couldn’t see that image, but it was basically a schematic of an experiment
  - The musculature of part of a frog is put into an anaerobic chamber (with no oxygen), and it’s not perfused (so there was no blood to carry hemoglobin to carry oxygen to the muscles)
  - Presumably electrodes were placed somewhere on the musculature within the chamber and the electrodes provided the stimulation for muscle contraction

*The question became: what is it that fueled the contraction?*

- Obviously, it’s the glycogen within the muscle
- But if [glycogen](https://en.wikipedia.org/wiki/Glycogen) (or glucose) is being used to fuel contraction without oxygen, it somehow must be happening in the absence or exclusion of the [mitochondria](https://en.wikipedia.org/wiki/Mitochondrion)

***And so what they were measuring was the consumption of glycogen, the production of lactate, and presumably they could measure the pH in the solution***

- Peter is assuming that the pH, which is a measure of acidity, was going down

Peter asks, “*And so the interpretation of that observation was what at the time?*”

> “*But since then, people have associated the appearance of lactate with oxygen lack. That’s a mistake*.”‒ George Brooks

- First of all, that was important in terms of quantifying glycolytic pathway precursor and product
  - You start with a certain amount of precursor, you wind up with a certain amount of product
- There was no oxygen there

***It’s a stress-strain kind of relationship***

- The muscle is stressed to perform, and it uses what it has (glycogen)
- It produces lactate and there is also an [acidosis](https://en.wikipedia.org/wiki/Acidosis)
- There’s association with lactate and lactic acidosis and fatigue; this whole thing was boiled up in one knot
- When George learned exercise physiology, it was all those same things: fatigue, acidosis, lactic acid

Peter asks, “*In the experiment that Meyerhof did almost exactly 100 years ago, at some point I assume the frog’s leg stopped contracting in the presence of the stimulus. And is it believed that that was due to a depletion of glycogen, or was it believed that the degree of acidosis had become so significant that the acidosis crippled in some way the actin and myosin filaments of the muscle and prevented either further contraction or relaxation?*”

- Exactly, at that time, people were trying to understand why muscles contracted, and it was just a simple kind of thing like, let’s have tea
  - Would you like tea with cream or would you like it with lemon? Oh, I would like with both.
  - So right then you get this curdling, the acidosis
- One idea of muscle contraction was that actually the actin and myosin kind of curdle and then they have to uncurdle
- So it was believed that the accumulation of lactic acid, caused fatigue

**When you look back at that experiment, what do you believe was the explanation for why the frog’s muscles ceased to contract in the presence of an ongoing stimulus?**

- Peter asks this so people can understand how George thinks about this problem today based on the entirety of his work

***George thinks there was*** [***ATP***](https://en.wikipedia.org/wiki/Adenosine_triphosphate) ***and*** [***creatine phosphate***](https://en.wikipedia.org/wiki/Phosphocreatine) ***depletion in this anaerobic environment***

Peter asks, “*By the way, in an experiment of that nature, how much does the pH go down?*”

- George doesn’t think they reported pH, but he pH would probably go just a bit under 7
- Peter explains for folks listening who aren’t familiar with [pH](https://en.wikipedia.org/wiki/PH), the number can be as low as 1 and as high as 14 [shown in the figure below]
  - Physiologically in a mammal, it’s very hard to get too much below the high 6s and too high above the high 7s
    - Physiology tends to exist in the 7s with 7.38 being perfectly neutral
  - The higher the number, the more basic, and the lower the number, the more acidic

![](https://peterattiamd.com/wp-content/uploads/2024/07/f3-georgebrooks-1024x638.png)

**Figure 3. The pH scale**. Image credit: [Natural Bio Health](https://naturalbiohealth.com/how-learning-the-ph-scale-can-create-a-more-balanced-diet/)

**A funny anecdote (maybe not so funny), but common story when Peter was training in surgery**

- When trauma patients are brought into the trauma bay, one of the pieces of data that the paramedics have on the way in is the pH
  - They can measure blood pH very quickly and easily, and that became a way that we would triage readiness in the ICU and in the operating room
- When gunshot wound victims or stab victims were being brought in, even if they were alive, if their pH was seven or 6.9, we knew that it was very unlikely that they would survive even if their heart was still beating at the moment that that was reported to us
- Peter can think of 1 case that was a miraculous case where a guy was brought in with a pH of 6.9 on arrival and he managed to survive

***It is funny how the body really, really regulates acid-base balance***

- Let’s fast-forward a little bit ‒ [Meyerhof](https://en.wikipedia.org/wiki/Otto_Fritz_Meyerhof) won the [Nobel Prize](https://www.nobelprize.org/prizes/medicine/1922/meyerhof/biographical/#:~:text=For%20his%20discovery%20of%20the,Physiology%20or%20Medicine%20for%201922.) for that observation in 1922
  - We sometimes refer to him as the father of physiology or the father of muscle physiology or the father of exercise physiology
  - He was awarded it along with [A.V. Hill](https://en.wikipedia.org/wiki/Archibald_Hill), and A.V. Hill is a very famous name in physiology
- Peter doesn’t remember exactly when [Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) made his seminal observation, but he’s guessing it was about 2 decades later (in the 1940s)
- Otto Warburg was actually Meyerhof’s professor in Germany
- The [Warburg effect](https://en.wikipedia.org/wiki/Warburg_effect_(oncology)) with **cancer cells**: cancer cells will take sugar (glucose) and make lactate, and they do that under fully aerobic conditions (under room air, where the oxygen is actually higher than it ever is in the body)
  - And these cancer cells will just break down carbohydrate, break down glucose
  - Quantitatively, you wind up with this lactate and acid
- If you look at the glycolytic pathway, at the end is this pyruvate anion and a proton NADH, (this redox carrier), it gives us lactate anion and [NAD+](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide)
  - So the last step in glycolysis does not make acid; it’s actually an alkalizing step
  - [see the figure below, since NAD+ carries the H+ ion, acid is not produced]

![](https://peterattiamd.com/wp-content/uploads/2024/07/f4-georgebrooks.png)

**Figure 4. Glycolysis and the production of lactate**. Image credit: [*Frontiers in Ophthalmology* 2023](https://www.frontiersin.org/journals/ophthalmology/articles/10.3389/fopht.2023.1296624/full)

- But in metabolism, there’s a lot of things that can give rise to acid, and some of the intermediates in the glycolytic pathway are acids
  - There’s lactate and there’s acid
- Peter’s observations in the ICU to be concerned about pH is really important
- Sometimes people also measure lactate
  - In [sepsis](https://en.wikipedia.org/wiki/Sepsis) or other conditions
  - Lactate is used as a surrogate for something that was of greater concern in the ICU: pH balance

## Fundamentals of metabolism: how glucose is metabolized to produce ATP and fuel our bodies [16:15]

**At a high level, this is what Peter tells a patient**

- Food is chemical energy
  - You eat these things and they have bonds in them, especially hydrocarbons
  - They’re incredibly rich in stored potential energy within the carbon-carbon and carbon-hydrogen bonds in particular (these are the most energy rich bonds)
- Metabolism is a fancy word for taking the chemical energy that is stored within the bonds (primarily between carbon and hydrogen and carbon and carbon) and turning that into electrical energy
- And that electrical energy is used to turn back into chemical energy
- So you take the electrical energy in the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain), for example, and then you shuttle it back into chemical energy in the form of [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate)
- Basically food to ATP is just changing the form of energy, but obviously energy is conserved in this process
  - That’s just kind of like a hand waving high-level explanation
- For the purpose of this discussion, we should go a little deeper and explain through the lens of glucose, which we’ll treat as synonymous with glycogen

**Walk us through how glucose is used by a cell that needs to make ATP. What are the different paths it can go down?**

- When glucose is activated to break down, there are barriers to that

*Start with getting glucose into the cell*

- Glucose is a molecule that can be quite high on the blood, but it can’t get into the cell
  - It needs a transporter
- Some of the transporters are constitutive (they’re in all cells)
- The first [glucose transporter](https://en.wikipedia.org/wiki/Glucose_transporter) discovered was named 1, and then 2, and 3, and 4
- [GLUT4](https://en.wikipedia.org/wiki/Glucose_transporter) is important because 4 is expressed in most of our body, in our muscles and in our fat cells
- We need to have these glucose transporters at the cell surface
- And depending on the various kinds of signaling [to move the glucose transporters to the cell surface], now glucose can come in
  - Insulin is a typical signal
  - Also muscle contraction will move these transporters to the cell surface
- When George teaches glycolysis to his class, he uses one of the textbook figures where it starts out with glucose, but he puts the brakes on and says, “N*o, we need to put a membrane barrier in here.*”

***We need to get glucose into the cell, and then it can be metabolized***

- Once the glucose is in the cell, then there are 2 things that can happen
  - 1 – It can be stored as glycogen
  - 2 – But if there’s an energy need, it will enter the glycolytic pathway and be degraded
- There are a couple of important regulatory steps, which involve phosphate level and redox, but it’s simple to say that the **glucose splits into two**
  - Glucose is a 6-carbon molecule that is split to make 2 3-carbon molecules
    - Depending on who you are and how you drive this pathway, the last step is either [the production of] pyruvate or lactate

![](https://peterattiamd.com/wp-content/uploads/2024/07/f5-georgebrooks.png)

**Figure 5. Overview of glycolysis and the production of either pyruvate or lactate**. Image credit: [Khan Academy](https://www.khanacademy.org/science/learn-to-clone-a-sheep-and-more/xb1ef3389afa1715a:microbes-in-human-welfare/xb1ef3389afa1715a:microbes-in-industrial-and-household-products/a/lactic-acid-and-alcohol-fermentation)

- What we found recently, because we traced the glucose to see what it makes, glycolysis basically goes to lactate
  - It’s a series of steps
  - One product is a reactant for the next step, and there’s a splitting of 6-carbon molecule to 2 3-carbon molecules that progresses to lactate
- The process itself is basically pH neutral

***The 6-carbon glucose is split into 2 3-carbon halves and can either make pyruvate or lactate, and either choice is pH neutral***

- Actually, if you get to lactate, it’s an alkalizing step, but he whole process itself is basically pH neutral
  - We’re talking about muscle
- This has been George’s thinking for his whole 50-year career about what happens in muscle
- One way to think about metabolism is the flow of energy, carbon derived energy

***And on this energy highway, carbon is reduced chemically then when it can be oxidized, a lot of energy is released, and we can capture that as ATP***

- George explains, “*When our muscles are working and doing glycolysis, 80% of that carbon flow comes from the previously stored carbohydrate glycogen*.”
- He has done numerous experiments looking at carbohydrate oxidation and exercise and the use of glucose, and really the body protects its glucose pool because there are certain cells that really need glucose, like our brain
- If we got our muscles going, they could suck up all the glucose and leave us really [hypoglycemic](https://en.wikipedia.org/wiki/Hypoglycemia) and we would crash
- Just the active muscles are going to take up glucose, but it’s not going to be a major part of the energy; it’s maybe 20, 25%
  - Most of that carbon is going to come from previously stored glucose, which we call glycogen
  - Peter adds that about 80% of the body’s total glycogen (or stored glucose) is found within skeletal muscles while the remaining 20-25% would be in the liver
- The **liver’s primary responsibility** is regulating blood glucose for the brain
- Where as, having all of that stored glycogen in the muscle is an important source of fuel for the muscle, so it doesn’t have to steal glucose from circulation that would otherwise be imperative to keep the brain happy
- Another important role lactate plays is in replenishing the liver
  - That was another [Nobel prize in 1947](https://www.nobelprize.org/prizes/medicine/1947/cori-gt/facts/) for discovery of the [Cori cycle](https://en.wikipedia.org/wiki/Cori_cycle)

## The critical role of lactate in energy production within muscles [24:00]

**What happens to lactate when it is produced in the metabolic process of breaking down glucose, and what determines that path choice in a normal muscle cell that needs ATP?**

*What are the physiologic pressures that drive towards pyruvate versus lactate?*

- We have a couple of steps that depend on [redox](https://en.wikipedia.org/wiki/Redox), but one of the things that’s been noticed by our colleagues who really have done a lot of muscle biopsies is that ***it’s not the ATP level that falls because the whole system is set up to maintain homeostasis of ATP***
  - But we get changes in [NAD and NADH ratio](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) (or redox), but we get changes in [ADP (adenosine diphosphate)](https://en.wikipedia.org/wiki/Adenosine_diphosphate)
- When we have this ATP molecule, there are 3 phosphates and we get energy by splitting 1 off and it gives us ADP [shown below]

***Turns out it’s a big signal to activate these enzymes of processing glucose***

![](https://peterattiamd.com/wp-content/uploads/2024/07/f6-georgebrooks.png)

**Figure 6. Cycling of ADP to ATP to store and use energy**. Image credit: [Khan Academy](https://www.khanacademy.org/science/ap-biology/cellular-energetics/cellular-energy/a/atp-and-reaction-coupling)

- We know that in a lot of ways if we just take an isolated mitochondria (take a muscle, isolate the mitochondria), and we want to turn them on and make them start doing something, we need to add ADP and away they go
  - They start to phosphorylate that ADP and make ATP by the chemiosmotic process, which you described as electrical energy
- So yes, the muscle mitochondrial network works like a big battery
- George doesn’t know if we’ll talk about mitochondrial functionality or about its arrangement
  - It’s a network
  - They’re not just little capsules
  - This whole network, he calls it the energy highway; other people have called it the cellular energy power grid

***Anyhow, that’s where the ATP is going to be generated, and to do that, you need this chemical energy fuel, which is pyruvate or lactate***

- People have assumed that it’s pyruvate that goes into the mitochondria, and it’s true that happens

***But most of that chemical energy comes in the form of lactate that goes into the mitochondrial reticulum or network, and that’s the fuel to run the apparatus of oxidative phosphorylation and make ATP***

**Peter points out**: for people and physicians listening who have studied this, that is the biggest departure from everything we ever learned

- The textbook says when you make **pyruvate** out of glucose, the pyruvate gets shuttled into the mitochondria, and there we undergo the Krebs cycle [aka the citric acid cycle, illustrated below] where we very, very efficiently produce massive amounts of ATP, and the only byproduct is carbon dioxide and water
  - As we are undergoing aerobic respiration, we’re consuming oxygen and pyruvate generating, again, incredibly efficient amounts of high volume ATP

![](https://peterattiamd.com/wp-content/uploads/2024/07/f7-georgebrooks.png)

**Figure 7. Pathways needed for aerobic respiration**. Image credit: [Khan Academy](https://www.khanacademy.org/science/biology/cellular-respiration-and-fermentation/variations-on-cellular-respiration/a/connections-between-cellular-respiration-and-other-pathways)

- Out comes carbon dioxide and water, which is what we’re breathing out
- Conversely, when you take that glucose and you make **lactate**, you do generate ATP, but very, very little amounts
- And that lactate now needs to escape the cell, make its way into the circulation where it can go back to the liver and be turned back into glucose via the Cori cycle to begin again

***Peter does not remember any discussion of lactate going into the mitochondria directly from the cytoplasm as a substrate for ATP production under aerobic respiration***

> “*We’ve been teaching glycolysis wrong for a hundred years*.”‒ George Brooks

- George explains that’s an assumption that’s really deleterious
- That lactate that’s formed enters the mitochondria, and we have shown that there’s a mitochondrial carrier for the lactate to get in, and we call it the [mitochondrial lactate oxidation complex](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0002915)
- We have electron micrographs and light micrographs to show how this process works and that the enzymes are there for lactate oxidation

***Lactate is important as a fuel***

- The first articulation of a lactate shuttle was by the Cori’s ([Carl](https://en.wikipedia.org/wiki/Carl_Ferdinand_Cori) and [Gerty Cori](https://en.wikipedia.org/wiki/Gerty_Cori))

***They showed that a dog muscle made to contract with adrenaline or otherwise will release pyruvate and lactate, which will recirculate to the liver and become glucose***

- That’s a way to supply blood glucose during exercise
- So the muscles are actually not only fueling themselves, they’re fueling adjacent tissues and they’re fueling the brain by this lactate shuttle or [Cori cycle](https://en.wikipedia.org/wiki/Cori_cycle)

![](https://peterattiamd.com/wp-content/uploads/2024/07/f8-georgebrooks.png)

**Figure 8. The Cori cycle**. Image credit: [ScienceFacts.net](http://sciencefacts.net)https://www.sciencefacts.net/cori-cycle.html

Peter asks, “*Is it a velocity or a demand dependent process? In other words, if ATP is being demanded at a very high rate, is the body in that scenario preferentially taking the lactate back to the Cori cycle, back to the liver to make glucose versus if the body has the time, it can make the long-term investment in getting more ATP per unit carbon by putting lactate into the mitochondria?*”

**Peter summarizes the traditional thinking on this**

- We go down the lactate pathway when we are demanding ATP faster than oxygen can be supplied to the mitochondria, and that’s why it’s referred to as this **anaerobic pathway**
- And if we have the time, if the ATP demand is low enough that we can afford to get oxygen to the mitochondria, well then we would always preferentially go down the [oxidative phosphorylation pathway](https://en.wikipedia.org/wiki/Oxidative_phosphorylation)

## Lactate as a preferred fuel during high-energy demands: impact on fat oxidation, implications for type 2 diabetes, and more [30:45]

*In the “mind-boggling” discovery that George is talking about, what determines the path?*

***It’s this ADP to ATP ratio ‒ that’s what accelerates glycolysis***

Peter asks, “*If the ADP to ATP ratio is low, which tells us ATP is being consumed quickly, does that drive lactate into the mitochondria or out to the liver?*”

- Recently, others have shown that lactate activates the mitochondria
- George has shown that lactate is a preferred fuel [reviewed in [2018](https://pubmed.ncbi.nlm.nih.gov/29617642/) and [2021](https://pubmed.ncbi.nlm.nih.gov/34719944/)]

**What do you mean by lactate activates the mitochondria?**

- Lactate activates [lactate dehydrogenase](https://en.wikipedia.org/wiki/Lactate_dehydrogenase), the enzyme in mitochondria which allows the carbon flow to go into the mitochondria for oxidation

Peter asks, “*Does that mean that it also amplifies other substrates flow through? So in other words, if you have a bunch of acetyl-CoA hanging around from fatty acid breakdown, is that also being stimulated to run through the mitochondria at an accelerated rate?*”

- To the contrary, we compare glucose to lactate to fatty acids and lactate is preferred over glucose in the brain and muscle
- The **path of degradation of lactate** is to generate this [acetyl-CoA](https://en.wikipedia.org/wiki/Acetyl-CoA), and that inhibits the enzymes that transport acetyl-CoA or fatty acids into the mitochondria

***So lactate basically shuts the door, blocks fatty acid metabolism***

- [Iñigo](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) and George have [shown](https://pubmed.ncbi.nlm.nih.gov/35308271/) this as [CPT-I](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_I) and [II](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_II), the carnitine-palmitate transporters
  - These are transporters that allow fatty acids to get into the mitochondria for [oxidation](https://en.wikipedia.org/wiki/Beta_oxidation)
- So yes, there is a competition amongst substrates and lactate shuts the door for fatty acid metabolism
- Peter is struggling to understand teleologically why that makes sense
  - He’s missing something, because he would never for a second suggest his intuition should be better than a billion years of evolution

**Why is it that we would ever want to shut down a substrate for which we have an infinite supply?**

- We’re carrying around more than a 100,000 kilocalories of fatty acid
- Why wouldn’t we always want to maximize our ability to utilize that substrate at the expense of something relatively finite as glycogen, which of course is necessary to even make the lactate?
- George explains, “*Well, that’s part of the fight and flight mechanism. So in terms of our survival, what are we going to save the fats for? The tiger?*”

***If you are in a lactate-dependent state, something has gone wrong ‒ you’re basically in a sympathetic state, and you don’t have the luxury of slow-burning fat***

**But fats are really important**

- You can see this play out in a natural world: we fight, we hunt, we escape
  - And this is really glycogen and glucose dependent

***Now our energy stores are depleted, and in recovery is when we’re going to use these fats***

**Resting levels of lactate in someone who has type 2 diabetes**

- For Peter, this makes more sense with something they’re going to talk about later (they [discussed previously with Iñigo](https://peterattiamd.com/inigosanmillan2/))
- You look at lactate levels in individuals at rest who have [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes) versus lactate levels at rest in world-class athletes, there’s a significant difference
- The great irony of that is the very low levels of resting lactate in the athlete mean that at rest they’re quite capable of oxidizing fatty acids when sympathetic drive is low and demand is low
- And yet paradoxically, the individual with type 2 diabetes who would most benefit from fatty acid oxidation, is presumably now inhibited in doing so because of those elevated levels of lactate

*Is that probably a fair assessment?*

- Yeah, that basically shuts down the fat metabolism

*Consider George’s old thinking*

- That lactate there [in diabetics] is elevated because of lack of disposal, not necessarily production
- It’s there because of failure to dispose

*George’s new thinking*

- The body, in a diabetic situation, has a hard time taking up glucose because insulin- signaling and the GLUT4 mechanism is not working very well

***So think about lactate not as a stress, but as a strain***

- So now we’re going to bypass this inhibition of glucose uptake, and we’re going to provide, actually, the preferred carbohydrate (lactate)
- We see that not only in diabetes, we see that in the heart after [MI](https://en.wikipedia.org/wiki/Myocardial_infarction)
- We had an MI because we had ischemia and we had a blockage
- Why would the heart prefer fast-acting fuel versus a slow-acting fuel?
  - Because it needs energy because it needs to survive

**How does one measure the kinetics by which one mole of lactate versus one mole of glucose versus one mole of fatty acid can produce ATP?**

*What are the tools that allow you to make the observation that one fuel is preferred over the others, or that the kinetics of one fuel are faster than that of another?*

- We use isotope tracers to do that
- In George’s first experiments where he gave carbon-14 labeled lactate to rats, then they would go into the tissues and try to measure it
  - It’s all gone
  - It’s been burned out into the atmosphere
    - Meaning the only place that C14 carbon would be found now is in carbon dioxide if you had a calorimeter
- George has done a number of experiments in collaboration with others or just on his own
- We’ve developed a technique called a [lactate clamp technique](https://pubmed.ncbi.nlm.nih.gov/12376315/), and it’s analogous to the [glucose clamp technique](https://en.wikipedia.org/wiki/Glucose_clamp_technique), which some of the physician listeners will know about
  - That’s where you raise the glucose to a certain level, and then you can study the production versus the disposal
- George infuses lactate up to 4 mM (and others have raised lactate even to higher), and when he does that, he can [measure](https://pubmed.ncbi.nlm.nih.gov/12411539/) the arterial-venous difference for glucose uptake
  - And it’s suppressed
- In a [study](https://pubmed.ncbi.nlm.nih.gov/25709562/) with UCLA, they did some PET scanning with a **traumatic brain injury** patient
  - This is a fancy way to say we can take a picture where glucose is being metabolized in the brain
  - You could see [in the figure below] there’s a blockage for glucose to get into the left frontal lobe in this patient
  - The next day, we infused lactate to 4 mM, and it completely stopped the glucose uptake
    - No glucose uptake in a PET scan. I can show you the image.

![](https://peterattiamd.com/wp-content/uploads/2024/07/f9-georgebrooks.png)

**Figure 9. Pet scan of a patient with traumatic brain injury**. Image credit: George shared by email

- Peter agrees, this clearly demonstrates that lactate is preferred over glucose

**Is the brain getting more ATP from lactate as the preferred fuel than glucose?**

- George’s colleague, [Pierre Magistretti](https://people.epfl.ch/pierre.magistretti) in Switzerland has [developed](https://pubmed.ncbi.nlm.nih.gov/29515192/) what he calls the **astrocyte-neuron lactate shuttle**, and that’s really sparked a lot of interest in metabolism in astrocytes [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/07/f10-georgebrooks-1024x698.png)

**Figure 10. The astrocyte-neuron lactate shuttle** Image credit: [*Nature Reviews Neuroscience* 2018](https://pubmed.ncbi.nlm.nih.gov/29515192/)

*For years, George was taught that glucose was the exclusive fuel for the brain*

- Peter adds that [beta-hydroxybutyrate](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid) would also be another fuel for the brain
- George agrees, but not if glucose or lactate is around
- In the injured brain for some reason it only takes up maybe 50% of what’s typical
  - Maybe there’s a block at the splitting enzyme in the glycolytic pathway
  - So globally, the brain is in a metabolic crisis after an injury
  - There’s some neural networking which just stops glycolysis
- Traditionally, what physicians would do is infuse glucose, and the glucose uptake… well, metabolism is blocked so the glucose doesn’t get in and doesn’t do anything
  - Or give insulin
  - Peter recalls that intranasal insulin was one of the tricks used to try to drive more glucose uptake
- The brain doesn’t express [GLUT4](https://en.wikipedia.org/wiki/GLUT4), so that’s not going to do much
- But now we have, instead of the 6-carbon molecule, we have a couple of 3-carbon molecules and the lactate transporters are highly expressed in the brain

***We know that under normal circumstances what’s happening is that the glucose is coming in, being taken up by the astrocytes, made into lactate, which are bathing the neurons in lactate, and lactate is the fuel for neurons***

**George Cahill’s famous fasting studies**

- Peter could have sworn that [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) demonstrated in those very famous [fasting studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC292907/) circa 1960s, 1970s, that even in the presence of glucose, the brain was still taking up significant [beta-hydroxybutyrate (BHB)](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid)
- If he’s not misremembering this, these subjects were fasted for a very long period of time: 40-day water-only fasts
- So these individuals had beta-hydroxybutyrate levels of 4-5 mM, which actually exceeded glucose concentration
- By this point, glucose concentration would’ve been about 3 mM in steady state
  - 3 mM of glucose is equivalent to a blood glucose of 55 mg/dL, and levels never really went below that
    - This is pretty hypoglycemic at about 60% of what you would normally walk around it
- At that level, glucose was meeting about 50% of their brain’s demand and about the other 50% was coming from BHB
- Peter concludes, at least in that situation, the brain would split fuels

***He doesn’t know if Cahill was measuring lactate, but it’s an interesting observation that the brain would split fuels in the presence of BHB and glucose***

- George agrees to the extent that there is competition amongst substrates: more glucose, less fatty acids
  - More fatty acids, vice versa
- Ketones come in by the lactate transporter ‒ the [monocarboxylate transporter](https://en.wikipedia.org/wiki/Monocarboxylate_transporter) allows ketones to get in
  - Meaning that BHB enters the cell through the same MCT transporter that would bring lactate into the cell
- George studied this early on, and there’s a greater preference for lactate over beta-hydroxybutyrate

***So if the concentrations were the same, the transporters would move lactate as opposed to beta-hydroxybutyrate***

**Peter’s experimental question about fuel usage**

- If you could clamp everything, you could have a person walk around with 4 millimolar (mM) of glucose, 4 mM of beta-hydroxybutyrate, 4 mM of lactate, and you’re peripherally clamping those concentrations
  - So you have equal concentrations of three fuels that the brain could use

*What is your prediction for neuronal uptake based on that scenario?*

***In an uninjured person, the preference would be for glucose and lactate in roughly equal amounts in the brain***

- George has [published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4530406/) on this, working with UCLA neurosurgery
  - They did experiments with dideutero-glucose and 13C lactate
    - This is [6,6-2H2]glucose (that is, D2-glucose) and [3-13C]lactate

## How the infusion of lactate could aid recovery from traumatic brain injuries (TBI) [43:00]

**Do this same experiment in a** [**TBI**](https://en.wikipedia.org/wiki/Traumatic_brain_injury) **patient**

- Everybody knows clinically that glucose is going to be suppressed

*How much of that is made up for by the lactate versus the BHB?*

- If lactate is around, it’s going to suppress [BHB](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid)
- Lactate could be the dominant fuel in the injured brain

***At the risk of stating the obvious, Peter point out the implication of this: we should be giving brain-injured people intravenous lactate around the clock to heal their brains (George agrees)***

- For various reasons, George lost his collaboration with UCLA neurosurgery, but they were in the stage II clinical trial of infusing lactate, and they weren’t the only ones
- There’s a [group in Switzerland](https://pubmed.ncbi.nlm.nih.gov/26421521/) [or who preferentially gives hypertonic lactate to TBI patients, and they appear to do better
- We were hoping to have a clinical trial, multi-center trial, demonstrating the use of lactate as an augmentation to glucose in the TBI state, but George doesn’t know what the status of those studies are
  - But there was a stage II clinical trials that started at UCLA

**It would be interesting to see what the uptake of lactate is if you can put an F18 label onto lactate**

Peter asks, “*Has anybody labeled lactate with* [*FDG*](https://en.wikipedia.org/wiki/Fluorodeoxyglucose_(18F)) *(the equivalent of an FDG) so that you could do a PET scan and actually demonstrate significant uptake of lactate in a brain, and then actually do that experiment in an injured brain?*”

- Peter is imagining images that everybody has seen of the injured brain under standard [FDG-PET](https://en.wikipedia.org/wiki/Positron_emission_tomography) where you have the hypoperfusion in the area
  - [the figure below shows an example of this]

![](https://peterattiamd.com/wp-content/uploads/2024/07/f11-georgebrooks.png)

**Figure 11. FDG-PET shows metabolic differences in different groups of TBI patients**. Image credit: [*Journal of Neurotrauma* 2011](https://pubmed.ncbi.nlm.nih.gov/21770759/)

- This is also relevant in diseases like [Alzheimer’s](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) and dementia where we see hypoperfusion of glucose
- George doesn’t know if this has been done
- His colleague at Berkeley, [Tom Budinger](https://bioeng.berkeley.edu/faculty/thomas_budinger) helped develop PET and helped make NMR clinically relevant
- He did experiments with carbon-11 lactate
  - In the PET scanner, it gives a signal (as does fluorodeoxyglucose) so that way you could see lactate taken up by the brain
- The difficulty with those experiments, is that the half-life of carbon-11 is on the order of minutes (20 minutes)
- The first experiments involved somebody in the cyclotron making carbon-11 lactate, putting it into a lead-lined station wagon, driving it down, running it through a column to remove the strontium 82, and then infusing it into his brain and imaging the brain
  - So it’s possible with carbon-11 to do that experiment

Peter asks, “*Any reason not to just put F18 onto lactate? Is that chemically not feasible?*”

- George hasn’t thought about hat
- Peter thinks this would be an interesting experiment, at a minimum just to generate a hypothesis that says we can fill an energetic gap by using lactate and simply observing a difference in perfusion pre- and post-lactate infusion
  - Maybe he’s missing something obvious about the chemistry of it
- George explains that Budinger would do it
  - When he would do the experiments with glucose or lactate, he also would give rubidium-82, which is a marker of flow
  - So he would want to do exactly what Peter described
    - You would want to know the uptake relative to the flow
    - If the flow is depressed in an area, then you would expect the uptake to be less
    - And so in the Budinger method, you need to view 2 isotopes simultaneously, and that’s really tricky and hard to do clinically
- It could be a great experiment, but getting it to work in clinical centers would be a real trick

**What about in rodent studies of hypoperfusion?**

- Peter assumes that would be an easier place to look at a TBI model where you can ask if lactate can rescue the animal
- George replies, “*We could just do that even without a tracer*.”

Peter asks, “*Is there any issue with infusing lactate at higher concentrations? Is 4 mM sufficient or is there any reason you couldn’t put in 6 or 8 mM?*”

- George thinks his friends in Switzerland have got it up to 8 mM, but then you’re using hypertonic lactate
- People need to understand that what you can give vascularly, can’t be too concentrated
  - The blood can be affected poorly

Peter asks, “*When we give patients an intravenous bag of lactated ringers, what’s the concentration of lactate in that solution?*”

- It’s really low
- What they do is they do half-molar sodium lactate, and we need to understand when we have half-molar sodium, it’s half-molar sodium and half-molar lactate
  - So the osmolality is twice that; it’s a thousand
  - And that’s sort of the upper limit of what you can give safely intravascularly without causing phlebitis, without causing crenation of the red blood cells shrinking and getting all distorted
- But you can clamp a person at 4 mM quite safely and easily
  - The idea was to do that for a couple hours a day, not continuously because we would have to make sure that kidneys were not affected because we’re giving a lot of sodium

**What’s the manner in which the lactate is delivered? In other words, what else has to be delivered with it to balance the solution?**

- Lactate anion has a negative charge, so to put it into the blood, you need to have something with a positive charge, and so the major cation in our blood is sodium
- So what’s used is sodium lactate
- In George’s studies, we could clamp to 4 mM and hardly raise the sodium level in the blood, so we thought that would be an approach that would be reasonable to work with a patient
- But again, you are going to be giving sodium, so you have to make sure that in the patient they have good kidney function

## The effects of exercise-induced lactate [49:30]

- Peter points out, “*The highest lactate I’ve ever measured in myself is about 18 millimole, obviously, after a very intense bout of exercise. Not surprisingly, anybody who’s measured lactate in themselves, anything over 10 is a very, very uncomfortable situation to be in.*”

**Where does the discomfort come from? Because it’s not the lactate that is causing discomfort, right?**

- No, lactate is there to moderate
- It’s a strain response
- It’s helping to protect you, but you probably have a severe acidosis

George asks, “*Are you ever hungry after one of these episodes?*”

- Not at all
- In fact, it’s usually you’re about to vomit if you don’t actually vomit
- George explains, “*Lactate crosses the blood-brain barrier and works in the brain in the hypothalamus to inhibit your appetite.*”
- Those of us who run 440 yards or 400 meters, we’re not hungry for 3 hours, right until that lactate level is cleared, which is really a good reason

**People have** [**written**](https://pubmed.ncbi.nlm.nih.gov/32893673/) **about this recently: lactate inhibits appetite**

- Lactate suppresses [ghrelin](https://en.wikipedia.org/wiki/Ghrelin), and it works directly in the CNS
- An advantage of doing an exercise, not like that one Peter did, but getting lactate up to maybe 3-4 mM, is it would actually help satiate people
  - George knows there are people say, “*Well, I exercise, and I’m really so hungry afterwards*.” and he responds, “*Well, you’re not exercising hard enough*.”

***If you do raise lactate, it will cross their blood-brain barrier; it will inhibit ghrelin secretion, and it will suppress the appetite***

- Peter knows there are people listening who are familiar with lactate testing, and there is a fundamental difference between having your lactate at 1.5 mM (or 1.0 mM, which is where it might be if you go for kind of a brisk walk) versus being at 4 mM (which is not a level you can sustain indefinitely, but it’s also not so strenuous that you could only do it for a few minutes)
  - A fit person could hold that level of exertion [4 mM of lactate] for 30 to 40 minutes

## Metabolic differences between highly-trained athletes and insulin-resistant individuals [52:00]

- Peter thinks this becomes very illustrative because they’re simply different metabolically
  - It’s not just that the athletes are stronger and the non-athletes are not

*What’s happening in terms of fuel partitioning that differentiates a highly, highly trained aerobic athlete, like a cyclist, with someone who’s got insulin resistance? What are the differences in their ability to utilize fuels?*

**First, let’s talk about the mitochondria**

- [Mitochondria](https://en.wikipedia.org/wiki/Mitochondrion) are the sinks or the disposal units
- So when anything fluxes, like carbon flux in the body, it has to go from a production or entry site and has to go to a removal site, and the mitochondrial network is the removal site
- When a highly trained athlete exercises…
- And here we need to talk about **relative or absolute power output**
- Let’s say 65% of VO2 max or 65% of effort, for an **untrained person**, that’s not very much exercise, really
  - They’ll get to 65% of VO2 max at a very low power output
- If we take a **trained athlete**, put him or her at their 65%
  - They’re generating a lot of lactate, but they’re burning it, and it’s recirculating to the core recycle [to the liver] to support blood glucose [via gluconeogenesis, as mentioned with the Cori cycle]

***So even if you just measure the concentration, you don’t have the whole story; you don’t have the flow (or flux rate)***

- Now, if you take that same athlete and you push him to a lactate that elicits maybe 6 or 8 mM, there are going to be really a lot of differences there
- You’ve exceeded the capacity of their mitochondria to clear lactate, and also, you’re probably going to have shunting away from the gut
- This goes back to something we mentioned in passing: [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis) (to making glucose) from lactate depends on good liver blood flow
  - When you start going really, really hard, your blood’s going to go to your muscles, basically, and you’re going to clamp down and you’re not going to perfuse the liver
  - So now that gluconeogenesis goes down, regardless of who you are, when you take the liver and the kidneys out of circulation, then the lactate level is going to be  higher
    - And of course, those are major organs of lactate disposal as well, accounting for 20, 25% (mentioned earlier)

**Going back to something George said earlier about what determines the fate of lactate**

- As the individual is increasing energy demand, they’re making more and more lactate

*Is ADP or ADP to ATP helping to determine when the lactate is going in the mitochondria versus back to the liver?*

- Because in the scenario George described where energy demand is going up and up and up, and therefore perfusion is going down in the organs that are able to recirculate lactate, you would think that the body would just say, “*Okay, no problem. I’m going to shovel more lactate into the mitochondria. I’ve got a perfect engine here to generate more ATP.*”

*In other words, why is that a problem that the lactate now can’t be cleared as efficiently through the gluconeogenic pathways?*

> “*Go again to your example of the athlete. When we train, we increase our mitochondrial mass maybe a hundred percent. If we train, we’ll raise our VO2 max maybe 10, 15%. There’s more plasticity in the muscle to increase the mitochondrial mass*.”‒ George Brooks

- George thinks training to increase mitochondrial mass is the key to [Iñigo’s](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) success with his athletes

***You can double your mitochondrial mass through training***

Peter asks, “*Over what period of time?*”

- The [first study](https://pubmed.ncbi.nlm.nih.gov/4290225/) on this appeared in 1967 and was done in rats by [John Holloszy](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00669.2018) over the period of several weeks of training rats
- Those studies were extended a bit with [Kelvin Davies](https://gero.usc.edu/faculty/davies/) to [show](https://pubmed.ncbi.nlm.nih.gov/22573103/) a sort of doubling of the mitochondrial mass
- Others have looked into the muscles of athletes and found that they have more than twice the mitochondrial mass of the average person
  - And that, of course, is a lot selection

***You see 2X the mitochondrial mass, not necessarily the number of mitochondria***

Peter asks, “*How is that conveyed? Is that larger mitochondria plus more mitochondria that amounts to that doubling?*”

- We talk about the [mitochondrial reticulum](https://pubmed.ncbi.nlm.nih.gov/3752235/)
  - Think about a tree budding and branching out leaves
  - If you do a thin section, and you do point counting, 1 mitochondrion and 2 mitochondrion 3 mitochondrion, 1000 mitochondrion, but they’re all part of a network
  - What you have is a bigger energy delivery system that goes from the cell surface deep within the fiber through this network
  - ***Some people call it the ‘cellular energy power grid’***

**Has the experiment been done to demonstrate the causality of exercise there?**

- In other words, do we have the experiment where you take untrained individuals, do the muscle biopsy, compute mitochondrial density, mass of mitochondria per unit mass of muscle, train them for 4-6 months, repeat the biopsy, and see if the training is leading to the doubling rather than just saying, “*Well, athletes are athletes because they have more mitochondria”*?

- George explains that it works both ways: if you are borne with that and you go into athletics, you’re successful
- It goes up proportionately
- Interesting, all the enzymes that are the constituents that make up this mitochondria network go up proportionately (as far as we can tell)
- So you get twice as much [Krebs cycle enzymes](https://en.wikipedia.org/wiki/Citric_acid_cycle), twice as much [electron transport cycle enzymes](https://en.wikipedia.org/wiki/Electron_transport_chain)
  - You basically activate the whole system

## How training enhances lactate utilization and facilitates lactate shuttling between fast-twitch and slow-twitch muscle fibers [58:45]

**Tell folks what an MCT is**

- George was looking for the ***lactate transporter protein***, and he got scooped
- Dr. [Christine Kim Garcia](https://www.vagelos.columbia.edu/profile/christine-k-garcia-md#credentials-amp-experience) in the [Goldstein lab](https://labs.utsouthwestern.edu/brown-goldstein-lab/people) in Dallas found it
  - It’s a Nobel Prize Lab
  - They were looking for transporters of things that contributed to cholesterol metabolism, and she found this protein
  - She found out it was a lactate transporter, and so they were called [monocarboxylate transporters](https://en.wikipedia.org/wiki/Monocarboxylate_transporter)
- Now it slides to the glucose transporter field where we have the 1st isoform and the 2nd one and the 3rd and the 4th
  - There are actually more than 4 now that have been discovered
  - The 1st one was discovered around 2000

**What Peter was taught is at best an oversimplification and at worst, it might be abjectly wrong**

***One of the benefits of training was increasing the density of MCTs***

- In other words, the harder I trained, the more I increased the density of these MCTs in my muscle cells
- And what that allowed me to do was produce more lactate, but get it out of the cell and back to the liver
- Imagine a little cartoon where I’ve got a muscle cell
  - I’m **untrained**, and I’ve got 50 MCTs
  - After **training**, I’ve now got 100 MCTs, after a period of time, not acutely, but years of training or whatever
    - And therefore, I can now make twice as much lactate and get that lactate out
- Now of course, all of this was predicated on the model that said more lactate in the muscle is bad because with lactate goes hydrogen and hydrogen inhibits performance
  - That was all viewed through that lens

*Was there any truth to the idea that as we train more, we increase the density of MCTs, which if nothing else, I assume, would give us more flexibility in this lactate flux game?*

- Yes
- This has been done in animals

***George has*** [***looked***](https://pubmed.ncbi.nlm.nih.gov/22012699/) ***at at trained and untrained people, and sees an increase in the abundance of the MCTs***

- Getting lactate into the mitochondrial network requires an MCT
- George was bold enough to look at a mitochondria and find MCTs
  - People think, “*Well, it’s just on the cell membrane, and it’s good for export;*” and that’s true, but in oxidative muscle fibers with the abundance of transporters, many of them are in the mitochondria

***That helps 2 ways: the lactate will move into the mitochondria as well as can be exported***

**We see a difference between fiber type**

- **Fast [-twitch] glycolytic fibers** will be pale in color, and they’re pale because of less heme oxygen compounds
  - They’ll have less blood flow, fewer capillaries per fiber
  - They’ll have less myoglobin, and mitochondria are the color of liver, or vice versa (liver is the color of mitochondria)
  - Those fibers, when they’re made to contract, they have lesser mitochondrial density
  - They will export lactate, but they can export it to a neighboring red fiber

***We call this the “cell-cell lactate shuttle” where a fast glycolytic fiber produces lactate, and it’s consumed by an adjacent fiber and never even appears in the venous blood except as CO******2***

- Peter has never heard that
- He’s had many podcasts that discuss **type I and type II muscle fibers** (colloquially referred to as slow-twitch fibers and fast-twitch fibers [[episode #250](https://peterattiamd.com/andygalpin2/)])
- The **slow-twitch fiber** (the type I fiber) is the red fiber
  - It’s the fiber that is dense in mitochondria
  - It is the one that has the capacity for oxidative phosphorylation
  - It is less powerful, but much slower to fatigue
- Then you have these **type II fibers** (fast-twitch)
  - Oversimplifying a little bit because there are subtypes of them
  - But the type II fiber, it’s a more contractile, more powerful fiber
  - It twitches a little faster
  - But it is very fast to fatigue
  - It’s the white fiber because it is lacking in the mitochondria

Peter asks,  “*Does it outright lack mitochondria and basically it’s just a pure glycolytic fiber?*”

- No, there are mitochondria in there, just a much lower density
- What George said a second ago is that as those cells [type II, fast-twitch] accumulate lactate, they realize that their neighboring Type I cells can make even more use of the lactate given that they have a greater density of mitochondria

***Fast-twitch type II muscle fibers will shuttle lactate to slow-twitch type I muscle fibers [where the lactate can be oxidized]***

Peter asks, “*Is that correct?*”

***Yeah, that’s actually part of the discovery of the lactate shuttle***

- Early on when George started doing the studies on rats and you see 14-lactate and tritiated glucose and comparing the flux rates of the two and looking at the various fates of where the carbon goes
  - He knew that there was, in exercise a large flux, but from the tracer itself, you can’t tell where
- George’s colleague at UC Irvine, [Ken Baldwin](https://medschool.uci.edu/news/memoriam-kenneth-m-baldwin-phd) did his studies on rats and he made them exercise hard
  - Then he measured the lactate levels in blood, in red muscle and in white muscle
  - A rat made to run hard has a very high level of lactate in the fast glycolytic Type II fibers

Peter asks, “*Can you give me the approximate concentrations in that type of an experiment between blood Type I and Type II?*”

- George will finish the analogy and then put some numbers on it
- Ken measured the lactate level in the arterial blood, and of course it was lower, and in the red muscles, the lactate level was lower than in arterial blood
- That gave rise to the idea that the fast fibers were sharing lactate, not just to the venous blood, but to the red fibers that were adjacent
- The numbers, George is trying to remember, this is back 30 years
  - In the fast fibers, it would be something like 10-12 milli equivalents
  - In the arterial blood it would be 4
  - In the red fibers it would be 3
- That gave rise to this idea of a shuttle (some people call it a shunt) from white fibers to red fibers

***As Peter described earlier, it’s easy for the white fiber to export the lactate, but it will export it in a three dimensional sense, being surrounded by slow red fibers who can oxidize lactate***

## The growing recognition of lactate and monocarboxylate transporters (MCT) [1:06:00]

**When did you first find MCTs on mitochondrial membranes?**

- About 1995

**What percentage of the relevant scientific community acknowledges that now?**

*Is it taken for granted within your world that that is completely settled and is it just that hasn’t made it out to any of the textbooks yet?*

- George along with [Tom Fahey](https://www.researchgate.net/profile/Thomas-Fahey-5) are revising their [textbook](https://www.amazon.com/Exercise-Physiology-Human-Bioenergetics-Applications-dp-0072556420/dp/0072556420/ref=dp_ob_title_bk), and are going to get it right

> *“There’s been a stonewall silence*.”‒ George Brooks

- For instance, in *Science* magazine, they published 2 papers simultaneously on the mitochondrial pyruvate transporter
  - [[Identification and Functional Expression of the Mitochondrial Pyruvate Carrier](https://www.science.org/doi/10.1126/science.1218530)]
  - [[A Mitochondrial Pyruvate Carrier Required for Pyruvate Uptake in Yeast, *Drosophila*, and Humans](https://www.science.org/doi/10.1126/science.1218099)]
- Previously George had shown the mitochondrial lactate transporter ‒ wasn’t even cited
  - Neither the editors or the reviewers knew about it

***Now things are changing, there is a lot of interest in lactate***

**Why  do you think something that was discovered 30 years ago that appears quite germane to the physiology of everything, but if nothing else, just through the physiology of exercise, but it clearly extends beyond that, why do you think that this isn’t more widely understood even in the physiologic circles that you travel in?**

- George explains, “*People who do science and medicine are smart people, if they learned it a certain way and that’s their set point*.”
- Peter tends to to differ between scientists and physicians, and he says this as no disrespect to his profession
- He thinks that that makes more sense at the physician level where look, medical school is drinking from a fire hose
  - It’s almost beat out of you to question things because you frankly don’t have the time; you’ve got two years to learn so much
- Peter would have to think that that’s quite different for people who choose a scientific pathway where discovery ‒ questioning orthodox beliefs, that is the name of the game

Peter asks, “*Is there something I’m missing here?*”

- George concedes that maybe there is a difference between science and medicine in this regard
- Given the opportunity, George will talk to, for instance, the *Washington Thoracic Society* and go to a meeting and talk to the docs
  - Because when they see lactate, they start infusing bicarbonate or they give oxygen
- In the medical field, there’s a character, his name is [Rinaldo Bellomo](https://research.monash.edu/en/persons/rinaldo-bellomo)
  - He’s a world-renowned physician, emergency room physician, and he’s written about the fact that pulmonologists need to be more like exercise physiologists with regard to understanding lactate metabolism
  - He challenges his colleagues to do that
  - Bellamo is a big name in the field

***There’s been a lot of inertia in this, but George thinks we’re getting some momentum***

## The intricate pathways of lactate metabolism: isotope tracer studies, how exceptional athletes are able to utilize more lactate, and more [1:09:00]

**Peter compared to one of his friends who is an exceptional cyclist**

- He’s one of the to 10 amateur cyclists in the country
- This is a guy who’s in his late 40s and he can still put out 5.3 watts per kilogram for an hour
  - That’s what we would call his functional threshold power
  - When he is on a bike, he can put out 420-430 watts for 60 minutes
    - Peter understands that people listening might not understand what 430 watts feels like, let alone what it would feel like for an hour
- He weighs about 80 kilos [176 lbs]
- He’s an incredible cyclist and great triathlete, but on the bike is where he shines
- At his age, his numbers are almost unheard of, and he would still be at the level of a low-level professional cyclist

*Contrast that with Peter*

- He’s a mediocre cyclist
- Even at his best, his FTP was lower than his
- Today, his FTP might be 3-3.5 watts/kg (very low)
- This friend was over at Peter’s house last week and they were lifting weights together
  - He doesn’t lift weights anymore; all of his energy goes into cycling
  - While Peter does everything; he’s a kind of jack of all trades, master of nothing
- They were doing leg exercises and 80 kilos is pretty big for a cyclist
  - He doesn’t look like a tiny cyclist, especially in the legs
- They were doing squats on a machine, and Peter had him at 20% less weight than he used
  - He asked him how it feels, and he said, “*Oh, there’s no way in hell I could move this.*”
  - They ended up taking it down to half the weight Peter would move for him to be able to do the exercises
- Peter was thinking, “*This is a very interesting lesson in physiology because his legs are so superior to mine in generating absurdly high wattage for a long period of time, yet when I’m asking him to do this different type of task, which is clearly more recruiting of a Type 2 muscle fiber, he doesn’t have the contractile force*.”
- They ended up having a great discussion about this
  - The friend was not as strong as Peter would’ve expected, and yet so superior in this other way
- This led them to talk about the differences in their metabolism

***What’s more interesting to Peter is not that his friend is not as strong as him on a squat, it’s how much stronger he is than Peter on a bike***

*Imagine you had a muscle biopsy of both Peter and his friend, of their quads*

Peter asks, “*What is it about him that is allowing him to hold 430 watts for an hour? What is happening at the level of fuel utilization that allows him to be so different from the rest of us, regardless of how strong we are?… What is it that he is doing that is so special and that which all exceptional athletes can do?*”

- George points out that it’s sport-specific, not all exceptional athletes can do this
  - Exceptional cyclists or endurance athletes
- They discussed it earlier as the **flow of energy**, and George would guess that he was mostly **type I fibers** (these red fibers that are highly perfused, that have the mitochondrial reticulum really highly expressed)
  - He can have a high carbon flux and sustain it
  - He can generate large amounts of lactate and clear it
  - And some of the lactate probably goes into his blood and helps maintain his blood sugar level
- The fact that he can’t exert as great of a force as Peter probably means, he’s got the slow red fiber type
  - And he also hasn’t learned how to do it
  - He probably could work with him a couple of times, he might improve
    - Peter is totally confident that in 3 weeks he would be doing the same amount of weight as Peter
- The point is not so much that he wouldn’t be as strong. It’s more that if you gave Peter, but for the rest of Peter’s life, he would not be able to get to 5 watts per kilo
  - That’s the bigger point
  - Even though ostensibly Peter is stronger
- George explains, “*We’re talking about different metabolic systems or a metabolic system surplus versus a contractual entity that coexist together in the same muscle. And of course, one feeds the other. So in his case of cycling, his muscle power output is limited by the carbon flow that he can sustain*.”
  - This is exactly where Peter wanted to go with this

**How much is he limited by carbon flux input versus metabolic byproduct output?**

*In other words, why isn’t he at 6 watts per kilo, which would make him among the best cyclists on planet earth?*

- George thinks it’s a matter of degree
- If we looked at a really top cyclist, we would find that they could clear lactate more efficiently than he could, and a lot of that would have to do with his **fiber type** and the **mitochondrial mass** that they had

***In the final analysis, George thinks what differentiates the absolute best performers on the planet is going to be lactate clearance***

- Or we’re talking about carbon flux because that glycolytic flux goes to lactate and nobody knew that until George traced it
- That lactate gets oxidized

***What you have is this production versus disposal capacity, and he’s got a great disposal capacity***

**When he is on that bike for 60 minutes at 430 watts, if you had to guess, if you could sample his arterial blood, his venous blood, his type I and his type II fibers for lactate concentration, what would be your prediction?**

- George hasn’t done this with trained athletes, but he’s done it with some people who are physically fit and recreationally competent
- You can see lactate very high in the **venous effluent** of a working muscle
- George makes up some numbers: 10-2
- And at the same time, since we had **arterial sampling versus femoral venous sampling**, when the blood goes around the body, not even one complete passage, it’s down to 4 mM
- There are lactate pyruvic conversions happening in the blood in part by the red blood cells and in part by the lung parenchyma because all the blood goes through the lungs

Peter asks, “*When you sample that venous blood at 10-12 mM, would it matter if you’re doing that pre or post portal vein?*”

- Peter would think you could not do that easily, but if you were sampling it above the liver, wouldn’t it be significantly lower given that the liver is also going to be a huge sink for lactate?
- George acknowledges, “*That’s a good point.*”
- It wasn’t a mixed venous sample, but he had a femoral sample, so in part dilutions
  - This is pre-liver, so they’re getting the absolute peak level of lactate

***Peter never thought of this, all those times he’s poking his finger, he’s probably underestimating the venous concentration of lactate because it’s already had a hepatic pass***

- George explains, “*It hasn’t had a hepatic pass, it’s had a hepatic dilution and it’s gone through the lungs*.”
  - That’s potentially a double reduction in lactate

Peter asks, “*So you’re saying if you’re measuring 16 mM in your finger or earlobe, and assuming you’re generating this on a bike and someone had a femoral transducer in you, you could be more than 20 mM in the femoral blood supply as it’s exiting the muscle. Correct?*”

- It hasn’t been explored much
- George has only had a couple of papers on it
  - [By Matthew Johnson](https://pubmed.ncbi.nlm.nih.gov/22031785/) and another [by Greg Henderson](https://pubmed.ncbi.nlm.nih.gov/14990548/)
- [Matthew Johnson](https://www.linkedin.com/in/johnsonmatthewlphd/) is a research scientist at Dexcom where they make glucose analyzers
  - He was a graduate student in George’s lab
  - His dissertation was just to infuse femoral venous lactate and look on the arterial side
    - And you can see there’s a huge change in concentration, and we attributed that to the pulmonary function

***George acknowledges they probably missed the hepatic dilution effect***

**Peter wonders if you would be able to use C-14 lactate, infuse it, and then look at how much C-14 glucose you’re forming in the liver**

- That would tell you what concentration of the lactate is being extracted by the liver
- George has done it in people with C-13, which is stable non-radioactive
- C-13 glucose production in the liver would give you that fraction

*And if you did this indirect calorimetry, you could measure the C-13 CO**2* *coming out of the lungs, right?*

- It gets tricky because measuring CO2 content is really hard because most of the CO2 is carried as bicarbonate (carb-amino): it’s temperature dependent, pH dependent
  - George has done some of that, getting what’s called the RQ
  - But he hasn’t done it as Peter described
- Based on Matt’s work, when you infuse massive amounts of lactate into the femoral vein and the re-sample the femoral artery, the mass balance tells us it had to go somewhere
  - Either some of it’s going to make glucose in the liver and some of it is being expired

***In all of George’s studies, about 75-80% of lactate gets oxidized***

- But really we’re talking about carbon flow, energy flow

**Lactate can flow around the body and be removed in diverse ways**

- It can be reconverted to glucose, which then gets oxidized
- Or it can be just oxidized directly in the muscle or in other muscle
  - For instance, we’re working really hard, maybe we see this in cross-country skiers
  - Our arms are highly glycolytic, release a lot of lactate
  - Our legs are redder, more oxidative; so here we are, we have polling, generating lactate, going into the arterial circulation, perfusing the muscle, fueling the muscle, fueling the brain, fueling the liver
- Peter had always assumed that the reason he could both see in himself and other athletes the highest levels of lactate following a swim (200 or 400 yard medley swim) where you’re doing all four strokes
  - It’s a several minute effort
  - If the goal was how high can you make your lactate, that’s the exercise to do it, maybe followed by rowing
  - Peter just assumed it was because you had more muscles involved
  - He didn’t know about what George just said

***The reason whole body activity would produce so much lactate is you have disproportionate type II [fast-twitch] fibers in the upper body relative to the lower body***

> “*How did I not know that?*”‒ Peter Attia

***Peter thinks that’s super interesting and such a good point: the upper body really can get pretty fatigued relative to the lower body***

**The arms have more type II fast-twitch muscle fibers**

- We are evolved to use our arms in different ways: we use them at a lower level, and at some point maybe we want to talk about the size principle
- Our type I fibers are easily recruited through low level things: help us writing, taking notes
- But now if we have to lift something heavier, we need to recruit those type II fibers
- And working overhead, we’re using Type II fibers, and we really having clearance problems
  - So that’s really fatiguing

## The role of lactate in cancer [1:23:15]

- We alluded to cancer at the outset with the [Warburg effect](https://en.wikipedia.org/wiki/Warburg_effect_(oncology)), where cancer cells seemingly in the presence of unlimited oxygen, still seemingly choose a metabolic pathway that avoids the mitochondria
  - Although Peter is going to come back and ask about that now because we’re going to call everything into question
- Let’s just go through the **traditional thinking**: you take cancer cells in a dish, you give them unlimited access to every substrate under the sun, and what do they do?
  - They don’t want to use fatty acids, they just want to use glucose, and they just want to make lactate
  - The first hypothesis put forward there was that cancer cells must have defective mitochondria, and that’s why they can’t use anything else; that’s why they have to make so much lactate
    - That hypothesis doesn’t seem to be the case
  - Famously [Lew Cantley](https://cantleylab.dana-farber.org/people.html), [Craig Thompson,](https://www.mskcc.org/about/leadership/office-president/craig-b-thompson-biography) and maybe [Matt Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) wrote that ***the cancer cell is not optimizing for ATP and it doesn’t care that it’s being inefficient in making lactate***
    - It’s optimizing for cellular building blocks because it’s a cell that has to replicate without stopping, and that’s why it’s doing that
    - It’s going down the lactate pathway to generate more carbon, nitrogen, whatever else it needs to actually build a cell

**Tell me a little bit now about where your discoveries kind of fit into this hypothesis around why a cancer cell would follow the principle of the Warburg effect**

- George thinks the answer has been staring us in the face

> “*Cancer is a problem of glycolysis, unrestrained glycolysis.*”‒ George Brooks

- He and [Iñigo](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) published [papers](https://pubmed.ncbi.nlm.nih.gov/27993896/) together on this
- His most recent paper (now being reviewed for publication) has to do with the expression of certain glycolytic enzymes

***It looks as if in all the various stages of cancer progression, lactate stimulates those [illustrated in the figure below]***

![](https://peterattiamd.com/wp-content/uploads/2024/07/f12-georgebrooks.png)

**Figure 12. Role of lactate in all major steps in carcinogenesis**. Image credit: [*Carcinogenesis* 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5862360/)

- Iñigo is now looking at sort of the mitochondrial basis for that
- Cancer cells do have mitochondria, and they’re capable of oxidizing different substrates, including lactate, but the lactate is generated

*The high lactate production seems to stimulate a lot of things that are untoward in cancer*

- In one of the papers George and Iñigo first wrote was to look at all the adaptations in muscle, the training, and look at where cancer cells differ from the norm and then look at those points of difference between training and cancer
  - And it has to do in part with lactate clearance

***Those cancer cells do generate a lot of lactate, and the lactate is injurious in those cells***

- Peter responds, “*It would be easy to listen to that statement and say, a cancer patient should never be exercising, and that might be one implication. Although another implication might be cancer patients need to be exercising because they need a sink for all that lactate.*”

**Which of those do you think is more accurate?**

- George used to believe the first: we don’t want to generate lactate
- But the more he thought about it
  - Lactate is low because you clear it, and when you do regular exercise, you increase your clearance capacity

***In that sense, if lactate is carcinogenic, by removing it, you’ll lessen the chance for carcinogenesis***

**Peter finds these statements remarkable**: that lactate is carcinogenic

- And then it feeds into the difference between concentration and flux or flow
- In physiology, this is one of the hardest things for people to wrap their mind around.
- Another example (near and dear to Peter’s heart) is when you look at intramyocellular fatty acids

**Why is it that both the best athletes in the world and the most metabolically unhealthy people with Type 2 diabetes both have high amounts of intramyocellular fat?**

- The difference is in the person with Type 2 diabetes, it’s static, it’s stagnant
  - It sits there, and it is one of the causative drivers of insulin resistance
- Yet in the athlete, it’s a carbon flow
  - It’s moving
- It’s the difference between a stagnant pond and a flowing river

***Peter thinks we get into this trap with lactate, where we measure concentrations and we just assume high is high, low is low, high is bad, low is good, but we can’t measure flux without the complex instrumentation you use in a lab***

- George explains, “*If you do an EM and you find a mitochondrial network, you’ll see a fat globule right next to it. The potential for fat oxidation is great.*”

*In George’s work, they’ve done some* [*MRS*](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance_spectroscopy) *and* [*MRI*](https://en.wikipedia.org/wiki/Magnetic_resonance_imaging) *and looked at athletes*

- [[reviewed in 2021](https://pubmed.ncbi.nlm.nih.gov/33566386/)]

***Athletes don’t use much fat during exercise, but in the recovery period when glycogen is low, that’s the period of fat burning***

- Those fats there [adjacent to the mitochondrial network] are pre-conditioning, pre-positioning fuel supply in recovery when glycolysis switches off and people start to relax
- So you’re right about this whole idea of flux

*Also in diabetes, glucose is high. Why? Was it produced too much or not cleared?*

- That’s easier to explain with glucose than with lactate
  - People more readily understand the dynamics of appearance versus disappearance
  - The level is informative, but it’s not the whole story

## The role of lactate in the pathophysiology of various diseases, and how exercise could mitigate lactate’s carcinogenic effects and support brain health [1:29:45]

- We’ve talked about the role of lactate in athletic performance
- TBI is something people are much more aware of today, yet we still seem relatively poor in therapies
- If we had a metabolic tool to use following a **concussion**
  - Imagine if there was a concussion protocol that said, every time a person got a concussion, they were to receive intravenous lactate for X number of consecutive days, 4 hours a day at 4 mM
    - That’s a very testable hypotheses
    - Peter finds it a little frustrating to think that this type of work isn’t being funded
    - The NFL Players Association should look into this because you clearly have a high volume of individuals who are susceptible to concussions, and it would be easy to test that
- We’ve talked a little about the role of lactate in cancer
  - We’ll come back to that maybe the next time [Iñigo](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) is on the podcast
  - The big takeaway is “*Yes, lactate may be carcinogenic, but the bigger problem is not the accumulation of lactate, it’s the accumulation of lactate in the absence of an effective clearance mechanism*.”

> “*If one thing has become demonstrated over and over in our discussion today, it is that if you want to increase lactate flow and you want to increase lactate clearance, you must exercise*.”‒ Peter Attia

**Are there other disease states besides these conditions we’ve discussed where lactate plays an important role in the pathophysiology?**

- George recalls that earlier Peter suggested about brain health, dementia, Alzheimer’s: ***it’s really looking at exercise as protective***, not just card game kind of mental exercise, but physical exercise and people talking about brain blood flow and the delivery of substrates
- Some people are talking about **the role of lactate and stimulating neurogenesis** and the dentate gyrus looking at development of new brain cells, which used to be a really heretical idea
  - The original idea was that when we’re born, we have a certain number of brain cells
  - Now we know that there’s a turnover of brain cells and they’re renewed, and we know that problems can occur when the progenitor cells are damaged or injured or not stimulated in some way
- George thinks there’s a big future for investigators to be working in the field of physical activity and aging and the healthspan

**We talked very briefly about the role of lactate specifically as a precursor or a canary in the coal mine around sepsis. Do you believe that that is still a valuable tool?**

- Definitely
- To follow [Bellamo’s argument](https://confluence.cornell.edu/download/attachments/272203844/8.%202013%20OACC%20Lactate%20clearance%20as%20a%20target%20of%20therapy%20in%20sepsis.pdf?version=1&modificationDate=1406120777000&api=v2), he challenges his colleagues: ***show me where it is an anoxic area in your patient***
  - Show me where there’s hypoxia
    - Nobody can identify it

***Then the attitude becomes, well, lactate is not the cause, it’s a response ‒*** ***it’s a strain and understanding of stress and strain***

Peter asks, “*You’re telling me that lactate is the response to anoxia or hypoxia, why, when we see lactate going up in a septic patient, can you not point to the area of anoxia? And then tell me what the response is to that.*”

- Where is this lactate coming from?
  - George thinks it might be coming from the gut
  - Peter agrees that this is what he was taught: when you see these rising lactate levels in patients, it is hypoperfusion of the gut
- Peter measured lactate in a patient and it’s up to 10 mM (that’s bad news)
  - Is he supposed to take that patient to the operating room and look for ischemic bowel?
  - That’s a lot of smoke, but it doesn’t tell you where the fire is, even if you believe it’s a gut-perfusion issue
- George think part of it is because the microbes are producing [racemic](https://en.wikipedia.org/wiki/Racemic_mixture) lactate, they’re producing L-lactate and D-lactate, and most of our body runs on the L-form of lactate (it’s identified as L-lactate)

***In sepsis, he thinks there’s a lot of D-lactate going on that is formed in the lower bowel as opposed to the upper bowel***

Peter asks, “*How easy is it to distinguish between those two? It’s been so long since I’ve done organic chemistry. I don’t remember how we distinguish, I understand the difference between a D and an L, but I don’t remember how one measures it.*”

- Most of the analyzers we have measure the L-form
- The 2 forms are mirror images of each other, and the L-form is what we usually make and utilize
- If we make the D-form, it’s neurotoxic and pro-inflammatory
- George thinks, “*In large part, people can’t really see the extent of lactatemia that occurs in sepsis.*”
  - When we measure the 1 mM in the septic patient, it’s only the L-lactate concentration
  - There could be 20 mM of D-lactate that is actually causing a problem

Peter asks, “*How could we confirm or refute that?*”

- We would need a special kind of analyzer to detect it, and that’s not the common analyzer that’s around

Peter asks, “*Do you have the ability in your lab if you wanted to measure D lactate to do so?*”

- In the past, George has submitted grant applications with clinicians who wanted to do this, and they didn’t get very far

**Where do we derive the belief that D-lactate is neurotoxic and pro-inflammatory?**

- If you give it, and when people can measure it, it’s associated
- George’s hypothesis is that the bacteria are making the lactate and they’re disproportionately making the less desirable form of it, and that the L-lactate, that which you’re actually measuring is probably not causing any of the problems associated with the sepsis
  - The L-lactate is telling you that something else is going on
- You mentioned his gut ischemia, that would be very hard to demonstrate because those microbes will make lactate regardless of the presence of oxygen

## George’s current research interests involving lactate [1:37:00]

**What is the most interesting question that you are asking today that you still don’t have an answer to in your mind with respect to lactate metabolism?**

- George’s most [recent paper](https://pubmed.ncbi.nlm.nih.gov/38388706/) touches on this
- For a hundred years, everybody including George has been thinking about muscle and related tissues
  - Tissues that can use lactate, but it’s all been a muscle thing
- George did a very simple test
  - They used the usual isotopes: 13-C-labeled lactate, di-deutero glucose, and D-5 glycerol
    - So they could measure lactate, glycerol, and glucose all at the same time
  - Then we gave people an [oral glucose tolerance test](https://en.wikipedia.org/wiki/Glucose_tolerance_test)
  - The first thing that came out in the arterial blood (not venous blood) after taking glucose is lactate

***There’s enteric glycolysis that takes place, and this is the way the body participates in distributing carbohydrate energy to make lactate; and this just changes our mind completely***

Peter asks, “*Did we not know before this that when you consume glucose, lactate goes up?*”

- We know that and nobody would understand why
- It’s part of the lactate shuttle
- George presented this in their most recent studies last year at the American Diabetes Association, and there was a doc there from NIH and he said, “*Well, we feed carbohydrate and we get 2 mM lactate, so what’s the deal?*”
- That’s the way the body’s working
- In sports we would say it’s “hiding the ball”
  - Baseball, we hide the ball and football, we try to hide the ball
  - Here the body’s trying to minimize the glucose load but still deliver carbohydrate energy, and it starts with the enterocytes in the gut

***There are plenty of studies where people would incubate enterocytes under air, give glucose, and immediately you have lactate***

*When you give somebody an oral glucose tolerance test (75 g of glucose), did you give a standard dose?*

- Yeah

Peter asks, “*So plasma glucose in these subjects will easily double, right? It’ll easily go from 75 milligrams per deciliter to 150 milligrams per deciliter, correct?*”

- Yeah
- And lactate might double, maybe go from 0.6 to 1.2 mM

Peter asks, “*From a mass balance perspective… can you remind me how much carbon went in each of those 2 paths?*”

- Good point. We’re just talking about the concentration, but earlier we talked about the flux
- So it looks like the liver is really, really important in this whole thing
  - It’s really underestimated
- Peter is asking about what George thinks he wants to do next is to really explore this problem: how does the body shuttle carbohydrate energy?
- So you said the blood glucose will rise and it will go double, but it doesn’t get that high until 30 minutes after the test
- Whereas if I give the glucose the lactate is spiking in 5 minutes, reaching a peak at 15 minutes, then subsiding and now the glucose is starting to become the carbohydrate energy form
- Peter explains something he and George take for granted, “*When a person’s blood glucose goes from 80 to 150 mg/dL (that’s still a trivial amount of absolute glucose difference concentration. It’s a difference of 5 g of glucose in the entire circulation that would explain that delta), you still gave the person 75 grams. In other words, we have to account for 70 more grams of glucose.*”
  - Peter’s thinking is that most of that is in muscle
  - He does oral glucose tolerance tests on everybody because he believes it’s a great functional test of glucose disposal
    - But they’re not measuring lactate when they do this (maybe they should)
    - They’re asking the question, “*How sensitive are your muscles to insulin and how much of a reservoir do you have to dispose of glucose because we’re also measuring insulin every 30 minutes as well as glucose*.”

***Because Peter doesn’t measure lactate, he is now wondering if there’s another pathway they’re not accounting for***

**How much of the glucose are those enterocytes turning into lactate as an alternative fuel source?**

- George explains, “*That’s the first part of what happens*”
- He was lucky to have arterialized blood so they could see the spike in lactate that comes out after taking glucose, way before the glucose starts to rise
- And then from isotope technology they could see that when glucose is rising, it’s giving rise to lactate
  - That’s been seen before, and it’s called the **indirect pathway**

**To go back to an earlier point about the importance of the liver**

- This is in our paper, we reference the [work](https://pubmed.ncbi.nlm.nih.gov/32140658/) of [Stender](https://ikm.ku.dk/english/contact/specialties/clinical-biochemistry/?pure=en%2Fpersons%2Fstefan-stender(49d9a1e4-2181-4c78-bae0-c7eced79daa4)%2Fpublications.html) who gave 13-C glucose in an OGT
- The liver picks up most of it, and the liver basically sequesters about 80% of the glucose load and then doles it out over time and it starts to release this glucose after about 30 minutes
- Meanwhile, lactate has a big role
- Glucose is still in the liver and now it starts to be doled out
  - It’s being released as glucose, and that’s getting converted to lactate in the muscles (what’s called the **indirect pathway of glucose metabolism**)
- So the liver is really key

***What George would hope to be able to do in the near future is to really revisit all this dietary nutritive aspects of: okay, glucose is taken up, made into lactate; or what if we have fats there like a real meal? (not just an OGT)***

- Maybe a “meal tolerance test,” a version of this was done by somebody named Schlicker in Germany, and they did this really [incredible study](https://pubmed.ncbi.nlm.nih.gov/35360693/)
  - They did make a mistake ’cause they forgot about the liver
  - They grew grain in a high carbon-13 CO2 environment, and plants take CO2 from the air when they make sugar
  - They did an oral glucose tolerance test with 13-C, and also they harvested this grain and they did a meal test and they made porridge out of this stuff, and they looked at the appearance of lactate and glucose in the blood
  - And they saw the same thing George did: right away is a spike in lactate
    - But they forgot about the liver

**Peter’s takeaway**

- You’re saying in a [standard oral glucose tolerance test](https://en.wikipedia.org/wiki/Glucose_tolerance_test), your belief is that most of the glucose that is being disposed of is actually being disposed of initially by the liver
- And then the liver starts doling that back out
  - The muscle picks it up
- Your secondary production of lactate is by the **muscle**
- Your primary production [of lactate] is by the **enterocyte** on immediate, that’s why you get 2 peaks of lactate

***You get the1st fast peak in response to the enterocyte making lactate, and then you get a 2nd delayed slower peak when the muscles get the glucose from the liver and start making lactate***

**Implication for metformin**

- One of George’s core investigators is [Umesh Masharani](https://profiles.ucsf.edu/umesh.masharani) (a diabetologist at UCSF), and he said maybe that’s how metformin works: metformin is encouraging [enterocytes](https://en.wikipedia.org/wiki/Enterocyte) to make lactate
  - [Metformin](https://en.wikipedia.org/wiki/Metformin) is the most popularly prescribed drug for high blood sugar, and one concern is that when you give that drug, lactate rises
  - The body is making lactate, that’s why lactate is high, and that’s a good thing
- Peter adds, “*There’s a body of literature suggesting that metformin may impede exercise performance*.”
- Despite the fact that metformin has been around for a long time, it’s very difficult to know what it’s doing or how much of its net outcome (which is reducing hepatic glucose output) can be attributed to inhibiting [complex I of the mitochondria](https://en.wikipedia.org/wiki/Respiratory_complex_I)
  - And if you’re inhibiting complex I, your activating [AMP kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase#), and that should reduce hepatic glucose output
- Peter knows that anybody on metformin has higher lactate levels
- George suggests, “*Maybe it’s a way to deliver carbohydrate energy*”
- Peter had always assumed that the doubling (if not 3X increase) in resting lactate levels resulting from metformin was due to inhibition of the mitochondrial complex I
  - Maybe that was a naive assumption that if you’re inhibiting the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain), you’re going to have more lactate
    - That may be true and unrelated
- This is why George wants to give C-13 lactate or C-13 glucose and look at he appearance of 13-C lactate in the blood
  - Do the quantitation Peter described and see where does the glucose go?

**How much would it cost to do the definitive experiments on the full flux disposal of lactate?**

- George could start very well with an [R01 research grant](https://en.wikipedia.org/wiki/National_Institutes_of_Health#R01_grant:~:text=31%25.%5B62%5D-,R01%20grants,-are%20the%20most) that’s 2.5 million dollars
  - That would be a start
  - That’s just to handle the glucose
  - But the real interesting stuff would be when glucose appears as it does in a meal with other things
- Peter thinks it would be interesting to do the experiments George just described (OGTT experiment) on individuals both on and off metformin
  - It would be interesting to see the difference in lactate production in those two individuals
  - It’d be interesting to also see if there is a way to quantify this enterocyte production
- George and Dr. [Masharani](https://profiles.ucsf.edu/umesh.masharani) want to do that
  - See if they give metformin and there’s an increase in lactate in the plasma, is that due to production outstripping removal?
  - Are we actually increasing the oxidative disposal of glucose, or is the glucose high because of increased gluconeogenesis?
  - They could answer all of these things with the combination of tracers that they use

*Conventional wisdom, what Peter was taught in med school about metformin*

- Be careful of metformin because you increase the risk of lactic acidosis
- A person on metformin is at an increased risk for lactic acidosis if they get dehydrated, if they get contrast in a CT scan

Peter asks, “*When viewing that concern through the lens of what we’ve just discussed, does it make sense?*”

- Caution is always advised (do no harm)

***When we prescribe metformin, we don’t know if it increases lactate production or inhibits disposal***

- Peter refers to their earlier conversation and asks, “*Just because you increase lactate production, does that mean you’re causing acidosis?*”
- George agrees, that’s an important consideration
  - When lactate rises, what’s the change in pH?

**What happens when you take those the TBI subjects, and you clamp them at 4 mM, George said there was no change in sodium, but there was no change in pH?**

- There’s a slight alkalosis: 7.38-7.4

**The colleagues George mentioned in Switzerland who were taking people up to 8 mM, were they seeing an acidosis?**

- They did not report it

Peter asks, “*Does that mean it’s possible that high levels of lactate do not materially alter acid-base physiology?*”

- Sometimes sodium lactate is given in metabolic acidosis, but the lactate concentration is very low in that setting
- The examples George is citing are much better for asking this question
  - Clamping people at a really, really high lactate that you just don’t get to

## Questions that remain about lactate: role in gene expression, therapeutic potential, difference between endogenous and exogenous lactate, and more [1:50:45]

**It seems to Peter that if what George is saying is correct, there’s a lot we’re misinterpreting**

- For example, sepsis literature where you get that patient in the ICU who’s got high lactate
  - They also have a low pH, but those 2 things could be driven by different processes
- George adds, “*If you see a low pH, yeah, you need to do something. You see a high lactate in the absence of a change in pH, I would be very inclined not to do much*.”

**Peter’s takeaway ‒** ***understanding the full flux, the full mass balance of lactate, both exogenous and endogenous is a necessary step to fulfill our understanding of metabolism in a more complete manner***

- This is what George thinks
- Exogenous means we’re going to infuse lactate, put it in the body some way
- George learned in organic chemistry, the salt of an acid is a base, so it’s not unexpected that when you give it, pH will rise slightly, and maybe part of that also is sodium

***So yeah, what does it mean to use this exogenous stuff?***

**Lactate is distinguished from pyruvate and lactate is reduced**

- Lactate has 1 more hydrogen than pyruvate [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/07/f13-georgebrooks.png)

**Figure 13. The chemical structures of lactate and pyruvate**. Image credit: [Khan Academy](https://www.khanacademy.org/test-prep/mcat/physical-sciences-practice/x04f6bc56:foundation-5-chemical-processes/e/enzymes---passage-2)

- So that keto bond on pyruvate (the double bond oxygen) becomes hydrogen, so it’s more reduced
- Now when you start putting in this reduced equivalent into the blood, it’s going to go around the whole body and change redox in a number of tissues, all the tissues, basically where the lactate is going to go

> “*Lactate is a powerful signal, and it works in diverse ways to activate various pathways, including by changing cell redox.*”‒ George Brooks

**What does lactate do in terms of gene expression?**

- Given how potent a signaling molecule it is in both metabolism directly in vis-a-vis redox, what do we know about other forms of signaling and expression of genes?
- There’s a new field now, so we used to think genes are regulated in part [epigenetically](https://en.wikipedia.org/wiki/Epigenetics) by acetylation or methylation
  - Now we realize they’re also lactylated

***George has done some of those experiments, they haven’t published it, but lactate is a predominant metabolite and it can bind to genes and it can affect gene expression***

- You can look on PubMed and see people are starting to [look at](https://pubmed.ncbi.nlm.nih.gov/38812044/) lactylation of histones by raising lactate
- George adds, “*Dr. Attia, you’ve got us into the stratosphere here of where science needs to go. Starting with the premise exercise is healthful. How can it affect the body corpus, promote healthful living, possibly in part by lactolation of histones promoting mitochondrial biogenesis.*”
- Peter finds it interesting because we’ve talked about all of these benefits of exercise
  - We talk about how his friend clearly has more mitochondria than he does
    - He has more MCTs and he’s so much better at clearing lactate and all of these things
- But what we are missing in that is the how and the why
  - Why is he doing that?
  - What is it about his training stimulus that does that?

***George is suggesting, what if the lactate itself is signaling the gene expression that leads to the more favorable phenotype seen in the athlete?***

- George published a [paper](https://pubmed.ncbi.nlm.nih.gov/17395833/) with [Takeshi Hashimoto](http://ritsumeikan): if you take muscle cells in a dish and add lactate, you activate 500 genes
- Maybe Peter is thinking about this a bit too quickly, he would have to believe it also must involve something favorable with consumption
- If you compared Peter and his friend:
  - Peter is on the bike 3-4 hours a week
  - His friend is on the bike 15-20 hours a week
    - Clearly his friend is making more lactate than Peter
- If you could do an experiment where you exogenously deliver the same lactate to Peter as his friend is making, Peter still doesn’t think t hey’d end up the same
  - Even though they have the same input of lactate
  - Because the friend is using it during exercise while Peter is sitting around

***It’s hard for Peter to imagine that lactate by itself would be the signal; he thinks there’s something associated with the benefits of how lactate is consumed during exercise***

- This is an interest in the literature, and people are doing lactate clamps on people and looking for increases in mitochondrial protein expression
- They’re seeing sometimes yes, sometimes no
- It has to do with the endogenous versus the exogenous because you get completely different signals
- So it’s the endogenous lactate when it’s high seems to stimulate mitochondrial biogenesis rather than just infusing it
- A lot of these pathways are redox sensitive

**Peter wants to make sure the listener understands this very important point**

- “Redox sensitive” is fancy speak for saying it depends on the amount of protons or pH balance of what’s going on
- And if you just give somebody lactate without actually creating the slight alteration in pH that is naturally going to be accompanied by exercise ‒ you don’t reap the benefits

***Whereas if the lactate is produced in concert with exercise, you get the lactate, but you also get the pH perturbation; and that is the key to unlock its potential***

- George explains that this is the work of other scientists, and the mixed results they’re getting depends on whether it’s endogenously or endogenously produced lactate

**If Peter were czar [and could dole out research funding]**

- He’d be throwing much more than just a paltry little [R01](https://en.wikipedia.org/wiki/National_Institutes_of_Health#Research:~:text=31%25.%5B62%5D-,R01%20grants,-are%20the%20most) at this, because it’s such an interesting question

*Going back to the TBI example, he would want to study*

- He would want to take a whole bunch of people with traumatic brain injuries or concussions
  - You’ve got a placebo group
  - You’ve got a group where you just infused intranasal insulin and glucose
  - Another group where you just infuse lactate
- You take them to equal concentration of lactate and glucose (5 mM of both)
- Then you have another group where you do that, but they exercise 2 hours a day, steady state, zone 2, just enough to get their own endogenous lactate up to about 2 mM and then get that clearance
- You might argue that it’s that exercising group that’s also being given exogenous lactate might actually have the best outcomes because they’re getting the redox potential as well as the lactate
- George has thought about this, and it’s probably not in the cards for a TBI patient to do a ny exercise
- But what about functional electrical stimulation of a comatose patient?
- Peter doesn’t mean strenuous exercise
- He means somebody who’s had a concussion but is still functional
  - They’re suffering the negative consequences of it

**George explains that endogenously mild electrical stimulation will raise lactate in someone who’s comatose with a significant CNS injury**

- It all comes back to Meyerhof, back to frogs with electrodes
- Now we are understanding that it’s just not a muscle thing ‒ it’s the whole thing
  - And there’s glycolysis going on simultaneously

**Back to our story about the muscle fibers: a lactate producer, a lactate consumer exchanging chemical energy**

- There are studies on healthy people, when we’re exercising our muscles hard enough, they are going to release lactate, but it’s now the favorite fuel for the heart
- [Studies](https://pubmed.ncbi.nlm.nih.gov/29127193/) that Hashimoto did on executive function
  - He did these with [Neil Secher](https://research.ku.dk/search/result/?pure=en%2Fpersons%2F135771) in Copenhagen
  - Give people standard cognitive tests
  - Then they exercise and build up their lactate ‒ they score better
    - When they recover, their lactate comes down, they go back to their basal scores
  - Brain fuel

***So think about the PE class: getting kids out to run around is not blowing off emotional energy; they’re going to fuel their brain for the next hour or so***

**Peter thinks this is so interesting because you just have to believe that there are too many factors in there to identify the amount of contribution of each**

- For example, we all know that when you exercise, [BDNF](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor) goes up and [Klotho](https://en.wikipedia.org/wiki/Klotho_(biology)) goes up, and all of those things have pro-cognitive benefits as well
- So it’s probably difficult to just assign all of the benefit of, there’s a clear obvious benefit between exercise and cognition
- What it sounds like is that there are many biochemical pathways that feed that, and lactate may indeed be a preferred energy source
- George mentions, “*There’s one study where lactate was infused and BDNF went up.*”
  - [mentioned in this [review](https://physoc.onlinelibrary.wiley.com/doi/10.1113/JP280955)]
- Peter wonders if anyone has ever looked at lactate infusion and klotho concentrations
- Peter is glad he finally had a chance to sit down and go through some of this really incredible work

And he hopes somebody in a position of funding is listening to this and realizes that for a relatively small sum of money relative to the type of money that’s thrown at a lot of biomedical research, we could really **answer some fundamental questions** about the fate of lactate and the interplay with glucose, especially the role of the liver and the enterocytes

§

## Selected Links / Related Material

**Episodes of** ***The Drive*** **with Iñigo San-Millán**: [1:15]

- [#201 – Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)](https://peterattiamd.com/inigosanmillan2/) (March 28, 2022)
- [#85 – Iñigo San Millán, Ph.D.: Zone 2 Training and Metabolic Health](https://peterattiamd.com/inigosanmillan/) (December 23, 2019)

**Peter’s book**: [Outlive](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZc3hWLITcnTc7B2P76ivh285q3LcpZmR8KEgNoEJuv1Zqxeouda-RMCf4k8e11ye-8-8baLYdnwPtSSwii3VQUlQyEAgDd_kSLgVMXkuSNhXa0XZnOvx4niMVZvo7j50qwJLAN-LzVptqJC67rNqR2vj7XvYEnkMkum6F5fYkqOIQareCM3YQ8ABta6croTyXn-WqR2sc6knnGp9Fs3nSWE.zzsFKRXtqKaubUYCWM8sabGF0asdx5aQgMO-2WAD_CU&qid=1717002766&sr=8-1) by Peter Attia with Bill Gifford (2023) | [1:15]

**Mitochondrial lactate oxidation complex**: [Evidence for the mitochondrial lactate oxidation complex in rat neurons: demonstration of an essential component of brain lactate shuttles](https://pubmed.ncbi.nlm.nih.gov/18698340/) | *PLOS ONE* (T Hashimoto et al 2008) | [28:45]

**Review of lactate metabolism and lactate shuttle**: [31:15]

- [The blood lactate/pyruvate equilibrium affair](https://pubmed.ncbi.nlm.nih.gov/34719944/) | *American Journal of Physiology Endocrinology and Metabolism* (G Brooks et al 2021)
- [The Science and Translation of Lactate Shuttle Theory](https://pubmed.ncbi.nlm.nih.gov/29617642/) | *Cell Metabolism* (G Brooks 2018)

**Lactate inhibits carnitine-palmitate transporters that allow fatty acids into the mitochondria**: [Chronic Lactate Exposure Decreases Mitochondrial Function by Inhibition of Fatty Acid Uptake and Cardiolipin Alterations in Neonatal Rat Cardiomyocytes](https://pubmed.ncbi.nlm.nih.gov/35308271/) | *Frontiers in Nutrition* (I San-Millan et al 2022) | [32:15]

**Lactate clamp technique**: [37:00]

- [Hematological and acid-base changes in men during prolonged exercise with and without sodium-lactate infusion](https://pubmed.ncbi.nlm.nih.gov/15475600/) | *Journal of Applied Physiology* (B Miller et al 2005)
- [Metabolic and cardiorespiratory responses to “the lactate clamp”](https://pubmed.ncbi.nlm.nih.gov/12376315/) | *American Journal of Physiology* (B Miller et al 2002)

**Infusion of lactate suppresses glucose uptake**: [Lactate and glucose interactions during rest and exercise in men: effect of exogenous lactate infusion](https://pubmed.ncbi.nlm.nih.gov/12411539/)  | *Journal of Physiology* (B Miller et al 2002) | 37:15]

**George Cahill’s fasting studies**: [Brain Metabolism during Fasting](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC292907/) | *The Journal of Clinical Investigation* (O Owen et al 1967) | [40:15]

**The uninjured brain has equal preference for glucose and lactate**: [Lactate: Brain Fuel in Human Traumatic Brain Injury: A Comparison with Normal Healthy Control Subjects](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4530406/) | *Journal of Neurotrauma* (T Glenn et al 2015) | [43:00]

**Lactate suppresses appetite**: [The emerging role of lactate as a mediator of exercise-induced appetite suppression](https://pubmed.ncbi.nlm.nih.gov/32893673/) | *American Journal of Physiology, Endocrinology and Metabolism* (S McCarthy, H Islam, T Hazell 2020) | [50:45]

**Double mitochondrial mass through training**: [56:00]

- [Biochemical adaptations in muscle. Effects of exercise on mitochondrial oxygen uptake and respiratory enzyme activity in skeletal muscle](https://pubmed.ncbi.nlm.nih.gov/4290225/) | *The Journal of Biological Chemistry* (J Holloszy 1967)
- [Age-associated declines in mitochondrial biogenesis and protein quality control factors are minimized by exercise training](https://pubmed.ncbi.nlm.nih.gov/22573103/) | *American Journal of Physiology* (E Koltai et al 2012)

**The mitochondrial reticulum and formation of a network called the ‘cellular energy power grid’**: [57:15]

- [Mitochondrial reticulum for cellular energy distribution in muscle](https://pubmed.ncbi.nlm.nih.gov/26223627/) | *Nature* (B Glancy et al 2015)
- [Mitochondrial reticulum in limb skeletal muscle](https://pubmed.ncbi.nlm.nih.gov/3752235/) | *The American Journal of Physiology* (S Kirkwood, E Munn, G Brooks 1986)

**Exercise increases expression of MCTs to facilitate lactate transport**: [Effects of acute and chronic exercise on sarcolemmal MCT1 and MCT4 contents in human skeletal muscles: current status](https://pubmed.ncbi.nlm.nih.gov/22012699/) | *American Journal of Physiology* (C Thomas et al 2012) | [1:01:15]

**Episode of** ***The Drive*** **that discuss type I and type II muscle fibers**: [#250 ‒ Training principles for longevity | Andy Galpin, Ph.D. (PART II)](https://peterattiamd.com/andygalpin2/) (April 10, 2023) | [1:02:45]

**George’s textbook on exercise physiology**: [Exercise Physiology: Human Bioenergetics and Its Applications](https://www.amazon.com/Exercise-Physiology-Human-Bioenergetics-Applications-dp-0072556420/dp/0072556420/ref=dp_ob_title_bk) by George Brooks, Thomas Fahey , Kenneth Baldwin (4th edition, 2004) | [1:06:30]

**Reduction in lactate as blood goes through the lungs and liver**: [1:18:30]

- [Transpulmonary lactate shuttle](https://pubmed.ncbi.nlm.nih.gov/22031785/) | *American Journal of Physiology* (M Johnson et al 2012)
- [Pyruvate shuttling during rest and exercise before and after endurance training in men](https://pubmed.ncbi.nlm.nih.gov/14990548/) | *Journal of Applied Physiology* (G Henderson 2004)

**Lactate and unrestrained glycolysis in cancer cells**: [1:25:15]

- [Is Lactate an Oncometabolite? Evidence Supporting a Role for Lactate in the Regulation of Transcriptional Activity of Cancer-Related Genes in MCF7 Breast Cancer Cells](https://pubmed.ncbi.nlm.nih.gov/32010625/) | *Frontiers in Oncology* (I San-Millan et al 2020)
- [Reexamining cancer metabolism: lactate production for carcinogenesis could be the purpose and explanation of the Warburg Effect](https://pubmed.ncbi.nlm.nih.gov/27993896/) | *Carcinogenesis* (I San-Millan, G Brooks 2017)

**Lactate shuttle after oral glucose tolerance test**: [Enteric and systemic postprandial lactate shuttle phases and dietary carbohydrate carbon flow in humans](https://pubmed.ncbi.nlm.nih.gov/38388706/) | *Nature Metabolism* (R Leija et al 2024) | [1:25:15]

**Elevated lactate in critically ill patients does not signal a lack of oxygen**: [1:32:30]

- [The importance of applying physiological principles of hyperlactataemia to the study of human disease](https://pubmed.ncbi.nlm.nih.gov/33527414/) | *Journal of Physiology* (E See, R Bellomo 2021)
- [Lactate clearance as a target of therapy in sepsis: a flawed paradigm](https://confluence.cornell.edu/download/attachments/272203844/8.%202013%20OACC%20Lactate%20clearance%20as%20a%20target%20of%20therapy%20in%20sepsis.pdf?version=1&modificationDate=1406120777000&api=v2) | *OA Critical Care* (P Marik R Bellomo 2013)

**George’s recent paper on enteric production of lactate**: [Enteric and systemic postprandial lactate shuttle phases and dietary carbohydrate carbon flow in humans](https://pubmed.ncbi.nlm.nih.gov/38388706/) | *Nature Metabolism* (R Leija et al) | [1:37:15]

**Stender’s work with 13-C porridge and OGT**: [Systemic Lactate Acts as a Metabolic Buffer in Humans and Prevents Nutrient Overflow in the Postprandial Phase](https://pubmed.ncbi.nlm.nih.gov/35360693/) | *Frontiers in Nutrition*(L Schlicker et al 2022) | [1:42:15]

**Schlicker’s study of metabolic flux in response to 2 carbohydrates: C-13 grain porridge and C-13 glucose OGTT**: [Systemic Lactate Acts as a Metabolic Buffer in Humans and Prevents Nutrient Overflow in the Postprandial Phase](https://pubmed.ncbi.nlm.nih.gov/35360693/) | *Frontiers in Nutrition* (L Schlicker et al 2022)  | [1:43:45]

**Review of histone lactylation**: [Lactylation: the novel histone modification influence on gene expression, protein function, and disease](https://pubmed.ncbi.nlm.nih.gov/38812044/) | *Clinical Epigenetics* (Y Hu et al 2024) | [1:53:45]

**Lactate upregulates expression of 500 genes in muscle cells**: [Lactate sensitive transcription factor network in L6 cells: activation of MCT1 and mitochondrial biogenesis](https://pubmed.ncbi.nlm.nih.gov/17395833/) | *FASEB* (Hashimoto et al 2007) | [1:55:00]

**The role of lactate in executive function**: [Maintained exercise-enhanced brain executive function related to cerebral lactate metabolism in men](https://pubmed.ncbi.nlm.nih.gov/29127193/) | *FASEB* (T Hashimoto et al 2018) | [2:00:15]

§

## People Mentioned

- [Iñigo San-Millán](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) (Assistant Professor of Medicine at the University of Colorado – Colorado Springs) [1:15, 1:25:15]
- [Otto Meyerhof](https://en.wikipedia.org/wiki/Otto_Fritz_Meyerhof) (1884-1951, German physician and biochemist, won the 1922 Nobel Prize in Physiology and Medicine) [4:45, 13:45]
- [Otto Heinrich Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) (1883-1970, German physiologist who won the 1931 Nobel prize in Physiology and Medicine) [14:00, 1:23:30]
- [Carl Cori](https://en.wikipedia.org/wiki/Carl_Ferdinand_Cori) (1896-1894, Czech-American biochemist and pharmacologist who discovered the Cori cycle with his wife, for which the 1947 Nobel Prize in Physiology and Medicine was awarded) [29:15]
- [Gerty Cori](https://en.wikipedia.org/wiki/Gerty_Cori) 1896-1957, Austrian-American biochemist who discovered the Cori cycle with her husband and won the 1947 Nobel Prize) [29:15]
- [Pierre Magistretti](https://people.epfl.ch/pierre.magistretti) (Professeur honoraire and Director of the Brain Mind Institute at EPFL in Switzerland, expert in brain energy metabolism) [38:45]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (1927-2012, was a scientist and professor at Harvard who advanced diabetes research, expert in fasting and ketones) [40:15]
- [Thomas (Tom) Budinger](https://bioeng.berkeley.edu/faculty/thomas_budinger) (Professor Emeritus of Bioengineering at UC Berkeley and recipient of the [2018 IEEE Medal for Innovations in Healthcare Technology](https://biosciences.lbl.gov/2017/11/28/budinger-receive-2018-ieee-medal-innovations-healthcare-technology/) for pioneering contributions to tomographic radiotracer imaging) [45:15]
- [John Holloszy](https://journals.physiology.org/doi/full/10.1152/japplphysiol.00669.2018) (1933-2018, former Professor and Director of at Division of Applied Physiology and later the Director of the Division of Geriatrics and Gerontology at Washington University School of Medicine in St. Louis) [56:15]
- [Kelvin Davies](https://gero.usc.edu/faculty/davies/) (Distinguished Professor Emeritus of Gerontology, Molecular & Computational Biology, and Biochemistry & Molecular Medicine at the University of Southern California, expert in mitochondria and mechanisms of aging) [56:30]
- [Christine Kim Garcia](https://www.vagelos.columbia.edu/profile/christine-k-garcia-md#credentials-amp-experience) (Chief of Pulmonary, Allergy, and Critical Care Medicine and Professor of Medicine at ColumbiaUniversity) [59:15]
- [Kenneth (Ken) Baldwin](https://medschool.uci.edu/news/memoriam-kenneth-m-baldwin-phd) (Professor Emeritus of Physiology & Biophysics at UC Irvine and expert in exercise-induced muscle adaptations) [1:04:30]
- [Thomas (Tom) Fahey](https://www.researchgate.net/profile/Thomas-Fahey-5) (former Professor of kinesiology at Cal State Chico [1:07:30]
- [Rinaldo Bellomo](https://research.monash.edu/en/persons/rinaldo-bellomo) (Professor of Acute & Critical Care at Monash University, Australia
- [Matthew Johnson](https://www.linkedin.com/in/johnsonmatthewlphd/) (research scientist at Dexcom where they make glucose analyzers) [1:18:30]
- [Lew Cantley](https://cantleylab.dana-farber.org/people.html) (Professor of Cancer Biology at the Dana-Farber Cancer Institute) [1:20:00]
- [Craig Thompson](https://www.mskcc.org/about/leadership/office-president/craig-b-thompson-biography) (cancer biologist, oncologist, and past president of Memorial Sloan Kettering) [1:20:00]
- [Matthew Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) (Director, Koch Institute for Integrative Cancer Research) [1:24:30]
- [Stefan Stender](https://ikm.ku.dk/english/contact/specialties/clinical-biochemistry/?pure=en%2Fpersons%2Fstefan-stender(49d9a1e4-2181-4c78-bae0-c7eced79daa4)%2Fpublications.html) (Clinical Associate Professor at the University of Copenhagen) [1:42:30]
- [Umesh Masharani](https://profiles.ucsf.edu/umesh.masharani) (Professor of Endocrinology and Metabolism) [1:44:00]
- [Takeshi Hashimoto](https://research-db.ritsumei.ac.jp/rithp/k03/resid/S000756?lang=en) (Professor of Sport and Health Science at Ritsumeikan University, Japan) [1:54:00]
- [Neils Secher](https://research.ku.dk/search/result/?pure=en%2Fpersons%2F135771) (Professor Emeritus of Clinical Medicine at the University of Copenhagen) [2:00:15]

§

![](https://peterattiamd.com/wp-content/uploads/2024/07/bio-georgebrooks.jpeg)

##### George A. Brooks, Ph.D.

George Brooks earned his PhD at the University of Michigan where he studied mitochondrial energetics under John Faulkner. He then completed a postdoctoral fellowship in muscle biology at the University of Wisconsin. Dr. Brooks is a Professor of Integrative Biology at UC Berkeley and the director of the Exercise Physiology Lab.

Dr. Brook’s research focuses on metabolic adjustments in response to exercise. He was the first scientist to propose the “lactate shuttle” theory in the 1980s, positing that lactate was actually a fuel source, rather than an unfortunate byproduct of exercise. He works in both animals and humans to elucidate the pathways and controls of lactic acid formation and removal before, during and after exercise. In addition to basic research, he collaborates with others to identify the causes and develop treatment modalities for conditions in lactic acidosis in persons suffering from injuries and infections such as traumatic brain injury, heart failure, inflammatory conditions, and HIV infection. He also conducts research on the “crossover concept” to understand how the body selects combinations of fatty acids, carbohydrates and amino acids for use during sustained exercise and other conditions. This work investigates the effects of exercise training, gender, age, and high altitude on substrate utilization. The results have direct implications for the prevention and management of metabolic inflexibility that contributes to obesity and type 2 diabetes in youth and aging.

Dr. Brooks has published more than 400 manuscripts throughout his decades-long career in exercise physiology research and has authored two textbooks, including [*Exercise Physiology: Human Bioenergetics and Its Applications*](https://www.amazon.com/Exercise-Physiology-Human-Bioenergetics-Applications-dp-0072556420/dp/0072556420/ref=dp_ob_title_bk). [[Berkeley Research](https://vcresearch.berkeley.edu/faculty/george-brooks)]