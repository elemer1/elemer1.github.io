# #39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer

**Source:** [https://peterattiamd.com/tedschaeffer/](https://peterattiamd.com/tedschaeffer/)

---

In this episode, Ted Schaeffer, Professor and Chair of the Department of Urology (youngest chairman in the country) at Northwestern, presents the roadmap for the best way to screen for, and treat, prostate cancer. We also get into the “mass screening” controversy and all the risks involved with treatment. In addition, we discuss our evolving understanding of cancer and the most exciting areas of research to come.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tedschaeffer/the_Drive_public.png)

Play

#39 - Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer

#39 - Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer

1x15s30s

0:002:31:55

## We discuss:

- Ted’s unique path to get his PhD [5:15];
- The exciting transition in science during Ted’s PhD in the 1990s [15:30];
- Ted’s advice to MD-PhD students, and why he choose urology and Johns Hopkins [23:45];
- History of prostate surgery, and Pat Walsh’s legendary work in prostate cancer [36:15];
- Prostate surgery and the risks involved with treatment [53:00];
- Screening for prostate cancer [58:00];
- The “mass screening” controversy [1:12:45];
- Biopsies and MRI: important things to know [1:25:30];
- Why urology is such a great field of medicine, and why Peter wants a goat [1:34:45];
- Ted’s work with Ben Stiller [1:39:00];
- Gleason grading system [1:43:45];
- Testosterone, DHT and the prostate cancer controversy [1:53:15];
- The metabolism of the prostate [2:03:00];
- The most exciting areas of research in prostate cancer [2:08:00];
- Benign issues involving the prostate: pelvic pain, infections and treatments [2:11:15];
- Video of Ted’s surgeries, the latest technology, and males contraceptive options [2:18:00];
- Watches and cars [2:23:30]; and
- More.

## Show Notes

## Ted’s unique path to get his PhD [5:15]

> “People ask me about my life and how I got to where I am . . . and one of the things I talk to my trainees about is, you never walk by an open door without looking inside.”

Unique path to get his PhD

- After 3 years of med school at Johns Hopkins, he left to study science for a year at the NIH (an uncommon decision)
- Received a scholarship from the [Howard Hughes Medical Institute](https://en.wikipedia.org/wiki/Howard_Hughes_Medical_Institute)
- Got introduced to [Pam Schwartzberg](https://www.niaid.nih.gov/research/pamela-l-schwartzberg-md-phd), a postdoc in the [Varmus Lab](https://www.varmuslab.org/)
- Varmus Lab: The lab of [Harold Varmus](https://en.wikipedia.org/wiki/Harold_E._Varmus) (a [Nobel Prize winner](https://www.nobelprize.org/prizes/medicine/1989/summary/) for his elucidation of the relationship between viruses and oncogenes)
- Pam mentored Ted during his time in the lab
- After his time at the NIH, Ted of granted his PhD from the University of Chicago for the great work he did even though it was not a formal PhD program

Attacking your weaknesses

⇒ Peter says: You said something a second ago that I love. Part of the reason you were attracted to immunology is you felt it was a weakness, and having spoken with a number of very good scientists, I find that to be a very common thread (Peter saw this trait in his mentor, [Steven Rosenberg](https://en.wikipedia.org/wiki/Steven_Rosenberg))

**The exciting transition in science during Ted’s PhD in the 1990s**

==> No longer single gene, single change

- At the time (1990s), people were still focusing on “single gene, single change” and that “you have this mutation, you get this cancer, this mutation, you have this phenotype”
- In other words, people were thinking “digital” rather than “analog”
  - Digital meaning, it’s either on or off
  - Analog meaning, there is an infinite number of iterations in between, like a volume knob on your rado
- But there was a transition in thinking, especially in immunology, that it was much more complex that than
- The tools to explore and test that on multigene levels were coming online in science at that time

Ted’s PhD work focused on [tyrosine kinase](https://en.wikipedia.org/wiki/Tyrosine_kinase): “So it turns out that the tyrosine kinases that I worked on my PhD are really involved in fine tuning the [T-cell receptor](https://en.wikipedia.org/wiki/T-cell_receptor) signaling . . . they really fine tuned the signal. It’s not off or on.”

Tyrosine kinase: what it is and why it’s relevant

- We all have unique DNA in every cell in our body
- But within each person, there is variability with what the cells do with the DNA code
- And exposure to environment, for example, can result in epigenetic change
- This change results in a protein

Proteins

- They are not inert, they can change
- Pieces of the proteins can be modified through kinases
- Tyrosine kinase is just one type of kinase
- **Kinases have become a very attractive target for drugs**

Drugs target kinases

*⇒ The idea in cancer biology is to find alterations to find mutations to find changes that you can “target” to do precision oncology, precision medicine. And so these are one of the ways that we’re beginning to think about advancing the medicine in that special way.*

[Gleevec](https://en.wikipedia.org/wiki/Imatinib)

- Gleevec, for example, targets a specifically altered/fused gene of tyrosine kinase
- It is able to cure [chronic myeloid cancer](https://www.leukaemia.org.au/disease-information/leukaemias/chronic-myeloid-leukaemia/) (CML) ⇒ this is an exception, however, in that it targets a single gene and has a curative effect

*“But for most cancer a single agent like Gleevec isn’t going to work because the [cancer] cells change and alter, but doing double or triple targeting will be an effective long term approach for those. Just like we’ve learned from HIV management.”*

## Ted’s advice to MD-PhD students, and why he choose urology and Johns Hopkins [23:45]

What advice would you give them to select a good lab?

- Find the right people to work with: “when you have an amazing mentor, it’s like everything works out”
- You must also have internal motivation and drive
- Do your best to find something you’re passionate about
- Have a clear understanding of this idea of *translation*: You can do science for science sake, but to me to make really big impacts, you have to be able to translate that to the human condition
- **Get some clinical time in BEFORE doing your PhD ⇒ you will know really key nuances that were important for understanding the right questions to ask**
- “This might be the nugget of the podcast” says Peter

**Why did you choose Urology? Why Hopkins?**

- [Father was a urologist](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=13362)
- Ted’s grandfather got sick and died of prostate cancer
- Also wanted to work with his hands
- Decided he wanted to be a prostate cancer scientist and surgeon

Johns Hopkins

- Best urology program in the US
- Chairman was [Pat Walsh](https://urology.jhu.edu/patrickwalsh/), the godfather of urology and prostate cancer surgery
- The people at Hopkins are amazing
- “I’ll never forget just the pursuit of excellence. That was really the epitome of Hopkins.”
- Pat Walsh pointed out that Johns Hopkins was a “negative selector”: “People come here because they want to pursue excellence. They don’t come here because there’s a good nightlife. They don’t come here because of X, Y, or Z. They come here for that single reason.”

## History of prostate surgery, and Pat Walsh’s legendary work in prostate cancer [36:15]

> “I can’t think of someone in the last 30 years that has so fundamentally changed the course of one operation, its impact on one disease, as Pat.”

Quote from Pat Walsh: *“You can’t make important discoveries unless you work on important problems.”*

Before Walsh, if someone had prostate cancer, what were the treatment options?

- Very few had surgery
- Life-threatening due to blood loss
- Many ended of with urinary leakage and losing sexual function

Why is blood loss from prostate surgery so deadly?

- Large number of veins (not arteries)
- Prone to tear, thin as paper
- It’s hard to access the prostate, it’s buried within the unique anatomy of the pelvis

In 1904, [Hugh Hampton Young](https://urology.jhu.edu/about/young.php), the first urologist at Johns Hopkins, performed the first radical prostatectomy using a perineal approach (going through the space between the scrotum and anus) . . . this approach is safer from a blood loss perspective but it is not as good at removing all the cancer

Tangent into some of Peter and Ted’s experiences as interns at Hopkins

- “Sunday school”
- [Warren shunt](https://en.wikipedia.org/wiki/Distal_splenorenal_shunt_procedure) (operation that Peter presented on at Sunday school)
- [NG tube insertion](https://en.wikipedia.org/wiki/Nasogastric_intubation): “The rest of my residency, I was throwing NG tubes in. If you looked at me, you got an NG tube and it didn’t hurt.”

Pat Walsh’s approach to prostate surgery

- For blood loss… He understood where the veins were and he controlled them by suturing them before they started bleeding.
- By doing that, you could actually see everything. (like going from operating in the dark to in the daylight)
- For retaining potency: this was not so obvious, but he figured that part out by working with some anatomists and really just studying and talking to his patients and listening to what they had to say
- He would record and rewatch all his cases to learn from his mistakes

**Dr. Pat Walsh’s video of his operations**:

**See also Pat Walsh performs a** **prostatectomy****in the 1970s**: [The Art of Retropubic Prostatectomy – Joseph J. Kaufman, MD and Patrick C. Walsh, MD](https://www.youtube.com/watch?v=EAif5oahUnw)

## Prostate surgery and the risks involved with treatment [53:00]

Odds of regaining sexual function and having no problems with urinary leakage?

- Not 100%, and it’s because the nerves are not myelinated
- Nearly all other nerves in the body have [myelination](https://en.wikipedia.org/wiki/Myelin)

Urinary leakage

- About 4% of cases, on average, have urinary leakage (more common in women and older men)
- Only 2% of Ted’s patients report urinary leakage

Sexual function

- For a 50 year old man, over 90% will regain function (if Ted’s patient)
- But ED is an age-related dysfunction, so the older the patient the higher the chance of not fully regaining function

[The neurovascular bundle of Walsh](https://medical-dictionary.thefreedictionary.com/neurovascular+bundle+of+Walsh)

- The bundle of nerves all around the prostate make it hard to remove without taking some of the nerves as well
- And the bigger the tumor the more nerves much be removed

## Screening for prostate cancer [58:00]

**What is** [**prostate-specific antigen**](https://en.wikipedia.org/wiki/Prostate-specific_antigen) **(PSA)?**

- The biggest controversy in prostate cancer
- PSA is a protein made by the prostate
- It’s function is to liquefy semen

Prostate is like a sewer system

- You have the main sewer leaving the city, that’s the urethra
- But not just urine, this channel also delivers semen out the tip of the penis
- Off this main sewer are slightly smaller sewers that go to different neighborhoods
- Within the neighborhood, there’s a sewer that comes out of the individual house
- The individual houses in this analogy are prostate [epithelial cells](https://en.wikipedia.org/wiki/Epithelium)
- Epithelial cells make the components of the semen
- Semen is used to give nutrients to the sperm while it’s trying to fertilize an egg
- PSA is a protein that breaks down the semen and liquefies it, which is an important process of in making fertilization possible

*How do we use the PSA number as a tool to screen for prostate cancer?* ⇒ **we check the values of the PSA in the blood**

- This was discovered in the 1980s
- Some PSA gets into the bloodstream (some is normal for everyone)
- The bigger the prostate, the more PSA leaks into the blood
- The older the person, generally the more PSA in blood

So what can make the PSA rise *besides* just getting older and having a larger prostate?

- An infection
- Cancer in the prostate

So what is a normal PSA?

- Age-adjusted
- A 40 year old is around .5 to .6 nanograms per ml
- A 50 year old, the normal is 1.0
- **\*No PSA number, no matter how low, guarantees that you don’t have cancer**
- But for a younger person, higher than 2.5 is cause for more workup
- An older person, higher than 4.0 is concerning
- **But not yet time for a biopsy**

**Percent free PSA:**

This was the first way that urologists began to look at what’s the chance that a PSA of 4.0 is coming from a cancer versus a PSA of 4.0 coming from just benign overgrowth

Example,

- Two guys have a PSA of 4.0
- Person A has a free PSA of 1.0, so he’s 25 percent free PSA
- Person B has a free PSA of 3.0, which is 75 percent free
- There’s less bound PSA in the lower percent free, and that’s more often associated with prostate cancer
- A high percent free PSA is associated with a big prostate and less of a chance of prostate cancer
- A low percent free PSA is associated with a higher likelihood that that PSA’s produced from a gland with prostate cancer in it
- So Person A is more likely to have cancer

**PSA density:**

- PSA number divided by volume of prostate: So 4.0 PSA/40 gram prostate= density of .1
- **PSA density more than .1 or .15  raises a red flag**
- So an 80 gram prostate (which is big) with a PSA of 4.0 is a density of .05, on avg. that person does not have cancer

[**Four-kallikrein test (4k score)**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2891337/) and the [**Prostate Health Index (PHI)**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3943368/)

- Two new tests that leverage off the idea that prostate cancer cells make PSA differently than benign prostate cells
- Both tests are equally accurate and interchangeable
- Peter calls the 4k test a “game changer” at his practice

4k score

- 4k test has figured out a way to give a *binary* answer
- Below 7.5% means you have a 1.6 percent chance to die in 20 years
- Above 7.5% means you have a continuous variable chance the higher the percentage

**The 7.5% cut off on the 4k test based on the database from Vickers and Hans Lilja**: [Improving the Specificity of Screening for Lethal Prostate Cancer Using Prostate-specific Antigen and a Panel of Kallikrein Markers: A Nested Case–Control Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4496315/) (Stattin et al., 2016)

![](https://peterattiamd.com/wp-content/uploads/2019/02/4k-score-1024x603.png)

**Figure 1. 4k score 7.5% cutoff.** Image credit: [4kscore.com](https://4kscore.com/wp-content/uploads/2016/04/Test-Interpretations.pdf)

## The “mass screening” controversy [1:12:45]

- In the 1940s, 40% of men coming in with prostate cancer had metastatic at presentation
- Epidemic of deaths of prostate cancer
- [Tom Stamey](https://med.stanford.edu/news/all-news/2015/09/thomas-stamey-expert-on-prostate-cancer-and-psa-test-dies-at-87.html) and [Bill Catalona](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=18380) figured out we could look at PSA numbers to catch cancer earlier
- 1990 FDA approved the test and set forth arbitrary cutoffs

The idea of “mass screening” controversy began

- The argument against mass screening is that it would lead to people being treated who didn’t need it, and the treatment process is not safe or cheap and can be hard on people
- Skeptics said it was a way for urologists to make money
- “No, it wasn’t that. It was because at the time the test was developed, it was the first biomarker for cancer. Pick up a cancer early, if you pick it up, treat it and cure that patient.”
- Over the next decade, this test reduced deaths from cancer, as well as reducing the incidence of metastatic cancer at presentation
- Playing devil’s advocate, Peter says, well that’s just [lead time bias](https://en.wikipedia.org/wiki/Lead_time_bias)
- Fortunately, the skeptics are losing ground on the argument against prostate screening, even “anti-screeners” like [Peter Albertsen](https://facultydirectory.uchc.edu/profile?profileId=Albertsen-Peter) are [coming around](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4350812/)

Not all prostate cancer is lethal

- Initially we developed a biomarker to pick up all prostate cancers ⇒ the PSA blood test
- We picked them up, we treated them, we reduced deaths **but we also over-treated people**
- People who had a cancer that would never have been lethal in their lifetime, so the screening tools got better (4k, PHI, etc.)

The over-simplified screening protocol of today

- PSA test first (including free PSA, PSA density)
- **However, it’s important to not in 10-15% of men with a “normal” PSA can still have a lethal type of cancer**
- If abnormal, then move to 4k/PHI
- If that’s abnormal, get an MRI
- If abnormal, get a biopsy

**Vicker’s analysis of percentage of people with lethal-type cancers that had a “normal” PSA reading**: [Evaluation of Prediagnostic Prostate-Specific Antigen Dynamics as Predictors of Death from Prostate Cancer in Patients Treated Conservatively](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2988082/) (O’Brien et al., 2012)

The government loosens its guidelines on screening

- Around 2008, the guidelines set forth lowered the amount of doctors who consistently screened for prostate cancer
- This change increased the incidence of cancer and metastatic cancer at first presentation
- **Ted wrote about this**: [Increasing incidence of metastatic prostate cancer in the United States (2004-2013).](https://www.ncbi.nlm.nih.gov/pubmed/27431496)

What is the screening recommendation of today?

- “The formal recommendation for screening for prostate cancer is: **each physician and patient should discuss together. There is no formal recommendation.**”
- This worries Peter because many patients will have doctors who aren’t willing to be able to educate themselves
- I still see a lot of patients that show up and they’re not getting screened because they’re doctor’s basically saying well, obviously this is ‘controversial,’

## Biopsies and MRI: important things to know [1:25:30]

**What is a** [**prostate biopsy**](https://www.mayoclinic.org/tests-procedures/prostate-biopsy/about/pac-20384734)**?** ⇒ a procedure to remove samples of suspicious tissue from the prostate to test for cancer

- Relatively safe now
- Dramatized by anti-screeners
- [Transperineal biopsies](https://aua.com.au/urological-conditions-and-our-expertiseurological-cancersprostate-cancer/transperineal-prostate-biopsy/) are more common
- Less common is transrectal biopsies

Risks involved with biopsies

- Bleeding after the procedure
- Usually just a small amount in a bowel movement
- 1 or 2% will visit hospital with trouble urinating due to a swollen prostate
- Only a small percentage will get an infection and need to visit the hospital (only 0.4% of Ted’s patients)
- [Ted’s wrote up an analysis of all the data on complications](https://www.ncbi.nlm.nih.gov/pubmed/21944136)
- “In my practice I don’t biopsy everybody. I biopsy people who I think have clinically significant prostate cancer.”

What to do before deciding on a biopsy?

- Get a PHI or 4K score (FYI, these tests perform [equally well across demographics](https://www.ncbi.nlm.nih.gov/pubmed/26688190))
- If abnormal, get an MRI

**What kind of MRI?**

- You want a [multiparametric prostate MRI](https://www.openaccessjournals.com/articles/what-is-multiparametricmri-of-the-prostate-and-why-do-we-need-it.pdf)
- **The most important parameter in the multiparametric MRI is actually the [diffusion weighted imaging](https://en.wikipedia.org/wiki/Diffusion_MRI)**
- This is the most *operator dependent*, so it really requires a skilled technician and a skilled interpreter radiologist to look at those DWI images

> “So if you’re listening to that, and if your doctor refuses that, I think those are the kinds of things that make me think you need another doctor.”

**Multinational prospective clinical trial looking at the utility of MRI to use for screening for prostate cancer which increased detection of high-grade cancer and reduced the over-detection of low grade cancer**: [Role of mpMRI of the prostate in screening for prostate cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5503955/) (Wallis et al., 2017)

**What kind of biopsy is needed?**

- If there’s an abnormality on the MRI, Ted will recommend a biopsy
- You shouldn’t just sample the suspicious lesion
- You should do the suspicious lesion plus doing a [sextant biopsy](https://medical-dictionary.thefreedictionary.com/sextant+biopsy)

Putting all the screening together

- If the PHI and 4k tests are abnormal, Ted will do a multiparametric prostate MRI
- If MRI looks abnormal, he will recommend a sextant biopsy
- But, 20% of the time, the MRI is a false negative
- So in the case of a negative MRI, he then looks more closely at the PSA density
- If PSA density if high, he will recommend a biopsy
- But if they have an MRI, no lesion, and a low PSA density, they don’t need a biopsy

> “We have great tools that are building off of this very simple PSA blood test to offer people very sophisticated screening for their prostate cancer.”

## Why urology is such a great field of medicine, and why Peter wants a goat [1:34:45]

- Matt McCormick, urologist in Reno
- Patients are so appreciative
- Funny profession (dick jokes)
- Ted adds that in urology you “own the diagnosis” unlike other fields

Goats

- Peter wants goats
- Ted says get a [pygmy goat](https://en.wikipedia.org/wiki/Pygmy_goat) (actually get 2)

![](https://peterattiamd.com/wp-content/uploads/2019/02/Pygmy-Goat.jpg)

**Figure 2. Baby pygmy goat.** Image credit: [roysfarm.com](https://www.roysfarm.com/raising-pygmy-goats-as-pets/)

## Ted’s work with Ben Stiller [1:39:00]

- Ted was Introduced to [Ben Stiller](https://en.wikipedia.org/wiki/Ben_Stiller) through [Dr. Bernie Kruger](https://priorityprivatecare.com/our-physicians/)
- Peter shares an office with Bernie in NYC
- Ben Stiller got a hold of the book [Dr. Walsh’s Guide to Surviving Prostate Cancer](https://www.amazon.com/Patrick-Walshs-Surviving-Prostate-Cancer/dp/1455504181) (“amazing book”)
- Ben then met with Dr. Walsh, who then referred Ben to Ted for surgery
- Ben is now an advocated for the importance of screening and treating prostate cancer

Ben and Ted on the Howard Stern show:

**Also, see Ben and Ted on TODAY show**: [Ben Stiller Opens Up About Prostate Cancer For First Time Since Diagnosis | TODAY](https://www.youtube.com/watch?v=CPH8JuGu8cc)

## Gleason grading system [1:43:45]

**The** [**Gleason grading system**](https://en.wikipedia.org/wiki/Gleason_grading_system) **is a way to measure the aggressiveness of a cancer when looking at samples from a biopsy**

In the beginning, you would get a *Gleason sum*:

- What’s the score of most prevalent abnormality on the view of the tumor (rated 1-5)
- What’s the score of the second most common, kind of glandular architecture (rated 1-5)
- You add those two scores together to get the Gleason sum

Now, it’s evolved to the *Gleason grade group:*

- There are some subtle differences in the Gleason sum that actually have real big differences for what the patient’s outcomes would be
- In 2014/2015, a better way to transmit this Gleason information to patients and to internits in a way they can understand was created

Grade group groups

- Goes between 1 and 5
- The original old-school Gleason sum of six, that’s a 1.
- A Gleason sum of 3 plus 4 equals 7 is a 2.
- A sum of 4 plus 3 equals 7 is a 3.
- A 4 plus 4 = 8 is now a 4.
- A 4 plus 5 equals 9 is now a 5.
- A 5 plus 5 equals 10 is now a 5.
- **So this step wise gradation into five bins of aggressiveness called the grade group actually translates very nicely into clinical outcomes**

Does Ted use genetic testing?

- Not generally
- Don’t do any testing if the results want matter or change what we recommend
- PSA density performs just as well as genetic testing in most cases

After you know the Gleason grade, does anything before that matter?

- Yes, it all is still relevant (4k score, PSA numbers, MRI, etc.)
- Peter: “So this is the ultimate Bayesian experience.” ⇒ see [Peter’s email discussing Bayesian statistics](https://us15.campaign-archive.com/?u=21bc5f75235505c27ce465f90&id=f6df60f935)
- Peter calls Ted’s approach with patients “next-level judgement”

## Testosterone, DHT and the prostate cancer controversy [1:53:15]

**5-alpha-reductase inhibitors**

- Men make a hormone called testosterone
- Testosterone is converted via and enzyme called 5-alpha reductase into a very similar molecule called dihydrotestosterone (DHT)
- DHT is more potent than testosterone
- DHT drives hair loss and enlarges the prostate

*Medication (5-alpha-reductase inhibitors) used to reduce DHT:*

- [Proscar](https://www.webmd.com/drugs/2/drug-4496/proscar-oral/details) (finasteride) at five milligrams is taken to reduce prostate size
- [Propecia](https://www.webmd.com/drugs/2/drug-5471/propecia-oral/details) (finasteride) is one milligram is taken to reduce hair loss

**Relationship between 5-alpha-reductase inhibitors and prostate cancer**

The [Prostate Cancer Prevention Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4322917/)

- This trial showed that [lowering DHT could reduce the risk of prostate cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4322917/)
- But one of the problems was that there was *increased detection of more aggressive cancers* in men taking the drug to lower DHT

*Why is this happening?*

- A) Is it inducing high grade cancer?
- B) Or is it *selecting* for it because any cancer that comes out of low DHT environment must be strong? ⇒ This is what Peter and Ted believe

**Collaboration with GenomeDx**

- Ted collaborated with [Elai Davicioni](https://genomedx.com/about/team/management-team/) and his company, [GenomeDx](https://genomedx.com/), to look at the biology of prostate cancers, how aggressive they were, and compare the aggressiveness of the prostate cancer with the androgen output of the tumor
- **Hypothesis**: the tumors that had the most amped up androgen signaling, the most androgen output, because prostate cancer’s a androgen-driven tumor, that they would be the most aggressive.
- **The answer**: It is the opposite ⇒ The high androgen output tumors can be aggressive, however, they are not as aggressive as the ultra low ones. So it’s a bimodal distribution.

[The Decipher Test](https://deciphertest.com/)

- GenomeDx product that’s very good at telling the aggressiveness of prostate cancer
- Almost like a genomic Gleason score

**Low androgen tumors vs high androgen tumors**

> “We’ve been able to take all this [GenomeDx] data, and we’ve been able to show that these low androgen output tumors are the most aggressive tumors.”

- Using the GenomeDx data
- Ted has shown that these low androgen output tumors are the most aggressive tumors
- Very high androgen tumors are also aggressive, but they’re exquisitely sensitive to androgen deprivation, which is one of the mainstays of treatment for metastatic prostate cancer
- Low androgen output tumors are not because they are not dependent on it for fuel
- “However, we’ve been able to model other compounds that they are sensitive to, and so we’re moving those things into clinical trials. It’s actually pretty exciting times.”

**So. . .does testosterone replacement therapy cause prostate cancer?**

*“I don’t see any clear evidence that physiologic replacement of testosterone is going to accelerate or cause a cancer to develop.”*

What about [estradiol](https://en.wikipedia.org/wiki/Estradiol)?

- Some have argued that as estradiol is going up, that may be playing a greater role in prostate cancer
- Ted says it is unclear
- Hard to know if it is causal or just associated

## The metabolism of the prostate [2:03:00]

**Do the mitochondria in the prostate cancer follow the** [**Warburg effect**](https://en.wikipedia.org/wiki/Warburg_effect)**?**

In other words, do they favor anaerobic metabolism over oxidative phosphorylation?

- “We don’t know a lot about the metabolic environment of the prostate”
- David Guis is making progress in this space
- He has a lot of really [interesting data looking at the sirtuin pathways](https://www.ncbi.nlm.nih.gov/pubmed/20129246) through mitochondria regulating the hormonal dependency or hormonal regulation of prostate cancer.
- He has a SIRT3 manganese superoxide dismutase pathway worked out and it regulates resistance to Tamoxifen and luminal B breast cancer
- So it could be up-regulating or down-regulating androgen production basically.

> “I do think that there’s something about metabolism in the prostate. I think it’s hard to study. . .You cannot model in a mouse. I do think that there are some good people on campus here who think about it and are gonna be able to study it.”

## The most exciting areas of research in prostate cancer [2:08:00]

- The most exciting stuff in urologic oncology is really moving beyond these prognostic biomarkers to *predictive biomarkers you can pick up in the DNA of a tumor or the DNA of a patient* ⇒ Particularly BRCA1, BRCA2, ATM loss . . . “these different kinds of DNA damage repair pathways that people didn’t really think matter for prostate, we now know within the last three years that they really matter.”

**⇒ Pete Nelson paper showing that about 11 to 12% of men with metastatic castrate-resistant prostate cancer had mutations, particularly BRCA2, BRCA1, ATM, RAD51**: [Recent advances in prostate cancer research: large-scale genomic analyses reveal novel driver mutations and DNA repair defects](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6073096/) (Frank et al., 2018)

- “If you look in the tumors of men with metastatic castrate-resistant prostate cancer, depending on where you look, over one third of the tumors, the cells will have mutations in these pathways, which makes them incredibly sensitive to PARP inhibition, so that’s a huge game changer.”
- “Also, the total genomic score, or the alterations in the genome of the individual cancer cells, and will that make them more sensitive to immunotherapy or not? That’s more coming online, but the idea that there are things in the somatic DNA of the tumor cells and in the germline of individuals that you can use to screen for not only prostate, but breast, pancreas, etc, that’s a huge game changer.”
- “Then I think Eli’s test, which has a lot of these built in biomarkers that predict response to drugs that now are being tested in clinical trials, with the idea that let’s test the ability to predict response, is pretty amazing stuff actually.”

## Benign issues involving the prostate: pelvic pain, infections and treatments [2:11:15]

**Chronic pelvic pain**

- This broad term covers common conditions like
  - Nonbacterial prostatitis (inflammation in prostate, no infection)
  - Interstitial cystitis

**Prostatitis**: Peter tells a personal story

- Peter had severe burning while peeing
- Not a UTI
- Called Ted, agreed it could be [prostatitis](https://www.mayoclinic.org/diseases-conditions/prostatitis/symptoms-causes/syc-20355766)
- [Ted’s dad’s paper](https://www.nejm.org/doi/full/10.1056/NEJMcp060423)
- Prostatitis can be caused by an infection, or just inflammation
- Ted suspected inflammation
- Before taking antibiotics, Ted said go and get a prostate massage so we can check the fluids for infection
- Peter said 3 days after massage, he felt great, never took antibiotics
- Peter said the massage was extremely painful, **here’s how he felt:**

- So what Peter had was nonbacterial prostatitis (inflammation in the prostate)
- This falls into the bucket of “chronic pelvic pain”
- Not so sure what causes it other than constipation

**Interstitial cystitis**

- Botox in the bladder as a treatment? ⇒ No, we use Botox in the bladder for people who have hypercontractility of the bladder, but we don’t use it for people who have interstitial cystitis

**Deep-seated infections in their prostate**

- You can actually directly inject antibiotics into the prostate
- The typical nidus for this persistent infection is actually the seminal vesicle, which is attached to the prostate
- So they will to a transrectal injection directly into the seminal vesicle

## Video of Ted’s surgeries, the latest technology, and males contraceptive options [2:18:00]

Robot surgery ⇒ All of Ted’s surgeries are now with the help of a robot

**Watch Ted perform a robotic prostatectomy:**

**Full list of Ted’s surgery videos**: [Click here](https://www.youtube.com/channel/UC848_zzLQPnWA01V3_CtS4A/videos)

Which is better robot or open?

- Robot is more precise in Ted’s opinion
- [Dr. Walsh Compares Open and Robotic-Assisted Radical Prostatectomy Operations](https://www.youtube.com/watch?v=zP7OGtteuVs)

Male contraceptives

- Anything coming soon outside of a vasectomy?
- Some stuff that can block testosterone in the testicle, some coming soon

Vasectomies

- Safe procedure for sure (maybe freeze some sperm first)
- Easy to reverse? ⇒ Over 90% are reversible with a good procedure

## Watches and cars [2:23:30]

**Watches**

- Ted was wearing the “[beautiful Hulk](https://www.google.com/search?q=rolex+hulk&source=lnms&tbm=isch&sa=X&ved=0ahUKEwjAlNeS15rgAhVES60KHeuoDywQ_AUIDygC&biw=1108&bih=647&dpr=2)” during the podcast interview
- Peter’s obsessed with 2 Vacheron watches: The Ultra Thin, and the 1921

![](https://peterattiamd.com/wp-content/uploads/2019/02/ultra-thin-1024x886.png)

**Figure 3. Vacheron Ultra Thin.** Image credit: [vacheron-constantin.com](https://www.vacheron-constantin.com/en2/watches/overseas/overseas-ultra-thin-2000v-120g-b122.html)

![](https://peterattiamd.com/wp-content/uploads/2019/02/1921-1024x683.jpg)

**Figure 4. Vacheron 1921. Image credit**: [monochrome-watches.com](https://monochrome-watches.com/vacheron-constantin-historiques-american-1921-mid-size-36-5-mm-review-price/)

**Cars**

- The car that Peter would choose to have as a daily vehicle: [Porsche 911 Turbo](https://www.porsche.com/usa/models/911/911-turbo-models/)

![](https://peterattiamd.com/wp-content/uploads/2019/02/911-Turbo-1024x507.png)

**Figure 5. Porsche 911 Turbo.** Image credit: [porsche.com](https://www.porsche.com/usa/models/911/911-turbo-models/)

Other cars mentioned:

- [Ferrari 458](https://en.wikipedia.org/wiki/Ferrari_458)
- [Ferrari 488](https://en.wikipedia.org/wiki/Ferrari_488)
- [McLaren P1](https://en.wikipedia.org/wiki/McLaren_P1)
- [McLaren Senna](https://en.wikipedia.org/wiki/McLaren_Senna)
- [McLaren 720S](https://en.wikipedia.org/wiki/McLaren_720S)
- [LaFerrari](https://en.wikipedia.org/wiki/LaFerrari)
- [Porsche 918 Spyder](https://en.wikipedia.org/wiki/Porsche_918_Spyder)

**Driver that Peter follows on YouTube:** [Chris Harris on Cars](https://www.youtube.com/chrisharrisoncars) (driver is a car reviewer named [Chris Harris](https://en.wikipedia.org/wiki/Chris_Harris_(journalist)))

§

## Selected Links / Related Material

**For a full list of Ted’s current publications**: [CLICK HERE](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=34261#publications)

**For a full list of Ted’s surgery videos**: [CLICK HERE](https://www.youtube.com/channel/UC848_zzLQPnWA01V3_CtS4A/videos)

**Ted’s scholarship to study at the NIH was through the**: [Howard Hughes Medical Institute](https://en.wikipedia.org/wiki/Howard_Hughes_Medical_Institute) | (wikipedia.org) [7:30]

**The lab where Ted studies immunology**: [The Laboratory of Harold Varmus](https://www.varmuslab.org/) | (varmuslab.org) [10:45]

**Harold Varmus and Michael Bishop shared the Nobel prize**: [The Nobel Prize in Physiology or Medicine 1989](https://www.nobelprize.org/prizes/medicine/1989/summary/) | (nobelprize.org) [12:00]

**In 1904, Hugh H. Young performed the first radical prostatectomy for cancer**: [Hugh Hampton Young, M.D.](https://urology.jhu.edu/about/young.php) | (urology.jhu.edu) [40:45]

**The founder of Johns Hopkins medicine**: [The Four Founding Physicians](https://www.hopkinsmedicine.org/about/history/history5.html) | (jhu.edu) [42:45]

**The procedure that Peter presented on during “Sunday School”**: [Warren shunt](https://en.wikipedia.org/wiki/Distal_splenorenal_shunt_procedure) | (wikipedia.org) [45:30]

**Dr. Pat Walsh’s video of his operations**: [Radical Retropubic Prostatectomy: 2004](https://www.youtube.com/watch?v=sasFpBlvxLg) | Johns Hopkins Urology (youtube.com) [51:00]

**Watch Pat Walsh perform a prostatectomy in the 1970s**: [The Art of Retropubic Prostatectomy – Joseph J. Kaufman, MD and Patrick C. Walsh, MD](https://www.youtube.com/watch?v=EAif5oahUnw) | Bill Spark (youtube.com) [51:00]

**The creation of the 4k Test**: [A four-kallikrein panel predicts prostate cancer in men with recent screening: data from the European Randomized Study of Prostate Cancer Screening, Rotterdam](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2891337/) (Vickers et al., 2010) [1:09:30]

**The 7.5% cut off on the 4k test based on the database from Vickers and Hans Lilja**: [Improving the Specificity of Screening for Lethal Prostate Cancer Using Prostate-specific Antigen and a Panel of Kallikrein Markers: A Nested Case–Control Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4496315/) (Stattin et al., 2016) [1:11:00]

**A notorious “anti-screener” actually agreed PSA testing was a good thing**: [Prostate-Specific Antigen Testing: Good or Bad?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4350812/) (Peter C. Albertsen, 2015) [1:15:30]

**Vicker’s analysis of percentage of people with lethal-type cancers that had a “normal” PSA reading**: [Evaluation of Prediagnostic Prostate-Specific Antigen Dynamics as Predictors of Death from Prostate Cancer in Patients Treated Conservatively](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2988082/) (O’Brien et al., 2012) [1:18:45]

**New screening guidelines lead to rise in advanced prostate cancer**: [Increasing incidence of metastatic prostate cancer in the United States (2004-2013).](https://www.ncbi.nlm.nih.gov/pubmed/27431496) (Weiner AB et al., 2016) [1:20:15]

**Ted’s paper about the percentage of people needed to be admitted to the ER after a biopsy**: [Complications after prostate biopsy: data from SEER-Medicare.](https://www.ncbi.nlm.nih.gov/pubmed/21944136) (Loeb et al., 2011) [1:27:00]

**The creation of the PHI test for detection prostate cancer**: [The Prostate Health Index: a new test for the detection of prostate cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3943368/) (Loeb et al., 2014) [1:28:15]

**4k test performs just as well for African-Americans**: [AN INDEPENDENT, MULTI-INSTITUTIONAL, PROSPECTIVE STUDY IN THE VETERANS AFFAIRS HEALTH SYSTEM CONFIRMS THE 4KSCORE ACCURATELY PREDICTS AGGRESSIVE PROSTATE CANCER](https://www.jurology.com/doi/full/10.1016/j.juro.2017.02.3171) (Punnen et al., 2017) [1:28:30]

**OPKO looking at 4k score performance in a clinical setting**: [Clinical performance of the 4Kscore Test to predict high-grade prostate cancer at biopsy: A meta-analysis of us and European clinical validation study results](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5737341/) (Zappala et al., 2017) [1:28:30]

**Ted’s clinical trying looking at the PHI test in African-American men**: [Prostate Health Index (PHI) Predicts High-stage Pathology in African American Men.](https://www.ncbi.nlm.nih.gov/pubmed/26688190) (Schwen et al., 2016) [1:28:30]

**Multinational prospective clinical trial looking at the utility of MRI to use for screening for prostate cancer which increased detection of high-grade cancer and reduced the over-detection of low grade cancer**: [Role of mpMRI of the prostate in screening for prostate cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5503955/) (Wallis et al., 2017) [1:31:00]

**Gleason score helps to evaluate the prognosis of men with prostate cancer**: [Gleason grading system](https://en.wikipedia.org/wiki/Gleason_grading_system) | (wikipedia.org) [1:34:45]

**Ted on Howard Stern show with Ben Stiller**: [Ben Stiller Goes Public with His Fight Against Prostate Cancer on the Howard Stern Show](https://www.youtube.com/watch?v=VXBRonwTbqM) | The Howard Stern Show (youtube.com) [1:39:45]

**Pat Walsh’s amazing book**: [Dr. Walsh’s Guide to Surviving Prostate Cancer](https://www.amazon.com/Patrick-Walshs-Surviving-Prostate-Cancer/dp/1455504181) by Patrick C. Walsh | (amazon.com) [1:41:00]

**The ISUP came together to create a better way to present Gleason score information to patients and internists in a way that they can better understand**: [International Society of Urological Pathology (ISUP) grading of prostate cancer – An ISUP consensus on contemporary grading.](https://www.ncbi.nlm.nih.gov/pubmed/27150257) (Egevad et al., 2014) [1:46:45]

**Peter’s weekly email about Bayesian statistics**: [How to make better decisions](https://us15.campaign-archive.com/?u=21bc5f75235505c27ce465f90&id=f6df60f935) | Peter Attia (peterattiamd.com) [1:49:45]

**Medication (5-alpha-reductase inhibitors) used to reduce DHT**: [1:54:45]

- [Proscar](https://www.webmd.com/drugs/2/drug-4496/proscar-oral/details) (finasteride) at five milligrams is taken to reduce prostate size
- [Propecia](https://www.webmd.com/drugs/2/drug-5471/propecia-oral/details) (finasteride) is one milligram is taken to reduce hair loss

**Trial showed lowering DHT could reduce the risk of prostate cancer**: [Prevention of Prostate Cancer: Outcomes of Clinical Trials and Future Opportunities](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4322917/) (Thompson et al., 2015) [1:55:15]

**Case reports that people with low PSAs are the individuals who get more aggressive cancers**: [Association of very low prostate‐specific antigen levels with increased cancer‐specific death in men with high‐grade prostate cancer](https://onlinelibrary.wiley.com/doi/full/10.1002/cncr.29691) (Mahal et al., 2015) [1:56:30]

**Ted’s collaborated with GenomeDx on the biology of prostate cancers, how aggressive they were, and compare the aggressiveness of the prostate cancer with the androgen output of the tumor**: [GenomeDx](https://genomedx.com/) | ([genomedx.com](https://genomedx.com/)) [1:56:45]

**Commercially available tests from GenomeDx**: [1:58:00]

- [Decipher test](https://deciphertest.com/) (for understanding prostate cancer risk)
- [Guidance test](https://genomedx.com/guidance/) (Recurrent UTI ■ Interstitial Cystitis ■ Prostatitis ■ Cystitis)

**Tim Ferriss book that Elai Davicioni called ‘Biggest Tools’**: [Tools of Titans: The Tactics, Routines, and Habits of Billionaires, Icons, and World-Class Performers](https://www.amazon.com/Tools-Titans-Billionaires-World-Class-Performers/dp/1328683788) by Tim Ferriss | (amazon.com) [1:58:30]

**Work by David Guis showing SIRT3 could be up-regulating or down-regulating androgen production and affecting cancer**: [SIRT3 is a mitochondria-localized tumor suppressor required for maintenance of mitochondrial integrity and metabolism during stress.](https://www.ncbi.nlm.nih.gov/pubmed/20129246) (Kim et al., 2010) [2:05:15]

**Peter’s Easter Island trip with Navdeep Chandel and Tim Ferriss**: [My Life Extension Pilgrimage to Easter Island](https://tim.blog/2016/10/20/my-life-extension-pilgrimage-to-easter-island/) | Tim Ferriss (tim.blog) [2:07:00]

**Pete Nelson paper showing that about 11 to 12% of men with metastatic castration-resistant prostate cancer had mutations, particularly BRCA2, BRCA1, ATM, RAD51**: [Recent advances in prostate cancer research: large-scale genomic analyses reveal novel driver mutations and DNA repair defects](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6073096/) (Frank et al., 2018) [2:09:30]

**Ted’s father wrote a paper which Peter read after having excruciating pain due to what he thought was prostatitis**: [Chronic Prostatitis and the Chronic Pelvic Pain Syndrome](https://www.nejm.org/doi/full/10.1056/NEJMcp060423) | Anthony J. Schaeffer, M.D. (nejm.org) [2:12:30]

**Chevy Chase scene in Fletch**: [“Using the whole fist there, doc? Moon River.”](https://www.youtube.com/watch?v=CfZiAiYNcI8) | Brian Sierzega (youtube.com) [2:13:30]

**Pat Walsh on the using the robot for surgery**: [Dr. Walsh Compares Open and Robotic-Assisted Radical Prostatectomy Operations](https://www.youtube.com/watch?v=zP7OGtteuVs) | OncLiveTV (youtube.com) [2:18:00]

**Porsche 918 breaks 1:30 lap time at Laguna Seca**: [Porsche 918 Spyder laptime at Laguna Seca](https://fastestlaps.com/tests/l89gn63puhdn) | (fastestslaps.com) [2:28:30]

**Ted’s website**: [dr-schaeffer.com](https://dr-schaeffer.com/) [2:30:00]

§

## People Mentioned

- [Jonathan Ashwell](https://ccr.cancer.gov/Laboratory-of-Immune-Cell-Biology/jonathan-d-ashwell) (immunologist who helped Ted decide to go into immunology) [9:45]
- [Grant Barish](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=24639) (good friend of Ted at Northwestern, introduced Ted to Pam Schwartzberg) [10:30]
- [Pam Schwartzberg](https://www.niaid.nih.gov/research/pamela-l-schwartzberg-md-phd) (mentored Ted in his NIH at the Varmus Lab) [10:30, 24:15]
- [Harold Varmus](https://en.wikipedia.org/wiki/Harold_E._Varmus) (Ted worked in his lab, Nobel Prize winner with the idea that you could pass on a cancer through a viral induction) [11:30]
- [Michael Bishop](https://en.wikipedia.org/wiki/J._Michael_Bishop) (shared the Nobel prize with Harold Varmus) [12:00]
- [Lewis Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley) (Peter had dinner with him, American cell biologist and biochemist who has made significant advances to the understanding of cancer metabolism) [12:45]
- [David Sabatini](https://twitter.com/DMSabatini?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (previous [guest on The Drive](https://peterattiamd.com/davidsabatini/)) [12:45]
- [Steve Rosenberg](https://en.wikipedia.org/wiki/Steven_Rosenberg) (Peter’s mentor at the NCI) [13:30, 36:00]
- [Francis Collins](https://www.nih.gov/about-nih/who-we-are/nih-director/biographical-sketch-francis-s-collins-md-phd) (Ted shared lab space with him, now the director of the NIH) [16:15, 18:15]
- [Louis Staudt](https://ccr.cancer.gov/Lymphoid-Malignancies-Branch/louis-m-staudt) (at the NIH) [17:00]
- [Charles Sawyers](https://www.mskcc.org/cancer-care/doctors/charles-sawyers) (an idol of Ted’s, involved in identifying this fused mutation) [22:30]
- [Pat Walsh](https://urology.jhu.edu/patrickwalsh/) (pioneer in prostate cancer treatment and surgery, Ted’s mentor and partner)  [32:00, 36:00, 54:30, 1:38:30]
- [John Cameron](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0001321/john-cameron) (pancreatic surgery) [36:30]
- [Hugh Hampton Young](https://en.wikipedia.org/wiki/Hugh_H._Young) (the first radical prostatectomy for cancer, first urologist at Johns Hopkins) [40:45, 42:45]
- The Four Founding Physicians of Johns Hopkins: [42:45]
  - [William Henry Welch](https://en.wikipedia.org/wiki/William_H._Welch) (pathologist)
  - [William Stewart Halsted](https://en.wikipedia.org/wiki/William_Stewart_Halsted) (surgeon)
  - [William Osler](https://en.wikipedia.org/wiki/William_Osler) (internist)
  - [Howard Kelly](https://en.wikipedia.org/wiki/Howard_Atwood_Kelly) (gynecologist)
- [Julie Ann Sosa](https://medschool.ucsf.edu/julie-ann-sosa-md-ma-facs-appointed-chair-surgery) (chair at UCSF, taught Ted how to tie a square knot) [45:15]
- [Karen Kling](https://www.rchsd.org/doctors/karen-kling-md/) (Peter’s fellow in Hopkins, now an attending in San Diego) [47:00]
- [Jon Vogel](https://www.cudoctors.com/Find_A_Doctor/Profile/21716) (taught Peter how to put in an NG tube) [47:00]
- [Andrew Vickers](https://www.mskcc.org/profile/andrew-vickers) (helped develop the 4k test) [1:08:15, 1:18:45, 1:28:00]
- [Hans Lilja](https://www.mskcc.org/cancer-care/doctors/hans-lilja) (helped develop the 4k test) [1:09:30, 1:28:00]
- [Peter Scardino](https://www.mskcc.org/cancer-care/doctors/peter-scardino) (helped develop the 4k test) [1:09:30]
- [Thomas Stamey](https://med.stanford.edu/news/all-news/2015/09/thomas-stamey-expert-on-prostate-cancer-and-psa-test-dies-at-87.html) (made the observation that you could use the PSA test to follow men after their cancer treatment and if the number went up their cancer was back, “It was a game changer”) [1:13:15]
- [Bill Catalona](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=18380) (one of Ted’s partners, another godfather in the field) [1:13:45]
- [Peter Albertsen](https://facultydirectory.uchc.edu/profile?profileId=Albertsen-Peter) (an “anti-screener” but actually concluded good things about PSA tests) [1:15:30]
- [Otis Brawley](https://winshipcancer.emory.edu/bios/faculty/brawley-otis.html) (Ted “got into it” with Otis about prostate cancer screening) ]1:23:00]
- [Matt McCormack](https://www.urologynevada.com/our-doctors-physicans/) (urologist in Reno, classmate of Peter in med school) [1:35:00]
- [Ben Stiller](https://en.wikipedia.org/wiki/Ben_Stiller) (patient of Ted’s, publicly outspoken about his battle with prostate cancer) [1:39:45]
- [Bernie Kruger](https://priorityprivatecare.com/our-physicians/) (amazing internist, doctor of Ben Stiller, Peter offices with him in NYC) [1:40:00]
- [Herbert “Bal” Carter](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0004339/herbert-carter) (surgical mentor for Ted) [1:42:30, 2:20:00]
- [Donald Gleason](https://en.wikipedia.org/wiki/Donald_Gleason) (Gleason score) [1:44:00]
- [Ian Thompson](https://www.texasurologygroup.com/about/) (prostate cancer prevention trial) [1:55:45]
- [Elai Davicioni](https://genomedx.com/about/team/management-team/) (GenomeDx, biology of prostate cancers) [1:56:45]
- [David Guis](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=25741) (brilliant radiation oncologist) [2:03:45]
- [Navdeep Chandel](https://www.feinberg.northwestern.edu/sites/diabetes/members/profile.html?xid=11123) (metabolism expert, previous [guest on The Drive](https://peterattiamd.com/navchandel/)) [2:06:45]
- [Matthew Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) (classmate of Peter and Ted, oncologist) [2:07:30]
- [Mark Pomerantz](https://www.dana-farber.org/find-a-doctor/mark-pomerantz/) (medical oncologists) [2:08:00]
- [Pete Nelson](https://www.fredhutch.org/en/diseases/featured-researchers/nelson-peter.html) (urologic oncologist, one of Ted’s heros) [2:09:30]
- [Anthony J. Schaeffer](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=13362) (Ted’s father, urologist at Northwestern) [2:12:30]
- [Bob Brannigan](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=10530) (vasectomy expert) [2:21:15]
- [Chevy Chase](https://en.wikipedia.org/wiki/Chevy_Chase) (prostate exam scene from the movie Fletch) [2:13:30]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) (greatest F1 driver of all time) [2:27:15]
- [Chris Harris](https://en.wikipedia.org/wiki/Chris_Harris_(journalist)) (car reviewer Peter follows, [Chris Harris on Cars](https://www.youtube.com/chrisharrisoncars)) [2:28:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/02/bio-image-500x500.jpg)

##### Dr. Edward Schaeffer

Edward (Ted) M. Schaeffer, MD, PhD is an internationally recognized physician-scientist with expertise in urologic oncology. He is Professor and Chair of the Department of Urology at the Feinberg School of Medicine and Northwestern Memorial Hospital and Director of the Genitourinary Oncology Program at the Robert H. Lurie Comprehensive Cancer Center of Northwestern University.

A respected clinician with expertise in open, laparoscopic, and robotic treatments of urologic malignancies, Dr. Schaeffer previously served as Director of the Prostate Cancer Program, Director of International Urology, and Codirector of the Prostate Cancer Multidisciplinary Clinic at Johns Hopkins Medicine.  He was also a member of the James Buchanan Brady Urological Institute and the Sidney Kimmel Comprehensive Cancer Center, where he participated in multidisciplinary approaches to the treatment of genitourinary cancers. Dr. Schaeffer was the R. Christian B. Evensen Professor of Urology, Oncology, and Pathology at the Johns Hopkins School of Medicine, and Founder and Chief Medical Officer of the Prostate Cancer Foundation of Norway.

Dr. Edward M. Schaeffer’s discoveries have greatly advanced the basic scientific understanding of prostate cancer and clinical care pathways. His groundbreaking research emphasizes at-risk populations, diagnosis, treatment outcomes, and the molecular biology of lethal prostate cancer.

Dr. Edward M. Schaeffer’s laboratory, which has been funded by the National Institutes of Health, the Howard Hughes Medical Institute, the U.S. Department of Defense, and the Prostate Cancer Foundation, specifically focuses on the molecular biology of locally aggressive prostate cancers and the impact of race on the biology of prostate cancer. [[dr-schaeffer.com](https://dr-schaeffer.com/about-dr-schaeffer/)]

Twitter: [@edwardschaeffer](https://twitter.com/edwardschaeffer?lang=en)

Website: [dr-schaeffer.com](https://dr-schaeffer.com/about-dr-schaeffer/)