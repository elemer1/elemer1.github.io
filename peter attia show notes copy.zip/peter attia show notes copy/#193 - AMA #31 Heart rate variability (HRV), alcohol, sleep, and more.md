# #193 – AMA #31: Heart rate variability (HRV), alcohol, sleep, and more

**Source:** [https://peterattiamd.com/ama31/](https://peterattiamd.com/ama31/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob first answer a variety of questions related to heart rate variability (HRV): what it means, why it matters, and how to measure, interpret, and potentially elevate it. Next, they dive deep into the topic of alcohol, beginning with a discussion on the negative impact that it can have on sleep. They then break down the confusing body of literature suggesting potential health benefits to moderate levels of drinking compared to complete abstinence and point out the limitations of these studies. Finally, they conclude by analyzing data on the impact of moderate and heavy drinking on the liver and on risk for Alzheimer’s disease and dementia.

Please note: this AMA is audio only. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #31 show notes page](https://peterattiamd.com/ama31). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- What is heart rate variability (HRV), and why do we measure it? [2:10];
- The association between low HRV and mortality risk [10:00];
- What high and low HRV means and why athletes strive for a high HRV [15:30];
- Factors that can raise or lower HRV [18:00];
- How and when to measure HRV, and the best wearables [19:15];
- Interpreting your personal HRV number and why there’s so much individual variation [23:15];
- How Peter’s morning HRV reading impacts his decision to train [28:30];
- Alcohol’s impact on sleep [31:30];
- Metrics to track the impact of alcohol on your sleep [34:00];
- Alcohol’s impact on the need to urinate during the night [39:00];
- Alcoholic fatty liver disease (AFLD) [41:30];
- Individual differences in the way people metabolize and react to alcohol consumption [44:15];
- Analysis of epidemiology studies suggesting moderate alcohol consumption lowers mortality risk [52:00];
- Alcohol consumption and Alzheimer’s disease [1:05:15];
- Heavy alcohol consumption and risk of dementia [1:08:30];
- Chronic effects of alcohol on the liver [1:17:45];
- The relationship between alcohol, sleep, and automotive deaths [1:20:45]; and
- More.

§

The Peter Attia Drive

Heart rate variability (HRV), alcohol, sleep, and more

§

## Show Notes

## What is heart rate variability (HRV), and why do we measure it? [2:10]

***What is HRV?***

- HRV stands for heart rate variability
- HRV measures the variation in time between heartbeats, and that’s measured in milliseconds (1,000 milliseconds is one second)
  - So if a person’s heart is beating 60 times per minute, you think there’s 1,000 milliseconds between every beat…but it turns out that it’s not really the case
  - Even if your heart is beating 60 times per minute (i.e., once per second) between the first beat and the second beat, it might be 1,010 milliseconds
  - And between that second beat and the third beat, it might be 960 milliseconds
  - And between that beat and the beat thereafter, it might be 1,027 milliseconds.
  - In other words, there is actually some variability
- If anybody has ever seen an EKG, most people will recognize that there is a very big spike for each of those beats (known as the spike in the R wave)
- If you now measure the distance between the Rs—the RR interval—and you take the RMSSD (The Root Mean Square of Successive Differences between normal heartbeats)…that means you calculate the time difference between each RR interval
  - The RMSSD is obtained by first calculating each successive time difference between heartbeats (RR intervals) in ms.
  - Then, each of the values is squared and the result is averaged before the square root of the total is obtained.
- So RMSSD is reported in milliseconds
  - If using wearables that calculate HRV while you’re sleeping, you’ll notice it gives you a number in milliseconds

**Why do we measure HRV? [5:45]**

*What can it tell us, possibly?*

- HRV provides a snapshot into how your body is balancing between the two branches of your autonomic nervous system: sympathetic (“fight-or-flight”), and parasympathetic (“rest-and-digest”).
- The heart is not a metronome – it’s actually erratic
- A healthy nervous system has a balanced but strong push and pull between Sympathetic and Parasympathetic causing high Heart Rate Variability
- It turns out that that variability is heavily influenced by which of the autonomic nervous systems is most dominant

*What is the autonomic system, and what’s the difference between sympathetic and parasympathetic?*

- The **Autonomic system** handles the unconscious processes (and even effects conscious behavior)
  - Autonomic contains two branches – the Parasympathetic and the Sympathetic
- **Sympathetic** is activated in times of stress
  - Fight or Flight
  - Sacrifice long term to get through the short term
  - Flood energy, dilate pupils, slow digestion/peristalsis, increase heart rate
  - It’s slowing digestion and peristalsis, meaning it’s slowing down anything that’s not essential, and it’s increasing heart rate
  - From a practical standpoint, if you’re laying in bed and you hear a loud bang in your house, you have no idea if it’s an intruder or if a picture fell off the wall, but you don’t even have to worry about it, your brain isn’t going to even force you to make that decision. It’s going to make the decision for you, which is this is a threat
  - so your heart rate is going to shoot up, your pupils will dilate, any amount of digestive energy going on right now will cease, and your liver is going to start cranking out glucose and making you available for fight or flight
- **Parasympathetic** is activated in times of recovery
  - Rest and digest
  - Conserve energy, constrict pupils, aid digestion, slows heart rate

***What does this have to do with HRV?***

- when the sympathetic system is revved up, HRV goes down
- when the parasympathetic system is in control HRV goes up
- As the heart rate speeds up, which is what’s happening under sympathetic tone, there’s less variability between the beats
- When the heart rate slows down, when the body is relaxing, there’s more variability between beats.

## The association between low HRV and mortality risk [10:00]

Overall:

- There’s not a lot of data, despite what people might have you believe about RMSSD, and heart rate variability, and mortality in *normal* populations
- But there are cohort studies that look at this and try to impute patterns

**The ARIC** [**study**](https://www.ahajournals.org/doi/10.1161/01.CIR.102.11.1239)

- Case-cohort in 900 participants age 45-64
- In people who had an HRV (using the rMSSD method from a two-minute rhythm strip on a 12-lead EKG) of less than 14.7 millisecond compared to those who had an HRV between 14.7 and 22.3 milliseconds, the study found a greater risk of:
  - All-cause mortality (ACM) by about 95%
  - Cerebrovascular mortality by 280%
  - And cancer mortality by 70% (barely significant)
  - There was no difference in CHD in the two groups
- W*hat can we impute from that study*?
  - these studies are very difficult to really draw a **causal** relationship from because there can be a lot of reasons why someone would have a lower HRV
  - It might just be that a low HRV is a marker for some of these other things, and when you correct for those other things in an otherwise healthy individual who doesn’t have them, does the HRV still hold up?
  - In this study, however, they did TRY to correct for all the usual suspects—Age, sex, race, smoking, triglycerides, hypertension, etc.
  - Peter says it’s still hard for him to say there is a causal relationship

[**Meta-analysis**](https://academic.oup.com/europace/article/15/5/742/673395) **from 2013**

- 8 studies and ~22,000 participants
- A low HRV (10th percentile) was associated with a 50% increased risk [1.50 (95% CI 1.22, 1.83)] of a first cardiovascular event in people without CVD compared to those in the 50th percentile.
- There was not a significant association (trend toward decreased risk) in the 90th percentile compared to the 50th percentile [0.67 (95% CI 0.41, 1.09)].
- The trend of note:
  - There’s a non-significant trend toward a decreased risk with these higher HRV values compared to the median, or compared to the, say, the 50th percentile
  - What happens is we’ll say there’s no difference for coronary heart disease incidents. And then you look at the relative risk and it was about non-significant, 50% increase
  - But we’ve talked about confidence intervals, and if confidence interval crossed one, but it was a 0.99—It was very close to getting there to significance
  - There tended to be a trend, but non-significant. And that seems to be repeated along a lot of these observational studies, whereas the low HRV compared to the median, seems like that shows more statistical significance in terms of an increased risk for the lower HRV.

Peter’s takeaway:

- Low HRV is ***associated*** with an increased mortality in people with heart disease, possibly cancer
- Higher HRV compared to intermediate levels has a less clear benefit
  - There was no significant difference for all-cause mortality, cerebrovascular mortality, cancer mortality, or coronary artery disease incidents in those who had an HRV above 22.3, compared to those who were 14.7 to 22.3
- In other words, what mattered most is if you were above 14.7 (in the ARIC study-which represents less the 50th percentile and likely closer to the 27%)
  - But once you’re above, there doesn’t seem to be any additional benefit to being above 22.3

## What high and low HRV means and why athletes strive for a high HRV [15:30]

*Is there a correlation between resting heart rate and HRV?*

- Some studies show that there’s a high (negative) correlation between the resting heart rate and the HRV
- Low heart rate, high HRV
- High heart rate, low HRV

*High HRV*

- HRV can be a metric for measuring how ready your body is to adapt, and ultimately perform, in sports.
- High HRV means you’re getting both strong “on” and “off” outputs and your body is highly responsive to your environment. It can quickly shift its energy from “fight or flight” to “rest and digest” to easily match its surroundings.
- It’s like this nice balance struggle, almost back and forth between the sympathetic and the parasympathetic systems

*Low HRV*

- Generally, it’s a sympathetic dominance
- However, in rare instances or particular instances where you can have a low heart rate and a low HRV, which usually it’s a parasympathetic dominance which seems like it’s relatively rare.
  - When you do your marathon training, for instance, you ramp up your training all the way up to maybe a couple weeks out before the event, and then oftentimes you do what’s called a taper. You actually bring down the volume of your exercise by quite a bit
  - What could happen there is that you’ve been training for an extended period of time, and probably revving up that sympathetic system while you’re exercising, et cetera. And then you compensate, you may get improvement in your parasympathetic, so you have this nice back and forth
  - Then you back off of all that exercise, and you might be backing off a lot of that sympathetic activity.
  - And so you might see this parasympathetic saturation which researchers refer to as a “hyper recovery state”
  - It could mislead you where you look at your HRV and say, “Well, it looks like my readiness, I’m not ready to train today.” However, it might be that, it’s almost like you’re hyper recovered. Your parasympathetic is dominating a little bit more than your sympathetic system

NOTE: comparing your HRV to another person’s HRV might not be the most helpful thing in the world, but knowing how your HRV, your heart rate, your respiratory rate, your body temperature change over time, and assimilating all of that data is probably a more useful biomarker

## Factors that can raise or lower HRV [18:00]

**Things that lower HRV**

- Alcohol – “I’ve never seen anything that lowers my HRV as much as alcohol does” says Peter
- stress
- when you go to bed and you’re stressed out, and you’re ruminating, you’re probably going to have lower HRV
- Smoking
- lack of physical activity
- lousy diet
- caffeine consumption in the evening
- high blood pressure
- high triglycerides
- metabolic syndrome
- apparently even air pollution can lower a person’s HRV

**Things that raise HRV**

- endurance exercise
- yoga
- meditation
- [Biofeedback](https://en.wikipedia.org/wiki/Biofeedback)
  - “Biofeedback is probably one of the things that I’ve seen have the most effect.”
  - “I’ve got a number of patients who are quite diligent in their use of biofeedback and breathing techniques. And I’ve seen them increase their HRV by 50%.”
- Good sleep hygiene

## How and when to measure HRV, and the best wearables [19:15]

**Ways to measure HRV**

*Chest leads*

- Up until 2016, Peter would track his HRV with chest leads –
  - super cumbersome device
  - And you had to wear the thing for three days at a time
  - really user hostile
  - On the positive side, it was very accurate and it was really interesting because it was also obviously tracking heart rate, respiratory rate, and everything 24/7.
  - it was extrapolating into when you were parasympathetic versus sympathetic based on how all of those things worked
  - And it was really interesting because it was also tracking heart rate, respiratory rate, and everything 24/7.
  - it was extrapolating into when you were parasympathetic versus sympathetic based on how all of those things worked

[*Gold standard*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6141929/) *is the EKG —*

- The gold standard is a multi-lead ECG: Other devices fall broadly into a few categories: chest sensors, wrist/arm sensors, ring sensors, and finger sensors.

*Chest sensors (ECG–electrical)*: Measures the electrical activity of the heart, a form of an ECG. With appropriate software, it can give you ECG data, RR intervals, and HRV.

*Photoplethysmography (PPG)*

- PPG is much more common in terms of wearables
- PPG uses green LED lights and a light-detector to measure the changes in the size of blood vessels and turns these measurements into heart rate readings.
- Devices that use this tech is [Whoop](https://www.whoop.com/), [Fitbit](https://www.fitbit.com/global/us/home), [Polar](https://www.polar.com/blog/category/polar-news/), [Oura](https://ouraring.com/), and [Apple Watch](https://www.apple.com/shop/buy-watch/apple-watch) (The Apple Watch also has ECG that is similar to a single lead ECG)
- They’re all basically shining an LED light through the skin, and they’re measuring changes in the size of the blood vessels, and they incorporate that into an assessment or calculation of what the heart rate is, and then go from there
- So basically optical sensors are what we use today

[*Oura*](https://ouraring.com/) *stands out for its accuracy*

- \**Disclosure: Peter is an investor and advisor for Oura*

- Oura does it slightly differently as it uses an infrared PPG
- the accuracy of Oura’s compared to an EKG is very high—it’s in the high 0.9s—Meaning it is incredibly accurate compared to a standard EKG
- The reason for Oura’s superiority in measuring HRV is that it is measuring off arterials
- It’s measuring on the arterial side of the capillaries based on where it sits on the finger, whereas all the other devices mentioned are measuring on the venous side of the capillaries (typically on their wrist, so they’re measuring on veins so it doesn’t have as strong a signal there as you have on the artery side)

> “So if we’re going to use this as a tool to not just periodically check HRV, and if we want to be measuring this more frequently, it’s got to be easy and accessible.” —Peter Attia

## Interpreting your personal HRV number and why there’s so much individual variation [23:15]

Questions:

*What is a good HRV?*

*What is a bad HRV in terms of the number?*

*What’s high? What’s low? What’s optimal?*

- Peter says we don’t really *know* the answers to these questions
- If you go back to the data we discussed at the outset—if you believe that there’s a causal relationship or even a proxied relationship between HRV and the mortality numbers—**the only thing you can conclude is below 14.7 would be not good**

*What is the average HRV?*

- First of all, HRV declines with age so whenever you talk about HRV, you have to talk about it in the context of age

![](https://peterattiamd.com/wp-content/uploads/2022/01/middle-50-of-HRV-1024x931.png)

**Figure 1.** Middle 50% of HRV Values by Age.

- The upper curve is showing you where 75% of the population fall below, and the lower curve is showing you the upper limit of the 25% of the population
- In other words, the shaded area between the lower and upper is showing you the middle 50% of the values
- You’ll notice it’s actually quite a steep drop with age
  - At 20 years old, the upper portion is about 105 milliseconds, the lower portion is about 60 milliseconds, the midpoint is about 80 milliseconds
  - By the time you’re 50, that midpoint is about 40 milliseconds, the lower point is about 30 milliseconds, the upper point is about 50 milliseconds
  - And then it flattens out a bit from there

Another way to look at this is just to look at the mean and standard deviations by looking at the figure below:

![](https://peterattiamd.com/wp-content/uploads/2022/01/Normal-ranges-for-HRV-1024x862.png)

**Figure 2.** Normal ranges for HRV based on chronological age according to the study analyzing 260 healthy subjects performed by [Umetani et. al, 1998](https://www.sciencedirect.com/science/article/pii/S0735109797005548#TBL1).

- Looking at the rMSSD column, in the 10 to 19 range, it’s actually saying the mean is 53 plus or minus 17
- Though it’s slightly different than the graph above (Figure 2), it’s a little more in line with the graph when you get into upper age ranges
- For example, for a 50-year-old, we would say 25 plus or minus nine—So 25 is the arithmetic mean of the population with a standard deviation of nine
- The more helpful way to think about this is where do you stack up relative to people your age
- But again, **the most important thing to be thinking about is how do you stack up to yourself over time**

***Why does there seem to be a lot of individual variation? [26:30]***

**The role of genetics**

- The gold standard for assessing genetic influence is to look at identical twins and compare them to non-identical twins, or non-twin siblings
- When you do those types of analyses, we see that a HRV is somewhere between 40 and 50% genetic
- when you consider things that are genetic like different diseases and things like that, to have a 40 to 50% genetic contribution is actually quite strong
- A person who has always been at the 25th percentile is probably always going to be at the 25th percentile — like height, you’re not going to do a lot to change that.

**Data**

- Genetics/heritability may account for a quarter to more than half of the interindividual variation in HRV.
  - Among 427 European twin pairs and 308 Aftican-American twin pairs, it was determined that the genetic influence on HRV during stress is largely similar compared to rest ([source](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1469-8986.2009.00793.x)).
  - **Among 218 identical twins, 301 fraternal twins, and 253 non-twin siblings, genetic contribution of HRV (using RMSSD) was estimated to be 40-48%** ([source](https://www.ahajournals.org/doi/full/10.1161/01.CIR.0000146334.96820.6E)).
  - In a comparison of twins and non-twin siblings, heritability of HRV was estimated to be between 46-57% with little variation of heritability estimates for day vs night ([source](https://onlinelibrary.wiley.com/doi/abs/10.1111/psyp.12246)).
  - In a study of 282 identical and 229 fraternal twin pairs, heritability was estimated to be 47% to 64%, and more than 90% of genetic influence was estimated to be shared across different components of HRV ([source](https://www.sciencedirect.com/science/article/abs/pii/S0167876016300502)).
- **Overall**: HRV (rMSSD) appears to be more useful as a *relative* measure rather than an absolute measure.

**Tip: Don’t compare your HRV to others**

- It’s easy to get hung up on your number relative to somebody else’s
- What’s a more useful endeavor is to know that, “*Hey, over the past five years I’ve been tracking my HRV, and I know what makes it ebb and flow. And I know that when it’s low for me, I know how I can act on that*.”

## How Peter’s morning HRV reading impacts his decision to train [28:30]

**Bob asks Peter whether his HRV score from the night of sleep impacts his decision to train/exercise that day…**

Peter response:

- “*No. It definitely doesn’t influence my decision to train because I’m going to train every single day*.”
- Before there was HRV, when Peter was growing up and training really hard, he used two metrics assessed in the morning to gauge readiness for exercise
  - One was resting heart rate before you got out of bed
  - The second was willingness to exercise
- Why does “willingness to exercise” matter?
  - It turns out it matters a whole heck of a lot
  - When you are really run down, your willingness to train goes down.
  - Note: This is in highly trained individuals so someone who is not used to training a lot might not be able to utilize that metric
- “So knowing that my resting heart rate was 45 instead of 39, and that I really didn’t want to go out and train, that was probably a good reason to back down a bit, if not even potentially take a day off”
- In the present, since Peter doesn’t train nearly as much or as hard as he used to, he’s going to train regardless of what his wearable says and instead he will rely on how he’s feeling during the training session on whether to dial up or dial down the intensity

> “I think one shouldn’t ignore the subjective feeling of not wanting to exercise for a day. I think one should pay attention to that. And I’d pay slightly more attention to that than to my HRV, for sure.” —Peter Attia

## Alcohol’s impact on sleep [31:30]

**Does alcohol negatively impact sleep?**

- “*Yes, hands down*” says Peter
- However, there is some confounding data
  - Alcohol is a sedative, it’s a GABA agonist
  - It will put you to sleep quicker, you will lose consciousness more quickly, but we should never confuse a loss of consciousness with falling asleep
  - For instance, “if someone took a baseball bat to your head, you would lose consciousness. You’d be laying on the ground. You wouldn’t be moving. You might look like you’re sleeping, but there’s nothing that’s happening in your brain that mimics sleeping or the restorative nature of sleeping”
  - So we never want to confuse consciousness with sleep

**According to Matt Walker (**[**episode #49**](https://peterattiamd.com/matthewwalker3/)**), alcohol does three things to sleep**:

- 1 – It’s a sedative, so it works like sleeping pills. You might lose consciousness more quickly, but you’re not “falling asleep” faster.
- 2 – Alcohol [fragments sleep](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2775419/)
- You wake up more times during the night; oftentimes so brief that you don’t remember. But it still impacts your physiology. You’re basically vacillating between non-REM light and one-minute wake-ups while not fully awakened / conscious.
- 3 – Alcohol [blocks REM sleep](https://www.ncbi.nlm.nih.gov/pubmed/23347102)
  - You tend to wake up unrefreshed and unrestored. But it doesn’t seem to negatively impact deep sleep.

Peter personally notices that even just two drinks is enough to have this impact on his sleep—

- very little change in his deep sleep
- But his REM sleep gets very disrupted, and gets displaced by more wake-ups (that he doesn’t necessarily perceive)
- And he ends up with more light sleep (Stage one and stage two)

**Mechanism of sleep disruption**

- It’s not clear what the mechanism of action is but it’s been speculated that it might be the aldehydes which is a byproduct of ethanol metabolism
- Matt Walker writes in his [book](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316): “*When the body metabolizes alcohol it produces by-product chemicals called aldehydes and ketones. The aldehydes in particular will block the brain’s ability to generate REM sleep*.”
- 2015 study writes: Alcohol-induced reduction in glutamate has been implicated in alcohol-induced suppression of REM sleep [in rats] ([Prospero-García et al., 1994](https://www.dropbox.com/s/a8kh2rr3vov0jxk/%23prospero-garcia%20%231994%20Pharmacology%20of%20ethanol%20and%20glutamate%20antagonists%20on%20rodent%20sleep-%20a%20comparative%20study.pdf?dl=0)).

**In summary**:

- Alcohol is reducing REM sleep
- It’s not having much of an effect on deep sleep and in some cases it can actually slightly increase deep sleep
- It can definitely reduce sleep latency so you can fall asleep quicker
- But overall reduces the quality of sleep (which has implications for disease)

## Metrics to track the impact of alcohol on your sleep [34:00]

**How alcohol affects Peter’s sleep**:

In Peter personally, alcohol will impact the four biometric parameters:

- resting heart rate
- heart rate variability
- respiratory rate
- body temperature

Note that it’s a function of i) how much you drink and ii) when you drink in relation to sleep

- For example, a single drink, four or five hours before bed really doesn’t have an effect on Peter
- But after two drinks, he’ll start to see a deterioration in sleep
- And the closer those drinks are to bedtime, the more impact it will have

So two drinks close to bedtime will have the following impact on Peter:

- Resting heart rate really go up easily 6-8 beats per minute
- Heart rate variability will be dramatically compressed at a minimum 20-25%, and even up to 50% if that alcohol is close to bed
- respiratory rate goes up by about 2 breaths per minute
- body temperature will go up by 0.3-0.6 °F

Side not about food:

- Food has a thermogenic effect
- For Peter, the more closely he’s eating to bedtime will drive his body temperature up

**Why do these metrics matter? [36:00]**

> “It just seems to me that all of these things are suggestive of more sympathetic tone, and that’s the underlying issue.” —Peter Attia

-An increase in HR, for example, may just be a marker for the issue, which is more sympathetic tone

-And in the case of the REM sleep fragmentation and the frequent awakenings, it’s also a problem that you’re just not sleeping as much

- You need your HR to decrease during sleep
- You need to drop your core body temp. By 2-3 °F to initiate sleep
- With raised HR and raised core body temp., you get more fragmented sleep, more awakenings, and disruption of REM sleep
- Note: it might be difficult to tease out chicken or egg here: elevated RHR can be an indicator of other health problems (sleep apnea, anxiety, etc.) but not a problem in and of itself. And fragmented sleep may drive overnight increases in HR and body temp.

**Peter’s cooling device –** [**Eight Sleep**](https://www.eightsleep.com/) **[37:00]**

- Peter uses a cooling device for sleeping
- He sets the device to mirror what his body should be doing
- “*So when I get in bed, it goes down a little bit, and then I really drop the temperature two hours after I go to sleep, and then I keep it really low, and then I bring the temperature up an hour before I wake up*.”

*-Did you track before and after when you started implementing cooling systems with sleep, as far as improvement?*

- Peter says yes, it’s very noticeable
- There were several days when he didn’t use it and his metrics demonstrated the difference
- “I mean, it was just miserable sleep”

## Alcohol’s impact on the need to urinate during the night [39:00]

***Does alcohol lead to more bathroom breaks overnight?***

Yes, for 2 reasons:

- 1) it’s a liquid so if you’re drinking a liquid before bed, whether it be water or alcohol, you have more glomerular filtration
- 2) But the real sinister problem with alcohol is that it inhibits a hormone called vasopressin, which is the antidiuretic hormone
  - So if you inhibit the antidiuretic hormone, you are creating a diuretic effect

Strategies to help with nocturia (nighttime urination)

- Vasopressin
  - If Peter drinks too much too close to bed, he will actually take a low dose of [vasopressin](https://www.drugs.com/mtm/vasopressin.html) to offset that effect and “it will works comically well” where he barely has to pee when he wakes up in the morning
  - Note that you should not be doing this without a doctor knowing what you’re doing because you can also develop [hyponatremia](https://en.wikipedia.org/wiki/Hyponatremia)
  - Although in the doses and quantities that we talk about it, it’s probably impossible, but you want to be sure that someone knows what your sodium levels are and things like that.
- Limiting liquid consumption at night
  - Peter suggests to patients they keep a journal
  - When did you drink, and how much did you drink, and when did you pee?
  - And if you can really get technical, how much did you pee?
  - The general rule of thumb is if someone is really struggling with nocturia, don’t drink anything for four hours before bed so you’re deliberately dehydrating yourself a little bit before bed.

## Alcoholic fatty liver disease (AFLD) [41:30]

**How do you determine if the patient has fatty liver and whether it’s in response to ethanol or fructose?**

- There’s nothing that histologically or certainly radiographically is going to tell you if they have fatty liver disease, it’s from alcohol versus non-alcohol
- AFLD, alcoholic fatty liver disease
- NAFLD, non-alcoholic fatty liver disease
  - Fructose is probably the single most important driver of NAFLD
- Clues to look at:
  - The first clue we look at is the liver function tests. It’s kind of a misnomer. They’re not really markers of liver function
  - Alanine aminotransferase or ALT is probably our most sensitive reference
    - anytime that number is over about 25 or 30, even though a normal range would be up to 45 or 55, Peter’s trying to get more insight into why
    - there’s lots of other things that can increase it—medications, statins like ezetimibe very commonly raise those transaminases from
- For someone who starts out with a 20 can easily go to a 30
  - You just have to really take a clear history of how much is that person drinking — Peter always ask how many drinks they have per week
- Finally, if you want to confirm your suspicion of fatty liver, you will do an ultrasound

*Is there a cumulative effect of ethanol and fructose?*

- *In other words…*if somebody does consume alcohol and they’re not going to reduce their alcohol consumption, all things equal, does it make more sense for that person to restrict fructose?
- Or even vice versa: So somebody who consumes a lot of fructose in their diet, maybe they should dial back the ethanol since both might contribute to fatty liver.
- “I can’t tell you off the top of my head that I’ve seen data to tell me that that is the case, but boy, I’d be shocked if it wasn’t.” says Peter

## Individual differences in the way people metabolize and react to alcohol consumption [44:15]

**Let’s talk about two different things…**

*-First, is there a genetic difference between individuals in terms of alcohol consumption and alcohol metabolism?*

- “No question. That’s a given.”
- The most obvious of that is people, and it’s almost always Asians, who have a deficiency of an enzyme called aldehyde dehydrogenase
- They have certain alterations in coding regions for genes that produce that enzyme which is very important for metabolizing ethanol
- The SNPs are in the [ALDH2 gene](https://en.wikipedia.org/wiki/ALDH2), and they cause a huge reduction in this enzyme’s activity
- If your heterozygous, you have mild symptoms
- Homozygotes, meaning people who have two copies of this, usually can’t tolerate a single drink
- So that’s a pretty clear genetic extreme example
- As an aside, there’s a drug that goes by the name Antabuse that inhibits that enzyme, and it’s can basically mimic the effect of having that genetic variant
  - In other words, if let’s just assume you have normal alcohol tolerance, if you took Antabuse, you would feel it just the way someone does who is homozygous

*-Secondly, tolerance seems to go down as we age*

- College person having 10 drinks feels different than a middle aged person having the same, generally speaking

**Individual differences in how alcohol affects sleep**

- Peter suspects there are genetic differences here
- We know for example, that we have very different metabolisms, genetically, for caffeine
- That is also likely true in alcohol
  - Matt Walker confirms this observation (in [episode #126](https://peterattiamd.com/matthewwalker4/)) — if you do some of the genetic testing you can see that some people are fast metabolizers of alcohol (same with caffeine)
- There are different rates of alcohol metabolism that are genetic and it might be that those faster metabolizers are less impacted by the effect of alcohol on sleep
  - if you took two people, one is a fast metabolizer, one is a slow metabolizer. They both have three drinks, four hours before bed
  - One of them might be feeling the effects of all of that when they go to sleep, if they’re a slow metabolizer, the other might not be
  - Peter’s unsure what of the genetic SNPs that are responsible, so it’s probably something you just have figured out empirically as an individual

***Would somebody who has developed a higher tolerance for alcohol through frequent consumption be able to metabolize it faster than they would if they hadn’t developed tolerance? [47:30]***

- There’s some [evidence](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5479325/) to suggest that chronic heavy drinkers (1–5 days weekly consumption of ≥5 drinks per occasion for men, ≥ 4 for women) absorb and metabolize alcohol faster than light drinkers (weekly drinkers who averaged consuming <6 drinks per week)
- So it may be possible that habitual consumption of alcohol may lead to a faster metabolism of alcohol may lessen some of the interference with sleep
- **Take home message**: There is a difference in absorption and metabolism for alcohol. So the more you drink, the better you get at drinking.

Food and food composition affects alcohol metabolism through effects on absorption rate and elimination rate

- High-carb meal before alcohol intake appears to reduce peak BAL relative to a high-protein meal → likely the result of differences in absorption rather than elimination rate
- When alcohol was administered IV (to isolate elimination from absorption), no differences in [rate of alcohol elimination](https://accp1.onlinelibrary.wiley.com/doi/epdf/10.1177/00912700122012814) were identified between subjects who had consumed either a high-carb, high-protein, or high-fat meal of equal caloric value, but all groups that had consumed a meal exhibited faster elimination rates than those who had undergone a 12-hour fast
- Anecdotally, some people who are on ketogenic diets say that they’re much more sensitive to alcohol
  - So someone who has been on a ketogenic diet for five months has a drink and will actually feel the effect of that
  - It might be that the liver ketogenic diet is doing a lot of glucogenesis and ketogenesis
  - And there’s some data that suggests that alcohol consumption will inhibit glucogenesis, and that’s sometimes why you see low blood sugar in somebody who is drinking
  - What’s possible is the liver is going to start to metabolize the alcohol to acetate and the brain can also use acetate for fuel.
  - A 2021 study shows that it may be that there’s more acetate around and it’s hitting the brain, and these people speculated that some of that acetate metabolism may be what’s causing some of the inebriation in the brain
  - So if there’s more acetate metabolism going on. And if you have lower blood sugar, then the brain is going to rely on what ketones and glucose, but the glucose is lowered because the glucogenesis is inhibited, so it might be relying more on byproducts of alcohol metabolism
  - Relatively speaking, maybe you feel more tipsy on a ketogenic diet, but something to maybe look into

## Analysis of epidemiology studies suggesting moderate alcohol consumption lowers mortality risk [52:00]

**What about the epidemiology that suggests moderate alcohol consumption lowers mortality?**

Peter’s initial response: “*The short answer is there are some epidemiologic studies to suggest this, but they have to be scrutinized pretty heavily*.”

*What is a standard drink?*

- Each beverage below = 14 g alcohol = “standard drink” in the US
  - 12 oz regular (5%) beer
  - 8-9 oz stronger (7%) beer
  - 5 oz table wine
  - 1.5 oz shot of 80-proof distilled spirits (rum, whiskey, vodka, gin, tequila, etc)
- You got to keep in mind, if you’re pouring your own drink, you’re almost drinking more than 14 g (unless you’re drinking beer out of a can)

*Drinking levels defined in epidemiology studies*:

- Moderate drinker: ≤14 drinks/wk and ≤4 drinks on any day for men; ≤7 & ≤3 for women
- Heavy drinker: >14 drinks/wk or >4 drinks on any day for men; >7 & >3 for women
- Former drinker: Stopped drinking alcohol
- Never drinker: Never had a drink (sometimes defined as <12 drinks in lifetime)
- Note: the definitions can vary from study to study.

*Inconsistent findings*

- Many observational studies investigating the association between alcohol consumption and all-cause mortality (ACM), with inconsistent findings.
- A majority of studies found a J-shaped relationship ([Castelnuovo et al., 2006](https://jamanetwork.com/journals/jamainternalmedicine/article-abstract/769554); [Ronksley et al., 2011](https://www.bmj.com/content/bmj/342/bmj.d671.full.pdf); [Bergmann et al., 2014](https://academic.oup.com/ije/article/42/6/1772/737628)).
  - J-curve means if you start on the left, moving to the right on the X axis…
    - The left is the zero drinking
    - And as you move to the right, you’re adding drinks, and superimpose on that a J. And the J is mortality.
    - So the nadir of mortality is not at the furthest left end of the graph
    - In other words, this is not a line that rises monotonically from the left to the right suggesting that there’s actually a benefit to some alcohol relative to no alcohol
  - What would possibly explain why there would be a slight reduction in all-cause mortality from these studies?
    - There are probably in the last 20 years, you’ve got maybe three or four studies that suggest that there is some benefit, and then you have others that find no benefit
    - So I think you have to look at these studies individually and understand the methodology.
- Other studies reported a nonsignificant association ([Stockwell et al., 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4803651/); [Knott et al., 2015](https://www.bmj.com/content/350/bmj.h384)).
- But most older cohort studies were subject to methodological issues

**Methodological issues**

- First of all, all of these are observational studies based on recall meaning there are no randomized control trials
- Secondly, another problem is the selection bias in these studies
  - For example, when they look at just baseline characteristics of these people, the people who are moderate drinkers tend to be healthier by the metrics that we use to measure health compared to the never drinkers and heavy drinkers
  - Additionally, the moderate drinkers have a higher socioeconomic status—higher education, higher income, more likely to exercise, more likely to eat a few fruits and vegetables
  - Never drinkers and the former drinkers that tend to be in a lower economic bracket, lower education, tend to have higher obesity, higher BMI, tend to of smoke more, etc.
- So there’s a lot of things that can confound the data going both ways.

Peter’s thoughts:

- “*It’s very difficult for me to believe that some alcohol is better than none. It’s possible that some alcohol is no worse than none in a healthy enough individual*.”
- Peter also points out that the cohorts are older people so a “survivorship bias” occurs in these studies
  - So to study a group of 30 and 40-year-olds, when you’re trying to understand mortality is going to be a pretty uninteresting study
  - So you’ve taken out people who are the least healthy by the time you’re studying people in their sixties
  - More on this bias…
    - A number of drinkers progress from light or moderate to heavy drinking over the years.
      - Selection bias due to premature death: If we later enroll that whole population — never drinkers, light drinkers, moderate drinkers, heavy drinkers — in a study starting at age 40 or 50, many remaining moderate drinkers will be the group that remained moderate drinkers their entire lives. Most others will either be a never-drinker or a heavy drinker—or, unfortunately, they’ll be dead. [More than one-third of all deaths from alcohol occur before age 50](https://www.medicalnewstoday.com/articles/324552#A-fresh-approach). When people enroll in these cohort studies at age 50, people <50 who die from alcohol have already been picked off. Because of premature mortality, alcohol-mortality associations based on cohort studies may underestimate negative health consequences compared with those observed among the general population.
- And of course it can’t be overstated that a lot of the people who do not drink anymore are not drinking for a reason (“sick quitter” bias — i.e., they have illnesses that have stopped them drinking)
- So again, when you put all of that together, there’s really only one study that I find very helpful

**Study that tried to control for the “unhealthy unuser bias” in drinking studies:**

**BMJ study (**[**Bell et al., 2017**](https://www.bmj.com/content/356/bmj.j909)**)**

- In over a million participants separated out those who had drank previously from those who had never drank (i.e., never-drinkers), looking at outcomes (6y follow-up), and adjusted for age, sex, socioeconomic status, and smoking status (in the case of hazard ratios).
- The hypothesis was that the former drinkers likely quit because they had to for health reasons compared to people who have never had a drink
- The key things the study looked at were all-cause mortality and cardiovascular death

**Results** (note that they adjusted for age, sex, socioeconomic status, and smoking status, in the case of the hazard ratios)

- All-cause mortality (ACM) vs moderate drinking:
  - Hazard ratios (HRs) for all-cause mortality vs moderate drinking:
    - Never-drinkers = 1.24 (95% CI, 1.20-1.28)
      - Suggests moderate drinking is associated with longevity or less likely to die
    - Former drinker = 1.38 (95% CI, 1.30-1.47)
      - Suggests that if we just take it at face value, that it seems like the former drinkers might be at higher risk than the people who never drink
  - Crude absolute risks (ARs) for all-cause mortality:
    - 5.9% (70,074/1,195,351) AR in moderate drinker
    - 11.0% (30,553/277,042) AR in never-drinker
    - 9.6% (6,877/71,682) AR in former drinker
- CVD death vs moderate drinking:
  - HRs for CVD death vs moderate drinking:
    - Never-drinker = 1.32 (95% CI, 1.27-1.38)
    - Former drinker = 1.44 (95% CI, 1.28-1.62)
  - Crude ARs for CVD death:
    - 1.1% (13,527/1,195,351) AR in moderate drinker
    - 2.3% (6,272/277,042) AR in never-drinker
    - 1.9% (1,365/71,682) AR in former drinker

![](https://peterattiamd.com/wp-content/uploads/2022/01/f3-ama31-1024x479.png)

**Figure 3.** Credit: [Bell et al., 2017](https://www.bmj.com/content/356/bmj.j909)

> “*I think there’s zero chance that these investigators have been able to even remotely strip out the confounders here*.” —Peter on the 2017 study above

Bob thoughts on the 2017 study:

- “*You look at the moderate drinkers versus the former drinkers or never drinkers, and they tended to be younger, less likely to be socioeconomically deprived. Smoking, that was a little more mixed, but moderate obesity, morbid obesity, again higher in the non-drinkers and former drinkers. Diabetes, the rates were almost, I think it was triple, more likely to abuse drugs. Anti-hypertensive drugs or statins in the former drinkers or never drinkers. So all these suggest that these people are unhealthier. And then what these studies try to do is they try to adjust for all these things.*
- *If you’re taking all these different variables and trying to throw them into this mixer, and then you come up with your hazard ratios. Now you’re looking at this almost estimation of people in each of these groups, and you’re trying to control for so many variables. It’s very difficult, at least for me to conclude that this is an accurate representation in each one of these groups*.”

## Alcohol consumption and Alzheimer’s disease [1:05:15]

**Rotterdam** [**Study**](https://pubmed.ncbi.nlm.nih.gov/11830193/)

*Disclaimer #1*: The epi on alcohol consumption and AD is quite heterogeneous: different study designs (cross-sectional studies, cohort studies, case–control studies), inclusion criteria, alcohol dosage standardization and dosage definitions, type of alcoholic beverages included, endpoints (only AD or all forms of dementia, MCI), and consumption patterns. These limitations apply to the epi on ACM/CVD as well.

*Disclaimer #2*: The limitations and biases discussed above on alcohol and CVD/ACM apply here, too

> “*So when you take all of that coupled with all of the problems associated with epidemiology and the confounders, I don’t find this study remotely convincing*.” —Peter Attia on the Rotterdam study

**What this study is and what it found**:

*-Design and results overview*

- A large cohort (nearly 8,000 individuals)
- 6y follow-up
- Elderly patients (over 55 years old, mean ~67),
- Moderate drinking was defined as 1–3 drinks per day (no definition of grams of alcohol)
- Resulted in a significant risk reduction for any form of dementia, especially vascular dementia, with an average follow-up period of six years *compared to never drinkers*.
- The analysis was adjusted for age, sex, systolic blood pressure, education, smoking, and body-mass index.
  - NOTE: They didn’t adjust for exercise or nutrition habits

*-More detail*

- Overall, 197 individuals developed dementia (146 Alzheimer’s disease, 29 vascular dementia, 22 other dementia).
- Hazard ratios in light-to-moderate drinking (1-3 drinks per day) vs never drinker:
  - Any dementia: 0.58 (95% CI, 0.38-0.90)
    - I.e., 42% reduction
  - Vascular dementia: 0.30 (95% CI, 0.10-0.92)
    - I.e., 70% reduction – meaning 1-3 drinks is going to LOWER your odds of vascular dementia vs. never drinking
- Crude ARs:
  - Dementia: 2.6% (38/1,443) AR in 1-3 drinks/d vs 5.6% (62/1,113) AR in never drinkers
  - There were a total 29 vascular dementia events across all participants, but no info on events per group

*-Overall*: Similar to the [BMJ study](https://www.bmj.com/content/356/bmj.j909), light to moderate drinking versus never drinking looks like on the surface that it lowers the risk of dementia and vascular dementia

## Heavy alcohol consumption and risk of dementia [1:08:30]

[**Study**](https://academic.oup.com/biomedgerontology/article/70/10/1248/2605482) **from Sweden**

–*Overview*:

An analysis from one of the largest **twin** cohorts worldwide (12,326 participants) with over 43 years of follow-up

Reminder:

- ​​This study was explained in terms of grams
- A properly poured drink is 14 grams of alcohol.
- If you look at it that way, we defined people as following
  - light drinkers were defined as 1-5 g per day
    - A single drink is about 15 grams per day
    - So these are people drinking on the order of two properly poured drinks a week
  - Moderate to heavy was defined as somewhere between 5-12 g per day
  - Heavy was 12 to 24 g per day
- In other words, at the low end someone who is two and a half drinks per week, all the way to the high end to somebody who is probably at 20 drinks per week
  - Those are our two groups

*Comparing what’s happening between twins – What did the study find?*

- The drinking twins had a higher risk of dementia by 57%
  - In other words, people who were drinking more than two and a half drinks per week, relative to those less than two and a half drinks per week had a greater risk of dementia by 57%
  - And you saw a reduced onset of dementia by 4.76 years, so dementia was coming on almost five years sooner
- Interestingly, the total abstainers were not different from the light drinkers
  - So not drinking anything versus having two and a half, three drinks a week, there’s no difference there
- But once you tick up from three drinks per week, there seem to be this increase
- So *does that mean having five drinks per week comes with this risk*?
  - No. Because these buckets are so large — Someone is going to barely make their way into this group if they’re having four drinks per week, but it’s also going to be someone who is having 20 drinks per week
  - “*So if I’m going to be critical of this study, that’s certainly another thing I’ll be critical of*.” says Peter

*What about monozygotic (identical) twins vs dizygotic (fraternal) twins?*

- 576 of the twins in the study were monozygotic twins
- When they compared results separating the type of twin, *what did they find?*
  - When looking at just monozygotic twins, the moderate-to-heavy drinkers had 3x the risk for dementia versus light drinkers
  - So the light drinkers, the people drinking less than two and a half to three drinks per week had about a 3X lower risk of dementia relative to people drinking somewhere between, call it, I don’t know, three and 20 drinks a week
  - We still saw no difference between non-drinkers and the light drinkers. There was no difference whatsoever

***Peter’s overall take on AD and alcohol based on this epidemiology:***

*Why is Peter being so vocal in his disdain for the body of literature suggesting that some alcohol is better for you than none?*

- “*I just have a really hard time believing that ethanol, which is frankly, a very toxic molecule is beneficial*.” says Peter
- There’s probably some exceptions to this…it’s quite likely that for some people, a little bit of alcohol might even have a counterbalancing effect on cortisol and stress and therefore offset the damage of the ethanol
  - But it doesn’t mean that ethanol isn’t necessarily harmful — it’s a toxin, but at a low enough dose, maybe it doesn’t really pose much of an issue
- If a randomized controlled study was done, Peter’s intuition is that it would NOT be a straight line starting at zero and going up. Rather, he thinks it would be a flat line for a while that then kicks up and kicks up non-linearly
- *Why does Peter think that?* — Let’s look at Tylenol
  - Tylenol is like alcohol, a very hepatotoxic molecule, and it doesn’t come with the central effects of alcohol, but in the liver, at least, it’s very similar
  - Peter’s not aware of any evidence that suggests taking a low dose of Tylenol intermittently is harmful, but clearly taking lots of Tylenol acutely is harmful
  - But more importantly, chronically taking Tylenol can be harmful as well, if you’re taking it in the level of four grams a day, every day

–*There are a couple of things that are worth pointing out*…

- Especially in The Rotterdam Study—the study that makes the strongest case for drinking…
- The legal drinking age for alcohol in the Netherlands is currently 18, but in 2014 it was age 16
- Culturally, this suggests the culture is one that probably drinks quite responsibly, a culture that doesn’t have a lot of problems with excessive alcohol consumption, and this is probably a culture where alcohol is integrated into every aspect of life
- Therefore not drinking alcohol is probably a marker for something odd
- It’s probably like not having a sauna in Finland, meaning there’s likely something fundamentally different about the person who lives in Finland and doesn’t sauna (or lives in Rotterdam and doesn’t drink)

> “*My takeaway for this is if alcohol brings you great pleasure and there’s no maladaptive negative in your life, it’s probably a wash to have some alcohol versus to have none. If alcohol is a maladaptive coping strategy for you, then I think abstinence does make a ton of sense*.” —Peter Attia

## Chronic effects of alcohol on the liver [1:17:45]

**When looking at the epi data suggesting moderate drinking is potentially better than no drinking, this could create an issue with the public health messaging**:

- So, we’re talking about the consumption of alcohol, all-cause mortality and all these problems and we’re looking at groups and we’re saying moderate drinking is better than never drinking at all
- As a public health figure, you might run into this issue of telling a population of people who have never touched alcohol to start drinking moderately when almost assuredly there is going to be some proportion of those people that are going to go on to drink beyond moderately, and they’re going to run into some problems especially when there are a lot of problems with the way these studies are designed

**Chronic effects of alcohol on the liver**

-Peter had [Chris Sonneday](https://twitter.com/hpb_txp_surg?lang=en) on the [podcast](https://peterattiamd.com/chrissonnenday/) in the past…

- Chris talked about how we’re actually seeing a rise in alcoholic liver disease, AFLD, as a cause for cellular carcinoma and/or liver transplant.
- The story about NAFLD being on the rise is well understood. It’s gone up by more than 2X in the last decade.
- But what’s almost not noticed is that the same is true for alcohol.
- So in 2010, alcoholic liver disease was accounting for 13% of liver transplants in the United States while non-alcoholic liver disease was 9%.
- In the last year for which we have data (2019), alcoholic liver disease is up to 29% while NAFLD is up to 22%.
- The big success story here is that Hepatitis C has been crushed. It’s gone from 45% to 19%. And that’s going to go down as time goes on, as we now have an effective treatment for Hep C.
- NAFLD was really poised to be the leading indication for a liver transplant in the United States, and now it’s slightly behind alcoholic liver disease
- Peter says it will be very interesting to note how these data change post COVID… “*I would bet that alcoholic liver disease would’ve risen disproportionately to NAFLD in the presence of COVID.*”

![](https://peterattiamd.com/wp-content/uploads/2022/01/f4-ama31-1024x351.png)

**Figure 4.** Causes of liver disease and HCC among adult liver transplant recipients in the U.S. in 2010 & 2019. Credit: [Wang et al., 2020](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0239393)

## The relationship between alcohol, sleep, and automotive deaths [1:20:45]

⇒ Peter wrote a [Sunday newsletter](https://peterattiamd.com/the-killers-on-the-road-reducing-your-risk-of-automotive-death/) on accidental death due to transport

- Primary conditions that lead to fatalities are: alcohol, speeding, and distraction leading to a loss of control or contact with another vehicle.
- In the cases where drivers are killed on freeways…
  - 31% of them have alcohol in their system
  - and nearly 85% of these drivers were over the legal limit of 0.08 g/dL.
- But also think about the negative effects alcohol has on **sleep quality**, which could also increase the probability of driver error.
  - When you understand how much poor sleep contributes to drowsy driving, which contributes to accidents, how much of that poor sleep could be underpinned by alcohol?
  - “*I don’t think we’ll ever know that, but it would suggest to me that this number of 31% and 85%, or 31% rather represents the floor to what this looks like*.”

Question for Peter: *Have you ever tried to test the effects of alcohol on your racing simulator performance?*

- Peter has a racing simulator and he works with a coach pretty frequently
- “*If I’m going to get in the simulator, I can’t have a glass of wine, zero chance. And even though that doesn’t put me anywhere near the legal limit of alcohol, and nor do I even perceive that anything is wrong*”
- Peter may have a blood alcohol of less than half the legal limit — probably at 0.02 to 0.03 where the legal limit is 0.08
- Even so, his reaction time is down and his spatial awareness is down
- This begs the question of the choice to have a glass or wine at dinner before driving home
- *Am I legally entitled to do that?* Absolutely
- *Do I have any perception that I’ve had anything to drink?* No.
- But at least in the really high stakes environment of being in a race car or in a simulator, that’s simulating a race car, my performance suffers

> “*Most of the time when you’re driving, you don’t need to be at the level of a race car driver, but if something goes wrong, you probably need the reaction time and wherewithal to manage something that’s sudden and potentially catastrophic*.” —Peter Attia

§

## Selected Links / Related Material

**The ARIC study looking at the association between low HRV and mortality risk**: [Low Heart Rate Variability in a 2-Minute Rhythm Strip Predicts Risk of Coronary Heart Disease and Mortality From Several Causes](https://www.ahajournals.org/doi/10.1161/01.CIR.102.11.1239) (Dekker et al., 2000) [10:30]

**2013 meta-analysis looking at the association between low HRV, cardiovascular risk and mortality risk**: [Heart rate variability and first cardiovascular event in populations without known cardiovascular disease: meta-analysis and dose–response meta-regression](https://academic.oup.com/europace/article/15/5/742/673395) (Hillebrand et al., 2013) [12:30]

**Wearables that track HRV**: [21:00]

- [Whoop](https://www.whoop.com/)
- [Fitbit](https://www.fitbit.com/global/us/home)
- [Polar](https://www.polar.com/blog/category/polar-news/)
- [Oura](https://ouraring.com/)
- [Apple Watch](https://www.apple.com/shop/buy-watch/apple-watch)

**Episode of The Drive where Matt Walker talks about the impact of alcohol on sleep**: [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/) | Peter Attia (peterattiamd.com) [32:30]

- Alcohol [fragments sleep](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2775419/)
- Alcohol [blocks REM sleep](https://www.ncbi.nlm.nih.gov/pubmed/23347102)

**Matt Walker’s book**: [Why We Sleep: Unlocking the Power of Sleep and Dreams](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316) by Matthew Walker (amazon.com) [33:30]

**Study in rats showing alcohol-induced reduction in glutamate has been implicated in alcohol-induced suppression of REM sleepAnother study found in rats**: [Pharmacology of Ethanol and Glutamate Antagonists on Rodent Sleep: A Comparative Study](https://www.sciencedirect.com/science/article/abs/pii/0091305794904421) (Prospero-García et al., 1994) [33:30]

**Cooling device Peter uses while sleeping**: [**Eight Sleep**](https://www.eightsleep.com/) | (eightsleep.com) [37:45]

**Evidence to suggest that chronic heavy drinkers absorb and metabolize alcohol faster than light drinkers**: [Alcohol-induced performance impairment: a 5-year re-examination study in heavy and light drinkers](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5479325/) (Brumback et al., 2018) [47:45]

**Study that tried to control for the “unhealthy unuser bias” in drinking studies looking at all-cause mortality**: [Association between clinically recorded alcohol consumption and initial presentation of 12 cardiovascular diseases: population based cohort study using linked health records](https://www.bmj.com/content/356/bmj.j909) (Bell et al., 2017) [1:00:30]

**Rotterdam study looking at alcohol consumption and Alzheimer’s disease**: [Alcohol consumption and risk of dementia: the Rotterdam Study](https://pubmed.ncbi.nlm.nih.gov/11830193/) (Ruitenberg et al., 2002) [1:05:15]

**Study from Sweden looking at twins and heavy alcohol consumption and risk of dementia**: [Midlife Alcohol Consumption and Risk of Dementia Over 43 Years of Follow-Up: A Population-Based Study From the Swedish Twin Registry](https://academic.oup.com/biomedgerontology/article/70/10/1248/2605482) (Handing et al., 2015) [1:08:25]

**Chris Sonnenday episode of The Drive**: [#155 – Chris Sonnenday, M.D.: The history, challenges, and gift of organ transplantation](https://peterattiamd.com/chrissonnenday/) | Peter Attia (peterattiamd.com) [1:19:00]

**Peter’s Sunday newsletter on accidental automotive deaths**: [The killer(s) on the road: reducing your risk of automotive death](https://peterattiamd.com/the-killers-on-the-road-reducing-your-risk-of-automotive-death/) | Peter Attia (peterattiamd.com) [1:20:45]

§

## People Mentioned

- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) [16:30]
- [Matt Walker](https://en.wikipedia.org/wiki/Matthew_Walker_(scientist)) [32:30]
- [Rob Lustig](https://en.wikipedia.org/wiki/Robert_Lustig) [43:45]
- [Winston Churchill](https://en.wikipedia.org/wiki/Winston_Churchill) [48:40]
- [Chris Sonnenday](https://www.uofmhealth.org/profile/1426/christopher-john-sonnenday-md) [1:19:00]

§