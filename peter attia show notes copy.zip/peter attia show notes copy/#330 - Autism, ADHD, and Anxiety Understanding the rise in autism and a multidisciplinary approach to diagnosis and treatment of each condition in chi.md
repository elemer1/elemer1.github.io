# #330 – Autism, ADHD, and Anxiety: Understanding the rise in autism and a multidisciplinary approach to diagnosis and treatment of each condition in children | Trenna Sutcliffe, M.D.

**Source:** [https://peterattiamd.com/trennasutcliffe/](https://peterattiamd.com/trennasutcliffe/)

---

Trenna Sutcliffe is a developmental behavioral pediatrician and the founder and medical director of the Sutcliffe Clinic in the San Francisco Bay Area, where she partners with families to provide care for children facing behavioral challenges, developmental differences, and school struggles. In this episode, Trenna shares her journey into developmental and behavioral pediatrics, including her pioneering work at Stanford and her expertise in autism, ADHD, and anxiety—the “three As.” She explores the diagnostic processes, the overlap and comorbidities of these conditions, and the importance of personalized treatment plans that address both medical and environmental factors. Trenna offers valuable insights into the changing prevalence of autism, the impact of evolving diagnostic criteria, and the range of therapies and medications available to support children and their families. She also discusses the challenges in accessing care and the critical need for a holistic approach that bridges healthcare and education.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/trennasutcliffe/the_Drive_public.png)

Play

#330 – Autism, ADHD, and Anxiety: Understanding the rise in autism and a multidisciplinary approach to diagnosis and treatment of each condition in children | Trenna Sutcliffe, M.D.

#330 – Autism, ADHD, and Anxiety: Understanding the rise in autism and a multidisciplinary approach to diagnosis and treatment of each condition in children | Trenna Sutcliffe, M.D.

1x15s30s

0:001:57:14

## We discuss:

- Trenna’s passion for developmental-behavioral pediatrics (DBP), and the process of diagnosing anxiety, ADHD, and autism [3:15];
- Understanding anxiety and ADHD: assessing impairment and self-esteem and identifying anxiety and emotional well-being in young patients [9:45];
- The evolving diagnosis of autism: understanding the spectrum and individual needs [16:30];
- The dramatic rise in autism spectrum disorder (ASD): genetics, environment, expanded diagnostic criteria, and more [25:45];
- Exploring epigenetics and the potential multigenerational impact of environment exposures on susceptibility to certain disorders [37:15];
- The evolution of autism classifications, and the particular challenges for children with level 1 (mild) autism due to a lack of support [41:15];
- The broadening of the autism spectrum: benefits and risks of expanded diagnostic criteria and the need for future frameworks to focus on better outcomes [48:00];
- The overlap between ASD, ADHD, and anxiety [57:15];
- Understanding oppositional defiant disorder, and the importance of understanding the “why” behind a behavior when creating treatment plans [1:00:45];
- Defining developmental-behavioral pediatrics (DBP), and Trenna’s professional journey [1:07:00];
- Updated methods of ABA (applied behavioral analysis) therapy: evolution, controversies, challenges of scaling autism care, and the need for tailored interventions [1:13:45];
- Advice for parents trying to find and evaluate care for children with autism, ADHD, or anxiety [1:22:45];
- Tailored treatments for ADHD: balancing stimulant medications with behavioral training [1:28:30];
- The interplay between medication, behavioral therapy, and neuroplasticity in managing ADHD, and the potential to grow out of the need for medication [1:39:45];
- Using medication to treat anxiety and other symptoms in kids with autism without ADHD [1:44:45];
- FAQs about medicating children with ADHD: benefits, side effects, dosage, and more [1:46:30];
- The “superpowers” associated with level 1 autism [1:48:45];
- The next steps to increase support for children with ASD, anxiety, and ADHD [1:50:45]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Trenna Sutcliffe is a developmental-behavioral pediatrician and the founder and medical director of [The Sutcliffe Clinic](https://www.sutcliffeclinic.com/) in the Bay Area
  - Which partners with patients and their families to evaluate and provide supportive care for children dealing with issues such as behavioral changes, developmental differences, and school struggles
- In this conversation, we explore her journey into developmental and behavioral pediatrics
  - She was the first person to be practicing under this designation at Stanford when she arrived about 20 years ago
  - This includes her background in genetics, pediatric neurology, and her current work in leading multidisciplinary teams around the care of children with autism, ADHD, and anxiety
- We spoke about the diagnostic processes for autism, ADHD, and anxiety (which she calls the 3 A’s)
  - Discussing how these behavioral diagnoses are made based on clinical traits and the criteria depending on the age of the child
- We focus on the overlap between the 3 A’s and how comorbidities are common in children with each of these conditions
- Trenna emphasizes the importance of a personalized treatment plan to consider the whole child, including their environment at home and at school
- We talk about the change in diagnostic criteria for autism between the DMS-4 and the DSM-5
- And what some of the drivers might be for the increase in the prevalence of autism today
  - This is a very hotly discussed topic
  - Trenna provides a very thorough discussion of what the factors are that may be contributing to this
- We discuss various therapies including
  - Applied behavioral analysis (ABA) for autism
  - Behavioral interventions and parental training for ADHD
  - Pharmacologic options for ADHD and anxiety, including the use of stimulants, non-stimulants, and SSRIs
  - Trenna explains how these medications are used alongside behavioral interventions to help children manage symptoms and improve their daily lives
- We talk about the challenges families face in accessing care, particularly outside of major urban areas
- And the importance of bridging healthcare and education to create a more holistic approach to support children with these developmental conditions

## Trenna’s passion for developmental-behavioral pediatrics (DBP), and the process of diagnosing anxiety, ADHD, and autism [3:15]

- Trenna did her undergrad and master’s degree in genetics, then went on to medical school
- After medical school, she did a residency in pediatrics but ultimately wanted to do developmental-behavioral pediatrics
  - It was a good fit with her interested and passions
- She did a year in pediatric neurology and then a fellowship in developmental-behavioral pediatrics before moving to California
- Her interests today primarily revolve around behavioral therapy for 3 things that we’re going talk about: autism, ADHD, and anxiety
- We’re coming at this through the lens of what Trenna does today
  - Which is running a really large, successful multidisciplinary [clinic](https://www.sutcliffeclinic.com/) for children up to 18 years old

**How are the diagnostic criteria defined, and how does a practicing clinician use the** [**DSM-5**](https://en.wikipedia.org/wiki/DSM-5) **or maybe modify that in the way that they try to come up with a diagnosis?**

**⇒** Anxiety, ADHD, and autism are all behavioral clinical diagnoses based on checklists of a number of traits and characteristics

- You need to be working with a physician trained in these conditions who has enough experience diagnosing these conditions
- Essentially, that person needs to be an expert on what the clinical picture looks like because there’s **no biomarkers** for any of these conditions
  - That’s the key thing: there are no blood tests, no brain scans to say who has anxiety, who has ADHD, who has autism

Trenna explains to families all the time, “*I have these clinical boxes and labels and diagnoses in my clinic, and these boxes and are manmade. We create these lists of criteria, but neurobiology in the brain is much more complex than these boxes.*”

- The key thing is to have a clinician who collects lots of data on the child
  - Their traits at home, at school, in multiple environments
  - Talking to parents, getting the history
  - Getting information from people other than parents: using rating forms or talking to teachers and therapists
  - Ideally, we get to see the child in their real-life environments
    - Maybe even observing them in a real-life place like school
  - And then doing assessment in the clinic to collect information about them
- With that, the clinician decides whether or not they meet diagnostic criteria
  - A list of traits or characteristics described in a book called the DSM

**⇒** One of the key things is about **whether or not those traits are creating impairment**, and that’s a key criteria for any of these diagnoses

*For example, anxiety*

- We all have feelings of anxiety
- Anxiety is actually a very appropriate normal feeling that we should all have, but it’s all about how much impairment is it creating, how does it impact function, and impact someone doing their job
- For a child, their job is to learn and go to school, make friends, practice communicating and interacting with other peers, and be a positive contributor in their community (which is school)
- So it’s about how these traits impact their function in that job

**What would you say is the youngest age that each of those could be diagnosed?**

- For **autism**, we can confidently make that diagnosis as young as 18 months of age
  - Although the typical age for diagnosis is 3 or 4 [years old]
- In the last 20 years, there’s been 1 or 2 cases where Trenna has made it at 15 months of age because it was very significant and obvious
  - Most often, at that young age, we do wait a few more months to watch how the child develops because kids are moving target
- With autism, it can be 18 months, 2 years of age
  - Although half of the cases of autism are diagnosed over 6
- With **ADHD**, you can make a diagnosis as young as 4 years of age
- But from Trenna’s clinical experience, she rarely jumps into the diagnosis with 4- or 5-year-olds because they’re still a moving target
- She may start behavioral interventions and parenting support but generally waits closer to school age

Peter asks, “*When you say school, you don’t mean preschool. You mean actual kindergarten, 5 to 6?*”

- Yes, a lot of people will wait till 5 or 6 to really see how that child is evolving, although technically you could make it younger
- With **anxiety**, there’s many different types of anxiety
  - There’s [separation anxiety](https://en.wikipedia.org/wiki/Separation_anxiety_disorder)
  - There’s something called [selective mutism](https://en.wikipedia.org/wiki/Selective_mutism) in young kids in preschoolers
- There’s definitely anxiety conditions in preschoolers

## Understanding anxiety and ADHD: assessing impairment and self-esteem and identifying anxiety and emotional well-being in young patients [9:45]

- You said separation anxiety is an example, and anyone who’s been a parent can appreciate moments of that

**What are some of the other types of anxiety, and how do you look to spot those in kids?**

> “*Anxiety is actually a normal emotion that we should all have. So it’s all about whether it’s creating enough impairment*.”‒ Trenna Sutcliffe

- Someone may have **generalized anxiety**: it’s seen in multiple places as pretty pervasive
- People can have **specific phobias** towards dogs or spiders or other things
- There’s **separation anxiety**
  - Many toddlers have separation anxiety and that’s very normal
  - It’s about how severe and significant the anxiety is, how pervasive it is, and whether it is impacting function
  - When it’s impacting the ability for a child to go to childcare or preschool, then it’s something we need to help
- There’s something called **selective mutism**
  - Children who are able to speak very well and speak well at home or with familiar adults but do not speak and are mute outside of that familiar environment
- There’s also **obsessive-compulsive disorder**, where people have obsessive thoughts or compulsive behaviors

Peter notices, “*You’ve reiterated it twice now, which tells me how important it is. It really has to come down to this impairment thing.*”

- He points out that all of us could probably read through the DSM-5 and place ourselves in each of these diagnostic buckets
- The truth of it is to ask, “*Which is maladaptive, which is mostly giving me the negative response that is impacting relationships or work or these other things?*”
  - Peter likes that framework for kids because you may think that your kid has ADHD but they’re doing well in school, enjoy playing sports, and have friends

**How would you help a parent navigate that if they think their son, daughter has ADHD**

*What are the impairment-style questions you would be asking to paint the contours of this condition, even if you acknowledge that that kid’s got a lot of energy?*

- Those are great questions because it is definitely a spectrum (there’s a [bell curve](https://en.wikipedia.org/wiki/Bell_curve))
  - We’re all on a bell curve
- When does it become leaving the average range (the typical profile) and over into what we call a disorder?

Trenna adds the caveat, “*I don’t like to use the word disorder for these conditions either because I think they’re just learning differences and thinking differences as well.*”

***Questions around impairment, the #1 thing she talks about with families is self-esteem***

- How is it impacting that child’s self-concept, how they see themselves?
- How is it impacting their relationships with peers? That’s another key one
  - Does it impact social interactions?
  - Does it impact how they connect with peers?
  - Does it impact the feedback they’re getting from peers?
- How does it impact their ability to learn and access learning opportunities at school or on the playground?
  - Are these traits impacting their ability to fully engage in learning, be successful, show their potential?

Trenna emphasizes, “*The self-esteem thing is very important to me.*”

**These are all biologic conditions: there’s neurochemicals, there’s genetics involved**

- And for a child to have a biologic condition and be in class and then feel bad because they are worried they’re not doing well enough, and they’re getting a lot of negative feedback from teachers and peers, not because those people are trying to be mean or negative, but they have to constantly remind that child because that child is forgetting things, losing things, forgot to put their name on the piece of paper, completely off task
- It’s not sustaining attention in a conversation
- It’s actually avoiding tasks that require a lot of sustained attention

***There’s a lot of these traits where it’s impacting the child’s ability to be successful day to day at school***

**How do you assess self-esteem?**

*What questions are you asking the child when you actually get to sit down with the child to determine that?*

*Is there anything you can glean on that dimension from speaking with anybody other than the child?*

- Yeah, you do both of those things: you speak to the child and you talk to others
- When you talk to the child, there’s multiple different ways of doing it
  - Not always easy to get the answer
- You’re building a relationship, a rapport with a child and there needs to be trust
- With younger children, we sometimes use approaches where we actually are talking about a third person
  - We may talk to them about another child so that you have another third person because sometimes it’s easier to talk about a third person than yourself
  - Talking about situations about how another child would feel at school, or why does another child feel uncomfortable at school, or why does a child come home crying some days?
  - When children talk about that, they relate to their own situations, and then you hear their stories

Peter asks, “*What is the age window in which you can utilize that technique?*”

- Mostly primary-elementary school-age
- By the time they get to 2nd, 3rd, 4th, 5th [grade], they’re able to share these stories about other people
- When they’re older, they’ll talk about themselves
- For a child, it’s hard to reflect on your own feelings and thoughts
  - To identify their own emotions
  - The “why” behind their emotions is challenging

## The evolving diagnosis of autism: understanding the spectrum and individual needs [16:30]

**How is the diagnosis of Autism Spectrum Disorder made?**

Peter explains, “*We’ll park for a moment the use of the word disorder and maybe come back to that*.”He thinks that when many people think of autism, if they’re old enough, they might think of [*Rain Man*](https://en.wikipedia.org/wiki/Rain_Man)

![](https://peterattiamd.com/wp-content/uploads/2025/01/f1-trennasutcliffe.png)

**Figure 1. Poster from the movie** ***Rain Man***. Image credit: [IMDB](https://www.imdb.com/title/tt0095953/?ref_=tt_mv_close)

- You think of somebody that is not neurotypical, that is quirky and very different
- You might think of even more extreme examples of children that are nonverbal and things of that nature

*Given the nature of this and the fact that it’s a spectrum, that must make it even more challenging to find the diagnosis*

- Very
- Trenna has so much to say about autism or the diagnosis and how we make it and how it’s changed so much over the years

**⇒** Autism spectrum is a huge spectrum

- It goes from the classic description that we remember from the last couple decades: nonverbal, very little communication skills, being somewhat isolated and not interacting with other people, mannerisms such as flapping your hands
- Nowadays, many children who have a lot of speech and language skills (who do communicate a lot) but struggle with the social communication that we have with each other

***Kids who struggle with social skills and do have some restricted interests of repetitive behaviors, they also qualify under this umbrella term called Autism Spectrum Disorder***

**⇒** This term [Autism Spectrum Disorder](https://en.wikipedia.org/wiki/Autism) came out in 2013 with the DSM-5

- How we diagnose it is based on clinical traits (again), but the definition and the checklist of those traits have actually changed many times over the last few decades

*Current procedure for diagnosis*

- You work with an expert who has a lot of experience with autism, and they do an analysis of someone’s behavior
- The 2 areas that we look at: social communication skills and repetitive behaviors restricted interests
- For **social communication skills**, our current diagnostic criteria requires that a patient has differences in 3 specific areas
- 1 – Their social reciprocity
  - This is the back and forth of social interactions
  - It’s how do you initiate socially?
  - How do you respond socially?
- 2 – Related to nonverbal communication skills
  - How someone uses their nonverbal communication, eye contact, gestures, as well as how they understand and interpret somebody else’s nonverbal communication
- 3 – Related to how they understand relationships
  - It’s about building friendships, playing with peers, how they understand the social context of being in a group

***In order to get the diagnosis, you do have to have differences in all those 3 areas***

Peter asks, “*Is this something that is done during one assessment, or is this something that’s done over repeated assessments?*”

- It depends on the level of severity in the child
- First of all, it’s important that whoever’s doing the assessment really understands that child

Peter asks, “*Who in your clinical team does this? What type of training does this person have?*”

- Generally, it’s a physician or a psychologist
- Most often, the physician is either a developmental-behavioral pediatrician (DBP) or a psychiatrist
- Occasionally, it’s a pediatric neurologist or somebody else with some sort of similar background and training
- If it’s not a physician, then it’s a psychologist that usually does the assessment

**The assessment could be multiple things**

- There’s no gold standard like the assessment has to include certain components
- But it’s important that the clinician get to know the child
  - It’s important to understand the profile

Trenna explains, “*The label is only one piece of it. If someone tells me their child has autism, I actually really don’t know much about their child…”*

> “*There’s a saying, ‘If you’ve met one child with autism, you’ve met one child with autism.*’”‒ Trenna Sutcliffe

**⇒** To really make a difference with the treatment plan, you need to understand that profile of that child’s strengths and challenges

*There’s multiple goals with the assessment*

- 1 – The diagnosis can be a tool to help the adults around that child better understand that child
- 2 – It gives some sort of structure of how to approach that child and leverage their strengths and work on skill building
- 3 – It can help get resources at school or through insurance

***To really make a difference, you want to understand what about that child is unique and different and how do you support that child***

*How do you do an assessment?*

- You should take a good history
- You should definitely meet with the child, work with the child in the clinic
- When it is a more **significant case** with significant impairments, we frequently can make the diagnosis pretty quickly
  - This is true for many children with very significant autism
  - It would be obvious to you if you were in a restaurant and you saw someone with autism
- But for children who have **milder symptoms**, it’s really important that there are
  - Multiple visits to see the child on multiple days
  - Different types of assessments are done directly with the child
  - Taking history with the parents
  - Collecting information from other people involved in that child’s life (such as teachers or therapists) is important to get different perspectives

**Peter’s summary**

- Autism diagnosis in more severe cases probably can be made earlier and earlier in life
- The sweet spot is 3-4 years of age
- Half of kids are diagnosed above the age of 6

Peter asks, “*Is that something that is a relatively recent phenomenon of the past decade since the DSM-5 broadened the inclusion criteria, or was that even true in the 70s and 80s?*”

- It’s complicated
- It has a lot to do with the new diagnostic criteria
- Before 2013, we had **Asperger’s syndrome** (we don’t use that diagnostic label anymore)
- We also had something called **PDD-NOS** (Pervasive Developmental Disorder Not Otherwise Specified)
- PDD-NOS was a term we used when it had similarities to Autistic disorder because all 3 of those names were under the umbrella of autism
- There were a lot of kids who received this PDD-NOS because they were like, “*Something’s different*”
  - They’re sprinkled with bits of autism, but they didn’t quite meet all the criteria
  - When you didn’t meet all the criteria, you got [the label] PDD-NOS
- Then there was **Asperger’s Syndrome**, which generally described an individual who had good cognitive skills, average or high cognitive skills, intellectual skills
  - They had a lot of speech and language skills; they actually have huge vocabulary
  - But again, their social reciprocity, back-and-forth conversation, picking up on social cues ‒ that was atypical
  - They also had a lot of restricted interests
  - They would have things they were really interested in, but then they would dive deep into those things

***In 2013, with the DSM-5, we put all of that together under Autism Spectrum Disorder***

- And so now the kids who have the more clear-cut, very traditional Autistic Disorder, they’re picked up at 2-3 years of age
- It’s the kids who have the stronger cognitive skills (they have speech and language present) that are picked up later
- Nowadays, with the new diagnostic criteria, language impairment may or may not be present in the diagnosis
- When you give the diagnosis of Autism Spectrum Disorder, you also have to clarify whether there is intellectual disability or without intellectual disability
  - And then we say with or without language impairment

> “*With all of these changes, the spectrum, it’s very broad.*”‒ Trenna Sutcliffe

## The dramatic rise in autism spectrum disorder (ASD): genetics, environment, expanded diagnostic criteria, and more [25:45]

- Peter points out that the CDC said in the year 2001, that roughly 1 in 150, 200 kids had autism
- This was before this change to the DSM-5
- We can only that to mean that those were the kids in the bucket of more extreme autism
  - That did not include PDD-NOS or Asperger’s
- The last year, prior to that change in 2012 it was down from 1 in 150 to 1 in 69
- In other words, there was something that was increasing the prevalence or diagnosis by about a factor of 2
- Then we get the change in the DSM, and today, we’re at 1 in 36 (that’s what the CDC said in 2020)

**What is driving the increase in the prevalence of ASD, notwithstanding that there has also been a larger net cast around it?**

Trenna explains, “*I can’t believe it’s 1 in 36 because I’ve been doing this for 25 years. I can never keep track of the numbers. Every time I go to an annual meeting, the number changes.*”

- The point being that the numbers have changed drastically
- Yes, people will say part of it is because the definitions change, there’s more awareness, there’s more resources, there’s more clinicians making the diagnosis

***But people in the field believe that those changes don’t explain the drastic changes in the numbers, and there has to be something else involved***

- Research in this area is looking at the impact of the **environment** and [epigenetics](https://en.wikipedia.org/wiki/Epigenetics) and what roles those 2 things have in increasing the rate of autism in our population

Peter asks, “*If you’re at a dinner party and you get cornered and everybody wants to talk about this, how are you walking people through this? What are you saying? (Let’s put the diagnostic criteria aside)… What are some of the environmental things that you think could be amplifying this?*”

- There are thoughts around pollution, maternal infection, prolonged fever during pregnancy, the health of the placenta, stress, parental age
  - A lot of environmental factors have been implicated
- To take a step back first, let’s talk about the cause of autism (the genetics, and the environmental piece), just to make it really clear, **the word autism describes a constellation of symptoms**

> “*There are many, many causes for autism. There isn’t a single cause. What causes autism is very complex, and we actually have more questions than answers.*”‒ Trenna Sutcliffe

- It’s not a 2-hit model, there’s many factors involved (it’s more of a 10-hit model)
- It’s multiple hits, and the order of the hits and the timing of the hits are also felt to be very important

**The genetic piece ‒ heritability is largely determined by studying identical twins separated at birth, raised in different environment**

- What is effectively the probability that they’re both going to come down with the same psychiatric condition?

***The heritability of autism is anywhere from 70-98% depending on the definition used, but it’s well over 90%***

- Peter didn’t know it was that high
- The heritability of autism is higher than it is for any other condition in the DSM
  - Even schizophrenia, bipolar disorder, and depression ‒ things that we know have very strong genetic components

***There’s definitely a genetic component to this but it’s not 1 gene ‒ it’s multiple genes***

- Some people say hundreds or even thousands of genes are associated with autism
- There’s multiple genetic changes in anybody with autism, and every person who has autism probably have a different group of genes that have been changed

**Peter’s analogy**

- He likens it to cancer with a fundamental difference
- Cancer is mostly about [somatic mutations](https://en.wikipedia.org/wiki/Somatic_mutation) and not [germline mutations](https://en.wikipedia.org/wiki/Germline_mutation)
  - Meaning most of the time when a person gets cancer, it is not based on genes that they were born with
  - It’s based on genes that were at one point normal that have since acquired mutations in their mutated state
  - Those genes no longer function normally, and the person develops cancer
  - This complicates the analogy because only about 5% of cancers arise from germline mutations (that you’re born with)
- The genes that are implicated in autism are indeed germline (you’re born with them)

***The point Peter wants to make is comparing the somatic mutations of cancer to the germline mutations of autism***

- When you’ve met a woman with breast cancer, you’re not going to find too many women that look the same with breast cancer
- And that’s really why gene therapy hasn’t panned out for most cancers, because to say that a person has breast cancer tells you some stuff
  - You could dig a little deeper and say, well, it’s estrogen-positive, it’s progesterone-positive, it’s HER2/neu-positive

*But still, why wouldn’t they all respond the same?*

- It’s because they have many different underlying genetic changes
- Furthermore, they have completely different immune responses in terms of what their tumor looks like

*The way Peter thinks about it*

- If you see 100 kids with autism
- And let’s just pick a number that’s somewhat conservative, we would say that autism is 85-90% heritable

***It simply means that the underlying genes for each of them were inherited, but they might have nothing to do with each other across all of those children, just as we would say all of the women who have breast cancer have acquired mutations that gave them breast cancer, but they could all be very different***

- Trenna agrees
- Peter thinks this is an easier way to think about it because polygenic things are harder to wrap our heads around
  - Especially when we don’t know what all the genes are
- Trenna points out that while we know there is a genetic component, we don’t know all the genes

***Each child with autism has a different “fingerprint” with their genetic makeup***

**The environmental component**

- There are genetic changes but some of the hits are environmental
- There is research to show maternal stress, pollution, maternal diet, parental age, these things also are associated with autism

**⇒** There’s a long list of things that are associated, but none of them alone, each one alone is not the key to autism, it’s the combination

*Could it be changes to our food environment?* *Peter compares it to* [*type 2 diabetes*](https://en.wikipedia.org/wiki/Type_2_diabetes)

- 50 years ago, the incidence of type 2 diabetes was in the ballpark of 1.5-2% of people in the US
- [Today it’s over 10%](https://www.cdc.gov/diabetes/php/data-research/index.html)
  - This is clear type 2 diabetes, not the gray area of pre-type 2 diabetes
- Let’s just say we’ve had a 5- to 7-fold increase in a condition over the course of 1 generation
- It would be very difficult to explain that just genetically, that there’s been some genetic change
  - We might have genetic susceptibilities, we might have genetic manifestations, but the thing of it is, something must have changed.
- Most people would point to our food environment as the leading thing that has driven that change, because the change in the food environment in 50 years is dramatic

Peter asks, “*When we apply the same logic to autism, do we see big enough changes in these environmental triggers, even just over the last 25 years?*”

- 25 years ago, kids were born with the same genetic predisposition
- There can’t be that much [genetic drift](https://en.wikipedia.org/wiki/Genetic_drift)
  - Unless we believe we are seeing more people pair together to combine four genes or genetic combinations that are producing this phenotype more than we saw before
- If we’re saying that whatever epigenetic change is happening is triggered by something in the environment, and we’re talking about if paternal age is going up, if maternal stress is going up, if maternal nutrition is getting worse, if environmental toxins, microplastics, heavy metals, whatever it is
  - And we have to talk about vaccines, of course, there’s going to be a subset of people that wonder about this
    - If this is an [in utero](https://en.wikipedia.org/wiki/Uterus) genetic condition, then childhood vaccines might be less responsible than some might think

Trenna explains, “*I wish I had all the answers, I don’t. I think it’s complex.*”

- There have been changes in diet, pollution, toxin exposure
- That’s one piece of it

## Exploring epigenetics and the potential multigenerational impact of environment exposures on susceptibility to certain disorders [37:15]

- With [epigenetic](https://en.wikipedia.org/wiki/Epigenetics) changes (just to clarify), the DNA sequence is not changed, it’s about tags on the DNA that can change the expression of genes [shown in the figure below]

Or proteins called [histones](https://en.wikipedia.org/wiki/Histone) that are changed that end up resulting in changed gene expression

![](https://peterattiamd.com/wp-content/uploads/2025/01/f2-trennasutcliffe.png)

**Figure 2. Epigenetic changes include DNA methylation and histone modification**. Image credit: [NIH](https://en.wikipedia.org/wiki/Epigenetics)

- But the changed gene expression can actually be inherited or passed through generations as well

Peter asks, “*Do we know that to be a fact, that the epigenome is being transmitted?*”

- Trenna thinks it’s controversial, but there is some thought about that, about the idea of the germ cells in a fetus

**⇒** In a grandparent being exposed to smoking, toxins, changes in food, how that grandparent exposure can actually change methylation in the germ cells of a parent who’s a fetus, then whose germ cell goes on to be a child with autism

- Trenna hopes that made sense; it’s confusing

***Peter wants to make sure listeners understand that this is not established***

**Peter explains epigenetics**

- We have these 4 things that make up DNA: C, G, A, and T, and that is the code of life
- But on the backbone of those things, you can put little [methyl groups](https://en.wikipedia.org/wiki/Methyl_group), which is just a little carbon with three hydrogens, and that’s called epigenetics [shown in the previous figure]
- By the way, we’re all born with methylated groups all over our epigenome
- Over life, we know that changes
  - Simply aging changes methylation

**⇒** But we believe that there is differential methylation in individuals in response to all the things just discussed, and we know that methylation controls gene expression

- In fact, methylation is probably the single most important thing that controls differential gene expression in different tissues

***The jugular question is, if you have a methylation pattern, can you pass that on to your fetus?***

- And what Trenna said a minute ago is even more remarkable, “*Would that child, when they develop, pass that methylation pattern onto their fetus?*”

***At that point, methylation, epigenetics, would start to become genetic ‒ it starts to become a part of the germline***

- Peter thinks this is an answerable question
  - This is on that list of things that we should know the answer to in a decade
  - Just based on the fact that we will have enough longitudinal data to be able to get at this

Trenna explains, “*The key thing is that we do know the environment impacts the methylation and the epigenetics. So it’s the idea of it crossing generations, it’s the idea of the methylation in a germ cell is altered or changed because of some sort of environmental exposure in, again, that parent or grandparent.*”

- In that sense the child is now susceptible to 2 things: the germline that they inherit from both parents and as a fetus, the methylation impact that occurs as a result of any of these other factors discussed

**Who are the people that are studying this most closely?**

- Peter always thinks it’s very foolhardy to work on an epidemic without understanding its causal nature
- He uses the example of how [HAART therapy](https://en.wikipedia.org/wiki/Management_of_HIV/AIDS#:~:text=highly%20active%20antiretroviral%20therapy%20(HAART).) changed the face of [HIV](https://en.wikipedia.org/wiki/HIV) forever
  - One of the greatest success stories of infectious disease medicine
  - It was all predicated on understanding what the cause was
  - If you didn’t understand that HIV was destroying [CD4 cells](https://en.wikipedia.org/wiki/T_helper_cell), you didn’t have a prayer of developing that therapy

## The evolution of autism classifications, and the particular challenges for children with level 1 (mild) autism due to a lack of support [41:15]

*Do you ever worry that this is going to affect 1 in 3 kids in 30 years? (What if this trend continues?)*

- One of the issues is how we define the condition, there is still that
- There is also this piece with genetics and the environment and how we are evolving
- And there’s this, this phenotype where there are differences in social communication skills and repetitive behaviors of restricted interests
  - Which is on a huge spectrum as well

Trenna explains, “*I just want to make sure this is the thing, when we are talking about these numbers, like 1 in 36, and this number continues to increase, is not just the kids who are non-verbal autism, it’s this really wide phenotype is increasing.*”

***It is important we understand the cause of why this phenotype is increasing, and then what should we or should not be doing about that?***

**What do you know about the change in the prevalence of the non-verbal (just to pick one subset) or child that is so impaired that a parent could diagnose them?**

*Do we know if that has remained relatively constant over the last 25 years, despite the change in diagnostic criteria?*

- Trenna believes there’s an increase in that number as well
- But the numbers that are put out there, the really profound numbers, actually describe the entire spectrum, and they don’t subdivide into the different parts of the spectrum

Peter asks, “*Do you have a ballpark idea? So if the overall diagnosis of autism has increased 5-fold in the last 20 years, has that more severe part gone up by 50%, by 100%?*”

**⇒** We subdivide autism spectrum into 3 buckets: [level 1, level 2, level 3](https://en.wikipedia.org/wiki/Autism#:~:text=DSM%2D5%20uses%20a%20%22level%22%20system%2C%20which%20ranks%20how%20in%20need%20of%20support%20the%20patient%20is%2C%20level%201%20being%20the%20mildest%20and%20level%203%20the%20severest)

- The more significantly impaired children would fall into level 3, where they require very substantial support
- There are very few research studies that actually look into these sub-buckets, and Trenna is not sure clinicians are always great at identifying kids in the sub-buckets either
- We’re talking about a very specific profile that should be very obvious to identify, but there’s other kids in sub-bucket 3 that are sometimes put in sub-bucket 2 depending on what clinician they see
- Peter assumes that sub-bucket 3 is not the totality of the children that were called autistic prior to 2013
  - Trenna agrees

**Peter’s takeaway** ***‒ you can’t even say (assuming the data existed, and it sounds like they don’t) what was the prevalence of autism in the DSM-4, and how does it compare to ASD sub-3 today. That wouldn’t even be a meaningful comparison***

- Trenna’s not sure if anyone has looked into it
- Even if they did, it wouldn’t be an apples to apples comparison

**⇒** One of  the reasons they put Asperger’s syndrome, PDD-NOS, autistic disorder all under 1 umbrella (which was quite controversial), was because clinicians did a really poor job of deciding which bucket you were in

- You would have a child, and one clinician would call it Asperger’s syndrome, another person would call it autistic disorder, another person would call it PDD-NOS
- So they decided, okay, rather than having these 3 names, let’s put it all under autism spectrum, but then they have level one, level two, level three
- But clinicians still struggle sometimes where there is a little bit of overlap, it’s not always clear

Peter asks, “*If you go back to DSM-4, when, as you mentioned, physicians are struggling to know which of these buckets to put them into, as an outsider looking in, my first question is, does it matter in terms of treatment and resources, does it matter more in terms of outcomes and support?*”

- It did make a difference with respect to resources
- Children with Asperger’s syndrome frequently did not get support or support covered [by insurance]

***You needed a diagnosis of autistic disorder to get support, so grouping these diagnoses under 1 umbrella (ASD) was a tool to get resources***

- Level 1 requires support, level 2 requires substantial support, and level 3 requires very substantial support

**Trenna’s concern is that when a child is level 1, they don’t always get the support they need because they have so many strengths**

- Kids in level 1 frequently have good cognitive skills: they have a lot of language skills, they struggle with some social skills, and they may have some difficulties with executive functioning and coping skills at times
  - But again, it’s considered mild
- A lot of those kids don’t get support, and that’s unfortunate because they also are the kids that respond to intervention so well
- If they get a little coaching on how do you cope with distress, how do you cope with change, how do you practice some social skills, not that they have to change
- We don’t need to change everything about them, but giving them a little bit of support about how to be adaptive in a community

***Giving that support goes a long way with that group, but frequently, they don’t get the support because they’re called level 1***

## The broadening of the autism spectrum: benefits and risks of expanded diagnostic criteria and the need for future frameworks to focus on better outcomes [48:00]

**Help me understand the natural history of those [level 1] kids back in the ‘70s and ‘80s**

- Back then, Peter thinks they weren’t labeled with autism, there wasn’t in-school programs to help them with social skills and communication skills
- They’re not intellectually  impaired, so it’s not like they’re going to struggle in school, but there’s clearly something that they’re struggling with

*Did those people go on to pick careers where they didn’t have to interact with people but could still do challenging cognitive work? (there are clearly a lot of them)*

- They found a path that made sense to them
- They obviously learned what their strengths were
- Their **strengths** may have been around memory, detail-oriented, following rules that are black and white, they may have had really wonderful cognitive skills in certain areas that were less around inferring and social skills and more concrete
- We don’t have studies to say this for sure, but Trenna’s guess is they have lived happy, successful lives, doing things that they enjoy doing, are passionate about

***They probably have found ways to not engage in large social settings, but there’s a lot of careers out there that are a good match***

- They also have relationships and marriages

**⇒** People with autism get married

**These characteristics resonate with people**

- Peter thinks there are probably thousands of people listening to this right now who are adults and thinking, “*This resonates, I get that. When I was a kid, I was hyper-focused on this stuff, I wasn’t interested in a whole bunch of stuff. It was a little harder for me to interact with other kids and things like that, and yet I found my path and here I am today.*”

*Trenna talks to parents all the time about this*

- When she evaluates children for autism or ADHD, at some point while she’s developing this relationship with the family, the parents say, “*Gosh, so much of my child is in me. As you are describing my child and my child’s strengths and challenges, I see me, and this is exactly what I went through when I was young.*”
  - And they share how hard it way that no one understood them
  - Or they thought it was their fault because they didn’t try hard enough
- It can be validating for an adult to learn that it wasn’t their fault, and this is part of their wiring
- Many parents ask her if they should get assessed
  - Trenna asks questions
  - Information is power, and it’s good for them to be thinking about it
  - With autism, often they don’t
  - But with ADHD, they often do because they realize their ADHD traits are impacting their function and success at their job
- Trenna shares with the the genetics and family history, because these things do run in families and there is a highly genetic component

***Sometimes just that conversation can be therapeutic itself***

- Someone feeling validated may have that “aha moment,” where this explains a lot
- It also helps them understand why sometimes they have these challenges at work or with their spouse

**⇒** Sometimes just having a perspective where you can see your challenges through a different lens helps a person think about how they can adjust or understand the triggers to reflect about how they want to respond the next time

> “*That information is empowering. Even if they don’t ever go to therapy or do anything else, just actually starting to become informed about it can help.*”‒ Trenna Sutcliffe

- Peter would imagine that it helps them a lot with their child because they’re seeing both that
  - Their child has this diagnosis and that partially explains the challenges they’ve been having
  - Because they’ve experienced it, they can empathize with that child, and it makes them a better parent

**Peter’s takeaway**

- Everything you said makes a great case for widening the diagnostic envelope
- If we go back 40 years, we had this narrow, narrow envelope
  - In other words, we had a test that had very high specificity but very low sensitivity
  - You were missing a lot of people, but you didn’t get any false positives, you didn’t over-pathologize
- Today, we have the opposite problem: we have a high sensitivity, low specificity test
- Anybody who’s autistic should get diagnosed, but then we’re stretching what that means
- And a lot of the people getting diagnosed today, maybe without any support, would go on to do just fine

**Do you worry that when the DSM-6 comes out, it could have a wider envelope, and we could start to get to a point where someone might say, “*****Hey, are we over-pathologizing this?*****”**

- Yes

*Are we getting to a point where, what does normal even mean anymore?*

- Trenna agrees and asks that question all the time
- She wonders every time a child has a few of these traits, if we’re coming up with the diagnosis every time someone is just a little bit different
  - We have to give a name to it all the time
- Rather than realizing there is neurodiversity (we’re all different)

*It’s an interesting debate, and you’ll hear different perspectives*

- The name gives us a way to get resources and help people
- But Trenna is also concerned that we have to give everything a name
- She wonders in the next DSM whether we’ll end up taking a step back, and the pendulum will swing a little bit [the other way]

Peter asks, “*When is that due?*”

- She doesn’t know
- There was a couple decades gap between the DSM-3 and DSM-4, and 4 and 5
- It could be another decade

**The difficulty of diagnosing level 1 ASD and the importance of services for this group**

- Trenna is concerned that the kids in level 1 autism might actually be part of several different diagnostic buckets
- Children who identify with level 1 autism, they see 1 clinician, that person may diagnose autism
- They see a 2nd clinician, that person may diagnose ADHD plus anxiety
  - They don’t even call it autism
- Trenna sees this all the time in her clinic
  - Kids come to her clinic, and they may have seen 3 other clinicians before (really great clinicians, high standards, experts), but ***there’s a lot of blurry lines with the diagnosis of level 1 autism, and you will hear different diagnoses***

**Back to thoughts around future DSMs**

- Trenna wonders how we’re going to address level 1 autism, and is it the same condition?
- How many different conditions are in that bucket?
- Peter would hope that by the time we have to make that decision, we would have enough data, and the data would ask the most important question: *how are we impacting outcomes?*
- In other words, when we widened the diagnostic envelope and said that we’re going to now have this ASD level 1 in here, that opened the door for more resources, that meant more kids had IEP programs at school

Peter asks, “*What’s an IEP?*”

**⇒** Individual education plan

***At the end of the day, we want to know if those kids are doing better***

- If the answer is yes, then it’s probably worth keeping
- If the answer is that didn’t make a darn bit of difference, all we did was create a bunch of anxiety for the parents, and maybe it didn’t
- Peter doesn’t know how one goes about answering that, but he would hope that somebody a lot smarter than him is thinking about it through that lens

***Because we can’t lose sight of the whole purpose of this: the purpose of a diagnosis anywhere in medicine should be to impact an outcome***

- A diagnosis for the sake of a diagnosis is not a particularly valuable tool, unless you’re an epidemiologist
- Trenna agrees

***This is why kids in level 1 should be receiving services, otherwise, what’s the point of giving the diagnosis***

- If we need to call something by a different name, who cares
- As long as kids get the service that makes them better off than they would’ve been had they received no service

## The overlap between ASD, ADHD, and anxiety [57:15]

**One more thing on the diagnosis piece: can you talk a little about the overlap between ASD, ADHD, and anxiety?**

*How often do they overlap? What do those Venn diagrams look like?*

- We diagnose anxiety in kids, and there’s that bucket
- Many kids clearly fall in the anxiety bucket and it’s clear to see that
- There are kids who have ADHD and clearly meet diagnostic criteria for ADHD
- Then, there are kids who clearly fall into the autism bucket

*Focusing on the autism bucket first*

**⇒** About half of kids with autism also have a diagnosis of ADHD

- You can find reports anywhere from 40-70% of kids
- Interestingly, before the DSM-5 (before 2013), we were not allowed to give both those diagnoses together, so they were mutually exclusive
  - If a child had autism, we did not give a diagnosis of ADHD
- Starting in 2013 they were allowed to give both diagnoses, and they give it a lot

**⇒** About 40% of kids with autism also have anxiety

- This makes sense when you think about the parts of the brain involved
- When you think about **ADHD**, we’re thinking about [executive functioning](https://en.wikipedia.org/wiki/Executive_functions) skills
  - We’re thinking about prefrontal lobes
- When you’re thinking about **anxiety**, you’re thinking about the [amygdala](https://en.wikipedia.org/wiki/Amygdala)

**⇒** When people have done **neuroimaging studies in kids with autism, we find there’s many areas of the brain involved**, but in particular: frontal lobes, the amygdala, the cerebellum, temporal lobes (there’s many, many areas of the brain involved)

***Kids with autism do have challenges with executive functioning and anxiety, although those are not part of the diagnostic criteria***

- Those are associated symptoms, associated traits, associated diagnoses
  - They’re comorbidities, not part of the core diagnostic criteria, but there’s a lot of overlap

**If 50% of them have ADHD, and 40% of them also carry a diagnosis of anxiety, is there a percent of those that are overlapped and have all three?**

- A lot of them have all 3 (Trenna doesn’t know the exact number)
- These kids present with the core features of autism, along with the executive functioning challenges, and are anxious

**What can we say about kids with ADHD and anxiety, what’s that overlap?**

- Kids who have ADHD and anxiety, their numbers towards autism are not as high
- There are a lot more kids with ADHD who are not diagnosed with autism, but there’s a lot of overlap between ADHD and anxiety
- ADHD frequently has a partner, either anxiety, or some other mood challenges, or you have learning differences
  - Learning disabilities are frequently present in kids with ADHD
  - Or you have oppositional behaviors

***There’s often a second condition present in kids with ADHD***

## Understanding oppositional defiant disorder, and the importance of understanding the “why” behind a behavior when creating treatment plans [1:00:45]

**More about oppositional behavioral tendencies**

- There’s a diagnosis called [oppositional defiant disorder](https://en.wikipedia.org/wiki/Oppositional_defiant_disorder)
- Trenna doesn’t use it quickly or often in young when she sees oppositional behaviors (that’s her personal approach)
- When she sees a child with oppositional behaviors, what does that mean?
  - Someone who argues, doesn’t follow rules, disobeys, lies

***Trenna wants to understand the “why” before diagnosing oppositional defiant disorder (ODD)***

- Technically, maybe they meet the criteria ‒ it’s a checklist criteria
- But that name doesn’t help her
- She wants to know the function behind that behavior, a reason for why a child is oppositional
- We have all seen kids who have meltdowns, who fight, who yell, who argue ‒ what’s the function behind that?
- It may be that child is actually anxious

***A lot of oppositional behavior in kids is driven by feelings of anxiety and embarrassment***

**What’s often behind oppositional behavior**

- It may be the child is impulsive
- That child lies and argues and yells no quickly because they’re impulsive and they have untreated ADHD
- It could be that child struggles with understanding social context and social skills
  - They actually have trouble with their social reciprocity, but they’re presenting with what looks like oppositional behavior
- That child may be sensory overloaded and have challenges processing sensory information and therefore becomes overwhelmed and dysregulated and oppositional
- The list goes on
- The point is when Trenna sees a child with oppositional behavior and a family says, “*Oh, well, someone told us it was ODD.*” She’s like, “*Now what?*” (she’ll explain more in a minute)
- Peter doesn’t know what fraction of kids are getting that type of insight and attention ‒ his concern would be, not enough

**We’re in a world of expanding labels and codes, and the “so what” is missing**

- Peter’s analogy: if you think about a person who has hypertension, hyperlipidemia, insulin resistance, it’s important to understand why
  - At a minimum, we have great treatments if we don’t know the why
  - If at the end of the day it’s just deemed essential hypertension, we have no clue why
  - Worst case scenario, we can put you on medication
  - If weight loss isn’t enough to reduce your blood pressure and fix your insulin resistance, at least we’ve got medications that work really well

**⇒** But a lot of people would be hesitant to give their kids medication here

*Which is all the more reason why you need to understand why this kid has oppositional defiant disorder*

- Because if it’s sensory overload, it’s a totally different treatment path than if it’s anxiety
- Trenna agrees
- This is one of the challenging things about her field
- She’s transparent with families regarding that

Trenna explains, “*We don’t know everything*.”

- Families want to find a diagnosis
  - It helps because it’s scary when you don’t know what’s happening
- Trenna walks them through these labels and diagnoses

**⇒** The risk is that they can see someone in her field and they do testing and give a diagnosis

- She sees kids come in with a report
- For example, this child has ODD
- She’s like, “*Okay, well what does that mean? What are we going to do about it?*”

***This comes back to how do we create treatment plans?***

- If you’ve met 1 child with ODD, you’ve met 1 child with ODD
- She doesn’t even know what to do with that
- There’s no treatment for ODD
- If she knows the child has impulsivity, she can treat that
- If the child has social difficulties, she knows what kind of treatment plan to create there
- If the child is anxious, she knows what type of therapies to give

> “*It’s really important to think about the why.*”‒ Trenna Sutcliffe

**It’s not just about the diagnosis, it’s about the journey afterward**

- When Trenna left the traditional medical model and started her [clinic](https://www.sutcliffeclinic.com/), this is one of the things she wanted to remember
- It’s really about personalized care

***You can make such a big difference in child development, human well-being by really understanding that specific child***

- Unfortunately sometimes when you’re on the treadmill in a medical model, it’s really hard to have the time to really get to know a child
- Trenna felt like she was [saying to patients], “*You have autism, here’s a list of 15 recommendations, good luck. And you have ADHD. Here’s a list of 15 recommendations. Good luck*.”
  - Without really getting to know the why behind that child’s behavior
- Peter is trying to think about how you compare this to adult psychiatry where psychologists and psychiatrists who really help people tend to focus less on their DSM-5 (in this case) diagnosis
- They use that if there’s a diagnosis there
  - We should know what it is
  - It paints the contours of what we think about
- As Peter’s friend [Paul Conti](https://drpaulconti.com/) always talks about, he’s like, “*If you don’t know their story, you can’t really help them*.”
- Now, that doesn’t mean that knowing their story precludes using pharmacologic agents when appropriate, but what it means is **you have to really understand the root**
  - Is this a response to trauma?
  - Is this a response to an underlying biologic condition?

Peter feels like adults seem to have more access to that kind of mental healthcare than children do, and asks, “*Is that a misperception on my part?*”

- No, Trenna agrees
- She doesn’t think we’ve done enough in pediatrics in this area

***You have to know the story and understand the whole child***

## Defining developmental-behavioral pediatrics (DBP), and Trenna’s professional journey [1:07:00]

**DBP is a very young specialty**

- Trenna was the first person at Stanford in [DBP](https://dbpeds.stanford.edu/); she created the group
- Developmental pediatrics was only recognized as a subspecialty by the American Board of Pediatrics in 1999
- A key thing about this field is it’s what we call a **biopsychosocial specialty**
  - What that means is we think about the **biology**: the genetics, the brain, the biology, the medication
  - The **psycho part** is the mental health piece
  - It’s the idea of, to support child development and behavior, you need to consider the physical well-being as well as the mental well-being
  - And then the **social piece** is the fact that we don’t live in isolation
    - We live in communities, we live in dynamics
- In order to help kids with their development and behavior, what better way to promote human well-being and health than to start early on and impact child development and behavior and self-esteem and learning

**⇒** The way to do it is you not only think about the biology, you think about the mental health and you think about the social (which is about family dynamics, parenting, school and education)

> “*This is the bridge between education and medical health, which honestly is hard to do in the traditional medical model (bridging to education), but it is really, really important.*”‒ Trenna Sutcliffe

- That’s where our kids are learning and developing and growing and exposed to experiences

***DBP looks at that whole picture, and that is the way to support child development and behavior, whether there’s a diagnosis or not***

**Trenna’s journey**

- Her husband got to Stanford in 2004 and she went there in 2005
- She did her DBP training at [The Hospital for Sick Children](https://www.sickkids.ca/) in Toronto (she’s Canadian)
  - It’s probably 1 of the 3 largest children’s hospitals in the world
- It was an incredible place to train with the volume of cases and complexity of cases
- She did pediatrics, pediatric neurology, and developmental-behavioral pediatrics
- Her interests and passions were always genetics, the human brain, development, neuroplasticity
- She did a lot of research in neuroplasticity, and then 20 years ago, moved to California in the Bay Area and took a job at Stanford
- The field of DBP was brand new, just starting out
- They did not have a developmental-behavioral pediatrician yet at Stanford
  - She was the first there
- After her, they hired an incredible developmental pediatrician by the name of [Heidi Feldman](https://profiles.stanford.edu/heidi-feldman), who then created the division of DBP at Stanford
  - She’s still there and they have a fantastic group there now
- When Trenna arrived, there was nobody else
- She was at Stanford for a number of years and did research, clinical work, as well as medical education teaching
- After that she focused on the clinical piece
- She went to a large clinical organization, did clinical work
- 10 years ago (in 2014), she decided to leave the traditional model and start her own multidisciplinary clinic

**What was happening prior to 2014 that you didn’t enjoy?**

- She felt that she could help families and patients more and/or differently
- She wanted to make an impact
- She felt that she was stuck in the model, and it’s just the medical model

*What she valued*

- Promoting health and well-being that’s all about DBP, development and behavior

> “*It’s about promoting health where medical centers have been in the past primarily focused on treating disease*.”‒ Trenna Sutcliffe

- She really believes in multidisciplinary teams and having an integrated team in this area
- Understanding the whole child requires not just a physician, requires therapists, psychologists, teachers, different types of professionals
- And to make a difference, those professionals have to be integrated

Trenna explains, “*If you want a touchdown, all the players need to be reading the same playbook*.”

*The problem with what she was seeing*

- A lot of the families would see her in the medical center as the doctor, but there was the school and the therapist
- They all had these different silos, and Trenna wanted to bring the silos together

**Trenna believes in community collaboration**

- The bridge to education
- That is really hard to do in a standard medical model
  - To have a collaboration with the schools
- Now, she does school observations
- She goes to IEP meetings
- She works with teachers in classrooms to see what the kids look like at school

**⇒** She believes that the family is the patient, not just the child; and to make a difference in a child’s life, she works with the parents

- It’s amazing how powerful parenting can be
- Training parents, this is the social piece, the dynamics, understanding the whole family situation is really important to make a difference in a child

*Trenna loves learning and being innovative and thinking outside the box*

- She decided to set something up where she can continue to ask questions and challenge the system and try to make it better

**Trenna’s team has 25 people**

- They have a few different programs
- They have a behavioral team focuses mostly on kids with autism
- About 20% of the kids who work with them don’t have a diagnosis of autism
  - They benefit from behavioral therapy, social skill groups, parent training that focuses on behavioral models
- They have a mental health therapy team that supports kids and teenagers with anxiety, depression
- They offer different types of therapy for that, mood dysregulation, ADHD
- They have psychologists who do testing for diagnostic assessment
- They have a medical team, but it’s not just giving medicines
- She does prescribe medicines, but that is a portion of what she does

Trenna explains, “*I look at the whole child and it’s really understanding the therapies, the parenting, the school piece, and medication (when it’s important and can help).*”

## Updated methods of ABA (applied behavioral analysis) therapy: evolution, controversies, challenges of scaling autism care, and the need for tailored interventions [1:13:45]

**There’s something called ABA. Describe what that is and why it’s so polarizing in the field of autism therapy**

- Applied Behavioral Analysis
- ABA means a million things these days, just like autism means so much as well
- ABA is a behavioral intervention that traditionally has been used with kids with autism

**⇒** It is about taking a skill and breaking it down into smaller sets, smaller subsets

- Traditionally it was very direct, adult-directed, repetitive, working on a small skill
- All these small skills add up to a bigger skill

*For example, it might be something to do with greeting someone*

- An appropriate greeting would be integrating verbal as well as eye contact, as well as maybe turning your body towards the person
  - When you greet them, when you meet a new person
- For someone with significant autism, that’s difficult and they need to learn how to turn their body and make the eye contact and do the vocalization and how to integrate that
- For that skill, you’d work on the different subsets
- You might be first working on if you want to greet someone and acknowledge them, you’re first going to look at them and have that joint attention
  - So you’re going to teach a child how to make eye contact
- Initially we did ABA with something called **discrete trial**, and that’s why it’s controversial
- Discrete trial is still used today and can be very helpful with it’s combined with more naturalistic forms of ABA

***Discrete trial would be about teaching a child to make eye contact and they get a reinforcer every time***

- So make eye contact, get a positive reinforcer
- So it’s positive reinforcers; it is a lot of repetition, practicing teaching a child a new skill
- You would add the other layers to it: the eye contact and then the greeting and the vocalization, turning your body
- You would add all that together to come up with this larger thing of how do you approach someone?
- Discrete trial has been around for decades
- That’s the part that’s controversial because people say, “*Oh, this is very repetitive and it’s not based on relationships*.”

*Over the years there have been more naturalistic ABA methods created*

- Naturalistic in that it occurs more in a child’s natural environment
- It is not just at a structure table where you and I are practicing eye contact, natural environment
- Also trying to understand the child’s natural motivators
- For example, it might happen at a park and it might happen that we know that child loves to be on the swing
- So rather than sitting at a table and me saying, “*Make eye contact, here’s your reinforcer, make eye contact. Here’s your reinforcer*.” Now we’re at a park
- We’re going to help this child learn that if you want me to push you on the swing, you got to look at me and somehow acknowledge me, so I go push you
  - Otherwise, I don’t know that you want to be pushed on a swing
  - That’s an example of a more naturalistic form

**One of the most naturalistic forms is something called pivotal response treatment (PRT)**

- This is actually training the parents in these skills because that’s really what it’s about
- It’s not about whether this child can make eye contact with therapist A at the table
- It’s about how does this child understand how to use eye contact, when it’s appropriate to use it, and the power of it in natural settings
- When you train the parents how to do it, then they can practice at the park, at the coffee shop, on the playground
- That is the most naturalistic form, teaching the parents

***This comes back to how powerful it is if you teach parents, but parents work with the child in a natural setting with natural motivators***

**Are there limitations to treatment in families with single parents?**

- Yes
- It’s time and resources and driving to therapies
- It depends on how significantly impaired your child is and how many therapies they need

**Peter is just trying to understand what the socioeconomic toll is**

- He thinks about that in multiple ways
- What is the typical cost of therapy?
- How much of this cost is covered by insurance?
- How much of this cost is embedded within the school program?
- An IEP is included if a kid’s in public school

*Is ABA therapy or PRT or any of these things covered by insurance companies for kids?*

- They can be
- It depends on the state
- In California, ABA is covered if you have a diagnosis of autism
- That’s where the diagnostic piece is important

**What about the impact of other siblings?**

Peter asks, “*Is there anything that you’ve noticed about the nuances around if a kid has an ASD diagnosis and they have other siblings that don’t have diagnoses or they do and where they are in birth order and just trying to understand the overall family environment and how it pertains to treatment?*”

- She could say so many things about that
- First, the siblings of children with autism are themselves at risk for either autism or autism-like traits or something called the broader autism phenotype
- They may actually not have autism, but they may have a few traits of it and/or at risk for other developmental disabilities
- Kids who are siblings are also at risk for language delays, anxiety
- They have a predisposition to have some developmental differences

*How much of that is based on the fact that this is largely a genetic condition?*

- If they’re siblings, they share genetic traits, even if they don’t have all of them

*How much of that is siblings developing traits in response to anything from mimicking the sibling with autism to responding in frustration to the behaviors of the kid with autism?*

- There is a **big genetic piece** to this
- They truly do have these conditions: language delay, autism traits, ADHD
- Very often you see a sibling with one of those other conditions and there’s that genetic piece
- But you’re right, there’s a **behavioral component**: coping component, anxiety component that may be related to family stress, attention-seeking behavior
- At the same time, Trenna also sees the opposite
  - She also sees many siblings who have incredible empathy for people who are different because they have a sibling who has a developmental disability

**Peter’s takeaway on ABA** ***‒ it’s not good or bad, it’s just another tool in the tool bag and it has elements that are valuable if applied in the environment of the child***

- Trenna recommends ABA
  - She offers it
  - It should be part of a child’s treatment plan
- The tricky part is you want it done with people who are well-trained, who understand autism and who understand behavioral therapy well
  - That’s why it’s sometimes controversial, because there is such a huge demand for therapy for kids with autism because the numbers are so high, it’s hard to find enough people to provide therapy
  - Also, it’s an industry: there are people who take jobs in this industry who actually are not well-trained or well-supervised or [don’t] really understand the nuances
    - Because if you know one child with autism, you know one child with autism
    - And if you’re just following a recipe, you might run into people, therapists who are not making a huge difference and are not that helpful

**What is the current size of the autism treatment industry and how does it compare to what it looked like 20 years ago?**

*In other words, has it grown commensurate with the increase in the prevalence, or is there a greater burden on the per capita therapist today?*

- There’s a burden
- Trenna doesn’t know the exact numbers, but it’s grown and growing
- It’s scaling, and when you scale, you dilute
  - You run into issues with quality

## Advice for parents trying to find and evaluate care for children with autism, ADHD, or anxiety [1:22:45]

- Start first with your pediatrician
- Your hope with the pediatrician is that they are able to connect you to resources in the network because you really need to find a team

***It’s finding a team***

Peter asks, “*How likely is that?*”

- It’s hard
- If you don’t live in Boston or San Francisco or the major cities, this multidisciplinary approach is not easy to find

**What are the options? What is the next best thing?**

- Try to create your team
- This is so stressful for a parent who’s in a situation like this, they don’t know anything about this
  - For families who speak a different language and don’t have higher education, this is a disaster
  - But even for families who are well-educated, trying to understand and quarterback this is difficult
- Basically you need a quarterback to help you decide
  - Is this ABA helpful or not?
  - Should I be focused on speech and language therapy or ABA therapy right now?
  - What should I be advocating for at my IEP meetings?

> “*You really need someone to help you with that roadmap. We need to help families more with that*.”‒ Trenna Sutcliffe

- Trenna thinks of herself as a Sherpa guiding people along this journey

***It’s the roadmap, and every year we pivot and turn: where should we spend more time?***

- Is it in social skills groups?
- Is it speech therapy?
- What should we be asking for?
- When you’re looking for somebody, it may not be a doctor
  - It might end up being a really good ABA therapist or a psychologist in your community who can help connect you
  - There are state programs

***One size does not fit all; make sure they have the philosophy***

**What to look for in a provider**

- 1 – This person needs to understand personalized care
  - They don’t just give the same treatment recommendation, same thing to every single child
  - It’s not black and white
  - You need to make sure that that provider is flexible in their thinking and their treatment approach so that they can provide individualized care
- 2 – This person would be proactive in helping you create some sort of team
  - It may not be a team like Trenna has under one roof, but they’re open to the idea of collaboration meetings with the child’s speech therapist or teacher
  - They will also be proactive in arranging collaboration meetings maybe once a season
- 3 – This person is someone who has skills in the parent training piece
  - That’s a really important piece
  - It’s not just parent education
  - It actually is parent training, because Trenna has seen that really make a difference
- Peter thinks this is a great list

**Peter is thinking about this through the lens of: how do you scale what you are doing?**

- You could just keep replicating a model that looks like Trenna’s, a really big multidisciplinary model
- But that can only be supported in a certain geography
  - You’re not going to be able to put that in every town
- Yet it seems unlikely that this is a condition that discriminates by geography, and therefore half of the kids in this country that have any of these conditions are going to be in areas where they’re never going to have large turnkey, multidisciplinary offerings
  - So their parents are going to have to do the heavy lifting

*Back to the cancer analogy*

- Unlike cancer, if a child gets cancer, a parent and family can go to another city for treatment
- But this is not something you’re going to go and do in another city
- It has to be an integration into your life where you are

> “*This isn’t a quick thing. This is years. This is a journey. And the whole point is to have it integrated and generalized in the child’s life*.”‒ Trenna Sutcliffe

- Getting ABA in some structured clinic is not the goal

***The goal is to have a child showing us these skills in real life, in their real life, in their classroom***

## Tailored treatments for ADHD: balancing stimulant medications with behavioral training [1:28:30]

**What percentage of the children that present to your clinic with a diagnosis of ADHD plus or minus anxiety require pharmacotherapy in your clinic and your experience?**

- Before answering this, Trenna emphasizes that kids who come to her clinic with ADHD often come to her because it’s more complicated than straightforward
- There’s a selection bias to her clinic
  - If this were straightforward, they wouldn’t be coming to her (hopefully their pediatrician could manage it)
- The percent of kids who are treated with medication depends on the age of the child and the severity of the ADHD
- For younger kids in her clinic (preschoolers), she will use behavioral interventions first
- She sees preschoolers who have been asked to leave multiple preschools because they’re hyperactive
- Although you could technically make the diagnosis in the preschool years, Trenna shares with families, “*We’re probably going down this path (whatever we’re going to call this in the next couple years), let’s start working towards helping your child build skills to regulate, manage their hyperactivity, manage their impulsivity*.”

**⇒** First line treatment for ADHD in kids under 6 is [behavioral parent training](https://en.wikipedia.org/wiki/Parent_management_training)

- We may or may not need to add a medication

**⇒** The guideline for 6 and older, first line treatment is medication plus behavioral parent training

- Medication makes a big difference
- Medication can be very, very helpful and Trenna reads the family where they are at on this journey and their family values and how they’re processing the information
  - She listens to their questions and concerns and she builds trust
- Sme families are ready to start medication right away
- Other families have questions

***Most often we do move towards medication because we know it helps***

**What about the people who say…**

- They’re going to be people who understandably come at this and are really judgmental
- Their narrative is going to be the following, “*These goddamn preschools trying to tell me a kid has ADHD. Maybe it’s because the preschool is just overcrowded and the people who work at the preschool are too lazy to actually let these kids play, let kids be kids. There’s nothing wrong with a kid that’s hyperactive. You just got to give him more to do, blah, blah, blah, blah, blah, blah. This is sacrilege that we would ever give a child medication just because they’re hyperactive.*” (that’s a narrative)
- Peter doesn’t think this is a lot of people
- If they’re sophisticated, hopefully they would not make a judgment like that without understanding the fact base a little bit more

*Would you agree that the best argument against that logic, is an argument that says you have to weigh the pros and the cons of being unmedicated, and what the impact on your education is going to be, and the long-term success you’re going to have as an adult versus the accepted risks of any medication? And the potential upside it has towards allowing that child to learn?*

- Peter likes Trenna’s framework: what is the adaptation of the condition (the phenotype)?
  - If it’s disruptive
  - If this is a difference in a child’s education
  - If this is a difference between a kid going to college and not
  - Or being successful in their career or not
  - Or having pro-social relationships versus not

***Trenna loves all these points because is it a risk-benefit ratio that you have to consider***

> “*You have to consider there’s risks in everything we do. There’s risks in all medications. There’s risks in everything*.”‒ Trenna Sutcliffe

- When she is working with a family, she talks to them about the research
- We have a lot of research around safety and long-term outcome and the outcome of individuals with ADHD who are left untreated

**More importantly, Trenna gets to know their child**

- It is the idea about her going and watching the child in class
- Talking to the teachers
- Getting to know that family more, really understanding
- People come to see her for a reason: if things were great, they wouldn’t come to see her
  - Even if initially maybe it was the school who said, “*Your little guy is way too busy and you need to see a doctor about this.*”
- When she gets to know the family, she finds out: well actually dinner is really stressful and bedtime routine is really stressful
  - Everyone’s in tears in the morning
- She gets to know them and it’s actually that personal part that helps them understand their child and they come back to self-esteem and interpersonal-[relationships]
- Their kid is not a statistic to her

**Sometimes she doesn’t use medication**

- If the child doesn’t need it, she’s not going to use it
- Although we know that medication can make a really big difference

**What medications are in your toolkit in that world?**

*Is* [*Vyvanse*](https://en.wikipedia.org/wiki/Lisdexamfetamine) *still used? Is* [*Ritalin*](https://en.wikipedia.org/wiki/Methylphenidate) *still used? Is* [*Focalin*](https://en.wikipedia.org/wiki/Dexmethylphenidate) *used?*

- Peter has discussed this on previous podcasts [episode [#270](https://peterattiamd.com/andrewhuberman2/#:~:text=It%E2%80%99s%20counterintuitive%20that%20a%20stimulant%20would%20be%20a%20treatment%20for%20someone%20with%20difficulty%20focusing%C2%A0)]
- ADHD medicines, we’re talking stimulants and non-stimulants
- First-line treatment considered is stimulants
- Within stimulants, we have 2 different medications: methylphenidate and amphetamine Methylphenidate
- We have many brands of [methylphenidates](https://en.wikipedia.org/wiki/Methylphenidate): Ritalin (which has been around since the 1950s), Focalin, Concerta
  - They differ in how the medication is released (the timing of release and pharmacokinetics)
  - It’s the same active ingredient
  - Interestingly, kids respond differently because the release mechanisms are different
    - Some kids are sensitive

**Peter’s takeaway**

- If a kid comes to you and tries one of these and you don’t get the response you want, you don’t necessarily abort the entire molecule
- You might switch to a different formulation
- Peter has spoken with many parents who have said, “*My kid was on Ritalin. It was a disaster. When they switched to Focalin, it got so much better.*”

Trenna explains, “*There’s no science unfortunately to tell us which one, which one is going to work for your child. So you have to basically try a few.*”

**Amphetamines for treating ADHD**

- That’s [Adderall](https://en.wikipedia.org/wiki/Adderall), which has been around since the 1930s, [Vyvanse](https://en.wikipedia.org/wiki/Lisdexamfetamine), [Dexedrine](https://en.wikipedia.org/wiki/Dextroamphetamine)
- The difference between Vyvanse and Adderall is release and kinetics
- Vyvanse is called a prodrug: it’s actually got a little molecule attached to it that needs to be cleaved in order for it to work
- But they’re all the same

**It’s very counterintuitive to people why you take a hyperactive kid and give them a stimulant. Do you want to just give a brief overview of why that works?**

**⇒** The way these medications work is they increase dopamine and norepinephrine in the synapses between the brain cells in the parts of our brain that are important for executive functioning, attention, inhibiting impulses

- The prefrontal lobes is the part of the brain where all the executive function attention happens
- Our brain cells have to communicate in order to see that behavior, attention
- These medications, although they’re called stimulants, what they do is they increase the levels of dopamine and norepinephrine in these synapses, the gap between the neurons, and they improve the electrical activity and communication between brain cells

**What are the most common side effects you caution parents about with these drugs?**

- The side effects can be annoying, but they’re not life-threatening
- The most common one is decreased appetite at lunchtime if you’re taking a medication that lasts the whole day
- There are medications that last 3-4 hours
  - We used to use those a lot a couple of decades ago when Trenna first started doing this
- About 20 years ago, we started using extended release a lot more
- Extended release lasts 8-10 hours or 12 hours a day
  - Those medications impact your **appetite** at lunch; breakfast and dinner are usually fine
  - It can impact **sleep onset**, and if that’s a problem, we adjust the timing of the medication in the morning

Peter asks, “*These are generally single administration first thing in the morning*”

- Yeah
- They’re really easy to use because you take it in the morning, the extended release will start to work within an hour, and then they’re working for the majority of the day.
- Then they come out of your system at the end of the day
- And so tomorrow, unless you give the medication to your child again, it’s like they’ve never been on it

**What are the differences then between the Ritalin class and the Adderall class?**

*Do you have any suspicion one way or the other as to which is going to be more effective if you were to prescribe Focalin versus Vyvanse?*

- When she first meets a young child, she generally starts with methylphenidate
- The reason for that is that the meta-analyses show that kids tolerate methylphenidate a tiny bit better than amphetamine
- Although amphetamine is a little bit more bang for your buck when you’re treating the symptoms
- That being said, every kid is different
- She has just as many kids on Adderall as she has on Ritalin

***Trenna uses every single brand out there, but she starts with methylphenidate because it’s shown to be tolerated better***

## The interplay between medication, behavioral therapy, and neuroplasticity in managing ADHD, and the potential to grow out of the need for medication [1:39:45]

**More about behavioral therapies**

- Peter goes back to something Trenna mentioned a second ago: if your kid’s been on this drug every day for a year and experienced all these benefits and then they come off the drug, it’s like they were never on the drug
- He is concerned that in the “drugged state,” you don’t get to do behavioral therapies that also have a positive impact independent of the drug
  - If the drug comes off the phenotype is changing
  - Is that not to be expected?

***Trenna wants kids to be practicing skills when they’re on the medication***

- Peter thinks in theory, they should be able to do a better job; it should be easier for them to practice the skills on the medication

*In addition to that, this is where the* [*behavioral parent training*](https://www.sutcliffeclinic.com/behavioral-parent-training-bpt-for-adhd) *part comes in: training specifically for family, not just the child*

- It’s amazing how powerful parents can be in modifying the behavior of their child

**⇒** Parents undergo the training and the child might undergo some sort of therapy, regulation group

- When the child is older, they undergo executive functioning coaching to learn organization and planning

**The benefits of practice**

- When we practice something over and over and over again, not only do we develop new behavioral patterns, new habits, we actually positively impact the developing brain ‒ that’s neuroplasticity (one of Trenna’s passions)
- We impact the brain through experience and our behaviors
- So when a child has ADHD, it is a wonderful time to practice new skills and you actually impact neural networks

**How long do patients need to take medication for ADHD**

Peter asks, “*Does that mean that you’re telling parents, or at least holding out a hope that, “Hey, your kid is seven or eight years old. We’re going to put them on Ritalin. This might not be a lifetime thing.”*

- Trenna doesn’t commit
- Peter gets asked that question all the time he puts patients on medication
  - If he puts patients on a lipid-lowering medication, generally their first question, once you get through the why should I be on this and what are the side effects etc. is, “*Am I going to be on this for life?*”
- She tells families that she doesn’t have a crystal ball, but she has many patients who do eventually come off medication and do really well

Peter asks, “*Is it naive to think that because ADHD primarily impacts the prefrontal cortex, that you would see at least a subset of people when they reach their late teens as girls and mid-20s as boys, when they reach maturation of that part of the brain that at least a subset of them should be able to develop potentially the skills to overcome the genetic component of this, or is that not necessarily correlated?*”

- No
- Trenna sees a lot of kids who do find strategies to compensate and who no longer need their medication as teenagers or young adults

**⇒** It’s really important that they start early: developing strategies and new behaviors

- Starting early is really important in strengthening those neural networks

**Non-stimulant class drugs that Trenna uses**

- [Strattera](https://en.wikipedia.org/wiki/Atomoxetine) also acts on norepinephrine and increasing the norepinephrine levels in the synapses
- There are a couple of old blood pressure medications we use: [guanfacine](https://en.wikipedia.org/wiki/Guanfacine) and [clonidine](https://en.wikipedia.org/wiki/Clonidine)
  - Those are alpha-2 agonists
  - They act in a different way: closing channels in the postsynaptic neurons

**⇒** All of those medications help with the communication between neurons in the attention center in the brain. The difference is that the non-stimulants have to be taken every day in order for them to work. So meaning they’re taken every day and you need a steady state in your body.

- Unlike the stimulants, you need a steady state of non-stimulants in your body to work
  - So they need to be taken every day

**Do you ever mix these 2 classes of drugs, or is it one or the other?**

- She often mixes them
- Non-stimulants do not have the side effects with poor appetite, and sometimes they can be really good with kids who have some emotional dysregulation, impulsive emotions

## Using medication to treat anxiety and other symptoms in kids with autism without ADHD [1:44:45]

**Are there any medications that typically show up in kids with autism but without ADHD?**

*Kids with autism ± anxiety*

- There’s no medication that treats the core symptoms of autism
- The core symptoms don’t require medication; [treatment] is therapy
- We use medication in kids with autism to treat target behaviors and symptoms
  - So we use medication for the symptoms no matter the label (autism, ADHD, etc.)

**Peter’s takeaway ‒** ***There are kids with autism that are going to be on medications and it’s really just a function of the symptom (you don’t need a diagnosis to decide)***

**Target symptoms usually treated in kids with autism**

- She’ll use stimulates to treat attention, hyperactivity, and impulsivity
- For challenges with emotional regulation, she’ll use a non-stimulant
- She may use an anxiety medicine, a [selective serotonin reuptake inhibitor (SSRI)](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) such as [Prozac](https://en.wikipedia.org/wiki/Fluoxetine) or [Zoloft](https://en.wikipedia.org/wiki/Sertraline)
- Sometimes she also uses that for rigidity
- Kids with autism who struggle with rigidity and transitions, it’s often anxiety related
- For kids who have really aggressive behaviors who may injure themselves, they’ll use atypical antipsychotics
  - She doesn’t use a lot of those
  - If the child is having those difficulties, she often works with a psychiatrist

## FAQs about medicating children with ADHD: benefits, side effects, dosage, and more [1:46:30]

Peter adds, “*I think it’s just got to be so hard for parents to potentially stomach putting children on psychiatric medication. But what you said earlier is interesting, which is most of them are coming back after saying, ‘I wish we did this sooner,’ which I suppose would be the most affirming thing you could ever hear in that situation.*”

**What are the things that parents typically notice after they start their child on medication, and how long does it typically take?**

- With **stimulants**, you see the benefits right away
- Parents are often like, “*We’re glad we did this and this is making a big difference*.”

*Let’s say the kid is a 7- or 12-year old who can articulate their feelings. What do they come back and say to you?*

- It helps them with their focus
- They feel more successful at school
- They share side effects

**What other side effects do they complain of besides appetite suppression?**

- Sometimes high school students will say they feel less social and funny when they’re taking their ADHD medication
- They’re less impulsive and spontaneous
- Trenna will talk about that with them; it’ doesn’t have to be black and white, all or nothing

***The goal isn’t to make someone 100% focused 100% of the time, we want to improve focus***

- When she has people come to her with side effects, she will change the dose or change to a different medication
- The key thing is having a relationship between the doctor and the patient
  - Lots of communication and the idea that if the patient is experiencing side effects, that they tell somebody so that you can adjust, you change the dose, you change the timing, you change the brand

## The “superpowers” associated with level 1 autism [1:48:45]

- You hear this phrase from time to time, which is that kids with autism have superpowers
- For example, you might think of Dustin Hoffman’s character in [Rain Man](https://en.wikipedia.org/wiki/Rain_Man)
  - Obviously he was highly impaired for most of life, but he clearly had a superpower
  - He could count cards and toothpicks
  - That’s the Hollywood version of that

Peter asks, “*Is there truth to this idea that kids with autism have superpowers or is this something that you would put more brackets around and say, well, sometimes those kids who are in* [*class 3*](https://en.wikipedia.org/wiki/Autism#:~:text=DSM%2D5%20uses%20a%20%22level%22%20system%2C%20which%20ranks%20how%20in%20need%20of%20support%20the%20patient%20is%2C%20level%201%20being%20the%20mildest%20and%20level%203%20the%20severest) *where they’re really impaired, maybe there’s something there, but it’s a lot harder to see than the kids in class 1 , for example?*”

- It is
- There is a difference between class 3 versus class 1: it’s harder to see in class 3

*Class 1 [aka* [*level 1*](https://en.wikipedia.org/wiki/Autism#:~:text=DSM%2D5%20uses%20a%20%22level%22%20system%2C%20which%20ranks%20how%20in%20need%20of%20support%20the%20patient%20is%2C%20level%201%20being%20the%20mildest%20and%20level%203%20the%20severest)*] has a lot of superpowers*

- Memory could be one of them
- Attention to detail
- Really good with remembering rules and following routines or a set order of operations
- There are a lot of famous people (who Peter won’t name) who have talked about themselves as having mild forms of autism, Asperger’s
- You would almost think that it’s predisposing them to some of their greatness in fields their trained in, often very technical fields
  - Trenna agrees
- More of a predisposition towards engineering, technical fields, STEM in general
- Trenna calls it a learning profile, a thinking profile
- **What may not be their strength**: things where you need a little bit more abstract inferring, or the social piece
- **What they do really well in**: things where you need to dive deep into some details, persevere and stick with something, hyper-focus on something

***A lot of people, once they find their passion as a young adult, they can dive deep and do really well***

## The next steps to increase support for children with ASD, anxiety, and ADHD [1:50:45]

***What do you think is the most important thing you want people to understand about anxiety, autism, ADHD that you think is either misunderstood or not understood at all?***

- There’s a lot of overlap
- Sometimes people get stuck on the label (the name) and don’t actually see the person beneath that name
- You need the diagnosis to get resources
- This is a field where there’s a lot of gray, it’s a moving target
  - We’ve changed the names and the definitions multiple times the last couple of decades, and it’s probably going to change again
- We need to be flexible with our thinking that the definitions might change

Trenna explains, “*There are these learning styles. And so if you’ve met one person with one of these names, you’ve met one person. And it’s really important to understand that person in order to help them with leveraging their strengths, and then understanding what kinds of gaps you want to fill and what kinds of skills you want to work on.*”

- Peter has found this discussion to be fascinating
- His only frustration is the concern that there aren’t enough people like her and her colleagues to match the psychological burden of these conditions across kids today

**Are you optimistic that 10 years from now, this model is going to be different, there are going to be more people that are going to want to come to practice this in the way?**

- We need to get more people to go into these fields
- We also need a better payer reimbursement structure to incentivize more people around a multidisciplinary approach
- We need to think about how to use and recruit people who are going to support, for example, the developmental-behavioral pediatrician (DBP) or the psychiatrist or the psychologist
  - For example, we need more DBPs, but we also need then more nurse practitioners or other allied professionals who can support the team
- It’s being creative and innovative with how you create the teams and find enough people to be on these teams, but then how it’s reimbursed and making sure there’s access to these teams will be really important
- Trenna believes the bridge to education is important as well
  - Which is not something that is part of an insurance model

**Do you think that the burden of paying for this is disproportionately on the healthcare system today and it should be a shared burden with the education system?**

- Peter is not saying that to be critical of the education system
  - They would need funding and resources to do this

*The question is, is that part of the issue that you’re always going to see these things manifested in the education system and that’s where you’re going to get the most bang for your buck when you address them?*

- Trenna goes back to the bridge
- The insurance, they’ll say that parts of this intervention are educational, so they’re not responsible for it
- Then the educational people will say that this part is this medical thing and it’s not actually interfering with the classroom

***You need to realize, to help that child move the needle, you have to have both systems working and talking together and collaborating***

> “*It’s a totally different system, but I really believe in bridging education, mental health and medical. If you want to make an impact on child well-being and health.*”‒ Trenna Sutcliffe

---

## Selected Links / Related Material

**Trenna’s clinic**: [The Sutcliffe Clinic](https://www.sutcliffeclinic.com/) (2024) | [1:00, 4:45, 1:05:15]

**Episode of *The Drive* that touched on using stimulants to treat ADHD**: [#270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific papers](https://peterattiamd.com/andrewhuberman2/#:~:text=It%E2%80%99s%20counterintuitive%20that%20a%20stimulant%20would%20be%20a%20treatment%20for%20someone%20with%20difficulty%20focusing%C2%A0) (September 11, 2023) | [1:34:30]

---

## People Mentioned

- [Paul Conti](https://profiles.stanford.edu/heidi-feldman) (Psychiatrist, consultant, author; specializes in trauma; previous guest on *The Drive*) [1:06:15]
- [Heidi Feldman](https://profiles.stanford.edu/heidi-feldman) (Professor of Developmental and Behavioral Pediatrics at Stanford) [1:09:45]

---

![](https://peterattiamd.com/wp-content/uploads/2025/01/treena-sutcliffe.webp)

##### Trenna Sutcliffe, M.D., M.S., F.R.C.P.C, F.A.A.P.

Trenna Sutcliffe earned a bachelor’s in molecular biology and medical genetics from the University of Toronto. She continued there earning a master’s in medical biophysics before completing her medical degree at McMaster University in Hamilton, Canada. Trenna did a residency in pediatrics followed by pediatric neurology. She then did a fellowship in developmental pediatrics at The Hospital for Sick Children, University of Toronto. Next, she moved to Sanford University where she completed a master’s in health research and policy. She worked at Stanford for a number of years as a developmental-behavioral pediatrician (DBP) and instructor in the Department of Pediatrics. After which, she worked at the Palo Alto Medical Foundation in Los Altos, California as a DBP. In 2014, she founded the Sutcliffe Clinic in Los Altos, California and has worked there as the medical director ever since.

Dr. Sutcliffe’s clinic provides personalized medical care for children and families with developmental and behavioral concerns. They implement evidence-based interventions and comprehensive support to help children thrive. They focus on a child’s strengths, teaching essential skills, involving parents, and empowering families to promote the well-being and development of the child. Dr. Sutcliffe specializes in treating children with autism spectrum disorder, ADHD, anxiety, and developmental delays. [[Sutcliffe Clinic](https://autismpediatrician.com/)]

Blog: [Sutcliffe Clinic Blog](https://www.sutcliffeclinic.com/blog)