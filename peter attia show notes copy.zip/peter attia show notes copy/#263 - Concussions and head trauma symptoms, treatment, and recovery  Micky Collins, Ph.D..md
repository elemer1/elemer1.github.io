# #263 ‒ Concussions and head trauma: symptoms, treatment, and recovery | Micky Collins, Ph.D.

**Source:** [https://peterattiamd.com/mickycollins/](https://peterattiamd.com/mickycollins/)

---

Michael “Micky” Collins is an internationally renowned expert in sports-related concussions and a consultant for multiple professional sports organizations. In this episode, Mickey first explains the definition and diagnosis of a concussion, as well as the diverse signs and symptoms associated with different types of concussions. He discusses the risk factors that contribute to increased susceptibility and/or severity of concussions in certain individuals, emphasizes the significance of prompt treatment, and uses case studies to illustrate the latest in treatment protocols and recovery process. Additionally, Mickey provides insight into the evolving field of concussion treatments, including the exploration of hyperbaric oxygen and synthetic ketones. He gives advice to parents of kids who play sports and discusses the promising prospects in the realm of concussion management.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/mickycollins/the_Drive_public.png)

Play

#263 ‒ Concussions and head trauma: symptoms, treatment, and recovery | Micky Collins, Ph.D.

#263 ‒ Concussions and head trauma: symptoms, treatment, and recovery | Micky Collins, Ph.D.

1x15s30s

0:001:21:25

## We discuss:

- Micky’s interest in concussion and how he started the first concussion clinic [3:15];
- Concussion: definition, pathophysiology, and risk factors making someone more susceptible [9:45];
- Symptoms of concussion, predictors of severity, and the importance of early and effective treatment [20:00];
- The six types of concussion, the effectiveness of treatment, and factors that impact recovery [25:45];
- The importance of seeing a specialist and the prognosis for recovery [30:00];
- Case study of a racecar driver who suffered a vestibular concussion [32:15];
- Why vestibular concussions are particularly problematic [42:45];
- A treatment plan for the racecar driver, possible use of medications, and how to address the root cause [45:45];
- Exploring alternative treatments: hyperbaric oxygen, synthetic ketones, and more [52:00];
- The natural history of a concussion if untreated and the effect, if any, of concussion on subsequent risk of brain disease [57:15];
- Chronic traumatic encephalopathy (CTE) [1:01:45];
- Advice for parents of kids who play sports: when and where to seek treatment for a possible concussion [1:04:45];
- Is there any evidence that the APOE4 genotype increases susceptibility to concussion or TBI? [1:10:15];
- The increased risk of concussions in older adults and a case study of a 90-year-old patient who suffered a head injury in a fall [1:11:15];
- Funding for concussion research and fellowship programs to train concussion specialists [1:15:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Dr. Michael ‘Micky’ Collins, an internationally renowned expert in sports related concussions
- Micky is the clinical and executive director of the [University of Pittsburgh Medical Center Sports Medicine concussion program](https://www.upmc.com/services/sports-medicine/services/concussion)
  - The largest research and clinical program focused on the assessment, treatment, rehabilitation, research and education of sports related mild traumatic brain injuries in athletes of all levels
- Micky has published more than 150 peer-reviewed research articles and was also the co-lead author of the CDC’s [Concussion Toolkit for Physicians](https://www.cdc.gov/TraumaticBrainInjury/index.html), an education standard for concussion management
- He is also co-founder of [ImPACT](https://impactconcussion.com/), the immediate post-concussion assessment and cognitive testing
  - The most widely used computerized sports concussion evaluation system that has become the standard of care in organized sports
- He has been instrumental in the development of numerous concussion management programs for youth, collegiate and professional sports leagues and teams
- Mickey is currently a consultant for several athletic organizations, including the Pittsburgh Steelers and the Pittsburgh Penguins
- In this episode, we focus the entire conversation around head trauma and concussions
  - The definition and diagnosis of a concussion
  - The signs and symptoms of concussion and the various types of concussions
  - We speak about the risk factors that can cause someone to be more susceptible to concussions or can cause more severe concussions in certain individuals
  - We speak about the importance of quick treatment and recovery from concussions
  - What to do as part of that recovery, whether the concussion is in a child, adult, or elderly person
- Lastly, we speak about what we know and don’t know about hyperbaric oxygen and synthetic ketones as treatments for concussion
- This was a really interesting episode for Peter
  - A lot of times he comes into podcasts having a pretty good handle of the subject matter, but that was not the case here
  - He came away from this far more optimistic and upbeat about the prognosis for people with concussions
- In the short time since this episode was recorded, Peter has already sent several people to Micky who have been suffering needlessly for so long post-concussion

## Micky’s interest in concussion and how he started the first concussion clinic [3:15]

**How did you come to study concussion?**

- When Micky went to college, he didn’t really know what he wanted to do in life
- He had a bunch of family members that were physicians and in the medical field
- He also went to college to play baseball as much as he did to be a student
- He was playing baseball his junior year and when his coach said, “*Micky, if you don’t declare a major today, you’re going to be ineligible.*”
  - He was taking a neuroscience course at the time and biopsychology, so he dove into studying biology and psychology
- He graduated college and knew he wanted to do brain behavior studies
- He got involved in a program at Michigan State University and earned his PhD in clinical psychology with an emphasis in clinical neuropsychology, which is the study of brain behavior
  - He took some medical classes through Michigan State as well as clinical psychology and neuroscience courses
- Two or three years into studying at Michigan State he realized he missed sports and wanted to combine traumatic brain injury in sports
  - No one had really done that before
  - There was no concussion speciality when he went to school

**Does this mean that if a patient has a concussion in a sport, and they saw a neurologist, that neurologist wouldn’t really have any particular insight on it?**

- This field did not exist when he was in school (‘97, ‘98, ‘99)
- When he arrived at UPMC (University of Pennsylvania Medical Center) he didn’t really know how he was going to make a living doing this
  - He didn’t know if he was going to be able to see patients
  - There was very little traction in anyone studying this topic (literally nobody)

***Micky started the first clinic in the world at*** [***UPMC***](https://www.upmc.com/services/sports-medicine/services/concussion)

- When he was getting into this, he knew he wanted to study concussion or mild traumatic brain injury, and he somehow wanted to involve sports

> “*It’s a hot topic now. At the time no one could care about it.*”‒ Micky Collins

- This was around the time that [football players] [Troy Aikman](https://en.wikipedia.org/wiki/Troy_Aikman), [Steve Young](https://en.wikipedia.org/wiki/Steve_Young), [Paul Kariya](https://en.wikipedia.org/wiki/Paul_Kariya) [NHL player], [Ricky Craven](https://en.wikipedia.org/wiki/Ricky_Craven) (racecar driver) and others started to talk about this topic of concussion
- Micky remembers watching [Al Michaels](https://en.wikipedia.org/wiki/Al_Michaels) on Monday night football talking about Steve Young’s concussion in 1997 (or ’96 whenever it was)
  - He basically said, no one knows anything about this injury
  - This topic is just a lot of speculation, but no one really understands about the injury
- At that moment, Micky said to himself, “*That’s what I can do*.”
  - Because it was a perfect marriage of brain trauma and sports, which is what he wanted to do for a living

**UPMC sports medicine concussion program**

- Long story short, he ended up having two mentors: [Mark Lovell](https://www.linkedin.com/in/mark-lovell-ph-d-facpn-a6a60833) and [Joe Maroon](https://www.neurosurgery.pitt.edu/people/joseph-maroon) (who’s a neurosurgeon
- At the time he was doing a fellowship at Henry Ford Hospital in Detroit, and Mark Lovell asked if he wanted to move to Pittsburgh
  - They were starting a big orthopedic sports medicine center and wanted them to do a concussion program
- Micky came to Pittsburgh with his mentors Mark Lovell and Joe Maroon, and the three of them started a [concussion program](https://www.upmc.com/services/sports-medicine/services/concussion) in 2000
- They had no patients, no one could care about concussion
- They started researching it slowly but surely and published many papers on it

**Study of college football players and concussion**

- Micky, Mark Lovell, and others published a big paper in [*JAMA*](https://jamanetwork.com/journals/jama/fullarticle/191533) in 1999 where they looked at college football and concussion at Michigan State University
- Micky always wanted to do research on college football players
  - He wanted to baseline test these guys if they had a concussion then repeat the testing to see what they could find
  - He naively went to the medical staff of Michigan State and said he wanted to work with the team
  - He met with the head coach (Nick Saban) who thought it was a great idea
- Then he started working at the University of Florida, the the University of Utah, then he came to Pittsburgh
- All of the data he collected from these universities was [published](https://jamanetwork.com/journals/jama/fullarticle/191533) in *JAMA* in 1999

***This was one of the first groundbreaking studies of looking at concussion in sports***

- This study enabled them to start the program in Pittsburgh
- For the first five years, he worked in a cubicle and would see maybe two to three patients a week (if that), and he was doing research
- Fast forward 23 years later, they now have 20,000 patient visits a year in their program
- They’ve published over 450,500 papers, written books, given talks around the world, and it’s probably the hottest topic in sports medicine

> “*We’ve learned a hell of a lot about this injury over that 23 years, and hopefully we can share some of that wisdom today*”‒ Micky Collins

## Concussion: definition, pathophysiology, and risk factors making someone more susceptible [9:45]

**Everybody’s heard the word concussion, but what actually is it? What is the diagnosis? How subjective versus objective is it? What are the criteria?**

- The word “concuss” literally translates from Latin to English to mean “to shake violently”
- Analogy to understand a concussion: think about your brain like an egg yolk inside an eggshell
  - The brain is inside this hard cavity
- **Pathophysiology** ‒ if you have acceleration, deceleration, or translational forces that are hard enough, the brain’s going to shift inside the skull
  - And that shifting of the skull is actually what causes concussion
  - When the brain moves inside the skull, the membrane to the neuron will stretch
  - And when that membrane stretches this little chemical called potassium (which is supposed to be inside the neuron) will leak into the extracellular space, and when that happens, there’s an increased demand for glucose (or energy) that occurs due to the release of potassium
  - At the same time, there’s an influx of calcium; calcium leaks across that same stretched membrane and goes into the cell
  - And when calcium goes into the cell, we get vasoconstriction and decreased cerebral blood flow
  - So, at the very time, the brain’s demanding more energy, you get an influx of calcium vasoconstriction and decreased cerebral blood flow, which decreases energy supply

***A concussion is a mismatch between demand and supply of energy to the cell***

- Concussion is not enough to cause cell death, [Wallerian degeneration](https://en.wikipedia.org/wiki/Wallerian_degeneration), there’s no structural changes to the neuron, but the cells struggle to operate at their normal efficiency
- We’ve now learned that when that **energy problem** happens, different systems in the brain can be decompensated and that decompensation of certain systems
  - We’ve now learned there’s different types of concussions
- There’s actually six different types of problems we see following concussion, and those different types of concussions help to determine how we treat the problem (we’ll explain more soon)
- As a clinician, his job is to find out where the aberrant signal is coming from and what system is decompensated, and then he has to apply the right treatment to the right problem
- None of this was known in 2000

“*None of anything I just told you, we knew in 2000, and so we’ve now really learned a lot about how this injury occurs.*”‒ Micky Collins

- We understand the pathophysiology fairly well, not completely well as in animal model work
- More importantly, we now clinically know how to evaluate this injury in a way where we can kind of figure out what’s happening and then apply a more targeted treatment
- However, we don’t have a **biomarker** right now for this injury
  - There’s no blood test that’s ready for prime time; there’s no serum marker
  - There’s no imaging; this is not seen in [MRI](https://en.wikipedia.org/wiki/Magnetic_resonance_imaging) or on [PET scan](https://en.wikipedia.org/wiki/Positron_emission_tomography)
    - It’s not seen on functional MRI
    - It’s not seen on MEG or on EEG
  - It cannot be detected in [CSF fluid](https://en.wikipedia.org/wiki/Cerebrospinal_fluid)
  - All of these things have been looked at

***Change occurs at the cellular level, and it’s an energy crisis***

- There’s not structural changes in the brain that are seen following concussion
- Everyone is searching for a biomarker, but we just don’t have it

**Peter’s takeaway**

- You have this movement of the brain relative to its protection in the skull, the membrane of the neuron stretches, and presumably you have a passive effusion of potassium out of the neuron
- As a result of that, there is demand for [glycolysis](https://en.wikipedia.org/wiki/Glycolysis) so that you can actively pump potassium back into the cell against an unfavorable gradient
  - That’s why you need more glucose (more ATP), to force potassium back into the cell

**Is the calcium just following a gradient across the stretched membrane at that moment?**

- Yes, that is Micky’s understanding though we don’t have an answer to that yet
- When calcium goes into the cell we get vasoconstriction and decrease in blood flow
- This produces a metabolic mismatch for the cell
- The important thing is we don’t feel that cells die from this
- Cells are just operating at a different level of efficiency
- What they literally see happen with this is different systems in the brain that require a lot of energy don’t work as efficiently, and they will literally decompensate from that energy problem
  - And that’s given us some good understanding of how to kind of approach this injury

W***ith a concussion, systems in the brain aren’t working as efficiently as they should***

**How global versus focal is this type of injury?**

*If you have two athletes that get into a car accident and have the same injury… Is the process occurring across the entire spectrum of neurons or is it occurring more in the temporal lobe of one person and more in the frontal lobe of another person?*

- This happens a lot more in non-athletes than it does in athletes
- Micky uses sports as a laboratory to study this injury, but this applies to slips and falls, car accidents
  - All kinds of older people fall, and that’s a real problem that one’s addressing
- As to Peter’s question, Micky wouldn’t look at this affecting the hippocampus or prefrontal gyrus or whatever
- He approaches it as systems in the brain and pathways in the brain
- It’s not known if you get hit in the head “here,” then you’ll have “this” symptom

***It’s more systematically looking at how the brain is functioning***

- They do see that when people hit the back of their head, they have a very specific presentation of problems (he can get into this later), but generally this is not the case
- Instead, after a concussion, whatever is weak seems to be more affected in patients
- There are preexisting risk factors to have a worse outcome from a concussion

***Those risk factors not only put you at more risk for less force causing concussion, but they tell you what kind of concussion you’re likely to have if you do have a concussion***

- For example, in patients with a history of car sickness, they are more likely to get concussed, and if they do, they are more likely to have a [vestibular](https://en.wikipedia.org/wiki/Vestibular_system) problem following a concussion

**Are these patients more likely to get concussed or if they get concussed, are they more likely to have vestibular symptoms?**

- Both
- Less force will cause injury in those patients
- In patients that have the issue of migraines, less force causes injury, and you’re going to go down that migraine pathway
- If you have a history of lazy eye or strabismus, you’re going to go down the ocular pathway
  - And yes, less force causes injury
- If you have a history of anxiety, you’re going to go down that pathway more ubiquitously

**We talk about cognitive reserve and movement reserve when we think about Alzheimer’s disease and Parkinson’s disease respectively, you’re now talking about a concussive reserve**

- This sort of applies
- A researcher out of UCLA coined that phrase “cognitive reserve”
- You’re more vulnerable with these different risk factors, and you’d more likely go down different pathways

**Girls are more likely to have concussions than boys**

- Neck strength plays a role with that
- Hormonal influences can play a role with that
- We also know that girls are six times more likely to have migraines and have car sickness than boys; and so they’re more at risk for these problems
- 60% of the patients that come through the clinic are female, 40% are male
- Micky sees a lot longer outcomes in females than he does in males

**How long is the susceptibility to a subsequent concussion higher following a concussion?**

- Peter recalls a quarterback for the Dolphins last year had a series of devastating concussions, and he couldn’t help but think that the subsequent concussion was a result of not being better from the first one
- In general, there is a definite vulnerability when you’re recovering from an initial injury in that less force will cause more serious outcome if you’re still recovering from the first event

*Do you ever go back to baseline?*

- Yes, Micky firmly believes that concussion is a treatable injury (he’s [published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5119544/) a lot on this)

***If you manage the injury effectively and treat it fully, he doesn’t see repetitive chronic cumulative problems***

- The best way to prevent problems from concussion is to manage it effectively when you have one
- And we are very good now at determining recovery, what that looks like and how that looks in our examination, how that looks with the testing that we do and the data points that we use [see studies listed in the selected links section]

> “*I am a big proponent of kids playing sports… manage this injury effectively, getting kids back to the sports they love because it’s a very healthy thing for them to be doing. And we haven’t found problems down the road in patients that are managed effectively.*”‒ Micky Collins

## Symptoms of concussion, predictors of severity, and the importance of early and effective treatment [20:00]

**The key here is to manage concussion effectively when you have one, you don’t want to stack these things up**

- You want to go and see a specialist to manage this injury, and you want to make sure you’re getting the right assessment done, the right tools
- There’s definite morbidity when this isn’t managed properly

**When a person has an injury and shows up in the clinic the next day, what are they typically complaining of and what are you doing to make that diagnosis?**

- There are approximately 21 different symptoms on the field that you can see following concussion, and it depends on what type of concussion you have
- There are *signs* and there are *symptoms* of injury
  - Signs are what you outwardly observe
  - Symptoms are what the patient reports
- ***Signs of concussion*** include: loss of consciousness, confusion, balance issues, vomiting
- ***Symptoms of concussion*** include: dizziness, fogginess or feeling detached, feeling one step behind, light sensitive, noise sensitive, nauseous, fatigued, blurred vision, double vision, fuzzy vision, headache, post-traumatic amnesia, retrograde amnesia, loss of memory before the injury, loss of memory after the injury

> “*We’ve done a lot of research looking at these different signs and symptoms and their relative ability to predict outcomes*”‒ Micky Collins

**The symptom on the field that best predicts a longer recovery from concussion**

- Is not loss of consciousness
- On field ***dizziness*** is six times more predictive than any other symptoms for a longer recovery from concussion (a month or longer recovery)
- The second symptom that best predicts outcome is ***fogginess***, kind of feeling one step behind, detached, removed

**What’s interesting about that is the** ***symptoms*** **of injury way better predict poor outcome than the** ***signs*** **of injury**

- The reason for that is because if you lose consciousness, it’s very unlikely you’re going to go back to play
- That may be why these symptoms predict worse outcomes, because a lot of patients tend to play through their injury
- Micky’s group just published a [paper](https://pubmed.ncbi.nlm.nih.gov/35981461/) and they’ve published a series of papers in [*Pediatrics*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5005026/), [*JAMA*](https://jamanetwork.com/journals/jamaneurology/fullarticle/2757869), and other journals
  - They asked the question, “*If patients have a head injury and they have symptoms of concussion, what happens if we take them out of play immediately? Or what happens if they continue to play and what do their outcomes look like?*”
  - These are retrospective studies; it’s hard to do this prospectively
  - They had a very large database with about 300 kids in the sample
    - 150 had symptoms/ signs of concussion and came out of play immediately
    - 150 continued to play after having those signs and symptoms
  - The people who were taken out of play immediately had an average recovery time of 18 days
  - People who returned to play for just 15 minutes beyond the point of their injury/ symptoms had an average recovery time of 44 days

***Playing just 15 minutes beyond a concussive event added close to a month onto the recovery***

**How were you able to control for the severity of the initial event?**

*Presumably there’s a bias there, which is that the kids who came out right away, maybe they were more in tune with something.*

- They controlled for a lot of factors: no group  lost consciousness more than another group, no group had more symptoms (specific symptoms) than another group
- Peter adds, “*It’s such a big difference. 18 to 44 days is a big enough difference that even if it’s not exactly that, there seems to be a signal somewhere in there.*”
- Micky did a follow-up [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6814501/) looking at dose-response, and it’s really powerful

***For every minute you try to play through your injury, you add on seven or eight days of recovery***

> “*You don’t want to play through this stuff. And a lot of kids and parents may not be aware that getting dizzy on the sideline is the most powerful predictor of outcome or feeling foggy or feeling tired or blurred vision, double vision.*”‒ Micky Collins

- Micky played sports his whole life, and he wouldn’t come out of play if he had those symptoms
  - He probably wouldn’t report it at all
- We need to do a really good job of educating parents on that
- But at the same token, Micky wants kids to play sports
- He’s not fear mongering here
- He truly believes this is an injury that’s treatable and we can get kids back to the sports they love, but it just shows you the differences in outcomes when it’s not managed properly initially early on

## The six types of concussion, the effectiveness of treatment, and factors that impact recovery [25:45]

- They do an evaluation where they ask about symptoms, obviously do a very good clinical interview
- They do a physical exam called the VOMS (stands for a vestibular ocular motor screening)
- They do impact testing
- They do a computer based neurocognitive test that has been FDA-approved that allows them to quantify and look at the concussion in a more objective way, looking at their cognition
- There’s different neurocognitive correlates that are see with these different types of concussions
- You put all this information together and they’re doing research now looking at these different phenotypes and different problems they see from concussion
  - Each of these different types of concussions are going to have different symptoms and different risk factors
  - Different therapeutic techniques to treat it and different outcomes and different return to play situations

***The six different types of concussions are: cognitive fatigue, vestibular, ocular, migraine, anxiety, and neck***

![](https://peterattiamd.com/wp-content/uploads/2023/07/f1-mickycollins.png)

**Figure 1. Six types of concussions**. Image credit: [vastdiversity.com](https://www.vastdiversity.com/six-types-concussion/)

- **Vestibular** is not the ear; it’s more central pathways in the brain
  - The vestibular system is a very significant system in the brain that starts in the inner ear and then kind of goes to the deep parts of the brain
- **Ocular** is your eyes working together as a team
  - It’s not your vision as much as ocular motor
- **Migraine** is headache with nausea and/or light or noise sensitivity and other symptoms
- Patients may have one of these problems or all six; they’re not mutually exclusive
- The more problems you have, the more difficult it is to treat
- You are going to treat each of those problems in a distinct, targeted way
- We’re starting to really be able to better identify where the signal is coming from with this injury

> “*If there’s 30 different types of knee injuries, why do we think there’s one type of concussion?*”‒ Micky Collins

**Is there an age or gender difference between the different types of concussions?**

- High school kids take the longest to recover from concussion (the adolescent brain)
- College athletes take the second longest
- Professional athletes recover more quickly than the other to
- There are a lot of vulnerabilities of the adolescent brain to this injury that you’ve got to be careful of
- There is an age relationship that Micky has [published](https://pubmed.ncbi.nlm.nih.gov/35350035/) on

**What do you think that is a result of?**

*Do you think the younger brain has a different hormonal milieu that is a driver of that distinction?*

- Research into this is ongoing
- Micky’s group is doing a really cool women’s study on concussion, looking at hormonal influences
  - They have found that menstruation chan change after head injury

**The estrogen and progesterone swings are enormous in a woman’s menstrual cycle. Are those hormones protective?**

- Micky is about ready to embark on the first women’s study on this injury in collaboration with McGee Hospital at UPMC
- He published a paper in [*JAMA*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5710410/) that showed that the menstrual cycle changes after head injury
- There’s a lot to learn

> “*A cool thing is, we started doing this work when no one cared about it, and now there’s too much work to be done and everyone cares about it*”‒ Micky Collins

## The importance of seeing a specialist and the prognosis for recovery [30:00]

*How much of the interest in concussion is a consequence of the attention that’s been brought to brain injury through the light of* [*CTE*](https://en.wikipedia.org/wiki/Chronic_traumatic_encephalopathy) *vis-a-vis the NFL?*

- Clearly the NFL is a very powerful enterprise, and there’s a lot of eyes on it
- There’s a lot of discussion on this topic, which is good in a lot of ways
  - It drives science and awareness
- But too much awareness without a solution is called hysteria (this is happening)
- There’s a lot of misinformation out there about concussion which hurts outcomes a lot of times
- Clinicians that aren’t aware of the recent advances in knowing how to treat this
  - They don’t know how to do the right evaluation
  - There’s a lot of mismanagement and mistreatment of this injury that leads to very poor outcomes

> “*If you bring me a patient with concussion, I can pretty much tell you I can treat that and get that patient better and get them back to the sports they love. There are highly effective treatments with this injury.*”‒ Micky Collins

**Is there a relatively finite window in which the physician has to be able to access the patient, and the further a patient is from that window, the more difficult treatment gets?**

- Micky [looked at](https://pubmed.ncbi.nlm.nih.gov/35286616/) what factors best predict outcomes from concussion
  - History of migraine is a huge factor predicting outcome
  - Certain symptoms that predict outcomes
  - The one factor that best predicted outcome was how quickly they get into our clinic
  - Patients who were seen in the clinic within seven days, that was the best predictor of recovery because treatment can be applied quickly

***If you do wait, it’s harder to treat; but even if you’re 1-3 years out from injury, you can be treated effectively the majority of the time***

- It’s not irreversible
- Patients get better even if they have been living with it chronically
- Micky had 20 patients on his schedule before this podcast
  - They will be normal when he finishes treating them

## Case study of a racecar driver who suffered a vestibular concussion [32:15]

- Micky just saw a racecar driver that has been going through this for two years and is miserable
- He was involved in an accident and had all the hallmark symptoms of vestibular problems
- It was a small track event where he somehow got hit in a way that their car rotated and went backwards into the wall
  - The video of the crash shows that his head hit the back of the headrest
- **Symptoms**: the driver had no loss of consciousness but immediately felt foggy, dizzy
  - They felt fatigued, had a headache
  - Early on, they had bilateral blurred vision
  - They had no memory loss, no confusion
- The car was totaled so they didn’t finish the race, but they also didn’t get medically evaluated
- They went about their life and continued to have these symptoms
- They went back to racing two weeks later and got into another accident
  - They had the same problem occur, same mechanism even
- Only when everything got worse did they seek medical attention
- They’ve lived with this for two years and have not improved
- They’re having headaches everyday that can get up to an 8 out of 10
  - They have light sensitivity, noise sensitivity, feel foggy
  - They don’t like busy environments
  - They feel dizzy when they exercise
  - They get headache, they get sick to their stomach, they’ve got a lot of car sickness
- It’s totally debilitating; it destroys your life
  - This is a person who is not racing or working anymore become of it
- They have massive sympathetic nervous system arousal where they can’t sleep at night
- They’re very foggy, very, very worked up, and they very much are isolative
  - They don’t want to be around other people because that triggers vestibular problems
  - And so they become more reclusive; they’re socially inactive
  - They find themselves exercising minimally
  - Their thoughts are going so fast, because the nervous system is racing; they’re in their head all day long
  - Migraines
- That is what Micky saw this morning, he does it all day long

***This is an injury that causes so many problems in patients***

**What are you going to do to help this person, and what’s a time course that you would give him for a reasonable expectation of recovery?**

- First he does a very good evaluation
- They are very used to seeing out-of-town patients
- Patients have five appointments in one day, all under one roof, and Micky is the point guard on that
  - Micky does the evaluation to find out what’s going on
  - They have a vestibular therapist
  - They do what’s called exertion therapy
  - They have a psychiatrist
  - They have a behavioral optometrist they can use
  - They have neck people they can use
- They identified that this patient has significant **vestibular problem** that has not been treated
  - The [vestibular system](https://en.wikipedia.org/wiki/Vestibular_system) is responsible for interpreting motion
  - When the vestibular system is not working well it’s going to cause a lot of dizziness
  - It’s going to cause a lot of fogginess
  - It’s going to cause environmental sensitivity where busy environments will bother them
  - They don’t want to exercise because movement bothers them
  - This injury decompensates that system so that the signal comes through aberrantly and will trigger all these really icky symptoms
  - It’s like a bad car sickness that they feel
- The same pathways in the brain that control the vestibular system mediate our sympathetic nervous system
  - These patients will also have massive [sympathetic nervous system](https://en.wikipedia.org/wiki/Sympathetic_nervous_system) arousal, they’re living in this fight or flight situation
  - Thoughts go faster, heart rate increases, they get a lot of cortisol, a lot of problems going on from the nervous system, and that’s all triggered by the head injury
  - Then when patients go into certain environments where they feel crappy, it not only triggers a vestibular problem, but it triggers that fight or flight response
- Patients will then, in a very [Pavlovian](https://en.wikipedia.org/wiki/Classical_conditioning) way, avoid those environments
  - They don’t want to work or exercise
- Because these patients have a massive sympathetic nervous system arousal, it triggers migraine
  - People get migraines when they’re stressed and don’t sleep consistently and don’t exercise consistently
- So what started off as one problem with a vestibular problem becomes an anxiety problem or a sympathetic nervous system problem, and then it becomes a migraine problem, and then migraine actually feeds back through the vestibular pathways and the ocular pathways
  - You can also have a lot of problems from that secondarily to the migraine

**This reminds Peter of an injury someone very close to him had**

- This person was riding his bike down the side of the road at a good clip (25 mph), and a runner jetted out between two cars (they were probably listening for cars but didn’t think about a bike) and they collided head-to-head
  - Peter knew the cyclist, not the runner
  - They both were devastated by this injury
  - The runner took the brunt of it, had a complete fracture of the face
- For two years, the cyclist couldn’t be in a room with the TV on
  - Any noise that the kids made was would make this person very irritable
  - It’s very similar to what you’re describing
- Micky points out that the pathways these patients go down is very predictable
  - It’s biological, it triggers these things in a very robust way, and then they are conditioned
- Peter has spoken with a couple of patients that have gone through this, and they describe it in as stark terms as someone would the most severe mental illness
  - They are not themselves anymore
  - Who they used to be, that person is gone
  - They are this new person that has nothing in common with the old one and it’s all in the wrong direction

**What percentage of people with a concussion have symptoms this severe?**

- Almost all of the patients he sees from out of town haven’t’ been treated and come to him because they’re feeling pretty well and want to know if they can go back to sports after having X number of concussions
- Micky sees 70-100 patients a week with this injury and, probably 80% of them are this sick

**What will be the next step for this patient (the racecar driver)?**

- All of his symptoms can be treated, but it’s completely antithetical to how you think we treat it
- When you think about a concussion you think you should **rest**, and this is *absolutely wrong* in how they approach this injury

- If you look at the literature over the years, a brain injury is an energy problem, and you need to rest the patient

***Rest only makes this worse, because the way we treat a vestibular problem is by retraining it***

- They treat anxieties by increasing parasympathetic nervous system arousal through exercise, very targeted physical therapy, and regulated sleep (a good sleep schedule)
- They treat a vestibular problem by retraining it
  - He wants them in busy environments, wants them exercising
- They have what’s called exertion therapy here

> “*If you come see me with a concussion, I don’t care how sick you are, I am working you out and I’m doing it aggressively a lot of times.*”‒ Micky Collins

- But you need to see a specialist in how to do that because you can do it the wrong way and make patients worse
  - It’s got to be very targeted in how you approach this, and every patient is different
  - There are different types of vestibular problems, different types of ocular motor problems, different types of personality characteristics, etc.

***But at the end of the day, if you match the right treatment to the right problem, you can get better from this, and that’s what they do all day long at the clinic***

- What Peter finds interesting in the case of this patients is that the injury took place two years ago
  - An energy crisis takes place, vasoconstriction takes place, and there is a mismatch of supply and demand
  - If you could biopsy his brain today or put yourself into a nanoparticle spaceship and enter his brain today, everything would look normal at the cellular level
    - Micky agrees

**Do you think there is still cellular damage microscopically apparent in this patient?**

- Micky doesn’t know the answer
- His suspicion based on everything he’s learned about the pathophysiology of this is that we should see a normal brain structurally and anatomically and even physiologically
- What happens with this injury happens is systems are affected, then you can go down these pathways, and if it’s not treated appropriately, this is what ends up happening

## Why vestibular concussions are particularly problematic [42:45]

**It seems that of the six phenotypes of concussion, this vestibular one is very problematic because it seems to amplify the other ones**

- Yes and Micky has done [research](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6825555/) on that
- The most common problem they see after concussion is anxiety
  - #2 is migraine
  - #3 is vestibular
  - Then ocular, then cognitive failure
- Anxiety is ubiquitous across this injury; it’s the most common clinical profile they see in that nervous system issue

**You said earlier that no symptom predicts a worse outcome more than dizziness, and that is tied to the vestibular system**

- Yes

*Is there something about this vestibular problem that would also amplify anxiety?*

- They do research and look at the numbers and publish that
- Micky’s gut is the vestibular stuff carries the day with this injury the majority of the time, or at least kicks it off
  - It’s a vicious cycle that spins out of control from that
- He doesn’t want to overgeneralize to every human being because it can have a very different presentation
- He sees people who have an ocular motor problem that no one has identified and no vestibular issues, no migraine
  - They’re completely normal, except they can’t focus when they look at their math homework, they get headaches in the front of their head, and they’re tired
  - That’s an ocular motor problem that can be fixed pretty easily
  - They have to retrain the ocular system, and they have exercises that can do that very effectively
- The vestibular stuff is ubiquitous
- There are patients where the vestibular problems kicked things off, but that’s not present anymore
  - It’s all migraine and anxiety, but it came from the vestibular system in the beginning
- It sounds like your friend who had that horrific bike accident has this vestibular profile
  - Peter adds that he got better after 2.5-3 years, and maybe part of it was that he doubled down on exercise, nutrition, and sleep
  - Micky agrees with this approach
- But if this friend came to Micky’s clinic a month after this injury, he would gotten better in weeks not months

## A treatment plan for the racecar driver, possible use of medications, and how to address the root cause [45:45]

**For the racecar driver, after his evaluation, what is his homework assignment?**

- Micky will see him again in four weeks
- He’s been given a very detailed set of vestibular exercises to complete every morning and evening
- He has been given an exercise program to kick him around the gym a little bit and get him moving

***When this vestibular system breaks down, you have to move in certain ways to treat it, and we’re in sports medicine, we know how to move people***

- We’ve given them a very specific workout that will train that vestibular system, and while we’re doing that, we’re also increasing the [parasympathetic nervous system](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system) by doing exercise
  - So, it’s killing two birds
  - Exercise also treats migraine
  - So, that’s three birds we’re killing by doing the exercise stuff
- He’ll do that workout program every day

**How many minutes a day will he spend exercising?**

- He will walk in the morning for 45 minutes, and then he does that very rigorous workout in the afternoon (it takes about 45 minutes to an hour)
- He is to do that every day until Micky sees him back in the clinic

**Can you give me an example of some of the exercises he’ll do in the afternoon?**

- This patient had a horizontal vestibular ocular reflex problem
  - When he moves his head side to side he can’t stay tracking, and this will stir him up with dizziness, fogginess, and headaches
- They have him doing a Russian twist where he’s got a ball and throws it against the wall to train that vestibular system
- They have him doing planks with head turns, lateral shuffles
- They’re doing a lot of burpees and things like that where it’s more linear or vertical rather than horizontal movements
- Given that he is a racecar driver, that vestibular ocular reflex when he is looking side to side, that affects his racing
  - That injury affected the very system that makes him who he is
- But we can retrain that by giving the reaction
- Micky prescribed a regulate sleep schedule where he gets up at the same time, goes to bed at the same time, no napping
- He wants him to do exposures to busy environments: grocery stores, restaurants, parties, whatever
- He wants him doing a lot of external activities
  - He doesn’t want him internal, thinking about his symptoms, and ruminating because the nervous system is so fired up
- Downtime makes this all worse
- He’s going to challenge him
- There are three different types of exposures he wants him to do everyday in terms of busy environments, and there’s exercise and different ocular things
- He prescribes a very detailed program, and it’s all written down so the patient can go home and do it
  - He doesn’t want to talk to him for a month, then he’ll see come back to the clinic and see him
  - Sometimes they do telemedicine a month later, but this guy is coming in because he is pretty sick

**There are medications that can help sometimes depending on the problem**

- Micky doesn’t ever start with medication, he wants to see if they can be treated behaviorally first

*What meds help with sleep? Trazodone?*

- Micky doesn’t like [Trazodone](https://en.wikipedia.org/wiki/Trazodone) because the sleep is coming from the nervous system problem
  - You’re treating a secondary problem by putting them on Trazodone
- Sometimes he uses a [SSRI](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) or a [tricyclic](https://en.wikipedia.org/wiki/Tricyclic_antidepressant) for treating the nervous system profile, but he doesn’t like SSRIs
- He has had decent outcomes with [sertraline](https://en.wikipedia.org/wiki/Sertraline)
  - It’s a medication that can actually affect not only the vestibular system, but the nervous system as well
- Sometimes you need [Effexor](https://en.wikipedia.org/wiki/Venlafaxine) (aka [Lexapro](https://en.wikipedia.org/wiki/Escitalopram) or [Escitalopram)](https://en.wikipedia.org/wiki/Escitalopram)
  - They have a psychiatrist at the clinic who is phenomenal

**Is this one of those things where treatment is empirical and you have a hunch as to what you’re going to do, but if in a month the patient’s not better, you abort regardless of what the data say?**

- They follow patients very carefully and will see them every 3-4 weeks until they are normal (via telemedicine or in-person)
- Patients need those follow-up appointments because they can get off the rails with this stuff
  - Some people aren’t as compliant as they should be
  - Sometimes they hit walls with migraine or anxiety or different problems

***But at the end of the day, the great majority of these patients get better, “I’m not just blowing sunshine”***

- Treatment just need to be done in a very targeted and diligent way

> “*There’s not a patient I don’t believe I can treat…  I really truly believe you come to me with concussion, I’m going to get you better from this.*”‒ Micky Collins

**How many of the male patients come in with hypogonadism as a result of this?**

*So something shuts off and their pituitary is just not making testosterone anymore*

- There are so many downstream things that can happen from a rampant sympathetic nervous system
  - It affects every bodily organ we have: the gut, hormonal influences, temperature regulation, migraine.
- Micky hasn’t looked at this topic
  - Would he find something? Perhaps

**Peter wonders how the** [**HPA axis**](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93adrenal_axis) **functions after a chronic insult like in the case of the racecar driver**

- He can’t help but imagine of both centrally and peripherally, there is some manifestation of this
- And to Micky’s point, you wouldn’t want to just get into a game of whack-a-mole where you’re just treating all of those things
  - You’d want to put all your effort of course into what’s the central problem here

**How is the root cause addressed?**

- Micky agrees, if you treat the root cause then those secondary downstream problems don’t occur

***This is why seeing patients early can really lead to better outcomes; you don’t see those problems happen in the first place***

## Exploring alternative treatments: hyperbaric oxygen, synthetic ketones, and more [52:00]

**Have you studied the use of hyperbaric oxygen?**

- This is something Peter gets asked about a lot for which he has no answer

***Yeah, I’m not a believer in it, and it’s not something that’s going to reverse the problems we see with this injury***

- Micky doesn’t want patients doing superfluous treatments that aren’t’ well founded empirically because it leads them into a sort of anxiety model where they’re just feeding into the problems
  - He sees this alot with this injury
  - He doesn’t blame the patient because no one is getting them better, so they’re trying all kids of different things
- He does not have patients to hyperbaric treatment with this injury because it leads to more searching and seeking that’s not targeted
- He sees patients that want to do hyperbarics, but there’s not data that has compelled him to say it would have any effect (positively or negatively) on outcomes from this injury

**Peter often discusses hyperbaric oxygen in the context of improving longevity**

- Patients always point to this very [poorly done study in Israel](https://www.aging-us.com/article/202188/text) that supposedly showed that telomeres got longer in a hyperbaric chamber
- But telomere elongation has nothing to do with longevity
- Peter points out the opportunity cost
  - There is a hyperbaric chamber in Austin, but you have to drive 30 minutes to get there, spend an hour in the chamber at two atmospheres, and then drive back
  - Are you going to put 2 hours a day into this for 4-5 days a week
  - Even if you’re completely cost agnostic, are you time agnostic?
- What could you have done with that time vis-a-vis improving your health?
  - If you spent half that time exercising, you’re going to get 10x the value
  - Peter suspects the same is true for Micky’s patients
- It sounds like the data on hyperbaric chamber treatment isn’t efficacious

**If you could get into a hyperbaric chamber the day of the injury, would that move the needle? Has that been studied?**

- No, because it’s hard to study that
- To Micky’s knowledge, there is no compelling data in any way, shape, or form that shows hyperbaric treatments to be effective at treating this problem
- He thinks Peter stated it very well and agrees entirely with how he just conceptualized it
- To add to this, what do you do when you’re in a hyperbaric chamber?
  - You think about crap a lot
  - You ruminate, and that isn’t good for this

**Synthetic ketones [54:45]**

**Have you looked at any of the data on the synthetic ketones (specifically acetyl acetate or beta-hydroxybutyrate) being in the system prior to an injury?**

- Peter acknowledges that this wouldn’t help you in a car accident because you don’t know when you’re going to have a car accident
- But if football players had synthetic ketones in their system (1-2 mmol of BHB) at the time of an injury, there’s a very strong theoretical argument and some animal data to suggest that could ameliorate some of these symptoms
  - Because you have a solution to that short-term energy crisis, and you don’t  have to rely on glucose
- Micky is not doing animal model work or that sort of research
- To his knowledge, that has not been done
- Theoretically he thinks it’s interesting and would be interested to look at that specifically in the literature
- To study that rigorously you’d want a pool of athletes where the frequency of concussion is high enough that you can study it
  - Football leads the way, but women’s soccer and basketball are also high
- The sport that carries the highest risk of concussion in terms of lifetime incidence is horseback riding
  - 90% of equestrians have concussions over the course of their career
  - The horse is a very large beast, and you fall from a very high degree
- The research hasn’t been really good there because a lot of parents don’t report the problems that occur
- Obviously boxing is a very common sport where this happens, concussion is a very common injury

***1.8-3.6 million concussions occur in this country per year due to sports and recreation alone; it’s very common; it’s crazy***

## The natural history of a concussion if untreated and the effect, if any, of concussion on subsequent risk of brain disease [57:15]

**What percentage of people who get a concussion end up like the racecar driver discussed, where things don’t get better until they see a specialist?**

- Micky wishes he knew the percentage but no one has done that kind of work
- We don’t know the denominator
- Micky adds, “*If you walked a day in my shoes, you’d think it was very common*”
  - He has a huge selection bias because he sees the sickest people
- He feels like a lot of kids will be fine after a concussion
  - They probably work out of it
- Micky has had moments in his life where he remembers playing sports and getting hit, feeling foggy and dizzy, and he didn’t have any problems from that (that he’s aware of)
- This happens fairly commonly and kids are fine, but patients with certain risk factors, certain personality types, certain biomechanics (it’s a confluence of factors) end up down this pathway where they can really get in trouble with it
  - He doesn’t think it’s all that infrequent

**Do we know anything about the effect of concussion on subsequent risk of brain disease?**

- One of the things we talk a lot about on this podcast is dementia, Alzheimer’s dementia and other types

*If two people who are identical in every way in terms of predisposition and other factors, but one person sustains multiple concussion in their life and the other does not. Do we know if that has any bearing on risk?*

- There has been some pretty good research on this
  - A lot of work out of Mass General in Boston
  - [Grant Iverson](https://researchers.mgh.harvard.edu/profile/10328909/Grant-Iverson) has [written](https://bjsm.bmj.com/content/51/12/969.long) really well on this topic (Micky respects his group)
- You see some relative increases in anxiety in some of those patients
- Overall, studies have shown that we’re not seeing any proclivity toward dementia (Lewy body disease or other neurodegenerative illness) in these patients
- It depends on what research you’re looking at, as you  know the research world is highly variable
  - Other camps would support that people who have repetitive head injuries end up with [chronic traumatic encephalopathy (CTE)](https://en.wikipedia.org/wiki/Chronic_traumatic_encephalopathy)
  - There is selection bias in studying patients who are donating their brains because they have problems

**There is a study ongoing at UPMC with a number of former NFL players**

- It’s a very large sample size, and one of the best controlled studies done in this area
- They’re doing the deepest dive you could do on their neurological health
  - They’re doing a 3-day evaluation, full neuropsych battery, fancy imaging
  - They’re doing lumbar punctures and looking at different biomarkers in CSF
  - They’re doing a sleep study
- Importantly, they’re matching them to controls that haven’t had these exposures
- They are looking at the prevalence of neurodegenerative issues in patients that have had repetitive head injuries versus patients that have not

- They’re two and a half years into the study now and just about to dive into the first statistical analysis

***There are other groups doing similar work so we’re going to have very good scientific answers on this question in the next several years***

## Chronic traumatic encephalopathy (CTE) [1:01:45]

**I know that CTE is not your area of expertise, but is it your intuition that CTE is the result of untreated concussions that accumulate repeated injuries?**

- Peter’s recollection is that CTE is not so much the result of major concussions but constant accumulated sub-concussive injuries
- Micky agrees this is correct, but whether that is scientifically accurate is a different story
  - He doesn’t know the answer, and that’s why they’re doing the research
- Science hasn’t evolved to have a definitive statement on these issues
- Anecdotally, Micky has seen patients who are convinced they have CTE and they get better with his treatments and don’t have problems after treatment
- It’s sad when they see patients with problems for whom treatment is available that the patient was unaware of, and this happens a lot
- Peter adds, “*That’s kind of an amazing thought… people who either played sports professionally or at a very high level who could easily think that they’re in the stages of CTE and maybe they’re not, maybe this is a concussion that hasn’t been appropriately treated*.”
- Further, Micky sees patients that are suicidal from this, and you wonder about the suicidality ‒ what percentage of those patients didn’t have those problems but believed they did
  - They have biologically derived sympathetic nervous system arousal and high anxiety
    - They feel horrible
    - They’re not working or exercising
    - They’re not regulated with their sleep
    - They’re not social, and they’re ruminating all day long
  - The suicide risk in that population is very, very high
- This is a function of hysteria that can come when you have increased awareness [of CTE] but no solution (discussed earlier)
- We need responsible science to lead us to better answers
- He understands the need to talk about this stuff in the media
- They see so many patients because of that awareness, and that’s a good thing because it’s leading a lot of people to get help that wouldn’t have received help
- But on the flip side, it can be very dangerous as well

## Advice for parents of kids who play sports: when and where to seek treatment for a possible concussion [1:04:45]

**What’s the best advice you offer to parents of a kid who is playing sports, whether it’s soccer, football, you name it?**

*For example, little Billy or little Susie has a concussion based on symptoms, and they are taken off the field right away. Do they need to come and see you in Pittsburgh?*

*How many centers of excellence are there in the country where you could go and get the level of treatment we discussed?*

- Great question
- Yes, there are centers around the country that do a really good job with this injury
  - You want to start at places that have experience and call themselves concussion clinics or specialty clinics
  - They are much more equipped to do the work than a general pediatrician
- You might want to start with your pediatrician
- If you have specialist clinics in your area, you want to start there
  - They are familiar with the literature and the tools and by and well equipped to manage these injuries

**Does every major medical center have one of these specialist clinics now?**

- UPMC was literally the first program in the world doing clinical work or studying this injury, and now every major geographic area has a center like this
  - It blows his mind just to talk about that
  - Only 20 years later
- If you’re in rural Idaho or something, you may not have access to it
- But now that telemedicine is widely used, a lot of times you have that option available
- So access is better than it has ever been

**Off the top of your head, what are the top five programs in the country that would be great places for people to start if they’re willing to travel? (Obviously your program)**

- Another program Micky has incredible respect for is [Innova](https://www.inova.org/our-services/inova-sports-medicine-concussion-program), in Washington DC
  - One of his former fellows is there; Micky has had 33 fellows train under him and they’re at various sites around the country
- [Boston Children’s](https://www.childrenshospital.org/programs/sports-concussion-clinic) does a pretty good job overall
- There are clinics in Houston, TX that do a good job
- Clinics in Phoenix
- Clinics in California
- One of his fellows is in North Dakota
- You can find out who he has [trained](https://dam.upmc.com/-/media/upmc/services/sports-medicine/services/concussion/documents/concussionprogram_fellowshipopportunities.pdf?la=en&rev=b7dcad73053c46159dedaeb0695b77c6&hash=955F40A3792199FC9F1E4C1C651340F1) at the [UPMC website](https://www.upmc.com/services/sports-medicine/services/concussion/experts)
- He collaborates with a lot of these programs

**Advice to parents whose child has a concussion on Monday afternoon**

- The earlier they see someone, the quicker they get better
- Go to the clinic right away; you want to be seen within seven days
- The first thing you have to do is make sure there’s not an intracranial bleed
- You want to start these treatments pretty quickly

**Peter’s takeaway ‒** ***basically it’s never too early and it’s never too late to seek help for this***

**Does all of this apply as we move from the kid to the parent?**

*If I’m out there playing with my kids and they somehow talk me into climbing a tree, which they often do, but I fall whack my noggin, same thing. Let’s say I go to the ER, we get the CT scan, I don’t have a bleed, there’s nothing going on. Let’s say I feel totally fine. I’m like, I got a bump on my head, but I feel fine and I’m medically cleared. Should I go and get evaluated or only if I have a symptom?*

- If you feel fine, it’s not necessary to get evaluated, but the symptoms can be subtle
- Without someone in the ER who can do the real ocular motor test, you can speak to the symptoms but you can’t speak to the signs
  - Even the symptoms are hard to speak to: dizziness, fogginess, fatigue, light sensitivity, noise sensitivity, headache, obviously, difficulties falling or staying asleep, nausea, car sickness, difficulty in busy environments, cognitive issues
- But if you’re not having any of those problems, then don’t get evaluated; live your life

***If your symptoms are pretty nasty and they’re not getting better, you better see someone (the sooner the better)***

- If you’re a weekend warrior and you want to play basketball again next weekend, you probably want to get it checked out to make sure everything is normal
- If you’re not a weekend warrior, you’re not going to hit your head again and it’s getting better, Micky is not sure you need to see someone

## Is there any evidence that the APOE4 genotype increases susceptibility to concussion or TBI? [1:10:15]

**Do you know anything about the role of the** ***APOE4*** **Genotype in terms of susceptibility to concussion or any traumatic brain injury?**

- Studies have looked into *APOE4* with this injury, and there’s no compelling data to suggest that genotype would put you at greater risk
- It’s not augmented where concussion plus *APOE4* allele leads to X, Y, or Z
- Micky doesn’t know of any hard data suggesting that is a big risk factor, although it’s interesting to look at
  - The research isn’t definitive or comprehensive
- He raised this issue in the [*JAMA* paper](https://jamanetwork.com/journals/jama/fullarticle/191533) published in 1999, but nothing definitive has been found

## The increased risk of concussions in older adults and a case study of a 90-year-old patient who suffered a head injury in a fall [1:11:15]

- Peter has talked a lot about the high mortality from falls after the age of 65
- One of the things that’s happening in the aging person is their brain is shrinking a little bit and their skull is not
  - So, presumably that’s making them more susceptible
  - They’re going to have more movement to the brain within the head

*Is that why we’re seeing a greater susceptibility in an aging population, in addition to the fact that they’re obviously more susceptible to a fall?*

- Micky doesn’t know, but it’s a great theory
- Obviously you see atrophy in that population
- There is also a lot of unprotected falls in that population
- There’s a lot of syncable events in that population, and there’s a lot less motor control when you do fall
- The biomechanics are going to be more violent in that population
- And also [cerebral spinal fluid](https://en.wikipedia.org/wiki/Cerebrospinal_fluid) is not as robust in that population, so you don’t have as much protection of the brain moving inside the skull either

***This is an understudied area, and it’s a huge problem that he sees day in and day out in the clinic***

- They are doing some of the first research looking at concussion in geriatric population, and it’s a very rewarding population to work with because you can treat it

**Case study of a 90-year-old man who suffered a head injury in a fall [1:12:45]**

Micky saw a 90-year-old this morning that fell about eight weeks ago

- They had a syncopal episode where they hadn’t hydrated well, maybe a little stress going on in their life, dysregulated blood flow, dysautonomic stuff
- They get up from going to the bathroom, collapse, hit their head on the linoleum floor
  - He fell forward off the toilet, face first
- They had a facial fracture, small subdural, bad concussion
  - Fortunately no intracranial intervention
  - The blood from the subdural reabsorbed
- They’re very, very dizzy both in bed and in life
  - They don’t like busy environments, feel fatigued all the time, get bad headaches they’ve never had before
  - They have a lot of anxiety that they’re not even aware of
- They were living alone at the time and now with family members around, they have to get support from them and they get enabled and they get really protective
- They think they’re going to fall again, so they don’t move as quickly
- The vestibular problem doesn’t get treated, because they’re not moving, they’re not doing anything
  - They’re not exercising, they’re not going to busy environments, and so the anxiety levels are up
  - They have benign positional vertigo that no one ever noticed, and that’s why they’re getting really dizzy in bed
- Micky will get them in the right physical therapy, the right vestibular therapy
- He will get family members on board and tell them how to approach things and get them more active and challenge them more and make sure the parents aren’t overprotecting them
- Once you explain how to treat this problem, they do really well
  - It’s amazing
  - It’s very, very rewarding to treat a patient like that
  - They’ll look great here in another few weeks, hopefully

**How much exercise is part of this person’s rehabilitation program?**

- Walking for now
  - They’re not a fall risk
- Balance exercises
- Vestibular exercises
  - For example, go to the grocery store and don’t hold on to the buggy; walk up and down the aisles
  - Challenge themself by going to a busy restaurant
  - Go back to church

> “*It’s really cool to see this stuff wash off the patient…They don’t think they’re ever going to get better…They think it’s the beginning of the end.*”‒ Micky Collins

## Funding for concussion research and fellowship programs to train concussion specialists [1:15:30]

**Is your research mostly funded through the NIH?**

- They get funding from a lot of different places, but they do have NIH funding
- They have funding from the NFL, the Centers for Disease Control
- There’s a really cool foundation in Pittsburgh called the [Chuck Noll Foundation](https://www.chucknollfoundation.org/) for the former coach, [Chuck Noll](https://en.wikipedia.org/wiki/Chuck_Noll)
  - They give out grants for researching head injury, and they’ve received a lot of funding from them
- The Steelers were the first team to ever do baseline testing, and Chuck Noel was a huge proponent of treating head injury the right way, and [Joe Maroon](https://en.wikipedia.org/wiki/Joseph_Maroon) had a lot to do with that
- It’s a pretty hot topic, and so there’s a lot of monies available to study this, which is exciting

**Do you have neurologists in your group now?**

- They have a few
- Neurologists do a phenomenal job with this injury
- But you’re not trained about concussion in medical school
  - That’s not in the curriculum
  - Just because you’re a neurologist doesn’t mean you know concussion
  - Just because you’re a neurosurgeon doesn’t mean you know concussion
  - This is new science, new information, and that’s why it’s really important to see a specialist

***Don’t assume that you go to a neurologist/ neurosurgeon that they are going to know this injury, because most of the time they don’t***

**How many fellowship programs are there in the US now for training concussion specialists?**

- Conservatively, maybe 10 to 15 fellowship programs that would do training specific to this topic
- It’s not that many, but they do exist

**Peter’s takeaway**

- He cannot believe the volume of patients Micky sees, and it probably speaks to how amazing his team is
- He came away from this discussion far more optimistic
- He didn’t have an appreciation for how positive the prognosis is (with the right therapy), even in patients with longstanding concussion
  - He thought it was the exception and not the rule that one could get better if you were two years out and still suffering

§

## Selected Links / Related Material

**Concussion clinic at UPMC**: [UPMC Sports Medicine Concussion Program](https://www.upmc.com/services/sports-medicine/services/concussion) | UPMC Life Changing Medicine (2023) | [1:04]

**CDC concussion toolkit for physicians**: [Traumatic Brain Injury & Concussion](https://www.cdc.gov/TraumaticBrainInjury/index.html) | CDC (April 20, 2023) | [1:15]

**Post-concussion assessment and cognitive testing; computerized sports concussion evaluation**: [ImPACT](https://impactconcussion.com/) | [1:30]

**Micky’s 1999** ***JAMA*** **publication**: [Relationship Between Concussion and Neuropsychological Performance in College Football Players](https://jamanetwork.com/journals/jama/fullarticle/191533) | *JAMA* (M Collins et al. 1999) | [7:45, 1:11:00]

**Treatment for concussion**: [Concussion is Treatable: Statements of Agreement from the Targeted Evaluation and Active Management (TEAM) Approaches to Treating Concussion Meeting held in Pittsburgh, October 15–16, 2015](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5119544/) | *Neurosurgery* (M Collins et al. 2016) | [19:15]

**Recovery from concussion**:

- [Tracking neuropsychological recovery following concussion in sport](https://pubmed.ncbi.nlm.nih.gov/16537266/) | *Brain Injury* (G Iverson et al. 2006) | [19:45]
- [Examining Recovery Trajectories Following Sport-related Concussion Using a Multi-Modal Clinical Assessment Approach](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4833014/) | *Neurosurgery* (L Henry et al. 2016) | [19:45]
- [Recovery Following Sport-Related Concussion: Integrating Pre- and Postinjury Factors Into Multidisciplinary Care](https://pubmed.ncbi.nlm.nih.gov/31479086/) | *The Journal of Head Trauma Rehabilitation* (A Kontos et al. 2019) | [19:45]

**Outcomes for concussion patients who are removed from play and others who continue to play**:

- [Removal From Play After Concussion and Recovery Time](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5005026/) | *Pediatrics* (R Elbin et al. 2016) | [23:00]
- [Association of Time Since Injury to the First Clinic Visit With Recovery Following Concussion](https://jamanetwork.com/journals/jamaneurology/fullarticle/2757869) | *JAMA* (A Kontos et al. 2020) | [23:00]
- [Comparison of Clinical Outcomes Between Athletes With Immediate and Delayed Onset of Symptoms Following Sport-Related Concussion](https://pubmed.ncbi.nlm.nih.gov/35981461/) | *Clinical Journal of Sport Medicine* (A Trbovich et al. 2023) | [23:00]

**Dose-response effect of playing through injury on recovery time**: [Preliminary Evidence of a Dose-response for Continuing to Play on Recovery Time after Concussion](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6814501/) | *Journal of Head Trauma Rehabilitation* (D Charek et al. 2020) | [24:30]

**Relationship between age and recovery time**: [The Role of Age, Sex, Body Mass Index, and Sport Type on the Dynamic Exertion Test in Healthy Athletes: A Cross-Sectional Study](https://pubmed.ncbi.nlm.nih.gov/35350035/) | *Clinical Journal of Sports Medicine* (A Sinnott et al. 2022) | [28:15]

**Menstruation can change after head injury**: [Association of Concussion With Abnormal Menstrual Patterns in Adolescent and Young Women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5710410/) | *JAMA Pediatrics* (M Snook et al. 2017) | [29:45]

**Factors that predict outcomes from concussion**: [Estimated Duration of Continued Sport Participation Following Concussions and Its Association with Recovery Outcomes in Collegiate Athletes: Findings from the NCAA/DoD CARE Consortium](https://pubmed.ncbi.nlm.nih.gov/35286616/) | *Sports Medicine* (S. Eagle et al. 2022) | [31:30]

**Vestibular concussions**: [Persistent Vestibular-Ocular Impairment following Concussion in Adolescents](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6825555/) | *Journal of Science and Medicine in Sports* (A Sinnott et al. 2019) | [43:00]

**Effects of concussion on dementia**: [A systematic review of potential long-term effects of sport-related concussion](https://bjsm.bmj.com/content/51/12/969.long) | *British Journal of Sports Medicine* (G Manley et al. 2017) | [59:15]

**Top concussion clinics include**:

- [Inova Sports Medicine Concussion Program](https://www.inova.org/our-services/inova-sports-medicine-concussion-program) | [1:06:45]
- [Sports Concussion Clinic](https://www.childrenshospital.org/programs/sports-concussion-clinic) | Boston Children’s Hospital | [1:06:45]

**Fellowship program at UPMC**: [UPMC Sports Medicine Concussion Program: Fellowship in Sports Neuropsychology](https://dam.upmc.com/-/media/upmc/services/sports-medicine/services/concussion/documents/concussionprogram_fellowshipopportunities.pdf?la=en&rev=b7dcad73053c46159dedaeb0695b77c6&hash=955F40A3792199FC9F1E4C1C651340F1) | UPMC (2022) | [1:07:30]

**Experts at UPMC**: [Your Concussion Care Team at UPMC](https://www.upmc.com/services/sports-medicine/services/concussion/experts) | UPMC (2023) | [1:07:30]

**Editorial on concussion**: [Concussion and Sport: Progress is Evident](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9585013/) | *Sports Medicine* (P O’Halloran, A Kontos, & M Collins 2022)

**Types of concussions**: [Concussion Guidelines Step 2: Evidence for Subtype Classification](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6911735/) | *Neurosurgery* (A Lumba-Brown et al. 2020)

**Diagnosis and management of mild TBI in children**: [Diagnosis and Management of Mild Traumatic Brain Injury in Children: A Systematic Review](https://jamanetwork.com/journals/jamapediatrics/article-abstract/2698455?resultClick=1) |  *JAMA Pediatrics* (A Lumba-Brown et al. 2018)

**Effectiveness of vestibular rehabilitation intervention**: [A Randomized Controlled Trial of Precision Vestibular Rehabilitation in Adolescents following Concussion: Preliminary Findings](https://pubmed.ncbi.nlm.nih.gov/34450120/) | *Journal of Pediatrics* (A Kontos et al. 2021)

§

## People Mentioned

- [Mark Lovell](https://www.linkedin.com/in/mark-lovell-ph-d-facpn-a6a60833) (Chairman and Chief Scientific Officer at ImPACT) [7:00]
- [Joseph (Joe) Maroon](https://www.neurosurgery.pitt.edu/people/joseph-maroon) (Clinical Professor of Neurological Surgery at the University of Pittsburgh Medical Center) [7:00, 1:15:45]
- [Grant Iverson](https://researchers.mgh.harvard.edu/profile/10328909/Grant-Iverson) (Professor of Physical Medicine and Rehabilitation at Harvard Medical School, Clinical Investigator and Psychologist at Mass General) [59:15]

§

![](https://peterattiamd.com/wp-content/uploads/2023/07/bio-mickycollins-500x500.png)

##### Michael "Micky" Collins, Ph.D.

Michael “Micky” Collins earned his Bachelor’s degree in psychology and biology at the University of Southern Maine where he played in the 1989 NCAA Baseball College World series. He earned a Master’s Degree in Psychology and a Doctorate degree in Clinical Psychology at Michigan State University.

Dr. Collins is a clinical neuropyscholgist and the Executive and Clinical Director and a founding member of the University of Pittsburgh Medical Center (UPMC) [Sports Medicine Concussion Program](https://www.upmc.com/services/sports-medicine/services/concussion). Established in 2000, this program was the first of its kind, and it remains the largest research and clinical program focused on the assessment, treatment, rehabilitation, research and education of sports-related mild traumatic brain injury in athletes of all levels. The program serves roughly 20,000 patients each year at six locations across Pittsburgh, PA.

In addition to his extensive clinical experience, Dr. Collins has been a lead author on several major groundbreaking studies of high school and college athletes published in *JAMA, Neurosurgery, American Journal of Sports Medicine,* and *Pediatrics*, and an author on more than 70 peer-reviewed research articles for other prestigious medical journals. He is a frequently invited presenter at international and national scientific meetings on brain injury in sports, and is often interviewed by local and national news media as an expert source.

Dr. Collins’ professional memberships include the International Neuropsychological Association, National Academy of Neuropsychology, and the North American Brain Injury Society. He serves on the editorial boards of the *Journal of Athletic Training* and *Brain Injury Professional*.

Dr. Collins has been instrumental in the development of numerous concussion management programs at the youth sports level nationwide. He has become a national leader in teaching and implementing the proper use of baseline and post-injury neuro-cognitive testing as a tool to help determine injury severity and recovery for safe return to play for young athletes. In addition to training hundreds of physicians and athletic trainers in the diagnosis and management of sports-related concussion, he was the co-lead author of the Centers for Disease Control’s “[Concussion Tool Kit for Physicians](https://www.cdc.gov/TraumaticBrainInjury/index.html),” which has been disseminated nationwide to several physician subspecialties as an education standard regarding concussion management. He co-authored the textbook [*Concussion: A Clinical Profile Approach to Assessment and Treatment*](https://www.amazon.com/Concussion-Clinical-Approach-Assessment-Treatment/dp/1433828235), and he co-founded [ImPACT](https://impactconcussion.com/), the most widely used computerized sports-concussion evaluation system. Dr. Collins is an advisor to numerous athletic organizations, including USA Rugby, US Lacrosse, Cirque De Soleil, Pittsburgh Steelers, Pittsburgh Penguins, and others. The North American Brain Injury Society recognized Dr. Collins with the 2005 Innovations in Treatment Award, given annually to an individual for developing and implementing innovative and efficacious treatment for persons with brain injuries. [[UPMC](https://www.upmc.com/media/experts/michael-collins)]