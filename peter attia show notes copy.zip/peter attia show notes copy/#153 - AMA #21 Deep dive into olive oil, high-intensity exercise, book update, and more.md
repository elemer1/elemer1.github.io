# #153 – AMA #21: Deep dive into olive oil, high-intensity exercise, book update, and more

**Source:** [https://peterattiamd.com/ama21/](https://peterattiamd.com/ama21/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob take a deep dive into olive oil. They explore the history of olive oil, discuss observational data that led to the hypothesis that olive oil is a healthier alternative to many other fats, and they explain the classification of olive oil types —including what to look for in a high-quality “extra virgin” olive oil. Peter and Bob round out the discussion with a “two-minute drill,” in which Peter answers questions from subscribers. They cover zone 5 training, an update on Peter’s book, lactate meters, standing desks, massage guns, electrolyte supplementation, and more.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #21 show notes page](https://peterattiamd.com/ama21/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The early history of olive oil and the Mediterranean diet (2:15);
- The three broad categories of fats: SFA, MUFA, and PUFA (6:25);
- Exploring the hypothesis that olive oil is healthy (10:30);
- Comparing olive oil to the makeup of other common oils (30:00);
- Defining “extra virgin” olive oil, what to look for when purchasing, and Peter’s favorite brand (34:30);
- Update on Peter’s book (47:15);
- Zone 5 training: Peter’s approach to zone 5 training, and other anaerobic training protocols (49:30);
- Advantages of using a standing desk compared to sitting (55:30);
- Lactate meters and strips (57:45);
- Electrolyte supplementation during fasting and keto, and why uric acid may increase (59:30);
- The usefulness of massage guns, foam rollers, and professional massage for muscle pain and tightness (1:01:30); and
- More.

§

The Peter Attia Drive

Deep dive into olive oil, high-intensity exercise, book update, and more

§

## Show Notes

## The early history of olive oil and the mediterranean diet [2:15]

**Background on the idea that olive oil is healthy**

- We always hear that olive oil is really healthy for us—that it’s heart-protective—Is it truly cardio-protective?
- At the surface, the idea is pretty straightforward, but the “further you get from shore, the deeper the water gets”

*So where does this perceived benefit of olive oil come from?*

- First and foremost, it stems primarily from the observational data of the [mediterranean diet](https://en.wikipedia.org/wiki/Mediterranean_diet)
- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) was the first to champion the diet in the 1970s and promoted heavily in the 1990s
- Keys was the first utilize and incorporate an assay for measuring serum blood cholesterol
- In the early 1950s, Keys and his wife traveled abroad and began observing societies, and asking a very simple question, “*Does the total serum cholesterol correlate with heart disease?*”
  - The answer was ‘**yes it did’**
- Of course, as time would go on and we would learn that there were different fractions of cholesterol—LDL cholesterol, HDL cholesterol, non-HDL cholesterol, etc. and we would refine that thinking
- But at the simplest level, when you took the bottom five percentile of people’s total cholesterol and the top five percentile of people with total cholesterol, you could predict those with higher cholesterol had more heart disease
- With that, the idea that what you ate could influence total serum cholesterol became the next and obvious thing to look at
- The way Keys presented his data would suggest that the more **saturated fat** that was in the diet, the higher the cholesterol, the higher the incidence of heart disease (but it turns out the devil is in the details)
- By the 1970s, Keys was really coming to an observation that a diet that was high in a different type of fat from a saturated fat called a *monounsaturated fat* would actually be more heart healthy
- Keys believed that food sources that were high in saturated fats were the problem, whereas those that were high in polyunsaturated and monounsaturated fats were going to be cardio-protective

## The three broad categories of fats: SFA, MUFA, and PUFA [6:25]

⇒ See [Bill Harris episode](https://peterattiamd.com/billharris/) about fatty acids

**1-Saturated fats**

**2-Monounsaturated fats**

**3-Polyunsaturated fats**

Saturated fats (SFA)

- They are “saturated” with hydrogen
- SFA are a long single chain of carbon atoms all hooked together (single bonds)
- The number of those single bonds will differentiate between different types of saturated fat (palmitic acid versus stearic acid, for example — [image](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-1.-SFA-billharris.png))

Monounsaturated fats (MUFA)

- These have the same long carbon chain as SFA (It can be 12, 14, 16, 18 carbons long)
- But there’s one double bond in a monounsaturated fatty acid ([image](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-2.-MUFA-billharris.png))
- When there’s a double bond in a molecule, it now has a point of unsaturation

Polyunsaturated fats (PUFA)

- Instead of one double bond, now we have two or more double bonds ([image](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-3.-PUFA-billharris.png))
- The same long carbon chain with now two or three typically double bonds
- PUFA is going to be *more unsaturated* than a monounsaturated fat

*The nomenclature is important*, says Peter

- An SFA called palmitic acid, for example, is referenced a certain way based on it’s structure
- We wouldn’t expect people to remember the structure of palmitic acid, so we would denote it **16:0**
  - It’s got 16 carbons in it, and it has **zero double bonds (**Therefore, you know it’s a saturated fat)
- Stearic acid, another SFA, is 18:0, so you would know that it’s got 18 carbons and zero double bonds
- Contrast that with oleic acid
  - Oleic acid now has another designation—18:1—So it’s 18 carbons and one double bond
  - But you have to add an additional piece of information, which is: *where is that double bond?*
    - It’s denoted N9, which means that it’s the ninth carbon
  - Well which side are you counting from?
    - Because the 9th and the 10th carbons‚ even though right next to each other, could each be considered the ninth carbon depending on which side you count from
    - The answer is that **you always count from the carboxylic side**
- Suffice it to say there’s a clear nomenclature for which side you begin the counting and, therefore, you can have an 18:1 N7 and an 18:1 N9 that are both monounsaturated fats of the same length, but they’re going to have different properties because the double bond is in a different place

## Exploring the hypothesis that olive oil is healthy [10:30]

**What were some of the observations that suggested a health benefit of olive oil?**

-So there was the observation that populations that consumed high amounts of olive oil and other monounsaturated fats had better health

-From that, a number of hypotheses popped up:

- First, **less saturated fats**
  - if they’re eating more MUFA, they’re eating less saturated fats
  - And at least according to Ancel Keys, saturated fats were the primary dietary driver of cardiovascular disease
- Secondly, more **oleic acid**
  - monounsaturated fats (such as oleic acid) is very high in vitamin E, which is known to be a **very potent antioxidant**
  - Oleic acid is also [considered to have some antithrombotic properties](https://pubmed.ncbi.nlm.nih.gov/1681350/)—meaning it reduces the coagulability of blood
- Thirdly, **less PUFA**
  - If you’re higher in MUFA, you’re going to be lower in PUFA
  - PUFA is a carbon chain that has at least two sources of saturation which means—
    - they are more prone to reactive oxygen species that can interfere with those double bonds ([Reaven et al., 1991](https://pubmed.ncbi.nlm.nih.gov/1897476/); [Parthasarathy et al., 1990](https://www.pnas.org/content/87/10/3894))
    - and the oxidation of LDLs (Low density lipoproteins) is a particularly damning problem in the generation of atherosclerosis
- Fourth, substituting olive oil for carbohydrates in the short-term **increased HDL cholesterol without increasing LDL cholesterol** ([Mattson and Grundy, 1985](https://pubmed.ncbi.nlm.nih.gov/3989378/); [Mensink and Katan, 1987](https://pubmed.ncbi.nlm.nih.gov/2879969/))
  - But now we’re working on multiple layers of inductions—
    - there was the observation that as HDL goes up, it’s cardio protective
    - But that’s a grossly, overly simplistic essentially incorrect assumption that is associative, but nevertheless this reinforces the idea

**The above hypotheses have been largely accepted**: [14:00]

**A** [**2014 meta-analysis**](https://lipidworld.biomedcentral.com/articles/10.1186/1476-511X-13-154)**,** for example, concluded that an elevated consumption of olive oil is associated with reduced risk of all-cause mortality, cardiovascular events and stroke, while monounsaturated fatty acids of mixed animal and plant origin showed no significant effects.

- When comparing the top versus bottom third of MUFA, olive oil, oleic acid, and MUFA:SFA ratio, the results indicate—
  - An overall risk reduction of all-cause mortality (11%)
  - Cardiovascular mortality (12%)
  - Cardiovascular events (9%); and
  - Stroke (17%)
- Major issues with this meta-analysis:
  - First, the large majority of this analysis was done by looking at **observational data** which rely on retrospective questionnaires—32 cohort studies, 42 reports, and close to a million subjects
  - It’s nearly impossible to you tease out/isolate one variable with food
    - A porterhouse steak, for example, has high amounts of saturated fat, but it also contains quite a bit of oleic acid
  - Another huge issue is [healthy user bias](https://en.wikipedia.org/wiki/Healthy_user_bias#:~:text=The%20healthy%20user%20bias%20or,of%20particular%20therapies%20or%20interventions.&text=For%20example%2C%20someone%20in%20ill,a%20job%20as%20manual%20laborer.):
    - If we’re told that monounsaturated fats, mediterranean diets, and olive oil are good for us, and we’re told that saturated fats are bad for us, when we study the eating patterns and behavior, we are really just testing for a person’s interest in being healthy more than anything else

**In** [**Lyon Diet Heart study**](https://www.ahajournals.org/doi/full/10.1161/01.cir.99.6.779)**,**

Design

- First study to separate itself from these pure observational studies—a true randomized trial looking at secondary prevention in the sense that they are looking at the prevention of cardiovascular complications in people who had already had them
  - When you’re trying to study something prospectively, you don’t necessarily want to take a group of healthy people and wait 30 years for something to go wrong
  - instead, you want to take people in whom you think the likelihood of something going wrong is very close
  - There’s actually no better population to study this than people who just survived a heart attack

Results

- This study reported benefits from a mediterranean diet (which generally is high in olive oil):
  - Incidence of [MACE](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events#:~:text=The%20so%2Dcalled%20%22classical%203,cardiac%20death%2C%20or%20MACE%22.) after about 4 years was lower in those assigned a MeDiet (~67% relative reduction; ~6% annual absolute reduction) compared to those assigned an AHA prudent diet.
  - All-cause mortality was also lower (~56% relative reduction; ~1% annual absolute reduction)

Notes

- The intervention group was consuming a lot of oleic acid (which makes up ~50% of olive oil)
- Note that the investigators created “margarine” with ~50% oleic acid for the French population who were used to eating butter and didn’t want to “mainline” olive oil for the study

[**PREDIMED study**](https://www.nejm.org/doi/10.1056/NEJMoa1800389?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed)

⇒ See [John Ioannidis episode](https://peterattiamd.com/johnioannidis/) where they discusses the major flaws of the PREDIMED study

This was a primary prevention study that was cleverly designed:

- Primary prevention studies are very challenging because you have to potentially wait a long time to see any signal (e.g., statin trials have always been very challenging to do because you can barely get a signal after five to seven years)
- But in this study they took people who hadn’t suffered a heart attack, stroke, or had cancer, however they did have metabolic syndrome — in other words, these people are very close to the edge

The put people into three different groups:

- One group had high extra virgin olive oil
- Another group had a diet high in walnuts, almonds, and hazelnuts (high MUFA in nuts)
- The third group was put on a low-fat diet

Results:

- The study was halted after about five years because the protective benefit of the two mediterranean arms was so high
- In short, despite some flaws (See [John Ioannidis episode](https://peterattiamd.com/johnioannidis/)), the PREDIMED provided reinforcement to this idea that was shown in the Lyon diet heart study along with all of the observational data

**Overall thoughts and considerations about the above data**:

- Suffice it to say that there seems to be reasonable evidence that a mediterranean diet is a good diet in the sense that it preserves the obvious features of a good diet (no processed foods, low in sugars, etc.)
- In fact, pretty much all “diets” advocate for less processed foods and refined carbohydrates/added sugar

But is it the case that a mediterranean diet stands above the rest amongst all of those?

- Peter says “I’m not sure…It might also depend on what we’re talking about, maintenance, prevention or treatment.”

Not all diets work for all people:

- You could also make the case that taking someone who doesn’t have diabetes and whose hemoglobin A1c is not 14, maybe taking someone who’s, say, nominally healthy, putting them on mediterranean diet for the purpose of prevention might be a totally great strategy
- Whereas maybe taking someone with NAFLD, NASH, type two diabetes, might require a different strategy, either one that restricts fructose and calories significantly and/or one that restricts carbohydrates, respectively

“So, that’s another thing worth keeping in mind is that think of diets like drugs and no one would ever believe that there is one drug that should be used by everyone for everything.” —Peter Attia qk

## Comparing olive oil to the makeup of other common oils [30:00]

![](https://peterattiamd.com/wp-content/uploads/2021/03/fats-1024x503.png)

**Figure 1. Comparing fat composition of various oils.**

**Olive oil**

- Oleic acid, a MUFA, is the main fatty acid in olive oil

*How does that compare to some of the other fats out there?*

**Soybean oil**

- Most processed foods contain [soybean oil](https://en.wikipedia.org/wiki/Soybean_oil) which is made up of about about 24% MUFA, 16% SFA, and 53% PUFA
- By comparison, olive oil is about 75% MUFA

**Lard**

- People think of lard as a “brick of saturated fat”
- But it is actually about 46% MUFA, 42% SFA, and about 10% PUFA

**Corn oil**

- [Corn oil](https://en.wikipedia.org/wiki/Corn_oil) is also commonly found in processed foods
- It’s makeup is similar to soybean oil—29% MUFA, 13% SFA, and 57% PUFA

***“Naturally occurring oils”***

- When it comes to naturally occurring oils, there’s basically two that really concentrate MUFA—olive oil and [safflower oil](https://en.wikipedia.org/wiki/Sunflower_oil)

**Omega-6 and omega-3 polyunsaturated fatty acids**

- With vegetable oils (PUFAs), there’s only one that is high in omega-3—[flaxseed oil](https://en.wikipedia.org/wiki/Linseed_oil)
- It should be noted that it’s not a substitute for marine sources of omega-3 polyunsaturated fats that are high in [EPA](https://en.wikipedia.org/wiki/Eicosapentaenoic_acid) and [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid)
- The major modern seed oils are generally very high in the omega-6 polyunsaturated fats—corn oil, soybean oil, sunflower oil, and [cottonseed oil](https://en.wikipedia.org/wiki/Cottonseed_oil)—each of those being at least 50% omega-6
- They also contain some SFA—corn oil is 13% saturated, soybean is 16%, sunflower 11%, and cottonseed is 27%

**Highest in saturated fat**

- Lard is 42% saturated,
- beef tallow is 52%,
- butter is 68%,
- coconut oil is 91%

*NOTE*: Any food with fat is going to have all three, but coconut oil is the one that’s mostly saturated fat.

**Engineered oils**

- These oils are engineered to boost the oleic content to essentially match that of olive oil
- high-oleic sunflower is 86%
- high-oleic canola at 76%

## Defining “extra virgin” olive oil, what to look for when purchasing, and Peter’s favorite brand [34:30]

**Extra virgin olive oil**—*What defines the virginity of an oil?*

- There are legal requirements for extra virgin olive oil set by the [International Olive Council](https://en.wikipedia.org/wiki/International_Olive_Council)
- Olive oils must have certain tastes and chemical properties that are extra virgin grade
- There is literally people that are tasting oils to see if they actually meet extra virgin requirements
- Other stipulations are an oil must be made from healthy, expertly picked olives, milled within 24 hours of the harvest to preserve their flavors and avoid spoilage

> “This is an art as much as it is a science.” —Peter Attia

For more on this, check out the book [Extra Virginity](https://www.amazon.com/Extra-Virginity-Sublime-Scandalous-World/dp/0393343618)

- The author, Tom Mueller, also an article in the New Yorker: [Slippery Business](https://www.newyorker.com/magazine/2007/08/13/slippery-business)
- What Tom and others argue is that when looking at the chemical constituents of an olive oil, it’s easy to be fooled into thinking that an olive oil is extra virgin
- But based on taste, literally swishing it in your mouth like wine, there are particular taste profiles that determine whether these things are extra virgin or not

**Things to look for in a quality olive oil:**

**1 – Cost**

- The good olive oil is expensive.
- If it’s cheap, it’s probably not great

**2 – Harvest date**

- Instead of an expiration date on these bottles, you’ll see something that’s called a harvested date which tells you when they actually harvested the olives
- you want a harvested date within 18 months
- unlike wine, this stuff doesn’t get better with age

**3 – smell and taste**

- It should smell fresh like grass or something fruity
- Taste: it should have a bitter, peppery taste that bites the back of the throat

**4 – “Pure” and “Light” descriptors is a bad sign**

“*The area that I got burned on is whenever they use words like pure and light and things like that. To me, that’s code for garbage. I mean, it literally means pure garbage*.” —Peter

- The IOC can’t tell you that something is EVOO because of the macros in it, but the reverse is true
- If you look at a pure or light olive oil, it’s often very high in PUFA and significantly lower in MUFA — So, it’s pretty clear when you’re looking at something that’s bogus in that regard

**5 – Where it was produced**

- The label should tell you where that olive oil was produced
- Sometimes it will tell you it’s produced in multiple places, which means they’re harvesting in different places, and they’re mixing those olives together suggesting it’s not as pure or consistent as they are likely all harvested at different times

**6 – How it’s bottled**

- it should be in a dark cool place
- The darker glass bottle helps preserve the olive oil
- if you have fats that are unsaturated, particularly polyunsaturated fats, they can be more prone to oxidation — so when you have the darker bottle, there’s less likelihood of that happening

\*\*\*

Brand Peter likes: [Kosterina](https://www.kosterina.com/products/singlebottle?variant=31193716883492)

**Peter’s aha moment**

- Peter stumbled upon a store that only sold olive oil
- The store had big metal canisters with little spigots on them that you could dole out olive oil onto little plates and sample them with bread
- He was blown away at the strength of the taste of some of these oils
- Many of them had that peppery bitter taste in the back of the throat
- The oils were also “comically pricey” says Peter
- This experience made Peter think: “I need to up my game a little bit on olive oil because if there is any benefit to this, I want to make sure I’m getting it.”
- Overall, Peter says that the breadth of information we have on olive oil makes him think that being thoughtful about the olive oil you consume is worth the effort

**Peter’s approach with his patients**

- On a clinical level, Peter’s approach with patients regarding fat intake is optimal is a function of a number of things — Namely, how much carbohydrate and how much protein you need
- But whether a person’s diet is going to be 40% fat or 60% fat or more or less, **his belief is that no less than 50% of that should be monounsaturated, and ideally closer to 60%**

*So, what are the ideal sources for those monounsaturated fats?*

- i) olive oil,
- ii) macadamia nuts, and
- iii) avocados

> “Those become a great way to achieve your MUFA goals, and that’s part of what we consider the appropriate distribution of fat.” —Peter Attia

\*\*\*

**One more thing to consider:** *Olive oil made from an “early harvest” may be better*

- Consider the premise that there may be deleterious effects of excess [linoleic acid](https://en.wikipedia.org/wiki/Linoleic_acid), n-6 PUFA
  - Or for simplicity purposes, that you’d rather have more MUFA than PUFA in your diet
- With these olive oils, depending on the ripeness of the olive, the fatty acid composition has a range
  - In other words, the oleic acid within the olive oil can vary from 55% to 83% of the total fat in the olive oil
  - So you could have two extra virgin olive oils because the extra virginity of it doesn’t speak to its distribution of oil (It’s really a function of the harvest, the taste, etc.)
  - Considering that oleic is basically 99% of the MUFA in olive oil, you could have it be as low as 50% of total fat and as high as 70+%
  - The linoleic acid ranges from about 3.5% to 21% of olive oil

![](https://peterattiamd.com/wp-content/uploads/2021/03/Composition-ranges-of-olive-oil-1024x352.png)

**Figure 2. Composition ranges of olive oil.** [[Beltrán et al., 2004](https://hera.ugr.es/doi/15058025.pdf)]

- According to the [literature](https://hera.ugr.es/doi/15058025.pdf),
  - During the ripening process, the more ripe the fruit, the ratio of MUFA to PUFA falls — So, the polyunsaturated fat content is greater
  - Basically, the earlier you harvest, the unripe olive is going to give you the highest amount of oleic acid and the least amount of linoleic acid

> “If you buy the argument that oleic is good, which I buy, and if you buy the argument that linoleic is suboptimal, which I’m not sure I buy, the earlier is better.” —Peter Attia

## Update on Peter’s book [47:15]

- About 12 months ago, Peter decided to change publishers
- He is currently shopping around for a new publisher
- This has pushed back the release of his book
- The good news is that he does have a manuscript ready to be reviewed by an editor
- Peter’s hope is that the book hits shelves in January of 2022

## Zone 5 training: Peter’s approach to zone 5 training, and other anaerobic training protocols [49:30]

**Peter’s zone 5 protocol**

On his stairmaster:

- One time per week using a **stairmaster**
- 4 minute pattern:
  - 3 minutes of zone 2
  - 1 minute at his VO2 max
  - Repeat for 20-30 minutes
- He usually does this on the tail end of a zone two workout (his longer aerobic day)
- Note: Peter knows his VO2 max and also knows the conversion to [METS](https://mets) which the stairmaster can track

He also does zone 5 on his bike:

- Four minutes at 125% of FTP (functional threshold power)
- Followed by four minutes recovery
- A one to one work/rest at a lower intensity than the 3 to 1 one rest to work that described on the stairmaster

> “My view is most people spend too much time there and not enough time in zone 2.” —Peter Attia

**Follow up questions**:

*What kind of stairmaster does Peter use?*

- The stairmaster Peter uses is a series of eight-inch steps that roll up and down (like an escalator)
- The higher the intensity you set it, the less resistance is in those steps and the faster you have to go to not fall off the back
- If Peter sets it to 8 METs, there’s actually quite a bit of resistance so he can step quite slowly without falling off
- But when set to 20 METs, it feels like there’s no resistance and he’s running up the stairs to not get thrown off the back

*Is it possible to go “all-out” or 100% for an extended period of time?*

- Basically, the limits of human performance in terms of “going all out” is about 10 seconds (despite what your spin class instructor might tell you)
  - See [Alex Hutchin](https://alexhutchinson.net/)’s book, [Endure](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866)
  - Also, check out the [podcast episode with Alex](https://peterattiamd.com/alexhutchinson/)
- You only need to look at the difference between a 100-meter and a 200-meter sprint
  - So, take the best explosive athletes on the planet — even by the time [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) is running the 200m, he is slowing down in the second half of that race
  - The force with which he’s able to hit the ground in the second half of that race is slower
  - The 100-meter race is basically a 10-second race is about the true limit of what “all out” means

*Let’s look at tabata workouts*:

- Consider two variants of Tabata: i) The 20:10 (20 sec spring with 10 sec recovery) and ii) the 10:20 (10 sec sprint with 20 sec recovery)
- Air bikes are a great tool for doing these types of workouts
- You can go so much harder for the 10:20 than the 20:10
- The 20:10 is generally favored because that’s the one that was studied by [Izumi Tabata](https://en.wikipedia.org/wiki/Izumi_Tabata) (the guy who wrote the papers) and [Koichi Irisawa](https://www.ritsumei.ac.jp/rs/category/tokushu/150715/) (the guy who actually developed the workout protocol)
- The problem with a “20:10 Tabata” is whether consciously or subconsciously you’re actually pacing yourself to complete it

\*\*\*

*Quick aside on the history of “Tabata” protocols*:

- [Tabata protocols](https://www.ritsumei.ac.jp/rs/category/tokushu/150715/) were actually devised in the early 1990s by Kouichi Irisawa, head coach of the Japanese national speed skating team
- Izumi Tabata was hired by Kouichi to test the effectiveness of the interval training program
- “*Although Coach Irisawa pioneered the idea*,” Tabata [said](https://web.archive.org/web/20151226092017/http:/www.ritsumei.ac.jp/eng/html/research/areas/feat-researchers/interview/izumi_t.html/) in 2015, “s*omehow it became named after me.*”

## Advantages of using a standing desk compared to sitting [55:30]

*Is standing in one place for most of the day a big improvement over sitting?*

*If so, why? More Calories burned? Less Muscle tightness? Less overstretching?*

- It depends on how engaged you are, meaning if you sit with no attention to the muscles of the abdomen and the thorax, sitting can be actually quite detrimental
- Generally speaking, when standing you have more engaged paraspinal muscles, abdominal muscles, obliques, transversalis, etc.
- That said, you can stand in a horrible manner and still be doing harm *relative to walking*
- Walking is preferred to sitting not just because of the energy expenditure, but because it forces you to actively engage muscles that prevent you from a bad postural position

**Most common postural mishaps:**

- [Anterior pelvic tilt](https://miro.medium.com/max/450/1*RF-LqLY1ZBkgiwHNmUQxLA.jpeg)
- [Rib flared](https://balancemotion.com/rib-flare-why-it-sucks-and-why-you-should-care/) upward lordotic position
- “*It’s very easy to* ***stand*** *in that position*.”

![](https://peterattiamd.com/wp-content/uploads/2021/03/anterior-pelvic-tilt-837x1024.png)

**Figure 3. Anterior pelvic tilt.** [[source](https://miro.medium.com/max/450/1*RF-LqLY1ZBkgiwHNmUQxLA.jpeg)]

⇒ Check out episode of the Drive with [Beth Lewis](https://peterattiamd.com/bethlewis/) and [Michael Rintala](https://peterattiamd.com/michaelrintala/)

**How Peter avoids the issues from sitting**:

- He spends a lot of time practicing sitting in a very actively engaged way
- He also don’t sit for hours at a time
- He is constantly getting up and moving around

***Is sitting the new smoking?***

“I don’t know”, says Peter, “I understand the sentiment of that statement, but I’m not sure I’d take it quite that far.”

> “I’d say inactivity, in general, might be the new smoking of which sitting is a component.” —Peter Attia

## Lactate meters and strips [57:45]

*What strips or devices are good enough for the regular guy to measure lactate levels to confirm zone two after exercise?*

*There seem to be some very expensive devices out there. Is there something decent for home use?”*

- Peter currently uses the [Lactate Plus by Nova](https://novabiomedical.com/lactate-plus/index.php)
  - This one is easy to get, but it’s also not cheap, and the cost of the strips are very expensive at ~$4 each
  - There may be a more affordable device + strips out there but Peter can’t speak to that
  - You can pace yourself at the frequency with which you want to do lactate testing
- When to use the meter:
  - Peter personally does the lactate test every single time he does his zone 2 workouts — “*That’s not necessary… [but] I’m obsessed with it so that’s why I do it*.”
  - “*Once you get your groove on and identify your zone 2 and start to figure out what roughly corresponds to it heartrate-wise and power-wise (if you’re using wattage), I think your cost of use will go down*.”

⇒ For more on zone 2 and lactate testing, check out [AMA #19](https://peterattiamd.com/ama19/)

## Electrolyte supplementation during fasting and keto, and why uric acid may increase [59:30]

After listening to the Dom D’Agostino AMAs ([Part 1](https://peterattiamd.com/domdagostinoama01/) and [Part 2](https://peterattiamd.com/domdagostinoama02/)) and the [Rick Johnson episode](https://peterattiamd.com/rickjohnson/), a subscriber has a question about electrolyte supplements as well as about salt and uric acid and ketogenesis:

*If salt does this conversion to fructose in the body, how is that affecting keto?*

- “Good question. I don’t think I know the answer.” says Peter
- As a general rule, the salt supplementation in keto is really not necessary for everyone, and personally for Peter, he doesn’t find it necessary during his brief periods of keto (and even when he’s short periods of fasting)
- However, during the longer fasts, Peter does need sodium, but that’s because he’s not eating food and he’s trying to just get sodium back to normal levels
- In keto, he does not supplement sodium at all, but he does supplement magnesium
- Again, when he’s fasting, he needs more magnesium and sodium, but that’s just to bring him up to what he’s not getting with his nutrition

**Potential change in uric acid**

-Peter says why uric acid may increase is an interesting question and he’s not sure he knows the answer

-But he has some thoughts on it…

- First, we clearly see uric acid spike during a fast
- And, there’s probably also an increase during ketosis
  - I*s it transient in ketosis?*
  - If so, *is it because uric acid and BHB are competing for the same transporters in the kidney?*  ⇒ That would obviously explain why you would see it in a fast
- *An alternative explanation*, which doesn’t have to be mutually exclusive, is that uric acid is going up because of the turnover of DNA that would take place during a fast, vis-a-vis autophagy and things like that.

## The usefulness of massage guns, foam rollers, and professional massage for muscle pain and tightness [1:01:30]

*Massage guns versus foam roller versus professional massage. How similar and effective are each of these?*

**Professional massage**:

- Most effective with the strong caveat that it’s highly dependent on the person giving the treatment

**Massage guns**:

- Be careful — it’s easy to go too hard with them so be mindful of not putting too much tension into the tissue

⇒ For example: Many think that if they feel pain or tightness in their back, for example, the best strategy is to just pulverize the muscle to loosen it up

- But the reality is that perhaps your back hurts because your QLs and paraspinous muscles have seized up
- And what people are missing in that situation is that they’ve seized up to protect you — your brain is basically saying, “You are in an unsafe position. I’m going to protect you by reducing your range of motion and I’m going to do that by locking these muscles in place.”
- So the massage gun isn’t really addressing the problem, and often it doesn’t necessarily make you feel that much better
- A *better course of action may be*:
  - More gentle massage work coupled with muscle relaxants
  - Then of course fixing the underlying problem

**Foam rollers**:

- They are a reasonable tool
- Peter doesn’t use them that much anymore
- His warmups now are much more dynamic and less about tissue preparation

§

## Selected Links / Related Material

**Oleic acid is also considered to have some antithrombotic properties—meaning it reduces the coagulability of blood**: [Coronary heart disease: seven dietary factors](https://pubmed.ncbi.nlm.nih.gov/1681350/) (Ulbricht and Southgate, 1991) [12:00]

**PUFA is a carbon chain that has at least two sources of saturation which means they are more prone to reactive oxygen species that can interfere with those double bonds**: [12:15]

- [Feasibility of using an oleate-rich diet to reduce the susceptibility of low-density lipoprotein to oxidative modification in humans](https://pubmed.ncbi.nlm.nih.gov/1897476/)) (Reaven et al., 1991)
- [Low density lipoprotein rich in oleic acid is protected against oxidative modification: implications for dietary prevention of atherosclerosis.](https://www.pnas.org/content/87/10/3894) (Parthasarathy et al., 1990)

**Clinical studies showing that substituting olive oil for carbohydrates in the short-term increased HDL cholesterol without increasing LDL cholesterol**: [13:15]

- [Comparison of effects of dietary saturated, monounsaturated, and polyunsaturated fatty acids on plasma lipids and lipoproteins in man](https://pubmed.ncbi.nlm.nih.gov/3989378/) (Mattson and Grundy, 1985)
- [Effect of monounsaturated fatty acids versus complex carbohydrates on high-density lipoproteins in healthy men and women](https://pubmed.ncbi.nlm.nih.gov/2879969/) (Mensink and Katan, 1987)

**2014 meta analysis of data on olive oil**: [Monounsaturated fatty acids, olive oil and health status: a systematic review and meta-analysis of cohort studies](https://lipidworld.biomedcentral.com/articles/10.1186/1476-511X-13-154) (Schwingshackl and Hoffmann, 2014) [14:00]

**Lyon Diet Heart Study: A randomized trial Lyon looking at secondary prevention of cardiovascular complications with subjects on the mediterranean diet**: [Mediterranean Diet, Traditional Risk Factors, and the Rate of Cardiovascular Complications After Myocardial Infarction](https://www.ahajournals.org/doi/full/10.1161/01.cir.99.6.779) (Lorgeril et al., 1999) [17:00]

**PREDIMED study—primary prevention study including a group eating extra virgin olive oil**: [Primary Prevention of Cardiovascular Disease with a Mediterranean Diet Supplemented with Extra-Virgin Olive Oil or Nuts](https://www.nejm.org/doi/10.1056/NEJMoa1800389?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) (Estruch et al., 2018) [21:30]

**Episode of The Drive with John Ioannidis where they discuss the flaws of the PREDIMED study**: [#143 – John Ioannidis, M.D., D.Sc.: Why most biomedical research is flawed, and how to improve it](https://peterattiamd.com/JohnIoannidis/) | Peter Attia (peterattiamd.com) [22:00]

**The International Olive Council that defines “extra virgin”**: [The International Olive Council](https://www.internationaloliveoil.org/) | (internationaloliveoil.org) [34:45]

**Book about the olive oil industry**: [Extra Virginity: The Sublime and Scandalous World of Olive Oil](https://www.amazon.com/Extra-Virginity-Sublime-Scandalous-World/dp/0393343618) by Tom Mueller | (amazon.com) [35:30]

- **Tom Mueller article in the New Yorker**: [Slippery Business](https://www.newyorker.com/magazine/2007/08/13/slippery-business) | Tom Mueller (newyorker.com) [35:45]

**Peter’s preferred brand of olive oil**: [Kosterina](https://www.kosterina.com/) | (kosterina.com) [41:00]

**The unripe olive is going to give you the highest amount of oleic acid and the least amount of linoleic acid**: [Influence of Harvest Date and Crop Yield on the Fatty Acid Composition of Virgin Olive Oils from Cv. Picual](https://hera.ugr.es/doi/15058025.pdf) (Beltrán et al., 2004) [45:45]

**Episode of The Drive with Alex Hutchinson where they talk about true sprint speed only being about 10 seconds**: [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/) | Peter Attia (peterattiamd.com) [53:00]

- **Great book by Alex Hutchinson**: [Endure: Mind, Body, and the Curiously Elastic Limits of Human Performance](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866) by Alex Hutchinson | (amazon.com) [53:00]

**Peter’s preferred lactate meter**: Lactate Plus. That’s the yellow and purple one made by Novo Nordisk [58:00]

**Dom D’Agostino AMAs**: [59:30]

- *Part 1*: [#116 – AMA with Dom D’Agostino, Ph.D., Part I of II: Ketogenic diet, exogenous ketones, and exercise](https://peterattiamd.com/domdagostinoama01/) | Peter Attia (peterattiamd.com)
- *Part 2*: [#120 – AMA with Dom D’Agostino, Ph.D., Part II of II: Ketosis for cancer and chronic disease, hyperbaric oxygen therapy, and the effect of ketosis on female health](https://peterattiamd.com/domdagostinoama02/) | Peter Attia (peterattiamd.com)

**Episode of The Drive with Rick Johnson where they discuss uric acid**: [#87 – Rick Johnson, M.D.: Fructose—The common link in high blood pressure, insulin resistance, T2D, & obesity?](https://peterattiamd.com/rickjohnson/) | Peter Attia (peterattiamd.com) [59:30]

§

## People Mentioned

- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) [3:30]
- [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis) [22:00]
- [Tom Mueller](https://twitter.com/tommuellerx?lang=en) (Author of Extra Virginity) [35:30]
- [Alex Hutchinson](https://twitter.com/sweatscience), who is going to be on the podcast [53:00
- [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) [53:45]
- [Koichi Irisawa](https://www.ritsumei.ac.jp/rs/category/tokushu/150715/) [54:45]
- [Izumi Tabata](https://en.wikipedia.org/wiki/Izumi_Tabata) [54:45]
- [Dom D’Agostino](https://ketonutrition.org/about/) [59:30]
- [Rick Johnson](https://peterattiamd.com/rickjohnson) [59:30]

§