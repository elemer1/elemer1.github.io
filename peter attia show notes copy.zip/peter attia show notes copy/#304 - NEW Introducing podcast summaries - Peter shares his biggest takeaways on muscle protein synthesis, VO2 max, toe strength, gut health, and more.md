# #304 – NEW: Introducing podcast summaries – Peter shares his biggest takeaways on muscle protein synthesis, VO2 max, toe strength, gut health, and more

**Source:** [https://peterattiamd.com/qps1/](https://peterattiamd.com/qps1/)

---

In this podcast summary episode, Peter introduces a new format aimed at summarizing his biggest takeaways from the last three months of guest interviews on the podcast. Peter shares key insights from each episode, covering diverse topics such as protein and muscle building with Luc van Loon, toe strength with Courtney Conley, VO2 max with Olav Aleksander Bu, liquid biopsies for cancer with Alex Aravanis, gut health and probiotics with Colleen Cutcliffe, and road safety with Mark Rosekind. Additionally, Peter shares any personal behavioral adjustments or modifications to his patient care practices that have arisen from these engaging discussions.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [episode #304 show notes page](https://peterattiamd.com/qps1/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- How Peter keeps track of his takeaways from each podcast episode [5:15];
- Luc van Loon episode: fat utilization, muscle protein synthesis, dietary protein, aging and inactivity, and more [8:45];
- Behavioral changes that have come about from the conversation with Luc van Loon [23:45];
- Courtney Conley episode: importance of toe strength and the impact of dedicated foot training [26:45];
- Olav Aleksander Bu episode: the importance of VO2 max for lifespan, and the practicalities of measuring and improving VO2 max [36:45];
- Behavioral changes that have come about from the conversation with Olav [56:00];
- Alex Aravanis episode: liquid biopsies for cancer detection [1:01:30];
- Colleen Cutcliffe episode: the importance of gut bacteria balance, and the potential therapeutic uses of probiotics, particularly Akkermansia [1:16:45];
- Mark Rosekind: the significant issue of road fatalities and injuries, their causes, and practical safety measures to reduce risks [1:27:00]; and
- More.

§

The Peter Attia Drive

NEW: Introducing podcast summaries - Peter shares his biggest takeaways on muscle protein synthesis, VO2 max, toe strength, gut health, and more

§

## Show Notes

\***Notes from intro**:

- Welcome to a special AMA episode of *The Drive*, we know that at times our interviews can be quite technical, and one of the most common requests we hear is that listeners would love to hear summaries of episodes we’ve done
  - We’re testing out a new style of AMA for this episode
- Before we get to it, Peter explains how he interacts with his podcast
  - He has an amazing team of analysts that help him prepare for each and every episode
  - He is typically going into an interview with anywhere from 10-20 pages of single-spaced notes that have him very familiar with the topic of discussion and lay the groundwork for where we’re going to go
  - During the interviews, Peter is feverishly taking notes because he’s learning as the podcast is going
  - At the end of every podcast, he typically takes the most important things that he has learned, and he transcribes them onto 5×8” cards
    - Any podcast might have somewhere from 1-4 of these
    - You can imagine someone doing this back in the way you would make a crib sheet in college: very small writing, but nothing on there is wasted
    - Sometimes there’s diagrams, tables, etc.
- It occurred to us that people might want to see what Peter’s takeaways are from a podcast
- In this episode, we’re going to look back over the last quarter’s podcasts and Peter will share his notes of what he learned personally and what he thinks were the most important insights
- In addition, he is going to comment (where applicable) if any of these learnings have led to a behavior change for Peter and/or his patients
- In this summary AMA we cover the following podcasts:
  - [Luc van Loon](https://peterattiamd.com/lucvanloon/) – protein and muscle building
  - [Courtney Conley](https://peterattiamd.com/courtneyconley/) – foot health
  - [Olav Aleksander Bu](https://peterattiamd.com/olavaleksanderbu/) – VO2 max
  - [Alex Aravanis](https://peterattiamd.com/alexaravanis/) – liquid biopsies
  - [Colleen Cutcliffe](https://peterattiamd.com/colleencutcliffe/) – gut health
  - [Mark Rosekind](https://peterattiamd.com/markrosekind/) – road safety
- Through these episodes, we speak about topics such as:
  - Protein, building muscle
  - VO2 max
  - The importance of toe strength and lower leg strength
  - Liquid biopsies and cancer
  - The gut microbiome and probiotics
  - How to mitigate the risks of automotive deaths
- To be clear, Peter doesn’t think this podcast is remotely a substitute for having listened to those podcasts
  - If you’re only listening to this, having not listened to that, the information that Peter spits out will be kind of jarring and might lack some context
- Peter hopes this is viewed as an adjunct to being able to listen to the podcast
  - And it might serve as a reason to go and what he talks about peaks your interest
- As this is a new episode style, if you like it and if you find value in this conversation, please let us know
  - Because we’ll continue it
  - Obviously if people don’t find this interesting, there’s no need for us to do it, and we could go back to regular AMAs
- If you’re a subscriber and you want to watch the video of the full of this podcast, you can find it on the [show notes page](https://peterattiamd.com/category/podcast/)
- If you’re not a subscriber, you can watch the sneak-peak of the video on our [YouTube page](https://www.youtube.com/@PeterAttiaMD/podcasts)

## How Peter keeps track of his takeaways from each podcast episode [5:15]

- Peter appreciates that our podcasts are long and quite deep (that’s by design), and he personally doesn’t have time to go back and listened to most of them
- He’s not capable of assimilating everything that comes out of a podcast
- Over the past year, he has gotten into a habit of feverishly taking notes when the guest is speaking
  - That seems to be the best time for him to get insights out of the episode
- Then immediately following the podcast, almost always on that day, he resynthesizes these notes on 5×8” index cards
  - The goal here is to minimize the cards because he wants the cards to be the highest yield thing that 6 months or 6 years from now he would go back to, and that captures the salient essence of what he learned
  - It’s always an eye towards something he didn’t know before or something he didn’t realize how important it was
- Peter is always looking for something that’s going to change his mind or change his practice
- We will look at some recent episodes from 2 realms
  - 1 – Peter’s most important takeaways, insights, and biggest learnings
  - 2 – If Peter has changed his mind, changed his behavior, how he works with himself, how he works with patients

## Luc van Loon episode: fat utilization, muscle protein synthesis, dietary protein, aging and inactivity, and more [8:45]

[#299 ‒ Protein: optimizing muscle protein synthesis, quality sources, quantity needs, and the importance of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) (April 22, 2024)

\*\*\*

- Luc’s episode wasn’t the only episode focused very heavily on protein
- Despite that, the richness of this episode surprised Peter

**We talked a lot about something called the Fat/Athlete’s Paradox**

- There’s this idea that when you look at the muscle of an athlete and you look at the muscle of someone with [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes), you are going to see large stores of intramyocellular lipids ([lipid](https://en.wikipedia.org/wiki/Lipid) within the muscle)
  - You’re looking at 2 opposite ends of the metabolic spectrum
- Peter remembers hearing this before, but he thinks what came into focus was the idea that this is one of the limitations of static information

***Because in the case of the person with type 2 diabetes, that intramyocellular lipid store is indeed just that, it is a depot***

- It is a place where excess energy is seeping out of adipose tissue and remaining stored in the muscle
- As we saw in our podcast a couple of years ago with Gerald Schuman, that’s one of the hallmarks of the cascade of events that leads to [insulin resistance](https://en.wikipedia.org/wiki/Insulin_resistance)

*The question is why aren’t athletes not insulin resistant? They’re the exact opposite of that*

- It comes down to the fact that for athletes that is less a storage depot and more a state of flux

***For the athlete, the intramyocellular lipid is indeed a fuel source, and it’s being turned over rapidly ‒ that’s the key takeaway there, and that’s really big***

- Just because you have triglyceride in the muscle on a biopsy, if you biopsied the muscle of an athlete and of the diabetic, you’re going to see high amounts, much higher amounts of fat than you would see in a non-elite athlete or non-diabetic
- But it’s important to understand, one is a constant flux that’s being used to “prime the pump” [of [fatty acid oxidation](https://en.wikipedia.org/wiki/Beta_oxidation)], and the other is obviously a pathologic finding

***The reason the athlete has that storage of fat so readily available: it’s an immediate access at that low end aerobic fuel point***

- If you think about [Zone 2](https://peterattiamd.com/exercising-for-longevity/), the idea is the minute you jump into that energy system, you want to make sure that you’re burning lipid and not burning glucose

**Amino acids are signaling molecules in and of themselves**

- It speaks to the fact that the ingestion of protein by itself stimulates muscle protein synthesis even in the absence of activity
- The amino acid signals [mTOR](https://en.wikipedia.org/wiki/MTOR)
  - We understand that mTOR is the master nutrient sensing molecule
  - And the [activation of mTOR](https://en.wikipedia.org/wiki/MTORC1) signals muscle protein synthesis even in the absence of activity

***Now, when you combine protein intake with exercise, you’re going to get more muscle protein synthesis***

- Luc made the analogy of bricks calling the bricklayers
  - [The amino acids stimulating protein synthesis]

**Recycled endogenous amino acids**

- Another point, brought up by Layne in one of our [first podcasts](https://peterattiamd.com/laynenorton/) was about the isotope labeling of amino acids to understand the flux of amino acids: there are about 300 grams of amino acids being utilized per day, and most of this is actually recycled endogenous amino acids
- If 300 grams of amino acids each day are being utilized, you’re not eating 300 grams per day
- The muscle itself is turning over and part of what’s being turned over is being reincorporated

***What is really wild is that it takes somewhere between 50-100 days for the complete turnover of a muscle***

- In other words, if  you look at a muscle in your bicep today, 100 days ago it wa made up of completely different amino acids
- In 2-3 months, you are completely turning over every muscle in your body
- Luc mentioned later in the podcast that that turnover is even more rapid in the **brain** to the tune of about 30 days
  - A month ago, the actual structure, the proteins that make up your brain were a totally different set of amino acids

**We talked a little bit about the difference between bodybuilders and endurance athletes**

- Bodybuilders, when they are undergoing muscle protein synthesis, you’re seeing more myofibrillar protein synthesis in the [type II fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types)
  - Based on the nature of the training stimulus
- Whereas endurance athletes, you’re seeing an increase in 2 things: mitochondrial protein synthesis and capillary density
  - This is occurring in the [type I fiber](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types)
  - Again this is based on the nature of the training stimulus

> “*Bodybuilders are getting bigger muscles, more contractile force, myofibrillar protein synthesis occurring in the type II fiber, while the [endurance] athlete is increasing mitochondrial protein synthesis and capillary density in the type I fibers ‒ an editorial comment on top of that, we want both of those things to occur.”*‒ Peter Attia

***That’s why we want both types of training***

**What drives muscle protein synthesis**

- Luc lists 4 things, which is a very helpful guide as you start to think about protein choices
- 1 – What is the digestibility of the protein
  - This is where **animal protein** has an enormous advantage over **plant protein** and that it is far more digestible
    - If you want to eat or get the majority of your protein from plants, that’s fine, but you will need to accommodate that by, for example, cooking it and/ or eating sources that have higher amounts of certain amino acids
- 2 – The rate of digestion
  - The most potent type of protein, which would be say beef protein or something like that
  - There’s a significant difference between ground beef and steak
    - The rate of digestibility is obviously greater for ground beef than steak
  - Similarly, [whey](https://en.wikipedia.org/wiki/Whey_protein) versus [casein](https://en.wikipedia.org/wiki/Casein), they’re both milk proteins, but whey has a much higher rate of digestibility than casein
  - Here’s where you’d see cooked versus raw
- 3 – Amino acid composition
  - An example would be collagen versus whey
    - Whey has a much higher quality amino acid composition that collagen
    - [Collagen](https://en.wikipedia.org/wiki/Collagen#Biology) tends to be rich in a handful of amino acids (glycine and proline) while [whey](https://en.wikipedia.org/wiki/Whey_protein#) has a more distributed wealth of amino acids
- 4 – The total amount of protein being consumed
  - The more protein that’s being consumed, the more muscle protein synthesis

**Quick primer on milk proteins**

- Milk protein is about 80% [casein](https://en.wikipedia.org/wiki/Casein) and 20% [whey](https://en.wikipedia.org/wiki/Whey_protein)

***The digestion profile of whey is much more rapid; casein is much slower; both are valuable***

- There was a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10772463/) that Luc was a part of, and we’ve written a [newsletter](https://peterattiamd.com/protein-anabolic-responses/) on it

***Talking about how much, much larger doses of protein could contribute to muscle protein synthesis in a study that was using casein because of this long lag in which it was dragged out***

- Luc mentioned that **plant protein** is specifically low in [lysine](https://en.wikipedia.org/wiki/Lysine) and [methionine](https://en.wikipedia.org/wiki/Methionine)

***If you’re going to eat plant protein, you’re going to have to probably look for ways to supplement those if you want to maximize muscle protein synthesis***

- Peter’s notes from this podcast is a bit longer than normal (there was so much there)

**Loss of muscle in the elderly**

- A very powerful image in Peter’s mind from this podcast is the idea that when you look at the graphs that describe loss of muscle in the elderly
  - They start out here and they drop down here
  - It’s kind of like a smooth curve that drops like a stone usually once people are in their mid-70s
- Luc made such a fantastic point, which is if you look at this at the **population level** (which is always how the data are presented), it appears to be a physiologic phenomenon
  - A physiologic phenomenon is an inevitability; it’s physiologic
- But if you actually look at it at the **individual level**, that’s not at all what it looks like: it’s actually a graded step function
  - If you’re watching, this is easier to see
    - Here’s your muscle mass and then boom, a big drop, and then you stay there for a little while and then boom, a big drop and away you go and away you go

***What it really comes down to on the individual level is a series of discrete periods of inactivity that result in sudden big drops in muscle mass that are never recovered***

- Sudden is relatively speaking, meaning over a period of months or weeks

> “*It’s been a while since that episode. I think about that every minute of every day, and I’m only in my 50s, and I keep thinking, ‘What do I need to do to make sure I don’t experience one of these 2-week or 2-month episodes that’s going to result in an irreversible loss of muscle mass?’*”‒ Peter Attia

***It really comes down to: how do you not get injured***

- Even if you don’t have an injury, how do you make sure you’re staying active?

**This gets to another important things discussed: the idea of anabolic resistance**

- This has come up over and over on various podcasts
- We talked about the 2 drivers of this, which are aging and inactivity

***It’s crystal clear that inactivity and age drive this***

- The question is is it one or the other?
- Is one simply a proxy for the other, et cetera?
- Luc offered great ideas for why maybe both of these things play a role

*Inactivity*

- This is the easier one to test because you can actually do an experiment
- You could take young people who ordinarily would not experience anabolic resistance and you can render them inactive
- There are very elegant [experiments](https://pubmed.ncbi.nlm.nih.gov/37994085/) done where you take young people and you put one leg in a cast for a period of time (1 week)
  - This is beautiful because each person is their own control: a young person, one leg in a cast, one leg not
- In 1 week there was a 35% difference between the active and inactive leg in a young person with respect to muscle protein synthesis and therefore anabolic resistance

***That very compellingly says inactivity plays a huge role, but that doesn’t mean that aging inherently doesn’t also account for some of this***

*There are lots of hypotheses that he put forward*

- Is there a decrease in amino acid uptake, a decrease in gut absorption, a decrease in the circulation of amino acids
- Is something called splenic sequestration going up?
  - Basically losing amino acids to the splenic system in the GI tract
- Is there a reduction of perfusion?
  - Of course that’s true elsewhere in the body, so maybe it’s true here and lower muscle uptake
- Finally, is there lower mTOR signaling?
  - It certainly is listed as one of the hallmarks of aging that nutrient sensing goes down

**The difference between myofibrillar muscle protein synthesis and muscle contractile tissue protein synthesis in response to different stimuli**

- While talking to Luc, Peter made a table about the difference between myofibrillar muscle protein synthesis and muscle contractile tissue protein synthesis in response to the following stimuli: exercise, dairy protein (whey and casein), and collagen protein
  - Collagen protein is not a complete protein; it’s mostly just got a couple of amino acids in it
- When you look at **exercise**, you see that it gives a huge increase in both myofibrillar muscle protein synthesis and muscle contractile tissue
- When you look at **dairy protein**, you get a big increase in myofibrillar, but not in contractile
  - Peter doesn’t find that surprising
- When you look at **collagen protein**, it’s relatively small on both

***What was highlighted for Peter was that total protein quality plays a big role in myofibrillar protein synthesis, and exercise plays the biggest role in generating contractile tissue protein synthesis***

## Behavioral changes that have come about from the conversation with Luc van Loon [23:45]

- 1 – Consistency of training and not taking time off
  - Not taking time off from training for a trip, life, or injury
- 2 – For really long endurance activity, maintaining dietary fat matters
  - In the outset of the Luc van Loon episode, we talked about how you want to maintain intramyocellular lipids
  - This has never been an issue for Peter because he’s never been a low-fat diet guy
  - It’s worth keeping in mind for athletes out there who tend to be lower on their fat consumption
    - Peter adds, “*You are depriving yourself of a pump prime*.”
    - [intramyocellular lipids are used for [beta oxidation](https://en.wikipedia.org/wiki/Beta_oxidation) before adipose tissue is mobilized]
- 3 – Peter has been using time-restricted feeding more, but he always makes sure to get protein while he’s in the non-feeding window
  - He doesn’t believe there’s any particular magic to not eating for 18 hours a day
  - It’s just a tool to restrict calories
  - He doesn’t care if he get another couple hundred of calories of protein during that window
- 4 – Peter feels a little more comfortable telling his wife to supplement her collagen protein drink with something else, because collagen protein is not a superior protein
  - There’s nothing wrong with drinking it; it’s just not a very complete protein
  - She is adamant about her collagen protein in the drink in the morning

**Consistency of training**

- A good quote from Luc, “*I’ve had a lot of people in my life asking me how important is it whether I take my protein shake before or after the training session, but I never had someone come up to me and say, look, how important is it if I skip 1 training session or miss 1 training session. Consistent training is the benefit. Consistent training so that every meal is a greater impact on your muscle protein synthesis.*”
- We see a lot of questions come through and sometimes people may overthink protein and when to take it and when not to

***For him to say whether you consume before or after, the biggest thing is just always be training, always be consistent and never take time off, was a really good point for people to remember***

## Courtney Conley episode: importance of toe strength and the impact of dedicated foot training [26:45]

 [#296 ‒ Foot health: preventing and treating common injuries, enhancing strength and mobility, picking footwear, and more | Courtney Conley, D.C.](https://peterattiamd.com/courtneyconley/) (April 1, 2024)

\*\*\*

- Peters obsession with his toes was probably a 7 out of 10 before this podcast, and since then it’s gone to a 9 out of 10
  - He’s wearing his [toe spacers](https://www.naboso.com/collections/accessories/products/naboso-splay?utm_source=google&utm_medium=cpc&utm_campaign=brand&gad_source=1) now
- Out of the gate in this episode, a “hit you in the face” statistic is, “*Declining toe strength is the single biggest predictor of falls in an aging population. So toe strength decreases 35% from young to old age.*”
- This is kind of remarkable, and by the time you’re 85 years old, you will have lost 75% of your toe strength from where you peaked

**Let’s talk about the metrics**

- Peter loves that you can metric this stuff

***You should be able to press 10% of your body weight through your*** [***flexor hallucis longus***](https://en.wikipedia.org/wiki/Flexor_hallucis_longus_muscle) ***(that’s the big toe), and 7% of your body weight through toes 2-5 while seated and leaning back***

- In the show notes of the podcast with Courtney, we linked to a whole series of videos that Courtney and Peter made in the gym where we went through those exercises
  - Go through and see those things
- Peter thinks he was able to do both of these: press 20 lbs through the great toe (a little over 10% of his body weight), he doesn’t remember about toes 2-5
- He was not able to pass all of the tests they went through on that video

*How hard is 10% and 7%? Is that something the vast majority of the public could pass right now?*

- Peter doesn’t think so
- He’s worked on this stuff a lot, certainly long before the video with Courtney was made
- He’s not sure he would’ve passed that test 5 years ago

> “*The good news is this is not a one-way street down, you can absolutely improve these things.*”‒ Peter Attia

***The other test that is great is the anterior fall envelope, which should be at least 4.5 inches***

- Peter had not does this test before and he passed it (but not by flying colors)
- We demonstrate that
- Peter puts that up there as something everybody should consider

*How to do it*

- You’re standing at a distance from a wall, you take a measurement using a laser device from your belly button to the wall, and you lean forward until you can’t support yourself with your toes anymore and you’re going to fall
- Then you redo the measurement and that needs to be 4.5 inches or greater

*Flexibility*

***You want to have dorsiflexion of at least 35 degrees***

- Dorsiflexion is toe up, and 35 degrees was a huge bar
- Peter doesn’t believe he passed that test
  - Maybe with one leg and not the other

> “*There are some very difficult metrics, and the ones that blew my mind the most were around calf strength.*”‒ Peter Attia

- Virtually nobody [has excellent calf strength], because Peter has now tried to have a lot of people do these tests
  - He has yet to meet somebody who is basically top, top, “top drawer” in calf strength
  - That includes really amazing athletes who are very strong
- One of the other things Peter learned is sometimes the best athletes are the best cheaters, so they’re able to get around weaknesses and still do remarkable things

***As Peter thinks about aging, especially aging as an active person, the calf is such an important muscle for strength because it stabilizes so much of the lower leg, and it also factors into a very strong*** [***Achilles tendon***](https://en.wikipedia.org/wiki/Achilles_tendon)

- Anybody who’s had an injury, even just a tendinopathy of that tendon realizes how stubborn that is, and nevermind if something is catastrophic

**We went into great detail of both the intrinsic and extrinsic musculature of the foot**

- When you combine intrinsic (meaning muscles within the foot that stabilize it) and extrinsic (the muscles on the front of the leg, on the front of the shin that stabilize it and the calf on the back) ‒ none of those 3 sets of muscles are very interesting to people
  - They’re not the type of muscles people really want to work out in the gym
- But the good news is, in this podcast we talked about a lot of ways to do that and if anyone’s rusty on that, just say get back to those videos and check them out

**Courtney talked about how many foot injuries and pains have a somewhat counterintuitive treatment plan**

- For example, an [ACL injury](https://en.wikipedia.org/wiki/Anterior_cruciate_ligament_injury) could be prevented by strengthening the [soleus](https://en.wikipedia.org/wiki/Soleus_muscle)
  - Whereas, most training protocols only focus on the hamstring
- As Peter is training for a very long ruck, his soleus training is through the roof
  - He’s experiencing fewer aches and pains now despite the fact that he’s rucking 5X more than he was a year ago, and he attributes it to a lot of that
- [Plantar fasciitis](https://en.wikipedia.org/wiki/Plantar_fasciitis) can be treated by strengthening and stabilizing the [flexor digitorum brevis](https://en.wikipedia.org/wiki/Flexor_digitorum_brevis_muscle) (on top of the foot), and again, we show exercises for that

*Another big takeaway was about* [*bunions*](https://en.wikipedia.org/wiki/Bunion)

- Bunion surgery doesn’t work very often because it’s not treating the root issue
- Again, you have to strengthen the muscles of the great toe so that you don’t get that inward bend of the toe
  - Which is what’s leading to the bunion poking out

**We talked about shoes**

- The majority of shoes are probably too narrow for most people in the toe box
- Peter’s takeaway: anytime we want to wear shoes that are not ideally suited to our feet, we want to think of that as a vacation
  - A vacation maybe is the wrong word, but a time off of doing what’s healthy
  - This doesn’t mean you should always have to wear these hideous, unattractive, minimalist shoes that have good toe play and relatively low drop
  - It just means you want to be able to balance those things out

**Peter’s behavior changes that came out of that**

- He’s always liked **toe spacers**, but he’s been wearing them a lot more since that discussion with Courtney
- He’s found a [brand](https://www.naboso.com/collections/accessories/products/naboso-splay?utm_source=google&utm_medium=cpc&utm_campaign=brand&gad_source=1) that he likes so much more than the ones he was using before the podcast
  - He attributes this to his wife who got them for him for his birthday
  - They’re light blue, rubbery, and not only do you have 4 of them that fit in between the toes, but they have little cuffs that wrap around all 5 of the toes
  - Not only are they incredibly comfortable, they just completely stay put all the time, which is again why he’s constantly in them
- He’s in them nonstop
  - He’ll shower with them
  - He’ll wear them the entire day ’cause he’s barefoot the entire day
  - He’s in the gym with them
  - He’s walking everywhere with them
  - Basically the only time he’s taking them off is if he’s putting a shoe on

*What changes have you noticed now that you are wearing toe spacers more than before?*

- Better foot proprioception
- When he’s lifting in them, he really likes what he would call an anatomic spread
  - It’s not a huge spread
  - He just feels his foot is far more planted on the ground
  - He is less likely to supinate and pronate
- It’s not that you never want to supinate and pronate
- Peter tends to over-supinate and this makes it easier for him to lean more towards pronation, which is balanced

***Peter is doing a lot more foot stuff than he’s ever done before, and he’s doing it because of the demand that he’s under, training for this long ruck***

- It’s not hard because his cardiovascular system is struggling, that’s for sure
  - It’s a rounding error on his cardiovascular system
- It’s very challenging for your feet, for your shins, and therefore, he’s doing a lot of the types of training that Courtney talked about to make that less difficult ‒ that’s probably the biggest takeaway for him

**Are you doing specific foot, lower leg training? Are you dedicating longer periods of time to it a few times a week?**

- No, Peter adds it each time he’s in the gym
- He’s in the gym doing something 6 days a week
- 4 of those are lifting, and this gets incorporated into his lift
  - For example, in between sets he’s always doing a foot-based exercise
    - It doesn’t matter if it’s leg day or upper-body day
  - These exercises could be on the mobile board, it could be a seated calf raise, it could be a relaxation exercise like the planter, the arch relaxing exercises to emphasize pronation
- There are 2 days a week where he is doing a dedicated all-in rehab day, and there he will probably have a little more focus on this

**Have you done some of the tests you originally did with her again to see if your metrics have increased?**

- No, Peter hasn’t checked and should check again soon

## Olav Aleksander Bu episode: the importance of VO2 max for lifespan, and the practicalities of measuring and improving VO2 max [36:45]

[#294 ‒ Peak athletic performance: How to measure it and how to train for it from the coach of the most elite athletes on earth | Olav Aleksander Bu](https://peterattiamd.com/olavaleksanderbu/) (March 18, 2024)

\*\*\*

- This was a podcast that Peter was very, very excited for
- Peter wonders what the feedback was on this podcast
  - His concern is that generally there is an inverse relationship between how much he enjoys a discussion and his feeling of how much the audience will
- Peter explains, “*This one was so over the top in terms of my enjoyment, I actually felt quite selfish ’cause I was… literally at this point only asking questions for my own benefit at this point, even if the detail is so great that nobody benefits, and I feel a little embarrassed saying that.*”
- It was definitely a technical episode, and it’s a topic that people are really interested in
  - For the people who really enjoy the details, they absolutely love this conversation
- We’ve covered [VO2 max](https://peterattiamd.com/breaking-down-vo2-max/) at so many [levels](https://peterattiamd.com/category/exercise/vo2-max/page/2/), so our audience has a pretty good foundational understanding of this

**The relationship between oxygen consumption and energy expenditure**

- Measuring oxygen consumption is the most practical way to measure energy expenditure
- Peter now uses one of the tools we discussed in that episode: the [VO2 Master](https://vo2master.com/)
  - It very accurately measures energy expenditure while rucking
- This helps Peter to really think about the nutritional demands for this very long 20-hour ruck
  - Because remember, when you’re using something like your Garmin watch (or whatever other smart device you’re using) to try to tell you **how many calories you’ve burned**, they’re trying to estimate it based on a various number of factors including heart rate and things of that nature, but truthfully, they’re not doing it very well
  - The gold standard is [indirect calorimetry](https://en.wikipedia.org/wiki/Indirect_calorimetry), which is something you can do with this VO2 Master (he’ll come back to this)

**Maximal oxygen consumption, which is the definition of VO****2** **max, is the greatest predictor of lifespan**

- You’ve heard Peter say this before, “*[VO**2* *max] It’s the integration of the exercise work that you’ve done over a long period of time.*”
- It’s a proxy for health because you simply can’t have a high VO2 max with anything not working
- By definition, if your VO2 max is very high, you have an exceptional cardiovascular system which enabled you to do it
  - An exceptional pulmonary system
  - You don’t have any neurologic issues
  - You don’t have metabolic dysfunction
- Again, that’s why it’s not surprising that we have this very strong association [between VO2 max and lifespan]

- Conceptually, people understand that VO2 max is not something you can cram for (do a year’s worth of training in 2 weeks)
- If you have other issues that are going to hamper your ability to get a good VO2 max, it can probably get in the way of your lifespan as well

*The question is: Because of that, do you think it dilutes the VO**2* *max data as it relates to being such a good predictor of mortality?*

- Maybe another way to say it is it’s like a healthy user bias
- One example of a **healthy user bias**: predicting a better lifespan for vegetarians
  - It’s not that you don’t eat meat that you have \_\_\_\_ (pick your favorite benefit)
  - Being a vegetarian is selecting for a lot of healthy behaviors that are indeed driving your health
    - It is not the absence of meat
    - Do you eat more vegetables? Yeah, and we know that vegetable consumption is beneficial
    - But again, that so often gets mistaken for clearly not eating meat is good for you and therefore, eating meat is bad for you
  - When you make the very difficult and conscious decision to not eat meat, you undoubtedly are making so many other healthy decisions, and that’s what’s giving you the benefit
- Conversely, when you look at the VO2 max data, yes, you’re looking at a healthy user bias because somebody who has a high VO2 max is very healthy by definition
- But the point is the way they got that health was by singularly focusing on the thing that gave them the high VO2 max
- It is a subtle distinction, but a very important distinction

***The thing that you have to do to get a high VO******2*** ***max is in and of itself the thing that is elongating your life, and that’s completely different from the nutritional case***

**If there was a “Peter Attia biological clock” to figure out how someone is aging, is VO****2** **max at the top of that list of metrics you would look at?**

- Peter has [written](https://peterattiamd.com/how-accurate-are-biological-age-clocks/) about biological clocks and what they’re good at and what they’re not

***If Peter had a health dashboard, VO******2*** ***max and strength would be at the top***

- Then you could argue so many of the things that are also important are largely going to be captured by that
- In other words, it’s very hard to be in the top 5% of VO2 max and the top 5% in strength and not also be metabolically healthy
- It would almost become irrelevant to say, “*Oh, and another thing I would put on that list at the top is highly insulin sensitive.*”
  - You don’t need that because you’ve already captured that in the first 2
- Peter wants to pick the highest order things and put them at the top
- From a purely physical standpoint, it would be really tough to say if you’re in the top couple of percent per VO2 max in the top couple of percent for strength
  - Then we could come up with different metrics of measuring strength
- By definition, you’ve captured items 3-20 on the other list of things that we know are valuable for your health
- Could you be in that situation and also have high blood pressure? Yes, you could
  - So somewhere on that list, you want to be able to know that someone’s got good blood pressure
- Could you have those 2 things going for you and still have elevated Lp(a) and Apo B? Absolutely
  - So we do need to include those other things on the dashboard, but those things are much easier to fix

> “*Getting a high VO**2* *max and being very strong are very hard to do. They take a long time. Everybody can do them, but as you said, they can’t be done quickly and easily, so therefore, they are the tip of the spear*.”‒ Peter Attia

**Olav talked why VO****2** **max plays such an important role in lifespan**

- When you consider people who get older, what would an elite VO2 max look like for someone who’s 80?
- This is going to be a person whose VO2 max is in the mid to high 30s
  - That’s top 1 to 2% of people in that age group
  - That’s achievable
  - BTW, Peter knows people in their 30s and 40s who don’t have that

***If you have high VO******2*** ***max, anytime you get really sick, you are using a far lower fraction of your total available oxygen consumption to fight off an infection***

- That explains how you might have 2 people in their 80s that get COVID, and 1 of them is really healthy and 1 of them is not
  - The person who has a VO2 max of 14 (which would put them in the bottom 25%) is going to use every bit of their oxygen consumption capacity to not die
  - Whereas, the other person, it doesn’t even require them half of their capacity to survive that

*Again, are there differences in underlying health?*

- Absolutely, but a big part of it is this ability to fight off infections (as an example)

**Another really important point here was talking about broad themes around training for VO****2** **max**

- You will incorporate VO2 max training
- You will get a VO2 max benefit with most type of cardiorespiratory training, including zone 2 (we’ve [talked](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/) about this a lot)
  - If the only thing you ever did was zone 2, your VO2 max would improve
  - Would you reach your potential doing it that way? Not a chance
- Peter has talked about the triangle [see the figure below] ‒ consider 2 scenarios
  - 1 – If a person only did zone 2 training, they’d have a big wide base and a modest peak [Peter misspoke here when he said, “*if you’re only doing VO**2* *max,*” and meant if you’re only doing zone 2]
  - 2 – If another person said, “*I’m going to be the king of* [*Tabata*](https://en.wikipedia.org/wiki/High-intensity_interval_training#Tabata_regimen)*,*” and they did these super short, high-intensity intervals 3X a week
    - Are they getting VO2 max benefit? Yes, they absolutely are
    - They may end up with a slightly higher VO2 max than the 1st person, but their base is pretty narrow
    - They may have a slightly higher peak, but they don’t have a very wide base
  - Neither of these people are achieving their potential
    - In the 1st case, they’re not doing enough intensity
    - In the 2nd case, they’re doing too much intensity, but it’s for too short a period of time; they need to be slightly less intense for a longer period of time (greater total volume)

![](https://peterattiamd.com/wp-content/uploads/2024/05/f1-qps1.png)

**Figure 1. The size of the fitness triangle relates zone 2 to zone 5 training**.

**Olav talked about what  you ultimately want to think about is the total amount of kilojoules expended during the high-intensity intervals**

- Peter explains, “*The literature makes this pretty clear: 3-8 minutes is the sweet spot*.”
- Which is much longer than what people typically think of when they think about high-intensity interval training where they’re doing 10 seconds, 20 seconds, or even 1 minute
  - There is value in doing those things
  - But if time is limited and you’re asking yourself, “*How can I increase my VO**2* *max, and I’m only going to do this once a week?*” (which is all Peter does)
    - It’s almost always 4 and 5 minute intervals, and he’s just stacking as many of those intervals as he can make time for in that workout session
- Peter typically does intervals with equal time on and off
  - He did a trainer workout where it was 3 minutes on, 3 minutes off (that’s an example at the lower end)
  - If he’s doing it outdoors, he’s going to go a little longer based on the hill he’s riding up and down

**Something that blew Peter’s mind: Olav talked about how we are not at all limited in VO****2** **max by the oxidative capacity of the mitochondria**

- He talked about in vitro experiments that demonstrate that the mitochondria are capable of more than 5X the oxygen consumption that we see in VO2 max
  - Peter was completely unaware of this
- It’s mind-boggling when you take a step back and ask the question, “*Where is the limit?*”
  - Clearly something limits oxygen consumption given that every human has a limit
  - It’s not unreasonable to guess it must be in the mitochondria of the cell
    - But that’s the one place we know it’s not
  - In fact, where we really think the limit is probably on **oxygen delivery**
    - It’s not how much oxygen you use, it’s how much can you deliver, and that’s really a **cardiac output** question
    - That’s a hemoglobin question
    - That’s a heart rate stroke volume question

***The thing that we know that decreases the most predictably with aging is indeed heart rate, and you are approaching maximum heart rate during a VO******2*** ***max interval***

- Peter thinks he is at his max heart rate at the end of each of his VO2 max intervals (he’s certainly within a couple of beats of it)
- That number has come down a lot from where he was 10 years ago
  - He’s easily 10 beats per minute lower in his maximum heart rate now than he was 10 years ago
  - By the way, his VO2 max is about 10 points lower (10 mL/ kg/ min) than it was 10 years ago

**Another very important insight that Peter took away from this podcast was that as important as VO****2** **max is from a health predictive standpoint, it’s** ***less important*** **than he might’ve appreciated with respect to peak physical performance**

- We want to not lose track of Olav’s expertise: he’s a coach to some of the best endurance athletes on the planet
  - In particular triathletes who are obviously remarkable athletes
  - And those competing at the highest level (World Ironman Championship, Olympics, etc.)
- Peter remembers hearing a statistic, probably 10 years ago, which said that if you took a bunch of runners at the beginning of a marathon and you knew the VO2 max of all of them, it wouldn’t help you very much at predicting the winner

***But if you knew their vVO******2*** ***max (so the velocity they were running at VO******2*** ***max), that is a better predictor of the order***

- Peter assumed from that, that if you knew the PVO2 max (the power at VO2 max), you would have a similar ability to predict success on a bike
  - Olav made the point that that’s not necessarily true
  - It’s only true if you know what event you’re looking at
- So if you’re looking at the Tour de France, that absolutely would *not* be true
  - Why? Because the Tour de France is not won at a VO2 max interval
  - If you look at something like the Tour de France and, by extension, if you look at something like an Ironman, the athlete is well **below VO****2** **max** for most of the time

*What really matters more, is*:

- How high is their zone 2?
- Where is lactate threshold 1?
- Where is lactate threshold 2?
- VO2 max is just an important point as you think about this through the lens of performance

***Understand, if you’re talking about a 4-minute race, yeah, VO******2*** ***max is very important because that entire race is taking place at your max VO******2******. But if you’re talking about a 1-hour time trial, you’re at, by definition, a functional threshold power well below VO******2*** ***max***

**Limit on energy consumption**

- The other thing Olav talked about that has really stuck with Peter is another huge limit here: energy consumption
- At these very, very high level of elite athletes, their energy consumption is through the roof

***A very quick way to estimate total energy expenditure: it’s 5X ventilation rate of oxygen (that’s not the exact formula)***

- So if a person is consuming 4 Liters per minute of oxygen, they’re consuming 20 calories per minute
  - That means they are at 1,200 calories per hour, at 4 liters per minute
  - Now, 4 L/min for an unfit person is brutal, and they can probably only hold that for a few minutes (this is not an issue)
  - But when you talk about the athletes that Olav is coaching who have a VO2 max of 7 L/min (or maybe high 6 L/min), they’re easily going to run the whole race above 4 L/min
- The question is, “*How do you get enough nutrition into these people? How do you get 1,200 calories per hour into somebody?*”
- Well, the answer is you don’t; you can’t come close to that
- But what if you have to get 600 calories per hour into them?
  - Obviously they’re going to use 600 calories of endogenous calories between glycogen and fat

***So in some ways the GI system might in fact be the bottleneck of ultimate human endurance (a very interesting idea for Peter)***

## Behavioral changes that have come about from the conversation with Olav [56:00]

**The most obvious behavior change Peter has made was he got a** [**VO2 Master**](https://vo2master.com/)

- Peter had heard a lot about portable VO2 devices, but every one of them he had seen was simply not either practical enough (it was too big and almost not portable) or not accurate enough
- When Peter asked Olav during the episode, “*What are you plus or minus 10% on that?*”
  - He made a comment that was funny
  - He’s like, “*If it was plus or minus 10%, I would’ve thrown it in the garbage*.”
  - It’s plus or minus a hundred milliliters
    - Peter thought that’s just too good to be true
- Peter got one and started testing it like a banshee
  - He’s wearing it everywhere and sending the data back to him to review
    - Walking around with this thing
    - Playing with the kids on the sports court
    - Doing workouts, doing all this stuff
- The thing is probably 50-100 ml of laboratory testing, but for Peter, far more enjoyable
  - Because now he can do his VO2 max testing outdoors, which just feels better
    - He hates being on a stationary bike doing a maximum exertion activity
- Also, you could do your VO2 max testing on a rowing machine
  - You can do it in other situations beyond the bike and treadmill
  - Peter has done it on a stairmaster, where he’s just sprinting upstairs
- It’s super cool
- Yeah, it’s an investment (it’s a $6,300 device), so this is not for the faint of heart
- Peter is not not for a second suggesting that you’ve got to have one of these.
- He’s just saying, if you’re a physiology idiot like him, he’d rather spend money on this than on a fancy vacation or something

**You mentioned you’ve tested your VO****2** **max in different settings. Have you seen a difference in that?**

- Peter has also worn it for zone 2 training
  - His VO2 was well below VO2 max when doing zone 2
  - On his bike, his VO2 is about 60-65% of his VO2 max
    - This tells him that he can hold 65% of his VO2 max almost indefinitely
    - Exclusively metabolizing fat and keeping lactate below 2 mmol

**One of the things Peter wants to talk to Olav about is when you look at his athletes, are they able to keep lactate below 2 mmol at 70% or 75% of VO****2** **max?**

- Peter would bet that they are
- As high as their VO2 max is, he would bet that their aerobic capacity is even greater
- That’s a cool metric to now track

**What’s the ideal triangle if you look at VO****2** **max at the top, and % of VO****2** **max on a VO****2** **for a Zone 2?**

*Is it ideal to be 65%? Is it ideal to be 70%? Do you think anyone’s found that answer out yet?*

- Peter doesn’t know
- He needs to talk to [Iñigo](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) because he might have a sense of this
- Between Iñigo and Olav, if those two guys don’t have a clear sense of that (which Peter is sure they do), then maybe people haven’t asked that question that way

**Peter wonders if he will have a higher VO****2** **max on a rowing machine**

- He hasn’t done it get on an Erg (rowing machine)
- He’s curious about it because it uses more muscles than anything else
- Everything he’s done so far has been lower body
  - Which is normally the way a VO2 max test is done
  - He has a higher VO2 max on the bike than on the StairMaster
    - Peter thinks that we probably acclimate to what we’re most efficient at

**What did you learn on the ruck with the VO2 Master?**

- Peter’s VO2 is very low while rucking
- Energy consumption is not going to be a challenge
- This is nowhere near as demanding as when he was doing marathon swims where you’ve got to be replacing a lot of calories an hour
- Experientially, Peter has found that he can do a 5-hour ruck and doesn’t need to eat a thing
  - He’s just drinking water
  - You’re just not burning that many calories
- The training for this is mostly rucking on the flats

## Alex Aravanis episode: liquid biopsies for cancer detection [1:01:30]

 [#290 ‒ Liquid biopsies for early cancer detection, the role of epigenetics in aging, and the future of aging research | Alex Aravanis, M.D., Ph.D.](https://peterattiamd.com/alexaravanis/) (February 18, 2024)

\*\*\*

- This is a technical episode on a subject that’s very interesting for a lot of people

**To understand liquid biopsies, you do have to understand a little bit about DNA and cell-free DNA**

- Out of the gate, Alex put some really good things into context
- You have 3 billion base pairs of DNA and when a cell dies, it releases some of this DNA ‒ that’s called **cell-free DNA**
  - Very important concept, to understand cell-free DNA, because you can’t understand liquid biopsies without this
  - These have a very specific length, which is about 160 base pairs
    - On a relative basis, very small
    - You have 3 billion base pairs, and we’re talking about 160 base pair fragments
    - Because of the very specific geometry of how DNA wraps around a nucleosome, the 160 base pairs gives you two wraps around a [nucleosome](https://en.wikipedia.org/wiki/Nucleosome)
    - To say that you’re looking for a needle in a haystack is an understatement
    - This is tiny, tiny, tiny amounts of DNA

*There are 3 reasons to care about cell-free DNA*

- 1 – It could be a way to look for therapy selection for a cancer
  - If a person has a known cancer, it’s easier to find cell-free DNA
  - You might use that cell-free DNA to say, “*I’m going to select therapy X over therapy Y.*”
- 2 – To monitor the recurrence rate of a cancer
  - Ideally, you give the person a therapy and all that cell-free DNA goes away (you’ve eradicated the tumor, and it’s no longer shedding)
  - That becomes a way to screen
  - We talked about this in the [podcast with Max Diehn](https://peterattiamd.com/maxdiehn/) a while back; that was the early use-case for liquid biopsies
- 3 – How could you use this to actually screen for cancer in a person who you believe does not have cancer?
  - This is what we mostly talked about in this episode
  - This is by far the most challenging
  - Could this be the early “canary in the coal mine” that shows up long before you have a symptom or a radiographic finding?
  - Alex pointed out, 70% of cancer deaths are from cancers without an approved screening recommendation
    - In other words, there’s a high value and need for doing this

**Different ways we can screen for cancer**

- 1 – Sometimes you can look directly at a cancer
  - An example of that would be a skin exam, a colonoscopy, a pap smear
  - You’re directly accessing where the tumor will be
- 2 – The majority of screening is indirectly looking at it
  - We use radiographic studies where we can’t directly, with our eye, look at the cancer
    - For example, we can look at a radiograph of a mammogram
  - We can impute through an indirect look where there may or may not be a cancer
- 3 – We can look at chemical signs of a cancer
  - The most notable example of this is a [PSA test](https://en.wikipedia.org/wiki/Prostate-specific_antigen#Serum_levels) for prostate cancer
    - A PSA test is a protein test that looks for evidence of prostate cancer
    - PSA is a far from perfect assay, but it’s a decent one if you know how to use it

***The argument put forth here by Alex is that cell-free DNA is a far better tool to look for in category #3***

- But he argues that more than anything else, it’s almost a new category of insight and it’s more functional because

**Cell-free DNA tells you 3 things**

- 1 – It tells you that something is growing fast
- 2 – Something is dying fast
- 3 – Something has access to circulation
- Something that’s growing fast, dying fast (i.e., turning over), and has access to circulation is very worrisome because those are the hallmarks, not just of cancer, but of **metastatic cancer**

***With very few exceptions, cancer isn’t what kills, metastatic cancer is what kills***

- Yes, there’s an exception, brain cancers will kill you without spreading
- But most cancers, when you’re talking about colon cancer, when you’re talking about breast cancer, when you’re talking about prostate cancer, pancreatic cancer, melanoma, they don’t kill you because of the organ they show up in, they only kill you when they leave that organ and they go to the lungs, to the liver, to the brain

***So cell-free DNA becomes a very important way to assess what a bad actor might look like***

**Analysis of methylation patterns**

- Of the 3 billion base pairs [in the human genome], roughly 28 million of them (less than 1%) are [methylated](https://en.wikipedia.org/wiki/DNA_methylation)
- A methyl group is a single carbon atom with three hydrogen atoms attached to it
  - It is typically attached to the C
    - Remember, you have these [base pairs](https://en.wikipedia.org/wiki/Nucleobase): A, C, T, and A
  - A methyl group is typically attached to the C when it’s followed by a G
    - You hear us talk about this in the podcast [CpG](https://en.wikipedia.org/wiki/CpG_site), where the P is a phosphate, and those are the most common places you see methylations

*When* [*GRAIL*](https://grail.com/)*, the company that Alex helped start, began looking for this idea of, “Could we find something in the cell-free DNA that would tip us off?” They basically considered 5 things*

- 1 – A DNA sequence
  - Will the sequence of DNA [mutations] tell us about the risk of cancer
- 2 – The length [of cell-free DNA or changes in fragment size]
  - On average they are 160 bp, but some are 150, some are 170
- 3 – Patterns of methylation
  - Where the methyl groups occur on cell-free DNA
- 4 – Chromosomal analysis
  - The number of chromosomes that are being split off [[chromosomal abnormalities](https://en.wikipedia.org/wiki/Chromosome_abnormality)]
- 5 – Something adjacent to it like cell-free RNA
- They took a very lengthy analysis to look at each of these individually and in every possible combination

***Interestingly, they found that methylation was the only one that mattered, and it mattered by itself. The others didn’t matter, and they added no benefit when they were added to the analysis.***

**Alex had a great analogy: you’re standing on a freeway overpass and you’re developing an image recognition for Fords**

- Your goal is to identify every Ford that comes through
- You develop an algorithm that identifies blue ovals with the word Ford on it
- Now, you also develop an algorithm for picking up pickup trucks, and you develop an algorithm that identifies the word F-150, and you identify an algorithm that identifies the word Raptor
- You ask, “*Do Fords have all of those other things? Are there Ford pickup trucks?*” Of course
  - “*Are there Raptors in F-150s?*” Yep

***None of those things are as valuable as being able to see a blue oval with Ford on it, and that’s effectively what methylation is***

- Everything else is interesting, but it’s subservient to this case

**We talked about why the** [**Galleri test**](https://grail.com/galleri-test/) **seems less likely to pick up certain types of cancers**

- One interpretation might be that the Galleri test has a blind spot to that type of cancer
- A more relevant and biologic explanation is: maybe that’s not a type of cancer that we should be aggressively treating because maybe it doesn’t have access or have the biology that grants it access to the circulation

*2 examples of cancers that have a low pick-up rate by the Galleri test*

- 1 – Hormone-positive breast cancers
- 2 – Prostate cancers

***We also know that those are 2 cancers that generally have a very favorable prognosis***

- The old adage, “*Every man dies with prostate cancer while some die from it*,” means that most prostate cancer does not spread, is not lethal
- We spent lots of time on this podcast talking about the ones you do need to worry about
- It will be interesting over time to see how accurately the GRAIL test is able to predict a subset of prostate cancers, for example, the Gleason 3+4s, or God forbid, 4+4s, but those are 2 aggressive cancers that we absolutely want to treat
  - As opposed to just picking up a bunch of Gleason 3+3s that may not require treatment and may just at most require active surveillance
  - [Gleason scoring of prostate cancer is explained in [episode #273 with Ted Schaeffer](https://peterattiamd.com/tedschaeffer2/)]
- Similarly, will there be a lot of daylight put between the hormone-positive cancers and the hormone-negative breast cancers?
  - Which, again, speaks to which ones have the most risk to metastasize and obviously are the least sensitive to conventional therapies

**There’s a lot that still remains to be seen with respect to GRAIL**

- The most important question has yet to be answered, which is, “*Will this technology, when employed prospectively in a randomized fashion, reduce cancer mortality?*”
  - That’s the only question that matters
- Let’s be clear, we don’t know the answer to that question yet because this hasn’t been done
- It is being [tested](https://pubmed.ncbi.nlm.nih.gov/36230741/) in the NHS system (in the UK), and we will know the answer to that question in a number of years
  - Peter thinks the NHS test will be the most important test of the utility of this in actually achieving the gold standard, which is going to be reducing cancer mortality
- Notice he didn’t say all-cause mortality
  - These studies are rarely powered to do that
  - So don’t get fooled by the fallacy that says, “*Oh, well, maybe it reduced cancer mortality but not all-cause mortality*.”
  - These are powered for cancer mortality

**How long until we learn more about liquid biopsies?**

*How many years until it’s potentially even looped in with the basic lipid panels?*

- When you ask that question, the implication is, “*How long until your insurance company pays for that?*”
- Today, anybody can go and do that, but it’s a very expensive test and you’re paying for it out of pocket
  - It’s $1,000 test
    - Maybe not as expensive as a VO2 master, but still an enormous chunk of change
- The jugular question is, “*When will Medicare pay for that?*”
  - When the government reimburses for that, all the private payers will follow
  - It’s not that Blue Shield is going to do it first

***Truthfully, that cannot happen until you have prospective randomized data that demonstrate the efficacy***

**A very big question**

- This is something that Peter didn’t get to talk to Alex about
  - But he’s sure Alex will be back at some point and we’ll be talking more about some of the other amazing work he’s involved in around methylation

*In the field right now, there is still some confusion about what the way of the future is*

- Is the way of the future the Grail approach where you do a pan test?
  - Meaning you do a single test that is aiming to look for all cancers
- Or is it going to be, “*No, we will have better fidelity going cancer by cancer*“?
  - You’re going to have a colon cancer version of these
  - You’re going to have a breast cancer liquid biopsy
  - You’re going to have a pancreatic cancer liquid biopsy
  - You’re going to have a sarcoma liquid biopsy
- You have to ask the question, “*What would those need to be priced at to make sense?*”
- Because if you told us today, “*Well, we have a test that’s better than Grail at the individual level and each of them is a thousand bucks*,” are you going to spend $25,000 a year getting a liquid biopsy for the 25 most common cancers?
  - That’s not going to go anywhere
- It’s just a very exciting time to be in the peanut gallery, where Peter is, watching this
- Clearly, this is not going to be the last podcast we do on this topic

**One thing that we’ve talked about before is it’s important to know that you could get false positives with the Grail test or a liquid biopsy**

- And there can be other costs that then are associated with tracking down, “*Is this actually cancer?*”
  - Not only is that monetary costs, but also mental costs
- You do not do this test, or any pan-test (meaning a whole body MRI, for example), if you’re not willing to invest a few more dollars, tests, and emotional tears on the follow-up
- Peter wrote this in [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZcgbQlnqFiCOpITpGSBWWFL34c5iZkUakjOTS2Dn1AvSr-Jn_fv1JmA7LjvuyUpV4BzCg0ilDh2WKrtV3yaSBcf4m7yUM-4PQ4OAYEcYDCSZYYfTTRtcZb0sxImkz1DO8IQJZJCnxiK9F9U8hzRv_hRVgwJdTM9yvoPOcrnSumpjubBNL_pWTi1--1V48NkYcN1vPgD91toEjfyZYb7skHw.l8DIDHD-Et7jw0nem-p3J2CXzslkScyTXe8YELBLlaM&qid=1713365183&sr=8-1), it’s a perfectly response if you don’t feel comfortable doing the follow-up to not do this test
  - And stick with whatever the standard screening is
- Peter will tell you: everybody should have a high VO2 max, relative to their individual capacity; everybody should be as strong as they can be.; but he’s not going to sit here and say everybody should be screening for cancer like he does (absolutely not)

***Everybody has to really think through this to their own level of comfort***

## Colleen Cutcliffe episode: the importance of gut bacteria balance, and the potential therapeutic uses of probiotics, particularly Akkermansia [1:16:45]

[#283 ‒ Gut health & the microbiome: improving and maintaining the microbiome, probiotics, prebiotics, innovative treatments, and more | Colleen Cutcliffe, Ph.D.](https://peterattiamd.com/colleencutcliffe/) (December 18, 2023)

\*\*\*

- This is one of those topics that Peter has largely stayed away from because he has found it difficult to find people that he thought understood both sides of the equation
  - The science of the gut and the gut biome
  - And then they also understood the market side of it, the product side
  - It’s not that he hasn’t been able to interact with people who can talk about the science of what’s happening in the gut, but their knowledge seemed to stop there
- Peter met Colleen a year ago
  - They were introduced at an event and went for a long hike
  - 2 Hours into this hike, he thought she knew more about this than anyone he had ever spoken with, and the depth of her insight is at the level he wants to talk about

> “*For me, this podcast was really fantastic*.”‒ Peter Attia

- Peter points out:  Colleen is the founder and CEO of a company ([Pendulum](https://pendulumlife.com/)) that makes a [probiotic](https://pendulumlife.com/products/pendulum-glucose-control-2-og?utm_source=search&utm_medium=google&utm_campaign=132401569592_0a0a33abe6ddb35abab93336335b48e3&utm_term=pendulum%20glucose%20control&gclid=CjwKCAiA9dGqBhAqEiwAmRpTCxhKyPb2qKwNnku4l2sHRachq_u7SLMCvlecdjYQZx-p59xN-BHdpxoCrgIQAvD_BwE)
  - He has no affiliation with the product
  - He takes it and by extension, a number of his patients take the product
- Peter explains, “*I don’t want this to be viewed as simply an endorsement of the product, although as I said, I take it, which presumably is an endorsement. But I want this to really be an endorsement of Colleen, frankly, and her knowledge in this space.*”

**Importance of the gut biome**

- Like any nuanced scientist, Colleen starts out by explaining that we really don’t want to think of any of the bacteria in the gut as good or bad
  - Just as Peter rails against the idea of good cholesterol, bad cholesterol, she rails against the idea of good bacteria, bad bacteria
  - Context matters and that’s the end of that
  - It’s balance that matters, and imbalance often leads to pathology

*What leads to imbalance?*

- Antibiotics, poor nutrition, age, high degrees of physiologic stress, disrupted circadian rhythm, menopause
- All of these things can deplete select strains within the gut microbiome, and that leads to microbiome dysfunction

**Use of probiotics as a therapy**

- We talked about the most obvious 1st proof of principle that you could use bacteria selectively as a therapeutic agent: fecal microbiome transplant
  - This is something we had talked about in the past [in [episode #215 with Michael Gershon](https://peterattiamd.com/michaelgershon/)]
- There’s a condition called [C-diff](https://en.wikipedia.org/wiki/Clostridioides_difficile_infection) (*Clostridium difficile* colitis)
  - [*C. difficile*](https://en.wikipedia.org/wiki/Clostridioides_difficile#) is a bacteria that exists in all of us, but in some patients (especially in the hospital who are being given antibiotics to treat something else), the antibiotic disrupts enough of the other bacteria that *C. difficile* grows unchecked.
  - This becomes a very rapidly fatal condition
- The traditional treatment for that is to use another antibiotic (typically [vancomycin](https://en.wikipedia.org/wiki/Vancomycin)) to try to knock *C. difficile* back into its place, but if this is unsuccessful that patient’s going to die
- Peter has seen this happen back when he was in my training

***One of the alternative treatments for this that is approved and is very successful (though not without risk) is to give a complete transplant of the gut biome***

- While that’s an obvious and efficacious way to do things, the question is, for those of us who are not on death’s door is, “*Should we also be looking at ways to intervene?*”

**Our discussion focused a lot on a particular bacteria called** ***Akkermansia***

- Colleen approaches everything as a biochemist

*There are 3 actions of Akkermansia*

- 1 – It has these surface proteins (Amuc\_1100) that activates an [L-cell](https://en.wikipedia.org/wiki/Enteroendocrine_cell#L_cell), and the L-cell activates [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1)
  - GLP-1 regulates appetite and glucose control
- 2- It secretes something called p9 which activates these these molecules called ICAMs, and they further activate the L-cells which increase the production of GLP-1
- 3 – It produces something called propionate, which other strains of bacteria will turn into butyrate ([short-chain fatty acids](https://en.wikipedia.org/wiki/Short-chain_fatty_acid)), which bind to G-coupled proteins that further increase the activation of the L-cells to make GLP-1

***The long and short of this is Akkermansia would be hypothesized to regulate glycemic control***

**RCT of their probiotic**

- We talk about that throughout the interview and through the lens of a [pilot study](https://pubmed.ncbi.nlm.nih.gov/32675291/), that Colleen’s company undertook to randomize people to receive [*Akkermansia*](https://pendulumlife.com/products/pendulum-glucose-control-2-og) versus a placebo, to see if glycemic control improve
  - Which it did

**Most probiotics on the market**

- She said most probiotics have typically focused on [*Lactobacilli*](https://en.wikipedia.org/wiki/Lactobacillaceae) and [*Bifidobacteria*](https://en.wikipedia.org/wiki/Bifidobacterium), but she said that that’s really because those are what are called [obligate anaerobes](https://en.wikipedia.org/wiki/Obligate_anaerobe)
- It’s important to understand that we have aerobic bacteria, which are many of the bacteria that we think about in our world
  - These are the bacteria on our skin or in our nose or things like that
    - These are bacteria that like us, require oxygen to live
- And then in the colon, most of the bacteria are anaerobic
  - That means oxygen kills them
- Then you have a handful that are [facultative anaerobes](https://en.wikipedia.org/wiki/Facultative_anaerobic_organism), which means they really are anaerobes, but they aren’t killed by oxygen
  - And *Lacto* and *Bifido* are of those natures
  - And that means they can be grown in an environment that has exposure to oxygen and they’re much easier to grow (and they are)

***But really, there doesn’t appear to be much evidence that giving these bacteria does a whole heck of a lot, and that’s why they have focused on Akkermansia***

- *Akkermansia* is a pure anaerobe, and for that reason it is almost impossible to grow
- It has the advantage of being a very effective bacteria because it has these biochemical pathways we’ve talked about
- We spend some time talking about how *Akkermansia* is grown and why it’s so challenging to produce

***We also spend time talking about why you want to be skeptical of people who say they’re doing this without going through the pharma-grade process of making a pure anaerobic bacteria***

> “*As interesting as this work with Akkermansia is, clearly in 5-10 years, we’re going to have far more insight into either what Akkermansia can do, but perhaps more importantly, what other strains of bacteria play a role in restoring health.*”‒ Peter Attia

**Benefits of taking a probiotic**

- There are clear examples of where taking a bacteria (i.e. a probiotic) are beneficial in a pathologic sense
- We talked about the fecal microbiome transplants
- If the data from Pendulum’s [pilot study](https://pubmed.ncbi.nlm.nih.gov/32675291/) pans out, Peter thinks you’re going to make a very compelling case that if you have insulin resistance or type 2 diabetes, there’s a benefit as well

***What remains to be seen is, will there be a benefit for healthy people to take this?***

- We know the answer to that question yet
- This was a podcast that had many great insights, but most great podcasts, leaves us with many great questions

**Behavioral changes Peter has made since this podcast**

- None that he wasn’t already doing

*Other takeaways*

- 1 – At the beginning of the podcast we talked a lot about the role of [insoluble fibers](https://en.wikipedia.org/wiki/Dietary_fiber), and that’s what you really want to make sure you’re eating a lot of
  - Insoluble fiber is the food that feeds these bacteria;
- When we talk about all the things that can cause [gut dysbiosis](https://en.wikipedia.org/wiki/Dysbiosis), near the top of that list has to be people who are not getting enough insoluble fiber
- So whether you’re like Peter and you want to get it mostly through salads where it’s placed in a bowl that’s bigger than your head, knock yourself out
- But if you don’t like salads, you’re going to have to find other types of vegetables that are going to deliver you high enough doses of that
- 2 – It’s reasonable to be cautious around too much artificial sweetener
- Perhaps the one exception (Peter has talked to Colleen about this a lot) is [allulose](https://en.wikipedia.org/wiki/Psicose)
  - Allulose, it’s not absorbed and it’s got this whole renal distribution, so that might be one that has minimal to no bearing on the gut
- But when you start to think about the others, the non-nutritive and even the nutritive ones
- Peter would just say, “*Look, anytime you’re having an artificial sweetener, just ask yourself, ‘Is this essential or am I just doing this out of habit? Could I be drinking a sparkling water? Do I really need to be drinking an artificially sweetened beverage right now?*’”
- For him personally, maybe twice a month he’s going to have a diet Dr. Pepper, or a Diet Coke, but 99% of the time, he’s just going to be drinking a Topo Chico

## Mark Rosekind: the significant issue of road fatalities and injuries, their causes, and practical safety measures to reduce risks [1:27:00]

[#295 ‒ Roadway death and injury: why everyone should care and what you can do to reduce risk | Mark Rosekind, Ph.D.](https://peterattiamd.com/markrosekind/) (March 25, 2024)

\*\*\*

- This was a great episode because we spent so much time on this podcast talking about metabolic disease, cancer, heart disease (the four horsemen)

***But it’s easy to lose track of the fact that there’s another killer out there, and that killer is people who die in transportation accidents…90 plus percent of that is on the road***

- Mark opened the podcast by stating something that Peter thought was very powerful, “*In 2021 (the last year for which we have complete data) 42,929 people lost their lives on U.S. roadways*.”
- That was interesting, not just of the number, but because of the specificity with which he spoke about that
- He said, “*That is a number that we want everyone to know. It’s not 42,928, it’s 42,929. Every one of those people we want to remember. It’s 118 people a day on average. It’s a devastating statistic, and think about that compounding over and over and over again.*”
- If you then think about it through the lens of injury: 2.5 million injuries per year, each year, and 6 million crashes per year

> “*We’ve seen a 50% increase in pedestrian deaths in the past decade. This is attributed to a greater degree of distraction amongst both pedestrians and drivers*.”‒ Peter Attia

**All that said, it’s important to put in mind technology changes, and there have been so many things that make driving today safer than it was when Peter was born**

- 50 years ago, 18.5 people were killed for every 100 million miles driven on a U.S. road
  - That’s the metric that you use, obviously you have to normalize this somehow
  - You can’t look at total number of deaths because the population is growing

***But today that number is down from 18.5 to 1.5. That is a slightly more than log-fold reduction and that’s a remarkable thing to look at.***

**Demographic responsible for fatal roadway crashes**

- One of the other things Peter was both surprised to hear and scared to hear, was that there’s a bimodal distribution of the driver demographic that is responsible for most of these fatal

***It’s 16 and 17 year olds (disproportionately males over females) and people 70 and up***

- Peter doesn’t think that’s surprising, and he’s sure somebody’s going to get mad that that sounds very ageist in both directions
- But the data are the data, regardless of how people feel about that
- For Peter, as someone who has a 15-year-old who’s got a learner’s permit, he’s not particularly excited about her driving that much
- And luckily as a female, he suspects she’s going to be a little less of an idiot than he was when he started driving
  - He could make the case that he’s lucky to be alive, just as many people listening to this are

**What are the causes of these crashes?**

- Analysis suggests it’s about 94% human causes, 2% technical (something wrong with the car), 2% environmental (for example, something in the weather), and then 2% from everything else
- When you talk about the main drivers of human causes, about 30% of these accidents result from some form of impairment (either ethanol, cannabis, or sleep deprivation)
  - About 25% of these are related to excess speed
  - About 30% are related to driver distraction
    - And that is not surprisingly something that is becoming more and more prevalent, as time goes on

**How can you be a little bit safer on the road?**

- The first step is obviously minding your own house ‒ the best thing you can do is be the best driver you can be
  - Don’t be the one that causes the accident, either that kills you or kills another driver or pedestrian

***Mark’s mantra: eyes on the road, hands on the wheel, head in the game***

*All sound obvious, but if we’re going to be brutally honest (Peter included), how many times are we failing on that?*

- For Peter, he’s pretty good about keeping his eyes on the road and his hands on the wheel
  - He’s definitely not the guy that’s reaching around grabbing the mocha frappuccino and futzing around on his phone
- But for him, it’s the head in the game that is the biggest challenge
  - It’s very easy for him to hop on a phone call that’s an important phone call and get really, really down the rabbit hole of not paying attention to what’s happening
- Peter is not going to sit here and tell you that he’s never going to talk on the phone while driving, but he’s more mindful of, “*What’s the frequency with which I should do it?*”
  - There are certain phone calls that absolutely don’t make sense to have while he’s driving because he can’t commit ample resources to the drive

 **The other thing Peter thinks about now, when driving**

- Let’s say you’re doing everything right, your head is in the game

*What else do you need to be focusing on to make sure that when another driver screws up, you aren’t going to bear the brunt of that mistake?*

- We’ve written about this several times now on a couple of our [newsletters](https://peterattiamd.com/kelvin-kiptum/), and we reiterated it here
  - [See the full list in the selected links section at the end]
- The easiest way to think through this is to go to where the deaths are

***1 – A third of deaths in cars happen at intersections***

- That is the #1 spot for a fatality
- Peter explains, “*Every time you’re going through an intersection, you need to be puckering up that sphincter tone. That’s where bad things happen*.”
- It is almost always going to be a driver that blows an intersection when you have the right of way

***The good news is, there is only a couple degrees of freedom when you’re going through an intersection that are going to result in your death ‒ statistically speaking as the driver, it’s going to be the driver hitting you on the left side***

> “*It’s an easy thing to do when your head is in the game, and it’s an easy thing to forget when your head is not in the game*.”‒ Peter Attia

- You’ve heard Peter say this before and again, “*Look left, look right, look left, before you enter the intersection when you have the right of way.*”
- In the entire time he’s been doing this (many, many years), he’s had 2 very close calls, where he’s had to stop when he had the right of way because someone ran the light

*2 – The next most common place that you’re going to die on the road is in two-way traffic where there’s no median*

- We see this a lot in Texas where Peter lives
- It’s most disconcerting because we have some very fast roads here
  - It’s not uncommon to have 60 and 70 mile an hour posted limits with two-way traffic and no median
  - Think about that for a moment: you got two people going 60 miles an hour that hit each other head on
    - That’s like hitting a wall at 120 miles an hour
- It is not surprising that very often, all parties are killed immediately in those types of accidents
- It can happen in an instant

***Peter’s rule of thumb here is he is never in the left lane unless he has to make a pass***

- He’s going to be in the right lane all day every day because it gives him just that additional buffer, if someone in the oncoming lane is coming into him

*3 – The third most likely place you’re going to die on the road is the freeway*

***When it comes to the freeway, it’s mostly when people are changing speed***

- This is someone getting on or off the freeway where speeds are changing dramatically
- So someone who’s in the left-hand lane, who at the last minute, realizes they need to get off and they just want to cut over everybody
- Or someone who’s merging on and doing so too slowly
- Those are the places where you get into trouble
- So again, you have to be paying attention

**The mind game Peter’s uses every time he gets on the freeway**

- He pretends that somebody woke up that day and they were given the secret mission of killing him, but they had to do it with their car
  - And he doesn’t know who they are
- Luckily there’s thousands of people out there, so the probability he’s going to run into them is not high, but it’s not zero
- You just have to imagine 1 of these people is an assassin sent here to kill you, and they’re not going to do it with a gun, they’re going to do it with their car

**Pedestrian deaths are up 50% ‒ how to be safer**

- 1 – Walk on the sidewalk
- 2 – Even on the sidewalk, and make sure you are incredibly visible if you’re walking at night
- 3 – Walk facing traffic
  - Peter spends a lot of time walking because he’s rucking, and one of the things that he’s does, especially when there aren’t sidewalks ‒ he makes sure he’s walking on the opposite side of the road
- 4 – There’s also still an awareness, “head in the game” thing
- 5 – When Peter is walking on the road, every time a car approaches him, he tries to make eye contact with the driver and wave
  - You could argue, “*Oh, what a friendly walker. He’s waving at every driver*.”
  - He’s also giving the driver a reason to look at him as well
  - Technically he’s not doing it to be friendly, he’s doing it to not die

§

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Luc van Loon**: [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) |  (April 22, 2024) | [9:45]

**Episode of** ***The Drive*** **with Gerald Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) (December 7, 2020) | [10:45]

**Episode of** ***The Drive*** **with Layne Norton mentions amino acid recycling**: [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training](https://peterattiamd.com/laynenorton/) (May 24, 2021) | [13:00]

**Larger doses of protein can contribute to protein synthesis**: [The anabolic response to protein ingestion during recovery from exercise has no upper limit in magnitude and duration in vivo in humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10772463/) | *Cell Reports Medicine* (J Trommelen et al 2023) | [17:45]

**Newsletter about larger doses of protein**: [New insights on maximizing protein utilization for muscle protein synthesis](https://peterattiamd.com/protein-anabolic-responses/) | PeterAttiaMD.com (K Birkenbach, P Attia 2024) | [17:45]

**Single leg immobilization and muscle loss**: [One Week of Single-Leg Immobilization Lowers Muscle Connective Protein Synthesis Rates in Healthy, Young Adults](https://pubmed.ncbi.nlm.nih.gov/37994085/) | *Medicine and Science in Sports and Exercise* (A Holwdera et al 2024) | [21:00]

**Episode of** ***The Drive*** **with Courtney Conley**: [#296 ‒ Foot health: preventing and treating common injuries, enhancing strength and mobility, picking footwear, and more | Courtney Conley, D.C.](https://peterattiamd.com/courtneyconley/) (April 1, 2024) | [26:45]

**Toe spacers that Peter wears**: [Naboso Splay](https://www.naboso.com/collections/accessories/products/naboso-splay?utm_source=google&utm_medium=cpc&utm_campaign=brand&gad_source=1) | Naboso (2024) | [33:15]

**Episode of** ***The Drive*** **with Olav Aleksander Bu**: [#294 ‒ Peak athletic performance: How to measure it and how to train for it from the coach of the most elite athletes on earth | Olav Aleksander Bu](https://peterattiamd.com/olavaleksanderbu/) (March 18, 2024) | [36:45]

**Portable VO2 analyzer**: [VO2 Master](https://vo2master.com/) | [39:15, 56:15]

**Newsletter about biological clocks**: [“Biological” clocks: a peek into the future or a haphazard guess of mortality?](https://peterattiamd.com/how-accurate-are-biological-age-clocks/) | PeterAttiaMD.com (S Lipman, K Birkenbach, P Attia 2023) | [43:30]

**Content on VO****2** **max**: [VO2 max](https://peterattiamd.com/category/exercise/vo2-max/) | PeterAttiaMD.com | [38:00]

**Content on Zone 2 training**: [Aerobic & Zone 2 Training](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/) | PeterAttiaMD.com | [47:15]

**Episode of** ***The Drive*** **with Alex Aravanis**: [#290 ‒ Liquid biopsies for early cancer detection, the role of epigenetics in aging, and the future of aging research | Alex Aravanis, M.D., Ph.D.](https://peterattiamd.com/alexaravanis/) (February 18, 2024) | [1:01:30]

**Episode of** ***The Drive*** **with Max Diehn**: [#213 ‒ Liquid biopsies and cancer detection | Max Diehn, M.D. Ph.D.](https://peterattiamd.com/maxdiehn/) (July 11, 2022) | [1:01:30]

**The GRAIL Galleri test for cancer**: [Galleri](https://grail.com/galleri-test/) | GRAIL (2024) | [1:09:30]

**Study design of Prospective RCT for cancer detection by Galleri test**: [Cell-Free DNA-Based Multi-Cancer Early Detection Test in an Asymptomatic Screening Population (NHS-Galleri): Design of a Pragmatic, Prospective Randomised Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/36230741/) | *Cancers* (R Neal et al 2022) | [1:13:00]

**Episode of** ***The Drive*** **with Colleen Cutcliffe**: [#283 ‒ Gut health & the microbiome: improving and maintaining the microbiome, probiotics, prebiotics, innovative treatments, and more | Colleen Cutcliffe, Ph.D.](https://peterattiamd.com/colleencutcliffe/) (December 18, 2023) | [1:16:45]

**Pilot study of probiotic** ***Akkermansia***: [Improvements to postprandial glucose control in subjects with type 2 diabetes: a multicenter, double blind, randomized placebo-controlled trial of a novel probiotic formulation](https://pubmed.ncbi.nlm.nih.gov/32675291/) | *BMJ* (F Perraudeau et al 2020) | [1:22:00]

**Probiotic that improves glycemic control**: [Glucose Control](https://pendulumlife.com/products/pendulum-glucose-control-2-og) | Pendulum (2024) | [1:22:15]

**Episode of** ***The Drive*** **with Mark Rosekind**: [#295 ‒ Roadway death and injury: why everyone should care and what you can do to reduce risk | Mark Rosekind, Ph.D.](https://peterattiamd.com/markrosekind/) (March 25, 2024) | [1:27:00]

**Newsletters about roadway accidents**: [1:32:45]

- [The loss of a rising marathoner is a tragic reminder of the toll of motor accidents](https://peterattiamd.com/kelvin-kiptum/) | PeterAttiaMD.com (K Birkenbach, P Attia 2024)
- [The Safety Debate Between Manual and Automatic Transmissions](https://peterattiamd.com/the-safety-debate-between-manual-and-automatic-transmissions/) | PeterAttiaMD.com (K Birkenbach, P Attia 2022)
- [The Epidemic on the Road](https://peterattiamd.com/the-epidemic-on-the-road/) | PeterAttiaMD.com (K Birkenbach, P Attia 2022)
- [Do helmets give cyclists a false sense of security?](https://peterattiamd.com/do-helmets-give-cyclists-a-false-sense-of-security/) | PeterAttiaMD.com (P Attia 2022)
- [The killer(s) on the road: reducing your risk of automotive death](https://peterattiamd.com/the-killers-on-the-road-reducing-your-risk-of-automotive-death/) | PeterAttiaMD.com (P Attia 2020)
- [Driving while distracted](https://peterattiamd.com/driving-while-distracted/) | PeterAttiaMD.com (P Attia 2019)

§

## People Mentioned

- [Luc van Loon](https://www.maastrichtuniversity.nl/ljc-van-loon)
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/#:~:text=Shulman%20is%20the%20George%20R,the%20Yale%20Diabetes%20Research%20Center.&text=Shulman%20is%20the%20recipient%20of%20the%20Stanley%20J.)
- [Layne Norton](https://twitter.com/biolayne)
- [Courtney Conley](https://gaithappens.com/attiapod/)
- [Olav Aleksander Bu](https://www.sloansportsconference.com/people/olav-aleksander-bu)
- [Alex Aravanis](https://twitter.com/Alex_Aravanis)
- [Max Diehn](https://profiles.stanford.edu/maximilian-diehn?tab=bio)
- [Colleen Cutcliffe](https://pendulumlife.com/pages/story)
- [Mark Rosekind](https://en.wikipedia.org/wiki/Mark_Rosekind)

§