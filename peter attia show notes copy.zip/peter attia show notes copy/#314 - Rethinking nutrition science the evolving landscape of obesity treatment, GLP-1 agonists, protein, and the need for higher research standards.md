# #314 ‒ Rethinking nutrition science: the evolving landscape of obesity treatment, GLP-1 agonists, protein, and the need for higher research standards | David Allison, Ph.D.

**Source:** [https://peterattiamd.com/davidallison2/](https://peterattiamd.com/davidallison2/)

---

David Allison, a leading expert in obesity and nutrition, quantitative genetics, clinical trials, and research methodology, returns to The Drive to explore the evolving landscape of nutrition science and obesity treatment. In this episode, David begins by discussing the intricate relationship between nutrition, obesity, and body composition, emphasizing the multifaceted impacts of food beyond mere calorie intake. David provides a critical analysis of the complexities in nutrition research and their practical implications for tackling obesity. He critiques historical public health policies, addresses the trust issues plaguing nutrition science, and underscores the need for a paradigm shift to more effectively combat obesity. The conversation also delves into the rise of GLP-1 receptor agonists like Ozempic and Mounjaro, exploring their ethical and practical considerations in obesity treatment. The episode concludes with an in-depth look at protein intake recommendations and highlights the significant research gaps that remain in the field.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/davidallison2/the_Drive_public.png)

Play

#314 ‒ Rethinking nutrition science: the evolving landscape of obesity treatment, GLP-1 agonists, protein, and the need for higher research standards | David Allison, Ph.D.

#314 ‒ Rethinking nutrition science: the evolving landscape of obesity treatment, GLP-1 agonists, protein, and the need for higher research standards | David Allison, Ph.D.

1x15s30s

0:001:58:34

## We discuss:

- The complex relationship between nutrition, body weight, and body composition [2:30];
- The slow progress in addressing obesity and public health despite substantial effort and investment [7:30];
- The very limited success of public health initiatives in curbing obesity [17:15];
- The evolving landscape of obesity research: public health initiatives and the impact of pharmacological success [26:30];
- Rethinking obesity solutions: the need for a paradigm shift [32:45];
- Understanding environmental triggers and embracing a balanced approach to addressing obesity that includes both pharmacological treatments and realistic lifestyle changes [41:45];
- The need for higher standards in obesity research [51:45];
- The rapid success of GLP-1 receptor agonists for weight loss: a discussion on the societal impact and controversy of their growing usage [1:02:15];
- The ethical and practical considerations of obesity drugs: risks, benefits, and motivations for usage [1:11:30];
- The use of GLP-1 agonists by athletes as performance enhancers [1:23:45];
- Unanswered questions about protein intake and health [1:30:45];
- Future research needed to understand basic questions around protein intake [1:45:00];
- David’s weekly newsletter: “Obesity and Energetics Offerings” [1:50:45]; and
- More.

§

## Show Notes

\***Notes from intro**:

- David Allison returns to *The Drive* for a second sit down
- He is currently the Dean and Provost Professor at the Indiana University Bloomington School of Public Health
- He has authored over 500 scientific publications and received many awards
- His research interests include obesity and nutrition, quantitative genetics, clinical trials, statistical and research methodology, and research rigor and integrity
- In our conversation today we discuss the relationship between nutrition, obesity, and body composition
  - How food affects body composition beyond caloric intake
- This leads us to a discussion around the complexity of nutrition research studies and how confusion continues to remain with translating knowledge into practical outcomes
  - Such as reducing obesity
- We talk about the public health efforts and policy
  - Why they have failed historically, in regard to obesity
  - And why there’s such a trust problem with nutrition science
- Next we dive into the emergence of GLP-1 agonists in treating obesity
  - And what is happening both socially and psychologically with drugs like Ozempic and Mounjaro
- We end the discussion talking about protein intake and the adequacy of current protein intake recommendations and the research gaps that lie between what we are told and maybe what is actually known
- Overall, this was a fascinating and philosophical (at times) discussion on the evolving landscape of nutrition science, obesity treatment, and the impact of research

## The complex relationship between nutrition, body weight, and body composition [2:30]

- The world of nutrition and health are always in the spotlight, in particular around a class of drugs: [GLP-1 agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist)
- Before we talk about that let’s talk a little bit about what we know and maybe don’t know about the relationship between nutrition and obesity

**Tell us what you think is actually known about the relationship between food and body composition**

- David likes the way Peter phrased this question, using the phrase “body composition” as opposed to just obesity or weight
- Those are 3 different things
  - **Obesity** implies a threshold, too much; there’s a judgment about the effects of the excess
  - Then there’s **body composition**, the tissue, how much is fat, how much is lean?
    - Where is the fat/ lean, what is the fat composed of?
    - What is the lean composed of?
  - Then there’s just **weight**, which is just your mass on this planet

***Those 3 things are highly related but not identical***

- What we know indisputably and even people who sort of rail against something they call the **“energy balance model”** (discussed in [episode #197](https://peterattiamd.com/davidallison/)) whether it’s really a model is unclear
  - It’s really more of a constraint
    - It is a constraint by which all other descriptions of what happens with weight and mass and food intake and energy and taken energy expenditure must operate
  - It’s really a restatement of the [first law of thermodynamics](https://en.wikipedia.org/wiki/First_law_of_thermodynamics), which is the law of conservation
    - Matter and energy can neither be created or destroyed but only converted
  - It’s not a description or an explanation of what happens
  - It just says if you describe any proposed explanation of what happens, it’s got to follow that first law of thermodynamics in order to make sense
- And that first law of thermodynamics in the field of nutritional obesity often gets stated as something like changes in energy storage equal changes in energy intake minus changes in energy output or delta energy stores equals delta energy in and minus delta energy out
  - Food intake can affect those things
  - Alternatively, you could say that energy intake is one of those things
  - So it gets back to that descriptive thing

*One of the questions becomes: How does all the other aspects of food besides the mere energy content of it affect the amount of weight one gains or loses, the body composition, the tissues, where the mass is distributed, what types of tissues it’s in, composition of those tissues?*

- Then whether or not one exceeds some threshold
- There’s every reason to believe that many aspects of food can influence the intake of it and other things as well
  - From the marketing and pricing of it
  - To the taste, the smell, the smell, the timing, what you eat it with, what it’s combined with, phytochemicals in it, micronutrients, macronutrients
- All can affect energy expenditure, subsequent energy intake or nutrient partitioning
  - Which is a fancy phrase for where you stick the energy that you store in the body
    - Do you stick it into fat or muscle or bone or visceral fat or subcutaneous fat, etc.

> “*The truth is, I think what we know is modest, and partly that’s because it seems to me to be very specific*.”‒ David Allison

- When you do a study and find in this species with this delivery of this composition in this way, this thing happens
  - When you look in a different species or a slightly different food, you get different results
  - Even when it’s well done and honestly done
- So there’s many, many studies saying, “*Well, we got this with pea protein and casein but not whey. Or we got it with whey but not casein. Or we got it when we fed it 2 hours before the test meal, but not 1 hour before. Or we got it in men but not in women*.”

David’s conclusion: ***This makes me think we’re talking often about subtle effects that may not be that clinically reliable and meaningful. And so the really big effect seems to be how many calories do you eat?***

- All these other aspects of food may then influence how many calories you eat, either of that food or in subsequent occasions
- And those can seem to have big effects, but we’re still sort of trying to suss those out

## The slow progress in addressing obesity and public health despite substantial effort and investment [7:30]

Peter asks, “*Do you ever spend time interacting with physicists or chemists, biochemists who sit on the sidelines and sort of look at the field of human energetics and wonder to themselves, ‘Why is there so much noise and why is there so little understanding?’”*

- Peter doesn’t think anybody is blaming the scientists

**What do you think it is at the meta level that explains the obvious but important observation that our knowledge in this space is woefully deficient relative to the effort that has been put into elucidating truth?**

*For example, why do we know very little relative to the same amounts of effort that have gone into physical sciences?*

- There are many reasons; some are perceptual and some are actual
- Perceptual: do we really know that much less?
  - In physics, how is it that relativity and quantum physics are compatible; or is dark matter real?
- We don’t’ give ourselves credit for certain things
  - In physics, there’s not a lot of discussion in modern times of the power of Newton’s, universal law of gravitation
    - It was figured out a long time ago and we take it for granted
- Some simple examples at the practical level in energetics
  - In most industrialized countries, there’s very little food shortage
  - It’s a big deal that we know that alcohol contains calories (we take that for granted)
    - [Wilbur Atwater](https://en.wikipedia.org/wiki/Wilbur_Olin_Atwater#) who stated the caloric content of alcohol was vilified for it at the time by the Temperance Movement
    - He himself was a teetotaler by the way that alcohol had no nutritional value
- [Folate](https://en.wikipedia.org/wiki/Folate) supplementation, which has radically reduced [spina bifida](https://en.wikipedia.org/wiki/Spina_bifida)
- Iodized salt, micronutrient deficiencies being maybe not eradicated in this country, but radically reduced a
- Other supplementation and greater food safety

***We’ve made a lot of practical progress***

- We’ve been feeding a number of people through nutrition and agriculture
  - More recently in the 1970s when we were told there was going to be a population explosion that would threaten our ability as a species

Peter asks, “*But isn’t that really more about agriculture than nutrition science?*”

- It’s agriculture, it’s food science
- Some of the nutrition science is more the micronutrients
  - All the way back to eliminating [scurvy](https://en.wikipedia.org/wiki/Scurvy) through the work of [James Lind](https://en.wikipedia.org/wiki/James_Lind) and figuring out eventually that it was vitamin C
    - They first thought it was just citrus in general
    - They didn’t assume it was the vitamin C
- To the folate and so forth, David thinks our notions, our understanding about LDL-cholesterol is very important
- The role of [saturated fats](https://en.wikipedia.org/wiki/Saturated_fat) and that we’re still learning more, but we do know some things about that

> “*I don’t think we want to take for granted that we have learned a great deal.*”‒ David Allison

**David’s perspective on obesity**

- In obesity, until 5 years ago (or so), when he would give talks about this, he would say, “*We actually have learned a lot, but it’s just not all that clinically relevant and what’s clinically relevant is mostly truly in the clinic, not in the community and the population*.”
- We’ve learned a lot about genetics (log orders)
  - Knowledge about the genetic underpinnings of obesity that we didn’t have prior to 1980

***Until recently, we’ve had moderate improvements in the clinic and virtually no improvements in the public health community domain***

**Peter’s analogy**

- When the Wright brothers first put an airplane into the sky, nobody would’ve said aviation is amazing
  - That was a proof of concept
- It’s safe to say that almost monotonically aviation has become safer and safer and safer over the past hundred years
- Peter thinks that allows us to say our understanding of Newtonian physics, Bernoulli’s principle, material science, all the things that enable aviation to be what it is today, relative to a hundred years ago, are probably getting better, and we’re also getting better at applying them to a real world problem
- Conversely, if the rate of airplanes falling out of the sky were increasing steadily over the past 50 years such that in 1970, whatever, 10% of airplanes fell out of the sky, but today 50% of airplanes fell out of the sky,nobody would be walking around saying, “*We’re doing really well. We understand much more about the physics of the airplane. Yes, it’s true. More of them are falling out of the sky*.”

> “*I would argue that in the presence of all of this knowledge that we have, we’re getting fatter and we’re getting sicker.*”‒ Peter Attia

**How do we reconcile the fact that our knowledge is somehow increasing and we’re so much more knowledgeable and yet the actual problem that matters seems to be getting worse, not better?**

- What we don’t have is the sort of sea change, the real orbit jumps in knowledge of a utilitarian useful knowledge, knowledge that helps us change the way we do things now that lead to better outcomes
  - There are a couple of exceptions that they will talk about later

Peter asks, “*So we have useless knowledge? What’s the contrapositive of that?*”

***We have knowledge that is useful for understanding and we hope we can build on to get to practical knowledge***

- [Steve O’Rahilly](https://www.csap.cam.ac.uk/network/steve-orahilly/) gave a nice talk about this about 2 years ago at the Royal Society meeting that he and David and others spoke at and hosted, and he said about his early days working in blood pressure (a few decades ago), “*As a physician geneticist biochemist who works in the field… We didn’t really have a lot of good drugs and blood pressure, and people kept hammering at the molecular biology and the biochemistry and the physiology of blood pressure and bit by bit things started to break… Now, we can treat blood pressure enormously better.*”
- That’s where he thinks we’re going to go with obesity ‒ we’re just sort of getting to the breaking point
- David thinks that’s what we’re seeing now with the [GLP-I agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) as well as some other drugs

*In other words, we may get to a point in 30 years when obesity rates are back to the level they were 50-100 years ago, and virtually everybody will be on a drug which we may or may not understand the mechanism of action for*

- David thinks we will understand more of the mechanism of action 30-50 years from now
  - Today, we don’t fully understand it
- Peter think’s that’s a reasonable analogy comparing it to blood pressure or comparing it to lipid management for that matter
  - Even 40 years ago, we didn’t really have tools to manage lipids
- David explains that the investment is going heavily toward biochemistry, molecular genetics, physiology, and pharmaceuticals
- We’ve seen an uptick and we’re seeing more of an uptick in that because some success is being achieved and the pharma companies, many of which who over the last few decades would be tepidly in and out, they’d dip their toe in the water of obesity, wouldn’t go so well, they’d pull out
  - Now they’re saying there’s real success coming

## The very limited success of public health initiatives in curbing obesity [17:15]

**There were a couple of recent Cochrane collaborations that came out discussing the success (or lack thereof) of public health initiatives around obesity**

*Do you want to say a little bit about those and maybe also talk a little bit about the history of why one would say that public health efforts to curb obesity have been a failure and the future of obesity management will be pharmacologic, not public health related*

- David think’s that’s a reasonable prediction, but he’s not sure it’s one he shares completely
- [they’ll come back to these Cochrane reviews later]

***Public health efforts to affect obesity in a meaningful way have thus far been singularly unimpressive***

- They may come back to talk about why, where that’s going, and where it should go
- In the present, and even more so in the not too distant future, clinical management including surgery and pharmaceuticals will be ever more powerful, safe, effective, and utilized
  - He doesn’t think they will ever become the complete solution
  - And he doesn’t think that there’s no solution in public health, but we’ve got to approach it differently

**When David started his career in 1991**

- He came to the New York Obesity Research Center at Columbia University and St. Luke’s-Roosevelt Hospital
  - It was the only [NIH funded obesity research center](https://www.niddk.nih.gov/research-funding/research-programs/nutrition-obesity-research-centers) at the time (it’s the first)
  - It was run by [Xavier Pi-Sunyer](https://www.researchgate.net/profile/Xavier-Pi-Sunyer-2), the legacy of [Ted Van Itallie](https://ajcn.nutrition.org/article/S0002-9165(22)00994-7/fulltext)
    - Across the park you’ve got [Jules Hirsch](https://en.wikipedia.org/wiki/Jules_Hirsch), [Rudy Leibel](https://www.neurosciencephd.columbia.edu/content/rudolph-l-leibel-md), and that group at Rockefeller
- Obesity wasn’t at the level of public interest that it is now
- What you had is these very **interdisciplinary groups:** physiologists, geneticists, physicians, psychologists, statisticians, nutrition scientists, etc. all working together on these problems
  - Many had been working together for decades, very academic but also clinical
- You had all the powerhouses that were in that region
  - You had [Mickey Stunkard](https://en.wikipedia.org/wiki/Albert_Stunkard) over at UPenn, you had [MRC Greenwood](https://nutrition.ucdavis.edu/people/mrc-greenwood) and others at Vassar and so forth

***If a young person like David made some foolish statement in a seminar about some aspect of physiology or medicine that showed he had no understanding of what the heck he was talking about, one more senior person would put him in his place***

- But in a very constructive way and explain
- And the statisticians would argue with the physiologists and so on
- You had a depth of knowledge and a real depth of expertise and an understanding

**The history around our current obesity epidemic:**

*Then the* [*NHANES-III*](https://en.wikipedia.org/wiki/National_Health_and_Nutrition_Examination_Survey) *data came out and there was the sense of crisis and panic public health*

- This is the **N**ational **H**ealth **a**nd **N**utrition **E**xamination **S**urvey
- It started coming out in the early ‘90s
- At the time, it was only done every few years
- The 3rd one was done, maybe between ’88 and ’93; so that the midpoint data they released around ‘91
- People started using the word **“epidemic”** and they saw what looked like a jump in the ‘80s
- Whether there’s a real jump or not is actually not so clear
  - If you look at skin folds, you see less of a jump and you see the increase starting earlier
  - If you look just at BMI and you look at increase, it’s been going up for hundreds of years
- The data from the Nobel laureate, [Robert Fogel](https://en.wikipedia.org/wiki/Robert_Fogel) ‒ he collected all these old data on British naval cadets from the 18th century and French cadets and Civil War soldiers and recaptured slaves during the Civil War and looked at these different groups
  - You see that obesity levels in BMI have been increasing for centuries
- But there clearly did seem to be an acceleration and that caused a panic
- Probably the most powerful voice at the time in this domain was [Kelly Brownell](https://sanford.duke.edu/profile/kelly-d-brownell/)
  - Kelly had been a real devotee of [Mickey Stunkard](https://en.wikipedia.org/wiki/Albert_Stunkard); he was one of Mickey Stonkert’s proteges and mentorees
  - He is a behavioral psychologist, doing behavioral treatment
- As a grad student, David would go to Kelly’s lectures and learn the mechanics of how to do behavioral treatment, cognitive behavioral therapy for obesity

Peter asks, “*Meaning CBT to help people eat less?*”

***Eat less, exercise more, and so on***

- Then he in the late ‘80s, early ‘90s he had a change, and shortly thereafter switched to Yale
- He got a [MacArthur Prize](https://en.wikipedia.org/wiki/MacArthur_Fellows_Program#) (the so-called Genius Award) and he started to look at maybe concerns about the negative effects of obesity
- He was one of the most powerful voices to start raising questions about the effects of yo-yo dieting or weight cycling going up and down
  - Are we doing more harm than good?
  - Are we just building false hopes up for people because obesity treatment is useless?
- Then he morphed into, it’s the environment
- He introduced the phrase **“toxic environment”**
  - We live in a toxic environment: you can’t drive down the street without encountering a fast food restaurant ( this is the problem)

***Kelly Brownell advised: we need to stop the individual treatment; we need to go to the public health treatment***

- He sort of abandoned his roots
- Many others were grasping that idea, inspired often by him, but others on their own, ad the public health community rushed in
  - This was a community that up until that point was working on smoking, food safety, leaded gasoline, sanitation, vaccination, so on

**There was a sense of “this is simple” ‒ people eat too much, they don’t exercise enough**

- Eating less is good
- Eating more “healthy” food is good
  - Some foods are considered healthy, some are not
  - And if you eat healthy food, something magical will happen
- More exercise is good

***Without any real understanding of this***

David has had public health people ask, “*If we got people to not walk with their iPhones, then they would walk a little faster and then they would expend more energy while they’re walking across campus, and that will help with weight loss. And what do you think?*”

- David thought, “*Well, we’re still going to cover the same distance;*” there’s a nonlinear relationship between walking speed and energy expenditure and the amount of energy is trivial etc.
  - Nobody who understands movement science and energetics and kinetics would make such a statement
  - But public health people think  they need clever ways of getting people to behave
- This is where if you’re embedded in a group of people, like the New York OBC Research Center, that wouldn’t have happened
  - They would immediately be educated by senior people who had been thinking about this

***In other words, the public health field wasn’t really able to self-police ideas that were not grounded in science***

**One of the things the School of Public Health at Indiana University of Bloomington is very proud of is their kinesiology department**

- They’re 1 of 4 schools of public health in the US that  have a named kinesiology department

> “*Every school of public health studies physical activity, but studying physical activity and being an expert in exercise science are two completely different things.*”‒ David Allison

- They have actual experts in exercise science who understand this, who treat it as a science and take it seriously
- It’s something they’re very proud of, and they do great work

**We’ve got a lot of nonsense rushing in the field**

- We got a lot of things that you wouldn’t have predicted to work, but people tried them because they sounded good, they felt good, gave people a positive feeling
  - Vending machines, farmer’s markets, walking trails
  - Without really saying, “*All right, let’s really work this out. How many people are going to do it? If they do it, how much effect will it have? Will they compensate by eating more or less or moving more or less later?*”

***We got a whole couple of decades of lousy uninformative research***

## The evolving landscape of obesity research: public health initiatives and the impact of pharmacological success [26:30]

**While the public health movement was taking hold, what happened to the guard?**

- The old guard that David referred to as having learned the physiology of obesity in the late ‘80s, early ‘90s?
- Peter wonders, “*What was their response to this? Were they a part of the movement? Were they distinct from the movement?*”

***It’s a mix***

- Some of the real strong behavioral people rushed in, did good science in the sense of things that were rigorous, but maybe not always well conceived that they were likely to be impactful
- But there was grant money to be had and people went after it and still do

**So was this also just driven by funding? Was there a change in funding priority?**

- It’s a lot more funding for obesity, still not as much as many people want
- There was the [Robert Wood Johnson Foundation](https://en.wikipedia.org/wiki/Robert_Wood_Johnson_Foundation), which didn’t put a huge amount of money in, but put money in (whether it was intentionally or not) in a very strategic way
  - Meaning they put in relative to what NIH or pharma put in
  - They put in a small amount of money, but it sounded like a big amount of money
  - It had millions
  - They made a lot of noise about it very successfully
  - They got a lot of careers started
  - They drew a lot of people into the field around public health, around community intervention, around diversity issues, and that’s all to the good

***What David thinks often happened is the amount of money they were dangling in relative to NIH, was small***

- So many people would rush in and get started that way, but then they’d go to NIH and get bigger studies
- So it did catalyze a lot of activity, and that’s good

***What we’ve learned, you can make different arguments about it***

- The very famous story with [Edison](https://en.wikipedia.org/wiki/Thomas_Edison) where his backers come to him, and say, “*All this time and money, and you still have nothing to show for your efforts toward making a light bulb.*”
  - And he said, “*No, I now know a thousand ways not to make a light bulb.*”
  - Whether it’s true story or not, David doesn’t know

**Those 2 Cochrane reviews Peter referred to earlier**

- [Summerbell](https://www.durham.ac.uk/staff/carolyn-summerbell/) was the senior author (not the first author)
  - One was in [children 5-12](https://pubmed.ncbi.nlm.nih.gov/38763517/) and the other is in [adolescents](https://pubmed.ncbi.nlm.nih.gov/38763518/)
- They do systematic reviews, very thorough, very objective meta-analyses according to the Cochrane method

*1 – What they find is that for both groups, there is no compelling evidence of what you would call a consistent, reliable, long-term clinically or public health, meaningful effect on preventing obesity in either children or adolescents*

- David included a lot of adjectives in there, and those are important
  - Most important one is probably “preventing,” he didn’t say treating, he said preventing

***That doesn’t mean that treatment of obesity in children doesn’t have any efficacy***

*2 – These are community diet exercise interventions*

Peter asks, “*How easily do we distinguish between prevention and treatment? Obviously, conceptually it’s trivial. Prevention is reducing the number of new cases. Treatment would be reversal of, but can you give a sense of what reversal of obesity rates look like?*”

- With public health stuff, David doesn’t want to say it’s zero because you always have some spontaneous reversal

*This article focused on the prevention side, not the treatment side. Was the implication that public health treatment has been successful, but prevention has not?*

- No, no
- There is some evidence for success of clinical treatment, more so in adults

Peter asks, “*Does clinical treatment include drugs and surgery?*”

- It can, but it doesn’t have to
- Somebody goes to a clinic, let’s say to see [Len Epstein](https://medicine.buffalo.edu/faculty/profile.html?ubit=lhenet) at Buffalo, and he puts them in a study for weight loss
  - David would call that a clinical intervention as opposed to Len Epstein saying, “*I’ve got an idea. I’m going to go out to the public schools and set these programs up and we’ll try to get everybody to be less obese and see if we prevent obesity*.”
- Len is one of the sharpest cats around, and he’s a very good skeptic and a very good commenter on what we really know and don’t know in that domain

**What** [**Summerbell**](https://www.durham.ac.uk/staff/carolyn-summerbell/) **shows basically is not only is there no compelling evidence for effects, but there’s reasonably compelling evidence that given the methods we’ve used today, the effects are either zero or trivial**

- David thinks that’s really important because he hears tremendous defensiveness now among people who are not practitioners of pharmaceuticals or favorable toward pharmaceuticals so much, because of the great success of some of the drugs
  - Especially the GLP-1 agonist related drugs
- In the same way as in the mid-90s, he heard tremendous defensiveness from the behavioral psychology community and others about genetics
  - Because they weren’t going to do genetics, and the [Rudy Leibels](https://www.neurosciencephd.columbia.edu/content/rudolph-l-leibel-md) of the world and the [Claude Bouchards](https://www.pbrc.edu/research-and-faculty/faculty/bouchard-claude-phd.aspx) of the world were talking it up and it was going to be big
  - And they were starting to feel threatened, and often didn’t know much genetics, but would try to somehow minimize the role
- There’s a lot of **fear now among people who want community intervention**, public health intervention, who say, “*I don’t want our solution to obesity be let everybody get obese, or let 2/3’s of the population get obese, and then we’ll give them surgery or drugs for the rest of their life. It’s too expensive, it’s not my ethos, etc.*”
- They’re worried that people like David who say, “*Look at the efficacy data, we need to think about this more,*” are implying that we should shut down all the other stuff
- For David, that’s absolutely not true

## Rethinking obesity solutions: the need for a paradigm shift [32:45]

**We need sub paradigm shifts within paradigms**

- By this, David doesn’t think the paradigm shift of saying, “*Don’t think about nutrition anymore, only think about drugs and surgery*,” is warranted
  - Nor is the paradigm shift of saying, “*Don’t ever think about public health or policy*.”
  - He doesn’t agree with those at all
- What we need within the paradigms of behavior, community, family, policy
- Let’s be honest, let’s look at [Carolyn Summerbell’s](https://www.durham.ac.uk/staff/carolyn-summerbell/) data, and others, and say there is no compelling evidence that any of this has had a meaningful impact
- You can cherry-pick here and there, you can say this policy led to differences in how much of that food was purchased in this context
  - Even if that’s true, did it lower obesity rates?
  - And those have never been shown

*How do we do that?*

- Peter agrees, and his personal bias is that so many of these public health ideas on the surface just make a ton of sense
- He can simultaneously hold true the following truths: on the one hand, he can see why it was logical in the early to mid-90s to say, “*We have to change the food environment*”
  - [Richard Thaler’s](https://www.chicagobooth.edu/faculty/directory/t/richard-h-thaler) work (another Nobel Laureate) would suggest that that’s the answer
  - You make the default environment better and people will opt into good choices
    - Peter points out that the default environment used to allow people to eat in a way that was clearly ad libitum and obesity rates were not what they were
- So something about the **environment** 200 years ago, 100 years ago, or even 50 years ago was significantly different from the environment today
- It’s not that our **genes** changed
  - Nobody would argue there’s been such a genetic drift that the reason that obesity rates are 2/3’s as opposed to 10% is due to a change in our species
- An environmental trigger or set of triggers seems more likely, and therefore public health solutions towards those seem very logical
- And then we have to be brutally honest with the assessment, which is this has been an abject failure
  - If at the end of the day you’re only measuring the outcome of interest, it hasn’t changed

**How do we know after 30 years and billions of dollars with no effect, that we should stay within the paradigm of public health solutions and just abandon all of the ones we have when we don’t really have a sense of why they failed?**

- David replies, “*We definitely don’t want to only rely on public health solutions. I would strongly oppose that.*”
- He agrees that there is a superficial sensibility to the public health arguments that were made for the various things tried and it was reasonable to try them
- But he says “superficial sensible” because everything that’s true makes sense (once we understand it)
  - If we’re wrong about something, then it didn’t make sense, we just didn’t understand that it didn’t make sense at the time
  - Some of that is assumptions, and it goes back to that public health thing
- David had a wonderful lunch with the most generous, interesting person, [Daniel Kahneman](https://en.wikipedia.org/wiki/Daniel_Kahneman), who won the Nobel Prize, who recently passed away
  - He and his wife were gracious enough to allow David and [Michelle Cardel](https://www.weightwatchers.com/us/science-center/team/michelle-cardel) to take them to lunch
    - Michelle was a former student with the group David led, and now works at [WW](https://www.weightwatchers.com/us/)
  - They talked about obesity a little bit, and Daniel’s this great behavioral economist
  - Daniel says, “*Well, I think this nudge stuff is really good. So you could put things on the menu and that would make people eat less*.”
  - David replied, “*Well, that’s a good idea. And some things like that are being tried and have been tried, but the big thing is compensation. Yes, you can get a person to eat a little less in this context, but then if they go home for dinner and they just eat more at dinner, it goes away*.”
  - And he looks at David without artifice and says, “*Hold it a second. So you’re telling me that there might be mechanisms in people that lead them to adjust for previous behavior?*”
    - Reduced calories
  - David answered, “*Yeah*”
  - Daniel sais, “*You’ve opened my eyes*”
    - As an economist, he didn’t think about this; he doesn’t understand physiology

> “*I think that was a big part of a lot of things [that] didn’t make sense because they didn’t take into account compensation and many other factors. They didn’t take into account magnitude of effect and so forth.*”‒ David Allison

**The second thing is the data themselves**

- People published a nice thing about a meta-analysis of nudge type stuff in PNAS a couple of years ago
- Someone else just went in and redid it and said, if you adjust for publication bias, it doesn’t look like there’s much holding up there
- So often we’re presented with evidence, with statements as though we confidently know these, and yet when you really start to open the hood and peel things back, you say, “*Hey, there’s not a lot of there there on the data.*”
  - We may want to come back to this when we talk about some other things like especially protein intake

***The data that nudge works is actually shaky ‒ that’s the second problem***

**The third is we seem to be unwilling to learn from the outcomes of our studies**

- We’re unwilling to say, “*We tried the school-based thing and it didn’t get a big effect. We tried it again. Fair enough, let’s try second. Let’s try it a third time.*”
- At a certain point when you say enough
- David has been saying this for 20 years
- If someone were to come to him and say, “*We’ve got this opportunity to invest in these big school-based, community-based public health oriented trials to reduce obesity levels in children or adults, and we have the money available, we want to do good, should we do it?*”
  - He would say, “*Show me how this proposed idea is radically different than what’s been done for the last 30 years, and then let’s talk. And if it’s not radically different, why are we wasting our time and money on that?*”

> “*I think we really need a radically different public health paradigm.*”‒ David Allison

- We need to stay in the public health paradigm, but within the paradigm, we need a sub-paradigm shift to say nutrition education, modest physical activity, build a little bit of a facility to allow people a little more activity: ***These have been tried, they don’t work***
  - They don’t have big meaningful effects

***Let’s try something completely different, radically different proposals***

**If you were Czar of the universe and the ultimate resource allocator, what percentage of resources would you put into a new and different form of public health (i.e., radically different approaches), and what percent would you put into medical treatments such as surgery and drugs?**

- A little more in the near term on the clinical treatment because David thinks we can make more rapid gains in that, while we need some slower, longer term assessment of the others
- He would also amp up the non-pharmaceutical, non-clinical, non-surgery a little bit
  - A lot funding for those other things will come from industry and a little bit from the government
    - If you look at a budget of a Pfizer or a Lilly or a Novo Nordisk and what they put towards certain areas, and then you look at what NIH can put toward those areas, we’re not talking about NIH being this overwhelming big dog

## Understanding environmental triggers and embracing a balanced approach to addressing obesity that includes both pharmacological treatments and realistic lifestyle changes [41:45]

Peter states that there’s still something here that just philosophically doesn’t sit well with him

- NHANES is now reported annually
- It seems likely that very soon (if not already) we’re going to see, for the first time in 5 decades, obesity rates going down
- The reason that Peter is still a little troubled from a public health perspective is we don’t have the answer to the question, “*What were the environmental triggers [of obesity]?*”
  - We think we know the answer, but every time we try an intervention against those things, it doesn’t work, which makes us call into question what the answer is
- Clearly we did not get obese because of a GLP-1 shortage that is now being ameliorated with GLP-1 drugs
- So clearly we have something that was causing the problem
- Again, multifaceted, likely, and then you have a totally different hack to work around the problem, which is why David is saying we need to do both of these things

**Speculate what it is about the world in the early part of the 21st century that makes obesity and type 2 diabetes a problem that it wasn’t 50 years ago**

- In 50 years there has been a log-fold difference in type 2 diabetes (that’s hard to imagine)
- David think’s there multiple closely related factors
- 1 – The food supply and its availability
- 2 – Lagged intergenerational effects
  - David thinks we have seen genetic changes (both genetic and epigenetic)
  - David has more direct knowledge and confidence on the genetic as opposed to the epigenetic changes
  - This is assortative mating, differential mating

*Do these fully account for the obesity epidemic?*

- No, of course not
- Is David trying to say that they are the biggest influences? No, of course not
- But he does think it’s important to push back and say these are factors and they come in through migration, through differential fertility, and through assortative mating
- David has [written papers](https://pubmed.ncbi.nlm.nih.gov/29980761/) about all these, and as have others
- If you look in things like [Framingham](https://www.nhlbi.nih.gov/science/framingham-heart-study-fhs), you see that people in certain BMI ranges have more children than people in other BMI ranges
  - We’re not asking about how good you are in theory at producing offspring, we’re asking how many offspring you produce
  - And so if richer, thinner people use more birth control and have fewer offspring and there’s some genes for thinness, you’re going to reduce their prevalence and vice versa

***Obesity is influenced genetically through migration, differential fertility, and assortative mating***

- Assortative mating doesn’t change allele frequencies, but changes gene frequencies, which you get like mates with like

*These influences strike Peter as somewhat marginal*

*What David thinks is largely responsible for the increase in obesity and type 2 diabetes*

- 1 – Largely (but not exclusively) is the increased availability of a greater variety of highly palatable foods
  - Foods that are relatively modest in cost, easy to acquire
- 2 – Also, the control of ambient temperature makes it easier to overeat foods
  - You don’t want to overeat a lot if there’s no air conditioning and you live in Austin, Texas and it’s 110 degrees out
- 3 – There’s some intergenerational lagged effects that we don’t fully understand
- If you look at the Danish data, [Thorkild Sørensen](https://publichealth.ku.dk/staff/?pure=en/persons/40607) and others have [written](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1600-0463.2001.tb05763.x) about this: for over a hundred years, every 18-year-old healthy male into the Danish army, and they have not only heights and weights of each one naked, kind of weirdly, they have photographs of each of them naked
  - What you see in these BMI levels is you’ll see a period where it’s flat for a little bit, then you’ll see a steep increase, and then it’ll flatten out again a little bit, and then you’ll see a steep slope
    - This has happened in 3 or more cycles
    - David doesn’t think anybody exactly understands why
- [Diana Thomas’s](https://www.westpoint.edu/mathematical-sciences/profile/diana_thomas) mathematical model predicts some of that
  - She’s a professor at West Point who studies obesity

***This suggests to David that culturally or behaviorally there could be some lags, whereby the weight of your parents or grandparents is affecting you***

- Both socially and genetically
- The oocyte that formed you was formed in your grandmother
  - So potentially through epigenetic things, that could be affecting you
- A cultural example: when David was a kid and they went out to dinner, if he wanted to order shrimp, he would have to ask his dad (because shrimp was expensive)
  - He could order chicken parm without asking
  - The weren’t rich or poor; they were lower middle class, creeping up
  - You can get shrimp by the bucket now at the local buffet for next to nothing, so David is prepared to eat a lot more shrimp than his Dad ever would’ve thought of because of changing economic times and so on
- David’s kids think nothing about ordering dinner in from DoorDash every night, where he still thinks that’s excessive, too indulgent (even though he can afford it)

***There may be levels at which one ratchets culturally, as well as physiologically or anatomically, and all of these things can be in play***

**David speculates that we need to change some of the attitudes**

- He has no proof this is true

*One of the bad things that the nutrition field has done (including the public health community) is talk about healthy foods that have magical effects*

- For example, the low-carb advocates and zealots who came up through the late ‘90s
- There’s the sense that there is a “right way” to eat, and if you just ate that right way, then you would maintain the weight you want or fat level you want without ever feeling lack of satiety or dissatisfaction

> “*Nobody agrees on what the right way is, but there is an underlying supposition that there is a right way to eat.*”‒ David Allison

*Peter points out that is philosophically not that different from a drug approach*

- If constructed a lot of parallel universes, and you put everyone on a diet of X, Y, and Z you would eradicate obesity
  - On one of those planets you could put everybody on [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide)
  - So you now have multiple different dietary treatments, when perfectly adhered to, that will dramatically improve obesity
    - One of those will be just a drug, maybe two of them will be a drug, another one will be a gastric bypass, etc.

***It still doesn’t answer the question, what triggered the problem?***

- Peter doesn’t know if they want to spend much more time on that because these are unanswerable questions
- What is the right diet to fix it?
  - Doesn’t that mean that the absence of that diet is what caused it?

***David agrees; the point he was trying to make is that by saying to people there is a right way to eat, we may foster a delusion***

- That is the real debate perhaps is not between the low-carb guy and the non-low-carb guy as to what this thing is, or the eat locally or whatever
- The real debate may be, is there a right way to eat, compositionally, or behaviorally, time of day or something, that will satisfy you, not make you feel deprived in the real world we live in (not in a parallel universe we could construct)?
- And the answer may be no
- And yet by continuing to sell that idea, we may continue to have people searching in the wrong spot

**Instead of searching for “*****How do I control, or overcome, my incomplete satisfaction with eating only this amount?*****” they’re looking for “*****What’s the way to eat that I don’t have that dissatisfaction?*****”**

- We may have to accept at some point for most of us (there are exceptions), to maintain a truly thin or lean body composition, we may have to accept that either we’re going to have to alter our desires in part through pharmaceuticals, or we’re going to have to accept that we don’t get to meet all our desires at times
  - As opposed to continue what may be the charade that there is a way that you can just eat a certain kind of food or certain type of diet or eat in a certain way that will lead you not to ever feel dissatisfied
  - If being thin or lean body composition is what we want, and David’s not saying everybody should want it, but for those who do want it
  - He thinks that’s an important stoic approach

## The need for higher standards in obesity research [51:45]

- David makes the point that we need to increase the quality of the evidence and the standards we hold
- We spend too much of our research budget on lousy evidence
- So in the childhood obesity field: David’s group, for example, often will write letters to the editor
- Another paper was retracted last week because they found **statistical errors** in it
  - And if you think about it, this is a randomized controlled trial of a treatment for obesity related or nutrition
  - They find this in diet, behavior, etc.; but usually not drugs
- If you think about a randomized controlled trial, at the low end, a randomized controlled trial is usually over $100,000 to conduct
  - At the high end, it’s tens of millions
- The ones David is looking at that often they find these mistakes in (and many cases are retracted, especially in childhood obesity) are probably in the multiple hundreds of thousands of dollars, occasionally millions
  - Then you think that’s all wasted, if they analyzed and misreported the data and got the wrong answer
  - David feels like they’re rescuing those dollars in some sense by getting the wrong answers out and the right answers in; it’s an important service

***The field needs to focus more strongly on doing research that questions, that answers questions well, that honestly reports the data***

**Do you think that problem is disproportionately present in the field of obesity research, or do you feel it’s both acknowledged and demonstrated at the same frequency in all fields of medicine?**

*Do you feel we have a brighter spotlight on it here thanks to certain individuals?*

- All of the above
- What we know is that there are many anecdotal statements by leading thinkers, like [Stuart Ritchie](https://en.wikipedia.org/wiki/Stuart_J._Ritchie) as just one example, [Gary Taubes](https://garytaubes.com/) (their mutual friend) who says nutrition is singularly bad
- And there are some of these are wonderfully colorful statements
  - [Johnny Ioannidis](https://profiles.stanford.edu/john-ioannidis) said, “*We need to accept that nutrition epidemiology is a dead science and bury the corpse.*”
  - Those are opinions; those are not bits of data

*The more distressing problem of science done incorrectly is the confusion it sows and the noise it creates*

- This is what the [Pew Charitable Trusts have shown](https://www.pewresearch.org/science/2019/08/02/americans-trust-dietitians-more-than-nutrition-researchers-but-are-skeptical-of-both-groups-transparency-accountability/) in surveys of representative samples of American population, people trust nutrition experts, clinicians, purveyors of knowledge, more than they trust nutrition scientists
  - And they trust nutrition science less than they trust other forms of science. So that’s a fact

> “*We do have a trust problem in nutrition science.*”‒ David Allison

*Is the research in nutrition science really better or worse [than other fields of science]?*

- It’s hard to pin that one down
- There’s not enough concrete strong comparisons to other areas
- David is trying to start some in his group
- There was a recent paper that came out in in an economic journal looking at reproducibility
  - It’s not a one-to-one comparison
- Reproducibility and replicability are not quite the same
- **Reproducibility is**: can I get your original data, run exactly the same analysis you said you ran, and get exactly the same result?
  - If I can, I’ve reproduced your research
  - Doesn’t mean your result was right, maybe you ran the wrong analysis, but at least I could do what you said you did
- We do that in nutrition and obesity and we find: what seems to be not infrequent errors, irreproducibility, or what we call verification problem
  - We don’t have exact numbers; it’s not a random sample of papers
  - **Verification problem** meaning we could reproduce your result, but it was wrong
    - It was wrong because you ran the wrong analysis
    - We run the right analysis, get a different conclusion

Peter asks, “*And you might do how many of these a year?*”

- More than a dozen, and maybe half turn out to be not reproducible or not verifiable

Peter asks, “*What’s the criteria upon which you select besides size of study?*”

- It’s usually 1 of 2 things: interestingness or something doesn’t look quite right (and they take a closer look)
- Peter would be curious when David has enough data to know if you take out the studies that look fishy, what percentage of the studies come up unverifiable
- David agrees, he should do this, and he hopes there’s a funder out there listing who will want to fund it
  - NIH may not always be so keen on having them answer this question
- David does spot checks in the area, and his sense is even within obesity [there’s a problem]
  - If you look at pharmaceutically done randomized controlled trials where their environment is a very strong regulatory authority
    - The FDA holds their feet to the fire

Peter asks, “*Do you think that’s the reason that drug studies tend to be very rarely found to require retraction?*”

- In modern times, yes

***And if somebody asked him if he trusts randomized controlled trials coming out of the pharmaceutical industry more or less than academia: infinitely more from the pharmaceutical industry***

**Differences between pharmaceutical and academic research**

- Peter agrees, but thinks it’s not intuitive to the average person listening
- The average person may think that data coming out of Pfizer is less trustworthy than the data coming out of Harvard
- But the key point is that Pfizer has to answer to somebody
  - The FDA will bring down a much greater and swifter punishment if issues are discovered in methodology, statistical analysis, reporting, etc.
- Whereas the academic community doesn’t have that degree of policing
- And the funding
  - People often say that industry is much more efficient than academia
    - But this depends on what you put in your denominator of efficiency
    - If you say output per unit time, no question; industry in general and pharma in particular blow academia away
    - But if you say output per unit dollar, academia probably blows industry away; they’re working on a shoestring budget, but that often means not much rigor
- The big pharma company who’s going to put their registration trial in is checking and double checking and having professionals check and so on

**Explain to folks that when people talk about a “Pfizer study” or a “J&J study,” they’re hiring** [**CROs**](https://en.wikipedia.org/wiki/Contract_research_organization) **to actually do the study**

- Sometimes people are under the impression that when Lilly is doing a study on a drug, it’s like the whole Lilly team doing the experiment
  - As opposed to Lilly providing the agent, helping think about the experiment, but basically having a clinical research organization (CRO) actually do it and having independent folks do the analysis
- That doesn’t mean there’s no bias
  - David hates to use the word bias because it’s not clear, but he doesn’t have a better word so he uses it hesitantly
  - Bias is often in question
- Peter adds, “*It’s how the question is asked which determines how the study is designed to look for a particular answer for sure.*”
- For example, an industry group might compare a new drug to the worst old drug in class
  - Whereas if a university guy did it, they might compare it to the best drug out there
- But once pharma has decided on the question, the design, execution, and reporting of the study seem to be enormously more rigorous
- If you’re talking about the dietary supplement industry, that’s a different game with a more complex answer

***David’s main point is that we need better data***

- We need to assess this

**Problems with non-industry-funded data**

- The non-industry-funded stuff typically includes the public health, the school-based stuff, the child obesity trials
- Their data is going to vary a lot
- The cluster randomized, community, school-based, childhood obesity trials tend to be quite poor

***The non-verifiability rate is very high***

- Whereas if you went to certain other kinds of trials, the NIH-funded clinical management of obesity trials will tend to be better

***So it’s going to vary a lot***

- David hopes he’s not biased, but he’s sure some of them will think he is
- He **discloses** that he has funding from all these groups:
  - Most of  his funding is government and NIH
  - He does have industry funding as does the school he leads, and this includes many of the pharmaceutical companies that think about clinical trial, design,a dn biostatistics
  - They’re funded from food industry at times, commodity groups

## The rapid success of GLP-1 receptor agonists for weight loss: a discussion on the societal impact and controversy of their growing usage [1:02:15]

- Currently obesity treatment is seeing a success it’s never seen before, and in a relatively short period of time
- 3 years ago, very few people knew what [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) (or Ozempic, which is the trade name given to the diabetes version of that drug)
  - Today, most people recognize it or some of its derivatives
- It’s worth noting that these are not new drugs
- [Tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide) is one of the newer drugs
- [Liraglutide](https://en.wikipedia.org/wiki/Liraglutide) and others have been around for at least a decade, and they’ve successfully treated people with type 2 diabetes
- People noticed it wasn’t just improving their diabetes, they were also losing weight; and that led to what became a set of dedicated experiments to test the efficacy of these drugs in non-diabetic, obese patients
  - And the rest is history

**Talk a little bit about what you think is socially and psychologically happening at the moment. Why are people so interested in this drug?**

- People are interested for the obvious reason: lots of people want to lose weight, and lot of people want to help other people lose weight
- For the first time in history, we have drugs that are now powerfully effective and appear to be reasonably safe
  - We’ve had drugs that were powerfully effective before but would kill you
  - And we’ve had drugs that were reasonably safe before, but at best modestly efficacious
- Safety is a social judgment, not a factual determination
  - Risk is a factual determination

*Safety is a social judgment, and so it invites all kinds of interesting speculations about cause*

- What is the role of GLP-1 in causing obesity?
- And is there a role?
- Just because things involving GLP-1 treat it, doesn’t mean it’s involved in the cause
- What’s the effect on stigma?
  - If we can treat it, does that reduce stigma in the same way that Viagra changed many things around erectile dysfunction
  - Interestingly, David didn’t predict the full cultural impact of that, which shows you it’s hard to predict these things
- People didn’t predict what Viagra was for (it was being used for something else, and they noticed erections as a side effect and then they started working on it)
  - In the early 90s when David visited one of his buddies who’s a biostatistician at Pfizer, and they told him they were working on this new thing and explained what it was, David laughed and said, “*What are you wasting your time on something so ridiculous and unimportant? Why don’t you do some important research?*”
    - Shows you what he knows

***Here we’re learning that again we get surprised in science, we’re seeing a moral panic***

- This is subjective on David’s part, but it is something he’s noticing

**Moralistic judgment around using these drugs to treat obesity**

- A lot of old arguments that had gone semi-dormant, at least in the academic community over the years of, “*Well, if you give people a drug for obesity, [it] doesn’t teach them anything and therefore when you stop the drug, the weight just comes back*.”
  - This was said as a criticism as opposed to saying, “*Well, who said it had to teach them anything? Who said that was the goal?*”
- For many drugs, you’re going to take those for the rest of your life (if you are in the right class for that): anti-seizure medications (if you have seizures), antihypertensives, anti-diabetes drugs, etc.
  - We don’t say, “*But the person with schizophrenia shouldn’t get the drug because if we stop giving it to them, the schizophrenia symptoms come back say.*”
    - No, schizophrenia is a serious disease, we need to give it to them
- With obesity, this has come up again
- It seemed to be put down a few years back but now David is hearing it again, this kind of moralistic judgment about that
- He’s also hearing the moralistic judgments come about motivation
  - It’s okay if you’re motivated for health
  - It’s not okay to get the drug if you’re motivated for something other than health
    - Which implies that assuming we have the same health issues, assuming the person would equally benefit from their health, we make a moral judgment about your motivation
- There is no evidence that people who are motivated for health to lose weight do better than people who are motivated for cosmetic or any ego business, any other reasons

***We need to get over some of that moral panic; the safety, the cost and the availability issues are big issues***

**David is defining safety in the sense that sometimes the FDA defines it: risk**

- Risk involves uncertainty as opposed to being risk involving known factor
- Not the probability that you get “this,” but the fact that we don’t know what happens if you take it for 40 years
  - For the safety issue, there are some open questions: no one has taken it for 40 years

**Right now, these drugs are very expensive**

- Our country is divided on how healthcare should be paid for
- There are a lot of different opinions, and there’s an availability problem

**Say a little more about the availability problem**

- Compounding pharmacies are now making semaglutide and tirzepatide
  - When Peter first saw this, he couldn’t understand how they could legally make an existing FDA-approved drug
    - That’s not within the statute of what a compounding pharmacy can do; they have to make a variation of that drug
    - For example, they have to change the delivery mechanism (make something topical that would only be available orally or something of that nature)
  - One of the exceptions to that rule is if the FDA-approved drug can’t be produced in sufficient quantities, then a compounding pharmacy can create the exact same drug that is available through the FDA label
    - Presumably that is happening

*Do we have a sense of why that is happening? What is them manufacturing bottleneck?*

*Secondly, do you have any insight into whether the quality control at the compounding pharmacy level matches that of Lilly or Novo Nordisk?*

- David doesn’t know why there is an availability problem, he doesn’t know the technical mechanics of it
- His understanding is that the technical process by which these drugs are produced is different than some other drugs
  - And the technical process is a slow one
  - So until they ramp up more and more production sites, they just can’t do it fast enough
  - But they are ramping up more and more production sites
- Novo just bought Catalent, which happens to have a plant in David’s backyard in Bloomington Indiana
- So we’ll probably see more of that ramping up
- About the compounding pharmacies: when David first heard about it, he too was skeptical
  - He’s far from an expert in compounding pharmacies or the legal aspects
- He started to hear a lot of reports about this, described as though it was a very shady endeavor
  - Again, that moralizing came in
- He has talked to some other people who are experts in it and who are using these
  - Admittedly, this is their business, so they have a motivation
  - They say, “*For this compounding pharmacy that I use, we use it in this way, this degree of quality control.*”
    - David is not an expert, but it sounds like very rigorous quality control
- He doesn’t think we should be dismissive of the concerns around compounding pharmacies, but he also don’t think we want to paint everybody with the same brush

***The question becomes as with anything is, “Show me your data. Show me your evidence on your quality control, your procedures?” And if they’re good, they’re good, then let’s use them. Let’s get over the moral panic.***

## The ethical and practical considerations of obesity drugs: risks, benefits, and motivations for usage [1:11:30]

- David brought up an interesting distinction: a person who is medically obese and metabolically unhealthy versus another person who’s overweight but doesn’t have any metabolic signs of being overweight
- Both of these people have a desire to lose weight
  - One of them to primarily ameliorate the medical conditions and also the aesthetic conditions and then the latter person just for the aesthetic conversions

***Society might make a different moral judgment on those two***

**Are you arguing that’s a false dichotomy?**

- It’s a legitimate dichotomy to see those situations as distinct situations, but not necessarily implying distinct recommendations coming from those
- Let’s refine it to a 2 by 2 [shown below]
  - 4 individuals come to you, and we’re going to say that you’re the objective all-knowing agent to determine their state of being
  - Half of the people are objectively at medical physical risk because of obesity and would be objectively medically helped by losing weight on this drug [groups 1 & 3]
  - Half of the people are not at objectively medical increased risk and would not be predicted to have a medical, major medical benefit [groups 2 & 4]
  - Within each of those groups, half of them think they have a medical problem (regardless of whether you objectively determined they do) and think they would benefit [groups 1 & 2]
    - And half of them aren’t interested in that; they want to do it for other reasons: cosmetic, income, stigma reduction, quality of life [groups 3 & 4]

![](https://peterattiamd.com/wp-content/uploads/2024/08/f1-davidallison2.png)

**Figure 1. A 2 by 2 of medical risk due to obesity and reasons for pursuing treatment, identifying 4 groups**

*The question is how should those four groups be treated?*

- It seems obvious that if we’re concerned about expense (and the expense borne by society, not the individual coming), or if there’s shortages and we’re going to take it away from someone who’s genuinely medically needed, then ***going to the non-medically needy people is questionable***
- But if we get over those problems and the person can afford to pay for it themselves, it is available, and we think there’s no big safety problem (or even if there is some safety problem, but we’ve told them and they’ve consented) ‒  take the libertarian view, ***it’s their choice***

**One of the big statements that got some news was a very reputable entity who has an interest in actually promoting this**

- This a major player in mainstream medicine
- A sort of 3-step statement was made
  - 1 – Step one is the drugs were intended and designed and studied for the treatment of medically needy people
  - 2 – The drugs were proved for that use
  - 3 – Therefore they should only be used for that

***And the third part is a moral judgment, not a factual judgment***

- Peter adds, “*The first and the second are true, and what they really tell you is therefore the cost benefit analysis has to be viewed through the lens of that patient population.*”
  - In other words, when you ask the question about risk and benefit, you have to at least acknowledge that the long-term risk, long-term benefit are studied in that population
  - This is what the data are, these are the risks, these are the benefits; make your judgment
- Conversely, if you ask the question,for a person who is subjectively 10 pounds overweight, should they be taking this drug
  - Peter could argue that this is him

**David’s analogy**

- A wealthy patient comes to Peter, they’re in good physical health and have all the material things they need
  - They have a family, family loves them, they don’t engage in violence
- Tsay, “*I feel miserable. I’m anxious all the time, or I’m depressed all the time.*”
- You might try a few things, explore it, but assuming you’ve explored it; it’s real
  - Maybe you tried some cognitive behavioral therapy; it didn’t seem to work
- You might recommend an anti-anxiety drug (FDA approves those things)
- We take the person’s quality of life and their feelings into account
- Why is it that the person who says, “*I feel too fat and I want to be 10 pounds thinner and look good in my bathing suit*,” or “*I want to get this job as the leading actor in that film*,” or “I *want a promotion in my environment and I think I’m more likely to get it if I’m thinner*” or “*I’m hungry all the time and I don’t plan to lose weight, I just want to stop being hungry all the time*.”

***Why are that person’s feelings or non-medical desires any less valid than the person with depression or for that matter, the person with an unusual but not health damaging physical feature, an unusual nose or something who says, “I just feel like I’d be judged better.”***

- Peter doesn’t think it is
- As the backstop to that is when the person who doesn’t like their nose goes to the ENT surgeon or the plastic surgeon to have the completely non-essential but emotionally beneficial procedure, if they’re seeing a good surgeon, the surgeon can tell them with unambiguous clarity what the probability of negative outcomes is
- He thinks the same is true in the case David described at the outset about the individual with depression or anxiety
  - A very good physician can explain to them what the **risks** are
  - Very few physicians would give you a medication for anxiety or depression without also prescribing in parallel with psychotherapy
    - The data are pretty clear that medication by itself is nowhere near as effective as medication coupled with psychotherapy

***So you have two things going for you that make this analogy not apples to apples, which is in the case of depression, we can say much more about the long-term side effects and we are combining it with a behavioral therapy that aims to improve the efficacy***

- Peter is not suggesting that the person who wants to lose 10 pounds doesn’t have a legitimate concern

**Peter’s concern is we don’t know enough about the long-term risk to tell them for their relatively minor health compromise, is it potentially worth the trade-off**

- We could probably say that with a higher degree of certainty for the individual with significant obesity
  - Because even if we would kind of have a small bracket of understanding the downside potentially of the drug, we really know the downside of having a BMI of 40
    - Being insulin resistant, having type 2 diabetes (these are clear downsides)

***For Peter, it’s not a moral question when he is confronted with this question (which he is all the time)***

- Every week or 2, he has a patient who fits this description, which is, “I*’d love for this to be easier.*”
- There’s nothing wrong with that

***Peter hopes we can get to a point where we could give them the same degree of clarity around risk that the plastic surgeon can give the patient who wants to undergo a rhinoplasty***

- David agrees and thinks the moral questions come in around how do you conceive of the role of FDA society physicians in regulating choices?

*This is why Peter is not taking one of these drugs*

- He would love to be 10 lbs lighter
- He would love to never be hungry
- These drugs improve glycemic control,a dn all the things they do are appealing
- For someone who is quite a risk-taker, he is not taking these drugs

**Peter’s clinical experience with GLP-1 agonists**

- He’s watched countless patients take these drugs and without exception, their **resting heart rate** overnight goes up about 10 beats per minute
- Their heart rate variability goes down slightly
  - [Peter discussed heart rate variability in [episode #305](https://peterattiamd.com/joeljamieson/)]
- That has him asking the question, “*For me personally, is it worth the trade-off?*”
  - Is there some underlying sympathetic/ parasympathetic imbalance that results from this drug that is doing a whole bunch of other good things vis-à-vis appetite potentially
  - “*Over the arc of my life, is it worth it?*”
- Maybe if he were 40 pounds overweight and it was medically a problem, he’d say, “*Oh, I’ll take the heart rate bump any day of the week*.”
- Informationally and in terms of the morality of the honest communication, David agrees 100%
- Informationally, we have a fair bit of data that allowed FDA to make its decisions on the use of these drugs for particular indications in patients who are judged to be “medically needy” of those drugs
  - We don’t have a lot of data on the person who’s thin, but who says, “*I just want it to be easier,*” or, “*I’d like to be 10 pounds thinner.*”
- Any treatment or provision of something to people without a full disclosure of what you know, and an honest disclosure is not right
  - At a bare minimum, the physician should say, “*I want you to be aware that I have no data on this over many decades. We only have a few years.  I want you to be aware that it was only tested thoroughly in these populations, which is not your population. And you need to know that there are, as* [*Rumsfeld*](https://en.wikipedia.org/wiki/Donald_Rumsfeld) *famously said, ‘The unknown unknowns.’*”
- There’s an issue of choice
  - There are lots of things that our society permits, but David personally wouldn’t want to do them
    - Think of freedom of speech
    - It’s perfectly acceptable and necessary that we allow certain people to come out publicly and make certain statements
    - But David is not sure he wants to make all those statements

***It comes down to this sense of after we have the inputs, we should be able agree on the facts***

- Then what we do with those facts
- We can disagree because we have different values
  - How much of this is paternalistic?
    - The FDA is very paternalistic; they’re going to decide which drugs are good for whom
  - Or how much are you a libertarian where you say, “*We’ll tell you about the effects to the extent we can of this drug or this treatment,*” but how good it is, whether you should do it, whether you want to do it implies values and you make that decision as long as it’s a fully informed decision
  - And those are different views of how we should proceed

## The use of GLP-1 agonists by athletes as performance enhancers [1:23:45]

- Hypothetically, for the sake of the next question, David is now in charge of both [WADA (World Anti-Doping)](https://en.wikipedia.org/wiki/World_Anti-Doping_Agency) and [USADA (US Anti-Doping)](https://en.wikipedia.org/wiki/United_States_Anti-Doping_Agency)
- You have an obvious and clear hard line against drugs that improve performance
  - An athlete cannot take testosterone or growth hormone or EPO or anything that boosts performance
- Now, if you think about it, a lot of sports have their performance improved when the athlete is lighter
- Weight management is a big part of many sports: cyclists, runners, gymnasts, rowers, any sport that is cardiac output versus body weight

**Should these drugs be banned by WADA and USADA? Are they indeed performance enhancing drugs?**

- Great question, David hadn’t thought of this before
- It introduces a whole different set of interests
- Prior, we were talking mainly about the individual persons taking the drug’s interest and a little bit about the provider’s interest, a little bit about society cost, FDA, so on
- Here you’ve introduced a 4th party and that party is the sport: all the spectators, the people who own it, the other participants
  - The sport has rules
  - Sport is very different than some other things where there’s an arbitrariness to it
    - Why does the baseball bat have to be this long and not that long?
    - Why does the tennis racket have to be within these dimensions?
    - Peter agrees, that part’s arbitrary, but what’s not arbitrary is we want it to be equal and fair
- But we change rules about intrinsic things
  - In some places, we don’t conditional age, while in others we have age brackets
  - Some boxing and wrestling, we have weight brackets
  - We don’t have height brackets in basketball
- David and some of his colleagues are trying to write a paper on **mathematically, what is bias**, what do we mean by that?

*They use basketball as an analogy to understand bias*

- David uses himself as the example to say he doesn’t do well for the basketball team because he’s short
  - He doesn’t call that bias because intrinsic to the idea of basketball is these are the rules: we don’t have springboards for shorter guys, we don’t have height classes
- In contrast, if you ask him to try out to be a biostatistics professor and the book is on the top shelf that you want him to lecture from and there’s no step stool, he would argue that’s biased
  - Because you could have put a step stool there and it’s not intrinsic to biostatistics professor performance to be able to reach tall things

***We need to look at the sport and say, “What do you want it to be?”***

- Somebody may say, “*I want it to be where part of the sport is being able to maintain your weight, and so I don’t want anybody to have a performance enhancing drug*.”
- David could alternatively turn around and say, “*We just want you to be able to get the basketball in the hoop,*” or “*We just want you to be able to row the boat. And if you do it by having more money and hiring a better coach, and you do it by taking Ozempic and you do it by having good genes, all is fair.*”

***David doesn’t think there’s a right answer form the sport point of view***

- Peter points out that the sport has already made several decisions
  - You can’t take a drug that increases the number of red blood cells that you have (that’s [EPO](https://en.wikipedia.org/wiki/Erythropoietin))
  - You can’t take a drug that increases the rate at which your muscles repair themselves after hard training (that would be testosterone)
  - You can’t take a drug like a diuretic that takes body weight away from you

***Peter thinks this is not a philosophical question about drugs; it’s a practical question about this class of drugs whose efficacy is profound and safety, at least in the short term is unquestionable***

Peter asks, “*Are we going to see at the Olympics this year in France, if they were drug testing for it, what fraction of athletes would be taking GLP-1 agonists (of the sports where body weight regulation is a key)? I don’t expect many shot putters to be taking it.*”

- Peter wonders how many boxers and rowers and runners and cyclists will be taking it
- David finds this fascinating and thinks they should do that study
  - He hasn’t heard about this before and thinks Peter’s speculation is apt
- As a formalist, he would ask about the underlying principles of these groups that say you can’t take testosterone and so on
  - They probably said, “*You cannot take a drug that enhances performance unless you have a medical need*.” (David doesn’t know)
  - But if they said that, it could get really tricky because **who defines the medical need**?
- Is it fair for the person who’s just below the threshold for needing the drug (who doesn’t get to take it)

> “*You have then also this idea of a fairness, a disabilities issue*.”‒ David Allison

**What about the person with obesity who has a strong genetic predisposition to it?**

- Who can’t manage to be not obese without the drug
- Is that effectively a disability ?
  - Is this now a violation of the [Americans with Disabilities Act](https://en.wikipedia.org/wiki/Americans_with_Disabilities_Act_of_1990) or something like that
- Is there a fairness issue?

***David don’t know that there’s a right answer; these would be tough political and moral questions, but it’s really particularly tough because you bring in the interest of the sport***

- It’s going to reflect back when you get into the health interest of the individual
- Just as with many sports, we might say it’s in the interest of the team or the coach or the sport itself to have this person at greater risk
  - But it’s not in the interest of their situation
- And yet we somehow accept that we allow people to play football even though there’s concussion risk, and we allow people to box and many other things

David asks, “*Are there some limits where we might say, ‘We’re not comfortable with your putting yourself at risk for this. We need to protect you as much as the sport.’?*”

## Unanswered questions about protein intake and health [1:30:45]

- [Protein](https://peterattiamd.com/category/nutritional-biochemistry/protein/) is a topic that Peter has addressed a number of times

**What do you think we know that we don’t know?**

- David points out that Peter is much more of an expert on the physiology and biochemistry of protein

*We know some very basic things*

- We know you can’t live without consuming some protein
- We know that the body is made not totally but heavily of proteins
  - They’re essential for functioning
- We know that proteins are made up of amino acids
- There are different amino acids that have different effects
  - Some amino acids can be synthesized in the body, some can’t be
  - David found the [podcast with Luc van Loon](https://peterattiamd.com/lucvanloon/) enormously educational, so he refers people to that one
    - He knows a lot more about protein
- We know that we need protein, we need a certain amount, we need certain amino acids, and we can get them from various foods or combinations
- We can pretty much get all the proteins we need from animal-based foods
- If we only eat plant-based foods, it’s not impossible with the exception of maybe [taurine](https://en.wikipedia.org/wiki/Taurine)
  - Whether we have to consume taurine or not is a question
    - If you’re a cat, you have to consume taurine
    - Peter adds, “*You could drink Red Bull and still eat plant-based protein, then you’re fine.*”

*Are there known things about the amino acids in terms of long-term human health?*

- We know a modest amount
- We see certain things about [leucine](https://en.wikipedia.org/wiki/Leucine) being important for skeletal muscle growth, anabolic effects
- We see some things about [isoleucine](https://en.wikipedia.org/wiki/Isoleucine) in mice maybe not producing longevity
- We see [taurine](https://en.wikipedia.org/wiki/Taurine) supplementation in mice and some other species appearing to prolong life in [Vijay Yadav’s](https://www.genetics.cuimc.columbia.edu/research-labs/karsenty-lab#:~:text=sends%20e%2Dmail)-,Vijay%20Yadav,-Assistant%20Professor%20of) work
- We see [methionine restriction](https://pubmed.ncbi.nlm.nih.gov/15924568/) in [Rich Miller’s](https://www.richmillerlab.com/biog) work prolonging life
  - [Methionine](https://en.wikipedia.org/wiki/Methionine) is related to taurine
  - It’s a lot of confusion

***What would really prolong life in humans is unclear***

> “*Whether the same things that will prolong or shorten life in terms of macronutrient composition in mice will do the same thing in humans is unclear. And there are different outcomes.*”‒ David Allison

- This is again part of why David railed against the idea of healthy foods so-called or unhealthy food so-called

*Healthy for what?*

- You might want to be 10 pounds thinner
- I might want to be able to lift 10 more pounds on the bench press
- That person wants to live 10 years longer
- The 3 diets for those things may be different

***After the idea the we need some minimal amount of protein, our knowledge gets shaky***

**Peter’s takeaway**: In other words, minimums and maximums were not necessarily a part of what you just described with much certainty

**Daily intake recommendations for protein**

- There’s reasonable confidence that the old school recommendations for protein intake are probably too low (0.8 g/kg)
  - Many people think that’s too low
  - You can survive, but can you thrive?
- That’s a big point in Peter’s book [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZYvVvMTwn080mPgXuOAjD_XK_KjTO3VwWMqP8Dhwyz6OXfIGzhW2lH6tjudB0KY76hzCg0ilDh2WKrtV3yaSBcf7X8WxSb6ltu7J0D1BQYH6d2Z6ZD9qcEqy4CsFBFiGPu_zkrV62x_lys_4NTr_mfwIoqnpafwN_akXJsDaK53DwBuwS-CP7mppw2a_lWAMGWfiHcBedMdMIDjnbwTnBGg.aDI-c_J_pUn_oUxPX8osAFoUW3ZBaseeRm97bTbhTMA&qid=1718806315&sr=8-1): ***we can think about treating diseases, we can think about preventing diseases, but neither of those are equivalent to optimizing our lives and our health***

*Different people have different ideas of optimal*

- Is optimal optimal comfort?
- Is it optimal length?
- Is it optimal ability?
- Whatever it is, it doesn’t seem that that’s the level, the RDA 0.8 g/kg is the optimal level for health or longevity or anything else (it’s probably somewhat higher)

*Next question is, are there minimal thresholds [of protein intake] at any sitting?*

- [Don Layman](https://fshn.illinois.edu/directory/dlayman) and others have argued there are
  - [Don Layman was a guest on [episode #244](https://peterattiamd.com/donlayman/)]
- Sometimes you hear 20 g, sometimes you hear 30 g as a minimum of protein in a particular setting to get anabolic
- As a statistician, when David hears this he is like, “*Really? Is that true?*”
  - A threshold in biology?
  - You’re telling me there’s a step function and you know it?
  - He doesn’t really believe there’s a step function, but maybe it’s [sigmoidal](https://en.wikipedia.org/wiki/Sigmoid_function)
    - Maybe it’s a little flat, and then it goes up steeply, and then it flattens out a little bit
- Then he wonders: How much sample size and how many different doses would you need to really get a fix on that and test whether it’s there?
- When he looks at studies done, his response is, “*You’ve got to be kidding me.*”
- They talked earlier about pharmaceutical company studies
  - Think about the numbers of people on which we tested COVID-19 vaccines
  - Think about the numbers of people we’ve tested statins and now GLP-1 agonists
  - Now think about the numbers of people used in randomized controlled trials from the nutrition community to look at protein needs
- Not all of us need to take a statin (a lot of us do)
- Not all of us need to take GLP-1 agonists

***All of us need protein, and yet the quality of evidence and the quantity of evidence we have is tiny***

- David explains, “*It’s dust compared to what we have on these pharmaceuticals. And so we really need to ramp this up. I would say I don’t think that we really know that you don’t get anabolic until you hit 20 or 30.*”
- Peter explains that those studies are small by necessity just based on funding and complexity of doing these studies
  - These are amino acid labeled tracer studies where they give people various doses of protein and they look at muscle protein synthesis
- He’s not here to say that we shouldn’t be doing bigger, better studies, but some of the studies that have been aimed at elucidating this are quite rigorous in terms of their mechanistic insights

Peter asks, “*The question is, isn’t it at least biologically plausible that there is a threshold?*”

- He agrees, it’s very unlikely a step function
  - It’s more likely a sigmoidal shaped curve
- But it seems biologically plausible that at low doses (10 g of amino acids), the liver might prioritize [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis) and there’s a saturation point where there is excess nitrogen and it will go and do this other thing [protein synthesis]
  - Plausibility doesn’t make it right; lots of plausible things turn out to be wrong

*This is why we need to do the studies*

- When David hears about what [Don Layman](https://fshn.illinois.edu/directory/dlayman), [Luc van Loon](https://www.maastrichtuniversity.nl/ljc-van-loon), and others have done ‒ it’s really impressive and rigorous

**But as a statistician who’s saying, “*****Do we know the answer?*****” David says, “*****Not really*****”**

- We’re also interested in long-term effects
- There’s an old saying, “*There is many a slip ’twixt between cut and lip. Drink and you spill*.”
  - You think it’s a done deal if I’ve got the cup and I’m moving it toward my mouth (I get the drink), but maybe not

***Tracer studies are important but they’re indirect. What we really want to know is if you do this for a year, are you stronger? Are you bigger? Etc.***

- David doesn’t think we really know that unequivocally

**David mentions Peter’s recent** [**discussion**](https://peterattiamd.com/protein-anabolic-responses/) **of a** [**study**](https://pubmed.ncbi.nlm.nih.gov/38118410/) **in which** [**Luc van Loon**](https://www.maastrichtuniversity.nl/ljc-van-loon) **was one of the authors that used up to 100 grams and looked at the other end of the threshold**

- Is there an asymptote?
- Is there a level in which you don’t get any more benefit?
  - Conventional wisdom was 40 g-ish was the ceiling
- The [study](https://pubmed.ncbi.nlm.nih.gov/38118410/) from Luc suggested that might be true for a very rapidly hydrolyzed protein such as whey, but maybe not with casein
  - Time release protein might be of value and meals like a steak might be closer to casein kinetics than whey kinetics
- David explains: We don’t know that there’s an upper limit
- We don’t know the full duration
  - Some people say you only stay anabolic for 2 hours after eating the protein
  - Luc’s study shows more

**What about the maximum amount of protein?**

- Traditional thinking here is 3 g/kg is the max, and if you consume more, you risk kidney damage

***Could excessive protein intake be harmful?***

- There is something that has been intriguing to David when he looks at this, and he hasn’t done a complete thorough check, but he’s in the process of working through it
- David hears that excessive protein intake could reduce bone mass, could lead to kidney function problems, some other unspecified problems
- There’s even this old thing called **“rabbit starvation,”** which you can find papers going back on this at least 100 years
  - They talk about hunters and survivalists and so on out in the woods who can shoot a lot of rabbits and eat their fill of rabbits and yet starve to death because they don’t have enough fat and carbohydrate to properly digest
- But if you go back and find the trials that showed this, a paper that says, “*Here are the limits.*”
- [Steve Heymsfield](https://www.pbrc.edu/research-and-faculty/faculty/Heymsfield-Steven-PhD.aspx) and [Sue Shapses](https://nutrition.rutgers.edu/faculty/sue-shapses.html) has just had a wonderful [nutrition 101 commentary](https://pubmed.ncbi.nlm.nih.gov/38598796/) in *New England Journal of Medicine*
  - They talk about some of the upper limits and they cite some papers
- We say, some bad things can happen if you eat too much protein, but when you go back to those papers, they’re review papers
  - They’re not trials
  - Those papers say the limits are like this and they cite a few things

***And you keep going back and we’re unable to find trials where people do it***

- All you seem to get to is somebody said, “*Well, but there was this group of hunters in this population who ate this many grams and they were okay. So don’t go above that*.”
- But nobody said, “*If you go above that, something bad happens*.”
- There’s this study and loosely of 1 or 2 guys who ate nothing but meat for 6 months to a year and they were fine
- Interestingly, there’s a corresponding study from 1928, 2 Polish scientists put 2 Polish people on a diet for 6 months of nothing but potatoes, fruit, and a little bit of fat to cook the potatoes in
  - The idea was can you get enough protein and nitrogen out of the potatoes
  - And the answer was yes, at least for 6 months and they were fine
- So people have been fine eating nothing but meat and no plants for 6, 12 months
- Or eating nothing but potatoes for 6 months as a protein source, and they’ve all been fine

***These are semi-anecdotes; they’re intervention studies, but they’re not big randomized control trials***

Peter asks, “*Do you remember in any of those studies how much weight was lost in each group?*”

- In the potato study, there was neither weight lost nor gained
- Peter wonders how those people didn’t lose weight
- David thinks they were probably thin to begin with
- If you go back to the classic studies of [Ted Van Itallie](https://ajcn.nutrition.org/article/S0002-9165(22)00994-7/fulltext) and [Sami Hashim](https://icahn.mssm.edu/about/srt/archives/oral-history/msslw-interviews/hashim) from ’60s where they would bring in as they described them at the time lean Columbia University students versus obese adults and they gave them Metrical through a tube where they could get unlimited supply, but they couldn’t really see how much they were eating
  - Metrical was the Boost or Ensure of 1960
  - And what they found is that the obese people generally lost weight
    - They didn’t fully compensate or the monotony made them reduce intake
  - Whereas the lean students all maintained weight
- David suggests, “*It’s probably that the effects of diet on weight change vary a great deal depending on where you’re starting*.”
- The potato eaters neither gained nor lost weight and they had beautiful nitrogen balance
- All meat eaters were fine for at least for 6, 12 months were fine
  - Though David hasn’t studied those papers as carefully
- What David has not seen done to test this rabbit starvation thing is bring in a bunch of healthy adults and feed them nothing but cooked rabbit for 6 months or something

***He has not seen a study that fed enormous levels of protein to normal adults and saw leaching of bone mass***

Peter asks, “*Do you think that study would need to be rabbit because it’s so lean or could it be rib eye, which is equally void in carbohydrate, but at least is high in fat? So from a macro perspective, you’re dividing things up*.”

- It depends on what you think the mechanism of action is
- It’s not crystal clear to David that people have specified a clear mechanism of action
- There is some speculation and some nice recent papers on this, that especially for people who want anabolic effects (bodybuilders, weightlifters), that when you eat protein, you should have some carbohydrate with it ‒ that will enhance the anabolism
  - Through insulin
  - Or you inject insulin
- David is just entering this literature

***His understanding from what he’s read so far: There is no compelling evidence that you get more anabolic effect if you eat carbohydrate with your protein than if you eat protein alone***

- **All of these things are presumed known and readily talked about but not demonstrated:** rabbit starvation, bone loss, kidney problems, and you must have carbohydrate with it
- David explains, “*I’ve not seen any trial data yet in normal adolescents or adults that suggests a negative health problem, not conjecture, but observed as a result of too much protein. Now, I’m not saying there isn’t such a study, but I have not yet found those studies. If anybody else knows them, please send them to me.*”

## Future research needed to understand basic questions around protein intake [1:45:00]

**Let’s assume those studies don’t exist. What is the probability that such basic questions like this will be answered in the coming decade of nutrition science?**

- Peter wonders what’s the appetite for this type of clinical investigation
  - Especially now, when the name of the game in nutrition science is pharmacology, not these mundane questions about macronutrients
- For obesity treatment and closely related things, diabetes treatment, prevention, David think’s Peter is right ‒ **pharmacology** is the name of the game
- For other areas, he thinks there’ll be more interest  ‒ **longevity promotion**
  - The Evolution Foundation could conceivably do big studies
  - But even there, nothing’s unlimited; they might say, “*Well, we’re going to focus a big trial that’ll be definitive and really give the answer, but it’s going to give the answer only in this age group*.”
- NIH and industry are likely to fund in most cases things that are small enough that we’re not going to know the answer about every dose at every period of time in every race, age, sex, and health status group
  - What we’ll know is pocket answers
- For example, we could get a study funded in which we very, very thoroughly looked at ordinary healthy adults over 60 years old who want to increase strength and muscle mass and we’ll look at protein intake and we’ll look at other upper limits
  - Then you might come back and say, “*You’ve shown it’s safe or unsafe for a 60-year-old. That doesn’t mean it is for a 20-year-old*.”
    - Similar to the example with casein, whey, but not pea protein and whatever

**How compelling do you find the data that high protein diets reduce longevity?**

- There are many proponents of the view that lower protein is better, especially within the plant-based community

*How do you assess the strength of that claim?*

- Very low
- David thinks it’s going to depend on species, and that’s important because it leads to the extrapolation issue
  - If you’re a butterfly, I think it probably does reduce lifespan, and a higher carbohydrate diet may increase lifespan more if you’re a butterfly

***In humans, there’s no compelling evidence [to support a low protein diet]; and there’s some evidence and reasons to believe the contrary***

- Some of that’s going to be tied to wealth
  - Wealthier people eat more protein than less wealthy people, including within our country
- So it’s hard to tease all this part of the epidemiology
- But if you look at the association studies, even there, it’s not compelling

*Then you can say, well, do you accept the association studies?*

- Not all that much
- If you look at the mouse studies of a low protein diet, they’re not all that compelling, and David’s not sure you see the full translation there

***Nothing that David knows of would say there’s very strong reason to believe (even if not definitive RCT) that higher protein will lead to less longevity; and if anything, there’s more compelling reason on the contrary***

**David’s friend and IU alumnus** [**Barry Sears**](https://drsears.com/author-of-1-best-seller-the-zone/) **talks about the** [**Zone Diet**](https://zoneliving.com/pages/zone-diet)

- The idea of the zone is that there’s too much on this end, you shouldn’t be too high on this end, don’t be too low over here
  - There’s a zone of things in the body and in diet that are right
  - You got to find the right spot
  - He very strongly believes that you want to upregulate [AMPK](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase) to live longer and you want to not upregulate [mTOR](https://en.wikipedia.org/wiki/MTOR) too much to live longer
    - Peter has talked about [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) [[episode #272](https://peterattiamd.com/davidsabatini-mattkaeberlein/)], which has effects that will go along with what he’s saying
- He might argue from that point of view that too much protein would reduce longevity
  - David can’t say he’s wrong
- It may also depend on which period of time
  - What’s good for you to do or eat early in life to prolong life may not be what’s good for you later in live
    - Sometimes we call that **antagonistic pleiotropy**
  - And here we might say that exercise in rats reduced mortality rate in the first half of life, but it increased mortality rate in the second half of life
    - [John Holloszy](https://nutritionalscience.wustl.edu/people/john-holloszy-md/) found this in rats, and David doesn’t know if it holds up as one study

***If we accept that as causal and valid and replicable, then maybe the same things might be true for protein, might be good to eat more when you’re younger and less when you’re older, or less when you’re younger and more when you’re older (David doesn’t know)***

**We also need to think that longevity is only one factor**

- There’s no right answer to this
- If someone were to say, “*Live this way and our best guess is you’ll die two years earlier. But until you die, you’ll be stronger. You’ll feel more energized. You’ll look better;*” you might make that trade
  - While someone else would not
  - Who’s to say, who’s right?

## David’s weekly newsletter: “Obesity and Energetics Offerings” [1:50:45]

- David serves as the editor of a newsletter that comes out every Friday: [*Obesity and Energetics* *Offerings*](https://www.obesityandenergetics.org/)
  - Peter has been a subscriber for a decade, maybe more

**When did it start?**

- It started organically when David was just in grad school or getting out
- Then, there was no formal letter of the internet
- He would hand his professors paper he had read; he mailed them to a couple of people
- Soon people started asking to be added to his list
- Then it became electronic
- Then it became a formal web thing
- Now it goes out to over 100,000 people worldwide
- They don’t charge anything for it; it’s free
- They don’t accept any commercial support for it
- It contains usually about 100 or a few more links to mostly scientific papers, sometimes popular media articles commenting on things in virtually every category related to obesity, energy, metabolism, nutrition
- Peter is a big proponent of it, and his team all subscribe to it
  - There are not too many newsletters that he relies on
- People ask Peter how he stays up to date on things, and the truth of it is he has to rely on other people doing a lot of the aggregation
  - Then he’ll go where his curiosity goes, and sometimes he’ll go a bit deeper
- One of the fun thinks Peter thinks is great for people learning is one of the sections called “Headline versus Study”
  - If folks listening are going to read any of the subheadings there, read that one because it give you a great sense of how misleading the traditional media can be
    - Not necessarily because they’re nefarious
    - It’s more of scientific ignorance and a misalignment of incentives
    - One, they’re simply not qualified ‒ they don’t have the scientific literacy to understand what a study shows
    - Secondly, they’re really incentivized to get you to read a study and click through something and they have to come up with a headline that makes that appealing
  - As David points out every week, there’s a great example of one where the headline is patently false at worst, and at best, so misleading as to be useless
- Peter thinks it’s valuable for folks to get into the habit of checking that once a week and seeing, “*Hey, that was a headline. I could see that headline. I could see how I’d get fallen, I’d get duped for that. But oh, there’s the study.*”
  - The headline could be something as outrageous as women are so much more likely to outlive their partners if they have sex 3 times a week
  - Then you look at the study and it’s about this rare species of fruit fly that sometimes mate with male fruit flies that die a little premature
    - It can be so ridiculous
- Anybody can subscribe for free
- [Andrew Brown](https://www.archildrens.org/research/researchers/andrew-brown), who’s a professor and David’s former mentee at University of Arkansas took over handling that category a few years ago, and he does a beautiful job with it
  - He sets these things up and often finds interesting things
  - He even got ot the point where others picked up on his use of the phrase, “*In mice,*” as a standard thing
    - Which is just as often a way of saying, “*Well, we found this in mice*,” but in mice is often left off in the headlines

**How many people are involved in curating that list each week?**

- It’s about 5 people in any 1 week, including David
  - There’s David, an editor, [Andrew](https://www.archildrens.org/research/researchers/andrew-brown) (who cleans everything up), and [Colby Vorland](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=cvorland) (who also cleans everything up), and someone else who posts it
  - It’s a lot of work, but it’s fun; it’s a labor of love
    - The editor rotates every week

§

## Selected Links / Related Material

**Episode of** ***The Drive*** **with David Allison**: [#197 – The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.](https://peterattiamd.com/davidallison/) (February 8, 2022) | [4:00]

**Cochrane collaborations on lack of success of public health initiatives for obesity**: [16:15, 28:45]

- [Interventions to prevent obesity in children aged 5 to 11 years old](https://pubmed.ncbi.nlm.nih.gov/38763517/) | *Cochrane Database of Systematic Reviews* (F Spiga et al 2024)
- [Interventions to prevent obesity in children aged 12 to 18 years old](https://pubmed.ncbi.nlm.nih.gov/38763518/) | *Cochrane Database of Systematic Reviews* (T Moore et al 2024)

**Genetic contribution to the obesity epidemic**: [GWAS for BMI: a treasure trove of fundamental insights into the genetic basis of obesity](https://pubmed.ncbi.nlm.nih.gov/29980761/) | *International Journal of Obesity* (J Speakman et al 2018) | [44:00]

**Danish data on intergenerational lagged effects of obesity**: [Causes of juvenile obesity: Clues from epidemiology](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1600-0463.2001.tb05763.x) | *APMIS* (T Sorensen 2011) [45:45]

**Pew Charitable Trusts have shown Americans trust clinicians more than nutrition scientists**: [5. Americans trust dietitians more than nutrition researchers but are skeptical of both groups’ transparency, accountability](https://www.pewresearch.org/science/2019/08/02/americans-trust-dietitians-more-than-nutrition-researchers-but-are-skeptical-of-both-groups-transparency-accountability/) | *Pew Research Center* (C Funk et al 2019) | [55:00]

**Episode of** ***The Drive*** **with Luc van Loon**: [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) (April 22, 2024) | [1:31:30]

**Methionine restriction prolongs life [in mice]**: [Methionine-deficient diet extends mouse lifespan, slows immune and lens aging, alters glucose, T4, IGF-I and insulin levels, and increases hepatocyte MIF levels and stress resistance](https://pubmed.ncbi.nlm.nih.gov/15924568/) | *Aging Cell* (R Miller et al 2005) | [1:32:45]

**Peter’s book**: [Outlive: The Science and Art of Longevity](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZYvVvMTwn080mPgXuOAjD_XK_KjTO3VwWMqP8Dhwyz6OXfIGzhW2lH6tjudB0KY76hzCg0ilDh2WKrtV3yaSBcf7X8WxSb6ltu7J0D1BQYH6d2Z6ZD9qcEqy4CsFBFiGPu_zkrV62x_lys_4NTr_mfwIoqnpafwN_akXJsDaK53DwBuwS-CP7mppw2a_lWAMGWfiHcBedMdMIDjnbwTnBGg.aDI-c_J_pUn_oUxPX8osAFoUW3ZBaseeRm97bTbhTMA&qid=1718806315&sr=8-1) by Peter Attia with Bill Gifford | [1:34:00]

**Peter’s newsletter about protein utilization for muscle protein synthesis**: [New insights on maximizing protein utilization for muscle protein synthesis](https://peterattiamd.com/protein-anabolic-responses/) | PeterAttiaMD.com (K Birkenbach, P Attia 2024) | [1:39:15]

**Recent nutrition 101 in** ***NEJM***: [Guidance on Energy and Macronutrients across the Life Span](https://pubmed.ncbi.nlm.nih.gov/38598796/) | *NEJM* (S Heymsfield, S Shapses 2024) | [1:40:15]

**Recent episode of** ***The Drive*** **on rapamycin**: [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) (September 25, 2023) | [1:49:30]

**David’s Newsletter**: [Obesity and Energetics Offerings](https://www.obesityandenergetics.org/) | [1:50:45]

§

## People Mentioned

- [Wilbur Atwater](https://en.wikipedia.org/wiki/Wilbur_Olin_Atwater#) (1844-1907, American chemist who studies nutrition and metabolism, provided energy values for macronutrients) [10:45]
- [James Lind](https://en.wikipedia.org/wiki/James_Lind) (1716-1794, Scottish physician who figured out that citrus fruits cured scurvy) [12:00]
- [Stephen (Steve) O’Rahilly](https://www.csap.cam.ac.uk/network/steve-orahilly/) (Head of Department of CLinical Biochemistry at the University of Cambridge, Co-Director of the Institute of Metabolic Science) [15:15]
- [Xavier Pi-Sunyer](https://www.researchgate.net/profile/Xavier-Pi-Sunyer-2) (Director Emeritus of the New York Nutrition Obesity Research Center and Professor Emeritus in the Institute of Human Nutrition at Columbia University) [19:00]
- [Theodore (Ted) Van Itallie](https://ajcn.nutrition.org/article/S0002-9165(22)00994-7/fulltext) (1919-2019, leading expert on obesity and metabolic disease, former Chief of Medicine at Mount Sinai St. Luke’s) [19:00, 1:41:45]
- [Jules Hirsch](https://en.wikipedia.org/wiki/Jules_Hirsch) (1927-2015, Professor at Rockefeller, former hospital physician-in chief, expert in obesity and metabolism) [19:15]
- [Rudolph (Rudy) Leibel](https://www.neurosciencephd.columbia.edu/content/rudolph-l-leibel-md) (Professor of Diabetes Research and Pediatrics and Medicine, Co-Director of the Naomi Berrie Diabetes Center, expert in obesity and diabetes) [19:15]
- [Albert (Mickey) Stunkard](https://en.wikipedia.org/wiki/Albert_Stunkard) (1922-2014, Psychiatrist and Professor at the University of Pennsylvania, pioneer in obesity research) [19:45]
- [MRC Greenwood](https://nutrition.ucdavis.edu/people/mrc-greenwood) (President Emerita, University of Hawaii; Chancellor Emerita, UC Santa Cruz; Distinguished Professor Emerita, UC Davis; expert in obesity, diabetes, and women’s health) [19:45]
- [Robert Fogel](https://en.wikipedia.org/wiki/Robert_Fogel) (1926-2013, won the [1993 Nobel Prize in Economic Sciences](https://www.nobelprize.org/prizes/economic-sciences/1993/fogel/facts/), economic historian) [21:30]
- [Kelly Brownell](https://sanford.duke.edu/profile/kelly-d-brownell/) (Emeritus Professor of Public Policy at Duke University, expert in obesity) [22:00]
- [Carolyn Summerbell](https://www.durham.ac.uk/staff/carolyn-summerbell/) (Professor of Sport and Exercise Sciences and Deputy Director of Fuse, The Centre for Translational research in Public Health at Durham University, UK) [33:30]
- [Leonard (Len) Epstein](https://medicine.buffalo.edu/faculty/profile.html?ubit=lhenet) (SUNY Distinguished Professor of Pediatrics and Division Chief, Behavioral Medicine at the University at Buffalo) [30:30]
- [Claude Bouchard](https://www.pbrc.edu/research-and-faculty/faculty/bouchard-claude-phd.aspx) (Endowed Chair in Genetics and Nutrition at Louisiana State University) [32:00]
- [Richard Thaler](https://www.chicagobooth.edu/faculty/directory/t/richard-h-thaler) (Professor of Behavioral Science and Economics at The University of Chicago Booth School of Business and recipient of the [2017 Nobel Prize in Economic Sciences](https://www.nobelprize.org/prizes/economic-sciences/2017/popular-information/)) [34:15]
- [Daniel Kahneman](https://en.wikipedia.org/wiki/Daniel_Kahneman) (1934-2024, Cognitive scientist known for his work on the psychology of judgment and decision making, recipient of the [2002 Nobel Prize in Economic Sciences](https://www.nobelprize.org/prizes/economic-sciences/2002/kahneman/facts/), Emeritus Professor of Psychology and Public Affairs at Princeton University) [36:45]
- [Michelle Cardel](https://www.weightwatchers.com/us/science-center/team/michelle-cardel) (Senior Director of Global Clinical Research and Nutrition at WeightWatchers) [37:00
- [Thorkild Sørensen](https://publichealth.ku.dk/staff/?pure=en/persons/40607) (Professor Emeritus of Epidemiology at the University of Copenhagen)  [445:45]
- [Diana Thomas](https://www.westpoint.edu/mathematical-sciences/profile/diana_thomas) (Professor of Mathematics at West Point, studies obesity) [46:15]
- [Stuart Ritchie](https://en.wikipedia.org/wiki/Stuart_J._Ritchie) (Scottish psychologist and science communicator, author of the book [*Science Fictions*](https://www.amazon.com/Science-Fictions-Negligence-Undermine-Search/dp/1250222699/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.QIeFmhUcDakliZz1T81xgaWpyZ39zVnW1w-cSZPBLZcbijvfciGwqOSznT8zNaz4VQqASzd0TcXrtgHQKm1AQPmZyInczmGO5NJPTWRZ2bCvEZ4_fbUmfemECzq0lQvY9cOyVuqlxXjvj8K60mq8JvZw6iCl4E5QiGdfGBSVNf7_kuAdkhCgscIeijJl9XKXb-D8CA1wkWksW2ndrUFIRZHNr8Ua1BUzpk8IBoF-mcM.N3qGRgxh3gy5nVtMLxklzCJjV1iJReLEcWR1D3e4sf4&qid=1718639256&sr=8-1)) [53:45]
- [Gary Taubes](https://garytaubes.com/) (Investigative science and health journalist, author of [*Rethinking Diabetes*](https://www.amazon.com/Rethinking-Diabetes-Science-Successful-Treatments/dp/0525520082/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.aalU2h4Dpx2VPjTr0cWvOEpu2H9vrNr0QE11hmLLtpjuB13Qx3j4Kr0uypjhUNk-BhmAtzyuenUPm3ik3env7GH2TbE9rOD3FtxNEocY-qsm7BN-OcsV8knt4NFqBzz4CXAh_0fof1XXKd_0yvSTL7O4L3Ydd8Yw_ODqnx1tYrnmeJetATgsNemskZDtd5SM6vAMCLMv8S8o2yWogXSAHh97yYQMrVr1W-cgCm1_y61Ld7jWqVxy_k1vRCiEKohmHjlLazlZp_5Do79l4UaRwpO05Hq1Fknp6puuckTvvjk.3AQBtsbWNy2TzsltKfsETfKIp71xEJyCMPx_AHqTscA&qid=1718639585&sr=1-1) and other books on nutrition) [53:45]
- [John (Johnny) Ioannidia](https://profiles.stanford.edu/john-ioannidis) (Professor of Medicine at the Stanford Prevention Research Center, Professor of Epidemiology and Population Health, Professor (by courtesy) of BIomedical Data Science) [54:00]
- [Luc van Loon](https://www.maastrichtuniversity.nl/ljc-van-loon) (Professor of Physiology of Exercise and Nutrition and Head of the M3-research group at the Department of Human Biology at Maastricht University, expert in skeletal muscle metabolism) [1:31:30]
- [Vijay Yadav](https://www.genetics.cuimc.columbia.edu/research-labs/karsenty-lab#:~:text=sends%20e%2Dmail)-,Vijay%20Yadav,-Assistant%20Professor%20of) (Assistant Professor of Genetics and Development at Columbia University in the Karsenty Lab, expert on taurine) [1:32:45]
- [Richard (Rich) Miller](https://www.richmillerlab.com/biog) (Professor of Pathology at the University of Michigan, Director of the Paul F. Glenn Center for Aging Research) [1:32:45]
- [Don Layman](https://fshn.illinois.edu/directory/dlayman) (Professor Emeritus of Food Science & Human Nutrition at the University of Illinois Urbana-Champaign, expert in protein metabolism) [1:34:45]
- [Steven Heymsfield](https://www.pbrc.edu/research-and-faculty/faculty/Heymsfield-Steven-PhD.aspx) (Professor of Metabolism & Body Composition at Pennington Biomedical Research Center Louisiana State University) [1:40:15]
- [Sue Shapses](https://nutrition.rutgers.edu/faculty/sue-shapses.html) (Professor of Nutritional Sciences at Rutgers University and Director of the NEXT Center at the NJ-IFNH) [1:40:15]
- [Sami Hashim](https://icahn.mssm.edu/about/srt/archives/oral-history/msslw-interviews/hashim) (expert in nutrition and lipid metabolism, former Director of the Division of Metabolism and Nutrition at Mount Sinai St. Luke’s) [1:41:45]
- [Barry Sears](https://drsears.com/author-of-1-best-seller-the-zone/) (Biochemist and author of [*Enter The Zone: A Dietary Road Map*](https://www.amazon.com/Enter-Zone-Dietary-Road-map/dp/0060391502/ref=sr_1_1?crid=2EJRE7Q1R75G1&dib=eyJ2IjoiMSJ9.WjRQkxxGww0CzTvBANjN6YrF4CdQq3PixNo8590XPNDlvrimOvmAfA1pj1rSgkkP62XawteTiM1mJzFXDUi2f04zIehtEXYOIL67OfrYrSYbfrtKC9_C5RvVc5m15UlM1b8BNPypR5BF5S1vwWXEkNAnywocBbZdLK6V-TcsAhRwsvcyAE6jpplz1MuAo8M5Rtypa3cJr-QfPzHQqTxnAPVkTxmwNJr3eVwwaN7W1M4.cYW52j_8gH9-RWnqqgRu-6nbOcNhe5McJ5DfJA_3rkw&dib_tag=se&keywords=the+zone&qid=1718898090&sprefix=the+zone%2Caps%2C111&sr=8-1)) [1:48:45]
- [John Holloszy](https://nutritionalscience.wustl.edu/people/john-holloszy-md/) (1933-2018, Professor at Washington University School of Medicine in St. Louis, expert in exercise biochemistry and calorie restriction) [1:49:30]
- [Andrew Brown](https://www.archildrens.org/research/researchers/andrew-brown) (Associate Professor of Biostatistics and Director of the Medical Sciences Biostatistics Core at the University of Arkansas) [1:53:45]
- [Colby Vorland](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=cvorland) (Assistant research scientist at Indiana University Bloomington) [1:54:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/02/david-allison-1x1-1-500x500.jpeg)

##### David Allison, Ph.D.

David B. Allison received his Ph.D. from Hofstra University in 1990. He then completed a post-doctoral fellowship at the Johns Hopkins University School of Medicine and a second post-doctoral fellowship at the NIH-funded New York Obesity Research Center at St. Luke’s/Roosevelt Hospital Center. He continued there as a research scientist and Associate Professor of Medical Psychology in Psychiatry at Columbia University College of Physicians & Surgeons. In 2001, he moved to the University of Alabama at Birmingham where he served as a distinguished professor and director of the NIH-funded Nutrition Obesity Research Center. In 2017, he became Dean and Provost Professor at the Indiana University School of Public Health-Bloomington.

He has authored more than 600 scientific publications and received many awards, including the 2002 Lilly Scientific Achievement Award from The Obesity Society (TOS); the 2002 Andre Mayer Award from the International Association for the Study of Obesity (IASO); the National Science Foundation–administered 2006 Presidential Award for Excellence in Science, Mathematics, and Engineering Mentoring (PAESMEM); and the 2018 Harry V. Roberts Statistical Advocate of the Year Award from the American Statistical Association. In 2009, he was awarded the Centrum Award from the American Society of Nutrition (ASN) and the TOPS research achievement award from the Obesity Society. In 2013, he was awarded the Alabama Academy of Science’s Wright A. Gardner award and the American Society of Nutrition’s (ASN) Dannon Institute Mentorship award. He was elected as a Fellow of the American Statistical Association (ASA) in 2007, the American Psychological Association (APA) in 2008, the American Association for the Advancement of Science (AAAS) in 2009, the NY Academy of Medicine in 2014, the Gerontological Society of America in 2014, the Academy of Behavioral Medicine Research in 2017, and inducted into the Johns Hopkins Society of Scholars in 2013. In 2012, he received an NIH Director’s Transformative Research Award entitled “Energetics, Disparities, & Lifespan: A unified hypothesis.” In 2020, he was awarded the American Statistical Association’s San Antonio Chapter 2020 Don Owen Award in recognition of excellence in research, statistical consultation, and service to the statistical community. In 2021, he received the Obesity Society’s Friends of Albert (Mickey) Stunkard Lifetime Achievement Award.

In 2012 he was elected to the National Academy of Medicine of the National Academies. In addition to co-chairing their Strategic Council for Research Excellence, Integrity, and Trust (with Marcia McNutt and France Córdova), he was selected for their ad hoc committee to develop methods for assessing misinformation about biological threats. He has also served on the Scientific Advisory Board for the Nutrition Science Initiative (NuSI) and served on the board-appointed Committee on Science and Technology Engagement with the Public (CoSTEP) for the American Association for the Advancement of Science (AAAS), 2014–2020.

He has contributed to many editorial boards and is currently an associate editor or statistical editor for *Obesity*; *International Journal of Obesity; Nutrition Today; Obesity Reviews; Public Library of Science (PLOS) Genetics; Surgery for Obesity and Related Diseases (SOARD)*, and *American Journal of Clinical Nutrition*. Dr. Allison is also proud to be the founding Field Chief Editor of *Frontiers in Genetics*. His research interests include obesity and nutrition, quantitative genetics, clinical trials, statistical and research methodology, and research rigor and integrity. [[Indiana University Bloomington School of Public Health](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison)]