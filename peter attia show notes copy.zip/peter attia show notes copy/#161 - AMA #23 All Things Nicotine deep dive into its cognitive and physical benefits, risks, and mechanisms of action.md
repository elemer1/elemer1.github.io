# #161 – AMA #23: All Things Nicotine: deep dive into its cognitive and physical benefits, risks, and mechanisms of action

**Source:** [https://peterattiamd.com/ama23/](https://peterattiamd.com/ama23/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob dive deep into nicotine, a complicated and interesting molecule that has effects on both the brain and the body. They analyze the results of the studies that describe nicotine’s cognitive benefits and potential for inducing weight loss. They talk about a smoking cessation technique called nicotine replacement therapy and give a full breakdown of the various routes of administration, dosing, and safety. Finally, they explore the fascinating and counterintuitive observation that cigarette smokers are less likely to get a severe case of COVID-19.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #23 show notes page](https://peterattiamd.com/ama23). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- How Peter first became interested in the potential benefits of nicotine [1:15];
- Untangling nicotine from tobacco [6:00];
- Nicotine replacement therapy (NRT) for quitting smoking: products, protocols, and a review of the literature [9:30];
- The cognitive benefits of nicotine: Overview of the literature [15:50];
- Where nicotine has the most positive impact on cognition [30:30];
- Possible mechanisms conferring the benefits of nicotine [37:00];
- How modafinil and other nootropics compare to nicotine [47:15];
- How nicotine may induce weight loss [54:00];
- Relationship between smoking and COVID-19: Analyzing the observation that smoking appears protective against COVID-19 [1:01:45];
- Breakdown of the various nicotine replacement therapies: route of administration, dosing, and safety [1:11:30];
- Concluding thoughts on nicotine: use cases, addictive properties, and more [1:19:45]; and
- More.

§

The Peter Attia Drive

All Things Nicotine: deep dive into its cognitive and physical benefits, risks, and mechanisms of action

§

## Show Notes

§

## How Peter first became interested in the potential benefits of nicotine [1:15]

**Quick aside on Peter’s deadlift routine**:

- Peter deadlifts in more the sumo (straight bar) and well as hex bar
- His current phase of deadlifting leans more sumo style rather than hex bar
- He’s using a traditional narrow stance straight bar
- But he goes in phases and likes to mix it up

> “This silly unrealistic question of, ‘If you’re going to do one exercise, what would it be?’ That would definitely be variations of deadlifts.” —Peter Attia

**Nicotine questions for today**:

- Does nicotine improve cognition?
- Does nicotine improve fat oxidation and can it actually help with weight loss?
- Is it possible that smoking is protective against COVID-19?

**When peter got interest in nicotine:**

- From a personal standpoint, Peter became interested in nicotine about 11 years ago
- He realized that if you could strip away the addictive nature of nicotine, the actual molecule was quite interesting
- He started chewing nicotine gum intermittently
- Note: If you’re not a smoker, go really easy with gum or lozenges because it can make you quite nauseous
- For about the next three or four years, he was on and off nicotine gum somewhere between four and eight milligrams a day and found it to be quite beneficial in terms of his mental focus
- And he never really felt even a slight bit of addiction (not the case for all people)
- More recently, Peter discovered nicotine containing pouches
- He always thought the gum tasted gross (too much sugar/sweetness) whereas the pouches are mostly flavorless
- With the pouches, you’re just basically just getting a pretty high dose of nicotine and it’s bypassing the liver so it actually hits you quicker

## Untangling nicotine from tobacco [6:00]

**Difference between nicotine and tobacco**

*Tobacco*

- Obviously cigarettes contain leaves from tobacco plants and tobacco also contains nicotine
- Tobacco is actually in the [nightshade](https://en.wikipedia.org/wiki/Solanaceae) family of plants, and when you look at potatoes and tomatoes and eggplants, there’s nicotine in there but at nowhere near tobacco
- Nicotine makes up about 1% to 3% of the dry weight of tobacco whereas these nightshades, it’s millions of a percent

**Nicotine is not a carcinogen**

- The US Surgeon General [indicated](https://stacks.cdc.gov/view/cdc/21569/Share) that there’s inadequate evidence to infer a causal relationship between nicotine exposure and risk for cancer
- But this is counterintuitive when you think about how bad for you smoking is — since nicotine is in there, and it’s addictive, it’s normal to think that it’s one of the carcinogens in cigarettes
- But even the U.S. Department of Health’s list of [69 potential and known carcinogens in cigarettes](https://www.cancer.gov/about-cancer/causes-prevention/risk/tobacco/cessation-fact-sheet), nicotine is not one of them
- In other words, nicotine—which has some benefits—unfortunately has that addictive part of it which keeps people coming back to smoking tobacco, **but in and of itself it doesn’t cause cancer**
- This is important to note because the U.S. Department of Health goes as far to say that processed meat is a class one carcinogen, and red meat is in the next class down as a carcinogen despite very little evidence
  - [See](https://peterattiamd.com/191027/) [Peter’s](https://peterattiamd.com/is-red-meat-killing-us/) [many](https://peterattiamd.com/the-red-meat-and-plant-based-recommendation-wars/) [articles](https://peterattiamd.com/red-meat-cancer-push-ups-and-cvd/) on the topic of red meat

> “If they can’t even recognize nicotine is carcinogenic given their sensitivity for identifying carcinogens, the likelihood that it has any cancer causing properties is approaching…zero.” —Peter Attia

## Nicotine replacement therapy (NRT) for quitting smoking: products, protocols, and a review of the literature [9:30]

**NRT – Nicotine replacement therapy**

- Nicotine is an addictive substance and so you could implicate that as getting people to smoke and stay smoking
- But now, they’re actually using nicotine to help people **quit** smoking
- There’s an entire industry of nicotine gum, lozenges, pouches, patches, etc.

A [review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6353172/) by the Cochrane Collaboration

- Looked at people who have quit for six months and haven’t returned to smoking
- They found high quality evidence that this NRT increases the chances of successfully quitting smoking by about 50% to 60% (relatively)
- However, in absolute terms: Absolute quit rate at 6 months is ~ 3-5%, and therefore NRT may increase the rate by 2-3%
- “You have to always ask the question, ‘What does that mean at an absolute level?’” says Peter
- In the big picture, the small absolute increase tells us that it is very hard to quit smoking using NRT

*Why doesn’t it work more?*

- - Bob says the lozenges for the most part come in two milligram and four milligram
  - But a cigarette supposedly has about one milligram of nicotine contained within the cigarette
  - But… it’s a different route of administration and people probably say something to the effect of “it’s just not the same” and they go back to the smoking

- I*s inhalation just the fastest route of administration making the rush and the buzz from the nicotine when you inhale it across that entire alveolar surface area*?

- - I think that plays a role, says Bob
  - They’re working on patches and nasal sprays trying to mimic getting speedier delivery of it

**Historical smoking data**

- At its peak in the mid 1960s, close to 60% of Americans over the age of 18 smoked cigarettes
- Now, Americans that smoke is around [15%](https://en.wikipedia.org/wiki/Prevalence_of_tobacco_use#:~:text=fallen%20to%2019%25.-,United%20States,8.7%20million)%20smoked%20some%20days.)
- Interestingly, in the [podcast with Nir Barzilai](https://peterattiamd.com/nirbarzilai/), he was talking about centenarians and discussing whether it is their genes or their environment causing them to live so long
- His basic conclusion is that it’s genes, not environment, citing that a lot of the centenarians had smoked

**\*One protocol that’s possibly more successful than just NRT for smokers trying to quit**: Combining [Wellbutrin](https://en.wikipedia.org/wiki/Bupropion), an antidepressant, with NRT

> “If you’re a smoker and you’re interested in longevity, there’s harder to find a lower hanging piece of fruit than smoking cessation as you move to improve someone’s health.” —Peter Attia

## The cognitive benefits of nicotine: Overview of the literature [15:50]

**A** [**meta-analysis**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3151730/) **from 2010**

- They found 41 studies (48 experiments) where there were sufficient effect size data (i.e., a minimum of five effect sizes from independent studies were available) to conduct meta-analyses on nine performance domains, including motor abilities, alerting and orienting attention, and episodic and working memory.
- When you do a meta-analysis, there’s usually an inclusion criteria and an exclusion criteria — In this case they only looked at the double-blind placebo-controlled trials on nicotine and smoking on human performance (i.e., attention and cognition) in healthy adult nonsmokers and smokers **who were not tobacco deprived**
- Regarding the “not tobacco deprived” criteria — they are making sure that the smokers were not coming to the study already in a state of low cognition due to withdrawal symptoms
  - For example, if you tell a heavy smoker to not smoke in the morning, their cognitive performance may actually decline just because of that, because they’re going through nicotine withdrawal

\*\*\*

**Quick aside on the topic of withdrawal**

- Withdrawal can be dangerous for some substances
- Alcohol withdrawal, for instance, is easily fatal
  - When patients come to the hospital to have surgery, for example, understanding how much they drink at baseline is very important
  - And if they are heavy drinkers, they either need to be given intravenous ethanol or given heavy dose of benzodiazepines
  - If you fail to do that, you can easily result in cardiac dysrhythmia and death
- That is NOT the case with nicotine withdrawal — there’s no dying from nicotine withdrawal, just profound misery
- The same is true with opiate withdrawal… profoundly miserable but not fatal

*Smoking withdrawal (Bob’s personal experience)*

- How long does that withdrawal last if a packet per day smoker quits cold turkey?
- Haven’t looked based on the studies, says Bob, but from personal experience it is miserable
- At the very beginning (first week or two) it’s brutal, because all you’re doing is thinking about having a cigarette throughout the day
- After that, Bob says he felt depressed for a couple of weeks after that
- After a year or so, you reach this point where you can’t even believe that you ever smoked in the first place and you’re never really thinking about a cigarette
- It’s situational though — for example if you go somewhere or do something which uses to be a place where you smoked (driving in car, golf course, etc.) — there’s a physiological craving that can come up
- “*It’s like that devil still on your shoulder . . .I don’t know when that devil just disappears but it seemed relatively long-term at least for me, which was after a couple years*.”

\*\*\*

**Back to the** [**meta-analysis**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3151730/):

*They looked at the following nine domains*:

- 1) fine motor,
- 2) alerting attention-accuracy,
- 3) alerting attention-RT (response time),
- 4) orienting attention-accuracy (directing attention to sensory events,\* as in cued target tasks — e.g., [Posner task test](https://www.psytoolkit.org/experiment-library/cueing.html)),
- 5) orienting attention-RT,
- 6) short-term episodic memory-accuracy,
- 7) long-term episodic memory-accuracy,
- 8) working memory-accuracy, and
- 9) working memory-RT.

![](https://peterattiamd.com/wp-content/uploads/2021/05/f1-ama23-1024x480.png)

**Figure 1.**

Examples of tests they did:

- For fine motor abilities they looked at small muscles of the body using a task with a peg board measuring how quickly can you put a peg into the board in the right color coded spot
- For the attentional categories like i) accuracy and ii) response time they used signal detection (think like the hearing test where you’d put on headphones and listen for a little auditory sound and you’re trying to see how quickly or how accurately you can detect the signal)
- For attentional orienting they looked at the accuracy and response time to a sensory event using a tasked called “Cued target detection.” and another one called the “[Posner task test](https://www.psytoolkit.org/experiment-library/cueing.html)”
  - For the cued target detection, they’ll cue you with an X on a screen and it could be on the left hand side or the right hand side just like that signal detection — in the test they may try to “trick” you and they’ll put the cue on the left hand side, and the “Go” thing shows up on the right hand side, but that’s directing attention to sensory events
    - They’re looking at the accuracy like, “Did you pick the correct side?”
    - And also how quickly you respond
- For memory: they have three different memory domains i) short-term memory, ii) long-term memory, and iii) working memory
  - short-term memory, they’re looking at word recall — give you a bunch of words and they’ll see how many words you get back accurately
  - Long-term episodic memory is similar but you listen to a story then you repeat back to them how much of the story you remember and what were the details of the story

\*\*\*

Quick aside: Comparing the tests above to early detection for Alzheimer’s disease—

- Bob did these tests at the [Alzheimer’s prevention clinic](https://weillcornell.org/services/neurology/alzheimers-disease-memory-disorders-program/our-services/alzheimers-prevention-clinic) in New York run by [Richard Isaacson](https://peterattiamd.com/richardisaacson/)
- Checking out different ways of testing cognition for Alzheimer’s prevention looking for any mild cognitive impairment or cognitive impairment
- Peter comments that he has all patients who are at high risk (i.e., at least one copy of the APOE4 gene age + over 60, or at least one relative with Alzheimer’s disease)
  - All those patients immediately fall into the “aggressive Alzheimer’s prevention protocol” on which they partner with Richard Isaacson
  - First they get a baseline test for the patient, then they start looking for any signal of potential early loss of cognition (goal is to catch it long before they get to the cognitive impairment stage)
- Challenge of this process:
  - You have to go through so many reps to try to find the signal — “it’s actually quite a pain to go through them all”
  - There’s definitely an intervention effect in the sense that you “want” to do well and you may even be nervous

*Peter personally remembers doing a test like this when trying to get into medical school*:

- He remembers doing a news recall this was my worst thing of all medical school application stuff
- When you take the MCAT test, it has (had?) four sections
  - Physical chemistry section
  - Biological sciences section
  - An essay you had to write
  - Then there was sight passages where you’d read seven sight passages and answer questions about them
    - Peter says “*I bombed that stage. . .To this day, I still maintain, it is a miracle I got into medical school because of how badly I did on that one section*”
    - “*I realize now, I should’ve been taking nicotine at the time.*”

\*\*\*

## Where nicotine has the most positive impact on cognition [30:30]

Overview of the [meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3151730/):

- Mean age ~26; ~50% male; ~80% white
- 29 experiments (60%) tested nonsmokers (never smokers and former smokers on NRT)

Results—They found significant positive effects of nicotine or smoking on (6/9) domains:

- 1) fine motor abilities,
- 2) alerting attention-accuracy
- 3) alerting attention-response time (RT),
- 4) orienting attention-RT,
- 5) short-term episodic memory-accuracy,
- 6) and working memory-RT (effect size range=0.16 to 0.44).
- The three **without** significant effects were:
  - i) orienting attention-accuracy,
  - ii) long-term episodic memory-accuracy, and
  - iii) working memory-accuracy

Peter’s thoughts:

- Does NOT surprise him that long-term memory wasn’t helped
- Does NOT surprise him that fine motor ability is helped
- Peter explains…
  - When driving his simulator, “*I definitely feel more focused and I seem to drive better with nicotine*.”
  - Interestingly, he doesn’t feel like nicotine would help him much with archery
  - When driving a race car you never get to take your mind off what’s happening, and you have to be thinking two corners ahead at every moment, and just these little lapses you have in concentration are devastating. You’re just guaranteed to crash.
  - It’s just really enhancing concentration in a way that I’m fully fixated on what’s happening. My visual field is wider. I’m looking further down the road and nothing is distracting me.
  - NOTE: It could be the placebo effect, because Peter has never been able to test this on himself in a blinded way
  - With archery — whereas concentration is also important when you’re doing archery, but I think archery is so much slower, and I think concentration is less important than repetition and being able to hold your body in a certain way and obviously being quite still when you do that

## Possible mechanisms conferring the benefits of nicotine [37:00]

*Is it safe to say that this meta-analysis makes a very clear case that nicotine is indeed a performance enhancing drug cognitively?*

- “Yes”, says Bob

*What was the effect size? How much did it improve performance?*

- it’s difficult because of the way that they do it based on effect size range, 0.16 to 0.44 and it’s not clear if that’s 16% of 44%, and a lot of these tests are the response time could be in milliseconds
- So we really don’t know the absolute improvement — just looks like 15-45% relative improvement in a task

*Quantitative vs. qualitative metrics*

- For all of these tests, they distill it down to something time-based
- And that really matters for some activities (e.g., driving a car at the limit)
- Much harder to quantify the effect of say writing an essay because that is much more qualitative
- For example, if Peter is sitting down to write he usually has about a half a day and for him it’s really just a question of ‘how long can I sit there and write without being distracted by something else?’
- Also, the quality of his writing is a factor — i.e., It’s not just how many words do I write, it’s how coherent are those words? How many times do I have to go back and rewrite those words?
- \*It’s just **really hard for a meta-analysis to capture that**

**How does it all work? [39:45]**

- By binding to [nicotinic acetylcholine receptors](https://en.wikipedia.org/wiki/Nicotinic_acetylcholine_receptor) in the brain, nicotine elicits its psychoactive effects and increases the levels of several [neurotransmitters](https://en.wikipedia.org/wiki/Neurotransmitter) in various brain structures – acting as a sort of “volume control”.
- Nicotine’s selectivity is thought to be due to a particular amino acid difference on these receptor subtypes—nicotinic acetylcholine receptors (nAChRs)
- nAChRs are part of this parasympathetic chain—which we think of as being a relaxing or down regulating part of the autonomic nervous system

***Nesbitt’s Paradox***

- Nicotine is unusual in comparison to most drugs, as its profile changes from [stimulant](https://en.wikipedia.org/wiki/Stimulant) to [sedative](https://en.wikipedia.org/wiki/Sedative) with increasing [dosages](https://en.wikipedia.org/wiki/Dose_(biochemistry)), a phenomenon known as “Nesbitt’s paradox” after the doctor who first described it in 1969
- At very high doses it dampens neuronal activity. Nicotine induces both behavioral stimulation and anxiety in animals. (Generally, stimulation at lower doses, anxiety at higher doses; anxiety during chronic dosing; anxiety from withdrawal of nicotine.)

*Where in the brain do these things bind? Do we know what part of the brain?*

- Results from the meta-analysis suggest that nicotine’s enhancing effects are due to its expression of nicotinic acetylcholine receptors (nAChRs) in the peripheral musculature, striatum (part of [basal ganglia](https://en.wikipedia.org/wiki/Basal_ganglia); responsible for voluntary movement), and motor cortex
  - These nicotinic acetylcholine receptors are also in the periphery, meaning things occur in the peripheral musculature, but it’s still unclear whether there are any effects on performance in the periphery like an increase in contractility or increase in relaxation of the peripheral musculature
  - What we do know is that it has an effect centrally in the striatum—which is the part of the basal ganglia and is responsible for voluntary movement (along with the motor cortex)
- Nicotine binds to “presynaptic” nicotinic acetylcholine receptors (nAChRs) in the brain
  - What we mean by presynaptic and postsynaptic…You have a space between neurotransmitters and so the pre-synoptic area will often release a neurotransmitter that then goes through this space to a postsynaptic receptor where its effect is mediated
  - So it binds to this presynaptic nicotinic acetylcholine receptors in the brain and then it facilitates the release of acetylcholine—generally a parasympathetic neurotransmitter— dopamine, serotonin glutamate and others
    - Serotonin is a neurotransmitter that’s associated with mood and depression—more serotonin is better, but it’s also quite calming and sedating
    - Dopamine is very pleasurable
  - “*It seems to me that that starts to explain a lot of the effects that these things have in the brain*.” says Peter
- W*hat do we think is happening in terms of the* ***prefrontal cortex*** *and other parts of the brain that might impact* ***decision making, memory, etc.***?
  - the parietal cortex, the thalamus, the hippocampus, all of these areas seem to have relatively high densities of these receptors
  - In other words, these receptors are quite ubiquitous in the brain
  - All those things are involved with the attention and memory
  - you have so many of these receptors concentrated in parts of the brain that explain some of these things
  - Obviously, the hippocampus play such an important role in memory consolidation
  - the prefrontal cortex plays a role in even judgment and very high order processing
- Alerting and arousal—
  - the alerting and arousal part of the network focuses on the locus coeruleus, and that’s in the ponds of a brain stem
  - that’s actually a part of the brain that secretes norepinephrine and epinephrine as their primary neurotransmitter

> “The more you and I dug into this, I think the more we were surprised to see a panoply of neurotransmitters that were effectively released by nicotine binding to the nicotinamide acetylcholine receptors, which I think starts to explain a lot of what we saw across those performance domains.” —Peter Attia

## How modafinil and other nootropics compare to nicotine [47:15]

Modafinil has been mentioned in previous AMA ([#4](https://peterattiamd.com/ama04/) and [#7](https://peterattiamd.com/ama07/)) as well as in the [AMA with Dom D’Agostino](https://peterattiamd.com/domdagostinoama01/)

[**Modafinil**](https://en.wikipedia.org/wiki/Modafinil)

- A lot of researchers are not really sure about the mechanisms of action of modafinil
- Modafinil is doing something similar but not necessarily to the same receptor, says Peter
- Modafinil is actually a pretty potent antidepressant (not at all its indication)
- Modafinil is a drug that was approved in ~1996 for narcolepsy
- Today, it’s become much more commonly used as a nootropic

Studies

- Several studies (like [1](https://pubmed.ncbi.nlm.nih.gov/10923755/), [2](https://onlinelibrary.wiley.com/doi/full/10.1111/j.1365-2869.2008.00654.x), [3](https://onlinelibrary.wiley.com/doi/pdf/10.1197/j.aem.2005.08.013)) have looked at performance metrics during sleep deprivation comparing those on modafinil to those on placebo
- Not surprisingly, the placebo group saw a pretty significant reduction in performance
  - Look no further than the [discussions with Matt Walker](https://peterattiamd.com/matthewwalker3/) where they talk about sleep deprivation’s impact on performance
- Caffeine also helps to some degree (the effects of this would be through inhibiting the ability of adenosine to bind to adenosine receptors)
- But nothing compares to the groups on modafinil (200 mg and 600mg)

*Peter’s use of modafinil in med school*

- “*For that reason, me and many of my co-residents were relying pretty heavily on Modafinil during our training when you would need to be at the time, this is no longer the case, but at the time it was not uncommon to be awake for 36 hours at a time*”
- “You’d be operating after not sleeping for 24 to 36 hours where obviously making mistakes is unacceptable.”
- Peter no longer uses modafinil
- He personally never “felt” anything from Modafinil.

**Modafinil vs nicotine**:

- There is clearly a sensation that one feels from nicotine, and we’ve talked about that at length
- Another interesting tidbit is the antidepressive properties of Modafinil, says Peter, which also mediated through norepinephrine, epinephrine, potentially serotonin
- That’s not really that surprising when you consider that two very successful classes of antidepressants are—
  - i) SSRIs, selective serotonin reuptake inhibitors. These are drugs that selectively inhibit the reuptake of serotonin there by leaving more serotonin around in this post-synaptic space
  - ii) SNRIs, selective norepinephrine reuptake inhibitors

*Another thing…*

- To Peter’s knowledge, Modafinil has never been demonstrated to show cognitive improvements in the performance metrics for people who are **not** sleep deprived
- In other words, it only rises to the level of being a true nootropic if you are sleep deprived.
- And that is different from nicotine
- Nicotine has a benefit in people who are not sleep deprived

*Looking at the notes from* [*AMA #4*](https://peterattiamd.com/ama04) *about modafinil*:

- About 10% of people are stimulated by modafinil, but about 90% of people they don’t really feel anything other than not being tired
- They also don’t have difficulty going to bed the next night

**Final thoughts**:

- Peter says: “*In our practice, we have some patients who do use Modafinil, and we are pretty quick to monitor how their sleep function is…*
- *…When we see reductions in sleep performance, even if they’re not feeling any activation from the Modafinil, we’re pretty quick to cut the dose down*”
- Peter does NOT encourage patients to use modafinil as a nootropic
- He also greatly discourages patients from using [adderall](https://en.wikipedia.org/wiki/Adderall) as a nootropic

## How nicotine may induce weight loss [54:00]

- Anecdotally, many smokers say once they quit smoking, they tend to gain weight
- There’s studies to suggest that that’s not just anecdotal
- Studies looked at how much do smokers weigh on average and then they looked at what type of weight gain do they see when they actually quit?
- When they quit smoking, they’re gaining the weight that they lost from the smoking – so part of this actually could be a weight loss effect of the nicotine itself included in the smoking
- One of the studies said that about 1 in 10 gained former smokers gained more than 30 pounds as well – So that might actually go beyond the amount of weight that they lost in the first place

**Interesting facts**

- Smokers weigh on average ~ 6-10 lb less than nonsmokers
- When they quit, they gain that weight back, and ~ 1-in-10 gain > 30 lb
- Quitters only eat more in the first 2-3 weeks
- After ~ 1 month, they’re eating no more than they did when they smoked
- Smokers who quit and then gain weight apparently consume no more calories than those who quit and do not gain weight.
- Smokers also tend to be less active and exercise less than nonsmokers (so differences in physical activity also fail to explain the weight gain associated with quitting)

Peter’s comments —

- It’s interesting in the smoker’s weigh on average 6 to 10 pounds less than nonsmokers AND they tend to be less physically active and exercise less
- it also appears that after about a month of quitting, smokers are not eating more than when they smoked
- “*So what else can be accounting for this weight loss?*”

**Potential mechanisms of nicotine conferring weight loss:**

*Studies are looking at a few things—*

- insulin resistance, particularly insulin resistance at the fat tissue or the fat cell
- They looked at the LPL (lipoprotein lipase) activity at the fat cell and muscle cell
- HSL (hormone sensitive lipase) activity at the fat cell

*Study findings*:  [[source](https://pubmed.ncbi.nlm.nih.gov/2114991/)]

- ↑ adipocyte insulin resistance (inhibits fat accumulation in adipocytes)
- ↓ adipocyte LPL activity (inhibits fat accumulation in adipocytes)
- ↑ adipocyte HSL activity (promotes fat mobilization), and lipolysis (i.e., mobilization of fatty acids), more FFAs available
- ↑ muscle LPL activity (promotes fat uptake in muscles)

Note: Good time to go back and check out [AMA #22: Losing fat and gaining fat: the lessons of fat flux](https://peterattiamd.com/ama22/)  – detail about what regulates the movement of free fatty acids and triglycerides into and out of adipose tissue

*What nicotine is doing*:

- If nicotine reduces LPL activity, lipoprotein lipase activity on a fat cell, that means it would inhibit fat accumulation
- If it increases hormone sensitive lipase activity, which is inside the fat cell, then it’s promoting fat mobilization, which means it’s breaking down triglycerides into free fatty acids
- It’s also increasing lipolysis, which means the mobilization of the fatty acid, which renders more free fatty acids available.

*The other thing it’s doing…*

- Nicotine is acting in the periphery by increasing muscle lipoprotein lipase activity
- So if in the fat cell you’re driving down LPL, it means you’re **bringing less fat into a fat cell**
- And if you increase LPL at a muscle cell, it means you’re **making more fat available to the muscles for utilization**

This begs the question… *If you just increased LPL activity at a fat cell, could that be a bad thing if you’re not active? Couldn’t that just bring more fat into a fat cell, which obviously kicks off this cascade of insulin resistance? Therefore, simply increasing LPL activity at a fat cell doesn’t necessarily imply a good thing.*

- It depends, says Bob
- It sounds counterintuitive, but if somebody’s in the dynamic phase of obesity—meaning they are gaining weight—so let’s say somebody that is in the process of gaining 30 pounds over 10 years
- If you’re looking at the early stages of that where they’re in this dynamic phase that they’re gaining the weight
- Let’s say that their LPL activity has increased and they’re putting fat into fats into their fat cells—then their fat cells are *relatively insulin sensitive*
- But at some point, it reaches a point where the adipose side is actually resistant—and that’s part of the counterintuitive nature to some of this
- So with nicotine and weight loss they see insulin resistance at the fat cell, which a lot of people might think, “Well that’s a good thing, because I’m not getting fatter”
- But, as discussed in the [Shulman podcast](https://peterattiamd.com/geraldshulman/) and [AMA #20](https://peterattiamd.com/ama20/), people with lipodystrophy (they have no subcutaneous fat) just have a bunch of free fatty acids floating in the bloodstream and there’s nowhere to put them, that’s probably not the best thing in the world
- But in the case of nicotine, it’s interesting that we’re seeing this fuel partitioning
- So, yes, LPL activity on the adipose side is low and the HSL activity in the adipose side is higher, so there’s more **mobilization in these fatty acids**
- But when you combine that with the *increased activity in the muscle* from nicotine, the muscle’s taking up the free fatty acids in the muscle and it may be **oxidizing those fatty acids**
- Note: These studies found no difference in plasma insulin levels between smokers and nonsmokers

**Insights from looking at LPL in smokers**

- If you look at an oral glucose challenge in people, you see a decrease in LPL in the smokers
- But because you weren’t seeing a change in insulin, it was actually suggesting that their resistance to insulin at the adipose tissue was high — which again, if you’re going to have resistance to insulin anywhere you absolutely want it at the adipose tissue
- And this effect could be due to an increase in [catecholamines](https://en.wikipedia.org/wiki/Catecholamine), says Peter
- Many things impact that stage of getting fat out of the fat cells
- And hormone sensitive lipase is a very potent version of that but so are catecholamines
- So, again, it could be that catecholamines are playing a role here

> “It’s so fascinating to me frankly that one molecule found in nature can be so potent. It’s hard to imagine you could engineer a drug to do this.” —Peter Attia

*Should people looking to quit smoking use NRT?*

- It certainly makes the case for relying on some form of nicotine replacement if you’re quitting smoking, if you’re at a normal weight and you’re not looking to gain any weight.
- Obviously, there’s some people who are perhaps underweight.

## Relationship between smoking and COVID-19: Analyzing the observation that smoking appears protective against COVID-19 [1:01:45]

**A couple of interesting (and head scratching) trends**:

1—Patients with a smoking history may have fewer severe COVID-19 complications than non-smokers, but the evidence is limited and inconsistent, and

2—An unusually low prevalence of smoking observed among hospitalized COVID-19 patients

**What are some of the observations?**

- [France](https://www.qeios.com/read/article/569): a quarter of French adults smoke, yet only 5% of 482 COVID-19 patients who came to the hospital were active smokers.
- [US](https://www.ncbi.nlm.nih.gov/pubmed/31725711/): the CDC reported a prevalence of 1.3% of COVID-19 cases in current smokers; compare that to the 16.5% population smoking prevalence in the US. A separate analysis of 4103 lab-confirmed COVID-19 patients treated at NYC hospitals reported a 5.2% smoking prevalence (**about a quarter of what you would expect**)
- [Germany](https://www.ncbi.nlm.nih.gov/pubmed/32519944/): a case series of hospitalized COVID-19 patients found a smoking prevalence of about 6%; compare that to the 25% smoking prevalence in Germany.
- [China](https://harmreductionjournal.biomedcentral.com/articles/10.1186/s12954-020-00437-5): a meta-analysis of 7168 patients (482 of them being smokers) found that the proportion of hospitalized COVID-19 patients who reported being smokers was **approximately one quarter of the expected prevalence** based on smoking rates in China—44% and 4% for males and females, respectively.

> “Here, we look at four countries’ independent data. This is an unmistakable signal.” —Peter Attia

***Any reasons why smoking might actually be protective?***

[Is there a smoker’s paradox in COVID-19?](https://ebm.bmj.com/content/early/2020/08/11/bmjebm-2020-111492)

- **Protection against cytokine storm**: Nicotine could maintain or restore the function of the cholinergic anti-inflammatory system and thus control the release and activity of pro-inflammatory cytokines. This could prevent or suppress the cytokine storm. (Or may be more simply a blunted immune response in smokers.)
  - important to point out that a year ago this time, we didn’t really understand COVID at all. It was a respiratory virus that was killing people at a rate in excess of influenza, but we were treating it like it was influenza
  - Since that time, we’ve come to realize actually steroids play a very important role in treating people who are very sick with this, because it actually calms the immune system down
  - It’s important to understand, you only care about COVID in the cases where it’s hospitalizing people and potentially killing them.
  - In those cases, it seems that an overactive immune system was certainly playing part of a role, not the only role
  - Because if that were the only thing that was killing people, then young people would be more vulnerable,
  - but there’s an interesting issue, which is unhealthy people are clearly more vulnerable
  - and that seems to be due to the up regulation of basically the receptors that are allowing the virus to gain access to the tissues in the body
  - cytokine storm is just a fancy word for when immune cells release chemical signals to other immune cells to come to the party and join on and attack the cells that are infected by the virus, that can backfire and they can go overboard and actually kill the host
  - That mechanism—Protection against cytokine storm—makes sense if we believe that nicotine could be basically acting as an antiinflammatory agent that prevents that
- **Increased nitric oxide (NO) may inhibit SARS-CoV-2**: NO is produced during smoking and may inhibit replication and entry into cells; cigarette smoke contains NO (400-1000 p.p.m) and smoking decreases the concentration of exhaled NO (See Figure 2 below)
  - “This was news to me”, says Peter, “because nitric oxide is generally a very positive agent”
  - Nitric oxide dilates blood vessels
  - NO is a very important part of preserving endothelial health and coronary arteries
  - It speaks to what can only be described as the dialectical dilemma of smoking, which means it can simultaneously do something that is good and something that is bad

![](https://peterattiamd.com/wp-content/uploads/2021/05/f2-ama23-1024x899.png)

**Figure 2.** Effects of nicotine and nitric oxide (NO) from cigarette smoke on the nervous system and on airway and vascular tissue. Nicotine releases glutamate and dopamine from presynaptic terminals. Glutamate acts upon postsynaptic N-methyl-D-aspartate (NMDA) receptors (Rg), and allows calcium to enter and to activate neuronal nitric oxide synthase (nNOS) through calmodulin. NO then diffuses to other cells where it activates guanylate cyclase (GC) to produce cyclic guanosine-395-monophosphate (cGMP), which in turn causes vasodilatation or airway dilatation. Further, it inhibits the re-uptake of dopamine and its own synthesizing enzyme NOS. Inhaled NO from smoke has similar actions on the GC–cGMP pathway and causes airway dilatation and pulmonary vasodilatation, and desensitizes airway NOS…In particular, cigarette smoking decreases the concentration of exhaled NO as well as the concentration of NO metabolites in plasma, sputum cells, urine and nasal fluid. [[source](https://pubmed.ncbi.nlm.nih.gov/12215243/#:~:text=NO%20may%20contribute%20to%20the,levels%2C%20and%20(4)%20NOS)]

- **Possible mechanisms involving ACE2:**
  - **1) Nicotine may upregulate ACE2, which may diminish disease severity**: Increases cleavage of angiotensin 2, leading to local vasodilation and anti-inflammatory effect
  - **2) Nicotine may downregulate ACE2, which may decrease risk of infection**: decreases risk of SARS-CoV-2 attachment and risk of infection
    - Nicotine might [bind](https://www.cebm.net/covid-19/nicotine-replacement-therapy/#:~:text=Nicotine%20may%20bind%20with%20the,of%20ACE2%20in%20multiple%20organs) to the ACE2 receptor, and this may compete with the virus ([preprint](https://arxiv.org/abs/2004.14943))
  - Peter asks: Is this something that we think is one or the other or it can be doing both at different times?
    - It’s confusing, says Bob, because you run down a list of hypotheses and these are completely counter right that it may up regulate ACE2 or it may down regulate ACE2
    - And the question is whether it can do both or if it’s doing one or the other?
    - This was something that was understood very early in the pandemic, which was that ACE2 plays an important role in the virus actually getting into the cell
    - So it would make sense that if nicotine down regulates ACE2, that would decrease the likelihood that the virus is going to make its way into the cell
    - Conversely if nicotine upregulates ACE2 perhaps later on, that could diminish the severity of the infections

*What are some possible methodological flaws with this data suggesting smoking protects against severe COVID?*

- Most studies don’t report the duration or frequency of smokers, or former smokers (many might have quit in the recent past);
- While using the general population as a control is convenient and offers some insight, the COVID-19 population likely has a different distribution of age, sex, comorbidities and smoking patterns;
- It’s difficult to get accurate history from patients who are either intubated or in respiratory failure (speaks to the cases that are more severe. It’s very difficult to get an understanding about their smoking history. There could be some poor data quality there.)
- If data from these patients are missing, and these patients are not removed from the denominator, it can give a false impression that smokers are less likely to develop severe disease.

![](https://peterattiamd.com/wp-content/uploads/2021/05/f3-ama23-1024x885.png)

**Figure 3.** Proposed mechanisms of interaction between smoking and COVID-19. [[source](https://ebm.bmj.com/content/early/2020/08/11/bmjebm-2020-111492)]

**An interesting thought**:

- No data on this, but would be interesting if you looked at people (like Peter) who have never smoked and are otherwise healthy, but would use nicotine for other reasons (like cognitive benefits)
- The idea would be to identify how much of this protection against COVID is the nicotine versus the smoking
- Important to note that with respiratory viruses and influenza, smoking is clearly a risk factor
- With that in mind, the CDC originally listed risk factors for severe COVID to be diabetes, hypertension, and cardiovascular disease and they also listed smoking just because it’s generally a risk factor for all the other respiratory viruses.
- Then with this data, it makes it a little bit more questionable
- Makes you wonder if you have healthy people using nicotine as a nootropic, could they possibly be getting more upside with nicotine and less downside?

## Breakdown of the various nicotine replacement therapies: route of administration, dosing, and safety [1:11:30]

**NRT comes in many forms: patch, gum, lozenge, inhaler, and nasal spray.**

Other products can function as alternative nicotine delivery systems, but are not FDA-approved as NRTs, which include snus (i.e., dip), [pouches](https://en.wikipedia.org/wiki/Nicotine_pouch), [toothpicks](https://ascpt.onlinelibrary.wiley.com/doi/abs/10.1038/clpt.1991.164), and e-cigarettes. (A 2019 randomized [trial](https://www.nejm.org/doi/full/10.1056/nejmoa1808779) found e-cigarettes were more effective for smoking cessation than NRTs.)

**Let’s look at some of these NRTs: route of administration, dosing, and safety**

- Cigarettes
  - **ROA**: rapid and high levels of arterial nicotine achieved when cigarette smoke is inhaled. (12) All the available medicinal nicotine products rely on systemic venous absorption and do not therefore achieve such rapid systemic arterial delivery. (13) It takes a few seconds for high doses of nicotine from a cigarette to reach the brain; medicinal products achieve lower levels over a period of minutes (for nasal spray or oral products such as gum, inhalator, sublingual tablet, or lozenge) and hours (for transdermal patches). (13)
  - **Dose**: Delivers about 1 mg nicotine per cigarette
  - **Safety**: looks like no bueno
- [E-cigarettes](https://www.nature.com/articles/srep04133) (vaping) [not an FDA-approved NRT]
  - **ROA**: vaporize and deliver chemical mixture typically composed of nicotine to the lungs of the user. By using this device, nicotine is delivered to the upper and lower respiratory tract without any combustion involved.
  - **Dose**: Nicotine content varies widely among products, typically ranging between 0 and 34 mg/mL: ~ 18 mg/mL is roughly 1 mg of nicotine delivered (= 1 cigarette)
  - **Safety**: The FDA has reported that e-cigarette cartridges and solutions contain potentially harmful components and they recommend that the sale of e-cigarettes should be prohibited or regulated as dangerous nicotine delivery systems.
- Chewing tobacco (and [dip](https://academic.oup.com/ntr/article/15/1/255/1112360))
  - **ROA**: nicotine is [absorbed](https://www.swedishmatch.com/Snus-and-health/Research-on-snus/Nicotine-uptake/) via the buccal mucosa. The uptake via the mucous membrane is slower than the uptake via the lungs during smoking.
  - **Dose**: [0-20%](https://www.swedishmatch.com/Snus-and-health/Research-on-snus/Nicotine-uptake/) of the nicotine present in a pinch of snus is absorbed via the mucous membrane and reaches the systemic circulation. This means that only 1-2 mg of nicotine is absorbed into the blood from a one gram pinch containing ca 10 mg of nicotine.
  - **Safety**: [FDA](https://www.fda.gov/news-events/press-announcements/fda-grants-first-ever-modified-risk-orders-eight-smokeless-tobacco-products): “Using General Snus instead of cigarettes puts you at a lower risk of mouth cancer, heart disease, lung cancer, stroke, emphysema, and chronic bronchitis.” [Associated](https://docs.google.com/document/d/1OuteW1GwNVPFF8109SmRPNP9QT0qWvopTSmgQ6hJX90/edit?usp=sharing) with a higher risk of oral and pharynx cancer by ~70% (~0.7% increase; 1% vs 1.7% lifetime risk in never users vs smokeless tobacco users, respectively)
- Transdermal [patch](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5003586/)
  - **ROA**: It delivers nicotine more slowly than acute NRT formulations, although nicotine plasma concentrations can get higher during the day with patch use than with acute NRT use. (18)
  - **Dose**: They are available in different doses, and deliver between 5mg and 22mg of nicotine over a 24-hour period, resulting in plasma levels similar to the trough levels seen in heavy smokers. (11)
  - **Safety**: Current evidence supports the safety of long-term use of nicotine patch treatment for tobacco abstinence. The most frequently reported side effects are local skin reactions (11) and Sleep disturbances have also been commonly reported with 24-hour patches. (13)
- [Gum](https://academic.oup.com/ntr/article/15/1/255/1112360)
  - **ROA**: The first NRT that was made available to consumers was transmucosally delivered nicotine polacrilex (nicotine gum).
  - **Dose**: It is available in both 2 mg and 4 mg dosage forms.18
  - **Safety**: in general well tolerated and have minimal adverse effects.
- [Lozenge](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5003586/)
  - **ROA**: As with nicotine gum, nicotine from the lozenge is absorbed slowly through the buccal mucosa and delivered into systemic circulation. (13)
  - **Dose**: The amount of nicotine absorbed per lozenge appears to be somewhat higher than that delivered by gum. (21)
  - **Safety**: in general well tolerated and have minimal adverse effects.
- [Inhaler](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5003586/)
  - **ROA**: although termed an “inhaler” the majority of nicotine is delivered into the oral cavity (36%) and in the oesophagus and stomach (36%). (22, 23) Very little nicotine is delivered to the lung (4%). Because absorption is primarily through the oral mucosa, the rate of absorption is similar to that of nicotine gum.
  - **Dose**: Each inhaler cartridge contains 10mg nicotine, of which up to 4 mg can be delivered and 2 mg can be absorbed following frequent “puffing”. (24)
  - **Safety**: in general well tolerated and have minimal adverse effects.
- [Nasal](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5003586/) spray
  - **ROA**: Each dose consists of two squirts, one to each nostril. (11, 24) Nicotine nasal spray is absorbed into the blood rapidly relative to all other NRT forms.(25)
  - **Dose**: delivers 0.5 mg of nicotine per 50-uL squirt.
  - **Safety**: in general well tolerated and have minimal adverse effects.

## Concluding thoughts on nicotine: use cases, addictive properties, and more [1:19:45]

**So how confident are we that nicotine is indeed a cognitive enhancer and even a performance enhancer?**

- Fairly confident, says Bob
- Would like to see more studies looking specifically at nicotine separate from smoking

**Caution**:

- The biggest drawback to the use of safe versions of nicotine is the addictive nature of it
- If you are a person who is going to be easily addicted to something, then one has to consider not using this or being very cautious with it

§

## Selected Links / Related Material

**The US Surgeon General reports inadequate evidence to infer a causal relationship between nicotine exposure and risk for cancer**: [The Health consequences of smoking—50 years of progress : a report of the Surgeon General](https://stacks.cdc.gov/view/cdc/21569/Share) | (cdc.gov) [7:00]

**In the U.S. Department of Health’s list of 69 potential and known carcinogens in cigarettes, nicotine is not one of them**: [Harms of Cigarette Smoking and Health Benefits of Quitting](https://www.cancer.gov/about-cancer/causes-prevention/risk/tobacco/cessation-fact-sheet) | (cancer.gov) [7:30]

**Peter’s many articles on the topic of red meat**: [9:00]

- [Is ditching meat a “game-changer” for your health?](https://peterattiamd.com/191027/) | Peter Attia (peterattiamd.com)
- [Is red meat killing us?](https://peterattiamd.com/is-red-meat-killing-us/) | Peter Attia (peterattiamd.com)
- [The red meat and plant-based recommendation wars](https://peterattiamd.com/the-red-meat-and-plant-based-recommendation-wars/) | Peter Attia (peterattiamd.com)
- [Red meat, cancer, push-ups, and CVD](https://peterattiamd.com/red-meat-cancer-push-ups-and-cvd/) | Peter Attia (peterattiamd.com)

**The Cochrane Collaboration’s review which found high quality evidence that NRT increases the chances of successfully quitting smoking by about 50% to 60%**: [Nicotine replacement therapy versus control for smoking cessation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6353172/) (Hartmann-Boyce et al., 2018) [10:15]

**Recent smoking stats in the US say 13% to 15% of American above 18 years old smoke**: [Prevalence of tobacco use](https://en.wikipedia.org/wiki/Prevalence_of_tobacco_use#:~:text=fallen%20to%2019%25.-,United%20States,8.7%20million)%20smoked%20some%20days.) | (wikipedia.org) [14:15]

**Episode of The Drive with Nir Barzilai**: [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) | Peter Attia (peterattiamd.com) [14:45]

**2010 meta analysis on the benefits of nicotine**: [Meta-analysis of the acute effects of nicotine and smoking on human performance](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3151730/) (Heishman et al., 2010) [16:00, 30:30]

[Posner task test](https://www.psytoolkit.org/experiment-library/cueing.html) [24:30]

**Richard Isaacson’s Alzheimer’s disease prevention clinic**: [Alzheimer’s Prevention Clinic](https://weillcornell.org/services/neurology/alzheimers-disease-memory-disorders-program/our-services/alzheimers-prevention-clinic) | (weillcornell.org) [26:15]

**Documentary about Ayrton Senna, the greatest F1 driver of all time**: [Senna](https://en.wikipedia.org/wiki/Senna_(film)) | (wikipedia.org) [35:45]

**The phenomenon known as Nesbitt’s Paradox where nicotine becomes a sedative at a certain level**: [Smoking, physiological arousal, and emotional response](https://pubmed.ncbi.nlm.nih.gov/4688163/) (Nesbitt, 1973) [40:40]

**Previous episode of The Drive that discussed modafinil**: [47:15]

- [#45 – AMA #4: sleep, jet lag protocol, autophagy, metformin, and more](https://peterattiamd.com/ama04/) | Peter Attia (peterattiamd.com)
- [#63 – AMA #7: Exercise framework, deadlifting, lower back pain, blood pressure, nootropics, CGM, and more](https://peterattiamd.com/ama07/) | Peter Attia (peterattiamd.com)
- [#116 – AMA with Dom D’Agostino, Ph.D., Part I of II: Ketogenic diet, exogenous ketones, and exercise](https://peterattiamd.com/domdagostinoama01/) | Peter Attia (peterattiamd.com)

**Studies looking at modafinil and its ability to stave off sleep deprivation and maintain or increase performance**:

- [A double-blind, placebo-controlled investigation of the efficacy of modafinil for sustaining the alertness and performance of aviators: a helicopter simulator study](https://pubmed.ncbi.nlm.nih.gov/10923755/) (Caldwell et al., 2000) [48:15]
- [Effects of dextroamphetamine, caffeine and modafinil on psychomotor vigilance test performance after 44 h of continuous wakefulness](https://onlinelibrary.wiley.com/doi/full/10.1111/j.1365-2869.2008.00654.x) (Killgore et al., 2008)
- [Cognitive Performance Following Modafinil versus Placebo in Sleep-deprived Emergency Physicians: A Double-blind Randomized Crossover Study](https://onlinelibrary.wiley.com/doi/pdf/10.1197/j.aem.2005.08.013) (Gill et al., 2006)

**Episode of The Drive with sleep expert Matt Walker where they discuss sleep deprivation’s impact of performance**: [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/) | Peter Attia (peterattiamd.com) [49:15]

**Study looking at the mechanisms of nicotine conferring weight loss**: [Smoking depresses adipose lipoprotein lipase response to oral glucose](https://pubmed.ncbi.nlm.nih.gov/2114991/) (Chajek-Shaul et al., 1990) [55:45]

**AMA episode about how fat enter and exits a cell**: [AMA #22: Losing fat and gaining fat: the lessons of fat flux](https://peterattiamd.com/ama22/) | Peter Attia (peterattiamd.com) [56:15, 1:00:30]

**Episode of The Drive with Gerry Shulman discussing insulin resistance**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) [57:45]

**AMA episode discussing insulin resistance**: [#149 – AMA #20: Simplifying the complexities of insulin resistance: how it’s measured, how it manifests in the muscle and liver, and what we can do about it](https://peterattiamd.com/ama20/) | Peter Attia (peterattiamd.com) [59:15]

**Statistics on smoking and COVID**: [1:01:45]

- **France**: a quarter of French adults smoke, yet only 5% of 482 COVID-19 patients who came to the hospital were active smokers: [Low incidence of daily active tobacco smoking in patients with symptomatic COVID-19](https://www.qeios.com/read/article/569) (Makoto Miyara et al., 2021)
- **US**: the CDC reported a prevalence of 1.3% of COVID-19 cases in current smokers; compare that to the 16.5% population smoking prevalence in the US. A separate analysis of 4103 lab-confirmed COVID-19 patients treated at NYC hospitals reported a 5.2% smoking prevalence (**about a quarter of what you would expect**): : [Tobacco Product Use and Cessation Indicators Among Adults – United States, 2018](https://www.ncbi.nlm.nih.gov/pubmed/31725711/) (Creamer et al., 2019)
- **Germany**: a case series of hospitalized COVID-19 patients found a smoking prevalence of about 6%; compare that to the 25% smoking prevalence in Germany: The Characteristics of 50 Hospitalized COVID-19 Patients With and Without ARDS (Dreher et al., 2020)
- **China**: a meta-analysis of 7168 patients (482 of them being smokers) found that the proportion of hospitalized COVID-19 patients who reported being smokers was **approximately one quarter of the expected prevalence** based on smoking rates in China—44% and 4% for males and females, respectively: [Smoking prevalence among hospitalized COVID-19 patients and its association with disease severity and mortality: an expanded re-analysis of a recent publication](https://harmreductionjournal.biomedcentral.com/articles/10.1186/s12954-020-00437-5) (Konstantinos Farsalinos et al., 2021)

**Smoker’s paradox paper investigating why smokers get less severe COVID**: [Is there a smoker’s paradox in COVID-19?](https://ebm.bmj.com/content/early/2020/08/11/bmjebm-2020-111492) (Shariq Usman et al., 2020) [1:04:30]

§

## People Mentioned

- [Nir Barzilai](https://www.afar.org/nir-barzilai) [14:45]
- [Richard Isaacson](https://peterattiamd.com/richardisaacson/) [26:15]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) [35:45]
- [Matthew Walker](https://psychology.berkeley.edu/people/matthew-p-walker) [49:15, 53:00]
- [Kirk Parsley](https://docparsley.com/about/) [53:00]
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald_shulman/) [57:45]

§