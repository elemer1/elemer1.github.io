# #69 – Ronesh Sinha, M.D.: Insights into the manifestation of metabolic disease in a patient population predisposed to metabolic syndrome, and what it teaches us more broadly

**Source:** [https://peterattiamd.com/roneshsinha/](https://peterattiamd.com/roneshsinha/)

---

In this episode, Dr. Ronesh Sinha, a physician, author, and educator based in Silicon Valley, shares his many insights into metabolic illness that he has gleaned from his South Asian patient population. In this conversation we focus on hyperinsulinemia, insulin resistance, metabolic dysregulation, inflammation, blood pressure, obesity, etc. and ways to address them with nutrition, sleep, exercise, stress management, and more. We also take a deep dive into insulin resistant phenotypes, evolutionary theory and geographic determinants of insulin resistance which provides insight into the genetic architecture and pathophysiology of metabolic syndrome. Additionally, we discuss the surprisingly interrelated topic of stress, and how we might be inadvertently passing this on to our children, leading to mental and physical sickness down the road.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/roneshsinha/the_Drive_public.png)

Play

#69 - Ronesh Sinha, M.D.: Insights into the manifestation of metabolic disease in a patient population predisposed to metabolic syndrome, and what it teaches us more broadly

#69 - Ronesh Sinha, M.D.: Insights into the manifestation of metabolic disease in a patient population predisposed to metabolic syndrome, and what it teaches us more broadly

1x15s30s

0:001:59:15

## We discuss:

- How a stubborn case of insulin resistance connected Peter with Ronesh [7:15];
- Ronesh’s clinical treatment focus of metabolic illnesses in South and East Asian patient populations [8:45];
- The distinction between visceral fat and subcutaneous fat stores [15:00];
- Shortcomings of a body mass index (BMI) calculator for evaluating metabolic disease risk [17:15];
- Cortisol and blood glucose variability [28:30];
- Insulin’s role in elevated blood glucose: A symptom of metabolic syndrome [33:25];
- Mechanistic explanations of insulin resistance (there may be more than one) [35:15];
- Theories on origins and evolutionary reasons for insulin resistance [40:00];
- The inverse relationship between the amount of brown adipose tissue and rates of insulin resistance, and the role of climate in patterns and prevalence of insulin resistance [49:50];
- Vitamin D levels, hyperinsulinemia, and other effects [53:45];
- The evolutionary benefit of being able to turn fructose into fat (and the price we are now paying for it) [58:00];
- The VO2 max relationship to insulin resistance and familial metabolic health [59:30];
- Using zone 2 fitness test to evaluate mitochondrial performance [1:01:15];
- Exercise for long-term functional health [1:06:00];
- Lifestyle changes to improve insulin resistance and other metabolic phenotypes [1:14:00];
- Is PCOS a manifestation of insulin resistance? [1:21:00];
- The impact of stress on adiposity, and Peter’s treatment regimen for overweight females resistant to typical nutritional approaches [1:23:45];
- How a culture of achievement and expectations can lead to undue stress, unhappiness, and health problems in our children (a Silicon Valley case study) [1:35:00];
- The negative impact of devices and social media on children [1:48:45];
- How you can help yourself, your family, and your community without being an MD or PhD [1:55:00]; and
- More.

§

## Show Notes

## How a stubborn case of insulin resistance connected Peter with Ronesh [7:15]

**How Peter and Ron connected**:

- Peter had a patient from India who had an unusually stubborn case of insulin resistance
- There was something about it that looked a little different from the usual hyperinsulinemia (there was an “impressive degree” of inflammation)
- This particular case led Peter to Ron’s book, [The South Asian Health Solution](https://www.amazon.com/South-Asian-Health-Solution-Culturally/dp/1939563054/ref=sr_1_1?crid=NUNKXXCROAHA&keywords=south+asian+health+solution&qid=1567036762&s=gateway&sprefix=south+asian+%2Caps%2C196&sr=8-1)
- Peter and Ron eventually connected (thanks to an introduction by [Mark Sisson](https://twitter.com/Mark_Sisson))

## Ronesh’s clinical treatment focus of metabolic illnesses in South and East Asian patient populations [8:45]

- In medical training, diabetes and cardiovascular disease case studies are typically African American, Caucasian, history of smoking, etc.
- Based in the  [Bay Area](https://wikitravel.org/en/Bay_Area_(California))/ [Silicon Valley](https://en.wikipedia.org/wiki/Silicon_Valley),  East and South Asian heritage were predominant population with early onset or family history of diabetes
  - Realized there was a gap in resources between how physicians are educated and the populations most afflicted with metabolic diseases (e.g., insulin resistance, diabetes, cardiovascular disease)
  - Decided to create East and South Asian population-specifi[c educational materials and protocols](https://culturalhealthsolutions.com/)
- Around the same time, Ronesh personally developed [metabolic syndrome](https://en.wikipedia.org/wiki/Metabolic_syndrome)
- Prompted him to step outside nutrition guidelines and look more closely at insulin resistance
  - He was following low fat, low-calorie model diet (eating meat, fish, healthy starch [Bengal](https://en.wikipedia.org/wiki/Bengal)-style diet of his heritage)
- Gradually tinkered with personal and patient macronutrient meal composition
  - Tracked [triglycerides (TGs)](https://en.wikipedia.org/wiki/Triglyceride) between making changes
  - Patients had high carbohydrate diet
  - Relationship between carbohydrate (CHO) and fat revealed that high triglycerides (a.k.a: blood fat) were **not reduced by a low fat diet**
  - Cut down on dietary CHO and prescribed more liberal dietary fat intake
- By contrast, African American patients can present with normal TGs and have diabetes
  - Prompted Ronesh to look at patient habitus
    - South and East Asian patients had slender limbs with less lean body mass
    - Lean body mass allows for the ability to process TGs
    - The population he treats has a high degree of visceral fat
      - Significantly higher proportion of visceral to subcutaneous fat
      - High visceral fat is responsible for the degree of inflammation seen in insulin resistance at low body weight

## The distinction between visceral fat and subcutaneous fat stores [15:00]

- Three classifications of fat:

1. Superficial [subcutaneous fat](https://en.wikipedia.org/wiki/Adipose_tissue#Subcutaneous_fat) (adipose) tissue (SSCAT)
2. Deeper layer of subcutaneous adipose tissue (DSCAT), right underneath the skin
3. [Visceral fat](https://en.wikipedia.org/wiki/Adipose_tissue#Visceral_fat)

![](https://peterattiamd.com/wp-content/uploads/2019/08/figure-1-ronesh-300x288.png)

**Figure 1.** **East and South Asian populations have more adipose tissue stored as VAT rather than as “safety belt” subcutaneous fat, putting them at higher risk for metabolic disease.** Image credit: ([health.harvard.edu](https://www.health.harvard.edu/staying-healthy/taking-aim-at-belly-fat))

*The city versus suburb analogy for subcutaneous and visceral fat*

> “The way I explain it to people is think of sort of a city versus a suburb. So the subcutaneous fat is really out in the suburbs, the superficial. The deep is a little bit further in, so this could be basically South San Francisco and the visceral is basically around the organs.”

- The subcutaneous or “suburban” fat structures are organized and have less access to blood supply
  - Ronesh considers this safeguard against having deeper tissue fat stores
  - These fat stores are more inert, with little [Free Fatty Acids (FFAs)](https://en.wikipedia.org/wiki/Fatty_acid) flux in and out of fat cells (responsible for inflammation)
- Deeper tissue subcutaneous fat and visceral fat are less organized and have access to blood supply and to the liver
  - High degree of [Transmembrane flux](https://en.wikipedia.org/wiki/Fatty_acid-binding_protein)
  - And a resulting presence of inflammatory mediators such as [Adipokines](https://en.wikipedia.org/wiki/Adipokine) and inflammatory chemicals
- Ronesh wrote a [blog post](https://culturalhealthsolutions.com/wheres-your-body-fat-a-look-at-body-shapes-and-health-risks-across-different-ethnic-groups-indians-asians-caucasians-etc/) about types of adipose tissue, ethnic-specific fat storage, and the health risks that visceral fat stores confer to the Asian population

## Shortcomings of a body mass index (BMI) calculator for evaluating metabolic disease risk [17:15]

- Body type of South and East Asian men and women exemplify how physical appearance does not necessarily indicate metabolic health ([Body mass index (BMI) calculator](https://en.wikipedia.org/wiki/Body_mass_index) would not be an accurate indication for metabolic health)
  - Men are typically thin and skinny but metabolic markers are elevated (“[Skinny fat](https://en.wikipedia.org/wiki/TOFI)”)
  - Women may have more subcutaneous but metabolic markers like TGs and HDL-C are healthy
  - Typically in men, unlike for women, the lack of subcutaneous fat insulation means that fat is predominantly stored as visceral fat
- A [study](https://science.sciencemag.org/content/341/6148/856) by [Mitch Lazar](https://www.med.upenn.edu/lazarlab/) that evaluated a combination resulting in four phenotypes: lean/overweight body weight with healthy/non-healthy metabolic markers, concluded that lean individuals with elevated metabolic markers had the worst outcomes (compared to overweight individuals who were also metabolically ill)
- The combination of higher proportion of subcutaneous fat stores and larger leg muscles facilitate lipid metabolization
  - Considering the [lipid overflow hypothesis](https://www.cell.com/trends/endocrinology-metabolism/pdf/S1043-2760(03)00192-9.pdf) first proposed by [Roger Unger](https://en.wikipedia.org/wiki/Roger_Unger)– in which fat storage is favored from subcutaneous to deep subcutaneous then lastly, visceral fat stores – larger subcutaneous fat stores insulate the body
  - Larger leg muscles in heavier individuals help process lipids
  - [South Asians are predisposed to insulin resistance](https://pdfs.semanticscholar.org/a1bd/9b40f4cb5007bee39fd2a7b9b2d07884229b.pdf) in part due to visceral fat storage

*Does Ronesh observe an association between patient TGs and their glycemic numbers?*

- Perhaps because patients are still in early stages but elevated TGs does not always present with glycemic impact (high blood glucose)
- Ronesh refers to these patients as pre-prediabetic
  - [Fatty liver](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease), elevated TGs, often with a family history of diabetes, but their  glucose levels are fine ([glucose tolerance](https://www.joslin.org/info/diagnosing_impaired_glucose_tolerance_IGT.html))
    - \*Ronesh wrote a [detailed blog post](https://culturalhealthsolutions.com/is-your-liver-fat/) on fatty liver in adults and kids\*
  - Important population to educate before becoming prediabetic: they still have preserved beta-cell function (as opposed to [Beta-cell failure](https://www.ncbi.nlm.nih.gov/pubmed/18777097)) and [Hyperinsulinemia](https://en.wikipedia.org/wiki/Hyperinsulinemia)
  - When tested, usually present with high fasting insulin levels

> “ …I absolutely get the ones that come in with full blown prediabetes or type two diabetes and triglyceride, but I’d say the majority of the population that I see, they’ve already got fatty liver, they’ve got high triglycerides, but their glucose looks fine. And that is a really important population to really educate because I’m telling them now that you don’t have prediabetes, you have pre-prediabetes and this is where we can make the most impact..”

**The difficulty in developing a unified theory of metabolic disease**

- Peter does not like the way diabetes is defined
- The problem with [Hemoglobin A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin):
  - There is discordance between imputed average blood glucose from hemoglobin A1C and actual measured average glucose
    - Using calibrated [Dexcom (CGM)](https://www.dexcom.com/) over the course of 90 days, he identifies patients’ average blood glucose
    - 75% of his patients have average blood glucose that does not match imputed average blood glucose
    - Peter himself is discordant (he hypothesizes due to his [beta thalassemia minor](https://en.wikipedia.org/wiki/Beta_thalassemia)) in that his hemoglobin A1C test overstates his average blood glucose compared to [Continuous glucose monitor (CGM)](https://en.wikipedia.org/wiki/Continuous_glucose_monitor)  reading
  - Peter does not consider test sensitive enough to evaluate more subtle hemoglobin A1C differences
  - Ronesh also confirms his clinical observation that the hemoglobin A1C test does not always align with other metrics to evaluate patient metabolic health
- Patients who exhibit glucose excursions after eating are not treated as high risk for metabolic syndrome when they should be, despite acceptable average blood glucose

![](https://peterattiamd.com/wp-content/uploads/2019/08/figure-2-ronesh-1024x973.jpg)

**Figure 2.** **For looking at an individual’s glucose values, CGM is a better tool for measuring average sugar levels, time-in-range, and hypoglycemia.** Image credit: ([diatribe.org](https://diatribe.org/whats-normal-a1c-when-it-misleading))

- A continuous glucose monitor (CGM) is a valuable tool for metabolic health management
  - Highlights inconsistency between inferred average blood glucose from hemoglobin A1C and measured average blood glucose
  - Provides insight into blood glucose variability

- Peter’s patients value wearing a CGM

1. - Insights gleaned

- - - Able to see glucose response of certain foods
    - How glucose intake in conjunction with/within another food can delay glycemic response
    - Role of sleep, proximity to exercising, and time of day on blood glucose levels
  - Gamification and behavior modification

- - - Becomes less about new insights
    - Altered behavior reinforced by achieving favourable blood glucose numbers
    - [Hawthorne Effect](https://en.wikipedia.org/wiki/Hawthorne_effect)  in practice

- Working towards a more robust diabetes diagnostic criteria, Peter proposes taking into account fasting and fed glucose levels, insulin levels, inflammatory markers
- Peter has observed elevated night time glucose levels by CGM in heavier weight patients who are otherwise metabolically healthy: *Could cortisol levels be responsible?*

## Cortisol and blood glucose variability [28:30]

- Ronesh observed, both personally and in his patients, that implementing nighttime rituals such as meditation and switching off devices, decreased fasting (morning) blood sugar
- The liver dictates morning blood sugar and [Cortisol](https://en.wikipedia.org/wiki/Cortisol) impacts the liver
- For individuals that are insulin resistant, liver is primed to produce high levels of glucose because of a high level of free fatty acids (FFAs) shuttled to liver to fuel [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis)
  - - Adipose tissue release more FFAs via [lipolysis](https://en.wikipedia.org/wiki/Lipolysis)
    - The addition of stress cortisol further increases lipolysis: Cortisol likewise releases FFAs from adipose tissue
    - Blood glucose improves with decrease in stress: The “emotional metabolic issue”
- Ronesh observed an elevated morning glucose in patients when their diets were too low in CHO, especially in the evenings

⇛ For more on the different kinds of lipids, what do they do, and how are they transported: check out a [previous episode of The Drive with Tom Dayspring](https://peterattiamd.com/tomdayspring1/) (specifically starting at 57:15)

![](https://peterattiamd.com/wp-content/uploads/2019/08/figure-3-ronesh-1024x782.png)

**Figure 3.** **The process of glucose metabolism in the liver. For individuals that have that are insulin resistant, liver is primed to produce high levels of glucose because of a high level of free fatty acids (FFAs) shuttled to liver to fuel gluconeogenesis.** Image credit: [slideplayer.com](https://slideplayer.com/slide/8222075/)

- The level of hepatic glucose output is tightly regulated
  - 100 milligrams of circulating glucose (a teaspoon measure equivalent) separates a metabolically normal individual from someone with type 2 diabetes
  - An organism would die in a matter of minutes from [Hypoglycemia](https://en.wikipedia.org/wiki/Hypoglycemia) after clamping the portal vein – thereby preventing the liver from circulating glucose

*Why can’t the liver – in an individual with type 2 diabetes – decrease hepatic glucose when blood glucose is elevated in the morning?*

- It is not clear how much blood glucose is regulated by the liver, pancreas, and within muscles
- Suspected that cortisol plays an important role

*Similarly, what dictates blood glucose variability in a metabolically healthy individual?*

- Cortisol plays an important role in fat flux through a fat cell
  - Difficult to measure [Hormone-sensitive lipase](https://en.wikipedia.org/wiki/Hormone-sensitive_lipase)
  - Cannot measure free cortisol in the blood

> “I think cortisol is a vastly underappreciated regulator of fat flux through the fat cell. Insulin gets a lot of attention because it’s perhaps the most potent both on the side of lipolysis and [Re-esterification](https://en.wikipedia.org/wiki/Glyceroneogenesis).” – Peter Attia

## Insulin’s role in elevated blood glucose: A symptom of metabolic syndrome [33:25]

⇒ For more on central paradox of insulin resistance check out a [previous episode of The Drive with Jason Fung](https://peterattiamd.com/jasonfung/) (specifically starting at 29:30)

- Insulin gets a lot of the “credit” in the context of metabolic syndrome
- [Jason Fung](https://twitter.com/drjasonfung?lang=en)’s model of insulin resistance explains that hyperinsulinemia rather than “resistance” drives metabolic syndrome
  - [insulin receptors](https://en.wikipedia.org/wiki/Insulin_receptor) and/or intracellular mechanisms are not “broken”
  - Insulin-mediated fat deposit into fat cells operates normally, suggesting normal function of insulin
  - Elevated level of insulin is due to difficulty “pushing” glucose into already full [Glycogen stores](https://en.wikipedia.org/wiki/Glycogen)
- Ronesh uses the *parking space analogy* of muscle glycogen stores when educating patients
  - Refer to [his lecture at Google](https://www.youtube.com/watch?time_continue=2001&v=UCc1o206GSs) at 6:24 where he discusses the parking lot model and at 29:50 where he explains gender disparity in fuel distribution

## Mechanistic explanations of insulin resistance (there may be more than one) [35:15]

> “And there may not be one cycle, because I think I was trying to find one process flow that would explain all these cases. There could be multiple. We can see arrows and diagrams going in multiple directions. And I realized at a certain point that I need to understand this process, but I’m probably not going to figure it out exactly for each individual patient.”

- In some cases, glycogen store capacity is not physical but induced in utero
  - [This study](https://www.ncbi.nlm.nih.gov/pubmed/9166672) in South Asian and Hispanic patient populations with a family history of diabetes develop insulin resistance in utero
  - Normal glucose tolerance offspring of diabetic parents
  - Elevated FFA is an early insulin signal inhibitor for glycogen storage
- Fat flux in the liver may precipitate metabolic syndrome in some cases, but in other cases, patients present with negative symptoms without having fatty liver or elevated TGs
- There are different categories of insulin resistance that will apply to different patients, although the mechanistic explanations are not well understood
  - Peter focuses on hyperinsulinemia
    - He educates his patients about the endocrine system, explaining four:
      - Thyroid system, Adrenal system, sex hormone, fuel partitioning
      - There is often patient confusion around what fuel partitioning means
      - Can simplify fuel partitioning problem by looking at one element of it in hyperinsulinemia
    - Relies on ([oral) glucose tolerance test (OGTT)](https://en.wikipedia.org/wiki/Glucose_tolerance_test), using Glucola – which has limitations (not reflective of physiologic glucose disposal), but is a standardized comparison model
    - Peter hopes for better point-of-care insulin testing and mentions that developments are being done in this space to further improve the glucola-type test.
    - CGM provides a measure of glycemic response in a real-world setting (whereas OGTT is taken in the morning, not in response to what a patient would ordinarily consume to spike blood glucose)

## Theories on origins and evolutionary reasons for insulin resistance [40:00]

> “…Because I think even in the early days since I developed it, I had this toxic relationship with glucose, triglycerides…”

*There have been different theories around the origins of insulin resistance…*

- [James Neel](https://en.wikipedia.org/wiki/James_V._Neel) first proposed the [Thrifty Gene Hypothesis](https://en.wikipedia.org/wiki/Thrifty_gene_hypothesis)
  - Insulin resistance is a result of human ancestors living in feast/famine cycles
  - Excess calories in the body would be stored as TGs, which would be utilized during famine periods
  - However evidence does not support that primitive humans experienced periods of famine and an actual “thrifty” gene was never identified
- [The Barker Hypothesis](https://en.wikipedia.org/wiki/Thrifty_phenotype) is not based on an actual gene but a gene phenotype
  - Intrauterine environment (in-utero stress) can trigger insulin resistance and heart disease
  - [David Barker](https://en.wikipedia.org/wiki/David_Barker_(epidemiologist)) looked at [birthweight records in the UK](https://www.abebooks.co.uk/book-search/title/atlas-of-mortality-from-selected-diseases-in-england-and-wales-1968-1978/), revealing that birthweight was inversely proportional to mortality for heart disease. This relationship has been supported in every continent, with the exception of Africa
  - [Dr. C.S. Yajnik](https://en.wikipedia.org/wiki/Chittaranjan_Yajnik) work on [babies in Prune](https://www.ncbi.nlm.nih.gov/pubmed/11281246), India reveals early signs of [infant hyperinsulinemia](https://www.ncbi.nlm.nih.gov/pubmed/12466355)
    - Babies have pot bellies [suggesting visceral fat](https://www.ncbi.nlm.nih.gov/pubmed/12586996)
    - Skinfold measures suggest limited amount of subcutaneous fat
- Dr. C.S. Yajnik proposed the Soldier to Diplomat Hypothesis  in which [insulin resistance is an evolutionary adaptation](https://www.ncbi.nlm.nih.gov/pubmed/17437648) that allows humans to preserve more glucose for brain function
  - [Gerald (Jerry) Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) who coined the term “metabolic syndrome” agreed that there is likely an evolutionary reason to preserve glucose for brain function
- Metabolic shifts (elevated)  glucose and lipids in utero has a trophic (neural developmental) impact
  - The South Asian population are the most highly insulin resistant country in the world
  - Dr. Yajnik’s research supports that hyperinsulinemia in utero may have some adaptive function to facilitate brain function and cognition (has  positive trophic impact)
  - Elevated glucose and elevated insulin can presumably have some impact on increasing IQ and intelligence
- It could be that postprandial elevated blood glucose after a fast/carbohydrate restriction is an evolutionary response to refuel the brain
  - Jake Kushner sent Peter a [paper that looked at mechanisms for why refeeding after carbohydrate restriction produces elevated blood glucose](https://www.ncbi.nlm.nih.gov/pubmed/28924074)
    - However… the analysis did not collect [Urinary c-peptide](https://en.wikipedia.org/wiki/C-peptide) (seemed “underfunded” says Peter)
    - Testable hypotheses: if muscle is resistant to insulin or if there is a delayed pancreatic response
  - Ronesh’s ideas …
    - Proceeding a fast period, the brain takes priority
    - Insulin resistance may occur at the skeletal muscle – which is responsible for 80%-90% of glucose disposal – in order to preserve glucose for brain function
    - He predicts that insulin secretion would be normal
    - In addition to skeletal muscle resistance, there is also likely β-cell dysfunction that contributes to elevated blood glucose
      - Flooding a system with insulin depresses β-cell function (pancreatic insulin production)
      - Patients in early stage insulin resistance already have [decreased β-cell function](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3708105/)
      - Pune India fetal studies found that fetal hyperinsulinemia was coupled with underdeveloped β-cell function
- A “standard” Caucasian path to metabolic disease = normal → hyperinsulinemic → obese → diabetic
- Asian populations seem to *skip the obesity phenotype* on their way to becoming metabolically dysregulated
  - One reason could be because they predominantly do not present with hyperinsulinemia
  - South Asian population genetically have decreased pancreatic β-cell density
- Subcutaneous fat obesity may not be a proximate reason for metabolic dysfunction
  - Lean (low amount of subcutaneous fat) habitus Asian populations still present with metabolic dysfunction
  - [A study](https://www.nejm.org/doi/full/10.1056/NEJMoa033179) took metabolically dysregulated people who underwent liposuction but did not metabolically improve
    - Liposuction removes subcutaneous fat but it is primarily the visceral fat stores that play a role in metabolic disease
    - There has not yet been a study in animal models that surgically remove visceral fat stores to evaluate metabolic impact

## The inverse relationship between the amount of brown adipose tissue and rates of insulin resistance, and the role of climate in patterns and prevalence of insulin resistance [49:50]

- [Brown adipose tissue](https://en.wikipedia.org/wiki/Brown_adipose_tissue) research reveals population-specific phenotypes related to climate

![](https://peterattiamd.com/wp-content/uploads/2019/08/figure-4-ronesh-1024x620.png)

**Figure 4. Brown adipose tissue specializes in dissipating heat as energy. As such newborns have high amounts of “brown fat” responsible for thermogenesis.** Image credit ([cell.com](https://www.cell.com/trends/endocrinology-metabolism/fulltext/S1043-2760(18)30044-4))

- - Brown adipose tissue is heat-generating (metabolically active), mitochondrially-dense, and can remove glucose from the system
  - An animal model [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3533266/) used brown adipose tissue transplantation to reverse insulin resistance
  - There is an inverse relationship between the amount of brown adipose tissue and rates of insulin resistance in human populations
  - Following the “[out of Africa Migration](https://en.wikipedia.org/wiki/Recent_African_origin_of_modern_humans)”…
    - Populations in northern, colder climates require a more active thermogenic metabolism
      - Have higher resting metabolism
      - Can generate more heat – their thermogenic resting metabolism can account for 15-18% of caloric burn rate
      - Have more brown adipose tissue
      - Have a lower incidence of insulin resistance
    - [Studies](https://academic.oup.com/jes/article/3/2/372/5250671) that compare the brown adipose tissue of South Asians and Europeans reveal that South Asians have significantly less brown adipose tissue
      - The Inuit and Eskimos in colder regions have very low insulin resistance
      - Pima Indians have a higher risk of insulin resistance

**Metabolic phenotypes within the Indian subcontinent**

- Between the northern and southern regions of India, there are marked differences in rates of insulin resistance, amount of brown adipose tissue, and body morphology
- [An epidemiologic study](https://pdfs.semanticscholar.org/12b3/18e7a89b73973de89403da10de472639ea83.pdf) of insulin resistance and diabetes in different regions of India reveals vastly different rates of diabetes between northern (Manipur) and southern (Kerala) regions
- Northern populations near the  Himalayas …
  - have low incidence of insulin resistance
  - The Manipur region have single-digit insulin resistance and diabetes
  - Body habitus tend to be leaner and taller
  - Lighter skin tone with not as high observed vitamin D deficiency
- Southern Indian populations near the equator…
  - have higher rates of insulin resistance
  - The Kerala region has an insulin resistance of up to 20%
  - Body habitus tend to be shorter with more visceral fat (pot bellies)
  - Darker skin tone with vitamin D deficiency
- Academic talent from country primarily comes from southern India ⇒ supports theory that in-utero insulin resistance imports cognitive benefit
- Although there is more insulin resistance
- Although there are confounders such as diet and activity level differences between populations, studies done on more rural, physically active southern populations still reveal relatively high rates of insulin resistance

> “But in general, if you look at the globe and you look at insulin resistance patterns, climate has a lot to do with it. And it might lead to a phenotype of basically who can manage baseline adipose metabolism better in terms of generating heat.”

## Vitamin D levels, hyperinsulinemia, and other effects [53:45]

- A lot of vitamin D deficiency Ronesh sees in South Asian patient populations is due to their skin pigment
- He writes about vitamin D deficiency here ([1](https://culturalhealthsolutions.com/solar-power-and-vitamin-d/),[2](https://culturalhealthsolutions.com/vitamin-d-deficiency-in-kids-and-adults/))
- Population is both vitamin D resistant and individuals do not absorb enough

*More (vitamin D) is not necessarily  better…*

- South Asians may not be adapted to have high vitamin D levels
- If he does supplement vitamin D for patients in the single digit ng/ml, Ronesh anecdotally has observed that …
  - that [supplementing](https://www.sciencedaily.com/releases/2013/03/130317221446.htm) vitamin D improves [C-reactive protein](https://en.wikipedia.org/wiki/C-reactive_protein) (anti inflammatory benefits)
  - Helps with hypertension as patient blood pressures improve
  - Even though vitamin D helps with glucose disposal, he has *not* observed significant glycemic improvements with supplementation
  - High placebo effect on energy levels with supplementation
- Ronesh is hesitant to supplement aggressively due to high rates of coronary calcification that he sees in the treatment population
- Peter no longer replaces vitamin D in his patients to achieve 40-60 ng/ml
  - He wants his patients to be above 30 ng/ml *without* supplementation
  - He personally no longer supplements with vitamin D
- Although Peter has not observed that vitamin D supplementation lowers blood pressure, he focuses on decreasing uric acid
- The effect of uric acid on blood pressure is significant
  - Decreasing uric acid content lowers blood pressure ([uric acid hypothesized to be an evolutionary adaptation to increase blood pressure](https://pdfs.semanticscholar.org/f299/c5928c0d1cbd0167f5b58ea292656a870a73.pdf))
  - Does not suggest antihypertensive medication until uric acid is below 5mg/dl
  - Correcting uric acid levels does not correct hyperinsulinemia

## The evolutionary benefit of being able to turn fructose into fat (and the price we are now paying for it) [58:00]

> “…This ability to generate uric acid is not unique to all species. It’s something quite unique to those that came from the lineage of having to survive a cold winter without much food.” —Peter Attia

- [Richard Johnson](https://www.asn-online.org/about/bio.aspx?ID=58272) has done research on the [uricase mutation](https://www.pnas.org/content/111/10/3763) during the early Miocene era (∼17 Ma) in a population that migrated to Europe
- Fructose is the primary nutrient in fruit, which was a main staple of early primates
- Fruit became less available during the global cooling that occurred at the time of these mutations
- Progressive loss of uricase activity allowed ancestors to readily accumulate fat via the metabolism of fructose (through de novo lipogenesis in the liver) from fruits
- One byproduct of the conversion of sugar into fat is uric acid

- However, in today’s society, the intake of fructose, primarily in the form of added sugars, has skyrocketed, while the intake of natural fruits high in vitamin C has fallen
- One hypothesis that the progressive loss of uricase activity allowed our ancestors to readily accumulate fat via the metabolism of fructose from fruits and survive harsh (and fruitless) winters

⇛ A [study](https://www.ncbi.nlm.nih.gov/pubmed/19381015) discussing the difference between fructose and glucose

## The VO2 max relationship with insulin resistance and familial metabolic health [59:30]

- In a weight, age-matched control trial, a study reported hyperinsulinemic individuals have a lower VO2 max
- [In early states of insulin resistance the muscle becomes inefficient at oxidative phosphorylation](https://escholarship.org/content/qt5cz1v976/qt5cz1v976.pdf) (marked by high levels of resting lactate)
- In a study of lean individuals with a family history of diabetes:
  - Without signs of insulin resistance, and normal glucose tolerance
  - their VO2 max is already decreased
  - offspring with a family history of diabetes had a 5% ATP output in response to VO2 max test compared to the 90% ATP output of individuals without a family history of diabetes
  - [ATP output suppression suggests early mitochondrial dysfunction](https://escholarship.org/content/qt5cz1v976/qt5cz1v976.pdf) prior to signs of metabolic disease
- Root cause of mitochondrial dysfunction for healthy offspring individuals with a family history of insulin resistance is not clear
  - Increased amount of FFAs in offspring could affect beta-oxidation
  - Could be something wrong with oxidative phosphorylation gene expression
  - One [study](https://www.scienceopen.com/document_file/2986351d-541d-4b63-a46c-f7a75a4da166/PubMedCentral/2986351d-541d-4b63-a46c-f7a75a4da166.pdf) suggests lower cardiorespiratory fitness (submaximal VO2 max) and reduced capacity to oxidize fat (fatty acid utilisation) represents a defect in substrate delivery to muscle, rather than in mitochondrial capacity to oxidise lipids (no marker for abnormal mitochondrial biogenesis)

![](https://peterattiamd.com/wp-content/uploads/2019/08/figure-5-ronesh-1024x542.png)

**Figure 5****. Beta-oxidation is the catabolic process by which fatty acid molecules are broken down in the mitochondria in eukaryotes to generate acetyl-CoA. One hypothesis for why the South Asian population may have a low VO2 max and an associated high resting lactate phenotype comes from a reduced capacity to oxidize fat (fatty acid utilisation) from which energy is generated.** Image credit: ([microbenotes.com](https://microbenotes.com/beta-oxidation-of-fatty-acid/))

- - - The suppressed ATP output of diabetic offspring individuals compared to control (individuals that do not come from a family history of diabetes) suggests that their mitochondria does not catalyze ADP to ATP across the inner membrane in the same way
    - Suggests mitochondria preferentially undergoes aerobic glycolysis (Warburg Effect)

\*It is still not clear if mitochondrial dysfunction is causal for diabetes or if it is an early, secondary symptom  that precedes mitochondria gene expression

![](https://peterattiamd.com/wp-content/uploads/2019/08/figure-6-ronesh-1024x682.png)

**Figure 6.** **In early states of insulin resistance, the muscle becomes inefficient at oxidative phosphorylation (marked by high levels of resting lactate). During glycolysis – rather than convert to pyruvate, NADPH, and ATP – glucose breaks down to lactate, NADPH and fewer ATP molecules.** Image credit:  [Medium.com](https://medium.com/@drjasonfung/the-paradox-of-cancers-warburg-effect-7fb572364b81)

⇛ For more on on what VO2 max can reveal about mitochondrial function, insulin resistance, type 2 diabetes, checkout a previous episode of [The Drive with Vamsi Mootha](https://peterattiamd.com/vamsimootha/) (specifically starting at 2:00:00)

## Using a Zone 2 fitness test to evaluate mitochondrial performance [1:01:15]

- Compared to a [Vo2 Max](https://en.wikipedia.org/wiki/VO2_max) test, a [Zone 2 fitness test](https://www.trainingpeaks.com/blog/zone-2-training-for-endurance-athletes/) test more accurately assesses mitochondrial efficiency
  - VO2 max test can be trained for (and via weight management)
  - Test is not diluted by anaerobic metabolism involved in VO2 max test
- A VO2 max test …
  - Maximizes aerobic capacity but also involves anaerobic metabolism
  - typically uses three minutes stages at increasing power output until failure (measuring real-time VO2)
- A zone 2 fitness test …
  - Uses lactate as a proxy to clamp lactate in order to assess maximum ATP production
  - samples lactate after long stage time interval (10-15 minute) on fixed power setting on a treadmill or bike
  - Uses lactate as a proxy to clamp lactate in order to assess maximum ATP production
  - samples lactate after long stage time interval (10-15 minute) on fixed power setting on a treadmill or bike
  - Produces a lactate performance curve
- lactate threshold is in the 3.8 to 4.2 millimolar range and the performance curve remains below this range (below aerobic threshold)

⇛ For more on Peter’s zone 2 training prescription check out a [previous episode of The Drive](https://peterattiamd.com/ama05/) (specifically starting at 35:30)

*In order to improve mitochondrial performance…*

- Peter thinks that training 3 hours a week in zone 2 teaches the system to generate more power with a lower lactate
- Without buying a lactate device to finger prick, consider a zone 2 proxy to be the highest level of exertion while being able to carry out a conversation

## Exercise for long-term functional health [1:06:00]

*In his insulin resistant Asian patients with lean body morphologies…*

- Ronesh emphasizes balancing physical activity that builds  aerobic endurance without compromising muscle mass
- Exclusive or predominant weight training facilitates increased glycogen storage capacity but patients became cardiovascularly deconditioned without doing other kinds of exercise
- He observed that cardiovascular deconditioning had impact on further improvements in insulin resistance and glucose tolerance

⇛ An [overview study](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000580) of why Asian Indians are at such high risk for Atherosclerotic Cardiovascular Disease and Diabetes

> “Finding that delicate balance of, ‘Yes, we’ve got to build up your aerobic system but we don’t want to compromise your muscle mass’, is sort of critical.”

- Ronesh observes lean Asian patients more readily lose muscle mass than other ethnic groups when doing volume endurance training
- As an explanation, studies in athletes reveal AMPK inhibition of mTOR but Ronesh hypothesizes that the threshold for mTOR inhibition may be lower in an Asian patient population
- Ronesh has a [2-part post](https://culturalhealthsolutions.com/the-real-risks-of-exercising-too-hard-and-how-to-exercise-part-1-of-2/) on aerobic/anaerobic exercise and strength training which has been a key resource for his diverse patient population

*There is not one kind of exercise that is “better” than another …*

- It is important to incorporate at least four components of exercise

**Stability** – the root cause of most injuries – it the ability to transmit load from joints to muscles

**Strength** – the ability to hinge, push, and pull

**Cardio** – encapsulates both aerobic and anaerobic: “training for life” (rather than performance) requires aerobic efficiency (zone 2 training) with some anaerobic performance (high intensity interval training)

- Peter favors a combination of  zone 2 training and anaerobic training

==> Example: Ronesh sees injuries in patients who take corporate HIIT/bootcamp classes  because they do not have a solid foundation of muscular infrastructure, balance, or stability

> “I kind of think of it as insulin resistance as also being anabolic resistance because you’re not able to really accumulate muscle mass as well as you could. It really creates a pretty depressing picture of how individuals age and become depressed later on in life.”

- Ronesh emphasizes the [importance of building stability and strength](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.2007.01783.x) in his younger patients
  - Population already has smaller leg mass to begin with
  - By the time individuals in the Asian population reach 50-60 years of age, their leg strength is compromised
  - [Here is a blog post](https://culturalhealthsolutions.com/why-muscle-really-matters-for-all-ages/) in which Ronesh talks about the importance of strength training, particularly building and maintaining leg muscles, in addition to ethnic differences
  - [Here is an animation](https://vimeo.com/344149108) Ronesh uses to help visualize how glucose enters a muscle cell

## Lifestyle changes to improve insulin resistance and other metabolic phenotypes [1:14:00]

> “A lot of individuals think stress reduction means that you’re magically going to eliminate external stress…But a certain percent of individuals…get high blood pressure, glucose abnormalities, some sort of chronic health condition as a result of that. So if we can train our system to not be as reactive and responsive to that external stress, that’s really what we’re looking for.”

- To accommodate the schedules of busy professionals, Ronesh tries to integrate strength, mobility and stress management exercises throughout the day
  - Introduces apps and tools to measure the number of squats, stretching and balance exercise
  - Using a smart watch, Ronesh teaches breathing exercises to lower blood pressure
  - Tracking heart rate makes the case that individuals can act in ways to change their own physiology
    - Peter views mindfulness as a tool that he can apply in his life, in order to respond rather than react
    - Peter has observed his glucose levels increase in response to stress
- Many of Ronesh’s patients have focused on the diet-exercise axis but not on the importance of stress, sedentary activity and sleep
- Many patients bring in their family members to medical visit, revealing family tension that is cause for stress

⇒ Ronesh summarizes digital tools and techniques for stress reduction in [this post](https://culturalhealthsolutions.com/stress-management-tools-and-resources/)

## Is PCOS a manifestation of insulin resistance? [1:21:00]

> “When you see all the generational elements, you realize that, well, this is much more challenging than just looking at one individual.”

Ronesh observes insulin resistance in response to stress across different lifespans: from pre-diabetes, coronary heart disease, and polycystic ovarian syndrome (PCOS)

⇛ Check out Ron’s [blog post](https://culturalhealthsolutions.com/7-steps-to-preventing-and-curing-the-pcos-epidemic-in-young-women/) on root cause, symptoms, and treatment of PCOS

- Treatment shifts from treating the individual to address generations of insulin resistance that manifests in different ways
- Ronesh does not treat many teenagers but many of his patients have female family members that fit the insulin resistant criteria in the form of PCOS
  - Endocrinologists in the surrounding Bay Area report seeing 25% to 30% of Asian Indians who probably have some manifestation of PCOS
  - Ronesh things a better name for the condition is insulin resistant ovarian syndrome rather than polycystic ovarian syndrome

*PCOS is the result of hyperinsulinemia*

- The effects of insulin on the ovary [Theca cells](https://en.wikipedia.org/wiki/Theca_of_follicle) results in release of testosterone
- The resulting manifestations have devastating effects (obesity, facial hair, acne, and emotional disorders) on teenage girls
- Many cases have been reversed with lifestyle changes that act to lower insulin
- [IGF plays a role](https://www.ncbi.nlm.nih.gov/pubmed/1283982) but addressing hyperinsulinemia can reverse the condition and its manifestations

## The impact on stress on adiposity, and Peter’s treatment regimen for overweight females resistant to typical nutritional approaches [1:23:45]

*The different adiposity phenotypes:*

- **Adiposity purely from excessive energy intake**: given unlimited access to food, some people will just not be able to stop eating (they respond to caloric restriction)
- **Adiposity coupled with hyperinsulinemia**: Population subset that responds really well to carbohydrate restriction and intermittent fasting
- **The sleep, stress dysregulated group**: Overweight individuals that *do NOT respond to caloric restriction, carbohydrate restriction, or fasting* (these tend to be mostly female)

*Peter’s treatment regimen for the* ***sleep, stress dysregulated group****:*

- Nutritional guidelines
  - Time restricted feeding, period fasting, carbohydrate restriction
  - In this case he will also increase monounsaturated fats and decrease saturated fats
- Sleep = at least 8 hours per night
- Exercise = Huge emphasis on **daily** exercise
- Must identify what is driving stress response which is driving metabolic dysfunction
- Approach requires patient’s commitment because it is a long process (may not see immediate drastic results)
- May not display as hypercortisolemia but there is often
  - Inflammation (slightly elevated fibrinogen and CRP)
  - Thyroid dysfunction (pre TSH there are thyroid antibodies marker)
- Difficult to parse if thyroid antibodies (anti-TPO, thyroglobulin) is a symptom of autoimmune disease or that of inflammation
- Ronesh tracks the autoimmune manifestations in his female patients, in antibodies that are slightly elevated, GI dysfunction, and eczema (to name a few)
- Inflammation is inhibitory to weight loss
  - addressing insulin resistance may not be enough
  - Inflammation causes subcutaneous fat cell expansion and impacts the ability of the fat cell to release FFAs
  - [This review](https://jasn.asnjournals.org/content/15/11/2792) describes the role of proinflammatory cytokines and hormones released by adipose tissue in generating the chronic inflammatory profile associated with visceral obesity
- Phenotype of treatment resistant adiposity seems more common in females
  - Increased subcutaneous adiposity could be evolutionary safety belt to have subcutaneous fat stores necessary to procreate
  - After menopause, insulin resistance phenotype becomes more prevalent

![](https://peterattiamd.com/wp-content/uploads/2019/08/figure-7-ronesh-1024x631.png)

**Figure 7.** **The relationship between adiposity, inflammation, insulin resistance and athleroschlerotic vascular disease.** Image Credit: ([Boden, 2009](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2596919/))

==> **Example**: Females Ronesh treats return to India (surrounded by family, likely sleeping better) and lose weight (despite increase in dietary carbohydrate), away from the stress of western life)

> “They’re back to their tribe, their family. They’re probably sleeping better. They’re eating a little bit less processed foods, but more carbohydrates, but they’re just in their native place now. Whereas when they come back here, they’re isolated. They’ve come back from a huge family. They’re here with all the independent stressors of western life and that is just so much more obesogenic. And I’ve seen so many cases that I’m basically convinced that that stress axis is a huge part of obesity.”

- Although difficult to measure, stress and sleep quality has effects on adiposity and overall health
- Sleep efficiency is key
  - Many devices ([Apple watch](https://www.apple.com/watch/), [Fitbit](https://www.fitbit.com/home), [WHOOP](https://www.whoop.com/),  [Oura Ring](https://ouraring.com/)) can measure sleep duration
  - There is a large difference in health metrics between patients that get 6 versus 8 hours on average per night

==> **Example**: In his South Asian patients, Ronesh sees a correlation between insulin resistance and sleep apnea

- Patients don’t necessarily have a high BMI
- Sleep apnea and intermittent hypoxia is an inflammatory stimulus
- When sleep apnea is corrected via lifestyle changes or CPAP, glucose numbers decrease
- Ronesh hypothesizes that hyperinsulinemia plays a causal role in sleep apnea

## How a culture of achievement and expectations can lead to undue stress, unhappiness, and health problems in our children (a Silicon Valley case study) [1:35:00]

 Quote TK “…the way we raise our kids early on might actually set a pattern for how much of an accelerated life or how much of a stressed out nervous system they might have later on. As I’ve talked to more and more families who are in Silicon Valley, I’m realizing that it is a lot of the behavioral patterns that we’re instilling in our kids are kind of setting the foundation for insulin resistance and inflammation early on.” -Ronesh [1:35:45]

###

> “…the way we raise our kids early on might actually set a pattern for how much of an accelerated life or how much of a stressed out nervous system they might have later on. As I’ve talked to more and more families who are in Silicon Valley, I’m realizing that it is a lot of the behavioral patterns that we’re instilling in our kids are kind of setting the foundation for insulin resistance and inflammation early on.”

- In his Silicon Valley patient population, Ronesh sees the manifestation of adult health disease early on in life
  - From fatty liver to adult hypertension in teenagers
    - Ronesh does not see a very strong relationship between coronary (heart) disease and elevated LP-a
    - Although [published studies](https://www.ncbi.nlm.nih.gov/pubmed/11290835) on LP-a suggests that the South Asian population are at risk for elevated LP-a, Ronesh does not observe a correlation
      - In fact, he sees plenty of heart disease in South Asians with *normal* LP-a levels

⇛ For more on Lp(a) check out a previous episode of The Drive: [Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know (EP.07)](https://peterattiamd.com/lpa/)

![](https://peterattiamd.com/wp-content/uploads/2019/08/figure-8-ronesh-1024x838.png)

**Figure 8.** **Potential mechanisms of FFA induced insulin-resistance and inflammation. Ronesh has observed that his Asian patient population that are not insulin resistant have a hereditary increase plasma FFAs.** Image credit: ([Boden, 2009](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2596919/))

**How culture, family dynamics, and parenting styles impact health**

- Ronesh encourages patients to come into treatment with their families (kids), which gives him insight into family dynamics and stressors
- Children are raised with the concept of “pyramid parenting”: The upcoming generation should exceed the achievement of their parents
  - Opioid and substance abuse has increased in response to achievement pressures
  - Ronesh and his wife present a talk that addresses the amount of pressure children are put under

**⇛** Reprogramming a culture: Ronesh and his wife [gave a talk](https://www.marvellbenefits.com/images/Events/Marvell-Children-Talk-3.7.2018.pdf) to high tech companies and schools called “[Is Your Child a Startup](https://youtu.be/JfLUbsA4xcs)?

- Peter just read the book: [The Coddling of the American Mind](https://www.amazon.com/Coddling-American-Mind-Intentions-Generation/dp/0735224897) … it suggests that the fragility of the Gen I (kids born post 1995) is a result of ridiculous over-the-top political correctness at institutions, [helicopter parenting](https://en.wikipedia.org/wiki/Helicopter_parent), and overly protective stuff happening
- This is slightly different variation than what Ronesh is describing which is children being “overly pushed”

> “If you think about how we look at our kids, for many individuals, the kids are an extension of their ego.”

*Does Ron think this is unique to the Silicon Valley or other areas of equal prominence?*

- It might be highlighted in Silicon Valley, but he thinks this problem can be found anywhere

⇒ Example: “Snowplow parenting”… Written about in a [New York Times article](https://www.nytimes.com/2019/03/16/style/snowplow-parenting-scandal.html) is another phenomenon in which parents create “pseudo profiles” of their children – projecting and creating large goals and aspirations that puts further pressure on children

*Ron’s personal experience of being pushed (and pushing his own kids)*

- Ronesh has experienced achievement pressure himself (his immigrant father became a doctor)
- Found himself guilty of pushing his own kids in some cases

*Pushing kids to do more and achieve more can impact their health*

- Children in high school do so much in the day that their sleep and diet becomes compromised
- Kids are burned out on exercise for sports that once they leave high school they have no desire to workout for fitness reasons
- Parents have scheduled out “play time” so kids are never just allowed time to screw around which can be important for their mental health

***\*Tips for parents*** *to help their kids better manager stress/be happier in the long run…*

- **Hobbies without expectations**: Ronesh emphasizes the importance of instilling hobbies for stress reduction later in life
  - Specifically, a source of pleasure that is **separate from pressure and expectation**
  - E.g., learning piano at their leisure vs. forcing them to learn piano to get college credits
- **Teach them to avoid too much internal rumination**: Teach them how to cognitively reframe situations (and avoid internal rumination)
  - *Example***:** Ronesh plays [Roses and Thorns](https://www.mindfulschools.org/inspiration/mindful-reflection/) with his children at the dinner table
  - Also, check out Ron’s [detailed post on rumination](https://culturalhealthsolutions.com/stop-rumination-depression-anxiety/) which explains common thought patterns, especially in high achievers, and how to mitigate their impact
- **As a parent, express some of your own thoughts and frustrations**: Doing this in front of your kids might make them more free and comfortable to open up and tell you relatable stories from their own life

- **Give kids some ownership in their own decisions (and even family decisions)**: Kids don’t respond well to someone just barking orders at them (THINK: Would YOU like working at a company where the boss does nothing except give you orders with little explanation?)

## The negative impact of devices and social media on children [1:48:45]

**Ron’s overall thoughts on phones and screens for kids**

- Ronesh sees phone use as a drug or toxin
- He suggests delaying it as long as possible (Ron waited until middle school for his 2 boys)

> “I think we’re living in a world right now where we’re just sort of, we’ve kind of normalized this whole thing [phone use]. It’s kind of like back in the day…where we knew cigarettes were bad for us, but hell, people were smoking anyway…when I really dig down in these family sessions, they always identify the phone as being a major cause of conflict in the family, attention deficit stuff, so many issues.”

**Neurochemistry/dopamine pathways and social comparison**

- He speaks to parents about the effect of device use on neurochemistry, dopamine pathways, and how it encourages social comparison (particularly for girls)

⇛  Here ([1](https://culturalhealthsolutions.com/stop-rumination-depression-anxiety/),[2](https://fortune.com/2015/10/23/is-silicon-valley-bad-for-your-health/),[3](https://www.politico.com/agenda/story/2017/06/13/workplace-health-habits-000457)) is some of Ronesh’s published work, chronicling effects and recommendations with regards to mental health, parenting and “Silicon Valley Syndrome”

⇛ For more on the impact of social media on stress levels and health: check out a [previous episode of The Drive with Dr. Robert Sapolsky](https://peterattiamd.com/robertsapolsky/) (specifically starting at 1:01:45)

> “…because of this device, they’re going to bed late, they’re having social issues. This is something we need to take seriously”

*To address the impact that devices can have on health and disease …*

- Ronesh is in the process of creating a non-profit called  DATA (Doctors Against Tech Addiction) in which he could congregate the support of CEOs and entrepreneurs from high tech companies and physicians alike

Ways to curb your child’s usage of the device:

- If you have a combative relationship, forcing them to put it down may lead to them wanting it more or using it to rebel
- Instead, it might make more sense to find a replacement for their idle time (e.g., hobbies)
- Parents are also guilty so kids may be mirroring the parent’s phone “addiction”
- Try to plan activities without phones (camping, hikes, walks, bike rides, etc.)
- Associate with other parents who agree with you and are willing to get together in a device free environment

## How you can help yourself, your family, and your community without being an MD or PhD [1:55:00]

- Peter makes a point to emphasize that people don’t necessarily need a doctor to walk them through making big impacts on their health
- There are so many resources (books, blogs, podcasts) that can help you improve your own health (stress, sleep, nutrition, etc.)
- **Ronesh highlights a key point**: People can still make a huge impact on the lives of their coworkers, their family, and friends just with the knowledge they’ve gained through the resources that Peter just mentioned
  - And it’s very rewarding to do so
  - And you can be an evangelists for health without being an MD or PhD

> “The most gratification is if I have a one-on-one interaction with the human being and I can make an impact on their life. And you don’t need special fancy degrees. Anybody at any stage can do that.” – Ronesh [1:56:45]

**Where can people follow Ron’s work?**

- The best way to reach Ronesh is through his website: <https://culturalhealthsolutions.com/>
- You can send him direct emails as well: [dr.ronsinha@southasianhealthsolution.org](mailto:dr.ronsinha@southasianhealthsolution.org)
- You can follow him at instagram at [roneshsinhamd](https://www.instagram.com/roneshsinhamd/)

§

## Selected Links / Related Material

**Ronesh’s book which helped Peter with his patients**: [The South Asian Health Solution: A Culturally Tailored Guide to Lose Fat, Increase Energy and Avoid Disease](https://www.amazon.com/South-Asian-Health-Solution-Culturally/dp/1939563054/ref=sr_1_1?crid=NUNKXXCROAHA&keywords=south+asian+health+solution&qid=1567036762&s=gateway&sprefix=south+asian+%2Caps%2C196&sr=8-1) by Ronesh Sinha MD | (amazon.com) [4:30, 8:30]

**Where Ronesh runs a medical consultation practice**:  [Bay Area](https://wikitravel.org/en/Bay_Area_(California)) | (wikitravel.org)  [9:00]

**Where Ronesh designs corporate health education and wellness programs for major companies**: [Silicon Valley](https://en.wikipedia.org/wiki/Silicon_Valley) | (wikipedia.org) [9:00; 52:45; 1:12:10; 1:35:45; 1:39:00; 1:46:45]

**Ronesh has a commitment to creating and providing open-source educational content on his website**: [including e-books and blog posts](https://culturalhealthsolutions.com/ebooks-list/)  | (culturalhealthsolutions.com) [9:45]

**The most common type of fat in the body composed of a glycerol molecule and three fatty acids**:[Triglycerides (TGs)](https://en.wikipedia.org/wiki/Triglyceride)  | (wikipedia.org)  [10:15; 14:15; 16:45; 21:15; 36:00; 40:00]

**Ronesh wrote a blog post about types of fat, ethnic-specific fat storage, and the health risks that visceral fat storage confers**: [Where’s your body fat? A look at body shapes and health risks across different ethnic groups](https://culturalhealthsolutions.com/wheres-your-body-fat-a-look-at-body-shapes-and-health-risks-across-different-ethnic-groups-indians-asians-caucasians-etc/) | Ronesh Sinha *culturalhealthsolutions*

**HdL***:* [High-density lipoprotein (HdL) cholesterol](https://en.wikipedia.org/wiki/High-density_lipoprotein)  | (wikipedia.org) [10:15; 11:45; 16:45]

**Where Ronesh is from**: [Bengal](https://en.wikipedia.org/wiki/Bengal)  | (wikipedia.org) [11:15]

**A type of fat around internal organs, located in the abdominal cavity**: [Visceral fat](https://en.wikipedia.org/wiki/Adipose_tissue#Visceral_fat) | (wikipedia.org) [14:15; 16:15; 19:30; 34:45; 40:15; 48:45; 52:15]

**A type of fat just below the skin that is not related to metabolic pathologies (and likely protective). Two types of adipose tissue are the superficial subcutaneous adipose tissue(SSCAT) and deeper layer subcutaneous adipose tissue, just right underneath the skin (DSCAT)**: [Subcutaneous fat](https://en.wikipedia.org/wiki/Adipose_tissue#Subcutaneous_fat) | (wikipedia.org) [14:15; 15:00; 19:30; 41:30; 48:45; 1:27:45; 1:39:15]

**Transport of long-chain fatty acids across the cell membrane via active transport is facilitated by a protein-mediated mechanism; proteins (fatty acid transporters) which are implicated in metabolic disease**: [Transmembrane flux](https://en.wikipedia.org/wiki/Fatty_acid-binding_protein) | (wikipedia.org) [16:15]

**Adipose tissue secretes various pro- and anti-inflammatory adipokines to modulate inflammation and insulin resistance. In obese humans and rodent models, the expression of pro-inflammatory adipokines is enhanced to induce insulin resistance**: Adipokines [16:15]

**When circulating in the plasma (plasma fatty acids) are not in their ester, fatty acids are known as non-esterified fatty acids (NEFAs) or**: [Free Fatty Acids (FFAs)](https://en.wikipedia.org/wiki/Fatty_acid) | (wikipedia.org) [16:15; 28:45; 34:30; 1:00:52; 1:27:45]

**Directionally speaking, too much subcutaneous fat can indicate risk for metabolic dysfunction. In both East and South Asian populations, however, men with lean body morphologies have markers of metabolic syndrome; their fat stores go directly to visceral fat and as such BMI calculation is not a good indicator for metabolic health**: [Body mass index (BMI) calculator](https://en.wikipedia.org/wiki/Body_mass_index) | (wikipedia.org)   [17:15]

**Modern jargon to describe lean individuals with a disproportionate amount of fat (adipose tissue) stored as visceral fat (rather than visually apparent, subcutaneous fat**): [Skinny fat](https://en.wikipedia.org/wiki/TOFI)  | (wikipedia.org) [17:15]

**Ronesh’s blog post on ethnic differences in body morphology and fat distribution**:  [Where’s your body fat? A look at body shapes and health risks across different ethnic groups – Indians, Caucasians, etc.](https://culturalhealthsolutions.com/wheres-your-body-fat-a-look-at-body-shapes-and-health-risks-across-different-ethnic-groups-indians-asians-caucasians-etc/) | Ronesh Sinha *culturalhealthsolutions*

**A study by Mitch Lazar on how the relationship between body morphology (using BMI) and metabolic syndrome requires revaluation**: [The Health Risk of Obesity–Better Metrics Imperative](https://www.sciencedaily.com/releases/2013/08/130822141948.htm) (R.S. Ahima and M.A. Lazar, 2013) [18:30]

**Hypothesis proposes that fat “spill- over” from ectopic fat (superficial subcutaneous adipose tissue compartment) into deep subcutaneous and visceral fat stores is linked to metabolic complications as superficial subcutaneous adipose tissue is relatively inert metabolically, whereas the other two adipose tissue types (deep subcutaneous and visceral)  are characterized by higher transmembrane fatty acid flux rates**:  Lipid overflow hypothesis [19:30]

- First proposed by Roger Unger: [Lipid overload and overflow: metabolic trauma and the metabolic syndrome](https://www.cell.com/trends/endocrinology-metabolism/pdf/S1043-2760(03)00192-9.pdf) (RH Unger, 2003)
- A concept overview: [Origins of metabolic complications in obesity: adipose tissue and free fatty acid trafficking](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3711689/) (B Mittendorfer, 2013)
- In the context of the South Asian study population, why certain ethnic groups are at higher risk for insulin resistance at lower body weight  : [Why might South Asians be so susceptible to central obesity and its atherogenic consequences? The adipose tissue overflow hypothesis](https://pdfs.semanticscholar.org/a1bd/9b40f4cb5007bee39fd2a7b9b2d07884229b.pdf) (AD Sniderman et al., 2006)

**Responsible for the insulin resistance (hyperinsulinemia) as fructose is metabolised in the liver where it gets turned into fat through de novo lipogenesis**: [Fatty liver](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease) | (wikipedia.org) [20:30]

**A type of cell found in pancreatic islets that synthesize and secrete insulin and amylin. In patients with type I or type II diabetes, beta-cell mass and function are diminished, leading to insufficient insulin secretion and hyperglycemia**: [Beta-cell failure](https://www.ncbi.nlm.nih.gov/pubmed/18777097) | (pubmed.gov) [20:30; 47:00]

**Another name for insulin resistance**: [Hyperinsulinemia](https://en.wikipedia.org/wiki/Hyperinsulinemia)  | (wikipedia.org) [20:30; 37:30; 40:30; 47:15; 57:45; 1:00:00; 1:22:15; 1:24:30; 1:33:00; 1:50:15]

**Ron’s detailed blog post on fatty liver in adults and kids**: [IS YOUR LIVER FAT? THE RISING INCIDENCE OF FATTY LIVER IN ADULTS AND KIDS](https://culturalhealthsolutions.com/is-your-liver-fat/) | Ron Sinha (culturalhealthsolutions.com) [20:45]

**Used to aid the diagnosis of diabetes**: [glucose tolerance](https://www.joslin.org/info/diagnosing_impaired_glucose_tolerance_IGT.html) | (joslin.org)  [34:30; 47:00; 1:00:00; 1:06:00]

**To determine glucose tolerance – how quickly glucose is cleared from the blood**: ([oral) glucose tolerance test (OGTT)](https://en.wikipedia.org/wiki/Glucose_tolerance_test) | (wikipedia.org)  [21:45; 38:30]

**A liver function test panel**: [Liver Function Test (LFT)](https://en.wikipedia.org/wiki/Liver_function_tests)  | (wikipedia.org)  [22:00]

**Diabetes trials often glycemia as their end point (meaning how low can you get the hemoglobin A1c/how “tightly” can you control the glucose) but even in the case of fatty liver/hyperinsulinemia, the marker can measure normal**: [Hemoglobin A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin)  | (wikipedia.org)  [23:00; 27:30]

**Continuous glucose monitor company**: [Dexcom (CGM)](https://www.dexcom.com/)  | (dexcom.com)  [23:00]

**Method of tracking blood glucose levels throughout the 24-hour period** : [Continuous glucose monitor (CGM)](https://en.wikipedia.org/wiki/Continuous_glucose_monitor)  | (wikipedia.org)  [23:30; 39:15]

**Continuous glucose monitor company**: [Libre](https://www.freestylelibre.us/cgm-difference/benefits-of-cgm.html)  | (freestylelibre.us) [23:00]

**Peter surmises that his hemoglobin A1c is grossly overstated due to his**: [beta thalassemia minor](https://en.wikipedia.org/wiki/Beta_thalassemia)  | (wikipedia.org) [24:00]

**In Peter’s experience, using a CGM elicits**:  [Hawthorne Effect](https://en.wikipedia.org/wiki/Hawthorne_effect)  | (wikipedia.org) [25:45]

**On the inhibitory impact of stress for weight loss and sleep quality, one steroid hormone of the glucocorticoid class of hormones**: [Cortisol](https://en.wikipedia.org/wiki/Cortisol) | (wikipedia.org) [27:30; 32:45; 1:25:45; 1:30:45]

**A metabolic pathway in which adipose tissues release free fatty acid as a result of hydrolysis**: [lipolysis](https://en.wikipedia.org/wiki/Lipolysis)  | (wikipedia.org) [28:45]

**A metabolic pathway that results in the generation of glucose, fueled by FFAs**: [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis)  | (wikipedia.org) [28:45]

- George Cahill starvation studies looking at gluconeogenesis: [Blood Glucose and Gluconeogenesis in Fasting Man](https://jamanetwork.com/journals/jamainternalmedicine/article-abstract/575355) (Felig et al., 1969)
- For more on the different kinds of lipids, what do they do, and how are they transported: check out a previous episode of The Drive with Tom Dayspring *(specifically starting at 57:15)*: [#20 – Tom Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology](https://peterattiamd.com/tomdayspring1/) | Peter Attia (peterattiamd.com)

**If the liver is prevented from putting out any glucose, the organism will die in a matter of minutes from**: [Hypoglycemia](https://en.wikipedia.org/wiki/Hypoglycemia) | (wikipedia.org)   [31:15]

**Fatty acids stick to a lot of things. Sticking is called esterification in the world of lipids. When fatty acids are reattached to the glycerol backbone (condensation to form a triglyceride)**: [Re-esterification](https://en.wikipedia.org/wiki/Glyceroneogenesis) | (wikipedia.org)  [32:45]

**Triglyceride dissolving enzymes  responsible for hydrolyzing triglycerides (lipolysis). These specific enzymes cannot be measured so it makes the evaluation of the role of stress hormone (and thus the release of FFAs) difficult to parse**: [Hormone-sensitive lipase](https://en.wikipedia.org/wiki/Hormone-sensitive_lipase)  | (wikipedia.org)  [32:45]

**Insulin is responsible for de novo lipogenesis (meaning if you have a lot of carbohydrates/glucose, it will build it into glycogen). Glycogen is  stored in muscle and liver; exercise increases the ability to put glucose away in the muscle as glycogen**: [Glycogen stores](https://en.wikipedia.org/wiki/Glycogen) | (wikipedia.org)  [33:15]

**Insulin is a hormone. It acts on the insulin receptor, which is on the cell surface**:  [insulin receptors](https://en.wikipedia.org/wiki/Insulin_receptor) | (wikipedia.org) [33:15]

**For more on insulin resistance check out a previous episode of The Drive with fasting expert Jason Fung (*****specifically starting at 29:30*****)**: [#59 – Jason Fung, M.D.: Fasting as a potent antidote to obesity, insulin resistance, type 2 diabetes, and the many symptoms of metabolic illness](https://peterattiamd.com/jasonfung/) | Peter Attia (peterattiamd.com) [33:15]

**Ron’s lecture at Google where he discusses the parking lot model (starting at 6:24)**: [Ronesh Sinha: “A Diabetes Cure Designed for Diverse Cultures”](https://youtu.be/UCc1o206GSs) | Talks at Google (youtube.com) [33:30]

**A study of healthy individuals who had a family history of diabetes were compared with matched control subjects who were not offspring of diabetics.  The offspring showed fasting hyperinsulinemia and higher free fatty acid levels**: [Metabolic defects in lean nondiabetic offspring of NIDDM parents: a cross-sectional study](https://www.ncbi.nlm.nih.gov/pubmed/9166672) (G Perseghin et al., 1997) [34:30]

**In the context of oral glucose monitoring testing of diabetes, Joseph Kraft authored**: [Diabetes Epidemic & You](https://www.amazon.com/Diabetes-Epidemic-You-Joseph-Kraft/dp/1425168094)  | (amazon.com) [38:30]

**An initial theory on the evolutionary origins of insulin resistance for adaptivity during feast/famine cycles**: [Thrifty Gene Hypothesis](https://en.wikipedia.org/wiki/Thrifty_gene_hypothesis)  | (wikipedia.org) [41:00]

**Hypothesis that associates foetal birth weight correlates with chronic conditions later in life**: [The Barker Hypothesis](https://en.wikipedia.org/wiki/Thrifty_phenotype)  | (wikipedia.org) [41:00]

**Published record revealing birth weight was inversely proportional to mortality from heart disease in the UK**: [Atlas of mortality from selected diseases in England and Wales, 1968-1978](https://www.abebooks.co.uk/book-search/title/atlas-of-mortality-from-selected-diseases-in-england-and-wales-1968-1978/) (abebooks.co.uk) [41:00]

**Research into the relationship between maternal nutrition, fetal growth and offspring risk of type 2 diabetes mellitus** [41:30; 43:00] :

- Small size at birth coupled with subsequent obesity increases risk for insulin resistance syndrome in later life:  [The insulin resistance epidemic in India: fetal origins, later lifestyle, or both?](https://www.ncbi.nlm.nih.gov/pubmed/11281246) (CS Yajnik, 2001)
- Supports the intrauterine origin of adiposity, central adiposity, and hyperinsulinemia in Indians: [Adiposity and hyperinsulinemia in Indians are present at birth](https://www.ncbi.nlm.nih.gov/pubmed/12466355) (CS Yanjnik et al., 2002)
- Small Indian babies have small abdominal viscera and low muscle mass: [Neonatal anthropometry: the thin-fat Indian baby. The Pune Maternal Nutrition Study](https://www.ncbi.nlm.nih.gov/pubmed/12586996) (CS Yanjnik et al., 2003)
- The Soldier to Diplomat Hypothesis  in which insulin resistance is an evolutionary adaptation: [Evolutionary origins of insulin resistance: a behavioral switch hypothesis](https://www.ncbi.nlm.nih.gov/pubmed/17437648) (MG Watve and CS Yajnik, 2007)

**Measured as a means to evaluate insulin secretion (low blood level suggests hyperinsulinemia and glucose variability)**: [Urinary c-peptide](https://en.wikipedia.org/wiki/C-peptide) | (wikipedia.org) [43:45]

**Paper sent to Peter by Jake Kushner that is trying to look at mechanisms for why refeeding after carbohydrate restriction produces elevated glucose**: [Postprandial Glucose Surges after Extremely Low Carbohydrate Diet in Healthy Adults.](https://www.ncbi.nlm.nih.gov/pubmed/28924074) (Kanamori et al., 2017) [43:45]

**Study presents how both East and South Asian populations have genetically determined reduced β cell reserve, which contributes to an increased risk of diabetes (As Peter notes, this genetic predisposition could suggest why Asian population pool bypasses hyperinsulinemia if they have less  β cell density or functionality in some way.)**: [Type 2 diabetes in East Asians: similarities and differences with populations in Europe and the United States](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3708105/)  (CW Ma and CN Chan, 2013) [47:45]

**Sam Klein study demonstrated that liposuction does not improve insulin resistance**: [Absence of an Effect of Liposuction on Insulin Action and Risk Factors for Coronary Heart Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa033179) (Klein et al., 2004) [48:45]

**The model of the geographic origin and early migration of anatomically modern humans**: [Out of Africa Migration](https://en.wikipedia.org/wiki/Recent_African_origin_of_modern_humans) | (wikipedia.org)  [49:45]

**Brown Adipose Tissue (BAT) presence and function are strongly correlated with metabolic rates and directly influence obesity susceptibility. Study on how human migration patterns influenced BAT and  insulin resistance patterns in different ethnic groups**: [The Impact of Early Human Migration on Brown Adipose Tissue Evolution and Its Relevance to the Modern Obesity Pandemic](https://academic.oup.com/jes/article/3/2/372/5250671) (D Sellayah, 2018) [51:00]

**An epidemiologic study of insulin resistance and diabetes in different regions of India reveals vastly different rates of diabetes between northern (Manipur) and southern (Kerala) regions**: [Epidemiology of diabetes in different regions of India](https://pdfs.semanticscholar.org/12b3/18e7a89b73973de89403da10de472639ea83.pdf) (V Mohan and R Pradeepa, 2009) [51:30]

**BAT transplantation in mice improved glucose tolerance, increased insulin sensitivity, lower body weight**: [Brown adipose tissue regulates glucose homeostasis and insulin sensitivity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3533266/) (KI Stanford et al., 2013) [51:45]

**Ronesh observes Vitamin D deficiency in his South Asian population. He writes about vitamin D deficiency and its effects**: [52:15; 53:45; 55:15; 56:30]

- [Solar power and Vitamin D](https://culturalhealthsolutions.com/solar-power-and-vitamin-d/) | Ronesh Sinha *culturalhealthsolutions*
- [Vitamin D deficiency in kids (and adults)](https://culturalhealthsolutions.com/vitamin-d-deficiency-in-kids-and-adults/) | Ronesh Sinha *culturalhealthsolutions*
- **In one of his posts, Ronesh references an article on vitamin D replacement (As is Peter, Ronesh is concervative on vitamin D supplementation but will do so if patient presents with very low levels)**: [Vitamin D replacement improves muscle efficiency](https://www.sciencedaily.com/releases/2013/03/130317221446.htm) (Society of Endochronoloy, 2013)

**Peter targets decreasing uric acid to lower blood pressure, although it does not address hyperinsulinemia:** [58:00]

- **In terms of uric acid origins: Richard Johnson’s study on the uricase mutation**: [Evolutionary history and metabolic insights of ancient mammalian uricases](https://www.pnas.org/content/111/10/3763) (R Johnson et al., 2013)
- **Higher serum uric acid in humans compared with most other mammals may have occurred as a means to increase blood pressure in early hominoids in response to a low-sodium and low-purine diet**: [Uric Acid, Evolution and Primitive Cultures](https://pdfs.semanticscholar.org/f299/c5928c0d1cbd0167f5b58ea292656a870a73.pdf) (R Johnson et al., 2004)
- **The increase in dietary fructose in the modern diet causes fatty liver because all that fructose goes into the liver and it’s turned into fat through de novo lipogenesis, leading to hyperinsulinemia. A study by Peter Havel comparing fructose and glucose**: [Consuming fructose-sweetened, not glucose-sweetened, beverages increases visceral adiposity and lipids and decreases insulin sensitivity in overweight/obese humans](https://www.ncbi.nlm.nih.gov/pubmed/19381015) (P Havel et al., 2009)

**For more on what VO2 max can tell us about mitochondrial function, insulin resistance, type 2 diabetes** **check out a previous episode of The Drive with Vamsi Mootha (specifically starting at 1:00:10)**: [#66 – Vamsi Mootha, M.D.: Aging, type 2 diabetes, cancer, Alzheimer’s disease, and Parkinson’s disease – do all roads lead to mitochondria?](https://peterattiamd.com/vamsimootha/) | Peter Attia (peterattiamd.com) [59:30]

**In the context of the relationship with insulin resistance and familial metabolic health**: [Vo2 Max](https://en.wikipedia.org/wiki/VO2_max) | (wikipedia.org) [59:30; 1:01:15; 1:05:15]

**Study suggests lower cardiorespiratory fitness (submaximal VO2 max) and reduced capacity to oxidize fat (fatty acid utilisation) in  South Asian population, correlated to insulin resistance phenotype, represents a defect in substrate delivery to muscle, rather than in mitochondrial capacity to oxidise lipids (no marker for abnormal mitochondrial biogenesis)**: [Fat oxidation, fitness and skeletal muscle expression of oxidative/lipid metabolism genes in South Asians: Implications for insulin resistance?](https://www.scienceopen.com/document_file/2986351d-541d-4b63-a46c-f7a75a4da166/PubMedCentral/2986351d-541d-4b63-a46c-f7a75a4da166.pdf) (Hall et al., 2010)  [59:30]

**VO2 max as a surrogate marker for (early) IR and metabolic syndrome; Mitochondrial Myopathy Hypothesis for type 2 diabetes (marked by high levels of resting lactate)**: [Assessment of Metabolic Flexibility by Means of Measuring Blood Lactate, Fat, and Carbohydrate Oxidation Responses to Exercise in Professional Endurance Athletes and Less-Fit Individuals](https://escholarship.org/content/qt5cz1v976/qt5cz1v976.pdf)  (San-Millán et al., 2016) [1:00:15]

**Peter’s best proxy for mitochondrial function**: [Zone 2 fitness test](https://www.trainingpeaks.com/blog/zone-2-training-for-endurance-athletes/) | (trainingpeaks.com)  [1:01:15]

**For more on Peter’s zone 2 training prescription**: check out a [previous episode of The Drive](https://peterattiamd.com/ama05/) (specifically starting at 35:30)  | (peterattiamd.com) [1:01:15]

**Ron’s 2-part series on how to exercise**: [THE REAL RISKS OF EXERCISING TOO HARD AND HOW TO EXERCISE-PART 1 OF 2](https://culturalhealthsolutions.com/the-real-risks-of-exercising-too-hard-and-how-to-exercise-part-1-of-2/) | Ron Sinha (culturalhealthsolutions.com) [1:06:00]

**Exercise is known to enhance peripheral insulin sensitivity and reduce insulin secretion.** **The molecular mechanism(s) for the enhanced glucose uptake with exercise training have been attributed to the increased expression and/or activity of key signalling proteins involved in the regulation of glucose uptake and metabolism in skeletal muscle related to changes in the expression and/or activity of proteins involved in insulin signal transduction in skeletal muscle such as the AMP‐activated protein kinase (AMPK)**: [Exercise training‐induced improvements in insulin action](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-1716.2007.01783.x) (Hawley and Lessard., 2007) [1:07:00]

**Ronesh’s blog post on the importance of weight training and building leg strength**: [Why muscle really matters](https://culturalhealthsolutions.com/why-muscle-really-matters-for-all-ages/) | Ronesh Sinha (culturalhealthsolutions.com) [1:13:00]

**An animation Ronesh uses to educate about muscle glycogen storage**: [Muscle Capacity](https://vimeo.com/344149108) | Ronesh Sinha (culturalhealthsolutions.com) [1:13:00]

**Personal data collection device**: [Apple watch](https://www.apple.com/watch/)  | (apple.com) [1:14:00]

**Personal data collection device**: [Fitbit](https://www.fitbit.com/home)  | (fitbit.com)  [1:14:00]

**Sleep and heart rate tracker**: [Oura Ring](https://ouraring.com/)  | (ouraring.com)  [1:31:00]

**Sleep and heart rate tracker**: [WHOOP](https://www.whoop.com/)  | (whoop.com)   [1:31:00]

**Ronesh’s book on IR in diverse populations like Asians/Asian Indians**: [The South Asian Health Solution](https://www.amazon.com/South-Asian-Health-Solution-ebook/dp/B00IOFMOYS/ref=sr_1_1?keywords=south+asian+health+solution&qid=1559942438&s=gateway&sr=8-1)  | (amazon.com) [1:19:30]

**Ronesh summarizes digital tools and techniques for stress reduction in this post**: [STRESS MANAGEMENT TOOLS AND RESOURCES](https://culturalhealthsolutions.com/stress-management-tools-and-resources/) | Ron Sinha (culturalhealthsolutions.com) [1:20:00]

**Ronesh’s blog post on root cause, diagnosis and management of PCOS**: [7 steps to curing the PCOS epidemic in young women](https://culturalhealthsolutions.com/7-steps-to-preventing-and-curing-the-pcos-epidemic-in-young-women/)  | Ronesh Sinha *culturalhealthsolutions* [1:21:15]

**Ronesh’s blog post on root cause, diagnosis and management of PCOS**: [How to prevent and cure hypothyroidism](https://culturalhealthsolutions.com/reverse-hypothyroidism-hashimotos/) | Ronesh Sinha *culturalhealthsolutions* [1:21:15]

**Overview study on why Asian Indians are at such high risk for Atherosclerotic Cardiovascular Disease and Diabetes**: [Atherosclerotic Cardiovascular Disease in South Asians in the United States: Epidemiology, Risk Factors, and Treatments: A Scientific Statement From the American Heart Association](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000580) (Santos Volgman et al., 2018) [1:21:15, 1:34:30]

**The effects of insulin on the ovaries particularly the theca cells is causing the testosterone release and that’s leading to all the different manifestations**: [Theca cells](https://en.wikipedia.org/wiki/Theca_of_follicle)  | (wikipedia.org) [1:22:15]

**On the effects of IGF and (versus) insulin in the pathogenesis of PCOS**: [The role of insulin-like growth factor-1 (IGF-1) and IGF binding protein-1 (IGFBP-1) in the pathogenesis of polycystic ovary syndrome](https://www.ncbi.nlm.nih.gov/pubmed/1283982) (R Homburg et al., 1992) [1:23:30]

**Although Christopher Gardner did not find that hyperinsulinemic people respond very well to true intermittent fasting and carbohydrate restriction, Peter successfully uses it clinically to treat patients**: [Weight loss diet study: Low carb vs. low fat and insulin resistance](https://med.stanford.edu/nutrition/nutrition-studies-group/completed-studies/different-diets-and-insulin-resistance.html) (CD Gardner et al., 2018) [1:24:30]

**Inflammation may be a potential mechanism whereby visceral adiposity leads to insulin resistance. This review describes the role of proinflammatory cytokines and hormones released by adipose tissue in generating the chronic inflammatory profile associated with visceral obesity**: [The inflammatory syndrome: The role of adipose tissue cytokines in metabolic disorders linked to obesity](https://jasn.asnjournals.org/content/15/11/2792) (Wisse, 2004) [1:27:45]

**The effects of how we internalize stress is hard to measure – it is not just about cortisol – another class of hormones can serve as neurotransmitters as well as hormones that regulate breathing and heart rate**: [Catecholamines](https://en.wikipedia.org/wiki/Catecholamine)  | (wikipedia.org)  [1:30:45]

**In Ronesh’s patient population,the prevalence of elevated coronary heart disease marker is often uncoupled with insulin resistance. For more on Lp(a) check out a previous episode of The Drive**: [Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know (EP.07)](https://peterattiamd.com/lpa/) | (peterattiamd.com) [1:34:15]

**This study suggests that elevated plasma Lp[a] confers genetic predisposition to CHD in Asian Indians, and nutritional and environmental factors further increase the risk of CHD**: [Evaluation of Lp[a] and other independent risk factors for CHD in Asian Indians and their USA counterparts](https://www.ncbi.nlm.nih.gov/pubmed/11290835) (RC Hoogeveen et al., 2001)[1:34:30]

**Ronesh and his wife give a talk  to high tech companies and schools called “Is Your Child a Startup?”**: [1:37:00]

- **Here is the presentation**: [Your Child Is Not a Start-Up: Improving the Health of Overworked, Undernourished Children](https://www.marvellbenefits.com/images/Events/Marvell-Children-Talk-3.7.2018.pdf) | (marvellbenefits.com)
- **Here is a youtube video of Ronesh giving the talk**: [Is Your Child a Startup?](https://youtu.be/JfLUbsA4xcs)  | (youtube.com)

**An activity Ronesh does with his children at home to manage stress and avoid rumination**: [Roses and Thorns](https://www.mindfulschools.org/inspiration/mindful-reflection/) | (mindfulschools.org)  [1:37:30]

**Some of Ronesh’s published work on chronicling effects and recommendations with regards to mental health, parenting and “Silicon Valley Syndrome”**:

- **A blog post how rumination is a key early indicator for future mental health issues (what Ronesh terms “pre-anxiety” nad “pre-depression”)**: [This single thought process can ruin your health](https://culturalhealthsolutions.com/stop-rumination-depression-anxiety/) | Ronesh Sinha (culturalhealthsolutions.com)
- **On the corporate health crisis in Silicon Valley, featuring Ronesh’s work:** [Is Silicon Valley bad for your health?](https://fortune.com/2015/10/23/is-silicon-valley-bad-for-your-health/)  | Jeffrey M. O’Brien (*fortune.com)*
- **An op-ed Ronesh wrote on the risks of living in an environment with intrinsic pressures**: [How your job can wreck your health](https://www.politico.com/agenda/story/2017/06/13/workplace-health-habits-000457) | Ronesh Sinha *(politico.com)*

**Book on how parenting has created a generation termed “Gen I” (“set-up to fail”)**: [The Coddling of the American Mind](https://www.amazon.com/Coddling-American-Mind-Intentions-Generation/dp/0735224897) | (amazon.com) [1:37:45; 1:43:45]

**Problematic Parenting styles**: [1:38:00]

- [Helicopter parenting](https://en.wikipedia.org/wiki/Helicopter_parent)  | (wikipedia.org)
- **The New York Times did an article on**: [snowplow parenting](https://www.nytimes.com/2019/03/16/style/snowplow-parenting-scandal.html)  | (*The New York Times*)

**Ron’s detailed post on rumination which explains common thought patterns, especially in high achievers, and how to mitigate their impact**: [THIS SINGLE THOUGHT PROCESS CAN RUIN YOUR HEALTH](https://culturalhealthsolutions.com/stop-rumination-depression-anxiety/) | Ronesh Sinha (culturalhealthsolutions.com) [1:46:45]

**For more on the impact of social media on stress levels and health check out a previous episode of The Drive with Dr. Robert Sapolsky (*****specifically starting at 1:01:45*****)**: [#51 – Robert Sapolsky, Ph.D.: The pervasive effect of stress – is it killing you?](https://peterattiamd.com/robertsapolsky/) | Peter Attia (peterattiamd.com) [1:51:15]

§

## People Mentioned

- [Mark Sisson](https://twitter.com/Mark_Sisson) (person who introduced Peter to Ron) [8:00]
- [Mitch Lazar](https://www.med.upenn.edu/lazarlab/) (studies homeostatic mechanisms that control physiological metabolism and has published on the shortcoming of using BMI as a singular metric for metabolic risk) [18:30]
- [Roger Unger](https://en.wikipedia.org/wiki/Roger_Unger) (American physician; proposed the Lipid Overflow hypothesis) [19:30]
- [Jason Fung](https://www.dietdoctor.com/authors/dr-jason-fung-m-d) (Nephrologist; previous guest on [The Drive](https://peterattiamd.com/jasonfung/)) [33:15]
- [James Neel](https://en.wikipedia.org/wiki/James_V._Neel) (geneticist who put forth the Thrifty Gene Hypothesis) [41:00]
- [David Barker](https://en.wikipedia.org/wiki/David_Barker_(epidemiologist)) (epidemiologist who authored the Barker Hypothesis, which associated in-utero conditions to chronic conditions later in life) [41:00]
- [Dr. C.S. Yajnik](https://en.wikipedia.org/wiki/Chittaranjan_Yajnik) (Diabetes and maternal nutrition; Studies of low birth weight babies, particularly of Pune, India) [41:30; 43:00]
- [Gerald (Jerry) Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) (endocrinologist and diabetes researcher who coined the term “metabolic syndrome”) [42:30]
- [Jake Kushner](https://www.bcm.edu/about-us/leadership/office-of-the-president/initiatives/mcnair-scholars-program/mcnair-scholars/jake-a-kushner) (previous guest on the [The Drive](https://peterattiamd.com/jakekushner/)) [43:45]
- [Sam Klein](https://diabetesresearchcenter.dom.wustl.edu/samuel-klein-md/) (authored how liposuction does not improve insulin resistance) [48:45]
- [Richard Johnson](https://www.asn-online.org/about/bio.aspx?ID=58272) (nephrologist; the uricase mutation) [58:00]
- [Ben Bruno](https://benbruno.com) (Peter follows him on [instagram](https://www.instagram.com/benbrunotraining/?hl=en); “Everyday is leg day” reference) [1:15:00]
- [Christopher Gardner](https://profiles.stanford.edu/christopher-gardner)  (Low-fat vs low-carb studies in insulin resistant and healthy study populations) [1:24:30]
- [Lori Loughlin](https://en.wikipedia.org/wiki/Lori_Loughlin) (American actress; media presence in association with the college admission scandal legal case; an example of “snowplow parenting”) [1:40:15]
- [Sanjay Gupta](https://en.wikipedia.org/wiki/Sanjay_Gupta) (American physician; anecdotally mentioned by Ronesh in accounting his own personal experience with parental, cultural pressure) [1:42:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/08/bio-image-ronesh.jpg)

##### Ronesh Sinha, M.D.

Dr. Ronesh (Ron) Sinha, author of [The South Asian Health Solution](https://www.amazon.com/South-Asian-Health-Solution-ebook/dp/B00IOFMOYS/ref=sr_1_1?keywords=south+asian+health+solution&qid=1559942438&s=gateway&sr=8-1), runs a medical consult practice focused on preventing and reversing insulin resistant conditions in predominantly Asian Indians, who have some of the highest rates of type 2 diabetes and early heart disease in the world.  He also designs corporate health education and wellness programs for major Silicon Valley companies like Oracle, Amazon, Google and more. More recently he has been focusing his energy on teaching busy families how to achieve better mental and metabolic health through talks/workshops at schools and corporations and online programs.

Instagram: [@roneshsinhamd](https://www.instagram.com/roneshsinhamd/)

Twitter: [@roneshsinha](https://twitter.com/roneshsinha?lang=en)