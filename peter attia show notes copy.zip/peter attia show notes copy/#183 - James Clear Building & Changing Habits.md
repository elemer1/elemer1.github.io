# #183 – James Clear: Building & Changing Habits

**Source:** [https://peterattiamd.com/jamesclear/](https://peterattiamd.com/jamesclear/)

---

James Clear is the author of the *New York Times* bestseller *Atomic Habits*. His extensive research into human behavior has helped him identify key components of habit formation and develop the “Four Laws of Behavioral Change.” In this episode, James provides insights into how both good and bad habits are formed, including the influence of genetics, environment, social circles, and more. He points to changes one can make to cultivate more perseverance and discipline and describes the profound impact habits can have when tying them into one’s self-identity. Finally, James breaks down his “Four Laws of Behavioral Change” and how to use them to create new habits, undo bad habits, and make meaningful changes in one’s life.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jamesclear/the_Drive_public.png)

Play

#183 - James Clear: Building & changing habits

1x15s30s

0:002:18:49

## We discuss:

- Why James became deeply interested in habits [1:45];
- Viewing habits through an evolutionary lens [6:00];
- The power of immediate feedback for behavior change, and why we tend to repeat bad habits [9:15];
- The role of genetics and innate predispositions in determining one’s work ethic and success in a given discipline [14:30];
- How finding one’s passion can cultivate perseverance and discipline [23:15];
- Advantages of creating systems and not just setting goals [29:15];
- The power of habits combined with self-identity to induce change [36:30];
- How a big environmental change or life event can bring on radical behavioral change [50:30];
- The influence of one’s social environment on their habits [54:15];
- How and why habits are formed [1:00:30];
- How to make or break a habit with the “Four Laws of Behavior Change” [1:09:30];
- Practical tips for successful behavioral change—the best strategies when starting out [1:16:15];
- Self-forgiveness and getting back on track immediately after slipping up [1:30:30];
- Law #1: Make it obvious—Strategies for identifying and creating cues to make and break habits [1:39:45];
- Law #2: Make it attractive—examples of ways to make a new behavior more attractive [1:47:45];
- Law #3: Make it easy—the 2-minute rule [1:58:45];
- Law #4: Make it satisfying—rewards and reinforcement [2:03:30];
- Advice for helping others to make behavioral changes [2:06:00];
- More.

§

## Show Notes

**Pre-show notes**

- Peter wanted to interview James after reading his book for the second time
  - [Atomic Habits: An Easy & Proven Way to Build Good Habits & Break Bad Ones](https://www.amazon.com/Atomic-Habits-Proven-Build-Break/dp/0735211299/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634054380&sr=1-1) by James Clear (2018)
- He realized this is such an important part of what he tries to do in his practice, and of course, what most of us try to do in our lives, which is change behaviors
  - Behaviors can really be distilled into habits
- This episode delves into Jame’s background, why this is an interesting topic to him, but mostly, it dives really deep into the four components of what goes into forming behavioral habits, and then, of course, breaking those apart
  - To explain how one can unlearn or learn new habits
- This episode is great for anyone who’s ever wanted to change a behavior or create a behavior

## Why James became deeply interested in habits [1:45]

**What excites James about habits**

1 – People build habits all the time whether they are thinking about it or not

- 40-50% of our behavior is automatic and habitual
- Automatic things include: brushing teeth, tying shoes, unplugging something after you use it
- One’s behavior is shaped or influenced by habits that preceded it

- For example, what one does with 3-4 minutes of free time (waiting in line or at home); this may be thinking about an email, playing a video game, scrolling social media
- This conscious behavior was set by the habit of pulling out one’s phone

> “The reach of our habits is very wide and it’s influencing our behavior all the time” – James Clear

- James thinks “*if you’re going to be building habits anyway, you might as well understand what they are and how they work and how to shape them so that you can be the* ***architect of your habits and not the victim of them***”
- Many times people think habits are happening to them; that they don’t have much influence on them
- The brain is always trying to automate and make behaviors more efficient
  - If one doesn’t really know what’s happening or where to adjust it, then it kind of feels like it’s happening to you rather than happening for you

2 – The realization that most of us in life wants some kind of results

- To get better at a skill, lose weight, make more money, reduce stress, etc.
- Results are a *lagging* measure of the habits that preceded them
  - One’s bank account is a lagging measure of financial habits
  - One’s weight is a lagging measure of nutrition and training habits

**Focus on what you can control**

- Habits are not the only thing that influence outcomes in life, i.e., Luck and randomness are other forces
- But by definition, randomness is not under your control
- The only reasonable approach is to focus on what’s in your control
- Over long time horizons, your results tend to bend in the direction of your habits

> “*I think because your brain is building habits all the time anyway and because your results are heavily influenced by the habits that you repeat, those are two primary reasons that I feel like got me interested in the topic*.” —James Clear

## Viewing habits through an evolutionary lens [6:00]

**Evolutionary rationale for humans to be creatures of habit**

- Peter notes an evolutionary rationale for why we’re creatures of habit
- The less energy we have to devote to things would free-up energy that can be used to survive and procreate
  - For example, the [autonomic nervous system](https://en.wikipedia.org/wiki/Autonomic_nervous_system) controls things completely without our voluntary control
    - This includes functions like breathing and having your heart go from beating fast or beating slow

*When did humans begin to proactively change habits?*

- James speculates that it probably does skew as a somewhat recent luxury for one particular reason—our ancestors lived in what was primarily an *immediate return* environment
  - The majority of decisions made that meaningfully impacted survival were ones that were relatively immediate in nature
  - These decisions had a pretty quick payoff, for example:
    - Taking shelter from a storm
    - Avoiding a lion in the savanna
    - Forging for the next meal in a berry bush
- Fast forwarding to modern society (certainly in the last 100 years), it seems to have created quite a few structures that favor a **delayed return** environment (not an immediate return environment), for example:
  - Go to work today to get a paycheck in 2 weeks
  - Study at school today to graduate in 4 years
  - Save for retirement today so you don’t have to work in a couple decades from now

> “So I think in a sense, we’re kind of walking through this modern society that rewards ourselves for patience and we still have this like paleolithic hardware where we prioritize instant gratification and immediate returns” – James Clear

- Delayed gratification has created a mismatch in an evolutionary sense
- David wonders if this modern mismatch has led to the desire to change our behavior and to adjust habits, and perhaps it wasn’t something people thought about as carefully thousands of years ago
- Some aspects of modern society are mismatched with that ancestral wiring
  - For example, why does one care about delaying gratification to get a PhD?… Likely because it affords some sort of status
    - Status is hierarchical and thought to be evolutionarily wired in
    - Some connections to ancestral wiring are there, but they’re not all aligned
- It seems that the vehicles used to attain status earlier were much ‘simpler’ than they are today

## The power of immediate feedback for behavior change, and why we tend to repeat bad habits [9:15]

**Comparing 2 example of a learned behavior, riding a bike and swimming**

- Thinking of habits this way, Peter compares the challenges of teaching an adult to do 2 different activities he enjoys, riding a bike and swimming
  - If one took a 20-year old who had never ridden a bike or swam; he thinks it would be easier to teach them to ride a bike because the object is balanced
    - With balance, one gets feedback immediately
      - When balance is lost, one will fall
  - Swimming is also about balance, balance in the water
    - Most people naturally sink feet first
    - One has to balance so they can breathe
    - Learning to swim well isn’t easy because the feedback loop is very long
      - It’s hard to make the connection that one is out of balance when learning to swim
      - When one is out of balance in swimming, one works harder but doesn’t realize why they’re working harder
      - It also doesn’t hurt as much when one fails at balance in water as compared to on the bike
    - Therefore, it requires much more deliberate practice to learn to swim than it does to ride a bike, at least at some basic level

**What is it that determines whether a habit is good or bad? And why do we tend to repeat bad habits?**

A question James often gets, “*Why do I repeat this habit if it’s bad for me? If it’s so terrible, then how come I keep coming back to it?*”

- What determines whether a habit is good or bad?
- All behaviors produce multiple outcomes across time
  - There is an immediate outcome and an ultimate outcome
- For most habits, the immediate outcome is pretty favorable
  - Smoking is a good example; one has a smoke with a friend outside the office at 10 AM; this provides immediate socialization; maybe it curbs nicotine cravings or allows one to de-stress for a couple minutes
    - The ultimate outcome though is negative, but this doesn’t happen for 2, 5, 10 years, or later
- With good habits the effect is often the reverse (an unfavorable outcome), especially the first time they are performed
  - The first week of training in the gym, one’s body looks the same and one is very sore
    - There’s not a lot to show for the effort put in
    - There are a lot of upfront costs
    - It’s only 2, 5, or 10 years later that one gets the outcome they’re looking for

> “In a sense, the cost of your good habits is in the present, the cost of your bad habits is in the future” – James Clear

- The misalignment between when one feels rewarded and feels punished helps to explain why people fall into bad habits
  - Things often categorized as bad like eating donuts or smoking a cigarette
- This also explains why people fall less easily into things that we would categorize as good
- This is related to the immediacy of feedback
  - Bad habits often give immediate feedback
  - Good habits often give delayed feedback

**Habits are driven by immediate feedback**

- David thinks Peter’s example of the medium that you’re in (air versus water) is fascinating
  - Think about water as being a feedback dampener, but there is another element to it which is the strength of the feedback
    - Falling on the ground off a bike and skinning your knee is pretty painful; one learns quickly
    - One doesn’t pay much attention to making a bad stroke in the water because of the low cost of sloppy form; it’s unlikely that habit will rectify it quickly

> “The cardinal rule of behavior change in Atomic Habits is behaviors that get immediately rewarded, get repeated, behaviors that get immediately punished, get avoided, and it’s really about the speed and the intensity of that feedback.” – James Clear

- The quicker the feedback occurs, the quicker change in behavior occurs
- Intensity is also important, feedback needs to be meaningful to change behavior
  - It can’t be so low that it doesn’t register
  - It doesn’t need to be too intense either
- Peter notes that one of the themes of James’ book is that willpower is not a great long-term strategy to change behavior

## The role of genetics and innate predispositions in determining one’s work ethic and success in a given discipline [14:30]

**James’s younger years**

- What was James like in high school? Was James a beacon of ‘discipline’ or a normal guy?  Did he have a hard time doing what was right?
  - It depends on the context, says James
    - If people looked at school, then yes he was disciplined; otherwise, maybe not
  - He always liked school; he played the middle ground between a nerd and a jock
    - He felt like a nerd on the sports teams he was on
    - In the science lab, he felt like the jock
    - He learned how to get along in both groups which was helpful socially and early in life
  - He thinks he thrived more in school than in sports; he barely played sports in high school
    - He played a total of 11 innings of baseball in highschool
    - In college, he blossomed and ended up being an academic [all-American](https://en.wikipedia.org/wiki/All-America) in baseball by the time he graduated

**Is there a behavior James has struggled with?**

- James would avoid things he struggled with, things he thought he would be bad at
  - It took a decade or two to overcome that wiring so he could start to take more risks and try things he didn’t think he would be good at

**How does free will pertain to habits?**

- The work of [Sam Harris](https://en.wikipedia.org/wiki/Sam_Harris)
- James did an [episode](https://samharris.org/subscriber-extras/200-creatures-habit/) on Sam’s podcast ([Making Sense Podcast](https://samharris.org/podcast/making-sense-episodes/))
- Sam Harris has written and spoken extensively about the idea that we actually don’t have free will, that this is an illusion
  - For example, he uses a very clever thought experiment, which is, “*If I tell you to think of a movie, the first movie that pops into your head, you have no control over what that’s going to be.*”
  - Conversely, there’s a part of Peter that thinks, “*Okay, but there were lots of things I have free will over, my ability to go and do something, take an action, go and exercise,” or something like that, but the deeper I get into this thinking, the more I start to realize, “Well, wait a minute, that may still be innate.*”
    - For some people it requires a lot of effort to exercise; for Peter, it requires virtually no effort to exercise
    - For some people it requires a lot of effort to mind what they eat; but we all know people for whom this is not the case
- James feels that going out to exercise is easier for him than health eating
  - It’s interesting to think about where one has certain inclinations and maybe not others
- With free will, he understands the argument, “*there’s this very long chain of atoms that are essentially colliding and leading us inevitably to the next action or the next thought or whatever, and if we could map them all out, then perhaps we could just predict everything that’s about to happen*”
- In daily life he acts as if he has free will
  - Ultimately, he feels that nobody knows the answer one way or another
  - If it’s all predetermined, then what he does doesn’t matter
  - If it isn’t predetermined then he’s going to choose the thing that he thinks serves him best
  - From a practical standpoint, he doesn’t see a reason not to choose the best option one can
    - If free will exists, one will be glad they did
    - If there isn’t free will, the same result will happen anyway so who cares

> “So whether I’m making that choice that best serves me or whether it was predetermined that I’m going to make the good choice, it kind of doesn’t really matter to me” – James Clear

- Peter thinks it might be that free will or the absence of free will is what determines a person’s propensity to change habits or form habits
- Maybe it’s easier for some people to change habits; it’s probably a spectrum
  - This doesn’t imply that a person who struggles with a given behavior can’t learn to master it

**The genetic component**

- Maybe there’s a genetic component
  - For example, Peter is never going to be as good a swimmer as [Micheal Phelps](https://en.wikipedia.org/wiki/Michael_Phelps), even if his parents threw him in the pool at age 2 and Michael didn’t start swimming until age 15
- Will it be easier for some people to go through the exercises needed to change habits and for other people will it be more difficult; and is this a difference that cannot be changed?
- James discussed something similar with his friend [David Epstein](https://en.wikipedia.org/wiki/David_Epstein_(journalist)) (he’s known for his work on the books [The Sports Gene](https://www.amazon.com/Sports-Gene-Extraordinary-Athletic-Performance/dp/161723012X/ref=sr_1_1?dchild=1&keywords=the+sports+gene&qid=1634062326&s=books&sr=1-1) and [Range](https://www.amazon.com/Range-Generalists-Triumph-Specialized-World/dp/0735214484/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=))
  - David said one of the things that surprised him, when he was researching *The Sports Gene*, is that characteristics that he thought would be mostly genetic (strength and speed and things like that) turned out to be heavily influenced by training and choice
    - Then qualities that he thought would be a choice, like grit and perseverance and desire to train turned out to have a much higher genetic component than he realized
  - Take the tennis legend [Steffi Graf](https://en.wikipedia.org/wiki/Steffi_Graf) for example, when she was 14 she participated in a study; she not only tested the highest for physical abilities like strength and speed and quickness and so on, but also tested the highest for competitiveness and desire to train and all these other things
    - Think of how pointless it would be to compete against her
    - Not only is she better than you, she also wants it more
  - James does think there is a heavy genetic component to some of the mental characteristics that would make you more likely to train
- Going back to the example about Michael Phelps, on the surface it seems like this comparison would make one less motivated
  - “Why even try? I’m never going to be Michael Phelps,” or, “If genes play such a large role, what’s the point?
    - James thinks this is the wrong less ot to take away
    - The primary lesson is that genes tell one where to work hard; they inform one’s strategy

## How finding one’s passion can cultivate perseverance and discipline [23:15]

- James discussed grit with his friend David Epstein, and the question came up, what if this grit/ perseverance/ discipline is one’s natural propensity based on the thing they are working on?
  - If a person is highly interested in something, what are the chances they will have increased perseverance and discipline in that area?

> “It’s very hard to beat the person who’s having fun because they’re going to want to keep working longer than the person who’s suffering, so grit is fit, I think is one way in which you can maybe try to stack the deck or stack the odds in your favor and get your genes aligned with the things that you’re working on” – James Clear

- Not all of us are going to have the good fortune to discover whatever the thing is we are interested in and good at at 4 or 6 years old
  - Going back to the Michael Phelps example, he began swimming at age 7
    - It’s very hard to find someone who’s more optimally designed to move through the water than him
  - This doesn’t mean that one should stop searching for what they are good at and passionate about
  - A person who is curious and willing to explore a lot of things is more likely to come across an area where they are fascinated or they are interested, and it also is a really good fit for their natural abilities or propensities
- From a genetic standpoint, anyone can improve but this doesn’t mean anyone can be Michael Phelps

**Key point:**

- Find what is interesting so it doesn’t feel like suffering in the same way that other people feel when they are trying this thing

> “You’ll often be surprised how far you can go and how willing you are to build habits and improve skills if you find some of those things that you’re truly fascinated by” – James Clear

**Hating to lose**

- Passion about that thing one finds they are interested in goes a long way toward driving success
- For example, Peter relates watching Michael Phelps race at meets that meant nothing
  - Michale is not shaved or tapered, he couldn’t care less to be there, it doesn’t look like he is going to win, yet somehow in the last 15 meters, he out-touches everyone
  - Peter’s impression is that Phelps is a guy who hates losing
  - Even when Michael is not in shape, the meet means nothing for him, and half of the people he’s competing against, this is their pinnacle; he hates losing so much
    - It’s a perfect combination for winning
- James has the same takeaway watching [The Last Dance](https://en.wikipedia.org/wiki/The_Last_Dance_(miniseries)) (a miniseries about the career of [Michael Jordan](https://en.wikipedia.org/wiki/Michael_Jordan))
  - Once when Jordan was recording [Space Jam](https://en.wikipedia.org/wiki/Space_Jam), after a 12 hour day filming he and the other NBA players went outside for a pickup basketball game
    - He could not handle losing even a pick up game
    - It would bother him so much not to get it right, not not win
    - James thinks this is a drive that Jordan cannot turn off; he doesn’t know any other way to be
    - Call it personality or genes, that’s just how he’s wired
    - James loves seeing that characteristic in any domain
- Another example is the musician [Maggie Rogers](https://en.wikipedia.org/wiki/Maggie_Rogers), she put a post on Instagram of all her notes on a song she was working on
  - She commented that the cymbal needed to come in a second earlier and a bunch of other stuff
  - She shared a clip of her listening to it with her producer
  - It was obvious that she cared so much about the details; it would bother her if the song was not as good as it could possible by
    - Maybe that’s the musician’s version of hating to lose
  - James loves to see this characteristic; he says “*It kind of lights me up. It makes me want to be that way about whatever thing I’m working on*”

> “If you can find that area where it would bother you for it to not be right, I got to think you’re going to get much better results there than most people, because most people will get bored or move on or get tired or frustrated, and the person who just will not stop unless it’s right is going to end up with better results” – James Clear

- It sounds simple to say, but the way to have great results is not to lower your standards

**Lessons learned from the sport of Formula One racing [27:45]**

- [Formula One](https://en.wikipedia.org/wiki/Formula_One) is one of Peter’s favorite sports and one of his hero’s is [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna)
  - James had never heard of him until he watched the [documentary *Senna*](https://en.wikipedia.org/wiki/Senna_(film)); after this he was completely hooked
  - Senna was a perfectionist even amongst his peers; he took it to a level that exceeded that
    - It cost him his life
    - That need to win killed him because he was trying to do something in a car that shouldn’t have been done at that time
    - It’s an amazing sport where the stakes are so high for trying to do something at the expense of a mechanical limit of the car, but yet, all drivers will tell you they’re going to go for it
- Senna’s death changed Formula One forever because it imposed safety in the sport
  - Prior to this the debate focused on telling drivers to drive slower
  - Driving 10% slower is nonsense
  - The head of the [FIA](https://en.wikipedia.org/wiki/F%C3%A9d%C3%A9ration_Internationale_de_l%27Automobile) (International Automobile Federation) at the time remarked that “all drivers will choose to have a less safe car if it goes faster”
    - These are the 20 most competitive drivers on the planet

## Advantages of creating systems and not just setting goals [29:15]

- Peter remarks that “*for most of us, we will never know what it’s like to be the top thousand in the world of anything*”
- Peter reflects on the things he loves to do: driving a race car, shooting a bow and arrow, exercise, and realizes he is multiple orders of magnitude beneath even the most lowly ranked profession of these things
  - The joy he gets from these pastimes is not in the absolute comparison of himself to others, but the relative comparison of where he was before

**What are the mechanisms that underlie success in an activity?**

- 1) Is it universal that people are mostly engaged by how much they are making progress relative to their own performance?
- 2) Are there some people who are only capable of finding pleasure when being compared to others in an absolute basis?

- James thinks both of these things are universal
  - The most motivating feelings to the human mind is the feeling of progress; it feels good
- He thinks at *a base level, we are goal-directed organisms* in the sense that we have a goal to get food or water or to procreate or to be safe, etc.
  - Now, with our complex brains and modern society, we come up with many other goals that are outside of just our basic needs
  - But still one wants to move toward a goal and resolve the tension, the gap between that goal and our current state as much as possible
- He also thinks its universal to have some bias towards status, prestige, rank, and hierarchy
  - It feels pretty good for anyone to win the game or have the best score on the scoreboard or climb the leaderboard and see themselves occupying a higher rung relative to those around them
  - It’s probably a spectrum; maybe some people have the dial turned up real high on the status part and maybe lower on the internal measures (and for other people it’s the reverse)

**Comparing focus on the journey to focus on the destination [32:00]**

- Put this in the context of weight loss; the goal is to lose 10 lbs., the process is to change one’s way of eating and exercising
  - Weight loss isn’t going to happen in a linear fashion, but that goal of losing 10 lbs. and fitting into a certain piece of clothing is a driving force
- Contrast this with learning to speak a new language
  - One can enjoy the process of learning a few new words every day, learning how the structure of the grammar works
  - One can realize they will never be perfectly fluent in that language but at some point they will be functional
  - This journey of learning can be pleasurable
- James has been very goal-oriented for most of his life
  - He would set goals for grades he wanted to get in school, for weight he wanted to lift in the gym, for numbers he wanted his business to hit
  - He found a note he made in his sophomore year of college listing goals he wanted to hit by the time he graduated
    - He hit about half of them
    - Setting the goal was not the thing that made the difference (or else he would have achieved all of them)
- James realized that goals were not the primary thing that drives results
  - In most domains, winners and losers have the same goal
  - Maybe a goal is necessary but it cannot be the distinguishing factor; maybe it’s not sufficient

**Distinguishing systems and goals**

- In the book ([Atomic Habits](https://www.amazon.com/Atomic-Habits-Proven-Build-Break/dp/0735211299/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634054380&sr=1-1)) James explains the [difference between systems and goals](https://jamesclear.com/goals-systems)
  - The goal is the desired outcome or target
  - The system is the collection of daily habits one follows
  - If there’s ever a gap between one’s desired outcome and one’s daily habits, daily habits will always win

> “Almost by definition, your current habits are perfectly designed for your current results” – James Clear

- For any goal one is pursuing, it’s not the results that need to change; it’s the habits, the input
  - Fix the input and the output will fix itself
- In some areas (like shooting a bow and arrow) the connection is obvious, but in other areas, the connection is not as clear but the pattern is still there
  - Adjust the habits, “g*et the machine running in a more fluid fashion*”, and the results will come naturally
  - Simply appreciating this will help rewire one’s mindset a bit
- James was so focused on outcomes and goals for a long time but now he realizes that the way it is achieved is with with the system, his habits
  - This realization helped him shift from focusing solely on goals to focusing on optimizing his system

> “What I would say now is like goals are for people who care about winning one time. You set a goal to run a half marathon and you train for three months and you do it and you complete the race, but then maybe you stop training after that.” – James Clear

- Systems are for people who care about winning again and again
  - This mental shift can be useful for sustaining results

## The power of habits combined with self-identity to induce change [36:30]

**Habits are a powerful force for change**

- A quote from [Archilochus](https://en.wikipedia.org/wiki/Archilochus) (a Greek poet) captures this well, “You don’t rise to the level of your expectations. You fall to the level of your training.”
  - James tweaks this to say “*You don’t rise to the level of your goals. You fall to the level of your systems* ”
    - It’s actually one’s habits that create that baseline
- In the title of *Atomic Habits,* it uses the atom as a metaphor to conveys 3 things:
  - (1) Habits are small (like an atoms); each should be small and easy to do
  - (2) Put the habits together and one ends up with their lifestyle or daily routine
  - (3) Habits (like atoms) are a source of immense energy or power

- “*The narrative arch of the book is to make changes that are small and easy to do; layer them on top of each other and like units in a larger system (or atoms in a molecule), collectively, they produce some really remarkable results*.”

**Incorporate the new behavior into one’s identity to sustain change**

- Peter read something in the book that resonated with him and provided a good explanation for why exercise comes naturally to him which is “*it’s so hardwired into my identity and why maybe certain other habits I’ve tried to create over time don’t come easily to me, because I haven’t fully identified with them yet.*”
- James remarks that “o*f all the ideas in the book, this is probably the least scientific. There are actually some studies, which I cite in that chapter and it’s not like there’s no science behind it.*”
- The concept of making something part of one’s identity is one philosophy behind how behavior change works
  - He also thinks this may be the only unique idea he has
  - Everything else in the book has been widely covered by other people and known for hundreds if not thousands of years

**Habits are an important component of one’s identity**

- On the surface-level, habits help one achieve external things, be more productive, be more fit, etc.
- On a deeper level, habits signal internally to one’s self about who they are and what they care about
- Habits are a signal of the story that we’re telling ourselves

> “In a sense, every time that you perform a habit, you are embodying a particular identity” – James Clear

- When one makes their bed, they embody the identity of someone who is clean and organized
- When one shoots basketball for 30 minutes, they embody the identity of someone who is a basketball player

- Doing things once or twice does not radically transform one’s story… but continuing it every day for 6 months or 2 years, at some point it crosses this invisible threshold where it becomes part of one’s identity
  - Habits provide evidence, proof of the story one is telling themself
  - This story is a very powerful thing; it’s deep, it’s personal
  - Maybe this story is why habits matter

**Identify the desired outcome**

- Going back to the question about process versus outcome versus identity, and how one changes, it begins by thinking about the outcome one desires
- Using weight loss as an example
  - Maybe one wants to lose 40 lbs. in the next 6 months
    - So they work out a nutrition and exercise plan to follow
    - Sometimes it stops with in the detail planning phase
  - The assumption is “If I do those things and I lose that weight, then I’ll be the kind of person that I want to be.”
- James suggests working backwards, instead of asking “*Who is the type of person I wish to be? What is the identity that I’d like to have?*”
  - One could ask a person with that identity, what kind of habits they have

*Use identity to inform process, to develop habits and let the outcome happen naturally*

- For example, James relates a story from one of his readers; she lost 110 lbs. and kept it off for over a decade
  - The question she carried around with her as she began her weightloss journey was “*what would a healthy person do?*”
    - This oriented her with the identity of a healthy person
    - For example:
      - Would a healthy person take a cab or walk 4 blocks to their meeting?
      - Would a healthy person order a salad and chicken or hamburger and fries
  - She carried this question into every context and used it to make choices that felt aligned with this identity she wanted to have instead of worrying about something specific

> “If you don’t have that shift in internal story yet, it’s hard for the behavior to follow suit” – James Clear

- Imagine if you went up to 2 people and said  “Hey, would you like a cigarette?”
  - The first person says, “Oh, no, thanks. I’m trying to quit.”
  - The second person says, “Oh, no, thanks. I’m not a smoker.”
    - Technically they’ve both done the same thing, turned down the cigarette
    - The first person is trying to be something they’re not
    - The second person has signaled a shift in identity change
- Getting to that stage of shift in identity is powerful for changing behavior because one’s not really trying to change anymore; one is acting in alignment with the type of person they see themself as

![](https://peterattiamd.com/wp-content/uploads/2021/11/identity-jamesclear-1024x663.png)

**Figure 1. Layers of behavior change.** Credit: [jamesclear.com](https://jamesclear.com/identity-based-habits)

**Elements of change [45:15]**

- In the beginning of change, one does not genuinely believe the desired identity about themself
  - The woman who lost 110 lbs. didn’t yet believe she was a healthy person so she carried this question to guide her decisions until the internal story was real for her
- It’s possible to have an epiphany and to change cold turkey or to just flip a switch and suddenly start acting in a different way
  - It rarely happens from some bolt of lightning insight
  - Probably the most common way it happens is by reading books
    - A book can change one’s worldview and they can start to do things completely differently after that
    - For example, someone reads a book that convinces them that carbs are the devil and that grain is terrible
      - The next day they want to throw out all the bread in the house; this is a sudden change
      - Sudden change is possible
- James doesn’t think that changing through an epiphany is very reliable
  - It’s not something one can plan or strategize for
  - Maybe it happens a couple times in one’s life
  - It’s not an efficient way to build a new habit

**What are the options if one wants to change their identity? [46:30]**

> “I think the best avenue that you have is to cast votes with your actions. In a sense, every action you take is like a vote for the type of person you wish to become.” – James Clear

- Doing one push-up does not transform the body, but it does cast a vote for “I’m the type of person who doesn’t miss workouts.”
- You often hear “*fake it till you make it*”
  - The difference in James’s method is he’s asking one to believe something positive about themself
    - Belief without evidence is delusion and at some point the brain doesn’t like this mismatch
    - To believe the new story about one’s self, actions need to feel aligned with this story; this begins with small habits
    - Small habits, small changes, prove this new story is true
- Going back to the woman who lost 110 lbs. and kept it off for a decade, Peter notes that losing weight isn’t difficult but keeping it off for this long is remarkable

**What happens in the temporal sequence of change?**

- Is it a daily struggle for the first year?
  - Constantly asking the question “what would a healthy person do?”
- When does this transition to “I’m a healthy person and this is what I do”?
  - When does it become autonomic that when one slips up, it feels wrong?
  - For example eating cotton candy feels horrible
- Whether it’s a habit or not, if one is bothered when they don’t do something, that is a signal that the ‘something’ is aligned with their identity
  - “Oh, I feel like I’m not being me if I don’t do this.”
- This process can be long
  - James has a friend who worked hard to lose weight and she had to lose 60 lbs. before the first person noticed
    - That is a lot of work in what feels like a vacuum, doing for one’s self without external feedback from the world
- One has to fall in love with the system and thing that go into it because change is an internal journey and it will take longer than one might imagine in a lot of cases

## How a big environmental change or life event can bring on radical behavioral change [50:30]

> “One of the most common examples that I hear of in my practice for the epiphany behavior change that sticks, is the person who quits smoking the day their child is born.” – Peter Attia

- There’s no one who smokes who doesn’t know the risks of it
  - It’s very rewarding in the short run, yet very damaging in the long run
  - Understanding the risks is intellectual
- But the day one has a child and decides “*I’m not going to have smoke in my household because I also know the harm rather of secondhand smoke. I’m not going to expose my child to this.*”
  - Peter hears these stories over and over of patients who grew up in a household were their parents were smokers and the second they were born, the parents stopped smoking; and that was 40 years ago
  - Is there a transference process here where, because it involves the life of another person, it’s easier to make this change stick?
- Massive environment changes or lifestyle changes are a good way to hack a radical change in one’s life; they’re a good way to make an epiphany stick
  - Examples include: having a kid, getting married, changing jobs, moving to a different city
  - Even something small like getting a dog can lead to rapid behavior change
  - It’s crucial that the decision is irreversible or at least hard to reverse
- An example from James’ life, one thing he has struggled with is going to bed early
  - He always gets 8-9 hours of sleep
  - But at 9 or 10 o’clock at night he often gets a second wind and thinks, “Well, maybe I’ll just send a few emails or something.” Of course, it’s never just a few.
    - Then it’s midnight of 1 am and he knows if he is to sleep 8 hours that means he won’t get up until 9 am
    - He prefers to get up early, and knows he feels better throughout the day if he does
  - But he keeps getting in this situation at 10 pm where he ruins things for himself the next day by staying up late
  - He’s tried many things to break this habit
  - He tried an outlet timer; plug it into an outlet and set the time for when it kills the power from that outlet
    - Plug the internet into it and at 10 pm it shuts off
    - But there are ways around this
  - The thing that made it stick was getting a dog, because the dog is going to get up at 7:00 AM and need to go for a walk
    - This worked because it was fairly hard to reverse getting a dog
- Having a child is permanent, they’re going to be there every day now
  - Maybe before one could rationalize not changing but once the child is there, it’s really immediate
  - The feedback loop is even tighter than before

> “Those irreversible or hard to reverse lifestyle changes also tend to be big drivers of quick behavior change” – James Clear

## The influence of one’s social environment on their habits [54:15]

**Making new habits stick**

- Peter can only think of one dramatic habit he changed that has stuck and it is the silliest thing, but he always bit his nails growing up, bit them nonstop
  - The day he decided to change was the day he got his first interview for med school
  - It was the first time he had to do an interview and something just came over him; he didn’t want to show up with horrible looking nails
  - So he stopped biting his nails 25 years ago
- James replies that there are 2 things this example brings to mind:
  - 1) It connects to identity

- Peter takes pride in how he’s presented

- The more the pride, the more the behavior starts to stick
- For example, consider a woman who takes pride in how her hair looks; she probably has all kinds of hair care habits and products and doesn’t have to convince herself to do them the way one might with other habits
  - “oh, I wish I could workout or something”
  - Nice looking hair is just an element of her identity she takes pride in so she does it fairly consistently
- Another example would be a guy who gets complimented on the size of his biceps
  - So he never skips an arm day at the gym because it’s an aspect of his identity that he takes pride in
- When one takes pride in something, they’ll fight pretty hard to keep it
- This is something one does naturally, or are internally motivated to continue doing it

- 2) The influence of the **social environment** on habits is huge

- This has come out since *Atomic Habits* was published and James thinks it’s even more important than he realized when he was writing the book
- In Peter’s example, it was the med school interviews, the image in his mind, the expectation of how he should present himself, the judgement of others that helped to drive that change
- Behaviors that stick for a long time (10, 20, 30 years, etc.) often have a strong social component involved

**The social component of a habit**

- Everyone is part of multiple tribes, some large (being an American) and some small (being a neighbor on one’s street)
- With the neighbor example, one might walk outside and see their neighbor mowing the grass and think “Oh, I need to cut my lawn.”
  - This habit will persist for as long as one lives there, 20 or 30 years
  - Why does one do it?
    - It feels good to have a clean lawn
    - Mostly though, one doesn’t want to be judged by their neighbors as being sloppy
- That social norm, that expectation for being part of the tribe helps a habit stick
  - A practical takeaway is, if one really wants a behavior change to last, then join a group where this desired behavior is the normal behavior
  - If it’s normal in that group then it’s going to seem much more normal personally and one is more likely to do it

> “I think maybe the deeper lesson here is that we don’t just do habits because of the results they get us.” – James Clear

- When one adopts behaviors, it’s a signal to those around  them that “*Hey, I get it. I fit in. I understand how to act in this group.*”
  - Most people choose belonging even if it come with habits they don’t really love; it feels good to go along with the crowd
  - If the habits they want go against the grain of the group, they won’t fit in well and may get ostracized

> “The desire to belong will overpower the desire to improve. You want to make sure you get those two things aligned. To join groups where your desired behavior is the normal behavior.” – James Clear

## How and why habits are formed [1:00:30]

**How do habits form?**

- As James researched for his book he tried to understand why behaviors happen and how do they happen; how do habits form?
- He found 40 different models of human behavior that scientists of all types had come up with over the last 150 years; broadly they fall into 1 of 2 categories
  - (1) Motivation models

- This explains internal drives, motivations, and cravings that compels one to act

- (2) Reinforcement models

- This describes rewards one gets from behaviors and how this reinforces behavior
- It describes what happens after an action

- He wanted to come up with a model that accurately described both the motivation that occurs before a behavior and the reinforcement that comes after
  - He wanted to understand how these 2 things influence the actions one takes

**Questions James asked in the research process**

- Many questions he thought were fairly simple about human behavior were not totally answered by these previous models
- For example, *what causes someone to try a new habit in the first place?*
  - No reward has been experienced yet
  - [B F Skinner](https://en.wikipedia.org/wiki/B._F._Skinner) and [Charles Duhigg](https://en.wikipedia.org/wiki/Charles_Duhigg) in [Power of Habit](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634146746&sr=1-1) popularized the *cue-routine-reward*
    - This describes the neurological pattern that governs a habit
    - It always starts with a cue, a trigger that tells the brain which habit to use
    - Last is the reward which helps the brain determine if this particular behavior is worth remembering for the future
- James also asked, “*why do 2 people respond differently to the same thing?*”
  - Consider the example of smoking; when 2 people see a cigarette why would one feel like “*Oh, I have to smoke.*” while another person’s like, “*I’ve never smoked a day in my life. I’m not interested at all*.”
  - Another example, James walks into his kitchen at 7 AM and sees a loaf of bread and thinks  “Oh, I’m going to make some toast for breakfast.”; then he walks in at 4 PM and sees the same cue but doesn’t think anything of it; he just moves on
  - But… if *cue leads to action* then why does the same cue elicit different actions in different people or even different actions in the same person?
- One of the meaningful components of the 4 stages he put together (and why he feels it accurately describes human behavior) is an insight he came across while researching this book
  - A neuroscientist named [Lisa Feldman Barrett](https://en.wikipedia.org/wiki/Lisa_Feldman_Barrett), she has published many studies and books on emotion
    - One book in particularly was helpful, [How Emotions Are Made: The Secret Life of the Brain](https://www.amazon.com/How-Emotions-Are-Made-Secret/dp/0544133315/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634147554&sr=1-1)
    - One key insight is that human behavior is often thought of as reactive
      - Someone does something and one responds
      - Someone says something and one feels a certain way
    - Human behavior is mostly predictive; one is endlessly going through their experience in life, predicting about what to do next
    - This element of prediction is a key thing missing from many of the previous models of habits and behavior

**Reward and dopamine**

- Peter recalls a discussion in James’s book about the dopaminergic surge coming more from the **anticipation** of the reward than the actual behavior that gives the reward
- There are a bazillion studies on [dopamine](https://en.wikipedia.org/wiki/Dopamine)
  - Dopamine is not the full story about habits, many neurochemicals are involved in the process and dopamine is just one part of the big picture
  - Initially it was thought that dopamine was involved in reward, satisfaction, and enjoyment
  - The crucial role dopamine plays is about *prediction and anticipation*
    - Think of the first time one ever takes a bite of a pancake; one doesn’t know what to expect
    - After taking that bite, one gets a surge of dopamine almost as if to mark the experience or say “Hey, that was good, let’s do it again”
    - The next time one sees a pancake, they know what to expect
  - Studies find that dopamine spikes **before** one takes a bite, not after
    - Similarly, there are a bunch of studies that show gamblers get a spike of dopamine before they roll the dice, not after
    - Drug addicts get a spike before they take a hit of cocaine, not after
  - In this context, dopamine is probably a *learning molecule*
    - It helps mark a favorable experience so one remembers it when one comes across a similar situation

**The process of a behavior is:**

- (1) See a cue
- (2) Get a craving, and it’s the craving (or anticipation or prediction) that motivates action
- (3) Respond
- (4) Outcome

**There is a lot of diversity between individuals**

- Consider 10 people who have never smoked a cigarette
  - Maybe 7 have no desire to smoke; they walk away
  - Maybe 3 will give it a try
    - One coughs and is disgusted; they never smoke again
    - One decides they kind of like it and will smoke socially; whenever they have a drink they also have a cigarette
    - One goes on to become a chain smoker
- How much of the difference between these people is neurochemical?
  - His book isn’t about addiction but from what he has learned, there is a strong genetic or neurochemical component to this
  - It seems like drugs hack the system
  - One way to define addiction is as a learning process that is broken
    - Addicts know the behavior does not benefit them in many ways but they cant help themselves; they can’t stop doing it
    - Drugs give a spike of dopamine when one shouldn’t be getting it; this breaks the process of learning to drive a behavior that doesn’t provide benefit
- Different people get pleasure from different things
  - When Peter is unhappy, he never thinks to have a drink
    - In this example, alcohol is only associated with something he wants to do when he feel good
    - He would never drink when he doesn’t feel good
  - When he doesn’t feel good he would happily binge on junk food
  - But there are people who would never want to eat in this situation, let alone junk food
  - It’s interesting to contemplate how much of this is genetic and how much is learned
  - Does this fall to the level of habits?

**Learned vs. genetic**

- James agrees, there is a genetic component; some people are more sensitive to certain substances than others
- He also thinks that it’s possible that much of it is learned
  - Maybe Peter has a story that junk food is the way to cope
- James says, “*Habits are solutions to recurring problems that one faces*”
  - For example, one recurring problem is that of coming home exhausted
    - So one person comes home and plays video games for 30 minutes
    - Another person comes home and goes for a run
    - A third person comes home and smokes a cigarette
      - All of these people are responding to the same underlying problem, but they are choosing different methods
- How do these habits get formed?
  - When someone learns that a certain method is effective in solving a problem, that tends to be the default even if it’s not the only way to solve that problem
    - Going for a run might make someone feel better but if they are used to smoking a cigarette, they develop a story around that solution
    - That story becomes a little bit of their identity; there is a learned component as well

## How to make or break a habit with the “Four Laws of Behavior Change” [1:09:30]

**The 4 components of a habit:**

- (1) Cue
- (2) Craving
- (3) Response
- (4) Reward

*Example:*

- - Cue
    - The cue is something one notices that starts a habit
    - One sees a plate of cookies on the counter and starts the habit of eating a cookie
  - Craving
    - The craving is the prediction or meaning assigned to that cue
    - This often happens quickly or automatically
    - One sees a plate of cookies and thinks yum, that will be sweet, sugary, tasty, enjoyable

- *It’s that favorable expectation that leads to that dopamine spike that motivates the 3rd step, the response*

- Response
  - The response is to walk over, pick up a cookie, and take a bite
- Reward
  - The reward is the sweet, sugary, satisfying taste of the cookie

![](https://peterattiamd.com/wp-content/uploads/2021/11/habit-loop-jamesclear-830x1024.png)

**Figure 2. Habit Loop.** Credit: [@jamesclear | Twitter](https://twitter.com/JamesClear/status/1059507532006375424/photo/1)

**A deeper dive**

- Not every behavior in life is rewarding; some are neutral, some have a cost
- Behaviors that are not rewarding are unlikely to become a habit because there is no reason to repeat it in the future
- There is a need for a positive, emotional signal to be associated with a behavior for one to stick with it
  - An immediate signal that says “hey, that was enjoyable”
- In Psych 101 class it is taught that most addictive behaviors are [variable reinforcing](https://en.wikipedia.org/wiki/Reinforcement#Intermittent_reinforcement_schedules)
  - This is why slot machines are particularly addictive because the pattern with which they produce a win is actually random
  - With the belief that one will win, and the memory of winning in the past, this becomes more addictive
  - With the cookie example, this is not variably reinforcing; it pretty much reinforces the same way every time
- There have been tons of studies on variable rewards and yes, they tend to accelerate or intensify behavior
  - With slot machines, studies have found that the sweet spot tends to be right abournd 50/50
  - Studies of mice doing a nose poke in a box for a squirt of sugar water find that when using a variable reward schedule the mice would nose poke something like 6,000 times in an hour
  - The average slot machine player will press the button like 800 times in an hour
  - A quote from the movie [Anchorman](https://en.wikipedia.org/wiki/Anchorman_(film_series)), “*50% of the time it works every time*”
    - Little did we know that Will Ferrell was a cognitive psychology fan
    - This was Pal Rudd’s line in [Black Panther](https://en.wikipedia.org/wiki/Black_Panther_(film)) too, “*50% of the time it works every time. I’m going to be honest with you. That smells like pure gasoline. It’s got bits of real panther in it. It’s made by Odeon.*”
- James enjoyed researching this book and interpreting research performed by academics; he’s not an academic
  - The hallmark of his work is his ability to make these ideas actionable and turn them into something anyone can apply to daily life

**The Four Laws of Behavior Change:** How to apply the 4 steps of a behavior (cue, craving, response, and reward) to the creation of a new habit

*1—Make it obvious*

- Make the cues of a good habit easy to see, the easier they get one’s attention the more likely one is to act on them

*2—Make it attractive*

- The more appealing or exciting a habit is, the more likely one is going to feel motivated to do it
- The more something is anticipated, the more motivation one will feel to do it

*3—Make it easy*

- The more convenient and simple a habit is, the more likely the behavior is to be performed

*4—Make it satisfying*

- The more enjoyable or pleasurable a habit is, the more likely one is to repeat it in the future

*These 4 laws give a high-level overview of how to build a good habit*

- It doesn’t require all 4 every single time, but the more of the 4 there are, the more likely it is that the good behavior will stick
- Using more of the 4 also makes it more likely that one will start on the new habit

**Invert these 4 laws to break a bad habit**

1—Make the cue invisible

- Reduce exposure to the cue
- Reduce exposure to the thing that starts the process
- For example. if one is on a diet then don’t follow food bloggers on Instagram

2—Make it unattractive

3—Make it difficult

- Put more steps between one’s self and the behavior

4—Make it unsatisfying

- Layer on an immediate consequence to the behavior
- Add a cost to the behavior

![](https://peterattiamd.com/wp-content/uploads/2021/11/four-laws-jamesclear.png)

**Figure 3. Four Laws of Behavior Change for good and bad habits.** Credit: [radreads.co](https://radreads.co/atomic-habits-james-clear/)

## Practical tips for successful behavioral change—the best strategies when starting out [1:16:15]

- Often a behavior change is a combination of breaking a habit and creating one
  - Using nutrition as an example: stop poor eating habits and start eating better
- James sees this as 2 sides of the same coin in most cases
- When he is changing a behavior he doesn’t usually think about breaking bad habits
  - Most of the time he’s focused establishing new, good behaviors

**3 ways to break a bad habit**

- 1) *Eliminate* it entirely, go cold turkey and never do it again

- For example, never drink beer again

- 2) *Curtail* the behavior to the desired degree, reduce it

- For example, instead of drinking a beer at dinner every night, drink it once a week

- 3) *Replace* the behavior

- For example, replace beer with water

- A  new habit often displaces an old one
  - Consider the growth of a plant as a metaphor
    - There are 2 plants growing side-by-side, a good habit and a bad habit
    - As the ‘good’ plant grows it starts to crowd out the ‘bad’ plant
    - The ‘good’ plant will soak up more energy and resources and grow at the expense of the ‘bad’ plant
    - It’s [zero-sum](https://en.wikipedia.org/wiki/Zero-sum_game) in the sense that there are only 24 hours in the day

**Growth mindset**

- James likes the mindset of trying to spend his 24 hours in the best way possible, moving toward whatever he is optimizing for, rather focus on a mindset of breaking bad habits
  - This gives a reason to improve even once good habits are established
  - This enables a mindset of “how can I grow?” rather than thinking about breaking bad habits

**One example, stopping the habit of smoking**

- Peter asks about the habit of smoking
  - It doesn’t take that much time
  - It’s going to be hard to introduce a new habit that will force smoking out
- James thinks it is helpful to divide the smoking habit into specific instances when it happens
  - Smoking is often lumped into a single habit, but the truth is it actually might be a collection of like a dozen habits throughout the day
    - Maybe there is the habit of smoking when one gets into the car for the morning commute
    - There could be the habit of smoking around 10:30 when one takes a break with a coworker
    - There could be a habit of smoking after dinner on one’s porch
    - Each of these 3 have their on cue, craving, response, and reward
    - Each of these should be addressed separately

> “In a sense, you kind of have to intervene in like 12 different places to try to come up with a solution for each one of those.” – James Clear

- Maybe during the morning commute one could have a cup of coffee instead of a cigarette
- Maybe trying an e-cigarette at 10:30 during the break with the co-worker is a place to start
  - One wants to maintain this feeling of socializing with a friend

- A habit like smoking needs to be addressed in different stages
  - It needs to be broken down to a degree where it’s easier to have a line of attack

**Environment and cues**

- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) writes in his commencement speech [*This is Water*](https://www.amazon.com/This-Water-Delivered-Significant-Compassionate/dp/0316068225/ref=sr_1_1?dchild=1&keywords=this+is+water&qid=1634221617&s=books&sr=1-1), about the ubiquity of water and what makes it profound is that one doesn’t even realize it’s there
  - He’s referring to thoughts
  - The same is true of cues; most people aren’t aware of the cue that starts the habit
  - The example of having a cigarette at 10:30 with a coworker is powerful because of the connection in the environment
- Peter relates a story from his residency in Baltimore, a place where there was rampant IV drug use
  - He treated patients who came to the hospital with abscesses from IV drug use
  - It’s amazing how that addiction (that habit) could cause a person to do something that at the surface doesn’t seem that logical
    - Use dirty needles
    - Have needles break in their abscesses
  - He would drain huge, baseball-size, pus-filled abscesses that had broken needles in them
    - The patient would be very sick; this is now life-threatening
    - Yet, the patient would be back in a month with the same thing; over and over
    - Many people would die
  - The best advice Peter could come up with was to suggest these patients not go back to the same place where they lived; he suggested they find new friends
    - He acknowledges this is not very helpful for someone who doesn’t have many choices
    - How can one expect a person to go back to the same place they were living, the same environment, with all the same people doing the same things, to “just resist it”; it doesn’t make sense
      - Similarly, if someone wants to stop drinking alcohol, theo ought not go into a bar anymore
- James compares environment to gravity; it has a pull that can be resisted for a bit but at some point it drains a person and sucks them back in
- The environment is what prompted the behavior in the first place
- One story from *Atomic Habits* is about soldiers who got addicted to heroin and drugs during the [Vietnam War](https://en.wikipedia.org/wiki/Vietnam_War)
  - People were worried what would happen to them when they returned home
  - 90% or more of them were fine
    - Because they didn’t go back to the place where they got addicted
    - They went home to friends and family
    - They didn’t have all the same signals that were prompting them to pick up the habit so they were able to drop it more easily than was expected
- Compare this to the typical drug addict who does the reverse
  - The go into rehab and get clean in a place where they leave all their cues and influences behind
  - After detox, they go back to the place where they got addicted before
    - This is an uphill battle; it’s much harder

> “Environment… is kind of like the invisible hand that drives our behavior.” – James Clear

- The environment is a force and when one has limited capacity, limited time, is low on energy, the choice often made is the one most obvious in the environment
  - One chooses the thing that is the path of least resistance

**The best place to begin for changing behavior is either the 1st or 3rd law**

- Make it *obvious* (address the cue) or make it *easy* (address the response)
  - Scaling habits down makes it more likely one will be able to complete the task
  - Making it obvious means creating an **environment** where the good choices are out in front
  - Make the good choice easy, the path of least resistance
- Individually, one change to the environment does not usually meaningfully change behavior
  - But making a dozen, or 50 little changes to the environment will stack the odds in one’s favor
    - If healthy food is on the counter one is more likely to eat it
    - If the TV is in a cabinet behind a door, one is less likely to see it
    - If the TV remote is in a drawer and a book is in its place, one is more likely to read
  - When James wanted to start reading more he put the audible app for audio books on the home screen of his phone and moved all the other apps to the second screen
    - It’s a very small thing but it was a way to stack the odds in his favor of listening to an audio book for a few minutes when he opened his phone rather than browse Instagram
  - The more little changes to the environment one can make, the more likely good behaviors are to arise

**Control the environment and have an accountability partner**

- Peter remarks how important it is to control the environment when making a change
- Changes in nutrition are a great example
  - He  hasn’t met too many people whose eating habits improved after they had kids
  - For example, his kids love Wheat Thins
    - They can get away with eating more Wheat Thins than he can
    - The pantry is full of Wheat Thins; so everytime he looks in the pantry for something he has to resist the Wheat Thins
    - This is a struggle even for someone who is disciplined and high performing
- Similarly, for many people the number of cookies they can eat is either 0 or 30; there’s no middle ground
  - One hack James uses when his wife makes chocolate chip cookies is to only bake a few and freeze the rest as balls of dough to be baked later
    - This is a better experience because cookies are best fresh out of the oven
    - Also, having cookies in the frozen dough form provides just enough friction to lower the chance of eating more cookies than one intends in one sitting
      - It takes another 15 minutes (or more) to get the dough out and bake it
      - James will bake 2 cookies and be satisfied eating these and not over eat
      - He controls the environment by only baking 2 cookies
  - His wife also provides accountability
    - James could bake 5 cookies, but his wife knows his goal and will call him out if he over-indulges
- Having a workout partner is another example of accountability
  - James goes to the gym after work with his wife
  - On some days he just doesn’t feel like it but when she says  “All right, are we going to go to the gym?” he changes his mind and goes to the gym
  - This is helpful for long term consistency
  - One has to be careful because it can go the other way if the partner agrees to skip the goal
  - Having a partner in change can create a spiral of momentum
    - This can help maintain progress toward the goal, when one person wants to slack off but the other person encourages the goal
    - But it can also go the other way if both people slack off one day, then it becomes easier to slack off the next day too

## Self-forgiveness and getting back on track immediately after slipping up [1:30:30]

- Peter has noticed in his patients (and himself) that the people who are more self-forgiving when they slip up and get back on course have an easier time than people who are very perfectionistic
  - Getting into a cycle of self judgement can lead to complete loss of behaviors in line with the goal for the rest of the day
  - The rational is, “I’ve already screwed this day up so I’m going to do whatever I want”
- Back to the nutrition example, one blown meal often turns to over-indulging for the rest of the day
  - Now the person feels horrible both physically and emotionally
  - This reduces one’s drive to continue to do what one set out to do
- James notes in his book, if you’re going to miss a workout, miss 1 but don’t miss 2
  - The spiral effect is real, don’t encourage momentum in the direction away from the goal
  - It’s rarely the first mistake that causes ruin
    - The real problem is the spiral of repeated mistakes that follows
- This is something that many professionals know; for example, [Nick Saban’s](https://en.wikipedia.org/wiki/Nick_Saban) football team at [Alabama](https://en.wikipedia.org/wiki/University_of_Alabama#Football), if they have a bad play the focus is on the next play
  - They don’t let one mistake become another mistake
  - Teams and athletes that are good at having a short memory for mistakes and getting right back on track have really successful careers
- [Gretchen Rubin](https://en.wikipedia.org/wiki/Gretchen_Rubin) had the clever idea to divide the day into 4 quarters (morning, afternoon, dinner, and night)
  - When one makes a mistake, keep it contained to that quarter; don’t lose the day, just lose the quarter
  - Get back on track in the next quarter
  - Keep failures small to contain the damage and make it easier to get back on track  quickly to maintain momentum and build consistency toward the goal
- Self judgement and feelings of guilt never make things better or any easier
  - Bad can happen, but don’t start identifying as someone worthy of these bad things
  - One is better off cutting the judgement and guilt out of the story and just accepting the event for what its is and moving on
- Peter notes that [mindfulness meditation](https://en.wikipedia.org/wiki/Mindfulness) is a tool that can help
  - Observe the judgement without judging it
  - It sounds odd but is very powerful
  - Peter relates a personal example, Monday he and the family were out traveling the whole day; when he got  home he really wanted to work out (he hates missing a workout) but everyone was exhausted from the day
    - He didn’t feel right going to work out and leaving  his wife with the kids and a bunch of stuff that needed to be unpacked
    - Part of the judgement was letting go of the fact that he wasn’t going to work out that day, and that was okay
  - This can be applied to any situation; stay flexible and recognize things for what they are, realize it’s only one day and it’s okay
    - For example, if stuck in the airport with crappy food, it’s okay, it’s just one day and it doesn’t make one horrible for eating crappy food
    - Acknowledgement is helpful
- Getting ‘back on the horse’ as quickly as possible is really powerful
  - Consider the example of car racing, it’s rare to make a mistake and crash a car because of what one did at that moment and not because of  what happened earlier
    - A spin at corner 4 usually resulted from a mistake that happened at corner 2
    - Sometimes it’s hard to realize this
    - It’s a humbling experience how mistakes compound

> “Rapid course correction is probably a deeply applicable lesson for many areas of life” – James Clear

**The importance of perspective**

- Live is dynamic, not static and preferences will evolve
  - What is optimized for today is different that it was 10 years ago and will probably be different in 5 years from now
  - A good strategy is to keep in mind the ultimate goal, and then correct as needed
- *ABZ is a good framework*; it came from the entrepreneur [Shaan Puri](https://www.shaanpuri.com/)
  - One needs to know their ABZ’s
    - A is where one is in the moment, right now
      - What’s the truth of the situation; what is the current reality?
      - What skills, strengths, weaknesses does one have?
    - B is the next step
    - Z is where one wants to go in the end
  - One doesn’t need to know C through Y right now
    - It doesn’t have to be all planned out
    - Just make sure the next step is directionally correct
    - Keep running the ABZ process over and over until one arrives at their goal
- [Annie Duke](https://en.wikipedia.org/wiki/Annie_Duke) talks about this slightly differently; she refers to it as *back casting*
  - Instead of saying “no, this is where I am, that’s the desired outcome”, work the steps backward
  - Take stock of where one is in the moment, where one wants to go, and not thinking too hard to predict every step going forward
  - James adds the question to this process “What would the magical outcome be?” to focus on the ideal scenario
    - Then work backwards from this
    - Some people have trouble with the brainstorming part of the process because they think if it’s unrealistic, why even try…the point is, it’s too early for this

> “Most people become their own bottleneck long before reality prevents them from doing it” – James Clear

- Work backwards from the magical outcome
  - This happens one step at a time
  - This is a powerful tool
- Have a clear vision but be flexible about how to get there
  - There can be lots of ways to get to a goal
- Don’t become a hostage to things working out in one exact way
- Take advantage of opportunities as they arise

## Law #1: Make it obvious—Strategies for identifying and creating cues to make and break habits [1:39:45]

> “One of the great myths… is [that] behavior change is hard.” – James Clear

**Self-awareness**

- To be more in control of behavior, it always starts with self-awareness
  - What are the habits?
  - What are the cues?
    - Be as detailed as possible
  - Don’t judge yourself
  - Just notice how one’s time is spent
- Ask who, what, when, where, why
  - For example, someone realizes they eat a lot of candy bars but they don’t know what the cue is
    - Use one’s phone to make a note, the next time one eats a candy bar
    - Note: what time it is; where, what’s the location; what’s the context; who else is around; what was going on just before this?
  - The more one starts to answer these questions about context, the better they will start to understand the cue
    - Begin with one habit at a time
    - Go through this exercise for 5-7 days to develop a good sense for what is prompting the behavior
- What’s the risk that the [Hawthorne effect](https://en.wikipedia.org/wiki/Hawthorne_effect) will kick in and one will start deviating from natural behavior because they’re making the observation?
  - This is possible, but one needs to see what’s going on to learn what the cue is
  - It can be hard to honestly observe one’s own behavior
    - Realize there are lots of biases and stories one tells themself for why one does what they do
    - Be honest with yourself
  - One might find themselves changing their behavior just by tracking the behavior
    - This has been shown with food journaling
    - People tracking what they eat, even when they’re not trying to change, end up making healthier choices
  - Sometimes the mere act of observing something or measuring something often changes the behavior associated with it
- Peter relates this to [continuous glucose monitors](https://en.wikipedia.org/wiki/Continuous_glucose_monitor)
  - They’re a remarkable tool for both insight and learning
  - One realizes the response eating a particular food has on their glucose
  - Once one saturates the insight part of the equation; this can take 3 or 6 months depending, it becomes forever a behavioral tool
    - One won’t want to eat a certain thing if it’s going to raise one’s glucose
    - One buys this device because they buy into the thesis that having glucose levels skyrocket is unhealthy
    - The device becomes an accountability partner
  - Wearables can offer an insight that’s not obvious but is objective
    - Another example is a [pedometer](https://en.wikipedia.org/wiki/Pedometer)
      - Once one has spent enough time walking 10,000 steps a day, they don’t really need a device to tell them that anymore
      - It becomes easier to do this on their own

> “I have this theory about technology and innovation and that the technologies that most radically change the world or change our behavior are all just different forms of vision” – James Clear

- X-rays are an obvious example; they allow one to see a broken bone
  - This allows one to see tissue in a  way they could not before
  - It gives more information that once can act on
- Another example is the number of new email subscribers at his website each day
  - Tracking this allows him to change the form and conversation and so on
- There is a deeper lesson about behavior change and what drives human behavior, visualizing progress is helpful
  - Simple strategies like a habit tracker where one puts an X on the calendar each day seem very basic but it can be meaningful because it provides a visualization of progress

> “This idea of what gets measured, gets managed is a great tool” – Peter Attia

- Peter finds this true in his life, about 6 months ago he began monitoring the water use at his house
  - He would read the water meter every Tuesday and record it in a spreadsheet and note how many gallons were used that week
  - He would then project for monthly usage, etc.
  - It’s unbelievable how much his water usage has come down in 6 months
  - In Texas, water is not expensive compared to California, but it’s just something he became obsessed with
    - He doesn’t want to waste any water
    - It became a game; it drives his family nuts, but he wants to have the lowest water vill ever in Austin

> “It’s like an adult version of eye spy. You walk in and you’re like, I spy the red thing and then all the red stuff in the room lights up.” – James Clear

- The act of observing a habit and its cues make it more apparent

## Law #2: Make it attractive—examples of ways to make a new behavior more attractive [1:47:45]

**Make it attractive**

- Maybe running is a new habit one wants to start
  - One sets their alarm for 6 AM, but when 6AM rolls around, the bed is warm and it’s cold outside
  - But, if one doesn’t get up and go for a run, they’ll feel like a jerk for leaving their friend in the park all alone
    - Meeting a friend has made it more attractive to go for that 6 AM run and less attractive to sleep in
    - It didn’t make the run easier but it changed the calculus going on in the mind about whether or not one should get up and do it
- Find *short-term solutions* to make a habit attractive
- In the *long-term*, it’s about the social environment, being part of a tribe that has the desired behaviors as their normal behavior
  - This makes these behaviors more attractive because when one adopts them, they help signal membership in the tribe
- [CrossFit](https://en.wikipedia.org/wiki/CrossFit) is a great example
  - It creates a community of people who have a certain belief about who they are and what they do
  - Peter has seen it turn very inactive people into very fit, impressive people

> “I think the social side, the community side of it, is the strongest piece of the whole thing” – James Clear

- Peter read [Richard Thaler’s](https://en.wikipedia.org/wiki/Richard_Thaler) book [Nudge](https://www.amazon.com/Nudge-Improving-Decisions-Health-Happiness/dp/0300122233/ref=sr_1_3?dchild=1&keywords=richard+thaler+nudge&qid=1634310911&s=books&sr=1-3) about 10 years ago
  - This book explains how thoughtful “choice architecture” can be created to promote good decisions
  - It seems so obvious; this makes it so interesting and insightful
  - Sometimes the most brilliant things in retrospect seems so entirely obvious
  - Reading this brought up the idea of food environment
    - Peter tells his patients, the more they can control their default food environment, the more healthy they can be
    - A bad food environment requires a lot of willpower, and that’s really hard
  - Nudging refers to a cue and also an environmental change
    - It doesn’t seem to capture the idea of making it attractive
- James relates this to the first law, make it obvious
  - Design the environment to make the good habit the obvious habit, the path of least resistance
- Another example of Nudges are default choices on forms
  - A default opt-in for every employee to a 401K (and requiring them to opt-out) is a nudge
  - This also makes it obvious
  - Nothing is easier than inaction

**Priorities**

- [Darya Rose](https://summertomato.com/about/darya/), who writes a [nutrition blog](https://summertomato.com/foodist/), has a great concept about home court habits and away court habits
  - Optimize one’s *home court habits* first
  - What’s the environment in one’s kitchen?  Set the tone here.
  - Don’t worry so much about what happens out traveling or at a restaurant as much as at home
  - Optimizing the home court allows one to build momentum and handle what they doing 70% of the time
    - After the home court is optimized, then move to the away court stuff

**Accountability partners**

- Accountability partners can be a great help in establishing a new habit
- The type of partner matters
  - One has a stronger connection to a spouse or friend
    - One doesn’t want to let their partner or friend down
    - There are also complexities here because one forgiving of someone they see all the time; there can be a lot going on in these relationships
      - Really tight or complex relationships may not be the best at promoting strict accountability
  - Accountability to a stranger can fall apart more easily because they’re opinion is not valued as much
    - Going back to the example of mowing one’s lawn, one cares deeply about this because they don’t want to have friction with their neighbors or be seen as sloppy, etc.
  - A coach is good because they want to see their client do a good job
    - One is going to see them repeatedly
    - One is paying for the coach; the more it costs, the more willing one is likely to follow through on that accountability
    - At a high level of an Olympic athlete, there is a tight relationship between an athlete and their coach
      - James got to see this when he was into Olympic weightlifting
        - He was average but he trained with a really great team
        - [Holley Mangold](https://en.wikipedia.org/wiki/Holley_Mangold) was on the team, she competed in the [2012 Olympics](https://en.wikipedia.org/wiki/United_States_at_the_2012_Summer_Olympics#Weightlifting) in London
        - He got to see the interactions between the coaches and her and what it took to make it to the Olympics

## Law #3: Make it easy—the 2-minute rule [1:58:45]

**Laws #1 and #3 are the most important to address for getting started**

- #1 is make it obvious
- #3 is make it easy

> “Take whatever habit you’re trying to build and scale it down to something that takes two minutes or less to do” – James Clear

- Examples:
  - If the goal is to read 30 books a year, scale this down to read one page
  - If the goal is to do yoga 4 days a week, this becomes take out the yoga mat
    - People don’t like this, they see it as a trick and don’t think they’ll fall for it
- One of Jame’s readers, Mitch lost a ton of weight, maybe over 100 lbs. and kept it off for a long time
  - He had an interesting rule for himself: when he first started going to the gym, for the first 6 weeks, he wouldn’t allow himself to stay longer than 5 minutes
  - It sounds silly, but what he did is master the art of showing up
    - He became the type of person that went to the gym 4 days a week

> “Something that we often overlook, which is a habit must be established before it can be improved” – James Clear

- A habit has to become standard before it can be optimized or improved or scaled-up
  - One could have the perfect plan, but unless it is acted upon, it doesn’t do any good
- People often fall into the all or nothing trap with habits
  - The thought is, “Well, if I can’t do the full marathon training program, then why go for a run at all?” Or, “If I can’t follow through on the perfect lean startup business framework, then why bother starting a company?”
- The 2-minute rule helps get over this tendency toward perfectionism and just start mastering the art of showing up
  - Find a small way to establish the habit and make it part of the new normal
  - Later, the habit can be scaled-up
- Retired boxer [Ed Latimore](https://en.wikipedia.org/wiki/Ed_Latimore) has a great quote, “*The heaviest weight at the gym is the front door*”
  - This is true for a lot of things in life; the hardest part is getting started

![](https://peterattiamd.com/wp-content/uploads/2021/11/ed-latimore-twitter-jamesclear-1024x277.png)

**Figure 4. Words of wisdom from a former boxer.** Image credit: [Twitter](https://twitter.com/edlatimore/status/1104199631985147905?lang=en)

**Master getting started and make it part of one’s lifestyle**

- When one is the kind of person who shows up consistently, then there are lots of options for how to improve
- Another example where the 2-minute rule really helps is adopting the habit of meditation
  - Meditating for the first time can be daunting
  - One might think “I’d be better served to go on a silent retreat for seven days or meditate 40 minutes every day”
    - But that’s a really big step for someone who has never meditated
    - Why not begin with 2 minutes of meditation every single day for a few weeks
    - Lay down the track to say “I’m a person who meditates” first
  - There are a whole host of other behaviors that go with simply meditating for 2 minutes each day, lots of questions such as:
    - Where is it going to happen?
    - What time of day is it going to occur?
    - Is this something that you’re going to do before work after work?
    - Will one do it on their lunch break?
    - Will one try to do it with somebody to provide a little bit of social accountability?
    - Is this a private thing that one is going to do in the corner?
    - Does one need a pillow to sit on or will one sit on the floor?
    - Are the kids going to interrupt?
  - Finding a very small version of the habit allows one to figure out all these questions, figure out the logistics and simply do it for a minute or two
    - Once all this stuff is handled and there are no more decisions to make, this frees up a little more mental capacity and energy to focus on the habit and scale it up a bit closer to the original goal

## Law #4: Make it satisfying—rewards and reinforcement [2:03:30]

**Make the habit pleasurable enough that one will want to return to it**

- Give an emotional signal that the habit is worth it
- Short-term reward, this is about reinforcement
  - Plan a reward: a bubble bath, ice cream, buying something
  - Make sure the reinforcement aligns with the long-term identity one is trying to build
    - For example, ice cream wouldn’t be a great reward for getting in better shape
    - Going to the gym and working out then eating a bowl of ice cream is like casting boats for 2 different identities
    - Another example of a mis-match is well rewarding a good budget and saving for retirement with buying a leather jacket
  - Align the reward with the goal
- For example, if one saved consistently for a month, they reward themselves with a special hike
- Just doing the work in the moment toward the habit is also satisfying

## Advice for helping others to make behavioral changes [2:06:00]

- There is some bias in who picks up Jame’s book *Atomic Habits*; this person has decided they want to examine their habits and potentially change them
  - James agrees that sometimes he’s only helping people who want to be helped
  - Often, the people who most need to read the book are not the people who do
  - People who read about habits are usually ones with fairly decent habits and an interest in this
- This is different from a doctor trying to help their patient with either easy or difficult changes
  - Some interventions are easy; on a simple level offering a pill to address blood pressure or cholesterol is simple
    - There is 60-70% compliance in patients taking a pill
  - Addressing sleep habits, nutrition, exercise, or mental health is more difficult
    - These require enormous change

> “Changing your own behavior is hard enough, changing other people’s behavior is a whole nother level of difficulty, a whole nother order of magnitude of difficulty” – James Clear

**How to help patients develop a new behavior**

- 1) Begin small, scale down the expectation, make it super simple just to get the patient started
  - Work on one thing at a time
  - Once this is established with consistency then use that momentum  to transfer it to the next thing
  - Trying to keep it simple is a pretty obvious answer, but also a useful one

- 2) Change the environment

- - Have the patient spend 1 afternoon changing the environment in their home to align better with their goal

> “You only need little pockets of motivation and if you can direct that pocket of motivation toward a high leverage action, like redesigning the environment, then it can continue to serve even a lazy person for a good chunk of time.” – James Clear

- 3) Praise the good and ignore the bad

- - This may relate more to coaching
  - It’s easy to say, but hard to follow because it goes against the grain of the goal
    - There is a time and place for rectifying mistakes
    - Early on, it’s best to build momentum and reinforce good behavior
    - Think of the good plant crowding out the bad plant
  - A funny example from an op-ed about a wife whose husband would never throw his dirty clothes in the laundry hamper
    - She tried nagging him, annoying him, moving the hamper to a different place out in the open but he still wouldn’t do it
    - Sometimes he would throw  his clothes next to the hamper
    - Eventually she settled on making a huge deal about it, every time he put his clothes in the hamper
      - She would run over and give him a kiss or hug
      - She would thank him and say “Oh, you’re making my life so much easier. Thank you so much”
    - Over the course of a year, she trained him to always put his clothes in the hamper because every time that happened, something good happened; he got praised
      - Praise feels good
      - It was almost like training a dog
      - Everyone likes being rewarded
  - Praising the good actions and ignoring the bad is almost like a form of gravity
    - People naturally gravitate toward the things that they get rewarded for
  - People often do the opposite of this
    - Think of the kid who comes down with the rest of the family to dinner only to hear “oh, look who showed up”
    - Sarcastic remarks that punish the desired behaviors are counterproductive
  - The tricky part is, it requires a lot of patience
    - This strategy has to maintained for 6 months, 1 year, 3 years
    - It’s hard to stick with in the long run

**James’ next book**

- Is about strategy, choices, decision-making and how one directs their attention
- After he finished *Atomic Habits*, he knew how to build better habits, but the next question was, which habit to focus on?
  - What’s the highest leverage action?
  - How does one figure out where to direct their energy and attention?

§

## Selected Links / Related Material

**James Clear’s book**: [Atomic Habits: An Easy & Proven Way to Build Good Habits & Break Bad Ones](https://www.amazon.com/Atomic-Habits-Proven-Build-Break/dp/0735211299/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634054380&sr=1-1) by James Clear (2018) | [0:45, 13:45, 37:00, 56:45, 1:01:00, 1:23:15, 1:59:45, 2:15:00]

**James’ appearance on the Making Sense Podcast**: [#200 – CREATURES OF HABIT](https://samharris.org/subscriber-extras/200-creatures-habit/) [A Conversation with James Clear](https://samharris.org/subscriber-extras/200-creatures-habit/) | Making Sense Podcast hosted by Sam Harris ([samharris.org](https://samharris.org/podcast/making-sense-episodes/)) | [17:15]

**Books written by David Epstein**:

- [The Sports Gene: Inside the Science of Extraordinary Athletic Performance](https://www.amazon.com/Sports-Gene-Extraordinary-Athletic-Performance/dp/1591845114/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634062326&sr=1-1) by David Epstein (2013) | [21:15]
- [Range: Why Generalists Triumph in a Specialized World](https://www.amazon.com/Range-Generalists-Triumph-Specialized-World/dp/0735214484/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by David Epstein (2019) | [21:15]
- **Book that popularized the cue-routine-reward**: [The Power of Habit: Why We Do What We Do in Life and Business](https://www.amazon.com/Power-Habit-What-Life-Business/dp/1400069289/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634146746&sr=1-1) by Charles Duhigg (2012) | [1:02:45]

**Book by Lisa Feldman Barrett**: [How Emotions Are Made: The Secret Life of the Brain](https://www.amazon.com/How-Emotions-Are-Made-Secret/dp/0544133315/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1634147554&sr=1-1) by Lisa Feldman Barrett (2017) | [1:03:45]

**Commencement speech by David Foster Wallace**: [This Is Water: Some Thoughts, Delivered on a Significant Occasion, about Living a Compassionate Life](https://www.amazon.com/This-Water-Delivered-Significant-Compassionate/dp/0316068225/ref=sr_1_1?dchild=1&keywords=this+is+water&qid=1634221617&s=books&sr=1-1) by David Foster Wallace (2009) | [1:21:00]

**Book**: [Nudge: Improving Decisions About Health, Wealth, and Happiness](https://www.amazon.com/Nudge-Improving-Decisions-Health-Happiness/dp/0300122233/ref=sr_1_3?dchild=1&keywords=richard+thaler+nudge&qid=1634310911&s=books&sr=1-3) by Richard Thaler and Cass Sunstein (2008)

**James’ website**: [jamesclear.com](https://jamesclear.com/)

**Jame’s weekly newsletter**: [The 3-2-1 Newsletter](https://jamesclear.com/3-2-1) | James Clear

**James’ online course**: [The Habits Academy:](https://habitsacademy.com/) The Habits Academy is the premier training platform for individuals and organizations that are interested in building better habits in life and work | James Clear

§

## People Mentioned

- [Sam Harris](https://en.wikipedia.org/wiki/Sam_Harris) (host of the Making Sense Podcast) [17:00]
- [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) (legendary swimmer) [20:30, 22:45, 24:00, 25:15]
- [David Epstein](https://en.wikipedia.org/wiki/David_Epstein_(journalist)) (wrote the book The Sports Gene) [21:15]
- [Steffi Graf](https://en.wikipedia.org/wiki/Steffi_Graf) (legendary tennis player) [22:00, 25:15]
- [Maggie Rogers](https://en.wikipedia.org/wiki/Maggie_Rogers) (a musician) [26:30]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) (Formula One legend) [27:45]
- [Archilochus](https://en.wikipedia.org/wiki/Archilochus) (a Greek poet) [36:30]
- [B F Skinner](https://en.wikipedia.org/wiki/B._F._Skinner) (psychologist who developed the principle of reinforcement) [1:02:30]
- [Charles Duhigg](https://en.wikipedia.org/wiki/Charles_Duhigg) (author of the Power of Habit) [1:02:30]
- [Lisa Feldman Barrett](https://en.wikipedia.org/wiki/Lisa_Feldman_Barrett) (neuroscientist and author of *How Emotions are Made*) [1:03:30]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) (a writer) [1:21:00]
- [Nick Saban](https://en.wikipedia.org/wiki/Nick_Saban) (football coach) [1:32:15]
- [Gretchen Rubin](https://en.wikipedia.org/wiki/Gretchen_Rubin) (author of many [books](https://www.amazon.com/s?k=gretchen+rubin&i=stripbooks&ref=nb_sb_noss_1) on happiness) [1:32:45]
- [Shaan Puri](https://www.shaanpuri.com/) (came up with the ABZ framework) [1:36:45]
- [Annie Duke](https://en.wikipedia.org/wiki/Annie_Duke) (decision strategist, popularized back casting) [1:37:45]
- [Richard Thaler’s](https://en.wikipedia.org/wiki/Richard_Thaler) (behavioral economist and author of *Nudge*) [1:50:45]
- [Darya Rose](https://summertomato.com/about/darya/) (writes a [nutrition blog](https://summertomato.com/foodist/)) [1:52:30]
- [Holley Mangold](https://en.wikipedia.org/wiki/Holley_Mangold) (weightlifter James trained with in the past) [1:57:45]
- [Ed Latimore](https://en.wikipedia.org/wiki/Ed_Latimore) (writer, retired boxer) [2:01:30]

§