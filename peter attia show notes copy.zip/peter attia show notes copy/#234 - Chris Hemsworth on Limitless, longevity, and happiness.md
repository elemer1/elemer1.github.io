# #234 ‒ Chris Hemsworth on Limitless, longevity, and happiness

**Source:** [https://peterattiamd.com/chrishemsworth/](https://peterattiamd.com/chrishemsworth/)

---

Chris Hemsworth, best known for his role as Thor in the Marvel movies, joins Peter to discuss his recent work in the docuseries called [Limitless](https://www.disneyplus.com/series/limitless-with-chris-hemsworth/2wow8Otyubmk). In the docuseries, Chris undertook extreme challenges to explore his physical and emotional limits and gain insights into longevity. In this episode, Chris discusses these many challenges—from fasting to arctic swims to 100-foot rope climbs—as well as the insights that he gained from each. Peter, who also played a role in the docuseries, guides Chris through the science of longevity, including what Chris’s APOE-ε4 genotype means for his risk of Alzheimer’s disease. Additionally, Chris describes how his outlook on health, happiness, work-life balance, and more have changed from his experience on Limitless.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/chrishemsworth/the_Drive_public.png)

Play

#234 ‒ Chris Hemsworth on Limitless, longevity, and happiness

#234 ‒ Chris Hemsworth on Limitless, longevity, and happiness

1x15s30s

0:001:11:15

## We discuss:

- Limitless: how Chris got involved and his overall experience filming the docuseries [3:00];
- “Fasting” ‒ ep. 3 of Limitless in which Chris attempts a 4-day fast [8:15];
- “Shock” ‒ ep. 2 of Limitless in which Chris swims in the Arctic Ocean [12:15];
- Cold exposure: the potential physical and mental benefits [19:30];
- “Strength” ‒ ep. 4 of Limitless in which Chris explores how muscle can improve longevity [21:15];
- The APOE-ε4 genotype and Alzheimer’s disease risk [31:30];
- How Chris uses sauna [39:45];
- “Acceptance” – ep. 6 of Limitless in which Chris explores the meaning of life by contemplating death [42:15];
- Chris’s new perspective on work-life balance [52:00];
- “Stress-Proof” – ep. 1 of Limitless in which Chris learns about the impact of stress and how to manage it [54:30];
- Chris reflects on his intrinsic motivation driven by both fear and purpose [58:00];
- Chris reflects on his career arc and how his presence as an actor has evolved [1:01:15];
- How Chris’s outlook has changed since filming Limitless [1:05:00]; and
- More.

§

## Show Notes

## *Limitless:* how Chris got involved and his overall experience filming the docuseries [3:00]

**When was the first time you heard about this project, was it a call from Darren?**

- Yea, that was 3 years ago
- [Darren](https://en.wikipedia.org/wiki/Darren_Aronofsky) said he wanted to do a docuseries called [*Limitless*](https://disneyplusoriginals.disney.com/show/limitless-with-chris-hemsworth) on longevity
  - And he knew Chris was fit and healthy, and he wanted to dive into the science of longevity
  - He wanted to put Chris in some extreme/ intense physical and emotional situations and see how he fairs
- Initially it was supposed to be a 3-week shoot, but once COVID hit, it got spread out over 2.5 years
  - It transformed in the best way possible as a result of having this extra time to flesh out each episode and explore the science in greater detail
  - Chris was able to grow throughout the experience and have different opinions on himself and how he approaches health and wellness
  - They joked about the change in timeline and were thinking of changing the title to ‘Relentless’

*What else were you working on while filming Limitless?*

- He had done the [*Avengers*](https://en.wikipedia.org/wiki/The_Avengers_(2012_film)) at this point and was thinking about doing a press tour when this came up
- He hadn’t done [*Thor: Love and Thunder*](https://en.wikipedia.org/wiki/Thor:_Love_and_Thunder) yet

*Peter’s involvement in the project*

- November 2019, he was sitting in his apartment in New York with a core group from [Nutopia](https://en.wikipedia.org/wiki/Nutopia_(production_company)) and [Protozoa](https://en.wikipedia.org/wiki/Protozoa_Pictures) (Darren, Ruth, Mary)
- Peter remembers getting a call 3 years ago; the idea was 6 episodes
- It’s amazing how quickly they morphed that into the first shoot in January

**Did Chris have any apprehension about doing the Limitless series? (besides the time)**

- This was not acting
- Chris was nervous, he had never hosted anything before where he was “himself”
- This was a situation where it was not only looking into the science but dissecting his abilities and seeing what his limits were in one regard
  - There’s a vulnerability that’s required there
- He had to be authentic and didn’t want to hold back
- He had some hesitation and did a of thinking about how he was going to come across
  - Was it going to be genuine?
  - Was it going to be appreciated or not?
  - All sorts of silly doubts and questions started to creep in that he wasn’t normally thinking about

**How the docuseries evolved**

- Chris doesn’t think any of them knew what the show was going to be
- They talked about it taking 3-4 weeks
- When he spoke to Darren earlier in the week about this he said, “*Yeah, it was a very different beast at the beginning*”
- Due to the time they spent on it, it was allowed to evolve and become something bigger
- The challenges became bigger too
- There were discussions about cold water immersion and doing ice baths
  - Then it became “*Let’s go to Norway, and let’s swim in the Arctic Ocean*”

> “*It became more and more epic as it went on*”‒ Chris Hemsworth

**How the team evolved**

- Peter noticed there was a kind of joy in how close the team became, “*It’s like you seem to trust the team even more and more as time went on and gave more and more of yourself*”
- Everybody involved in had the expectation this was going to be bracketed in terms of time and COVID, but then it changed
  - The breadth of expectation of what this could be expanded the scope so much

**Do you get the sense that you were willing to give way more of yourself as this thing went on then maybe you had committed to upfront?**

- Absolutely
- Chris agrees, the trust in the people he was working with made a big difference
  - He knew these were the experts in their field
  - He knew they were taking care of him and advising him in the right way
- Chris reflects, “*It’s like working with a director and each of the experts in each of these series were kind of leading the way and they were at the helm, and I was following.  And if I have a good relationship with my director, and I trust them and that only comes through the experience and time spent, then I’m going to give more of myself and take more risks and not feel like it’s going to be exploited in any way.*”

## “Fasting” ‒ ep. 3 of Limitless in which Chris attempts a 4-day fast [8:15]

- This was the 1st episode of Limitless that they filmed

***What did Chris know going into this, and what was his expectation?***

- Chris had never fasted before
- The initial discussions were around [intermittent fasting](https://en.wikipedia.org/wiki/Intermittent_fasting) and time restricted feeding
- Then it became a day or a couple days, and then Peter said, “*No, we’re doing four days.*”
  - Peter points out he suggested 3 days because he wouldn’t normally have a patient go more than 3 days on their 1st fast
  - But they said, “*No, we’re going to do one more*”
- Chris’s thoughts were around if he would be able to do it or not
- He expected to kick into ketosis on day 2-3
- When he got to day 4 he was like, “*Nah, I’m not feeling any of the sharpness or alertness*”
  - But that afternoon when they went spear fishing, it kicked in and things started to percolate
- As they were getting ready to head out on the boat, Peter realized how strong Chris was
  - Because Chris didn’t have much time to prepare for the fast, and the circumstances weren’t ideal
  - They worked out every day and did a bunch of other things
  - They learned the entirely new skill of breath holding and spearfishing (that would be challenging under any circumstance)

**It’s been almost 3 years since they filmed this episode, how much do you remember?**

*Was there ever a moment when you thought, “I’m not worried that something’s going to happen to me, but I’m worried that I’m not going to be successful?”*

- That was most episodes
- As he was doing the Artic swim or 4-day fast or climbing the rope, Chris kept thinking “*Don’t complete this exercise*”
  - There was a healthy amount of fear motivating him
  - But he also kept coming back to the *why* of it and understanding the purpose of each challenge

> “*On one hand it looked like they were trying to kill me, but on the other hand it was like there was an incredible amount of information and knowledge and support and science there that says, “You do this. You do this consistently, you work this into your daily routine, then the benefits are exponential.”*”‒ Chris Hemsworth

## “Shock” ‒ ep. 2 of Limitless in which Chris swims in the Arctic Ocean [12:15]

- They filmed episode 2 in Norway, in February
- Chris had maybe 2 weeks off when they went from Australia to Norway
- Peter recalls, “*That was a beauty I couldn’t imagine*”
- It was a place you would normally never go
  - It took 3 flights (or something crazy) to get there
- Jumping in the ocean when it’s 36o F is a totally different experience than an ice bath
  - Peter notes, “*It was another example of you were being asked to do something much quicker than you would normally do so*”
- Chris was able to train for some of the episodes
  - For the strength episode, he spent 6-7 months training on and off (due to injuries and so on)
- To prepare for the cold water immersion he did a couple of ice baths back in Australia
- Talking to Ross about it, the overarching idea was to look at the development of [brown fat](https://en.wikipedia.org/wiki/Brown_adipose_tissue)
  - But Ross pointed out that not much was going to happen in 4 days
- So it became as much of an adaptation around cold water immersion as it was a resilience test
- The first time Chris jumped in the water in Norway he was in there for 4.5 minutes, and that was longer than any ice bath he had done
  - It was snowing
  - He’s breathing in freezing cold air, and it’s windy
  - He’s also moving (treading water); in an ice bath you just sitting there and a couple mL of water will start to heat up if you stay still
- For him it was trusting Ross and listening to Ross’s voice
- If he didn’t have Ross there coaching him through it, he would’ve questioned it to no end
  - On the actual swim itself, halfway through he was like, “*You’re dying, get out of the water. This is ridiculous.*”

**What does it feel like to swim in water this cold?**

- Peter has done long swims at 49o F, but he has never been in water that cold
- It feels like you’re on fire (which is hard to understand)
- You start to feel breathlessness, it takes your breath away
- It was one of the most painful things Chris has ever done
- It was very different from the ice bath
- The big thing was putting his head underwater

**Did you have earplugs?**

- No
- His training was treading water, all with his head above water

**Swimming in the Arctic Ocean**

- Ross proposed going for a proper swim, but Chris didn’t want to
  - Chris was saving it for the actual shoot
- But in hindsight, if he hadn’t experienced how painful it was, he would have been even more doubtful
- He warmed up as much as possible before he stripped down and dove in
- Ross suggested, “*When you get in, just take a second to try and adjust before you put your head under*”
- Chris didn’t know they were filming when he did the warm up and walked down to the edge
- He was in the water and huffing
- Ross didn’t even have time to jump onto the boat that was chasing us along
- Chris started swimming maybe 25, 30, 40 meters, and was like “*I got this*”
  - He decided to do 2 laps
- Once the initial adrenaline went away, he felt the most extreme headache pain right all through and to the back of his eyes, in front of his head, everywhere
- He was looking at the bottom as he was swimming, and he started to get really dizzy
- All of the sudden he stopped and realized he was going to throw up (it was that painful)
- He looks and realizes he had swum off course a bit; so he starts swimming to where a couple of the camera guys were
- They direct him to the buoy
- So he heads down again, but the whole time he’s thinking, “*Nah, get out. Get out, get out, get out.*”
- But he also has Ross’s voice in his head saying, “*Come on, fight, fight, dig in*,” so he just started going for it
- But what starts to happen is your arms and legs are just like lead balloons, nothing works
  - Peter adds, you can’t keep your fingers together, they start to splay; you can’t hold the water
- When Chris got to the buoy, they were all cheering and stuff and Darren said, “*Oh, I was waiting for a big celebration*”
  - But Chris couldn’t move; he thought he was going to die

> **“***I couldn’t move. I just thought I was going to die.*”‒ Chris Hemsworth

- They had to drag him onto the jet ski and then the boat
- He started to warm up with a blanket and beanie
- The feeling afterward was wild

> “*I’ve never felt the endorphin kick and the sort of elation that I felt afterward*”‒ Chris Hemsworth

- He remembers the most serene, peaceful state in awe of everything
  - A wonderful sense of calm and overwhelming sort of joy
- There in Norway, it’s the most stunning backdrop

***Chris thinks this feeling comes with any time you achieve something that you think is impossible or overcome some great challenge***

- There’s such a beautiful feeling
- It made him think about people who climb Everest and do extreme feats all the time, while the rest of us are wondering, “*Why the hell would you do that?*”
  - Chris explains, “*I believe it’s for that, that moment; that post feeling was pretty special. I’ll remember it for a long time*.”
- Peter thinks there is something to that, and it’s not just accomplishing the feat, “*It’s the temporal juxtaposition of being so low and so high*”
  - Think of how you don’t feel speed on an airplane, you feel acceleration
  - We’re only wired to feel the rate of change, and he thinks this is true of emotion
  - He doesn’t think you feel profound joy if you’re constantly in a state of bliss and everything is going well all the time
    - 4 minutes earlier, Chris was thinking he was going to die
    - So later there is this unbelievable surge of positive emotion
  - He thinks there’s a physiologic explanation for what Chris experienced
  - To go from your absolute lowest to your absolute highest in 4 minutes (with no negative, lasting injury); that’s the juice

![](https://peterattiamd.com/wp-content/uploads/2022/12/f1.-hemsworth.jpeg)

**Figure 1. Chris surfing in the Arctic Ocean.** Image credit: [National Geographic for Disney+/Craig Parry](https://geekdad.com/2022/11/chris-hemsworth-pushes-his-body-in-limitless-with-chris-hemsworth-on-disney/)

## Cold exposure: the potential physical and mental benefits [19:30]

- Peter thinks of all the things in *Limitless* (the strength stuff, endurance, mental challenges), the hardest one to make the case, scientifically, that it will make you live longer is to go and jump in the Arctic Ocean and swim
- However, says Peter, he thinks there’s a benefit to get used to cold water exposure
- Even on a busy morning like this morning, Peter spent 30 seconds to 1 minutes in a cold shower in the hotel
- He loves that feeling of the first time you get into the ice water
- There is really compelling evidence for what this does to brain chemistry (see studies listed in the selected links section at the end)
- Although in Chris’s swim, it was to a much higher degree than just taking a cold shower or an ice bath
- Peter thinks his brain was probably being flooded with endorphins and neurotransmitters that are very positive

**Are ice baths still part of your routine?**

- Oh, for sure
- It’s probably the endorphin kick, but also every time Chris gets in the ice bath, it’s still brutal
- The moment you get out, you’ve gone from one extreme to another, it’s an instant kick of happiness
- Chris says he thinks that from inflammation repair to general mood, it helps him
  - If he wakes in the morning and is feeling off or achy, jumping in the cold shower is a game changer

**Does Elsa join you? Do your kids join you?**

- Yea, they have a sauna and ice bath set up at home, and it’s the best rehab
- Elsa does it
- The kids will jump in, but not that long

> “*Single best investment I’ve ever made was the sauna and cold plunge at home*”‒ Peter Attia

## “Strength” ‒ ep. 4 of Limitless in which Chris explores how muscle can improve longevity [21:15]

- This is a great example of where COVID really benefited the series because the initial challenge for strength was kind of an interesting challenge, but the one Chris ultimately ended up doing was better
- Peter’s view on this from a scientific perspective, was what can we say about strength and longevity (or fitness and longevity)
  - [Grip strength](https://peterattiamd.com/avoiding-injury-part-ii-grip-strength/) and [cardiorespiratory fitness](https://peterattiamd.com/mikejoyner/) would be top of the list
- That’s why he thinks this was a perfect challenge because it’s grip strength and it’s top-end cardiorespiratory fitness
  - This challenge was an epic rope climb (100 feet)

![](https://peterattiamd.com/wp-content/uploads/2022/12/f2-hemsworth.jpeg)

**Figure 2.  Chris completing the rope climb challenge**.  Image credit: [National Geographic for Disney+/Craig Parry](https://geekdad.com/2022/11/chris-hemsworth-pushes-his-body-in-limitless-with-chris-hemsworth-on-disney/)

**Training for the challenge**

- Initially Chris was going to be in a harness and pulling a car across a section of land
  - Ross actually had done that for 20 hours or something crazy, and he was training Chris
  - Chris did a good month pulling a sled in the backyard
    - He had a little Polaris dune buggy thing he was pulling for a bit
    - But it just started to aggravate his back and joints and everything
- He then transitioned to the rope climb, and it was probably more on point as far as the science around strength and longevity
- As he started training for the rope climb, he’d never climbed a rope before
  - Ross had also done a feat like that, and so he was training Chris
  - Ross said, “*Look, you want to be strong, but you don’t want to be heavy. The heavier you are, the harder it is going to be to get up that rope*.”
- Chris had a 3 meter (10 feet) rope in his house
  - He would train by climbing 3/4ths the way up and jumping off and doing loops like that
  - One day he jumped down and blew out his ankle
    - He ruptured all the ligaments and tore ligaments

**Was there anything different that day?**

- He was in the gym set up in his house
- He was watching the UFC, and his mates were in the next room
- He was trying to get in 15 minutes and this was the last one
- He jumped off onto a mat and just rolled his ankle
  - It turned blue straight away
- Nutopia and the team from National Geographic were in Australia ready to shoot the next week so he had to call them and tell them it wasn’t going to happen
- That was the foot he was going to anchor off as he was pulling himself up

**Training for Thor and how it impacted his rope climb**

![](https://peterattiamd.com/wp-content/uploads/2022/12/f3.-love-and-thunder-691x1024.jpg)

**Figure 3.** ***Thor*** **theatrical release poster.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Thor:_Love_and_Thunder)

- Chris’s weight fluctuated throughout the Limitless filming
- He had been training quite intensely with Ross prior to filming and training for [Thor](https://en.wikipedia.org/wiki/Thor:_Love_and_Thunder) and learned some pretty unique, special things about how to just blast the body and do the most effective intense workouts, and when and what to eat and so on
  - He was schooled in that more so than he’d ever been before
- For his Thor role, he had an opportunity to get stronger and bigger than he ever was, but the timing of it didn’t line up with the rope climb challenge
- When Ross turned up, he hadn’t been using the rope at all because he’d been working on Thor
- They started doing it and Chris was so heavy that after getting in 3-4 pulls up, everything was tightening up on him
- So he had about 2 weeks where Chris just stopped lifting weights completely
- Chris adds, “*It’s funny, I don’t know if you’ve ever put on a big amount of muscle that it doesn’t take long for your body to go, “Okay, we can switch gears now.”*”
- He started a lot more rope pulls and sled pulls
- In 2.5 weeks of not lifting weights and reducing his calories dramatically he probably lost a couple of kg (4-5 lbs)
- But he was still heavier than he should have been for the rope climb

***This became less about his training/ preparation and more about grit and the will to just get up there***

- He remembers Ross being at the top of the cart going, “*Make it a fierce fight, make it a fight. Come on, big man*.”
  - That was in his head

**How long did it take, start to finish?**

- Probably a couple of minutes
- It was a long time to be climbing a rope
- There was a harness to catch him if he fell
- He was surprised that the quad burn was one of the most gnarly things
  - From doing the push and the anchor
  - Especially his right leg
- His biceps and forearms were also burning
- When he got off, he had claws; he couldn’t extend his fingers (they were locked)

**How do you feel physically now from a strength perspective in terms of how this has kind of morphed your training a little bit?**

- His training is more specific now
- When he was younger he could get away with going in and just starting to throw weights around (biceps, back, chest, and shoulders)
- Now he’s smart about warming up and not hitting everything too many times
- This came from working with Ross and his trainer [Luke Zocchi](https://zocobodypro.com/)
- He’s learned a more targeted approach
- Everything is about explosive energy lighting up your [sympathetic nervous system](https://en.wikipedia.org/wiki/Sympathetic_nervous_system)
- He’s gotten far more gains training like this

**Chris’s genetics around muscle fibers**

- He has a pretty favorable gene around [fast-twitch muscle fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types)
  - It’s sort of a genetic predisposition to be muscular, strong, and to be explosive
- Chris was lean when he was younger, but when he started doing more pushups or whatever, he would grow
- He adds, “*I’ve always had to work my ass off in that space.  But yeah, I do feel I’ve had some benefits there.*”
- One of the hallmarks of aging is the atrophy (shrinkage) of these fast-twitch muscle fibers
  - This is why people are losing strength and power and explosiveness most rapidly as they age much more than they’re losing endurance, slow-twitch fiber
- One of the things Peter always talks about with patients is, “*Hey, we need you lifting weights all the time. You start early, and you never stop lifting weights. And the heaviest you can lift is the better because it’s only through lifting heavy weights that you can really get those fast-twitch type II muscle fibers firing*.”
- So the fact that Chris kind of has a genetic predisposition to have more of them is a good thing

## The APOE-ε4 genotype and Alzheimer’s disease risk [31:30]

- One of Peter’s earliest memories of this whole experience was in Dec. 2019‒ Chris was in LA to get some blood work done
- To kick off the first bit of shooting, Peter was to sit down with Chris in January in Australia and go through his blood work
- Peter got the blood test back 2 weeks before he was supposed to go to Australia; he saw something that he didn’t want to go through with Chris for the first time on camera
  - It was too much
  - Peter could discuss all of the results except for this one thing; he asked Darren to trust him, and he did
- Darren called Chris in a panic and was like, “*You’ve got to call Peter Attia, something’s come up but I don’t know what it is*”
  - Chris was rattled
- Peter hasn’t had many patients with 2 copies of the [APOE-ε4 allele](https://en.wikipedia.org/wiki/Apolipoprotein_E#E4) (maybe 3)
  - Only about 1% of the population has this genotype
  - 2 of Peter’s patients suspected their genotype based on family history
  - For 1 patient, it was a total shocker
- Peter tells his patients, “*Look, this is a gene that really increases risk of Alzheimer’s disease but it’s not a deterministic gene*”
  - This is a hard concept to explain to somebody who doesn’t eat, sleep and breathe genetics
  - Which is, you have this gene and it doesn’t guarantee this thing is going to happen
  - And there are some genes that are deterministic, for example if you have the gene for [Huntington’s disease](https://en.wikipedia.org/wiki/Huntington%27s_disease), you’re going to get Huntington’s disease
  - This isn’t that kind of gene, but it’s increasing your odds, and that’s the bad news

***The good news is, the earlier you know this, the more you can do to mitigate risk***

**How much of this message did you hear back then?**

- Chris knew nothing about the science or the markers and so on, outside of that one conversation
- When he hung up the phone and was trying to explain it to his wife, he was like, “Y*eah, I’m not really sure what he just said, but I think I’m more vulnerable to Alzheimer’s*.”
- Chris wishes they’d had more conversations immediately after because he spent a week thinking, “*What does this mean? What’s going to happen, and how long have I got?*”
- He tried to talk to his parents about it, and they didn’t know much about it either
- His grandfather has Alzheimer’s and it’s been very tragic to watch
- This was a good kick in the ass and a reminder for Chris to do whatever’s within his control to give himself the best fighting chance
- And whatever work he’s doing for brain health benefits the rest of his body and life anyway, so he turned it into a positive

**When and why did you decide you wanted to be public with something so personal?**

- One of the interesting things about filming this is we did everything in duplicate for those episodes
- They talked about all this stuff and realized there was a good chance they were not going to want to talk about this particular aspect of Chris’s health publically
  - So they redid that whole thing without this
- For about 2 years, they didn’t know which version they were going to use
  - This was 100% Chris’s decision
- Chris replied, “*Well, the same reason it’s motivated me to make positive changes. I thought, “Well, that’s a great opportunity for anyone else out there who may be in the same situation to either go and get checked or to understand more about brain health and see what they have within their power to make that change.”*”

> “*It’s a missed opportunity to motivate others to do the same if I don’t talk about it*”‒ Chris Hemsworth

- When they put together the episode they didn’t overdramatize it or exploit anything
- They did a great job making it relatable, to show that Chris was a human being like anyone who has many of the same challenges and is up against the same things as all of use are

**More on the APOE-ε4 gene**

- 20-25% of the population has at least 1 copy of the APOE-ε4 [allele](https://en.wikipedia.org/wiki/Allele)
- Having 2 copies of the APOE-ε4 allele is a very rare combination
- Having 1 copy doesn’t increase the risk of Alzheimer’s as much having 2 copies
- But the 20-25% of the population that has 1 copy of this allele, they make up about ⅔ of cases of Alzheimer’s disease
- On Chris’s decision to share these results, Peter says, “*I applaud you for doing it, and I’m really glad you did decide to do this because I’ve always said I really wish every single person would know their APOE genotype early in life*.”
- There is a lot of resistance in the medical community to this
  - Many physicians say, “*Look, no one should know that. There’s nothing that can be done about it. Why would you burden somebody with that knowledge?*”
  - But people like Peter, [Richard Isaacson](https://vivo.weill.cornell.edu/display/cwid-rii9004), and [Kellyann Niotis](https://news.lafayette.edu/2021/04/15/biology-success-story-kellyann-niotis-12/) fundamentally disagree

> “*We think that this is absolutely a condition through which you have an enormous lever arm to mitigate risk*”‒ Peter Attia

- Peter thinks not knowing that information early is criminal
- Chris adds that whatever he does to protect himself and have the best chance, it benefits everything else anyway
- They talked about reducing stress levels and more mindfulness practices

***There’s certain training I do, nutrition, my sleep habits, all those things made a dramatic difference in every other part of my life too***‒ Chris Hemsworth

## How Chris uses sauna [39:45]

- Before they shot the series in Norway, Chris talked about how much of a fan of sauna he was, then they got into the science of why
- It hasn’t been proven to the same extent as some things because much of the data is observational
- But the data is overwhelmingly positive in the same direction with every single study

**Has sauna taken on a more urgent role?**

- Yeah, definitely; it’s become a bigger part of Chris’s daily routine
- He often uses it after a workout
- He doesn’t know what the science says, but he feels great after doing it
  - It helps with mood elevation
  - The same with an ice bath
- Peter agrees, even if the benefit of [heat shock proteins](https://en.wikipedia.org/wiki/Heat_shock_protein) is less than we think
- Peter notices benefits for his sleep when he uses the sauna
- For Chris, when he’s been training a lot and wakes up achy he will get in the sauna in the morning and do an ice bath, and he feels 50% better
  - “*I feel like everything’s just kind of lit up and awakens*”

## “Acceptance” – ep. 6 of Limitless in which Chris explores the meaning of life by contemplating death [42:15]

- When Peter thinks about he last episode, this one more than any other reaped the benefit of COVID because they had much more time to flesh it out
  - The initial version was kind of gimmicky

**Did you have much of a hand in the creative side of that or were you just a passenger?**

- Chris was a passenger
- He was kept in the dark intentionally; Darren didn’t want him to know much about it
- It was an immersive theater experience, and Chris is glad he didn’t know because he feels like he would’ve had preconceived ideas and expectations
  - This would have biased his reaction
  - So to go into it blind and just open and ready for whatever they were going to throw at him was exciting and different from the other episodes
  - There was no prep or understanding of the science prior to shooting
- All he knew was it was about the acceptance of death

**What did that “aging suit” feel like?**

![](https://peterattiamd.com/wp-content/uploads/2022/12/f4-hemsworth.jpeg)

**Figure 4. Chris plays ping pong in the aging suit.** Image credit: [National Geographic for Disney+/Craig Parry](https://geekdad.com/2022/11/chris-hemsworth-pushes-his-body-in-limitless-with-chris-hemsworth-on-disney/)

- Uncomfortable, incredibly restrictive
- Because he couldn’t hear properly, and people spoke to him with a condescending/ patronizing tone
  - How you often hear people talk to the elderly
  - Chris thought, “*Oh, my god, I hope I don’t do that*”
- It was incredibly isolating too
- His vision was diminished, he couldn’t hear so everything felt pulled away
- The contrast between having all of his abilities the hour before he put the suit on, and not having 50 years to transition into that was extreme

> “*There are so many things about that episode that are beyond beautiful*”‒ Peter Attia

- One of the subtle things Peter liked about that episode was that all of the residents of that place were not actors
- The episode was slightly over an hour, but Peter assumes it was shot over several days
  - So they had a lot of time on the set
  - A lot of the folks didn’t know who he was prior to this

**What was it like, interacting with the people in this episode?**

- It was unique and different on so many levels
- Being in a retirement village with elderly folks who were there for the fun of the episode, but were just genuine and truthful and honest and didn’t hold back with anything they were thinking (no filter)
  - It was great; it was refreshing
- It was different from being in an industry where a lot of people know who you are and a lot of the time you’re sort of supported in what you’re doing and everything’s made as accommodating as possible
- This was like, “*No, you’re one of us now*”

> “*It was fantastic, sort of brought me straight back to earth if I’d drifted previously*”‒ Chris Hemsworth

- Peter has known Chris for many years, and he’s pretty down to earth
- That episode was different because there was no superhero component to it
- Chris was a lot more nervous about that episode than anything else because it wasn’t something he could fight or muscle through or just put my head down, drip my teeth and go for it
  - He had to be completely open and vulnerable and accessible and confront things that he had never really thought about that much
  - He had to interact with people who were at the end of their days
    - Or who had dealt with death in very extreme ways
    - Or come close to death
- To go from one environment of physical sort of challenge and feats and then go into this emotional state was a real shock and an adjustment
- Chris is proud of what the episode became because it’s unlike anything he’s ever done or seen

**BJ Miller’s story** [48:30]

- Peter is guessing Chris didn’t know [BJ MIller’s story](https://peterattiamd.com/bjmiller/) before that episode
  - See [episode #125](https://peterattiamd.com/bjmiller/) of The Drive with BJ Miller
- No, he didn’t

**You heard this story for the first time on camera, what did it feel like?**

*What was more emotional, the tragedy of the story or how you were moved by his resilience and how he overcame it to do what he’s doing?*

- It’s a combination of things
- He is one of the most unique individuals Chris has ever met
- There is something saintly and otherworldly about him
- His story shook Chris
- Also the strength now with which he reflects upon it and his attitude toward what happened to him was so inspiring.
- Chris was really exhausted coming into that episode
  - It felt like he was at the end of a five year run of different films and work and he was shooting this series throughout
- He was more vulnerable than he’d been in a long time,
- There were a lot of the questions that were starting to circulate through his head‒
  - Am I proud of what I’ve done?
  - What’s next?
- Chris adds, “*All I kept thinking was I have been sprinting through life and the moments and opportunities and I’m grateful for them, but I’ve been very quickly going to the next one, to the next one, next one.  And I was in a bit of a state of what’s next and what’s the point and who am I?*”
- He hadn’t been able to analyze these questions, but they were there in the back of his head
- His mom had said something a few days before that she’d had this experience where she came pretty close to what she thought was going to be her death (in a very instant sort of moment)
  - She’s fine now, but she said, “*Oh, I wasn’t at all afraid to go because I realized I’m so thankful for my life and I’m so happy about everything I’ve had and all the experiences*”
  - Chris thought, “*Well, what a beautiful feeling*”
- And in that moment, when he was talking to BJ about it, he got really emotional because he realized that he’s “not ready yet”
  - “*I have all these beautiful things around me and family and friends, but I can’t go yet. This is not my time.*”

**Considering your own death**

- It was strange because they were manipulating everything in that space to make him feel like he’s going to die, and he’s asked to think about his death, how he would want it to be and so on

***But I had this sort of sense of urgency of just‒ I’m not ready***

- This made him think about his kids and how they’re growing up and things are changing so dramatically

> “*It made me think about my kids and how they’re growing up and things are changing so dramatically, and I want to sit, I want to soak it in. I don’t want to be in a sprint anymore. I want to be more present. I want to be right here and appreciate everything that’s in front of me.*”‒ Chris Hemsworth

- He’s tried to articulate that a few times and he doesn’t know if he’s hit the nail on the head
  - This exactly why something in him felt so fragile at that point
- That whole experience shook him to his core and made him want to slow down and just race home to his family and kids
  - And not jump on another plane and travel and work and do anything else

**Natalie’s story**

- Peter thinks about the time Chris was sitting on the bench next to Natalie was equally profound

**You weren’t aware of Natalie’s story.  Were you wondering why they were having you talk to a normal looking, healthy 27-year -old woman?**

- Yeah, definitely
- What she said, there was an urgency from her to shake people and say, “*Wake up. It doesn’t last forever. The end could come at any moment, so make the most of it, and love and laugh and live with a sense of gratitude and joy.*”
- That was incredibly inspiring
- It was heartbreaking hearing what she’s been facing at such a young age
- Chris is really thankful that he had those conversations
- He was forced to have this realization now, not when he’s 80
  - He’s so glad he’s not sitting on his deathbed going, “*Damn, I should have done this. I could have done this. If only I’d done that.*”
- He felt like this was an awakening or a sort of shake up
  - It came at the perfect time

## Chris’s new perspective on work-life balance [52:00]

**You haven’t had more than 2 months off in the last 10 years, right?**

- Yeah, pretty much
- During COVID and even now he’s still working on prepping things

**What Chris’s daughter said when he jokingly suggested to her that he might retire**

- Chris has worked so hard, and been so successful

- With that success has come so many wonderful things‒ wealth, fame, a platform

- Peter adds, “*More people are going to know what the APOE4 gene is and why they need to be tested and what they can do about it because of this episode… than would’ve ever come out of the scientific literature ever*”
  - This is all attributed to Chris’s platform
- So there’s all of these amazing things both to Chris personally and to society at large that come from this
- But at the same time, that’s not sustainable
- Everytime Chris leaves for a work trip, he tells his kids, “*It’s not long. Soon, I’m going to take some downtime.*”
- His daughter sort of rolls her eyes at this and says, “*Yeah, sure*”
- He told her, “*Look, when I’m done with this tour, I’m having a big chunk of time at home.*”
  - She goes, “*Oh, great, awesome. It’d be fun then.*”
- He replied, “*Yeah, and maybe I’ll just retire. Maybe this is it. Maybe I’ll stay home with you forever now.*”
  - She’s like, “*No, Dad, you can’t… Kids love seeing you play Thor.*”
- This was a beautiful moment of understanding that maybe there is a purpose to it
- For Chris, he’s been chasing his career for a number of reasons
  - It’s been his journey
- There’s a sense of guilt that comes with chasing down your dreams all the time
  - When you have kids, it’s not about your dreams anymore, it’s about theirs
  - He has a family to take care of

***Chris was questioning what he’s contributed or done, and hearing his daughter say that was a beautiful little moment***

- He doesn’t want to retire for a number of reasons
- He certainly wants to replenish and fill up his cup again
- He feels like he’s been a flat stick for so long now
  - He’s loved it and is very thankful for it
  - But he needs a chunk of time at home to to get reinspired

## “Stress-Proof” – ep. 1 of Limitless in which Chris learns about the impact of stress and how to manage it [54:30]

***How is your sleep now compared to 3 years ago?***

- Chris has a restless mind, he would wake up a lot in the middle of the night
  - He’s have a thought and fixate on it
  - Sometimes it was a very rational thought like, “*I’m worried about the success of this film. I’m worried about my relationship with my wife. I’m worried about…*”
    - These are normal things to be concerned with
    - But they would wake him up and he wouldn’t be able to go back to sleep
  - Sometimes theory were things that seemed less rational, and all of us have those very irrational thoughts
    - Chris adds, “*It’s mostly irrational*”
- In general, he is sleeping better than he was back then
- He was just running in a state of fight or flight constantly, but that was required
- For him to leave Australia with not a whole lot of money in the bank and live on people’s couches and audition and audition
  - To go through that sort of grind and be told no a million times and still obsessively be pushing forward requires a huge amount of compulsive-obsessive, self-motivated drive
- The problem is you then start to achieve those things, and he’s no longer in the same sort of fight that he was, but he’s still acting like he is
  - His internal environment is still thinking it’s running away from the dinosaurs or whatever
- The more comfortable he gets, the more he rationally talks himself through, “*Hey, it’s all okay now. You can afford to do this and this and this and you don’t have to… You worry so much about it not working out.*”
- And some of that dissipates, but it’s there all the time
- He’d be lying if he said he had a complete handle on it
- He also doesn’t want to dismiss it too much because it’s what got him here
  - It’s a tool that he will still need to use at certain times
- So he’s monitoring that, and he hears a lot of people talk on that

***What is required to get to a certain place is a blessing and a curse.  It’s a hard thing to switch off once you’ve opened the gates.***

- Peter thinks this is a common thread for people who have achieved great success

## Chris reflects on his intrinsic motivation driven by both fear and purpose [58:00]

**When you think about your motivation, when you think about the love you have for your craft, is there a way to use excitement more than fear?**

- Peter recalls the story of Chris’s father when he told him that he wasn’t going to be paying off the mortgage anytime soon
  - Chris realized all that his parents had done for him and his brothers, and he wanted more for them
- So part of the fuel for Chris’s success was the desire to take care of his family
- But he also had a real passion for what he does
  - He’s an artist who enjoys making art
- Peter asks, “*Where’s the fire coming from? Is the fire coming from a place of fear? Is the fire coming from a place of love? I mean, do those go back and forth for you from time to time, in different seasons?*”
- Absolutely, yeah
- Chris used to get intense performance anxiety when he was first acting, and it was debilitating
  - He would go to auditions, and he’d want to throw up and would be shaking
- Even when he got jobs, he would be on a set and it was like he couldn’t think or see
  - He felt like he was going to pass out
- He was fighting that for years
- Talking about fear or excitement, Chris remembers reading something about tests with athletes, performers, musicians, actors, whatever (anyone in a sort of adrenaline fueled sort of space)
  - They asked them if they were nervous or excited before an event
  - Some of them said they were scared out of their minds
  - Some of them said they were pumped
  - The interesting thing is, they all had the same physical response‒ elevated heart, pulse, clammy hands, short of breath, etc.

***That was a real light bulb moment, and Chris thought “The only difference was how they labeled that feeling”***

- That’s when Chris realized he had programmed himself to say this feeling is bad
  - That fear is negative
- He decided to see it as a positive and realize, “*My spidey senses are up now. I’m going to be able to think faster, react quicker, see clearer. My vision will be sharp.*”

***It was all just a decision to see it differently***

- He thinks fear has a place, it pushes you
- Your purpose pulls you
- You need both of them to have an equal relevance in the conversation
  - “*It’s a bloody good motivator too*”

**Chris’s motivation during the challenges of** ***Limitless***

- In half of the challenges, Chris was afraid of looking ridiculous if he didn’t complete this task or the fact that the episode wouldn’t have worked
  - That fear kept him going
  - But also the sort of purpose of why he was doing it kept him going
- He thinks both fear and purpose deserve equal relevance in the conversation
  - It’s about balance
  - If you have too much of, “*Oh, my purpose and my thing*,” there can be a lack of humility
  - He feels fear has allowed him to have more of a self-deprecating sort of sense of humor about himself and the world and the work
    - Hopefully it keeps him humble

## Chris reflects on his career arc and how his presence as an actor has evolved [1:01:15]

**What was the first role you had where you allowed yourself to think, “*****I’m going to make it*****”?**

- In the first [*Thor* film](https://en.wikipedia.org/wiki/Thor_(film)) he thought, “*Great, I’m in the game*”
  - This was 2011
  - But he didn’t know if the film was going to work
  - He didn’t know if they were going to do an [Avengers film](https://en.wikipedia.org/wiki/The_Avengers_(2012_film))

**Was there something funny in the audition for** ***Thor*****?**

- Chris didn’t get a call back; he got some pretty bad feedback to the effect of, “*We’re not even going to give you any sort of constructive criticism or anything. It was just kind of minimal and nothing*”
- He was shooting a film in Vancouver and his little brother calls him to tell him they were flying him to LA for the film *Thor*
  - His brother Liam sent in an audition on tape
- They had 6 final guys for Thor, and Liam was one of them
  - [Joss Whedon](https://en.wikipedia.org/wiki/Joss_Whedon) and [Drew Goddard](https://en.wikipedia.org/wiki/Drew_Goddard) were with Liam, and they both said, “*What the hell’s going on here? Was this your brother… Why aren’t you in the mix? You should be Thor.*”
    - They worked with Chris on [*The Cabin in the Woods*](https://en.wikipedia.org/wiki/The_Cabin_in_the_Woods)
- So they reopened the casting and Chris got a chance to do an audition, he sent in a tape
- He was called back to meet with [Ken Branagh](https://en.wikipedia.org/wiki/Kenneth_Branagh) and do the audition
- Chris had a very different attitude about it
  - He didn’t put anyone on a pedestal like he did the first time
  - He was a little pissed off that his brother had gotten there and he hadn’t
    - It was good motivation
- It’s about perspective
- He was able to walk into that room and give the very best version of whatever he had to offer, as opposed to people pleasing and asking, “*Is this what you want? Or is it this way?*”
  - There’s a lack of strength with that other attitude
  - They needed a character to be assertive
  - He had a lot more presence in that space than he did the first time around (and he got the part)

**How long does an audition take?**

- Usually, you have a few days to learn it
- Sometimes they call you at lunchtime and want you to come in that afternoon and read it
- When you’re actually there in front of them, it depends on how well (or bad) it goes
  - It could be 5 minutes, 2 minutes, an hour
- Chris has had people answer the phone midway through his audition and be like, “*Yep, that’s great. Thank you very much. We’ll call you*.”
  - It’s brutal
  - You either become numb or it destroys you

**How’d you hear about** [***Rush***](https://en.wikipedia.org/wiki/Rush_(2013_film))**?**

- [Ron Howard](https://en.wikipedia.org/wiki/Ron_Howard) was making the film, Chris didn’t know anything about [Formula 1](https://en.wikipedia.org/wiki/Formula_One_racing)
- Chris’s agent called him and told him he should do an audition
- Ron Howard said, “*Oh, look, I’ve seen Thor. He’s great, but he’s not right for the character. He won’t fit in the Formula 1 car*”
  - Chris replied, “*Well, I’m not that size… I’m doing an audition.*”
- Chris watched an interview with [James Hunt](https://en.wikipedia.org/wiki/James_Hunt), and his hair was long enough that he could style it like his

**Had he already picked** [**Daniel**](https://en.wikipedia.org/wiki/Daniel_Br%C3%BChl) **for** [**Niki**](https://en.wikipedia.org/wiki/Niki_Lauda)**?**

- Chris thinks so
- Peter loves that film, “*If you were getting a dollar for every time that film got watched by me, you’d be even more wealthy*.”
- Chris hasn’t seen it since the premier
  - It’s hard to watch yourself

**So you don’t take your kids to** ***Thor*** **or they don’t watch it around the house?**

- He’ll watch it once or twice
- If he’s producing it, he’ll stick through it a bit more
- But it should be uncomfortable
  - Chris thinks there’s something narcissistic about enjoying it too much

## How Chris’s outlook has changed since filming *Limitless* [1:05:00]

**If we’re sitting here in 5 years and your life is better than it is today, what are you doing?**

- Peter is think of this in terms of the final episode of *Limitless*
  - Meaning that Chris is running less
  - The balance between purpose and fear is more in favor of purpose
  - He feels more connected to his kids and family
- There is another thing came up in the episode that Chris wants to clarify
- He doesn’t feel like he’s been doing anything wrong as much as he’s been in the storm of it
- He has a beautiful relationship with his kids, wife, and family
- He’ll be there with them, but his brain is pulled in a million other places

**Is it just about a state of mind?**

- It’s both (what he’s doing and his state of mind)
- In the episode Chris was asked to imagine what his death would look like
  - And if this was his final moment, who would he have around?
  - Where would he be?
- He realized, it’s in the living room with his family and friends
  - That’s where he is every other weekend

**Chris’s realization**

- It’s already right here in front of you, change your attitude
- He realized he wanted to do this even more now and he has an opportunity to do that because he’s not in the fight or the sprint anymore
- He wanted to be more curated with his choices
- He wanted to have more time pre and post the film to prepare and decompress as opposed to just piling one after the other

**Does that mean more directing, shifting the balance a little bit?**

- Chris thinks it’s who the directors are
  - Working with people that are at the top of their game
  - He’s been so lucky to have worked with some wonderful people (like [George Miller](https://en.wikipedia.org/wiki/George_Miller_(filmmaker)))
- To continue to work with individuals like that where he’s learning from them
  - It’s a collaboration, but they’re at the helm; they’re steering the ship
  - He doesn’t feel like he’s got to police anyone else there
- It is the dream, and then he’s inspired by those people, and he’s doing it for the right reasons
- He’s working from an artistic space and an expression, as opposed to a financial one

***He can be more curated in his choices and have more stillness and more calm***

**Reflections on what they learned working on** ***Limitless***

- Peter got involved with *Limitless* because Darren and him are such good friends; doing something fun like this with Darren was the motivation
- When he reflects on the last 3 years, one of the most unexpected joys has been meeting Chris and all the people around him
- To know that Chris is surrounded by amazing people like Ben, Aaron, Zach, his family, his parents, and brothers, Peter adds, “*You are rich, Chris. You are rich in people.*”

For Chris, the biggest joy is the people he’s met through this experience and ***the knowledge that friendship is the most important***

§

## Selected Links / Related Material

**Docuseries** ***Limitless***: [Limitless with Chris Hemsworth](https://disneyplusoriginals.disney.com/show/limitless-with-chris-hemsworth) | National Geographic on Disney+ (2022)

**Effects of cold exposure on brain chemistry**:

- [Autonomic nervous function during whole-body cold exposure before and after cold acclimation](https://pubmed.ncbi.nlm.nih.gov/18785356/) | *Aviation, Space, and Environmental Medicine* (TM Makinen 2008)
- [Improved mood following a single immersion in cold water](https://onlinelibrary.wiley.com/doi/full/10.1002/lim2.53) | *Lifestyle Medicine* (JS Kelly & Ellis Bird 2021)
- [Effect of Acute Cold Stress on Neuroethology in Mice and Establishment of Its Model](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9559653/) | *Animals* (Y Hu et al. 2022)

**Benefit of sauna and heat shock proteins**: [Cardiovascular and Other Health Benefits of Sauna Bathing: A Review of the Evidence](https://www.mayoclinicproceedings.org/article/S0025-6196(18)30275-1/fulltext#secsectitle0025) | *Mayo Clinic Proceedings* (JA Laukkanen et al. 2018)

**BJ Miller’s story**: [#135 – BJ Miller, M.D.: How understanding death leads to a better life](https://peterattiamd.com/bjmiller/) | Peter Attia (peterattiamd.com) [48:30]

§

## People Mentioned

- [Darren Aronofsky](https://en.wikipedia.org/wiki/Darren_Aronofsky) (American film director, producer, and screenwriter, directed [*Limitless with Chris Hemsworth*](https://disneyplusoriginals.disney.com/show/limitless-with-chris-hemsworth))
- [Luke Zocchi](https://zocobodypro.com/) (personal trainer and author, Chris’s trainer)
- [Richard Isaacson](https://vivo.weill.cornell.edu/display/cwid-rii9004) (Professor of  Neurology at Weill Cornell Medicine)
- [Kellyann Niotis](https://news.lafayette.edu/2021/04/15/biology-success-story-kellyann-niotis-12/) (preventative neurologist at Early Medical specializing in neurodegenerative disorders)
- [BJ Miller](https://en.wikipedia.org/wiki/BJ_Miller) (has a powerful near death story) [48:30]
- [Joss Whedon](https://en.wikipedia.org/wiki/Joss_Whedon) (American filmmaker and writer, co-wrote and produced [*The Cabin in the Woods*](https://en.wikipedia.org/wiki/The_Cabin_in_the_Woods))
- [Drew Goddard](https://en.wikipedia.org/wiki/Drew_Goddard) (American filmmaker, directed [*The Cabin in the Woods*](https://en.wikipedia.org/wiki/The_Cabin_in_the_Woods))
- [Ken Branagh](https://en.wikipedia.org/wiki/Kenneth_Branagh) (British actor and filmmaker, directed [*Thor*](https://en.wikipedia.org/wiki/Thor_(film)))
- [Ron Howard](https://en.wikipedia.org/wiki/Ron_Howard) (American director, producer, screenwriter, actor)
- [James Hunt](https://en.wikipedia.org/wiki/James_Hunt) (British race car driver who won the Formula 1 championship in 1976)
- [Daniel Brühl](https://en.wikipedia.org/wiki/Daniel_Br%C3%BChl) (Spanish-German actor and filmmaker, starred in [*Rush*](https://en.wikipedia.org/wiki/Rush_(2013_film)))
- [Niki Lauda](https://en.wikipedia.org/wiki/Niki_Lauda) (Australian Formula 1 driver who won the championship in 1975, 1977, & 1984)
- [George Miller](https://en.wikipedia.org/wiki/George_Miller_(filmmaker)) (Australian filmmaker)

§

![](https://peterattiamd.com/wp-content/uploads/2022/12/bio-image-hemsworth-500x500.png)

##### Chris Hemsworth

Christopher Hemsworth is an Australian actor who is most well known for playing Thor in the Marvel Cinematic Universe.  Apart from his work in Marvel movies, he has starred in *Star Trek* (2009), *A Perfect Getaway* (2009), *Snow White and the Huntsman* (2012), *The Cabin in the Woods* (2012), *Red Dawn* (2012), *Rush* (2013), *Blackhat* (2015), *Men in Black* (2019), and *Extraction* (2020).  Most recently, he was the star in the National Geographic docuseries [*Limitless*](https://disneyplusoriginals.disney.com/show/limitless-with-chris-hemsworth) which focuses on the natural physical declines that come with aging and what can be done to preserve health.  [[Wikipedia](https://en.wikipedia.org/wiki/Chris_Hemsworth)]

Facebook: [Chris Hemsworth](https://www.facebook.com/chrishemsworth/)

Instagram: [@chrishemsworth](https://www.instagram.com/chrishemsworth/?hl=en)

Twitter: [@chrishemsworth](https://twitter.com/chrishemsworth)