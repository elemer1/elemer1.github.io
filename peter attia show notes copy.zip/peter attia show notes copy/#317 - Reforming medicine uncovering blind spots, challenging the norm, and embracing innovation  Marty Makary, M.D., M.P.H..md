# #317 ‒ Reforming medicine: uncovering blind spots, challenging the norm, and embracing innovation | Marty Makary, M.D., M.P.H.

**Source:** [https://peterattiamd.com/martymakary3/](https://peterattiamd.com/martymakary3/)

---

Marty Makary, a Johns Hopkins surgeon and New York Times bestselling author, returns to The Drive to discuss his latest book, [*Blind Spots: When Medicine Gets It Wrong, and What It Means for Our Health*](https://geni.us/blindspots). In this episode, Marty explores how a new generation of doctors is challenging long-held medical practices by asking critical new questions. He discusses the major problems of groupthink and cognitive dissonance in the medical community and delves into several of the “blind spots” raised in the book, including treatments for appendicitis, the peanut allergy epidemic, misunderstandings about HRT and breast cancer, antibiotic use, and the evolution of childbirth. He explains the urgent need for reform in medical education and the major barriers standing in the way of innovative medical research. Throughout the conversation, Marty offers insightful reflections on where medicine has succeeded and where there’s still room to challenge historic practices and embrace new approaches.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/martymakary3/the_Drive_public.png)

Play

#317 ‒ Reforming medicine: uncovering blind spots, challenging the norm, and embracing innovation | Marty Makary, M.D., M.P.H.

#317 ‒ Reforming medicine: uncovering blind spots, challenging the norm, and embracing innovation | Marty Makary, M.D., M.P.H.

1x15s30s

0:002:03:23

## We discuss:

- The issue of groupthink and cognitive dissonance in science and medicine [2:30];
- How a non-operative treatment for appendicitis sheds light on cognitive dissonance [7:00];
- How cognitive dissonance and effort justification shape beliefs and actions [13:15];
- How misguided peanut allergy recommendations created an epidemic [17:45];
- The enduring impact of misinformation and fear-based messaging around hormone replacement therapy allegedly causing breast cancer [25:15];
- The dangers of extreme skepticism and blind faith in science, and the importance of understanding uncertainty and probability [28:00];
- The overuse of antibiotics and the rise of antibiotic resistant infections and poor gut health [33:45];
- The potential correlations between early antibiotic use and chronic diseases [40:45];
- The historical and evolving trends in childbirth and C-section rates [50:15];
- Rethinking ovarian cancer: recent data challenging decades of medical practice and leading to new preventive measures [1:05:30];
- Navigating uncertainty as a physician [1:19:30];
- The urgent need for reform in medical education [1:21:45];
- The major barriers to innovative medical research [1:27:30];
- The dogmatic culture of academic medicine: why humility and challenging established norms is key for progress [1:38:15];
- The major successes and ongoing challenges of modern medicine [1:51:00]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Marty Makary is a surgeon and public policy researcher at Johns Hopkins University as well as Peter’s former colleague during residency
- He’s a member of the National Academy of Medicine
- He writes regularly for *The Washington Post, The New York Times*, and *The Wall Street Journal*
- He is the author of 2 New York Times bestselling books: [*Unaccountable*](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198367/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.ZkiqDaZraR6YHsTFrDsb-F-cC9jtrzD2I9vls2VHGSruX-togrknfjJuZLqWMoBuVljVBolo722HfMvWygize3U1tJEw1bYp799jx7EDPzw-EyczA_jmUOf-LCoUZs78DVzNsociiR1r802g2yZKZFBCu7BfVIB5GEcK-SLp04lw9ZGW5UOd1clM6CGYsZZ0.WywSNj4o0F8sXR0PMeLF-w5PvYb0O01Qkucylr7aihQ&qid=1723636916&sr=8-3), and [*The Price We Pay*](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.ZkiqDaZraR6YHsTFrDsb-F-cC9jtrzD2I9vls2VHGSruX-togrknfjJuZLqWMoBuVljVBolo722HfMvWygize3U1tJEw1bYp799jx7EDPzw-EyczA_jmUOf-LCoUZs78DVzNsociiR1r802g2yZKZFBCu7BfVIB5GEcK-SLp04lw9ZGW5UOd1clM6CGYsZZ0.WywSNj4o0F8sXR0PMeLF-w5PvYb0O01Qkucylr7aihQ&qid=1723636916&sr=8-2)
- His current book ([*Blind Spots: When Medicine Gets It Wrong, and What It Means for Our Health*](https://geni.us/blindspots)) is set to be released on September 17
- In this episode we talk about many of the themes in his new book
  - Including how a new generation of doctors are thinking differently to ask new questions about the way things have been practiced in medicine historically
- We lay the foundation for the conversation by discussing cognitive dissonance and how this theory applies to the medical community today
- We discuss a few examples of the blind spots from the book such as
  - The treatment for appendicitis
  - The peanut allergy epidemic
  - The misunderstanding of HRT as it relates to breast cancer
  - Antibiotic use
  - How childbirth has evolved over the years, and more
- All of these detail the many scenarios in which a new medical approach may be possible if we’re able to ask different questions
- We also reflect on where medicine has done a good job over the last few decades, and where Marty believes there is room to challenge historic practices and pave a new way

## The issue of groupthink and cognitive dissonance in science and medicine [2:30]

- Marty’s new book is out: [*Blind Spots*](https://geni.us/blindspots)
- Peter remembers talking with him as it was in the works and asks, “*Can I take 5% credit for the inclusion of* [*HRT*](https://en.wikipedia.org/wiki/Hormone_replacement_therapy) *in this book?*”
  - [Discussed in-depth in [episode #253](https://peterattiamd.com/joannmanson/) and a previous [newsletter](https://peterattiamd.com/clearing-the-air-on-hrt/)]
- Marty explains that Peter gets 99% credit for that; that was incredible
- That tipped him off to do his own investigative journalism
- He tracked down the people that made that initial announcement saying HRT caused breast cancer and he pinned them down and went over the stats with them hard and finally got them to confess that it did not
- Peter thinks the book is a great read and it goes through a number of situations that all have this theme in common, “*The idea is a bit shaky in terms of lack of evidence, which in and of itself is not really a problem. That really is the way medicine and science have to work. They have to start with ideas that we may or may not have great evidence for, but what goes wrong?*”

**Why is there a book about this instead of a bunch of case studies of how everything has gone really well?**

- There’s a science to [groupthink](https://en.wikipedia.org/wiki/Groupthink), and that’s what’s really going on a lot of times
  - It’s the bandwagon effect
  - It’s not just in medicine, it’s in business, it’s in politics, it’s in relationships
  - People are dead set on an idea, not because they’re convinced of it, but because they simply heard it first
- There was a psychologist named [Leon Festinger](https://en.wikipedia.org/wiki/Leon_Festinger) who since passed away, but had written a tremendous amount of material on this idea of [cognitive dissonance](https://en.wikipedia.org/wiki/Cognitive_dissonance)
  - He really carved this entire discipline out in psychology
  - The idea is that the brain doesn’t like to be uncomfortable with conflicting ideas
  - It likes to settle and be lazy with one thought; it’s often the first thing you hear
  - If something comes along that challenges your deeply held views or just what you’ve happened to heard before, there’s this internal conflict
- What the body does is it will reframe the new information to make it fit what you already believe or it’ll dismiss it completely, kind of the modern day cancel culture
- This happens in day-to-day life
- It happens in human interactions and it happens in medicine too

> “*We get this herd mentality, but the important thing in science is that the purpose of science is to challenge deeply held assumptions. That’s something that I follow as a thread in so many areas of modern day health recommendations in this book.*”‒ Marty Makary

***One of Peter’s takeaways from the book is what a person can do going forward***

**How does a normal person navigate this?**

- Peter thinks this is a hard thing to hear both as the author of the book and as a person listening
- Using himself as an example, he has access to more information
  - He has a research team that can help him a answer questions
  - If he was to challenge every idea out there, he’s not sure he’d get anything done

*What is the balance in your mind between when your doctor tells you something that makes sense (seems logical, plausible) but technically, you haven’t done the thinking on it?*

Peter asks, “*How do you not allow yourself to become a crazy conspiracy theorist who doesn’t trust anything and throws out what’s 80% good in the pursuit of throwing out the 20% that’s trash? How does one navigate that?*”

- There are extremes on both sides
- You see the pendulum swing, like with **childbirth**
  - There’s this over medicalization of ordinary life, and then this swing back to avoid all doctors and hospitals and deliver at home with nobody
- It’s a dangerous proposition
- You see that frequently in the history of modern medicine

***For the everyday consumer out there, I think the flag should go up when something is put out there as a health recommendation with such absolutism as science evidence-based, when really there’s nothing to point to***

- We don’t want to create hysteria
- We need people to trust doctors
- Marty needs his patients to trust him a lot of times, but asking questions should be part of the process
- There are times when we are very slow as the medical community to implement scientific evidence and it’s okay to educate the public on it

## How a non-operative treatment for appendicitis sheds light on cognitive dissonance [7:00]

**What an** [**appendicitis**](https://en.wikipedia.org/wiki/Appendicitis) **is**

- It’s inflammation of the appendix and infection sets in
  - The tight junctions [in the appendix] break down and bacteria from the colon will creep in there and infect the appendix
  - It becomes inflamed, and gets into the blood system in late stages

**200 years ago, what was the mortality from acute appendicitis?**

- The **mortality** was over 60%
- [Walter Reed](https://en.wikipedia.org/wiki/Walter_Reed), a famous physician died of appendicitis
- It was a common cause of death
- The **lifetime prevalence** was not that small, 5-7%
  - There’s a 1 in 18-20 chance you’d get an infection of your appendix and a 60% chance that if you got it, it would kill you
- It’s still one of the most common operations performed in American hospitals
- As surgeons, we have learned it as a reflex
- When Peter was at Johns Hopkins, he and Marty did many together
- You do it swiftly
- You do it with a laparoscope as of the last 30 year
- This is a reflex; we don’t even think about it in the hospital
- It’s been one of these easy things: diagnose, treat, diagnose, treat
- Diagnosis used to be tricky, because it can present a lot of ways
- Now, the CAT scan just points out the bullseye, and you go to work
- It’s a quick great case for a surgeon and a surgical trainee

**Then a study came out showing that you don’t need to operate, and a short course of antibiotics is 67% effective in patients that come in with appendicitis**

- If the appendix is not ruptured or there’s no little stone (what we call a fecalith in the appendix), which is the vast majority of people
- Here’s a discovery that really shook up the whole field of modern surgery

**Peter’s recap**: If you’re in the majority of cases of appendicitis, it’s not yet ruptured, and it doesn’t have an obvious mechanical cause, you can get the same outcome as surgery by using antibiotics in 60-70% of the cases

- If they don’t respond to an antibiotic, then you take them back to surgery (approximately a third of those people
- Marty explains that something like high 80% will respond to the initial course of antibiotics and only a small fraction (maybe 12%) will come back with recurrent symptoms in the first month
  - Then you go to surgery for them

***The total cure is 2/3’’s***

**By avoiding surgery**

- The cost is reduced
- The patient doesn’t have to undergo an incision, anesthesia, risk of infection, risk of hernia
  - All of which are minor risks, but they’re present
- Other savings: the carbon footprint of the hospital, the amount of waste produced, the nursing staffing resources, the wait list at a hospital every night
  - Every hospital in America has cases that are waiting to go, and typically, there’s an appendix or two on that list
- Marty explains, “*We’ve got a nursing staffing crisis. There’s so many implications to appropriately implementing this research.*”

**Marty offered this to a kid who came to see him**

- The study had been out for a couple of months
  - He read it and was convinced
- Nobody else was really offering it at the time
- A 19-year-old, perfect candidate, no rupture, no fecalith, healthy guy with an early appendicitis came in
- They’re already getting antibiotics when they get diagnosed in the emergency department
  - Usually you just need to run it a little bit longer
- Marty offers him surgery versus no surgery
- He tells Marty that he has to fly out the next morning to Boston for his sister’s wedding
  - Marty thinks, “*Oh, my God. What gets him to the wedding faster?*”
    - If he gets in the operating room right now, he might get there in a wheelchair
- He offered him both and told him what he didn’t know

> “*I told him what I don’t know, which is I think the most important part of being a doctor is understanding the unknowns and dealing with uncertainty.*”‒ Marty Makary

- He chose the antibiotic; he chose no surgery
- He goes to the wedding the next day, dances up a storm

***Marty becomes so convinced that this may be revolutionary; then he talks to one of his colleagues***

- He tells one of his colleagues about it and gets the reply, “*I don’t buy it.*”
- Marty pointed him to the [randomized control trial](https://pubmed.ncbi.nlm.nih.gov/26080338/), published in a top journal
- He says, “*I need to see two randomized control trials.*”
- They’ve been doing this in Europe a lot longer than we’ve heard about it in the U.S.
- A [second randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/33017106/) comes out a year later, and Marty shows it to him
- He says, “*I need to see three randomized controlled trials.*”
- Believe it or not, a [third one](https://pubmed.ncbi.nlm.nih.gov/35576384/) came out maybe 6 months later
  - [Long term follow-up](https://pubmed.ncbi.nlm.nih.gov/30264120/)
  - The initial study was [repeated in children](https://pubmed.ncbi.nlm.nih.gov/31800496/)
- Other studies came out that were non-randomized
- Marty showed it to him and he said, “*I just think you’re better with it out*.”
- Marty thought it would be unethical to do any more research [the case for it had been made]

## How cognitive dissonance and effort justification shape beliefs and actions [13:15]

- Marty’s colleague who didn’t accept non-surgical treatment of appendicitis is an example of the **cognitive dissonance** that Leon Festinger was describing

**Leon Festinger embedded himself into a cult to prove his theory correct**

- A cult that met in Chicago believed that aliens were going to pick them up, because there was going to be a great flood on a certain day, a certain time
  - He read about this in the paper that they were assembling to be picked up by this spaceship

***He realized this is the real world example of his theory of cognitive dissonance, why we cling to what we believe first, and we’re not open-minded to be objective***

- Leon wanted to test and see when the aliens don’t come to rescue the people who were firm believers, how many of them would say, “*Oh, my God. How stupid was I to think this?”*
  - Versus what will be the set of stories that get spun to explain why their belief was still right?
- Aliens didn’t come that night and he was there in the room with all the cult members and somebody said at 12:05 (because the pickup was supposed to happen at noon), “*Oh, the other clock is wrong. It’s really 11:55*.”
- Everyone gets excited and there’s this denial and denial through the night
- By the morning, it was obvious; it did not come true
- And they did not abandon their views; they dug in deeper
- Those who had a little belief, they thought, “*This is nuts;*” they just left
- There was a physician that Festinger spent time with, and he writes about it in his book called [*When Prophecy Fails*](https://www.amazon.com/When-Prophecy-Fails-Leon-Festinger/dp/1578988527/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.IILRhX8coKD7K22mkPIsTRkhLb1rLHv-m8fFzLJ6_uByljAYF9pZET-zVVDGg_qKvcwR4p8Q_0jzLIwc_a7twqE2uV1DG1tDYAETPOGNJCwK9k8qjODjwHuiMvHicLGr3e9gAuAhwm1jQzF3XBZvIIbLw_yN3ViCoKPJ0JPI_jxkKrk29-eOuOtJ9IaMXNas.bf695LWKTA35ZC9nUdZ-n8lPOLeeu_JPZyByezbLDJA&qid=1724074659&sr=8-1), where the doctor said it just openly once, almost in a Freudian way, said, “*I just have so much vested in this now at this point. My job, my family, my friends, everybody knows I’m so into this. I have to hold on.*”

***Festinger watched in plain view what we all experience in a subconscious way: this resistance to new ideas***

- You see it in politics and business and everything else

**It’s a theory that’s now well accepted as cognitive dissonance**

- It’s tied closely to [effort justification](https://en.wikipedia.org/wiki/Effort_justification) (that’s the concept in psychology)
- The idea is, “*Hey, I’m vested. I’ve spent all this energy on it. It must be good or justified*.”
- We do that with our surgical residency, fraternity hazing
- It fosters this cycle of abuse

**More examples**

- Two psychologists right after Festinger around that time took college students and set up an experiment where they did a tedious, boring task
  - They paid each group
  - But one group they paid them $20
  - The other group they paid $1 an hour

***Which group said they enjoyed doing the task more? The group getting paid a dollar, because they had to justify***

*Another experiment*

- They had 3 groups where they would give them a sex talk and have them take an entrance exam
- Group 1 had an entrance exam that was incredibly difficult
  - They didn’t give them the results, but just said, “*You passed.*”
- Group 2 had a moderately difficult exam
- Group 3 had no exam
- Then they had the talk, and it was the most boring, disappointing letdown you could imagine
  - Basically bees get together and multiply
- Participants thought, “*What? This is what we tried hard to get in for this class?*”
- Then they asked them if they enjoyed the class

***The group that enjoyed it the most was the one with the hardest test***

**This plays out in our lives every day**

- Marty has read these studies and written about them
- He thinks about his in his research meetings when new ideas get suggested
  - When people ask him if we should do it a certain way

> “*We’ve got these traditions and dogmas in medicine that can take on a life of their own.*”‒ Marty Makary

## How misguided peanut allergy recommendations created an epidemic [17:45]

- This is an epidemic, it’s tragic, and people can go into severe [anaphylaxis](https://en.wikipedia.org/wiki/Anaphylaxis) just being near a peanut without even ingesting the peanut
- In 1999, Mount Sinai did a [study](https://pubmed.ncbi.nlm.nih.gov/10200001/) and estimated the prevalence to be about half of 1%
  - The vast majority were very mild
- There are many theories as to why that might’ve crept up from zero generations prior, but the American Academy of Pediatrics decided to address this problem by issuing a recommendation
- Now, they didn’t know what to recommend
- Marty went back and interviewed some of the individuals who made that recommendation
- It was a strong recommendation, and even if it wasn’t made with such absolutism, it was interpreted as the law of the land
- The recommendation was for all children age 0-3 to avoid all peanut products, including the little peanut butter moms would put into food in infancy, and pregnant mothers and lactating mothers should also avoid peanuts
  - 100% peanut abstinence

***That was the year 2000, and what happened immediately after that recommendation was peanut allergy rates in the US began to soar***

**We saw a new type of allergy, which is the severe anaphylactic reaction, the ultra allergy**

- Where if someone used the same ice cream scooper in the pistachio, even though they had rinsed it, that kid could end up in the emergency room
- We saw emergency room visits skyrocket

**The medical establishment (the elites) [pushed this recommendation], not the rank-and-file doctors that think independently**

- A lot of rank-and-file doctors knew they just made this up
- Some had immunology backgrounds and knew this doesn’t fit with immunology
- In immunology, you need to be exposed to things early in life to be immune tolerant, something called [oral](https://en.wikipedia.org/wiki/Immune_tolerance#Oral_tolerance) and [immune tolerance](https://en.wikipedia.org/wiki/Immune_tolerance)
  - Parents have known it as the dirt theory, where sometimes that you’re around cats and dogs and kids that play in dirt develop a robust immune system where they are healthier later in life
  - Bubble kids end up getting really sick later on

**Pediatricians try to speak out against this recommendation to avoid peanuts**

- Allergist [Gideon Lack](https://www.harleystreetpaediatricgroup.com/prof-gideon-lack/) was enlightened early on, he noticed that kids who had iron or metal in their teeth for dental work, were less likely to get a reaction to ear-piercing later in life
- He had done research in immune tolerance and knew this concept
  - If you’re exposed to something, you’re less [reactive to it]
- Well, a bunch of pediatricians detested this [peanut avoidance] recommendation, and tried to speak up
- They were basically silenced or sidelined

**It became known as the 1, 2, 3; it took on a life of its own; it became dogma**

- At age 1, you can introduce milk
- At age 2, you can introduce eggs
- At age 3, finally, you can introduce some peanut products

**The medical establishment doubled-down on the recommendation to avoid peanuts for the first 3 years**

- They assumed that people were not listening to their recommendation
- They thought, “*We have non-compliant parents out there. If we can only get everyone to comply with this, we can defeat this epidemic.*”
- If you can hear little echoes here of modern day correlations

***The more they doubled down, the worse it got to the point where now there’s an estimate that 1 in 18 kids has a peanut allergy, but the severe peanut allergy is the real issue now***

**About 20% of schools in America have banned all peanut products altogether**

- The more you ban, the less exposure, the more immune sensitization
- Parents who decided to introduce peanut butter as their grandmother did were ridiculed as anti-science

**2 medical students from Africa in Marty’s research center at Johns Hopkins**

- These are public health graduate students, one’s from Cameroon and one’s from Zimbabwe
- They flew over for the research meeting, and in their first days they were like, “*What is it with the peanut allergies here?…* ***We have no peanut allergies in Africa****.*”

***We think it might’ve been microbiome related, but the peanut abstinence threw lighter fluid into this fire and it really resulted in where we are today***

**15 years into this recommendation, the study that Dr. Gideon Lack proposed got done**

- A [study](https://pubmed.ncbi.nlm.nih.gov/25705822/) published in *The New England Journal of Medicine* in 2015 with 640 kids doing a randomized control trial to early peanut butter exposure in infancy 4, 5, 6 months (not as their sole diet)
- These kids are still pro-breastfeeding, right?
- Whole peanuts have a choking risk
- Fast-forward a couple of years, radically 8-fold different rates in peanut allergies and severe allergies
- It’s one of the biggest odds ratios you see in research

***2 years later (in 2017), the bureaucrats at NIAID (National Institute of Allergy and Infectious Disease) and NIH get around to putting out a*** [***position paper***](https://www.niaid.nih.gov/sites/default/files/addendum-peanut-allergy-prevention-guidelines.pdf) ***reversing the recommendation to avoid peanuts in infancy***

- For 17 years people followed the recommendation to avoid peanuts

**Do we also understand how much has that position paper reversed the behavior in parents?**

*When it comes to kids that are born today, do we know that the amount of peanut abstinence going on is virtually gone now?*

- It’s unknown, but it’s a great point
- Why not reverse the recommendation now that the science is clear with the same vigor at which you pointed out initially?
- Why not show some humility?

***We didn’t see the leaders get out there and call CBS Mornings and other morning shows and say, “Hey, we got something terribly wrong. We really need to correct the record on this.”***

## The enduring impact of misinformation and fear-based messaging around hormone replacement therapy allegedly causing breast cancer [25:15]

**That’s the beef Peter has with the** [**HRT**](https://en.wikipedia.org/wiki/Hormone_replacement_therapy) **stuff: the megaphone of fear that was promulgated through estrogen hysteria in 2001**

- Even though if you read the fine print today, many of those people have walked back those recommendations of estrogen avoidance
- Again, not only is it too little, too late: you’ve got a generation of women, over 20 million women who have been deprived of HRT
- Even women that are eligible to take HRT today, they’re still confused because the same megaphone that was used to say estrogen will give you breast cancer is not being used to correct course

***There’s an enormous asymmetry in these information campaigns***

- Peter has done a great job covering HRT [in [episode #253](https://peterattiamd.com/joannmanson/) and a [newsletter](https://peterattiamd.com/clearing-the-air-on-hrt/)]
- In the investigative journalism Marty did around the HRT dogma, he discovered from one of the guys in that committee that they were hoodwinked before the announcement
- The 40 investigators were basically told,  “*Hey, throw out the agenda. We’ve got some breaking news on this study, [HRT] causes breast cancer. We already submitted the journal. It’s coming out.*”
- A bunch of guys there are like, “*This is not how we do research.*”
  - One of them, [Bob Langer](https://profiles.ucsd.edu/robert.langer), who Marty interviewed, had said in a shouting match with the lead investigator, “*Look, if you put something out there as sensitive as breast cancer is caused by HRT, you will never be able to put that genie back in the bottle.*”

***Sure enough, Bob Langer confessed to that there was no increase in breast cancer deaths***

- That was at the time of [publication](https://pubmed.ncbi.nlm.nih.gov/12117397/)
- That was demonstrated again [9 years later](https://pubmed.ncbi.nlm.nih.gov/23543779/), and again in a follow-up of the same cohort [20 years later](https://pubmed.ncbi.nlm.nih.gov/32721007/)
- Marty explains, “*There’s probably no modern day medical intervention that has improved the health of a population as much as HRT for postmenopausal [women], but it’s not just HRT. The medical establishment got opioids wrong for 35 years. They got heart stents wrong for 15 years. They got the low-fat diet wrong for how many 60 plus years. They got peanut allergies wrong for 17 years.*”

***Where’s the apology? Where’s the humility? That’s why there’s distrust right now***

## The dangers of extreme skepticism and blind faith in science, and the importance of understanding uncertainty and probability [28:00]

**Where Peter struggles**

- He has friends who are otherwise smart people who have such ridiculous views in terms of where the pendulum has swung the other way, and they’re convinced you shouldn’t microwave your food because microwaves are harmful
- He doesn’t say this to be arrogant, but there’s such a degree of scientific illiteracy that even when he tries to explain to one of these friends what a microwave is and why a microwave can’t be harmful
  - You have to understand what ionizing radiation is
  - You have to understand if microwaves are harmful, then light is more harmful based on the wavelength
- That’s a hard thing to explain to people who don’t understand science ‒ you can’t see wavelengths; it’s difficult

***It bothers Peter that we’ve created a bimodal distribution of complete rejection of science, and everything that medicine says is wrong (and you should never go to a doctor and anything your doctor says is wrong), to complete and utter blind faith***

- It comes back to his question, which he doesn’t have a great answer to, “*How does a reasonable person maintain skepticism but not be paralyzed by it and not be pushed so far to either extreme?*”
- Marty doesn’t have a satisfying answer either

***This is exactly what Leon Festinger was describing***

- The father of modern medicine, [Dr. Claude Bernard](https://en.wikipedia.org/wiki/Claude_Bernard), said, “*In science more than in any other discipline, you have to recognize that we bring biases to any question. You have to actively suspend those biases as you take in new information, so you have impeccable objectivity*.”

***It’s a lesson for everyone today. Unfortunately, we’re going the other direction in science right now.***

**The mindset in medicine**

- We’ve got this culture of obedience in medical school that goes right down to your first day of medical school
- Marty is an optimistic on the future of healthcare because enough people now are anti-central authority, anti-corporate, and they’re questioning things they didn’t before, but this culture of just get in line and do what you’re told is still a powerful force [we’ll come back to discuss medical education at the end]
- Peter has said this many times before, “*There are no proofs in science… Nothing is 100% certain. Science is not a thing, it’s a process*.”
  - What is highly probable today is probably a better way of describing something that we think is true

***New information should always be obtaining probability***

- Peter feels very fortunate that he was a math major before he went to medicine because it came to him a little more naturally to think that way
  - He was trained in the mathematics of uncertainty (statistics and probability theory)
- You could look at some index cases of peanut allergies in the ‘90s, and you could say they hypothesis of this being due to being exposed to peanuts as a child turns out to be wrong, but that would be your hypothesis
  - You wouldn’t cling to that hypothesis with absolute certainty because you would understand that it’s a probability distribution and you might assign it a probability of 50%
- You would say, “*Well, if this is true, how would I test it?*”
- You would test it; then, based on information as it’s coming in, you would update that probability
  - Is it now more than 50% or less than 50%?
- COVID offered so many lessons in this, which is, “*Hey, did this virus come from a lab or did it come from a wet market? I don’t know. I’d say 90% it came from a wet market because we have a precedent of viruses coming out of wet markets.*”
  - We’re going to try not to talk about COVID today because COVID fatigue is rampant
- Well, 3 months later we have some more information, should we update the probability?
- Maybe it’s 80/20 now
- 6 months later, we still haven’t found the vector so maybe it’s 50/50

***If you thought about it that that way, it’s easier to change your position because you’re not wed to a binary outcome (yes or no); you’re thinking about it as a probability distribution function***

- The probability is constantly getting upgraded, updated, improved, and it’s theoretically converging on what is true as we go
- Like [Ivermectin](https://en.wikipedia.org/wiki/Ivermectin), all of these things are reasonable things to have assumed, but what became unreasonable was to not go through this process
  - Both sides, the sides that clung to them and the sides that morally opposed them

## The overuse of antibiotics and the rise of antibiotic resistant infections and poor gut health [33:45]

- This is something that probably doesn’t get that much attention
- When Peter was in the hospital, we talked a lot about the idea of [antibiotic resistance](https://en.wikipedia.org/wiki/Antimicrobial_resistance) being a real problem (particularly in the ICU)
- But as a person who lives outside a hospital now, Peter doesn’t hear much about it
- That makes him think one of a couple scenarios
- Scenario #1 is it was greatly exaggerated in the early 2000s when he was a resident because it hasn’t materialized
- Scenario #2 it was real and still is real, but more and more drugs are being developed to keep the bacteria at bay
- He could walk through several other machinations

**Give us a sense of what this means, what the implications are and what can be done about it**

- About 100,000 people in the US die each year from antibiotic resistant bacteria
- The time period it took for bacteria to develop resistance through their natural evolution was about 23 years when antibiotics were first mass-produced in the 1950s and 60s
- Then it shrunk down to 14 years, and now it’s about 1 year

***Within a year, a bacteria will mutate around an antibiotic [to develop resistance]***

- We’re now seeing [*C. diff*](https://en.wikipedia.org/wiki/Clostridioides_difficile) (one of those common bacteria) take the life of somebody every other month or so in the hospital
  - In most hospitals, you tend to pick it up in the hospital
- About 60% of outpatient antibiotics are unnecessary according to several studies
  - The same is true for inpatient antibiotics
- So you’ll look back and say, “*Oh yeah, they took* [*Ancef*](https://en.wikipedia.org/wiki/Cefazolin) *for this tiny little thing they didn’t need to take the Ancef antibiotic for*.”

**In the operating room**

- Matry has personally given thousands of unnecessary antibiotics because he’s been forced to
- When you perform an operation, there’s a protocol that you give every single operative patient antibiotic before the incision
- The reason was there were bacteria on the skin and even though we scrub the skin, you can’t get every bacteria out
- We’re going to give you an antibiotic that has to be in your system
  - It’s going to be given to you intravenously
  - Usually the anesthesiologist still does it in pre-op or before you cut the skin so that by the time that incision goes through whatever bacteria are on the edge of that skin aren’t going to potentially get in
- That makes a lot of sense, and Peter has never questioned it
- There must’ve been studies that demonstrated lower incidence of wound infections

**Was something that prevalent implemented without an RCT?**

- There were studies and there were RCTs in major abdominal operations that were done open

***Now, most surgery is done minimally invasive, and people have inappropriately extrapolated those findings to minimally invasive surgery***

- Have you ever heard of an infection after a [laparoscopic inguinal hernia](https://en.wikipedia.org/wiki/Inguinal_hernia_surgery#Laparoscopic_repair)?
  - Marty has never seen it

Peter asks, “*But isn’t that because we’re giving them antibiotics, potentially?*”

- Marty doesn’t think so, because you would see at least some [infections], he doesn’t think it would be 100% effective
- You don’t see that with abdominal surgery
  - It reduces the incidence of infections a little bit
  - Marty doesn’t think there’s any mechanism in some of these procedures
- For whatever reason, with no data, the research from open abdominal GI cases got extrapolated broadly

**Rationale behind this broad recommendation**

- Marty was actually in practice a little bit before the broad recommendation
- He remembers asking this guy, [Patch Dellinger](http://antimicrobe.org/authors/E_Patchen_Dellinger.asp) (who was involved in these recommendations), “*Why is it the antibiotic recommendation at the time of incision for every operation? I’ve never seen or heard of an infection for these minor procedures.*”

***The committee thought about this a lot and decided that making it easy to remember to do it for every operation would ensure that the big operations get it***

**Marty wondered what these antibiotics are doing to the gut microbiome**

- A new theory has emerged out of the University of Chicago suggesting that surgical infections don’t come from the skin bacteria crawling in
- It comes from the gut, some sort of weakness in the gut, and there may be a transposition of some bacteria
- They’ve actually done studies now in mice where they alter their gut microbiome prior to surgery and they have found that there’s some reduction in infection

***It’s possible the giving probiotics preoperatively may reduce the risk of infection***

- This is a big area of ongoing research; there’s nothing definitive

**We’ve learned that people should chug a Gatorade 3-4 hours before surgery**

- It’s mostly for the glucose
- But what’s it doing to the gut?
- Is the patient coming in a starvation state and is that doing something to the microbiome?
- We’ve had all this dogma in the operating room
  - You got to wear your hats like here, you got to cover your shoes
  - Some places don’t cover your shoes
- Then you go to Africa and you realize they’re not wearing anything (not even masks), and their infection rate is no different
- You wonder what the mask is doing?
  - Preventing sweat from dripping in?
  - Preventing airborne particles? They come out of the side of your mask

***Research at the University of Chicago is challenging a lot of deeply held assumptions in operating room protocol***

**Changes Marty has made when he operates**

- For a minor laparoscopic procedure he doesn’t give Ancef anymore

> “*The average 10-year-old in America has taken 11 courses of antibiotics, and the average 3-year-old has taken 2.5 courses of antibiotics. We think that 0-3 age group, the microbiome is the most sensitive to antibiotics.*”‒ Marty Makary

***Antibiotics are like carpet bombing your microbiome, these millions of bacteria that live in harmony***

## The potential correlations between early antibiotic use and chronic diseases [40:45]

**A** [**study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7796951/) **out of the Mayo Clinic is shattering our assumptions about chronic diseases**

- Mayo Clinic researchers took the 14,000 children that live in Olmsted County, the area of Rochester, Minnesota
- They looked at kids who took an antibiotic course in the first 2 years of life and tracked whether or not they developed asthma, learning disabilities, obesity later in childhood
- What they found were these incredible correlations
- There were about 10,000 kids who had taken an antibiotic course and 4,000 who had not, and they matched them to the best of their ability statistically

*Among kids had taken an antibiotic in the first 2 years of life, they observed*

- A 20% increase in obesity
- A 21% increase in learning disabilities
- A 32% increase in attention deficit disorder
- A 90% increase in asthma
- A 289% increase in celiac disease
- These were all the statistically significant findings
- Other studies have shown a correlation between antibiotics early in childhood and ulcerative colitis and Crohn’s disease

***It makes sense, we’re changing the microbiome***

**We may be carpet bombing the microbiome with the dogma that there are no downsides to antibiotics**

- You got some sniffles, it probably won’t help you, but it won’t hurt you ‒ not true

Peter asks, “*In this study, how do we know that the 4,000 kids who were in the control arm that didn’t get antibiotics weren’t healthier kids, which is why they never needed the antibiotic and that it wasn’t some other factor about the 10,000 who did get the antibiotics, either they were just naturally less healthy kids. There was something about them that was less robust. There were other factors that couldn’t be corrected for that actually explains those differences.*”

- Marty loves this question ‒ that’s how a scientific mind should think because there could be confounding variables
  - For example, maybe it’s the infection they they were treating that is the cause

***First, we cannot make conclusions from this study, but this study is an incredible signal that we should pay attention to for 2 reasons***

- 1 – It’s been repeated in a [Danish study](https://pubmed.ncbi.nlm.nih.gov/26312581/) of about a million children
- 2 – There was a dose-dependent relationship where the more courses of antibiotics the child took the higher the odds ratio

![](https://peterattiamd.com/wp-content/uploads/2024/09/f1-martymakary3-1024x800.png)

**Figure 1. Association between antibiotic exposure in the first 2 years of life and risk of common health conditions**. Image credit: [*Mayo Clinic Proceedings* 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7796951/)

**Explain how you can increase the probability of a finding being real in an epidemiologic study**

*This comes back to: what’s the probability?*

- Peter explains, “*Causality is the single most important force in science. I’m convinced of that. If you don’t have causality, you have nothing… You stated a correlation. It’s only interesting to us if there’s causality*.”
- The question is how probably is the causality and various factors, defined by a statistician named [Austin Bradford Hill](https://en.wikipedia.org/wiki/Austin_Bradford_Hill), speak to the strength of the association and the probability or likelihood that that association is causal
  - [he developed the [Bradford Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria), shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/09/f2-martymakary3.png)

**Figure 2. The Bradford Hill criteria**. Summarized from: [*European Journal of Epidemiology* 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8206235/)

- You could say on the basis of **strength of associations**, that one’s more likely to be causal
  - The hazard ratio (HR) for celiac disease was 2.89 (a strong HR) versus the others that are around 1.2 [see part A of the figure above]
- Another factor is **reproducibility**, that makes it a little more likely to be causal
  - Another [study](https://pubmed.ncbi.nlm.nih.gov/26312581/) did the same analysis and came up with the same answers
- The **dose effect** within the association: the more antibiotics you took, the more strongly you have these associations [see parts B & C of the figure above]
- Marty explains, “*This is the first formal study I’ve seen like this on an epidemiologic basis that fits a hypothesis that to me makes sense.*”
- [Cephalosporins](https://en.wikipedia.org/wiki/Cephalosporin) had a higher correlation [see [table 3](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7796951/)]
  - They’re generally considered to be a little more damaging to the microbiome than the [Ancefs](https://en.wikipedia.org/wiki/Cefazolin) and [penicillins](https://en.wikipedia.org/wiki/Penicillin)

Peter asks, “*Is that because they target gram negatives more or anaerobes more?*”

- Marty doesn’t know

**Other observational data**

- Farmers have used antibiotics to fatten animals for food production for decades
- The world expert on the microbiome, [Marty Blaser](https://cabm.rutgers.edu/person/martin-j-blaser), who was the chief of medicine at NYU, his daughter developed chronic abdominal diseases and obesity
  - They feel terrible because they gave her a bunch of antibiotics in childhood, and they thought there was an association
  - He’s a laboratory scientist, and he started doing all these mice experiments

***If antibiotics are making animals more obese, what are they doing to humans?***

- Peter explains that is another of the Bradford Hill criteria: do you have **experimental evidence** that also supports this?
  - In the case of human epidemiology, you would look at animals

**Let’s go back to the** [**Rochester Minnesota study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7796951/)

- You got 4,000 kids who never took an antibiotic
- 10,000 kids who did at least a course or 2
  - Those 10,000 kids weren’t just given antibiotics for no reason
  - They must have had ear infections, tonsillitis, appendicitis, something

Peter asks, “*How do we draw the line between what was medically necessary? Because as unfortunate as those consequences are they pale in comparison to a life-threatening infection that could have killed a kid. How do we decide what the minimum effective dose is, what’s absolutely medically necessary versus what is superfluous and potentially just exposing a kid to these complications later in life?*”

- Antibiotics save lives; they’re amazing medications
- They ushered in the “white coat era”
- Peter wrote in his [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.2CY-ecDoB_FwcCj_cX8lmzdRff_Ow52M8M5ozrXZWdoaJ6XpnhAXg7VGE_lpiV-cjd2V_3kSqKTHUhw87kQ342_d7RAnoRie-8WaPJnwyiX4m7yUM-4PQ4OAYEcYDCSZeth-mG2LZDVW5oI5XBlNRXDF4Itsh7jA74axzMHpl7R9LBIFY-rqj35S28ceTpcHX3IO7M_fxDnRR_688VOZy0xrFmoQJof4dWYiB0FFGpk.guXdrXXz9FALTEh2cPHepmjAEJISejYlR7_FqY0P9wg&qid=1724167915&sr=8-1), “*It’s what took us from medicine 1.0 to medicine 2.0*.”
  - It’s not the only thing that made the difference, but arguably the single most important difference was sanitation and antimicrobial therapy in the transition from medicine 1.0 to 2.0
- For 250,000 years of human existence, we died like dogs from infection
  - Life expectancy was 38
- Peter concludes, “*We don’t want to throw the baby out with the bathwater*.”
- Marty agrees, this is the nuance
- People want a simple dumb message, an all or nothing
  - Which is where our echo chambers of media, politics, and social media take us in life

***Antibiotics save lives, but they are also massively abused and overused, at least 60% in all the studies***

**About 45% of antibiotic use is justified**

- Marty even questions that number because they would say that antibiotics should be given before minor surgical procedures
- There’s epidemiologic data over time that look at all these chronic diseases
  - These diseases are multifactorial, especially obesity
- Look at all the increases we’ve seen in these exact diseases that they’ve seen increase in the antibiotic group
- After the broad administration of antibiotics in the 1940s, 50s, and 60s, it just went up even further

**The discoverer of antibiotics,** [**Alexander Fleming**](https://en.wikipedia.org/wiki/Alexander_Fleming)

- In 1922 had warned after he got the Nobel Prize about the massive overuse of antibiotics
  - During Marty’s research he found Alexander’s diary where he had written about these factories producing penicillin, it blew him away
- [Penicillin came from] a mold that blew into his lab when someone left the window open
  - He was growing *Staphylococcus* on agar gel and some mold landed and formed a circle; around the mold all the bacteria were killed
- This is considered to be the greatest discovery in modern medicine
- It took us from being surgeon barbers where we had a lancet and an ax to do amputations and maybe [Digoxin](https://en.wikipedia.org/wiki/Digoxin) (which didn’t help)
  - That was it
  - Doctors weren’t disrespected, they were respected like a priest or a barber
- Then with the mass production of antibiotics, now we had the power and control of the substance where only we could give you a magic pill
  - Doctors began to wear white coats
  - They had an unquestioned authority
  - We kept people in the hospital

## The historical and evolving trends in childbirth and C-section rates [50:15]

**Care of normal healthy babies after birth**

- Normal healthy babies were routinely held in the hospital for 10 days
  - Peter was in the hospital for 14 days when he was born (normal, at term)
  - It’s crazy, you could be out of the hospital with an [aortic root replacement](https://en.wikipedia.org/wiki/Valve-sparing_aortic_root_replacement) in half that time
- Marty remembers his little sister was born around 1980 and his mom came home from the hospital after delivering her; everyday he and his brother would ask, “*Dad, when is our little sister coming home from the hospital?*”
  - She was totally normal, but the doctors hadn’t released her yet

***Looking back on it, this is medical paternalism. This is that white coat era. This never happened before in history.***

- People stayed in the hospital for 2 weeks after a cataract
- For babies, they’d measure their toe diameter, they’d probe and poke and put babies in the NICU and feed them formula
  - Mother’s would ask to hold their babies only to be told, “*No*.”
- As a student, Marty was in the OB rotations for his first rotation
- He was nervous
- He would go into a room and there’s all sorts of chaos, and his job was to cut the umbilical cord
- He’s holding these scissors, there’s chaos, then all of a sudden there’s a baby and he can barely see this slippery cord, they’re putting clamps on it and telling him to cut
- He cuts the cord then they take the baby off to a warming table
  - They put the baby under this table with the french fry light

***The irony is the baby was getting a warm blood transfusion from the mother with a pulsating umbilical cord, which was actively pulsating when they clamped it and told Marty to cut it***

- Marty didn’t say anything, he wanted to get a good grade
- He thought, “*The mom wants to hold the baby. Wouldn’t that be warm enough?*”

***Turns out the data now on skin-to-skin time: hours of skin-to-skin, that’s the best incubator***

- There’s all kinds of incredible data now on how the baby has more normal blood pressure and heart rate and more normal glucose levels when the baby is held by the mother
- When Marty heard about these studies, he was like, “*That makes sense, but I don’t get the glucose. Why would the glucose?*”
  - They’re stress hormones, cortisol spikes

**What are they doing?**

- They’re sticking a metal temperature probe in the baby’s rectum
  - Is this a nice way to welcome a human into the world?
- The baby’s temperature is what the mom’s temperature was because the baby just came from mom 2 seconds ago
- They were just like, “*Oh, we have to put it on the sheet,*” and all this probing and poking
- They wash the baby
  - Now, they know not to wash a baby for the first 24 hours, because there’s a [proteinaceous coat](https://en.wikipedia.org/wiki/Vernix_caseosa)

**C-sections**

- C-sections save lives, but C-sections like antibiotics are also massively overused
- It turns out as the head of the microbiome unit at the NIH explained to Marty when he did the research for this book, she said, “*In a vaginal delivery, the baby’s gut in utero is sterile, and so it’s seeded. The microbiome is seeded from the bacteria in the vaginal canal and then augmented by bacteria from the colostrum (the early breast milk) and the skin in the kiss of the grandparents. But when you’re born by a C-section, the baby is extracted from a sterile operative field. What may seed the baby’s microbiome are the bacteria that normally live in the hospital*.”
- When she explained it to me that way, Marty thought, “*My god, it makes sense.*”

*What is the prevalence of C-section today and how close are we to peak C-section versus, what was it 50 years ago?*

- We’re about 30% in the United States
- Private hospitals in Brazil are at 90%
- Overseas, it’s sometimes even worse
- The individual doctor C-section rate ranges from 12% to even 100%
- We have a big project at Johns Hopkins and through our [consortium](https://gameasures.com/) on the appropriateness of care, where we look at practice patterns of physicians, and we basically can profile a physician on their pattern of doing something where there’s known to be a lot of inappropriate overuse

Peter asks, “*50 years ago, the C-section was done because it was medically necessary. Is that a safe assumption?*”

- Yeah, there’s definitely more unnecessary C-sections

***The OB’s that Marty really respects and trusts (they have impeccable judgment) have C-section rates in the 12-15% range, and they talk passionately about the overuse of C-sections***

**Thinking back to the world of medicine 1.0**

- We barely got to our 40th birthdays
- Infant and maternal mortality were sky high
- Every one of those kids that would be getting a necessary C-section, they’d be dying an probably the moms are dying ‒ the C-section is a huge advance that saves lives

***C-sections and antibiotics have saved more lives than anything we’re doing in medicine today***

- That has doubled the human lifespan

**When something goes wrong in delivery**

- It doesn’t go wrong in hours, it goes wrong in seconds
- A fetus doesn’t have an enormous physiologic reserve, so when their heart rate starts crashing, you’ve got to get that baby out immediately

**Why did we go from a world in which we were able to get these 12-15% of children born safely via a C-section to a C-section rate of 50, 60, 70% (depending on your series)?**

- It’s a combination of a consumerist culture
- Being an OB doctor, specializing in labor and delivery is one of the hardest
  - It’s a brutal lifestyle
- You have somebody who’s been pushing in labor, it’s now 10 o’clock at night, they’re telling you, “*Just cut this thing out of me.*”
  - It may not be medically necessary, but in the fog of the moment
- There are OB practices where you check out from your first prenatal visit and the receptionist when they schedule the next visit also asks you to pick a date for your C-section
  - The ethical OB doctors Marty has interviewed about this ‒ it drives them crazy
  - No informed consent
- Some people think, “*Oh, it’d be nice to have it on a grandmother’s birthday, and why don’t we schedule a Christmas Eve birthday*.”
- There are so many factors
- In Brazil, there’s a dogma that vaginal delivery changes one’s sexual pleasure (it’s unsubstantiated)
- Marty went with his cousin when she delivered and the OB docs come in and looked at something on the rhythm strip and tell her that a C-section might be safer for the baby
  - Even though she didn’t want a C-section, she is reasonable and open-minded
  - You tell that to any woman and they’re going to do it

**There’s a little bit of what we call the nudge**

- When asking about the non-operative protocol for appendicitis the doctor may say, “*Well, it’s a little experimental. Could be a little dangerous.*”
- We have the nudges in medicine in every field ‒ “*You have bone on bone in your joint. Nothing is going to help except a knee replacement.*”
- Peter thinks he’s probably guilty of this, when he nudges patients toward what he thinks is the right answer

**Do we have any evidence that this trend is reversing? That it’s coming back to a more natural childbirth process?**

- For cord cutting, [studies](https://pubmed.ncbi.nlm.nih.gov/35170013/) have looked at delaying cord clamping by 45 seconds versus 90 seconds and there was a clinically statistically significant benefit to waiting 90 seconds
  - You’re getting stem cells

***OBs Marty respects say you want to cut the cord after it’s done pulsating; you could go 2 minutes***

- We don’t want the pendulum to swing to the extreme and people take inappropriate positions
  - An OB was told by a patient, “*Don’t you dare cut that before five minutes;*” she explained, “*Okay, it’s not going to pulsate after two minutes.*”

***The C-section rate has stabilized because awareness is out there***

- People don’t understand the impact of the microbiome
- A [study](https://pubmed.ncbi.nlm.nih.gov/37103933/) just came out in *JAMA Surgery* that showed children born by C-section had higher rates of colon cancer before age 50

**Using big data to encourage better practices among doctors: Global Appropriateness Measures**

- This is a consortium of physicians that Marty helped to start with [Dr. Will Bruhn](https://www.linkedin.com/in/will-bruhn-md)
- Their website is [gameasures.com](https://gameasures.com/)
- Dr. Will Bruhn tracks C-sections rates for healthcare organizations and he will say, “*Here’s the 28 doctors at this hospital. Here’s their individual C-section rates as we are pulling from big data…* *doctors shouldn’t be under scrutiny for a 15% versus a 19%, but we use these data as a screening tool.*”
  - If you have a 30% C-section rate in your low-risk deliveries, then that is a screening tool to identify inappropriate concerning patterns that warrant a closer clinical review
  - We can use big data to identify these cases; we can scrub the severe preeclampsia and the twins and all that

***The Global Appropriateness Measures is the only group doing this analysis***

- Using the commercial data and Medicare data, what they do is pull the C-section rate in low-risk deliveries for doctors and send a report showing doctors where they stand on the bell curve

***The data shows that when doctors get a report and see they’re an outlier, they regress toward the mean***

**What’s the reimbursement or the economic differences between a C-section and a vaginal birth?**

- $9,000 versus $7,000
- It’s not an economic decision, it’s other factors, given how difficult the job of being an OB is

**They’re also doing this for other procedures**

- Spine and hardware infusion rate during lumbar spine surgery
  - You’re rate shouldn’t be over 50% in non-deformity cases
- How often a hernia is fixed on both sides
  - It shouldn’t be fixed on both sides more than 20% of the time

> “*We learn the ways in which there’s inappropriate practice patterns and then we profile individual docs for improvement*.”‒ Marty Makary

**What percentage of inguinal hernias are repaired with mesh versus tissue repair?**

- Marty thinks they’re all fixed with mesh except in the famous [Shouldice Clinic](https://www.shouldice.com/) (in Toronto, Canada)
- Marty has a minor hernia and he might go there someday if it ever becomes a problem
- One of the things Peter took away from residency was how difficult a tissue repair is, technically
  - He still doesn’t understand the anatomy
- Secondly, how much better it was if the tissue was sound
- Yet, they didn’t do many tissue repairs; pretty much everybody uses mesh
- The mesh now is so lightweight; they’re like a little thin net
- If Marty could do it as well as the Shouldice Clinic, he would

***If you want to get a tissue repair of an inguinal hernia, you got to go to the Shouldice Clinic, but mesh is less intrusive now and there’s less downside to using mesh than there used to be***

## Rethinking ovarian cancer: recent data challenging decades of medical practice and leading to new preventive measures [1:05:30]

- Marty’s research team at Johns Hopkins is dedicated to studying the big issues in healthcare that we are not talking about, that we should be talking about
  - Where research is taking off
  - New science is pointing to things that’s not given lot of attention or NIH dollars
- One of those areas is the true origin of ovarian cancer

**Anatomy of the female reproductive system**

![](https://peterattiamd.com/wp-content/uploads/2024/09/f3-martymakary3.png)

**Figure 3. Anatomy of the female reproductive system**. Image credit: [NCI](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/fallopian-tube)

- The ovary sits draped under the fallopian tube [aka the uterine tube] and the end of the fallopian tube has finger-like projections called the [fimbriae](https://en.wikipedia.org/wiki/Fallopian_tube) [shown in the figure below]
  - We’re talking like a millimeter; they’re almost in contact [with the ovary]

![](https://peterattiamd.com/wp-content/uploads/2024/09/f4-martymakary3.png)

**Figure 4. Female reproductive system: fimbriae at the end of the uterine/fallopian tube**. Image credit: [OpenStax Anatomy and Physiology](https://openstax.org/books/anatomy-and-physiology-2e/pages/27-2-anatomy-and-physiology-of-the-ovarian-reproductive-system)

- It used to be thought that the only purpose of the ovary was to produce sex hormones, but it’s not true
- It produces the eggs that go down through the fallopian tube into the uterus
- Doctors have really struggled with ovarian cancer, really no major progress [has been made] in modern medicine
  - Most of the cases are lethal or present in late stages
  - There’s almost nothing you can do; very little surgical intervention
  - There are some cases where it’s early enough, but overall, the fatality rate is over 50%
- There’s a strong association between certain types of breast cancer and ovarian cancer [[*BRCA* mutation](https://en.wikipedia.org/wiki/BRCA_mutation)]; there’s a hereditary predisposition
- A big [study](https://pubmed.ncbi.nlm.nih.gov/33991479/) was just done in the UK looking at screening tests for ovarian cancer, and none were shown to improve outcomes ‒ total failure
  - Using ultrasound or CAT scans

***They abandoned the entire idea of ovarian cancer screening based on this big UK study; here we are with a cancer with almost no advances where a ton of money has been spent***

> “*I love this blind spot of medicine because it shows how when you’re certain of something in medicine, you can still benefit from challenging deeply held assumptions.*”‒ Marty Makary

**A recent discovery shows that ovarian cancer does not come from the ovary**

- The most common and lethal type comes from the fallopian tube and the cells float onto the ovary
- We have taken out millions of healthy ovaries to prevent ovarian cancer during abdominal surgery, during a hysterectomy
- Turns out we were targeting the wrong organ
- This discovery is based on genetics and research from [Dr. Drapkin](https://www.med.upenn.edu/apps/faculty/index.php/g275/p8790102) at Penn Medicine, a guy at Johns Hopkins, and a gynecological oncologist where her career focus is to increase public awareness about this

***The vast majority of ovarian cancer patients are actually fallopian tube cancer, and we can prevent it because the fallopian tube serves no function after a woman’s childbearing years***

- Even after menopause, there’s low levels of estrogen that can trickle out of the ovary for a while
- After a woman’s done having kids, if they want to have their tubes tied, at Johns Hopkins they remove the fallopian tubes

***Removing the fallopian tubes massively reduces your 1 in 78 lifetime-chance of developing ovarian cancer***

- Peter think’s lifetime-chance is high (Marty had the same reaction)

**We don’t think like that in clinical medicine**

- At the Pancreas Cancer Conference, a patient once asked what her lifetime chance of developing pancreatic cancer is
- The experts didn’t know
- Marty looked it up: it’s 1 in 67 (for pancreatic adeno lethal cancer)
  - It’s something like the 4th most common lethal GI cancer
  - 5th most common lethal cancer full stop (not GI)
  - #1 is lung, #2 is breast and prostate, then colon, then pancreas
  - Breast is only over pancreas because it’s almost exclusively women, whereas pancreas is men and women, but it’s about 40,000 for both breast and pancreas cancer
- If one has chronic pancreatitis, relative risk increases 28%
- The risk of ovarian cancer is high (at 1 in 78); it’s the most common GYN cause of death

**How widely accepted is it today that ovarian cancer is a misnomer?**

- In the vast majority of these cancers, it’s fallopian tube cancer
- Although you can have other types of gonadal tumors that are much more benign that arise out of the ovaries
- Women who die from ovarian cancer die from where it spreads to

*Why did it take pathologists so long to figure this out?*

***Because of medical group think***

- Marty interviewed the scientists involved in this discovery
- The resistance they encountered was the same old story as experienced by people who challenged the low-fat diet, opioids are not addictive, HRT, and all this other stuff
- At UCSD, San Diego, a pathologist there wrote a very [bold essay](https://pubmed.ncbi.nlm.nih.gov/10053122/) in one of the medical journals where he said, “*I’m telling you that cells we’re looking at do not look like ovarian cancers. These ovarian cancer cells, they don’t look like ovarian cells.*”
  - He got attacked, just got destroyed like the *H. pylori* causes ulcer [guy](https://en.wikipedia.org/wiki/Barry_Marshall)
- His courageous step actually led some researchers in the Netherlands to explore this, and they affirmed him (this was 15 years ago)
- [Ronny Drapkin](https://www.med.upenn.edu/apps/faculty/index.php/g275/p8790102) and [Chris Crum](https://www.dfhcc.harvard.edu/insider/member-detail?tx_hcc_persondetail%5Baction%5D=show&tx_hcc_persondetail%5Bcontroller%5D=Person&tx_hcc_persondetail%5Bperson%5D=343&cHash=97548dff77e68c9ef07893e08e5b8a9b) explained, “*When everyone’s laughing at an idea in science, that’s a signal you should look into it. Your curiosity should kick in*.”
- Peter adds, “*I want to keep coming back to: maybe 19 out of the 20 things that we laugh at, we should be laughing at. I mean, this is the thing, I just want to make sure we’re not giving people a license to assume that every dumb idea is right. Most dumb ideas end up being dumb and wrong.*”

**The challenge is the signal-to-noise ratio is still incredibly low**

- The examples that are most remarkable always looked a little foolish at the outset, but we want to make sure people understand that just having a crazy idea is not sufficient
- You have to have a means of stating what a hypothesis is, determining how to test that hypothesis, and above all else, having the ability to update your hypothesis based on new emerging information
- Because again, most crazy ideas end up being wrong (Marty agrees)

**Where are we right now in terms of rolling this insight out into broader oncologic care?**

- Marty explained that at Hopkins, if a woman wants to get a tubal ligation (tying of the fallopian tubes), she is told they will take out her fallopian tubes to make sure she never gets cancer
  - Massively reduce the risk

*How ubiquitous is the acceptance of this and is there any uncertainty that remains here or is this basically now a* [*fait accompli*](https://www.merriam-webster.com/dictionary/fait%20accompli) *as far as our understanding of that physiology?*

- There is uncertainty because we are early in something like this
- It is now standard of care in Germany and most of Canada that when a woman comes in for any abdominal surgery, elective abdominal surgery
- Even a [lap chole](https://en.wikipedia.org/wiki/Cholecystectomy#Laparoscopic_surgery) (taking the gallbladder out; this is very common)
  - Marty is doing this now in his practice ‒ [Rebecca Stone](https://clinicalconnection.hopkinsmedicine.org/participant/rebecca-stone-md-ms#:~:text=Dr.,well%20as%20gestational%20trophoblastic%20disease.) who is the GYN oncologist at Johns Hopkins comes in and does the [salpingectomy](https://en.wikipedia.org/wiki/Salpingectomy)

**What is the probability of taking out the fallopian tube and damaging an ovary such that a woman ultimately needs an oophorectomy as well?**

- This would be a disaster, an absolute disaster for a woman to lose her ovaries if she’s premenopausal and still relying on those for hormones

***This is a big unknown and the single reason why this is not a broad recommendation for any woman to just come in for a fallopian tube removal***

- It is only offered as a concomitant procedure
- OBs are very good at this
- They say it’s a simple procedure, but but here’s the issue if you make a broad recommendation: what if 1 in 20 surgeons has a complication rate of 5%
  - You’ve canceled out all the public health benefit of reducing ovarian cancer
- That’s why this is a recommendation that not even all of the surgeons at Hopkins are aware of
- The **current recommendation** for removal of the fallopian tubes is for women having another elective abdominal procedure who are done having children
  - Generally on the younger side and not over 67 (which is the average age for ovarian cancer)
  - After age 67, your benefit diminishes
- In Canada, they’ve done [giant studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8829665/) showing lower rates of ovarian cancer long-term
- The pathologist, [Dr. Velculescu](https://profiles.hopkinsmedicine.org/provider/victor-e-velculescu/2777442) at Johns Hopkins has actually said, “*Marty, we haven’t made progress with chemotherapy on ovarian cancer, and maybe this is why. We may have been targeting the wrong type of organ tissue.*”
  - So it’s pretty interesting
- It’s an opportunity for people to be aware of this best practice out there
- Like the guy who needs to see 3 randomized controlled trials to do the non-operative protocol for appendicitis; it’s going to take time
- Only some doctors in the United States outside of GYN are doing this
- The American Academy of OB-GYN has actually put out a [statement](https://www.acog.org/clinical/clinical-guidance/committee-opinion/articles/2019/04/opportunistic-salpingectomy-as-a-strategy-for-epithelial-ovarian-cancer-prevention) recommending women who come in after they’ve done having kids

***There’s a national guideline on it, but it takes a long time for people to learn the best practice***

- Marty hopes it can address the incidence of ovarian cancer; in his mind, it’s in the bucket of “challenging certainty”
  - If you’re 100% certain that this cancer must come from the ovary, be open-minded to the fact that hey, there’s some things here that we haven’t understood in the past

**Possible mechanisms behind the protective effect of removing fallopian tubes**

- Maybe it’s blocking off some of the cells that could have have caused cancer and migrated down
- Maybe it’s killed off some of the lining
- There’s an understanding that ovarian cancer is more likely to be discovered after it’s spread
  - There’s a little gap between the fallopian tube and the ovary
  - Maybe it disseminates in the early stages because of that gap

## Navigating uncertainty as a physician [1:19:30]

- You’re a doctor and you have 99% certainty that this cancer is coming from the ovaries, and everything you do in your practice is predicated around that, but now you have to work with a 0.1% probability that everything you believe about this is wrong
  - Which means you’re a good doctor because you don’t have 100% certainty in anything
  - That’s a really low number: a 1 in 1,000 delta

**How do you not squash that and allow that to remain open and flexible while you continue to do your best work here and periodically come back to revisit this?**

- Assuming you’re not even the one who’s doing the primary work, but you’re just trying to keep up-to-date on your practice
- You say, “*Well, maybe that’s now a 1% chance;*” at some point if that’s a 10% chance, “*I really need to pay attention.*”

> “*If there’s a 10% chance I’m wrong, I really need to pay attention to this. I need to pause. We’re not trained to do that.*”‒ Peter Attia

**How do we go about thinking about this in medical education?**

- Peter doesn’t know enough about medical education today
- It’s been 25 years for him, but Marty is closer to it because he’s still part of a university system

*Is medical education significantly different today when it comes to this? How does a medical education today at Hopkins differ from what it was 25 years ago?*

> “*One of the most important qualities of a physician is humility, knowing your limits and having the self-awareness that you could be wrong*.”‒ Marty Makary

- When it’s clear that you might be wrong, you feel bad about it and you tell the patient, “*Hey, we got this wrong. I thought this is the best way to approach it.*”
- You don’t tell patients, “*You need to have your fallopian tubes out.*”
- Marty admires what his colleague [Rebecca Stone](https://clinicalconnection.hopkinsmedicine.org/participant/rebecca-stone-md-ms#:~:text=Dr.,well%20as%20gestational%20trophoblastic%20disease.) says, “*We have some data that is suggesting that if we take the fallopian tube out, we can reduce your risk of ovarian cancer significantly.*”

***The danger in medicine, one of the poisons today is the absolutism that’s out there***

## The urgent need for reform in medical education [1:21:45]

- Marty explains, “*When we go through medical school, you’re just memorizing and regurgitating and it’s this terrible robotic dogmatic training.*”
  - It’s still that way; you might even say it’s worse
- Marty was talking this morning to a friend he’s working with on the appropriateness work ([Dr. Will Bruhn](https://gameasures.com/about-us)) about all the useless, dumb rote memorization
  - He just graduated from Oklahoma University School of Medicine
  - He said this was about 50% of his medical education
  - For example, this bacteria is catalase positive, this is a branch-chain bacteria, this is a straight chain, memorizing the names of enzymes
- Marty asks, “*What are we doing to these kids? They come to us in medical school, bright, creative, altruistic. They want to do good.*”
- Social justice is a generational value

***We beat them with the rote memorization of these enzymes and stuff you can look up***

- We have phones nowadays; you don’t have to know the [Krebs cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle) on demand in the trauma bay
- We do this to this incredible generation
  - We spit them out 7-8 years later
  - They’re different people; they’re robotic
  - They’re sometimes emotionally disconnected
  - They’ve learned a reflex as a survival mechanism in order to do what we tell them to do, which is get through the exams
- A lot of students, they see the tension; they feel it; they hate it; they’re fighting it

***We do have incredible students that are able to stay normal through the process, but it’s a struggle because the culture of medicine says obey***

**One private company controls medical education in every medical school in America: the** [**AAMC**](https://www.aamc.org/about-us/mission-areas/medical-education)

- A small group of people get to decide what every doctor learns in their medical education, and these people are dinosaurs
- They collect a lot of money from these students
- They’re forcing these kids to memorize the names of all these…

Peter asks, “*What’s the relationship between the AAMC and the company that administers the USMLE and the accreditation? Are they linked in some way?*”

- The [USMLE](https://www.usmle.org/) is the licensing exam and it is regulated by the AAMC (a private organization)

**Marty gets to talk to a lot of people and gets a birds-eye view on things**

- Marty was talking at a conference of medical school deans and met the dean of the medical school in San Antonio, [University of the Incarnate Word (UIW)](https://osteopathic-medicine.uiw.edu/about-us/)
- She agreed, “*Why do we have to teach all this rote memorization and just beat them to regurgitate? I would love to teach self-awareness and understanding uncertainty and focus on applied statistics and the critical appraisal of research and the fact that there are nerves that extend to every aspect of the hand without having to name 50 nerves in the hand, regurgitate on the exam. I would love to have a modern day education, but I can’t because the AAMC dictates what we teach and we have to teach to a test in our test score pass rate.*”

***It’s a terrible system and it’s connected to the*** [***American Board of Medical Specialtie***](https://www.abms.org/)***s, which issues board certification***

- They’ve recently required a $200-300 payment every 2 years or so to take a quiz to maintain board certification
  - They’re making a ton of money off this new thing
  - They’re a private organization, a monopoly
- Imagine if your college called you and said, “*Hey, your degree, you don’t have it anymore. You got to pay us every year to keep your degree.*”
  - *That’s what the American Board of Medical Specialities is doing*
- Marty’s buddy [Will](https://gameasures.com/about-us) told him that at Oklahoma University School of Medicine you have to complete 8 hours on transgender sensitivity and 2 hours on nutrition
  - Those 2 hours on nutrition were so pathetic, it might’ve been better to have zero hours

***There is an awareness among a generation of doctors and students, they know it isn’t right to just be memorizing; something is missing***

**Doctors want to think differently**

- They’re smart
- You’ve got a huge number of people, doctors learning from this podcast
- They’re hungry for this honesty with where medicine is going

*Questions they’re asking*

- Maybe we should be talking about more chronic diseases differently
- Maybe we should be talking more about treating diabetes with cooking classes than just throwing insulin at people
- Maybe we should talk about school lunch programs, not just putting kids on [Ozempic](https://en.wikipedia.org/wiki/Semaglutide)
- Maybe we should talk about sleep medicine when we treat high blood pressure, not just throwing antihypertensives at people, first line, second line, third line
- Maybe we should talk about ice in physical therapy instead of just surgery and opioids when somebody comes in with pain
- Food is medicine
- The microbiome, general body inflammation

***These are the topics that a generation of doctors are starving to talk about, and we need more research in them***

## The major barriers to innovative medical research [1:27:30]

**Who will fund this research?**

- When Peter talks about the pillars of medicine (5 things): nutrition, exercise, sleep, emotional health, and then molecules
  - You could really add a 6th pillar, which would be a waste bucket of everything else that may or may not have benefit: sauna, cold plunge, red light therapy, all that stuff
- Only one of those buckets is really taught well in medical school: you learn about procedures and medications very well
- We learn nothing about exercise, sleep, nutrition, and emotional health and wellbeing
- Part of that is when it comes to molecules and procedures, the way to study it is straightforward, the interventions are easy
  - You take this pill or you don’t
- On top of that, there’s a financial engine that justifies the cost of the studies
- When it comes to doing research on many of these other things outside of philanthropic and government causes (such as the NIH), it’s very difficult to get any of that research funded

*How would we create a new medicine around something for which it would be so difficult to really gather the right evidence, or would you argue, look, we already know enough today that we could teach off the current practice?*

- Marty thinks the NIH could not be more broken
- They’ve got these siloed funding centers to fund what the old belts and suspenders professors want to fund (kidney and cardiovascular disease)
  - It’s a legacy system where if the senior guys who’ve done the research and made a name for themselves on an idea like it, they throw money your way

*A disruption is happening right now*

- You’re seeing private industry fund research on different probiotics and bacteria you can introduce
- They funded our research on price gouging and predatory billing and other big blind spot in medicine

***A lot of Marty’s work is not funded by the NIH***

- People think a lot of what he says makes sense and they ask, “*Why don’t we have a big study on natural immunity and we could draw the blood of these people?*”

***A lot of studies need to be done but don’t fall in with with the NIH silos***

- A classic example of where studies are needed is a practice that is surging now in the US: taking a newborn and [cutting the frenulum](https://en.wikipedia.org/wiki/Frenectomy) under their tongue [to correct a tongue-tie]
- Some people believe this should be done routinely, other people believe it should only be done on a foreshortened tongue, other people believe it should never be done
- The claim is that it’ll improve breastfeeding and lactation rates
  - There’s been babies that don’t breastfeed because they’re in pain from this
- Some claim that it may help with sleep apnea, speech impediments (Marty thinks these are outrageous claims)
- It’s driven a lot in dentistry
- It’s in the lactation world
- Some people who are also cutting the frenulum under the upper inside lip and sometimes the side of the tongue and the frenulum under the tongue

***It’s this dogma that has never had any scientific evidence to support the claim***

Peter asks, “*Is it being tested?*”

- No
- This desperately needs a randomized controlled trial just like the peanut allergy study, just like the antibiotic study
- Do it in a cohort of a couple hundred randomization, and follow them for 5 years or so

*Who’s going to fund that study?*

- Not big pharma
- Not at one of the NIH clinical centers
- Not the American Academy of Pediatrics

> “*This is the Bermuda Triangle of healthcare in the United States and worldwide*.”‒ Marty Makary

***We desperately need to fund things where there are ideas, people are doing things, and they’re doing them in a black hole with no scientific evidence.***

- We need to do the appropriate study
- We could answer the controversy in less than a year

**We saw this during COVID**

- Marty hates to mention COVID
- All those COVID controversies could have been answered in 3 weeks or a month or two
  - We could have done the clinical study, immediately done the randomization, answered the question
- Instead everyone went on TV and opined about it (it’s easier)

**The NIH controls $80 billion. What are they funding?**

- They were funding this cruel dog experiment at the University of Iowa, trapping these dogs, and having these sand flies bite their heads in these cages, and concluding in the article that is published, Leishmaniasis can spread from dog to dog via sand fly bites
- Marty asks, “*Who gives a shit?*”
- This is where our tax dollars are going

***We’re not funding basic clinical research***

Peter asks, “*Why do you think that is?*”

- It’s not diabolical
- People get set in their ways
- It’s Leon Festinger’s cognitive dissonance
- Marty sees this a lot with health equity ‒ describing disparities in health equity, is not interesting at all
  - We know there are massive disparities in health equity
- What’s interesting is what you’re doing to reduce disparities in health equity
- Yet half of papers are on differences in so-and-so by race and socioeconomic status
- Marty explains, “*It’s been known since the beginning of time, the #1 driver of health status overall in a population is the socioeconomic status of that community*.”

*Maybe it’s intellectual laziness, the old guard*

- There are fresh ideas in medicine
- But when you show up in the academic world as a resident or a student with a big idea, you’re told, “*No, no, you need to pick one narrow area and work on an incremental little scientific paper.*”

***That’s how the NIH funds their research: little, small ideas***

- The NIH doesn’t fund big ideas
- We need new ideas on cancer
- What’s the “ROI” on our cancer funding?
  - A paper at [ASCO](https://www.asco.org/) showed that [Avastin](https://en.wikipedia.org/wiki/Bevacizumab) increased [glioblastoma](https://en.wikipedia.org/wiki/Glioblastoma) survival rates by 2 months
- Patients want to know what’s the cure? Did you cure anyone else that you haven’t cured before?

***If that’s the top paper at ASCO, our investment on research has a terrible R0I, and Marty thinks it’s because we’re not funding big ideas***

**We need Ben Franklin thinkers**

- [Ben Franklin](https://en.wikipedia.org/wiki/Benjamin_Franklin), intellectually curious, starts thinking about ophthalmology, invents bifocals
  - Is interested in electricity, invents the lightning rod
  - Invents a stove called the Pennsylvania stove
- We don’t have Ben Franklin thinkers today in medicine
- Marty thinks [Vinay Prasad](https://vinayakkprasad.com/) is one
- Peter is one, he broadly thinks about healthcare

Peter asks, “*You think we don’t have them or you think we don’t have a vehicle to fund them?*”

- We don’t have a vehicle to encourage them
- Today in med school you’re told to pick one organ to focus on
- If you ask, “*What if I’m interested in the whole body, or the system, or the way we deliver care, or the way we fund research, or approve drugs, or what if I’m interested in all of it? What if I’m interested in gun control, and violence prevention, and I’m interested in trauma, and everything?*” you’re told, “*No, no. Stop thinking like that. You got to pick an organ.*”

**Many doctors want something more meaningful**

- Doctors are starting their own businesses
- 50% of medical students at Johns Hopkins are getting a second degree with their medical degree
  - They don’t want to live the life they see of the guys who have 4 NIH grants and 60 papers
- Marty hit that point where he was like, “*Okay, I’ve published 300 scientific peer review articles. Nobody’s reading them. I don’t think I’ve made beyond maybe a couple meaningful contributions. What are we doing? We’ve got to focus on impact.*”

> “*Everything we do now in our research group focuses on impact, and that’s how we got into the science of medical errors, frailty as a condition, predatory billing, and price gouging in medicine.*”‒ Marty Makary

**Rebuilding trust is the hottest topic right now in medical journals**

- 62% of Americans say in a Harvard survey, they don’t trust the medical profession to bill them fairly and they avoid care or delay it for fear of the bill
- You can now have the cure for pancreas cancer, but that cure instead of being 100% effective, it’s only 38% effective because you’ve lost that connection

## The dogmatic culture of academic medicine: why humility and challenging established norms is key for progress [1:38:15]

**In 2020,** ***The New England Journal of Medicine*** **endorsed a candidate for presidency**

- This is the most esteemed journal in all of medicine, and for 208 years it was decidedly apolitical but it chose to break that

*Why do you think that’s a bad idea?*

- There is a political narrative and in politics everyone sticks to the same talking points
- Science is based on a civil discourse of different ideas among experts, and so they’re directly in conflict
- The journal decided to endorse a presidential candidate for the first time
- Other journals have said, “*Here are some issues we’re not going to be bothsidesing*.”
- Okay, well what if you said that about peanut allergies back in the days?
- What if you said that about people who are suggesting opioids are very addictive?
- They’ve seen it ‒ *The New England Journal of Medicine* is the place that published that [study](https://www.nejm.org/doi/pdf/10.1056/NEJM198001103020221) that out of 30,000 cases of people taking narcotics, there was only 1 patient who developed dependence, and that became the dogma

***And dogma takes on a life of its own***

**Marty thinks the journals are in a bubble**

- Just like we need term limits for politicians, just like presidents should turn over after 8 years, journal editors should not serve terms like monarchs in Europe or African presidents
  - They’re there for life and it’s, they’re loading these journal editorial boards with their buddies (it’s cronyism)
- It’s hard to criticize because we all need the journals to publish our research
- Just a couple years ago, *The New England Journal of Medicine*, out of 51 editors had 1 African-American
- What’s going on is it’s their buddies from the Brigham and Women’s Hospital, and Beth Israel Deaconess, and Mass General
- And so you have all these internal medicine doctors who look alike, think alike, they’re buddies from one institution and from one part of the country deciding what should go through the gates for the rest of the doctors of the world to see

**It’s changing**

- [Vinay Prasad](https://vinayakkprasad.com/), and [John Mandrola](https://www.linkedin.com/in/john-mandrola-12427a18/), and [Adam Cifu](https://www.adamcifu.com/), and Marty, and some others started a new news feed called [*Sensible Medicine*](https://www.sensible-med.com/)
- They’re publishing their thoughts in real time when they see articles that look flawed, when there’s a bandwagon effect ‒ they call things out
- They have 100,000 subscribers to this thing now
- They’re starting a new journal which is designed to be objective, and it’s called the *Journal of the Academy of Public Health*
  - [Jay Bhattacharya](https://healthpolicy.fsi.stanford.edu/people/jay_bhattacharya), and [Martin Kulldorff](https://dc.hillsdale.edu/Academy-for-Science-and-Freedom/Martin-Kulldorf/), and Marty, and a bunch of others

**How do you know you won’t fall into the same trap of** ***The New England Journal of Medicine*****?**

- Peter points out that the biggest journals in the world became political in 2020
  - They made a very concerted conscious decision to weigh in on politics, to endorse presidential candidates
- He doesn’t think it matters who they’re endorsing or what party you’re in
- He’s amazed that more people don’t look at that and say, “*Oh no, that is awful. That is awful. We cannot have science and politics. We can’t have those things commingle*.”
  - There’s an objectivity that can’t be commingled there
- Marty agrees

***Peter doesn’t have a sense of what the answer is here because he still doesn’t understand systemically what’s going on***

**Is the goal of that to be a little bit more provocative in the other direction, even if it’s deliberately provocative, but careful not to create disagreement for the sake of disagreement?**

- That’s right
- Marty explains, “*We are prone to the same bandwagon groupthink as the JAMA, New England Journal editors that are a bunch of like-minded friends. We are at risk of that and we have to be constantly aware of it*.”

*In “*[*Sensible Medicine*](https://www.sensible-med.com/about)*”*

- We’ve invited people who disagree
- We love publishing pro-con articles on the same issue, the same topic
  - You’ll see: Vinay Prasad is wrong, Adam Cifu is wrong on this topic
  - They’re sparring in the spirit that we should have in academics
- Remember when [Obama](https://en.wikipedia.org/wiki/Barack_Obama) first ran for president, he was asked, “*What is your favorite book?*”
  - He said, [*Team of Rivals*](https://www.amazon.com/Team-Rivals-Political-Abraham-Lincoln/dp/0684824906/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.aCiphqjkgAv6Tjit7usvD2LHcj42DaRvSLlt2wpicVQCYqrTvcRJ8hgHXzZfCM3CkCcgcT6H6thtNqBd9hGztIR4I3MU7pw-RSduIOjV5o6du2oCTb5bsfZxJdqraJNCf2J2a1y_Igt3BXMFOcm7diaWc9WI_4OJ8wktIHJ__DherikAoKJya6Z4WZyjOqteyYQN3cd7uRGvcdL7Xx6G_SkHpOyFPsoNEKcUxE36e9M.PBHW1vPjXHKuLVzYFHvqEzUA6OXoLxFmO0h48yHNyTo&qid=1725382373&sr=8-1)
  - It’s about how [Lincoln](https://en.wikipedia.org/wiki/Abraham_Lincoln) brought together all these different opinions
    - He wanted them on his cabinet
    - He wanted to moderate a civil discourse
    - It wasn’t just different opinions; Lincoln’s cabinet was composed of the people who had attacked him and run against him during the election

> “*We need to stay humble, avoid celebrity worship in medicine*” ‒ Marty Makary

**Academic medicine**

- The greatest, highest attainable achievement you can have as a physician, is to be the chief of a department
  - This is what dominates in the culture of academics

Peter asks, “*But what percentage of physicians today are academic physicians versus community physicians?*”

- Maybe 10% of physicians fall into the bucket of academic physicians
  - What is defined as an academic center nowadays is blurring with the acquisitions and mergers
  - If we define it as people who have some funding for research and/or are involved in education of students and residents
- But they control a lot of the gain

**How much do community physicians look to academic physicians?**

- Most people listening are going to get the bulk of their medical care from people who are not academic physicians
- Therefore, the most important thing in delivering exceptional care to the majority of people is making sure that community-based physicians are able to think independently or able to think clearly
- Peter doesn’t know if the answer lies in the hierarchy of the academic institution
  - He doesn’t know that is really where the problem is
  - He doesn’t think it’s where 5-10% of the attention lies
  - Marty doesn’t disagree
- Being in the ivory tower, the top of Hopkins, Marty has a skewed perspective, but every doctor gets trained in an academic medical school
- Every student comes through this culture where we tell them it’s a privilege to hold a retractor for 6 hours instead of, “*Come and watch me talk to a patient’s family afterwards and learn self-awareness and how to be perceptive and empathetic.*”
- Marty doesn’t have a solution

**We are moving more in the direction of everybody ‘get in line’ than we are in the freedom of the rank-and-file doctor in America to speak how they would speak creatively**

- For example, Marty will ask a doctor what he thinks about hormone replacement therapy postmenopausal
  - Someone will say, “*Well, I’ve heard this, but I tend to question that. I know some people are saying this. I’m not sure*.” (that’s a good doctor)
  - A doctor who says, “*According to this U.S. Preventive Service Task Force, you must do this.*”
    - You’re reciting a catechism
    - That’s not the doctor that we want to create

*How do you teach humility?*

- [John Cameron](https://pathology.jhu.edu/pancreas/our-team/john-cameron) and Marty did this thing when they operated next door to each other, Marty would pause and say, “*This is a really interesting scenario. Can the scrub nurse run over or the tech run over and get Dr. Cameron to take a look at this?*”
  - And he’d come in and he’d say, “*Ah, this is really interesting Marty. In the past, I’ve done it this way or that way.*”

***Marty knows exactly what he’s going to say, but he wants to model humility to the students and residents in the room ‒ that’s one way to teach humility, but it’s an uphill battle***

**The policing right now in modern medicine is at an all-time high**

- Marty gave grand rounds for the OB-GYN department at Hopkins
- It went great, they helped him shape some of these ideas and research that he’s worked on (and discussed earlier)
- When Marty filled out the CME form, he’s coined this ICD-9 diagnosis code called, “*Send us your slides in advance harassment syndrome*.”
  - It starts off in the hallway with, “*Hey Peter, would you be interested in giving us a talk sometime?*” “*Yeah, sure*.”
  - Then the harassment, and the email, and we need you to fill out these forms, and write four questions for our CME, and send us your slides
  - We have to have your slides
  - Marty replies, “*No, you don’t have to have my slides. I’m going to work in current events from that morning of my talk*.” (the kryptonite for the send us your slides in harassment syndrome)
  - Then you show up with a thumb drive of your presentation
- Filling out this CME (continuing medical education) requirement for any time you give grand rounds was, “*I hereby agree that everything I say will comply with generally accepted norms and standards recognized by consensus within the medical profession*.”
- Marty felt strongly opposed to this
- He likes to cite research that challenges deeply held assumptions
- He was not going to sign some catechism that says, “*Yes, I will obey and only say things that are in line with consensus.”*

**Marty’s point is**

- If you look at our track record in modern medicine, when we use good scientific studies, before we make massive health recommendations, peanut allergies, whatever, when we have good science, we shine as a profession
- When we wing it, when an elite small group of medical establishment folks decide what the world is going to do based on their own gut feeling or dogma, they have a lousy track record

## The major successes and ongoing challenges of modern medicine [1:51:00]

**What do you think medicine has done the best job of in the last decade?**

- There have been some really big wins here that don’t get maybe as much attention as they deserve
- Cardiac surgical care, line infections in hospitals
- Obstetrical care ‒ the infant mortality rate is good as modern medicine can deliver it
  - We’ve now accepted these new best practices of skin to skin time, delayed cord clamping, encouraging breastfeeding early on, reducing C-sections when not necessary
  - These best practices have been implemented in the last 10 years
- We’re pretty good at a lot of acute care
- Marty recalls a video he saw on social media where a guy said, “*If I get shot, I want to go to a US hospital. We have the best care in the world. If I break a bone, I’m going to go straight to a doctor. But when it comes to telling me what I should be eating or how to live my life, I don’t think I trust modern medicine.*”
- If you come in with chronic abdominal pain, sometimes our sophisticated system doesn’t know what to do

***Acute care has been mastered***

- Marty thinks about the operations he was a part of: [laparoscopic whipples](https://en.wikipedia.org/wiki/Pancreaticoduodenectomy), it’s a tour de force of science and technology and advancements
- We do something called a pancreas transplant with islet cells now for people with chronic pain

**Good stuff is happening; we have good people going into medicine and nursing**

> “*People go into medicine, nursing, every aspect of healthcare united by one common thing, and that is everybody wants to help other people who are in need.*”‒ Marty Makary

- It’s an incredible bond
- It’s a profession we should all be proud of
- Marty’s dad shared little tips, ways to connect with patients. “*Don’t  ask somebody, are you taking your medication? Instead, say, some people find it hard to take their medications as prescribed. How are you doing with it?*” (it’s far less head to head)

***It’s the best job in the world, teaching these little pearls and gems, citing research, calling out the importance of good scientific methodology***

- Medical centers are still some of the most respected institutions in America
- Which is why we’ve called on them to have ethical billing and pricing practices
  - But we can correct course

**Marty would encourage anyone to get into medicine**

- Where else can you put a knife to someone’s skin within seconds of meeting them, just because you’re the doctor?
- People will tell you secrets they’ve never told their spouse within minutes of meeting you because you’re the doctor
- There’s an incredible heritage in the profession

*You’ve got to be okay with memorizing enzyme names over and over again (hundreds of names of molecules you could look up on Google)*

- Peter thinks the bigger issue is not that you have to memorize those names, it’s that you’re lacking the context and why
- Peter still memorizes the names of complex enzymes and pathways, but the difference is I’m doing it because it’s feeding his interest
- He’s reading papers, learning new things; he has to draw diagrams ‒ he’s doing the same thing he was 25 years ago
- He doesn’t want to suggest that it’s not important to have knowledge

***It’s easier to know it when you have the scaffolding around why***

- Peter can’t tell you every step of the Krebs cycle, but he still remembers in great detail how metabolism works because it really matters to what he does

**Peter hopes that medical education can major in the major and minor in the minor because it matters that you understand these things**

- Why the Krebs cycle matters
- Why when the Krebs cycle isn’t working, every disease in the body gets worse
- Why is it that a person with cardiovascular disease, type 2 diabetes, Alzheimer’s disease, why do they have defective Krebs cycle?
- That’s what he wants medical students to be understanding and learning

**If you were to ask Peter if he would do it all over again and go into medicine**

- The answer is undoubtedly yes
- He also realizes there are a lot of other exciting fields in the world today that maybe weren’t available to him

*About surgical residency*

- Knowing what Peter knows today and where he ended up, he would have been better off doing an internal medicine residency
- But then he wouldn’t know Marty, [Ted Schaeffer](https://www.tedschaeffermd.com/), or a lot of the amazing people that he’s gotten to know through surgical training
- Their surgical training, when you didn’t have regulations on work hours and stuff, it was so hard
- It really gave him an appreciation for how much easier his life is today and how lucky he has it to not be woken up every 14 minutes when he sleeps and things like that

***Peter would probably be reluctant to change anything; it all worked out okay***

- Peter is really grateful for the folks he met along the way
- He agrees with Marty, the one thing that unites all the people working in the medical field is they’re doing it for the right reasons
- Medicine attracts great folks

**Our challenge in the academic towers**

- How can we keep the focus both on the technically sophisticated pieces of metabolism so they understand it, but at the same time not lose sight of the overall person?

***You have to preserve the humanity of the field while harnessing critical thought and doing it around this scaffolding of purpose***

*Classic example: the* [*Pima Indians*](https://pubmed.ncbi.nlm.nih.gov/27111117/) *in New Mexico*

- They had been cut off with their water supply, farmers, ranchers, and settlers
- All of a sudden, this nation of Indians weren’t able to grow crops and the healthy foods they’d been needing for centuries
- The US government, recognizing how they were being depleted of food and the starvation that was happening, they started shipping food
  - This wasn’t whole food stuff
  - This was Spam, and potato chips, or whatever else
- They started developing massively high rates of obesity
- Diabetes quickly ensued
- You had this population that was massively obese and with diabetes
- The NIH decides to swoop in and address this problem by looking for a predisposing gene for obesity and diabetes
- They tested the blood of all these poor Indians
- And it’s like we can’t see the forest from the trees sometimes
  - We’ve been feeding them shit for decades, and that is what’s been driving the obesity and diabetes (it’s not that they have a gene)

§

## Selected Links / Related Material

***New York Times*** **bestselling books by Marty**: [1:15]

- [Unaccountable: What Hospitals Won’t Tell You and How Transparency Can Revolutionize Health Care](https://www.amazon.com/Unaccountable-Hospitals-Transparency-Revolutionize-Health/dp/1608198367/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.ZkiqDaZraR6YHsTFrDsb-F-cC9jtrzD2I9vls2VHGSruX-togrknfjJuZLqWMoBuVljVBolo722HfMvWygize3U1tJEw1bYp799jx7EDPzw-EyczA_jmUOf-LCoUZs78DVzNsociiR1r802g2yZKZFBCu7BfVIB5GEcK-SLp04lw9ZGW5UOd1clM6CGYsZZ0.WywSNj4o0F8sXR0PMeLF-w5PvYb0O01Qkucylr7aihQ&qid=1723636916&sr=8-3) by Marty Makary (2012)
- [The Price We Pay: What Broke American Health Care–and How to Fix It](https://www.amazon.com/Price-We-Pay-American-Care/dp/1635574110/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.ZkiqDaZraR6YHsTFrDsb-F-cC9jtrzD2I9vls2VHGSruX-togrknfjJuZLqWMoBuVljVBolo722HfMvWygize3U1tJEw1bYp799jx7EDPzw-EyczA_jmUOf-LCoUZs78DVzNsociiR1r802g2yZKZFBCu7BfVIB5GEcK-SLp04lw9ZGW5UOd1clM6CGYsZZ0.WywSNj4o0F8sXR0PMeLF-w5PvYb0O01Qkucylr7aihQ&qid=1723636916&sr=8-2) by Marty Makary (2019)

**Marty’s latest book**: [Blind Spots: When Medicine Gets It Wrong, and What It Means for Our Health](https://geni.us/blindspots) by Marty Makary (2024) | [1:15]

**Non-operative treatment for appendicitis**: [9:00]

- [Antibiotic Therapy vs Appendectomy for Treatment of Uncomplicated Acute Appendicitis: The APPAC Randomized Clinical Trial](https://pubmed.ncbi.nlm.nih.gov/26080338/) | *JAMA* (P Salminen, et al. 2015)
- [Five-Year Follow-up of Antibiotic Therapy for Uncomplicated Acute Appendicitis in the APPAC Randomized Clinical Trial](https://pubmed.ncbi.nlm.nih.gov/30264120/) | *JAMA* (P Salminen, et al. 2018)
- [Nonoperative Treatment Versus Appendectomy for Acute Nonperforated Appendicitis in Children: Five-year Follow Up of a Randomized Controlled Pilot Trial](https://pubmed.ncbi.nlm.nih.gov/31800496/) | *Annuals of Surgery* (B Patkove, et al. 2020)
- [A Randomized Trial Comparing Antibiotics with Appendectomy for Appendicitis](https://pubmed.ncbi.nlm.nih.gov/33017106/) | *NEJM* (CODA Collaborative, et al. 2020)
- [Antibiotics versus Appendectomy for Acute Appendicitis – Longer-Term Outcomes](https://pubmed.ncbi.nlm.nih.gov/34694761/) | *NEJM* (CODA Collaborative, et al. 2021)
- [Antibiotics versus placebo in adults with CT-confirmed uncomplicated acute appendicitis (APPAC III): randomized double-blind superiority trial](https://pubmed.ncbi.nlm.nih.gov/35576384/) | *The British Journal of Surgery* (P Salinen, et al. 2022)

**Festinger’s book about cognitive dissonance**: [When Prophecy Fails](https://www.amazon.com/When-Prophecy-Fails-Leon-Festinger/dp/1578988527/ref=tmm_pap_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.IILRhX8coKD7K22mkPIsTRkhLb1rLHv-m8fFzLJ6_uByljAYF9pZET-zVVDGg_qKvcwR4p8Q_0jzLIwc_a7twqE2uV1DG1tDYAETPOGNJCwK9k8qjODjwHuiMvHicLGr3e9gAuAhwm1jQzF3XBZvIIbLw_yN3ViCoKPJ0JPI_jxkKrk29-eOuOtJ9IaMXNas.bf695LWKTA35ZC9nUdZ-n8lPOLeeu_JPZyByezbLDJA&qid=1724074659&sr=8-1) by L Festinger, H Rieken, and S Schachter (1956) | [15:00]

**Prevalence of peanut allergies in the US**: [Prevalence of peanut and tree nut allergy in the US determined by a random digit dial telephone survey](https://pubmed.ncbi.nlm.nih.gov/10200001/) | *The Journal of Allergy and Clinical Immunology* (S Sicherer, et al. 1999) | [18:15]

**RCT of peanut butter exposure in infancy**: [Randomized trial of peanut consumption in infants at risk for peanut allergy](https://pubmed.ncbi.nlm.nih.gov/25705822/) | *NEJM* (G Du Toit, et al 2015) |  [23:45]

**NIAID position paper on preventing peanut allergies**: [Addendum Guidelines for the Prevention of Peanut Allergy in the United States](https://www.niaid.nih.gov/sites/default/files/addendum-peanut-allergy-prevention-guidelines.pdf) | S Cooper 2016 | [24:45]

**Previous content on hormone replacement therapy (HRT)**: [26:15]

- [#253 ‒ Hormone replacement therapy and the Women’s Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT](https://peterattiamd.com/joannmanson/) | JoAnn Manson, M.D. (May 8, 2023)
- [Clearing the air on hormone replacement therapy](https://peterattiamd.com/clearing-the-air-on-hrt/) | PeterAttiaMD.com (K Birkenbach, E Henry, S Lipman, P Attia 2023)

W**omen’s Health Initiative, initial results on HRT cancer risk**: [Risks and Benefits of Estrogen Plus Progestin in Healthy Postmenopausal Women: Principal Results From the Women’s Health Initiative Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/12117397/) | *JAMA* (J Rossouw et al. 2002) | [27:00]

W**omen’s Health Initiative, follow-up results**: [27:15]

- [Estrogen plus progestin and breast cancer incidence and mortality in the Women’s Health Initiative Observational Study](https://pubmed.ncbi.nlm.nih.gov/23543779/) | *Journal of the National Cancer Institute* (R Chlebowski, et al 2013)
- [Association of Menopausal Hormone Therapy With Breast Cancer Incidence and Mortality During Long-term Follow-up of the Women’s Health Initiative Randomized Clinical Trials](https://pubmed.ncbi.nlm.nih.gov/32721007/) | *JAMA* (R Chlebowski, et al. 2020)

**Mayo Clinic study of antibiotics in children 2 and under**: [Association of Infant Antibiotic Exposure With Childhood Health Outcomes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7796951/) | *Mayo Clinic Proceedings* (Z Aversa, et al. 2020) | [40:45]

**Danish study of antibiotic use in children and risk of chronic disease**: [43:00]

- [Use of Antibiotics and Risk of Type 2 Diabetes: A Population-Based Case-Control Study](https://pubmed.ncbi.nlm.nih.gov/26312581/) | *The Journal of Clinical Endocrinology and Metabolism* (K Mikkelsen, et al. 2015)
- [Association Between Antibiotics in the First Year of Life and Celiac Disease](https://pubmed.ncbi.nlm.nih.gov/30836095/) | *Gasteroenterology* (S Sander, et al. 2019)

**Global appropriateness measures**: [54:45]

- [GAM: The gold standard in healthcare appropriateness measurement](https://gameasures.com/) (2024)
- [Clinical Appropriateness Measures Collaborative Project](https://www.ahip.org/resources/clinical-appropriateness-measures-collaborative-project) | AHIP (2021)

**Delayed cord clamping**:[A Randomized Controlled Trial of a 30- versus a 120-Second Delay in Cord Clamping after Term Birth](https://pubmed.ncbi.nlm.nih.gov/35170013/) | *American Journal of Perinatology* (R Soliman, et al. 2024) | [1:00:30]

**Increased risk of colon cancer if born by C-section**: [Evaluation of Birth by Cesarean Delivery and Development of Early-Onset Colorectal Cancer](https://pubmed.ncbi.nlm.nih.gov/37103933/) | *JAMA Network Open* (Y Cao, et al. 2023) | [1:01:15]

**Tissue repair for hernias**: [Shouldice Hernia Hospital](https://www.shouldice.com/) (2024) | [1:04:00]

**UK study of screening tests for ovarian cancer**: [Ovarian cancer population screening and mortality after long-term follow-up in the UK Collaborative Trial of Ovarian Cancer Screening (UKCTOCS): a randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/33991479/) | *The Lancet* (U Menon, et al. 2021) | [1:07:15]

**Essay on the cellular origin of ovarian cancer**: [1:12:15]

- [The cell of origin of ovarian epithelial tumors and the ovarian surface epithelium dogma: does the emperor have no clothes?](https://pubmed.ncbi.nlm.nih.gov/10053122/) | *Gynecologic Oncology* (L Dubeau 1999)
- [The cell of origin of ovarian epithelial tumours](https://pubmed.ncbi.nlm.nih.gov/19038766/) | *The Lancet. Oncology* (L Dubeau 2008)

**Removal of fallopian tubes reduces risk of ovarian cancer**: [Outcomes From Opportunistic Salpingectomy for Ovarian Cancer Prevention](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8829665/) | *JAMA Network Open* (G Hanley, et al. 2022) | [1:17:30]

**ACOG statement on removing fallopian tubes to prevent ovarian cancer**: [Opportunistic Salpingectomy as a Strategy for Epithelial Ovarian Cancer Prevention](https://www.acog.org/clinical/clinical-guidance/committee-opinion/articles/2019/04/opportunistic-salpingectomy-as-a-strategy-for-epithelial-ovarian-cancer-prevention) | *ACOG Clinical* (2019) | [1:18:30]

***Sensible Medicine*** **news feed**: [Sensible Medicine](https://www.sensible-med.com/) (2024) | [1:41:00]

**Barack Obama’s favorite book**: [Team of Rivals: The Political Genius of Abraham Lincoln](https://www.amazon.com/Team-Rivals-Political-Abraham-Lincoln/dp/0684824906/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.aCiphqjkgAv6Tjit7usvD2LHcj42DaRvSLlt2wpicVQCYqrTvcRJ8hgHXzZfCM3CkCcgcT6H6thtNqBd9hGztIR4I3MU7pw-RSduIOjV5o6du2oCTb5bsfZxJdqraJNCf2J2a1y_Igt3BXMFOcm7diaWc9WI_4OJ8wktIHJ__DherikAoKJya6Z4WZyjOqteyYQN3cd7uRGvcdL7Xx6G_SkHpOyFPsoNEKcUxE36e9M.PBHW1vPjXHKuLVzYFHvqEzUA6OXoLxFmO0h48yHNyTo&qid=1725382373&sr=8-1) by Doris Kearns Goodwin (2005) | [1:43:30]

§

## People Mentioned

- [Leon Festinger](https://en.wikipedia.org/wiki/Leon_Festinger) (1919-1989, social psychologist who developed the theory of cognitive dissonance) [4:00]
- [Gideon Lack](https://www.harleystreetpaediatricgroup.com/prof-gideon-lack/) (Head of the Children’s Allergy Service at Guy’s and St Thomas’ NHS Foundation Trust, and Professor of Paediatric Allergy at King’s College London) [20:00]
- [Robert (Bob) Langer](https://profiles.ucsd.edu/robert.langer) (Emeritus Professor of Family Medicine and Public Health at UC San Diego) [26:30]
- [Claude Bernard](https://en.wikipedia.org/wiki/Claude_Bernard) (1813-1878, French physiologist and proponent of the scientific method) [30:00]
- [Patchen Dellinger](http://antimicrobe.org/authors/E_Patchen_Dellinger.asp) (Professor Emeritus of Surgery at [UW Medicine](https://uwsurgery.org/about/faculty/emeritus-faculty/#:~:text=E.%20Patchen%20Dellinger%2C%20MD)) [37:45]
- [Austin Bradford Hill](https://en.wikipedia.org/wiki/Austin_Bradford_Hill) (1897-1991, English epidemiologist who pioneered the [“Bradford Hill” criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) for determining a causal association) [43:45]
- [Martin Blaser](https://cabm.rutgers.edu/person/martin-j-blaser) (Professor of Medicine and Pathology & Laboratory Medicine and Chair of the Human Microbiome at Rutgers University) [45:47]
- [Alexander Fleming](https://en.wikipedia.org/wiki/Alexander_Fleming) (1881-1955, Scottish physician and microbiologist who discovered the first antibiotic) [49:00]
- [Victor Velculescu](https://profiles.hopkinsmedicine.org/provider/victor-e-velculescu/2777442) (Professor of Oncology and Co-Director of Cancer Genetics and Epigenetics Program at Johns Hopkins Kimmel Cancer Center) [1:17:45]
- [Will Bruhn](https://www.linkedin.com/in/will-bruhn-md) (MD, Co-Founder & COO at [Global Appropriateness Measures](https://gameasures.com/about-us)) [1:01:45, 1:22:00, 1:26:00]
- [Ronny Drapkin](https://www.med.upenn.edu/apps/faculty/index.php/g275/p8790102) (Professor of Pathology in Obstetrics & Gynecology at Perelman School of Medicine University of Pennsylvania, expert in ovarian cancer) [1:08:30]
- [Christopher Crum](https://www.dfhcc.harvard.edu/insider/member-detail?tx_hcc_persondetail%5Baction%5D=show&tx_hcc_persondetail%5Bcontroller%5D=Person&tx_hcc_persondetail%5Bperson%5D=343&cHash=97548dff77e68c9ef07893e08e5b8a9b) (Professor of Pathology at Harvard Medical School, Director of Womens and Perinatal Pathology at Brigham and Women’s Hospital) [1:13:15]
- [Rebecca Stone](https://clinicalconnection.hopkinsmedicine.org/participant/rebecca-stone-md-ms#:~:text=Dr.,well%20as%20gestational%20trophoblastic%20disease.) (Associate Professor of Gynecology and Obstetrics at Johns Hopkins Medicine, expert in gynecologic cancers) [1:15:45, 1:21:30]
- [Ben Franklin](https://en.wikipedia.org/wiki/Benjamin_Franklin) (1706-1790, American polymath: a leading writer, scientist, inventor, statesman, diplomat, printer, publisher, and political philosopher; one of the founding fathers of the US) [1:35:15]
- [Vinay Prasad](https://vinayakkprasad.com/) (hematologist-oncologist and Professor of Epidemiology and Biostatistics at UCSF, co-founder and editor of [*Sensible Medicine*](https://www.sensible-med.com/about)) [1:35:30, 1:41:00]
- [John Mandrola](https://www.linkedin.com/in/john-mandrola-12427a18/) (cardiac electrophysiologist practicing in  Louisville, KY, co-founder and editor of [*Sensible Medicine*](https://www.sensible-med.com/about)) [1:41:00]
- [Adam Cifu](https://www.adamcifu.com/) (general internist and Professor of Medicine at the University of Chicago, co-founder and editor of [*Sensible Medicine*](https://www.sensible-med.com/about)) [1:41:00]
- [Jay Bhattacharya](https://healthpolicy.fsi.stanford.edu/people/jay_bhattacharya) (Professor of Health Policy at Stanford University; working with Marty on the *Journal of the Academy of Public Health*) [1:41:30]
- [Martin Kulldorff](https://dc.hillsdale.edu/Academy-for-Science-and-Freedom/Martin-Kulldorf/) (epidemiologist, a biostatistician, and a founding fellow at Hillsdale College’s Academy for Science and Freedom; he was a professor of Medicine at Harvard for 13 years; working with Marty on the *Journal of the Academy of Public Health*) [1:41:30]
- [John Cameron](https://pathology.jhu.edu/pancreas/our-team/john-cameron) (the Alfred Blalock Distinguished Service Professor of Surgery at The Johns Hopkins) [1:49:15]

§

![](https://peterattiamd.com/wp-content/uploads/2019/08/marty-makary-1x1.jpeg)

##### Marty Makary, M.D., M.P.H.

Martin (Marty) Makary is a graduate of Bucknell, he earned a medical degree from Sidney Kimmel Medical College of Thomas Jefferson University and a Master’s in Public Health from Harvard Universities. He completed his surgical residency at Georgetown University and his specialty training at Johns Hopkins Hospital.

Dr. Makary is Professor of Surgery, Chief of Islet Transplant Surgery, and a public policy researcher at Johns Hopkins School of Medicine. He writes for *The Washington Post* and *The Wall Street Journal*. He is also author of two New York Times bestselling books, *Unaccountable* and *The Price We Pay*. Dr. Makary served in leadership at the World Health Organization Patient Safety Program and has been elected to the National Academy of Medicine. He has published over 250 peer-reviewed scientific articles. His current research focuses on the underlying causes of disease, public policy, health care costs, and relationship-based medicine. [[Johns Hopkins Medicine](https://profiles.hopkinsmedicine.org/provider/martin-a-makary/2701414)]

Website: [Marty Makary MD](https://www.martymd.com/)

X: [@MartyMakary](https://x.com/martymakary?lang=en)