# #103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held

**Source:** [https://peterattiamd.com/strong-convictions-loosely-held/](https://peterattiamd.com/strong-convictions-loosely-held/)

---

In this episode, originally recorded to be the 100th episode of The Drive, Peter discusses topics that he has changed his mind about since starting the podcast as a result of preparing for interviews as well as from the actual conversations. Peter also reviews some of his favorite moments from the first 99 episodes, shares what books he’s currently reading, and much more. Initially scheduled to be released as episode 100, this was delayed due to recent podcasts covering COVID-19.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) |

![The Peter Attia Drive](images/strong-convictions-loosely-held/the_Drive_public.png)

Play

#103 - Looking back on the first 99 episodes: Strong Convictions, Loosely Held

#103 - Looking back on the first 99 episodes: Strong Convictions, Loosely Held

1x15s30s

0:001:17:23

## We discuss:

- Definition of “strong convictions loosely held”, and the value in trying to shoot down your own hypotheses [2:20];
- Metformin—How Peter’s strong convictions have changed since 2018 [8:00];
- Getting a dog—Why Peter caved and how it’s going so far [15:45];
- Rapamycin—How Peter’s feelings have evolved, and the questions still needing to be answered [20:45];
- Archery, the joy of pursuing mastery, and the importance of stillness [26:50];
- Zone 2 training—Why Peter has made it a big component of his exercise regimen [37:30];
- Deadlifts—Why Peter now believes it’s extremely beneficial to longevity when done properly [41:45];
- Read any good books lately? [50:00];
- Baby aspirin for preventing blood clotting—Why Peter no longer takes it, and a few alternative options [53:15];
- Generic drugs—How and why Peter’s mind has shifted on generic drugs [55:45];
- Omega-3 fatty acids, EPA and DHA—How Peter’s long-held views have changed [58:15];
- How Peter got better at saying “no” [1:02:30];
- Does Peter have any favorite episodes of The Drive? [1:07:15]; and
- More.

§

## Show Notes

## Definition of “strong convictions loosely held”, and the value in trying to shoot down your own hypotheses [2:20]

- During the pre-show preparation and during conversations with podcast guests, Peter will often shift his thinking about a topic
- And in most cases it leads to positive behavior changes
- This episode is about sharing some of those situations where Peter’s thinking has changed

**“Strong convictions loosely held”**

- This is a phrase that exists in various forms (e.g., strong opinions loosely held, strong opinions weakly held, strong convictions weakly held, etc.)
- But this particular this version was something one of Peter’s patients told him was a guiding principle at a very successful hedge fund where they would make bold investments based on strong convictions but they were very loosely held convictions and they were always looking for ways to change their information
- Bob points out that especially in science and medicine, the ability to change your mind is a “*feature and* ***not*** *a bug”*
- In his [book](https://books.google.com/books?id=MBWGDwAAQBAJ&pg=PA195&lpg=PA195&dq=Richard+Feinman+What+you+do+in+science+is+you+make+a+hypothesis+and+then+you+try+to+shoot+yourself+down.&source=bl&ots=S9zSsECYEp&sig=ACfU3U18qWwfAXc5HuTDKqeovdubfyt21A&hl=en&sa=X&ved=2ahUKEwiP8u-R8bXoAhVHPawKHYU5B-AQ6AEwAHoECAwQAQ#v=onepage&q=Richard%20Feinman%20What%20you%20do%20in%20science%20is%20you%20make%20a%20hypothesis%20and%20then%20you%20try%20to%20shoot%20yourself%20down.&f=false), biochemist [Richard Feinman](https://en.wikipedia.org/wiki/Richard_D._Feinman) (not to be confused with [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman)) quoted his colleague, [Izja Lederhendler](https://www.researchgate.net/scientific-contributions/38114253_Izja_Lederhendler), who said, “*What you do in science is, you make a hypothesis and then you try to shoot yourself down.*”

## Metformin—How Peter’s strong convictions have changed since 2018 [8:00]

**How has Peter’s strong convictions about Metformin changed since he started the podcast in the summer of 2018?**

-Peter had been personally taking metformin for about 7 years

-Peter said the benefits of metformin were clear for:

- Type 2 diabetes
- Obesity without T2D
- Hyperinsulinemia
- Metformin seemed to reduce incidents of cancer, and
- increase the survival of cancer

-These benefits got Peter thinking that metformin could maybe work as a longevity agent even in those people who were otherwise “healthy”

⇒ Peter [interviewed Nir Barzilai](https://peterattiamd.com/nirbarzilai/) for the podcast

*Fast forward to December of 2018…*

- This was when Peter first became interested in zone two training
- It was the first time he’d ever been checking lactate levels under low levels of exertion
- He noticed his baseline lactate levels were quite high
- He then came to the conclusion that the metformin was the cause of this
- Why?… Metformin is a weak mitochondrial toxin
- One of the potential rare complications of metformin is [lactic acidosis](https://www.sciencedirect.com/science/article/pii/S0026049515003066)
- This lactate observation got Peter to change his thinking…
- Maybe the benefits of metformin are most pronounced in people who have otherwise quite defective mitochondria to begin with so they can afford a “slight hit” to their mitochondrial performance because of all the other benefits they’re getting
- Those benefits of metformin may not hold true for someone who’s otherwise quite healthy who’s looking to maximize mitochondrial health and throughput

**-Peter stopped taking metformin in early 2019**

- Since stopping, he noticed the following:
  - 1)  Lactate levels went down and his zone 2 efficiency (as measured by lactate) went up
  - 2) Glucose levels are a bit higher
    - Metformin was suppressing glucose levels and that was probably a good thing

**Metformin and exercise**

- Peter has also [written](https://peterattiamd.com/metformin-and-exercise/) about how metformin can blunt the positive effects of exercise
- Peter followed that up with [another article](https://peterattiamd.com/191013/) reviewing a recent paper showing metformin blocked the positive muscular adaptations from resistance training
- W*hy does it do this*?
  - While chronic inflammation is bad, the acute oxidative stress from strength training can lead to beneficial adaptive responses
  - Another potential reason may be due to an inhibition mTORC1

> “I now would say I reserve metformin prescriptions for patients who obviously are in need of it from the standpoint of glucose and insulin regulation, but I don’t view it really as a pro longevity agent yet.”

⇒ Peter is looking forward to seeing if the [TAME Study](https://www.afar.org/research/TAME/) will get funded to look at people without diabetes and asking the question, *Can this extend life indirectly via mitigating the onset of chronic disease?*

## Getting a dog—Why Peter caved and how it’s going so far [15:45]

Peter’s family recently got a puppy

- Peter had resisted this for a long time thinking that they just didn’t have the bandwidth as a family to add in the work necessary to care for a dog
- Peter never thought this day would come, “*If I woke up tomorrow morning with my head sewn to the carpet, I wouldn’t be more surprised than I am right now.*” –[Clark Griswold in Christmas Vacation](https://www.youtube.com/watch?v=2fQxzuaE2MA)
- But after relentless pressure from his daughter, Peter’s resistance weakened and they adopted a puppy from a dog shelter
- The puppy’s name is Molly, and she was the runt of the litter and she is visually impaired
- “*She’s amazingly gentle, and sweet and kind . . .I don’t regret it even though it’s harder than I thought it would be*.”

![](https://peterattiamd.com/wp-content/uploads/2020/04/molly-1020x1024.png)

**Figure 1.** Molly.

> “I think I’m getting the point that people had been trying to make for years when I had been saying, ‘why would anybody get a dog?’, which is, I think there were these **intangible benefits** that come from a dog that you don’t appreciate if you try to just think about it with your logical brain.”

- Getting a dog is a lot of work
- But the unconditional love from a dog is unlike any other

**Bob’s joke:**

- *Want to know who loves you more?*

- Put your spouse and your dog in the trunk of a car and drive around for an hour.
- When you open the trunk, *who’s happy to see you*?

## Rapamycin—How Peter’s feelings have evolved, and the questions still needing to be answered [20:45]

**How has Peter’s feelings about rapamycin evolved?**

–*In December 2014, a* [*paper*](https://www.ncbi.nlm.nih.gov/pubmed/25540326) *was published that was the turning point for Peter*

- The paper showed that the strength of vaccination in healthy subjects could be augmented by a rapamycin analog ([everolimus](https://en.wikipedia.org/wiki/Everolimus))
- This was counterintuitive because rapamycin’s on label use was to suppress the immune system for the mitigation of organ rejection from a transplant
- The study also showed that there were different ways to dose rapamycin (e.g., daily, weekly, higher and lower doses, etc.)

**Peter now takes rapamycin personally** ⇒ Peter spent 4+ years diving deeper into the literature to figure out the right dose and frequency of dose

- There are two main risks when you’re taking a medication that you don’t have an immediate biomarker for…
  - You don’t know for sure if the drug is actually working
  - You don’t know for sure if things are going awry
    - Only true symptom of too much rapamycin is mouth sores

> “[With rapamycin], you don’t really know if you’re taking enough and you don’t know if you’re taking too much beyond some of those symptoms. And so, you really have to be able to triangulate on what the right dose is. And so, that’s what basically took me about four years.”

**Unanswered questions**

- Peter is still trying to figure out ways we can have biomarkers that can lend insight to the efficacy of taking rapamycin
- He still remains unsure about the exact best dose, frequency, and the amount of “cycling” that is optimal
- “*But my convictions are now high enough on the side of something that looks like what I’m doing right now is probably beneficial.*”

## Archery, the joy of pursuing mastery, and the importance of stillness [26:50]

**Does Peter still practice archery?**

- Yes, a lot
- He also spends a lot of time practicing driving (Formula 1) in his simulator mostly

*-Peter on why archery is so addicting*:

- First, there’s no ceiling to how much you can improve
- Secondly, there’s many different types of archery that you can learn (like many diff sports in one)
- “*You also realize that archery has kind of a great metaphor for life and you can’t focus just too much on your target. You really have to focus on the process or you’re not going to get better*.”

**Mastery:** Archery is a great framework for trying to master something

- “*I don’t think you have to like archery to appreciate the notion of mastery*”
- People crave getting better at something
- And it doesn’t just have to be sort of a physical domain… It can be an intellectual domain, it can be an emotional domain, or a relational domain

**The joy in making progress and getting better at something**

- Bob has had his own revelation over his life
- Growing up, he was a miserable student
- But he was so focused on sports like hockey where he dedicated his time and energy towards this pursuit of getting better and mastery
- It wasn’t really until adulthood that he realized he could find that same level of joy in intellectual pursuits
- Peter says, “*I do pity the person who’s never found it interesting to try to get better at something.*”

**Can you take practice and mastery too far?**

- Yes says Peter, especially if you are **too focused on the result instead of the process**
- The best days of archery, when Peter isn’t being to internally competitive, archery feels like meditation
- On those days, he can sort of disregard the outcome… “but that’s not often the case”

**The importance of stillness**

- A really big change over the past couple of years for Peter is his newfound appreciation for **how essential it is to have activities in your life that are NOT objective-oriented or outcome-based**
- Peter has recently gone back to swimming laps in a pool but he does so without an objective or goal other than to feel the water moving through his fingers and he the sound of the water moving past him

⇒ See this [Ryan Holiday episode](https://docs.google.com/document/d/1ZcuCeNPLGR1ax8G4PrHkOr2s1PpeKYfEKnLcBy8QpFk/edit#90%20%E2%80%93%20Ryan%20Holiday:%20Stillness,%20stoicism,%20and%20suffering%20less) of The Drive for more on stillness

## Zone 2 training—Why Peter has made it a big component of his exercise regimen [37:30]

**How Peter’s thoughts around zone 2 exercise has changed**

- When Peter stopped cycling back in 2014-2015, he basically stopped doing cardio exercise in “zone 2”
- If he was going to do cardio it would be quick, efficient, and high intensity (e.g., a six min mile run rather than a 9 min mile)
- Peter then met Iñigo San Millán and did more research and he learned about the benefits of zone 2 training for things like:
  - **metabolic benefits** ⇒ insulin-dependent, and insulin-independent mediated glucose disposal
  - **mitochondrial benefits** ⇒ function, mitochondrial health density
  - **Neurotrophic benefits** ⇒ the [BDNF](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor) secretion

–*Peter has now added zone 2 training to his regimen*

- He spends 3-4 hours per week training in zone 2 (usually on a stationary bike)
- He really enjoys it and spends his time listening to podcasts and audiobooks (something you can’t really do when your engaged in high intensity intervals)
- Both Peter and Bob use a [Wahoo Kickr](https://www.wahoofitness.com/devices/bike-trainers) to help them stay in the right zone

> “We can do zone 2 our entire lives. We can do it safely and it just yields enormous dividends.”

## Deadlifts—Why Peter now believes it’s extremely beneficial to longevity when done properly [41:45]

**The importance of deadlifts as an adult…** ***how has Peter’s thinking changed on this?***

- Going all the way back to high school, Peter used to deadlift and squat heavy weights
- He continued this practice for a long time
- It wasn’t until about 2016, Peter injured his oblique muscle
- After that, he really had no ability to deadlift without a good amount of discomfort
- It was at that point he started to ponder whether the deadlift was the right thing to be doing if you’re optimizing for longevity
- “*I was like, look, I can probably get most of the benefits of a dead lift doing things that place me under less load*.”
- He sort of got away from deadlifting at all for a while
- However… he reintroduced deadlifting once he started [DNS](https://www.rehabps.com/REHABILITATION/Home.html) about 18 months ago

–[Dynamic Neuromuscular Stabilization](https://www.rehabps.com/REHABILITATION/Home.html)

- It was through that process of learning DNS that Peter realized that the deadlift was going to be beneficial…
- Not because of the metabolic benefits, but rather because it becomes a beautiful audit for everything working perfectly

–*His deadlifting routine*:

- Deadlifts 2 or 3 times per week
- Both straight bar and trap bar
- He does NOT use super heavy weight
- Rarely goes above 350 lbs on the trap bar
- On the straight bar, he goes super light, about 185 lbs
- He does a lot of slow eccentrics
- He films every single rep of every single set and studies it
- He then sends it to his coach, [Beth Lewis](https://www.instagram.com/bethlewisfit/)
- He is trying to make his deadlift perfect
- A typical workout is something like 4 sets of 10 reps

*What could Peter get out of doing that deadlift perfectly?*

- Am I doing just the right amount of thoracic extension?
- Do I have just the right curvature in the lumbar spine?
- Am I activating my glutes?
- Am I activating my hamstrings,
- I’m I pulling back instead of pulling up?
- Am I wedging correctly?

> “All of this little stuff translates bio mechanically to the activities of daily living that matter to me. Like getting up off the floor, picking up one of my kids, lifting a piece of luggage, or something like that.”

**The deadlift as a way to check yourself**

- If I can do the deadlift and it feels right, then I know I’m ready to do everything correctly.
- When something does NOT feel right during a deadlift, you get 2 things from it:
  - First, you now have learned what that feeling is
  - Secondly, you now have learned the steps that you can go back and reconstruct what needs to be done

***Which is the benefit?*** *The deadlift itself or the things you need to do in order to deadlift properly?*

“I’m not even sure how much of the benefit is the actual deadlift versus all the things you have to do to do the deadlift correctly.”

**One last interesting point…**

- You can actually deadlift in a way that puts your spine under **traction**
- You would think that anytime you’re lifting under an axial load, your spine is under compression
- However, when you learn the right positioning and you understand how to create intra abdominal pressure, and you know to elongate your spine, you can actually dead lift and create traction in the spine actively

## Read any good books lately? [50:00]

**Books mentioned by Peter:**

*-Currently reading*: [Far From the Tree](https://www.amazon.com/Far-Tree-Parents-Children-Identity/dp/0743236718/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Andrew Solomon

*-Recently re-read*: [Stillness is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585) by Ryan Holiday ([previous podcast guest](https://peterattiamd.com/ryanholiday/))

- Peter also likes [Ego is the Enemy](https://www.amazon.com/Ego-Enemy-Ryan-Holiday/dp/1591847818) and [The Obstacle Is The Way](https://www.amazon.com/Obstacle-Way-Timeless-Turning-Triumph/dp/1591846358) by Ryan Holiday

**Books mentioned by Bob**:

- [Why We Get Fat](https://www.amazon.com/Why-We-Get-Fat-About/dp/0307474259) by Gary Taubes
- *Book by a future podcast guest*: [Malignant](https://www.amazon.com/Malignant-Policy-Evidence-People-Cancer/dp/1421437635) by Vinay Prasad (book about public health policy and cancer)
- Azra Raza’s book, [The First Cell](https://www.amazon.com/First-Cell-Human-Pursuing-Cancer-dp-1541699521/dp/1541699521/ref=mt_hardcover?_encoding=UTF8&me=&qid=)
- Great books by Sid Mukherjee ([previous podcast guest](https://peterattiamd.com/sidmukherjee/)):
  - [The Gene](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1432837818)
  - [Emperor of All Maladies](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439170916)
  - [The Laws of Medicine](https://www.amazon.com/Laws-Medicine-Field-Uncertain-Science/dp/1476784841) (TED Book)

⇒ PBS [documentary](https://www.pbs.org/kenburns/cancer-emperor-of-all-maladies/) about cancer featuring Sid’s book, **Emperor of All Maladies**

⇒ More recent PBS [documentary](https://www.pbs.org/show/gene/) featuring Sid’s book, **The Gene**

## Baby aspirin for preventing blood clotting—Why Peter no longer takes it, and a few alternative options [53:15]

**Peter’s previous mindset about aspirin**:

- On a long flight, baby aspirin would work for prevention of deep vein thrombosis
- Furthermore, it’s widely understood that in general, baby aspirin inhibits platelets which are one of the cellular matters in blood that’s responsible for clotting
- These facts resulted in Peter believing it was reasonable to use baby aspirin to prevent heart attacks and strokes (from clotting)

**How his thoughts have changed**:

- After some digging, Peter found that there wasn’t much evidence that baby aspirin had any efficacy in mitigation of deep vein thrombosis, especially on an airplane
- Also found that the gold standard would be [heparin](https://www.drugs.com/heparin.html) but it’s not very practical because it would have to be injected

**Alternatives to baby aspirin for prevention of clotting**:

–[Flite Tabs](https://www.amazon.com/Flite-Tabs-Aidan-Formula-Flights/dp/B01BLQG2D0)

- OTC product found on Amazon
- A pretty potent agent that actually had pretty remarkable [evidence](https://www.ncbi.nlm.nih.gov/pubmed/14565628) that it prevented deep vein thrombosis (DVT)

–[Nattokinase](https://www.webmd.com/vitamins/ai/ingredientmono-1084/nattokinase)

- Plant derived
- Far more [evidence](https://rhochistj.org/RhoChiPost/nattokinase-use-dvt-prophylaxis/) for prevention of DVT than baby aspirin

> “So that was a bit of a humbling experience because you think, ‘well, look on first principles, aspirin’s got to be thinning the blood, it’s got to be good for this’. And then you realize, ‘well, wait a minute, even something as simple as that, when you actually really antagonize the literature, it turned out not to be the case’. And the things that did seem to have some efficacy are things I’d never even heard of. So it’s a little scary, because it makes me wonder how many times that is happening throughout the course of my life.”

## Generic drugs—How and why Peter’s mind has shifted on generic drugs [55:45]

**Peter’s previous thought about generic drugs**:

-Peter’s default thinking used to be…

- Generics were great
- Exactly the same as branded but a fraction of the cost
- Branded drugs were basically a scam

**How his thoughts have changed**:

- Over the past couple of years, Peter had noticed that certain generic statins (i.e., rosuvastain instead of Crestor) were not producing the normally very clear changes to biomarkers that you’d expect
- He began to wonder if not all generics were created equal
- He then read Katherin Eban’s book: [Bottle of Lies](https://www.amazon.com/Bottle-Lies-Inside-Story-Generic/dp/0062338781)
- And had [Katherine Eban on the podcast](https://peterattiamd.com/katherineeban/)
- And now Peter’s **entire mindset has changed**
- In his medical practice, he works primarily with one pharmacy that will only issue branded drugs if Peter or the patient insists
- And when he does prescribe generic drugs, he will only do so by first considering and evaluating the companies making them and cross referencing that with an FDA list of potential bad actors
- “*So I don’t think that has completely mitigated the problem, but I think it’s probably taken care of three quarters of it.*”

## Omega-3 fatty acids, EPA and DHA—How Peter’s long-held views have changed [58:15]

Peter recently had [Bill Harris](https://omegaquant.com/dr-william-s-harris/) (omega-3 expert) [on the podcast](https://peterattiamd.com/billharris/)

- His discussion with Bill explains some of his evolved thinking about omega-3 fatty acids mentioned below

**Peter’s long-held views have been**:

- He’s always believed EPA and DHA (found in oily fish) are beneficial
- But he questioned whether it was the EPA and DHA specifically or whether it was the other things in the fish that were conferring the benefit
- His thinking has evolved now to the point where he believes EPA and DHA by themselves are quite potent drugs
- Regarding EPA specifically:
  - The [REDUCE-IT study](https://www.ncbi.nlm.nih.gov/pubmed/31707829?dopt=Abstract) showed 4 grams of a pharmaceutical grade EPA called Vascepa is “*as potent as any anti-cardiovascular disease drug that we have*”
- With DHA:
  - The clinical trials aren’t as clear
- In fact, there was a [study](https://www.nejm.org/doi/full/10.1056/NEJMoa1811403) released that showed not much benefit (but no harm either)

**Peter’s current, overall thoughts on EPA and DHA**:

- High level of confidence in the necessity of EPA and DHA
- He now believes in a higher level of EPA+DHA that we should strive for
- He used to generally look for a red blood cell membrane level of about 8% to 10% (aka Omega-3 Index) but now thinks we could really push that up to 12-14% without any undesirable side effects

⇒ You can test your own omega-3 index with [OmegaQuant](https://omegaquant.com/)

**Are omega-6 polyunsaturated fatty acids bad for you?**

- Peter has historically believed that eating omega-6 was generally not a good thing
- But the problem is omega-6 is so often packed with processed food
- So, admittedly, it’s hard to say whether the omega-6 is harmful or if the problem is what it’s packaged with
- Bill, however, has a strong conviction that omega-6 fatty acids are NOT harmful
- And Bill’s takeaway message is that **you shouldn’t really think about omega-6 polyunsaturated fats, you just need to add more EPA and DHA in**

> “This is a very polarizing topic. People are on both sides of this. Both sides I think have people that I think are quite bright. So I’m a bit confused on that.”

## How Peter got better at saying “no” [1:02:30]

**In the past…**

- Peter had a hard time saying no to anything
- “I was basically on a treadmill of sort of saying yes to anything and everything that was asked of me”

**Today…**

- Peter says he’s getting better at saying no to things
- But he points out that saying ‘yes’ and saying ‘no’ could both be taken to the extreme
- It’s a hard balance to figure out

**People and things that helped Peter with this**:

–[Tim Ferriss](https://twitter.com/tferriss?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

- [How to say “no”](https://tim.blog/2017/11/25/how-to-say-no/)
- [How to say “no” gracefully and uncommit](https://tim.blog/2018/07/19/essentialism/)
  - One practical takeaway Peter gleaned was to respond with “Can I get back to you on this?” when people ask you for something

–[Ric Elias](https://twitter.com/ricelias?lang=en) ⇒ see [podcast episode with Ric](https://peterattiamd.com/ricelias/)

–[Jason Fried](https://twitter.com/jasonfried?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) ⇒ see podcast episodes with Jason ([#74](https://peterattiamd.com/jasonfried/) and [#93](https://peterattiamd.com/jasonfriedama/))

> “The insight that I think Jason Fried brought to his episode really well was when you’re saying ‘yes’ to something, you’re actually saying ‘no’ to something else, you just don’t know what that something else is yet. That’s a very important insight.”

## Does Peter have any favorite episodes of The Drive? [1:07:15]

**Peter on his feelings towards starting and maintaining The Drive Podcast**:

- Peter was very hesitant about starting a podcast despite a lot of encouragement to do so
- It was mostly due to the fear around the amount of work it would take
- Not starting a podcast was as “*strong conviction, fortunately loosely enough held that I was able to sort of get out of my own way*”

*Today…*

- Peter is very happy with the podcast
- His big team around him allow him to just focus on the discussion with people
- “barring some unforeseen thing, we’re going to one day be that podcast that’s on our 300th episode.”

**Any favorite episodes?**

*-Some he really enjoyed from a* ***technical*** *standpoint*:

- [Rick Johnson episode](https://peterattiamd.com/rickjohnson/) about fructose
- [Keith Flaherty episode](https://peterattiamd.com/keithflaherty/) about cancer

*-Favorites in terms of enjoyable conversations*:

- [Damon Hill episode](https://peterattiamd.com/damonhill/) about his F1 career and working with Senna
- [Ric Elias episode](https://peterattiamd.com/ricelias/) about the gift of life for how much he thinks people will benefit from hearing it

*-Other episodes mentioned*:

- [Katherine Eban episode](https://peterattiamd.com/katherineeban/) illuminating the corrupt generic drug market
- [Zdogg episode](https://peterattiamd.com/zubindamania/)
- [Marty Makary episode](https://peterattiamd.com/martymakary/)
- [Mark Messier episode](https://peterattiamd.com/markmessier/)

§

## Selected Links / Related Material

**Richard Feinman’s book that quoted his colleague, Izja Lederhendler, who said, “What you do in science is, you make a hypothesis and then you try to shoot yourself down.”**: [Nutrition in Crisis](https://books.google.com/books?id=MBWGDwAAQBAJ&pg=PA195&lpg=PA195&dq=Richard+Feinman+What+you+do+in+science+is+you+make+a+hypothesis+and+then+you+try+to+shoot+yourself+down.&source=bl&ots=S9zSsECYEp&sig=ACfU3U18qWwfAXc5HuTDKqeovdubfyt21A&hl=en&sa=X&ved=2ahUKEwiP8u-R8bXoAhVHPawKHYU5B-AQ6AEwAHoECAwQAQ#v=onepage&q=Richard%20Feinman%20What%20you%20do%20in%20science%20is%20you%20make%20a%20hypothesis%20and%20then%20you%20try%20to%20shoot%20yourself%20down.&f=false) by Richard David Feinman | (books.google.com) [5:30]

**Meta-Analysis looking at metformin and cancer: Metformin and Cancer Risk and Mortality**: [A Systematic Review and Meta-Analysis taking into account Biases and Confounders](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4154969/) (Gandini et al., 2014) [8:30]

**Peter’s interview of Nir Barzilai**: [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) | Peter Attia (peterattiamd.com) [10:15]

**One of the potential rare complications of metformin is lactic acidosis**: [Metformin-associated lactic acidosis: Current perspectives on causes and risk](https://www.sciencedirect.com/science/article/pii/S0026049515003066) (DeFronzo et al., 2015) [11:45]

**Peter’s article about how metformin can blunt the positive effects of exercise**: [Metformin and exercise](https://peterattiamd.com/metformin-and-exercise/) | Peter Attia (peterattiamd.com) [14:30]

- *And here’s a follow up to that one*: [Metformin and exercise – déjà vu all over again?](https://peterattiamd.com/191013/) | Peter Attia (peterattiamd.com)

**Nir Barzilai’s metformin study currently in the works but needing funding**: [TAME Trial – The Targeting Aging with Metformin Trial](https://www.afar.org/research/TAME/) | (afar.org) [15:00, 26:30]

**Line from Christmas Vacation that Peter said was his reaction when his family finally got a dog**: [Christmas Vacation- Surprised Clark?](https://www.youtube.com/watch?v=2fQxzuaE2MA) | donut778 (youtube.com) [16:15]

**2014 paper that Peter calls the “turning point” in his feelings and curiosity about rapamycin**: [mTOR inhibition improves immune function in the elderly.](https://www.ncbi.nlm.nih.gov/pubmed/25540326) (Mannick et al., 2014) [21:00]

**Episodes of the The Drive focuses on mTOR and rapamycin**: [22:45]

- [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) | Peter Attia (peterattiamd.com)
- [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) | Peter Attia (peterattiamd.com)

**Rapamycin and mouth sores**: [Oral mucosal injury caused by mammalian target of rapamycin inhibitors: emerging perspectives on pathobiology and impact on clinical practice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4971919/) (Peterson et al., 2016) [24:30]

**Grit**: [Grit: the power of passion and perseverance](https://www.ted.com/talks/angela_lee_duckworth_grit_the_power_of_passion_and_perseverance?language=en) | Angela Duckworth (ted.com) [32:30]

**Episode of The Drive about importance of stillness**: [#90 – Ryan Holiday: Stillness, stoicism, and suffering less](https://peterattiamd.com/ryanholiday/) | Peter Attia (peterattiamd.com) [35:00]

**Episode of The Drive about Zone 2 training**: [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com) [38:45]

**Peter and Bob use a Wahoo Kickr on their stationary bike to help them stay in the right zone**: [Wahoo Kickr](https://www.wahoofitness.com/devices/bike-trainers) | (wahoofitness.com) [41:00]

**Competitor of Wahoo Kickr**: [CompuTrainer](https://www.racermateinc.com/computrainer/) | (racermateinc.com) [41:00]

**Peter practices DNS and it changed the way he thought about doing deadlifts – Dynamic Neuromuscular Stabilization (DNS)**: [The Prague School and Dynamic Neuromuscular Stabilization](https://www.rehabps.com/REHABILITATION/Home.html) | (rehabps.com) [44:45]

**Book Peter is currently reading**: [Far From the Tree: Parents, Children and the Search for Identity](https://www.amazon.com/Far-Tree-Parents-Children-Identity/dp/0743236718/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Andrew Solomon | (amazon.com) [50:00]

**Book Peter recently re-read and has read a bunch and gifted a bunch**: [Stillness Is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585) by Ryan Holiday | (amazon.com) [50:30]

**Other Ryan Holiday books that Peter recommends**: [50:30]

- [Ego Is the Enemy](https://www.amazon.com/Ego-Enemy-Ryan-Holiday/dp/1591847818) by Ryan Holiday | (amazon.com)
- [The Obstacle Is the Way: The Timeless Art of Turning Trials into Triumph](https://www.amazon.com/Obstacle-Way-Timeless-Turning-Triumph/dp/1591846358) by Ryan Holiday | (amazon.com)

**Book Bob mentioned**: [Why We Get Fat: And What to Do About It](https://www.amazon.com/Why-We-Get-Fat-About/dp/0307474259) by Gary Taubes | (amazon.com) [51:30]

**Book by Vinnie Prasad, future podcast guest, which has a section about public health policy and cancer**: [Malignant: How Bad Policy and Bad Evidence Harm People with Cancer](https://www.amazon.com/Malignant-Policy-Evidence-People-Cancer/dp/1421437635) by Vinayak K. Prasad | (amazon.com) [51:30]

**Book by Azra Raza, future podcast guest**: [The First Cell: And the Human Costs of Pursuing Cancer to the Last](https://www.amazon.com/First-Cell-Human-Pursuing-Cancer-dp-1541699521/dp/1541699521/ref=mt_hardcover?_encoding=UTF8&me=&qid=) by Azra Raza | (amazon.com) [52:15]

**Sid Mukherjee books**: [52:30]

- [The Gene](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1432837818)
- [Emperor of All Maladies](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439170916)
- [The Laws of Medicine](https://www.amazon.com/Laws-Medicine-Field-Uncertain-Science/dp/1476784841) (TED Book)

**PBS documentary about cancer featuring Sid’s book, Emperor of All Maladies**: [Cancer: The Emperor of All Maladies](https://www.pbs.org/kenburns/cancer-emperor-of-all-maladies/) | (pbs.org) [52:30]

**OTC product with pretty remarkable evidence that it prevented deep vein thrombosis (DVT)**: [Flite Tabs](https://www.amazon.com/Flite-Tabs-Aidan-Formula-Flights/dp/B01BLQG2D0) | (amazon.com) [54:30]

**Some evidence that Flite Tabs prevent DVT**: [Prevention of venous thrombosis in long-haul flights with Flite Tabs: the LONFLIT-FLITE randomized, controlled trial.](https://www.ncbi.nlm.nih.gov/pubmed/14565628) (Cesarone et al., 2003) [54:30]

**Another OTC supplement that has shown to be better than baby aspirin**: [Nattokinase](https://www.webmd.com/vitamins/ai/ingredientmono-1084/nattokinase) | (webmd.com) [54:30]

**Some evidence of nattokinase for DVT**: [Nattokinase use in DVT prophylaxis](https://rhochistj.org/RhoChiPost/nattokinase-use-dvt-prophylaxis/) | (rhochistj.org) [54:30]

**Episode of The Drive about generic drugs**: [#71 – Katherine Eban: Widespread fraud in the generic drug industry](https://peterattiamd.com/katherineeban/) | Peter Attia (peterattiamd.com) [55:45]

**Episode of The Drive about omega-3 fatty acids**: [#83 – Bill Harris, Ph.D.: Omega-3 fatty acids](https://peterattiamd.com/billharris/) | Peter Attia (peterattiamd.com) [58:15]

**Study showing 4 grams of  EPA (Vascepa) was a potent anti-cardiovascular disease drug**: [REDUCE-IT USA: Results From the 3146 Patients Randomized in the United States.](https://www.ncbi.nlm.nih.gov/pubmed/31707829?dopt=Abstract) (Bhatt et al., 2020) [59:15]

**Omega-3 study stopped early for futility**: [NEJM publication: Marine n−3 Fatty Acids and Prevention of Cardiovascular Disease and Cancer](https://www.nejm.org/doi/full/10.1056/NEJMoa1811403) (Manson et al., 2019) [59:30]

**The Drive podcast episodes that discuss the concept of and benefit of “saying no”**: [1:02:30]

- [#74 – Jason Fried: Optimizing efficiency and work-life balance](https://peterattiamd.com/jasonfried/) | Peter Attia (peterattiamd.com)
- [#79 – Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/) | Peter Attia (peterattiamd.com)

**Tim Ferriss blog and podcast about saying “no” that helped Peter**: [1:03:45]

- [How to say “no”](https://tim.blog/2017/11/25/how-to-say-no/) | (tim.blog)
- [How to say “no” gracefully and uncommit](https://tim.blog/2018/07/19/essentialism/) | (tim.blog)

**Peter’s favorite technical episodes of The Drive podcast**: [1:09:50]

- [#87 – Rick Johnson, M.D.: Fructose—The common link in high blood pressure, insulin resistance, T2D, & obesity?](https://peterattiamd.com/rickjohnson/) | Peter Attia (peterattiamd.com)
- [#62 – Keith Flaherty, M.D.: Deep dive into cancer— History of oncology, novel approaches to treatment, and the exciting and hopeful future](https://peterattiamd.com/keithflaherty/) | Peter Attia (peterattiamd.com)

**Favorite episodes of The Drive in terms of enjoyable conversations**: [1:10:30]

- *Damon Hill episode about his F1 career and working with Senna*: [#86 – Damon Hill: Overcoming loss, achieving success, and finding one’s identity](https://peterattiamd.com/damonhill/) | Peter Attia (peterattiamd.com)
- *Ric Elias episode about the gift of life for how much he thinks people will benefit from hearing it*: [#79 – Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/) | Peter Attia (peterattiamd.com) | Peter Attia (peterattiamd.com)

**Other episodes of The Drive mentioned**: [1:11:15]

- *Katherine Eban episode illuminating the corrupt generic drug market*: [#71 – Katherine Eban: Widespread fraud in the generic drug industry](https://peterattiamd.com/katherineeban/) | Peter Attia (peterattiamd.com)
- *Zdogg episode*: [#37 – Zubin Damania, M.D.: Revolutionizing healthcare one hilariously inspiring video at a time](https://peterattiamd.com/zubindamania/) | Peter Attia (peterattiamd.com)
- *Marty Makary episode*: [#68 – Marty Makary, M.D.: The US healthcare system—why it’s broken, steps to fix it, and how to protect yourself](https://peterattiamd.com/martymakary/) | Peter Attia (peterattiamd.com)
- *Mark Messier episode*: [#82 – Mark Messier: Leadership, personal growth, and performing under pressure](https://peterattiamd.com/markmessier/) | Peter Attia (peterattiamd.com)

**Peter’s 2019 appearance on the Tim Ferriss podcast**: [Peter Attia, M.D. — Fasting, Metformin, Athletic Performance, and More (#398)](https://tim.blog/2019/11/27/peter-attia-fasting-metforming-longevity/) | (tim.blog) [1:13:45]

§

## People Mentioned

- [Richard Feinman](https://en.wikipedia.org/wiki/Richard_D._Feinman) [5:30]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) [5:30]
- [Izja Lederhendler](https://www.researchgate.net/scientific-contributions/38114253_Izja_Lederhendler) [5:30]
- [Nir Barzilai](https://www.einstein.yu.edu/faculty/484/nir-barzilai/) [10:15, 24:45]
- [Joan Mannick](https://www.restorbio.com/team_post_type/joan-mannick-m-d/) [21:00]
- [Lloyd Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/) [21:00]
- [David Sabatini](https://twitter.com/DMSabatini?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [22:45]
- [Matt Kaeberlein](https://en.wikipedia.org/wiki/Matt_Kaeberlein) [22:45]
- Steve Ostet [26:00]
- [Ryan Holiday](https://twitter.com/RyanHoliday?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [35:00, 50:30]
- [Iñigo San Millán](https://medschool.cuanschutz.edu/deans-office/cu-med-today/profiles/inigo-san-millan) [38:45]
- [Beth Lewis](https://www.instagram.com/bethlewisfit/) [46:40]
- [Andrew Solomon](https://twitter.com/Andrew_Solomon?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [50:00]
- [Sid Mukherjee](https://en.wikipedia.org/wiki/Siddhartha_Mukherjee) [50:15]
- [Gary Taubes](https://en.wikipedia.org/wiki/Gary_Taubes) [51:30]
- [Vinay Prasad](https://en.wikipedia.org/wiki/Vinay_Prasad) (Malignant) [51:30]
- [Azra Raza](https://cancer.columbia.edu/azra-raza-md) [52:00]
- [Katherine Eban](https://twitter.com/KatherineEban?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [55:45, 1:11:15]
- [Bill Harris](https://omegaquant.com/dr-william-s-harris/) [58:15]
- [Jason Fried](https://twitter.com/jasonfried?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:02:30]
- [Ric Elias](https://twitter.com/ricelias?lang=en) [1:02:30]
- [Tim Ferriss](https://twitter.com/tferriss?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:03:45, 1:06:30, 1:13:45]
- [Charlie Munger](https://en.wikipedia.org/wiki/Charlie_Munger) [1:06:30]
- [Warren Buffett](https://en.wikipedia.org/wiki/Warren_Buffett) [1:06:30]
- [Travis Denson](https://instagram.com/superserioushealth) [1:09:00]
- Nick Stenson [1:09:00]
- [Rick Johnson](https://www.foodaddictionsummit.org/presenters-johnson.htm) [1:09:50]
- [Keith Flaherty](https://en.wikipedia.org/wiki/Keith_Flaherty) [1:09:50]
- [Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill) [1:10:30]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) [1:10:45]
- [Ric Elias](https://twitter.com/ricelias?lang=en) [1:10:45]
- [Tom Brady](https://twitter.com/TomBrady?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:11:45]
- [Zubin “Zdogg” Damania](https://zdoggmd.com/about-z/) [1:12:15]
- [Marty Makary](https://en.wikipedia.org/wiki/Marty_Makary) [1:12:15]
- [Mark Messier](https://en.wikipedia.org/wiki/Mark_Messier) [1:12:15]

§