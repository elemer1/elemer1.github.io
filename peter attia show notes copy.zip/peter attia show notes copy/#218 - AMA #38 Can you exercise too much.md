# #218 – AMA #38: Can you exercise too much?

**Source:** [https://peterattiamd.com/ama38/](https://peterattiamd.com/ama38/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives deep into the question of whether there is such a thing as “too much exercise.” He explores the theoretical “J-curve” relationship between exercise and longevity, whereby mortality risk declines with increasing activity levels only to see an uptick above a certain exercise volume threshold. While Peter maintains that exercise is perhaps the single most important tool we have to live longer and live better, he explains the challenges involved in identifying an optimal dose. He takes a hard look at studies—many of which have contradictory results—to highlight major limitations in methodology and how readers could be misled. Additionally, he discusses the rare, but real, risks associated with extreme levels of physical activity and concludes by weighing the benefits against the risks of exercise.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #38 show notes page](https://peterattiamd.com/ama38). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- How exercise reduces risk for all-cause mortality [2:30];
- Defining the metric called “MET” and how it’s useful for evaluating different exercises [7:45];
- The challenge in determining the optimal dose of exercise and the limitations of methods used to study the effect of exercise [13:30];
- Using VO2 max as a proxy for fitness to better predict mortality risk [19:00];
- Reviewing data which support the theory of a “J-curve” relationship between exercise and longevity [24:45];
- Importance of understanding p-values and statistical significance [33:30];
- Deconstructing the studies that show a J-curve: major limitations and how one could be misled [36:45];
- Peter’s takeaways on the theoretical “J-curve” relationship between exercise and longevity [51:15];
- Risk of sudden cardiac death from vigorous physical exertion [53:45];
- Atrial fibrillation associated with extreme levels of exercise [1:00:00];
- Parting thoughts: benefits of exercise far outweigh the risks [1:04:00]; and
- More.

§

The Peter Attia Drive

Can you exercise too much?

§

## Show Notes

§

## How exercise reduces risk for all-cause mortality [2:30]

**Overall question of today’s episode**: *What is the optimal dose of exercise for longevity?*

Four pillars of exercise:

- 1) Stability (the foundation)
- 2) Strength
- 3) Zone 2 aerobic training
- 4) Zone 5 (high intensity, e.g., HIIT)
- See [AMA #12](https://peterattiamd.com/ama12/)

*How much should one be working out?*

- When you look at the literature, it doesn’t quite agree with each other
- For example, [Alex Hutchinson](https://peterattiamd.com/alexhutchinson/), [Mike Joyner](https://peterattiamd.com/mikejoyner), and [AMA #27](https://peterattiamd.com/ama27/) don’t necessarily agree with the “J-curve” argument whereas in the [James O’Keefe episode](https://peterattiamd.com/jamesokeefe/) he discusses his research which talks about a J-curve

**The core questions for today include**:

- What is the optimal dose of exercise for longevity?
- And can you do too much?
- We’re NOT really looking at what is the minimum dose?
  - See Peter’s [weekly email](https://peterattiamd.com/does-walking-10-minutes-per-day-extend-your-life/) responding to articles exploring the 10,000 steps rule

*Why explore whether there’s validity to there being “too much exercise”?*

- “Even if majority of people aren’t in the situation where they’re butting up against potential limits of exercise in terms of crossing from being benefit to risk, I think it’s a very important question nevertheless” says Peter
- And it might speak to some of the mechanistic insights around exercise
- And of course for those people who do want to push the limits, it probably gives us some insight as well.

**How is exercise so beneficial, not only for our health span, but also for our lifespan:**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-1.-IG-post-ama38.png)

**Figure 1.** [**@peterattiamd**](https://www.instagram.com/p/CdbG8LNu-aj/)

***Why is exercise so important and why should people make the time for it and put the effort in to understand this?***

- There’s really no need to spend time discussing this beyond just stating that regardless of which chronic disease you’re looking at, whether it be ASCVD, cancer, Type 2 diabetes, Alzheimer’s disease, all cause mortality, it doesn’t matter
- Exercise is going to reduce the toll of mortality across all of those things

Some of the mechanisms by which it does it:

- It can improve lipids
- It can reduce inflammatory markers.
- It can reduce flow mediated shear stress in arteries
- Much of the benefit in cancer comes through the metabolic benefits of exercise
  - we know for example that the second leading environmental or modifiable risk of cancer after smoking is in fact obesity
  - It’s really less the adiposity of obesity that’s the problem, and the metabolic consequences of obesity that are found in many, but not all obese patients
- Diabetes is probably one of the most clear places where you just dramatically see an improvement.
  - The improvement has to do with glucose disposal and insulin sensitivity within the muscle

*“There really isn’t any ambiguity here*” says Peter

\*\*\*\*\*

*For more info and references related to the benefits of exercise on lifespan and healthspan, please see below:*

**What is the relation between exercise and longevity?**

**Background**:  At the most basic level, physical activity increases blood flow throughout the body, improving energy and nutrient transport in tissue. Improving physical fitness can be achieved by performing exercises, which are planned, structured physical activities that require bodily exertion, and has been shown to have numerous health-positive effects on lifespan (quantity of life) and healthspan (quality of life), listed below:

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-A.-ama38.png)

**Figure A.** Lifespan benefits of exercise.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-B.-ama38.png)

**Figure B.** Continuation of Figure A “Lifespan benefits of exercise.”

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-C.-ama38.png)

**Figure C.** Health span benefits of exercise.

*ALP, alkaline phosphatase; ASCVD, atherosclerotic cardiovascular disease; BALP, bone alkaline phosphatase; BDNF, brain-derived neurotrophic factor; BMD, bone mineral density; GH, growth hormone; GLP-1, glucagon-like peptide-1; GLUT4, glucose transporter 4; HDL-C, high density lipoprotein cholesterol; IGF-1, insulin like growth factor 1; LDL-C, low density lipoprotein cholesterol; NGF, nerve growth factor; NTX, amino-terminal crosslinked telopeptide of type 1 collagen; P1NP, procollagen type 1 N-terminal propeptide; PPAR-𝛾, peroxisome proliferator-activated receptor gamma; REM, rapid eye movement; ROS, reactive oxygen species; SWS, slow wave sleep; TNF-⍺, tumor necrosis factor ⍺*

([Nystoriak](https://www.frontiersin.org/articles/10.3389/fcvm.2018.00135/full) 2018, [Hojman](https://www.sciencedirect.com/science/article/pii/S1550413117305673) 2018, [Stanford](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4315445/#:~:text=In%20summary%2C%20exercise%20is%20critical,independent%20increase%20in%20glucose%20uptake.) 2014, [Yang](https://www.karger.com/Article/FullText/500110) 2019,  [Farzanegi](https://sci-hubtw.hkvisa.net/10.1080/17461391.2019.1571114) 2019, [Dishman](https://onlinelibrary.wiley.com/doi/full/10.1038/oby.2006.46) 2006, [Beaulieu](https://link.springer.com/article/10.1007/s40279-016-0518-9) 2016, [Dorling](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6164815/) 2018, [Andrade](https://www.scielo.br/j/jbpneu/a/5kFRpV49Q45RQCcJMf7k8PH/?lang=en) 2016, [Hawley](https://www.sciencedirect.com/science/article/pii/S0092867414013178) 2014, [Mitchell](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0078636) 2013,  [Marini](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7644859/) 2020, [Schoenfeld](https://journals.lww.com/nsca-jscr/fulltext/2010/10000/The_Mechanisms_of_Muscle_Hypertrophy_and_Their.40.aspx?__cf_chl_jschl_tk__=099d7084ff33a3d4999555a69c173fa9fc35818f-1610020100-0-AYQLlf1UtwiZ2J6xql2n2jZSicx8IoF9bD95D3OImdLzcy55vz9YvMxxVYgCGGvYSDtE9Vbea7GBex9hGnxmYim4klwNAzaVcY6jlMTtK_Lc9WM8zinATGY8VIkN6JudsFhISESYoYXQNmIlcsVV0LAmgUigjqHP1RLie3dFUuaBTBNfUcIRBn1SZ3yJsj0X2zaPAeyLvZiTnV5frdav6Fh5v3_8y2riBJntUYlfvWwR_cH0rbZbTxaMSl1SnnE7UPnnnVlJbM00c0j76MSFsmHmGNaoWqmM2ilPqvI80mM1EbBKCaiaYwJoqd5EOF2xVnfuls0NmJHgb1sZCnOdnf-IaBka0S5rjFIvpO1-HUTEPl5zM7G0zQGRNGSnrxE6vC9PAPGn8fR7QtedDhHA1NSfr2APa5Y8d0jBwGVs0WqQox9dcVBGpee9V6bmBesR-gQCL_G_GyJV1gYDIWnHYSXqdKMUs8HiyNdvSVY6dqhD) 2010)

\*\*\*\*\*

## Defining the metric called “MET” and how it’s useful for evaluating different exercises [7:45]

**MET stands for metabolic equivalent of task**

- It’s basically an energy currency in the body
- One MET is the energy cost of being alive at rest
- One MET is equivalent to 3.5 milliliters per minute, per kilogram of oxygen utilization, and that relationship for the most part just holds
  - In other words, if you are doing 10 METs of exercise, you are consuming 35 milliliters of oxygen per kilogram per minute, and that becomes relevant as we start to think about VO2 max

*How many METs do you get doing various things? (some approximate examples)*

- Sitting there doing nothing is one MET
- Walking your dog might be three METs
- Going for a slow bike ride 10 miles an hour or less, four METs.
- Mowing your lawn might be five and a half METs.
- Playing golf, four and a half METs.
- Resistance training vigorously, six METS
- Rowing at a hundred watts, moderate effort, you’re at seven METs

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-2.-mets-ama38.png)

**Figure 2.** Mets.

*Now you can look at the speed change, right?*

- Once you’re running six miles an hour (a 10 minute mile) and that’s still a jog, you’re almost at 10 METs at that point
- Once you’re running 10 miles an hour (six minute mile) you’re at about 14 and a half METs
- You should get a sense of the non-linearity of this, meaning 14 METs versus seven METs—You wouldn’t hold 14 METs for half the time you’d be able to hold 7 METs

**METs are normalized for time**

- If you’re running a six minute mile pace for an hour, we would say you did 14 and a half MET hours of work
- Here’s another way to think about it
  - It’s the difference between watts and joules for cyclists
  - On a bike, your power meter tells you instantaneously how much work you’re doing—that’s wattage, which is really joules per second
  - And then you multiply that over the total time that you do it, you take it back to total energy.
- So the MET is an instantaneous measurement and you normalize it over time to give the total volume—so the work that’s done is really the MET hour
  - For example, if you do a hike for six METs worth of activity or six METs worth of exertion, and you do it for 45 minutes, that would be four MET hours of work done.

***When people think about their METs, how is it that knowing how many MET hours you’re putting out, how is that helpful to someone as they think about exercise on a whole?***

- Peter says that for most people, it’s not
- “I’m probably one of the few people who tracks my MET hours per week”
- Peter has a spreadsheet where he’s basically putting in his activity, the amount of time he spends doing it at various different intensities
  - At the end of the week, he can say, “look, I’m doing a hundred MET hours per week during this phase of my training”
  - “During this phase of my training it might be 80”
  - “Back in the old days, it was 200 MET hours per week. It was a much greater workload.”
- So all of these things are just ways to track the work you’re doing

**When tracking METs becomes important**

- It partially becomes relevant when you want to evaluate the research, because the research has to be able to take into account, not just how much time you’re exercising, but what’s the intensity of that exercise?
- It would be very difficult to provide guidance if we didn’t know this.
- For example, *Are two people who are running 15 miles per week experiencing the same metabolic benefit or harm*?
  - Well, certainly not
  - One could be running them all at 10 minute mile pace
  - One might be, just imagining this, one might be running them all as 400 all out repeats
  - So you have to have some way to normalize that
  - In the case of the latter, you would probably see a much higher MET hour because of the intensity.

## The challenge in determining the optimal dose of exercise and the limitations of methods used to study the effect of exercise [13:30]

***Are we even able to say if there is a minimum efficient or most effective dose of exercise when you look at MET hours per week?***

- People have tried to figure out what that looks like
- However, there are a lot of challenges in trying to do

**What we know**:

- If you take the people who are doing zero MET hours per week of deliberate activity (i.e., actual physical activity)…
  - We know that people who are doing nothing have the highest mortality risk by an insane long shot
  - Just the smallest increase from doing nothing to doing say 10 MET hours per week (e.g., going for a brisk walk for two hours a week)—That’s probably a 20-25% reduction in your all-cause mortality
- The other thing that we can say is that the relationship between increasing MET hours and decreasing mortality is non-linear
  - The rate probably slows the further you go—basically the rate at which you get the benefit goes down
  - So going from nothing to 10 MET hours per week will have a bigger benefit than going from 10 to 20, and going from 20 to 30

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-3.-arem-2015-ama38.png)

**Figure 3.** The y-axis in the mortality risk, with 1.0 equivalent to the risk of a sedentary person. The x-axis indicates the ranges of MET hrs/wk an individual reported. The bottom arrow shows the multiple of the recommended 150 min/wk of moderate-vigorous physical activity, equivalent to 7.5 MET hrs/wk. Adjusted values are given with 95% CI. Source: [Arem](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2212267) 2015

Most of what Peter just said is not controversial, however, where we start to get into some differences of opinion is, ***what does the shape of that curve look indefinitely?***

- *Can you push that too far*?
- *Do you always accrue benefit by increasing activity or at some point does it backfire and you get too much activity leading to reduction in the benefit or stated another way a slight increase in risk*?
- No one’s suggesting that increase in risk goes back to baseline risk, but *does it go above an optimal range*?
- Which now gets to the question Nick posed at the beginning, which is, *Is there an optimal level?*
- *Is there a level that gives you the absolute lowest mortality*?
  - The answer is, it depends where you look and it depends how carefully you look at the data

**Limitations of studies and methods used to estimate the effect of exercise and longevity [17:00]**

The question of “*What is the optimal dose of exercise?*” is such an important question, so *why don’t we have the answer?*

- It suffers a lot of the same limitations that we see in nutritional studies, which rely on epidemiologic inputs
- A lot of these exercise studies are epidemiologic and they use retrospective, sometimes prospective surveys to collect data on the subjects
- Admittedly, it’s easier for people to recall patterns of exercise than food, but you could argue that exercise recall is far from perfect.
- Furthermore, a lot of times these studies are done based on the amount of exercise a person is doing at a given time and it extrapolates that into the future
- That’s especially true for studies where they’re using accelerometry which looks something like…
  - Put a band on a patient to truly track your activity for a couple of weeks
  - We are just going to assume as we follow you longitudinally that you’re going to do that same thing for the next five years
  - And we’re going to do that with thousands of people and we’ll be able to stratify the outcomes of those next five years with how much you move during these two weeks
- A lot of this stuff creates really large error bars
- Some of these studies get better and better when they start to actually *measure markers of fitness*

## Using VO2 max as a proxy for fitness to better predict mortality risk [19:15]

**A better way to predict (Peter’s approach with patients)**

- In some of the previous podcasts ([AMA #27](https://peterattiamd.com/ama27/)) we’ve talked about VO2 max as a proxy for your fitness
- Again, one approach is, “show me how much you exercise a week, various exercises, various intensities, and I’ll predict your mortality”
- Other studies say “no, just tell me how fit you are. What’s your VO2 max? How strong are you? And we’ll tell you how much risk reduction you get”

In Peter’s practice, they focus exclusively on the latter — “*We are fixated on the show me what you got*.”

- This is because Peter has the luxury of doing those things like CPET testing (VO2 max testing and the functional testing on patients)
- They do strength assessments on patients that are very detailed.
- “*We skip the part of tell me how much you’re doing and let that be a predictor of how well you’re going to do, and instead just focus on the results*”
- Of course, how much you do is a dramatic influence on your results — “*We’re very interested in how much you’re doing, but only in service of getting the results that are much more cleanly predictive of your mortality*”

**Nick’s follow up question:**

- You could take two people, similar ages, but maybe different health statuses but one has a better baseline of fitness
- And you could give them the same exercise program, but that doesn’t mean the benefits are going to be exactly the same
- Peter would be looking at what the outcome is—meaning we want to get people to a VO2 max that’s in the top 2.5%, for example
- Some people may have to work harder to get there than others, but we want everyone to get there regardless of how hard you have to work
- *Is that accurate*?
  - Taken to its extreme, yes, says Peter
  - we’re fixated on getting you as strong and fit as possible
  - it’s also the duration of time it takes to get there
  - If you have somebody who’s quite fit, it just takes less work to maintain them than somebody who is really unfit and needs to now build up a strong enough base to get back to the level before (or getting to a level that they’ve never been at)
- The good news? You’re accruing benefit across all of these.

**\*The point Peter is trying to make**: We have smaller error bars when we’re trying to make inferences about people based on very objective measurements—VO2 max, their wall sits, their grip strength—than we do by trying to extrapolate from how many MET hours per week they’re doing

\*\*\*

Tangent on an activity called “[rucking](https://www.goruck.com/pages/what-is-rucking)”:

- Peter is a big fan of “rucking” which is essentially walking/hiking with a weighted backpack
- [Michael Easter](https://twitter.com/michael_easter?lang=en) writes about rucking and will be a future [guest on the podcast](https://peterattiamd.com/michaeleaster)

## Reviewing data which support the theory of a “J-curve” relationship between exercise and longevity [24:45]

**Overview**:

- The analyst team looked at all the different studies that showed there’s an idea of this J-curve and then broke them down to really try and answer this question of whether there is a true J-curve
- In a previous AMA ([AMA #27](https://peterattiamd.com/ama27/)) looking at the VO2 max data, there wasn’t a J-curve in terms of how mortality dropped as VO2 max went up
- In fact, there was a monotonic benefit
  - There was no change in direction
  - Basically four quartiles of fitness
  - Then in the last one, it even went to the top 2.5%
  - And there was just benefit all the way along
  - Now, the majority of the benefit came from being in the bottom 25 percentile fitness to being in the 25th to 50th percentile business—as a single quartile jump had the biggest bang for your buck.

> “The take home message here if you’re listening to this and you don’t exercise is, stop listening to the rest of this podcast. Don’t worry about the J-curve. Don’t worry about the most extreme fitness. Don’t worry about any of that stuff. Just move up a quartile and you’re doing so much for your longevity.” —Peter Attia

**Reviewing the studies**

This part of the discussion is going to be focused on a very big [review article](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7431070/) (by previous [podcast guest, James O’Keefe](https://peterattiamd.com/jamesokeefe/))

- The article makes the case for this J-curve
- And we’re going to examine that and ask the question, *how robust are those conclusions?*

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-4.-ama38-1024x557.png)

**Figure 4.** The J-curve refers to an initial reduction in risk when comparing low levels of exercise to those who are sedentary. Y-axis is the HR, x-axis is level of activity grouped by publication. In some studies there is an inflection point, after which increasing exercise seems to increase mortality hazard ratios. \* Indicates incident cardiovascular disease as outcome. Source: [O’Keefe et al 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7431070/)

- There are nine studies in this review
- The article evaluates each of them through the lens of three types of participants in each study
  - Inactive (yellow circles)
    - And the inactive have all put a relative hazard ratio of one i.e., that’s the reference group
    - So, inactive, we are calling you unity risk of all cause mortality
  - The two other groups
    - Optimally active (green circle) — note that “optimally active” has different definitions for different studies
    - Then “most active” (red circle)
- If you take this graph at face value, you would say, “wow, there really looks to be a J-curve”
  - You would see that the the yellow circles—the unity ones—they have the highest mortality
  - If you get into that optimal zone, you see a huge reduction
  - if you go a little bit further into that red zone…
    - Depending on the study, sometimes you go down, sometimes you go flat, but it looks like *most* of the time, you actually uptick in mortality
  - In all but one case, you don’t erase the benefits of being optimally active, but you move away from optimally towards inactive in terms of benefits
- So taken at face value, this figure would indicate that there is “too much here” and you might want to be in this really low to moderate area of exercise

**Error bars**

Always ask this question when you look at data: ***where are the error bars?***

- Remember data points have to have an embedded uncertainty in them
  - The typical convention is to put an error bar on every data point, outside of the reference point, that gives you some confidence
  - By convention, we typically talk about a 95% confidence interval
  - If you have two dots, and one’s lower than the other, you’d think, “well, that’s clearly better than the other one”
  - But if their 95% confidence interval bars overlap, that’s not the case—we have no statistical basis on which to say that
- It turned out, all but one of the studies included in this analysis actually had the information within the papers to put the error bars on them, but they weren’t there in the original figure

So Peter’s team just went and created the exact same figure, but **added the 95% error bars:**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-5.-ama38-1024x615.png)

**Figure 5.** Source: Internal analysis taken from the [original sources](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7431070/)—error bars indicate 95% confidence intervals where available from original analyses.

-The first of these studies—[Arem](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2212267)

- If you just look at the J-curve, it looks to have an uptick
- basically if you’re optimally exercised, you have a 40% reduction in mortality
- But if you are most active, it goes up to a 30% reduction, meaning you lose 10%.
- But when you put the error bars on, ***it’s not significant***

-The next study—[Lear](https://www.umed.wroc.pl/sites/default/files/files/aktualnosci/2017/12/Lancet_71.pdf)

- This study suggests that optimally active has a 20% reduction in risk
- And most active takes you to about a 65% reduction in risk
- That one turns out to be statistically significant
- It’s also one of the two curves that says there’s no J-curve

-The [Lee](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4131752/) study

- It hits its natter at about 65% as well
- Then it upticks to about 75%
- but the 95% bars overlap, so it’s not statistically significant

-The next study—[Schnohr](https://www.sciencedirect.com/science/article/pii/S0735109714071745)

- This shows a huge reduction in risk when it goes from inactive to optimally active—an 80% reduction in risk
- The most active data suggests that the hazard ratio is 1.97, however, it’s not significant
- They couldn’t even draw the error bar on this one because it’s so big it would come off the page

-The [Paffenberger](https://sci-hubtw.hkvisa.net/10.1056/nejm198603063141003) study

- There are no error bars and it shows a J-curve
- So, again, we don’t know if it’s statistically significant

-The [Wen](https://www.natap.org/2011/HIV/PIIS0140673611607496.pdf) study

- This curve is “L shaped”
- But it’s not significant

-The [Stewart](https://www.sciencedirect.com/science/article/pii/S0735109717392665) study

- Mortality risk goes straight down as you get more active (meaning no J-curve)
- But it’s not statistically significant

-The [Armstrong](https://www.ahajournals.org/doi/pdf/10.1161/CIRCULATIONAHA.114.010296) study

- Shows a J-curve
- But also not significant

-The [Maessen](https://www.runningresearch.nl/images/PDFs/Maessen_MCP_2016_Lifelong_exercise_patterns_and_CV_health.pdf) study

- Shows a J-curve
- But also not significant

\*\*\*\*\*

## *Additional resources below for a deeper dive:*

NOTE: *To skip this section of the show notes to where the conversation picks up, scroll down to the next section “Importance of understanding p-values and statistical significance [33:30]”. Hint: use ctrl+F (for PC) or command+F (for Mac) to search notes.*

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-D.-ama38.png)

**Figure D.** All journal articles cited in O’Keefe’s paper falls into one of two categories, either the J-curve data is not statistically significant or the data shows higher activity leads to better longevity (J-curve is contradicted).

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-E.-ama38.png)

**Figure E.** 3 most illustrative papers cited in O’Keefe 2020.

***Brief overview of why these three studies in Figure E were chosen***:

**Arem:**

- This is one of the largest studies. It pools data from six studies for a total of 661, 137 subjects.
- Even with large participant numbers, the most active group >75 MET-hr/wk) had the smallest number of participants (4k vs >124k in the 22.5-40 MET-hr/wk group), leading to large CI, and no statistically significant findings

- **Illustrates that the effects of the high end of exercise on longevity is harder to study due to fewer subjects in this category – even in very large populations.**

**Lear:**

- This is an international study across seventeen different countries of varying socioeconomic statuses, which addresses a limitation of many exercise studies – that they are predominantly performed on white populations of higher socioeconomic status.
- Questionnaire records both occupational and recreational physical activity.
- The J-curve in this study used by O’Keefe is pulled from the recreational-only physical activity – likely to compare to other recreation studies (Arem is leisure time activity, Schnor is jogging, etc)
  - Ignores that occupational + recreational physical activity does not have a J-curve.
  - Recreational-only subset compares to those who have 0 MET-hr of recreational activity – not sedentary people. By contrast the other two studies compare to 0 MEt-hr of LTPA or non-runners

- **Illustrates no upper bound to the effects of physical activity on longevity in a diverse subject pool.**

**Schnor:**

- By the O’Keefe figure, this study has the highest HR for the most active group,  using data from the Copenhagen Heart Study, which assessed different parameters of running on ACM.
- HR increased from light to moderate to heavy joggers – but the problem here is one of sample size.
  - Light (n = 570), Moderate (n=252), Heavy (n = 36)
  - No indication for cause of death – 2 deaths out of 36 heavy joggers leads to a high hazard ratio with a very large CI
- Another study of runners (Lee 2014) evaluated over 13,000 runners and did not replicate any J-curve findings (drop in HR with any running, but no statistically significant uptick).

- **Illustrates the lack of repeatability in small sample sizes and why confidence intervals are important.**

## Arem 2015

**Background:**  [Arem](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2212267) 2015

- **Objective:**  To quantify the dose-response association between leisure time physical activity (LTPA) and mortality, and define the upper limit of benefit or harm associated with increased levels of physical activity.
- **Data collection**:  Population-based prospective cohorts in the United States and Europe with self-reported LTPA were collected, pooling data from 6 studies in the National Cancer Institute Cohort Consortium (baseline 1992-2003). Included studies had at least five years of follow-up and at least 1000 deaths among non-Hispanic, white participants. There were 661,137 participants with 116,686 deaths, median age 62 yrs. Each LTPA was associated with an estimated MET value and MET-hrs were calculated based on survey answers to time spent on various LTPA activities. Participants were grouped into activity levels based on estimated MET-hrs and intensity.
- **Activities recorded**:  Surveys asked for weekly time spent over the prior year walking, jogging, running, swimming, tennis, racquetball, bicycling, aerobics, and dance. Walking for exercise was the largest contributor to overall MET hours per week.
- **Follow up time**:  Average of 14.2 yrs.
- **What the data suggests**:  Performing 0.1 – 7.5 MET hrs/wk reduces mortality risk by 20% compared to sedentary participants. Maximum benefits occur between 22.5 – 75 MET hrs/wk with 39% reduced risk. At ≥ 75 MET hrs/wk, there was a 31% benefit with a larger 95% CI. The participants at the highest level of activity tended to be younger, never smokers, lower BMI, and fewer comorbidities.
- **Supports J-curve?**:  No. Authors state that the uptick in mortality at highest LTPA levels was not statistically significant.

**Study Limitations**

- Bias inherent to self-reporting questionnaires.
- >30x participants in moderate exercise vs high intensity (124k participants in “optimal group vs 4k in highest exercise volume group). This is captured by the large confidence interval left out of O’Keefe graphic.
- HR adjustments appear highly suspect because the HR for all vigorous exercisers was higher than moderate exercisers at equivalent MET hr/wk, which does not align with the overall literature.
- Uptick in mortality at highest PA level not stat. sig. because CI is large
- MET-hr/wk intensities were assigned using absolute compendium-derived values that may not account for individual variation

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-F.-ama38.png)

**Figure F.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-G.-ama38.png)

**Figure G.** Figure from [Arem](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2212267) 2015. The y-axis is the mortality risk. The x-axis indicates the ranges of MET hrs/wk an individual reported. The bottom arrow shows the multiple of the recommended 150 min/wk of moderate-vigorous physical activity, equivalent to 7.5 MET hrs/wk. Adjusted values are given with 95% CI. The uptick for > 75 MET hrs/wk is not stat. sig.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-H.-ama38.png)

**Figure H.** Table 2 from [Arem](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2212267) 2015. This table compares levels of moderate intensity activity and levels of vigorous intensity activity, where moderate-intensity (3.0 to <6.0 METs) and vigorous-intensity (≥6.0 METs) activities were separated but used to create mutually adjusted models. Each group was stratified by the number of MET hrs/wk spent in that exercise intensity.

- Firstly, authors offer zero explanation of this table, it is left to the reader to assume what is being presented.
- This subgroup analysis had a total of 348,725 subjects – **each subject is represented in both the moderate and vigorous analysis** because the survey asks each person for time spent in either category. Ex. There are 52, 848 subjects in the 0 MET-hr category of the J-curve. These subjects will be in the 0 MET-hr for both moderate and vigorous activity. There are 528 subjects who ***only*** participate in vigorous activity, for a total of 53, 376 subjects in 0 MET-hr of moderate LTPA, and 190,750 subjects who ***only*** participate in moderate LTPA leading to 243, 598 participants in the 0 MET-hr for vigorous activity.
- It appears that the HR for all vigorous activity levels is higher than moderate activities at equivalent MET hr/wk. This seems highly suspect and may be a result of incorrect adjustments.
- When observing the yellow highlighted boxes, both groups had equivalent # of participants but there were 2x as many deaths in the moderate group, yet their HR is still lower than the vigorous group. This seems highly suspect and may be a result of incorrect adjustments.

For this table, In intensity analyses, categories of MET hours per week were adjusted (0, 0.1 to <7.5, 7.5 to <15.0, 15.0 to <30.0, and ≥30.0) owing to a lower range of MET hours per week for each intensity and fewer deaths in the highest categories.

**Note from Sam: Of the 105,127 participants who do some amount of vigorous exercise, most of them also reported moderate LTPA- we just don’t know what volume (528 report only vigorous LTPA). While vigorous LTPA doesn’t show a trend with increasing volume, it is unclear how much that increased volume of vigorous activity may be muted by heterogeneous volume of moderate activity in each level of vigorous MET-hr/wk of vigorous activity, especially due to 70% of subjects being in the 0 MET-hr/wk in the vigorous analysis.**

**Summary:**

- In a prospective pooled analysis of six cohorts, volume of self-reported LTPA as estimated by MET-hr/wk was inversely associated with mortality.  From this study the authors concluded that the observed mortality benefit threshold started at approximately 22.5-40 MET-hr/week with no statistically significant excess risk at 75 MET-hr/week or more, not supporting the J-curve theory of dose-response for exercise.

## Lear 2017

**Background:**  [Lear](https://www.umed.wroc.pl/sites/default/files/files/aktualnosci/2017/12/Lancet_71.pdf) 2017

- **Objective:** Prospective Urban Rural Epidemiologic (PURE) study done in 17 countries of various income levels examined whether physical activity is associated with lower risk of mortality and CVD in countries at varying economic levels and whether these associations differ by type of physical activity. (Are the protective effects of physical activity (PA) the same for high income countries where PA is mainly recreational vs. low income countries where PA is mainly non-recreational?)

- **Data Collection:** Individuals aged 35–70 years without pre-existing CVD were surveyed to record sociodemographic factors, medical history, lifestyle behaviors, and risk factors. Analysis was performed on 130,843 participants living in urban and rural areas of selected cities between Jan 2003 and Dec 2010 who completed the International Physical Activity Questionnaire (IPAQ) which included 1-week total PA. Countries included  (Canada, Sweden, UAE, Argentina, Brazil, Chile, Poland, Turkey, Malaysia, South Africa, China, Colombia, Iran, Bangladesh, India, Pakistan, and Zimbabwe).

- **Activities:** A total of occupation, transportation, housework, and recreational activity reported in metabolic equivalents (MET)×minutes per week (Converted to MET-hr/wk). Physical activity was also reported in minutes per week of physical activity by intensity (low, moderate, vigorous) .

- **Follow up Time:** Average follow up duration 6.9 years

- **What the data suggests:** Higher physical activity was associated with a lower risk for mortality and incidence of major CVD. As participating in physical activity (especially in daily life) is inexpensive, physical activity is a low-cost approach to reducing deaths and CVD that is applicable globally with large potential effect.

- **Supports J-curve?:** **This study does not support the J-curve theory. There was statistical significance of difference in all cause mortality between both low and moderate vs high levels of physical activity**

- - **Did not observe any adverse effects of physical activity on outcomes even in the approximately 9000 participants who reported over 2500 minutes per week of moderate intensity physical activity (equivalent to 17 times that of  the physical activity guidelines).**

**Study Limitations**

- Inaccurate claims from self-reporting questionnaires.

- The study aimed to compare HR of individuals participating in any physical activity and those who participated in recreational activities. Self-reported recreational activity was almost non-existent for countries of middle and lower income with most reporting 0, meaning the information used to create the graph (Fig. b, below) relies on much fewer data points, plus the CI appears to show that the J-curve is non-significant.
- Possible misclassification in obtained information on of medical event or cause of death
  - Death certificates (available in 100% of deaths), medical records (50-80% available), household interviews, and other sources of information

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-I.-ama38.png)

**Figure I.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-J.-ama38.png)

**Figure J.** Hazard ratios and 95% CI for all-cause mortality and major CVD, all-cause mortality, or major CVD by level of physical activity.c  Statistical significance of difference in all cause mortality between both low and moderate vs high levels of physical activity.  Data adjusted for age, sex, education, country income level, urban or rural residency, family history of CVD, and smoking status; taking into account household, community, and country clustering. There were 3155 events for all-cause mortality and major CVD, 2041 events for all-cause mortality, and 1723 events for major CVD. The p values of the first column show the significance of each comparison and second column shows the significance of the overall effect of physical activity. Low physical activity=<600 MET×min per week (<10 MET-hr/week). Moderate physical activity=600–3000 MET×min per week (10-50 MET-hr/week). High physical activity=>3000 MET×min per week (>50 MET-hr/week). CVD=cardiovascular disease. Major CVD=CVD mortality plus incident myocardial infarction, stroke, or heart failure. MET=metabolic equivalents.

***So where does the J-curve/U-curve shown in O’Keefe come from?***

- When analysis is limited to recreational activity only Figure (B) below
- Problematic for several reasons
  - 55% of participants had no recreational physical activity but 82% met physical activity guidelines ≥10 MET-hr per week and ≥150 min per week of moderate intensity physical activity.
  - Vast majority of subjects (72.5%) fall into the 0-600 MET-min category but 0 MET-hr spent on recreational activity does not mean 0 MET-min spent on any physical activity
    - Only 2.9% of study population participated in high physical activity (≥50 MET-hr/wk that derived exclusively from recreational physical activity compared with 37.9% of participants who attained this through non-recreational physical activity.
    - There is an uptick leading to a HR >1 of low and low-middle income with high levels of recreational activity, but with large confidence intervals
      - Is there another factor that would increase risk of mortality and CVD for individuals  in low and low-middle income countries that participate in more recreational activities?
  - Hazard ratios are normalized to population at the 0 MET-hr population
    - Since many of the subjects with 0 MET-hr recreational activity had high levels of occupational physical activity – the normalizing group already has the benefits of exercise
    - Different outcome than comparing to sedentary individuals

- - **Why might this curve have been included?**

- - - Other studies Arem, Lee, Schnor, etc are all based on leisure-time physical activity, so O’Keefe extracted information only from Lear’s recreational activity data
  - Given that one of the criticisms of exercise research is that it largely focuses on white, higher socioeconomic subjects, it is a disservice to not include the full results

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-K.-ama38.png)

**Figure K.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-L.-ama38.png)

**Figure L.** Comparison of physical activity and mortality and major CVD (A) Adjusted HR (black line) and 95% CI (red lines) for mortality and major CVD compared with total physical activity which includes both recreational and occupational or other non-recreational physical activity. (B) Adjusted HR for mortality and  major CVD compared with *recreational physical activity only*. Note that the number of subjects who fall into the category of 0-600 MET-min/wk for total physical activity is 21,690 (16.6%), but is 94, 893 subjects (72.5%) when HR is evaluated for recreation-only.  Models were adjusted for age, sex, education, country income level, urban or rural residency, family history of CVD, and smoking status, taking into account household, community, and country clustering.

**Summary:**

This study addresses some of the limitations of previous exercise research that has predominantly focused on non-Hispanic white individuals of higher socioeconomic standing by surveying internationally across countries of various income levels. Higher physical activity was associated with a lower risk for mortality and incidence of major CVD, which does not support the J-curve theory. There were no observed adverse effects of physical activity on outcomes even in the approximately 9000 participants who reported over 2500 minutes per week of moderate intensity physical activity (equivalent to 17 times that of  the physical activity guidelines). O’Keefe only reported data on the “recreational” activity recorded from the surveys that showed a J-curve, however that data was based on low reporting and the CI indicated no statistical significance in the uptick.

## Lee 2014

**Background:**   [Lee](https://www.sciencedirect.com/science/article/pii/S0735109714027466) 2014

- **Objective:** Evaluate the associations of running with all-cause and cardiovascular mortality risks and construct a dose-response curve of running.

- **Data collection:** Aerobics Center Longitudinal Study is a prospective, observational, cohort study including 55,137 adults with a mean age of 44 yrs who received a medical exam and questionnaire between 1974 and 2002. Running or jogging activity during the past 3 months was assessed at baseline by the physical activity questionnaire, including 4 questions about duration, distance, frequency, and speed. Cardiorespiratory fitness (VO2max) was measured with a treadmill exercise test.

- - Individuals reporting myocardial infarction (MI), stroke, or cancer at baseline and those with <1 year of mortality follow-up were excluded to minimize potential bias due to serious undetected underlying diseases on mortality.

- - Clinical examination also measured resting blood pressure, blood glucose, cholesterol, BMI, and health behaviors (smoking, alcohol consumption, and LTPA), physician-diagnosed medical conditions, and parental history of CVD.

- **Activities recorded:** Running or jogging and total amount of other physical activities except running (cycling, swimming, walking, basketball, racquet sports, aerobic dance, and other sports-related activities).

- **Follow up time:** Mean follow up time 14.7 years (through December 31, 2003)

- **What the data suggests:** Overwhelmingly, the data favor running in reducing the hazard ratio of all cause mortality and cardiovascular mortality. VO2max is related to mins/week spent running.
- **Supports the J-curve?:** Hazard ratio alone follows a J-curve trajectory but with large confidence intervals that **do not** show any statistical significance.

**Study Limitations:**

- This cohort is primarily college-educated, non-Hispanic white adults from middle to upper socioeconomic strata
- The use of self-reported running during the past 3 months, which is longer than conventional physical activity questionnaires that include the previous 1 week or 1 month (Recall bias towards over reporting activity especially with longer windows)
- Lack of adequate dietary information.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-M.-ama38.png)

**Figure M.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-N.-ama38.png)

**Figure N.** Demographic and clinical metrics across runner and non-runner groups. Note that metrics are roughly the same lifestyle choices such as drinking and participation in other physical activity. Most active runners have a different distribution of BMI, are less likely to have ever smoked, and have higher cardiorespiratory fitness (VO2max).

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-O.-ama38.png)

**Figure O.** Running has a significant impact on all cause and cardiovascular mortality at any dose. The reference group for all analyses is non-runners. All hazard ratios (HRs) were adjusted for baseline age (years), sex (not in sex-stratified analyses), examination year, smoking status (never, former, or current [not in smoking-stratified analyses]), alcohol consumption (heavy drinker or not [not in alcohol drinking-stratified analyses]), other physical activities except running (0, 1 to 499, or ≥500 MET-min/week), and parental cardiovascular disease (yes or no). Unhealthy was defined as the presence of 1 or more of the following health conditions: abnormal electrocardiogram (ECG), hypertension, diabetes, or hypercholesterolemia. Heavy alcohol drinking was defined as >14 and >7 drinks per week for men and women, respectively. BMI = body mass index.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-P.-ama38.png)

**Figure P.** Participants were classified into 6 groups: non-runners and 5 quintiles of each running distance, frequency, total amount, and speed. All hazard ratios (HRs) were adjusted for baseline age (years), sex, examination year, smoking status (never, former, or current), alcohol consumption (heavy drinker or not), other physical activities except running (0, 1 to 499, or ≥500 MET-min/week), and parental cardiovascular disease (CVD) (yes or no). The bars indicate 95% CI, and HRs are shown next to the bars. MET = metabolic equivalent. Highlighted box indicated data used by O’keefe from 0, 1200-1839, and >1840 MET-mins groups.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-Q.-ama38.png)

**Figure Q.** Combined graphic of HR curves above without CI. Hazard ratios (HRs) of all-cause and cardiovascular mortality by running characteristics (weekly running time, distance, frequency, total amount, and speed). Participants were classified into 6 groups: nonrunners (reference group) and 5 quintiles of each running characteristic. All HRs were adjusted for baseline age (years), sex, examination year, smoking status (never, former, or current), alcohol consumption (heavy drinker or not), other physical activities except running (0, 1 to 499, or >500 MET-minutes/week), and parental history of cardiovascular disease. All p values for HRs across running characteristics were <0.05 for all-cause and cardiovascular mortality compared to non-runners except for running frequency of >6 times/week (p = 0.11) and speed of <6.0 miles/h (p = 0.10) for cardiovascular mortality.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-R.-ama38.png)

**Figure R.** Figure from [Lee 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4131752/) adults, aged 18 to 100 years (mean age, 44) is a prospective, observational cohort study with a mean follow-up of 15 years. Cardiorespiratory fitness was assessed using a maximal treadmill exercise test and total weekly running time was calculated based on surveyed average duration of running multiplied by the weekly frequency. For the average age elite VO2max in men is <14.7 METs, for women >13.3 METs. Can get close to this category of CRF with ~ 4 hours of weekly running, for an average pace of 10 min/mile, that would be 40 weekly MET-hours.

**Summary****:**

This study found that runners had an overall reduced HR for all cause mortality and cardiovascular mortality compared to non-runners, regardless of self-reported duration, distance, frequency, and speed. Running even at lower doses or slower speeds was associated with significant mortality benefits. The uptick in HR at the highest activity levels did not appear to be significantly different from HRs found in moderate levels of activity, so this study does not support the J-curve.

## Schnor 2015

**Background:**  [Schnor](https://www.sciencedirect.com/science/article/pii/S0735109714071745) 2015 (co-authored by O’Keefe)

- **Objective:** Determine the long-term effects of pace, quantity, and frequency of jogging on all-cause mortality.

- - **This study is similar to Lee et al. (above), but with a smaller number of participants, especially in the most active and strenuous jogging group.**

- **Data collection:** Data collected from the Copenhagen City Heart study, and was a prospective, observational, cohort study following 1098 healthy joggers and 3950 healthy non-joggers. Questionnaires were used to compile weekly quantity of jogging, frequency of jogging, and the subject’s own perception of pace (slow, average, fast). Baseline data was recorded between 2001-2003 for participants aged 20-95 yrs. The joggers were subdivided into 3 groups according to dose of jogging:  light (6 METs), moderate (6-12 METs) or strenuous (≥ 12 METs).

- **Activities recorded:** Authors recorded only jogging.

- - Light jogging was ~5 mph, < 2.5 h/wk, and ≤ 3x/wk.

- - Strenuous jogging was > 7 mph, > 4 h/wk or > 2.5 h/wk for >3x/wk.

- - Moderate jogging encompasses a regimen in between the two groups, either being faster, having greater quantity, or greater frequency than light joggers but less than strenuous joggers.

- **Follow up time:** Average follow up time of 12 years (up to April 2013)

- **What the data suggests:** The data suggests that light to moderate intensity of jogging has a beneficial effect on mortality, but that strenuous and high volume can have a detrimental effect on mortality, creating a “U-shaped” association.
- **Supports the J-curve?:** Even slow jogging (6 METs) corresponds to vigorous exercise and strenuous jogging corresponds to very heavy vigorous exercise (≥12 METs), which when performed for decades could pose health risks, especially to the CV system. This would support a J-curve if the strenuous exercise group wasn’t nearly 16 times smaller than the light joggers and there were related causes of death in this group (e.g. CVD versus accidental). Low number of participants in the strenuous group and extremely large 95% CI does not support the J-curve.

**Study Limitations:**

- Order of magnitude more participants in sedentary and light joggers than strenuous joggers (576 vs 40)
- Note that in the recreated plot from O’Keefe the marker for most active group is lower to not zoom the graph out) and the CI is left off because it extends well outside the bounds of the graph
- There were few individuals in the most active group (n=36, fully adjusted) and only 2 deaths (no cause of death identified), resulting in an enormous CI, group too small to be meaningful

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-S.-ama38.png)

**Figure S.**

**While there is the smallest of differences between these two confidence intervals, it would be premature to conclude a J-curve from this study (Lee has a larger number of participants and still saw no significant J-curve trends). The very small number of participants in the strenuous jogging category, and a lack of information about the small number of deaths makes this data unreliable.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-T.-ama38.png)

**Figure T.** Table. Characteristics of pace, frequency, and duration of jogging to determine categorization.

- To estimate MET-hr/week from running:
  - Light joggers:  5 mph (~ 6 METs), <2.5 hrs/wk = 15 MET hrs/wk (HR 0.22, CI 0.10 to 0.47)
    - Might be an overestimation of reduction in HR? Equivalent HR in Lee et al was 0.72 (900 MET-mins/week)
  - Strenuous jogger:  7 mph (> 12 METs), >4 hrs/wk = >48 MET hrs/wk (HR 1.97, CI 0.48 to 8.14)
    - From Lee:
      - Joggers who ran at > 7 mph had HR of 0.63-0.65
      - Joggers who ran >3 times per week had HR of 0.67-0.78

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-U.-ama38.png)

**Figure U.** Forest plot – indicating number of participants and adjusted hazard ratios for different intensities of jogging. O’Keefe used adjusted HR in original plots.

- Even though there might be statistical significance in this study when comparing HR of light and strenuous joggers, the present limitations of the study and the discrepancy between this study and Lee should curb any conclusions drawn about a J-curve with respect to the jogging doses studied.

**Summary:**

In the Copenhagen City Heart Study, joggers were divided into 3 groups of light, moderate, and strenuous intensities (METs) depending upon a combination of speed, duration, and frequency of jogging per week. The authors claimed there was an increase in HR for strenuous joggers, but the data was based on 2 deaths within the high MET group, creating an outrageous 95% CI that obviously showed no significance. The data from the joggers in this study do not support the J-curve.

## Paffenbarger 1986

**Background:**  [Paffenbarger](https://sci-hubtw.hkvisa.net/10.1056/nejm198603063141003) 1986

- **Objective:** To study the effect of exercise in delaying all-cause mortality in male Harvard alumni.

- **Data collection:** In 16,936, male Harvard alumni (ages 35-74, and were in college in 1916-1950), LTPA, daily physical activity, and other health characteristics were surveyed during their college and post-college time, with follow up data on influences of mortality and estimated length of life through mailed questionnaires between 1962-1966. Energy expenditure (in kcal) was estimated for all surveyed physical activities, then groups were stratified by weekly energy use.

- **Activities recorded:** City blocks walked, number of stairs climbed, types of sport participation and time spent each week on sport participation. Each activity was associated with a fixed energy expenditure (kcal).

- **Follow up time:** Range of 12-16 years of follow up

- **What the data suggests:** **Increasing physical activity decreases all-cause mortality.** When stratified by age, and energy expenditure binned into <500, 500-2000, and >2000 kcal, all-cause mortality monotonically decreased with increasing activity levels. When lumping everyone above 3500 kcal into one bin, there appears to be an uptick in deaths when compared to those with lower kcal use that were grouped into smaller 500 kcal bins. These lower kcal groups also had lower number of participants, so the data is less reliable for those bins. Meaning, the “uptick” may only be a statistical anomaly.
- **Supports the J-curve?:** Not from age-stratified curves. For Data based on kcal/ wk energy expenditure, it is impossible to conclude without more information.

**Study Limitations:**

- Harvard alumni are not necessarily representative of the general population
- Fixed kcal values (e.g. 28 kcal per 70 stairs climbed or 56 kcal per 7 city block walked (7/12 miles))
- No confidence intervals are reported – so statistical significance can’t be concluded.
- No reported number of subjects across each group (reported prevalence in % man-years)

- - Physical activity was binned in 500 kcal increments, except for the highest activity group which was PA > 3500 kcal.

- - - The highest activity group (>3500 kcal) had a prevalence of 18.1 % of man-years, compared to 3000-3499 kcal which had a prevalence of 5.0% man-years but a smaller HR.
    - Likely indicates differences in group size that would have shown up in CI and statistical analysis
- Self-reported questionnaires

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-V.-ama38.png)

**Figure V.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-W.-ama38.png)

**Figure W.** Data used by O’Keefe are <500, 3000-3499 kcal, and >3500 kcal

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-X.-ama38.png)

**Figure X.**

**Summary:**

This study on Harvard men aimed to find the association between kcal expenditure from daily activities (walking to work, stairs climbed, sports) and all-cause mortality. When energy expenditure was binned into <500, 500-2000, and >2000 kcal, all-cause mortality decreased with increasing kcal expenditure in all age groups. However, when bin-width was reduced to 500 kcal each, there were more deaths in the > 3500 kcal group, but the group also had much higher man-years than the lower kcal groups. This change in statistics due to cherry-picking bin widths can be misleading, especially if populations from one group far outnumbers other groups. Altogether, the J-curve is not supported by the data in this publication.

## Wen 2011

**Background:**  [Wen](https://www.natap.org/2011/HIV/PIIS0140673611607496.pdf) 2011

- **Objective:** Assessment of health benefits of exercise volume in a Taiwanese population, with a focus on the low end of exercise compared to inactive, but subjects of all activity levels were recruited.

- **Data collection:** In this prospective, observational, cohort study of 416,175 Taiwanese older than 20 yrs, participants filled out a LTPA questionnaire during 1996-2008 regarding LTPAs that they did during the previous month. Groups were separated into 5 categories of exercise volumes (METs). Other demographic information such as age, sex, education, physical labor at work, smoking, drinking, diabetes, hypertension, and history of cancer. Clinical values of fasting blood glucose, systolic blood pressure, total cholesterol, and BMI.

- **Activities recorded:** Light (e.g., walking), moderate (e.g., brisk walking), medium vigorous (e.g. jogging), or high-vigorous (e.g., running). To calculate MET-hrs, MET values of 2.5 for light, 4.5 for moderate, 6.5 for medium-vigorous, or 8.5 for high-vigorous exercise were used as well as the duration per week spent on the different LTPA activities within the previous month.

- **Follow up time:** Thirteen year study period with an average follow up period of 8 years.

- **What the data suggests:** The data suggests there is a monotonic decrease in HR with increasing PA, there is no J-curve. Couldn’t find the data for the “optimal” activity that would recreate original curve – possibly error in original O’keefe graph
- **Supports the J-curve?:** No, there is a monotonic decrease in all cause mortality with increasing exercise volume, although HR of patients performing high and very high activity levels were not significantly different.

**Study Limitations:**

- Potential bias in reported activity levels from questionnaires reporting the last 1-month of activity.
  - Study used two consecutive visits to show consistency in reporting with statistically insignificant HR differences
- Cohort was recruited from participants with above average socioeconomic status which may not be generalisable to all east Asians.
- The largest volume of exercise reported in this study was 45.2 MET-hr/wk (+/- 15.4), which would not be able to evaluate any mal effects of exercise volumes greater than 75 MET-hr/wk
- Only leisure-time activity was studied of the possible physical activity  from work, transportation, household, and LTPA.
  - Based on Lear, occupational physical activity can have the same beneficial effects on all-cause mortality as leisure activity.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-Y.-ama38.png)

**Figure Y.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-Z.-ama38.png)

**Figure Z.** Hazard ratios as a function of exercise volume. Comparisons for all levels of exercise were compared to the inactive group. All cause mortality (A), all cancer (B), cardiovascular disease (C), and diabetes mellitus (D).

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AA.-ama38.png)

**Figure AA.** Relation between daily physical activity and reduction in all-cause mortality compared with inactive individuals. Every additional 15 min of daily exercise (up to 100 min a day, then plateau) is expected to generate an additional reduction of 4% all-cause mortality. Vigorous exercise generates these same reductions in mortality on a shorter timescale. Red line is the average of all participants regardless of exercise type.

**Summary:**

In this assessment of health benefits of exercise volume in a Taiwanese population, all-cause mortality monotonically decreased with increasing exercise volume. Vigorous exercise imparted reduction in all-cause mortality in a shorter duration of exercise than moderate intensity exercise and vigorous exercise has a higher ceiling for risk reduction. Both moderate and vigorous exercise intensities plateau in their conferred benefits, but there is no evidence from this study showing a J-curve or increase in risk at the highest level of exercise. However, the largest volume of exercise reported in this study was 45.2 MET-hr/wk (+/- 15.4). In other studies, such as Arem don’t see the potential uptick until 75 MET-hr/wk or greater, which this study would not be able to evaluate.

## Stewart 2017

**Background:**  [Stewart](https://www.sciencedirect.com/science/article/pii/S0735109717392665) 2017

- **Objective:** Analyze association of self-reported exercise and mortality in patients with stable coronary heart disease (CHD). To determine if doubling exercise volumes (either by increasing intensity or duration) was associated with decreasing all-cause mortality.

- **Data collection:** The Stabilization of Atherosclerotic Plaque by Initiation of Darapladib Therapy (STABILITY trial during Dec 2008 – Apr 2010) had a total of 15,486 patients randomly assigned to take darapladib (inhibitor of lipoprotein-associated phospholipase A2) from 39 countries who had chronic stable CHD prior to surgical interventions and had at least one CV risk (i.e. >60 yrs old, smoker, etc.). Participants filled out a baseline questionnaire about hours each week spent participating in mild (< 3 METs), moderate (3-6 METs), and vigorous exercise (> 6 METs).

- **Activities recorded:** Mild physical activity: easy walking, yoga, Tai Chi, mild house work. Moderate physical activity: fast walking, jogging, aerobics, gardening, bicycling, dancing, swimming or house cleaning Vigorous exercise: running, lifting heavy objects, playing strenuous sports, or strenuous work

- **Follow up time:** Median follow up time of 3.7 years

- **What the data suggests:** In this study which groups subjects into equal-sized tertiles, there is a reduction in all-cause mortality with increasing levels of physical activity.
- **Supports the J-curve?:** This was one of the included studies in O’Keefe that did not suggest a J-curve, and that conclusion remains, in both the condensed analysis of tertiles of activity, as well as a more extended analysis by MET-hrs. There is a statistically insignificant increase in HR for non-CV death between the intermediate activity group and the most active group.

**Study Limitations:**

- Activity reported by MET range intensity. Highest activity group includes all vigorous exercise regardless of total MET-hrs
- Shorter overall follow-up time than other studies (median follow-up 3.7 years compared to next shortest (Lear – 6.9 years)

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AB.-ama38.png)

**Figure AB.**

**\*\*Note the large standard deviation on the most active tertile. This is because participants who performed** ***any*** **vigorous exercise were put into the most active group, regardless of total MET-hrs.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AC.-ama38.png)

**Figure AC.** HR for each tertile of activity. All cause mortality and CV death risk are reduced with increasing exercise. Non-CV death has a statistically insignificant uptick from intermediate to most active.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AD.-ama38.png)

**Figure AD.**

- **MET-hrs/wk shown with each progressive interval doubling exercise volume. There is a monotonic trend in risk reduction with increasing MET-hrs. There are fewer participants in the >160 MET-hrs/wk category, indicated by the larger confidence interval. The inset graph is plotted on a linear axis of MET-hrs. Although there is diminishing returns in all-cause mortality risk reduction with increasing MET-hrs, there is no evidence of a J-curve in this study. The number of subjects in each stratification is listed in the table below.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AE.-ama38.png)

**Figure AE.**

**Summary:**

In an international study of patients with coronary heart disease, self-reported exercise intensity and volume was associated with decreased all-cause mortality. CV death has a statistically significant reduced risk from the least active tertile to the most active tertile. Increasing exercise volume (MET-hr/wk) was associated with a monotonically decreasing risk reduction of all-cause mortality. At the highest volumes of exercise, there may be diminishing returns on increased exercise volume, but there was no significant increase in all-cause mortality risk at the highest exercise volumes, which does not support the J-curve theory.

## Armstrong 2015

**Background:**  [Armstrong](https://www.ahajournals.org/doi/pdf/10.1161/CIRCULATIONAHA.114.010296) 2015

- **Objective:** To assess the relationship of frequency, duration, and type of physical activity in women with incident CHD, cerebrovascular disease, and venous thromboembolism (VTE), excluding the first 4 years of followup from recruitment into the study to limit the possible effects of reverse causation attributable to preclinical disease.

- **Data collection:** The Million Women study recruited 1.1 million women with mean age of 56 years between 1996-2001 in the UK without prior vascular disease, collecting their demographic data and self-reported frequency and duration of strenuous physical activity (defined by any work or exercise causing sweating and a fast heart beat). Approximately 3 yrs later, a resurvey questionnaire was sent to participants to evaluate change in levels of activity. METs were calculated as excess energy expenditure above baseline sedentary value of 1.0 METs. This was calculated for each activity by subtracting 1 from the multiplier listed in the compendium, and multiplying this MET value by the number of hours reported at the 3-yr follow up survey.

- **Activities recorded:** Housework, gardening, walking, cycling, or strenuous activity.

- **Follow up time:** Average follow up time of 9 years (excluding the first four years to minimize effects of unknown prior existing conditions).

- **What the data suggests:** The data showed that women who engaged in physical activity had a lower incidence of CHD, cerebrovascular disease, and VTE than women who were inactive. Overall, the main difference in risk was between those doing some activity versus none, with the lowest risks being observed among women doing moderate amounts of activity. There was an uptick in CVD incidence for women who perform strenuous activities 7 d/wk, but this group also had a much higher percent of current smoking and lower socioeconomic status. Women with performing strenuous activity 7 d/wk were more likely to be smokers and of lower income (25.6% and 20.1%, respectively) compared to those who performed strenuous activity 1-6 d/wk (under 15.5% and 13.9%, respectively).
- **Supports the J-curve?:** The data does support the J-curve, however even after adjustments, there may be residual confounding factors from the much higher percentage of smoking and lower economic status among the most active group of women who performed strenuous activity 7 d/wk.

**Study Limitations:**

- MET-hrs for all PA reported at the 3-year resurvey was used including walking, gardening, cycling, housework, and any work or exercise causing sweating or a fast heartbeat
- Women performing any exercise and strenuous exercise 7 d/wk were more likely to be smokers and of lower income compared to those who only exercised or active 1-6 d/wk. There are likely residual confounders in the most active groups after any adjustments are made, so statistics from this high active group may be less reliable.
- >10 hrs/week of housework had a HR >1 for coronary heart disease – likely indicates other contributing factors

**NOTE: This study does not report all cause mortality, so the table constructed for other studies is omitted for Armstrong 2015**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AF.-ama38.png)

**Figure AF.** Demographics and Characteristics of the Million Women study. Exercise is not stratified by MET-hrs but by frequency of exercise in days per week. The J-curves for coronary heart disease seen with daily exercise are accompanied by curves of other factors (smoking, socioeconomic status) that still may have residual effects even in adjusted hazard ratios. Ex. The percent of current smokers who perform daily strenuous exercise is the same as those who are inactive. The red box shows average MET-hr per week for all activity and strenuous activity. The extremely large standard deviations make all of these activity volumes virtually indistinguishable from each other.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AG.-ama38.png)

**Figure AG.** Absolute risks of coronary heart disease, cerebrovascular disease, and venous thromboembolism per 100k with 95% confidence intervals for both strenuous and any physical activity excluding the first four years of follow-up.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AH.-ama38.png)

**Figure AH.** Relative Risks and 95% CI of incident vascular diseases for specific activities. The compendium of physical activities indicates METs per activity. Excess METs are calculated from the METs of a specified activity minus 1 (i.e. METs in excess of being sedentary) multiplied by the time in the activity. Note that there are only three categories. MET-hrs/wk are divided up into smaller intervals in other studies to better describe dose-response of exercise. The hazard ratios are likely affected by pooling 0-40 MET-hrs/week compared to the studies that compare to a mostly inactive group.

**Summary:**

This study is **NOT**  evaluating dose-response of exercise on all-cause mortality, so is less comparable to other studies. This study reported incident coronary heart disease, cerebrovascular events, and venous thromboembolisms as a function of exercise intensity (strenuous-only or all) and frequency (number of days per week). Housework, gardening, walking, cycling, or strenuous activity were the reported activities, but these activities are very susceptible to individual variation (cycling was an infrequent activity) and strenuous activity was given a broad definition of any activity that led to sweating and a fast heart rate. For example, within the right column of J-curve plots for any physical activity, a participant might go on a leisurely daily walk, and that individual would be grouped with someone who runs daily (strenuous exercise).  Additionally, women performing any exercise and strenuous exercise 7 d/wk were more likely to be smokers and of lower income compared to those who only exercised or active 1-6 d/wk. There are likely residual confounders in the most active groups after any adjustments are made, so statistics from this high active group may be less reliable.

## Maessen 2016

**Background:**  [Maessen](https://www.runningresearch.nl/images/PDFs/Maessen_MCP_2016_Lifelong_exercise_patterns_and_CV_health.pdf) 2016

- **Objective:**  To determine the relationship between lifelong exercise dose and the prevalence of cardiovascular disease (CVD, includes myocardial infarction, stroke, or heart failure) and cardiovascular risk factors (CVRF, includes hypertension, hypercholesterolemia, or T2 diabetes) morbidity. Also, to confirm or reject the U-shaped association between exercise and CV morbidity.
- **Data collection**:  The population-based observational, retrospective Nijmegen Exercise Study included 12,440 participants and collected self-reported PA information from online questionnaires from June 1, 2011 through December 31, 2014. Survey asked for lifelong exercise habits since 18 yrs old. Mean age of participants was approximately 50 yrs.
- **Activities recorded**:  Surveys asked for  (1) exercise time (hours) per week and (2) self perceived intensity (light/moderate/vigorous). This was asked for 4 age periods:  (1) 18 to 29 years, (2) 30 to 49 years, (3) 50 to 64 years, and (4) 65 years and older.
- **Follow up time**:  Median 32 yrs (including self reported activities since 18 yrs)
- **What the data suggests**:  The study found a regular low to medium dose of exercise significantly reduced CV morbidity without further risk reduction at higher doses. Data suggests a curvilinear relationship between lifelong exercise patterns and cardiovascular health.
- **Supports J-curve?**:  No. Authors explicitly state “these findings contradict recent studies suggesting a potential U-shaped association“. There is an uptick in CV morbidity at highest PA levels but was not statistically significant.

**Study Limitations**

- Incidence of CVD or CVRF (CV risk factors) morbidity (not death) was associated with self-reported survey answers based on MET hrs/wk throughout life beginning at age 18, from participants with a mean age of 50. Accuracy of memory recall is likely unreliable.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AI.-ama38.png)

**Figure AI.**

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-AJ.-ama38.png)

**Figure AJ.** Figure from Maessen 2016 shows the proportion of participants with (A) cardiovascular disease, CVD or (B) cardiovascular risk factors, CVRF. The y-axis shows the proportion of patients with the morbidity (blue bars, %) and the odds ratio OR (black dots with CI). The x-axis shows the exercise quintile groups, dose in MET min/wk, and the number of participants.

**Summary:**

This Dutch study assessed the relationship between lifelong exercise in MET hrs/wk and the incidence of cardiovascular disease (CVD) or cardiovascular risk factors (CVRF). Participants with the mean age of 50 were asked to provide estimated weekly activity levels since they were 18. Memory recall for such long timelines are not accurate and can only be used for understanding general lifelong habits. Even so, the authors found there was a decrease in CV morbidity for any exercisers compared to non-exercisers. Higher MET hrs/wk was associated with lower morbidity, except for the highest activity group which had a small but non-significant uptick. The authors state explicitly that “these findings contradict recent studies suggesting a potential U-shaped association”. Therefore, the study does not support the J-curve.

\*\*\*\*\*

## Importance of understanding p-values and statistical significance [33:30]

***When Peter says something is “not statistically significant”, why does that carry so much weight?***

- Anytime you’re doing inquiry, you have to account for the possibility that the effect you’re seeing is due to chance
- The way you do that is you use this statistical technique to basically address the certainty of your finding
- Now, nothing can be 100% certain, so what you do is: Ask a question which is assigned as a probability that the results that are being shown are being shown by chance
  - And that probability is called a P value
- You can set p-value to anything you want, but the convention is to either set it to 1% or 5%.
- For these analyses, they were all shown as 5% probability or P values, which means a 95% confidence interval
- For example:
  - If the number that gets spit out of the analysis is 0.7, you have to be able to say, “*I’m 95% confident that the answer lies somewhere between 0.6 and 0.8*”
  - I’m telling you the answer is 0.7, but in reality what I’m telling you is, “*I’m 95% confidence that the actual answer lies somewhere between 0.6 and 0.8*”

⇒ For more check out: [Studying Studies: Part V – power and significance](https://peterattiamd.com/studying-studies-part-v-power-and-significance/)

*What are some of the things that give you more confidence?*

- 1 – Sample size: The more samples you have the more likely you can be confident
- 2 – Variability to the inverse:
  - If you did an experiment with 10 samples in it
  - And the answers you got out were all basically the same—even though there were only 10 samples in it—you’d be much more confident that you had the right answer
  - Whereas if you had a small sample size and lots of variability, you’re going to have to have a very big confidence interval to be confident

⇒ Try this questionnaire to find out how hard it is to hit the 95% confidence interval: [**Do you understand what a “95% confidence interval” means?**](https://peterattiamd.com/confidence/)

- This is a game that Peter likes to play: asking people 20 questions for which there’s a known answer, but asking them to give a range that is 95% confident for each
- If you do this correctly, if you truly understand what a 95% confidence interval is… if you’re asked those 20 questions, you should get the correct range 19 times
- Most people, Peter included, the first time they play that game, they just fail miserably

> “We tend to be far more confident than we turn out to be justified in being.” —Peter Attia

## Deconstructing the studies that show a J-curve: major limitations and how one could be misled [36:45]

- In the [analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7431070/) discussed above, 7 studies show a J-curve but none of them are statistically significant
- The one study that is statistically significant, does NOT show a J-curve
- That *calls into question the J-curve*, says Peter

One could argue that maybe that’s the case because the sample sizes are too small and that’s why the error bars are so big

- If you shrunk those error bars, that would at least take the statistical concern off the table
- In one case, we don’t know if you can or can’t, which is the Paffenbarger study
- in the other, you statistically would exactly say the opposite (the Lear study)
- In the others they’re not statistically significant at all
- But if you shrunk all those error bars to little mini bars, you’d say, wow, that’s significant, but you’re not going to see it on either the size or noisiness of your data set
- This is why rather than just dismiss this outright, it’s probably helpful to go and look at a few of the studies, if anything, to explain the limitations of this line of inquiry

**There are two ways to think about these questions:**

- 1) through the lens of how much activity somebody is doing, and
- 2) through the lens of somebody’s fitness
- Peter would argue that neither are perfect, but the latter (somebody’s fitness) is much better.

**Issue #1**: *Relying on self-reporting questionnaires and self-reporting as the primary indicator of activity level.*

- This was present in all nine of these studies

**Issue #2**: *Lack of statistical significance in results*

- All the studies that show a J-curve are statistically insignificant
  - Arem, Lee, Schnohr, Armstrong, Maessen
- Data that did NOT show a J-curve
  - [Wen](https://www.natap.org/2011/HIV/PIIS0140673611607496.pdf) and [Stewart](https://www.sciencedirect.com/science/article/pii/S0735109717392665) (not significant)
  - [Lear](https://www.umed.wroc.pl/sites/default/files/files/aktualnosci/2017/12/Lancet_71.pdf) (was statistically significant)

**Issue #3**: *Cherry picking data*

- Lear study, for instance:
  - all cause mortality actually showed no J-curve when all physical activity was combined, both recreational and occupational
  - J-curve only exists in the all cause mortality when recreation only activity was considered, but it’s worth noting that this was a population that had a very active day job
  - There might be something there, but you have two different J-curves depending on which you look at

**Issue #4**: *Very small numbers of people in the most active group*

- Arem paper – 31x times less in the active group vs. the moderate group
- Schnohr paper – 16x less in active group

> “I just don’t think you’re going to be able to make conclusions one way or the other. And that obviously is already being demonstrated in the error bars being so big.” —Peter Attia

**Issue #5**: *general poor methodology*

- Strong confounders, incorrect grouping, etc.
- In the Armstrong paper, for ex: most of the active women also had a higher percentage of smoking and lower socioeconomic status than the less active women – a “reverse healthy user bias”
- In the Paffenbarger study, there were no confidence intervals

**Diving into specific papers and how you can be misled**

*Overview*:

- [Arem](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2212267) paper
  - lack of statistical significance
  - less participants in the active group by a long shot
  - poor adjustment on the data
- [Lear](https://www.umed.wroc.pl/sites/default/files/files/aktualnosci/2017/12/Lancet_71.pdf) paper
  - skipping out on the activity data for recreational being a little cherry picked
  - then total physical activity not even showing the result.
- [Schnohr](https://www.sciencedirect.com/science/article/pii/S0735109714071745) paper
  - had a very low number of deaths in the highest activity group, which of course then impacts its statistical significance

[**Arem**](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2212267) **paper**

- A really large study, because it’s pooling data from six studies that total nearly 700,000 subjects
- But even with these really large numbers, obviously the most active group, which was defined as more than 75 MET hours per week had the smallest number of participants
  - basically 4,000 versus 124,000 in the 25 and a half to 40 MET hours per group.
- That leads to pretty large confidence intervals and therefore no statistical significance in the findings
- In other words, ***what that study actually shows is that the mortality benefit goes lower, lower, lower, lower, lower, and at the most extreme end looks to stay about flat***

\*\*\*

**Sidebar about exercise and MET hours**

*Peter describes his weekly MET hours broken down into his types of exercise for an example*:

- What does a 100 MET hours a week look like?
- He exercises about 14 hours per week as follows
- I’m rucking three to four hours per week—That means three or four, three mile sessions, heavy, heavy pack, lots of climbing
- I’m on a bike doing zone two—my zone two might be a higher or lower MET than somebody else’s zone two so you have to go and compare the METs to watts. You have to do a watt to MET conversion
- I would say that I probably get 40 of my METs probably just on the bike. Maybe 50 actually. Maybe 60. I’m not even sure
- Let’s just say 230 watts times four hours per week of zone two, plus 30 minutes a week of zone five, which is a much, much higher MET, probably 16, 17 METs
- And then call it six to seven hours a week of relatively intense strength training, which might only produce, might only be about six METs, but multiplied by that time
- What I just described as a hundred, you can imagine scaling that back by a factor of four for 25, versus just scaling that back by 25%, probably gives you a sense of activity

Nick makes an important point: “*You mentioned that your zone 5 might only be a much smaller time than your resistance training and it might produce more METs, but you’re not in the game of, ‘Let’s see how I can get a hundred METs in the least amount of time as possible…you’re in the game of hitting all the different pillars and then adding those METs there.*’”

*Peter’s response*:

- Whatever my MET hours are, is simply a consequence of what I’m doing, but I’m not optimizing to be at 75 versus 100, versus 125
- The training goal is all in service of the centenarian decathlon.. . .It just so happens that’s what [my METs] works out to be
- The other things to keep in mind:
- There’s an adaptation here as well. So if you take somebody who’s never exercised, you’re going to get them well on the way to their goals in a fraction of the time that I need to spend doing this
- Think back to the [podcast with Layne Norton](https://peterattiamd.com/laynenorton2/) where he talked about theoretical patients, you take somebody who’s de-conditioned, doesn’t have a lifetime of exercise under their belt, you’re going to get remarkable adaptations in a short period of time

*Takeaways from Peter*:

- “I don’t want anybody listening to this to be put off and be discouraged and be thinking that, ‘oh my God, I don’t want to exercise that much’
- No, no, no, that’s the wrong way to think about it
- I’ve been exercising at a very high level my whole life. And so it’s just I need more stimulus to get the benefit
- If you’re a largely sedentary person, the good news is you’ll need a quarter of the output that I’m doing to achieve incredible benefit.”

**Back to the** [**Arem**](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2212267) **paper**

- This study was pooling data from six studies across the National Cancer Institute consortium
- They wanted to look at studies that had at least a five year follow up and they had a bunch of other criteria about how many deaths they wanted to have, etc.
- Out of those 661,000 participants, there were about 116,000 deaths at a median age of 62—that tells you might have been biased more towards cancer there
- The activities were gathered from surveys—they were asked over the prior year to get a sense of your weekly time spent jogging, running, swimming, looking at all these exercises
- They tried to be as granular as possible and that’s why they were able to for this paper, put it into MET hours
  - They said over the past year, how many hours per week do you spend walking, jogging, running, swimming, playing tennis, racketball, bling, aerobics, etc.
  - They had a decent sense of what your MET hours per week were going to be
- Pretty long follow up about 14 years

*Results*:

- The data show monotonic decline until the very last group when the data go up, **but the error bars suggest it’s just flat**
- The authors noted that, so to their credit, Peter doesn’t think this paper was misrepresented in the original publication
- The biases here are obvious—So self-reporting annual look backs
- You get the sense that the extremes are accurate
- There were a lot of people in the zero group, not much ambiguity there, the people who were in the more than 75 MET hours per week group, probably no ambiguity about how much they’re exercising
- whether you have true discrimination between the groups is less clear.

*Looking at this group because it was so large, what was a fraction of participants and even deaths within each of the different groups within it?*

- The bins were not linearly sized
- There’s one bin that is just zero—so no activity
  - That was 8% of the population that accounted for about 10% of the deaths
- The next bin was basically any amount of activity—So 0.1 MET hours up to 7.5—still a relatively sedentary group
  - That was 26% of the participants, about 29% of the deaths
- Then you go 7.5 to 15 MET hours.
  - That’s 26% of the population. 25% of the deaths
- 15 to 22.5 MET hours per week
  - 18% of the participants, 17% of the deaths
- 22.5 to 40 MET hours per week
  - 19% of the participants, 18% of the deaths
- 40 to 75 MET hours per week (big range of exercise)
  - That’s only 2.9% of the participants. 1.2% of the deaths
- In the last group, meaning the greater 75 MET hours per week
  - 0.6% of the population, 0.2% of the deaths
- Really **those last two groups represent 3.5% of the participants and account for less than 1.5% of the deaths**

*In an ideal study, if you were just setting up with perfect controls, each of those bins would have an equal number of people?*

- If this were an experiment where you could randomize and put an equal number of people in each bins and then randomize them to the given amount of exercise
- Then you’d solve all your problems (assuming you could get them to be compliant with that intervention)

## Peter’s takeaways on the theoretical “J-curve” relationship between exercise and longevity [51:15]

**Peter’s thoughts on the idea of a “J-curve”**

- “It’s really hard for me to believe we aren’t coming to the conclusion correctly, which is that this J-curve either doesn’t exist, or if it does exist, is not a big issue.”
- The reason is that study after study, after study, even when presented through the light of there is a J-curve, when scrutinized, that goes away
- Two thirds of the time, there’s no statistical significance
  - And if there is even a shred of significance, it’s usually in the opposite direction or it excludes an important cohort within the study

**This finding jives with Peter’s logic:**

- When you look at the health outcome data based on fitness, they were at odds with one another
- How is it that people with a VO2 max in the top 2.5% of the population can have a clearly lower mortality than everybody else, but somehow people exercising more than four hours or five hours per week don’t?
  - How do you reconcile that?
- “In other words, I know what it’s like to have a VO2 max in the top 2.5% of the population when I’ve had it, it ain’t coming by five or six hours a week of exercise.”
- It might only be three or four hours of super intense exercise, but that’s on the base of much more aerobic training at a lower intensity

> “Based on the analysis now that our team has done, I feel more confident in understanding why this dichotomy is not a true dichotomy.” —Peter Attia

⇒ Exercise also impact bone health: [#214 – AMA #37: Bone health—everything you need to know](https://peterattiamd.com/ama37/)

## Risk of sudden cardiac death from vigorous physical exertion [53:45]

**Just because the data doesn’t support the idea of a “J-curve” doesn’t mean there’s no risk with exercise**

- Peter would like to ensure that people don’t think that there is absolutely no harm that can ever be done with any amount of exercise
- For one, you can have orthopedic injuries
  - You can cause a lot of damage to yourself exercising if you’re doing so incorrectly

**Cardiac issues**

- At very extreme levels, there are indeed increased risks of sudden cardiac death and MI during and shortly after bouts of really vigorous physical exertion
- But the absolute risk of these things is incredibly small
- Basically the longer and more physically demanding something seems to be, the higher the risk of sudden cardiac death
- For a complete marathon, you’re looking at about [one death per 100,000 participants](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000749)
- For a half marathon, it’s about a quarter of that, [0.27 deaths per 100,000 participants](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000749)
- Men are at higher risk than women in this regard (about twice as high)
- Also worth noting: The risk doesn’t vanish the second you stop exercising, we do still see a slight uptick in increased risk of sudden cardiac death within an hour of that physical activity
- But we’re talking about less than 1 per 100,000

**Orthopedic injuries**

- Also worth mentioning that the orthopedic injuries far and away dominate here
- A way that this is typically reported is in the number of orthopedic (i.e, overuse musculoskeletal injuries) that you’ll see per 1,000 hours of participation

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-6.-injuries-per-1000-hours-ama38-655x1024.png)

**Figure 6.** Number of injuries per 1000 hours of participation in various recreational and competitive sports, and lifestyle and commuting activities (bars represent 95% confidence interval). Credit: [Parkkari 2004](https://pubmed.ncbi.nlm.nih.gov/15088246/)

- This looks at basically everything from squash, judo, racketball, wrestling, basketball, soccer, ice hockey, etc.
- So just to give you a sense of what we’re talking about, at the extreme end of the spectrum—squash—you’re looking at about 15 injuries per 1,000 hours of participation
- Something like running, believe it or not, it’s only about 2-3 per 1,000 hours
- So these more multi complex movement, explosive things tend to have a little bit more risk than cycling, running, swimming, things like that

**Sudden cardiac death—who is at risk and the importance of health screening**

Most people that have a fear of exercise is around this idea of **sudden cardiac death**.

The question is: *How do we identify who’s at risk?*

- Well, we want to have good cardiovascular medicine care
- A third of women and half of men who will have their first brush with coronary artery disease will have so before the age of 65
- Probably [40% of people’s first brush with major adverse cardiac event is sudden death](https://peterattiamd.com/ronkrauss/)
- All of this speaks to a more important approach to general health screening
- Peter wonders if you look at every one of those people that had sudden cardiac death, *how many of those were atherosclerotic in nature versus arrhythmias*?
- And of the ones that were purely atherosclerotic that either led to an arrhythmia or an ischemic event…
  - How many of those people would’ve been detected during a stress test?
  - Or had they had a coronary CT scan, would you have demonstrated the presence of atherosclerosis?

> “The message shouldn’t be: exercise is dangerous. It should be, we need to have a little bit more caution before we maybe think about running a marathon. We should make sure that we’re in generally good cardiovascular health because obviously that’s placing a significant amount on the heart.” —Peter Attia

## Atrial fibrillation associated with extreme levels of exercise [1:00:00]

***On the lifespan perspective, looking at cardiovascular concerns, are there any other concerns other than what you mentioned that people should be aware of when looking at volume of exercise?***

Yes, we must acknowledge that certainly extreme levels of exercise may in fact predispose people who have certain things; Things like…

- And the strongest evidence is probably for people with [atrial fibrillation](https://en.wikipedia.org/wiki/Atrial_fibrillation)
- Coronary calcification: On the [podcast with James O’Keefe](https://peterattiamd.com/jamesokeefe/), we also talked about potentially the increase in coronary calcification, which may not be as predictive of poor outcomes as we see it in the standard method that we look at coronary calcification
- Fibrosis of myocardial tissue

**Atrial fibrillation**

- There’s about a [fivefold increase](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000749) in risk for people with A-fib who are doing a lot of cardio
- At some point we will begin to identify, hopefully genes that can identify those that are at risk
- Peter has seen this occur in families, where a father and two sons who are all fit and have no other risk factors for AFib, but they will develop AFib associated with exercise
- This type of info is what makes Peter think that there are going to be people that are genetically predisposed to this
- As discussed in the [podcast with Mike Joyner](https://peterattiamd.com/mikejoyner), atrial fibrillation is a pretty manageable rhythm—it’s not a fatal rhythm
- If you have AFib, it can be a real nuisance—you could need to be cardioverted and sometimes you need to be on medications to thin your blood
- So not to play this down, but it’s not a ventricular arrhythmia that can result in cardiac death
- If we see greater coronary calcifications, it tends to be offset by much larger coronary arteries and better endothelial health
- It’s not clear that this is actually predisposing to atherosclerosis, and also it’s not really clear what the incidence is
- When we think about atrial fibrillation normally, there’s a phenotype that goes with it—somebody that’s got underlying heart disease, hypertension, obesity, etc.
- But when you’re talking about **athlete AFib**, that seems to be five, six, seven, even eightfold difference
- We see this in endurance athletes a lot and Peter’s noticed, empirically, that it tracks in families

*Why do we think athletes might be at risk or are getting AFib? What’s the mechanism of action that we know there?*

- It’s been suggested that they have increased short term inflammation and fibrosis
- It also increases vagal tone at rest—that’s why athletes have slower heart rates at rest
- But during exercise they’re having heightened sympathetic tone
- They also get remodeling of the atria and the ventricles
- They get larger and that’s what allows an athlete’s heart to pump so much more per given heartbeat
- It might be that all of these things together, the remodeling, the vagal tone, the inflammation and scarring is what potentially leads to this atrial fibrillation.

![](https://peterattiamd.com/wp-content/uploads/2022/08/Fig-7.-ama38.png)

**Figure 7.** Proposed mechanisms that over many years of high-volume, especially endurance training, could lead to atrial fibrillation. [[Franklin 2020](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000749)]

- Depending on the study you look at, we’re directionally speaking about a fivefold increase and it’s talking about people who have 10,000 hours of exercise under their belt
- “Truthfully, when I think about all of the risks of exercise, this is the one I think about most. I don’t really worry about the mortality J-curve, especially if you’re going through this analysis.” says Peter

And look, you probably don’t need to spend 20 hours a week doing cardio

- You can really capture all of the benefits necessary to optimize lifespan and healthspan, and you don’t need to subject your pump (heart) to that much volume

## Parting thoughts: benefits of exercise far outweigh the risks [1:04:00]

- The risks that we just discussed are vanishingly small—We’re talking about 0.1, 0.2% of the population that are even contemplating so much exercise, that those are the risks we’re dealing with
- The majority of people CAN and SHOULD be exercising more

Exercising just one hour a day, even just at 8 METs for 56 MET hours per week, “*there’s just no chance you’re doing anything but grabbing net every shot*”

§

## Selected Links / Related Material

**AMA about fruits and vegetables**: [#211 – AMA #36: Fruits & vegetables—everything you need to know](https://peterattiamd.com/ama36/) | Peter Attia (peterattiamd.com) [2:45]

**Episode of The Drive with Alex Hutchinson**: [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/) | Peter Attia (peterattiamd.com) [2:45] [3:30]

**AMA episode which discussed VO2 max**: [#176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity](https://peterattiamd.com/ama27/) | Peter Attia (peterattiamd.com) [3:30, 26:00]

**Episode of The Drive with James O’Keefe**: [#134 – James O’Keefe, M.D.: Preventing cardiovascular disease and the risk of too much exercise](https://docs.google.com/document/d/1nZALmM44YSCPfshXDeeVBVIu_7oUSVqJ4WY81su9QyM/edit#134%20%E2%80%93%20James%20O%E2%80%99Keefe,%20M.D.:%20Preventing%20cardiovascular%20disease%20and%20the%20risk%20of%20too%20much%20exercise) | Peter Attia (peterattiamd.com) [3:45, 1:01:30]

**Peter’s weekly email responding to articles exploring the 10,000 steps rule**: [Does walking 10 minutes per day extend your life? (Hint: No.)](https://peterattiamd.com/does-walking-10-minutes-per-day-extend-your-life/) | Peter Attia (peterattiamd.com) [4:30]

**The cartoon Peter posted on Instagram**: [@peterattiamd](https://www.instagram.com/p/CdbG8LNu-aj/) | (instagram.com) [6:00]

**Big review paper exploring the possible J-curve of exercise and longevity**: [Training for Longevity: The Reverse J-Curve for Exercise](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7431070/) (O’Keefe et al., 2020) [27:45]

*Papers analyzed in the O’Keefe review paper*:

- Arem study: [Leisure Time Physical Activity and Mortality: A Detailed Pooled Analysis of the Dose-Response Relationship](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2212267) (Arem et al., 2015)
- Lear study: [The effect of physical activity on mortality and cardiovascular disease in 130000 people from 17 high-income, middle-income, and low-income countries: the PURE study](https://www.umed.wroc.pl/sites/default/files/files/aktualnosci/2017/12/Lancet_71.pdf) (Lear et al., 2017)
- Lee study: [Leisure-Time Running Reduces All-Cause and Cardiovascular Mortality Risk](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4131752/) (Lee et al., 2015)
- Schnohr study: [Dose of Jogging and Long-Term Mortality: The Copenhagen City Heart Study](https://www.sciencedirect.com/science/article/pii/S0735109714071745) (Schnohr et al., 2015)
- Paffenberger study: [Physical Activity, All-Cause Mortality, and Longevity of College Alumni](https://sci-hubtw.hkvisa.net/10.1056/nejm198603063141003) (Paffenberger et al., 1986)
- Wen study: [Minimum amount of physical activity for reduced mortality and extended life expectancy: a prospective cohort study](https://www.natap.org/2011/HIV/PIIS0140673611607496.pdf) (Wen et al., 2011)
- Stewart study: [Physical Activity and Mortality in Patients With Stable Coronary Heart Disease](https://www.sciencedirect.com/science/article/pii/S0735109717392665) (Stewart et al., 2017)
- Armstrong study: ​​[Frequent Physical Activity May Not Reduce Vascular Disease Risk as Much as Moderate Activity Large Prospective Study of Women in the United Kingdom](https://www.ahajournals.org/doi/pdf/10.1161/CIRCULATIONAHA.114.010296) (Armstrong et al., 2015)
- Maessen study: [Lifelong Exercise Patterns and Cardiovascular Health](https://www.runningresearch.nl/images/PDFs/Maessen_MCP_2016_Lifelong_exercise_patterns_and_CV_health.pdf) (Maessen et al., 2016)

**20 question questionnaire where you could try and figure out how hard it is to hit 95% confidence interval**: [Do you understand what a “95% confidence interval” means?](https://peterattiamd.com/confidence/) | Peter Attia (peterattiamd.com) [36:00]

**Episodes of The Drive with Layne Norton**: [46:45]

- [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training](https://peterattiamd.com/laynenorton/) | Peter Attia (peterattiamd.com)
- [#205 – Energy balance, nutrition, & building muscle | Layne Norton, Ph.D. (Pt.2)](https://peterattiamd.com/laynenorton2/) | Peter Attia (peterattiamd.com)

**AMA episode about bone health**: [#214 – AMA #37: Bone health—everything you need to know](https://peterattiamd.com/ama37/) | Peter Attia (peterattiamd.com) [53:45]

**Data looking at deaths during marathons and other exercise-related cardiovascular events**: [Exercise-Related Acute Cardiovascular Events and Potential Deleterious Adaptations Following Long-Term Exercise Training: Placing the Risks Into Perspective–An Update: A Scientific Statement From the American Heart Association](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000749) (Franklin et al., 2020) [55:15]

**Data showing the number of injuries per 1000 hours of participation in various recreational and competitive sports**: [Active living and injury risk](https://pubmed.ncbi.nlm.nih.gov/15088246/) (Parkkari et al., 2004) [56:30]

**Episode of The Drive with Ron Krauss**: [#03 – Ron Krauss, M.D.: a deep dive into heart disease](https://peterattiamd.com/ronkrauss/) | Peter Attia (peterattiamd.com) [57:30]

**Data showing a fivefold increase in risk of cardiovascular event for people with A-Fib doing a lot of cardio**: [Exercise-Related Acute Cardiovascular Events and Potential Deleterious Adaptations Following Long-Term Exercise Training: Placing the Risks Into Perspective–An Update: A Scientific Statement From the American Heart Association](https://www.ahajournals.org/doi/10.1161/CIR.0000000000000749) (Franklin et al., 2020) [1:00:45]

**Episode of The Drive with Mike Joyner**: [#217 ‒ Exercise, VO2 max, and longevity | Mike Joyner, M.D.](https://peterattiamd.com/mikejoyner/) | Peter Attia (peterattiamd.com) [1:01:30]

§

## People Mentioned

- [Alex Hutchinson](https://peterattiamd.com/alexhutchinson/) [3:45]
- [James O’Keefe](https://peterattiamd.com/jamesokeefe/) [3:45, 27:45]
- [Michael Easter](https://eastermichael.com/) [24:15]
- [Layne Norton](https://twitter.com/BioLayne?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [46:45]
- [Ron Krauss](https://peterattiamd.com/ronkrauss/) [57:30]
- [Mike Joyner](https://twitter.com/drmjoyner) [1:01:30]

§