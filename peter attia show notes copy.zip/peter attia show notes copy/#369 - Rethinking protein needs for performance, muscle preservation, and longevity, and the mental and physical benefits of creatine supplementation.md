# #369 ‒ Rethinking protein needs for performance, muscle preservation, and longevity, and the mental and physical benefits of creatine supplementation and sauna use | Rhonda Patrick, Ph.D.

**Source:** [https://peterattiamd.com/rhondapatrick3/](https://peterattiamd.com/rhondapatrick3/)

---

Rhonda Patrick is a scientist, health educator, and host of the FoundMyFitness podcast whose work explores the intersection of nutrition, aging, and disease prevention. In this episode, Rhonda joins Peter for part two of his deep dive on protein, continuing last week’s discussion with David Allison and expanding the conversation to include creatine supplementation and sauna use. She discusses why the current RDA for protein is insufficient, how much more is needed to maintain muscle mass and prevent frailty, how activity level and aging influence protein requirements through mechanisms such as anabolic resistance, and how to determine optimal protein intake. The conversation also covers creatine’s proven effects on strength, endurance, and performance; its overlooked benefits for cognition and brain health; and the optimal dosing for different populations. Rhonda closes with the science behind sauna use, including its cardiovascular and cognitive benefits, the role of heat shock proteins, and practical guidance on temperature and duration.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/rhondapatrick3/the_Drive_public.png)

Play

#369 ‒ Rethinking protein needs for performance, muscle preservation, and longevity, and the mental and physical benefits of creatine supplementation and sauna use | Rhonda Patrick, Ph.D.

#369 ‒ Rethinking protein needs for performance, muscle preservation, and longevity, and the mental and physical benefits of creatine supplementation and sauna use | Rhonda Patrick, Ph.D.

1x15s30s

0:001:50:00

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Why the current protein RDA is too low, and why maintaining sufficient amino acid intake is vital for muscle preservation and health [A: 3:30, V: 0:11];
- The case for raising the protein RDA by at least 50% [A: 9:45, V: 7:12];
- Anabolic resistance: why inactivity—more than aging—blunts the body’s response to protein, and how resistance training restores it [A: 14:00, V: 11:46];
- How sarcopenia develops, the profound effect of frailty on quality of life, and why it’s crucial to build and maintain muscle early [A: 20:00, V: 18:40];
- Finding the optimal protein dose [A: 25:00, V: 24:46];
- Why aiming higher is smarter: the case for targeting 2g of protein per kg of body weight in the real world [A: 32:15, V: 32:39];
- Protein needs for pregnant women and growing adolescents [A: 37:30, V: 38:26];
- Why higher protein intake is crucial when trying to lose fat while preserving or gaining muscle [A: 39:45, V: 41:05];
- GLP-1 drugs: protein needs, muscle preservation, dosing strategies, evidence of broader health impacts, and more [A: 43:45, V: 45:31];
- How overweight individuals should calculate protein needs based on target body weight [A: 50:45, V: 53:54];
- Unpacking a misunderstood topic: the relationship between protein intake, mTOR activation, and longevity [A: 52:00, V: 55:29];
- Why it’s unclear whether rapamycin is geroprotective in humans, and how misinterpreted animal data have fueled misconceptions about protein or mTOR activation being harmful [A: 1:00:45, V: 1:05:21];
- The unmatched longevity benefits of exercise, its synergy with higher protein intake, and Peter’s recommended protein intake [A: 1:06:15, V: 1:11:33];
- How Rhonda became fascinated with creatine—a well-studied, safe, and effective supplement for improving exercise performance [A: 1:09:00, V: 1:14:52];
- Creatine for the brain: how higher doses may enhance cognition under stress and support resilience against aging and disease [A: 1:16:30, V: 1:23:26];
- Optimal creatine use: dosing for adults and teens, safe product selection, debunking kidney myths, and more [A: 1:25:45, V: 1:34:27];
- Sauna: how deliberate heat exposure mimics exercise, boosts cardiovascular and brain health, and shows promise for improving mood and mental resilience [A: 1:32:15, V: 1:41:54];
- The benefits of sauna for reducing risk of dementia, and why hotter may not be better [A: 1:41:15, V: 1:52:32];
- The FoundMyFitness podcast [A: 1:45:30, V: 1:57:33]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Rhonda Patrick is returning for her third conversation on the drive
- Rhonda is a scientist, health educator, and host of [*FoundMyFitness* podcast](https://www.foundmyfitness.com/episodes)
- Her work focuses on the intersection of nutrition, aging and disease prevention, and she is widely recognized for bringing clarity to complex topics in health science
- This is part two of a deep dive on protein, but we expand into other topics like creatine, supplementation and sauna use

In this episode, we discuss

- Why the RDA for protein is too low and why a new minimum of at least 50% more than the RDA is needed to avoid negative protein balance
- The distinction between minimum, optimal, and high protein intake
- How activity level and aging can affect requirements anabolic resistance
  - What it is, why inactivity drives it, and how resistance training restores sensitivity
- The role of protein in preventing frailty and sarcopenia and the quality of life implications in aging
- Evidence on protein intake during pregnancy, weight loss, and while using GLP-1 agonists
- Addressing the concerns about mTOR, cancer risk, and reconciling protein intake with longevity research
- The case for creatine
  - How it enhances strength and endurance performance
  - It’s overlooked benefits for cognition and brain health
  - Why dosing above 5 g/day may be necessary
- Practical guidelines on creatine dosing and the populations who may benefit most
  - For example, vegetarians, older adults, young athletes, older athletes
- The science of sauna use
  - Revisiting the mechanisms especially as they pertain to cardiovascular adaptations and heat shock proteins, dementia risk and cardiovascular disease reduction
  - Best practices for temperature, duration, and frequency
  - How to weigh infrared versus traditional dry saunas and why going hotter isn’t always better
- Peter really enjoyed this discussion with Rhonda and he’s truly hopeful that this is the last time he needs to do a podcast in a very long time that addresses some of the controversy surrounding protein intake

## Why the current protein RDA is too low, and why maintaining sufficient amino acid intake is vital for muscle preservation and health [A: 3:30, V: 0:11]

- Protein is an important topic
- Rhonda and Peter have probably talked to all the world’s experts on protein
  - [Explore more at [PeterAttia—MD](https://peterattiamd.com/category/nutritional-biochemistry/protein/) and [FoundMyFitness](https://www.foundmyfitness.com/topics/protein)]
- They were chatting a moment about about the recommended daily allowance (RDA) for protein, and really what it should be called is “the minimum daily allowance”
  - Recommended almost sounds like optimal
  - The RDA is 0.8 g of protein per kg of body weight

***People confuse the RDA with the optimal amount of protein***

- They have both talked to countless experts about this
  - [Stu Phillips](https://mira.mcmaster.ca/our-faculty/stuart-phillips/) being one [episode [#76 of FoundMyFitness](https://www.foundmyfitness.com/episodes/stuart-phillips)]
- People can start off by reading Stu Phillips’ [Perspective Protein Requirements and Optimal Intakes in Aging: Are we ready to recommend more than the recommended daily allowance?](https://pubmed.ncbi.nlm.nih.gov/29635313/)
- There are several other publications on this topic, if you have the time and the willingness to go into the scientific literature
  - Read or listen to *The Drive* or listen to *FoundMyFitness*

**When the actual experts talk about the protein RDA, what you will learn is that a lot of the studies that were done to determine this RDA were flawed**

- They were called **nitrogen balance studies**
- They were flawed for many reasons, and Rhonda doesn’t want to get into all the technical reasons
- What they are doing is measuring the amount of nitrogen that is excreted in urine after you are metabolizing protein
- The most important flaw is that different types of foods that have protein in them have different nitrogen to protein ratios
- Nitrogen balance studies are collecting urine, and that it’s an incomplete collection
  - When you pee in one of those cups, you don’t get all the urine
  - And we lose nitrogen through other means

***Essentially the signal-to-noise ratio is pretty low***

> “*Ultimately, what countless experts have now agreed upon is that the protein for the RDA has been underestimated because of those reasons*.”‒ Rhonda Patrick

**New studies have been done**

- These have been stable isotope studies
- The major isotope that’s used is the L-1,13-carbon labeled phenylalanine
- These studies take a small cohort of people, give them a known amount of protein with that isotope tracer, and then that tracer is oxidized when it’s metabolized and that’s measured through breath (the oxidation of phenylalanine).

***And so now you’re getting a quantification that’s much more accurate in terms of your protein steady state and turnover***

Rhonda explains, “*The whole point here is that you’re trying to figure out the minimal amount of protein you need to take in every day to make sure that you’re not in a negative protein balance*.”

**⇒** That’s important because we don’t store amino acids like we store fatty acids as triglycerides or we store glucose as glycogen

- The major source of our amino acid storage tank (so to speak) is our muscle skeletal muscle tissue
- And you don’t want to be pulling from that skeletal muscle tissue to get amino acids every day

**Why do we need amino acids every day?**

- Because everything in our body requires proteins
- Proteins are doing all the work in our body
- Proteins are made up of amino acids, and so we have to be giving ourselves a daily intake of amino acids to make sure we’re able to do all those functions

Peter wants to state that again because there’s a very important and fundamental point here that is glossed over when we talk about it because we take it for granted

- We can store fat in unlimited quantities ‒ so if you deprive a person of fat calories for a period of time, they have a long reservoir that they can dig into
- We can store carbohydrates
  - Now we can’t store them quite as much because we only have so much glycogen we can store in the muscle and in the liver
  - But when we break down fat, we keep making the substrate to actually make glucose [gluconeogenesis]
  - So we get into a nice little rhythm

***The only place that an amino acid sits in residence in our body is in the muscle***

**⇒** Therefore, if we even get near the edge where we are not getting sufficient intake of amino acids, we don’t have a buffer, we don’t have a rainy day fund that we can dip into, we immediately start to catabolize or break down muscle

- Peter doesn’t think we have to make the case that that’s a bad idea

> “*There is not really a single scenario I can think of that is clinically relevant where it would be desirable to give up muscle mass.*”‒ Peter Attia

- Maybe if you’re Mr. Olympia, you can sacrifice muscle mass
- But for you and me, and everybody listening to us ‒ ***giving up muscle mass because we are falling short on our protein intake would be a strategic error and an unforced error***

Rhonda agrees and adds, “*For short-term and long-term health. I think that’s pretty clear and that’s where this RDA not being enough is a very important point.*”

## The case for raising the protein RDA by at least 50% [A: 9:45, V: 7:12]

**There have been multiple isotope tracer studies showing that 1-2 g of protein per kg of body weight is needed to prevent negative protein balance in adults**

- This is quite a bit more than the RDA of 0.8 g/kg (50% more)
- Most of the isotope tracer studies show 30-50% more protein intake is required
  - [Reviewed in [2010](https://pubmed.ncbi.nlm.nih.gov/19841581/) and [2018](https://pubmed.ncbi.nlm.nih.gov/28698222/)]
- That’s really important because if we look at the actual protein intakes of adults, these are nutritional surveys that are done: they’re all flawed
  - We all know the flaws of questionnaires

**Let’s just talk about what we think people are actually taking in**

- All adults are mostly taking in about 0.9 g/kg body weight per day of protein
- That’s pretty close to what that RDA is, not what it should be
- Older adults, if we look at the gender (male versus female)
  - Males are taking in about 0.9 g/kg
  - Females are taking in 0.8 g/kg
  - They’re really just hitting that what we call RDA, which now we have established is not enough

***The RDA is not enough to basically be in a net protein balance. So that’s really important, and that’s essentially telling us that most adults are walking around without being in steady state protein balance.***

**We know the rates at which muscle mass/skeletal mass are declining by decade in an aging population.** *Is there any way we can estimate what percent of that decay is simply being driven by insufficient amino acid consumption versus other factors?*

Other factors would be

- 1 – Anabolic resistance associated with aging
- 2 – Anabolic resistance associated with sedentary behavior
- 3 – Lack of sufficient resistance training
- There are many factors that explain clearly the fact that as a person goes from 50 to 60 to 70 on average they’re losing muscle mass
- But it would be interesting to consider how much of that is explained by the fact that they are also barely skirting the minimum amount of nitrogen that they need and in many cases falling below it
- Rhonda doesn’t know that there’s a direct way to do that
- But there are [studies](https://pubmed.ncbi.nlm.nih.gov/25056502/) that have shown that older adults are really more susceptible to these things: like anabolic resistance where your muscle tissue is not as sensitive to amino acids, mostly because of physical inactivity
  - And this increases with age

**⇒** But when older adults take in [1.2 g/kg of protein](https://pmc.ncbi.nlm.nih.gov/articles/PMC5952928/), it nearly eliminates some of the age-related muscle loss that happens

- Rhonda thinks that is some evidence to support what Peter was saying in that if older adults increase their protein intake by 50% to this minimum, they’re actually preventing a lot of the age-related loss in muscle that occurs

***Most experts agree that the RDA should be 1.2 grams per kilogram body weight per day ‒ it’s time to change the  RDA to that number***

**⇒** We also know that [older women](https://pubmed.ncbi.nlm.nih.gov/36402009/), if they take in that amount of 1.2 g/kg, they’re 30% less likely to have frailty in old age, which is also very important

- That’s pretty good evidence that it’s clear that just increasing your protein intake by 50% is really important for aging for our muscle health and also is getting us out of that net negative state that we’re in.

**Peter’s takeaway**: step #1 we should move the floor from 0.8 to 1.2 g/kg protein intake per day

Rhonda adds, “*The floor being the minimal amount of protein that we need to take in per day, this is not optimal.*”

## Anabolic resistance: why inactivity—more than aging—blunts the body’s response to protein, and how resistance training restores it [A: 14:00, V: 11:46]

**Anabolic resistance compounds with the fact that we’re already not getting enough protein to be in a positive state of protein balance**

- Anabolic resistance is when your muscle tissue becomes less sensitive to amino acids, and so muscle protein synthesis isn’t occurring as much as it does when you’re younger

**⇒** The consensus now is that a lot of anabolic resistance is not necessarily due to the aging process per se, so much as inactivity

- The [experiment](https://pubmed.ncbi.nlm.nih.gov/37994085/) that Luc van Loon shared when he was on the podcast [[episode #299](https://peterattiamd.com/lucvanloon/)]: they put a cast on 1 leg of young subjects and left them in this state for a period of time
  - The casted leg did nothing while the other leg continued to go through exercises (single-leg extensions, leg curls, etc.)
  - They then ran the stable isotope experiment in these individuals and looked at muscle protein synthesis rates, and lo and behold, the leg that was uncasted perfectly normal
  - The other leg [in the cast] had significant anabolic resistance

***To Peter, that’s the clearest demonstration that inactivity is the main culprit***

- There’s probably an all-things-equal age-related component as well, but he suspects that inactivity is playing a larger role than aging, per se (Rhonda agrees)

**Can we explain what anabolic resistance is?**

- When we eat protein, we’re breaking down amino acids and the primary amino acid that is anabolic is [leucine](https://pubmed.ncbi.nlm.nih.gov/38046946/)
  - When it gets into the muscle tissue, it provides a signal to increase muscle protein synthesis
  - So you’re making more protein in your muscle, and that in turn increases muscle hypertrophy
- The other major signal to do that is mechanical force (**resistance training,** working of the muscles)
- As we get older, our muscles do become less sensitive to those amino acids, the [leucine transporter](https://en.wikipedia.org/wiki/Branched_chain_amino_acid%E2%80%93cation_symporter) being one of the major ways, but there’s others as well

***What happens is that for the same protein dose, older adults have less muscle protein synthesis***

- This [study](https://pubmed.ncbi.nlm.nih.gov/25056502/) has been done, and if you compare younger adults and older adults 65 years age and older, you give them the same exact protein dose
  - The younger adults have twice as much muscle protein synthesis
  - Older adults need double that amount of protein (that’s a lot)

Rhonda explains, “*For the older adults to get the same amount of muscle protein synthesis, they had to double their amount of protein to get the same amount of muscle protein synthesis as the younger adults.*”

***Anabolic resistance means your muscle tissue is not as sensitive to the amino acids, and to get more of them in, you have to increase your intake of the protein***

- Rhonda agrees with Peter’s point about **physical activity** being the major driver here
  - It’s totally true, and there’s so much evidence out there to prove that
  - Luc van Loon’s [study](https://pubmed.ncbi.nlm.nih.gov/37994085/) being one
  - But also older adults that do engage in resistance training have the same anabolic response to the same amount of protein as younger adults

> “*As you’re aging, if you’re a 65, 70-year-old male listening to this episode and you are engaging resistance training, you’re likely not experiencing much anabolic resistance*.”‒ Rhonda Patrick

***So you don’t necessarily have to experience anabolic resistance if you are physically active in training (that’s the most important public health message here)***

- Peter points out the impact that physical training has on [insulin resistance](https://en.wikipedia.org/wiki/Insulin_resistance) as well
  - Completely different mechanism of action, probably ties in more to fatty acid accumulation within muscles and all sorts of other things that lead to it
- But again, the most effective remedy is physical activity
  - It’s been demonstrated so conclusively that actually nobody really talks about it
  - It’s just taken for granted
  - [discussed in detail in episodes [#140](https://peterattiamd.com/geraldshulman/) and [#337](https://peterattiamd.com/ralphdefronzo/)]

**What percent of the population is resistance training?**

- Rhonda points out that [surveys](https://pmc.ncbi.nlm.nih.gov/articles/PMC11000248/) of the general population looking at how physically active people are (young and old adults) report that ***about 32% of them engage in resistance training***
  - If you just look at ***older adults, it’s 22%*** of the population
  - So essentially most older adults and most people are not engaging in resistance training
  - [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f1-rhondapatrick3.png)

**Figure 1. Percentage of U.S. adults who meet the muscle-strengthening guidelines (2 or more days a week)**. Image credit: [*Journal of Physical Activity and Health* 2021](https://journals.humankinetics.com/view/journals/jpah/18/S1/article-pS37.xml)

- Physical activity mirrors those numbers

***The bottom line here is that putting in the effort is hard***

- It’s easier for people to just increase putting something in their mouth (that’s why pills are so popular)

**Compounding factors cause loss of muscle in older adults**

- Going back to the RDA being too low: it’s so important because people are out there thinking they’re getting enough protein
- It’s really more important with older adults
  - You have a little bit of wiggle room when you’re younger
- First of all, it’s not enough protein, and then on top of that this anabolic resistance is setting in and most people are not being active
- People are not engaging in resistance training
- So there’s all these compounding factors that’s really just digging into their muscle

***These factors compound in an insidious sort of way, taking away each year and then the next thing you know, you’re frail, you have sarcopenia***

## How sarcopenia develops, the profound effect of frailty on quality of life, and why it’s crucial to build and maintain muscle early [A: 20:00, V: 18:40]

**Peter is surprised that more people don’t talk about this**

- His patients are obviously indoctrinated into this
- The medical system doesn’t seem to talk enough about frailty and [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia)
- Peter worries about this, and even when he wrote [*Outlive*](https://www.amazon.com/dp/0593236599/?bestFormat=true&k=outlive%20peter%20attia&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_k0_1_7_de&crid=3QNZZVUJ8I17I&sprefix=outlive), he didn’t do enough of a job emphasizing it
  - He certainly talked about it, but when he talked about 4 horsemen, he talked about cardiovascular and cerebrovascular disease, cancer, neurodegenerative and dementing diseases and metabolic disease
  - Because of course, those are the things that are the main assault on your lifespan
  - And relative to those, frailty is not as big an assault on lifespan
  - It is as the risk of falls are enormous and the mortality is very high once you’re north of 75
  - But he had to pick 4 horsemen; he didn’t want to go with 5

***When you think about quality of life, which most people care about at least as much, if not slightly more than length of life, Peter thinks frailty kind of wins the day***

- Along with minimizing too much cognitive decline, frailty is the thing that seems to determine the quality of your final decade on this earth

Peter makes the point, “*We have lots of great tools, both in terms of training and nutrition, that can offset frailty*.”

- Yet it is surprising that despite the fact that most people have witnessed it, that’s the part that’s amazing
- It’s not like the people who are suffering from frailty and sarcopenia are out of sight because they’re our parents and our grandparents
  - We’ve watched it
  - We’ve been to the movie over and over and over again

***We see how it goes, and yet somehow we either don’t think it’s going to happen to us or it somehow still seems abstract because it’s so many years off***

**What’s your take on this overall challenge?**

- Rhonda agrees that frailty risk is important, and she has witnessed it with family members

It’s this incremental thing where something happens

- Maybe there’s a fall
- Maybe there’s just a surgery, a planned surgery or a hip replacement or a knee replacement
- If your parents or your grandparents are inactive for many weeks and they lose a lot of muscle mass (this happens)
- If this is a younger person, it’s much easier to gain back that muscle mass
- It’s not the same with an older adult
  - Even if you’re engaging in resistance training after, you’re not going to get the same amount of muscle mass back as you’ve lost
- And these sorts of events happen in periods of time
- Maybe COVID or the flu, whatever it is, they keep hitting
- And you reach this what’s called “**disability threshold**,” where all of a sudden your parents, they just can’t walk much at all anymore
- And it’s like all of a sudden it’s like, when did this happen?
- Well, the evidence was mounting over the last 5 years when they had these points of inactivity that were occurring

Rhonda explains, “*I think people just don’t follow the timeline where it’s like they see what’s leading up to it before this catabolic crisis occurs, where then they reach this point now where they’ve just lost so much muscle mass from these several events that have occurred where they’re just not mobile*.”

- And then of course, anabolic resistance is kicking in even more and more and more, and everything is just compounding
- People haven’t observed the timeline to see that A+B+C is getting me to this point
- Whereas with Alzheimer’s disease is just like this disease that everyone knows about and it’s like this one thing causes the problem

**When Peter** [**spoke**](https://peterattiamd.com/lucvanloon/) **to Luc van Loon, he made a good point about how people lose strength and muscle mass**

- When we draw the curve for how people lose strength and how people lose muscle mass, we draw it in a curved smooth line, which gives us the **incorrect impression** that this is a gradual and imperceptible changing physiologic process
  - That’s because it’s averaging everything
- If you zoom in and look at it at the individual level, it looks like this, exactly as you described: ***discrete periods of loss from which there is no recovery because at the later points in life it becomes very difficult to make those recoveries***

> “*All of this points back to where we’re going today, which is when you are young and young as 40, 50, even 60, you have to build up as much physiologic headroom as possible.*”‒ Rhonda Patrick

- You have to prepare for the rainy day, because the rainy day is coming
  - It’s not a question of if, it’s simply a question of when and exactly and what fashion it will be delivered, but you must prepare for this

**Peter’s advice**: you must steel yourself for what is coming, and you must build up as much muscle mass and strength and cardiovascular fitness as you can muster, because the longer you can ride it out, the better you’re going to be

- Rhonda agrees, “*It’s like our retirement fund. You have to put money in because one day you will retire, and if you don’t put any money in that fund, you’re going to be screwed. And so with the muscle mass, you’re right. You have to bank as much as you can while you’re young.*”
- She points out that they haven’t talked about optimal [protein intake], they’ve just talked about not going backwards

***Most people are going backwards because the RDA is too low (that’s the big problem)***

## Finding the optimal protein dose [A: 25:00, V: 24:46]

- Coming from the field of aging, there’s a bit of a nuanced approach to looking at how protein affects the way we age
- Some of that data has biased researchers and people to think that protein is bad
- Aside from that, it’s really hard to understand why someone would be so opposed to increasing protein intake when there’s really just no evidence that it’s harmful, at least in healthy adults
- Peter points out that there are some [studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC4617900/) looking at 3 g/kg/day, and anybody who looks at the data would argue you’re not really getting a benefit at 3 g/kg/day that you aren’t getting at 2 g/kg/day
  - The curve is saturating
  - You’re hitting an asymptote of muscle protein synthesis at that point, so there may be other reasons a person would choose to consume that much protein (satiety and things of that nature)
  - But from a purely anabolic reason under normal conditions (not considering bodybuilders), you’ve hit the saturation curve
- But we can’t seem to find the evidence that it’s causing any harm
  - Experimental or epidemiologic evidence, just no evidence.
- Let’s go back, we’ve established a new floor: there is ***nobody that should be consuming less than 1.2 grams of protein per kilogram per day***

**What happens as we start to increase that from 1.2 to 1.6?**

- This is where Rhonda turns to experts like [Stu Phillips](https://mira.mcmaster.ca/our-faculty/stuart-phillips/)
- He did a really great [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/28698222/) looking at about 49 different studies in adults that were undergoing controlled trials, resistance training alone or resistance training plus supplemental protein, and the supplemental protein went up to 1.6
  - They found that even going from 1.2 g/kg/day to 1.6 gg/kg/day, ***people gained about 27% more lean body mass and 10% more muscle strength*** compared to just training alone
  - Same training, just adding the protein. That’s pretty big.
- Those are bigger gains than Peter would expect, especially on the strength side
- Rhonda thinks about supply and demand
  - We’re talking about people that have a more optimal protein intake and are training

> “*That’s number one, you need to be training. If we’re talking about optimal protein intake, you need to be training.*”‒ Rhonda Patrick

- What’s happening when you’re training is you’re breaking down muscle
- You need protein to support the repair of that muscle and the rebuilding of it, and so that makes sense in a way
- But yeah, she was surprised by the [gains in] strength as well

***Really, once you went above 1.6 grams, there was still increases in muscle protein***

Peter points out, “*Yeah, but the curve is slowing down.*”

- Rhonda likes the analogy that Phillips uses: “*If you have a wet washcloth, you squeeze it to get all the water out. Most of that water’s coming out at 1.6 g/kg body weight, but you can keep squeezing a little and you’re still getting some water out*.”
  - [The benefits of consuming >1.6 g/kg of protein are] just marginal; most people don’t care about that difference, some people do

Who’s going to want to go higher than 1.6 g/kg?

- Someone that’s obsessed with banking muscle mass
- A high level athlete, definitely going to have to go above 1.6
  - That’s when you get into the more 2, 2.2 g/kg body weight
  - People that are doing a high level of training, whether that’s endurance or strength training/resistance training
  - Because endurance athletes, you are battling being catabolic

***The evidence for more optimal protein intake is  about 1.6 g/kg body weight and you can get marginal benefits up to 2.2 g/kg, but that’s in people that are really training***

**Peter sees an analogy here with apoB and cardiovascular disease**

- If you look at the 3 bodies of evidence (all of the epidemiologic data, all of the clinical trial data, and all of the Mendelian randomization data) and you plot every single one of them on a graph [shown in the figure below]
  - On the X-axis you have [LDL-C](https://en.wikipedia.org/wiki/Low-density_lipoprotein) going down [magnitude of exposure to lower LDL-C]
  - On the Y-axis, you have cardiovascular mortality [proportional reduction in risk of coronary heart disease]
- [How to read the graph below: the blue line is from Mendelian randomization studies, the green line is from observational epidemiology studies, and the red line is from RCT]
- [Compare the change in proportional risk (y-axis) looking at two different LDL-C concentrations (x-axis) – for example, follow the yellow lines on the graph]
- [For example, compare a change in LDL-C going from 39 mg/dL to 23 mg/dL]
  - [This is a 16 mg/dL drop which most would say there is no need to treat]
- [The change in proportional risk is the difference in the percentage shown on the y-axis]
  - [Mendelian randomization studies show the risk goes from 53 to 35% (18% drop)]
  - [Observational studies show the risk goes from 33 to 23% (10% drop; typically 4-6 years difference)]
  - [RCT show the risk goes from 22 to 12% (10% drop, typically 2.5-5 years difference)]

![](https://peterattiamd.com/wp-content/uploads/2025/10/f2-rhondapatrick3-1024x666.png)

**Figure 2. Log-linear association per unit change in LDL-C and the risk of cardiovascular disease (CHD)**. Image credit: [*European Heart Journal* 2017](https://pmc.ncbi.nlm.nih.gov/articles/PMC5837225/)

- Not surprisingly, as LDL-C goes lower, cardiovascular mortality goes lower [clearly shown in the figure below]
- What’s interesting though is you can see that there are different points in the curve at which it starts to matter more
  - And at some point it flattens out ‒ you don’t get as much benefit from reduction

***We could use the same argument to think about what is optimal because we’re doing the reverse here: here, lower is better as opposed to going up on protein***

![](https://peterattiamd.com/wp-content/uploads/2025/10/f3-rhondapatrick3.png)

**Figure 3. The relationship between cardiovascular events and LDL-C.** Image credit: [*Journal of Clinical Endocrinology and Metabolism* 2019](https://pubmed.ncbi.nlm.nih.gov/30785997/)

- [Peter Libby](https://physiciandirectory.brighamandwomens.org/details/1055/peter-libby-cardiovascular_medicine-boston) has done an [analysis](https://pubmed.ncbi.nlm.nih.gov/31250329/) that has demonstrated that you will continue to see a meaningful reduction in cardiovascular disease as [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) heads towards 30 mg/dL
  - 30 mg/dL is really low by most people’s standards
  - For context, 60 mg/dL is about the 5th percentile at the population level
  - 30 mg/dL is about what a child is
- We’re born with relatively low levels of apoB and as we age, they just keep going up and up and up, which of course is one of the things that’s driving cardiovascular disease is this rise in apoB

So the question then becomes how low do you need to go?

- Should everybody be walking around at 30 mg/dL?
- Is that the solution to eliminating ASCVD?
- And the answer is probably not
- It probably depends on your previous exposure though
- For example, Peter has a patient who’s already had 2 stents placed and has a significant burden of disease
  - You bet your bottom line they are at 30 mg/dL of apoB
  - Even if we have to put 3 drugs on them to make sure that’s the case
  - Because their burden of disease and their lifetime exposure to apoB has been so high
- But he has another patient who is 40-years-old who has perfectly pristine coronary arteries and is walking around with an apoB of 60 mg/dL
  - And Peter doesn’t think they need to do a thing; they’re fine

Peter explains, “*It’s the inability I think for people to understand that level of nuance and understanding when it’s worth the second squeeze versus when just the sloppy squeeze is good enough. It’s very frustrating for a person like me who craves nuance.*”

- Rhonda thinks this analogy is perfect

## Why aiming higher is smarter: the case for targeting 2g of protein per kg of body weight in the real world [A: 32:15, V: 32:39]

***People that are training are getting a great amount of benefit from 1.6 g/kg body weight, but that doesn’t mean you can’t go above that and still get a little more benefit***

- Certainly when you start to get into that energy deficit phase as well
  - So we were talking about elite endurance athletes, that’s one way to be in an energy deficit
  - There’s also people that are actively trying to lose fat, gain muscle

**⇒** If you want to lose fat and gain muscle at the same time, you’re going to have to take in a lot of protein

**Another point Peter wants to make is you’re still dealing with an asymmetric target**

- He tells patients to be closer to 2 g/kg
- He knows that’s going to get a whole bunch of people on the anti-protein train just losing their mind.
  - How is this guy so irresponsible to tell his patients to eat 2 g of protein per kg of body weight?
  - Didn’t he just hear what Rhonda said, 1.6 is good enough for most people?

Peter’s “real world” advice

- Peter’s patients unfortunately don’t live in labs
  - And in the real world, you can’t always hit your targets
  - Some days you do, some days you don’t
  - Some days you’re traveling, some days your not
- If Peter is telling somebody to hit 1.6 and one day they’re at 1.2, another day they’re at 1.7, another day they’re at 1.5, another day they’re at 1.9
  - They’re average might hit 1.6
- But how many days were they below versus how many days were they above?
  - Let’s just say it’s an equal split
  - But we’ve just established the shape of this curve is like this
  - So that means every day you’re below, the downside is much greater than the upside of being above
  - In other words, all the days you’re above are not making up for all the days you’re below

***What Peter would really like to do is shift the range so that your low day is 1.6 and your high day is maybe 2.2***

- Then you don’t have days where you are ever amino acid restricted

Peter adds, “*And this is the difference between people who take care of people in the real world and bozos who write on Substack who don’t know the first thing about clinical medicine when it comes to managing athletes and people who have to fend for themselves every day with every meal.*”

- If you’re sitting there listening to this and you’re confused and you’re asking, “*Oh my God, should I be eating 2 g per day?*”
  - Yeah, more or less
  - And that way if you fall short at 1.6, you can be confident that you’re okay
- But if you’re aiming at 1.6 and you have a bad day and you will when you hit 1.2, you might be taking a step backwards and you won’t make up for it the next day

Rhonda shares, “*I can just tell you from personal experience, it’s actually smarter to aim higher because I’m constantly not meeting the 1.6.*”

- Peter is not either
- People look at him like he’s a protein eating machine, but he has a hard time hitting his goals too
  - He’s busy
  - He misses meals
  - Sometimes the family has a low protein meal for whatever reason (the kids want pasta for dinner)
- It’s very difficult if you don’t have a chef preparing your every meal, and Peter never has a chef preparing any of his meals unless he’s out at a restaurant ‒ it’s difficult to hit these targets every day

**Back to the minimum amount of protein needed to not be in amino acid deficit**

- Rhonda was thinking about what they mentioned earlier: 1.2 being this sort of the minimum buy-in
- The 1.6 g/kg body weight isn’t necessarily just for people training a little bit ‒ it’s also older adults that are not training
  - Because we talked about the anabolic resistance, and them needing twice as much protein

**⇒** What you’re talking about here is going up to 2 g/kg so that you can really have an average at least of 1.6 g/kg

- Peter never wants to fall below 1.6 g/kg
- The point is, he knows he’s training every single day
  - Not like a madman
  - But some form of cardio or something in the gym

Peter adds, “*I know that I’m going to take steps backwards if I’m below 1.6. So I’m going to overshoot so that my down day is 1.6. and if my up day is 2.5 once in a while, who cares?*”

**The next point: Show me the data that eating 2.5 g of protein per kg per day is even remotely harmful**

- [David Allison](https://www.pcori.org/people/david-b-allison-phd) wrote a piece on [LinkedIn](https://www.linkedin.com/posts/david-allison-2917963b_the-danger-of-high-protein-intake-in-normal-activity-7358769010160685056-mWak?utm_source=share&utm_medium=member_desktop&rcm=ACoAAE2HT-MB2Pl_osdQk7zoQJZ9yElSWDEuXIg) recently that was a call to anyone: just show me the data that meet these criteria (human clinical trials)
  - Nothing but crickets
- Rhonda hasn’t seen any human data on this either
- The most negative data Peter saw recently was a [study](https://pubmed.ncbi.nlm.nih.gov/40383260/) that looked at total parenteral nutrition in ICU patients
  - The question was, “*Should we be ramming high amounts of protein in these people?*”
  - And the most negative thing you could say is it had no benefit
- Peter’s conclusion was maybe we shouldn’t be ramming high protein total parenteral nutrition into the central veins of critically ill ICU patients, but it didn’t harm them
- And if anybody is going to be harmed, it’s the people that are in renal failure

## Protein needs for pregnant women and growing adolescents [A: 37:30, V: 38:26]

**What do we know about the protein requirements for women who are pregnant (or who will become pregnant) and also adolescents?**

*Are there any formal recommendations for these 2 groups?*

- Protein requirements go up, but Rhonda doesn’t remember what the recommendation is
  - [the [American Pregnancy Association](https://americanpregnancy.org/healthy-pregnancy/pregnancy-health-wellness/pregnancy-nutrition/#:~:text=Experts%20recommend%2075%20to%20100%20grams%20of%20protein%20per%20day) recommends pregnant women eat 75-100 g protein per day while the [RDA for protein in pregnant women](https://pmc.ncbi.nlm.nih.gov/articles/PMC7997328/#:~:text=RDA)%20for%20protein%20during%20the%20first%20trimester%20of%20pregnancy%20is%20estimated%20at%2046%20g/day%20(0.8%20g/kg%20bw/day)%2C%20and%20at%2071%20g/day%20(1.1%20g/kg%20bw/day)%20during%20the%20second%20and%20third%20trimesters%20%5B3%5D.) increases for the 2nd and 3rd trimesters to 1.1 g/kg/day]
  - [for adolescents, [healthy children.org](https://www.healthychildren.org/English/ages-stages/teen/nutrition/Pages/Protein-for-the-Teen-Athlete.aspx#:~:text=The%20amount%20of%20protein%20adolescents,meet%20his%20daily%20protein%20requirement) recommends 50 g/day while the [dietary reference intake (DRI)](https://www.ncbi.nlm.nih.gov/books/NBK214999/) is 27 g/day for males and 28 g/day for females]
- It’s all about going a little bit above what’s the RDA, and we’ve already established that’s not enough

***Rhonda’s take-home message: just knowing that 0.8 g/kg/day is not enough***

- That’s the single most important message because everyone looks at those guidelines

For example

- The other day, Peter was eating something ‒ he forgets how much protein it had in it, but it had % of daily requirement (obviously baked to a very low number)
- His son looked at it and goes, “*Is that really 40% of your daily protein requirement?*”
- Peter told him, “*No, this is just wrong. You can ignore this*”
  - He didn’t have the energy to explain the RDA to him

**Growing is an important time for protein**

- Amino acids are activating [IGF-1 growth hormone](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) and that’s really important for growth
- There were [studies](https://pubmed.ncbi.nlm.nih.gov/35109944/) done in infants and toddlers that were given egg versus milk versus some kind of vegan protein, and it was clear that the egg was the winner here
  - Egg protein provided more essential amino acids that were important for growing taller, and that’s always something that Rhonda as a mom thinks about
- Plus kids are more physically active ‒ it’s really important to get the protein requirements
- Rhonda hasn’t dug into the nuance of that data

***The way she looks at it is it’s got to be 1.2 g/kg***

- An adolescent is pretty close in body size to an adult
- Peter would think it should be at least 1.2-1.6 g/kg
  - The activity level of his kids makes him look sedentary

## Why higher protein intake is crucial when trying to lose fat while preserving or gaining muscle [A: 39:45, V: 41:05]

**Anything else we want to say on the topic of protein to help with some of the confusion that is out there?**

*For people restricting calories or doing intermittent fasting, wanting to gain muscle and lose fat*

- That is a very specific group of population of people where **high protein intake is critical** because if you’re in a caloric deficit, you really are battling your body pulling from your muscle reserve
- If you’re resistance training, that helps somewhat, but you’re certainly not going to gain muscle
- And we just talked about wanting to bank as much muscle as possible as we’re younger while we can because we need that reserve because we’re going to start pulling from it eventually
- That’s where you start to get really high numbers: **2.2, g/kg** or even higher
- You can find studies out there using 3 g/kg

***Going above the 1.6 in this scenario seems to be key as well when you’re getting up to that 2.2 g/kg/day because it does give you a little bit more edge over gaining muscle***

- Muscle protein synthesis in combination with resistance training is a little bit thermogenic
  - You’re really wanting to prevent this catabolism

**There was a period of time over the course of a year where Peter made a very dedicated goal to lose body weight and gain muscle**

- It did require quite a bit of time restricted eating
- The amount of attention I had to pay to protein intake was pretty incredible
- And what I did that seems counterintuitive because he wasn’t intermittent fasting because I believed that a fasted state was producing some benefit
  - Some people think that, “*Well, if I don’t eat breakfast, I’m kicking off some autophagy or something*.”
  - No, no. It was purely a caloric restriction ploy
  - ***His fasting window did not prevent consuming liquid protein***

Peter shares, “*In other words, if I wasn’t eating breakfast or lunch (which I wasn’t, I was only having a meal a day, which was dinner) but I would still consume protein shakes outside of those windows. Otherwise, I could never hit the protein target.*”

***He was in caloric deficit, but in amino acid excess***

- You can do that pretty easily with whey protein

Rhonda asks, “*Did you have any GI problems consuming so many shakes?*”

- No, but the did a lot of experimentation
- He ultimately settled on a brand that he really liked
  - He’s blanking on the name, maybe [Ascent](https://www.ascentprotein.com/collections/protein-powder)
  - He has no affiliation with them
  - It was the only protein he could mix directly in water and not have it be lumpy; he didn’t even need a blender
- He liked that better than the pure egg proteins (the feeling on his gut)
- This is another level of challenge if you’re trying to recomp in that way

## GLP-1 drugs: protein needs, muscle preservation, dosing strategies, evidence of broader health impacts, and more [A: 43:45, V: 45:31]

**People on GLP-1 receptor agonists**

- Rhonda doesn’t know how difficult it is to eat a meal versus take a protein shake
- On [GLP-1 receptor agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist), you’re satiated pretty much all the time
  - You don’t have a real appetite
  - Also digestion is slowed

Rhonda asks, “*So if you’re consuming more protein, I don’t know how that all affects.*”

- 15-20% of Peter’s patients are on [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide)
- And unlike 5 years ago when we started using [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) in patients and we’re just watching muscle fall off these people
  - Frankly, his point of view 5 years ago was, “*I don’t know about these drugs. I think there’s some benefit in some people, but I think there’s a lot of downside.*”

***Today, Peter thinks that virtually anybody can use these drugs safely for long term muscle health, but it requires a ton of deliberate attention***

> “*This is exactly the group of people who you want to be using easy to digest protein sources*.”‒ Peter Attia

- If you’re on tirzepatide, you don’t really want a steak
  - You don’t really want to have a big chicken breast, you might not want to even have an omelet
- But if we have to make sure you’re hitting that 1.6, you might be doing a bunch of liquid shakes
- And yeah, we can sit here and poo poo processed food and say, “*How disgusting is it that people have to resort to eating shakes?*”
- But if the alternative is they’re not getting enough protein and they’re on a drug that is making them anorexic, we also know the downside of that

***Peter is doing DEXA on his patients before and after, and they’re not seeing the type of muscle loss on tirzepatide***

- Tirzepatide starts at a **dose** of 2.5 mg, and some people are getting enough benefit there
- His approach has been is: “slow and steady wins the race”
- Anecdotally Peter has heard from others, and seen it in patients: that yo-yoing on and off these drugs is probably a bad idea
- He always tell a patient, “*Look, I’d probably rather you were on 2.5 mg until there was a new drug that we felt was even better than you’re on 10 mg, you lose a ton of weight, you come off, you gain, you go back on, you lose.*”
  - The idea of being on a saw is probably a bad idea

Peter explains, “*I think the data suggest you’re getting most of the value by about 10 milligrams. So once you go to 12.5 and 15, which are the two highest doses, you’re still getting a benefit. But it’s like most drugs, you’re getting most of the benefit at the lowest dose. So 5 to 7.5 milligrams of tirzepatide is probably where you’re getting the majority of the benefit.*”

Rhonda asks, “*What do you think about some of that data on heart issues or bone loss? Does that concern you at all?*”

- Sure, it all does
- The question comes back to: ***How much of that is occurring due to the loss of amino acid intake and the loss of training?***

**What Rhonda is interested in: How much of the benefits of GLP-1 agonists are from weight loss?**

- We have these GLP-1 receptors on so many different tissues
- Systemically, how is it beneficial? Is it not beneficial?
  - She doesn’t know that we really know
- We have data where there’s obviously positive effects
- You see reduced Alzheimer’s disease incidence with people taking these GLP-1 receptor agonists, but how much is that due to weight loss?

Peter has looked into this a lot

- He did a podcast [[episode #320](https://peterattiamd.com/ama64/)] on this somewhat recently where he went through this particular question: **Will GLP-1 receptor agonists ultimately prove to be geroprotective?**
  - He came up with a very obscure way to define that (which is independent of weight loss): if you apply them to people with type 2 diabetes and significant obesity and you correct the metabolic dysfunction, you’re going to live longer
  - So by that regard, it’s a geroprotective agent
- But the real question is if you take a person who is of normal weight, who does not have type 2 diabetes, but maybe has a higher risk for Alzheimer’s disease and you microdose them (2.5 mg/day)

**Peter’s experience with patients microdosing tirzepatide**

- Peter is doing this in some patients for obscure metabolic condition without obesity (diabetes and very low body weight) and the effect on their diabetes is profound
  - Along with very careful strategies around nutrition

Rhonda asks, “*They’re looking more metabolically healthy?*”

- These are really interesting cases ‒ you simply cannot believe the degree of metabolic dysfunction in a person who otherwise looks the way they look [thin]
- In one case in particular, it was so confusing that even after all the genetic testing we did, we simply couldn’t figure out an answer for this
  - We couldn’t understand where the β-cell fatigue was coming from, absent a formal diagnosis of type I diabetes
  - And within 3 months of being on 2.5 mg of tirzepatide, this individual’s OGTT had almost normalized
  - Peter expects that at 6 months it will
  - And we’ve managed to do this without any weight loss

The interesting question is when you look at some of the Alzheimer’s biomarkers

- Some of the Alzheimer’s biomarkers are improving significantly, and it begs the question: Should this be part of the playbook for an individual who’s at high risk?
  - Especially given that we now we really understand how to make sure people don’t lose weight and don’t lose lean mass, and therefore Peter suspects they don’t lose bone density and all these other things that matter
- Rhonda speculates that if you’re microdosing, you’re not going to be as satiated and you’ll still have somewhat of an appetite

**Peter has seen some other weird things anecdotally**

- Patients have told him that when they inject in the abdomen (the subcutaneous fat of the abdomen), the **anorexic effects** are greater than if you inject in the leg or butt
- There was some mechanistic data to suggest that maybe you’re getting more **vagal tone** when you inject in the abdomen
- Again, Peter doesn’t know if any of these things are correct, they would need to be studied
- But that would be a very important piece of data: if there’s a location you can inject this where you minimize the anorexic effect of the drug
  - For some people that would be a feature, not a bug
  - For some people that would be a bug as opposed to a feature
  - So you have to understand how to use the tool

## How overweight individuals should calculate protein needs based on target body weight [A: 50:45, V: 53:54]

**Talking about obese people losing weight**

- This reminded Rhonda of something they should have pointed on regarding protein requirements
- Most people aren’t going to do a DEXA scan on to see what their lean body mass is
- Rhonda has talked to a variety of experts ([Brad Schoenfeld](https://www.lehman.edu/academics/health-human-services-nursing/exercise-sciences-recreation/bradley-schoenfeld/), [Stu Phillips](https://mira.mcmaster.ca/our-faculty/stuart-phillips/)) and they agree that really if you’re someone that’s overweight or obese, you shouldn’t be calculating it based on your actual weight because your protein requires way too high
  - [*FoundMyFitness* episodes [#78](https://www.foundmyfitness.com/episodes/brad-schoenfeld) and [#76](https://www.foundmyfitness.com/episodes/stuart-phillips)]

***Calculate protein intake based on your target weight***

- If you empirically could measure your lean body mass, that would be better
- Peter is glad she pointed this out
- For most people, probably it’s not much of an issue, but if you’re at 300 lbs right now and your ideal body weight is 220, you don’t need a DEXA to figure that out.
- Peter remembers at the end of high school, he was 200 lbs
  - That was his good weight
  - Which is he’ll probably never get back into those jeans again
- But by the end of his freshman year of college, he was 220.

***Most people can probably figure out their goal weight, and that’s what they should be targeting their protein intake to***

## Unpacking a misunderstood topic: the relationship between protein intake, mTOR activation, and longevity [A: 52:00, V: 55:29]

**How do we reconcile caloric restriction as a geroprotective intervention with the advice to increase protein intake?**

- It’s the oldest one in the book
- Peter is not aware of an intervention where a non-genetic intervention that has from a longer standing perspective produced a more consistent outcome in terms of laboratory animals where you restrict them of calories and they’re going to live longer
- To his knowledge, there are only 2 interventions that have extended life across all 4 models of organisms from yeast, worms, flies and mammals, rodents, and that is **caloric restriction** and [rapamycin](https://en.wikipedia.org/wiki/Sirolimus)

***They have one thing in common: they both result in the down regulation of*** [***mTOR***](https://en.wikipedia.org/wiki/MTOR)

**⇒** We also know that an amino acid leucine (mentioned earlier) is the single most important of all the amino acids at turning up mTOR

Peter asks, “*So how can we reconcile the idea that protein seems to be good for you, but mTOR going down seems to be good for you, at least in another way?*”

- Rhonda suggests ignoring the worm and fly data, because who cares
- Even the rodent data is a stretch

Rhonda points out, “*You know what else turns on mTOR? Exercise, physical activity, mechanical force turns it on in our muscle, and we know exercise is one of the best things that we can do for our health.*”

- For simplicity, the best way to think about this is that you want mTOR active in your active skeletal muscle
- You don’t necessarily always want it active systemically, but if you are exercising, if you’re moving around and you’re taking in protein (it’s going to your muscle)
  - We know that for a fact
- Rhonda talked about anabolic resistance and how exercise can counter that
  - While it’s increasing the expression of leucine transporter, it’s causing leucine and other branched-chain amino acids to go up into skeletal muscle
  - Multiple [human studies](https://pubmed.ncbi.nlm.nih.gov/7900797/) have shown this
  - These are tracer studies, beautiful data, no argument

***Exercise causes leucine and other branched-chain amino acids to be taken up into skeletal muscle where you want it to be so that it activates mTOR, increases muscle protein synthesis***

- When it comes to **deactivating mTOR**, whether that’s through protein restriction or rapamycin, that would be an hour’s long podcast talking about all the nuanced data there, because there’s all sorts of differences with sex, differences in rodents
  - Her point is about protein restriction

**Important differences between mice and humans, and why mouse studies don’t tell the whole story**

Rhonda spent 6 years in grad school working with mice

- These mice are in a small cage, and they are not physically active, they’re not running around
- They’re not under threat
- They’re being fed ad libitum, being fed up as much protein as they want
- They’re perfectly thermoregulated
- They’re not being exposed to influenza or COVID, whatever viruses, anything that’s going to take them out for a period of a couple of weeks
  - They’re in a sterile environment
- They’re happy and that’s it

***People are not mice***

- As we get older, we’re being exposed to infectious diseases
- Things are going to make us immobile for a period of weeks, and that is devastating to us
  - Especially when you add them up and they happen this year, and then the next year it happens again
  - And then you’re just losing that muscle mass, and then you reach that disability threshold
- Peter talked earlier about [Luc van Loon](https://peterattiamd.com/lucvanloon/) talking about those curves
- It’s very clear: you can see the data where there’s a disability threshold
- You get enough of these catabolic crisis events where you’re just immobile for a certain period of time because you’ve had a surgery or you’ve had the flu or whatever’s kept you inactive

***That doesn’t happen to these mice ‒ so protein is much more important to humans because we need that muscle mass and we need to bank it early***

- Rhonda thinks that’s a really important difference, and we can’t just look at the data in mice and go, “*Oh, you can restrict them from protein and they live longer and they’re fine.*”

**⇒** Mice are not going through these catabolic crises

- Mice are *not* going through these points of not moving for a period of time for losing all this muscle mass where they reach this disability threshold (it’s not happening in mice)

**Back to protein intake: comparing needs of a sedentary person to an active person**

- Rhonda and Peter agree, the optimal scenario here isn’t a sedentary person just sitting there eating as much protein as they want
  - No, they need to be moving physically active (that’s the whole point)
- You’re supporting your physical activity by increasing your protein intake

***With exercise, the amino acids that are activating mTOR and are going to skeletal muscle (leucine is going into skeletal muscle)***

- So who cares if you [the sedentary person] isn’t taking in more?

*Peter thinks that’s an important point and take it one step further*

**⇒** If you told him to come up with the optimal nutrition strategy for the individual who is *active* and then come up with the optimal nutrition strategy for a person who is going to be *sedentary*, they would be very different

- He’s going to try to talk that sedentary person into not being sedentary
- But if at the end of the day that individual says, “*I don’t want to do anything, I just want to sit in front of my computer.*”
  - You know what? It probably makes sense to be a little bit caloric restricted because you can’t solve your metabolic challenge through activity
  - But what if you could at least solve it through nutrition restriction?

Peter explains, “*I think it’s the inability of people to understand that those are very different states. You cannot treat those 2 people the same way*.”

- Rhonda mentions a [study](https://pmc.ncbi.nlm.nih.gov/articles/PMC5048552/) by [Valter Longo](https://valterlongo.com/biography/) that came out years ago
  - It was a large cohort study looking at dietary protein intake from vegetable versus meat sources
- And we all know that meat sources have higher levels of essential amino acids like leucine
- This study looked at all-cause mortality
- You’ve heard millions of times from other studies about vegans have a lower all-cause mortality than meat eaters
- Well, it turns out when you actually start to analyze the data and correct for a lot of confounding factors, meat eaters that were physically active, were not obese or overweight, didn’t smoke, didn’t drink excessive alcohol ‒ they had the same mortality rate as vegans

***In other words, when meat eaters didn’t have all these unhealthy lifestyle factors, they had the same mortality rate as the vegans***

Rhonda’s takeaway

- If you’re going to be a **sedentary person** that’s smoking, and if you have unhealthy lifestyle factors, maybe you don’t need to be so obsessed [with protein intake]
- You definitely want to make sure you’re at least getting the minimal amount of protein because you don’t want to be in the deficit, but you don’t want to necessarily just be constantly activating mTOR if you’re just going to sit around and smoke and be overweight and not do anything with that protein

**Peter’s analogy to inflammation**

- Most people on the surface understand that a constant “on” state of the inflammatory system would be bad, but of course if you had no inflammatory response, that would be also bad
- So the ideal state is: inflammation when you need it, otherwise “off”

***And Peter thinks that’s probably the right way to think about this, which is we want mTOR “on” when it has a job to do, and we want it relatively silent when we don’t***

- Further, he thinks if [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) is geroprotective in humans, it’s probably working by tamping down the chronic inflammatory component of what we see with mTOR activation
  - Which might actually involve inflammation as well as one of the many things

**There’s also the challenge of trying to get folks to understand the difference between chronic and acute things**

*Cortisol is a great example*

- [Cortisol](https://en.wikipedia.org/wiki/Cortisol) is a vital hormone
- The appropriate rhythm of cortisol is essential for life
- If you took that away, you would actually be dead (that’s called [Addison’s disease](https://en.wikipedia.org/wiki/Addison%27s_disease))
- But cortisol constantly being on would also be a problem (that would be [Cushing’s disease](https://en.wikipedia.org/wiki/Cushing%27s_disease))
- So both extremes are bad

***The same is true with mTOR***

## Why it’s unclear whether rapamycin is geroprotective in humans, and how misinterpreted animal data have fueled misconceptions about protein or mTOR activation being harmful [A: 1:00:45, V: 1:05:21]

**Speculating on the benefits of (or lack thereof) rapamycin**

Rhonda would like to see data comparing inhibiting mTOR versus physical activity

- Even animal data
- Running on a treadmill, being physically active
- Because if you look at a lot of the effects of Rapamycin, Rhonda’s take is: this is what exercise does and exercise does it better
- Rhonda is not convinced that someone who’s already bought into how important exercise is (both cardiovascular and weight training)

Peter remembers that [Eric Verdin](https://www.buckinstitute.org/lab/verdin-lab/) made a very interesting comment on the podcast a while ago

- Eric is in the camp that he does not believe rapamycin will be geroprotective in humans
- [[episode #359](https://peterattiamd.com/ericverdin/)]
- Eric talked about the [longevity quotient](https://en.wikipedia.org/wiki/Longevity_quotient)
  - [[after 1:08:15](https://peterattiamd.com/ericverdin/#:~:text=The%20longevity%20quotient%20is%20this%20idea%20that%2C%20if%20you%20look%20across%20the%20animal%20kingdom%2C%20the%20larger%20you%20are%2C%20the%20longer%20you%20live)]
  - This is a very famous plot [shown below], that shows body size on the x-axis and lifespan on the y-axis
  - When you plot all the organisms on this thing, as a general rule, the relationship rises up and to the right: ***the larger an animal is, the longer it lives***

![](https://peterattiamd.com/wp-content/uploads/2025/10/f4-rhondapatrick3.png)

**Figure 4. Relationship observed between life expectancy and body size**. Image credit: [*Proceedings, Biological Sciences* 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4043093/)

- But there are always animals that punch above and below their weight
  - These are animals that live much longer than you would expect based on their body size
  - And there are animals that live much shorter than they should based on their body weight

Well, it turns out two interesting examples are mice and humans

- Mice live on average 2 years
  - Peter forgets the exact number, but they should be living close to 4 or 5 years based on the longevity quotient line
  - So they are punching well below their weight
- Humans, we live 80 years
  - We should probably be 40 according to the data
  - By the way, we did live 40 years until modern medicine came along
  - So maybe we were totally on the curve correctly until Medicine 2.0 came around at the turn of the last century and basically over five generations doubled our lifespan

Eric makes an interesting argument

***Eric argues that rapamycin disproportionately works well in animals that are below the longevity quotient, and that’s why it works so reproducibly in mice, but he argues it might not have any effect in humans because we’ve already captured so much of our genetic potential in terms of lifespan***

- Now the idea that rapa would give us an extra 15% of life, he feels is just kind of hard to imagine
- Again, that’s a theoretical argument
- It’s super interesting, but Peter had never heard it in relation to the longevity quotient before and he thought it was very much worth pondering

**Rhonda has seen data from people using rapamycin and resistance training**

- Rapamycin [blunted](https://pmc.ncbi.nlm.nih.gov/articles/PMC2678224/) some of the muscle protein synthesis (as would be expected)

Peter wonders, “*Is there a way around that? Is there a way where you could intermittently dose it? You just take it once, you time it so that it’s not in proximity to a bout of resistance training by a couple of days or something like that.*”

- The [mTOR study](https://pmc.ncbi.nlm.nih.gov/articles/PMC10709984/#Sec3) that Rhonda is thinking of was an animal study where they gave mice the (human equivalent of) 25 g of protein and mTOR was activated in macrophages
- This whole story was pieced together about atherosclerosis, and it was essentially arguing that atherosclerosis was being caused by protein
  - Rhonda was like, “*Are you kidding me?*”
- It comes down to activating mTOR in systemic circulation versus the leucine going to the muscle because you’re physically active
- Keep in mind, those leucine transporters, they’re pretty sensitive for quite a while
  - At least 24 hours, maybe even longer [after exercise]

Peter thinks the mice atherosclerosis studies are very dangerous, and we have to be very careful

- They have a very different lipoprotein system than we do
- They evolved in a totally different manner than we did
- The amount of protein they require is totally different from us
- So he’s always really wary when he sees these studies that are using the mouse model of atherosclerosis
- He understands why we do it because it’s much easier and cheaper than looking at primates
  - And obviously we can’t do these studies in humans

***You can find a lot of things in mice when it comes to atherosclerosis that don’t seem to matter whatsoever in human biology, and he would chalk this up to one of those examples***

Rhonda points out, “*That’s a lot of the controversy around protein being bad for you and activating mTOR is coming from that study. And then there’s countless studies on cancer increasing with IGF-1 and mTOR. And again, same deal where IGF-1 exercise is causing IGF-1 to go into the brain, to go into muscle.*”

- Peter makes the point that [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) has a staggeringly short half-life ‒ on the order of minutes

**⇒** Administering IGF systemically is a lousy way to get it to the muscle

- You want to think of it almost as a paracrine thing where it has to be delivered into the muscle

## The unmatched longevity benefits of exercise, its synergy with higher protein intake, and Peter’s recommended protein intake [A: 1:06:15, V: 1:11:33]

***In Peter’s view, all roads still point back to this idea that exercise is the most important drug***

- He’s just not aware of a “drug” that is better than exercise
- And there’s this enormous effort to figure out a way to put exercise into a pill
  - He just can’t imagine it’ll ever happen
- There might be several pills that come out of it
  - We might figure out a way to make [klotho](https://peterattiamd.com/denadubal/), we might figure out a way to make [BDNF](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor), we might figure out a way to deliver IGF directly to muscles
  - There might be a whole bunch of little things
- Rhonda points out that 500 molecules change [with exercise]
- One example is [irisin](https://peterattiamd.com/irisin-the-magic-exercise-hormone/)

**Exercise and protein go hand in hand**

Rhonda adds, “*We’re talking about being optimal, increasing our health span, increasing our lifespan, having a good quality of life. Then you’re talking about having a higher protein intake to support your physical activity, period.*”

- Athletes, they’re some of the longest-lived individuals on the planet
  - They talked about this in their last podcast [[episode #252](https://peterattiamd.com/rhondapatrick2/)]
  - Olympic athletes live on average 5 years longer than the general population
  - Same goes with a lot of these athletes playing these indoor team sports
- There are several studies out there looking at elite athletes, including people in the NBA, major league baseball, a lot of these big professional sports leagues, they’re taking in at least 2 g protein per kg per day
  - Clearly protein isn’t killing them
  - In fact, they’re living longer than the general population

> “*Again, it comes down to that exercise is the king, right? Exercise is the most important thing, but you need a protein to support that physical activity.*”‒ Rhonda Patrick

***Rhonda doesn’t understand why anyone’s arguing about that. What’s the argument?***

**Peter’s recommendation for protein intake**

- Despite all the flak he’s taking, he’s going to defend this one and continue
- And if new data emerge, he’s always happy to change his mind
  - He’s changed his mind about so many things: GLP-1 agonists, sauna

Peter adds, “*If there are data that will make me change my mind, I will stand up here with a straight face and I will eat crow and I will tell you that I’ve changed my mind.*”

***Peter stands by his recommendation of 2 g/kg/day***

- As he explained earlier, if you aim for 2 and fall short, you’ll still be at 1.6
  - If you aim for 1.6 and fall short, you’ll be at 1.2
  - ***And 1.2 won’t be made up for on the next day because the downside is asymmetric compared to the upside***
- This is why he recommends 2 g protein per kg clinically
  - That’s how he works with real people in the real world to try to help them live a longer life

Rhonda asks, “*Is there anything else with the protein?*”

Peter replies, “*No, let’s never talk about this again pending new data that fundamentally changed the way we think about it.*”

## How Rhonda became fascinated with creatine—a well-studied, safe, and effective supplement for improving exercise performance [A: 1:09:00, V: 1:14:52]

- Peter wants to pivot to talk about [creatine](https://en.wikipedia.org/wiki/Creatine), a topic which Rhonda may be single-handedly more responsible for the buzz on than anybody else
- [*FoundMyFitness* [episode #100](https://www.foundmyfitness.com/episodes/darren-candow)]
- Peter remembers when he was in high school, boys in the 80s were mainlining creatine, but he doesn’t remember why
  - It must have come from bodybuilding magazines
- At the time, everyone said creatine phosphate is better and you had to load 30 g a day for 2 weeks, then go into your maintenance phase at 5 g a day
  - Then you repeat the cycle every 8 weeks
- This was 35 years ago, and fast-forward to a few years ago, and we’re paying attention to creatine again

**What got you interested in this topic?**

- It’s one of the most well studied sports related supplements ever
  - There’s just decades and decades of research out there on creatine
  - A lot of it has to do with muscle
  - We’ll talk about the brain, which is Rhonda’s interest
- It’s one of the tried and true supplements
- It’s safe
- Rhonda doesn’t know that there’s any other sports supplement out there that’s as safe as creatine (that’s an important point)

***Rhonda’s journey with it began with her obsession with increasing her resistance training***

- Everything they talked about in the first half of this episode

Rhonda admits, “*I realized that I was so focused on endurance training for long-term health, for brain health, that I sort of neglected my muscle mass and thinking about how important muscle mass was for long-term health.*”

- Peter points out that she has chronicled this pretty well on [social media](https://www.instagram.com/reel/C-EjtrQJcWY/?utm_source=ig_web_copy_link&igsh=NTc4MTIwNjQ2YQ==)

- Rhonda had a couple of experts on and reads the literature voraciously
  - [*FoundMyFitness* [collection](https://www.foundmyfitness.com/tags/strength) on strength]
- She realized that she wasn’t doing enough resistance training
- Rhonda has a personal trainer now

- She is now doing resistance-type training
- She does CrossFit-type training for at least 3 hours a week now
  - When she started out, she was doing 30 minutes a week
- And that’s when she became really interested in creatine

***It’s the one supplement has been shown to benefit people that are working out***

**Rhonda didn’t know why creatine was beneficial until she got into the literature**

- Most people know creatine is stored in our skeletal muscle as creatine phosphate, and it’s essentially used to rapidly recycle [ATP (adenosine triphosphate)](https://en.wikipedia.org/wiki/Adenosine_triphosphate)
  - This is the major energy currency in our cells

**⇒** Creatine phosphate is able to help rapidly recycle ATP so you can make energy quicker ‒ very relevant for a lot of scenarios, including high intensity interval training, resistance training, even endurance training because it decreases recovery time because you’re recycling that ATP

- We make creatine endogenously ‒ about 1-2 g/day in our liver
- Meat is the major dietary source of creatine
- So vegetarians 100% rely on the 1-2 g/day made by the liver, and they’re probably the population that benefits the most with supplementing with creatine
  - There are countless studies showing that vegetarians aren’t getting any creatine from their diet

Peter asks, “*Does the type of meat matter? Does fish versus beef versus chicken? I would imagine there are differences.*”

- Yes, there are differences
- Beef would provide the most creatine
  - It’s probably why people on a carnivore diet, they just get so jacked ‒ they’re getting protein and they’re working out

*Do you have a sense of if you eat a 12-ounce steak, how many grams of creatine would you get?*

- Generally speaking, on average, people are getting 1-2 g of creatine in their diet, plus you have endogenous production of another 1-2 g/day
  - [the figure below shows the creatine content for different types of meat]
- And you can supplement on top of that

![](https://peterattiamd.com/wp-content/uploads/2025/10/f5-rhondapatrick3.png)

**Figure 5. Creatine content in common foods**. Image credit: [ResearchGate](https://www.researchgate.net/figure/Creatine-Content-in-Select-Foods_tbl3_227249571)

**For many, many decades, the literature was all about the effects on exercise performance**

- Because the muscle is a big consumer of energy, especially if you’re working the muscle

**⇒** Generally speaking, 5 g/day of creatine is enough to saturate your muscle tissue

- It takes about a month (maybe 3 weeks) to actually fully saturate it if you’re doing 5 g a day

Peter’s reaction, “*Hence the bros that were telling me to take 30 when I was 13. That might’ve been overkill.*”

- Why people do that **loading phase**: when doing short-term weeks-long studies, people want to quickly get their muscles saturated
- Most people don’t have to do that unless you’re doing some competition and you need it right then and there
  - Generally speaking, it’s not necessary and you increase the risk of GI distress

Peter asks, “*Our thinking today is just take 5 g every day and then you should be all right.*”

- That was Rhonda’s thinking up until a few months ago
- For the last year and a half, she was taking about 5 g/day

***The evidence there is that the creatine is essentially improving your exercise performance in that you can do one to two more reps or essentially the volume of training goes up because you’re recycling that energy quicker***

- You’re able to do more, and that’s the reason you increase muscle mass and strength (because you’re able to do more work)
- Rhonda found with CrossFit, it really is useful because there’s a lot of explosive training, a lot of HIIT

Rhonda shares, “*For me, it was pretty obvious that it was having an effect. And of course there’s probably a mixture of placebo in there as well (I’ll definitely admit that).*”

## Creatine for the brain: how higher doses may enhance cognition under stress and support resilience against aging and disease [A: 1:16:30, V: 1:23:26]

- Rhonda is very interested in brain health, neurodegenerative disease risk, anything that can improve cognitive function in a safe way, any kind of safe [nootropic](https://en.wikipedia.org/wiki/Nootropic)
- Her interest has built up over years where she was getting interested in the brain effects, even though she hadn’t been supplementing with it
- She had been keeping an eye on the literature
- Finally, when she started using it, she got pushed over and was like, “*Okay, I’m all in. I want to get into this.*”
- The literature was clear with the muscle ‒ there’s a lot of literature
  - You can’t deny it
  - [read more on the [creatine topic page](https://www.foundmyfitness.com/topics/creatine) at *FoundMyFitness*]

Peter points out, “*It is a little odd. There aren’t that many things that show up where the consistency of the studies is always in the same direction. And really what you’re basically looking at is the magnitude or the effect size, but you’re always on the same side of the tornado plot.*”

- And when we’re talking about 40 years or whatever of research, that’s a lot of data
- Your brain does make a little bit of creatine as well (somewhere between 1-3 g/day)

Rhonda cautions, “*The data on the effects of supplemental creatine on the brain isn’t dating back as far. And so you do have to kind of take the data with somewhat of a grain of salt because there’s a lot of small studies and they’re not… the end all be all.*”

**Let’s talk about some of the measurements**

- Peter thinks one of the advantages of studying the effects of creatine on physical performance is we have really good objective measurements that you can demonstrate in a short period of time
  - You can do a 12-week study and in just 12 weeks you could objectively, unambiguously determine if there was hypertrophy and if there was an increase in performance

*How do we do that on the cognitive side?*

*What are the data that you’ve been looking at that have given you an increasing level of confidence?*

First let’s talk about **dose** because that’s important

- That was where initially when researchers were looking into the effects of creatine on the brain, the ***5 g/day didn’t seem to be doing anything in terms of getting creatine into the brain***

**⇒** Creatine crosses the [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier) but the muscles are greedy as hell (especially if you’re training)

- There was a German [study](https://pubmed.ncbi.nlm.nih.gov/10484486/) that was published a few years back that did a dose-dependent effect and looked at creatine levels in certain brain regions

Peter asks, “*Naive question, are they using an isotope? Are they labeling creatine?*”

- [the [study](https://pubmed.ncbi.nlm.nih.gov/10484486/) referenced used [MRI](https://en.wikipedia.org/wiki/In_vivo_magnetic_resonance_spectroscopy)]
- Taking 10 g of creatine means it’s not rate-limited and you are increasing levels of creatine in the brain
  - You have to double that [typical 5 d/day dose]

Peter asks, “*Does that mean that you’re going to get mixed results if you look at the cognition literature, because you’re going to have some studies that were under-dosed, and if you have a study that was done at 5 and it shows no effect, you’re going to come to the wrong conclusion potentially?*”

***Bingo, just like with any supplement and or drug, dose matters***

- So yes, that is the case, but also it’s important to point out just like with muscle, you have to be stressing your muscle for creatine to work
  - You’re basically putting in the work and you’re able to put in more work, and that’s why you can increase muscle mass and you can increase strength

**With the brain, creatine works in the background of stress**

- Examples of stress: psychological stress (like you have an exam, marital, stress, whatever psychological stress, emotional stress), sleep deprivation is a big one, neurodegenerative disease or anything that’s compromising brain function
- That’s where creatine really shines in terms of cognitive function
- Rhonda thinks most people are constantly under stress
- Even just diving into the scientific literature, what we do every day, learning, that is the stress
  - The brain consumes a lot of energy as well

Peter adds, “*20% of our total caloric intake goes to an organ that weighs less than 2% of your body weight. It is the most insane statistic of the human body*.”

> “*Whatever psychological stress, emotional stress, sleep deprivation is a big one, neurodegenerative disease or anything that’s compromising brain function, that’s where creatine really shines in terms of cognitive function*.”‒ Rhonda Patrick

Which is why it makes sense that giving your brain extra creatine

- Creatine can help the brain recycle that energy quicker
- It would help particularly in the background of when you’re using more of that energy, if energy’s being triaged to whatever stress and the hormones and the whatever’s going on, fill in the blank
- The studies that typically are looking at the effects of creatine on cognitive function are looking at **processing speed** [[reviewed](https://pmc.ncbi.nlm.nih.gov/articles/PMC10721691/) in 2023]
  - They’re looking at a battery of tests that are typical of any fill in the blank supplement or treatment that is either going to improve cognitive function, memory being another one, right?
- Creatine has been shown to improve processing speed, but again, really it’s in the background of stress
  - Whether that’s stress being aging
  - Older adults seem to benefit from taking exogenous creatine or supplemental creatine
  - And people that are sleep-deprived (that’s a really big one)
- There’s been a few [studies](https://pubmed.ncbi.nlm.nih.gov/38418482/) that have shown people that are sleep-deprived
  - They gave 20-25 grams of creatine (based on their body weight), but if they were sleep-deprived and given that creatine, not only did the cognitive deficits that usually occur when you’re sleep-deprived not occur, but their cognitive processing speed was improved more than baseline.
  - Now, this is a small study, and we can’t just hang our hat on this one study

**Who is doing these studies?**

- Peter points out that there can’t really be any financial incentive to do them (creatine is ubiquitous; there’s no IP around it)
- [Darren Candow](https://www.uregina.ca/kinesiology-health-studies/directory/faculty/darrencandow.html) is someone who he’s getting into the brain stuff [*FoundMyFitness* [episode #100](https://www.foundmyfitness.com/episodes/darren-candow)]
- There’s quite a few people that have been doing muscle research, and it’s opening doors for them where they’re collaborating and they’re reaching out to people that are doing more neuroscience (it’s kind of exploded)

Peter realizes, “*This has got* [*Dom D’Agostino*](https://health.usf.edu/medicine/mpp/faculty/ddagosti)*‘s name written all over it… We got to talk Dom into doing this.*”

- A [pilot study](https://pmc.ncbi.nlm.nih.gov/articles/PMC12089086/) came out with people who have [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease)
  - They were given 20 g of creatine and it improved cognitive function in these patients with Alzheimer’s disease
  - [no placebo group]
  - Then had them exercise in an improved strength and improved lean body mass [[published](https://pubmed.ncbi.nlm.nih.gov/40977987/) separately]

**Peter is skeptical**

- He thinks the name of the game is prevention, and that’s where he’s more interested
  - Of course, that’s the hardest thing to study
- When we think about the energy crisis that’s happening in a brain with Alzheimer’s disease (AD) ‒ there are probably many paths towards AD
  - There are inflammatory paths
  - There are lipid mediated and vascular paths
  - There are sort of these more metabolic paths
- But when you take that individual who is most susceptible to the metabolic path towards dementia and 10 years earlier or 20 years earlier, you’re giving them a substrate that is augmenting ATP creation.
  - That’s the hardest thing to study
  - That’s also the single most important question in his mind

> “*Prevention is the name of the game for sure, a hundred percent.*”‒ Rhonda Patrick

- Unfortunately, there’s a lot of people’s parents out there that have it right now because they missed the boat on prevention
- Those people are obviously, their kids are willing to do anything to help them

***The point Rhonda wants to make is she thinks that creatine for the brain is the most interesting aspect of this area of research right now***

**⇒** She certainly thinks there’s really no downside to taking 10 g of creatine a day

- In cases of sleep deprivation: she just got back from China 5 days ago, and she’s been taking 15-20 g a day

## Optimal creatine use: dosing for adults and teens, safe product selection, debunking kidney myths, and more [A: 1:25:45, V: 1:34:27]

**GI side effects**

- Peter remembers, as a kid, he never had GI side effects even when taking 30 g a day, but for some people it’s 10-20 g
  - In one dose, that would affect a lot of people’s GI
- Rhonda does 5 g doses: she’ll put 5 g into water or tea, and takes it before noon
- She doesn’t know if this is placebo, but she doesn’t get sleepy in the afternoon anymore
  - Peter take is, “*If the placebo’s working for you, take it.*”
- It’s working because it’s physiologic, it’s a biological mechanism

***There really is no downside, and more evidence is showing that 10 gh is going to be the new baseline***

**If you aren’t in a state of jet lag, do you take 10 g a day (2 shots of 5 g) and you’re feeling great?**

- Yeah, that’s what Rhonda does

**Let’s talk a little bit about brands**

*Are most of the companies out there that are otherwise very reputable in making supplements?*

- Peter thinks there are a handful of supplement companies that seem to be credible (Thorne, Momentous)

*Is there any difference between them?*

*Do you always look to make sure that* [*Creapure®*](https://www.creapure.com/en/creapure/what-creapure) *is the active ingredient within it or does it matter?*

***Rhonda thinks the most important thing is that it’s creatine monohydrate***

- The reason people like Creapure*®* is because it’s pure
- But what Rhonda likes even more than that is [NSF certification](https://en.wikipedia.org/wiki/NSF_International) because there’s rigorous testing to make sure there’s no lead contamination and these heavy metals and things that sort of hitchhike on a lot of these supplements.
  - That’s what she looks for
  - She uses [Thorne](https://www.thorne.com/products/dp/creatine)
- She thinks Creapure*®* is great too, depending on whatever brand is using creapure
- There’s no reason you can’t have both ‒ you could have Creapure*®* and an NSF certified product

**Creatine gummies are very popular but there was a third party test**

*Why don’t you tell what they discovered*

- There was [third party testing](https://www.wired.com/story/creatine-gummies-dubious-claims/) looking at actually quantifying the levels of creatine monohydrate in these gummies, and there was essentially none in 95% of them

Rhonda explains, “*That does, I think, translate to gummies in general. I’ve talked to vitamin manufacturers and they’ve said it is incredibly challenging to get an active ingredient into a gummy and you’re heating it up, so there’s the heat component that’s degrading things*.”

- She would avoid a creatine gummy

This whole gummy craze drives Peter bananas

- How many gummies does he need to eat?
- Look at the chalky white creatine powder, look at what 5 g looks like and ask yourself, how many gummies would I need to put this into such that they would be palatable?
- Then the question is, do I really want that many gummy bears?
  - What am I doing to my teeth?
  - How much sugar do I need to eat, that’s totally unnecessary?
- If Peter is going to have sugar, let it be good
  - Give him a nice piece of chocolate
  - Give him a piece of carrot cake
  - He’s not going to squander his sugar calories on gummy bears that are not even giving him creatine

***Don’t eat the gummy, you need the powder***

- There are also capsules, but you’re going to have to take so many capsules to get 10 g or even 5 g

**The value of creatine for vegans and vegetarians is another important aspect**

- Rhonda has so many vegan friends that it has literally changed their lives
- Her phone blew up ‒ she couldn’t believe the magnitude of effect that these women were experiencing was way outsized compared to what Rhonda was getting
  - And Rhonda noticed an effect (it was unreal)

Peter asked, “*And how long had they been vegan?*”

- One of them for about 2 years and another one for decades
- Peter would be interested in the one who had been vegan for 2 years, when she all of a sudden got creatine back, he wonders if that was a short enough period of time that she was like, “*Oh my God, this is what I used to feel like just 2 years ago.*”
  - Or there’s probably too many confounding variables
- That’s a good question
- She has always restricted calories, and Rhonda doesn’t know how much protein she was eating

**What about creatine supplementation for kids?**

- Peter’s daughter is 17 and she’s training really hard
  - She runs cross country, she’s in the weight room

*Is she too young?*

- No

*Should she be taking creatine?*

- Yes, there’s [studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC7922146/) out there on kids, children younger than 17
- Peter’s boys are very active in sports
- Rhonda is giving it to her son
  - If she remembers correctly, it’s 0.1 g/ kg body weight
  - She gives her son 2.5 g
- There’s [studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC8228369/#sec3-nutrients-13-01915) that show creatine improves agility and speed
  - A lot of the studies were done on endurance, because kids are lifting weights

*Peter asks if Rhonda would recommend 5 g for his daughter*

- Yeah
- She’s tall too
- She’s almost an adult
- Rhonda would give her 10 g (if it was her daughter)
- There are some studies that have been done in college students who are taking a test and stuff, and of course you’re sleep-deprived when you’re studying for the test and the creatine improves test scores.

> “*I’m all in on the creatine.*”‒ Rhonda Patrick

Peter’s response, “*My creatine budget, literally the household creatine budget just went up by 4x.*”

- The same happened to Rhonda 6 months or so ago

**The harm that people claim is unfounded**

- It doesn’t cause kidney problems
- The problem is, people are looking at [creatinine](https://en.wikipedia.org/wiki/Creatinine)
  - And if you’re supplementing with creatine, you’ve got to tell your physician

Peter’s PSA, “*Physicians listening to this, please make this another reason to just look at* [*cystatin C*](https://en.wikipedia.org/wiki/Cystatin_C)*, please. I’m sure the test costs an extra dollar. It’s worth it. Cystatin C is a far more accurate way to measure and estimate* [*GFR*](https://en.wikipedia.org/wiki/Glomerular_filtration_rate)*, and you don’t have this problem of getting the confounded creatine levels increased*.”

## Sauna: how deliberate heat exposure mimics exercise, boosts cardiovascular and brain health, and shows promise for improving mood and mental resilience [A: 1:32:15, V: 1:41:54]

- Peter wants to talk about a topic that is near and dear to both of their hearts: temperature
- He was probably the biggest sauna skeptic for many years, not because he didn’t love it
  - He’s always loved a sauna
  - He just had a hard time believing that the data were causal
  - He thought there was too much healthy user bias in the studies
- But over the last 5 years, as he’s looked closer and closer at the data, it’s very difficult for him to believe that there isn’t a positive effect in terms of at least cardiovascular disease and dementia
- He can’t comment on the effect size
  - It’s very difficult to comment on the effect size from all the epidemiology
- Those are Peter’s priors
- He is now in a place where he actually view sauna as an intervention that can help an individual reduce their risk
- Personally, Peter doesn’t worry about [cardiovascular disease [ASCVD]](https://peterattiamd.com/category/risks/heart-disease-prevention/) anymore
  - It’s so easy to manage the risk around that otherwise
- But [dementia](https://peterattiamd.com/category/risks/neurodegenerative-disease-prevention/) is a very difficult risk to manage fewer things we understand about the causal pathways to get there than we do ASCVD
- In many ways, he’s in the sauna, not just because he enjoys it, not just because it’s a wonderful social opportunity to be with your spouse (if that’s how you choose to do it), but because he’s also banking a little bit on, “*Hey, I want to get some benefit to my brain.*”

**Tell us where you are currently**

*Tell us if anything has changed in your mind, one way or the other, both in increasing confidence, decreasing confidence*

- Because Peter knows that Rhonda is one of the people who keeps up with this literature more than anybody
- Rhonda is still a huge proponent of using deliberate heat exposure to improve your health, both cardiovascular and brain
- She thinks that the physiological mechanisms are in some ways **mimicking some aspects of moderate intensity cardiovascular exercise** and that is how it is improving cardiovascular health and also an aspect of that brain health
- In terms of cardiorespiratory fitness, there’s been not only observational data, but there’s been [intervention studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC7862510/) looking at endurance
  - Getting someone on a stationary cycle and then adding the sauna on top of that and VO2 max improvements were greater in individuals that are also doing the sauna right after their training

***Anything that improves cardiovascular health is going to improve brain health***

**Other benefits of heat stress: increased expression of heat shock proteins**

- There’s another aspect of this story that dates back to the origins of one of Rhonda’s first biology experiments she did when she was actually a technician at the Salk Institute (before she went to graduate school), and that has to do with the [heat shock protein response](https://en.wikipedia.org/wiki/Heat_shock_response)
- We know that heat stress in the form of either hot baths or going into a hot sauna ‒ if you are in a 163 degree Fahrenheit sauna for 30 minutes, we know that [heat shock proteins](https://en.wikipedia.org/wiki/Heat_shock_protein) increase about 50% over baseline
  - Infrared sauna is a little different, you’d have to stand there a long time to get a real heat shock response

Peter asks, “*What would be the equivalent exposure in steam or water?*”

- In water, it’s about 104 degrees for 20 minutes, shoulders down

Peter asks, “*Presumably if you’re in a hotter dry sauna, less time is needed?*”

- Presumably, we don’t have that data

**Tell me more about the infrared (IR) sauna**

- There’s no question Peter gets asked more than, “*Hey, are all the benefits you’re talking about, which all seem to come from studies in dry sauna, are they also applicable to infrared saunas?*”
- The only data he can find is if you’re using infrared, you actually have to rely on the change in skin temperature
- Whereas in **dry sauna**, we can look at time and temperature and humidity
- So if you know the temperature of the sauna, the humidity of the sauna, and the duration that you’re in there, you know how to measure the effect size
- You can’t do that with an IR sauna

Rhonda doesn’t know about that, but most studies have compared a regular hot sauna to infrared sauna at the same amount of time

***In other words, the dose is the same, obviously the temperature difference is pretty vast***

- Depending on the study, the hot sauna could be 160 or it could be 175 or 180 and the infrared is 140 or something like that
- So there’s a lot of variation in terms of the temperature of the saunas
- There was one study, the title was something like, “Infrared Saunas Does Not Mimic Cardiovascular Effects of Exercise,” and that’s because of the dose [[Infrared sauna as exercise-mimetic?](https://pubmed.ncbi.nlm.nih.gov/34954348/)]
  - If you’re just doing 20 or 30 minutes, it’s not going to be the same
  - Your heart rate doesn’t go up as much
  - You don’t feel as hot because the temperature’s not as hot
- Now you will sweat based on a different mechanism

Rhonda explains, “*As far as my take of the literature, it’s pretty clear to me that infrared saunas, if you want it to mimic the cardiovascular exercise response, you might have to double that…. Rather than spending 20 minutes in a 175-180 degree sauna, you’re going to spend 40 minutes.*”

***In an infrared sauna, you’re giving up your time***

- Rhonda has been in infrared saunas many times, if you stay in long enough, you get that, you feel hot and you feel that heart rate going up just like you do when you’re in a hot sauna
  - It just takes a lot longer

**Rhonda and Dr. Ashley Mason collaborate on a variety of sauna studies**

- [Ashley Mason](https://osher.ucsf.edu/patient-care/patient-care-team/ashley-mason) has been on *The Drive* [episode [#341](https://peterattiamd.com/ashleymason/)] and *FoundMyFitness* [episode [#67](https://www.foundmyfitness.com/episodes/ashley-mason)]
- She’s a psychologist by training and she looks at depression
- She’s looking at depression as an endpoint in terms of these infrared saunas, and she’s [looking](https://pubmed.ncbi.nlm.nih.gov/34674592/) at core body temperature increases
  - People, their core body temperature is going up by almost 2 degrees
  - In that case, she’s got them in infrared sauna for like 85 minutes
  - They’re in there a long time, and they are getting hot
- She’s got assistants that are cooling them down on their head because it’s a head out infrared sauna (it’s basically like a bed)
- Anyways, that’s the whole other area looking at the effects on mental health

This actually stems from her mentor [Dr. Charles Raison](https://www.psychiatry.wisc.edu/staff/raison-m-d-charles-l/), who Rhonda had on the podcast many years ago [episode #]

- He did this really phenomenal [pilot study](https://pubmed.ncbi.nlm.nih.gov/27172277/) looking at hyperthermia
  - And there’s this funny chamber [the Heckel device, shown in the figure below] where it’s increasing your core body temperature, but Ashley’s not using that anymore
- She’s established the heat bed as a safe way

![](https://peterattiamd.com/wp-content/uploads/2025/10/f6-rhondapatrick3.png)

**Figure 6. Heckel hyperthermia device used in Dr. Raison’s study**. Image credit: *J*[*AMA Psychiatry* 2016 supplement 2](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2521478)

**What do you think is the role of the head being hot?**

- When Peter is in his sauna (a dry sauna), he’ll run it pretty hot (at least 190)
  - Part of it is he doesn’t want to be in there more than 20 minutes because time is tight
  - He’d rather do 190-200 degrees for 20 minutes than go longer

Peter shares, “*But I will tell you, the most discomfort is in my head.*”

- Part of that is he’s sitting on the top bench, temperature is hottest at the top
- His head is exposed to more heat than his torso just based on that difference

*Is there harm or benefit or do we know anything that’s happening from any of these other metabolic parameters?*

- Rhonda will come back to that question

**Rhonda’s point at using hyperthermia to treat major depressive disorder**

- The [pioneering study](https://pubmed.ncbi.nlm.nih.gov/27172277/) where people with major depressive disorder were exposed to this device where they’re heating up their core body temperature by about 2 degrees (a single treatment), and they had an antidepressant effect that lasted 6 months compared to a sham control
- Ashley has [done](https://pmc.ncbi.nlm.nih.gov/articles/PMC11216717/) 4-8 treatments (depending on the person) and the results were phenomenal
  - She didn’t have a sham control

Peter asks, “*How do you sham control that?*”

- In [Raison’s study](https://pubmed.ncbi.nlm.nih.gov/27172277/), he had the same device [shown above] that just got people a little bit warm enough where they were thinking they were getting the active treatment, but it was not raising their core body temperature by 2 degrees

**What got Rhonda interested in sauna back in 2008**

- She lived across the street from a YMCA
- She was going into the sauna in the morning before she would go into the lab to do her experiments
  - It was freezing in Tennessee
  - She was going every single morning and staying in a long time because it was a like, “go hard, go home” kind of thing, and she loves the heat
- It was incredible the effect it was having on her mental health and her ability to deal with stress and anxiety
  - So much that she was like, “*This is insane. What’s going on? Nothing has changed other than I’m going to the sauna every day before I go and do all my failed experiments*.”

> “*What got me into the whole sauna was actually the effect on my mental health.*”‒ Rhonda Patrick

- It’s been fun for Rhonda to go full circle and team up with Ashley on some of this research
  - And she’s amazing by the way
  - She’s got some new studies coming out in this whole field of sauna depression, Rhonda thinks just she’s opening the door

## The benefits of sauna for reducing risk of dementia, and why hotter may not be better [A: 1:41:15, V: 1:52:32]

**Back to Peter’s question about the effects of sauna on the head**

- If you think about hot tubs, jacuzzis, we’re all sitting with our head out
- When Rhonda is in a hot sauna and she’s also on the top and it’s the same deal: she wants to get out in 20 minutes
  - If she stays too long, she will get a headache
  - She knows her threshold now
  - She knows the temperature and the duration and the amount of water (all those variables)

Peter asks, “*Isn’t it amazing how much water you can drink in a sauna?*”

- He worries he’s going to get [hyponatremia](https://en.wikipedia.org/wiki/Hyponatremia)

**The interesting thing about dementia risk and heat shock proteins**

- What [heat shock proteins](https://en.wikipedia.org/wiki/Heat_shock_protein) do is they prevent proteins from misfolding and forming aggregates
- And so obviously when you’re getting into a hot sauna, you are [denaturing](https://en.wikipedia.org/wiki/Denaturation_(biochemistry)) some proteins, and so your heat shock proteins are a stress response that’s activated to help with the proper folding of those proteins that were kind of denatured somewhat from the heat that you were exposing yourself to
- It turns out the heat shock proteins stay active for a long time, and so they end up having this effect where ***you’re now just improving the folding of proteins in general, even after you’re out of the hot sauna***
- There’s a lot of animal studies that have been done
- Rhonda did a lot of studies in worms many, many years ago where you can take amyloid beta 42, inject it into a worm muscle tissue and then activate heat shock proteins, and it prevents the aggregation and it prevents the muscle paralysis that occurs in these worms
- Animal studies have been done looking at amyloid beta and heat shock proteins and Alzheimer’s disease: again, it’s having a protective effect
- Now, is that the whole story?
- No, the cardiovascular effects are also important for brain health, in Rhonda’s opinion

**⇒** [Data](https://pubmed.ncbi.nlm.nih.gov/27932366/) coming out of [Dr. Jari Laukkanen](https://www.uef.fi/en/article/jari-laukkanen-appointed-as-professor-of-internal-medicine-at-the-university-of-eastern-finland)‘s lab showing that dementia and Alzheimer’s disease risk is 66% lower in people that are using the sauna 4-7 times per week versus just 1 time a week

- Protocol used was 175 or 179 degrees for 20 minutes
- [[Episode #37](https://www.foundmyfitness.com/episodes/jari-laukkanen) of *FoundMyFitness* with Jari Laukkanen]

**Here’s where Peter’s question comes in: What about the head?**

- There was another [study](https://pubmed.ncbi.nlm.nih.gov/33088678/) out of Finland (it was not Jari’s lab, it was another professor), but this study looked at sauna use and dementia risk, and then it stratified the data based on temperature
  - And people that are using the sauna, again, they’re getting a protective effect against dementia
  - But when people were going extreme, so if they’re going above 200 degrees Fahrenheit, and on average if they’re getting to 212 (it’s not an uncommon thing), their [dementia risk was actually increased](https://www.sciencedirect.com/science/article/pii/S2211335520301790#s0025:~:text=For%20high%20sauna%20temperatures%20of%20100%C2%A0%C2%B0C%20or%20more%2C%20an%20elevated%20risk%20was%20revealed%20during%20the%20first%2020%C2%A0years%20(HR%C2%A0%3D%C2%A02.04%2C%2095%25%20CI%C2%A0%3D%C2%A01.32%E2%80%933.15)%20in%20comparison%20with%20those%20with%20a%20temperature%20under%2080%C2%A0%C2%B0C.) with that temperature where it was really hot

***Rhonda’s concern is the head at that high of a temperature***

- Peter has started wearing one of those sauna hats
  - It’s not logical why it’s helping
  - But it makes such a difference
- Peter has also dialed down the temperature a little bit
  - He used to be consistently got to at least 200, and now he uses it at 185-190
- Rhonda uses her sauna at 180

Peter replies, “*My wife is going to be very happy if we dial it down to 180. She seems more sensitive to the heat than I am.*”

- Rhonda finds she is more sensitive to the heat than her husband is as well.
  - She wonders if there’s some kind of sex thing where [women are] more sensitive to it

**Do you really think that we could even dial it to 180?**

- Absolutely, and get the same benefit (the data is showing that)
- You have to get it hermetically correct

***Rhonda hopes that people out there doing sauna at 212 are listening to this because it’s too hot***

- There’s no need for it
- There’s no evidence that you’re getting added benefit
- There’s a potential risk (downside)
- That’s just one [study](https://pubmed.ncbi.nlm.nih.gov/33088678/)

## The FoundMyFitness podcast [A: 1:45:30, V: 1:57:33]

**What year did you launch your podcast?**

- 2014
- Here we are 11 years in and Peter points out, “*You are the OG in this space. You have an incredible podcast.*”

**Are you still enjoying it? And what are you most excited about?**

- Rhonda loves doing the podcast
- She doesn’t do it every week like some people
- She likes to find the guests that she’s really interested in learning from

Rhonda shares, “*What I love the most is I’ve always learned more from the conversations I would have with my colleagues or professors than I would from reading a paper. And now I get to do that for a living where I’m just having these superstars on my podcast and I get to learn so much.*”

- She reads their papers first, but she also learns so much from the conversation and people get to benefit from it
  - It’s so rewarding
  - Rhonda adds, “*I get to scratch my own itch, and then I also get to help people*.”

**Peter wants to make sure that everybody listening understands Rhonda’s place in the podcast landscape**

- Peter has talked about one of his favorite podcasts called [*Acquired*](https://www.acquired.fm/)
  - Acquired is a podcast about companies, great companies and what makes them great
  - The hosts, Ben Gilbert and David Rosenthal, they only put out one a month on average, but the reason is the amount of work that they have to put into the preparation is insane
  - Peter has gotten to know Ben especially, and Ben is putting at least 120 hours of preparation into each podcast, and therefore you can only do one a month (and it shows)
- In many ways, Peter thinks of Rhonda as the *Acquired* podcast version in our space

> “*Just the breadth and the depth of what you’re doing is awesome, it’s such a treat and it’s always quality over quantity*.”‒ Peter Attia

- Peter adds that she wouldn’t be able to put in the quality if she were trying to bang one of these things out a week
- He’s glad to hear that she’s still loving it
- It’s hard to believe how fast time has gone
- Peter remembers [being on her podcast](https://www.foundmyfitness.com/episodes/peter-attia) in 2014
  - He was one of the first 10 guests
- Peter sort of knew what a podcast was because [Tim Ferriss](https://tim.blog/about/) had [him on](https://tim.blog/guest/peter-attia/), but he didn’t really understand what her podcast was
- Look at how much it has evolved

Rhonda feels the same about Peter’s podcast

- When she’s looking for information she knows she can trust ‒  Peter is someone she’s always been able to trust for being rigorous
- If something changes, then Peter will change and she respects that

---

## Selected Links / Related Material

**Episodes of** ***The Drive*** **with Rhonda Patrick**: [0:15, 1:06:15]

- [#02 – Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more](https://peterattiamd.com/rhondapatrick/) (July 2, 2018)
- [#252 ‒ Latest insights on Alzheimer’s disease, cancer, exercise, nutrition, and fasting | Rhonda Patrick, Ph.D.](https://peterattiamd.com/rhondapatrick2/) (May 1, 2023)

**Rhonda’s podcast**: [FoundMyFitness Episodes](https://www.foundmyfitness.com/episodes) | [0:15]

**Peter and Rhonda’s content on protein**: [4:30]

- [Protein](https://peterattiamd.com/category/nutritional-biochemistry/protein/) | Peter Attia—MD
- [Protein Intake](https://www.foundmyfitness.com/topics/protein) | FoundMyFitness

**Rhonda’s podcast with Dr. Stuart Phillips**: [#76 Stuart Phillips, PhD, on Building Muscle with Resistance Exercise and Reassessing Protein Intake](https://www.foundmyfitness.com/episodes/stuart-phillips) (June 29, 2022) | FoundMyFitness | [5:15, 51:00]

**Stuart Phillips perspective on the protein RDA**: [Perspective: Protein Requirements and Optimal Intakes in Aging: Are We Ready to Recommend More Than the Recommended Daily Allowance?](https://pubmed.ncbi.nlm.nih.gov/29635313/) | *Advances in Nutrition* (D Traylor, S Gorissen, S Phillips 2018) | [5:15]

**Isotope tracer studies on the amount of protein intake needed to prevent negative protein balance in adults**: [9:45]

- [Evidence that protein requirements have been significantly underestimated](https://pubmed.ncbi.nlm.nih.gov/19841581/) | *Current Opinion in Clinical Nutrition and Metabolic Care* (R Elango et al. 2010)
- [A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength in healthy adults](https://pubmed.ncbi.nlm.nih.gov/28698222/) | *British Journal of Sports Medicine* (R Morton et al. 2018)

**Older adults require higher protein intake to support muscle protein synthesis**: [Protein ingestion to stimulate myofibrillar protein synthesis requires greater relative protein intakes in healthy older versus younger men](https://pubmed.ncbi.nlm.nih.gov/25056502/) | *The Journals of Gerontology* (D Moore et al. 2015) | [12:15]

**Protein intake of 1.2 g/kg prevented age-related loss of lean mass (as compared to the RDA of 0.8 g/kg)**: [Perspective: Protein Requirements and Optimal Intakes in Aging: Are We Ready to Recommend More Than the Recommended Daily Allowance?](https://pubmed.ncbi.nlm.nih.gov/29635313/) | *Advances in Nutrition* (D Traylor, S Gorissen, S Phillips 2018) | [12:30]

**Women who take in 1.2g/kg protein (per day) are 30% less likely to have frailty in old age**: [13:15]

- [Higher protein intake is associated with a lower likelihood of frailty among older women, Kuopio OSTPRE-Fracture Prevention Study](https://pmc.ncbi.nlm.nih.gov/articles/PMC7098934/) | *European Journal of Nutrition* (M Isanejad et al. 2019)
- [Adequate protein intake in older adults in the context of frailty: cross-sectional results of the Nutrition and Health Survey in Taiwan 2014–2017](https://pubmed.ncbi.nlm.nih.gov/33851197/) | *American Journal of Clinical Nutrition* (S Wu et al. 2021)
- [Foods, nutrients and hip fracture risk: A prospective study of middle-aged women](https://pubmed.ncbi.nlm.nih.gov/36402009/) | *Clinical Nutrition* (J Webster, D Greenwood, J Cade 2022)

**Episode of** ***The Drive*** **with Luc van Loon**: [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) (April 22, 2024) | [14:30, 23:15]

**Luc van Loon’s study of muscle protein synthesis after immobilization of one leg in a cast**: [One Week of Single-Leg Immobilization Lowers Muscle Connective Protein Synthesis Rates in Healthy, Young Adults](https://pubmed.ncbi.nlm.nih.gov/37994085/) | *Medicine and Science in Sports and Exercise* (A Holwerda et al. 2024) | [14:30]

**Review of the role of leucine in stimulating muscle protein synthesis**: [Research progress in the role and mechanism of Leucine in regulating animal growth and development](https://pubmed.ncbi.nlm.nih.gov/38046946/) | *Frontiers in Physiology* (S Rehman et al. 2023) | [15:45]

**Older adults have to consume twice as much protein as young adults to achieve the same level of muscle protein synthesis**: [Protein ingestion to stimulate myofibrillar protein synthesis requires greater relative protein intakes in healthy older versus younger men](https://pubmed.ncbi.nlm.nih.gov/25056502/) | *The Journals of Gerontology* (D Moore et al. 2015) | [16:30]

**Survey of resistance training in U.S. adults**: [Trends in Meeting the Physical Activity Guidelines: Muscle-Strengthening Alone and Combined With Aerobic Activity, United States, 1998-2018](https://pmc.ncbi.nlm.nih.gov/articles/PMC11000248/) | *Journal of Physical Activity and Health* (E Hyde et al. 2021) | [18:15]

**Effects of a high protein diet >3 g/kg**: [A high protein diet (3.4 g/kg/d) combined with a heavy resistance training program improves body composition in healthy trained men and women – a follow-up investigation](https://pmc.ncbi.nlm.nih.gov/articles/PMC4617900/) | *Journal of the INternational Society of Sports Nutrition* (J Antonio et al. 2015) | [26:00]

**Effect of resistance training with and without protein supplementation on strength and muscle mass**: [A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength in healthy adults](https://pubmed.ncbi.nlm.nih.gov/28698222/) | *British Journal of Sports Medicine* (R Morton et al. 2018) | [27:00]

**Effect of high protein diet on ICU patients receiving parenteral nutrition**: [Effect of acute phase protein dose on clinical outcomes in critically ill patients](https://pubmed.ncbi.nlm.nih.gov/40383260/) | *Clinical Nutrition ESPEN* (S Shiraishi et al. 2025) | [37:00]

**Studies in children comparing egg, milk, and vegan protein sources**: [Animal-source foods as a suitable complementary food for improved physical growth in 6 to 24-month-old children in low- and middle-income countries: a systematic review and meta-analysis of randomised controlled trials](https://pubmed.ncbi.nlm.nih.gov/35109944/) | *The British Journal of Nutrition* (H Asare et al. 2022) | [38:45]

**Rhonda’s with Dr. Bradley Schoenfeld**: [#78 Brad Schoenfeld, PhD: Resistance Training for Time Efficiency, Body Composition & Maximum Hypertrophy](https://www.foundmyfitness.com/episodes/brad-schoenfeld) (December 6, 2022) | FoundMyFitness | [51:00]

**Exercise increases amino acid transport into skeletal muscle**: [Increased rates of muscle protein turnover and amino acid transport after resistance exercise in humans](https://pubmed.ncbi.nlm.nih.gov/7900797/) | *The American Journal of Physiology* (G Biolo et al. 1995) | [54:00]

**Valter Longo’s study of the association of mortality with animal and plant protein intake**: [Animal and plant protein intake and all-cause and cause-specific mortality: results from two prospective US cohort studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC5048552/) | *JAMA Internal Medicine* (M Song et al. 2017) | [58:00]

**Episode of** ***The Drive*** **with Eric Verdin**: [#359 ‒ How metabolic and immune system dysfunction drive the aging process, the role of NAD, promising interventions, aging clocks, and more](https://peterattiamd.com/ericverdin/) | Eric Verdin, M.D. (August 4, 2025) | [1:01:00]

**Rhonda’s podcast about creatine**: [#100 The Optimal Creatine Protocol for Strength, Brain, and Longevity | Darren Candow, PhD](https://www.foundmyfitness.com/episodes/darren-candow) (March 31, 2025) | FoundMyFitness | [1:09:00]

**Rapamycin blunts muscle protein synthesis after resistance training**: [Rapamycin administration in humans blocks the contraction-induced increase in skeletal muscle protein synthesis](https://pmc.ncbi.nlm.nih.gov/articles/PMC2678224/) | *The Journal of Physiology* (M Drummond et al. 2009) | [1:03:00]

**Review of animal data on effects of rapamycin on muscle response to exercise**: [Geroprotector drugs and exercise: friends or foes on healthy longevity?](https://pmc.ncbi.nlm.nih.gov/articles/PMC10709984/#Sec3) | *BMC Biology* (C Elliehausen et al. 2023) | [1:03:45]

**Creatine improves brain processing speed in the background of stress (reviews)**: [1:21:30]

- [The effects of creatine supplementation on cognitive function in adults: a systematic review and meta-analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC11275561/) | *Frontiers in Nutrition* (C Xu et al 2024)
- [“Heads Up” for Creatine Supplementation and its Potential Applications for Brain Health and Function](https://pmc.ncbi.nlm.nih.gov/articles/PMC10721691/) | *Sports Medicine* (D Candow et al. 2023)

**Cognitive benefits of creatine after sleep deprivation:** [Single dose creatine improves cognitive performance and induces changes in cerebral high energy phosphates during sleep deprivation](https://pubmed.ncbi.nlm.nih.gov/38418482/) | *Scientific Reports* (A Gordji-Nejad et al. 2024) | [1:22:15]

**Pilot study giving Alzheimer’s patients 20 g creatine**: [1:24:00]

- [Creatine monohydrate pilot in Alzheimer’s: Feasibility, brain creatine, and cognition](https://pubmed.ncbi.nlm.nih.gov/40395689/) | *Alzheimer’s & Dementia* (A Smith et al. 2025)
- [Eight weeks of creatine monohydrate supplementation is associated with increased muscle strength and size in Alzheimer’s disease: data from a single-arm pilot study](https://pubmed.ncbi.nlm.nih.gov/40977987/) | *Frontiers in Nutrition* (A Smith et al. 2025)

**Third party testing of creatine gummies**: [Those Creatine Gummies You Bought Online Might Not Contain Any Creatine](https://www.wired.com/story/creatine-gummies-dubious-claims/) | *Wired* (K Knibbs June 18, 2025) [1:28:00]

**Review of creatine use in children**: [Creatine Supplementation in Children and Adolescents](https://pmc.ncbi.nlm.nih.gov/articles/PMC7922146/)

 | *Nutrients* (A Jagim, C Kerksick 2021) | [1:30:30]

**Cardiovascular benefits of sauna**: [1:33:45]

- [Effects of regular sauna bathing in conjunction with exercise on cardiovascular function: a multi-arm, randomized controlled trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC9394774/) | *American Journal of Physiology Regulatory, Integrative and comparative physiology* (E Lee et al. 2022)
- [Standalone sauna vs exercise followed by sauna on cardiovascular function in non‐naïve sauna users: A comparison of acute effects](https://pmc.ncbi.nlm.nih.gov/articles/PMC8485612/) | *Health Science Reports* (E Lee et al. 2021)

**Cardiorespiratory fitness (VO****2** **max) benefits of sauna**: [Intermittent post-exercise sauna bathing improves markers of exercise capacity in hot and temperate conditions in trained middle-distance runners](https://pmc.ncbi.nlm.nih.gov/articles/PMC7862510/) | *European Journal of Applied Physiology* (N Kirby et al. 2020) | [1:34:00]

**Infrared sauna does not mimic exercise**: [Infrared sauna as exercise-mimetic? Physiological responses to infrared sauna vs exercise in healthy women: A randomized controlled crossover trial](https://pubmed.ncbi.nlm.nih.gov/34954348/) | *Complementary Therapies in Medicine* (J Hussain et al. 2022) | [1:36:45]

**Episode of** ***The Drive*** **with Ashley Mason**: [#341 – Overcoming insomnia: improving sleep hygiene and treating disordered sleep with cognitive behavioral therapy for insomnia | Ashley Mason, Ph.D.](https://peterattiamd.com/ashleymason/) (March 24, 2025) | [1:37:45]

**Rhonda’s podcast with Ashley Mason**: [#67 Dr. Ashley Mason on Sauna Use for Depression, Conquering Insomnia, and Mindfully Breaking Bad Habits](https://www.foundmyfitness.com/episodes/ashley-mason) (November 2, 2021) | [1:37:45]

**Rhonda’s podcast with Charles Raison**: [#41 Dr. Charles Raison on Depression, the Immune-Brain Interface & Whole-Body Hyperthermia](https://www.foundmyfitness.com/episodes/charles-raison) (March 19, 2018) | [1:38:30]

**Charles Raison’s pilot study using hyperthermia to treat depression**: [Whole-Body Hyperthermia for the Treatment of Major Depressive Disorder: A Randomized Clinical Trial](https://pubmed.ncbi.nlm.nih.gov/27172277/) | *JAMA Psychiatry* (C Janssen et al. 2016) | [1:38:45]

**Ashley Mason’s study combining hyperthermia with cognitive behavioral therapy to treat depression**: [Feasibility and Acceptability of an Integrated Mind-Body Intervention for Depression: Whole-Body Hyperthermia (WBH) and Cognitive Behavioral Therapy (CBT)](https://pmc.ncbi.nlm.nih.gov/articles/PMC11216717/) | *International Journal of Hyperthermia* (A Mason et al. 2025) | [1:40:00]

**Jari Laukkanen’s study finds sauna use lowers risk of dementia and AD**: [Sauna bathing is inversely associated with dementia and Alzheimer’s disease in middle-aged Finnish men](https://pubmed.ncbi.nlm.nih.gov/27932366/) | *Age and Aging* (T Laukkanen et al. 2017) | [1:43:00]

**Study stratifying sauna use and temperature with dementia risk**: [Does sauna bathing protect against dementia?](https://pubmed.ncbi.nlm.nih.gov/33088678/) | *Preventative Medicine Reports* ( P Knekt et al. 2020) | [1:43:30]

---

## People Mentioned

- [Stuart Phillips](https://mira.mcmaster.ca/our-faculty/stuart-phillips/) (Professor in the Department of Kinesiology at McMaster where he is also a Tier 1 Canada Research Chair in Skeletal Muscle Health, Director of the Physical Activity Centre of Excellence (PACE) and the McMaster Centre for Nutrition, Exercise, and Health Research, and Lab Lead for the Exercise Metabolism Research Group; expert in the impact of nutrition and exercise on muscle) [5:15, 27:00, 51:00]
- [Peter Libby](https://physiciandirectory.brighamandwomens.org/details/1055/peter-libby-cardiovascular_medicine-boston) (Mallinckrodt Professor of Medicine at Harvard Medical School, physician scientist who specializes in cardiovascular medicine at Brigham and Women’s Hospital) [30:30]
- [David Allison](https://www.pcori.org/people/david-b-allison-phd)  (Professor, Endowed Chair, and Director of the Children’s Nutrition Research Center at Baylor College of Medicine; expert in obesity and nutrition, quantitative genetics, clinical trials, and research methodology) [36:45]
- [Bradley Schoenfeld](https://www.lehman.edu/academics/health-human-services-nursing/exercise-sciences-recreation/bradley-schoenfeld/) (Professor of Exercise Science at Lehman College where he is the Graduate Director of the Human Performance and Fitness Program, expert in sports fitness and strength and conditioning) [51:00]
- [Valter Longo](https://valterlongo.com/biography/) (Edna M. Jones Professor of Gerontology and Biological Sciences and Director of the Longevity Institute at the University of Southern California –Leonard Davis School of Gerontology; expert in mechanisms of aging) [58:00]
- [Eric Verdin](https://www.buckinstitute.org/lab/verdin-lab/) (President, CEO, and Professor at the Buck Institutes of Aging, expert in the epigenetic regulators of the aging process) [1:01:00]
- [Darren Candow](https://www.uregina.ca/kinesiology-health-studies/directory/faculty/darrencandow.html) (Professor in the areas of exercise physiology, nutrition and aging at the University of Regina, Canada where he also supervises the Aging Muscle and Bone Health Laboratory) [1:23:45]
- [Ashley Mason](https://osher.ucsf.edu/patient-care/patient-care-team/ashley-mason) (Associate Professor of Psychology, Integrative Clinical Psychologist and research faculty at the UCSF Osher Center for Integrative health where she is the director of the UCSF Sleep, Eating, Affect (SEA) Laboratory, co-director of the UCSF Center for OBesity Assessment, Study, and Treatment) [1:37:45]
- [Charles Raison](https://www.psychiatry.wisc.edu/staff/raison-m-d-charles-l/) (Professor of Psychiatry and Human Ecology at the University of Wisconsin School of Medicine and Public Health, expert in development of novel treatments for major depressive disorder) [1:38:30]
- [Jari Laukkanen](https://www.uef.fi/en/article/jari-laukkanen-appointed-as-professor-of-internal-medicine-at-the-university-of-eastern-finland) (Professor of Internal Medicine, University of Eastern Finland, expert in CVD risk factors and benefits of sauna) [1:43:00]

---

![](https://peterattiamd.com/wp-content/uploads/2025/10/rhonda-bio-image-600x600.png)

##### Rhonda Patrick, Ph.D.

Rhonda Patrick earned her BS in biochemistry/ chemistry from the University of California, San Diego. She earned her PhD in biomedical science at the University of Tennessee Health Science Center, St. Jude Children’s Research Hospital. In her graduate work she investigated the link between mitochondrial metabolism, apoptosis, and cancer. She discovered a protein critical for cell survival which has two distinct mitochondrial locations with disparate functions. Her work linked the role of this protein in inhibiting apoptosis to a previously unrecognized role in mitochondrial respiration and maintenance of mitochondrial structure. Her dissertation findings were published in the 2012 issue of [*Nature Cell Biology*](https://pmc.ncbi.nlm.nih.gov/articles/PMC3401947/).

Dr. Patrick did her postdoctoral training at Children’s Hospital Oakland Research Institute with Dr. Bruce Ames where she investigated the effects of micronutrient inadequacies on metabolism, inflammation, DNA damaging, and aging. She investigated whether supplementation can reverse such damage. Additionally, she studied the role of vitamin D in brain function, behavior, and other physiological functions.

Dr. Patrick. also spent time at the Salk Institute for Biological Sciences where she investigated the role of insulin signaling in protein misfolding, a common characteristic of neurodegenerative disease. In 2012, she co-founded [FoundMyFitness Science Podcast](https://www.foundmyfitness.com/episodes) with the goal of encouraging the public to think about health and longevity using a proactive, preventative approach. [[FoundMyFitness](https://www.foundmyfitness.com/about-dr-rhonda-patrick)]

Follow Dr. Rhonda Patrick:

Instagram – <https://instagram.com/foundmyfitness>

X – <https://x.com/foundmyfitness>

Website – <https://www.foundmyfitness.com/>

Weekly health newsletter – <https://www.foundmyfitness.com/newsletter>

You can subscribe to Rhonda’s monthly series on YouTube, Spotify, and Apple Podcasts:

YouTube: <https://www.youtube.com/foundmyfitness?sub_confirmation=1>

Spotify: <https://open.spotify.com/show/5QjpaU0o1Q2MkVZwwG3y7d>

You can download Rhonda’s free protocol guides, here:

How to Train According to the Experts – <https://howtotrainguide.com/>

The Cognitive Enhancement Blueprint – <https://bdnfprotocols.com/>

The Omega-3 Supplementation Guide – <https://fmfomega3guide.com/>