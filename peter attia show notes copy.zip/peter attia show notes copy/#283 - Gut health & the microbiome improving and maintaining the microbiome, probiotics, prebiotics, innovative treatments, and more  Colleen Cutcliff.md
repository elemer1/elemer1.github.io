# #283 ‒ Gut health & the microbiome: improving and maintaining the microbiome, probiotics, prebiotics, innovative treatments, and more | Colleen Cutcliffe, Ph.D.

**Source:** [https://peterattiamd.com/colleencutcliffe/](https://peterattiamd.com/colleencutcliffe/)

---

Colleen Cutcliffe is an expert in molecular biology and co-founder of Pendulum Therapeutics, a company working to develop treatments for a variety of diseases by targeting the microbiome. In this episode, Colleen delves into the complexity of the microbiome, how it is tested, and how it changes over time. She explores how probiotics, prebiotics, and postbiotics affect the gut and makes a compelling case that well-developed products have the potential not only to enhance gut health but also to positively influence overall metabolic well-being. Colleen emphasizes the significance of a high-fiber diet in sustaining a thriving gut microbiome, shares insights on minimizing microbiome damage during antibiotic use, provides tips for fostering and preserving a healthy gut, and much more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/colleencutcliffe/the_Drive_public.png)

Play

#283 ‒ Gut health & the microbiome: improving and maintaining the microbiome, probiotics, prebiotics, innovative treatments, and more | Colleen Cutcliffe, Ph.D.

#283 ‒ Gut health & the microbiome: improving and maintaining the microbiome, probiotics, prebiotics, innovative treatments, and more | Colleen Cutcliffe, Ph.D.

1x15s30s

0:002:32:41

## We discuss:

- Colleen’s background and current focus [4:45];
- The basics of the microbiome [7:15];
- The study of the human microbiome [15:15];
- Categories of bacteria, and the implications on health of the rapid evolution of bacteria [19:45];
- Methods for measuring and understanding the microbiome, and key indicators of microbiome health [28:30];
- The important role of fiber for promoting gut health through the production of butyrate [38:30];
- The case for manipulating gut bacteria via fecal microbiota transplant (FMT) [45:00];
- Dynamics of the microbiome: the gut-brain connection and how antibiotics, nutrition, stress, and more impact the microbiome’s diversity and function [50:15];
- Factors that influence the vaginal microbiome [55:15];
- The effect of gut microbes on obesity and challenges with fecal transplants in people [58:45];
- Beneficial strains of gut bacteria and strains commonly found in probiotics [1:01:15];
- The difference between a probiotic and a prebiotic, and how CFUs are a measure of the “active ingredient” [1:09:45];
- Considerations about how probiotic strains are produced, and more on the meaning of CFU [1:14:15];
- Mitigating the effect of antibiotics on the microbiome [1:22:30];
- What do we know about the effect of artificial sweeteners on the gut microbiome? [1:30:00];
- Why Akkermansia is a keystone strain with implications for metabolic health and an individual’s response to dietary interventions [1:36:15];
- The essential steps necessary to develop a robust probiotic for optimal health support [1:45:45];
- How Akkermansia helps control blood glucose, and potential implications of Akkermansia in weight loss, diabetes management, and more [1:48:45];
- Pendulum Therapeutics’ commitment to rigorous product develop [2:06:30];
- More details about the probiotic “Glucose Control” and other probiotics developed by Pendulum Therapeutics [2:13:00];
- Further studies of Akkermansia that have been proposed or are underway [2:20:30]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Colleen Cutcliffe received her bachelor’s degree in biochemistry from Wellesley College, and Ph.D. in biochemistry and molecular biology from Johns Hopkins University
- She then completed postdoctoral training at Northwestern’s Children’s Memorial Hospital, and subsequently began working as a scientist in the pharmaceutical industry
- She is currently the CEO and co-founder of [Pendulum Therapeutics](https://pendulumlife.com/)
  - A start-up working to develop treatments for a variety of diseases by targeting the microbiome
  - Although, given that Pendulum has been around for about a decade, it seems odd to refer to them still as a start-up
- Peter wanted to have Colleen on the podcast because she was the first person he met and had deep discussions about the microbiome where he really felt like the person knew what they were talking about
  - He doesn’t say that to be disparaging about the many other people who have a lot to say about the microbiome
  - But when Peter asked questions, she had answers that made sense
- So much of the work that Peter has seen around the microbiome has been interesting, but it’s been difficult to understand how one could operationalize and make real causal effect from the science that is being presented
- Over the course of many months, Peter and Colleen had a number of discussions, and Peter became quite interested in some of the products that her company sells
- And Peter began to see some of the benefits in his own blood work ‒ something that he was incredibly skeptical of at the outset
  - They realized after their first meeting that many people had been telling him about some of these products over the past 4-5 years, and Peter had been generally dismissive without looking more deeply at the data behind them
- In this conversation, we dive into all things related to the microbiome
  - What it is and how it changes over time
  - How you can measure it, and if that is something that is important (or lack thereof)
- We talk about probiotics versus prebiotics versus postbiotics
- We talk about how much bacteria actually make it into products
- We speak about fecal transplants and the importance of fiber as well as artificial sweeteners and antibiotics as it relates to the gut microbiome
- We then speak specifically about *Akkermansia* and Colleen’s work at Pendulum around creating products that not just focus on this bacteria, but creating substrate for it, and other tools that will enable the gut to be fed in the best possible way to improve metabolic health
- This is a really interesting discussion on many levels
- Peter wants to stress just how skeptical he has been on this topic for at least a decade
  - There is probably no area of medicine that he has been more skeptical of than this one
  - With some of the high profile failures of companies in this space, Peter has somewhat smugly felt vindicated in his skepticism
- But Peter feels like that is changing, and the work that Colleen and her team have shared with him (along with other work that has been shared by other people) have begun to make him think that there may indeed be something to this gut biome
  - Peter explains, “*It’s not that I don’t think that the gut biome matters, but the question is can we change it using tools other than our nutrition?*”
    - This is one of the most important questions that we dive into in this discussion

## Colleen’s background and current focus [4:45]

- Peter connected with Colleen six months ago
- They figured out they were both at Hopkins at the same time

**What did you do your Ph.D. in?**

- Colleen did here Ph.D. in biochemistry and molecular biology, really thinking about enzymes and pathways and how they all interact with each other
- Then she did a postdoc at Northwestern ‒ we were looking for diagnostic markers for pediatric [Wilms’ tumors](https://en.wikipedia.org/wiki/Wilms%27_tumor)
- Next she moved out to the Bay Area and worked in pharma
  - We were developing drugs for [Parkinson’s disease](https://en.wikipedia.org/wiki/Parkinson%27s_disease)
- She followed a pretty traditional path of a scientist into pharmaceutical drug development
- Then she did what everybody does in Silicon Valley, she joined a startup company
  - This was a DNA sequencing instrument company that went through rapid growth, went public
- On the other side of that, she started [Pendulum Therapeutics](https://pendulumlife.com/pages/story)
- It was really premised in the fact that things like probiotics and yogurts have been on the shelves for decades, but there actually hasn’t been a new ingredient introduced in over 50 years
  - That’s because microbiome science wasn’t a real science until DNA sequencing technology enabled us to really be able to survey the microbiome and create these metabolic maps and start to approach it like a biochemical problem and a systems biology problem
- Advances in DNA sequencing technology allowed the nascent field of the microbiome to produce real products, and that’s what Colleen has been focused on for the last 10 years

## The basics of the microbiome [7:15]

**How do we define the microbiome?**

- The microbiome is essentially all of the microbes that reside in and on us: bacteria, viruses, fungi, yeast
  - They are on our skin, they’re in our nasal passages, they’re in our lungs and they’re in our guts
- Our gut runs from mouth to anus and is outside of our body, even though people don’t always think of it that way

**What allows colonization of the gut? Is that set from birth?**

- For a long time, we all believed that the mother’s womb was an entirely sterile environment and there were no microbes there at all
- Some recent studies have started to elucidate that there are some strains, but it’s very minimal
- When we think about the gut microbiome of an adult versus somebody who’s in the womb, it’s incredibly much more diverse once you become an adult
- The primary initial seeding of the microbiome is through the delivery in the vaginal canal
  - And so we’re going to get gross for a second
  - Literally as you’re being delivered, you are consuming fecal matter that is in the vaginal canal, and that’s your first seeding of microbes
- Infants have a very small diversity of microbes that are really tied to mother’s breast milk
- As you start to eat foods and as you start to get exposure of environments, then the diversity of your microbiome starts to really grow and flourish
- Then at some point during the **aging process**, the opposite starts happening
  - You start to become less diverse in your microbiome as we age

***You start out almost like a blank slate, you get a lot more diverse, and then as we age, you start to lose that diversity and therefore some key functions in the microbiome***

**When is peak diversity, what decade of life?**

- It varies from person to person, but if you can remember a time where you could eat or drink whatever you wanted to and you didn’t have to worry about it, that would probably be the time
  - Teenagers

**You hear all of these sort of bumper sticker slogans about the gut biome, “*****It outnumbers us 10 to 1*****.” Is that true?**

- Those numbers have come into question
- They’re nice to give people a framework for the fact that you have a ton of microbes in you, and that’s the important part
- Whether they outnumber 10 to 1 or 2 to 1 is probably not that important

> “*What is important is that they [microbes] make up a huge portion of your body mass as well as functions, and so it’s an important key part of your health*.”‒ Colleen Cutcliffe

***The idea is there are many cells that are not you between your mouth and your anus as there are you***

**How do they weigh so little relative to the rest of us?**

- We are 70% water; most of your mass is water (not the cells minus the water)

*Are microbes largely anhydrous cells?*

- Colleen doesn’t know the water content of bacteria
- She thinks about it a little bit differently (she’s a biochemist): it’s more about the **biochemical functions**
  - What’s the output of each of these cells versus the output of our cells?
  - When you look at it that way, bacteria are real workhorses
- There’s definitely redundancy among bacterial cells, but each of them is having multiple functions and multiple outputs
- When you think about it at a cellular level, she would think more about what are the things being produced by the cell?
- Bacteria tend to secrete a lot of things that they’re producing, unlike the cells in our body
- So there’s a lot of function that’s associated with the microbiome that’s super important
- Peter remembers learning about [prokaryotes](https://en.wikipedia.org/wiki/Prokaryote) and [eukaryotes](https://en.wikipedia.org/wiki/Eukaryote) in his first and only biology course as a kid
  - Because he didn’t take bio again until he decided to go to med school (in 9th grade or whatever)
  - There are some fundamental differences between prokaryotes and eukaryotes

**Can you explain to people listening what the difference is between our cells and bacterial cells?**

- Every cell in our body needs the other cells and the organs and the whole system in order to be able to survive and do their job, whereas bacteria, they don’t need anybody else
- Every **bacterial cell [a prokaryote]**, every unit is its own living thing that can replicate, perform functions, lose functions, be genetically modified and all of that
  - Every cell is a living organism
  - And then they divide really, really rapidly, some of them as quickly as 10 to 15 minutes
- There’s this other component, because some bacterial strains divide so quickly and because they’re also under the pressures of evolutionary processes, they can **evolve super quickly**
- We as humans, we have a long evolutionary timeline because it comes in the form of you make a kid who makes a kid who makes a kid
- Now, imagine if that was happening every 10 minutes
  - You can evolve really, really rapidly
  - And so that’s part of the antibiotic crisis out there, which is to say that these things can be become resistant to antibiotics because of this division time

**Is it an oversimplification to say that most bacteria enjoy a complementary relationship with us as their host?**

*Clearly there are some bad bacteria, but thinking in terms of flora such as the bacteria on our skin, in our nasal passages, in our gut?*

- We’ve co-evolved with these microbes and these bacteria, and so generally speaking, when you’re co-evolving with something, there’s some mutual benefit
- Colleen cringes when people talk about “good bacteria” and “bad bacteria” (although she does it as well) ***because it’s the ecosystem and the context of these bacteria that’s actually more relevant***
  - A good bacteria can become a bad bacteria in a certain situation
  - And likewise, bad bacteria can become beneficial in a different context
- It’s important to know that they’re all part of these different pathways and what they’re doing together
- For example, [*Clostridium difficile*](https://en.wikipedia.org/wiki/Clostridioides_difficile) is something that people think is a terrible pathogen, yet almost all of us have *Clostridium difficile* in our guts
  - But at the level that it’s at and in the context of the ecosystem of our strains, it’s not having a nasty pathogenic impact
- Peter compares this to “good cholesterol” and “bad cholesterol” being meaningless terms
  - Of course cholesterol is simply cholesterol, and it’s where it ends up that can be good or bad

**While we’re on the topic of** ***Clostridium difficile*** **(which we’ll come back to in more detail), what is the prevalence of that as a function of total gut biome in a person who’s healthy and not otherwise in a pathologic state?**

- This is the convoluting part about the microbiome, which is that if you sequence and do really deep sequencing and even biochemical assays across a person’s microbiome for the purpose of **population studies**, what you find is that ***the difference between people is huge***
- The [Human Microbiome Project](https://en.wikipedia.org/wiki/Human_Microbiome_Project) [[NIH website](https://hmpdacc.org/)], in which they looked across 10,000 plus people at all ages and different demographics, really demonstrated that at the strain level, people are pretty different from person to person
- When you start to look at the functions, that’s where you start to see some redundancy

***So it’s hard to say for a particular strain; if someone gives you an actual number and they don’t give you a range, that’s probably not correct***

## The study of the human microbiome [15:15]

**What were the observations it landed at vis-a-vis various factors, both modifiable and unmodifiable, either genetic or age, and diet (being the most obvious modifiable factor), how did that impact the gut biome in these 10,000 people?**

- The Human Microbiome Project didn’t have a longitudinal component to it or a perturbation of the system and looking at before and after
- So it really was just a one-time observation looking across a population of people
- This was super early on, so we so we didn’t know anything about the microbiome
  - We barely knew how to sequence the thing
    - Should we do [16S sequencing](https://en.wikipedia.org/wiki/16S_ribosomal_RNA#PCR_and_NGS_applications), which is just a gene that all microbes have?
    - Should we do whole genome sequencing?
  - Even what sample should be taken was questioned
    - A scoop of stool, the entirety of the stool?
- There was a lot of unknowns at the time
- It was a government funded project
- Even just getting this information across 10,000 people from skin to gut to vaginal microbiome was a huge endeavor
- Coming out of that have been a ton of longitudinal studies and studies where people have done interventions

**Going back to what you said earlier, it’s not just bacteria, it’s viruses, yeast, fungi, what does the pie chart of that look like in terms of numbers? In terms of function?**

- This field is really nascent
- Colleen hesitates to even answer the question of what is the role or the significance of all these different types of microbes?
- We also don’t really know what the role of viruses are in the microbiome, but one could imagine that you have functions that are important and that you need to be healthy, and that maybe these viruses help accelerate movement of those particular genes from one bacteria to another

**Do we know anything about how our microbiome compares in complexity to that of other animals?**

- A lot of microbiome studies are done in mouse models
- Having been in pharma, Colleen feels like if you’re a mouse and you’ve got cancer, you’ve got it made
  - We have so many different cures for you
- The translation of that into humans is not that great, and the microbiome is even worse because animals eat different foods

> “*Your diet is one of the biggest things that impacts your microbiome.*”‒ Colleen Cutcliffe

- And so now you’re saying what is an animal’s microbiome?
  - How does it interact with the host?
  - What implications did it have for health?
- You’re even one more step removed

***There are a lot of strains that exist from mouse to man, but because it’s all about context, it’s not totally clear that you can really use these animal models to predict what will happen in a human***

**Has anyone looked at animals that are not living in captivity and not genetically inbred (like** [**black 6 mice**](https://en.wikipedia.org/wiki/C57BL/6)**)?**

*Do we know about the microbiome of our pet dogs or wild animals?*

*Do they more closely resemble us?*

*Or again, is it purely a function of what they are eating?*

- A function of what they’re eating is such a big driving factor
- If you look at your pet dog, it really does depend on what you’re feeding them
  - Some people feed their dogs pretty much a grain-based diet
  - Some people are cooking chicken for their dogs every night

***Looking at pets is hard because it just ends up being parsed out by what you’re feeding them***

- Just to get back to the reality of these genetically modified **mouse models**, it’s even more extreme in microbiome studies
- They literally make what Colleen calls “the bubble boy” of mice
  - They try to entirely deplete these mice of microbiomes
  - They’re taking a mouse that has no microbiome, and then they’re infusing them with a human microbiome, and asking, “*Okay, what happens now to the mouse?*”
  - These are germ-free mouse models that are really commonly used to understand the impact of a human microbiome on the health of the animal

 **Colleen’s takeaway‒** ***This is completely not what would ever happen in real life***

## Categories of bacteria, and the implications on health of the rapid evolution of bacteria [19:45]

- Peter’s vague recollection of microbiology is on line in the sand we draw to divide them is:
  - Are they [aerobic](https://en.wikipedia.org/wiki/Aerobic_organism) or [anaerobic](https://en.wikipedia.org/wiki/Anaerobic_organism)?
    - Aerobic bacteria require oxygen for respiration while anaerobic bacteria can generate ATP without oxygen
    - Then you have facultative bacteria of each where they prefer to do it one way, but they can do it the other way
  - Are they [gram positive](https://en.wikipedia.org/wiki/Gram-positive_bacteria) or [gram negative](https://en.wikipedia.org/wiki/Gram-negative_bacteria)?
    - Which is simply a staining technique

**Are there any other divisions worth talking about as we explain the types of bacteria?**

- Aerobic versus anaerobic is definitely one of the most important things
- The bacteria on your skin definitely loves oxygen
- The gut microbiome is actually a strictly anaerobic area of the distal colon, so there’s literally no oxygen
  - Those strains can’t even grow in the presence of oxygen

*One other thing might be localization*

- So your GI tract and the gut microbiome, there’s this so-called **gut lining**
  - The epithelial cells where there’s this mucin layer, that’s an important part of having a well fortified gut lining
  - There are strains that live in that mucin layer, and so that’s a different type of a strain
    - They feed off of mucin versus many of the other strains that sort of feed off of things like the foods that you eat or [prebiotics](https://en.wikipedia.org/wiki/Prebiotic_(nutrition))

**Can you tell me anything about how the bacteria change as you progress along from mouth to anus?**

- Obviously, you’re going into less and less oxygen as you go down, so presumably you don’t have pure anaerobes in the mouth, but Peter remembers from working in an ER, whenever somebody received a **bite**, you would think, “*Ah, how bad can a bite be?*”
  - We were really conditioned to remember that those are some of the **dirtiest wounds** a human can have, no less dirty than a feces-soiled wound
  - So even at the proximate end of that bacterial lining, these are really frightening bacteria.
- By the way, that’s a very long tube; the listener would have to understand how tortuous the small intestine and the colon can be
- Colleen explains that the primary thing that changes is the **anaerobic** part
- Obvious in your mouth there’s a lot of oxygen exposure
- Then when you get to the distal colon, there’s no oxygen
- All along that path from the mouth to the stomach is where you have a reasonable amount of oxygen exposure
- Once something gets through the stomach, there’s sort of this in-between the strict anaerobic and the aerobic area, and a lot of the [*Lactobacillus*](https://en.wikipedia.org/wiki/Lactobacillus) and [*Bifidobacterium*](https://en.wikipedia.org/wiki/Bifidobacterium) strains that are on the labels of [probiotics](https://en.wikipedia.org/wiki/Probiotic) out there today, they reside in that **small intestine** area

- Then you get to the recesses of the gut microbiome, which is where all the action happens
  - After your stomach has broken down foods and they make their way to the **distal colon**, that’s where an incredible amount of metabolism is happening, and there’s no oxygen
- The **mouth microbiome** is a really interesting opportunity because what’s happening in the mouth and what’s coming out the other side give you an indication of what’s happening in the middle

**A funny story about the microbiome in the mouth**

- Early when Colleen started [Pendulum](https://pendulumlife.com/pages/story), she met a guy who was really interested in hyena mouth microbiomes
  - The reason is because the hyena is one of these bizarre animals that can eat a carcass of an animal after it’s been dead for extended periods of time, a week, two weeks
    - No other animal will go near an animal that’s been dead for that amount of time because of the bacterial overload (this is just going to kill you)
- The big question is: why are they able to do that?
- It turns out, if you look at the microbiome of a hyena, they make an incredible amount of **antibiotics**
- He had this whole theory that if you could understand what antibiotics are being generated in that hyena’s mouth microbiome, it might be a new source of antibiotics for us
- He was so extreme in this belief that the hyena had such a clean mouth that in the context of doing this job (trying to get microbiomes), when he got bit by a hyena
  - He went to the emergency room and they’re getting ready to give him antibiotics, and he said, “N*o, I don’t want antibiotics. It’s going to decimate my microbiome. Furthermore, I know that because I got bit by hyena, I’m not going to get an infection. They have the cleanest mouths*.”
    - And he had to sign all these waivers, and apparently he never got an infection
- The mouth microbiome is a source of potentially bacteria, and maybe other sources of new science

**How do we classify these bacteria?**

- This goes back to back to seventh grade biology where you have the phylum, the family, the genus, the species, the strain, and so that’s the organization of them [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2023/12/f1-colleencutcliffe.png)

**Figure 1. The hierarchy of biological classification’s eight major taxonomic ranks**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Taxonomic_rank)

- What DNA sequencing has enabled us to do is to really look at [strains](https://en.wikipedia.org/wiki/Strain_(biology))
- We give names to these strains based on their genomic makeup
  - Even that part is really evolving in our understanding, as well
- For example, [methylation](https://en.wikipedia.org/wiki/DNA_methylation) is a hot topic when it comes to humans, and bacterial genomes are also methylated
  - It’s typically used for silencing certain genes
- You have this question of, “*Is it really just the genetic makeup or [are] these post modifications also changing a strain from one thing to another?*”
- Should you **define a strain** by its genomic makeup, which is the traditional way we define things, or should you define it based on what it’s doing and its actions?
  - And that last one becomes more complicated

***Colleen thinks we’re going to see the definition of a strain evolve as we learn more***

**Do you mostly operate in a world where you’re thinking of the strain, then?**

- Yeah; we operate in a world where we’re thinking about the strain and the function
- For example, as we manufacture our strains, we occasionally do **whole genome audits**, because these strains do divide and replicate (most of them basically every two hours)
  - You want to make sure that whatever genetic modifications you’re just tapping naturally don’t actually impact the function of this strain
  - We’ll do a whole genome sequencing of these batches
  - We’ll do a full panel of biochemical assays to understand are they still generating small molecules at the rate that we’d expect growth curves?
- And that’s one of the challenges to actually being in this area, is that these guys evolve really quickly
- It’s hard for Peter to wrap his head around the speed with which these things are mutating
- When he thinks of his former life in the hospital, everybody knew what [MRSA](https://en.wikipedia.org/wiki/Methicillin-resistant_Staphylococcus_aureus) was, but does this mean there is a new MRSA for a particular period of time?
  - Fortunately, it always seemed to be responsive to vancomycin, but at some point it wouldn’t be
  - There is [VRE (vancomycin resistant Enterococci)](https://en.wikipedia.org/wiki/Vancomycin-resistant_Enterococcus)

**Does that mean that within the span of a year of your life, your gut microbiome is changing, not just as a result of you changing, but because they’re evolving?**

- They’re optimizing for their environment
- Again, if you take diet as the primary thing that can modify your microbiome, it’s the primary thing that can modify your microbiome because that’s their food
  - They’re living in your gut
  - They’re waiting for you to feed them
- Peter reasons, “*The reason that MRSA and VRE are evolving is to escape the antibiotic.*”
  - Yes
  - Which is against our best interest
- But the gut biome could be evolving in our best interest because in theory, it’s evolving to its environment (which is us)
- Colleen agrees, “*Exactly. It’s evolving to survive what we’re feeding them and the environment that we’re creating for them.*”
- It’s very fluid; you can go on a trip to another country and eat the food there for a week and come back and your microbiome looks totally different in just a short period of time
  - Many of us have experienced that
  - You travel and get GI distress from foods because you’re not used to having them, and you can whole hog change your microbiome
- That’s actually what really drew Colleen to this field, because when you’re talking about human genomics and human systems, the way in which you can impact them is limited because it’s an already existing system that’s relatively immutable without some real serious external force
- You have to introduce a chemical small molecule to change a pathway that has five backups to it in your system
- But the microbiome is incredibly mutable, and we’re doing it all the time

***So when you think about the ability to change the microbiome and to have real health implications, that’s where it’s at; that’s why it’s an exciting field***

## Methods for measuring and understanding the microbiome, and key indicators of microbiome health [28:30]

- If we were interested in understanding your genes, we could approach this in a number of ways
- We could do the gold standard: a whole genome sequence
  - We could sequence every nucleotide of every single coding and non-coding gene in your body
  - 20 years ago, that would’ve cost close to a billion dollars
  - Today, that’s about a thousand dollars
  - Still not the most practical test in the world because it yields a whole bunch of information one doesn’t know what to do with
- Conversely, we could go on a fishing expedition and you could say, “*Well, I’m really worried about my risk of cancer*,” and we could do a commercial test that looks at a whole bunch of known [polymorphism SNPs](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism), and we could screen for a hundred of those things
  - It’s a much more targeted look, and we could get that information

**Walk me through the menu of options that you as a scientist would embark on to do this and then what a consumer can do**

- It’s actually quite similar when it comes to understanding the microbiome
- You can do [shotgun sequencing](https://en.wikipedia.org/wiki/Shotgun_sequencing) where you’re getting the entire genomes of all the different microbes
  - Then you need to be able to assign which genome goes to which microbe, and there’s a fair amount of redundancy
  - So you use long read paired with short read sequencing to be able to get

*Explain* [*long-read*](https://en.wikipedia.org/wiki/Third-generation_sequencing) *paired with* [*short-read sequencing*](https://en.wikipedia.org/wiki/DNA_sequencing#Next-generation_methods)

- For example, if you have a 1000 bases of DNA that you want to sequence

*How many genes and base pairs does a bacteria typically have?*

- This is a huge range of sizes
- If you’re trying to measure a certain piece of DNA, you can use short read sequencing technologies, which allow you to, with high accuracy, get these short pieces of your sequence
  - You get maybe 200 base pairs
  - You would have a few of these, and then you paste them together based on the overlapping sequences
  - And each piece is pretty accurate in terms of the sequence
- Then, you can do long read sequencing, which will allow you to get in one shot that entire 1000 base pairs, but that tends to be a slightly lower fidelity read
  - You might have some errors in there

***That’s why the best way to do it is to do both long-read and short-read sequencing***

**Bacteria can have multiple copies of the same gene**

- The reason that stitching together is problematic is because bacteria have redundant genes
  - Some bacteria might have 5 copies of a gene versus another bacteria that has 10 copies of a gene
    - As it turns out, that matters
- There is a strain that’s been studied pretty well that metabolizes [digoxin](https://en.wikipedia.org/wiki/Digoxin) (Colleen doesn’t remember the name of the strain)
  - Digoxin is a drug used to treat heart failure
  - And one of the reasons why that drug fell from being first line is because the efficacy had such a wide/ broad range across people, so it’s hard to know the right amount to prescribe to somebody
- What they found was that there’s a microbe that can metabolize digoxin, and so people who needed higher doses to have efficacy had higher amounts of this strain
- But then in another double click of that, it wasn’t just that strain, it was how many copies of this particular gene that it had
  - If it had over 5, it could metabolize digoxin
  - If it had less than 5, it couldn’t
- Peter reasoning that the bacteria must exist high in the GI tract because if it were something in your [cecum](https://en.wikipedia.org/wiki/Cecum) or beyond, presumably it wouldn’t impact this
  - It has to be somewhat in proximity to the liver to have such an impact on the bioavailability of that drug
- Colleen doesn’t remember the location of this bacteria, but she remembers this part about ***the number of genes being important as to whether it could even metabolize a thing or not***
- Peter continues, “*Normally we think a lot about the different genes in the* [*P450 system*](https://en.wikipedia.org/wiki/Cytochrome_P450) *in the liver, which is heavily responsible for how most drugs are metabolized. And that clearly explains a lot of the variability in human metabolism of drugs. I never knew about this. This is even one step beyond that, and obviously not dependent on our genome.*”
  - ***This is an example of drug metabolism that is dependent on the genome of the bacteria***
- These are mostly gut microbes, so for oral drugs, there’s some path that it takes where it’s interacting with these microbes and they’re able to metabolize various drugs

**Getting back to the sequencing question**

- The number of replicates matter
- Imaging you have these short snippets
  - Then, it’s a guessing game as to is this an actual replicate or was it only there one time?
  - And that’s why you need the long-read sequence

***The long-read sequence becomes your template to compare these short reads to, and that costs several thousand dollars per sample (even today)***

- Just imaging that, and now it’s every bacterial strain out there
- And there’s a lot of redundancy in bacterial strains
- For a large number of them, we don’t even know, “*Are these real bacteria? What do they do?*”

***There’s still a lot of uncataloged genes, and that’s a real endeavor***

**The second way to approach this is** [**qPCR**](https://en.wikipedia.org/wiki/Real-time_polymerase_chain_reaction)**-based**

- With qPCR you’re looking at a specific strain and you’re trying to understand how much of that exists
- So you might have a lot of bacterial strains in your ecosystem, but you don’t know how much they are relative to each other
  - You can get a catalog of everything that’s in there, but you don’t really know how much of each one is in there from these sequencing methodologies
    - Although there are some really interesting tools that people are starting to develop to try to get at that
- The more accurate way to get at the quantitation (or how much of this strain is actually in the microbiome) is by using quantitative PCR (qPCR)
  - You’re using [primers](https://en.wikipedia.org/wiki/Primer_(molecular_biology)) that are specific to that strain, and then you’re using PCR in a quantitative way to understand how much of it is in there compared to say, some other strain, or compared to the entirety of all the different bacteria in there?
  - ***And now you have an idea of is this constituting 1% of my microbiome, 10% of my microbiome?***
- If you’re low in specific microbes or specific functions, qPCR becomes the way that you would really look at that

**But there’s an added very important complexity that the microbiome has that the human genome doesn’t have, and that’s around rapid replication and evolution**

- As we talked about with the Human Microbiome Project, it’s not good enough to get one snapshot in time
- You really want to understand what is your baseline microbiome, and then if you ever change your diet, you travel, you go on antibiotics
  - There’s all kinds of things that can change your microbiome in very acute ways, and all of a sudden it becomes a different microbiome
  - And so this longitudinal data really matters
- Additionally, because every microbe is replicating at a different rate, the fraction in which one microbe might be in your gut today might be different tomorrow
- You need longitudinal data that gets you the quantitative piece, plus who are the players?
- Then the third part is because they’re also mutating, you need to understand, well did the functions change?

> “*If you really want to understand the microbiome, I mean, we were spending five to $6,000 per sample to understand longitudinally what’s happening, what are the different functions, how are these things changing? It’s pretty hard to do.*”‒ Colleen Cutcliffe

**What are the ideal functional assays?**

- Peter doesn’t want to lose sight of what matters when we look at our cells
- In humans, that function matters more than the genome
  - The protein is more important than the gene

*What do we look at in the gut biome? Secretory proteins?*

*How are you determining the health of the function versus just the genome?*

- We are super interested in **carbohydrate metabolism**, and so we look at the output of that as the [short-chain fatty acids](https://en.wikipedia.org/wiki/Short-chain_fatty_acid) such as butyrate, propionate, acetate
- You can take an individual strain, feed it a substrate, and depending on where in that biochemical pathway it is, its substrate might be slightly different
  - Then look at how much of those small molecules are being produced on a [gas chromatography](https://en.wikipedia.org/wiki/Gas_chromatography)
  - You’re running an enzymatic reaction
  - If you think about the bacteria as the enzyme, you’re giving a substrate and you’re basically doing your old fashioned [Michaelis–Menten curves](https://en.wikipedia.org/wiki/Michaelis%E2%80%93Menten_kinetics) where you’re giving it increasing amounts of substrate, and you’re basically looking at the enzymology of substrate going to that short-chain fatty acid
- For example, you eat a piece of bread (starch, polysaccharide), and digestion begins in the mouth
  - [Amylase](https://en.wikipedia.org/wiki/Amylase) starts to break that down
  - It continues further in the stomach
  - Peter asks, “*By the time it gets to the* [*jejunum*](https://en.wikipedia.org/wiki/Jejunum)*, it’s mostly just glucose monomers, right?*”
    - Colleen think’s that’s still being figured out ‒ what is the state of affairs when things arrive?
- It’s actually really hard to survey what’s happening in the gut microbiome because we don’t have good sampling methodologies
- The pushback with all of the technologies is the ease with which things can get **contaminated**
  - Essentially you might be able to get a sample, but then in the process of pulling that back out, it becomes contaminated with the other things that are along the track
- Peter hopes this could be done intraoperatively when you’re in there operating for something else
  - The problem is you wouldn’t be operating on somebody without bowel prep, and so you’ve completely destroyed the system
  - You’re also not operating on somebody in an anaerobic chamber, and the second bacteria get exposed to oxygen, it’s different

## The important role of fiber for promoting gut health through the production of butyrate [38:30]

**Explain how carbohydrate metabolism produces byproducts and what those byproducts are**

- When people who listen to this podcast and Peter thinks of carbohydrate metabolism, “*I don’t think of any of the things you just said.*”
  - Peter thinks  glucose, glucose-1 phosphate, glucose-6 phosphate, pyruvate, acetyl-CoA the Krebs cycle
  - He thinks of lactate as a byproduct of oxidative phosphorylation
- And Colleen is thinking of things in a different level because she’s obviously looking at a different host

*Explain the metabolism on that side of the ledger*

- When we talk about carbohydrates, we’re really talking about fiber
- And our microbiome is uniquely positioned to metabolize fibers, a wide variety of which we actually can’t even metabolize ourselves

***Fiber is one of the primary prebiotics that feeds all of your strains***

- When we think about carbohydrate metabolism from the perspective of the microbiome, it’s really thinking about these fibers

***There are primary and secondary fermenters in the microbiome that can metabolize these fibers into certain short-chain fatty acids, which then become precursors for the ultimate short-chain fatty acid, which is*** [***butyrate***](https://en.wikipedia.org/wiki/Butyric_acid#In_the_mammalian_gut)

- Butyrate is this incredibly important short-chain fatty acid that’s been studied in a wide variety of conditions

> “*One of the most important molecules it [your microbiome] makes is butyrate.*”‒ Colleen Cutcliffe

**Butyrate has a role in GI health**

- **Colon cells** are the only cells that use butyrate as their source of energy (as opposed to glucose, which is what used by every other cell)
- And so when you don’t have enough butyrate that’s been associated with things like **colon cancer** and not having good colon health
- Butyrate is also a small molecule that triggers [G protein-coupled receptors](https://en.wikipedia.org/wiki/G_protein-coupled_receptor) to then release [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) from these [L cells](https://en.wikipedia.org/wiki/Enteroendocrine_cell#L_cell) in the microbiome
  - So it also plays a role in sort of this gut metabolism axis

***Butyrate becomes this really important small molecule that the gut is producing based on the foods that you’re eating, and that’s kind of where we’ve really honed in***

—

***The importance of fiber for your gut microbiome***

*If we think about the difference between soluble and insoluble fiber, are you referring mostly here to insoluble fiber?*

- - Yeah, **insoluble fiber** is most readily available in **vegetables and fruits**
  - Peter drinks this green drink every morning, and recently a patient asked him, “*Why do you drink it? Do you think it’s a substitute for having vegetables?”*

- Peter doesn’t, he said “*I think it’s a substitute for having vegetables with respect to the vitamins you get, and probably even a lot of the polyphenols, but it’s clearly not a substitute for the fiber,”*

- Practically speaking, you can look at the ingredient label, and there isn’t enough fiber in it to be a substitute

***At the end of the day, fiber is essential for gut health, which by extension means it’s essential for human health***

- You have to be eating a ton of fiber, insoluble fiber

- Colleen points out, there have been a myriad of studies showing that getting fiber from these powders can be pretty impactful for your microbiome
  - You have to get them in the volumes needed

**What are typical recommendations of fiber? Is it 1830 grams per day?**

- Colleen doesn’t know what the current standard recommended dose is, but thinks it’s between 20-30 g
  - [The [USDA RDA](https://ask.usda.gov/s/article/How-much-dietary-fiber-should-I-eat) is 14 grams of fiber per 1000 calories of food; 28 g per 2000 calories]
- She thinks the average American is consuming something like 1-2 g
  - We’re way off base on how much fiber we’re consuming

**To get back to the question, there is a delivery component to this too**

- Taking fiber where you mix in in a drink might be a lot less impactful than if you were to take it in an enteric-coated capsule that got through the stomach acid and then closer to the distal colon
  - It’s a delivery question, and you might be able to get away with a lot less
- Peter thought that given it’s insoluble fiber, it would be impervious to the gut and the environment along the way
- Colleen explains that the measurements of these things along the way has been elusive
- Peter asks, “***You eat a piece of celery,*** *which is basically all insoluble fiber. You mechanically break it into smaller pieces, but functionally it’s still cellulose that’s making its way down. At what point in the gut, does it have to wait till it’s in the colon, or does the metabolism and production of butyrate begin in the small intestine?*”
- There’s some *Bifidobacterium* in the small intestine that can help start to break that down, but the general thought is that the majority of that metabolism is happening in the **distal colon**

**Which strains of bacteria are most responsible for the metabolism of insoluble fiber in the production of butyrate as a byproduct?**

- It’s a multi-step pathway
- Many strings can do this breakdown: [*Clostridium*](https://en.wikipedia.org/wiki/Clostridium)*,* [*Bifidobacterium*](https://en.wikipedia.org/wiki/Bifidobacterium), [*Akkermansia*](https://en.wikipedia.org/wiki/Akkermansia)
  - *Akkermansia* was discovered in the early 2000s, and it also plays a really important role in generating these short chain fatty acids

*Are these strains, do they belong to the same species?*

- - [no] these are the species names
  - A strain name would have two parts to it: [*Akkermansia mucinphila*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10079265/)
    - But Colleen shortened the name of the strain to *Akkermansia*, which really does represent the species
  - So [*E. coli*](https://en.wikipedia.org/wiki/Escherichia_coli) is a strain name

- *Escherichia* plus whatever would be the species

- *Clostridium* is the species, and [*Clostridium difficile*](https://en.wikipedia.org/wiki/Clostridioides_difficile) is the strain

## The case for manipulating gut bacteria via fecal microbiota transplant (FMT) [45:00]

- [*C diff*](https://en.wikipedia.org/wiki/Clostridioides_difficile) is one of the most compelling arguments for an intervention in treating human disease by manipulating the gut bacteria

**Tell folks what** ***Clostridium difficile*** **is as a bacteria, and how does it go from being a benign/benevolent participant in our coexistence with the universe to one that could kill us?**

- [*Clostridium difficile*](https://en.wikipedia.org/wiki/Clostridioides_difficile) is a strain, and many of us have it in low levels in our gut microbiome
  - And we walk around perfectly healthy and fine with it
- When you take an **antibiotic**, that’s essentially almost like a nuclear bomb to your microbiome
  - It kills everything in there
  - But in some cases, it doesn’t kill everything
  - There are these strains of *Clostridium difficile*, that after you take an antibiotic are not killed
- The problem with killing off all the other strains is now all the competition is gone

***Imagine you have this ecosystem of different microbes, and now you’ve just gotten rid of all of them except you have this strain that has no competition and it can start to propagate unchecked***

- When you start to have these really high levels of *Clostridium difficile* in your microbiome, that’s when it starts to make you really sick, and ultimately it’s fatal
- The way in which we treat infections is through more antibiotics
- When you have this *Clostridium difficile* infection, which is a result of having taken an antibiotic, almost ironically, the cure also is another antibiotic
  - And really what you’re trying to do is to get an antibiotic that can kill that strain and get it back to its low levels until your microbiome can reconstitute itself through the food that you eat
  - The success rate of those antibiotics varies from person to person, but overall it’s something like 70% successful
  - Remember, fatality is on the other side of this (30% die)
- One of the concepts was really to go in the reverse direction and say, “*Okay, if the problem is that now there’s no competition and this guy can propagate unchecked, what if we just load up the person’s gut with all these different microbes, reestablish an ecosystem, and then that’s the way to kind of temper this thing down?*”
  - That’s called a [fecal microbiome transplant](https://en.wikipedia.org/wiki/Fecal_microbiota_transplant)
    - It’s exactly what it sounds like
    - You literally take feces from a person and transplant it into another person
    - That thing has a 99% success rate

**When was the fecal transplant first done? In the 90s?**

- It was definitely done as one-offs before people were doing real studies with it
- A ton of them were done in Australia
  - It’s one of the places where the most of these are being done
- It has an incredible success rate; it’s kind of gross

**What was it like back in the day, and how is it done today?**

- Colleen thinks people are still using the methodology of actually going up through the colon
- But people have tried to create capsules to be able to make it so that you can just consume these capsules with a drink, and then it gets there
  - And those seem to be effective
  - They’re not as effective as the enema version
    - And because probably in the process of getting that stool into a freeze dried format or into a pill format, you’re losing probably some of the diversity that you just get when you do it the old fashioned way

**What risks are associated with fecal microbiome transplants (FMT)? Are they overblown?**

- Fundamentally, it doesn’t feel like a therapeutic to give people shit
- There’s this instinct that this isn’t safe
- The reality is that the source of that person is really important
  - How do you know that that’s a so-called healthy stool donor?
  - What if they’ve got some weird pathogen that now you put it into this person who’s already in a depleted/compromised state?
- Furthermore, because everybody’s microbiomes do have these different functions, it’s possible that you might cure them of the *C diff*, and you might not have given them a new pathogen, but you might’ve changed their metabolism of foods in a way that’s not beneficial to them
- For example, there are some of these case studies of someone getting a fecal microbiome transplant, and now all of a sudden they have **obesity** issues that they never had before

***What really is at the heart of it is that we’re very early in understanding microbiome science***

- The job of the FDA is to make sure that people are safe, and so they have to decide is it more safe to give people this cure that has this incredibly high success rate when fatalities on the other side?
  - Or is it more safe to say, “*Hey, let’s keep learning more about this before we actually introduce it into clinical care*.”
  - The FDA has tried to shut the whole thing down
- Probably 20 years ago, the FDA essentially said, *“FMTs are not approved by the FDA. They’re not safe until we learn more about the science.”*
- But physicians, patients, patient’s families who had all experienced the benefit of FMT (and also people who were in the queue to get this done) went to DC and said, “*This  is crazy. This thing has such a high cure rate. How could you possibly take it away as an option for people?*”
  - So the FDA reversed their decision and let people do FMT

## Dynamics of the microbiome: the gut-brain connection and how antibiotics, nutrition, stress, and more impact the microbiome’s diversity and function [50:15]

**The example of a lean person who receives a FMT to treat** [***C diff*** **colitis**](https://en.wikipedia.org/wiki/Clostridioides_difficile_infection) **who recovers and then develops obesity**

*The hypothesis is that the gut bacteria of the obese individual is playing a causal role in their obesity*

*But first, why wouldn’t the habits of the recipient immediately override the bacteria that they got on the receiving end, given that their habits are more in line with being lean?*

*In other words, given the rapid evolution of these bacteria, why do they persist in their phenotype?*

- Colleen points out that these are case studies not clinical trials, and you’re dealing with the uncontrollable nature of humans
- One of the interesting things is that these people’s habits did *not* go back to what they used to have
- One of the things we’re learning about the microbiome is through this **gut-brain connection**, your microbiome can actually influence your food cravings
  - We actually have some data supporting that as well

***If you think about this new microbiome as maybe it’s not metabolizing food as efficiently, it gives your predilection towards obesity, but on top of that, it changes your food cravings, you’ve actually now got a double whammy against you that keeps you from being your old self***

- Colleen thinks the microbiome, this gut-brain connection, its ability to generate neurotransmitters, its ability to change cravings, it’s still at early stages of understanding, but it can basically change your behavior
  - So, you’re not really the old person you were

**Talk about the gut-brain connection**

- Peter’s vague recollection is that serotonin plays a role here
- [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) was mentioned earlier
- [GIP](https://en.wikipedia.org/wiki/Glucose-dependent_insulinotropic_polypeptide) is typically secreted higher in the gut, but that presumably plays a role as well

***This is in the early stages and we’re going to learn so much more over time, but the gut is a massive producer of a bunch of things that we’ve traditionally thought of as neurotransmitters***

- Yes, [serotonin](https://en.wikipedia.org/wiki/Serotonin), [dopamine](https://en.wikipedia.org/wiki/Dopamine), [GABA](https://en.wikipedia.org/wiki/%CE%93-Aminobutyric_acid), these GLP-1, GIPs
- And there are neurons in the gut
- There’s this relationship between the neurons in the gut and the neurons in the brain
- The neurotransmitters being generated by the gut can make their way straight to the brain through the [vagus nerve](https://en.wikipedia.org/wiki/Vagus_nerve)
- There is potentially an opportunity, for example, to tackle stress and anxiety through the gut microbiome where you have these gut microbes that can produce large amounts of GABA, which has been shown to be able to reduce stress and anxiety
- The question: is there an opportunity to go after the gut to reduce stress and anxiety?
  - Getting back to this cravings thing
  - It’s really interesting for anybody who’s ever felt stress or anxiety; you know actually your food cravings oftentimes change and kind of are hand in hand with that
- This part about the gut-brain connection that involves both cravings and these neurotransmitters is really, really fascinating

**How much of that do you think is regulated by things outside of food, meaning the gut flora as it comes to changing function, which then changes our physiologic state?**

- We’ve talked about food, and we should talk about it some more
- Colleen already talked about antibiotics

*What are other modifiable factors that change this?*

- Certainly the two biggest changes in your microbiome are the things we’ve talked about: antibiotics and nutrition
- Beyond that, what we know is that as you **age**, your microbiome starts to become depleted
  - Especially with regards to diversity and loss of function of your microbiome
- We know that when you go through periods of intense **stress**, your microbiome becomes depleted
- We know that when your [circadian rhythm](https://en.wikipedia.org/wiki/Circadian_rhythm) gets disrupted (when you travel, and day becomes night, night becomes day), that changes your microbiome

*When you say depleted, tell me what that means in a technical sense*

- What happens is that you have loss of function, so you start to become depleted in specific strains that have specific functions
- For example, this strain mentioned earlier, [*Akkermansia*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10142179/), is one of the ones that is deeply studied, and low levels of akkermansia have been associated with a really wide variety of diseases ranging from obesity, to immunological disorders, to stress and anxiety and GI issue

***Depletion basically means you’re losing certain strains and certain functions***

- And then for us women, when we go through **menopause**, there’s a massive change in the microbiome on the other side of that experience

*Peter was going to ask about the vaginal microbiome, but right now are you saying that with respect to the gut as well?*

- Yes, the gut too

## Factors that influence the vaginal microbiome [55:15]

**What are the factors that influence the vaginal microbiome besides the most obvious, which must be menopause, pregnancy, or anything that has a dramatic shift in endometrial lining and changes?**

- Presumably, if you sample a woman’s vaginal microbiome across the month of her cycle, given that her estrogen, progesterone levels are fluctuating, you’re going to see differences

*Peter assumes there’s a “healthy versus an unhealthy.” How does that manifest itself and what does one do about that?*

- Colleen is not an expert in the vaginal microbiome, but certainly [*Lactobacillus*](https://en.wikipedia.org/wiki/Lactobacillus) strains are some of the more important strains in the vaginal microbiome
  - The name of the game there is actually production of acid
  - You want an acidic environment there; it’s a protective environment
    - The goal is to keep yeast and things away
- A a healthy vaginal microbiome is really associated with the acidity level that these bacteria keep the vaginal microbiome at, and it can also be influenced by the **food that you eat**
- It’s not totally elucidated, but one of the things that gets recommended for UTI is cranberry juice
  - And you’re not inserting that into your vaginal canal
  - You’re consuming it
  - There’s definitely this connection between the food that you’re eating and then the composition of your vaginal microbiome
- **Pregnancy** is also another thing that really changes it

**Some work Colleen’s company Pendulum Therapeutics [formerly Whole Biome] did with the Mayo Clinic early on was around the idea of preterm labor**

- Preterm labor has been highly associated with [bacterial vaginosis](https://en.wikipedia.org/wiki/Bacterial_vaginosis), and it’s a broad name because we don’t fully understand what it means
  - But it’s an infection or a disruption of the vaginal microbiome that triggers preterm labor
  - One of the ideas was that if you could prevent bacteria vaginosis, you might be able to reduce the incidence of preterm labor
- And there’s another idea, which is that once you have a preemie, you’re a lot more prone to have a preemie again
  - And these women usually also have this bacterial vaginosis, which happens right before they deliver the baby
- Maybe there’s something about your vaginal microbiome that makes you more susceptible to bacterial vaginosis, which then leads to this preterm labor
- Then there’s of course the [UTIs](https://en.wikipedia.org/wiki/Urinary_tract_infection) and [yeast infections](https://en.wikipedia.org/wiki/Vaginal_yeast_infection) and things like that

**Are there other systemic complications from a negatively altered vaginal microbiome in a woman who’s entered menopause?**

- Peter reasons that the level of hormones is going to have a profound impact on the microbiome

*Do we know if any of the problems associated with menopause (beyond the obvious ones like vaginal dryness and hot flashes) have their roots in a change in that microbiome?*

- That work is still pretty early on, and Colleen would hesitate to go too far there
- She’s not an expert in menopause or these hormones, but she believes that estrogen has a modification that gets made that is a signal to the body to not put that estrogen back in a circulation (she guesses that you urinate them out)
  - And there are microbes in the gut whose job is to remove that modification
  - The effect is that it could potentially *increase* your circulating estrogen
- This is all super early stage research
- If you go try to look up studies around menopause and the microbiome, it’s extremely sparse, and so the answer is we just really don’t know
- Peter presumes that one day there could be bacterial products used to address some of these issues

## The effect of gut microbes on obesity and challenges with fecal transplants in people [58:45]

**Is the evidence in mice where you take an obese mouse and do a fecal transplant from a lean mouse to make that obese mouse lean, are those robust, reproducible findings?**

- Yeah, a lot of people have done that
- Even to take it one step further, they can make these mice obese or lean using a *human* microbiome transplant
  - They basically would take the microbiome from an obese woman, put it into a lean mouse, and see that lean mouse become obese
- We talked about the overlap between mice and men, and here is some overlap there because you can actually change the metabolism of these mice through these fecal transplants

**Why has this not taken off in humans?**

- People have done fecal microbiome transplants into people with [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)

*There are two big challenges*

- 1 – Safety: do you feel confident that that stool donor is a stool that you want to have in your body and move forward with?
- 2 – Reproducibility: a more profound challenge is the ability to reproduce the effect
  - Maybe linked to safety
  - Even if it’s always Joey who’s providing the stool
    - Joey travels; Joey goes on antibiotics; Joey changes his diet
    - You may not always be getting the same stool from that donor
  - In order to generate consistent results, in drug development, we do [dose-response curves](https://en.wikipedia.org/wiki/Dose%E2%80%93response_relationship)
    - How much of it do you need and what effect will it have?
    - ***You can’t do that if your intervention is a fecal microbiome transplant because that thing is different from person to person and even from the same person from time to time***
- Peter agrees, “*It’s a pretty messy drug.*”
- When Colleen started Pendulum, the fecal microbiome transplant data was super compelling
  - ***That tells you there’s something in that microbiome that can change your physiology***
- Colleen explains the challenge, “*How do you figure out what are the components of that microbiome that are conferring that benefit, and how do you make a reproducible manufacturing and quality process so that you know every time I deliver this pill to you, I know exactly what’s in it, and it’s the same every single time?*”
- How do you take that whole kitchen sink, the whole fecal microbiome and say, “*Actually it’s these four strains or these two strains or these fifties strains*”? (that’s the tricky part)

## Beneficial strains of gut bacteria and strains commonly found in probiotics [1:01:15]

- We’ve already talked about strain names *Lactobacillus* and *Akkermansia*
- Colleen explains, “*If you start to look at labels on the supplements that are out there, you’re going to see a lot of Lactobacillus and Bifidobacterium. Those are the two primary species that are pretty much in every product.*”
  - Those strains are relatively easy to grow, and it’s one of the reasons why they are in a lot of probiotics

**Why are they easy to grow? I thought anaerobes are hard to grow.**

- They are facultative; they can grow in some amount of oxygen
- *Akkermansia* is a strict anaerobe, so when Pendulum wanted to start manufacturing *Akkermansia* and were trying to outsource it to probiotics manufacturers, they kept sending back dead stuff
  - In order to manufacture a strict anaerobe, your entire manufacturing system (end-to-end) has to keep all oxygen out
    - A single molecule of oxygen kills the whole batch

***There’s a real manufacturing challenge to some of these next generation probiotic strains***

**Let’s talk more about the** ***Lactobacillus*** **and** ***Bifidobacterium*****: are they a bit of the shiny light problem (the keys under the shiny light)?**

- Yeah

*Are they the strains that are the most ubiquitous [in probiotics] because they’re easy to grow?*

*Or is there a really good physiologic case for their utility?*

- They’re easy to grow and so they’re prevalent
  - That’s why so much work has been done on them
- There was no microbiome science when these strains started making their way into the market in the ‘70s
  - There was just, “*What can I culture?*”
  - Nobody thought about strict anaerobes or how to keep oxygen out
    - That’s a pain and that’s expensive
- Furthermore, they got grandfathered in by the FDA as safe because they’d been on the market for so long
  - Now, if you want to bring a new strain to market, you have to go through the entire process of demonstrating all the thousands of reasons why this thing is safe

**Just to be clear, from a regulatory standpoint, if a company wants to put a new strain into a probiotic, they’re going down a grass pathway, “**[**generally regarded as safe (GRAS)**](https://en.wikipedia.org/wiki/Generally_recognized_as_safe)**” pathway, or an** [**IND**](https://en.wikipedia.org/wiki/Investigational_New_Drug)**?**

- If you want to be able to sell it directly to consumers, you have to go down the GRAS pathway

*Are there people that are actually looking at a pure pharma strategy where they’re making an IND and going down the drug pathway?*

- Absolutely, they’re all startups, pharmaceutical drug companies that are using the microbiome as the therapeutic and filing INDs and doing these studies
- In fact, this fecal microbiome transplant in the form of a pill, that’s a therapeutic
  - There are multiple companies out there that are developing that as a drug therapy
- The closest thing Peter can think of to that would be immunotherapy using [TIL](https://en.wikipedia.org/wiki/Tumor-infiltrating_lymphocytes)
  - You have immunotherapy in the form of a drug where you use something like [Keytruda](https://en.wikipedia.org/wiki/Pembrolizumab) (CTLA-4 inhibitor), where you have a single molecule that is an actual drug that triggers the immune system to do something
  - But then you have tumor-infiltrating lymphocytes (TIL), where you go and harvest a patient’s tumor, grow those T-cells out, multiply them several logs, and then re-infuse them, and then re-infuse them
    - But, of course, then every patient has their own designer drug
    - That’s still a purely regulated FDA IND problem
    - That sounds a lot more like the fecal microbiome transplant, which is every patient has a different drug
    - The difference there is it’s not coming from them

**This begs the question, should every patient going to the hospital have a banked stool sample so that they can provide their own transplant?**

- Peter points out, “*You could have an autologous transplant and save a lot of the risk.*”
- Colleen thinks that would be a super smart thing to do
  - You could bank your own stool in your freezer
    - Leave a stool sample in your fridge when you go to the hospital

**What drew your interest in this other species called** ***Akkermansia*****?**

- It was really centered around trying to understand the difference in people with metabolic syndrome versus people who don’t have metabolic syndrome
- A variety of people have done twin studies
- Twin studies are really interesting because you take a twin pair, and you’re looking for discordant twins where one twin is healthy and the other twin has diabetes or is obese
  - And you’re looking at their microbiome and you’re basically saying, “*Genetically these two people are the same. This is a nurture problem, not a nature problem*.”
  - And so you start to look at their microbiomes and you start to see patterns
- Around the world, if you compile this data together, you start to see that the twin that has obesity or type 2 diabetes has a different microbiome from the twin that’s healthy, and one of the hallmarks that appears to be true across different cultures and different dietary patterns is this *depletion* in this strain called *Akkermansia*
  - Depletion in absolute numbers

**What’s the relative difference between these populations?**

- Colleen doesn’t know but thinks that is interesting
- She points out, “*The so-called ‘healthy gut’ microbiome, which has yet to be defined. Across the world, Akkermansia comprises the microbiome on the order of somewhere between 5% to 10% or 5% to 8% for a healthy individual no matter where you’re living. And so being depleted or having nothing show up is a really stark difference.*”
  - Peter thinks this is a profound difference

**At 5-10%, does that make** ***Akkermansia*** **the most predominant species in the gut?**

- Colleen doesn’t know if there is a current tally of “winners” because there is such a difference from person to person in terms of the composition of the microbiome

**How do you explain the presence of** ***Akkermansia*** **in the gut of metabolically healthy people regardless of their diet?**

- Presumably that also means it’s independent of diet because you can point to people who are on radically different diets who are metabolically healthy
  - You can have people who are on an all-plant diet who are metabolically healthy, and presumably eating 100 grams or more of fiber a day
  - And you can have somebody on a carnivore diet who are also very metabolically healthy
  - And then, of course, everything in between

*So given the sensitivity of this flora to diet, how do we make that explanation?*

- Colleen is trying to think about any studies that have really gotten to the heart of this
- The study that you would want to do is you want to take one of these individuals, measure their microbiome, and you’d want to put them on a series of different diets and just see
  - Is this something that is not changeable, no matter what you eat or what diet you are on, this particular strain stays high?
- Peter reacts, “*In which case you would argue that the microbiome is a readout of their metabolic health, not the cause of their metabolic health*.”
- This could be, but Colleen was going to go in a slightly different direction
  - Perhaps the host themselves plays a larger role in the composition of the microbiome than we really understand
    - As you change your diet, you would expect your microbiome to change
    - But if there is something about the host that never changes, that might be the influence
    - We don’t know
- Peter thinks it’s possible that these studies haven’t been done across a broad enough dietary spectrum
  - So even though there’s geographic diversity, maybe there isn’t as much dietary diversity
- If you go and look at the Inuit, who prior to the adoption of Western food were eating a seemingly ridiculous diet, and yet we’re quite metabolically healthy
  - Not that we could go back and do this
- It makes Colleen wonder too
  - There are tribes in South America that have been relatively untainted by anything outside of where they are
  - She knows that there are definitely microbiome studies that are happening in some of those tribal groups
    - That could be the beginnings of this kind of a study

## The difference between a probiotic and a prebiotic, and how CFUs are a measure of the “active ingredient” [1:09:45]

- About the microbiome, when we talk about it’s all these bacterial and yeast strains, that’s the [probiotic](https://en.wikipedia.org/wiki/Probiotic)
  - The probiotic is the living organism itself
- [Prebiotic](https://en.wikipedia.org/wiki/Prebiotic_(nutrition)) is the food that feeds those organisms
  - We talked about fibers and inulin and polyphenols and things like that ‒ those are prebiotics

> “*Prebiotics are the food. The probiotic is the organism itself. And then what these organisms produce or what they secrete is now being called the postbiotic*.”‒ Colleen Cutcliffe

- Butyrate would be a [postbiotic](https://en.wikipedia.org/wiki/Postbiotic)
- One more term people might start seeing is **symbiotic**, and all symbiotic refers to is you’ve mixed two or more of these things together
  - The pre and the probiotic together, or the probiotic and the postbiotic
  - So a symbiotic has multiple

**When people are consuming yogurt, they’re consuming a prebiotic, presumably? (it’s the bacteria in there)**

- Yeah; they’re *Lactobacillus* bacteria that are in that yogurt that stay alive in the context of yogurt

**What is the perceived, believed, or realized efficacy of consuming massive amounts of** ***Lactobacillus*** **and** ***Bifidobacterium*****?**

- The most well-documented (and even reported from consumers) impact of consuming *Lactobacillus* and *Bifidobacterium* probiotics in general in yogurts is around **GI symptoms**
  - Things like gas and bloating and diarrhea and constipation
  - A lot of people report and there have been studies showing both sides of it

***Basically there have definitely been studies showing that people have a better GI when they’re consuming these probiotics or these yogurts with probiotics***

**If you go and buy yogurt off the shelf, how much lactobacillus is naturally within that?**

- Colleen thinks they add it in, so it varies
- It is something that naturally occurs in yogurt, but all of the things you’re buying off-the-shelf are also supplemented with additional *Lactobacillus*
- Colleen points out, “*The real question to ask yourself when you’re buying yogurt is how much sugar is in it?*”
  - Peter agrees

**What is the dose effect of a probiotic?**

*If you pick a bottle of your favorite probiotic, it uses something called CFUs (colony-forming units). Can you explain what those are?*

- Some brilliant marketer decided that [CFU (colony-forming units)](https://en.wikipedia.org/wiki/Colony-forming_unit) was going to become the metric, the name of the game for probiotics
- Remember back to seventh grade biology where you might’ve been given a Petri dish and you had to swab your mouth or swab your hand or put your finger on it, and then you see what grows?
  - That’s basically that tool

***You take your pill, yogurt, or whatever, and you basically spread it out on a Petri dish; then you count how many colonies form, and that gives you a numbe***r

- So you’ll say, “*This pill has 10 to the 9th colony-forming units in it.*”
- Some marketer decided that that’s the most important thing, is the number of colony-forming units, and I have 10 times more colony-forming units than somebody else maybe
- CFUs are interesting, but it’s less relevant than the function of what’s happening in your pill
- Moreover, it only gives you one piece of data about what’s in that pill
  - When you do that, the only thing you get to see is what’s able to form a colony
  - Colleen explains, “*Actually, in almost every supplement, every probiotic out there, the majority of what’s in that pill is dead probiotic, and you don’t see any of that when you use this technology*.”

**There’s a different tool that can be used called** [**flow cytometry**](https://en.wikipedia.org/wiki/Flow_cytometry)

- Essentially what you do is you take your capsule, you put it into this [flow cy](https://en.wikipedia.org/wiki/Flow_cytometry)t[ometer](https://en.wikipedia.org/wiki/Flow_cytometry), and its readout is live cells, dead cells, and in-between cells
- It’s based on a staining of the membrane
- It tells you which of these cells is viable, that the membrane is really intact, which of them have a compromised membrane, and which ones are somewhere in between

***And now you know exactly what’s in your pill because even if you could have the same number of live cells, it turns out that those dead cells and those in-between cells, they actually have a function***

- Those guys are the so-called **postbiotics**

> “*You don’t really know what’s in your pill unless you’re using flow cytometry versus colony-forming units*.”‒ Colleen Cutcliffe

**When you do flow cytometry, which surface receptors (or molecules) are you staining for?**

- Colleen doesn’t remember, but there are two that they stain for
  - This varies by bacteria
  - There are common ones among almost all bacteria

## Considerations about how probiotic strains are produced, and more on the meaning of CFU [1:14:15]

- Peter recaps: *Lactobacillus* is able to use oxygen and not use oxygen [it’s facultative]; so if you’re going to produce it, you would under the conditions of oxygen because it’s cheaper and easier

**Some probiotics need to be refrigerated and some don’t. What’s the specificity of that?**

- It’s really about stabilizing something that’s meant to be inside the body
- For a lot of these *Lactobacillus* and *Bifidobacterium* strains, because we’ve been manufacturing them for so long, we figured out how to get them to be stable through this process

**Take a step back and explain the process**

- You take these strains and you’re basically growing them into these big vats
  - If you’ve ever been to a brewery or a vineyard, you see these big vats, and it’s sort of the same in these manufacturing plants
- You grow these strains in a culturable media, and then when they get to a certain optical density, you then harvest them
- Centrifugation is one of the most common ways to harvest
  - You basically spin down the cells, get rid of the media, and now you have this paste of cells

*How slowly do you need to spin them to prevent them from dying?*

- *Lactobacillus* and *Bifidos* (at least the ones that are on the market today) are pretty hardy
- You can spin them awfully fast and be done with this whole process pretty quickly
- There are other strains that are a lot more sensitive, so you have to do this process much more slowly
- It depends on the strain
- But you essentially throw away the media, and you take this paste of cells, and then you [freeze-dry](https://en.wikipedia.org/wiki/Freeze_drying#) them
  - That gets them into a powder form
  - And once they’re in a powder form, they tend to be pretty stable
  - Then you could throw them in a pill

*How does freeze-drying actually work?*

- An instrument called a lyophilizer uses both pressure and temperature
  - A lot of them use flat pans that you put your paste on and slide it into the lyophilizer
  - It’s like baking
  - Then over a period of time, it’s basically using temperature and cold, the sublimation process of removing the liquid from the cells directly into a gas
- On the other side of that process, you have this powder
- And that powder may be stable at room temperature
  - It may still need to be refrigerated
- What you’re trying to figure out is, “*What are the additives that you can incorporate that help it get through this freeze drying process and remain viable?*”
- The things that have to stay refrigerated, even after that process, they’re still relatively unstable
- When we first started making *Akkermansia*, it absolutely had to be refrigerated
  - Once you freeze dry it, you shut its metabolism down completely, and then the minute it gets even a little bit warmer, it would die within hours
  - It basically warms enough to the point where it’s no longer cryogenically preserved, but there’s no substrate for and it dies
- The most important part is you do want it to be able to get through this freeze drying process, and of course, everybody wants shelf-stable product

***The most important thing is that when you ingest this strain, it actually makes its way to the gut microbiome, is able to reconstitute and to perform its functions, secrete the proteins it’s supposed to secrete, secrete the small molecules it’s supposed to secrete***

- When you do this process, every time you make a mod, you’re like, “*Oh, my gosh. We just improved the viability for X*.”
  - You have to go to the other side and say, “*Okay. Now I got to put in a human and see if I get the same output*.”
  - It’s a pretty lengthy process

**Do you think that that 90% loss is typical on the most common strains that are used commercially?**

- No
- We grow some of those strains and you can maintain higher viability, but you’re never going to get 100%
- It’s more on the order of between 50% and 80%
  - You’re definitely above the halfway mark

**How many of those make it into the person? In other words, once they’re reheated, how many of them die along the way?**

- A lot of it depends on the encapsulation that you’re using
- If you have these [enteric-coated capsules](https://en.wikipedia.org/wiki/Enteric_coating), you can make it through the stomach acid, and then you can use these [time-release capsules](https://en.wikipedia.org/wiki/Modified-release_dosage) so that it takes a certain amount of time
  - You’re making some assumptions around GI transit
- Further, Colleen explains “*Then there’s the least expensive version, which probably all falls apart in the stomach and very little of it gets to the actual destination*.”

**So it wouldn’t make sense to be drinking a probiotic in a liquid then?**

- You could get a lot more efficacy if you took it in a pill format
- We talked about these *Lactobacillus* that are in yogurts
  - Part of it is that if you just have to get just on the other side of the stomach and the small intestine, that is a different thing than trying to get all the way to the gut microbiome

**Is that where it seems that** ***Lactobacillus*** **and** ***Bifidobacterium*** **need to be seeded, just outside the stomach?**

- Colleen doesn’t know, but you can find them all along the tract and even into the distal colon

**What is their functional output? Do they make butyrate?**

- *Lactobacillus* tend to produce **lactic acid**
- Various strains of *Bifidobacterium* can produce **short-chain fatty acids**, and they need to be paired with secondary fermenters in order to get to the final butyrate

**Lactate is also a great substrate fuel for enterocytes, correct?**

- Yes, and maybe that’s why *Lactobacillus* exist all along the tract

*In that sense, is the primary function of the Lactobacillus to make food for the gut?*

- We don’t exactly know the answer to that, but there are definitely a bunch of other strains that are dependent on having the products of those *Lactobacillus* strains

**Is** ***Lactobacillus*** **also in that 5-10% prevalence?**

- Colleen is not sure

**Peter’s takeaway‒** ***Lots of companies out there are selling Lactobacillus probiotics. You should put them in the fridge, and you should hope that their manufacturing process is such that you’re getting 80% instead of 10% of what they claim.***

- Colleen agrees
- This is where I think our government could maybe have an important role: to put some guidelines and requirements around labeling
- Let’s say you think CFU is a perfectly fine metric, but there are caveats:
  - The CFU that gets put on that label could be the CFU at the time of manufacture, or it could be the CFU…
  - If I say this thing’s got a two-year shelf life stability, it could be the CFU at the two-year time mark
  - Is this company going to tell me the higher number or are they going to try to legitimately tell me what the thing is at the end of the shelf life?

**Is CFU by definition always alive?**

- Yes

**Are there any recommendations about how many CFU you need of each of those two bacteria?**

- People tend to converge around, “*You need billions.*”
- Colleen would ask the question in a slightly different way, “*What are you trying to do?*”
  - What problem are you trying to solve?
- Generally, most people should operate under, “*I just need the minimum viable product to solve my problem*.”
  - For you, that might be 10 billion [10 to the 9th]
  - For somebody else, it might be 10 to the 7th
- Unfortunately, because of marketing, a lot of people are taking things and they don’t even really know why they’re taking them
  - It gets difficult when you don’t know what the problem is that you’re trying to fix

## Mitigating the effect of antibiotics on the microbiome [1:22:30]

**Going back to antibiotics for a second**

- For most people, taking antibiotics is almost always oral
- But if you’re in the hospital, it’s not uncommon to take an intravenous antibiotic
  - For example, if you’re having surgery, it’s not uncommon right before the surgeon cuts your skin for them to administer an intravenous antibiotic, usually something that covers for skin flora and that reduces the risk of surgical wound infection

***Do intravenous antibiotics also have the same obliterating effect on the gut biome that oral ones do?***

- Colleen has not investigated that, but these *Clostridium difficile* infections often arise when people are getting antibiotics that they’re taking prior to surgeries
- Now that he thinks about it, Peter remembers that people do get [*C diff* colitis](https://en.wikipedia.org/wiki/Clostridioides_difficile_infection) from IV antibiotics

**What do we know about the ideal response to helping your gut out when you take antibiotics?**

- In the past year, Peter took two courses of [Augmentin](https://en.wikipedia.org/wiki/Amoxicillin/clavulanic_acid), which is a pretty power antibiotic
  - He had a pharyngeal abscess, and there’s no messing around with that type of infection
    - He was on steroids and Augmentin trying to avoid surgery (and luckily he did)
- He did nothing after taking antibiotics and seems to feel okay

*Is he just lucky or should he have done something?*

- We know that you have an ecosystem in your microbiome
- When you take an antibiotic, that pretty much kills everybody, and then over some amount of time, you get a new microbiome from the food that you’re eating, the environment you’re in
  - For a lot of people, that new microbiome is the same as your old microbiome
  - But for a lot of people it’s not
- One of the really interesting things are [studies](https://www.journalofinfection.com/article/S0163-4453(22)00004-4/fulltext) that have been done in kids where they show that kids who are systematically on antibiotics, later on in life are more prone to things like obesity, type 2 diabetes
  - Even things like ADHD, celiac disease
  - ***There’s something in those developing years where post-antibiotic, you’ve got a different microbiome than pre-antibiotic***
  - So that’s just something to consider on the other side of an antibiotic

> “*If ever you are going to clean up your diet, that’s a good time to do it because you’re starting with a new blank slate of your microbiome*.”‒ Colleen Cutcliffe

- What happens for a lot of people is post-antibiotic is they’re actually starting to feel better and feel well, and then they’re craving foods that maybe they haven’t been able to eat
  - And so you maybe aren’t giving yourself the best shot at a good microbiome on the other side
- Colleen used to believe that taking a probiotic during an antibiotic course seemed illogical because the antibiotic is just going to kill that probiotic
  - But there have been studies coming out showing that
  - One study that is really compelling showed that if you did a fecal microbiome transplant after taking the antibiotics (or at the tail end of that), or if you were taking probiotics during the time of taking antibiotics, that somehow on the other side of that, you had what we’ll call a “healthy gut microbiome”
    - So you’re able to have some of these functions that we’ve talked about, the development of short-chain fatty acids
    - You’ve got *Akkermansia* in there

***The idea here is that even though that antibiotic is killing these strains, you might be doing some kind of a seeding at maybe very low, undetectable levels that’s allowing you to have a healthier microbiome on the other side of the antibiotics***

**What Colleen would do if she was going on antibiotics**

- She would probably double-down on the probiotics that she’s taking
- The other side of that: really coming in hard and strong with a [high-fiber diet](https://www.ncbi.nlm.nih.gov/books/NBK559033/) would be your best chance of reconstituting with really good microbes

**Why is it that if you just take one antibiotic for your skin infection, which presumably would be like a first-generation cephalosporin, it obliterates your gut microbiome (which has nothing in common with the bacteria on your skin)?**

- Antibiotics seem very specific: when you take Augmentin, you’re targeting certain bacteria
  - And that’s why there are so many different types of antibiotics
  - It’s not just a class of drugs like [cephalosporins](https://en.wikipedia.org/wiki/Cephalosporin)
    - You have the first generation, the second generation, the third generation
- Gut bacteria are all highly anaerobic versus bacteria on the skin that are totally aerobic

*Why does the antibiotic even mess with the gut biome?*

***Antibiotics are a lot more broad-spectrum than the physicians recommending them know***

- The name of the game for the people who are manufacturing and producing antibiotics is to create a more [broad-spectrum antibiotic](https://en.wikipedia.org/wiki/Broad-spectrum_antibiotic) because you want your antibiotic to the the go-to choice from a doctor
  - You want your antibiotic to tackle the most different kinds of infection, to become the more popular antibiotic
- One of the arguments in the antibiotic world is that antibiotics over time have become more and more broad-spectrum
  - They kill more and more different things
- Whereas you really want to go in this opposite direction, which is to have a lot more precision
- There are all these [phage therapies](https://en.wikipedia.org/wiki/Phage_therapy) and things where people are trying to get really specific (that’s new)

***Most of the antibiotics out there, they decimate your microbiome. They don’t kill everything, which is why you can have these things like these C diff infections.***

**Quantitatively, how much does the gut microbiome change after a course of broad-spectrum antibiotics?**

*If you took a gram of stool from Peter now and looked at how many bacteria there were in it, and then took a gram of stool from him after he was on Augmentin for 10 days, what is the log-fold reduction in viable bacteria?*

- Colleen doesn’t know but thinks this should be published
  - [[One study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4643023/) shows a decrease in total anaerobic bacteria in feces from 10 to the 8.5 CFU/g to 10 to the 6.2 CFU/g, and *Bifidobacteria* fell from 10 to the 7.1 CFU/g to below detectable levels (10 to the 2)]

**Peter’s takeaway‒** ***the best thing you can do if you’re on an antibiotic is to “take advantage” of the fact that you’re starting with a new team and go out of your way to eat the best possible diet***

**Are there things you would be mindful of eating other than salad, vegetables, and fruits during that recolonization week? Or not eating?**

- [High-fiber foods](https://www.healthline.com/nutrition/22-high-fiber-foods#bottom-line) are important
- Adding in **fruit** is important too because those are a source of fiber and polyphenols
- We know that [polyphenols](https://en.wikipedia.org/wiki/Polyphenol) are beneficial prebiotics for the microbiome
  - Polyphenol consumption results in higher levels of *Akkermansia*
- She would *avoid* high-fat, high-sugar foods

**What is it about dietary fat or sucrose, fructose and glucose, that would be problematic?**

It’s not about the detrimental effects of them; it’s about what they don’t contain

- They don’t tend to be high in fiber

***It’s really about trying to optimize for high-fiber, high polyphenol foods***

## What do we know about the effect of artificial sweeteners on the gut microbiome? [1:30:00]

- Recently, Peter and his team put out a lengthy [newsletter](https://peterattiamd.com/sugar-substitutes/) to our premium audience, a 15,000-word treaty on all things related to non-nutritive sweeteners and non-sugar sweeteners that are themselves nutritive (a pretty broad piece)
- Without recasting the entire thing, it’s really clear that there’s something going on with these non-nutritive sweeteners beyond their caloric or non-caloric impact
- In other words, we all understand that sucrose has 4 kilocalories per gram, and it’s broken down into one part glucose, one part fructose
  - We understand the metabolism of those things, and we understand that if consumed in excess, you have probably some harm beyond just the caloric side vis-a-vis the fructose molecule and not the glucose molecule
- It’s now also clear that under isocaloric conditions, high quantities of non-nutritive sweeteners are not entirely benign

**What do we know about how the gut addresses these?**

- If for no other reason because of the fact that these are very foreign molecules in the concentrations we consume them
  - In comparison, we consume glucose and fructose for our entire existence
  - We’re just seeing it in a higher concentration now
  - But probably not as much of a multiple in concentration as we see [aspartame](https://en.wikipedia.org/wiki/Aspartame) or [sucralose](https://en.wikipedia.org/wiki/Sucralose)
- Colleen begins with the caveat, “*You are clearly a far deeper expert in all of this than I am. I haven’t spent hardly any time thinking about [this]*”
- Peter knows nothing about the impact on the gut, just the observations clinically about what we see in terms of sugar cravings and other repetitive behaviors and metabolic symptoms
  - Suggested by a very famous [paper in *Natur*](https://pubmed.ncbi.nlm.nih.gov/25231862/)*e* a few years ago

*Do you think part of that is manifested through the gut?*

- There have been a lot of studies done in mice, and we’ve already talked about the advantages and disadvantages to getting too fired up about mouse studies, especially in the microbiome
- The data that’s out there is conflicting around the impact of these non-nutritive sweeteners on the microbiome, and maybe it’s because of what Peter just pointed out:
  - These things are not all created equal
  - And so by lumping them together and doing these studies, that might be causing some of this conflict
- The research is at a relatively early stage
- A lot of studies have been done in animals
- There are definitely studies which show that they can have a detrimental effect to some of these beneficial microbes

***In Colleen’s view, the jury’s still out because we don’t understand the complexity of these different sweeteners or the complexity of a microbiome and the adaptation of the microbiome to consumption of these sweeteners***

- So yeah, evolutionarily, maybe these things haven’t been around for very long, but again, because how fast bacteria replicate (rapid evolution)
  - There are bacteria that can metabolize small molecule drugs they’ve definitely never seen before

***The name of the game is to understand how does your microbiome evolve to these, and how does it help or hurt you, and how’s that linked to a metabolic pathway?***

**Peter’s takeaway‒**

- You could take five people who have the same weight and give them the same dose of [Digoxin](https://en.wikipedia.org/wiki/Digoxin), and they’re going to have five different [PKs](https://en.wikipedia.org/wiki/Pharmacokinetics)
  - PK refers to the concentration of the drug within their body
  - In other words, a product of their metabolism
- He would say the same is probably true for aspartame, sucralose, saccharin, all of the above

**Anecdotally, Peter has seen**

- He has seen so many cases of people who are trying to lose weight, trying to improve their metabolic health, drinking 6 Diet Cokes a day
  - They’re saying, “*Look, I’m getting zero calories in here and nothing will budge*.”
  - Do me a favor, substitute soda water for the Diet Coke for a month, and let’s see if it makes a difference
    - And the world changes
- But he doesn’t know what to make of that observation because it’s anecdotal and he doesn’t have perfect control over the situation
  - It’s certainly possible that when they started drinking all the Topo Chico and started ditching the Diet Coke, that they were also doing 10 other things that changed
- He’s seen it enough in both directions where it works and where it doesn’t work
- Peter wonders if there are individual factors where in that individual for whom it becomes a productive change, there’s a lack of symbiosis between the evolution of their bacteria in the high aspartame environment versus the adaptation of another person
- Peter’s wife drinks Diet Coke; she probably has one every other day
  - He doesn’t know that that’s a high or low dose
  - She’s in great shape, healthy
- Peter can’t stand the taste of diet coke, but it doesn’t seem to cause him any ills
  - But he’s seen people where there is clearly an association between its use and otherwise

**Colleen proposes an interesting study**

- Take a bunch of individuals, get some baseline data around their microbiome, and then you would start them either on a bunch of Diet Cokes or a bunch of soda water
  - Then measure their microbiome over time
- Then do a little washout period and do a crossover and see what happens

**Colleen’s frustration with a lot of microbiome studies**

- They treat it the way that we do drug studies, which is you just have cohorts and you’re just comparing them to each other

***Really in the microbiome, the person matters, and so crossover designs are going to give you way more information about what’s doing what in that person, and then you can start to draw themes about pathways***

- But that would be an interesting design to do because it could be that at the onset, if there was something about these people who could live off of Diet Coke, that enabled them to lose weight in that way or be healthy in that way; that could be a solution
  - Let’s assume people prefer Diet Coke over unflavored soda water

## Why Akkermansia is a keystone strain with implications for metabolic health and an individual’s response to dietary interventions [1:36:15]

**A very interesting** [**study**](https://www.science.org/doi/10.1126/science.aao5774)

- They took all these people, they put them all on the same diet, and one person loses way more weight than the other person
  - And everybody has experienced this.
- They were trying to understand if there is something about the starting microbiome that changes the way people respond to diet
- They just did a regular high-fiber diet

***They found that if you start out with higher levels of Akkermansia that was associated with all the metrics of responding better to the diet in terms of BMI, hip-to-waist ratio, A1C, weight, all of these things those people did better, and it’s correlative***

- Not to keep going back to this strain, but it really is this keystone strain for a reason
- If they had higher starting amounts, they responded better to the diets

> “*I do think there’s something about the microbiome that can help you or hurt you as you go through these nutrition changes.*”‒ Colleen Cutcliffe

**If your microbiome is suboptimal**

- For example, if you are woefully deficient in *Akkermansia*, then it is harder for you to have a favorable response to a healthy intervention
  - And/or you may be more susceptible to the downside of less healthy intervention
- On the one hand, you may be *more impacted* negatively by something like non-nutritive sweeteners and you may be *less responsive* to dietary corrections

*Would you agree with that statement?*

- Yeah, that kind of hypothesis is what the data points to

**When you talk about** ***Akkermansia*****, are you always referring to the same strain?**

- Most of the work has been done on a particular strain called [*Akkermansia mucinphila*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10079265/)
  - There are other *Akkermansias* out there, but when people say *Akkermansia*, they are referring to that strain

**How is it grown?**

- You’ve already alluded to the fact that it’s a hardcore anaerobe, and if even one molecule of oxygen is brought in the presence of its culture, it’s dead
- Peter understands why an obligate anaerobe survives without oxygen, but he doesn’t remember the biochemistry of why oxygen is toxic
  - It must be a free radical thing
  - [[obligate anaerobes](https://en.wikipedia.org/wiki/Obligate_anaerobe) lack enzymes to break-down reactive oxygen species, including superoxide dismutate and catalyse; therefore the presence of superoxide and hydrogen peroxide (which always occurs with oxygen) is toxic]
- They are insanely sensitive to it
- There’s so much oxygen in the air around us, but this is really this compartmentalized body part that we have, and there are these strict anaerobes
- We talked a little bit about these microbiome therapeutic companies that are developing drugs, and almost every single one of those companies has had to develop their own manufacturing plant
  - Because all these next-generation strains that we’re talking about that are in the gut microbiome, in the distal colon, they have this same problem with oxygen
  - You have to create this end-to-end closed system

**Were there people out there trying to grow** ***Akkermansia*** **without super, super strict controls?**

- Yeah
- There’s a company that is touting pasteurized *Akkermansia* (dead *Akkermansia*) as the product that you really want
- It’s hard to not only grow the strain, but also to maintain its viability on the other side of that, as you try to create a product that people can take

**Are there many products out there that contain** ***Akkermansia*** **?**

- No
- We have a whole game of whack-a-mole happening at our company for what we’re calling “fakermansia”
  - These are people who will throw a supplement on Amazon and say, “*This is Akkermansia*”
  - You can test all of these things and most of them just have *Lactobacillus*/ *Bifidobacterium* in them
  - It’s false advertising

**Walk us through the process of producing** ***Akkermansia***

- You get rid of oxygen by pumping in a competitor, nitrogen
- It starts with a freezer master stock of the strain, so we always go back to the freezer stock because of this genetic component
  - This master stock of the strain has been very heavily characterized
  - We don’t want to just keep growing this thing and then go off of that growth and go off of that growth (profound genetic drift)

*Do you grow this in a pure nitrogen environment?*

- You’re pumping in multiple other gasses, and nitrogen is one of the primary ones
  - The mix of gasses is part of the “secret sauce” of growing the strain
- In the beginning when you just have the small stock and you’re doing the smaller cultures, you’re literally operating in an anaerobic chamber [such as one shown below]
  - So you’ve got the gloves going to this chamber
  - Then there is a physical tube that goes from that chamber into an entirely closed bag filled with media, and then you’re growing it at these larger scales

![](https://peterattiamd.com/wp-content/uploads/2023/12/f2-colleencutcliffe.png)

**Figure 2. An anaerobic chamber.**  Image credit: [Anaerobe Systems](https://anaerobesystems.com/education/anaerobic-bacteriology-course/)

- Everything is a closed, locked system, and you’re pumping in these other gasses in order to continue to keep oxygen out, because really, no matter how closed the system is, what we found is that oxygen makes its way in
- One of the most expensive parts of this process is the pumping in all these other gasses
- If you come visit our site, you’ll see we just have walls and walls lined with these tanks of these other gasses that are getting pumped in
- Then after growing the bacteria, everything through lyophilization has to remain anaerobic
- Only once it’s freeze-dried is it in a stable state
- You could leave *Akkermansia* powder out on this table for weeks and it would be fine, so it’s really just leading up to that freeze-dried state
  - In the freeze-dried state the bacteria is dormant and not metabolically active
- Freeze-dried *Akkermansia* is stable at room temperature, so you can have those pills at room temperature
  - Freezing or refrigeration is not needed

**Is body temperature what’s necessary to heat it?**

- When you consume *Akkermansia*, hydration is your big problem because it’s in a freeze-dried state
  - This is why desiccant packets are included in our bottles
    - Don’t throw out this packet because that’s what’s going to help you keep these guys stable
  - It’s all about keeping the moisture out
- You’re trying to keep it dormant
- When water enters the game, that’s what brings it back to life, and they die if oxygen is present

**What does this process take in terms of time?**

- The time varies for each of the different strains
- It also depends on the concentration and the number of bottles that you’re trying to make
- Probiotic manufacturing has been happening around the world for a very long time
- But Pendulum built their anaerobic process from scratch
  - They had Ph.D. scientists and microbiologists who were taking these small-scale methodologies and then trying to figure out, “*How do you grow them at a larger scale?*”
  - Our manufacturing plant is in San Francisco because that’s where all of our Ph.D. microbiologists were living, and we actually have a pretty young team of people
    - Some of them came straight out of their postdocs
  - It cost $410 million to make that plant

**How are you doing the** [**flow cytometry**](https://en.wikipedia.org/wiki/Flow_cytometry) **on the anaerobe without introducing oxygen?**

- The flow cytometer is in an anaerobic chamber
- Peter used to do flow cytometry every day, they’re huge
- Pendulum has custom-build anaerobic chambers for all this stuff

*How does the person go in? Are they just putting their arms in?*

- Yeah; using these gloves, you stick your arms in
- All of it is done through these gloves
  - Preparing for the [FACS](https://en.wikipedia.org/wiki/Flow_cytometry#Cell_sorting_by_flow_cytometry), mixing antibodies, rinsing
- Then there’s a little box on the side that you open it up, you put your thing in there, you close it, you have to deoxygenate it
- The double chamber is like a submarine, but people get pretty adept at using these gloves

**Aside from the fact that** ***Akkermansia*** **from an epidemiologic standpoint always shows up, how long has your company been selling an** ***Akkermansia*** **probiotic?**

- Only a couple of years
- We really spent about a decade doing dev work and R&D work and preclinical and clinical work
- Colleen wanted to make sure the thing did what we thought it was going to do

## The essential steps necessary to develop a robust probiotic for optimal health support [1:45:45]

**Are you comfortable saying how much money you spent on that R&D?**

- A lot
- Pendulum has raised $150 million, and we’ve only had products in-market for about 2-3 years
- It was a heavy lift to build a manufacturing plant, do all the R&D work, funding preclinical and clinical work
- We fund other PIs to do work with these strains
- There’s a lot of blueprints from pharmaceutical drug industry that we’ve adopted because of the incredible rigor that they have around developing products with efficacy
- Peter points out, “*And your industry is not one that’s known for rigor*”
  - Colleen agrees

**This was a really pivotal moment for our company, when we really decided to sell to consumers**

- We’d always had this idea that the microbiome is really interesting because it’s mutable and you could develop things that could help people

***There is a lot of evidence through these fecal microbiome transplants suggesting that you can actually help people improve health through a microbiome intervention, and if you followed a drug development rigorous pathway, you could actually identify the subset of that fecal microbiome transplant that could help people***

- If you could figure out how to manufacture them, you could really have a product with efficacy
- Now, how do you bring that to market and how do you choose to commercialize that?
- We always believed that because these are [GRAS](https://en.wikipedia.org/wiki/Generally_recognized_as_safe), these are naturally occurring strains, that you had an opportunity to bring this directly to the public
  - That would allow you to really democratize the availability of it
- If we launched [Pendulum Glucose Control](https://pendulumlife.com/products/pendulum-glucose-control-2-og?utm_source=search&utm_medium=google&utm_campaign=132401569592_0a0a33abe6ddb35abab93336335b48e3&utm_term=pendulum%20glucose%20control&gclid=CjwKCAiA9dGqBhAqEiwAmRpTCxhKyPb2qKwNnku4l2sHRachq_u7SLMCvlecdjYQZx-p59xN-BHdpxoCrgIQAvD_BwE) as a drug, we would only be able to sell it to doctors who would prescribe it to people who had type [2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)

> “*Anybody who’s aging should be thinking about how to help their body metabolize glucose better*.”‒ Colleen Cutcliffe

- Colleen emphasizes, “*We really felt like there was this natural product, things that could deliver efficacy that was measurable, that would be important, and then enabling these products to be available to everybody as opposed to only through a prescription*.”
- That meant that the consumer market was really the way to go
- Also, a lot of people learn information about health on their own
  - Dr. Google is the most famous doctor on earth
- We really wanted to bring it directly to consumers
- The downside of that is it’s really hard in this particular space to elevate it
  - Everybody selling a probiotic is a marketing genius
  - There are people who make you feel like what they’re selling is super innovative, and you’ve never seen anything like this before
    - But when you really look at the ingredients, it’s literally the same thing that everybody else has been selling

***Because a consumer is not going to read clinical trials or necessarily compare your ingredients to ingredients and all the other labels or do all that legwork, it becomes a really different game to play where you’re trying to deliver something that provides meaningful health solutions for people***

- You’re also having to play the marketing game of, “*How do I convince people or use proxies to help them understand this works?*”
  - Because you’re not selling to a bunch of doctors, you’re selling to regular people
- Peter thinks that even if you are selling to doctors, it’s complicated
  - It’s not like doctors would necessarily understand this
  - He struggles to understand this

## How Akkermansia helps control blood glucose, and potential implications of Akkermansia in weight loss, diabetes management, and more [1:48:45]

**Explain what** ***Akkermansia*** **does to control glucose**

- You’ve alluded to this product called [Glucose Control](https://pendulumlife.com/products/pendulum-glucose-control-2-og?utm_source=search&utm_medium=google&utm_campaign=132401569592_0a0a33abe6ddb35abab93336335b48e3&utm_term=pendulum%20glucose%20control&gclid=CjwKCAiA9dGqBhAqEiwAmRpTCxhKyPb2qKwNnku4l2sHRachq_u7SLMCvlecdjYQZx-p59xN-BHdpxoCrgIQAvD_BwE)
- There’s a clear and obvious correlation as to why *Akkermansia* is beneficial, but that doesn’t explain mechanistically what it’s doing

*Do we have an insight into why Akkermansia is something that lowers an individual’s blood glucose or response to a glucose load?*

- At a very fundamental level, this is primarily [acting] through the [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) pathway
  - Peter points out, “*If you’re hearing this, and you’ve heard of* [*Ozempic*](https://en.wikipedia.org/wiki/Semaglutide)*, you’ve heard of GLP-1. Ozempic is a mimetic of GLP-1*.”
- There are **3 key things** that we know about what *Akkermansia* does that result in this
- 1 – It has a surface protein called Amuc\_1100 that appears to be able to bind to [TLR2 receptors](https://en.wikipedia.org/wiki/Toll-like_receptor_2) that helps stimulate these [L cells](https://en.wikipedia.org/wiki/Enteroendocrine_cell#L_cell)
- Take one step back: you have these L cells at the lining of your gut microbiome, and L cells are the cells that secrete GLP-1

> “*A lot of people don’t know this. Your microbiome is really the guy secreting GLP-1.*”‒ Colleen Cutcliffe

- So you have this beautiful system where you eat food, your microbiome metabolizes it, and right there are these cells that respond to that food by secreting GLP-1
- 2 – *Akkermansia* also secretes a protein called P9, and P9 binds to these [ICAM2](https://en.wikipedia.org/wiki/ICAM2) receptors in the L cells, which are known to stimulate them to produce GLP-1
- 3 – *Akkermansia* is able to produce a short chain fatty acid called [propionate](https://en.wikipedia.org/wiki/Propionic_acid#Biology), and propionate is upstream of [butyrate](https://en.wikipedia.org/wiki/Butyric_acid#Biochemistry)
- There are a bunch of strains which can take propionate, convert it into butyrate, butyrate binds to [G protein-coupled receptors](https://en.wikipedia.org/wiki/G_protein-coupled_receptor) 42 and 44, also in these L cells, and stimulates GLP-1 secretion

***These are all ways in which Akkermansia can stimulate GLP-1 secretion, and there are only two strains shown to be able to directly stimulate GLP-1: Akkermansia mucinphila and*** [***Clostridium butyricum***](https://en.wikipedia.org/wiki/Clostridium_butyricum)

- They actually act together because *Clostridium butyricum*, as its name indicates, is a butyrate producer

**GLP-1 has multiple benefits**

- It helps your body know to secrete [insulin](https://en.wikipedia.org/wiki/Insulin) to help you metabolize the sugars that are in your blood after eating a meal
- The other benefit, which is becoming really popular now, is that it induces **satiety**: it makes you feel full
  - It does that in two ways that are not totally understood
  - 1 – It slows your GI transit, which gives you a feeling of fullness
  - 2 – It has some kind of a neurotransmitter mechanism that allows you to feel like you don’t have cravings (you’re full)
    - It makes it a very powerful small molecule
- What we’re doing that’s pretty distinct from what these small molecule drugs are doing is the **natural way**

***We’re giving you the upstream bacteria that’s enabling your body to produce GLP-1***

- The result of that is that your body will produce GLP-1
- Then, it’ll go back down, and it’ll produce it again after you’ve eaten food

***It’ll raise your levels of GLP-1 so you get these benefits of lowered blood glucose, reduced food cravings, lowered*** [***A1C***](https://en.wikipedia.org/wiki/Glycated_hemoglobin)***, and the body weight impact***

**Peter’s takeaway‒**

- Provided you have a lot of *Akkermansia* and you’re feeding it the right food, a couple of things will happen after you eat food
- One of them is related to a surface receptor on the bacteria (Amuc\_1100)
  - That surface protein by itself just stimulates L cells in the enterocyte that makes GLP-1
  - This pathway is the *least* well understood
    - More work has been done on the short-chain fatty acid and P9 protein [#2 & #3 above]
- It secretes P9, it secretes Propionate
  - Propionate gets converted to butyrate by a class of *Clostridial* strains (*Clostridium butyricum* is the most well-studied)
  - P9 directly stimulates L cells by binding the ICAM2 receptor

**Aren’t ICAM2 receptors usually involved in an inflammatory immune response?**

- Colleen has not done studies around that, but for sure that is an area of heavy interest
- Peter’s recollection from 25 years ago is that when a person is [septic](https://en.wikipedia.org/wiki/Septic_shock), you have all of these ICAM modules that lead to vasodilation, leaky capillaries, secretion of monocytes out into the peripheral tissue as macrophages
  - But it sounds like this is a distinct process here
- Colleen doesn’t know how much of this is tied to that process, but not only does *Akkermansia* stimulate these L cells to produce GLP-1, but *Akkermansia* has another role which maybe is very much tied to this, which is that it helps **regulate the mucin layer**
  - That mucin layer turns out to be super important for if it gets too thin or if it’s too thick, it’s a so-called **“leaky gut”** or GI issues that is a result of not having enough *Akkermansia* is really that you have too thin of a mucin layer
    - With a leaky gut you start to get the ability for pathogens to infiltrate and then also for these molecules to secrete out

**What is the fate of the butyrate made of the propionate?**

- It binds to these [G protein-coupled receptors](https://en.wikipedia.org/wiki/G_protein-coupled_receptor), and that’s also what stimulates the L cells to then go release GLP-1
  - Multiple of these small molecules are the signaling molecules for these receptors on the L cells

**Peter’s takeaway‒** ***All roads point to more Akkermansia, more GLP-1. What differs from someone taking Ozempic is they just have a mega high dose of GLP-1 all the time. And what you’re talking about here is a waxing and waning dose of GLP-1 that is more physiologic because it comes with your meal.***

**One would** ***not*** **expect this type of intervention to produce the amount of weight loss you would see with carpet bombing somebody with GLP-1?**

- Absolutely not
- One of the other big differences is that the GLP-1s are injected, so it is going right into the bloodstream, whereas it’s a microbiome effect where you get the waxing and waning
- This is more physiologically relevant, but it’s not going to be the same as just hammering a bunch of GLP-1 straight into the bloodstream all the time, all day, all night

**The impact of** ***Akkermansia*** **on blood sugar [1:55:45]**

*What was the first study that demonstrated that Akkermansia could play a role from an intervention perspective from impacting metabolism vis-a-vis blood sugar?*

- It was discovered by [Dr. Lee Kaplan](https://ghdcenter.hms.harvard.edu/KaplanLee) over at MGH
  - He’s a bariatric surgeon, and his initial interest was what’s happening to the microbiome when we do bariatric surgery
- He was one of the first people to really look at these microbes and discovered that *Akkermansia* appeared to be inversely associated with obesity
- Then started doing these in vitro studies to figure out what it is doing, back in the early 2000s
- Peter points out one remarkable observation that came from his work with the [Roux-en-Y gastric bypass](https://en.wikipedia.org/wiki/Gastric_bypass_surgery#Surgical_techniques) (which is a reorganization of the plumbing of a person’s gut):
  - If you took a person who was obese with type 2 diabetes and you do a Roux-en-Y gastric bypass on them, within days of surgery, their glycemic control improves even before they’ve lost weight
    - This is a very important point, because nobody would find it surprising if a person after a gastric bypass loses a hundred pounds and their diabetes goes away
- The question is, “*Why does their diabetes resolve in the days following surgery when the real weight loss hasn’t started?*” And there have been lots of suggestions:
  - 1 – Fasting: you’re not eating anything a day before surgery or a day or two after surgery
    - That’s a significant fast that depletes all of the glycogen in the muscle and much of the liver glycogen
  - 2 – You’re also completely changing their gut biome by re-plumbing their GI

**Say more about those data in terms of what they say as far as pre and post-surgical gut biome**

- Colleen is not an expert in these surgeries
- A lot of publications have used them to try to understand, “*What are the key gut microbes out there?*”
  - It *doesn’t* answer this question, “*Why do you see such an immediate response?*” (sometimes hours after the surgery)
    - Just thinking about the length of time it takes these different pathways to have effect, this suggests it is most likely something hormonal
    - But we don’t have the answer to that
- Peter thinks it’s hard to imaging it’s *not* something related to GLP-1

***This is the research space where Akkermansia was born out of***

- There are a bunch of animal models used to do gastric bypass surgeries
- This was some of the early [work](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3652229/) that laid the foundation for the fact that your microbiome could play a role in weight loss or weight gain
  - They would take these microbiomes before and after the surgeries, and then they would put them into these mouse models and they would show that you could change the metabolism of the mouse
- It’s been really hard in the field to take that fecal microbiome data, where there’s a glimmer of hope, and distill it down to the things that are actually doing that
  - That’s the big challenge of the field
  - We’re not there
- So when you say, “*Oh, what did they find?*” they found that the whole gemish could change things, but we don’t really know what in there is doing that
  - One hypothesis is that *Akkermansia* is doing part of that

**The easiest way to test that would be to give people** ***Akkermansia*****. Who did you do that in collaboration with?**

- The [clinical trial](https://drc.bmj.com/content/8/1/e001319) published in BMJ was the most rigorous trial we’ve done
- That trial used *Akkermansia* in combination with 4 other strains
- The idea is that *Akkermansia* can produce propionate, but without the help of another strain, it can’t produce butyrate
- We had this idea of including primary and secondary fermenters
  - Let’s not make *Akkermansia* the only primary fermenter; let’s add some more in there
  - And really thinking about, “*What are the team members that you’d want in here that could metabolize fiber into butyrate?*”
    - Trying to optimize butyrate production
- At the time that we did this study, nobody even knew what P9 was or Amuc\_1100
  - We thought it was only playing a role in the mucin regulation
  - We didn’t even really know that it was able to stimulate GLP-1
    - We really thought it was these butyrate producers that were doing that (which are the *Clostridial* strains and also *Bifidobacterium infantis*, also a primary fermenter)
- We did a placebo-controlled, double-blinded randomized trial where we had 3 arms
- 1 – Placebo
- 2 – This full formulation of all 5 team members [bacteria, labeled WBF-011 in the paper]
- 3 – A subset [of bacteria] that did *not* include *Akkermansia* [labeled WBF-010 in the paper]
- Initially, we wanted to study people who just had type 2 diabetes, but weren’t on any medication
  - It turns out that’s almost impossible to find
- Then they decided to study people on [metformin](https://en.wikipedia.org/wiki/Metformin)
  - A lot of people are on metformin, so if your thing is going to benefit people, it ought to work on top of metformin
- Recruiting into clinical trials is hard, and it takes a long time
- We are a startup company, and we were worried we’re going to run out of money if we don’t expand this out
- So we started including people on [sulfonylureas](https://en.wikipedia.org/wiki/Sulfonylurea#Medical_uses)
- Finally, we get all the people in trials
  - It’s still a pilot trial, 76 people across these three different arms
- What we found is that compared to the placebo group, the people who were on the full 5-strain formulation over a 90-day period, their A1C went down by 0.6 [see the figure below]
  - And their blood glucose spikes went down by 34% (the entirety of the area under the curve)
  - This was measured using a pretty old school [oral glucose tolerance test](https://en.wikipedia.org/wiki/Glucose_tolerance_test)
    - They literally came into the clinic, they got their sugar, and then they had blood drawn every 15 minutes for two hours
  - The reason we did that, rather than a [CGM](https://en.wikipedia.org/wiki/Continuous_glucose_monitor), was because we wanted to use all the gold standard, traditional methodologies
    - We don’t want anybody to think that the data was weird

![](https://peterattiamd.com/wp-content/uploads/2023/12/f3-colleencutcliffe.png)

**Figure 3. Change in glucose (from supplemental figure 1A)**. Image credit: [*BMJ* 2020](https://drc.bmj.com/content/8/1/e001319#DC5)

![](https://peterattiamd.com/wp-content/uploads/2023/12/f4-colleencutcliffe.png)

**Figure 4. Change in hemoglobin A1C (from figure 1C)**. Image credit: [*BMJ* 2020](https://drc.bmj.com/content/8/1/e001319#DC5)

- Peter reacts to the 0.6% drop in hemoglobin A1C, “*It was a pretty big drop.*”
- Peter confirms, “*Akkermansia, plus four strains to do the conversion of propionate into butyrate?*”
  - We also have strains that do the redundant function of *Akkermansia:* they’ll do that primary fiber into the propionate, or acetate

**How did the group absent Akkermansia do?**

- They had some efficacy, but it wasn’t like the 5-strain formulation
- As Colleen’s co-founder and biostatistician would say, “*That was not statistically significant.*”
  - The data’s [published](https://drc.bmj.com/content/8/1/e001319), so anybody can go look at it
- It looked like it was in between the placebo and the 5-strain formulation
- Peter adds, “B*ut it could have been very underpowered, and that’s why you didn’t see a difference*.”
  - Colleen agrees

**Thinking about this, not as a scientist, but as an entrepreneur. This was a do-or-die moment.**

- There’s going to be a binary outcome here
- Either we were going to be a company on the other side of this, or we were probably going to close up shop, because it was all in on this trial
- The company was founded in 2012, and the trial began about 2018 [published in 2020]
- All the stuff leading up to this was: we had to identify the strains
  - We had to figure out how to manufacture them
  - 6 years of basic science
- It’s very rare that your first clinical trial out of the gate, works
  - This is why we tested the 3-strain and the 5-strain [groups 2 and 3 mentioned earlier]

**Why didn’t you just do the placebo versus the 5-strain?**

- Because *Akkermansia* was so hard to grow
- We were hoping the 3-strain would be great and we wouldn’t have to grow *Akkermansia*
  - It turns out that we needed it

*Peter wonders what the effect of Akkermansia alone would be*

- Lots of people have been doing work with *Akkermansia* solo, and Colleen bet that by itself it’s probably not as impactful as the formulation
  - When using it solo, you don’t have the assistance in converting propionate to butyrate

[**Butyrate**](https://en.wikipedia.org/wiki/Butyric_acid#) **is a stable short-chain fatty acid. Why aren’t we just all mainlining butyrate?**

- There have been a ton of preclinical and in vitro work, showing the massive benefits of butyrate across a bunch of different states, including metabolism
  - Yet, none of them is translated into humans
    - Even when we try to do these enemas, these clinical trials, they’ve never looked the way they did in the animal studies
  - The animal models blow your mind, blow you out of the water, and the human trials really don’t show that
- Colleen thinks for this particular pathway that we’re talking about here, it’s a **localization problem**
- Earlier she mentioned that butyrate is a source of energy for all these colonic cells
  - The issue is when you’re delivering butyrate, all along that track, this butyrate is being absorbed by all these different cells
  - And where you need it to get to for this pathway is to the gut lining, where the G-protein coupled receptor is sitting (you need it to bind to that G-protein coupled receptor)

**Peter’s takeaway‒** ***So it’s not that Akkermansia just makes butyrate, it’s that it delivers it to the place where it needs to be***

- Exactly; literally the physical proximity is what’s enabling this to work

**What was the average hemoglobin A1C of people at the beginning of this trial?**

- These are people with type 2 diabetes, they were between 7.5-8.2 (for all the groups)
- [Table 1 in the paper states for groups described earlier #1 (placebo) 8.9±0.3, #2 (all 5 strains) 8.8±0.3, and #3 (3 strains) 8.5±0.3]

**This study was only done for 90 days, but is there any plan to redo this and find out what happens if people stay on this treatment for a year?**

*Could you take someone with type 2 diabetes and knock 1.2% off their hemoglobin A1C? (which for many people would take them out of the diabetic range)*

- We have multiple ongoing studies, and maybe this will get back to the personal story of entrepreneurship
  - Which is that, on the heels of this study, we were like, “*Holy shit, we made something that works. Now we’ve got to figure out how to commercialize it. But before we do that, we should probably replicate the study. Or maybe we should do them in parallel.*”

## Pendulum Therapeutics’ commitment to rigorous product develop [2:06:30]

**Did you get any pushback from your investors for doing another study?**

- If you’re wearing your “scientific hat”, that’s the obvious thing to do
  - Because scientists always want to replicate things, and make sure, and add another question
- If you’re an investor, you might be like, “*Are you crazy? We just got the answer. It’s the best possible answer. Don’t ever ask another question*.”
- Peter points out, “*There’s a reason virtually no supplement companies will ever, ever, ever do a clinical trial. They don’t want to know the answer.*”
- First of all, we have been super fortunate in having investors that believe in the underlying premise of our company

> “*The underlying premise of the company is that the supplement space is riddled with tons of products that don’t really do anything, and therefore it’s very hard for anybody to own market share.*”‒ Colleen Cutcliffe

- It’s actually a highly fragmented space
- Sometimes you get a player that comes in, they take market share because they’ve done something fancy on the marketing side; but then somebody else comes in and takes their market share

***Our underlying premise was, if you could deliver something that actually helped people in measurable ways, you could take that whole market over because now you’ve created something that works***

- It’s a very big deal to make a claim with a product
- In order to know if it works, you have to study this claim around lowering A1C and blood glucose spikes

***Pendulum Therapeutics is the only one that makes this claim, nobody else does***

- The other reason our investors got behind it is first of all, they understand that we’re trying to build products that can change lives, and we have investors that have gotten behind game-changing, category-creating products in the world
  - So Apple and these sorts of companies that maybe didn’t have a predecessor to them
- Peter notes, “*That’s a very different risk tolerance than biotechnology. Biotech is the graveyard of some great investors*.”
- Colleen has learned by having products in market, and enabling people to run their own studies on themselves
- Especially in the context where nutrition and your microbiome are still pretty much a “black box” of the scientific community
- We’ve been able to garner so much data from our customers who are just sharing this stuff voluntarily with us, in order to be able to do better and better product development

***Colleen is now a believer that the clinical trial is important, because it gives you a very controlled environment to know whether there’s a “there” there, but unless you can change behavior in the real world, and have people actually experience benefit that they can come back and tell you about, you haven’t made a product that’s very interesting at all***

- The other part to this story that’s important in our strategy is that, because we had this clinical data and because a consumer may not be able to go read a paper but a doctor can
  - It’s important that we go to healthcare professionals directly, but then we also go through them to help create credibility (or knowledge) for consumers

**If you want to convince a bunch of doctors that the thing you have works, they’re going to want to see more than a pilot**

- And they’re also going to want to see it run by somebody, that’s not yourself
- We immediately launched these studies, and then Covid hit
  - And every study one by one got brought to its knees, because people with diabetes are more prone to Covid complications
  - And then you’re like, “*Well, I don’t know what this Covid is doing to the microbiome.*”
  - Then people were totally not adherent to any protocols
  - They couldn’t come into clinic
  - So one by one, we lost a lot of money on trials that we were trying to do follow-ups on
- Then Colleen’s chief medical officer said, “*All right, we have to wait until everything is cleared out before we even start another clinical trial. Because we’re not going to lose another dollar.*”
- Literally, just in this last year, 2023 is when we felt like there was enough of a handle on this that we could actually start doing clinical trials
- But now we’ve sort of built up some momentum

**These clinical trials [in progress] are all being run by third party PIs, in academic and clinical institutions**

- We’re just giving free product to run these trials, and we’ll get that data
- Colleen thinks this is important if you want to get the medical community behind you, and she thinks that’ll be a differentiator
- That means they have to apply for their own grants to fund the study
  - They’re just having a significant part of the cost taken out of it, which is the drug
  - And the government is putting out NIH grants; there’s quite a few of them centered around microbiome interventions

**How many such trials are underway right now?**

- About a dozen, around the world
- Not all are for type 2 diabetes
- We have several studies where investigators have their own hypothesis about what these strains are doing
- For example, we talked about the gut-brain axis: we have an investigator that’s been funded by the [Milken Institute](https://milkeninstitute.org/), that is looking at the role of *Akkermansia* in bipolar disorder

**There are over 3,000 publications on** ***Akkermansia*****, mostly by academics**

- A lot of them are correlative studies
- Colleen’s clinical trial was an intervention study

***What she did is unique, in that she bridged a gap: until you can test an intervention under blinded randomized conditions, you can’t know if there’s an associative link***

- And her work has at least suggested that

## More details about the probiotic “Glucose Control” and other probiotics developed by Pendulum Therapeutics [2:13:00]

**How many products do you sell today?**

- Pendulum sells the product that was tested in that trial, it’s called [Glucose Control](https://pendulumlife.com/products/pendulum-glucose-control-2-og?utm_source=search&utm_medium=google&utm_campaign=132401569592_0a0a33abe6ddb35abab93336335b48e3&utm_term=pendulum%20glucose%20control&gclid=CjwKCAiA9dGqBhAqEiwAmRpTCxhKyPb2qKwNnku4l2sHRachq_u7SLMCvlecdjYQZx-p59xN-BHdpxoCrgIQAvD_BwE)
  - It is marketed for people with type 2 diabetes
  - It lowers A1C and blood glucose spikes
  - It is the *exact* formulation that was in that clinical trial [it contains 5 strains]

**Do you still use that same quality control metric, of actually doing flow cytometry on those products?**

- Yeah
- Peter takes Glucose Control and if he looks at that bottle, he doesn’t remember it saying anything about CFU on the back
  - It says **AFU**: active fraction unit
    - It’s in the number of cells that appeared in that active fraction
  - It’s going to look like 10 to the 8th or 10 to the 9th for most of the strains

**What other products do you sell?**

> “*Once people try it, they really stick with the product.”*‒ Colleen Cutcliffe

- When they released Glucose Control, one of the hallmarks of their business that they’re very proud of, is repeat business
- We actually got a lot of feedback from people
  - We were getting amazing reports of, “*Oh, my A1C is lowered, my blood glucose spikes have lowered.*”
  - When we launched our first version of Glucose Control, we also offered people free A1C testing every 90 days, and a nutrition coach (we had a team of registered dieticians)
    - We’re going to give you your nutrition coaching, and we’re going to give you the test that’s going to tell you if it’s working

**How did you offer that for free? You didn’t want to make money, I’m guessing.**

- We don’t offer it now
- Somebody even said, “*Oh my gosh, everyone should go buy this product right now, because these are non-scalable. So at some point they’re not going to offer these things.*”
  - Colleel laughed when she saw that, but then eventually she realized that’s true
- She thinks it’s still important for us to offer **nutrition information**
  - It just doesn’t necessarily have to come through a registered dietician, and a personalized one-on-one coaching
  - And maybe AI will help us get there faster than we would otherwise

**What other things did you hear from customers?**

*Did you see in the real world, comparable reductions in hemoglobin A1C?*

- The reports we got back were higher A1C drops, higher blood glucose drops

*Do you have a sense of how much selection bias was going into that? Were there a good number of people saying, “What the hell, it didn’t get better?”*

- No actually
- And you can see it in the return purchase rate, and Pendulum Glucose Control is $165 a month (that’s real out-of-pocket expense)

**How expensive are the top-selling probiotics?**

- A normal probiotic is $20 a month
- A premium, high-end probiotic is $49 bucks a month
- So $165 is way out there

**Peter is guessing that their margin is not that high given the manufacturing process**

- What’s even worse is Peter was teasing her about offering this test and nutrition coaching
- We’re not only losing because of those, but we were actually losing on every bottle we sold

***It was costing more than $165 a bottle to make it***

- Colleen explains, “*It was all kind of a hot mess out of the gates. But I think what we believed was that, we knew that as we scaled, a lot of those costs would go down. So just like everything else, if you’re buying 10 bottles versus 10,000 bottles, the same bottle costs you a lot less.*”

**Can you currently make a bottle for less than it costs?**

- Yes, we do make it for less than we’re pricing it
- But we also have to ship it cold, so there is that transport cost
- Peter explains that you get 3 bottles (a 3-month supply), it arrives in an ice pack, in a big box
  - Just like if you order [Repatha](https://en.wikipedia.org/wiki/Evolocumab) or something like a PCSK9-inhibitor
  - It shows up cold, and you’ve got to put it in the fridge right away
  - You can’t travel with it

**Colleen and Pendulum Therapeutics wanted to give the product the best chance of success**

- This is why they gave people the tools to help them measure
- A lot of people don’t even know what a [high-fiber diet](https://www.ncbi.nlm.nih.gov/books/NBK559033/) is supposed to look like
- We got all this great feedback
- Efficacy was higher than we’d even seen in the trial
- But we also got a lot of complaints:
  - How is this $165 a month?
  - Why isn’t my insurance covering it?
  - Why does it have to be cold?
  - I can’t travel with it
  - What am I supposed to do in the time that I’m traveling?
  - I don’t have type 2 diabetes

**A lower dose version of Glucose Control**

- We kind of took all that and decided to run some marketing tests on a lower dose version
  - That had huge uptake
- And so we launched a product this year called [Metabolic Daily](https://pendulumlife.com/products/pendulum-metabolic-daily)
  - It’s literally the same thing as Glucose Control, but just at a lower dose, and that allows us to get down to this price point of $49 a month
    - Which feels a lot more manageable for people, especially if you don’t have type 2 diabetes, but you want to help your body metabolize sugars and carbs better
  - That product still has all 5 strains in it
  - It needs to be refrigerated
    - Colleen explains, “*All of our products really should be refrigerated. That does maintain the viability for longer.*”

**We also released the single strains that are components of these products**

- We had a lot of people who came back to us and said, “*Hey, I’m buying your pendulum glucose control, but all I really want is Akkermansia. I just want that one strain*.”
- We thought, “*Who the hell knows what Akkermansia is? This is just some really educated people coming to us, and it’s not a real market*.”
- We did a market test
  - We made a thousand bottles of *Akkermansia*
- We literally just called it [*Akkermansia*](https://pendulumlife.com/products/pendulum-akkermansia), and we put on there for gut health
- We made no claims about it
- People were coming to us, wanting *Akkermansia* for a wide variety of reasons
  - From metabolism issues, to GI issues, to neurological disorders

> “*We made a thousand bottles. In less than 10 days every bottle was gone.*”‒ Colleen Cutcliffe

- *Akkermansia* is one of the hardest, most expensive products to make, but that is one of our bestsellers
  - Actually a lot of practitioners use it
    - Let’s say they ran a gut microbiome test and the person is low in *Akkermansia*
    - Then they just want to give them the minimal viable product to boost this strain back up
- Peter points out, “*We’re really on the outskirts of knowledge here. We really don’t know what it’s doing by itself…. In terms of outcomes, that’s more of a stretch, right?*”
- Colleen explains that we know it’s secreting some of these proteins
- What we’ve learned from having it in the market, is that people are getting a variety of different measurable impacts from it
- One of the most interesting things that we learned is that we had a bunch of people telling us, “*Actually, the reason why I stay on it is because I don’t have any more sugar cravings. I went to the Christmas party and didn’t eat a single cookie, and I’m usually the guy sitting at the table eating all the cookies.*”

**We started to see this theme of sugar cravings**

- As we talked about earlier, one of the hallmarks of GLP-1, is improvement in satiety
- We just did a little pilot study ourselves: we said, “*Go on this product for 90 days and do this diagnostic test on cravings*.”
  - It wasn’t blinded and there wasn’t a placebo arm
  - It was just a proof of concept
  - What we see is that people have a significant reduction in these food cravings
  - That is now being parlayed into funding a clinical trial to look at that

***This is where Colleen thinks the consumer space is a really interesting place to play: rather than going all in with millions of dollars on a clinical trial based on a hypothesis in your head, you can now put products out there to people, and hear back what they’re experiencing***

- You could even get really sophisticated and say, “*Okay, well maybe I’d like to know what are people starting microbiomes or what are their diet? Or what are their lifestyles? Or their demographics?*”
  - To try to understand who might this thing have the most efficacy for?

## Further studies of Akkermansia that have been proposed or are underway [2:20:30]

**Peter proposes an interesting study**

- It would be very interesting if you go back in time, if you had the funding to look at what the constitution of the gut biome was *prior* to the study and *after* the study
  - To see if that predicted response
- In other words, is the greater the deficit of *Akkermansia* at the outset of the study, a predictor of a greater response upon normalization?
- Because even though the average hemoglobin A1C came down by 0.6, there must’ve been people for whom it came down by over a percent
  - And people for whom it only came down by 0.2

**Do you have a sense of what that relationship is?**

- In that trial, we got four stool samples from people during the trial
  - Baseline
  - Something like 30 days in
  - And after the 90-day mark
  - Then we did a washout period where you went for a month without taking anything, and then we got a stool sample
- We racked our brains about, “*How are we going to get people to provide four stool samples?*”
  - This is a real ask
  - We wanted the whole sample
  - We gave people like these cool whip containers, and they had to literally shit in a bucket and put it in their own freezer until they could get to the clinic
    - And everything had to stay frozen
- We had a 100% compliance
  - We had people who dropped out of the study who were still sending us their shit
  - It was amazing how much sample people were willing to share

**The sample used to study the gut microbiome**

- Peter remembers when his brother got back from a trip to Africa, he had an awful GI bug and eventually had to collect a stool sample
  - Peter was looking in his fridge and there was this bag in there, and he was like, “*What’s that?*”
    - He’s like, “*Ah, it’s just some shit.*”
    - Peter didn’t believe him at first
- People were sending Colleen shit
- She wanted this microbiome information in case the clinical trial didn’t work
  - That would provide information on if the probiotic strains got delivered or not
- She wanted to see the presence and absence of their strains
- We also wanted to understand, “*Could you do this predictive modeling of who would be better or worse responders?*”
  - And we couldn’t because the n was too small
    - It also could be that we don’t know enough about these individuals

***The microbiome alone or even the levels of Akkermansia alone are not enough of a predictor of who will be better or worse responders to probiotic therapy***

**Did anybody who took** ***Akkermansia*** **have a significant increase from pre-study to post study during the 90 days?**

*What was the falloff, from 90 days through the washout?*

- Every participant in the study showed an increase in all the strains
  - That was very rewarding because we invest a lot in the encapsulation to get the thing delivered

**Peter’s takeaway‒** ***that was a great proof of concept that you managed to deliver something which in theory is undeliverable***

- The washout period was 30 days (after the 90 days of treatment), and most people lost the strains after that period
- But there were about 15% to 20% of participants, who were able to maintain their *Akkermansia* levels even after not taking the pills anymore

**Is there any chance that those are the people who just consume the best diets (ate the most fiber)?**

- We didn’t do diet logs, and the reason is because Colleen is told that people are liars
- In retrospect [this would be valuable to know]
- Peter thinks a diet log where you only ask them to log fiber… take a picture of everything you eat that is one of these things on this laminated card
  - Carrot, celery, orange
  - Eat all the cookies you want, I just want to know this metric
- Colleen wishes she had met peter when they were doing the trial design
- They didn’t do that, but they asked people, “*What are you? Omnivore? Vegetarian?*”
  - There didn’t appear to be a correlation with that
- Then they asked people *not* to change their diet
  - We don’t want people to have to undergo a behavioral change in order to see an improvement
  - It should be *just* the microbiome intervention
- Of course, we don’t know if people change their diets

**The study Colleen wants to do now**

- Part of the trial is you’re going to be on the product and then we’re going to deliver to you a high-fiber meal that we want you to have for lunch, 3 days in the week
  - The control group just gets the pills

***By deliberately making sure that people are getting this added fiber, you can compare whether that fiber is helpful***

- It almost feels like a no-brainer: the people who will have higher fiber food will do better
- But you will measure their microbiomes, and we’ll see whether the strains are actually even higher for them too

**The next two years is a really interesting time for our scientific understanding of what’s going on**

- If nothing else, Pendulum Therapeutics has figured out how to make something from a manufacturing process that no one else was going to figure out
  - There’s no university that could ever have figured this out, because they wouldn’t have been able to put the resources in it
  - No one was going to spend a hundred million dollars to figure out how to make an obligate anaerobe, when the maximum NIH grant is $480,000 a year
- Now it enables a bunch of people to **ask these questions** about what’s the impact on depression?
  - What’s the impact on ADHD?
  - What’s the impact on obesity, type 2 diabetes?
- Peter adds, “*In many ways, it feels like the bridge between the diet and the drug.*”
  - Because we already have a really good sense from an **efficacy** standpoint, to get somebody to lose weight by changing their diet
  - The **effectiveness** is the problem: it’s too hard to implement for most people
  - At the other end of the spectrum, we clearly know now how to do it with drugs, and that really changed in 2014 when [liraglutide](https://en.wikipedia.org/wiki/Liraglutide) came out
    - But clearly [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) was the game changer, and that’s 3 years ago, was when we saw the pivot from semaglutide as just a diabetic drug, to an obesity drug.

*Look at other questions that haven’t been answered yet*

- The dose response, and is more, better?
- Do we know anything about how much is too much?
- What’s the maximal dose?
- What’s the minimum effective dose and the median effective dose?
- It’ll be five years, and we’ll be sitting here and hopefully having a more interesting discussion
- Colleen points out, “*The right question is, what is the colonization that’s happening?*”
  - It’s not just about what you’re delivering, it’s about what’s colonizing
    - And that’s different from person to person
- If we could crack that nut on the dose to colonization ratio, and in what context that’s better, you start to see improvements
- Colleen agrees, it is the gap between nutrition, and then these downstream small molecules
- The microbiome has been a black box, and now we’ve got some tools here
  - We’re just at the beginning of it
- For us, the big name of the game is, how do we get these products into as many people’s hands, and as many investigators hands as we can to create more and more data around:
  - What is your starting microbiome?
  - What is your lifestyle?
  - How are these things tied together?
  - What are the health outcomes that can really come from a different microbiome?

**Are there any other bacteria out there as specific strains, or even species that you think are going to be worth investigating based on the literature today?**

- Maybe in five years there are many other strains out there that people are taking
  - You might have in your fridge a bottle of *Akkermansia* strain 2, strain 3, strain 4
- We discussed the key strains but there are others, absolutely
- The link between our microbiome and our immune response is super interesting

§

## Selected Links / Related Material

**Company Colleen co-founded**: [Pendulum Therapeutics](https://pendulumlife.com/) | [1:15]

**Kids who are systematically on antibiotics are prone to disease later in life**: [Antibiotic exposure and adverse long-term health outcomes in children: A systematic review and meta-analysis](https://www.journalofinfection.com/article/S0163-4453(22)00004-4/fulltext) | *Journal of Infection* (Q Duong et al 2022) | [1:24:15]

**Definition of a high-fiber diet**: [1:26:00]

- [High Fiber Diet](https://www.ncbi.nlm.nih.gov/books/NBK559033/) | *StatPearls* (A Akbar & A Shreenath 2023)
- [22 High Fiber Foods You Should Eat](https://www.healthline.com/nutrition/22-high-fiber-foods#bottom-line) | Kris Gunnars, *healthline* (May 3, 2023)

**Artificial sweeteners alter gut microbiota in mice**: [Artificial sweeteners induce glucose intolerance by altering the gut microbiota](https://pubmed.ncbi.nlm.nih.gov/25231862/) | *Nature* (J Suez et al 2014) | [1:32:00]

**Higher levels of** ***Akkermansia*** **associated with better response to a high-fiber diet**: [Gut bacteria selectively promoted by dietary fibers alleviate type 2 diabetes](https://www.science.org/doi/10.1126/science.aao5774) | *Science* (L Zhao et al 2018) | [1:36:15]

**Pendulum probiotic for lowering blood glucose**: [Glucose Control](https://pendulumlife.com/products/pendulum-glucose-control-2-og?utm_source=search&utm_medium=google&utm_campaign=132401569592_0a0a33abe6ddb35abab93336335b48e3&utm_term=pendulum%20glucose%20control&gclid=CjwKCAiA9dGqBhAqEiwAmRpTCxhKyPb2qKwNnku4l2sHRachq_u7SLMCvlecdjYQZx-p59xN-BHdpxoCrgIQAvD_BwE) | Pendulum (2023) | [1:47:00, 1:48:45, 2:12:00]

**Clinical trial of** ***Akkermansia*** **and 4 other bacteria in type 2 diabetics**: [Improvements to postprandial glucose control in subjects with type 2 diabetes: a multicenter, double blind, randomized placebo-controlled trial of a novel probiotic formulation](https://drc.bmj.com/content/8/1/e001319) | *BMJ* (F Perraudeau et al 2020) | [1:59:30]

**Glucose Control at a lower dose**: [Metabolic Daily](https://pendulumlife.com/products/pendulum-metabolic-daily) | Pendulum (2023) | [2:17:15]

***Akkermansia*** **probiotic from Pendulum Therapeutics**: [*Akkermansia*](https://pendulumlife.com/products/pendulum-akkermansia) | Pendulum (2023) | [2:17:15]

§

## People Mentioned

- [Lee Kaplan](https://ghdcenter.hms.harvard.edu/KaplanLee) (Director of the Obesity, Metabolism and Nutrition Institute at Massachusetts General Hospital and Associate Professor of Medicine at Harvard Medical School) [1:56:00]

§

![](https://peterattiamd.com/wp-content/uploads/2023/12/bio-colleencutcliffe-500x500.png)

##### Colleen Cutcliffe, Ph.D.

Colleen Cutcliffe earned her B.A. in Biochemistry from Wellesley College and Ph.D. in Biochemistry and Microbiology from Johns Hopkins University. She completed her postdoctoral studies at Northwestern’s Children’s Memorial Hospital. She has held senior positions at bioscience and pharmaceutical firms. Dr. Cutcliffe co-founded Pendulum Therapeutics which uses insights into the microbiome to develop health interventions and probiotics. She currently serves as the CEO of Pendulum. [[Pendulum](https://pendulumlife.com/pages/story)]