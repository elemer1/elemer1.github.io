# #77 – AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions

**Source:** [https://peterattiamd.com/matthewwalkerama2/](https://peterattiamd.com/matthewwalkerama2/)

---

##### Check out more content with sleep expert, Matthew Walker, Ph.D.:

- *(April 1, 2019)* [Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, and memory](/matthewwalker1/)
- *(April 8, 2019)* [Part II of III: Heart disease, cancer, sexual function, and sleep disruption](/matthewwalker2/)
- *(April 15, 2019)* [Part III of III: The penetrating effects of poor sleep from metabolism to genetics](/matthewwalker3/)
- *(June 17, 2019)* [AMA #1: Strategies for sleeping more and sleeping better](/matthewwalkerama/)
- *(October 28, 2019)* [AMA #2: short sleep mutants, optimal sleep environment, & sleep apnea](/matthewwalkerama2/)
- *(August 31, 2020)* [Sleep & Covid-19: Sleep and immune function, chronotypes, and hygiene tips](/matthewwalker4/)
- *(September 7, 2020)* [AMA #3: Fasting, gut health, blue light, caffeine, REM sleep, and more](/matthewwalkerama3/)

In this special episode, Matthew Walker returns for his second AMA episode where he provides his expert insight on numerous sleep-related questions directly from listeners. He answers a wide range of questions from the gene that causes the short sleeping phenotype, to the ideal sleeping position, to the optimal temperature for best sleep, to how fasting affects sleep, plus a full dissertation on sleep apnea, and much, much more. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

We discuss:

- DEC2—A genetic mutation that produces a short sleeping phenotype [11:00];
- What is the best position to sleep in? [22:45];
- Should you consider a “sleep divorce” with your partner? [27:00];
- The challenge of kids wanting to sleep in bed with their parents [28:45];
- Is there an ideal type of pillow? [32:30];
- Any data on hammock sleeping? Should adults be rocked to sleep like a baby? [34:45];
- The optimal room temperature and body temperature for the best sleep [38:30];
- Do humidifiers help? [50:40];
- How do high altitudes affect sleep? [53:15];
- What is the data on weighted blankets (e.g., the Gravity blanket)? [57:00];
- Caffeine—How much, and in what way, does it affect sleep? [58:15];
- How does sexual activity relate to sleep quality? [1:04:00];
- Should we be sleeping in two phases? First sleep & second sleep? [1:06:30];
- Napping—Is there ideal duration? Should we be napping or not? [1:08:30];
- Advice for new parents dealing with sleep deprivation [1:12:00];
- Understanding your sleep chronotype [1:16:15];
- If you drink too much alcohol in a given night, is there anything you can do to make sure your sleep isn’t wrecked? [1:20:45];
- How postmenopausal women can manage their sleep problems with (and without) hormone replacement therapy [1:23:00];
- Could a daily practice of Wim Hof’s breathing method help or hinder quality of sleep? [1:29:15];
- Why do some people paradoxically feel more tired the more they sleep? [1:31:15];
- Sleep apnea—How to know if you have it, the different types, the causes, and helpful resources [1:33:15];
- Is there such a thing called “sleep eating”? [1:45:00];
- If Matt was “sleep czar”, what changes would he make to society to improve sleep? [1:46:15];
- Catch up sleep: Explaining the difference between retrospective damage and prospective benefit [1:48:45];
- Does poor sleep really speed up the aging process? [1:50:30];
- Is medicated sleep better than no sleep? [1:53:00];
- Does vivid dreaming disrupt the sleep cycle? [1:56:45];
- Is there potential benefit to using “binaural beats” or some type of sound to induce better sleep? [1:57:45];
- How is sleep affected by fasting and time-restricted eating? [1:59:45];
- Is there any evidence that polyphasic sleep (e.g., “Uberman”) works? [2:03:30]; and
- More.

§

The Peter Attia Drive

Short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions

§

## Show Notes

## DEC2—A genetic mutation that produces a short sleeping phenotype [11:00]

DEC2 mutation

- People with this mutation are the acclaimed “short sleepers”
- They don’t sleep as much as most people (or as much as most people should be sleeping)

*Does this sound like you?*

- Many people think, “wow, I only get 5 hours of sleep and feel fine, this must be me”
- Matthew cautions, it’s only a fraction of a percent of people who have this gene mutation
- You are more likely to get struck by lightning than to have this gene mutation

*So how much sleep do they need?*

- Some think 5 hours is all they need, however…
  - When you bring these people to the lab and set up ideal sleeping conditions…
  - They sleep about **6.25 hours**
- An important thing to point out is that the average person sleeps at *6.5 hours per night*
  - And many people get much less than that
  - And they are NOT the DEC2 mutants
- When you take the average population and put them in a lab…
  - They will sleep between 7.5-9.5 hours per night
  - Why the big range? ⇒ probably due to age difference in the general population

**Why we don’t sleep as much or as well as we get older?**

- As we get older, even though we may **need** as much sleep as we did when we were younger…
- Physiologically we just can’t generate that sleep that we need

*Why can’t we?*

- Firstly, as we age, part of the brain atrophy as a quicker rate than others
- Particularly the deep sleep generating areas ⇒ the [medial prefrontal cortex](https://www.sciencedirect.com/topics/medicine-and-dentistry/medial-prefrontal-cortex)
- (Trick: Take your thumb, stick it between your eyes, raise it up about an inch and a half, and you’re right there. That’s your medial prefrontal cortex.)
- That part of the brain atrophies quickly
- It also accumulates beta amyloid most significantly and early on

*How much sleep does a young, healthy person need?*

- If you take away electricity and only expose people to natural light, their [sleeping habits will change](https://www.ncbi.nlm.nih.gov/pubmed/23910656)
- No electricity, no phones, etc.
- Two things tend to happen
  - 1) They sleep almost **9 hours per night**
  - 2) They **go to bed around 9:30 pm** (even people who say their bedtime is typically 11pm or later)

**Back to the DEC2 mutation people**

*Are there any health consequences of having the DEC2 mutation?*

- We don’t know the answer yet for 2 reasons:

  1) Because we haven’t known about the gene for long enough to look at long term data

   2) There is just so few of these people to make any statically meaningful conclusions

*Do they lose more sleep from one sleep stage vs. another?*

- They tend to be really efficient deep sleepers (almost like they are really efficient at clearing out the adenosine that has built up throughout the day)
- However, they get less REM sleep

*Does that matter?*

- Matthew cautions anyone who thinks any stage of sleep is less important than another

⇒ Rat studies in the 1980s looked at sleep deprivation…

- First, they [deprived rats of any sleep at all](https://www.ncbi.nlm.nih.gov/pubmed/6857280/) and after 9-11 days they were dead
- They then [selectively deprived them of either REM sleep or non-REM deep sleep](https://www.ncbi.nlm.nih.gov/pubmed/2648533)
- The rats that were deprived of REM sleep died almost as quickly as when they were deprived of total sleep
- The rats that were deprived of deep sleep took about twice as long to die
- The takeaway is that **REM sleep may be more important in terms of being an essential life ingredient**

## What is the best position to sleep in? [22:45]

\*First, if you suffer from sleep apnea/heavy snoring, Matt advises AGAINST sleeping on your back

\*\*Questionnaire to tell you your risk for sleep apnea: [Stop-Bang Questionnaire](https://stopbang.ca/osa/screening.php)

*Which sleeping position is best?*

- 45% of people sleep on your side (fetal position)
- If you don’t have apnea or snoring…
- Sleep on your back is best for your spinal alignment
- One of the causes of sleep difficulties (outside of mental anxiety) is physical pain
- And back sleep generally results in the **least amount of pain**

*Is there evidence that sleeping on your back vs. side vs. stomach produces better sleep?*

- Not at this time
- So, if you are comfortable, don’t force yourself to change positions

Side sleeping and the glymphatic system

- Glymphatic system essentially is a cleansing system for the brain that during sleep at night washes away all the metabolic toxins and byproducts, beta amyloid, tau, and the other Alzheimer’s-related proteins)
- See [previous episode with Matt](https://peterattiamd.com/matthewwalker1/) for more on the glymphatic system
- There is some evidence in animal studies that’s accumulating that [side sleeping allows the glymphatic system greater clearance capacity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4524974/) than any other sleeping position
- Another observation is that you rarely see other species exclusively sleeping on their back
- It’s usually some version of side sleep and it MAY have something to do with the glymphatic system

## Should you consider a “sleep divorce” with your partner? [27:00]

- If you survey people, about 40% of them will say that they do not sleep in the same location as their partner.
- Of the remaining 60%… about 20-30% of that group will actually say that they go to bed with their partner at night, but they will wake up in a different location in the morning
- If you fall into this category, Matthew recommends a “*sleep divorce*”
  - (which can prevent you from having a real one)

*If I get a sleep divorce, will I no longer be intimate with my spouse?*

- The stigma is that if you’re not sleeping together well, you’re not having sex
- In fact, it’s actually the opposite
- By having a sleep divorce, you could increase the quality of your sleep which means…
  - [Sex hormones improve](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4445839/) both in males and in females
  - Their physical relationship and the [intimacy improves](https://www.ncbi.nlm.nih.gov/pubmed/25772315)
  - The quality of their relationship improves

## The challenge of kids wanting to sleep in bed with their parents [28:45]

Peter asks the question about kids sleeping in bed with their parents

- Peter points out that from an evolutionary perspective, young kids probably never slept alone in their own part of the cave
- So it’s natural for many kids to want to sleep with you
- But sleeping with kids can disrupt your own sleep

Matthew confirms this ancestral way to sleeping

- Looking at hunter-gatherer tribes…
- You see them sleeping as a group

*Why isn’t it a problem for them?*

- Well, first they don’t suffer from snoring (and other sleep disorders) the same way we do because they are generally much more lean whereas the Americans suffer from obesity, etc.
- They also don’t even know what insomnia is (probably they have the same anxiety we do from modern society)

***How do we deal with this in the modern world?***

The downside of having kids in the bed

- Sleep quality suffers which may result in you NOT being the very best version of parents
  - Including getting behind the wheel and drive your children around the next day while sleepy
- Second component of that is it’s difficult to train them to actually gain the confidence for them to sleep by themselves and develop that skill.
- And it is a skill that they will need throughout their lives.

Don’t make it a habit

- Matt says to not make it habit
- Instead have it be more of “treat” for them every once in a while

## Is there an ideal type of pillow? [32:30]

- Not any good scientific data out there
- Matthew says this actually could be an opportunity do come in and disrupt the industry

Here are his quick thoughts on how we could find the right pillow:

“You could do things like three-dimensional sort of, moving an iPhone around your head, understand what your mass is, insert your body type, etc, etc, give a few questions on your sleep preference. I think there’s a way that you could actually find the Da Vinci code to the correct pillow, or at least the correct three closest pillows. You send them out to people, and then they pick which one they want, and they send the other two back.”

## Any data on hammock sleeping? Should adults be rocked to sleep like a baby? [34:45]

- Matt says there isn’t much about hammock sleeping specifically, but…
- There is something about the nature of **rocking** (like we do with babies)

A group out of Geneva [did a study](https://www.bbc.com/news/health-46986419)

- They took a bed frame and a mattress, and then they suspended it from the ceiling with four ropes at either corner.
- And then they connected the bed to a device that would just cycle the bed from left to right in this lateral motion at a very slow rocking speed
- So it’s so slow that you typically don’t have too much of a sense of it when you close your eyes
- *So what happened*?
  - The individuals fell asleep significantly faster
  - They had greater amounts of deep sleep, and especially these deep sleep brainwaves
  - And what usually comes with those deep sleep brainwaves are something else that we call [sleep spindles](https://en.wikipedia.org/wiki/Sleep_spindle) (short bursts of synchronous activity that are critical for learning and memory)
- \*In summary, the rocking motion…
  - i) induced a physiologically reliable change in brain oscillations, and
  - ii) helped people fall asleep faster

![](https://peterattiamd.com/wp-content/uploads/2019/10/rocking-bed-1024x682.png)

**Figure 2. Rocking bed from University of Geneva study.** Image credit: [bbc.com](https://www.bbc.com/news/health-46986419)

## The optimal room temperature and body temperature for the best sleep [38:30]

***Did our ancestors get better quality sleep during certain times of the year and/or in certain climates?***

- Best data that we have right now is looking at these hunter gatherer tribes
- Take tribes that live in warm climates (e.g., close to the equator)
  - In winter, they sleep longer at night
  - In summer, they sleep less at night
  - However, they tend to take naps in summer afternoons to make up for that

> “The data favors coldness for longer sleep.”

⇒ Tip: Peter uses the [chiliPAD](https://www.chilitechnology.com/) in the summer time

***Is there an optimal room temperature?***

- Between [*65-67 degrees*](https://www.sleep.org/articles/temperature-for-sleep/), says Matt
- But the answer is more complex than that
- For example, it varies from person to person

[Studies have been done](https://academic.oup.com/brain/article/131/2/500/407617) where they strap people into a body suit where you can exquisitely control the temperature of any part of the body

–*Summary of the findings*:

1. For your extremities (hands and feet), if you warm them up with socks, for example, it will bring heat to them away from your body, resulting in a cooling of your core temp so you will fall asleep faster
2. Then you need to get cold to stay asleep during the night
3. And then you need to warm up to wake up in the morning

\*Other tips for cooling your core body temperature

- Take a hot bath or a shower
- All of the blood is charmed to the surface of your skin, and
- it radiates the heat out of the core of your body
- Your core body temperature plummets once you get out

So in real life…

- Warm yourself up with a hot shower to radiate that heat out and get you to sleep quicker
- Keep the room cool to keep your body cold throughout that middle section and later section of sleep.
- Then, set your thermostat to rise in the last 15 minutes of your sleep so you will wake up easier and feel less groggy

**Tangent on thermoregulation**

- We live within a very narrow range of body temp (about 10 degrees F)
- At 104-105 degrees, you’re destroying protein internally
- And then anything below about 92, 93, even 94, it starts to get concerning
- “You’re always on some thermal edge of a cliff in some ways.”

***How much better would you predict one would sleep if the room temperature went from 75 to 65?***

- On average, people are more likely to sleep considerably better at 65 than 75.
- In terms of duration, or stage quality, or what metric?
- Some people will see it in terms of quantity of deep sleep, but most benefit is in **quality** of sleep
- In [studies](https://academic.oup.com/brain/article/131/2/500/407617), much of the benefit of the cooler temperature is in the **quality of your sleep measured by the electrical brainwave signature**
- This is NOT something you’ll see on your personal sleep tracker
- So just know that if you aren’t seeing an improvement in quantity on your sleep tracker, don’t just assume it’s not helping

## Do humidifiers help? [50:40]

- It’s surprising that we have so little data on this, says Matthew, given how many people use humidifiers next to their bed
- Matthew says he thinks intuitively that “there may be something in humidity”
- However, the few studies out there don’t really suggest humidity is making a difference
  - [This study](https://www.ncbi.nlm.nih.gov/pubmed/11683212) that found that holding the temperature constant and changing the humidity did not alter the sleep of the neonates
- So right now, not great data overall
- and the data that we *do have* doesn’t really suggest so much of a change.
- But the “*absence of evidence is not evidence of absence*”
- We just need more studies

## How do high altitudes affect sleep? [53:15]

The [data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3654241/) of altitudes above ~5,000-6,000 feet (usually climbers) suggests:

- People wake up more frequently
- They have less amount of non-rapid eye movement sleep
- less deep non-REM sleep quantity
- They also have lower *quality* deep sleep
- \*So they struggle to fall asleep, and when they do get to sleep, the depth of that deep sleep is not as deep.

*What about once people are acclimated to the altitude?*

- We don’t have good longitudinal data to look at the question of acclamation
- At some point, you would think that the body does recalibrate

We also don’t know…

- At what altitude sleep begins to be affected
- Is it gradual as you move away from sea level?
- Is it a linear change? Or is it exponential?
- Is is a step function change at a certain level?

Peter’s observation about this sleep quality at elevation:

- In 4 years of sleep data
- Peter’s lowest month of heart rate variability came during a month that he spent half the month in Colorado

## What is the data on weighted blankets (e.g., the Gravity blanket)? [57:00]

Peter asks if there are any data on efficacy of weight blankets (like the [Gravity Blanket](https://gravityblankets.com))

COUPON CODE=Subscribers get a [discount on Gravity Blankets](https://peterattiamd.com/members/discounts/)

- Peter personally uses the Gravity blanket during the winter time
- Matthew says there is no good data at the moment
- It’s very hard to do a placebo controlled study
- There is no way for study participants to be blind to whether or not they have a 25 lb blanket on them
- That said, if people subjectively feel like their sleep is improving that is a good thing
- And even if the effect is a [placebo](https://peterattiamd.com/the-placebo-effect/), that’s not a bad thing

## Caffeine—How much, and in what way, does it affect sleep? [58:15]

- Some people are more sensitive to caffeine than others
- The more rapid you metabolize caffeine, the less sensitive you are to its effects
- But when referring to sensitivity, we’re talking about pure “wake promotion”
- This may be a totally separate measure when compared to how it affects your sleep
- In other words, if you are someone who is not affected by caffeine at all, that doesn’t mean you aren’t harming your sleep quality

*What happens when you take 180-200 mg of caffeine in the evening?*

- On average, it reduced the amount of deep sleep quality in terms of electrical quality by about 20%
- So even if you can fall asleep fast, and get the same “quantity” on deep sleep (like on your sleep tracker), it doesn’t mean your quality isn’t negatively affected
- \*A 20% reduction is deep sleep quality is equivalent to aging you by 25 years

> “I would have to age you by probably somewhere around about 25 years to get that drop in your deep sleep quality. Or you could do it every night with a cup of coffee.”

**And even** [**more concerning study**](https://www.ncbi.nlm.nih.gov/pubmed/7796154/)

- Gave people a dose of caffeine at 7:20 am
- No caffeine at all throughout the day
- Compared it to placebo
- They found something “stunning”
- It dropped deep sleep by 10-12%

## How does sexual activity relate to sleep quality? [1:04:00]

*Does having regular sex improve the quality of sleep?*

*When is the best time to have sex before sleep?*

*Does an actual orgasm improve sleep quality?*

- For most people (60% of women, 70% of men), [sex that results in an orgasm produces better quality of sleep](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6409294/)
- It has to be sex that results in an orgasm for *both* partners

*Why would orgasm and sex actually lead to better sleep physiologically?*

- We move into the parasympathetic state of the nervous system, which is this sort of quiet, restful state of the nervous system.
- Part of that is because your heart rate will decelerate after the increase that’s happened during intercourse
- Less cortisol –  the deceleration of the HR will also come with a reduction in things like cortisol
  - Cortisol is the enemy of sleep at night…it should be dropping to almost it’s the lowest levels just before you fall asleep and stays low in the first half of the night

**Masterbation**

- [Masturbation can also be a sleep aid](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6409294/)
- It doesn’t seem to be as effective as sex between individuals, but it certainly does seem to have an impact

## Should we be sleeping in two phases? First sleep & second sleep? [1:06:30]

- In the [Dickensian era](https://en.wikipedia.org/wiki/Charles_Dickens), there is some evidence people would sleep in 2 shifts
- At this time (in the UK and Europe), people would split shift the night and they would sleep for the first half and they would get up and eat, have sex, do social activities, etc. then go back to sleep
- But *were we designed to sleep this way*?
- Matthew says there is no evidence to suggest that is how we are supposed to be sleeping

*What about the afternoon* [*siestas/naps*](https://en.wikipedia.org/wiki/Biphasic_and_polyphasic_sleep#Biphasic_sleep)*?*

- It’s more likely that we were designed to sleep 6.5-7 hrs at night and take an afternoon nap
- This is common in hunter gatherer tribes

## Napping—Is there ideal duration? Should we be napping or not? [1:08:30]

***Is there an ideal duration of a nap?***

- It depends on what you’re asking of the nap
- A **90 minute nap** will give you one full sleep cycle and allow for some REM sleep
- If you want to simply get rid of some fatigue and sleepiness, a **15-20 minute nap** will be enough
- Try to avoid waking up after about 45 minutes
  - You will be in the middle of a deep sleep cycle
  - You may suffer what’s called sleep inertia, which is where you may actually feel even worse.
  - You’ll feel groggy

***Should you be napping or not?***

It’s a “*double edged sword*”

Benefits of napping may include…

- Improvement in learning and memory
- Cardiovascular function

Bad things about napping…

- Throughout the day you are building up the sleepiness chemical called adenosine
- And after about 16 hours of wakefulness, you should have enough of this sleepiness chemical weighing down on you (i.e., sleep pressure) to force you into sleep at night
- If you nap, you release some of that pressure which may make it harder for you to fall asleep at night

> “So the answer is if you can nap regularly and you’re not struggling with sleep at night, naps are just fine. But if you can’t nap regularly or especially if you’re struggling with sleep at night, the advice is do not nap, build up that healthy sleepiness.”

## Advice for new parents dealing with sleep deprivation [1:12:00]

*Advice for new parents, especially moms, with young babies*

- Nap when the child is napping (if possible)
- The nights will be rough and disruptive so you’ll have enough sleep pressure even if you are napping several times a day
- If you have a spouse or partner that has a different sleep cycle (say you are an early riser and they are a night owl)…
- Try to split up the baby shifts to match that trait

## Understanding your sleep chronotype [1:16:15]

*Is your sleep chronotype genetically set?*

- Yes, you are born with the genes for your chronotype

*No matter your genes though…*

- Your sleep timing and hours needed will change from childhood, to teen years, to adulthood

*Moving high school start times…*

- In a [previous podcast](https://peterattiamd.com/matthewwalker2/), Matthew spoke extensively about the need to move high school start times to later in the day to match teens’ propensity to sleep longer and later into the morning
- “*That’s where we see some of the greatest amounts of sleep deprivation because that’s where the greatest mismatch between school start times and wake up times happen relative to their shifted now biological circadian rhythm.*”

*Adulthood*

- You start to settle into your genetic sleep chronotype

*Older years*

- Then as we get into our elder years we regress to childhood hours, go to bed early, wake up early

## If you drink too much alcohol in a given night, is there anything you can do to make sure your sleep isn’t wrecked? [1:20:45]

*If you drink too much, is there anything you can do that night be make sure your sleep isn’t wrecked?*

- Probably not
- Best thing to do is expect a bad night of sleep and plan accordingly tomorrow

*Peter’s two cents…*

- In the case where you didn’t go overboard, but maybe had 1-3 drinks
- Alcohol inhibit vasopressin which is an antidiuretic hormone
- Peter has used a drug called vasopressin (0.1 milligrams of DDAVP or vassopressin)
- It will prevent you from needing to get up and pee during the night (since that is part of the sleep disruption)
- **CAUTION**: this is not an over the counter medication, and if you take too much you can have problems

## How postmenopausal women can manage their sleep problems with (and without) hormone replacement therapy [1:23:00]

Many women after menopause [see a decline in their sleep quality and quantity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5810528/)

⇒ Side note:

1. Peter is a big proponent of HRT for women with symptoms
2. See [The Drive episode with Carol Tavris and Avrum Bluming](https://peterattiamd.com/caroltavris-avrumbluming/)

But for women who for whatever reason *don’t want to take hormones*…

*–What else can women do or can women do in particular around this issue shy of taking hormones?*

- Matt says between 40 to 50% of women will go through significant sleep difficulties during that menopausal phase
- One of the triggers there is thermoregulation (i.e., hot flashes throughout the night)
- It’s not just that though, insomnia can also be part of the problem

–In terms of treatments…

- The data haven’t been very good (there’s not enough studies)
- With that said, the first step should be to try to figure out what is really triggering the sleep problems
- Firstly, people are getting older and your sleep just gets worse as you get older
- Going a step further, we also know that with the menopausal transition, we get changes in mood states
  - Increases in depression
  - Increases in anxiety
- So then you try to answer the question: *Is it one of those that is the trigger or is it some of these symptoms that are altering thermoregulation?*
- In terms of treatment of the mental health aspects, there are different treatments (e.g., meditation)
- But for menopause and sleep…
  - Data suggest that **HRT (hormone replacement therapy) combined with melatonin** has some efficacy
  - You combine those two and sleep seems to be improved as well

**Peter’s approach with his patients**

- Peter’s approach with HRT uses all three hormones: Estrogen, testosterone, and progesterone
- Each of them can play a role in sleep, **but you can’t do it at the same time**

*The approach*

   Step 1:

- First symptoms that typically show up are [vasomotor symptoms](https://www.medicalnewstoday.com/articles/317801.php)
- Peter will treat vasomotor symptoms first with estrogen alone, *for a short period of time*
- You can’t do that for a long period of time because unopposed estrogen will increase the risk of endometrial cancer.
- But for a period of a month or two, it’s not an issue at all.

   Step 2:

- And once you fix the vasomotor symptoms, you then ask, *How are you feeling? How are you sleeping?*
- There’s a subset or women whom once the estrogen levels are normalized, the FSH comes down, they feel amazing (i.e., no more joint discomfort, hot flashes, sleep disturbances, etc.)
- But… there sleep isn’t getting better
- In those women, we have a choice:
- We could either just go straight to a progesterone coated IUD (which will basically cover you from the endometrial perspective); or
- You would use systemic progesterone
- And the progesterone is a great sleep drug for this subset of women

   Step 3:

- If sleep still not all the way back, Peter will use testosterone
- “*I have found this approach to allow you to, almost without exception between the three of them, return a woman’s sleep to sort of a great state.*”

*\*In terms of mood irregularities*…progesterone is probably the most sensitive to mood disruptions during perimenopausal period

**In summary**:

- For a woman who is experiencing sleep disturbances with menopause who for some reason either doesn’t have a doctor who’s comfortable doing hormones or doesn’t want hormones herself…
- *Melatonin, temperature regulation, and sleep hygiene* is the playbook

## Could a daily practice of Wim Hof’s breathing method help or hinder quality of sleep? [1:29:15]

[Wim Hof](https://en.wikipedia.org/wiki/Wim_Hof)

- Also known as The Iceman, is a Dutch extreme athlete noted for his ability to withstand freezing temperatures
- He attributes his feats to his [Wim Hof Method (WHM)](https://www.wimhofmethod.com/), a combination of frequent cold exposure, breathing techniques, and meditation

*Could a daily practice of Wim Hof’s breathing method help or hinder quality of sleep?*

- “Fantastic question… no idea.” says Matthew

Peter would like to explore this more

- He’s heard a wide range of reports from people from almost dying
- To people saying it change their life

## Why do some people paradoxically feel more tired the more they sleep? [1:31:15]

If this is happening in the first couple of weeks or months once you’re starting to go into sleep extension…

- It’s usually because you’re still trying to sleep off the debt that you’ve accumulated
- Now, we can never pay back all of the sleep debt that we carry
- The system has no capacity for recovering all that it lost, but it will try to sort of sleep back some of that debt.
- And when people start to sleep longer and they are carrying a lifetime chronic debt, then they typically have almost like a “sleep hangover” effect as they’re washing out the chronic sleep restriction

If this has been going on for five or six months…

- That’s something different
- Figure out what your sleep chronotype
- Maybe you’re sleeping the right amount now, but you’re just not placing that eight-hour window of sleep at the right point on the clock face for your specific chronotype.
- And that’s where you can also get some of this hangover effect too if you’re not sleeping at the right phase.

> “You’ve got to be sleeping the right amount, but also at the right time to be in sync with your chronotype, with your circadian biology, and that can sometimes cause hangover effects as well.”

## Sleep apnea—How to know if you have it, the different types, the causes, and helpful resources [1:33:15]

**What does the term actually mean?**

- Apnea simply means absence of respiration/breathing

**Two primary types of apnea**:

*1 | Obstructive sleep apnea*

- This is the version where your airways collapse, either partially or fully, which obstructs your ability to breath
- With a partial collapse, you’ll start to get this sort of strange sound
- When it fully collapses, that’s when you will get cessation of breathing typically

*2 | Central sleep apnea*

- There is no blockage in the airway, there is no problem with the airway at all.
- In fact, it seems to be a fault of the brain itself.
- The brain for a short period of time stops sending the signal for respiration.

*Note: You can also have a* ***mix of both obstructive and central apnea***

**An underdiagnosed killer**

- Sleep apnea is the most underdiagnosed sleep disorder
- About 80% of people who have it are undiagnosed
- It kills you chronically but poor sleep contributing to disease and aging
- And it kills you acutely
  - E.g., you might fall asleep behind the wheel of your car

![](https://peterattiamd.com/wp-content/uploads/2019/10/car-accidents-from-sleep-loss-1024x685.png)

**Figure 1. Sleep loss and car crashes.** Source: [Why We Sleep: Unlocking the Power of Sleep and Dreams](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316) by Matthew Walker

**Think you might have sleep apnea?**

- Take the [Stop-Bang Questionnaire](https://stopbang.ca/osa/screening.php)
- If you do, find yourself a board certified sleep medicine doctor at [sleepeducation.org](https://sleepeducation.org/find-a-facility)

> “Do not leave sleep apnea untreated, it will shorten your lifespan, and it will certainly shorten your health span. That data is compelling.”

**CPAP device**

- Stands for continuous positive airway pressure
- It attempts to force open the obstructed airway with pressure
- It needs to be fitted to the individual and the pressure titrated to match the needs of the person

Adherence issues: *How can we improve the compliance and adherence for these devices?*

–First, we must get really good at fitting the mask properly because…

1. i) an uncomfortable fit will reduce adherence
2. ii) a bad fit will not keep the proper pressure needed to open the airway

–Secondly, accountability from another person or technology

- Having an app or having a coach that would actually just help you check in with you every day, just give you motivation

**Do we know what causes central apnea?**

- Not a lot of data so the etiology is less clear
- We know a lot more about the contributing factors of **obstructive apnea**
  - Such as men are twice as likely to have it
  - Overweight
  - Neck circumference

*What is the most common type of sleep apnea in the population?*

- More common for obstructive than central
- But there could be a self-selecting bias because people are more likely to get checked if they snore (a central apnea person may not be snoring)
- So we really don’t know

Do you have a point of view on using the apneic hypoxemic index versus the oxygen desaturation index (ODI)?

- Peter prefers using the ODI with a 4% cutoff
- The [mortality data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5276717/) says more than ~25 **4% ODIs per hour** is a really significant **predictor of mortality**
- Peter says this information helps him communicate with the patient the severity of this and why we really have to act on this sort of thing

AHI

- Apnea hypopnea index looks at the number of times that you have a true apneic event where you have a cessation of breathing
- A **moderate** degree of apnea would be a cessation of breath between **10 to 15 per hour**
- That would be like someone coming into your bedroom and *strangling your neck until you stopped breathing* **80-100 times in a single night**
- And then I’m going to expect you to wake up the next day and feel good and go to work and perform well and be a good partner to your wife or husband?
- “*That’s ridiculous…but that’s what that disorder is doing.*”

***Do any of the sleep trackers detect oxygen saturation?***

- Fitbit devices have the capacity built in (but may not have unlocked it yet)
- Apple may be looking into this, but again, I have no insider knowledge.
- Matt says it would be a huge deal if sleep devices could do this…
- The but obviously concern would be the accuracy

**Other helpful apps**

An app called [SnoreLab](https://www.snorelab.com/)

- It records the audio throughout the night
- Then you can go back and it’s almost like a Richter shock where you can see how severe your snoring was
- You can even tap anywhere during the night and you can hear yourself snoring

## Is there such a thing called “sleep eating”? [1:45:00]

*Is there such a thing called “sleep eating”?*

- It is a real condition
- It’s part of a set of conditions that we call [parasomnias](https://en.wikipedia.org/wiki/Parasomnia)
- These are things that happen around sleep, not necessarily during sleep itself
- Parasomnias typically happen from deep sleep (not during dream sleep like most people think) when you get a jolt of the sympathetic nervous system activity
- You technically wake up, but you’re neither fully awake nor fully asleep and you start to act out routine behaviors (i.e., Sleep walking, sleep talking)
- But a more rare variation is *sleep eating*

*What do we do about it?*

- There’s not too much we can do, unfortunately
- Talk to a sleep doctor
- There may be a few pharmacological approaches out there but not great treatment outcomes right now
- The doctor on [this video](https://www.youtube.com/watch?v=dCEnro20G9U) says **clinical hypnosis** can help with this

## If Matt was “sleep czar”, what changes would he make to society to improve sleep? [1:46:15]

***If Matt was “sleep czar”, what 3 changes would he make to society to improve sleep?***

  Step 1: A public health campaign needs to be the first step at the government level

- There are great campaigns for things like drink driving, safe sex, risky behavior, even physical activity, eating.
- We have policies for those in these first world nation government approaches,
- But *where is the policy for sleep*?

  Step 2: Institutions

- A great example would be medicine
- You see in a doctor’s office posters that would describe here are “8 ways that you can improve your diet” or “4 ways that you can improve your physical activity”
- W*here’s the chart that describes tips for better sleep*?

  Step 3: Education

- In school, we get lectures on safe sex, drink and driving, etc.
- W*here was that lecture for sleep education*?
- “It is so fundamental. It’s such a huge part of that developing teenager’s life, they should be given that. It should be given early on.”
- Matt wants to help create an education curriculum that is palatable to young audiences so we stop this sort of “parent to child transmission of sleep neglect and sleep ignorance”

## Catch up sleep: Explaining the difference between retrospective damage and prospective benefit [1:48:45]

**Explaining the difference between retrospective damage and prospective benefit**

So let’s think about cancer,

- If I put you on one night of four hours of sleep, I can [drop your natural killer cell count on average for this group by about 70%](https://www.ncbi.nlm.nih.gov/pubmed/7871104)
- The following day after that short sleep, your vulnerability to cancer is presumably going to be increased because of that drop in NK cells
- Now, getting lots and lots of sleep the following night is **not going to go back in time and bend the arrow of time back on itself and wash away that cancer risk**
- Instead, what it’s going to mean is that for the day after you’ve got good sleep, your natural killer cell count is going to be presumably back up
- Therefore you’re now **de-risking your cancer risk by way of getting good sleep**.

See [previous episode](https://peterattiamd.com/matthewwalker2/) with Matt where they discussed NK cells

> “So you can’t really go back in time, you can’t pay back a debt that you’ve accumulated at that point and wash away the damage that happened at that point, but you can risk mitigate in the future by getting good sleep.”

## Does poor sleep really speed up the aging process? [1:50:30]

In the [previous AMA](https://peterattiamd.com/matthewwalkerama/), Matt discussed how less sleep is associated with an increase in biomarkers of age ⇒ specifically this section: Does poor sleep speed up the aging process? [2:12:00]

*But does poor sleep really* ***cause*** *faster aging?*

*Or could we be inappropriately inferring causality from epidemiology studies?*

- Firstly, Matt admits that sleep and aging is a bi-direction system
  - It goes both ways
  - I.e., aging causes poor sleep, but poor sleep also causes aging
  - But the question then becomes… *Is the traffic flowing more dominantly in one direction than another?*
- So, *when does Matthew feel comfortable making claims of causality*?
  - Only when he sees evidence in…
    - Epidemiological studies;
    - Experimental human studies; and
    - Experimental animal studies;
  - \*That’s the point where you start to feel comfortable speaking about causality.\*

*Ways to test causality:*

- - First in people,
    - we can take someone who has no anxiety, take sleep away, hold all of the factors constant and see if anxiety is induced
    - That’s causal manipulation.
    - But let’s be self critical there: *Perhaps it’s just the stress of being sleep deprived that causes the anxiety and* ***not the lack of sleep itself***

- *How do you control THAT?*

- - Do an animal study where you can actually remove the adrenal glands to therefore remove the cortisol response that is producing the stress.
  - You can hold the stress response constant and you can deprive them of sleep and you can look at anxious behavior, and you’ll see the same thing.

> “So it’s only under those circumstances where I see causality, I see epidemiological studies, I see experimental human studies, I see experimental animals studies. That’s the point where you start to feel comfortable speaking about causality.”

==> For more on the pitfalls of epidemiology see [Studying Studies: Part II – observational epidemiology](https://peterattiamd.com/ns002/)

## Is medicated sleep better than no sleep? [1:53:00]

*For someone struggling with severe insomnia, is it better to get almost no sleep or to take an* [*antihistamine*](https://en.wikipedia.org/wiki/Antihistamine) *or mild* [*benzos*](https://en.wikipedia.org/wiki/Benzodiazepine) *as a sleep aid?*

- Matt admits that this is a very tough question
- Firstly, people very quickly build a tolerance to antihistamines
- And then they can typically have [rebound insomnia](https://www.ncbi.nlm.nih.gov/pubmed/2567741) when they come off of antihistamines and/or benzos
- Matt suggests first going through [Cognitive Behavioral Therapy for Insomnia](https://sleepeducation.org/treatment-therapy/cognitive-behavioral-therapy) (CBTI)
- If that doesn’t work, then “*I don’t know the right answer to that*”
- In 2016, the [American College of Physicians made the recommendation](https://www.acponline.org/acp-newsroom/acp-recommends-cognitive-behavioral-therapy-as-initial-treatment-for-chronic-insomnia) that sleeping pills must no longer be the first line recommended treatment for insomnia due to their harmful (even fatal) consequences and that the first treatment must be CBTI

CBD

- CBD was discussed on previous episodes of The Drive with Matt Walker
  - [Episode #49 with Matt](https://peterattiamd.com/matthewwalker3/) ⇒ *The efficacy of THC and CBD as sleep aids [1:05:30]*
  - The first [AMA episode with Matt](https://peterattiamd.com/matthewwalkerama/) ⇒ “*Can CBD and THC be used for sleep? [1:39:30]*”)
- But people are reportedly having some success with CBD for sleep
- But be careful, it’s the “wild wild west” with OTC CBD… “there’s not good regimented quality control”

Peter’s two cents…

- In a crisis situation, short use of benzos is not an unreasonable choice (Matt agrees)
- In many cases, anxiety can drive insomnia (and insomnia can then also drive anxiety)
- But in cases of anxiety being the prime driver, short term use of benzos may help to break the cycle
- Peter finds it’s not that hard to get people off them and back into a routine

## Does vivid dreaming disrupt the sleep cycle? [1:56:45]

- Vivid dreams do not seem to disrupt sleep in terms of quantity of quality (even though they may feel sort of exhausting)
- Trauma dreams (i.e., in PTSD patients) do, in fact, [disrupt sleep](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4197954/)

## Is there potential benefit to using “binaural beats” or some type of sound to induce better sleep? [1:57:45]

*Is there a potential benefit to using “binaural beats” to induce better deep sleep?*

- Matt says that these “binaural beats” or other downloaded sound files don’t have any good scientific studies that have really demonstrated efficacy

**Data around sound inducing better deep sleep**

- Studies have been done where people will actually measure your deep sleep brainwaves
- They will use these short bursts of sound that try to predict when that next deep sleep brainwave is going to arrive
- And at the sort of “stroke of midnight” they will play the auditory tone
- And if you do that, what you can actually induce is a larger size, a bigger amplitude of deep sleep brainwave activity
- And you can get some [memory benefits](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4523433/) from that

*⇒ But here’s the problem…*

- First, if your timing is off and you’re striking at 6 rather than midnight, you’re actually going to inhibit your deep sleep brainwaves
- Secondly, if you’re doing it all night, the brain will actually start to fight back
  - At best, it becomes ineffective.
  - At worst, it could become sleep disruptive.

## How is sleep affected by fasting and time-restricted eating? [1:59:45]

Matthew has said in a [previous episode](https://peterattiamd.com/matthewwalker2/) that fasting, from an evolutionary perspective, would reduce our sleep demand to give us more time to forage for food

But in Peter’s experience with fasting, he finds it produces an amazing state of sleep (albeit slightly less duration) but better in quality

**Does this surprise Matthew?**

- *Yes and no*, he says
- He says “no” because we don’t really have good data
- The only decent data we have is with people practicing Ramadan where [their REM sleep is negatively affected](https://www.ncbi.nlm.nih.gov/pubmed/11903862)

**Eating window with time-restricted eating**

- Peter points out that Ramadan isn’t true fasting it’s just fasting during the day time and they feed at night time so they are almost in a “hyper fed state”
- The Ramadan data is probably better at helping us learning something about meal timing’s effect on sleep for someone practicing time-restricted feeding and suggests and **earlier window of eating is better**
- [Here is data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6627766/) pointing to an early feeding window being better based on glucose levels

## Is there any evidence that polyphasic sleep (e.g., “Uberman”) works? [2:03:30]

*What is the Uberman schedule of sleep?*

- It’s a version of [polyphasic sleep](https://en.wikipedia.org/wiki/Biphasic_and_polyphasic_sleep) where sleep for short bursts (45-90 mins) then be awake for a couple hours and then just cycle on and off throughout the day
- Kind of like sleeping like an infant
- There is no good evidence in adults that that is at all how we should be sleeping.

Check out this “real life” [experiment](https://youtu.be/XLTg2nHZEHQ) where [Cosmo Kramer](https://en.wikipedia.org/wiki/Cosmo_Kramer) tried polyphasic sleep (**Spoiler alert**: It didn’t work well)

§

## Selected Links / Related Material

**The first AMA with Matt Walker**: [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/) | Peter Attia (peterattiamd.com)

**Matthew’s book**: [Why We Sleep: Unlocking the Power of Sleep and Dreams](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316) by Matthew Walker | (amazon.com) [1:00]

**Matthew’s Ted Talk**: [Sleep is your superpower](https://www.ted.com/talks/matt_walker_sleep_is_your_superpower?language=en) | (ted.com) [1:00]

**Hemingway quote**: [“There are only three sports: bullfighting, motor racing, and mountaineering; all the rest are merely games.”](https://www.goodreads.com/quotes/42427-there-are-only-three-sports-bullfighting-motor-racing-and-mountaineering) | (goodreads.com) [3:30]

**Matthew says you are more likely to get struck by lightning than to have the DEC2 gene mutation**: [Rare Genetic Mutation Lets Some People Function with Less Sleep](https://www.scientificamerican.com/article/genetic-mutation-sleep-less/)  | Katherine Harmon (*Scientific American*); (*National Geographic*) [12:00]

**Most people optimally need 7-9 hours of sleep every night**: [National Sleep Foundation’s sleep time duration recommendations: methodology and results summary](https://www.sleephealthjournal.org/article/S2352-72181500015-7/fulltext) |  (Hirshkowitz et al., 2015) [14:00]

**Evidence for how electrical lighting and the constructed environment is associated with reduced exposure to sunlight during the day, increased light exposure after sunset, and a delayed timing of the circadian clock as compared to natural light-dark cycle whilst camping**: [Entrainment of the human circadian clock to the natural light-dark cycle](https://www.ncbi.nlm.nih.gov/pubmed/23910656) (Wright et al., 2013) [15:30]

**Twins studies that looked at the DEC2 mutation**: [Study of twins discovers gene mutation linked to short sleep duration](https://aasm.org/study-of-twins-discovers-gene-mutation-linked-to-short-sleep-duration/) | ([aasm.org](https://aasm.org)) [16:45]

**Mice models with DEC2 mutation had shortened NREM and REM sleep phases (v. control)**:  [The Transcriptional Repressor DEC2 Regulates Sleep Length in Mammals](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2884988/) (He et al., 2009) [20:15]

**Rat studies looking at the impact of total vs. selective sleep deprivation**: [20:30]

- *Total sleep deprivation of rats until death in the 1983*: [Physiological correlates of prolonged sleep deprivation in rats.](https://www.ncbi.nlm.nih.gov/pubmed/6857280/) (Rechtschaffen et al., 1983) [1:17:15]
- *Selectively deprived rats of non-REM or REM*: [Sleep deprivation in the rat: X. Integration and discussion of the findings.](https://www.ncbi.nlm.nih.gov/pubmed/2648533) (Rechtschaffen et al., 1989) [1:20:15]

**Questionnaire to assess the likelihood that you have sleep apnea**: [Stop-Bang Questionnaire](https://stopbang.ca/osa/screening.php) | (stopbang.ca) [22:45]

**Animal studies showing that side sleeping allows the glymphatic system greater clearance capacity than any other sleeping position**: [The Effect of Body Posture on Brain Glymphatic Transport](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4524974/) (Lee et al., 2015) [25:45]

**Sleep’s effect on intimacy in relationships**: [28:00]

- *Lower testosterone in sleep deprived men*: [Effect of 1 Week of Sleep Restriction on Testosterone Levels in Young Healthy Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4445839/) (Leproult et al., 2011)
- *Sex drive in women… For every one hour of extra sleep that a female gets, they have somewhere between a 13 to 15% increase in the desire to be intimate with a partner*: [The impact of sleep on female sexual response and behavior: a pilot study.](https://www.ncbi.nlm.nih.gov/pubmed/25772315) (Kalmbach et al., 2015)

**Study that showed rocking promotes better sleep**: [Rocking like a baby promotes better sleep in adults](https://www.bbc.com/news/health-46986419) | Laurel Ives (bbc.com) [35:30]

**The bed cooling system Peter uses in the summer**: [chiliPAD Sleep System](https://www.chilitechnology.com/products/chilipad-sleep-system) | (chilitechnology.com) [41:50]

**Optimal ambient temperature for sleep is 65-67 degrees Fahrenheit**: [The ideal temperature for sleep](https://www.sleep.org/articles/temperature-for-sleep/) | (sleep.org) [42:15]

**Thermosuit studies showing skin temperature has a big impact on** ***quality*** **of sleep**:  [Skin deep: enhanced sleep depth by cutaneous temperature manipulation](https://academic.oup.com/brain/article/131/2/500/407617) | (Raymann et al., 2008) [42:15; 49:30]

**Study that found that holding the temperature constant and changing the humidity did not alter the sleep of the neonates**: [Influence of incubator humidity on sleep and behaviour of neonates kept at stable body temperature.](https://www.ncbi.nlm.nih.gov/pubmed/11683212) (Telliez et al., 2001) [51:15]

**The effect of altitude on sleep**: [Effects of High Altitude on Sleep and Respiratory System and Theirs Adaptations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3654241/) (San et al., 2013) [54:30]

**Drug that helps with altitude sickness**: [Diamox](https://www.webmd.com/drugs/2/drug-6753/diamox-oral/details) | (webmd.com) [56:00]

**Weighted blanket that people subjectively report improves their sleep**: [Gravity Blanket](https://gravityblankets.com) [56:45]

- Check out the [subscriber-only discount](https://peterattiamd.com/members/discounts/) on the Gravity Blanket

**Just 200 mg of caffeine at 7 AM can affect sleep that night**: [Caffeine intake (200 mg) in the morning affects human sleep and EEG power spectra at night.](https://www.ncbi.nlm.nih.gov/pubmed/7796154/) (Landholt et al., 1995) [1:00:00]

**Sex with a partner and masturbation may produce better quality of sleep**: [Sex and Sleep: Perceptions of Sex as a Sleep Promoting Behavior in the General Adult Population](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6409294/) (Lastella et al., 2019) [1:04:00]

**From the Dickensian era, the sleep model called “Two Sleeps” or “First and Second Sleep”**: [Humans Used to Sleep in Two Shifts, And Maybe We Should Do It Again](https://www.sciencealert.com/humans-used-to-sleep-in-two-shifts-maybe-we-should-again) | MELINDA JACKSON AND SIOBHAN BANKS (sciencealert.com) [1:07:00]

**Episode of The Drive discussing HRT for women after menopause**: [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) | Peter Attia (peterattiamd.com) [1:23:00]

**Menopause and sleep difficulty**: [1:24:30]

- [Sleep problems during the menopausal transition: prevalence, impact, and management challenges](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5810528/) (Baker et al., 2018)
- [Sleep Disorders in Postmenopausal Women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4621258/) (Jehan et al., 2015)

**Breathing technique that Peter has heard mixed reviews about but could improve sleep**: [Wim Hof Method](https://www.wimhofmethod.com/practice-the-method) | (wimhofmethod.com)[1:29:15]

**Questionnaire to assess the likelihood that you have sleep apnea**: [Stop-Bang Questionnaire](https://stopbang.ca/osa/screening.php) | (stopbang.ca) [1:36:00]

**Find yourself a board certified sleep medicine doctor**: [Find a Sleep Facility Near You](https://sleepeducation.org/find-a-facility) | (sleepeducation.org) [1:36:00]

**Untreated sleep apnea will shorten lifespan and healthspan**: [Obstructive Sleep Apnea and Hallmarks of Aging](https://www.cell.com/trends/molecular-medicine/pdf/S1471-4914(17)30105-3.pdf) (Gaspar et al., 2017) [1:36:00]

**Men are at least twice as likely as women to have obstructive sleep apnea**: [Gender Differences in Obstructive Sleep Apnea and Treatment Implications](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2642982/) (Lin et al., 2018) [1:39:45]

**4% ODIs is a really significant predictor of mortality**: [Prognostic importance of novel oxygen desaturation metrics in patients with heart failure and central sleep apnea](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5276717/) (Watanabe et al., 2017) [1:40:40]

**App that allows you to listen back to your snoring during the night**: [SnoreLab](https://www.snorelab.com/) | (snorelab.com) [1:43:45]

**The UK government very recently released some guidelines as to how much sleep is necessary**: [Government To Issue Sleep Guidelines](https://sleepcouncil.org.uk/government-to-issue-sleep-guidelines/) | (sleepcouncil.org.uk) [1:46:45]

**Increase in heart attacks the day following daylight savings time**: [Daylight savings time and myocardial infarction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4189320/) (Sandhu et al., 2014) [1:48:45]

**One night of four hours of sleep can drop your natural killer cell count on average by about 70%**: [Partial sleep deprivation reduces natural killer cell activity in humans.](https://www.ncbi.nlm.nih.gov/pubmed/7871104) (Irwin et al., 1994)  [1:49:15]

**For more on the pitfalls of epidemiology see**: [Studying Studies: Part II – observational epidemiology](https://peterattiamd.com/ns002/) | Peter Attia (peterattiamd.com) [1:50:45]

**Evidence from studies examining the effects of acute sleep deprivation among healthy samples suggests acute sleep deprivation (i.e., 24 hour period minimum) increases depressive and anxiety symptoms**: [A Test of the Effects of Acute Sleep Deprivation on General and Specific Self-Reported Anxiety and Depressive Symptoms: An Experimental Extension](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2862829/) (Babson et al., 2010) [1:51:30]

**Animal model sleep studies in which sleep-deprived rats receive adrenalectomy reveal neuroprotective and transcriptional responses to sleep (and lack thereof) irrespective of corticosterone (i.e., hypothalamic-pituitary axis (HPA)**: [Separating the Contribution of Glucocorticoids and Wakefulness to the Molecular and Electrophysiological Correlates of Sleep Homeostasis](https://academic.oup.com/sleep/article/33/9/1147/2454539) (Mongrain et al., 2010) [1:52:30]

**Rebound insomnia from antihistamines and benzos**: [Rebound insomnia: a critical review.](https://www.ncbi.nlm.nih.gov/pubmed/2567741) (Gillin et al., 1989) [1:54:00]

**American College of Physicians now say sleeping pills must no longer be the first line recommendation for insomnia and it should instead be Cognitive Behavioral Therapy for Insomnia (CBTI)**: [ACP Recommends Cognitive Behavioral Therapy as Initial Treatment for Chronic Insomnia](https://www.acponline.org/acp-newsroom/acp-recommends-cognitive-behavioral-therapy-as-initial-treatment-for-chronic-insomnia) | (acponline.org) [1:54:45]

**Peter and Matt spoke about CBD in the previous episodes**: [1:55:15]

- [Episode #49 with Matt](https://peterattiamd.com/matthewwalker3/) ⇒ *The efficacy of THC and CBD as sleep aids [1:05:30]*
- The first [AMA episode with Matt](https://peterattiamd.com/matthewwalkerama/) ⇒ “*Can CBD and THC be used for sleep? [1:39:30]*”)

**Trauma dreams from PTSD disrupt sleep**: [Sleep Disturbances as the Hallmark of PTSD: Where Are We Now?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4197954/) (Anne Germain, 2013) [1:57:15]

**Using sound and beats to improve sleep and memory**: [1:58:00]

- [Memory Improvement via Slow Oscillatory Stimulation during Sleep in Older Adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4523433/) (Westerberg et al., 2015)
- [Boosting slow oscillations during sleep potentiates memory](https://nature.com/articles/nature05278) (Marshall et al., 2006)

**Effect of fasting during Ramadan on sleep**: [Sleep during Ramadan intermittent fasting.](https://www.ncbi.nlm.nih.gov/pubmed/11903862) (Roky et al., 2001) [2:00:30]

**Data on time restricted feeding suggests an early window is better**: [Early Time-Restricted Feeding Improves 24-Hour Glucose Levels and Affects Markers of the Circadian Clock, Aging, and Autophagy in Humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6627766/) (Jamshed et al., 2019) [2:01:45]

§

## People Mentioned

- [Ernest Hemingway](https://en.wikipedia.org/wiki/Ernest_Hemingway) [3:30]
- [David Beckham](https://en.wikipedia.org/wiki/David_Beckham) [8:45]
- [Margaret Thatcher](https://en.wikipedia.org/wiki/Margaret_Thatcher) (boasting about not needing sleep) [12:30]
- [Ronald Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) (boasting about not needing sleep) [12:30]
- [Donald Trump](https://en.wikipedia.org/wiki/Donald_Trump) (boasting about not needing sleep) [12:30]
- [Bob Kaplan](https://twitter.com/bobkaplan?lang=en) [58:15]
- [Thomas Edison](https://en.wikipedia.org/wiki/Thomas_Edison) (electric light may have screwed up our natural bedtime) [1:08:00]
- [Robert Redford](https://en.wikipedia.org/wiki/Robert_Redford) (Matt’s “dad”) [1:19:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/04/matthew-walker-image-2x1-500x500.jpeg)

##### Matthew Walker, Ph.D.

Dr. Walker earned his degree in neuroscience from Nottingham University, UK, and his PhD in neurophysiology from the Medical Research Council, London, UK. He subsequently became a Professor of Psychiatry at Harvard Medical School, USA. Currently, he is Professor of Neuroscience and Psychology at the University of California, Berkeley, USA. He is also the founder and director of the Center for Human Sleep Science.

Dr. Walker’s research examines the impact of sleep on human health and disease. He has received numerous funding awards from the National Science Foundation and the National Institutes of Health, and is a Kavli Fellow of the National Academy of Sciences.

Dr. Walker is the author of the International Bestseller, Why We Sleep. It has a singular goal: to reunite humanity with sleep.

In addition, Dr. Walker is an internationally recognized [speaker](https://www.sleepdiplomat.com/speaker), a successful [entrepreneur](https://www.sleepdiplomat.com/entrepreneur), and a Sleep Scientist for Google.

[sleepdiplomat.com]

**Twitter**: [@sleepdiplomat](https://twitter.com/sleepdiplomat?lang=en)

**Center for Human Sleep Science**: [https://www.humansleepscience.com/](https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s)

**Matthew’s publications**: <https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s>