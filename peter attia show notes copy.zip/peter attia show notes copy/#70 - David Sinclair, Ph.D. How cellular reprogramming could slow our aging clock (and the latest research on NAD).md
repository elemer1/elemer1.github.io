# #70 – David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)

**Source:** [https://peterattiamd.com/davidsinclair2/](https://peterattiamd.com/davidsinclair2/)

---

In this episode, David Sinclair, Ph.D., a Professor in the Department of Genetics at Harvard Medical School and co-Director of the Paul F. Glenn Center for the Biological Mechanisms of Aging, returns to the podcast to discuss the content of his new book, [*Lifespan: Why We Age – and Why We Don’t Have To*](https://www.amazon.com/Lifespan-Why-Age_and-Dont-Have/dp/1501191977). This conversation focuses on the biological mechanisms involved in what David terms the Information Theory of Aging which provides insights into the “clock” that determines our aging and to what degree it can be manipulated. Our discussion on aging of course leads us into interconnected topics of epigenetics, sirtuins, cellular senescence, as well as what compounds David is personally taking for his own longevity. Additionally, we discuss the most up to date information related to NAD and longevity by looking at the potential benefits (if any) of supplemental agents (NAD precursors, NR, NMR, etc.) that pose a promise of increasing NAD.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/davidsinclair2/the_Drive_public.png)

Play

#70 - David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)

#70 - David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)

1x15s30s

0:002:10:15

## We discuss:

- SIR genes and cellular identity [8:45];
- Sirtuins regulate gene expression [14:30];
- DNA is methylated at the deepest layer of the epigenome [17:45];
- Methylation pattern and determining cellular age [20:15];
- Cellular reprogramming [33:45];
- Yamanaka factors to push cells “back in time”  [41:00];
- Human cellular reprogramming viability [57:00];
- Measuring the rate of aging [1:02:45];
- Cellular reprogramming for longevity [1:14:45];
- Compounds David takes for his own longevity [1:29:15]
- NAD precursors (NR, [NMN](/does-nmn-improve-metabolic-health-in-humans/)) and pterostilbene [1:40:00];
- The current field of sirtuin activators [2:03:15];
- David’s artistic work [2:05:15] and;
- More.

§

## Show Notes

## SIR genes and cellular identity [8:45]

*The SIR gene – silent information regulator – is a gene that controls other genes*

- One of the roles it is most well-known for, is its implication in longevity:  In a [study](https://www.ncbi.nlm.nih.gov/pubmed/10521401) by Matt Kaeberlin Sir2 was shown to control the aging process in yeast
- The gene group’s primary roles are to:
  - Silence other genes
  - Repair damaged DNA

*The SIR enzyme is the master regulator of this cellular survival circuit*

- The SIR gene cannot silence other genes and serve a cellular repair function at the same time
  - silenced genes are temporarily “turned on” while the damage is repaired by the enzyme protein
  - “turned on” genes help with the repair
  - the protein then returns to its “silencing post”

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-1-sinclair2-1024x911.png)

**Figure 1. When SIR enzyme proteins detect stress in the cell (e.g. DNA breakage) the protein leaves the silent region to go and repair the DNA. When the problem is fixed, it returns to its original post, silencing genes.** Image credit: ([Alves-Fernandes and Jasiulionis, 2019](https://www.mdpi.com/1422-0067/20/13/3153))

*Overtime, in the back-and-forth of repair…  SIR genes lose track of which genes should be silenced or not*

- In aging yeast, the loss of cellular identity results in a [sterility phenotype](https://www.cell.com/fulltext/S0092-8674(00)81038-7)
- With age, our cells lose their “program” but early evidence in mice suggests that the original “hard disk program” can be recovered; restored to the original programming

> “We have some early evidence from mice that we can actually find that hard disk drive and reinstall the software so that it’s pristine again and we find that we can actually improve the health quite dramatically in parts of a mouse’s body.” — David Sinclair, Ph.D

*What does Claude Shannon’s Information Theory of Communication have to do with aging?…*

- In his [1940 paper](https://www.math.harvard.edu/~ctm/home/text/others/shannon/entropy/entropy.pdf), mathematician Claude Shannon presented his Information Theory of Communication
- He presented how to encode information and make sure that information gets to the receiver

- Shannon figured out how to preserve information: make a repository and reset the system

## Sirtuins regulate gene expression [14:30]

- In the embryo, cells begin the same, but the pattern of gene expression creates different cell types
- Genes are made up of DNA that express protein in a certain way and selected genes are turned on
- The selective gene activity allows for cell differentiation (e.g., it is why an epithelial cell is different to a liver cell)

*SIR proteins maintain the structure of a cell’s DNA*

- Spooled DNA won’t be read by the cell
- If a cell needs to read the gene, SIR proteins will be removed and the bundle will open

*There are layers of spooled DNA; the Epigenome*

- The superficial layer: SIR transient proteins, transcription factors turn genes on and off to be read
- One level below are histones, which chemically modify the spooling proteins
- The deepest layer is where DNA is methylated
  - Attaching a methyl group to an end of the DNA makes it so the gene is not expressed
  - Some genes in a cell are never turned on

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-2-sinclalir2.png)

**Figure 2. Layers of epigenome. Genome function and cellular phenotypes are influenced by DNA methylation and the protein-DNA complex known as chromatin.** Image credit: ([The NIH Roadmap Epigenomics Mapping Consortium, 2010](https://www.researchgate.net/figure/Layers-of-genome-organization-Genome-function-and-cellular-phenotypes-are-influenced-by_fig1_47415477))

## DNA is methylated at the deepest layer of the epigenome [17:45]

- Attaching a methyl group to an end of the DNA makes it so the gene is not expressed
- Methyl groups on DNA within a genome is the underlying code that tells the cell what type it is

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-3-sinclair2-1024x678.png)

**Figure 3. One of the carbons on the methyl group attaches to a carbon on one of the ends of DNA. The addition of the methyl group inhibits DNA expression.** Image credit: [British Society of Cell Biology](https://bscb.org/learning-resources/softcell-e-learning/epigenetics-its-not-just-genes-that-make-us/)

*Waddington’s metaphor for epigenetics*

- [Conrad Waddington](https://www.amazon.com/Strategy-Genes-Routledge-Library-Editions-dp-1138998133/dp/1138998133/ref=mt_paperback?_encoding=UTF8&me=&qid=) used a fertilized egg rolling down a hill and landing in a valley – thus becoming a certain kind of cell – as a metaphor for what was to become understood as epigenetics
  - The embryo can roll down this mountain and become any cell
  - The cells go down into valleys that determine the fate of the cell (i.e., differentiation)
  - They settle into valleys, and this is how cells know what they are

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-4-sinclair2-1024x743.png)

**Figure 4. Waddington’s Landscape.** Image Credit: [Waddington, 1957](https://www.amazon.com/Strategy-Genes-C-H-Waddington/dp/1138017310)

## Methylation pattern and determining cellular age [20:15]

*With age, cells lose their patterns of gene expression…*

- It’s as though the marbles start to drift into other valleys
- Methyl groups accumulate over time, get removed in certain places, or appear in different places on the DNA genome
  - DNA breaks, SIR proteins reorganization and cells can revert back to other kinds of primordial (e.g. skin, liver) cells
  - The cell ‘nature’ changes and its ‘identity’ becomes blurry

⇒ In one of [David’s talks](https://forum.frontiersin.org/david-sinclair-cracking-reversing-aging), he depicts “epigenetic noise” (10:30)

> “it appears very much like a loss of information and interruption and noise because these methyl groups that are laid down in a pristine precise fashion when we’re young, there are other methyls that accumulate over time in different places. What appears to be randomly so it’s a loss of the original pattern. That’s why we talk about entropy.” -David Sinclair, Ph.D

- The compact disc (CD) that is our genome gets scratched overtime (noise) such that cells don’t read the right genes (the epigenome) at the right times

*There is evidence that cells retain an original copy of the CD; a copy of the original placement of methyl groups on the epigenome*

- David’s lab can program cells to “go young again” by correcting the methylation pattern within a cell’s genome
  - Hitting the cellular reset button to read the right pattern of methyl groups
  - The cell becomes like a stem cell – Yamanka gene reprogramming factors are pre-embryonic cells with fewer methyl groups
  - The DNA spools get reset with the original methylation pattern within the epigenome
  - Results in a younger phenotype and the mouse’s chronological age is also younger

> “But what I think exists in cells and we have some evidence is that, like Shannon suggested for the internet or information, is that if you have a backup copy… and now going back to the genome… there seems to be something in cells that tells them these methyl groups, the programs that were laid down when you were a baby are still there and cells can access that somehow to say: ‘All these other things that have happened since you were born or since you were a teenager, that’s just noise… Ignore that.’” -David Sinclair, Ph.D

*‘Carbon dating’ a cell on the basis of methylation pattern*

- Cellular aging begins at conception and methylation pattern reveals a cell’s age
- Determining chronological age has a 95% fidelity from a blood sample
- This cellular ‘clock’ known as the [Horvath Clock](https://en.wikipedia.org/wiki/Epigenetic_clock) tells you how fast you are aging
  - The rate can change depending on lifestyle; known mechanisms to increase rate (e.g. smoking) or slow aging (e.g. exercise, caloric restriction)
    - When fasting, mechanisms turn on sirtuins – implicated in longevity
    - NAD levels increase and sirtuins have more substrate to repair DNA and keep genes in the epigenome that should be silent, silent (i.e. retain cellular identity)
- [Telomeres](https://en.wikipedia.org/wiki/Telomere) have formerly served as a pretty good clock for chronological age but are not as accurate as the Horvath Clock
- Different tissues divide at different rates
- They are not immutable: [A study](https://www.nature.com/news/astronaut-twin-study-hints-at-stress-of-space-travel-1.21380) – that compared the telomeres of twins, one of which spent a period of time in space – revealed that telomere health reversed within 2-3 days after being back on earth
- Conversely, a recently [published paper](https://www.ncbi.nlm.nih.gov/pubmed/28198702) exemplified the clock’s accuracy: the calculated cellular age matched the patient’s medical records (rather than the individual’s lifestyle recollection)

*The Horvath clock uses machine learning to read methyl groups on a gene* *to determine age*

- A published [universal clock](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4015143/) can use the location of methyl groups – irrespective of cell type – and determine the age (of a mouse)
- David and his colleagues in the field can determine how long a methyl group has been at a given locate on the genome

> “There isn’t a program that tells us we must age…but there are processes like I was describing about movement of these SIR proteins in yeast, and movement in mammals like us, that leads to a predictable change on our genome that changes the way genes are switched on and off as we age in very precise locations.”  -David Sinclair Ph.D

- Aging is not a genetic program but processes like the movement of SIR proteins provide predictable patterns of change to the genome
- Genes are switched on and off as we age in very precise locations

## Cellular reprogramming [33:45]

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-5-sinclair2-1024x574.png)

**Figure 5. This cartoon depicts turning back the aging clock through cellular regeneration of progeria mice.** Image credit: [Juan Carlos Izpisua Belmonte Lab/Salk Institute](https://www.salk.edu/scientist/juan-carlos-izpisua-belmonte/))

- The stored copy a cell keeps of the original methyl group placements on a gene allows it to reset itself; reprogram itself
- The [Belmonte lab](https://www.salk.edu/scientist/juan-carlos-izpisua-belmonte/publications/) showed that if a cell is reprogrammed and too quickly, it will become tumorous
- David’s lab does “[partial reprogramming](https://www.cell.com/fulltext/S0092-8674(16)31664-6)”: the cell regains its youth but does not lose its identity
  - Every cell has a master copy to reprogram itself back to a youthful, original state
  - The reset is intrinsic to each cell (a neighboring cell could not be reset next to a reprogrammed cell, for example)

> “What I mean by reprogramming is that we can use technology that we use now to generate stem cells, but to partially reprogram them so that they turn on the youthful pattern of genes that we once had ,that we know we lose. There is no question, as we get older our cells don’t turn on the genes that they once did when they were young. And genes that should be on when you young get switched off. So we lose that. That’s that noise. Genetic noise I call it. Reprogramming somehow resets that pattern.” -David Sinclair Ph.D

- As we get older, genes that were once bundled by SIR proteins and methylated DNA become undone and read by the cell
- Reprogramming signals the cell in the dysfunctional region to re-package: place SIR proteins where they once were, add or remove methyl groups, and switch the gene off again
- Shannon’s backup disc is called the observer: it keeps the original signal (or copy of the original program) and the receiver sense checks the transmission

*As we age, our DNA is largely intact…*

- We haven’t lost genes due to mutations, as believes in the 1950s
- The information is there but cells don’t know whether to read it or spool it up and hide it away

*The methylation clock – the deepest level of the spooled DNA epigenome – is very hard to reverse*

- Interventions such as rapamycin, NAD booster, Metformin – impact the superficial layer where transcription factors singal which genes to be read or not – [slow down aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5943638/) but they cannot reverse it
- They can change the rate but not the direction [of aging]
- Cellular aging reversal – at the level of DNA methylation and chemical modification of proteins – is achieved with stem cell technology reprogramming factors; [Yamanaka Genes](https://en.wikipedia.org/wiki/Induced_pluripotent_stem_cell)

## Yamanaka factors to push cells “back in time”  [41:00]

David’s lab, alongside the labs of [Bruce R. Ksander](https://eye.hms.harvard.edu/bruceksander) and  [Zhigang He](https://www.hms.harvard.edu/dms/neuroscience/fac/He.php),  use the eye as a model tissue to reset youthful gene expression

**⇒ Experiment Deepdive** : [Mice retinal cell reprogramming](https://www.biorxiv.org/content/10.1101/710210v1)

- Three  of the Yamanaka genes were packaged into [AAV (adenovirus vectors)](https://en.wikipedia.org/wiki/Adeno-associated_virus)
- The genes were given a [doxycycline antibiotic](https://en.wikipedia.org/wiki/Doxycycline) on/off switch (the gene can be silenced with the antibiotic)
- The fourth Yamanaka, [myc gene](https://en.wikipedia.org/wiki/Myc) was excluded – an oncogene that causes cancer, which turned out not to be necessary in order to reprogram cells to be partially young again
- Three scenarios were tested:

1. A young mouse with a traumatized optic nerve
2. Pressure-treated mouse to create a glaucoma
3. An old mouse with natural vision loss
   1. vision was measured by electrical signal in the visual cortex and observing the mouse’s response to moving lines

- Yamanaka genes in the virus vector were turned on after loss of vision occurred (the treatment needs to reverse and not just prevent the damage)
- Results:
  - Nerves were regenerated in all three experiments
  - Vision was restored in mice with glaucoma and age-related vision loss
- The AVV treatment mechanism:
  - The AVV contains genes that specify the cell during embryogenesis
  - A Horvath nerve cell clock was used to determine and restore methylated pattern of genes during early development for such cells
- Nerve cell methylation patterns of young and old mice were compared
  - Could determine which retinal genes were on/off in younger mice cells compared to older mice
  - Young mice have genes for taste in retinal cells, hypothesized to be relevant for chemical signaling
- When the retina was reprogrammed, genes that went down with aging proportionally corrected:
  - Genes that went way down with age went way back up
  - Genes that went a little bit down with age went a little bit back up
  - One prediction would be that chemical changes map to genes that incur a change with age
- David’s lab have identified hypersensitive regions in the epigenome in response to stress (broken DNA, UV damage)
  - Once the DNA unspooled, or opened and methyl groups have been added/removed in the wrong places, the structure remains that way unless reprogrammed
  - Evidence for epigenetic noise in a cell
- AVV technological limitations:
  - How many of the cells can receive the virus vector?
  - If the cell does not get the virus, it will not get reprogrammed (i.e reprogramming is binary and cell-specific)
  - AVVs cannot be delivered to every cell in a mouse, but that may not be necessary
  - *What cells in the human body can be reprogrammed?*

- - *The retina can be restored, the optic nerves re-grown, but it is unknown how much of the animal can be reprogrammed*

- Retinal case study advantages:
  - The retina has FDA approved drugs for viral delivery
  - The eye is insensitive to the rest of the immune system
  - A lot of  AVV can be delivered to the optic nerve

## Human cellular reprogramming [57:00]

*The obstacle is not getting to the patient but producing the virus*

- Although Peter votes that David’s lab work with the prostate tissue next, other tissues have more of an acute for reprogramming if something goes wrong (e.g. loss of vision, heart failure)
- David’s lab has a hypertrophy mouse model for reprogramming experimentation

*There is a large interest in gene therapy…*

- There is a high demand for making adenoviruses, creating both a long wait time and inflated costs
- There is a lot of promise in the gene therapy research area and also a lot of potential economic gain
- Where gene therapy used to be avoided (thought to be risky, dangerous), it is now a notable field for financial investment
- The virus vectors used today are different types of viruses to those used in previous research from decades before
- Viruses used today cannot integrate into the genome and cause mutation (cancer) or cause negative immune reactions

*Single cell gene mutations are primed for gene therapy* *(e.g. sickle cell anemia, thalassemia, cystic fibrosis)…*

- There are active [clinical trials](https://clinicaltrials.gov/) for patients with obvious candidate genes – it won’t be long before these diseases are correctable
- But there is a cost barrier (e.g [Spark Therapeutics](https://sparktx.com/) drug that treats retinal degeneration)
  - One potential model: The cost of treatment is paid out as future earnings of the individual whose health was restored by treatment (tied to gain in productivity)

## Measuring the rate of aging [1:02:45]

*Can the clock be used to measure the effectiveness of ‘drugs’ (i.e. fasting, rapamycin)?*

- *To evaluate the extent to which methylation and epigenetic changes in DNA occur*
- To study the (directional) rate of change
- There are companies that now [provide service](https://www.the-scientist.com/news-analysis/company-sells-a-biological-age-kit-31143) to ‘read’ DNA methylation age

⇒ **Example**: Every six months to a year, take a ‘snapshot’ of the universal (cellular) Horvath clock, save a blood sample to “look back in time” and see the rate of change (cellular aging)

*Cellular senescence is a ‘hallmark’ of aging*

- DNA damage that occurs with chronological age results in [senescent cell](https://www.nature.com/subjects/senescence) accumulation
- In early stages of aging: epigenetic noise and the loss of cellular identity
- In the end stages of aging: the cell stops dividing but don’t die – they become senescent
  - DNA damage at telomeres is notably persistent and highly efficient in inducing senescence and/or apoptosis
  - An important mechanism to prevent cancer proliferation, cells send out chemical signals and disrupt the epigenome

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-6-sinclair2-1024x1024.png)

**Figure 6. The Hallmarks of Aging.** Image Credit: ([López-Otín, et al., 2013](https://www.cell.com/cell/fulltext/S0092-8674(13)00645-4?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867413006454%3Fshowall%3Dtrue))

For more on the different hallmarks of aging: check out a [previous episode of The Drive](https://peterattiamd.com/davidsinclair/) when David was first on the show (specifically starting at 1:14:14)

*Senescent cells could be part of the cause for loss of cellular identity as we age…*

- Contributes to epigenetic interference and DNA methylation of surrounding cells
- Other senescent cells make surrounding cells senescent or tumorigenic
- In [one study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6082705/), implanted senescent cells in mice induced signs of premature aging, such as higher blood sugar

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-7-sinclair-2-1024x926.png)

**Figure 7. Cellular senescence and altered intercellular communication. n young organisms, cellular senescence prevents the proliferation of damaged cells, thus protecting from cancer. In old organisms, the pervasive damage and the deficient clearance of senescent cells result in their accumulation and contribution to aging.** Image credit:  ([López-Otín, et al., 2013](https://www.cell.com/cell/fulltext/S0092-8674(13)00645-4?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867413006454%3Fshowall%3Dtrue))

*A little senescence goes a long way…*

- Senescent cells in the fat of mice or human models of different ages, stained with senescence-associated [β-galactosidase](https://en.wikipedia.org/wiki/Beta-galactosidase) (SABG) for identification
  - Older fat is packed with senescent cells (fat stain is dark blue)
- The phenotypic identification of a senescent cells
  - The most reliable phenotype of senescence is SABG; cells turn blue when stained
  - Other genes that signal DNA damage and stop cancer by telling cells to stop replicating, turn on (e.g. [p16](https://en.wikipedia.org/wiki/P16), [p21](https://en.wikipedia.org/wiki/P21))
    - One [fluorescent mouse model](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3718011/) made by [Ned Sharpless](https://en.wikipedia.org/wiki/Norman_Sharpless) was under the control of the p16 gene
    - When a tissue got stressed the fluorescent signal came on
  - There is no definitive way to identify senescence in a tissue (although SABG is most reliable)

*It is not known how to reverse senescence, even with cellular reprogramming…*

> “So, we’ve got a pretty badly scratched CD that we can polish with reprogramming, but if you’ve gouged it so deep [senescent cells] that even reprogramming can’t work, then we need something else probably.” -David Sinclair, Ph.D

- The pre-senescent loss of cellular identity is reversible (mouse model retinal cell experiment results)
- In theory, it should be possible to get a senescent cell to replicate again if its DNA is in tact

## Cellular reprogramming for longevity [1:14:45]

*The ideal application for longevity and not just disease treatment…*

- A reactive tool to respond to aging phenotypes in specific tissue cells
  - Most imminent application that we will see within the decade, to address different disease types
  - One limitation is that the AVV does not infiltrate every cell in the body evenly (liver cells are favoured)
  - Different AVV protein variations are used for different parts of the body (e.g. AAV9 is good for muscle cells)

- Reprogramming also holds the possibility to globally ‘turn back the clock’ by restoring pre-embryonic methylation patterns in all cells
  - Reprogramming treatment will move away from being tissue-specific
  - *Is there theoretically an argument for cellular immortality?*

- - Cells lose genetic information but epigenetic information (the backup drive) remains in tact
  - The information lost in genetic information (the gauging of the CD) may limit cellular eternal lifespan (immortality)

> “I think the problem with what I’m calling the information theory of aging, which is what I wrote about in my book, is that we do lose information. Every cell does experience mutations. It’s not perfect…and so ultimately, if you’re a thousand years old, you may have lost a lot of the genetic information. But epigenetic information, because there’s this backup drive, this observer, that we have found exists in cells somehow, that you can tap into, as long as the genome, the DNA strands, are still largely intact, we can reverse aging.” -David Sinclair, Ph.D

*What the future could hold…*

- A couple of years ago, David did not think it was possible to extend human life to 200 years
  - If vision can be restored (retinal cellular reprogramming), than other parts of the body can be restored, too
  - Even if reprogramming does not work for senescent cells for which too much genetic information has been lost, then perhaps they can be deleted
  - Tissues can be regrown and replaced from another organism or in a dish
- David is optimistic about not just being able to slow cell aging, but actually having cells go back in time.. ‘Turning back the clock’…
- The optionality play: further advancements will be available to extend life even beyond the possibilities of today (once, say, a person reaches 200 years old)
- David proposes the following image for what the aging process may look like:

> “…a lifestyle where you’re monitoring yourself with devices, devices tell you what to eat, when to eat, if you want to pay attention, you don’t have to listen, but when there’s a problem, you’re notified. You’ve got a tumor somewhere in your body, we’ve detected it, go have that killed before it grows. That’s going to be 20 years ahead of what we can do now for patients. That’ll keep you young and healthy for a lot longer.” -David Sinclair, Ph.d

*Current global trends in life expectancy …*

- Up until about 2015, life expectancy was increasing at about 0.4% per year but has started to crest
- Lifestyle choices (eat, stress, exercise) has recently slowed the global increase in life expectancy
- But the average lifespan is increasing at the ‘top end’ (i.e. countries with the longest life expectancy, like Japan)

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-8-sinclair2.jpg)

**Figure 8. Average life expectancy of Japan continues to increase.** Image Credit: [roperld.com](https://www.roperld.com/science/LifeExpectancyUS.htm)

> “But to really go beyond that [maximum ages up to 120 years old], I think you need something really new, and that’s why I’m a lot more optimistic than I was, having seen what reprogramming has in terms of potential to be able to not just slow the clock down, which is inexorable, seemingly inexorable, but now actually get cells to go back in time.”  -David Sinclair, Ph.d

Genetics/epigenetics of centenarians, gene sequencing, CETP-VV, Lp(a): check out a [previous episode of The Drive](https://peterattiamd.com/nirbarzilai/) with Nir Barzilai (specifically starting at 1:49:15)

## Compounds David takes for his own longevity [1:29:15]

*Metformin and Rapamycin (and exercise)*

- One of Metformin’s main effects is mitochondrial inhibition, which elicits an upregulated response to make more
- Blunting mitochondria production may not be the best for exercise and recovery
- Peter writes about Metformin and exercise dynamics [here](https://peterattiamd.com/metformin-and-exercise/)

*A clear theme: Pulse your biological stress*

> “Put your body in a state of anxiety or fear, adversity, but you don’t want to do it all the time. Your body needs a chance to recover.” -David Sinclair, Ph.D

- Although not proven, David suggests that it may be best to alternate Metformin and exercise (by day), to let the body recover
- David does not take metformin regularly
  - Only if he feels good
  - When he is traveling and knows he will not be exercising
- Along the same lines, David wouldn’t take Rapamycin (which signals to the cell not to grow) while exercising
  - David doesn’t take rapamycin regularly
  - Peter doesn’t take rapamycin or metformin while fasting >24h

*David takes resveratrol every morning (does not take it in pulsatile doses)…*

- He takes a gram with dietary fat, like yogurt
- He doesn’t have any negative effects
- It is not as powerful as rapamycin but it does extend the lifespan of a mouse on a western diet
- This [mouse study](https://www.ncbi.nlm.nih.gov/pubmed/17086191) reported that fat mice taking resveratrol were healthier and lived longer than those that didn’t take the compound
- Similar to metformin, rapamycin seems to be beneficial in metabolically unhealthy individuals but if health is otherwise optimized, there is not as much benefit
- The first Interventions Testing Program [(ITP) study on resveratrol](https://www.ncbi.nlm.nih.gov/pubmed/20974732) showed treatment of resveratrol (at 50 and 200 mg/kg), beginning at 12 mo of age, did not have significant effects on survival in wild-type (WT) male or female mice
- David’s lab has new, unpublished data on resveratrol benefits for old, unhealthy mice
  - Two doses of either  24 mg per kg and 240 mg per kg both extended lifespan
  - The lower dose was just as effective but the higher dose kept the mice from gaining weight

⇛ For more on resveratrol: check out a [previous episode of The Drive](https://peterattiamd.com/davidsinclair/) when David was first on the show (specifically starting at 43:00)

*One amino acid change blocks the resveratrol plant molecule…*

- A debated [2013 study](https://www.ncbi.nlm.nih.gov/pubmed/23471411/) found that a SIRT1 mutation blocked resveratrol from activating the sirtuin enzyme
  - It held true that resveratrol would not work with the SIRT1 genetic mutation
  - The mutation made a protein enzyme that could not bend and therefore, resveratrol could not activate it
- The new experiment in David’s lab takes a mouse with the protein enzyme mutation (missing an amino acid) that renders it immune to the effects of resveratrol
  - The original [2006 study](https://www.ncbi.nlm.nih.gov/pubmed/17086191) of mice with a high-fat diet with/without resveratrol administered and with/without the resveratrol immunity mutation
  - The study confirmed that resveratrol extends lifespan by activating SIRT1

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-9-sinclair2-1024x757.png)

**Figure 9. Mechanism of Sirt1 activation by resveratrol. Downstream of AMPK, an increase in NAD + levels leads to SIRT1 activation, which promotes beneficial metabolic changes primarily through deacetylation and activation of PGC-1α.** Image Credit: ([Pacholec et a`l., 2010](https://www.ncbi.nlm.nih.gov/pubmed/20061378))

## NAD precursors (NR, NMN) and pterostilbene [1:40:00]

*Why are NAD levels important?*

- [Nicotinamide adenine dinucleotide](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) (NAD) is a coenzyme found in all cells
- One of the oldest and most important molecules for life
- NAD exists in two forms: NAD+ (oxidized form) and NADH (reduced form)
- NADP, NADH don’t activate sirtuins, only NAD+ will do that
- Sirtuins (protectors of the epigenome) lose their activity overtime and require two things for maximum activity:
  - An accelerator (i.e. resveratrol)
  - A fuel, or substrate (ie. NAD)
- We now know NAD levels fluctuate and go down with age

*In humans, is more NAD better? (i.e. Does more NAD extend lifespan?)*

- In animal models, [more NAD is better](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6342515/) (the more there is, the longer the lifespan)
- The idea is that by replacing or boosting NAD, cellular defense and DNA repair is upregulated

- It could be that the less healthy someone is, the more they will benefit from more NAD – like is the case for supplementing with metformin, resveratrol
  - In studies, the benefits of NAD and resveratrol are seen in obese subjects or older mice that were given a NAD boost
  - [In one study](https://www.sciencedirect.com/science/article/pii/S0092867418301521), young mice that were given a NAD boost did not run further but they did if a boost and exercise was administered at the same time

*Supplementing (boosting) NAD…*

- In humans and mice, there have been few studies of taking NAD orally but subjects have been given NAD precursors
- Most take NAD intravenously (IV) but there is evidence that [cells don’t take up NAD directly](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(18)30196-7)
  - it first needs to get broken down and then reconstituted once inside of a cell
  - There is not convincing evidence that IV NAD makes it into the cell (from plasma)
  - NAD goes up and down not only in the cytoplasm but also in the mitochondria
  - NAD is made de novo in the cell, but you don’t get to shuttle NAD between cell

*Nicotinamide Riboside (NR) is a NAD precursor…*

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-10-sinclair2-1024x686.png)

**Figure 10. NAD precursors (vitamin B3 forms).** Image credit: ([Poljsak and Milisav, 2018](https://www.sciencedirect.com/science/article/abs/pii/S0924224417303552))

- [Nicotinamide riboside](https://en.wikipedia.org/wiki/Nicotinamide_riboside) (NR) is partly a piece of B3 and a piece of DNA
- NR becomes NAD in two steps:
  - A cell uptakes the NR molecule and a phosphate group is attached, becoming [NMN](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide)
  - NMN then becomes NAD

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-11-sinclair2-1024x510.jpg)

**Figure 11. Nicotinamide mononucleotide (NMN) and nicotinamide riboside (NR) molecular structures. In the NAD pathway, the addition of a phosphate group is added to NR to create NMN, which the cell turns into NAD.** Image credit: [Tru Niagen Blog](https://blog.truniagen.com/home/2018/3/16/8-key-differences-between-nmn-nr)

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-12-sinclair2.jpg)

**Figure 12. NAD Biosynthetic Pathways: NR gets converted into NAD in two steps.** Image Credit: [lifespan.io](https://www.lifespan.io/campaigns/can-nmn-increase-longevity/)

- Once NR it is turned into NAD in the cell, it is recycled and turned into nicotinamide (NAM)
- NAM is a version of niacin, or vitamin B3
- A high dose of supplemented vitamin B3 can raise NAD levels but other components will be missing (riboside/sugar/DNA/phosphate)
- Taking niacin isn’t as effective as taking either NR or NMN
- There are reasons not to take high does of NAM

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-13-sinclair2-1024x733.png)

**Figure 13. Cellular pathway of NAD production and recycling.** Image credit: ([Wu and Sinclar, 2019](https://www.nature.com/articles/s42255-018-0015-6?WT.feed_name=subjects_organelles))

*NAM is an effective inhibitor of the Sirtuins…*

- A [2002 study](https://www.jbc.org/content/277/47/45099.short) showed that NAM inhibits sirtuins, enzymes you want to be active (the whole point of NAD is to be used as a substrate or fuel for sirtuins)
- Try to avoid NAM while raising AND levels
- It could be great to have a field definition of NAD:NAM ratio (to give an indication of cellular ‘boost’ to ‘break’)
- The field research attempts to increase NAD while keeping NAM levels low

*Taking NR orally…*

- A [study](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(18)30196-7) showed that orally-taken NR got turned into NAD in the liver (while most did not exit the liver)
- The study reported that NAM blood levels were raised but not NR
- Another [clinical trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5701244/) showed that orally administered NR raised NAD levels in the muscle and increased plasma NAM
  - High dose of 100mg administered
  - Placebo controlled with a high BMI study population in their mid-50s
  - The result could imply that the NR is getting past the liver and uptake in muscle cells produce NAD
  - There were a few improvements in inflammatory markers (some inflammation decreased in the muscle and mitochondrial markers were lower)
    - The interpretation of this finding is not clear
    - It could be an NR-specific effect or having to do with the class of molecules
    - It is surprising as other research shows that NMN and NR boost mitochondrial activity (in mice)
- It is important that NAD increases in the mitochondria, in particular – which has not yet been demonstrated

*Is there an advantage to taking NR* [*sublingually*](https://en.wikipedia.org/wiki/Sublingual_administration) *(SL) rather than orally?*

- Under the tongue, the substance gets directly absorbed, rather than passing through the liver (via the portal circulation)
- The microbiome will consume some of the NR when ingesting niacin (the nicotinamide comes off easily)
- There is evidence that the gut plays a big role in how much and if NR gets into the rest of the body

*There is not conclusive findings about what happens to NAD building blocks when they pass through the gut…*

- Not all findings are in agreement, but David believes that the microbiome removes a lot of the nicotinamide from NR and NMN before it is taken up by the gut
  - It makes sense not to put all of it in the gut
  - But if it all passes through the gut, some will get through
  - NMN gets broken down by the gut and then remade in the body into NAD
  - There is also data that some NMN and some of the NR gets through to the rest of the body and gets beyond the liver into the muscle

The most recent ITP study, that is not yet published, is a robust analysis of  NR in the mouse animal model

- Findings are not definitive because there is plenty of ways to dose, administer
- But it is another data point
- [Johan Auwerx](https://people.epfl.ch) says that administering NR to mice does expand lifespan
- David’s lab experiments with [NMN and lifespan in mice](https://www.cell.com/cell/fulltext/S0092-8674(18)30152-1)

*Does taking NAD precursor commute benefits for humans?*

- The administering of these molecules are beneficial for mice in health and longevity and research is still being done to answer if the same  results occur in humans
- [A recent study](https://www.ncbi.nlm.nih.gov/pubmed/30668199) published the effects of mega-dosing NR and pterostilbene versus placebo for ALS treatment
  - There were reported improvements on subjective quality of life measures
  - One cardiac function was also evaluated
  - To delineate the effects of NR and pterostilbene (a molecule similar to resveratrol) a trial would need to administer both separately

*A potential theme of supplementing with longevity compounds in humans…*

- It could be that there are only measurable positive effects if the individual is not healthy
- In terms of sirtuin activators, David’s lab is focused on NAD-boosting drugs
  - The most advanced molecule is currently being used in a trial (phase one) of healthy volunteers
  - Looking to be used for unhealthy individuals with rare disease (a fast track for a disease that has an unmet need)

## David’s artistic work [2:05:15]

![](https://peterattiamd.com/wp-content/uploads/2019/09/fig-14-sinclair2.jpg)

**Figure 14. One of David’s drawings that appear in his book. The face is that of James L. Kirkland, American physician and biologist.** Image credit: [David Sinclair, Ph.D](https://lifespanbook.com/illustrations/)

- David drew the artwork in his book
- He draws as a hobby  and was going to be a computer graphic designer prior to falling in love with lab work
- He made the original art (drawing 28 faces in 28 days) and took a digital photograph
- You can visit the [book website](https://lifespanbook.com/) to order the book and more about it and all of David’s renderings that appear in the [here](https://lifespanbook.com/illustrations/)

§

## Selected Links / Related Material

**Claude Shannon’s 1940 paper on the information theory of communication**: [A mathematical theory of communication](https://www.math.harvard.edu/~ctm/home/text/others/shannon/entropy/entropy.pdf) (Shannon, 1940) [8:45]

**Kaeberlein overexpressing the Sir2 gene in a yeast cell promoting longevity**: [The SIR2/3/4 complex and SIR2 alone promote longevity in Saccharomyces cerevisiae by two different mechanisms](https://www.ncbi.nlm.nih.gov/pubmed/10521401) (Kaberlein, McVey, and Guarente, 1999) [9:45]

**Waddington’s landscape**: [The Strategy of the Genes by Conrad Waddington](https://www.amazon.com/Strategy-Genes-Routledge-Library-Editions-dp-1138998133/dp/1138998133/ref=mt_paperback?_encoding=UTF8&me=&qid=) | (amazon.com) [18:30]

**One of David’s talks, speaking at Science Unlimited 2019**: [Cracking and reversing the aging clock](https://forum.frontiersin.org/david-sinclair-cracking-reversing-aging) | (frontiersin.org) [19:45]

**David’s TED Talk on aging**: [A Cure for Ageing?: David Sinclair at TEDxSydney](https://www.youtube.com/watch?v=vCCdmGKtxPA) | TEDx Talks (youtube.com) [19:45]

**DNA methylation age of cell types developed by Steve Horvath**: [Horvath (epigenetic) Clock](https://en.wikipedia.org/wiki/Epigenetic_clock) | (wikipedia.org)  [26:30]

**A presentation of the Horvath Clock conceptual framework**: [DNA methylation-based biomarkers of aging and lifecourse](https://nathanshockcenters.org/assets/uploads/default/Horvath-Steven.pdf) (Horvath) [26:30]

**Twin astronauts study that revealed telomere changes with space travel but rapid reversal thereafter (supporting that telomeres are not immutable markers of aging)**: A[stronaut twin study hints at stress of space travel](https://www.nature.com/news/astronaut-twin-study-hints-at-stress-of-space-travel-1.21380) (Witze, 2017) [29:15]

**Horvath developed a multi-tissue predictor of age that allows one to estimate the DNA methylation age of most tissues and cell types**: [DNA methylation age of human tissues and cell types](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4015143/) (Horvath, 2013) [33:00]

**Along with Horvath, Hannum worked on the DNA-methylation analysis to determine cellular age**: [Genome-wide methylation profiles reveal quantitative views of human aging rates](https://www.sciencedirect.com/science/article/pii/S1097276512008933/pdfft?md5=9e57c4e35b9d55e4eac7ee7f2d863823&pid=1-s2.0-S1097276512008933-main.pdf) (Hannum et al., 2013) [33:00]

**A fine line between cellular reprogramming to pluripotency and tumor development**: [p53: Guardian of reprogramming](https://www.tandfonline.com/doi/abs/10.4161/cc.9.19.13301) (Menendez, Camus, Belmonte, 2010)  [33:45]

**Retina Cellular reprogramming study by David and his colleagues**: [Reversal of ageing- and injury-induced vision loss by Tet-dependent epigenetic reprogramming](https://www.biorxiv.org/content/10.1101/710210v1) (Ksander, He, Sinclair, et al., 2019) [35:15; 41:30]

**An observational study that investigates what could change the rate of epigenetic aging**: [Epigenetic clock analysis of diet, exercise, education, and lifestyle factors](https://www.ncbi.nlm.nih.gov/pubmed/28198702) (Quach et al., 2017) [38:30]

**Nir Barzilai’s effort to look at metformin as a treatment for aging**: [Metformin as a Tool to Target Aging](https://www.ncbi.nlm.nih.gov/pubmed/27304507) (Barzilai et al., 2016)[1:30:30]

**Researchers led by Dr. James Kirkland of the Mayo Clinic wanted to understand how senescent cells contribute to the physical effects of aging. Mice who received the senescent cells had impaired walking speed, physical endurance, and grip strength compared to control mice. Larger doses of senescent cells caused greater impairment over time**:  [Senolytics Improve Physical Function and Increase Lifespan in Old Age](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6082705/) (Kirkland et al., 2018) [1:10:00]

**p16INK4a mouse made by Ned Sharpless suggests that activation is a characteristic of all emerging cancers**: [Monitoring Tumorigenesis and Senescence In Vivo with a p16INK4a-Luciferase Model](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3718011/) (Sharpless et al., 2013) [1:11:45]

**Recent studies suggest that metformin may blunt the effects of exercise** [1:29:15]:

- **Peters blog post on taking metformin and exercise**: [metformin and exercise](https://peterattiamd.com/metformin-and-exercise/) | (peterattiamd.com)
- **Metformin may blunt strength training benefits in elderly individuals**: [metformin to augment strength training effective response in seniors: the masters trial](https://academic.oup.com/innovateage/article/2/suppl_1/544/5169519) (Peterson et al., 2018)
- **Metformin blunted the full effects of exercise training**: [Independent and combined effects of exercise training and metformin on insulin sensitivity in individuals with prediabetes](https://www.ncbi.nlm.nih.gov/pubmed/22040838/) (Malin et al., 2012)
- **A New York Times article that reports exercise-blunting effects**: [An anti-aging pill? Think twice](https://www.nytimes.com/2019/06/19/well/move/an-anti-aging-pill-think-twice.html?smid=nytcore-ios-share)  |  Gretchen Reynolds *New York Times*

**Effects of resveratrol and yeast lifespan found to be Sir2-dependent**: [Small molecule activators of sirtuins extend Saccharomyces cerevisiae lifespan](https://www.ncbi.nlm.nih.gov/pubmed/12939617) (Howitz et al., 2003)  [1:34:15]

**ITP showed that if you have a healthy mouse on a lean diet, it doesn’t extend their lifespan**: [1:36:30]

- **First ITP study showing treatment of resveratrol (at 50 and 200 mg/kg), beginning at 12 mo of age, did not have significant effects on survival in WT male or female mice**: [Rapamycin, But Not Resveratrol or Simvastatin, Extends Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pubmed/20974732) (Miller et al., 2009)
- **Second ITP study showing treatment of resveratrol, beginning at 4 mo of age, did not have significant effects on the lifespan of male or female WT mice**: [Evaluation of Resveratrol, Green Tea Extract, Curcumin, Oxaloacetic Acid, and Medium-Chain Triglyceride Oil on Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3598361/) (Strong et al., 2012)

**A 2013 study found that a SIRT1 mutation blocked resveratrol from activating the sirtuin enzyme**: [Evidence for a common mechanism of SIRT1 regulation by allosteric activators](https://www.ncbi.nlm.nih.gov/pubmed/23471411/) (Sinclair et al., 2013) [1:37:00]

**A 2006 nature study reporting that resveratrol shifts the physiology of middle-aged mice on a high-calorie diet towards that of mice on a standard diet and significantly increases their survival**: [Resveratrol improves health and survival of mice on a high-calorie diet](https://www.ncbi.nlm.nih.gov/pubmed/17086191) (Sinclair et al., 2006) [1:38:30]

**NAD acts as the body’s signaling molecule. In 2000, Sir2 was reported to have histone deacetylase activity, which results in chromatin compaction and requires NAD+, a cofactor also required for redox reactions and whose levels change in response to nutrients and stress**:  [1:42:00]

- [Transcriptional silencing and longevity protein Sir2 is an NAD-dependent histone deacetylase](https://www.ncbi.nlm.nih.gov/pubmed/10693811) (Imai, Armstrong, Kaeberlain, Guarente, 2000)
- [The silencing protein SIR2 and its homologs are NAD-dependent protein deacetylases](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC18515/) (Landry et al., 2000)

**Young mice that were given a NAD boost did not run further but they did if a boost and exercise was administered at the same time**: [Impairment of an Endothelial NAD+-H2S Signaling Network Is a Reversible Cause of Vascular Aging](https://www.sciencedirect.com/science/article/pii/S0092867418301521) (Sinclair et al., 2018) [1:43:00]

**In animal models, boosted NAD levels has demonstrated advantageous results**: [Therapeutic potential of NAD-boosting molecules: the in vivo evidence](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6342515/) (Sinclair et al., 2018)

**How NMN gets into cells**: [The elusive NMN transporter is found](https://www.nature.com/articles/s42255-018-0015-6?WT.feed_name=subjects_organelles) (Wu and Sinclair, 2019) [1:44:00]

**Nicotinamide is an effective inhibitor of sirtuins**: [Inhibition of Silencing and Accelerated Aging by Nicotinamide, a Putative Negative Regulator of Yeast Sir2 and Human SIRT1](https://www.jbc.org/content/277/47/45099.short) (Bitterman et al., 2002) [1:47:30]

**NR given orally were metabolized to nicotinamide (NAM) in the liver**: [Quantitative Analysis of NAD Synthesis-Breakdown Fluxes](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(18)30196-7) (Rabinowitz et al., 2018)  [1:48:00]

**Repeat dose of NRPT is a safe and effective way to increase NAD+ levels**: [Repeat dose NRPT (nicotinamide riboside and pterostilbene) increases NAD+ levels in humans safely and sustainably: a randomized, double-blind, placebo-controlled study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5701244/) (Dellinger et al., 2017)  [1:49:15]

**It is important for NAD to go up in mitochondria in particular particularly**: [1:51:30]

- [Nutrient-Sensitive Mitochondrial NAD+ Levels Dictate Cell Survival](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3366687/) (Sinclair et al., 2007)
- [Declining NAD+ Induces a Pseudohypoxic State Disrupting Nuclear-Mitochondrial Communication during Aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4076149/) (Gomes, Sinclair, et al., 2013)

**Modulation of NAD(+)-producing and -consuming pathways have a major physiological impact and hold promise for the prevention and treatment of metabolic disease**: [The secret life of NAD+: an old metabolite controlling new metabolic signaling pathways](https://www.ncbi.nlm.nih.gov/pubmed/20007326) (Hootkooper, Canto, Wanders, Auwerx, 2010) [1:52:15]

**NMR administered to mice improved lifespan**: [1:54:15]

- [administered NMN to advanced aged mice and saw improved DNA repair capacities](https://www.ncbi.nlm.nih.gov/pubmed/28336669) (Li et al., 2017)
- **Improved blood vessel growth and increased blood flow in aged mice taking NMN**: [Impairment of an Endothelial NAD+-H2S Signaling Network Is a Reversible Cause of Vascular Aging](https://www.cell.com/cell/fulltext/S0092-8674(18)30152-1) (Das et al., 2018)

**A small trial reported that oral NR taken with pterostilbene treated individuals with ALS**: [Efficacy and tolerability of EH301 for amyotrophic lateral sclerosis: a randomized, double-blind, placebo-controlled human pilot study](https://www.ncbi.nlm.nih.gov/pubmed/30668199) (de la Rubia et al., 2019) [1:58:30]

§

## People Mentioned

- [Claude Shannon](https://en.wikipedia.org/wiki/Claude_Shannon) (mathematician who figured out how to mathematically encode information and make sure that it got to the receiver)  | (wikipedia.org)  [8:45; 13:15]
- [Leonard “Lenny” Guarente](https://en.wikipedia.org/wiki/Leonard_P._Guarente) (professor of biology at MIT, seminal work on sirtuins, founder of Elysium) | (wikipedia.org) [9:15]
- [Matt Kaeberlein](https://peterattiamd.com/mattkaeberlein/) (received Ph.D. at MIT with Guarente as advisor)  | (wikipedia.org) [9:45]
- [Conrad Hal Waddington](https://en.wikipedia.org/wiki/C._H._Waddington) (Waddington’s landscape)  | (wikipedia.org) [18:30]
- [Steve Horvath](https://ph.ucla.edu/faculty/horvath) (Professor in Human Genetics and Biostatistics at UCLA)  | (ucla.edu) [26:30]
- [Juan Carlos Belmonte](https://www.salk.edu/scientist/juan-carlos-izpisua-belmonte/) (Investigator at the Salk Institute)  | (salk.edu) [33:45]
- [Bruce R. Ksander](https://eye.hms.harvard.edu/bruceksander) (Associate professor of Ophthalmology)  | (harvard.edu) [41:30]
- [Zhigang He](https://www.hms.harvard.edu/dms/neuroscience/fac/He.php) (Professor of Neurology at Boston Children’s Hospital)  | (harvard.edu) [41:30]
- [Jessie Gelsinger](https://en.wikipedia.org/wiki/Jesse_Gelsinger) (died from AAV immune response) [51:00]
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) (former guest on [The Drive](https://peterattiamd.com/nirbarzilai/), Director of the Longevity Genes Project, spearheading a study on metformin to target aging [[TAME trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5943638/)])  | (wikipedia.org) [1:02:45; 1:27:45]
- [James Kirkland](https://www.mayo.edu/research/faculty/kirkland-james-l-m-d-ph-d/bio-00096544) (M.D., Ph.D. who investigates the impact of cellular aging (senescence) on age-related dysfunction and chronic diseases)| (mayo.edu)  [1:10:00]
- [Ned Sharpless](https://en.wikipedia.org/wiki/Norman_Sharpless) (FDA commissioner; made luciferase knockin mouse (p16LUC))
- [George Church](https://arep.med.harvard.edu/gmc/) (professor at Harvard and MIT) | (harvard.edu) [1:20:30]
- [Jeanne Calment](https://en.wikipedia.org/wiki/Jeanne_Calment) (French ‘supercentenarian’ who died at a reported 122 years of age)  | (wikipedia.org)  [1:27:00]
- [Johan Auwerx](https://people.epfl.ch)  (Professor at the École Polytechnique Fédérale in Lausanne, Switzerland)  | (epfl.ch) [1:52:15; 1:58:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/09/david-bio-image-pt2--500x500.png)

##### David Sinclair, Ph.D.

David A. Sinclair, Ph.D. is a Professor in the Department of Genetics at Harvard Medical School and co-Director of the Paul F. Glenn Center for the Biological Mechanisms of Aging.

He is best known for his work on understanding why we age and how to slow its effects. He obtained his Ph.D. in Molecular Genetics at the University of New South Wales, Sydney in 1995. He worked as a postdoctoral researcher at M.I.T. with Dr. Leonard Guarente where he co-discovered a cause of aging for yeast as well as the role of Sir2 in epigenetic changes driven by genome instability. In 1999 he was recruited to Harvard Medical School where his laboratory’s research has focused primarily on understanding the role of sirtuins in disease and aging, with associated interests in chromatin, energy metabolism, mitochondria, learning and memory, neurodegeneration, and cancer. He has also contributed to the understanding of how sirtuins are modulated by endogenous molecules and pharmacological agents such as resveratrol.

Dr. Sinclair is the co-founder of several biotechnology companies (Sirtris, Ovascience, Genocea, Cohbar, MetroBiotech, ArcBio, Liberty Biosecurity) and is on the boards of several others. He is also co-founder and co-chief editor of the journal Aging. His work is featured in five books, two documentary movies, 60 Minutes, Morgan Freeman’s “Through the Wormhole” and other media.

He is an inventor on 35 patents and has received more than 25 awards and honors including the CSL Prize, The Australian Commonwealth Prize, Thompson Prize, Helen Hay Whitney Postdoctoral Award, Charles Hood Fellowship, Leukemia Society Fellowship, Ludwig Scholarship, Harvard-Armenise Fellowship, American Association for Aging Research Fellowship, Nathan Shock Award from the National Institutes of Health, Ellison Medical Foundation Junior and Senior Scholar Awards, Merck Prize, Genzyme Outstanding Achievement in Biomedical Science Award, Bio-Innovator Award, David Murdock-Dole Lectureship, Fisher Honorary Lectureship, Les Lazarus Lectureship, Australian Medical Research Medal, The Frontiers in Aging and Regeneration Award, Top 100 Australian Innovators, and TIME magazine’s list of the “100 most influential people in the world”. [[medapps.med.harvard.edu](https://medapps.med.harvard.edu/agingresearch/index.php/about/staff/sinclair)] His new book, [*Lifespan*](https://lifespanbook.com/), explains why we age and why we don’t have to.

David on LinkedIn: [David A. Sinclair, Ph.D. A.O.](https://www.linkedin.com/in/sinclairda/)

David on Twitter: [@davidasinclair](https://twitter.com/davidasinclair?lang=en)

David on Instagram: [davidsinclairphd](https://www.instagram.com/davidsinclairphd/?hl=en)David’s book website: [lifespanbook.com](https://lifespanbook.com/)