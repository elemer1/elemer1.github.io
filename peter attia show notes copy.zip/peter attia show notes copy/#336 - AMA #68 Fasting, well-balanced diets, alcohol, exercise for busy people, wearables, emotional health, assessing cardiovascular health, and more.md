# #336 – AMA #68: Fasting, well-balanced diets, alcohol, exercise for busy people, wearables, emotional health, assessing cardiovascular health, and more

**Source:** [https://peterattiamd.com/ama68/](https://peterattiamd.com/ama68/)

---

In this “Ask Me Anything” (AMA) episode, Peter tackles a diverse set of listener-submitted questions, covering a wide range of health and performance topics. He dives into assessing cardiovascular health, discussing key biomarkers and risk factors, and breaks down various fasting approaches, including time-restricted eating and prolonged fasting. The conversation also explores the impact of alcohol on health and disease risk, fundamental principles of nutrition, and optimal protein intake. Additionally, he examines the pros and cons of ketogenic and low-carb diets, strategies for building effective exercise routines, and the role of wearables in tracking health metrics. The episode concludes with insights on emotional health, making this a well-rounded discussion packed with practical takeaways for anyone looking to optimize their well-being.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #68 show notes page](https://peterattiamd.com/ama68). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Episode format: overview of common health topics based on listener questions [1:30];
- How to accurately assess your cardiovascular health [3:00];
- The impact of fasting, time-restricted eating, and dietary restriction on metabolic health [9:00];
- Alcohol: health risks of consumption, limitations of research, and how to weigh the risks against social and personal enjoyment [13:45];
- Principles of a well-balanced diet: macronutrients, micronutrients, protein, energy balance, and more [23:45];
- The benefits and drawbacks of ketogenic diets: impact on satiety, metabolic health, athletic performance, lipid levels, and more [29:15];
- Protein: best sources for muscle growth, total intake, PDCAAS scoring system, and getting adequate amounts on plant-based diets [36:15];
- Creating an effective fitness routine that fits into a busy schedule [41:45];
- The role of rest and recovery in a workout routine [46:00];
- How to track fitness progress beyond just weight on a scale [48:30];
- The best low-impact exercises for individuals with joint issues [52:00];
- Wearables: insight vs. compliance, and how to use them effectively [54:45];
- How to evaluate the risks and benefits of medical interventions: procedural risks, complication rates, and asking informed questions [59:00];
- Sleep: impact on metabolic and cognitive health, and tips for improving sleep quality [1:03:45];
- How to identify and address emotional health challenges [1:08:30]; and
- More.

---

The Peter Attia Drive

#336 – AMA #68: Fasting, well-balanced diets, alcohol, exercise for busy people, wearables, emotional health, assessing cardiovascular health, and more

---

## Show Notes


---

## Episode format: overview of common health topics based on listener questions [1:30]

- This AMA episode compiles listener-submitted questions gathered over the past three years from the [AMA portal](https://peterattiamd.com/submit-a-question/) on the website.
- The questions cover a wide range of health topics in a structured yet broad manner.
  - Diseases and health conditions
  - Nutrition and fasting
  - Exercise and fitness strategies
  - Other general wellness topics

How Listeners Can Participate in Future AMAs

- The AMA portal allows listeners to [submit questions](https://peterattiamd.com/submit-a-question/) at any time.
- Questions can be related to:
  - Past podcast episodes
  - Newsletters
  - Personal health concerns

Episode Format & Experimentation

- This AMA will feature more questions with shorter answers, mimicking how Peter would respond in casual conversations (e.g., at a party).
- If listeners enjoy this style, Peter suggests doing quarterly AMAs with a mix of general Q&A and specific listener-submitted questions.
- Possibility of acknowledging specific individual submissions in future episodes.
- Goal: Test if this approach resonates with the audience and adjust accordingly.

## How to accurately assess your cardiovascular health [3:00]

**The Importance of Cardiovascular Health**

- Cardiovascular disease (CVD) is the leading cause of death worldwide.
- Many people are curious about their current cardiovascular risk and how to properly assess it.

**Key Tools for Assessing Cardiovascular Risk**

*Family History as a Primary Indicator*

- One of the most overlooked yet critical aspects of risk assessment.
- It’s not enough to just know how long relatives lived; it’s important to understand:
  - What conditions they had (e.g., high cholesterol, high blood pressure).
  - Whether they took medications for cholesterol or hypertension.
  - If they required cardiovascular procedures (e.g., stents, bypass surgery, revascularization).
- Early cardiovascular events in family members suggest potential heritable causes, such as:
  - Elevated Lipoprotein(a) [Lp(a)]
    - Podcast: [#07 – Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know](https://peterattiamd.com/lpa/)
    - Podcast: [#210 – Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.](https://peterattiamd.com/benoitarsenault/)
    - Podcast: [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/)
  - Familial Hypercholesterolemia (FH)
    - Podcast: [#255 ‒ Latest therapeutics in CVD, APOE’s role in Alzheimer’s disease and CVD, familial hypercholesterolemia, and more | John Kastelein, M.D., Ph.D.](https://peterattiamd.com/johnkastelein/)
    - [More resources](https://peterattiamd.com/?s=Familial%20Hypercholesterolemia%20(FH))

*Calcium Scan (CAC) for Assessing Arterial Damage*

- A CAC scan helps determine the extent of arterial calcification, which indicates advanced disease.
  - Article: [Coronary artery calcium scan](https://peterattiamd.com/coronary-artery-calcium-scan/)
  - Podcast: [#247 ‒ Preventing cardiovascular disease: the latest in diagnostic imaging, blood pressure, metabolic health, and more | Ethan Weiss, M.D.](https://peterattiamd.com/ethanweiss2/)
  - Podcast: [#203 – AMA #34: What Causes Heart Disease?](https://peterattiamd.com/ama34/)
- Key points about CAC:
  - An ideal score is zero, meaning no calcification.
  - However, a score of zero is not always definitive, as 15% of cases can have soft plaque not detected by CAC.
  - In these cases, a CT angiogram (CTA) can provide a clearer picture but exposes the patient to radiation and contrast dye risks.
  - Calcification itself is a protective mechanism, but its presence suggests an underlying cardiovascular process that could indicate broader risks.

*Lipid Profile and Blood Markers*

- ApoB and Lp(a) are the two most critical markers.
  - More on apoB:
    - Podcast: [#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB](https://peterattiamd.com/understanding-cardiovascular-disease/)
    - Article on apoB: [Measuring cardiovascular disease risk and the importance of apoB](https://peterattiamd.com/measuring-cardiovascular-disease-risk-and-the-importance-of-apob-part-1/)
    - Podcast: [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/)
- LDL cholesterol, HDL cholesterol, and non-HDL cholesterol are less relevant once ApoB and Lp(a) are known.
- Triglycerides are important only when extremely elevated (>400 mg/dL), which can indicate metabolic issues requiring intervention.

*Blood Pressure as a Major Risk Factor*

- Hypertension is a significant predictor of cardiovascular disease and is often under-monitored.
- Key blood pressure considerations:
  - Ideal blood pressure is below 120/80 mmHg.
  - 130/85 mmHg, previously considered normal, is now known to increase risk.
  - Doctors often measure blood pressure incorrectly—proper technique includes:
    - Sitting still for five minutes before measurement.
    - Ensuring the arm is positioned at heart level.
    - Using a properly fitting cuff and avoiding crossed legs.
    - Checking multiple readings (duplicate or triplicate measurements).
  - Monitoring at home twice daily for two weeks once a year provides a better assessment.
- Resources:
  - Article: [All things blood pressure: from measurement to management](https://peterattiamd.com/all-things-blood-pressure/)
  - Podcast: [#258 – AMA #48: Blood pressure—how to measure, manage, and treat high blood pressure](https://peterattiamd.com/ama48/)

*Lifestyle and Metabolic Factors*

- Smoking significantly increases CVD risk.
- Metabolic health plays a critical role, including:
  - Hyperinsulinemia
  - Insulin resistance
  - Type 2 diabetes
- Addressing metabolic dysfunction is crucial for long-term cardiovascular health.

**Tests and Metrics Not Considered as Useful**

- Carotid Intima-Media Thickness (CIMT)
  - Peter does not find CIMTs particularly useful for assessing cardiovascular risk.
  - The data does not support CIMT as a superior tool compared to the aforementioned tests.

## The impact of fasting, time-restricted eating, and dietary restriction on metabolic health [9:00]

**Defining Fasting vs. Time-Restricted Eating**

- Common misconception: People often use the terms fasting and intermittent fasting interchangeably.
- Peter’s distinction:
  - Time-Restricted Eating (TRE) or Time-Restricted Feeding (TRF):
    - Eating within a set window each day (e.g., 16:8 or 18:6 fasting/eating patterns).
    - No caloric restriction beyond the timing of food intake.
  - Fasting:
    - Extended fasting beyond 24 hours (e.g., 48-hour, 72-hour, or even 7- to 14-day fasts).
    - Water-only fasting—no caloric intake during this period.

**Impact on Metabolic Health**

*Time-Restricted Eating vs. Caloric Restriction*

- Current research suggests that time-restricted eating alone does not provide additional metabolic benefits beyond simple caloric restriction.
- When calorie intake is matched, there is no significant advantage to compressing meals into a shorter window.
- The key metabolic benefit comes from reducing total caloric intake, regardless of timing.

*Three Main Strategies for Reducing Calories*

- 1) Direct Caloric Restriction (Counting Calories)
  - The most precise but also the most effort-intensive approach.
  - Common among bodybuilders, who meticulously track macronutrient intake.
  - Provides clear control over caloric balance and body composition changes.
- 2) Time-Restricted Eating (TRE) / Intermittent Fasting (IF)
  - Passive calorie reduction strategy—reducing the eating window often leads to lower intake.
  - However, not always effective—some people compensate by eating more in a shorter period.
  - Works well for those who don’t want to track food intake directly but still need a structured way to reduce calories.
- 3) Dietary Restriction (Restricting Food Types Instead of Timing or Quantity)
  - Focuses on eliminating specific foods or food groups rather than meal timing.
  - Example: Cutting out sugar, processed foods, or high-carb foods.
  - The stricter the restriction, the more likely it results in reduced overall calorie consumption.

**Choosing the Right Approach**

- No single best method—it depends on personal preference and lifestyle compatibility.
- Experimenting with different strategies can help individuals determine what works best for sustainable metabolic improvements.
- Caloric restriction is the primary driver of metabolic benefits, regardless of whether it’s achieved through fasting, eating windows, or specific food choices.

> “It’s the calorie restriction that provides the greatest benefit. How you go about achieving it is really a function of your style.” —Peter Attia

⇒ Peter covers this topic extensively in his book: [OUTLIVE](https://peterattiamd.com/outlive/)

⇒ More on time-restricted eating and fasting: [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/)

## Alcohol: health risks of consumption, limitations of research, and how to weigh the risks against social and personal enjoyment [13:45]

**Understanding Alcohol’s Unique Effects**

- Alcohol as a nutrient: Unlike carbohydrates, fats, and proteins, alcohol has unique metabolic effects.
  - Energy density: Alcohol provides 7 kcal per gram, closer to fat (9 kcal per gram) than to carbohydrates and protein (4 kcal per gram).
  - Caloric load: Many drinkers underestimate how much of their caloric intake comes from alcohol—some patients derive up to 25% of total calories from alcohol.
  - Primary concern: Beyond its caloric content, the toxicity of alcohol itself and its metabolic byproducts are the main health risks.

**Challenges in Studying Alcohol’s Health Effects**

- Epidemiology vs. Randomized Control Trials (RCTs)
  - Epidemiological studies (observational data) often suggest small hazard ratios, making it difficult to draw strong conclusions.
  - Unlike tobacco, where the risks are extremely clear, alcohol research is more nuanced.
  - RCT limitations: There are no long-term randomized control trials on alcohol consumption. Existing RCTs tend to be short-term and lack definitive conclusions.

**Key Findings from Large-Scale Studies**

[JAMA Study](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2802963) (Largest to Date, 2023)

- Included 107 cohort studies with 5 million participants.
- Compared various drinking patterns to lifelong abstainers (e.g., individuals who never consumed alcohol, often for religious or personal reasons).

Mortality Risk Based on Alcohol Consumption

- Former drinkers (who quit drinking):
  - Had 26% increased risk of all-cause mortality compared to lifelong abstainers.
  - Often quit due to health reasons, potentially skewing the data.
- Occasional drinkers (<1 drink per week):
  - No significant increase in mortality risk.
- Low-volume drinkers (≤1.5 drinks per day):
  - Also did not show increased mortality risk.
- Medium-volume drinkers (up to 3 drinks per day):
  - Surprisingly, no significant increase in mortality.
- High-volume drinkers (3-4 drinks per day):
  - 20% increased mortality risk.
- Very high-volume drinkers (>4 drinks per day):
  - 35% increased mortality risk.

*Gender Differences in Alcohol Metabolism*

- Women generally fare worse than men with alcohol consumption.
- Key reasons:
  - Lower body weight and lean mass → Less water to dilute alcohol.
  - Lower levels of alcohol dehydrogenase (ADH) → Slower metabolism, leading to prolonged exposure to toxic byproducts.
  - Higher susceptibility to negative health effects like liver disease, cancer, and cardiovascular issues.

**Alcohol’s Link to Chronic Disease**

- Clear associations with:
  - Cardiovascular disease (e.g., hypertension, increased stroke risk).
  - Dementia and cognitive decline.
  - Cancer risk (especially breast, liver, and esophageal cancer).
  - Increased all-cause mortality in high consumption levels.

**Reconciling Epidemiology with Mendelian Randomization Studies**

- Epidemiology studies (observational) often show a flat or J-shaped risk curve, implying that moderate drinking isn’t harmful or may even be protective.
- [Mendelian Randomization Studies](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2790520) (Genetic Studies) suggest a linear increase in risk, meaning even low levels of alcohol increase mortality risk.
- Conclusion: Given the uncertainties, the precautionary principle suggests that abstaining from alcohol is the lowest-risk option.

**Practical Considerations for Individuals**

- Is it ever “worth it” to drink?
  - Moderation is key: If drinking enhances social well-being and enjoyment, moderate consumption (e.g., a few drinks per month) is unlikely to be harmful.
  - Context matters:
    - A few drinks per month in a social setting vs. regular drinking with high intake.
    - Binge drinking (>4 drinks at once) is clearly harmful, even if infrequent.
  - Risk-based decision-making:
    - Consider whether alcohol negatively affects sleep, diet, mood, or behavior (e.g., overeating, poor decision-making, impaired driving).

⇒ Check out this article from Peter: [Is low-to-moderate alcohol consumption beneficial for longevity?](https://peterattiamd.com/low-to-moderate-alcohol-consumption-and-longevity/)

**Final Takeaways**

- No level of alcohol is beneficial for health.
- Low to moderate drinking is unlikely to be significantly harmful for most people.
- Excessive alcohol consumption significantly increases mortality risk.
- Gender and genetics play a role in how alcohol affects an individual’s health.
- Mendelian randomization [suggests](https://onlinelibrary.wiley.com/doi/full/10.1002/ijc.33917) a dose-dependent increase in health risks.

## Principles of a well-balanced diet: macronutrients, micronutrients, protein, energy balance, and more [23:45]

**The First Principles Approach to Nutrition**

- Different experts will give different answers regarding what constitutes a healthy diet.
- It’s important to take a first principles approach rather than a rigid or zealot-based view.
- Why do we eat?
  - Primary reasons: Provide structural and energetic needs for the body.
  - Secondary reasons: Micronutrients support enzymatic and metabolic reactions.

**Macronutrients and Their Roles**

- Protein: Primarily used for structural purposes, not energy.
  - Only in extreme cases (starvation, extreme caloric deficits) will the body use amino acids for energy.
- Carbohydrates: Serve as a primary energy source, not structural.
- Fats: Serve both as an energy source and for structural components of cells (e.g., phospholipids, cholesterol).

**Achieving Balance in Macronutrient Intake**

- A well-balanced diet should include adequate protein and fat without excessive energy intake.
- Protein intake recommendations:
  - The RDA of 0.8g/kg body weight is likely too low for optimal health.
  - A more appropriate range is **~1.6g/kg body weight (~1g per pound of body weight).**
  - Excess protein is not harmful because the body efficiently disposes of excess nitrogen via urine.

**Energy Balance and Body Composition**

- The biggest issue for most people is excessive energy intake, leading to fat storage.
- Tools to assess energy balance:
  - Scale weight (imperfect but useful for tracking trends).
  - [DEXA scans](https://peterattiamd.com/ama40/) (preferred for assessing body composition).
    - Provides detailed body fat percentage and visceral fat levels.
    - Target: Stay below the 25th percentile for body fat (adjusted for age/sex).

**The Importance of Micronutrient Balance**

- Omnivorous diets generally meet micronutrient needs.
- Debate exists over whether modern food sources are micronutrient-rich enough due to:
  - Soil depletion
  - Animal feed quality
  - [Mark Hyman](https://drhyman.com/pages/about-dr-hyman) touched on regenerative agriculture in [episode #94](https://peterattiamd.com/markhyman/)
- Restrictive diets (plant-based or carnivore) require supplementation:
  - Plant-based: Risk of B12, iron, zinc, omega-3 deficiencies.
  - Carnivore-based: Risk of fiber, vitamin C, folate deficiencies.

## The benefits and drawbacks of ketogenic diets: impact on satiety, metabolic health, athletic performance, lipid levels, and more [29:15]

**Defining a Low-Carb or Ketogenic Diet**

- Keto is an extreme form of dietary restriction that virtually eliminates carbohydrates.
- Total carbohydrate intake is usually between 30-50 grams per day (not net carbs).
- Goal: Achieve a state of ketosis, where the body produces beta-hydroxybutyrate (BHB) levels above 2.0 mmol/L.
- Macronutrient breakdown:
  - Carbohydrates: <10% of daily intake (typically ~5%).
  - Protein: ~15-20% of daily intake.
  - Fat: ~70-80% of daily intake.

**Benefits of a Ketogenic Diet**

- Satiation & Reduced Hunger
  - Many people feel fuller on keto, making caloric restriction easier.
  - Misconception: Some believe they can eat unlimited calories and still lose weight, but total caloric intake still matters.
- Weight Loss (if calories are controlled)
  - Keto may lead to weight loss due to lower insulin levels & increased fat oxidation.
  - Most weight loss occurs because of caloric restriction, not because of ketosis itself.
- Metabolic Benefits for Some
  - Can be beneficial for people with type 2 diabetes or metabolic syndrome.
  - Some experience improved insulin sensitivity & reduced inflammation.
- Potential Neurological Benefits
  - Ketones may be neuroprotective and have therapeutic benefits for epilepsy, Alzheimer’s, and Parkinson’s.

**Downsides and Risks of a Ketogenic Diet**

- Reduced Athletic Performance for High-Intensity Sports
  - Keto depletes glycogen, which is essential for explosive movements.
  - Athletes in strength, sprinting, or power-based sports may experience declines in performance.
  - While some adaptation occurs, keto never fully replaces the performance benefits of carbohydrates.
- Lipid Profile Changes (Increased LDL & ApoB)
  - High-fat intake (especially saturated fat) can elevate LDL cholesterol and ApoB, mimicking familial hypercholesterolemia.
  - Mechanism: Saturated fat reduces LDL receptor activity, leaving more LDL in circulation.
  - Solution: Monitor lipid markers and consider medication if necessary.
- Potential for Overeating & Weight Gain
  - Keto does not guarantee weight loss—some people overeat calorically dense fats (e.g., nuts, oils) and fail to lose weight.
  - Some individuals consume excessive calories without realizing it.
- Long-Term Sustainability Issues
  - Strict carb restriction is hard to maintain.
  - Social situations, limited food variety, and cravings make long-term adherence challenging.

**Key Considerations Before Starting a Ketogenic Diet**

- Understand your goals: Is keto the right tool for your specific health, weight loss, or performance objectives?
- Monitor health markers: Check lipid levels (LDL, ApoB), metabolic markers, and body composition.
- Adjust based on individual response: Some people thrive on keto, while others experience negative side effects.
- Consider medical supervision: Those with preexisting conditions should consult a healthcare provider before starting.

## Protein: best sources for muscle growth, total intake, PDCAAS scoring system, and getting adequate amounts on plant-based diets [36:15]

**Importance of Protein Quantity**

- The first priority when considering protein for muscle growth is getting enough total protein.
- Recommended intake: 1.6 to 2 grams of protein per kilogram of body weight.

**Understanding Protein Quality: PDCAAS**

- [PDCAAS](https://en.wikipedia.org/wiki/Protein_digestibility_corrected_amino_acid_score) (Protein Digestibility Corrected Amino Acid Score) measures protein quality based on amino acid composition and digestibility.
- Scale: 1.0 = highest possible score (perfectly digestible with all essential amino acids).
- Animal proteins generally score higher than plant proteins.

*Top animal-based protein sources (PDCAAS = 1.0)*

- Milk & Eggs (complete proteins with all essential amino acids).
- Whey & Casein (high-quality isolates derived from milk).
- Chicken & Beef (slightly lower but still high-quality at 0.95 and 0.92).

*Plant-based protein sources & considerations*

- Soy Protein Concentrate – PDCAAS = 1.0 (also has ~5g leucine per 100g).
- Pea Protein Isolate – PDCAAS = 0.85 – 0.9 (~5.7g leucine per 100g).
- Tofu – PDCAAS = 0.9, but much lower leucine (~1.7g per 100g protein).

\*Important Note on Plant Protein:

- Cooking affects PDCAAS, so be mindful of whether scores refer to raw or cooked food.
- If avoiding animal products, higher total intake is required to match the amino acid profile of animal proteins.

**Role of Leucine in Muscle Growth**

- Leucine is a key amino acid for muscle protein synthesis (MPS).
- Higher leucine content = more effective protein source for muscle growth.
- Comparison of leucine content per 100g of protein sources:
  - Whey Protein Isolate – ~9g leucine (highest).
  - Casein – ~5.8g leucine.
  - Soy Protein Concentrate – ~5g leucine.
  - Pea Protein Isolate – ~5.7g leucine.
  - Tofu – ~1.7g leucine (much lower).

**Animal-Based vs. Plant-Based Protein Intake**

If consuming animal proteins regularly:

- Quality is rarely a concern as they naturally provide complete amino acid profiles.

If on a plant-based diet:

- More planning is required to ensure adequate leucine intake and total protein.
- Mixing plant proteins (e.g., combining legumes with grains) can help balance amino acids.
- Higher total protein intake may be needed to compensate for lower PDCAAS and leucine content.

![](https://peterattiamd.com/wp-content/uploads/2025/02/f1-ama68.png)

**Figure 1.** Protein scores.

**Practical Advice: Focus on Total Protein First**

- If you are hitting your total protein target (~1g per pound of body weight), protein quality is less of a concern.
  - Example: A 150 lb person consuming 150g protein daily will almost always get enough essential amino acids from a balanced diet.
- For vegans or plant-based eaters, hitting a high total intake (~1.2-1.5g per pound) compensates for lower protein quality.
- For bodybuilders or those gaining weight (e.g., a 200 lb vegan bulking to 240 lbs), total protein intake ensures adequate muscle-building potential.

## Creating an effective fitness routine that fits into a busy schedule [41:45]

**The Biggest Challenge: Finding Time for Exercise**

- Exercise is one of the most common areas where people struggle due to time constraints.
- Unlike nutrition, which can be adjusted without taking extra time, exercise requires dedicated time each week.
- Peter acknowledges that this is a question he gets frequently and that exercise, while not necessarily harder than nutrition adjustments, requires people to carve out specific time for it.
- His approach: Instead of prescribing an ideal workout plan right away, he first has people take an honest assessment of how much time they can realistically commit to in a given week.

**Identifying Available Time by Cutting Unnecessary Activities**

- Instead of immediately assigning a detailed training schedule, Peter asks patients to reflect on their daily habits.
- He tells them: “Let’s only focus on the next 8 to 12 weeks. We’re not talking about anything beyond that. How much time can you give me each week for the next 8 to 12 weeks? Don’t answer me now. Go think about it, come back tomorrow.”
- He wants them to consider:
  - How much time do you actually spend scrolling social media, watching TV, etc.?
  - Are there activities you do that are important, but could be shortened or made more efficient?
- The goal is to find unused or underutilized time that could be repurposed for exercise.
- Example: If someone evaluates their schedule and comes back saying they can commit three hours per week, then Peter builds their program around that.

**The Structure of a Simple, Minimalist Workout Plan (3 Hours Per Week)**

- Once someone commits to a time frame, Peter structures their training into equal parts cardio and strength training:
  - 50% of the time spent on low-intensity cardio ([Zone 2 training](https://peterattiamd.com/tag/exercise-zone-2-training/)).
  - 50% of the time spent on strength training.
- The specific scheduling is flexible based on personal preference:
  - Three 1-hour sessions per week.
  - Six 30-minute sessions per week.
- Cardio Component (50% of weekly workout time):
  - The primary focus is low-intensity, steady-state cardio (Zone 2 training).
  - Zone 2 is key because it improves mitochondrial efficiency and cardiovascular health.
  - Options based on fitness level:
    - Highly deconditioned individuals → Brisk walking may be enough.
    - Moderately fit individuals → Treadmill walking, stationary biking, or rucking (walking with a weighted pack).
    - More advanced individuals → Can increase intensity but should still aim for sustained, moderate effort.
- Strength Training Component (50% of weekly workout time):
  - Goal: Build strength efficiently while minimizing time commitment.
  - Priority: Making it as convenient as possible so it becomes a sustainable habit.
  - Home workouts are encouraged to avoid the extra time required for commuting to a gym.
  - Example of a 30-minute home strength workout (3 times per week):
    - Bodyweight exercises → Push-ups, squats, lunges, planks.
    - Resistance bands or dumbbells if available → Simple compound movements like deadlifts, presses, and rows.

**The Importance of Habit Formation: The First 12 Weeks**

- Focus is on consistency, not perfection.
- Most people who go from doing nothing to three hours per week will feel and see a difference after 12 weeks.
- Progress markers matter:
  - Peter emphasizes small victories, saying: “Most people who do nothing in the way of exercise—after 12 weeks of doing this—are going to feel better, and they might even look better.”
  - If someone starts out unable to hold a wall sit for 10 seconds and later gets up to 60 seconds, that’s real progress.
  - Seeing tangible results reinforces motivation and makes the habit easier to sustain.

**Scaling and Expanding the Routine**

- After 12 weeks, the next step is reassessing progress and adjusting time commitment:
  - If three hours per week felt manageable, could you increase to four hours?
  - Could you refine your workouts to be more structured or efficient?
- The routine should be adaptable, ensuring long-term adherence without unnecessary complexity.

## The role of rest and recovery in a workout routine [46:00]

**Do You Really Need a Recovery Day? … It Depends**

- The need for a dedicated recovery day varies based on age and intensity of training.
- Physiological vs. Psychological Need for Rest:
  - Most people do not need a built-in recovery day from a physiological standpoint.
  - Some individuals may need it psychologically, meaning they feel better knowing they have a planned day off. If that’s the case, it’s perfectly fine to schedule one.
- The mistake many people make:
  - Training too hard, too often, without enough variation.
  - Doing the same workout every day, which can lead to stagnation and lack of progress.

**Strength Training: Avoiding Consecutive Days on the Same Muscle Group**

- Lifting three days in a week?
  - Those days should NOT be back-to-back.
  - Muscle groups need time to recover for optimal gains.
- Professional bodybuilders only train each muscle group once a week because their sessions are so intense that more frequent training would hinder recovery.
- General guideline for most people:
  - Split up workouts to allow muscle groups ample recovery time.
  - Rotate focus areas: Example → Upper body one day, lower body the next.
  - Incorporate different movement patterns (e.g., push vs. pull, heavy vs. light).

**The Role of Auto-Regulated Rest Days**

- Peter’s personal approach:
  - He does not schedule recovery days.
  - Rest days “just happen” naturally when life gets in the way (e.g., travel, busy schedule).
  - Typical frequency: He finds himself taking two days off per month on average.
  - When traveling heavily: He might end up with three to four unplanned recovery days per month simply due to logistics.
- Key takeaway:
  - If you’re too exhausted or life interferes, take a rest day, but don’t assume you need one every week if you’re training intelligently.

**Structuring Weekly Cardio with Built-in Variability**

- Peter’s weekly cardio routine:
  - Four days per week total.
  - Three days of Zone 2 (low-intensity, steady-state cardio).
  - One day of “clobber fest” (high-intensity effort).
- The importance of adjusting with age and experience:
  - Years ago: Peter could handle three days of high-intensity work per week.
  - Now: He only does one truly hard day per week (60–90 minutes max).
  - The shift is necessary to allow for better recovery and continued performance improvements.

**The Principle of Progressive Overload and When to Rest**

- Progressive overload: The idea that to improve, you must continually challenge your body by increasing weight, volume, or intensity over time.
- Rest should be based on need, not a rigid schedule.
  - If you’re still progressing and feeling good, you likely don’t need a recovery day.
  - If you feel overly fatigued or unable to progressively overload, take a rest day.
- Progression should apply to both:
  - Strength training: Gradually increasing weight, reps, or intensity.
  - Cardio: Improving endurance, speed, or power output.

## How to track fitness progress beyond just weight on a scale [48:30]

**The Scale Is Useful for Tracking Nutrition, Not Fitness**

- Weight is a better indicator of nutritional progress than fitness progress.
- If someone is overweight and losing weight via caloric restriction, the scale is a reasonable tracking tool.
- However, the scale doesn’t tell the full story of health improvements.

**What Actually Improves When Losing Weight?**

- If body fat is reduced through dietary changes, not exercise, it’s important to track other markers of health beyond the scale, including:
  - Blood pressure: If it was high, is it now improving?
  - Insulin sensitivity: If insulin resistance was an issue, is it getting better?
  - Other metabolic markers: Are key indicators of cardiovascular and metabolic health improving?
- The scale gives a rough directional idea, but true progress should be measured directly through these markers.

**Assessing Fitness Progress with Functional Tests**

- Weight alone does not measure fitness.
- Fitness should be assessed with performance-based tests rather than body weight.
- Zone 2 endurance test as a fitness metric:
  - Alternative to VO2 max testing (which requires specialized equipment).
  - Tracks how much work ([METS](https://peterattiamd.com/ama39/), watts, heart rate) a person can sustain at a given effort level.
  - Example:
    - If someone started walking at 2.5 mph on a 3% incline when beginning a fitness routine, they should check:
      - Can they now sustain a higher speed or incline with the same level of exertion?
- RPE (Rate of Perceived Exertion) as a measurement tool:
  - The goal for Zone 2 work is being able to talk in full sentences, though slightly out of breath.
  - Tracking progress means improving endurance capacity over time.

**Why the Scale Can Be Misleading for Exercise Gains**

- Exercise often leads to muscle gain, not just fat loss.
- Particularly in women new to strength training, it’s common for:
  - Weight to stay flat or even increase slightly.
  - Clothing to fit differently despite the scale not changing.
  - Muscle mass replacing fat, which is a positive body composition change.
- What really matters:
  - Changes in body shape, strength, endurance, and functional fitness rather than just weight.

**The Best Indicators of True Fitness Progress**

- Instead of relying on weight, track improvements in:
  - Strength metrics (e.g., ability to lift heavier, perform more reps, do bodyweight exercises more easily).
  - Cardio performance (e.g., running, cycling, Zone 2 endurance).
  - Mobility and flexibility.
  - Body composition (DEXA scans, body fat percentage, lean muscle mass tracking).
  - Blood markers that reflect overall metabolic health.

## The best low-impact exercises for individuals with joint issues [52:00]

**Why Running Is Not Necessary for Most People with Joint Issues**

- Running can be stressful on joints, especially for those with knee, hip, ankle, or back problems.
- It isn’t necessary for cardiovascular fitness or overall health.
- There are many other effective, low-impact alternatives that provide similar or even better benefits without the stress on joints.

**Swimming: A Whole-Body, Low-Impact Workout**

- One of the best exercises for people with joint issues.
- Engages the entire body while keeping impact on joints to a minimum.
- High cardiovascular demand: Most people are inefficient swimmers, making it a naturally high-exertion workout.
- Two major drawbacks:
  - 1) Access limitations: Not everyone has easy access to a pool.
  - 2) No impact for bone density: Unlike weight-bearing exercises, swimming does not improve bone density, which is an important factor in long-term musculoskeletal health.
- Ideal when paired with strength training: This combination provides both cardiovascular and musculoskeletal benefits.

**Cycling: A Safe and Effective Low-Impact Exercise**

- Can be done indoors or outdoors, making it highly accessible.
- Minimizes stress on joints while still providing cardiovascular benefits.
- Good alternative for individuals with lower-body joint pain who still want to engage in aerobic activity.

**Rucking: A Surprisingly Low-Impact Strength and Cardio Option**

- Involves walking with a weighted backpack to add resistance.
- Less joint impact than running but still provides substantial cardiovascular and muscular benefits.
- Particularly effective on hills: Increases workload without requiring higher-impact movements.
- Benefits for bone density: The added load enhances strength and stability without excessive stress on joints.
- ⇒ See [episode #292](https://peterattiamd.com/jasonmccarthy/) with Jason McCarthy on rucking

**Stairmaster: A Controlled, Safe Alternative to Running**

- Walking on a stairmaster is low-impact but still engages the lower body effectively.
- Emphasizes concentric movement (going up), reducing strain from eccentric loading (like running downhill).
- Can be adjusted for intensity: Walking at a steady pace or incorporating short bursts of higher effort for interval training.

**Rowing: Full-Body, Low-Impact Cardio and Strength Training**

- Highly effective for cardiovascular endurance.
- Engages both the upper and lower body without placing undue stress on the joints.
- Can be modified for intensity based on an individual’s fitness level.
- A great option for people who want both strength and endurance training in a single movement.

**Considerations for Running and High-Impact Activities**

- Even for those without joint issues, running is not necessary for cardiovascular fitness.
- Personal example:
  - Peter used to run more when he was 30 pounds lighter.
  - Now, he rarely runs (maybe once per month) and only for high-intensity interval training (HIIT).
  - Running maximizes his heart rate better than cycling, but the joint risk outweighs the benefits.
- Over time, the risk of running-related injuries increases, making lower-impact alternatives a smarter choice for long-term health.

**Key Takeaways for People with Joint Pain Looking to Stay Active**

- Avoid running if it causes pain or discomfort.
- Opt for joint-friendly activities: Swimming, cycling, rucking, stair climbing, and rowing.
- Incorporate strength training to support joint health and bone density.
- Choose exercises based on accessibility and personal preference to ensure long-term consistency.

## Wearables: insight vs. compliance, and how to use them effectively [54:45]

**Wearables as Tools for Compliance vs. Insight**

- Framework for evaluating wearables:
  - Are they being used for compliance or insight?
  - Some devices can serve both purposes.
- Example: Continuous Glucose Monitors (CGMs)
  - Initially provide insight: People are shocked to see how food, stress, exercise, and sleep affect blood sugar.
  - Insight overload period: Typically lasts 30 to 90 days until patterns become predictable.
  - After that, becomes a compliance tool: Users modify behavior based on feedback, using it to gamify their choices (e.g., avoiding sugar spikes).

**Wearables as Behavioral Influencers**

- Peter’s anecdote on CGMs and diet choices:
  - While visiting family in Canada, he reminisced about childhood chocolates (Coffee Crisp, Aero bars).
  - His sister bought him a box of Coffee Crisps.
  - Someone joked, “You’re not wearing a CGM, are you?”
  - His response: “Hell no! If I was, I wouldn’t eat this because I wouldn’t want to see the blood spike.”
  - Example of how tracking can change behavior—people act differently when they are being monitored.

**Devices That Are Purely for Insight**

- [Morpheus](https://trainwithmorpheus.com/) (HRV Tracker) as an example:
  - Peter uses it daily for tracking heart rate and heart rate variability (HRV).
  - It helps predict his optimal Zone 2 heart rate with strong accuracy.
  - No compliance element—purely insight-driven.
  - Helps assess recovery levels and workout readiness.
  - While not necessary, it adds a gamification element that can be motivating.

**Sleep Trackers: Helpful or Harmful?**

- Can be valuable tools if used correctly.
- However, they can also cause anxiety for some users.
- Peter’s advice:
  - If someone develops insomnia due to stress from tracking sleep data, they should take a break from using the device.
  - Key takeaway: The irony of sleep trackers causing sleep problems means they should be used with caution.

**Key Takeaways on Wearables**

- Understand why you’re using them—for compliance, insight, or both.
- Be mindful of behavioral effects—wearables can change habits based on real-time feedback (e.g., CGMs preventing sugar intake).
- Some wearables are purely insight-based, while others influence behavior.
- Sleep trackers can be useful but may cause stress, requiring a break if they negatively impact sleep.

## How to evaluate the risks and benefits of medical interventions: procedural risks, complication rates, and asking informed questions [59:00]

**Understanding the Risks of Action vs. Inaction**

- Core question to ask: What is the risk of doing this, and what is the risk of not doing this?
- Example:
  - If you break your clavicle, should you undergo surgery or let it heal conservatively?
  - Understanding the risks of both choices is essential.
- Optionality:
  - Can you defer surgery and still do it later, or does delaying it close the window for a better outcome?
  - Some treatments allow flexibility; others eliminate future options (e.g., one type of surgery preventing another).
  - Example: If a patient is considering Procedure A, B, or C, understanding whether choosing one eliminates the possibility of doing the others.

**Risk Assessment: Population vs. Individual Risks**

- Understanding risk at two levels:
  - Population-based risk: General statistical risk of a procedure.
  - Surgeon-specific risk: How often has this specific surgeon encountered complications?
- Example: Getting a central line placed:
  - Standard risk data (population-level): The doctor provides general complication rates (e.g., pneumothorax, hemothorax).
  - Individual surgeon’s record: The doctor should know if their complication rates are higher or lower than national averages.
- Colonoscopy example:
  - Ask your endoscopist:
    - “What is your personal risk of perforation or bleeding?”
    - “Do the patients who develop complications look like me (in terms of age, health status), or are they in a different category?”
  - Key insight: If a doctor has a higher complication rate, it could be because they take on more complex cases.

**Why Understanding Risks Upfront Matters**

- Patients who are well-informed about potential complications tend to handle unexpected issues better.
- Doctors often fail at effectively communicating risk.
  - Many downplay risks or don’t explain them thoroughly.
  - Patients should take initiative in asking specific questions.
- Doctors should do a better job, but until then, patients must advocate for themselves.

**Should Doctors Know Their Own Complication Rates?**

“*Is it reasonable for a patient to ask their doctor about their complication rates?*“

- Yes, surgeons should know their first-order complication rates.
  - Examples of first-order complications a surgeon should track:
    - Wound infection rates
    - Re-operation rates
    - Conversion from laparoscopic to open surgery (for gallbladder removal, etc.)
  - What surgeons might not always track:
    - Indirect complications (e.g., a blood clot forming weeks after surgery).

**How to Ask These Questions Without It Feeling Awkward**

- Acknowledging the doctor-patient power dynamic:
  - It can feel awkward or intimidating to ask a surgeon about their complication rates.
- Tactful way to ask:
  - “Hey, I’m not asking this to judge you—I just want to set my expectations.”
- Higher complication rates don’t always mean a bad surgeon.
  - Best surgeons often take the hardest cases.
  - Example: In cardiac surgery, the highest mortality rates often belong to the most skilled surgeons, because they handle the most complex cases.
  - Key takeaway: Understand the context behind a surgeon’s statistics before making a decision.

**Key Takeaways for Patients Considering a Medical Intervention**

- Ask about both the risk of doing something and the risk of not doing it.
- Understand optionality: Will delaying the procedure close future treatment options?
- Know the difference between population-level risk and surgeon-specific risk.
- Be proactive in asking questions—don’t assume doctors will explain everything upfront.
- If a doctor doesn’t know their complication rates, consider it a red flag.
- Complication rates should be interpreted in context. High rates may indicate more difficult cases rather than poor skill.

## Sleep: impact on metabolic and cognitive health, and tips for improving sleep quality [1:03:45]

**Why Sleep is Critical for Health**

- Historical lack of attention to sleep:
  - Up until about a decade ago, sleep was largely ignored in medicine.
  - Figures like [Matthew Walker](https://peterattiamd.com/matthewwalker1/) and [Arianna Huffington](https://www.ariannahuffington.com/) helped bring much-needed attention to the field.
    - Matthew Walker episodes of The Drive can be found [here](https://peterattiamd.com/matthewwalker1/)
  - In medical school, sleep was never discussed, even though it plays a crucial role in health.
- Connection to chronic diseases:
  - Sleep disturbances [increase the risk of hypertension](https://www.nature.com/articles/hr201370#:~:text=Short%20sleep%20duration%2C%20sleep%20continuity%20disturbance%20(SCD)%2C,for%20SCD%2C%201.14%20(1.07%E2%80%931.20)%20for%20EMA%20and) (high blood pressure) by 20%.
  - Poor sleep can [lead to glucose dysregulation](https://pubmed.ncbi.nlm.nih.gov/10543671/), similar to non-insulin-dependent diabetes (Type 2 diabetes).
  - Despite its importance, physicians still frequently fail to inquire about a patient’s sleep quality when assessing conditions like high blood pressure or insulin resistance.
- Why sleep should be a priority:
  - When assessing insulin-resistant patients, their sleep quality should be just as much of a concern as diet and exercise.
  - Poor sleep negatively affects multiple aspects of health, making it essential to optimize.

**Challenges in Studying Sleep’s Long-Term Health Effects**

- Acute sleep deprivation can be studied experimentally:
  - Studies have [demonstrated](https://pmc.ncbi.nlm.nih.gov/articles/PMC4435718/) that reducing sleep to 4–5 hours per night for 1–2 weeks significantly worsens glucose metabolism.
  - Euglycemic insulin clamp [studies](https://pubmed.ncbi.nlm.nih.gov/10543671/) show profound reductions in glucose disposal, reinforcing the link between sleep and insulin resistance.
- Chronic sleep deprivation is harder to study due to reliance on epidemiology:
  - The long-term effects of sleep deprivation rely on observational studies rather than controlled experiments.
  - Confounding factors, like stress, make it difficult to isolate sleep’s direct effects on health outcomes.
  - There is strong evidence linking chronic sleep deprivation to [cardiovascular disease](https://peterattiamd.com/matthewwalker2/) and [dementia](https://peterattiamd.com/matthewwalker1/), but the data on cancer is less conclusive.
- Key takeaway:
  - Short-term sleep deprivation studies clearly show metabolic consequences.
  - Long-term effects are harder to prove definitively due to study limitations, but strong associations exist with major diseases.

**Framework for Improving Sleep**

- 80% of sleep problems are solved by good sleep hygiene.
- Key strategies for better sleep:
  - Consistent sleep schedule:
    - Go to bed and wake up at the same time every day, even on weekends.
    - Avoid “social jet lag”—where you sleep in dramatically later on weekends.
  - Limit pre-bed stimulation:
    - Avoid stressful activities before bed (e.g., work, news, social media).
    - Watching TV is okay, but be mindful of what you watch.
  - Optimize your sleep environment:
    - Keep the room dark and cold (cooler temperatures improve sleep).
  - Regulate food and alcohol intake before bed:
    - Avoid eating or drinking for at least three hours before bed to prevent waking up during the night.
    - Alcohol significantly disrupts sleep, so avoid drinking close to bedtime.
  - Be mindful of body temperature:
    - Eating before bed can raise core body temperature, leading to poor sleep quality.
    - Ensuring a cool room temperature can improve sleep onset and maintenance.

**Common Misconceptions About Sleep Improvement**

- People are often surprised by simple changes that dramatically improve sleep.
  - Many never considered the impact of eating before bed or room temperature on sleep quality.
  - Small habit adjustments can have major effects on sleep and overall health.
- Key takeaway:
  - Fixing sleep isn’t complicated—simple hygiene changes work for most people.
  - The key is consistency and removing disruptions from daily routines.

## How to identify and address emotional health challenges [1:08:30]

**Understanding Emotional Health: A Broad and Complex Issue**

- Emotional health is a broad topic that varies greatly by individual.
  - Some people seek to improve specific relationships (e.g., with a spouse, child, or parent).
  - Others struggle with internal feelings of emptiness, lack of joy, or absence of purpose.
- Success doesn’t always guarantee fulfillment.
  - Many highly successful individuals feel a sense of emotional emptiness, despite external achievements.
  - This seems counterintuitive, but achievement without purpose or connection can leave a person feeling unfulfilled.

**First Step: Identifying the Core Issue**

- Before seeking a solution, it’s critical to determine what needs to be addressed.
  - If the issue is related to relationships, the approach will differ from a more internal struggle like lack of fulfillment.
  - Understanding what is causing emotional discomfort is necessary before finding the right tools to address it.

**Tools & Strategies for Addressing Emotional Health**

*Self-Reflection & Introspection*

- “Feelings are data”—they are neither good nor bad, just signals that provide insight.
  - Instead of dismissing uncomfortable feelings, it is important to lean into them and analyze their cause.
  - Ignoring or avoiding emotional discomfort does not resolve the underlying issue.

*Journaling as a Tool for Self-Discovery*

- Journaling can be a powerful way to process and analyze emotions.
  - Writing helps to clarify thoughts and reveal subconscious patterns in behavior and emotions.
  - Peter personally finds that when he writes while in an emotionally difficult state, he can often identify key underlying issues.

*Therapy & External Support*

- A skilled therapist can provide structure and guidance for emotional self-exploration.
  - Many emotional challenges benefit from an outside perspective that can help uncover blind spots.
  - Therapy can provide tools to process emotions effectively, particularly for those struggling with relationships or a lack of purpose.

**Key Takeaways**

- Emotional health encompasses both external (relationships) and internal (purpose, joy) struggles.
- Identifying what specifically is causing distress is the most important first step.
- Self-reflection and journaling can be valuable tools for understanding emotional patterns.
- Therapy is highly beneficial for providing structured guidance in working through emotional difficulties.
- Ignoring emotional discomfort is ineffective—it’s essential to lean into it and seek resolution.

⇒ Check out this episode of The Drive: [#298 ‒ The impact of emotional health on longevity, self-audit strategies, improving well-being, and more | Paul Conti, M.D.](https://peterattiamd.com/paulconti4/)

---

## Selected Links / Related Material

**Resources on lipoprotein(a) [Lp(a)]**: [3:00]

- Podcast: [#07 – Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know](https://peterattiamd.com/lpa/)
- Podcast: [#210 – Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.](https://peterattiamd.com/benoitarsenault/)
- Podcast: [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/)

**Resources on Familial Hypercholesterolemia (FH)**: [3:00]

- Podcast: [#255 ‒ Latest therapeutics in CVD, APOE’s role in Alzheimer’s disease and CVD, familial hypercholesterolemia, and more | John Kastelein, M.D., Ph.D.](https://peterattiamd.com/johnkastelein/)
- [More resources](https://peterattiamd.com/?s=Familial%20Hypercholesterolemia%20(FH))

**Calcium Scan (CAC) resources**: [3:00]

- Article: [Coronary artery calcium scan](https://peterattiamd.com/coronary-artery-calcium-scan/)
- Podcast: [#247 ‒ Preventing cardiovascular disease: the latest in diagnostic imaging, blood pressure, metabolic health, and more | Ethan Weiss, M.D.](https://peterattiamd.com/ethanweiss2/)
- Podcast: [#203 – AMA #34: What Causes Heart Disease?](https://peterattiamd.com/ama34/)

**ApoB resources**: [3:00]

- Podcast: [#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB](https://peterattiamd.com/understanding-cardiovascular-disease/)
- Article on apoB: [Measuring cardiovascular disease risk and the importance of apoB](https://peterattiamd.com/measuring-cardiovascular-disease-risk-and-the-importance-of-apob-part-1/)
- Podcast: [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/)

**Blood pressure resources**: [3:00]

- Article: [All things blood pressure: from measurement to management](https://peterattiamd.com/all-things-blood-pressure/)
- Podcast: [#258 – AMA #48: Blood pressure—how to measure, manage, and treat high blood pressure](https://peterattiamd.com/ama48/)

**More on time-restricted eating and fasting**: [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/) | Peter Attia (peterattiamd.com) [9:00]

**Peter’s book covers many of the topics discussed in this episode**: [OUTLIVE: The Science & Art of Longevity](https://peterattiamd.com/outlive/) by Peter Attia (peterattiamd.com) [13:00]

**Large JAMA study on alcohol consumption**: [Association Between Daily Alcohol Intake and Risk of All-Cause Mortality](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2802963) (Zhao et al., 2023) [14:00]

**Mendelian Randomization Studies (Genetic Studies) suggest a linear increase in risk, meaning even low levels of alcohol increase mortality risk**: [Association of Habitual Alcohol Intake With Risk of Cardiovascular Disease](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2790520) (biddinger et al., 2022) [15:00]

**Article from Peter on alcohol**: [Is low-to-moderate alcohol consumption beneficial for longevity?](https://peterattiamd.com/low-to-moderate-alcohol-consumption-and-longevity/) | Peter Attia (peterattiamd.com) [20:00]

**AMA episode of The Drive on DEXA scans**: [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/) | Peter Attia (peterattiamd.com) [27:00]

**Episode of The Drive with Mark Hyman where he touched on regenerative agriculture**: [#94 – Mark Hyman, M.D.: The impact of the food system on our health and the environment](https://peterattiamd.com/markhyman/) | Peter Attia (peterattiamd.com) [28:00]

**Resources on zone 2 training**: [Exercise – zone 2 training](https://peterattiamd.com/tag/exercise-zone-2-training/) | (peterattiamd.com) [44:00]

**Episode of The Drive with Jason McCarthy that discusses the health benefits of rucking**: [#292 ‒ Rucking: benefits, gear, FAQs, and the journey from Special Forces to founding GORUCK | Jason McCarthy](https://peterattiamd.com/jasonmccarthy/) | Peter Attia (peterattiamd.com) [53:00]

**Wearable purely for insights that tracks HRV (among other things) that Peter uses**: [Morpheus](https://trainwithmorpheus.com/) [57:45]

**Episode of The Drive about sleep with Matthew Walker**: [1:04:00]

- (April 1, 2019) [Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, and memory](https://peterattiamd.com/matthewwalker1/)
- (April 8, 2019) [Part II of III: Heart disease, cancer, sexual function, and sleep disruption](https://peterattiamd.com/matthewwalker2/)
- (April 15, 2019) [Part III of III: The penetrating effects of poor sleep from metabolism to genetics](https://peterattiamd.com/matthewwalker3/)
- (June 17, 2019) [AMA #1: Strategies for sleeping more and sleeping better](https://peterattiamd.com/matthewwalkerama/)
- (October 28, 2019) [AMA #2: short sleep mutants, optimal sleep environment, & sleep apnea](https://peterattiamd.com/matthewwalkerama2/)
- (August 31, 2020) [Sleep & Covid-19: Sleep and immune function, chronotypes, and hygiene tips](https://peterattiamd.com/matthewwalker4/)
- (September 7, 2020) [AMA #3: Fasting, gut health, blue light, caffeine, REM sleep, and more](https://peterattiamd.com/matthewwalkerama3/)

**Sleep disturbances increase the risk of hypertension (high blood pressure) by 20%**: [The relationship of sleep duration and insomnia to risk of hypertension incidence: a meta-analysis of prospective cohort studies](https://www.nature.com/articles/hr201370#:~:text=Short%20sleep%20duration%2C%20sleep%20continuity%20disturbance%20(SCD)%2C,for%20SCD%2C%201.14%20(1.07%E2%80%931.20)%20for%20EMA%20and) (Meng et al., 2013) [1:05:00]

**Chronic sleep disturbances can present with nearly as dysregulated a glucose as a person who shows up with non-insulin-dependent diabetes**: [Impact of sleep debt on metabolic and endocrine function](https://pubmed.ncbi.nlm.nih.gov/10543671/) (Spiegel et al., 1999) [1:05:00]

**Studies have demonstrated that reducing sleep to 4–5 hours per night for 1–2 weeks significantly worsens glucose metabolism**: [Impaired Insulin Signaling in Human Adipocytes After Experimental Sleep Restriction](https://pmc.ncbi.nlm.nih.gov/articles/PMC4435718/) (Broussard et al., 2015) [1:06:00]

**Euglycemic insulin clamp studies show profound reductions in glucose disposal, reinforcing the link between sleep and insulin resistance**: [Impact of sleep debt on metabolic and endocrine function](https://pubmed.ncbi.nlm.nih.gov/10543671/) (Spiegel et al., 1999) [1:06:00]

**There is strong evidence linking chronic sleep deprivation to cardiovascular disease and dementia, but the data on cancer is less conclusive**: [1:07:00]

- Dementia: [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/)
- CVD: [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/)

**Episode of The Drive on emotional health**: [#298 ‒ The impact of emotional health on longevity, self-audit strategies, improving well-being, and more | Paul Conti, M.D.](https://peterattiamd.com/paulconti4/) | Peter Attia (peterattiamd.com) [1:08:30]

---

## People Mentioned

- [Matthew Walker](https://peterattiamd.com/matthewwalker1/) (sleep researcher) [1:04:15]
- [Arianna Huffington](https://www.ariannahuffington.com/) (sleep researcher) [1:04:15]