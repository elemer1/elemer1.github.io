# #290 ‒ Liquid biopsies for early cancer detection, the role of epigenetics in aging, and the future of aging research | Alex Aravanis, M.D., Ph.D.

**Source:** [https://peterattiamd.com/alexaravanis/](https://peterattiamd.com/alexaravanis/)

---

Alex Aravanis is a leader in research and development of technologies and clinical tests utilizing the latest tools in DNA analysis and data science. In this episode, Alex delves into two interconnected topics: liquid biopsies and epigenetics. He begins by tracing the trajectory of genome sequencing and tumor sequencing, setting the stage for a detailed exploration of liquid biopsies as an early cancer detection method. The discussion encompasses key concepts such as cell-free DNA, DNA methylation, sensitivity, specificity, and the predictive values associated with liquid biopsies. Transitioning to epigenetics, Alex examines the intricate interplay of DNA methylation and aging biology and explores the possibility of using cellular reprogramming to reverse epigenetic changes that occur with aging.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/alexaravanis/the_Drive_public.png)

Play

#290 ‒ Liquid biopsies for early cancer detection, the role of epigenetics in aging, and the future of aging research | Alex Aravanis, M.D., Ph.D.

#290 ‒ Liquid biopsies for early cancer detection, the role of epigenetics in aging, and the future of aging research | Alex Aravanis, M.D., Ph.D.

1x15s30s

0:002:05:32

## We discuss:

- Alex’s background in applying engineering to problems in medicine [3:15];
- A primer on human genetics, and the history and current landscape of DNA sequencing [11:00];
- The advent and evolution of liquid biopsies for early detection of cancer [23:15];
- The role of cell-free DNA in cancer detection: how incidental findings in non-invasive prenatal testing led to the development of liquid biopsies [40:15];
- The development of a universal blood test for cancer detection, and a discussion of specificity of tests [46:00];
- Advancements in cell-free DNA analysis and development of a multi-cancer screening test at GRAIL [51:00];
- DNA methylation explained [58:15];
- Optimizing cancer detection with methylation analysis of cfDNA in small blood samples [1:02:45];
- The importance of understanding sensitivity, specificity, positive predictive value, and negative predictive value in cancer screening [1:08:00];
- The performance of the GRAIL Galleri test and its ability to detect various types and stages of cancer [1:21:00];
- Do early cancer detection methods, like liquid biopsies, translate to improvement in overall survival? [1:27:45];
- The role of epigenetics in aging [1:39:30];
- How cell-free DNA methylation patterns can help identify a cancer’s tissue of origin [1:45:30];
- Cellular and epigenetic reprogramming, and other exciting work in the field of aging [1:52:30]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Alex Aravanis is the CEO and co-founder of [Moonwalk Biosciences](https://moonwalk.bio/)
- Peter notes upfront that he is also an investor and an advisor to Moonwalk Biosciences
- Alex and Peter were colleagues in medical school
  - Peter has known Alex a little over 25 years
- Before Moonwalk, Alex was [Illumina’s](https://www.illumina.com/) chief technology officer, the SVP, and head of research and product development
  - Under his leadership Illumina launched the industry-leading product for generating and analyzing most of the world’s genomic data
  - He developed large genome based research and clinical applications
    - Including whole genome sequencing for rare disease diagnosis
    - Comprehensive genomic profiling for cancer and for selected optimal therapies
    - The most advanced AI tools for interpreting genomic information
- Alex has been the founder of several biotech and healthcare companies
  - Including GRAIL Bio, where he served as the chief science officer and head of R&D
- At GRAIL he led the development of it’s multi-cancer, early screening test [Galleri](https://grail.com/galleri-test/)
  - Which we’ll discuss at length in this podcast
- He holds over 30 patents and serves on the scientific advisory board for several biotechnology companies
- Alex received his masters and Ph.D. in electrical engineering and his M.D. from Stanford University
  - He completed his undergrad in engineering at Berkeley
- In this episode, we talk about 2 related things: liquid biopsies and epigenetics
- We cover the evolution of genome sequencing and tumor sequencing
- We then speak at length about Alex’s work with GRAIL and liquid biopsies
  - Including an understanding of cell-free DNA, methylation, sensitivity, specificity, along with the positive and negative predictive value of liquid biopsies
- Then we get into epigenetics, methylation, and the biology of aging
  - This is an especially complicated topic, but truthfully, there are few topics in biology today that excite Peter more than this

## Alex’s background in applying engineering to problems in medicine [3:15]

- Peter and Alex both started med school together
- One of the things Peter remembers when they first met was that they clicked over the fact that they both were engineers
  - They had a good group of friends, and not of them was a pre-med
  - They all followed a non-traditional path to medical school
- Alex came to Stanford University as an electrical engineer and did a Ph.D. in the lab of [Dick Tsien](https://med.nyu.edu/faculty/richard-tsien), a very prominent scientist

**Tell folks a little bit about what you did in that work and what it was that got you excited enough about science to deviate off the traditional MD path**

- Alex did his Ph.D. in electrical engineering
- Stanford has a cool configuration on the campus where the engineering school is literally across the street from the medical school
- Over time, he became more and more interested in applying signal processing techniques (circuit design, imaging, AI, things like that) with the problems in medicine that were more interesting than some of the traditional engineering products
- Alex met world-famous neuroscientists
- Dick Tsien, who’s very interested in fundamental questions about the quantum unit of communication in the brain (which is the individual [synaptic vesicle](https://en.wikipedia.org/wiki/Synaptic_vesicle))
  - And there was a question of just what did it look like and how did it operate?

***This was the beginning applying these engineering tools to really important questions in biology and helping answer them***

- That first story was a great article in [*Nature*](https://pubmed.ncbi.nlm.nih.gov/12789339/) where we definitively answered the question of how that quantum is transmitted between cells, and then we went on to do several other projects like that

**How is that information transmitted?**

- Alex explains, “*It was really fun to come at these problems with an engineering and communications background, but if you look at a central neuron on the brain and you look at the rate at which information is transferred, it seemed to be much faster than the number of synaptic vesicles in the terminal*.”
- There’s only 30 synaptic vesicles in the terminal by an electron microscope, yet you’re seeing hundreds of transmissions over a few seconds
  - So how is that possible?
  - There were various theories
- There was an individual vesicle that was fusing and staying fused and pumping neurotransmitters through it without collapsing
  - And that’s how you could get these much more rapid pumps
- We came up with a cute term called “kiss and run,” to explain the phenomenon
  - It helped answer this fundamental question of question of how did the brain get so many small neurons yet able to transmit so much information per individual connection
- Peter points out that one of the benefits of Alex doing his Ph.D. at Stanford, in [Tsien’s](https://med.nyu.edu/faculty/richard-tsien) lab was that he overlapped with some other really thoughtful folks
  - Including [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth), a previous guest on the podcast [[episode #191](https://peterattiamd.com/karldeisseroth/)]

**During your Ph.D., what were the most important things you learned philosophically (not necessarily technically) that are serving you in the stuff we’re going to talk about today (liquid biopsies and epigenetics)?**

*When you think back to your background in electrical engineering, what were the transferable skills?*

- 1 – There is a saying in engineering, “*If you can’t build it, you don’t understand it*.”
  - So simply understanding a description of something is not the same as you can build it up from scratch
  - You can’t always do that in biology, but you can do experiments where you’re testing the concept of “can I really make it work”
    - That was an engineering concept that served Alex well
- 2 – Another, it’s not exclusive to engineering, but was being very first principled: do we really understand how this works?
  - In that particular lab, there’s a big emphasis on doing experiments where you always learn something, where regardless of whether or not it confirmed or rejected your hypothesis
    - You learn something new about the system
  - Don’t do experiments where you may just not learn anything
    - That was a very powerful way to think about things

**Fast-forward to circa 2012 when Alex was at Illumina for the first time**

*Tell folks a little about the company and what you were recruited to do*

- Illumina is the largest maker of **DNA sequencing technologies**
- So when you hear about the human genome being sequenced, things like expression data, [RNA-Seq](https://en.wikipedia.org/wiki/RNA-Seq), most [liquid biopsies](https://en.wikipedia.org/wiki/Liquid_biopsy), most tumor sequencing, finding genetic variants in kids with rare disease ‒ most of that is done with Illumina technology
- They also make the chemistries that process the DNA, the sequencers that generate that information, and the software that helps analyze it
- Alex really took that tool from a very niche research technology to standard of care in medicine
  - In hundreds of thousands of publications and tremendously it has been advancing science

***What attracted Alex to the company and why he was recruited was to help develop more clinical applications and more applied applications of the technology***

- The technology had been used by sequencing aficionados for basic research, but it could be used for more
  - The company and Alex agreed that it could be used to help every cancer patient, every person with a genetic disease
- The question was: how to develop the technology (and other aspects of it, the assays and softwares) to make that a reality
  - That was what Alex was hired to do

## A primer on human genetics, and the history and current landscape of DNA sequencing [11:00]

- Peter points out that many take for granted some of the lingo involved with sequencing, but it might be a bit of a black box to some people listening

**Explain what was done in the late ‘90s, early 2000s when the human genome was sequenced and how DNA sequencing has changed**

*A quick primer on human genetics*

- Most cells in the body have 23 pairs of [chromosomes](https://en.wikipedia.org/wiki/Chromosome)
  - They’re very similar, except the X and Y chromosome (which are obviously different in men and women)
- Each one of those chromosomes is actually a lot of DNA packed together in a very orderly way [summarized in the figure below]
  - Where the DNA is wrapped around proteins called [nucleosomes](https://en.wikipedia.org/wiki/Nucleosome), which are composed of [histones](https://en.wikipedia.org/wiki/Histone)
  - And then it’s packed into something called [chromatin](https://en.wikipedia.org/wiki/Chromatin), which is this mass of  DNA and proteins
  - And again, packed together and then you make these units of chromosomes

![](https://peterattiamd.com/wp-content/uploads/2024/02/f1-alexaravanis.png)

**Figure 1. Packing of DNA into chromatin to form a chromosome**. Image credit: [Scitable](https://www.nature.com/scitable/topicpage/dna-packaging-nucleosomes-and-chromatin-310/)

- Now, if you were to unwind all of those chromosomes
  - “Pull the string on the sweater” and completely unwind it, and if you were to line all of them end-to-end, you would have 3 billion individual bases
    - So the ATCG code at any given of one of those 3 billion positions, you would have a string of letters
    - Each one would either be A, T, C or G, and it would be 3 billion long

***To sequence a whole human genome is to read out that code for an individual***

- And once you do that, you then know their particular code at each of those positions
- At the end of the last century, that was considered quite a daunting task, but our country and others decided that it was a very worthy one to do
  - And so they funded the [Human Genome Project](https://www.genome.gov/human-genome-project), and all over the world at centers, people were trying to sequence bits of this 3 billion bases to comprise the first complete human genome

**There were 2 efforts to sequence the first human genome**

- One was a public effort led by the NIH and [Francis Collins](https://irp.nih.gov/pi/francis-collins) at the time
  - They had a particular approach where what they were doing was they were cutting out large sections of the genome and then using an [older type of sequencing method](https://en.wikipedia.org/wiki/Sanger_sequencing), called [capillary electrophoresis](https://en.wikipedia.org/wiki/Capillary_electrophoresis), to sequence each of those individual bases
- There was a private effort led by [Craig Venter](https://www.jcvi.org/about/j-craig-venter) and a company called [Celera](https://en.wikipedia.org/wiki/Celera_Corporation), which took a very different approach
  - They cut up the genome into much, much smaller pieces, pieces that were so small that you didn’t necessarily know a priority, what part of the genome they would come from
    - Which is why they were doing this longer, more laborious process through the public effort
- But there was a big innovation, which is they realized that if you had enough of these fragments, you could, using a mathematical technique, reconstruct it from these individual pieces
  - You could take individual pieces and look at where they overlap
  - Again, we’re talking about billions of fragments here, and you can imagine mathematically reconstructing that is very computationally intensive, very complex
  - But the benefit of that is that you could generate the data much, much faster
- And so in a fraction of the time and for a fraction of the money, this private effort actually caught up to the public effort
- This culminated in each having a draft of the human genome around the same time in late 2000, early 2001
  - Then simultaneously, in *Nature* and *Science*, we got the first draft of the human genome milestone in science

**What were the approximate lengths of the fragments that Celera was breaking DNA down into?**

- They were taking chunks out in individual megabases, so a million bases at a time
- And then they would isolate that and then deconstructed even into smaller pieces, which were kilobase fragments (a thousand bases at a time)
- So they would take a piece of the puzzle, but they would know which piece it was, and then break that into smaller and smaller ones
- Then after you had the one kilobase sequences, they would put it all back together
- Contrast that with the private effort, which they called [shotgun sequencing](https://en.wikipedia.org/wiki/Shotgun_sequencing), which is you just took the whole thing, round it up, brute force sequenced it, and then used the informatics to figure out what went where

**In shotgun sequencing, how small were the DNA fragments broken down into?**

- They got down to kilobase and hundred base, multi-hundred base fragments

***But the key difference was all you had to do was keep sequencing (just brute force) as opposed to this more artisanal approach of trying to take individual pieces and deconstruct them and then reconstruct them***

**Do we know the identity of the individual whose genome was first sequenced?**

- Alex thinks the original one is still anonymous and likely a composite of multiple individuals
  - Just because of the amount of DNA required
- Soon after, the genomes of individuals were sequenced
  - Craig Venter may have been the first individual who is named that we had the genome for

**What technology reduced the cost of sequencing a human genome?**

- Peter points out that the cost of sequencing a human genome initially was a billion dollars
  - This was $9-10 per sequence
- Alex explains that by 2012, the cost of sequencing the human genome was in the low tens of thousand of dollars
  - Let’s call that 4-5 logs of improvement
- It was a series of inventions that allowed the sequencing reactions to be miniaturized
- And then you could do orders of magnitude, more sequencing of DNA by miniaturizing it
- The older sequencers, they had a small glass tube, and as the DNA went through, you sequenced
- This got converted into a 2D format, kind of like a glass slide, where you had tiny fragments of DNA stuck to it, hundreds of millions, then ultimately billions, and then you sequenced all of them simultaneously
- So there was a huge miniaturization of each individual sequencing reaction, which allowed you to just in one system to generate many, many more DNA sequences at the same time
- There’s a very important chemistry that was developed called [sequencing by synthesis](https://en.wikipedia.org/wiki/Illumina_dye_sequencing), by a Cambridge chemist who Alex knows well, [Shankar Balasubramanian](https://www.ch.cam.ac.uk/person/sb10031)
  - He developed Illumina sequencing chemistry, which ultimately went through a company called Celexa, which Illumina acquired, and that has generated the majority of the world’s genomics data
  - The original chemistry that he developed in Cambridge

**What was it about that chemistry that was such a step forward?**

- It allowed you to miniaturize the sequencing reactions
- So you could have a huge number (ultimately billions) in a very small glass slide
- It also allowed you to do something which is called **cyclic sequencing** in a very precise and efficient and fast way where you read off one base at a time and you can control it
  - You imagine you have say a lawn of a billion DNA fragments and you’re on base 3 on every single fragment and you want to know what base 4 is on every fragment
  - It allowed you to simultaneously sequence just 1 more base on all billion fragments, read it out across your whole lawn, and then once you read it out, add 1 more base, read it all out
  - And so this allowed for this huge parallelization

## Advances that have lowered the cost of genome sequencing [20:00]

Current landscape of genome sequencing

**Current cost of genome sequencing**

- The last time Peter looked, it cost on the order of $500-1000 to sequence the whole human genome

*Is that accurate?*

- That’s way to expensive
- Today it’s a couple hundred dollars
- Peter has noticed that this has improved faster than Moore’s law
- [Moore’s law](https://en.wikipedia.org/wiki/Moore%27s_law) is not a law of physics or something like that, but it became an industry trend in microprocessors
  - It refers to the density of transistors on a microchip and the cost of the amount of computing power per amount of transistors
  - And that geometrically decreased in a steady way
    - Something on the order of doubling every 2 years
    - But there was a geometric factor to it that the industry followed for decades starting in the late ‘60s
    - It’s not quite following that anymore
    - Transistors are getting down to the atomic scale, but that went way faster than people had envisioned
  - So that relentless push is what made the whole software engineering/ high-tech industry possible

*If you just look at the cost of sequencing from 2000 till today, it’s sort of like two curves*

- There’s the relentless curve that gets to where we are in 2013, but then there was another big drop in price that occurred after that
- Alex explains that when [Illumina](https://www.illumina.com/) really started to deliver the higher throughput next-generation sequencing, it brought along a new faster curve because of the miniaturization
  - This ability to sequence billions of fragments in a small area
  - He was privileged to be a big part of this effort

***And Illumina just continued to drive the density down, the speed of the chemistry up, all the associated optics, engineering software around it drove that much faster than Moore’s law reduction in cost***

**Were other companies involved in the culmination of next-gen sequencing?**

- Yeah, many
- Some of them are still around, but none are nearly as successful as Illumina

**The vast majority of sequencing being done is next-generation sequencing**

- There’s niche applications where other approaches are used, but 99% of the data being generated is some version of next-generation sequencing

## The advent and evolution of liquid biopsies for early detection of cancer [23:15]

**Where in your journey did the idea of liquid biopsies come up?**

*Talk a little about the history of one of the companies in that space*

- Tumor sequencing predated liquid biopsy
- A couple companies developed tumor sequencing
  - Most notably [Foundation Medicine](https://www.foundationmedicine.com/) was the first to do it successfully as a clinical product
    - Developed using Illumina technology
- You can imagine is there are these genes that are implicated in cancer that often get mutated
  - Knowing which mutations a tumor has big implications for prognosis, but also for treatment
  - Over time, we have more and more targeted therapies where if your tumor has a very particular mutation, it’s more likely to respond to certain drugs that target that type of tumor
  - At the time, as more and more of these mutations were identified that could be important in the treatment of a tumor, it was becoming impractical to do a [PCR test](https://en.wikipedia.org/wiki/Polymerase_chain_reaction) for every mutation
- Imagine there’s 100 potential mutations you’d like to know about if a patient has a tumor in their lung
  - Testing for each of these individually is expensive and you can get a lot of [false positives](https://en.wikipedia.org/wiki/False_positives_and_false_negatives#False_positive_error)
- What companies like Foundation Medicine do is sequence all of these positions at once with next-generation sequencing
  - They would make a panel to sequence say 500 hundred genes, the one that are most important in most solid cancers
  - Then they would sequence them in 1 test
  - This would allow them to see the vast majority of the potential mutations that could be relevant to treatment for that cancer patient
    - And so that is still a very important tool

> “*In oncology today, a large fraction of tumors are sequenced, and that’s what allows people to get access to many types of drugs.*”‒ Alex Aravanis

- Many of the targeted therapies for lung cancer, melanoma ‒ that all comes from tumor sequencing
  - Or you hear about things like microsatellite instability or high mutational burden
- Once that was established, then a few folks (most notably at [Johns Hopkins](https://www.hopkinsmedicine.org/kimmel-cancer-center/research/ludwig-center), but also other places) started to ask the question, “*Well, could we sequence the tumor from the blood?*”
- And you might say, “*Well, hey, you have a tumor in your lung, why would sequencing blood be relevant to looking at the tumor?*”

**It turns out there is tumor DNA in the blood, and this is interesting**

- In the late ‘40s, it was first identified that there was DNA in the blood outside of cells, so-called [cell-free DNA [cfDNA]](https://en.wikipedia.org/wiki/Circulating_free_DNA)
- Then in the ‘70s, it was noticed that cancer patients had a lot of DNA outside their cells in the blood, and that some of this was likely from tumors from the cancer itself [[circulating tumor DNA, ctDNA](https://en.wikipedia.org/wiki/Circulating_tumor_DNA)]

**If you know anything about tumor biology, you know that cancer cells are constantly dying**

- We think of cancers as growing very quickly, and that’s true, but they actually are dying at an incredible rate because it’s disordered growth
- Many of the cells that divide have all kinds of genomic problems, so they die or they’re cut off from vasculature
- The crazy thing about a tumor is, yes, it’s growing fast if it’s an aggressive tumor, but also the amount of cell death within that tumor is also very high
- And every time one of those cells die, some of the DNA has the potential to get into the bloodstream

**It was this insight along with the tumor sequencing that said,** ***“Hey, what if we sequence this cell-free DNA, could we end up sequencing some of the tumor DNA or the cancer cell DNA that’s in circulation.”***

- Early results (particularly from this [group at Johns Hopkins](https://www.hopkinsmedicine.org/kimmel-cancer-center/research/ludwig-center)) began to show that indeed that was possible
- Then a few companies, again using Illumina technology
- Then we started doing it at Illumina also

***Assays and tests and technologies developed at Illumina became the liquid biopsy***

- In this context, it was for late-stage cancer
  - It was for patients who were diagnosed with a cancer and you wanted to know if their tumor had mutations, and you could do it from the blood
- There was a big benefit for **lung cancer, as taking a biopsy can be a very dangerous** proposition
  - You can cause a [pneumothorax](https://en.wikipedia.org/wiki/Pneumothorax), you can land someone in the ICU
  - In rare cases it can lead to death in that type of procedure

***The ability to get the mutational profile from the blood was really attractive, and that started many companies down the road of developing these liquid biopsies for late-stage cancers***

**Tell me the typical length of a cell-free DNA fragment. How many base pairs or what’s the range?**

- It depends on the exact context, but around 160 base pairs
  - So that’s 160 letters of the ATCG code
- There’s a very particular reason it’s that length, which is that if you pull the string on the sweater, you will unwind the chromosome and you keep doing it until you get down to something around 160 base pairs, what you find is that the DNA, it’s not just naked, it’s wrapped around something called a [nucleosome](https://en.wikipedia.org/wiki/Nucleosome) [shown in the previous figure]
  - A nucleosome is an octamer (or 8) of these [histone proteins](https://en.wikipedia.org/wiki/Histone) in a cube and the DNA is wrapped around it twice
    - And that’s the smallest unit of [chromatin](https://en.wikipedia.org/wiki/Chromatin) of this larger chromosome structure
  - The reason it’s 160 bases is that’s more or less the geometry of going around twice
  - And so DNA can be cleaved by enzymes in the blood, but that nucleosome protects the DNA from being cut to anything smaller than about 160 base pairs

*Does that mean that the cell-free DNA that is found in the blood is still wrapped around the nucleosome twice? It’s still clinging to that and that’s protecting it from being cleaved any smaller?*

- That’s right

**The first application of liquid biopsies was to figure out the mutation present in late-stage cancers without requiring a tissue biopsy**

- Peter presumes that it was easy to gather hundreds of 160 base pair fragments and use the same sort of mathematics to reassemble them based on the few overlaps to say this is the actual sequence because presumably the genes are much longer than 160 base pairs that they’re looking at
  - That’s right
- By this point in 2014, 2015 the informatics was quite sophisticated
  - You could take a large number of DNA sequences from fragments and easily determine which gene it was associated with

**Other uses of liquid biopsy in cancer**

- Peter recalls a discussion with [Max Diehn](https://med.stanford.edu/diehnlab.html?tab=proxy) on the podcast maybe a year and a half ago [[episode #213](https://peterattiamd.com/maxdiehn/)] (another one of their med school classmates) about looking at cancer recurrences in patients who were clinically free of disease

*The question becomes, is the cancer recurring?*

- The sooner we find out, the better our change at treating it because it’s a well established fact in oncology that the lower the burden of tumor, the better the response
  - The lower the mutations, the less escapes, etc.

*Did that become the next iteration of this technology, which is, if we know the sequence of the tumor, can we go fishing for that particular tumor in the cell-free DNA?*

- Yeah
- Broadly speaking, there’s 3 applications for looking at tumor DNA in the blood
- 1 – **Screening** (which we’ll talk about later), which is people who don’t have cancer (or 99% who don’t) and trying to find the individual who has cancer and invasive cancer but doesn’t know it
- 2 – There’s this application of what we call **therapy selection**, which is you’re a cancer patient trying to decide which targeted therapy would be best for you
- 3 – The other one previously mentioned is what we call **opt-in minimal residual disease**: we’re looking at monitoring a response, which is you’re undergoing treatment and you want to know: is the amount of tumor DNA in the blood undetectable and also its velocity (is it changing)
  - That could tell you if your treatment working
  - Is the tumor DNA burden (or load) going down?
    - Is it undetectable and you’re potentially cured, that there’s no longer that source of tumor DNA in your body?
    - Or is it present even after a treatment with intent to cure?
  - The presence of that tumor DNA still means basically, unfortunately you have not been cured, because there is some nidus of tissue somewhere that still harbors these mutations and therefore is the tumor, even if it’s not detectable by any other means

**At what point does this company called** [**GRAIL**](https://grail.com/) **(that we’re going to talk about) come into existence, and what was the impetus and motivation for that as a distinct entity outside of Illumina?**

- There were several technological and scientific insights that came together along with some really old entrepreneurs and investors
- The use of this liquid biopsy technology in late-stage cancers showed it was clearly possible to sequence tumors from the blood
  - And it was clearly actually the tumor DNA and it was useful for cancer patients
- We knew it could be done, but what the field didn’t know is could you see this in early stage cancers, localized cancers that were small?
  - There was not a lot of data on that, but there was the potential

*There was also a really interesting incidental set of findings in a completely different application called* [*noninvasive prenatal testing* [NIPT]](https://en.wikipedia.org/wiki/Noninvasive_prenatal_testing)

- This is a totally different application; it was discovered, principally by a scientist in Hong Kong named [Dennis Lo](https://www.cuhk.edu.hk/med/cpy/Research/DennisLo.htm), that you could see fetal DNA in the blood, or more specifically placental DNA in the blood, and it was also cell-free DNA
  - What he developed along with one of the professors at Stanford ([Steve Quake](https://med.stanford.edu/profiles/stephen-quake?microsite=cap-profiles-home&tab=cap-profiles-home)) was a technique to look for [trisomies](https://en.wikipedia.org/wiki/Trisomy) in the blood based on this placental or fetal DNA, and this is called noninvasive prenatal testing
- What you do is, you sequence the cell-free DNA fragments in a pregnant woman, you look at the DNA, and if you see extra DNA, for example, at the position of chromosome 21, well, that indicates that there are tissues in the woman that’s giving off extra chromosome 21 (presumably the fetus or placenta)
- And so this ended up being an incredibly sensitive and specific way to test for the presence of trisomies (chromosome 21, 18, 13) early in pregnancy, and it’s had a tremendous impact
- NIPT was also involved in subsequent iterations of the test in the United States
  - It decreased amniocentesis by about 80%, because the test is so sensitive and specific as a screen that many, many women have now not had to undergo amniocentesis and the risks around that
- Again, it’s a totally different application of cell-free DNA

***But what happened is, during the early commercialization of about the first few hundred tests, one of the companies pioneering this (called Verinata that Illumina acquired) began to see in rare cases very unusual DNA patterns***

- It wasn’t just a chromosome 21 or 18 or 13, but what’s often called [chromothripsis](https://en.wikipedia.org/wiki/Chromothripsis), which is many, many aberrations across chromosomes
- The two women who really did this analysis and really brought both Illumina and the world’s attention to it were [Meredith Halks-Miller](https://bioevolutionlabs.com/team/meredith-miller-md/), a pathologist and lab director at this Illumina-owned company, Verinata, and another bioinformatics scientist, [Darya Chudova](https://www.linkedin.com/in/darya-chudova-78b28513/)
- What they showed is ultimately that these women actually had cancer
  - They were young women of childbearing age, they ultimately had healthy children, but they had an invasive cancer, and it was being diagnosed in their cell-free DNA by this noninvasive prenatal test
- As they began to show these patterns to people, it became clear that they were cancer
  - If you have many, many chromosomes that are abnormal, that’s just not compatible with life or a fetus
  - So when you saw these genome-wide chromosomal changes, it was very clear that we’re incidentally finding cancer in these women

**Peter’s recap**: whenever you say we’re sampling for cell-free DNA, we should all be keeping in the back of our mind, that we’re looking for these teeny, tiny little 160 base pair fragments, wrapped around little nucleosomes

Peter asks, “*Now, let’s just go back to the initial use case around trisomy 21. With 160 base pairs, is that sufficient to identify any one chromosome? Presumably, you’re also sampling maternal blood, so you know what the maternal chromosomes look like, and you’re presumably juxtaposing those two as your control. Is that part of it?*”

- Not quite, it’s all mixed together
  - In maternal blood, it’s a mixture
  - The majority of the cell-free DNA is from her own cells and tissues, and then you have superimposed on that a bit of cell-free DNA mostly from the placenta
  - And so what you’re seeing is this mix of cell-free DNA
- Then what you do is ***you sequence it***, and there’s different ways to do it, but most common way is to do shotgun sequencing, and you sequence millions of these fragments
  - Every time you sequence a fragment, you place it in a chromosome based on its sequence (compared this to the draft human genome)
  - This will tell you for example that the 1st fragment goes on chromosome 2
  - The 3rd fragment, this sequence looks like chromosome 14
  - ***And you keep putting them in the chromosome buckets***
- What you expect, if every tissue has an even chromosome distribution is that that profile would be flat and each bucket would be about the same level
- But what you see in a woman carrying a fetus that has a **trisomy** is about 5-10% greater in the chromosome 21 bucket
  - Remember 90% of it might be maternal blood (so that’s all going to be even), but within the 10% fetal, you’re going to have an extra 50%
    - So the total might be an extra 5% or 10%, but that’s a whopping big signal and very easy to detect

> “*It just gives a sense of how large the numbers are, if a 5% delta is an off-the-charts unmistakable increase in significance. I want to make sure again people understand what you just said, because it’s very important*.”‒ Peter Attia

- Because the majority of the cell-free DNA belongs to the mother, and because the fetal/placental cell-free DNA is a trivial amount, even though by definition a trisomy means there is 50% more of 1 chromosome, you’ve gone from 2 to 3 copies in the fully diluted sample, that might only translate to a few percent, but that’s enough, given the large numbers that you’re testing, to be a definitive, statistically significant difference that triggers a positive test
  - Alex adds, “*Well put. Yes.*”

## The role of cell-free DNA in cancer detection: how incidental findings in non-invasive prenatal testing led to the development of liquid biopsies [40:15]

**Explain where this cell-free DNA is coming from**

- When cells are destroyed (either through [necrosis](https://en.wikipedia.org/wiki/Necrosis) or [apoptosis](https://en.wikipedia.org/wiki/Apoptosis))
- There’s a lot of cell turnover of cells that replicate, especially epithelial cells, blood cells, and so on, some of the DNA from the nucleus ends up in circulation
  - Again that DNA wrapped around these nucleosome

***Essentially cell death and cell turnover is the source of cell-free DNA***

- Since at any one time there’s millions of cells dying and being turned over, there’s always some base level cell-free DNA in the blood

**Do you have an approximate guess for how many base pairs of cell-free DNA are floating around your body or my body as we sit here right now?**

- If you took a 10 ml blood tube (which is a lot of what these tests use) and you remove all the cellular DNA (remember, there’s a ton of DNA in the cells in circulation), so you get rid of the cells, you probably have ***on the order of a few thousand cells worth of cell-free DNA***
  - Which isn’t a lot
  - But each cell would be 3 billion base pairs
- Peter remarks, “*On the one hand, it doesn’t sound like a lot because there are billions of cells. On the other hand, it still sounds like a lot. That’s still a big computational problem*.”
- Alex explains, “***Where it becomes challenging is when we get into early detection where, if you think about it, for any position in the genome, you only have a few thousand representations of it, because there’s only a few thousand cells***.”
  - And so, that starts to limit your ability to detect events that occur at 1 in 1,000,000 or 1 in 100,000

**Initial cases in pregnant mothers where NIPT revealed significant mutations across a number of genes due to cancer**

*Is it correct that these mutations are showing up in relatively small amounts because they’re not in all of her cells?*

- Yeah
- So you might expect a flat pattern in the majority of cases
  - Or when the fetus has a trisomy, you see these very well known accumulations, mostly in chromosome 21, but occasionally in chromosome 18 or 13
- Instead, what you see is just increases and decreases, monosomies and trisomies across many, many chromosomes, which is just not compatible with life even as a fetus
  - ***But there is a biology where you do see these tremendous changes in the chromosomes, and that’s often in the case of cancer***

*Do you recall what those cancers turned out to be in those young women?*

- Meredith and Darya published a [paper in *JAMA*in 2015](https://jamanetwork.com/journals/jama/fullarticle/2389341) on the details these 10 or so cases and what happened in each of them
- It was a mix
- Alex thinks there was a neuroendocrine, uterine, some GI cancers
- Peter points out, “*One doesn’t know the contrapositive, one doesn’t know how many women had cancer but weren’t captured.*”

*Is it safe to assume that the ten who were identified all had cancer?*

- Yes, there were no false positives
- We just don’t know how many false negatives there were

***These incidental findings were one of the things that contributed to the evidence that cancer screening might be possible using cell-free DNA***

- We already knew that yes, tumors do put cell-free DNA into the bloodstream, but this was a profound demonstration that, in actual clinical practice
  - You could find undiagnosed cancers in asymptomatic individuals, and that it was highly specific
  - In those initial ones every case turned out to have cancer
- Alex points out, “*Now, to your point, it’s [NIPT is] not a screening test, because even in relatively healthy and women of childbearing age (a population of 100,000) you expect epidemiologically 10 times or so or 50 times that number of cancers over a year or so. So, clearly you’re missing the majority of cancer, so it’s not a screening test*.”

***It was an inadvertent proof of concept that raised attention at Illumina to the potential of using cell-free DNA and sequencing-based methods to develop a very specific test for cancer***

## The development of a universal blood test for cancer detection, and a discussion of specificity of tests [46:00]

**What was the next step in the process of systematically going after addressing this problem?**

- Alex and some other folks in Illumina, along with the two scientists mentioned earlier ([Meredith](https://bioevolutionlabs.com/team/meredith-miller-md/) and [Darya](https://www.linkedin.com/in/darya-chudova-78b28513/)), and then also in particular the CMO at the time ([Rick Klausner](https://altoslabs.com/team/leadership/rick-klausner/))
  - Rick had a very long history in cancer research and in cancer screening, he was the previous National Cancer Institute (NCI) director under Bill Clinton, and he was the CMO at Illumina at the time
- We started to talk more and more about what it would take to develop (or determine) the feasibility of a universal blood test for cancer, based on this cell-free DNA technology
- And being very first principle, Alex really asked the question, “*Why is it that in 50 years of many companies and a tremendous amount of academic research, no-one had ever developed a broad-based blood test for cancer?*”
  - Not just many cancers, let alone *any* cancer
  - And really the only example is PSA, and again, the false positive rates there are so high that its benefit-to-harm has been questioned many times, and that’s why it doesn’t have a [USPSTF](https://en.wikipedia.org/wiki/United_States_Preventive_Services_Task_Force) grade A or B any more
- And the fundamental reason is **specificity**

> “*There’s lots of things that are sensitive (meaning that there are proteins that accumulate, biochemistries, metabolites that go up in cancer), but the problem is they go up in a lot of benign conditions*.”‒ Alex Aravanis

- So, a big benign prostate spews out a lot of PSA, and pretty much every other protein or metabolite does that

***The biomarkers to date were all very sensitive, but all had*** [***false positive***](https://en.wikipedia.org/wiki/False_positives_and_false_negatives#False_positive_error) ***rates of, say, 5% or 10%***

- And so if you’re imagining screening the whole population, you can’t be working up 1 of 10 people for a potential cancer

**The key technological thing to solve was, how do you have something that has a 1% false positive rate, or a 0.5% false positive rate?**

- Because that’s what you need to get to if you want to do broad-based cancer screening in relatively healthy asymptomatic people

***And this is why we thought it might be possible with cell-free DNA, because the tumor DNA could be more specific than proteins and other things that are common in benign disease***

**The things Alex and colleagues didn’t know**

- How much DNA does an early stage tumor pump out?
  - If it doesn’t pump out any, there’s nothing to detect
- The other is heterogeneity
  - Cancer is not like infectious disease, or there’s one very identifying antigen or sequence
  - Every tumor is truly unique
    - Even 2 lung cancers that are both the same histological subtype, they can share very few mutations or none
    - So, you can have 2 squamous cell lung cancers that honestly don’t have a single shared mutation, so now you need to look at hundreds or thousands or even at millions of positions to see enough potential changes

**This is where** [**NGS**](https://en.wikipedia.org/wiki/Massive_parallel_sequencing) **was a really good fit**

- How do you overcome the heterogeneity?
  - That you need to now look for a disease that isn’t defined
- That got us thinking: in addition to sequencing many positions and sequencing very deeply, and using cell-free DNA, we were going to **need to use AI or machine learning**, because we had to learn these complex associations and patterns that no human being could curate thousands of different mutational profiles and try to find the common signals and so on
- What emerged over the course of a year is that this might be possible, but we’re going to have to enroll very large populations just to study and find the signals and develop the technology
- Then we’re going to need very large studies to actually do interventions and prove it clinically valid, that it actually works

***We’re going to have to use NGS and sequence broadly across the whole genome, and only then might it be possible***

**At that time, Illumina made a board level decision that this made more sense as an independent company**

- Given the amount of capital that was going to be required
- Given the scientific and technical risk
- Given the kind of people that you would need to recruit who were passionate about this
- It made sense to do this as a separate company
- The CEO at the time, [Jay Flatley](https://www.illuminaventures.com/team/jay-flatley/), in early 2016 announced the founding of the company and then spinning it out of Illumina, and Alex had the honor of being one of the co-founders of it [[GRAIL](https://grail.com/)]

## Advancements in cell-free DNA analysis and development of a multi-cancer screening test at GRAIL [51:00]

**It’s 2016 at this new company (GRAIL). What is the sequence of the first 2 or 3 problems you immediately get to work on?**

- Alex wrote the starting research and development plan, and the way he wrote it was, “*We needed to evaluate every potential feature in cell-free DNA*.”
  - Meaning that any known method of looking for cancer in cell- free DNA, we needed to evaluate
  - We needed to not look at just one method or someone’s favorite method or whatever they thought might work; we needed to look at every single one
    - And that’s what we did
- We developed an assay and software for mutations and then a bunch of other things: chromosomal changes, changes in the fragment size, and many others
- And we said, “*We’re going to test each one of these head-to-head, and we’re going to test them in combination, and we’re going to figure out the best way to do this*.”
- We even had a mantra that [Rick](https://altoslabs.com/team/leadership/rick-klausner/) came up with that Alex thought was very helpful, which is, “*We’re either going to figure out how to do this or we’re going to prove it can’t be done*.”

**It was a lot of building these assays**

- We needed a massive datasets to train the machine learning algorithm, so we had this study called the [CCGA, the Circulating Cell-free Genome Atlas](https://grail.com/wp-content/uploads/2020/12/Fact-Sheet-The-Circulating-Cell-free-Genome-Atlas-CCGA-Study.pdf), where we recruited 15,000 individuals with and without cancer of every major cancer type (in most cases hundreds), and then we tested all of these different methods, including a methylation-based assay, and we did blinded studies to compare them to see
  - Could any of them detect a large fraction of the cancers?
  - Did any of them have the potential to do it at high specificity?
  - Because that’s what we would need if we were going to develop a universal test for cancer that could be used in a broad population

**Let’s go back and talk about a few of those things, because there is a lot there**

*You were focused on any measurable property of cell-free DNA*

- Measuring it, quantifying it
- The fragment length seems relatively fixed, but presumably with a large enough sample size, you’re going to see some variation
  - Peter asks, “*Does that matter?*”
- The actual genetic sequence is your bread and butter, to be able to measure that
- Alex also mentioned methylation, Peter asks, “*Explain that*.”

*Were there any other properties besides fragment length, sequence, and methylation that I’m missing?*

- There were several others
- 1 – Chromosomal changes
  - As we mentioned, in cancer, the numbers of chromosomes often changes
  - Many cancers will often double the number of chromosomes
    - So you can go from 23 to double or even triple the number
    - But these chromosomes are not normal, so often the arms or the structures of chromosomes will get rearranged
  - There’s a way to look at that also in the cell-free DNA, like as we mentioned in the noninvasive prenatal testing, where you look at the amount of DNA per chromosome or per part of chromosome
  - We looked at what’s called these [chromosomal abnormalities](https://en.wikipedia.org/wiki/Chromosome_abnormality)
- 2 – We also looked at **cell-free RNA**, so it turns out there’s also RNA from tumors in circulation

Peter asks, “*How stable is that? I was under the impression that RNA wouldn’t be terribly stable, unlike DNA, which of course is double strand and quite stable. How do you capture cell-free RNA?*”

- Naked RNA is not very stable
- However, if RNA is bound to a protein, it’s protected
  - One such protein is called an [Argonaute protein](https://en.wikipedia.org/wiki/Argonaute)
- Peter presumes this is typically messenger RNA that’s been in the process of being transcribed, but somewhere along the way before translation occurs, there’s the disruption to the cell that results in lysis or something, and you’re just basically getting the cell-free RNA because you happened to catch it at that point, it was a replicating cell or something
  - Or it was just translating protein
- Yeah, or during apoptosis (during some kind of programmed cell death), it’s somehow being digested or bound
- The amount relative to the amount of cell death is low, so presumably most of the RNA is destroyed, but enough of it does get protected and bound to proteins
- Whether or not it’s cellular garbage or it’s intentional is kind of a different question, but it is present
- There’s also vesicular structure (so little bubbles of membrane) that the RNA can be contained in
  - The most common one is referred to as an [exosome](https://en.wikipedia.org/wiki/Exosome_(vesicle)), which are these little vesicles in circulation

***So, in a variety of different ways, you can have messenger RNA and other types of RNA preserved outside of cells in circulation, and we looked at that also***

**How long did it take to quantify all of these things?**

*You were also asking the question, can combinations of these factors add to the fidelity of the test, correct?*

- Yeah
- This initial research phase took close to 3 years and cost hundreds of millions of dollars
- We had to recruit the largest cohort ever for this type of study
- In the [CCGA study](https://grail.com/wp-content/uploads/2020/12/Fact-Sheet-The-Circulating-Cell-free-Genome-Atlas-CCGA-Study.pdf) (mentioned earlier), there were different phases
  - There was a discovery, and then multiple development and validation phases
  - We had to make the world’s best assays to look at each of these features, and then we had to process all of those samples and then analyze them, and we did it in a very rigorous way
    - The [final testing](https://www.annalsofoncology.org/article/S0923-7534(21)02046-9/fulltext) was all done blinded, and the analysis was all done blinded, so we could be sure that the results were not biased
    - And then we compared them all, and we also compared them in combinations
  - And we used sophisticated machine learning approaches to really maximize the use of each individual type of data from each, whether or not it was mutations or the chromosomal changes or methylation

**You mentioned the CCGA had 15,000 samples. How many of those samples were cancers versus controls?**

- It’s about 60% cancer, versus 40% controls
- They started with a biased set where you know what’s happening (often referred to as a training set), and they moved to a blinded, unbiased set for confirmation (aka a test set)

## DNA methylation explained [58:15]

**Before we get into those results, explain methylation**

- [DNA methylation](https://en.wikipedia.org/wiki/DNA_methylation) is a chemical modification of the DNA
- In particular, at the C in the ATCG code (the C stands for cytosine) is a particular nucleotide or base in DNA
- Mammalian biology can methylate it, can add a methyl group [shown in the figure below]
- A methyl group is just a single carbon atom with three hydrogens, and then bonded to that cytosine
  - And so that’s what DNA methylation is

![](https://peterattiamd.com/wp-content/uploads/2024/02/f2-alexaravanis.png)

**Figure 2. Methylated cytosine**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/DNA_methylation)

- It turns out that there’s about 28 million positions in the human genome that can be methylated (out of 3 billion bases)
- It usually occurs at what’s called CpG sites, which is if you go along one strand of DNA, where a G follows a C, that’s what a CpG is [shown in the figure below]
  - This is not pairing of the DNA, but one strand
  - It’s a C with a phosphate bond to a G

![](https://peterattiamd.com/wp-content/uploads/2024/02/f3-alexaravanis.png)

**Figure 3. Chemical structure of a CpG site within a DNA strand**. Image adapted from [Wikipedia](https://en.wikipedia.org/wiki/Nucleic_acid_structure)

- At those positions in the genome, there are enzymes that can methylate the cytosine and demethylate it

**Why DNA methylation is important**

- These chemical modifications are really important, because they affect things like [gene expression](https://en.wikipedia.org/wiki/Gene_expression)
- It’s one of the more important classes of something that’s called [epigenetics](https://en.wikipedia.org/wiki/Epigenetics), which is changes that are outside of the genetics or outside of the code itself
- As you know, the DNA code is the same in most cells of the human body, but obviously the cells are quite different, so a T-cell is very different than a neuron
  - And other than the T-cell receptor, all of the genes are the same
  - The code is the same
  - So, why are these cells different? It’s the epigenetics

***Things like which parts of the gene are methylated or which ones are associated with histones (that are blocking access to the DNA), that’s what ultimately determines which genes are transcribed, which proteins are made, and why cells take on very different morphology and properties***

**An analogy to understand the difference between methylation of (epigenetics) and the sequence of genes**

- Methylation is a very fundamental code for controlling it, Alex calls epigenetics the **software** of the genome
- The genetic code is kind of the **hardware**
- But how you use it, which genes you use when, in which combination, that’s really the epigenetics

**What is the technological difference in reading out the methylation sequence on those CpG sites relative to the ease with which you measure the base pair sequences?**

- There are different technologies to do that
- For cell-free DNA, usually you want very accurate sequencing of billions (or many hundreds of millions) of these small fragments
- It adds complexity to the chemistry to determine which of these sites are methylated
  - You pretreat the DNA in a way that encodes the methylation status in the ATGC sequence
  - Then you just use a sequencer that can only see ATCG, but because you’ve encoded the information, you can then de-convolute it and infer which sites were methylated

*More about how the methylation status is determined ‒* [*bisulfite sequencing*](https://en.wikipedia.org/wiki/Bisulfite_sequencing)

- There are chemicals that will for example [deaminate a cytosine](https://en.wikipedia.org/wiki/Deamination#Deamination_reactions_in_DNA) that’s not methylated, and then that deaminated cytosine effectively turns into a [uracil](https://en.wikipedia.org/wiki/Uracil) (which is a fifth letter in RNA), and then when you copy the DNA, you amplify it prior to the sequencing, it amplifies as a T, because a U when it’s copied by a DNA polymerase becomes a T
  - Then you end up with a sequence where you expect to see C’s and you see a T
  - And if you see a T there, then you know that it must’ve been an unmethylated site
  - And if the C was not changed, then you say, then that must have been a site that was methylated
    - If the C was methylated, you’ll see G’s opposite them
    - Because the methylated C won’t turn into a uracil
- There are other ways to determine methylation pattern in a DNA sequence, but that’s the predominant method

## Optimizing cancer detection with methylation analysis of cfDNA in small blood samples [1:02:45]

- Alex came up with all these different thing you can do with a tiny amount of blood (10 mL, 2 small tubes)
- Peter presumes there was an optimization problem here where you min-max this thing and realize this would be easy to do if we could take a liter of blood, but that’s clinically impossible
  - It would be nice to “Theranos” this and do this with a finger-stick of blood, but you’re never going to get the goods

**How did you end up using a 10 mL blood sample?**

- Was it just sort of an optimization problem that got you there as the most blood we could take without being unreasonable, but yet still have high enough fidelity?

*Can you get better and better at doing this if you were taking 8 tubes of blood instead of 2?*

- Practical considerations: you need standard phlebotomy and standard volumes that are below ones where you could put someone in jeopardy
- It turned out that what ultimately limited the sensitivity of the test was the background biology

***For broad-based cancer screening, more blood would not help***

- There are **other applications now for monitoring therapy or for therapy selection** where you’re looking for a particular target, and there you could improve sensitivity with a larger blood sample
  - This is someone who has cancer and you know what kind of cancer

**Did methylation turn out to be the most predictive element at giving you that very, very high specificity, or was it some combination of those measurable factors?**

- It was pretty unexpected
- Most people thought that the mutations were going to be the most sensitive method
- Some of us thought that the chromosomal changes were going to be the most sensitive
- The methylation signals were kind of the dark horse
  - Alex had to fight several times to keep it in the running
- But again, we really let the data tell us what the right thing to do is, not biases from other experiments

***We approached things in a comprehensive, rigorous way, and in the end, the methylation data performed the best by far ‒ it was the most sensitive, it detected the most cancers, and it was very specific (less than 1% false positive rate)***

**Methylation had another feature which was very unique, it could predict the type of cancer**

- This tells you what organ or tissue the cancer originated from
- Interestingly, adding them all together didn’t improve on the methylation
- You might’ve thought, “*Hey, more types of information, and signal are better,*” but it actually didn’t

> “*We ended up with one clear result that the methylation patterns in the cell-free DNA, were the most useful, and information, and adding other things, was not going to help the performance*.”‒ Alex Aravanis

**Why do you think that was?**

- It comes down to this is a good engineering principle
- If you want to improve your prediction, you need an additional signal that carries information, and is independent from your initial signal
  - If it’s totally correlated, then it doesn’t actually add anything

*Alex uses an analogy to explain this concept*

- Let’s say you’re on a freeway overpass, and you’re developing an image recognition for Fords, and you say, okay, what I’m going to start initially with, is an algorithm, that’s going to look for a blue oval with the letters FORD in it (that’s pretty good)
- Next, you know that some Fords also have the number 150 on the side (F-150), so you add that
- If you think about it, if your algorithm, based on the blue oval is already pretty good, adding the 150 is not going to help, ***because whenever the 150 occurs, the blue oval is also always there***
- Now, if the blue oval wasn’t always there, or there were Fords that didn’t have the blue oval, then some other signal could be helpful

***That’s what ended up happening, the methylation signal was so much more prevalent, and so much more distorted in cancer, that everything else didn’t really add, because anytime you could see one at the others, you could also see many more abnormal methylation fragments***

## The importance of understanding sensitivity, specificity, positive predictive value, and negative predictive value in cancer screening [1:08:00]

**Peter wants to make sure people understand the mission statement Alex and his colleagues brought to this, which was high specificity is a must**

*The metal detector in the airport is a good analogy to explain sensitivity and specificity*

- People have heard Peter use this analogy on the podcast before
- **Sensitivity** is the ability of the metal detector to detect metal that should not go through
  - And let’s be clear, it’s not that people in the airports care if your phone is going through, or your laptop, or your watch, or your belt
  - They care that you’re bringing guns, knives, or explosives
    - That’s why the metal detector exists
    - It has to be sensitive enough that no one carrying one of those things can get through
- If you’re optimizing for sensitivity, you make it such that you will detect any metal that goes through that thing
  - And by definition, you’re going to be stopping a lot of people
  - You’re going to stop everybody from walking through
  - If their zipper is made of metal, you’ll stop them
- So you have to dial the thing so that you have some **specificity** to this test as well, which is you can’t just stop everybody
  - In an ideal world, you want everyone to make it through who is not carrying one of those really bad things
    - And we’re defining bad things by a certain quantity of metal
- Therefore, your **specificity** is to say, “*I don’t want my test to be triggered on ‘good guys.’ I want my test to be triggered on ‘bad guys.’*”
- Anybody who’s ever been through 2 different airports wearing the exact same clothing, and realizes sometimes it triggers, sometimes it doesn’t
  - What you realize is not every machine has the same setting
  - And that’s, because the airport, the people at TSA, ***they turn up, or turn down the sensitivity, and that changes the specificity as well***

**How deliberately do you, when you’re setting up this assay, have the capacity to dial up, and down sensitivity and specificity?**

- There is a threshold and it is complex
- Conceptually, there’s a threshold inside the algorithm
  - You can imagine that after you have this comprehensive map of all these different types of methylation changes that can occur in the fragments of hundreds of examples of every cancer type, and then, you compare it to all the methylation changes that can occur outside of cancer (which we haven’t talked about but are very important)
  - Most of the methylation patterns are pretty similar, and similar cell types across individuals, but there are changes that occur (that occur with age, or ethnicity, or environmental exposure, and so on)
  - What you’d like is for those 2 populations to be completely different, but it turns out there is some overlap
    - So there are fragments that occur in cancer that can occur outside of cancer
- The algorithm is trying to separate these populations, and whether or not you are going to call something as a potential cancer (and say a cancel signal is detected) is whether or not the algorithm thinks, “*Is it associated with this cancer group, or is it associated with a non-cancer group?*” [illustrated in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/02/f4-alexaravanis.png)

**Figure 4. Hypothetical overlap between the cancer group and non-cancer group**.

- There are some overlap between these, and where you set that overlap will determine your specificity
  - For example in the border between individuals who don’t have cancer, but out for whatever reason, an abnormal level of fragments that look cancerous

***So there is a dial to turn where you can increase the stringency (and call fewer false positives), but then you will start to miss some of the true positives***

- What was so great about methylation is that these populations were pretty well-separated
  - Better than anything the world had ever seen before
  - Which is why you could get high specificity, and still pretty good sensitivity

**Inside the company, is there a specific discussion around the trade-offs of, it’s better to have a false positive than have a false negative?**

[*Prostate-specific antigen*](https://en.wikipedia.org/wiki/Prostate-specific_antigen) *is the mirror image of this*

- Alex explains, “*It’s a highly, highly sensitive test with very low specificity*”
- PSA is obviously a protein, so it’s a totally different type of assay (it’s a far cruder test)
- The idea in theory is someone with prostate cancer is going to have a high PSA, so you’re not going to miss people with cancer
- But as Alex pointed out earlier, you’re going to be catching a lot of people who don’t have cancer, and it’s for that reason, there is no longer a formal recommendation around the use of PSA screening
  - It is now been relegated to the just talk to your doctor about it
  - The thinking is, there are too many men that have undergone an unnecessary prostate biopsy on the basis of an elevated PSA, that really should have been attributed to their [BPH](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia), or [prostatitis](https://en.wikipedia.org/wiki/Prostatitis), or something else [discussed further in [episode #273](https://peterattiamd.com/tedschaeffer2/)]
  - So not within the fact that we have far better ways to screen for prostate cancer today

***PSA is a test that is highly geared towards never missing a cancer in its current format, under low prevalence populations, which is effectively the population it’s being designed for***

- This is designed as a screening tool

*PSA seems to have better negative predictive value than positive predictive value, correct?*

- It’s pretty high in both, because negative predictive value also is related to prevalence

**Just to put some numbers out there**

- In the CCGA study, and importantly in an interventional study called [PATHFINDER](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(23)01700-2/fulltext), [the GRAIL test was found to have] a positive predictive value of around 40% (for all cancers, all stages)
  - [The figure below summarizes the stages of cancer progression]
  - It’s a population study, so it’s whatever natural set of cancers, and stages occur in that group
  - That was about 6,500 individuals

![](https://peterattiamd.com/wp-content/uploads/2024/02/f5-alexaravanis.png)

**Figure 5. Roman numeral staging of cancer progression**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cancer_staging#Overall_stage_grouping)

**Do you recall what the prevalence was in that population? Was it a low risk population?**

- It was a mix of a slightly elevated risk population, and then average risk population
- Just in terms of risk, Alex thinks of anyone over 50 as high risk
  - And that’s where the majority of these studies are happening

> “*Age is your single biggest risk factor for cancer. The population over 50 is about a 10x increased risk relative to the population under 50*.”‒ Alex Aravanis

- Peter adds that age 55-65 is the decade where cancer is the #1 cause of death
- In developed nations, that’s actually increasing
  - We’re making such incredible progress on metabolic disease, and cardiovascular disease
  - Cancer in the developed world is predicted to become surpass cardiovascular disease is the #1 killer
- Alex wouldn’t call older populations low risk, he’d call them average risk for that age group
  - Which is still relatively high for the overall population

***This study was a mix; the prevalence was a bit <1%***

- Some of these studies do have a healthy volunteer bias

**Peter’s takeaway:** ***in a 6,500 person cohort with a prevalence of 1% (which is pretty low), the positive predictive value was 40%***

**What was the sensitivity for all stages then?**

- Peter would think it’s got to be 60% or higher sensitivity, and the specificity has got to be >99%
  - Alex agrees, those are the rough numbers

**Results from the** [**PATHFINDER study**](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(23)01700-2/fulltext)

- About half of the cancers that manifested over the lifetime of the study were detected by the test
- The test actually doubled the number of cancers in that interventional study than were detected by standard of care screening alone
  - The enrollees were getting standard of care screening according to guidelines including mammography, cervical cancer screening, colonoscopy or stool-based testing (based on guidelines)
- A number of the cancers that the [GRAIL Galleri test](https://grail.com/galleri-test/) detected were also detected by standard of care, which you would expect, but the total number of cancers found was about doubled with the addition of the Galleri test
  - And that was predominantly cancers where there isn’t a screening test for, which is going back to the positive predictive value
    - Just the positive predictive value of most screening tests is low single digits
- You’ve probably had the experience that a female friend calls and tells you that something was **found on a mammography** and they have to go for a follow-up and a biopsy
  - Literally, 19 times out of 20, it’s a false positive
  - That’s one where we’ve accepted, for better, or worse, a huge false positive rate to catch some cancers
    - And that’s why there’s a fair amount of debate around mammography

***Mammography has a positive predictive value of about 4.5%; the vast majority of people who get initial positive, they’re not going to end up having cancer, but it’s still potentially worth it***

- We’re talking about something where we’re approaching 1, or 2 positive tests will ultimately lead to a cancer diagnosis that’s potentially actionable
- Alex thinks sometimes when people hear 40%, they say, “*Gee, that means there’s still a fair amount of people who are going to get a positive test,*” meaning a cancer signal detected, and ultimately not

***But for a screening these, 40% is an incredibly high yield***

*Going back to the airport analogy to understand what a 40% positive predictive value means*

- This is a metal detector that is basically saying, look, we’re willing to beep at people who don’t have knives to make sure everybody with a knife, or gun gets caught
- So the **negative predictive value** is what’s giving you the insight about the bad guys
- A 40% **positive predictive value** means
  - ***Let’s just make the numbers even simpler and say it’s a 25% positive predictive value ‒ it means for every 4 people you stop, only 1 is a true bad guy***
- Think about what it’s like in the actual airport
  - How many times in a day does the metal detector go off, and how many times in a day are they catching a bad guy?
  - The answer is, it probably goes off 10,000 times in a day, and they catch zero bad guys on average

***So that gives you a sense of how low the positive predictive value is, and how high the sensitivity is, and how low the specificity is***

**Physicians have an important role to play in helping patients understand screening tests**

- Peter thinks that’s a great way to look at it: if you are screening a population that is of relatively normal risk, a positive predictive value of 20% is very, very good
- It also explains where the burden of responsibility falls to the physician
  - As a physician, you have to be able to talk to your patients about this explicitly prior to any testing

***Patients need to understand: hey, there’s a chance that if I get a positive test here, it’s not a real positive***

- Patients have to have the emotional constitution to go through with that, and they have to be willing to then engage in follow-up testing
- Because if this thing says it looks like you have a lung cancer, the next step is you’re going to be getting a chest X-ray or a low dose CT of your chest
  - And that doesn’t only come with a little bit of risk (in this case, radiation, although it’s an almost trivial amount)
  - But more than anything, it’s the risk of the emotional discomfort associated with that
- Peter points out, “*I think, honestly, when you present the data this way to patients, they really understand it, and they really can make great informed decisions for themselves.*”
- For some patients it means: Thank you, but no, thank you. They just don’t want to go through with this
  - And that’s okay too

## The performance of the GRAIL Galleri test and its ability to detect various types and stages of cancer [1:21:00]

**Alex is no longer a part of the company GRAIL**

- When he was at Illumina, he helped spin-off GRAIL as a co-founder, and he led the R&D and clinical development
- He actually went back to Illumina as the chief technology officer
  - We were running all of the companies research and development (really, really fantastic fun job)
- Subsequently, Illumina acquired GRAIL, a subsidiary of Illumina
  - That was almost 3 years ago
- Recently, Alex left Illumina to start a new company [[Moonwalk Biosciences](https://moonwalk.bio/)]
  - A really interesting biotech company that he’s the CEO of
- He’s no longer actively involved in either company though he has great relations with all his former colleagues, and is excited to see their progress
- Full disclosure: he is still a shareholder of Illumina

**Peter is intrigued with certain data regarding the Galleri test**

- Peter has gotten to know a number of Alex’s colleagues who are still at GRAIL, and one of the things that intrigued him was some of the histologic differences and the stage differences of cancer
- If you look at the opening data, a few things stood out to Peter
- There were certain histologies that if you took them all together by stage, didn’t look as good as others

**For example, talk a little bit about prostate cancer detection using the Galleri test**

- What Alex thinks Peter is referring to is there is a very wide variety of different performances and different cancers
  - They’re all highly specific: they have a very **low false positive rate**
    - There’s only 1 false positive rate for the whole test
- The test is very good at detecting earlier stage localized cancers
  - Particularly in prostate cancer, and hormone receptor-positive breast cancer
  - The detection rate is lower for [stage I](https://en.wikipedia.org/wiki/Cancer_staging#Overall_stage_grouping) cancers

*This gets to a very important issue, which is what is it that you want to detect?*

- Do you want to detect everything that’s called cancer today
- Or do you want to detect cancers that are going to grow and ultimately cause harm?

**Alex points out, “*****The weird thing about cancer screening in general is there’s both over, and under diagnosis.*****”**

- Most small breast cancers, and most [DCIS](https://en.wikipedia.org/wiki/Ductal_carcinoma_in_situ), and most even small prostate cancers will never kill the patient, or cause morbidity
- But there is a small subset that will
- And so, for those, we have decided to again, go for a trade-off where we’ll often resect things, and go through treatments just to make sure that smaller percentage is removed, even though we’re removing a ton of other cancers that are unlikely to ever proceed into anything dangerous

> “*On the flip side, 70% of people who die of cancer, they die from an unscreened cancer.*”‒ Alex Aravanis

- So there’s huge **under-diagnosis,** you should remember that 70% of people who ultimately die of cancer on their death certificate, they die from a cancer **where there is no established screening** prior to something like [GRAIL’s Galleri](https://grail.com/galleri-test/)

***We have this weird mix: there’s a lot of cancers where we know we’re over diagnosing, but we’re doing it for a defensible trade-off; and then, there’s a huge number of cancer deaths occurring where there’s essentially zero diagnosis***

**What does it mean to have tumor DNA in your blood?**

- Measuring, and detecting a cancer from tumor DNA in your blood is a functional asset
- To get tumor DNA in your blood, you have to have enough cells, they have to be growing fast enough, dying fast enough, and have blood access
- If you have a tumor that’s small, encapsulated ‒ it’s not going to have DNA in the blood

***So unlike an imaging assay (which is anatomical), this is really a functional assay***

- You’re querying for whether or not there’s a cancer that has the mass, the cell activity, and death, and access to the blood to manifest its DNA into the blood
- It’s really stratifying cancers on whether or not they have the activities

**Interestingly, this functional assay is very correlated with ultimate mortality**

- There’s a really nice [set of data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9401481/) that the GRAIL put out where you look at Kaplan-Meier curves (shown below)

![](https://peterattiamd.com/wp-content/uploads/2024/02/f6-alexaravanis-1024x600.png)

**Figure 6. Overall survival in cancers detected (red) versus not detected (blue) by the GRAIL test**. Image credit: [*Clinical Cancer Research*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9401481/) 2021

- Over the course of the CCGA study, which is now going out 5+ years, you can ask, “*What do survival curves look like, if you were positive, your test was detected, versus your test was negative, meaning your cancer was not detected by the GRAIL test?*”
  - And there’s a big difference

***Basically, if your cancer was undetectable by the GRAIL test [blue in the figure above], you have a very good outcome, much, much better than the general population with that cancer***

**This suggests 2 things**

- 1 – Those cancers may not have actually been dangerous, because there’s not a lot of mortality associated with them, and maybe that’s also why they couldn’t put their tumor DNA in the blood
- 2 – Whatever the existing standard of care is, it’s working well
- If you look at all the cancers in the Kaplan-Meier curve that were detected, they have a lot of mortality associated with them
  - ***What it’s showing is that the cancers that are accounting for the majority of mortality, those are the ones that the test is detecting (the dangerous cancers)***
- This **biological rationale** makes a lot of sense: a tumor that grows fast gets its DNA in the blood, and that’s probably also a dangerous tumor that is going to become invasive and spread

**This suggests that GRAIL is a functional assay**

- Cancers detected by this test are active enough to get its signal into the blood, and it’s very likely if untreated, to ultimately be associated with morbidity, and potentially mortality
- It’s an open question: of these tumors that aren’t detectable, and that are in cancers (we know there’s a lot of indolent disease)
  - What does it really mean that the test is low sensitivity for that?

## Do early cancer detection methods, like liquid biopsies, translate to improvement in overall survival? [1:27:45]

**Does the ability to screen this way lead to better outcomes?**

- When Peter went through these data 18 months ago, he went through every single histology by stage, and the one that stood out more than any other was the sensitivity discrepancy between [triple negative breast cancer](https://en.wikipedia.org/wiki/Triple-negative_breast_cancer) and [hormone positive breast cancer](https://en.wikipedia.org/wiki/Breast_cancer_classification#Receptor_status)
- He points out that within the same disease of breast cancer, we understand that there are 3 diseases: estrogen positive, there’s HER2 new positive, there’s triple negative [discussed further in [episode #278](https://peterattiamd.com/haroldburstein/)]
  - Those are the defining features of 3 completely unrelated cancers, with the exception of the fact that they all originate from the same mammary gland (but that’s about where the similarity ends)
  - Their treatments are different, their prognosis are different
- To take the two most extreme examples, you take a woman who has triple positive breast cancer (estrogen receptor positive, progesterone positive, HER2 neu positive) and you take a woman who has none of those receptors positive (triple negative breast cancer)
  - The difference on the Galleri test performance on stage I, and stage II (this is cancers that have not even spread to lymph nodes), the hormone positives were about a 20% sensitivity for stage I, stage I
    - And the triple negative was 75% sensitivity for stage I, stage II
  - This underscores Alex’s point, which is the triple negative cancer is a much, much worse cancer [Peter misspoke and said triple positive instead of triple negative here]
    - And that at stage I/ stage II, you’re detecting 75% sensitivity, portends a very bad prognosis
- **Peter states his bias to this question**: yes, screening in this way will lead to better outcomes
  - His bias is that early detection leads to earlier treatment, and even if the treatments are identical to those that will be used in advanced cancers, the outcomes are better, because of the lower rate of tumor burden
- Peter points out an example of this: 2 of the most common cancers are breast, and colorectal cancer, where the treatments are virtually indistinguishable in the adjuvant setting, versus the metastatic setting, and yet the outcomes are profoundly different
  - In other words, when you take a patient with breast, or colorectal cancer, and you do a surgical resection, and they are a stage III, or less, and you give them adjuvant therapy, they have far, far, far better survival than those patients who undergo a resection, but have metastatic disease, and receive the same adjuvant therapy
    - It’s not even close
  - ***This is the reason he argues that the sooner we know we have cancer, and the sooner we can begin treatment, the better we are***
- The skeptic will push back and say, “*Peter, the only thing the GRAIL test is going to do is tell more people bad news.*”
- We can concede that people are going to get a better, more relevant diagnosis, that we will not be alerting them to cancers that are irrelevant, and overtreating them, and we will alert them to negative, or more harmful cancers, but it won’t translate to a difference in survival

**What is your take on that, and how can that question be definitively answered?**

- Alex thinks this is an important question, and over time it will be definitively answered
- The statistics are very profound: for most solid tumors, 5 year survival when disease is localized (hasn’t spread to another organ) is 70-80%
  - The 5 year survival is <20% per metastatic stage IV disease
  - That correlation of stage of diagnosis, versus 5-year survival is night, and day, and obviously, everyone would want them, and their loved ones, and most people in the localized disease category
- There’s an academic question: does that really prove that if you find people with localized disease through this method (as opposed to all the variety of methods that happens today) that you will have the same outcome?
  - Alex guesses you could come up with some very theoretical possibility that somehow that won’t, but that doesn’t seem very likely

***This gets to a fundamental question of: are we going to wait decades to see that, and in the meantime give up the possibility/probable likelihood of finding these cancers early (and intervening early will change the outcome)***?

- Bigger and more definitive studies will come over time

**The nihilistic point of view, that until it’s done, we’re not going to find cancers early and  intervene**

- Alex doesn’t think it’s consumable to do that, especially when the false positive rate is low

- A former colleague who the test found an ovarian cancer
  - Do you think when she went to her OBGYN, and said, “*Look, the test said that I have potentially an ovarian cancer,*” and they did an ultrasound, and they found something
  - That OBGYN said, “*You know what? Since this was found through a new method, let’s not intervene. There’s a malignancy. It is an ovarian cancer. We know what the natural history is, but we’re not going to intervene.*”
- Similarly, with cases of pancreatic cancer, head, and neck, or things like that
- Alex doesn’t understand the logic, because today, people do show up (it’s not very often) with early stage versions of these diseases (ovarian, pancreatic, head, and neck, and things), and we treat them

***So why is it you wouldn’t treat them if you could find them through this modality?***

- Alex doesn’t know of any GI surgeon who says, “*Well, you’re one of the lucky people. We found your pancreatic cancer at stage I/II, but we’re not going to treat it, because there isn’t definitive evidence over decades that mortality isn’t better*.”
- Alex understands the academic point, and GRAIL, and others are investing a tremendous amount to increase the data
- He doesn’t think the idea that we have this technology, and we’re going to allow huge numbers of cancers to just progress to late stage before treating is the the right balance of potential benefit, versus burden of evidence

**Is there now a prospective real world trial ongoing in Europe?**

- There is

***While we’re waiting for that readout, Alex’s personal belief is the potential benefit of finding cancer is so significant that testing now for many patients makes sense***

**The endpoint of reduction in stage IV cancer is very clever**

- A lot of the folks who oppose cancer screening tend to cite that a number of cancer screening studies do not find an improvement in all-cause mortality even when there’s a reduction in cancer specific mortality
  - For example, we did this colonoscopy study or we did this breast cancer screening study and it indeed reduced breast cancer deaths, but it didn’t actually translate to a difference in all-cause mortality
- Peter has explained this on a previous podcast [[Episode #289](https://peterattiamd.com/ama56/)], but it is worth for folks who didn’t hear that to understand why
  - [See also this previous [newsletter](https://peterattiamd.com/life-extension-from-cancer-screening/)]
  - To him, that’s a very misguided view of the literature because what you fail to appreciate is those studies are never powered for all-cause mortality
  - And if you reduce breast cancer mortality by 40% or 30%, that translates to a trivial reduction in all-cause mortality because breast cancer is still just one of 50 cancers
    - And even though it’s a relatively prevalent cancer over the period of time of a study (which is typically 5-7 years), the actual number of women who are going to die of breast cancer is still relatively small compared to the number of women period who are going to die of anything
  - In previous podcasts, Peter has discussed that it’s very difficult to get that detection within the margin of error
  - And so if you actually wanted to be able to see how that translates to a reduction in all-cause mortality, you would need to increase the size of these studies considerably even though really what you’re trying to do is detect a reduction in cancer specific mortality
- Peter says this to point out one of the interesting things about this NHS study, “*It is a pan screening study and to my knowledge, it’s the first. In other words, it has the potential to detect many cancers and therefore you have many shots on goal.*”
  - Potentially this could show a reduction in all-cause mortality and not just cancer- specific mortality
  - He would have to see the power analysis, but he wonders if the investigators thought that far ahead

**Do you know?**

- They’re going to follow these patients long-term, and they will be able to have the data on mortality
- Alex doesn’t know if it’s powered for all-cause mortality
  - He thinks that’s unlikely, just for the reasons Peter said, which is the numbers would be really high

## The role of epigenetics in aging [1:39:30]

- Alex recently left Illumina and started another company
- Peter is involved in that company as both an investor and an advisor, and it’s an incredibly fascinating subject
- One of the things that we talk about a lot is going back to this role of the epigenome
  - Alex did a great job earlier in explaining it and putting it in context

**Peter will fill in a few more details about methylation of our genome**

- We’ve got these 3 billion base pairs and lo and behold some 28 million of them also happen to have a methyl group on their C
- Just to throw it out there, as a general rule, when we’re born, we have our max set of them and as we age, we tend to lose them

***As a person ages the number of those methylated sites goes down***

- Alex explained early what these methylated sited so, and their purpose in impacting [silencing] gene expression
- It’s worth also pointing out that there are many [hallmarks of aging](https://www.cell.com/cell/pdf/S0092-8674(22)01377-0.pdf) [discussed in [episode #272](https://peterattiamd.com/davidsabatini-mattkaeberlein/)]

![](https://peterattiamd.com/wp-content/uploads/2024/02/f7-alexaravanis.png)

**Figure 7. Epigenetic alterations is one of the 12 hallmarks of aging**. Image credit: [*Cell* 2023](https://www.cell.com/cell/pdf/S0092-8674(22)01377-0.pdf)

- There are many things that are really believed to be at the fundamental level that describes why Alex and Peter today look and function entirely different from the way they did when they met 25 years ago
  - Peter adds, “*We’re half the men we used to be*.”

**The question is, where do you think methylation fits into the biology of aging? (That’s a macro question)**

- The hallmarks of aging was [originally proposed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/) about 10 years ago
  - [[Hanahan](https://www.ludwigcancerresearch.org/scientist/douglas-hanahan/) came up with the [hallmarks of cancer](https://www.cell.com/cell/fulltext/S0092-8674(00)81683-9) in 2000]
- He recently gave a talk where he talked about the idea that perhaps methylation is the hallmark of **hallmarks of aging**

***There is mounting data that the epigenetic changes are the most descriptive of aging and are becoming more and more causally linked to aging events***

- Peter knows there’s lots of data that show that people of comparable age but different health status can have very different methylation patterns
  - For example, smokers versus non- smokers, people who exercise versus people who don’t, people who are obese versus people who are not
- There’s also some data that look at centenarians relative to non-centenarians, and you get a sense of different patterns of methylation
  - Obviously that’s a complicated analysis because by definition there’s a difference in age
- We’ve established long ago that centenarians do not acquire their centenarian status by their behaviors
  - Just look at [Charlie Munger](https://en.wikipedia.org/wiki/Charlie_Munger) and [Henry Kissinger](https://en.wikipedia.org/wiki/Henry_Kissinger), 2 people who recently passed away at basically the age of 100, despite no evidence whatsoever that they did anything to take care of themselves
  - So clearly their biology and their genes are very protective
- There are a bunch of these hallmarks of aging
  - The [original paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/) had 9 and that’s been expanded [to 12 in [2023](https://www.cell.com/cell/pdf/S0092-8674(22)01377-0.pdf), see the previous figure]
- Peter points out that Alex shares the view that the epigenome sits at the top [of the hallmarks of aging] and that potentially it’s the one that’s impacting the other
- So when we think about mitochondrial dysfunction
  - Which no one would dispute, Peter’s and Alex’s are nowhere near as good as they were 25 years ago
  - Their nutrient sensing pathways, inflammation, all of these things are moving in the wrong direction as we age

**How do you think mitochondrial dysfunction ties to methylation and to the epigenome, and to gene expression by extension?**

- Alex proposes that we reduce it to an engineering framework
- If we took Peter’s epigenome from 25 years ago (when Alex first met him), and we knew for every cell (all 28 million positions) what the methylation status was
  - And we took it again today, where most of those cells have deviated from that
- Those sites don’t go away, it’s just whether or not they have the methyl group or not changes
  - Some places gain it [methylation], some places lose it

***The question is: if we could flip all those back, would that force the cell to behave like it was 25 years ago?***

- The fidelity with which it controlled expression of those genes, the interplay between them, would it be reprogrammed back to that state?
- Alex thinks is a really provocative hypothesis
- We don’t know that for sure, but there’s more and more evidence that might be possible

**The burning questions is: can we reprogram things [methylation status] back to that earlier state?**

- Now that we have the ability to characterize the methylation status
  - We know what it looks like in a higher functioning state (which correlates with youth)
- We are gaining technologies to modulate that and change the epigenome as opposed to modifying proteins
  - To go in and remethylate and demethylate certain sites

*If methylation is the root level at which things are controlled, will you then get all of the other features that the cell had and the organism had?*

- That’s a really exciting question to answer, because if the answer is yes (or even partially yes), then it gives us a really concrete way to go about this
- We talk about the hallmarks, and the hallmarks are complex and interrelated
- What Alex likes about the epigenome is we can read it out and we’re gaining the ability to modify it directly
- So if really it’s the most fundamental level at which all of these other things are controlled, it gives us a very straightforward engineering way to go about this

## How cell-free DNA methylation patterns can help identify a cancer’s tissue of origin [1:45:30]

- A year ago, Alex was part of a remarkable effort that culminated in a publication in [*Nature*](https://www.nature.com/articles/s41586-022-05580-6)
  - It sequenced the entire human epigenome
  - Roughly 24 years after the human genome project 24 years ago roughly

**Can you talk a little bit about that and maybe explain technologically how that was done?**

- In the development of the [GRAIL Galleri test](https://grail.com/galleri-test/), there was a key capability that we knew was going to be important for a multi-cancer test
  - Very different from most cancer screening today which is done 1 cancer at a time
- If you have a blood test and it’s going to tell you there’s a cancer signal present and this person should be worked up for cancer, you’d really like to know, “*Where is that cancer likely to reside?*”
  - Because that’s where you should start your workup, and you want it to be pretty accurate
- If the algorithm detects a cancer and it’s really a head and neck cancer, you’d like the test to also say it’s likely head and neck
  - And then do an endoscopy
  - And *not* have to do lots of whole body imaging or a whole body PET-CT or things like that

***We developed something called a “cancer site of origin,” and today the test has that***

- If you get a signal detected, it also predicts where the cancer is and it gives the top 2 choices
  - It’s about 90% accurate in doing that

**How does that work?**

- The physicians and patients that have gotten that have described it as magic that it detects the cancer and predicts it, and ***it’s based on the methylation patterns***

*Methylation is what determines cell identity and cell state*

- So again, the DNA code is more or less the same in your cells, but the methylation patterns are strikingly different
- When a cell replicates, why does it continue to be the same type of cell?
  - When epithelial cell replicates the same DNA as a T cell or a heart cell, but it doesn’t become those [cell types], it stays [an epithelial cell]
  - It’s because the methylation pattern, those exact methylation states on the 28 million [sites], are also replicated
- Just in the same way that DNA has a way of replicating the code, there’s an enzyme that looks and copies the [methylation] pattern to the next cell
- And that exact code determines if the cell is a colonic epithelial cell or a fallopian epithelial cell, or whatever
- We knew that the only way to make a predictor in the cell-free DNA is to have that **atlas of all the different methylation patterns**
- So with a collaborator, a guy named [Yuval Dor](https://iias.huji.ac.il/people/yuval-dor) at Jerusalem University, we laboriously got surgical remnants from healthy individuals
  - He developed protocols to isolate the individual cell types of most of the cells that get transformed in cancer
  - And then we got pure methylation patterns where we sequenced the whole methylome of all those cell types
    - This was like sequencing the whole genome
  - We [published](https://www.nature.com/articles/s41586-022-05580-6) that a year ago as the first atlas of the human methylome and all of the major cell types
- Now for the first time we could say, “*Hey, this is the code which makes you beta islet cell in the pancreas that makes insulin versus something else*.”
  - Interestingly, there’s only one cell in the body where the insulin promoter is not methylated, and that is the beta islet cell
  - In every other single cell, that promoter is heavily methylated because it shouldn’t be making insulin
- It’s those kinds of signals that when you have the cell-free DNA, you look at the methylation pattern, and it allows the algorithm to predict the tissue where the cancer originated, and that’s how the algorithm does it

> “*This atlas, again, was a real breakthrough for diagnostics and it made cancer site of origin useful.*”‒ Alex Aravanis

- This atlas is also being used for lots those cancer monitoring tests too, because it’s so sensitive
- You can compare the methylation pattern in the good state versus the bad state

**This brought up the interesting possibility: if you’re going to develop therapeutics or you want to rejuvenate cells or repair them**

- Does comparing the methylation pattern in the good state versus the bad state then tell you the exact positions that need to be fixed?
- And then with another technology which can go and flip those states, will that reverse or rejuvenate the cell to the original or desired state?
- Peter points out that the genome doesn’t migrate so much as we age
  - Obviously it accumulates mutations

**Do you need longitudinal analysis of a given individual (i.e. within an individual) to really study the methylome?**

- For example, would you need to know what Peter’s epigenome looked like at birth, 1 years old, 2, 3, 4, 50 years old?
  - So that you could also see not just how does the methylation site determine the tissue specificity or differentiation, but how is it changing with normal aging as well?
- Alex thinks a lot of it is *not* individual specific

*An example*

- Alex has done a fair amount of work in T-cells, and if you look at exhausted effector T-cells versus naive memory cells (where younger individuals tend to have more of those and it gives them more reservoir to do things like fight disease, fight cancer), there’s very distinct methylation changes
  - Certain genes get methylated demethylated
  - And those changes seem to be very correlated with this change in T-cell function
- Alex’s belief is that those represent fundamental changes as the T-cell population gets aged and you end up with more and more T-cells that relatively speaking are useless
- So if you wanted to rejuvenate the T-cells, repairing those methylation states is something that would benefit everyone
- Now, there are definitely a small percentage of methylation sites that are probably drifting or degrading, and those could be specific to individuals
  - There’s some gender-specific sites for sure, there’s some ethnic ones

***But big, big [methylation] changes seem to happen more with loss of function, big changes in age (that are probably common across individuals), or in the case of cancer we also have profound changes***

## Cellular and epigenetic reprogramming, and other exciting work in the field of aging [1:52:30]

- When Peter thinks about this space, the term “[Yamanaka factors](https://pubmed.ncbi.nlm.nih.gov/19030024/)” comes up
  - A [Nobel Prize](https://www.nobelprize.org/prizes/medicine/2012/press-release/) was awarded to [Yamanaka](https://www.cira.kyoto-u.ac.jp/e/research/yamanaka_summary.html) for the discovery of these factors

**Can you explain what they are and what role they play in everything you were discussing?**

- What Yamanaka and colleagues discovered is that if you take fully differentiated cells (for example, fibroblasts) and you expose them to particular cocktail of 4 transcription factors, the cell reverts to a stem cell-like state
  - And these are called [induced pluripotent stem cells](https://en.wikipedia.org/wiki/Induced_pluripotent_stem_cell)
- You subject a differentiated cell that was a mature cell, but a particular type (Alex thinks most of their work was in fibroblasts), and the cell when it’s exposed to these transcription factors, they unleash a huge number of changes in gene expression
  - And these transcription factors are powerful ones at the top of the hierarchy
  - Genes get turned on, get turned off, and then ultimately if you keep letting it go on, you end up with something that is a type of stem cell

***Why this was so exciting is it gave the possibility to create stem cells through a manufactured process***

- As you know, there is a lot of controversy about getting stem cells from embryos or other sources
- This created a way now to create stem cells and use them for medical research by just taking an individual’s own cells and de-differentiating it back to a stem cell

**How much did that alter the phenotype of the cell itself?**

*In other words, the fibroblast has a bunch of phenotypic properties. What are the properties of a stem cell and how much of that is driven by the change in methylation?*

- Peter is trying to understand how these transcription factors are actually exerting their impact throughout this regression (for lack of a better word)?
- We refer to cell type specific features as “**somatic features**” like a T-cell receptor
  - A T-cell receptor is a feature of a T-cell
  - Or a dendrite or an axon would be for a neuron, or an L-type calcium channel for a cardiac myocyte
  - Those are very cell type specific features
- If you turn on these Yamanaka factors and you go back to a pluripotent stem cell, you lose most of these
- And that word pluripotent means the potential to become anything (at least in theory), so you lose most of these cell types specific features
- The use of the iPSCs is then to re-differentiate them, and that’s what people have been attempting to do

***Yamanaka factors opened up the ability to do that, which is you create this stem cell that now potentially has the ability to be differentiated into something else***

- So you give it a different cocktail and you try to make it a neuron or a muscle cell, and then use that and a tissue replaces therapy
  - There’s a lot of research on that and a lot of groups trying to do that

*Regarding the question: what is the relationship between that and the epigenetics and methylation state*

- That has not been well explored
- That’s something that Alex and others are excited to do because it could be that you’re indirectly affecting the epigenome with these Yamanaka factors, and that if you translated that into an epigenetic programming protocol, you could have a lot more control over it
- Because one of the challenges with the Yamanaka factors is if you do this for long enough, eventually the stem cell becomes something much more like a cancer cell and just becomes unregulated growth
- Again, this has been a huge breakthrough in learning about this kind of cell reprogramming and de-differentiation

***But our ability to use Yamanaka factors in a practical way for tissue and cell replacements is not there, and Alex hopes that by converting it to an epigenetic level, it’ll be more tractable***

- Alex mentioned this is typically done with fibroblasts
- Peter assumes the experiment has been done where you sprinkle Yamanaka factors on cardiac myocytes, neurons, and things like that

**Do these other cells not regress all the way back to potent stem cells?**

- They do to varying extents
- If you truly have a pluripotent stem cell, in theory it shouldn’t matter where it came from because it’s potent
- With developmental factors, where did your first neurons come from?
  - You had a stem cell and then in the embryo or the fetus, there were factors that then coaxed that stem cell to become these other types of cells and tissues
- So if it’s truly pluripotent, you should be able to do that

**Alex thinks Peter is getting at something which is different, which is called partial reprogramming**

- Yamanaka and the people who have followed his work, they’re trying to do these things which is kind of stop halfway
  - ***What if you took a heart cell or a T-cell that’s lost a lot of function and you give it these Yamanaka factors, but you stop it before it really loses its cell identity, will it have gained some properties of its higher functioning youthful state without having lost it?***
  - There’s some provocative papers out there on this
- There’s a guy ([Juan Carlos Belmonte](https://altoslabs.com/team/leadership/juan-carlos-izpisua-belmonte/)) who’s done some work on this and some very provocative results in mice
  - Doing these partial reprogramming protocols and rejuvenating
  - Again, it’s mice, so all the usual caveats
  - But they are getting very striking improvements in function and eyesight, cognition, again in these mouse metrics
  - He’s certainly interested in trying to understand how that might be able to translate to humans
- The worry there would be that if you don’t control it, then you could make essentially a tumor
- Yamanaka factors have opened up that whole area of science that it’s possible to do these kinds of dramatic de-differentiations
- We don’t yet know how to really harness that in a context of human rejuvenation
  - But there’s a lot of people trying to figure that out

**If you had to guess with a little bit of optimism, where do you think this field will be in a decade?**

*What do you realistically think can happen with respect to addressing the aging phenotype vis-a-vis some method of reversal of aging, some truly geroprotective intervention?*

- Alex is optimistic and he’s a believer
- He thinks for specific organs and tissues and cell types, there will be treatments that rejuvenate them
- It’s hard to see in a decade that there’s just a complete rejuvenation of every single cell in tissue in a human, but joint tissues, the retina, immune cells, we’re learning so much about the biology related to rejuvenation and healthier states of them
- And then in combination with that, the **tools to manipulate them**, which is equally important
- You could understand what the biology is, but not have a way to intervene (the tools), to go in and edit these at a genomic level
  - To edit it at an epigenetic level
- To change the state and the delivery technologies to get them to very specific tissues and organs is also progressing tremendously

***Alex definitely sees a world in 10 years from now where we may have rejuvenation therapies for osteoarthritis, rejuvenation for various retinopathies, where we can rejuvenate full classes of immune cells that make you more resistant to disease, more resistant to cancer***

> “*I think we’ll see things that will have real benefits in improving health span*.”‒ Alex Aravanis

**This is an area that truly excites Peter more than anything else in all of biology**

- This question: if you can revert the epigenome to a version that existed earlier, can you take the phenotype back with you?
- And that could be at the tissue level, as you say, “*Could I make my joints feel the way they did 25 years ago? Could it make my T-cells function as they did 25 years ago?*”
  - And obviously one can extrapolate from this and think of the entire organism
- Peter grateful that Alex has taken the time to talk about something that’s really no longer his main project, but something for which he provides as good a history of as anyone vis-a-vis the liquid biopsies, and then a little bit of a glimpse into the problem that Alex is obsessed with today

§

## Selected Links / Related Material

**Moonwalk biosciences**: [Pioneering precision epigenetic medicines](https://moonwalk.bio/) | Moonwalk Bioscience (2024) | [1:00, 1:21:45]

**Illumina, Inc**.: [Illumina. This is the Genome Era.](https://www.illumina.com/) | Illumina (2024) [1:15]

**The GRAIL Galleri test**: [Galleri](https://grail.com/galleri-test/) | GRAIL (2024) | [2:00, 1:16:45, 1:22:30, 1:29:00, 1:46:00]

**Previous episode of** ***The Drive*** **with Karl Deisseroth**: [#191 – Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.](https://peterattiamd.com/karldeisseroth/) (January 17, 2022) | [6:30]

**Liquid biopsy group at Johns Hopkins**: [The Sidney Kimmel Comprehensive Cancer Center](https://www.hopkinsmedicine.org/kimmel-cancer-center/research/ludwig-center) | Johns Hopkins Medicine (2024) | [25:45]

**Previous episode of** ***The Drive*** **with Max Diehn**: [#213 ‒ Liquid biopsies and cancer detection | Max Diehn, M.D. Ph.D.](https://peterattiamd.com/maxdiehn/) (July 11, 2022) | [30:45]

**Women whose cancer was discovered through NIPT**: [Noninvasive Prenatal Testing and Incidental Detection of Occult Maternal Malignancies](https://jamanetwork.com/journals/jama/fullarticle/2389341) | *JAMA* (D Bianchi et al 2015) | [44:00]

**Factsheet on the CCGA**: [The Circulating Cell-Free Genome Atlas Study](https://grail.com/wp-content/uploads/2020/12/Fact-Sheet-The-Circulating-Cell-free-Genome-Atlas-CCGA-Study.pdf) | Grail [52:15, 56:30, 1:14:15,1:25:45]

**CCGA study blinded testing**: [Clinical validation of a targeted methylation-based multi-cancer early detection test using an independent validation set](https://www.annalsofoncology.org/article/S0923-7534(21)02046-9/fulltext) | Annals of Oncology (E Klein et al 2021) | [56:30]

**PATHFINDER study (an interventional study)**: [Blood-based tests for multicancer early detection (PATHFINDER): a prospective cohort study](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(23)01700-2/fulltext) | *The Lancet* (D Schrag et al 2023) | [1:14:15]

**GRAIL test and Kaplan-Meier survival curves**: [Prognostic Significance of Blood-Based Multi-cancer Detection in Plasma Cell-Free DNA](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9401481/) | *Clinical Cancer Research* (X Chen et al 2021) | [1:25:45]

**Episode of** ***The Drive*** **on cancer screening**: [#289 – AMA #56: Cancer screening: pros and cons, screening options, interpreting results, and more](https://peterattiamd.com/category/podcast/) | Peter Attia (peterattiamd.com) [1:37:15]

**Newsletter on cancer screening and all-cause mortality** : [The futility of estimating changes to all-cause mortality from target cancer screening studies](https://peterattiamd.com/life-extension-from-cancer-screening/) | Peter Attia MD (S Lipman, K Birkenbach, & P Attia, 2024) | [1:37:15]

**Original paper on hallmarks of aging**: [The Hallmarks of Aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/) | *Cell* (C Lopez-Otin et al 2013) | [1:43:45]

**Most recent paper on hallmarks of aging**: [Hallmarks of aging: An expanding universe](https://www.cell.com/cell/pdf/S0092-8674(22)01377-0.pdf) | *Cell* (C Lopez-Otin et al 2023) | [1:42:45]

**Alex’s recent** ***Nature*** **paper**: [A DNA methylation atlas of normal human cell types](https://www.nature.com/articles/s41586-022-05580-6) | *Nature* (N Loyfer et al 2023) | [1:45:45]

§

## People Mentioned

- [Richard (Dick) Tsien](https://med.nyu.edu/faculty/richard-tsien) (Professor of Neuroscience and Physiology and Professor of Neurology, Chair of Neuroscience and Physiology, and DIrector of the Neuroscience Institute at NY University, Emeritus Professor of Molecular & Cellular Physiology at [Stanford University](https://profiles.stanford.edu/richard-tsien?tab=bio)) [4:00]
- [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) (Professor of Bioengineering and of Psychiatry and Behavioral Sciences at Stanford University) [6:30]
- [Francis Collins](https://irp.nih.gov/pi/francis-collins) (NIH distinguished Investigator at the Center for Precision Health Research) [13:30]
- [Craig Venter](https://www.jcvi.org/about/j-craig-venter) (Founder and CEO of the J. Craig Venter Institute and expert in genomic research) [14:00]
- [Shankar Balasubramanian](https://www.ch.cam.ac.uk/person/sb10031) (Professor of Medicinal Chemistry at the University of Cambridge, developed sequencing by synthesis) [19:00]
- [Max Diehn](https://med.stanford.edu/diehnlab.html?tab=proxy) (Professor of Radiation Oncology at Stanford University and member of the Stanford Cancer Institute) [30:45]
- [Dennis Lo](https://www.cuhk.edu.hk/med/cpy/Research/DennisLo.htm) (Professor of Chemical Pathology at The Chinese University of Hong Kong, pioneered research on cell-free fetal DNA) [34:15]
- [Stephen Quake](https://med.stanford.edu/profiles/stephen-quake?microsite=cap-profiles-home&tab=cap-profiles-home) (Professor of Bio Engineering, of Applied Physics, and by courtesy, of Physics at Stanford University) [34:30]
- [Meredith Halks-Miller](https://bioevolutionlabs.com/team/meredith-miller-md/) (physician-scientist, expert in NIPT, and pioneer in developing liquid biopsies) [36:15, 44:00, 46:15]
- [Darya Chudova](https://www.linkedin.com/in/darya-chudova-78b28513/) (Chief Technology Officer at Guardant Health, bioinformatics scientist, expert in NIPT, and pioneer in developing liquid biopsies) [36:30, 44:00, 46:15]
- [Richard Klausner](https://altoslabs.com/team/leadership/rick-klausner/) (Founder and chief scientist at Altos Labs, Director of NCI from 1995-2001, and member of the National Academy of Sciences) [46:15]
- [Jay Flatley](https://www.illuminaventures.com/team/jay-flatley/) (former CEO of Illumina) [50:45]
- [Douglas Hanahan](https://www.ludwigcancerresearch.org/scientist/douglas-hanahan/) (Professor Emeritus at [EPFL](https://www.epfl.ch/labs/hanahan-lab/prof-douglas-hanahan/) and the Ludwig Cancer Research Institute, expert in the [hallmarks of cancer](https://aacrjournals.org/cancerdiscovery/article/12/1/31/675608/Hallmarks-of-Cancer-New-DimensionsHallmarks-of)) [1:41:15]
- [Yuval Dor](https://iias.huji.ac.il/people/yuval-dor) (Professor of Medicine at The Hebrew University of Jerusalem, corresponding author on the [DNA methylation atlas](https://www.nature.com/articles/s41586-022-05580-6)) [1:48:15]
- [Shinya Yamanaka](https://www.cira.kyoto-u.ac.jp/e/research/yamanaka_summary.html) (Director Emeritus & Professor at the Center for iPS Cell Research and Application at Kyoto University) [1:52:45]
- [Juan Carlos Belmonte](https://altoslabs.com/team/leadership/juan-carlos-izpisua-belmonte/) (Founding Scientist and Director of the San Diego Institute of Science, expert in using Yamanaka factors for cellular rejuvenation) [2:02:00]

§

![](https://peterattiamd.com/wp-content/uploads/2024/02/bio-alexaravanis-500x500.png)

##### Alex Aravanis, M.D., Ph.D.

Alex Aravantis earned a BS in Electrical Engineering and Computer Science from the University of California, Berkeley. He then moved to Stanford University where he earned an MS and PhD in Electrical Engineering as well as an MD.

Dr. Aravantis has spent 20 years leading research and development efforts, spanning basic research and technology development through late-stage clinical development. Dr. Aravantis holds more than 30 patents and serves on the scientific advisory board for several biotechnology start-up companies.

He was first recruited to Illumina, Inc. to work in R&D. There he developed multiple technologies, including clinical assays for the analysis of RNA and DNA from fixed tissues, whole exome analysis, massively parallel single cell transcriptomics, and liquid biopsy using cell-free nucleic acids. He was a co-founder of the spin-off company GRAIL, where he led teams developing a multi-cancer early detection test by combining hi-intensity sequencing and the latest tools of data science. He returned to Illumina as the Chief Technology Officer and Head of Research and Development. He focused on using next-generation sequencing to translate genomics to the clinic and accelerate scientific breakthroughs. Recently, Dr. Aravantis left Illumina to start Moonwalk Biosciences where he is leading development of precision epigenetic medicines. [[Illumina](https://www.illumina.com/company/news-center/press-releases/2020/891cfd5a-7bbe-4d2b-967f-93394b8f2bff.html)]

X: [@Alex\_Aravanis](https://twitter.com/Alex_Aravanis)