# #124 – AMA #15: Real-world case studies—metabolic dysregulation, low testosterone, menopause, and more

**Source:** [https://peterattiamd.com/ama15/](https://peterattiamd.com/ama15/)

---

As a follow up to [AMA #14](https://peterattiamd.com/ama14/) where Peter explained his framework for analyzing labs, this “Ask Me Anything” (AMA) episode focuses on a number of real-world case studies exploring metabolic dysregulation, low testosterone, menopause, hypothyroidism, elevated uric acid, and more. From the examples discussed, you can follow along how our clinical team goes about interpreting diagnostic measures and applying relevant research findings. Once again, Bob Kaplan, Peter’s head of research, will be asking the questions. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #15 show notes page](https://peterattiamd.com/ama15). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Should you stop taking supplements before getting a lab test? [2:45];
- Family history—Questions to ask and what to look for [5:30];
- The purpose of an oral glucose tolerance test (OGTT) [12:15];
- Case study—Insufficient muscle mass for proper glucose disposal [17:15];
- Why hemoglobin A1c is a relatively unhelpful metric [24:00];
- Case study—Exceeding carbohydrate tolerance [26:30];
- Case study—Metabolic dysfunction and a framework for metabolic health [33:30];
- Peter’s ideal tracking of metabolic health for all his patients [43:30];
- Contrasting presentations of hypogonadism—Low free testosterone [45:00];
- How sleep, exercise, and alcohol affect testosterone levels? [56:20];
- Case study—Surprisingly fast onset of menopause [59:25];
- Case study—Hypothyroidism and high cholesterol [1:07:00];
- Case study—Elevated uric acid and hypertension [1:10:55]; and
- More.

§

The Peter Attia Drive

Real-world case studies—metabolic dysregulation, low testosterone, menopause, and more

§

## Show Notes

## Should you stop taking supplements before getting a lab test? [2:45]

**Does Peter have patients stop taking their supplements before doing their lab tests?**

- Peter actually prefers that patients ARE taking the supplements that they typically take
- In fact, he will postpone lab work to allow for a person re-continue taking a supplement that they may have run out of
- For example, if a person is taking methylated B vitamins because they have high homocysteine, we wouldn’t want to run lab tests if they ran out of their supplement — we’d want to see their labs with the supplement to make sure it’s keeping homocysteine down

**The more important point**: You need to know how long it takes to see the effect of the intervention

For example, one of the longer tail things is looking at [omega-3 index](https://omegaquant.com/what-is-the-omega-3-index/)

- The [Omega Quant test](https://omegaquant.com/) looks at the red blood cell membranes and measures the amount of EPA and DHA (Omega 3 fatty acids)
- Your index number rises with increase fish consumption and/or taking fish oil supplements but it takes 3+ months to fully assimilate the change
- And if you think that the change is supposed to happen quicker, you could be misled into thinking you’re not giving them enough
- By contrast, with a drug like [Repatha](https://en.wikipedia.org/wiki/Evolocumab), a few doses would be sufficient to know if the drug is working or not

⇒ See [episode of The Drive with Bill Harris](https://peterattiamd.com/billharris/) for more on omega-3 fatty acids

## Family history—Questions to ask and what to look for [5:30]

**Is** [**23andMe**](https://www.23andme.com/) **data comparable to family history data?**

- “Actually, that pretty much tells me nothing . . . this stuff doesn’t mean Jack compared to your family history.”
- With the 23andME data, you CAN look at things like
  - i)  [TOMM40](https://en.wikipedia.org/wiki/TOMM40) gene to assess [risk of Alzheimer’s disease](https://en.wikipedia.org/wiki/TOMM40#Clinical_significance), and/or
  - ii) [FOXO3](https://en.wikipedia.org/wiki/FOXO3) — a gene [associated with longevity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7366647/)
- But the genes Peter thinks are important are things that they measure on their own (e.g., MTHFR, APOE, etc.)

**Family history data**

- Peter gives new patients a large form prior to their first visit
- He wants to know everything knowable about mother, father, both sets of grandparents, aunts and uncles, and siblings
- Cardiovascular disease, for example—does anybody have a history of cardiovascular disease? Did they take any medication for blood pressure, cholesterol? Did they ever have a stroke, chest pain, heart attack?
- Same questions around dementia, cancer, metabolic disease/diabetes
- Next, they prod the answers to those questions to understand context:
  - You may see a family history full of cancer, but then find out that they all smoked three packs a day
  - The patient may have a relative die of a heart attack at 50—Is this a case of [LP(a)](https://peterattiamd.com/lpa/)? Was this person an alcoholic and heavy smoker?

**Looking for patterns**

- The more time you spend gathering data, the more likely you’ll understand what’s really at the root of the genetic template that you inherited
- You’re looking for patterns—signature of cancer, dementia, cardiovascular disease
- Example —
  - About [1 in 10 people](https://www.sciencedirect.com/science/article/pii/S0019483218312781#:~:text=According%20to%20the%20National%20Heart,(ASCVD)%2C%20calcific%20aortic%20valve) show up with an elevated Lp(a), but the number by itself doesn’t tell you how bad of a problem it is
  - We know Lp(a) is bad, but is this a *big problem or just a medium problem*?
  - For the patients who have family members with a lot of sub 60 year old cardiovascular events AND elevated Lp(a) — you need to be acting on that in the **most aggressive manner**
  - But maybe you can afford to be less aggressive in the case where families have high Lp(a) but nobody’s having any events until their 80s

## The purpose of an oral glucose tolerance test (OGTT) [12:15]

**Oral glucose tolerance test (OGTT)**

- The OGTT is a really cumbersome test and it’s not done frequently especially not with the frequent sampling and looking at glucose and insulin like Peter does it
- Pregnant women might be familiar with a simple version of this test when screening for gestational diabetes
  - Blood test done before taking the glucose
  - Then 75 grams of glucose is ingested
  - Two hours later they do another blood draw
  - You see the glucose before and glucose after

**How peter does the OGTT for patients**

- 75 grams of a pure glucose drink
- Blood draw at time 0 (before ingesting glucose), 30 min, 60 min, and 90 min
- Measure both the insulin and glucose levels at each time point
- Over the 90 minute period, the patient is not allowed to eat, drink, or exercise
- *Note*: The test has to be considered in **one data point**—e.g., if the person hasn’t slept well in the week leading up to the test, or the person was on a very low carbohydrate diet coming into the test and didn’t refeed glucose before—you can misinterpret those tests a little bit
- Side effects:
  - *Feeling sick* — a lot of patients when infused with that much glucose feel incredibly sick
  - *Paradoxical crash of glucose* —
    - in some cases for patients who are especially insulin sensitive, they’ll experience a paradoxical crash of glucose after the fact because that huge amount of glucose causes such a rise in insulin in the short term because the body is sort of caught off guard
    - Their muscle is so insulin sensitive that they see kind of an overcorrection of glucose and they end up hypoglycemic

## Case study—Insufficient muscle mass for proper glucose disposal [17:15]

**“Patient A”**

Basics:

- 33, Male
- Asian descent
- Body type: Not overweight but high BF%

Meds while on a labs (pertinent):

- Metformin 500 mg BID

Fam Hx: **Some CVD. Longevity on his side**.

- Father: Hyperlipidemia
- Paternal grandmother: Alive and well, 86 YO. HTN and T2DM.
- Paternal grandfather: Fatal MI (69 YO)
- Mother: Hyperlipidemia
- Maternal Grandmother: Alive and well, 90 YO. Hyperlipidemia.

Med Hx:

- Lost 50# in about 2 years. High BF%, low LBM.
- OSA
- Past hx of obesity and metabolic syndrome.
- NAFLD
- ApoE 3/3
- Heterozygous for MTHFR – 677C/C, 1298 A/C

Imaging:

- No CAC done.

Nutrition:

- TRF 18/6
- Prolonged fasting
- Candy eater

Other Testing:

- Omega-3 Index: 7.1%

**Metabolic Test for Patient A**

![](https://peterattiamd.com/wp-content/uploads/2020/08/patient-A-1-1024x598.png)

**Figure 1. Patient A – metabolic test.**

*Observations*: This is somebody with **great metabolic numbers**

*More about* [*hemoglobin A1c*](https://en.wikipedia.org/wiki/Glycated_hemoglobin) *(HbA1c)—*

- HbA1c is trying to estimate the average blood glucose by looking at the amount of glucose that is stuck to hemoglobin—and if you can estimate how long a molecule of hemoglobin lives in circulation, you should be able to convert that to an average glucose
- For example,
  - An HbA1c of 5.0% corresponds to an estimated average blood glucose of 97 milligrams per deciliter
  - HbA1c of 6.0% corresponds to an estimated average blood glucose of 126 mg/dL — “***pre-diabetic***”
  - HbA1c of more than 6.5% estimates average blood glucose to be 140 mg/dL — ***diabetic***

For Patient A—

- His HbA1c of 5.1% suggesting his average blood sugar is about 100 mg/dL
- His fasting glucose is 75
- His fasting insulin is 5
- This patient *appears* to be very healthy metabolically, despite some imperfect dietary patterns (e.g., candy eater)

**OGTT results for Patient A**

![](https://peterattiamd.com/wp-content/uploads/2020/08/patient-A-2-1024x740.png)

**Figure 2. Patient A – OGTT results.**

![](https://peterattiamd.com/wp-content/uploads/2020/08/patient-A-3-1024x670.png)

**Figure 3. Patient A – Insulin.**

*Observations*:

- Patient A starts with a baseline blood glucose of 75 which is exceptional
- However, it shoots up to 184 and basically stays there for the next hour
- Insulin goes up to 47 which isn’t outrageous, but interestingly, it stays about there until about 90 minutes when it drops to 77
- The question*: Why isn’t he putting this glucose away? What could be happening here?*
  - He doesn’t meet the criteria for type 2 diabetes under any circumstance, but clearly his OGTT does not look good
  - This is a great example of the type of thing you miss when you only look at these fasting labs without what we would call a “provoked test”

*The diagnosis:*

- Insufficient muscle mass
- Insufficient ability to dispose of glucose through either *insulin-dependent* and the *insulin-independent* methods of glucose disposal
  - See podcast [episode with Inigo San Millan](https://peterattiamd.com/inigosanmillan/)

**Prescribed therapy for Patient A**:

1—Start wearing a CGM

- Peter wants to see how high his blood glucose is getting during the day
- Wants to understand avg. blood sugar (and reconcile it with the hemoglobin A1c) as well as his standard deviation from the average

2—Resistance exercise

- He need to put on some muscle mass
- He could also afford to lose some body fat, however, the way that we want to reduce his body fat percentage is actually put muscle mass on you and “dilute” the fat
- So this is one of those patients that has the challenge of needing to become **anabolic** with respect to muscle while becoming **catabolic** with respect to fat simultaneously

## Why hemoglobin A1c is a relatively unhelpful metric [24:00]

- The [hemoglobin A1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin) is a relatively unhelpful number because it is *so dependent on that assumption that our red blood cell lives 90 days*
- But there are so many cases when a patient has a red blood cell that lives too long or too short relative to that baseline assumption, therefore their HbA1c either grossly underestimates or grossly overstates their average blood glucose
- In the case of this patient, once he was wearing a CGM his average blood glucose was actually higher than 100 milligrams per deciliter (which was predicted by the HbA1c)

Peter’s personal example:

- Peter has the [beta thalassemia trait](https://en.wikipedia.org/wiki/Beta_thalassemia)—he’s got really tiny red blood cells that stick around for a long time because they’re just less likely to get mechanically destroyed by his spleen
- This leads to an **overestimation** of average blood glucose as predicted by his HbAlc
- His HbA1c typically measures at 5.6%, yet his CGM data has his average blood sugar at 95 mg/dL which would correspond to a HbA1c of 4.8%
- Conversely, Patient A has larger red blood cells that lead to accelerated destruction and a HbA1c that **underestimates** average blood glucose

## Case study—Exceeding carbohydrate tolerance [26:30]

**“Patient B”**

Basics:

- 43, Female
- European descent
- Body type: BMI 19. Low muscle mass

Meds while on a labs (pertinent):

- None

Fam Hx:

- Mother: Uterine cancer
- MGM: Uterine cancer and CVA
- MGF: Lung cancer (smoker)
- Father: CVA
- PGM: CVA
- PGF: 74 – dec – MI, TIAs
- P aunt: TIA, HTN
- Brother: Parkinson’s

Imaging:

- None

Nutrition:

- TRF 18/6
- Low carb, high fat diet. SFA mostly from dairy and meat.
- 55% Fat, 18% CHO, 27% PRO

Exercise:

- Yoga 2x/week
- HIIT boot camp 1x/week
- Limited/infrequent weight or resistance training

**\*Overall observations BEFORE the OGTT test:**

- Great metabolic numbers
- Low BMI
- Low-ish but reasonable muscle mass for age/gender
- Decent dietary macros

![](https://peterattiamd.com/wp-content/uploads/2020/08/patient-B-1-1024x240.png)

**Figure 4 – Patient B – OGTT results.**

*Observations:*

- At 60 minutes, both glucose and insulin are “off the chart”
- At 2 hours—
  - Glucose was down but Peter wants to see less than 100
  - Insulin was still elevated at 52, ideally would want that to be no more than twice baseline insulin

*8 day sample of CGM data*:

![](https://peterattiamd.com/wp-content/uploads/2020/08/patient-B-3-1024x484.png)

**Figure 5. Patient B – 8 day sample of CGM data.**

**Diagnosis and concluding observations:**

- This patient is someone who is clearly eating more carbohydrates than they are capable of disposing
- *\*Moral of the story*: There is no one size fits all. There is no number of carbs that is the right number of carbs. There are people out there that can ingest 500 grams of carbohydrates a day. It’s just a question of, *can you dispose of them adequately?*
- In the case of this patient, the reality of it is with her muscle mass and her type of exercise, she was exceeding her carbohydrate tolerance
- Fasting insulin or fasting BG would not have provided any clues to the underlying potential IR present.
- CGM also confirmed her average BG and standard deviation were above target.

> “The point of this case is using this OGTT becomes a great flag to see something that you wouldn’t miss.”

**\*Important points about the OGTT test:**

*First*, Peter’s preferred ranges are typically more stringent than the “normal” ranges listed on lab results

*Secondly*, you can be mislead by results of an OGTT if you take the test while on a low-carb diet/ketogenic diet or you are in the middle of a prolonged fast

- That could result in insulin and glucose shown to be very high due to “physiologic insulin resistance”—An example would be the body basically shutting down the muscle to accept glucose on account of preparing the body to save as much glucose as possible for the brain
- Avoid this by refeeding carbs for three days before the OGTT to get the system primed again

*Third*, someone on a ketogenic diet will have much higher free fatty acids

- This will show up as a bad thing because for someone with T2D they will also have elevated FFA
- But the test won’t be able to distinguish that the keto dieter is just someone who is oxidizing fat constantly

## Case study—Metabolic dysfunction and a framework for metabolic health [33:30]

**Peter’s framework for metabolic health**

- Metabolic health is a foundation with 3 pillars that stand on it
- Peter uses this framework to think about chronic disease
- The 3 pillars are the 3 disease states that are responsible for the *majority* of chronic deaths
  - 1) Atherosclerotic diseases
  - 2) Cancer
  - 3) Neurodegenerative diseases

Metabolic health is the **foundation** for which these disease states are set upon

- If the metabolic state of health of an individual is anything other than *fully optimized*, it is going to increase risk for each and every one of the three pillars of chronic disease
- You can think of metabolic health as a continuum with the most extreme state of metabolic dysregulation being unregulated [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)
- T2D is a situation in which the patient is completely unable to partition fuel, even at the most basic level, which is to get glucose out of the circulation.
- A person’s risk of the pillar diseases goes up significantly
- Obesity and type 2 diabetes probably represent the [second leading cause of cancer](https://peterattiamd.com/wp-content/uploads/2018/12/obesity-and-cancer-768x930.gif) (second only to smoking)
- And there’s no disputing the relationship that type 2 diabetes has on Alzheimer’s disease and on cardiovascular disease

> “If you want to further reduce your risk of Alzheimer’s disease, cancer, atherosclerosis, in addition to doing all of the “disease these specific things,” you must be the most metabolically flexible, metabolically healthy person imaginable.”

*What does that mean?*

- You must be able to dispose of glucose really, really efficiently.
- This is why many of Peter’s patients wear a CGM — it’s a tool to be able to see if average glucose is below 100 with a standard deviation below 15 — which gives you a sense of how much it’s cycling and therefore how low you’re keeping insulin levels

*You can also look at* ***lipids***

- A person will sometimes have very high LDL, very high triglycerides and very low HDL
- In fact, the condition of [metabolic syndrome](https://en.wikipedia.org/wiki/Metabolic_syndrome) is partially defined by two of those
- Metabolic syndrome that is meant to closely approximate insulin resistance
- It’’s defined by having at least 3 of the following 5 things
  - Elevated waist circumference: waist to hip ratio > 0.90 (male); > 0.85 (female), or BMI > 30 kg/m2
  - Elevated fasting blood sugar: >100 mg/dL
  - Elevated blood pressure: systolic BP > 130 or diastolic BP >85 mm Hg
  - Elevated triglycerides: > 150 mg/dL
  - And low HDL: < 40 mg/dL for males; < 50 mg/dL

\*\*\*\*\*

**Case study – “Patient C”**

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-C-glycemic-control-1024x281.png)

**Figure 6. Patient C – Glycemic control.**

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-C-lipids-1024x347.png)

**Figure 7. Patient C – Lipid panel.**

*At first glance—*

- This patient does NOT meet the criteria to be considered having metabolic syndrome
- His lipid panel also shows a good outlook
- In fact, if he goes to the doctor, he will most likely be told he has a complete bill of health

*Digging a little deeper—*Looking at [liver function test](https://en.wikipedia.org/wiki/Liver_function_tests) (LFT) — These are enzymes that are produced by the liver under the stress of the liver. So as the liver is experiencing any inflammation or scarring, these numbers will get higher and higher and higher.

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-C-LFT-1024x407.png)

**Figure 8. Patient C – LFTs.**

Note: Peter thinks of normal ALT and AST as being **below 20** whereas the labs will say that below 40 is normal (see [Rob Lustig episode](https://peterattiamd.com/roblustig/) of The Drive)

*Inflammation markers—*

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-C-Inflammation-markers-1024x242.png)

**Figure 9. Patient C – Inflammation markers.**

*Other important metrics—*

- [Homocysteine](https://en.wikipedia.org/wiki/Homocysteine) = 12 (lab will say this is pretty normal, but Peter thinks it’s too high)
- [Uric acid](https://en.wikipedia.org/wiki/Uric_acid) = 7.8
  - Even the lab says that this number is too high — but the lab is thinking about this through the lens of gout
  - Peter on the other hand sees this as very concerning through the lens of blood pressure and insulin resistance (see [Rick Johnson’s episode](https://peterattiamd.com/rickjohnson/) of The Drive)
  - Peter wants his patients **below 5** on the uric acid scale, “non-negotiable”
  - Ideally, uric acid is in the 2-3 range
  - Peter has seen incredible benefits on blood pressure and insulin simply by reducing the uric acid

\*Summary of observations about Patient C so far:

- This guy is 0 for 5 on metabolic syndrome
- He looks to be as insulin sensitive as they come
- Yet his uric acid is 7.8 and his homocysteine is 12 — both **signs of inflammation**

*Looking at his insulin and OGTT results—*

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-C-OGTT-1024x281.png)

**Figure 10. Patient C – OGTT results.**

*Notable observations:*

- Fasting insulin at baseline is quite high
- At 90 minutes, insulin is still dramatically elevated

**Thoughts and lessons**:

- This is a guy who metabolically slips through the cracks in most cases
- You can’t just look at the traditional markers of metabolic syndrome — you’ve got to dig a little bit deeper

**How the treatment has gone with Patient C**:

- Goal was to reduce inflammation by correcting homocysteine and insulin levels
  - It has been stubbornly difficult to correct his homocysteine—He’s got an [MTHFR](https://en.wikipedia.org/wiki/Methylenetetrahydrofolate_reductase) mutation that has made it complicated
  - It took a year to get this patient’s fasting insulin to a normal range
- CGM became a very helpful tool for him as well on the behavioral front, because he was struggling with some of the things he was eating
- He struggled with some bad eating habits — He runs marathons was mainlining energy goos and such and it took him a while to understand how damaging those foods can be

## Peter’s ideal tracking of metabolic health for all his patients [43:30]

- First, put a CGM on everyone
- He would NOT wait until they fail an OGTT
- The intervention begins once your **avg. blood sugar is above 100, or your std dev. is above 15**

*Why do it this way?*

- Because your CGM metrics start to look concerning YEARS before you might fail an OGTT
- Your HbA1c looks concerning nearly a decade after an OGTT starts to look concerning

> “We literally wait until your hemoglobin A1c is broken, which means by definition your average blood sugar is about 140. By this point you’ve already got impaired erections. You’re already losing your vision. You already doubled your risk of cancer and heart disease and Alzheimer’s. Like we’re going to wait until you got there to say, ‘Oh, we better do something about this.’ It really doesn’t make any sense obviously.”

## Contrasting presentations of hypogonadism—Low free testosterone [45:00]

**Important prerequisites**:

- [Video of Peter explaining males sex hormones](https://vimeo.com/336926305/9be146c683)
- When Peter says “low testosterone” he’s actually referring to low “**free**” testosterone because that is what is acting physiologically
- Peter only treats a patient for low free testosterone when it is *accompanied by symptoms*

**First order question when investigating the cause of low free testosterone**:

1. Is the problem in the testes whereby the body is failing to make enough? (Primary hypogonadism)
2. Or is the problem that the brain not getting the signal to tell the testes to make more? (Secondary hypogonadism)

\*\*\*\*\*

**Case study – Secondary hypogonadism**

**“Patient D”**

- 28, Male
- European descent
- Body type: BMI: Average. Lean..

Meds while on a labs (pertinent)

- None

Fam Hx: Remarkable for CVD

- Father:  9 Stents, hyperlipidemia – SMOKER
- Paternal grandfather: Fatal MI, HTN.

Med Hx:

- Hypogonadism – past treatment with HCG and testosterone cypionate.
- Hypothyroidism

Social Hx:

- Poor sleep quality and duration – A function of social life.
  - Travels a ton for work – Asia, Europe, North America
  - Robust social life – late nights, alcohol

Imaging:

- MRI of pituitary –  Negative (ruling out a [pituitary adenoma](https://en.wikipedia.org/wiki/Pituitary_adenoma))

**Lab tests**:

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-D-low-t-1024x250.png)

**Figure 11. Patient D – Low testosterone.**

\**Note*: This lab was measured free T in picograms per milliliter but it measured total T in nanograms per deciliter. A better comparison would be using nanograms for free T which would put free T at 4.16. So you can now see that free T is only 4.16 of the 234 total T making it just 2% of the total.

*Observation from lab*: Free T of 4.16 places him well below the lower limit (5th to 10th percentile) AND he’s experiencing symptoms.

*Now let’s look at **LH** and **FSH**—*

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-D-male-hormones-1024x345.png)

**Figure 12. Patient D – hormones.**

*Observation and diagnosis:* Given that LH and FSH are also at the very bottom of the reference range, this thereby confirms the diagnosis of **secondary hypogonadism** (aka central hypogonadism)

**Therapy for Patient D**:

First line of therapy—

- Fix his sleep, nutrition, and alcohol to get LH and FSH high enough to actually get his testosterone higher
- After 9 months, Patient D’s LH and FSH doubled, however, his free testosterone levels did not go up enough

Second line of therapy—

- Next, Peter prescribed Clomid—a drug that tells the hypothalamus, to tell the pituitary, to make more FSH and LH by basically tricking it with respect to estradiol levels
- Patient D is currently in the second line of therapy and being monitored

Last line of therapy—Exogenous testosterone

- For a 28 year old, Peter would NOT want to turn to exogenous T unless he had to

\*\*\*\*\*

**Case study – Primary hypogonadism**

**“Patient E”**

- 49, Male
- Body type: BMI: Lean. ~10% BF

Meds while on a labs (pertinent)

- After labs were on t.cypionate 0.25 mL 2x/week.

Fam Hx: Irrelevant.

Med Hx:

- Anxiety
- Insomnia
- IBS

Social Hx:

- Poor sleep quality and duration due to anxiety.
- High anxiety
- High stress work environment
- Frequent travel impacting sleep quality

Nutrition:

- TRF 18/6
- Low carb.
- Alcohol: Minimal

Exercise

- Strict weight training and endurance training.

**Symptoms of low testosterone (BEFORE treatment)**

- Low Libido
- Low mood and motivation – apathetic.

Pre-treatment lab work:

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-E-before-1024x962.png)

**Figure 13. Patient E – before treatment.**

*Observations:*

- Total T and Free T is in the 20th percentile
- His estradiol is quite robust
- And his FSH and LH are very high — especially for such a low free testosterone
- That suggests that his **brain is perceiving and doing its best to tell the testes what they need to do**

*Next steps—*

- First, make sure that the body has enough substrate
  - In this situation, Patient E didn’t because his DHEA-S was only 73
- Secondly, make sure he’s not turning too much of his testosterone into dihydrotestosterone (52) or estradiol (45)

**Possible treatment approaches:**

1-One approach is you can block some of the conversion to estrogen—but when the estrogen is only 45 that doesn’t make a lot of sense b/c you also run the risk of having the estrogen too low

2-Another approach is you can block the conversion of testosterone to DHT using 5-alpha-reductase inhibitors—but if they’re not symptomatic from that (e.g., enlarged prostate or hair loss), it might not be the best approach given those drugs can come with some *sexual side effects*

3-For Patient E, the first order attempt would be to **replace the DHEA-S** which is only at 73—if you have more of the building block for testosterone, will you make more of it?

- Peter tried this approach with patient DHEA but it didn’t really do anything

4-Next, you can try an injectable form of testosterone called [testosterone cypionate](https://en.wikipedia.org/wiki/Testosterone_cypionate)

- For Patient E, Peter started with *100 mg per week*

**\*Results AFTER treatment with 100 mg/week with testosterone cypionate**

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-E-after-1024x748.png)

**Figure 14. Patient E – after treatment.**

*Observations:*

- Peter says that they “overshot” with that dose
- His total T and Free T numbers were “supraphysiologic” which is not the intended goal

*More technical notes for those interested*:

- His LH and FSH of course became unmeasurable and his sex hormone binding globulin fell to 30
- What’s neat from a physiology standpoint is… his sex hormone binding globulin started at 87 (why he started out with a free T that was only 1% of his total T)
- He also had a relatively high estradiol, so in anticipation of his estrogen going through the roof once he was given injections they put him on an estrogen blockage — “*but we kind of overdid it.*”
- His estradiol ending up falling below 25 and with it, his SHBG fell to 30—that’s why his free T went up to 2.5% of his total T (from only 1% pre-treatment)

**Clinical outcome after treatment** (all that really matters):

- Reduced body fat percentage
- Increased in strength from strength training
- Improved libido/sex drive
- Improved mood – blunted response to stressors from work
- Testicular atrophy (Did not cycle him on/off — he wanted to stay on this as he had no concerns with the long term impact of that as it pertained fertility)

## How sleep, exercise, and alcohol affect testosterone levels? [56:20]

**Alcohol**

- Alcohol negatively impacts testosterone levels indirectly most clearly through the damage it does to sleep quality

**Sleep**

- Sleep is such an important part of hormone synthesis at the pituitary level
- Managing sleep quality and quantity is of utmost importance:
  - Blue light blockers
  - Reduction of cortisol at night
  - Less alcohol consumption
  - Less late-night eating
- Sleep is especially important in the cases of secondary hypogonadism
- The association with low testosterone and low sleep is not trivial, *but it’s not clear which one’s causing the other*

**Exercise and muscle mass**

“*I don’t think that muscle mass gets enough attention in the longevity literature*”, says Peter

When an older person puts on more muscle—

- They are less likely to fail and break a hip
- They also may experience a higher quality of life through greater activities of daily living

Using testosterone to aid in muscle mass—

- Peter says it’s clear at this point that testosterone supplementation *does not* increase the risk of prostate cancer
- And if it does increase the risk of cardiovascular disease, it’s in the most minor way imaginable
- When you consider the longevity benefits of muscle mass aided by testosterone supplementation, you can make the case that the benefits outweigh any potential downsides related to chronic diseases

## Case study—Surprisingly fast onset of menopause [59:25]

> “I pulled this case because of how much it surprised me. This was one of those cases where I’d never seen anything like this in terms of speed.”

**“Patient F”:**

Patient F went from asymptomatic perimenopausal woman to completely symptomatic and menopausal *within 7 months*—Thus, requiring HRT to alleviate symptoms.

Basics:

- 47, Female
- Body type: BMI: Lean

Meds while on a labs (pertinent):

- Mirena IUD
- Put on pellets when creams and oral estrogen failed

Fam Hx: .

- Mother: menopause 48 YO

Med Hx:

- RLS
- Climacteric symptoms

Social Hx:

- Poor sleep quality when off HRT
- High social stressors – family, work.
- High stress work environment

Nutrition:

- Alcohol: 5-7 per week

**Patient F in August 2017**

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-F-aug-2017-804x1024.png)

**Figure 15. Patient F – lab results from August 2017**

- Her lab results were so good it was “kind of comical” says Peter
- *Side note*: Even her cholesterol was the lowest Peter had ever seen (funny anecdote: she was eating 12 eggs per day)
- She was having regular periods
- And given that Peter drew blood during this woman’s [follicular phase](https://en.wikipedia.org/wiki/Follicular_phase), her estradiol (183), FSH (11), and LH (12) were “*the most normal numbers I’ve ever seen*” indicating that this woman *[should be]* several years from menopause
- **Her only complaint in 2017**: she would occasionally get these vasomotor symptoms at night (hot flashes and sweat through her bed sheets)

![](https://peterattiamd.com/wp-content/uploads/2020/08/estrogen-and-progesteron-cycle-1024x534.jpg)

**Figure 16. Female hormone cycle.** Image credit: [PrimalEye](https://primaleye.uk/how-female-hormones-affect-your-diet/)

==> More about female hormones in [AMA #4](https://peterattiamd.com/ama04/)

**Patient F in March 2018 (7 months later)**

- Patient explains that her vasomotor symptoms (night sweats) are really increasing
- They decided to do another blood draw, results shown below—

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-F-march-2018-737x1024.png)

**Figure 17. Patient F- March 2018.**

*Observations and diagnosis*:

- This is complete, full-on menopause
- They repeat the test which confirms this finding
- Peter was so surprised, they used the Dutch test which gives us more insight into the sub-fractions of estradiol — this time done during her [luteal phase](https://en.wikipedia.org/wiki/Luteal_phase)

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-F-DUTCH-test-842x1024.png)

**Figure 18. Patient F – DUTCH test.**

*Observations*: They found the same thing—zero progesterone, zero testosterone, and zero of any estrogen (estrone, estradiol, and estriol along with all of the fractions of estrone like 16-hydroxy, 4-hydroxy and 2-hydroxy)

**Concluding thoughts**:

- Peter says, “what’s mind boggling to me is this is a woman who basically six months earlier had all of these hormones.”
- A possible related observation was that Patient F’s symptoms were “relentless and devastating”
- She was “unquestionably the most difficult patient that I have ever had to alleviate symptoms of menopause through”

> “That was just such a great teaching point for me. . .I’ve never seen that. And I’ve watched many women go through menopause, but I’ve never seen something happen so quickly.”

## Case study—Hypothyroidism and high cholesterol [1:07:00]

⇒ Please check out [Peter’s video](https://vimeo.com/337835256/765434e953) where he explains thyroid hormones

**“Patient G”**

Basics:

- 66, Female
- Body type: Low BMI

Meds:

- No pharmaceuticals
- B12/MF
- EPA/DHA
- Calcium, vitamin D, vitamin K2, boron.

Fam Hx: .

- Mother: Died at 99 years old due to a fall
- Father: Died at 92 due to a cholecystectomy

Med Hx:

- Osteopenia
- Exposure to DES in utero.

Nutrition:

- Low carb. High fat.

Imaging:

- CAC of zero at age 66 (despite high cholesterol)

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-G-Lipids.png)

**Figure 19. Patient G – Lipid panel.**

*Observations from lipids:*

- Doesn’t quite look like she has FH
- She does have pretty high cholesterol and ApoB, HOWEVER, not in a pattern that would look like metabolic syndrome (i.e., she has low VLDL, low triglycerides)
- And given her coronary artery calcium score of zero in her mid sixties, you clearly understand that there’s something about her elevated cholesterol and ApoB that is NOT particularly problematic

*Next, let’s look at her thyroid—*

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-G-thyroid-1024x636.png)

**Figure 20. Patient G – Thyroid numbers.**

*Observations*:

- TSH is a tab above normal
- Ratio of free T3 to reverse T3 is below 0.2
- Going back in time, her TSH and her ratio of free T3 to reverse T3 has alway been in this range
  - Why? ⇒ Probably due to her nutrition—She doesn’t eat many calories would could impact her reverse T3
    - *Side note*: This is pretty normal when fasting—as you restrict calories, the body tries to compensate by slowing metabolic rate and the best tool it has to do that is raising reverse T3, which basically just means shuttling more T4 into reverse T3 than free T3

**Possible therapeutic options**:

*\*Peter makes the following important point*: Before using lipid lower agents to treat elevated LDL and ApoB, you should first use the right versions of T4, T3 to fix the hypothyroidism

Looking specifically at “Patient G”—

- Peter is debating whether it makes sense to intervene and try to lower her LDL cholesterol and ApoB
- It’s not clear as to if they should treat this for 2 main reasons: 1) **Her calcium score is zero**, and 2) She doesn’t have any **symptoms** of hypothyroidism even though her thyroid numbers aren’t perfect

*But what if her* ***calcium score was positive*** *(say at 100)?*

- Given her LDL and ApoB is elevated, “*anybody would jump all over treating*”
- *Where you’d make a mistake* in this patient is if you tried to correct LDL and ApoB with lipid lowering agents instead of first using the right versions of T4, T3 to fix the hypothyroidism
- *So had she had a positive calcium score*, Peter would have done the following—**A low dose of T4 and a reasonable dose of T3** because of the high reverse T3.
  - Typically if a patient has high reverse T3 and you *just* give them T4, you’re just giving them more T4 substrate to make more reverse T3 (which could make the problem worse)

*Peter’s main point—*

- Make sure you’re always paying attention to thyroid function
- He likes to see TSH below 2 if someone’s got lipid issues that you want to treat

## Case study—Elevated uric acid and hypertension [1:10:55]

**“Patient H”**

Basics:

- 46, Male
- Body type: Normal BMI
- Hx: Prior to onboarding, patient was diagnosed with [essential HTN](https://en.wikipedia.org/wiki/Essential_hypertension), blood pressure ranging from 140/90 to 160/90 mmHg.
  - He was treated with [lisinopril](https://en.wikipedia.org/wiki/Lisinopril) (ACEi) bringing him into the 130/90 range (still higher than ideal for 46 year old, especially if he’s interested in longevity)

Meds:

- Uloric 40 mg QD
- Lipitor 20 mg
- 6/2020: Added Repatha.

Fam Hx: .

- HTN: Father and Uncle
- CVD: Maternal and Paternal Grandfather.

Med Hx:

- Essential HTN
- Mixed hyperlipidemia
- Atherosclerotic heart disease with evidence of calcification on CAC

Nutrition:

- Low carb. No signs of metabolic syndrome or insulin resistance.

Exercise:

- Weight training 3x/week
- Zone2 training 3 hr a week.

Imaging:

- **CAC of 88** – Approximately **85th percentile** for age. (even more reason to be aggressive in treating blood pressure)

\*To reiterate: **This is a guy that on paper looked really good. He’s also very muscular and lean. He runs and exercises six days/week. He also eats well**.

*Looking at his initial labs—*

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-H-1-1024x241.png)

**Figure 21. Patient H – Initial Labs when presenting with essential hypertension.**

*Observations*:

- His uric acid was 6.1
- It was also quite stubborn—never went down with a dietary change (tweaking protein levels, reducing fructose, etc.)
- Peter could not get his uric acid below 6, and the target was below 5
- See [Rick Johnson podcast](https://peterattiamd.com/rickjohnson/) to understand the importance of lowering uric acid

*Labs after ~18 months on Uloric—*

![](https://peterattiamd.com/wp-content/uploads/2020/08/Patient-H-2-1024x678.png)

**Figure 22. Labs after ~18 months on Uloric.**

*Observations*:

- Uloric “fixed” uric acid
- His HTN resolved even with a persistently high homocysteine
- He no longer required ACE inhibitor (for blood pressure)

**Concluding thoughts**:

- This is a pretty unusual response to just lowering uric acid
- But it’s also a **great teaching point**—
  - **Do NOT go after blood pressure until you’ve got the uric acid below 5**
  - Only then start playing with the blood pressure medication
- **\*The broader point**: Try to fix the *insulin resistance and metabolic syndrome* first (which in this case he didn’t have, but he did have the elevated uric acid) ***before*** you introduce drugs to treat blood pressure.

*What determines uric acid levels?*

- Things that can drive up uric acid levels include:
  - People who eat foods with lots of DNA and RNA (i.e., protein sources)
  - Yeast in the beer
  - Fructose
  - But the biggest part may be **genetics**, says Peter ⇒ “*I don’t know why it is that in some patients you can remove all of the normal impediments to normal uric acid metabolism and it’s still elevated.*”
- For Peter personally—
  - Despite eating and exercising well, he can’t get his uric acid below 5.5 without using [allopurinol](https://www.webmd.com/drugs/2/drug-8610/allopurinol-oral/details)
  - He has a family history of hypertension

⇒ Make sure to check out [Rick Johnson’s episode](https://peterattiamd.com/rickjohnson/) for more on the importance of managing uric acid levels

*Peter’s internal standard for blood pressure*: **Below 120/80** without producing any symptoms of lightheadedness

§

## Selected Links / Related Material

**At home Omega-3 index test looking at the levels of EPA/DHA**: [Omega-3 Index](https://omegaquant.com/) | (omegaquant.com) [4:00]

**See episode of The Drive with Bill Harris for more on omega-3 fatty acids**: [#83 – Bill Harris, Ph.D.: Omega-3 fatty acids](https://peterattiamd.com/billharris/) | Peter Attia (peterattiamd.com) [4:00]

**About 1 in 10 people roughly have an elevated Lp(a)**: [Lipoprotein(a): An independent, genetic, and causal factor for cardiovascular disease and acute myocardial infarction](https://www.sciencedirect.com/science/article/pii/S0019483218312781#:~:text=According%20to%20the%20National%20Heart,(ASCVD)%2C%20calcific%20aortic%20valve) (Enas et al., 2019)  [10:45]

**See episode of The Drive with Iñigo San Millán for more on exercise and different methods of glucose disposal**: [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com)   [22:45]

**Obesity and type two diabetes probably represent the second leading cause of cancer (after smoking)**: [35:00]

- [#32 – Siddhartha Mukherjee, M.D., Ph.D.: new frontiers in cancer therapy, medicine, and the writing process](https://peterattiamd.com/sidmukherjee/) | Peter Attia (peterattiamd.com)
- [#62 – Keith Flaherty, M.D.: Deep dive into cancer— History of oncology, novel approaches to treatment, and the exciting and hopeful future](https://peterattiamd.com/keithflaherty/)  | Peter Attia (peterattiamd.com)

**See episode of The Drive with Rob Lustig where they discuss normal ALT and AST as being below 20**: [#14 – Robert Lustig, M.D., M.S.L.: fructose, processed food, NAFLD, and changing the food system](https://peterattiamd.com/roblustig/) | Peter Attia (peterattiamd.com) [39:00]

**See episode of The Drive with Rick Johnson for the importance of managing uric acid**: [#87 – Rick Johnson, M.D.: Fructose—The common link in high blood pressure, insulin resistance, T2D, & obesity?](https://peterattiamd.com/rickjohnson/) | Peter Attia (peterattiamd.com) [40:00, 1:12:30]]

**Video of Peter explaining males sex hormones**: [Male sex hormones](https://vimeo.com/336926305/9be146c683) | A|M (vimeo.com) [45:15]

**Test Peter used to get more insight into the sub-fractions of estradiol:** [Dutch test](https://dutchtest.com/) | (dutchtest.com) [1:04:15]

**Video of Peter explaining thyroid hormones**: [Thyroid hormones](https://vimeo.com/337835256/765434e953) | A|M (vimeo.com) [1:08:00]

§

## People Mentioned

- [Bill Harris](https://omegaquant.com/dr-william-s-harris/) [4:00]
- [Dr. Joseph Kraft](https://pharmacistcatherine.net/2017/02/22/dr-joseph-r-kraft-1922-2017/) [15:15]
- [Iñigo San Millán](https://twitter.com/doctorinigo?lang=en) [22:45]
- [Rob Lustig](https://twitter.com/RobertLustigMD?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [39:00]
- [Rick Johnson](https://www.cudoctors.com/Find_A_Doctor/Profile/9426) [40:00, 1:12:30]

§