# #146 – Guy Winch, Ph.D.: Emotional first aid and how to treat psychological injuries

**Source:** [https://peterattiamd.com/guywinch/](https://peterattiamd.com/guywinch/)

---

Guy Winch is a psychologist, author, and co-host of the Dear Therapist podcast. In this episode, Guy speaks to the commonality of the human condition with relatable stories from his decades of therapy sessions as well as his own experience with incessant rumination in the early days of his private practice. He shares insights on what he sees as an epidemic of rumination that leads to career burnout, the consequences of social comparison heightened by social media, and the psychological impact of not recognizing success. He emphasizes the need for a “psychological medicine cabinet” and provides concrete and practical tools for treating emotional injuries. He concludes with a discussion about the widespread impact of the coronavirus pandemic on emotional health and how we can use experienced psychologists in a time when it’s especially needed.
*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/guywinch/the_Drive_public.png)

Play

#146 - Guy Winch, Ph.D.: Emotional first aid and how to treat psychological injuries

#146 - Guy Winch, Ph.D.: Emotional first aid and how to treat psychological injuries

1x15s30s

0:001:57:29

## We discuss:

- The unique format and impetus for Guy’s podcast with Lori Gottlieb (3:00);
- How Guy pieced together the many different schools of thought in psychology to develop his own unique approach (7:45);
- The most important component of successful therapy, and why it sometimes makes sense to “break the rules” (19:30);
- Insights extracted from Guy’s own battle with extreme stress and anxiety around finishing his education and starting his private practice (28:15);
- The epidemic of rumination, burnout, and the inability to psychologically leave work (34:15);
- Antidotes to incessant rumination, and tips for transitioning from work to home to avoid burnout (41:15);
- The psychology of complaining: The hidden cost of complaining incorrectly and benefits of learning how and when to complain (52:30);
- The consequences of social comparison, and the impact of “failure” on emotional health (1:02:15);
- How Guy helps people who struggle to acknowledge any level of success (1:07:30);
- Emotional first aid: The importance of a psychological medicine cabinet for treating emotional injuries (1:19:00);
- The role of therapists in normalizing the discussion of emotional injuries and illuminating the commonality of feelings (1:27:45);
- The widespread impact of the coronavirus pandemic on emotional health (1:35:15);
- How to properly use affirmations—a tool for treating psychological injuries (1:42:00);
- The importance of nuanced language and the stories we tell ourselves (1:47:30);
- Peter’s favorite episode of the Dear Therapist Podcast (1:53:15); and
- More.

§

## Show Notes

## The unique format and impetus for Guy’s podcast with Lori Gottlieb [3:00]

[**Dear Therapists Podcast**](https://www.guywinch.com/podcast/)

Hosted by Guy Winch (who writes an [advice column for TED](https://ideas.ted.com/tag/dear-guy/)) and fellow therapist [Lori Gottlieb](https://lorigottlieb.com/) (who writes an [advice columnist for The Atlantic](https://www.theatlantic.com/projects/dear-therapist/)

- Initial concept was just advice, however, they wanted to do something different because the thing that’s always frustrated Guy is that even if you can give the most brilliant advice, you never find out what happened
- The podcast format is such that they bring in a new letter each week, reading the letter to one another, and then do a very brief case consultation like we would in a therapy office
  - Note: the brief case consultation is done totally cold and organically live on the podcast
- They then immediately bring in the guest, and do a session
- At the end of the session, Guy and Lori each give the guest very actionable advice that they have to do within a week
- Next, Guy and Lori give some predictions about what we think will happen
- Then they hear back from the guest to find out what happened when they implemented the advice: *how they felt about it, how it went, what they took from it*
- Finally, Guy and Lori give closing thoughts as therapists to the situation

## How Guy pieced together the many different schools of thought in psychology to develop his own unique approach [7:45]

**Early years and education**

- Guy has wanted to be a therapist from an early age
- He recalls back to age 14 wanting to be a psychologist
- He was born in England but his formative years were spent in Israel
- Has an identical twin who he is very close with: “I*f you can’t get along with the person that’s most like you in the world, then you have some work to do to figure out why you don’t like yourself*.”
- He came to the US after his undergraduate degree
- He completed a master’s and PhD at NYU, and then I did a postdoc at NYU Medical Center

**During Guy’s education, how did he refine his interests?**

- The good thing about an undergraduate degree in psychology is that if you do it right, it gives you a lot of exposure to different areas of psychology
- you can be a psychologist who runs rats through mazes, or you can be a psychologist that does consulting for organizations, you can be a clinical psychologist and do therapy (what Guy does)
- It was very clear from the beginning of his education that he was thoroughly disinterested in severe psychopathology (everyone else was fascinated by schizophrenia, for example)
- “I felt I wanted to help regular people deal with regular life. That was always my interest.”
- Guy says that growing up he was always looking at the adults around him and thinking, “*I’m not sure you guys are communicating very well.*”

> “I was always interested in just working with regular people, improving their quality of life.” —Guy Winch

**The uncertainty of the science of psychology [12:00]**

- Psychology has many different schools of thought — “*There are so many great thinkers in this space, and they’re often at odds with each other*.”
- It’s the opposite of something like physics, for example, where there’s a continuity of the science, and a new discovery can upend an old one, but there’s general agreement about it (e.g., Relativity built upon Newtonian mechanics, and people could understand where the Newtonian laws broke down)
- Guy says, “Psychology is all about uncertainty. We don’t have that grasp of the human mind, we don’t have that grasp of the brain. We don’t have that grasp of emotions, we don’t even have that grasp of consciousness yet at all. And so we’re very much in the infancy of understanding how we tick, and how we operate.”
- There isn’t a unifying set of theories or principles like in physics and mathematics
- Furthermore, psychology is a much newer science

**How Guy shaped his approach with so many competing theories in psychology**

*How do you think a young student/therapist creates the scaffolding that is going to become their mental model? And more importantly, how malleable is that over time?*

- Guy thinks of it this way:
  - When you go somewhere and you’re presented with 10 different religions where everyone who presents them presents them fervently…
  - My response to that was to be an agnostic and to not believe in any of them
  - But instead to curate and say, “What in that one can I take? What aspect of this resonates with me?”
  - And that’s how Guy thought of the different theories in psychology ⇒  “These are all ideas from which I get to pick what seems right to me, but I don’t need to endorse or embrace fully any of them.”

**Did Guy’s outside the box approach rub others the wrong way?**

*Did that ever put you at odds with your colleagues, who couldn’t understand why you didn’t fit in one box?*

- Yes, says Guy
- For example, it’s common practice for therapist to not share personal information with patient
  - But the first patient Guy ever had asked Guy where he’s from
  - Guy’s supervisor said, “*If somebody asks you where you’re from, you can’t tell them, because you’re introducing extraneous material*.”
  - The idea is that you should instead just ask them “what their thoughts, and feelings, and associations are about where you might be from, and what that means to them”
  - But Guy’s take is that withholding that information simply creates a distraction and “*makes me the center of something that I don’t think I should be the center of*.”
- Guy had issues with some of the techniques that he was presented from the beginning, whereas other students were a bit more “devout”

## The most important component of successful therapy, and why it sometimes makes sense to “break the rules” [19:30]

**The most important component of successful therapy**

- In Lori’s [book](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055), she explains that the training of the therapist and the credentials of the therapist don’t matter as much as the rapport that is built between the therapist and the client
- That’s “very accurate” says Guy
- In fact, Guy’s dissertation was about what are the aspects of the therapist, their experience, their gender, their age, that might influence therapy outcome
- But since then it’s been very clear, and the research is very, very clear about it, that the most active ingredient in therapy is the [fit between the therapist and the patient](https://www.psychologytoday.com/us/blog/compassion-matters/201612/the-importance-the-relationship-in-therapy)
- For example, a patient going to therapy for the first time wants to feel that this “stranger” they’re spilling their guts to really gets them, that they’re responding and asking questions that shows that they get it
  - “*It’s a bull’s-eye or a miss. You either feel, ‘That person gets me.’ Or, ‘They don’t.*’”
- That said, the real work start after that, but it’s going to be a “slog” if you don’t have that rapport from the beginning
- In other words, **rapport between therapist and patient is “*****necessary, but not necessarily sufficient*****”** criteria for great therapy.

**Stories about “breaking the rules” in medicine and therapy**

Peter tells a story from medical school

- Peter decided to attend the funeral of a young boy who died in a car crash
- He was the one who had to tell the mother that her son did not make it, and he subsequently became close with the family and kept up with her for years
- “I really took a shit-kicking for that from one of the senior fellows when he found out I went to the funeral. He said, ‘That is an absolute mistake. You had no business going to that funeral. You must draw a line between you and the patients.’”

In [Lori’s book](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055), she talked very eloquently about going to her patient’s funeral, something that was part of her patients dying wish

Guy once attended the funeral of one of his patients…

- When it was his time to speak at the funeral he said, “*I can’t talk about him because of privacy laws, but I can talk about you*.”
- He just spoke about how meaningful his client’s time was with his family and friends
- “And *it gave me so much closure, it was so meaningful to me, I’m assuming it was meaningful to the people who were ther*e.”

Peter concludes: “*I just think it’s a privilege to be in the position you’re in, or the position that I was once in, where obviously the most delicate situations of a person’s life you can sometimes be a part of*.”

## Insights extracted from Guy’s own battle with extreme stress and anxiety around finishing his education and starting his private practice [28:15]

**Early days of private practice — Taking the “hard” cases**

- When Guy started his private practice in 1992, he was a dime a dozen in NYC
- As such, he was taking on difficult cases:
  - Children with terminal illnesses
  - “Aggressive” husbands
  - Etc.
- He gained invaluable experience with these cases
- When you have a terminally ill child as a client, you really have two clients, the child and the parents
- He was doing a lot of family therapy for that reason
- He learned that with couples therapy, you try to use a “one-way mirror” ⇒ rather than the “he said/she said” stories, you are all in there together
- Oftentimes he would take cases where the husband was deemed aggressive
  - Guy found that “No, they were not aggressive. They were upset, or angry…But they weren’t violent people.”

**Coping with extreme stress and anxiety around finishing his education in time [30:30]**

- The dissertation was traumatic, says Guy
- He was on a five-year visa (a [J-1](https://en.wikipedia.org/wiki/J-1_visa)) so the pressure was really on him to get his degree done
- After his dissertation, he was to stay for another 18 months for practical training — but if he didn’t complete it all, he would have to leave
- It impacted everything in terms of what he did, how he did it, the dissertation he chose
- His dissertation advisor was difficult to work with which added to the stress
- “*It took me three to four years after graduating before I could walk into a library without feeling a real surge in anxiety*.”

> “When everything you have and every investment you’ve ever made, emotionally and intellectually, might go down the tube if you don’t finish. And someone just is making it very difficult to finish. . .Academia is a very difficult place.” —Guy Winch

*How did Guy help himself through that stressful time?*

- He had his own therapist, which was extremely useful
- Secondly, he avoided libraries — “I *was really traumatized*.”
- Third, he was able to start his own private practice so he could focus his energy into that

**Endless rumination – the consequence of his stress/anxiety**

- In Guy’s TED Talk, [How to turn off work thoughts during your free time](https://www.ted.com/talks/guy_winch_how_to_turn_off_work_thoughts_during_your_free_time/transcript), he spoke about his struggle with endless rumination once he started his private practice and his inability to “turn it off” at home

## The epidemic of rumination, burnout, and the inability to psychologically leave work [34:15]

**Guy’s TED Talk**: [How to turn off work thoughts during your free time](https://www.ted.com/talks/guy_winch_how_to_turn_off_work_thoughts_during_your_free_time/transcript)

- Guy says his speech was really about the concept of **rumination**
- We all experience work stress, but most of that stress actually happens **outside of work**
- When you’re absorbed in your work, you’re not conscious about whether you’re stressed, you’re just doing it
- It’s when you stop—you’re driving home, sitting at dinner, trying to fall asleep at night—*that’s when all those worries and ruminations come*
- And if you’re not diligent about managing them and limiting them, **they can really take over**

**Healthy vs. unhealthy self-reflection**

- It’s interesting, we seem to have this assumption that psychologists would welcome any kind of self-reflection — “Like, reflect away. That’s a great thing.”
- However, Guy says that’s not always the case because there’s **healthy and adaptive self-reflection**, and there’s **unhealthy and maladaptive self-reflection**

*-Healthy version*:

- If you’re thinking about things in a way that’s trying to gain insight, or understanding, or meaning, or you’re trying to problem solve something, you’re trying to tackle it.
- That’s adaptive

*-Unhealthy version*:

- If you’re just replaying the same upsetting memory or idea over and over again, if you’re just walking around your house in the evening, muttering, “I have so much to do tomorrow.
- It’s not useful. You’re stressing yourself out.
- When you do that, actually you activate your stress response which has the consequences of things like:
  - Lack of sleep;
  - Unhealthy eating habits;
  - Irritability;
  - You’re checked-out with your family; and
  - Much more.

![](https://peterattiamd.com/wp-content/uploads/2021/01/self-reflection-guywinch-764x1024.png)

**Figure 1. Adaptive vs. maladaptive self reflection.** [[source](https://www.youtube.com/watch?v=vBqoA1V6Fgg)]

“Stress from work happens outside of work. So you need to control it, because you’ll like your job much better if you’re not burnt out.” —Guy Winch

**The source of Guy’s rumination**

- Once he started his private practice, he felt a sudden, and enormous, responsibility
- Half his practice has always been couples and families — “Those are very active lives, sometimes intense situations.”
- Individuals, on the other hand, don’t often “go nuts” in a session
- “But a couple, you take your eye off the ball for one second, can go very wrong, very quickly.”
- You have kids who were dying
- Husbands that spouses are they’re afraid of
- You’re responsible for helping and for having an impact, and that is a huge responsibility
- A conscientious person is naturally going to be asking themselves whether they’re doing their best
- They may even question their expertise
- “*You try and do the best you can. But if you’re conscientious, it’s stressful.*”

**The good and bad of feeling stress**

- A certain amount of stress is actually very adaptive:
  - Without it, you become so complacent
  - But it’s really an “inverted U”
  - For Guy, in his early years of practice, he went a little too far on the rumination

**When Guy realized he was burnt out and needed to make a change**

In his [TED Talk](https://www.ted.com/talks/guy_winch_how_to_turn_off_work_thoughts_during_your_free_time/transcript), Guy tells the following story of when it “hit him”:

- He found himself stuck in a broken down elevator with another person who lived in his building
- The other man began to panic, smashing all the buttons and saying, “This is my nightmare. This is my nightmare.”
- Instead of being compassionate—which he would have been in any other circumstance—Guy said out loud, “And this is my nightmare.”
- Guy says it was horribly obnoxious and really unkind to say
- “The minute those words left my mouth, I literally said, ‘What is going on with me? That’s not me at all.’”
- That is the moment Guy realized that **he was burnt out**

*But how is that possible?? He’s only been in practice for a year!*

- He started asking himself things like, ‘How many hours am I working?’

“And that’s when I started realizing it’s not the hours that I put in my office. It’s the hours that I’m working in my head afterwards. Those don’t stop.” —Guy Winch

**The epidemic of rumination**

- Guy’s personal story is not that unique in today’s society
- We live in such a connected world that it’s harder and harder to detach from work
- And burnout can not just result from how much time you are at work…
- …but **how much time you’re thinking about work** ⇒ “*And that’s the part you can control.*”

*The impact of the coronavirus pandemic*

- The pandemic has been terrible for people in that way
- It’s difficult enough to make a separation when you don’t have that physical space of the office, now you have to “leave the office” **psychologically**
- And unless you create from guard rails for yourself, unless you have the discipline to really determine, “I finish at this hour”, then you’re going to struggle with it

## Antidotes to incessant rumination, and tips for transitioning from work to home to avoid burnout [41:15]

**Peter proposes a hypothetical case study**:

- A very successful man or woman professionally
- Yet, when they’re home, they can’t interact with their kids because they’re constantly lost in thought
- They struggle to sleep
- They tend to numb that behavior with maybe a little more alcohol than they should

*What suggestions would Guy have for that person?*

1 – Do something mentally engaging that requires concentration

- This person has to realize that this is NOT going to happen *naturally*
- You can’t direct yourself to not think about something
- However, you can **redirect** your thoughts to think about something else
- That said, it must be something active and engaging
- If, for example, you’re trying to drown out work thoughts by watching TV, it won’t be long before your mind drifts back to work thoughts
- The same with goes with reading, unfortunately
- It must be something active where you’re actually **engaging your head** and doing something that **requires concentration**

2 – Pose it as a problem to be solved

- It feels very satisfying to ruminate, because it *feels* like you’re doing something important
- The reality is that you’re not really trying to figure anything out ⇒ you are most likely just obsessing and replaying it like you’re in an emotional hamster wheel just spinning your wheels
- Whatever that thing is that’s in your mind, **pose it as a problem to be solved**
- *For example*: Let’s say you have the really common rumination of, “I have so much work to do, or when am I going to do this?”
  - Well then that’s a scheduling problem
  - Ask yourself, “When in my schedule am I going to have time to deal with this? What can I move to make that time?”
  - If you put it in your schedule, and move things around to do so, **the stress you’ll feel about it will ease and the urge to ruminate will ease with it**

3 – Setting up guardrails and create rituals of transition

- This is the most important, says Guy
- You have to define when you switch off every night — when you stop working
- I.e., *At what point in time can your family rely on you to show up and not be at work mentally*?
- You must decide when to “turn it off”
- You have to create **rituals of transition** to make you feel like you’re no longer at work:
  - change out of your work clothes
  - put on some music
  - change the lighting
  - If you have kids: get on the floor and play with them
  - If you have a spouse: you have to get into romantic mode
- The main point: You can’t just sit there, *passively*
- You must engage with them (or with an activity if you’re alone)
- Things that can help get out of work mode: you plan the evening, organize the game, organize the outing, curate the dinner

> “You really have to purposefully mark out territory to have a life. And if you don’t, you won’t.” —Guy Winch

**What about pharmacotherapy options?**

*What is Guy’s take on using medication to help ease some of this stress/rumination in tandem with the behavioral actions*:

- My first instinct would not be to refer someone to a psychiatrist when they’re ruminating in this way
- Why? Simply because there are so many things they need to try
- It will be more effective to change the habit that sets you up to ruminate rather than just medicate the rumination away
- It’s more durable, but it is more difficult
- To have the durability of the response, comes at a price, which is you have to work harder upfront

**What Peter has found helpful, personally**:

- The ritual of playing with young kids
- But you have to be **on the floor**
- You have to be doing exactly what they’re doing
- You have to be all in, you can’t be half doing it
- Peter comments: “*That is a real antidote to sort of rumination and that negative loop…not easy to do initially. It turns out to be a bit of a shock to your system. . .we lose this ability to play pretty quickly. It fades from us*.”

**Another tip from Guy**: *Feed your various identities*

- There are many aspects of everyone’s identity
- You’re not just a professional, you’re an individual
  - an amateur tennis player perhaps
  - an amateur cook
  - etc.
- You can access any one of those aspects of your identity and bring it forth in that moment.

⇒ Examples:

- You sign up for a race and go train
  - And then the question is, can you improve your time?
  - Can you put in the miles you need to put in?
- If you’re an artist,

- Go into the studio, because that’s where you’ll create best
- Or create a studio-like atmosphere in your home

-These various aspects of our identity **make us feel like us** and they **make us feel important**

> “There are many aspects of our identity that we can access that actually get short shrift when we’re too preoccupied with work. And we will suffer for not accessing these parts of ourselves.” —Guy Winch

**How long did it take Guy to personally make this transformation away from rumination?**

- A year of two into his private practice, he realized that he had been full steam ahead since my undergraduate days — Undergraduate, graduate degree, post-doc, then practice.
- “*I hadn’t stopped to consider how I feel about what I’m doing*.”
- He came to the conclusion that he simply could not do psychology 50- 60 hours a week
- He needed balance
- He went through a two year exploration of what that would be, taking him to some “unusual stations”
  - He talked with NASA about being an astronaut, for example
- Ultimately, he ended up realizing that he wanted to write
- From there, he decided to limit the hours of the week in which he sees patients to create space for writing
- He wrote for 14 years and didn’t publish a word
- His writing had nothing to do with psychology — he wrote screenplays, for example
- An agent finally said to him that he should write about psychology
- But Guy was resistant to that idea as the whole idea of writing was to escape from psychology
- That, however, ultimately changed

## The psychology of complaining: The hidden cost of complaining incorrectly and benefits of learning how and when to complain [52:30]

**Quick story about how guy decided to write about the psychology of complaining**:

- Guy went to Best Buy to purchase headphones and couldn’t find anyone to help him
- He got annoyed and left the store
- On the way out, he saw a sign showing the store manager that said, “How was our customer service? Email me and let me know.”
- He sent over an email and got a quick response
- That email made him think about how the “*squeaky wheel gets the grease*”
- That was the spark of an idea: **What’s the psychology behind that?**
- He noticed there weren’t any books about the psychology of complaining
- A writing agent convinced Guy to write up a proposal for a book and the idea sold at auction

⇒ Check out [Guy’s talk at Google](https://www.youtube.com/watch?v=KxdDvJ2J-VI) (first 30 minutes are most relevant):

**The psychology of complaining**

Insights from doing research for his book, [The Squeaky Wheel](https://www.guywinch.com/books/the-squeaky-wheel/):

- There’s a hidden cost of complaining incorrectly
- Complaining is a form of expressing empowerment, to the extent that we’re trying to get a result
- The research by psychologist [John A. Goodman](https://twitter.com/jgoodman888?lang=en), as mentioned in [Guy’s book](https://www.guywinch.com/books/the-squeaky-wheel/), showed that 95% of people who have a customer service complaint with the product **don’t actually voice it**
- *Why? ⇒* Because they fear that it will be too difficult, too time-consuming, and too aggravating to do that

![](https://peterattiamd.com/wp-content/uploads/2021/01/why-consumers-dont-complain-guy-winch-1024x515.png)

**Figure 2.** [[source](https://www.youtube.com/watch?v=KxdDvJ2J-VI)]

- Instead, they will tell 12-16 people on average about that incident — ultimately spending way more time, getting aggravated each time, all over again, and **getting zero results**
- “***Our complaining psychology is really broken***.” says Guy
- The problem is that when you tell 16 people about how you were wronged, and you don’t do anything about it, you’re going to feel like a victim and you’re going to feel powerless (Because that’s the story you’re telling)
- This is a big problem when you think about how many complaints we have on a *daily basis*
- When you work with people in individual psychotherapy, and they often bring up issues and complain about someone
- The therapist will ask the most obvious question, “Did you discuss that with them?”
- The common response is alarming: *They often say “no” and they look at the therapist like, “Why would I discuss it with them? That’s just going to cause an argument.”*

> “*People absolutely are convinced that to voice something that’s really important for them, meaningful for them, is an impossibility*.” —Guy Winch

- “*Now, in some way they are correct*” says Guy
- They’re right b/c the vast majority of people express complaints so poorly that it actually does get the wrong result

![](https://peterattiamd.com/wp-content/uploads/2021/01/complaining-paradox-guywinch-1020x1024.png)

**Figure 3.** [[source](https://www.youtube.com/watch?v=KxdDvJ2J-VI)]

Peter asks: *Has the way we complained changed over time?*

- Take an extreme example: Looking at hunter-gatherers, it’s unlikely they complained in the way we do now b/c it would likely upset the tribe — and potentially end up in being ostracized

*How did we get to the point where we’re at today, where 19 out of 20 people won’t voice the complaint to the entity that can address it?*

- Guy goes back ~150 years to the origin of the term “the squeaky wheel.”
- It came from a [poem](https://idioms.thefreedictionary.com/squeaky+wheel+gets+the+grease#:~:text=The%20current%20version%20of%20this,the%20grease.%22%20However%2C%20the) by a guy called [Josh Billings](https://en.wikipedia.org/wiki/Josh_Billings), who was a humorist in the days of [Mark Twain](https://en.wikipedia.org/wiki/Mark_Twain)
- “I hate to be a kicker [complainer], I always long for peace, But the wheel that does the squeaking Is the one that gets the grease”
- The word “kicker” was a very insulting word associated with the people who complained too much
- As a society at that time, 150 years ago, complaining was frowned upon.
- And because it was used mostly transactionally:
  - i.e., If the blacksmith didn’t put the horseshoe on correctly, you’ll go and say, “My horse is limping,”
  - But if your horse was only limping slightly, you might not, because you didn’t want to be a kicker.

*Fast forward to today*:

- You’re going to become a reality TV star if you complain enough, or if you voice something on social media.
- In other words, the idea today that’s really been developed because culturally, the complainer (the squeaky wheel) may or may not “get the grease” but they WILL get the **attention**
- And sometimes the attention is better for them than the grease
- The grease is supposed to quiet the wheel, but many complainers aren’t looking to be quieted — They are looking to actually get a megaphone and be louder

**The gap between expectations and reality**

Expectations have grown over the industrialization of society —

- Back when we were sharing four people to a bed and going to the outhouse to go to the bathroom in the snow — we would rarely never complain about discomfort
- But today, because our expectations are so high—and **complaining gets triggered when there’s a big gap between expectation and reality**

## The consequences of social comparison, and the impact of “failure” on emotional health [1:02:15]

**The gap between expectation and reality**

*How much general discontent and human psychological suffering comes down to that single delta?*

- A lot, says Guy, and it’s exacerbated by social media

**Social media’s impact**

- - Because it’s so highly curated into our “Best moments”, it has set very poor expectations or very wrong expectations for
    - a) what we should expect out of life, and
    - b) how much work we should be expected to put in to get that

- *Outsized impact on the youth*

- - For Guy, what stands out about the internet, social media apps, etc. are the **convenience** of them
  - That convenience of being able to keep in touch with so many people at a distance, and see what’s going on with them and enjoy the pictures, etc. is very, very convenient
  - But for a young person who grew up with this, it’s not about convenience…
    - it’s about **image curation**
    - It’s about **comparison** (likes, followers, etc.)
  - So it’s looked upon very differently to the younger generation — “*It’s looked upon as a way to measure your worth, rather than as a way to get something done*.”

**The impact of social comparison and “failure” on our emotional health**

Peter points out that, if you’re willing to compare yourself to a *broad enough array*, you’re will be a failure by comparison

*What is the antidote to that misery that comes from comparison?*

- First of all, it’s a true misery
- For example, Guy works with people are quite successful
- They don’t necessarily think of themselves as failures, but they just don’t think of themselves as successful
- Celebrating success doesn’t mean you’re “done” says Guy
- Many people plan to only celebrate when they reach the “top of a heap” … but there is no such thing as the “top”… therefore that is a bad life plan, because you will never be satisfied, will always feel envious, and will always feel insufficient

> “*If you keep looking up, you will never, ever be satisfied. You will never, ever be happy*.” —Guy Winch

## How Guy helps people who struggle to acknowledge any level of success [1:07:30]

- No, says Guy, the empathy for these people came natural
- “*My primary job is to see the world through that person’s eyes to really understand their experience. My job is not to react to that as I would if I’m hearing it from a stranger. My job is to really try and understand why*.”
- Often something happened in their childhood (not something from their adult lives) which set them on a path of just keep barreling forward and not dare to take their eye off the goal or their foot off the pedal

**How empathy helps in therapy**

- Once you really understand someone, once you really see the world through their eyes, two things happen.
- Number one, you have compassion for them.
- And number two for me, you like them — “when you really get someone, there’s a fondness that gets triggered”
- Customer service as a therapist is very important:
- “I’m genuinely happy to see you. You’re going to see that in my face, and I think there’s something very powerful about that for people.”
- Being genuinely compassionate is a **natural outcome of using empathy**

**Inability to acknowledge being successful**

It’s not uncommon for Guy and Peter to come across people with an inability to simply acknowledge something done as being successful

- It’s like there is a fear that if they stop to acknowledge “success”, they will lose it
- Peter feels like this personally: “W*henever I finally achieved my goal, the happiness lasts for maybe 13 milliseconds*.”

*How does Guy help people overcome this?*

1—**A visualization exercise**

- the key about visualization exercises is the detail — the more detail in the visualization, the more you’ll connect to it emotionally
- You must spend time really painting the picture
- He starts by having the person think back to when this was just a dream: *Where were you? What was the weather like? What were you wearing? Who were you with? How were you feeling back then?*
- Next, he has the person insert into their visualization having their present selves deliver the news to their past selves about the success: *How do you reveal it? What does that younger version of yourself think? How amazing would they feel? How excited would they feel?*
- The goal is to give them the perspective of the person who hasn’t achieved yet (them at a younger age) and looking at the achievement from that vantage point
- Peter’s comments:
  - He says that sounds a lot like the promising technique called EMDR for addressing trauma from your childhood
  - Also, he sees how this can be very helpful because, “f*rom any one day to the next, it’s very difficult to appreciate a change. But over a decade, I mean, it could be a step function*.”

2—**Allowing your success to be celebrated**

- A lot of the times, these people who don’t want to celebrate have people around them who do
- Guy will say, “If you don’t want to go and have a celebration for you, do it for them, they want to celebrate you. Indulge them.”
- What happens is that they get caught up in it and they can connect to it at some point
- “*Just start celebrating, you’ll connect at some point to what it is you’re celebrating*.”

## Emotional first aid: The importance of a psychological medicine cabinet for treating emotional injuries [1:19:00]

- The reception to Guy’s first book, [The Squeaky Wheel](https://www.guywinch.com/books/the-squeaky-wheel/), was better internationally than it was in the US
- However, it gave him a chance to write a second one, [Emotional First Aid](https://www.guywinch.com/books/emotional-first-aid/)

**What was the motivation to write Emotional First Aid?**

- He wanted the next book to be just full-on psychology, emotional health, and wanted it to really reflect the work he was doing with patients
- For years, he had been regularly reading research articles and trying to find ways to apply findings in my practice
- Over time, he had curated a lot of different little tricks and tips and techniques for people to manage common emotional wounds like failure, rejection, guilt, self-esteem, low self-esteem and such
- Guy felt like there was a need for a “***psychological medicine cabinet***” in the same way be have one for our physical ailments

**3 types of injuries**

- Peter lays out a contrast of how we handle “injuries” to better understand why it is we struggle so much with “emotional injury”
- Case 1 – Broken femur: We know for sure when this happens, bone sticking out, etc.
- Case 2 – Type 2 diabetes: Can’t see anything from the outside, but we have a blood test that can tell us you have it
- Case 3 – Rejection: Nobody sees it, and we’re far less likely to even acknowledge it
  - There is a stark contrast between those three cases
  - The idea that being rejected or failing at something warrants “treatment” is going to sound a bit silly and you’re going to have to do some convincing to get someone to consider that concept

![](https://peterattiamd.com/wp-content/uploads/2021/01/physical-vs-psychological-guywinch-1024x546.png)

**Figure 4. Physical vs. psychological injuries.** [[source](https://www.youtube.com/watch?v=vBqoA1V6Fgg)]

Guy tells a true story from a couples therapy session:

- A senior executive in a financial institution and his wife in a session with Guy
- They’re talking about emotions and the importance of emotions and he immediately shuts Guy down and says, “I don’t believe in feelings.”
- Guy said, “You don’t believe in feelings?”
- He said, “I know people have them, but it’s not as if they’re real. They shouldn’t matter.”
- his wife sitting next to him, dabbing her eyes with a tissue because she was having feelings.
- Guy turned to the wife and I said, “Did you know your husband doesn’t believe in feelings?”
- And she stopped crying and said, “No, but it explains a lot.”
- At that point Guy and the wife were laughing out loud but the husband was not and looked very irritated
- The husband was just about to stand up and leave and Guy said, “You look angry.”
- He goes, “I am angry.”
- Guy says, “Well, there’s one feeling you believe in. Now, let’s talk about some of the others and how they might be impacting your marriage.”
- The husband sat back down because Guy made his point which was: **You can’t just curate. If you believe in anger, there are other feelings you have to believe in as well.**

**Why do many people think that feelings are not worthy of attention?**

Going back in time…

- when we were earlier on in our development, societally/industrially, when it really was about just keep alive, roof, shelter (the [Hierarchy of Needs](https://en.wikipedia.org/wiki/Maslow%27s_hierarchy_of_needs)), your emotional wellbeing was very much at the bottom of that hierarchy
- Actualization was at the bottom of that hierarchy
- we had to reach a certain level of industrialization and comfort and safety and self-sufficiency as a society, as individuals to be able to start looking at higher order needs
- And that’s when we started paying attention more to emotions — so it’s a **very recent development, relatively speaking**

Fast forward to today…

- We are at a point where we need to think about our emotional wellbeing
- Emotional wellbeing has a huge impact on our **physical wellbeing**, our longevity and our overall health
- So even if that’s the priority—just staying alive—we know there are many emotional/psychological conditions that can actually contribute to you dying much more quickly than you might otherwise

**Peter’s take**: “*If the emotional piece is not working… at best, you will continue to do okay physically and just be miserable, which strikes me as the definition of torture. At worst, you’ll have all of that plus an impaired physical existence. So either way, if you’re emotionally broken, I think you’re in for a very difficult life*.”

![](https://peterattiamd.com/wp-content/uploads/2021/01/benefits-guywinch-1024x760.png)

**Figure 5. Benefits of emotional first aid.** [[source](https://www.youtube.com/watch?v=vBqoA1V6Fgg)]

## The role of therapists in normalizing the discussion of emotional injuries and illuminating the commonality of feelings [1:27:45]

> “I think any mental health professional these days has to think of themselves as an ambassador, because there is such ignorance that we have about our emotional and our psychological states and how we operate and what matters.” —Guy Winch

**The need to educate**

- Guy says it starts with education
- The main reason he started the Dear Therapist Podcast with Lori was because within those episodes there are a lot of insights that are very transferable
- Guy’s approach to therapy:
  - “If I have a one-off hour with you, I’m going to come in guns blazing right in the beginning, because we’re going to get something done. And so, it’s going to be a little head-spinning for the person, because I’m not holding back.”
  - He’s experienced enough that I can fill in a lot of gaps without hearing a lot of information
  - Therapy clients are often surprised and fascinated with Guys ability to articulate what they are feeling better than they can themselves
  - And that fact is the source of Guy’s frustration — “*It’s something we should all be able to do if we were better educated in how psychology and feelings work*.”
- We know, for example, that rejection hurts even if the person who rejected you is someone you absolutely despise
- And if you don’t know that we are wired to respond that way, you’re likely to feel bad about yourself

**You are not alone**

- We need to understand that if something happens to us which triggers a feeling inside — anyone else that had the same them happen to them would feel similarly
- The difference is that the other person might not show it, they might not confess it, and they might not feel it to that extent but feel it they will feel it
- Our emotional DNA is global, it’s universal
- Our responses might differ but our experience is the same

> “There’s so much we can teach, there’s so much we can inform, and there’s so much that [we could do that] would feel unifying as humans, would make us feel more connected to one another, because we’re all so the same under the skin.” —Guy Winch

**The commonality of feelings — “you are not alone”**

- Peter tells the story about his own personal therapy session with his therapist, Esther Perel (someone Guy has shared an office with for 27 years)
- Peter was sharing his pattern of thought to Esther as if “I was the only person in civilization that has probably ever had this”
- But Esther basically finishes Peter’s thought for him and informs him that his feelings/thought pattern is NOT unique — “*Peter, I hate to tell you this, and I’m not saying this to minimize you as a person, but this isn’t a very uncommon thing. Your mind when it’s poisoned is staggeringly unoriginal. Lots of people have the exact same poisonous sets of thoughts that you do*.”
- In other words, there are, unfortunately, a very common set of beliefs that are maladaptive that people like Peter, says Guy
- Peter admits that he took comfort in this fact
- Guy says the upsetting thing here is that the only reason Peter didn’t realize that his feelings weren’t unique is because people don’t often express their feelings
- And that is, again, why Guy believes that it’s the duty of therapists to be ambassadors, to get the word out
- We should have more accessible platforms for understanding this stuff
- It should be taught in high schools rather than “*whatever esoteric information people will soon forget when they graduate*”

## The widespread impact of the coronavirus pandemic on emotional health [1:35:15]

*Is the tide shifting towards more people recognizing and trying to address emotional injuries?*

- Guy believes the answer is yes
- And the coronavirus pandemic has moved the dial “*more than anything else, by far*”

**Impact of the pandemic**:

There are very few people untouched by stress, anxiety, grief, loss, loneliness, tension, relationship rupture, fear, depression, etc.

Guy’s op-ed for the Boston Globe: [Loneliness, anxiety, grief — dealing with the mental health impacts of the coronavirus](https://www.bostonglobe.com/2020/04/21/opinion/loneliness-anxiety-grief-dealing-with-mental-health-impacts-coronavirus/?p1=Article_Inline_Text_Link) (April, 2020)

- In the article, he expressed the following sentiment:
- This pandemic is going to leave a legacy of mental health crisis that is going to be years to address and we should start thinking about it right now because we cannot, as therapists, address the needs of people when there are not enough of us.
- Therapy is not a practical solution for everyone. We need to start working on online mass interventions that can be deployed psychologically and emotionally because we’re going to have masses of people with trauma.

People are more receptive to the idea of dealing with emotional injuries

- While most people are unscathed physically, everyone is a little bit damaged now [emotionally]
- People are actually paying attention to it now, they’re more receptive to it now, they’re more interested in it now and I think they will listen more now.

***How to scale the work of the great therapists?***

- The answer is not make more therapists, says Guy, it’s just not practical
- We need more self-guided online interventions for things like loneliness or anxiety: The field of psychology needs to invest more resources into finding useful interventions that truly can be put online where anyone can do in the privacy of their home in their own time
- Will it be as effective as one-on-one therapy? No
- Will it be effective and actually helpful to a lot of people? Yes
- Not everyone needs the therapy

Currently, the options are basically:

- Go to therapy
- Read an article
- Read a book.
- “There’s a lot in the middle that we can do that can be deployed and scaled really on a mass level.”

These “middle ground” options are great resources to at least triage and do some “first aid”

- Guy says many readers of [Emotional First Aid](https://www.amazon.com/Emotional-First-Aid-Rejection-Everyday/dp/0142181072) have told Guy that they frequently re-reference his book as needed like their “medicine cabinet”
- If tools can be put into a book, they can be provided much better with interactive online tools, with apps, etc. and really helpful for people on a mass scale

## How to properly use affirmations—a tool for treating psychological injuries [1:42:00]

**Peter’s experience with the tool known as “affirmations”**

- During very intensive therapy, Peter was challenged to come up with 47 affirmations (one for each year he’s been alive)
- At first, he couldn’t come up with even two
- He eventually had an enormous breakthrough and in one sitting wrote them all out
- Peter notes the biggest challenge and most important part of affirmations is that you **truly believe them**

**Guy explaining affirmations**

- Positive affirmations are defined as those typical sayings that you get on refrigerator magnets and the bottom of calendars.
  - “I am going to be a great success.”
  - “I am beautiful and worthy of great love.”
- However, these generic sayings really only work for those who already have high self-esteem and actually [*harms* those with low self-esteem](https://journals.sagepub.com/doi/abs/10.1111/j.1467-9280.2009.02370.x) (the very people these affirmations target)

*Why are they harmed by them?*

- Because looking at the mirror and telling yourself that you’re going to be a great success when you feel like a massive failure, for example, is not going to register as believable
- Instead, it’s going to register as unbelievable and remind you that, in fact, you feel like a failure
- These “work” for people with high self-esteem because it doesn’t contradict their internal beliefs

**How to make affirmations useful**

- First, you individualize them so that they sound **believable** to you; For example:
  - Do NOT say “I’m going to be a great success”.
  - Instead say, “I am going to persevere until I succeed”
  - Do NOT say, “I’m beautiful and I’m worthy of great love.”
  - Instead say, “I have amazing eyes and an amazing personality and I’m going to keep putting myself out there until I find the person who appreciates them.”
- **The Upshot**: Individualize the affirmation so that it sounds **believable** to you, and yet is **hopeful** and **optimistic** and **sets a goal**.

⇒ See Guy’s TED Ideas article: [5 ways to build lasting self-esteem](https://ideas.ted.com/5-ways-to-build-lasting-self-esteem/)

More tips:

- You can always tweak the affirmation so that it has the same sentiment, but it matches the reality that you’re living in that moment
- For example, if your affirmation is “I am a good father.” but you just lost your temper on your kids… you might change it to “I am trying to be a good father and I am learning from my mistakes.”

⇒ See Guy’s [talk](https://youtu.be/vBqoA1V6Fgg?t=1835) for more on the use of affirmations

## The importance of nuanced language and the stories we tell ourselves [1:47:30]

**The importance of language in therapy**

- Language is very important for Guy when it comes to therapy …
- If Guy isn’t able to express feelings in language that truly captures it, he actually has no way of knowing if that’s how someone actually feels
- For most people, our emotional language is very limited and to lack nuance: e.g., angry, sad, upset
- But there’s tons of nuance in language with dozens of words for certain levels or kinds of upset
- Guy chooses his words very carefully because he wants to make the point that “you’re not just angry, you’re also quite frustrated and you’re also quite resentful”

> “It’s very complex, our emotional experience, except we tend to think of it in just one thing—which it’s not.” —Guy Winch

**Narrative psychology**

- Guy uses narrative psychology to a degree in anything that he does (which helps him as a writer and vice versa)
- Guy says his duty in a first session after the client tells their story is for Guy to tell it back to them but for it to be a different story with a different perspective
- In Guy’s version, why they feel the way they do or why they’re stuck in the way they are “will become abundantly clear” and what they will need to do about it—in basic rough terms—will also become clear

*Simple example*:

- If you’re a survivor of a horrible plane crash and you lost a limb in that plane crash what is the story you have about that?
- Are you a horribly unfortunate person who became disabled in a plane crash?
- Or are you the luckiest person alive because you’re the only one who walked away?
- Those different perspectives are going to make you recover in a very different way, feel very differently about yourself, and feel very differently about the life you go forward to live
- It’ll be much more adaptive to think of yourself as a very fortunate survivor rather than have the self-pity of to think you’ve been horribly, horribly victimized

> “We have a choice in the stories we tell ourselves. We don’t have choice about the facts, we have choice about our organization, our perspective, and the narrative we create around them.” —Guy Winch

## Peter’s favorite episode of the Dear Therapist Podcast [1:53:15]

Peter urges people to go and listen to the [Dear Therapist Podcast](https://lorigottlieb.com/podcast/) hosted by Guy and Lori Gottlieb

Peter’s favorite episode is called, [Molly’s Father’s Suicide](https://podcasts.apple.com/us/podcast/mollys-fathers-suicide/id1523340696?i=1000499395423)

§

## Selected Links / Related Material

**Books authored by Guy Winch**:

- [The Squeaky Wheel: Complaining the Right Way to Get Results, Improve Your Relationships, and Enhance Self-Esteem](https://www.guywinch.com/books/the-squeaky-wheel/) [1:00, 54:30, 1:16:45]
- [How to Fix a Broken Heart](https://www.guywinch.com/books/how-to-fix-a-broken-heart/) [1:00]
- [Emotional First Aid: Healing Rejection, Guilt, Failure, and Other Everyday Hurts](https://www.guywinch.com/books/emotional-first-aid/) [1:00, 1:19:15, 1:41:00]

**Podcast co hosted by Guy and Lori Gottlieb**: [Dear Therapists Podcast](https://www.guywinch.com/podcast/) | (guywinch.com) [1:30, 3:00, 1:27:45, 1:53:15]

**Episode of The Drive with Lori Gottlieb**: [#122 – Lori Gottlieb: Understanding pain, therapeutic breakthroughs, and keys to enduring emotional health](https://peterattiamd.com/lorigottlieb/) | Peter Attia (peterattiamd.com) [1:30]

**Guy’s three TED Talks**: [1:30]

- 2014: [Why we all need to practice emotional first aid](https://www.ted.com/talks/guy_winch_why_we_all_need_to_practice_emotional_first_aid) | (ted.com)
- 2017: [How to fix a broken heart](https://www.ted.com/talks/guy_winch_how_to_fix_a_broken_heart/transcript) | (ted.com)
- 2019: [How to turn off work thoughts during your free time](https://www.ted.com/talks/guy_winch_how_to_turn_off_work_thoughts_during_your_free_time/transcript) | (ted.com) [34:30]

**Guy’s several talks at Google**: [1:30]

- *Google talk about complaining (first 30 minutes most relevant)*: [The Squeaky Wheel | Guy Winch](https://www.youtube.com/watch?v=KxdDvJ2J-VI) | Talks at Google (youtube.com) [54:30]
- *Talk which mentions affirmations 30 minutes in*: [Emotional First Aid | Guy Winch](https://www.youtube.com/watch?v=vBqoA1V6Fgg) | Talks at Google (youtube.com) [1:46:15]

**Lori’s weekly column for The Atlantic**: [Dear Therapist](https://www.theatlantic.com/projects/dear-therapist/) | (theatlantic.com) 4:00

**Guy’s advice column for TED**: [Dear Guy](https://ideas.ted.com/tag/dear-guy/) | (ideas.ted.com) [4:00]

**Lori Gottlieb’s bestselling book**: [Maybe You Should Talk to Someone: A Therapist, HER Therapist, and Our Lives Revealed](https://www.amazon.com/Maybe-You-Should-Talk-Someone/dp/1328662055) by Lori Gottlieb | (amazon.com) [19:30, 24:00]

**Studies suggest most important factor in the success of someone’s therapy is the relationship that you have with your therapist**: [The Importance of the Relationship in Therapy](https://www.psychologytoday.com/us/blog/compassion-matters/201612/the-importance-the-relationship-in-therapy) | Lisa Firestone Ph.D. (psychologytoday.com) [20:15]

**Researcher who found that about 95% of people with a customer service complaint don’t actually voice that complaint to the company**: [John A. Goodman](https://twitter.com/jgoodman888?lang=en) [55:15]

**The saying “the squeaky wheel gets the grease” originated in a poem by Josh Billings, a humorist in the days of Mark Twain**: [squeaky wheel gets the grease](https://idioms.thefreedictionary.com/squeaky+wheel+gets+the+grease#:~:text=The%20current%20version%20of%20this,the%20grease.%22%20However%2C%20the) | (idioms.thefreedictionary.com) [1:00:00]

**Guy’s op-ed for the Boston Globe**: [Loneliness, anxiety, grief — dealing with the mental health impacts of the coronavirus](https://www.bostonglobe.com/2020/04/21/opinion/loneliness-anxiety-grief-dealing-with-mental-health-impacts-coronavirus/?p1=Article_Inline_Text_Link) | Guy Winch (bostonglobe.com) [1:36:45]

**Research showing affirmations only help people with high self-esteem**: [Positive Self-Statements: Power for Some, Peril for Others](https://journals.sagepub.com/doi/abs/10.1111/j.1467-9280.2009.02370.x) (Wood et al., 2009) [1:43:30]

**Peter’s favorite episode of the Dear Therapists Podcast**: [Molly’s Father’s Suicide](https://podcasts.apple.com/us/podcast/mollys-fathers-suicide/id1523340696?i=1000499395423) | Dear Therapists (podcasts.apple.com/) [1:53:15]

§

## People Mentioned

- [Lori Gottlieb](https://lorigottlieb.com/about/) [1:30, 3:00, 19:30, 1:27:45, 1:48:15]
- [Bruce Lee](https://en.wikipedia.org/wiki/Bruce_Lee) [17:15]
- [John A. Goodman](https://twitter.com/jgoodman888?lang=en) [55:15]
- [Josh Billings](https://en.wikipedia.org/wiki/Josh_Billings) [1:00:00]
- [Mark Twain](https://en.wikipedia.org/wiki/Mark_Twain) [1:00:00]
- [Esther Perel](https://www.estherperel.com/my-story) [1:31:30, 1:47:45]
- [Jim Kochalka](https://www.oncourseinternational.com/jim-kochalka/) [1:52:15]

§

![](https://peterattiamd.com/wp-content/uploads/2021/01/bio-image-guywinch-450x500.png)

##### Guy Winch, Ph.D.

Guy Winch is a licensed psychologist who works with individuals, couples and families. As an advocate for psychological health, he has spent the last two decades adapting the findings of scientific studies into tools his patients, readers and audience members can use to enhance and maintain their mental health. As an identical twin with a keen eye for any signs of favoritism, he believes we need to practice emotional hygiene with the same diligence with which we practice personal and dental hygiene.

His books — [*Emotional First Aid: Healing Rejection, Guilt, Failure, and Other Everyday Hurts*](https://geni.us/FBGb); [*The Squeaky Wheel: Complaining the Right Way to Get Results, Improve Your Relationships and Enhance Self-Esteem*](https://target.georiot.com/Proxy.ashx?TSID=12033&GR_URL=https%3A%2F%2Fwww.amazon.com/Squeaky-Wheel-Complaining-Relationships-Self-Esteem/dp/1976342139); and [*How to Fix a Broken Heart*](https://geni.us/NF9za4) have been translated into 26 languages. He also writes the popular “[Squeaky Wheel Blog](https://www.psychologytoday.com/blog/the-squeaky-wheel)” on PsychologyToday.com.

In January, Winch partnered with TED to launch [*Dear Guy*](https://ideas.ted.com/tag/dear-guy/), a science-based advice column for TED’s Ideas blog. His new podcast, [*Dear Therapists*](https://www.guywinch.com/podcast/), is cohosted with fellow TED speaker Lori Gottlieb and executive produced by Katie Couric. He has also dabbled in stand-up comedy. [[ted.com](https://www.ted.com/speakers/guy_winch)]