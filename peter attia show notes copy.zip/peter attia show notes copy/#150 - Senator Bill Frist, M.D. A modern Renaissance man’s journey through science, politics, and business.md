# #150 – Senator Bill Frist, M.D.: A modern Renaissance man’s journey through science, politics, and business

**Source:** [https://peterattiamd.com/billfrist/](https://peterattiamd.com/billfrist/)

---

Bill Frist is a nationally acclaimed heart and lung transplant surgeon, former U.S. Senate Majority Leader, and is actively engaged in health policy and education reform. In this episode, Bill takes us through his long and varied career in medicine, politics, and business, which includes establishing the organ transplantation program at Vanderbilt as well as rising from the lowest-ranked member of the U.S. Senate to the Majority Leader in two terms. We discuss some of the most significant moments of his time in the Senate, such as advocating for AIDS prevention programs’ funding and addressing complicated issues like stem cell research and the end-of-life issues raised by the Terri Schiavo case. We also hear his first-person account of what happened behind the scenes on September 11, 2001, his frustration with our lack of preparation for the pandemic, and his thoughts about the current state of U.S. politics. Finally, we talk about his current endeavors in health policy and education reform.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/billfrist/the_Drive_public.png)

Play

#150 - Senator Bill Frist, M.D.: A modern Renaissance man's journey through science, politics, and business

#150 - Senator Bill Frist, M.D.: A modern Renaissance man's journey through science, politics, and business

1x15s30s

0:002:23:38

# We discuss:

- Bill’s decision to pursue medicine and do organ transplants (3:40);
- The miraculous nature of organ transplants: History, Bill’s work, and the most exciting things to come (12:00);
- Frist’s experience building up the heart transplant program at Vanderbilt (21:45);
- The famous rivalry between surgeons Denton Cooley and Michael DeBakey (29:15);
- How the medical field can attract bright young people to pursue medicine (33:00);
- Bill’s decision to leave medicine and run for the US senate (38:00);
- The value in having scientists and physicians in Congress (47:30);
- A discussion on whether or not senators should have term limits (55:30);
- The highly polarized nature of politics, and how we can fix it with empathy (1:00:30);
- Bill’s time in the Senate and quick rise to Senate Majority Leader (1:05:30);
- The lifesaving impact of the President’s Emergency Plan for AIDS Relief (PEPFAR) under George W. Bush (1:15:15);
- How Bill reversed course on his view of the value and morality of stem cell research (1:19:45);
- Complex end-of-life decisions, and Bill’s role in the infamous Terri Schiavo case—a story that captures the conflict among law, morality, and improving technology (1:30:00);
- Remembering the events of September 11th from Bill’s perspective in the Senate (1:49:45);
- The coronavirus pandemic: Bill’s accurate 2005 prediction, and a discussion about future preparedness (1:56:45);
- The divided state of US politics, and how we can come together (2:06:45);
- How experience in medicine and politics is shaping Bill’s current endeavors in business, reforming education, palliative care, and more (2:12:45); and
- More.

§

## Show Notes

## Bill’s decision to pursue medicine and do organ transplants [3:40]

**Frist’s early medical career**

- His father and both brothers were docs
  - Always assumed he’d do something health related
  - Saw that it was gratifying and what his dad was able to do for people
- Tried other things (public and international affairs) but came back to medicine

*You were not pre-med and studied other things at Princeton. Do you think that encouraged you to do other things besides medicine in your career?*

- Frist interned in Washington DC for Congressman [Joe Evins](https://en.wikipedia.org/wiki/Joe_L._Evins) from Tennessee during high school and college, wrote for a local newspaper over the summer, etc. [6:44]
- But back then, it was very unusual to have other interests outside of medicine when applying to med school: usually pre-med track, work in a lab, etc.
- Went to Harvard Med, then a 6-year residency and fellowship, all at Mass General Hospital in Boston

**Organ Transplantation Medicine**

- Frist wanted to do transplant surgery
  - Frist had stayed at Mass General because of the early work with kidney transplants and  immunology
  - Harvard ended its heart transplant program because it was too experimental and it could do much more proven preventive care at a similar cost
  - Frist then went to Stanford for a transplant fellowship
- [Christiaan Bernard](https://en.wikipedia.org/wiki/Christiaan_Barnard) did first heart transplant in South Africa around 1966-67
- Then ~100 were performed in Texas, but most patients died and the program was shut down
- [Norman Shumway](https://en.wikipedia.org/wiki/Norman_Shumway) (whom Peter called “the pioneering transplant surgeon of our era”) was Frist’s mentor at Stanford
  - He was outside the mainstream
  - Did ~10 years of lab research before bringing it to patients
  - Others like Bernard were too brash, programs shut down because doing lots of surgeries with low survival rate [9:45]

> *Norman Shumway, Frist’s mentor at Stanford,  “figured out the science, the immunology of [heart transplants], the cardiac biopsies, the instruments of it, and in a very deliberate way. And I tell that long story because it really had a huge impact on me, that the science is really fundamental. It’s important. Until you get the science right, you should not be taking this to the clinical world. Know the facts, get rid of the misinformation, do clinical trials, don’t prematurely take things to the field.”* *– Bill Frist*

- MA General had a 50% mortality rate and concluded that its program was not doing the greatest good for the greatest number of patients
- Frist strongly disagreed
  - He knew that transplants could save hundreds of thousands of lives
  - And enable people who would otherwise have died in 6 months to live for decades longer

## The miraculous nature of organ transplants: History, Bill’s work, and the most exciting things to come [12:00]

- So he went to Stanford because Shumway had “systematically had spent 20 years developing heart transplantation and continued to do that” as the field evolved
- Peter wishes he had met [Thomas Starzl](https://en.wikipedia.org/wiki/Thomas_Starzl), who wrote the book [The Puzzle People](https://www.amazon.com/Puzzle-People-Memoirs-Transplant-Surgeon/dp/0822958368): **“**I can’t recommend it highly enough to people who love stories about the history of medicine.”
  - Idea that you face failure after failure but patients have no other choice, so you keep going [12:45]
  - What Peter took away from book
    - 1) you must believe the situation will get better
    - 2) you have to have a personality where you won’t give up after multiple failures because you can focus on what progress there has been [13:16]
- Progress has been made
  - Have made progress in immunology: in early 1980s only had [prednisone](https://en.wikipedia.org/wiki/Prednisone) and [6-Mercaptopurine](https://en.wikipedia.org/wiki/Mercaptopurine) (6-MP) [14:04]
  - Some progress was surgical techniques
    - Heart would be inflamed right after surgery, which frustrated many surgeons
    - Shumway figured how to go in through the neck to heart [14:55]
  - Only drugs they had at first were prednisone and [azathioprine](https://en.wikipedia.org/wiki/Azathioprine) (Imuran)
  - Then in 1982, could use [cyclosporine](https://en.wikipedia.org/wiki/Ciclosporin), which was accidentally discovered from a fungus
    - Dropped mortality from roughly 50% to 20%
    - Can adjust the immunological treatment so not so severe that patients die from infections [15:26]

> *“I think the important point in all of this … is that science is [an] evolutionary process.” – Bill Frist*

- The great transplant surgeons “had that deliberate, that discipline, that focused process in taking these insurmountable challenges that were impossible to do and systematically, over a period of time, capturing the best of the best, even when there are lots of losses along the way, ultimately be successful.” [16:01]
- The surgical giants  – people like [Alfred Blalock](https://en.wikipedia.org/wiki/Alfred_Blalock), [William Halstead](https://en.wikipedia.org/wiki/William_Stewart_Halsted), Norman Shumway, [C. Walton Lillehei](https://en.wikipedia.org/wiki/C._Walton_Lillehei), and Thomas Starzl – and their staff – fundamentally changed surgery

*Do you believe that there are any more step functions ahead in surgery? … is there something that you think is still an untapped opportunity? [16:54]*

- It’s strange to imagine taking a heart out of one person and putting it in another, and to imagine that he’s done it hundreds of times [17:15]
- It’s amazing to think about taking a heart out of one person, putting it on ice and flying it somewhere else, and then putting it into someone else.  It’s putting a piece of meat in someone’s chest and then all of a sudden it starts beating rhythmically, then the patient goes home a week later: “It’s miraculous” [18:03]
- It took pioneers like Shumway and Starzl to make that happen
- Developments in other areas of surgery too
  - instead of large incisions and bloody procedures, can now use scopes and minimally invasive surgery
  - robotic surgery
- Exciting developments at the cellular level and in regenerative medicine
  - Imagine instead of transplanting a new heart being able to inject new cells into someone’s heart that can rejuvenate it – that will be exciting
  - Is that surgery or not? It’s unclear
  - Exciting things in synthetic biology world: imagine being able to put in [mitochrondria](https://en.wikipedia.org/wiki/Mitochondrion) surgically
- This is where a lot of the future is
- At Stanford, Shumway set a very different tone than other places [20:40]
  - Did not do things for tradition’s sake
  - took a team approach
    - Merit-based: did not have to put in a certain amount of time to do something; you could do it if you were ready and able
    - respect for nurses [20:35]
    - Said he was “the world’s greatest first assistant” – it was about the team
- [Bruce Reitz](https://en.wikipedia.org/wiki/Bruce_Reitz) came out of that tradition
  - He had just left Stanford as Frist came in
  - Went to Johns Hopkins

## Frist’s experience building up the heart transplant program at Vanderbilt [21:45]

- Frist then went to Vanderbilt
  - Built the first heart transplant program east of the Mississippi, eventually heart-lung
  - Modeled program on Stanford’s heart-lung program
- Started with heart, then added lung when cyclosporine made that possible
  - Reitz and Shumway did the first heart-lung transplant
  - Lung is harder than heart even though seems it would be the other way around

*How were insurance companies thinking about this type of procedure at that time? [23:00]*

- Dealing with Medicare, Medicaid, commercial payers [23:24]
- Government did not reimburse for transplants because considered experimental for about 8 years
  - designated certain centers to figuring it out
  - once the survival was sufficient and you were qualified as a center of excellence, then they would start reimbursing
  - private payers were similar
- To get program established, Vanderbilt agreed to pay for expenses of first 10 transplants if insurance didn’t
  - Started being reimbursed after doing about 6 of them
  - After maybe 8 years, all payers would cover transplants
- Got good results
  - 100% chance of death without transplant
  - With transplant, 80% survival at 5 years
  - Could live as long as 30 years

*At Stanford you were in a great program with a great culture and the best people.  Then all of a sudden you’re in charge and under a lot of pressure to be successful in order to keep the program going. You have the stress of not only the patient’s life but also the program’s success and what it means for transplantation generally.  What was that pressure like? [25:04]*

- Added pressure of having worked with Shumway [26:14]
  - Within a year, people began to go to Bruce Reitz and Frist instead of Stanford
  - Shumway said they were just as good
  - People could get same culture
  - Within a year lots of people coming into Vanderbilt
- At Vanderbilt Frist worked with [Walter Merrill](https://www.vumc.org/section/38530), a highly versatile surgeon
  - Had come to watch Frist at Stanford
  - They did all surgeries together for 10 years
- Did some transplants on kids 2-3 days old
- Motto at Vanderbilt
  - team first
  - “keep it simple, stupid”
  - don’t be afraid to “double dribble” it (do it again if it’s not perfect the first time)
- Program is now the largest heart transplant program in America
  - also does lung, heart-lung, bone marrow
  - ultimately added liver and pancreas as well
- Frist was lucky to get a mentor and then go out and replicate his mentor’s culture

## The famous rivalry between surgeons Denton Cooley and Michael DeBakey [29:15]

- [Denton Cooley](https://en.wikipedia.org/wiki/Denton_Cooley) and [Michael DeBakey](https://en.wikipedia.org/wiki/Michael_DeBakey) were Houston surgeons who were excellent but also arrogant
- Frequently competed with each other
- Made many advances in surgery and vascular surgery
- Jumped on transplantation after Shumway and Bernard
  - but did not limit number and do it deliberately like Shumway
  - Did ~110 heart transplants in competition with each other in late sixties, but all of the patients died
  - Shumway was using a little cannula through the neck to try to reduce inflammation
    - Texas doctors “didn’t have the patience for that”
    - shut down their program
  - Did a few in late 70s and then started again in 80s with everyone else
- Peter says story of DeBakey and Cooley would make [a](https://www.amazon.com/Hearts-surgeons-transplants-miracles-disasters/dp/0841501238/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) [good](https://www.amazon.com/100-000-Hearts-Surgeons-Memoir/dp/0976669773) [book](https://www.amazon.com/Ticker-Quest-Create-Artificial-Heart/dp/0804138001) that he’d want to read [30:50]
- Rivalry between them that was well-known

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig-1-frist-1024x536.png)

**Figure 1.  Representations of the rivalry between Cooley and DeBakey in the August 5, 1968 issue of** ***Life Australia*** **and a cartoon by Oliphant in a 1969 edition of** ***The Denver Post*****.  Both images were reproduced in a 2010** [**article**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3014138/) **Cooley wrote about the feud in the** ***Texas Heart Institute Journal*****.**

- Peter’s encounter with Cooley at an American College of Surgeons conference [31:22]
  - At Hopkins, Peter noticed a picture of Cooley when he was young and “upsettingly handsome”
  - Peter and another resident met Cooley at a conference
    - he told them it took him fewer years to become a surgeon than were currently required in training programs
    - But he added, “Now, admittedly, I was better than everybody else”
- Frist says that even though they were arrogant, they’re icons [32:48]
  - contributed a lot to medicine
  - because of their procedures and people they trained, hundreds of thousands of people are alive today

## How the medical field can attract bright young people to pursue medicine [33:00]

*Has the profession changed such that the best and the brightest would never consider medicine today? If the great surgeons were 20 years old today, would they be going into biotech startups?*

- Used to be an element of athleticism about it
  - not true anymore
  - Technology is now widely used
- All the exciting new developments still attract students
  - as does wanting to heal people and be part of something bigger than yourself
  - Other fields will attract people too, but we will still have good people applying to med school

*What advice do you have for somebody today who wants to go into medicine? Given what you know about the profession of medicine and also the landscape of payers, hospital systems, etc., what advice do you have for somebody to be successful? [35:44]*

- Today there is much more acceptance of and appreciation for people with broad experiences in medicine; they have a curious mind [36:30]
- “It’s all health and it’s all healing. It’s all giving hope. There’s lots of different ways to do it.”

## Bill’s decision to leave medicine and run for the US senate [38:00]

*In the early 90s, how were you starting to think about a transition into elected office?*

- Being in the US Senate was never Frist’s goal
- Had been in medicine for a long time and wondered what he could do to affect health at a community or population level
  - It was policy, which could best be done in the Senate
  - His dad had said that the greatest gratification has been able to give somebody hope, and Frist thought policy could do this
- No one in his family has ever run for office
  - His mom was more Democrat, his dad more Republican, and he was “probably neither”
  - His dad thought he was crazy to give up a career at the top of the surgical world
- He decided he would do it to effect change at the policy level, but would only do it for about 10 years because “I’m not a politician”

*Why did you choose the Senate, with only 2 seats, instead of the House, in which TN has 9 seats? And how long was the process of preparing to run? [41:18]*

- Spent about two and a half years before he “started talking”
  - “You have to go all in”
  - no physician had been elected to the Senate since 1928
- Around 1991, talked to [Howard Baker](https://en.wikipedia.org/wiki/Howard_Baker) (former senate majority leader), [Lamar Alexander](https://en.wikipedia.org/wiki/Lamar_Alexander) (former governor), and [Al Gore](https://en.wikipedia.org/wiki/Al_Gore) (then a senator). All said this is a tough business but if you’re serious, do it
- Had to choose between two seats, running against an unknown or an incumbent, and he ran against incumbent

*What was the primary like back then compared to, for example, what primaries are like today, which is a fight to the extreme? [44:41]*

- At that time TN was roughly half Republican (east) and half Democratic (west), so to win statewide “your politics tended to be very principled” to appeal to a broad range of people
  - He was one of 6 primary candidates
  - from middle and not east TN
  - hadn’t paid political dues to Republican party
- In primary he ran against [Bob Corker](https://en.wikipedia.org/wiki/Bob_Corker), whom he ultimately recruited to the United States Senate, who was also an outsider like Frist
  - Doesn’t want to idealize it too much, but was a clean race
  - no one was driven to extremes like they are now
- Frist won, but no one had expected him to (he says chances were ~1%) [46:47]
  - Part of Republican wave in 1994 and only one to beat an incumbent
  - Part of it was being in right place at right time
- 3 big policy issues:
  - balance the budget / eliminate the debt
  - keep taxes small
  - welfare reform

## The value in having scientists and physicians in Congress [47:30]

*How did you learn the mechanics of the US Senate? If the first time you’re doing a transplant by yourself is scary, I would think the first day you’re sitting on the floor of the US Senate is 10 times scarier. [47:44]*

- It was hard at first, didn’t know how things worked
  - “Precedent is experience. It’s being around. It’s age. It’s knowledge. … But I had zero.”
  - Didn’t have friends or colleagues there, but helped that he was a doctor, listening to learn, and considered as someone who could be trusted
- Many senators were lawyers, but not being one ended up being an advantage
  - Experienced Senators wanted his perspective from the outside world
  - Healthcare issues came to Frist immediately

> “There was nobody in the [Senate] chamber who’d ever taken care of a patient or written a prescription” – Bill Frist

- The last time Peter looked at the stats, slightly fewer than 1% of people in Congress had either an undergrad or graduate degree in science [52:19]
- Now there are ~3 physicians in Senate and ~14 in House
- Frust says that the number of physicians in the Senate decreased by roughly half every 50 years
  - 1750 to 1800: ~24-25
  - 1800 to 1850: ~12
  - 1850 to 1900: ~6
  - 1900 to 1950: ~3
- Some in medicine think you are not a serious doctor if dabbled in policy or politics
- The lack of doctors in politics has been “to the detriment of patients and America, because physicians are the best voice for 300 million people, because they’re listening to their problems and their challenges, and the socioeconomic and the diversity issues.”
- Running “tears your life apart”
  - you give up privacy
  - affects your family
  - 50% of country doesn’t like you
- “I spent a lot of time explaining what science is. And as science was progressing and technology was progressing, ethical issues were involved.” [54:59]
- Need more docs in Senate

## A discussion on whether or not senators should have term limits [55:30]

**Bill’s philosophy on how long one should stay in office**

- Frist was always clear that he wanted to serve only two terms (12 years) in the Senate [55:33]
  - Allowed him to do what he thought was right in his last term
  - Did not have to focus on fundraising
  - He believes in the idea that you should go to Washington DC to serve as a **citizen legislator** and use your broad experiences, trials, tribulations, and empathy to help shape the laws of the land — and then return to your life and live under those laws

> “I believed very much in a concept called the citizen legislator. … The citizen, the broad experiences, the trials, the tribulations, the challenge is the understanding, the empathy, and applying all of that to help shape the laws of the land.  And then after I’ve done that, go back and live under the laws that I’ve passed” – Bill Frist

**Does Bill think we should set term limits for Senators and Representatives?**

- Frist disagrees with Peter that there should be term limits for Senators and Representatives
  - The job is complicated, as complicated as heart surgery
  - When he became leader, he needed the experienced people who had been there for years to explain the history and precedent of things
  - Need people who will limit their time, but also need the veterans: “*I do think this mixture is important because of the complexity of the job*”

## The highly polarized nature of politics, and how we can fix it with empathy [1:00:30]

*What was the camaraderie like between parties when you were in the Senate? It used to be that politicians of opposite parties still socialized together. There was still a degree of respect. How much time did you spend with members of the opposite party, and what were those relationships like? Above all else, how did that influence your ability to bring empathy to the other side’s point of view? [1:00:42]*

- The first six years and the last six years were different for Bill
  - Served under [Bill Clinton](https://en.wikipedia.org/wiki/Bill_Clinton) and [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush)
  - Because of media and the internet and cable TV, everything happened in real time and “nothing could be done behind closed doors”
- During his first term, he would frequently meet, have dinner, and have discussions with members of opposite parties
- But over time, and during his second term, that seemed to happen less and less frequently
- Bill says it’s gotten much worse since he left office, tut the change began during his tenure

Striking a balance between the media holding politicians accountable and creating a counterproductive environment where the media polarizes everyone [1:03:47]

- Transparency is critically important
  - “hiding things, in the long run, is unhealthy and destructive to our government, to the fundamentals of our democracy.”
  - What has changed has been all the misinformation that campaigns
  - But it’s nearly impossible to counter real-time misinformation put out by the media
  - This lead to less and less meetings across parties — it created an unhealthy practice of separating from each other
- Can be fixed with more **empathy**
  - Need to be more like a doctor with empathy and connection
  - You don’t have to agree with someone, but you need to have empathy for another person’s perspective to be able to see two sides of things
  - Bill says there’s “just less empathy in the corporate structure of the United States Senate today”

## Bill’s time in the Senate and quick rise to Senate Majority Leader [1:05:30]

**Senate committee work in his first term [1:05:43]**

- He was lowest in seniority because he was not only newly elected but also never been in public office before
- Served on Banking Committee
- Also Health, Education, Labor, and Pension (HELP) Committee and chaired the Subcommittee on Disability Policy
- About 2 years into tenure he was on Foreign Affairs Committee; stayed on that for the rest of his time because he had done so much travel to other countries doing medical work
- On Commerce Committee from years 2-6

**Senate Majority Leader in his second term**

*What string of events allowed you to go from being still a relatively junior senator to being the second most powerful person in Washington after the president? [1:07:30]*

- Crazy to go from rank 100 to rank 1 in 6 years (Lyndon Johnson did it but he was in House for years)
- [Bob Dole](https://en.wikipedia.org/wiki/Bob_Dole) and [Trent Lott](https://en.wikipedia.org/wiki/Trent_Lott) were battling with each other over control
- The way to influence a body “is to get involved in the determination of who’s in the room and who is not”
- Six years in, he ran the National Republican Senatorial Committee
  - Recruited Lamar Alexander, [Elizabeth Dole](https://en.wikipedia.org/wiki/Elizabeth_Dole), and [John Thune](https://en.wikipedia.org/wiki/John_Thune)
  - Probably would not have been in the Senate without Frist recruiting them
- The Republicans won 11 Republican seats even though it was George W. Bush’s midterm election and the Democrats were expected to win
- Frist traveled and raised money and recruited people
  - He’d spend hours talking with potential candidates and their families
  - His goal was just to keep losses to a minimum because in the first midterm of any party, that party loses seats 9/10 times [1:12:00]
  - They won so Frist got credibility
- But some infighting among the Republicans led to Bill’s appointment
  - He didn’t want majority leader because hard to do policy when you’re in leadership
  - 5 people wanted to be the majority leader but none had enough votes
  - Coming off midterm victory, Bill had built up a lot of credibility as someone who was talented, non-threatening, and could bring both parties together
  - The group decided Bill was best positioned for the role

> “This is no different, elections and life. Things are fair and things are unfair, and luck is a part of it.” —Bill Frist

## The lifesaving impact of the President’s Emergency Plan for AIDS Relief (PEPFAR) under George W. Bush [1:15:15]

[President’s Emergency Plan For AIDS Relief (PEPFAR)](https://en.wikipedia.org/wiki/President%27s_Emergency_Plan_for_AIDS_Relief)

- PEPFAR doesn’t get a lot of attention in the US and many Americans don’t know much about it
- But Africans who have been impacted by it hold the [Bush administration](https://en.wikipedia.org/wiki/Presidency_of_George_W._Bush) in high regard
- Frist had spent 2-3 weeks a year in Africa, doing surgery and training people, mainly in the Louis province of South Sudan but also in Ethiopia, South Africa, and Botswana
  - [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) had no experience with Africa
  - 3 million people there were dying of HIV/AIDS a year (more than TB or malaria)
  - Bush listened to Frist and [Anthony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci), and in the [2003 SOTU address](https://www.youtube.com/watch?v=hcKXcVCUoG0), he made the single largest commitment to a single disease by a POTUS
- At the time, the right was saying AIDS was God’s punishment and the left was doing nothing
- Legislation was passed in about 6 months
  - spending about 200 million a year under Bill Clinton [1:18:49]
  - under Bush the Senate passed first $3B the first year, then $3B/yr for 5 years
  - after that others continued it and over time it was $65 billion
  - The vote was close but bipartisan
  - Now many other spinoff programs addressing multiple diseases, infrastructure, and surveillance in multiple countries

> “Twenty million people are alive today because of that five-page bill that surprised everybody coming out of this president.” —Bill Frist

## How Bill reversed course on his view of the value and morality of stem cell research [1:19:45]

**Stem cell research**

- Bill initial held the common view of the Republican party in opposing stem cell research
- Eventually, he reversed course and supported it

*What changed?*

- Frist was familiar with brain death because of donor patients
- The [1996 Dickey-Wicker Amendment](https://en.wikipedia.org/wiki/Dickey%E2%80%93Wicker_Amendment) banned federal funding of embryonic stem cell research, which was still new
- They are unique because they can become any kind of tissue, and you can make unlimited copies of it
  - People didn’t know what could, or should, be done with them
  - But great medical potential if you could regenerate a sick heart or repair neurodegeneration
- Frist was unsure if the fed government should fund it
  - could only get them by destroying an embryo, which 50% of Americans consider a human
  - Bush supported allowing research on the 78 cell lines already created but said wouldn’t create and destroy embryos
  - Frist supported also using embryos that had been created in fertility clinics and would otherwise be discarded
  - there was an evolution of knowledge and better techniques
  - It became clear that only about 22 of the 78 original cell lines were good, so Frist now felt they were not sufficient [1:24:09]
- In 2005 Congress overwhelmingly passed the [Stem Cell Research Enhancement Act](https://en.wikipedia.org/wiki/Stem_Cell_Research_Enhancement_Act#Stem_Cell_Research_Enhancement_Act_of_2005) to allow use of fertility clinic embryos, but Bush vetoed it
  - Very exciting to Frist, but he didn’t want “embryo mills” where women paid to let their eggs be used to create embryos that would be destroyed
  - Frist felt that the US needed a “disciplined mechanism around that” which ultimately was put in place
  - The principles he set out in 2000 and 2005 are essentially in place today
- 17 years later, we’ve made some progress but no breakthroughs yet – not yet treating Alzheimer’s and Parkinson’s with stem cells
  - Very challenging to figure out how to instruct stem cells – which cell type to become, how many times to divide, etc.
  - Bill says we are at step 1 of 10 in this process
- “You have to set up the construct, or you’re not going to find funding.”
  - There was an assumption that advancements could happen really fast so we had to fund everything right away regardless of moral issues
  - We increased finding with ethical constructs that Frist thinks worked well
  - These fields are promising but they must be ethically constrained, Frist wishes wish we could slow them down
  - People in Washington make this policy and must be held accountable; they need to do it in the best way they can at a point in time.

## Complex end-of-life decisions, and Bill’s role in the infamous Terri Schiavo case—a story that captures the conflict among law, morality, and improving technology [1:30:00]

Peter witnessed an ethically complicated case when he was in medical school

- Patient was brain dead but there was a complicated family dynamic and disagreement about removing life support
- All the hospital ethicists tried unsuccessfully to deal with it
- Ultimately it was mediated by [Bruce Reitz](https://en.wikipedia.org/wiki/Bruce_Reitz), the chair of cardiac surgery at Stanford
  - Spent two hours with family
  - Eventually they came to an agreement (in that case, that life support should be withdrawn)

**Terri Schiavo case [1:31:50]**

- The [Terri Schiavo case](https://en.wikipedia.org/wiki/Terri_Schiavo_case) became a national issue when Bill was in the Senate
- Young woman who had eating disorder
  - Developed low potassium from repetitive vomiting, went into cardiac arrest
  - Able to revive her body because young, but her brain has been deprived of oxygen for several minutes
  - Had to be fed through a tube
- Her husband believed she would remain in a [persistent vegatative state](https://en.wikipedia.org/wiki/Persistent_vegetative_state) (PVS)
  - but her parents disagreed
  - led to major court battle
- Happened in 1990, but has implications for everybody listening today [1:33:38]
- PVS is a medical term
  - means you can move and you open your eyes
  - but you have to be supported with both a feeding tube and a ventilator
- Her husband took her to top medical centers, tried rehab and pretty much everything
  - By 1993, he had given up
  - but all of her blood relatives objected to removing the tube and having a DNR order; said she recognized and responded to them
- She had nothing written down: no living will, no advanced directive
  - Family says she’s a devout Catholic and they will take care of her
  - By law husband can make the decision

\*\*\*

**The importance of an advanced directive**  [01:36:17]

- This cannot be overstated or emphasized enough, says Peter
- “Everybody should have [an advanced directive] because the time to build the roof is when the sun is shining. And the time to have this discussion is when clear heads prevail.” – Peter Attia
- Bill agrees: “People don’t like to think about death or where they’re going to be buried, or wills. This is one that out of respect for your loved ones.

\*\*\*

**Back to the Schiavo case**:

- 7 years later, her feeding tube taken out
  - but courts ordered it replaced
  - At the time, medical witnesses said her condition was not beyond some recovery and she could theoretically improve
- She’s either in a minimally conscious state, or persistent vegetative state
  - In 2003, the FL state court had 5 doctors test her: two chosen by husband, two by family, one by court
  - Three to two, they said she was in a persistent vegetative state and it would be okay to withdraw therapy
  - other two said she was in a minimally conscious state and could recover
- She stayed alive for 6 days
  - during the 6 days, the FL legislature passed law allowing the FL governor, [Jeb Bush](https://en.wikipedia.org/wiki/Jeb_Bush), to order the tube put back in
  - Florida Supreme Court struck the law down
- Frist says these decisions should be made with by family with a physician or caregiver (and clergy if applicable)
  - but this became political
  - The pope made a statement
  - someone pledged $2 million for her care

- Because he was a doctor, and someone familiar with brain death, Frist got involved: “*I  didn’t want to do it, because I don’t think it should be done. It should be really rare, really exceptional, but this had become a global issue*.”
- Frist sees the question as **whether the government has the right to terminate life when the family objects** to it and they’ll take financial responsibility
  - He would not take a heart if the spouse consented but the rest of family objected, even though he legally could
  - He would not go to harvest an organ if the family disagreed, so he avoided this type of situation [1:41:42]

**PVS vs. mentally conscious**

- The debate centered over Schaivo was whether she was in a PVS vs. a mentally conscious state
- A neurologist had said she was in the latter
- The difference between them [1:42:19]
  - Some brainstem function:
    - blink if touch cornea
    - if you injected ice water in her ears, doll’s eye reflex
    - minimal gag reflex
  - But the definition is not determined by a single test
  - She had not had an MRI or PET scan
    - did not have them until after she died
    - Post mortem CT scan showed that she had little brain matter and the space was mostly fluid

⇒ Watch Bill [discuss this case](https://www.youtube.com/watch?v=FBYk4F164Hk) on the Senate floor:

**Bill’s conversations those involved**

- Frist spoke with both the neurologist and Terri’s brother [1:43:07]
  - family said “don’t terminate her”
  - she had not had a full workup – no MRI, no CT scan
  - 15 neurologists had signed an affidavit that said she needed an independent current evaluation
- Intervening was controversial even among Frist’s staff, who asked, “What in the world are we doing?”
  - Frist agreed but had to deal with it because it got to Senate
  - He thought it should dealt with locally like it had been for the 20 years he was in medicine

Bipartisan bill supported unanimously in the United States Senate

- overwhelming majority and both parties in the House of Representatives
- The bill itself said Schaivo needed an exam that is truly independent; guaranteed a process and not an outcome
- If she’s in a persistent vegetative state, then remove the tube if that’s what the husband wants
- And if not, the family should be listened to
- The fed courts denied the petition
- feeding tube was removed and she died

**Conflict among law, ethics and morality, and improving technology**

- the story captures the conflict among law, ethics and morality, and improving technology, and the problem of not having directives written down
  - a lot of people say it was his biggest mistake in the Senate, but would do it again if setting up a **process** and **not an outcome**
  - Frist was the only person in the Senate at the time who’d taken two oaths, the Senate oath but also the Hippocratic oath
  - “And when there’s ambivalence around that, and when the family wishes otherwise, and it’s true ambivalence, I will opt on life.”
- Says federal intervention in these types of cases should be “exceptional and rare” (as it has been) and decisions clearly should be made locally

**Separating the politics from the science**

- Politics made it worse, commentators said Frist was “playing doctor in the United States Senate”

> “What I tried to do … and it’s hard to do, is to separate the politics from the policy. To separate the politics from the science.” – Bill Frist

- Case shows challenge to policymakers who are given trust to make decisions like this
- Peter cannot understand how, in the late 1990s, a CT scan wasn’t done – would have been obvious what condition her brain was in if they had done it [1:47:59]
- Peter doesn’t think Frist was being so much political (given that it was his final term) as voting his conscience

Politics is a part of our democracy [1:48:55]

- many of us wish you could push this extreme partisanship out of it
- politics and policy can’t be separated totally
- If argue law to the extreme may not be able to see the larger picture
- Need to elect people who have **broad past experiences** with other fields and can discern the social context

## Remembering the events of September 11th from Bill’s perspective in the Senate [1:49:45]

*It’s so hard to believe that we are now in the 20th year since 9/11. As a Senator, what do you remember about that morning, and what was running through your mind as this thing was unfolding?*

- Frist still has nightmares about it
  - It was an assault we did not yet fully understand, but they had make decisions without enough info
  - As a pilot, his first thought was it’s pretty rare to hit a building
  - When it was clear it was a passenger jet, he was at a high level of leadership [1:51:38]
  - He had been briefed and knew there had been a lot of “noise on the internet” and he knew there was real chance it was something major
  - When second plane hit, he knew there was a real risk of a 3rd
- Also immediately wondered where his kids were – they were in school in Washington near major landmarks
- Certain people taken to secure location “so if there is an atomic bomb or if something happens, we can refashion government”
  - A few senators, a few house members, a few Supreme Court justices, the president or the vice-president
  - Frist was not in that group, but “it was as intense as anything in the surgery that had gone awry that I’d ever done.”

> “I wouldn’t panic [in surgery], but this world of not having any information, … essentially no intelligence, and not knowing where it’s coming from, and not knowing what was going to ensue over the next 12 hours. This is different than anything at the operating room, at the table. In there you’re doing life and death things every day. This was different.” – Bill Frist

- “And so once we found out we didn’t have the intelligence, which was pretty quick, we had to pretty much assume that we were all going to be taken out.” [1:54:54]
- All the leaders went to Capitol steps together, both parties together and nothing else mattered
  - It was about the safety and security of our country and maybe existentially the future of our country [1:56:00]
  - “We displayed to the world that you can try to take us out, but you can’t take us out. I think that was really important.”

![](https://peterattiamd.com/wp-content/uploads/2021/02/fig-2-frist-1024x516.png)

**Figure 2. Members of Congress on the Capitol steps on September 11, 2001** [[source](https://uschs.wordpress.com/2011/09/20/september-11-2001-standing-on-the-u-s-capitol-grounds/)]

- Once they knew they could reconstitute government, busy time making a series of strategic decisions about whether and whom to hit

## The coronavirus pandemic: Bill’s accurate 2005 prediction, and a discussion about future preparedness [1:56:45]

*There was an “amazing lack of partisanship” following 9/11.  Does it surprise you that a pandemic like COVID didn’t have any of that effect of unifying the country? Do you think this is different because a pandemic is not a group or country and it doesn’t affect the US exclusively?*

- With 9/11 there was “an embodiment of something that is external to you that you can project towards,” which doesn’t apply to a virus that affects everyone globally and does not discriminate
- Also, with the virus our leadership and communication was very different than with 9/11
  - Frist noticed a difference in how things were handled
  - Big disappointment to Frist

## *“I think that if there had been a call to action with appropriate communication, leadership, trust, empathy, [and] understanding, that this pandemic could have been externalized and we would probably have more rallying around it instead of … what you see on social media and internet and television” – Bill Frist [1:59:24]*

- In 2005, Frist quite [accurately predicted](https://www.forbes.com/sites/billfrist/2020/05/06/we-failed-to-act-on-pandemic-preparedness-after-sars--we-cannot-make-that-same-mistake-again/?sh=3cb85e216281) what we’re seeing now based in part on the 1918 epidemic [1:59:47]
  - He said it was a matter of when, not if
  - predicted 10 effects that have come to pass
  - People have taken it seriously, but “the lack of preparedness was just crystal clear to me” [2:00:41]
  - Suspected it would involve animals and spread around the world
  - Frist gave about 20 similar speeches in 2005 called The Manhattan Project
  - He mentioned the possibility of bioterrorism as well because of 9/11, smallpox stockpiles, etc. [2:01:53]
- Regardless of the cause, in a pandemic you need:
  - Communications
  - Infrastructure
  - Stockpiling
  - Biology research and development
  - antiviral agents
  - manufacturing capacity, etc.
- Some legislators have started parts of it, but Frist hopes this pandemic will make the urgency more clear
  - Frist’s biggest fear is that nothing will be done
  - people need to push for it
  - Tend not to think about dangers that are not immediately visible: “It’s only the snake that’s at your foot that you’re scared of. Once the snake goes off in the trees, you just lose that sense of sort of urgency there”

- Peter points out that, although it sounds horrible to say, we dodged a bullet here [2:04:03]

- This virus is not nearly as powerful as the Spanish Flu or the Hong Kong Flu or SARS1 or MERS
- the Ebola Virus, it kills very quickly
- SARS-Cov-2 is very contagious but less lethal
- If we get something more lethal with a long latency, it could kill tens of millions of people

- Frist testified before Lamar Alexander’s Health Committee [2:05:19]
  - People said it was crazy to think about the next pandemic when we have one now
  - The public needs to understand and stay on it
- We need to beef up simple things like infrastructure
  - vaccine distribution has been a challenge
  - we have fewer public health people on payroll than we did 8 years ago

## *“Public health has been the stepchild of health and welfare and healing. That is inverted now, and people appreciate it, but are we going to actually deliver on it? Not just next year, and not just put more funding in it, but really do it over a period of time?” – Bill Frist [2:06:16]*

## The divided state of US politics, and how we can come together [2:06:45]

- Our current two-party system rewards the extremes and punishes the compromisers
  - Things like social media and cable news amplify it
    - But on [Frist’s podcast](https://asecondopinionpodcast.com/), about 90% of guests say they’re optimistic about things
    - Frist himself is optimistic by nature
  - The next few years are going to be really difficult and may get worse, but eventually we will work it out
  - We will to figure out how “to curate social media in a way that still allows freedom of expression and free speech, but where it can’t be used in the negative ways, whether it’s partisanship or misinformation”
- Leadership will take a while [2:09:31]
  - Before Iraq War tensions, Bush periodically had people from both parties to breakfast with no press
  - It was uncomfortable but a good idea
  - [Barack Obama](https://en.wikipedia.org/wiki/Barack_Obama) and [Donald Trump](https://en.wikipedia.org/wiki/Donald_Trump) didn’t do it
  - Need to do it, gives cover to people below
- It’s courageous to say, “I’m willing to sacrifice a second term”
  - Peter notes that this is a big sacrifice [2:11:59]
  - Frist says it’s hard but doable
    - There is a call now for this kind of bringing people together
    - “Doesn’t mean sacrifice your principles. It doesn’t mean sacrifice your party. It just means come to the table and be able to have a discussion and have a disagreement and … sort of shaking hands after you have a big debate on the floor of the Senate.”

## How experience in medicine and politics is shaping Bill’s current endeavors in business, reforming education, palliative care, and more [2:12:45]

- Doing venture capital
- On the board of numerous companies and non-profit organizations
- Part of the [Bipartisan Policy Center](https://en.wikipedia.org/wiki/Bipartisan_Policy_Center)

*Your commitments span so much. What has been the most interesting and what have you brought to it from medicine and politics?*

- Healing and health has been his consistent theme
  - medicine was 10 years learning and 10 years delivering
  - then 12 years in politics
  - then 10 years in the private equity world
  - last five years in venture capital
- Also became interested in education
  - Frist asked himself, “Putting together my past experiences, what if there’s one thing that could be done to change the course of history?”
  - K through 12 education, especially for girls on a global scale
  - Started a foundation called [State Collaborative on Reforming Education](https://ballotpedia.org/State_Collaborative_on_Reforming_Education#:~:text=The%20State%20Collaborative%20on%20Reforming,the%20campus%20of%20Vanderbilt%20University.) (SCORE)
    - had impact in TN with dramatic improvement for K-12
    - “The nexus between health and education is so real. … It just feeds together.”
- His investment focus is on mission-directed health service companies that lift up vulnerable populations rather than pharmaceutical companies or molecules or devices
- Palliative Care
  - After 50 years, hospice is really good in the US
    - but Frist is working on palliative health care and chronic disease
    - most people do not die the way they would want to die
    - Palliative care is decent at major hospitals, but not in areas further away from them
  - He noticed that patients waiting for transplants lived longer than expected when he dealt with their nutrition, exercise, mental health, and “spiritual health”
    - When he came out of the Senate it wasn’t any better
    - He created [Aspire Health](https://aspirehealthcare.com/), a company that is now the largest palliative, non-hospice-related palliative health company in communities across the country
    - The innovation and execution are really no different than for a heart transplant
- Peter says Bill is a true Renaissance man [2:20:11]
- But there really is something to be said for having people in the government who haven’t spent their entire lives in government.
- Frist says he told stories and discussed issues that he hasn’t told before “because of my huge respect for the nature of your podcast” and it was an honor to be on The Drive

§

## Selected Links / Related Material

**Thomas Starzl’s memoir of his experiences as a transplant surgeon**: [The Puzzle People](https://www.amazon.com/Puzzle-People-Memoirs-Transplant-Surgeon/dp/0822958368) by Thomas Starzl **|** (amazon.com) [11:37]

**Books about the rivalry between Denton Cooley and Michael DeBakey** [30:50]:

- [Hearts: of surgeons and transplants, miracles and disasters along the cardiac frontier](https://www.amazon.com/Hearts-surgeons-transplants-miracles-disasters/dp/0841501238/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Thomas Thompson | (amazon.com)
- [100,000 Hearts: a surgeon’s memoir](https://www.amazon.com/100-000-Hearts-Surgeons-Memoir/dp/0976669773) by Denton A. Cooley | (amazon.com)
- [Ticker: The Quest to Create an Artificial Heart](https://www.amazon.com/Ticker-Quest-Create-Artificial-Heart/dp/0804138001) by Mimi Swartz | (amazon.com)

**Cooley’s article about his rivalry and reconciliation with DeBakey**: [Feuds](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3014138/) (Cooley 2010) [30:50]

**George W. Bush’s AIDS program that Frist urged him to fund**: [President’s Emergency Plan for AIDS Relief (PEPFAR)](https://en.wikipedia.org/wiki/President%27s_Emergency_Plan_for_AIDS_Relief) **|** (wikipedia.org) [1:15:12]

**The 2003 State of The Union Address by George W. Bush where he announced the commitment to fight HIV/AIDS**:  [State Of The Union Address 2003](https://www.youtube.com/watch?v=hcKXcVCUoG0) | Politics 101 (youtube.com) [1:17:30]

**Amendment passed to prohibit funding for embryonic stem cell research**: [1996 Dickey-Wicker Amendment](https://en.wikipedia.org/wiki/Dickey%E2%80%93Wicker_Amendment)  **|** (wikipedia.org) [1:19:58]

**2005 act to allow use of fertility clinic embryos in research, passed by Congress but vetoed by George W. Bush**: [Stem Cell Research Enhancement Act](https://en.wikipedia.org/wiki/Stem_Cell_Research_Enhancement_Act#Stem_Cell_Research_Enhancement_Act_of_2005) **|** (wikipedia.org) [1:24:09]

**Frist’s Senate floor speech about the Terri Schiavo case**: [Frist Diagnosing Terry Schiavo on Senate Floor](https://www.youtube.com/watch?v=FBYk4F164Hk) **|** SoThisIsWashington (youtube.com) [1:43:07]

**Frist’s 2005 predictions about the 2020 COVID pandemic**: [Manhattan Project for the 21st Century: address at the National Press Club on December 8, 2005](https://www.forbes.com/sites/billfrist/2020/05/06/we-failed-to-act-on-pandemic-preparedness-after-sars--we-cannot-make-that-same-mistake-again/?sh=3cb85e216281) **|** Bill Frist (forbes.com) [1:59:47]

**Frist’s pandemic testimony before Senate Health Committee in June 2020** (Frist testimony begins at 1:01:45): [Coronavirus Response and Future Pandemic Preparedness](https://www.c-span.org/video/?473305-1/coronavirus-response-future-pandemic-preparedness)**|** (c-span.org) [2:05:19]

§

## People Mentioned

- [Joe Evins](https://en.wikipedia.org/wiki/Joe_L._Evins) (Congressman from Tennessee from 1947 to 1977 with whom Frist interned) [06:44]
- [Christiaan Bernard](https://en.wikipedia.org/wiki/Christiaan_Barnard) (South African surgeon who performed the first heart transplant) [08:51, 9:45, 29:17]
- [Norman Shumway](https://en.wikipedia.org/wiki/Norman_Shumway) (Pioneering transplant surgeon at Stanford with whom Frist trained) [8:51, 10:43, 11:37, 14:55, 16:01, 22:03, 18:03, 20:40, 22:03, 26:14, 29:17]
- [Thomas Starzl](https://en.wikipedia.org/wiki/Thomas_Starzl) (Transplant surgeon who transformed the field of transplant medicine, author of [*The Puzzle People*](https://www.amazon.com/Puzzle-People-Memoirs-Transplant-Surgeon/dp/0822958368)) [11:37, 16:01, 18:03]
- [Alfred Blalock](https://en.wikipedia.org/wiki/Alfred_Blalock) (American surgeon best known for his work in heart surgery) [16:01]
- [William Halstead](https://en.wikipedia.org/wiki/William_Stewart_Halsted) (Groundbreaking American surgeon and a founding professor at Johns Hopkins Hospital) [16:01]
- [C. Walton Lillehei](https://en.wikipedia.org/wiki/C._Walton_Lillehei) (Surgeon who pioneered open heart surgery) [16:01]
- [Bruce Reitz](https://en.wikipedia.org/wiki/Bruce_Reitz) (Surgeon who performed the first successful heart-lung transplant) [20:35, 22:03, 26:14, 01:30:11]
- [Walter Merrill](https://www.vumc.org/section/38530) (Vanderbilt surgeon and colleague of Frist) [26:14]
- [Denton Cooley](https://en.wikipedia.org/wiki/Denton_Cooley) (Houston transplant surgeon who performed first artificial heart surgery) [29:17, 31:22, 32:48]
- [Michael DeBakey](https://en.wikipedia.org/wiki/Michael_DeBakey)  (Houston transplant surgeon who performed early heart transplants) [29:17, 32:48]
- [Howard Baker](https://en.wikipedia.org/wiki/Howard_Baker) (Former senator from Tennessee and senate majority leader) [41:18]
- [Lamar Alexander](https://en.wikipedia.org/wiki/Lamar_Alexander) (Former Tennessee senator and governor)  [41:18, 01:07:30, 02:05:19]
- [Al Gore](https://en.wikipedia.org/wiki/Al_Gore) (Former Vice President of the US and Tennessee senator) [41:18]
- [Bob Corker](https://en.wikipedia.org/wiki/Bob_Corker) (Former Tennessee senator) [44:41]
- [Bill Clinton](https://en.wikipedia.org/wiki/Bill_Clinton) (42nd President of the US) [01:00:42, 01:18:49]
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) (43rd President of the US) [01:00:42, 01:07:30, 01:15:12, 01:18:49, 01:19:58, 01:24:09, 02:06:51, 2:09:31]
- [Bob Dole](https://en.wikipedia.org/wiki/Bob_Dole) (Former senator from Kansas and senate majority leader) [01:07:30]
- [Trent Lott](https://en.wikipedia.org/wiki/Trent_Lott) (Former senator from Mississippi and senate majority leader) [01:07:30]
- [Elizabeth Dole](https://en.wikipedia.org/wiki/Elizabeth_Dole) (former senator from North Carolina and cabinet member under Ronald Reagan and George H.W. Bush) [01:07:30]
- [John Thune](https://en.wikipedia.org/wiki/John_Thune) (former ND senator and senate majority whip) [01:07:30]
- [Anthony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci) (Infectious disease expert and director of the National Institute of Allergy and Infectious Diseases (NIAID)) [01:15:12]
- [Terri Schiavo](https://en.wikipedia.org/wiki/Terri_Schiavo_case) (Woman in a persistent vegtative state whose husband’s request to withdraw her feeding tube caused a national political and legal controversy) [1:30:11 through 01:49:56]
- [Jeb Bush](https://en.wikipedia.org/wiki/Jeb_Bush) (Former governor of Florida) [1:36:17]
- [Barack Obama](https://en.wikipedia.org/wiki/Barack_Obama) (44th President of the US) [2:10:50]
- [Donald Trump](https://en.wikipedia.org/wiki/Donald_Trump) (45th President of the US) [2:10:50]

§

![](https://peterattiamd.com/wp-content/uploads/2021/02/Bill_Frist-bio-image-500x500.jpg)

##### Bill Frist, M.D.

Senator William Frist, M.D. is a nationally-acclaimed heart and lung transplant surgeon, former U.S. Senate Majority Leader, founding partner of Frist Cressey Ventures and chairman of the Executives Council of the health service investment firm Cressey & Company. He is actively engaged in the business as well as the medical, humanitarian, and philanthropic communities. He is chairman of both Hope Through Healing Hands, which focuses on maternal and child health and global poverty, and SCORE, a statewide collaborative education reform organization that has helped propel Tennessee to prominence as a K12 education reform state.  As a U.S. Senator representing Tennessee from 1994 -2006 (the first practicing physician elected to the Senate since 1928), Senator Frist served on both the Health (HELP) and the Finance Committees responsible for writing all health legislation. He was elected Majority Leader of the Senate, having served fewer total years in Congress than any person chosen to lead that body in history. His leadership was instrumental in the passage of the 2003 Medicare Modernization Act and the historic PEPFAR legislation that provided life-saving treatment globally to over 12 million people and reversed the spread of HIV/AIDS worldwide.  Honoring his pledge to serve just two terms, he left the Senate and his position as Majority Leader in 2006.  As a leading authority on healthcare, Senator Frist speaks nationally on health reform, government policy, global health, education reform, and volunteerism. In 2019 he launched “A Second Opinion” podcast, which addresses challenging healthcare issues of today from three distinct vantage points: policy, medicine, and innovation. He is Co-Chair of the Health Project at the Bipartisan Policy Center and co-founder of Aspire Health. Aviation is one of Frist’s passions, and has proved to be essential in all aspects of his life. [[billfrist.com](https://billfrist.com/about/)]

Bill’s website: <https://billfrist.com/>

Bill’s podcast: [A Second Opinion](https://asecondopinionpodcast.com/)

Bill on YouTube: [Senator Bill Frist, MD](https://www.youtube.com/c/BillFristMD)

Bill on Instragram: [senatorbillfrist](https://www.instagram.com/senatorbillfrist/?hl=en)

Bill on Facebook: [Senator Bill Frist, M.D.](https://www.facebook.com/SenatorBillFrist/)

Bill on Twitter: [@bfrist](https://twitter.com/bfrist?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)