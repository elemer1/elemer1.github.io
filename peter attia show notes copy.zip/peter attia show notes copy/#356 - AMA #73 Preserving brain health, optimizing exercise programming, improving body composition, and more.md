# 356 – AMA #73: Preserving brain health, optimizing exercise programming, improving body composition, and more

**Source:** [https://peterattiamd.com/ama73/](https://peterattiamd.com/ama73/)

---

In this “Ask Me Anything” (AMA) episode, Peter addresses frequently requested topics, including brain health, exercise programming, and body composition. He explores the factors that influence dementia risk—including metabolic health, fitness, sleep, hearing, cholesterol levels, and more. He explains how to implement zone 2 training and VO₂ max intervals for cardiovascular fitness and also covers how to combine cardio modalities, how to stay in zone 2, and special considerations for women. Peter highlights the benefits of light movement after meals and offers strength training tips for those managing injuries. Additional insights include how to maintain fat loss, the truth about so-called “slow metabolisms,” and how to set appropriate daily protein goals while managing the trade-off between lean mass and body fat over time.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #73 show notes page](https://peterattiamd.com/ama73). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of episode topics on brain health, cardiovascular training strategies, and body composition [2:15];
- Understanding dementia risk: modifiable vs. non-modifiable contributors to cognitive decline [5:00];
- The causality between metabolic health and dementia [9:45];
- How diet and exercise influence brain health: energy balance and exercise as key preventative tools [13:30];
- Why combining aerobic, resistance, and cognitively engaging activities offers the most comprehensive benefits for preventing cognitive decline [17:00];
- Additional lifestyle factors that influence dementia risk: smoking, head trauma, alcohol, and sleep [19:45];
- The link between hearing loss and dementia: dose-dependent risk and the case for correction [25:15];
- How poor oral hygiene may contribute to neuroinflammation and dementia risk [23:30];
- Supplements for brain health: which ones matter and when they’re worth considering [28:45];
- Low LDL cholesterol and brain health: debunking the myth of cognitive risk [33:45];
- How to approach zone 2 training: the importance of staying in zone 2 and tailoring intensity based on your time and goals [38:00];
- Lactate testing for zone 2: clinical protocols and at-home approaches [43:00];
- Combining modalities in zone 2 training: balancing enjoyment and efficiency [47:00];
- Zone 2 training for women: addressing the misconception that zone 2 training is unnecessary or ineffective for postmenopausal women [49:30];
- Effective strategies for VO₂ max training: short vs. long intervals [51:45];
- The benefits of post-meal walking for glucose management, and why spikes in glucose during exercise aren’t harmful [56:45];
- The role of stability training in supporting resistance work and healthy aging [1:00:15];
- Adapting strength training to manage chronic back injuries and train for longevity [1:02:00];
- The role of aerobic exercise (like zone 2) in fat loss, metabolic health, and weight maintenance [1:06:30];
- Debunking the “fast vs. slow metabolism” myth: why energy balance and protein matter most for fat loss [1:09:45];
- Lean mass vs. body fat: why both matter for health and longevity [1:12:15];
- How protein intake impacts muscle mass and why pairing it with resistance training is significantly more effective [1:15:15]; and
- More.

---

The Peter Attia Drive

356 – AMA #73: Preserving brain health, optimizing exercise programming, improving body composition, and more

---

## Show Notes


---

## Overview of episode topics on brain health, cardiovascular training strategies, and body composition [2:15]

- Today’s AMA will be covering a variety of topics gathered from questions on social media, through the website, through the AMA portal, and more
- The main topics include brain health, exercise, and body composition
  - Peter will answer questions around all the different variables and interventions people can do in order to prevent cognitive and neurological decline.
  - He will dive into the most common exercise questions, which are a lot around zone 2, including questions around if females should be doing zone 2 training, as well as some VO2 max training questions.
  - Additionally, Peter will address questions related to body composition and diet, touching on exercise, fat loss, lean mass development, and the role of protein

## Understanding dementia risk: modifiable vs. non-modifiable contributors to cognitive decline [5:00]

For more check out: [#251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/)

\*\*\*

**Categories of Risk Factors**

*Non-Modifiable Risk Factors*

- Definition: Factors you cannot change, but they are important to acknowledge.
- Examples:
  - Age: Risk of cognitive decline increases monotonically with age (i.e., steadily, without plateau).
  - Sex:
    - Women have 2x the risk of Alzheimer’s compared to men.
    - Not fully explained by longer life expectancy.
    - Peter suspects sudden estrogen withdrawal during menopause may play a major role.
    - Possible link between HRT (Hormone Replacement Therapy) and reduced risk, but more data is needed.
  - Genetics:
    - Most notably, the APOE e4 genotype significantly increases Alzheimer’s risk.
    - Other genetic contributors exist as well.

*Modifiable Risk Factors*

- Definition: These are areas individuals can influence through lifestyle and health management.
- Key Modifiable Risks:
  - Obesity:
    - [Associated](https://onlinelibrary.wiley.com/doi/10.1111/j.1467-789X.2010.00825.x) with a 60% increase in relative risk for dementia.
    - Risk becomes more meaningful with age due to increasing baseline risk.
  - Type 2 Diabetes:
    - [Raises](https://jamanetwork.com/journals/jama/fullarticle/2779197) dementia risk by ~50%.
    - Risk increases with disease duration: every 5 years adds ~25% more risk.
  - Hypertension:
    - Also [raises](https://pmc.ncbi.nlm.nih.gov/articles/PMC11425581/) dementia risk by ~60%.
  - Dyslipidemia (High LDL cholesterol):
    - Each 1 mmol/L (≈40 mg/dL) [increase](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00150-1/fulltext) in LDL is linked to an 8–10% increase in all-cause dementia risk.

**Genetic Susceptibility & Interaction with Modifiable Risks**

- APOE e4 carriers are more vulnerable to the above modifiable risks.
- For example, a person with diabetes and APOE e4 has a [5.5x greater risk of dementia](https://diabetesjournals.org/diabetes/article/51/4/1256/34635/Type-2-Diabetes-APOE-Gene-and-the-Risk-for) compared to a diabetic without the APOE e4 variant.
- This shows gene-environment interaction—modifiable risks carry greater impact in genetically susceptible individuals.

**Summary of Prevention Strategy**

- Target metabolic health aggressively by optimizing:
  - Blood pressure → Target: ≤ 120/80 mmHg.
  - Lipid levels → Keep LDL and other harmful lipids as low as reasonably possible (with diminishing returns at very low levels).
  - Insulin sensitivity → Reduce insulin resistance through diet, exercise, and lifestyle interventions.

> *“If your objective is to prevent cognitive decline, . . .You want to be as metabolically healthy as possible and be as insulin sensitive as possible.”* —Peter Attia

## The causality between metabolic health and dementia [9:45]

***Are obesity, diabetes, and hypertension causal in dementia, or are they merely correlated?***

- Peter says that this is a critical question, and we assess it using the best tools available for human studies

**Tools to Determine Causality in Humans**

*Randomized Controlled Trials (RCTs)*

- Considered the gold standard for establishing causality.
- In the context of dementia:
  - There are RCTs directly targeting hypertension, diabetes, and hypercholesterolemia.
  - Many show reduced dementia risk as a primary or secondary outcome.
  - Even when the primary endpoint is something else (e.g., coronary artery disease), secondary benefits to cognitive health are often observed.

*Mendelian Randomization*

- Considered slightly weaker than RCTs.
- Uses genetic proxies to examine cause-effect relationships over a lifetime.
- Supports the idea that these risk factors (especially metabolic ones) contribute causally to cognitive decline.

**Mechanistic Support for Causality**

- Peter outlines biological pathways through which these conditions can plausibly cause dementia, strengthening the case beyond just statistical association:
  - **Hypertension** and **hypercholesterolemia** → Endothelial damage
  - **Diabetes** → Insulin resistance and glycation
  - All three contribute to:
    - Chronic inflammation
    - Oxidative stress
    - Amyloid plaque accumulation
    - Capillary dysfunction in the brain
- These mechanisms support plausibility and coherence, two pillars of causal inference in epidemiology.

**Interplay Between Conditions**

- Most people don’t have just one condition—e.g., diabetes is often accompanied by hypertension and dyslipidemia.
- Statistically separating each risk factor’s individual contribution is difficult.
- Peter’s takeaway: Don’t worry about comparing exact relative risk percentages (e.g., 55% vs. 60%). Instead:
  - Focus on managing all modifiable risks, since they often occur together and amplify overall risk.

**Evidence from Intervention Trials**

- Blood Pressure Control
  - Keeping systolic BP <120 mmHg:
    - Reduces risk of dementia and mild cognitive impairment even within 3–4 years.
    - Brain capillaries are especially vulnerable to hypertension-related damage.
    - See [SPRINT MIND](https://jamanetwork.com/journals/jama/fullarticle/2723256#google_vignette) trial
- Lipid Lowering
  - Even with statins (Peter’s “least favorite” lipid-lowering method):
    - 20% [reduction](https://www.nature.com/articles/s41598-018-24248-8#citeas) in all-cause dementia risk.
    - ~30% [reduction](https://academic.oup.com/eurjpc/article/29/5/804/6454065) in Alzheimer’s disease specifically.
    - These effects seen in RCTs with cardiovascular disease as primary endpoint.
- Diabetes treatment: A majority of studies suggest [metformin](https://clindiabetesendo.biomedcentral.com/articles/10.1186/s40842-024-00168-7/tables/2) reduces risk of dementia. Additionally, [GLP-1](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370%2824%2900268-2/fulltext#supplementary-material) agonists may provide a greater decrease in risk relative to DPP-4 inhibitors and sulfonylureas, perhaps due to the combination of glycemic control and weight loss.

***Summary Takeaway***

- Yes, there is strong evidence of causality, not just correlation, between cardiometabolic dysfunction and dementia.
- This evidence comes from:
  - RCTs, Mendelian randomization, and
  - Biological plausibility via mechanisms like endothelial damage and inflammation.

**Actionable conclusion**: Proactively manage blood pressure, lipid levels, and glucose metabolism to reduce long-term cognitive risk.

## How diet and exercise influence brain health: energy balance and exercise as key preventative tools [13:30]

***Can Diet and Exercise Prevent Cognitive Decline or Dementia?***

- Nick asks if diet or exercise, outside of obesity management, directly reduce dementia risk.
- Peter reframes the answer using three categories:
  - 1) Non-modifiable risk factors (already covered)
  - 2) Modifiable risk factors (nutrition plays a major role)
  - 3) Proactive interventions (exercise as the biggest one)

**The Role of Diet**

- Diet is key to managing modifiable metabolic risks:
  - Prevents obesity
  - Supports insulin sensitivity
  - Promotes energy balance
  - There is no “magical brain diet” proven to prevent dementia.
- Balanced Diet over Extremes
  - Extreme diets are harder to sustain and may negatively impact energy balance.
  - A balanced, sustainable diet is more effective at:
    - Preventing fat accumulation
    - Maintaining insulin sensitivity
- Potential Marginal Benefits
  - Though secondary to energy balance, some dietary characteristics may add value:
    - Higher monounsaturated fat intake may help more than saturated or polyunsaturated fats.
    - Antioxidant-rich foods may reduce inflammation and oxidative stress.
  - But these are “third- or fourth-order” benefits compared to energy balance, which is the “first-order” concern.

**The Role of Exercise**

- Exercise as the #1 Intervention for Brain Health
  - Exercise provides both direct and indirect neuroprotective benefits.

> “*The single largest and most important intervention one has for brain health is exercise*.” —Peter Attia

- Mechanisms of Exercise Impacting Brain Health
  - Exercise promotes neurotrophic and protective factors, including:
    - BDNF (Brain-Derived Neurotrophic Factor)
    - IGF-1 (Insulin-like Growth Factor 1)
    - Klotho (a longevity-related protein)
      - Check out [episode #303](https://peterattiamd.com/denadubal/) with Dena Dubal on klotho
  - These compounds support vascular, metabolic, and anti-inflammatory pathways, all relevant to Alzheimer’s risk.
- Exercise and Insulin Sensitivity
  - Exercise is crucial for:
    - Expanding glucose reservoirs (via building muscle)
    - Maintaining insulin sensitivity, a key factor in metabolic health
  - This makes exercise not only a brain booster but also a metabolic regulator.
- Relative Risk Reduction
  - Being inactive vs. active leads to a 40% relative [increase](https://publichealth.jhu.edu/2025/small-amounts-of-moderate-to-vigorous-physical-activity-are-associated-with-big-reductions-in-dementia-risk) in dementia risk.
    - Not quite as high as diabetes (50–60%), but still significant.
  - However, many studies are crude in categorizing activity levels, likely underestimating the true protective benefit of higher-intensity or consistent exercise.
    - The more detailed the exercise measurement, the greater the risk difference appears.

## Why combining aerobic, resistance, and cognitively engaging activities offers the most comprehensive benefits for preventing cognitive decline [17:00]

***Are Certain Exercises Better for Cognitive Health and Dementia Prevention?***

- Peter cautions against choosing a single exercise type based solely on its potential cognitive benefits.
- Both aerobic and resistance training are highly beneficial for:
  - Brain health
  - Overall health
  - Health span and longevity

[2022 Meta-Analysis](https://www.sciencedirect.com/science/article/pii/S209525462100051X) Findings

- A meta-analysis suggests:
  - Resistance training may be more effective than other modalities at slowing cognitive decline in people who already have mild cognitive impairment (MCI) or dementia.
  - Combined exercise programs (aerobic + resistance) outperform single-modality programs.

**Peter’s Strong Position**

- No hedging: People are always better off doing multiple exercise modalities.
- Benefits of combining exercise types:
  - Accretive effects on disease prevention
  - Greater reductions in all-cause mortality
  - Broader improvements in health span, not just cognition

> “*I feel very strongly saying this, I don’t need to hedge this statement. I think an individual is always going to be better off doing more modalities than fewer because not only are they getting accretive benefits on disease-specific issues, you’re going to see a greater reduction in all-cause mortality.*” —Peter Attia

**Why Resistance Training May Be Uniquely Helpful**

- Higher Cognitive Engagement
  - Resistance training demands more coordination and focus.
  - It activates the brain more than repetitive aerobic movements like cycling or jogging.
  - Cognitive load may contribute to its brain-health advantages.
- Comparable Intensity Consideration
  - If done at equal metabolic cost (same METs), resistance training:
    - Involves more intentional movement
    - Requires greater attention and strategy
    - May stimulate more neurocognitive pathways

**How to Enhance the Brain Benefits of Aerobic Activity**

- Choose aerobic exercises with complexity to increase cognitive involvement:
  - Shadowboxing
  - Fast-paced dancing
  - Basketball
  - Tennis
- These offer more mental stimulation than simple, repetitive exercises like jogging.

**Final Message: Do It All**

- The optimal approach for cognitive and overall health is to incorporate a mix of:
  - Cardio
  - Resistance training
  - Sports
  - General physical activity
- Variety creates synergistic benefits that exceed any single method.

## Additional lifestyle factors that influence dementia risk: smoking, head trauma, alcohol, and sleep [19:45]

**Smoking**

- Smoking is one of the clearest modifiable risk factors for dementia.
- Though the data are epidemiological (not randomized controlled trials), the association is strong: smoking is linked to a ~60% [increase](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0118333) in dementia risk.
- The likely mechanism is vascular: smoking causes endothelial damage, which is harmful to both cardiovascular and brain health.
- Because of its well-established harms, Peter emphasizes that this is an easy and obvious target—do not smoke.

**Head Trauma**

- Avoiding head injuries is another important preventive step, especially for younger individuals.
- Peter shares that he personally experienced a great deal of head trauma in his youth and cannot know how much cognitive damage it may have caused.
- While older adults may not need to worry about this directly, parents of teenagers should be mindful—particularly if they know their child may carry APOE e4, a gene associated with increased dementia risk.
- The takeaway: minimize activities with a high risk of repeated head injury, especially during developmental years.

**Alcohol**

- The belief that moderate alcohol consumption is protective for brain health is [largely a myth](https://peterattiamd.com/low-to-moderate-alcohol-consumption-and-longevity/).
- Studies showing a J-shaped curve (where modest drinkers appear to have lower risk than abstainers) are likely confounded by the fact that many abstainers are already in poor health.
- When these biases are corrected, even modest drinking appears [neutral](https://onlinelibrary.wiley.com/doi/full/10.1002/ijc.33917) or [harmful](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2790520) to brain health.
- Despite this, Peter admits that he enjoys alcohol and drinks 4–6 times a week, but with boundaries:
  - No more than two drinks in a day
  - Three alcohol-free days per week
  - No alcohol close to bedtime
- His recommendation: if alcohol means little to you, consider quitting entirely. If it brings you real enjoyment, enjoy it consciously and sparingly.
- Check out [AMA #31](https://peterattiamd.com/ama31/) and [AMA #68](https://peterattiamd.com/ama68/) for more on alcohol

**Sleep**

- Peter stresses that it’s surprising sleep hasn’t come up earlier in the conversation, given its significant [causal link to dementia risk](https://peterattiamd.com/matthewwalker1/).
- Inadequate sleep, especially less than 5 hours per night, is [associated](https://pmc.ncbi.nlm.nih.gov/articles/PMC7906211/) with over twice the risk of Alzheimer’s disease.
- He believes this connection is causal, as poor sleep often precedes cognitive decline rather than results from it.
- While the definition of “adequate sleep” can vary, Peter offers some practical guidance:
  - Spend 7.5 to 8 hours in bed
  - Aim for a sleep efficiency of around 85% (i.e., most of that time should be spent sleeping)
  - Avoid obsessing over sleep tracker data if you otherwise feel rested and maintain regular sleep habits
- He advises that if patients feel fine but their sleep trackers suggest otherwise, ignore the device and focus on subjective sleep quality.
- For those unsure if they’re truly rested, Peter suggests using simple sleep questionnaires to assess fatigue that might not be obvious.
  - [Fatigue Severity Scale (FSS)](https://www.mercy.net/content/dam/mercy/en/pdf/fatigue-severity-scale-epworth-sleepiness-scale-questionaire.pdf)
  - From the [episode of The Drive with Ashley Mason](https://peterattiamd.com/ashleymason/):
    - [The Pittsburgh Sleep Quality Index (PSQI)](https://www.sleep.pitt.edu/psqi)
      - [PSQI (pdf)](https://www.sleep.pitt.edu/sites/default/files/assets/Instrument%20Materials/PSQI-Instrument.pdf)
    - [Insomnia Severity Index (pdf)](https://www.med.upenn.edu/cbti/assets/user-content/documents/Insomnia%20Severity%20Index%20(ISI).pdf)

Resources on the importance of sleep and sleep hygiene:

- [7-part series with sleep expert Matthew Walker](https://peterattiamd.com/matthewwalker1/)
- Topics on website: [Sleep](https://peterattiamd.com/category/sleep/)

## The link between hearing loss and dementia: dose-dependent risk and the case for correction [25:15]

**Strong Link Between Hearing Loss and Dementia**

- Hearing loss shows a clear, dose-dependent [association](https://jamanetwork.com/journals/jamaneurology/fullarticle/802291) with dementia.
- Dose-dependency means: the more severe the hearing loss, the higher the relative risk of developing dementia.
  - Mild hearing loss is associated with a ~90% increase in dementia risk.
  - Severe hearing loss is linked to a ~400% increase in risk.
- Dose-response relationships are generally a strong indicator of potential causality, especially when the “dose” is measurable and objective — as it is with hearing (via audiograms).

*Hearing Is Easy to Measure Objectively*

- Peter points out that hearing is unlike nutrition, where people often can’t recall or report accurate amounts (e.g., “two pieces of bacon vs. four”).
- Because hearing levels are measured precisely and clinically, the dose-response here carries more credibility than other observational associations.

*Mechanistic Plausibility and Ongoing Research*

- There are plausible mechanisms explaining how hearing loss might contribute to cognitive decline (though not detailed here).
- However, the field is still in the early stages of conducting randomized controlled trials (RCTs) to test causality directly.
- The ideal RCT design would involve:
  - Identifying individuals at elevated risk of dementia (e.g., with mild cognitive impairment).
  - Randomizing them to receive either hearing correction (e.g., hearing aids) or no correction.
- But conducting these trials is ethically challenging, especially when early evidence strongly favors treatment.

**Clinical Recommendation: Correct Hearing Loss**

- Despite the lack of definitive RCTs, Peter recommends treating hearing loss as a “no-regret move.”
- Even if correcting hearing doesn’t reduce dementia risk, it undeniably improves quality of life.
- His clinical stance: All patients with hearing loss should have it corrected, regardless of their dementia risk.

## How poor oral hygiene may contribute to neuroinflammation and dementia risk [27:30]

**Importance of Oral Health**

- Peter emphasizes that oral hygiene is a key health priority, especially for his patients.
- In his clinical practice, daily flossing is expected — if a patient isn’t flossing, it’s considered a serious issue.

Inflammation from Poor Oral Hygiene

- When someone doesn’t floss for a while and then resumes, bleeding gums often occur.
  - This is a visible sign of inflammation, which is a key concern.
- Accumulated inflammation in the gums may have broader health consequences beyond oral discomfort.

Possible Link Between Oral Health and Dementia

- There is a hypothesis that periodontal disease may contribute to cognitive decline through:
  - Systemic inflammation (inflammation throughout the body).
  - Neurologic inflammation (inflammation affecting the brain).
  - Proximity of the mouth to the brain, which might allow bacteria or inflammatory compounds easier access to brain tissue.

Recommendation: Non-Negotiable Oral Hygiene

- Brush with an electric toothbrush at least twice daily.
- Floss every single day.
- Peter frames these habits as non-negotiable, regardless of whether they definitively lower dementia risk.
- Even if the link to dementia is ultimately weak, these habits can prevent dental emergencies (like root canals), which makes them well worth adopting.

\*For more on the importance of oral health, check out [episode #166 with Patricia Corby](https://peterattiamd.com/patriciacorby/)

## Supplements for brain health: which ones matter and when they’re worth considering [28:45]

**Framework for Thinking About Supplements**

- Peter begins with his standard approach to evaluating supplements:
  - Is the supplement being used to correct a deficiency?
  - Or is the goal to achieve supernormal levels?
- For more on this topic, check out [AMA #69: Scrutinizing supplements](https://peterattiamd.com/ama69/)

**Three Primary Nutrients That May Help (if Deficient)**

- These are low-impact, fifth-order interventions compared to earlier lifestyle factors.
- 1) Omega-3 Fatty Acids (EPA & DHA)
  - May have cognitive benefits if levels are low.
  - Ideal blood level: 8–10% of RBC membranes made up of EPA/DHA (measured via the [Omega-3 Index test](https://omegaquant.com/omega-3-index-basic/)).
  - Caveats:
    - Much of the data is epidemiologic (i.e., observational).
    - Could be a proxy for overall good nutrition.
    - RCTs are flawed because they dose without ensuring target levels are reached.
- 2) Vitamin D
  - Could be beneficial if correcting a deficiency.
  - RCT issues:
    - Most studies randomize by dose (e.g., 2,000 IU/day) rather than achieving optimal blood levels (e.g., 60–70 ng/mL).
    - Absorption varies widely between individuals.
    - Ideal trial would stratify by actual deficiency and treat to a target.
- 3) B Vitamins
  - May also be important in correcting deficiencies, but likely lower impact than Omega-3s or Vitamin D.
- **Key takeaway**: These supplements may help if you’re deficient, but are not substitutes for core lifestyle factors like exercise, sleep, diet, and metabolic health.

**Titanic Analogy**

- Taking supplements like omega-3s or B vitamins while ignoring bigger issues (e.g., poor diet, no exercise, hypertension) is like:
  - Worrying about your sunscreen brand while sinking on the Titanic.
  - Supplements are minor details in the broader picture of cognitive health.

**Additional Supplements Worth Considering (for Marginal Gains)**

- These are optional, possibly helpful for high-risk individuals who have already addressed the basics:
- 1) Creatine
  - May [enhance](https://pmc.ncbi.nlm.nih.gov/articles/PMC1691485/) short-term memory and fluid intelligence.
  - Effect likely greater in older adults and those who don’t eat much meat.
  - Mechanism: assists with phosphate transfer, similar to ATP.
- 2) Curcumin (from turmeric)
  - Anti-inflammatory.
  - Theracurmin is a recommended high-bioavailability brand.
  - Data is modest, but could be a small boost if already doing everything else right.
- 3) Magnesium L-threonate (Magtein)
  - Designed to enhance brain magnesium levels.
  - Sparse human data, but may help with sleep and potentially brain health.
  - Expensive and not strongly supported yet, but possibly worth trying for those optimizing every detail.

## Low LDL cholesterol and brain health: debunking the myth of cognitive risk [33:45]

***Does Low LDL Cholesterol Harm Brain Health?***

*Common Concern*

- Many people fear that very low LDL levels might impair cognition or brain function.
- Social media influencers often claim that high cholesterol is good for the brain, or that lowering it is dangerous.

*Peter’s Clear Position*

- Scientific evidence is strong:
  - LDL levels as low as 30 mg/dL do not impair brain function.
  - In fact, dementia risk declines as LDL falls, at least down to this threshold.

*Why the Myth Persists (and Why It’s Wrong)*

- Argument for the myth:
  - Cholesterol is vital for nerve and brain function.
  - People assume that lowering cholesterol in the blood means starving the brain of cholesterol.
- Peter’s rebuttal (4 key facts):
  - 1) Blood cholesterol is a small part of total body cholesterol
    - Blood serum cholesterol (LDL + HDL + VLDL) represents only 5–10% of your body’s total cholesterol pool.
    - Even if you eliminated all cholesterol from the blood (which isn’t feasible), you’d still retain 90% of total cholesterol elsewhere in the body.
  - 2) The brain makes its own cholesterol
    - The brain is a closed system in terms of cholesterol—it doesn’t rely on cholesterol from the bloodstream.
    - It synthesizes and regulates its own supply.
  - 3) LDL-lowering drugs don’t affect brain cholesterol
    - PCSK9 inhibitors, among the most potent LDL-lowering drugs, cannot cross the blood-brain barrier.
    - Therefore, they don’t touch the brain’s cholesterol pool.
  - 4) Children thrive on very low LDL levels
    - Children naturally have LDL levels below 30 mg/dL, yet their brains develop just fine.
    - This directly undermines the idea that low LDL is inherently harmful to cognitive development.

**Final Conclusion**

- The brain protects and manages its own cholesterol supply.
- LDL levels as low as 30 mg/dL are either protective or neutral in terms of cognition.
- A recent [study](https://jnnp.bmj.com/content/early/2025/03/21/jnnp-2024-334708) found a plateau in dementia risk reduction at 30 mg/dL, with no further benefit below that level. ([article about the study](https://www.news-medical.net/news/20250401/Study-links-low-LDL-C-levels-to-reduced-risk-of-dementia.aspx?utm_source=chatgpt.com))
- The claim that higher LDL protects brain health is not only false—it’s potentially dangerous.

## How to approach zone 2 training: the importance of staying in zone 2 and tailoring intensity based on your time and goals [38:00]

***How Strict Should You Be with Zone 2 Training?***

- S*hould you avoid slipping into Zone 3 during a Zone 2 workout? Does it ruin the effectiveness of the session*?

**Peter’s Framework**: Context Matters

Peter compares two scenarios:

- A. High-volume athlete (Peter 10 years ago / pro cyclists):
  - Rode 14–20 hours a week, ~75–80% in Zone 2.
  - Didn’t stress about dipping in and out of zones during rides (e.g., pushing into Zone 3 on hills, dropping into Zone 1 on descents).
  - Total time spent in Zone 2 was so high that minor variations didn’t matter.
  - This is common among elite or high-volume endurance athletes.
- B. Time-constrained person (Peter today):
  - Exercises ~3–4 hours a week, much less than before.
  - Zone 2 now serves a different purpose:
    - Not training to be a better cyclist.
    - Using it to improve mitochondrial function and longevity.
  - With limited time, Peter wants every minute of a 45-minute workout to be as effective as possible.
  - So he strictly avoids slipping into Zone 1 or 3:
    - Zone 1 = not enough stimulus.
    - Zone 3+ = shifts toward glycolysis, not fat oxidation.
  - He treats Zone 2 training almost like “medicine” for metabolic health.

**Practical Application**: What Should You Do?

- Peter says to self-assess:
  - Are you more like him now, with limited time and an interest in healthspan?
  - Or are you like a competitive athlete with hours to train?

*What If You Drift Out of Zone 2 Mid-Workout?*

- If your heart rate drifts into Zone 3 briefly, is the workout ruined?
  - No, not at all.
  - The goal is consistency, not perfection.
  - A brief dip or spike is normal and doesn’t invalidate the session.
  - Even a full Zone 1 workout is better than no workout at all.

**Final Advice on Cardio Allocation**

- If you only have ~4 hours per week for cardio:
  - Spend 80% of it in Zone 2.
  - Spend the remaining 20% in VO2 max (Zone 5) work.
  - Other modalities aren’t bad—but they’re less efficient at building mitochondrial capacity and longevity benefits compared to this mix.

## Lactate testing for zone 2: clinical protocols and at-home approaches [43:00]

***If someone wants to test lactate instead of relying on heart rate or perceived exertion (RPE), what’s the best protocol? Should you test during the workout, after the session, or after a cooldown?***

- Peter says it depends on your goal
- There are two approaches—one clinical and precise, the other practical and home-based.

**Clinical Method** (Used at His Practice and [10 Squared](https://10squared.com/))

- VO2 Max Test First:
  - Clients first undergo a VO2 max test to establish baseline fitness and oxygen consumption capacity.
- Estimate Zone 2 Target:
  - From VO2 data and respiratory quotient (RQ), they can identify the individual’s point of maximum fat oxidation—this generally occurs at ~65–70% of VO2 max in reasonably fit individuals.
  - Example:
    - A person with a VO2 max of 4.0 L/min likely has zone 2 around 2.7–2.8 L/min.
    - That becomes their target zone during next-day testing.
- Three-Way Validation (“Triple Convergence”):
  - Lactate Level: Should be between 1.7 and 2.0 mmol/L.
  - Perceived Exertion (RPE): Matched to expectations.
    - Watch this [video](https://www.youtube.com/watch?v=Qdop-xHnUOk) of Peter explaining RPE
  - Fat Oxidation: Confirmed via RQ data from metabolic cart.
- Note: Testing RPE is tricky when wearing a mask during cardiopulmonary testing.

**At-Home “Dirty” Method** (Peter’s Old Routine)

- Peter used to do this setup on a stationary bike with a nearby station containing:
  - Soap and water (alcohol doesn’t clean lactate well)
  - Lactate strips, a meter, lancet (poker), and towel.
- Protocol:
  - Ride at a given wattage (e.g., 180 watts) for ~15 minutes.
  - Clean and test lactate mid-ride.
  - If lactate is too low (e.g., <1 mmol/L), increase wattage and repeat in 6-minute increments.
  - Repeat until lactate is in the 1.7–2.0 mmol/L range—indicating zone 2 effort.

**Peter’s Current Approach**

- He no longer tests during the session.
- Now, he just does one lactate check at the end of the workout, even though it’s not necessary.
- Why? Purely out of habit and personal interest—not because he needs the data.

**Takeaway**:

- For precision, you can triangulate zone 2 using VO2 max, RPE, and lactate.
- For practical use, simply testing once mid- or post-ride for a 1.7–2.0 mmol/L lactate reading is often enough.
- Ultimately, consistency in zone 2 training matters more than perfect lactate tracking.

## Combining modalities in zone 2 training: balancing enjoyment and efficiency [47:00]

***If someone does three 60-minute zone 2 sessions a week, is it okay to split a single session into different modalities—like 30 minutes cycling and 30 minutes running—or does that reduce the effectiveness of the workout?***

- Peter emphasizes consistency and enjoyment over perfection
- While mixing modalities might slightly reduce the physiological adaptation compared to sticking with a single modality for the full session, the benefit of enjoying the workout and not missing sessions outweighs any potential downside.
- If doing 20 minutes each on a bike, rowing machine, and treadmill keeps you engaged—go for it.
- No formal study has tested whether mixed-modality zone 2 training is less effective, but his intuition says it probably is “technically” less optimal.
- However, adherence is the bigger win, so variety is welcomed if it keeps you consistent.

Practical Considerations by Modality:

- Cycling and Inclined Treadmill Walking:
  - Easier for most people to stay within zone 2 (i.e. low lactate levels and heart rate).
- Rowing and Running:
  - Much harder for average individuals to stay in zone 2 because they may quickly exceed the heart rate or lactate thresholds unless they’re highly efficient at the movement.
- Personal Example:
  - Peter’s wife can easily stay in zone 2 while running because of her elite fitness (sub-3:30 marathoner).
  - Peter admits he’s not an efficient runner, so zone 2 running is harder for him.

**Takeaway**:

Mixing modalities is totally fine—especially if it helps you enjoy the workout and stay on track long-term. Just be aware that some activities (like running or rowing) may make it harder to truly stay in zone 2 unless you’re well-trained.

## Zone 2 training for women: addressing the misconception that zone 2 training is unnecessary or ineffective for postmenopausal women [49:30]

***Is zone 2 training beneficial for women, particularly those who are perimenopausal or post-menopausal, given their unique hormonal shifts and metabolic changes?***

- Yes, zone 2 is still valuable for women
- Peter pushes back on a growing myth—often fueled by social media—that post-menopausal women should avoid zone 2 training. He tries to steel man the opposing argument before refuting it:
  - The argument against zone 2 goes like this:
    - Women tend to have more type 1 (oxidative) muscle fibers, better fat oxidation, and more efficient mitochondria than men.
    - Therefore, they might gain less marginal benefit from zone 2 training.
    - Meanwhile, estrogen and testosterone declines after menopause cause anabolic resistance, making resistance training more important to preserve type 2 fibers and lean mass.
  - Peter agrees that resistance training is essential for post-menopausal women.

*But It’s Not Either/Or*:

- Peter emphasizes that a well-rounded fitness plan must include both resistance and aerobic training.
  - Framing it as a zero-sum decision (i.e., only zone 2 or only strength work) is unhelpful.
- If a woman could only train one hour per week, then yes, resistance training might take priority.
- But ideally, Peter would advocate for more than one hour so that both modalities can be included.

**Takeaway**: Zone 2 training is still important for women—even post-menopause. While resistance training is critical due to age-related hormonal changes and muscle loss, aerobic fitness shouldn’t be sacrificed. The best path forward is doing both, not choosing between them.

## Effective strategies for VO₂ max training: short vs. long intervals [51:45]

**Do shorter intervals (under 3 minutes) help improve VO₂ max, or is it necessary to stick with the 3–8 minute interval recommendation?**

- Short Intervals Can Help, But Longer Ones Are More Efficient
- Short intervals, like those used in a Tabata protocol (e.g., 20s on / 10s off for 4 minutes total), do improve VO₂ max, especially for those doing no other training.
- Even zone 2 training can provide some benefit to VO₂ max, acting as a very long, low-intensity interval.
- However, the most efficient way to improve VO₂ max is by doing 3–8 minute intervals at high intensity.

**Why 3–8 Minutes Is Optimal**:

- To increase VO₂ max, the body must spend time near its current VO₂ max, typically ≥90% of VO₂ max capacity.
- Shorter intervals may be too intense, causing the body to overshoot VO₂ max and rely more on glycolysis before sufficient VO₂ max engagement is reached.
- Longer intervals (e.g., 20 minutes) are too mild—you’re working hard, but not hard enough to push VO₂ max adaptations.
- Peter compares both extremes and explains:
  - Short intervals = not enough time near VO₂ max.
  - Long intervals = not enough intensity.

\*See [Andrew Coggan](https://www.peakscoachinggroup.com/DrAndrewCoggan)’s [work](https://www.trainingpeaks.com/blog/power-training-levels/) on cycling and FTP (Functional Threshold Power) as well as his work on the power-duration model and TrainingPeaks “Power Zones”

**Practical Training Guidance**:

- Interval Length: 3 to 8 minutes.
- Work-to-Rest Ratio: 1:1. (If you go hard for 4 minutes, rest for 4 minutes at very low intensity.)
- Perceived Effort:
  - Minute 1: Manageable
  - Minute 2: Starting to hurt
  - Minute 3: Entering the “pain cave”
  - Minute 4: Total exhaustion
- If you’re crushed by the end of the interval and can barely pedal/walk during the recovery—you did it right.
- If you feel fine at the end, you didn’t go hard enough.
- Peter uses RPE (rate of perceived exertion) and power output rather than heart rate, which lags and isn’t as responsive in the moment.

**\*Final Note**: VO₂ max training is more art than exact science. The feel of the session is critical. You’ll get better at gauging effort through experience, and the right stimulus comes from both intensity and sustained time at that intensity.

## The benefits of post-meal walking for glucose management, and why spikes in glucose during exercise aren’t harmful [56:45]

***Does walking after meals help regulate blood sugar, and how should people interpret glucose spikes during or after exercise?***

- Peter says that post-meal walking can help and here’s why:
  - After eating, especially carbohydrate-heavy meals, blood glucose rises.
  - The body clears glucose into muscles via two key mechanisms:
    - 1) Insulin-dependent: Insulin triggers GLUT transporters to shuttle glucose into muscle cells.
    - 2) Insulin-independent: Muscle contraction alone—even light activity like walking—also drives GLUT transporters to the muscle surface and enhances glucose uptake.
      - Because of that second mechanism, light movement like walking after meals helps clear glucose from the blood even without needing as much insulin.
  - “Walking isn’t magic,” Peter says, but it’s effective, simple, and socially practical after dinner—more so than hopping on a bike, even though more intense activity would clear more glucose.

***What About Glucose Spikes During Exercise?***

- Peter confirms that glucose spikes during intense exercise are normal and not a cause for concern.
- This happens because:
  - The liver releases glucose in anticipation of increased energy demand (ATP needs).
  - It’s a healthy and expected physiologic response—not a sign of metabolic dysfunction.

***Should People Worry About Any Glucose Spike?***

- No, not in isolation.
- Occasional high glucose from a meal (e.g., 170 after birthday cake) or intense exercise (e.g., 150 during intervals) is not harmful by itself.
- What matters is the frequency and pattern of spikes—e.g., regular spikes above 140–150 from daily meals would warrant closer attention.
- “Don’t panic about one spike—look at the overall pattern,” Peter says.
- Importantly, exercise-related spikes are excluded from concern, because they reflect healthy metabolic flexibility and are driven by a different mechanism than post-meal spikes.

## The role of stability training in supporting resistance work and healthy aging [1:00:15]

***Peter has often talked about the importance of building up lean mass to prevent age-related muscle loss. But how important is stability training to prevent age-related muscle loss versus just pure resistance training?***

- Resistance training and sufficient protein intake are very important for building muscle and combating age-related muscle loss.
- But stability training is necessary to support resistance training in the sense that it allows you to undertake load-bearing exercise safely.
- Stability training is the thing you want to be doing to ensure that you can load yourself safely because that’s what’s going to prevent muscle loss.
- It’s also important to understand that anything you’re doing that’s improving stability is also improving mobility (very important for health span despite it being harder to measure and link to longevity)

> “*We can just see empirically that all the strength in the world, if it doesn’t come with reasonable mobility, is going to be somewhat limiting at a minimum in quality of life.*” —Peter Attia

## Adapting strength training to manage chronic back injuries and train for longevity [1:02:00]

See [Episode of The Drive with Sean Mackey](https://peterattiamd.com/seanmackey/)

\*\*\*

***What specific changes did Peter make to strengthen his back and avoid re-injury following his past spinal surgeries?***

- Peter’s severe back injury happened over 25 years ago, but it still shapes his training today.
- Despite surgical repairs, he acknowledges he’s “not playing with a full deck” and must remain vigilant indefinitely to live pain-free and active.

*Some of the adjustments he’s made over time*

- Stopped Running:
  - Peter used to enjoy running, especially outdoors or while traveling.
  - However, he decided in 2016 to stop running, even though it never directly hurt his back.
  - The main reason: he felt too heavy at 180 lbs to run without risk.
  - He notes others might argue that “better technique” could help—but for him, it’s not worth the risk.
- Phased Out Heavy Deadlifting:
  - Deadlifting was Peter’s favorite lift growing up and his strongest movement.
  - He continued doing it for years—often feeling better afterward, but occasionally it would “lock him up” for up to two weeks.
  - The injury wasn’t debilitating, but the flare-ups of tight QLs and erector spinae led him to reconsider.
  - About a year or so ago, he stopped deadlifting entirely to minimize risk, despite enjoying the exercise.
- What He Does Instead
  - Peter still lifts heavy, but avoids axial loading:
    - Uses belt squats (which offload the spine).
    - Hack squats, barbell lunges, Cossack squats — but with lighter weights.
    - Focuses on single-leg movements with dumbbells.
  - These provide strength benefits with less strain on the spine.

Broader Philosophy

- It’s about understanding your own body and playing the long game.
- For Peter, longevity and function outweigh short-term enjoyment or ego lifting.
- His mindset: trade a few things now (like heavy deadlifts) to protect against re-injury and long-term disability.

## The role of aerobic exercise (like zone 2) in fat loss, metabolic health, and weight maintenance [1:06:30]

***If someone wants to use cardio—specifically zone 2—to lose fat, what should they consider? Is it as simple as hopping on a treadmill or bike?***

- Peter’s Key Clarification: Zone 2 Is Not for Fat Loss
- Zone 2’s primary purpose is to improve mitochondrial function and aerobic efficiency, not to improve body composition.
- It’s a foundational piece of a well-rounded fitness program, which also includes:
  - VO2 max (peak aerobic output)
  - Resistance training
  - Mobility and stability work

**Why Exercise Alone Won’t Make You Lose Fat**

- The body resists fat loss through strong compensatory mechanisms, including:
  - Increased appetite
  - Other behavioral and metabolic shifts
- As a result, exercise by itself isn’t an effective driver of fat loss.
- That said, exercise is critical for health and fat-loss maintenance, even if it’s not the initial driver of shedding pounds.

> “*So as important as exercise is for health, it turns out it is not the prime lever for fat loss because the body will defend against fat loss and energy imbalance through compensation very aggressively.*” —Peter Attia

**Why You Still Need to Exercise During Fat Loss**

- Peter emphasizes three reasons exercise is still essential:
  - Improves insulin sensitivity
  - Increases metabolic flexibility
  - Helps preserve and build lean mass
- These effects are vital for long-term success, even if they don’t directly cause weight to drop.
- The data suggest that exercise doesn’t really help you lose weight, but it does help you **maintain weight loss**
  - And therefore, you might as well begin the process of exercise during the weight loss phase so that the system is in place when you’ve achieved weight loss and that you have a better chance of maintaining it.

*What is Metabolic Flexibility?*

- Metabolic flexibility is the body’s ability to switch efficiently between burning fat and glucose depending on the energy demand.
- In a metabolically healthy person:
  - At rest (like during a podcast), the body should burn mostly fat.
  - If you’re burning glucose at rest, it suggests metabolic dysfunction.

**The Role of Resistance Training**

- As you lose fat, your body is at risk of also losing lean muscle.
- Resistance training blunts muscle loss and helps:
  - Improve glucose storage (via more muscle mass)
  - Boost insulin sensitivity
  - Enhance overall health and appearance

**Long-Term Benefit: Weight Maintenance**

- [Studies](https://pubmed.ncbi.nlm.nih.gov/34283417/) show that those who maintain weight loss are more likely to be exercising regularly.
- While causality is murky (e.g., maybe more motivated people also happen to exercise), the pattern is strong enough to reinforce the recommendation:
  - Start exercising early in the fat-loss process, so the habit is in place when it matters most.

## Debunking the “fast vs. slow metabolism” myth: why energy balance and protein matter most for fat loss [1:09:45]

***How should people think about calorie needs for fat loss if they believe they have a “fast” or “slow” metabolism?***

- Peter’s Core Insight: Fat Loss Is About Energy Balance
  - Fat loss or gain depends on energy balance—calories in vs. calories out.
  - If energy intake equals energy expenditure (considering activity, lean mass, and age), weight remains stable.
  - The common belief in having a “fast” or “slow” metabolism is largely unsupported by evidence.

**Myth-Busting the “Fast Metabolism” Idea**

- Peter himself used to believe he had a fast metabolism because he could eat more than others without gaining weight.
- However, when adjusting for lean body mass, activity levels, and age, there’s [no strong evidence](https://www.science.org/doi/10.1126/science.abe5017) that some people naturally burn significantly more calories than others.
  - A PubMed [study](https://pubmed.ncbi.nlm.nih.gov/2243122/) on resting muscle metabolism found BMR differences across individuals after adjusting for fat-free mass, fat mass, age, and sex. However:
    - These differences were relatively small.
    - They arose more from variations in muscle metabolism, not systemic metabolic speed differences.
  - Broad [reviews](https://www.health.harvard.edu/does-metabolism-matter-in-weight-loss?utm_source=chatgpt.com) show that once you account for lean mass and age, residual variation in BMR is limited—typically the unexplained portion is around 10–30%, much of which is just measurement noise

**The Real Explanation Behind “Eating Little but Not Losing Weight”**

- Peter acknowledges this still feels counterintuitive, especially when observing people who claim to eat little and not lose weight.
- A possible explanation: compensatory mechanisms, where the body subtly reduces energy expenditure (e.g., through reduced spontaneous movement or metabolic shifts).

Follow-Up Question: *Does Food Type (Macros) Matter?*

- Yes—macronutrient composition plays a supporting role, even if calorie balance remains the primary factor:
  - Protein and fat tend to:
    - Increase satiety
    - Require more energy to digest (higher thermic effect)
  - Refined carbs can:
    - Stimulate appetite
    - Make it easier to overeat
- Bottom line: If you’re not getting enough protein while trying to lose weight, you’re undermining your effort.

## Lean mass vs. body fat: why both matter for health and longevity [1:12:15]

***Is it more important to increase lean mass or decrease body fat percentage? How should we prioritize these goals?***

- Both lean mass and fat mass matter greatly, and you can’t reduce this to a “which is more important” question.
- Peter pushes back against oversimplification, emphasizing that optimal health requires a balance — not being excessively fat or deficient in muscle.

*Illustrative Examples to Show the Extremes*:

- Anorexia nervosa: Very low body fat, but dangerously low lean mass → Not healthy.
- Morbid obesity (e.g., 400 lbs, 50% fat): High lean mass and excessive fat → Also not healthy.
- These show that focusing on only one side of the equation (muscle or fat) misses the point.

**Key Mortality Data – Age Matters**:

- Under age 60:
  - Being in the top 20% for body fat [increases](https://onlinelibrary.wiley.com/doi/10.1002/jcsm.12921) all-cause mortality more than being in the bottom 20% for lean mass.
- Over age 60:
  - This relationship flips — muscle mass becomes even more protective.
- Known as the “obesity paradox”, where older individuals with slightly higher fat might do better, possibly due to:
  - Greater metabolic reserves
  - Reverse causality (e.g., illness leading to leanness)

**Peter’s Practical Takeaway**: Aim for the Middle Ground

- Avoid:
  - Being in the top 50% for fat mass
  - Being in the bottom 50% for muscle mass
- This is an achievable and meaningful goal for almost everyone, regardless of genetics or starting point.
- He doesn’t expect perfection (e.g., top 10% muscle / bottom 10% fat), but the median thresholds are realistic and clinically relevant.

## How protein intake impacts muscle mass and why pairing it with resistance training is significantly more effective [1:15:15]

***Can increasing daily protein intake alone improve muscle mass or retention even without also increasing activity or resistance training?***

- Protein helps — but not nearly as much without resistance training
  - Yes, amino acids (protein) can stimulate muscle protein synthesis (MPS) even in the absence of exercise.
  - However, the effect is significantly smaller than when protein is paired with resistance training.
  - This combination of exercise and protein intake is synergistic, meaning the results are better together than either alone.

*Memorable Analogy (via* [*Luc van Loon*](https://peterattiamd.com/lucvanloon/)*)*:

- Protein (amino acids) = bricks
- Muscle-building machinery = bricklayers
- Amino acids (bricks) can call the bricklayers (stimulate MPS), but they build more effectively when exercise is involved — like having a construction site with both materials and active workers.

**Age-Related Challenge: Anabolic Resistance**

- As we age, we become less responsive to the muscle-building signals from protein — known as anabolic resistance.
- But, as we learned in the [podcast with Luc van Loon](https://peterattiamd.com/lucvanloon/), this might be less due to aging itself and more due to inactivity.
- Meaning: older adults can still build muscle if they maintain regular resistance training alongside adequate protein intake.

**Practical Recommendation**:

- For best results:
  - Consume 1.6–2.0 grams of protein per kg of body weight per day
  - Pair that intake with resistance training
- This combination improves:
  - Muscle protein synthesis
    - Resistance exercise [increases](https://www.sciencedirect.com/science/article/pii/S1279770723018729?via%3Dihub#fig3) muscle protein synthesis by an additional ~50% over just a meal containing 90g of protein alone
  - Lean mass levels
    - In a [meta-analysis](https://www.sciencedirect.com/science/article/pii/S0002916523029271?via%3Dihub#f2) from Luc van Loon, protein supplementation added an additional 0.69 kg (95% CI =0.47-0.91 kg) of fat-free mass when combined with resistance exercise compared to resistance exercise alone.
  - Prevention of age-related muscle loss

---

## Selected Links / Related Material

**Previous AMA episode of The Drive discussing brain health**: [#251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/) | (peterattiamd.com) [5:00]

**Obesity is associated with about a 60% increase in the risk of dementia**: [Body mass index in midlife and late-life as a risk factor for dementia: a meta-analysis of prospective studies](https://onlinelibrary.wiley.com/doi/10.1111/j.1467-789X.2010.00825.x) (Anstey et al., 2011) [7:30]

**Diabetes increases the risk of dementia by about 50%**: [Association Between Age at Diabetes Onset and Subsequent Risk of Dementia](https://jamanetwork.com/journals/jama/fullarticle/2779197) (Amidei et al., 2021) [8:00]

**hypertension increases the risk of dementia by about 60%**: [Association between blood pressure and dementia in older adults: a cross-sectional study from China](https://pmc.ncbi.nlm.nih.gov/articles/PMC11425581/) (Yi et al., 2024) [8:00]

**High LDL cholesterol and dementia—For every one millimole per liter increase in LDL cholesterol, which is about a 40 milligram per deciliter increase, that’s about an 8 to 10% increase in all-cause dementia**: [Blood cholesterol and risk of dementia in more than 1·8 million people over two decades: a retrospective cohort study](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00150-1/fulltext) (Iwagami et al., 2021)[8:00]

**An APOE e4 carrier versus a non-e4 carrier, both of whom have diabetes, will show a significant increase in risk (5.5x) for the APOE e4 carrier**: [Type 2 Diabetes, APOE Gene, and the Risk for Dementia and Related Pathologies: The Honolulu-Asia Aging Study](https://diabetesjournals.org/diabetes/article/51/4/1256/34635/Type-2-Diabetes-APOE-Gene-and-the-Risk-for) (Peila et al., 2002) [8:45]

**Trials showing that systolic blood pressure below 120 millimeters per mercury (or even below 140) lowers the risk of dementia over a relatively short timeline (3-4 years) as well as lowers mild cognitive impairment**: [Effect of Intensive vs Standard Blood Pressure Control on Probable Dementia](https://jamanetwork.com/journals/jama/fullarticle/2723256#google_vignette) (The SPRINT MIND Investigators for the SPRINT Research Group, 2019) [12:15]

**Lipid lowering with statins are associated with a 20% decrease in the risk of dementia**: [13:00]

- 20% reduction in all-cause dementia risk: [Use of statins and the risk of dementia and mild cognitive impairment: A systematic review and meta-analysis](https://www.nature.com/articles/s41598-018-24248-8#citeas) (Chu et al., 2018)
- ~30% reduction in Alzheimer’s disease specifically: [Statin use and risk of dementia or Alzheimer’s disease: a systematic review and meta-analysis of observational studies](https://academic.oup.com/eurjpc/article/29/5/804/6454065) (Olmastroni et al., 2022)

**Episode of The Drive with Dena Dubal that discussed the promise of klotho**: [#303 – A breakthrough in Alzheimer’s disease: the promising potential of klotho for brain health, cognitive decline, and as a therapeutic tool for Alzheimer’s disease | Dena Dubal, M.D., Ph.D.](https://peterattiamd.com/denadubal/) | Peter Attia (peterattiamd.com) [15:45]

**Being inactive vs. active leads to a 40% relative increase in dementia risk**: [Small Amounts of Moderate to Vigorous Physical Activity Are Associated with Big Reductions in Dementia Risk](https://publichealth.jhu.edu/2025/small-amounts-of-moderate-to-vigorous-physical-activity-are-associated-with-big-reductions-in-dementia-risk) | (jhu.edu) [16:30]

**A 2022 meta analysis that suggests resistance training is somewhat more effective in slowing cognitive decline than other modalities amongst individuals that already have MCI or dementia**: [Comparative efficacy of various exercise interventions on cognitive function in patients with mild cognitive impairment or dementia: A systematic review and network meta-analysis](https://www.sciencedirect.com/science/article/pii/S209525462100051X) (Huang et al., 2022) [17:30]

**Smoking comes with about a 60% increase in the risk of dementia**: [Smoking Is Associated with an Increased Risk of Dementia: A Meta-Analysis of Prospective Cohort Studies with Investigation of Potential Effect Modifiers](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0118333) (Zhong et al., 2015) [20:00]

**Peter’s resources on the topic of alcohol**: [21:15]

- *Premium newsletter*: [Is low-to-moderate alcohol consumption beneficial for longevity?](https://peterattiamd.com/low-to-moderate-alcohol-consumption-and-longevity/) | Peter Attia (peterattiamd.com)
- *AMAs on this topic*:
  - [#193 – AMA #31: Heart rate variability (HRV), alcohol, sleep, and more](https://peterattiamd.com/ama31/) | Peter Attia (peterattiamd.com)
  - [#336 – AMA #68: Fasting, well-balanced diets, alcohol, exercise for busy people, wearables, emotional health, assessing cardiovascular health, and more](https://peterattiamd.com/ama68/) | Peter Attia (peterattiamd.com)

**Sleep surveys/questionnaires where you can get a sense of your sleep quality**: [24:00]

- [Fatigue Severity Scale (FSS)](https://www.mercy.net/content/dam/mercy/en/pdf/fatigue-severity-scale-epworth-sleepiness-scale-questionaire.pdf)
- From the [episode of The Drive with Ashley Mason](https://peterattiamd.com/ashleymason/):
  - [The Pittsburgh Sleep Quality Index (PSQI)](https://www.sleep.pitt.edu/psqi)
    - [PSQI (pdf)](https://www.sleep.pitt.edu/sites/default/files/assets/Instrument%20Materials/PSQI-Instrument.pdf)
  - [Insomnia Severity Index (pdf)](https://www.med.upenn.edu/cbti/assets/user-content/documents/Insomnia%20Severity%20Index%20(ISI).pdf)

**People sleeping less than five hours per night consistently more than doubles the risk of Alzheimer’s disease**: [Examining sleep deficiency and disturbance and their risk for incident dementia and all-cause mortality in older adults across 5 years in the United States](https://pmc.ncbi.nlm.nih.gov/articles/PMC7906211/) (Robbins et al., 2021) [24:30]

**Resources about sleep hygiene**: [24:45]

- [7-part series with sleep expert Matthew Walker](https://peterattiamd.com/matthewwalker1/)
- Topics on website: [Sleep](https://peterattiamd.com/category/sleep/)

**Hearing loss shows a clear, dose-dependent association with dementia**: [Hearing Loss and Incident Dementia](https://jamanetwork.com/journals/jamaneurology/fullarticle/802291) (Lin et al., 2011) [25:15]

**Mild hearing loss shows about a 90% relative risk of dementia, whereas those with severe hearing loss, it’s a 400% increase in the risk of dementia**: [Hearing Loss and Incident Dementia](https://jamanetwork.com/journals/jamaneurology/fullarticle/802291) (Lin et al., 2011) [26:15]

**Episode of The Drive about oral health**: [#166 – Patricia Corby, D.D.S.: Importance of oral health, best hygiene practices, and the relationship between poor oral health and systemic disease](https://peterattiamd.com/patriciacorby/) | Peter Attia (peterattiamd.com) [27:30]

**AMA episode of The Drive about how to evaluate supplements**: [#340 – AMA #69: Scrutinizing supplements: creatine, fish oil, vitamin D, and more—a framework for understanding effectiveness, quality, and individual need](https://peterattiamd.com/ama69/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com)) [28:45]

**An at-home test to get your Omega-3 blood levels**: [Omega-3 Index](https://omegaquant.com/omega-3-index-basic/) | (omegaquant.com) [29:30]

**Evidence to suggest creatine leads to a modest but statistically significant positive effect on short-term memory and fluid intelligence**: [Oral creatine monohydrate supplementation improves brain performance: a double-blind, placebo-controlled, cross-over trial.](https://pmc.ncbi.nlm.nih.gov/articles/PMC1691485/) (Rae et al., 2003) [32:00]

**A recent study found a plateau in dementia risk reduction at LDL levels of 30 mg/dL, with no further benefit below that level**: [Low-density lipoprotein cholesterol levels and risk of incident dementia: a distributed network analysis using common data models](https://jnnp.bmj.com/content/early/2025/03/21/jnnp-2024-334708) (Lee et al., 2024) [37:00]

**Peter’s video explaining rate of perceived exertion (RPE)**: [Why rate of perceived exertion (RPE) is the best metric for identifying Zone 2 training](https://www.youtube.com/watch?v=Qdop-xHnUOk) | Peter Attia, MD (youtube.com) [43:00]

**Andy Coggan’s work**: [Cycling Power Zones Explained](https://www.trainingpeaks.com/blog/power-training-levels/) | Andrew Coggan, Ph.D. (trainingpeaks.com) [55:00]

**Episode of The Drive with Sean Mackey where Peter discussed his back pain**: [#345 ‒ Chronic pain: pathways, treatment, and the path to physical and psychological recovery | Sean Mackey, M.D., Ph.D.](https://peterattiamd.com/seanmackey/) | Peter Attia (peterattiamd.com) [1:01:45]

**Data that suggests that if you look at two groups of people who have lost weight where one exercises and one doesn’t, the ones who exercise have an easier time with weight maintenance**: [Physical Activity and Weight Loss Maintenance](https://pubmed.ncbi.nlm.nih.gov/34283417/) (Balfour and Boster, 2023) [1:09:15]

**It seems to be a bit of a fallacy that some people have faster or slower metabolisms**: [Daily energy expenditure through the human life course](https://www.science.org/doi/10.1126/science.abe5017) (Pontzer et al., 2021) [1:10:45]

**For those under age 60, being in the top 20% for body fat increases all-cause mortality more than being in the bottom 20% for lean mass. However, for those over age 60, this relationship flips — muscle mass becomes even more protective**: [Predicted fat mass and lean mass in relation to all-cause and cause-specific mortality](https://onlinelibrary.wiley.com/doi/10.1002/jcsm.12921) (Liu et al., 2022) [1:13:30]

**Episode of The Drive with Luc van Loon where he had a great analogy for protein and muscle protein synthesis**: [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) | Peter Attia (peterattiamd.com) [1:15:30]

**Resistance exercise increases muscle protein synthesis by an additional ~50% over just a meal containing 90g of protein alone**: [The anabolic response to resistance exercise and a protein-rich meal is not diminished by age](https://www.sciencedirect.com/science/article/pii/S1279770723018729?via%3Dihub#fig3) (Symonsi et al., 2011) [1:16:15]

**A meta-analysis from Luc Van Loon showing that protein supplementation added an additional 0.69 kg of fat-free mass when combined with resistance exercise compared to resistance exercise alone**: [Protein supplementation augments the adaptive response of skeletal muscle to resistance-type exercise training: a meta-analysis](https://www.sciencedirect.com/science/article/pii/S0002916523029271?via%3Dihub#f2) (Naomi et al., 2012) [1:16:15]

---

## People Mentioned

- [John F. Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy) (“”Too often we enjoy the comfort of opinion without the discomfort of thought.”) [34:00]
- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) [41:15]
- [Andy Coggan](https://www.peakscoachinggroup.com/DrAndrewCoggan) [55:00]
- [Sean Mackey](https://en.wikipedia.org/wiki/Sean_Mackey_(physician)) [1:01:45]