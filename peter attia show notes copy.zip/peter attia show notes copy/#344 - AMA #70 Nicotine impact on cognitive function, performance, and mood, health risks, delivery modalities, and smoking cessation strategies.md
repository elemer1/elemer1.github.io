# #344 – AMA #70: Nicotine: impact on cognitive function, performance, and mood, health risks, delivery modalities, and smoking cessation strategies

**Source:** [https://peterattiamd.com/ama70/](https://peterattiamd.com/ama70/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives deep into nicotine—a topic increasingly debated both scientifically and publicly. He clarifies the critical differences between nicotine and tobacco, highlighting why nicotine alone isn’t primarily responsible for smoking’s severe health consequences. Peter examines the specific risks associated with nicotine use, including addiction, sleep disruption, cardiovascular concerns, and effects on mood and anxiety. He evaluates various nicotine delivery methods, from traditional cigarettes to gums, pouches, and synthetic alternatives, ranking them according to their relative safety. Additionally, Peter explores nicotine’s potential positive and negative impacts on physical performance, cognitive function, fertility, and its interactions with other stimulants like caffeine. Finally, he provides practical guidance for minimizing risks with nicotine use and offers thoughtful strategies for smoking cessation and effective nicotine replacement therapies.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #70 show notes page](https://peterattiamd.com/ama70/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Revisiting the previous AMA on microplastics: low-effort, high-impact changes to significantly reduce microplastic exposure [1:45];
- Overview of episode topics related to nicotine [3:30];
- The current landscape of nicotine research [4:45];
- Addressing the common misconception that nicotine itself is the primary cause of tobacco-related health risks [6:45];
- Peter’s Marlboro-branded apparel is a nostalgic tribute to the Formula One era and not a sign of support for smoking [10:00];
- The limitations of current research on the health risks of nicotine itself [12:15];
- The most common side effects of nicotine [18:15];
- The impact of nicotine on sleep [21:30];
- Nicotine and mood: how nicotine can have both anxiety-inducing and calming effects based on genetics and dosage [25:00];
- The addictive properties of nicotine: factors influencing addiction risk, and why certain people may struggle more than others [29:15];
- The various nicotine products and nicotine delivery methods available: effects, absorption rates, and potential risks [33:45];
- The relative risks of various nicotine products: how differences in nicotine concentration, absorption rates, and presence of contaminants impact their safety [37:00];
- How nicotine exposure during adolescence can negatively impact brain development [47:45];
- Nicotine’s potential to prevent or slow neurodegenerative diseases [50:45];
- Nicotine’s impact on memory, learning, and attention [52:45];
- The interaction between nicotine and other stimulants, particularly caffeine [55:15];
- Nicotine’s potential impact on physical performance [57:15];
- The potential effects of nicotine on fertility, and the challenges of distinguishing the impact of nicotine itself from the effects of smoking [58:30];
- Considerations for people curious about using nicotine for its cognitive benefits [1:01:30];
- How to think about nicotine: weighing cognitive claims, addiction risks, and personal tolerance [1:03:15];
- The prevalence of smoking, the health risks it poses, and the substantial long-term benefits of quitting [1:05:45];
- Effective strategies for smoking cessation including the use of nicotine replacement therapies [1:09:00];
- The reasons behind weight gain after quitting smoking, the role of nicotine in appetite suppression, and strategies to manage weight [1:15:30]; and
- More.

---

The Peter Attia Drive

#344 – AMA #70: Nicotine: impact on cognitive function, performance, and mood, health risks, delivery modalities, and smoking cessation strategies

---

## Show Notes


---

## Revisiting the previous AMA on microplastics: low-effort, high-impact changes to significantly reduce microplastic exposure [1:45]

Microplastics AMA: [#332 – AMA #67: Microplastics, PFAS, and phthalates: understanding health risks and a framework for minimizing exposure and mitigating risk](https://peterattiamd.com/ama67/)

\*\*\*

**Peter’s Personal Changes regarding microplastics**

- 80/20 Approach to Mitigating Exposure:
  - Peter implemented changes aimed at reducing 80% of his microplastics exposure.
  - These changes were chosen because they are low-cost and low-effort but provide high impact.
  - He intentionally avoids stressing over the final 20% of exposure, which:
    - May or may not matter in terms of actual health impact.
    - Would require disproportionate effort, and he believes it’s not worth the trade-off in quality of life.
- Philosophy:
  - Peter uses a sigmoidal cost/effort curve to assess lifestyle changes—targeting the steep part of the curve (maximum benefit for minimal effort).
  - He chooses not to obsess over theoretical or hard-to-measure risks if the lifestyle cost is too high.

[Video](https://www.youtube.com/watch?v=IsmBq0v50k4) demonstrating the specific changes Peter made:

## Overview of episode topics related to nicotine [3:30]

Previous AMA on nicotine from 2021: [#161 – AMA #23: All Things Nicotine: deep dive into its cognitive and physical benefits, risks, and mechanisms of action](https://peterattiamd.com/ama23/)

\*\*\*

**TOPIC: Nicotine**

- Episode Focus:
  - This AMA is dedicated entirely to nicotine, a topic that has grown in public interest.
  - The discussion is prompted by a significant increase in nicotine use compared to when Peter and Nick first addressed it in an AMA about four years ago.
- Key Themes of the Episode
  - Nicotine Use Today:
    - Increased popularity and broader public use since the original AMA on the subject.
    - Growing curiosity about nicotine’s potential short-term and long-term benefits.
- Topics to Be Covered:
  - Benefits of Nicotine:
    - Focus on areas like cognition and exercise performance.
  - Risks of Nicotine:
    - Health risks and potential side effects users should be aware of.
  - Forms of Nicotine Use:
    - Different vehicles and methods of delivery (e.g., patches, pouches, gum, vaping, cigarettes).
    - Comparison of pros and cons of each.
  - Smoking Cessation Segment
    - Discuss smoking cessation strategies.
    - Offer advice on how to help loved ones quit or approach the conversation with them.

## The current landscape of nicotine research [4:45]

**State of Nicotine Research – Then vs. Now**

Historical Context of Nicotine Research

- Most research on nicotine has historically been tied to tobacco, particularly its use in cigarettes.
- This linkage complicates understanding the independent effects of nicotine, because:
  - Tobacco products include many harmful compounds beyond nicotine.
  - It’s difficult to isolate nicotine’s effects from those of tobacco smoke or other tobacco-derived components.

Natural vs. Synthetic Nicotine

- A growing distinction in current research and public discourse is between:
  - Tobacco-derived nicotine (even in non-combustible forms like pouches).
  - Synthetic nicotine, which is produced without any use of the tobacco plant.
- This distinction is relevant because:
  - Synthetic nicotine may carry fewer contaminants.
  - It could allow researchers to study nicotine in isolation more accurately.

Challenges in Isolating Nicotine’s Impact

- Many perceived or observed health effects (e.g., infertility) are well-documented in smokers, but not well studied in users of:
  - Vapes
  - Nicotine pouches
  - Other non-combustible or synthetic products
- This limits our ability to draw firm conclusions about nicotine itself, apart from tobacco.

Contrast With the Prior AMA

- Peter notes that this episode will differ from the prior nicotine AMA in key ways:
- The previous discussion focused more on biological mechanisms (e.g., how nicotine acts on receptors).
- This episode will address more practical questions, like risks, benefits, usage methods, and cessation strategies.
- There’s more research now on potential benefits of nicotine than there was four years ago, and those findings will also be explored.

## Addressing the common misconception that nicotine itself is the primary cause of tobacco-related health risks [6:45]

**Clarifying the Misconception: Nicotine vs. Tobacco**

- Public Perception: Many people automatically associate nicotine with cigarettes and tobacco, leading to a blanket assumption that nicotine itself is highly dangerous.

So What Causes the Harm in Tobacco Products?

- Nicotine ≠ Tobacco Toxins:
  - Nicotine is only one compound in the tobacco plant.
  - The major health risks from tobacco (e.g., cancer, cardiovascular disease) are not primarily caused by nicotine.
- Primary Harmful Components in Tobacco Smoke:
  - Toxic metals
  - Formaldehyde
  - Polycyclic aromatic hydrocarbons (PAHs)
  - These non-nicotine chemicals are the main culprits in tobacco-related diseases.
- Tobacco-Derived Nicotine: Still Risky
  - Important Nuance:
    - Even if nicotine is extracted from tobacco, the resulting product can still contain carcinogens.
    - These carcinogens are byproducts of the tobacco curing and processing process.
    - This was something Peter admits he didn’t fully appreciate four years ago.
- Risk Gradient Based on Proximity to Tobacco:
  - The closer a product is to actual tobacco, the greater the risk.
  - Risk hierarchy (from most to least harmful):
    - Cigarettes, cigars, pipes
    - Chewing tobacco (e.g., loose leaves, Snus)
    - Purified tobacco-derived nicotine (still risky)
    - Synthetic nicotine (potentially safer, fewer contaminants)

## Peter’s Marlboro-branded apparel is a nostalgic tribute to the Formula One era and not a sign of support for smoking [10:00]

**Addressing the Marlboro Logo on Peter’s Clothing from a recent video**

- Listener Confusion
  - A listener emailed asking why Peter, known for being health-conscious, appeared in a video or photo wearing a hat or shirt with the Marlboro logo.
  - The question implied concern over whether this signaled support for smoking or big tobacco.
- Peter’s Response & Clarification
  - Not an Endorsement:
    - Peter makes it clear that he does not support cigarette smoking or tobacco use in any form.
    - He emphasizes: “Smoking is an absolute error” and possibly the biggest unforced health mistake one can make.
  - Formula One Nostalgia:
    - Peter is a longtime fan of Formula One (F1), especially the sport’s 1980s–2000s era.
    - During that period, [Marlboro was a major sponsor](https://cdn-1.motorsport.com/static/img/archive/autosport/news/155009_1000431/s8/1000431.jpg)—most notably for Ferrari and McLaren.
    - Some of the memorabilia or replica items Peter wears include original sponsor livery (branding/design) from those classic F1 vehicles.
  - Why He Still Wears the Gear:
    - His clothing choices are era-appropriate nods to a period in motorsport history—not statements about lifestyle choices.
    - Brands featured on the gear (e.g., Marlboro, Hugo Boss, Nationale) reflect authentic recreations of F1 team designs from that time.
  - Final Note on Tobacco Sponsorship:
    - Peter mentions that tobacco no longer sponsors F1, which he views as a positive shift for the sport.

## The limitations of current research on the health risks of nicotine itself [12:15]

**Harms Associated with Nicotine Itself (Excluding Tobacco Products)**

Addiction as the Primary Risk

- The most significant known risk of pure (synthetic) nicotine is its highly addictive nature.
- Nicotine is a potent stimulant and habit-forming compound, even without tobacco.

Other Potential Health Risks (Mostly Theoretical or Animal-Based)

- Endothelial Dysfunction:
  - Some mechanistic evidence suggests nicotine may impair endothelial function which could plausibly increase the risk of cardiovascular disease, but these connections have not been substantiated by any reports to date on clinical outcomes in humans.
- Tumor Growth and Atherosclerosis (in Rodents):
  - High doses of nicotine have been shown in mouse and rat [models](https://pmc.ncbi.nlm.nih.gov/articles/PMC2759510/) to:
    - Increase tumor growth and metastases
    - Accelerate atherosclerotic plaque development
  - Important caveat: Rodent studies don’t always translate to humans; significant “daylight” between outcomes in rodents vs. people.

Receptor Mechanism of Nicotine

- Nicotine acts on nicotinic acetylcholine receptors, found throughout the body (not just in the brain).
- Chronic exposure leads to receptor desensitization and tolerance over time.

Use of Mendelian Randomization (MR) to Study Nicotine in Humans

- Why MR is Needed: It’s hard to isolate nicotine’s effects from tobacco without unethical long-term RCTs.
- What Is MR:
  - A method using genetic variants as proxies for behaviors or exposures (e.g., nicotine metabolism).
  - Example: MR has shown LDL cholesterol is causally linked to heart disease; HDL is not.
- 2024 Mendelian Randomization [Study](https://consensus.app/papers/estimating-the-health-impact-of-nicotine-exposure-by-khouja-sanderson/1fee3e4f05fc5bdb8f31f4de12a23fb6/?extracted-answer=Increased+nicotine+metabolism+increases+the+risk+of+COPD%2C+lung+cancer%2C+and+lung+function%2C+while+decreased+nicotine+exposure+decreases+heart+rate+and+lung+function.&q=What+are+the+benefits+and+harms+of+nicotine+use&pro=on&year_min=2020) on Nicotine:
  - Investigated whether nicotine metabolism genes are associated with disease risk.
  - Fast metabolizers = lower circulating nicotine → expected lower exposure.
  - Slower metabolizers = higher exposure → appeared to show increased disease risk (lung function, COPD, ASCVD).
  - But when adjusted for smoking heaviness, that added risk disappeared.
- Interpretation:
  - The harmful outcomes (cardiovascular, respiratory, etc.) appear to come from non-nicotinic components of tobacco, not nicotine itself.

Caveats on Current Evidence

- The 2024 MR study is not Level 1 evidence (not a randomized controlled trial).
- Ideal study design: Randomize people to various tobacco-free nicotine products and follow for health outcomes—unlikely to happen for hard outcomes like mortality.
- Could feasibly study softer endpoints in controlled settings (e.g., blood pressure, sleep, cognitive markers).

## The most common side effects of nicotine [18:15]

**Common Side Effects of Nicotine Use**

Gastrointestinal (GI) Distress

- [Most frequent symptom is nausea](https://pubmed.ncbi.nlm.nih.gov/20626883/), especially in nicotine-naive individuals.
- A non-smoker using 4 mg of Nicorette gum will likely feel significant nausea and may vomit.
- Even lower doses (e.g., 0.5 mg) are better tolerated for first-time users.
- Estimated prevalence: About 10% of the population may experience significant GI issues.

Sleep Disturbance

- Nicotine has activating effects, which can impair sleep quality.
- Poor sleep can have secondary effects, including:
  - Metabolic dysfunction
  - Cardiovascular disease
- This is particularly concerning for regular users of high-dose nicotine (including non-smokers using synthetic products).

Acute Cardiovascular Effects

- Temporary increases in:
  - Heart rate: typically 10–15 beats per minute
  - Systolic blood pressure: rises by 5–10 mmHg
- These effects resolve upon cessation of nicotine use.
- Not considered physiologically significant in healthy individuals, but could pose a risk for those with underlying cardiovascular conditions.

Categorizing the Side Effects

- These side effects (GI, sleep, heart rate, BP) are best placed in the “acute symptom” bucket.
- No evidence they cause long-term damage unless use is chronic and compounded with other risk factors.

⇒ BONUS: Check out the [Big Chief clip](https://www.youtube.com/watch?v=nxM4ygJR5LI) from The Sandlot

## The impact of nicotine on sleep [21:30]

**Nicotine and Sleep**

Evidence from Human Studies

- Well-designed randomized controlled trials (RCTs) using crossover designs (where each participant serves as their own control) provide clear evidence that nicotine can negatively impact sleep.
- One notable [study](https://pubmed.ncbi.nlm.nih.gov/7962682/) used a 14 mg nicotine patch and found:
  - REM sleep decreased from ~24% to ~19% of total sleep time.
  - Total sleep time and sleep efficiency also decreased.
  - Participants spent more time awake in bed—clearly clinically relevant effects.

Mechanism and Delivery Method Differences

- The method of nicotine delivery matters:
  - Patches (slow, sustained delivery) were used in most of the sleep studies.
  - Other forms (e.g., gum, lozenges, pouches) have faster onset and shorter duration, which may allow for better control and timing.
- These other forms are typically used by people not for smoking cessation, but for performance or cognitive enhancement.

Timing and Dosage Considerations

- Based on rough extrapolation from [animal data](https://pubmed.ncbi.nlm.nih.gov/10463313/) (rodents), the team estimates:
  - >5 mg of nicotine within 2–3 hours before bed likely impacts REM sleep.
  - ≤5 mg taken more than 3 hours before bed is less likely to impair sleep.
- Peter’s recommendation: Stop using nicotine 6 hours before bedtime to avoid any sleep disruptions.

Additional Concern: Withdrawal-Induced Sleep Disruption

- Withdrawal from nicotine (especially at higher doses) can also negatively affect sleep, even if the user isn’t currently consuming nicotine.
- This adds another layer of complexity, particularly for those who use nicotine consistently throughout the day.

Practical Advice for Users

- Use sleep tracking tools (e.g., Oura Ring, Whoop) to observe how nicotine affects your own sleep metrics.
- Individual experimentation with timing and dose can help personalize the impact.

## Nicotine and mood: how nicotine can have both anxiety-inducing and calming effects based on genetics and dosage [25:00]

**Nicotine’s Impact on Mood and Anxiety**

Complexity of Cause and Effect

- Epidemiologic data is limited in distinguishing whether nicotine causes anxiety or if individuals with existing anxiety/depression self-medicate with nicotine products (like cigarettes or alcohol).
- Causality is hard to prove, especially since most long-term data comes from studies of smokers, not users of pure nicotine.

Evidence That Nicotine Can Increase Anxiety

- [Rodent studies](https://www.sciencedirect.com/science/article/abs/pii/S0278584619304890?via%3Dihub) show that chronic nicotine use increases anxiety-like behaviors, even at low doses.
  - This suggests a dose-dependent relationship, and that as little as 3 mg (a common dose in nicotine pouches like ZYN) may trigger anxiety symptoms.
- Anecdotally, a friend of Peter’s experienced heightened anxiety when using nicotine—even at low doses like toothpicks with 2–3 mg of nicotine.
- This anxiety effect is usually present only during active use and does not appear to persist after discontinuation.
- Neuroscientists have also [shown](https://www.cell.com/neuron/fulltext/S0896-6273(21)00428-1) that nicotine promotes anxiety by inhibiting the activity of dopamine neurons projecting from reward circuits to the amygdala, and blocking this inhibition can block nicotine’s anxiogenic effects
- There may also be [differences in effect](https://academic.oup.com/ijnp/article/4/4/371/617363) on men vs. women

Nicotine Can Also Be Calming for Some

- Peter shares his personal experience:
  - Nicotine via pouches tends to calm him, even producing a sedative effect at slightly higher doses.
  - This variability may come down to individual differences in genetics, metabolism, and baseline neurochemistry.
- Genetic heterogeneity likely explains why some people feel anxious and others feel relaxed or sedated using the same product and dose.

Importance of Individualized Use

- Peter emphasizes the need to “know thyself” when using nicotine:
  - Monitor your mood and anxiety levels.
  - Be willing to adjust or stop use if negative symptoms occur.
  - Low doses (e.g., 3 mg pouches or toothpicks) are a good starting point, but responses can vary significantly.

Overall Summary of Nicotine’s Mood Effects

- Nicotine may acutely promote anxiety, especially at higher doses or with chronic use.
- It may also offer short-term antidepressant or calming effects in some individuals.
  - In a 4-week [RCT](https://link.springer.com/article/10.1007/s00213-006-0516-y) of nonsmokers with depression (n=11), chronic (but not acute) nicotine resulted in a significant decline in depression scores by day 8, but scores returned to placebo levels when nicotine dose was reduced in the last week of the trial.
  - The antidepressant effects do not continue past the period of nicotine use, and the antidepressant effects will gradually diminish if tolerance develops
- These effects do not persist once nicotine is discontinued.
- Self-awareness, dose control, and careful experimentation are key.

## The addictive properties of nicotine: factors influencing addiction risk, and why certain people may struggle more than others [29:15]

**Addictive Potential of Nicotine**

Core Understanding of Nicotine Addiction

- Nicotine is highly addictive.
- Quitting nicotine often leads to classic withdrawal symptoms, including:
  - Irritability
  - Anxiety and even anger
  - Difficulty concentrating
  - Sleep disturbances
  - Increased appetite and weight gain
- These withdrawal symptoms, especially appetite and irritability, are a primary concern for smokers trying to quit, and why nicotine replacement therapy (NRT) can be so helpful.

Individual Response to Addiction Risk May Vary

- Peter notes he has not personally experienced withdrawal symptoms, which may be due to:
  - Low daily doses (3–6 mg/day)
  - Individual genetic factors (affecting nicotine metabolism and neuroreceptor sensitivity)
- His case suggests some people may not be as prone to addiction, but this shouldn’t be generalized.

Mechanism Behind Nicotine Addiction

- Stimulates dopamine release → promotes drug-seeking behavior and psychological dependence.
- Desensitization of nicotinic acetylcholine receptors over time → body compensates by:
  - Increasing number of receptors (upregulation)
  - This leads to tolerance and dependence—hallmarks of addiction seen in many substances.

Signs to Self-Monitor for Addiction

- Peter suggests asking yourself:
  - Am I experiencing cravings?
  - Do I have a compulsion to use it?
  - Does nicotine interfere with things I need to do?
  - Have I lost control over my use?
  - Are there consequences to my behavior?
- If yes to most, it’s a strong sign of dependence or addiction.

How Much Is Too Much? Addiction Thresholds

- Animal [studies](https://link.springer.com/article/10.1007/s00213-005-0037-0) suggest addiction risk rises at ~30 mg/day.
- But epidemiologic [data](https://www.nejm.org/doi/full/10.1056/NEJM199407143310212) (from humans) show risk may begin as low as 5 mg/day.
  - Therefore, to play it safe, Peter recommends staying under 5 mg/day, especially for non-daily users.
- For context:
  - One ZYN pouch or nicotine gum often contains 4 to 6 mg of nicotine.
  - That means even one pouch a day might put you at the addiction threshold.

**Understanding Individual Differences in Nicotine Addiction Risk**

Core Factors Influencing Addiction Risk

- Dose and frequency are two of the most significant variables:
  - The higher the dose and the more frequent the use, the greater the risk of addiction.
- Context and behavior matter:
  - Using nicotine as a coping mechanism (e.g., to numb emotions or distract from stress) increases risk.
  - Environmental triggers and substitution behaviors (e.g., using nicotine instead of addressing underlying issues) also increase vulnerability.
- Peter cites the [episode with Dr. Anna Lembke](https://peterattiamd.com/annalembke/), who emphasizes how the context in which substances are used significantly affects the risk of dependence.

Genetic and Physiological Factors

- There is genetic heterogeneity in how people respond to nicotine:
  - Some individuals are more susceptible to developing dependency based on neurochemical and genetic factors.
- Women metabolize nicotine faster than men:
  - This faster metabolism may lead to greater withdrawal intensity, potentially making quitting more difficult.
  - [Epidemiological data](https://academic.oup.com/ntr/article-abstract/23/10/1673/6257701?redirectedFrom=fulltext) supports that women often have lower success rates in smoking cessation compared to men.
- Hormonal factors may also play a role:
  - The effect of estrogen and variations in estrogen receptor activity, especially pre- vs. post-menopause, may influence addiction risk and cessation outcomes.

Key Takeaway

- Addiction susceptibility is a complex interplay of:
  - Genetics
  - Hormonal influences
  - Behavioral context
  - Frequency and intensity of use
- There’s no perfect way to predict who will become addicted, but understanding these risk factors can guide more personalized decision-making and caution in using nicotine products.

## The various nicotine products and nicotine delivery methods available: effects, absorption rates, and potential risks [33:45]

**Overview of Modern Nicotine Products (Beyond Smoking)**

Common Forms of Nicotine Consumption (Non-Combustible)

- Inhalation Products (non-cigarette):
  - Includes vapes and E-cigarettes.
  - Delivers nicotine quickly via the lungs.
  - Often contain other chemicals; risk profile depends on formulation and device.
- Transdermal Delivery:
  - Nicotine patches.
  - Provide slow, steady nicotine delivery over many hours.
  - Commonly used in smoking cessation strategies.
- Oral Mucosa Absorption:
  - Gum (e.g., Nicorette): 1–4 mg doses.
  - Lozenges: similar to gum in dosage and duration.
  - Pouches: e.g., ZYNs, VELOs (tobacco-free, typically nicotine salts).
  - Toothpicks: contain 1–5 mg, though effective absorption is likely lower.
- Snus (Peter advises avoiding anything that has tobacco in it):
  - Finely ground tobacco-based oral product.
  - Still contains tobacco and thus higher associated health [risks](https://onlinelibrary.wiley.com/doi/full/10.1002/ijc.34643).

Tobacco-Free vs. Tobacco-Derived Products

- Synthetic nicotine:
  - Created without tobacco, avoids tobacco-associated contaminants.
  - Preferred option for reducing health risks.
- Tobacco-derived nicotine:
  - Even when purified, may still carry residual carcinogenic compounds.
  - Greater risk than synthetic forms, especially if product is minimally processed.

Moisture Levels in Pouches and Impact on Absorption

- Dry Pouches:
  - Slower onset.
  - Duration of nicotine effect: 30 to 90 minutes.
- Moist Pouches:
  - Faster absorption.
  - Shorter duration of action: 20 to 60 minutes.
  - Moisture content typically 30–50%.

**Relative Duration & Dose by Product Type**

![](https://peterattiamd.com/wp-content/uploads/2025/04/f1-ama70.png)

**Figure 1.** Common nicotine products and their delivery.

Practical Note

- Individual preference for delivery method may vary by desired onset speed and duration.
- Moisture, dose, and placement in the mouth all impact absorption kinetics.

## The relative risks of various nicotine products: how differences in nicotine concentration, absorption rates, and presence of contaminants impact their safety [37:00]

**Comparative Risks of Nicotine Products**

*Framework for Evaluating Nicotine Product Risk*

- Two primary factors to evaluate:
  - 1) The maximal circulating concentration of nicotine that’s associated with that product:
    - Total dose (mg of nicotine)
    - Absorption speed (e.g., inhalation vs. patch)
    - Bioavailability (how much reaches circulation)
  - 2) Presence of any compound that is NOT nicotine that may enter your body:
    - Carcinogens, aldehydes, heavy metals, and contaminants.

Relative Risk by Nicotine Form

- Cigarettes:
  - ~1–2 mg nicotine per cigarette, inhaled.
  - Very high absorption, bioavailability, and toxicity from combustion byproducts (formaldehyde, heavy metals, etc.).
  - Extremely high addiction potential and serious long-term health risk.

**Addiction potential**:

> “*Higher addiction potential occurs with the higher the concentration, the faster absorption, and the greater the total consumption*.” —Peter Attia

\*Important points:

- Nicotine absorption and bioavailability depend on where you put it (skin vs mouth vs lungs)
- But also the pH of the product itself—the more alkaline the environment, the more readily it is absorbed.

\*\*\*

- Vapes / E-cigarettes:
  - [Very rapid absorption](https://link.springer.com/article/10.1007/s40279-017-0764-5).
- Nicotine Patches:
  - Slower release, steady exposure.
  - Lower addiction potential due to slower delivery.
  - Considered one of the safest nicotine options.
- Gum / Lozenges:
  - Absorbed through oral mucosa.
  - Faster than patch, slower than vape.
  - Usually 1–4 mg per piece.
  - Low risk; FDA-approved for cessation.
- Nicotine Pouches (e.g., ZYN, VELO):
  - Tobacco-free versions are much safer.
  - Moisture content affects absorption speed:
    - Dry pouches: slower onset, longer-lasting (30–90 min).
    - Moist pouches: faster onset, shorter duration (20–60 min).
  - Buffered to raise pH (alkaline), which increases absorption but too much can cause mouth discomfort.
  - Should be third-party tested (e.g., see [nicoleaks.com](http://nicoleaks.com)).
  - For nicotine pouches, pH is an important consideration for safety. Beyond the implications for nicotine absorption, the pH of the mouth is important to avoid irritation and enamel breakdown. An acceptable range of pH is 5.5-9.0 for pouches. (Long-term, the mouth should be as close to neutral, pH 7, as possible). The range is determined by the acidity buffers of the pouch, determined by the manufacturer. A more basic (higher pH) pouch will have more free nicotine, which is more quickly absorbed ([link](https://www.researchgate.net/publication/351900828_Characterization_of_Total_and_Unprotonated_Free_Nicotine_Content_of_Nicotine_Pouch_Products)).
- Snus / Chewing Tobacco:
  - Contains actual tobacco → retains many carcinogens.
  - Higher risk, even without combustion.
  - Strongly discouraged.

![](https://peterattiamd.com/wp-content/uploads/2025/04/f2-ama70-1024x304.png)

**Figure 2**. Source: [Toby Mündel, Sports Medicine, 2017](https://link.springer.com/article/10.1007/s40279-017-0764-5)

**Chemical Additives and Contaminants**

- Most nicotine products (even FDA-approved ones) contain additives:
  - Flavors
  - Texture agents
  - pH buffers to optimize absorption
- Unfiltered tobacco derivatives = higher carcinogenic risk
- FDA-approved products on the other hand have *stringent testing and oversight*
- E-cigarettes/vapes
  - These can contain transition metals and aldehydes that can, at some levels, come in line with what you would experience in cigarettes
  - The majority of non-nicotine chemical byproducts that are identified in E-cigarettes are basically things that result from thermal decomposition of the products within them
    - A [review](https://pmc.ncbi.nlm.nih.gov/articles/PMC7873740/) found 47 such compounds

![](https://peterattiamd.com/wp-content/uploads/2025/04/f3-ama70.png)

**Figure 3.** Harmful exposures associated with e-cigarettes. 1) Based on data from Münzel et al. 2020, Azzopardi et al. 2021, Jablonski et al. 2022, and Back et al. 2023; 2) Particulates in e-cigarettes are primarily liquid, dissipate quickly, and are of uncertain relevance to human disease. (In contrast to particles from combustion that contain solid matter.)

> “The takeaway of this is I do not believe that vapes are entirely benign, even the non-tobacco-derived ones.” —Peter Attia

**Some takeaways**:

- When you look at the FDA-approved options, which include synthetic nicotine pouches, they appear to be much safer
- So if it’s smoked, if it’s burned, if it’s from tobacco, if it’s whole tobacco, just stay away from it.
- ZYNs have been recently authorized by the FDA as having more benefit than risk for those switching from other smokeless tobacco products
  - Don’t over-interpret that as a particularly high bar, but nevertheless, that’s a much better sign than had the FDA not said that.

Independent Testing and Quality Assurance

- Variability in contaminant levels by brand and flavor
- Users should check third-party testing results before using any product
- [Nicoleaks.com](http://nicoleaks.com) is a helpful third-party testing resource for nicotine pouches

Peter’s Risk Ranking (Least risky to most risky)

- 1) FDA-Approved Products (gum, patches)
- 2) Tobacco-free Pouches (e.g., ZYN – synthetic or purified nicotine)
- 3) E-cigarettes/Vapes (risk from heating elements, aldehydes, heavy metals)
- 4) Combustible Tobacco Products (cigarettes, cigars, pipes)

## Potential cognitive benefits of nicotine: short-term benefits and impact of chronic use [44:45]

**Cognitive Benefits of Nicotine – Short vs Long-Term**

Mechanism of Action

- Nicotine binds to nicotinic acetylcholine receptors in the brain.
- Triggers release of neurotransmitters:
  - Acetylcholine (learning, memory)
  - Dopamine (reward)
  - Serotonin, GABA, etc.

Short-Term Cognitive Effects

- May enhance:
  - Attention
  - Focus
  - Working memory
- Likely to diminish over time as dependency increases.
- Acute boost followed by receptor desensitization.

Long-Term Use & Dependency

- Habitual use → upregulation of receptors → tolerance.
- When nicotine is absent, cognitive function may dip below baseline.
- This dip [resolves](https://pmc.ncbi.nlm.nih.gov/articles/PMC3278577/) within 2–4 weeks after cessation.

Permanent Cognitive Changes?

- Rodent [studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC3278577/) suggest no lasting cognitive damage in adults after cessation.
- No permanent deficits in attention, learning, or impulsivity—once withdrawal phase passes.

## How nicotine exposure during adolescence can negatively impact brain development [47:45]

**Cognitive Effects of Nicotine in Adolescents and Young Adults**

Brain Development Vulnerability

- The human brain does not fully mature until the early to mid-20s.
- During adolescence, key brain regions like the prefrontal cortex and dopamine circuits are still developing.
  - These areas are essential for executive function, decision-making, and emotional regulation.
- The immature brain is more vulnerable to external chemicals like:
  - Nicotine
  - Alcohol
  - THC
  - Psychedelics

Role of Nicotinic Receptors in Development

- Nicotinic acetylcholine receptors play a role in neural development during adolescence.
- Nicotine exposure during this critical developmental window may interfere with the maturation of executive function and emotion regulation systems.

Evidence from Animal Studies

- [Rodent models](https://www.nature.com/articles/npp200896) show lasting cognitive and emotional consequences from early nicotine exposure:
  - Contextual fear conditioning persists into adulthood.
  - Negative changes in the hippocampus and emotional learning.
  - Reduced attention span and increased impulsivity in adulthood.
  - These effects persist long after nicotine exposure ends—well beyond the typical withdrawal phase.

Extrapolation to Humans & Precautionary Principle

- While these studies are in animals, Peter urges caution due to:
  - The biological plausibility of similar effects in humans.
  - The ethical impossibility of running equivalent randomized trials in adolescents.
- Peter strongly advises:
  - Anyone under 25 to avoid nicotine in any form.
  - Parents to consider refraining from use around kids—even if they themselves use nicotine—to avoid modeling behavior or creating confusion about safety.

## Nicotine’s potential to prevent or slow neurodegenerative diseases [50:45]

**Potential Role of Nicotine in Neurodegenerative Diseases & Cognitive Impairment**

Theoretical Basis for Benefit

- Nicotinic acetylcholine receptor activation has been shown to:
  - Reduce inflammation (anti-inflammatory effect).
  - Reduce cell death (anti-apoptotic effect).
  - Improve neuroplasticity.
- Based on these mechanisms, nicotine could hypothetically:
  - Reduce the risk of neurodegenerative diseases.
  - Slow their progression.
  - Improve cognitive function in those with baseline cognitive impairment.

Nicotine & Alzheimer’s Disease

- Currently, no compelling evidence supports nicotine as beneficial for Alzheimer’s.
- Studies have not yet demonstrated consistent or significant clinical benefit.

Nicotine & Parkinson’s Disease

- Some epidemiologic data, animal studies, and small clinical trials suggest:
  - A slowing in disease progression.
  - Some improvement in motor symptoms.
- However:
  - Placebo-controlled trials (30–160 participants) have not confirmed these effects.
  - Open-label trials (no blinding or placebo) have shown some promise but lack scientific rigor.
- More clinical trials are ongoing, and:
  - It’s possible previous studies were underpowered.
  - Or were using inappropriate metrics to detect effects.
- Peter summarizes the evidence as:
  - “*There is some smoke here, but the fire has yet to be identified*.”

**Nicotine & Cognitive Impairment in Non-Neurodegenerative Contexts**

- In contrast to Alzheimer’s and Parkinson’s, nicotine has [shown](https://www.researchsquare.com/article/rs-1954093/v1) more promise in:
  - Improving attention, learning, and memory in individuals with:
    - Mild cognitive impairment (MCI)
    - [Age-related cognitive decline](https://link.springer.com/article/10.1007/s00213-003-1614-8)
    - Cognitive impairment from [chemotherapy](https://link.springer.com/article/10.1007/s11764-019-00786-6) or psychiatric conditions like [schizophrenia](https://www.nature.com/articles/npp2015176)

## Nicotine’s impact on memory, learning, and attention [52:45]

**Nicotine and Cognitive Performance in** ***Impaired*** **Individuals**

Human Studies: Promising Results in Impaired Populations

- Acute and chronic treatment with:
  - Nicotine
  - Other nicotinic receptor agonists (with similar but not identical effects)
- Have shown measurable improvements in cognitive functions like:
  - Memory
  - Learning
  - Attention
- These benefits have been observed in individuals with:
  - Mild Cognitive Impairment (MCI) (incipient dementia)
  - Age-related cognitive decline
  - Schizophrenia
  - Cognitive impairment caused by chemotherapy (“chemo brain”)
- These findings suggest potential therapeutic uses of nicotine in populations with preexisting cognitive deficits.

**Nicotine & Cognition in** ***Healthy*** **Individuals: Unknown**

No Solid Data for Cognitively Normal Individuals

- No human trials yet address the question:
  - D*oes nicotine enhance cognition in healthy people*?
- The closest data comes from rodent studies, where:
  - Nicotine shows improvements in animals whose cognitive function was impaired by stress.
  - But this doesn’t answer whether nicotine helps non-impaired subjects.
  - Key point: Improvement of deficits ≠ enhancement beyond baseline.

The MIND Trial (Upcoming)

- A major ongoing study: [MIND](https://alz-journals.onlinelibrary.wiley.com/doi/abs/10.1002/alz.064697) = Memory Improvement through Nicotine Dosing
  - Focus: Nicotine’s effect on cognitive decline.
  - Expected to report later this year (2025)
  - Will **not** answer whether nicotine benefits healthy individuals.

**Caution: Possible Limits on Cognitive Gains**

- Potential Cognitive Benefits in Healthy People May Be Temporary
  - While nicotine may offer short-term cognitive enhancement, the benefits could be neutralized by:
    - Desensitization of nicotinic acetylcholine receptors
    - Tolerance and dependence
  - As dependence increases:
    - Cognitive performance may drop in the absence of nicotine, effectively negating any earlier gains.

> “I’m not thoroughly convinced this is a viable tool for ongoing cognitive enhancement.” —Peter Attia

## The interaction between nicotine and other stimulants, particularly caffeine [55:15]

**Nicotine and Caffeine: Interaction Between Stimulants**

Animal Studies Suggest Potential for Enhanced Reward

- Stimulants may “cross-potentiate” each other’s effects in animals.
  - Example: Caffeine may enhance nicotine’s reward effect.
- One rat [study](https://pmc.ncbi.nlm.nih.gov/articles/PMC3775986/#:~:text=Furthermore%2C%20chronic%20oral%20exposure%20to,et%20al.%2C%201994).):
  - Caffeine exposure led to increased self-administration of nicotine.
  - The effect was dose-dependent.

Human Evidence is Limited and Inconclusive

- A small human [study](https://pmc.ncbi.nlm.nih.gov/articles/PMC3209967/pdf/nihms-334427.pdf) (20 participants, all nicotine-naive) evaluated the cognitive effects of nicotine and caffeine:
  - Nicotine (2 mg and 4 mg) improved reaction time on working memory tasks.
  - Caffeine (0, 75, 150 mg) improved:
    - Working memory accuracy
    - Orienting attention
  - Best working memory accuracy occurred at 150 mg caffeine before nicotine.
  - No evidence of a synergistic or multiplicative cognitive boost when both were used together.
  - Conclusion: Effects seem to be redundant, not additive.

Nicotine + Smoking Can Affect Caffeine Metabolism

- Smoking accelerates caffeine metabolism, likely due to substances in smoke (not nicotine itself).
  - This means caffeine is cleared from the body more quickly in smokers.
  - Result: Lower circulating caffeine concentration, potentially reducing caffeine’s effects.
  - This phenomenon is not observed with pure nicotine (e.g., patches, pouches).

Caution Beyond Studied Doses

- The human study only tested low doses of nicotine (2–4 mg) and moderate caffeine doses (up to 150 mg).
- Peter warns against extrapolating effects beyond those doses.
- No guidance offered for higher intake combinations due to lack of research.

## Nicotine’s potential impact on physical performance [57:15]

**Nicotine and Physical Performance**

Nicotine as a Stimulant in Athletics

- Nicotine is commonly used by elite athletes, particularly in high-intensity or kinetic sports (e.g., weightlifting, football, hockey).
- Not typically desirable in sports requiring fine motor control (e.g., archery, shooting) due to potential stimulation effects.

World Anti-Doping Agency (WADA) Perspective

- Not banned, but monitored by WADA since 2012.
  - WADA monitors substances that may be performance-enhancing, even if not yet banned.
- Monitoring status implies:
  - Suspected usage patterns among athletes.
  - Uncertain benefit — i.e., insufficient evidence to justify a ban.
- Peter notes that WADA typically has a low bar for banning substances, so the fact that nicotine remains legal suggests limited proven enhancement effects.

Practical Implications

- Athletes who are WADA-tested are being tracked for nicotine use, even though it’s not prohibited.
- This raises awareness among competitive athletes that usage is on the radar, possibly subject to future regulation.

## The potential effects of nicotine on fertility, and the challenges of distinguishing the impact of nicotine itself from the effects of smoking [58:30]

**Nicotine and Fertility**

Challenges in Interpreting the Research

- Most available data is based on studies of cigarette use, not isolated nicotine, making it difficult to isolate nicotine’s true impact.
- Effects from E-cigarettes or nicotine-only products are not as well studied in humans.

Findings from Animal Studies

- Rodent [studies](https://pubmed.ncbi.nlm.nih.gov/23926503/) show:
  - Nicotine can negatively affect male fertility:
    - Decreases in sperm count, motility, and morphology.
  - Important note: These effects were reversible after a 30-day washout period.
    - Suggests potential for recovery of fertility after cessation of nicotine exposure in humans.

Human Male Fertility Data

- Epidemiologic [study](https://academic.oup.com/humrep/article/35/7/1693/5859935) of ~1,200 men using E-cigarettes:
  - Found a significant reduction in sperm count compared to non-users.
  - Causal factors are unclear:
    - Could be due to nicotine.
    - Could be due to other compounds in vapor.
    - Could be due to lifestyle confounders.

Human Female Fertility Data

- Observational [study](https://watermark.silverchair.com/kwaa067.pdf?token=AQECAHi208BE49Ooan9kkhW_Ercy7Dm3ZL_9Cf3qfKAc485ysgAAA04wggNKBgkqhkiG9w0BBwagggM7MIIDNwIBADCCAzAGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQMq8WWH7Xpq-M14QSoAgEQgIIDAVZwsZ6bHtwRSX5mx8v_526NwGDDf6fVjJrsI7f-6FBNMelvJOwmK97qBCABDYMU4nScBsOgb3cH1q61mDfCv4O4DNJ5esx4eJcVwC18WceBvPpCRyycvD94gisSopJhhDtdrQbdSIGaMNzuW9YLQQgcC-xaIK4Qcumi0eFBCguiFpuctm_igWhrcaivlST-ca4DHSv1RD8ahklG3kSa9qsxvnPRzLxrep1xwHyBi_sfyvmZMjGheoCpq3ySy_I3Ant3QXn2SVrwLRF0vhx4pOJ0FrwCPy6L_l9cprzMHOC_SwFYMZwoMZPbwMsIeURrbTiC3_8dKxhkOkZ7yizRgeYr6jDlVdN0gLetUiwmhW_-v-sUH-65wHzhpF2AW7FD3dtVymFwq4AcTGQrsgk5Y1MoMSb2lsFfal4cRaXhIDrnBjfOyGPIc3oERqIFpbY4zwYxIj0dr8pAW0PtWX59ugm0e6DKu_dKlQ-CwoRctoALwPY8mOEi-HIXKJkqhKIpsvDZVsAWkB8fcCn59xnAgZMCsW8b_rE2lLeQ73LFL3GpMyXaSJ_CRjtY6-bcubaGgEqcMiSY_iKTDkiePsQk5tPKP85bycBma-zSRyz13gGFpYWeu0QCnhtB3DkcsJLUbRmQES04uXy4d23K2U-Z_oDn-0R1na-OfZ5z3lXm6Ck3txzk0PGYOj0333MwafShFMfz5996wQlqbR65mlEIIJsrARvf3bB64hJf4ZNxvv7vhShjrBwbY5qrz1jZm7KzBiUcdK293jWGDSfgnJgi85p9_LcPGGj6SiQnFdrpnEoY8FPpeDBL5iRHtyS5HCsY9mV6VMh_ss775gXJudBYwpumcfmBv_xp4kpCjWNAqUGTAlH_muGCzK34bA1M6xs31cTlk9p1p0GmYf_5GhdmJ0b3nFSAYdsHFzh0i_6uYxJR-f6AFGvlvmXDDTEJPGaHXD9eRRb9mAO4LBinn8kEt3vNHgulb1AG911gBui6NNdpCAmD9SqDKss3aJDDaHCcJ-0):
  - Compared E-cigarette users vs. never-smokers.
  - Found a 13% lower chance of pregnancy in users, but:
    - The difference was not statistically significant.
    - Same caveats about confounding variables apply.

*Peter’s Perspective and Practical Advice*

- Most smokers can and do conceive, so small impairments may not block fertility entirely.
- For those who are older or dealing with increased reproductive risks, optimizing health (including removing nicotine) makes sense.
- Recommendation if you’re trying to conceive:
  - Consider a nicotine washout period.
  - Aim to stack the odds in your favor by eliminating possible negative contributors.

## Considerations for people curious about using nicotine for its cognitive benefits [1:01:30]

**Safest Way to Use Nicotine (If Pursuing Potential Cognitive Benefits)**

Caution Against Overestimating Benefits

- Peter urges restraint and skepticism about cognitive enhancement claims:
  - Current evidence is limited for cognitively normal individuals.
  - Awaiting results from the MIND trial, which may offer more clarity in ~4 years.

Narrow Conditions for Potentially Beneficial Use

- For any benefit to exist, several conditions must be met:
  - Short-term use only.
  - Low/intermittent doses (a few milligrams).
  - No signs of dependence or addiction.
- If dependence occurs, it could eliminate or reverse any cognitive benefits due to receptor desensitization and withdrawal effects.

*Peter’s thoughts*

- If someone chooses to experiment:
  - Use gum or a high-quality nicotine pouch (tobacco-free, third-party tested).
  - Avoid smoking, vaping, or tobacco-derived products.
  - Start with the lowest possible dose (e.g., ~2–3 mg).
  - Remain vigilant and monitor for:
    - Cravings
    - Escalating usage
    - Side effects (e.g., sleep, anxiety)

## How to think about nicotine: weighing cognitive claims, addiction risks, and personal tolerance [1:03:15]

**How to Think About Nicotine: Balancing Risks and Benefits**

Know Yourself: Risk Tolerance & Individual Differences

- Peter emphasizes the importance of self-awareness in how one responds to substances.
- Notes that he’s personally never experienced addiction to common substances (nicotine, caffeine, alcohol), but this is biological, not moral.
- Individuals should assess their own susceptibility to dependence before considering nicotine.

Nicotine’s Subjective Effects Vary

- Peter uses nicotine for its calming effect, not for stimulation or cognitive boost.
- He doubts it improves cognition for him and is skeptical of long-term enhancement claims.
- Reinforces that enjoyment ≠ safety or benefit, and dependence could negate any perceived benefits.

Evaluate Substances by Mechanism, Not Just Legality

- Argues that people should evaluate substances like nicotine in the same framework as:
  - Caffeine
  - Adderall (amphetamines)
  - Cocaine (included for comparison, not endorsement)
- Framework to assess:
  - Mechanism of action
  - Stimulatory potential
  - Addictiveness
  - Health risks

Nicotine’s Relative Risk Profile

- Nicotine sits between caffeine and amphetamines in terms of risk:
  - More risky than caffeine
  - Less risky than amphetamines
  - Much less risky than cocaine
- It’s not harmless, but not the worst actor when considered mechanistically and behaviorally.

![](https://peterattiamd.com/wp-content/uploads/2025/04/f4-common-stimulants-ama70.png)

**Figure 4.** Common stimulants and their relative effects. aAmphetamine lasts longer, thus does not have the same level of behavioral reinforcement that cocaine or nicotine use does. bAdded risk of unknown purity of illicit substances

## The prevalence of smoking, the health risks it poses, and the substantial long-term benefits of quitting [1:05:45]

**Smoking Prevalence, Risks, and Benefits of Quitting**

Current Smoking Trends

- Global smoking [prevalence](https://www.who.int/news/item/16-01-2024-tobacco-use-declines-despite-tobacco-industry-efforts-to-jeopardize-progress#:~:text=Currently%20the%20WHO%20South%2DEast,Oman%2C%20and%20Republic%20of%20Moldova.) is around 15%.
- U.S. rate is slightly above global average; Europe is higher (~23%).
- Smoking rates have dropped significantly since the 1960s, when U.S. prevalence was 2–3x higher than today.
- Despite progress, a meaningful portion of the population still smokes.

How Risk Is Measured: Pack Years

- Smoking risk is commonly calculated using “pack years”:
  - Formula: packs per day × years smoked.
  - Example: Half a pack per day for 25 years = 12.5 pack years.
- Categorization:
  - Light smokers: <10 cigarettes/day
  - Average smokers: 10–20/day
  - Heavy smokers: >20/day

Health Risks of Smoking

- Risks increase monotonically with more consumption—more smoking = higher risk.
- Smoking is linked to major chronic diseases:
  - Atherosclerotic cardiovascular disease (ASCVD)
  - Cancer
  - Chronic obstructive pulmonary disease (COPD)
- While not many patients at Peter’s practice are current smokers, helping even one person quit can be a major win for long-term health.

Benefits of Quitting Smoking

- CVD Risk Reduction (based on [Framingham Heart Study](https://jamanetwork.com/journals/jama/fullarticle/2748507)):
  - Within 5 years, risk of CVD dropped by 39%.
  - Event rate dropped from 12 to 7 per 1,000 person-years.
  - After 10–15 years, CVD risk is nearly identical to never-smokers.
- Cancer Risk Reduction:
  - After 20 years of smoking cessation, risk of cancer is also virtually equivalent to that of a never-smoker.
- Takeaway: It is never too late to quit. Past smoking history should not be an excuse to continue smoking.

## Effective strategies for smoking cessation including the use of nicotine replacement therapies [1:09:00]

**Smoking Cessation: Strategies, Tools, and Mindset**

Approaching Smoking Cessation Thoughtfully

- Peter emphasizes he’s not a cessation specialist, but offers practical, experience-based strategies.
- Cold turkey is rarely effective, especially for long-term smokers (e.g., half a pack/day for 20 years).
- A broad, systematic approach is required to address:
  - Nicotine addiction
  - Environmental triggers
  - Behavioral reinforcers (e.g., oral fixation, stress, habits)

Behavioral Techniques for Quitting

- Trigger Mapping
  - Log each cigarette over 2 weeks: time, location, situation, emotional state.
  - Goal: Increase mindfulness about why you’re smoking.
- Routine Reduction
  - Example: Cut “coffee + cigarette” habit to half a cigarette and extend time between smokes.
- Urge-Behavior Decoupling
  - When you feel the urge to smoke, delay it with a timer (15–30 minutes).
  - This builds control and reduces impulsivity.

Nicotine Replacement Therapy (NRT)

- Replace one cigarette with 1–2 mg of nicotine from NRT.
- [Cochrane Review](https://pmc.ncbi.nlm.nih.gov/articles/PMC6353172/) Findings:
  - NRT increases quit rate by 50–60% relative risk.
  - Absolute risk improvement: ~0.6%.
  - In 1,000 smokers trying to quit:
    - ~100 succeed without support.
    - ~160 succeed with NRT.

Pharmacologic Therapies

- Varenicline (Chantix): Nicotine receptor partial agonist.
- Bupropion (Wellbutrin): Dopamine/norepinephrine reuptake inhibitor.
- Cochrane Review Results:
  - Varenicline > single NRT or bupropion.
  - Varenicline ≈ combination NRT (i.e., gum + patch).
- Peter’s advice: Start with NRT, then add one of these drugs if needed.

Supporting Behavioral Change

- Address hand-to-mouth fixation with replacements like:
  - Toothpicks
  - Nicotine toothpicks
- Additional tools:
  - Behavioral therapy
  - Group therapy
  - Accountability partners

Handling Relapse

- Relapse is common, especially after first attempts.
- Success often comes from repeated attempts.
- Self-compassion is crucial:
  - Avoid negative self-talk.
  - Use a self-talk script like: “*This does not invalidate my progress. It’s a data point, not a failure*.”
  - Identify what triggered the relapse and use it to improve the plan.

## The reasons behind weight gain after quitting smoking, the role of nicotine in appetite suppression, and strategies to manage weight [1:15:30]

**Weight Gain After Quitting Smoking: What to Expect and How to Manage It**

Why Weight Gain Can Happen

- Nicotine suppresses appetite and slightly increases metabolism, so:
  - Smokers are, on average, 6–10 pounds lighter than non-smokers (when adjusted for other variables).
- When nicotine is removed, metabolic rate and appetite may return to baseline, leading to:
  - Mild to moderate weight gain for most.
  - Significant weight gain (up to 30 pounds) for ~10% of quitters.

What the Data Shows

- 12-Month Prospective [Study](https://pmc.ncbi.nlm.nih.gov/articles/PMC6534411/) (approx. 350 participants):
  - ~50% successfully quit smoking.
  - Among those who quit:
    - ~100 maintained weight within 5% of baseline.
    - Only 18 gained more than 10% of body weight.
- **Key Insight**: Most quitters do not experience extreme weight gain. It’s a valid concern but should not deter quitting.

Potential Pharmacologic Solutions

- Peter explored the potential role of GLP-1 agonists (e.g., semaglutide, liraglutide) in preventing post-cessation weight gain:
  - Existing data on first-generation GLP-1 drugs showed no significant effect.
  - However, these older drugs were less effective overall, so their lack of impact may not apply to newer GLP-1s (like Ozempic/Wegovy).
  - Future research could be promising but doesn’t currently offer strong solutions.

Behavioral and Practical Solutions

- Part of the weight gain might be due to oral fixation, not increased appetite.
  - Solutions:
    - Use toothpicks or nicotine-free toothpicks to satisfy the hand-to-mouth habit.
    - Keep healthy oral habits in place of smoking (e.g., chewing gum, drinking water, brushing teeth after meals).
  - Acknowledging and addressing behavioral habits can reduce compensatory snacking and mindless eating.

---

## Selected Links / Related Material

**AMA episode of The Drive on microplastics**: [#332 – AMA #67: Microplastics, PFAS, and phthalates: understanding health risks and a framework for minimizing exposure and mitigating risk](https://peterattiamd.com/ama67/) | Peter Attia (peterattiamd.com) [2:00]

**Video of Peter explaining ways he’s reducing microplastics in his life**: [Five Ways to Reduce Your Microplastic Exposure | Peter Attia](https://www.youtube.com/watch?v=IsmBq0v50k4) | Peter Attia M.D. (youtube.com) [3:00]

**High doses of nicotine have been shown in mouse and rat models to increase tumor growth**: [Nicotine Promotes Tumor Growth and Metastasis in Mouse Models of Lung Cancer](https://pmc.ncbi.nlm.nih.gov/articles/PMC2759510/) (Davis et al., 2009) [13:30]

**2024 Mendelian Randomization Study on Nicotine which investigated whether nicotine metabolism genes are associated with disease risk and found that harmful responses came from non-nicotinic components of tobacco, not nicotine itself**: [Estimating the health impact of nicotine exposure by dissecting the effects of nicotine versus non-nicotine constituents of tobacco smoke: A multivariable Mendelian randomisation study](https://consensus.app/papers/estimating-the-health-impact-of-nicotine-exposure-by-khouja-sanderson/1fee3e4f05fc5bdb8f31f4de12a23fb6/?extracted-answer=Increased+nicotine+metabolism+increases+the+risk+of+COPD%2C+lung+cancer%2C+and+lung+function%2C+while+decreased+nicotine+exposure+decreases+heart+rate+and+lung+function.&q=What+are+the+benefits+and+harms+of+nicotine+use&pro=on&year_min=2020) (Khouja et al., 2024) [13:45]

**Most frequent symptom of nicotine use is nausea, especially in nicotine-naive individuals**: [Adverse events associated with nicotine replacement therapy (NRT) for smoking cessation. A systematic review and meta-analysis of one hundred and twenty studies involving 177,390 individuals](https://pubmed.ncbi.nlm.nih.gov/20626883/) (Mills et al., 2010) [18:15]

**The “Big Chief” scene in The Sandlot**: [THE SANDLOT “Big Chief” Clip (1993) Baseball Comedy](https://www.youtube.com/watch?v=nxM4ygJR5LI) | JoBlo Movie Clips (youtube.com) [21:00]

**Study that found nicotine having a negative impact on REM sleep, sleep efficiency, and total sleep**: [Dose-dependent effects of transdermal nicotine on early morning awakening and rapid eye movement sleep time in nonsmoking normal volunteers](https://pubmed.ncbi.nlm.nih.gov/7962682/) (Gillin et al., 1994) [21:30]

**Animal data suggesting, if extrapolated, that >5 mg of nicotine within 2–3 hours before bed likely impacts REM sleep and that ≤5 mg taken more than 3 hours before bed is less likely to impair sleep**: [Changes in sleep after acute and repeated administration of nicotine in the rat](https://pubmed.ncbi.nlm.nih.gov/10463313/) (Salin-Pascual et al., 1999) [22:3

**Rodent study shows that chronic nicotine use increases anxiety-like behaviors, even at low doses**: [Effects of chronic nicotine on the temporal structure of anxiety-related behavior in rats tested in hole-board](https://www.sciencedirect.com/science/article/abs/pii/S0278584619304890?via%3Dihub) (Casarrubea et al., 2020) [25:30]

**Neuroscientists have also shown that nicotine promotes anxiety by inhibiting the activity of dopamine neurons projecting from reward circuits to the amygdala, and blocking this inhibition can block nicotine’s anxiogenic effects**: [Nicotine inhibits the VTA-to-amygdala dopamine pathway to promote anxiety](https://www.cell.com/neuron/fulltext/S0896-6273(21)00428-1) (Nguyen et al., 2021) [26:00]

**There may also be differences in effect on mood in men vs. women**: [Nicotine has calming effects on stress-induced mood changes in females, but enhances aggressive mood in males](https://academic.oup.com/ijnp/article/4/4/371/617363) (File et al., 2001) [26:15]

**Nicotine may offer short-term antidepressant or calming effects in some individuals per a 4-week RCT**: [Transdermal nicotine attenuates depression symptoms in nonsmokers: a double-blind, placebo-controlled trial](https://link.springer.com/article/10.1007/s00213-006-0516-y) (McClernon et al., 2006) [28:00]

**Animal studies suggest addiction risk rises at approximately 30 mg of nicotine per per day**: [Dose, duration, and pattern of nicotine administration as determinants of behavioral dependence in rats](https://link.springer.com/article/10.1007/s00213-005-0037-0) (Vann et al., 2005) [31:00]

**But epidemiologic data (from humans) show risk may begin as low as 5 mg/day**: [Establishing a Nicotine Threshold for Addiction — The Implications for Tobacco Regulation](https://www.nejm.org/doi/full/10.1056/NEJM199407143310212) (Benowitz et al., 1994) [31:15]

**Episode of The Drive with Dr. Anna Lembke where she emphasizes how the context in which substances are used significantly affects the risk of dependence**: [#321 – Dopamine and addiction: navigating pleasure, pain, and the path to recovery | Anna Lembke, M.D.](https://peterattiamd.com/annalembke/) | Peter Attia (peterattiamd.com) [32:30]

**Epidemiological data supports that women often have lower success rates in smoking cessation compared to men**: [A Comparison of Quit Outcomes for Men and Women in a Smoking Cessation Program Offering Personalized Nicotine Replacement Therapy and Counseling in Primary Care Clinics](https://academic.oup.com/ntr/article-abstract/23/10/1673/6257701?redirectedFrom=fulltext) (Voci et al., 2021) [33:15]

**Evidence that Vapes / E-cigarettes have very rapid nicotine absorption**: [Nicotine: Sporting Friend or Foe? A Review of Athlete Use, Performance Consequences and Other Considerations](https://link.springer.com/article/10.1007/s40279-017-0764-5) (Mündel, 2017) [38:00]

**External website that links every single nicotine product out there, and it talks about its pH and even third-party testing on contaminants:** [nicoleaks.com](http://nicoleaks.com) [38:15]

**A review found 47 harmful compounds in E-cigarettes**: [A review of constituents identified in e-cigarette liquids and aerosols](https://pmc.ncbi.nlm.nih.gov/articles/PMC7873740/) (Eshraghian and Al-Delaimy, 2021) [41:15]

**Data regarding long-term use & dependency showing habitual use leads to tolerance, and when taken away, cognitive function dips below baseline (this dip resolves after a few weeks)**: [The Duration of Nicotine Withdrawal-Associated Deficits in Contextual Fear Conditioning Parallels Changes in Hippocampal High Affinity Nicotinic Acetylcholine Receptor Upregulation](https://pmc.ncbi.nlm.nih.gov/articles/PMC3278577/) (Gould et al., 2012) [45:00]

**Rodent studies suggest no lasting cognitive damage in adults after cessation—no permanent deficits in attention, learning, or impulsivity—once withdrawal phase passes**: [The Duration of Nicotine Withdrawal-Associated Deficits in Contextual Fear Conditioning Parallels Changes in Hippocampal High Affinity Nicotinic Acetylcholine Receptor Upregulation](https://pmc.ncbi.nlm.nih.gov/articles/PMC3278577/)  [45:00]

**Rodent models show lasting cognitive and emotional consequences from early-in-life nicotine exposure**: [Long-Lasting Cognitive Deficits Resulting from Adolescent Nicotine Exposure in Rats](https://www.nature.com/articles/npp200896) (Counotte et al., 2008) [48:30]

**In contrast to Alzheimer’s and Parkinson’s, nicotine has shown more promise in improving attention, learning, and memory in individuals with**: [51:45]

- Mild cognitive impairment: [The Effect of Low Dose Nicotine on Working Memory and Positive Emotion in Patients with Mild Cognitive Impairment](https://www.researchsquare.com/article/rs-1954093/v1) (Zamnia et al., 2022)
- Age-related cognitive decline: [Chronic transdermal nicotine patch treatment effects on cognitive performance in age-associated memory impairment](https://link.springer.com/article/10.1007/s00213-003-1614-8) (White and Levin, 2003)
- Cognitive impairment from chemotherapy: [Nicotinic treatment of post-chemotherapy subjective cognitive impairment: a pilot study](https://link.springer.com/article/10.1007/s11764-019-00786-6) (Vega et al., 2019)
- Psychiatric conditions like schizophrenia: [Randomized, Double-Blind, Placebo-Controlled Study of Encenicline, an α7 Nicotinic Acetylcholine Receptor Agonist, as a Treatment for Cognitive Impairment in Schizophrenia](https://www.nature.com/articles/npp2015176) (Keefe et al., 2015)

**A major ongoing study on the cognitive impact of nicotine—MIND (Memory Improvement through Nicotine Dosing)**: [Long-term nicotine treatment of mild cognitive impairment (The MIND Study): Baseline characteristics and study progress](https://alz-journals.onlinelibrary.wiley.com/doi/abs/10.1002/alz.064697) (Newhouse et al., 2023) [53:30]

**One rat study showed that caffeine exposure led to increased self-administration of nicotine**: [Effects of Caffeine on Alcohol Consumption and Nicotine Self-Administration in Rats](https://pmc.ncbi.nlm.nih.gov/articles/PMC3775986/#:~:text=Furthermore%2C%20chronic%20oral%20exposure%20to,et%20al.%2C%201994).) (Rezvani et al., 2014) [55:15]

**A small human study (20 participants, all nicotine-naive) evaluated the cognitive effects of nicotine and caffeine**: [Caffeine’s Influence on Nicotine’s Effects in Nonsmokers](https://pmc.ncbi.nlm.nih.gov/articles/PMC3209967/pdf/nihms-334427.pdf) (Blank et al., 2007) [56:00]

**Rodent studies show nicotine can negatively affect male fertility (reversible after a 30-day washout period)**: [Effects of nicotine on sperm characteristics and fertility profile in adult male rats: a possible role of cessation](https://pubmed.ncbi.nlm.nih.gov/23926503/) (Oyeyipo et al., 2011) [58:45]

**Epidemiologic study of ~1,200 men using E-cigarettes found a significant reduction in sperm count compared to non-users but the causal factors are unclear**: [Use of e-cigarettes associated with lower sperm counts in a cross-sectional study of young men from the general population](https://academic.oup.com/humrep/article/35/7/1693/5859935) (Holmboe et al., 2020) 59:15]

**Global smoking prevalence is around 15%**: [Tobacco use declines despite tobacco industry efforts to jeopardize progress](https://www.who.int/news/item/16-01-2024-tobacco-use-declines-despite-tobacco-industry-efforts-to-jeopardize-progress#:~:text=Currently%20the%20WHO%20South%2DEast,Oman%2C%20and%20Republic%20of%20Moldova.) | (who.int) [1:06:00]

**Quitting smoking resulting in CVD risk reduction, even rate reduction, and after 10–15 years, CVD risk is nearly identical to never-smokers**: [Association of Smoking Cessation With Subsequent Risk of Cardiovascular Disease](https://jamanetwork.com/journals/jama/fullarticle/2748507) (Duncan et al., 2019) [1:07:00]

**Study finding that nicotine replacement therapy (NRT) of replacing one cigarette with 1–2 mg of nicotine from NRT resulted in improved odds of smoking cessation**: [Nicotine replacement therapy versus control for smoking cessation](https://pmc.ncbi.nlm.nih.gov/articles/PMC6353172/) (Hartmann‐Boyce et al., 2018) [1:11:15]

**12-Month Prospective Study looking at weight gain after quitting smoking**: [Does everyone who quit smoking gain weight? A real-world prospective cohort study](https://pmc.ncbi.nlm.nih.gov/articles/PMC6534411/) (Jeremias-Martins et al., 2019) [1:16:15]

---

## People Mentioned

[Anna Lembke](https://peterattiamd.com/annalembke/) [32:30]