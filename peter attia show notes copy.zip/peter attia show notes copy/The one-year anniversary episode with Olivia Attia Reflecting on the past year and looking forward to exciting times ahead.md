# The one-year anniversary episode with Olivia Attia: Reflecting on the past year and looking forward to exciting times ahead

**Source:** [https://peterattiamd.com/oneyearanniversaryepisode/](https://peterattiamd.com/oneyearanniversaryepisode/)

---

In this anniversary episode, Olivia, Peter’s daughter who initially kicked off The Drive podcast with her [sneak peek episode](https://peterattiamd.com/sneak-peek-peter-attia-drive/), returns to ask Peter the tough questions on how the podcast is going, what he has learned along the way (and how he plans to make it better), what exciting things are in store for the future, and plenty more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/oneyearanniversaryepisode/the_Drive_public.png)

Play

The one-year anniversary episode with Olivia Attia: Reflecting on the past year and looking forward to exciting times ahead

The one-year anniversary episode with Olivia Attia: Reflecting on the past year and looking forward to exciting times ahead

1x15s30s

0:0016:48

## We discuss:

- Revisiting the question from 1 year ago: Does the world really need another podcast? [1:15];
- What have you learned about podcasting over the last year? [2:15];
- How many more podcast episodes do you plan to make? [4:20];
- How do you deal with negative comments? [5:00];
- What advice do you have for someone wanting to start their own podcast? [6:20];
- How did you manage to make a podcast despite your knuckleheaded tech skills? [7:40];
- Any guests you want to interview but have not yet? [9:30];
- Any new exciting things planned for the podcast? [10:25];
- Thanking the subscribers [13:30];
- Question for Olivia: Are you going to play a Zeppelin song for your next talent show? [14:30]; and
- More.

§

## Show Notes

## Revisiting the question from 1 year ago: Does the world really need another podcast? [1:15]

- “Probably not”
- There are 500+ new podcasts appearing every week
- However, Peter has been very surprised with how much he has enjoyed doing it after the initial 3 month experiment
- He was encouraged by the great feedback from listeners
- Plans to keep it going

## What have you learned about podcasting over the last year? [2:15]

- It’s way harder to do a good interview than he ever thought
- When listening to other podcasts, Peter now takes notes on how to be a better interviewer, ask good questions, etc.
- Examples of exceptional interviewers:
  - Tim Ferriss
  - Sam Harris
  - Steven Dubner
- Peter call him himself a 2 out of 10 in terms of his interview skills (1 out of 10 a year ago)
- In more technical episodes… Peter sees how someone not well versed can get lost and he wants to to a better job setting context for the listener
- In less technical episodes… he will frequently realize when listening back that he forgot to ask a great question or didn’t take a good opportunity to segway into an interesting topic which would be more valuable than the path that was taken
- “*Work in progress*”

## How many more podcast episodes do you plan to make? [4:20]

- Hopefully, **a lot more**
- Currently, we are recording faster than we can release them
- Peter has an endlessly growing spreadsheet of people he wants to interview (“probably 3 years worth”)

## How do you deal with negative comments? [5:00]

- When commenters disagree with something, it doesn’t bother Peter (“healthy discourse”)
- The bothersome comments are the ones that are just people being nasty
- Peter uses a simple technique:
  - Just ask yourself, “*is this true?*”
  - If the answer is “*no*”, it becomes much easier to just dismiss the comment as nonsense
- (Another strategy is just to refrain from reading too many comments on social media)

## What advice do you have for someone wanting to start their own podcast? [6:20]

- Make sure the topic you choose is super fascinating to you ⇒ You must enjoy it so much that you are willing and able to do the research and prep work to do a good job when interviewing someone
- Another route is doing a podcast where it is you doing most of the talking, such as [Jocko Willink](https://twitter.com/jockowillink) on [Jocko Podcast](https://jockopodcast.com/) (Although, this might actually be *harder* to do a job than interviewing a guest)
- In the end, the podcast should be something that YOU would want to listen to
  - The audience will find you rather than the reverse
  - Audience may be small, but you’ll have a passionate and supportive group of people

## How did you manage to make a podcast despite your knuckleheaded tech skills? [7:40]

- “*I have a kickass team*”
- Peter’s job is to just record the interview (Thankfully, operating the equipment is pretty simple)
- Prior to the interview, [Bob Kaplan](https://twitter.com/bobkaplan?lang=en) and Nick Stenson do the research about the guest and their field to make sure Peter is prepared with the interview
- After the interview, our production guy, [Mathew Passy](https://twitter.com/MathewPassy) will do the sound editing
- Finally, [Travis Denson](https://twitter.com/tden185) is in charge of making the behemoth show notes for every episode

## Any guests you want to interview but have not yet? [9:30]

- “*Yes, a ton of people.*”
- In some cases, guests are willing and able, but we haven’t been able to align schedules
- There’s also a subset of people that have either not responded or just said “no”
- Hopefully, as the podcast grows, more people will see value in being a guest on The Drive

## Any new exciting things planned for the podcast? [10:25]

- **Yes!**
- Launching “[Qualys](https://peterattiamd.com/podcast/qualys)” in the summer of 2019
- Currently, episodes of The Drive are the long-form, deep dives
- The “Qualys”, named after a “qualifying lap” in Formula 1, are going to be *fast*, easily digestible, short **clips from past episodes**
- There is so much old content ripe with great information, but it might be hard for a new listener to get “caught up”
- Coming soon, we will be releasing a “Qualy” episode every Tuesday through Friday

\*Note: Qualys are for subscribers only

## Thanking the subscribers [13:30]

\*Thank you, thank you, thank you! The podcast is only possible because of our subscribers.\*

- The subscriber model is in lieu of selling ads
- Peter prefers to only talk about products that he actually uses and enjoys, not something he is being paid to talk about
- Peter and the team are constantly trying to come up with ways to create more and more value to subscribers
- The Qualys are one example, but more things in the pipeline as well

[*CLICK HERE*](https://peterattiamd.com/subscribe/) *to learn more about becoming a subscriber*

## Question for Olivia: Are you going to play a Zeppelin song for your next talent show? [14:30]

- Olivia plays drums and she’s planning for her next talent show
- Peter wants to know if she will do a Led Zeppelin song?
- Olivia is not so sure
- But at least she knows how talented the great [John Bonham](https://en.wikipedia.org/wiki/John_Bonham) is…

§

## Selected Links / Related Material

**The original episode with Olivia Attia from one year ago**: [#00 – Sneak peek: The Peter Attia Drive](https://peterattiamd.com/sneak-peek-peter-attia-drive/)

**The Jocko Willink episodes of the The Drive that Olivia mentioned**:

- Part 1: [#55 – Jocko Willink, retired Navy SEAL, Part I of II: objective, strategy & tactics, leadership, protocols, dealing with death, and applying the many lessons learned from war](https://peterattiamd.com/jockowillink1/)
- Part 2: [#56 – Jocko Willink, retired Navy SEAL, Part II of II: Sleep, fasting, raising kids, discipline, taking ownership, and the impact of war](https://peterattiamd.com/jockowillink2/)

**The Tim Ferriss episode of The Drive**: [#01 – Tim Ferriss: depression, psychedelics, and emotional resilience](https://peterattiamd.com/timferriss/)

**Learn more about becoming a subscriber**: [Subscribe to Support the Site](https://peterattiamd.com/subscribe/)

**Led Zeppelin song mentioned**: [Stairway To Heaven](https://en.wikipedia.org/wiki/Stairway_to_Heaven)

§

## People Mentioned

- [Tim Ferriss](https://twitter.com/timferriss?lang=en) (example of an exceptional interviewer)
- [Sam Harris](https://twitter.com/SamHarrisOrg) (example of an exceptional interviewer)
- [Steven Dubner](https://en.wikipedia.org/wiki/Stephen_J._Dubner) (example of an exceptional interviewer)
- [Jocko Willink](https://twitter.com/jockowillink) (Jocko Podcast, previous guest on The Drive)
- [Bob Kaplan](https://twitter.com/bobkaplan?lang=en) (research for show prep)
- Nick Stenson (research for show prep)
- [Mathew Passy](https://twitter.com/MathewPassy) (podcast producer and sound editor of The Drive)
- [Travis Denson](https://twitter.com/tden185) (show notes guy)
- [John Bonham](https://en.wikipedia.org/wiki/John_Bonham) (drummer for Led Zeppelin)

§