# #212 – The neuroscience of obesity | Stephan Guyenet, Ph.D.

**Source:** [https://peterattiamd.com/stephanguyenet/](https://peterattiamd.com/stephanguyenet/)

---

Stephan Guyenet is a neuroscientist focused on the neuroscience of obesity and energy homeostasis.  He is the author of the book, [*The Hungry Brain*](https://www.amazon.com/Hungry-Brain-Outsmarting-Instincts-Overeat/dp/125008119X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1649439652&sr=8-1) and founder/ director of [*Red Pen Reviews*](https://www.redpenreviews.org/). In this episode, Stephan explains how obesity has changed phenotypically over the course of human history as well as what might explain the dramatic increase in prevalence of obesity in the last few decades. He talks in depth about the role of genetics, the brain, and hormones like leptin play in the regulation of fat mass. He dives deep into two common theories of obesity—the carbohydrate-insulin model and the energy balance model and provides his take on which theory has stronger evidence. Additionally, he provides insights on how we’re hard-wired to think about food and the consequences of modern foods designed for maximal pleasure. Finally, he goes through the factors that affect body weight, set points, and provides takeaways for people wanting to take advantage of what we know about the brain’s role in regulating our body weight.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/stephanguyenet/the_Drive_public.png)

Play

#212 - The neuroscience of obesity | Stephan Guyenet, Ph.D.

1x15s30s

0:002:24:59

## We discuss:

- Stephan’s neuroscience background and his focus on the nuances of obesity [2:15];
- How obesity has changed for humans throughout history [8:00];
- The association between obesity and adverse health outcomes, the “obesity paradox,” and confounders when relating BMI to longevity [14:00];
- The sharp increase in obesity across demographics [23:30];
- The hypothalamus and its role in obesity [30:00];
- The role of the hormone leptin in obesity [40:00];
- The genetic component of obesity [46:30];
- Understanding the tendency of humans to store fat through an evolutionary lens [57:00];
- The hedonic aspect of food, and how the brain reacts to modern, highly-rewarding foods [1:03:30];
- How we are hard-wired to think about food [1:14:30];
- A review of the “Carnivore diet” [1:21:45];
- The energy balance model, carbohydrate-insulin model, and unifying the theories around adiposity [1:34:15];
- Body weight set points: a hypothetical comparison of two individuals [1:41:45];
- Takeaways for people who want to lose weight and keep it off [1:48:30];
- Evidence that favors the energy balance model of weight gain [1:56:00];
- The synergistic effect of fat and carbohydrates and observations that a low-fat diet or a low-carb diet can cause weight loss [2:04:30];
- Red Pen Reviews [2:11:00];
- More.

§

## Show Notes

**\*Notes from intro:**

- Stephan Guyenet is a neuroscientist and a passionate communicator about the science of obesity and many aspects of health
- His research has focused on neurogeneration early in his career, and more recently, the neuroscience of obesity and energy homeostasis
- His scientific publications have been cited more than 3,600 times
- He’s the author of a book published in 2017, [*The Hungry Brain*](https://www.amazon.com/Hungry-Brain-Outsmarting-Instincts-Overeat/dp/125008119X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1649439652&sr=8-1)
- He’s also the founder and director of [*Red Pen Reviews*](https://www.redpenreviews.org/) which publishes informative, consistent and unbiased reviews of popular health and nutrition books
- He is a review editor at *Frontiers in Nutrition*
- In this episode, we talk about his background and what led him to get to where he is today
- We talk about obesity and how it’s changed phenotypically over the last thousand years
  - Specifically looking at US rates of obesity over the past, probably 150 years
- We talk about what the brain has to do with obesity, the role of leptin and the genes that regulate fat mass and obesity
- We talk about the hedonic aspects of food and how our taste today is different than obviously what our ancestors tasted
  - And how energy and chloric density relate to taste and how we potentially select foods
- We discuss the carnivore diet and Red Pen’s review of the carnivore diet
- We speak about the energy balance model, the carbohydrate insulin model, and unifying theories around adiposity

## Stephan’s neuroscience background and his focus on the nuances of obesity [2:15]

**Stephan’s path to becoming one of the most thoughtful people on the nuances of obesity**

- Stepahn was a biochem major as an undergrad, but had neuroscience in mind
  - His idea was that biochem would provide a foundation for going into neuroscience later
- He did his PhD with [Al LaSpada](https://www.faculty.uci.edu/profile.cfm?faculty_id=6967) at the University of Washington studying neurodegenerative disease
- He stayed at the University of Washington for a postdoc with [Mike Schwartz](https://endocrinology.uw.edu/faculty/michael-schwartz-md)
- He has always been fascinated by the brain, but didn’t know which area of neuroscience he wanted to get into for a long time
- He became interested in neurodegenerative disease for a few different of reasons:
  - 1 – They’re just absolutely horrible diseases
  - 2 – His grandmother had Alzheimer’s disease
- In grad school he was studying a class of neurodegenerative diseases called [triplet repeat diseases](https://en.wikipedia.org/wiki/Trinucleotide_repeat_disorder)
  - This includes [Huntington’s disease](https://en.wikipedia.org/wiki/Huntington%27s_disease)
  - They are also called polyglutamine repeat diseases
- The genetics of Huntington’s disease are complex and interesting
  - It’s [non-Mendelian](https://en.wikipedia.org/wiki/Non-Mendelian_inheritance) because the length of the CAG repeat actually changes intergenerationally
  - The weird thing about it is these CAG repeats are unstable in replication
    - Theycode for polyglutamine structures in the protein
  - You tend to see an [enlargement](https://en.wikipedia.org/wiki/Trinucleotide_repeat_expansion) of these polyglutamine repeats from one generation to the next
    - So it has this really weird non-Mendelian pattern
  - The [penetrance](https://en.wikipedia.org/wiki/Penetrance) is pretty high, meaning if you have this repeat of a certain length, you are going to develop disease
    - But it’s not 100% fixed
- Stephan was studying a less common disease called SCA7, [spinocerebellar ataxia](https://en.wikipedia.org/wiki/Spinocerebellar_ataxia) type 7
  - Not many people have this disease
- He had always been interested in fitness and nutrition
- So when he started learning about the neuroscience of obesity during his PhD work, he got really into it
  - This was a way to satisfy his desire for impactful research
  - He realized there was a ton of information on this topic that was incredibly enlightening and not making its way to the public

**At what point, finishing up your PhD did you connect with Mike?**

- He was interested in obesity and wanted to stay at the University of Washington for personal reasons
  - Staying at the same institution after your PhD is atypical but he was not a big fan of the typical academic thing
- Mike’s lab was a really good fit
  - He was a postdoc with him until 2013
- Peter remembers meeting Stephan at a conference in 2012, 10 years ago

## How obesity has changed for humans throughout history [8:00]

- Humans have been around for maybe 6 million years

*What has changed over the last 1000 years in terms of our phenotype?*

- Thinking of body shape of people in modern, affluent societies (like the US) compared to a typical human 1000 years ago, we are much fatter
- 1000 years ago there was obesity among the wealthy, probably for similar reasons that we have obesity today
  - There is evidence of this from Egyptian mummies
  - Certainly the prevalence was much lower
- Just to be clear, we’re defining obesity in the most traditional way as a [BMI (body mass index)](https://en.wikipedia.org/wiki/Body_mass_index) of more than 30
  - The advantage of BMI is it’s really easy to measure and you can calculate it from these really simple measures that go back a long time
  - Unfortunately they didn’t have DEXA machines in 1890, which would’ve been a more informative way of looking at it

**How BMI has changes in recent history**

- 120-130 years ago only a few % of people (low single digits) had a BMI > 30
- More recently, we start to have really good data in the US in 1960 when the [NHANES (national health and nutrition examination survey)](https://en.wikipedia.org/wiki/National_Health_and_Nutrition_Examination_Survey) began
  - The % of people who are obese by this measure has gone up from the late 1800’s to maybe 12% of adults in the US
- The category of extremely obese refers to a BMI over 35
  - There is class 1, class 2, and class 3 obesity; these correspond to a BMI of around 30, 35 and 40 (see the table below)

![](https://peterattiamd.com/wp-content/uploads/2022/06/f1-guyenet.png)

**Figure 1.  Basic BMI categories.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Body_mass_index)

- More recently, the median BMI has increased too
- The most extreme changes happened in the more severe obesity category
  - Very few people had BMIs > 35 in the earliest measures
  - Today 9-10% of adults have a BMI > 35
- The distribution of BMIs used to be a lot tighter too; today it has spread out
  - This difference is illustrated in the figure below, where the blue line can be thought of as the ancestral distribution of BMI and the red line the current distribution of BMI
  - The blue line shows a tighter distribution where the standard deviation is less than the red line (a larger standard deviation)

![](https://peterattiamd.com/wp-content/uploads/2022/06/f2-guyenet.png)

**Figure 2.  Comparison of a tight and spread-out distribution of a trait in a population.**  Image credit: [Statistics by Jim](https://statisticsbyjim.com/basics/normal-distribution/)

- There are still people in every BMI category but since it is more spread out, there is a disproportionate increase at extreme values (illustrated in the red curve above)

**Is this true for the underweight category?**

- Typically the cutoff for underweight is 18.5
- Stephan is not sure what the fraction of this category would be in 1900; he thinks it was higher than today

## The association between obesity and adverse health outcomes, the “obesity paradox,” and confounders when relating BMI to longevity [14:00]

- 1000 years ago, Egyptian aristocrats would have viewed obesity as a sign of affluence
  - In medical school, Peter remembered learning how [gout](https://en.wikipedia.org/wiki/Gout) emerged about his time
    - This is a disease of excess‒ excess alcohol, excess sugar, excess protein
    - This was a rich man’s disease
- There were physicians in ancient Greece, in India, who recognized that being very heavy was associated with health problems, such as having sweet-tasting urine (a sign of [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes))
- There were insurance life tables in the early 1900 that suggested that people who had obesity had shortened lifespans and greater risk of certain diseases
- This became controversial with a series of studies about the “[obesity paradox](https://en.wikipedia.org/wiki/Obesity_paradox)” that [Katherine Flegal](https://en.wikipedia.org/wiki/Katherine_Flegal) was involved in
  - This was discussed in a recent episode, [#197 – The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.](https://peterattiamd.com/davidallison/)
  - In these studies, looking at a graph of the relationship between BMI and longevity, the nadir (the lowest point on the graph) was in the overweight range (shown in the figure below)
  - This finding was repeated in meta-analyses of millions and millions of people

![](https://peterattiamd.com/wp-content/uploads/2022/06/f3-guyenet.png)

**Figure 3. The relation between longevity and obesity in humans.**  Image credit: [*PNAS* 1958](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC528632/)

- This had people suddenly saying, “*Well, maybe higher body fatness is not bad. Maybe it’s actually protective.*”
- The reason this is called a paradox is because there is lots of evidence that excess body fat contributes to all kinds of diseases: type 2 diabetes, cardiovascular disease, certain cancers

***How could obesity be productive for mortality when it’s driving all these diseases that are the leading causes of mortality?***

- This is why it’s called the “obesity paradox”

**Research has come out since then suggesting this is an artifact of the observational data**

- There are probably a few things going on
- The biggest one is, people who are sick often lose weight
- There are lots of health conditions that cause people to lose weight: poorly controlled type 2 diabetes, renal failure, chronic obstructive pulmonary disease (COPD), Alzheimer’s disease, cognitive decline

**Leanness can be confounding**

- *The concern was, this makes leanness look worse than it really is*
  - Many people in the lean category are not sick
- People have called this [reverse causation](https://en.wikipedia.org/wiki/Correlation_does_not_imply_causation#B_causes_A_(reverse_causation_or_reverse_causality)), but [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) corrected him; the technical term is [confounding](https://en.wikipedia.org/wiki/Confounding)
  - Peter’s recent surgery is an illustrative example
  - He had shoulder surgery less than 3 weeks ago
  - In the 18 days since his surgery, he’s lost 9 lbs
  - His BMI probably went from 26 to 24
  - On paper, this looks good, but he would argue there is nothing superior about his health today compared to 18 days ago
  - Of the 9 lbs he’s lost, probably 7 lbs were lean body mass
  - ***This shows how an improvement in BMI can occur with a deterioration in body composition***
- BMI is a crude measure but it’s useful for a population-level study
  - It can be useful for screening

**How do you get around the issue of confounding?**

- Stephan likes one [method](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3985598/) developed by [Andrew Stokes](https://www.bu.edu/sph/profile/andrew-stokes/) and his colleagues
  - This is the maximum attained weight method
  - Instead of correlating your current BMI with mortality risk, it asks the question “*What’s the heaviest you’ve ever been, and how does that correlate with your health outcomes?*”
  - This aims to screen-out an health conditions you may have developed that might have caused you to lose weight
- With this method, it sharpens the association between BMI and mortality
  - The nadar (lowest point on the graph of lowest longevity) now shifts to a lower BMI
  - ***Now a BMI in the lean range looks best***
  - Further, there is a larger difference between being the mortality of people who are lean and those who are obese
  - This analysis excludes a bunch of people who were formerly in the obese category; it puts them in a lower category
    - Their health outcomes are terrible
    - Those who used to be classified as obese are now just overweight or lean
    - But they have massively elevated rates of chronic disease and mortality
    - ***They are bringing all this excess mortality into the lower weight categories***

*This sounds like horrible news.  It suggests that if your BMI is 33, all hope is lost.  If you bring your BMI down to 26, you don’t assume the health of people in this category.  This doesn’t sound right either.*

- Another limitation of the observational data is it’s hard to lose a lot of weight
  - And keep it off
  - It’s hard to go from a BMI of 35 to 25
- People who are losing weight have predominantly unintentional weight loss

**How does** [**bariatric surgery**](https://en.wikipedia.org/wiki/Bariatric_surgery) **affect this?**

- The data for people with type 2 diabetes taking [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) indicate this reduces all-cause mortality in a meta-analysis of randomized control trials
- Stephan notes, “*It will be interesting to see whether that extends to people without type 2 diabetes”*

## The sharp increase in obesity across demographics [23:30]

**From an epidemiologic standpoint, when do obesity rates take off?**

- Back in the 60s we may have been at 12% obese
- It’s hard to imagine this low figure given today it is 43% obese
- Stephan points out, “*Probably a lot of people listening will have seen graphs of NHANES data where it kind of spikes around 1980*.”
  - The 1980 data was actually a multiyear survey that spanned somewhere around ‘76-‘84
  - 1978 was about the average of that data
  - Today the range is much narrower
- So we don’t know exactly when obesity rates began to go up, but it is somewhere in the range of ‘76-‘84
- Currently we have a sharper focus on changes in dietary intake because of the annual data from the [USDA Economic Research Service](https://www.ers.usda.gov/topics/food-choices-health/food-consumption-demand/)
- The data on BMI are less sharp
- During this time period (‘76-‘84) big changes happen to the diet
- Somewhere from the late 70s – early 80s obesity went from around 15% to 43% of US adults
  - This includes people where 20 years old
  - So if you look at the lifetime risk, it’s well over 50%

> “*More than half of US adults will be classified as actually having obesity at some point in their life if the current context is maintained*”‒ Stephan Guyenet

- The same is true for type 2 diabetes
  - The prevalence of all diabetes is around 10-12%
  - The lifetime risk is double that‒ *it’s mind blowing the number of people who will, at some point in their life, develop type 2 diabetes*
- Peter adds, over the last 50 years, if you consider the prevalence of type 2 diabetes, this disease has gone up 5-fold

***In the US (and developed nations), obesity is no longer a condition of affluence*** ***at the individual level***

**How does obesity in the rest of the world compare to the US?**

- There is still not a lot of obesity in the poorest people in the world
  - Places challenged with food security, where the diet is very limited
  - Such as subsistence farmers in Sub-Saharan Africa

*If you looked at the bottom 10% of the population economically in the US and compared it to the top 10% economically, is there a difference in obesity?*

- Yes
- But if you’re looking in tertiles to compare the bottom third to the top third, there’s very little difference
- You can start to see larger differences emerge when you start analyzing it by sex and race
  - Women in the top tertile are leaner than women in the bottom tertile
  - There’s no difference for men in terms of income

> “*My overall feeling though, is that there is no demographic in the United States that has not gotten a lot fatter over the last few decades*”‒ Stephan Guyenet

## The hypothalamus and its role in obesity [30:00]

**What does the brain have to do with obesity?**

- [Rudy](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md) was on the podcast 2-3 years ago, so now is a good time to review the neurobiology of the hypothalamus and its regulation of energy expenditure and appetite
  - [#33 – Rudy Leibel, M.D.: Finding the obesity gene and discovering leptin](https://peterattiamd.com/rudyleibel/)
- 1 – The brain is the organ that generates behavior
  - Behavior relates to body fatness in terms of how much we eat, how we use our bodies, how we sleep, whether we’re stressed or not
  - *Most people would agree that food intake, quantity and quality are pretty important*
- 2 – The brain contains a regulatory system for body fat mass
  - This is located in the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus), which has been described by [Herman Pontzer](https://scholars.duke.edu/person/Herman.Pontzer) [in his book [*Burn*](https://www.amazon.com/Burn-Research-Really-Calories-Healthy/dp/0525541527/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651495897&sr=8-1)] as being “*like a wad of bubble gum on the bottom of your brain near where your optic nerves cross, so it’s this little tiny part of the brain that specializes in homeostasis or maintaining the stability of body systems*”
    - Peter describes it as a walnut
- The hypothalamus regulates body temperature
  - There’s a thermostat in there and thermometers that measure your core temperature
- Thermometers on your skin measure future threats to your core temperature
  - For example, if you jump into a cold lake, your core temp doesn’t instantly drop
  - But your brain knows it will drop because of the temperature sensors in your skin
  - So your brain can respond adaptively
  - The hypothalamus engages a suite of behavioral and physiological responses to maintain temperature homeostasis
  - On the physiology side, you get vasoconstriction, nonshivering thermogenesis through brown fat, shivering
  - And then through the behavioral side, you want to get out of the cold water, put a sweater on, drink some hot tea; you want to adopt a heat-conserving posture
- Through this coordinated physiology and behavior, you get incredible regulation of temperature, of core temperature plus or minus 1o F when the exterior temperature could be varying by 50o
  - This is an example of the type of regulation the hypothalamus specializes in

***Unfortunately, the body fat regulatory system is not so precise***

> “*A nice name for that is the lipostat*”‒ Stephan Guyenet

- A nice name for the regulatory system for body fatness is the lipostat
- Lipo meaning fat and stat meaning the current state of

**Evidence of the connection between the hypothalamus and obesity**

- In 1840 the Viennese physician Bernhard Mohr published a case study about a woman who had extreme obesity, rapid onset extreme obesity
- He did an autopsy after her death, and she had a tumor in her hypothalamus

*How much of her obesity was due to hyperphagia (excess eating) versus loss of activity or shutdown of metabolic rate?*

- The closest experimental analog of hypothalamic obesity would be [VMH (ventromedial nucleus of the hypothalamus)](https://en.wikipedia.org/wiki/Ventromedial_nucleus_of_the_hypothalamus) lesion
  - This lesion has been performed very precisely in animals since the ‘20s using a [stereotaxic device](https://en.wikipedia.org/wiki/Stereotactic_surgery)
  - As soon as the anesthesia wears off, these animals are cramming food into their faces
    - If there’s no food in their cage, they’ll eat bedding
    - They have extreme [hyperphagia](https://en.wikipedia.org/wiki/Polyphagia)
  - They continue binging until they have rapidly gained a large amount of weight (it will start to plateau off)
- Experiments have been done with animals that have a VMH lesion
  - 1 – If you restrict them to a normal level of calorie intake, it prevents weight gain
    - ***This suggest that weight gain is due to hyperphagia (excess eating)***
  - 2 – Later experiments showed that control of calorie intake didn’t completely eliminate weight gain, only about 80% of the weight gain was eliminated
    - ***This suggests an energy expenditure component***
    - The weight gain is thought to be mostly due to hyperphagia but also in small part, to changes in energy expenditure

**What have we learned about the lipostat and circulating factors that might play a role in governing it?**

- The simple explanation‒ there is a [negative feedback](https://en.wikipedia.org/wiki/Negative_feedback) system in the hypothalamus (similar to your home thermostat) that measures levels of a circulating hormone called [leptin](https://en.wikipedia.org/wiki/Leptin)
  - Leptin circulates in proportion to your body fat mass
    - So the same way your home thermostat measures the temperature in your home, your hypothalamus is measuring the level of leptin in your circulation
  - There’s still some controversy about how exactly or where that measuring happens, but the signal gets to the hypothalamus
  - ***The hypothalamus determines if you have the amount of fat it wants you to have***
    - So the same way that your thermostat has a set point and your internal thermostat in your body has a set point, your hypothalamus has a certain idea of how much fat it wants you to have on your body
    - If you deviate from that, it starts to engage a coordinated series of physiological and behavioral responses to restore the previous level of body fat

> “*This system works better at protecting against fat loss than it does against fat gain*”‒ Stephan Guyenet

- Over long periods of time, the average person in this country tends to gain fat
  - The lipostat is not preventing this, it might be resisting but will not stop the process of weight gain
  - The lipostat will vigorously defend against weight loss
- Stephan notes, “*This is part of the cruelty or the unfairness of how obesity works… your set point is your defended level of body weight*”
- There is controversy about what to call the set point, but your body and brain will defend against weight loss as if you were starving
  - This happens in both lean and obese

> “*A person with obesity, their body defends against weight loss as if they were starving*”‒ Stephan Guyenet

- It’s literally a starvation response
  - It’s the same behavioral and physiological process that ramps up your hunger
    - It makes you more focused on food queues, with greater cravings
  - It downregulates your energy expenditure
  - It does everything it can to try to bring the fat back,

***That is a key reason and possibly the primary reason why weight loss is so difficult and so temporary***

- Without this regulation, weight loss would probably be pretty easy
  - Weight maintenance certainly would be easy, but it’s not
  - People tend to regain back to their former level unless there extremely well-supported in that weight loss
    - And even then there is usually some amount of weight regain

## The role of the hormone leptin in obesity [40:00]

[**Leptin**](https://en.wikipedia.org/wiki/Leptin) **is made in the adipocyte and secreted in proportion to body fat mass**

- The more adipose tissue you have, the more leptin you have
- Leptin is also strongly impacted by short-term energy balance
  - Let’s say cut your calories by 25% for a couple of days, you’re going to see a drop in leptin that is disproportionate to your amount of fat mass
- There are [leptin receptors](https://en.wikipedia.org/wiki/Leptin_receptor) in many parts of the body, but the ones that are relevant for body weight regulation are in the brain
  - There are a high concentration of leptin receptors in the hypothalamus
  - They’re in other parts of the brain too
  - It’s not 100% clear where the important ones are for body weight regulation
- In mouse models where the leptin receptor is knocked out (removed) from the [GABAergic](https://en.wikipedia.org/wiki/GABAergic) cells, the animals respond as if they don’t have leptin receptors at all (in terms of weight gain)
  - [GABA](https://en.wikipedia.org/wiki/%CE%93-Aminobutyric_acid) is the main inhibitory [neurotransmitter](https://en.wikipedia.org/wiki/Neurotransmitter) in the brain
- You can knock the leptin receptor out of certain cell subtypes in the hypothalamus and get big effects
  - One paper suggested you can just knock it out of [AgRP](https://en.wikipedia.org/wiki/Agouti-related_peptide) neurons and recapitulate the obesity phenotype of animals that have no leptin receptor
    - This is controversial, not all papers show this
- Probably the most important cells with the leptin receptor are in the hypothalamus
  - The hypothalamus receives this message and conveys it to the key cell types at the center of this lipostat‒ **the AgRP neurons**
- In his [book](https://www.amazon.com/Hungry-Brain-Outsmarting-Instincts-Overeat/dp/125008119X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1649439652&sr=8-1), Stephan refers to the AgRP neurons as **NPY neurons** (for simplicity)
  - More commonly they’re called [AgRP](https://en.wikipedia.org/wiki/Agouti-related_peptide) neurons and [POMC](https://en.wikipedia.org/wiki/Proopiomelanocortin) neurons
  - The AgRP, those are the hunger neurons
  - The POMC, those are the satiety neurons
    - Or you could think of them as hunger/body fat-increasing neurons
    - The POMC are essentially the opposite of the AgRP

**Explaining leptin resistance**

- Leptin was discovered first in 1994 by a team led by [Jeff Friedman](https://www.rockefeller.edu/our-scientists/heads-of-laboratories/1163-jeffrey-m-friedman/) and [Rudy Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md)
  - They found this was the gene missing in an obese mouse model called the [*ob/ob* mouse](https://en.wikipedia.org/wiki/Ob/ob_mouse)
  - The animal was extremely obese as a result of lacking a defect in the production of this protein (leptin)
  - One single base pair that destroyed this protein and caused loss of function and this massive obesity
- There was a scientific bonanza when it was discovered and that humans too have leptin
  - Many thought that maybe people with obesity don’t have enough leptin, so their brains think they don’t have enough body fat when in reality they do
- The failure to perceive the body fat, that’s what causes obesity in these *ob/ob* mice
- They started measuring leptin levels in people with obesity, and it turns out they were actually elevated

***We now know that leptin levels are correlated with fat mass***

*What’s the deal? If this is a hormone that regulates body fatness, why is it that people with obesity have so much of it and it’s not suppressing their excess body fat mass?*

- The concept that has been invoked to explain this is ***leptin resistance***
- So in the same way that people can develop insulin resistance where it takes more insulin to do the physiological jobs in the body, people with obesity require more leptin for the hypothalamus to be satisfied
- Explained another way, ***obese people require more leptin to avert the starvation response***
  - Where the brain has alarm bells that start going off because it thinks you don’t have enough body fat
- Questions about leptin resistance:
  - Are there fewer leptin receptors on a certain kind of cell?
  - Is their impairment of downstream signaling affecting [intracellular signaling cascades](https://en.wikipedia.org/wiki/Signal_transduction)?
  - Is there a change in cell to cell communication?
    - Maybe the cell that’s receiving the leptin is getting the message just fine, but there’s some kind of downstream change in neural processing where the signal gets clouded or modified
    - We don’t know the answer to that question

**Peter’s summary: we know the problem in obesity is not that leptin levels are too low because of 2 observations**

- 1 – There are high levels of leptin in circulation in obese people
- 2 – Giving obese people exogenous leptin doesn’t improve their condition
- Stephan notes, “*You can give high levels of leptin and it will cause weight loss, but it doesn’t do much*”
- Early animal studies of leptin signaling in the hypothalamus suggest that the intracellular signaling cascade activated by leptin is *not* impaired in obese animals

> “*It’s like they’re getting the same leptin signal from a much higher level of leptin*”‒ Stephan Guyenet

## The genetic component of obesity [46:30]

- - Peter notes, [studies](https://www.frontiersin.org/articles/10.3389/fendo.2012.00029/full) in [identical twins ( MZ twins](https://en.wikipedia.org/wiki/Twin#IdenticalTwins)) show ***obesity has a heritability of 0.7***
    - He was surprised at how large this is
    - This level of heritability tells you that something is very, very genetically predetermined
    - So even though 100 years ago, virtually none of us were obese, today your lifetime incidence of obesity if 50%

- *Our genes haven’t changes in 100 years, so clearly our susceptibility for obesity has been with us for a great period of time and is highly preserved*

**What in our environment in the last 50 years has allowed obesity to flourish?  What do we know about the genes that regulate obesity?**

- [Meta-analysis of twins studies](https://www.frontiersin.org/articles/10.3389/fendo.2012.00029/full) suggest an average heritability of 75% for obesity
  - The heritability of body mass index (BMI) is very high
  - About 75% of those differences between people is explained by their genetics
- [Genome-wide association studies (GWAS)](https://en.wikipedia.org/wiki/Genome-wide_association_study) are used to ask the question, “*If we look at the entire genome, and we look at these representative genetic markers where different people have different genetic code called* [*SNPs (single-nucleotide polymorphisms)*](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism)*, where in the genome/ what markers correlate with differences in body mass index?*”
  - BMI is really easy to measure, so you can get really big sample sizes in this studies
    - This is needed to get statistically significant results
    - You’re looking at millions of people
    - There are also a lot of genomic markers, so tremendous statistical power is needed to detect anything with a high level of confidence
    - The [latest of these studies](https://academic.oup.com/hmg/article/27/20/3641/5067845) is on the order of 800,000 people
  - An example of studies that have saturated heritability are GWAS studies of height; they looked at around 3 million people
    - These studies have gotten all the information they can about common genetic variants that correlate with differences in height
  - Stephan thinks studies of BMI will be saturated in the near future
    - Soon we may know all the common genetic differences that correlate with differences in BMI
  - So far, GWAS have identified 900 venetic variants
    - ***This suggests that differences in BMI between individuals are genetically very complex***
    - BMI is determined by a lot of different genes with very small effect sizes
    - ***So you’re getting this sorting of all these different genes and whatever combination you get determines whether you are susceptible or not to obesity in a fattening environment***
- There are various ways of looking at what these genes are doing
- One is to look at the underlying biology that makes some people fatter and some people slimmer
- If you look at people in their regular everyday context, you can ask what genes correlate with a high BMI or a low BMI
  - These studies are very naturalistic and replicable (meaning, if you do 3 studies of this nature, you tend to get similar results)
  - This is a rigorous and objective study
  - It’s not hypothesis-driven so there is little bias
  - It’s simply looking for a [correlation](https://en.wikipedia.org/wiki/Correlation)
  - Peter adds, “*Part of that comes from the strength of what ultimately makes genetic analyses like Mendelian randomization so powerful is the genes are randomly distributed…you are looking at a million people for whom the genes are randomly spread across them*”
    - It’s very powerful if you get the same results over and over again from an unbiased sample

**BMI is linked to brain biology [52:15]**

*From a teleological viewpoint, why is it that only 50% of us will become obese in our lifetime?  Why not 100%?*

- 1000 years ago, none of us were obese but 50% of us had the genes that would allow us to become obese in an obesogenic environment
- Stephan adds the intuitive question, “*Why can some people effortlessly stay thin and other people have to really struggle to maintain their weight and maybe are not able to*”
- Looking at genomic differences, one can identify genes and the tissues where they are expressed
- There was a [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5896795/) that looked at 48 different traits of all kinds of diseases, personality traits, other stuff; they asked “*What does the tissue enrichment look like?*”
  - If you look at body mass index, it looks like psychiatric diseases and educational attainment
  - All of those are heavily enriched for brain-related genes to a similar degree
  - ***The biology of BMI is heavily enriched for brain-related biology***
  - Peter adds that psychiatric diseases are some of the most heritable in medicine; [schizophrenia](https://en.wikipedia.org/wiki/Schizophrenia#Genetic) has a heritability index of 0.6-0.7 (or more)
  - These parallel characteristics are highly genetic and disproportionately concentrated in the brain

**Stephan’s takeaway:** ***We don’t really know exactly how the brain is doing this, what it is about these genes, but we can see that it correlates with certain types of ways of interacting with food***

> “*People that have obesity promoting genes tend to have greater eating drive*”‒ Stephan Guyenet

- People with obesity promoting genes also tend to have lower satiety
  - But this hasn’t been explored very well yet
- If you look at the monogenic obesity syndromes (where there is 1 mutation that causes severe obesity), those really revolve around the leptin brain signaling axis
  - Mutations tend to be in: [leptin](https://en.wikipedia.org/wiki/Leptin), the [leptin receptor](https://en.wikipedia.org/wiki/Leptin_receptor), [melanocortins](https://en.wikipedia.org/wiki/Melanocortin), the [melanocortin receptors](https://en.wikipedia.org/wiki/Melanocortin_receptor) (which are downstream of leptin in the brain)
  - These are the types of signals that show up in genome-wide association studies
  - But they’re not dominant; a lot of this stuff is really general
    - It’s things that affect general neuronal development and neurotransmitters
    - These are involved in a lot of things

***There is a lot to learn about how these genes are involved in obesity; but what we can say is‒ differences in body fatness between individuals are primarily determined by differences in how the brain is constructed and how it operates***

> “*There’s a long way to go before we really understand exactly how those genes are affecting the brain in a way that impacts body fatness*”‒ Stephan Guyenet

## Understanding the tendency of humans to store fat through an evolutionary lens [57:00]

**How leptin fits into a teleological perspective**

- 250,000 years ago, for all intent and purposes we were the same creatures then as we are now
  - The difference is our environment
- In that time, food and energy are on of our top priorities
  - Acquisition of energy was essential in that it could kill you very quickly if you failed to do that
  - Acquiring energy and storing it was a struggle that defined us in the short term probably more so than reproduction
- Thinking of leptin in this environment, ***it is a signal saying there is not enough energy***
  - So it’s not surprising that high leptin doesn’t make you want to stop eating
    - This is not the problem that humans faced in the past

***Instead, nature would care about low leptin levels***

- Low leptin levels should be a screaming signal to go and eat

**What is known about the efficiency with which we store energy?**

- Humans have a remarkable ability to get fat
- We don’t really store carbohydrates, we can’t really store protein since we don’t want to break down muscle to get amino acids
- We rely on the ability to store fatty acids
  - Excess carbohydrates are stored as fatty acids in a relatively inert structure of [white adipose tissue](https://en.wikipedia.org/wiki/White_adipose_tissue)
- Stephan replies, “*I think Herman Pontzer would be a great person to talk to about this*”
  - His book [[*Burn: New Research Blows the Lid Off How We Really Burn Calories, Lose Weight, and Stay Healthy*](https://www.amazon.com/Burn-Research-Really-Calories-Healthy/dp/0525541527/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651495897&sr=8-1)] is on Peter’s list to read
- [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) would also be a good person to talk to
- There are good reasons to have a certain amount of body fat
  - This provides a way to cover your energy needs between eating opportunities
  - Glycogen is another energy reserve, but is is far more limited
  - The awesome thing about fat, it’s a concentrated source of energy
    - Dietary fats are 9 calories per gram, carbohydrates are 4, proteins are 4
    - Fat is anhydrous, there’s not water, just energy
    - Fat is hydrophobic, it can be stored without having to hydrate it like you have to do with [glycogen](https://en.wikipedia.org/wiki/Glycogen)
    - The weight of glycogen is mostly water
    - For adipose tissue, 85-90% of the weight is fat; the energy density is really high
    - Peter agrees, “*there’s no battery that can come close to the energy density of our fat… or any hydrocarbon for that matter*”
  - We also need fat reserves for times of illness
    - The primary causes of mortality in children under 5 in low-income environments is strongly related to their weight for height (a different way of measuring BMI) and disease pressure
    - In children, diseases like diarrhea interfere with nutrition
    - Kids with moderate or severe malnutrition are underweight and have massively increased mortality because they lack the energy stores of fat and cannot defend themselves against infections
- Apart from energy, other nutrients and vitamins are important, and the lack of them is also a source of mortality in kids
  - This is another selective pressure to maintain a certain amount of fat

> “*Humans have a lot more fat than our closest primate relatives*”‒ Stephan Guyenet

- Chimps don’t develop obesity, their % fat is in the mid-single digits
- Human physiology is special in our capacity for fat storage
- Stephan doesn’t know the % fat of different ancestral populations; this is an interesting question

**Does a history of starvation select for more obesity-type genes?**

- [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) has argued against this idea
  - Apparently obese people do not survive famines better than lean people, which is counterintuitive
  - Stephan is not sure why this is

## The hedonic aspect of food, and how the brain reacts to modern, highly-rewarding foods [1:03:30]

- We have 5 tastes: sweet, sour, bitter, salty, and umami

**What is the best way to describe umami?**

- It’s a meaty flavor that is present in cooked meat, bone broth, soy sauce
  - [Wikipedia](https://en.wikipedia.org/wiki/Taste) describes it as savoriness
- It’s distinct from salt
- When you look at what hunter gatherers ate (either contemporary or historical), it is radically different from what we eat today
- There are different hedonic properties today
- When the [Hadza](https://en.wikipedia.org/wiki/Hadza_people) kill an antelope, they just cut off pieces of meat and cook it in the coals of a fire
  - They just cut off charred parts and eat
    - It’s half raw on the inside
  - There are no sauces; they don’t put salt on it
  - They will also eat rotten meat
- If a typical person were to try to eat at a Hadza camp for a week, it would be really challenging
  - Probably the most palatable thing they eat is honey, but they’re not putting it on toast with butter
    - They’re drinking the honey and eating the honeycomb
- They also eat a lot of [baobab](https://en.wikipedia.org/wiki/Adansonia#Fruit_2)
  - This is a very fibrous fruit that has some sweetness but also has some off-flavors; it’s very different from an apple
- Tubers are another major part of their diet; this is their least preferred type of food
  - They are so fibrous that they have to spit out a wad of fiber after they’re done chewing it and sucking out the nutrients
- Consider how our reward circuits adapt to our way of cooking, sauteing onions, adding spices and sauces
- The Hadza are just taking food out of nature, cooking it, and eating it
- It’s a radically different diet than we are accustomed to

> “*Our brains are set up to not be satisfied with ordinary stuff, once we have gotten good stuff*”‒ Stephan Guyenet

- [Michael Krashes](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/krashes-michael) did an interesting study on this in mice
  - Mice normally eat these unrefined food pellets
  - They much prefer calorie-dense, refined, high-fat pellets over these healthier pellets
  - He looked at the activity of their reward circuits and found that once they’ve been exposed to the preferred food, they devalue the less preferred food
    - The healthy pellets no longer satisfies them or motivates them in the same way that it did before they were exposed to the highly-preferred food

***To put this in context with the typical American diet, people raised in an environment of tasty, calorie-dense, easy-to-eat food would find it difficult to eat as our ancestors did***

**How does calorie density differ from taste?**

- Peter thinks table sugar is disgusting, he wouldn’t eat it or mix it into water and drink it
  - It tastes fine in coffee and tea but not by itself
- Similarly, he finds the taste of lard disgusting
  - Even though he was on a ketogenic diet for 3 years
  - He never developed a taste for putting butter in coffee and things like that
- But he LOVES ice cream, “*I think ice cream is about one of the most beautiful tastes in the world*”
- So he doesn’t enjoy sugar or butter by itself but combined in ice cream, it’s amazing
  - Ice cream doesn’t have that much more calories than butter
- An interesting anecdote related to this‒ when Peter’s daughter turned 6-months old (she’s now 13) they gave her ice cream
  - His wife was able to breastfeed so she didn’t have formula
  - They were fastidious about not feeding her junk as typical idiot first parents can be
  - But they gave her a treat for her 6-month birthday
  - He remembers sitting in Del Mar, California and holding an ice cream cone up for her to eat
  - He remembers, “*In milliseconds her eyes opened wider than they’ve ever opened, and she couldn’t get into that thing fast enough*.”
    - This suggests that her brain is responding

*What is it about taste and energy density that is instantly rewarding?*

- Stephan agrees, ice cream has an almost drug-like effect on his brain; this brings up interesting questions

*If our brains are wired for calories, why are those not very motivating?*

- There is an optimal concentration of these nutrients that is not a 100%
  - Salt is a good example, eating salt straight-up by the spoonful is horrible
  - But at the right concentration, salt really enhances food
    - This is true of all the nutrients, including carbohydrate and fat
  - [Bliss point](https://en.wikipedia.org/wiki/Bliss_point_(food)) is a term used to describe this

***There is an optimal concentration for enjoyment and, presumably, also for reinforcement; the release of dopamine sets your motivational drive and helps you form habits***

- If you removed the sugar from ice cream, it probably wouldn’t taste bad but it wouldn’t be nearly as good
- If you removed the fat, it also wouldn’t be as good; fat-free ice cream isn’t exactly flying off the shelves
- It’s the combination of sugar and fat really put it over the top

***Foods commonly associated with strong cravings and addictive-like behavior are generally a combination of carbohydrate and fat***

- Usually there are other flavorings involved
  - Salt in savory foods like pizza or French fries
  - Sweet or savory are generally combinations of carbohydrate and fat

> “*Modern foods have been crafted to maximally stimulate enjoyment and motivation*”‒ Stephan Guyenet

- Generally these foods are hitting multiple bliss points at the same time
  - They’re not a combination you see in nature; you don’t see foods that are as reinforcing
  - The closest thing in nature may be certain type of nuts that have some carbohydrate and fat together

## How we are hard-wired to think about food [1:14:30]

**Thinking back to our ancestors, what helped them understand and prioritize calorically-dense food?**

- Peter would think that 3 things mattered most: i) total calories, ii) protein, and iii) sodium
  - *It can’t be an accident that sodium is the only mineral we can taste*
  - Stephan agrees
- Energy for humans primarily comes from carbohydrate and fat
  - We get a list: carbohydrate, fat, protein, salt and sometimes umami/ glutamate
  - We are subconsciously wired to like these things
- Human cultures have figured out what foods are good over long periods of time
- Key to this is [dopamine](https://en.wikipedia.org/wiki/Dopamine)-mediated [reinforcement](https://en.wikipedia.org/wiki/Reinforcement)

***Our bodies are setup to respond to certain types of nutrients and create a motivation and learning response that prioritizes and sets the motivation level on seeking these types of foods***

- Presumably, these are the kinds of nutrients our ancestors would have needed to prioritize to maximize [reproductive success](https://en.wikipedia.org/wiki/Reproductive_success) (the currency of [natural selection](https://en.wikipedia.org/wiki/Natural_selection))
- Modeling has been done on foraging behavior in a wide variety of animals (and humans); it reveals that this behavior generally revolves around maximizing the rate of energy return
  - Peter thinks the hunting behavior of big cats is a good example of this
  - They will chase an antelope and it’s almost like they have a sensor inside that says, “*I’m going to stop chasing now because my energy cost is greater than what I could consume in this kill*”

**Gut-brain signaling and dopamine mediated reinforcement**

- Our bodies are wired around energy acquisition, in terms of our motivation and learning on a nonconscious level
  - It’s hard-wired
  - [Research since 2018](https://www.science.org/doi/10.1126/science.aat5236) has shown that we have dedicated sensors in the small intestine called **neuropod cells** (shown as a pink triangle in the figure below)
    - They have receptors for specific nutrients and are directly hooked up to the [vagal neurons](https://en.wikipedia.org/wiki/Vagus_nerve)

![](https://peterattiamd.com/wp-content/uploads/2022/06/f4-guyenet.png)

**Figure 4.  The gut detects nutrients and transmits that information to the brain via the vagus nerve.**  Image credit: [*Science* 2018](https://www.science.org/doi/10.1126/science.aat5236)

- When they detect glucose (carbohydrates), amino acids (protein), or fatty acids (fat), they start sending signals up your vagus nerve to your brain stem
- The signal gets distributes to many parts of the brain, particularly relevant is dopamine release in reward centers (illustrated in the figure below)
- If the food that you’re eating contains a high concentration of these valuable nutrients (particularly in combination), you’re going to get a higher level of dopamine release

> “*The more dopamine release you get, the more of a motivation you will develop toward that food*”‒ Stephan Guyenet

![](https://peterattiamd.com/wp-content/uploads/2022/06/f5-guyenet.png)

**Figure 5. Transmission of nutrients sensed in the gut to the brain.** Image credit: [*Cell* 2018](https://www.cell.com/cell/fulltext/S0092-8674(18)31110-3)

**Conundrum:** ***Why does it seem difficult to eat steak excessively if we’re hard-wired for calorie dense foods?***

- It’s high in sodium, fat, and protein and total calories
- The only thing steak is missing is sugar, fiber, carbohydrates etc.
- Stephan asks, “*With the potato, is that with or without toppings?*”
  - It’s so much better with butter, sour cream, salt, and it has to have crispy skin too
- Stephan notes, “*When you look at the foods that people cite as the most typically associated with strong cravings and loss of control over eating behavior, meat does not usually come up high on that list*”
- Thinking about meat, it is about 75% water; so (1) the calorie density is not especially high unless it’s a really fatty piece of meat
- Compare meat to something like a brownie or pizza, which is more calorie dense than steak
- (2) Steak doesn’t have any carbohydrate, so it doesn’t have that fat-carbohydrate combination that is most closely associated with foods that people lose control around
- (3) Steak has a high protein level, and though a strong protein-specific appetite  has been demonstrated in many different species, protein doesn’t work the same as carbohydrate and fat
  - Protein is something our bodies want to get enough of, but they don’t want to get too much
  - There is a drive to acquire protein, but there’s also a drive to keep it within a certain range and not eat too much

***This is demonstrated when people go on a high protein diet, their overall calorie intake will drop***

## A review of the “Carnivore diet” [1:21:45]

**People lose weight on a carnivore diet, is this the motivation for going on this diet?  Why does it result in weight loss?**

- Stephan [reviewed](https://www.redpenreviews.org/reviews/the-carnivore-code/) a book on this diet, [*The Carnivore Code*](https://www.amazon.com/Carnivore-Code-Unlocking-Returning-Ancestral/dp/035846997X/ref=sr_1_1?crid=1WJ9D0UBCEPZQ&keywords=the+carnivore+code&qid=1651673834&sprefix=the+carnivore%2Caps%2C117&sr=8-1)
- We don’t have any good data on the impact of carnivore diet on weight; there are no randomized control trials
- Anecdotally, people lose a lot of weight
- Stephan speculates that a carnivore diet has multiple properties that make it an effective weight-loss diet
  - 1 – It has very little carbohydrates
  - Being on the extreme of the fat:carbohydrate ratio in either direction is more slimming than being in the middle

> “*The most fattening diets are rich in both carbohydrate and fat*”‒ Stephan Guyenet

- 2 – The variety of a carnivore diet is very low
  - You can prepare meat in different ways
  - You can eat chicken, fish, beef, whatever but the variety is greatly, greatly reduced
- 3 –  You’re cutting out all the highly-processed, calorie-dense foods
  - Everyone agrees these foods drive excess intake and increased body fatness, though we could debate why

- Peter notes that a carnivore diet may have a role in overcoming some acute illness
  - One of the core tenets is that plants are low-grade toxic
  - Peter is biased toward thinking that plants are valuable

**What is the thesis of a carnivore diet?**

- Everything is toxic except grass-fed animal foods
- Even tap water is considered not optimal
- The book spends a lot of time going through the litany of all the potentially harmful compounds in plant foods

> “*There is a bias toward thinking if it’s in a plant, it’s healthy; and I don’t think that’s true.*”‒ Stephan Guyenet

- There are some plant compounds that are not good for some people
  - If you eat a lot of spinach, you can get kidney stones from all the [oxalate](https://en.wikipedia.org/wiki/Oxalate#Occurrence_in_nature)
  - There are studies suggesting that the [glucosinolates](https://en.wikipedia.org/wiki/Glucosinolate) in cabbage family plants might contribute to type 2 diabetes
  - Kidney beans, if you don’t cook them enough, they can be really toxic because of the [lectins](https://en.wikipedia.org/wiki/Lectin)
- Stephan notes, “*The way to think about how healthy a food is is not to say, does it contain toxins? It’s to say what’s the cost-benefit analysis on this food? And most importantly, what are the empirical outcomes that we can see when its impacts on health are directly studied?*”

**Stephan evaluates new ideas people come out with, about a healthy diet**

- Take lectins for example, [Gundry](https://en.wikipedia.org/wiki/Steven_Gundry) suggests we shouldn’t eat certain plants because they contain lectins
  - This is a bottom-up approach, extrapolating empirical effects on health from mechanism
- Stephan thinks its better in a complex field like nutrition to start with the empirical evidence
  - You first need a study to suggest that there’s an actual effect on health
  - Then you can try to understand the mechanism

**What are some biochemical changes that occur in people on a carnivore diet?**

- The obvious one is [dyslipidemia](https://en.wikipedia.org/wiki/Dyslipidemia)
- There’s a shift toward a ketogenic metabolism because of the fact that it’s very low carbohydrate
- One of the downsides Stephan focused on in the [review](https://www.redpenreviews.org/reviews/the-carnivore-code/) (that is downplayed by many advocates of the carnivore diet, including [Paul Saladino](https://carnivoremd.com/)), is the change in LDL cholesterol and LDL particle count

***The crux of his review on Red Pen Reviews is simply that there are a lot of claims made that are not supported by any kind of convincing evidence***

- There is not great evidence here but, a [survey](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8684475/) of around 2000 carnivore dieters gathered information about their blood lipid values before and after this diet
  - He thinks [David Ludwig](https://www.drdavidludwig.com/) was involved
  - They simply reached out to people on social media groups and administered this survey
  - There was a large increase in [LDL cholesterol (LDL-C)](https://en.wikipedia.org/wiki/Low-density_lipoprotein)
  - [HDL](https://en.wikipedia.org/wiki/High-density_lipoprotein) and triglycerides were in an optimal range; see table 4 of the [publication](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8684475/)
- Just to repeat what Paul Saladino has said, his LDL cholesterol is 533 mg/dL and his LDL particle count is also through the roof
  - Stepahn doesn’t want to pick on him, just make a point about increased LDL-C
- Not everyone on a carnivore diet responds like this
  - He think’s [Shawn Baker’s](https://twitter.com/sbakermd?lang=en) lipids are fine; he’s another carnivore diet guy
- Stephan recalls a mean increase in LDL of 30 mg/dL in the survey of people on the carnivore diet
- But a large increase in LDL-C raises red flags in terms of cardiovascular risk over the long run
  - Peter notes that of all the things that could go wrong, this is one of the most treatable
  - It’s very easy to treat elevated [ApoB](https://en.wikipedia.org/wiki/Apolipoprotein_B)
  - Yet, people who go on this diet (or a ketogenic diet) and develop an elevated LDL pattern often avoid treatment
  - Peter doesn’t understand why they dig in their heels and say, “*Clearly, this is a good thing, and LDL does not cause heart disease*”

> “*It’s an ideology that has emerged to defend a certain type of dietary pattern.*”‒ Stephan Guyenet

- These kinds of ideas emerge from the low carb community to defend against the idea that there might be some downside to certain types of low carb diets
- It’s been taken to the extreme in the carnivore community because that’s a potent stimulus for increasing LDL
- People don’t want to believe there’s a downside to the thing they’re doing
  - People go on this diet, lose weight, feel better, and have some improvement of X, Y, Z condition
  - They can see all these tangible things improving
  - They don’t want to believe there’s an intangible thing that’s putting them at severe risk
    - Cardiovascular disease is a #1 killer; it’s a huge deal
    - Even if it doesn’t kill you, it can do really bad things to you physically and cognitively
    - It’s not a risk you want to be ignoring
    - ***High LDL is treatable and you don’t have to stop the diet***

> “*It’s an irrational part of dietary tribal ideology that is holding people back from experiencing their best health*”‒ Stephan Guyenet

- Peter notes the same stubborn ideology at the opposite end of the dietary spectrum, where patients go on these incredibly restrictive plant-based diets
  - It’s usually some combination of micronutrient deficiency and/or protein deficiency that’s going to be the death of them
  - But they won’t supplement their diet with protein shakes or B vitamins
  - They seem to think it threatens their belief system
  - It’s self-destructive

## The energy balance model, carbohydrate-insulin model, and unifying the theories around adiposity [1:34:15]

- Peter recently heard a [podcast](https://sigmanutrition.com/episode429/) with Stephan and Kevin Hall
  - [#429: Kevin Hall, PhD & Stephan Guyenet, PhD – Carbohydrate-Insulin Model vs. Energy Balance Model](https://sigmanutrition.com/episode429/)
  - He thought they did a good job explaining the history of these models
- The 2 models are the [carbohydrate-insulin model](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8634575/) (promoted by [David Ludwig](https://www.drdavidludwig.com/)) and the [energy balance model](https://academic.oup.com/ajcn/advance-article/doi/10.1093/ajcn/nqac031/6522166) (promoted by [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin))
- The most recent incarnation of the **carbohydrate-insulin model** is a lot more complex than previous one
  - The idea that there are things in the diet and in the environment that impact insulin signaling (summarized in the figure below)
  - And insulin signaling impacts body fatness
  - ***Downstream of the fattening process of insulin signaling on adiposity is the proposal that it leads to elevated calorie intake and possibly a decline in metabolic rate***
  - So it proposes a reversal of the relationship; it proposes a reversal of the relationship between energy balance and body fatness
  - Basically, the energy balance phenotype is *downstream* of that fattening process instead of being upstream

![](https://peterattiamd.com/wp-content/uploads/2022/06/f6-guyenet.png)

**Figure 6.  The carbohydrate-insulin model of obesity.**  Image credit: [*The American Journal of Clinical Nutrition*](https://academic.oup.com/ajcn/article/114/6/1873/6369073?login=false) 2021

- The **energy balance model** is *upstream* of the fattening process
  - We have all these things happening in the environment and physiologically in our bodies, and those signals are impinging primarily on the brain (summarized in the figure below)
  - Energy balance is then a result of that brain activity
  - And this brain activity is feeding into adipose tissue
  - So in that context, ***body fatness is kind of receiving the excess energy***
  - ***Body fat is not really the driver of this process, but when excess energy enters the body, it’s what mops it up***

![](https://peterattiamd.com/wp-content/uploads/2022/06/f7-guyenet.png)

**Figure 7.  The energy balance model of obesity.**  Image Credit: [*The American Journal of Clinical Nutrition* 2022](https://academic.oup.com/ajcn/advance-article/doi/10.1093/ajcn/nqac031/6522166)

**Peter’s summary of these 2 models**

- In the *carbohydrate-insulin model*, the idea is that the primary cause is the adipose tissue increasing in its fatness
  - The adipose tissue wants more energy; this is driven by external factors such as carbohydrates
  - Also in the drive to increase fatty acid deposition into adipose tissue is a reduction in circulating metabolic fuels and this drives an increase in appetite
  - Intake of food goes up to accommodate the reduction in circulating metabolic fuels
    - All feeding into a drive toward fatness
- The *energy balance model* is the conventional model; it says the reverse is happening
  - The input of fuels into the system leads to an increase in circulating metabolic factors that is now driving energy balance into the fat cell
  - Stephan points out, “*If you look at David Ludwig’s* [*paper*](https://academic.oup.com/ajcn/advance-article/doi/10.1093/ajcn/nqac031/6522166)*, he contrasts the carbohydrate-insulin model against what he calls the energy balance model, which is basically calories in and calories out. None of this is really regulated*.”
    - The conventional model contends that fat tissue is simply a result of how many calories you happen to eat or how much you decide exercise
    - None of the obesity researchers who study the mechanism of body fat regulation ascribe to the conventional model
  - However the energy balance model acknowledges the brain regulation of both body fat and appetite
    - It contends that body fatness regulated by the energy intake and expenditure via the brain

**Are all calories equal?**

- Peter recalls from the [podcast](https://sigmanutrition.com/episode429/), “*One of the things that Kevin pointed out is the energy balance model does not consider all calories identical*” (in terms of their impact on body fat)
  - 1 – There may be different thermogenic effects
  - 2 – There may be different regulatory effects on appetite
- Stephan agrees, this theme is emerging in animal models
  - You can change the diet composition and produce animals that will gain fat independent of calorie intake
    - David Ludwig has shown this for carbohydrate quality
    - This has also been shown for dietary fat
  - So in principle, these types of effects are possible
- Peter recalls, “[*Rick Johnson*](https://som.ucdenver.edu/Profiles/Faculty/Profile/9426) *described an experiment like that on my recent podcast with him, which was an isocaloric swap to a very high fructose diet where the animals didn’t gain weight, but they fuel partition differently. They got fatter. This was over a long time…. 9 months*”
  - [#194 – How fructose drives metabolic disease | Rick Johnson, M.D.](https://peterattiamd.com/rickjohnson2/)
- Stephan adds this has been shown in a number of contexts in rodents
  - Energy expenditure in rodents is more plastic than ours

## Body weight set points: a hypothetical comparison of two individuals [1:41:45]

- 2 siblings are the same height, one weighs 200 lbs and the other weighs 160 lbs
  - On the surface they look identical
- One of these used to be obese; now they are post-obese
  - They lost 40 lbs and kept the weight off
  - It’s 3 years later and his weight doesn’t yo-yo
- The other was never obese

**Are these 2 people metabolically the same?**

- Stephan thinks probably not
- [Rudy Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md) has studied people who lost weight out to 1 year (maybe 2)
  - He hasn’t seen any sign that their leptin-dependent starvation response goes away
- The set point around which the lipostat regulates can change based on dietary and environmental variables
  - For example, if you take someone on a typical diet and put them on a low carb diet, you don’t have to tell them to reduce their calorie intake, that will occur spontaneously and they will lose fat and the typical person will end up being comfortable at a lower weight
    - They’re not experiencing a starvation response
    - You can see this on other diets as well

> “*There are things we can do to change the set point*”‒ Stephan Guyenet

- But changing the setpoint doesn’t mean a formerly obese person is cured; if they went back to their other diet they will generally go back to their former weight

***The set point can be modified by a different environment***

- As long as you maintain that change, you can maintain the effect
- But if the change goes away, then the effect goes away

**Where is the greatest window of vulnerability for someone who lost weight, going back to these 2 hypothetical individuals?**

- Let’s take the genetics out of it and pretend they are identical twins living in the same household
- Let’s say they have the genes to allow them to become obese in the right environment
- Perhaps one of them had an injury in high school that kept him from playing sports
  - He ended up playing more video games and eating more
- The other one was more active, and this explains why now, at age 40, one is 40 lbs overweight and the other is not

**Are there windows in a person’s life when they are more susceptible to resetting of a set point, a higher and higher set point?**

- It sounds to Peter like the set point never goes down; it’s a monotonic crank
- Stephan doesn’t know the answer
- There is potential for people to gain weight at almost any point in life
- One thing that is potentially interesting is, *there may be an influence of the intrauterine environment*
  - What’s going on while you’re developing inside the uterus
  - There is some evidence that women who undergo [bariatric surgery](https://en.wikipedia.org/wiki/Bariatric_surgery) for obesity and lose a lot of weight, their children are at a lower risk of developing obesity than women of similar weight who did not have the surgery
    - These are 2 women with severe obesity
    - The woman who had bariatric surgery lost a lot of weight before having a child

**Is weight loss through gastric bypass surgery physiologically the same as losing weight from diet and lifestyle changes?**

- Peter doesn’t think so
- Gastric bypass is unique where by as long as the person doesn’t take in liquid calories, the weight loss is quite durable
  - Liquid calories can completely disrupt the feedback mechanisms, similar to a [GLP-1 agonist](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1_receptor_agonist)
  - Anecdotally, Peter has seen patients who take [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) who don’t lose weight

***The way you can cheat semaglutide is to drink a massive amounts of calories***

- So drinking a lot of alcohol, juices, or things like that

## Takeaways for people who want to lose weight and keep it off [1:48:30]

**For people in the obese category**

- For people with a BMI of 30 or 35, it’s worthwhile to consider medical treatment
- Something like [semaglutide](https://en.wikipedia.org/wiki/Semaglutide); it’s a very safe drug
  - It causes something on the order of 18% weight loss
  - This is better than the typical effect of diet and lifestyle strategies but you have to keep taking the drug
- See an obesity specialist

> “*The tools that we have now are just way better than what they used to be*”‒ Stephan Guyenet

**For people who just want to lose a few pounds**

- *Your appetite and your body fatness are very much regulated by your brain*
  - This is based on inputs your brain is receiving; a lot of this is nonconscious
- Try to give the nonconscious brain signals to regulate things in a more slimming direction
- He doesn’t think it is sustainable or effective for most people to simply rely on willpower all the time
- Here are some ways to control these signals to your brain:
  - 1 – Control your food environment and the sensory cues your brain is exposed to
    - How tempting is it to grab and eat food in your vicinity?
    - Lower the barriers to eating healthy, prep healthy snacks and have them nearby
  - 2 – There’s a wide variation in the number of calories it takes to feel satisfied at a meal and this depends on what foods you are eating
    - It’s intuitive to eat until you feel satisfied and then stop eating
    - The satiety point can be reached with vastly different numbers of calories

**Is satiety a function of gastric distention?**

- This is important, but the system is complex; *the brain is receiving a lot of signals*
  - Signals from the small intestine about what the nutrient composition is
  - Oral sensory detection of food properties
  - Your brain knows based on the sensory properties what the nutritional composition of the food is based on prior experience
  - Stomach distention is a biggie, and this relates to calorie density
  - If you have a food that has more volume per calories, it fills up your stomach more and sends signals to oppose further food intake
  - Protein is more satiating per calorie
  - Palatability, the better something tastes the less it fills you up per calorie

***Stephan is not sure how to disentangle palatability from calorie density but they’re both strongly correlated with lower satiety***

- Peter asks about the drive to simply finish what’s on your plate whereas if they finished 10 bites earlier, they would have been happy
- Stephan agrees, this is a plausible factor
- The problem is, research from [Biran Wansink](https://en.wikipedia.org/wiki/Brian_Wansink) was so bad, much of it was [retracted](https://www.vox.com/science-and-health/2018/9/19/17879102/brian-wansink-cornell-food-brand-lab-retractions-jama)
  - The refilling soup bowls was one of his classic experiments

## Evidence that favors the energy balance model of weight gain [1:56:00]

**Comparing the 2 models**

- One of the arguments in favor of the **carbohydrate-insulin model** is other examples of growth that are regulated from the hormones, out to the intake of energy
- Peter thinks about watching his kids grow in height
  - His youngest is not yet 5, he eats more than the other 2 combined; and he’s growing fast
  - Most would agree he’s not growing because of how much he’s eating
  - He’s eating that much because of how much he’s growing
  - He’s responding to growth hormone and all these other things

***The central thrust of the carbohydrate-insulin model is, increased insulin signaling is driving an increase in food intake***

- This can be initiated by sleep disturbances that increase (or decrease) insulin signaling, or foods that stimulate insulin

**Experimentally, what is different about these models?**

- Both Peter and Stephan agree, data suggests the **energy balance model** is easier to explain
- *The models are not mutually exclusive*
- If you understand the mechanism of obesity, then it should be easier to address
- Most obesity drugs (weight loss drugs) were discovered in haphazard ways
  - [Dinitrophenol](https://en.wikipedia.org/wiki/2,4-Dinitrophenol) was a high explosive used in World War I, and somebody figured out if you take it, it makes you lose weight
    - It does so by increasing your energy expenditure
    - So some people managed to cook themselves literally from the inside out
  - Many of the other drugs are repurposed psychiatric drugs that just happen to cause weight loss
- [Rybelsus (Semaglutide)](https://en.wikipedia.org/wiki/Semaglutide) is a drug developed to treat obesity based on its mechanism of action, from the bottom up
  - It’s safe and effective
- We’re in a new era where weight loss drugs are being designed based on mechanism and an understanding of biological regulation
- *Cardiovascular medicine* is an example of this more refined era of drug development
  - Incredible insights have been coming out of genetics studies such as [PCSK9 inhibitors](https://en.wikipedia.org/wiki/PCSK9#As_a_drug_target)
    - This is an example where we first understood the biology, then we came out with a therapy
    - And it works awesome
- This is the era we’re are getting into now with obesity

> “*It actually is really important to understand the mechanism*”‒ Stephan Guyenet

**The success of Semaglutide argues against the carbohydrate-insulin model of obesity**

- Peter predicts that these models will have more and more in common as time goes on
- One of the arguments against the carbohydrate-insulin model is provided by semaglutide
  - This drug raises insulin in the short run
  - Patients on this drug lose a ton of weight and their insulin levels go up slightly
    - This tends to resolve over a long period
    - But for at least 3 months, they have elevated insulin
  - We know the drug is increasing insulin sensitivity
    - So patients on the drug are getting a double effect
  - This is hard to reconcile with a model that claims insulin must go down for weight/ fat to go down
- Stephan replies, “*I think that model is just not even plausible at this point. If you want to say, is it a factor? I think that’s still in play, but to say, this is the determinant, I just don’t even think that’s plausible at this point.*”
- Semaglutide was identified based on its ability to increase glucose-stimulated insulin secretion
  - That is what [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) does
  - It’s an [incretin hormone](https://en.wikipedia.org/wiki/Incretin) and this is why it was used in type 2 diabetes management
  - It gives people more insulin around meals when they really need it
    - Just injecting insulin is a crude way to manage blood glucose; it’s not time specific
    - GLP-1 gave it that much needed time specificity
    - GLP-1 also had some other benefits in reducing food intake and body weight
    - The figure below summarizes the effects of GLP-1 which would presumably extend to GLP-1 receptor agonists such as Semaglutide

![](https://peterattiamd.com/wp-content/uploads/2022/06/f8-guyenet.png)

**Figure 8.  Functions of GLP-1 and GLP-1 receptor agonists such as Semaglutide.**  Image credit: [Lthoms11](https://en.wikipedia.org/w/index.php?curid=55236027) on [Wikipedia](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1)

- [Genome-wide association studies (GWAS)](https://en.wikipedia.org/wiki/Genome-wide_association_study) on BMI point largely to **genes involved in the brain**
- GWAS on body fat distribution (controlling for BMI and looking at the distribution of fat on the body) point to a **insulin signal**
  - This gives some support to the carbohydrate-insulin model

**Peter’s takeaway‒ the total amount of body fat seems more related to energy intake; it’s regulated more on the intake side of the equation and somewhat by the brain**

- The carbohydrate insulin model is all about this idea of energy partitioning; there could be some of that flying under the radar of BMI
  - This adds a layer of nuance
  - Stephan doesn’t think the door is closed on it
- This is showing up in body fat distribution
- [David Ludwig](https://www.drdavidludwig.com/) is publishing studies suggesting there could be correlations between baseline insulin secretion and what proportion of weight loss is lost as fat versus a lean tissue
  - Published in the *Journal of Nutrition* in 2022, [Stimulated Insulin Secretion Predicts Changes in Body Composition Following Weight Loss in Adults with High BMI](https://pubmed.ncbi.nlm.nih.gov/34587231/)
- Stephan thinks there could be some energy partitioning effect but he doesn’t think the carbohydrate-insulin model explains obesity, because obesity is not just energy partitioning
  - You have a bigger body, you’re eating more energy, you’re burning more energy
  - You have more lean mass, more fat
  - That phenotype is not explained by energy partitioning
  - But there could be some subtle energy partitioning phenotype that is also operating

## The synergistic effect of fat and carbohydrates and observations that a low-fat diet or a low-carb diet can cause weight loss [2:04:30]

Peter recalls, “*You said something earlier about the more you restrict carbohydrate or the more you restrict fat, typically the more weight you’re going to lose. The sweet spot, if you want to gain weight, is to have lots of both of them.* ***How much of that do you think comes down to the hedonic component of how good ice cream tastes? The ubiquity of food choices? Or do you think there’s something very unique physiologically going on?*** ”

- For example, people on the potato diet (where all they eat is potatoes), lose weight like crazy
- This has been shown in animal models
  - The advantage here is the ability to have really tight control on the diet for a large proportion of the animal’s lifespan
- [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) published a study of around 29 different diets and 5 different strains of mice
  - Published in *Cell Metabolism* in 2018, [Dietary Fat, but Not Protein or Carbohydrate, Regulates Energy Intake and Causes Adiposity in Mice](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(18)30392-9)
  - Their predictions and findings are summarized in the figure below
  - They systematically varied the carbohydrate to fat ratio in the diet
  - They asked, “*How does that interact with body fatness?*”

***They found mice got fatter with the more fat they ate, up to a point at which they began to lose weight***

- 1 – If you start with animals that are on a low fat/ high carbohydrate diet, and you start replacing that carb with fat, they get fatter and fatter and fatter and fatter and fatter until you hit about 60%
- 2 – But then as they kept increasing the fat and decreasing the carbohydrate, the mice would get slimmer again

![](https://peterattiamd.com/wp-content/uploads/2022/06/f9-guyenet.png)

**Figure 9.  Summary of results from studying 29 diets in 5 strains of mice.**  Image credit: *C*[*ell Metabolism* 2018](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(18)30392-9)

- There are studies published showing rodents lose weight on a ketogenic diet, just like humans do

**Stephan’s takeaway:** ***having a diet in the middle is where the problem is***

- Peter notes this is ironic, because that’s where the standard American diet is, in the middle
  - It’s easy to eat the wrong combination of fat and carbohydrate
- Stephan adds, “*If you look anywhere in the world where people are rich enough and industrialized enough to eat whatever they want, that’s generally what you’re going to see. At least after a couple decades of cultural adaptation, you’re going to see pretty* ***equal proportions of fat and carbohydrate****.*”
- There are some hypotheses to explain why this is (though presently we don’t really know)
  - This is primarily an empirical observation that we’re trying to explain
  - 1 – There is a physiological effect of not eating much carbohydrate
    - Your body has to work a little bit harder to synthesize glucose; this is an increased metabolic demand
  - 2 – There is also a physiological effect of eating a low fat diet
    - You’re slightly increasing metabolic demand
    - You’re going to synthesize more fatty acids
  - But Stephan doesn’t think these are great explanations as these metabolic effects are very small

**Questions about Speakman’s studies**

- *Were the mice allowed to eat* [*ad libitum*](https://en.wikipedia.org/wiki/Ad_libitum)*?*
- *Were they eating significantly less at the extremes in terms of total energy intake?*
- *Were the diets controlled for protein?*
- Stephan thinks the answer is yes
- Sometimes there was not a perfectly tight correlation between energy intake and fat gain
- There is the physiology of increased metabolic cost of living the extremes
- There is also the neurobiology of food intake

**Stephan’s take away:** ***I think the most satisfying explanation we have right now is that foods that are more appealing to eat (and more motivating) have both carbohydrate and fat***

- He’s not saying he has evidence this is the explanation, but this is the only thing he can think of that explains it
- When people go on a very low fat or a very low carb diet, their energy intake declines by hundreds of calories a day
  - This happens automatically, right away
- ***His thought is that food in these diets is less rewarding so we eat less of it***
- Peter notes, “*It’s not very difficult to take your carbohydrate intake down to 5-7%, a ketogenic diet will do that. It’s a pretty easy diet to adhere to, especially today.*”
- He doesn’t know now how one would go about getting only 5% of their calories from fat; this seems harder
  - Stephan agrees
- In studies of low fat diets, the lowest fat content was in the 10% fat range
  - Even starch foods like whole wheat and corn have a fair amount of fat in them; not far off from 10%
- You would have to work hard to lower your fat intake to 15% and Peter is not convinced there are great health benefits to this

## Red Pen Reviews [2:11:00]

- [Red Pen Reviews](https://www.redpenreviews.org/) is a 501c3 nonprofit that publishes the most informative, consistent and unbiased reviews of popular nutrition books available
  - Developed by Stephan with the help of other academics; inspired by the nutrition scientist [Seth Yoder](https://thescienceofnutrition.wordpress.com/)

***What makes this website unique is the semi-quantitative review method they developed and apply to each book***

- They [explain their review method](https://www.redpenreviews.org/our-process/) on the website
  - This yields a numerical score for scientific accuracy, reference accuracy, and helpfulness
  - This allows them to apply the same rigorous method to all books so the reader can compare apples to apples between different books
- Peter notes, “*This is a pretty labor intensive process. So how many do you bang out in a year?*”
- They spend 40-100 hours per book
- They’ve been operating since 2019 and have 14 reviews
  - Their pace was slow last year due to COVID-related challenges
  - They’re on target to publish 6-8 reviews this year
- They have a total of 8 reviewers, each completes on average 1 review a year
  - But it turns out that some people do the majority of the reviews
- Stephan points out, “*We are trying to maximize our impact on public health knowledge and public health. So we really try to pick the books that are most impactful right now.*”
- They aim to give people information on things they are already interested in by looking for books that are:
  - Selling the most
  - Have the most social media engagement
  - Are from influential authors
- The most recent book they [reviewed](https://www.redpenreviews.org/reviews/volumetrics/) was [*The Ultimate Volume Metrics Diet*](https://www.amazon.com/Ultimate-Volumetrics-Diet-Science-Based-Strategies/dp/0062060643/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651760964&sr=8-1) by [Barbara Rolls](https://hhd.psu.edu/contact/barbara-rolls)
- Before that was [*The Carnivore Code*](https://www.amazon.com/Carnivore-Code-Unlocking-Returning-Ancestral/dp/035846997X/ref=sr_1_1?crid=1WJ9D0UBCEPZQ&keywords=the+carnivore+code&qid=1651673834&sprefix=the+carnivore%2Caps%2C117&sr=8-1) by [Paul Saladino](https://carnivoremd.com/); Stephan was the primary reviewer for this one ([link to the review](https://www.redpenreviews.org/reviews/the-carnivore-code/))
  - They have a primary reviewer and a peer reviewer
- Before that was [*Eat, Drink, And Be Healthy*](https://www.amazon.com/Eat-Drink-Be-Healthy-Harvard/dp/0684863375/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651763545&sr=8-1) by [Walter Willett](https://www.hsph.harvard.edu/walter-willett/) ([link to the review](https://www.redpenreviews.org/reviews/eat-drink-and-be-healthy/))
- Before that [*Eat Fat, Get Thin*](https://www.amazon.com/Eat-Fat-Get-Thin-Sustained/dp/0316387827/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651763580&sr=8-1) by [Mark Hyman](https://drhyman.com/about/) ([link to the review](https://www.redpenreviews.org/reviews/eat-fat-get-thin-why-the-fat-we-eat-is-the-key-to-sustained-weight-loss-and-vibrant-health/))

**You’ve been doing this for three years now, has anything surprised you so far?**

- Stephan remarks, “*One of the things that has really come into focus through the course of this process is that credentials are not a reliable correlate of information quality*”
  - Not to pick on anyone, to give an example‒ [David Perlmutter](https://www.drperlmutter.com/about/) is a MD and a board certified neurologist, yet his book [*Grain Brain*](https://www.amazon.com/Grain-Brain-Surprising-Sugar-Your-Killers/dp/0316485136/ref=sr_1_1?crid=2YS7OSZ33MNC8&keywords=grain+brain&qid=1651764426&sprefix=grain+brain%2Caps%2C119&sr=8-1) got the lowest scientific accuracy score of any book they reviewed ([link to the review](https://www.redpenreviews.org/reviews/grain-brain-the-surprising-truth-about-wheat-carbs-and-sugar-your-brains-silent-killers/))
  - He’s seen this in many cases
  - Credentials are not completely meaningless, but once you get into people who are highly credentialed, their work is variable
    - Some of their books do really well and some do really poorly

> “*I think most people who are educated in this sphere know that there’s a lot of low quality information*”‒ Stephan Guyenet

- Like in science, there’s a replicability crisis
  - Scientists are not infallible
  - There’s problems like this, even in this peer reviewed literature
- But once you get outside of this sphere where there’s accountability and you’re in the public sphere where there’s very little accountability, it’s a free for all
  - Many people who are very well credentialed share information that is very low quality
  - Most people have very little ability to detect it
  - Stephan admits, “*Even somebody like me, who I consider myself knowledgeable, at least in some areas I can get taken in too. I might read a book and it seems compelling.*”
- [*The Carnivore Code*](https://www.redpenreviews.org/reviews/the-carnivore-code/) did worse than he expected
  - As he was reading it he thought it made sense, it was interesting, it brought up points he wanted to look into
  - But when he started checking the citations and searching the scientific literature he realized the book did not put forth the best interpretation that an unbiased person would come to when looking at this body of evidence

***Most of his surprises were realizing the quality of popular nutrition books was worse than he thought***

- Peter is in the process of trying to finish his book; one of the things that is so daunting is the fact-checking process
  - He could never rely on his publisher for this, it’s too technical
  - He has analysts who fact check, but they have to be analysts who did not help with the research for the book because you’ve got to get fresh eyes on it
  - He just knows there’s going to be something they get wrong, incorrectly cite, or misinterpret
- There’s something daunting  knowing that the book won’t hit the shelves until 8 months after the last edits
  - Something is going to change in those 8 months, let alone 2 years
- Stephan agrees, every book is going to have mistakes
- The process Peter describes is far more rigorous than most books being published in this sphere
- Publishers do not impose a filter on the contents of these books
  - They do not view it as their job to police the claims of authors
  - If somebody comes in with an MD, they’re viewed as the expert
- For Stephan’s book ([*The Hungry Brain*](https://www.amazon.com/Hungry-Brain-Outsmarting-Instincts-Overeat/dp/125008119X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1649439652&sr=8-1)), he sent chapters out to experts in the field and had them look at it
  - This doesn’t’ mean his book won’t have mistakes
  - He’s been [cataloging mistakes](https://www.stephanguyenet.com/mistakes-page-for-the-hungry-brain/) on his [website](https://www.stephanguyenet.com/)
- Peter agrees, mistakes are inevitable
  - The best approach is to collectively figure out what they are and create a repository of updates
- Stephan thinks this is the best attitude, a truth-seeking attitude
  - You’re not presenting yourself as someone who has to be right to be rational

> “*You’re presenting yourself as someone who’s trying to get towards the truth and your audience can help you and help all together to get closer to the truth*”‒ Stephan Guyenet

- The method Stephan developed for *Red Pen Reviews* is [available on their website](https://www.redpenreviews.org/our-process/) for authors to see
  - They have criteria for healthfulness
  - They have criteria for scientific accuracy that can’t be gamed
- He admits, “*Part of the reason why we do that is because we’re trying to help authors write better books*”
- If you write a book that you think would score well, that going to be a good book from an evidence standpoint
- Stephan would have loved to have these criteria available when he was writing his book
  - It’s a great resource for writing with higher quality evidence
- He likes to view his organization as not just finger wagging at people who makes mistakes, but also providing a resource to improve information quality
- The reviews are freely available to anyone
- They love donations, but access to their resources do not depend on that

**Peter’s takeaway:**

- It is kind of amazing how much we still don’t know about something that is so ubiquitous and so important

- He gets the sense we’re converging

- He thinks these good faith debates that exist between people like Stephan, Kevin, David Ludwig

- They’re really good for the field because it’s forcing people to be sharper in their thinking

- Ultimately it’s getting us closer to theories that are aligning better with experimental evidence

- Peter knows his thinking on this has changed quite a bit and ***he now finds the balance of the evidence to be more on the energy balance side of the equation***

- He enjoys trying to understand both sides of this

***It’s very complicated, suggesting that there’s more overlap in the theories than we probably appreciate***

§

## Selected Links / Related Material

**Episode of** ***The Drive*** **that discussed the “obesity paradox”**: [#197 – The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.](https://peterattiamd.com/davidallison/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 28, 2022) | [16:00]

**Maximum attained weight method of correlating BMI with mortality risk**: [Using maximum weight to redefine body mass index categories in studies of the mortality risks of obesity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3985598/) | *Population Health Metrics* (A Stokes 2014) | [19:30]

**Episode of** ***The Drive*** **with Rudy Leibel**: [#33 – Rudy Leibel, M.D.: Finding the obesity gene and discovering leptin](https://peterattiamd.com/rudyleibel/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 17, 2018) | [30:15]

**Book by Herman Pontzer**: [Burn: New Research Blows the Lid Off How We Really Burn Calories, Lose Weight, and Stay Healthy](https://www.amazon.com/Burn-Research-Really-Calories-Healthy/dp/0525541527/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651495897&sr=8-1) by Herman Pontzer (March 2021) | [32:00, 59:00]

**Stephan’s book** ***The Hungry Brain***: [The Hungry Brain: Outsmarting the Instincts That Make Us Overeat](https://www.amazon.com/Hungry-Brain-Outsmarting-Instincts-Overeat/dp/125008119X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1649439652&sr=8-1) by Stephan J. Guyenet (2017) | [42:30, 2:18:45]

**Recent GWAS study of genes correlating with difference in BMI**: [Meta-analysis of genome-wide association studies for height and body mass index in ∼700000 individuals of European ancestry](https://academic.oup.com/hmg/article/27/20/3641/5067845) | *Human Molecular Genetics* (L Yengo *et al.* 2018) | [49:00]

**Twin studies on the heritability of obesity**: [Variability in the heritability of body mass index: a systematic review and meta-regression](https://www.frontiersin.org/articles/10.3389/fendo.2012.00029/full) | *Frontiers in Endocrinology* (CE Elks *et al.* 2012) | [46:30]

**GWAS studies of obesity**: [Heritability enrichment of specifically expressed genes identifies disease-relevant tissues and cell types](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5896795/) | *Nature Genetics* (HK Finucane *et al.* 2018) | [53:45]

**Neuropod cells in the intestinal epithelium sense nutrients and transmit this information to the brain**: [A gut-brain neural circuit for nutrient sensory transduction](https://www.science.org/doi/10.1126/science.aat5236) | *Science* (MM Kaelberer *et al.* 2018) | [1:17:45]

**Nutrients sensed in the gut activate reward centers in the brain**: [A Neural Circuit for Gut-Induced Reward](https://www.cell.com/cell/fulltext/S0092-8674(18)31110-3) | *Cell* (W Han *et al.* 2018) | [1:18:15]

**Book on the carnivore diet, Stephan reviewed**: [The Carnivore Code: Unlocking the Secrets to Optimal Health by Returning to Our Ancestral Diet](https://www.amazon.com/Carnivore-Code-Unlocking-Returning-Ancestral/dp/035846997X/ref=sr_1_1?crid=1WJ9D0UBCEPZQ&keywords=the+carnivore+code&qid=1651673834&sprefix=the+carnivore%2Caps%2C117&sr=8-1) by Paul Saladino (August 2020) | [1:21:45, 1:27:30, 1:33:45, 2:13:30, 2:16:15]

**Red Pen review of** ***The Carnivore Code***: [Red Pen Reviews: The Carnivore Code: Unlocking the Secrets to Optimal Health](https://www.redpenreviews.org/reviews/the-carnivore-code/) | Stephan Guyenet, Red Pen Reviews | [1:21:45, 1:27:30, 2:13:30]

**Survey of people on a Carnivore Diet**: [Behavioral Characteristics and Self-Reported Health Status among 2029 Adults Consuming a “Carnivore Diet”](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8684475/) | *Current Developments in Nutrition* (BS Lennerz *et al.* 2021) | [1:28:00]

**Podcast with Stephan Guyenet and Kevin Hall**: [#429: Kevin Hall, PhD & Stephan Guyenet, PhD – Carbohydrate-Insulin Model vs. Energy Balance Model](https://sigmanutrition.com/episode429/) | Host Danny Lennon, [Sigma Nutrition Radio](https://sigmanutrition.com/) (March 9, 2022) | [1:34:30]

**Review of the energy balance model of obesity**: [The energy balance model of obesity: beyond calories in, calories out](https://academic.oup.com/ajcn/advance-article/doi/10.1093/ajcn/nqac031/6522166) | *The American Journal of Clinical Nutrition* (KD Hall *et al.* 2022) | [1:35:30]

**Review of the carbohydrate-insulin model of obesity**: [The carbohydrate-insulin model: a physiological perspective on the obesity pandemic](https://academic.oup.com/ajcn/article/114/6/1873/6369073?login=false)  | *The American Journal of Clinical Nutrition* (DS Ludwig *et al.* 2021) | [1:35:30]

**Episode of** ***The Drive*** **with Rick Johnson**: [#194 – How fructose drives metabolic disease | Rick Johnson, M.D.](https://peterattiamd.com/rickjohnson2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 7, 2022) | [1:41:15]

**David Ludwig’s recent publication on the correlation between insulin levels and loss of fat versus lean tissue**: [Stimulated Insulin Secretion Predicts Changes in Body Composition Following Weight Loss in Adults with High BMI](https://pubmed.ncbi.nlm.nih.gov/34587231/) | *Journal of Nutrition* (JMW Wong *et al.* 2022) | [2:03:30]

**Red Pen Reviews, Stephan’s website that reviews books on nutrition**: [Red Pen Reviews: Expert health and nutrition book reviews that sort fact from fiction](https://www.redpenreviews.org/) (2022) | [2:11:00]

**Books recently reviewed by Red Pen Reviews:**

- [The Ultimate Volumetrics Diet: Smart, Simple, Science-Based Strategies for Losing Weight and Keeping It Off](https://www.amazon.com/Ultimate-Volumetrics-Diet-Science-Based-Strategies/dp/0062060643/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651760964&sr=8-1) by Barbara Rolls and Mindy Hermann (2012) | [2:13:45]

- [The Carnivore Code: Unlocking the Secrets to Optimal Health by Returning to Our Ancestral Diet](https://www.amazon.com/Carnivore-Code-Unlocking-Returning-Ancestral/dp/035846997X/ref=sr_1_1?crid=1WJ9D0UBCEPZQ&keywords=the+carnivore+code&qid=1651673834&sprefix=the+carnivore%2Caps%2C117&sr=8-1) by Paul Saladino (2020) | [1:21:45, 1:27:30, 1:33:45, 2:13:30, 2:16:15]
- [Eat, Drink, And Be Healthy: The Harvard Medical School Guide to Healthy Eating](https://www.amazon.com/Eat-Drink-Be-Healthy-Harvard/dp/0684863375/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651763545&sr=8-1) by Walter Willett (2001) | [2:14:00]
- [Eat Fat, Get Thin: Why the Fat We Eat Is the Key to Sustained Weight Loss and Vibrant Health](https://www.amazon.com/Eat-Fat-Get-Thin-Sustained/dp/0316387827/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651763580&sr=8-1) by Mark Hyman (2016) | [2:14:00]
- [Grain Brain: The Surprising Truth about Wheat, Carbs, and Sugar–Your Brain’s Silent Killers](https://www.amazon.com/Grain-Brain-Surprising-Sugar-Your-Killers/dp/0316485136/ref=sr_1_1?crid=2YS7OSZ33MNC8&keywords=grain+brain&qid=1651764426&sprefix=grain+brain%2Caps%2C119&sr=8-1) by David Perlmutter and Kristin Loberg (2018) | [2:14:45]

**Recent reviews from** ***Red Pen Reviews*****:**

- [The Ultimate Volumetrics Diet: Smart, Simple, Science-Based Strategies for Losing Weight and Keeping It Off](https://www.redpenreviews.org/reviews/volumetrics/) | Red Pen Reviews (2022)| [2:13:45]
- [The Carnivore Code: Unlocking the Secrets to Optimal Health](https://www.redpenreviews.org/reviews/the-carnivore-code/) | Stephan Guyenet, Red Pen Reviews | [1:21:45, 1:27:30, 2:13:30]
- [Eat, Drink, and Be Healthy: The Harvard Medical School Guide to Eating](https://www.redpenreviews.org/reviews/eat-drink-and-be-healthy/) | Red Pen Reviews | [2:14:00]
- [Eat Fat, Get Thin: Why the Fat We Eat Is the Key to Sustained Weight Loss and Vibrant Health](https://www.redpenreviews.org/reviews/eat-fat-get-thin-why-the-fat-we-eat-is-the-key-to-sustained-weight-loss-and-vibrant-health/) | Red Pen Reviews | [2:14:00]
- [Grain Brain: The Surprising Truth About Wheat, Carbs, and Sugar– Your Brain’s Silent Killers](https://www.redpenreviews.org/reviews/grain-brain-the-surprising-truth-about-wheat-carbs-and-sugar-your-brains-silent-killers/) | Red Pen Reviews | [2:14:45]

**Stephan’s website**: [Stephan J Guyenet, Ph.D.: The Science of Body Weight and Health](https://www.stephanguyenet.com/) | Stephan Guyenet (2022) | [2:19:00]

**List of mistakes Stephan has found in his book** ***The Hungry Brain***: [Stephan J Guyenet, Ph.D.: The Science of Body Weight and Health: Mistakes page for The Hungry Brain](https://www.stephanguyenet.com/mistakes-page-for-the-hungry-brain/) | Stephan Guyenet (2021) | [2:19:00]

**Method used to evaluate books on nutrition by** ***Red Pen Reviews***: [Red Pen Reviews: Method](https://www.redpenreviews.org/our-process/) | Red Pen Reviews (2022) | [2:19:45]

**Stephan’s weight loss management program and courses**: [Ideal Weight Program](https://www.humanos.me/programs/ideal-weight-program) (2022)

§

## People Mentioned

- - [Michael (Mike) Schwartz](https://endocrinology.uw.edu/faculty/michael-schwartz-md) (Professor of Medicine at the University of Washington; Stephan’s postdoctoral advisor) [3:00]

- [Albert (Al) LaSpada](https://www.faculty.uci.edu/profile.cfm?faculty_id=6967) (Professor of Neurology, Pathology, and Biological Chemistry currently at UCI; Stephan’s graduate advisor) [3:00]

- [Katherine Flegal](https://en.wikipedia.org/wiki/Katherine_Flegal) (epidemiologist at the CDC, obesity expert) [15:50]
- [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) (Provost Professor at Indiana University Bloomington School of Public Health, expert in obesity epidemiology) [18:00]
- [Andrew Stokes](https://www.bu.edu/sph/profile/andrew-stokes/) (Professor at the Boston University School of Public Health) [19:30]
- [Rudolph (Rudy) Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md) (Professor of Medicine at Columbia University, expert in the genetics of obesity) [30:15, 43:00, 1:42:38]
- [Herman Pontzer](https://scholars.duke.edu/person/Herman.Pontzer) (Associate Professor of Evolutionary Anthropology at Duke University and author of *Burn*) [32:00, 58:45]
- [Jeffrey (Jeff) Friedman](https://www.rockefeller.edu/our-scientists/heads-of-laboratories/1163-jeffrey-m-friedman/)  (HHMI investigator at The Rockefeller University, discovered leptin) [43:00]
- [John Speakman](https://en.wikipedia.org/wiki/John_Speakman) (Professor at the University of Aberdeen, expert in energy balance) [59:00, 1:03:00, 2:05:15, 2:07:30]
- [Michael Krashes](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/krashes-michael)  (Section Chief at the National Institute of Diabetes and Digestive and Kidney Diseases at the NIH, expert on appetite) [1:07:45]
- [Steven Gundry](https://en.wikipedia.org/wiki/Steven_Gundry) (Physician and author of [*The Plant Paradox*](https://www.amazon.com/Plant-Paradox-Dangers-Healthy-Disease/dp/006242713X/ref=sr_1_1?crid=3OT3HODSB0CSC&keywords=the+plant+paradox+steven+gundry&qid=1651674674&sprefix=the+plant+pa%2Caps%2C104&sr=8-1)) [1:26:30]
- [David Ludwig](https://www.drdavidludwig.com/) (Physician, Professor of Nutrition at Harvard School of Public Health, and author of [*Always Hungry*](https://www.amazon.com/Always-Hungry-Conquer-Cravings-Permanently/dp/1455533866/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651675455&sr=8-1)) [1:28:00, 1:35:45, 1:39:00, 1:41:00, 2:03:30, 2:21:30]
- [Paul Saladino](https://carnivoremd.com/) (Physician and author of [*The Carnivore Code*](https://www.amazon.com/Carnivore-Code-Unlocking-Returning-Ancestral/dp/035846997X/ref=sr_1_1?crid=1WJ9D0UBCEPZQ&keywords=the+carnivore+code&qid=1651673834&sprefix=the+carnivore%2Caps%2C117&sr=8-1)) [1:28:45, 2:13:30]
- [Shawn Baker](https://twitter.com/sbakermd?lang=en) (Physician and author of [*The Carnivore Diet*](https://www.amazon.com/Carnivore-Diet-Shawn-Baker/dp/162860350X/ref=sr_1_1?crid=2G5UA7HDQCUHZ&keywords=the+carnivore+diet+shawn+baker&qid=1651677271&sprefix=the+carnivore+diet+sh%2Caps%2C99&sr=8-1)) [1:29:15]
- [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) (Section Chief at the National Institute of Diabetes and Digestive and Kidney Diseases at the NIH, expert on diet and metabolism) [1:34:30, 1:36:00]
- [Richard (Rick) Johnson](https://som.ucdenver.edu/Profiles/Faculty/Profile/9426) (Professor of Medicine at the University of Colorado) [1:41:15]
- [Seth Yoder](https://thescienceofnutrition.wordpress.com/) (nutrition scientist, helped start [*Red Pen Reviews*](https://www.redpenreviews.org/))
- [Barbara Rolls](https://hhd.psu.edu/contact/barbara-rolls) (Author of [*The Ultra Volumetrics Diet*](https://www.amazon.com/Ultimate-Volumetrics-Diet-Science-Based-Strategies/dp/0062060643/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651760964&sr=8-1), Professor at PennState) [2:13:45]
- [Walter Willett](https://www.hsph.harvard.edu/walter-willett/) (Author of [*Eat, Drink, And Be Healthy*](https://www.amazon.com/Eat-Drink-Be-Healthy-Harvard/dp/0684863375/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651763545&sr=8-1), Professor of Medicine at Harvard) [2:14:00]
- [Mark Hyman](https://drhyman.com/about/) (Author of [*Eat Fat, Get Thin*](https://www.amazon.com/Eat-Fat-Get-Thin-Sustained/dp/0316387827/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1651763580&sr=8-1), [Physician at the Cleveland Clinic](https://my.clevelandclinic.org/staff/19048-mark-hyman#:~:text=About%20Mark%20Hyman%2C%20MD&text=He%20is%20the%20founder%20and,the%20Institute%20for%20Functional%20Medicine.)) [2:14:00]
- [David Perlmutter](https://www.drperlmutter.com/about/) (Author of [*Grain Brain*](https://www.amazon.com/Grain-Brain-Surprising-Sugar-Your-Killers/dp/0316485136/ref=sr_1_1?crid=2YS7OSZ33MNC8&keywords=grain+brain&qid=1651764426&sprefix=grain+brain%2Caps%2C119&sr=8-1), [Neurologist](https://www.ifm.org/about/profile/david-perlmutter/)) [2:14:45]

§

![](https://peterattiamd.com/wp-content/uploads/2022/06/bio-image-guyenet.jpeg)

##### Stephan Guyenet, Ph.D.

Stephan Guyenet earned his BS in biochemistry at the University of Virginia and PhD in neuroscience at the University of Washington.  He then went on to study the neuroscience of obesity and eating behavior as a postdoctoral fellow in Mike Schwartz’s lab.  He’s spent a total of 12 years in the neuroscience research world studying neurodegenerative disease and the neuroscience of body fatness.  His publications in scientific journals have been cited more than 3,600 times by his peers.

Today, he continues his mission to advance science and public health as a researcher, science consultant, and science communicator.  His book, [*The Hungry Brain*](https://www.amazon.com/Hungry-Brain-Outsmarting-Instincts-Overeat/dp/125008119X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1649439652&sr=8-1), was released in February of 2017 and was named one of the best books of the year by *Publishers Weekly* and called “essential” by *The New York Times Book Review*.  He is a Senior Researcher at *GiveWell* and scientific reviewer for the [Examine.com](https://examine.com/about/) Research Digest.  Past clients include the *Open Philanthropy Project*.

He is the founder and director of [*Red Pen Reviews*](https://www.redpenreviews.org/), which publishes the most informative, consistent, and unbiased popular health and nutrition book reviews available.  He is the primary designer of an innovative course-based body weight management program called the [*Ideal Weight Program*](https://www.humanos.me/programs/ideal-weight-program), which is part of the *HumanOS* platform.  He periodically contributes to the scientific literature and is a review editor at *Frontiers in Nutrition*.  [[Stephan J Guyenet, Ph.D](https://www.stephanguyenet.com/)]

Twitter: [@sguyenet](https://twitter.com/sguyenet?lang=en)