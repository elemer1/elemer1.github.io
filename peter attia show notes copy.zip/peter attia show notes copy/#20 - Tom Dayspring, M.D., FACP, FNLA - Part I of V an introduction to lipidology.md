# #20 – Tom Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology

**Source:** [https://peterattiamd.com/tomdayspring1/](https://peterattiamd.com/tomdayspring1/)

---

##### Check out our 5-part series with Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology:

- *(October 15, 2018)* [Part I of V: An introduction to lipidology](/tomdayspring1/)
- *(October 16, 2018)* [Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](/tomdayspring2/)
- *(October 17, 2018)* [Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](/tomdayspring3/)
- *(October 18, 2018)* [Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](/tomdayspring4/)
- *(October 19, 2018)* [Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](/tomdayspring5/)
- *(September 21, 2020)* [**FOLLOW-UP:** The latest insights into cardiovascular disease and lipidology](/tomdayspring6/)

In this five-part series, Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology, and one of Peter’s most important clinical mentors, shares his wealth of knowledge on the subject of lipids. Part I serves as an introduction to Tom, his work, and an overview of lipid terminology.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tomdayspring1/the_Drive_public.png)

Play

#20 - Thomas Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology

#20 - Thomas Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology

1x15s30s

0:001:14:28

We discuss:

- Tom’s recent and remarkable physical transformation [6:30];
- The moving stories behind Tom’s obsessions: firefighting, hockey, and, of course, lipids [20:30];
- Tom’s medical background [39:30];
- Producing some of the most accessible diagrams on lipids [50:00];
- What are the different kinds of lipids, what do they do, and how are they transported? [57:15]; and
- More.

§

## Show Notes

**Note: The following is a transcript, including added (and original) figures provided by Thomas Dayspring, M.D., FACP, FNLA, along with corrections, comments, and post-podcast amplifications by Dr. Dayspring.**

## Tom’s recent and remarkable physical transformation [6:30]

Peter Attia: I think a lot of people have been looking forward to this. I think many people have sort of relied on your insights, your knowledge, over the years as I have, and I think what follows — and I have no idea how long this is going to be — but I suspect it will not be one episode, but this will certainly be the master’s class in Lipidology. Not just for physicians who want to understand this more, but I think for patients too, but there’s so much stuff to talk about before we get into that, and I figure if you’re willing to talk about it, what I’d love to do is have you explain a little bit about this remarkable physical transformation you’ve undergone in the last year which, this is actually the first time I’ve seen you in person in eight months, and I could barely recognize you as you walked down the hall to my apartment yesterday.

Tom Dayspring: Well, many people who have seen glimpses me on the internet or whatever, in person, God knows how many lectures I’ve done across our great country, I’ve always known, jeez, for a lipid guy and a cardiometabolic guy, he’s kind of obese, so he probably doesn’t always practice what he may be preaching. So indeed I’ve had a long, long experience with obesity and insulin resistance and cardiometabolic disarray. And always had the usual million excuses why I didn’t have to do anything about it, I felt good, nothing was happening to me. And I just kept ignoring it. But I did keep aging.

Tom Dayspring: So for those who don’t know, I reached 72 years of age this year, 71 last year and I’ve been great friends with Peter for a long time. And Peter, of course, has been harping on me to do better nutritionally and I just stumbled into [his lecture](https://vimeo.com/228845024), done up at MIT, where he talked a lot about longevity and hey, 80 is the average age of death in the United States, and I was an old man. I can see a little light at the end of the tunnel, like jeez, if 80 is the average age of death, how much longer do I got to go?

Tom Dayspring: And over the last five, six years, I’ve dealt with a bunch of morbidities, a lot of them arthritic and spinal, but cholecystectomy and fatty liver, were sneaking up on me, even though, other than my bone issues, I’ve felt pretty bad. So I just said, “You know, since I do see the end of the tunnel and Peter’s making a lot of sense, what he’s talking about, all about longevity here, maybe I ought to listen to what he’s preaching here.” And he did raise a topic of intermittent fasting during that talk.

Tom Dayspring: I sort of figured I got to do low carbs, finally, more than I ever did, but the fasting was kind of new to me, and in further conversations with Peter he just kind of put me on an incredible regimen he’s developed. It’s a modified intermittent fast that, I said, “I can do that,” and I did it and as Peter says, that was 67 pounds ago over the last 11 months. I’ve just finished my 11th month. I do one week a month of 700 calories or less, pretty significant carb restriction.

**[10:00]**

Tom Dayspring: And it’s not only the weight is coming off, but a bunch or residual orthopedic symptoms I was having that I just thought I’m going to have to live with the rest of my life, I’ve had hip replacement, several spinal surgeries, 90% of the time, 95%, I feel like I’ve got my normal hip back, my normal spine back. I can walk again.

Peter Attia: Yeah, when we walked to dinner last night and you said that that was a walk you would not have been able to do a year ago.

Tom Dayspring: Yeah, a year ago, I could walk a short block and I’d have to sit down and wait for my bones to say, okay, try it again. And now I just don’t have any of those limitations, so it’s been miraculous in a lot of ways, and I think it’s way beyond just the weight loss, too. I think this fasting, whatever else it’s inducing in me, has just changed a lot of things. And we know that because look, I work for a laboratory, I can do a lot of sophisticated testing on myself and checking every cardiometabolic marker that pretty much a lab can do nowadays, and there was some ugliness to my report a year ago. Those who follow the lab I work for know it’s reported in red, yellow, and green. Green is “you’ve got an optimal level” of whatever, and it went from a pretty yellow, red report, to 100% green report. So it’s not only, jeez, I’m feeling so much better: biochemically, I’m doing unbelievable.

Tom Dayspring: And I mean, I’m happy about all of that, but the disappearance of the aminase levels have been especially impactful.

Peter Attia: Yeah, so I’ll interject to just add some commentary. So the first thing I would say is, you were quite resistant I recall, when we first had the heart-to-heart. So you called me after you saw the MIT video. I don’t even know why you saw it. I don’t think I sent it to you.

Tom Dayspring: I think you linked it to me.

Peter Attia: Did I?

Tom Dayspring: And one last joke about that, you know, I’m good friends with Peter, I don’t want to ignore anything he sends me. I send him a lot of stuff and I know he reads most of it, and I said, “All right, I’ll humor him, I’ll listen to ten minutes of this lecture, and at least I can be honest and say, yeah, I listened to it.” And I put it on and I’m a busy guy, I don’t have an hour and a half to listen to a podcast and I just couldn’t stop listening to it. I went right to the end. I’ve listened to it one more time. I’ve referred it to many other people to listen to, so it’s one of these things in life that somehow it really impacted me on that day.

Peter Attia: Which is interesting because the first ten minutes are not particularly interesting, so I don’t know, luckily we snuck you through, but, I’d always had this concern because over the past seven years we’ve known each other, you see my labs, I see your labs, and I’d always been kind of concerned about those LFTs and it was like they were getting higher and higher and there were a number of other things I was concerned with. So when you responded to me saying, hey, I want to do something about this, and I said, “You know, in the past, you’ve had a hard time just adhering to carbohydrate restriction, I think we need to try something a little bit more extreme.

Peter Attia: And so, what I proposed, as you said, was this idea of doing a modified fast, and this is sort of loosely based on Valter Longo’s five-day [FMD](https://prolonfmd.com/fasting-mimicking-diet/), but we kind of took it a little more extreme, so a slightly higher ratchet up on the caloric restriction during five days, and also doing it every single month as opposed to quarterly, and also, in Longo’s version of the fast, it’s focusing on the restriction of protein, so it’s actually relatively high carbohydrate. We wanted to restrict carbohydrates, both inside and outside of the FMD. Well, you expressed enormous reservation, just like at a practical level, like, “Peter, I don’t think I can do this.” And so what I think I wanted to point out was that it was amazing that you took that plunge the first time, because I remember that first one you did last, I think, October.

Peter Attia: And you worked very closely with Nicole, who’s our dietitian inside the practice and she was just incredible at sort of guiding you through the logistics of what does it actually mean to eat 700 calories a day of basically no carbohydrates, and then once you emerged from that, what are you going to. Do you remember what it felt like after that first time?

Tom Dayspring: Yeah. And look, I was highly motivated because of morbidities I had, my age, and figured I’m a time bomb, something more is going to happen, I sure don’t want to go undergo more with orthopedic degenerative arthritic changes, and my gallbladder is gone, but that fatty liver, and how many liver cells do I have left. My big worry for what I do, is cognitive impairment as time goes on, and I was certainly headed toward ugliness in that direction also. And as you start approaching it, I want to hang around. I got a Son. I got a great life. I want to be here for a while. So, I was super motivated, which 20 years ago, if we even knew this stuff, I don’t know how motivated I would have been. So the end was near. And just being so motivated, even though when I looked at Peter’s recommendation and Nicole’s, I was like, “Wow, I don’t think I can do this. You want me to…”

Tom Dayspring: To me the caloric restriction for those five days was you’re starving yourself and I just didn’t think my body would allow me to do that, as a guy who’s used to nibbling all day long, every day of the week. But the motivation made me, “I’ll try it. If it doesn’t work, it doesn’t work,” but he had convinced me in that talk that it was a good chance to shut down a lot of these metabolic pathways that were contributing to my morbidities.

Tom Dayspring: So with Nicole’s great help and understanding how to put together meals, especially during that week and with an incredible wife, who’s willing to prepare my meals, I did it. And you know, that first five-day fast, by day two or three, the hunger pangs are there and, “Oh my God, can I do it?” But no, I got to do this. And it’s kind of funny. After day three, the hunger disappears and on subsequent fasts, sometimes I go five days I don’t even feel hungry during it. Maybe sometimes. Like last month I did it, the third day, which I do it a Monday through Friday, the Wednesday, “Oh God, I’m kind of hungry. I felt kind of weak today,” but it lasted half of that day and then just passed. So I really tolerate those five-day fasts well and the results are so astronomical. The weight just poured off. We rapidly repeated some of the biomarkers and for a guy like me, whose life is looking at biomarkers in people, and seeing it was just so impressive that this has got to be doing good things to my body.

Tom Dayspring: And symptom-wise, symptoms disappeared that I didn’t realize, I didn’t realize I couldn’t walk up a flight of steps without being a little bit short of breath or things like that, and that’s just all gone.

Tom Dayspring: So there were a lot of rewards that came quickly and the fasting wasn’t as horrific as I thought it was going to be.

Peter Attia: Yeah, I think people who listen to me talk have got the sense that I’ve become more and more a proponent of fasting as an adjunct to dietary restriction. Of course, dietary restriction meaning the restriction of certain macronutrients, so carbohydrate restriction would be a form of dietary restriction, protein restriction would be, say, meat restriction, for those who choose to be vegetarian or vegan, that would be a form of dietary restriction. And all of these things can offer benefits potentially. But caloric restriction, the actual restriction of the total number of calories, for limited periods of time, I think has to be a cornerstone of what we do. Because it is simply the most powerful way to deplete glycogen. It is simply the most powerful way to reduce insulin. It is the most powerful way to turn those nutrient sensing organelles and molecules off. And we know that we don’t want those things off indefinitely, but we know that our current living environment, where they’re basically always on. You are constitutively fed. It’s evolutionarily unnatural and in the metabolically ill person, it might be the single most destructive thing you can do.

Peter Attia: And I’ve said this before and I’ll say it again, Tom, my intentions, I wish I could say it was just altruistic. It was incredibly selfish, my motivation for this. I just, I remember sitting down and saying this to you in October or September last year. I was like, “Look, Tom, the impact your teachings have had on me personally, and therefore by extension on all of my patients, it can’t be measured.” And so, I started jokingly, and I’d been calling you this for a couple of years, I’ve been referring to you as the national treasure. And I remember saying this to your brother when we had dinner with him a few years ago and he kind of rolled his eyes at me. I’m sorry, to your son, to Brad, and so, I just said, “Look, this is a selfish motivation I have to keep Tom around as long as possible.” So, as long as I can be transparent about that.

Tom Dayspring: You’re very kind. But the other good thing about your talk, look, I’m basically a scientist. I don’t try and ad lib and make things up, like so many people do to support whatever they believe, but there was just so much plausibility and the science behind a lot of what you said seemed very real to me and I did a little reading and so that sort of boosted me, too. Peter’s just not making this stuff up, it’s beyond the theory stage, I think. And if we look at our evolutionary genetic ancestry and what our human ancestors, the way they ate years ago, it just makes a lot of sense. So here I am and I’m not giving it up any time soon.

Peter Attia: Well, and I’m holding out hope that my Dad is listening to this or will listen to this. I don’t think he’s ever listened to one of my podcasts, but I might insist that he at least listen to this portion of this podcast because if I could get my Dad to do this, that would be, again probably for selfish reasons, that would be sort of the highlight of my life. And you’ve generously offered to speak with my Dad because he certainly won’t do what I would recommend. So it would have to be Nicole and you sort of cajoling him into trying this. And Nicole has also offered to help in any way. So Dad, if I can get you to listen to this, I hope you’d consider doing this.

**[20:00]**

Peter Attia: Well, first of all just watching the transformation you’ve just described unfold over the last seven, eight months, it’s blown my mind because I’ve worked with many patients over many years and I’ve almost never seen the level of fastidious dedication to adherence that I’ve seen from you. I’ve known you for many years before and you’ve been sort of ambivalent towards this, so it was sort of this question of once the switch flipped, there was no wavering. Now, I didn’t make the connection at the time, but I think more recently I’ve realized that’s just kind of the Dayspring way. So before we get into lipids, I want you to tell me about the very first obsession you had.

## The moving stories behind Tom’s obsessions: firefighting, hockey, and, of course, lipids [20:30]

Tom Dayspring: Well I’ve had a few obsessions in my life. There is more to me than just understanding biochemistry and cholesterol and other lipids and probably the first thing in my life was being born to two incredible parents, one of whom was a professional firefighter in the city of Paterson, New Jersey, New Jersey’s third largest town. So when you’re a son of a firefighter (Figure 1), real early in life you’re visiting firehouses and being exposed to the incredible men who are firefighters and all their glorious machines that are sitting there in the firehouses, these big, red things with bells on them and sirens that, when they start them up, make a lot of noise. Every once in a while, your mom brings you to some major conflagration where you see your Dad running in and out of buildings that are collapsing and on fire.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-36.png)

**Figure 1. Tom Dayspring, son of a firefighter.**

Tom Dayspring: So I just developed an unbelievable passion and love for firefighting, which remains to this day. I’ll put in a plug. I run one of the most viewed and largest historical firematic firefighting websites in the United States, it’s [patersonfirehistory.com](https://www.patersonfirehistory.com/) if anybody would like to [visit] it and you’ll see there are thousands of pages of thousands of photographs and incredibly documented data on the Paterson, New Jersey fire department, which has, very unusually in the United States, it goes back 200 years. Paterson was formed by [Alexander Hamilton](https://en.wikipedia.org/wiki/Alexander_Hamilton) right after the revolutionary war, as a mega-industrial town because of a giant waterfall that was in the town so they had a need for firefighting early on. So you really can trace the entire history of firefighting in the United States by focusing on Paterson and it applies to New York and other towns that have been around for a long while.

Tom Dayspring: So I’ve just had a great passion for doing that. So, of course, I wanted to be a firefighter, too. So to collect the 30, 40 years of data that is now my website, you got to be a little bit of a nut job with a passion for firefighting to do that, and I was able to collect that material through of course having a father who was well connected in firefighting world. But I put my heart and soul into it.

Tom Dayspring: When I was an adult, after med school, I used to go to every antique market around firematic flea shows to collect. I collected one of the largest displays of firematic antiquities that were around in the United States outside of a museum.

Peter Attia: I didn’t even know that was a word, by the way. I just like the way that sounded.

Tom Dayspring: Firematic.

Peter Attia: Firematic antiquities.

Tom Dayspring: Yeah. And there are a bunch of nut jobs like me who are very much into this. It’s funny-

Peter Attia: You were recently given an award.

Tom Dayspring: I was because of my dedication to Paterson, documenting all this. They’re so proud of it. It’s probably the most visited historic fire department website in the United States. The department very much respects what I do. At a certain point, it became very cooperative with sharing some of their archival material that my father hadn’t stolen when he was a chief officer of the department years ago. So the latter years have had their cooperation, but they brought me up to a memorial ceremony they had in June recently. They have a monument up there where if you make the supreme sacrifice if you’re a firefighter who dies in the line of duty, you get your name on this beautiful bestowed monument outside their fire headquarters.

Tom Dayspring: And they’ve had 28 firemen, unfortunately, have their name on that monument over the last couple hundred years and through my archival analysis, in 1938 I found the name of a firefighter who died on the job. He dropped dead as he was carrying a big hose and running to a fire hydrant to hook it up. And it sort of got ignored. Now in 1938, he obviously died of a heart attack at the scene. He was 50-some years old. Dying of a heart attack while you were fighting a fire was not considered a fireman’s death at that time. If a wall collapsed on you it would have been. But nowadays, it certainly is. If you have a heart attack at a fire, you would get your name on the monument, your colleagues would mourn you heavily. So I actually found the data buried deep in the files that this guy dropped dead at a fire scene. I went to the library, got the newspapers that documented it, and I presented it to the department.

Tom Dayspring: So lo and behold, they added the 29th name to the monument, fireman Edward Moore died in 1938, so a little belatedly, but his name is there. So I wanted to go up and see that presentation and the chief said, “Tom, would you get up and just tell this crowd a little bit about who Edward Moore was, because none of them will certainly know him?” So I made a little three, four-minute speech on who he was, what happened to him and I started to walk back to my seat and the chief said, “No, Tom, don’t leave the podium yet.” And he said, “You know, to make a long story short, what you’ve done for the department, we are for the first time in the department history, making you an honorary battalion chief (Figure 2).”

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-37.png)

**Figure 2. Tom Dayspring, honorary battalion chief.** With Chief Brian McDermott (left) and Deputy Chief Kevin Hancock of the Paterson Fire Department.

Tom Dayspring: It’s the highest honor a professional fire department can ever give to a civilian. They will never give you a rank above a battalion chief, a deputy chief, assistant chief or a top chief, but me, a battalion chief? My dad was a chief for 30 years in the Paterson fire department. Starting as a battalion and a deputy and assistant. I just can’t display the emotions that went through me. Because my life, I always wanted to be a fireman, Dad twisted my arm and said, “No, you’re going to college and you’re going to study whatever you want to study, but you’re not joining the fire department out of high school.” Which I probably really wanted to do.

Tom Dayspring: And as tears were in my eyes, there were 400 people in the audience at this big ceremony, I just looked to the skies and hoped I was additionally making my father very proud of me. And he was proud of me because of my medical career of course. So, my love and passion of firefighting got me this, and just to finish that story, because they told me, “You’re the first person we’ve awarded battalion chief to,” but they didn’t know, I know their history. Back in the 1960s, a woman was made an honorary battalion chief in the Paterson fire department and it happened to be a nun at one of the big hospitals in Paterson, a Sister Loretta Agnes. Now, what do you know? One of the major reasons I’m a doctor and I trained actually at St. Joseph’s Hospital in Paterson, New Jersey, because I really wanted to practice in that area. She was a friend of the family, a nun, and would visit our house all the time and she knew I was pursuing a medical career and she used to always harp on me, “Oh, you’ve got to come and visit our hospital. I’ll give you the grand tour and you can hang out there in the emergency room if you want and just get to know our hospital.” Mr. Smart Ass here, “No, I’m going to go to some big university hospital here and so I want nothing to do about a hospital in Paterson, New Jersey. Even though it’s 700 beds and it’s a large hospital with a teaching program.

Tom Dayspring: But I took her up on it, and I was a freshman medical student at the time, and she just let me hang out in the emergency room and I hooked up with a couple of docs who worked there. I would go in the evening after finishing classes, I would go hang out in St. Joe’s and I don’t know. It’s a large part of who I am, what I do. It fit in perfectly. I’m a fireman, the emergency room is where all the action is happening. So Sister Loretta had a mega influence, and I did go to train there and she was a Godsend to patients, so I interacted with her so much.

Tom Dayspring: But Sister Loretta was made an honorary battalion chief (Figure 3) by the department because of her care that she extended to every firefighter who was ever brought to St. Joseph’s Hospital in Paterson, New Jersey. So there are two honorary chiefs in our history, linked in other ways, you know. So it’s just kind of spooky how that turned out. But just a great honor. And on my desk at home, I have a blotter that, is like a plastic top, so I can stick things that are important to me underneath it. I have my mother and father’s, the little card that was at their funeral that funeral homes put out. I’ve got some pictures of my son there. And I’ve got a mass card that my wife and I gave Sister Loretta on her passing. It’s impactful. And last, but not least, the fire department actually now does an annual Sister Loretta Agnes dinner for the clergy in Paterson, and I kind of laughed: about two years ago, they called me up and said, “Did you ever hear of Sister Loretta Agnes?”

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-38.png)

**Figure 3. Tom’s father, Assistant Chief Joseph Dayspring, with Sister Loretta Agnes.**

Peter Attia: Does a bear shit in the woods?

Tom Dayspring: Yeah. Yeah. So actually, on our website now, I have a [whole page dedicated to her](https://www.patersonfirehistory.com/sister-loretta.html) and what she’s done for the fire department, so it’s kind of funny.

Peter Attia: Well, yeah, I mean, we could probably spend another hour talking about that and I know that our listeners would actually appreciate it but that said, there are a couple other things I want to get to, even before we get to the lipid stuff.

**[30:00]**

Peter Attia: The other things that we connected on pretty early was I realized you were a hockey fan. Of course, I grew up in Toronto, and I don’t think you can grow up in Canada without being a hockey fan, without playing hockey, and being obsessed with it. Certainly when I was a really young kid, probably until I was about 13, it was hard to think of anything but hockey. And it turns out, just as you had this real light-switch moment with all these things we’ve talked about, you had kind of that flip-of-the-switch moment in hockey, too, right?

Tom Dayspring: I sure did, and it was very easy to grow up in New Jersey in the 1950s, and the early ’60s without knowing what ice hockey was, or even ice skating per se, other than a month or two on a pond, maybe, in January. When I was a young boy, a defining moment in my life was the first visit, my Dad picked me up in a car and brought me to Yankee Stadium, and I walked into, probably in the early ’50s, into that stadium in the green grass, and these Yankees running around in their white uniforms and pinstripes, so I became a mega baseball fan growing up. A New York Yankee diehard, which I remain to this day. And that was a transforming moment to be sure, it’s the sport we played as a kid, Wiffle ball all the time, me pretending I’m Mickey Mantle (Figure 4) and the pitcher would be Whitey Ford throwing to me.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-39.png)

**Figure 4. September 12, 1958: Tom met Mickey Mantle in the Yankee Clubhouse where he signed this picture.**

Tom Dayspring: But in 1962, while in high school, my best friend was another young man who also had firefighting as a passion. I always joke, I think I became his best friend because he knew my father was one of the fire chiefs in Paterson. He wanted to hang around with a fire chief’s son, but who cares? I loved the guy, and we grew up and became so close in high school, but for some reason, he was a hockey fan and he says, “I go to Madison Square Garden occasionally, I’d like you to come with.” “Why not?”

Tom Dayspring: So I went over, and I remember to this day, it was probably 1962, maybe it was in freshman, sophomore year in high school, you walk into the old, and I’m talking the old Garden, up on 8th Ave and 49th Street, it was a dark, dingy place, you’re walking in, you almost need night vision goggles. But all of a sudden, you walk into a spot where the glow of that white ice strikes you and out come these guys in red, white, and blue, the New York Rangers, who at that time were wearing no helmets…and the other team. There were only six teams [at the time] so the competition was unbelievable. I just fell in love instantly. One game and I knew, I just have to start following this sport, and I told Peter within the year, not only did I say I have to watch this, I went out and bought myself a pair of skates, which wasn’t easy to do back in those days, and me and one other buddy, at night, in the winters, we started going to a local pond we knew about.

Tom Dayspring: We were the only two people out there and we just taught ourselves how to ice skate. We bought some hockey sticks, started playing, one thing led to another, convinced a few other young friends to do it and within a year or two, we knew the one or two rinks that were within 50 miles of our house, so we would drive down there and rent the ice for an hour. And so I became a pretty decent hockey player (Figure 5) considering I didn’t grow up in Canada. At least playing against New Jersey competition, and over time, joined men’s leagues and some of my best friends in life now are not doctors, they’re guys I played men’s league ice hockey with, beer hockey as they call it nowadays, or whatever, because after you’re done with the rink, you know where you wound up for a while.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-40.png)

**Figure 5. Tom Dayspring, hockey player.**

Tom Dayspring: And I played until I was 50 years old and the last part of my hockey story, of course, when I was so lucky my wife and I have a child, who turned out to be a boy. When he came home from the hospital, my wife and I drove him home, brought him upstairs, put him in this wonderful bedroom we had put together with a crib in it and what was laying in his crib? A small hockey stick that was about 4 feet long. I wanted him to imprint on it like the ducklings do to the mother duck, and as it turns out, my Son turned out to be an incredible lifelong hockey player at every level, youth hockey, high school and college and-

Peter Attia: He was the team captain in college (Figure 6), wasn’t he?

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-41.png)

**Figure 6. Brad Dayspring, Tom’s son.**

Tom Dayspring: He’s just had leadership abilities. I credit that to my father. He was probably the captain of every team he was ever on, from right up through high school and into college and so I’m very proud of him. So a large part of my life was not only playing hockey as I grew up, watching hockey, but every night of my life, I was at a practice, watching him. And so, again, some of my best friends were other hockey parents. Again, I was hanging out with all the docs and going to the doctor’s balls and that kind of stuff. They never saw me.

Tom Dayspring: And in practice for 37 years I just had a Godsend of a fellow, I call him a brother really, my associate, who just covered my tail every time I wanted to run, “Hey I got to go to practice with Brad. Or I got to go play hockey.” He just covered the practice and it made my life easier. So yeah, that’s the other super passion of mine. When I say dedicated to hockey, even when I was in med school, when class was over I was going to a rink or someplace or I’d show up in my greens, because, “Hey guys, cover for me for a few hours, we got a game tonight.” And that’s how crazy I was. In my medical school yearbook, you’ll see a picture of Tom Dayspring and the class voted, you know we’re going to predict what everybody’s going to wind up and I was predicted, of course, to be the future New York Rangers team physician. Which I never did achieve, but close enough.

Peter Attia: Well, it’s not too late, so we should add that to the list of things we might try to figure out how to tee up. You know, it’s so funny, because I grew up in Toronto, the Maple Leafs were also one of the original six. Now I grew up, you know, in the ’70s and ’80s, so by then, the league had expanded and I very quickly fell in love with the Edmonton Oilers, who would very soon go on to become the most dominant team of the ’80s. But even watching them come up before they became that most dominant team, they were just electrifying, thanks to, of course, Wayne Gretzky, but also guys like Mark Messier, who would go on to become captain of the New York Rangers and finally bring glory back to the Rangers after one of the longest hiatuses in sports. It was ’94 when they won the Stanley Cup again, right?

Tom Dayspring: Yep.

Peter Attia: But it’s the same experience. I remember the first time my Dad took me to Maple Leaf Gardens, which of course is not where they play anymore, but it was this old sort of historic kind of dingy arena and I remember one game, because it was like, gold seats were the best, then red, blue, green and gray, and we could afford the grays, but I remember for an exhibition game, where the tickets were a bunch cheaper, the Oilers came to play the Leafs and we got gold seats and I mean, I couldn’t believe what it was like to sit ten feet, maybe a little bit more, maybe 20 feet from the glass and actually see, at the time there was a goalie name Grant Fuhr. I played goalie in hockey, so Grant Fuhr was actually the guy that I was trying to emulate and to see these guys: Jari Kurri, Glenn Anderson, Paul Coffey, Mark Messier, Wayne Gretzky, it was a very special thing to do as a kid and I can certainly relate to that.

Peter Attia: And the older I got, the more I realized that the experience I had was basically going to be shared by every kid growing up, in Detroit, Chicago, New York. I mean, the stuff that you would have seen. Montreal, never mind. You might argue that it was even more fanatical in Montreal than any other place.

Tom Dayspring: Let me just expand on that. Peter is right. If you ever have the opportunity, I mean any hockey game is great, but if you can get such a seat. And way back when, when we were kids going over to the Garden, you know, the lower best seats, a lot of them were corporate, those who could afford those seats, but they didn’t always show up, those guys. So almost always by the third period, we’d be sneaking down there and sitting there as young kids and ushers wouldn’t give you too much trouble if you were showing up in the 3rd period there and it’s just a different game back then. And look, I love the military, nothing can be like in a foxhole when you’re fighting for your life, but when you see what those guys, with the way they look at each other and the way they hit and at top speeds, wow. It’s a different sport.

Peter Attia: Yeah, it’s funny you bring that up. I totally forgot but as a kid, that was my M.O., was we’d get the gray seats, which I think were $5, maybe $9, but that was what we could afford, and we would just take binoculars and lock eyes on seats where we thought people had left and then we’d weasel our way down and it was the same thing, it was just a different era back then. They weren’t electronically scanning tickets, so usually by the end of the game, you were sitting close-

Peter Attia: Very, very close. Oh God, just special memories. Well, let’s get to what everyone really wants to hear. I’m sure nobody wants to hear us bullshitting about hockey and stuff like that.

Peter Attia: Like I said, I don’t even know how we’re going to organize this. We’ve talked very briefly about a loose framework for what we want to talk about. I don’t want to put any restrictions on time, I just want to go as long as we got to go. I’ve set aside an entire day, which for me is almost impossible to do. I think I’m seeing one patient all day today. Then we’ll divvy this up in the end.

Peter Attia: Let’s just start with a definition. What’s a lipid? What’s cholesterol? What are these things?

## Tom’s medical background [39:30]

Tom Dayspring: Before we even do that, let me tell you how I wound up in this world. I went to med school ’68 to ’72. Residency in internal medicine for three years after that. I’ve already told you, I’ve done an extensive amount of time working in emergency rooms, where everybody comes in. In those days acute myocardial infarction was very, very common. You didn’t spend the night in the ER without seeing a couple of them. People coming in and foaming pulmonary edema.

Tom Dayspring: I just recognized early on, that arteriosclerotic heart disease and clinical endpoints are bad news. A lot of those people were young and dying way too prematurely. In those days when you came in, even if we got you through your acute coronary syndrome, pulmonary edema, I mean it’s 50/50. Most of them were dead by morning, or those that survived, then had this morbidity that you had to deal with. I grew up in an era when it was rampant, the acute episodes, that I don’t think they see anywhere near what the frequency, that I did back then.

Tom Dayspring: I just latched on to it. I was lucky those were the days when the concept of a coronary care unit was invented. Mason Sones invented coronary angiography at that time, and our hospital developed probably one of the first departments in New Jersey, that was doing coronary angiography.

Tom Dayspring: That’s the world I decided to start hanging out in. My elective in medical school were all spent in a coronary environment (Figure 7). One year of our residency, the third year, was pretty much elective. So all I did was hang in the angiography lab, or the coronary care unit, or the post coronary floors providing care.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-42.png)

**Figure 7. Tom Dayspring in medical school.**

Tom Dayspring: My first opportunity to go into practice, a cardiology group actually brought me in to, “Hey you manage our hypertension. You do stress testing,” which I had done a lot of, as a resident. Of course, I’d be taking call every fourth night in that group too. It dawned on me, “God, every night I’m being called back to the hospital at two-three in the morning. It’s another acute MI for God sakes.” So I jumped really early on to the prevention strategy. It would be far better to prevent heart attacks than getting up in three in the morning, and praying you could help them survive this episode, that they at least made it to the hospital with.

Tom Dayspring: So early on in life, I just said, “What’s involved with arteriosclerosis?” And early in my career, hey, please don’t smoke. Try not to be fat, which I was not the best example of. And let’s attack your blood pressure, aggressively.”

Peter Attia: I want to pause for a second here, because you said something really interesting that I just hear so often from physicians of your generation, including a physician I’m really close to here in New York, who I share office space with. He’s about your age, runs a very nice concierge practice in the city, and he basically said the exact same thing you just said which is, “We just say MI’s all day, every day. Nonstop.” A week couldn’t go by where one of his patients didn’t have an MI, and then contrasts it with today. He’s like, “I don’t know the last time I saw one. I don’t know the last time I saw a Q-wave MI.” He doesn’t recall.

Tom Dayspring: I get that all the time from young docs, residents, or physicians who have been in practice, but they’re not in a baby boomer era of my age. They’ve all seen obviously, acute coronary syndromes, but it’s a different type of acute coronary syndrome. They don’t see these people coming in and foaming in pulmonary edema. They just don’t know what it’s like the massive transmural MI’s with Q-waves developing, dropping dead before your eyes. Because they’re rushing them right to the cath lab now, and dissolving their clots in everyday modern practice.

Tom Dayspring: I was talking to Peter last night, and it would not be unusual during my residency, if you were the first year resident on board, you covered every admission in our 700 bed hospital. There were nights where I’d get a dozen admissions to the coronary care unit. A dozen of some sort of exacerbation or clinical event related to arteriosclerotic heart disease. Most of them are of most horrific nature.

Tom Dayspring: I just don’t believe that they see that nowadays. Yes they see acute coronary syndromes, but they don’t see the type of acute coronary syndromes we saw back then. So it has changed. Look, we got a long way to go to still eliminate this heart disease. I think if we all jumped on prevention much earlier in life, we’d end this disease. But, yeah, it was a different world back then. Surely was.

Peter Attia: Was there one person that would be your first mentor? The person that specifically got you, not just interested in cardiovascular disease, but pointed you towards lipids, like something about these lipids matter.

Tom Dayspring: No. I sort of discovered lipids by myself. As I said, I was evolving. I wanted to be a preventionist, so I was on the hypertension bandwagon. Then it became pretty obvious after a lot of the big epidemiologic trials starting coming in with more data, [Framingham](https://www.framinghamheartstudy.org/), MRFIT ([Stamler and Neaton, 2008](https://www.ncbi.nlm.nih.gov/pubmed/18799447)). That lipids, specifically cholesterol, was the one they focused early on, was a real big player in here. I realized, and I’m a self-education guy in most of the things, “Alright I’m as up to date as I can be on hypertension in the 1980s, now it’s time for me to start doing some lipid education.” So I started doing a lot of reading.

Tom Dayspring: First course I ever went to, to take lipids to a different level, was out there at the Cleveland Clinic. But the guy that I hooked onto earliest, that really became a major mentor, a good friend, was Dan Rader, down in Philadelphia, who turned out to become a world high-density lipoprotein expert. But just an expert, in my mind, in all things lipids. He was so far ahead of the curve.

Tom Dayspring: So Dan was one of the really early ones. Others I had jumped onto were Tony Gotto, Virgil Brown, Allan Sniderman, and Ron Krauss. People like that, who were really doing the type of investigations that when you started doing lipid reading, you’d find-

Peter Attia: All roads keep pointing to these guys.

Tom Dayspring: Yeah, really did. They were gifted enough also that you could semi-understand what they were writing about and talking about. I told Peter, he said, “How long did it take you?” It was 10 years of serious reading. Anything you could get your hands on. I think the first five years was, you read something, you didn’t even know what you read. But, I was just motivated to keep going back sooner or later. One day I woke up, and it sort of all made sense.

Tom Dayspring: It took a lot of education. I think it’s easier nowadays, because there are phenomenal reviews put together by a lot of people. They just didn’t exist in those days. You had to discover it yourself. If you didn’t spend two years at the NIH doing research on it, you wouldn’t be exposed to it that way.

Peter Attia: Well you’ve also played a big role in that. When I now get to think about how I got into this interest, what sparked my interest: there wasn’t a single moment, but I do remember reading a single document that you had written in 2011. I think I was introduced to it by, remember that guy Greenie [[E. James Greenwald](https://www.specialtyhealthwellness.com/who-we-are/wellness-team/)], up in Reno?

Tom Dayspring: Yes, sure.

Peter Attia: Yeah. So I think Greenie had sent me a document you wrote, and it was the first time I’d even heard of NMR. I mean I knew what NMR was from chemistry, but I didn’t know what NMR was with respect to lipids. So he sends me this document. It was a PowerPoint, but with notes embedded, so it was printed as a vertical. I printed it as a vertical. So each page had a slide, which I would learn later on, were famous Dayspring figures. At the time, I didn’t realize that. Then just great text and prose explaining it. It was 26 pages long or something like that, and it was dense like you can’t imagine. Well, you can imagine, because you made it, there was a density to it. And I’m thinking, “Okay, I know I’m just kind of a dumb surgeon, so it’s not like I ever knew this stuff.” But it was just so captivating. It was like there was a whole other world, that I didn’t know existed. And these particles mattered. I remember feeling like, “How did I not want to know this, when I was going through medical school and training?”

Peter Attia: I guess when you go down that surgical path, you’re not thinking about this stuff. You’re thinking about the surgical ways to address these problems. I mean I read it so many times, because the first few times I was kind of frustrated. I was like, “I don’t know what the hell is going on here. I really have no clue what he’s talking about, and what are these apo- this and apo- that?” I just kept getting confused by the concordance and the discordance between all these particles, but then mid-2011, was when the bug bit me, too.

Peter Attia: To your point, I think so many people today, whether it be physicians, patients, anybody, who wants to understand this topic better, really can look to you and your work as a great way to synthesize the work of these luminary folks, that you’ve alluded to.

Tom Dayspring: It’s kind of funny, because who could have ever imagined that? When I started my lipid journey, I just was a real-world internist with a big practice in Northern New Jersey, and my only real goal was to be a better internist to my patients, most of whom were getting arteriosclerotic or cardiovascular events.

Tom Dayspring: Rather than mastering ulcers and GI bleeds, I just went where the money was, arteriosclerotic heart disease. I invested all my time and effort on learning this, with no grand design that, “Hey Dayspring, whether you know it or not, within 10 or 15 years, you’re going to be the most requested lipid educator in the United States.” How did that ever happen? It just happened, because I taught myself as a dumb real world internist, made it understandable to my brain. Part of the Dayspring learning curve is visual.

## Producing some of the most accessible diagrams on lipids [50:00]

Peter Attia: You said you used to draw.

Tom Dayspring: I draw graphics as I’m reading this stuff. I have no artistic skills whatever. If I draw a human being, it’s that stick figure with a circle as a head. But PowerPoint came along, and there are tools there, which are not that hard to master. I was able to draw and I’m now known as one of the best lipid-lipoprotein illustrators in the country.

Peter Attia: Yeah, we will unquestionably link to maybe your 50 finest diagrams in this podcast, which is to say about 1% of what you’ve produced. But I remember the first time you sent me one of your PowerPoints, I was like, “Oh, this is really interesting.” Either Tom has contracted with an illustrator to do this, or he’s found somebody else that’s already done these. And when you said you had done them, I was blown away, because you have to remember I cut my teeth in PowerPoint at a place like McKinsey, where we’re PowerPoint ninjas.

Peter Attia: I could do anything in PowerPoint. I couldn’t do what you had done. Simply because I didn’t have the time. Those were such complicated figures. If I ever came across that was that complicated, that I needed to make a slide for, I would just get the illustrator to do it. I wouldn’t actually be able to sit there and make it happen. So I couldn’t believe it. I think the listeners who aren’t familiar with your illustrations, are going to find themselves incredibly surprised and grateful for that sacrifice.

Tom Dayspring: So illustrating things made me understand. I mean look, my illustrations got better and better as time went on. Early on, they were a bunch of colored circles. Then I learned shading, and making them move and animate on the slide. I’ve really progressed there, but I just learned by illustrating.

Tom Dayspring: I’ve since had serious educators tell me the human brain just understands things better by seeing pictures and graphically, than reading thousands of words put together. There is no doubt my gigantic success as a lipid educator was I could dumb-down the talk, and try and make you understand complex enzymology, or anything else, the apoprotein and how they interact. But as I’m saying it, in my dumbed-down version, you were looking at it moving on a screen with a graphic. So it made comprehension of advanced lipid-related areas much easier for even a layman, or certainly a physician to understand.

Tom Dayspring: Just the part of who I became. Then somehow, because of all of my intense prepared writing slide notes as Peter said, I became pretty good at putting together prose. I’ve done a little bit of research in my time, because of places I wound up. An author of a research publications. But most of the things you’ll find in the literature of me, are reviews and discussing this, and trying to make you understand concepts. Then you can go read the genius studies, and you’ll understand what they’re talking about.

Tom Dayspring: I just evolved into that. Actually the first guy, it was a cardiologist down in Florida, Michael McIvor. He’s the first guy I ever saw use PowerPoint for lipids. I just used him and he shared a lot his early stuff on. I learned from him. It’s made my life as a well-known lipid educator.

Tom Dayspring: I got opportunities to start doing lipid education, and if you go out and you’re lucky enough to have some people come and listen to you, you better be good at what you do, or they’re going to bad mouth you, and you’ll never be invited back. Or if they do want you to come back, they’re going to like you. They’re going to be in touch with you.

Tom Dayspring: I just developed ways of explaining lipids and illustrating lipids that became huge. Just to finish this — Mike Davidson, who’s one of the all-time Gods in the lipid world in Chicago, still a university professor there, one of the big founders of the National Lipid Association, did at one time during his presidency, bestow their Presidents Award to me (Figure 8), which is given to people who make contributions to lipidology. This is the top lipid organization in the country. It’s like, “How does some real-world internist with no formal lipid training, ever work his way up to an award like that?”

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-43.png)

**Figure 8. Tom Dayspring, 2011 NLA President’s Service Award recipient.**

Tom Dayspring: Mike told me, “surveys were done by the NLA and a lot of people joined this organization, because they heard Tom Dayspring’s lipid lecture.” Mike was a big advocate of teaching through illustration. I’ve illustrated many things from Michael over the years. He’s right. That’s my claim to fame. I hope some of you follow me at [@Drlipid](https://twitter.com/Drlipid), because Twitter is the way to get a lot of my graphics nowadays.

Peter Attia: There’s a lot of stuff that we’ll make sure we link to, but the lipidaholics or the Lipidaholics Anonymous – I used to read those case reports constantly. We’ll have to make sure we can pull all of those things out of the archive, because there are some amazing cases there. But, yeah, we’ll make sure people know where to find you on Twitter and all that stuff, ’cause-

Tom Dayspring: Quickly. When I was on this giant lecture tour, for 10, 15 years of my life, I did generate a weekly newsletter called Lipidaholics Anonymous (Figure 9), where they were one case discussion, all real world, that were in my practice, or sent to me by other docs.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-44.png)

**Figure 9. Lipidaholics Anonymous: Case 291 — [Can losing weight worsen lipids?](https://www.dropbox.com/s/1fbzojwm4lytjss/Dayspring%20-%20Lipidaholics%20Case%20291%20-%20Can%20losing%20weight%20worsen%20lipids%3F.pdf?dl=0) by Tom Dayspring.**

Tom Dayspring: I would just take it to the next level. So I would explain it basically, and then I would, like I’m talking to a lipidologist, illustrate it. It became immensely popular. I had several thousand people. It was free. I sent it out each week in a group email, but it really enhanced my reputation. And it found itself on a lot of desktops

Tom Dayspring: That’s a big part of who I was. I do have most of them still there, but people are like, “Give me all of them.” I don’t want you to know what I was saying in the year 2002, because it’s mostly all wrong nowadays, because we’ve evolved so much. If you want to see what we were talking about in lipids in 2002, they might have some historical interest.

Peter Attia: Yeah, well you just touched on an important point which is, I like to say all facts have a half-life. Some of them are really, really long half-lives. The earth being round, we would call that an incredibly long half-life fact. Half-life is nearly infinite on that.

Peter Attia: But elevated levels of HDL-cholesterol aren’t necessarily a good thing. That’s a fact that I think used to be deemed a fact, based on the epidemiology of Framingham. I think today anyone who’s serious about the study of lipidology would say, that’s grossly oversimplified, potentially incorrect ([Dayspring, 2007](https://www.ncbi.nlm.nih.gov/pubmed/17684448); [Toth et al., 2013](https://www.ncbi.nlm.nih.gov/pubmed/24079290)).

Tom Dayspring: That’s certainly one of the all-time facts that really disappeared. I personally think it’s a waste of time to even put it in the lipid profile, other than it’s used in certain calculations that are popular nowadays, like non-HDL cholesterol. But I encourage no one to ever make a judgment on any human’s cardiovascular risk, based on their high-density lipoprotein cholesterol level, or think you know what you’re doing to a human being if you somehow change that HDL-cholesterol metric in that patient: has nothing to do with anything, to be honest.

## What are the different kinds of lipids, what do they do, and how are they transported? [57:15]

Peter Attia: Alright, so now I’m chomping at the bit. We got to get into this. So where do we even begin? What’s a lipid, what’s cholesterol? Let’s explain what these things mean, HDL-C.

Tom Dayspring: Sure, well a lipid is basically a molecule that is not soluble in water ([Fahy et al., 2005](https://www.ncbi.nlm.nih.gov/pubmed/15722563); [Fahy et al., 2009](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2674711/)). It might be soluble in certain organic solvents, but not in water. It’s a hydrophobic (i.e., nonpolar) compound (Figure 10).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-45.png)

**Figure 10. The polarity of lipids.**

Tom Dayspring: And oils and fats are what everybody thinks of as a lipid. Some cholesterol is in there. I never liked calling cholesterol a fat, but it’s a lipid. Fats to me are fatty acids and combinations of fatty acids or glycerides. So that’s what lipids are (Figure 11).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-46.png)

**Figure 11. Categories of lipid molecules.** Glycerolipids have a glycerol backbone. Eicosanoids are 20 carbon chain fatty acids. Sterols are sterane derivatives. Sphingolipids have a backbone of sphingoid bases and a set of aliphatic amino alcohols that includes sphingosine. Prenols consist of isoprene units (5 carbon units).

Tom Dayspring: Different lipids have different degrees of solubility. Some are extremely hydrophobic, because both ends in a molecule can’t be seen in water. Some lipids have one end is a little bit water-soluble, hydrophilic (i.e., polar), and the other one isn’t. That would be where cholesterol fits in, phospholipids fit in (these are also called amphipathic). So that’s what a lipid is.

Tom Dayspring: There are several types of lipids in your body, but the ones that those of us who live in a clinic lipidology world are focused on our cholesterol (strongly recommended reading: [Steinberg, 2004](https://www.ncbi.nlm.nih.gov/pubmed/15102877); [Steinberg, 2005a](https://www.ncbi.nlm.nih.gov/pubmed/15547293); [Steinberg, 2005b](https://www.ncbi.nlm.nih.gov/pubmed/15995167); [Steinberg, 2006a](https://www.ncbi.nlm.nih.gov/pubmed/16227628); [Steinberg, 2006b](https://www.ncbi.nlm.nih.gov/pubmed/16585781)) basically two types of cholesterol: cholesterol and cholesteryl ester (Figure 12). There are fatty acids, but fatty acids stick to a lot of things. Sticking is called esterification in the world of lipids.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-47.png)

**Figure 12. Cholesteryl ester.** Free (unesterified) cholesterol (amphiphilic) and cholesteryl ester (in this case having a saturated fatty acid) making it hydrophobic or lipophilic. The fatty acid, in this case, has 16 carbons and is palmitic acid. The entire molecule is called cholesteryl palmitate.

Tom Dayspring: So they combine to carbohydrates, cholesterol; a three-carbon sugar called glycerol is the most common thing they bind to (Figures 13 and 14). If you have one fatty acid on a glycerol, it’s a monoacylglycerol. If you have two, that’s a diacylglycerol. If you have three fatty acids stuck on your glycerol compound, that is called a triacylglycerol (Figure 14), which most people would call a triglyceride (Figures 13 and 15).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-48.png)

**Figure 13. Glycerolipids.** Gylcerolipids include molecules to which fatty acid acyl groups are esterified (attached) to a 3-carbon glycerol backbone. The graphic above shows triacylglycerols (triglycerides) that have 3 fatty acids esterified to glycerol, and phospholipids which have 2 fatty acid acyl groups and a head group containing a phosphorous group esterified to glycerol.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-49.png)

**Figure 14. Glycerides.** Glycerides can also be classified according to the number of fatty acid acyl groups they contain: mono (1), di (2), and tri (3). The acyl groups are esterified to a glycerol backbone. The fatty acids can be the same or different per glyceride. A triglyceride can have 3 of the same fatty acids, or two of one, and one of another, or three different fatty acids.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-50.png)

**Figure 15. Triglyceride (TG).** In this example of a TG, there are three different acyl groups esterified to the glycerol backbone. Note the three carbons of glycerol are labeled, using the stereo-specific numbering system as sn-1, sn-2 or sn-3. Specific lipases hydrolyze the fatty acid at specific sn locations.

Tom Dayspring: If you’re as old as me, you’re not used to hearing those terms, and you’re used to hearing triglycerides. But initially, they were just called glycerides. Glycerides would be the whole family of mono, diacyl, and triacylglycerides. It’s basically the way in which the human body transports fatty acids, or stores them. Transports them in the plasma or stores them in various tissues, in case you need a fatty acid for a certain purpose. Be it energy or a structural purpose, then the fatty acids would disconnect from its glycerol backbone: that would be called de-esterification (Figure 16). That fatty acid could be used to whatever the cell wanted to do with that fatty acid. So if the cell didn’t need it, it could store it ’til when it did need it, as a glyceride.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-51.png)

**Figure 16. De-esterification.** Hydrolysis of fatty acids from TG creates diacylglycerols, which are labeled according to which carbon the de-esterification occurs at.

**[1:00:00]**

Tom Dayspring: Those are your basic definitions, but the one glyceride that is of incredible importance, it may be in the future even one we’re going to be looking at most seriously, and the one that nobody ever looks at or even brings into the discussion nowadays, are our phospholipids.

Tom Dayspring: Phospholipids are simply glycerol compounds, so you’ve got your three carbon, alcohol sugar there, and there are two fatty acids attached to it (Figures 13 and 17). There’s a lot of fatty acids in the makeup of every phospholipid. You might have the same two fatty acids, different fatty acids. Fatty acids come in different lengths, different types of double bonds. Then they got a head group, which has usually got a phosphorous moiety in it.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-52.png)

**Figure 17. Glycerophospholipids.** Graphic of a typical phospholipid – which contains a phosphorus containing head group and two fatty acids esterified to glycerol. The head group can be quite varied.

Tom Dayspring: Phospholipids are kind of cool, because part of it is water soluble, part of it is hydrophobic, doesn’t like water. They’re called amphiphiles, amphipathic is the name. That allows them to sit in certain positions in our body where, their hydrophobic lipid tails, the fatty acids, can exist in a lipid-rich environment inside the cell, inside a core of a lipoprotein, which is all hydrophobic lipids. But its hydrophilic surface can interact with plasma.

Tom Dayspring: So where do phospholipids exist? On the surface of our lipid transportation vehicles, lipoproteins, or on our cell membrane. Every cell membrane in your body is phospholipids.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-53.png)

**Figure 18. Cell membrane lipid bilayer.** In a bilayer cell membrane, the hydrophilic (polar) surfaces of the head group of the phospholipid and the –OH moiety of free cholesterol align to interact with plasma, whereas the nonpolar surfaces point to the core of the lipoprotein.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-54.png)

**Figure 19. Lipoprotein surface and core.** In the surface unilayer of lipids of a lipoprotein, the hydrophilic (polar) surfaces of the head group of the phospholipid and the –OH moiety of free cholesterol align to interact with plasma, whereas the nonpolar surfaces point to the core of the cell.

Tom Dayspring: What nobody seems to know, is most of your phospholipids are made in the liver or they’re made in the small intestine. The intestine absorbs fatty acids, repackages them into glycerides: phospholipids and triglycerides, and then they become part of lipoproteins that enter your lymphatics from the gut, in the lymph (Figure 20). Or your liver gets fatty acids, and it makes phospholipids and your liver makes lipoproteins, and excretes them.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-55.png)

**Figure 20. Anatomy (cross section) of a lipoprotein.** Unilayer of surface free (unesterified) sterols (mostly cholesterol but also unesterified phytosterols) and phospholipids. Core of hydrophobic triglycerides, diglycerides, monoglycerides and cholesteryl ester (or phytosterol esters). Structural surface apoprotein B100 (hepatic produced) or B48 (enterocyte produced) and apoA-I (hepatic or enterocyte produced). ApoB is nontransferable. The volume of a lipoprotein core is a third power of the radius. HDLs contain from 1-5 copies of apoA-I. Chylomicrons can traffic several copies of apoA-I, which are rapidly lost during lipolysis. Ultra-small LDLs can also carry apoA-I.

Tom Dayspring: So few people know that [a gigantic function of lipoproteins is to deliver phospholipids]. Everybody talks of lipoproteins as if they’re delivering cholesterol all over the place, meaning that’s what we have lipoproteins for. That’s probably the last reason we have lipoproteins, because every cell in your body makes every cholesterol molecule it needs to do what it has to do, with a few rare exceptions ([Dietschy et al., 1993](https://www.ncbi.nlm.nih.gov/pubmed/8245716)). So, for example, if I’m a nasal cell, I don’t need some lipoprotein to come and deliver cholesterol to my cell, because I need cholesterol in my nasal cell membranes. That [nasal cell, or any] cell will make cholesterol.

Tom Dayspring: Every cell has the genetic power, the protein, and the enzymology to make cholesterol to its heart’s content ([Ačimovič and Rozman, 2013](https://www.ncbi.nlm.nih.gov/pubmed/23558541)). The tragedy is, when we eat, most of our cells make way too damn much cholesterol, which becomes then not an absolutely life-sustaining molecule needed in your cell membranes, but a cellular toxic molecule, because it crystallizes and kills those cells ([Mulay and Anders, 2016](https://www.ncbi.nlm.nih.gov/pubmed/27332905)).

Tom Dayspring: So evolution has given our cells incredible powers to evict ([Ory, 2004](https://www.ncbi.nlm.nih.gov/pubmed/15459087)), efflux out cholesterol, so they don’t suffer cholesterol toxicity in those cells. That will be certainly something we’ll get into. How do cells get rid of all this cholesterol, because of what we’re eating and are making too much of it. It’s not that lipoproteins are delivering too much cholesterol to most of these cells, although they can in certain areas. Some people do get cholesterol built up in their skin, such as xanthomas.

Peter Attia: I want to just interject for a moment to go back and clarify something for the listeners. So we talk a lot about fats, but many people are familiar with the term saturated fats, monounsaturated fats, polyunsaturated fats. You touched on it very briefly, but just so that they understand the broader context, a saturated fat means a fatty acid, hydrocarbon that has no double bonds in it.

Peter Attia: A monounsaturated fat, has a single double bond in it. And a polyunsaturated fat, has two or more. Of course, depending on the position of the first double bond with respect to its carboxyl group, that’s where we get into these omegas. But the point here is, when people talk about saturated, monounsaturated, and polyunsaturated fat, they’re referring to the positions of these double bonds within these long hydrocarbons that also can be a variable length ([Rustan and Drevon, 2005](https://onlinelibrary.wiley.com/doi/pdf/10.1038/npg.els.0003894)).

Peter Attia: So for example, a saturated fat can be very short, six, seven, eight carbons in length. Or it can be much longer. And each one of them has its own name. The same is true with the monos. Once you get into the mono’s and poly’s the nomenclature starts to get complicated, because you’re describing both the position of the double bonds and the length of the hydrocarbon (Figures 21 and 22).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-56.png)

**Figure 21. Fatty acids.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-57.png)

**Figure 22. Fatty acids (continued).**

Peter Attia: Now these things have all of these complex properties, but in many ways, it still pales in comparison to the complexity of the cholesterol system, because those fatty acids can also, even though they are not soluble in water, and therefore they can’t float around willy-nilly, they have the luxury of being transported on albumin right?

Tom Dayspring: They do ([Richieri and Kleinfeld, 1995](https://www.ncbi.nlm.nih.gov/pubmed/7751810)).

Peter Attia: Which is another protein in the plasma, that can hide this hydrophobic part of them in an ability to transport them through. But yet, why can’t we transport cholesterol, which you’ve just explained is not soluble in water, it’s hydrophobic. Why can’t we transport cholesterol or phospholipids in albumin? Something that’s so ubiquitous and benign.

Tom Dayspring: Well you can (Figure 23) ([Hellerstein and Turner, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24362356)). Cholesterol can attach to albumin. Before I answer your current question, what I was explaining before, is the lipoproteins, everybody thinks their purpose is to deliver cholesterol to tissues. That’s their last purpose. They don’t do that. The real purpose of our lipoprotein, our lipid transportation system, is to transport energy to tissues that need them. That would be triglycerides. The fatty acids, which our cells oxidize, create ATP. So they are brought to tissues that are very good at extracting triglycerides from lipoproteins, muscle cells. But if your muscles, because you’re not using your muscles, don’t need any energy today, those triglycerides will be dumped as a fatty acid into an adipocyte to be stored as a fatty acid in the form of a TG.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-58.png)

**Figure 23. A schematic of plasma cholesterol trafficking: within erythrocytes, albumin, and lipoproteins.** The cholesterol can be acquired by lipidation via membrane transporters or free diffusion from any cell. Lipoproteins can swap neutral lipids (TG for TG) using cholesteryl ester transfer protein (CETP). LDLs and HDLs can traffic cholesterol to hepatocytes and enterocytes, HDLs can traffic cholesterol to steroidogenic tissue and adipocytes. LDLs return cholesterol to the liver or enterocytes. An HDL returning cholesterol to the liver (where it can be delipidated or internalized by holoparticle receptors) is called direct reverse cholesterol transport (RCT) and an LDL returning cholesterol to the liver (via LDL receptor-mediated clearance or free diffusion ) is called indirect RCT. The process of trafficking cholesterol to the intestine (for excretion into gut lumen) is called transintestinal cholesterol efflux (TICE). Note HDLs can be lipidated at any cell via ABCA1 or G5 transporters (the majority of lipidation occurs at liver or intestine).

Tom Dayspring: What nobody talks about, what else are the lipoproteins delivering, that cells cannot be a cell without? Their phospholipids. What is the surface of every lipoprotein or cell (Figures 18 and 19)? Phospholipids. Where do the phospholipids come out of? Lipoproteins, as surface passengers of lipoproteins, produced in the intestine or the liver.

Tom Dayspring: So what are the biggest lipoproteins, because they would have the most gigantic surface area? Chylomicrons coming out of your gut and very-low-density particles (VLDLs) coming out of our liver (Figures 24 and 25). So we all talk about, “Oh they’re delivering cholesterol. They’re delivering maybe triglycerides,” because they’re very TG-rich. But they’re delivering phospholipids.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-59.png)

**Figure 24. Separation of the apolipoprotein B and apolipoprotein A-I particles by buoyancy (density) using the ultracentrifuge.**

**Chylomicrons** (intestinally-produced) containing one molecule of apolipoproteinB48 plus several other (multiple copies of) apoproteins: apoA-I, apoC-II, apoA-V, apoE, etc.

**Very low-density lipoproteins (VLDL**) are hepatic-produced and carry one nontransferable molecule of apolipoprotein B100 plus several other (multiple copies of) apoproteins: apoC-II, apoA-V, apoE, etc.

**Intermediate-density lipoproteins (IDL)** may be hepatic-produced or be the lipolytic remnant of a VLDL. They contain one nontransferable molecule of apolipoprotein B100 and also apolipoprotein E

**Low-density lipoproteins (LDL)** which contain one nontransferable molecule of apolipoprotein B100 may be hepatic-produced or is a lipolytic remnant of an IDL. A small percentage can carry other apolipoproteins like E, C-III, A-Ia

**High-density lipoproteins (HDL)** are a mixture of small particles ranging from unlipidated apoprotein A-I to discoid to spherical particles carrying varying degrees of phospholipids, free and unesterified cholesterol. HDLs can carry from 1 to 5 molecules of apoA-I. Also present on HDLs may be apoA-II as well as a multitude of other transient trafficked apoproteins. The functionality of specific HDLs are related to their proteome. The largest HDL of which few exist is designated as HDL-1, with HDL-2 family being intermediate in size and HDL-3 the smallest.

**Lipoprotein(a)** is an LDL-like lipoprotein that also contains (bound to apoB100) a single molecule of apoprotein(a).

Note that size and buoyancy of the particle are related to its lipid content: Intestinally produced chylomicrons carry the largest lipid load, with HDLs carrying the least. With each class of lipoproteins are heterogeneous subclasses that vary in size, density, and lipid composition. Under physiologic conditions, the largest lipoproteins are characteristically TG-rich whereas the small (LDLs and HDLs) are TG-poor and cholesterol-rich. Small particles are always denser than larger particles, hence using the descriptive term *small, dense* is a redundancy.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-60.png)

**Figure 25. Very low-Density lipoproteins are apoB-100, typically TG-rich particles produced and secreted by the liver.** In this graphic, their apolipoproteins are listed, but not shown. Because of the size of the particle, the surface area is large and VLDLs are a major carrier of phospholipids. Under physiologic conditions, VLDLs characteristically contain a 5-to-1 ratio of TG to cholesterol and VLDL-C, and hence often estimated as TG/5.

Peter Attia: Just to clarify again. The spherical lipoprotein has an inside?

Tom Dayspring: Yep. That is called the particle core (Figure 20).

Peter Attia: Which carries the cholesteryl ester and the triglyceride ([Shen et al., 1977](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC430495/)), but the phospholipid isn’t carried inside that central cargo. It’s actually embedded within the surface of the lipoprotein. Therefore, the chylomicron being the largest followed by the VLDL, the very low-density lipoprotein, the larger the surface area of these things, the greater their capacity to carry phospholipids since the phospholipid is carried in the wall.

Tom Dayspring: Correct. When these gigantic triglyceride-rich particles go to your muscles or adipocytes to deliver their triglyceride in their core, very hydrophobic, in that core is a special type of cholesterol that has a fatty acid to it, cholesteryl ester (Figures 12 and 20), incredibly hydrophobic also.

Tom Dayspring: Those two tissues that I talked about, muscles and adipose tissue, have very powerful triglyceride dissolving enzyme called lipoprotein lipase, which starts hydrolyzing the core triglycerides ([Li et al., 2014](https://www.ncbi.nlm.nih.gov/pubmed/25463094)). Now, these big dump trucks full of triglycerides like that, they start to shrink when the triglycerides undergo hydrolysis (Figure 26), meaning de-esterification. The particle, as it shrinks, that’s called lipolysis, meaning removal of a lipid from a lipoprotein.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-61.png)

**Figure 26. Normal VLDL lipolysis.** Schemata of hepatic secretion of VLDL and lipolysis (hydrolysis of core TG, and surface phospholipids. Under conditions of TG <130 mg/dL ~40% of the apoB-containing lipoproteins excreted by the liver are LDLs. Thus not all LDLs result from lipolysis of VLDLs. ApoC-II, of which VLDLs carry several copies, is the main ligand for lipoprotein lipase (LPL) expressed in myocytes or adipocytes. ApoA-V helps anchor TG-rich VLDLs to areas where LPL is expressed. ApoE (several copies of which are on VLDLs and IDLs) is a ligand for the LDL receptor or LDL receptor-related protein which clear VLDL, IDLs, and LDLs from plasma. LDL-P is a measurement of the number of LDLs, irrespective of size (in nmols) that exist per liter of serum. Also, note that both IDLs and LDLs can be directly produced and secreted by the liver and do not necessarily have to be lipolytic remnants of VLDLs.

Tom Dayspring: So you can imagine these big fat balloons full of triglycerides. If you could suck water out of a balloon, it becomes a smaller balloon, and it would get wrinkles on it. Well, lipoproteins don’t develop surface wrinkles, they just evict their surface phospholipids, which can immediately attach to a contiguous cell where the decrease in diameter of the lipoprotein has occurred. Or they jump on a protein that evolution has given us called phospholipid transfer protein ([Masson et al., 2009](https://www.ncbi.nlm.nih.gov/pubmed/19023137)), which then takes all those phospholipids and brings them to cells that say, “Hey, I need phospholipids.” Or joins the surface apoprotein that is not made in the liver or intestine, but grows itself, matures itself in the plasma high-density lipoproteins.

Tom Dayspring: You couldn’t change a baby HDL’s unlipidated apoA-I (*baby* meaning small or immature), which is the structural protein of an HDL into a big fat mature large HDL if you weren’t supplying it with what?

Tom Dayspring: Phospholipids. Where would an HDL get phospholipids ([Ji et al., 2014](https://www.ncbi.nlm.nih.gov/pubmed/25060793))? As these big triglyceride-enriched particles shrink and they extrude them (phospholipids), phospholipid transfer protein says, “Here little baby HDL, here are your phospholipids.” And they can mature into it. So it’s just an incredible system.

Peter Attia: I love the idea. I love anthropomorphizing these things. Little baby HDL. That’s good.

Tom Dayspring: It helps. That all being said, I want everybody to understand the importance of phospholipids because we don’t measure them, because it’s complex to measure them. There are so many different types of phospholipids based on the exact fatty acid makeup. It (their structure) depends on the fatty acid (Figure 17). Remember glycerol has three positions. They’re called stereospecific number one (sn-1), number two (sn-2), and number three (sn-3). Everything depends. The lipases attack, various fatty acids, and different positions. It’s really complicated. The phospholipids affect a lot of cell membrane functioning (signaling).

**[1:10:00]**

Tom Dayspring: Since phospholipids are making up not only a surface of lipoproteins, basically because they’re water-soluble and it allows these dump trucks to float (i.e., be somewhat soluble) around in plasma. In the cell membrane, what Peter was just talking about, that fatty acid make up in the phospholipid has become so crucial. Because saturated fats are straight, they’re rugged, they don’t bend. So it gives some structure to a phospholipid. If your phospholipids do contain a lot of saturated, hey you’ve got a strong cell membrane there, that’s hard to get through.

Tom Dayspring: But the real reason cells function and interact with the rest of the cells of your body is, they signal each other. Signaling occurs, because something occurs at a certain area of the lipid cell membrane, that we’re going to call a lipid raft, which is a specialized collection of special phospholipids with a little bit of free cholesterol interspersed. The structural positioning that at phospholipid takes u, if you have several double bonds in that thing, if you’ve ever seen a 3-D view of a phospholipid that’s got several double bonds in it, it takes up an incredible amount of space. It’s two legs spread out, and you change the structure of the cell membrane. That structure of that area called the lipid raft, allows certain cellular proteins to locate there. Those are all our receptors that pull things into cells or extrude things out of cells (Figures 27 and 28).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-62.png)

**Figure 27. Membrane lipid spatial alignment.** Demonstrates the importance of the fatty acid legs of phospholipids and how that spatially affect lipid membranes.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-63.png)

**Figure 28. Membrane lipid spatial alignment (continued).** Demonstrates the importance of the fatty acid legs of phospholipids and how that spatially affect lipid membranes as well as affinities for specific lipases.

Peter Attia: The fluidity of the membrane is highly, highly dependent on the nature of the fatty acids in the phospholipid-

Tom Dayspring: The fluidity and the ability to shelter or let certain proteins be expressed in that area (Figure 29). If I’m an LDL receptor, or some immunoreceptor, there are certain areas of cell membrane I could never locate to, because the phospholipids wouldn’t allow it. But there are other areas, they say, “Welcome! Here’s where you’re supposed to be expressed.” And cells know that and they construct their lipid membranes, hopefully, if you have the right type of phospholipids and everything functions well.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-64.png)

**Figure 29. Lipid rafts and cell surface receptors.** Lipid rafts are specialized membrane areas, defined by the makeup of free cholesterol on the FA on specific phospholipids, that, depending on their makeup, are conducive or not conducive to protein expression (location).

Tom Dayspring: So, as we start to talk, and those who study and investigate membrane physiology, it’s one of the more advanced areas in lipidology ([Holthuis and Menon, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24899304)), but as we also are starting to understand some of the qualities beyond just measurements of various lipoproteins, their phospholipid makeup is going to be crucial.

Tom Dayspring: And as we talk about HDLs, we’re going to start throwing around the word HDL functionality. And a giant part of HDL functionality, what a specific HDL particle does in your body, what it might be capable of accomplishing or not accomplishing, is due to the fatty acid makeup of its phospholipids ([Birner-Gruenberger et al., 2014](https://www.ncbi.nlm.nih.gov/pubmed/25107698); [Rosales et al., 2016](https://www.ncbi.nlm.nih.gov/pubmed/27005803)).

Tom Dayspring: And one day I think we’re going to be analyzing the lipidome of various lipoproteins ([Brown and Hazen, 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4018580/)), and we’re going to have a lot more insight of what lipoproteins do or don’t do.

§

§

## Selected Links / Related Material

**Peter’s talk on longevity at MIT**: [Reverse-engineered approach to human longevity](https://vimeo.com/228845024) | Peter Attia (vimeo.com) [8:15]

**Valter Longo’s FMD**: [Fasting Mimicking Diet](https://prolonfmd.com/fasting-mimicking-diet/) | ProLon (prolonfmd.com) [13:00]

**Paterson fire department history**: [Paterson Fire](https://www.patersonfirehistory.com/) | (patersonfirehistory.com) [21:45]

**The Multiple Risk Factor Intervention Trial (MRFIT)**: [The Multiple Risk Factor Intervention Trial (MRFIT)—Importance Then and Now](https://www.ncbi.nlm.nih.gov/pubmed/18799447) (Stamler and Neaton, 2008) [44:30]

**The Framingham Heart Study**: [Framingham Heart Study](https://www.framinghamheartstudy.org/) | (framinghamheartstudy.org) [44:30]

**Case of elevated LDL-C and LDL-P on a low-carb diet**: [Lipidaholics Anonymous Case 291 Can losing weight worsen lipids?](https://www.dropbox.com/s/1fbzojwm4lytjss/Dayspring%20-%20Lipidaholics%20Case%20291%20-%20Can%20losing%20weight%20worsen%20lipids%3F.pdf?dl=0) | Tom Dayspring (PDF) [54:45]

**HDL emerging knowledge**: [High-density lipoproteins: emerging knowledge](https://www.ncbi.nlm.nih.gov/pubmed/17684448) (Dayspring, 2007) [56:30]

**HDL emerging knowledge**: [High-density lipoproteins: a consensus statement from the National Lipid Association](https://www.ncbi.nlm.nih.gov/pubmed/24079290) (Toth et al., 2013) [56:30]

**What is a lipid**: [Update of the LIPID MAPS comprehensive classification system for lipids](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2674711/) (Fahy et al., 2009) [57:30]

**What is a lipid**: [A comprehensive classification system for lipids](https://www.ncbi.nlm.nih.gov/pubmed/15722563) (Fahy et al., 2005) [57:30]

**Pathogenesis of atherosclerosis**:[Thematic review series: the pathogenesis of atherosclerosis. An interpretive history of the cholesterol controversy: part I](https://www.ncbi.nlm.nih.gov/pubmed/15102877) (Steinberg, 2004) [58:15]

**Pathogenesis of atherosclerosis**:[Thematic review series: the pathogenesis of atherosclerosis. An interpretive history of the cholesterol controversy: part II: the early evidence linking hypercholesterolemia to coronary disease in humans](https://www.ncbi.nlm.nih.gov/pubmed/15547293) (Steinberg, 2005a) [58:15]

**Pathogenesis of atherosclerosis**:[Thematic review series: the pathogenesis of atherosclerosis: an interpretive history of the cholesterol controversy, part III: mechanistically defining the role of hyperlipidemia](https://www.ncbi.nlm.nih.gov/pubmed/15995167) (Steinberg, 2005b) [58:15]

**Pathogenesis of atherosclerosis**:[The pathogenesis of atherosclerosis. An interpretive history of the cholesterol controversy, part IV: the 1984 coronary primary prevention trial ends it—almost](https://www.ncbi.nlm.nih.gov/pubmed/16227628) (Steinberg, 2006a) [58:15]

**Pathogenesis of atherosclerosis:** [Thematic review series: the pathogenesis of atherosclerosis. An interpretive history of the cholesterol controversy, part V: the discovery of the statins and the end of the controversy](https://www.ncbi.nlm.nih.gov/pubmed/16585781) (Steinberg, 2006b) [58:15]

**Every cell can make the cholesterol it needs**: [Role of liver in the maintenance of cholesterol and low density lipoprotein homeostasis in different animal species, including humans](https://www.ncbi.nlm.nih.gov/pubmed/8245716) (Dietschy et al., 1993) [1:02:15]

**Every cell makes the cholesterol it needs**: [Steroidal triterpenes of cholesterol synthesis](https://www.ncbi.nlm.nih.gov/pubmed/23558541) (Ačimovič and Rozman, 2013) [1:02:30]

**Cholesterol can crystalize and kill cells**: [Crystallopathies](https://www.ncbi.nlm.nih.gov/pubmed/27332905) (Mulay and Anders, 2016) [1:02:30]

**Cells have the power to evict**: [Nuclear receptor signaling in the control of cholesterol homeostasis: have the orphans found a home?](https://www.ncbi.nlm.nih.gov/pubmed/15459087) (Ory, 2004) [1:03:00]

**When people talk about saturated, monounsaturated, and polyunsaturated fat, they’re referring to the positions of these double bonds within these long hydrocarbons that also can be a variable length**: [Fatty Acids: Structures and Properties](https://onlinelibrary.wiley.com/doi/pdf/10.1038/npg.els.0003894) (Rustan and Drevon, 2005) [1:04:00]

**Fatty acid transport on albumin**: [Unbound free fatty acid levels in human serum](https://www.ncbi.nlm.nih.gov/pubmed/7751810) (Richieri and Kleinfeld, 1995) [1:05:00]

**Reverse cholesterol transport**: [Reverse cholesterol transport fluxes](https://www.ncbi.nlm.nih.gov/pubmed/24362356) (Hellerstein and Turner, 2014) [1:05:15]

**Particle core carries the cholesteryl ester and the triglyceride**: [Structure of human serum lipoproteins inferred from compositional analysis](https://www.ncbi.nlm.nih.gov/pubmed/265578) (Shen et al., 1977) [1:07:00]

**Lipoprotein lipase (LPL)**: [Lipoprotein lipase: from gene to atherosclerosis](https://www.ncbi.nlm.nih.gov/pubmed/25463094) (Li et al., 2014) [1:07:30]

**Phospholipid transfer protein (PLTP)**: [The role of plasma lipid transfer proteins in lipoprotein metabolism and atherogenesis](https://www.ncbi.nlm.nih.gov/pubmed/19023137) (Masson et al., 2009) [1:08:30]

**Where would an HDL get phospholipids**: [Impact of phospholipid transfer protein on nascent high-density lipoprotein formation and remodeling](https://www.ncbi.nlm.nih.gov/pubmed/25060793) (Ji et al., 2014) [1:08:45]

**Membrane physiology, one of the more advanced areas in lipidology**: [Lipid landscapes and pipelines in membrane homeostasis](https://www.ncbi.nlm.nih.gov/pubmed/24899304) (Holthuis and Menon, 2014) [1:12:00]

**HDL functionality**: [Understanding high-density lipoprotein function in disease: Recent advances in proteomics unravel the complexity of its composition and biology](https://www.ncbi.nlm.nih.gov/pubmed/25107698) (Birner-Gruenberger et al., 2014) [1:12:30]

**HDL functionality**: [Speciated High-Density Lipoprotein Biogenesis and Functionality](https://www.ncbi.nlm.nih.gov/pubmed/27005803) (Rosales et al., 2016) [1:12:30]

**Analyzing the lipidome**: [Seeking a Unique Lipid Signature Predicting Cardiovascular Disease Risk](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4018580/) (Brown and Hazen, 2014) [1:12:45]

§

§

## People Mentioned

- [Valter Longo](https://gero.usc.edu/faculty/longo/) (creator of the ProLon FMD) [13:00]
- [Nicole Vantress](https://www.linkedin.com/in/nicole-vantress-rd-cnsc-94554b42/) (Director of Health and Nutrition at Attia Medical, PC) [13:45]
- [Brad Dayspring](https://twitter.com/BDayspring?lang=en) (Tom’s Son) [14:30]
- [Alexander Hamilton](https://en.wikipedia.org/wiki/Alexander_Hamilton) [22:15]
- [Edward Moore](https://www.patersonfirehistory.com/the-supreme-sacrfice.html) (firefighter that died at the scene of a fire, Tom discovered) [25:15]
- [Sister Loretta Agnes](https://www.patersonfirehistory.com/sister-loretta.html) (honorary battalion chief, Paterson Fire Department) [27:00]
- [Mickey Mantle](https://en.wikipedia.org/wiki/Mickey_Mantle) (New York Yankees) [31:00]
- [Whitey Ford](https://en.wikipedia.org/wiki/Whitey_Ford) (New York Yankees) [31:00]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) (Edmonton Oilers) [36:00]
- [Mark Messier](https://en.wikipedia.org/wiki/Mark_Messier) (Edmonton Oilers) [36:00]
- [Grant Fuhr](https://en.wikipedia.org/wiki/Grant_Fuhr) (Edmonton Oilers) [37:00]
- [Jari Kurri](https://en.wikipedia.org/wiki/Jari_Kurri) (Edmonton Oilers) [37:00]
- [Glenn Anderson](https://en.wikipedia.org/wiki/Glenn_Anderson) (Edmonton Oilers) [37:00]
- [Paul Coffey](https://en.wikipedia.org/wiki/Paul_Coffey) (Edmonton Oilers) [37:00]
- [Mason Sones](https://en.wikipedia.org/wiki/F._Mason_Sones) (invented coronary angiography) [40:45]
- [Dan Rader](https://www.med.upenn.edu/apps/faculty/index.php/g5165284/p17778) (Tom’s friend and mentor) [45:15]
- [Tony Gotto](https://en.wikipedia.org/wiki/Antonio_Gotto) (Tom read his research early in his lipid education) [45:30]
- [Virgil Brown](https://medicine.emory.edu/endocrinology/brown-william-virgil.html) (Tom read his research early in his lipid education) [45:30]
- [Allan Sniderman](https://www.mcgill.ca/expmed/dr-allan-d-sniderman) (Tom read his research early in his lipid education) [45:30]
- [Ron Krauss](https://profiles.ucsf.edu/ronald.krauss) (Tom read his research early in his lipid education) [45:30]
- [E. James “Greenie” Greenwald](https://www.specialtyhealthwellness.com/who-we-are/wellness-team/): (sent Peter one of Tom’s NMR papers) [46:45]
- [Michael McIvor](https://www.healthgrades.com/physician/dr-michael-mcivor-xlrgb) (cardiologist using PowerPoint for lipids) [53:00]
- [Michael Davidson](https://www.lipid.org/about) (past NLA president) [53:45]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/10/tom-dayspring-300x300.jpg)

##### Thomas Dayspring, M.D., FACP, FNLA

Thomas Dayspring, MD, FACP, FNLA is the chief academic officer for True Health Diagnostics, LLC. He provides scientific leadership and direction for the company’s comprehensive educational programs. Dr. Dayspring is a fellow of both the American College of Physicians and the National Lipid Association. He is certified in internal medicine and clinical lipidology.

Before relocating to Virginia in 2012, Dr. Dayspring practiced medicine in New Jersey for 37 years. Over the last two decades, he has given over 4,000 domestic and international lectures, including over 600 CME programs on topics such as atherothrombosis, lipoprotein and vascular biology, biomarker testing, and women’s cardiovascular issues.

Dr Dayspring is an Associate Editor of the Journal of Clinical Lipidology. He has authored or co-authored numerous manuscripts published across leading journals such as the American Journal of Cardiology, the Journal of Clinical Lipidology, and several lipid-related book chapters. He was the recipient of the 2011 National Lipid Association President’s Award for services to clinical lipidology. [[truehealthdiag.com](https://truehealthdiag.com/leadership/thomas-dayspring/)]

Disclosures:

- Employed full time for last three years by True Health Diagnostics, LLC, which provides biomarker diagnostics and clinical services to clinicians, patients, and healthcare organizations
- 2017: small consulting project for Abbvie

Tom on Twitter: [@Drlipid](https://twitter.com/Drlipid)