# #377 ‒ Special episode: Understanding true happiness and the tools to cultivate a meaningful life—insights from past interviews with Arthur Brooks

**Source:** [https://peterattiamd.com/bestofbrooks/](https://peterattiamd.com/bestofbrooks/)

---

In this special episode of The Drive, Peter presents a curated “best of” conversation with bestselling author and previous guest Arthur Brooks, organized around four core themes: happiness itself, the forces that undermine it, the tools and practices that help cultivate it, and the courage required to live and love well. The episode brings together the most meaningful moments from two past interviews into a single, focused discussion that distills Brooks’ most insightful ideas and offers practical takeaways for building a life that’s both successful and deeply happy.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/bestofbrooks/the_Drive_public.png)

Play

#377 ‒ Special episode: Understanding true happiness and the tools to cultivate a meaningful life—insights from past interviews with Arthur Brooks

#377 ‒ Special episode: Understanding true happiness and the tools to cultivate a meaningful life—insights from past interviews with Arthur Brooks

1x15s30s

0:001:39:31

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Happiness vs. happy feelings, and how happiness and unhappiness can coexist [A: 2:15, V: 1:20];
- The six fundamental emotions [A: 5:30, V: 4:43];
- The three main “macronutrients” of happiness [A: 15:00, V: 14:18];
- Enjoyment: one of the three macronutrients of happiness [A: 22:45, V: 22:02];
- Satisfaction: one of the three macronutrients of happiness [A: 30:45, V: 29:55];
- Sense of purpose: one of the three macronutrients of happiness [A: 38:45, V: 37:53];
- Fame: one of the traps that hijack our happiness [A: 46:30, V: 45:39];
- Success addiction, workaholism, and their detriment to happiness [A: 49:15, V: 48:34];
- The reverse bucket list: one of Arthur’s tools and practices he recommends for moving past the traps that hijack our happiness [A: 59:15, V: 58:32];
- Metacognition: one of Arthur’s tools and practices he recommends for moving past the traps that hijack our happiness [A: 1:01:00, V: 1:00:08];
- Taking charge of your happiness: discipline, transcendent experiences, and other deliberate actions for “happier-ness” [A: 1:11:30, V: 1:10:36];
- Tracking happiness: the biomarkers and micronutrients behind the macronutrients of happiness [A: 1:22:45, V: 1:10:36];
- The value of minimizing the self and looking outward [A: 1:30:45, V: 1:29:48];
- How Arthur surprised himself with his ability to improve his happiness [A: 1:34:45, V: 1:33:57]; and
- More.

---

## Show Notes

\***Notes from intro**:

- This is a special, best of episode with Arthur Brooks
- Arthur is a Harvard professor, social scientist, columnist at *The Atlantic* and bestselling author
- Peter has sat down with Arthur twice in the past few years to talk about how to build a life that’s both successful and deeply happy
- We pulled the best moments from these two conversations ([episode #226](https://peterattiamd.com/arthurbrooks/) and [episode #280](https://peterattiamd.com/arthurbrooks2/)) into one focused episode built around 4 themes: happiness, what hijacks it, the tools and practices that help, and the courage to live and love well
  - Highlighting the most insightful and actionable takeaway steps from previous episodes
- Peter is really excited about this one because he’s actually recently gone back and started rereading one of Arthur’s books
- He’s come to realize in rereading it, that in just a span of a year and a half or two years, it’s so easy to forget some of the nuance
- While he rarely has the time to go back and listen to old podcasts, he loves having a mashup like this that actually brings some of the most important aspects from several podcasts into one

## Happiness vs. happy feelings, and how happiness and unhappiness can coexist [A: 2:15, V: 1:20]

- Peter congratulates Arthur on his new [book](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2) and adds, “*This is not your first, second or third rodeo, but I’m sure each time, it’s a little bit of a what’s the world going to think?*”
- Arthur thinks writing a book is like having a child, “*A book is something where as you bring it into the world you go through…*” [stages]
  - He remembers [Elisabeth Kübler-Ross](https://en.wikipedia.org/wiki/Elisabeth_K%C3%BCbler-Ross), the Swiss psychiatrist who wrote that famous [book](https://www.amazon.com/Death-Dying-Doctors-Nurses-Families/dp/1476775540/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1698246510&sr=8-1) about death and dying
  - You have to go through five stages
  - Most of that research has been questioned since then, but it’s pretty interesting
- When writing a book, you go through bargaining and denial and rage, and finally there’s acceptance but you’re still nervous for sure

**What’s the difference between happiness and happy feelings? Are they the same thing?**

- They’re not the same thing, and this is a really important misconception
- Most of us live in the era of feelings
- Arthur adds, “*If you’d talk to my parents or, god knows, my grandparents about feelings, they would scratch their head. What are you talking about?*”
- You’re talking about your emotions all the time, [ephemera](https://en.wikipedia.org/wiki/Ephemera)
- Feelings seems so counterproductive

> “*Our grandparents were right. Feelings are not happiness, any more than the smell of the turkey is your Thanksgiving dinner.*”‒ Arthur Brooks

***Feelings are evidence of happiness, and that’s incredibly good news***

**A lot of people think that happiness is a feeling. It’s quite incorrect.**

- There are many better technical definitions of happiness, but they produce a lot of feelings
  - They’re associated with a lot of emotions, which is [limbic system](https://en.wikipedia.org/wiki/Limbic_system) activity (a part of the brain)
  - A 40-million year evolutionary process that developed the limbic system to create emotions
  - That signals information and is what emotions come from
- If you mistake these feelings for the underlying phenomenon of happiness, you’re going to be chasing it all over the place
  - You’ll be chasing ghosts: how I slept last night, what I ate for breakfast, if my spouse yelled at me this morning
- If you mistake the *feelings* of happiness for the underlying *phenomenon* of happiness, you wind up being managed as opposed to having any prayer of managing your own happiness

***That’s the first thing to keep in mind: it’s not feelings***

Peter reflects, “*It’s hard to differentiate though… you have to remind yourself when you’re in the throes of what I just referred to as negatively valenced feelings, that this is not a statement of my overall state of happiness.*”

**What’s the relationship between unhappiness and happiness? Are they polar images? How do they coexist?**

- If you go back to the ancient philosophers, there was the idea that happiness and unhappiness exists on a spectrum
  - So unhappiness would be the lack of happiness
- We know a lot better now given the explosion of neuroscience and the way that emotions are produced that in fact, you can be happy and unhappy
  - Or have happy and unhappy feelings in parallel
- For example, the average person spends about 40% of their time with predominantly **positive feelings**
  - It sits in a neutral idle of positivity
  - Most people do, not everybody
- About 16 or 17% of the time, the average person has predominantly **negative feelings**, something is going on
  - That’s more intense
  - And part of the reason is because negative emotions get your attention and they’re supposed to
  - Evolution favors negative emotions
  - Positive emotions are nice to have, but negative emotions, pay attention because that could cost you your life

## The six fundamental emotions [A: 5:30, V: 4:43]

**What are some of the most powerful negative emotions that would drive action?**

*If you think about his evolutionarily, and not even going back to millions of years ago but just going back hundreds of thousands of years ago to the origin of our species as homo sapiens*

- There are basically **6 fundamental emotions** or basic emotions
  - These are the building blocks of all emotional life that are produced by the limbic system of the brain
  - 4 negative and 2 positive
- The **4 negative emotions** are sadness, anger, fear and disgust
  - All 4 of those have a very strong evolutionary basis

**Fear and anger** have to do with threat

- They involve the [amygdala](https://en.wikipedia.org/wiki/Amygdala) of the brain
- When a car is about to run you over and you’re a pedestrian in a crosswalk, that crosses your visual cortex and is recorded in the occipital lobe of your brain as an enormous predator
  - That signals to your amygdala to send the signal through the hypothalamus of your brain to your pituitary glands (which signals your adrenal glands above your kidneys) to spit out stress hormones
  - That happens in 74 milliseconds
  - By that time, you’re sweating, your heart is pumping, you’ve jumped out of the way and you’ve flipped off the driver, a combination of fear and anger in response to the enormous predator
  - Three seconds later, your prefrontal cortex catches up and you say, “*I shouldn’t have flipped him off. That’s not my values*,” or whatever it happens to be
- So that’s your limbic system keeping you alive (that’s fear and anger)

**Disgust** involves the [insular cortex](https://en.wikipedia.org/wiki/Insular_cortex) of the brain, also part of the limbic system

- That’s when you pull something out of the back of your fridge you forgot about a few weeks ago, and you hold it and you’re like, “*Oh.*”
  - That signals don’t eat it
  - And so anything that might carry a pathogen signals that basic negative emotion of disgust to you
- Now, it can be misattributed to people, and that’s what demagogic politicians always do
  - That’s what the media does to us
  - It tries to reprogram the insula of the limbic system of the brain so that when somebody disagrees with you politically, you look at them like a cockroach
  - That’s what demagogic leaders and dictators have done for time immemorial so that people will undertake barbaric acts against people in their own countries, at least of war, etc.

Last but not least is **sadness**, and sadness has also evolved

- Sadness is what you feel largely in the [dorsal anterior cingulate cortex](https://en.wikipedia.org/wiki/Anterior_cingulate_cortex) of the brain (another part of the limbic system)

**⇒** That’s mental pain usually when you’re either socially excluded or you’re separated from a loved one

- Now that’s something that’s evolved because you don’t want to be separated from your tribe
  - You don’t want to walk the frozen tundra and die alone

But what happens, for example, in **grief**?

**⇒** Grief is unremediated sadness

- And the reason is because your brain is saying make this separation go away, and you can’t because the other person is permanently gone
- And so the grief is just this pulsating activity in the dorsal anterior cingulate cortex of the brain saying “*I must be reunited with that person but I can’t be.*”
- In many cases it takes a lot of time for the dorsal anterior cingulate cortex to stop registering that sadness, that pain

Peter adds, “*The sadness we feel when a person dies, which would be the ultimate form of separation, is a more extreme version of, say, a social isolation that you might feel, like what a kid feels if they go to sit at the cafeteria table and all the other kids get up and walk away.”*

**There are interesting studies that look at how grief registers in the brain**

- The brain is thrifty and the neuroscience of this is super interesting
- When you stub your toe, there’s actually 2 processes going
  - There’s sensory pain and affective pain
  - 1 – Sensory pain means you can feel it in the nerve endings and it’s very unpleasant
  - 2 – Affective pain is I hate this
  - And you feel both in physical pain
- The affective component involves the same part of the brain, the dorsal anterior cingulate cortex, when you have something that emotionally bothers you, when you’re being excluded
- We know that because there’s these interesting [studies](https://pubmed.ncbi.nlm.nih.gov/14551436/) in an fMRI machine, they’re looking at the part of the brain that’s illuminated
  - They’re being subjected to being rejected by somebody else, and they can see the part of the brain that’s actually illuminated

**Does the brain treat all pain the same?**

- Peter loves going into **cold plunges** (he does it almost every day), and it’s insanely uncomfortable
- He adds, “*There’s not a day that I step into that 42-degree ice bath with jets shooting water around me that I’m like, ‘This doesn’t hurt,’ but it doesn’t come with the ‘I hate this’ because I’m choosing to do it and I think there’s value in it.*”

*Does the brain treat that differently? How would we think of that as an emotion?*

- This is a controlled aversive emotion under your own power
- Another example is if you go to a **haunted house on Halloween** and get scared
  - You’re controlling the fear
- If you’re on a really radical **amusement park ride**, it’s the same thing
- You’re subjecting yourself to a little bit of the stress hormones and the experience of the aversive emotion, but since it’s under your own control, you actually use it in a way that you enjoy
- For example, people who do **extreme sports**, this is the same thing that they do
  - They like to feel a little bit in danger
  - One of Arthur’s kids is somebody who likes this ‒ he likes to expose himself to things that actually hurt, as long as he’s under control

**Is there any evidence that other species do this?**

- No
- This is a uniquely human phenomenon
- For example, there’s also no evidence that you can train any other species to appreciate spicy food, to ingest [capsaicin](https://en.wikipedia.org/wiki/Capsaicin)
- This is a really higher order phenomenon where we have aversive emotions
- Other animals have aversive emotions, but we actually can dominate them through a process called [metacognition](https://en.wikipedia.org/wiki/Metacognition) where we experience the emotions not just in the limbic system of the brain but in the prefrontal cortex
  - This is the human difference is where this comes around
- For example, if the dog wants the cookie, it eats the cookie
  - Dogs are limbic creatures

**Limbic reaction versus making it metacognitive**

- Little kids are limbic, and when Arthur’s kids were little, they’d be screaming over something, there’s a piece of rice on their chair (whatever thing that bums them out), and you’re like, “*Use your words.*”
- What you’re telling them to do is to experience the emotion in the prefrontal cortex of the brain where they can decide how to react
- They can think about what their own emotions are
  - And when you’re doing that, then you can get in the cold plunge and say, “*It hurts so good*.”
  - That’s what metacognition brings to you
- Also, with metacognition you can say something like, “*I’m really sad about this. What am I learning?*”

***That’s how you can be a far more evolved human being by becoming more and more metacognitive, using the techniques for doing so, which is a lot about what Arthur’s writing about these days***

**What are the 2 positive emotions?**

- While pretty much all neuroscientist agree on the 4 negative emotions, they don’t all agree on the 2 positive
- The 2 that pretty much everybody agrees on are joy and interest
- Some people believe that surprise is a positive basic emotion

**Joy** is obvious ‒ ordinarily, it’s when you’re reunited with somebody that you love or something good happens pursuant to struggle

- The joy you get after you work really hard for something and you get it, that’s a basic positive emotion
- It’s an evolved reward so that you work hard to find some berries on a bush and you get your caloric needs met for the day
- That’s actually stimulating a part of the brain called the [ventral striatum](https://en.wikipedia.org/wiki/Striatum#Structure), which is your reward system, and, boom: that feels good, I want to do it again, do it again

**Interest** is different: interest is you get intense pleasure

- For example, people are listening to *The Drive* (which Arthur does)
  - Why? Because he learns something from it
  - Why does he care? It’s not like it’s going to dramatically change his salary trajectory or his professional success if he does or doesn’t listen to the show
  - He wants to learn because learning is intensely pleasurable
- That’s really a fascinating phenomenon because that’s how people evolve and make progress, and it makes sense that that would be an evolutionary phenomenon
  - We would favor learning so that people can get ahead and feed themselves and find new sources of food and find new mates and all the things that they do
- And the way that that’s adapted to the current environment is they listen to this show
- It seems to Peter that both joy and interest could be found in creatures other than us
- Learning would be a testable hypothesis, presumably with a maze or something like that
  - Whether the learning is positively valenced
  - You can teach a worm things, we just don’t know whether it’s a positive balanced experience because they don’t have the kind of brain that will give you emotions as we understand them
- Peter wonders if optogenetics would provide insight into that one day when you could get cellular level resolution of different parts of the brain
  - He’s thinking about [Karl Deisseroth’s](https://profiles.stanford.edu/karl-deisseroth) work [discussed in [episode #191](https://peterattiamd.com/karldeisseroth/)]

**We know that dogs have rudimentary emotions**

- They can mimic human emotions really well
- But it’s almost certainly a limbic phenomenon that looks metacognitive more than anything else
- And one of the things that we do is we selectively breed dogs so that their emotional state more clearly mimics our own
  - We like that
  - They make better companions
  - They do something they’re not supposed to do and they look guilty
  - They don’t feel guilty; that’s certainly an illusion
- Peter has a new puppy and can really relate to this
- There are certain ways that they are quite similar to us
  - For example, there’s a lot of research that suggests that they have serotonin balance issues, and if you give a dog a [selective serotonin re-uptake inhibitor (SSRI)](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor), it will actually have some of the same effects it can have on people
  - You can give your dog Prozac and your dog will be less depressed or at least have fewer depressive symptoms in some cases
  - So there are ways that they are similar to us for sure

## The three main “macronutrients” of happiness [A: 15:00, V: 14:18]

**Define happiness**

- Arthur teaches a class at the Harvard Business School called *Leadership and Happiness in HBS*
  - It explains what happiness is and how you get it
- By the time his graduate students reach him, a lot of them are realizing that the world’s promises are empty

> “*The money, power, pleasure, and fame that are supposed to bring you undying happiness are false promises.”* ‒ Arthur Brooks

- Money, power, pleasure, and fame can be instrumental to getting what you want, but they can’t intrinsically give you the satisfaction you desire
- There is a competitive system to get into elective classes, and this one fills in 9 seconds
  - There’s hundreds of people on the waiting list for this class

On the first day he asks students “*What is happiness?*”

- They say many things‒ “*It’s that feeling I get on Thanksgiving*”
  - Wrong. Happiness is not a feeling any more than your Thanksgiving dinner is the smell of the turkey
  - The feeling of happiness is evidence of happiness
- Happiness is measured in all sorts of ways, both complicated and simple

**⇒** One thing we know of people who are really happy, they have a lot of happy feelings

- They have a lot of satisfaction and contentment with their lives
- They’re getting abundance and balance across 3 dimensions
- If he asked, “*Hey, Peter, what is the Thanksgiving dinner?*” Peter would say “*Well, it’s carbohydrates, proteins, and fat.*”
  - These are the 3 macronutrients of all food
- Forget lifespan, let’s talk health span and happiness span

> “*Let’s get our literal macronutrients in order for health span and let’s get our happiness span in order with the macronutrients of happiness.*”‒ Arthur Brooks

The 3 macronutrients of happiness are:

- 1 –enjoyment
- 2 –satisfaction
- 3 –purpose

***You need these 3 things in balance and abundance to be a happy person***

**More about the 3 macronutrients of happiness**

- This is different from unhappiness
  - Happiness and unhappiness are not opposites, they’re different phenomena
- So we’re just talking about happiness here
- 1 – To be a truly happy person, you need to **enjoy** your life
  - And that requires not pleasure, “*It’s pleasure plus elevation*”
  - It’s pleasure plus metacognition
  - Thanksgiving dinner fills your belly and tastes good, that’s pleasure
  - But the experience that you have of consuming the Thanksgiving dinner with other people and having a memory, that can last forever, that’s enjoyment
- 2 – **Satisfaction** is super fleeting and troublesome
  - As Mick Jagger says, “*I can’t get no satisfaction*”
  - The truth is you can’t keep satisfaction
  - Arthur has participated in the literature on the problem with satisfaction
  - “*It’s the joy and reward for a job well done and a goal met. That elation from actually meeting a goal*.”
- 3 – **Purpose**, “*Is meaning in life*”
  - He talks a lot about the coherence, the significance, the direction, the meaning of meaning
  - And it gets back to a lot of the great philosophy, but we can also measure it

Arthur has a few diagnostic questions that he asks for clients who come to him who lack purpose in their life

- Why were you born?
- And for what are you willing to die?

***If you can’t answer one or both of those questions, you have a serious meaning problem***

- We’ve got to dig in to solve that particular problem

**Let’s now talk about these 3 components of happiness**

- Arthur wrote about this in [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
- Happiness is NOT a feeling (we’ve established that)
- Feelings are evidence of happiness

**Indirect ways to figure out how happy someone is**

- Arthur could ask your wife, “*How happy is Peter?*” when Peter’s not there and he would probably get some very accurate information
- There’s some tests, they’re not very good, but you could answer a series of targeted questions when you’re under fMRI
- But really the best way to do it, the most cost-effective and efficient way to do that is for you to anonymously answer a bunch of questions that are like this
  - Imagine all the people you know were the happiest person you’ve ever met, really happy, is 10, and the most miserable SOB you’ve ever met is a 1
  - All things considered at this period of your life, not this moment, this period of your life, all things considered, thinking of those people, what’s your number?
    - That turns out to be incredibly accurate
  - You’ve got to have a large sample because some people answer it in a wonky way
  - And it has to be anonymous because if you answer this in front of your wife, you’ll probably lie
    - People don’t tell the truth in front of their spouses necessarily, in front of their friends, because they give answers that people want to hear

**Based on these data, you find that the happiest people, they have three macronutrients in balance and abundance**

- Peter asks, “*Are those responses* [*normally distributed*](https://en.wikipedia.org/wiki/Normal_distribution)*?*”
  - Yes they are, but the mean is not 5, it’s more like 7.5
  - There’s a bias toward the top part of the scale
  - Normally happy is about 7-8
- Most people over the course of their adult lives (early 20s to early 50s), they’re between 7-9
- Most of the executives that Arthur works with one-on-one who are 3’s, they’re depressed
  - They’re actually suffering from clinical issues
  - They’re behind the line of scrimmage
- There’s nobody who’s like, “*Yeah, I’m pretty normal. I’m probably at the 40th percentile. That probably makes me a three and a half*.”
- 40th percentile is probably a 5
  - They would like to be better, and they feel like they’re not as good as they should be
  - Despite the fact that in the scale that looks like the middle of the scale, but it’s not the middle
- The people who are in the upper end (8-9) and like Arthur’s wife (9.5), they tend to be really healthy, and healthy means they have balance and abundance across what Arthur often refers to as the “happiness macronutrients”
  - It’s very easy in this audience because everybody knows it’s protein, carbohydrates, and fat, and the best diets are those that have all of them in balance and abundance
    - You have to get your macros
    - You’re not going to have 100% protein

***The three happiness macronutrients are i) enjoyment, ii) satisfaction, and iii) meaning***

- By the way, none of those is straightforward any more than protein, carbohydrates, and fat is straightforward

> “*You have to have strategies to understand why they’re so hard to attain and what you need to do ‒ exercises to make sure that you can be better and more skillful at attaining each one***.**”‒ Arthur Brooks

## Enjoyment: one of the three macronutrients of happiness [A: 22:45, V: 22:02]

**Enjoyment**

- Enjoyment seems straightforward ‒ “*I want to enjoy my life, get a lot of pleasure*” ‒  but that’s wrong
- Pleasure is limbic
- Enjoyment involves the prefrontal cortex

***Enjoyment is a much more complex phenomenon than pleasure***

- Pleasure is a signal from the limbic system that says this thing that you’re doing will help you survive usually through caloric needs or passed on your genes through something like sex, nothing more
  - It’s just like any positive emotion, it sends a signal saying, “*Do more of this.*”
- That’s not the secret of happiness
- That’s incredibly evanescent; it’s extremely temporary
- And if you pursue pleasure, what you’ll be doing is you’ll be engaging systems in your brain
  - The [dopamine system](https://en.wikipedia.org/wiki/Dopamine), for example, which is the anticipation of reward, the reward being pleasure
  - [This was the subject of [episode #321](https://peterattiamd.com/annalembke/) with Anna Lembke]
- You’ll hit the lever, get the cookie; hit the lever, get the cookie
- It will never last, and you’ll become an addict

> “*Pleasure seeking, I mean, the hippie phenomenon, the hippie motto of ‘if it feels good, do it’ is life ruining advice*.”‒ Arthur Brooks

- If you only did what feels good, you’d never go into an ice bath
  - You wouldn’t stay married

***What you need for enjoyment: the source of pleasure, people, and memory***

- That’s where you’re engaging your prefrontal cortex
- So Anheuser-Busch *never* runs ads for beer of a dude alone in his apartment pounding a 12 pack
  - They never do that, right?
  - A lot of people use the product that way
  - Why don’t they show that?
  - Because that’s the pursuit of pleasure and that’s dangerous; that’s bad for you
- Use of methamphetamine is bad for you
- What we’re incredibly good at using science today is to take things that give a little bit of pleasure evolutionarily and supercharge them
  - Natural endorphins that you get that will block pain under normal circumstances, we can supercharge them in a lab and make fentanyl and 100,000 people died last year

***That pursuit of that pleasure is utterly ruinous***

- We look at a random series of events, and when it’s random, we get payoffs a little bit
  - We’ll seek those events, and that gives us a little bit of pleasure
  - We turn that into slot machines in Vegas, and then you’re sitting there at 4:00 AM by yourself
  - Really, really bad for you

***That’s the problem: seeking pleasure alone, not making memories, will make you miserable***

- Usually if something gives you pleasure and you’re doing it alone, you’re usually doing it wrong
- Example: pornography is a problem
  - It uses the sexual function in a way that leads to addiction and huge problems in people’s lives
  - It’s contraindicated
  - It’s not good for especially young people to use that, but that’s the same thing as fentanyl in this way

***Okay, so what do you do? You make sure you’re with people, especially the people you love, and you’re making memories***

- That’s why Anheuser-Busch’s ads have 2 dudes or 10 dudes or a family cracking open a Bud and drinking it and laughing
  - Because in the ad they want you to associate the beer with happiness, which is *enjoyment* is the central factor, *not the pleasure* that the little bit of alcohol will bring you, and that’s what we need to do (that’s the strategy)

**Peter and his team are working on a very in-depth newsletter on the conflicting data on alcohol (specifically around wine)**

- [[Is low-to-moderate alcohol consumption beneficial for longevity?](https://peterattiamd.com/low-to-moderate-alcohol-consumption-and-longevity/) (January 2024)]
- Why is it that at a biochemical level and certainly looking at the Mendelian randomizations, alcohol is toxic at any dose and it’s a monotonically increasing function, so there’s no amount of alcohol that is healthy
- Yet the epidemiology is pretty significantly in favor of modest drinking over abstinence
- And once you even strip out all of the obvious confounders that would lead to that, you’re left with the phenomenon you describe, which is if you dig into the data really deeply, it’s the *Mediterranean drinking pattern* that seems to be associated with some benefits at low doses
  - People and memory, not the alcohol per se
  - The food and the wine and the people combo that seems to be beneficial, not the vodka and Red Bull in the dorm issue
    - Even though it’s the same molecule, it’s a very different experience
- Processed sugar is the same thing: you find the people who eat candy one to three times a month on average live a year longer than people who abstain completely from candy
  - Candy’s terrible for you: it rots your teeth, it leads a metabolic syndrome
  - Eating candy one to three times a day is very different than eating it one to three times a month
- And so the whole point is you do something that you enjoy
  - It’s something that gives you a little bit of pleasure, which something really sweet does because of our evolution
  - Something that gives you a little bit of euphoria, like alcohol, it makes you feel good

***But you do it with people and you make a memory***

- Unless all your friends are drunks, which is bad

***You can use a little bit of poison in a productive way, but it has to be about enjoyment, never about pleasure per se***

- Arthur wishes he had this information when he was in his twenties (not 59)
  - It would have saved him a lot of grief
  - All that time he wasted with drinking, with unproductive activity
  - And the way he missed opportunities to love and be loved and to have a happier life

> “*This is really, really news that people can use.*”‒ Arthur Brooks

**From an evolutionary perspective**

Peter points out, “*This is probably one of the stronger arguments against evolution being in favor of happiness. It’s clear that evolution is in favor of* ***pleasure****. Pleasure might be one of the most potent fuels that drives the engine of evolution, at least when it comes to reproduction, but certainly other aspects of evolution as well.*”

- But **enjoyment** is a higher order process and Peter guesses it would not necessarily have the same evolutionary drive, although he supposes being with people obviously also has a strong evolutionary bent if for no other reason than we couldn’t have survived alone even through the industrialization of agriculture

Arthur explains, “***The problem is the maladaptation that comes with technological progress is that you can strip off the component of enjoyment that is pleasure and then supercharge it in the lab. That’s the problem***.”

- The internet makes it possible to do that
- Chemistry makes it easy to do that
- There are all kinds of ways that we strip out that component of enjoyment, so it’s no longer part of the evolved societies that would’ve been more traditional

Peter asks about the person listening who loves to smoke and says, “*Guys, I enjoy smoking, I really enjoy it*,” is this really pleasure (if you’re doing it by yourself)?

- That’s right
- Arthur’s wife smokes 2 times a year when she’s with her sister in Barcelona
  - She loves her sister
  - Her sister smokes only after meals, only with people maybe once or twice a day (which by the way is too much)
  - Suffice it to say that any amount of tobacco and any amount of smoke in your lungs is not good for you
  - His wife is not a smoker
- Arthur used to be a smoker, but now he doesn’t touch it
  - Not even twice a year
  - He doesn’t want that monkey on his back
  - He so thoroughly stripped the pleasure from tobacco off from the enjoyment of communally smoking that he can’t handle it anymore
  - Part of that is his mad scientist, part of that gets back to what they talked about earlier

## Satisfaction: one of the three macronutrients of happiness [A: 30:45, V: 29:55]

**What is satisfaction?**

- Satisfaction is the joy after struggle
- If students cheat to get an A on an exam, there’s no satisfaction
- But if they actually struggle for it and they study for it, they get a ton of satisfaction when they get an A, because that’s how we’re wired

***Again, this comes back to the evolutionary psychology, even biology, is that you go looking hard for something and you get it, you want that to be reinforced as a good thing to do***

- That’s why Mother Nature really wants that to happen, and that’s why we have that evolutionary imperative

**Here’s this little twist that Mother Nature throws into it**

- If you knew that the satisfaction (that joy) wasn’t going to last, you’d think twice before going through the struggle
- You’d think twice about the cost benefit analysis
- If you said to yourself, “*I like that watch. It’s a nice watch,*” I don’t know what kind of watch that is
  - That’s a Seamaster or something, right?
  - It says GMT; it’s a nice watch
- But if you’d thought to yourself, “*It’s a pretty expensive watch. I’m going to really, really like it for a week,*” you’d think twice about it
- This is a trivial example, but there’s all kinds of things that we do
  - That relationship, that conquest, that business plan, that fill in the blanks
  - “*I’m not going to enjoy it for very long*.”

***Mother Nature shields you from that truth; you have to have it wear off quickly because you wouldn’t be ready for the next thing***

- If you’re a caveman and you’re looking for calories and you find berries on a bush after a long hike, that’s incredibly satisfying
  - That gives you a bunch of joy
- But if you sat there enjoying them for the next week, you’d be a saber-toothed tiger’s dinner

***You have to be ready for the next set of emotions. That’s homeostasis. You go back to the baseline, physical baseline, emotional baseline (you always go back)***

> “*But if you realize that, you won’t make the effort in the first place.*”‒ Arthur Brooks

- So Mother Nature tantalizes you with the joy that’s going to come after the struggle and then veils the knowledge that you’re not going to enjoy it forever
- For example, people actually think, “*If I move to California, I’m going to be happy for the rest of my life because of the sunshine.*”
  - Arthur has the data: it’s a few months
  - The taxes are forever
- Arthur sees this constantly with people
- His students think they’re going to be happier at 38 than 28, which is generally not true
  - Generally your happiness is lower at 38 than it is at 28, and lower at 48 than it was at 38
- The reason they get it exactly upside down, is because they think that they’re going to get things they want and they’re going to be satisfied forever with them
  - When they get married, they’ll be permanently happier

**Have you been able to quantify the length of satisfaction, the duration of satisfaction when they get admitted to Harvard Business School (before they matriculate)?**

- Oh yeah
- There are interesting studies that ask this question, when you get a bonus at your job, when do you enjoy it the most?
  - When it hits your check or the day you find out?
- It’s a question that answers itself
- You go home because your boss says, “*You’re the linchpin in this company. What a great job you’re doing, 40% bonus*.”
  - You don’t have the dollars, but you go home and open a bottle of champagne with your spouse
  - You earned it; it’s great
- Three weeks later, it shows up in your check and you’re like, “*Huh, yeah. Yeah, good. Good. I can do something with that.*”
- But that’s not where the real satisfaction happens because of the **homeostasis**
- Now, the fact that this surprises you leads to deeply **suboptimal behavior**
  - If you keep getting surprised again and again and again and again, the satisfaction doesn’t last
- Natural conclusion is that you just needed more; it just wasn’t enough
  - So go get more and more and more, and this leads to this chase, what we call it in Arthur’s business the “**hedonic treadmill**”
- Hedonic means feelings, and the treadmill is you’re running, running, running, running to keep, maintain, and to get more of certain feelings, and you never figure out that you’re on a treadmill and not making progress
- The homeostasis is that you catch up immediately
  - You get ahead by two inches and immediately it starts running you backwards
- Unless you keep running, running, running, running, then you’re going to be going the wrong direction, and that’s terrifying and terrible

***So people not figuring out Mother Nature’s cruel little hoax, they wind up on the hedonic treadmill of more, more, more, more, more, have more***

**Why are we fooled by this?**

- We’re born to be fools when it comes to this satisfaction problem

**Peter’s takeaway** ‒ “*This is actually one of the macronutrients where it seems that evolution is fully engaged. Clearly, evolution favors pleasure over enjoyment, but evolution is all for satisfaction… and all for fooling you into believing this is the one that’s going to be the eternal satisfaction*.”

- Arthur agrees, “*That’s the animal path.*”

**But there is a glitch in that matrix that we can exploit if we’re willing to stand up to our natural impulses**

*This is where every philosophical and religious tradition comes in*

**⇒** According to the First Noble Truth of Buddhism, life is suffering

- That doesn’t mean life *has* to be suffering
- It means life is naturally suffering

***What the Buddhists are saying is that left to your devices, you’re going to suffer***

- And the word for suffering in that First Noble Truth of Buddhism is mistranslated
- The word in Sanskrit is dukkha, and dukkha actually means **dissatisfaction**
- [the [Four Noble Truths](https://en.wikipedia.org/wiki/Four_Noble_Truths)]

**⇒** The 1st noble truth of Buddhism is that life is unsatisfying because of the hedonic treadmill, because of homeostasis

*And how do you get beyond that?*

- You recognize that the reason for your dissatisfaction ‒ this is the second truth

**⇒** The 2nd noble truth is **attachment** is the reason for your dissatisfaction

**⇒** The 3rd noble truth is that you need to **detach**

**⇒** And the 4th noble truth is the [**Eightfold Path**](https://en.wikipedia.org/wiki/Noble_Eightfold_Path), which is entirely contrary to nature

- The Eightfold Path is NOT natural, and that’s why it’s hard

Here’s the way to think about it:

- Mother Nature says satisfaction will come and stay if you have more, more, more
- What’s your life strategy?
  - More. More money. More power. More pleasure. More admiration. More Instagram followers. More.

***The right mode, a model that better satisfies, that gives you more satisfaction that lasts is: haves divided by wants***

- All the things you have divided by all the things that you want
- And this is basically kind of what the Eightfold Path of Buddhism comes into (this is a baby version)
  - Arthur apologizes to the Buddhists who are listening to us
- The Eightfold Path says you don’t need to have more strategy, you need to want less strategy ‒ you need to want less

***We need to manage our wants in this life, and in so doing, then satisfaction hangs around***

- That’s what the Dalai Lama always says, “*You shouldn’t have what you want, you should want what you have*.”
  - Really which is another way of talking about this

**There are all kinds of techniques, of visualizations to do this**

- Because Arthur has an arts background: he was a professional musician for many years and his mother was a painter
  - We have a tendency to think of our lives that we’re building, especially the hustlers, the go-getters, the strivers who listen to you
  - That your life is like a beautiful painting and you’re the artist with a brush, and that canvas is your life, and you’re putting the brushstrokes on the canvas
- The problem is by the time you’re 45 and you’re a striver, that canvas is full (it’s dense)

***You need to use the metaphor that your life is actually a sculpture, that you’re chipping away, that you are in there, but there’s too much stuff stuck to you ‒ you need less, less, less***

## Sense of purpose: one of the three macronutrients of happiness [A: 38:45, V: 37:53]

**The third macronutrient (a sense of purpose, meaning) extends far beyond “work”**

- Arthur explains, “*Meaning is the most important because it’s the protein. You’ll die.*”
- You can vary the carbs and fat a lot, but you can’t mess with protein too much
  - It’s a basic building block and you’re in big, big trouble when you become protein deprived, because there’s no other way to get it
  - It’s not like your carbs are going to transform into proteins
- And everybody knows when they don’t have a sense of meaning because their life is empty

***They’re the most miserable when they don’t have a sense of meaning, but nobody knows exactly what it is***

**Philosophers and psychologists define meaning as a combination of 3 things: coherence, purpose, and significance**

1 – **Coherence** is things happen for a reason

- That’s the first part of meaning
- You believe that things happen for a particular reason
- That doesn’t mean your way is the right way and it might be randomness
- Arthur’s father was a Ph.D. biostatistician, also very religious, and he used to say that the greatest miracle in the world was randomness
  - That God built the universe with randomness and regular distributions of events
  - He thought that miracles were extreme tale events in random distributions, and God loved randomness
- In other words, there’s lots and lots of different ways to understand why things are coherent

2 – The second is **purpose**, which is direction

- Your life has direction
- There’s a word called the [rhumb line](https://en.wikipedia.org/wiki/Rhumb_line), and it means the end point toward which your voyage is tending
  - You’re not going to get there and you’re going to vary from it, but you have to have a north star (something you’re navigating to)

3 – The last is **significance**: it would matter if you weren’t alive

***These are worth thinking about in detail in our lives***

**Arthur has a diagnostic test to see if somebody has a meaning crisis**

- It’s a 2 question exam
  - And if somebody doesn’t have real answers…
  - Everybody’s got PC answers, answers you give your mom or whatever
- The reason this is useful is these are the 2 questions to go looking for answers to in your life

> “*This is your vision quest is to find the answers to these by reading, by experiencing, by meditating, by spending time by yourself, by praying, by asking people’s advice, by therapy (I don’t know, do your thing).*”‒ Arthur Brooks

1 – Why are you alive?

- You got to have an answer, your answer, a real answer

2 – For what are you willing to die today?

- You flunk this quiz by saying, “*I don’t know*.”
- The adventure actually begins after you flunk the quiz because it’s like, “*I’m going to figure that out. I’m going to go find those answers. I’m going to read. I’m going to consider. I’m going to do all the things that you do metacognitively to find the answers to these questions.*”
- There are probably a lot of people who cannot answer #1
- Or who can answer #1, but can’t answer #2
  - I’m alive because of some biological process, etc.
  - But #2 is I don’t know what I’m willing to die for

Peter asks, “*Are you asking #1 through the lens of biology?*”

- It depends on how you answer it and what actually gives you meaning
- A spiritual person or a religious person would have a divine response to the first question
- An atheist would respond to the first question in terms of biology
  - They would really understand that the biological answer could give you a tremendous sense of meaning and a sense of place in the universe

Peter adds, “*Although it’s interesting because as someone who leans far more towards the agnostic atheist side, I spend most of my time coming to grips with mortality, which is a very difficult thing to come to grips with.*”

- Which is question #2
- Peter comes to grips with that by addressing Arthur’s third point around sense of purpose, which is his insignificance
  - In other words, it’s only through accepting his complete and utter insignificance that he can have some semblance of peace with his finitude and his eventual and relatively quick demise

Arthur agrees, “*This is one of the reasons that transcendence**is one of the happiness practices*”

- The practice of **transcendence**, whether it’s secular or religious transcendence is really important because it makes you small
  - You stand in awe of a sunset
  - You stand in awe of seeing somebody committing an unbelievably selfless act

***Transcendence makes you actually feel smaller, which gives you peace through a sense of perspective***

- One of the people who works in Arthur’s area, [Dacher Keltner](https://psychology.berkeley.edu/people/dacher-keltner) at UC Berkeley, has a book called [*Awe*](https://www.amazon.com/Awe-Science-Everyday-Wonder-Transform/dp/1984879685/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) that talks about the neurocognitive processes involved when you’re experiencing awe, and why it gives you such deep peace
- And it’s really all about what you’re talking about: you got to get small

***If you can find ways to get small, you’re going to be a lot better off, for sure***

**How do we reconcile that with the need to have significance through your sense of purpose?**

- The key is at the same time you realize that you matter, but at the same time, it’s okay that the universe will be just fine if you die
- They seem like conflicting phenomenon, but they’re actually weirdly compatible
  - It matters that I exist here, and things will be just fine if I don’t
- You think about this when you get married for the first time
  - You say, “*You love me, and if I’m gone, you’ll be okay.”*
- It’s this sense of peace, that balance between those two things turns out to be the trick
- Peter reacts, “*I’ve never been able to find that.*”
  - Arthur hasn’t found it either for sure, but he thinks practice makes perfect

**The way to think about this and the way to find the answers to the questions is really interesting**

*Arthur has worked on this with his kids*

- He has adult kids
- His 23-year-old (Carlos) is like Peter, he’s human performance machine
  - He’s a scout sniper in the US Marine Corps
  - 204, 4% body fat, 6’5”
- Carlos didn’t have the answers to that because many young adults don’t
- But he found the answers to that as he did something that was truly difficult
  - Going through marine basic training and then infantry training battalion, and then doing the Indoc to become an operator in the Marines, in the scout sniper platoon
  - That stuff’s no joke, it’s hard
- If you ask him question #1 now: Why are you alive?
  - He’d simply say, “*Because God made me to serve.*”
  - That is both the how and the why of question #1
- Question #2: For what are you willing to die?
  - Very simple: for his faith, his family, his fellow Marines, and for the United States of America and our allies
- These are very solid answers
- These are not the right answers for somebody listening, or you, or me necessarily, but they are answers that he actually believes, and that’s what gives him his sense of meaning

***Finding what we really do think about those things; what really is persuasive to us is a philosophical, and (for some) a theological journey really worth taking***

## Fame: one of the traps that hijack our happiness [A: 46:30, V: 45:39]

***The traps that hijack our happiness (the 4 idols): money, power, pleasure, and fame***

**Fame**

- Arthur says that fame is a funny one because most people listening will think, “I *don’t want to be famous,*” but they want to be admired by others and have some prestige
  - That’s localized fame
  - To be known and admired by the right people
- It’s exactly the same phenomenon philosophically and psychologically

*How much of the pursuit of this is nature versus nurture?*

- There’s a lot of research on that
- Most of the philosophy and even the evolutionary psychologists would suggest that we’re hardwired to be looking for money, power, pleasure and fame, because that gives us f**itness in the mating market**
- Who gets mates?
  - Somebody who’s got a bigger cave, more flints, more animal skins, more Buffalo jerky piled up in the corner, and is actually known by more people than he or she knows
  - This gives you mating fitness
- And so the results is this would become an imperative; it would become hard wired
- There is all kinds of evidence of this

Arthur explains, “*You actually find that when people are at their base nature, when they’re being distracted, they will go for these particular rewards over much more intrinsic, more satisfying rewards having to do with love.*”

- We see this in our consumer patterns
- Neuroscience research talks about it, how it will illuminate our brains, how it will stimulate the most dopamine
  - The most dopamine comes from these not very satisfying rewards, but nonetheless, the ones that we’re supposed to go for

Now, here’s the key thing to keep in mind ‒ mother nature wants you to pass on your genes

- Mother nature wants Peter Attia to have a hundred kids
  - But of course Peter doesn’t want that
  - He wants 3 and you want to have a lifelong partnership with 1 wife
- And that means that you can’t live the hippie motto of, “*If it feels good, do it.*”
  - That is the motto of useful idiots
- By the way, there’s other stupid mottos like, “*If it feels terrible, treat it and make it go away,*” because suffering is really important in a full life too, it turns out

> “*The key thing to keep in mind is that mother nature, she doesn’t care if you’re happy.*”‒ Arthur Brooks

**⇒** We don’t select on happiness; we select on biological fitness to mate, to pass on our genes

- And so the result is, if you follow, “*If it feels good, do it,*” you’re going to be chasing a whole lot of very fleeting rewards for what you think is enduring satisfaction
  - And you’re going to have your hedonic treadmill speeding at a terrifying velocity, and you won’t even know how to get off it

***You need to get in charge of your own life, this is the bottom line***

## Success addiction, workaholism, and their detriment to happiness [A: 49:15, V: 48:34]

**Arthur wrote in** ***The Atlantic*** **a couple months ago about** [**happiness**](https://www.theatlantic.com/family/archive/2022/03/chasing-happiness-leads-to-dissatisfaction/629427/) **and** [**success**](https://www.theatlantic.com/family/archive/2022/02/reaching-goals-doesnt-always-lead-to-happiness/622894/)**, noting that the happiest people weren’t necessarily the most successful**

- It looked at some data that suggest a little bit of sacrifice in happiness led to greater success
- We can define success in different ways
  - Having a lifelong marriage, where you’re in love with your spouse ‒ that’s unbelievably successful
  - Believing you have found spiritual transcendence
  - Living for the good of other people
- But that’s NOT what we’re talking about

We’re talking about worldly success, money, power, fame, the admiration of other people

- People who are remarkably successful along those worldly metrics, they’re making cost-benefit calculations systematically that are not in their own happiness favor, typically

***They’re making sacrifices to their own happiness for some reason***

*This is one of the things Arthur has looked at in his own research: Why?*

- As a social scientist, Arthur finds it really beneficial to go out and talk to humans

Arthur interviewed an unbelievably successful woman on Wall Street

- She was a billionaire from business startups
- She had epic success after success and was very well known
- She confessed she was missing decisions, people were doubting her
- At the same time her and her husband were just kind of roommates, she had a cordial relationship with her adult kids, she was starting to get bad blood work back from her doctor, she thought she was probably drinking too much, she couldn’t sleep right
- She asked him, “*What are you doing?*”
- Arthur replied, “*You don’t need a nerd from Harvard to tell you what to do. You told me you’re a billionaire, step back from your company, take a souvenir in it, go onto the board, whatever, get to know your husband, reestablish a relationship with your kids, start to take care of your drinking problem. Become a client of Peter Attia, I don’t know.*”
- He asked her why she doesn’t do these things

***She thought about it and replied, “I guess I’d prefer to be special than happy.” ‒ this is the hallmark of addiction***

**Addiction**

- Arthur used to be a musician, and he’s met a lot of addicts, he’s met a lot of alcoholics

***And they will confess that before they got clean and sober they preferred to be high than happy***

- They knew they’d be happier when they were finally beyond this thing, but wanted to get high one more time
- [William Burroughs](https://en.wikipedia.org/wiki/William_S._Burroughs) called it, “*The red, the blood in the hypodermic needle before you actually put down the plunger and it gives incredible pleasure to people*”
- They say just one more time, and that’s what that lady was saying to him

***That’s a success addiction, that is absolutely implicated in the dopamine system and that is like any other behavioral addiction that a lot of very worldly, successful people fall prey to (a lot of people listening to this)***

- You have to ask yourself, “*Is this a pathology that I’m actually feeding by actually trying to get this edge?*”

**There’s a lot of literature on workaholism**

- Workaholism is an ancillary addiction to success addiction
- People work really, really hard; the payoff, the cookie that you get, the dopamine is just driving you to is:
  - The promotion
  - The raise, the dollar
  - The compliment
  - The adulation on social media
- People that are going to be sacrificing their own happiness decisions for these success metrics

**What would the world look like today if no one was pursuing being special over being happy?**

*How much of the modern marvels of this world do we owe to the backs of people  who sacrificed their own happiness for the innovation that allows us to be doing what we’re doing right now?*

- Arthur has thought about this, “*For me to say, you and I should break our success addiction, therefore the world would be better if nobody had a success addiction, it’s the fallacy of composition.*”

Arthur’s metaphor: it’s to basically say, since I get home faster if I go a 100 miles an hour down the freeway, it would be better if everybody drove a 100 miles an hour on the freeway

**⇒** What you find is that many of the greatest innovators, composers, creative intellects, these were people that absolutely sacrificed their happiness

- They were deeply, deeply unhappy
- There’s a huge literature that shows the [ventrolateral prefrontal cortex](https://en.wikipedia.org/wiki/Ventrolateral_prefrontal_cortex) is stimulated in depressives in a way that makes them highly creative
  - There is good brain science that shows the people who are suffering from mood disorders tend to be disproportionately creative and they do a lot
  - [Van Gogh](https://en.wikipedia.org/wiki/Vincent_van_Gogh) was not the outlier, it turns out
- There’s a lot of weird people in Silicon Valley that have a lot of untreated maladies, and they’re doing a lot
- It is true, that the world has been propelled by a lot of unusual people with unusual goals

Arthur concludes, “*I don’t know if I were the divine, how I would create the universe. I don’t know how I would designate people in society. I don’t know whether I would make people sacrifice their happiness for the greater good of the whole. I’m just not sure whether there’s a success martyrdom that’s going on here.*”

- Peter adds, “*My two cents having none of the data and none of the insights that you do is that we are probably a lot better off for people who have made enormous sacrifices.*”
  - Think about the great physicists, the great mathematicians‒  [Newton](https://en.wikipedia.org/wiki/Isaac_Newton), [Gauss](https://en.wikipedia.org/wiki/Carl_Friedrich_Gauss), [Euler](https://en.wikipedia.org/wiki/Leonhard_Euler)
  - These people made untold sacrifices in terms of the pain that they endured as a result of their genius
- Arthur agrees

> “*But there’s one thing that I want to emphasize, which is that the misery is not inevitable*”‒ Arthur Brooks

**This is one of the reasons Arthur has done his work**

- He’s not asking people to not be successful, ambitious, or not to work hard
- He’s asking them to dominate it, such that you’re not playing to your most innate drives, so that you can be successful and happy
  - This is a pretty small group of people, but they are there
- Arthur writes in his [book](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) about the case of [Johann Sebastian Bach](https://en.wikipedia.org/wiki/Johann_Sebastian_Bach), the greatest composer who ever lived, who died surrounded by the people who loved him and who revered him

***The reason is because he got on his second curve, he dedicated his work to other people***

- He didn’t say, “*Forget it. I’m not going to write anymore music*”
- He said, “I*‘m going to write music. And I’m just going to detach myself from the ego of having this enormous audience of people who will say that I’m the greatest composer ever, and I’m going to do it for humanity and to glorify God and to refresh the soul of other people. And if it’s really successful in commercial terms, it is. And if it isn’t, that’s okay too.*”

Arthur concludes

***In other words, be really ambitious, but detach yourself from the worldly idols and think about how you can use your success in service of other people. And that’s the hack, that’s the work around, that’s actually the glitch and the success on happiness matrix, is when you become “other” focused, you can be a success machine and also happy.***

- Peter agrees and adds, “*Just because that’s what got us here today as a civilization, doesn’t speak to the individual choice that we all have.*”

**An example from Peter’s practice is his thinking on cancer screening for an individual**

- This is based solely on the individual
  - This is really all about individual risk, individual cost and what the reward potentially is
- It would be a totally different question if he were in charge of creating a cancer screening program for everyone in the country
  - When you start to talk about it at a societal trade-off level, it’s a much more complicated problem
  - Now you have to look at quality adjusted life years and all these other metrics, and you have to balance a budget to basically do this

**Peter’s takeaway‒** ***just because everything we said is probably true, it doesn’t mean that any one individual doesn’t have the potential to make a choice to live in less misery or to be happier***

Arthur agrees and adds, “*I believe you don’t even have to sacrifice the success, but you do have to go against your worldly urges in a very big way.*”

- Not the urge for success, but against your worldly urge to pursue the success for a particularly idolatrous reason
- This is the point that’s made by philosophers and theologians forever, “*When you do things in service of others, to lift other people up, to bring other people together, then you can become unbelievably successful*”
- You can become the [Dalai Lama](https://en.wikipedia.org/wiki/Dalai_Lama), [Desmond Tutu](https://en.wikipedia.org/wiki/Desmond_Tutu), [Mother Teresa](https://en.wikipedia.org/wiki/Mother_Teresa), [Albert Schweitzer](https://en.wikipedia.org/wiki/Albert_Schweitzer)

What do all of those people have in common?

Arthur explains, “*They were world-famous, but they were* ***doing this in the service of their fellow women and men****, and that was the key distinction that allowed them to wiggle their way into the both happy and successful quadrant*.”

## The reverse bucket list: one of Arthur’s tools and practices he recommends for moving past the traps that hijack our happiness [A: 59:15, V: 58:32]

**Here’s the “reverse bucket list” exercise Arthur gives his students**

- The way for them to be successful is through the visualization and manifestation that comes from having a **bucket list**
  - On your birthday you list all your ambitions and all your desires and your cravings, and you imagine yourself getting all these things (this is the visualization)
  - That’s a good way to blow up the denominator of your satisfaction equation and feel like a complete loser
- You need a **reverse bucket list** where you make a list of all of your worldly attachments and you cross them out
  - Not that you won’t get them, but that now they’re not limbic
  - Now they’re in your prefrontal cortex
  - Now that you can actually manage those cravings in an entirely different way
- And this absolutely works

***Arthur does this reverse bucket list exercise on his birthday every year now***

**Using the “reverse bucket list” technique with your opinions**

- For example, on his last birthday, Arthur thought, “*What are my attachments that are holding me down?*”
  - He realized it was a lot of political opinions
- [Thích Nhất Hạnh](https://plumvillage.org/about/thich-nhat-hanh/biography) (the Vietnamese Buddhist monk who started the Plum Village Community of Western Buddhists) said that the greatest source of misery and attachment for most people is their opinions

***We’re so attached to our opinions; it’s like we’re hoarding our gold***

- And if you get between me and my opinions, you’re stupid and evil
- Arthur thought to himself, “*My political opinions are too strong. I’m too attached to them*.”
- So he wrote down about half of his political opinions
  - He still has them, but he crossed them out which negated their importance, their moral importance in his life

***He need fewer opinions because what it really comes down to is he needs more friends***

- Now he’s way lighter, way freer

## Metacognition: one of Arthur’s tools and practices he recommends for moving past the traps that hijack our happiness [A: 1:01:00, V: 1:00:08]

**How does the exercise of acknowledging the opinions and crossing them out, how does that translate?**

- For instance, we sit here today on the heels of a tragedy that took place very recently, a terrorist attack, and it’s a very dividing event politically
- Even though Peter is not a political person, he doesn’t talk about his political views publicly, he has very strong views
  - And as a result of that, he’s prone to be very judgemental of those who hold opposing views
  - There are certain views where he is all about nuance, and there’s some views where it is black and white

*How would that exercise help in this situation?*

- This gets back to metacognition

**⇒** Metacognition is not being limbic, but rather experiencing emotions and emotional phenomena in the prefrontal cortex of the brain, where you can make conscious executive decisions

> “*Experiencing emotions and emotional phenomena in the prefrontal cortex of the brain where you can make conscious executive decisions, is letting your CEO do it as opposed to the kids do it.*”‒ Arthur Brooks

What you do when you have a strong volatile political opinion (which is not just terrorism is bad)

- When it’s that anybody who disagrees with me about this particular situation is a moron, that’s what goes on the list

***What you do is you cross that out, not because you don’t think that, but because you’re willing to consider that***

- You’re willing to let your CEO think about that as opposed to axiomatically assuming that
- It’s no longer a limbic opinion where you see something on TV and you get a sense of revulsion, where your insular cortex engages because you have a sense of disgust on the contrary

Peter asks, “*Do you think that that’s a better strategy than my strategy (which is to tune all of that out) is to basically say, ‘I’m going to do something that feels cowardly,’ which is I’m not going to engage in any of this by reading any of it, by watching any of it, by participating? I’m going to focus on what I do best. I’m going to do my job and not become a spectator.*”

- There’s a lot to that because you should specialize in what you can do well

***You should focus on the things you can control as opposed to the things that you can’t***

- These are 2 different phenomenon
- Peter points out, “*You could argue my strategy is a dangerous strategy from a societal perspective because then if everybody took that approach, nobody would do anything.*”
  - Arthur agrees
  - You wouldn’t have any collective action, and everybody would be ignorant for sure

**What you’re trying to do is protect yourself from your limbic system when you block out information**

- This is basically: I don’t like the news, so I’m going to cancel the newspaper
- You shouldn’t be afraid of information, and that’s all your limbic system is delivering to is information
- You should learn how to use information

***Ideally, what you do is metacognitively you process the information and make decisions on how to use the information***

- Sometimes that’s not efficient
- Sometimes that’s suboptimal because you don’t have time to do it

**Arthur has found that he uses a combination of the 2 techniques**

- He was president of a [think tank](https://en.wikipedia.org/wiki/American_Enterprise_Institute) in Washington, DC for almost 11 years
- He was so aware all the time of what everything everybody was saying and doing; he knew what was going on
  - He knew if there was going to be a budget resolution
  - He could tell you what was going on with a farm bill, the whole deal

Now he knows a lot less, and the reason is he rations his access to news

- He reads a total of 15-30 minutes of news per day all at once
- He needs more bandwidth for his work, and he doesn’t want it to intrude on his work
  - But he’s not afraid of his limbic system
- He’s not afraid of what this information will actually do to him because he’s working metacognitively to make sure that when he does have this information, he can process it in executive ways as opposed to childlike ways
  - It’s no longer “ghosts in the machine”

Arthur has a repertoire of ways he can deal with it

- 1 – He can choose his reactions to his emotions
- 2 – He can use substitute emotions
- 3 – He can act as if he had different emotions, and he can disregard his emotions
- But all of that is on purpose, and those are the fruits of metacognition

**What do you do with your knowledge base?**

*As a mad scientist, what are the tools you use to regulate your emotions and keep the balance more on the positive versus negative valence?*

> “*The reason I’ve done this research, Peter, is because I need it. This is me-search.*”‒ Arthur Brooks

- If you’re a mad scientist and you don’t self-manage, you’re going to be all over the place
  - You’re going to be a big mess
  - You’re going to have difficult relationships
  - A lot of the time, you’re going to be miserable, and it’s avoidable

***It’s actually unconstructive not to self-manage***

- But self-management is not one weird trick as they like to say on the internet
  - There’s no hacks

**It’s really all about mental habits**

- It starts with knowledge of the science
- It goes into specific practices, and then a lot of it has to do with teaching other people
- As you know, the best way for you to live better is to teach other people how to live better
- If you want to be healthy, start a health podcast or something and make sure you’ve got good science on your side

*When it comes to being a “mad scientist”…*

- The mad scientist profile that’s hard to manage otherwise, and the mistake that people get into is they try to stay on the positive side
- With bipolar disorder, we find that the biggest problem that they have is staying on their meds because they like the manic and they don’t like the depression, but they can’t time it
  - And by the way, Arthur is not saying that every mad scientist has bipolar disorder
  - He’s just saying that they tend to have mania
  - There’s a hypomanic edge, as [John Gartner](https://johngartner.com/) talks about, and that’s what most mad scientists have, a little bit of this
    - That’s why they tend to make pretty good entrepreneurs (like Peter), but they fall prey to a lot of mood issues that are pretty avoidable

***You actually have to stabilize your mood so that you’re not seeking the highs and trying to avoid the lows***

- At the pro level of self-management in the mad scientist category is to not seek the highs because the highs don’t help you that much

***What you actually need to be is a full person, not riding the wave of your emotions ‒ you need to manage your emotions and never let them manage you***

**That gets into the whole topic of metacognition**

**⇒** That is to experience your emotions in your prefrontal cortex as opposed to living according to your limbic system

- Never be managed by your limbic system
  - Your limbic system is nothing more than the factory for your emotions
  - And if you’re basically taking raw factory materials and trying to live according to them as opposed to assembling them, making them into a set of experiences, learning from them, growing from them, you’re not fully alive
  - You’re subject to a crazy machine all the time

A lot of what Arthur writes about is actually how do you experience emotions more fully in the prefrontal cortex of your brain?

- What are the techniques for doing so?
- And when you’re doing that, what is the repertoire of reactions and responses that you can bring to a highly volatile emotional state?

**Are there any folks where, for example, the poet (the great artists), where you actually push them to be more in that limbic system or is it the same for everyone because the poet is the one who’s disproportionately down?**

- There’s interesting research that doesn’t use the same [PANAS test](https://en.wikipedia.org/wiki/Positive_and_Negative_Affect_Schedule), but it’s pretty provocative nonetheless
- The people who have a tendency toward depression (not bipolar), they tend to be more creative, they’re **ruminators**, and they also tend to be romantics
  - This follows a pattern
  - You’ve met people like this that have this pattern of romantic, creative, depressive, poetic people
- Neuroscience research suggests that there’s a part of the brain that’s especially active for these people: it’s called the [ventrolateral prefrontal cortex](https://en.wikipedia.org/wiki/Ventrolateral_prefrontal_cortex), and this is the part of the brain that you use a lot when you’re ruminating on something, which depressive people do as they think about the thing
- This is also what’s going on when you’re in love with somebody
  - You can’t stop thinking
  - You’re ruminating on another person
- This is the same thing that’s going on when you’re working on a business plan or writing a symphony or actually writing a poem
- That’s what they’re really good at, but also what they’re really bad at
- They can’t stop thinking about things which is good for them and really bad for them
  - Their strength is their weakness

***This is the same thing across all the profiles: your strength is your weakness, your weakness is your strength. Learn to manage it: wire to the strengths, remediate the weaknesses, and complete yourself.***

- Arthur encourages everybody to be more metacognitive
- So that if you’re a poet, you can be really, really poetic but it won’t ruin your life

**Do we think that the most extreme form of greatness that we’ve seen, the most genius type of phenomenon that we’ve seen as a species, always comes from extremes in these categories?**

- It’s almost certainly not true
- It’s sort of the caricature of what we think to be true
- And part of the reason is because those are the spectacular cases
  - You see somebody who’s unbelievably good at something and who’s weird, you focus on their weirdness
- There are tons of people who are extremely accomplished and not that weird (you don’t have to be weird)
- It’s the thing where it’s like, to be a great entrepreneur, you have to be the person that [Walter Isaacson](https://liberalarts.tulane.edu/departments/history/people/walter-isaacson) wants to write a biography about
  - If Walter Isaacson is writing your biography, get help

**⇒** There are tons of people, very successful entrepreneurs, artists, athletes, just people who excel, who have decent relationships, who are able to self moderate, and who don’t abuse drugs and alcohol

- Now, a lot of them do, and part of the reason is because they have certain personality characteristics that go relatively unremediated
- And we have people who are highly limbic
  - They tend to be successful in spite of their messy mental hygiene, not because of their messy mental hygiene

***It’s even better if you’ve got some of these characteristics and you’re really creative and really hardworking and really driven and you MANAGE it; that’s even better***

## Taking charge of your happiness: discipline, transcendent experiences, and other deliberate actions for “happier-ness” [A: 1:11:30, V: 1:10:36]

**Managing social media**

- Thinking about some of those things, based on Peter’s personal experience, he would agree that social media usually does not produce a positive feeling (it’s usually negative)
- But if we’re going to put on our “metacognitive hats” and self-manage…
  - If we think of ourselves as capable of self-managing through difficulty
  - To coexist in this world

**What are the steps we want to take to minimize the damage of these things and at the same time, sort of try to find this semblance of happiness?**

- The goal of Arthur’s work is greater happiness not perfect happiness (that’s not the goal, nor is it desirable)
- People say, “*I want to be happy*,” but they don’t because pure happiness would mean the eradication of your negative feelings and you’d be dead
  - You wouldn’t learn and grow
  - We got get back to the same problem with satisfaction

***Happiness is not a destination, it’s a direction, and we all want to get happier***

- [Oprah Winfrey](https://en.wikipedia.org/wiki/Oprah_Winfrey) calls it “happier-ness” ‒ that’s the goal

**⇒** To do that, you need information, and that’s why Arthur teaches you about the science of happiness

- It’s a super interesting body of knowledge
- Arthur [writes](https://www.theatlantic.com/projects/how-build-life/) about it every week

**Arthur’s advice** ***‒ Do the work to change your habits, and then you need to share it with other people so it becomes permanent in your consciousness***

- Arthur is dedicated to making an entire generation of happiness aficionados and teachers
- He wants a movement of people who say, “*My hobby is learning about happiness. And in my job, I’m a happiness teacher.*”
- And to do that, you have to know the facts on this

**There are certain things you need to protect yourself from and certain things you need to do**

- You need aversion, and you need approach

You need to take seriously your spiritual life

*For the non-religious person*

- Peter acknowledges that most people listening are not religious
- Many people would be confused by Arthur as scientist and serious intellectual guy describing himself as having a very strong religious faith
  - Yet he doesn’t have a difficult time reconciling science and faith

Arthur explains, “*Faith and reason have to coexist in the same way that understanding a Picasso painting and understanding Picasso the man are utterly reconcilable but not the same thing. The painter and the painting are not in conflict with each other. They’re both important things to understand.*”

- Peter points out that there are many religious people who take a very literal view of the Bible and would say, “*Well, the earth is 6,000 years old or whatever.*”
  - They need to study more science
  - They are taking things too literally
  - They’re not understanding that there’s an intellectual bifurcation between the concept of the creation, the myth of how that actually creation takes place (which is the literalness that you’re talking about) and then the evidence (the awe-inspiring evidence of the creation itself)
- One of the reasons Arthur is religious is because of science
  - Every time he learns something new, he’s like, “*Thank you. What a wonderful gift*.”
  - It doesn’t also freak him out that he might be wrong about the science
  - It also doesn’t freak him out that he might be wrong about the religion
- Some people view those with religious views as more fortunate
  - Peter thinks this makes it easier to process death if you believe there is a life after death
  - Arthur agrees, “*There’s meaning in a different dimension*.”
  - Whereas, if you only think of it in terms of biochemistry, death is a blank screen

Death is a “what question” and in the spiritual dimension, death becomes a “why question”

- Those are different interrogatives that have different philosophical and emotional content

There is this area in-between of spirituality (which is not religion), and this is the closest Peter gets to religion

- Around the idea of finding enormous pleasure in nature
- That’s why Peter lives in the middle of nowhere and has to be outside every day; it’s so beautiful

Arthur explains, “*That’s a transcendent experience, and that’s really what we’re talking about.*”

**The transcendent experience**

- A lot of people get transcendence from nature

**What does a person do who lives in a very busy urban center, where they’re surrounded by a wall of concrete all day, every day?**

- If that turns out to be destructive to your transcendence, that’s a reason to move
  - For some people, not everybody
- Some people get their transcendence from other dimensions of life
  - Maybe they’re traditionally religious
  - Maybe they’re serious meditators
  - Maybe they become completely awestruck from music or human genius
  - This really gets back to transcending your littleness

***That transcendent experience, what it does is it gives you the same benefit as a religious journey (the same happiness benefit)***

Peter’s takeaway

- We need to talk about something much broader than religion in the formal sense
- Awe can be the religious belief or an obsession or appreciation of great music or art
  - Or meditation can be the place you tap transcendence
- Arthur points out, “*It’s also very convenient to not invent your own physics on this*“
  - The Catholic Church is really, really good for him

> “[It] *is not what I feel. It’s what I’ve decided to do.*”‒ Arthur Brooks

***This is an important thing to understand about transcendence: you don’t feel transcendence all the time; you decide to experience transcendence and put yourself in the circumstances to experience awe***

- For example, Peter may go outside and there’s a lot on his mind
  - He has a very busy, and hectic, and stressful life, and he doesn’t feel it every single day
- Arthur goes to a mass every day, but  he doesn’t feel it every day
  - He wakes up an atheist a lot

**Why do you go to mass every day?**

- It’s part of the protocol for living the life he wants to live
- He gets up at 4:45, works out for an hour (body), goes to mass (soul), then to work
- That’s when his creativity is the highest
- Notice that he’s optimizing his dopamine
- This gives him the creativity and focus for 3 hours that he needs to write
- He also wants to optimize both body and soul at the very beginning of the day so he’s centered on the things that really matter to him, notwithstanding how he feels

***It’s the discipline of the will that in and of itself is so important***

- He doesn’t want to do it a lot of days, but that’s not the point

**Do you think that there is a deficit of that as well of that idea?**

*The difference between a feeling and the discipline of the will (or commitment)*

- For example, Arthur alluded to **marriage** earlier
- Anyone who’s married for many years will acknowledge that so much of the almost perverse joy of marriage is that you make a lot of sacrifices for another person and you find yourself putting someone else ahead of yourself
  - That’s a very hard thing to do
  - Peter adds, “*I’m just so hardwired to be such a selfish guy that it’s really a wonderful practice to do something where I know, ‘I’m going to make my wife’s coffee today, because she would do the same for me.’*”

**Arthur thinks Peter has discovered (and not enough people have) that love is not a feeling;  happiness is not a feeling either**

- Love is a commitment
- [Martin Luther King](https://en.wikipedia.org/wiki/Martin_Luther_King_Jr.) gave this very beautiful sermon on the most transgressive passage in the Christian Bible, which is Matthew 5:44, love your enemies
  - And he says, “*Jesus says, ‘Today I give you a new teaching. You have heard that you should hate your enemies and love your friends. I tell you, love your enemies and pray for those who persecute you.*’”
  - He says, “*Jesus doesn’t say to like your enemies, because that’s a sentimental thing.* ***To like is to feel, to love is to decide.***”

This is what’s going on between you and your wife

**⇒** The satisfaction, the disciplining of your own will comes from the decision to love her

- That’s the magic in marriage
- That’s the magic in friendship
- That’s the magic that you can have in a relationship with your kids
- Arthur adds that if it’s all about your feelings, he’d be divorced
  - His wife would bail on him because he’s a pain to be around
  - She decides every day to love him

[Aristotle](https://en.wikipedia.org/wiki/Aristotle) talked really compellingly about love and friendship

- [Thomas Aquinas](https://en.wikipedia.org/wiki/Thomas_Aquinas) (based on Aristotle) in 1265, writes the [*Summa Theologica*](https://en.wikipedia.org/wiki/Thomas_Aquinas#Works), his magisterial contribution to philosophy
  - He reintroduced Aristotle to the West
  - Everybody was a [Platonist](https://en.wikipedia.org/wiki/Plato#Philosophy) to Aquinas

**⇒** He defined love as to will the good of the other, as other

- When you’re making your wife that cup of coffee (not withstanding your feelings), you’re willing her good for her, not you

***That discipline of the will to love another person like that, that decision to do so is completely transformative***

- That’s transcendent to the day-to-day experience
- The **animal path** is, “*Well, I’m not going to make coffee. I don’t feel like it*.”
- The **divine path** is to love her, is to will her good as her
  - That’s the human distinction
  - That’s organized life

**Peter’s takeaway** ‒ “*It really seems that that’s almost a theme here of happiness, that happiness is much more about deliberate decision-making, deliberate choices, as opposed to reactive feelings, which that’s obviously the extent to which we’ve discussed it. I think I like this thing that Oprah said, not happiness, but happier-ness.*”

- The thing that Arthur liked the most about what Oprah said was, “*Let’s write a book*… *Let’s spread this idea to a bunch of other people*.”
- Arthur has been listening to *The Drive* for a long time, and this is the salient theme, “*Take charge. Don’t leave your health up to what feels good right now… You’re the boss. The startup is you… You’re the CEO. Treat it as such. The CEO doesn’t do what feels good all the time.”*

> “*The CEO does what’s right, notwithstanding her or his feelings.*”‒ Arthur Brooks

***That’s the secret of happiness, treating your life like a startup… and you’re not going to do it by doing what feels good in the moment***

**When Peter talks about healthspan, Arthur talks about “happy-span”**

- You’re not going to discipline the will sufficiently to be able to make the decisions that lead you on this divine path that can give you this thing that you actually see
- It’s not perfect, but you can learn and grow and have progress throughout the journey

## Tracking happiness: the biomarkers and micronutrients behind the macronutrients of happiness [A: 1:22:45, V: 1:10:36]

**How do you think about the biomarkers of happiness?**

- In Peter’s work, there are so many biomarkers
  - It’s one of the things that makes his job relatively straightforward
  - Blood-based biomarkers
  - Biomarkers of performance: VO2 max, strength
  - Body composition
- Arthur has thought about this so much and he’s had dozens of entrepreneurs want to engineer the idea and app-ize it
- In the class at Harvard, you have to be able to turn it into some sort of a product, and the way that you would do that is by having a relatively complicated but measurable phenomenon that you could look at and get better at
  - That’s a proxy marker for the underlying construct, which is happiness
- Here’s the fundamental problem with that: it’s a different species of challenge

**There’s two types of problems in human life: complex problems and complicated problems**

- Discussed in their earlier podcast, [episode #226](https://peterattiamd.com/arthurbrooks/) at [1:33:30]
- The **complicated problems** are really, really tricky and take a lot of computational horsepower and learning, but once you solve them, you can replicate the solution with effortless ease forever
  - You can do the same with biomarkers
- The **complex problems** are incredibly easy to understand, but impossible to solve
  - There are too many permutations of what can actually happen
- For example, Peter likes Formula 1 racing, and so Arthur is going to take a bunch of Unix machines and wire them together, and with 250,000 lines of code, he’s going to simulate every F1 race for the rest of the year
- This is idiotic. Why? Because F1 is complex
  - That’s why it’s interesting and you want to watch it
  - That’s why it’s so exciting to watch a Formula 1 race, because it’s complex
  - Winning is the simplest thing in the world: you cross the finish line before the other guys
  - But a million different things can happen, and that’s the fun of it

> “*All of life’s joys are complex problems. Most of the solutions that we get from technology and science are complicated solutions*.”‒ Arthur Brooks

***The biggest problems that we have right now has to do with the fact that we want to solve our complex problems (like love) with complicated solutions (like Instagram)***

- A complicated solution to a complex problem will always leave you cold and make you worse off
- For example, if Arthur said, “*I’m going to get rid of all the Formula 1 races because it’s dangerous, and I’m going to have nothing more than computer simulations of it*.”
  - That’s dumb
- That is key for us to understand, and that’s the reason he can’t app-ize this

***Happiness is a complex and adaptive human phenomenon, and you can only get it by living it, and working on it, and making progress, and failing (just like your marriage)***

- Peter acknowledges, “*In that sense, at least I get feedback in my marriage, because when I screw up and I apologize, I see that my wife forgives me. When I make a mistake, I feel the lenience and the love. When I need the help, the help is there. So, indirectly, I’m getting really good feedback.*”
- Conversely, if a person was to take an honest assessment of their marriage, and realize, “*We’re two ships passing and we don’t fight, but we don’t have anything in common,*” if they were thoughtful enough, they’d recognize things are not well
  - So they’d have a barometer there

**Do you think that using others as a mirror is the best way to get the true barometer of happiness?**

*Or, do we rely on our own internal assessment?*

- We wind up with our own internal assessment, but it’s not good enough to have that be one single metric of, “*How happy am I?*”
- We have identified **3 metrics of happiness** so far today in the conversation:
  - 1 – Levels of enjoyment
  - 2 – Satisfaction
  - 3 – Meaning
- We can know whether or not we have those things on the basis of the science that we’ve talked about and the ways that we can get better at and practice it

***The techniques for getting more of those things are faith, family, friends, and satisfying work***

- Arthur breaks it down even further
- He doesn’t try to make it complicated, it’s still complex

**Arthur keeps a spreadsheet that lists the** ***micronutrients*** **behind the macronutrients of his happiness**

- He tracks dozens of dimensions, and he’s rating himself
- He weighs those things according to his experience of how they feed into the macronutrients
- He has scores on those dimensions and he wants to make progress every year

He rates himself twice a year: on his birthday and half birthday

- His half birthday is coming up (November 21st) and he’s going to fill out his spreadsheet and say, “*I’m not on pace to get the progress that I had in my strategic plan for my happiness for next May… What are the things I need to actually touch up?*”
- Arthur is doing a curve fit to the complex problem he’s trying to solve with a little bit of a complicated solution
- He gives all those dimensions to his students and says, “*Look, do the reading. Do the work. I’ve read 10,000 articles about this, so you don’t have to.*”
- He tries to break it down a little bit, so that he can have a multidimensional problem

***One of the things that we know with complex problems is the more multidimensional you make it, the more likely you are to get better solutions***

- The worst thing that you can do is like, “*How do I feel today?*”
  - You’re not going to make progress under those circumstances

**What are some of the micronutrients that go into this for you?**

- Warmth of my marriage
- The relationship with my kids
- How well things are going with respect to the value I’m trying to create with my career
- Stability of friendships
- The degree to which Arthur feels like he’s properly philanthropic
- The interest he’s taking in his professional life
- The closeness he has with certain intimates in his life
- The extent to which he’s avoiding or finding conflict in his work relationships
- All these things go into Arthur’s spreadsheet, because he knows that they really matter across these 3 dimensions, the extent to which he’s enjoying my life over the course of each day

***He does these particular ratings, and then he puts them together with a weighted sum across them***

- He’s messed with a weighted sum and experimented with it until it seems about right with respect to what he’s experiencing

**You make it a multidimensional problem**

- There’s a huge body of social science (imperfect linear models) where you take big problems and make them into a bunch of little tiny problems, and that curve fits to the complex thing you’re trying to solve
- Peter notes that by evaluating this twice a year, you aren’t dependent on the technical noise of the day or the week

***You’re trying to answer these questions through the lens of the last half of the year***

- Arthur adds, “*If I’m having a big conflict with my wife on my birthday, I don’t do it that day… because I don’t want the noise.*”
  - And if something really great happens to him, he doesn’t answer it that day either, because he doesn’t want his neurochemistry to be affecting it unduly
- He’s been doing it for 25 years, and he’s pretty cold and calculating
- Peter thinks it would be a reasonable to make this into an app [as a starting point for people to do this for themselves]
- Arthur agrees that it could be, but it’s very different from biomarkers, because he doesn’t actually know what you would look at
  - What are the biomarkers? Cortisol, hormones?
- When Peter mentioned biomarkers, he didn’t mean blood-based biomarkers

***He meant anything either subjective or objectively measurable that would serve as a proxy for a dashboard of your happiness health***

- Arthur has that, but it’s imperfect

**Any plans to share that, to make that something others can use besides your students?**

- Arthur admits, “*I should do that*”
- He’d be very interested in experimenting on that (maybe with Peter’s clients) to see to what extent that could be a useful tool
- [Arthur added a tool to his website: [Take the Happiness Scale](https://learn.arthurbrooks.com/the-happiness-scale)
- Arthur’s book published in 2025 might also have some insights on this, [*The Happiness Files: Insights on Work and Life*](https://www.amazon.com/Happiness-Files-Insights-Arthur-Brooks/dp/B0F4MFQ6VN/ref=sr_1_1?crid=337W5LTFKV1ES&dib=eyJ2IjoiMSJ9.Km-5JDEyYLZXboVyOQksbQAzn0Lv3IhP3q19FQGHhTz9oC4tUaJlBMfnyaEZA209sx2S7HobIAEw8oD3bn405vkfENTaIOHluOBoKFYi4Ca3_Vx8254W5Ld23K78iLK3VOEd8SMazah8eH7zLHolh3QcqGeT7FmRdBk9zRhh-N7cwVKofSSe4JMrnUb9gXB0qBJDaHDayoM7-xtTtmFlZbh1CwmCDmktY0KFjOw9-v8.9vjSzOROTgm9H51moLlAWcQrXI0pjO2eMr3fQhlhhH8&dib_tag=se&keywords=arthur+brooks&qid=1765481498&s=books&sprefix=arthur+brooks%2Cstripbooks%2C107&sr=1-1)]

## The value of minimizing the self and looking outward [A: 1:30:45, V: 1:29:48]

**The idea of less self**

*Take away the mirrors*

- Peter finds this to be a very interesting discussion
- Some people will literally minimize the view of themself in a mirror, and then of course Arthur talks about broader versions of that, such as social media and things like that

*Do you think everybody would benefit from this?*

- [William James](https://en.wikipedia.org/wiki/William_James) talked about the I-self versus the me-self (you must have both)

**⇒** When you’re looking in the mirror, you’re 2 people: you’re the looker and the lookie

***And you need both, because you need to be able to look to understand what’s going on around you, but you need to have a reflection of yourself to understand who you are***

- I need to see, but I need to be seen by me so I can understand my context, so I can understand my place in the world
- You’ll get run over by a car if you don’t have the I-self
- Or you’ll have somebody kill you because you’ve offended them repeatedly because you don’t understand the me-self is the way that this works out

**The problem in our society is it’s all me-self, no I-self**

- Most people are not observing the world very much at all
- They’re being observed and they’re observing themselves
- They’re trying to be observed, and they’re observing themselves

*Social media is a classic case of this*

- Checking your notifications is nothing more than a me-self obsession, “*What are they saying about me? What impact am I having on other people?*”
- Why we do it: we’re evolved to want to understand where we are in the hierarchy
  - Social comparison, even envy, are evolved phenomena, because it helps keep us alive and make progress

***It’s misery when it takes over and when technology supercharges our ability to be in the me-self state***

There are moments when you can be really confused about the I-self and the me-self

- One time Arthur was really thinking deeply about something and was obsessed
- He was in the car with his daughter, and he filled up the car with the gas, took off from the gas station, lost in thought
- About a block later, he hears this weird ding, ding, ding, ding
- He thought, “*What’s going on? Somebody dragging a muffler*,” and he’s looking for somebody dragging a muffler
- Then he notices that cars are honking and pointing at him
- He stopped the car, and it turns out he hadn’t pulled the gas hose out of the car
  - The hose pulled out of the pump and was dragging it down the road
  - He went back to the gas station and found out how expensive it is to replace part of a gas pump (pretty bad)

***The whole point was he was the I-self and the me-sell all at once, and it was this weird disequilibrating experience***

**One of the ways to get much happier is to be more in the I-self and less than in me-self state is to minimize the reflection, is to think a lot less of what other people are thinking and to observe yourself a lot less**

*Different ways to do that*

In his book [[*Build the Life You Want*](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2)], Arthur talks about this guy he works with pretty closely: a fitness influencer and fitness model

- If you’re seeing your lower abs and you’re an adult, that means you’re never eating anything you like (ever), and you’re not getting enough enjoyment for your life, right?
- He was miserable for 10 years
- He didn’t eat what he liked; he always had headaches; he didn’t feel good
- He didn’t have normal relationships
- And so, he decided he had to make a change in his life
- He literally got rid of every mirror in his apartment and showered in the dark for a year, so he couldn’t see his own abs, and his life completely changed
  - Just on the basis of getting rid of those mirrors

**When people are miserable in Arthur’s classes, he says**

- 1 – Take the notifications off your social media (turn them off)
- 2 – Don’t look at your mentions (under any circumstances), don’t pay attention to that
- 3 – Literally start getting rid of some of your mirrors, your literal mirrors
- And what you’ll do is you’ll get into more of a state of looking outward

***The more you look outward, the happier you’ll be***

- The better off your life will be, when you’re walking around going, “*Man, that’s amazing.*”
  - You know what’s not amazing? Me.

## How Arthur surprised himself with his ability to improve his happiness [A: 1:34:45, V: 1:33:57]

**What surprised you the most when you set out to write [**[***Build the Life You Want***](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2)***]*****?**

- Peter points out that Arthur is writing a book on a topic that he’s studied for decades and written column after column weekly in [*The Atlantic*](https://www.theatlantic.com/projects/how-build-life/)
- He’s written other books that touch on similar themes [see the selected links section at the end of these nots]
- Peter has to believe that there’s something Arthur believes today that he absolutely didn’t before

***Arthur has changed his opinion about a lot of different things***

> “*The science has gotten clearer and my knowledge has gotten deeper.*”‒ Arthur Brooks

- Arthur wrote his first book about happiness in 2008 [[*Gross National Happiness*](https://www.amazon.com/Gross-National-Happiness-Arthur-Brooks/dp/0465002781/ref=sr_1_8?crid=2D2AUC9SPNWTF&keywords=arthur+brooks+books&qid=1698764137&sprefix=arthur+brooks+books%2Caps%2C91&sr=8-8)]
  - But it was like a book on astronomy
  - It was observing happiness from a distance: Who are the happy people, who are the unhappy people?

**Arthur realized, “*****It never really occurred to me that with the science I could change my own life, that I’m not a fundamentally happy person*****.”**

Mad scientists struggle because negative affect

- It gets your attention so much more strongly than positive affect does
- If you’re high positive and high negative, you’re going to feel on balance, pretty negative a lot

For years, Arthur always thought, “*Happiness is a really interesting thing, but it’s not my lot.”*

- Then, when he came back and started the new happiness projects, writing his [column](https://www.theatlantic.com/projects/how-build-life/) and the books he’s written in the past couple of years, he decided to see if that was true
  - To see the ways he could use this knowledge to change his habits and get happier
  - He doubted it and thought he couldn’t

***But Arthur actually did; he changed his life***

He’s usually 8-9 weeks out on his column in the Atlantic, because he’s trying the things that he’s suggesting

- He’s a lab rat, and he knows Peter does this too
  - You’re not going to suggest something to your clients that you don’t feel comfortable with
- Even as a human being, this is what he’s doing too
- And he’s taking constant updates
  - He takes the tests with his students on positive and negative affect and life satisfaction

**Arthur’s wellbeing has risen by 60% in the past four years**

- He explains, “*It was a pretty low base. It was a bad denominator. But it’s been dramatic, and I didn’t actually trust, I didn’t actually believe, but it’s actually true, and anybody can do this.*”
- Peter thinks this is a great message because Arthur hasn’t wrapped his identity up in being the happiest guy
  - He’s not faking it
- Peter explains when people see him eat a donut, they’re like “*What?*” and he tells them, “*Hey, read the* [*book*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=1MA1P4X1UMXAK&keywords=outlive&qid=1698768779&sprefix=outlive%2Caps%2C97&sr=8-1)*, man*.”
  - He didn’t say, “*Don’t eat a donut*.”
  - Don’t eat 10 a day

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Arthur Brooks**:

- [#280 ‒ Cultivating happiness, emotional self-management, and more | Arthur Brooks Ph.D.](https://peterattiamd.com/arthurbrooks2/) (November 27, 2023)
- [#226 ‒ The science of happiness | Arthur Brooks, Ph.D.](https://peterattiamd.com/arthurbrooks/) (October 10, 2022)

**Arthur’s column in** ***The Atlantic:*** [How to Build a Life](https://www.theatlantic.com/projects/how-build-life/) | [1:00, 1:12:45, 1:30:45]

**Books on happiness by Arthur Brooks**: [2:15]

- [The Meaning of Your Life: Finding Purpose in an Age of Emptiness](https://www.amazon.com/Meaning-Your-Life-Finding-Emptiness/dp/0593545427/ref=sr_1_5?crid=337W5LTFKV1ES&dib=eyJ2IjoiMSJ9.Km-5JDEyYLZXboVyOQksbQAzn0Lv3IhP3q19FQGHhTz9oC4tUaJlBMfnyaEZA209sx2S7HobIAEw8oD3bn405vkfENTaIOHluOBoKFYi4Ca3_Vx8254W5Ld23K78iLK3VOEd8SMazah8eH7zLHolh3QcqGeT7FmRdBk9zRhh-N7cwVKofSSe4JMrnUb9gXB0qBJDaHDayoM7-xtTtmFlZbh1CwmCDmktY0KFjOw9-v8.9vjSzOROTgm9H51moLlAWcQrXI0pjO2eMr3fQhlhhH8&dib_tag=se&keywords=arthur+brooks&qid=1765481498&s=books&sprefix=arthur+brooks%2Cstripbooks%2C107&sr=1-5) by Arthur Brooks (2026)
- [The Happiness Files: Insights on Work and Life](https://www.amazon.com/Happiness-Files-Insights-Arthur-Brooks/dp/B0F4MFQ6VN/ref=sr_1_1?crid=337W5LTFKV1ES&dib=eyJ2IjoiMSJ9.Km-5JDEyYLZXboVyOQksbQAzn0Lv3IhP3q19FQGHhTz9oC4tUaJlBMfnyaEZA209sx2S7HobIAEw8oD3bn405vkfENTaIOHluOBoKFYi4Ca3_Vx8254W5Ld23K78iLK3VOEd8SMazah8eH7zLHolh3QcqGeT7FmRdBk9zRhh-N7cwVKofSSe4JMrnUb9gXB0qBJDaHDayoM7-xtTtmFlZbh1CwmCDmktY0KFjOw9-v8.9vjSzOROTgm9H51moLlAWcQrXI0pjO2eMr3fQhlhhH8&dib_tag=se&keywords=arthur+brooks&qid=1765481498&s=books&sprefix=arthur+brooks%2Cstripbooks%2C107&sr=1-1) by Arthur C. Brooks (2025)
- [Build the Life You Want: The Art and Science of Getting Happier](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2) by Arthur Brooks and Oprah Winfrey (2023)
- [From Strength to Strength: Finding Success, Happiness, and Deep Purpose in the Second Half of Life](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Arthur C. Brooks (2022)
- [Gross National Happiness: Why Happiness Matters for America–and How We Can Get More of It by](https://www.amazon.com/Gross-National-Happiness-Arthur-Brooks/dp/0465002781/ref=sr_1_8?crid=2D2AUC9SPNWTF&keywords=arthur+brooks+books&qid=1698764137&sprefix=arthur+brooks+books%2Caps%2C91&sr=8-8) Arthur Brooks (2008)

**Book about the neurocognitive process that occurs when you feel awe**: [Awe: The New Science of Everyday Wonder and How It Can Transform Your Life by Dacher Keltner](https://www.amazon.com/Awe-Science-Everyday-Wonder-Transform/dp/1984879685/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2023) | [43:45]

**Arthur wrote in** ***The Atlantic*** **about happiness and success**: [49:15]

- [What the Second-Happiest People Get Right by Arthur Brooks](https://www.theatlantic.com/family/archive/2022/03/chasing-happiness-leads-to-dissatisfaction/629427/) | *The Atlantic* (March 31, 2022)
- [Why Success Can Feel So Bitter](https://www.theatlantic.com/family/archive/2022/02/reaching-goals-doesnt-always-lead-to-happiness/622894/) by Arthur Brooks | *The Atlantic* (February 24, 2022)

**Tool to track your happiness**: [Take the Happiness Scale](https://learn.arthurbrooks.com/the-happiness-scale) | [ArthurBrooks.com](http://arthurbrooks.com) | [1:30:30]

---

## People Mentioned

- [Aristotle](https://en.wikipedia.org/wiki/Aristotle)
- [Thomas Aquinas](https://en.wikipedia.org/wiki/Thomas_Aquinas)

---

![](https://peterattiamd.com/wp-content/uploads/2022/10/bio-image-arthurbrooks.jpg)

##### Arthur Brooks Ph.D.

Arthur C. Brooks is the William Henry Bloomberg Professor of the Practice of Public Leadership at Harvard Kennedy School and Professor of Management Practice at Harvard Business School. Before joining the Harvard faculty in July of 2019, he served for ten years as president of the American Enterprise Institute (AEI), a public policy think tank in Washington, DC.

Brooks is the author of 12 books, including the national bestsellers: [*Build the Life You Want: The Art and Science of Getting Happier*](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2) (2023), [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2022), [*Love Your Enemies*](https://www.amazon.com/Love-Your-Enemies-America-Contempt/dp/0062883755/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2019), [*The Conservative Heart*](https://www.amazon.com/Conservative-Heart-Happier-Prosperous-America/dp/0062319752/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2015), and [*The Road to Freedom*](https://www.amazon.com/Road-Freedom-Fight-Free-Enterprise/dp/046502940X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (2012). He is a columnist for The Atlantic, host of the podcast [*How to Build a Happy Life*](https://www.theatlantic.com/podcasts/how-to-build-a-happy-life/), and subject of the 2019 documentary film [*The Pursuit*](https://arthurbrooks.com/the-pursuit/). He serves on the board of the Legatum Institute, a think tank in London.

Brooks began his career as a classical French hornist, leaving college at 19, touring and recording with the Annapolis Brass Quintet and later, the City Orchestra of Barcelona. In his late twenties, while still performing, he returned to school, earning a BA through distance learning at Thomas Edison State College, and then an MA in economics from Florida Atlantic University. At 31, he left music and earned an MPhil and PhD in public policy analysis from the Rand Graduate School, during which time he worked as an analyst for the Rand Corporation’s Project Air Force.

Brooks then spent 10 years as a university professor, becoming a full professor at Syracuse University’s Maxwell School of Citizenship and Public Affairs in his seventh year out of graduate school and occupying the Louis A. Bantle Chair in Business and Government. During this decade, Brooks published 60 peer-reviewed articles and several books, including the textbook *Social Entrepreneurship* (2008). [[Harvard Business School](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664)]

Instagram: [arthurcbrooks](https://www.instagram.com/arthurcbrooks/?hl=en)

Website: [arthurbrooks.com](https://arthurbrooks.com/)

X (formerly twitter): [@arthurbrooks](https://twitter.com/arthurbrooks)