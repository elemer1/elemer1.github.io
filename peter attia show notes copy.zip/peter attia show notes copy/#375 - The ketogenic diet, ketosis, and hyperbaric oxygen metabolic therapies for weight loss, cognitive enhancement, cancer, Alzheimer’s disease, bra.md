# #375 – The ketogenic diet, ketosis, and hyperbaric oxygen: metabolic therapies for weight loss, cognitive enhancement, cancer, Alzheimer’s disease, brain injuries, and more | Dominic D’Agostino, Ph.D.

**Source:** [https://peterattiamd.com/domdagostino2/](https://peterattiamd.com/domdagostino2/)

---

Dom D’Agostino is a neuroscientist and professor at the forefront of metabolic therapies, including ketogenic diets, exogenous ketones, and hyperbaric oxygen. In this episode, Dom breaks down nutritional versus supplemental ketosis, defines meaningful ketone thresholds, and outlines practical ways to achieve ketosis. He explains how a ketogenic diet can support metabolic health and weight loss, and advises on how to maintain adequate protein and avoid common mistakes. Dom surveys the growing landscape of exogenous ketones—from salts and esters to 1,3-butanediol—and effective pairings like caffeine, MCT oil, and alpha-GPC. He highlights the role of ketogenic therapy in cancer (particularly glioblastoma) and its promise for neurodegenerative diseases. The conversation also covers recommended hyperbaric oxygen protocols for brain injuries and cognitive function, situations where fasting or ketones offer cognitive and anti-inflammatory benefits, and touches on the carnivore diet as a ketogenic variant with potential relevance for autoimmune and metabolic conditions.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/domdagostino2/the_Drive_public.png)

Play

#375 - Ketogenic diet, ketosis & hyperbaric oxygen: metabolic therapies for weight loss, cognition, Alzheimer's & more | Dom D'Agostino, Ph.D.

#375 - Ketogenic diet, ketosis & hyperbaric oxygen: metabolic therapies for weight loss, cognition, Alzheimer's & more | Dom D'Agostino, Ph.D.

1x15s30s

0:002:08:25

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Dom and Peter’s shared interest in ketosis, and Dom’s scientific journey [A: 2:30, V: 0:11];
- Dom’s work for the Navy on oxygen toxicity [A: 7:00, V: 5:40];
- Nutritional ketosis defined: physiology, biomarkers, and how fasting and diet generate therapeutic ketones [A: 15:00, V: 14:20];
- The historical roots of ketogenic diets in epilepsy treatment, and evidence showing ketones reduce seizure activity and strengthen brain resilience [A: 19:00, V: 18:58];
- Dom’s personal experience on the ketogenic diet: tracking macros, getting enough protein, and monitoring ketone levels [A: 24:15, V: 25:08];
- Using a ketogenic diet for weight loss: Dom’s guidance on protein, fiber, calorie tracking, lipid monitoring, and more [A: 31:00, V: 33:05];
- Protein on ketogenic diets: Dom’s rationale for higher intake and muscle preservation [A: 38:00, V: 41:02];
- Incorporating carbohydrates into keto: timing, high-fiber foods, and other considerations [A: 41:30, V: 44:56];
- The carnivore diet: whether carnivore eating induces ketosis, how it functions metabolically, and why it may help individuals with autoimmune conditions [A: 44:15, V: 48:21];
- Early exogenous ketones: how 1,3-butanediol works, its liver toxicity risk, and why ketone esters replaced it [A: 48:15, V: 53:10];
- The progression of exogenous ketones: why BHB monoesters and ketone salts emerged as better alternatives to 1,3-butanediol for ketone supplementation [A: 59:30, V: 1:06:31];
- Ketone salts: easing the transition into ketosis, dosing, and how they compare to ketone esters [A: 1:04:00, V: 1:11:46];
- The differences between D- and L-β-hydroxybutyrate, and how racemic mixtures may elevate ketones longer and offer unique biological effects [A: 1:09:30, V: 1:18:06];
- How ketosis may boost NAD, and why NAD supplements have fallen short so far [A: 1:16:30, V: 1:25:54];
- Emerging evidence for using a ketogenic diet to treat anorexia and other psychiatric disorders [A: 1:20:30, V: 1:30:34];
- Potential cognitive and performance benefits of ketone supplementation, and why pushing ketones too high can be dangerous [A: 1:23:45, V: 1:34:18];
- Applications for ketone esters, and why ketone salts or MCT-blended formulations may be safer and more practical for most people [A: 1:29:15, V: 1:40:25];
- The role of a ketogenic diet in treating cancer [A: 1:34:45, V: 1:46:37];
- The potential of a ketogenic diet for treating Alzheimer’s disease [A: 1:45:45, V: 1:59:31];
- Tools for cognitive enhancement: ketones, alpha-GPC, MCT, caffeine, strategic fasting, and more [A: 1:53:45, V: 2:09:45];
- Hyperbaric oxygen therapy for concussion, TBI, PTSD, and cognitive function, including protocols and dosing approaches [A: 1:55:30, V: 2:11:26];
- Peter’s takeaways, recommended products, and additional resources to learn more [A: 2:03:00, V: 2:20:30]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dom D’Agostino is a neuroscientist and professor at the forefront of metabolic therapies, including ketogenic strategies, exogenous ketones, and hyperbaric oxygen

In this episode, we discuss:

- Nutritional versus supplemental ketosis: clear definitions and thresholds for clinical ketosis
- Practical ways to achieve ketosis while keeping protein intake adequate
- Why the early transition into a ketogenic diet can be challenging and how electrolytes and ketone salts can smooth that on ramp
- The growing landscape of exogenous ketones
  - The salts versus the esters
  - 1,3-butanediol
  - Taste and insulin effects
  - Simple effective pairings, such as caffeine, MCT, and alpha-GPC
- Ketogenic diets as metabolic therapy for cancer, especially glioblastoma
- The prospects for ketogenic diets in neurodegenerative diseases, including dementia and Alzheimer’s disease
- Hyperbaric oxygen chambers ‒ Dom’s recommended protocols, practical barriers, and the rigor of ongoing trials
- When fasting and ketones shine as a situational tool for cognition work load, travel, inflammation
- The carnivore diet as a ketogenic variant ‒ what it implies for certain autoimmune and metabolic conditions

## Dom and Peter’s shared interest in ketosis, and Dom’s scientific journey [A: 2:30, V: 0:11]

- It’s been a long time since Peter has seen Dom in person
- Dom sees Peter’s brother ([Paul](https://www.ryanleak.com/paulattia)) a lot more
  - Paul’s an amazing entrepreneurial mentor and a life mentor
- Dom has been on this podcast a couple of times
  - [Episodes [#05](https://peterattiamd.com/domdagostino/), [#116](https://peterattiamd.com/domdagostinoama01/), and [#120](https://peterattiamd.com/domdagostinoama02/)]
- We’ve probably got hundreds of thousands of listeners today that weren’t listeners the first and second time he was on the podcast
- And for those that were, it would be understandable that they’ve forgotten most of what we’ve spoken about

**Just by way of background, Peter explains how he and Dom are connected**

- [Ken Ford](https://uwf.edu/intelligent-systems-and-robotics/faculty/ihmc-research-scientists/dr-kenneth-m-ford.html) connected them back in 2011-ish
- At the time, Peter was about a year into experimenting with a ketogenic diet
  - Having all sorts of interesting success with it for the most part ‒ once he got over the hump of figuring out how to do it
- We must have connected at his institute, and then the rest is kind of history
- We then, through our friendship became very deeply involved in the testing of the earliest generations of various forms of **synthetic ketones**
  - A topic we will undoubtedly get to today because it’s impossible to imagine how much proliferation there has been of these things that were

**How Dom’s interest in this space came to be**

- Peter recalls that Dom’s Ph.D. was in neuroscience
- Yeah, nutrition
- He started doing an undergraduate thesis project in neuroscience and the neural control of autonomic regulation
  - Specifically the brain network, the [rostral ventrolateral medulla](https://en.wikipedia.org/wiki/Rostral_ventrolateral_medulla)
  - This is the brain stem network that controls respiration ‒ inspiratory neurons, expiratory neurons, and how they respond to oxygen and CO2
- And that led him down the path of oxygen, hypoxia, hyperoxia, hypercapnia, extreme environments
  - What happens to the brain under oxygen deprivation and nutrient deprivation
- At the time, he was interested in [alpha-L-Polylactate](https://trademarks.justia.com/787/23/alpha-l-78723540.html) because it was in [Cytomax](https://www.allstarhealth.com/de_p/224/Cytosport_Cytomax.htm?srsltid=AfmBOoobVWUlmj1CQUdiDiOI7xRerfkFUvW2jjcdNBNuxXdNceJcVres), which was something he used because he raced mountain bikes
- Dom was testing some things lactate, and then he got steered onto the ketogenic diet after getting a postdoctoral fellowship by the Office of Navy Research
  - Which is part of the Department of Defense to understand the cellular and molecular mechanisms of central nervous system oxygen toxicity, which manifests as seizures

***Dom was mostly interested in drugs, but then he pivoted and went back to the ketogenic diet because it works for so many different seizure disorders when drugs fail***

- He was gravitating towards a tenure track position, and everybody told him this was the dumbest thing to do
  - You can’t get NIH funding with ketogenic, nobody had heard of the ketogenic diet
  - This was around 2005
- Dom started tinkering with ketones
- In 2007 he started writing grants, and in 2008 he got a postdoctoral grant
  - It was very sizable ‒ like a NIH-level grant and it paid full indirects
  - That came from the Office of Navy Research (part of the Department of Defense)
- His position went from postdoc to something called a Research Assistant Professor
  - Which is like an intermediate position before you get into tenure track
  - The university was gauging his productivity
- Dom got good data on hyperbaric atomic force microscopy, very mechanistic research
- He also did patch clamp electrophysiology and confocal microscopy

***His work was really focused on redox mechanisms and looking at superoxide production under graded levels of oxygen and different metabolites***

- In the process of doing all that, he had no interest in cancer, but he had some [glioblastoma](https://en.wikipedia.org/wiki/Glioblastoma) cells and he threw them into the hyperbaric chamber
  - And under confocal microscopy, he could see the mitochondria were lighting up and then kind of exploding or disappearing in the cancer cells
- That was kind of unique, and that led him on a side tangent thing to study cancer
- But the central thing that he studied was neuroscience
  - He’s been in the neuroscience department and mainly focused on that

## Dom’s work for the Navy on oxygen toxicity [A: 7:00, V: 5:40]

**The problem with too much oxygen and Dom’s work for the Navy**

- Folks might not understand why the navy would be interested in the effects of too much oxygen
- When you think of the navy, you think of being underwater
  - When you think of being underwater, you think of oxygen deprivation

*What is it about certain types of diving that actually bring about the opposite problem?*

- You experience that with hyperbaric oxygen therapy, and there’s [14 different FDA approved applications](https://www.fda.gov/consumers/consumer-updates/hyperbaric-oxygen-therapy-get-facts)
- In that context, you only go to about a maximum of 2.5 to 3.0 atmospheres of pure oxygen
- In the context of military diving, like a Navy SEAL use a closed circuit rebreather because there’s no bubbles
  - So there’s a stealth component to that
  - You’re breathing high concentrations of oxygen, and at 50 feet of seawater, the potential for [oxygen toxicity exists](https://en.wikipedia.org/wiki/Oxygen_toxicity)

**Explain what oxygen toxicity is**

*How does a rebreather work?*

*What is the concentration of oxygen they’re breathing in?*

- A closed circuit rebreather, for example, like a [Drӓger rebreather](https://en.wikipedia.org/wiki/Dr%C3%A4ger_(company)#Diving_equipment), those early rebreathers and even now it’s high concentration

***You’re breathing 100% oxygen, so there’s no nitrogen***

- There’s 80% nitrogen in the air we’re right now
- There’s no nitrogen [in a rebreather] so you avert the potential for [nitrogen narcosis](https://en.wikipedia.org/wiki/Nitrogen_narcosis)
  - So nitrogen is not narcotic at one atmosphere, but you get something called the [Martini effect](https://en.wikipedia.org/wiki/Nitrogen_narcosis#)
  - As you go down lower, nitrogen becomes narcotic (that’s something else that Dom studies)
- You’re breathing 100% oxygen, and then there’s a CO2 scrubber
  - So you’re blowing out the exhaled carbon dioxide is scrubbed out from the breather
  - And it’s a closed circuit, so there is no off gassing associated with scuba diving or even other types of technical diving where you have some off gassing
- Peter adds the reason they can do that is because you’re not wasting gas on the 80% nitrogen
  - You basically store the CO2 that’s coming out
  - Once you’ve scrubbed it, you’ve got pure O2 coming in
  - So your volume of air needed is much lower because you’re just solving for the oxygen
- Dom explains that the oxygen tanks are pretty small [that are used] with a rebreather

**Analogy to understand why the Navy uses a rebreather**

- Dom has a couple ponds on his property
- When he sees bubbles coming across the pond, he knows an alligator is coming towards him
  - When Peter’s brother was visiting, they were looking at the alligators and getting them to come by throwing pebbles (they come when they hear something)
- If he goes to the pond with a weed wacker, he sees bubbles coming across
- The analogous situation would be a Navy SEAL coming across a body of water, that still you can clearly see the bubble trail coming to you

***With a closed circuit rebreather, that completely averts the bubble trail and the noise that the bubbles make***

**The problem with a rebreather**

- If you’re were closer and you dive down to 100 feet of seawater
  - Because someone starts shooting at you, or you have to go down deep to put a mine on the bottom of a bridge or something like that
- You’re going to have a seizure within 5 minutes

**⇒** Oxygen is a stimulant: it stimulates a massive amount of [glutamate](https://en.wikipedia.org/wiki/Glutamic_acid#Neurotransmitter) release that activates [AMPA receptors](https://en.wikipedia.org/wiki/AMPA_receptor), [NMDA receptors](https://en.wikipedia.org/wiki/NMDA_receptor)

- In a way, it stimulates the neural network
- It also sort of deactivates or inhibits an enzyme [glutamic acid decarboxylase](https://en.wikipedia.org/wiki/Glutamate_decarboxylase), which converts more glutamate to [GABA](https://en.wikipedia.org/wiki/GABA)
- And there’s a big burst in [reactive oxygen species](https://en.wikipedia.org/wiki/Reactive_oxygen_species)
- So you have a constellation of things going on in your brain

***Dom studies the negative effects of high oxygen***

- Which kind of has some people who study hyperbaric oxygen a little bit standoffish towards him
- But in the context of lower oxygen, hyperbaric oxygen therapy can be very therapeutic
  - Peter wants to come back to this topic, but first he wants to finish this particular application

**⇒** The problems with closed circuit rebreathers with 100% oxygen are dramatic: if you have a seizure at 100 feet, you’re going to die pretty quickly

**When did the Navy realize this, and was this a relatively recent discovery?**

- No, it’s not
- Dom’s mentor, [Dr. Jay Dean](https://health.usf.edu/medicine/mpp/faculty/jaydean), his lab was like a museum with lots of historic pictures
- [Paul Bert](https://en.wikipedia.org/wiki/Paul_Bert) was a French physiologist who wrote a book
  - He did a lot of seminal studies well over 100 years ago in the 1800s showing that you could give animals [caisson’s disease](https://en.wikipedia.org/wiki/Decompression_sickness) under high pressure oxygen or high atmospheric effects

**⇒** About 150 years ago, we realized that oxygen was a stimulant

- We didn’t know why
- And then with military diving, then you have the problem of averting oxygen seizures
- There’s a number of people in the Navy [who worked on this problem], and they established the dive tables for preventing oxygen toxicity seizures, nitrogen narcosis, high pressure nervous syndrome
  - [Frank Butler](https://news.usuhs.edu/2025/01/dr-frank-butler-receives-presidential.html) comes to mind
  - [Claude Piantadosi](https://medicine.duke.edu/profile/claude-anthony-piantadosi), [Richard Moon](https://medicine.duke.edu/profile/richard-edward-moon) ‒ there’s a network at Duke University which did a lot of the seminal studies
- There are all things that you have to avert when you’re diving, depending on what kind of diving you’re doing

**The navy came to Dom because he had specialized knowledge and wrote grants to delve into oxygen toxicity seizures**

- 1 – It’s unknown why these seizures occur
- 2 – It gives us a lot of insight into the brain to understand it from a redox effect, from a neuropharmacology effect
- These grants were called “*Investigating the cellular and molecular mechanisms of CNS oxygen toxicity*”
- Unlike the NIH, Dom got a lot of expensive tools to play with through this grant from the navy (chambers, microscopes, electrophysiology equipment)
- This allowed Dom to tinker in the lab and in that process he made some serendipitous discoveries
  - With cancer
  - With fundamental effects that happen in cells under high pressure with different gasses (oxygen, nitrogen, helium)
- The Office of Navy Research has a 6.1 program, and that’s basic science
  - And then 6.2, 6.3.
- As Dom progressed in his career, he started working up from a cell-based system to animal models
  - Then it went to a pig model system
- Now essentially, we’re doing the rat studies at Duke with human subjects that get inside a chamber
  - We get diaphragmatic, we get EEG, we have a line going into their arm that goes to a mass spec to get blood gases to do a metabolomics
  - They’re working a flight simulator
  - They’re exercising, it’s water out immersion: so their body’s underwater, but you get the [hypovolemic effect](https://en.wikipedia.org/wiki/Hypovolemia) of the fluid shift and things like that to simulate that dive
  - And then we push them to a seizure
    - Believe it or not, this got approved through an IRB, which is even more amazing than the [Cahill study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC292907/)
  - But we pushed them to an EEG seizure to where we can see the seizure, and then we decompress
- We look at latency to seizure under dietary ketosis or supplemental ketosis or the combination
  - Dom is a co-investigator on it because it’s being done at Duke
  - They’re registered clinical trials on [clinicaltrial.gov](http://clinicaltrial.gov) [[ID NCT05801120](https://clinicaltrials.gov/study/NCT05801120), [ID NCT05831228](https://clinicaltrials.gov/study/NCT05831228), [ID NCT03433261](https://clinicaltrials.gov/study/NCT03433261) in collaboration with [Bruce James Derrick](https://medschool.duke.edu/profile/bruce-james-derrick) at Duke ]
  - These are funded by the Department of Defense has Office of Navy Research (ONR)
  - They have the CDMRP (Congressionally Directed Medical Research Program) and also NAVSEA
  - This is an ONR project that got spun into a NAVSEA project (Naval Sea Command Project) ‒ NAVSEA is more human studies and an ONR is basic science and then some human research
  - [Recent publications: [Therapeutic ketosis with ketone ester delays central nervous system oxygen toxicity seizures in rats](https://pubmed.ncbi.nlm.nih.gov/23552496/) and [Exogenous ketone ester delays CNS oxygen toxicity without impairing cognitive and motor performance in male Sprague-Dawley rats](https://pubmed.ncbi.nlm.nih.gov/34132115/)]

## Nutritional ketosis defined: physiology, biomarkers, and how fasting and diet generate therapeutic ketones [A: 15:00, V: 14:20]

- Dom used the term nutritional ketosis
- He also talked about supplemental ketosis, sometimes referred to as exogenous ketones

**Let’s start with nutritional ketosis and just give people some definitions of how you achieve it, how much variability there can be in a diet to get there, what the thresholds are, and a little bit about what’s happening physiologically**

- Dom directs people to Peter’s early [blogs on nutritional ketosis](https://peterattiamd.com/category/ketosis/) [see more in the “selected links” section at the end of these notes]
  - There’s a blog on [ΔG](https://peterattiamd.com/ketosis-advantaged-or-misunderstood-state-part-ii/), one on [exogenous ketones](https://peterattiamd.com/experience-exogenous-ketones-2/)
- Dom’s study used ketone electrolyte salts (D/L-BHB), which increase your efficiency of oxygen utilization

*Take a little bit of a step back to explain nutritional ketosis*

- Dom likes to start with **fasting**
- When you stop eating, you suppress the hormone insulin, you mobilize fatty acids for fuel
- The brain can’t use the long chain fatty acids that are stored in your adipose tissue
- So through [beta oxidation](https://en.wikipedia.org/wiki/Beta_oxidation) of fatty acids in the liver, accelerated beta oxidation in the context of insulin suppression generates these molecules ([ꞵ-hydroxybutyrate](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid) and [acetoacetate](https://en.wikipedia.org/wiki/Acetoacetic_acid) [aka ketone bodies]), and then they spill into circulation
- Ketone bodies become largely responsible for preserving brain energy metabolism in the context of energy deprivation or carbohydrate restriction

**⇒** The elevation of ꞵ-hydroxybutyrate or acetoacetate in the blood, in the urine or the breath becomes a biomarker for ketosis

- You can achieve ketosis through fasting, through diet, through supplements, alcoholic ketoacidosis, or diabetic ketoacidosis
- Then you have **nutritional ketosis**, which is eating carbohydrate-restricted ketogenic diet that’s primarily high in fat
  - The original diet was 90% fat
  - Modified versions of the diet are about 60-70% fat with higher protein
- Now, we know, especially in kids who restrict protein too much, you could stunt their growth and have developmental issues there
  - So clinically, a modified version of the ketogenic diet is actually being gravitated more towards even in pediatric epilepsy
  - We’re learning that protein is really important, and it was underappreciated in the early pediatric ketogenic diets
  - In the context of sports, protein is extremely important
- The ketogenic diet is the most scientifically researched diet that is defined by the objective biomarker (ketones) that defines the physiological state

**⇒** **Biomarker for clinical ketosis** is when β-hydroxybutyrate is above 0.5 mmol/L

**In the context of ketosis, there are remarkable changes in our metabolic physiology and the neuropharmacology of our brain**

- β-hydroxybutyrate has unique [epigenetic](https://en.wikipedia.org/wiki/Epigenetics) effects that are [pleiotropic](https://en.wikipedia.org/wiki/Pleiotropy)
  - Dom’s student just finished a project on that

*Tell folks what that means*

- Pleiotropic is a fancy, somewhat nebulous word that means there are multiple mechanisms that are activated biochemically, physiologically, and neuro-pharmacologically, that have beneficial effects
- An explosion of research has occurred on ketogenic diets (and supplements) this in PubMed and clinicaltrials.gov (ongoing trials)

**Take a step back to talk about the ketogenic diet**

- Some people say it does nothing magical in the context of body composition, alterations, or fat loss (there’s truth to that)

Dom adds, “*I say there’s a hard stop there… The ketogenic diet is indeed a magical diet in the way that it remarkably changes our physiology.*”

- No other diet exists that can manage drug-resistant seizures (for example)

***A ketogenic diet can manage drug-resistant seizures because it profoundly changes our fuel system, our physiology, our biochemistry, and our neuropharmacology***

## The historical roots of ketogenic diets in epilepsy treatment, and evidence showing ketones reduce seizure activity and strengthen brain resilience [A: 19:00, V: 18:58]

- A ketogenic diet is used to treat [epilepsy](https://en.wikipedia.org/wiki/Epilepsy) ‒ this was first identified in adults in the 1920s, because there were no drugs for epilepsy

*What gave them the idea to try this diet?*

- They had [EEGs](https://en.wikipedia.org/wiki/Electroencephalography) back then but they didn’t know much
- They did some really good physiology in the 1930s, ‘40s that is underappreciated
- The first observation was that fasting controlled seizures
  - The Gospel of Mark talks about fasting; it’s all over in the literature
- With a ketogenic diet, ketone bodies are elevated in the blood, urine, and even in the breath
- They understood that these ketone bodies were somehow associated with seizure control (and we did not have anti-seizure drugs back then)
- [Banting and Best](https://en.wikipedia.org/wiki/Insulin#Extraction_and_purification) isolated insulin in the 1920s ‒ in Peter’s mind, that was the golden era of metabolism

*When were ketones first isolated (*[*BHB*](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid) *specifically)?*

- Within a decade around that time; it was discovered in the context of [diabetic ketoacidosis](https://en.wikipedia.org/wiki/Diabetic_ketoacidosis)
- Then work at the Mayo Clinic by [Wilder](https://en.wikipedia.org/wiki/Russell_Morse_Wilder) and a few other people were helping establish the framework for what would be ultimately the first ketogenic diet therapies
  - It was just eating all fat
- Then we realized the need to titrate in the protein to prevent protein malnutrition
- The first clinical report of a ketogenic diet used to treat epilepsy was a side note in a clinical journal in 1921
  - They reported remarkable effects
  - At the time, we didn’t have anything [to treat seizures]

***They didn’t understand mechanistically, why a*** [***ketogenic diet***](https://en.wikipedia.org/wiki/Ketogenic_diet#) ***reduced seizures ‒ we still don’t fully understand all the mechanisms involved***

- That’s why it’s such a fruitful, robust area of research right now
  - With drug companies scrambling to mimic the effects of a ketogenic diet (it’d be a blockbuster drug)
- Peter’s recollection: if you took 100 patients who have drug-resistant seizures (so nonstop seizures despite all the best available pharmacology), a ketogenic diet will completely cure a third of them

**Will a ketogenic diet cause about 50% reduction in seizure activity for another third of them, while one third of them will still be unresponsive ‒ is that correct?**

- In the context of pediatric epilepsy, about ⅔ of patients will be therapeutically responsive to a ketogenic diet for managing seizures

**⇒** A ketogenic diet is highly efficacious for managing seizures

- ⅔ of people who have failed drug therapy (with multiple drugs) [will benefit from a ketogenic diet]

*What about adults?*

- Post adolescence, 30-40% of patients benefit from a ketogenic diet
- But then it’s thought that compliance with a ketogenic diet is lower than with kids (whose parents feed them a ketogenic formula and calculate it out)
- There’s something about the pediatric brain that’s probably more responsive

***Of the ⅔ that respond, ⅓ have complete seizure control (95-100% control); and 10-15% are super responders***

- Super responders: they go on a ketogenic diet for a year or 2, then transition off and never get seizures again

> “*They talked about the ketogenic diet being curative, and that was really interesting to me.*”‒ Dom D’Agostino

- The brain is changing as you go through development
  - Shifting brain networks and network stability
  - Suppressing inflammation
  - Changing neurotransmitters in a way that there’s the kindling effect with seizures
- Seizures beget seizures
  - Once you have a seizure, you’re more likely to have another seizure
- So if you control seizures and you do it through a protracted timeframe, that’s going to decrease that kindling effect (lessen the chance that you’ll have another seizure)
- Dom has replicated that, just throwing sodium D/L-ꞵ-hydroxybutyrate into a hippocampal brain slice preparation under different levels of things that stimulate seizures (and measuring seizures in a slice)
  - In the [orthodromic](https://en.wikipedia.org/wiki/Orthodromic) population, you can stimulate and measure the orthodromic population spike of the neurons firing back, and then you can decrease the amplitude of that over time and essentially silence seizures in a slice
  - And at the same time, you’re making that hippocampal brain slice more metabolically resilient ‒ you could throw different agents at it that would be neurodegenerative or hyper excitable, and it will protect it
- This really interested Dom, and he was completely unaware of this literature in his postdoc
- And when he started delving into it, it changed the trajectory of his career

**Dom’s innovative approach**

- He wanted to study the ketogenic diet in parallel or in tandem with exogenous ketones
- He wanted to know what was the most efficacious form of exogenous ketones we can use and how can it augment the therapeutic efficacy of a ketogenic diet
- Nobody was looking at this at the time

## Dom’s personal experience on the ketogenic diet: tracking macros, getting enough protein, and monitoring ketone levels [A: 24:15, V: 25:08]

**You’ve obviously experimented a lot with a ketogenic diet yourself. When did you first try a ketogenic diet?**

- In 2009 he started actually checking ketones [he’s been on a ketone diet for the last 16 years]
  - The little [CardioChek](https://mms.mckesson.com/product/500350/PTS-Diagnostics-1708) meter was super expensive at the time, and it did your HDL and triglycerides and things
  - Peter was using the Abbott one, [Precision Xtra](https://abbottstore.com/diabetes-management/precision-brand/precision-brand/precision-xtra-blood-glucose-ketone-monitoring-system-1-pack-9881465.html?srsltid=AfmBOoqJx61EBEuntdn-gx5lxdfpfKmG5LCnZpiTWoaD4rgrldr7thiu)
  - Dom also had a lab assay (ELISA) he was comparing it to; then he got the Precision Xtra by Abbott
- Back then the strips were $5-10 each, and Peter was going through 3 a day
  - That price point has come down
- Now we have the [Keto Mojo](https://shop.keto-mojo.com/)
  - It aligns more with Dom’s assays
  - It does the glucose ketone index [the ratio of glucose to ketones in the blood; he’ll come back to this is later)
- Dom rapidly lost 10-15 lbs. within 5 years of starting the ketone diet
- But his exercise and lifts tanked too
  - He lost strength on the benchpress, not so much with the deadlift and squat

**Dom learned a lot of lessons**

1 – Protein is really important

- He was thinking that ketones would save muscle as they have an anticatabolic effect

***But if your protein goes from 250 g/day to 70-80 g/day, you’re going to lose a lot of muscle***

- Just don’t tell the RDA that, they still want you to believe that 0.8g/kg is all you need
- It’s very context dependent
- Dom was in the gym and even training with [Layne](https://biolayne.com/about/?_gl=1*12qp8mc*_up*MQ..*_ga*MTM2MTU4NzcyMS4xNzU2Mzg2ODk2*_ga_ML9WRT2ESX*czE3NTYzODY4OTUkbzEkZzAkdDE3NTYzODY4OTUkajYwJGwwJGgw) at the time
- They’re avoiding research with [Donald Layman](https://fshn.illinois.edu/directory/dlayman), [Stu Phillips](https://mira.mcmaster.ca/our-faculty/stuart-phillips/)
  - Donald Layman was on the podcast in [episode #224](https://peterattiamd.com/donlayman/)
- You need to titrate protein intake to meet your needs
  - If you’re an athlete, if you have a high metabolic rate, if you’re trying to gain muscle ‒ you have to leverage protein (that becomes the key factor)

2 – A clinical ketogenic diet skyrockets his [LDL](https://en.wikipedia.org/wiki/Low-density_lipoprotein) and [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B#Clinical_significance)

- Pharmacologically, he has a mutation in [NPC1L1](https://en.wikipedia.org/wiki/NPC1L1), so a tiny dose of [etzetimibe](https://en.wikipedia.org/wiki/Ezetimibe) brings that down

**What do you think are the most common mistakes people make when they’re trying to enter nutritional ketosis?**

1 – Not tracking their ketones

- People think, “*Oh, I’m just going to eat this or that and not track*.”
- Use a good tracking metric ‒ [Carbon app](https://www.joincarbon.com/) is great
  - You don’t have to do it every day, day in and day out

***You want to use a tracking app to be able to correlate blood levels of ketones with what you’re eating***

- You can track blood ketone levels
- You can track ketones in your urine and breath too

2 – You also want to track the macronutrient ratios and composition, and total amount of calories

- When Dom got into this, everybody said, “*If you do a ketogenic diet, you don’t have to track calories. Calories don’t matter*.” ‒ that’s BS
  - There are some people out there who can overeat on a ketogenic diet
  - You could polish off a bag of macadamia nuts or sour cream or heavy cream or what ever

**What is the state of the art on urine and breath meters these days?**

- With the breath meter, breath acetone correlated with seizure control
- The [Biosense](https://mybiosense.com/order.html) device has fallen out of favor
- The [KetoAir](https://ketoair.us/) is pretty good [shown below]
  - It’s the size of a pen
  - It correlates really well with some of the blood ketone measurements

![](https://peterattiamd.com/wp-content/uploads/2025/12/f1-DD.png)

**Figure 1. The KetoAir is a breath meter for the ketone acetone**. Image credit: [KetoAir](https://ketoair.us/)

**⇒** Dom notices that if he’s in a calorie deficit, his blood ketones can be very low, but his breath ketones are high

Dom adds, “*I think your ketone production that you’re measuring is a consequence of ketone production and ketone utilization.*”

- In the context of an energy deficit, your tissues are sucking up ketones out of your blood fast, but your blowing off more acetone
- Peter’s view in the past was that he was never going to get better precision than using blood
  - Dom agrees that blood is the gold standard for measuring ketones
- Then you have interstitial [ketone measurement]
- Dom was wearing a continuous ketone monitor

**How many companies make a continuous ketone monitor?**

- [Abbott](https://www.freestyle.abbott/ie-en/products/bgm/freestyleoptiumneo.html) makes one, but Dom can’t use it because they use [TestFlight](https://testflight.apple.com/) software and he has an Android

Dom is very impressed with the continuous ketone monitor made by [SiBio](https://www.sibiosensor.com/)

- SiBio is a company in China that now has a footprint in the US
- Dom doesn’t get paid by them
- The first week the ketone measurements are very accurate, but the last week they tend to measure only about half of what you measure in the blood

Peter asks, “*Is it microneedles or is it a long filament?*”

- It looks exactly like a CGM device [shown below]

![](https://peterattiamd.com/wp-content/uploads/2025/12/f2-DD.png)

**Figure 2. Continuous ketone monitor by SiBio**. Image credit: [SiBio](https://www.sibiosensor.com/products/sibio-ks1-continuous-ketone-monitoring-sensor?variant=44845071990998)

- It uses the exact same technology as a CGM, just a different enzyme
- Wearing it, Dom could swim all day in salt water, do stuff on the farm (it doesn’t come off)
- It’s probably as reliable as a CGM device is now
  - It’s remarkably reliable and the specificity is good
- It’s measuring [BHB](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid)
- Dom pressure tested it with high doses of ketones and it performs well

**⇒** An important point about [ꞵ-hydroxybutyrate](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid): you need to know if it’s the D enantiomer or the R enantiomer of BHB because there’s supplements out there that are [racemic](https://en.wikipedia.org/wiki/Racemic_mixture)

- Emerging technologies:
  - The continuous ketone monitor
  - The continuous lactate monitor, which Dom thinks is going to be lactates and oncometabolites
- These are not commercially ready yet
- Dom doesn’t think companies are motivated to bring it to market, and there’s more testing that needs to be done
- His colleagues at the Moffitt Cancer Center are salivating over the opportunity to do glucose, ketone, and lactate monitoring

**⇒** We see that tumor burden is tightly correlated with blood lactate levels; so we use lactate monitoring

- If you have an expanding mass of metastatic cancer, lactate levels correlate very nicely

***For monitoring cancer, lactate and oncometabolites should be measured***

## Using a ketogenic diet for weight loss: Dom’s guidance on protein, fiber, calorie tracking, lipid monitoring, and more [A: 31:00, V: 33:05]

**A common mistake people make with a ketogenic diet is not measuring your actual ketone levels**

- You need to measure your ketone levels and track what you’re eating so you can see the association of: when I ate this, it went down, when I ate this, it went up

**What are some other mistakes people make with their diet formulation?**

- Is that they typically err on the side of too much protein, not enough protein?
- Are they not realizing where carbs are sneaking into their diet?

*And what kind of guidance do you give people?*

- How many grams of carbs a day do you tell somebody or do you vary that based on their activity level?

> “*Unlike many people out there, I view a ketogenic diet as a prescription metabolic therapy*.”‒ Dom D’Agostino

- There’s clinical keto and there’s internet keto, of which a lot of people are following a low-carb diet
  - Which has a plethora of metabolic benefits
  - You just have to be up on your blood work and vigilant about tracking your biomarkers
- A **clinical ketogenic diet** is typically done with consulting or even following a framework ‒ books that are out there that tell you step-by-step on how to do it
  - For example, a lot of [books](https://www.amazon.com/Ketogenic-Therapies-Epilepsy-Conditions-Seventh/dp/0826149588/ref=sr_1_1?crid=3S48ALS12AUP8&dib=eyJ2IjoiMSJ9.3hMoiVO55NO2tG-nG8ta9hcbW9DjByPem141xwoSJ6x6ZLALDRScr5jGZuB8QdkNQIhcmwfr_VuMggTZreLhgXwzikfYp61RnCUu9-NWMwijhdB9SPAlaV7s9LJzzYYX6jmLFiJQjP6TOK3ETTyxCO9J_e7RzgzKWP1Z_eBnzioToLrO8ObWrCAQ-XOB6ZV7Gly_43dOCA6Igeuy63B3lg.gqGsAvGtfThB9jK012-2lHaYPfR1XqYl35cD0W0MvRg&dib_tag=se&keywords=Eric+Kossoff&qid=1756476067&s=books&sprefix=eric+kossoff%2Cstripbooks%2C88&sr=1-1) out there by Dr. Eric Kossoff, MD
  - If you have cancer, Miriam Kalamian has a guide, [*Keto for Cancer*](https://www.amazon.com/Keto-Cancer-Ketogenic-Metabolic-Nutritional/dp/1603587012/ref=sr_1_1?crid=1RL5GOK8CQ20R&dib=eyJ2IjoiMSJ9.aeqW7TyQqAO6DA-HrV4nHQ.2-XWg5aUhBWbdU_E2IfdpGQhC4-SIQFbiJWKfbTjkJw&dib_tag=se&keywords=ketogenic+guide+for+cancer+and+miriam&qid=1756476300&s=books&sprefix=ketogenic+guide+for+cancer+and+miriam+%2Cstripbooks%2C73&sr=1-1)
- From a practical or logistical point of view, Dom ran a small [study](https://clinicaltrials.gov/study/NCT04920058#study-overview) with [Dr. Allison Hull](https://www.linkedin.com/in/allison-hull-50213bb7/) that looked at people that they didn’t have any overt pathology
  - Putting normal people on a low-carb ketogenic diet
  - [[preliminary results](https://faseb.onlinelibrary.wiley.com/doi/10.1096/fasebj.2022.36.S1.R4527)]

**⇒** If you transition a person to a ketogenic diet over 4-6 weeks, they adhere to it better, and you actually get more favorable health responses

- You don’t have a lot of funky blood work
- It could the the electrolytes with people that have certain mutations with fatty acid oxidation disorders, even [*APOEE4*](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms:~:text=%CE%B54%20(rs7412%2DC%2C%20rs429358%2DC)) carriers
- There’s some genetics to unpack there
  - You’ll see their LDL go up, HDL go down, triglycerides go up
  - Dom has seen that in quite a few people, especially people who were carriers or homozygous for *APOE4* ‒ their lipid metabolism is a little bit different

⇒ It’s important to get blood work to track triglycerides, HDL, apoB, LDL, hemoglobin A1c, insulin levels

- Dom has seen people’s insulin levels go up, but generally speaking insulin goes down for 80-90% of people

There are so many different guides to a ketogenic diet out there

- If you’re doing it to manage a clinical condition, you should be working with a registered dietician
- Dom recommends [Advanced Ketogenic Therapies](https://advancedketogenictherapies.com/)
  - It’s a team of people spearheaded by [Denise Potter](https://advancedketogenictherapies.com/team#:~:text=Our%20Team-,Denise%20Potter,-%2C%20RDN%2C%20CDCES)
  - She’s a registered dietician, came from the world of epilepsy, and worked as a conventional registered dietician and then transitioned to ketogenic
  - She now has a team of a half dozen or more people

**If someone just wants to do this on their own, like any other diet they might follow, what guidance would you give them?**

- It depends on why they want to use it

*The most common reason would be weight loss*

- Calories are super important
- For purely weight loss, Dom recommends: high protein, moderate fat, and high fiber
- The carbohydrates you’re getting should be fibrous carbohydrates: 50-100 g of carbs per day if ⅓ of those carbs are fiber

**⇒** That excludes all ultra-processed food, even processed food

- Broccoli is about ⅓ fiber
- You’ve got all your leafy vegetables
- Dom has a list of 30-40 forms of carbohydrates that are about ¼-⅓ fiber

Peter asks, “*Would carrots be in there?*”

- No ‒ carrots can be highly glycemic, especially if they’re cooked
- Foods on the list: broccoli, cauliflower, avocado, cucumber, asparagus [other high-fiber vegetables shown below]

![](https://peterattiamd.com/wp-content/uploads/2025/12/f3-DD.png)

**Figure 3. Low-carbohydrate fibrous vegetables**. Image credit: [KetoNutrition 2022](https://ketonutrition.org/what-is-keto/#:~:text=Low%2Dcarbohydrate%20fibrous%20vegetables)

Foods to avoid

- Bell peppers are a little too high in sugar ‒ they’re at the cutoff point
  - Maybe a green pepper
- Tomatoes are pretty high in sugar (tomato is a fruit)

***These are things you need to be vigilant about, and that’s why it’s important to use a tracking app***

- Dom uses a tracking app from time to time if he wants to make adjustments and be very good
  - Like the [Carbon](https://www.joincarbon.com/) app or other apps
- One thing he noticed: he thought he was eating about 3,200 calories/day but when he put it into the app, it was more like 4,000 calories/day
  - He always underestimates his calories
  - Probably because fat is so calorically dense ‒ think egg yolks, fatty fish
  - This morning Dom had 3 cans of sardines and each can is 20 g of fat, 15 g of protein; that’s 60 g of fat from sardines and extra virgin olive oil
  - It seems like nothing, but it adds up

***When people are not losing weight with a ketogenic diet, they need to track calories ‒ creating even a 10-20% energy deficit will be a big lever for weight loss***

**What’s the efficacy of a ketogenic diet for weight loss?**

*Do you think it works because under conditions of caloric restriction, it’s more satiating than diets that are high in carbohydrates?*

- Off the top of his head, Dom finds the ketogenic diet hyper satiating, especially a high protein ketogenic diet
- It’s hypo palatable

> “*You’re not going to overeat a ketogenic diet just because it doesn’t have the hyper palatability of a standard American diet.*”‒ Dom D’Agostino

- Dom thinks a ketogenic diet fundamentally changes metabolic physiology and brain neuropharmacology in a way that decreases appetite regulation

With a higher protein diet:

- You’re getting higher [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1)
- You’re reversing insulin resistance
- You’re improving fatty acid oxidation

Dom adds, “*I think you’re fundamentally weaning your brain off glucose*.”

- Your brain is dependent on glucose with a standard American, and as you’re decreasing glucose availability, your brain has a counter-regulatory dysphoric reaction to that and as it transitions into ketosis

> “*You could avert a lot of this simply by using ketone electrolytes.*”‒ Dom D’Agostino

- [KETOSTART](https://www.audaciousnutrition.com/products/ketostart-tropical) is electrolytes bound to ꞵ-hydroxybutyrate (D/L-BHB salts)

Consume that when you start the diet, and that’ll largely mitigate 2 things

- It’ll mitigate the electrolytes
- A ketogenic diet has a natriuretic effect, which means you (1) dump sodium and (2) it has a diuretic effect
- These are the things that really throw a monkey wrench into some of the clinical trials
  - The electrolytes
  - Dehydration

## Protein on ketogenic diets: Dom’s rationale for higher intake and muscle preservation [A: 38:00, V: 41:02]

Peter asks, “*You keep saying high protein. Can you define high protein in this context?*”

- Historically, 8 to 10 to 12% [protein] was used with ketogenic diets

***Dom is talking about a ketogenic diet that is 20-30% protein (that’s considered high protein)***

- That’s hard for people sometimes

**Do you find it easier to just say, “*****Keep your carbs at 50 g and try to get them from high fiber carbs? Get your protein to x grams, and then limit your total calories to whatever (3,000), with fat filling the rest.*****”?**

*What does it typically work out to in terms of grams of protein per lb. of body weight?*

- Dom is upwards of 220 lbs and 220 g of protein would be the upper end if he’s very active
- He doesn’t think there’s any benefits to go above and beyond that

**At that level of protein, you’re not undergoing so much** [**gluconeogenesis**](https://en.wikipedia.org/wiki/Gluconeogenesis) **that you’re making too much glucose that’s offsetting the ketone process?**

- Everybody is a unique metabolic entity, so they’re going to have a different response
- For Dom, when he was in his late teens-20s, eating 4-500 g of protein worked for him

**⇒** For some people, if you’re going to jump from 50 g a day or the RDA recommendations (80 g) ‒ you want to do that to ideal bodyweight

- Example: if you’re 100 kg, the RDA recommends you eat 80 g of protein, not 220 g
  - At 80 g, you would not be able to maintain your muscle

**⇒** The more muscle you have, the higher your protein turnover will be

- You’re breaking down protein and building protein
- That whole cascade is amped up probably several times higher in the, especially if you’re working out and breaking down protein and you have a fast metabolism
- Dom’s recent [testing of his] resting metabolic rate showed it was 34% higher
  - He’s going to redo that in 2 weeks
  - He was off [creatine](https://en.wikipedia.org/wiki/Creatine#) and some other things, so he’s reloading on creatine
  - That’s even when adjusted for his lean mass

***After turning 50, Dom is very vigilant with his protein intake because sarcopenia and the loss of lean mass is considerably higher***

**⇒** Activity is the main mitigator for the loss of lean mass

Dom explains, “*If you’re providing a stimulus for your body to grow and maintain muscle, you need protein that’s double the recommended daily allowance.*”

## Incorporating carbohydrates into keto: timing, high-fiber foods, and other considerations [A: 41:30, V: 44:56]

**Any other quick do’s and don’ts around things like fruit? Berries? Artificial sweeteners?**

Dom tends to carb backload at the end of the day

- He eats no carbs all day and at dinner he’ll have a salad or vegetables
- Then in the evening he has wild blueberries (which have ⅓ of the sugar of regular raspberries, blueberries)
- Then he’ll have a keto mousse, which is just cocoa powder, chocolate ketone powder, some stevia or monkfruit, and cinnamon
- It has no effect on his [CGM](https://en.wikipedia.org/wiki/Continuous_glucose_monitor) (it actually goes down)

**⇒** What Dom has found is if the carbohydrates are delivered with fiber, there’s really no glycemic spiking

Dom has a short list of foods he eats every day

- Berries, broccoli, asparagus, dark chocolate, and salads
- He keeps things pretty simple at home
- In the past, he had a desire to have more different kinds of foods
- When he was traveling in Greece, he’s not going to pass up all the great food
  - He ate as much carbohydrates as they were serving him
  - He came back 6 lbs. lighter because of all the activity (in the water, walking in the sun)
  - He’s pretty metabolically flexible; he felt great

**Metabolic flexibility is a consideration**

If you really delve to carbohydrate restriction and your body is completely fat adapted, it’s like carbohydrates are a foreign substance and glucose spikes [when you eat them]

- You’re going to have a pretty big counter-regulatory effect once you start bolusing carbohydrates again
- Because you’re changing your physiology
- Your gut for one thing is not going to tolerate that
- For example, look what happens to fitness competitors when they diet and then they finish a competition and go out for a cheat meal ‒ they’re up all night with gas and bloating
- The GI takes a big hit
- The liver takes a big hit
- When glucose hits the peripheral system, it can’t absorb it so you CGM goes off the charts
- That can trigger inflammation, and that can alter the gut microbiome
- It’s going to affect your mood
- These are wild swings that yo-yo dieters go through

If you’re low-carb and you achieve your weight loss goals but you miss carbohydrates, you can slightly titrate them back in

- Start with fibrous vegetables, but some people can’t tolerate that
- Most people can tolerate fruits

## The carnivore diet: whether carnivore eating induces ketosis, how it functions metabolically, and why it may help individuals with autoimmune conditions [A: 44:15, V: 48:21]

**Let’s talk about the carnivore diet**

- There are different ways people go about doing this
- Some versions are incredibly strict where you literally eat nothing but meat
- Other versions are expanded into other animal products (eggs and dairy)

*Starting with the meat-only version, what do you think is happening metabolically?*

*How does one achieve ketosis with just meat?*

- Dom had ribeye the other night, and he think it would hit the keto macros because it was a lot of fat
  - He was annoyed because there was less meat and more fat

***Dom thinks you could achieve ketosis with a fatty carnivore diet, especially if calories are restricted***

Peter asks, “*Couldn’t do it if it was a New York strip or a filet. You just don’t have enough fat in it relative to the protein, right?*”

- You could if you were in a caloric deficit
- In an energy deficit, your insulin is going to go in the right direction

**⇒** Dom is a firm believer that carnivore diets can be therapeutic for people who have autoimmune disorders

- Some of those people could do an elimination diet, but the carnivore diet is the ultimate **elimination diet**
- A carnivore diet meets your **protein requirements** for enough protein to build muscle
- Steak and an animal-based protein diet has pretty much all the **micronutrients**
- You could argue maybe vitamin C in magnesium [intake would be low]
  - But you do not see vitamin C deficiency in people that are on carnivore diets surprisingly
  - There’s some vitamin C in liver and stuff too ‒ if you’re eating nose to tail, that’s not something you have to worry about
- Dom has seen magnesium trending low
  - Although we don’t have the best magnesium measurements for the blood work
  - But he has seen magnesium being beneficial for people
  - Remember we get magnesium from chlorophyll, and we’re not getting any of that really with the carnivore diet [Dom misspoke here and said ketone diet]
- We’re talking steak and water
  - Not even coffee, not even putting pepper on the steak
- There are a group of people who believe it’s working for them, and they have a lot of anecdotal data to support that
  - Dom gets an inbox full of people that say, “*Hey, look, I had this condition or that condition. I followed carnivore and here’s my blood work*”, and he can’t argue with that

***Peter finds that stuff pretty compelling from an elimination diet perspective, and he’s met a number of folks who feel that way; it’s quite binary (either it works or it doesn’t)***

- The influencer voice is also amplified
- For example, [Joe Rogan](https://www.instagram.com/reel/B8ARl8VFJp3/) had [vitiligo](https://en.wikipedia.org/wiki/Vitiligo) (an autoimmune disorder)

**There’s a wide variety of things the carnivore diet can be therapeutic for**

- There’s a group in Budapest Hungary called [Paleomedicina](https://paleomedicina.com/), and Dom went to their clinic and they pulled their [files](https://paleomedicina.com/hu/esettanulmanyok)
  - He saw everything from type 1 diabetes to cancer to different neurological disorders
  - They showed him blood work longitudinally over time
  - It could be cherry-picked cases, but it was pretty convincing
  - They probably have a dozen or more publications (case series and things like that)

***The carnivore diet is a form of a ketogenic diet***

- Paleomedicina focuses on super fatty cuts of meat, fatty fish, and if practiced the way they do, it works

## Early exogenous ketones: how 1,3-butanediol works, its liver toxicity risk, and why ketone esters replaced it [A: 48:15, V: 53:10]

- Exogenous ketones are supplemental ketones
- Earlier Dom alluded to them through the lens of kickstarting a ketogenic diet (we’ll come back to that application)

- Peter was once on the journey Dom is on and was a regular consumer of these things
- In the past 3 months, Peter has tried a product: it’s a diester of 1,3-butanediol
  - It’s a white powder that he puts in his coffee
  - It doesn’t come with the liver toxicity
  - What blows Peter’s mind is when you mix it in water/a drink, it’s palatable (not delicious) ‒ it’s not horrible the way that most of these synthetic ketones used to taste
  - You can make a shot of it, and it’s totally reasonable
  - It’s fantastic as the creamer in coffee

**Circa 2011, there were only a few products you could consume**

- ꞵ-hydroxybutyrate monoester
- A ketone salt
- Acetoacetate diester
  - The monoester and 2 [acetoacetates](https://en.wikipedia.org/wiki/Acetoacetic_acid) on [1,3-butanediol](https://en.wikipedia.org/wiki/1,3-Butanediol) [aka 1,3-butanediol acetoacetate diester; those are 2 esters]

**Unfortunately we have to get into a little biochemistry to explain the difference between esters and salts**

- Everybody is talking about these things as though they’re the same and they’re categorically not the same
- Most people have no idea what they’re talking about and most people who are selling these things are not being transparent about what it is you’re buying
  - They just call everything a ketone
- If you go to [Clinicaltrials.gov](https://clinicaltrials.gov/search?intr=MCT) and search ketone supplement “MCT” [[medium-chain triglyceride](https://en.wikipedia.org/wiki/Medium-chain_triglyceride)]
  - That’s a 8-10 carbon fatty acid that can convert to ketones
  - We’ll come back to this

One of the original ketogenic substances was 1,3-butanediol

- Dom has some of the MIT reports of testing this compound from the 1960s compliments of [Ken Ford](https://uwf.edu/intelligent-systems-and-robotics/faculty/ihmc-research-scientists/dr-kenneth-m-ford.html)
- And then there was a report written for NASA where they were basically looking at this as a long-duration spaceflight food
- 1,3-butanediol [shown below] is an alcohol ‒ specifically, it’s a di-alcohol or a glycol

![](https://peterattiamd.com/wp-content/uploads/2025/12/f4-DD.png)

**Figure 4. Chemical structure of 1,3-butanediol**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/1,3-Butanediol)

- It’s remarkably ketogenic, which means you consume it and you elevate ꞵ-hydroxybutyrate
- And it’s incredibly stable ‒ hence the interest for long-duration spaceflight
- It also preserves food
- In the report, they soaked it into some biscuits and they were extremely shelf stable
- It’s a humectant, which means it keeps food moist
- It’s [GRAS](https://en.wikipedia.org/wiki/Generally_recognized_as_safe)-approved to be put in sausage casings and things like that
- Dom credits 2 people: [Dr. Henri Brunengraber](https://case.edu/medicine/nutrition/about-us/faculty/henri-brunengraber) from Case Western and the late [Dr. Richard Veech](https://ketonutrition.org/2020-2-11-tribute-to-dr-richard-veech/)
  - Richard was Dom’s mentor; he passed away [in 2020]
- Dom was trying to acquire Richard’s ketone ester for some studies and he ultimately used the monoester [ꞵ-hydroxybutyrate](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid) for seizures [shown below], *but it had no anti-seizure effect*

![](https://peterattiamd.com/wp-content/uploads/2025/12/f5-DD.png)

**Figure 5. Chemical structure of ꞵ-hydroxybutyrate**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid)

***1,3-butanediol was the original ketogenic molecule and these Brunengraber and Veech spearheaded research on ketone esters***

**1,3-butanediol is metabolized like alcohol and why that is problematic**

*You said 1,3-butanediol elevates ꞵ-hydroxybutyrate. Explain how and why*

- You can consume 1,3-butanediol and it’s a precursor to ꞵ-hydroxybutyrate (BHB)
  - When you consume it, it goes through the [alcohol dehydrogenase pathway](https://en.wikipedia.org/wiki/Alcohol_dehydrogenase#Properties) much like alcohol [metabolism]
  - You can elevate BHB with this precursor, but it needs to be metabolized by the liver
  - And when it’s metabolized by the liver, the liver does have to work

**⇒** If you consume enough to jack up your ketones to 3 or 5 millimolar for 2 or 3 weeks, you’re going to see your [liver enzymes](https://en.wikipedia.org/wiki/Elevated_transaminases) jump up

- Dom has done that with 1,3-butanediol (R and R/S)
- You have to take a lot of it: 75-100 mL per day for someone like him to be in therapeutic ketosis.

***When you convert 1,3-butanediol to ꞵ-hydroxybutyrate, you also generate an aldehyde***

Peter points out, “*If I asked you to consume 100 g of ethanol a day for 2 weeks, your* [*transaminases*](https://en.wikipedia.org/wiki/Elevated_transaminases) *would go up*.”

- Yeah, Dom has done that before
- A standard drink is about 15 g of alcohol (maybe more), round-up to 20 g
- 100 g of alcohol is 5 alcoholic beverages a day
  - You could space that out over the course of the day and not even get a buzz
- So 5 alcoholic beverages a day for 2 weeks
  - You are metabolizing ethanol with alcohol dehydrogenase, and you’re going to create all of the various metabolites

***The reason your transaminases are elevating is those enzymes are leaking out of hepatocytes because the hepatocytes are injured due to the inflammation that results from that metabolic pathway***

Peter asks, “*Is that at all analogous to what’s happening with a comparable dose of 1,3 butanediol?*”

- Yeah, it is
- There’s a couple things going on
- You drink alcohol, you’re de-energizing the redox state of the liver, and you’re generating acetaldehyde (an aldehyde molecule) and you’re also generating acetate
- Aldehyde damages DNA ‒ it’s got oxidative stress issues, baggage that comes with it
- You’re also generating acetate, and acetate is actually something Dom has looked into
  - It’s a remarkable alternative fuel for the brain
  - Maybe a lot of people don’t know that, but when you drink alcohol, you’re giving your brain acetate

***Metabolism of 1,3-butanediol is analogous to drinking alcohol; and instead of generating acetate, you’re generating ꞵ-hydroxybutyrate (another alternative fuel for the brain)***

- [Dom shared by email that 30 mL of pure 1,3-butanediol is like “1 ethanol shot” and requires the same level of ADH enzyme and ALDH activity to detox]
- These enzymes deplete NAD+ and their activity can sharply drop ATP levels in hepatocytes
- [Further, 1,3-butanediol [induces](https://pubmed.ncbi.nlm.nih.gov/7193248/) physical dependence and withdraw similar to ethanol]

*Does metabolism of 1,3-butanediol generate the same amount of aldehyde?*

- You’re generating ꞵ-hydroxybutyrate aldehyde that is relatively short-lived, but you can overwhelm the [ADH enzyme](https://en.wikipedia.org/wiki/Alcohol_dehydrogenase#)
  - So if you drink too much of it, you can overwhelm the enzymatic degradation

[Henri Brunengraber](https://case.edu/medicine/nutrition/about-us/faculty/henri-brunengraber) did some seminal studies on this

- Some of it is published
- They had a [ketogenic dog model](https://pubmed.ncbi.nlm.nih.gov/10876102/) that they gave 1,3 butanediol as a hypoglycemic agent
  - It’s a hypoglycemic agent because it de-energizes the liver and prevents glycogenolysis and gluconeogenesis because those mechanisms in the liver are highly, highly energy dependent
- So that’s analogous to [alcoholic ketoacidosis](https://en.wikipedia.org/wiki/Alcoholic_ketoacidosis)
  - When you have an alcoholic that’s fasting and he over consumes alcohol, he goes to the ER because he experiences alcoholic ketoacidosis
  - You have runaway ketogenesis because you’re inhibiting [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis)

Peter asks, “*Why can’t that patient make enough insulin in response to the* β-*hydroxybutyrate to bring the acidosis under control?*”

- If you increase insulin, that insulin is only going to facilitate glucose disposal
- The liver doesn’t respond to the insulin signal to make less [BHB](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid) in alcoholic ketoacidosis

**Tangent on fasting**

Peter asks, “*When you and I used to do our ridiculous 10-day fasts, do you still do those?*”

- Dom will do a 5-day fast eating 2 or 3 cans of sardines a day
- He gets the same benefits and it mitigates a lot of the negative effects

Peter explains, “*When we used to do these 10 and 14 day water only fasts, our ketones would actually plateau.*”

- Even when [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) did the [seminal studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC292907/) of 40-day water only fasts, their ketones plateaued at 7 to 10 days
- And a big part of that was that insulin is now keeping them in check
- The reason the ketones aren’t going to produce a level of acidosis is that
- And that’s why of course kids primarily with type 1 diabetes can develop ketoacidosis
  - They don’t have the [ꞵ-cell](https://en.wikipedia.org/wiki/Beta_cell) capacity to offset that rise in ketones

**Back to alcoholic ketoacidosis**

- This case of the alcoholic is very interesting to Peter (he actually was never aware of this)
- Dom explains that you de-energize the liver so the liver can’t undergo gluconeogenesis, to some extent [glycogenolysis](https://en.wikipedia.org/wiki/Glycogenolysis)
- Then you have the electrolyte balance, you get dehydration
- So it’s a constellation of things

**Getting back to 1,3-butanediol [and why it’s not a great exogenous ketone to take]**

**⇒** If you consume it and you consume large amounts of it, you can overwhelm that enzymatic cascade and you can start generating a lot of these aldehyde intermediates and that’s maybe not a good thing (especially chronically)

*2 problems people should be aware of*

- Especially important for elderly people using it for cognitive enhancement
- 1 – you get buzzed on it
- Dom has probably consumed more 1,3-butanediol than anybody
  - He had it in big 20 L vials
- Peter used to buy it from Sigma Chemicals; it was dirt cheap
- Dom experimented with the racemic mixture and then the R-enantiomer (it’s great)
- He mixed it with a standard diet and gave it to [animals with metastatic cancer](https://pubmed.ncbi.nlm.nih.gov/24615175/) and it suppressed cancer

***Drinking 1,3-butanediol to elevate BHB is somewhat analogous to drinking alcohol to generate acetate (which is a great molecule), but it’s a very indirect way to do it that comes with toxicity***

[*Veech*](https://ketonutrition.org/2020-2-11-tribute-to-dr-richard-veech/) *and* [*Brunegraber’s*](https://case.edu/medicine/nutrition/about-us/faculty/henri-brunengraber) *work*

- Other were involved in the research
- [Sami Hashim](https://icahn.mssm.edu/about/srt/archives/oral-history/msslw-interviews/hashim) developed the β-hydroxybutyrate ester
- You can take 1,3-butanediol and do a trans-esterification reaction and add β-hydroxybutyrate to it, or you can add acetoacetate to the molecule
- And when you consume it, you quickly liberate the ketones (β-hydroxybutyrate or acetoacetate), and then the 1,3-butanediol then goes to the liver
- Dom mimicked the pharmacokinetics exactly in the lab
  - You have an initial peak and then an hour or two later you have a second peak from the 1,3-butanediol
  - It’s dose-dependently potentially problematic

With 1,3-butanediol, there are 2 issues that have the potential for liver toxicity in people that do not have healthy livers

- 1 – It causes an increase in [liver enzymes](https://en.wikipedia.org/wiki/Elevated_transaminases)
  - Dom’s liver is pretty healthy, and it doubled his liver enzymes if he takes a large dose for 2 weeks
- 2 – It has a higher narcotic effect in someone who is frail, who doesn’t have good stability
  - If you take a large dose
  - In Dr. Veech’s words, “*It’s going to make you drunk stupid.*”
- Dom was trying to acquire some of Dr. Veech’s ester, then was going to use 1,3-butanediol and Veech talked him out of it

***The whole reason for developing the monoester was to avert this problem***

## The progression of exogenous ketones: why BHB monoesters and ketone salts emerged as better alternatives to 1,3-butanediol for ketone supplementation [A: 59:30, V: 1:06:31]

**The BHB monoester avoids problems associated with pure 1,3-butanediol**

- The BHB monoester [shown below] is β-hydroxybutyrate with a monoester bond to 1,3-butanediol
  - Or you can say it the other way: it’s 1,3-butanediol bound to β-hydroxybutyrate
  - The BHB monoester is still 51% 1,3-butanediol by millimolar concentration.
    - The acetoacetate diester Dom often uses in his seizure studies is 35% 1,3-butanediol

![](https://peterattiamd.com/wp-content/uploads/2025/12/f6-DD.png)

**Figure 6. Chemical structure of BHB monoester**. Image credit: [Ketone-IQ 2019](https://ketone.com/blogs/library/exogenous-ketones-ketone-supplement-fundamentals?srsltid=AfmBOor6_aelT1DorWz_PGMUOouq9l3Oo0wbyKBrv-E2lwcHaRWh6L2z)

**Why is it that you don’t experience the same negative issue with the BHB monoester?**

*Is it because you just consume less of it because you’re getting BHB directly?*

- Yeah, you could take half the amount
- The kinetics are a little bit slower too, because you have to hydrolyze the BHB from that in the liver

**Why can’t you just consume BHB?**

*Is that not stable enough by its own other than in itself?*

- You can ‒ there’s a free acid
- Dom tinkered with that originally and is still experimenting with BHB free acid formulations

***It’s super acidic and not very stable in solution; ideally, it needs to be liquid in an electrolyte formulation***

- At the time, in Dom’s electrophysiology experiments, you can’t put a ketone ester in the bath because it has to be metabolized by the liver
  - So you can’t put it into neurons
  - You have to use the salt ‒ you mimic the pharmacokinetics of what you get with the ester
  - He was putting in sodium β-hydroxybutyrate(racemic salts)
- He thought about giving sodium β-hydroxybutyrate to the animals, but he was very concerned about **sodium overload**
  - Hypertension
  - All the negative effects of salt
- Most physiologists who study salt ‒ the problem with salt-sensitive people and salt is that you get hypertension
  - But that’s specific to sodium chloride (not sodium bicarb, sodium citrate)

**⇒** He’s talking about sodium β-hydroxybutyrate [a ketone salt], and if you consume large doses (grams) of that, it doesn’t have the same hypertensive effect as table salt

- It’s something about the chloride (sodium chloride)
- You could use potassium chloride instead of sodium chloride for salt

***This is an important point because a lot of people a lot of people shy away from ketone salts because of the sodium, but salt-sensitive hypertension is associated with sodium chloride***

- Dom was communicating with [Patrick Arnold](https://www.linkedin.com/in/patrick-arnold-8302676/) at the time, trying to get potassium chloride
  - He couldn’t buy it from Sigma

**Ketone salts**

Dom wondered, “*How could nobody have thought about putting ketones on different electrolytes?*”

- He had this idea of combining it with sodium, calcium, potassium, magnesium
- He wanted to balance the sodium with potassium and create a ketone salt ([ionically bound](https://en.wikipedia.org/wiki/Ionic_bonding))

*Back to high school chemistry*

- BHB is a highly acidic molecule [it has a negative charge]
- You can [covalently bond](https://en.wikipedia.org/wiki/Covalent_bond) it through an ester to 1,3-butanediol
- Or without that baggage, it can form an [ionic bond](https://en.wikipedia.org/wiki/Ionic_bonding) (not covalent bond) to a salt [with a positive charge]
  - You just need a positive charge to offset the negative charge of BHB
- You want sodium AND potassium because with both of them you have 2 positive charges
  - Instead of 1 calcium or 1 magnesium (which each have 2 positive charges)

***The idea is to have monovalent and divalent cations***

- You can spread the BHB out to create a quad salt
  - This was the idea back in 2011
- Dom and [Patrick Arnold](https://www.linkedin.com/in/patrick-arnold-8302676/) made BHB salts and over time settled on a ratio of sodium, potassium, to calcium similar to [LMNT](https://science.drinklmnt.com/electrolytes/lmnts-electrolyte-ratios-explained)
  - LMNT uses sodium chloride

[KETOSTART](https://www.audaciousnutrition.com/products/ketostart-tropical) from Audacious Nutrition is sodium β-hydroxybutyrate and calcium

- It’s got a spread of electrolytes that are similar
- So you’re giving electrolytes and also ketones

**⇒** That’s really important when you start a ketogenic diet because you’re replenishing the electrolytes that you’re spilling out through a natriuretic effect (especially the sodium)

- Also, there’s an energetic gap in the brain when you start a ketogenic diet where you have an energetic need for the increase in ketones

## Ketone salts: easing the transition into ketosis, dosing, and how they compare to ketone esters [A: 1:04:00, V: 1:11:46]

- A lot of people have lived this experience and don’t know why [the “keto flu”]

**⇒** Which is in the early stages of a ketogenic diet, when glucose levels are going down and ketone levels haven’t come up enough to fill the gap, you really feel lousy

- In retrospect, you can work around that, but it’s easy to miss it
- Meaning it’s easy to miss the mark and therefore suffer that painful transition, which can last weeks in some people

***And therefore, using these exogenous ketones can be a very elegant bridge through it so that you don’t experience the negative side effects of the transition to a ketogenic diet***

- You can see the energetic effects in an [FDG PET scan](https://en.wikipedia.org/wiki/Positron_emission_tomography)
  - You’re going to see less brain glucose utilization
- You have the contraction of plasma volume because as you lose water and electrolytes, so that you might have orthostatic hypotension, you get the brain fog
- Then you have electrolytes, which are literally molecules that are involved in action potentials and keeping membrane potentials in cells

**All these can be mitigated through ketone salts, and have an advantage over the ketone esters**

- They also have the advantage because the mineral delays **gastric absorption**
- When you take a dose of a ketone salt, it does not cause an **insulin effect**

**⇒** If you drink a ketone ester or a large dose of 1,3-butanediol, and you do an insulin measurement an hour after, you’re going to see your insulin levels increase (Dom has done this before)

- The increase in insulin seems to be proportional to the differential
- So if you rapidly increase ketones 2 mM, and if you stay under 2 mM, then you don’t get the spiking in insulin

***But if you consume it and you get above 1.5 to 2 mM, then you see this counter regulatory dump in insulin***

- This is what Dom saw in himself, and a few other people that did this—There appears to be a threshold

**⇒** And that would also explain when people drink a large dose of a ketone ester, their glucose levels go down

- It’s a bit of a scary situation because Dom knows people have gotten themselves into the situations that when you drink the ketone ester about 2 hours later you can be [hypoglycemic](https://en.wikipedia.org/wiki/Hypoglycemia) and also **hypoketotic**
  - Which means your ketones come up, you utilize them as fuel, but you’ve released insulin and that caused peripheral glucose disposal
- Then you get into a point where you’re running, for example, and you tank
- You could trigger a headache if you take a large dose (there’s ways around that)

**The ketone salt does not produce that effect at all for a number of reasons**

- The rate of rise of ketones in the bloodstream seems to be the predictor of if you’re going to release insulin
- There, there’s something about the electrolytes too
  - Maybe delays gastric absorption
  - You’re not getting an elevation of ketones that’s as high and as rapid as you would get with the ketone ester
- [the benefits of ketones salts over ketone esters is summarized in this figure below from a 2025 publication]

![](https://peterattiamd.com/wp-content/uploads/2025/12/f7-DD-1024x501.png)

**Figure 7. Advantages of ketone salts over ketone esters**. Image credit: [*Pharmaceuticals* 2025](https://www.mdpi.com/1424-8247/18/10/1436#)

**What’s the brand of the ketone salts that you gave to me?** [Audacious Nutrition – KETOSTART](https://www.audaciousnutrition.com/products/ketostart-tropical) [shown below]

![](https://peterattiamd.com/wp-content/uploads/2025/12/f8-DD.png)

**Figure 8. KETOSTART ketone electrolytes**. Image credit: [Audacious Nutrition](https://www.audaciousnutrition.com/products/ketostart-tropical)

- One packet is about 1 gram of electrolytes: sodium, calcium, magnesium, potassium (there’s different formulations)
- The packets are about the size of LMNT
- You get 6-10 grams of pure β-hydroxybutyrate minus the electrolytes
- The amount of ketones you get depends on which packet you take
  - It’s 6-10 grams of the 2 different [enantiomers](https://en.wikipedia.org/wiki/Enantiomer) of β-hydroxybutyrate (an equal mix of the D & L enantiomer)
- Then you have the acetoacetate
- The β-hydroxybutyrate does need to break down to acetoacetate to be used in the mitochondria
- And then you have acetone, which has some interesting signaling and metabolic effects (surprisingly)
  - It also correlates really well with seizure control

Peter asks, “*In somebody my size (180 lbs.), 10 grams of BHB will take me to what level for how long? At rest, let’s just say I’m not exercising.*”

***Dom’s CKM (continuous ketone monitor) shows that one packet increases his ketones for about 4 hours***

- [the figure below shows Dom’s CKM trace after consuming 10 g of D/L-BHB salts (Audacious Nutrition, Ketostart) with 3 meals at 1 pm, 4 pm, and 7 pm]
  - [Dom shares that when his BHB levels are > 2mM (with supplementation), he feels hyperactive and agitated; his sweet spot is between 1-2 mM, and this appears to be the case in people that are healthy, whereas someone in a disease state may require higher levels]

![](https://peterattiamd.com/wp-content/uploads/2025/12/f9-DD.png)

**Figure 9. Dom’s continuous ketone monitor (CKM) data after taking a 10 g packet of BHB salts**

- He would eat carbohydrates to make sure he’s at zero [ketones] to start with
- He’s done this dozens of times: he’s in his car on a road trip, has his CKM on, drank one packet and his ketones were elevated for 4-6 hours
  - He was super hyper-focused driving and it was great
- His ketones were elevated between 1-2 mM, which is an ideal range and not stimulating insulin
- [KETOSTART](https://www.audaciousnutrition.com/products/ketostart-tropical) contains D and L [ketones], and his CKM was only measuring the D
  - So that’s not accounting for the L or acetoacetate or acetone
  - It’s a 50/50 mixture of D and L, but only measuring the D, and it’s still getting between 1-2 mM

Peter asks, “*Does that mean you’re actually at twice that level?*”

- Potentially, yeah

## The differences between D- and L-β-hydroxybutyrate, and how racemic mixtures may elevate ketones longer and offer unique biological effects [A: 1:09:30, V: 1:18:06]

**What were we doing with our Abbott finger sticks?**

- Measuring D-β-hydroxybutyrate

*Does that mean every time we were measuring this, we were probably only capturing half what* [*Cahill*](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) *was capturing, or has everybody always measured half?*

- Some of the first ones to come out on the market measured [racemic](https://en.wikipedia.org/wiki/Racemic_mixture) ketones, and then everybody gravitated to the D-enantiomer

**Explain what enantiomers are**

**⇒** β-hydroxybutyrate produced in the body primarily in the form of D-β-hydroxybutyrate

- D-β-hydroxybutyrate is the mirror image of L-β-hydroxybutyrate
  - [the difference in these [enantiomers](https://en.wikipedia.org/wiki/Enantiomer) (D- and L- forms of a molecule) is illustrated in the figure below, and this is a chemistry concept called [chirality](https://courses.lumenlearning.com/suny-potsdam-organicchemistry/chapter/4-1-chirality/))
- We say if a β-hydroxybutyrate supplement is [racemic](https://en.wikipedia.org/wiki/Racemic_mixture), it has D- and it has L-forms in it

![](https://peterattiamd.com/wp-content/uploads/2025/12/f10-DD.png)

**Figure 10. Enantiomers are mirror images of each other**. Image Credit: [KetoNutrition 2022](https://ketonutrition.org/why-do-we-need-both-d-bhb-and-l-bhb/)

- Another example: allulose and fructose [shown below]
  - [They differ at one chiral center (carbon 3, highlighted in red below)]
  - [allulose is an [epimer](https://en.wikipedia.org/wiki/Epimer) of fructose, explained in this [chemistry textbook](https://courses.lumenlearning.com/suny-potsdam-organicchemistry/chapter/4-4-molecules-with-multiple-chiral-centers/#:~:text=diastereomers%20which%20differ%20at%20only%20a%20single%20chiral%20center%20are%20called%20epimers.)]

![](https://peterattiamd.com/wp-content/uploads/2025/12/f11-DD.png)

**Figure 11. Fructose and allulose are epimers that differ at carbon 3**. Image credit: [PeterAttiaMD.com 2020](https://peterattiamd.com/replacing-sugar-with-allulose/)

- The important thing to remember is [Ringer’s lactate](https://en.wikipedia.org/wiki/Ringer%27s_lactate_solution) which is [a racemic mixture of] D- and L-lactate [shown below]
  - [the chemical difference is the 3-dimensional orientation of the CH3 group]

![](https://peterattiamd.com/wp-content/uploads/2025/12/f12-DD.png)

**Figure 12. Enantiomers of lactate**. Image credit: [*Frontiers in Bioengineering and Biotechnology* 2019](https://www.frontiersin.org/journals/bioengineering-and-biotechnology/articles/10.3389/fbioe.2019.00259/full)

*Why does this matter chemically? Do the D- and L-forms of a molecule behave the same?*

- There are lots of [racemic](https://en.wikipedia.org/wiki/Racemic_mixture) compounds: statins, Adderall, ibuprofen

**The D-β-hydroxybutyrate gets metabolized very, very fast**

- It gets in your system, your tissues suck it up, you metabolize it

**Your body makes very small amounts of L-β-hydroxybutyrate with a racemase enzyme**

- That racemase enzymes is not in the liver, but it’s in the tissues
- That’s very interesting because some tissues are converting D to L to maybe use the L-β-hydroxybutyrate as a signaling [molecule] (Dom’s speculation)

***Nonetheless, D-β-hydroxybutyrate gets metabolized very quickly and then the L-β-hydroxybutyrate is like a timed-release version of β-hydroxybutyrate***

- [Brianna Stubbs](https://www.linkedin.com/in/brianna-stubbs-91930794/) did some nice work looking at the D to L, and Dom has done quite a bit of [work](https://pmc.ncbi.nlm.nih.gov/articles/PMC11435142/) on the D and the L (and with racemic compounds)
- The L will get metabolized 3 or 4x slower and you get about 20% conversion of the L back to D, but it’s a very slow process

**⇒** The advantage of taking the racemic mixture [of both D and L] is that the ketones elevate and stay elevated quite a bit longer

- Dom thinks of the L-β-hydroxybutyrate as an important **signaling molecule** because you get higher concentrations of L in the brain
  - If you give someone racemic beta-hydroxybutyrate and then you pull out the heart and you take samples of the brain out, the levels of L-beta-hydroxybutyrate are going to be quite a bit higher

Peter asks, “*Is that just because it sticks around longer and therefore, crosses the blood-brain barrier or in the case of the brain?*”

- Yeah, it metabolizes slower
- We think this is important because the L-β-hydroxybutyrate definitely does not have the same energetic potential in regards to generating ATP (according to [Veech](https://ketonutrition.org/2020-2-11-tribute-to-dr-richard-veech/))
  - And Dom believes this because it gets metabolized much slower

*If you take the total metabolism of it, are you saying that 1 mole of L-β-hydroxybutyrate and 1 mole of D-β-hydroxybutyrate produce a different amount of ATP?*

- Yeah
- Ultimately, L-β-hydroxybutyrate will go into acetyl-CoA, but it’ll be metabolized more like a fatty acid
- The D-β-hydroxybutyrate has a redox shift and it causes a reductive shift
  - Actually, you could have reductive stress (he’ll come to that in a minute)

***The D- and the L-β-hydroxybutyrate get metabolized at different rates: D gets metabolized faster than the L (L takes about 3 or 4 x times longer)***

**L-β-hydroxybutyrate retains signaling effects**

- For example, in the [2015 *Nature Medicine* paper](https://pubmed.ncbi.nlm.nih.gov/25686106/) on the [NLRP-III inflammasome](https://en.wikipedia.org/wiki/Inflammasome#NLRP3_inflammasome) [showed that D-BHB will suppress it]
- The effects of BHB don’t seems to be enantiomer specific

Dom explains, “*That’s important because if the L gets elevated in the brain, then it could inhibit neuro inflammation and inflammatory processes. It’s almost like the drug form of BHB*.”

- The signaling effects and the epigenetic effects of the L seem to be present too

***You have the D that gets burned up quickly for fuel, and then the L that kind of hangs around gets metabolized slower and is hitting the various receptors***

- There are important signaling functions that ketones are attributed to
  - You have the [GPR109A receptor](https://en.wikipedia.org/wiki/Hydroxycarboxylic_acid_receptor_2) and you have epigenetic effects
  - You have the NLRP-III inflammasome
- D-β-hydroxybutyrate has been spent and used as fuel, but the L is hanging around and actually preserving that positive signaling effect

**Are the continuous ketone monitor (CKM) and the Abbott measuring D or L?**

- They only measure the D; they do not measure the L
- Your body makes small amounts of L, but it’s usually just in the tissues
- L-BHB concentrates in the heart (30- 34%), and this appears to serve a beneficial effect
- Pharmaceutical companies are the ones that have reached out about this
- There’s quite a bit of patent literature
  - There are numerous patents on L-β-hydroxybutyrate now
  - There’s probably about three dozen patents on L now probably attributed to Dom talking about the effects

> “*However, I think Dr. Veech brought up a good point, and he was right in that D-beta-hydroxybutyrate is energetically favorable for producing ATP, but a D/L mixture is almost like you get the benefits of the D, and then you get the signaling benefits of the L*.”‒ Dominic D’Agostino

- Dom delivered that with the ketone diester and that gave remarkable results in seizure control in animal models of cancer [[2019 review](https://pubmed.ncbi.nlm.nih.gov/31680801/)]
- The industry is coming full circle: now you have L-enriched formulations with D-β-hydroxybutyrate

***Dom has always stuck with racemic mixtures because he knew there was fundamentally something interesting about both the D and L forms***

- When he used pure D-β-hydroxybutyrate, it trended toward making seizures happen faster (he doesn’t know why but speculates it’s reductive stress)
- This was Veech’s initial compound and Dom’s first attempt using the ester ‒ the mono-ester had no effect on seizures

## How ketosis may boost NAD, and why NAD supplements have fallen short so far [A: 1:16:30, V: 1:25:54]

Dom’s colleague [Dr. Jong Rho](https://medicine.yale.edu/ysm/profile/jong-rho/) said, “*You need to look at acetoacetate, and when you elevate β-hydroxybutyrate and acetoacetate in a 1:1 ratio, that creates a redox balance.*” (that’s important)

- Also when you rapidly spike D-β-hydroxybutyrate, you’re causing something called **reductive stress**
- You have the production of [NADH](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) from NAD, and that’s actually depleting NAD

**⇒** A ketogenic diet will boost your NAD

- You could take **NAD supplements**, and that’s something that Dom is working on too because he thinks a central mechanism in ketogenic diets and supplements is the elevation of NAD
  - He’s working with NAD compounds, but he can’t talk about that because it’s through an industry
  - But there are multiple compounds of stabilized NAD that have interesting and remarkable effects
  - Dom is working on combining them with various new ketone molecules

> “*NAD is sort of like this hub that is central player in the benefits of ketogenesis*.”‒ Dom D’Agostino

**What do you make of the fact that there hasn’t been any efficacy of NAD supplementation or even NAD precursors?**

- Peter points out that NR and NMN have really not yielded any meaningful or measurable benefits
- The only thing he’s ever seen that looked somewhat positive was in the [trial](https://pubmed.ncbi.nlm.nih.gov/30668199/) that looked at patients with ALS and you saw a slightly shorter time to ventilator use with an NR formulation
- We just haven’t seen any benefits,

*What do you attribute that to with respect to the NAD story and what do you think might be missing if, indeed, there’s efficacy there?*

- Dom is currently running experiments that he can’t discuss
- There are different stabilized forms of NAD molecules that are in clinical trials (phase 2, maybe phase 3 clinical trials)

**It’s a stability problem ‒ you have to stabilize NAD**

- Because when you consume it, the liver takes a lot of it
  - And if it doesn’t, you’re not taking enough of it in a stabilized form
- Actually, Dom thinks NAD would be good for [non-alcoholic fatty liver disease](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease)

**⇒** You have to take a dose that gets past the liver, into circulation and crosses the blood-brain barrier

- There’s a number of different stabilized versions of NAD that are in development and testing, and some of them Dom is working on that have potential for [treating] oxygen toxicity
  - He’s working on those now, giving them acutely and also chronically and graded doses

**Will there be other applications of stabilized NAD, such as the holy grail of geroprotection or even just physical performance enhancement?**

- Yes, Dom is convinced
- He wants to replicate some of the animal literature
- He has plans to do some exercise studies, oxygen toxicity studies, brain studies

**⇒** You need to give quite a bit of it in a stabilized form and it needs to get to the muscle

- Dom is very interested in crossing the [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier) and getting it into the brain
- He thinks these things will be more efficacious **in the context of energetic or metabolic stress**
  - For someone who’s already aged where your NAD level tanks (it goes down in a linear fashion like with age)
  - Also in the context of traumatic brain injury or shock (and these are the things that Dom studies)
- Dom is not studying NAD as a longevity molecule
- He’s studying in the context of rare disorders to military operational stress, extreme environments, things like that
- You have to do those studies and then you glean insights into that that can then translate into the world of longevity if you’re showing mitochondrial enhancements and preservation
- Because as we age and we go through different stress conditions, thats analogous to some of the things Dom studies
- Peter feels like the buzz over NAD has largely died
  - It under-delivered and most people aren’t talking about it anymore
- Some people say with keto

## Emerging evidence for using a ketogenic diet to treat anorexia and other psychiatric disorders [A: 1:20:30, V: 1:30:34]

**Ongoing trials with a ketogenic diet**

- Dom went to PubMed right before coming here
  - There are 6,000 peer-reviewed publications on [PubMed](https://pubmed.ncbi.nlm.nih.gov/?term=ketogenic+diet&sort=date) and 717 of them in the last year
  - There’s also 558 registered clinical trials on a ketogenic diet ([clinicaltrials.gov](https://clinicaltrials.gov/search?term=ketogenic%20diet))
  - If you look at CAR-T therapy, there’s maybe 4-500 [over 3,000 on [PubMed](https://pubmed.ncbi.nlm.nih.gov/?term=CAR-T+cell+therapy&filter=datesearch.y_1&sort=date), over 2,000 [clinical trials](https://clinicaltrials.gov/search?term=CAR-T%20cell)]

*Are those spread mostly between cancer and metabolic disease?*

- There’s 40-50 clinical trials on psychiatric disorders
  - That includes bipolar, schizophrenia, major depression, anxiety disorders, anorexia, alcohol use disorders, alcohol withdrawal, traumatic brain injury, autism

**Anorexia is quite interesting. What do you think is the hypothesis there?**

- [Anorexia](https://en.wikipedia.org/wiki/Anorexia_nervosa) is the psychiatric disorder with the highest mortality
- [Guido Frank](https://profiles.ucsd.edu/guido.frank) at UCSD is an expert in eating disorders
  - He’s running a study on anorexia that Dom can’t talk about, but some of the data is very encouraging
- Dom’s colleague [Dr. Deanna Rancourt](https://www.usf.edu/arts-sciences/departments/psychology/people/faculty/diana-rancourt.aspx) has peripheral interest in this
- There were case reports that combining a ketogenic diet with ketamine put anorexia into remission, and there’s been quite a bit of buzz about that
- For anorexia, typically you steer people away from any kind of dietary restriction

***But the effects of the ketogenic diet on neuropharmacology, on the hedonic response, on stabilizing your mood and other factors that could play into anorexia seem to be at play***

- Dom was super skeptical because it flies in the face of everything that he knew
- Deanna Rancourt at University of South Florida is one of the leading experts [on eating disorders], and Dom remembers talking to her about it and she was a little bit skeptical
- But the data coming out looks very promising and compelling
- There’s continuing emerging data on **psychiatric disorders**, largely funded by [The Baszucki Group](https://baszuckigroup.com/) ([Jan and David Baszucki](https://baszuckigroup.com/who-we-are/), their foundation)
  - Dom thinks they’re funding million-dollar studies
  - 6 of them are: Ohio State University, Stanford, Oxford, Stony Brook, UCSD, UCLA, maybe Edinburgh
  - They’re funding many different studies, mostly across severe psychiatric disorders

Peter asks, “*Are they doing this with ketogenic diets? Ketogenic diets plus supplements? Just supplements?*”

- Primarily the ketogenic diet
- Dom has served as a reviewer and quite a few studies will be incorporating exogenous ketone supplementation
  - They see that as an innovative approach and a necessary approach for the feasibility of therapeutic ketosis, because with a psychiatric disorder, it’s really difficult to get someone to adhere to a ketogenic diet with bipolar, with schizophrenia (it’s a nightmare)

## Potential cognitive and performance benefits of ketone supplementation, and why pushing ketones too high can be dangerous [A: 1:23:45, V: 1:34:18]

- People may understand why a ketogenic diet might have efficacy for **weight loss** (multiple mechanisms could explain it)
- There are undoubtedly thousands of people listening to us who have no interest in weight loss
- Some of the things Dom has talked about might’ve piqued their curiosity with respect to performance

**Can you get all the same benefits of a person who slaves their way through a very strict diet through judicious use of ketone supplements?**

- It depends (people don’t like that answer), it’s very context-dependent

> “*There are benefits that you get from carbohydrate restriction that cannot be replicated with exogenous ketone supplementation*.”‒ Dom D’Agostino

**⇒** With that said, exogenous ketone supplementation tends to **lower blood glucose** independent of carbohydrate restriction

**Is it part of the mechanism that you just described earlier where if you ingest enough ketones, you’re going to drive insulin enough that’s going to drive down glucose, which by the way would not be the most desirable way to lower glucose?**

- That’s what Dom originally thought
- He remembers talking to [Dr. Veech](https://ketonutrition.org/2020-2-11-tribute-to-dr-richard-veech/) about this and his opinion was that you’re **enhancing insulin sensitivity** and facilitating glucose disposal by virtue of enhancing insulin sensitivity
- Dom thinks it’s a combination of different factors

**⇒** Consuming exogenous ketones influences the liver in ways that we don’t understand

- The next big project that Dom wants to do is liver metabolomics giving exogenous ketones
- Because the liver is a master regulator of metabolism, especially in the context of everything Dom studies

***What Dom thinks is happening is that exogenous ketones are decreasing*** [***gluconeogenesis***](https://en.wikipedia.org/wiki/Gluconeogenesis)***, decreasing*** [***glycogenolysis***](https://en.wikipedia.org/wiki/Glycogenolysis)***, and also, simultaneously enhancing insulin sensitivity for greater glucose disposal***

- However, if ketones get too high, then you have competition [between fuels in the cell]
  - The tissues are basically happy with ketones and they probably decrease glucose consumption to some extent

**Dangers of higher levels of ketones**

Dom emphasizes, “*An important message that I want to send is that higher ketones are not advantageous, and I think potentially very problematic.*”

- Dom has killed quite a bit of animals inadvertently in early studies by putting them into [ketoacidosis](https://en.wikipedia.org/wiki/Ketoacidosis) with different ketone esters
- We’ve never done that with ketone salts, although, we can achieve therapeutic ketosis with ketone salts or [MCT](https://en.wikipedia.org/wiki/Medium-chain_triglyceride)
- High ketosis would be in animals once we get above 6 or 7 [mM]
  - Then they start hyperventilating
  - They get sluggish, and sometimes we can’t bring them back
- That has made Dom a bit scared about some of the ketone esters, and he thinks some of them could be in the bucket of a drug, especially if used in a pediatric population.

**⇒** If you’re jacking up your ketones, once you get above 2, 3, 4, and 5 mM you are approaching energy toxicity

- You have a level of ketones in your blood that’s producing energy toxicity

**Energy toxicity** is defined by an elevation of a metabolite circulating in your blood that is causing a number of things

- One is a counter regulatory reaction, which means it’s increasing the secretion of insulin
- And your kidneys have to dispose of that, and our blood gases and blood pH, blood pH will start to go down

***Your blood will become more acidic above a level of 2 mM of ketones (maybe 3 mM in the context of supplemental ketosis). That’s not a good thing***

- If you’re on a ketogenic diet and your glucose is so low, your levels of ketones may approach 3 or 4 because of the glucose deficiency that you have in your body
  - Fat oxidation is so high
- It’s a very elegant and finely tuned response that you have
  - It’s happening slowly enough that the redox reaction to balance your pH is happening
  - You’re going to blow off enough CO2 ‒ you have respiratory and renal compensation
- This does not apply to exogenous ketone salts because the salt is actually a natural buffer
  - The salt is the ionic bond; it is a positive and a negative [charge]

**⇒** When you consume large doses of β-hydroxybutyrate, it’s an [anion](https://en.wikipedia.org/wiki/Ion#Anions_and_cations) and you’re creating an acidic condition that your body needs to mitigate through respiratory and renal compensation

- That can be problematic, especially in elderly people purchasing ketone esters, where their liver function is not good, they’re not very stable, and they’re already under metabolically compromised situations

***Energy toxicity is something people don’t think about in the context of supplemental ketones***

- We think energy toxicity in the form of supplemental calories

## Applications for ketone esters, and why ketone salts or MCT-blended formulations may be safer and more practical for most people [A: 1:29:15, V: 1:40:25]

**Do you think there’s any meaningful application for a BHB monoester these days?**

- It’s context-dependent
- It can be given orally or theoretically IV in the context of acute situations

> “*I’m in favor of ketone esters and more potent ketone molecules for medical applications.*”‒ Dom D’Agostino

- For example, [status epilepticus](https://en.wikipedia.org/wiki/Status_epilepticus) or a traumatic brain injury from a blast

Peter asks, “*But I thought you said they didn’t work well in epilepsy.*”

- It depends
- Dom is talking about a **ketone diester of** [**acetoacetate**](https://en.wikipedia.org/wiki/Acetoacetic_acid)

*Peter is talking about the original molecules from the NIH that was a monoester of BHB*

- They can be formulated
- This comes to something that’s a gap in the literature
- There’s a gap because every company or university with IP wants to study a single molecule in isolation

Dom explains, “*I think what we need to do is actually formulate things, and that’s what we do.*”

***Every molecule will have pros and cons and caveats, and you could largely mitigate the problem with ketone esters by simply mixing it with*** [***MCT***](https://en.wikipedia.org/wiki/Medium-chain_triglyceride)

- You’re still going to have the 1-3-butanediol issue if you’re consuming that over long periods of time (that is something to consider)
- But you can also have a glycerol triester of β-hydroxybutyrate or acetoacetate

***The go-to for the average person would probably be the electrolyte salts***

- You want to stay in that sweet spot of 1-2 mM

**⇒** If you elevate β-hydroxybutyrate in the blood 1 mM, that represents a 10% increase of available energy to the brain

Lactate is also something to consider

- Lactate and ketones are used as alternative fuel for the brain

**Peter had George Brooks on the podcast a while ago, and he talked about how you could probably rescue concussion patients if you administered lactate quickly following a concussion**

*Would you say the same is likely true for ketones?*

- [George Brooks was the guest for [episode #312](https://peterattiamd.com/georgebrooks/)]
- Lactate is an incredible molecule
- Dom’s early studies in 2004-05 were on lactate, but the ketones represented a more viable option and also had the anti-seizure effects
- Plus, Dom was inspired by the work of [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.), [Dr. Veech](https://ketonutrition.org/2020-2-11-tribute-to-dr-richard-veech/), and [Theodore Van Itallie](https://ajcn.nutrition.org/article/S0002-9165(22)00994-7/fulltext),
- Dom was steered towards β-hydroxybutyrate

***Dom’s message is: formulation is the key***

**⇒** You have β-hydroxybutyrate, you have a lactate, you have MCTs cross the [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier)

- [MCTs](https://en.wikipedia.org/wiki/Medium-chain_triglyceride) are a type of fat that actually can cross the blood-brain barrier

**Do you still use MCTs for anything?**

- Dom thinks MCTs are great
- He uses a coffee creamer called [Keto Brainz](https://ketobrainz.com/products/keto-brainz-nootropic-creamer-30-servings?srsltid=AfmBOopU2JKS4bKINT2lgM1ZGhK57Yhxj8ILCLytsLFqIo66ik2rbd46&selling_plan=7889846527)
  - It’s a mixture of things: [alpha-GPC](https://en.wikipedia.org/wiki/Glycerophosphorylcholine), [L-theanine](https://en.wikipedia.org/wiki/Theanine), MCT

Dom explains, “*When you combine a ketone salt with MCT, then you have a formulation that stimulates your own ketone production while you’re delivering an exogenous ketone*.”

- If it’s a racemic D/L-β-hydroxybutyrate [KETOSTART](https://www.audaciousnutrition.com/products/ketostart-tropical), then you have a sustained ketone delivery system for half of the day
  - You just dose that a couple times
- Formulation can avoid some of the problems that we talked about with the fast entry of ketones into the bloodstream with the keto esters 1,3-butanediol
  - If you formulate that with MCT, you can mitigate some of the negative effects
  - Dom has [published](https://pubmed.ncbi.nlm.nih.gov/27999529/) on this ‒ it mitigated toxicity in animal models [additional studies linked in the “selected links” section at the end of these notes]

**⇒** The rate of rise of ketones is a trigger for some of the counter-regulatory effects; it’s more of a dosing issue

**Questions about** [**KETOSTART**](https://www.audaciousnutrition.com/products/ketostart-tropical)

- If you’re taking the formulated ketone salt [KETOSTART], you do not have to worry about the electrolyte load
- If you’re consuming 3 of those a day, that would be 3 g of additional electrolytes (in addition to what you’re getting in your food)

*Many people would say that’s too many electrolytes, but you’re not seeing the effect because of the lack of chloride?*

- Generally, it’s not a problem for people with normal physiology, even impaired kidney function
  - [KetoCitra](https://santabarbaranutrients.com/pages/ketocitra?srsltid=AfmBOoqAXWK3-M5h9smuVReFpeT7OMU15O4ytHmrg_vC3ZAK5x4fYfKM) is used in people with chronic kidney disease [technically not an electrolyte, but it has been used in studies to improve kidney function]
  - A [study](https://pubmed.ncbi.nlm.nih.gov/38095025/) just came out using β-hydroxybutyrate citrate and other electrolytes for kidney disorders [in a rat model of polycystic kidney disease]
- Dom was concerned that sodium would cause hypertension, but sodium chloride seems to be the major player there

***No, hypertension is not a concern, but also do your blood work***

- This was one of the early concerns Dom had and it steered him toward developing something other than a sodium salt (potassium, calcium, and others)

**⇒** Electrolytes are largely benign unless you’re above the 10 g per day

- Even with dietary sodium, the guidelines are something like 5 g of sodium per day, but something just came out that said it probably should be more like 8-10
  - [current [guidelines](https://www.fda.gov/food/nutrition-education-resources-materials/sodium-your-diet) recommend limiting sodium to <2.3 g per day]
  - Looser guidelines say it becomes problematic after 5 g per day [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/12/f13-DD.png)

**Figure 13. Salt consumption and guidelines**. Image credit: [*Nutrients* 2021](https://pmc.ncbi.nlm.nih.gov/articles/PMC8468043/#sec8-nutrients-13-03232)

## The role of a ketogenic diet in treating cancer [A: 1:34:45, V: 1:46:37]

**Say a word about what you think the future is for ketogenic diets in the treatment of cancer**

- Dom was an author on a review with 49 authors with the title, [*Clinical research framework proposal for ketogenic metabolic therapy in glioblastoma*](https://pubmed.ncbi.nlm.nih.gov/39639257/)
  - That includes basic scientists and a number of oncologists at major cancer centers
  - [Dr. Thomas Seyfried](https://www.bc.edu/bc-web/schools/morrissey/departments/biology/people/faculty-directory/thomas-seyfried.html) was the senior author (he was on the podcast in [episode #30](https://peterattiamd.com/tomseyfried/))
  - [Tomas Duraj](https://awareclinic.com/dr-tomas-duraj/) was the primary author
- It’s really important to focus on cancers where standard of care doesn’t work
  - Advanced metastatic cancer, obviously pancreatic and glioblastoma, but glioblastoma has always been the heart of what we’re studying

> “*The idea is to make metabolic therapy part of the standard of care.*”‒ Dom D’Agostino

- That review creates a framework for using ketone metabolic therapy for managing glioblastoma

Dom adds, “*We think similar reviews can be written for other types of cancers that are specifically, that are highly glycolytic and have the Warburg effect.*”

- This includes cancers that are really hot on an [FDG PET scan](https://www.mdanderson.org/cancerwise/standardized-uptake-value--suv--numbers-on-pet-scans--what-do-they-mean.h00-159698334.html) (above 2.5 SUVs would define it as hyperglycolytic)

**⇒** Achieve and maintain a glucose-ketone index (GKI) of 1, 2, 4 (GKI = mM glucose/mM ketones)

- For example, if your glucose was 4 mM (relatively normal) and your ketones were 1 mM, that gives a GKI of 4
  - This is where Dom is at now
- The standard American diet produces a GKI of 40 or 50
- The guidelines are for a GKI of 1-2, but Dom thinks that’s too strict

***Achieving a glucose-ketone index of 1-4 is the basis of the therapy, and that sets the stage for the other modalities to work***

- Then you want target glucose and glutamine with various drugs [this approach is summarized in the figure below]
- If we’re going to talk about anti-glycolytic drugs ([Metformin](https://en.wikipedia.org/wiki/Metformin)), we’ve done quite a bit of research with Metformin and it could be a synergizer

![](https://peterattiamd.com/wp-content/uploads/2025/12/f14-DD-1024x571.png)

**Figure 14. Overview of ketogenic metabolic therapy in glioblastoma**. Image credit: [*BCM Medicine* 2024](https://bmcmedicine.biomedcentral.com/articles/10.1186/s12916-024-03775-4)

**Is there any evidence that any form of a ketogenic diet (even at a 1:1 ratio of glucose to ketone) is going to produce a durable remission in a patient with** [**GBM**](https://en.wikipedia.org/wiki/Glioblastoma)**?**

- Peter points out that any patient who survives a glioblastoma has been misdiagnosed
  - They didn’t have glioblastoma

***No, it’s not going to cure it, but standard of care does nothing. We’re talking about doubling, tripling survival***

- The ketone metabolic therapy framework for GM is like the first document in a series of documents
- Ultimately version 3 will use AI platforms to decode the genetics

**In an RCT when you place full standard of care versus full standard of care plus ketogenic therapy, what is the difference in median survival?**

- Those studies are ongoing now
- [Dr. Jethro Hu](https://researchers.cedars-sinai.edu/Jethro.Hu/about) at UCLA [at Cedars-Siani] just published a [study](https://pubmed.ncbi.nlm.nih.gov/40595067/) that showed improved metrics of survival and increased quality of life

***That research is ongoing, and there’s at least a half dozen clinical trials in progress now***

**But there’s problems with those clinical trials that prevents us from getting to the question**

- No clinical trial yet has achieved and maintained a glucose-ketone index [GKI] of 1-4

**Once you maintain a GKI of 1-4, then you go and aggressively target glucose and glutamine**

- You could target glucose with:
  - [Lonidamine](https://en.wikipedia.org/wiki/Lonidamine) (an inhibitor of [hexokinase](https://en.wikipedia.org/wiki/Hexokinase))
  - [3-bromopyruvate](https://en.wikipedia.org/wiki/Bromopyruvic_acid)
  - [2-Deoxy-glucose](https://en.wikipedia.org/wiki/2-Deoxy-D-glucose)
  - An [SGLT2 inhibitor](https://en.wikipedia.org/wiki/SGLT2_inhibitor)
  - We have about two dozen different drugs that you could use
- And then you want to target glutamine, because you could take glucose out of cell media and put in glutamine and maintain cancer cells in glutamine without glucose
- Peter thinks it’s hard to imaging that you’re ever going to get glucose to less than 40% of the brain’s fuel (which would be a big achievement)
  - You ramped up ketones, you took glucose down peripherally to 2.5 or 3 mM
  - If you have a glucose-ketone index of 1.1 and they’re both sitting at 3 mM, then you’re doing all those therapies, the neurons are still getting 40-50% of their energy from glucose
- The idea is to use something like lonidamine to inhibit hexokinase II
- There are glycolytic enzymes and transporters that are upregulated, and if you create an energy crisis in GBM cells that’s great enough, then you trigger autophagy and cell death

***There’s an incredible glycolytic energetic demand in glioblastoma cells, and if that’s not met, then that triggers cell death pathways***

Dom explains, “*But to make inroads into that and create that energetic crisis, you have to decrease glucose availability, decrease circulating insulin, which decreases growth factors like IGF-1 and a whole host of other mTOR and other growth factors, and then aggressively target pharmacologically circulating glucose and glycolytic enzymes. And then you have to aggressively target glutaminolysis circulating glutamine.*”

Drugs that inhibit glutamine metabolism in cancer cells

- There’s a drug [DON](https://en.wikipedia.org/wiki/6-Diazo-5-oxo-L-norleucine) that Dr. Seyfried [uses](https://pubmed.ncbi.nlm.nih.gov/31149644/), and Dom has not used, but he has talked to some patients that use it
  - It does cause some GI stress
  - That’s a pretty big heavy hitter
- Other drugs include [sodium phenylbutyrate](https://en.wikipedia.org/wiki/Sodium_phenylbutyrate)
  - [Glycerol phenylbutyrate,](https://en.wikipedia.org/wiki/Glycerol_phenylbutyrate) which will [bind up glutamine](https://www.ncbi.nlm.nih.gov/books/NBK476305/#:~:text=Prodrug%20metabolized%20to%20phenylacetate%2C%20which%20conjugates%20with%20glutamine%20to%20form%20phenylacetylglutamine%20to%20be%20excreted%20by%20the%20kidneys%2C%20providing%20another%20route%20of%20nitrogen%20elimination.) and then you pee some of it out
  - There’s [EGCG](https://en.wikipedia.org/wiki/Epigallocatechin_gallate)
  - [Curcumin](https://en.wikipedia.org/wiki/Curcumin)
  - [Quercetin](https://en.wikipedia.org/wiki/Quercetin) has glutaminase inhibiting properties

Peter points out, “*But again, none of this has been demonstrated clinically. This is all kind of anecdotal, meaning we don’t have evidence in a clinical trial that this works. We’re sort of extracting mechanistically from what we think these things do.*”

- No, there’s RCTs, cell data, animal data

**What’s the holdup?**

- Peter interviewed [Tom](https://www.bc.edu/bc-web/schools/morrissey/departments/biology/people/faculty-directory/thomas-seyfried.html) 7 years ago [[episode #30](https://peterattiamd.com/tomseyfried/)] and they had this exact same conversation

*Why is it so hard to do these trials?*

- Especially for these cancers that are basically just killing machines, people are dead within a year of diagnosis
- Dom is super frustrated and that’s what motivates him
- He would encourage people to read that [framework of the ketone](https://bmcmedicine.biomedcentral.com/articles/10.1186/s12916-024-03775-4) [therapy for GBM]
  - And it’s really important to access the [supplementary information](https://bmcmedicine.biomedcentral.com/articles/10.1186/s12916-024-03775-4#Sec31), which gives all the different drugs and everything

Peter asks, “*Oncologists are not going to read that, right? (the people that are on the front lines that are taking care of these patients)*”

- Some of them are authors, so they have read it

Peter reiterates that what they want and need is a clinical trial that says, “*This stack of interventions is going to double median survival.*”

- It would become standard of care
- But the trial has to be done

Dom asks the question, “*Who is going to fund this clinical trial?*”

- The policymakers and the people at the foundations, people at the federal government, the NIH, the DOD, they have to be convinced that this is going to work
- We’re talking about something way beyond the ketogenic diet here
  - We’re talking about a very comprehensive, calculated metabolic-based intervention that targets diet, glycolytic drugs, anti-glutamine drugs
  - And then there’s a redox component too
  - So it’s synergized with different drugs
  - That could be hyperbaric oxygen therapy (radiation and chemo kill cancer cells through oxidative stress)
- The other thing is where the money is actually going to come from
- The focus now has been using ketone metabolic therapy as an adjuvant for [Moffitt Institute](https://www.moffitt.org/treatments/immunotherapy/car-t-therapy/car-t-clinical-trials/) CAR T therapy for lymphoma
  - But just working on some grants for ketone metabolic therapy, and it’s strictly their focus on β-hydroxybutyrate because that correlates with the adaptive immune response that will augment checkpoint inhibitors (specifically [PD-1 inhibitors](https://en.wikipedia.org/wiki/PD-1_and_PD-L1_inhibitors) and [CTLA-4 checkpoint inhibitors](https://en.wikipedia.org/wiki/Checkpoint_inhibitor))
  - And also the ketogenic diet, specifically β-hydroxybutyrate correlated with expansion of [CAR T cells](https://en.wikipedia.org/wiki/CAR_T_cell)
- So right now, the funding agencies are kind of focused on augmenting the standard of care because we already use the standard of care

**What is needed to run a clinical trial with dietary therapies involved**

- You have to have oncologists who are savvy and knowledgeable about ketogenic diets
- You have to have an RD team
- The inclusion-exclusion criteria are really important
  - The heterogeneity of many people with brain tumors is something to consider
- Also, when you have a patient with a glioblastoma, the pharmaceutical companies are scrambling to get their drug into that patient
  - They are paying a lot of money to the major institutes to conduct the research

Peter asks, “*Is GBM the wrong model then? Because you need a win.*”

- Yeah
- You’ve got to demonstrate a win
- Should the first one be [pancreatic adenocarcinoma](https://en.wikipedia.org/wiki/Pancreatic_cancer)?
  - You have far more patients
  - Life expectancy is a little bit longer, but it’s equally fatal, meaning advanced pancreatic cancer is uniformly fatal
- Look, all cancers are heterogeneous, but it might be that GBM is even more so
- And it’s also heavily impacted by the radiation
  - The radiation then completely changes it
  - Virtually all of these patients are going to need radiation, which makes it even more difficult
  - Peter doesn’t want to offer advice on this, but that might be something worth considering

## The potential of a ketogenic diet for treating Alzheimer’s disease [A: 1:45:45, V: 1:59:31]

- [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) is equally devastating, with a much longer tail
- In Peter’s mind it seems somewhat easier to address through metabolic therapies because, at least in the subset of those patients for whom an energetic crisis is at the core
  - He doesn’t think that that’s true for all cases, he thinks that’s also a very heterogeneous disease
  - But at least one subset of these people are probably in an **energetic crisis**

**What do we know about the current research and what’s the current state of affairs for using ketogenic therapies?**

- There’s not been a whole lot of movement with the Alzheimer’s drugs
- Antibody therapy costs at least $50k, and you have the potential for side effects like cerebral hemorrhage

***They need to move the needle for prevention***

**Characteristics of Alzheimer’s disease**

- A hallmark characteristic of Alzheimer’s disease is [glucose hypometabolism](https://pmc.ncbi.nlm.nih.gov/articles/PMC10453773/), and that is being part of the criteria for evaluation
- Let’s call it dementia, because Alzheimer’s is still a pretty fuzzy diagnosis
  - Clinically, we have [PET scans](https://alz-journals.onlinelibrary.wiley.com/doi/full/10.1002/alz.14338) to look at amyloid and then [p-tau](https://alz-journals.onlinelibrary.wiley.com/doi/full/10.1002/alz.14508) and other things
- It’s better to focus on mild cognitive impairment (MCI) and advanced Alzheimer’s disease

***A ubiquitous characteristic is glucose hypometabolism***

Dom shares, “*I’ve always been under the impression that the accumulation of amyloid and tau are a consequence, are a downstream epiphenomenon of neuro-inflammation.*”

**There are many genes that can cause Alzheimer’s disease**

- An [*APOE4*](https://en.wikipedia.org/wiki/Apolipoprotein_E#E4) carrier is 80% likely to get Alzheimer’s disease, if they have 2 copies
  - <40% of those who have 1 copy get Alzheimer’s disease
  - About 25% of the population has 1 copy, and their risk is 2-fold higher (no one would consider that destiny)
- There’s [variants of] a handful of genes in which you are destined to get it: [*PSEN1*](https://en.wikipedia.org/wiki/Presenilin-1#Alzheimer's_disease)*,* [*PSEN2*](https://en.wikipedia.org/wiki/Presenilin-2)*,* [*APP*](https://en.wikipedia.org/wiki/Amyloid-beta_precursor_protein)

> “*Destined to get it is a strong word. If you do nothing*.”‒ Dom D’Agostino

***Dom thinks inflammation is a major driver of disease, and that wasn’t even on his radar 10 years ago***

- Systemic inflammation leads to neuro-inflammation
- We know that if we take mice and inject [LPS](https://en.wikipedia.org/wiki/Lipopolysaccharide), we can rapidly cause amyloid progression

**⇒** ***Metabolic based therapies, ketogenic therapies, diet, these things not only change metabolic physiology and brain energy metabolism, but they reduce systemic inflammation***

- [Peter’s recent [newsletter](https://peterattiamd.com/bd-for-neuroprotection/) highlighted the [finding](https://pubmed.ncbi.nlm.nih.gov/39693909/) that supplementing with exogenous ketones reduced inflammatory signals in the brain and appeared to play a neuroprotective role in healthy rats]
- Dom measures his inflammatory markers like [hs-CRP](https://en.wikipedia.org/wiki/C-reactive_protein)
  - His is non-detectable, and he’ll even do things like work out really hard
  - It was only elevated when he lived in an undersea environment and was breathing [hypercapnic](https://en.wikipedia.org/wiki/Hypercapnia) under a lot of stress

Dom explains, “*I think the advantage of ketogenic metabolic therapies for Alzheimer’s disease is really hinging upon suppressing inflammation, improving glucose metabolism, and elevating ketones to increase symptomatically brain energy metabolism.*”

**Of those, would you say that the latter is the most important?**

- Peter wonders if it’s the alternative fuel source that is the most important

**Has someone done the experiment where you take people in the earliest stages of dementia or in modest stages of MCI (mild cognitive impairment), who are progressing towards dementia and you randomize them to standard of care versus the exact same standard of care plus a KD? Has that experiment been done cleanly in a randomized fashion?**

- Peter thinks this is a much easier thing to test, and he wonders if it’s been done cleanly in a randomized fashion

***Those experiments (like many things), are ongoing***

**⇒** Acute effects: if we elevate ketones in the context of a cognitive deficit, we can improve cognition under a battery of different exams

- But the question that investigators are after is that if you do an amyloid PET scan, at baseline, and 2 years, 5 years, 10 years ‒ that is of the highest interest
- Because amyloid is basically the prerequisite for having Alzheimer’s disease
- Those studies are ongoing, and Dom is connected with some investigators that are doing it and some that have done more acute studies

***The feedback is: most people respond favorably, but there’s also a subset of people that are hyper-responders***

And with Alzheimer’s disease, there’s [vascular dementia](https://en.wikipedia.org/wiki/Vascular_dementia)

- It could be a blood flow problem
- It could be an excess glutamate problem
- It could be a number of different things that are amenable to being reversed or mitigated through ketone metabolic therapies

***Patient selection for these studies is going to be huge***

- Dom doesn’t think that’s been done yet
- The **inclusion criteria** should be patients that present with remarkable glucose hypometabolism
- The [amyloid hypothesis](https://en.wikipedia.org/wiki/Biochemistry_of_Alzheimer%27s_disease#Amyloid_hypothesis) has a lot of baggage with it
- There’s people who have brains that are chock-full of amyloid are completely sharp and are completely normal
- Other **biomarkers**: we have [p-tau](https://alz-journals.onlinelibrary.wiley.com/doi/full/10.1002/alz.14508) that we can look at

- There’s other **therapeutics** in the pipeline: the [p75 receptor](https://en.wikipedia.org/wiki/Low-affinity_nerve_growth_factor_receptor) agonist or amplifier [looks](https://www.alzheimers.gov/news/new-drug-candidate-targeting-synaptic-resilience-well-tolerated-alzheimers-patients) pretty promising (those studies are ongoing)
- For prevention, the **antibodies** do have applications, but they also come with a lot of baggage
  - Not only the cost and accessibility, but cerebral hemorrhage

**The low hanging fruit for this population would be a ketone metabolic therapy intervention**

- That could be a ketogenic formula that could also have a number of different co-factors and other things
  - There’s [lactate](https://en.wikipedia.org/wiki/Creatine)
  - There’s [creatine monohydrate](https://en.wikipedia.org/wiki/Creatine)
  - There’s [⍺-ketoglutarate](https://en.wikipedia.org/wiki/%CE%91-Ketoglutaric_acid)
- This is a problem with funding agencies: they don’t want to fund a formula

**Work with medium-chain triglycerides (MCT)**

- There’s some work done with MCT: [Sam Henderson](https://www.linkedin.com/in/samuel-henderson-806b984a/)[published](https://pmc.ncbi.nlm.nih.gov/articles/PMC2731764/) in 2008 when the molecule was AC-1202
  - But if you look at the patent, it was just [caprylic triglyceride](https://pmc.ncbi.nlm.nih.gov/articles/PMC2731764/#:~:text=AC%2D1202%20is%20a%20medium%20chain%20triglyceride%20composed%20of%20glycerin%20and%20caprylic%20acid%20(C8%3A0))
  - And it actually improved the mini mental status exam
- [Dr. Mary Newport](https://www.linkedin.com/in/mary-newport-md-226b3479/) saw that and gave her husband coconut oil and [MCT oil](https://en.wikipedia.org/wiki/Medium-chain_triglyceride) and he improved
  - The [case report](https://pubmed.ncbi.nlm.nih.gov/25301680/) with [Dr. Veech](https://ketonutrition.org/2020-2-11-tribute-to-dr-richard-veech/) being one of the co-authors on that was published
  - They just followed a ketogenic intervention
  - That was the longest case report for years
  - It followed his progression and stabilization
  - He ended up succumbing to the disease, but she got many more years with him through ketogenic intervention

Dom’s takeaway, “*I think we have to think about putting together a comprehensive metabolic based formula*.”

- [Dale Bredesen](https://www.pacificneuroscienceinstitute.org/people/dale-bredesen/) has been spearheading some things and looking at more of a comprehensive approach
- [Dr. Stephen Cunnane](https://recherche-cerveau-sherbrooke.ca/en/laboratory-team/) has been working on MCTs and other ketogenic agents for Alzheimer’s
  - He also did a [dual PET scan](https://pubmed.ncbi.nlm.nih.gov/28709938/) where you do a glucose ketone PET scan, and showed and published that as we age, our capacity to use glucose decreases over time, but that does not happen with ketones

**⇒** Our brain’s ability to use ketones over time is preserved [as we get older]

- So that’s an important distinction and a good foundational framework for the rationale for doing ketone metabolic therapy
- [Dom’s [review](https://pubmed.ncbi.nlm.nih.gov/35004814/) on the benefits of ketone supplementation for the brain]

***Dom thinks you’ll probably have more benefit by thinking about it as a comprehensive metabolic therapy where you can target different things***

- There’s a number of different molecules like [alpha-GPC](https://en.wikipedia.org/wiki/Glycerophosphorylcholine), but no one does anything with formulations

## Tools for cognitive enhancement: ketones, alpha-GPC, MCT, caffeine, strategic fasting, and more [A: 1:53:45, V: 2:09:45]

**What do you think is the state of the art with alpha-GPC, just in general, for normal cognitive enhancement?**

- It’s hard to know because Dom always takes it with something else
- When he used it by itself it gave him a headache
- Dom thinks it has the ability to be beneficial in the context of cognitive deficit
  - Like many things; like ketones are
- Everything that he studies is in the context of environmental stress or some kind of deficit, and that’s where ketones shine

***Speaking personally, Dom thinks they give you an extra boost because they’re a source of energy***

*What do you think they’re best taken with?*

- Alpha-GPC works well with caffeine
- So alpha-GPC, MCT, and caffeine, and maybe theanine too has a little bit of a [GABAergic](https://en.wikipedia.org/wiki/GABAergic) effect
- That describes a product called [Keto Brainz](https://ketobrainz.com/products/keto-brainz-nootropic-creamer-30-servings?srsltid=AfmBOopU2JKS4bKINT2lgM1ZGhK57Yhxj8ILCLytsLFqIo66ik2rbd46&selling_plan=7889846527)
  - That’s a pretty good product that is kind of a staple for Dom
  - It’s what he puts into his coffee when he’s working on grants or giving lectures or just needs long periods of cognitive [work]
- The alpha-GPC may make him a little bit too stimulated and it might affect his sleep
- Dom uses that situationally, just as he now uses fasting now

**Dom recommends that people use fasting situationally**

- It shouldn’t be your default
- The more you do it, the easier it gets

***You can maybe derive more benefits situationally if you have an inflammation event***

- For example, 2 people reached out to him who have a [shingles](https://en.wikipedia.org/wiki/Shingles) or a [herpes simplex](https://en.wikipedia.org/wiki/Herpes_simplex_virus) flare up and fasting works for that
  - Or they have some kind of GI issue
  - Or if they’re traveling
  - Or for Dom, when he’s just bogged down with a lot of paperwork, grant reviews, writing grants or something, he’ll fast for half of the day (or more of the day) and he finds that he’s sharper, but he only uses it situationally

## Hyperbaric oxygen therapy for concussion, TBI, PTSD, and cognitive function, including protocols and dosing approaches [A: 1:55:30, V: 2:11:26]

- To Peter, the 2 most apparent indications for hyperbaric oxygen would be as treatment of the bends and for burn patients

**⇒** [Hyperbaric oxygen](https://en.wikipedia.org/wiki/Hyperbaric_medicine) dramatically aids with wound healing

- But there are many things that are conspicuously absent from any FDA approval
  - There’s no FDA approval for [TBI](https://en.wikipedia.org/wiki/Traumatic_brain_injury)
  - There’s no FDA approval for [concussion](https://en.wikipedia.org/wiki/Concussion)
  - There’s no FDA approval for anything geroprotective
- Yet every time Peter has gone back and looked at the data around concussion and TBI, there seems to be a case for it
  - It depends how you look at the data
- Patients are always asking him about hyperbaric oxygen
  - It’s one of the things he gets asked about the most
- Peter generally tells patients that it’s not worth the cost, the hassle, the inconvenience
- Outside of the approved FDA indications, the only thing he would suggest going against the FDA recommendation is if he were to have a concussion

Peter adds, “*If one of my kids had a concussion, I would probably say the downside of hyperbaric oxygen is low enough. I think the potential upside is there. I think it’s worth the risk.*”

**First of all, do you agree with that statement? If not, modify it.**

***In the context of an acute concussion, within the first 48-72 hours, Dom thinks hyperbaric oxygen can be remarkable effective for the younger population (kids), and probably effective for adults if given early***

- He would go with the **standard protocol**: 2 atmospheres of oxygen, 60-90 minutes, 5 days a week (minimum 3 days a week) for 40 total sessions
  - That’s a lot; you’re talking about 2 months
- You can understand why Peter doesn’t recommend people do this
  - That’s a job
  - If you’ve got to drive 30 minutes each way, spend 90 minutes in it (that’s 2.5 hours), 5 days a week for 6 weeks [possibly longer, because that’s only 30 sessions]
  - It’s an insane commitment
- Peter is on the fence on this particular indication; he can’t make that much time to do anything in his life
- There are some gyms that have **soft chambers**
  - There’s more buzz about it with people biohacking
  - A soft chamber can get to about 1.3 atmospheres of oxygen
- That might be a good place to start: if you have a mild concussion or want a mild hyperbaric oxygen protocol
  - 1.3 atmospheres, 3x per week, for 2 weeks or something
  - Dom is just speculating
  - He would expect a minimum of 20 sessions, but would really want to get you in for 40 sessions
- Dom has been a reviewer on a variety of different publications (systematic reviews, etc.)
  - He’s been on top of this field

**⇒** There’s data that suggest that even if you had **traumatic brain injury years ago**, hyperbaric oxygen increased cognitive function and pretty much all metrics of cognition

- The protocol was 40-60 sessions, 1.5-2 atmospheres of hyperbaric oxygen

**There’s a community called The Villages, and a clinic there called the** [**Aviv Clinic**](https://aviv-clinics.com/hyperbaric-centers/villages-florida/)

- They’re not publishing much, but they’ve treated at least 100,000 patients
- They have convincing data showing remarkable **increase in cognitive function in elderly** people
  - People who don’t have TBI
- Cardiometabolic biomarkers are improving over time, like glucose control
  - Dom is a little bit skeptical on that, but he does see in his animals sometimes that they go hypoglycemic when we pull them out [of the hyperbaric chamber]
  - Peter suggests the glucose control could be because they’re spending 10 hours in chamber a week not eating while they’re in there
  - Oxygen increases metabolic activity too

**Studies of hyperbaric oxygen therapy**

- The DOD funded a [study](https://pubmed.ncbi.nlm.nih.gov/22908837/) where they did hyperbaric oxygen and the control was hyperbaric air
  - Hyperbaric oxygen is 100% oxygen
  - [a published [critique](https://pmc.ncbi.nlm.nih.gov/articles/PMC3837504/#B10) of this study]
- Peter points out that you’re still getting hyperbaric exposure to 20% oxygen [in this control/sham group]
- Dom agrees
  - The control was just hyperbaric pressure, and both groups got benefits
  - There’s a lot of muddy waters
- The DOD wants to put a nail in this coffin
- They funded the University of South Florida (USF, where Dom is) [[link to the clinical trial](https://hbot.usf.edu/)]
  - The university has 6 beautiful chambers in a facility that’s run by the neurosurgery and neuroscience department
  - Dom’s friend [Dr. Joe Dituri](https://www.usf.edu/engineering/bme/faculty-staff/joseph-dituri.aspx) runs the facility which is doing this work
  - They have subjects with [PTSD](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder) and also subjects with brain injury, but it’s more of a PTSD trial
  - The sham [control] is that they pulse the pressure during the initial compression to make you think like you’re undergoing pressure, but they keep it at 1 atmosphere, and at the end with the decompress, they pulse it so you feel it a little bit

Peter asks, “*Why PTSD as opposed to TBI?*

- It’s brain injury PTSD
- These 6 chambers are active from morning till night
- It’s a $30 million project that has all the right controls
  - All the right people involved and multiple institutes collaborating
  - It’s still [enrolling](https://hbot.usf.edu/)

Peter asks, “*When does it read out?*”

- Preliminary data should be coming out within the next year
- And if people do get a benefit from it and they’re in the sham group, or if they’re in the hyperbaric group, they’re going to give them access to that
  - They’re going to cross it over
- It’s going to become a treatment center
- Dom was not actively involved in the initiation of that
  - Maybe because he studies the negative effects of hyperbaric oxygen
  - But he’s been peripherally involved, and he’s been inspired by the work they’re doing

> “*I’ve been inspired by the work that they’re doing and the level of scientific rigor that they’re using to approach this question of the potential neuroregenerative and cognitive, even mental health effects, of hyperbaric oxygen.*”‒ Dom D’Agostino

***Benefits of hyperbaric oxygen have been reported anecdotally, but they have not been systematically studied in this rigorous way (that project is ongoing right now)***

- In addition, Dom has reviewed some papers that will be coming out on work that has been done which suggests that if you had traumatic brain injury years ago and you go into chambers and you use a rigorous method [it provides benefit]
  - The only thing is they did not have a sham control
- It’s hard to do a control, but they’ve figured out a way to do it at USF and they have a person that comes in to question the patient and figure out if they’re lying or not about the control
  - Like, “*Did you experience it?*”
  - And basically all the subjects getting the sham have no idea if they got sham or treatment
  - That type of control has never been done before
  - And just the sheer number of people that are going to be treated (all veterans)

## Peter’s takeaways, recommended products, and additional resources to learn more [A: 2:03:00, V: 2:20:30]

**Peter’s takeaways**

- There have been a lot of things that unfortunately haven’t changed fast enough since they last spoke
  - Namely around our insights around cancer and Alzheimer’s disease, largely due to a lack of clinical trials
- But the unbelievable change in exogenous and supplemental ketones, it’s exploded
  - And Dom has been leading the charge in that
- It gives Peter a lot of hope
- Long ago he’s given up on the discipline of a ketogenic diet, although he achieved remarkable benefit from it
  - But something just changed when his daughter was old enough and Peter just wanted to start eating everything, and that hasn’t vanished
  - He’s on the “see food” diet
- Dom distinctly remembers going to the gym with Peter and the amount of volume he would do, or just riding the bike or swimming (it was crazy)

Dom has really piqued Peter’s curiosity about these exogenous ketones

- In addition to the one he’s just started putting in his coffee, he’s going to give these salts a try
- They didn’t speak about it today, but there aren’t the same GI consequences that used to exist with ketone salts
  - Which largely limited their consumption

**⇒** You can buy [KETOSTART](https://www.audaciousnutrition.com/products/ketostart-tropical) by Audacious Nutrition directly from them or on [Amazon](https://www.amazon.com/Audacious-Nutrition-KetoStart-Exogenous-Electrolytes/dp/B0B5Y8744Q/ref=sr_1_1?crid=2R96S6WMFWGM0&dib=eyJ2IjoiMSJ9.gCs-B2USRcol6tYUrXJcDkHMFgHW3seaQaK5ChQWp_cYFa1P1Nw90RW2iCxIJFrBYRI8YRRqjnQSiX3VB-zOHqoxhVcUkzk03k0NH8osPD1ryaQSCJ1_DTsvis2i6LgcdG715GoIcQgXCt-5X1gCx4knHX20u2A30aCd9RR7t5h50pWNJqyoG5h6WI9G1e3q.2kpW_pAs5lxRzXC6Vzc_dZpaWFmUtfeEAHjRHZZjXWs&dib_tag=se&keywords=ketostart%2Baudacious%2Bnutrition&qid=1757531001&sprefix=ketostart%2Baudacious%2Bnutrition%2Caps%2C99&sr=8-1&th=1)

- This is what Dom uses
- It evolved out of the molecules that Dom originally studied and stuck with
- Dom is not involved financially with this company, though his wife advises them
  - He’s on the sideline
  - He doesn’t have any brands or sell anything; he doesn’t have any companies

**Dom’s disclosures**

- Dom advises for Levels and for Metro International Biotech

**Where to learn more**

- Dom has an informational website: [KetoNutrition](https://ketonutrition.org/)
- The big thing he’s involved in is [*The Metabolic Link*](https://membership.metabolicinitiative.com/podcast-pre-login) podcast [on [YouTube](https://www.youtube.com/@MetabolicHealthSummit/podcasts)], and the [Metabolic Health Initiative](https://www.metabolicinitiative.com/), which is an ACCME-accredited medical education platform
  - The Metabolic Health Initiative is a platform that is associated with the podcast
  - They have educational information where we have doctors, neuroscientists, cardiologists, oncologists, and doctors that treat metabolic disorders give lectures on this
  - And so you can get medical education and learn about ketogenic
  - It meets the ACCME bar of standards
- It’s also associated with the [Metabolic Health Summit](https://metabolichealthsummit.com/)
  - Many people on *The Drive* podcast have spoken at the summit
  - That was in Clearwater, FL, and they’re regrouping and figuring out what its future will be
  - There’s really no experience that can mimic an in-person event
  - It’s where you can network with people in basic science and clinical science
  - A big focus is having patients talk and talking about the implementation strategies

**Resources**:

- The Metabolic Link Podcast on all major players: <https://themetaboliclink.buzzsprout.com>
- The Metabolic Link on YouTube: <https://www.youtube.com/@MetabolicHealthSummit>
- The Metabolic Initiative (Medical Education Platform): <https://membership.metabolicinitiative.com>
- Metabolic Health Initiative Website (The Metabolic Link, Metabolic Initiative, Metabolic Health Summit): <https://www.metabolicinitiative.com>

**Social Channels**:

- Instagram
  - Metabolic Health Summit: <https://www.instagram.com/metabolichealthsummit/>
  - The Metabolic Link: <https://www.instagram.com/themetaboliclink>
  - Metabolic Health Initiative: https://www.instagram.com/metabolicinitiative
- Facebook: <https://www.facebook.com/metabolichealthsummit>
- X: <https://x.com/MetabolicSummit>
- LinkedIn: <https://www.linkedin.com/company/metabolichealthsummit>
- TikTok: <https://www.tiktok.com/@themetaboliclink?_r=1&_t=ZP-91yPwV4Pmql>

---

## Selected Links / Related Material

**Episodes of** ***The Drive*** **with Dom**: [3:00]

- [#05 – Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer](https://peterattiamd.com/domdagostino/) (July 16, 2018)
- [#116 – AMA with Dom D’Agostino, Ph.D., Part I of II: Ketogenic diet, exogenous ketones, and exercise](https://peterattiamd.com/domdagostinoama01/) (June 22, 2020)
- [#120 – AMA with Dom D’Agostino, Ph.D., Part II of II: Ketosis for cancer and chronic disease, hyperbaric oxygen therapy, and the effect of ketosis on female health](https://peterattiamd.com/domdagostinoama02/) (July 20, 2020)

**FDA-approved applications of hyperbaric oxygen therapy**: [Hyperbaric Oxygen Therapy: Get the Facts](https://www.fda.gov/consumers/consumer-updates/hyperbaric-oxygen-therapy-get-facts) | U.S. Food & Drug Administration (2021) | [7:45]

**Latency to oxygen toxicity seizure when under ketosis**: [13:45]

- [Therapeutic ketosis with ketone ester delays central nervous system oxygen toxicity seizures in rats](https://pubmed.ncbi.nlm.nih.gov/23552496/) | *American Journal of Physiology* (D. D’Agostino et al. 2013)
- [Delaying latency to hyperbaric oxygen-induced CNS oxygen toxicity seizures by combinations of exogenous ketone supplements](https://pubmed.ncbi.nlm.nih.gov/30604923/) | *Physiological Reports* (C Ari et al. 2019)
- [Exogenous ketone ester delays CNS oxygen toxicity without impairing cognitive and motor performance in male Sprague-Dawley rats](https://pubmed.ncbi.nlm.nih.gov/34132115/) | *American Journal of Physiology. Regulatory, Integrative, and Comparative Physiology* (N Stavitzski et al 2021)

**Content on** [**PeterAttia.MD**](http://peterattia.md) **on ketosis**: [Ketosis](https://peterattiamd.com/category/ketosis/) | [15:30]

- [Is ketosis dangerous?](https://peterattiamd.com/is-ketosis-dangerous/) (December 2, 2011)
- [The interplay of exercise and ketosis – Part I](https://peterattiamd.com/the-interplay-of-exercise-and-ketosis-part-i/) (March 7, 2012)
- [The interplay of exercise and ketosis – Part II](https://peterattiamd.com/the-interplay-of-exercise-and-ketosis-part-ii/) (March 14, 2012)
- [Ketosis: Advantaged or Misunderstood State? (Part I)](https://peterattiamd.com/ketosis-advantaged-or-misunderstood-state-part-i/) (April 23, 2018)
- [Ketosis – Advantaged or Misunderstood State? (Part II)](https://peterattiamd.com/ketosis-advantaged-or-misunderstood-state-part-ii/) (January 1, 2013)
- [Ketones and Carbohydrates: Can they co-exist?](https://peterattiamd.com/ketones-carbohydrates-can-co-exist/) (August 13, 2013)
- [My experience with exogenous ketones](https://peterattiamd.com/experience-exogenous-ketones-2/) (June 12, 2018)
- [The keto buffet](https://peterattiamd.com/the-keto-buffet/) (July 15, 2018)
- [Ketogenic Diets: Not For Everyone?](https://peterattiamd.com/ketogenic-diets-not-for-everyone/) (December 5, 2021)

**Episode of** ***The Drive*** **with Donald Layman**: [#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.](https://peterattiamd.com/donlayman/) (September 26, 2022) | [26:15]

**App for nutrition tracking for ketone diet**: [Carbon](https://www.joincarbon.com/) (2025) | [27:15]

**Devices to measure ketones in your breath**: [28:00]

- [Biosense](https://mybiosense.com/order.html)
- [KetoAir](https://ketoair.us/)

**Continuous ketone monitor**: [29:00]

- [SiBio](https://www.sibiosensor.com/)
- [FreeStyle Optium Neo](https://www.freestyle.abbott/ie-en/products/bgm/freestyleoptiumneo.html) (Abbott)

**Books for guiding a clinical ketogenic diet**: [32:00]

- [Ketogenic Diet Therapies for Epilepsy and Other Conditions, Seventh Edition](https://www.amazon.com/Ketogenic-Therapies-Epilepsy-Conditions-Seventh/dp/0826149588/ref=sr_1_1?crid=3S48ALS12AUP8&dib=eyJ2IjoiMSJ9.3hMoiVO55NO2tG-nG8ta9hcbW9DjByPem141xwoSJ6x6ZLALDRScr5jGZuB8QdkNQIhcmwfr_VuMggTZreLhgXwzikfYp61RnCUu9-NWMwijhdB9SPAlaV7s9LJzzYYX6jmLFiJQjP6TOK3ETTyxCO9J_e7RzgzKWP1Z_eBnzioToLrO8ObWrCAQ-XOB6ZV7Gly_43dOCA6Igeuy63B3lg.gqGsAvGtfThB9jK012-2lHaYPfR1XqYl35cD0W0MvRg&dib_tag=se&keywords=Eric+Kossoff&qid=1756476067&s=books&sprefix=eric+kossoff%2Cstripbooks%2C88&sr=1-1) by Eric Kossoff et al. (2020)
- [Keto for Cancer: Ketogenic Metabolic Therapy as a Targeted Nutritional Strategy](https://www.amazon.com/Keto-Cancer-Ketogenic-Metabolic-Nutritional/dp/1603587012/ref=sr_1_1?crid=1RL5GOK8CQ20R&dib=eyJ2IjoiMSJ9.aeqW7TyQqAO6DA-HrV4nHQ.2-XWg5aUhBWbdU_E2IfdpGQhC4-SIQFbiJWKfbTjkJw&dib_tag=se&keywords=ketogenic+guide+for+cancer+and+miriam&qid=1756476300&s=books&sprefix=ketogenic+guide+for+cancer+and+miriam+%2Cstripbooks%2C73&sr=1-1) by Miriam Kalamian, foreword by Thomas Seyfried (2017)

**Study with Alison Hull of low-carb ketogenic diet in healthy individuals**: [Improving Emotional Well-Being and Cardio-Metabolic Health with Continuous Glucose Monitoring](https://faseb.onlinelibrary.wiley.com/doi/10.1096/fasebj.2022.36.S1.R4527) | *The FASEB Journal* (F Walson et al. 2022) | [29:55]

**Guide to a ketogenic diet that Dom recommends**: [AKT: Advanced Ketogenic Therapies](https://advancedketogenictherapies.com/) (2025) | [33:30]

**Fiber-rich vegetables**: [What is Keto?](https://ketonutrition.org/what-is-keto/) | KetoNutrition (2022) | [34:30]

**Paleomedicina**: [47:30]

- [Paleomedicina](https://paleomedicina.com/) (2025)
- [Medical Case Studies](https://paleomedicina.com/hu/esettanulmanyok) (2025)

**Metabolism of 1,3-butanediol is analogous to drinking alcohol**: [Effects of acute and chronic 1,3-butanediol treatment on central nervous system function: a comparison with ethanol](https://pubmed.ncbi.nlm.nih.gov/7193248/) | *The Journal of Pharmacology and Experimental Therapeutics*  (G Frye et al. 1981) | [55:00]

**George Cahill’s fasting studies**: [Brain Metabolism during Fasting](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC292907/) | *The Journal of Clinical Investigation* (O Owen et al 1967) | [56:30]

**1,3-butanediol suppresses metastatic cancer in mice**: [Ketone supplementation decreases tumor cell viability and prolongs survival of mice with metastatic cancer](https://pubmed.ncbi.nlm.nih.gov/24615175/) | *International Journal of Cancer* (A Poff et al. 2014) | [57:45]

**Benefit of dietary ketosis, ketone supplement, and hyperbaric oxygen in a mouse model of metastatic cancer**: [Nontoxic metabolic management of metastatic cancer in VM mice: novel combination of ketogenic diet, ketone supplementation, and hyperbaric oxygen therapy](https://pubmed.ncbi.nlm.nih.gov/26061868/) | *PloS one* (A Poff et al. 2015)

**KETOSTART exogenous ketone electrolyte supplements**: [Audacious Nutrition – KETOSTART](https://www.audaciousnutrition.com/products/ketostart-tropical) | [1:03:30, 2:04:30]

**Anti-inflammatory effects of BHB in the brain**: [The ketone metabolite β-hydroxybutyrate blocks NLRP3 inflammasome-mediated inflammatory disease](https://pubmed.ncbi.nlm.nih.gov/25686106/) | *Nature Medicine* (Y Youm et al. 2015) | [1:13:45]

**Ketone esters for seizure control**: [Ketone Administration for Seizure Disorders: History and Rationale for Ketone Esters and Metabolic Alternatives](https://pubmed.ncbi.nlm.nih.gov/31680801/) | *Frontiers in Neuroscience* (A Poff, J Rho, D D’Agostino 2019) | [1:15:30]

**Episode of** ***The Drive*** **with George Brooks**: [#312 – A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond | George A. Brooks, Ph.D.](https://peterattiamd.com/georgebrooks/) (August 5, 2024) | [1:31:15]

**Formulating ketone esters with MCT mitigates negative effects**: [1:32:30]

- [Exogenous Ketone Supplements Reduce Anxiety-Related Behavior in Sprague-Dawley and Wistar Albino Glaxo/Rijswijk Rats](https://pubmed.ncbi.nlm.nih.gov/27999529/) | *Frontiers in Molecular Neuroscience* (C Ari et al. 2016)
- [Exogenous Ketones Lower Blood Glucose Level in Rested and Exercised Rodent Models](https://pubmed.ncbi.nlm.nih.gov/31581549/) | *Nutrients* 2019
- [Delaying latency to hyperbaric oxygen-induced CNS oxygen toxicity seizures by combinations of exogenous ketone supplements](https://pubmed.ncbi.nlm.nih.gov/30604923/) | *Physiological Reports* (C Ari et al. 2019)
- [Physiologic, Metabolic, and Toxicologic Profile of 1,3-Butanediol](https://pubmed.ncbi.nlm.nih.gov/34521698/) | *The Journal of Pharmacology and Experimental Therapeutics* (C McCarthy et al. 20221)
- [Ketone supplementation abolished isoflurane anesthesia-induced elevation in blood glucose level and increased recovery time from anesthesia in Wistar Albino Glaxo Rijswijk rats](https://pmc.ncbi.nlm.nih.gov/articles/PMC9903607/) | *BMC Anesthesiology* (Z Kovacs, D D’Agostino, C Ari 2023)
- [Divergent Hepatic Outcomes of Chronic Ketone Supplementation: Ketone Salts Preserve Liver Health While Ketone Esters and Precursors Drive Inflammation and Steatosis](https://www.mdpi.com/1424-8247/18/10/1436) | *Pharmaceuticals* (C Ari, D D’Agostino 2025)

**Benefits of ketone salts and potassium citrate for kidney disease (in rats)**: [A combination of β-hydroxybutyrate and citrate ameliorates disease progression in a rat model of polycystic kidney disease](https://pubmed.ncbi.nlm.nih.gov/38095025/) | *American Journal of Physiology. Renal Physiology* (J Torres et al. 2024) | [1:34:00]

**Benefits of a ketogenic diet for treating cancer**: [Clinical research framework proposal for ketogenic metabolic therapy in glioblastoma](https://pubmed.ncbi.nlm.nih.gov/39639257/) | *BMC Medicine* (T Duraj et al. 2024) | [1:35:00]

**Episode of** ***The Drive*** **with Thomas Seyfried**: [#30 – Thomas Seyfried, Ph.D.: Controversial discussion—cancer as a mitochondrial metabolic disease?](https://peterattiamd.com/tomseyfried/) (November 26, 2018) | [1:35:30, 1:41:45]

**Jethro Hu’s phase 1 study of treating GBM with a ketogenic diet**: [A phase 1 safety and feasibility trial of a ketogenic diet plus standard of care for patients with recently diagnosed glioblastoma](https://pubmed.ncbi.nlm.nih.gov/40595067/) | *Science Reports* (L Amaral et al. 2025) | [1:38:15]

**RCT with MCT compound AC-1202 in AD patients**: [Study of the ketogenic agent AC-1202 in mild to moderate Alzheimer’s disease: a randomized, double-blind, placebo-controlled, multicenter trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC2731764/) | *Nutrition and Metabolism* (S Henderson et al. 2009) | [1:52:15]

**Benefits of ketosis for the brain**: [Ketone Supplementation: Meeting the Needs of the Brain in an Energy Crisis](https://pubmed.ncbi.nlm.nih.gov/35004814/) | *Frontiers in Neuroscience* (A Poff et al. 2021)

**Case report of Mary Newport’s husband who had AD treated with MCT**: A [new way to produce hyperketonemia: use of ketone ester in a case of Alzheimer’s disease](https://pubmed.ncbi.nlm.nih.gov/25301680/) | *Alzheimer’s & Dementia* (M Newport et al. 2015) | [1:52:15]

**Dual PET scan for both glucose and ketones show glucose utilization decreases with MCI and AD**: [A cross-sectional comparison of brain glucose and ketone metabolism in cognitively healthy older adults, mild cognitive impairment and early Alzheimer’s disease](https://pubmed.ncbi.nlm.nih.gov/28709938/) | *Experimental Gerontology* (E Croteau et al. 2018) | [1:52:45]

**Aviv Clinic at The Villages**: [Aviv Clinics, Central Florida](https://aviv-clinics.com/hyperbaric-centers/villages-florida/) | [1:56:45]

**Clinical trial of hyperbaric oxygen treatment of TBI/PTSD at the University of South Florida**: [About the Trial](https://hbot.usf.edu/about-the-trial/) | USF Health (2025) | [2:00:30]

**Dom’s podcast**: [The Metabolic Link](https://membership.metabolicinitiative.com/podcast-pre-login) podcast | The Metabolic Health Initiative (2025) | also on [YouTube](https://www.youtube.com/@MetabolicHealthSummit/podcasts) | [2:05:30]

- The Metabolic Link Podcast on all major players: <https://themetaboliclink.buzzsprout.com>
- The Metabolic Link on YouTube: <https://www.youtube.com/@MetabolicHealthSummit>

**The Metabolic Health Initiative website for CME (The Metabolic Link, Metabolic Initiative, Metabolic Health Summit)**: [The Metabolic Health Initiative](https://www.metabolicinitiative.com/): Bridging the education gap in metabolic health & therapy (2025) | [2:05:30]

- The Metabolic Initiative (Medical Education Platform): <https://membership.metabolicinitiative.com>

**The Metabolic Health Summit Conference**: [Metabolic Health Summit](https://metabolichealthsummit.com/): The World’s Leading Medical & Scientific Conference on Metabolic Health (2025) | [2:06:00]

**Social Channels**:

- Instagram:
  - Metabolic Health Summit: <https://www.instagram.com/metabolichealthsummit/>
  - The Metabolic Link: <https://www.instagram.com/themetaboliclink>
  - Metabolic Health Initiative: <https://www.instagram.com/metabolicinitiative>
- Facebook: <https://www.facebook.com/metabolichealthsummit>
- X: <https://x.com/MetabolicSummit>
- LinkedIn: <https://www.linkedin.com/company/metabolichealthsummit>
- TikTok: <https://www.tiktok.com/@themetaboliclink?_r=1&_t=ZP-91yPwV4Pmql>

---

## People Mentioned

- [Kenneth Ford](https://uwf.edu/intelligent-systems-and-robotics/faculty/ihmc-research-scientists/dr-kenneth-m-ford.html) (Founder and Emeritus Chief Executive Officer of the Florida Institute for Human & Machine Cognition (IHMC), expert in AI and cognitive science) [3:15, 50:45]
- [Jay Dean](https://health.usf.edu/medicine/mpp/faculty/jaydean) (Professor of Molecular Pharmacology & Physiology, College of Medicine, Adjunct Professor of Military and Emergency Medicine at USF Health, expert in the effects of O2, CO2, and barometric pressure on the CNS) [8:111]
- [Frank Butler](https://news.usuhs.edu/2025/01/dr-frank-butler-receives-presidential.html) (Navy SEAL, physician, and expert in oxygen toxicity who created the Tactical Combat Casualty Care revolutionizing battlefield trauma protocols, recipient of the Presidential Citizens Medal) [11:00]
- [Claude Piantadosi](https://medicine.duke.edu/profile/claude-anthony-piantadosi) (Professor Emeritus of Medicine, Interim Chief of Pulmonary, Allergy and Critical Care Medicine, Professor of Pathology at Duke University School of Medicine; expert in acute lung injury) [11:00]
- [Richard Moon](https://medicine.duke.edu/profile/richard-edward-moon) (Professor of Anesthesiology, Medical Director of the Hyperbaric Center, Professor of Medicine at Duke University School of Medicine; expert in the pathophysiology of high altitude and immersion pulmonary edema) [11:00]
- [Donald Layman](https://fshn.illinois.edu/directory/dlayman) (Professor Emeritus of Food Science & Human Nutrition at the University of Illinois Urbana-Champaign; expert in the relationship between dietary protein and carbohydrates and adult health) [26:15]
- [Stuart Phillips](https://mira.mcmaster.ca/our-faculty/stuart-phillips/) (Professor of Kinesiology at McMaster University where he is the Director of the Physical Activity Center of Excellence, member of the McMaster Institute for Research on Aging, member of the Centre for Metabolism, Obesity, and Diabetes Research, and a Tier 1 Canada Research Chair in Skeletal Muscle Health) [26:16]
- [Allison Hull](https://www.linkedin.com/in/allison-hull-50213bb7/) (Physician dual board-certified Adult Internist and Pediatrician with Florida Medical Clinic/Orlando Health; Co-Founder of the [R3 institute](https://myr3health.com/about-us/); expert in behavior change to reverse metabolic disease) [32:15]
- [Denise Potter](https://advancedketogenictherapies.com/team#:~:text=Our%20Team-,Denise%20Potter,-%2C%20RDN%2C%20CDCES) (Registered Dietitian Nutritionist, author of [*The Migraine Diet: A Ketogenic Meal Plan for Headache Relief*](https://www.amazon.com/dp/164152961X/ref=cm_sw_em_r_mt_dp_U_3DWYDbP57JYD4), founder of [Advanced Ketogenic Therapies](https://advancedketogenictherapies.com/)) [33:30]
- [Joe Rogan](https://en.wikipedia.org/wiki/Joe_Rogan) (Podcaster and host of *The Joe Rogan Experience*) [47:15]
- [Henri Brunengraber](https://case.edu/medicine/nutrition/about-us/faculty/henri-brunengraber) (Professor Emeritus of Nutrition at Case Western Reserve School of Medicine) [51:30, 55:00, 58:15]
- [Richard Veech](https://ketonutrition.org/2020-2-11-tribute-to-dr-richard-veech/) (Had a 50-year NIH career as a Medical Officer in NIMH; he became a Lab Chief in 2000 and later Chief of the NIAAA Laboratory of Metabolic Control; widely recognized as a father of metabolomics and advocate of ketones) [51:30, 58:15, 1:13:00, 1:26:00, 1:31:45, 1:52:15]

- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (1927-2012, was a scientist and professor at Harvard who advanced diabetes research, expert in fasting and ketones) [56:30, 1:31:45]
- [Sami Hashim](https://icahn.mssm.edu/about/srt/archives/oral-history/msslw-interviews/hashim) (Was an expert in lipid metabolism and the ketogenic diet; helped develop medical use of MCTs) [58:15]
- [Patrick Arnold](https://www.linkedin.com/in/patrick-arnold-8302676/) (Chemist, expert in ketones and nutritional supplements) [1:01:45]
- [Brianna Stubbs](https://www.linkedin.com/in/brianna-stubbs-91930794/) (Research Assistant Professor & Director of Translational Science at Buck Institute for Research on Aging, expert in the health benefits of ketosis) [1:11:45]
- [Jong Rho](https://medicine.yale.edu/ysm/profile/jong-rho/) (Section Chief of Pediatric Neurology at Yale School of Medicine; expert in pediatric epilepsy and treatment with a ketogenic diet) [1:16:15]
- [Guido Frank](https://profiles.ucsd.edu/guido.frank) (Professor in Residence in Psychiatry at UCSD, expert in eating disorders running a clinical trial to treat anorexia with a ketogenic diet) [1:21:30]
- [Diana Rancourt](https://www.usf.edu/arts-sciences/departments/psychology/people/faculty/diana-rancourt.aspx) (Associate Professor and Director of Clinical Training in the Department of Psychology at the University of South Florida, expert in eating disorders) [1:21:30]
- [Jan and David Baszucki](https://baszuckigroup.com/who-we-are/) (Jan is president of Baszucki Group and founder of Metabolic Mind; David is the founder and CEO of Roblox. Together, they co-founded [Baszucki Group](https://baszuckigroup.com/) to advance the family’s philanthropic goals.) [1:22:45]
- [Theodore (Ted) Van Itallie](https://ajcn.nutrition.org/article/S0002-9165(22)00994-7/fulltext) (1919-2019, leading expert on obesity and metabolic disease, former Chief of Medicine at Mount Sinai St. Luke’s) [1:31:45]
- [Thomas Seyfried](https://www.bc.edu/bc-web/schools/morrissey/departments/biology/people/faculty-directory/thomas-seyfried.html) (Professor of Biology at Boston College, expert in mechanisms by which metabolic therapy can manage chronic diseases) [1:35:30, 1:41:45]
- [Tomas Duraj](https://awareclinic.com/dr-tomas-duraj/) (physician-scientist working in Thomas Seyfried’s lab and practicing medicine at [Aware Clinic](https://awareclinic.com/about-us/)) [1:35:30]
- [Jethro Hu](https://researchers.cedars-sinai.edu/Jethro.Hu/about) (Associate Professor of Medicine, Neurology, Neurosurgery, and Neuro-Oncologist at Cedars-Sinai; expert in treating GBM with a ketogenic diet) [1:38:15]
- [Samuel Henderson](https://www.linkedin.com/in/samuel-henderson-806b984a/) (Chief Scientific Officer at Cerecin, expert in neurodegenerative diseases and metabolism) [1:52:15]
- [Mary Newport](https://www.linkedin.com/in/mary-newport-md-226b3479/) (MD, neonatologist who then became a certified ketogenic nutrition specialist after caring for her husband who had AD, [author](https://coconutketones.com/) of 4 books on ketones) [1:52:15]
- [Dale Bredesen](https://www.pacificneuroscienceinstitute.org/people/dale-bredesen/) (Senior Director of Precision Brain Health at the Pacific Neuroscience Institute) [1:52:45]
- [Stephen Cunnane](https://recherche-cerveau-sherbrooke.ca/en/laboratory-team/) (Professor at the Faculty of Medicine and Health Sciences in University of Sherbrooke, expert in the link between nutrition and brain energy metabolism) [1:52:45]
- [Joe Dituri](https://www.usf.edu/engineering/bme/faculty-staff/joseph-dituri.aspx) (Associate Professor of Practice in the Department of Medical Engineering at the University of South Florida, expert in hyperbaric medicine and treatment of TBI) [2:00:45]

---

![](https://peterattiamd.com/wp-content/uploads/2025/12/bio-DD-600x600.png)

##### Dominic D’Agostino, Ph.D.

Dominic “Dom” D’Agostino earned a BS in Biological Sciences and Nutrition Science from Rutgers University then completed his Ph.D. in Neuroscience at the University of Medicine and Dentistry of New Jersey. Dr. D’Agostino completed postdoctoral research with Dr. Jay B. Dean in the Department of Neuroscience, Cell Biology and Physiology at Wright State University Boonshoft School of Medicine in Dayton, OH. He was also a postdoctoral fellow in the department of Molecular Pharmacology and Physiology at the University of South Florida (USF) Morsani College of Medicine in Tampa, FL. He continued at USF as an Assistant Professor and is and currently is a tenured Associate Professor in the Department of Molecular Pharmacology and Physiology at the [USF Morsani College of Medicine](https://health.usf.edu/medicine/mpp/faculty/ddagosti). Dr. D’Agostino is also a Senior Visiting Research Scientist at the [Institute for Human and Machine Cognition (IHMC)](https://www.ihmc.us/groups/ddagostino/).

Dr. D’Agostino’s laboratory develops and tests metabolic-based strategies for targeting CNS oxygen toxicity (seizures), epilepsy, neurodegenerative diseases, and cancer. The main focus of his lab over the last 10 years has been understanding the anticonvulsant and neuroprotective mechanism of the ketogenic diet and ketone metabolite supplementation. The shift in brain metabolism (from glucose to ketones) reduces neuronal hyperexcitability, oxidative stress and enhances brain energy metabolism. This approach can be used to treat a wide variety of pathologies linked pathophysiologically to metabolic dysregulation, including cancer. Other areas of interest include researching drugs that target cancer-specific metabolic pathways. He was a research investigator and crew member on NASA’s Extreme Environment Mission Operation (NEEMO 22) and has a personal interest in environmental medicine and methods to enhance safety and physiological resilience in extreme environments. His research is supported by the Office of Naval Research (ONR), Department of Defense (DoD), private organizations and foundations. [[KetoNutrition](https://ketonutrition.org/about/)]

Facebook: [Dominic D’Agostino](https://www.facebook.com/dominic.dagostino.1/)

Instagram: [dominic.dagostino.kt](http://dominic.dagostino.kt/)

LinkedIn:  [Dominic D’Agostino](https://www.linkedin.com/in/dominic-d-agostino-156014b)

Podcast: [The Metabolic Link](https://membership.metabolicinitiative.com/podcast-pre-login) (on [YouTube](https://www.youtube.com/@MetabolicHealthSummit/podcasts))

Website: [Dominic D’Agostino](https://drdominicdagostino.com/) and [KetoNutrition](https://ketonutrition.org/)

X: [@DominicDAgosti2](https://x.com/dominicdagosti2?lang=en)