# #191 – Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.

**Source:** [https://peterattiamd.com/karldeisseroth/](https://peterattiamd.com/karldeisseroth/)

---

Karl Deisseroth is a world-renowned clinical psychiatrist, neuroscientist, and author of [*Projections: A Story of Human Emotions*](https://www.amazon.com/Projections-Story-Emotions-Karl-Deisseroth/dp/1984853694). In the episode, Karl explains his unique career path that led to the development of optogenetics—a revolutionary technique that uses specialized light-sensitive ion channels to precisely control the activity of select populations of neurons. Karl provides a concise overview of how optogenetics works and how it can be used to better understand mental illness, to identify the neurons responsible for specific behaviors, and to guide development of new treatments. Karl uses his experience as a practicing psychiatrist to provide deep insights into depression, anxiety, autism, and personality disorders and explains the role of optogenetics in mapping out brain regions responsible for common mental health afflictions.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/karldeisseroth/the_Drive_public.png)

Play

#191 - Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.

#191 - Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.

1x15s30s

0:002:29:23

## We discuss:

- Karl’s journey through medical school and interest in the brain [5:00];
- A profound medical school experience that changed Karl’s career path to psychiatry [17:30];
- Karl’s commitment to research and challenges overcome early in his career [27:00];
- The state of psychiatry and mental health therapies when Karl started his lab in 2004 [33:15];
- Neuroscience 101: fundamentals of neuroanatomy and neurophysiology [38:15];
- Traditional techniques for identifying the brain regions involved in specific behaviors [47:15];
- Intro to optogenetics and how to get a gene into a neuron [51:15];
- How viruses helped make optogenetics possible [1:01:45];
- How optogenetics was used to investigate the effects of dopamine neurons [1:15:45];
- Appreciating the power of optogenetics [1:22:00];
- Investigating and treating anxiety with optogenetics [1:26:45];
- Autism and autism-related anxiety, and the potential of optogenetics in treating autism [1:38:00];
- Optogenetics as a powerful tool for the discovery and creation of medical treatments [1:45:00];
- Karl’s inspiration to write his book, Projections [1:48:00];
- Mania and bipolar disorder: evolutionary basis, symptoms, and the high prevalence in North America [1:52:45];
- Depression: evolutionary basis and insights from optogenetics [2:03:15];
- The effects of trauma early in life [2:18:45]; and
- More.

§

## Show Notes

**\*Notes from intro**

- Karl is a former classmate of Peter’s from Stanford, where he received his MD and PhD
- He completed his clinical training in psychiatry, and he also did a postdoctoral fellowship there at Stanford during the same period of time
- He’s currently a professor of psychiatry and behavioral sciences and bioengineering at Stanford
- Over the past 16 years, Karl’s lab has focused on combining neuroscience and bioengineering to create a set of revolutionary tools
  - This has done something for the first time ever in neuroscience, which is basically to allow the use of genetic engineering to input light sensitive channels into very specific neurons
    - In fact, into any neuron that they choose to put these into
  - This then allows Karl and his team, and others who have been able to follow in his footsteps, to use photons, that is to say to use light, to turn on and turn off very selective neurons
  - This is something that was absolutely impossible until about a decade ago.
- This tool is referred to as [optogenetics](https://en.wikipedia.org/wiki/Optogenetics)
  - As its name suggests it’s opto, it’s light
  - It’s genetics, it uses this genetic engineering tool to put these channels, these light sensitive channels, into neurons
  - This has opened up a field of neurobiology that basically has allowed investigators like Karl to ask questions that have never been asked or answered before
- The discussion today will go into how Karl and his team came up with these unbelievable ideas, how they refine the tools, and what they’ve learned as a result of doing this
- This work has not gone unnoticed in the scientific community; Karl has won virtually every scientific award out there
  - Just this month, he was awarded the very prestigious [Lasker award](https://laskerfoundation.org/awards/about-the-awards/) for his optogenetic light activated molecular research
    - Now it’s worth pointing out, to those who might not be aware, that about 50% of Lasker winners go on to win the [Nobel prize](https://www.nobelprize.org/prizes/)
- This episode will discuss not just about his background and how it led him to these discoveries in his chosen career path, but it will also dive into some of the deeper questions about mental illness
  - Remember, Karl is a practicing psychiatrist, and it’s his interest in the human condition that really guides his research
  - This episode will dive quite deep into depression, anxiety, autism
  - It will touch briefly on some personality disorders
  - But truthfully, this episode ran out time after two and a half hours; and the discussion only made it through about half of the material that Peter wanted to talk about
  - So it’s safe to say that Karl will absolutely be back on this podcast because there’s still so much to talk about
- The other thing to be aware of, before this discussion begins, is that Karl has recently written a remarkable book called [Projections](https://www.amazon.com/Projections-Story-Emotions-Karl-Deisseroth/dp/1984853694/ref=sr_1_1?crid=2PM6K01FV77H5&keywords=projections+karl+deisseroth&qid=1636936339&qsid=146-5475333-0110134&sprefix=karl+des%2Caps%2C186&sr=8-1&sres=1984853694%2C024138186X%2C1250223180%2C1328949966%2CB091KCYTHG%2CB08PVZNYQT%2CB08SGWNLV9%2C1260117103%2C1496447794%2CB08P7JTGQ1%2CB0982LBC7P&srpt=ABIS_BOOK)
  - This is a book that Peter has mentioned in the podcast; he’s read it twice
  - Karl’s ability to write is perhaps only rivaled by his ability to conduct Nobel prize-worthy science
  - He’s a remarkable writer, and you don’t need to be afraid of this book being written by such an esteemed scientist; it reads like a piece of poetry
  - It really is a remarkable book and a remarkable journey into not just his personal journey, but also into the eye of mental illness

## Karl’s journey through medical school and interest in the brain [5:00]

- Karl was in the MD PhD program when Peter met him
  - They didn’t start at the same time but finished at the same time
  - The reason Peter knew him, even on their first day of surgery was because Karl had done his PhD in the same lab as 2 of Peter’s friends
- All kids that go to med school are pretty bright, but the MD PhD students were in a class of their own
  - Peter suspects it was even harder to get into the MD PhD program than it was just the straight MD program
- Karl did his undergrad in biochemical sciences at [Harvard](https://gsas.harvard.edu/programs-of-study/all/biological-and-biomedical-sciences); they didn’t call it biochemistry
  - They didn’t call it a major either; it was a concentration; he concentrated in biochemical sciences
  - He had a lot of other interests; all of his friends were physicists, theoretical physicists; so he was exposed to some pretty unusual stuff for a biochemist
- He knew he wanted to go into medicine pretty early on because he was interested in the brain early on
- He wanted to understand the brain at the level of cells
  - But he was also interested in the most high-level aspects of brain function, so he thought he needed to talk to human beings
  - He needed some access to the human brain
- He found that interesting because he was interested in emotion and the ability to express feelings through words
- Further, he was torn; he liked writing and literature and the use of words, and he liked cells and biology
  - He wanted to somehow fuse them, and it seemed that medical school was the way to go because he could work with the human brain
- He could have just gone to medical school, but he was also selected into this very, very advanced program that was incredibly selective, the [MSTP program](https://med.stanford.edu/mstp.html), the medical science training program
  - This tells Peter that Karl knew he wanted to do research beyond just clinical medicine
  - Yes, and the nice thing about the MSTP is it lets one delay in making a commitment, so he could keep both threads alive
  - Then there’s a beautiful synergy that can happen too, and certainly happened with him, that he realized, “*Oh wait, I don’t have to make this decision*.” It actually is good to keep both threads alive in his work and his life
  - It’s a pretty special program in the United States; there are efforts along these lines in Europe and other countries, but it’s not nearly as institutionalized as it is here
- Peter recalls there were maybe 6 or 8 MSTP students in their class at Stanford
  - He always felt like they  had the most pressure on them; there was this expectation from both the clinical and research side
  - An expectation that they would go on to be great doctors
  - On the research side, they had the opportunity to do their PhD with a Nobel laureate or exceptional scientist
  - There was also this expectation that they would lead the charge scientifically
  - Of the MSTP students in their class, Peter thinks Karl is the only one that ended up doing clinical training
    - The others didn’t end up doing a residency; they either went purely into academic research or into industry

**Neurosurgery, Karl’s first clinical rotation**

- In med school Peter remembers Karl was “*pretty hell bent on neurosurgery*”
- That was the goal; because he wanted access to the human brain, and who among the different clinical specialties has that access?
  - It seemed to him that neurosurgeons had it all
  - If one were to build an interface with the brain, if one wanted to both communicate with a person as they were expressing feelings and emotions, and to understand at the level of cells what was going on, who could do that but a neurosurgeon, was my reasoning
  - The neurosurgeons, his colleagues and friends, are amazing people, brilliant, and he saw no reason not to pursue that
- Neurosurgery was the first rotation that he selected in the second 2 years of medical school
  - Even before surgery, he did neurosurgery, which was kind of interesting just coming in there with no general surgical training
  - That’s how certain he was
- Peter had a similar experience where he was absolutely, positively, sure of what he wanted to focus on, pediatric oncology
  - In his case, he had a less pleasant experience than Karl
  - He did not enjoy his time in pediatrics largely because he felt like he didn’t fit in
- He thinks so much of the clinical rotations in the medical school experience, is a function of how well one fits in with the residents of that specialty
  - He didn’t feel like he fit in with the pediatricians
    - They didn’t laugh at his jokes
    - They thought he was probably a little too obnoxious, that he spent too much time imitating [Dr. Evil](https://en.wikipedia.org/wiki/Dr._Evil) and [Fat Bastard](https://en.wikipedia.org/wiki/Fat_Bastard), pretending to eat the babies
  - The whole thing just didn’t go well; it was a disaster
  - Then his next rotation was general surgery where he connected, and even though he had no desire whatsoever to go into surgery, that became an overnight love
- Peter thinks its highly unusual that Karl would do a neurosurgery rotation so early in his training
  - That’s usually something one does in the fourth year, not the third year
- When Peter did general surgery at Hopkins, he did one month of neurosurgery as a rotation
  - He never had an interest in neurosurgery, but he didn’t have a choice about this rotation
  - During that month, he fell in love with it
  - In fact, he spoke to the program director at Hopkins and said, “W*ould it be ridiculous for me to try to transfer into neurosurgery?*”
    - That’s how much he enjoyed it
    - The director said, “*I can absolutely get you in, but it won’t be at Hopkins. Hopkins is the most competitive neurosurgery program in the country. We only take three people. It’s already full. You’re not going to get in here, but I can get you to another program.*”
    - And Peter actually contemplated it for about a month
  - He can see the appeal of it; there was something about cutting open the [dura](https://en.wikipedia.org/wiki/Dura_mater) and operating on the brain; it’s a surprisingly simple organ in that sense
- Karl notes, at one level it is an organ, but it would be unfair to say that all that neurosurgeons get to do is think about it as an organ
  - They do have to think about that, the blood supply and whether the cells are receiving enough oxygen and glucose
  - They also get to think about high level concepts
- In his neurosurgery rotation, there was a patient who had a little bit of thalamic infarct as a result of the surgery, and a little bit of loss of tissue in the thalamus
  - The patient had a [neglect syndrome](https://en.wikipedia.org/wiki/Hemispatial_neglect)
  - He spent a lot of time working with the patient afterward characterizing exactly how this worked
  - He asked the patient to draw a clock, and the patient drew just half of a clock; it was a classical thing, but amazing to see with one’s own eyes talking to another person
  - And the patient said, “*The clock looks fine,*” but it was a half a clock
  - That certainly didn’t diminish his interest in neurosurgery at all
  - At the one level, there were problems which clearly needed to be better
    - Aspects of neurosurgery, as with every clinical specialty needed to improve, needed to reduce consequences like that
  - Yet at the same time, it was incredibly interesting as well
- He loved the operating room
- He love the suturing, although he wasn’t as good as Peter
- But he was good enough and particularly because it was so early, he thinks that the promise was there
  - It would’ve worked out; it still had a magic about it
  - When the dura is exposed, yes, it’s an organ, but there’s a spirituality to that

> “To know that you’re actually looking at the storehouse of a human being’s thoughts and feelings and everything about them, all encapsulated in this collection of cells. It’s quite an amazing thing.” – Karl Deisseroth

- So he had no negativity at all

- He did notice that neurosurgeons didn’t get a lot of free time; there was not a lot of philosophizing
  - It’s a 7-year progression
  - He talked to all the neurosurgery residents, and he noted a steady decline in willingness to philosophize as their progress through the residency continued
    - This could almost be plotted linearly on a graph
    - With all due credit to them, it’s the nature of the system they’re in that they don’t necessarily have all the time they would like to think deeply, although they certainly are very bright and thoughtful, and they certainly could
  - He noted that here are people who maybe don’t have the freedom to do everything he would like, and that was in the back of his mind
- Peter thinks back to the 3 people in his class that were assigned neurosurgery
  - These were 3 ridiculously smart guys, and one would think, “*Well, they’re in neurosurgery, so how interested are they going to be in their year of general surgery?*”
    - But they were every bit the exceptional interns that the categoricals were, the ones who were going to go into general surgery
  - One of the experiences that stands out from his month of general surgery in his internship was an awake procedure they did on a patient
    - So under local anesthetic, the brain was opened, and the patient while wide awake was being probed in an effort to determine certain symptoms and to see what part of the brain could be lesioned in order to ameliorate these symptoms
    - He thinks for anybody to see that in real life with their own eyes, even once, it’s really hard to believe what’s happening
    - First of all, the brain is not some sensory organ—The fact that the patient can be awake while a surgeon is probing into the brain, and it’s firing an electrical impulse into one area or another; to see how it changes this part of the visual field… “*that was magic*”
- Karl felt very strongly after his neuroscience rotation; it was all systems go after that
  - Surprisingly, the neurosurgeons at Stanford liked him okay after that too
  - He got very positive feedback from them; they wanted him to come back and do an internship
  - He was happy with that; it was where he was headed; but things changed

## A profound medical school experience that changed Karl’s career path to psychiatry [17:30]

- There are a set of mandatory rotations medical students have to do, neurosurgery is not one of them
  - They are: pediatrics, general surgery, internal medicine, OB-GYN, and one of them is psychiatry
    - Psychiatry is kind of this afterthought for the medical student
    - Very few people want to go into psychiatry; yet amazingly two of the smartest people in their med school class, Karl and [Paul Conti](https://www.drpaulconti.com/), end up picking this field ultimately, just amazing
- When Karl began his psychiatry rotation he had a get me through it attitude
  - No disrespect to psychiatry
  - Psychiatrists have a hard challenge; there is not a measurable
    - They have questions they ask patients; their work is all with words
    - There’s no biomarker
    - There are efforts, they do look at EEG ratios of this to that; progress is being made
    - But clinically diagnoses are not based on measuring something about the brain in psychiatry
    - The psychiatrist can notice a neurological or medical problem, but they can’t define someone’s psychiatric state with a biomarker
    - Amazingly, to this day, this is still true
- Peter remembers his 1-month psych rotation
  - They had choices; he did an entire outpatient month, which he ended up finding quite enjoyable
  - This was his last rotation before graduation; this meant there was not chance to choose that field of study, even if he liked it
  - He was already matched in general surgery
  - But that month working outpatient, was relatively low acuity but interesting nevertheless
- Karl’s month in psychiatry was the opposite of that
  - This was probably fortunate for him
  - He was in the locked unit at the VA, at the [Veterans Administration](https://en.wikipedia.org/wiki/United_States_Department_of_Veterans_Affairs) hospital
    - This was a unit where patients can’t leave, and this is due to being a danger to themselves or a danger to others or having a grave disability
    - These patients were severely ill
  - He walked into that having had what he thought were typical experiences with psychological issues
    - Everybody has friends or family who have had depression or anxiety
    - He had seen substance abuse and intoxicated states and dementia
    - He thought he had a fairly decently broad understanding of what can go wrong on the psychiatric side

> “There is nothing like what you can see when you walk into the locked ward of a psychiatric hospital” – Karl Deisseroth

- There’s sort of a purity, not in a good way, but because there’s not confounding issues like intoxication and so on; there’s a consistency and a purity to the disorders
- So if there is someone with acute [schizophrenia](https://en.wikipedia.org/wiki/Schizophrenia) or [schizoaffective disorder](https://en.wikipedia.org/wiki/Schizoaffective_disorder), other things that might confound what’s going on have been removed
- And there’s this very strong, acute, straightforward expression of the symptoms; that’s just mind boggling to see if one hasn’t experienced it before

- This experience **completely changed his course** in his medical education
- Even on his very first day, there was a patient with schizoaffective disorder
  - This is a very severe combination of mood and psychotic symptoms that are all mixed up together
  - This patient accosted him in the locked unit, started screaming at him
  - It was not necessarily the sort of street encounter that one might have in a city—
    - It was more direct and personal and evocative of something going on in the mind of the patient, that was clearly a source of immense suffering, of great disability
    - And yet at the same, it was tantalizing because this was a human being who was physically intact, but whose reality was so completely different from his
    - Here were two people with intact bodies and brains who were next to each other, and they inhabited completely different realities
  - To experience that was an “utterly transformative moment”, says Karl
    - Both seeing the suffering and realizing he had no idea what’s going on
    - But it’s incredibly interesting to think, how is this possible? How could this be happening to a human being?
  - This direct exposure changed his course
- Peter notes that many people when confronted with that would be quite frightened, especially when they realize the limitations of the tools available
- Let’s consider another analogy, a patient that comes in with a gunshot wound to the chest
  - That’s an incredibly frightening experience
  - There’s literally a sucking chest wound; blood could be splaying around the room, vital signs are crashing, the person is on the verge of death
  - But that can be exciting in a way, because tools are actually available to do something
    - It might be completely draconian
    - One might be doing a [thoracotomy](https://en.wikipedia.org/wiki/Thoracotomy) in the ER, cross-clamping the aorta; but run that patient to the OR and one can fix them
- What Karl describes is something that Peter would argue is much more frightening, but compounded by the question of what to do?
  - He could temporarily give that person [Haldol](https://en.wikipedia.org/wiki/Haloperidol), and sort of snow them, but that’s not curing them
  - The problem is the lack of tools; this is an unbelievable opportunity to learn
  - But for many people that could have been off-putting

*Peter asks what about Karl’s experience in the psychiatric ward captured his interest?*

- Karl notes this was not something he wanted to spend his life doing in this setting
- But he had a different reaction, which surprised him; there were two sides to it
  - 1) One was exactly what Peter is saying, the level of mystery was a positive rather than an aversive thing
    - Maybe this was partly his scientific training
    - At that point he’d completed his PhD and he’d spent years trying to figure things out
    - We all want to figure things out; that’s a natural human impulse
    - Not everybody necessarily spends years and years and years trying to figure out the same thing, and that’s the kind of training one gets in the PhD program
    - He saw these patients and thought, “*Okay. We’ve got to figure this out. This is clearly a mystery that is something that it’s a burden that humanity shares. It’s a terrible burden that this human being is suffering. But what’s the solution? We’ve got to figure it out. We’ve got to understand this*.”
  - 2) This mystery strikes to the heart of something that has always intrigued him, which is what is an emotion, physically?
    - What is a feeling, physically?
    - How does the collection of cells in the brain create a feeling, an emotion?
    - He realized at that moment, this is actually why he came to medical school

> “It had all made sense in one moment that it hadn’t before” – Karl Deisseroth

- As a physician, the instinct is to help, is to heal; but if the tools aren’t available, what can one do?
  - It’s a problem, but he wasn’t frustrated with the inability to do anything
    - The fact was they could do a little bit to help, so it wasn’t quite nothing
    - There were medications back then and still that help somewhat
    - Medications don’t come with understanding; they don’t help doctors explain to the patient or the family or to ourselves what’s really going on, but they do help a little bit
  - He knew that he could do something, not much, but a little bit, and as time went on, hopefully, and as the science progressed, maybe he could do more
- In that moment he didn’t have another thought for neurosurgery, although it was a hard process to reshape what his trajectory was going to be
  - He had one set of plans
  - His friends and family had a set of expectations
  - He thinks his father was pretty disappointed when he told him on the phone that he was going to do psychiatry
    - He could hear it in his voice; he could sense that this was not what he’d hoped for his son
    - But, he came around in the end and I think he’s happy now,
  - It was an adjustment; it was a remapping
  - But it was a very compelling experience that the process of medical training and the required psychiatry rotation made possible

## Karl’s commitment to research and challenges overcome early in his career [27:00]

**The challenges of keeping up with research during residency**

- Peter notes that psychiatry and neurosurgery have 1 thing in common but differ otherwise
- Residencies are quite demanding
  - In their day, the 80-hour work week limit was not in place
- Peter asks if it was hard to put research on hold during his psychiatry residency?
- Yes, there are a lot of challenges that people in this realm face because things move so quickly in the research realm
  - If one steps aside for even a year, forget about 4 years, the world one reenters is so different, and it’s very hard to catch up
  - That’s to some extent an old problem, because that’s been faced by everybody who planned to do a residency; but it’s not negligible because it’s an old problem
  - It’s that issue exactly that ends up driving people to make this hard choice that Peter mentioned earlier
    - People say, “*In the end, I’m going to have to do one or the other. If I do the residency, I’ll be a doctor. I’ll be a good doctor, maybe a great doctor. I’ll be informed by all my scientific training. Maybe I’ll read papers better. Maybe I’ll be more amenable to new ideas, new treatments as a result of that. But ultimately I’ll be a physician.*“
    - Or on the other side they say, “*I’m not going to do the residency. I’m not going to drop off this fast moving train. At this moment, I’ve just finished my PhD. I’m a world expert in this. I can do things that nobody else can do.”*
    - Why lose that momentum?
    - Why not speed up, add the next tool in the tool belt and make great discoveries?
    - And that is very, very tempting; he had very clear opportunities to do that
    - This is the hard choice that the MD PhD faces at that moment
  - Now efforts are made to ameliorate that, such as limiting the work week to 80 hours for residents
  - He had extra challenges, he was effectively a single dad at the time
    - He  had to think about his family, his residency, and the lab; it was very, very challenging
  - There are research track residencies and they help a little bit
    - They are efforts to help people keep their scientific mind alive during residency
    - It’s not great, but it’s a little bit of protected time here and there
    - It’s never quite enough to get momentum, but at least one can keep a foot in the lab and try to stay connected
- He did a research track, psychiatry residency
  - He stayed at Stanford, and this was a big factor for him
  - He was very fortunate in this regard, a guy named [Rob Malenka](https://med.stanford.edu/profiles/robert-malenka), who was a psychiatrist and a great neuroscientist, was at that moment coming from UCSF to Stanford
    - He was setting up his lab at Stanford, and Karl knew, “*here’s somebody, a psychiatrist, but also as a neuroscientist; he’ll understand what’s going on in my residency that I’m taking call, I’m up all night. He’ll understand why I’m never in the lab during expected hours; why I’m never at lab meeting.*”
    - That made it work out
  - He worked nights and weekends
  - He maybe came to one of the lab meetings over 4 years, and he effectively did a combined postdoctoral fellowship and psychiatry residency at the same time at Stanford
    - Some funny stories, because Stanford’s very compact, he could literally be on-call from the lab
    - He’d be [patch clamping](https://en.wikipedia.org/wiki/Patch_clamp); he’d be at the rig listening, making measurements on currents flowing across a single cell and he’d get paged, then go walk over to the ER, admit a patient, come back, patch clamp the next cell
      - And it was a pretty special moment when that happened
      - It felt like the different parts of his life could work together; they could be compatible
  - So many people have such a hard time, understandably, making this work, and he feels fortunate that he was able to make it work

**Challenges and insights of being a father**

- Karl’s son was born in ‘96; now he’s 25
  - So he was 5 years old when Karl was in the middle of this
  - This is something he touches on in his book, [*Projections*](https://www.amazon.com/Projections-Story-Emotions-Karl-Deisseroth/dp/1984853694/ref=sr_1_1?crid=2PM6K01FV77H5&keywords=projections+karl+deisseroth&qid=1636936339&qsid=146-5475333-0110134&sprefix=karl+des%2Caps%2C186&sr=8-1&sres=1984853694%2C024138186X%2C1250223180%2C1328949966%2CB091KCYTHG%2CB08PVZNYQT%2CB08SGWNLV9%2C1260117103%2C1496447794%2CB08P7JTGQ1%2CB0982LBC7P&srpt=ABIS_BOOK)

> “It turned out to be a theme early in my life, how my experiences with my son, how they related to all the stressors and the patient experiences that I was having” – Karl Deisseroth

- Psychologically, it helped him to have something that mattered more than anything else in the lab or in the clinic
- Though it was difficult to make everything work practically, this was something that was on a different scale and it helped him not get to stressed about things happening in the lab or clinic
  - This is a common feeling in people with kids
  - For him, this was extremely important at the time
  - There were patchwork solutions of childcare and so on that made things work
  - But ultimately, it was helpful for him, in getting through those times.
- His son is now an MSTP student at [Baylor](https://www.bcm.edu/education/education-programs/md-phd-program); he’s doing his MD PhD in Texas, and he’s now a second year
  - He’s a cool kid; he’s good at guitar, much better than Karl; and he likes computer science

## The state of psychiatry and mental health therapies when Karl started his lab in 2004 [33:15]

- Karl began setting up his lab in ‘04; then it really hit full steam between ‘06 and ‘09
- He had just completed his psychiatry residency
- He had a pretty deep understanding of where things were clinically
  - He knew both the medications available and also the brain stimulation treatments, and the interventions
- He did [electroconvulsive therapy](https://en.wikipedia.org/wiki/Electroconvulsive_therapy), which is very effective for treatment-resistant depression
  - It’s the treatment of choice for many people
  - It’s incredibly effective; it’s stunning to see
  - It has some problems, one doesn’t want to give it too much, and there can be side effects; but it’s incredibly effective
  - The durability of electroconvulsive therapy varies
    - Some patients need maintenance electroconvulsive therapy; so after 3 months or so, the effect will be diminished and they’ll require it to stay alive effectively
    - For patients who are, for example, just acutely suicidal, and they’ll need it every 3 months or so
      - This is called maintenance or continuation electroconvulsive therapy or ECT
  - So it’s not a permanent fix, like so much of medicine and so much of psychiatry
    - It’s something that moves things back into a healthy range for a time
    - It was satisfying to help the patient, to take somebody who was in just horrific psychological distress and put them into a state where they could go back and do their work and live with their friends and family and be happy for some time
  - How it was working was not known; this is still true today
    - Why is this seizure that doctors give the patient effective?
      - It’s done in a pretty refined way these days; the patient’s body is paralyzed so there’s no physical seizure; it’s all happening in the brain
      - This is a safe procedure
      - But still it’s not specific; it causes a general pattern of activity through the brain of the patient; and this astonishing psychiatric effect is created
      - This is still a mystery and Karl was unsatisfied by that
- At the time there were early efforts with other brain stimulation treatments
- There was a [vagus nerve](https://en.wikipedia.org/wiki/Vagus_nerve) stimulation

![](https://peterattiamd.com/wp-content/uploads/2022/01/f1-karld.png)

**Figure 1. The vagus nerve highlighted in yellow.** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Vagus_nerve)

- This is the 10th cranial nerve that comes from the brainstem and goes down to innervate the heart and the abdomen
- It’s shown in the figure above in yellow
- The abdomen also sends fibers back to the brain
- One can put a little cuff around the nerve and stimulate the brain through the neck
  - This is kind of interesting, a little highway to the brain
  - But the effects were very small and inconsistent on the population level
  - It did gain FDA approval for treating depression

- Similarly, there was [transcranial magnetic stimulation](https://en.wikipedia.org/wiki/Transcranial_magnetic_stimulation); this was in its early days then as well

![](https://peterattiamd.com/wp-content/uploads/2022/01/f2-karld.jpeg)

**Figure 2. Transcranial magnetic stimulation.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Transcranial_magnetic_stimulation)

- This was a treatment where one can non-invasively stimulate a tiny patch of the brain by putting a rapidly changing magnetic field near the scalp of the patient
- Again the effects were small on the population level
- It did get FDA approved, but it’s still not fully understood

- To this day, in all these treatments, and also all medications, the mechanisms of action are not fully understood
  - So there is a lot of mystery
- He came from his psychiatry residency fully aware that essentially the entire field was unmoored from scientific understanding
  - This is no fault of the practitioners; it was just not known
  - The tools and techniques were not available
  - There was no specific way of causing something to happen to a particular kind of cell
  - All these treatments are nonspecific, a seizure all through the brain, a stimulation of a nerve, wherever that nerve may go is known but not specifically related to any psychiatric symptom
  - Transcranial magnetic stimulation, it can stimulate a little patch of the brain, but it’s not known where depression comes from or where anxiety comes from
    - Is it this patch or that patch or that patch?
  - There is no deep level of understanding of what’s present
  - And of course the medications act throughout the brain without cell type specificity; this was the setting
- To answer Peter’s question, his goal was basic science; how could he build an approach to give some kind of precise causality
  - This was the context of his early career

## Neuroscience 101: fundamentals of neuroanatomy and neurophysiology [38:15]

- Before diving deep into the science, let’s review brain structure, neuroanatomy and neurophysiology
- The cells in the brain are more complex structurally than any other cell
- In our brains there are approximately 90 billion [neurons](https://en.wikipedia.org/wiki/Neuron) and each one of them is a self-contained unit
  - It’s covered by a membrane, but it can generate electricity
  - It’s got little channels, little pores in its surface that can generate little electrical impulses; and this is how one, single neuron can project from one part of the brain to another (or from one part of the brain to the spinal cord)

![](https://peterattiamd.com/wp-content/uploads/2022/01/f3-karld-1024x656.png)

**Figure 3. Schematic and histology of a neuron.**  Image credit: [OpenStax Anatomy and Physiology figure 4.19](https://openstax.org/books/anatomy-and-physiology/pages/4-5-nervous-tissue-mediates-perception-and-response#fig-ch04_05_01)

![](https://peterattiamd.com/wp-content/uploads/2022/01/f4-karld-1024x681.png)

**Figure 4. Parts of a neuron in detail.**  Image credit: [OpenStax Anatomy and Physiology figure 12.8](https://openstax.org/books/anatomy-and-physiology/pages/12-2-nervous-tissue#fig-ch12_02_01)

- The figures above identifies an axon and dendrites in a neuron
- A neuron can send connections through its [axon](https://en.wikipedia.org/wiki/Axon), its outgoing wire, effectively to many parts of the brain
- It sends information in the form of electricity down its axon, down its outgoing connection
- And the connections are received by the downstream cells through little structures called [dendrites](https://en.wikipedia.org/wiki/Dendrite)
- And the interface from one cell to the next is called a [synapse](https://en.wikipedia.org/wiki/Synapse)
  - See a diagram of the synapse in the figure below
  - In most cases, information gets across that little gap from one cell to another in the form of chemicals
  - So the electricity triggers release of a chemical, the chemical drifts across this tiny little gap that’s some tens of nanometers
  - These chemicals then act on receptors on the other side (the postsynaptic side), and that creates a new burst of electricity in that downstream cell

![](https://peterattiamd.com/wp-content/uploads/2022/01/f5-karld-1024x913.png)

**Figure 5. Release of neurotransmitters at the synapse.**  Image credit: [OpenStax Anatomy and Physiology figure 12.27](https://openstax.org/books/anatomy-and-physiology/pages/12-5-communication-between-neurons#fig-ch12_05_03)

- So that’s the electrochemical process of information flow
- This is going on in 90 billion neurons at the same time
  - Maybe they form 10,000 or even 100,000 synapses each
  - Their wiring is incredibly complex
  - There’s some structure to it
  - There are collections of axons that may travel together, but then they also bifurcate and separate in incredibly complex ways
  - And all of that’s in the brain

**Brain structures shared by vertebrates; what is different in humans**

- Think about this from an evolutionary perspective; people are [vertebrates](https://en.wikipedia.org/wiki/Vertebrate), this means they have a backbone and certain organization of the brain
- Karls lab studies fish, mice, and rats; these are all vertebrates
  - They all have the basic vertebrate body plan and brain plan
  - But evolution has given people much bigger brains than fish
- A couple things have happened over the course of hundreds of millions of years
  - 1) Everything is scaled up in humans
    - The same structures are there but many more cells are added; this allows people to do more complex things
  - 2) new things have been added
    - The [cortex](https://en.wikipedia.org/wiki/Cerebral_cortex) is on the surface of the brain; see the diagram below
    - It’s like the rind of a melon, except in humans it’s quite thin, it’s just a few millimeters thick
    - And within that few millimeters, there are 6 separate layers within that cortex or rind; those are layers of cells
    - All the wiring coming out from that cortex goes to deep structures
    - The human cortex is much more advanced; fish don’t really have something like that
      - But fish have the deeper structures: the interchanges and the movement control, and the arousal systems, and the sleep systems

![](https://peterattiamd.com/wp-content/uploads/2022/01/f6-karld.jpg)

**Figure 6. Six layers of the cortex.**  Image credit: [Neuroscience Figure 26.2](https://www.ncbi.nlm.nih.gov/books/NBK10870/)

![](https://peterattiamd.com/wp-content/uploads/2022/01/f7-karld-1024x758.png)

**Figure 7. The hypothalamus.** Image credit: [OpenStax Anatomy and Physiology figure 13.11](https://openstax.org/books/anatomy-and-physiology/pages/13-2-the-central-nervous-system#fig-ch13_02_06)

- There are structures deep in the brain, like the hypothalamus that govern all the primary needs of salt balance and avoiding danger and mating and sleep, thermoregulation
  - The figure above shows the location of  the hypothalamus
  - These deep structures are common to every vertebrate
  - Humans have a hypothalamus and fish have a hypothalamus
  - These deep structures are shared and ancestral among all vertebrates

- In humans there is this surface structure that is incredibly elaborated in our lineage and is responsible for some of the most complex and mysterious things we do
  - The great thing is that mice sort of sit somewhere in between fish and humans
    - They have the cortex that we have and it’s amazingly similar
    - It’s got the same six layers
    - It’s got the same kinds of neurons that are connected in the same way
    - It’s just much smaller than what is in humans
    - And so by looking at the fish and the mice and humans, he can piece together a lot by studying the cells and the connections that make things happen
    - This is the context of his work as a neuroscientist
- The first layer is the [brain stem](https://en.wikipedia.org/wiki/Brainstem); this is the most primordial layer that handles so many functions one is not even thinking about, like breathing
  - The figure below shows the 3 parts of the brain stem: the midbrain, pons, and medulla

![](https://peterattiamd.com/wp-content/uploads/2022/01/f8-karld-1024x707.png)

**Figure 8. The brain stem.** Image Credit: [OpenStax Anatomy and Physiology figure 13.12](https://openstax.org/books/anatomy-and-physiology/pages/13-2-the-central-nervous-system)

- The brain stem is highly, highly conserved
- In the brain stem and in the midbrain, are a clusters of neurons, like the [dopamine neurons](https://en.wikipedia.org/wiki/Dopaminergic_pathways) and the [serotonin neurons](https://en.wikipedia.org/wiki/Serotonin_pathway) and the noradrenaline (or norepinephrine) neurons
  - They’re all clustered there in the brain stem in and around other cells that govern the movement of the muscles of the face and neck that send information down to the rest of the body
    - The vagus nerve is one example
  - These basic structures in the brain stem are highly conserved
    - Fish and mice and humans all have them
    - There’s a little bit of different shaping and arrangement, but it’s basically the same logic

**Messages neurons send to other neurons**

- Peter asks if each neuron can only emit 1 neurochemical, such as serotonin
  - Is this largely a binary signal or are there neurons that can secrete more than 1 neurotransmitter?
- A relatively recent understanding is that there are multiple neurotransmitters that can be released by the same neuron
- One still refers for example, to the dopamine neurons as dopamine neurons, because that’s what makes them special
  - That’s what they can do that other neurons can’t do
- But what’s been discovered recently, what the field has discovered is that [dopamine](https://en.wikipedia.org/wiki/Dopamine) neurons, some of them also release another neurotransmitter called [glutamate](https://en.wikipedia.org/wiki/Glutamate_(neurotransmitter))
  - Glutamate is an excitatory neurotransmitter; it stimulates the downstream cells (a postsynaptic neuron)
- Other dopamine neurons can release a different neurotransmitter called [GABA](https://en.wikipedia.org/wiki/Gamma-Aminobutyric_acid)
  - Gaba is an inhibitory neurotransmitter; it shuts down the cell that’s receiving the signal
- So there’s actually a great deal of complexity; and there are also other things that can be released at the same time, [neuropeptides](https://en.wikipedia.org/wiki/Neuropeptide)
- There’s a lot of complexity on the other side of the synapse, too (in the postsynaptic neuron)
- Different cells have different receptors for the different chemicals that can do totally different things
  - There can be a receptor for glutamate that makes excitation happen
  - Or there can be another receptor for glutamate that doesn’t do that, but makes a longer pattern of modulation happen that’s not even a direct excitation
  - This is just a flavor of the complexity
- But broadly speaking, neurons are still referred to  as things like dopamine and serotonin neurons, because that’s the first level of complexity

## Traditional techniques for identifying the brain regions involved in specific behaviors [47:15]

Peter asks “*Prior to the work that we’re going to get into here, what tools existed to really try to establish causality between the stimulation of one region of the brain and some sort of response, be it a phenotype or an impulse?*”

- Was there ever any way to imagine how one part of the hypothalamus was responsible for a type of thought or emotion?
- How was that probed?
  - Karl notes, this was a big challenge that neuroscience faced, finding out what actually matters for function

**Electrical stimulation is useful but has limited resolution**

- There are ways of listening in
  - There are ways of putting in electrodes to listen, to pick up electrical patterns of activity
  - One can put an electrode in the cortex or in the hypothalamus or in the brain stem, and pick up the chatter of neurons as these little electrical impulses go by
  - One could use the same electrode to also stimulate.
    - One could send current in through this wire that has been placed, and that has an effect
  - So one can make things happen by just sending current into the brain
    - At some level, though, this is just a scaled down version of the electroconvulsive therapy discussed earlier, which is also just current being put into the brain, causing things to happen; but there’s no cell specificity
- Every single neuron in the brain is electrical and all parts of every neuron are electrical
  - Not just the cell body itself that has the DNA in it, but also every part of the axon, the dendrite; it’s all electrical
  - And so if one sends in current to a spot in the brain, even with a tiny electrode, it’s affecting every single cell near the electrode
    - And not just that, it’s affecting every bit of wiring that happens to be going through there
    - So there’s no cell type specificity because every cell is electrical
    - Still thought, this can be useful
- There was a great deal of foundational work in neuroscience going around and stimulating different parts of the brain and observing what happened
  - It was discovered that if one put an electrode in the parts of the brain where dopamine neurons live and where the axons come out, that rodents will really work hard for that; they seem to really like it
    - This can be inferred because they will press a lever thousands of times a day to get a burst of electricity to the dopamine neurons
  - Little clues like this built up over time, but then there was always complexity as scientists dove deeper into it
    - The realization came that, wait, this is not just the dopamine neurons
    - In this region of the brain there are a lot of other cells and connections
    - So is it really the dopamine neurons? It’s this region, but what really are the cells?
    - And so there was a lot of uncertainty in the field as to which cells were actually doing what.
- Apart from electrical stimulation, there was not a good way to turn things off also
- Karl notes, in science, “*we like to add things and see what happens, and that’s testing whether something is efficient to cause and effect. And we like doing that, that tells you something. But then we also like to take away something of interest and we can see what is lost with that. And that’s testing the necessity of something. How much is that needed? We would’ve liked to turn off cells and say, okay, now what’s different in the animal and their behavior?*”
- It was known that if one stimulated really hard with an electrode, this could effectively exhaust the cells and make them not fire anymore
  - That was state-of-the-art, both clinically and research wise, in trying to create a local inhibition
  - But again, this was not cell type specific at all, because all the cells are electrical
- This the kind of situation that he found himself in, not too different clinically or in research, no cell type specificity

## Intro to optogenetics and how to get a gene into a neuron [51:15]

**The promise of channel opsins**

- There are these small plants, single-celled plants that make [channelrhodopsins](https://en.wikipedia.org/wiki/Channelrhodopsin)
  - These are single proteins that are placed in the surface membrane of cells, but microbial cells, not in our cells
  - These are found in algae, single-celled algae
  - Related molecules are present in ancient forms of bacteria
- These have been known to exist for years
- This class of protein is really interesting because they’re light activated electricity generators
  - These are single bits of biology, single biomolecules that do an amazing job
  - They receive a photon of light and they move charged particles, ions across the surface of the cell
  - Now there’s a huge family of these
  - These are called [microbial opsins](https://en.wikipedia.org/wiki/Opsin#Type_I_opsins), and a sub family of them is called the channelrhodopsins
  - Now what’s amazing is that these proteins were known broadly in biology, in biochemistry for decades
    - They were discovered in 1971 by [Dieter Oesterhelt](https://en.wikipedia.org/wiki/Dieter_Oesterhelt) and [Walther Stoeckenius](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3149375/), who were at UCSF
- This was part of the training of biochemists, biologists in [Lubert Stryer’s](https://en.wikipedia.org/wiki/Lubert_Stryer) beautiful [biochemistry textbook](https://www.amazon.com/Biochemistry-Lubert-Stryer/dp/1319114679/ref=sr_1_2?keywords=stryer+biochemistry&qid=1637000274&qsid=146-5475333-0110134&sr=8-2&sres=1319114679%2C1464126100%2C0716787245%2C1319114636%2C1464126135%2C1464188033%2C0716746840%2C1319114792%2C1319032958%2C1319275443%2C1319274579%2C1429283602%2C0716730510%2C0716725606%2C1429276355%2C0716720752&srpt=ABIS_BOOK); there’s a page on the [bacteriorhodopsin](https://en.wikipedia.org/wiki/Bacteriorhodopsin)
  - This is where Karl learned about it
  - These proteins, they have a photo cycle
    - This is a choreography of movements of the protein after the photon hits; this leads to an ion (a charged particle) moving across the membrane of the cell
  - So this was a class of proteins that was well known
- It turned out that these microbial opsins turned out to be the key for [optogenetics](https://en.wikipedia.org/wiki/Optogenetics), the technology Karl developed that brought this cell-type-specific causality

Peter asks, ***When did Karl realize he could genetically insert these things into neurons and effectively put a digital switch into a single neuron?***

- There was a coalescence of different threads that happened that were partly plausibility threads
- And if you look at this historically, anybody in theory could have thought about this and tried this
- In the late eighties or all through the nineties, these genes were known; somebody could have put them into neurons and tried this, but it wasn’t technically plausible for many reasons

**How to get a gene into a neuron [54:30]**

- There were not good ways of introducing genes into neurons until the nineties, and particularly the late nineties
  - Neurons are a little bit tricky; they’re very finicky and sensitive
  - He knew this because it was a theme in his PhD work, and also in my postdoc work
    - He studied how to get genes into neurons
    - Even in a cultured neuron preparation, it’s not easy
  - This is part of why nobody had tried this before
  - But in the late nineties that started to change; he did an experiment introducing genes into neurons as part of his postdoctoral work in the [Malenka lab](https://profiles.stanford.edu/robert-malenka?tab=research-and-scholarship)
    - This was something he was good at
    - He developed the viral tools and the ways of introducing genes into neurons
- Introducing genes into neurons is by no means a minor thing; it’s very technical

**DNA contains instructions for making proteins**

- [DNA](https://en.wikipedia.org/wiki/DNA) is the instruction manual for making proteins, things like proteins, biomolecules that have a job
- Each [gene](https://en.wikipedia.org/wiki/Gene) is a bit of DNA; it is a sequence of what is called [nucleotides](https://en.wikipedia.org/wiki/Nucleotide)
  - There are 4 different nucleotides: A, G, C, and T
  - The order in which these nucleotides appear is a code
    - That’s the [genetic code](https://en.wikipedia.org/wiki/Genetic_code) that dictates which protein will be made
    - A protein is a biomolecule that has a particular structure and a job that comes from its structure, like being in a channel or something in the surface of a cell that receives a photon and lets a charged particles go across
    - The instructions for making a protein are encoded in the DNA, in the gene
- How does one get a gene into a cell?
  - [Viruses](https://en.wikipedia.org/wiki/Virus) are are little bits of biology that basically exist to get DNA and RNA into cells
  - Viruses have a little bit of this genetic code, this material (DNA or RNA) and they have that encased in a coating that might have some lipids or fats and some proteins
  - A virus floats through liquid or floats through the air, hits a cell and fuses with the cell; this gets the DNA or the RNA into the cell
    - Then that triggers the creation of new virus particles; and then that’s how the virus spreads.
  - Viruses are extremely good at getting genetic material into cells; they are evolved for that
    - Some viruses work with DNA and some work with RNA
    - RNA is the step in between DNA and protein
    - From the DNA sequence of a gene an RNA copy is made ([transcription](https://en.wikipedia.org/wiki/Transcription_(biology))); this is translated ([translation](https://en.wikipedia.org/wiki/Translation_(biology))) into a protein; the describes the [flow of genetic information in biology](https://en.wikipedia.org/wiki/Central_dogma_of_molecular_biology)

**Viruses can get a gene into a cell**

- Viruses are very useful for biologists, if one wants to get a gene into a cell
- There are dangerous and lethal viruses, but there are also safer, weaker viruses
  - Some viruses have been modified by virologists to be extremely safe; they have lost the ability to propagate from one cell to another
  - But, they can still do that first step; they can bring DNA into 1 set of cells
  - After that, the life cycle, if you will, stops
- Karl worked with safe, modified viruses that can be used to shuttle bits of DNA into cells; that’s the core technology
- It was a very recent technology to use viruses to get genes into neurons
  - Many people were trying to do this
- Karl’s lab published the first paper that used a microbial opsin to get light sensitivity in the summer of 2005
  - Published in *Nature Neuroscience*, [Millisecond-timescale, genetically targeted optical control of neural activity](https://pubmed.ncbi.nlm.nih.gov/16116447/)
  - This was a close call because within 6 months, several other papers came out; they were all submitted right after theirs was published
  - Clearly, many people had been thinking about this
  - He didn’t know at the time that the brother of his PhD advisor, [Roger Tsien](https://en.wikipedia.org/wiki/Roger_Y._Tsien) (a Nobel laureate for his work with [green fluorescent protein](https://en.wikipedia.org/wiki/Green_fluorescent_protein)) was working on this as well
- Now there was a broad awareness in the field that technology was now available to introduce genes into neurons
- People had wanted to get cell type specificity for a long time with neurostimulation
- [Francis Crick](https://en.wikipedia.org/wiki/Francis_Crick) (of DNA double helix fame) had been calling for this technology for years
  - In fact, in 1999, he’d even suggested that not only did we need a way in neuroscience to control individual cell types, but he said maybe light would be a good way of doing it
  - He didn’t have an idea of how to do it, but he said light would have some good properties: it would be fast, it would be relatively noninvasive
  - Photons could scatter through tissue and most neurons don’t respond to light at baseline, unlike electricity
  - And so light would be a way of getting great specificity

> “So there was this broad awareness that this kind of thing suddenly might be possible” – Karl Deisseroth

## How viruses helped make optogenetics possible [1:01:45]

**How to introduce enough opsins to control a neuron**

- 1 virus can introduce the gene to 1 neuron
  - The virus lacks the capacity to replicate
  - The dose of the virus determines how many cells will get the gene
  - If a high concentration of viral particles is used then more cells will get infected
    - Also there will be more copies of the gene delivered to each cell
    - Multiple viral copies can infect the same cell; this is very important
- These microbial opsins generate tiny currents
  - They are not generating the huge currents that mammalian ion channels are
    - This is a big reason why a lot of people didn’t rush to this
    - People looked at the current size and thought, “*This is not going to work.*“
- Most existing methods of introducing genes give maybe 1 to 7 copy numbers of the gene; this is not enough to control a neuron
  - That was a huge issue
  - But with the viral technologies, one could get 100’s or more copies of the gene per cell
    - This provided much bigger currents with these microbial opsins; in the picoamps and nanoamps range
    - So then again, his experience with viral tools was critical
- The [action potential](https://en.wikipedia.org/wiki/Action_potential), this is this blip of electricity that propagates down the axon of a neuron, it can be triggered by signals that are in the order of 100 to 200 picoamps
  - And then it becomes a voltage impulse that’s about a 100 millivolts, and that propagates down the cell
  - One needs in the range of hundreds of picoamps to control a neurons
    - A single opsin produces vastly less electricity than that
- Karl found that without a high copy number of opsins, the current generated is on the single or less picoamp level
  - Current levels this small aren’t useful because he isn’t measuring current from a single channel
  - Since then, out of scientific curiosity, he and others have looked at the currents that are generated and they’re extraordinarily small
  - He only gets to the 100’s of picoamp level by expressing probably a hundred thousand to a million opsins per cell
- This was the key issue; this was many orders of magnitude (several factors of 10) away from where it needed to be with these opsins unless there was a way of introducing many genes and getting very robust, safe expression

**How to achieve opsin production in specific cells and not its neighbors**

- Introducing the virus into say, a mouse was the other technological challenge that had to be faced
  - It was not obvious how this would be done
  - Where would the specificity come from?
  - Yes, none of the cells respond to light
  - Yes, maybe a gene could be added that makes the cells respond to light, but wait, where’s the specificity going to come from?
  - How does one get this gene only into the cells of interest?
- One possibility is to concentrate the virus and do a very focal injection into, let’s say, the [pons](https://en.wikipedia.org/wiki/Pons)
  - This could create a little hotspot of virus and then that virus would get into all the cells that are in and around that spot in the pons; and that’s good
  - That would give some spatial specificity
  - This is already a big leap beyond the electrode because the electrode and the virus both so far in how they’ve been described are not cell type specific
    - The electrode was going to be stimulating all the axons that happened to be going by
- If the virus is injected at one spot, viruses are not very good at getting into axons
  - They’re just going to get the cells, the little spherical cell bodies that live in that region
  - So right away that provides some specificity
  - There are less of the cross-streams of activity being stimulated
  - But it’s not enough because even if it’s just getting the cell bodies that are in that region, there are many different kinds of neurons
    - There are the dopamine cells, but right next to them there are the GABA cells, and next to them are the glutamate cells; and they’re all jumbled up together
    - This again is not too different from the electrode
    - Now if one puts in light, it’s still going to be simulating all these cells
- What is needed is a way to make the production of the opsin cell-type specific
  - With a virus, there were many possibilities they thought about
- This was the critical issue, “*How do you get a versatile, generalizable way of targeting specific cell types?*”
  - That probably took until 2009
  - Back in 2004, 2005, there were some possibilities that he and others could imagine
  - He could try to imagine engineering the [virus capsid](https://en.wikipedia.org/wiki/Capsid), this coating of the virus that has proteins on it
  - There were theoretical ways and even possible practical ways of engineering capsid proteins so that they would only target one kind of cell because that kind of cell had something else on its surface, and maybe we could create some kind of lock and key mechanism
    - For example, a [coronavirus](https://en.wikipedia.org/wiki/Severe_acute_respiratory_syndrome%E2%80%93related_coronavirus), its lock and key works through the ACE2 receptor
    - One could target a potential surface protein or receptor on the dopaminergic neuron for viral attachment and entry
    - The drawback was that he didn’t have that richness of understanding to choose a protein specific to only dopaminergic neurons; there was not look-up table
    - Every time one wants to target a particular cell type, one has to now do some deep dive into all the proteins it expresses and also all the cells that are nearby that one doesn’t target them or have some cross-reactivity
    - And so while initially plausible, this is never going to versatile, generalizable, and practical; it still isn’t today

**The solution was to control expression of the opsin**

- Another strategy is working with DNA
- Each gene, each bit of DNA in chromosomes, in genomes, contains the code for a protein
- But also near it, it’s got another bit of DNA that’s called a [promoter](https://en.wikipedia.org/wiki/Promoter_(genetics)) or an [enhancer](https://en.wikipedia.org/wiki/Enhancer_(genetics))
  - This is a bit of DNA that doesn’t code for a protein
  - What it does is it attracts what are called [transcription factors](https://en.wikipedia.org/wiki/Transcription_factor), things that decide whether that bit of DNA gets turned into RNA and then into protein
- By changing the structure around the gene, the promoter and enhancer determines whether this gene is expressed at all
  - The gene could sit there quiet and not be used to make the RNA and the protein, or it could be active and make the RNA and a protein
- This turns out to be critical because that was the path forward
  - He could work with the bits of DNA near genes, promoters and enhancers; this gave him some leverage
- Think about a dopamine neuron again
  - What is a dopamine neuron?
  - It makes dopamine and it releases dopamine
  - Okay, now how does it make dopamine?
  - Well, it’s got its own biomolecules that make dopamine; it’s got [enzymes](https://en.wikipedia.org/wiki/Enzyme) that turn other precursor chemicals into dopamine
  - Now those enzymes are made chiefly in dopamine neurons
  - And why are they only made in dopamine neurons and not in your big toe neuron or not in the serotonergic neuron right next door?
  - It turns out that each cell type is defined by its job, just as in many case we are defined by our jobs
    - This is a critical thing because a professional dopamine-producing cell is going to have promoters or enhancers that dictate activity of genes encoding dopamine enzymes
    - For example, the tyrosine hydroxylase gene is a gene that helps make dopamine; it is active in dopamine neurons
- What Karl did was to take a little bit of the promoter from the tyrosine hydroxylase gene and put it in front of the [channelrhodopsin](https://en.wikipedia.org/wiki/Channelrhodopsin) gene
  - Then he packaged that whole thing up into a virus and infected cells
  - The virus could now be administered systemically because this is an elegant solution to target expression of the opsin in dopamine neurons
    - A higher load of virus needs to be used if given systemically
    - A focal injection provides other advantages, and this was preferred
  - The specificity was taken care of by the promoter
    - The virus gets into all cells (both serotonergic and dopaminergic neurons) but the genes is only expressed, and the opsins are only made in the dopaminergic neurons as a result of the promoter

**Is the immune response a barrier to opsin expression?**

- Peter notes that in a typical viral infection, for instance with an [adenovirus](https://en.wikipedia.org/wiki/Adenoviridae) that causes a garden-variety cold, the immune system responds and clears infection
  - The adenovirus infects the epithelial cells lining the trachea
  - The virus uses the cell’s machinery to copy its genetic material and make viral proteins; this is how it replicates
  - The immune system is very good at recognizing this
    - Soluble [antibodies](https://en.wikipedia.org/wiki/Antibody) can bind virus released by infected cells
    - [T cells](https://en.wikipedia.org/wiki/T_cell) can recognize infected cells through [MHC class I](https://en.wikipedia.org/wiki/MHC_class_I) or [MHC class II](https://en.wikipedia.org/wiki/MHC_class_II)
      - MHC class I will present viral antigen on the surface of an infected cell for a T cell to recognize; the T cell will come and destroy that cell
- The question is, how can one prevent the immune system from eliminating the genetically engineered virus?
  - This was another barrier to overcome
- There is something special about the brain; it’s an [immune-privileged](https://en.wikipedia.org/wiki/Immune_privilege) organ
  - The [T-cells](https://en.wikipedia.org/wiki/T_cell) and [B-cells](https://en.wikipedia.org/wiki/B_cell) that patrol the body don’t have free access to the brain
- Karl has recently explored this sort of thing in peripheral optogenetics (not in the brain)
  - It works
  - There is a loss of opsin expression over time, over months
    - The immune response is part of that loss
    - This doesn’t happen in the brain; this is a benefit of the immune privilege of the brain

## How optogenetics was used to investigate the effects of dopamine neurons [1:15:45]

- With a opsin gene introduced into a specific type of neuron, light (or photons) can be used to turn the neuron on and off with precision
  - This became possible in 2009-2010

Peter asks: ***What was the first question you sought to ask using this technology from a neurobiology and neurochemical standpoint?***

- One big question Karl (and everyone in the field) wanted to understand — what is the role of **dopamine neurons** in the response generated when animals are stimulated in a particular region of the brain
  - Are the dopamine neurons responsible for the animal’s response or is it some other cell nearby?
    - Is it the [GABAergic cells](https://en.wikipedia.org/wiki/GABAergic)?
    - Is it the [serotonergic cells](https://en.wikipedia.org/wiki/Serotonergic)?
- In 2009 he introduced an excitatory channelrhodopsin into just the dopamine neurons of this spot in the mid brain that’s called the [ventral tegmental area (VTA)](https://en.wikipedia.org/wiki/Ventral_tegmental_area)
  - The VTA has all these other kinds of cells, but that’s where the dopamine neurons also live
  - He used a souped-up form of the promoter strategy he just explained to get the gene expressed in just the dopamine neurons
  - He asked a very simple question
    - He gave a mouse a simple 2-room house to live in; it can go back and forth from one room to the other
    - He turned on the laser light, the light that activated the channelrhodopsins on the dopamine neurons, only when the animal was in one room and not the other room?
    - He then looked to see when he did this, what room the animals preferred to be in
      - Would the mice prefer to be in the room where the laser light had been applied or the other room?
      - These rooms were equivalent in every other way
- To provide a crude comparison, he could have put sugar water in 1 room of this mouse house and not the other
  - This would allow him to see if the mouse preferred the room with the sugar water (or something else pleasurable), or not
- This test is an old test; it’s called the [conditioned place preference test](https://en.wikipedia.org/wiki/Conditioned_place_preference)
  - The animal now prefers a place and it’s because of the conditioning
  - One would pair something good like cocaine or sugar or food or social interaction, a material) with one room, and one would see later that the mouse would choose to spend time in there, revealing by its behavior that this thing had a positive value to it
- The flip side can be done too; this can use a negative thing
- One can make the animal feel mildly nauseous
  - It could be given [lithium](https://en.wikipedia.org/wiki/Lithium), which is given to patients, too, and one side effect that they can have is mild nausea
  - One can give the mouse mild nausea in one room, and then it’ll avoid that room
    - And that’s conditioned place aversion
  - So the animal can report the sign, the valence positive or negative of its experience by where it chooses to spend time; and that’s incredibly valuable
- This hearkens back to Karl’s very first experience wanting to be a neurosurgeon because a human being could tell him what they were feeling
  - Well, of course, the human being is more eloquent than a mouse
  - But behaviorally, a mouse can report whether something is of positive or negative value to it
- This experiment looked solely at the excitation of a dopamine neuron
- Peter asks what a positive balance would look like in this conditioned place preference test
  - Is it 51/49 in favor of the dopamine firing; the preference for the room where the mouse receives the light to activate the opsins in the dopamine neurons?
  - If this experiment was run 100 times, how many times would the mouse go to the positive valence side?
- With typical rewards such as sugar water, or social interaction, the number showing a positive preference is 70/30 or 80/20
  - That’s the level to which the mouse will prefer one chamber versus another
    - One room versus another in terms of how it devotes its time
- But these numbers can be pushed optogenetically using light (or with stimuli) up or down by making the experience more extreme
  - It’s quite a flexible test
- In some ways the animal is expressing its subjective sense by where it’s choosing to spend time
- He can also make a more souped-up version of that test where the animal actually has to work to get the light by pressing a lever or poking its nose in a little hole and trigger a pulse of light by each of its actions
  - This is called [self-administration](https://en.wikipedia.org/wiki/Self-administration)
  - This is a slightly more advanced version where it tests how hard the animal will work for light
  - How hard will the animal work for a precisely defined set of activity in precisely defined dopamine neurons?
- With this test an animal will press a lever thousands of times a day to get that light
- So now there is no doubt that the activity of dopamine neurons in this way is positive
  - And it’s not just positive, it can be extremely positive
  - Animals will work very, very hard to get it

## Appreciating the power of optogenetics [1:22:00]

- The appreciation by clinicians, psychiatrists, who also have some interest in the science side was very quick and immediate because they knew better than anyone else how much this specificity was was needed and wanted in field
- In 2009, the generality of this targeting method was key because then people knew, okay, this wasn’t just a parlor trick, a one-off, a demonstration that one could get some photosensitivity in one cell
  - People recognized that this was actually a generalizable versatile method
  - One could apply this principle to any cell type
  - It was done in freely moving mammals
- With mice having our same brain structures (our cortex, our hypothalamus and everything in between), the significance and the opportunity was pretty clear to everyone by 2009, particularly the psychiatrists
- So there was a great deal of interest and because the technique was generalizable
- It was very widely adopted
  - He sent out clones (the bits of DNA) to thousands of labs around the world
  - And many thousands of discoveries were made by other labs, which was great
  - This showed that anybody could use this technique to tackle any question, any disease, any symptom in diverse animals
- So after 2009, it was off and running
  - Between ’04 and ’09, though, those were hard times because his lab was still putting the pieces together
  - Solving the light delivery
  - Solving the virus issues
  - Getting the cell type targeting to be generalizable and versatile

**Funding**

- Early on, he had some initial trouble getting grants
- But then pretty quickly once the opportunity became clear, both the [National Institute of Mental Health](https://www.nimh.nih.gov/) and the [National Institute on Drug Abuse](https://www.drugabuse.gov/), two main institutes of the NIH, immediately were very supportive
- Then later he got a great deal of support from [DARPA](https://www.darpa.mil/) and from the [National Science Foundation](https://www.nsf.gov/)
- He also got support from a number of private donors
  - People who in many cases came through the psychiatry setting
  - Friends or family members who had suffered from a psychiatric disease and they had heard about what we were doing and wanting to support it
- So he ended up getting both federal and nonprofit institutions and private donors, and it all came together
- But really, until he had things working in this generalizable way, times were a little bit tough

## Investigating and treating anxiety with optogenetics [1:26:45]

- Karl wanted  wanted to understand the internal states of mammals and how they can go wrong and create symptoms
- Working with animal subjects, with mice for example, one must figure out what they can report that matters
  - One thing they can report very well are these universal things that all mammals experience: anxiety, social interaction, and caring for offspring, for young
  - These are quintessential mammalian states that matter; they can go wrong
- He wanted to study them and he wanted to study them in ways that were now precise and causal and had to do with specific cell types

**Anxiety**

- One of the first things his lab studied was anxiety
- As a psychiatrist, he specializes in patients who suffer from depression, and also social difficulties, and autism spectrum disorders
  - A common theme in both autism and depression is anxiety
- Anxiety is not a small thing
  - Anxiety can be absolutely crushing to one’s life, to one’s interactions, to occupation, to even being able to go out in the world
  - This is a potentially severe disorder in many people
  - Of course, anxiety also can exist in a normal healthy range too
  - It only becomes a psychiatric disorder when it exceeds that healthy range and verges into or, in many people unfortunately goes way beyond, into a pathological extreme
- How is that maladaptive transformation from normal anxiety to pathological anxiety defined?
  - The other extreme is a person incapable of experiencing anxiety; they could probably injure themselves and might be socially quite destructive
  - There must be some evolutionary basis for anxiety and self-preservation
- What is the [DSM-5](https://en.wikipedia.org/wiki/DSM-5) (a diagnostic and statistical manual) criteria for anxiety that has gone too far?
  - The criterion for rising to the level of disorder in the psychiatric literature is — it’s only a disorder if there’s impairment in social or occupational functioning
  - Someone can have a symptom in psychiatry, even a hallucination for example, but if it’s not impairing their life, social function, occupational function… it’s not called a disorder
    - Karl has had patients who were hallucinating but it was in a way that was not disrupting their life
    - He had a blind patient who had visual hallucinations; but he was fine with them, they weren’t distressing
      - So this was not a disorder
  - This is flexible because different people have different social and occupational situations
  - And this is a challenge in psychiatry
  - But maintaining this as a criterion is very good because it ensures that psychiatrists only treat the things that need to be treated
- To think about anxiety, if someone can’t function, they can’t leave their apartment to go to work; that is impairing their occupational functioning
- There are people who have anxiety easily in that realm or far beyond, and those are people he wants to help
- On the flip side, there are people who have risk taking behavior that’s extreme because they don’t perceive or worry about threat, and that’s also a problem
- So anxiety needs to be treated in patients who are severely affected
  - And the problem is, in anxiety, there are medications that help, but they come with some problems
  - The most effective anti-anxiety medications are things that relate to [Valium](https://en.wikipedia.org/wiki/Diazepam) and [Xanax](https://en.wikipedia.org/wiki/Alprazolam) and [Ativan](https://en.wikipedia.org/wiki/Lorazepam)
  - These are medications that work, but they can be addictive
    - They can cause the human being to adapt to the dose and to make it very difficult to stop taking the medication
  - It is thought that these medication primarily work as a [GABA agonist](https://en.wikipedia.org/wiki/GABA_receptor_agonist)
    - [GABA](https://en.wikipedia.org/wiki/Gamma-Aminobutyric_acid) is a relaxing neurotransmitter; it is non-excitatory
  - Other problems with these medications is they cause cognitive slowing and sedation
    - Not everybody can tolerate them
- Peter asks what neurons GABA receptors are concentrated in for their action in the brain
  - Karl replies, “*That is a great question. It’s the subject of a lot of research*”
- It is not known which cells are the most anxiety-relevant cells that these medications target
  - This is where optogenetics can be helpful
  - This is the the type of question that can now be answered
- It will be useful to know which cells govern the different features of anxiety
- Anxiety actually has different parts to it
  - Changes in physiology: the heart beats faster, breathing is faster
  - Changes in behavior: avoidance of a risky situation or impulse
    - When people or mice feel anxious they avoid going out in the open
  - The negative quality is the hardest to define and most mysterious
    - This is the most difficult to experience
    - If one is avoiding a risky situation, why does nature make it feel so bad?
- Anxiety feels bad and in many cases, causes so much suffering in addition to the behavioral dysfunction that happens
  - So actually, anxiety is complicated
  - It’s got these different parts, and they all come on together, all go away together
- This brings up the question, are these parts controlled by different cells?
  - Next, what cells should be targeted for treatment?
- In 2013 Karl’s lab did an optogenetics experiment that targeted different parts of what they thought could be the anxiety pathway
  - They found that indeed different cells control each of these different parts
  - There’s a set of cells that control the breathing changes
  - And there’s another set of cells right nearby that control the behavioral changes, avoiding risky situations
  - And there’s yet a third set of cells that control the negative valence, the internal state, the bad feeling
  - Each cell type cleanly controls separate feature of anxiety
  - This was answered with optogenetics, introducing light sensitivity and light triggered activity
    - And also reproducing each of these completely distinct manifestations of anxiety
- They found they could turn up or down each feature of anxiety in mice, completely separately from the other features
- This got so interesting philosophically; they could make animals avoid the open area,
  - Many people don’t like being out in exposed areas
  - Mice definitely don’t because that’s when they’re going to get eaten
  - They could make mice be much more avoidant of an open space with a specific cell type optogenetic intervention
    - But the mice didn’t care that this was happening
    - There was no negative valence to it
    - And this was so interesting that we could create the behavioral avoidance of anxiety without the mice having this negativity

> “It turns out then that behavioral states that mammals have, they can be cleanly broken apart into these features, and we could show that with optogenetics” – Karl Deisseroth

**Parenting**

- Other people have done some great work on parenting, another quintessential mammalian state using the same set of optogenetic techniques
  - [Catherine Dulac](https://en.wikipedia.org/wiki/Catherine_Dulac) for example at Harvard, did this in 2018
  - Mice are pretty good parents; they take care of their young
  - Her lab did an amazing experiment; they optogenetically found that different parts of parenting could be broken down into their subfeatures as well
  - And the two parts of parenting that were broken down in this way are (1) going out to find the young and bring them back to the nest and (2) caring for the young, grooming them

> “Those are just two examples, but that kind of thing really gets to the heart of what’s so interesting about the brain. How are these complex states…  pieced together from cells?” – Karl Deisseroth

## Autism and autism-related anxiety, and the potential of optogenetics in treating autism [1:38:00]

Peter asks why anxiety tracks so closely in people with [autism](https://en.wikipedia.org/wiki/Autism)

- What is understood about autism?
  - There is a significant genetic component
  - It’s not clear though, what triggers it
  - The phenotype exists on a pretty extreme spectrum in terms of functionality, superpowers, and super deficits
- Autism is one of Karl’s main clinical areas of focus
  - He sees patients with [autism spectrum](https://en.wikipedia.org/wiki/Autism_spectrum) disorders here
  - He knows that they are hard to treat
  - There’s not a medication that treats autism
- Alot of autism patients are very anxious, and he can help them with their anxiety
  - He uses medication like the [benzodiazepine](https://en.wikipedia.org/wiki/Benzodiazepine) class of medications discussed earlier
  - These help the anxiety; they don’t help the social problems per se, but they help with the anxiety
    - The question is why is this? Why is anxiety such a [comorbid](https://en.wikipedia.org/wiki/Comorbidity) symptom?
- Why does anxiety show up so much in autism?
- Well, the human social interaction world is very complicated
  - It’s very fraught with possibilities for misunderstanding, catastrophic errors of interpretation, embarrassment, humiliation, confusion
  - We have a very social world that we’ve created
- For people who have difficulty with keeping up with the fast rate of social information and making sense of it, social interactions provoke a lot of anxiety
- For someone on the autism spectrum, these are extremely challenging situations because it’s very hard to keep up with this high information rate of the social interaction
  - For example, when they talk to someone, how do they know where to look, what to do?
  - What part of the person do they pay attention to?
    - Do they look at the eyes, the mouth?
    - Do they look at body movements?
  - God forbid there’s more than one person
    - In a conversation with three people, how do they know who to look at?
  - How do they know what to say next?
- He has patients who are as confused by social interaction and as overwhelmed by it as one can imagine somebody not knowing the language, not knowing the customs of a culture, and being placed into it while extremely consequential things involving them were happening in real time; this is the situation
  - One can understand anxiety being a big part of autism, just being unable to predict what happens
- These are patients who he can help with their anxiety, still not yet with their autism
- There are many genes that are linked to autism; it’s a very genetically determined disease, not completely but heavily
- The problem is, like so many of the psychiatric disorders, the genetic underpinnings are a patchwork
  - It’s many different genes that all contribute a little bit in those cases
  - And so with all the beautiful genetic studies, which has given a lot of insight, it hasn’t led to treatments because there’s not a single gene, single protein, single cell to intervene in yet

**What does treatment for autism look like in the coming decade?**

- Optogenetics has given us a window now into what could be this 10-year time scale of autism treatment
- Mice are social
  - They parent
  - They will choose to spend time with another, even same-sex member of their species, compared to being alone
  - And they have complex interactions
    - They have a give and take
    - They exchange information, and there’s a lot of it
- When his lab makes mutations in some of the genes that are most powerfully related to autism (that come from the human literature), they can make mice that have impaired social interaction as well
  - They’ve studied these in the laboratory
  - They’ve asked, can the social deficits of these mice be corrected?
    - And the answer is yes
- This is a whole thread of work in his laboratory, studying social interaction
  - Asking which cells, which circuits in the brain can improve social interaction, including in these autism-mutation mice
- Think about social interaction, the parenting example made this clear; there are different parts to it
  - Part of a social interaction might be the motivation, the drive to be social
    - This could vary in people
  - Part of social interaction might be cognition, the understanding, the insight
    - That could be separate
  - Probably different cells affect each of these
    - And indeed they found some dopamine neurons that do seem to increase the drive for social interaction
    - But then there are other cells in the front of the brain, where some of the most advanced, complex cognitions happen (the frontal cortex) that may be more involved in the information fire hose that’s coming through with a social interaction
      - How does one keep up with it?
      - How does one make sense of it?
      - That may be more of the cognitive side
- He now knows the cells that can improve social interaction in these different areas
- And now that he understands these cells better, one can imagine designing medications that for the first time are aligned with a specific kind of cell that’s known to be important in social interaction
  - This is an exciting opportunity for the future
  - It’s not here yet, but at least now there is a causal cellular understanding, and that opens so many doors

## Optogenetics as a powerful tool for the discovery and creation of medical treatments [1:45:00]

- Peter asks if in the next decade or so, will optogenetics be the tool for establishing cellular signal-wise causality, but not be the mode of treatment?
  - Will patients come to the clinic with probes that can be activated directly with light to change the neurotransmitters present?
  - Or is optogenetics just a tool to establish where to target treatment?

> “Optogenetics, in my view, is by far the most important… as a discovery and understanding tool.” – Karl Deisseroth

- This allows scientists to understand what makes things happen in the brain at the level of cells
  - This is the opportunity that optogenetics creates
- And that understanding then opens the door to every kind of treatment
- Once it is understood which cells are actually causing and relieving symptoms, then medication can be designed that address those cells
  - Brain stimulation treatments can be designed to target those cells or their axons as they project across the brain
- Providing this causal foundation opens up every door, in principle

> “As I see it, by far the future, it’s the understanding that opens every treatment door” – Karl Deisseroth

- His friend and colleague, [Botond Roska](https://en.wikipedia.org/wiki/Botond_Roska) in Switzerland, just this year was able to confer a form of sight to a blind person with optogenetics
  - This was just published in the *Nature Medicine* this year, [Partial recovery of visual function in a blind patient after optogenetic therapy](https://www.nature.com/articles/s41591-021-01351-4)
- 10 years ago they collaborated on a study where he put one of our microbial opsins into a human retina, cadaveric, after life
  - He had ways of keeping the retina alive for some time in these donated retinas
  - And he was able to show that optogenetics worked perfectly well to control human retinal neurons
  - Then he spent the next 10 years going through all the hoops of primate studies and clinical trials
- He’s a vision scientist, and he focused on retinal degeneration and just this year he was able to take a human being who was blind from retinal degeneration and create light sensitivity so this person could accurately reach for objects on a table; that was not possible before
  - So literally making a blind person see, at least to some extent, can happen
- So I think there may be cases like that, and of course, they’re uplifting this to see

> “But the biggest picture is that it’s a discovery tool” – Karl Deisseroth

## Karl’s inspiration to write his book, *Projections* [1:48:00]

**His passion to write this book,** [***Projections: A Story of Human Emotions***](https://www.amazon.com/Projections-Story-Emotions-Karl-Deisseroth/dp/1984853694)

- Peter has read Karl’s book twice and is in awe of his writing
  - It’s a huge challenge to make topics like this accessible to everyone and make it interesting enough that someone not in the field would want to read
  - The accessibility and artistic style of this book seems effortless
  - Peter knows how difficult this is because he’s finishing up his own book
- Karl notes, “*You never really know when you take a step like this or a risk like this if it’s really working. This was a risk. This was something that was very different. It’s not what people expected, as you say, not a typical scientific text at all, really.*”
- His goal in writing the book was to help everybody, whatever their background
  - He wanted to help people understand and feel what these altered states of mental illness are
  - A big part of the book is working with those feelings
  - He wanted to help people understand and feel for themselves what mania might be like
  - Or what the fragmentation of schizophrenia might be like
  - Or the crushing pathological grief of bereavement
  - Or the incredibly complex states of eating disorders
    - Where there are these astonishing behavioral patterns that seem so inexplicable compared to what one would think would be what people were evolved to do

> “I wanted people to feel this; and so I had to do this with the writing, with the words” – Karl Deisseroth

- In each chapter, the writing is adapted to cause that feeling
  - In the mania story, the words are exuberant in the way that mania is
  - In the schizophrenia or a psychosis story, there’s a fragmentation and a disorganization that happens
  - And so in all of these cases, he worked with words in ways that are not typical for a scientist
    - This is something he wanted to do
    - This was his initial passion in life
    - It was incredibly fulfilling actually to come back and be able to do this
- He was on a mission, he had something he wanted to tell and share with everybody
  - For him it was incredibly addictive
- He did the bulk of the writing over a couple years from 2017 to 2019 or so, and then wrapped it up in 2020
- He would block out a couple hours a different time each day, depending on his schedule
  - He looked forward to his writing time so much
  - His life is complex now; he has a total of 5 kids
    - His wife Michelle is an incredibly accomplished MD, PhD, also running clinical trials
      - She was also one of Peter and Karl’s classmates
      - She is in the hospital a lot
  - So the writing would be at different times, often very late at night or early in the morning
  - He tried to block out 2 hours
  - He found he would look forward to this like almost nothing else
  - He found it incredibly uplifting even though it was a big challenge logistically

> “I just relished the joy of finding the right word and spending days thinking about it, trying to find the right turn of phrase” – Karl Deisseroth

## Mania and bipolar disorder: evolutionary basis, symptoms, and the high prevalence in North America [1:52:45]

- Peter loves how the book tries to dive into the evolutionary basis for mental illness
  - This is something he has been obsessed with
  - He loves trying to think about things through an evolutionary lens; and sometimes, the answers come a little easier than other times
  - One of the places where it comes up is in the story of Alexander
    - He won’t give away the entire story, but post 9/11 this gentleman is triggered into what sounds like his first manic event
    - Peter found the discussion about the evolutionary basis for mania fascinating
    - This was personally very interesting because when he was in residency his wife actually encouraged him to see a psychiatrist
    - The psychiatrist, after 1 day, decided he was [hypomanic](https://en.wikipedia.org/wiki/Hypomania)
    - This prompted Peter to begin examining everything he’d ever done in life
    - One of the things he came across at the time (2004, 2005) was a book by a psychiatrist at Hopkins
    - It suggested that the prevalence of hypomania in North America was higher than anywhere else in the world because it had the highest concentration of recent immigrants
    - The argument was, with a collection of people (immigrants) who are 1 to 5 generations away from people who left a comfortable life elsewhere to come to nothing
      - These people don’t know the language
      - They don’t know the culture
      - They don’t know the people
    - It’s not surprising that this could concentrate hypomania here in North America
    - From an evolutionary view, sometimes traits are very valuable at the population level and not at the individual level
      - Peter finds this fascinating
- Karl notes that recent immigrants who get up and leave home to take this risk, they have the energy and motivation to make this happen, to sustain this complex goal with so many possible downsides
  - This is not small thing
  - Some people wouldn’t want to do this
  - There is a possible genetic link to this behavior

**Bipolar disorder [1:55:45]**

- Mania is one of the poles of bipolar disorder
- Bipolar disorder is a highly genetic disorder and one of the most common in psychiatry
  - [Bipolar type I](https://en.wikipedia.org/wiki/Bipolar_I_disorder) disorder is extraordinarily genetically determined
- Peter wants clarification, does that mean that bipolar stems from bipolar or it just clusters with other psychiatric illness?
  - In other words, would schizophrenia or significant depression also be a genetic precursor to it?
- Karl notes that in monozygotic twins (especially those that are raised apart, this is where the most pure information comes from) [concordance](https://en.wikipedia.org/wiki/Concordance_(genetics)) of mania or bipolar disorder appearing in each twin is high
  - For bipolar type I the concordance is almost above 70%; this shows a strong genetic determination
- The concordance for autism in monozygotic twins is also high, but lower
- For depression, it’s around 50%
- Most psychiatric disorders have strong genetic links
  - They tend to have concordance values less than 80% but in the 50-80% range
    - This includes depression, schizophrenia, autism, and bipolar disorder
- Mania is the positive pole of bipolar disorder; the other pole is depression
- People with bipolar type I have had at least 1 manic episode where they have a period of time (could be a week) where they’ve had this very clear, discreet state of elevated mood, increased goal-directed activity, projects, plans, spending, taking risks, faster speech, not needing sleep
  - They truly do not need to sleep, not nearly as much
  - This causes problems, serious problems
  - Mania can do terrible things; people make very poor decisions; this can be fatal
  - The transition from out of depression to mania is probably the most risky time
    - They have some negativity from the depression and the energy to act on it
- Karl notes, “*some of my most memorable experiences in talking with manic patients… I actually love talking to them because there’s such a charge of energy. Anything’s possible. They’re funny. They’re warm. They’re charismatic.*”
  - It’s easy to see that this is a state is not a bunch of random things happening in the brain
  - This is a coherent state of elevated mood; it’s consistent
  - He has seen it in many patients
  - Human beings have as something they can do, a sustained state of elevated mood and energy
    - He looks at this and thinks, why?
    - What does that mean for treatment?
    - Is there an ethical issue with treatment?
    - Are there cases where mania is positive?

*Back to the story about Alexander from the book…*

- This is something that writing the story about Alexander in his book really made him think hard about
- This story about Alexander occurred 20 years ago, right after 9/11
  - This experience planted the seed for this book
- This patient, Alexander never had any psychiatric illness; nor was any in his family
- But he was flipped into a completely classic, full-blown mania after 9/11
- He had no particular connection to the 9/11 tragedy
  - In fact, he was on a sailing trip in the Mediterranean with his wife at the time
- He came back home after 9/11 and a couple weeks later, he was manic
  - All these symptoms that just discussed; and it was a huge problem
  - But he had this appropriate or at least aligned quality to his symptoms; he was retirement age
  - He was training himself to go into battle
    - He was rappelling down trees
    - He was running through the night
    - He was reading about military strategy
    - Then he verged into this very difficult, emotionally, challenging person
    - He was screaming
    - He was hyper religious
    - Everything had become quite extreme and incompatible with his life; and so that ended up bringing him to the hospital
- This state of elevated mood and energy was triggered by context, and this is actually the flip side of what is seen with immigrants
- In immigrants, there likely to be a set of conditions that led to these people being able to have the energy and willingness to take the risk and meet all the incredible challenges of moving across countries and cultures
  - But this is not a fight or flight response of the minute when one has a threat, and one gets a boost of energy, and then one meets the threat, and then it’s gone
  - Instead, immigrants need a sustained level of energy for weeks, months, years even, to take a risk and a life shift like that
- And so everything is on a spectrum
  - There is mania, and then there is this hypomanic state in between that makes a lot of sense for people who are able to sustain this elevated energy state, these would be our immigrants
- He looks at this and thinks, it’s a spectrum
  - Definitely it can be bad
  - But one has to value the whole spectrum and understand the whole spectrum
  - It’s part of who we are as the human family
- Peter asks, “*Why do you think that in the bipolar condition, you have this pairing of such opposites? Is the depression a necessary part of bipolar to basically allow the recharging after this unbelievable discharge of emotional and physical energy?*”
  - Why doesn’t the disorder cycle between normal affect, mania, normal affect, mania?
- This is a great question, but there is not an answer
  - Some fortunate people do cycle between normal affect and mania
  - It is possible to get a diagnosis of bipolar disorder without ever having a depression
    - 1 episode of mania is enough to diagnose bipolar type I
    - There are people who haven’t hit a major depression yet
  - However, most of the time people are at that other pole of the disorder
- It’s not known why people with bipolar disorder cycle between these 2 poles; there are a lot of interesting ideas
  - Maybe there’s some resource that’s exhausted; it’s not known what this is
  - Is it a neural circuit that can become exhausted?
    - We know neurons can run out of energy
    - This is part of how the brain stimulation to cause inhibition works, but that works on a very fast time scale
    - Neurons can be exhausted for seconds to minutes
    - It’s not known what create exhaustion on the week’s scale
  - Maybe it’s the termination mechanism that it just overshoots
  - Or maybe what’s lost is the homeostatic thing that keeps energy in a tight range, and then it could go in either direction because of the loss of some break that’s present on either side

## Depression: evolutionary basis and insights from optogenetics [2:03:15]

**Anxiety**

- Anxiety is the most common psychiatric disorder; depression is certainly up there
- Anxiety disorders are so underappreciated
  - A lot of people don’t talk about them
  - A lot of people can make it through the day with anxiety, even if they’re suffering terribly

**What has optogenetics revealed about depression?**

- Depression is Karl’s clinical speciality
- He does [vagus nerve stimulation (vns therapy)](https://en.wikipedia.org/wiki/Vagus_nerve_stimulation)
- Electroconvulsive therapy is still used
- He also uses [transcranial magnetic stimulation](https://en.wikipedia.org/wiki/Transcranial_magnetic_stimulation)
- Clinically though, everyone is looking for guidance from science, because it’s still not known clinically what actually is going wrong in depression
  - Depression is not understood in a way that can guide therapies
- Optogenetics has helped quite a bit because there are different parts to depression, and this is how it is diagnosed
  - There is depressed mood
  - There is this negative state
  - There is hopelessness; this is kind of the opposite of mania
    - A manic person thinks anything is possible
    - A depressed person thinks nothing is possible
    - There is a deep discounting of the value of effort; this shows up as hopelessness
    - This can lead to suicidality and certainly severe social and occupational dysfunction
  - And then there are other parts to depression; there’s something called [anhedonia](https://en.wikipedia.org/wiki/Anhedonia)
    - This is not commonly known
    - People don’t talk about anhedonia; it’s an incredibly important symptom
    - It’s such a core symptom of depression that actually one can get a diagnosis of major depressive disorder without depressed mood if they have anhedonia
    - Anhedonia is the **absence of pleasure or joy from things that normally bring pleasure or joy**
    - For example, everyone has had a cold and know what it’s like for taste to be gone; food has lost all joy
    - With the anhedonia of depression, all the joy of food or social interaction or one’s children, one’s grandchildren, a book, a movie, all the joy of life is gone
    - This is a horrific thing

> “It leads to very serious problems and that’s something that optogenetics has helped us understand” – Karl Deisseroth

**Anhedonia**

- Simple behaviors can be studied in mice to determine what neurons and what neurotransmitters are involved in the propagation of anhedonia
- Provide a simple choice for the mice: drink sugar water or drink plain water
  - Mice, like us, enjoy a sugary drink
  - Normally, a mouse will prefer to drink the sugary drink by a factor of 2:1, or more
    - But when a mouse has been stressed — something unpredictable has happened or it’s sleep has been disrupted; now, it will not prefer the sugar water nearly as much, it won’t care as much
      - This is interesting given all the evolutionary importance of a high metabolic rate mammal needing sugar, and the reward felt from sugar, and then not caring if the drink is sugar water or plain water
- Karl and others have explored this kind of thing with optogenetics
  - He found that there are pathways of dopamine neurons which are tightly linked to mood and mania and depression
    - But dopamine neurons are a complex set of cells
    - Some send connections to one part of the brain, some send connections to another part of the brain
  - He have found some interesting pathways that relate to those dopamine neurons, where one can actually affect how potent a normal rewarding stimulus is by something going on in the frontal cortex
    - In the frontal part of the brain, an over activity in the [prefrontal cortical areas](https://en.wikipedia.org/wiki/Prefrontal_cortex) can cause anhedonia in rodents
    - An overactivity seems to cause an inability of the dopamine neurons to recruit reward circuitry
  - This is an insight that optogenetics brought us, and it’s something that he’s following up mechanistically
- Using optogenetics at the frontal cortex can suppress both positive and negative things
  - It can suppress fear
  - It can suppress anxiety
  - This is part of how one exerts cognitive control over situations
  - One can enter a scenario that they know is risky
    - If one thinks about it enough
    - If one frames it enough cognitively
    - If one reviews the need for it, for taking this action
  - And so the frontal cortex can help one by tamping down negative aspects
  - But when overactive, it turns out can tamp down positive aspects as well
  - Optogenetics has given a causal insight into this
- All the other features of depression are susceptible to optogenetics study
  - His lab has gotten insight into them

**Hopelessness**

- Hopelessness is another aspect of depression that can be studied using optogenetics
- One might ask, how is hope measured in an animal?
- This begins by putting an animal in a challenging situation that is not escapable
  - Such as a maze that doesn’t have an exit
  - It doesn’t have to be painful, just something the animal would want to get out of
  - The animal can try to get out of this challenging situation and then eventually it gives up; it’s hopeless
  - This can be done in fish and mice
- It’s this hopelessness; this discounting of effort
- This can be an appropriate thing if the situation truly is hopeless
  - Then it really is not good to keep devoting effort to it
  - If one keeps flailing against an insuperable situation, they’re burning energy, they could cause physical risk, they’re distracted from other things
- Withdrawing, entering into a passive coping state is actually adaptive up to a point
  - The problem with depression is it becomes extreme; it becomes maladaptive
  - The value of everything has been discounted
  - And then it’s got this mysterious negative balance to it too, which is of course also part of the problem

**What is the evolutionary basis for depression?**

- Withdrawal, this passivity, may provide some insight
  - Think of it like a hibernation
  - Is it worthwhile for an animal to actively try to cope with winter by running around, trying to find more food all through the winter, or to withdraw, to sleep more, to not see the value or feel the value in going outside and doing anything?
    - And clearly, no matter what one does, one can’t fight winter, right?
    - The best thing is to conserve one’s energy; ride it out on some time scale that’s appropriate
- Now, think about depression
  - It comes with this low energy
  - It comes with this hopelessness, this discounting of effort, this lack of motivation to go seek things to be enjoyed, reduced drive for social interaction
  - A negative aspect is the one part that he can’t explain
    - That’s of course the clinically significant problem
    - Why does it feel bad?
    - And this is not just feeling bad; this is agony, this is psychic pain, this is the kind of thing that drives people to seek suicide
    - It is not understood why depression feels bad
  - But the passivity of coping, that can be adaptive
  - Perhaps one could see depression as a bad hack, maybe one that’s not fully evolved yet
    - Just like mania is not fully evolved yet
    - Mania is not under all the right controls to make it more generally suitable and reasonable
- The easiest way to make depression happen is to remove the joy, remove the energy to seek out reward
  - This results in an organism that is going to be passive; it doesn’t see a path to something positive
- To speculate on the evolutionary basis of depression, maybe one way of getting to a goal included having this negative state to it
  - At a population level, maybe depression had some adaptive value
  - Remember depression is very genetically determined
  - It’s common, it’s biological, and at some level, one has to deal with the fact that “*we have evolved to be where we are now, and we have this high rate of depression;. and so we have to include in our thinking, the biology and the evolution together.*”
  - This is not a definitive understanding

**Depression in our closest relatives, primates**

- One of the clearest examples that can be observed in nonhuman primates is when they enter a maladaptive state that looks like grief in bereaved states
  - There are cases when a nonhuman primate who is old enough to feed itself, but who has let’s say has lost its mother and loses the motivation to feed and protect itself and stay with the troop, and ends up dying as a result
    - This is a clearly maladaptive state documented in a nonhuman primate
    - One could call it something like a depressed-like state deriving from bereavement and presumed to anthropomorphize, something like grief associated with bereavement
  - So yes, Karl believes these states are shared by our nonhuman primates

**Suicide**

- Peter asks about self-harm; suicide is a top 10 cause of mortality in the developed world
  - If one includes overdose as a subset of self-harm then it probably jumps to the top 7
- There is no evidence that suicide occurs nonhuman primates
- And there are less suicidal forms of self-harm that can happen
  - Now and then animals are seen carrying out behaviors like head banging and things like that
- This is very hard to study
- When he thinks about it, the ending of the self is an extremely cognitively complex thing
  - The act of suicide is a horrific thing
  - It is not understood what it means, that there is an ending of life, an ending of the self and that the pain that’s being felt now would not be felt then
    - It doesn’t seem that animals have this level of understanding of the universe
    - Dolphins and whales and elephants have incredibly complex and amazing minds;  they may be better than we are at some of these deep concepts, but they may have less clear ways to express it
    - They may be not having fingers and hands to do things that we can do; they may not have the ways to express it, even though their cognitions may be just as complex
  - One thing that sets humans apart from other amazing animals is our brains and our hands
    - Those two don’t come together in any other animal
    - He thinks that’s why you don’t see suicide elsewhere

## The effects of trauma early in life [2:18:45]

- Peter notes that their friend from medical school ([Paul Conti](https://www.drpaulconti.com/)), who trained with Karl in psychiatry had just written a wonderful [book on trauma](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351/ref=sr_1_1?qid=1637175819&qsid=146-5475333-0110134&refinements=p_27%3APaul+Conti+MD&s=books&sr=1-1&sres=1683647351&text=Paul+Conti+MD)
  - This begs the question, what role does trauma play in the amplification of depression
  - Depression is highly heritable, but like most conditions that are heritable, there tends to be an environmental trigger that can bring one person to have it and one not to
    - Even with the most extreme example of monozygotic twins raised in a separate environment, and one comes down with something… there is clearly some difference
  - What is the role of early childhood trauma in depression
    - Could this be [epigenetic](https://en.wikipedia.org/wiki/Epigenetics)?  Could this then be transferred to subsequent generations
- The lasting effects of early life trauma are unfortunately very clear
  - These can be seen in animals as well
  - It extends beyond depression, for sure, to include the personality disorders like [borderline personality](https://en.wikipedia.org/wiki/Borderline_personality_disorder), for example
  - So there’s no question that early life trauma has lasting psychiatric influence throughout life and can cause very severe problems
- There are many ways to look at this:
  - Why is it happening?
  - How is it happening?
  - Is there a wiring change?
  - Is the lasting quality due to a physical structure of the brain as a circuit?
    - That’s one level at which it could happen
    - Brain circuitry is very tuneable that way, especially in young people
- One could imagine that early life experience with trauma sets up the human to expect, in some ways, that the world is a harsh and unpredictable place, and that the value system had better be set up to deal with that, because that’s how it is
- One could almost imagine an adaptive, though very unfortunate process going on, where there’s a period of youth when one is gathering statistics about the environment, deciding what the adult should be like, and then implementing that
  - And so early life trauma could intersect with such a process very unfortunately, and create people with a lasting state of depression
  - For example, expecting aversive things to be present at higher rates and negative consequences of actions to be present at a high rate
    - Now that could be the case as far as an evolutionary logic, but there’s no doubt that this happens in terms of the behavioral effect and the psychiatric effect, the lasting effects of early life trauma
- Now, if it’s not neurocircuitry, what else could it be?
  - It could be genetic or [epigenetic](https://en.wikipedia.org/wiki/Epigenetics)
  - The genome does not change from childhood to adulthood; what changes are the activity of the transcription factors, the promoters, and the enhancers
  - Trauma could be affecting gene expression throughout life
    - At least through the life of that individual
    - It is understood mechanistically how that could work
- Finally the question of an intergenerational aspect in human beings
  - This is very hard to separate the nature and from the nurture
  - Of course, there is parenting that’s linked to what might have happened in the prior generation
  - He would say it’s still controversial how much intergenerational epigenetic transfer can happen; although in animals, there are mechanisms

**Emotional tears**

- Peter found Karls exploration of the evolutionary basis for tears completely fascinating
  - He never once considered that; and that in itself from someone who is often thinking about the evolutionary basis for this feature or that feature, this is interesting
- Emotional tears, the liquid coming from tear ducts in times of emotion
- As far as one can tell, it’s a human trait
  - The great apes don’t do this and even some human beings don’t do it
  - So it’s a special thing
- It’s not that humans are the only ones that grieve, but we’re the ones that secrete this fluid from our eyes at these extreme moments
- This has been studied; there are scholars of tears
  - They can do things like add or subtract tears digitally from pictures of faces; and these have enormous impacts
    - The reactions of people seeing an image of a person crying is much, much greater than seeing a smile or a grimness
    - In particular, it creates a desire to help
- When people see tears, it creates a desire to help that person
  - He thinks this intersects very closely with the evolutionary nature of tears
- Tears are a truth channel
  - It’s not easily gameable
  - It reveals something in a social grouping, like those that we’ve evolved to maintain
  - It is an involuntary expression of something— the world changing, of needing new systems in place
  - It triggers this outreach from people who see it, in a very powerful way
- This question— can an emotional change cause something like tears to happen?
  - It would be a very easy rewiring to happen
  - There are already axons that come from emotional regions and go to the brainstem that control the breathing rate, for example in anxiety
  - And right next to those breathing rate regions, there are regions that control the tear ducts
    - They’re right next to each other in the brainstem
    - In a very tiny, tiny rewiring little axon, just going in one slight different direction would create this state of expression,  this visible manifestation of an inner world
    - And for social species like ours, it could be easily evolutionarily selected for
- So in the story, *Storehouse of Tears* in [*Projections*](https://www.amazon.com/Projections-Story-Emotions-Karl-Deisseroth/dp/1984853694/ref=sr_1_1?crid=2PM6K01FV77H5&keywords=projections+karl+deisseroth&qid=1636936339&qsid=146-5475333-0110134&sprefix=karl+des%2Caps%2C186&sr=8-1&sres=1984853694%2C024138186X%2C1250223180%2C1328949966%2CB091KCYTHG%2CB08PVZNYQT%2CB08SGWNLV9%2C1260117103%2C1496447794%2CB08P7JTGQ1%2CB0982LBC7P&srpt=ABIS_BOOK), this is something that a patient’s story helped bring to the forefront of Karl’s mind, and he discussed quite a bit
  - Peter comments, “*I won’t give any more away from that story because I want people to read it for themselves*”
- Peter also notes that this discussion could go on for another couple of hours, but they have reached their limit of time
- Stay tuned for another episode with Karl Deisseroth sometime next year

⇒ **Karl recently received the** [**Lasker Award**](https://en.wikipedia.org/wiki/Lasker_Award): [Karl Deisseroth shares Lasker Award for research on microbial molecules behind optogenetics](https://med.stanford.edu/news/all-news/2021/09/karl-deisseroth-lasker-award.html)

§

## Selected Links / Related Material

**Karl’s book on emotions**: [Projections: A Story of Human Emotions](https://www.amazon.com/Projections-Story-Emotions-Karl-Deisseroth/dp/1984853694/ref=sr_1_1?crid=2PM6K01FV77H5&keywords=projections+karl+deisseroth&qid=1636936339&qsid=146-5475333-0110134&sprefix=karl+des%2Caps%2C186&sr=8-1&sres=1984853694%2C024138186X%2C1250223180%2C1328949966%2CB091KCYTHG%2CB08PVZNYQT%2CB08SGWNLV9%2C1260117103%2C1496447794%2CB08P7JTGQ1%2CB0982LBC7P&srpt=ABIS_BOOK) by Karl Deisseroth (2021) | [4:15]

**First publication of inserting a microbial opsin into neurons**:  [Millisecond-timescale, genetically targeted optical control of neural activity](https://pubmed.ncbi.nlm.nih.gov/16116447/) | *Nature Neuroscience* (E S Boyden *et al.* 2005) | [59:45]

**Treatment of a form of blindness with optogenetics**: [Partial recovery of visual function in a blind patient after optogenetic therapy](https://www.nature.com/articles/s41591-021-01351-4) | *Nature Genetics* (J A Sahel *et al*. 2021) | [1:46:45]

**Paul Conti’s book on trauma**: [Trauma: The Invisible Epidemic: How Trauma Works and How We Can Heal From It](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351/ref=sr_1_1?qid=1637175819&qsid=146-5475333-0110134&refinements=p_27%3APaul+Conti+MD&s=books&sr=1-1&sres=1683647351&text=Paul+Conti+MD) by Paul Conti and Lady Gaga (2021) | [2:18:45]

**Karl recently received the Lasker Award**: [Karl Deisseroth shares Lasker Award for research on microbial molecules behind optogenetics](https://med.stanford.edu/news/all-news/2021/09/karl-deisseroth-lasker-award.html) | Bruce Goldman (med.stanford.edu) [2:25:45]

**Profile of Karl in** ***The New Yorker***: [Lighting the Brain: Karl Deisseroth and the optogenetics breakthrough](https://www.newyorker.com/magazine/2015/05/18/lighting-the-brain) | John Colapinto, *The New Yorker* (May 11, 2015)

**Karl’s review of optogenetics and its utility in understanding the neural basis of psychiatric disorders**: [Illuminating circuitry relevant to psychiatric disorders with optogenetics](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4293223/) | *Current Opinion in Neurobiology* (E Steinberg *et al.* 2015)

**Addgene guide to microbial opsins and optogenetics**: [Optogenetics guide](https://www.addgene.org/guides/optogenetics/) | [addgene.org](https://www.addgene.org/)

**Optogenetic investigation of neurons involved in fear-related freezing behavior during high anxiety states in mice**: [Basomedial amygdala mediates top–down control of anxiety and fear](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4780260/) | *Nature* (A Adhikari *et al.* 2015)

**Optogenetic investigation of neurons involved in passive behavior in zebrafish**: [Neuronal dynamics regulating brain and behavioral state transitions](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6726130/) | *Cell* (A Andalman *et al.* 2019)

**Optogenetic investigation of social behavior in a mouse model of autism**: [Modulation of prefrontal cortex excitation/inhibition balance rescues social behavior in CNTNAP2-deficient mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5723386/) | *Science Translational Medicine* (Aslihan Selimbeyoglu *et al.* 2017)

**Karl’s Stanford University website**: [Deisseroth Lab](https://web.stanford.edu/group/dlab/) | [stanford.edu](https://www.stanford.edu/)

- [Optogenetics resources](https://web.stanford.edu/group/dlab/optogenetics/)

§

## People Mentioned

- [Paul Conti](https://www.drpaulconti.com/) (in Peter’s and Karl’s med school class, became a psychiatrist) [18:00; 2:18:45]
- [Rob Malenka](https://med.stanford.edu/profiles/robert-malenka) (psychiatrists and neuroscience at Stanford who Karl did his residency with) [30:30; 55:00]
- [Dieter Oesterhelt](https://en.wikipedia.org/wiki/Dieter_Oesterhelt) (discovered and characterized bacteriorhodopsin with W Stoeckenius) [52:40]
- [Walther Stoeckenius](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3149375/) (discovered and characterized bacteriorhodopsin with D Oesterhelt) [52:40]
- [Lubert Stryer](https://en.wikipedia.org/wiki/Lubert_Stryer) (biochemist and author of biochemistry textbook) [52:45]
- [Richard (Dick) Tsien](https://en.wikipedia.org/wiki/Richard_W._Tsien) (Karl’s PhD advisor) [1:00:30]
- [Roger Tsien](https://en.wikipedia.org/wiki/Roger_Y._Tsien) (awarded the Nobel prize for his work on green fluorescent protein) [1:00:30]
- [Francis Crick](https://en.wikipedia.org/wiki/Francis_Crick) (awarded the Nobel prize for his work on the structure of DNA) [1:01:00]
- [Catherine Dulac](https://en.wikipedia.org/wiki/Catherine_Dulac) (used optogenetics to study parenting) [1:36:30]
- [Botond Roska](https://en.wikipedia.org/wiki/Botond_Roska) (used optogenetics to cure a form of blindness) [1:46:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/01/bio-image-karld.jpeg)

##### Karl Deisseroth M.D., Ph.D.

Karl Deisseroth is the D.H. Chen Professor of Bioengineering and of Psychiatry and Behavioral Sciences at Stanford University, and Investigator of the Howard Hughes Medical Institute. He received his undergraduate degree from Harvard, his PhD from Stanford, and his MD from Stanford. He also completed postdoctoral training, medical internship, and adult psychiatry residency at Stanford, and he is board-certified by the American Board of Psychiatry and Neurology. He continues as a practicing psychiatrist at Stanford with specialization in affective disorders and autism-spectrum disease, employing medications along with neural stimulation.

Over the last sixteen years, his laboratory created and developed optogenetics, hydrogel-tissue chemistry (beginning with CLARITY), and a broad range of enabling methods. He also has employed his technologies to discover the neural cell types and connections that cause adaptive and maladaptive behaviors, and has disseminated the technologies to thousands of laboratories around the world.

He is also an inpatient/outpatient attending physician in the Department of Psychiatry and Behavioral Sciences at Stanford.  His clinical work focuses on treatment-resistant depression and autism-spectrum disease using medications and high-speed neural stimulation.

Among other honors, Deisseroth was the sole recipient for optogenetics of the 2010 Koetser Prize, the 2010 Nakasone Prize, the 2011 Alden Spencer Prize, the 2013 Richard Lounsbery Prize, the 2014 Dickson Prize in Science, the 2015 Keio Prize, the 2015 Lurie Prize, the 2015 Albany Prize, the 2015 Dickson Prize in Medicine, the 2017 Redelsheimer Prize, the 2017 Fresenius Prize, the 2017 NOMIS Distinguished Scientist Award, the 2018 Eisenberg Prize, the 2018 Kyoto Prize, and the 2020 Heineken Prize in Medicine from the Royal Netherlands Academy of Arts and Sciences. For his discoveries, Deisseroth has also received the Perl Prize (2012), the BRAIN prize (2013), the Pasarow Prize (2013), the Breakthrough Prize (2015) the BBVA Award (2016), the Massry Prize (2016) and the Harvey Prize from the Technion/Israel (2017). He was selected a Howard Hughes Medical Institute Investigator in 2013, and was elected to the US National Academy of Medicine in 2010, to the US National Academy of Sciences in 2012, and to the US National Academy of Engineering in 2019. [[Stanford Profiles](https://profiles.stanford.edu/karl-deisseroth)]