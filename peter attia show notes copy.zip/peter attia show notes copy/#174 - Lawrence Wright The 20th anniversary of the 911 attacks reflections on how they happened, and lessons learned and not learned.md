# #174 – Lawrence Wright: The 20th anniversary of the 9/11 attacks: reflections on how they happened, and lessons learned and not learned

**Source:** [https://peterattiamd.com/lawrencewright/](https://peterattiamd.com/lawrencewright/)

---

Lawrence Wright is the author of [The Looming Tower: Al-Qaeda and the Road to 9/11](https://www.amazon.com/Looming-Tower-Al-Qaeda-Road-11/dp/1400030846) which won the 2007 Pulitzer Prize for general nonfiction and was named one of Time’s top 100 books of all time.  In this episode, released just before the 20th anniversary of the September 11th attacks, Lawrence and Peter discuss the book and the lasting impact of that day. Lawrence reflects on his personal experiences on that day and how he was first drawn into reporting on the attacks. Lawrence then discusses in detail the history that led up to 9/11 which is really composed of two parallel stories. The first story is of the growing discontent in Muslim countries, the roots of Islamic radicalism, and how two extremists, Osama bin Laden and Ayman al-Zawahiri, joined forces to create the global terrorist organization Al-Qaeda. The second story is about how interpersonal and institutional conflicts between the FBI and CIA led to a massive failure in intelligence and resulted in multiple missed opportunities to predict and prevent the attacks on September 11th, 2001. Finally, they reflect on what we should have learned from 9/11 and the future of terrorism.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/ajB-qvbgyG4)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/lawrencewright/the_Drive_public.png)

Play

#174 - Lawrence Wright: The 20th anniversary of the 9/11 attacks: reflections on how they happened, and lessons learned and not learned

#174 - Lawrence Wright: The 20th anniversary of the 9/11 attacks: reflections on how they happened, and lessons learned and not learned

1x15s30s

0:003:01:55

## We discuss:

- Lawrence and Peter recount their personal experiences on September 11th, 2001 [3:30];
- How 9/11 changed the US into a security state and affected a generation [9:45];
- Lawrence’s early coverage of 9/11 and how he knew it was going to be “the story of our lifetime” [14:45];
- Egyptian politics and the foundation of radical Islam [22:45];
- Anwar Sadat’s presidency, assassination, and the birth of the radical Islamic movement [33:00];
- Aftermath of the Sadat assassination, and establishment of Al-Qaeda in Afghanistan [50:15];
- Osama bin Laden: upbringing, involvement in the Soviet–Afghan War, and rise to celebrity status in Saudi Arabia [56:00];
- How the Western intervention in Saudi Arabia impacted Arab nationalist’s hatred of America [1:15:30];
- Theorizing on the role of the religion in holding back Islamic states from making progress towards democracy [1:20:30];
- Bin Laden’s time in Sudan [1:32:30];
- The CIA vs. the FBI: setting the stage for the failure of US intelligence [1:37:00];
- The mistake by US intelligence of not taking the bombings of the US embassies and the USS Cole seriously [1:46:00];
- Al-Qaeda in America: Losing the planners of the 9/11 attacks from our clutches and incompetence at the FBI and CIA [1:56:00];
- Incompetence at the CIA [2:04:45];
- Problematic policies and Europe, and a direct message warning of the 9/11 attacks [2:14:45];
- The role of political infighting and personality conflicts that helped enable the 9/11 attacks and the lack of accountability [2:22:45];
- What came of the 9/11 commission, the role of the Saudi government, and the trials of Ali Soufan [2:36:00];
- Lessons from 9/11 and the future of terrorism [2:46:30]; and
- More.

§

## Show Notes

## Lawrence and Peter recount their personal experiences on September 11th, 2001 [3:30]

It’s almost the 20th anniversary of September 11, 2001, “certainly the most pivotal moment for many of us in our lifetimes”

- Peter says it’s hard to believe how fast 20 years have gone by
- When Lawrence heard what happened, he knew it was probably a terrorist attack because he had written about terrorism before
  - But it was still surprising how dramatic a strike it was
  - Lawrence had written a movie called [*The Siege*](https://en.wikipedia.org/wiki/The_Siege) (which starred [Denzel Washington](https://en.wikipedia.org/wiki/Denzel_Washington), [Bruce Willis](https://en.wikipedia.org/wiki/Bruce_Willis), and [Annette Bening](https://en.wikipedia.org/wiki/Annette_Bening)) about a terrorist attack on US soil in NYC
- In 1998, a few months before the movie opened, Al-Qaeda had attacked American embassies in East Africa and killed 224 people
  - but it got little media attention because it happened far away
  - Americans still had a sense of invulnerability and didn’t pay much attention
- That same month, there was a bombing at a Planet Hollywood restaurant in Cape Town, South Africa that killed two British tourists and cost a little girl her leg
  - An Islamic group took credit and said the attack was a protest against the trailers for *The Siege*
  - “The movie hadn’t even come out yet and people are already dead. And that was a scarring experience for me. …  And so terrorism touched me right off”
  - He knew Muslims were angry about being portrayed as terrorists
  - People picketed the movie and it did not do well, but it was the most rented movie in the US after 9/11
- Peter wonders what the collective impact is for the average person
  - On that day he was a surgical resident at Hopkins taking care of a kid who had been hit by a car (who turned out to be ok)
  - When Peter heard a plane had hit, he assumed it was a small Cessna that went off course due to fog, but after the second plane hit everyone was watching it on the TVs in the ER
  - “And then for the next 48 hours, none of us left the hospital because we were waiting. Would there be survivors coming? Obviously, there were none”
  - Peter didn’t know anyone who died that day, or any first responders who were traumatized, but for 10 years he had nightmares about being in the cockpit of [United flight 93](https://en.wikipedia.org/wiki/United_Airlines_Flight_93), the plane that crashed in Pennsylvania

## How 9/11 changed the US into a security state and affected a generation [9:45]

- Lawrence says it’s partly generational – he and Peter are old enough for it to have deeply affected them personally

> “I think every American was profoundly affected in one way or another. For one thing, there was this sense of invulnerability. It was a smug feeling …Things that happen out there in the rest of the world don’t really touch us. … And that was so punctured. It was so disillusioning, that we’re a regular country and we’re vulnerable, and that was shattering. And I don’t think anybody who was cognizant at that age, I don’t think anybody walked away feeling the same.” —Lawrence Wright

- The culture changed around that event, and young people don’t know what it was like before
  - Lawrence remembers once taking a date to the airport in Dallas where they went on a grounded plane and ate a snack in the first class compartment and sat for a while in the FAA tower
  - That could never happen today; there was not a feeling of being threatened
  - People in their mid-20s or 30s can’t imagine that kind of freedom (“They don’t know that you could go visit the Liberty Bell in Philadelphia without having to take off your belt and your shoes”)
  - It’s now normal to live in a security state and feel antagonistic towards the rest of the world

> “It’s an aberration in our history. And I would like for us to try to remember the country we were and aim to steer towards that, because … if you lose a memory, of the country that we were, then I don’t think we can ever get back to port.” —Lawrence Wright

- Peter’s parents are immigrants from Egypt
  - His dad would often spend a flight in the cockpit and invite the crew over for a meal at their house in Toronto (he was a cook and owned a restaurant)
  - That sounds bizarre today
- It makes sense to protect ourselves, be on guard, and ramp up our defenses, but we have created a security state that has abridged our freedom
  - “We’re doing it to protect ourselves, but at the same time, we’re the ones that are holding the handcuffs”

## Lawrence’s early coverage of 9/11 and how he know it was going to be “the story of our lifetime” [14:45]

Lawrence published [*The Looming Tower*](https://en.wikipedia.org/wiki/The_Looming_Tower) in 2006

- He knew right away that “this was the story of our lifetime”
- He knew it has to have been an organization like the one depicted in *The Siege* (which we now know was Al-Qaeda)
- A cell tower had been destroyed and the phones were out
  - Peter remembers not being able to reach his girlfriend for a day and a half
- Lawrence emailed [David Remnick](https://en.wikipedia.org/wiki/David_Remnick), his editor at *The New Yorker*, and asked to work on the story
  - David asked Lawrence, [Jeff Toobin](https://en.wikipedia.org/wiki/Jeffrey_Toobin), [Jeff Goldberg](https://en.wikipedia.org/wiki/Jeffrey_Goldberg), and [Jane Mayer](https://en.wikipedia.org/wiki/Jane_Mayer) to find human stories that he could wave together into a narrative

![](https://peterattiamd.com/wp-content/uploads/2021/09/fig-1.-wright-743x1024.jpeg)

**Figure 1. The cover of the** ***New Yorker*****’s first issue after 9/11, published on September 24, 2001.** Image credit: [The New Yorker](https://www.newyorker.com/magazine/2001/09/24)

- Lawrence found a reporter named [Kirk Kjeldsen](https://www.goodreads.com/author/show/7112700.Kirk_Kjeldsen) who had an appointment at the [Windows on the World](https://en.wikipedia.org/wiki/Windows_on_the_World) restaurant on the top floor of the World Trade Center at 9 am for an investment magazine called [*Waters*](https://www.waterstechnology.com/static/waters)
  - He fell asleep on the subway and missed his stop
  - He ran late into the World Trade Center and had just got on an elevator when the first plane hit
  - The elevator doors accordioned, and he got out and saw objects lying everywhere
  - He went out onto a patio and there were hundreds of shoes and what he did not yet recognize as bodies on the ground
  - When something landed on the ground near him he went back inside
  - Kjeldsen’s story started Lawrence writing about 9/11

- “I knew from then that I was on the case and that whatever portion of my life was already spoken for”
  - In February, he signed a contract for a book that was supposed to be turned in a year later, but it took 5 years to write
- Peter says there are many of these stories
  - he knew someone who was supposed to be on one of the 4 flights but missed it because she overslept
  - It’s hard to process stories like that
  - And of course someone else probably got her seat
- Lawrence’s book is hard to get through because many of the details are “difficult to swallow”
- The book is really two stories:
  - The first is the history of Al-Qaeda
    - Not just [Osama bin Laden](https://en.wikipedia.org/wiki/Osama_bin_Laden) but a long history going back to Egypt
    - Resonated with Peter because growing up he went to Egypt every year
  - The second is the story about the intelligence
    - [Thomas Friedman](https://en.wikipedia.org/wiki/Thomas_Friedman) [wrote](https://www.amazon.com/Longitudes-Attitudes-Exploring-World-September/dp/0374190666), “The failure to prevent September 11 was not a failure of intelligence or coordination. It was a failure of imagination,” implying that we could not have anticipated such an attack
    - But Peter says Lawrence’s book makes clear it was in fact “a catastrophic failure of intelligence”

## Egyptian politics and the foundation of radical Islam [22:45]

**Sayyid Qutb**

- [Sayyid Qutb](https://en.wikipedia.org/wiki/Sayyid_Qutb) was an Egyptian educator and member of the Muslim Brothers, which was outlawed in Egypt
- Qutb got out of Egypt at a time when leaving was difficult
- He got a job teaching at a college in Greeley, Colorado in the 1940s
  - Greeley was a “scrubbed up Norman Rockwell type of town” but it horrified Qutb, who thought it personified American excesses and he felt shocked and threatened by the behavior of the women
  - He did go to NY, where he encountered many Jewish people, whom he hated despite having never met one before
- When he came back from Greeley, he wrote a very influential article about how dangerous America was (what Lawrence calls the “opening shot”) at a time when the US was held in high esteem in the developing world
- When [Gamal Nasser](https://en.wikipedia.org/wiki/Gamal_Abdel_Nasser) came into power after the officer’s revolt in 1952, he tried to enlist Sayyid Qutb in his governance
  - Qutb did work for the government for a while, but the Muslim Brothers’ goal was to have an Islamic dictatorship, not a military one
  - Nasser had hoped to co-opt the Muslim Brothers and tame the Islamic trend in the country
- Qutb was a well-known figure due to his commentaries on Islam and the [Quran](https://en.wikipedia.org/wiki/Quran) that were published all over the Arab world

**Egyptian politics**

- Egypt is almost entirely [Sunni Muslims](https://en.wikipedia.org/wiki/Sunni_Islam) (there is an insignificant [Shiite](https://en.wikipedia.org/wiki/Shia_Islam) minority) and Christians, who make up perhaps 10% of the population
- Piety is how one advances in a deeply religious society
- When Lawrence taught at an American university there in 1969-71, the country was transitioning
  - it was rare to see women with head coverings even at Cairo University
  - [Ayman al-Zawahiri](https://en.wikipedia.org/wiki/Ayman_al-Zawahiri), then a medical student at Cairo University, was part of an effort to get women to cover up and become more overtly religious
- Peter points put that Lawrence was there in the middle of the transition from Nasser to [Anwar Sadat](https://en.wikipedia.org/wiki/Anwar_Sadat)
- Peter’s mother left Egypt at age 22 on September 28th, 1970
  - When she got on the plane, Nassar was president
  - By the time she landed in Copenhagen, Nassar was dead
  - She was shocked because Nassar seemed indomitable to her generation
- Nasser was the first Egyptian to rule Egypt in about 2500 years (even [Cleopatra](https://en.wikipedia.org/wiki/Cleopatra) and the Greeks had overthrown a Turkish king)
  - He was “glamorous, very handsome, compelling figure, [and] extremely charismatic” figure, and Egypt essentially annexed Syria in the United Arab Republic as the Syrians wanted to be connected to “the most powerful figure in the Arab world”
  - He even survived after the “hideously mismanaged” [Six Day War](https://en.wikipedia.org/wiki/Six-Day_War) with Israel in 1967
  - He had a heart attack while moderating a peace conference with the Palestinians
  - Americans were advised not to go out, and the usually noisy streets were dead quiet
  - Lawrence lived on [Zamalek](https://en.wikipedia.org/wiki/Zamalek), on an island in the middle of the [Nile River](https://en.wikipedia.org/wiki/Nile), right across from the Russian news agency [RIA Novosti](https://en.wikipedia.org/wiki/RIA_Novosti)
- The US Central Intelligence Agency ([CIA](https://en.wikipedia.org/wiki/Central_Intelligence_Agency)) had given Nasser a $10 million bribe, which he used to build the revolutionary tower on the island
- His funeral parade started at the tower and then crossed the [Qasr El Nil Bridge](https://en.wikipedia.org/wiki/Qasr_El_Nil_Bridge)
  - A large crowd of people on the other side of the bridge rushed towards the funeral procession (cortege)
  - In front of the cortege, police with batons beat a path through people and the bridge trembled
  - Lawrence thought about how soldiers must break rank when they cross a bridge to avoid the [Tacoma Narrows](https://en.wikipedia.org/wiki/Tacoma_Narrows_Bridge_(1940)) effect and was worried the bridge would collapse
- He thought that the country would never be the same

## Anwar Sadat’s presidency, assassination, and the birth of the radical Islamic movement [33:00]

- Egypt has always been ruled by military forces and figures (with the brief exception of the [Muslim Brotherhood](https://en.wikipedia.org/wiki/Muslim_Brotherhood) president)
- Then Anwar Sadat became president in 1970 after Nasser
  - He was considered a joke, a fool who missed the revolution
  - but he was underestimated and turned out to be a significant figure
  - Egypt and Israel are at peace because of Sadat
  - Up until that point, Egypt had been a kind of Soviet military base, but Sadat expelled them
- Qutb told Nasser he would rather die than renounce his stance and called his bluff
  - Four years before Nasser’s death, he had Qutb executed
  - Qutb’s execution became a symbol of the oppressiveness of the Arab regimes
  - The Muslim Brotherhood or some other form of Islamism seemed the only alternative
  - Qutb’s death inspired others
- Before he was executed, Qutb gave a man who was his lawyer, teacher, and good friend his Quran
  - That man’s nephew, Ayman al-Zawahiri, started a cell to overthrow the Egyptian government when he was 15
  - “That’ll show you the level of commitment that Al-Qaeda was born in”
- Peter asks why, when Sadat became president, he freed many people imprisoned by Nasser
  - Lawrence says because Sadat was very religious (he called himself “the first man of Islam”), he thought the would have standing with the Muslim Brotherhood
  - He did not understand the fanaticism that many prisoners developed
- Soldiers would come in and shoot prisoners in their cells, and Qutb wondered what kind of Muslim would do that to another Muslim
  - There’s an Arabic word, [*takfir*](https://en.wikipedia.org/wiki/Takfir), which means to expel someone for their disbelief
  - Qutb created the precedent for the idea that you’re not a real Muslim if you do not agree with him
  - “Once that door was opened, it led to the idea of terrorism. That’s where Zawahiri and Bin Laden got permission to become the terrorists that they became”
- There was a lot of tribal warfare in the region prior to Islam
  - Islam was partially the [prophet Muhammad](https://en.wikipedia.org/wiki/Muhammad)’s effort to stop the fighting by unifying Muslims (one of the meanings of Islam is submission)
  - Did not stop the infighting, particularly in Saudi Arabia
  - The [Ikhwan](https://en.wikipedia.org/wiki/Ikhwan) were fanatic tribesmen who fought for the first Saudi king but then had to be subdued with British war planes and weapons
- There was an idea among the [*takfiri*](https://en.wikipedia.org/wiki/Takfiri) (those who accuse other Muslims of apostasy) that first you attack the near enemy, then the far enemy
  - To Bin Laden, the US was the far enemy and [Hosni Mubarak](https://en.wikipedia.org/wiki/Hosni_Mubarak) and the Saudi royals were the near enemy
  - The enemies in order of proximity were the heretics, the Shia, the Jews, and the west
  - Bin Laden saw that there were American bases in Saudi Arabia and thus the US was not such a far enemy

**The contradictions of Anwar Sadat [40:15]**

Going back to the early 1970s, [Ayman al-Zawahiri](https://en.wikipedia.org/wiki/Ayman_al-Zawahiri) is in medical school, Sadat is “romanticized” in the West…*but how did the Egyptians view Sadat in the mid-to-late 1970s?*

- Sadat saved face in the west with the [Yom Kippur War](https://en.wikipedia.org/wiki/Yom_Kippur_War) in 1973, but creating peace with Israel was not popular in the Middle East
- Lawrence thinks Sadat goes not get enough credit for how daring he was
  - First, Israel did not see him as a threat, so he had to show he was willing to go to war
  - The Israelis had taken all of Sinai and built a sand fortress that extended the entire length of the [Suez Canal](https://en.wikipedia.org/wiki/Suez_Canal)
  - Sadat used German-made fire hoses to melt away the sand and managed to cross the Suez Canal in a few hours
  - It was like a mirror of the 1967 war
  - Egypt was defeated by [Ariel Sharon](https://en.wikipedia.org/wiki/Ariel_Sharon)’s army, but it had made a point
- It made Sadat a hero because Egyptians had felt humiliated after being quickly subdued in 1967
  - After that loss, Egyptians wondered why God had allowed them to be defeated and concluded it was because they were not religious enough
  - “*The 1967 war was a huge influence in driving people into radicalism*”
- But Sadat did not understand that the radicalism would eventually focus on him
  - Peter notes that at the end of his life, Sadat wanted to separate religion and politics
  - Sadat was not popular because he promoted peace with Israel and chided religious practices by saying things like covered women had tents on their heads
  - His wife had pushed for the right of women to get divorced
  - “They were really trying to bring modernity to Egypt and it was ultimately the nail in his coffin”
  - A [*fatwa*](https://en.wikipedia.org/wiki/Fatwa) was brought against him
  - He followed a similar path to the [Shah of Iran](https://en.wikipedia.org/wiki/Mohammad_Reza_Pahlavi)
    - 1979 was a tumultuous year in the Muslim world
    - The Shah was [overthrown](https://en.wikipedia.org/wiki/Iranian_Revolution) in Iran
    - The Soviets [invaded](https://en.wikipedia.org/wiki/Soviet%E2%80%93Afghan_War) Afghanistan
    - The [Camp David Accords](https://en.wikipedia.org/wiki/Camp_David_Accords) led to the [Egypt-Israel Peace Treaty](https://en.wikipedia.org/wiki/Egypt%E2%80%93Israel_peace_treaty)
    - There was [an attack in Mecca](https://en.wikipedia.org/wiki/Grand_Mosque_seizure), the holiest place in Islam, where radical Islamists took over and the French had to help the Saudis
    - We still don’t really know what happened or how many people died
    - A lot of innocent people were killed and then dozens were arrested and executed
    - But it was a trauma for Saudi Arabia and ended in a deal between the Royal family and the clerics
      - the royal family needed permission from the clerics to attack the mosque, which was considered “so holy that you’re not even supposed to mow the grass” – they couldn’t just go in to control the situation without clerical support
      - in return, the royal family agreed to allow religious figures greater standing and more social power
    - After that, Saudi Arabia became much more conservative and the clerics more fanatical
- Sadat was ultimately assassinated by an organization called [Al Jihad](https://en.wikipedia.org/wiki/Egyptian_Islamic_Jihad) (called Egyptian Islamic Jihad by American intelligence), one half of what would become [Al-Qaeda](https://en.wikipedia.org/wiki/Al-Qaeda)
  - Al-Zawahiri, who was still a practicing physician, played only a small role in the assassination
- Peter was only 8 years old when Sadat was killed, but he remembers the day clearly
  - Peter’s uncle was one of the generals standing with Sadat when he was shot
  - Everybody around Sadat realized what was going on and dropped to the floor
  - Men were firing and throwing grenades, but fortunately most did not go off or a lot more people would have been killed
  - It’s a wonder that everyone on the platform wasn’t killed
- Sadat remained standing, which Peter’s uncle interpreted as Sadat thinking it was part of the parade but Lawrence interprets as him standing to receive his execution
  - Peter talks about the “harrowing” stills of the moments before Sadat was killed
  - He is standing at attention, which looks to Lawrence like he was going to go out unintimidated

![](https://peterattiamd.com/wp-content/uploads/2021/09/fig-2.-wright.jpeg)

**Figure 2. Anwar Sadat prior to his assassination.** Image credit: [Dallas Morning News](https://www.dallasnews.com/photos/2012/10/06/today-in-photo-history-1981-egyptian-president-anwar-sadat-assassinated/)

- He was also vain and did not want a bullet proof vest to mar the lines of his new Italian-made uniform, so he was not wearing adequate protection

## Aftermath of the Sadat assassination, and establishment of Al-Qaeda in Afghanistan [50:15]

- The men in prison following the assassination of Sadat (some charged and some not charged) were tortured (“torture is deliberate humiliation”)
  - “*We don’t understand clearly the role of humiliation in human affairs, but it’s very powerful*”
- [Hosni Mubarak](https://en.wikipedia.org/wiki/Hosni_Mubarak) became president after the assassination
- The humiliation of the 1967 war sparked some of the radicalism
- We don’t know what happened to Zawahiri, but he was likely tortured

“You can emerge from that totally broken, or you can emerge full of rage and willing to do anything to exact revenge. … They were people that were either broken or turned into something else. And that something else became the seeds of Al-Qaeda”

- Al-Qaeda began as al-Zawahiri’s organization “Al Jihad”
  - They went on a rampage when they got out of prison
  - In a careless plan to assassinate the prime minister , they put a bomb outside a girls’ school, which only killed a schoolgirl, [Shaima Abdel-Halim](https://www.deseret.com/1993/11/26/19078500/egyptian-mourners-decry-terrorist-acts)
  - People in Cairo were furious and [marched in the streets](https://www.deseret.com/1993/11/26/19078500/egyptian-mourners-decry-terrorist-acts)
  - Zawahiri was actually offended by their fury
  - One of her killers now lives in London because Britain would give asylum to anyone facing the death penalty
- The topography of Egypt is not really amenable to the guerrilla warfare of the resistance
  - When you get too far away from the Nile, you are in the middle of the desert
  - The military had a strong hold over the Nile from upper Egypt to the [Nile Delta](https://en.wikipedia.org/wiki/Nile_Delta) and the [Mediterranean Sea](https://en.wikipedia.org/wiki/Mediterranean_Sea)
  - Zawahiri realized this by the mid-1980s and left for Afghanistan
- “When the [Soviets invaded [Afganistan]](https://en.wikipedia.org/wiki/Soviet%E2%80%93Afghan_War), it was an electric alarm in the Muslim world that an Islamic country was being occupied by a secular government”
  - The Soviet Union was expansionist, but it was not a good idea to go through Pakistan, a nominal ally of the US
  - There was a lot of turnover in leadership and things were a bit chaotic
  - [Zbigniew Brzezinski](https://en.wikipedia.org/wiki/Zbigniew_Brzezinski), [Jimmy Carter](https://en.wikipedia.org/wiki/Jimmy_Carter)’s national security advisor, supplied the [*mujahideen*](https://en.wikipedia.org/wiki/Afghan_mujahideen) with weapons and stingers to “give the Soviet their own Vietnam”

## Osama bin Laden: upbringing, involvement in the Soviet–Afghan War, and rise to celebrity status in Saudi Arabia [56:00]

The other half of Al-Qaeda was started with [Osama bin Laden](https://en.wikipedia.org/wiki/Osama_bin_Laden)

- Osama came from unbelievable wealth, unbelievable privilege
- He is the son of [Mohammad bin Laden](https://en.wikipedia.org/wiki/Mohammed_bin_Awad_bin_Laden) who was an illiterate laborer from Yemen who was blind in one eye
  - He did some work as a handyman prior to building his wealth
  - At that time that Mohammad made it to Yemen, the US was building up the Saudi oil reserves with Aramco
  - American companies were building roads, hotels, etc. in Saudi Arabia
  - At that time the king was [King Abdelaziz](https://en.wikipedia.org/wiki/Abdulaziz_of_Saudi_Arabia), who didn’t really trust the Americans
  - When [President Roosevelt](https://en.wikipedia.org/wiki/Franklin_D._Roosevelt) and the infirm king met in the Suez Canal, Roosevelt gave him a wheelchair
  - The king asked Mohammad Bin Laden to build a ramp so he could get upstairs
- From the very beginning, the goal had been to unify the two sides of Saudi Arabia
  - The western part was divided by the [Sarawat](https://en.wikipedia.org/wiki/Sarawat_Mountains) mountain range, which blocked access to the holy sites Mecca and Medina and a major city, Jeddah

![](https://peterattiamd.com/wp-content/uploads/2021/09/fig-3.-wright-937x1024.jpeg)

**Figure 3. Map showing mountain ranges (in green) around Mecca, Medina, and Jeddah**. Image credit: [World Atlas](https://www.worldatlas.com/maps/saudi-arabia)

- When [Faisal](https://en.wikipedia.org/wiki/Faisal_of_Saudi_Arabia) became king, he wanted to build a road to join them, a daunting task
- He accepted Mohammad Bin Laden’s (later found to be inaccurate) bid
- The legend is that Mohammad pushed a goat over the cliff and built the road following the goat’s path down the cliff face
- “That was one of the most important roads in history because it unified the kingdom”

- Mohammad Bin Laden became famous and was considered a hero
  - He had multiple wives and more than 50 children
  - Under traditional Islamic custom, men have 4 wives
  - The 4th wife is often discarded so the man can take another wife
  - Mohammed’s 4th wife was Syrian and of the [Alawite](https://en.wikipedia.org/wiki/Alawites) sect (like the [al-Assad family](https://en.wikipedia.org/wiki/Al-Assad_family)), considered heretical by Sunni Muslims
    - She was the mother of [Osama bin Laden](https://en.wikipedia.org/wiki/Osama_bin_Laden)
    - Mohammed divorced her but arranged for her to marry one of his trusted employees
    - Osama grew up in Jeddah with his mother and her second husband, to whom he became close
- Osama was very pious
  - He wore long pants to play soccer, which the other players eventually did as well
  - He fasted two days a week, emulating what he thought the prophet Muhammad did
  - He played Islamic games and led [a capella](https://en.wikipedia.org/wiki/A_cappella) singing (instrumental music is frowned upon in Saudi Arabia)
  - Being extremely religious may have been a way of standing out in very religious Saudi Arabian society, to achieve by becoming more of an authority
  - Mohammed died in an airplane crash when Osama was young, but he had exceptional status that few non-royals had

> “Osama, being the son of the fourth wife, and then cast out of the inner circle when the father divorced his mother, he always wanted to distinguish himself, and there was a hoard of other children around to compete against.” —Lawrence Wright

- Like some of his brothers (one of whom died when he crashed a plane in Texas), Osama took physical risks
  - He raced horses and drove too fast and had lots of wrecks
- A teacher who was in a secret cell of the Muslim Brothers impressed Osama
  - Like many others, Osama was also heavily influenced by the work of Sayyid Qutb
  - He went to Afghanistan and was inspired
  - He joined [Abdullah Azzam](https://en.wikipedia.org/wiki/Abdullah_Yusuf_Azzam) (“the godfather of the Arab participation in the war against the Soviets”), who saw him as a prestigious cash machine
  - At first Osama’s main task was raising money
- Then he moved to Afghanistan and formed an Arab wing of the war
  - Saudi Arabia had only a nominal army, so there was no organized military
  - Afghan warlords complained about the Arab fighters because they had no training and effected no real change in the war
  - But the Saudis loved that a son of the famed Muhammad bin Laden would actually go out and fight

**The beginnings of the Taliban [1:07:00]**

- Lawrence guesses there were fewer than a hundred Saudi [*mujahideen* fighters](https://en.wikipedia.org/wiki/Afghan_mujahideen)
  - But Saudi men would sometimes fly up for the weekend, not actually encounter the Soviets, and then claim they had been fighting in Afghanistan
- Although there were no US forces, the CIA was providing money and weapons to the [mujahideen](https://en.wikipedia.org/wiki/Afghan_mujahideen)
  - The US gave money to [Hamid Gul](https://en.wikipedia.org/wiki/Hamid_Gul), a Pakistani general who would parcel the money to seven warlords (whom the CIA called the “seven dwarfs”)
  - But Gul gave the money to the most radical warlords, directing US money to those who would later be allies with the [Taliban](https://en.wikipedia.org/wiki/Taliban)
- The word “Taliban” means “students” in Arabic and Urdu
- Many young Afghan and Pakistani boys whose parents had no money would be sent to [*madrassas*](https://en.wikipedia.org/wiki/Madrasa), many of which were on the border between Pakistan and Afghanistan
  - They would memorize the Quran in Arabic, a language they did not speak
  - They were often abused by the Afghan warlords
- Two Afghan commanders fought over a boy, which started the organization that would result in the Taliban
  - The boys looked very feminine with eye shadow and lipstick
  - Lawrence theorizes that the boys were sexualized in a society from which women were absented
  - A minor cleric named [Mohammed Omar](https://en.wikipedia.org/wiki/Mohammed_Omar), who later became the leader, began to organize
  - Lawrence thinks humiliation also played a role that’s “hard to quantify but impossible to ignore”
- The [Northern Alliance](https://en.wikipedia.org/wiki/Northern_Alliance) was a Pashtun organization that was part of the Afghan government
- It’s not known when Zawahiri and bin Laden met, but it might have been when bin Laden was raising money for the *mujahideen* or after bin Laden set up shop in Peshawar, Pakistan
  - When the Soviets withdrew from Afghanistan in 1989, bin Laden glorified himself but really hadn’t done much
  - He messed things up and got inexperienced kids killed and had no real victories

> “But what he did accomplish was to create a legend around himself and around the era of mujahideen. And it’s fascinating to me as a person that’s always been intrigued by religious beliefs, how these legends spread, and how they fortified his image.” —Lawrence Wright

- There was a myth that if you fell in battle, your body would not putrefy and would be surrounded by green birds
  - [Mohammed Jamal Khalifa](https://en.wikipedia.org/wiki/Mohammed_Jamal_Khalifa), Bin Laden’s best friend and brother-in-law, claimed to have seen this phenomenon with his own eyes
  - People throughout the Muslim world heard stories of brave fighters who live in caves and win against technological powers
  - People believed they should support these fighters and donated to the cause
- In Saudi Arabia, there’s a prohibition on human (or even animal) forms (though there are pictures of the kings and princes)
  - It’s taken so seriously that there was even a legal battle over the image on the Starbucks logo
  - they were ultimately allowed to keep it because the figure was classified as a mermaid and thus mythological rather than animal or human

![](https://peterattiamd.com/wp-content/uploads/2021/09/fig-4.-wright.png)

**Figure 4. The Starbucks logo that led to litigation in Saudi Arabia.**

- Lawrence calls bin Laden “Saudi’s first celebrity”
  - The Saudi royals weren’t used to having a rival power
  - but bin Laden was “enigmatic, intriguing, very handsome, very tall, and had a kind of elegance about him,” and people would come out in droves to hear him make a speech

## How the Western intervention in Saudi Arabia impacted Arab nationalist’s hatred of America [1:15:30]

**Resentment in Saudi Arabia – Saddam invades Kuwait**

- In summer 1990, Iraq under [Saddam Hussein](https://en.wikipedia.org/wiki/Saddam_Hussein) invaded Kuwait
  - In retrospect, this was a huge factor leading to 9/11
- bin Laden didn’t want America and other allies to rush in to save Saudi Arabia
  - He proposed having a few dozen Al Qaeda fighters resist the million-man Iraqi army and wasn’t taken seriously
- Peter spent a week with [Prince Turki](https://en.wikipedia.org/wiki/Turki_bin_Faisal_Al_Saud), who said bin Laden believed his own hype about his victory in Afghanistan
  - bin Laden was likely horrified that his country was going to be defended by an army that included women, Jews, and Christians
- The US could have left after Saddam Hussein retreated, but we didn’t
  - The Saudi royals know everyone in the world wants their oil, so they were tolerant of an American military presence
  - A saying is attributed to the prophet Mohammed that there shall not be two religions in Saudi Arabia
  - There were more than two in Mohammed’s time and then, but bin Laden took it to mean that only Sunnis with his specific beliefs should live in Saudi Arabia
  - But there were lots of Americans and other foreigners, most not Muslim, living in the country to defend it, which was humiliating
- There were many nationalist groups across the Arab world who wanted to transform their countries
  - Zawahiri in Egypt was one of them – “​​*And as you characterize the corrupt ruthless leader, that was true. He was right about the nature of the rule, but he was* ***wrong about the solution****.*”
  - bin Laden created a coalition of these groups, redirecting them to become an **international** terrorist group rather than focus on their nationalist orbits

## Theorizing on the role of the religion in holding back Islamic states from making progress towards democracy [1:20:30]

**Egyptian reckoning**

- Peter would ask his parents why Egypt had to have rigged elections instead of an actual democracy
  - His parents had different views: his mom loved Egypt and Nasser and his dad despised them
  - But they agreed that democracy would not work there and you needed an iron fist to rule it and Mubarak was the least bad option
- Lawrence said he was “*wrong about Egypt*” — he thought Egypt was ready for democracy and it wouldn’t fall apart like Iraq
  - He was very optimistic but he was wrong
- When he went back to speak at American University in Cairo and Cairo University around the election, the students were excited by democracy and wanted revolutionary, nonviolent change
  - But one student asked, “*What happened to us?*”
  - They had been the center of civilization, and every Egyptian lives with the weight of that history on their shoulders
  - Peter’s mom would tell him that because they were [Coptic](https://en.wikipedia.org/wiki/Copts), his ancestors built pyramids and science and engineering was in his blood
  - Lawrence told the Egyptian student that it takes a generation
    - his father emerged poor from the [Dust Bowl](https://en.wikipedia.org/wiki/Dust_Bowl) in Kansas but became a banker in Dallas and “he and his generation built the most powerful country and economy in the history of the world”
    - But members of a generation must have influence to make such a change

> “The failure of tyranny, I think, is essentially those kinds of people that would be transformative for a country are not given the chance to be the kind of leaders that they could be.” —Lawrence Wright

**Peter asks:** *What role does religion play in this? And specifically, what role does Islam play in this? Is there something about Islam and its current level of maturity, which may be as akin to Christianity a thousand years ago, that is standing in the way of the progress you speak of?*

**Islam and politics**

- Islam plays out differently in different countries
  - Indonesia has been a successful Muslim country
  - But Islam means submission, and it’s harmful when people are encouraged to adopt a submissive attitude
  - Ruthless dictatorships justify themselves based on religion and use religious texts that urge compliance
  - Lawrence thinks it is possible to have an Islamic country that is a modern democracy
  - Tunisia has been struggling to do that, but there are “tyrants from Morocco all the way to Southern China” and Lawrence hopes the region can mature from that
- When Lawrence was in Egypt, it was more secular and accommodating and “longed for a relationship with the west”
  - Egyptians liked Americans (whom they saw as truly democratic and friendly) but not the insular Soviets, whom they viewed as an occupying force
  - Lawrence had a great time living and teaching in Egypt
  - But it was different after 9/11
    - Though the governments were friendly, the people were upset, which Lawrence found odd given that we were the ones who had been attacked
    - An Egyptian woman told Lawrence she believed the US had been behind 9/11
      - She believed this because “nobody’s ever told us the truth” and it made sense to her that the US wanted an excuse to attack the Arab world
      - Peter notes this is like saying that the CIA killed [Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy) because they had to figure out a way to get into Vietnam

## Bin Laden’s time in Sudan [1:32:30]

- In the early 1990s, Osama bin Laden has been “humiliated” by his own government who have essentially said, “Thanks, but no thanks. We’re going to have the Americans help us out here.”
- So bin Laden went to Sudan, what happens next?
- From 1992-1996, Al Qaeda became essentially an agricultural organization
- Bin Laden was probably the largest landowner in Sudan
  - He provided services like building highways for the government in exchange for land
  - Lawrence went to Sudan to find out more about bin Laden’s time there
- He met an Al Qaeda contact who told him about some of bin Laden’s enterprises
  - He turned out to be [Mohammed Loay](https://en.wikipedia.org/wiki/Mohammed_Loay_Bayazid) (Al-Qaeda name Albarida Alsuri), who took the notes at the founding of Al-Qaeda in May 1988
  - After a failed attempt, Lawrence finally got him to agree to talk again
  - He had not been sure what to make of Lawrence because he had been sitting on an exercise ball at their first meeting, which Loay found strange
- Loay said that the Sudan years were wonderful for Al-Qaeda because they weren’t fighting and Bin Laden was generous with his money
  - But those years in Sudan—at least according to the Loay—were kind of wonderful years for Al-Qaeda because they weren’t fighting anybody
- But the US state department had opened a file on bin Laden as a *potential terrorist* and pressured the Sudanese government until they expelled him

## The CIA vs. the FBI: setting the stage for the failure of US intelligence [1:37:00]

**The other main story in** ***The Looming Tower*** **is the failure of US intelligence—There were two parallel organizations: I-49 and Alec station**

**Alec Station:**

- [The bin Laden Issue Station](https://en.wikipedia.org/wiki/Bin_Laden_Issue_Station) (codename Alec Station), the first “off-campus” CIA US station, was a unit designed to track bin Laden
  - The CIA ignored it and called its employees “the island of lost toys”
  - The team was led by [Michael Scheuer](https://en.wikipedia.org/wiki/Michael_Scheuer), who was a loose cannon and today is “off the rails”
  - But he could understand bin Laden’s mindset and was right that Al Qaeda was a terrorist organization that could and intended to strike the US
  - The idea that a man in a cave in Afghanistan would attack America seemed comical and Scheuer was not taken seriously

**I-49:**

*\*Peter points out that both Scheuer and* [*O’Neill*](https://en.wikipedia.org/wiki/John_P._O%27Neill) *were right about the threat, but because of their remarkable disdain for each other, tragically both let this thing slip*

- [I-49](https://www.historycommons.org/entity.jsp?entity=i-49_1), an anti-terrorist squad of the Federal Bureau of Investigation ([FBI](https://en.wikipedia.org/wiki/Federal_Bureau_of_Investigation)), was led by [John P. O’Neill](https://en.wikipedia.org/wiki/John_P._O%27Neill), a flamboyant agent
  - He wore Gucci suits and shoes like ballet slippers
  - He had a luxurious, decorated office with fresh flowers (and, Lawrence notes, a copy of the book [*The Tulip: The Story of a Flower That Has Made Men Mad*](https://www.amazon.com/TheTulip/dp/B0092G9S1K/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=)) that stood in sharp contrast to the typical drab FBI office
  - When O’Neill was assigned to NYC, he had a list of names of everyone he wanted to meet
- O’Neill and Scherer hated each other, which tragically resulted in both of them letting things slip
- There was antagonism between the CIA and the FBI
  - Lawrence’s movie *The Siege*, about a woman in the CIA, was about this rivalry
  - The FBI’s purpose is law enforcement and the CIA’s is intelligence, so they can have different priorities

> “As an American, I can’t tell you how disappointed I am in our intelligence agencies and their failure to protect our country. That’s their mission, but they got so caught up in their institutional and personal antagonisms that they allowed 9/11 to happen.” —Lawrence Wright

**The different priorities of the FBI and the CIA**

- Al-Qaeda and Al-Jihad became one entity in the late 90s
- After the bombing of the American embassies in Kenya and Tanzania in 1998, the FBI was given the task of trying to find out if it was a crime against the US
  - 224 people, including many Americans, were killed
  - more than 100 people were blinded by flying glass
- Americans killed on foreign soil is the purview of the FBI
  - The way it is supposed to work is that the FBI gets permission from the government of the country where they’re investigating, conduct a criminal investigation, and then the accused would stand trial in the United States
  - But only 6 of 50,000 FBI agents spoke Arabic
  - One of them was [Ali Soufan](https://en.wikipedia.org/wiki/Ali_Soufan), who was born in Lebanon and he began piecing together what was going on with Al-Qaeda
    - O’Neill made Soufan his eyes and ears in the Arab world
  - Many I-49 agents spoke Russian or other Eastern European languages
  - Then the Soviet Union fell, but I-49 agents did not have experience in dealing with the Arab world

## The mistake by US intelligence of not taking the bombings of the US embassies and the USS Cole seriously [1:46:00]

On October 20, 2000, the [USS *Cole*](https://en.wikipedia.org/wiki/USS_Cole_(DDG-67)) [was blown up](https://en.wikipedia.org/wiki/USS_Cole_bombing) by a small skiff

> “USS *Cole* was an unbelievable worship for traditional warfare and yet was defenseless against guerrilla warfare. … There was kind of this decade lag after the cold war where the military industrial complex had not adopted to what the new warfare was.” —Peter Attia

- It was blown up 2 weeks before the election and 19 sailors died
- It is parallel to the way the FBI and CIA had the “human and intellectual skillset that’s for the wrong war” and did not catch up with the skills needed to fight an organization like Al-Qaeda
- The USS *Cole* was in the [Gulf of Aden](https://en.wikipedia.org/wiki/Gulf_of_Aden) in Yemen, which is not a US ally and an area with many people intent on doing harm to the US
  - It was not uncommon for small boats to approach selling things or delivering food, so the USS Cole crew would not have been suspicious
- Lawrence suspects bin Laden thought the embassy bombings would grab US attention, but we ignored them
  - Then the *Cole* bombing did not draw the US in either
  - Some of the main operatives in the embassy and bombings were al-Zawahiri’s men
- Peter wonders why neither [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) nor [Al Gore](https://en.wikipedia.org/wiki/Al_Gore) made the *Cole* bombing an issue in their campaigns
  - Lawrence suspects it was because it did not happen here: “That’s one of the reasons Americans were so vulnerable is our own hubris in the sense of isolation that we have historically always felt”
  - US lives lost abroad seem to be viewed as the cost of doing business

> “There’s a gap between our role in the world and the people we think we are.” —Lawrence Wright

- bin Laden felt that the US was encircling the Islamic world and our goal must be to destroy Islam
  - bin Laden felt that Islam should regain its expansionist power
  - He wanted the US to suffer and make it feel humiliation because he understood that power
- It seemed preposterous that someone like bin Laden could attack such a powerful and distant country
  - O’Neill and Scheuer both understood that Osama bin Laden was a bad actor who should be taken seriously
  - But O’Neil believed that bin Laden and other Al-Qaeda operatives should be brought to justice in US courts, while Scheuer thought they should be assassinated
- After the bombings in Kenya and Tanzania, there was a bungled attempt to assassinate bin Laden in 1998
  - The Clinton White House bombed training camps in Afghanistan and a factory in Khartoum that we thought was manufacturing poison chemicals for Al-Qaeda but was actually the primary manufacturer of veterinary medicines in a poor country
  - bin Laden wasn’t in the camps
  - The attacks were exactly what bin Laden wanted

> “There was a failure of imagination, but it was coupled with prejudicial ideas about who we’re dealing with and a tremendous absence of knowledge about the cultures that our adversaries came from.” —Lawrence Wright

- Clinton floated the idea of sending in ninjas rappelled down from [Cobra helicopters](https://en.wikipedia.org/wiki/Bell_AH-1_Cobra)
  - might have surprised bin Laden and in retrospect may have been a better idea
  - “but we were still in the remote control phase of our Imperial rule”

## Al-Qaeda in America: Losing the planners of the 9/11 attacks from our clutches and incompetence at the FBI and CIA [1:56:00]

- On January 15, 2000, two Saudis named [Khalid al Mihdhar](https://en.wikipedia.org/wiki/Khalid_al-Mihdhar) and [Nawaf al Hazmi](https://en.wikipedia.org/wiki/Nawaf_al-Hazmi) arrived in the US
  - They had been in a meeting in Kuala Lumpur with the Cole bombers
  - Couldn’t train as pilots because they did not speak English
  - On the day they arrive, a Saudi named [Omar al-Bayoumi](https://en.wikipedia.org/wiki/Omar_al-Bayoumi) was at the Saudi consulate in LA talking to the minister of religious affairs
  - He then went to a middle astern restaurant where he “coincidentally” encounters the two men
  - Bayoumi gives them money and sets them up in San Diego
- [Haifa Al Saud](https://en.wikipedia.org/wiki/Haifa_bint_Faisal_Al_Saud), the wife of the Saudi ambassador to the US, [Bandar Al Saud](https://en.wikipedia.org/wiki/Bandar_bin_Sultan_Al_Saud), sends Bayoumi thousands of dollars
  - The money has never been accounted for
  - Their daughter, [Reema Al Saud](https://en.wikipedia.org/wiki/Reema_bint_Bandar_Al_Saud), is now the Ambassador to the US
- Bayoumi introduces al-Hazmi and Mihdhar to [Anwar al-Awlaki](https://en.wikipedia.org/wiki/Anwar_al-Awlaki), a cleric at a Saudi mosque in San Diego (the US eventually killed him with a targeted drone strike in Yemen in 2011)
- In March, almost 2 years before 9/11, Prince Turki informs the CIA in Riyadh that al-Hazmi and Mihdhar are in the US
  - Mihdhar’s wife, [Hoda Al-Hada](https://www.historycommons.org/entity.jsp?entity=hoda_al-hada_1), comes from an Al-Qaeda jihadi family and is in Yemen
  - The CIA has wiretapped the Al-Hada household, which gets 14 calls from San Diego
- Ali Soufan, who is questioning *Cole* bombing suspects, learns about the meeting in Kuala Lumpur, Malaysia
  - Soufan asks the CIA for info on al-Hazmi and Mihdhar at least 3 times
  - The CIA says it has no information about the meeting, even though it covered it and sent a Malaysian policeman to take photographs of it
  - They had photographs of the participants and hid it from the FBI
- The FBI had the authority in this situation a warrant on Al-Qaeda and Bin Laden and all his followers
  - The CIA is not supposed to operate within the US
  - It was an obstruction of justice for the CIA to hide information about the planning and Kuala Lumpur meeting during the investigation of the *Cole* bombing and 19 associated murders
- Meanwhile, Michael Scheuer had been relentless in pressing the agency and trying to get rid of Bin Laden
  - When members of the UAE royal family were coming to a camp in Afghanistan to hunt an endangered bird (the [bustard](https://en.wikipedia.org/wiki/Bustard)), Scheuer wanted to bomb the camp in hopes of getting bin Laden
  - Since the UAE is an ally, that could have been a disaster (not to mention that we were selling them a whole fleet of F-16s at that moment)
  - Scheuer was terminated and replaced at Alec Station by a woman whom Lawrence calls “an FBI villain” (and who later married Scheuer)

**Incompetence at the FBI and CIA [2:04:45]**

- A number of I-49 agents were physically located at Alec Station
  - They were FBI agents privy to CIA information that they could not share with their FBI colleagues
  - Peter finds it odd that none of them broke ranks as [Edward Snowden](https://en.wikipedia.org/wiki/Edward_Snowden) did a decade later
  - Lawrence says there was an idea called “the wall” that information should not travel from the intelligence world into the criminal one and vice versa, but it wasn’t the law as many thought, just a custom
- The FBI had its own intelligence division and, like grand jury testimony, it’s supposed to be sealed
  - “But when you’re faced with something like that, your only alternative is to break the law and there can be very serious consequences and it’s a lonely thing to do but that’s really the only thing you do”
  - These FBI agents are broken by what happened
  - John O’Neill died in the World Trade Center on 9/11 as a consequence of their reticence to say anything
- Lawrence holds the CIA responsible for 9/11
  - If the CIA had told the FBI that members of al-Qaeda were in the US, the FBI had warrants and the authority to follow them, tape them, monitor their computers, and arrest them
- Lawrence wrote an [article](https://www.newyorker.com/magazine/2002/09/16/the-man-behind-bin-laden) about Ayman al-Zawahiri for the *New Yorker* and the CIA asked to talk to him
  - He met with about 20 people at Alec Station and they all spoke Arabic
  - He wasn’t trying to hide info from the CIA – he was publishing it – and he didn’t feel that he was betraying sources by speaking to the CIA
  - They said Bin Laden was alive in 2003, when there was a rumor that he was dead
- Intelligence agencies tend to trust info that has been stolen, figuring people tell the truth when they are not being listened to
  - In contrast, reporters like to talk to people directly to ask things you don’t normally get on transcripts
- The CIA had a transcript of Lawrence’s conversation with Zawahiri’s cousin
  - He assumed Egypt has tapped the cousin and gave it to the CIA
  - But Lawrence later found out the CIA had tapped his phone
  - They are not supposed to tap Americans and, if they do, they should be identified as “Individual A” rather than by name
- Lawrence was visited by a terrorism squad in Austin
  - He thought they wanted advice (he had given background on Al-Qaeda to the FBI before)
  - One of them was from the FDA and was terrified when he saw the books and Arabic names in Lawrence’s office
  - They asked him about a call he had made to England
    - The number was for a barrister who had represented some jihadis
    - They thought Lawrence’s daughter [Caroline Wright](https://www.carolinewrightart.com/about), who was a college student at the time, was calling the lawyer to reach the jihadis
  - He realized they had been listening to his calls

> “I was really outraged as an American citizen but also shocked by the level of incompetence.” —Lawrence Wright

- He was glad they at least came to clear it up, “but the presumptions that they had were so absurd that I could see how we got ourselves into this fix”

- The CIA couldn’t operate in the US, but the Saudis could
  - They struck a deal with the Saudis to track al-Hazmi and Mihdhar, but they should have known better
- “Here they are in our clutches, we have an opportunity to penetrate al-Qaeda, which is not something the CIA had been able to do”
- But then the two hijackers disappeared and the CIA lost them
  - It was only then, in August of 2001, that the CIA went to the FBI to ask them to find the men they had lost
  - It was just a couple of weeks before 9/11
  - It was too late and the FBI never did find them

**What motivated the 9/11 terrorists?**

- [Mohamed Atta](https://en.wikipedia.org/wiki/Mohamed_Atta) was the senior figure among them
  - He was pious but also educated
- Peter wonders if it’s possible that all 19 of the 9/11 terrorists literally believed “they would be greeted in paradise by virgins”
  - Lawrence thinks they did, but that their primary motive was martyrdom, which “has its appeal, especially for young men who have really little opportunity to make a dent in the world”
  - Or even just that if they sacrifice their lives, they can change history

## Problematic policies and Europe, and a direct message warning of the 9/11 attacks [2:14:45]

**International tolerance for foreign terrorist groups**

- Because of Germany’s tortured history, it bans domestic terrorist organizations (fascists are not tolerated)
  - But it adopts an implicit neutrality about immigrants who oppose regimes in their home countries
  - If it doesn’t affect Germany, the country tends to stay out of it
- Other countries in Europe were also “slow to awaken to the threat to their own countries”
  - Terrorists were allowed into England because they faced the death penalty in Egypt, and some even get subsidized rent
    - Lawrence knows a driving instructor in London who murdered a little girl (Shaima Abdel-Halim) in Egypt in a failed attempt to kill the prime minister
  - England, Germany and Spain especially all tolerated foreign terror groups developing inside their borders
- [Atta](https://en.wikipedia.org/wiki/Mohamed_Atta), unlike the others, spoke decent English and was one of the 4 pilots
  - He had been coordinating with al-Qaeda in Spain, then flew to the US
- The 9/11 terrorists weren’t really hiding in the US; they did not know the CIA knew they were there
  - They had driver’s licenses in their own names and were even listed in the San Diego phone book
  - “They didn’t feel threatened and they took advantage of that freedom”

**A direct warning to President Bust on August 6th, 2001**

- [Richard Clarke](https://en.wikipedia.org/wiki/Richard_A._Clarke) was the lead counter-terrorism adviser on the National Security Council under Clinton
- After the election, he got pushed down the ranks because the Bush administration was still focused on China and Russia
  - When Clarke warned [Condolezza Rice](https://en.wikipedia.org/wiki/Condoleezza_Rice), the incoming National Security Advisor, about al-Qaeda, she did not take the threat seriously
  - Bush did not take it seriously until the Saudis threatened to break off relations with the US because of Israel
- Then on August 6, 2001, there was a CIA [presidential daily brief](https://en.wikipedia.org/wiki/Bin_Ladin_Determined_To_Strike_in_US) warning that al-Qaeda was set to attack in the US

![](https://peterattiamd.com/wp-content/uploads/2021/09/fig-5.-daily-brief-wright-811x1024.png)

**Figure 5. Presidential Daily Brief on August 6, 2001.** [[source](https://en.wikipedia.org/wiki/Bin_Ladin_Determined_To_Strike_in_US)]

- This was around the same time that the CIA lost track of the men they were tracking in San Diego
- When asked about the memo during the 9/11 commission, Condi Rice claimed it was already known but also speculative with no added intelligence

> “Such dodges were characteristic of a lot of the people involved in this massive intelligence failure. … It was just incompetence, actually. There were memos that we didn’t read and yes, it was in the memos but it never really came to the attention of people in authority.” —Lawrence Wright

- There had been other bombings (the embassies and the *Cole*) and al-Qaeda was here, so it was obvious they were planning an attack on US soil
- When O’Neill asked Condi Rice about this, she said it was not a high priority because it was like swatting flies

## The role of political infighting and personality conflicts that helped enable the 9/11 attacks and the lack of accountability [2:22:45]

- It wasn’t just incompetence but also personality conflicts
- [Barbara Bodine](https://en.wikipedia.org/wiki/Barbara_Bodine), then the ambassador to Yemen, did not get along with John O’Neill
  - O’Neill was a polarizing figure – you either loved or hated him
  - Bodine was offended when the FBI showed up in Yemen heavily armed
  - O’Neill saw it as trying to protect his people, but Bodine made them give up their long guns and kicked O’Neill out of Yemen
  - Bodine saw her job as cultivating a better relationship with the Yemenis, and she saw O’Neill as a “swaggering misogynist” whose macho stance was alienating them
- O’Neill took papers he should not have removed from the office to Florida so he could work at a conference
  - he left his briefcase in a conference room where it was stolen
  - When he recovered it, only a cigar cutter had been taken, but he had to turn himself in
  - His many enemies at the FBI took the chance to get rid of him
- Richard Clarke wanted O’Neill to replace him, but O’Neill was in debt and took a job as head of security at the World Trade Center
  - He was killed on 9/11 after about a month on the job
  - “He’s the guy that had the warrant on bin Laden. But instead of getting bin Laden, bin Laden got him”
  - Some of his colleagues told him he would be safe because they had already hit the World Trade Center in 1993
  - But he believed they’d come back to finish the job
  - He had escaped but walked back into the building on 9/11 to rescue others

If the CIA had told the FBI earlier, or if the attack had happened later, it’s possible 9/11 could have been prevented

- The FBI could have cross-checked the CIA list of suspected al-Qaeda operatives and the list of flight school attendees
  - They could have been prevented from boarding planes
  - And investigate why certain Arabs wanted to learn to fly but not to land
  - One FBI agent had envisioned them crashing planes into buildings
- When the 9/11 families sued to see the pages suppressed in the 9/11 report, they found that the CIA had known that some Saudis had been doing trial runs
  - They would see if they could “accidentally” walk into the cockpit
  - One flight was actually grounded due to Saudi passengers’ provocative behavior; they claimed they were headed to a party at the Saudi embassy and gave them an actual embassy phone number
- Even [George Tenet](https://en.wikipedia.org/wiki/George_Tenet) from the CIA was warning the White House that an attack was being planned
  - He seemed to understand the seriousness of the threat, but at the same time his agency was derelict
  - Peter says, “It’s sort of like the arsonist who as the house catches on fire is actually the one that calls the firefighters”
  - Tenet has refused to speak with Lawrence

> “I think I’m being fair enough to say the CIA knew what was going on. They hid the information from the FBI. Had the CIA been transparent and worked in tandem with the FBI, that 9/11 would not have happened. I think the facts support that. There’s never been accountability for this, not any.” —Lawrence Wright

- Tenet got the [Presidential Medal of Freedom](https://en.wikipedia.org/wiki/Presidential_Medal_of_Freedom) and other accolades instead of being held accountable
- And others at the CIA got promotions instead of being charged with obstruction of justice

## What came of the 9/11 commission, the role of the Saudi government, and the trials of Ali Soufan [2:36:00]

**The 9/11 commission (2:36:00)**

- Frustrating for family members
  - Many pages of the report were suppressed and some info was redacted
- It is not clear why the Saudis were given their clearance to leave
- It’s not clear to Peter why anyone within the royal family or Saudi intelligence would want bin Laden to succeed
  - But it appears that some of them at best watched it happen and at worst supported it financially and in other ways
  - Lawrence postulates that after the Saudis told us that al-Qaeda was in America:
    - the CIA may have thought the Saudi government could use the low-level recruits to find people like Bayoumi
    - Or maybe Bayoumi was a Saudi intelligence operative and that’s why the ambassador’s wife sent him money
  - Maybe the Saudis wanted to figure out what the al-Qaeda operatives were planning
  - Peter doubts the Saudis knew the terrorists could accomplish something on such a grand scale
- Peter says the analogy here might be someone who accidentally sets a house on fire and then calls the fire department, but makes sure they’re nowhere near the scene when the firefighters arrive
- Lawrence hopes a whistleblower will come forward to reveal what actually happened, but 20 years later no one has
  - Lawrence thinks the CIA hopes “to bury it in institutional memory and have it never surface”
- Richard Clarke was the only government official to take responsibility and publicly apologize
  - He’s been the target of partisan hit jobs, but he actually served under presidents of both parties
  - Lawrence was on [Sean Hannity](https://en.wikipedia.org/wiki/Sean_Hannity)’s show and all Hannity wanted to do was attack Clarke
  - Some of Clarke’s actions – like authorizing the flights for the Saudis to leave the US – are questionable, but he was the one warning about al-Qaeda

**Ali Soufan was a huge asset to the US (2:42:30)**

- He was an earnest immigrant who became the lead agent for the *Cole* bombing investigation around age 26
- He was intelligent and well-versed in Islam
- He would confront al-Qaeda members about their beliefs, asking them to show him where it said that in the Quran
  - He more or less won over [Nasser al-Bahri](https://en.wikipedia.org/wiki/Nasser_al-Bahri) (known as Abu Jandal) with his knowledge of Islam
- He could effectively interrogate without torture
  - He said he would leave if they continued waterboarding prisoners at the [Guantanamo Bay detention camp](https://en.wikipedia.org/wiki/Guantanamo_Bay_detention_camp), so they told him to leave
  - He identified the al-Qaeda operatives through his skilled interrogation techniques
    - But during that time, the CIA was hiding something from him
- On 9/11, he loses his mentor John O’Neill
- He is told to remain in his office in Yemen and was finally given the photos of the people at the meeting in Kuala Lumpur
  - He recognized an al-Qaeda operative in the pictures
  - If the CIA had given him the pictures when he first asked, the FBI could have cracked the case then

> “And he went to the bathroom and threw up, and he went to work. And thus, when he got the names of the al-Qaeda guys and he essentially solved the crime from that office in Yemen. One man and history could have been so different if the CIA listened [and] acceded to his request and there was nobody better prepared to take advantage of it than Ali Soufan.” —Lawrence Wright

## Lessons from 9/11 and the future of terrorism [2:46:30]

- Peter reflects how amazing Lawrence’s investigation was – the amount of research, the dangerous trips into “the lion’s den,” and how infuriating it must have been to learn how incompetence had such severe consequences
  - Nothing Peter has been professionally upset about – such as the Dietary Guidelines in the 1970s – compares to this
  - Peter also thinks that Lawrence’s work has “created a place in history for a lot of people who wouldn’t otherwise be recognized” like Ali Soufan
- What is the future of asymmetric warfare with organizations like al-Qaeda?
  - Lawrence thinks it will be an issue in the future
  - There are innumerable terrorist groups, including white supremacists in our own country
  - “Al-Qaeda set a template: a small group, highly empowered by kind of judo moves of using technology against the countries that developed the technology”
    - There were 300-400 members of al-Qaeda on 9/11, and now there are 30,000-40,000 members all over the world
    - Lawrence worries that drone technology will empower them
- Small groups can now have far greater influence and power
  - There are groups like [Aum Shinrikyo](https://en.wikipedia.org/wiki/Aleph_(Japanese_cult)), a Japanese cult that wanted to destroy much of the world with diseases or atomic bombs and had a lot of capable scientists as members
  - A white supremacist group called [Atomwaffen Division](https://en.wikipedia.org/wiki/Atomwaffen_Division) wants to wipe out much of the population with biological warfare so only white people are left
  - “It’s dismayingly easy to create diseases”
- Lawrence says he talked to the American version of [M](https://en.wikipedia.org/wiki/M_(James_Bond)), the fictional character in James Bond stories who creates weapons
  - The man was worried that high school kids who can create computer viruses will one day soon be able to manufacture biological viruses
- Lawrence laments that our world is limited by a loss of freedom because of the danger
  - The next two generations will live in a world with terrorism, and Lawrence doesn’t see how we will restrain it
- There are two strategies to combat terrorism
  - Reduce the drive for terrorism by addressing the humiliation and disenfranchisement of potential perpetrators
  - Improve our offensive strategies by improving intelligence
- Lawrence says we see waves of different types of terrorism
  - mass shootings (which started with the [UT tower shootings](https://en.wikipedia.org/wiki/University_of_Texas_tower_shooting) in 1966 and extends to the present, such as the [2019 massacre in El Paso](https://en.wikipedia.org/wiki/2019_El_Paso_shooting) that killed 23 Mexican Americans)
  - school shootings
  - Drive-by shootings
- Lawrence thinks we are doing a better job of being alert to terrorism and containing it, but our intelligence agencies must improve
- Terrorism is not the only threat to our safety and security
  - we must also consider things like public health, the natural environment, and global warming, and so far we are not addressing them adequately
  - “The pandemic was a catastrophic intelligence failure. This was a national security threat. We’ve lost more than 600,000 Americans”
- Peter asks if relatively small terrorist organizations would have the capacity to acquire and actually utilize nuclear weapons
  - Lawrence says that, for now at least, nuclear weapons tend to be beyond the capacity of such groups, but that could change in the future
  - Biological weapons are a big concern, as are toxins like [anthrax](https://en.wikipedia.org/wiki/Anthrax), because of their scale

> “I think we can’t live our lives in fear all the time, but you’d be nuts not to pay attention to the fact that there are dangers out there and there are people that want to cause harm. … It’s the absence of unity in our community that threatens us the most now because we’re not together on this. There are people that would cheer on such actions and what kind of country have we become in that case?” —Lawrence Wright

- Peter hopes we can all reflect on the people who made sacrifices and lost their lives – experience both gratitude and sadness
- Lawrence reflects that sometimes tragedies have benefits for society
  - We did not emerge from the [1918 flu pandemic](https://en.wikipedia.org/wiki/Spanish_flu) stronger
  - We came out of the [Great Depression](https://en.wikipedia.org/wiki/Great_Depression) stronger, more compassionate, and more resilient
  - But we squandered 9/11
    - We [invaded Iraq](https://en.wikipedia.org/wiki/2003_invasion_of_Iraq) and tortured people in Guantanamo

> “The consequences of what we did to ourselves after 9/11 are greater than what was done to us.” —Lawrence Wright

- We need to take lessons from 9/11 and the pandemic and try to make ourselves back into the country we once were and want to be again

§

## Selected Links / Related Material

**Lawrence’s books:**

*Book this podcast is based on:* [The Looming Tower: Al-Qaeda and the Road to 9/11](https://www.amazon.com/Looming-Tower-Al-Qaeda-Road-11/dp/037541486X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1629640973&sr=8-1) (2006) | [Intro, 15:00, 2:27:15, and throughout]

*Other Nonfiction*

- [The Plague Year: America in the Time of COVID](https://www.amazon.com/Plague-Year-America-Time-Covid/dp/0593320727/ref=sr_1_1?dchild=1&keywords=The+Plague+Year%3A+America+in+the+Time+of+COVID&qid=1629640928&sr=8-1) (2021)
- [God Save Texas: A Journey into the Soul of the Lone Star State](https://www.amazon.com/God-Save-Texas-Journey-State/dp/0525520104/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1629326217&sr=1-6) (2018)
- [The Terror Years: From Al-Qaeda to the Islamic State](https://www.amazon.com/Terror-Years-al-Qaeda-Islamic-State/dp/0385352050/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1629328515&sr=1-1) (2016)
- [Thirteen Days in September: Carter, Begin and Sadat at Camp David](https://www.amazon.com/Thirteen-Days-September-Carter-Begin/dp/0385352034/ref=sr_1_1?keywords=Thirteen+Days+in+September%3A+Carter%2C+Begin+and+Sadat+at+Camp+David&qid=1629328458&s=books&sr=1-1) (2014)
- [Going Clear: Scientology, Hollywood, and the Prison of Belief](https://www.amazon.com/Going-Clear-Scientology-Hollywood-Prison/dp/0307745309/ref=sr_1_1?crid=10TC2DLWHGHIY&keywords=going+clear+scientology%2C+hollywood%2C+and+the+prison+of+belief&qid=1629326503&s=books&sprefix=going+c%2Cstripbooks%2C171&sr=1-1) (2013)
- [Twins: And What They Tell Us About Who We Are](https://www.amazon.com/Twins-What-They-Tell-About/dp/1630262455/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1629328398&sr=1-2) (1997)
- [Remembering Satan: A Case of Recovered Memory and the Shattering of an American Family](https://www.amazon.com/Remembering-Satan-Recovered-Shattering-1994-03-29/dp/B01LZ51QSF/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1629328117&sr=1-1) (1994)
- [Saints and Sinners](https://www.amazon.com/Saints-Sinners-Lawrence-Wright-1993-04-13/dp/B01F7XM7JG/ref=sr_1_2?dchild=1&keywords=saints+and+sinners+lawrence+wright&qid=1629328044&s=books&sr=1-2) (1993)
- [In the New World: Growing up with America from the Sixties to the Eighties](https://www.amazon.com/New-World-Growing-America-Eighties/dp/0345802950) (1988)
- [City Children, Country Summer: A Story of Ghetto Children Among the Amish](https://www.amazon.com/City-Children-Country-Summer-Ghetto/dp/0684161443/ref=sr_1_1?dchild=1&keywords=City+Children%2C+Country+Summer%3A+A+Story+of+Ghetto+Children+Among+the+Amish&qid=1629327672&sr=8-1) (1979)

*Fiction*

- [The End of October: A novel](https://www.amazon.com/End-October-novel-Lawrence-Wright/dp/0525658653/ref=pd_bxgy_img_1/139-2451850-0250862?pd_rd_w=ZiYOi&pf_rd_p=c64372fa-c41c-422e-990d-9e034f73989b&pf_rd_r=W9VMJWYT1NZ1QJZ74MJV&pd_rd_r=ad133727-bea0-4d95-97f7-12639097380a&pd_rd_wg=H8IUt&pd_rd_i=0525658653&psc=1) (2020)
- [God’s Favorite: A novel](https://www.amazon.com/Gods-Favorite-Novel-Lawrence-Wright/dp/0684868105/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1629328603&sr=1-1) (2000)

**Lawrence’s movie**: [The Siege](https://en.wikipedia.org/wiki/The_Siege) | screenplay by Lawrence Wright, Menno Meyjes, and Edward Zwick (1998) | [5:00, 6:30, 15:15, 1:40:00, 2:02:30]

**Collection of** ***New Yorker*** **writers’ reactions to 9/11**: [Talk of the Town: Tuesday, and After](https://www.newyorker.com/magazine/2001/09/24/tuesday-and-after-talk-of-the-town) | *The New Yorker* (September 24, 2001) | [16:30]

**Book with Friedman quote about 9/11 being a failure of imagination rather than intelligence**: [Longitudes & Attitudes: Exploring the World after September 11](https://www.amazon.com/Longitudes-Attitudes-Exploring-World-September/dp/0374190666) | by Thomas Friedman (2002) | [22:15]

**Article about outrage at the death of an Egyptian girl accidentally killed in a bungled asassination attempt on the prime minister**: [Egyptian Mourners Decry Terrorist Acts](https://www.deseret.com/1993/11/26/19078500/egyptian-mourners-decry-terrorist-acts)  | *Deseret News* (November 26, 1993) | [52:30]

**Article about the conflict between the CIA and FBI leading up to 9/11**: [9/11 Congressional Report Faults F.B.I.-C.I.A. Lapses](https://www.nytimes.com/2003/07/24/us/9-11-congressional-report-faults-fbi-cia-lapses.html) | David Johnston, *New York Times* (July 24, 2003) | [1:40:45]

**Lawrence’s profile of John O’Neill**: [The Counter-Terrorist](https://www.newyorker.com/magazine/2002/01/14/the-counter-terrorist) | Lawrence Wright, *The New Yorker* (January 6, 2002) | [1:41:00]

**Book John O’Neill had in his FBI office**: [The Tulip: The Story of a Flower That Has Made Men Mad](https://www.amazon.com/TheTulip/dp/B0092G9S1K/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) | by Anna Pavord (2000) | [1:41:45]

**Lawrence’s article about Ayman al-Zawahiri**: [The Man Behind bin Laden: How an Egyptian doctor became a master of terror](https://www.newyorker.com/magazine/2002/09/16/the-man-behind-bin-laden) | Lawrence Wright, *The New Yorker* (September 8, 2002) | [2:08:00]

**ADDITIONAL RESOURCES:**

**Profile of Sayyid Qutb**: [A Lesson In Hate: How an Egyptian student came to study 1950s America and left determined to wage holy war](https://www.smithsonianmag.com/history/a-lesson-in-hate-109822568/) | David Von Drehle, *Smithsonian Magazine* (February 2006)

***New Yorker*** **profile of Osama bin Laden**: [The Outlaw](https://archives.newyorker.com/?i=2011-05-16#folio=088) | Steve Coll, *The New Yorker* (May 16, 2011)

**Article about the first decade after 9/11**: [Coming Apart](https://www.newyorker.com/reporting/2011/09/12/110912fa_fact_packer) | George Packer, *The New Yorker* (September 11, 2011)

***New Yorker*** **reflection on the legacy of 9/11**: [The Continuing Legacy of 9/11](https://www.newyorker.com/news/news-desk/the-continuing-legacy-of-911) | Caroline Lester, *The New Yorker* (September 11, 2019)

**Article about recent threats to Ali Soufan**: [Is the Saudi Government Plotting Against Another U.S.-Based Critic?](https://www.newyorker.com/news/news-desk/is-the-saudi-government-plotting-against-another-us-based-critic) | Dexter Filkins, *The New Yorker* (July 16, 2020)

§

## People Mentioned

- [Osama bin Laden](https://en.wikipedia.org/wiki/Osama_bin_Laden) [Intro, 21:45, 56:15, 1:00:15, 1:03:07, 1:03:45, 1:05:00, 1:52:15]
  - A founding member and the leader of al-Qaeda, he was involved in a variety of Islamist extremist activities throughout his life. In 1979, he began fundraising for the Afghan *mujahideen* fighting to expel Soviet invaders from their country. He spent a good portion of his life in Sudan where his views became increasingly extreme and anti-American, leading him to found al-Qaeda as a training base for global terrorist operations. He planned and trained operatives to carry out attacks on two U.S. embassies in East Africa, the USS *Cole*, and the 9/11 hijackings. He escaped into Pakistan following the U.S. invasion of Afghanistan in 2001 and was killed by American special forces in 2011. He claimed that the United States and its allies were the true source of anti-Muslim sentiment
- [Ayman al-Zawahiri](https://en.wikipedia.org/wiki/Ayman_al-Zawahiri) [Intro, 27:15, 35:30, 38:00, 40:15, 48:00, 53:00, 2:08:00, 2:10:30]
  - Egyptian doctor and Islamist extremist considered the ideological mind behind al-Qaeda who became the group’s leader after bin Laden’s death. He was imprisoned following in his involvement in the assassination of Egypt’s President. He was a founding member of al-Qaeda while living in Sudan, though he remained focused on running al-Jihad until the two organizations merged in the late 1990s
- [Denzel Washington](https://en.wikipedia.org/wiki/Denzel_Washington) [5:00]
- [Bruce Willis](https://en.wikipedia.org/wiki/Bruce_Willis) [5:00]
- [Annette Bening](https://en.wikipedia.org/wiki/Annette_Bening) [5:00]
- [David Remnick](https://en.wikipedia.org/wiki/David_Remnick) [15:45, 16:30]
- [Jeff Toobin](https://en.wikipedia.org/wiki/Jeffrey_Toobin) [16:15]
- [Jeff Goldberg](https://en.wikipedia.org/wiki/Jeffrey_Goldberg) [16:15]
- [Jane Mayer](https://en.wikipedia.org/wiki/Jane_Mayer) [16:15]
- [Kirk Kjeldsen](https://www.goodreads.com/author/show/7112700.Kirk_Kjeldsen) [16:45, 17:52, 18:15, 19:15]
- [Thomas Friedman](https://en.wikipedia.org/wiki/Thomas_Friedman) [22:15]
- [Sayyid Qutb](https://en.wikipedia.org/wiki/Sayyid_Qutb) [22:45, 23:30, 24:15, 25:30, 34:30, 35:30, 37:15, 1:04:30]
  - Egyptian teacher who viewed the United States as morally decadent and sought to Islamize Egyptian society as a way to shield it against the corrupting influence of Western values. He was executed for conspiring to assassinate the President of Egypt and viewed himself as a martyr for Islam. His writings and ideas became a significant inspiration to later Islamists, most notably al-Zawahiri and bin Laden
- [Gamal Nasser](https://en.wikipedia.org/wiki/Gamal_Abdel_Nasser) [23:15, 25:30, 27:45, 28:30, 30:00, 31:30, 34:00, 36:30]
  - Leader of the 1952 Egyptian revolution; fiery nationalist who transformed politics in the Arab world. He and Sayyid Qutb had radically differing views on the future of Egyp, a difference that eventually led Nasser to have Qutb executed in 1966
- [Anwar Sadat](https://en.wikipedia.org/wiki/Anwar_Sadat) [28:15, 33:30, 34:00, 34:30, 36:30, 40:15, 41:45, 43:30, 47:45, 48:30, 49:15]
  - Former president of Egypt who was assassinated by al-Jihad in 1981
- [Prophet Muhammad](https://en.wikipedia.org/wiki/Muhammad) [38:30, 1:01:30, 1:18:45]
- [Hosni Mubarak](https://en.wikipedia.org/wiki/Hosni_Mubarak) [39:30, 50:45, 1:20:45, 1:21:45]
- [Mohammad Reza Pahlavi](https://en.wikipedia.org/wiki/Mohammad_Reza_Pahlavi) (Shah of Iran) [44:45]
- [Shaima Abdel-Halim](https://www.deseret.com/1993/11/26/19078500/egyptian-mourners-decry-terrorist-acts) [52:30, 2:17:00]
- [Zbigniew Brzezinski](https://en.wikipedia.org/wiki/Zbigniew_Brzezinski) [55:30]
- [Jimmy Carter](https://en.wikipedia.org/wiki/Jimmy_Carter) [55:30]
- [Mohammad bin Laden](https://en.wikipedia.org/wiki/Mohammed_bin_Awad_bin_Laden) [56:30, 57:30, 58:45, 59:45, 1:00:45, 1:02:45, 1:06:45, 1:14:45]
  - The father of Osama bin Laden, Mohammed bin Laden founded his own construction company that became a favorite of the Saudi royal family and was commissioned to build palaces, major roads, and renovate Islam’s two holiest mosques. He was famous, extremely wealthy, and had a close relationship with the Saudi royal family
- [King Abdulaziz](https://en.wikipedia.org/wiki/Abdulaziz_of_Saudi_Arabia) [57:30]
- [President Roosevelt](https://en.wikipedia.org/wiki/Franklin_D._Roosevelt) [57:45]
- [King Faisal](https://en.wikipedia.org/wiki/Faisal_of_Saudi_Arabia) [58:30]
- [al-Assad family](https://en.wikipedia.org/wiki/Al-Assad_family) (including [Hafez al-Assad](https://en.wikipedia.org/wiki/Hafez_al-Assad) and [Bashar al-Assad](https://en.wikipedia.org/wiki/Bashar_al-Assad)) [1:00:30]
- [Abdullah Azzam](https://en.wikipedia.org/wiki/Abdullah_Yusuf_Azzam) [1:05:30]
  - Charismatic Palestinian cleric whose *fatwa* summoning Muslims to repel the Soviet invasion of Afghanistan began the Arab involvement in that war. He was assassinated by unknown parties on November 24, 1989
- [Hamid Gul](https://en.wikipedia.org/wiki/Hamid_Gul) [1:07:45]
- [Mohammed Omar](https://en.wikipedia.org/wiki/Mohammed_Omar) [1:09:30]
  - Mullah Omar is the founding leader of the Taliban. Though initially fearing that bin Laden’s presence in Afghanistan would make the Taliban the target of U.S. military strikes, he refused to turn bin Laden or his followers over to the United States or its allies
- [Mohammed Jamal Khalifa](https://en.wikipedia.org/wiki/Mohammed_Jamal_Khalifa) [1:12:30]
- [Saddam Hussein](https://en.wikipedia.org/wiki/Saddam_Hussein) [1:15:30]
- [Prince Turki Al-Faisal](https://en.wikipedia.org/wiki/Turki_bin_Faisal_Al_Saud) [1:16:45, 2:00:00, 2:37:00]
  - A member of the Saudi royal family and the head of Saudi intelligence, he initially worked with Osama bin Laden to channel money to the Afghan *mujahideen* but eventually came to consider bin Laden a violent threat and sought to control his activities
- [John F. Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy) [1:32:15]
- [Mohammed Loay Bayazid](https://en.wikipedia.org/wiki/Mohammed_Loay_Bayazid) [1:34:30, 1:35:30, 1:36:15]
- [Michael Scheuer](https://en.wikipedia.org/wiki/Michael_Scheuer) [1:37:45, 1:38:15, 1:39:30, 1:52:15, 2:03:15, 2:04:00]
  - Controversial CIA agent who opened Alec Station in 1996 and ran it until he was relieved of duty in 1999; frequently clashed with John O’Neill
- [John P. O’Neill](https://en.wikipedia.org/wiki/John_P._O%27Neill) [1:39:30, 1:41:00, 1:44:45, 1:52:15, 2:07:00, 2:22:15, 2:23:45, 2:24:15, 2:25:45, 2:26:30, 2:27:15]
  - An FBI agent who was head of the Bureau’s counterterrorism efforts in the years leading up to 9/11. At the time, O’Neill was one of the few U.S. officials who understood the true threat posed by terrorist groups like al-Qaeda but, due in part to his polarizing personality, he was routinely stymied in his efforts to lead more thorough investigations following the embassy bombings and the USS *Cole* attack. Shortly before 9/11, O’Neill became the chief of security at the World Trade Center in New York City and was killed in the 9/11 attack
- [Ali Soufan](https://en.wikipedia.org/wiki/Ali_Soufan) [1:44:15, 2:01:15, 2:03:00, 2:05:45, 2:42:30, 2:46:30, 2:47:30]
  - A Lebanese-born FBI agent and one the few agents who spoke Arabic prior to 9/11, he became a major asset to John O’Neill’s counterterrorism effort and led the investigations of the bombings of the East African embassies and the USS *Cole*. He was the first person to definitively link al-Qaeda to the 9/11 attacks
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) [1:49:45, 1:59:00, 2:19:00, 2:19:45, 2:32:15]
- [Al Gore](https://en.wikipedia.org/wiki/Al_Gore) [1:49:45]
- [Khalid al Mihdhar](https://en.wikipedia.org/wiki/Khalid_al-Mihdhar) [1:56:00, 1:57:30, 1:58:00, 2:00:30, 2:01:45]
  - Hijacker who died in the crash of American Airlines Flight 77 when it struck the Pentagon on September 11, 2001. Married to Hoda al-Hada, the daughter of the mujahid whose phone in Sanaa would prove to be so critical in understanding the scope of al-Qaeda
- [Nawaf al Hazmi](https://en.wikipedia.org/wiki/Nawaf_al-Hazmi) [1:56:00, 1:57:30, 1:58:00, 2:01:45]
  - 9/11 hijacker who died on American Airlines Flight 77, which crashed into the Pentagon
- [Omar al-Bayoumi](https://en.wikipedia.org/wiki/Omar_al-Bayoumi) [1:57:00, 1:57:45, 1:58:15, 2:38:00, 2:38:30]
- [Haifa Al Saud](https://en.wikipedia.org/wiki/Haifa_bint_Faisal_Al_Saud) [1:58:15, 1:59:00, 1:59:30]
- [Bandar Al Saud](https://en.wikipedia.org/wiki/Bandar_bin_Sultan_Al_Saud) [1:58:15, 1:59:00, 1:59:30]
- [Reema Al Saud](https://en.wikipedia.org/wiki/Reema_bint_Bandar_Al_Saud) [1:59:30]
- [Anwar al-Awlaki](https://en.wikipedia.org/wiki/Anwar_al-Awlaki) [1:58:45]
- [Hoda Al-Hada](https://www.historycommons.org/entity.jsp?entity=hoda_al-hada_1) [2:00:30, 2:00:45]
- [Edward Snowden](https://en.wikipedia.org/wiki/Edward_Snowden) [2:05:15]
- [Caroline Wright](https://www.carolinewrightart.com/about) [2:12:15]
- [Mohamed Atta](https://en.wikipedia.org/wiki/Mohamed_Atta) [2:14:00, 2:17:30]
  - Pilot of American Airlines Flight #11, which struck the World Trade Center
- [Richard (Dick) Clarke](https://en.wikipedia.org/wiki/Richard_A._Clarke) [2:18:45, 2:19:30, 2:25:30, 2:32:15, 2:40:30, 2:40:45, 2:41:30]
- [Barbara Bodine](https://en.wikipedia.org/wiki/Barbara_Bodine) [2:23:00, 2:23:30]
- [George Tenet](https://en.wikipedia.org/wiki/George_Tenet) [2:32:00, 2:33:30, 2:34:30]
- [Sean Hannity](https://en.wikipedia.org/wiki/Sean_Hannity) [2:41:15]
- [Nasser al-Bahri](https://en.wikipedia.org/wiki/Nasser_al-Bahri) (aka Abu Jandal) [2:43:30]
  - bin Laden’s chief bodyguard in Afghanistan who, after being captured by Yemeni authorities after the USS *Cole* bombing, became a significant source for the FBI

§

# TIMELINE OF EVENTS LEADING UP TO 9/11/01

*[source:* [*wikipedia*](https://en.wikipedia.org/wiki/Timeline_of_the_September_11_attacks)*]*

**1950:** [Sayyid Qutb](https://en.wikipedia.org/wiki/Sayyid_Qutb) returns to Egypt from a two-year visit from the United States and joins the [Muslim Brotherhood](https://en.wikipedia.org/wiki/Muslim_Brotherhood) due to his disgust towards Western culture

**1951–1965:** Qutb writes the book [*Fi Zilal al-Quran*](https://en.wikipedia.org/wiki/Fi_Zilal_al-Quran) while in prison for an assassination attempt against [Gamal Abdel Nasser](https://en.wikipedia.org/wiki/Gamal_Abdel_Nasser). The book calls for an Islamist revolution against secularism to establish a Middle Eastern theocracy rooted in [sharia law](https://en.wikipedia.org/wiki/Sharia). The book also concludes that any Muslims who support secularism are [*takfir*](https://en.wikipedia.org/wiki/Takfir). The book becomes highly influential for Islamic terrorists.

**1966:** Sayyid Qutb is executed in Egypt

**1976–1980:** Osama bin Laden is radicalized by Qutb while attending King Abdulaziz University

**1979:**

- The Soviet Union invades Afghanistan
- bin Laden travels to [Afghanistan](https://en.wikipedia.org/wiki/Democratic_Republic_of_Afghanistan) to assist the [Sunni Mujahideen](https://en.wikipedia.org/wiki/Islamic_Unity_of_Afghanistan_Mujahideen)
- The [Iran hostage crisis](https://en.wikipedia.org/wiki/Iran_hostage_crisis)
- [Grand Mosque seizure](https://en.wikipedia.org/wiki/Grand_Mosque_seizure)

**1981:** Bin Laden’s future deputy [Ayman al-Zawahiri](https://en.wikipedia.org/wiki/Ayman_al-Zawahiri), the leader of [Jama At al-Jihad](https://en.wikipedia.org/wiki/Jama_At_al-Jihad), is arrested for his role in the [assassination of Anwar Sadat](https://en.wikipedia.org/wiki/Assassination_of_Anwar_Sadat) and imprisoned for three years.

**1983:** The [1983 Beirut barracks bombings](https://en.wikipedia.org/wiki/1983_Beirut_barracks_bombings) targeting the [Multinational Force in Lebanon](https://en.wikipedia.org/wiki/Multinational_Force_in_Lebanon) during the [Lebanese Civil War](https://en.wikipedia.org/wiki/Lebanese_Civil_War) provides inspiration for Bin Laden.

**October 1984:** Bin Laden co-founds a network, the [Maktab al-Khidamat](https://en.wikipedia.org/wiki/Maktab_al-Khidamat) (MAK), with [Abdullah Yusuf Azzam](https://en.wikipedia.org/wiki/Abdullah_Yusuf_Azzam) in Afghanistan and Pakistan to recruit Muslims for the Afghan resistance.

**1986:** Bin Laden travels to Afghanistan to lead MAK forces in combat

**February 1987:** Al-Qaeda establishes its first [training camps](https://en.wikipedia.org/wiki/Afghan_training_camp) in Afghanistan

**May 25, 1987:** bin Laden withstands a Soviet attack during the [Battle of Jaji](https://en.wikipedia.org/wiki/Battle_of_Jaji), establishing his reputation in the Arab world

**December 8, 1987:** The [First Intifada](https://en.wikipedia.org/wiki/First_Intifada) begins in Palestine. Bin Laden expresses vocal support for the conflict, and begins to advocate in favor of [jihad](https://en.wikipedia.org/wiki/Jihad) against the West

**1988**: Osama bin Laden founds [al-Qaeda](https://en.wikipedia.org/wiki/Al-Qaeda)

**November 24, 1989:** Azzam is assassinated in a car bombing, allowing bin Laden to dominate al=Qaeda

**August 2, 1990:** [Ba’athist Iraq](https://en.wikipedia.org/wiki/Ba%27athist_Iraq) [invades](https://en.wikipedia.org/wiki/Invasion_of_Kuwait) and annexes Kuwait. Fearing an Iraqi threat to [Eastern Province](https://en.wikipedia.org/wiki/Eastern_Province,_Saudi_Arabia) oilfields, [King Fahd](https://en.wikipedia.org/wiki/Fahd_of_Saudi_Arabia) rapidly accepts American military assistance to the opposition of bin Laden

**September 1990:** Bin Laden makes an offer to [Sultan bin Abdulaziz Al Saud](https://en.wikipedia.org/wiki/Sultan_bin_Abdulaziz_Al_Saud) to defend [Saudi Arabia](https://en.wikipedia.org/wiki/Saudi_Arabia) from [Ba’athist Iraq](https://en.wikipedia.org/wiki/Ba%27athist_Iraq) with 100,000 fighters after the [Iraqi invasion of Kuwait](https://en.wikipedia.org/wiki/Invasion_of_Kuwait). He is turned down and becomes embittered by the intervention of non-Islamic troops from the [U.S.-led international coalition](https://en.wikipedia.org/wiki/Coalition_of_the_Gulf_War) in the [Gulf War](https://en.wikipedia.org/wiki/Gulf_War)

**November 5, 1990**: [El Sayyid Nosair](https://en.wikipedia.org/wiki/El_Sayyid_Nosair) commits the [assassination of Meir Kahane](https://en.wikipedia.org/wiki/Assassination_of_Meir_Kahane) at the [New York Marriott East Side](https://en.wikipedia.org/wiki/New_York_Marriott_East_Side), one of the first Islamist terrorist attacks in the United States. The FBI subsequently finds documents linking the attack to al-Qaeda, making it the organization’s first involvement in attacks in the United States

**April 1991:** Bin Laden moves to Sudan and begins expanding al-Qaeda

**1992:** Bin Laden begins to target U.S. military forces in the [Arabian Peninsula](https://en.wikipedia.org/wiki/Arabian_Peninsula) and the [Horn of Africa](https://en.wikipedia.org/wiki/Horn_of_Africa), as well as to consider alliances with [Shiite](https://en.wikipedia.org/wiki/Shia_Islam) [Iranian](https://en.wikipedia.org/wiki/Iran)-backed organizations such as [Hezbollah](https://en.wikipedia.org/wiki/Hezbollah).

**December 29, 1992:** Al-Qaeda attacks U.S. military forces for the first time in the [Yemen hotel bombings](https://en.wikipedia.org/wiki/1992_Yemen_hotel_bombings) in [Aden](https://en.wikipedia.org/wiki/Aden).

**February 26, 1993**: [Ramzi Yousef](https://en.wikipedia.org/wiki/Ramzi_Yousef) carries out the [1993 World Trade Center bombing](https://en.wikipedia.org/wiki/1993_World_Trade_Center_bombing)

**October 3-4, 1993:** 18 American servicemen are killed by al-Qaeda-trained forces in the [Battle of Mogadishu](https://en.wikipedia.org/wiki/Battle_of_Mogadishu_(1993))

**April 9, 1994:** bin Laden’s [Saudi citizenship](https://en.wikipedia.org/wiki/Saudi_Arabian_nationality_law) is revoked

**September 1994:** [Mohammed Omar](https://en.wikipedia.org/wiki/Mohammed_Omar) founds the [Taliban](https://en.wikipedia.org/wiki/Taliban) in Kandahar

**June 1995:** U.S. intelligence links al-Qaeda to an unsuccessful assassination attempt against Egyptian President [Hosni Mubarak](https://en.wikipedia.org/wiki/Hosni_Mubarak) in Addis Ababa, Ethiopia

**January 8, 1996:** As bin Laden makes bellicose statements regarding the United States and Saudi Arabia, [Michael Scheuer](https://en.wikipedia.org/wiki/Michael_Scheuer) creates a CIA unit, the [Bin Laden Issue Station](https://en.wikipedia.org/wiki/Bin_Laden_Issue_Station), to gather intelligence on bin Laden

**Mid-1996:** Khalid Sheikh Mohammed meets with Osama bin Laden and another al Qaeda leader, Mohamed Atef, to pitch several plans for attacking the U.S., including one that was a larger version of what would become the Sept. 11 attacks

**August 23, 1996:** bin Laden issues a [*fatwa*](https://en.wikipedia.org/wiki/Fatwa) declaring war on the United States, which is published in the [Arabic-language](https://en.wikipedia.org/wiki/Arabic) [newspaper](https://en.wikipedia.org/wiki/Newspaper) [*Al-Quds Al-Arabi*](https://en.wikipedia.org/wiki/Al-Quds_Al-Arabi) in [London](https://en.wikipedia.org/wiki/London). The FBI and the U.S. Attorney for the Southern District of New York open a criminal file on him under the charge of seditious conspiracy

**September 27, 1996**: The [Taliban](https://en.wikipedia.org/wiki/Taliban), a radical Islamic movement, [rises to power](https://en.wikipedia.org/wiki/Taliban%27s_rise_to_power#Emergence_in_Afghanistan) by [conquering Kabul](https://en.wikipedia.org/wiki/Battle_of_Kabul_(1992%E2%80%931996)) and declares the [Islamic Emirate of Afghanistan](https://en.wikipedia.org/wiki/Islamic_Emirate_of_Afghanistan)

**November 1996:** Informant [Jamal al-Fadl](https://en.wikipedia.org/wiki/Jamal_al-Fadl) first reveals the existence of al-Qaeda to the FBI.

**February 1998**: Bin Laden expands religious edict against US and allies by issuing a second *fatwa* calling on Muslims to join a jihad against Jews and Christians until the United States and Israel evacuate the Middle East

**1998**: 9/11 hijacker [Mohamed Atta](https://en.wikipedia.org/wiki/Mohamed_Atta) and associates are monitored by US and Germany in their Hamburg apartment.

**June 8, 1998:** A U.S. grand jury delivers a sealed indictment of bin Laden for “conspiracy to attack defense utilities of the United States”

**August 7, 1998**: Al-Qaeda [bombs the U.S. embassies](https://en.wikipedia.org/wiki/1998_U.S._embassy_bombings) in Kenya and Tanzania

**August 20, 1998**: [Operation Infinite Reach](https://en.wikipedia.org/wiki/Operation_Infinite_Reach), U.S. cruise missile strikes on Al-Qaeda training camp in Khost, Afghanistan, in retaliation of Al-Qaeda’s U.S. embassy bombings two weeks earlier

**1998**: An embassy bombing suspect claims an “extensive network of al-Qaeda sleeper agents” is planning a “big attack” inside the US

**Spring 1999:** bin Laden, Mohammed and Atef meet in Kandahar and develop an initial list of targets: the White House, the Pentagon, the Capitol and the World Trade Center

**Fall 1999:** Four recruits for the suicide mission begin training at the Mes Aynak camp in Afghanistan

**October 8, 1999:** Al-Qaeda is designated as a [Foreign Terrorist Organisation](https://en.wikipedia.org/wiki/Foreign_Terrorist_Organisation) by the U.S. State Department

**October 15, 1999:** The [United Nations Security Council](https://en.wikipedia.org/wiki/United_Nations_Security_Council) passes a resolution demanding that the Taliban extradite Bin Laden

**November–December 1999:** The [2000 millennium attack plots](https://en.wikipedia.org/wiki/2000_millennium_attack_plots) for bombings in Jordan and Los Angeles International Airport are discovered and prevented

**November-December 1999:** A separate group of four recruits travel to Afghanistan to begin training. They pledge allegiance to bin Laden and one of them, Mohamed Atta, is chosen as the leader of the group, which will become the core set of pilots in the plot

**Jan. 15, 2000:** Two of the four original recruits from the fall of 1999, Nawaf al Hazmi and Khalid al Mihdhar, become the first of the 9/11 operatives to reach the U.S.

**May-June 2000:** Atta and Shehhi arrive in the U.S. and attend flight classes

**Mid-August 2000:** Atta and al Shehhi pass the Private Pilot Airman test. Flight instructors describe them as aggressive and rude

**October 12, 2000**: The [USS *Cole*](https://en.wikipedia.org/wiki/USS_Cole_(DDG-67)) is bombed in Yemen by Al-Qaeda

**By year-end 2000:** The three Hamburg pilots (Atta, Shehhi and Jarrah) have begun to train on jet aircraft simulators

**April 2001:** Additional “muscle hijackers,” charged with storming the cockpits and controlling passengers while the pilot hijackers flew the planes, begin to arrive in the U.S.

**May-June 2001:** The pilot hijackers take surveillance flights and get more aviation training

**Mid-July 2001:** Atta determines that the best time to seize airliners was 10-15 minutes after takeoff, when the cockpit doors typically were opened for the first time. The hijackers planned to crash the aircraft if it appeared they would be unable to reach their targets. He planned to crash his plane on the streets of New York

**August 6, 2001:** President George W. Bush receives the [President’s Daily Brief](https://en.wikipedia.org/wiki/President%27s_Daily_Brief) [*Bin Ladin Determined To Strike in US*](https://en.wikipedia.org/wiki/Bin_Ladin_Determined_To_Strike_in_US) warning of an imminent attack on the United States by al-Qaeda.

**Aug. 26-Sept. 5, 2001:** The conspirators purchase their airline tickets over the Internet, by telephone and in person.

**Sept. 9-10, 2001:** The conspirators move into position near the airports from which they will launch their attacks

§

![](https://peterattiamd.com/wp-content/uploads/2021/09/1x1-wright-500x500.png)

##### Lawrence Wright

Lawrence Wright is an author, journalist, screenwriter, playwright, and staff writer for *The New Yorker*.  He is a member of the Council on Foreign Relations and the Society of American Historians.  He is the author of two novels, numerous plays, two screenplays (including the 1998 movie *The Siege*) and ten non-fiction books, including *The Looming Tower: Al-Qaeda and the Road to 9/11* (2006), which won the Pulitzer Prize for general nonfiction and numerous other awards. He graduated from Tulane University and the American University in Cairo.

Website: [lawrencewright.com](https://www.lawrencewright.com/)

Twitter: [@lawrence\_wright](https://twitter.com/lawrence_wright?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)