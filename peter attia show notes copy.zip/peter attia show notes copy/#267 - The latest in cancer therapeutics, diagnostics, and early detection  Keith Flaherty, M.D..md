# #267 ‒ The latest in cancer therapeutics, diagnostics, and early detection | Keith Flaherty, M.D.

**Source:** [https://peterattiamd.com/keithflaherty2/](https://peterattiamd.com/keithflaherty2/)

---

Keith Flaherty is the director of clinical research at the Massachusetts General Hospital Cancer Center and a [previous guest](https://peterattiamd.com/keithflaherty/) on The Drive. In this episode, Keith first delves into the statistics on cancer’s prevalence as we age, underscoring the significance of finding effective treatments and early detection methodologies. He touches on the history of cancer therapeutics and illuminates the notable enhancements in cancer therapy within the last decade that are setting the stage for a promising future. He goes into detail on the potential of immunotherapy and therapies that can combat cancer’s evasive tactics while explaining some of the existing challenges around specificity, cost, and scalability. Additionally, Keith highlights the significant leap in early detection methodologies, namely liquid biopsies, which have the potential not only to determine if a cancer is present in an early stage, but also identify the possible tissue of origin.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/keithflaherty2/the_Drive_public.png)

Play

#267 ‒ The latest in cancer therapeutics, diagnostics, and early detection | Keith Flaherty, M.D.

#267 ‒ The latest in cancer therapeutics, diagnostics, and early detection | Keith Flaherty, M.D.

1x15s30s

0:001:50:07

## We discuss:

- Keith’s interest and expertise in cancer [3:15];
- Cancer deaths by decade of life, and how cancer compares to other top causes of death [7:00];
- The relationship between hormones and cancer [12:00];
- The link between obesity and cancer [18:45];
- Current state of treatments for metastatic cancer and reasons for the lack of progress over the decades [22:30];
- The interplay between the immune system and cancer cells [32:00];
- Different ways cancer can suppress the immune response, and how immunotherapy can combat cancer’s evasive tactics [39:30];
- Elimination of a substantial portion of cancers through immune cell engineering faces challenges of specificity, cost, and scalability [52:15];
- Why TIL therapy isn’t always effective, and the necessity for multimodality therapy to address various aspects of the cancer microenvironment [1:01:00];
- The potential developments in cancer therapy over the next five years: T-cell activation, metabolic interventions, targeting tumor microenvironments, and more [1:06:30];
- The challenge of treating metastatic cancer underscores the importance of early detection to improve survivability [1:19:15];
- Liquid biopsies for early detection of cancer and determining the possible tissue of origin [1:24:45];
- Commercially available cancer screening tests [1:33:45];
- How to address the disparity in cancer care, and the exciting pace of progress for cancer detection and treatment [1:40:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Keith Flaherty was a previous guest ([episode #62](https://peterattiamd.com/keithflaherty/) back in July of 2019)
- Keith is currently the [Director of Clinical Research at the Massachusetts General Hospital Cancer Center](https://www.massgeneral.org/doctors/18371/keith-flaherty) and a [Professor of Medicine at Harvard Medical School](https://www.dfhcc.harvard.edu/insider/member-detail/member/keith-t-flaherty-md/), and he serves as the [editor-in-chief of Clinical Cancer Research](https://aacrjournals.org/clincancerres/pages/editors), a very prestigious journal
- His research focuses on understanding novel molecularly-targeted therapies in cancer
  - Within this field, his focus has been on the development of response and predictive biomarkers to define the mechanism of action and resistance of novel therapies, as well as to identify the optimal target populations
- In this episode, we start by looking at some of the statistics around the prevalence of cancer as we age
  - This really highlights the importance of this topic, and although we don’t spend a lot of time on it, because intuitively people understand that
  - It’s important for people to understand progress
- We then shift the conversation to discuss what has been done and what has not been done over the past several decades
  - There have been some very notable improvements in cancer therapy over the last 10 years, which we highlight
- From there, we shift our focus to looking at what is on the horizon and what the future of cancer therapeutics holds
  - Both in the short term and in the long term
  - Even within a five-year period, there are some incredibly exciting things that look to build on the successes of the past decade
- We talk about liquid biopsies, which play a very important role in early diagnosis of cancer
  - We talk about the state of the art today and what we think it’s going to be in the future
  - Peter has talked about this in the past ‒ liquid biopsies have the potential to diagnose cancer from a simple vial of blood
  - Liquid biopsies can not only determine if a cancer is present in an early stage, but also identify the possible tissue of origin
- A lot has changed since Keith and Peter initially spoke over four years ago
- For Peter, this conversation was illuminating, and it certainly won’t disappoint those of you who are interested in cancer

## Keith’s interest and expertise in cancer [3:15]

**A lot has happened in the past four years**

- In **therapeutic development**, maybe you could have said four years ago that some of the things that have played out would have played out
- But on the **diagnostic side**, Keith didn’t quite have the crystal ball vision as to how things would develop there
- Those two areas are tightly related in oncology

**Give folks a short background, a little bit about what you’re doing and why you are in a great position to talk about the field of cancer** [4:15]

- Keith is a medical oncologist whose been in the field for 23 years
- The first translation of molecular insights (specifically genetic insights into cancer biology) really became therapy 23 years ago
  - That’s when [Imatinib (or Gleevec)](https://en.wikipedia.org/wiki/Imatinib) was first used in patients and was a revolutionary moment
  - Keith’s career started right then and there as a medical oncologist
- His focus has been trying to translate science to medicine in very much that way, taking insights in terms of the genetic makeup (like the mutational architecture of cancers) and trying to translate that understanding into therapy
- Like anybody in the academic medical world and oncology, he focused on specific cancer types ‒ melanoma and kidney cancer
  - He chose both of those because of the molecular insights that existed at the time felt like they were beginning to be ripe for translation
- Keith did that work for about a decade at University of Pennsylvania
- Then he moved to Mass General to build a clinical program focused on therapeutic development much more broadly across cancer
  - Part of the Harvard Medical School umbrella
- He built a translational research group surrounding therapeutic development on this interplay between therapeutics and molecular understanding and diagnostics
  - It’s what he refers to as, “*bedside-to-bench translational research*”
  - The goal is to understand mechanisms of action and mechanisms of resistance
    - In other words, when drugs work, why?
    - And if they don’t work, why not?
    - Then use those insights to try to accelerate or drive the whole process forward
- Over the past 10 years, he’s co-founded a handful of biotech companies
  - [Loxo Oncology](https://www.loxooncology.com/) being the first 10 years ago, and that was acquired four years ago
  - [Scorpion Therapeutics](https://www.scorpiontx.com/) being the most recent, where he sits in the offices of Scorpion Therapeutics
- Through those channels, it’s his job to keep a steady eye on new therapeutic concepts that could be ready for primetime and then trying to translate his understanding into tools that we can actually use for real patients (such as diagnostics)

## Cancer deaths by decade of life, and how cancer compares to other top causes of death [7:00]

- Peter points out, “*There’s something about cancer that’s particularly damning, which is when you look at the other two chronic diseases that are huge killers, which are cardiovascular disease and neurodegenerative disease, they increase in their severity exponentially as you age. They don’t really become a dominant source of mortality until people are in the seventh and eighth decade of life, and that’s not true for cancer.*”
- Our analysts put together the table below of the % people that die from cancer in 10-year increments
  - What’s interesting is that number peaks in the middle
  - At age 25-34, its 6%
  - At age 35-44, it’s 13% and that’s a staggering number for people so young
  - At age 45-54, it’s 23%
  - At age 55-64, it’s 30%
  - At age 65-74, it’s 31%
  - Then, paradoxically, it begins to come down because those other diseases are taking off

![](https://peterattiamd.com/wp-content/uploads/2023/08/f1-keithflaherty.png)

**Figure 1. Percentage of people that die from cancer in 10-year increments**.

- Another way to look at this is, *where does cancer rank in cause of death for all causes by decade*?
  - If you go in those same buckets (starting at 25 to 34), it goes from third, third, second, first, first, second, third
  - In other words, it’s always first to third

***There is no other disease that always ranks in the top three cause of death for every age ‒ it’s cancer***

- Cancer is the second leading cause of death overall
- There’s nobody who’s listening to this podcast whose life has not been affected by cancer

**Keith breaks down this data a little bit**

- Think about pediatric cancers, there’s almost nothing more jarring and seemingly unjust than a child being diagnosed with cancer
- For children, cancer is quite rare, but it occupies an enormous amount of mindshare
- As you go into the decades, it’s interesting to reflect on the **cancer types** that kind of lead the way
- For people in their 20’s, 30’s, and 40’s: brain tumors, leukemia, melanoma (the most deadly form of skin cancer and one of the cancer types Keith has been focused on in his career long) lead the way
  - And there’s some interesting implications there in terms of what causes those cancers in people vulnerable to them
- For [carcinogen](https://en.wikipedia.org/wiki/Carcinogen)-induced cancers, those really start to jump up in later decades
  - Melanoma is an example, ultraviolet light is a carcinogen for skin cancer
  - Smoking-related cancers are another example
    - Lung cancer leads the way, but there’s a smoking footprint for a bunch of other cancer types that people don’t think about so much: head and neck cancer, bladder cancer
    - Smoking is not the sole cause of these other cancers but it’s a big contributor
    - These smoking-related cancers require exposure and a bit of time to accumulate
- Of the big four cancers (breast cancer, prostate cancer, lung cancer, and colorectal cancer), breast cancer and prostate cancer are not related to ultraviolet light or smoking so much, but there is an interplay between hormone receptors where they are co-opted in a way
- For cardiovascular disease and neurodegenerative disease, Keith would argue there’s something at play there that is similar to these hormone-driven cancers, which are very age related
- *Breast cancer* and *prostate cancer* really pick up in those later decades of age

***It’s interesting to reflect on the how and why different cancers feature in those different decades of age, and that has tons of ramifications in terms of how we think about screening***

**The big 4 cancers**

- Lung cancer is #1, breast and prostate cancer are #2, and colorectal cancer is #4
- If you add a 5th (pancreatic cancer), you now account for >50% of all cancer deaths

> “*At the end of the day, just five cancers account for a little over half of all cancer death in the United States*”‒ Peter Attia

## The relationship between hormones and cancer [12:00]

- When it comes to breast and prostate cancer, we have a clear understanding of the role of hormones and yet the implicated hormones are at their lowest levels when these cancers typically come on board
  - There is the relationship between [testosterone](https://en.wikipedia.org/wiki/Testosterone) and [dihydrotestosterone (DHT)](https://en.wikipedia.org/wiki/Dihydrotestosterone) and prostate cancer, and yet, when men have their highest levels of these hormones (in their 20s, 30’s, and even in their 40s), that cancer is never to be found
  - Cancer shows up only when those hormones are greatly diminished
  - The same is true with breast cancer, but it’s not necessarily hitting at the peak level of estrogen in women (there’s more complexity to it)
  - Peter notes, “*It speaks to just how much is going on beyond the surface and the first order of thinking*”
- If you look at cancers other than breast and prostate cancer, where we’ve really gone the deepest in our understanding of what causes them, it’s been around the [growth factor receptor](https://en.wikipedia.org/wiki/Growth_factor_receptor) and signaling downstream of growth factor receptors
  - So the action has been on the surface of cancer cells and then internally
- Keith explains the point that Peter just made about hormone receptors is that basically cancer cells “figure out” how to become independent of the actual growth factors themselves
  - Through genetic mutation (or alteration), they “turn on” these surface receptors or the immediate downstream signaling molecules from those surface receptors
    - This is the hotspot of where most cancers (not all) actually get their oncogenic drive (the mutations that drive cancer)

***Thinking about prostate cancer and breast cancer occuring when the levels of circulating hormones are low, what has happened is cancer cells have wired themselves in a way to be independent of those ligands (those hormones), but still using the receptors and their downstream consequences to drive cancer***

**Peter wonders if there’s a parallel between the observation that a prostate cancer that develops in the presence of low testosterone is a worse prostate cancer**

- Peter recalls a paper in the *New England Journal of Medicine*, probably 15 years ago, that demonstrated a worse outcome of prostate cancer with lower testosterone levels at the time of diagnosis
  - This is very counterintuitive as everybody thinks testosterone is causing prostate cancer
  - He wouldn’t interpret that to mean testosterone has zero role in prostate cancer or that high testosterone is protective
- Instead, Peter would argue, “*Cancers that grow without the hormone are worse*”
  - The parallel for breast cancer is that ER/PR negative breast cancers are worse than [ER/PR positive breast cancers](https://www.cancer.org/cancer/types/breast-cancer/understanding-a-breast-cancer-diagnosis/breast-cancer-hormone-receptor-status.html)
    - The latter are typically hormone-sensitive (or driven) cancers
  - The cancers that initiate or proliferate without their respective hormones tend to be harder to combat
- Keith agrees, cancers that have figured out how to proliferate without their respective hormones…
  - He likes to anthropomorphize cancer; it’s the easiest mindset for thinking about how cancers solve the problems they need to some to become cancer
- For example, [triple-negative breast cancer](https://en.wikipedia.org/wiki/Triple-negative_breast_cancer)
  - This cancer lacks the hormone receptors and [HER2](https://en.wikipedia.org/wiki/HER2) (a well-established growth factor on normal cells and cancer cells)
  - In breast cancer, their genetic makeup is still dependent on the same sort of cellular processes
    - They just do it through a variety of means and ones that become very challenging to directly target
- The treatability of these cancers (let’s stick with breast cancer) is far greater because we have drugs for more targets
- We’ve had drugs for intercepting those hormone receptors (inside the cells) for a long time
  - Serious advances have been made by applying new chemistry strategies to develop better versions of these drugs

**In cancer types, we are witnessing the distribution of “haves and have-nots”**

- There are patients whose prognosis to start with is better and whose therapy advances are really accelerating
  - Hormone receptor-positive breast cancer is a good example of this, where additional drugs have been successfully developed as combinations since we spoke four years ago
  - The outcomes of those patients continue to be distanced from cancers like pancreatic cancer
- In the case of pancreatic cancer, the case fatality rate is far higher than other cancers
  - It doesn’t even come close in terms of number of cases diagnosed to breast, prostate, or lung cancer
  - But the mortality per case diagnosed (the likelihood that it’s going to be fatal) is inordinately high
  - That’s a prognostic issue
  - It’s an aggressive cancer
- But our therapy advances have been quite minimal for pancreatic cancer
  - All we have are the classical chemotherapy drugs of the pre-2000 era, and they only have a modest impact
- Pancreatic cancer remains in the “have-not” end of the spectrum

## The link between obesity and cancer [18:45]

**Obesity is the second most prevalent environmental trigger of cancer after smoking**

- We can debate whether it is obesity, per se (Peter doesn’t think it is)
- He thinks it’s the inflammation and growth factors that come with obesity
  - Namely [insulin](https://www.mdanderson.org/cancerwise/sugar--insulin-resistance-and-cancer--what-is-the-link.h00-159461634.html#:~:text=If%20you%20are%20insulin%20resistant,to%2013%20types%20of%20cancer.), [IGF-1](https://www.ceu.ox.ac.uk/news/study-of-almost-400-000-confirms-that-higher-blood-levels-of-igf-1-are-a-risk-factor-for-several-types-of-cancer), and the [inflammation](https://www.cancer.gov/news-events/cancer-currents-blog/2022/reducing-inflammation-to-treat-cancer#:~:text=In%20a%20normal%20inflammatory%20response,that%20could%20lead%20to%20cancer.) that is part and parcel with that
  - He assumes the inflammation impairs the immune system
- A lot of cancers are related to obesity
  - Of the top five, breast, prostate, pancreatic, and colorectal cancers are clearly linked to obesity
  - There are also 25-27 other cancers that have a pretty tight relationship to obestity
- Obesity is not only something that is increasing in societal prevalence, but you might argue that it also takes a while to kick in
  - Keith is glad Peter brought up that point
- It’s easy to think about [ultraviolet radiation](https://www.cancerresearchuk.org/about-cancer/causes-of-cancer/sun-uv-and-cancer/how-does-the-sun-and-uv-cause-cancer#:~:text=How%20can%20UV%20cause%20skin,can%20lead%20to%20skin%20cancer.) and skin cancer; it’s easy to think about smoking
  - Now that we can sequence the genome of a population of cancer cells, we can see the damage those types of carcinogens induce
- Obesity is unquestionably the 3rd highest-ranking “carcinogen,” but the way it acts is more complicated, it’s systemic
- Keith latches onto the literature Peter alluded to regarding insulin signaling and the body’s metabolic response to obesity
  - When someone is obese, there are metabolic adaptations the body attempts to make
  - It is analogous to the hormone-receptor-driven cancer in breast and prostate cancer
  - It’s a different phenomenon, but [insulin-like growth factor (IGF)](https://en.wikipedia.org/wiki/Insulin-like_growth_factor) and its receptors are ubiquitous on all cell types
    - And certainly on cancer cell types for which there is epidemiologic evidence that those cancers are more common in the obese population
- Laboratory data suggests that the signaling that happens through insulin signaling in cells is tightly tied to the growth factor receptor pathway
  - It is ultimately part of that same biology
  - There’s a pathway that connects those surface receptors into cells that then regulate how the mitochondria act as the power stations inside of cells to the so-called [PI3-kinase pathway](https://en.wikipedia.org/wiki/PI3K/AKT/mTOR_pathway), well described as being a driver in cancer
    - That pathway is basically being chronically driven in that setting of high insulin levels, high insulin growth factor circulating levels
- The question of, “*Exactly what threshold level poses risk, and over what period of time?*”
  - Those dots have not been fully connected
  - But the epidemiology is undeniable
  - Laboratory data supporting that connection is also undeniable
- There is something about that pushing that is driving cancer, and it’s like chronic inflammation which is another direct causal factor for certain cancers
  - Cancer can arise in an organ site or tissue site where there’s chronic inflammation

> “*They [obesity and inflammation] keep whipping the horse, if you will, in a way, and cells will ultimately, through genetic alteration, still basically respond to that environmental stress, and cancers ensue.*”‒ Keith Flaherty

## Current state of treatments for metastatic cancer and reasons for the lack of progress over the decades [22:30]

**Peter’s immunotherapy rotation in medical school**

- Peter remembers his last year in medical school (January of 2000), he moved across the country from California to Bethesda to go and spend four months rotating on the immunotherapy service with [Steve Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) ([episode #177](https://peterattiamd.com/stevenrosenberg/))
- This was the opportunity and dream of a lifetime
- Peter had read Steve’s book, [*The Transformed Cell*](https://www.amazon.com/Transformed-Cell-Stephen-Rosenberg/dp/0399137491/ref=sr_1_1?crid=3DVRTQ2ITZDDX&keywords=the+transformed+cell&qid=1690381087&sprefix=the+transformed+cell%2Caps%2C100&sr=8-1), many, many times as a medical student and wanted to go and learn what he could
- He was there from January until April of that year, and it was literally one of the most joyful examples of pure bliss
- Peter found a friend he could stay with in Bethesda, but it turned out, in the four months he was there, he was probably only there eight times
  - He didn’t leave the hospital
  - He literally had a cot where he slept
  - He wanted to be as close to the lab and clinic as possible
- Peter will never forget one of the most insane things Steve said the first week he was there; he said, “*Looking back over the past 30 years, we have basically made no progress in the long-term management of metastatic epithelial cancers.*”
  - Translating that into English, if you had a solid organ tumor that had spread to a distant site in 1970, the chance that you were going to be alive in 10 years was the same in the year 2000, and that was basically zero
- There were a couple of small exceptions, and these happen to be the cancers that both Keith and Steve are interested in
  - About 10-15% of patients could achieve a solid durable remission at the time to high-dose [interleukin-2](https://en.wikipedia.org/wiki/Interleukin_2#Medical_use), but that was not the case for any other [epithelial tumor](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/epithelial-carcinoma)
  - There was still absolutely no sense of why that wasn’t the case for the other 90% of patients who had metastatic [renal cell carcinoma](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/renal-cell-carcinoma) and [melanoma](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/melanoma)

**How are we doing today, 23 years later?**

*Do you have a sense of how much bigger the 10-year survival number is?*

- Peter recalls it was 0% 10-year survival for solid organ tumor in 1970
- Let’s call it 1% survival in 2000 (the few cases of RCC [renal cell carcinoma] and melanoma [who survived])
- We don’t have the 10-year data, but if you track 5-year and 3-year outcomes, you’d like to think they’re going to get to 20%
- Keith clarifies the term [metastatic](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/metastasis): clinically overt, detectable metastatic cancer means that you’re picking it up radiographically (or clinically)
- When cancers are found earlier, at a localized site, it’s very, very common that cancers will have spread to regional lymph nodes (through lymphatic channels to the closest lymph node basin, wherever that may be)
  - This is not true for all cancers, but certainly true for the common epithelial cancers

***The point to emphasize is that spread to lymph nodes is properly called metastatic (it’s a jargon term), but we don’t think about that as being metastatic***

**Peter’s analogy** ‒ when people leave a city in an airport and go to another airport (in another city), we don’t call it spread until they leave the airport and go to the city proper, even though they’ve clearly demonstrated the capacity to go from their house to the airport and hop on an airplane; once they’ve stepped foot out of customs and collect their bags, now we can say they’ve really spread

- Keith also points out, “*It’s feasible to surgically remove regional lymph nodes along with the primary site of disease in the vast majority of cases*.”
  - Historical standard practice of surgical resection includes removing regional lymph nodes, and we think of surgeries that can encompass all of that as basically being one treatment
    - Those patients are not thought have metastatic disease
- We only know that some of those people actually have metastatic disease at the time of surgery by following them 5-10 years
  - Even not that long, only 1-3 years is enough for most aggressive cancers
- You do the surgery, you clean the slate, you do various kinds of scans and you see nothing in a substantial fraction of those patients
  - Depending on the cancer type and the features of their primary tumor and lymph node involvement
- Let’s say 30-50% will manifest with metastatic disease over several years of follow-up
  - They had metastasis before the surgery was ever done
  - As Peter said, the traveler (cancer cells) left the airport and lodged in a distant site
  - We just didn’t have the methods to find it
- This is where some huge advances have been made in blood-based detection of metastasis
  - We’re not perfectly good at that now
  - There have been substantial improvements in the technology for detecting [circulating tumor DNA](https://en.wikipedia.org/wiki/Circulating_tumor_DNA) where people have only **microscopic metastatic disease** (we’ll come back to this term)
- For **evident overt metastatic disease**, we’re getting to the 15-20% [10-year survival] (10% on an absolute scale)
  - This is when you can see it on scans or clinically witness it

***Half of that advance has come from one therapeutic modality:*** [***PD-1 antibody-based immunotherapy***](https://en.wikipedia.org/wiki/PD-1_and_PD-L1_inhibitors#PD-1)

- It’s astounding that a single approach has accounted for half of that number

***The other half of that advance has come from a repertoire of so-called molecularly-targeted therapies that intercept genetically altered drivers (alluded to earlier, surface receptors and their downstream signaling molecules)***

- Those individual drugs have picked off as small as 0.2% of the cancer population (in the rarest instance) up to a couple few percent
- But you add them all up, and those have produced long-term survivors now by historical standards (that 10-year number)
  - It’s an astoundingly long survival by historical standards because metastatic cancer will prove fatal in nearly everybody untreated within that time frame

**Peter’s takeaway** ‒

- From 1970 to 2000, zero progress was made
- From 2000 to now, we’ve made a small dent in that
  - Half of that dent has been on the back of [Keytruda](https://en.wikipedia.org/wiki/Pembrolizumab) [a PD-1 inhibitor, antibody immunotherapy]

**How many drugs are in the other half of that?**

- We mentioned [Gleevec](https://en.wikipedia.org/wiki/Imatinib) earlier, that was probably the first
- There have been 52 FDA approvals against 19 unique mechanisms
  - There’s a lot of me-tooisms, and this is true in all therapeutics, not just oncology
  - There is some overlap in those 19 mechanisms, and if Keither were to really boil it down, we’re in the range of 10 truly unique molecular targets

**How Keytruda enables T cells to kill cancer [30:15]**

- The target of Keytruda is [PD-1](https://en.wikipedia.org/wiki/Programmed_cell_death_protein_1), and that’s a surface receptor on certain immune cells
  - In particular it’s on [CD8+ T lymphocytes](https://en.wikipedia.org/wiki/Cytotoxic_T_cell) that can kill tumors directly
  - But there are other immune cells that express PD-1 and that’s a “brake” on those immune cells
- The antibodies that block that brake are the so-called PD-1 antibodies
  - There are five of them that are FDA approved
  - [Keytruda (or pembrolizumab)](https://en.wikipedia.org/wiki/Pembrolizumab) is the dominant one that made it to market first and it’s also in the broadest number of cancer populations

**Is anti-CTLA-4 still being used or is that mostly used in melanoma?**

*What is the prevalence of its susceptibility versus that of PD-1?*

- [CTLA-4](https://en.wikipedia.org/wiki/CTLA-4) is another brake on immune cells (the same T cells)
- It was discovered before PD-1 as a target and therapy was advanced against it a little earlier than PD-1, but a much smaller percent of cancer patients get a benefit from that drug
- There is some evidence that it can act independently to exert its own benefit (maybe for 1%)
  - So PD-1 is really doing the heavy lifting for that 10% number of patients who get long-term benefit
- There are 4 cancers (and most would argue a 5th) where there is evidence that adding CTLA-4 to PD-1 is beneficial

## The interplay between the immune system and cancer cells [32:00]

- Peter did an entire podcast dedicated to that with Steve Rosenberg ([episode #177](https://peterattiamd.com/stevenrosenberg/)), and Keith discussed it briefly four years ago ([episode #62](https://peterattiamd.com/keithflaherty/))
- Peter points out, “*People don’t necessarily completely understand the nuances of the immune system, given that it’s played such an important role in cancer optimism over the past two decades, and given that it’s probably about to play more of an important role as we go forward, I think it’s worthwhile for the listener and viewer to understand how the immune system works with respect to cancer.*”
  - He doesn’t want people to be lost when we talk about [TIL](https://en.wikipedia.org/wiki/Tumor-infiltrating_lymphocytes) or [checkpoint inhibitors](https://en.wikipedia.org/wiki/Checkpoint_inhibitor)

> “*Unfortunately this is one of those moments in this podcast where you got to buckle your seatbelt up a little bit, but it pays dividends because you become a very educated consumer of how these drugs work.*”‒ Peter Attia

- Keith likes to start with the concept that the immune system needs to find levers that it can grab onto, as in differences, things that are fundamentally different from normal cells
  - Our immune system is trained in fetal development to do exactly that and only that
    - Except for the fact that we unfortunately hold on to self recognizing immune cells and those can cause autoimmune disease (which is not the topic of our conversation today)

**Consider what is different about cancer cells**

- We began to understand some time ago that a common feature of cancer cells is that they behave like they are sort of progenitors or precursors
  - In development, all mature cells in the body come from a stem cell of some sort and there’s different lineages and different types of stem cells, but ultimately you see cancers actually adopt sort of a biological behavior that’s like backing up in the developmental process
  - This is a consequence of the genetic alteration that Keith likes to refer to as a sort of “combination lock” ‒ genetic alterations that lead to cancers
- Developmental cells have surface proteins (aka surface markers) that are not expressed in fully mature tissues
  - And the immune system can see those; that’s well-documented
  - Steve Rosenberg’s early successes were identifying those immune cells that existed in people that could recognize those types of antigens
  - These are referred to as [cancer/testis antigens](https://en.wikipedia.org/wiki/Cancer/testis_antigens)
- There are also antigens we refer to as **lineage antigens**
  - Like surface markers that tag a certain cell type that the immune system can recognize even though we think of those as being more like self
  - But we see evidence that the immune system reacts to those and there are cell therapies that also take advantage of that

**The big discoveries of the recent several years have been that carcinogens cause mutations in genes**

- Genes first encoded RNA then proteins
- Mutations in genes alter the amino acid sequence of the protein and that can be recognized
- These are almost always intracellular proteins
- All cells have machinery that break down proteins as they age and will present a representative set of those broken-down protein fragments (or peptides) on the cell surface in the context of molecules we refer to as [major histocompatibility receptors (MHC)](https://en.wikipedia.org/wiki/Major_histocompatibility_complex)
  - The idea is they’re trying to show the “wares”, the inner contents of the cell to the immune system
  - [this is called [antigen presentation](https://en.wikipedia.org/wiki/Antigen_presentation)]
  - When there is a viral infection, you have infection inside the cell, and we think this is how how this machinery evolved in the first place [to identify cells infected with a virus]
  - If cells stop doing this [presenting antigens from inside the cell on MHC], then there is a branch of the immune system ([natural killer cells](https://en.wikipedia.org/wiki/Natural_killer_cell)) that will swoop in and kill those cells
- An [antigen](https://en.wikipedia.org/wiki/Antigen) is a protein fragment that the immune system can see as “different”

**Peter’s analogy to understand antigen presentation**:

- You have a row of homes and each person in their home is responsible for demonstrating the contents of their home
  - They reach inside and they pull out various items from their home and they leave them on the curb
- The military is coming down the street, inspecting the contents on the curb, and they’re just making sure that it’s all stuff that we’ve pre-agreed is safe
  - They don’t know the entire repertoire of what could be presented, but they have a very clear list of what is acceptable and they’re basically just identifying anything that is not on the “acceptable list”
- If anything shows up and it’s not on the “acceptable list”, the house is destroyed
- Furthermore, if you leave nothing on your curb (either because you’re too incompetent or you’re nefarious and you’re trying to hide what’s in your home), there’s another branch of the military that comes along and just blows up your house
  - So failing to play the game results in a loss of home

***This [antigen presentation] is the beginning***

**It’s important to recognize the core principle that cancer is a “genetic disease”**

- Mutations happen in key genes that disable the cell’s ability to repair DNA damage
- For example, commonly mutations activate some of those surface receptors or downstream signaling molecules discussed earlier
  - Those mutations can be seen as different, and they begin to increase the “toolbox” of “handles” that the immune system can latch onto

***If cancers are witnessed by immune cells as having a difference early, they can be eliminated***

- There’s lots of evidence for this
- Indirect negative evidence: people who have profoundly compromised immune systems will pop up with cancers
  - If you give people seriously high dose immunosuppressive medication (for various other medical conditions), you will see cancers just sprout up quickly and then certainly over time as well
- There is an inordinate amount of evidence in support of this **immune surveillance** concept
  - That it is keeping proto cancers down, if not outright eliminating them
  - That it’s just part of life on planet earth in the cosmic storm with [UV radiation](https://en.wikipedia.org/wiki/Ultraviolet) as being one carcinogen
    - [Gamma radiation](https://en.wikipedia.org/wiki/Gamma_ray) coming through the atmosphere is also a cause of DNA damage
- We have to try to repair that damage inside of cells (again, using the anthropomorphic inside of a cell, inner workings here)
- But if the repair can’t happen, we have this other mechanism of immune surveillance basically to wipe it out

## Different ways cancer can suppress the immune response, and how immunotherapy can combat cancer’s evasive tactics [39:30]

> “*The reason why I wanted to spend enough words on this concept is that basically people have to understand that by the time they’re diagnosed with cancer, something’s gone wrong.*”‒ Keith Flaherty

- A diagnosis of cancer means that the system/ surveillance didn’t work to detect the forming cancer
  - It didn’t eliminate it

**“Brakes” on the immune system**

- For every process that activates the immune system in response to an infection there are “brakes” to stop immune responses
- Go with the idea that the primary function of the immune system (and how it evolved) is to fight infection
- Imagine having the flu forever:
  - Just dumping [cytokines (immune system hormones)](https://en.wikipedia.org/wiki/Cytokine) into the bloodstream
  - Cranking up body temperature
  - Consuming a ton of metabolic resources in fighting infection
  - Feeling bad as a consequence of all of this
  - “*You can’t do that indefinitely. You got to stop immune responses.*”
- There are a very elaborate set of mechanisms to stop immune responses

***Cancers have craftily figured out how to reach into the genetic code and co-op mechanisms that will impede immune system recognition and response ‒ this is the PD-1 story***

*PD-1 is the target of Keytruda*

- Cancers that are most responsive to Keytruda have figured out how to express on their surface the foot that presses on the brake, and that’s called [PD-L1 (programmed death-ligand 1)](https://en.wikipedia.org/wiki/PD-L1)
- PD-L1 reaches across to [PD-1](https://en.wikipedia.org/wiki/Programmed_cell_death_protein_1) on T cells and tells them to “*Shut down*”/ “*Mission accomplished, don’t need to do anything here*”
- So a lung cell (an alveolar lung cell) that ultimately becomes cancer is not supposed to express PD-L1 on its surface
  - It’s not supposed to be regulating the immune system; that’s not it’s natural job
- But a cancer that arises from that lung alveolar cell in many instances figures out how to express that protein

***Blocking the interaction of the “foot” with the “brake”, that’s magic***

> “*Now that’s just one mechanism, but as I said, it’s actually produced a bigger incremental benefit in the cancer population than any single mechanism we’ve ever discovered in all of cancer biology research and therapeutic development history.*”‒ Keith Flaherty

**There are other mechanisms by which the immune system can be suppressed**

- In fact, there are entire cell types in the immune system repertoire that have a dampening effect on immune system response and cancers can recruit them into their so-called microenvironment and create this very adverse environment for the T-cells (that could otherwise attack and kill)
  - It’s almost like assembling a “force field”
  - The cancerous cell is recruiting these suppressive immune cells
- Keith wants to make it clear what we’re up against, how complicated it is and adds, “*We’re super grateful to have had this kind of eureka moment with the success of PD-1 drugs, but the cancers have co-opted multiple mechanisms by which they defend themselves*.”

***To use this immunotherapy concept more broadly in cancer is going to require us to develop an understanding of which tricks are being pulled and target those very specificall***y

- We can’t disable people’s immune systems
- We need a fair amount of precision and figuring out the “sweet spot” in terms of what mechanisms cancers are using for this purpose

**Why immunotherapy’s potential was overlooked 20 years ago [43:15]**

- Peter recalls his podcast with [Steve](https://peterattiamd.com/stevenrosenberg/), “*The one that I was most blown away by… was that roughly 80% of epithelial tumors had novel neoantigens.*”
  - Let’s make sure people understand what that means and how shocking that is relative to where we were 20 years ago
- Peter’s time at NIH was such a formative part of his education and he can’t tell you how many people during residency interviews just laughed in his face and said, “*This immunotherapy stuff is nonsense. It’s totally irrelevant. What are you talking about, kid? You’re going to sell yourself to us as an interesting person that we should let into our program and you’re talking about that crap? It literally means nothing. Okay, it works on melanoma, who cares?*”

Peter Asks: *Why is the fact that 80% of epithelial cancers have novel neoantigens a totally staggering feature that, had people understood that 20 years ago, maybe more than just a handful of people would’ve found immunotherapy to be a very promising field?*

Keith breaks-down the biology of novel antigens:

- A fair number of mutations accumulate in a cell that’s going to become cancer
  - Never less than dozens in the most genetically simple cancers
  - Typically your into the hundreds and thousands
  - Not all of these mutations have a consequence to the point about these antigens
  - Some are in parts of the genome that don’t encode proteins
    - In which case, they’re never going to become antigens
- As mutations are translated into proteins and as those proteins age, they get broken up in the [proteasome](https://en.wikipedia.org/wiki/Proteasome) and presented in the context of these MHC molecules on the cell surface (discussed earlier)
  - But that’s done differently in each of us so that we don’t show our entire “wares”
    - We show a selected representation of them
- The MHC molecules, you inherit half of your set from your mother and half of your set from your father
- The MHC molecules have the ability to grab just certain protein fragments and present them
  - By “grab,” Keith means they’re actually loaded onto the MHC by cellular machinery that’s quite elegant
- The point is we have this repertoire of showing the inner contents [of the cell] and so only certain mutated proteins gets get translated into that

***Only certain mutated proteins/ altered proteins can actually be presented out of the very large number of mutations that actually exist***

- **Epithelial cancers include**: breast, colon, prostate, and lung cancer
  - It’s not leukemia, lymphoma, brain tumors, and melanoma
    - Melanoma comes from melanocytes, which are neural crest in origin and share features with brain tumors
- But it is astounding that you find evidence that mutated proteins are being presented in the vast majority of these common cancers
- We are born with this elaborate, very impressive repertoire of [T cell receptors](https://en.wikipedia.org/wiki/T-cell_receptor) that sit on the surface of T cells and can recognize exactly these altered proteins with just one amino acid substitution present in the peptide fragment
- To meet the definition of an antigen, you have to find in a human being that the immune system can see it in the context of it being presented on these MHC complexes
  - That is a kind of “lock and key” concept
  - It has to structurally work out that the protein fragment is being presented to the T cell receptor, but *not* the unmutated version
    - The difference has to be enough to tell the T cell “go kill”
- These exist and first began to be described about a decade ago
- At the time we were sequencing a ton of cancer genomes, and we began looking in retrospect as PD-1 and CTLA-4 were being clinically developed
  - We found that these tumors have a ton of these mutations, and they were the ones that were more likely to respond than other cancer types

***Ultraviolet radiation associated cancers have enormous amounts of mutations, oftentimes dozens of these mutated neoantigens, and that explains why the response rate is so high in those cancers***

- Smoking related cancers then account for just about all the rest of cancers where PD-1 has been efficacious
- We didn’t know this when PD-1 and CTLA-4 antibodies were first being developed

***It was simply this interplay where you can add one drug that blocks this “foot on the brake” and you unleash these preexisting T cells against these presented antigens***

***What else can we do with that information?***

- We can actually engineer immune cells to attack these things
  - To potentially overwhelm other ways that cancers try to protect themselves from the immune system ‒ this is what cell therapy of various kinds can do
- We’re still in the early days of elaborating this understanding that, “*Yes, the vast majority of cancers have these alterations that the immune system can actually recognize.*”
- Keith adds one very nuanced point, “*We have learned that some mutated neoantigens will cause a much more robust immune response than others.*”
  - In other words, they’re not all the same in terms of the type of immune response that can be elicited
- There’s an argument that many have made in terms of thinking about cancer biology and evolution and coexistence of this immune surveillance system
  - That basically the mutations that we end up seeing in diagnosed cancers are ones that aren’t particularly well recognized
    - They don’t produce powerful immune responses
  - The ones that produce powerful immune responses, those cancers never became cancers in the first place
    - They got wiped out

> “*So there’s this notion that basically you have to be able to fly under the radar. You can build yourself as a cancer cell with a certain repertoire of mutations provided that none of them are powerfully immunogenic.*”‒ Keith Flaherty

**Spontaneous regression of solid organ metastatic cancer**

- Peter recalls that through all of recorded human history, there have been very, very rare reportable incidents of spontaneous regressions of solid organ metastatic cancer (these epithelial tumors)
- Steve Rosenberg writes about one, which was the patient who got him to completely change his career
  - It’s the 1960s, he’s a resident at the Brigham
  - A patient comes in who 10 years earlier had been sent home to die with metastatic gastric cancer throughout his liver
  - They took his stomach out to palliate him, and he should have been gone in three months
  - He shows up 10 years later with a gallbladder that needs removing, not a shred of cancer
    - Clearly a spontaneous remission
- This is an example of someone whose cancer made no so much and not so significant of an antigen that it got wiped out before it got anywhere
  - This one got all the way to the “promised land”, but somehow at that point the immune symptom recognized it and responded
- Then it took almost 20 years to figure out that if you just dump enough [interleukin-2 (IL-2](https://en.wikipedia.org/wiki/Interleukin_2), which is “candy” to T cells), that you’re going to pick up the next threshold
  - Which is melanoma and renal cell carcinoma

***At the time we didn’t know why, but as Keith just pointed out, these cancers have so many mutations that you’re stoichiometrically bound to come up with an antigen that’s going to be your “lottery ticket”***

- If we just dump enough interleukin-2 on, we’re going to flip the next threshold
- Then of course the checkpoint inhibitor takes it one step beyond that
  - When there is not enough of a spontaneous response, even when IL-2 is given, targeting checkpoint inhibitors provides more sophisticated help turning down the [T cell] suppressor
- But to really unlock this, to make 80% of cancer gone
  - Imagine that
  - It might be more because maybe you can induce mutations (we’ll discuss this in a moment)

> “*If we just wanted to take 80% of cancer deaths off the table, we have to be able to find out who is that perfect soldier down there that’s really, really, really outnumbered and make more of them. So what does that look like?*”‒ Peter Attia

## Elimination of a substantial portion of cancers through immune cell engineering faces challenges of specificity, cost, and scalability [52:15]

**Connecting the dots from early versions of cell therapy to where we are now**

- Steve Rosenberg’s work was so-called **adoptive T cell therapy**
  - Let’s not focus on that jargon term so much
- The process is basically doing a surgery to remove a single site of metastatic cancer
  - Then removing the immune cells that had found their way into that cancer
    - Some of them are seeing antigens they’re specific for
    - Others are just trafficking through and they’re kind of bystanders
- In any case, immune cells don’t traffic at high numbers through all cancers, but in certain “immunogenic cancers,” yes, they do
  - Melanoma is near the top of the chart there

***What Steve was doing through the ‘90s and certainly by the time Peter got there, was taking those immune cells, isolating them from that patient’s tumor, and simply expanding them***

- There was no genetic manipulation, it was just growing these [TIL (tumor-infiltrating lymphocytes)](https://en.wikipedia.org/wiki/Tumor-infiltrating_lymphocytes)
- TILs were grown to a number what when they were infused back into the patient, they could traffic through the body and destroy people’s cancer
  - Not all the time, but a significant minority of patients could be cured that way
  - That’s still true today
- With just that approach alone (with no genetic manipulation), we are right on the verge of that becoming an FDA-approved therapy for melanoma (finally )
  - Which is where Steve had had the most consistent success back in those years
- Steve has tried it in many different cancer types

***What’s been learned along the way is this idea of antigen specificity, that you can find what the immune system is seeing (what the TILs [T cells] are looking at)***

- The **next step** is to take that knowledge and engineer a patient’s own immune cells (collected from the blood) to direct them against cancers
- Because of advances in cellular genetic engineering, we can now introduce the recognizing piece to the immune cells to direct them against cancers
- If you sequence a patient’s cancer, you can identify a mutated antigen that will only be in the cancer cell and introduce into their immune cells a “surface recognizer” (for say 80% of patients)
  - Sequencing is now routine standard of care
  - Keith is being vague about that so as to not get lost in too much jargon all at once
- You can “dial up” that number of cells in the laboratory and then infuse them back like a blood infusion
  - This is how cell therapy is given
- Keith points out, “*We are not doing that today to be very clear.*”

**Cell therapy today**

- The cell therapy advances, beyond just simply expanding the tumor infiltrating immune cells (TILs or lymphocytes), the engineering that’s being done right now are against surface lineage markers
  - On B cells for lymphoma primarily, but some leukemias and now multiple myeloma as well
  - Basically we are wiping out the cancer cells that arise from that population and the normal cells
  - Keith clarifies, “*What we were talking about is a very elegant, very tumor specific cell therapy strategy, which you can readily envision taking the field, if you will. But where we are right now in cell engineering is going after common surface markers in cell populations that we can “afford” to get rid of*.”
    - So eliminating [B cells](https://en.wikipedia.org/wiki/B_cell) is not a great long-term thing, but you can survive without your B cells
    - (B cells are antibody producing cells, for those who don’t track immunology)

**The “poster child” for this is CD19**

- [CD19](https://en.wikipedia.org/wiki/CD19) is on every B cell
  - We don’t have to get into why it’s called CD19
- When a subset of B-cells go on to become lymphoma that is otherwise unresponsive to other treatments, you can basically send in someone that’s going to target every CD19
  - You’ll get rid of the “bad guys” and you’ll get rid of some “good guys”
  - On balance, it’s worth it, for sure
- But what we’re talking about here is a next layer of sophistication
  - For example, if a patient has metastatic lung cancer, it’s not an option to wipe out all of the lungs
  - It’s a more complicated problem
- There are many cancers for which you could live without the organ
  - You don’t need your colon, breast, prostate, or even pancreas

**Peter’s friend with** [**Lynch syndrome**](https://en.wikipedia.org/wiki/Hereditary_nonpolyposis_colorectal_cancer) **is an example**

- He was adopted so he didn’t know any family history of this disease
- He developed stage III colon cancer in midlife (a great surprise at age 40)
- Later he developed a pancreatic adenocarcinoma
- Peter sent him to an excellent doc whom he had trained with, and he was inoperable
  - The diagnosis was advanced pancreatic cancer with a 6-12-month prognosis
- This was 2012, maybe 2013, just around the time that a [paper](https://www.nejm.org/doi/full/10.1056/nejmoa1500596) had come out in the *New England Journal of Medicine* announcing, “*If you have mismatched mutation genes, you might be a candidate for this new anti-PD-1*.”
- This story has a happy ending because he got the anti-PD-1 therapy and went into a complete remission
  - Now he needs insulin because his immune cells destroyed every pancreatic cell in his body
    - Destroyed both the cancer and non-cancer

**Do we not have enough novel proteins on breast cells or prostate cells that the CD19 approach is going to work anywhere else? Is that a one hit wonder?**

- These T cells are powerful
- You need to find “handles” on the surface that are truly specific for cancer cells
- Keith points out, “*I was honing in on what is truly specific for cancer cells, these mutations.*”

***Developing personalized engineered T-cell therapy for the entire global cancer population is a “big hill to climb”***

**Current focus of the field**

***In the meantime, the field is trying to identify those surface markers (proteins) that are truly specific to cancer***

- There are other therapeutic modalities that don’t require quite as much specificity
  - You can direct chemo even ‒ an antibody that has chemotherapy drugs on the back end of it that gets ingested by the cancer cell will have a more localized effect
  - Another example is [radionuclide](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/radionuclide): really powerful radiation emitters attached to the back end of antibodies
- Cell therapy requires a high specificity to the tumor, otherwise, you’re going to obliterate every single cell in the problem

> “*Here’s the problem: cancers come from us*.”‒ Keith Flaherty

- So finding proteins unique to cancer cells is a real conundrum, not just a technology gap
- Just feeling blindly and trying a bunch of things because of the power of the killing potential of these immune cells, no one in the field has an appetite for that

***This has been where the field has been anguishing most in terms of trying to understand if there’s more CD19-like opportunities, but on common epithelial cells where we can’t destroy the normal version. We need to get to this greater specificity.***

**The cell-engineering field**

- This field has advanced to the point of being able to create bifunctional recognizing elements
  - These are surface recognizing receptors where both of the targets have to be present
  - It’s an “and” switch (like the Boolean and or)
- Instead of just creating a cell that goes after CD19, you create a cell that goes after CD19 *and* CD20
  - You only ever kill a cell that’s got both
  - Though this is not a perfect example because CD19 and CD20 are almost always co-expressed on B cells

***The point is that there is a fair amount of work going on right now to try to find pairs of proteins that might only be expressed on certain cancers, and that might start to give us the opportunity to take this same basic approach***

- This is more readily scalable than the personalized approach
- In theory the personalized approach can be done
  - You determine the genetic makeup of your cancer cells and zero in on a personalized approach that’s specific to your immune system type and to that mutation
- But we have to drive down the cost to manufacture, and a lot has to happen for that to be remotely feasible, economically manageable

## Why TIL therapy isn’t always effective, and the necessity for multimodality therapy to address various aspects of the cancer microenvironment [1:01:00]

**Back to** [**TIL**](https://en.wikipedia.org/wiki/Tumor-infiltrating_lymphocytes) **therapy**

- Keith mentioned earlier that they’re on the cusp of receiving an FDA approval for the treatment of metastatic melanoma
  - For a patient with metastatic melanoma who presumably has progressed through all other non-cell therapies and still has harvestable tumor
    - This is a very important feature of TIL: you actually have to be able to surgically pull out a large enough sample of a tumor
- For example, a patient who has cancer that has spread to their lung
  - They have to undergo lung surgery and take out a wedge (or lobe or whatever amount is necessary)
  - That tumor is taken immediately to the lab where all the lymphocytes that are there are expanded and expanded and expanded (to 109 cells)
  - These cells are re-infused usually with interleukin

**TIL sounds great in theory, but why doesn’t this work every single time?**

- It goes back to the defense mechanisms to a degree
- There are layers of “force fields”
- There are actually direct mechanisms that can impede killing at the tumor cell level
- Keith talked earlier about PD-L1 being expressed on the surface of cancer cells
- It turns out that there are even intracellular mechanisms, such as the way in which interferon (an immune system hormone) triggers cell death
  - It’s part of the killing process that when CD8+ T cells are trying to kill a cell (a virally infected cell or in this case a cancer cell)
  - Successful cancer cells have altered this intracellular process

***The immune cells are actually unable to do the killing because that [cancer] cell is no longer sensitive to immune cell-mediated death***

- This is a very nasty little trick and one that can’t be overcome just by dumping in more immune cells
- This can also cause resistance to PD-1 antibodies
  - It’s been demonstrated in melanoma and a handful of other cancer types now

***So you have to start inside the cell in terms of ways in which cancers have evolved an ability to (1) resist immune recognition that they’re contending with and also (2) recruit suppressive immune cells***

- Very antigenic cancers very commonly do that
- And you can’t overwhelm them just by introducing more CD8-positive T cells
- And so in those cancer types where those so-called myeloid cells are very, very predominant, this cell therapy has just not taken hold at all

**Other difficulties with TIL**

- There are trafficking issues
  - Features of cancer micro environments that make it very challenging for immune cells to persist, multiply, and do their killing work
    - Some of them related to oxygen tensions and some related to nutrient availability

**Metabolic differences in cancer cells**

- We’ve known for a long time that cancer cells are metabolically inefficient
- They’re living in this incredibly harsh environment with very low oxygen gradients
- This stems in part from the [Warburg effect](https://en.wikipedia.org/wiki/Warburg_effect_(oncology))
  - [discussed in [episode #187](https://peterattiamd.com/samapple/)]
  - People thought that cancers can’t undergo oxidative phosphorylation and that’s why they’re doing this inefficient thing
  - Cancer cells go through reams of glucose which leaves them more building blocks (which is what they need more than ATP)
  - On top of that, you’re lowering the pH, creating this incredibly harsh microenvironment
  - Peter adds, “*It seems like there’s every reason in the world from a natural selection standpoint for cancer to do that.*”
- This is what Keith thinks is the “why” of it: cancer cells ultimately figure out hot to thrive in such harsh environments
- Immune cells can’t survive in that harsh environment

***So this harsh environment is a “force field” and another thing we’re not addressing by virtue of just dumping in more immune cells***

- When Keith talks about **multimodality therapy** for cancer, it’s about targeting those mechanisms that we can address inside the cancer cell
  - It’s about modulating the environment metabolically
  - Even fixing to a degree this paucity of oxygen in the pockets of the microenvironment
  - As well as manipulating these other cell populations like immune cells
- It turns out that even fibroblasts get recruited into certain cancers where they seem to be part of the force field against the immune system as well
  - Most notably in pancreatic cancer
  - So we have to knock down the force field

> “*It’s the Star Wars analogy: you’ve got to take out the moon that generates the force field around the death star before you send in your fighters to actually try to destroy it.*”‒ Keith Flaherty

- We’re on the verge of understanding the hierarchy of this biology and how to think about both diagnosing and then treating at this level
- But the toolbox has to elaborate much more completely
  - In Keith’s view, it’s not going to be four therapeutic maneuvers all in column A or four in column D
  - It’s one from A, one from B, one from C, one from D
    - That’s the type of four drug regimen that’s going to eradicate cancer and it’s not going to be one cocktail for all patients

## The potential developments in cancer therapy over the next five years: T-cell activation, metabolic interventions, targeting tumor microenvironments, and more [1:06:30]

**Questions about what the next five years might hold for us**

*How much further have we gone in immunotherapy in activating T-cells, either through adoptive cell therapy via genetic engineering to take peripheral blood lymphocytes and engineer them into TILs? (the category of therapy)*

*Let’s talk about other ways to identify checkpoints or checkpoint inhibitors and or combat the tumor suppressor cells (call that the tumor suppressing environment).*

*How much of it is going to be in the metabolic environment or the interstitial micro environment and targeting the hostility?*

*And then how much of it is going to be inducing mutagenesis?*

- In Peter’s [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1690475187&sr=8-1) (he thinks this made it to the final version) he referenced one study that had taken patients with lung cancer where none of them had any PD-1 activity, but a course of platinum-based chemotherapy all of a sudden rendered a subset of them susceptible to it [anti-PD-1 therapy]
  - In other words, conventional chemotherapy increased immuno susceptibility
    - Even though the patients weren’t particularly responsive to the conventional chemo
- There are lots of ways to go about doing that
- Paradoxically, you could almost imagine taking a cancer cell and exposing it to more mutation forming insults

**What do we need to double the durable response rate?**

- Let’s look backwards briefly
- Over the past eight years, we have exhaustively tried to find other “gas pedals” and “brakes” on immune cells (CD8+ T cells most notably)
- And we know what those “gas pedals” and “brakes” are on those cells
- We have tried drugging those typically on top of PD-1 antibody therapy, and that has almost completely systematically failed
  - Interestingly, it doesn’t produce horrific toxicity
    - In other words, the immune system doesn’t get so hyper activated
  - But it just hasn’t moved the needle
- The caveat is that those approaches have been used without any notion of trying to “zero in” on individual patients and sets of patients for whom that new immunologic mechanism was hypothesized to be uniquely suited
  - In other words, we’ve been “throwing a lot of spaghetti at the wall and hoping things would stick” by just treating a broad array of different cancer patients with absolutely no **molecular selection**, even though there are certainly there were and remain hypotheses along those lines that were never really tested
- Just trying to hyper activate T cells with drugs, we’ve played that out
  - The only way to revolutionize that would be to sharpen our lens by focusing on very specific patient populations

**Other therapeutic approaches**

- There is a related class of therapies which have been exploding in terms of understanding how the genetic blueprint is folded up and unfolded: metabolism targeted therapies and epigenetic targeted therapies
  - The regulators of that and the way in which many cancers figure out how to co-opt the function of some of those folders and unfolds
  - There’s been a real explosion in early development of drugs in that class
- Altered metabolism in cancer cells (the Warburg phenomenon mentioned earlier) and the regulators of that switch have become elucidated in a more complete way in recent years
- Many people would’ve thought that you can’t target metabolism because every cell in the body  needs to be able to regulate its metabolism in a condition-dependent way
- We think we’re on to some unique regulators that cancer uses
  - Keith’s therapeutic development work is focused in that area

**How to target metabolism in cancer cells [1:10:45]**

- From a [glycolysis](https://en.wikipedia.org/wiki/Glycolysis) standpoint, we know cancer is basically a “one trick pony”
  - Most cancers are turning glucose into pyruvate all day every day, independent of how much fatty acid is available and independent of how much oxygen is available
  - And they have perfectly healthy mitochondria
    - People used to hypothesize the mitochondria were deficient and that explained their metabolism
- Taking something that interferes with any enzyme that turns glucose into pyruvate would be a bad idea

**Where else could you target to disproportionately hurt a cancer cell without hurting a non-cancer cell that’s undergoing glycolysis?**

- Keith’s group just published a [paper](https://aacrjournals.org/cancerdiscovery/article/13/3/672/716753/Discovery-of-Targets-for-Immune-Metabolic) on this five months ago where they looked broadly to understand metabolic regulatory cancer cells selectively
  - This analysis was focused on immune cell recognition versus lack of recognition, the interplay between these two things
- We already discussed the idea that cancers seem to adopt this inefficient metabolic strategy in part because it allows them to suck in available nutrients and keep them away from immune cells
- When you look in an unbiased way at all of the gene products expressed in cancer cells differently than in normal cells, what you see is outside the mitochondria
  - Cancer cells regulate the amount of mitochondria they have though programs outside of the mitochondria
    - The nuclear genome, not the mitochondrial genome regulates this process
- One of those switches jumped out of this analysis as the top differentiator expressed in cancers and not in other cells
  - Historically, this type of molecule has been thought to be challenging to create a drug against
  - But there is actually a proto drug against it in preclinical development, and Keith’s group has been collaborating academically with that company to see if this is really going to bear out

> “*These are the types of insights we just didn’t have five and certainly 10 years ago, that there might be ways to actually laser in on the regulators and metabolism that cancers are most potentially vulnerable to.*”‒ Keith Flaherty

- Keith is not suggesting these are going tobe standalone approaches
- They’re going to potentiate other therapies
- When we look at what drives resistance to both *targeted therapy* (these surface receptor and downstream molecules discussed earlier that have been successful and extend people’s lives with cancer) and *immunotherapy*, and we look at **common themes in terms of resistance**, this **metabolic switch** like using oxidative phosphorylation when they weren’t using it before, that’s a very common theme in what we call the persister cell population in both therapy types
- The idea that you would then potentiate simply what we’ve already got with this class of therapies to go from 20% of cancer patients having long-term survival to 40% (Keith is making that number up) just by figuring out this piece of the puzzle
- We might have to toggle upstream, downstream, play with where it is that we’re ultimately poisoning this process, and we may have to do it just periodically
  - In other words, not constant drug exposure all the time to be able to get away with it, which is a common theme in terms of thinking about four drug regimens for cancer

**Combination therapy: pushing cancer cells toward death by increasing their number of mutations [1:14:30]**

*The idea of taking advantage of this very delicate balance where cancer cells have accumulated genetic alterations to a degree that’s supposed to be intolerable for a cell survival*

- If you can’t repair mutations and alterations that have been caused by acute exposure to something like radiation (for example, where you get a lot of mutations all at once)
- We have repair mechanisms, but if they don’t do their job, then a cell has a program by which it commits suicide, so-called [program cell death](https://en.wikipedia.org/wiki/Programmed_cell_death)
- And basically cancer cells live dangerously on the edge in having accumulated these mutations in certain cancers
- In people with Lynch syndrome (like Peter’s friend discussed earlier), Keith adds, “*Wow, the number of mutations that accumulate because of the defective machinery is just off the charts*.”
- Mutations in ultraviolet radiation associated skin cancers are also off the charts
- We know that if you introduce more mutations into those cells in the laboratory, you push them over the edge
  - There’s a limit to what they can handle
- So how about combining that concept with what we were talking about before, immune system recognition of mutated proteins
- Going back to anthropomorphizing of cancer cells, a cancer cell wants lots of mutations because it helps you dial the “combination lock” and become a cancer

***We’re going to not just double, we’re going to 10x the number of mutations you have both to increase immune recognition and possibly also just simply push more cell death***

- That is the concept behind platinum-based chemotherapy effectiveness in cancers that are somewhat deficient in repairing their genomes
  - That’s a link that we’ve known about now therapeutically for a number of years
- [PARP inhibitors](https://en.wikipedia.org/wiki/PARP_inhibitor) target a DNA damage repair enzyme ([PARP](https://en.wikipedia.org/wiki/Poly_(ADP-ribose)_polymerase)), and inhibiting its function can push certain cancers over the edge
- The immunologic piece requires another layer of complexity which is that you would basically need to introduce mutations that are shared across the whole population of cancer cells
- Interestingly, the immune system is able to elaborate immune responses that become broader
  - This is called **epitope spreading**: where the immune system latches onto a certain antigen in mounting an initial immune response, but then can bring in reinforcements that are recognizing other antigens and create a more polyclonal response
    - The initial response was a monoclonal response
    - So that’s part of innate immune function
- But for this to happen, there’s good experimental evidence that you have to start with something that’s shared in at least 95, 98, maybe even 99% of cancer cells
- This is the basis of using radiation to treat a single site of metastatic cancer in someone who has 20 sites
  - This hasn’t worked (or only worked in very rare, sporadic cases) where it triggers a much more profound immune response that is systemic and goes after all the tumor sites
- Peter clarifies, “*The reason it would be rare is if you only introduce a whole bunch of mutations to 10% of the tumor, you might generate a new immune response. You might kick the tumor over the edge either by having so many mutations that it all undergoes program cell death or it now finally rises to the level of detection. But that’s not sufficient enough across the entire organism.*”
  - It won’t clear the rest of the tumors

**Oncogene-targeted therapy backbone treatments**

- Medical oncology has come up with a systemic approach
- There is some fascinating data from one of Keith’s colleagues at Mass General (soon to be published) that suggests you can incubate cancer cells with mutation-inducing drugs (certain chemotherapy drugs), but for that to work you have to use another therapy first
- Some of the therapies already discussed are partially effective for a period of time (months to many months) before resistance manifests
- If you use that therapy in combination with chemotherapy drugs that cause the cells to accumulate more and more mutations, it appears that you can buy the time you need to trigger immune recognition, and even make PD-1 antibody-based therapy more effective
  - Shown in mouse models
  - The next step is to try this idea in human beings
  - ***This is called the oncogene targeted therapy backbone treatments***
- This uses chemotherapies that are [alkylating agents](https://en.wikipedia.org/wiki/Alkylation#In_biology); they are able to introduce new mutations
- It would appear that even at low doses, you can potentially introduce the mutations without having some of the deleterious effects that chemotherapy drugs are well known to cause

## The challenge of treating metastatic cancer underscores the importance of early detection to improve survivability [1:19:15]

![](https://peterattiamd.com/wp-content/uploads/2023/08/f2-keithflaherty.png)

**Figure 2. Cancer staging**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cancer_staging)

**Prognosis for someone with stage III colon cancer**

- If you take a person with stage III  colon cancer, you’re going to put that patient on a fancy regimen of chemotherapy
  - This person has cancer in their colon (visible to the eye) and in the lymph nodes of the colon but it has spread no further (no radiographic evidence that it’s anywhere else)
  - [Read more about cancer staging at the [National Cancer Institute](https://www.cancer.gov/about-cancer/diagnosis-staging/staging)]

*How many of those patients are going to be alive in 5 years? 60-70% of them?*

- That’s about right
- It depends on the size of the initial tumor and other features

**Prognosis for someone with metastatic colon cancer**

- Let’s now take that same patient, except he also has cancer that has spread to his liver (stage IV)
- You’re going to go ahead and cut the colon out, take those lymph nodes out, but on the CT scan, you’re going to notice that he’s also got metastatic cancer
- So one patient is stage III and one is stage IV
- We’re going to give that stage IV patient the same chemotherapy, the same drugs

***But in five years, somewhere between none and a few percent of those stage IV patients will be alive. And if you wait to 10 years, it’s none.***

**What’s a decent explanation for that observation?**

- Keith clarifies the question, “*Why is it that we’re actually able to eradicate microscopic residual disease with the same drugs that don’t do the job when you have macro disease?*”
  - In other words, why does it work when you have hundreds of millions or billions of cells *not* all clumped together (but sort of diffuse), but when you have a hundred billion cells and they’re in big visible clumps, the same drugs just fail?
- There are two prevailing hypothesis to explain this
- 1 – The **clonal heterogeneity concept** refers to how cancers evolve
- We used to think that cancer cells were identical clones of one another, just a massive number of identical cells
  - In the beginnings of cancer, that is largely true
- As cancers continue to evolve in our bodies, they keep mutating, and so you start establishing subclones
  - You typically have a dominant subclone, that might even be 99% of cells
  - Then in that remaining 1%, you might have 10, 20 subclones
  - We’ve proven now that certain therapies actually are able to pick off the 99%, they leave the 1%, and then somewhere in that 1% is a clone that has a resistance mutation already in it to the drug that we’re giving
- The clonal heterogeneity hypothesis is quite strong
- If you nip cancer in the bud by offering the same therapy when there’s not so much clinical heterogeneity, that represents a curative opportunity
- With oncogene targeted therapies that go after mutated activated proteins (growth factor receptors and downstream targets in particular), it’s very clear you can cure a trivial fraction of patients with overt metastatic disease
  - You can cure a substantial fraction of patients in the so-called [adjuvant setting](https://en.wikipedia.org/wiki/Adjuvant_therapy)
    - This is the microscopic residual disease setting
- The question is why
- We think part of the explanation has to do with the lack of clonal heterogeneity
- 2 – The **secondary immune response**
- All successful curative cancer therapies trigger immune recognition through what is referred to as immunogenic cell death
- You’re killing cancer cells directly with drugs, but the “mop up work” of actually eradicating every single last cell is the immune system’s job
  - This is a concept first introduced when we had just these conventional chemotherapy drugs from the 1900s
- We now have more evidence that the more elegant molecularly-targeted drugs engender these types of immune system recognition as part of their mechanism of action
  - There is better immune recognition in patients who are receiving these therapies (looking a biopsies compared to pretreatment)

> “*Yes, you’re directly killing cells with these drugs. That’s true, but the eradication piece is ultimately an immune system phenomenon.*”‒ Keith Flaherty

- Peter thinks there’s kind of a hybrid there too, which is in that micrometastases environment (the adjuvant setting), you have less capacity for the tumor to create the hostile environment that impairs the immune system from mopping up the damage
  - Having as few cancer cells as possible increases the odds of killing them
  - Keith agrees

> “*Early detection is going to allow our same toolbox of drugs to be massively more effective*”‒ Keith Flaherty

## Liquid biopsies for early detection of cancer and determining the possible tissue of origin [1:24:45]

**We’re pretty terrible at early detection as it stands right now**

- We only have real direct **evidence of effective screening** for a few cancer types
  - 1) Such as cervical cancer for sure, but we could also hopefully eradicate cervical cancer by getting everybody vaccinated eventually ([HPV vaccine](https://en.wikipedia.org/wiki/HPV_vaccine))
  - 2) Breast cancer is another example, “*We can cut the risk of breast cancer death by about a third with mammography.*”
    - But that’s not a very inspiring number
    - Keith strongly suggests that everyone who is eligible should get mammograms
  - 3) Colonoscopy, and other less invasive means of detecting colon cancer, can reduce risk of colon cancer death by about 25-30% ballpark
- Despite lots of effort and controversy, prostate cancer screening is quite poor
  - PSA tests are not a great way of detecting cancers, and certainly not potentially dangerous prostate cancers
- Peter points out that these last three examples are three of the big five, and they all have something in common
  - Mammography, infrequent colonoscopy, and PSA are not great screens by themselves
  - Policymakers and physicians can confuse the statistics just discussed as proof positive that early screening doesn’t justify the cost
- Mammography used in isolation has blind spots, but that doesn’t mean that adding ultrasound or MRI to the breast surveillance program won’t dramatically increase the odds of finding cancer
  - Stacking tests with different sensitivities and specificities
- Except for small calcified lesions, mammography works poorly in hyper glandular tissue
  - The opposite is true for MRI
- PSA by itself is just shy of a random number generator, but PSA density and PSA velocity now adds much more specificity
  - Furthermore, you start to add things like a [4K](https://www.fda.gov/medical-devices/recently-approved-devices/4kscore-test-p190022#:~:text=The%204Kscore%20Test%20is%20an,previous%20biopsy%2C%20and%20digital%20rectal) and if the risk is high enough, you get multiparametric MRI
- For the past 10 years, Peter has not had one patient get a prostate biopsy that wasn’t warranted
  - He’s not a superstar, rather they are using multiple tests
  - They’re not just using PSA
  - Some patients only get picked up on PSA velocity
    - Their PSA is not high enough to trigger the 4k

**Peter gets frustrated with the medical community that’s anti-early screening or opposed to screening and early detection**

- Analogy: that’s like saying there’s too many fatalities in cars, so we shouldn’t drive
  - Yea, there are fatalities in driving, but let’s figure out ways to drive better
  - That’s totally different from saying, “*We’re going to abandon all of those things.*”
- In Keith’s world as an oncologist, he doesn’t have to contend with this community
- He takes those numbers as being absolute support and endorsement [of early screening]

**Liquid biopsies**

- For the massive remaining unmet need, there has been enormous advance in methods for detecting single alleles, single fragments of genes in the bloodstream [aka liquid biopsies]
- It turns out that normal cells shed DNA in the bloodstream
  - This DNA is digested and broken down reasonably quickly, but not immediately
  - And cancer cells also do this
- The more cancer you have in your body, the more copies of cancer DNA will be shed in the bloodstream
- Sequencing technologies have advanced to a degree that now, from a single 10 mL tube of blood
  - And particularly one collected over time
    - Analogous to your PSA velocity example where you’re sampling at multiple time points
  - If you sample at multiple time points now and subject those to sequencing
    - These methods being commercialized

> “*Since we talked four years ago, what felt like very much a research method is now emerging as a real clinical option*.”‒ Keith Flaherty

- There are methods now that can find a broad array of cancers at an earlier point
- In R&D mode right behind them are 10x, 100x more sensitive methods that are going to absolutely “move the needle” in terms of our ability to find cancers at a microscopic point

**What do you do when you detect microscopic cancer?**

- This is a fundamental conundrum
- Overlay on top of that what you can do with [circulating tumor DNA](https://en.wikipedia.org/wiki/Circulating_tumor_DNA)
  - 1 – You can sequence it for mutations
  - 2 – You can look at methylation patterns
- Methylation patterns  have to do with the folding and unfolding of the “blueprint”
  - They are molecular modifications that exist in certain cell types
- If you find a mutated sequence of DNA and it has the methylation pattern of colon epithelial cells, this tells you what cancer you probably have
- While you can’t direct the scalpel right away, you can do a colonoscopy
- Similar for breast cancers and others, you can start to focus your attention with imaging analysis to try to detect the cancer
  - Maybe not immediately
  - Maybe it’s going to tak six, 12, 18 months of continued surveillance

***Then you’ll find the cancer at a much earlier point than you would’ve ever found it based on our other methods***

- Early adoption of methods as they exist now that are getting rapidly better in terms of increased sensitivity
- There’s been a real explosion in terms of investment in this area and now scale up of technologies that are commercially relevant

**You can also find targetable mutations**

- Analysis of circulating tumor DNA can also find mutations that can be targeted with drugs or immunotherapies
- Maybe you can’t direct the scalpel, but we know what drug to give the eradicate the trivial amount of cancer
  - Think back to the earlier discussion of clinically overt metastatic disease versus microscopic disease that remains after surgery (aka the adjuvant setting)

***Finding cancers at a point where there’s many fewer of these cells and where the defense mechanisms of force fields and the heterogeneity (that we talked about before) don’t exist ‒ this is a real reason for optimism***

**There are two applications here**

- 1 – Do more precise therapy in the post-surgical setting
  - So really figuring out right after surgery, who still has microscopic disease in them and who doesn’t?
  - Peter agrees, “*That’s a much easier problem.*”
    - He talked with [Max Diehn](https://profiles.stanford.edu/maximilian-diehn?tab=bio) about this [[episode #213](https://peterattiamd.com/maxdiehn/)]
    - Max is one of the pioneers in that field
- Peter adds, “*This now becomes the most elegant way for post-treatment surveillance, but it’s what we started with that is the much more difficult problem and frankly, the most important problem.*”

**Benefits of detecting cancer early**

- We’ve been stuck in this mode in cancer research and therapeutic development ‒ start with the worst case scenario
- The same therapies that are somewhat effective in the overt metastatic setting are much more effective in the so-called adjuvant or post-surgical setting
- We have every reason to believe they’re going to be at least as effective, arguably more, when we’re down two logs, three logs, even fewer cells at the time of cancer diagnosis
- At this earlier time, the immune system is still quite competent, is still actually doing much of its job

## Commercially available cancer screening tests [1:33:45]

**What is the state of the market today in terms of tests that people can get as part of a cancer screening protocol?**

- Peter notes that [Grail](https://grail.com/) has a commercially available kit, but you need to get it through a physician
  - It’s not commercially available

*How close are we to these tests being an imperative part of cancer screening?*

- We are not quite at the imperative point
- But we’re certainly at the point where it’s reasonable to get a test
- There’s a [test](https://www.exactsciences.com/Pipeline-and-Data/multi-cancer-early-detection) that was initially developed by a company called Thrive that was acquired by [Exact](https://www.exactsciences.com/about) and is now available commercially
- Another company called [Delphi](https://delphi-diagnostics.com/) has a commercially available [test](https://delphi-diagnostics.com/our-technology/breast-cancer-diagnostic-tests/)

**The concern that many people have with liquid biopsies**

- Getting a positive blood test can lead to a large degree of anxiety
  - Especially if you don’t find the problem with a standard radiographic assessment
- The medical community hasn’t had time to work out the kinks of “*How do we manage this situation?*”

**Keith’s public service announcement:** *there needs to be generalists who really develop expertise, content knowledge, have a network of specialists that they can work with to be able to catch these patients*

- These tests were launched before that was really created
- If you just get a test and you’re not in the hands of someone who can manage a positive test, it is anxiety provoking

**The future of liquid biopsies**

- Keith and his collaborators have been doing direct head-to-head comparison analyses of how much lower can they go in terms of the amount of tumor DNA in the blood that can be detected with what are currently R&D methods, but are readily scalable
  - “*We’re really at 100x better.*”
- Peter asks, “*At that point, you’re talking about a finger drop of blood. If you’re a 100X better than 10 mL, you mean?*”
  - You could take it in that direction
  - But we want to stay with a 10 mL sample and do serial analyses
- To prove this point [the utility of liquid biopsies], you can begin in high risk populations
- Keith can readily envision how to capture a much bigger section of the population

**What’s differentiating these companies, if you just look at Delphi and Grail?**

- Peter has no affiliation with any of these companies
  - He uses [Grail](https://grail.com/) in his patients based on the affiliation with [Illumina](https://www.illumina.com/science/technology.html)
    - Illumina is the best sequencing company
  - He doesn’t use Grail in everybody because, “*You got to be able to tolerate the noise that may come of these tests.*”

**To increase sensitivity, there are three aspects to circulating tumor DNA to pay attention to**

- 1 – Look for mutations
- 2 – Fragment-length fragmentomics is its own field separate from first generation genomics
  - Delphi came out of that scientific discovery
  - Circulating tumor DNA comes in different fragment sizes than normal cell DNA (that is a phenomenon of this population)
  - You’re measuring multiple circulating DNA fragments and have to tune your algorithm to find the sweet spot of differentiation
  - Keith thinks everyone will eventually use this method
- 3 – Methylation analysis of circulating tumor DNA
  - This features has been a differentiator in terms of the first marketed products
  - More companies are up and coming
- Peter points out that #1 is not valuable for pan screening
  - Instead, that’s how you check for recurrence of cancer, when you know the mutation

**We’re not going to be able to screen people on the basis of guessing cancer mutations, are we?**

- Some would argue we can as the cost of sequencing continues to nose dive
- There are some who argue, “*Actually, no, no, we just go after the 1,000 most common cancer mutations (pick a number, the 10,000, the 100,000 most common cancer mutations) that we actually can…*”
  - Mutations in genes such as: [*KRAS*](https://en.wikipedia.org/wiki/KRAS), [*p53*](https://en.wikipedia.org/wiki/P53) (mutated in 50% of all cancers now)
  - The problem is there are hundreds of different mutations and p53 is a big gene
- People used to object to that concept based on a sequencing cost argument, but that is becoming less and less relevant
- Sequencing doesn’t require customization, which is what is being done in the post-surgical setting
- When you know what mutations exist in the resected tumor, it does allow you to create very, very sensitive tests for that patient, and that’s being done commercially
- But when you don’t know what you’re looking for, the argument is, “*If you don’t know what you’re looking for, the argument is if you do enough sequencing, you’ll find them.*”

**Are there companies that are doing this type of sequencing?**

- No
- But there’s a scale up in investment in this area which is heartening to see
  - Keith used to complain about the fact that diagnostics didn’t get the same investment that therapeutics got because the return on investment is fundamentally different

> “*As clinicians, we need the diagnostics. We can’t even think about therapeutics until we basically diagnose*.”‒ Keith Flaherty

- Peter points out the irony of how people talk about, “*Oh, we’d really love to lower healthcare costs*.”
  - This can be done with earlier and better diagnostics
  - It’s wise to be upset about the cost of oncology therapeutics that are adding no value, but if you spend 1/10th of that on diagnostics, you make that problem irrelevant
- With early diagnosis, the duration of therapy needed to reach a curative outcome [is much less]

**Peter’s takeaway ‒ we’re turning this into a “lock and key model” from diagnostic to therapeutic**

## How to address the disparity in cancer care, and the exciting pace of progress for cancer detection and treatment [1:40:15]

- Peter thinks of Keith as one of the most remarkable oncology advocates
- If one of his patients comes down with an unusual cancer, he will ask Keith about any promising clinical trials
  - For example a breast cancer that is [HER2 neu](https://en.wikipedia.org/wiki/HER2) positive but [ER](https://en.wikipedia.org/wiki/Estrogen_receptor) [PR](https://en.wikipedia.org/wiki/Progesterone_receptor) negative [this refers to the [receptor status](https://en.wikipedia.org/wiki/Breast_cancer_classification#Receptor_status)]
- Peter adds, “*There should be an entire industry of Keith Flaherty’s who are there to be consulted by families who find themselves in this situation.*”
- People need help navigating the system, and the disparity in cancer care in this country (and probably in most countries) is significant
- Therefore, it does matter who you know
  - It does matter which expert points you to the best treatment center

**What can somebody do when they get that bad news?**

- This drives Keith crazy ‒ access to expert opinion
  - Particularly for complex, unique outlier cases
  - “*You don’t know as a patient or a family member, whether you’re dealing with a middle of the road case.”*
- 1 – We need to pool our insights
  - Break down the silos of hospitals and centers and universities and whatever, and pool our opinions
- 2 – We need to leverage technology for this purpose
  - People get all excited about artificial intelligence (AI) in terms of how it’s informing chemistry advances and the like
  - But first you need to start to build the database of opinions that Keith and others offer to specific cancer cases based on certain aspects of their diagnosis
    - And the patterns are, these are not hard for a machine to figure out
    - A human could figure it out
    - Codify what Keith does as the teaching set for AI
- #1 & #2 would cover 95% of the typical cases
- 3 – The edge cases are where we need to apply our specific attention, and there are enough experts like Keith to handle the edge cases
- The problem with the way our system works is, nobody knows what the complexity of their diagnosis is
  - Everybody is seeking the same level of care and decision making without that understanding
  - But we can get way ahead of this and be transparent in explaining, “*Look, here’s why we’re saying you’ve got a very typical case. We have a ton of outcome data. We know what therapy is the very best.*”
- The issue of therapeutic access and investigational therapies that are crossing the divide and are showing real responses in real human beings and should be considered as a certain priority
  - Maybe not the top priority, but a backup option or something

> “*Honestly, we are so inefficient in terms of how it is that we disseminate information. It drives me crazy.*”‒ Keith Flaherty

- You shouldn’t have to get on an airplane to ever go see anybody
  - But even on the Zoom screen
- There are a few people working on this, and if you throw some technology at this problem, Keith thinks it will go away

**What is the best thing that one could do now?**

*What are the companies that are out there that are trying to do this now that are reputable in your mind?*

- The company [N-of-One](https://www.genengnews.com/resources/n-of-one-qiagen-take-precision-drug-development-to-the-next-level/) has been at this for a long time and this is a model that they are quite good at
  - They’re not accumulating the database or figuring out how to focus attention
- The company [Xcures](https://xcures.com/about/) is doing this kind of work, but it’s still at the stage of helping individual patients navigate
  - It’s not the full insight machine, but it’s going to come

**Keith’s takeaway on this approach ‒** ***this is another area where we’re “blowing the bank” on a very efficient system that not scalable***

**Peter’s conclusions ‒**

- We’re not “curing cancer,” but we’re going to get a lot better at detecting it earlier
  - Which gets people into a treatment pipeline sooner
- We’re going to continue to see incremental ways to harness the immune system
  - That’s where he sees a lot of optimism
  - This in combination with other traditional therapies and non-traditional therapies (such as the metabolic ones discussed earlier)

**Keith’s conclusions ‒**

- “*The good news is that the technology curve continues to bend upward.*”
  - Sequencing technologies is an example
  - Cell engineering advances
  - The ability to take new molecular targets and rapidly cycle that though to new drugs, small molecules, antibodies and the like
- “*All of these advances are converging in a way that if we keep talking at four year increments, the pace of progress is going to be substantially greater per unit time*.”
- Now the convergence of diagnostics and therapeutics is finally coming into view
- The “take-home message” is it’s the crossing of those wires that is going to get us toward the path of having much higher percentage of patients who are 10-year survivors

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Keith Flaherty**: #[62 – Keith Flaherty, M.D.: Deep dive into cancer— History of oncology, novel approaches to treatment, and the exciting and hopeful future](https://peterattiamd.com/keithflaherty/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (July 15, 2019) | [1:00]

**Steven Rosenberg’s book on cancer**: [The Transformed Cell](https://www.amazon.com/Transformed-Cell-Stephen-Rosenberg/dp/0399137491/ref=sr_1_1?crid=3DVRTQ2ITZDDX&keywords=the+transformed+cell&qid=1690381087&sprefix=the+transformed+cell%2Caps%2C100&sr=8-1) by Stephen Rosenberg and John M. Barr (September 1982) | [22:45]

**Previous episode of** ***The Drive*** **with Steve Rosenberg on immunotherapy**: [#177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers](https://peterattiamd.com/stevenrosenberg/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 27, 2021) | [22:45, 32:00]

**Blockade of PD-1 is a more successful cancer therapy in people with mutations in mismatch repair genes**: [PD-1 Blockade in Tumors with Mismatch-Repair Deficiency](https://www.nejm.org/doi/full/10.1056/nejmoa1500596) | *New England Journal of Medicine* (D Le et al. 2015) | [57:30]

**Previous episode of** ***The Drive*** **with Max Diehn**: [#213 ‒ Liquid biopsies and cancer detection](https://peterattiamd.com/maxdiehn/) | Max Diehn, M.D. Ph.D. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (July 11, 2022) | [1:32:45]

**The interplay between metabolism and immune cell recognition in cancer cells**: [Discovery of Targets for Immune–Metabolic Antitumor Drugs Identifies Estrogen-Related Receptor Alpha](https://aacrjournals.org/cancerdiscovery/article/13/3/672/716753/Discovery-of-Targets-for-Immune-Metabolic) | *Cancer Discovery*(A Sahu et al. 2023) | [1:11:30]

§

## People Mentioned

- [Steven Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) (Chief of Surgery, Senior Investigator and Head of Tumor Immunology at the Center for Cancer Research, National Cancer Institute) [22:45, 32:00, 50:15]
- [Max Diehn](https://profiles.stanford.edu/maximilian-diehn?tab=bio) (Professor of Radiation Oncology at Stanford University, pioneer in developing liquid biopsy methods for detecting cancer) [1:32:45]

§

![](https://peterattiamd.com/wp-content/uploads/2023/08/bio-keithflaherty-500x500.jpeg)

##### Keith Flaherty, M.D.

Keith Flaherty earned his Bachelor of Science from Yale University. He earned his medical degree from Johns Hopkins University, completed his residency in internal medicine at Brigham and Women’s Hospital, and completed a medical oncology fellowship at the University of Pennsylvania. Dr. Flaherty began his career as a Professor of Medicine at the University of Pennsylvania. Currently he is a [Professor of Medicine at Harvard Medical School](https://www.dfhcc.harvard.edu/insider/member-detail/member/keith-t-flaherty-md/) where he is the Richard Saltonstall Endowed Chair in Oncology. He also serves as the Director of Henri and Belinda Termeer Center for Targeted Therapy, Cancer Center, Massachusetts General Hospital, and Director of Clinical Research, Cancer Center, Massachusetts General Hospital. At Dana-Farber/ Harvard Cancer Center he serves as the co-leader of the [developmental therapeutics program](https://www.dfhcc.harvard.edu/research/research-programs/discipline-based-programs/developmental-therapeutics/), and he is a member of the [melanoma research program](https://www.dfhcc.harvard.edu/research/research-programs/clinical-based-programs/melanoma/).

Dr. Flaherty has expertise in melanoma. His research focuses on understanding novel, molecularly targeted cancer therapies and predictive biomarkers. Dr. Flaherty and colleagues have established the efficacy of inhibiting BRAF and/or MEK for treating metastatic melanoma. He has also been a leader in characterizing mechanisms of resistance to BRAF inhibitor therapy. Dr. Flaherty has served as Principal Investigator for numerous clinical trials of novel cancer therapies.

Dr. Flaherty joined the NCI Board of Scientific Advisors in 2018 and AACR Board of Directors in 2019.  He serves as editor-in-chief of Clinical Cancer Research. Dr Flaherty has co-founded and served as an advisor for several biotech companies. In 2013 Dr. Flaherty co-founded Loxo Oncology, served on the Board of Directors, and chaired the Scientific Advisory board until its acquisition by Eli Lilly for $8 billion. He is co-founder of Strata Oncology, X4 Pharmaceuticals, Apricity, and Scorpion Therapeutics. He serves on the board of directors of Loxo Oncology, Inc. and Chair of Clinical Advisory Board for Monopteros Therapeutics. [[Monopteros](https://monopterostx.com/keith/)]