# #238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease

**Source:** [https://peterattiamd.com/ama43/](https://peterattiamd.com/ama43/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers questions related to the leading cause of death in both men and women—atherosclerotic cardiovascular disease (ASCVD). He highlights the most important risk factors for ASCVD, such as apoB, LDL, hyperinsulinemia, and Lp(a), and explains the mechanism by which they confer risk and how these factors are interrelated. Peter also dives deep into the data around apoB to try to answer the question of how much residual risk is conferred for ASCVD through metabolic dysfunction once you correct for apoB. He also looks at the data around lifetime risk reduction of ASCVD in the context of low apoB.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or our website at the [AMA #43 show notes page](https://peterattiamd.com/ama43). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- A racecar analogy for understanding atherosclerotic cardiovascular disease [2:00];
- Defining and differentiating apoB and LDL-C [10:00];
- The interrelated nature of insulin levels, apoB, triglycerides, and ASCVD parameters [13:00];
- Another way that hyperinsulinemia plays a role in endothelial dysfunction [18:00];
- Why Peter uses the oral glucose tolerance test (OGTT) with all patients [20:15];
- Is there any evidence that hyperinsulinemia is an independent contributor to ASCVD? [23:00];
- Thinking through risk in the context of high-fat diets resulting in improved metabolic metrics but with an elevation of apoB/LDL-C [27:30];
- Thinking through risk in the context of low apoB but higher than normal triglyceride levels [32:15];
- The importance of lowering apoB for reducing ASCVD risk [38:15];
- Data on men and women with familial hypercholesterolemia that demonstrates the direct impact of high apoB and LDL-C on ASCVD risk [47:45];
- Importance of starting prevention early, calcium scores, and explaining causality [52:30];
- Defining Lp(a), its impact on ASCVD risk, and what you should know if you have high Lp(a) [56:30];
- Lp(a) and ethnic differences in risk [1:00:30];
- Why someone with elevated Lp(a) should consider being more aggressive with apoB lowering strategies [1:05:00];
- Addressing the common feeling of hesitancy to taking a pharmacologic approach to lower ASCVD risk [1:07:15];
- Peter’s take on the 2022 Formula 1 season and thoughts on 2023 [1:15:15]; and
- More.

§

The Peter Attia Drive

Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease

§

## Show Notes

§

## A racecar analogy for understanding atherosclerotic cardiovascular disease [2:00]

**Previous episodes on this topic:**

- [AMA 34](https://peterattiamd.com/ama34/)
- [Episode #210 with Benoît Arsenault on Lp(a)](https://peterattiamd.com/benoitarsenault/)
- [#185 with Allan Sniderman](https://peterattiamd.com/allansniderman/)
- [#140 with Gerald Shulman insulin resistance](https://peterattiamd.com/geraldshulman/)

\*\*\*

What’s more or less known:

- apoB can increase risk
- Lp(a) can increase risk
- Insulin, not good for ASCVD

But the open questions include things like:

- H*ow can these risk factors collectively influence the risk of someone*?
- And how to think through hypotheticals such as:
  - W*hat if my apoB is low, but my Lp(a) is high*?
  - W*hat if my insulin is good, but my LDL or apoB is raised*?

**Racecar analogy**:

- Imagine your lifespan is the length of time it takes you to drive a race car from point A to point B, where point B is driving it off a cliff
- You have two pedals: the accelerator and the brake pedal
  - Your feet are always on both pedals, so it’s really just a question of how hard are you pressing on each one
- In this analogy, there’s never a point when the car is not moving towards the edge of the cliff, but you can do things that really speed up the drive, which means you’re moving towards death more quickly
  - That would mean you’re pressing much more on the throttle than you are on the brake
  - Conversely, you could have minimal pressure on the throttle and much more pressure on the brake and really slow your forward progress.
- Then the questions become:
  - What are the factors that you could be doing that accelerate the drive towards the cliff?
  - What are the things that you can be doing that slow that trajectory?
- That said, some things aren’t under you control like Lp(a)
  - Lp(a) is just a low level of maintenance throttle that is put on the pedal
  - So somebody who’s born with a low Lp(a) has a very low throttle application
  - Someone who’s born with a high Lp(a) would have a higher throttle application.
  - we would just call this baseline maintenance throttle.
- High apoB is also an accelerator, but you can apply the “brake” by lowering it
  - You can lower apoB with dietary changes (slight push on brake)
  - Or you can lower it with the application of pharmacotherapy (hard push on brake)
  - The more you’re lowering apoB, the harder you’re pushing on the brake
- If a person has, for example, type 2 diabetes that is generally accompanied by hyperinsulinemia
  - what is hyperinsulinemia doing in this equation? It is pressing harder on the throttle
  - It is accelerating through mechanisms like upregulation of APOC3 expression, which regulates apoB in the wrong direction
  - So more APOC3 means more apoB impacts the LDL receptor, the LDL receptor related protein. It moves all of these things in the wrong direction
- Other examples of accelerators:
  - Smoking
  - High blood pressure
- So what are the big three things that are driving ASCVD?
  - Smoking,
  - hypertension,
  - apoB.
  - Then, of course, you have other things, like Lp(a), hyperinsulinemia

> “That would be my analogy, which is we have a car that we can’t actually stop, but we can really slow it down to a dull roar. That’s going to be through some combination of manipulating the brake and the throttle.” —Peter Attia

One thing to add to this analogy:

- If you’re 100 feet from the end of the cliff (i.e., you’re an older person) and you’re traveling fast, you better get ready to lock up the brakes.
- If you have a mile between you and the cliff, you can be a lot more judicious in your use of the brake pedal

⇒ [AMA #34](https://peterattiamd.com/ama34) stresses the importance of starting preventative strategies early in life

## Defining and differentiating apoB and LDL-C [10:00]

**ApoB and LDL-C**

- oftentimes these are in concordance, sometimes they’re in discordance
- Peter always prefer to know apoB
- Oftentimes, people don’t know their apoB and they only have their LDL-C, which can be a predictor as well

**Defining the molecules**

- LDL-C is a laboratory measurement that measures the concentration of cholesterol contained within the LDL particles
- LDL, low density lipoprotein, is not a laboratory measurement
  - It’s either LDL-C, the cholesterol concentration within
  - Or the LDL-P, the number of LDL particles
- Peter prefers to look at apoB, which is the concentration of all particles that carry the apoB lipoprotein; which includes…
  - LDL (the lion’s share)
  - but also VLDL
  - and Lp(a), which is a subset of the LDL

**In summary**

- Your LDL cholesterol concentration is a predictor of risk—the higher it is, the more likely your risk
- But the apoB is a **better** predictor of risk because:
  - It captures not only the concentration of LDL, and we know that it’s the **number of particles** more than the cholesterol concentration of the particles that drives risk
  - But also because it includes the other atherogenic particles—namely the VLDL
- Side note on Lp(a)
  - The Lp(a) is generally captured inside of the LDL
  - We like to know that separately because in people for whom it’s very high, our best strategy at the moment to reduce residual risk is to obliterate apoB concentration
- Peter measures all of these in his patients, but at the end of the day, he looks heavily at apoB concentration as the most important metric

**⇒ For more info on this topic:**

- [AMA 34](https://peterattiamd.com/ama34/)
- [#185 with Allan Sniderman](https://peterattiamd.com/allansniderman/)

## The interrelated nature of insulin levels, apoB, triglycerides, and ASCVD parameters [13:00]

***Are there relationships between insulin levels and other lipid ASCVD parameters like apoB?***

Before getting to that question, Peter takes a step back to explain an observation about hyperinsulinemia:

- The observation that is unequivocal is hyperinsulinemia is associated with worse outcomes in ASCVD
- Type 2 diabetes, for instance, is just a very extreme manifestation of hyperinsulinemia
  - While type 2 diabetes is defined by glucose level, but the precursor to that is hyperinsulinemia
  - typically the true canary in the coalmine, is it’s a postprandial challenged glucose response, where glucose is normal, but insulin is distorted (elevated)
  - When we see that 30, 60 minutes after you’ve been challenged with glucose, you have elevated insulin, we know that you’re on the path towards insulin resistance.

People with type 2 diabetes are much more likely of developing ASCVD—The question is why? What’s the mechanistic explanation for this?

- Insulin and insulin resistance impact the expression of APOC3
  - APOC3 is another lipoprotein
- In Peter’s [upcoming book](https://peterattiamd.com/outlive/), he writes about the APOC3 gene, which is one of the centenarian genes
- Centenarians are more likely to have a version of that gene that results in lower expression…in other words, that’s a good thing.
- The “bad” version of that is what we see the expression pattern in people with hyperinsulinemia insulin resistance is that we upregulate that
  - If we do that, if we increase the expression of that, it blocks the activation of something called lipoprotein lipase or LPL
  - LPL is an enzyme that sits on cells that basically performs a function of controlling lipolysis.
  - One of the side effects we see of blocked LPL activity is less utilization of triglyceride
  - If you’re using them less, what’s happening? You’re increasing the amount of triglyceride you have.

*Let’s think back to what does this all mean?*

- If you increase the concentration of triglyceride, we know that risk goes up
- But the question is, through what mechanism? ⇒ It goes up through apoB
- Why does it use apoB? ⇒ Because triglycerides like cholesterol are not water soluble. They’re fat soluble, which means they can’t be trafficked on their own. They can’t just freely float through plasma. They need a chaperone.
  - The most common chaperone we use to move cholesterol are apoB-bearing particles, namely the VLDL particle, which is itself very atherogenic
  - In fact, if it sticks around a long time and becomes a remnant, it is especially atherogenic.
- If we are increasing expression of APOC3 and blocking the action of lipoprotein lipase, we’re going to see a net increase in triglyceride
- Furthermore, we’re going to see a specific increase in a type of LDL which is triglyceride rich
  - We really don’t want to see these triglyceride-rich LDLs
  - We want the triglycerides to be utilized because if you have now triglyceride-rich LDLs and their purpose there is to really carry cholesterol, what does the body do?
- It has to make more LDLs. That means the concentration of apoB is going up.
- That’s the most important mechanism

*How do we see this?*

- The way we basically see that is we’re going to see high plasma levels of triglycerides, and we’re going to see other things as well
- going to see HDL cholesterol concentration go down. That’s probably due to the change in activity of a protein called cholesteryl ester transfer protein, CETP

> “Hyperinsulinemia is a risk factor that also increases, both directly and indirectly, the risk of ASCVD.” —Peter Attia

## Another way that hyperinsulinemia plays a role in endothelial dysfunction [18:00]

- The other way insulin, especially hyperinsulinemia, is playing a role is with endothelial dysfunction
- If you ask the question, *what is the cascade of events that leads to ASCVD?*
  - Endothelial dysfunction is an important risk factor
- W*hy is endothelial dysfunction an important risk factor?*
  - Because if the endothelium is not working, the apoB particles have an easier time getting through the gaps and into the subendothelial space
  - Furthermore, we know that that’s what propagates the risk—
    - As the apoB particles get retained and oxidized and the immune cells, namely monocytes that become macrophages, undergo the phagocytosis of the oxidized LDL particles and become foam cells, that creates an inflammatory milieu in the subendothelial space that drives endothelial dysfunction and leads to a greater and greater cascade of more apoB particles being retained, oxidized, etc.
- Insulin itself seems to drive this endothelial dysfunction
- But this is a much harder thing to demonstrate because we don’t really have great clinical commercial assays for endothelial function
- If you do look at cultured endothelial cells and you alter insulin concentration, you’re going to see signaling pathways in the endothelium that suggest that they are becoming less functional

⇒ For more, check out this article: [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/)

## Why Peter uses the oral glucose tolerance test (OGTT) with all patients [20:15]

**Oral glucose tolerance test (OGTT)**

- For understanding someone insulin level and insulin sensitivity, Peter prefers the OGTT test
- This is a test that has to be done the old-fashioned way at a doctor’s office (no at home test for this yet)
- The OGTT works by drawing your blood while you’re fasted, and it’s drawing glucose and insulin
- Then you drink a pre-formulated glucose drink called Glucola which comes in 50, 75 and 100 grams of glucose… Peter always uses the 75g formula to keep the test consistent
- After the patient drinks the glucola, they will draw the glucose and insulin levels 30, 60, 90, and sometimes 120 minutes later
- Peter is looking for a pattern of glucose and insulin concentrations over the two hours
- You should see the peak of insulin and glucose usually at 30 minutes, maybe at 60 minutes
- You tend to see peaks at 30 in insulin-sensitive individuals
- Peter is both looking for the number, meaning the actual concentrations of glucose and insulin, and also the pattern over the course of the 2 hours

**OGTT on every patient**

- We do it for every patient on day one when they come in
- There are some patients whom I would say the results of that test probably suggest that this is a test that they don’t need anytime soon again
- Then there are other patients in whom it really illustrates a significant issue and becomes the type of test we might do every six to 12 months.

⇒ For more on the OGTT test and what it can tell you, check out: [AMA #15: Real-world case studies—metabolic dysregulation, low testosterone, menopause, and more](https://peterattiamd.com/ama15/)

## Is there any evidence that hyperinsulinemia is an independent contributor to ASCVD? [23:00]

Hyperinsulinemia, as Peter explained, can have a role in ASCVD through lipid metabolism, but *is there any evidence that hyperinsulinemia is an independent contributor to ASCVD?*

- Peter says this an important question because we’ve already explained how insulin mediates so much of its effect through apoB
- But it then begs the question, *if you account for apoB, do you get any additional prediction from insulin?*

At look at the data…

The largest study that looked at this was a [Finnish study](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/415831) that looked at about 2,600+ men

- It sought to identify the relationship between hyperinsulinemia and all of the usual variables, obesity, hypertension, dyslipidemia, etc
- It prospectively followed men and divided them into quartiles of fasting serum insulin
  - You had the lowest quartile, second, third, and the highest
- If you looked at the raw data, you would see that the risk of ASCVD went up with quartile, but once the investigators corrected for lipids, blood pressure, BMI, etc., there was *no statistical significance*
  - That was even comparing the highest quartile to the lowest quartile
- Peter says, “That’s not surprising in the sense that I think most of the impact of insulin and hyperinsulinemia can be transmitted through apoB, either through LDL clearance directly and/or triglyceride concentration going up”
- They did see that there was some effect potentially on endothelial dysfunction, and that should actually be independent there
  - But it begs the question, *was fasting insulin the right metric?* Maybe it was. Maybe it wasn’t.

Another [study](https://drc.bmj.com/content/8/1/e001217) looked at this using a tool called [Mendelian randomization](https://peterattiamd.com/allansniderman/) (MR)

- MR works by finding genes (or SNPs) that are associated with the phenotype of interest and a sking the question, because those genes and those SNPs are going to be randomly distributed across a population, *how do the random distribution of those properties impact the outcome I care about?*
- In this particular study, they found 50 SNPs that were associated with insulin resistance and asked the question, *how does the property of IR as determined by these genes drive cardiovascular disease?*
  - They certainly found a strong prediction—Coronary artery disease, myocardial infarction, ischemic stroke, all of these things were statistically significantly associated with insulin resistance
  - The odds ratios that they found were anywhere from 20%, up to an 80% increase, in risk
- The limitation of this study can be found by asking the question: *What were they using to define insulin resistance?* ⇒ *In other words, what were they defining as the phenotype of interest?*
  - The phenotype that they were using was high fasting insulin, low HDL cholesterol, and high triglyceride level
  - Here’s the problem with that:
    - HDL cholesterol and triglycerides are generally captured very well in apoB
    - So it’s not entirely clear that this study chose the right metric through which to identify insulin resistance
    - By the way, it’s also not clear that even just high fasting insulin by itself as genetically determined, which is what it would be in this study, would also represent that
- Summary from Peter: “*This is a long-winded way of saying I’m not sure how strong the relationship is independently of insulin resistance once you correct for all of the other places where it shows up*.”

## Thinking through risk in the context of high-fat diets resulting in improved metabolic metrics but with an elevation of apoB/LDL-C [27:30]

**Hypothetical patient scenario (which is not uncommon):**

- A patient goes on a new diet (usually keto or carnivore) and
  - insulin levels go down
  - blood pressure goes down
  - They feel better, and lost some weight
  - But, they noticed an **increase** in apoB and/or LDL-C
    - S*hould they be concerned with this*?

*Peter’s response*:

- We see this most commonly in people who are going on diets that are really high in fat
- A not uncommon finding is a person goes on one of these diets, and they go from having a normal lipid profile to a very abnormal lipid profile
- It’s not uncommon for these people to look like they have familial hypercholesterolemia—meaning they have the lipid profile of people with a genetic disease that results in the impaired clearance of apoB particles
- These patients will show up with a total cholesterol level easily of 300 milligrams per deciliter, an LDL cholesterol level north of 200 milligrams per deciliter, a very high HDL cholesterol, 80 to 90 milligrams per deciliter, and low triglycerides
- That’s also accompanied by normal insulin signaling, so these are patients that are not insulin resistant

The question then becomes: *What has been the change in risk?*

- Let’s just say this person went from having some insulin resistance, so higher triglycerides, lower HDL, higher insulin, and relatively normal LDL cholesterol
- Now all of a sudden their LDL cholesterol is through the roof, HDL cholesterol has gone up, triglycerides have gone down, insulin has gone down
- There are a lot of people out there who are asserting that the risk is fine and there is no increase in risk
  - They say this even in the context of LDL cholesterol going from the 40th percentile to above the 99th percentile, and with it the apoB of course
  - And they says that this is not cause for alarm because insulin has come down, HDL cholesterol has gone up, and trigs have gone down

*Peter’s counterargument to those saying there is no increase in risk*:

- Triglycerides below the level of 400 are not predictive at all of ASCVD risk once you’ve corrected for apoB
  - In other words, all of the risk of the triglyceride is captured within apoB
  - So immediately, we now can say it doesn’t matter that your trigs went from 150 down to 50… “*That’s wonderful. It certainly suggests you’re more insulin sensitive*.”
- But if your apoB went from 80 to 180, your risk has gone up dramatically
- We know that that’s true of the HDL cholesterol as well
  - HDL cholesterol is one of the most confusing metrics out there
  - HDL really is all about function
  - It is not about the cholesterol content within it, the way LDL is
- We’ve also just established that while lower levels of insulin are probably better than higher levels of insulin, it’s not clear how much of that is true once you’ve corrected for apoB
- When apoB skyrockets in the presence of falling insulin and triglycerides, all evidence to date suggests your risk of ASCVD has not gone down
- It is therefore our position that if a person is on a diet that is creating benefits in some ways, for example, weight loss, amelioration of insulin resistance, but it’s driving apoB up, and they’re really serious about longevity and reducing the risk of disease, they basically have two choices
  - One is to abandon the diet
  - The other is to stay on the diet and take lipid lowering medication
    - And it’s not a “failure” to have to take a medication to lower apoB in the presence of a diet that is otherwise potentially working for somebody

## Thinking through risk in the context of low apoB but higher than normal triglyceride levels [32:15]

Nick asks a clarifying question: “*If your apoB has gone down and is in the 5th, 10th, or 20th percentile, but your triglycerides have gone up, you’re not worried about that because you care more about the apoB going down?*”

- Peter says, “Yes, this has been clearly established that as long as the triglycerides are below 400”
  - Once the triglycerides are above 400, you run into a world of different problems, like pancreatitis
- Again, for example, if you have an individual whose apoB is at the 50th percentile, whose triglyceride level is 100 milligrams per deciliter and then you put them on a medication that lowers their apoB from the 50th percentile to the 5th percentile, but their triglycerides in the meantime go from 100 to 150, **their risk has gone down, not up**
- Just for people to know, triglycerides of 400 is an abnormally high number for a *fasting level*
  - It’s not uncommon to see a level of 400 if you accidentally draw somebody’s blood after they’ve eaten
  - But if a person’s been fasting for 12 hours and their triglyceride level is over 400, they’re either profoundly insulin resistant or they have a genetic disorder that results in elevated levels of triglycerides
  - Peter says “We care very deeply about those because you have to make sure you’re addressing the remnant apoB problem”
  - To be clear, it would be almost impossible to imagine a scenario where a person’s apoB is in the 5th percentile when their trigs are 400
    - Why? ⇒ Because apoB has to include the VLDL, and the VLDL is impacted heavily by … meaning the concentration of VLDL has to be impacted heavily by the triglyceride concentration
  - It is not impossible, however, to believe that there’s a situation where your LDL cholesterol could be in the 5th percentile and your trigs could be in the top 0.01 percentile if they’re at 400
    - Why? ⇒ Because if you only look at LDL cholesterol, you can miss this type of pathology where the VLDL cholesterol is very high through the triglyceride burden (this is a great example of where apoB is essential)

***How does Peter look clinically at triglycerides? Are there certain things with patients that triglycerides alone tell you, or is it more how triglycerides are wrapped with the other lipid panel metrics?***

- He looks at the triglyceride every time he draws blood and asks the question, *what’s the ratio of triglyceride to HDL cholesterol?*
  - This is a poor man’s test of insulin sensitivity
  - We always want that ratio to be as low as possible—A great ratio is less than 1.0, meaning if your HDL cholesterol concentration is higher than your triglyceride concentration, you’re very likely quite insulin sensitive
- We also know that with elevated triglycerides comes an increase in the risk of NAFLD, so it just alerts us to pay attention to these things
  - Of course, he’s also looking at the liver function tests, the AST and the ALT

**Unique nature of apoB as a biomarker**

- ApoB is in some ways an exception and not a rule when it comes to biomarkers
- It’s a beautiful biomarker in that it aggregates so much information that you can really focus on it because, by itself, it tells you a lot
- That is NOT the case with a lot of biomarkers
- Example: Testosterone
  - Testosterone, which by itself communicates a lot of information, but if you don’t really know the sex hormone binding globulin and the free testosterone level, you don’t really know what’s going on there
  - Furthermore, if you don’t know how the patient feels, you really don’t know what’s going on there
  - Someone who’s got a testosterone level at the 50th percentile could feel totally fantastic.
  - hey could have a low sex hormone binding globulin and a high free testosterone and they’re great
  - Another person could have a high SHBG, a low free testosterone, and feel horrible
  - Or, you might have two people with the same level that feel completely different, and therefore you can’t just treat somebody or make a broad statement based on that.
- The same is true with triglycerides because we look at a bunch of other things
  - We want to see other metrics of insulin resistance. We want to look at the AST; the ALT; the homocysteine; the insulin, of course; the glucose; the A1C; the ferritin level.
  - All of these things communicate information to us, such that no one number in that suite is by itself complete

## The importance of lowering apoB for reducing ASCVD risk [38:15]

**ApoB is necessary, though not sufficient, factor in the development of ASCVD**

> “*ApoB is a necessary, though not sufficient, factor in the development of ASCVD which means the more you lower it, the more you lower risk. Full stop.*” —Peter Attia

The big three **modifiable** risk factors are *smoking, hypertension,* and *apoB*

- If a person says, “*I want to be able to take the #1 cause of death off my list of things I’m going to die from*.” …  We can do it, says Peter
- We can’t say that for the number two, number three, number four, and number five causes of death—We don’t have the tools to take the two through five causes of death off the list
- But we DO have the tool for number one
- In other words, the #1 leading killer of people is **the most preventable** if you’re willing to
  - a) not smoke,
  - b) if you are obsessive about maintaining normal to low blood pressure, so below 120/80
    - Lifestyle factors play an enormous role—Body weight, exercise, sleep, etc.
    - And if “lifestyle changes” are not working, there are lots of medications that can help.
    - But to allow your blood pressure to be higher than that is just leaving countless amounts of money on the table
  - c) keep apoB low
    - The more you lower it, the more your risk goes down
    - Peter loves the figure below because it shows three types of data that unambiguously show us this to be true

![](https://peterattiamd.com/wp-content/uploads/2023/01/f1-ama43-1024x593.png)

**Figure 1.** Credit: [Ference et al., 2017](https://pubmed.ncbi.nlm.nih.gov/28444290/)

- NOTE: This is all done in LDL cholesterol, so this is actually inferior to what you would see if you did this analysis with apoB, but it’s directionally showing you the same thing
- On the X axis, you are looking at a reduction in LDL cholesterol
  - This is shown in millimole per liter. I believe that one millimole per liter of LDL is roughly 40 milligrams per deciliter
  - The middle of the X axis, it says one millimole per liter, that’s about the equivalent of about a 40 milligram per deciliter reduction
- On the Y axis, you’re seeing the reduction in the risk of cardiovascular disease
- You have three lines on here
  - The lines are the best fits for three data sources
  - The first, the red ones, are all the randomized control trials
    - These are all the randomized control trials where patients are put on lipid lowering medication
    - They’re followed for about five years (median follow up time)
    - NOTE: One of the limitations of using RCTs to understand the magnitude of risk reduction is the short duration of which we do these studies
    - This is a disease of lifetime exposure to LDL
    - So if you only intervene for five years, which is understandable, that’s all you can do in an RCT, you would expect to see a lower magnitude of risk.

S*o what does this figure show us*?

- The red line shows you that if you drop it down by one millimole per liter, 40 milligrams per deciliter, over a five-year period of time, you’re going to experience about a 22% reduction in risk
  - Now, if the LDL-C reduction is lower, the risk reduction is higher, and vice versa
- Then you look at the gray data points (which are using prospective cohort studies)
  - These are not randomized. These are just following people over time
  - These have advantage of being able to go longer, but the disadvantage of not being randomized and therefore being subject to confounders
  - But not surprisingly here, you see a steeper line to the best fit curve
  - A steeper line means a greater risk reduction
  - In fact, in this cohort for people with a one millimole reduction in exposure to LDL-C, and again, this is now over 12 years, you’re seeing about a 32%, 33% risk reduction in CVD.
- The blue line on here is the Mendelian randomization study
  - This is very interesting because here you now have lifetime exposure
  - Remember how Mendelian randomization works. This is looking at your genes, and we know that LDL is heavily influenced by genes
  - What we can do with these studies is look at people who genetically acquire lower LDL levels and compare them to people with genetically higher LDL levels
  - the median followup here is 52 years which means that you have to look for an outcome. You have to look at a point in time when you see an event.
  - And you’re seeing this on average at about 52 years. So the duration at which you’re studying your subject is over a 52-year period, which means, again, longer period of time
  - Here I would argue you do have randomization because that’s what Mendelian randomization does (Nature does the randomization. Nature is putting genes into different people.)
  - Here with a one millimole reduction of LDL cholesterol, we’re seeing about a 52% to 53% reduction in risk

**The big takeaway**:

- To all the people who fit in the camp of saying “my LDL-C or my apoB don’t matter because of X”
  - And X can be because their on a keto diet or because my insulin is low
  - X can be literally anything they want to say, but it doesn’t matter
- There is **no scenario under which your risk is going down when your LDL-C and apoB are going up**
  - That’s true if you look at all of the body of literature in the randomized control trials
  - That’s true if you’re looking at all of the literature of the prospective cohort trials
  - And that’s true if you look at all of the Mendelian randomization.

> “*If you can find me another area of biology where it is so abundantly clear, I can’t wait to see it*.” —Peter Attia

## Data on men and women with familial hypercholesterolemia that demonstrates the direct impact of high apoB and LDL-C on ASCVD risk [47:45]

**Defining familial hypercholesterolemia (FH)**

- FH is a genetic condition
- It’s a very heterogeneous genetic condition, meaning there is not one genetic pattern that results in the disease
- In fact, there are over 3,000 genetic patterns that result in this disease
- This is a disease that is defined, therefore, by the phenotype and not the genotype
- Thousands of paths genetically to get this and most of them involve LDL clearance, so most of these involve the clearance of the low density lipoprotein by the liver
- Given that, we concern ourselves with is *what’s the phenotype?* ⇒ And the phenotype is an *LDL cholesterol over 190 milligrams per deciliter*

![](https://peterattiamd.com/wp-content/uploads/2023/01/f2-ama43-1024x437.png)

**Figure 2.** Credit: [Perak et al., 2016](https://www.ahajournals.org/doi/10.1161/circulationaha.116.022335#:~:text=Heterozygous%20familial%20hypercholesterolemia%20(FH)%20affects%20up%20to%201.5%20million%20individuals,250%20to%201%20in%20200.)

- In this graph, it’s comparing men and women, and the relative risk of ASCVD depending on age and depending on LDL cholesterol
- Let’s just consider the blue bars for the men right now
  - These are men with LDL cholesterol less than 130 milligrams per deciliter
  - on the Y axis, which is the height of the bar, is what is the number of events per thousand person years?
    - Not surprisingly, this monotonically rises to the right
    - In other words, for people whose LDL cholesterol is below 130 milligrams per deciliter, the older they get, the more events we have
- This is also true for women but there’s about a decade shift
  - If you look at the men who are 50 to 59, they have about the same ratio as women who are 60 to 69
  - If you look at women who are 70 to 79, they have about the same ratio as men who are 60 to 69.
  - This is, again, completely consistent with what’s been historically observed, namely that women are at equal risk for ASCVD if you shift by one decade
- Takeaways from this graph:
- There is an unambiguous association of ASCVD in people with FH (LDL cholesterol is over 190 milligrams per deciliter)
- What you’re comparing, instead of moving from left to right, you’re looking front to back
  - At any point in time, the risk is much higher for the people with the LDL cholesterol above 190 milligrams per deciliter compared to those below 130

**FH does not come with insulin resistance**

- Familial hypercholesterolemia is not accompanied by insulin resistance
- In other words, Peter has patients in his practice who have FH
- These are patients that have very, very high LDL-C, very high HDL-C, very low triglycerides, and they’re insulin sensitive
- In other words, they’re indistinguishable from many of the people who pursue a dietary pattern that creates that phenotype (e.g., keto)
- It’s crystal clear how much of a difference there is in risk.

> “*I’m really hammering this point [that apoB being high matters even in the context favorable metabolic metrics like high insulin sensitivity]. We’ve got all of the RCT data. We’ve got all the prospective data. We’ve got all the Mendelian randomization data, and now we’re looking at the FH cohort.*” —Peter Attia

## Importance of starting prevention early, calcium scores, and explaining causality [52:30]

**ASCVD is a disease that can take a long time to progress, which is why you have to worry about it so early in life**

- Going back to the analogy early on is if you start to apply brakes at a mile out compared to 100 yards out, it’s much easier to stop the car going over the cliff
- You can be fooled by some of the metrics that people who to deduce risk
- For instance, you’ll maybe hear people who 40 years old say, “Look, my LDL-C is like 250 and I did a CAC score and I had no calcium so obviously I’m in the clear.”
- Peter’s response to that person might be something like, “Yeah, that may be true if you’re looking at 10-year risk and you only want to live from 40 to 50”
- But everything you look at and everything you’re talking about with this is, again, looking at that **50-year risk**, and do you want to live from 70 to 80, 80 to 90, 90 to 95

**Being fooled by calcium scores**

*CAC scores have a 15% failure rate*

- It’s worth noting that 15% of calcium scores are false negatives, meaning for every hundred people who have a zero on their calcium score, 15 of them will have a positive finding on a CT angiogram
- This would mean they’ll either have calcium, they’ll have soft plaque, and as many as 1% to 2% of them will actually have unstable-appearing soft plaque
- When you have a 15% fail rate, you’ve got to be careful how much stock you put in it

*But let’s just look at the 85% of people who have a negative CAC and it’s a true negative*

- To say “*I’m not going to remove the causal factor in ASCVD because I don’t have calcium yet*” is like saying “*I’m a smoker and I just had a lung scan, and it shows that I don’t have lung cancer, therefore I’m going to keep smoking*”
- People fail to understand *causality*
  - When a causal risk factor is present, you remove the causal risk factor, full stop. That’s the way you guarantee that the disease stays away.
- Now it’s true, many people who smoke don’t get cancer. But does that in any way suggest that if you’re a smoker who quits smoking, you won’t reduce your risk?

- Autopsy of a 23 year-old man showing foams cells in the subendothelial space of his very proximal left anterior descending artery
- This is a guy that would’ve had a negative calcium score—there was no calcification there yet
- This case demonstrates how early this disease begins

## Defining Lp(a), its impact on ASCVD risk, and what you should know if you have high Lp(a) [56:30]

**For more on Lp(a), check out these resources**:

- [Episode with Benoît Arsenault on Lp(a)](https://peterattiamd.com/benoitarsenault/)
- [Episode #07: Deep Dive: Lp(a)](https://peterattiamd.com/lpa/)
- [Episode with Tom Dayspring (Part 5)](https://peterattiamd.com/tomdayspring5/)

\*\*\*

**What is Lp(a)?**

- Lp(a) is a subset of LDL
- When you have any measurement of LDL, if you have your LDL cholesterol measured, it’s including in it the Lp(a).
- most people, Lp(a) concentration is quite low. It doesn’t really contribute to ASCVD risk
- Anywhere from 8% to potentially as high as 20%, it really depends on the population, there is a threshold beyond which, typically 50 milligrams per deciliter, but maybe 30 milligrams per deciliter, above which we would say quote-unquote you have high Lp(a).
- Lp(a) is an LDL particle, so it means it’s complete with its apoB. But it also has another apolipoprotein on it called apolipoprotein little a
- when an apolipoprotein little a wraps onto an apoB LDL particle, it’s called Lp(a).
- Epidemiology is very clear that LP(a) is associated with a higher risk of ASCVD
- It’s also associated with a higher risk of aortic stenosis

**How much does reducing apoB reduce the risk of high Lp(a)? Is that the question?**

Another question: *If you have a high Lp(a), but your doing everything you can to keep a low apoB, should you still be concerned about your Lp(a) levels?*

- The answer is yes and no
- If you have a high Lp(a) and you’re doing everything medically possible to lower apoB and address all other factors associated with ASCVD, do you need to worry?
  - “I would say no because there’s no point in worrying because there’s nothing else you can do at the moment”
- But should you be paying attention? ⇒ Yes
- Why? ⇒ Because of two things:
  - 1) You want to make sure you’re also documenting the health of your aortic valve
    - The evidence is overwhelming that you don’t want to wait to replace an aortic valve until a person has significant aortic stenosis. You want to do this in a low state of disease.
  - 2) We want to keep our eye on the ball for new treatments
    - There is a drug right now in the pipeline, a drug called an [antisense oligonucleotide](https://pubmed.ncbi.nlm.nih.gov/27665230/), that very successfully reduces Lp(a)
    - Phase II [studies](https://www.nejm.org/doi/10.1056/NEJMoa1905239) have demonstrated very clearly that use of this drug, which blocks the synthesis of apolipoprotein little a in the liver will basically obliterate Lp(a)
    - if you take this drug, Lp(a) goes away. It’s in phase three studies now because the FDA understandably wants to know: *Does it also reduce events?*
    - If that trial is positive, this drug will be approved. Then that person should be paying attention so that we make sure we get those patients on those drugs
- But in the short term, if your Lp(a) is elevated, we need to take extra steps and be especially aggressive in lowering your apoB
  - That will reduce your risk, but it won’t reduce it to the level that a person is at when their apoB and Lp(a) are very low

## Lp(a) and ethnic differences in risk [1:00:30]

***What do we know about ethnic differences as it relates to Lp(a) as well?***

- There was a [study](https://academic.oup.com/eurheartj/article/43/39/3925/6670882) that was published this summer from the UK Biobank
- What they did is they looked at white and black people (Peter wishes they would’ve looked at Southeast Asian as well b/c in his experience, he sees the highest concentration of elevated Lp(a) in Southeast Asian)

![](https://peterattiamd.com/wp-content/uploads/2023/01/f3-ama43-1024x619.png)

**Figure 3.** Credit: [Kronenberg et al., 2022](https://academic.oup.com/eurheartj/article/43/39/3925/6670882)

- If you look at the left figures, A and B, what you’re seeing is the frequency distribution of Lp(a) concentration
- In both of these figures, the X axis is the same—It is showing the increase in concentration of Lp(a)
  - It’s doing this in nanomole per liter, as opposed to milligrams per deciliter
  - 170 nanomole per liter is 80 milligrams per deciliter, and 215 nanomole per liter is 100 milligrams per deciliter

*-But what do you see?*

- You see that black people are much more likely to have an elevation of Lp(a)
- We see a more spread out distribution than in white people
- In white people, you see a very sharp drop off, as opposed to a more spread out curve
- If you look at the percentage of people over 240 nanomole per liter, it’s 3.8% in white individuals, 6.9% in black individuals
- You can see that at every cutoff point, you’re going to see a higher frequency in the black population than the white population
- On the right hand side of this curve, you want to look at what’s the implication from cardiovascular disease?
- This actually surprised Peter—he had been under the impression that Lp(a) was less virulent in a black population
- In other words, he knew that black individuals were more likely to have high Lp(a), but he thought that, based on empirical observation which was clearly wrong, that it didn’t come with as high a risk

*-If you look at C and D, the sub-figures, what do you see?*

- The line is showing you that as Lp(a) concentration goes up, so too does the hazard ratio
- Here’s what’s interesting:
  - The graphs aren’t all that different. What’s very different is the variability
  - what you’re seeing in the shaded area is the 95% confidence interval
  - If you look at white individuals, and what we’re doing by the way is in this figure comparing the hazard ratio for a given Lp(a) to the reference Lp(a) (reference is the median of the population)
  - The median of the population is 20 millimole per liter, which is about 11 milligrams per deciliter.
  - You can see that it gets up to 2.7 hazard ratio, but with very tight 95% confidence interval in the white population
  - In the black population, it gets up to about 2.6, 2.7 as the hazard ratio. So directionally the same, but look at the size of the 95% confidence interval
  - to me what’s interesting here, and this maybe explains why you can be misled when you’re looking at 10 individuals, because the variability is so great
  - whereas in the white population, the variability is actually very tight
  - “*That’s a very interesting observation as it dispels at least one of the myths that I believed*.”

## Why someone with elevated Lp(a) should consider being more aggressive with apoB lowering strategies [1:05:00]

***If someone listening does have a high Lp(a), low levels of apoB just naturally without pharmacological interventions, is there still a benefit for them to think about lipid lowering therapies?***

- The answer is yes
- In a patient with low Lp(a), even if their apoB is 80 milligrams per deciliter, it should still be lowered in Peter’s opinion
- Why? ⇒ You’ve got the number one cause of death (ASCVD), and you can make it the number 10 cause of death.
- All you have to do is not smoke, have perfect blood pressure, and have apoB concentration below the fifth percentile
- If you do those things, it’s really hard to get ASCVD
- So yes, everybody in my book should have apoB reduced provided they can tolerate the treatment that’s necessary to do that

*When it comes to patients with high Lp(a), there’s a special consideration*:

- There’s one class of drug on the market today that at least has some chance of lowering Lp(a), and that is the PCSK9 inhibitors
- Our first line lipid lowering medication in patients with elevated Lp(a) is not a statin but is, in fact, a PCSK9 inhibitor, which on average probably reduces Lp(a) concentration by about 30%.
  - Note that for some patients it will be a 60% reduction, and in others almost no reduction
- It remains to be seen whether that has any bearing on outcomes
  - It might be that reducing Lp(a) by 30% isn’t enough, but it’s certainly better than increasing the risk
- But given that what we’re doing primarily is lowering apoB, that would be my preferred approach.

## Addressing the common feeling of hesitancy to taking a pharmacologic approach to lower ASCVD risk [1:07:15]

- Sometimes people are opposed to pharmacological interventions because maybe they don’t want the side effects or maybe they don’t think it can work
- But there’s other patients where they might just psychologically feel that if they take a medication, it admits failure, it admits defeat
- The point here is we have these drugs at our disposal, and utilizing them doesn’t necessarily mean anything negative about the person that has to utilize them.
- We should get over that hump because, as we said, if we want to really fight this number one cause, we need to use everything at our disposal

**Peter adds the following regarding the skepticism around big pharma**:

- There’s a little bit too much black-and-white thinking around this space
- And everything that transpired as a result of COVID has only made this worse
- For very understandable reasons, the public has grown far more skeptical of big pharma
- There were a lot of the shenanigans around claims that were made with respect to the COVID vaccine that turned out not to be true (when it was known that they were not true)
- That’s the part that many people struggle with
- Again, the COVID vaccines are safe, but…
  - The vaccines absolutely reduce the risk of hospitalization and death, but they didn’t really reduce the risk of transmission
  - And the magnitude of the reduction in healthy people was questionable
  - There were side effects that were not acknowledged
- It’s very hard to hold all of these conflicting truths simultaneously, such as…
  - Vaccine worked
  - It was mostly safe, but not 100% safe (but what drug is 100% safe?)
  - But there was so much polarized talking on all of this that if you got caught in the crosshairs of this, you come away from this thinking some crazy thoughts like… “COVID was basically one big conspiracy theory to prop up the profitability of pharma” … which of course isn’t true
  - But did pharma profit greatly off COVID? ⇒ Yes, they did

*So how do you reconcile these things?*

- You have to reconcile them by saying that it’s true that pharma can make a product like lipid lowering drugs on which they profit, and yet it’s true that those drugs can extend your life—Those two factors can coexist.
- It’s important to be able to think in a manner that’s called dialectically, which is simultaneously hold things true that seem contradictory
- It seems contradictory that a company can make money selling you a drug and that that drug can actually improve your life.
- You might be thinking that it “should” be that if somebody’s making money on you, it should be hurting you…But if you think about it, that’s a *very illogical position*
  - For instance, I go to a gym and I pay them a membership. By definition, they can’t be breaking even on me. They have to be making money on me to go to the gym.
  - But does that mean going to the gym is bad? ⇒ No
  - If I go to the gym and do the right exercises, it’s good for me, while they are simultaneously making money on me
- “*I just think we need to be a little bit more selfish and say, what can I extract benefit-wise on the back of companies that are themselves trying to make money*?”
- Can they make money producing something, and can I profit in terms of my life? ⇒ I think the answer is yes
- You also have to be able to say that that can be true for some drugs and not true for others
  - There can be some drugs that are totally useless
  - there are a number of chemotherapeutic agents that are out there that offer no benefit to the patients—meaning the risk is very high, the toxicity is extremely high, and the reward is very low
  - There are literally drugs that have been approved that extend life by a month and cost $40,000
  - you can say that that’s a situation where the risk-reward trade-off for the patient is so poor and the profits are so high for the pharma company that it seems unethical
  - Yet that doesn’t tell you about another situation

“*What you’re hearing is just an incredible frustration in me that exists in people who don’t have the capacity to think through a nuanced lens*.” —Peter Attia

**The gift of apoB as a biomarker**

- Peter is worried about scenarios where people say, “*ApoB, LDL-C, it’s all a hoax. It’s all pharma’s ploy to get you to buy drugs*.”
- Or people who say, “The only thing you need to do to not ever have heart disease is stop eating sugar.”
- Or the people that say, “As long as your trigs are low and your insulin is low, you can’t get heart disease.”
- That that type of reasoning is dangerous
- There you’re dealing with somebody who either is willingly ignoring information or who’s decided they don’t want to understand the process

*It’s very sad because we do have this gift*

- The gift is of all of the horseman of disease, the one that is the number one killer is the one for which we have:
  - the most understanding of how the disease works,
  - we have the most understanding of how to prevent it,
  - and we have the most tools at our disposal, pharmacologic and otherwise to reduce risk

\*\*\*

**More resources:**

- [AMA 34](https://peterattiamd.com/ama34/)
- [Episode with Allan Sniderman on CVD](https://peterattiamd.com/allansniderman/)
- [Episode with Benoît Arsenault on Lp(a)](https://peterattiamd.com/benoitarsenault/)
- [Many podcasts with Tom Dayspring](https://peterattiamd.com/tomdayspring1/)

## Peter’s take on the 2022 Formula 1 season and thoughts on 2023 [1:15:15]

***What’s your take on the F1 season this year? Are you happy with it? Was it exciting? What was most interesting?***

- For me, it’s always exciting
- But no, the season was not as exciting as last year (may not ever be as good as the 2021 season)
- In this season, you saw one of the most dominant performances ever by a given driver ([Max Verstappen](https://en.wikipedia.org/wiki/Max_Verstappen) with [Red Bull](https://en.wikipedia.org/wiki/Red_Bull_Racing)), given that you have an exceptional driver in an exceptional car
- But the reason that his performance rose to the level of being so great is that his main rivals, Mercedes and Ferrari, floundered for different reasons
- In the case of Mercedes,
  - they really didn’t get the car designed right at the beginning of the year, and they spent the first half of the season not even being a threat
  - Only at the end of the season in the last four or five races did they come on as a threat and you saw what could’ve been
  - In other words, it’s not so much that Red Bull did something otherworldly, it’s that Mercedes made such a mistake in car design
- In the case of Ferrari,
  - Peter says “I’ve never seen such a collection of incompetent individuals at the top level of a sport.”
  - They truly are the world’s most incompetent team
  - They started the year with a car that was better than the Red Bull but through what can only be described as a comical display of incompetence, they basically give away any chance of being competitive
- The history books might look back and say, “Well, Max won this year, set all these records, most wins, most points, et cetera, and it was just because the Red Bull was such a competitive car.”
- But the reality is that the two other cars that should’ve been side by side made these bit mistakes
- But all of this points to next year being a really exciting year.

**Predictions for how the 2022 season ends**:

*Who ends the year number two in the driver rankings?*

- Peter, to date, has only watched up through free practice two
- FP two is generally the most indicative practice to give you a sense of what people really have for race pace
- [Charles Leclerc](https://en.wikipedia.org/wiki/Charles_Leclerc) with Ferrari performed better in FP two than [Sergio “Checo” Perez](https://en.wikipedia.org/wiki/Sergio_P%C3%A9rez)
- So Peter would give a slight advantage to Leclerc
- Conversely, “Ferrari is Ferrari and they just have a demonstrated capacity to screw everything up”
- So it’s too close to call because Leclerc a better driver, but they can always screw things up
- After this recording, [Leclerc did in fact finish #2 and Checo was #3](https://racingnews365.com/formula-1-standings-2022)

**Early predictions from Peter for the 2023 F1 season**

- “*Assuming Ferrari does NOT change leadership, I think it’s going to be between Red Bull and Mercedes next year…*”

“*If Ferrari has a leadership change, then I think they might be competitive again, but the team principle of Ferrari is a clown.”*

§

## Selected Links / Related Material

**AMA #34 all about heart disease**: [#203 – AMA #34: What Causes Heart Disease?](https://peterattiamd.com/ama34) | Peter Attia (peterattiamd.com) [2:30, 9:15, 12:45, 52:30]

**Episode of The Drive with Benoît Arsenault discussing Lp(a)**: [#210 – Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.](https://peterattiamd.com/benoitarsenault/) | Peter Attia (peterattiamd.com) [2:30, 56:30, 1:00:30]

**Episode of The Drive with Allan Sniderman discussing apoB**: [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/) | Peter Attia (peterattiamd.com) [2:30, 12:45, 25:15]

**Episode of The Drive with Gerard Shulman discussing insulin resistance**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia (peterattiamd.com) [2:30, 13:30]

**Episode of The Drive discussion the concepts of Medicine 2.0 and Medicine 3.0**: [#231 – AMA #41: Medicine 3.0, developments in the field of aging, healthy habits in times of stress, and more](https://peterattiamd.com/ama41/) | Peter Attia (peterattiamd.com) [8:30]

**Episode of The Drive with Nir Barzilai where they mention the APOC3 gene**: [#204 – Centenarians, metformin, and longevity | Nir Barzilai, M.D.](https://peterattiamd.com/nirbarzilai2/) | Peter Attia (peterattiamd.com)[14:30]

**Finnish study that looked at how much prediction you’d get from insulin metrics if you account for apoB**: [Hyperinsulinemia and the Risk of Cardiovascular Death and Acute Coronary and Cerebrovascular Events in Men The Kuopio Ischaemic Heart Disease Risk Factor Study](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/415831) (Lakka et al., 2000) [23:30]

**Mendelian randomization study suggesting not much evidence that insulin resistance is an independent factor of CVD risk once you correct for apoB**: [Causal associations of insulin resistance with coronary artery disease and ischemic stroke: a Mendelian randomization analysis](https://drc.bmj.com/content/8/1/e001217) (Chen et al., 2020) [25:00]

**Data showing that lowering LDL-C and apoB lowers ASCVD risk**: [Relation of cholesterol-year score to severity of calcific atherosclerosis and tissue deposition in homozygous familial hypercholesterolemia](https://www.sciencedirect.com/science/article/abs/pii/S0002914997893095) (Schmidt et al., 1996) [40:15]

**Peter’s instagram post about the deceased young man already showing early signs of ASCVD**: [@PeterAttiaMD](https://link) [55:30]

**Episode of The Drive that dives deep in Lp(a)**: [#07 – Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know](https://peterattiamd.com/lpa/) | Peter Attia (peterattiamd.com) [56:30]

**Episode of The Drive with Tom Dayspring where they discuss Lp(a)**: [#24 – Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](https://peterattiamd.com/tomdayspring5/) | Peter Attia (peterattiamd.com) [56:30]

**Literature on a drug called an antisense oligonucleotide showing potential to lower Lp(a)**: [59:30]

- [Antisense oligonucleotides targeting apolipoprotein(a) in people with raised lipoprotein(a): two randomised, double-blind, placebo-controlled, dose-ranging trials](https://pubmed.ncbi.nlm.nih.gov/27665230/) (Viney et al., 2016)
- [Lipoprotein(a) Reduction in Persons with Cardiovascular Disease](https://www.nejm.org/doi/10.1056/NEJMoa1905239) (Tsimikas et al., 2020)

**Studying looking at Lp(a) and ethnic differences in CVD risk**: [Lipoprotein(a) in atherosclerotic cardiovascular disease and aortic stenosis: a European Atherosclerosis Society consensus statement](https://academic.oup.com/eurheartj/article/43/39/3925/6670882) (Kronenberg et al., 2022) [1:00:45]

§

## People Mentioned

- [Benoît Arsenault](https://iucpq.qc.ca/en/research/researchers#760) [2:30]
- [Allan Sniderman](https://www.cardiomuhc.ca/allan-sniderman) [2:30, 8:15]
- [Gerard Shulman](https://medicine.yale.edu/profile/gerald-shulman/#:~:text=Shulman%20is%20the%20George%20R,the%20Yale%20Diabetes%20Research%20Center.&text=Shulman%20is%20the%20recipient%20of%20the%20Stanley%20J.) [2:30]
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) [14:30]
- [Taylor Swift](https://en.wikipedia.org/wiki/Taylor_Swift) [45:30]
- [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) [56:30]
- [Tom Dayspring](https://twitter.com/drlipid) [56:30]
- [Max Verstappen](https://en.wikipedia.org/wiki/Max_Verstappen) [1:16:00]
- [Charles Leclerc](https://en.wikipedia.org/wiki/Charles_Leclerc) [1:18:30]
- [Sergio “Checo” Perez](https://en.wikipedia.org/wiki/Sergio_P%C3%A9rez) [1:18:30]

§