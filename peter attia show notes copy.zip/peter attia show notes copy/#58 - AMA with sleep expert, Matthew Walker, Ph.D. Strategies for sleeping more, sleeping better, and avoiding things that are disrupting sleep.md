# #58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep

**Source:** [https://peterattiamd.com/matthewwalkerama/](https://peterattiamd.com/matthewwalkerama/)

---

##### Check out more content with sleep expert, Matthew Walker, Ph.D.:

- *(April 1, 2019)* [Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, and memory](/matthewwalker1/)
- *(April 8, 2019)* [Part II of III: Heart disease, cancer, sexual function, and sleep disruption](/matthewwalker2/)
- *(April 15, 2019)* [Part III of III: The penetrating effects of poor sleep from metabolism to genetics](/matthewwalker3/)
- *(June 17, 2019)* [AMA #1: Strategies for sleeping more and sleeping better](/matthewwalkerama/)
- *(October 28, 2019)* [AMA #2: short sleep mutants, optimal sleep environment, & sleep apnea](/matthewwalkerama2/)
- *(August 31, 2020)* [Sleep & Covid-19: Sleep and immune function, chronotypes, and hygiene tips](/matthewwalker4/)
- *(September 7, 2020)* [AMA #3: Fasting, gut health, blue light, caffeine, REM sleep, and more](/matthewwalkerama3/)

In the first three parts of our [series with sleep expert Matthew Walker](https://peterattiamd.com/matthewwalker1/), Matt revealed the many reasons why we need sleep as well as the many short- and long-term dangers of not sleeping enough. In this special AMA episode, Matt comes back to provide a dissertation on listener’s questions about HOW to sleep. He answers questions from subscribers that largely focus on the practical and tactical ways we can improve our sleep in terms of duration, quality, consistency, and avoidance of the common things that are standing in the way the best sleep possible.

If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Matthew’s TED Talk, and his favorite public speakers [3:40];
- How good are the current sleep trackers like Oura, Fitbit, etc.? [6:45];
- Is it bad to eat food too close to bedtime? [11:40];
- How does exercise impact sleep? [13:15];
- How is appetite affected by our sleep quality? [17:30];
- Anxiety, cortisol, and weight gain: An awful feedback loop of sleep deprivation [19:30];
- How to optimize your wind down routine: lights, temperature, & relaxation [22:10];
- How alcohol disrupts sleep (and contributes to Alzheimer’s disease) [42:00];
- Sleep’s impact on sex hormones, and romantic relationships [46:00];
- Performance, accuracy, and minimizing the damage of shift work [51:30];
- Bed partners: How to sleep in separate beds and retain a good relationship [55:30];
- Can we use sound machines and electrical stimulation to improve sleep? [57:40];
- Will we ever be able to “supercharge” our sleep stages using technology? [1:03:30];
- Why sleep is the best insurance policy for lifespan and healthspan [1:07:45];
- Melatonin: How (and how not) to use it for sleep improvement [1:15:00];
- The dangers of sleeping pills, useful alternatives, and cognitive behavioral therapy for insomnia [1:24:30];
- Can CBD and THC be used for sleep? [1:39:30];
- Why haven’t we been able to develop a really effective sleeping aid? [1:46:40];
- Can you get too much sleep? [1:51:50];
- What to do (and not do) immediately following a terrible night of sleep? [2:04:15];
- Why a consistent wake up time is king [2:10:30];
- Does poor sleep speed up the aging process? [2:12:00];
- Can different people be more (or less) resilient to sleep deprivation? [2:18:50];
- Finding your optimal sleep schedule and determining your sleep chronotype [2:23:45];
- Defining sleep efficiency and how to improve it [2:29:25];
- Correcting insomnia: A counterintuitive approach [2:31:45];
- How can parents improve the sleep of their kids? [2:37:30]; and
- More.

**SPECIAL ANNOUNCEMENT**: Based on your feedback, we are excited to announce the launch of our exclusive, members-only podcast feed. This allows subscribers to listen to every episode of *The Drive* without the subscriber callout, plus full episodes of our members-only AMA podcasts, and other exclusive content directly in your podcast player. Learn how to get set up with a couple of taps [here](https://peterattiamd.com/members/private-podcast-feed/): (be sure that you are logged in).

§

The Peter Attia Drive

Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep

§

## Show Notes

## Matthew’s TED Talk, and his favorite public speakers [3:40]

Matthew recently gave a TED Talk: [Sleep is your superpower](https://www.ted.com/talks/matt_walker_sleep_is_your_superpower/up-next?language=en)

Matthew’s favorite speakers:

- [Carl Sagan](https://en.wikipedia.org/wiki/Carl_Sagan)
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman)
- [Ken Robinson](https://en.wikipedia.org/wiki/Ken_Robinson_(educationalist)) ⇒ TED Talk: [How to escape education’s death valley](https://www.ted.com/talks/ken_robinson_how_to_escape_education_s_death_valley)

> “They transcend being an exquisite public speaker into being someone who is just so compelling because they add to this sprinkle layer on top called wonderment.”

## How good are the current sleep trackers like Oura, Fitbit, etc.? [6:45]

What can the common sleep trackers tell us about sleep?

- **Best at**: Estimating total duration of sleep (Two-class model)
- **Pretty good at**: Determining where you’re in awake, non-REM, and REM (Three-class model)
- **Least accurate when**: Estimating your time split between 4 stages… awake, light non-REM, deep non-REM, and REM (Four-class model)

⇒ Matthew says don’t fret: “I wouldn’t get too nervous about some of your sort of deep sleep versus light sleep numbers. Some of them could be accurate within an individual, but for others it can be more tricky because of their physiology that’s not giving the right signals for class accuracy.”

**Trend lines** and **relative changes** are more important

- Once you establish some kind of baseline and you see a deviation from that baseline, it’s more than likely that that deviation is a real deviation rather than a problem of the technology because the technology, even though it’s errorful is consistently errorful night after night after night
- So any variance from your baseline is where you want to focus more of your attention
- Trendlines: Matthew advises to pay most attention to your **weekly trend line**s when using a sleep tracker

**The Oura ring**

- Peter uses (and is an investor and advisor) the [Oura ring](https://ouraring.com/)
- He says that the Oura ring is also very good at measuring and tracking:
  - [Resting heart rate](https://ouraring.com/heart-rate-while-sleeping/) while sleeping
  - [Heart rate variability](https://ouraring.com/heart-rate-variability-basics/)
  - [Body temperature](https://ouraring.com/body-temperature-trends/)
  - [Movement](https://ouraring.com/activity-score/)

⇒ More regarding heart rate

Peter: “When your resting heart rate is up seven beats per minute and your heart rate variability is down 20%… those are bad things.”

*What can cause these heart rate issues?*

- For Peter at least… it is typically:
  - The room was boiling hot
  - Ate a monster meal 10 minutes before bed
  - He had two alcoholic drinks or more
  - Jet lag

## Is it bad to eat food too close to bedtime? [11:40]

Matt advises cutting off all eating at least **3 hours before bed**

⇒ Two main reasons why:

- **First**, the principal reason is just because when you lie down, you’re more likely to get acid reflux, more likely to have digestive issues
- **Secondly**, because it can raise your core body temperature
  - You need to drop your core body temperature by about two to three degrees Fahrenheit to initiate sleep and then to stay asleep
  - That’s why it’s easily to sleep in a cold room than a hot room

\*\*If you must have something to eat close to bed because you are too hungry to sleep, avoid simple carbs because those will actually just get translated more quickly into energy and ultimately a heat index

## How does exercise impact sleep? [13:15]

*Is it bad to exercise too close to bedtime?*

- Yes, it can be
- Firstly, exercise increases core body temperature and keeps it elevated for a while
- Secondly, hormones are changed
  - epinephrine, norepinephrine, adrenaline, and cortisol
- \*Matt advises **not to exercise within 2 hours of your bedtime**

*Is exercise earlier in the day good for sleep?*

- Yes
- For the most part, exercise, anything that is before two hours of sleep is a fantastic tool in terms of sleep promotion

*Can getting good sleep improve exercise?*

- Yes, sleep profoundly helps exercise
- It’s a two-way street, so it’s beneficial both way, but the evidence is strongest in that sleeping well improves exercise

*In what ways does good sleep improve exercise?*

- Your motivation to do anything (especially exercise) is increased dramatically
- [Peak muscle strength increases](https://www.ncbi.nlm.nih.gov/pubmed/29422383) (in compound movements)
- Your ability to respire and expel carbon dioxide is improved the more sleep that you’re getting
- Likelihood of [injury risk markedly decreased](https://www.ncbi.nlm.nih.gov/pubmed/25028798)
- Your ability to even sweat and perspire is determined by how much sleep that you get
- The [time it takes to reach physical exhaustion increases](https://www.ncbi.nlm.nih.gov/pubmed/7199438)

## How is appetite affected by our sleep quality? [17:30]

When you are sleep deprived:

- The brain receives is a signal that is not dissimilar to starvation
- It releases a cascade of hormones that change your appetite profile
- So you’ll want to eat more
- And you’re less satisfied after you eat food

Why?

- Human beings seem to be the only species that will deliberately deprive themselves of sleep for no apparent reason
- The only other time that we see this in the wild where it does seem to have an impact is when animals are under conditions of starvation
- So when the body undergoes sleep deprivation, the brain thinks, “Oh, I must be under conditions of starvation… I must stay awake and forage for food.”
- But it’s a “fake starvation signal” which i[ncreases a hormone called ghrelin (which makes you want to eat more) and it suppresses a hormone called leptin (which gives you a feeling of fullness)](https://www.ncbi.nlm.nih.gov/pubmed/17308390/)

> “Overall, hunger levels go up, you start to eat more. Now, we combine that with this lack of motivation of exercise in all sorts of obesogenic directive territory. Eating more, wanting to exercise less. You’re burning fewer calories. That usually is why we’re starting to understand part of the sleep-dependent obesogenic equation.”

## Anxiety, cortisol, and weight gain: An awful feedback loop of sleep deprivation [19:30]

**Cortisol and weight gain**

- Peter says cortisol also plays a role in weight gain
- It is a very anabolic hormone to adipose tissue and a very catabolic hormone to muscle tissue
- It also affects the liver and glycogen stores via hepatic glucose output ⇒ It’s raising glucose, which in turn is raising insulin, which is now acting alongside cortisol

Chronic undersleeping

- Chronic undersleeping (most Americans) leads to hypercortisolemia
- That is then causing a cascade of biology that is nonoptimal

⇒ Example, more cortisol means more anxiety

- More anxiety means less sleep
- Less sleep means more cortisol (and more anxiety)
- An awful feedback loop

*Evolutionary reason for this?*

- The animal is sleep deprived, which is an evolutionary trigger that there’s a reason you’re sleep deprived, therefore you will need more cortisol

> “We’ve imposed sort of the mental Saber-Tooth Tiger, which is called society-triggered anxiety.”

For more on cortisol, and the role of cortisol in the subacute level of stress, see [Peter’s interview of Robert Sapolsky](https://peterattiamd.com/robertsapolsky/)

## How to optimize your wind down routine: lights, temperature, & relaxation [22:10]

**Lighting**

“*[Light] is probably one of the most underappreciated factors that is contributing to poor sleep.*”

- Matt says we are a “dark-deprived society” and our lighting is fooling your brain into thinking that it’s still daytime
- Dusk would usually tell our brain to release melatonin to get us prepared for a healthy sleep cycle

Quick Tips:

1. Simply switch off most of the lights starting 90 min before bed
2. Avoid blue light (e.g., iPhone/iPad screens and LED bulbs)

- Longer wavelength light (“blue light”) puts the breaks on melatonin release more so than the warmer colored lights
- *Why?* ⇒ One theory is because we evolved in the ocean and the light that we used to help regulate our circadian rhythm to bring us awake was the sun shining through the water (“blue light”)
- Some people will can go to the extreme of installing red bulbs to elimate all blue light in the evenings…
- But for most people, just dropping down half of the lights in the last hour or so before bed will help greatly

**Temperature**

- Most people keep their bedrooms too warm at night
- Ideally, bedroom temp should be **65-68 degrees fahrenheit**

*⇒ But what if this feels too cold??*

- The problem is that your extremities get too cold in those temperatures
- Hack the system by wearing socks or putting a hot water bottle by your feet
- You have to warm up your feet and your hands to essentially then evacuate the heat
- Use them as massive radiators, and that charms the blood from the core of the body out to the surface and then it is released
- Warming your feet and your hands before bed with socks and hot water bottle means that those feet start to get more blood supply that draws the blood and temperature away from your core
- Your core body temperature drops, and that’s great, and then you’re fast asleep and your body is now being cooled by the temperature that you’ve set at night

Hot shower before bed

- A hot shower (or sauna) before bed will bring the blood to the surface
- When your surface is warm, it dumps all of the heat from the core of your body

**Relaxation**

In the last hour before bed, try to find a wind-down routine that involves at least one of the three following:

1. Relaxing body movements
2. Meditation
3. Journaling

*Body relaxation*

- Light stretching
- Light movement
- Nothing strenuous

*Meditation*

- Matt was originally skeptical of meditation for improving sleep
- But he says the [data is very strong with insomnia patients](https://www.sciencedaily.com/releases/2009/06/090609072719.htm)
- Matt now consistently practices meditation
- Matt says **meditation is particularly helpful for people who struggle with falling asleep due to their mind racing** when the get in bed and close their eyes

*Journaling*

- Writing/journaling before bed can [decrease the time it takes to fall asleep](https://www.ncbi.nlm.nih.gov/pubmed/29058942)
- An hour before bed, take out some paper and just **write down all the concerns you’re having** and finish with three things you are grateful for
- Sounds “hokey”, but “science is pretty impressive” says Matthew
- That has been shown to actually **decreases the time it takes for insomniacs to fall asleep by about 50%**

*Positive vs. negative thoughts*

⇒ [Studies about mood](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4185310/) show…

- When a person is in a negative mood state:
  - It takes them longer to fall asleep
  - Sleep is worse
- If you put them in a positive mood set
  - Fall asleep faster
  - Sleep is better
- \*This is why ending your journaling with positivity is important

**Peter’s tip:**

- Avoid email and social media an hour from bedtime
- Doing this consistently improves Peter’s deep sleep scores

**The point is this**: Things that cause stress and anxiety (e.g., emails, social media) not only make it harder to fall asleep even when you’re tired simply because you are ruminating over negative thoughts (“wired and tired”), but it also release cortisol which is a stress hormone that promotes wakefulness (insomnia patients get a spike in cortisol right after getting in bed)

**More tips from Matthew:**

*1) Remove clocks from the bedroom* ⇒ For some people, knowing the clock time elicits anxiety (“*I can’t believe it’s 2 AM and I’m still awake!*”)

*2) Don’t lie in bed awake for very long*

- Your brain is this remarkably associative device and if you lie in bed awake, very quickly it will land that your bed is the place of being awake, not being asleep
- Break that association, get out of bed, go somewhere different, in dim light, just read a book or something along those lines and only return to bed when you’re sleepy

## How alcohol disrupts sleep (and contributes to Alzheimer’s disease) [42:00]

> “Alcohol is the most misunderstood sleep aid.”

Alzheimer’s disease

- Peter: “I think you could potentially make a case that the association between alcohol consumption and Alzheimer’s disease could potentially be mediated almost entirely through the absolute destruction of sleep that alcohol causes.”
- Matt says he routinely sees an [association between fragmented sleep and Alzheimer’s disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3669060/)

Two forms of “quality” sleep:

1. Consistent bedtime and wake up time
   - Our bodies love consistent rhythm
   - And when you force it out of that rhythm, your circadian rhythm as a consequence is markedly disrupted
2. Continuous sleep during the night
   - Meaning continuous sleep with as few awakenings as you can
   - This is where alcohol is vicious: “It will litter your sleep with numerous awakenings and those numerous awakenings mimic exactly what we see as a sleep phenotype that **predisposes you to a higher Alzheimer’s disease risk**.”

How alcohol affects sleep:

- Frequent wake ups (fragmented sleep)
  - Note: Many people aren’t even realizing they are waking up a ton
- You’re basically vacillating between non-REM light and one-minute wake-ups where you’re not fully awakened conscious
- Alcohol inhibits vasopressin, so it’s a potent diuretic, which means you’ll need to get up to urinate more frequently
- It also negatively impacts: resting heart rate, heart rate variability, temperature and respiratory rate ⇒ “*It’s devastating.*”

> “Fragmented sleep we know seems to be a predisposing factor for greater likelihood of amyloid and tau pathology, which are the two proteins that seem to contribute right now to Alzheimer’s.”

## Sleep’s impact on sex hormones, and romantic relationships [46:00]

Sleeping with a bed partner

- Sleeping with someone who snores or moves around a lot can contribute to poor sleep
- Sleep apnea is a very serious condition that can “strip years from your life if it’s untreated”
- About 80% of people who have sleep apnea are currently undiagnosed
- Sleep apnea/snoring can cause poor sleep in both people in the same bed

Sleeping in separate beds

- Matthew says some people should consider a “sleep divorce” where you sleep in different beds/rooms
- When surveyed:
- About 40% of partners admit to sleeping in separate beds
  - And of the 60% who start in the same bed, about 30% of those will switch beds in the middle of the night and wake up in another bed

*Does sleeping in separate beds means you have a bad relationship?*

- The data says the opposite is true
- For those who choose to sleep in separate rooms, they have better sleep quality
- Better sleep quality leads to a better mood
- Better mood leads to improved interpersonal relationships (more patience, more energy for each other)

⇒ Sexual hormones

- Sex hormones that are highly dependent on sleep
- Men who are sleeping just sort of four to five hours a night, will have a [level of testosterone which is probably 10 years aged](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4445839/)
- In females, for every one hour of extra sleep that a female gets, they have somewhere between a [13 to 15% increase in the desire to be intimate with a partner](https://www.ncbi.nlm.nih.gov/pubmed/25772315)

> “When you are sleeping separately, if that’s what you feel you need, your mood is better. Your relationship is better. And you’re much more likely to have a more fulfilling physical relationship intimately with your partner.”

*When it does NOT make sense to medically correct testosterone in a male?*

- Peter says it’s an error to correct low testosterone in a male **if the FSH and LH are low and the patient is not sleeping well**
- Sure you could give them testosterone exogenously, and you could fix that
- But… when someone has low testosterone and has inappropriately low FSH and LH (the hormones that would tell the body to make more) are **you have to correct the sleep**

⇒ Peter’s experience with sleep and low-T

- When Peter finished residency (and basically never slept)… his total testosterone was 220 nanograms per deciliter
- That was three standard deviations below his age appropriateness

## Performance, accuracy, and minimizing the damage of shift work [51:30]

**Accuracy**

- Peter relays a story from a friend of his [Jake Muise](https://www.instagram.com/deer4dinner/?hl=en) who runs a hunting operation out of Hawaii
- Jake says they control the over populated axis deer by hunting them from a long distance in the middle of the night
- It’s incredible vital that their shots are extremely accurate so the animal dies immediately and feels no pain
- The interesting part is that when Jake listened to Matthew’s interview on a previous episode of The Drive, he said it finally made sense as to why they’re shooting was the least accurate on Mondays (2x less accurate!) ⇒ “*Everything Matthew Walker said completely makes sense to our observation.*”
- Mondays were the first day of the week where they had to wake up in the middle of the night so it’s makes sense to reason that their accuracy was worse because they got less sleep and they had yet to acclimate to their new sleeping rhythm
- By the end of the week, their accuracy became much more dialed in (presumably because they were acclimating to their new sleep cycles)

**Shift work**

*If you must work a job that includes shift work, what is the best set of recommendations?*

- Try to stay on *longer bouts* of that shift work
- Don’t do flip flop shift work where you are on for two days, off for three days, on for four days, and so on

## Bed partners: How to sleep in separate beds and retain a good relationship [55:30]

> “I think it’s one of the most under-discussed topics in the  sleep and societal world.”

- The thing people fret about it not the 8 hours of sleeping when you are more or less unaware of your partner…
- It’s the stigma around the process of seeing them at bedtime and when you wake up

**How to “hack the system”:**

- You can still sleep in separate locations but **develop a good night routine and a good morning routine**
- In the evening, make a habit of going into the bedroom at the time that the first person likes to go to bed
- Hang out for a bit and say goodnight to each other
- In the morning, reverse engineer the same trick
- “*You get 99% of the benefit of co-sleeping without the need to actually co-sleep and you sleep better.*”

Matthew’s personal story:

- Matt and his partner sleep in separate beds
- They have slightly different needs in terms of when they go to bed and how much sleep they need
- They decided to try the “sleep divorce” and it has worked really well
- There is no shame in that, Matt says

## Can we use sound machines and electrical stimulation to improve sleep? [57:40]

*Is there much evidence that there are sound machines or music or any devices that can help you get better sleep and/or improve certain stages of sleep*?

Possibly, says Matt

There are 2 types of sound manipulation that are most commonly used:

1. Sound blocking
2. Rhythmic frequencies

**Sound blocking**

- White noise, pink noise, etc.
- no evidence right now that they’re necessarily harmful for your sleep. As long as they’re not too loud and too close
- **Caution**: Be weary of sound that is cognitively activating (radio, television)
  - Your brain usually continues to process it even while sleeping

**Rhythmic frequencies**

*Electrical stimulation*

- It is an [electroceutical where we insert a small amount of voltage into the brain](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4523433/) using a set of pads that usually sit on the forehead
- We try to “sing in time” with those deep sleep brainwaves to amplify the size of them
- In doing so, we can actually [**almost double the amount of memory benefit**](https://www.nature.com/articles/nature05278) that you get from sleep

⇒ Problems making this difficult to commercialize:

1  The process is incredibly precise and depending on the individual and takes the ability to predict the next deep sleep brain wave… so the idea that you can just kind of put some beats that kind of regulate with some rhythm into the brain, and you can actually force the brain into synchrony, that seems unlikely

2  If you keep stimulating with sound or with electricity, after five or 10 seconds, the brain actually starts to fight back against that excessive potentiation of brainwaves

**Analogy**: Like defibrillation of the heart where you can’t just apply a voltage to somebody’s chest when their heart is in a bad rhythm…you have to first sense the rhythm to know where to put the voltage

> “So my point is this: it’s technically very challenging to do this type of brain stimulation. You need to be reading out. And then writing. So, read, write, read, write . . . You need to be measuring, stimulating, measuring, stimulating, and backing off when you need to. It’s a smart, closed-loop, intelligent system and it’s very unlikely that you can just use our more neanderthal approach to doing that, because the brain is just so complex.”

## Will we ever be able to “supercharge” our sleep stages using technology? [1:03:30]

To be able to supercharge our brains using at-home stimulation, we will first need:

- Much more accurate in our ability to stage sleep on our devices
- Those devices would have to be connected directly to, meaning speaking with the device that’s putting in the voltage

*Will this improve sleep efficiency and allow for less total sleep?*

- Matt says that we just don’t know as of now
- Currently, the technology was developed for the aging brain where you start to get a pernicious drop in deep sleep
- The decline begins in your early 30s and it gets worse and worse each decade
- Matt’s lab has tried to salvage aspects of deep sleep in older adults and give back many of the physical and cognitive benefits that sleep normally has

> “I think sleep is a huge part in the aging puzzle, and it may fast become probably one of the best tools that we have in the anti-aging toolbox.”

*What about for younger people, perhaps starting in their 30s?*

- Matt is worried about going that route: “It’s very rare that you can actually gain a benefit in a system that’s biological without seeing a cost somewhere else down the line.”

*⇒ What could that cost be*?

- “Well, it’s possible that if you increase deep sleep, you may actually drive down the amount of rapid eye movement sleep that you get.”
- “So I think we have to be very careful in terms of finding the optimal balance between sleep enhancement and converse sleep detriment to other stages.”

*Is it possible that we can then try to augment those others too and just raise all of the boats of sleep stages on that single tide of stimulation?*

- It might be possible, however, at the moment they have only been able to improve deep, slow wave sleep
- But there is very little research showing ways to augment REM sleep

## Why sleep is the best insurance policy for lifespan and healthspan [1:07:45]

“Stop thinking of sleep is something you have to do. Think about it as something you want to do. This is a performance enhancing drug.” —Peter on how he wants his patients to view sleep

- It’s a life insurance policy
- It is probably the most democratic health care insurance policy that you have, or health care system.
- Sleep essentially is a life support system
- And I’ve often described sleep as perhaps Mother Nature’s best effort yet at immortality.
- We’ve got lots of people trying to optimize different pathways and I think that’s great. I want them to keep sort of finding ways to modulate your metabolic pathways or your immune pathways or your reproductive pathways.

*Analogy: Sleep is like the master volume lever on a mixing deck that you see in the studio*

- Sleep acts like a superordinate node in the biological equation of health
- It’s like that master volume button on a mixing deck that you see in the studio
- You can manipulate each one of those dials, or you can go to the far left and just move that one dial all the way up and all of the other levers seem to move with it.
- If you optimize sleep, you’re doing as much as probably you can from the health regard standpoint in terms of increasing your insurance for a longer life

*Can better sleep mean a longer* ***healthspan****?*

- Matt thinks there is a good chance healthspan increases along with lifespan
- “What I’m fascinated by and wanting to do studies on is looking at health span, not just lifespan.”

*Huge economic cost savings*

- It could be a huge cost benefit equation, says Matthew
- If you were to think about the relief of health care burden that would happen if we could live longer, healthier by way of sleep, the cost savings could be enormous too
- Unfortunately, as a country, we are not motivating/incentivizing our societies to get better sleep
- The government is heavily involved in incentivizing other things: Avoiding drunk driving, healthy eating, exercise, and now even for mental health
- “But there’s nothing about sleep and so I would to think about trying to manipulate that to you for the good of an individual and the good of the society and cost savings economically.”

**Let’s get Matthew nominated for the MacArthur award!**

- Peter: “I’m excited to think about what the world looks like in 10 years as a result of what you’ve done in the shoulders of all of the people who are doing this research upon which your megaphone is standing. Because it’s remarkable.”
- Peter thinks Matthew is a prime candidate for the [MacArthur award](https://en.wikipedia.org/wiki/MacArthur_Fellows_Program)
- “You are exactly the type of person that needs to win that award because all of their winners are remarkable people… but the scale of what you’re doing is so impressive.”
- Peter has been trying to figure out how to nominate Matthew for 6+ months without making any progress

**So if anybody listening to this either is on the committee or knows how to begin the nomination process, please help!**

## Melatonin: How (and how not) to use it for sleep improvement [1:15:00]

**Melatonin**

- Lowest dose is about 300 *micrograms*
- They can be as high as 5 to 10 *milligrams*
- *\*All of these doses are very high relative to our natural production of melatonin*

*What is your overall thoughts on the use of melatonin (exogenous melatonin)?*

- It can help the timing of your sleep, but it doesn’t necessarily change the quantity and the quality of that sleep
- However, it may actually have a *potential benefit for deep non REM sleep*

⇒ Efficacious under at least two conditions (and maybe a third):

- **First: When you’re jet lagged and you’re traveling**
  - Melatonin can be immensely useful to help retrain your sleep rhythm
  - Take it about 45 minutes to an hour before bed
- **Secondly: People who are typically over the age of 50**
- - - The older that we get the blunter our circadian rhythm
    - The circadian rhythm, which is your 24 hour rhythm, has a wonderful high peak during the day
      - You’re active and alert and then it scales down at night and that’s when we sleep (it’s up and it’s down, it’s up and it’s down)
      - The older that we get, the flatter that rhythm becomes (less deep valleys and less high peaks) ⇒ could be the reason older people might say “I feel a little bit fatigued and tired during the day, but then I don’t sleep as well at night.”
      - Melatonin in older individuals can help increase the peaks and valleys
- **Third (less proven): To fight the effects of artificial light (i.e., blue light from electronics)**
- - As technology gets better and more intertwined in our lives we are more prone to exposure to light that messes with our circadian rhythm

*Can taking melatonin affect quality sleep?*

- Potentially because it may be hypothermic, meaning it may help drop your core body temperature
- “*That’s where I think the unknown advantages of melatonin on sleep may be found.*”

**The two caveats if you’re considering melatonin**:

**1 Dose**

- Some people are dosing too high
- There is some evidence out there that if you use too high a dose, you may actually shut down your body’s own production of natural melatonin (like what happens when taking too much testosterone, for example)
- Start with the minimum dose of 0.5 milligrams
- Cut it off at 3 milligrams

**2 Not FDA regulated**

- [A study looking at different brands of melatonin supplements](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5263083/) found the the amount of melatonin claimed on the label was, on average, very different than the actual amount in the supplement ⇒ *anywhere from 80% to 470% less melatonin says Matthew*
- While Matthew doesn’t have a specific brand to recommend, Peter says that he trusts [Jarrow](https://www.jarrow.com/) for his supplements (but doesn’t know about their [melatonin](https://www.jarrow.com/products/search?key=melatonin))

*Don’t discount the placebo effect*

- It’s important to note that if you see a benefit to your sleep when taking melatonin, it does not matter whether the supplement itself is working or if it’s simply a [placebo effect](https://us15.campaign-archive.com/?u=21bc5f75235505c27ce465f90&id=1ce39b914d)

## The dangers of sleeping pills, useful alternatives, and cognitive behavioral therapy for insomnia [1:24:30]

“I feel very comfortable telling patients that I would rather you stick your genitals in a grinder than you take Ambien or Lunesta.” —Peter Attia

**Ambien and Lunesta**

- These are sedative hypnotics and don’t actually get you into your good sleep stages
- The FDA [updated its mortality risk warnings](https://www.fda.gov/news-events/press-announcements/fda-requires-stronger-warnings-about-rare-serious-incidents-related-certain-prescription-insomnia) regarding those sleeping pills because of this increased risk of death

⇒ Study: [Hypnotic drug risks of mortality, infection, depression, and cancer: but lack of benefit](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4890308/)

- But even more scary says Peter is the increased risk of chronic illness
- Sleeping pills seems to weaken the immune system leading to higher rates of infection
- Weakened immune can increase cancer risk as well
- In 2016, the [American College of Physicians said sleeping pills must no longer be the first line recommendation for insomnia](https://www.acponline.org/acp-newsroom/acp-recommends-cognitive-behavioral-therapy-as-initial-treatment-for-chronic-insomnia)… it has to be something else called [Cognitive Behavioral Therapy for Insomnia](https://www.sleepfoundation.org/articles/cognitive-behavioral-therapy-insomnia) (CBTI)

**CBTI**

- Peter has had several patients go through CBTI with “great success”
- It’s a nonpharmacological, psychological method working with a therapist
- and they try to understand where your sleep problems are at and create a bespoke solution for you, the individual
- It’s just as efficacious as sleeping pills in the short term
  - But the real benefit is in long term benefits
  - When you stop sleeping pills, the benefit goes away, and you might have even made it worse (“rebound insomnia”)
  - With CBTI, the [benefits can last for years after stopping therapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3481424/)

*How do you recommend people find good CBTI therapists?*

- Peter recommends a sleep doctor [Vik Jain](https://www.nm.org/doctors/1992965156/vikas-jain-md) in Chicago
- Here’s a site to help you [find a facility near you](https://sleepeducation.org/find-a-facility) that is AASM accredited

*What questions to ask a potential sleep doctor?*

- Ask them about their success rates
- Ask them where they have found problems with your patients
- Which patients have you typically had the hardest difficulty with in terms of the profile of sleep problems?
- And if they sound like you, then maybe you want to look elsewhere as well

**Tylenol PM and Benadryl**

For Benadryl…

- Benadryl-induced sleep also has some of the risks associated with it that sleeping pills have
- It’s less potent in terms of that bad consequence and outcome to sleep

For Tylenol PM…

- Not good enough data yet to suggest that it’s either good or bad

**What about low doses, or intermittent use of benzodiazepines?**

⇒ Examples: Xanax, Valium

- Matthew says be careful, only use it in the most dire of circumstances
- It may have [similar negative consequences as Ambien and Lunesta](https://www.ncbi.nlm.nih.gov/pubmed/22371848) per one study by [Dan Kripke](https://profiles.ucsd.edu/daniel.kripke) (even just 3 to 18 pills per year)

> “See how far you can really get with all of the other kaleidoscope of possibilities of sleep enhancing possibilities that we’ve discussed. And if those fail, then I think you can think about last resources. But those drugs typically just are not producing natural sleep. So I would think of those medications like that box on the wall that says, ‘Break glass in terms of emergency.’ If you’re in that situation and you’re really struggling, then it’s possible that that’s the time to break the glass, but those shattered shards can sometimes still cut you.”

**GHB and XYREM**

*What about* [*GHB*](https://en.wikipedia.org/wiki/Gamma-Hydroxybutyric_acid) *and* [*Xyrem*](https://en.wikipedia.org/wiki/Sodium_oxybate) *as a precursor?*

- Xyrem is a potent drug for people with narcolepsy
- Matt says that Xyrem or GHB are are drugs that appear to increase the amount of deep sleep that you have because it puts your brain into a more sort of sedated slow rhythm
- HOWEVER… a closely look in the lab shows it may not look like naturalistic sleep
- Xyrem seems to be detrimental to sleep spindles
  - Sleep spindles are short synchronous bursts of electrical activity that happened during non-REM sleep
  - they are critical for things like learning memory and brain plasticity
- When you take GHB or Xyrem, the amount of sleep spindle activity is decreased often

⇒ Sleep spindles

- We see sleep spindles at the end of a deep, slow wave and what happens is that once you’ve hit the peak of that slow wave, you will often have a little bit of a spindle burst (that burst in tandem is called *phase amplitude coupling*)
- That coupling is critical for long term memory transfer and for strengthening connections between brain cells (brain plasticity)
- So Xyrem and GHB is not recommended to people who do not have narcolepsy

> “We don’t have deep sleep in a pill.”

## Can CBD and THC be used for sleep? [1:39:30]

**THC**

- THC does speed up the time with which you fall asleep (sleep onset latency)
- The downsides…
  - THC seems to actually block REM sleep
  - People build up a dependency so when you stop taking THC you typically have “[rebound insomnia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4446186/)”
- “*THC right now is not recommended for sleep.*”

**CBD**

- CBD as a sleep aid looks “*increasingly promising*” says Matthew

*⇒ What to look for in CBD supplement*?

- Go for something that’s higher dose (more on the pure CBD side and very little THC)

⇒ *How is CBD working?*

- Still not totally sure, but possibly in the following ways:
- CBD, **at certain doses**, may reduce in core body temperature
- It can be an [anti-anxiety solution](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6326553/) (quiets down the fight or flight branch of the nervous system)
- It also *does not* blunt REM sleep, nor create rebound insomnia when you stop taking it

Caveat

- Not FDA regulated at all, “The Wild West”
- “*CBD makes melatonin look FDA regulated*”

## Why haven’t we been able to develop a really effective sleeping aid? [1:46:40]

From an electrophysiological perspective…

- It is much, much more than just being unconscious
- Brainwaves and brain oscillations are incredibly complex, and they are doing different things at different times during different stages of sleep

At the level of neurochemistry…

- There are vast changes in your chemicals acetylcholine, noradrenaline, serotonin, all of these things have very distinct differential profiles as you ebb and flow in and out of the different stages of sleep

From a neural network standpoint…

- Different parts of the brain are switching on and switching off as you go in and out of the different stages of sleep
- And it’s not simple, when you go into deep non REM sleep, some parts of the brain become active, some parts of the brain become inactive and as you go into REM sleep then, many of those things start to reverse and change

“*Once you actually start to understand what [sleep] is, well, it just might be too complicated to replicate with the pills.*”

> “I think of it almost like an orchestra. Wakefulness is the full orchestral power of all of the segments of the orchestra playing, but then when you go into light non REM sleep, you’re quieting down some parts of the orchestra, you’re bringing in the strings, the brass has gone down But then you go into deep sleep and now you’ve just got the deep rhythm and even the strings have gone down. You go into REM sleep and now all of a sudden you’ve got all of the percussion, you’ve got the strings coming in… It’s so difficult to orchestrate that from a single molecular standpoint and all we do right now with these drugs is we just think of sleep like a coma and we knock the brain out by using these strong powerful agents and it’s just not naturalistic sleep… so why would we believe it would have the same benefits? And it doesn’t.”

## Can you get too much sleep? [1:51:50]

- There is a pathological condition called [idiopathic hypersomnia](https://en.wikipedia.org/wiki/Idiopathic_hypersomnia) where people just have an excessive amount of sleepiness
- The other place where you see [hypersomnia](https://en.wikipedia.org/wiki/Hypersomnia) (excessive sleep or excessive sleepiness) is in the condition of depression
  - However, Matt believes that it might not be that depressed people are sleeping more, but rather that they are just lying in bed more, not wanting to face the day

*But is there a case where you can have too much sleep?*

- Yes, just like you can have too much of other things that are essential such as water, oxygen, food, and water
- However, it might prove hard to oversleep naturally without something else causing it (i.e. illness)

*Is nine hours too much?*

- No, nine hours is not a problem
- 14+ hours is where Matthew would be concerned (outside of childhood)

*What does the data say?*

- [Some studies](https://www.ahajournals.org/doi/10.1161/JAHA.118.008552) show that the more sleep you get the better your health until you start to surpass the 9 hour mark
- After nine hours there is a turn back up in mortality risk (like a “J” shape curve)
- But those studies were not controlling well for the comorbid diseases that were occurring
- In other words, we aren’t sure which direction is the causality
- And in fact, it’s more likely that the sick people tend to sleep more because they are trying to get over the illness and their body is forcing them to rest
- But because the illness, they die more frequently therefore creating the increase in mortality risk

## What to do (and not do) immediately following a terrible night of sleep? [2:04:15]

- One of the mistakes that people will make when they are under slept is they will try to sleep later that following morning, like trying to “get it back” if they can
- But if you sleep later into that following morning, you’re not going to be then tired at your normal time that subsequent evening so you’ll be throwing off your normal routine

⇒ *In the case that you have to go to bed abnormally late one night:*

- First, wake up at the same time
- Secondly, avoid the temptation for naps during the day
  - You build up lots of that natural healthy sleepiness, that’s the adenosine chemical
  - When you nap in the afternoon, it’s like just releasing that valve on the pressure cooker and you release some of that healthy sleepiness
- Finally, just go to bed at your normal time

**Caffeine**

- Just like avoiding napping, Matthew says to be careful with caffeine
- He recommends to stop using caffeine 14 hours before you expect to go to sleep
- Caffeine has a half life on average for most people of about six hours, it has a quarter life of 12 hours
- In other words…
  - After six hours, 50% of the caffeine is still in your brain
  - After 12 hours, 25% is still there
  - So if you have a cup of coffee at noon… a quarter of that caffeine is still in your brain at midnight

## Why a consistent wake up time is king [2:10:30]

- A consistent wake up time is the most important factor in terms of your sleep/wake routine
- It’s best to wake up at the exact same time every single day, weekend, weekday, etc.
- Even if you’ve had a bad night of sleep…wake up at the same time
- By doing that, it is a self regulating factor for better sleep
- It’s going to be a lot more difficult for you to fall into bad patterns of things like sleep onset insomnia or sleep maintenance insomnia

> “It’s not the one size fits all solution for everything, but it’s a great start if there’s only one piece of advice that you follow, waking up at the same time every single day is king.”

## Does poor sleep speed up the aging process? [2:12:00]

\*If you take a bucket of people with same age and compare those that are short sleeping vs. those that are sleeping a health amount…**the people who are getting less sleep have a biological age greater than their chronological age**

*Why is this being determined?*

1 Telomeres

- Telomeres have often been used as sort of somewhat of a biomarker of age and advanced or accelerated or artificially accelerated aging
- That’s [exactly what you see in people who are under slept](https://www.ncbi.nlm.nih.gov/pubmed/25890781)

2 Skin

- [Sleep deprivation can increase the aging of skin](https://www.sciencedaily.com/releases/2013/07/130723155002.htm)
- Looking at things such as:
  - Water permeability
  - Speed of recovery from an insult (e.g., sunburn)
  - The quickness of recovery get worse as you age
  - Underslept people have less resilient skin

3 Heart

- A fantastic database called the [MESA Database](https://www.mesa-nhlbi.org/) which is a fantastic study of atherosclerosis shows that getting six hours of sleep or less relative to people who are getting eight hours of sleep or more makes your heart look 10 years older

\*In short, you can increase your biological age deleteriously with short sleeping despite having the same chronological age

*But do we actually have a standardized formal test or assay that we can do right now for insufficient sleep as a function of artificial aging?*

- No we don’t
- We just have the data that a lack of sleep will artificially age you from a biological standpoint
- The problem is the effects are long term, so hard to test … “*There’s nothing that you can do to that person in a month that’s going to throw them off the rails.*”
- We don’t have a great integral readout of sleep quality over years except the indirect ways that you’ve talked about which is the impact on the disease.

## Can different people be more (or less) resilient to sleep deprivation? [2:18:50]

*Is everyone impacted by sleep deprivation in the same way?*

- No, people can be less affected in some ways
- But that generally means they might be more affected in another way

⇒ Example, two people of the same age are both sleeping 5.5 hours per night…

- Person A might be hit hard metabolically (e.g., weight gain) and reproductively (e.g., less sex drive)
- Person B might not see much of any of the affects of Person A but might show a decline in immune function or cognition compared to Person A

*What about averages compared to the individual level?*

- Memory, spatial attention, emotional stability, judgment, and decision making are all impaired by sleep deprivation *on the average*
- However, *if you look at each individual*, not all people show impairment in all those areas when they are sleep deprived

> “Different people are differentially vulnerable to sleep deprivation in different domains of brain function. In other words, just because you’re resilient to not slowing down in your response times, doesn’t mean that you’re going to be also resilient in other parts of the brain. If anything in fact, you will fall apart. So… the point is I suspect the same is true…in the body for all of those different physiological systems, too.”

*The challenge of a global composite score for sleep*

- Since each person is affected in different way across the difference brain and body domains, it is very difficult to come up with a standardized sleep deprivation test

⇒ *But is it possible?*

- There are some core fundamentals, says Matt, that for everyone they are going to be globally lock step, bound to how much sleep that you’re getting
- Those commonalities could serve as that universal marker of insufficient sleep

> “We’re starting to try to see if we can find out what is common and universal in terms of its sensitivity to insufficient sleep, and then separate that from other things that are more individual specific in terms of their sensitivity to insufficient sleep.”

## Finding your optimal sleep schedule and determining your sleep chronotype [2:23:45]

**Finding your optimal sleep schedule**

*Is being a morning person versus an evening person genetic?*

- It is genetic… it’s called your chronotype
- Society has the distribution of different chronotypes so you can be a strong evening type, or you could be a strong morning type
- Peter, for example, is a morning type (go to bed early and wake up early)
- “*There are these things called chronotypes. It’s not your decision. You don’t get to decide.*”

*Can you change your chronotype?*

- It’s very difficult to change, says Matthew
- You might be able to wiggle it around **by about 30 minutes from your natural rhythm**, but not much more than that or you will start sacrificing sleep quality

⇒ For example: If you’re an evening type who likes to go to bed at midnight and wake up at 8:00 am in the morning, for you to try and become a morning type and go to bed at 10:00 pm and wake up at 6:00 am, that’s two hour pull back in terms of your sleep schedule. That’s very difficult to do and now have your sleep be of lesser quality than it could be if you were going to bed at midnight and waking up at 8:00.

*Are you mistaking your chronology for insomnia?*

- Some people will think they have insomnia but in fact it could be that they aren’t aligning with their chronology
- So if you naturally get tired at midnight but you’re trying to force yourself to sleep at 10am, you might think you have insomnia

*Relationship problems and chronotypes*

- Couples who have marked chronotype mismatches typically struggle
- In a survey, almost 40% of people admitted that sleep issues including sleep mismatching in terms of typical timing caused a significant relationship to end as a consequence

**Questionnaire that can help you figure out your chronotype:**

- Morningness / Eveningness questionnaire (MEQ)
- [Here is one version of an MEQ](https://www.cet-surveys.com/index.php?sid=61524&newtest=Y)

## Defining sleep efficiency and how to improve it [2:29:25]

*Sleep duration*

- When Matthew recommends getting 7-9 hours of sleep per night, he is talking about actual sleep, **not just time in bed**

*Sleep efficiency*

- The time you are asleep divided by the time you are in bed
- You might only be asleep for 85-90% of the time you are lying in bed
- If you are someone who needs 8 hours of actual sleep, and you’re sleep efficiency is about 90%, then you need to be lying in bed for approx. **8 hours and 50 minutes** (sleep opportunity)

*Sleep opportunity*

- This is the time you plan to be in bed with the opportunity to sleep
- Matthew gives himself a **minimum** *sleep opportunity* of 8 hours per night

*Oura ring*

- Peter says this is why he loves the [Oura ring](https://ouraring.com/)
- It’s very good at telling you how long you were in bed and how much of that time you were actually asleep

⇒ What Peter tells his patients…

- If there’s a problem with total sleep time and efficiency is low, you have to improve the quality
- If total sleep time is low and efficiency is high, you need more time in bed

## Correcting insomnia: A counterintuitive approach [2:31:45]

**The caveat for insomnia patients**

- If you’re someone who’s struggling with insomnia and you’re lying in bed awake a lot of the time, you may need to **decrease your time in bed** to increase sleep pressure
- It’s counterintuitive, but one of the tools in the CBTI toolbox is to shorten the sleep opportunity
- Re-establish confidence that you can fall asleep in bed
- Constraining the person down to just six hours of sleep opportunity
- By compressing that window down you’re sleeping less and you’re building up more of that sleep pressure because as a consequence of the reduction of sleep opportunity time, you’re going to be awake during the day longer
- The longer that you’re awake, the more of that sleep pressure you build up
- The idea is force your brain to realize that it only has this tiny opportunity of six hours so it must take advantage

> “It’s this ironic way that we help treat insomnia. We constrain total sleep time. Use brute force efficiency in a brute force response from the brain and all of a sudden something magical happens. You start to control your sleep rather than your sleep controlling you.”

**Example insomnia patient**: Someone who’s chronotype is early to bed, early to rise, but they’re having problems with insomnia.

- *Do you push them more on delaying bedtime? ⇒* Slice off the sleep opportunity on both sides
- Next, you should hold the wake up time constant
- And then try to go to be a tad earlier, and earlier
- If you have set back you can “reign it back in” by shortening the sleep opportunity again

> “This is usually one of the last tools in the CBTI box that you typically use just because it’s so hard for compliance and adherence and it is pretty miserable because we’re putting you on essentially a short sleep restriction… but it’s a wonderful way for the patient to then finally feel as though they have control because it’s a technique that they can use once they understand how the sleep system works.”

## How can parents improve the sleep of their kids? [2:37:30]

Referring to kids from 5th grade up through high school

- Their natural inclination is to go to bed later and wake up later (as compared to younger kids and adults)
- School start times

- Currently, most school start way too early
- “By the way, 7:50 am school start time… you’re educating your child amnesiac.”
- Most people don’t have the choice to switch schools to one with later start times

*So, what can the average parent do to help their kids get better sleep?*

**A recent** [**intervention study**](https://www.theguardian.com/society/2019/apr/28/sheffield-sleep-problems-families-nhs-programme) **looking at young kids**

- 800 kids in an area around a town called Sheffield in the UK
- The kids were considerably getting less sleep than they needed

⇒ They found that the implementation of four things actually added almost two hours of sleep to their kids:

1. *Regularity*: Bed at the same time and waking up at the same time
2. *Removing all toys and electronics from the bedroom*: turns bedroom into an environment that was queued up for sleep
3. *Relaxing routine*: building in some kind of relaxing routine (e.g., reading with the child before bed)
4. *Daylight exposure*: making sure that the child got sufficient daylight throughout the day

§

§

## Selected Links / Related Material

**Three-part series with Matthew on The Drive**: [00:45]

- Part 1: [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/)
- Part 2: [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/)
- Part 3: [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/)

**Matthew’s book**: [Why We Sleep: Unlocking the Power of Sleep and Dreams](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316) by Matthew Walker | (amazon.com) [2:00]

**Matthew’s TED Talk**: [Matt Waller at TED2019: Sleep is your superpower](https://www.ted.com/talks/matt_walker_sleep_is_your_superpower/up-next?language=en) | (ted.com)  [2:00, 4:30]

**Ken Robinson’s TED talk on education**: Sir Ken RobinsonatTED Talks Education: How to escape education’s death valley | (ted.com) [5:15]

**Sleep trackers**: [7:00]

- [Oura ring](https://ouraring.com/) [2:31:15]
- [Whoop](https://www.whoop.com/)
- [Fitbit](https://www.fitbit.com/home?afsrc=1&utm_source=ShopAtHome.com%2C+LLC&utm_medium=affiliate&utm_campaign=Fitbit+Homepage&CJEVENT=4fd48b978dee11e98265007c0a1c0e10)

**Sleep and exercise**: [Interrelationship between Sleep and Exercise: A Systematic Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5385214/) (Dolezal et al., 2017) [14:30]

**Peak muscle strength increases for compound movements with good sleep**: [Inadequate sleep and muscle strength: Implications for resistance training.](https://www.ncbi.nlm.nih.gov/pubmed/29422383) (Knowles et al., 2018) [14:30]

**Time to physical exhaustion is reduced with sleep deprivation**: [Effect of sleep deprivation on tolerance of prolonged exercise.](https://www.ncbi.nlm.nih.gov/pubmed/7199438) (Martin BJ, 1981) [14:30]

**Sleep and injury risk**: Chronic lack of sleep is associated with increased sports injuries in adolescent athletes. (Milewski et al., 2014) [14:30]

**Sleep deprivation increases appetite through an increases a hormone called ghrelin and suppression of leptin**: [Impact of sleep and sleep loss on neuroendocrine and metabolic function.](https://www.ncbi.nlm.nih.gov/pubmed/17308390/) (Van Cauter et al., 2007) [18:45]

**The Drive episode discussion stress and cortisol**: [#51 – Robert Sapolsky, Ph.D.: The pervasive effect of stress – is it killing you?](https://peterattiamd.com/robertsapolsky/) | Peter Attia (peterattiamd.com) [21:15]

**The LED light wins the Nobel Prize in 2014**: [The Nobel Prize in Physics 2014](https://www.nobelprize.org/prizes/physics/2014/summary/) | (nobelprize.org) [25:15]

**Meditation for insomnia**: [Meditation May Be An Effective Treatment For Insomnia](https://www.sciencedaily.com/releases/2009/06/090609072719.htm) | ScienceDaily (sciencedaily.com) [29:40]

**Journaling before bed can reduce the time it takes to fall asleep**: [The effects of bedtime writing on difficulty falling asleep: A polysomnographic study comparing to-do lists and completed activity lists.](https://www.ncbi.nlm.nih.gov/pubmed/29058942) (Scullin et al., 2018) [32:00]

**A positive mood set tends to improve sleep quality and reduce time to fall asleep**: [33:00]

- [The Effect of Mood on Sleep Onset Latency and REM Sleep in Interepisode Bipolar Disorder](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4185310/) (Talbot et al., 2009)
- [You’ll feel better in the morning: slow wave activity and overnight mood regulation in interepisode bipolar disorder.](https://www.ncbi.nlm.nih.gov/pubmed/28625231) (Soehner et al., 2018)

**Popular movie which is centered around the dreaming state of sleep**: [Inception](https://en.wikipedia.org/wiki/Inception) | (wikipedia.org) [39:00]

**Sleep fragmentation can contribute to Alzheimer’s disease**: [Sleep Fragmentation and the Risk of Incident Alzheimer’s Disease and Cognitive Decline in Older Persons](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3669060/) (Lim et al., 2013) [42:30]

**Lower testosterone in sleep deprived men**: [Effect of 1 Week of Sleep Restriction on Testosterone Levels in Young Healthy Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4445839/) (Leproult et al., 2011) [48:45]

**Sex drive in women… For every one hour of extra sleep that a female gets, they have somewhere between a 13 to 15% increase in the desire to be intimate with a partner**: [The impact of sleep on female sexual response and behavior: a pilot study.](https://www.ncbi.nlm.nih.gov/pubmed/25772315) (Kalmbach et al., 2015) [48:45]

**Technology increase deep sleep and improve memory ⇒ electrical stimulation via inserting a small amount of voltage into the brain to “sing in time” with deep sleep brainwaves to amplify the size of them**: [Memory Improvement via Slow Oscillatory Stimulation during Sleep in Older Adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4523433/) (Westerberg et al., 2015) [1:00:00]

**Brain stimulation treatment that uses direct electrical currents to the brain can double memory in young healthy adults**: [Boosting slow oscillations during sleep potentiates memory](https://www.nature.com/articles/nature05278) (Marshall et al., 2006) [1:00:00]

**The decline in deep sleep with age (“The Great Depression of deep sleep”)**: [Sleep and Human Aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5810920/) (Mander et al., 2017) [1:05:00]

**Short sleep predicts all cause mortality**: [Sleep duration and all-cause mortality: a systematic review and meta-analysis of prospective studies.](https://www.ncbi.nlm.nih.gov/pubmed/20469800) (Cappuccio et al., 2010) [1:09:45]

**The award Peter is desperately trying to get Matthew nominated for**: [MacArthur Fellows Program](https://en.wikipedia.org/wiki/MacArthur_Fellows_Program) | (wikipedia.org) [1:13:45]

**Melatonin may reduce core body temperature**: [The hypothermic effect of melatonin on core body temperature: is more better?](https://www.ncbi.nlm.nih.gov/pubmed/8836952) (Dawson et al., 1996) [1:19:15]

**Study that looked at many different vendors of over-the-counter melatonin**: [Melatonin Natural Health Products and Supplements: Presence of Serotonin and Significant Variability of Melatonin Content](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5263083/) (Erland et al., 2017) [1:21:30]

**Peter’s preferred supplement brand**: [Jarrow Formulas](https://www.jarrow.com/) | (jarrow.com) [1:22:15]

**FDA updated its mortality risk warnings regarding those sleeping pills because of this increased risk of death**: [FDA requires stronger warnings about rare but serious incidents related to certain prescription insomnia medicines](https://www.fda.gov/news-events/press-announcements/fda-requires-stronger-warnings-about-rare-serious-incidents-related-certain-prescription-insomnia) | (fda.gov) [1:26:15]

**Rates of infection  and cancer when taking sleeping pills increases with the degree of use and dosage**: [Hypnotic drug risks of mortality, infection, depression, and cancer: but lack of benefit](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4890308/) (Daniel F. Kripke, 2016) [1:26:45, 1:32:45]

**American College of Physicians now say sleeping pills must no longer be the first line recommendation for insomnia and it should instead be Cognitive Behavioral Therapy for Insomnia (CBTI)**: [ACP Recommends Cognitive Behavioral Therapy as Initial Treatment for Chronic Insomnia](https://www.acponline.org/acp-newsroom/acp-recommends-cognitive-behavioral-therapy-as-initial-treatment-for-chronic-insomnia) | (acponline.org) [1:27:00]

**CBTI is better for insomnia than sleeping pills, especially in the long run**: [Comparative effectiveness of cognitive behavioral therapy for insomnia: a systematic review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3481424/) (Mitchell et al., 2012) [1:28:15]

**How to find a sleep clinic that does CBTI that is accredited by the American Academy of Sleep Medicine**: [Find a Sleep Facility Near You](https://sleepeducation.org/find-a-facility) | (sleepeducation.org) [1:29:30]

**Sleep supplement that Peter takes made by Kirk Parsley**: [Doc Parsley’s Sleep Remedy](https://store.docparsley.com/products/doc-parsley-sleep-remedy-single) | (docparsley.com) [1:32:15]

**Taking Xyrem and/or GHB can have a detrimental impact on sleep spindles and therefore learning and memory**:

- [Differential effects of sodium oxybate and baclofen on EEG, sleep, neurobehavioral performance, and memory.](https://www.ncbi.nlm.nih.gov/pubmed/22851803) (Vienne et al., 2012) [1:34:30]
- [Slow wave sleep induced by GABA agonist tiagabine fails to benefit memory consolidation.](https://www.ncbi.nlm.nih.gov/pubmed/23997364) (Feld et al., 2013) [1:34:30]

**Dangers of taking sleeping pills (and benzodiazepines) even just 3-18 pills/year**: [Hypnotics’ association with mortality or cancer: a matched cohort study.](https://www.ncbi.nlm.nih.gov/pubmed/22371848) (Kripke et al., 2012) [1:34:45]

**THC blocks REM sleep**: [Sleep Disturbance in Heavy Marijuana Users](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2442418/) (Bolla et al., 2008) [1:40:30]

**Rebound insomnia with THC due to dependency: Cannabinoid abuse and addiction**: [Clinical and preclinical findings](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4446186/) (Panililio et al., 2015) [1:40:30]

**CBD reduces anxiety**: [Cannabidiol in Anxiety and Sleep: A Large Case Series](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6326553/) (Shannon et al., 2019) [1:42:30]

**Study showing too much sleep is linked to increased mortality but Matthew says they not really controlling well for comorbid diseases that were occurring**: [Self‐Reported Sleep Duration and Quality and Cardiovascular Disease and Mortality: A Dose‐Response Meta‐Analysis](https://www.ahajournals.org/doi/10.1161/JAHA.118.008552) (Kwok et al., 2018) not really controlling well for the comorbid diseases that were occurring. [1:58:15]

**Sleep and telomere length**: [Telomere length as a marker of sleep loss and sleep disturbances: a potential link between sleep and cellular senescence.](https://www.ncbi.nlm.nih.gov/pubmed/25890781) (Tempaku et al., 2015) [2:13:00]

**Sleep loss increases skin aging**: [Sleep deprivation linked to aging skin, study suggests](https://www.sciencedaily.com/releases/2013/07/130723155002.htm) | (sciencedaily.com) [2:14:00]

**MESA database**: [Multi-Ethnic Study of Atherosclerosis](https://en.wikipedia.org/wiki/Multi-Ethnic_Study_of_Atherosclerosis) | (wikipedia.org) [2:14:45]

**The astronaut twin study**: [The NASA Twins Study: A multidimensional analysis of a year-long human spaceflight](https://science.sciencemag.org/content/364/6436/eaau8650) (Garrett-Bakelman et al., 2019) [2:17:45]

**Research into sleeping with a bed partner**: [Two in a bed: The influence of couple sleeping and chronotypes on relationship and sleep. An overview](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5152533/) (Richter et al., 2016) [2:28:00]

**The test for determining your sleep chronotype**: [Automated Morningness-Eveningness Questionnaire (AutoMEQ)](https://www.cet-surveys.com/index.php?sid=61524&newtest=Y) | (cet-surveys.com) [2:28:30]

**Genetic sequencing that may help you figure out your sleep chronotype**: [23 and me](https://23andme.com) | (23andme.com) [2:38:45]

**UK study with 800 kids and found that the implementation of four things added 2+ hours of sleep to their kids**: [NHS sleep programme ‘life changing’ for 800 Sheffield children each year](https://www.theguardian.com/society/2019/apr/28/sheffield-sleep-problems-families-nhs-programme) | Denis Campbell (theguardian.com) [2:39:00]

§

## People Mentioned

- [Tim Ferriss](https://twitter.com/timferriss?lang=en) [4:15]
- [Carl Sagan](https://en.wikipedia.org/wiki/Carl_Sagan) (one of Matt’s favorite speakers) [5:15]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) (one of Matt’s favorite speakers) [5:15]
- [Sir Ken Robinson](https://en.wikipedia.org/wiki/Ken_Robinson_(educationalist)) (one of Matt’s favorite speakers) [5:15]
- [Robert Sapolsky](https://en.wikipedia.org/wiki/Robert_Sapolsky) (expert on stress, guest on The Drive) [21:15]
- [Jari Laukkanen](https://twitter.com/laukkanenjari?lang=en) (researcher who studies benefits of saunas that Matt would love to work with to look at sleep) [29:00]
- [Jake Muise](https://www.instagram.com/deer4dinner/?hl=en) (hunting guide in Hawaii that Peter is friends with) [51:30]
- [Majel Connery](https://www.majelconnery.com/bio) (Matthew’s girlfriend, sleep in separate beds) [56:45]
- [Orrin Hatch](https://en.wikipedia.org/wiki/Orrin_Hatch) (deregulation of the supplement industry) [1:24:30]
- [Vikas Jain](https://www.nm.org/doctors/1992965156/vikas-jain-md) (sleep doctor that Peter works with) [1:29:00, 2:10:30]
- [Kirk Parsley](https://twitter.com/docparsley?lang=en) (sleep doctor who makes a [sleep cocktail](https://store.docparsley.com/products/doc-parsley-sleep-remedy-single) that Peter uses) [1:32:15]
- [Dan Kripke](https://profiles.ucsd.edu/daniel.kripke) (studies effects of Ambien on sleep) [1:32:45]
- [Marion Jones](https://en.wikipedia.org/wiki/Marion_Jones) (testosterone/steroids) [1:49:45]
- [Barry Bonds](https://en.wikipedia.org/wiki/Barry_Bonds) (testosterone/steroids) [1:49:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/06/mw-bio-image-ama1-500x500.png)

##### Matthew Walker Ph.D.

Dr. Walker earned his degree in neuroscience from Nottingham University, UK, and his PhD in neurophysiology from the Medical Research Council, London, UK. He subsequently became a Professor of Psychiatry at Harvard Medical School, USA. Currently, he is Professor of Neuroscience and Psychology at the University of California, Berkeley, USA. He is also the founder and director of the Center for Human Sleep Science.

Dr. Walker’s research examines the impact of sleep on human health and disease. He has received numerous funding awards from the National Science Foundation and the National Institutes of Health, and is a Kavli Fellow of the National Academy of Sciences.

Dr. Walker is the author of the International Bestseller, Why We Sleep. It has a singular goal: to reunite humanity with sleep.

In addition, Dr. Walker is an internationally recognized [speaker](https://www.sleepdiplomat.com/speaker), a successful [entrepreneur](https://www.sleepdiplomat.com/entrepreneur), and a Sleep Scientist for Google.

[sleepdiplomat.com]

**Twitter**: [@sleepdiplomat](https://twitter.com/sleepdiplomat?lang=en)

**Center for Human Sleep Science**: [https://www.humansleepscience.com/](https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s)

**Matthew’s publications**: <https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s>