# #201 – Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)

**Source:** [https://peterattiamd.com/inigosanmillan2/](https://peterattiamd.com/inigosanmillan2/)

---

##### Check out more content with expert, Iñigo San Millán, Ph.D.:

- *(December 23, 2019)* [Part I of II: Zone 2 Training and Metabolic Health](/inigosanmillan/)
- *(March 28, 2022)* [Part II of II: Deep dive back into Zone 2 Training](/inigosanmillan2/)

Iñigo San-Millán is an internationally renowned applied physiologist and a [previous guest on The Drive](https://peterattiamd.com/inigosanmillan/). His research and clinical work focuses on exercise-related metabolism, metabolic health, diabetes, cancer metabolism, nutrition, sports performance, and critical care. In this episode, Iñigo describes how his work with Tour de France winner Tadej Pogačar has provided insights into the amazing potential of elite athletes from a performance and metabolic perspective. He speaks specifically about lactate levels, fat oxidation, how carbohydrates in food can affect our lactate and how equal lactate outputs between an athlete and a metabolically unhealthy individual can mean different things. Next, he discusses how [Zone 2 training](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/) boosts mitochondrial function and impacts longevity. He explains the different metrics for assessing one’s Zone 2 threshold and describes the optimal dose, frequency, duration, and type of exercise for Zone 2. Additionally, he offers his thoughts on how to incorporate [high intensity training (Zone 5)](https://peterattiamd.com/category/exercise/high-intensity-zone-5-training/) to optimize health, as well as the potential of metformin and NAD to boost mitochondrial health. Finally, he discusses insights he’s gathered from studying the mitochondria of long COVID patients in the ICU.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/inigosanmillan2/the_Drive_public.png)

Play

#201 - Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)

#201 - Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)

1x15s30s

0:002:45:31

## We discuss:

- The amazing potential of cyclist Tadej Pogačar [3:00];
- Metrics for assessing athletic performance in cyclists and how that impacts race strategy [8:30];
- The impact of performance-enhancing drugs and the potential for transparency into athletes’ data during competition [17:00];
- Tadej Pogačar’s race strategy and mindset at the Tour de France [24:00];
- Defining Zone 2, fat oxidation, and how they are measured [26:45];
- Using fat and carbohydrate utilization to calculate the mitochondrial function and metabolic flexibility [35:45];
- Lactate levels and fat oxidation as it relates to Zone 2 exercise [40:00];
- How moderately active individuals should train to improve metabolic function and maximize mitochondrial performance [51:45];
- Bioenergetics of the cell and what is different in elite athletes [57:30];
- How the level of carbohydrate in the diet and ketogenic diets affects fuel utilization and power output during exercise [1:08:30];
- Glutamine as a source for making glycogen—insights from studying the altered metabolism of ICU patients [1:15:00];
- How exercise mobilizes glucose transporters—an important factor in diabetic patients [1:21:00];
- Metrics for finding Zone 2 threshold—lactate, heart rate, and more [1:25:00];
- Optimal Zone 2 training: dose, frequency, duration, and type of exercise [1:41:15];
- How to incorporate high intensity training (Zone 5) to increase VO2 max and optimize fitness [1:51:15];
- Compounding benefits of Zone 2 exercise and how we can improve metabolic health into old age [2:01:45];
- The effects of metformin, NAD, and supplements on mitochondrial function [2:05:15];
- The role of lactate and exercise in cancer [2:13:30];
- How assessing metabolic parameters in long COVID patients provides insights into this disease [2:19:00];
- The advantages of using cellular surrogates of metabolism instead of VO2 max for prescribing exercise [2:25:45];
- Metabolomics reveals how cellular metabolism is altered in sedentary individuals [2:33:45];
- Cellular changes in the metabolism of people with diabetes and metabolic syndrome [2:39:15]; and
- More.

§

## Show Notes

**\*Notes from intro:**

- Iñigo San-Millán Iñigo was a [previous guest on *The Drive* back in December of 2019](https://peterattiamd.com/inigosanmillan/)
  - That episode was incredibly popular; we not only re-broadcasted it, but we reached out to many of you for follow up questions in preparation for this episode
- We begin the conversation around Iñigo’s work with 2-time Tour de France winner, [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar)
  - His training
  - What the best of the best in the world are capable of
  - And how we can use that to benchmark ourselves
- We discuss lactate levels, fat oxidation, the relationship between watts and lactate, how carbohydrates in food can affect our lactate
- Then we talk about how equal lactate outputs in an athlete and a metabolically unhealthy individual can mean different things and how to interpret that
- We get into very specifics around Zone 2 exercise
  - This includes many of the questions people had around what metrics to use to know if you’re in Zone 2
  - How to structure an ideal Zone 2 training program without a lactate meter with regards to duration, timing, frequency
  - The importance of compounding the rate of improvement that can happen with Zone 2 training
- We talk a lot about [VO2 max](https://en.wikipedia.org/wiki/VO2_max) and high intensity training
  - Where that fits in with overall Zone 2 training
  - How exercise can have such a large impact on longevity
- We discuss Metformin and its potential impact on the mitochondria
- We discuss claims that NAD can boost mitochondrial health
- We end by discussing healthy versus unhealthy mitochondria
- We speak about Iñigo’s study on [long COVID](https://en.wikipedia.org/wiki/Long_COVID) patients, which revealed effects on the mitochondria that were reminiscent of [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)
- As a brief reminder of his background, Iñigo is an Assistant Professor at the [University of Colorado School of Medicine](https://som.ucdenver.edu/Profiles/Faculty/Profile/19887)
  - His area of research and clinical work focuses on: metabolism, nutrition, sports performance, over training, diabetes, cancer, and critical care
- He’s also an internationally renowned applied physiologist
- He has worked for the past 20 years with many professional athletes and teams around the world
  - This includes the 2 times tour de France winner Tadej Pogacar

## The amazing potential of cyclist Tadej Pogačar [3:00]

**Tadej Pogačar**

- No one knew who [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) was 2.5 years ago but now he may potentially go down as the greatest Tour de France cyclist of all time
  - To win the tour at such a young age (21)
  - Not just win the yellow Jersey, but the white Jersey, and the polka-dot Jersey repeatedly, he looks like something of a different species almost

**Iñigo’s work with Tadej Pogačar**

- Iñigo began working with Tadej Pogačar in late 2018 when he signed up for the the [UAE team](https://www.uaeteamemirates.com/)
  - Pogačar had just turned 19
  - Iñigo recognized right away his potential
- Physiological testing of Pogačar  revealed his amazing capabilities
  - His ability to clear lactate and put out a great amount of power for long periods of time
  - Iñigo measured his blood lactate levels at a given power output
    - He’s been doing this testing for 20 years with professional athletes, professional cyclists
    - This allows him to categorize people
  - Pogačar was at a different category in his first year as a pro cyclist
  - He could sustain a high amount of power with very low lactate compared to the rest
- Iñigo uses [TrainingPeaks software](https://www.trainingpeaks.com/athlete-features/) to track his ability to sustain a given power output for the whole day or a specific glycolytic effort
- Iñigo saw his trainability, how easy he would get the concepts, how easy he would be comfortable with the training, how easy he would recover
- Iñigo would talk to him once, twice a day using the [WhatsApp](https://www.whatsapp.com/)
  - He would know when Pogačar had a hard week and Pogačar would often tell him he was good and recovering well
    - Where as other cyclists would have to take it easy after that week

## Metrics for assessing athletic performance in cyclists and how that impacts race strategy [8:30]

- Around this time, Iñigo began developing a platform for metabolomics with colleagues at the university, [Angelo D’Alessandro](https://medschool.cuanschutz.edu/biochemistry/people/primary-faculty/dalessandro-angelo) and [Travis Nemkov](https://profiles.ucdenver.edu/display/15074368)
- They can look at hundreds, if not thousands of metabolites in the human body
- They did this in the [Tour of California in 2019](https://en.wikipedia.org/wiki/2019_Tour_of_California), which was around April; Pogačar won
  - So he has the analysis of all of Pogačar’s metabolites
  - Prior to this, they ran this analysis at the training camp in January, 2018

> “*Wow, this guy has different metabolites at the glycolytic level, acidic level, recovery level…. this guy is different*”— Iñigo San-Millán

- One of the most telling data points for a cyclist is lactate production (y-axis) versus watts per kilo (x-axis)
  - A normal climbing tempo in the Tour de France is about 5 watts
  - Someone at that intensity might have already six millimoles (mmol) of lactate, where it would be 1 mmol at resting levels
  - This can predict how taxing the work is and really predicts performance
- In the first training camp of the year for the team they do physiological testing and he gets this data
  - This allows him to rank the cyclists
  - They test this with different racing simulations; this measurement is very predictive
- Peter notes this is one thing he loves about cycling— knowing where the athletes stand before the race based on their FTP (functional threshold power) in watts per kilo
- Peter [interviewed Lance Armstrong last year](https://peterattiamd.com/lancearmstrong/) and Lance revealed when he was off EPO he could hold 450 watts for 30 minutes
  - So that would be slightly above FTP
  - He was around 70 to 75 kilos
  - This was in the ballpark of 6 watts per kilo
  - But on [EPO](https://en.wikipedia.org/wiki/Erythropoietin) it was 7.1 watts per kilo, a huge difference
- Only the GC contenders could do that, ride at 6 watts per kilo
  - But there relatively few moments in the tour when one needs to sustain that level
  - These moments occur at the most important strategic times; this is where the race is won and lost
    - Because races are won and lost by minutes
    - It takes about 4-5 hours per day for 23 days to complete the [Tour de France](https://en.wikipedia.org/wiki/Tour_de_France); it’s about 100 hours in all
    - Yet the difference between the 1st, 2nd, 3rd guy will be, in some cases seconds, in some cases a few minutes
    - For someone to win by 5 minutes is considered a blowout
- Iñigo uses this metric a lot
- Knowing the power output a ricker can sustain for specific times and climbed tells alot about his capabilities

**What distinguishes Tadej Pogačar from other cyclists?** [13:00]

- For Pogačar, in the Alps, he was riding at a very, very high level
- Iñigo will observe the data that he has, the data he thinks the other ones have, and he will structure a strategy for the next day
  - This helps to answer questions like, “*Hey, does he have the legs to attack?  Should be holding back or what should we doing?*”
- He knows when a rider is at so many many watts per kilo, for this many minutes, what his capacity is to recover
  - He has the physiological data and trends
  - But one has to be careful with the algorithms because there are days when the data says the cyclist should be in top form but the feel more fatigued

## The impact of performance-enhancing drugs and the potential for transparency into athletes’ data during competition [17:00]

**FTP (functional threshold power)**

- Peter notes that the current transparency in cycling that arose from the high octane era of cheating, we now know the numbers cyclists were putting out when they were assisted by EPO and blood transfusions
  - The best cyclists, using performance enhancing drugs, were putting out between 6.8-7.1 watts per kilo FTP
  - Cyclists today are not doing that
  - A cyclist could probably win the tour today at 6.1 watts per kilo
- Peter asks, “*Do you think that making that data public would put to rest a lot of the criticisms that say they’ve just found new ways to cheat, but it’s still basically a dirty sport?*”
- Iñigo thinks this is a good point
- It frustrates him when people think that they’re doing 7 watts per kilogram, but the real data from the day and it says it was way lower
  - On the short climbs they may be at 7.2, now they’re doing 6.3 maybe
  - The longer climbs they’re doing 5.5, 5.8

**Athlete’s data**

- Team policy usually keeps this data private
- But if the data is released, there will always be people who will not believe it or think the data is altered

> “*I just have that frustration that I wish that I could really show the data and people can see it*”— Iñigo San-Millán

- Some teams and riders are releasing their data
  - This allows him to see where Pogačar is
- Peter remarks that one of the things the sport of [Formula One](https://en.wikipedia.org/wiki/Formula_One) has been able to do (because of advances in technology) is make more of the data available to the viewer
  - You can see the drivers speed, what gear he’s in, the difference between throttle and brake pressure
  - You can hear the driver speak with their race engineers
  - This year they introduced a new camera angle, which shows what the driver sees
- Iñigo agrees this is fun for the viewer; cycling has so many possibilities to engage people fascinated with the physiology
  - Some cameras already installed in the front and the back, this is available from [Velon](https://www.velon.cc/about-velon)
    - This gives a sense of how difficult it is to sprint at 40 mph or descend at 70 mph
    - You can see power output in real time; it’s an estimation
    - Stats are only shown for the riders who wear the Velon
    - They aren’t doing all the top contenders, but it’s the first step

> “*The world of biosensors is going to revolutionize sports where we’re going to be able to see so many different parameters of athletes in real time*”— Iñigo San-Millán

- Imagine if you could see lactate and glucose in real time
  - This is technologically feasible
  - This would be great for all sports
  - Imagine in an NBA basketball game seeing the lactate of LeBron James as compared to the other players

## Tadej Pogačar’s race strategy and mindset at the Tour de France [24:00]

- Peter asks about [Ventoux](https://en.wikipedia.org/wiki/Mont_Ventoux#Tour_de_France) in the Tour de France this year
- This was probably Pogačar’s toughest stage
- It was a very difficult climb and a very long climb; Pogačar’s mentality was wired like a champion
  - He knows the top of the climb is not the end of the stage
  - It has a very long descent
  - Having a big gap and knowing you have a big descent, and staying calm is an important strategy
- The day before, 2 cyclists George Bennett and Sergio Higuita attacked in a short but very steep climb
  - There were maybe 12 riders left when they attacked
  - Then there was a descent and a long highway all the way to the finish line; so there was plenty of time to catch up
  - Tadej didn’t follow them; he strategized that he had time and would take the chance on beating them tomorrow
  - These guys were caught 2-3 kilometers to the finish line
  - So all those 12 guys got together the next day, and Tadej eliminated them one by one
- This is how Tadej thinks— no panic, plenty of time today, “*Why am I going to go full gas when I know that he’s going to go full gas and he might lose energy for tomorrow because he might pay for this at this time of the tour de France and we have plenty of time to catch him up*”

## Defining Zone 2, fat oxidation, and how they are measured [26:45]

**Tadej’s training in zone 2**

*Peter asks how much time Tadej spends in Zone 2; how does this change over the course of the year?*

- In the winter, 70-80% of the days he trains in Zone 2
- As the season gets closer, he starts increasing the number of high intensity days
- When the racing season begins, there may be one stage race of 5-7 days then he will have a 5 day block (or 1 week) to recover before the next stage race
- He alternates using different energy systems; each energy system has a time in the year where it is used in order to try to achieve certain goals

**A primer in Zone 2 training**

*⇒ See the* [*previous episode of The Drive with Inigo*](https://peterattiamd.com/inigosanmillan/) *for more*

- The intensity of exercise is important to stress the mitochondria and oxidative capacity
- This will recruit mainly type 1 muscle fibers

![](https://peterattiamd.com/wp-content/uploads/2022/03/f1-inigo2-1024x643.png)

**Figure 1. Muscle fiber types.**  Image source: [Wikipedia](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types)

- This is where you are mobilizing the highest amount of fat, both from adipose tissue as well from fat oxidation inside the mitochondria
- [Oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation) is the primary means of generating energy; this utilizes the mitochondria
  - The mitochondria is burning both fat and glucose
- Zone 2 exercise intensity is the best at stimulating mitochondrial function and fat oxidation and lactate cleanse capacity

**Lactate can be used as a fuel**

- Lactate is a great fuel for cells; it’s probably the preferred fuel for most cells in the body
  - This is work that [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) discovered; Iñigo would not be surprised if he wins the Nobel Prize
  - Iñigo has been translating a lot of his research
- Lactate is oxidized in the mitochondria to produce energy
  - This requires [MCTs (monocarboxylate transporters)](https://en.wikipedia.org/wiki/Monocarboxylate_transporter) to move the lactate from the cytoplasm of the cell into the mitochondria
  - This is stimulated with Zone 2 training

**Zone 2 training is characterized by a high level of fat oxidation**

- Fat oxidation increases in Zone 2 training
- As exercise intensity increases the fatmax starts to go down sharply

*Ways fat oxidation can be measured*:

- Peter notes that he can hook patients up to an [indirect calorimeter](https://en.wikipedia.org/wiki/Indirect_calorimetry)
  - They wear a mask over their nose and mouth that has the ability to measure the amount of oxygen consumed using an O2 sensor
  - O2 is coming in at 21% and whatever is exhaled is the difference between that
  - There is a similar sensor for CO2, so you know how much CO2 is produced
- Hook the patient up to an ergometer (this could be a bike, treadmill, rowing machine, etc.)
  - As you increase the demand on the muscle you increase the wattage or speed
  - This allows VO2 and VCO2 (volume of O2 and CO2) and to be determined
    - These are usually measured in liters per minute (L/min)
- The ratio of VO2 and VCO2 will tell how much energy is made from fat oxidation and how much of it is glycolytic
  - This can be converted to total grams of fat oxidation and a total grams of glucose oxidation per minute
- So you then could plot on the y-axis fat oxidation and on the x-axis work (or power in watts)

**Oxidation of fats and carbohydrates vary depending on exercise intensity [34:30]**

- In the 1920s [Francis Benedict](https://en.wikipedia.org/wiki/Francis_Gano_Benedict) was one of the first ones who started to look into oxidation of fat and glucose
  - The indirect calorimetry machines were called metabolic cards
- As exercise intensity increases, one needs more oxygen
  - VO2 increases, and more CO2 is produced
- In a lipolytic state, a more fatty oxygenation state, you still consume oxygen, but you do not produce as much CO2
- In a more glycolytic state, which occurs at higher exercise intensity
  - You’re recruiting the type II muscle fibers
  - You’re using more glucose for energy purposes, consuming more oxygen and producing more CO2
- Plug in all these numbers into stoichiometric equations, and it will give you a profile of fat oxidation versus work (or power output) throughout the ramp state (a ramp test)

## Using fat and carbohydrate utilization to calculate the mitochondrial function and metabolic flexibility [35:45]

**Metabolism of elite athletes compared to a recreational athlete, or someone with metabolic disease**

- This is where elite athletes like Pogačar have an amazing fat oxidation capacity compared to other competitive athletes
  - They have also characterized this in recreational athletes, or people with even type 2 diabetes or metabolic syndrome, and even with COVID patients
  - This reflects what’s happening in the mitochondria and how the mitochondria oxidizes those fuels at different exercise intensities
  - For example, at an intensity of 200 watts (W), an elite athlete does not use their glycolytic capacity as much a someone who is not well trained
    - The elite athlete can still recruit slow twitch muscle fibers and rely on fat to produce ATP because they have amazing mitochondrial function and are very efficient, metabolically speaking
  - In a recreational athlete, or someone who is sedentary, or someone with type 2 diabetes, you’re going to see mitochondrial impairment or dysfunction at 200 watts
    - They will fully rely on glucose because they cannot sustain that effort with fat oxidation alone
    - This will be reflected in the gas exchange, the CO2 and VO2

**Determining oxidation of fat and carbohydrates indicates mitochondrial function**

- This can be plotted to produce a metabolic map of fat oxidation and carbohydrate oxidation
- In an indirect way, you can calculate the mitochondrial function and metabolic flexibility, to determine how fats and carbohydrates are utilized
  - This can allow you to determine training zones
  - Iñigo has been using this methodology for 16-17 years
- Iñigo uses [equations described by Frayn in 1983](https://pubmed.ncbi.nlm.nih.gov/6618956/) to calculate fat oxidation and carbohydrate oxidation
  - These have been validated with stable isotope tracers ([double labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water))
- In a study he’s going to publish soon, he has validated fat oxidation and carbohydrate oxidation directly with mitochondrial respiration.
- In muscle biopsies, he has directly injected: fatty acids, pyruvate representative of carbohydrates, and glutamine representative of amino acids
  - From this he can see that a very high correlation between this indirect methodology to look at mitochondrial function and the direct methodology, which is through muscle biopsy and injecting the substrate and seeing how it’s oxidized

## Lactate levels and fat oxidation as it relates to Zone 2 exercise [40:00]

**Analysis of cellular metabolism as exercise workload increases**

**Blood lactate levels:**

- The change in blood lactate levels as workload increases can be used to define Zone 2 training
- Peter finds these 2 graphs (below) really powerful
  - From *Sports Medicine* 2018, [Assessment of Metabolic Flexibility by Means of Measuring Blood Lactate, Fat, and Carbohydrate Oxidation Responses to Exercise in Professional Endurance Athletes and Less-Fit Individuals](https://pubmed.ncbi.nlm.nih.gov/28623613/)
  - The independent variable here is the workload in watts (x-axis); that’s the metric that matters in cycling, which is he thinks the easiest way to do this test
  - This shows a progressive increase in workload as the wattage increases
  - The y-axis is the dependent variable; the first figure below follows blood lactate
    - The triangles represent individuals with metabolic syndrome (MtS); they have a resting lactate that is almost 2 millimole (mmol)
    - The squares represent a modestly trained athlete (MA)
    - The diamonds represent a professional athlete (PA)

![](https://peterattiamd.com/wp-content/uploads/2022/03/f2-inigo2-1024x516.png)

**Figure 2.  Relationship between blood lactate levels and exercise power in: professional athletes (PA), moderately active individuals (MA), and individuals with metabolic syndrome (MtS).**  Image Credit: [*Sports Medicine* 2018](https://pubmed.ncbi.nlm.nih.gov/28623613/)

![](https://peterattiamd.com/wp-content/uploads/2022/03/f3-inigo2-1024x528.png)

**Figure 3.  Fat oxidation versus power in: professional athletes (PA), moderately active individuals (MA), and individuals with metabolic syndrome (MtS).**  Image Credit: [*Sports Medicine* 2018](https://pubmed.ncbi.nlm.nih.gov/28623613/)

- Iñigo thinks resting blood lactate levels are going to be used more and more as a biomarker, like resting blood glucose levels
- In patients with type 2 diabetes or profound metabolic syndrome their resting blood lactate levels are 1.5-3 mmol

**Using blood lactate levels to define Zone 2 exercise in individuals with different levels of fitness**

- Peter recalls their discussion of using a blood lactate level of about 2 mmol as a marker of the threshold for Zone 2 exercise
  - Increasing lactate beyond 2 mmol indicates movement from Zone 2 to Zone 3
- Looking at these date, the individual with metabolic syndrome is tapping out Zone 2 initially, any incremental workload placed on them takes them out of zone 2
  - By the time they’re at 100 watts, they’re already at the threshold of their Zone 2
- Conversely, when you look at that medium trained individual (moderately active, healthy, squares in figure 1), they start out with a lactate of about 1, and it’s not really until they hit about 175 watts that they pass that inflection point where they move beyond Zone 2
- Professional endurance athletes (represented by diamonds)start out at a lactate level of 0.5 mmol, and they stay relatively flat until they hit about 300 watts is when they finally cross over that threshold
  - This would normalize the data for weight
- Peter notes that as you move from left to right, the athletes get lighter; he would like to see the x-axis in watts per kilogram
  - Iñigo agrees, but this is what the reviews wanted; one review did not allow them to use watts/kg
- The person with metabolic syndrome would be in Zone 2 at 1-1.3 watts/kg
- The modestly trained individual is in Zone 2 at probably around 2-2.2 watts/kg
- The professional athlete is in Zone 2 in the ballpark of 4 watts/kg
- Peter notes for his patients he aspires to see 3 watts/kg as an elite level of fitness

**Analysis of fat oxidation changes as workload increases in individuals with different levels of fitness**

- The second figure looks at the same groups of individuals, the same independent variable (workload in watts, x-axis), but now the dependent variable is fat oxidation (y-axis)
  - Fat oxidation is easy to calculate via [indirect calorimetry](https://en.wikipedia.org/wiki/Indirect_calorimetry)
- 2 things stand out
  - 1) The fitter the individual, the higher their absolute capacity for fat oxidation
  - 2) A fit individual will actually increase fat oxidation to a local maxima before that oxidation begins to decline whereas most mortals begin at a maximum and decline from there
  - Why is this change in fat oxidation occurring?
- Iñigo starts training at 1-1.5 watts/kg
  - For an elite athlete this is below resting level
  - They don’t need to use much fat for energy until they are pushed harder (2-3.5 watts/kg)
- In people who are not very fit, starting above 1.5 watts/kg may be too much
- If you started at 0.5 watts/kg, you might see a higher fat oxidation and the same phenomenon
  - 0.5 watts/kg is nothing; this is close to resting levels; one can maintain this for a long time
- If you start at 2 or 1.5 watts/kg with someone who has significant metabolic dysregulation, you’re going to miss their fat max (maximum fat oxidation, fat max ox)
- Fat max ox is occurring earlier than when blood lactate levels reach 2 mmol
  - This is true for everyone except those with metabolic syndrome, because their levels are so low
  - The moderately fit person hits their maximum fat oxidation at about 130 watts, but they’re hitting a lactate of 2 at 175 watts
  - The professional athlete is hitting maximum fat oxidation a little shy of 250 watts but they’re hitting 2 mmol of lactate closer to 300 watts

**Relating maximum fat oxidation to Zone 2 exercise**

- Peter asks if Zone 2 should be redefined as the place where maximum fat oxidation occurs
- Looking at these 2 graphs, using a blood lactate level of 2 mmol might be too much

- Iñigo agrees, this is what he has been learning all these years
  - Blood lactate levels change between groups
  - Everything is related to the lactate kinetics and lactate oxidation in the mitochondria

**Relating lactate levels to metabolic stress in individuals at different fitness levels**

- Part of his doctoral thesis (published 20-some years ago) showed that the same blood lactate concentration in an elite athlete does not correspond to the same metabolic stress in a recreational athlete
  - 2 mmol lactate in elite athletes might be a higher metabolic stress than 2 mmol in a patient with metabolic syndrome
- A patient with metabolic syndrome can exercise for a couple hours with a blood lactate level of 2.5 mmol
  - A professional athlete is going to be hurting at that lactate level
- 4 mmol is the gold standard for lactate threshold
- Put a world class athlete and a recreational athlete at 4 mmol lactate and measure intensity and power output and ask who can maintain this output the longest
  - Intuitively you would think it would be the world class athlete; it’s the opposite
  - Iñigo observed this 20 years ago
  - Recreational athletes at the same blood lactate concentration would go about 30% longer because metabolically, it’s not as taxing for them as an elite athlete
  - The main reason is that the lactate measured in the blood reflects what is not oxidized by the mitochondria

**Metabolism of lactate**

- When someone has high power output, they need a lot of glycolysis to provide that energy; this will produce lactate
- Lactate is the mandatory obligatory byproduct, not waste product, but byproduct of glycolysis
- So the higher the glycolysis, the higher the lactate
- Lactate has 2 routes it can take
  - 1) Lactate can go from the fast twitch muscle fibers to the slow twitch muscle fibers
    - This is the lactate shadow that George Brooks discovered
    - Lactate is oxidized in the mitochondria of those slow twitch muscle fibers
  - When someone has good lactate clearance capacity, they will be good at oxidizing it for fuel and will not use the 2nd route
  - 2) Lactate can be exported to the blood
    - This occurs when there is poor mitochondrial function
    - When the ability of the mitochondria to take in and oxidize lactate is saturated, the lactate will be exported to the blood
    - This will be at a lower power output in less fit individuals
    - This is why looking at blood lactate levels in individuals at different fitness levels may not mean the same thing
    - The disparities are not huge

## How moderately active individuals should train to improve metabolic function and maximize mitochondrial performance [51:45]

***How should the moderately active individual train to maximize mitochondrial performance?***

- Based on these data, the moderately active individual hits 2 mmol lactate at 175 watts but max fat oxidation at 125 watts
  - That’s a 50 watt difference
- What should this person do to improve metabolic function, mitochondrial performance, fuel flexibility?
  - Should Zone 2 be defined as 125 watts or 175 watts?
- Iñigo advises going somewhere in the middle

**Compare blood lactate levels to fat oxidation as power output of exercise increased**

![](https://peterattiamd.com/wp-content/uploads/2022/03/f4-inigo2-751x1024.png)

**Figure 4. Comparing blood lactate and fat oxidation at different power outputs in: elite athletes (A), moderately active individuals (B), and individuals with metabolic syndrome (C)**.  Image Credit: [*Sports Medicine* 2018](https://pubmed.ncbi.nlm.nih.gov/28623613/)

- For an elite athlete, graph A above shows a correlation between blood lactate levels and fat oxidation where [R =](https://en.wikipedia.org/wiki/Correlation_coefficient) 0.97
  - The correlations are also very strong in the moderately active (B) and metabolic syndrome (C) individuals
- So normally fat oxidation and lactate go together
- These graphs show 2 lines
  - 1) An initial increase in fat oxidation followed by a decline in fat oxidation
  - 2) Lactate production increases with increased power output
- Peter asks if where these 2 lines cross means anything
  - For the elite athlete, they’re crossing at about 325 watts
- Iñigo notes that the crossover point in these 2 lines occurs at a high wattage in elite athletes
  - In moderately active people it’s closer to 180 watts
  - In individuals with metabolic syndrome it’s about 125 watts
- As exercise intensity increases, one needs to oxidize more carbohydrates
- As exercise intensity increases, one may get to the maximum for fat oxidation and in a moment switch to glycolytic fibers
- As exercise intensity increases beyond a certain point, fat oxidation declines sharply and disappears
- High intensity exercise requires energy to be produced quickly by glycolysis (utilization of carbohydrates)
- Lactate is the byproduct of glucose utilization

> “*All these elements, fat oxidation, carbohydrates, and lactate, they’re very well connected”*— Iñigo San-Millán

**Relationship between blood lactate levels and carbohydrate utilization as the power output of exercise increases**

![](https://peterattiamd.com/wp-content/uploads/2022/03/f5-inigo2-731x1024.png)

**Figure 5.** **Comparing blood lactate and carbohydrate oxidation at different power outputs in: elite athletes (A), moderately active individuals (B), and individuals with metabolic syndrome (C)**.  Image Credit: [*Sports Medicine* 2018](https://pubmed.ncbi.nlm.nih.gov/28623613/)

- The correlations are quite good because lactate is the byproduct of glucose utilization
- In the elite athletes (A) the gap is wider; they use a lot of glucose
  - The larger the gap between the blood lactate curve and carbohydrate oxidation curve, the more efficient the individual is in clearing lactate (oxidizing lactate)
  - Here the lactate doesn’t show up in the blood, it stays in the muscle
  - This reflects the lactate shuttle ([MCT transporters](https://en.wikipedia.org/wiki/Monocarboxylate_transporter) at work); this allows the mitochondria to use lactate as a fuel

## Bioenergetics of the cell and what is different in elite athletes [57:30]

- The cell uses 2 main substrates for fuel: fatty acids and pyruvate, but also lactate (outlined in the figure below)
  - 1) Normally glucose goes through [glycolysis](https://en.wikipedia.org/wiki/Glycolysis) and ends up in the cytosol, outside the mitochondria, where it is oxidized to pyruvate
    - That pyruvate enters the mitochondria via a pyruvate carrier
    - In the mitochondria it’s oxidized to acetyl-CoA which enters the [Krebs cycle (aka the citric acid cycle)](https://en.wikipedia.org/wiki/Citric_acid_cycle)
    - Complete oxidation of glucose occurs via [oxidative phosphorylation using the the electron transport chain](https://en.wikipedia.org/wiki/Oxidative_phosphorylation)
  - 2) Fatty acids use a similar mechanism
    - Fatty acids get converted to acetyl-CoA through different mechanisms
    - Fatty acids are processed by [CPT-1 then CPT-2](https://en.wikipedia.org/wiki/Carnitine#Carnitine_shuttle_system); this converts them to acetyl-CoA in the mitochondria for oxidation

![](https://peterattiamd.com/wp-content/uploads/2022/03/f6-inigo.jpg)

**Figure 6. Oxidation of pyruvate and fatty acids in the mitochondria to produce energy (ATP).** Image Credit: [Molecular Biology of the Cell](https://www.ncbi.nlm.nih.gov/books/NBK26894/figure/A2504/?report=objectonly)

- But every time you use glucose, you produce pyruvate
  - And every single time, that pyruvate is going to be reduced to lactate; this is the key concept
- Glycolysis utilizes NAD+ and transforms it to NADH + hydrogen (see the figure below)
- When glycolysis is utilized rapidly, this will deplete NAD+ and the only way to replenish it is to reduce pyruvate to lactate
  - This is necessary for glycolysis to continue

![](https://peterattiamd.com/wp-content/uploads/2022/03/f7-inigo2-1024x707.png)

**Figure 7. Lactate is produced when energy demands are high to provide the NAD+ required for glycolysis.**  Image Credit:[OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/7-5-metabolism-without-oxygen)

- 3) But this lactate enters the mitochondria through a specific transporter (MCT1), then  a specific enzyme ([LDH, lactate dehydrogenase](https://en.wikipedia.org/wiki/Lactate_dehydrogenase)) oxidizes lactate back to pyruvate so it can enter the Krebs cycle
- Lactate acts as an extra fuel, but to utilize it, these transporters must be expressed

- 3 transporters that are needed to move metabolites into the mitochondria where they can be used for the most efficient form of ATP production (they will enter the Krebs cycle and then the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain) for oxidative phosphorylation)

![](https://peterattiamd.com/wp-content/uploads/2022/03/f8-inigo2-1024x680.png)

**Figure 8. Transporters (MPC, MCT1, and CPT) move metabolites into the mitochondria for oxidation.**

- Fatty acids enter the mitochondria via [CPT](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_I) and are converted to Acetyl-CoA (2 carbon molecule) that can enter the Krebs cycle
- There are 2 fates of glucose byproducts
  - 1) Traditionally we think of glucose being reduced to pyruvate (via glycolysis), pyruvate entering the mitochondria then being converted to acetyl-CoA
    - This follows the same fate of the fatty acid (Krebs cycle + electron transport chain = ATP)
  - As energy demands increase, no matter how fit you are, at some point you produce more lactate and don’t have enough cellular oxygen to go down this first route
  - 2) If there are enough MCT1 transporters in the mitochondria, you can bring lactate into the mitochondria for oxidative phosphorylation
    - Lactate is converted back to pyruvate
    - Pyruvate becomes acetyl-CoA
    - Acetyl-CoA enters the Krebs cycle, and this will continue on to the electron transport chain where the majority of ATP is produced
    - Oxidation of lactate will produce 32 units of ATP instead of just the 2 ATP made by glycolysis and the reduction of pyruvate to lactate

**Increased expression of MCT transporters allows for increased oxidation of lactate**

- Thinking about what makes Pogačar so remarkable physiologically, perhaps he has a boatload of MCT1 transporters in his mitochondria
  - This could explain in part why his blood lactate levels are so much lower than everybody else’s at a comparable work level
  - How much of that is genetic and how much is a result of his training?
- Having more MCT1 transporters will allow for increased oxidation of lactate
  - There is a genetic component to this
  - There is also an [epigenetic](https://en.wikipedia.org/wiki/Epigenetics) component
    - Expression can be affected by how you train, how you rest, how you eat, etc.
    - Training is aimed at increasing the  MCT1 transporters for lactate and also pyruvate
- These transporters are downregulated in people who are sedentary
- This is what is different in professional athletes
- Fast twitch muscle fibers use glucose
- During high intensity exercise (climbing, running at high intensity or swimming, etc) requires glucose
  - Glucose is converted to pyruvate then to keep glycolysis going, pyruvate is converted to lactate
    - This yields less ATP than going through the Krebs cycle and electron transport chain, but it provides ATP much faster
    - The ATP generated from lactate production occurs much faster than oxidation of fatty acids
  - Using glucose as a fuel always results in the production of pyruvate
    - Higher intensity exercise results in the production of more pyruvate and then more lactate
  - Lactate has 2 routes it can take

![](https://peterattiamd.com/wp-content/uploads/2022/03/f9-inigo2-1024x665.png)

**Figure 9. Export of lactate from fast twitch to slow twitch muscle fibers where it can be oxidized.**

- 1) Lactate can enter the mitochondria via MCT1
  - It can be taken into the cell then into the mitochondria via MCT1 where it will be converted to pyruvate → acetyl-CoA then enter the Krebs cycle
- 2) Lactate can be transported out of the fast twitch muscle fibers
  - It travels to adjacent slow twitch muscle fibers where it will be oxidized to produce energy

> “*Well-trained athletes… have an amazing ability to oxidize the lactate inside mitochondria*”— Iñigo San-Millán

- At some point, everyone gets to the point where they cannot sustain the effort anymore
- What’d difference in these guys is they can do 400 watts for a long timer versus a mere mortal who cannot even do 2 strokes at 400 watts
- When there is a lot of MCT1 and mitochondrial function, lactate will increase and accumulate
  - But it’s not the lactate per se, but the hydrogen ions associated with the lactate that elicit acidosis of the micro environment of the muscle
- We learned from cancer that the cancer microenvironment is very acidic
- An acidic environment will interfere with different functions in the muscle with regards to the force and velocity of the muscle fibers
  - This is not necessarily the cause of fatigue; there are multiple theories about that
- When the lactate cannot be oxidized, it is exported to the blood
- This is why people with poor mitochondrial function (people with metabolic syndrome or type 2 diabetes) cannot oxidize lactate during exercise
  - The mitochondria in their slow twitch muscle fibers also don’t use fat; they rely on glucose
  - The moment they start using glucose, they produce lactate
  - But they cannot oxidize the lactate; this is why it is exported to the blood
- By the time Pogačar saturates MCP1 and his mitochondrial capacity to oxidize lactate, he’s achieved a tremendous amount of power output
  - This is why a blood lactate level of 1 or 1.5 in a world class athlete doesn’t represent the same metabolic status as the same lactate level in a normal person
- [Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) and his team showed that well-trained athletes use more glucose
  - You cannot do 400 watts without a massive amount of carbohydrate oxidation
- Indirect calorimetry of recreational athletes or people with metabolic syndrome shows a maximum of 4 g/min carbohydrate oxidation
  - Elite athletes can get to 6.5 gram/ min; this is a massive amount of glucose oxidation
  - And elite athletes will produce more lactate
    - But the key is, it doesn’t show up in the blood because it’s oxidized in the muscle
    - This correlates a lot with fat oxidation as well

## How the level of carbohydrate in the diet and ketogenic diets affects fuel utilization and power output during exercise [1:08:30]

**Metrics of cellular metabolism when on a ketogenic diet**

- 10 year ago, Peter was on a [ketogenic diet](https://en.wikipedia.org/wiki/Ketogenic_diet) for 3 years; it was at the end of that 3 year period when he got back into cycling
  - There there was about a 6 to 12 month period when was still in ketosis, and was getting back into cycling shape
  - He has 1 [VO2 max test](https://en.wikipedia.org/wiki/VO2_max) from that time
  - These data are interesting; he observed a maximum fat oxidation of 1.3 g/min
    - This occurred almost immediately
    - It was sustained until about 3.5 watts/kg; then it fell off and glucose became the dominant fuel source
    - At the time his FTP (functional threshold power) was about 4.1 watts/kg
    - At the end of the test his glucose oxidation was just under 6 g/min, about 24 KCAL/min
  - Peter has seen this with another very fit cyclist who has been in ketosis for 7 years
    - His 20 minute FTP test was about 412 watts for 20 min
    - This guy could hold 1200 watts for 15 seconds; that’s good glycolytic power
    - His fat oxidation was 1.5 g/min
    - This made it confusing to define Zone 2 by maximum fat oxidation

**Metrics that define Zone 2 exercise should be adjusted for a ketogenic diet**

- [Ketosis](https://en.wikipedia.org/wiki/Ketosis) is an extreme example, but given how much the [respiratory quotient](https://en.wikipedia.org/wiki/Respiratory_quotient) (RQ; the ratio of VCO2 to VO2) depends on baseline carbohydrate intake— how do you adjust the definition of Zone 2
  - Peter’s data would lead you to dramatically overestimate his mitochondrial efficiency
  - He doesn’t have lactate data from that test
  - His blood glucose was 4-5 mmol
- Iñigo thinks there is an artifact in the metabolic card
  - The metabolic card measures gas exchange, and then through the equations it says, this person must be burning fat or burning carbohydrates
- As you exercise, no matter what fuel you’re using, you keep increasing oxygen consumption
- But if you don’t have much carbohydrates, you’re not going to produce much CO2
  - This will mislead the stoichiometric equation because the algorithm is going to think you’re using a lot of oxygen and now producing enough CO2
  - Instead you’re going to be burning a lot of fat; that’s why you see fat oxidation north of 1 g/min
- If you were to change your diet, 3 days later your fat oxidation might be 0.35
- This is an artifact of the gas exchange
- Someone in ketosis would have a maximum blood lactate of 2-3 mmol because simply they don’t have carbohydrates
- Peter would like to see this studied again, because if someone is only eating 50 g of glucose a day
  - How much glycogen are they making from the glycerol of all the fat that’s being converted to ketones?
  - When Jeff Volek and Steve Finney looked at this, they put people into very strict ketosis and did muscle biopsies
    - They still saw 60% glycogen content in the muscle relative to what was there under high carb conditions
  - Peter thinks his capacity to oxidize 5.5-6 g glucose/min was still there; it just took a long time to get there
- Peter asks, “*is the VCO**2* *estimation off because of the stoichiometric coefficients, or do you think the VO**2* *estimation is also off?”*
- No, Iñigo doesn’t think the VO2 estimation is off; ketones are used very well for energy purposes

## Glutamine as a source for making glycogen—insights from studying the altered metabolism of ICU patients [1:15:00]

**Glutamine can be used as a fuel and to generate glucose**

- There is a 3rd element that is key in bioenergetics— [glutamine](https://en.wikipedia.org/wiki/Glutamine)
- [Glutaminase](https://en.wikipedia.org/wiki/Glutaminase) it’s highly expressed and utilized; it converts the amino acid glutamine to [glutamate](https://en.wikipedia.org/wiki/Glutamic_acid) (which can enter the Krebs cycle)
  - Iñigo has learned that from ICU patients
  - ICU patients are  a great model to study stress metabolism
  - For wound healing, ICU patients use about 3x more glucose at rest than what we have
    - It’s part of the healing process
- Iñigo published a pilot study with ICU patients; they lack muscle glycogen
  - Published in *Critical Care* in 2015, [Winning the war against ICU-acquired weakness: new innovations in nutrition and exercise physiology](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4699141/)
- By the time someone gets into the ICU they use 3x the glucose at rest
- An athlete uses the same amount of glucose during high intensity exercise but for a reduced amount of time 2-4 hours
- For someone in the ICU, they are using that amount of glucose 24/7
- Eventually the body is going to run out of glycogen in the muscle; this will cause huge stress to the body
- Glutamine is another source of fuel
  - It directly enters the mitochondria and is oxidized
- This is where [cachexia](https://en.wikipedia.org/wiki/Cachexia) come into play; every ICU patient becomes cachectic or suffers from muscle loss
  - This is the post ICU muscle wasting syndrome
- ICU patients express tremendous levels of glutamine because they need it to either enter the Krebs cycle for energy or for [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis)
- ICU patients also have [hyperglycemia](https://en.wikipedia.org/wiki/Hyperglycemia)
  - In the acute ICU phase, they also have [insulin resistance](https://en.wikipedia.org/wiki/Insulin_resistance)
  - Their hyperglycemia is off the charts
    - They are not going to get IVs of glucose
    - These patients benefit from receiving protein
- Giving them glutamine has been shown to increase survival
- The question becomes, “*where is this hyperglycemia coming from when you do not have glycogen?*”
  - It is probably coming from protolysis (breakdown of protein) from muscles to release glutamine
- Peter asks about the hepatic glycogen stores of these patients
- The liver is maintaining hyperglycemia; from an evolutionary perspective, you’d rather err on the side of hyperglycemia than hypoglycemia
- Iñigo agrees; the liver is the source of gluconeogenesis
  - His hypothesis is that glutaminolysis is occurring in the muscle

> “*Those muscles, they eat themselves to feed themselves or to feed the rest of the body*”— Iñigo San-Millán

- Peter reasons that exercising ICU patients, getting some load bearing resistance, would be important
  - Iñigo’s colleague [Paul Wischmeyer](https://scholars.duke.edu/person/paul.wischmeyer) (now at Duke University) is researching this
- Iñigo thinks this hyperglycemia likely comes from gluconeogenesis
  - There could be a lot of glutamine released when you’re in a state of ketoacidosis as well
    - Especially in the first phase; we know that cortisol is very high at first
- 2 main parameters in ICU patients that are predictors of mortality are
  - 1) High cortisol levels
  - 2) High lactate levels
  - These feel related; it’s a great model to understand stress metabolism

## How exercise mobilizes glucose transporters—an important factor in diabetic patients [1:21:00]

- Once you exercise, you have insulin resistance and difficulty translocating [GLUT4 transporters](https://en.wikipedia.org/wiki/GLUT4) to the surface of the muscle
  - These move glucose into the cell
- Skeletal muscle is probably the first tissue where diabetes starts because around 80% of the carbohydrates we have are oxidized in skeletal muscle
  - Pyruvate should be oxidized in the mitochondria
- But with insulin resistance, GLUT4 transporters cannot be translocated
  - But there is a second way to move those transporters that not many people know about— that’s muscle contraction
  - Muscle contraction is insulin-independent mechanism of translocating GLUT4 transporters to the cell surface
- Glucose uptake also seems to be heavily dependent on fitness

> “*The fittest athletes require virtually no insulin to translocate glucose into the muscle, through the insulin independent pathway*”— Iñigo San-Millán

- Insulin also translocates GLUT4 transporters to the cell surface; and these transporters start bringing glucose inside
- He has learned from people with [type 1 diabetes](https://en.wikipedia.org/wiki/Type_1_diabetes), they should not inject themselves with insulin before exercise
  - This would result in 2 signals for translocating these receptors (insulin and muscle contraction), resulting in [hypoglycemia](https://en.wikipedia.org/wiki/Hypoglycemia)
  - Exercise alone is enough to take care of the glucose
- This can be applied to people who have insulin resistance (with pre-type 2 diabetes)— exercise right after you eat that carbohydrate
  - This will bring those transporters to the cell surface to move glucose into the cell
  - You are not going to need insulin
- Peter agrees and relates this to his own observations with lactate testing
  - He has tested his lactate every 30 minutes for a day
    - Yes, this is insane, expensive, and painful for your fingers
    - But it allowed him to learn how much a meal impacts blood lactate levels
  - When he wakes in the morning, his resting lactate level varies
    - He’s tracked this for over 40 days; it ranges from 0.3 -1.1
    - The median level is around 0.8
    - Iñigo notes that in the neighborhood of 1 is normal for a fit individual
  - Next he may eat a very high carb breakfast and go and do a Zone 2 ride or don’t eat anything at all and go and do a Zone 2 ride
    - This results in a very different lactate performance curve
    - The high carb meal raises lactate

## Metrics for finding Zone 2 threshold—lactate, heart rate, and more [1:25:00]

**Metrics for characterizing Zone 2 training**

- In a patient or a world class athlete you have the ability to do indirect calorimetry and lactate testing to determine Zone 2 training
  - But training normal people is different
  - The lactate measured in the blood is heavily influenced by production and clearance
- The gold standard would be to measure fat oxidation
  - But even this can be confounded in people on a ketogenic diet
- With patients, Peter will do a Zone 2 test based on their fat oxidation during an escalated VO2 max test
  - For example, their maximum fat oxidation may be 0.3 g/min, and this occurs at a wattage of 1.5 watts/kg
- How should patients train to achieve Zone 2?
  - They won’t be able to train with indirect calorimetry
  - Some people will have lactate meters and some people won’t
- What is a good surrogate for determining your training zone?

- In this example, the patient oxidizes the most fat at a workload of 1.5 watts/kg
- Peter wants them to increase this to 2.5

**How would Iñigo recommend they train?**

- He would start with a metabolic test; this information can provide watts, or speed, or heart rate (many people don’t have a power meter)
- Peter brings up another metric he uses with patients, RPE
  - Peter misspeaks and defines this metric as “relative perceived exertion”, instead of “rating of perceived exertion”
  - From his experience, he is in Zone 2 when his lactate levels are between 1.7-1.9 mmol
  - He can carry on a conversation but it’s not as comfortable
  - Iñigo agrees, **exercising at a level where you can carry on a conversation and it feels a bit strained** is a good surrogate for knowing you’re in Zone 2
    - You will be just at that threshold of not being able to carry on a conversation
    - The person you’re talking to will know you are exercising

**How to use heart rate as a guide**

- For people who have not done a metabolic test, heart rate is a good guide
- First you need to determine your maximum heart rate (not the predicted maximum)
  - For Peter, he is in Zone 2 when he is working at 78-81% of his maximum heart rate
  - For less trained people, this % is lower
  - He tells patients to start at a broad range of 70-80% of their realized maximum heart rate
    - Then make adjustments based on their rating of perceived exertion
- Iñigo notes what your **resting heart** rate can tell you
  - Take your heart rate when you first wake up
  - For example, if you’re normal heart rate is 50 and you’re a bit fatigued, you might wake up with a heart rate of 65
  - This ties into the concept of [heart rate variability](https://en.wikipedia.org/wiki/Heart_rate_variability);  heart rate will vary from day to day
  - Waking up with a higher heart rate is a red flag that you are fatigued
    - Some people’s heart rate is not super sensitive to this but elite athletes are for sure
- Secondly, if your **Zone 2  heart rate** is 130, some days it  might be hard to get to that rate
  - You may be struggling at 110 beats per minute
  - This also falls into that concept of heart rate variability
  - Athletes will see this; they can’t get their heart rate up on days they are fatigued

**An experiment Peter did with medication to lower heart rate**

- If he takes a huge dose of a [beta blocker](https://en.wikipedia.org/wiki/Beta_blocker), it takes all the gas out of his heart rate
  - This allows him to push harder and generate a higher Zone 2
  - You have to be careful if you have low blood pressure (like Peter), but [propranolol](https://en.wikipedia.org/wiki/Propranolol) is fine
    - It lowers the heart rate but not the blood pressure
  - This is not a pleasant experience but an interesting self experiment
- Peter’s Zone 2 is 2.75-2.85 watts/kg; he really wants to get over 3
  - At this level he is at the upper end of maximum heart rate, 81% maximum heart rate
- If he takes 60 mg of time released propranolol, he is able to get over 3 watts/kg and his heart rate will only be at 68% of maximum
  - But it feels horrible; he feels like he’s going to die
  - It’s not pain, but it’s the worst feeling in the world

**How fatigue and glycogen stores affect heart rate**

- Iñigo relates this to what you feel when you’re fatigued, when you don’t have enough fuel
- He has experienced difficulty adjusting to exercise after a few days of intermittent fasting
- When you don’t have enough glycogen storages, it’s very possible that adrenal activity is decreased
- You need to break down glycogen; this requires [glycogen phosphorylase](https://en.wikipedia.org/wiki/Glycogen_phosphorylase#Mechanism) in the muscle and that’s directly regulated by [catecholamines](https://en.wikipedia.org/wiki/Catecholamine)
- Iñigo’s hypothesis is that when there is decreased glycogen stores, the brain says, “*I don’t care about your legs, don’t use up all the glycogen because you have to give it to me*”
  - The brain doesn’t shut down glycogen degradation, but it slows it down by releasing less catecholamines
  - The collateral effect of that is a lower heart rate; catecholamines also regulate heart contractility (they increase heart rate)
    - So a lower level of catecholamines results in a lower heart rate
- When he sees that an athlete’s heart rate is not going up as it usually would, he knows they have less glycogen stores
  - So he advises them to take an easy day or load up on carbohydrates
  - Then see how responsive they are the following day
  - 9 times out of 10, they are back at their top level the next day
- The brain uses about 100-125 g of glucose a day
  - When your work involves a lot of thinking and stress, the brain might need a lot more glucose
  - This can be supplied by [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis)
  - Muscles can also release glucose to be utilized by the brain as well
    - Glycogen phosphorylase in the muscle will degrade glycogen to glucose and that can go into circulation to feed other organs
    - This requires [glucose 6-phosphatase](https://en.wikipedia.org/wiki/Glucose_6-phosphatase) to release glucose from the cell ([activity observed in skeletal muscles of mice followed by release of glucose](https://pubmed.ncbi.nlm.nih.gov/3022618/))
    - This is small compared to what the liver is doing, but it’s possible
- Iñigo has noticed that some days when he is stressed (not dieting) he feels dead when he goes out to exercise
  - He wonders what is going on
  - He notices that his **heart rate doesn’t get up** on those days
  - Maybe you’re not overtrained but overworked
  - On days like this, he takes a day completely off
    - He sleeps  more
    - He increases his carbohydrate intake
    - The day after this, he feels like a million dollars and can even beat his PR (personal record)
- Resting recovery is key for performance
- Peter agrees; he used to judge his performance by training load (not anymore)
  - He’s found that when he is doing too much work-wise, his performance suffers
  - He has to cut back on training to make time for more sleep or more relaxation

## Optimal Zone 2 training: dose, frequency, duration, and type of exercise [1:41:15]

**Advice for the person new to Zone 2 training**

- High intensity training is not enough
- Maybe someone new to this does some weights, plays some tennis, but they don’t really do any stead-state, sustained cardio (Zone 2)
- Peter asks Iñigo what training program he would recommend

> “*You can accomplish very important mitochondrial adaptations and very important metabolic adaptations by exercising one hour*”— Iñigo San-Millán

**Duration of exercise**

- Aim for 1 – 1.5 hour
- Iñigo has measured adaptations that occur after training: fat oxidation, lactate clearance capacity
  - Both are surrogates of mitochondrial function
- If you only train once a week, chances are your mitochondrial function will deteriorate over time, especially as you age
  - He sees this in body builders and high intensity exercisers— they have very poor mitochondrial function compared to people who do a little bit of everything
- 2 days a week might maintain what you have
  - If you are new to an exercise program, this might not be enough
- 3 days a week will start to show results
- 4 days a week is ideal for sure
- 5-6 days a week are ideal; but not everybody has 6 days a week to train
  - 4-5 days a week of training is achievable for most people
- Put aside 1-1.5 hours

> “*Maybe Pogacar needs four hours, five hours to keeping increasing those huge mitochondria for a long time*”— Iñigo San-Millán

- For a mere mortal, somebody just starting out who may not be fit, you can’t start off with 1 hour
  - Start with 20, 30, or 40 minutes
  - Gradually build up to a 1 hour walk or run
- If you bike, 1 hour 20 minutes or an hour and a half, 4 days a week is good
- For patients just starting out, Peter is happy if they exercise 30 minutes, 3-4x a week
- Peter can’t do Zone 2 on the road; he uses a trainer
  - It’s hard to stay at a constant level on the road with starting and stopping, wind and hills, etc.
  - Iñigo agrees, the trainer is great, it isolates everything; if you can go 1 hour on the trainer
    - He likes to be outside
    - But on the trainer he will watch a movie or catch up on work— low-key activity
- For people who haven’t done much, even 20-30 minutes might start producing results
  - But eventually this is not enough
  - The body will need longer training periods to boost mitochondrial function

> “*If you can get to a goal of about an hour to an hour and a half, that should really work*”— Iñigo San-Millán

**Frequency of Zone 2 training**

- It’s also important to stimulate other energy systems like the glycolytic system
- People think that all elite athletes do is high intensity all the time and intervals; it’s the exact opposite
- The workload is very similar in an elite athlete of any sport, whether it’s a triathlete or a cyclist or a marathon runner, or a swimmer
- The majority of their exercise sessions are lower intensity
- We cannot be so naive as to think that the best coaches and athletes in the world haven’t figured this out when they’re always trying new, cutting-edge things
  - Elite athletes spend hours and hours and hours of training to just improve a fraction of a second
- Increasing glycolytic capacity and high intensity training are necessary but they are not what elite athletes do

> “*The elite athletes have the best metabolic function of any human. Why not try to imitate their philosophy of exercise?*”— Iñigo San-Millán

- Peter asks Iñigo to compare 4 training regimens, each totaling 4 hours per week:
  - 1) 4, 60-minute sessions
  - 2) 1, 80-minute session and 3, shorter sessions
  - 3) 2, 2-hour sessions
  - 4) 1, 4-hours session
- #1 would be the best, 4, 60-minutes sessions has a higher frequency
  - Of course if you have 3 hours on the weekend to add to this, go ahead

## How to incorporate high intensity training (Zone 5) to increase VO2 max and optimize fitness [1:51:15]

- There is a need for some high intensity too

**Peter’s 4 pillars of exercise**

- 1) Stability
- 2) Strength
- 3) Low-end aerobic, to improve mitochondrial efficiency
- 4) High-end aerobic, for peak aerobic/ anaerobic performance
  - Peter struggles the most with this one because when done right, it hurts the most
  - It’s also no longer relevant because he doesn’t compete in anything
  - He enjoyed this type of training when he was competing because he would see the rewards

**High intensity training**

- From a lens of health, the data are unambiguous— VO2 max is highly correlated with longevity
  - There are not many variables that are more strongly correlated
  - But the levels don’t have to be that high
- Pogačar’s VO2 max is probably 85
- Peter notes that for someone his age to be considered elite, in the top 2.5-2.7% of the population; this carries with is a 5x reduction in risk compared to the bottom 25% of the population
  - The VO2 max required here is 52-53 mL/min/kg
  - Peter asks if this can be used as a gauge for how much high intensity training is needed?
- Iñigo thinks more about bioenergetics energy systems
- Longevity is also highly related with mitochondrial function and metabolic health

> “*There’s an aging process where we lose mitochondrial function, and there’s a sedentary component where we lose mitochondrial function*”— Iñigo San-Millán

- Iñigo wishes there was a pill you could take to increase mitochondrial function, because it would increase metabolic health and longevity
- But the only medication we know of is exercise
- Dose and sustainability are important
  - High intensity exercise is not sustainable
  - Very extreme diets are not sustainable
  - If you combine both, it’s even worse
- High intensity training is important to improve glycolytic capacity
- We lose glycolytic capacity as we age and it’s important to stimulate it
- Peter asks, if he has 1 additional training session per week, should he do a 5th session of Zone 2 training or a VO2 max protocol?
- For VO2 max, high intensity training, Peter prescribes patients to do a 4×4 protocol
  - 4 minutes of the highest intensity, sustained exercise followed by 4 minutes of recovery
  - Repeat this 4-6x
  - Add a warm up and cool down on either end and this will be a little over an hour
- Iñigo recommends if you have a 5th day, do any type of high intensity session
- What he does on almost every Zone 2 sesion is at the end, he does a very high intensity interval
- Iñigo does 1.5 hours of Zone 2, 4-5x a week (his typical routine)
  - He tries to do a good 5 minute, high intensity interval at the end
- Increasing mitochondrial function takes months or years
- Increasing the glycolytic system takes much less time, weeks or months
- If you stimulate the glycolytic system 2-3 days you’ll see progress
- Add a high intensity interval 2-3 days a week at the end of that Zone 2 training, and you’ll target both energy systems: the oxidative mitochondrial system and the glycolytic energy system

***Is zone 5 training okay to do immediately following zone 2 training?***

- Peter asks if you blunt the benefit gained from Zone 2 training if you immediately follow it with Zone 5
- Iñigo says no, because it’s done at the end, then exercise is over
  - But don’t do it in the reverse order because this will trigger all these hormonal responses and high blood lactate
  - We know lactate inhibits [lipolysis](https://en.wikipedia.org/wiki/Lipolysis)
  - So if you have a high interval in the middle or the beginning and you don’t clear lactate very well
- Another study Iñigo has under review shows that lactate at the autocrine level decreases the activity of [CPT1](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_I) and [CPT2](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_II) (needed for fatty acid transport into the mitochondria for oxidation)
  - So lactate interferes with the transport of fatty acids as well
- Peter is glad Iñigo raised this point because often patients will say, “*I went out and did a two-hour ride today and it showed me that I spent 45 of those minutes, 45 of those 120 minutes were in Zone 2. So I did 45 minutes at Zone 2*”
  - This is not the same as spending 45 minutes in dedicated Zone 2 training
  - There is a lot of up and down intensity
  - The average might be Zone 2, but you’re oscillating between Zone 1, Zone 2, Zone 4, all the time
- Iñigo has done lots of testing of himself, starting at age 15 but now he gauges his Zone 2 training by sensation
- He is 50 now and is proud that he has the same metabolic parameters he had at age 40
  - Lactate, power, VO2
  - His VO2 is about 4 L/min
  - When he was a cyclist his VO2 was about 4.5-4.8
    - It’s only decreases some which he’s really happy about because he’s not training like he did
    - This proves to him that doing this routine helps to maintain metabolic health (1.5 hours of Zone 2 exercise ending with 5 minutes of high intensity effort, 4-5x a week)
    - He’ll see what happens in the next 10 years

## Compounding benefits of Zone 2 exercise and how we can improve metabolic health into old age [2:01:45]

- Iñigo has seen unbelievable improvement in people who just retired, in their 60’s, who now have time to exercise and sleep; they’re not overworked

> “*It’s unbelievable and super inspiring how much they improve in their 60’s*”— Iñigo San-Millán

- He’s seen people in their 70’s with the metabolic parameters of active 30-year olds
- He knows an 81-year old who is a world champion cyclist in the category of 80-85; he has metabolic parameters of someone in their 30’s
  - He was not a professional athlete in his 20’s or 30’s
  - He  was a hypertensive smoker who started cycling because he needed to change his lifestyle in his 40’s
- Peter takes away from the conversation the importance of compounding
- Iñigo noted earlier the potential to make relatively quick changes in your glycolytic efficiency (to improve VO2 max)
  - You could see 50% improvement in a few months
- It is very difficult to see a 50% improvement in mitochondrial function in a few months
  - It’s important to set realistic expectations
- We should think of this level of training the same way as accumulating wealth
  - It’s day in and day out
  - Small compounded gains over years, and years, and years
  - This is why a 40-year-old overweight smoker can become a world champion cyclist at 80 because he probably never once again got out of shape in that 40 years
- Iñigo notes it’s incredibly inspiring to see people in their 60’s, just retired, do their first test then come back 1 year later
  - They feel as strong as they did in their 30’s
  - They’re not taking medication, they’re in a good state of mid
  - They’re eating in moderation, a little bit of everything
- We thought for years that everything is downhill after 40, but you can really change

> “*You can really take ownership of that and improve it at any age*”— Iñigo San-Millán

## The effects of metformin, NAD, and supplements on mitochondrial function [2:05:15]

**Effect of metformin on mitochondrial function and blood lactate levels**

- Peter asks if Iñigo has any insights into whether [metformin](https://en.wikipedia.org/wiki/Metformin) impairs mitochondrial function
  - Studies are ongoing to see if the impairment of mitochondrial function or elevated lactate levels seen in patients taking metformin is an artifact of the drug or is a real effect
- Iñigo agrees that more research on this topic is needed
- Metformin seems to work for pre-diabetic patients and those with first-stage diabetes
- We know that metformin inhibits [complex I](https://en.wikipedia.org/wiki/Electron_transport_chain#Complex_I), which is key for mitochondrial function
  - It’s part of the electron transport chain
- He will see someone showing up with a lactate of 3.5 mmol at rest and the first thing he asks is if they are taking metformin; many times the answer is yes
  - He thinks elevated lactate levels are an artifact of taking metformin
- Peter notes that patients taking metformin, their fat oxidation is suppressed because when they undergo metabolic testing, it show a very, very low level of fat oxidation
  - So their blood lactate levels don’t really speak to what is happening in the mitochondria
- Iñigo notes that people aren’t taking metformin as a medication for longevity (or for general health); they’re already clinical patients
  - These people already have mitochondrial impairment or dysfunction
  - So it’s difficult to discern the effect of metformin on their mitochondria
- This question could be answered with muscle biopsies to assess mitochondrial function

**Do any supplements increase mitochondrial function?**

- Peter asks what other supplements might improve mitochondrial function
  - Precursors to [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide#Biosynthesis) are common ([NR](https://en.wikipedia.org/wiki/Nicotinamide_riboside) or [NMN](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide))
    - Are these clinically relevant?
  - If you boost NAD in the plasma, is it boosted in the cell?  Is it beneficial to the mitochondria?
- Iñigo doesn’t think we have the answer and we need to be cautious about how we interpret the data

> “*If you look at so many metabolites at the cellular level and mitochondrial level, they’re downregulated with aging*”— Iñigo San-Millán

- The question is why are these metabolites downregulated?
- Is the mitochondria per se downregulated with age?
  - Therefore it doesn’t need as much NAD and other metabolites?
- NAD is very important in [glycolysis](https://en.wikipedia.org/wiki/Glycolysis); it is needed to maintain redox status
  - NAD is utilized to convert glycerol-3-phosphate → 2,3-phosphoglycerate
  - When NAD is depleted the only thing that rescues it is lactate
- Is taking NAD going to increase longevity? Iñigo doesn’t think so

> “*Because longevity is not just one supplement or two or three or four or five. It’s a compendium on incredible amount of things that happen at the cellular level*.”— Iñigo San-Millán

- He doesn’t think 1 supplement will do this
- Remember when everybody thought [resveratrol](https://en.wikipedia.org/wiki/Resveratrol) was the thing for longevity?
  - Studies in mice showed in increased longevity by 50%
  - A lot of people started to take in resveratrol when they were 50, and they’re dead now
  - It doesn’t increase longevity in humans

**Could supplements favor the metabolism of cancer cells?**

- Peter asks if there is a scenario where too much NAD could be harmful
  - In cancer patients, if you doubled their NAD levels, wouldn’t this favor the tumor’s metabolism?
- Iñigo has done this pilot study in mice; he has done a lot of research on cancer metabolism
- We know glycolysis is key in cancer cells and NAD is absolutely indispensable for that
- Iñigo had done a pilot study in a few mice (it’s not published yet) where mice were given triple-negative breast cancer tumors; they tested 2 groups (4 mice each)
  - These tumors grow very, very fast
  - 1) One group got plain water
  - 2) The other group got nicotinamide riboside (NR, a NAD precursor)
    - You cannot take NAD, you can only take a precursor
  - They observed tumor growth for 23 days
  - They saw a 15% increase in tumor growth in the NAD group
  - They have statistical significance even with only 4 mice in each group; the results were consistent
    - He would love to follow this up using more mice

### The role of lactate and exercise in cancer [2:13:30]

- It just occurred to Peter earlier when they discussed the mitochondrial slide that lactate released from cells could feed a tumor
- Iñigo’s work on cancer metabolism is looking at this
- Lactate regulates genetic expression of the most important genes in breast cancer
  - He has now found this is true in lung cancer too
- Lacate is a mandatory byproduct of glycolysis
- In 1923 [Warburg](https://en.wikipedia.org/wiki/Warburg_hypothesis) characterized a high rate of glycolysis in cancer cells
  - What struct Warburg was not the amount of glucose used but the production of lactate
- Iñigo’s work is showing that lactate is an [oncometabolite](https://en.wikipedia.org/wiki/Oncometabolism#Oncometabolites)
- When there is a high glycolytic rate in cells, they will produce a lot of lactate

> “*You cannot clear that lactate, it’s going to drive cell growth and proliferation as we’re seeing*”— Iñigo San-Millán

- He is doing studies to block lactate production through genetic engineering  as well as [DCA (dichloroacetic acid)](https://en.wikipedia.org/wiki/Dichloroacetic_acid#Therapeutic_uses)
  - When lactate production is stopped, they see proliferation stop within hours
- Peter notes, “*exercise would increase your capacity for clearing lactate in the long term, but in the short term raises lactate. So it begs the question, in a cancer patient specifically, what’s the net impact of exercise?*”
- This is something Iñigo and [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) are working on
  - Brooks has shown that the acute response to lactate is to increase the expression of 600+ genes
  - All these genes are involved in cellular homeostasis and in the benefits of exercise
- Lactate is a stimulating molecule
- We know about the effects of acute exposure to lactate from exercise; cancer is different
  - In cancer the lactate keeps accumulating; exposure is chronic
  - Lactate is responsible for the acidic microenvironment of the tumor
  - The more acidic the tumor the more metastatic it is, the more aggressive, the more glycolytic
    - The question is— why is that lactate accumulating?
    - Can exercise counteract this?

**Benefits of exercise**

- Exercise might be beneficial for many patients
- How does exercise affect [exosomes](https://en.wikipedia.org/wiki/Exosome_(vesicle)) released by cancer cells?
  - Exosomes are microvesicles in the body that may be responsible for metastasis
- Another publication he’s working on is looking at the protein content and microarray nodes of exosomes released by breast cancer cells and lung cancer cells
  - This is providing incredible information to understand cancer metastasis
- On the other side, muscles also release exosomes
  - One of the benefits of exercise is the crosstalk between skeletal muscle and many organs
  - Could this be mediated through exosomes released by muscles?
  - Could exosomes released by muscle cells keep cancer at bay?
    - He doesn’t know yet

> “*We’re suspecting that we’re scratching the surface of something that potentially could be very interesting thing, to understand better the effects of exercise*”— Iñigo San-Millán

- Peter notes, “*the deeper I go in the rabbit hole, into all things that relate to longevity, the more convinced I am that if you’re going to rank order things, if you were forced to rank order things, there’s nothing that ranks above exercise, as the single most potent tool or agent we have to impact longevity. And yet paradoxically, in the acute setting, exercise seems to do everything incorrectly*.”
- The chronic impact of exercise is undeniable geroprotective

## How assessing metabolic parameters in long COVID patients provides insights into this disease [2:19:00]

- Iñigo just published a study of metabolic parameters of patients with long COVID
  - Published in the *American Journal of Respiratory and Critical Care Medicine* in 2022, [Decreased Fatty Acid Oxidation and Altered Lactate Production during Exercise in Patients with Post-acute COVID-19 Syndrome](https://www.atsjournals.org/doi/full/10.1164/rccm.202108-1903LE)
- He observed that mitochondria in long COVID patients (even in those who were previously healthy) look like those from people with type 2 diabetes
  - In terms of fat oxidation and lactate production
- This study took place in the National Jewish Hospital; it competes with the Mayo Clinic as the #1 pulmonology hospital in the US
- People with long COVID struggle to breathe during simple tasks such as walking up stairs
- A test of their pulmonary function looks normal
- COVID affects cardiac muscles so their cardio function was measured; this too is normal
- Next they undergo [CPET testing](https://en.wikipedia.org/wiki/Cardiac_stress_test), this is physiological, metabolic testing
  - They measure lactate as well
- This study looked at 50 individuals; 25 of them previously had underlying conditions but the other 25 were normal people
  - Most of these normal people were moderately active
    - Some were doing marathons or triathlons
  - The average age was 50
- Iñigo got the raw data from their metabolic tests and looked at fat oxidation and lactate production as a surrogate for metabolic function, metabolic flexibility, and mitochondrial function
  - He was shocked, because they were significantly worse than people with type 2 diabetes and metabolic syndrome
  - This could explain why these people cannot go up the stairs where as before they were doing marathons

**Potential mechanisms of decline in metabolic health and mitochondrial function**

- We know that viruses can hijack the mitochondria for their own benefit, for reproduction— could COVID do the same thing?
- There are people with long COVID that improve in weeks or months; they go back to normal
- But, there are a handful of people who after a year, have not improved one bit
- Can exercise be used in a therapeutic way to stimulate mitochondrial function
- Peter notes that [myocarditis](https://en.wikipedia.org/wiki/Myocarditis) occurs in some COVID infections; the rate is 2.3 cases of myocarditis per 100,000 people infected with COVID
  - Most cases of myocarditis are transient, they recover; but some are not
  - Myocarditis is inflammation of the cardiac muscle that results in depressed [ejection fraction](https://en.wikipedia.org/wiki/Ejection_fraction)
  - He clarifies that what Iñigo is studying in these long COVID patients is distinct from myocarditis
    - What Iñigo is describing is a global insult to the mitochondria in skeletal muscle
- Iñigo agrees; the data (though indirect, lactate measurements) point toward mitochondrial dysfunction
- The next step is to obtain biopsies for analysis
- It could also be a microperfusion problem with the capillaries
  - Microthrombosis may prevent perfusion and result in increased lactate levels
- But we know that other viruses can hijack the mitochondria and disrupt it
- Mitochondria can interfere with viral fission and fusion processes
- Most of the time, this disruption of mitochondrial function by viruses subsides
  - And mitochondrial function is restored shortly after the symptoms are gone
  - Why is this virus different?
- Most of these patients had a mild course of COVID; they were not hospitalized; they were not in the ICU
  - This work was done primarily on patients infected with the original variant and Delta (from June 2020 – April 2021)
  - There were 35 females and 15 males; so more females
- Long COVID may be a rare event, but when millions of people are infected, if it occurs 1 in 1 million— there will be a lot of people who need help

## The advantages of using cellular surrogates of metabolism instead of VO2 max for prescribing exercise [2:25:45]

**Limitations of using VO****2** **max as a metric**

- How predictable is the relationship between Zone 2 as defined by maximum fat oxidation compared to VO2 max?
- So if you run somebody through a [CPET (cardiopulmonary exercise test)](https://en.wikipedia.org/wiki/Cardiac_stress_test) and figure out that their VO2 max is 4 L— how predictably can you say at X percent of that, you will be at maximum fat oxidation?
- Iñigo has a manuscript in preparation with 225 subjects where they look at the relationship between fat oxidation and VO2
- Historically, research studies with exercise have been based on VO2 max
  - For example, patients were exercising for 6 months at 60% of their VO2 max
  - Peter asks if this means 60% of the heart rate that produced VO2 max or 60% of the power that is their max power at VO2 max
  - Iñigo agrees that studies are not consistent with this metric
- Iñigo looked at the cardiorespiratory adaptations and cellular adaptations to exercise
  - He wanted to know how well they correspond
  - Athletes can improve tremendously at the cellular level but not at all at the cardiorespiratory level (at least based on VO2 max)
  - Consider this example— an athlete who used to be an average professional with a VO2 max of 72.3 becomes a very good professional in 2 years
    - His VO2 max remained the same but his lactate levels were incredibly better
    - At a workload of  5 watts/kg his lactate was at 5 mmol 2 years ago but is now 1.7 mmol
    - The magic happened at the cellular level for this athlete
- The VO2 max of an elite athlete does not come close to predicting performance
- VO2 max corresponds with fitness in the same way that watts corresponds with fitness
  - This implies that instead of using VO2 max to look at longevity and fitness, a power test (or a speed test on a treadmill) can be used; they will show the same thing
  - Individuals who are not active and have poor fitness, have a lower VO2 max and a lower power output
    - They have lower speed and lower lactate capacity
- VO2 max had been used as a great surrogate for fitness forever; Iñigo wants to see if it’s really that specific

**Exercise at a specific % VO****2** **max does not tell you anything about a person’s metabolic state**

- In this study, people with the same VO2 max might be in different metabolic states
  - Some are oxidizing a lot more fat or carbohydrates
  - This means VO2 max does not correspond to the same metabolic status
  - Peter thought that most people would be metabolizing mostly carbohydrates by the time they are at their VO2 max
- Iñigo notes that a sedentary individual at 75% of their VO2 max, might be around 3 mmol
  - Whereas a world class athlete at 75% VO2 max, is about 1.5 mmol
  - So metabolically, they’re different but they are at the same VO2 max

> “*So, if we prescribe exercise based on VO**2* *max, we might not do things correctly*”— Iñigo San-Millán

- If you look at carbohydrate oxidation in these same individuals, working at 75% VO2 max
  - A sedentary individual oxidizes about 2 g/min
  - An elite athlete oxidizes about 3 g/min
  - This is also different when they work at 50% VO2 max
- Longitudinally carbohydrate oxidation and VO2 correspond very well
  - The same is true for fat oxidation
- But if you look at the lactate levels of individuals in the same group, lactate and VO2 max don’t correlate
  - The correlation [(R2)](https://en.wikipedia.org/wiki/Coefficient_of_determination) values are sometimes 0.2 or 0.1 or 0.3
- Over the last few decades, Iñigo has learned about improving metabolism at the cellular level
- If you want to be precise about prescribing exercise, use cellular surrogates such as lactate levels and fat oxidation is better than VO2 max
  - Using [METs (metabolic equivalents of task)](https://en.wikipedia.org/wiki/Metabolic_equivalent_of_task) is prehistoric
- Peter notes that declining mitochondrial function is a hallmark of aging
  - He explains to patients that Zone 2 exercise is a way to measure mitochondrial function
  - Zone 2 exercise is both the treatment and the test
  - Now we know there is even more to look at on the cellular level

## Metabolomics reveals how cellular metabolism is altered in sedentary individuals [2:33:45]

**What do biopsies tell us about mitochondrial function in sedentary individuals?**

- There is a lot of research that shows the difference at the cellular level between people with type 2 diabetes (or metabolic syndrome) and active individuals, or even sedentary individuals
- Iñigo compared sedentary individuals with moderately active individuals; they looked at the mitochondria
  - In sedentary individuals there is a decreased capacity of the mitochondria to oxidize fuels (pyruvate, fatty acids, and amino acids)
  - There is also a significant decreases in the complexes that make up the electron transport chain
  - There is decreased capacity of the transporters that move different metabolites into the mitochondria
  - The transporter for pyruvate into the mitochondria is also dysregulated in sedentary individuals (as compared to active individuals)
    - Similarly, oxidation of pyruvate in the mitochondria is dysregulated
- What are the implications of these findings?
  - These people don’t have diabetes or prediabetes or clinical symptoms
  - But sedentary people are being used as the model to compare with unhealthy individuals
  - These sedentary individuals don’t have downregulation of [GLUT4 transporters](https://en.wikipedia.org/wiki/GLUT4) or abnormal [glucose tolerance tests](https://en.wikipedia.org/wiki/Glucose_tolerance_test)

> “*I’ve been pushing for years that the model should not be the healthy, sedentary individual*”— Iñigo San-Millán

- As humans, we are meant to walk or exercise, so the sedentary individual needs an intervention
- Iñigo had a hard time getting an [IRB](https://en.wikipedia.org/wiki/Institutional_review_board) to use active people as the gold standard in his studies

**What happens to glucose once it is inside the cell in sedentary individuals?**

- Iñigo unpublished studies show a disruption in the [mitochondrial pyruvate carrier (MPC)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7464753/) disrupts entry of pyruvate into the mitochondria
- Most diabetes research has focused on the peripheral level
  - Looking at glucose levels, GLUT4 on the surface of the cell, insulin resistance, how much insulin the pancreas is releasing, etc.
- Iñigo is studying the fate of glucose once it enters the cell
  - Does it enter the mitochondria?
  - Is it reduced to lactate?
  - This can be used as a metric for dysregulation of glucose metabolism before patients have clinical symptoms
  - Dysregulation of glucose metabolism in sedentary individuals may occur 10-15 years ahead of clinical symptoms (such as insulin resistance)
- Iñigo is studying the same thing with transport of fatty acids into the mitochondria
  - He’s measuring the levels of fat transporters ([CPT1](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_I) and [CPT2](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_II)) in the mitochondria in sedentary individuals
    - These are also significantly downregulated
    - So in sedentary individuals, fatty acids will not be transported well into the mitochondria (where they can be oxidized)
  - If he injects fatty acids into the mitochondria, he finds they are not oxidized well either
- At a cellular level, there are significant differences in the metabolism of fuels (glucose and fatty acids) in sedentary people compared to moderately active people

## Cellular changes in the metabolism of people with diabetes and metabolic syndrome [2:39:15]

**Metabolism of intramuscular fat**

- People with diabetes/ metabolic syndrome have intramuscular triglycerides
  - These are fat droplets
  - This fat is not metabolically active, yet it continues to grow in size
- Elite athletes also have intramuscular triglycerides but they are very active
  - 25-30% of the fat oxidation comes from that fat droplet
  - This is probably a evolutionary mechanism to not rely on adipose tissue
  - Perhaps it is a quicker source of fatty acids for fuel
  - These fat droplets are constantly being turned over, oxidized and replenished
- Iñigo’s colleague at the University of Colorado, [Brian Bergman](https://medschool.cuanschutz.edu/endocrinology/research/metabolism-obesity-and-diabetes/bryan-bergman-phd), is working to characterize the content of these fat droplets
  - One thing they know is these fat droplets are very high in [ceramides](https://en.wikipedia.org/wiki/Ceramide) and [diglycerides](https://en.wikipedia.org/wiki/Diglyceride)
  - Ceramides are key in the athelosclerotic process;they are a hallmark of cardiovascular disease
    - Historically it has been shown that ceramides are released from the liver
    - Now he is seeing that ceramides are in intramuscular triglycerides

> “*Could this be a connection between cardiovascular disease and type 2 diabetes?*”— Iñigo San-Millán

- These intramuscular fat droplets in people with type 2 diabetes keep growing and they release proinflammatory molecules
- Iñigo is working to establish the connections between type 2 diabetes and cardiovascular disease at the mitochondrial level
- We know that about 80% of people with type 2 diabetes also have cardiovascular disease (and vice versa), which is why it is called cardiometabolic disease

> “*Could the nexus of all that be a mitochondrial impairment?*”— Iñigo San-Millán

- Peter comments, he’s going to need to do a 3rd podcast in a couple years when all of this data is published
  - There’s going to be a lot more questions to be answered

§

## Selected Links / Related Material

**Previous podcast with Iñigo**: [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 23, 2019) | [0:45, 29:00, 51:45]

**Previous podcast with Lance Armstrong**: [#178 – Lance Armstrong: The rise, fall, and growth of a cycling legend](https://peterattiamd.com/lancearmstrong/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 4, 2021) | [11:00]

**Iñigo’s indirect method to assess metabolic flexibility and oxidative capacity**: [Assessment of Metabolic Flexibility by Means of Measuring Blood Lactate, Fat, and Carbohydrate Oxidation Responses to Exercise in Professional Endurance Athletes and Less-Fit Individuals](https://pubmed.ncbi.nlm.nih.gov/28623613/) | *Sports Medicine* (I San-Millan and GA Brooks 2018) | [37:00, 40:00]

**Equations for calculating fat and carbohydrate oxidation**: [Calculation of substrate oxidation rates in vivo from gaseous exchange](https://pubmed.ncbi.nlm.nih.gov/6618956/) | *Journal of Applied Physiology: respiratory, environmental and exercise physiology* (KN Frayn 1983) | [39:15]

**ICU patients lack muscle glycogen**: [Winning the war against ICU-acquired weakness: new innovations in nutrition and exercise physiology](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4699141/) | *Critical Care* (PE Wischmeyer and I San-Millan 2015) | [1:15:45]

**Iñigo’s long COVID study**: [Decreased Fatty Acid Oxidation and Altered Lactate Production during Exercise in Patients with Post-acute COVID-19 Syndrome](https://www.atsjournals.org/doi/full/10.1164/rccm.202108-1903LE) | *American Journal of Respiratory and Critical Care Medicine* (E de Boer *et al.* 2022) | [2:19:15]

**Summary of Iñigo’s research at the University of Colorado**: [Inigo San Millán: Bringing Elite Tests to the Masses](https://medschool.cuanschutz.edu/deans-office/cu-med-today/profilesarchives/inigo-san-millan) | by Lisa Marshall *CU Medicine Today* (May 2013)

**Iñigo’s website**: [Welcome to Dr. San-Millan’s Website](https://www.inigosanmillan.com/) (2018)

§

## People Mentioned

- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) (Slovenian cyclist who currently rides for UCI WorldTeam UAE Team Emirates, 2 time Tour de France winner) [1:00, 4:30, 20:15, 24:30, 34:30, 1:01:15, 1:45:30, 1:52:30]
- [Angelo D’Alessandro](https://medschool.cuanschutz.edu/biochemistry/people/primary-faculty/dalessandro-angelo) (Iñigo’s collaborator, Assistant Professor of Biochemistry and Molecular Genetics at theUniversity of Colorado Denver – Anschutz Medical Campus) [8:30]
- [Travis Nemkov](https://profiles.ucdenver.edu/display/15074368) (Iñigo’s collaborator, Assistant Professor of Biochemistry and Molecular Genetics at the University of Colorado Denver – Anschutz Medical Campus) [8:30]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (former professional cyclist, won the Tour de France 7 consecutive times) [11:00]
- [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) (Professor at UC Berkeley who specializes in exercise physiology and metabolism) [30:30, 50:45, 2:15:30]
- [Francis Benedict](https://en.wikipedia.org/wiki/Francis_Gano_Benedict) (20th century physiologist) [34:45]
- [Paul Wischmeyer](https://scholars.duke.edu/person/paul.wischmeyer) (Professor of Anesthesiology at Duke University) [1:20:15]
- [Otto Warburg](https://en.wikipedia.org/wiki/Warburg_hypothesis) (20th century biochemist/ physiologist, described the Warburg effect in cancer calls) [2:14:30]
- [Brian Bergman](https://medschool.cuanschutz.edu/endocrinology/research/metabolism-obesity-and-diabetes/bryan-bergman-phd) (Professor in the Division of Endocrinology, Diabetes, and Metabolism at the University of Colorado Anschutz Medical Campus)  [2:40:00]

§

![](https://peterattiamd.com/wp-content/uploads/2022/03/bio-pic-inigo2.jpeg)

##### Iñigo San-Millán, Ph.D.

Iñigo San-Millán earned his doctorate at the University of the Basque Country School of Medicine.  He did his postdoctoral research at the Harvard Medical School Cancer Research Program.  Currently he is an Assistant professor in the School of Medicine at the [University of Colorado School – Colorado Springs](https://som.ucdenver.edu/Profiles/Faculty/Profile/19887).  His research and clinical work focuses on: exercise metabolism, cancer metabolism, metabolic health, nutrition, sports performance, diabetes, and critical care.

Dr. San-Millán has worked for the past 25 years with many professional teams and elite athletes worldwide across multiple sports, this includes: soccer, cycling, football, basketball, track and field, rowing, triathlon, swimming, and Olympic training. He has been a consultant in exercise physiology and sports medicine to international organizations such as the US Olympic Committee.  He has pioneered the development of new methodologies for monitoring athletes at the metabolic and physiological level.  He developed the first method to indirectly measure mitochondrial function and metabolic flexibility/  He co-developed the first methodology to deploy metabolomics assessment to professional sports as well as the first method to indirectly measure skeletal muscle glycogen in a non-invasive manner using high frequency ultrasound.  Currently, he is the [Director of Performance for Team UAE Emirates cycling team](https://www.uaeteamemirates.com/rider/inigo-san-millan/) and the personal physiologist and coach of 2020 and 2021 Tour de France winner Tadej Pogacar.

Although now a recreational athlete, he used to be a competitive athlete.  He played soccer for 6 years for the developmental academy of Real Madrid soccer team.  He also raced as a low-key, professional cyclist for 2 years.  [[Dr. San-Millan’s Website](https://www.inigosanmillan.com/about-me)]

Twitter: [@doctorIñigo](https://twitter.com/doctorinigo?lang=en)