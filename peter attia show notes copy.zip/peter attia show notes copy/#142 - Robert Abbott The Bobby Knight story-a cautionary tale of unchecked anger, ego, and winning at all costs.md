# #142 – Robert Abbott: The Bobby Knight story—a cautionary tale of unchecked anger, ego, and winning at all costs

**Source:** [https://peterattiamd.com/robertabbott/](https://peterattiamd.com/robertabbott/)

---

Robert Abbott is a six-time Emmy award winner and the director of “The Last Days of Knight,” the behind-the-scenes documentary of legendary coach Bobby Knight, and the events that led to his termination from Indiana University. In this episode, Robert takes us through his investigative journey, which revealed cautionary tales of a winning at all costs environment—how pain often gets left in the wake of unchecked anger, ego, and perfectionism. Robert reflects on Knight’s legacy and extracts lessons in self-awareness and accountability that can be applied to ensure history doesn’t repeat itself.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/robertabbott/the_Drive_public.png)

Play

#142 - Robert Abbott: The Bobby Knight story—a cautionary tale of unchecked anger, ego, and winning at all costs

#142 - Robert Abbott: The Bobby Knight story—a cautionary tale of unchecked anger, ego, and winning at all costs

1x15s30s

0:002:14:25

## We discuss:

- Robert’s career covering sports and interesting athletes (2:30);
- Robert’s early impression of Bobby Knight’s controversial persona (10:15);
- The journalistic work that uniquely prepared Robert for his Bobby Knight story (13:30);
- The cost of excellence in sports—cautionary tales of ‘greatness at any cost’ (19:15);
- Knight’s coaching style, waning success in the 90s, and what put him on Robert’s radar (25:30);
- Three alarming accounts from a former player (Neil Reed) that launched Robert’s investigation into Bobby Knight (35:15);
- The “win-first” environment at Indiana that provided cover for Knight’s toxic behavior (44:45);
- Knight’s ego swells—a shift from team-first to “I” and “me” (53:00);
- How patience, honesty, and gaining trust with his sources paid off in his reporting on Bobby Knight (1:01:30);
- The vicious cycle and anger and shame, and why Bobby Knight is so interesting to Peter (1:08:00);
- Releasing the choking tape—Breaking open the Knight story, vindicating his earlier reporting, and the most powerful moment Robert has ever witnessed in his journalistic career (1:20:00);
- The bittersweet story of Neil Reed—triumph, PTSD, and breaking the cycle of pain (1:43:15);
- Examining Bobby Knight’s legacy, and how society can avoid a repeat of similar devastating situations (1:57:30);
- Final thoughts on Bobby Knight and the pain left in his wake (2:08:00); and
- More.

§

## Show Notes

## Robert’s career covering sports and interesting athletes [2:30]

Robert’s documentary on Bobby Knight: [The Last Days of Knight](https://www.espn.com/30for30/film/_/page/lastdaysofknight)

\*\*\*

**Early career**

*What drew Robert to journalism?*

- Always a fan of sports
- Previously was a competitive golfer at Florida State University (played in Future Masters, Junior Orange Bowl, Tournament of Champions, etc.)
- Post golf career, got into media performance with the idea of being an on-air sportscaster
- Took a journalism class and was surprised how much it interested him
- His first job was at the local TV station as a cameraman, editor, and on-air reporter
- Eventually got hired at CNN as an associate producer but gravitated into becoming a storyteller
- He started doing profiles of athletes—traveling around the country and spending time with people

“I love the psychology of sports, what makes someone great, what they have to sacrifice to give it up. And that’s kind of what shaped my early career at CNN.” —Robert Abbott

***Ever a letdown when meeting an athlete you admired?***

- Countless times, says Robert
- He grew up watching the Olympics, ([Olga Korbut](https://en.wikipedia.org/wiki/Olga_Korbut), [Nadia Comaneci](https://en.wikipedia.org/wiki/Nadia_Com%C4%83neci))
- He was very fascinated by their human stories, but to become great, many of the olympians had to be one dimensional (i.e., not that interesting)
- Robert is drawn to people who have a story to tell
- Examples:
  - A swimmer, [Gary Hall Jr.](https://en.wikipedia.org/wiki/Gary_Hall_Jr.) whom Robert did a piece about
  - The [Jamaican bobsled team](https://en.wikipedia.org/wiki/Jamaica_national_bobsleigh_team) for the 1992 winter Olympics
  - Did a story on [Prince Albert](https://en.wikipedia.org/wiki/Albert_II,_Prince_of_Monaco) with the Monaco bobsled team
  - Latvian bobsled team after communism had just ended

## Robert’s early impression of Bobby Knight’s controversial persona [10:15]

By 1991, Bobby Knight had won three national championships at Indiana ([1976](https://en.wikipedia.org/wiki/1975%E2%80%9376_Indiana_Hoosiers_men%27s_basketball_team), [1981](https://en.wikipedia.org/wiki/1980%E2%80%9381_Indiana_Hoosiers_men%27s_basketball_team), [1987](https://en.wikipedia.org/wiki/1986%E2%80%9387_Indiana_Hoosiers_men%27s_basketball_team)), and he had historic seasons in [1975](https://en.wikipedia.org/wiki/1974%E2%80%9375_Indiana_Hoosiers_men%27s_basketball_team) (one loss) and [1976](https://en.wikipedia.org/wiki/1975%E2%80%9376_Indiana_Hoosiers_men%27s_basketball_team) when they went undefeated, plus he coached the [1984 Olympic men’s team](https://en.wikipedia.org/wiki/1984_United_States_men%27s_Olympic_basketball_team) to a gold medal

**Robert’s attitude and opinion towards Bobby Knight in 1991:**

- Robert vividly remembers reading [John Feinstein](https://en.wikipedia.org/wiki/John_Feinstein)‘s book from 1987, [A Season on the Brink](https://www.amazon.com/Season-Brink-Hoosiers-Feinstein-Paperback/dp/B011MBPQS6), which painted a picture where Knight would relentlessly ride by his players
- One story about a player Daryl Thomas where Knight called him a ‘pussy’ and put a box of tampons in his locker
- Feinstein ends the book with a line that says, “*Do the ends justify the means?*”
- The answer seemed to be “yes” in Robert’s mind considering the success Knight had at the time

> “*I had no idea that 13 years later, my boss would give me an assignment that ultimately I would be asking that same question and presenting it to the country*.”

## The journalistic work that uniquely prepared Robert for his Bobby Knight story [13:30]

**Robert’s work from about 1987 into the 1990s…**

- Robert covered all the big sports events
- He got used to turning stories about very quickly (e.g., within 30 minutes)

> “As a journalist, I learned to make decisions quickly, not always the right one, but you get a ton of at-bats and you learn.”

- He spent time with Nick Charles (lead anchor on CNN sports at the time) and they often discussed Bob Knight as an “onion-like” character with many layers to peel back — a person they would love to spend time with seeing what made him tick
- Eventually, CNN gave Robert the green light to do special projects

⇒ Full list of films [here](https://en.wikipedia.org/wiki/Robert_Abbott_(director)#Filmography)

**Robert says the two projects that prepared him most for his Bobby Knight project were**: [Battle of the Sexes (1994)](https://en.wikipedia.org/wiki/Robert_Abbott_(director)#Battle_of_the_Sexes_(1994)) and [Field of Screams](https://en.wikipedia.org/wiki/Robert_Abbott_(director)#Field_of_Screams_(1994))

- Battle of the Sexes was very successful for CNN creating the impetus for more
- Field of Screams was inspired by the book [Among the Thugs](https://www.amazon.com/Among-Thugs-Bill-Buford/dp/0679745351) — a journalist who immersed himself amongst the soccer hooligans in England and went into the psychology of how those riots start
- Field of Screams became much more about stalking and death threats of athletes
  - The film highlighted [Mitch Williams](https://en.wikipedia.org/wiki/Mitch_Williams)’ story who began receiving death threats after he [gave up a walk-off home run in game 6 of the World Series to lose to the Toronto Blue Jays](https://www.youtube.com/watch?v=-F5HwiGm7lg) — his wife said, “I remember vividly him walking around with a gun in his hand because the wind’s blowing outside.”
  - The film also highlighted the stalking of [Katarina Witt](https://en.wikipedia.org/wiki/Katarina_Witt) and the [stabbing](https://news.bbc.co.uk/onthisday/hi/dates/stories/april/30/newsid_2499000/2499161.stm) of [Monica Seles](https://en.wikipedia.org/wiki/Monica_Seles)
- In producing this film, Robert spent time with fascinating people like:
  - [Dr. Park Dietz](https://en.wikipedia.org/wiki/Park_Dietz), a psychiatrist who runs a threat assessment group in San Diego who has testified in many of the highest profile US criminal cases (e.g., [Jeffrey Dahmer case](https://en.wikipedia.org/wiki/Jeffrey_Dahmer))
  - And [Dr. Gavin de Becker](https://en.wikipedia.org/wiki/Gavin_de_Becker), the guy every star went to if they got death threats or threatening mail

**How’ve those films prepared Robert:**

- “I spent nine months on this documentary. It wasn’t two days, three days, three weeks, three months, it was a long time.”
- “These documentaries prepared me in how to tell a story at an hour level. How to tell a story at a two hour level, all the different places you could take kind of a narrative yarn.”
- “Those two films (Battle of the Sexes and Field of Screams) prepared me the most for the assignment I was going to get in 1999 (on Bobby Knight)”

## The cost of excellence in sports—cautionary tales of ‘greatness at any cost’ [19:15]

Peter and Robert discuss the “cost of excellence” in sports — meaning individuals who were given too long a leash by society based on their level of professional success often leading to their downfall

Example: [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson)

- Mike Tyson of the late ’80s and early ’90s, I mean an incredible talent who was completely out of control
- He had a traumatic childhood — and that rough upbringing in some cases can produce a knife that is very sharp on two sides
- On the one hand, it made him an unbelievably rage filled fighter — he built up an armor to make sure he could never be hurt again
- But none of the underlying problems got fixed so he basically was going to be a nonstop hurting machine, inside and outside the ring

Example: [Tiger Woods](https://en.wikipedia.org/wiki/Tiger_Woods)

- He was such a prodigy that he may not have had enough people around him that could say, “Hey, let’s revisit how you’re going to sort of live your life.”
- And things probably just got out of control.
- But again, when you’re so dominant and you’re winning and the money is there and the titles are there, I think it’s easy to overlook these things.

**More about Mike Tyson**

*If he was surrounded by better people, would his better character traits have come to the surface?*

- It’s clear that he does have a more sensitive side — he’s not a horrible monster, but there was years where he acted that way
- But he was such a cash cow for everyone around him that there’s no incentive to help Tyson with his underlying issues as long as he keep producing big pay days
- Sadly, that’s what happened to Tyson with [Don King](https://en.wikipedia.org/wiki/Mike_Tyson_vs._Michael_Spinks), [Bill Cayton](https://en.wikipedia.org/wiki/Bill_Cayton), and Rory Holloway
- He did have some people around him that may have kept him on a better path — guys like [Steve Lott](https://en.wikipedia.org/wiki/Steve_Lott) and [Teddy Atlas](https://en.wikipedia.org/wiki/Jimmy_Jacobs_(handballer)) — but those guys got pushed out by the crew around Tyson
- Tyson did have a fond affection for a guy named Jimmy Jacobs, but he died in early ’88, and Peter feels like that was the beginning of the end of Tyson’s career

## Knight’s coaching style, waning success in the 90s, and what put him on Robert’s radar [25:30]

**What’s happening to Knight in the ’90s and then how Robert got brought into his story on Knight**

- Knight won his last national championship in the late ’80s
- In the ’90s, he still had good teams, but he started getting bounced in the first or second round of the tournament
- You kind of just kept waiting for him to get that player or get that sign or class that would put him back on the top
- **Then in 1999**, [Luke Recker](https://en.wikipedia.org/wiki/Luke_Recker) announces he’s leaving Indiana — a big story since he was the star of the team.
- That’s when Robert’s boss, Steve Robinson, put Robert on the task of figuring out why Recker left
- Initially, Robert thought that this was going to be a non-story, a waste of time
- Steve and Robert both thought going into this that it was just going to be a story of entitled AAU basketball kids with inflated egos that can’t handle playing for a guy like coach Knight

**Some background on Bobby Knight’s coaching philosophy**

- Knight was a role player at Ohio State on their national championship team
- Then he went to Army to coach, and when he got to Indiana he applied that brand of basketball at — The sense of “I’m going to break you down to nothing and then build you back up into the person I want you to be”
- He was all about unselfish basketball, playing defense, sharing the basketball
- Most of his teams lacked a true “superstar”

*Players beginning to leave…*

- Two years before Recker left, [Neil Reed](https://en.wikipedia.org/wiki/Neil_Reed) had left in 1997 and then [Jason Collier](https://en.wikipedia.org/wiki/Jason_Collier) had left in 1998 for Georgia Tech
- So Steve Robinson had a feeling something was going on
- Even still, the thought going in was that Knight was notoriously hard on his players so it was most likely that these kids just didn’t want to do it

**The simple question that turned into an investigation:**

- Interestingly, Recker faxed in his notice to coach Knight at midnight saying he was not returning — “that’s a weird way to say I’m leaving. That interested me a little bit.”
- The assignment was: *Why are really good players leaving Indiana and Bob Knight’s program?*
- It started with a simple question, but it **became** an investigation after just the first few calls
- The first conversation was with Neil Reed’s dad, “*He didn’t hold anything back. Terry told me everything*.”

> “What I’ve learned since then, is all great investigative assignments start with a really simple question.”

## Three alarming accounts from a former player (Neil Reed) that launched Robert’s investigation into Bobby Knight [35:15]

**Conversation with Neil Reed**

- Reed told Robert how much he loved Indiana and how excited he was to go there
- He wanted to play for coach Knight
- Neil was a tough-minded kid, he wanted to play for coach Knight because he wanted to go play for somebody who was going to push him and make him better

> “You could just tell the love he had for Indiana basketball, and specifically coach Knight. And that’s why he went there.”

*Why Neil Reed left Indiana – Robert first hearing the choking story*

- [Larry Richardson](https://iuhoosiers.com/sports/mens-basketball/roster/larry-richardson/5122) was a big man and coach Knight had always taught Neil the point guard, “*Hey, talk to your team. Command their presence*.”
- Coach Knight laid into Neil, “*Why the hell didn’t you call out his name? Why didn’t you talk to him?*”
- He gave all this praise to Larry and then just laid into Neil in an unrelenting fashion
- Neil made the mistake when he turned to Larry and said, “*Larry, did I*?”. And Larry Richardson said, “*Yes, you did.*”
- That embarrassed coach Knight, and that’s when Neil alleged that **coach Knight came at him and grabbed him by the throat**

![](https://peterattiamd.com/wp-content/uploads/2020/12/choking-image-1024x578.jpeg)

**Figure 1. Screenshot of Knight grabbing Reed by the throat.** [[source](https://www.indystar.com/story/sports/college/indiana/2018/04/05/last-days-knight/474220002/)]

**Two other stories that stood out to Robert**

*1—Kicking the university president out of practice*

- One time, coach Knight kicked the president of the university, [Myles Brand](https://en.wikipedia.org/wiki/Myles_Brand), out of practice
- Brand brought some people in on a tour, and was talking out loud to the group, and coach Knight said something to the effect of, “Shut the fuck up. I don’t come into your office and talk while you’re trying to work. Get the hell out of here.”
- At that point I was like, “Holy shit. You’ve got the balls to throw the president out of practice. Who’s running this school?”

*2—Brandishing soiled toilet paper at halftime*

- One time after a particularly poor first half of basketball, coach Knight wiped himself and he showed the toilet paper to the players and said, “This is how you guys are playing. You’re playing like shit.”

> “All of a sudden it turned from a story in my mind about society, entitlement of AAU basketball players [unwilling] to be coached … to an investigation, ‘Did these three things happen? Can I confirm that these three incidents took place?’”

**Robert’s intuition about whether Neil Reed was telling the truth:**

*What does your intuition tell you?*

- “50-50”, says Robert, “because I’m like, ‘He’s probably disgruntled. Is he exaggerating? Did it really happen?’”
- But there was a lot of validity to what he said
- That said, Robert kept a skeptical attitude towards the allegations — “*Part of what I’ve learned is if you’re going to do a good investigation, you can’t get too excited. You just have to be even keel.*”

**What did Robert do next after his call with Neill?**

- Robert took a big step back and decided he need to understand Indiana basketball
- First person he interviewed is [Garry Donna](https://www.indystar.com/story/sports/high-school/2017/03/05/basketball-legend-garry-donna-dies-73/98784928/), the guy who started, “Hoosiers Basketball” magazine
- Donna described coach Knight as “Dr. Jekyll and Mr. Hyde.” — charming and brilliant at one time and then behind closed doors he can totally lose it
- You’d sort of see the tip of the iceberg, but you never saw the whole iceberg underneath
- he painted a picture and an environment playing for Knight

> “That first interview was foundational for me, that it gave me a sense of what it’s like, and why the administration is afraid of coach Knight.”

## The “win-first” environment at Indiana that provided cover for Knight’s toxic behavior [44:45]

**Bob Knight had already displayed very questionable behavior prior to the Robert’s investigation:**

- In 1985 Knight famously [threw the chair](https://www.youtube.com/watch?v=ukpekodCQ-U) across the court while someone was at the foul line

- In 1988, he made an absolutely [ridiculous statement](https://www.nytimes.com/1988/04/27/sports/knight-is-criticized-over-rape-remark.html) to [Connie Chung](https://en.wikipedia.org/wiki/Connie_Chung) on air using when talking about how he handled stress, “*I think that if rape is inevitable, relax and enjoy it*.”
- While reporting in 1999, Robert had uncovered the face that In 1987, the [Bloomington Faculty Council](https://bfc.indiana.edu/) was so offended by the John Feinstein book that they put together a bill of rights for athletes stating, “*No coach should verbally, or mentally abuse their athletes*.”
- In other words, people knew about Knight’s conduct back in 1987, knew he was out of control, but Knight goes on to [win the national championship](https://en.wikipedia.org/wiki/1986%E2%80%9387_Indiana_Hoosiers_men%27s_basketball_team) that year

> “Now they cannot put a saddle on. There’s no way. The horse is out of the barn, and it is so far down the road that there’s no coming back. He was a legend. He was the most powerful man in the state.”

- After the rape comment in the Connie Chung interview, the president of the university released a tempered statement about it
- In “retaliation” to the tempered statement from IU, coach Knight went out and interviewed to coach at New Mexico
- Coach Knight was basically like, “*Really? You’re going to put out a statement about me. I’ll go to New Mexico and let’s see what happens*.”
- All of a sudden the entire state is up in arms now attacking the president instead of attacking coach Knight for what he said
- And so that shot across the bow gave Knight the power he needed to survive up until 2000

**Did his behavior publicly get** ***worse*** **over time?**

- On YouTube there’s no shortage of [ridiculous moments in press conferences](https://www.youtube.com/watch?v=8BItv4Wo58k)
- He had unbelievable disdain for the press when he didn’t like their questions
- As media grew from the ’70s, the ’80s, to the ’90s, up until 2000, the media had greater and greater access to him
- Robert doesn’t think he fundamentally changed over that time, but what happened was Knight’s success as a coach started to dwindle leading to more frequent and bigger outbursts
- He had success at Army. He came to Indiana, had immediate success, took him to the final four in the second year. Won a national title in ’76. Won two more and an Olympic gold medal.
- So in a sense, you could say that *“****the ends justified the means”*** during that run
- But when he started getting eliminated in the first or second round of the tournament and these incidents became more and more public, Robert personally believes he took it out on his players and said, “*It can’t be me. I’ve won three national titles, an Olympic gold medal. It has to be you*.”
- In all likelihood, his players from the earlier years were more likely to put up with coach Knight’s antics since they were winning championships, “*if you win the national championship, you forget about a lot of it and you’re a hero forever, but when you start losing in the first and second round of the tournament you’re less willing to put up with that*.”
- In the early ’70s and ’80s right when he’d push you to your breaking point, he’d throw his arm around you, and walk out of practice, say something to you for 15 seconds. And it all went away, and you’re willing to run through a wall for him.
- But in the ’90s, instead of throwing his arm around kids, he took it out on them
- There’s a famous [audio recording of a tirade](https://www.youtube.com/watch?v=Chdg7wEGfYw) during half time of one game
- When Robert asked Richard Mandeville, who played for five years for coach Knight, Richard immediately said, “*That’s what I wish everybody who was watching this would understand that that’s every day.*”

## Knight’s ego swells—a shift from team-first to “I” and “me” [53:00]

- Knight was known for his team-first style of coaching, it’s not about the individual
- But in the 1990s when Knight’s success started to dwindle, it was clear he made a shift to “I” and “me”
- He had been so successful that when he started not being successful, in his mind it was, “It can’t be me. It’s got to be my players.”
- One player told Robert that when the NCAA tournament would come, probably the greatest three weeks in sports for people who love basketball, “***We didn’t care if we lost. Yeah, we wanted to win, but if we lost, we knew we didn’t have to go to practice the next day***.”

**Shifting from team to “I” – all about his ego in the 90s**

- There’s this view that Knight is this guy who places the importance of the team at the highest level, but Peter suspects it was really all about his ego
- He had lost all sense of checks and balances, there was nobody in that guy’s orbit that could offer any sense of sanity

> “I think a lot of people who give off this aura of team first, team first, team first, are really quite ego-driven when you really get underneath the surface.” —Peter Attia

**Bobby Knight’s private life [56:00]**

*Was Knight able to put some restraint in place with respect to his anger in his private life?*

- One story paints a nasty picture
- Knight was on a hunting trip in Argentina with his son
- One night, he and his son got in a physical altercation resulting in his son getting a bloody nose
- Robert looked into this alleged event and the owner of the hunting lodge confirmed it happened, “He confirmed what happened. He runs a very high-end lodge. He doesn’t want to bad mouth his very wealthy clients, but he did confirm to me that he drove them to the hospital and said to coach Knight, ‘You’re no longer welcome here.’”

Next, Robert called Christopher Simpson, the vice-president of media communications and [Myles Brand](https://en.wikipedia.org/wiki/Myles_Brand)’s right-hand man

- Robert spoke to Simpon on the day where they would announce [zero tolerance policy](https://www.dailynebraskan.com/knight-fired-for-violating-zero-tolerance-policy/article_7c5d6379-234a-5014-ae03-fffd23099d3e.html)
- Robert said to Christopher Simpson, “If coach Knight can’t control his temper so much so that he would harm his own son, how can you as a representative to this university ensure that if mothers and fathers around the country are going to send their sons to play for him that they’re not going to be safe?”
- Robert was appalled at his answer, “That has nothing to do with his coaching.”
- That gave you a sense of where the university was in trying to do damage control and protect coach Knight

## How patience, honesty, and gaining trust with his sources paid off in his reporting on Bobby Knight [1:01:30]

In April of ’99, Robert gets called into Steve’s office…

- [Luke Recker](https://en.wikipedia.org/wiki/Luke_Recker) had just left, the third player in two and a half years to be gone.
- That Sunday night is when Robert spoke to Neil
- Several days later, Robert flew up to Indiana, and for the next 9 months he’s reporting on it
- The problem was that nobody wanted to go on camera or speak on record: They were afraid of coach Knight – “*I could hear and feel the fear in their voices as I spoke to them*.”
- That fact drove Robert forward, “*There’s something here and I have to be patient.*”
- That meant slow-playing each relationship and developing trust with each source: “*I knew if I got one person on camera, I could probably get the second. If I got two, I could get the third. And if I got three, I could get five*.”

**Getting people to talk**

- The first ended up being [Professor Murray Sperber](https://en.wikipedia.org/wiki/Murray_Sperber)
- Early on, Robert called Luke Recker but Luke wouldn’t talk
  - However, Robert spoke to Luke’s mother and others who said that Luke wanted to quit after his freshman year
  - One time after his freshman year, Luke and his mother went in to speak to coach Knight telling him, “He doesn’t want to play here anymore.”
  - And coach Knight basically said, “I’ll change.” — but nothing changed
  - So at the end of year two, Luke really wanted out of there
- Next, Robert reached out to [Jason Collier](https://en.wikipedia.org/wiki/Jason_Collier) who was also not interested in talking
  - Robert said to Jason ”I’m not going to put your name out there. I’m just trying to understand what it’s like to play for coach Knight.”
  - Jason responded, “You know what it’s like to play for coach Knight? Go rent [Full Metal Jacket](https://en.wikipedia.org/wiki/Full_Metal_Jacket).” and then he hung up the phone
- Robert then started going through the roster and was eventually able to track down [Charlie Miller](https://iuhoosiers.com/sports/mens-basketball/roster/charlie-miller/9809) who agreed to talk
  - The first 10-15 minutes of the interview, Miller told Robert how much he loved coach Knight,  had respect for coach Knight who gave him an opportunity other people didn’t
  - But then Miller said, “Yes, he did put his hand around Neil’s throat.” — confirming that there was physical contact and
  - Miller did the interview on camera which was a huge breakthrough
- After that, Robert got ahold of [Richard Mandeville](https://iuhoosiers.com/sports/mens-basketball/roster/richard-mandeville/9810) who had played for Knight for five years
  - Reluctant at first, he agreed to go on camera once Robert told him that he already spoke to Charlie Miller and Neil Reed. And then he sat on camera.
- Finally, Neil Reed eventually agreed to go on camera and now Robert had 3 former players sit on camera

## The vicious cycle and anger and shame, and why Bobby Knight is so interesting to Peter [1:08:00]

**What is it about Bobby Knight that’s so interesting to Peter?**

- Peter sees some similar qualities in himself, namely **perfectionism** and a **bad temper**
- “I’m a perfectionist” says Peter, “and I’ve been that way as long as I’ve had any sort of conscious awareness of anything.”
- “Also, I’ve had a terrible temper my entire life
- E.g., at just five years old if he was building a big Lego tower and it broke, “I’d smash it into a million pieces”
- “I was just utterly pissed off beyond words when I couldn’t do something perfectly”

While that phenotype of a person can lead to some pretty good accomplishments…

- You can become pretty good at sports, you can do really well in school, you can do really well professionally, **but it comes at a great cost**

> “One of the biggest breakthroughs I’ve had in therapy, which was very difficult, I consider it the single biggest step function I’ve ever experienced in my life, was becoming aware enough of my inner monologue, not dialogue, but monologue with myself.” —Peter Attia

- \***Journaling** is a big help to keeping himself on track
  - Once when reviewing his journal entries with his therapist, the therapist pointed out Peter’s extreme **lack of self-compassion**
  - The therapist told Peter to personify the entity inside of his brain that is constantly berating him
  - Peter decided to **name that entity Bobby Knight**
- \***Meditation**, another useful tool, gives you enough of a pause or at least an awareness of the inner voice

Peter’s default is to be a harsh **self-critic** —

- when he makes “mistakes” his inner voice would NOT be “Ah, try again better, do it better the next time.” but instead it would be, “*You fucking idiot. You are so bad at this. How dare you practice this hard and still be this shitty*.”
- It was just this never ending insult
- And the “chairman of my board is Bobby Knight”

Seeing Robert’s [documentary on coach Knight](https://www.espn.com/30for30/film/_/page/lastdaysofknight#:~:text=Nearly%20two%20decades%20later%2C%20the,fall%20of%20a%20coaching%20legend.) allowed Peter to come up with this idea of Bobby Knight as his inner critic

- Step one: Become aware of the inner Bobby Knight
- Step two: Learning to offer an alternative explanation — “my way of saying you’re no longer the chairman of the board, thank you very much. In fact, you can leave the boardroom now.”

> “I suspect there are many people who can relate to that inner critic that is brutal. And this sort of lack of compassion we can have for ourselves.” —Peter Attia

**Robert’s reaction to Peter comparing his inner voice to coach Knight**

- Robert sees plenty of similarities to coach Knight
- There were stories of Coach Knight playing board games with his grandmother and she’d let him win, because if he didn’t win he’d throw a fit
- He’s a perfectionist with a terrible temper (his greatest undoing)
- The word jumped out when listening to Peter was “**awareness**” — And if you’re not aware of it, you can’t help yourself

**A story about Knight and self awareness**:

- Robert interviewed Dave Kindred, longtime journalist and someone who had known him for a long, long time, the good and the bad
- In a game in the mid 70s, Indiana vs Kentucky, coach Knight and Joe B Hall (coach of Kentucky) met at mid-court on the sidelines, and Knight [slapped on the back of the head](https://www.latimes.com/archives/la-xpm-1998-jan-01-sp-4146-story.html)

- Kindred is writing a story with a couple of other writers. And here comes Knight walking across the court, and Kindred looked at the other sports writers and said, “*This isn’t going to go well, this looks like trouble*.”
- Knight sat down with him and he said, “*How do I get myself into these situations?*”
- Which led Robert to believe that coach Knight **had an awareness of his flaws** as early as the mid 70s
- Unlike Peter, Knight didn’t try to address them
- Very early on coach Knight knew that there was something in his nature and his character, and that he had a temper
- “B*ut he never got it under control. And it ultimately led to his downfall 25 years later, but he was aware of it*.”

**The topic of** ***anger*** **[1:16:45]**

⇒ Check out Peter’s [discussion with therapist Terry Real](https://peterattiamd.com/terryreal/) on the topic of anger

- Anger can be a powerful anesthetic
- Many times anger overcomes a lot of the inadequacy that underpins it
- There’s a grandiosity that stands in the place of a true inner strength
- Often there’s a void that needs to be filled — and anger fills it and numbs pain in the short run,  but it’s immediately **followed by a lot of shame**

*In the case of coach Knight…*

- It’s unlikely that after berating his players every single day, shoving soiled toilet paper in their faces, etc. is thinking to himself, “*I’m a great guy*.”
- More likely, he’s feeling ashamed of what he’s doing, and as a result of that he’s beating himself up more
- It becomes greater and greater vicious cycle of needing greater grandiosity to overcome that shame, which leads to more outbursts of anger

A hard cycle to break

- “That’s a very difficult cycle to break.” says Peter
- You really need somebody else to help you break it—someone who can challenge you and push you
- Without that, you sometimes need a devastating crisis

> “My guess is it’s just a combination of all of these things. In that sense he became a victim of his success. His success kept him far enough away from crisis that there probably wasn’t enough impetus to change until it was too late.” —Peter Attia

**Robert’s take on Knights unbreakable cycle of anger**

- In March 2000, Robert released his [first story](https://transcripts.cnn.com/TRANSCRIPTS/0003/15/nsst.00.html) which laid out the three allegations put forth by Neil Reed (kicked the president out of practice, he brandished soiled toilet paper, and he grabbed Neil Reed by the throat)
- That could have been his crisis moment if he had people around him challenging him to be better
- ***But what actually happened?*** Indiana rallies the troops, everybody says it’s not true (including mainstream media)
- Eventually, Robert does a [second piece](https://web.archive.org/web/20090206071248/https://sportsillustrated.cnn.com/thenetwork/news/2000/04/11/knight_cnnsi/) that includes video evidence of Knight choking Reed and it changed the entire narrative of the nationwide story

## Releasing the choking tape—Breaking open the Knight story, vindicating his earlier reporting, and the most powerful moment Robert has ever witnessed in his journalistic career [1:20:00]

\*\*\*

**Robert’s ESPN 30 for 30 documentary**: [The Last Days of Knight](https://www.espn.com/30for30/film/_/page/lastdaysofknight)

*Here’s the original piece Robert did on Knight from March 15, 2000 which included the 3 allegations by Neil Reed*: [Former Players Break Silence About Bobby Knight; Indianians Rally Around Coach](https://transcripts.cnn.com/TRANSCRIPTS/0003/15/nsst.00.html)

*Here is the follow-up to the original story which included the choking tape*: [The Knight Tape – Video captures encounter between IU coach, ex-player](https://web.archive.org/web/20090206071248/https://sportsillustrated.cnn.com/thenetwork/news/2000/04/11/knight_cnnsi/)

*Here’s video showing the original AND follow-piece airing on CNN*: [Bob Knight CNN/SI Report](https://www.youtube.com/watch?v=tnXPM2eoGx0)

\*\*\*

**Gaining possession of the choking video & the importance of building trust with sources**

- After Robert’s [first story in March of 2000](https://transcripts.cnn.com/TRANSCRIPTS/0003/15/nsst.00.html), the media pushed back claiming the allegations were factually not true (claiming CNN was out to get coach Knight)
- Unfortunately, much of the outrage was directed towards Neil Reed for the “false” allegation about the choking incident
- However, Robert had long heard that a video tape of the choking incident existed — so **why didn’t Robert pursue the video?**
  - “*I thought if I pushed or asked about it and I got a no, then where do I go from there?*”
  - “*I work every one of my sources how I feel I can best connect with them, gain their trust*”
- At lunch with one of his sources, the source invited Robert back to his home saying, “I want to show you something.”
- The source showed Robert the tape of coach Knight going towards Neil Reed and Neil Reed’s head snapping back
- But even in that moment, Robert didn’t ask for the tape — Which might seem crazy considering for a month now, CNN and his reporting is under fire
  - “*I wasn’t sure that the answer would be yes*.”
- “The more I talked to somebody and it’s not on the front page, or it’s not in the news, the more they trusted me”, says Robert, “That’s how I got everything I got in this story.”
- Even though the video would vindicate his reporting and shut up all the critics, he didn’t ask for it — “*And it was just an instinct of mine*.”
- A couple days later, that same contact calls Robert offering him the tape, but Robert made a deal with that person that he wouldn’t air the tape until his contact got a lawyer

> “The tape shows up at my house a number of days later. It’s vindication for all my reporting.”

**Getting the tape, but keeping it quiet**

- Robert got the tape in the mail, but kept it to himself
- While he trusted Steve Robinson and Jim Walton, Robert was afraid the “higher ups” would force them to air it immediately
- So the only way to prevent that from happening, and probably being in complete control

*Telling his bosses about the tape*:

- After speaking to the attorneys of the source who gave Robert the tape, he finally decides to tell his bosses he acquired it: “I walked into Steve’s office with Jim Walton and I say, ‘I got the tape.’ And he’s like, ‘What? “Holy shit.’”

> “I hope people understand why I didn’t tell my immediate bosses, because I didn’t want somebody to overrule their decision, and I never wanted anybody who placed their trust in me to think I fucked them. And the only way I could ensure that 100% was to hold the tape and not let anybody know I had it.”

- After a few days of developing a follow up piece to his original reporting of the 3 stories told by Neil Reed, Robert’s bosses say,  “We have to call Indiana. . .In order to be fair journalists, we have to give them a chance to respond.”
- “I wanted to throw a haymaker and just have them watch it on TV like everyone.” says Robert
- To the credit of Walton and Robinson, they push back and say “No, to be honorable journalists, to be fair, we have to give them a chance to respond.”
- So **they called the Indiana University executives**

*Robert on why he didn’t want the Indiana executives a chance to see the tape before airing it*:

- Robert was afraid they would slap an injunction on us for having “stolen property”
- “I*t was probably personal frustration of all of the roadblocks and hurdles that Christopher Simpson specifically, and the lies he had said to me over the 9 months, 10 months of my reporting… Or now, it was over a year, actually, of my reporting that I didn’t think we owed them anything*.”

**Robert’s process of being a trustworthy reporter and being fair to his sources:**

- The same day that the Indiana executives were coming to view the tape, Robert had Neil Reed watching the choking video and react to it on camera
- Robert had spent nine months with Neil and talked to him over that time before the *initial report* had come out
- Neil later did an interview with ESPN for another project about it. And he told them, “Yeah, Robert and I became friends. We just started talking.”

> “If you’re real with people and they trust you, they’ll tell you anything, and Neil told me everything. And I never reported, I never hung him out to dry. I never betrayed his confidence in me.”

**The Indiana personnel coming to view the tape:**

- The personnel included two members of the board of trustees and two vice presidents of the school:
  - [Frederick Eichhorn](https://www.legacy.com/obituaries/name/frederick-eichhorn-obituary?pid=160271373)
  - [John Walda](https://www.repository.law.indiana.edu/notablealumni/205/)
  - [Christopher Simpson](https://www.dailypress.com/news/dp-xpm-20080227-2008-02-27-0802270144-story.html)
  - [Terry Clapacs](https://honorsandawards.iu.edu/search-awards/honoree.shtml?honoreeID=1072)
- In the room with Robert was Steve Robinson and Jim Walton
- The literal moment they all sat down at the table, Christopher Simpson (Miles Brand’s right-hand man) says, “*We understand you’re in possession of stolen property that belongs to Indiana University, and we want it returned immediately*.”
- Next came the **most powerful moment Robert’s experienced in his journalistic career**…
- Steve Robinson responded without missing a beat, in the most even keeled, emotionless tone just said something to the effect of:
- “*Well, I’m disappointed that you would come in here and say that. We were kind enough to invite you down to view this tape. If you’d like to pursue legal action, we’ll escort you out the door to the bank of elevators outside, I’ll push the button for the 13th floor, and you can speak to our legal department. But before the door opens on the 13th floor, this tape will be on CNN, CNN international headline news. We’ll send it out to 300 affiliates around the country. Now, did you come here to threaten us, or would you like to watch the tape?*”

“In my 34 years of being a journalist, I’ve never seen a more powerful moment by someone I worked with. . .he just surgically castrated him.” —Robert Abbott

- They then agreed that they can watch it in the room with Robert present but that whatever happens in this room is “off the record”
- [Steve Delsohn](https://www.amazon.com/Steve-Delsohn/e/B001IXU1ZW/ref=dp_byline_cont_pop_book_1), an investigative journalist who worked for ESPN for years, he wrote a [book](https://www.amazon.com/Bob-Knight-Unauthorized-Steve-Delsohn/dp/074346267X) and there was a chapter on this where Delsohn wrote, “*Robert was left alone in a room with four men who wished he was never born*.”
- Simpson began peppering Robert with questions, to which Robert responded, “*Hey, everything in this room is off the record. Do you want to sit here and ask me a bunch of questions? Or do you want to watch the tape*?”
- And then Christopher Simpson said he wanted to see the tape and he stood up to go press play
- At that point Robert stopped him and said, “*Mr. Simpson, sit the fuck down. I don’t care what my bosses say. If you don’t sit down right now, I’m going to unplug that machine, walk out to my car and drive back to my house, and you guys aren’t going to see this tape*.”
- So he sat back down, and they played the tape a number of times and they didn’t say anything

**After the meeting – interviewing John Walda**

- They had made an agreement that after watching the tape, Robert would interview John Walda
- Walda, the head of the board of trustees, was the one in charge of the investigation by the school.
- He was earlier quoted in the Indianapolis Star saying, “*I put no stock in what Neil Reed says. If CNN is saying it, then I don’t believe it.*”
- Robert’s first question to him was, “*You’ve now seen the tape. Do you put any stock in what Neil Reed says?*“
- But Walda was a broken record of just saying “*We’ve seen the tape. We’re in the middle of an investigation, it’s going to be part of our investigation*.”
- Robert says, “*For 10 months, I had been waiting to interview anyone from Indiana and hold them accountable, and so he started to frustrate me*”
- So he said, “*What do you say to people who want to send their sons to play for Bob Knight? Is that what’s going to happen to them?*”
- And ironically, Christopher Simpson says to Robert’s bosses, “*He can’t ask that*.”
- Robert asked about four more questions just to prolong the agony of him standing there, and then they left
- CNN put the [follow-up story](https://web.archive.org/web/20090206071248/https://sportsillustrated.cnn.com/thenetwork/news/2000/04/11/knight_cnnsi/) on about two hours later and it was front page news across the country

\*\*\*

**The Bobby Knight pieces by Robert and others in 2000**:

- March 15, 2000 – The [CNN transcript](https://transcripts.cnn.com/TRANSCRIPTS/0003/15/nsst.00.html) from the original piece by Robert
- Robert’s [follow-up piece](https://web.archive.org/web/20090206071248/https://sportsillustrated.cnn.com/thenetwork/news/2000/04/11/knight_cnnsi/) showing the choking tape
- Here’s the [video](https://www.youtube.com/watch?v=tnXPM2eoGx0) of the **original piece** in March AND the **follow-up piece** in April showing the choking tape
- April 14, 2000 – [NY Times article](https://www.nytimes.com/2000/04/14/sports/tv-sports-the-evidence-arrives-by-video-knight-indeed-had-a-choke-hold.html)
- May 22, 2000 – [SI article](https://vault.si.com/vault/2000/05/22/general-amnesty-after-an-investigation-that-uncovered-evidence-of-repeated-serious-transgressions-the-indiana-hierarchy-let-bob-knight-off-with-a-slap-on-the-wrist) by Robert Abbott

## The bittersweet story of Neil Reed—triumph, PTSD, and breaking the cycle of pain [1:43:15]

![](https://peterattiamd.com/wp-content/uploads/2020/12/neil-reed-with-coach-knight-706x1024.jpg)

**Figure 2. Reed with Coach Knight.** [[source](https://www.nytimes.com/2012/08/03/sports/ncaabasketball/neil-reed-was-known-as-player-choked-by-bob-knight.html)]

**Robert’s regret**

- Robert has come to regret the process of filming Neil Reed watching the choking video on camera without telling the story of how it impacted Reed psychologically
- “In the moment, I knew how difficult it was for him. . .how painful it was for him. But sadly…the purpose of that second story was to say, ‘We did a first story where this young man alleged these three things, and everybody said it was factually incorrect. Oh, by the way, it was correct, and here’s why. You can see it for yourself.’”
- Robert makes the comment, “*I missed the human story sitting right in front of me*.”
- In retrospect, he should have done a follow-up piece with Neil several weeks, several months, whatever later to say, “*What was this like personally?*” to focus on the damage the experience did to him as a young man

> “I confess that I fucked up as a journalist. I did the journalistic part of the story, but I missed the human story sitting right in front of me, which was Neil.”

**A bittersweet ending**

- Neil Reed went on to seemingly do pretty well
- He was coaching kids in high school basketball
- Tragically, he died of a massive heart attack at the age of 36

*Dreams becoming nightmares*

- Reed had always wanted to be a Hoozier
- As a young kid he often sported Indiana gear and dreamed of playing for Knight
- He once told Robert, “***I don’t know what’s worse. Never having your dream come true or having your dream come true and it turning into a nightmare***.”
- It’s especially painful to think about how the experience at IU made Neil question his entire being and everything that his life had led to to that point… yet coach Knight didn’t lose anything but a point guard who he quickly replaced
- Yet the tables ultimately turned as all these years later, Knight never really overcame being fired from Indiana but Neil, who struggled for a number of years, ultimately put it behind him

*Breaking the cycle*

- Oftentimes people who are traumatized and humiliated pass that on to others, but Neil proved to be someone who stopped the cycle — “*The abused didn’t turn into the abuser*.”
- Robert spoke to Reeds former high school players and they all had fond memories of him on and off the court
- In contrast, many of Knight’s players have no relationship with him off the court

*PTSD*

- While on the exterior Neil Reed seemed to have moved past the events of his college days
- But a little investigation painted a picture of someone who was still haunted
- For example, a few days after the horrifying [Jerry Sandusky trial](https://en.wikipedia.org/wiki/Jerry_Sandusky), Reed sent out a tweet that said, “*I now realize that kids deserve to be punched, spit on, choked, and raped in the shower. So a select few can be worshiped like gods*.”
- Robert says reading this tweet took his breath away, “He died a tortured human being,”  — It never left him. It ate at his mind and ate at his heart and ate at his soul. He never escaped what happened to him at Indiana.
- In a interview with his family, Robert further confirmed his lasting trauma from a story his wife told about a friendly wrestling match with when she put his hands on his neck, “*he just stopped…she noticed a distinctive change in him*”

*But by all accounts, Reed kept his PTSD locked away,*

> “He didn’t bring anybody down. He didn’t wallow in what had happened. He wanted to move on from it, and admirably, he did.”

## Examining Bobby Knight’s legacy, and how society can avoid a repeat of similar devastating situations [1:57:30]

**Aftermath of Robert’s reporting on Knight in the spring of 2000**

- The university decides not to fire him
- Instead, they “cowardly” create this zero-tolerance policy
- Knight quickly violates the policy leaving Indiana with no choice but to fire him
- He goes on to coach at Texas Tech for about 8 years before retiring
- He’s since done some commentary work on ESPN

**What’s his legacy at this point?**

- “I think it’s very mixed” says Robert
- A previously mentioned idea is that oftentimes people need a “crisis” to “awaken” them
- In a perfect world, Robert’s reporting would have been that moment for Coach Knight—it would have given him an awareness that he had to get his temper under control
- But it didn’t
- Furthermore, Knight lacked a community around him holding him accountable
- After Robert’s reports came out, Knight essentially begged for this job to Myles Brand which spurred the university to come up with the zero-tolerance policy

> “In a perfect, pollyannic world, he changes, the people around him keep him under control, and he breaks Dean Smith’s record for all-time wins at Indiana, and this is a learning experience for him. But it was anything but.”

- The reality is that immediately after zero-tolerance was implemented, he resented the people at the school
- He was like, “How dare you humiliate me like this?”
- Knight allegedly berated the head of the University Council for the school, Dottie Frapwell, when they were going over his punishments following Robert’s reporting
- Robert actually called Dottie to confirm the story, but he instead got a return call from Christopher Simpson

**Evidence of not learning anything**

- If you look at [Jeremy Schaap’s interview with Knight](https://www.youtube.com/watch?v=ZNxKeCLfJqs), he was just pathological lying probably to the level of what a psychopath is capable

**A fascinating human nonetheless**

> “Coach Knight is brilliant. A genius. He’s as only God can do, give some of us amazing gifts in one area and so many flaws in another.”

- Robert is fascinated by stories that resemble an onion with many layers
- Bobby Knight encompasses that type of person
- For example, Knight excelled in his recruitment of high quality kids — “*He recruited really, really quality individuals. I remember after my original reporting being impressed with the body of people I spoke to.*”
- Robert also interviewed [Angelo Pizzo](https://en.wikipedia.org/wiki/Angelo_Pizzo) (known for his work on the movie [Hooziers](https://en.wikipedia.org/wiki/Hoosiers_(film)))
- When Knight wins the national championship, he invites Angelo Pizzo to a practice and then on a recruiting trip so he basically spends the next 10 hours with Knight
- Apparently they talked about Russian history for six straight hours
- Pizzo talked about how smart he was. They jumped from topic to topic, mostly about Russian history.

[Dave Kindred](https://en.wikipedia.org/wiki/Dave_Kindred) on Knight’s anger problem, “*He had an anger in him. I don’t know where it came from or why it was there, but it never left him. And that was ultimately his undoing*.”

> “And that’s the genius of Coach Knight. How well read was, how he can motivate people. But ultimately, like Icarus, he didn’t understand his flaw and he flew too close to the sun. He couldn’t control his temper.”

## Final thoughts on Bobby Knight and the pain left in his wake [2:08:00]

**Peter thanks Robert for highlighting Neil Reed’s story**

- Peter says, “*Even though Neil’s life was taken too soon, he was validated. He got to spend the last decade of his life knowing that what happened, hopefully he understood it wasn’t his fault, which is easy to say. Because cognitively, of course it wasn’t his fault, but* ***that’s not always easy to understand as a victim***.”
- Robert says,
  - “*I owed it to Neil. It’s as simple as that. And I feel I owed it to him to make his story part of this film. Because when somebody trusts you like that…it’s a weight on y*ou.”
  - “B*y doing this film, at least I told people who the real Neil Reed was, who the Neil Reed I came to know wa*s.”

**The juxtaposition of Knight and Reed**

- “The most important thing in ‘The Last Days of Knight’ to me is the ending”, says Robert
- And that’s what gave the film the heart and soul of it. It was really about a young man who somehow found the strength to put it behind him. And someone (Knight) who would have all the success in the world, more success than anybody could ever imagine, that human being couldn’t put it behind him and to this day is angry and bitter.
- Neil was the opposite of Knight—A kid who had everything taken from him was able to move on.
- Knight in reality had very little taken from him—he still had three national championships, Olympic gold medal, Hall of Fame. He just couldn’t move beyond it.

“*And it tells you about the character of both individuals*.”

§

## Selected Links / Related Material

**Robert was the director of “The Last Days of Knight,” the behind-the-scenes documentary of legendary coach Bobby Knight, and the events that led to his termination from Indiana University**: [30 for 30: The Last Days of Knight](https://www.espn.com/30for30/film/_/page/lastdaysofknight#:~:text=Nearly%20two%20decades%20later%2C%20the,fall%20of%20a%20coaching%20legend.) | (espn.com) [3:00]

**Bobby Knight’s championship teams at Indiana**: [10:30]

- [1975–76 Indiana Hoosiers men’s basketball team](https://en.wikipedia.org/wiki/1975%E2%80%9376_Indiana_Hoosiers_men%27s_basketball_team) | (wikipedia.org)
- [1980–81 Indiana Hoosiers men’s basketball team](https://en.wikipedia.org/wiki/1980%E2%80%9381_Indiana_Hoosiers_men%27s_basketball_team) | (wikipedia.org)
- [1985-1986 Indiana Hoosiers men’s basketball team](https://en.wikipedia.org/wiki/1985%E2%80%9386_Indiana_Hoosiers_men%27s_basketball_team) | (wikipedia.org)

**Bobby Knight coached the USA men’s basketball team to a gold medal in 1984**: [1984 United States men’s Olympic basketball team](https://en.wikipedia.org/wiki/1984_United_States_men%27s_Olympic_basketball_team) | (wikipedia.org) [10:30]

**John Feinstein’s book on Knight**: [Season on the Brink: A Year with Bobby Knight and the Indiana Hoosiers](https://www.amazon.com/Season-Brink-Hoosiers-Feinstein-Paperback/dp/B011MBPQS6) by John Feinstein | (amazon.com) [11:00]

**Robert covered the 1996 Atlanta summer Olympics when the bombing by domestic terrorists occurred**: [Centennial Olympic Park bombing](https://en.wikipedia.org/wiki/Centennial_Olympic_Park_bombing) | (wikipedia.org) [13:15]

**The two projects that prepared Robert most for his Bobby Knight project**: [15:00]

- [Battle of the Sexes](https://en.wikipedia.org/wiki/Robert_Abbott_(director)#Battle_of_the_Sexes_(1994)) | (wikipedia.org)
- [Field of Screams](https://en.wikipedia.org/wiki/Robert_Abbott_(director)#Field_of_Screams_(1994)) | (wikipedia.org)

**Book about the soccer hooligans in England and the psychology of how those riots start**: [Among the Thugs](https://www.amazon.com/Among-Thugs-Bill-Buford/dp/0679745351) by Bill Buford | (amazon.com) [16:00]

**Mitch Williams gives up walk-off home run to lose the 1993 World Series sparking death threats from angry fans**: [1993 WS Game 6: Joe Carter wins Series with homer](https://www.youtube.com/watch?v=-F5HwiGm7lg) | MLB (youtube.com) [16:30]

**The stabbing of tennis star Monica Seles**: [1993: Tennis star stabbed](https://news.bbc.co.uk/onthisday/hi/dates/stories/april/30/newsid_2499000/2499161.stm) | (bbc.co.uk) [18:00]

**The last Mike Tyson fight where Tyson “went in as a great fighter and everything thereafter was sort of downhill”**: [Mike Tyson vs. Michael Spinks](https://en.wikipedia.org/wiki/Mike_Tyson_vs._Michael_Spinks) | (wikipedia.org) [25:15]

**Knight’s ridiculous statement to Connie Chung using rape as an analogy to describe stressful situations**: [Knight Is Criticized Over Rape Remark](https://www.nytimes.com/1988/04/27/sports/knight-is-criticized-over-rape-remark.html) | Malcolm Moran (nytimes.com) [45:00]

**Knight famously threw a chair across the court while someone was at the foul line**: [Bobby Knight throws chair, gets ejected vs. Purdue in 1985 [Full Incident] | College Basketball](https://www.youtube.com/watch?v=ukpekodCQ-U) | ESPN (youtub.com) [45:30]

**Mash up of Knight’s heated moments with the press**: [Some Quality Time With Bob Knight](https://www.youtube.com/watch?v=8BItv4Wo58k) | thecelebratedmisterk (youtube.com) [49:00]

**The famous audio recording of a Bob Knight tirade during half time of one game**: [BRAVO LIBRARY Bobby Knight angry halftime speech](https://www.youtube.com/watch?v=Chdg7wEGfYw) | David Bravo Jr. (youtube.com) [52:00]

**Indian’s zero tolerance policy put in place after Knight had repeated faced criticism for his actions**: [Knight fired for violating zero-tolerance policy](https://www.dailynebraskan.com/knight-fired-for-violating-zero-tolerance-policy/article_7c5d6379-234a-5014-ae03-fffd23099d3e.html) | (dailynebraskan.com) [1:00:00]

**Jason Collier told Robert that playing for Knight was like the movie Full Metal Jacket**: [Full Metal Jacket](https://en.wikipedia.org/wiki/Full_Metal_Jacket) | (wikipedia.org) [1:05:30]

**In a game in the mid 70s, Indiana vs Kentucky, coach Knight and Joe B Hall (coach of Kentucky) met at mid-court on the sidelines and Knight slapped on the back of the head**: [Out of Touch? Not Bobby Knight](https://www.latimes.com/archives/la-xpm-1998-jan-01-sp-4146-story.html) | Dave Kindred (latimes.com) [1:14:45]

**Peter’s interview of therapist Terry Real where they discussed anger**: [#119 – Terry Real: Breaking the cycle of shame, anger, and depression](https://peterattiamd.com/terryreal/) | Peter Attia (peterattiamd.com) [1:16:45]

**The original piece Robert did on Knight from March 15, 2000 which included the 3 allegations by Neil Reed**: [Former Players Break Silence About Bobby Knight; Indianians Rally Around Coach](https://transcripts.cnn.com/TRANSCRIPTS/0003/15/nsst.00.html) | (cnn.com) [1:20:00]

**Robert’s follow-up piece to the original story which included the choking tape**: [The Knight Tape – Video captures encounter between IU coach, ex-player](https://web.archive.org/web/20090206071248/https://sportsillustrated.cnn.com/thenetwork/news/2000/04/11/knight_cnnsi/) | Robert Abbott (cnn.com) [1:20:00]

**Here’s the CNN report on youtube showing the original AND follow-piece by Robert**: [Bob Knight CNN/SI Report](https://www.youtube.com/watch?v=tnXPM2eoGx0) | arobsz (youtube.com) [1:20:00]

**The infamous choking tape showing Bob Knight grabbing Neil Reed by the throat**: [Bob Knight Chokes Neil Reed](https://www.youtube.com/watch?v=fm3YFFjj5y8) | jwjiv1 (youtube.com) [1:22:00]

**Steve Delsohn’s book on Bobby Knight which has a chapter about the meeting between Robert and the IU executives where he wrote that “Robert was left alone in a room with four men who wished he was never born”**: [Bob Knight: The Unauthorized Biography](https://www.amazon.com/Bob-Knight-Unauthorized-Steve-Delsohn/dp/074346267X) by Steve Delsohn | (amazon.com) [1:37:45]

**Bob Knight got fired after grabbing an IU student and therefore violating the zero tolerance policy**:  [2:00:00]

- [Bob Knight could be fired after latest allegations – University investigating student claim that coach grabbed him, screamed profanities](https://www.cnn.com/2000/US/09/09/indiana.knight/) | (cnn.com)
- [Knight Fall – BOB KNIGHT’S CONTROVERSIAL 29-YEAR REIGN AT INDIANA CAME TO AN IRONIC END WHEN HE GAVE A STUDENT AN UNMANNERLY LESSON IN MANNERS](https://vault.si.com/vault/2000/09/18/knight-fall-bob-knights-controversial-29-year-reign-at-indiana-came-to-an-ironic-end-when-he-gave-a-student-an-unmannerly-lesson-in-manners) | (si.com)

**Jeremy Schaap’s interview with Knight after he was fired**: [Bob Knight and Jeremy Schaap – 9/12/2000](https://www.youtube.com/watch?v=ZNxKeCLfJqs) | Galen Clavio (youtube.com) [2:03:30]

**Angelo Pizzo (who Robert interviewed for his documentary) is known for the films Rudy and Hooziers**: [2:04:15]

- [Hoosiers (film)](https://en.wikipedia.org/wiki/Hoosiers_(film))
- [Rudy (film)](https://en.wikipedia.org/wiki/Rudy_(film))

§

## People Mentioned

- [Bobby Knight](https://en.wikipedia.org/wiki/Bob_Knight)
- [Jim Walton](https://en.wikipedia.org/wiki/Jim_Walton_(journalist)) [7:00, 1:25:00, 1:34:00]
- [Olga Korbut](https://en.wikipedia.org/wiki/Olga_Korbut) [7:00]
- [Nadia Comaneci](https://en.wikipedia.org/wiki/Nadia_Com%C4%83neci) [7:00]
- [Roone Arledge](https://en.wikipedia.org/wiki/Roone_Arledge) [7:15]
- [Dick Ebersol](https://en.wikipedia.org/wiki/Dick_Ebersol) [7:15]
- [Gary Hall Jr.](https://en.wikipedia.org/wiki/Gary_Hall_Jr.) [8:30]
- [Albert II, Prince of Monaco](https://en.wikipedia.org/wiki/Albert_II,_Prince_of_Monaco) (“Prince Albert”) [9:30]
- [Isaiah Thomas](https://en.wikipedia.org/wiki/Isiah_Thomas) [11:00, 30:15]
- [John Feinstein](https://en.wikipedia.org/wiki/John_Feinstein) (Season on the Brink author) [11:00]
- [Nick Charles](https://en.wikipedia.org/wiki/Nick_Charles_(sportscaster)) [14:15]
- [Jim Huber](https://en.wikipedia.org/wiki/Jim_Huber) [16:30]
- [Mitch Williams](https://en.wikipedia.org/wiki/Mitch_Williams) [16:30]
- [Katarina Witt](https://en.wikipedia.org/wiki/Katarina_Witt) [17:15]
- [Monica Seles](https://en.wikipedia.org/wiki/Monica_Seles) [17:15]
- [Dr. Park Dietz](https://en.wikipedia.org/wiki/Park_Dietz) [18:00]
- [Jeffrey Dahmer](https://en.wikipedia.org/wiki/Jeffrey_Dahmer) [18:00]
- [Dr. Gavin de Becker](https://en.wikipedia.org/wiki/Gavin_de_Becker) [18:00]
- [Madonna](https://en.wikipedia.org/wiki/Madonna) [18:15]
- [David Letterman](https://en.wikipedia.org/wiki/David_Letterman) [18:15]
- [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson) [20:00]
- [Tiger Woods](https://en.wikipedia.org/wiki/Tiger_Woods) [21:00]
- [Andre Agassi](https://en.wikipedia.org/wiki/Andre_Agassi) [21:45]
- [Pete Sampras](https://en.wikipedia.org/wiki/Pete_Sampras) [21:45]
- [Evander Holyfield](https://en.wikipedia.org/wiki/Evander_Holyfield) [22:00]
- [Don King](https://en.wikipedia.org/wiki/Don_King_(boxing_promoter)) [24:00]
- [Bill Cayton](https://en.wikipedia.org/wiki/Bill_Cayton) [24:00]
- Rory Holloway [24:00]
- [Cus D’Amato](https://en.wikipedia.org/wiki/Cus_D%27Amato) [24:00]
- [Steve Lott](https://en.wikipedia.org/wiki/Steve_Lott) [24:15]
- [Teddy Atlas](https://en.wikipedia.org/wiki/Teddy_Atlas) [24:15]
- [Jimmy Jacobs](https://en.wikipedia.org/wiki/Jimmy_Jacobs_(handballer)) [24:45]
- [Michael Spinks](https://en.wikipedia.org/wiki/Michael_Spinks) [25:15]
- [Luke Recker](https://en.wikipedia.org/wiki/Luke_Recker) [26:30]
- Steve Robinson (Robert’s boss at CNN) [26:45, 1:25:15, 1:34:00]
- [John Havlicek](https://en.wikipedia.org/wiki/John_Havlicek) [29:30]
- [Steve Alford](https://en.wikipedia.org/wiki/Steve_Alford) [30:15]
- [Neil Reed](https://en.wikipedia.org/wiki/Neil_Reed) [30:45, 1:19:00, 1:43:00, 2:08:00]
- [Jason Collier](https://en.wikipedia.org/wiki/Jason_Collier) [31:00]
- [Bobby Cremins](https://en.wikipedia.org/wiki/Bobby_Cremins) [32:15]
- [Larry Richardson](https://iuhoosiers.com/sports/mens-basketball/roster/larry-richardson/5122) [36:30]
- [Myles Brand](https://en.wikipedia.org/wiki/Myles_Brand) (former president of IU) [38:00]
- [Garry Donna](https://www.indystar.com/story/sports/high-school/2017/03/05/basketball-legend-garry-donna-dies-73/98784928/) [42:15]
- [Connie Chung](https://en.wikipedia.org/wiki/Connie_Chung) [45:00]
- [Alexander Wolff](https://en.wikipedia.org/wiki/Alexander_Wolff) (SI writer) [47:45]
- [Calbert Cheaney](https://en.wikipedia.org/wiki/Calbert_Cheaney) [50:00]
- [Kent Benson](https://en.wikipedia.org/wiki/Kent_Benson) [51:15]
- [Richard Mandeville](https://iuhoosiers.com/sports/mens-basketball/roster/richard-mandeville/9810)  [52:45, 1:07:30, 1:19:00]
- [Christopher Simpson](https://www.dailypress.com/news/dp-xpm-20080227-2008-02-27-0802270144-story.html) [59:45]
- [Professor Murray Sperber](https://en.wikipedia.org/wiki/Murray_Sperber) [1:03:15]
- [Charlie Miller](https://iuhoosiers.com/sports/mens-basketball/roster/charlie-miller/9809) [1:06:15, 1:19:00]
- [Dave Kindred](https://en.wikipedia.org/wiki/Dave_Kindred) [1:14:15, 2:07:30]
- [Joe B. Hall](https://en.wikipedia.org/wiki/Joe_B._Hall) [1:14:45]
- [Lester Munson](https://en.wikipedia.org/wiki/The_Sportswriters_on_TV) [1:23:45]
- [Rick Davis](https://www.cnn.com/profiles/richard-davis-profile) [1:27:15]
- [Frederick Eichhorn](https://www.legacy.com/obituaries/name/frederick-eichhorn-obituary?pid=160271373) (IU executive that came to CNN to watch the tape) [1:33:15]
- [John Walda](https://www.repository.law.indiana.edu/notablealumni/205/) (IU executive that came to CNN to watch the tape) [1:33:15]
- [Christopher Simpson](https://www.dailypress.com/news/dp-xpm-20080227-2008-02-27-0802270144-story.html) (IU executive that came to CNN to watch the tape) [1:33:15]
- [Terry Clapacs](https://honorsandawards.iu.edu/search-awards/honoree.shtml?honoreeID=1072) (IU executive that came to CNN to watch the tape) [1:33:15]
- [Steve Delsohn](https://www.amazon.com/Steve-Delsohn/e/B001IXU1ZW/ref=dp_byline_cont_pop_book_1) [1:37:45]
- [Hillary Horgan](https://twitter.com/hillaryhorgan?lang=en) [1:47:45]
- [Jerry Sandusky](https://en.wikipedia.org/wiki/Jerry_Sandusky) [1:54:00]
- [Dean Smith](https://en.wikipedia.org/wiki/Dean_Smith) [2:01:00]
- [Dottie Frapwell](https://vault.si.com/vault/2000/09/18/knight-fall-bob-knights-controversial-29-year-reign-at-indiana-came-to-an-ironic-end-when-he-gave-a-student-an-unmannerly-lesson-in-manners) [2:02:00]
- [Jeremy Schaap](https://en.wikipedia.org/wiki/Jeremy_Schaap) [2:03:30]
- [Angelo Pizzo](https://en.wikipedia.org/wiki/Angelo_Pizzo) [2:04:15]
- [Gene Hackman](https://en.wikipedia.org/wiki/Gene_Hackman) [2:04:30]
- [Dennis Hopper](https://en.wikipedia.org/wiki/Dennis_Hopper) [2:04:45]
- [David Anspaugh](https://en.wikipedia.org/wiki/David_Anspaugh) [2:05:00]

§

![](https://peterattiamd.com/wp-content/uploads/2020/12/abbott_robert_c.png)

##### Robert Abbott

Robert Abbott is a six-time Emmy Award winning producer and director with 30+ years experience in the sports and entertainment industry. This is his second film for ESPN’s acclaimed 30 for 30 series and the first for his company Hey Abbott! Entertainment. Abbott pitched the 30 for 30 film, Catholics vs. Convicts, and was the film’s executive producer in 2016. Abbott spent 11 years at ESPN , from 2001-2012, and during that time was instrumental in creating series like E60 and Top 5 Reasons You Can’t Blame. He also helped create and oversee the productions of Who’s #1? and The Headlines for ESPN25, the network’s 25th anniversary project. Prior to joining ESPN Abbott spent 14 years at CNN where he produced the award-winning documentaries, Field of Screams, Battle of the Sexes and The Moses Project.

Abbott is a graduate of Florida State University and lives in Avon, CT with his wife Jennifer and their three sons. [[espn.com](https://www.espn.com/30for30/film?page=lastdaysofknight)]