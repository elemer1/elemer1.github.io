# #90 – Ryan Holiday: Stillness, stoicism, and suffering less

**Source:** [https://peterattiamd.com/ryanholiday/](https://peterattiamd.com/ryanholiday/)

---

##### Check out more content with Ryan Holiday:

- *(January 27, 2020)* [Ryan Holiday: Stillness, stoicism, and suffering less](/ryanholiday/)
- *(March 27, 2020)* [Ryan Holiday: Finding stillness amidst chaos](/ryanholiday2/)

In this episode, Ryan Holiday, author of [Stillness is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585), shares the profound impact that stoic philosophy has had on his personal life and his career as a successful writer. Ryan stresses the importance of stillness in a modern world set up to encourage the opposite and lays out the best strategies to develop stillness in your life. He also explains the destructive nature of being driven by ego, as well as the perils of jealousy and anger, and provides practical steps you can take to avoid those harmful states.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ryanholiday/the_Drive_public.png)

Play

#90 - Ryan Holiday: Stillness, stoicism, and suffering less

1x15s30s

0:002:16:06

## We discuss:

- Has a more connected world improved or worsened our lives? [2:15];
- Consequences of an overly secure life, living in the present, & the misconception of unlimited time [5:45];
- Stoicism 101: The definition and origins of stoic philosophy [15:45];
- Ryan’s career transition into writing, and his take on what makes a book or business successful [26:45];
- Storytelling—The upside and downside of telling stories and self narrative [36:15];
- Does achieving success have to come from a place of craving and proving others wrong? And what are the costs of building a legacy? [38:45];
- Ego—confusing ego with confidence, signs your ego is showing, & antidotes to the negative effects of ego [52:45];
- Ryan’s advice to Peter about writing (and finishing) his book [1:06:30];
- Stillness—what it is, how it compares to meditation, & the obstacles to achieving stillness [1:10:30];
- Ryan’s morning routine, relationship with his smartphone, and how he avoids falling victim to the trappings of technology and a hyperconnected world [1:17:40];
- The perils of jealousy and envy [1:24:15];
- How to live in the moment in a modern world not designed for stillness [1:32:15];
- How the idea of “dying well” can help you live better [1:36:00];
- How has fatherhood impacted Ryan’s philosophies on stillness and living in the moment? [1:39:45];
- How to make your favorite day your every day [1:42:00];
- The most reliable strategies for developing stillness [1:47:30];
- Anger—what the stoics say about anger, outrage in politics, & why more anger isn’t the solution [2:02:00];
- How to follow Ryan’s work [2:12:00]; and
- More.

§

## Show Notes

## Has a more connected world improved or worsened our lives? [2:15]

-Peter starts by asking Ryan about life on a farm

- Ryan lives in a home on a farm for part of the year outside of Austin, TX
- The internet is not good and the phone signal is lost if you leave the house
- The silence created by not have a connection to the world: “*It creates a sort of an artificial silence, which is great*.”

–*How have smartphones improved or worsened our lives?*

- Ryan comments that when smartphones first came out if felt like it gave us more freedom
- But as the technology improved, you can now be reached at all times whether texting, calls, emails, and social media channels
- “*Once I was carrying [smartphones] around in my pocket and I could always access them, they were always there, that’s when it became much worse*.”

-Peter’s take:

- There is a balance, an optimization point, that was missed and we’ve now gone too far.
- We still have more to gain on the max if the objective is making money for the companies that produce things like that (but it’s more complicated from a personal perspective)

## Consequences of an overly secure life, living the present, & the misconception of unlimited time [5:45]

**What is the strangest or most surprising thing about a farm?**

“*There’s a lot of death. Just overall a lot of death.*”

- It just familiarizes you with death in a way that human beings used to be a lot more familiar with
- Your grandparents would die in your house, or your wife would die of childbirth in your house, or you would die being killed by Native Americans in your house.
- Life was more brutal and violent, but it was also **more present**

-Ryan tells the story of an injured goose

- The goose was attacked by something and they took it to the vet to get it stitched up for $300
- Then a dog came along and killed it a couple months later
- But the interesting thing was… the other geese they just didn’t even care. “It was just like, ‘we’re a gaggle and there were five of us, and now there’s four of us. It wasn’t this elaborate mourning thing.’”

⇒ [D.H. Lawrence](https://en.wikipedia.org/wiki/D._H._Lawrence) has a poem where he [says](https://www.goodreads.com/quotes/4343-i-never-saw-a-wild-thing-sorry-for-itself-a), “*I never saw a wild thing sorry for itself. A small bird will drop frozen dead from a bough without ever having felt sorry for itself.*”

**One lesson Ryan has taken from living on a farm**:

> “*The animals are much more present and focused and not worried in the way that humans are worried. And ironically, they have way more to be worried about.*”

**Is it possible that our overly safe and secure lifestyle has robbed us of something?**

- In the US, all of your basic needs are being met
- We’re not worried about being bombed or killed on a daily basis (unlike [some people](https://peterattiamd.com/tomcatena/) in other parts of the world)

*-How has that affected us?*

—**First**, we begin to assume that we have **unlimited time** or that we have complete control of our existence

- We could choke on food, or get hit by a bus tomorrow
- Seneca [talks](https://dailystoic.com/how-to-say-no-advice-from-the-worlds-most-powerful-man/) a lot about how we’re really tight-fisted over the things that don’t matter (money, property, stuff, things you can get more of) yet we are MOST generous with our time.

![](https://peterattiamd.com/wp-content/uploads/2020/01/tight-fisted-ryanholiday-1024x698.png)

**Figure 1. Seneca pointing out how we are too generous with our time compared to how tight-fisted we are with things that don’t really matter.**

**–Secondly**, because you feel like there’s unlimited time, your **quality of life goes down** because you stop living in the moment

- Insights from stoics:
  - From [Marcus Aurelius](https://en.wikipedia.org/wiki/Marcus_Aurelius)—Make sure you are enjoying what you are doing
    - Marcus Aurelius [said](https://dailystoic.com/14-stoic-quotes-on-death/), “*Are you afraid of death because you won’t be able to do THIS anymore?*”
    - We don’t really actually judge the **quality of the existence** that we have very much. I think there’s a lot of people who are alive, who are basically dead anyway. They’re sleepwalking through life.

![](https://peterattiamd.com/wp-content/uploads/2020/01/am-i-afraid-of-death-marcus-aurelius-ryan-holiday.jpg)

**Figure 2. Quote by Marcus Aurelius about death and making sure you are doing what you want to be doing.** Image credit: [azquotes.com](https://www.azquotes.com/quote/825998)

- From [Seneca](https://en.wikipedia.org/wiki/Seneca_the_Younger)—He talks about how we think that death is something that lays off in the future, but actually death is something that’s happening right now.
  - In other words, if averages tell you that you’ll live to be 78, instead of saying I have 48 years left, you should realize you’ve already died 30 odd years.

> “Most of our time already belongs to death. The time that has passed is dead. I think that’s a much more active, empowering, adaptive way to think about it. . .Oh, I’m dying all the time and every second that passes, you don’t get back. And then that allows you to decide how you’re going to spend that time, or at least think about that you are spending it.” —Ryan Holiday

## Stoicism 101: The definition and origins of stoic philosophy [15:45]

Peter highly recommends Ryan’s email newsletter called [The Daily Stoic](https://pages.convertkit.com/79d6c63e9f/0965aed219)

**Ryan has two ways to explain the philosophy of stoicism:**

1 | Simplest way:

- The central precept of stoicism is the idea that we don’t control the world around us, but we control how we respond.
- Said more clearly…“*You don’t control other people, you control yourself. You don’t control what happens, you control your reactions.*”

2 | The more nuanced way:

-Stoicism is a way of life built around [four virtues](https://dailystoic.com/4-stoic-virtues/):

1. Courage
2. Justice
3. Temperance (moderation)
4. Wisdom

“*It’s sort of truth, self-control, doing the right thing, having the stones to stand up for those things. That, to me, is the essence of this philosophy.*”

**The complicated story of Seneca:**

> “Seneca, on the one hand, was this remarkable example of stoic philosophy, and yet in the end, his desire to be approved by Nero [and] to be in his good graces. . .may well have forced him to contradict all the things that he believed in.”

*The story of Seneca and Nero*

- [Seneca](https://en.wikipedia.org/wiki/Seneca_the_Younger) is this Roman Senator, he’s a philosopher, he’s a playwright, he’s probably the smartest man in Rome in his time.
- But he’s sent into exile by an emperor, Claudius
- While in exile, on this rock in the middle of nowhere, he’s writing this philosophy all about adversity and perseverance
- But then he gets summoned back to Rome, but only if he is willing to be the tutor of a young boy named [Nero](https://en.wikipedia.org/wiki/Nero)
- Nero was this very promising student who also has a dark side
- He starts out good and towards the end…
- Seneca is writing speeches for Nero that help Nero justify why he murdered his mother.
- “*It gets very dark, very quickly.*”
- And Seneca becomes extraordinarily wealthy for his association with Nero
- It’s a tough balance, because Seneca was suddenly morally compromised in a bunch of ways that, if he had his choice, he wouldn’t be
- Ultimately Seneca decides to leave towards the end, and Nero’s like, “No, you don’t get to leave. I decide when you leave.”
- But Seneca made his decision which ultimately led to Nero ordering Seneca to kill himself (which was the way they did things at the time)

*-Ryan and Peter contemplate how Seneca would reflect on his decision to tutor Nero rather than stay in exile…*

- Maybe he said yes because he thought he could prevent this from happening
- Ryan doesn’t think Seneca was in denial about who Nero was, but Ryan postulates that Seneca probably said to himself, “*who will do a better job than me?*”

It begs broader questions…

- Do we have a greater obligation to our own principles and our own personal beliefs?
- Do we have a greater obligation to society to maximize the impact we can have on others?
- **For Seneca**, he probably did the best he could have, and perhaps he saved lives as a result of his association to Nero?
- Some even believe that Seneca conspired to assassinate Nero
- The point here is that this is not clear cut, it’s infinitely complicated

**The story of Cato during the Roman Empire**: *What happens when you have no ability to compromise?*

- [Cato](https://en.wikipedia.org/wiki/Cato_the_Younger) was the stoic philosopher
- Cato loved Rome dearly, however, his inability to compromise, his insistence on principle and perfect solutions, essentially grind the Roman political machine to a halt

> “I think one of the things you end up taking as you study philosophy and history is just some humility about how complex these things are and how rarely they are as black and white as they seem. I think what stoicism is really about is a sort of a personal code that lets you try to figure out what you should do in your individual situations, and not be so concerned about what other people did, or why or how or whether they were perfect.”

## Ryan’s career transition into writing, and his take on what makes a book or business successful [26:45]

When Ryan first starting reading stoicism

- Started reading [Epictetus](https://en.wikipedia.org/wiki/Epictetus) and [Marcus Aurelius](https://en.wikipedia.org/wiki/Marcus_Aurelius) in college
- It definitely impacted him but he Ryan points out, “*how much you’re really getting at that age, it’s hard to tell.*”

Early career

- From there he became a research assistant for a really great writer, [Robert Greene](https://en.wikipedia.org/wiki/Robert_Greene_(American_author))
- He did marketing for a couple of other writers
- Then somehow ended up as the director of marketing at [American Apparel](https://en.wikipedia.org/wiki/American_Apparel)… “*which was a crazy, dysfunctional, chaotic, but ultimately really fascinating place to work.*”

–About his time at American Apparel:

- “It was just a lot of money, a lot of temptations, a lot of conflict, a lot of politics, a lot of the human condition out on display.
- But… it was [also] a really interesting creative learning opportunity. I got to do all sorts of cool stuff from a marketing perspective that got seen by millions and millions of people.
- I sort of learned how…you write stuff, but this is where the rubber meets the road, where you sell it to people.”

**What are some important insights that Ryan learned about writing early on?**

–[Robert Greene](https://en.wikipedia.org/wiki/Robert_Greene_(American_author)), who wrote [The 48 Laws of Power](https://www.amazon.com/48-Laws-Power-Robert-Greene/dp/0140280197), says, “*Never appeal to mercy or gratitude. Always appeal to self interest.*”

- The premise being… *I want to build a company that’s ethical, fair to employees, not destroying the environment, but* ***no one will buy clothes for those reasons***
- They ultimately buy clothes because they look good in them, etc.
- It’s this sort of tension between the pure expression and the realities of the market.
- What Ryan took from that… “*As a writer, it’s not just what you want to say, it’s where that overlaps with the market*”

> “The perfect book idea is what you can’t stop thinking about and what people can’t stop saying they need a book about. When those overlap, you get something really powerful.”

Ryan see the path to successful writing as follows:

- Especially when writing about stoicism, which to most people is an obscure, boring, complicated thing
- How does he give it to people who are busy, tired, overwhelmed, don’t like books, don’t like big ideas, can’t pronounce any of the names?
- He’s NOT trying to reach the 1% of people who are reading the original stoicism literature
- “I’m trying to reach people who think, ‘*Philosophy? I don’t have time for that*.’”
- Ryan says a successful writer can tap into that market if they “***get out of the artistic side of your profession a little bit.***”

**More about the overlap of what you are fascinated by with what people want to know more about:**

- Ryan also believes that part of his success as a writer is because he’s writing about topics with a long tail of history
- Stoicism for example has survived “*2,500 years of diverse human experiences*”

⇒ “*Almost every single one of my books is rooted in, or inspired, or in some way almost a rip off of some very brilliant, sometimes obscure, sometimes popular title from the past.*”

- Ryan’s first book was this book called [Trust Me, I’m Lying](https://www.amazon.com/Trust-Me-Lying-Confessions-Manipulator/dp/1591846285)
- It was an expose of how the media works.
- And many people credit Ryan for predicting the rise of “fake news”
- But Ryan says that he modeled that book after a book by [Upton Sinclair](https://en.wikipedia.org/wiki/Upton_Sinclair) published in 1913 called [The Brass Check](https://www.amazon.com/Brass-Check-Study-American-Journalism/dp/0252071107)
- “Although I do want to do things that haven’t been done before. I’m still kind of thinking, ‘How can I take some risk off the table by modeling and on something that has some proven staying power?’”
- [Star Wars](https://en.wikipedia.org/wiki/Star_Wars), for example, is still being watched today and not because the “amazing special effects” (which they were at the time) or the novel idea of a “sci-fi” movie… but because of the **story being told***—a timeless story based on the hero’s journey*

> “I think when you root things in some arc, or story, or deeper truth, you are taking some of that risk off the table. I just think that’s a strategy not employed enough.”

## Storytelling—The upside and downside of telling stories and self narrative [36:15]

**Best quotes from Ryan about storytelling and self narrative**:

*“Narrative is one of the things that makes us human. We’ve been telling stories in writing for 5,000 years. We have an oral Epic poem tradition that’s probably 10,000 years old. So it goes to the core of who we are.”*

*“And I go back and forth, sometimes I think [storytelling] is very powerful. Sometimes I think it’s very dangerous.”*

*“You can tell people facts or you can tell them stories that leave them with the conclusions that are the same as the facts that you would have told them.”*

*“What I decided to do with Obstacle, Ego is the Enemy, and now Stillness, was not write a book that tells people what the stoics say, but give people books that illustrate what the Stoics said or believed through story.”*

**What do you think is the downside of the storytelling?**

> “I think stories are a great way to learn lessons about other people. Stories are a bad way to think about your own life.”

- Too many people go through life like they are performing for an imaginary audience …
- … and this comes at the expense of actually living in the moment

## Does achieving success have to come from a place of craving and proving others wrong? And what are the costs of building a legacy? [38:45]

**Story about having “enough”**

- Two successful writers, [Kurt Vonnegut](https://en.wikipedia.org/wiki/Kurt_Vonnegut) and [Joseph Heller](https://en.wikipedia.org/wiki/Joseph_Heller), are at a party at a billionaire’s house
- Vonneguy and Heller are sort of the “status symbol” people at the party and don’t really have any business being there otherwise
- Vonneguy says to Heller, “How does it feel to know that he made more money this week than your book will probably ever make in it’s life?”
- And Heller said, “Well I have something he doesn’t have.”
- Vonnegut said, “What could that possibly be?”
- And he said, “***I have enough****. I have a sense of what enough is.*“

**Can you do something at an elite level from a place of fullness? Or does it have to come from a place of craving?**

- Ryan says many people are afraid of having “enough” because the “lack of satisfaction” is what people believe propel them to greatness
- Per Ryan, “*It can be responsible for a lot of victories. But it can also be responsible for why you failed to appreciate or enjoy any of those victories.*”

-In his book, [Stillness is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585), Ryan is exploring the question of: **Can you do what you’re doing well, like at an elite level even from a place of fullness? Or does it have to come from a place of craving?**

- Examples of being driven by craving:
  - I’m gonna prove them all wrong.
  - I’m going to beat anyone that doubts me.
  - I’m going to earn my father’s approval
- But is it possible to do it the other way?
  - From a place of passion, appreciation and gratitude
  - Or just for the love of the game?
- Can there at least be a **balance** of the two mindsets?

-Ryan’s current take on it:

- Ryan thinks it IS possible do it from a place of fullness
- In Ryan’s life… he can look at the success of his book sales, etc. and say “*I’m doing it*.”
- But he sometimes doubts this logic, thinking that maybe if he was a little hungrier… “*Could I have sold MORE copies*?”
  - I don’t pretend to have the definitive answer, but I do generally think fullness is better than craving and it’s more sustainable.
  - A fuel of “craving” and “proving them wrong” might eventually **corrode the engine**.

> “My goal in my life is to be great at what I do, but somehow be a normal person. For whatever reason that’s important to me, to have some semblance of a normal life, to not be so lopsided, to not be miserable, to actually like what I’m doing.”

**Peter’s take:**

“*The likelihood you’re going to hit an absolute maxima, not the local, the absolute maxima of your quantifiable metric—money, likes, acceptance, trophies—and that you could [simultaneously] hit a local maxima of the inverse of suffering. I think that’s incredibly rare.*

*I think more likely if you choose to select a local maxima around some measure of the* ***inverse of suffering****, you probably aren’t going to hit an absolute maxima on those other things (money, fame, etc.). But who cares? … What game are we playing?*”

⇒ Example: Tiger Woods

- He once said something along the lines of *“I don’t play it because I love golf…I play for the hardware…Winning is great, but beating someone is always better.*”
- He’s probably the greatest golfer of all time
- But the other areas of his life seem to be ticking time bombs that when they go off take down the entire edifice that he’d spent so much time building

**What does building your legacy for when you’re gone cost you while you are still alive?**

- People who long for posthumous fame, forget that you’re not going to be around to appreciate it
- So why would you be trading in your happiness now for something you won’t enjoy when you’re gone?
- In other words, *what does it* ***cost*** *you when you are alive?*

–*Peter says these are important lessons but you have to be ready to hear it*:

> “You have to have pain to change. I mean, you know what? Even if that’s not true, it’s true of me. Even if it’s not true broadly. It’s absolutely true of Peter Attia. He must hurt to change.” -Peter Attia

## Ego—confusing ego with confidence, signs your ego is showing, & antidotes to the negative effects of ego [52:45]

> “A big distinction between ego and confidence…Confidence is important, right? You’ve got to know what you’re capable of. You’ve got to have some evidence of it. You got to have some knowledge of strength and weakness. I think the problem with ego is that it’s not any of that. Ego comes from some third place. And I think at the core of ego is an association of our identity with results, or with external things. So in some senses it can be helpful in terms of driving external results; but we see just as often that ego undermines those results once we get them.”

**The ego comes back to get you eventually**

- Historically, it’s hard to point to super egotistical people, even ones super successful, who died surrounded by people who loved them (Julius Caesar, Saddam Hussein, etc.)

*-Confusing ego with confidence*

- It’s very easy to confuse ego and confidence because you don’t actually know
- Especially for young people because “*you haven’t experienced it enough to know what profound insecurities and weaknesses these strategies are compensating for and how vulnerable these guys are to slumps, or mistakes, or how often they get in their own way.*”

*⇒ Example: Steve Jobs*

- Very successful, but did he really NEED to be fired from his own company before making the big return to Apple? Or could he have accomplished more or made a bigger difference if his ego wasn’t so powerful?
- **The point is…** we are really bad at calculating **how much more successful a person could be if their ego wasn’t getting in the way**.

> “You can be successful despite ego. And that’s different from saying you can be successful because of ego.”

**Signs of your ego showing itself:**

  1 | when you feel like it’s **all on you**… “you have profoundly inflated your importance in whatever situation you’re in”

  2 | when you feel **paranoia** like “People are out to get me. They’re screwing me over. I’m being held back.”

  3 | when you start to **identify with what you’ve accomplished** using arbitrary ratings of success (likes, downloads, book sales)…that’s ego because now you’re not present, you’re thinking about how do you maintain and control and get these things

  4 | when you are **comparing yourself to other people** … a decent sign of ego… instead you should compare yourself against your intention, or your own standards

  5 | *(from Peter)* when you’re **more interested in being “right” than finding the truth**

**A saying from** [**Cyril Connolly**](https://en.wikipedia.org/wiki/Cyril_Connolly):

> “Ego sucks us down like the law of gravity.” —Cyril Connolly

- In other words, “*if you are not ever getting up off the couch, gravity is not a big problem for you. But if you’re jumping between buildings, or you’re doing something really hard, really high up there, the falls going to be real painful.*”

**Antidotes to the negative effects of ego:**

  1 | **Humility**

  2 | Always trying to **learn**

- Epictetus [said](https://www.goodreads.com/quotes/303727-it-is-impossible-for-a-man-to-learn-what-he), “*It is impossible for a man to learn what he thinks he already knows.”*
- [John Wheeler](https://en.wikipedia.org/wiki/John_Archibald_Wheeler), the physicist, [said](https://www.goodreads.com/quotes/271895-we-live-on-an-island-surrounded-by-a-sea-of), “*As your Island of knowledge grows, so does the shoreline of ignorance.*”
- In other words… the more you learn, the smarter you are, but the **more aware you become of the things you don’t know**

⇒ Ryan has [written](https://ryanholiday.net/the-swarm-strategy-how-to-learn-about-anything/) about the topic of truly learning a topic, like the Civil War, for example

> “There’s people who as they get more successful, there’s less and less you can teach them, and there’s less and less that they want to hear. Then there are people who as they get better, become more curious, more interested, more open, less rigid. I think that’s where you want to go.”

![](https://peterattiamd.com/wp-content/uploads/2020/01/wait-but-why-dunning-kruger-curve-ryanholiday-948x1024.jpg)

**Figure 3. One blogger’s humorous take on the Dunning-Kruger curve.** Image credit: [@waitbutwhy](https://www.instagram.com/p/B6_du7onLaf/)

## Ryan’s advice to Peter about writing (and finishing) his book [1:06:30]

- Peter is currently struggling with the idea that the book he is writing is “finished”
- He’s crippled by the idea that once he hands it in, there will be things in the book that his opinion might change about in the future
- A book is this “static” thing, whereas he never feels like he’s done learning about these topics

**Ryan’s advice**:

—[Winston Churchill](https://en.wikipedia.org/wiki/Winston_Churchill), who wrote more books than just about anyone in the 20th Century, says that at some point you have to “kill the book and fling it to the public”

- “And I think it’s right. You do. You have to stop at some point.” says Ryan

–In Ryan’s experience in writing, he says “*I look at the book and it’s just, I didn’t know what I didn’t know. So there’s a certainty to some of the things that in retrospect I see with more nuance now. And so in a way each of the books is a balance, right? Because you want the books to be tight and you want them to be straight forward. You want them to be compelling. But also you have to be intellectually honest.*”

- Ryan credits his mentor, [Robert Greene](https://en.wikipedia.org/wiki/Robert_Greene_(American_author)), for a lot of what he knows about writing

> “Certainty is the enemy, because certainty is what you regret when you look back. It’s not that you took a stand or you thought this or you said this. It’s the **tone** with which you did it that you can come to regret. It was the pretension that, ‘of course I’m right.’”

## Stillness—what it is, how it compares to meditation, & the obstacles to achieving stillness [1:10:30]

**Meditation vs. stillness**

- Ryan says people confuse stillness with meditation
- Meaning that they think stillness requires solitude or silence
  - Perhaps solitude is the easiest way to achieve that… but in real life you can’t drive out to a cabin in the woods each time you need stillness

> “I’m interested in, ‘How do you have stillness in the real world—where you have bills to pay and a family and a house and neighbors and you drive a car in traffic.’”

*-By stillness, Ryan really means…*

- The stillness of reducing the expectations
- Reducing or extracting the unnecessary.
- Locking into what you’re doing, whatever it is, even if it’s a minor thing
- Think [Anne Frank](https://en.wikipedia.org/wiki/Anne_Frank) sitting in front of her diary
- Or the **opposite** of whatever Tiger Woods’ life was like.
- Or the stillness that [Marcus Aurelius](https://en.wikipedia.org/wiki/Marcus_Aurelius) was able to achieve as the emperor

**⇒ Ryan’s article about how Kennedy handled the Cuban Missile Crisis in a very calm and stoic manner**: [Leadership lessons from the Cuban Missile Crisis](https://www.managementtoday.co.uk/leadership-lessons-cuban-missile-crisis/leadership-lessons/article/1662045)

–*Why doesn’t Ryan talk much about meditation?*

- Ryan says it’s about meeting people where they are
- The science is clear that meditation is effective, but it’s also clear that most people don’t want to meditate
- Ryan thinks a better starting point is to talk about a more comprehensive philosophical approach to stillness
- At the end of that conversation, the person might be in a better place to try something like meditation

> “and you realize that philosophy is actually an active word based writing process, not a book that you read one time and then you’ve magically absorbed the insights.”

**Meditation is a tool to reach an outcome, but Stillness itself is the outcome, the skill you want to attain**

*-How Peter uses meditation:*

- Meditation is a tool, a training platform that teaching you a skill
- The skill Peter takes away from meditation is “**gap awareness**”
- Gap awareness is the gap between stimulus and response
- Peter wants the biggest gap possible
- During the actual practice of mindfulness meditation…
- Peter focuses on his breath
- And he catches himself thinking
- And then he comes back and forth and back and forth and back and forth
- [Jeff Warren](https://jeffwarren.org/), a great meditation teacher, describes this process of catching your thought and bringing it back to your breath (over and over) as analogous to doing bicep curls

-So in the above case, meditation is just the **tool** that is training a skill called “gap awareness”

- Stillness, on the other hand, is the skill (not the tool)

***What are some of the obstacles to stillness?***

1. Over-committing yourself to more than you can conceivably handle.
2. Never feeling like you have “enough” … like an insatiable demand or need
3. Unnecessary noise, (internal noise or exterior)
4. Bad habits, and bad routines
5. The total lack of routine or structured limits can be a “huge obstacle to stillness”
6. A lack of hobbies or practices

- Meditation, for example, is not just the practice of doing it, it’s the “**having” of a practice period**.
- Your practice could be cooking dinner every night, for example
- “Having a thing that you do that you control, that you can access on demand is hugely important.”
- For Ryan, that practice is running or swimming.

> “Just having this place I can go to when I’m stressed or overwhelmed or when I’m struggling with some big decision is a huge source of relief and reflection for me.”

## Ryan’s morning routine, relationship with his smartphone, and how he avoids falling victim to the trappings of technology and a hyperconnected world [1:17:40]

*How long after waking up does Ryan wait before looking at his phone?*

- Usually at least an hour (many time longer)

*Does he use an alarm to wake up?*

- Not usually, mostly because he has really young kids who take care of that

Ryan really likes an app called [SPAR!](https://getspar.com/)

- It allows you to create challenges for yourself and your friends and holds you accountable for doing them

*Ryan is trying to push out how long he can go before looking at his phone*:

- He started by challenging himself to go at least an hour
- Now he’s accomplished that and just sees how long he can go
- The morning that this podcast was recorded he got up to 2.5 hours

Peter asks, *what did you do with that 2.5 hours that we not cursed with your phone?*

- Took his son for a bike ride
- Had breakfast
- Did some journaling
- Then got some work done (writing) on his computer

> “So it’s not that I don’t want to ever use the phone, it’s just I want to be using the phone rather than be used by the phone, which is what I think most of the time our use of these devices is, were being used by the technology.”

*What about people who have lives and jobs that don’t offer that luxury?*

- Ryan clarifies that it’s not really about disconnecting yourself completely from your phone
- It’s more about building in boundaries around it that keep you from falling victim to what the phone is made to do, **which is to make you use the device**.

**Computer and email**

-Unlike Peter, who despises email, Rick prefers email as his medium of communication:

- He funnels everything through email so that he can have control over when and how he responds
- “What I hate are fucking phone calls. That’s what I want to have the least amount of in my life.”
- Email is good for me, but I’m not writing and simultaneously checking my email every time something comes in.
- Any rules around when he checks his email?
- Not really, he sort of checks it peripherally throughout the day so I can see if things are happening
- But he prioritizing the tasks of the day and never allows himself to get sucked into immediate, reactive response to stuff
- Once he’s taken care of his tasks, he will dedicate time to responding to emails

## The perils of jealousy and envy [1:24:15]

> “I find there’s very few egotistical people who I think we would define as still.”

**Others on jealousy**:

–[Theodore Roosevelt](https://en.wikipedia.org/wiki/Theodore_Roosevelt) once said, “*Comparison is the thief of joy.*“

–[*Joseph Epstein*](https://en.wikipedia.org/wiki/Joseph_Epstein_(writer)) said, *“Of all the seven deadly sins, envy is the only one that’s no fun*”

**Per Ryan**:

“*When you are envious, it is always a negative feeling. You’re only feeling bad about what YOU don’t have and you are angry or resentful or hurt that someone else has it instead. . .*

*. . .The irony of envy is often we are envious of people who are envious of other people. In some cases we don’t know it, but secretly they’re envious of us.*”

*⇒ Example*, many people think they want fame, but many famous people would give anything to have their privacy back.

## How to live in the moment in a modern world not designed for stillness [1:32:15]

Ryan has previously written “*the call to stillness comes quietly, but the modern world does not and that creates a pretty negative pressure against stillness.*”

- The lack of stillness opportunity in our modern world largely comes from the smartphones and internet
- But even in the Roman Empire days, life was incredibly noisy
- Ryan says one of his favorite quotes that he put in his book [[Stillness](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585)] is from [Blaise Pascal](https://en.wikipedia.org/wiki/Blaise_Pascal) in mid 1500s, “*All of humanity’s problems stem from our inability to sit quietly in a room alone.*“
  - What Ryan thinks he meant by that was that all of our suffering stems from the things we go out and do to try to alleviate that suffering that ultimately create new forms of suffering.
  - Pascal has also said [paraphrased], “*Distraction is the greatest thing that we pursue to combat our misery. Yet, it is in and of itself our greatest form of misery.*”

**The story of the fisherman and the CEO**

![](https://peterattiamd.com/wp-content/uploads/2020/01/fisherman-and-businessman-story-ryanholiday-828x1024.png)

**Figure 4. Famous story of the fisherman and the businessman.** Credit: [paulocoelhoblog.com](https://paulocoelhoblog.com/2015/09/04/the-fisherman-and-the-businessman/)

-This fisherman story actually dates back 600+ years

- There’s a similar story of a minister speaking to a king and the king is saying, “*Well we have to invade Prussia. And then after Prussia we have to invade Vienna, [and so on], and THEN we can have peace.*”
- Ryan’s take is that part of what Pascal is saying is that… **if we could sit quietly in a room alone, we wouldn’t go do these things that then prevent us from sitting quietly in a room alone**.

**⇒ Study where people are given the option of sitting alone or pushing a button for an electrical shock that allows them to leave the room**: [People would rather be electrically shocked than left alone with their thoughts](https://www.sciencemag.org/news/2014/07/people-would-rather-be-electrically-shocked-left-alone-their-thoughts)

**Parenthood offers a learning opportunity**

- Ryan’s example is that sometimes as a father, he will feel like, “*I’ve got to rush home, I’ve got to drive dangerously. I’ve got to see my kids*.”
- But then you see your kids and two minutes later you’re like, “I’m going to go in the other room and do my thing now.”
- We have this well-intentioned urge to do the right thing, to be there with people it, but then **are we actually doing it when we’re there?**

-Take the example where a parent has to travel a lot and be away from their kids

- That time away from the kids would be infinitely easier if 100% of the time you were with the kids you were actually present
- As opposed to how most of us are which is thinking about to do lists, or running around the house trying to do things

-The big decisions are easier, the hard decisions are the more subtle things

- Like deciding to run an errand, or clean the garage, instead of just being present

> “This is where that [memento mori](https://en.wikipedia.org/wiki/Memento_mori) stuff comes in . . .don’t think about it as you have an unlimited amount of [time] . . . because you’ll never get the time back. So was it actually more important that you went and did X, Y, and Z? Maybe not.”

## How the idea of “dying well” can help you live better [1:36:00]

**What does “dying well” mean to Ryan?**

- [Cicero](https://en.wikipedia.org/wiki/Cicero) once [said](https://dailystoic.com/nothing-goes-planned/), “*to philosophize is to learn how to die.*”
- Ryan says that the ancients valued dying as something important that you want to do well

–*But how could focusing on my death make my life any better*?

- Seneca describes the visual of an older person who can’t “let go”
- He said something like, “You should look with pity on the aged lawyer who continues to plead in court for his clients.”
- He’s talking about the guy who can’t accept that his moment has passed and he has to pass the baton to the next generation.
- Despite all their success, all their fame, all their money, there’s not enough.

–*But what would the argument that maybe that is their greatest source of joy? Shouldn’t they keep doing what they love?*

- Ryan’s rebuttal is that, “*Is this actually fun or is this a compulsion, or a craving?*”

⇒ [Joan Rivers video](https://www.youtube.com/watch?v=HXDO3UNRowA)

- Joan River once explained why she wasn’t retiring by pointing to a blank calendar and saying, “*See these blank pages? If these pages stay blank, it means that I’m nothing, that I’ve fallen off, that my career was pointless*.”
- Ryan’s interpretation is that Joan is basically saying, “*These blank pages make me a worthless as a human being*.”
- That’s **craving** versus fullness, says Ryan
- And it’s a very different answer than had Joan said, “*See this blank calendar, what am I going to do? I’m going to sit around at home. I love being on the road. I love working. I love being with an audience. This is what I was put on the planet to do*.”

> “The idea of aging gracefully, of going out well is, it’s not this separate thing. It is the culmination of these principles that we’re talking about. Death isn’t this separate random other thing. It is a process that we’re already engaged in, whether we know it or not. . .You’re dying now and you’ve already died however many years you’ve been alive and you’re just doing it every day until you finally get to the last time that you do it.”

## How has fatherhood impacted Ryan’s philosophies on stillness and living in the moment? [1:39:45]

> “Parenting and presence are very related because what is fascinating and entertaining and stimulating for [young children] is usually an incredibly boring thing [to an adult], and so you are almost forced to adopt that childlike existence, and I find it very refreshing.”

## How to make your favorite day your every day [1:42:00]

**When Ryan talks to people about success…**

- He doesn’t ask, “What do you want to accomplish? What do you want to have? What do you want to have done?”
- Rather, he asks, “What do you want? How do you want that to manifest itself into your life? What do you want your life to look like?”

–*For Ryan, his answer is…*

- A day with almost no exterior interruptions. A little time to write. Not feeling pressure. Time with family. And being outside.

–*To figure out your own answer to that question, Ryan suggests paying attention to “perfect days”…*

- Say you visit somewhere on vacation and then you’re like, “Oh, wouldn’t it be wonderful to live here?”
- Or when you have one of those perfect days you should think, “How can my whole life be like this?”
- Ryan says we have a lot more power over that then we think
- But unfortunately we then just “go back to agreeing to shit we don’t want to do.”

-The skeptic might say, “*How much power do we actually have over that?“*

- Ryan is successful and can afford to take steps towards his dream day, but what about the average person?
- Ryan responds that “*it wasn’t free for me to set up this life. There were real costs to it.*”
- He could have more opportunities in business and writing if he lived in NY or LA.
- The point is… “***this life that I set up was not gifted to me****. This required a bunch of different compromises and a bunch of different well thought out, intentional decisions.*”
  - Buying a house that was less than I could afford
  - Saying no to awesome sounding things
  - Passing on opportunities

-Before making a life decision, ask yourself… “*Is this getting me closer to that day or further from that day?*”

- Commonly, people will tell themselves, “*oh, this stretch of hard work is temporary and then I it will calm down on it’s own*”
- But that’s a slippery slope…
  - “*You tell yourself it’ll go back to normal after a certain point, but it doesn’t go back to normal. You have to put it back to normal, right? You have to stop. You have to draw a line.*”
- Ryan is much more interested in creating a **sustainable** lifestyle

==> Ryan’s blog post: [So you want to be a writer? That’s Mistake #1](https://ryanholiday.net/so-you-want-to-be-a-writer-thats-mistake-1/)

## The most reliable strategies for developing stillness [1:47:30]

- Meditation is a practice to get to a desired state (or better yet, [trait](https://youtu.be/1iGVX_ubMmE?t=7217)).
- Whereas with stillness… stillness itself is the desired outcome

*Ryan says that stillness is tough to define*:

> “The problem with . . .what you get from stillness or whatever the opposite of ego is, is that there’s an ineffability to it. You can’t really describe what it is because it’s fleeting and ephemeral and also deeply unique to each person and each time you have it. . .I can’t even give you a definition of what stillness is, let alone a magical recipe. But I can give you some tools or strategies that tend to be correlated with achieving that outcome.”

**The most reliable strategies to developing stillness:**

**1 | Walking**

- Every day, Ryan walks just to get some sort of low impact, physical exercise outdoors
- But he’s doing the exercise for the **mental benefits**, not the physical benefits
- On the topic of running and swimming: Ryan does these to but they are for the physical benefits primarily
- And when he’s walking he is simply trying to pay attention to the experience of walking
- When he finds himself distracted, he just reminds himself to bring his attention back to the experience (so it’s very much like meditation in that way)

**2 | Journaling**

- Many stoics journaled as a way to find stillness
- “*I think journaling would be a huge one.*”

**3 | Hobbies**

- Ideally, the hobby is not something that you can “win” at or where more effort equals better outcome
- It should not be a willpower-related endeavor
- Examples: Painting, writing, causal sports,
- Just having some sort of practice or activity that you do on a regular basis.
- For Ryan, it’s the farm⇒ while the farm can be a lot of work, the work feels restorative to Ryan

⇒ Ryan tells a story that he got from the book he recommends called, [On Looking](https://www.amazon.com/gp/product/1439191263/ref=dbs_a_def_rwt_bibl_vppi_i2) by Alexandra Horowitz, where she described how differently kids view experiences

## Anger—what the stoics say about anger, outrage in politics, & why more anger isn’t the solution [2:02:00]

**What did the stoics think about anger?**

- As a group, they’re against it
- Seneca wrote a beautiful essay called [On Anger](https://en.wikipedia.org/wiki/De_Ira)
  - It’s basically a warning to young Nero about the costs and the dangers of anger

*-We make excuses for anger…* Like ego, we’re really eager to make excuses for it, “*Oh, it’s part of who I am and helps me with what I’ve done. It’s great fuel.*”

**Temper vs. moral outrage**

- There is a distinction
- Losing your temper is rarely something you are happy that happened
- But that’s different than say, when you hear or see something that isn’t right and your immediate reaction is, “*That’s not okay. I’m upset that that’s the status quo.*”
- The stoics are very anti-temper
- Seneca is like, “Look, if someone murdered your father, you’d still get vengeance. You don’t want to do it from a place of anger.”
- And I think he just means that there’s an objective idea of justice.

-Ryan points out that not being angry doesn’t mean you accept everything and that you wilt and you tolerate the gravest injustices, but it’s that **you’re not being jerked around by those reactions**.

- In the movie [Lincoln](https://en.wikipedia.org/wiki/Lincoln_(film))…
  - there’s a scene where Abe Lincoln slams the table out of rage and says “I am the president of the United States.” He’s just like, “I am clothed in immense power. That’s impotence.”
  - He’s angry at the impotence that he got this far and this thing is so obvious. Passing the 13th amendment is profoundly obviously the right thing to do.
  - That’s so much of where our anger comes from.
  - But then when you even think about that situation, **it’s not the anger that solves it**, it’s that he then leaves that room and he’s willing to basically do all sorts of complicated, even in some cases, morally dubious things, to get where he needs to go.

–*What does the expression mean, “revenge is a dish best served cold”?*

- In Ryan’s book, [Conspiracy](https://www.amazon.com/Conspiracy-Peter-Gawker-Anatomy-Intrigue/dp/0735217645/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), he write about Peter Thiel and his quest to destroy Gawker
- People think that “revenge is a dish best served cold” means you want to enjoy the fruits of your victory
- But no, it means that you don’t want to touch a hot plate. You don’t want to do it out of anger because *you’ll get burned*.

**Anger and outrage in politics**

> “I think politically, we’ve now confused anger and political change. We almost conflate purity or moral superiority with how angry you are. That’s not how you solve any problems.”

- Ryan believes the current levels of moral anger and outrage is all a performance
- It’s almost therapeutic
- It’s in the way that we used to be really into music, we’re now really just into being angry about political and social issues.

> “There are very few problems to which anger as the solution, and the most serious problems, the ones that are the most aggravating, are the ones that require the most discipline and the least amount of anger.”

*-Ryan on why more anger isn’t the solution*:

- Most of the wrong in the world is not being done deliberately.
- Most of the wrong is being done by people who don’t know better, who are ignorant, who are being manipulated, or in some cases think they’re doing the right thing.
  - So anger at those people is not going to make them change their mind. You’re not going to yell at someone into waking up to the bad assumption that you’ve taken in.
- And then there are real bad people in this world
  - There’s evil and there’s sociopaths and there’s real bad actors. Those people, you’re certainly not going to yell at a sociopath into not being a sociopath.
- It’s precisely **the most dangerous high stakes situations require our utmost cognitive and rational resources**.
- “*I’m just stating the fact that less anger is better.*”

**If only we could see an photograph of ourselves in a fit of rage…**

- Seneca talks about this idea of seeing other angry people and how off putting it looks
- (like [this one of Tom Izzo](https://www.gannett-cdn.com/-mm-/0c5050ee767657768c817a0db0970b3ac502ac0f/c=0-262-5031-3092/local/-/media/2019/03/24/USATODAY/usatsports/gty-1137411721.jpg?width=3200&height=1801&fit=crop&format=pjpg&auto=webp))
- He talks about looking in the mirror when you’re anger, “Have you ever actually seen yourself getting angry?”
- Peter and Ryan think if you could look at yourself (in reality or in reflection) you would be repulsed at how you look and might lead you to think twice in the future before losing your temper

⇒ Check out Ryan’s blog post for more on this topic: [Here’s How You Stop Anger From Making You Do Something Stupid](https://ryanholiday.net/heres-how-you-stop-anger-from-making-you-do-something-stupid/)

## How to follow Ryan’s work [2:12:00]

-Check out his latest book, [Stillness Is The Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)

-Subscribed to his 2 newsletters:

- [Daily Stoic](https://dailystoic.com/)
- [Daily Dad](https://dailydad.com/)

-Social media

- [Twitter](https://twitter.com/ryanholiday/)
- [Instagram](https://www.instagram.com/ryanholiday/)
- [Facebook](https://www.facebook.com/ryanholiday)

§

## Selected Links / Related Material

**List of Ryan’s books**: [My Books](https://ryanholiday.net/ryan-holiday-books/) | (ryanholiday.net)

**Book that is the main topic of discussion in this podcast**: [Stillness Is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585) by Ryan Holiday | (amazon.com) [1:00, 37:00, 40:45, 1:45:50, 1:48:15]

**Ryan’s daily email newsletter that Peter cannot speak more highly of**: [The Daily Stoic](https://pages.convertkit.com/79d6c63e9f/0965aed219) | (dailystoic.com) [1:30, 16:00, 2:12:00]

[**D.H. Lawrence**](https://en.wikipedia.org/wiki/D._H._Lawrence) **poem where he says he’s never seen an animal feeling sorry for itself**: [D.H. Lawrence > Quotes > Quotable Quote](https://www.goodreads.com/quotes/4343-i-never-saw-a-wild-thing-sorry-for-itself-a) | (goodreads.com) [9:30]

**Peter’s interview of Tom Catena, an amazing doctor who serves a million people in South Sudan**: [#40 – Tom Catena, M.D.: The world’s most important doctor – to nearly a million patients – saving countless lives in the war-torn and remote villages of Sudan](https://peterattiamd.com/tomcatena/) | Peter Attia (peterattiamd.com) [10:15]

**Seneca talks a lot about how we’re really tight-fisted over the things that don’t matter, yet we’re the most generous with our time**: [How To Say “No”: Advice From The World’s Most Powerful Man](https://dailystoic.com/how-to-say-no-advice-from-the-worlds-most-powerful-man/) | Ryan Holiday (dailystoic.com) 11:30

**Marcus Aurelius said, “Are you afraid of death because you won’t be able to do this anymore?”**: [14 Stoic Quotes on Death](https://dailystoic.com/14-stoic-quotes-on-death/) | (dailystoic.com) [13:15]

**The four virtues of stoicism**: [The Highest Good: An Introduction To The 4 Stoic Virtues](https://dailystoic.com/4-stoic-virtues/) | (dailystoic.com) [18:30]

**TV show that Ryan says has a plot analogous to how Seneca’s intentions start out good but they turn dark after he becomes closer with Nero**: [Breaking Bad](https://en.wikipedia.org/wiki/Breaking_Bad) | (wikipedia.org) [21:00]

**John Kelly, Trump’s former Chief of Staff, warned Trump that other people would not be able to tell him “no” the way that he could and it would lead to bad consequences**: [John Kelly says he warned Trump he’d be impeached if he hired a ‘yes man’ as chief of staff to replace him](https://www.washingtonpost.com/politics/john-kelly-says-he-warned-trump-hed-be-impeached-if-he-hired-a-yes-man-as-chief-of-staff-to-replace-him/2019/10/26/e4d5d028-f827-11e9-8cf0-4cc99f74d127_story.html) | Colby Itkowitz and Josh Dawsey (washingtonpost.com) [22:30]

**Company where Ryan worked before becoming a full time writer**: [American Apparel](https://en.wikipedia.org/wiki/American_Apparel) | (wikipedia.org) [27:00]

**Book that suggests that you should “*****Never appeal to mercy or gratitude. Always appeal to self interest.*****”**: [The 48 Laws of Power](https://www.amazon.com/48-Laws-Power-Robert-Greene/dp/0140280197) by Robert Greene | (amazon.com) [29:00]

**Classic books and big hit books that keep selling copies and are examples of big hitters that give publishers funds to allow them to invest in book projects of today**:  [33:15]

- [Great Gatsby](https://www.amazon.com/Great-Gatsby-F-Scott-Fitzgerald/dp/0743273567) by F. Scott Fitzgerald | (amazon.com)
- [Good to Great](https://www.amazon.com/Good-Great-Some-Companies-Others/dp/0066620996/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Jim Collins | (amazon.com)
- [The Four Hour Work Week](https://www.amazon.com/4-Hour-Workweek-Escape-Live-Anywhere/dp/0307465357) by Tim Ferriss | (amazon.com)
- [To Kill a Mockingbird](https://www.amazon.com/Kill-Mockingbird-50th-Anniversary/dp/0062420704/ref=sr_1_2?gclid=Cj0KCQiAyKrxBRDHARIsAKCzn8xujiCMa7-wI-9U6YVElkQ_g4gqExPKlcWYg7KDZk8Bbr-aqyYU_KYaAsFbEALw_wcB&hvadid=326580105024&hvdev=c&hvlocphy=9027582&hvnetw=g&hvpos=1t1&hvqmt=b&hvrand=10276169970163124857&hvtargid=aud-836690481282%3Akwd-423657976309&hydadcr=10029_9773055&keywords=to+kill+mockingbird+hardcover&qid=1579885719&sr=8-2) by Harper Lee | (amazon.com)

**Ryan’s first book**: [Trust Me, I’m Lying: Confessions of a Media Manipulator](https://www.amazon.com/Trust-Me-Lying-Confessions-Manipulator/dp/1591846285) by Ryan Holiday | (amazon.com) [34:15]

**Book that Ryan used as the model for Trust Me, I’m Lying**: [The Brass Check](https://www.amazon.com/Brass-Check-Study-American-Journalism/dp/0252071107) by Upton Sinclair | (amazon.com) [35:00]

**Two of Ryan’s books where he took the approach to writing that was about telling a story to the reading that allowed them to come to the conclusions he wanted them to come to rather than just tell them directly**: [37:00]

- [The Obstacle Is the Way: The Timeless Art of Turning Trials into Triumph](https://www.amazon.com/Obstacle-Way-Timeless-Turning-Triumph/dp/1591846358?tag=ryanholnet-20)
- [Ego is the Enemy](https://www.amazon.com/Ego-Enemy-Ryan-Holiday/dp/1591847818?tag=ryanholnet-20) [37:00, 52:45]

**Book by Joseph Heller**: [Catch-22](https://www.amazon.com/Catch-22-50th-Anniversary-Joseph-Heller/dp/1451621175/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Joseph Heller | (amazon.com) [39:20]

**Book by Kurt Vonnegut**: [Slaughterhouse-Five](https://www.amazon.com/Slaughterhouse-Five-Novel-Modern-Library-Novels/dp/0385333846/ref=sr_1_1?gclid=CjwKCAiA66_xBRBhEiwAhrMuLZdwon7jmi7Z9pu8tK65pBh3nGszznoTKfQnhXZhYOBSqi-YY0vCKhoCb1IQAvD_BwE&hvadid=409913392290&hvdev=c&hvlocphy=9027599&hvnetw=g&hvpos=1t1&hvqmt=b&hvrand=7977899799411116768&hvtargid=aud-836690481282%3Akwd-315532356220&hydadcr=10024_11275120&keywords=slaughterhouse+five+kurt&qid=1579988383&sr=8-1) by Kurt Vonnegut | (amazon.com) [39:20]

**Austin Kleon’s definition of “Art monsters”**: [Art monsters](https://austinkleon.com/2017/11/09/art-monsters/) | Austin Kleon (austinkleon.com) [48:45]

**Famous baseball player who got arrested for allegedly beating his daughter**: [EX-MLB STAR JOSH HAMILTON ARRESTED FOR CHILD ABUSE](https://www.tmz.com/2019/10/30/josh-hamilton-arrested-child-abuse-texas-rangers/) | (tmz.com) [49:00]

**The “rise and fall of WeWork” is a great example of what happens when ego (of founder Adam Neumann) is just utterly unchecked**: [WeWork](https://en.wikipedia.org/wiki/WeWork) | (wikipedia.org) [56:15]

**Another example of unchecked ego was Dov Charney getting fired from American Apparel**: [Dov Charney: Dismissal](https://en.wikipedia.org/wiki/Dov_Charney#Dismissal) | (wikipedia.org) [57:30]

**Colin Powell talks about making sure your ego is not associated with your position**: [Quotations from Chairman Powell](https://govleaders.org/powell.htm) | Oren Harari (govleaders.org) [59:10]

**Epictetus the inability to learn when you think you already know**: [Epictetus > Quotes > Quotable Quote](https://www.goodreads.com/quotes/303727-it-is-impossible-for-a-man-to-learn-what-he) | (goodreads.com) [1:03:15]

**John Wheeler, the physicist, said, “As your Island of knowledge grows, so does the shoreline of ignorance.”**: [John Archibald Wheeler > Quotes > Quotable Quote](https://www.goodreads.com/quotes/271895-we-live-on-an-island-surrounded-by-a-sea-of) | (goodreads.com) [1:03:15]

**Ryan’s article about the process of truly learning a topic (the Civil War, for example) and how you must view it from all angles and immerse yourself in the topic**: [The Swarm Strategy (How to Learn About Anything)](https://ryanholiday.net/the-swarm-strategy-how-to-learn-about-anything/) | Ryan Holiday ( [1:04:40]

**Ryan article about how Kennedy handled the Cuban Missile Crisis in a very calm and stoic manner**: [Leadership lessons from the Cuban Missile Crisis](https://www.managementtoday.co.uk/leadership-lessons-cuban-missile-crisis/leadership-lessons/article/1662045) | Ryan Holiday (managementtoday.co.uk) [1:12:00, 1:56:30]

**The 2 documentaries about the fraudulent “Fyre Festival”**: [1:25:00]

- [Fyre Fraud](https://en.wikipedia.org/wiki/Fyre_Fraud) | (wikipedia.org)
- [Fyre: The Greatest Party That Never Happened](https://en.wikipedia.org/wiki/Fyre_(film)) | (wikipedia.org)

**Famous parable about the fisherman and the businessman**: [1 MIN READING: The fisherman and the businessman](https://paulocoelhoblog.com/2015/09/04/the-fisherman-and-the-businessman/) | Paulo Coelho (paulocoelhoblog.com) [1:30:30]

**Study where people are given the option of sitting alone or pushing a button for an electrical shock that allows them to leave the room**: [People would rather be electrically shocked than left alone with their thoughts](https://www.sciencemag.org/news/2014/07/people-would-rather-be-electrically-shocked-left-alone-their-thoughts) | Nadia Whitehead (sciencemag.org) [1:31:25]

**Cicero once said, “to philosophize is to learn how to die.”**: [Nothing Goes As Planned](https://dailystoic.com/nothing-goes-planned/) | (dailystoic.com) [1:36:00]

**Video of Joan Rivers revealing why she doesn’t want to retire**: [Joan Rivers Is ‘A Piece of Work’](https://www.youtube.com/watch?v=HXDO3UNRowA) | Associated Press (youtube.com)[1:38:00]

**Ryan’s article about the real life of a writer/author**: [So you want to be a writer? That’s Mistake #1](https://ryanholiday.net/so-you-want-to-be-a-writer-thats-mistake-1/) | Ryan Holiday (ryanholiday.net) [1:45:15]

**Book by Alexandra Horowitz where she takes a walk with various types of people to see what they notice that she doesn’t**: [On Looking: A Walker’s Guide to the Art of Observation](https://www.amazon.com/Looking-Walkers-Guide-Art-Observation/dp/1439191263) by Alexandra Horowitz | (amazon.com) [1:54:45]

- She also wrote: [Inside of a Dog: What Dogs See, Smell, and Know](https://www.amazon.com/gp/product/1416583432/ref=dbs_a_def_rwt_bibl_vppi_i0)

**Ryan says the way JFK handled the Bay of Pigs situation was much different (in a bad way) than he handed the Cuban Missile Crisis**: [Bay of Pigs Invasion](https://en.wikipedia.org/wiki/Bay_of_Pigs_Invasion) | (wikipedia.org) [1:57:15]

**Book that JFK read which may have influenced his approach to dealing with the Cuban Missile Crisis**: [The Guns of August](https://en.wikipedia.org/wiki/The_Guns_of_August) by Barbara Tuchman | (wikipedia.org) [1:57:45]

**Books series on Lyndon Johnson by Robert Caro that Ryan recommends**: [The Years of Lyndon Johnson](https://en.wikipedia.org/wiki/The_Years_of_Lyndon_Johnson) | (wikipedia.org)  [2:00:00]

**JFK cheated on his wife during the missile crisis**: [John F. Kennedy: Affairs, extramarital relationships and friendships](https://en.wikipedia.org/wiki/John_F._Kennedy#Affairs,_extramarital_relationships_and_friendships) | (wikipedia) [2:01:30]

**Seneca beautiful essay called “On Anger” (in english)**: [De Ira](https://en.wikipedia.org/wiki/De_Ira) | (wikipedia.org) [2:02:30]

**Ryan references a scene in the movie “Lincoln” where Abe Lincoln slams his fists in anger**: [Lincoln](https://en.wikipedia.org/wiki/Lincoln_(film)) | (wikipedia.org) [2:05:00]

**Ryan’s book about Peter Thiel’s quest to take down Gawker**: [Conspiracy: Peter Thiel, Hulk Hogan, Gawker, and the Anatomy of Intrigue](https://www.amazon.com/Conspiracy-Peter-Gawker-Anatomy-Intrigue/dp/0735217645/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Ryan Holiday | (amazon.com) [2:05:45]

**Tom Izzo losing his temper at a player**: [Michigan State players had to get between Tom Izzo and Aaron Henry during angry timeout](https://www.usatoday.com/story/sports/ftw/2019/03/21/tom-izzo-michigan-state-aaron-henry/39237113/) | Andy Nesbitt (usatoday.com) [2:09:45]

**How to follow Ryan’s work**: [2:12:00]

-Subscribed to his 2 newsletters:

- [Daily Stoic](https://dailystoic.com/)
- [Daily Dad](https://dailydad.com/)

-Social media

- [Twitter](https://twitter.com/ryanholiday/)
- [Instagram](https://www.instagram.com/ryanholiday/)
- [Facebook](https://www.facebook.com/ryanholiday)

§

## People Mentioned

- [Tom Catena](https://en.wikipedia.org/wiki/Tom_Catena) (doctor in South Sudan, previous [guest](https://peterattiamd.com/tomcatena/) on The Drive) [10:15]
- [Seneca](https://en.wikipedia.org/wiki/Seneca_the_Younger) [11:30, 16:15, 1:37:15, 2:02:30)
- [Marcus Aurelius](https://en.wikipedia.org/wiki/Marcus_Aurelius) [13:15, 49:20, 1:12:15, 2:04:45)
- [Zeno of Elea](https://en.wikipedia.org/wiki/Zeno_of_Elea) [16:30]
- [Socrates](https://en.wikipedia.org/wiki/Socrates) [16:30]
- [Cicero](https://en.wikipedia.org/wiki/Cicero) [16:45, 1:36:00]
- [Julius Caesar](https://en.wikipedia.org/wiki/Julius_Caesar) [16:45, 24:00, 54:00]
- [Cato](https://en.wikipedia.org/wiki/Cato_the_Younger) [16:45, 24:00]
- [Epictetus](https://en.wikipedia.org/wiki/Epictetus) [17:30, 26:45, 1:03:15]
- [Claudius](https://en.wikipedia.org/wiki/Claudius) [19:45]
- [Nero](https://en.wikipedia.org/wiki/Nero) [20:15]
- [John Kelly](https://en.wikipedia.org/wiki/John_F._Kelly) [22:30]
- [Donald Trump](https://en.wikipedia.org/wiki/Donald_Trump) [22:30, 53:00, 1:26:30]
- [Pompey](https://en.wikipedia.org/wiki/Pompey) [24:30]
- [Marcus Aemilius Lepidus](https://en.wikipedia.org/wiki/Marcus_Aemilius_Lepidus_(triumvir)) [24:30]
- [Dov Charney](https://en.wikipedia.org/wiki/Dov_Charney) (CEO of American Apparel) [32:00]
- [Robert Greene](https://en.wikipedia.org/wiki/Robert_Greene_(American_author)) (wrote The 48 Laws of Power) [29:00, 1:09:00]
- [Upton Sinclair](https://en.wikipedia.org/wiki/Upton_Sinclair) [35:00]
- [Kurt Vonnegut](https://en.wikipedia.org/wiki/Kurt_Vonnegut) [39:00]
- [Joseph Heller](https://en.wikipedia.org/wiki/Joseph_Heller) [39:15]
- [Tiger Woods](https://en.wikipedia.org/wiki/Tiger_Woods) [46:45, 1:12:00]
- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) [47:15]
- [Bill Belichick](https://en.wikipedia.org/wiki/Bill_Belichick) [47:15]
- [Tom Hanks](https://en.wikipedia.org/wiki/Tom_Hanks) [48:45]
- [Austin Kleon](https://twitter.com/austinkleon) (“art monsters”) [48:45]
- [Alexander the Great](https://en.wikipedia.org/wiki/Alexander_the_Great) [49:50]
- [Saddam Hussein](https://en.wikipedia.org/wiki/Saddam_Hussein) [54:00]
- [Vladamir Putin](https://en.wikipedia.org/wiki/Vladimir_Putin) [53:00]
- [Kanye West](https://en.wikipedia.org/wiki/Kanye_West) [55:15]
- [Steve Jobs](https://en.wikipedia.org/wiki/Steve_Jobs) [55:15]
- [Adam Neumann](https://en.wikipedia.org/wiki/Adam_Neumann) [56:15]
- [Travis Kalanick](https://en.wikipedia.org/wiki/Travis_Kalanick) (former CEO of Uber) [56:15]
- [Colin Powell](https://en.wikipedia.org/wiki/Colin_Powell) (making sure your ego is not associated with your position) [59:10]
- [Cyril Connolly](https://en.wikipedia.org/wiki/Cyril_Connolly) (“Ego sucks us down like the law of gravity.”) [1:02:30]
- [John Wheeler](https://en.wikipedia.org/wiki/John_Archibald_Wheeler) [1:03:15]
- [Bob Kaplan](https://twitter.com/bobkaplan?lang=en) [1:03:45]
- [Abe Lincoln](https://en.wikipedia.org/wiki/Abraham_Lincoln) [1:05:00]
- [Winston Churchill](https://en.wikipedia.org/wiki/Winston_Churchill) [1:07:30]
- [Dalai Lama](https://en.wikipedia.org/wiki/Dalai_Lama) [1:10:30]
- [John F. Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy) [1:12:00, 1:56:30]
- [Anne Frank](https://en.wikipedia.org/wiki/Anne_Frank) [1:12:00]
- [Sam Harris](https://twitter.com/SamHarrisOrg?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:14:45]
- [Jeff Warren](https://jeffwarren.org/) [1:15:00]
- [Bill Clinton](https://en.wikipedia.org/wiki/Bill_Clinton) [1:25:00, 1:59:00]
- [Hillary Clinton](https://en.wikipedia.org/wiki/Hillary_Clinton) [1:25:00]
- [Kayne West](https://en.wikipedia.org/wiki/Kanye_West) [1:25:00]
- [Elizabeth Holmes](https://en.wikipedia.org/wiki/Elizabeth_Holmes) [1:25:00]
- [Theodore Roosevelt](https://en.wikipedia.org/wiki/Theodore_Roosevelt) (“Comparison is the thief of joy.”) [1:27:15]
- [Joseph Epstein](https://en.wikipedia.org/wiki/Joseph_Epstein_(writer)) (“Of all the seven deadly sins envy is the only one that’s no fun.”) [1:27:15]
- [Blaise Pascal](https://en.wikipedia.org/wiki/Blaise_Pascal) [1:29:30]
- [Michel de Montaigne](https://en.wikipedia.org/wiki/Michel_de_Montaigne) [1:36:00]
- [Joan Rivers](https://en.wikipedia.org/wiki/Joan_Rivers) [1:38:00]
- [Alexandra Horowitz](https://alexandrahorowitz.net/) (On Looking book) [1:54:45]
- [Dwight D. Eisenhower](https://en.wikipedia.org/wiki/Dwight_D._Eisenhower) [1:57:30]
- [Barbara Tuchman](https://en.wikipedia.org/wiki/Barbara_W._Tuchman) (The Guns of August) [1:57:45]
- [Nikita Khrushchev](https://en.wikipedia.org/wiki/Nikita_Khrushchev) [1:58:20]
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) [1:59:00]
- [Lyndon Johnson](https://en.wikipedia.org/wiki/Lyndon_B._Johnson) [1:59:00]
- [Robert Caro](https://en.wikipedia.org/wiki/Robert_Caro) (book series on Lyndon Johnson) [2:00:00]
- [Peter Thiel](https://en.wikipedia.org/wiki/Peter_Thiel) [2:05:45]
- [Tom Izzo](https://en.wikipedia.org/wiki/Tom_Izzo) [2:09:45]

§

![](https://peterattiamd.com/wp-content/uploads/2020/01/Ryan-Holiday-bio-image-ryanholiday-450x500.png)

##### Ryan Holiday

Ryan Holiday is the bestselling author of [Stillness is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585), [Trust Me, I’m Lying](https://www.amazon.com/Trust-Me-Lying-Confessions-Manipulator/dp/1591846285), [The Obstacle Is the Way](https://www.amazon.com/Obstacle-Way-Timeless-Turning-Triumph/dp/1591846358), [Ego Is the Enemy](https://www.amazon.com/Ego-Enemy-Ryan-Holiday/dp/1591847818), [Conspiracy](https://www.amazon.com/Conspiracy-Peter-Gawker-Anatomy-Intrigue/dp/0735217645/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) and other books about marketing, culture, and the human condition. His work has been translated into over 30 languages and has appeared everywhere from the New York Times to Fast Company. His company, Brass Check, has advised companies such as Google, TASER, and Complex, as well as multiplatinum musicians and some of the biggest authors in the world. He lives in Austin, Texas.

Websites:

[Ryanholiday.net](https://ryanholiday.net/)

[DailyStoic.com](https://dailystoic.com/)

[DailyDad.com](https://dailydad.com/)