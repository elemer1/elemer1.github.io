# #179 – Jeremy Loenneke, Ph.D.: The science of blood flow restriction—benefits, uses, and what it teaches us about the relationship between muscle size and strength

**Source:** [https://peterattiamd.com/jeremyloenneke/](https://peterattiamd.com/jeremyloenneke/)

---

Jeremy Loenneke has a Ph.D. in exercise physiology, a Master’s in nutrition and exercise, and is currently the director of the Kevser Ermin Applied Physiology Laboratory at the University of Mississippi, where he focuses his research on skeletal muscle adaptations to exercise in combination with blood flow restriction (BFR). In this episode, Jeremy explains the science of BFR and the mechanisms by which BFR training can produce hypertrophy using low loads. Here, he reviews anatomy and terminology of muscle structure and discusses the evidence that increasing muscular strength may not be dependent on increasing muscle size. Additionally, Jeremy goes into depth on how one might take advantage of BFR training, including practical applications for athletes and average people, as well as the situations for which BFR training would be most advantageous.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/3m15T_4jVzE)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jeremyloenneke/the_Drive_public.png)

Play

#179 - Jeremy Loenneke, Ph.D.: The science of blood flow restriction—benefits, uses, and what it teaches us about the relationship between muscle size and strength

#179 - Jeremy Loenneke, Ph.D.: The science of blood flow restriction—benefits, uses, and what it teaches us about the relationship between muscle size and strength

1x15s30s

0:001:59:25

## We discuss:

- Jeremy’s interest in exercise and weightlifting and his scientific training [3:30];
- The microstructure and physiology of muscle [8:00];
- Definitions of fast-twitch and slow-twitch muscle fibers [12:45];
- Comparison of strength vs. hypertrophy [21:30];
- Blood flow restriction training and the origins of the Kaatsu system [28:30];
- The details and metrics related to exercise under blood flow restriction [44:45];
- Considerations when training with blood flow restriction: loading, pace, rest, and risks [53:00];
- Blood flow restriction studies and the relationship between muscle size and muscle strength [1:04:15];
- Evidence that increasing muscular strength is not dependent on increasing the size of the muscle [1:16:30];
- Practical applications of blood flow restriction training for athletes and average people [1:27:30];
- Situations in which blood flow restriction training is most advantageous [1:35:30];
- The mechanisms by which blood flow restriction training can produce so much hypertrophy at such low loads [1:39:45];
- Applications of “passive” blood flow restriction training [1:47:15];
- What experiments would Jeremy do if he had unlimited resources? [1:51:45];
- More.

§

## Show Notes

**Pre-show notes**

- Jeremy is the Director of an applied physiology laboratory and his research focuses on skeletal muscle adaptations to exercise in combination with blood flow restriction
- Peter first tried blood flow restriction a little over 10 years ago, in a swimming pool
- [Blood flow restriction](https://en.wikipedia.org/wiki/Blood_flow_restriction_training) is a general term that applies to occluding some portion of the arterial inflow to a muscle
  - Under these conditions, it becomes harder for the muscle to contract
  - This allows an individual to exercise with a lower weight than they would normally use
- The most common term associated with this from a brand perspective is [Kaatsu](https://en.wikipedia.org/wiki/Kaatsu), which is Japanese for training with a restriction
- Peter remarks that one of the most interesting things that comes out of this discussion, “is that blood flow restriction offers a very cool way to study the relationship between muscle size and muscle strength”
- This episode will explain the physiology of the sarcomere, the microanatomy of muscle fibers, the difference between type two and type one fibers
  - It will explain what an actin filament is and what a myosin filament is

## Jeremy’s interest in exercise and weightlifting and his scientific training [3:30]

**Jeremy’s interest in exercise**

- - He was into wrestling from age 5 through high school
  - He didn’t lift weights then or do any conditioning, but his coaches continually told him to get in the gym to get stronger
    - He started listening toward the end of high school
  - One of his friends was into bodybuilding and powerlifting; Jeremy started training with him
    - It helped a little with wrestling
  - He began reading muscle magazines and focused on exercise  science early on in undergrad

- *He wanted to know how to make a muscle bigger, how to make it stronger*

**Jeremy’s scientific training**

- At first he wanted to work with athletes, but upon trying it, he didn’t like it and turned to research
  - He had a mindset that everybody was going to train and train hard and he found a mismatch between his expectations the athletes he worked with
- He landed at the University of Illinois and that’s where he met Lane and a couple of other people
  - That’s where he really came came across blood flow restriction and focus his time on this; this was around 2007-2008
  - He got into human research
- He did his PhD at the University of Oklahoma
  - His dissertation focused on different methods of applying blood flow restriction?
    - He evaluated the acute response of different exercise loads of 20%, 30%, under different pressures
- He took a job at [Ole Miss](https://hesrm.olemiss.edu/people/jeremy-paul-loenneke/), The University of Mississippi

## The microstructure and physiology of muscle [8:00]

**The anatomy of a muscle**

- Muscles are made of tubular fibers called [myofibrils](https://en.wikipedia.org/wiki/Myofibril), shown in the figure below
- The smallest unit is a [sarcomere](https://en.wikipedia.org/wiki/Sarcomere)
  - This is the repeating unit between 2 *Z-lines* (aka Z discs)
  - Myofibrils are composed of repeating units of sarcomeres
  - Sarcomeres are made up of alternating thin and thick filaments
    - *The thin filaments are made of actin,* shown in green below
    - *The thick filaments are made of myosin*, shown in purple below
  - [Actin](https://en.wikipedia.org/wiki/Actin) and [myosin](https://en.wikipedia.org/wiki/Myosin) are both proteins
    - Exercise results in the production of more actin and myosin
    - Muscle will get bigger when more actin and myosin is made than is broken down
  - Actin and myosin interact to cause muscle contraction; this happens during exercise
    - Contraction results in signaling for muscle adaptation

![](https://peterattiamd.com/wp-content/uploads/2021/10/f1-jeremyL.jpeg)

**Figure 1.** Anatomy of a skeletal muscle fiber. Image credit: [OpenStax Anatomy and  Physiology](https://openstax.org/books/anatomy-and-physiology/pages/10-2-skeletal-muscle#fig-ch10_02_02).

**\*Here’s a review of muscle anatomy**: [Skeletal Muscle Structure](https://youtu.be/XoP1diaXVCI) | GreatPacificMedia (October 4, 2009) (youtube.com) | [8:00]

**There are 2 broad types of muscle, endurance based and force based**

- [Muscle fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types) fall into 1 of 3 categories

1. Type I: slow twitch speed, small force, highest resistance to fatigue
   1. Also called SO for slow oxidative fibers
   2. They generate energy by [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation) using [mitochondria](https://en.wikipedia.org/wiki/Mitochondrion) to perform [aerobic respiration](https://en.wikipedia.org/wiki/Cellular_respiration#Aerobic_respiration)
   3. Used for endurance exercise
2. Type IIA: fast twitch speed, medium force, some resistance to fatigue but less than type I
   1. Also called FOG for fast oxidative/glycolytic; or or FO fast oxidative
   2. They generate energy using aerobic respiration but may switch to [anaerobic respiration](https://openstax.org/books/anatomy-and-physiology/pages/24-2-carbohydrate-metabolism) (which produces [lactate](https://en.wikipedia.org/wiki/Lactic_acid#Exercise_and_lactate))
3. Type IIX: fast twitch speed largest twitch force, low resistance to fatigue (fatigue easily)
   1. Also called FG for fast glycolytic
   2. They generate energy using anaerobic respiration
   3. Used for high resistance exercise such a lifting heavy weights

- In reality, muscle exists on a continuum between high endurance and high force capabilities
- Exercise can shift muscle to a different type
- Generally, exercise shifts the overall muscle fiber to become slower, more oxidative, and more efficient
- The sarcomere is composed of fibers bordered by [Z-lines](https://openstax.org/books/anatomy-and-physiology/pages/10-2-skeletal-muscle?query=sarcomere%20z-lines&target=%7B%22type%22%3A%22search%22%2C%22index%22%3A0%7D#fs-id2044502), labeled as a Z disc in the previous figure

**What happens during muscle contraction**

![](https://peterattiamd.com/wp-content/uploads/2021/10/f2-jeremyL-777x1024.jpeg)

**Figure 2. Signaling by a nerve initiates muscle contraction.** Image Credit: [OpenStax Anatomy and Physiology](https://openstax.org/books/anatomy-and-physiology/pages/10-2-skeletal-muscle#fig-ch10_02_03)

- When one decides to exercise, a signal goes from the nerve to the muscle; see the previous figure
  - There is a release of calcium
  - This calcium will expose binding sites
  - During [muscle contraction](https://en.wikipedia.org/wiki/Muscle_contraction#Cross-bridge_cycle), filaments slide past each other; shown in the next figure
    - Myosin (in purple) interacts with actin (in green) to cause this movement
    - Myosin has 2 heads; it will bind both actin and ATP
    - ATP is required to break the bond between myosin and actin
    - ATP is hydrolyzed to recock the myosin head then reattach to actin; this requires more calcium
  - As long as calcium is president, or as long as signals for movement are being sent, the actin and myosin in sarcomeres will keep interacting producing muscle contraction
    - The actin and myosin don’t all interact at the same time; they each interact at different times to produce fluid motion

![](https://peterattiamd.com/wp-content/uploads/2021/10/f3-jeremyL-660x1024.jpeg)

**Figure 3. Sliding filament model of muscle contraction.**  Image credit: [OpenStax Anatomy and Physiology](https://openstax.org/books/anatomy-and-physiology/pages/10-3-muscle-fiber-contraction-and-relaxation#fig-ch10_03_03)

- Peter notes that ATP is required to release the actin-myosin complex, and this explains rigor mortis
  - A dead person cannot make ATP; they don’t have the ability to release the actin myosin filaments
    - This is why a body gets stiff
- There is a continuum of [muscle fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types); the terms fast twitch and slow twitch are used
  - The faster twitch muscle has a higher contractile force, but it fatigues quickly

## Definitions of fast-twitch and slow-twitch muscle fibers [12:45]

**Clarify fast twitch and slow twitch muscle fibers**

- *Do they all twitch at the same speed?*

- *Faster muscle fibers have a higher contractile force but fatigues quickly*

- *Is the difference in muscle types a difference in the neurologic signal or difference in the speed of contraction?*

- The work of [Andy Galpin](https://hhd.fullerton.edu/knes/facultystaff/AndyGalpin.php) and others addresses this question
  - Review article from 2020 [Moving human muscle physiology research forward: an evaluation of fiber type-specific protein research methodologies](https://pubmed.ncbi.nlm.nih.gov/32783659/)
  - Old methods of studying this have limits
  - Studies depend on how the fibers are actually identified and the methodology

**More on classifying muscle fibers**

- An explanation of the types of muscle fibers is summarized in the book [Skeletal Muscle: Form and Function](https://www.google.com/books/edition/Skeletal_Muscle/-EfxEhSFaMYC?hl=en&gbpv=1&dq=muscle%20fibers%20IIab%20IIx&pg=PA187&printsec=frontcover&bsq=muscle%20fibers%20IIab%20IIx)
- Muscle fiber types are classified according to the myosin heavy chain  isoforms ([MHC](https://en.wikipedia.org/wiki/Myosin)) they contain; this can be type I, IIA, IIB, and IIX
  - I or II designates the fiber type
  - They have different physiologic and staining properties, classified into [3 major groups](https://emedicine.medscape.com/article/1141359-overview#a2):

1. *Type I* are slow twitch, produce the smallest force, and are resistant to fatigue
2. *Type IIA* are fast twitch, produce a larger force, and are resistant to fatigue
3. *Type IIX* (aka Type IIB) are fast twitch, produce the largest force, and are easily fatigued

- A, B, or X designates the myosin heavy chain isoform

- In general, type IIX are bigger and stronger, but fatigue much faster
- Type IIA are more oxidative, they’re forceful and can sustain contraction for longer
- Exercise causes type IIX to transition to type IIA; there’s not a lot of type IIX leftover
- Type I fibers are a little slower and not as forceful, but they don’t fatigue easily

**Differences in contractile strength between a type I and type IIX fiber**

- The type I fiber has lots of mitochondria surrounding the myofibrils within the sarcomere
  - It can readily access energy via oxidation of glucose and fatty acids using aerobic respiration
- The type IIX fiber lacks mitochondria surrounding it
  - It’s restricted to anaerobic respiration, converting glucose to lactate using anaerobic glycolysis

*What accounts mechanically for the difference between these 2 fibers?*

- Most people would say the overall size difference
  - In young people, the size of the fiber is distinctly different
  - Fiber mechanics are different and how they interact within the body is also important

**Is the capacity for aerobic work versus explosive strength (anaerobic work) genetically set?**

- This is difficult to determine because may studies extrapolate from small bits of fibers
- Athletes thought to have some of the greatest endurance capacities are cross-country skiers.
  - Many of them have a predominance of type I fibers
    - The question is, were they born this way (and that’s why they gravitated to this sport) or was there a shift in fiber type with training; it’s probably both
- There probably is a large genetic component to both the baseline amount of fiber types and also the body’s response to exercise

**How does training impact fiber type?**

- Consider a wiry person who can’t put on muscle no matter what they do, but get them out on a bike and you can’t catch them
- Some, but training won’t take an average athlete and make them an elite athlete
  - One could move up a few notches
- The tools are lacking to discriminate individuals who are highly responsive to training and those that are not

## Comparison of strength vs. hypertrophy [21:30]

- Exercise causes a muscle to get bigger
- Measure one’s biceps crudely with a tape measure or more more accurately with an MRI or ultrasound; then compare the size after 6 months of prescribed exercises

**Why does the muscle get bigger after exercise?  What happened in that cycle of hypertrophy?**

- There could be an increase in fiber size, this is [hypertrophy](https://openstax.org/books/anatomy-and-physiology/pages/10-3-muscle-fiber-contraction-and-relaxation?query=hypertrophy&target=%7B%22index%22%3A0%2C%22type%22%3A%22search%22%7D#fs-id1725236)
  - The muscle cells themselves increase in size
- The number of cells in the muscle could also increase, this is [hyperplasia](https://openstax.org/books/anatomy-and-physiology/pages/10-8-smooth-muscle?query=hyperplasia&target=%7B%22type%22%3A%22search%22%2C%22index%22%3A0%7D#fs-id2166530)
  - Hyperplasia is not thought to play a big role in increased muscle size in adults
  - We can’t rule it out, but there isn’t much evidence for it
- Changes in muscle size are thought to be due to hypertrophy; increased cell size
  - It’s assumed this increase in cell size is due to increased overall protein (actin, myosin, etc.) and other components that help support the cell
- Peter notes that muscle cells are unique in this characteristic of changing in size
  - Other cells don’t do this
  - A Dermatologist looking at moles, biopsies them don’t really look at the cell size
    - Concern in this scenario would be if hyperplasia, [metaplasia](https://en.wikipedia.org/wiki/Metaplasia), or [dysplasia](https://en.wikipedia.org/wiki/Dysplasia) were observed

*Does the actin and myosin complex change in size or if there are simply more of these proteins?*

- Short-term measures of protein synthesis show more overall actin and myosin, along with other things

**Strength**

- - There is mechanical strength and neurologic strength
  - If one measures the ability to do a bicep curl, there’ll be 2 measurements
    - The maximum weight lifted in a single rep (single rep max)
    - The maximum weight lifted a set number of times (measure of endurance)
  - For example, someone does the same exercises over 6 months and sees a 20% increase in the weight used for a single rep max and and 15% increase in the amount of weight moved 10 times; *explain what happened for this strength change*
    - The initial change in strength is thought to be due to *neurological changes*
      - The signal sent from the brain, through the spinal cord, to the alpha motor neuron
        - The alpha motor neuron is the nerve that communicates with the muscle
        - There could be changes anywhere in this pathway

- *With more excitatory input there is less inhibition; the thresholds that makes it easier to fire the type II fiber is lowered*

- - After 3-4 weeks of training, the muscle get bigger; *the change in fiber size will also contribute to a change in strength*

- *This is something Jeremy’s work has taken some exception to*

- - - Publication: [Is muscle growth a mechanism for increasing strength](https://pubmed.ncbi.nlm.nih.gov/30902152/) (Loenneke *et al.* 2019)
- Peter relates the common dogma that muscle size relates to strength because the size increase comes from more actin and myosin; so with more contractile units, strength increases

**Jeremy’s work calls this dogma into question**

- There is a neural component to increases in strength but also changes at the local level that can explain changes in strength
  - There may be changes at the myosin head or changes in calcium release that occur when strength is increased
    - There isn’t any good evidence for this yet, but this is his idea behind why someone may get stronger following exercise

## Blood flow restriction training and the origins of the Kaatsu system [28:30]

**Peter’s experience with blood flow restriction exercise**

- He used to swim a lot, 10 year ago his friend [Steve Munatones](https://www.linkedin.com/in/munatones) (a world-class marathon swimmer) visited him for a swim workout; after the workout Steve brought out these [Kaatsu bands](https://kaatsu.com/) and asked Peter to put them on his thighs, upper thighs, arms, and upper arms for compression
- Steve had what looked like a blood pressure cuff that he could use to calibrate the occlusive pressure
- He asked Peter to to swim a 50 yard butterfly all out
  - A request that is challenging under any circumstances but doable; he could do a set of 10 50’s at 90% with 45 seconds in between and be fine
  - Peter remembers this being the hardest thing he has ever done; it felt harder than swimming 200 yards of butterfly; he felt like he was going to die
  - This piqued his curiosity with this technique but he didn’t have the equipment and forgot about the technique until recently

**Origin of the Kaatsu system**

- Yoshiaki Sato came up with the [Kaatsu system](https://en.wikipedia.org/wiki/Kaatsu)
- Legend has it that Yoshiaki was kneeling at a Buddhist ceremony and felt a little numbness, a sensation similar to what he felt doing heavy squats, and he thought there could be some connection there
  - Kneeling was restricting his blood flow
- He was interested in bodybuilding
- This led him to begin experimenting with different ways to restrict blood flow in his lower body and upper body
- Some stories day he actually harmed himself a little because he was maybe applying it too tightly
- He had a skiing accident and used blood flow restriction during his rehab and saw what he thought was pretty good gains
- Ultimately, he found that one can use very light weights (low loads) that make it feel like lifting very, very heavy weights
  - This is obviously useful if someone had a skiing accident or doesn’t want to lift heavy weights because of some sort of injury
- Research on blood flow restriction and exercise began to be published in the  late ’90s, early 2000s
- Peter relates the experience of one of his patient’s last year who had a complete tear in his bicep, underwent surgical repair, and used blood flow restriction during the rehab phase
  - The patient wanted to get back to training sooner so was open to this technique
  - His recovery was remarkable and it piqued Peter’s curiosity
- The term KAATSU is synonymous with blood flow restriction, and it’s Japanese for training with increasing pressure
  - More accurately, it’s a brand of apparatus used for this technique

**How was this hypothesis tested, that blood flow restriction while training will produce improved results?**

- - Shinohara published the first [paper in 1998](https://pubmed.ncbi.nlm.nih.gov/9459541/); they had subjects do leg exercises with blood flow restriction on one leg but not the other; greater change was observed in the limb with blood flow restriction
    - This was 30 years after Sato began experimenting with this stuff in Japan
  - The idea of blood flow restriction is to reduce blood flow going into the limb but not completely occlude blood flow
  - There is a tremendous amount of variability in how the pressure was applied early on
    - Early studies would take a cuff and apply the same pressure to every single person, independent of their blood pressure or limb size or cuff size (these are all important factors)
  - The current method is to begin by taking the cuff up to the lowest pressure for which there is no blood flow at all; then change the pressure to a percentage of that
    - This ensures some blood flow during exercise
    - One could use ultrasound, use a handheld Doppler Probe that’s essentially detecting the pulse to determine the pressure at which there is no blood flow (**arterial occlusion pressure** or AOP)
      - Take for example the ankle; before doing any exercise, the patient simply lies down, the cuff is slowly inflated until blood flow isn’t heard; note the pressure and take a percentage of it
        - If the arterial occlusion pressure measured is 100 [mmHg](https://en.wikipedia.org/wiki/Pulse_pressure), then typically use anywhere between 40-80 mmHg

- *The AOP is the lowest pressure for which there is no blood flow*

**The cuff size used for blood flow restriction matters; it will change the pressure**

- Pressure and force are related by the area that the cuff takes up; so the wider the cuff, the lower the pressure needed to reach occlusion
- Some think a wider cuff is better because a lower pressure can be used, but this is not true; it’s all relative
- If the AOP is 100 mmHg, then 40-80% of this is a wide range
  - Exercising at 40 mmHg versus 80 mmHG may be the difference  between comfort and discomfort

> “40%, that’s the pressure that we use when all we care about is muscle adaptations. In other words, increasing muscle size and strength. Now, you can see the same adaptation at 80% with a little bit less work because you’re going to fail sooner, but the discomfort is going to be much higher.” – Jeremy Loenneke

- - Jeremy’s preliminary data suggests that some vascular changes may require a pressure higher than 40%; but this is just 1 study; it did observed this effect in both the upper and lower body

- *Using a moderate pressure (40%) or a high pressure (80-90%) will give pretty much the same changes in muscle size and strength; the discomfort will be quite different*

**What is the variability between individuals for tolerance of discomfort at a fixed occlusive pressure?**

- “What would the [bell curve](https://en.wikipedia.org/wiki/Normal_distribution) look like? How tight would it be for the time at which a person cries uncle?”
  - [Blood Flow Restricted Exercise and Discomfort: A Review](https://pubmed.ncbi.nlm.nih.gov/32058360/) (2020)
- Discomfort studies applying 40% AOP and having people simply sit show a low variability from person to person; the study stopped at 4 minutes and everyone could do the exercise
  - Some people are going to experience that as more discomfort than other people
  - This doesn’t necessarily mean the blood flow is reduced by 40% either; that is different
  - The blood flow may differ from person to person depending on how big the muscle is and a variety of other things
  - There are some people who perceive almost everything as extreme discomfort; the discomfort they feel at 40 is not different than it is at 80 because they already rated it so high; there are people on the opposite side who rate the discomfort low too
    - That’s a limitation of the discomfort scale

## The details and metrics related to exercise under blood flow restriction [44:45]

**How much of the arterial flow of blood occurs at 40% AOP? How much venous pooling occurs?**

- Jeremy doesn’t know that off the top of his head; it isn’t 40%; on average it’s a bit lower
  - It also depends upon the position and exercise
- Venous occlusion probably occurs because the thought is, it doesn’t take a lot of pressure to collapse the vein
  - During exercise the blood is pumping back out with the muscle pump
  - At rest there is usually venous pooling
- Peter did a workout with a set of leg presses
  - 30 reps, rest 30 seconds, then 15 reps, rest 30 seconds, 15, rest 30 seconds, 15
  - He’s not sure what hurt worse, the 30 seconds in between or the last 2 sets

> “The whole thing was just so wildly uncomfortable” – Peter Attia

- But he’s flying by the seat of his pants because this is not based on occlusive pressure (AOP); so he doesn’t know how far off he is
- Jeremy has already convinced him that he should be more scientific in my approach

- - Jeremy agrees that Peter’s workout is tough; even stronger subjects are going to be at failure with this number of reps (30, 15, 15, 15 reps)
    - In his experiments, he has people exercise 4 sets at as many repetitions as they can; this controls for effort

- *The number of repetitions can be used as a weak surrogate of blood flow restriction*

- - - - At 20-30% one should get close to 30 repetitions on the first set then maybe 12-15 reps on the second set
        - If one cannot achieve 30 reps on the first set, then the load is probably too high or the wraps are too tight
    - If there is pain before exercising, then it’s too tight
    - **In practical use of restriction**, he uses a knee wrap; he doesn’t know how much pressure is being applied
    - **In a clinical setting or for rehabilitation**, it’s important to know what pressure is being applied

- *For a healthy person going to the gym, knowing the pressure is not that important*

- - - In this discussion, if the load is low and one is in pain after applying the wraps, then the wraps are too tight
      - Loosen the wraps and one should get close to 30 reps on the first set, then close to 15 reps on the last 3 sets
      - This will depend on strength; one might fail pretty quick in the 4th set

- *The number of repetitions can provide some idea of the level of blood flow restriction being applied*

**What would be the maximum amount of time a subject should work under pressure, at 40% occlusive pressure (considering the combined lift and recovery period)**

- This depends if they are resistance training or are they doing low-intensity aerobic exercise
  - *For low-intensity aerobic exercise*, one can probably keep it on for 30 or 40 minutes; there shouldn’t be much discomfort at low intensity
    - The cuffs are not all that tight
    - One is not building up a tremendous amount of metabolites
    - This is probably not providing a tremendous amount adaptation either
  - *For resistance exercise*, just starting out, 7-10 minutes is a good place to start
    - Don’t leave the cuffs on for more than a few exercises
    - When one is just starting out, don’t go beyond 1 exercise
- In his studies with people who are untrained, performing multiple exercises is pretty tough
- He suggests beginning with 4 sets of an exercise, then take the cuffs or wrap off

**What other metrics could people use if they don’t have access to a Doppler to determine the pressure?**

- *Systolic blood pressure is not always the same as occlusive pressure*

- - - If the size of the cuffs are similar (for both applying pressure and measuring systolic blood pressure) then systolic blood pressure could be used as a basis for determining % pressure

- *For the average gym-goer, it’s simpler to apply the wrap as a percentage of resting limb size*

- - - There is some data on this working with people who come into the clinic to learn exercises to do at home; in the clinic a device is used to set the occlusive pressure to 40%; they are told to mimic this pressure at home
      - Some are successful but this can vary between 20-50% AOP; not terrible but also not great
    - This idea was based on a paper a long time ago that said the pressure should rate a 7 out of 10 to be sure it is subocclusive
      - The range for this is huge; one day a person may be at 90% AOP and the next day the same feeling might be 10% AOP
      - This scale isn’t recommended anymore

- *When conditioning is the goal, use a percentage of resting circumference and then use repetitions as a guide*

- Peter doesn’t have nice cuffs, but the thing he likes is they have numbers on them; this gives him a sense of how tight to wrap them

## Considerations when training with blood flow restriction: loading, pace, rest, and risks [53:00]

**Weight**

- Choose a weight that is 20-30% of a 1-rep maximum weight
- The utility is the ability to use blood flow restriction (BFR) with very low loads
- He’s tried combining  BFR with high loads but the benefits are not additive; *BFR doesn’t add anything to use a high load over a low load*
  - High load exercise is a maximum stimulus; it’s hard to maximize something that’s already pretty much maximal in a given training session
  - If one wants to lift with heavy weights, then just do that; but *the utility of BFR is that lower loads can be used to achieve results*

**Pacing**

- - The slower the pace of exercise, the less repetition one is going to be able to do; this probably doesn’t matter too much overall for growth

- *He typically uses a 1 second up 1 second down pace*

- - This is a nice, controlled movement
- Some people use 1.5 seconds
- Peter asks if what matters most is time under tension; so slower pace and fewer reps are still okay
  - Yes; when Jeremy thinks about a muscle growing it needs to be activated for a sufficient length of time to get all of those signaling pathways turned on; there’s many ways for this to occur
    - One can use really, really heavy weights repeatedly
    - One can use low loads or a very slow pace
    - Both of these are recruiting more and more fibers, activating them, and signaling them to grow; both approaches should accomplish the same thing

**Rest**

- *Jeremy generally uses 30 second rest intervals*

- This works well especially if one is targeting a muscle that’s necessarily directly under blood flow restriction
  - For example the chest
  - Some data support doing a standard bench press exercise with blood flow restriction around the arms to augment the size of the chest
    - Muscles distal to the cuff (the triceps) are fatiguing and the chest is picking up the load
    - In the gym, he likes to experiment with that; so do some chest and then superset with some tricep extensions or something like that; but this hasn’t been studied in the lab

**What about doing complex, multi-joint movements under restriction?**

- Data looking at bench press, squat, and they have seen some benefits assuming use of light weights
- He prefers isolation movements, especially if the goal is growth
- He thinks the success would vary depending on the movement
- One can do compounds, there is evidence that suggests it can help with the squat, help with the barbell bench press
- He tenda to use isolation movements and for research purposes
- He feels better, safer doing isolation types of exercises

**Risks**

- - Peter asks if he is worried about [rhabdo](https://en.wikipedia.org/wiki/Rhabdomyolysis), or nerve damage
  - First, it helps to understand that this is a very acute response
    - Blood flow is restricted for minutes not hours
  - The safety profile overall is comparable to that of high load exercise or traditional exercise
  - Two common concerns are blood clotting and muscle damage
    - Everything carries with it a risk

- *Blood flow restriction does not appear to increase the risk of blood clots or muscle damage*

- - - One will be sore after performing exercise under blood flow restriction, but when one looks at the muscle fiber it appears to be intact; there does not appear to be structural damage
  - Have [CK levels](https://medlineplus.gov/lab-tests/creatine-kinase/) been measured to compare muscle damage with and without restriction?

- *There is not a whole lot of difference in CK levels between the same exercise without blood flow restriction*

- - - There is certainly soreness but not structural damage
  - What is the blood pressure response proximal to the cuff when exercising?  Is blood pressure going up centrally in the heart, the aorta, the brain?
    - Compared to the same exercise without blood flow restriction, blood pressure is usually higher but comparable to (or even a little lower) than high load exercise
    - How high does blood pressure get and how quickly does it return back to baseline

- *Compared to high load exercise, blood pressure is similar and usually comes back down to baseline within five minutes in healthy individuals*

- - - Certain populations may hyper-respond, so that is something to consider
  - Peter notes in his experience, when he does unrestricted heavy movements (so five to eight reps of deadlifts or something where he’s really going for it) it feels like he has a much higher blood pressure than the blood pressure he feels when exercising under BFR
    - With BFR exercise he’s never got the feeling like his head’s going to pop off his shoulders, which he commonly feels when doing a heavy deadlift

> “But I would say that overall, it does appear to be very safe” – Jeremy Loenneke

- In the studies that have been done, it appears to be relatively safe
  - As with anything, for example, when giving a drug in a large clinical trial, one will start to see some side effects that were never seen before
  - He expects that when it becomes more and more popular, there will be certain rare events that have never seen before

## Blood flow restriction studies and the relationship between muscle size and muscle strength [1:04:15]

**Comparing exercise of one arm under blood flow restriction to the other arm without restriction**

- - Comparing exercise using the same exercise, same weights, same number of reps, same rest, in the same individual where one arm is subject to blood flow restriction and the other arm is not restricted
    - [Shinohara](https://pubmed.ncbi.nlm.nih.gov/9459541/) did some of these experiments
    - The criticism on within subject studies is with respect to strength, not necessarily muscle growth because it has been observed that when training one side but not the other, the other arm often increases in strength; Jeremy is not sure this happens when both limbs are trained

- *Jeremy thinks the limbs respond to the local training*

- - Does the limb under blood flow restriction show gains in strength and/or size as compared to the other, unrestricted limb performing the same exercise

- *Yes, limbs trained under BFR show gains in strength and size*

- - - Jeremy notes that the response in the blood flow restriction subject will be better than a work-matched control, even if it’s the same person
      - With the caveat that exercise is not done to failure; this is difficult because even at 30% AOP (arterial occlusion pressure) some people will be reaching failure during 4 sets in the non-occluded arm

- *When training one limb to failure and the other limb with BFR to failure, the adaptation observed is pretty similar; but the exercise volume needed is much lower with the blood flow restricted limb*

> “blood flow restriction by itself, so just the application of restriction and deflation, in some ACL reconstruction post-surgery environment has shown to have some sort of benefit” – Jeremy Loenneke

- Even if people walk very slowly under blood flow restriction (not even close to failure) there appears to be some adaptation, though not as much as seen with resistance exercise

- *With resistance exercise, it might be fair to say that blood flow occlusion is causing more of the muscle to activate sooner (and then fatigue sooner) than under a non-occluded condition*

- - Blood flow restriction is just a tool to increase the time to failure and therefore act as a more efficient means to fatigue the various fibers
  - All of the benefits of blood flow restriction are not known

**The relationship between strength and hypertrophy**

- Conventional wisdom is that once muscle growth is there, it is probably contributing to changes in strength
  - Neural changes occur first followed by large contributions from [muscle hypertrophy](https://en.wikipedia.org/wiki/Muscle_hypertrophy)

> “I started to really see that maybe that’s actually not the case because we almost always see muscle growth which is similar to or equivalent to that of highload exercise, but the strength (assuming that we’re not practicing the test repeatedly) is almost always less.” – Jeremy Loenneke

- - Jeremy has done research in the low load realm and has begun to see that perhaps muscle hypertrophy does not increase strength

- *He almost always see muscle growth which is similar to or equivalent to that of high load exercise, but the strength (assuming that we’re not practicing the test repeatedly) is almost always less*

- - He began to question “where did this story come from about muscle growth playing a role [in strength], and why do we even think it in the first place”
    - This is where it really becomes difficult for people to have this conversation because everybody has learned this paradigm

- - He thinks if one compared a bunch of people and measured muscle size and strength, on average it would be true that people who are bigger would be stronger, people who are smaller would be weaker

- *But that’s not an effect of exercise because the same relationship is seen in people who have never exercised in their life*

- - The correlation or association between strength and size is equally strong in the untrained as it is in the trained

**The question here is,** ***when a person begins to exercise and then they get stronger, is that due to changes in muscle size?***

>  “Okay. But were those studies ever able to actually make that claim?” – Jeremy Loenneke

- - He doesn’t question if they are related

- *Does a change in one result in a change in the other?*

- - It makes sense that it would, actin (protein) is increasing so why would this not produce increased strength
  - However, there are numerous times in the literature where greater changes in muscle size occur but strength doesn’t change

> “So that leads me to believe that there could be quite a bit of disconnect with respect to muscle growth and the change in strength.” – Jeremy Loenneke

**Publications establishing the current paradigm linking increased muscle hypertrophy to increased strength**

- - Jeremy wrote a [review](https://pubmed.ncbi.nlm.nih.gov/30902152/) trying to go back to the root of this dogma
    - He found there were 3 papers (mentioned below) that formulated this *viewpoint that neural changes occur first, followed by hypertrophy*
  - One [paper](https://pubmed.ncbi.nlm.nih.gov/453338/) commonly cited studied 5 individuals where one arm lifted weights and the other arm did no work
    - They inferred muscle growth off changes in the slope of integrated [EMG](https://en.wikipedia.org/wiki/Electromyography)
      - If they saw a change in slope, they inferred it to mean muscle growth
      - *In Jeremy’s opinion:* one cannot infer growth off a change in EMG
      - The EMG amplitude is essentially an estimate of muscle [action potential](https://en.wikipedia.org/wiki/Action_potential)
      - To explain what they were doing, pick a variety of weights (10 lbs, 20 lbs, 30 lbs, etc) and measure the EMG amplitude when a subject lifts each weight, and they would repeat this measurement every couple weeks
        - So if the subject lifted 10 lbs and the amplitude was a little less, they would infer muscle growth
        - They are using the amplitude to assess the neurologic signal and over time if the neurologic signal goes down while the effort remains the same, they assume hypertrophy (muscle growth) makes up the difference

- *One point Jeremy likes to make is*: this guarantees that at some point, hypertrophy is going to be a mechanism; they’re not actually testing a mechanism; they’re just assuming that at some point it will be a mechanism

- - - They did measure arm circumference, but that was not the variable used to quantify growth
  - The other commonly cited study is by [Ikai and Fukunaga](https://pubmed.ncbi.nlm.nih.gov/5425330/); they actually measure muscle size

- *To his knowledge, this is the first study to document changes in muscle size in response to resistance exercise – a landmark paper*

- - - They infer that if muscle growth changes, then it must be playing a role; and if muscle growth doesn’t change when subjects got stronger, then it must be neutral – this has been the paradigm ever since
      - For example, if he runs a training study and the subjects get stronger but no change in muscle size is observed, they would conclude neural changes are at work
      - Similarly, in this study, if the subjects got stronger and changes in muscle size were measured then they would conclude that both neural changes and hypertrophy are responsible for increasing strength
      - *Jeremy thinks there is a fallacy in making this claim:*  this logic assumes that the ability to document something (hypertrophy) thereby attributes it as a reason for increasing strength
        - This logic makes intuitive sense but he would like to see it more rigorously tested
  - Historically the link between muscle hypertrophy and strength comes from these 2 studies and reviews by [Digby Sale](https://experts.mcmaster.ca/display/saled)
    - Ikai and Fukunaga’s 1970 publication, [A study on training effect on strength per unit cross-sectional area of muscle by means of ultrasonic measurement](https://pubmed.ncbi.nlm.nih.gov/5425330/)
    - Mortani and deVries 1979 publication,  [*Neural factors versus hypertrophy in the time course of muscle strength gain*](https://pubmed.ncbi.nlm.nih.gov/453338/)
    - Sale’s review in 1982, [Physiology of weight-lifting exercise](https://pubmed.ncbi.nlm.nih.gov/7073463/)
    - Sale’s review in 1988, [Neural adaptation to resistance training](https://pubmed.ncbi.nlm.nih.gov/3057313/)
      - Sale suggests that most training studies are only documenting a certain aspect of the actual person’s training age; they’re never going to be able to actually answer this question because the studies are too short
      - *Jeremy questions this* because the study by Moritani and deVries used 8 weeks, and this is the same duration as a lot of other studies that have contradicted this paradigm of hypertrophy resulting in increasing strength

- *Theses studies are the basis for the idea that strength comes from neural changes followed by hypertrophy*

## Evidence that increasing muscular strength is not dependent on increasing the size of the muscle [1:16:30]

- - Peter notes that blood flow restriction seems to provide an elegant tool to test this hypothesis, but *what other experiments could test this without blood flow restriction?*
    - Could someone do workouts where they only do 1-5 reps of an exercise; they’re basically always working to failure, whether it’s 1 rep max or 2 reps or 3 reps
    - For example, he knows athletes who try to maximize strength and minimize hypertrophy
      - Runners, for example, want to maximize the strength to weight ratio; *they want to add strength without adding size*
      - They train with a trap bar, they do not do the eccentric motion; they lift the weight up and drop it, lift the weight up and drop it; and they’re never going above five reps
    - The opposite workout would be more of a bodybuilding workout

- *Peter asks if these 2 workouts could uncouple the metrics of strength and hypertrophy*

- - Jeremy agrees and has tried to address this question several times via study design
    - One group trains doing a [1RM test](https://en.wikipedia.org/wiki/One-repetition_maximum) (repetition maximum); they come in and work up to about 5 reps in total then go home
      - In this group they are trying to maximize the strength signal but not get growth
      - This group should show what strength looks like if muscle growth does not occur
    - Compare this to the traditional training group; they would do about 8-12 reps of a very simple movement, the bicep curl
      - In this group both muscle growth and increased strength is observed
    - Most articles would conclude that since muscle growth is observed, that muscle growth must be contributing to strength

- *Jeremy asks*: what would strength look like if growth did not occur

- - - - In the study described above, he found that first group got stronger without increasing muscle size while the second group experiences both increased strength and increased muscle size; *but the strength increase was the same in both groups*
      - He expects to see a greater separation when assessing more complex movements
      - If doing a barbell bench press (a very, very simple movement) he would expect the group doing 1RM to be far better than the group doing 8-12 reps

- *His results suggest that change in muscle size is not necessary for a change in strength nor does it appear to be contributing given that the strength is the same in these 2 groups*

- - **Limitations** – in order to get that differential in growth, they had to apply slightly different exercise patterns
    - One group was doing 8 to 12 reps, it’s still a high load but not 100%; where as the other group was training at 100%
      - Some suggest this is not a fair comparison
    - There are more differences than simply muscle growth in these 2 groups; others have suggests they follow-up on these with [mediation analysis](https://en.wikipedia.org/wiki/Mediation_(statistics)) to look at how much of this change relative to a control is driven by muscle size within each group individually
      - When they did this, they did not see any mediation, meaning that *none of the change in strength could be explained by that change in muscle size in either one of the groups*

**Mediation analysis** –

- - There are some statistical approaches where one can look at the relationship between 2 exercise groups; instead of looking at them head to head, compare them individually to a group that is not exercising at all
    - This can control for many factors: random error across time, measurement noise, random biological variation, etc.
    - Jeremy explains mediation analysis as “saying “Okay, we have this group here. How much strength did they gain?” So they got stronger. That’s a direct relationship. So when this group exercised, they got stronger. Now, mediation says, “Okay, let’s add in a variable here to see if we can remove this relationship [between exercise and increased strength] either partially or completely.”

- *When muscle growth is added to this model it no longer correlates with strength; this indicates the relationship is driven by another variable, not muscle growth*

- - - - He didn’t expect a complete correlation between muscle growth and strength, but he did expect a  partial correlation

- *No correlation between strength and muscle growth was seen in either group*

- Peter asks “Is the [contrapositive](https://en.wikipedia.org/wiki/Contraposition) then that it’s not at all coupled?”
- His intuition would be that there is an association, not 100% causal; the [R2 value](https://en.wikipedia.org/wiki/Coefficient_of_determination) might be 0.5 not 0.99
- He would not guess no association or a negative association or one-to-one causal association
- Mediation analysis could show if there were partial mediation; but none was observed
  - They didn’t see any effect at all
  - There are other potential reasons, random error with measurements cannot be ruled out
  - Jeremy does see an accumulation of evidence suggesting that if muscle growth does play a role in strength, it is so small that they are not able to detect it

> “I am not sure that muscle growth in response to exercise is a mechanism [for increasing strength]. I’ve seen no experimental evidence that suggests that that’s the case.” – Jeremy Loenneke

- In practical terms, when someone is interested in getting as strong as possible, they don’t care whether muscle growth is a mechanism driving strength or not; they just want to get strong

**What was learned from these experiments in terms of increasing one’s strength?**

- *There is a huge specificity component; train a good portion of time at or close to 1RM*

- - If strength is desired for squatting or deadlift; then spend time training at 1RM with these exercises
- *Training to increase muscle growth* typically requires a lot of recovery because a large volume of exercise is required to make a muscle grow
- *If strength is the goal*, then perhaps less time can be devoted to high repetition exercise

- Jeremy is performing more experiments to address the role of (or lack thereof) muscle growth in increasing muscle strength

**What are other explanations to explain how strength increases?**

- - No one disputes the [neurologic component](https://en.wikipedia.org/wiki/Strength_training#Realization_of_training_goals); is there another mechanism?
  - Some have the opinion that the exercise-induced changes are probably predominantly neural; Jeremy’s not there yet
  - *He thinks there could be some local changes at the muscle, and that might be able to explain why some groups get stronger;* that it’s not just neural
    - Perhaps the muscle at the local level gets better at responding to forceful contractions
    - Maybe there are qualitative alterations in the local muscle that are not due to muscle size such as:

- *How the muscle deals with calcium*

- *How the myosin head binds*

- Jeremy thinks the usual argument isn’t fair – “Well, if muscle growth is not a mechanism, then what exactly is it?”
  - One doesn’t explain something by stating “We don’t have a lot of evidence for this, and there’s a lot of evidence against this”
- He does think there is a neural component to developing strength, he also thinks there may be molecular changes in the muscle other than growth but he hasn’t identified this yet

## Practical applications of blood flow restriction training for athletes and average people [1:27:30]

**How common is BFR (blood flow restriction) with athletes today?**

- - It’s becoming more common; at Ole Miss and *many Division 1 schools*, a large portion of the athletic departments have blood flow restriction devices
    - They are using them for rehab
  - He’s seen players in the NBA and the NFL using BFR
    - For both rehab and everyday training
    - Perhaps they recover a little quicker using BFR
    - They perceive it as a way to get a workout in without having to spend so much time recovering

- *Is the speed of recovery a function of less trauma to the muscle during a BFR workout?*

- - This isn’t known
  - But it appears that when athletes are injured and working out with BFR, they get more out of it and have less pain during movement
- How would a *bodybuilder* use BFR?
  - The goal of a bodybuilder, not being judged on strength, is to build volume; Peter discussed this with [Layne on the podcast](https://peterattiamd.com/laynenorton/) and he explained “Look, at the end of the day, the volume is what’s going to matter”
    - This can be accomplished with isolated movements
    - Using compound movements requires lots and lots of volume across these kinds of ranges
  - Jeremy thinks BFR could be a valuable tool for bodybuilders depending on how they feel any given day
    - If one is not feeling good and has a heavy day at the gym, they could use BFR to achieve similar training with lighter weights
    - On days one isn’t feeling focused lifting heaving weights can be dangerous; using BFR is an option to improve safety because lighter weights are used and it doesn’t require as much focus
    - He thinks BFR can be used to promote muscle growth
    - BFR can help with exercise variety
    - If one is hurt, evidence is accumulating that it is helpful in rehabilitation

> “It’s important to note that if a person’s not comfortable with it, they don’t have to do blood flow restriction in order to optimize how much muscle that they can grow. But it is a tool that could be potentially quite effective for them.” – Jeremy Loenneke

**When to use BFR and common concerns**

- Peter relates what happened in his workout today
  - He had a heavish day scheduled; the main set was a 5 by 5 deadlift
  - He had 5 sets to warm up and get to the starting weight
  - He was struggling with the first set of 5 and other sets
  - He thought on the 5th set in that he might hurt himself by breaking his form; this is when he stopped and switched to the leg press with BFR
    - It was a very light weight, that without BFR he could have done hundreds of reps with
- Peter thinks BFR is a great way to mix up training
  - It’s a tool for people who don’t have the technique to do heavier lifts
  - It’s an alternative to painful, [Super Slow training](https://en.wikipedia.org/wiki/Super_Slow)
- Jeremy was never really interested in Super Slow training
  - He never felt like he was going to get very strong with that method
  - The movement is slow and the weight is usually light so he questions how transferable this exercise is
  - He agrees this type of training is hard; he didn’t enjoy it
- Peter clarifies “*the one place where it’s unambiguous that you need to be doing a traditional lift without restriction is if you’re training for maximum strength of that lift*”
  - He doesn’t think most people are doing maximum strength bicep curls
  - But for a bench press, squat, deadlift, or leg press, there’s probably no substitute for for a 80% to 100% 1RM
  - Jeremy agrees

## Situations in which blood flow restriction training is most advantageous [1:35:30]

- *Exercising with low load under BFR will allow someone to build strength but to a much smaller degree than they would under traditional exercise*

- - - The load cannot be too low, 20-30% is too low
  - Jeremy uses the bicep curl as a research model to answer particular questions; these studies aren’t designed for personal training
  - One must keep in sight the reason why certain things are done
    - Some will look at the BFR literature and see a study that found similar changes in high load exercise; but the majority of studies do not find this effect
      - In the methods, the low load BFR group does 1RM every 2 or 3 weeks in an attempt to reset the load so they can assume they’re progressing

- *But what they end of up doing is practicing lifting a heavy weight, so this is not studying low loads of BFR; it’s low loads of BFR plus 1RM training*

- - Jeremy published a review of studies done with only low loads of BFR (without the 1RM test); their results are less than those produced by high load exercise
    - Review from 2020, [Strength testing or strength training: considerations for future research](https://pubmed.ncbi.nlm.nih.gov/33017302/)
    - This illustrates the point that the best way to improve heavy lifting is to practice lifting heavy weights
    - One will still get stronger lifting a lighter weight, but not as strong as lifting heavy weights

**In the big picture, there are 2 areas where BFR shines**

- *For a person who can’t lift heavy weight but still needs to get stronger and potentially bigger*

- Someone who is recovering from injury
- Someone with concerns about lifting heavy weights due to technique or simply seeking to avoid injury

- *For a person seeking to increase muscle hypertrophy*

- - Most studies demonstrate slightly superior hypertrophy resulting from exercise under BFR despite less total volume of exercise and lower load

- Jeremy agrees, *low load exercise with BFR produces more hypertrophy than exercise with a matched load*

- - Peter clarifies, to make them equal, one has to do more reps (repeat until failure) on the unrestricted side; and this takes more time

**Jeremy clarifies a point about vascular adaptations**

- He expected vascular adaptations to be the same across the board (with or without BFR) as long as one is doing lots of reps
  - This is not what they found; *vascular adaptations were not the same with BFR*
    - He wants to repeat these experiments
  - He thought just the workload would be less for BFR; this is true for muscle but he doesn’t know if it’s true for all variables

## The mechanisms by which blood flow restriction training can produce so much hypertrophy at such low loads [1:39:45]

**The role of lactate levels**

- - Peter assumes that one reason why BFR can produce so much hypertrophy using a low load is the response to metabolic challenge
    - He tested lactate levels with and without BFR using blood from a pin-prick of his finger
    - When he occludes the arm and exercises, the lactate levels go through the roof at locations well distal to the occlusion
      - He’s pin-pricking his finger and getting very, very high levels of lactate
      - Is this because the lactate is not allowed to clear out of circulation?
    - [Lactate](https://en.wikipedia.org/wiki/Lactic_acid) is a metabolic by-product of exercise, especially [this type of exercise](https://en.wikipedia.org/wiki/Anaerobic_exercise)
    - He had a higher level of lactate exercising under BFR than when unoccluded and lifting slightly more weight

- *Peter asks if lactate levels matter*

- Jeremy explains as lactate pools, it may turn on some [anabolic](https://en.wikipedia.org/wiki/Anabolism) signaling pathways to activate growth
  - So exercising under BFR is thought to trap lactate in the muscle where it may augment muscle activation
    - Trapped metabolites (such as lactate) may cause the muscle to work harder than it normally would
    - Lactate may fatigue some of the [cross-bridges](https://openstax.org/books/anatomy-and-physiology/pages/10-3-muscle-fiber-contraction-and-relaxation?query=muscle%20cross%20bridges&target=%7B%22type%22%3A%22search%22%2C%22index%22%3A0%7D#fs-id2292610) formed during muscle contraction
      - Interaction between the actin and myosin microfilaments occur as myosin heads form cross-bridges with actin
        - The figure below shows actin filaments in green and myosin filaments in purple
        - Notice the purple balls on the myosin filament interact with the actin filament
        - This is the sliding filament model of muscle contraction

![](https://peterattiamd.com/wp-content/uploads/2021/10/f4-jeremyL-1024x937.jpeg)

**Figure 4. Crossbridges are formed between myosin and actin during muscle contraction.** Figure credit: [OpenStax Anatomy and Physiology Figure 10.10](https://openstax.org/books/anatomy-and-physiology/pages/10-3-muscle-fiber-contraction-and-relaxation#fig-ch10_03_03)

- - When cross-bridges fatigue, more and more fibers may need to be recruited to complete the work

- *In this model metabolites induce fatigue, this leads to further muscle activation; and muscle activation for a sufficient amount of time is what makes the muscle grow*

**Are the mechanisms in play with BFR different from that of traditional exercise**

- - Does high load exercise employ a different mechanism than low load exercise with BFR?

- *Jeremy thinks no*

- - - The mechanism involved in activation is different, but once the muscle fiber is activated, the signaling pathway is going to be similar
    - For example, a 1RM bicep curl trying to lift 70 lbs (an enormous weight) activates a large portion of the musculature
    - Compare this to low loads, fewer muscle fibers are activated initially because the weight is low

- *Exercise with low loads under BFR initially activates fewer muscle fibers, but as metabolites are trapped, more and more fibers are activated so ultimately a similar amount of fibers are activated compared to exercise with high load*

- Peter asks what happens to fiber fatigue under 2 scenarios without BFR: 8-10 reps with 80 lbs versus 40 reps with 40 lbs.
  - Jeremy explains [Henneman’s size principle](https://en.wikipedia.org/wiki/Henneman%27s_size_principle)
    - This relates the input and output of motor neuron and their muscle fibers to size and size-ordered activation during movement
    - A [motor unit](https://www.medscape.com/answers/1141359-194326/how-are-motor-units-recruited) is a motor neuron + muscle fibers
    - With any exercise 1 motor unit is recruited first
    - As required a 2nd motor unit is recruited and so on, in a sequential fashion as needed
    - Lifting a heavy weight recruits 2 motor units quickly
    - Lifting a lower weight takes longer to recruit 2 motor units

**Muscle fiber types used in exercise**

- - For example, if a person fails at 8 reps with 80 lbs and 40 reps with 40 lbs; it simply means the 40 reps took longer to burn through the type I fibers and the type IIA’s and IIAB’s, and then at the end of the exercise the type IIX’s failed
  - If this person repeated the exercise 20 minutes later at 80 lbs and failed at 8 reps this means he got to the IIX sooner
    - Type IIX muscle fiber are fast twitch, produce the largest force, and are easily fatigued
      - They rely on anaerobic respiration which produces lactate
  - *Type I and II fibers both grow in response to exercise: high load, low load, with or without BFR*

- *At the extreme level, a body builder’s hypertrophy is explained by growth in both types of fibers*

## Applications of “passive” blood flow restriction training [1:47:15]

- For someone with serious injury
- For example, someone who had ACL surgery
  - Apply BFR to their limb, inflate and deflate for a period of time, a couple times a day to slow muscle loss
  - Only a few [studies on this](https://pubmed.ncbi.nlm.nih.gov/11128848/)
  - Muscle growth does not occur, rather loss of muscle is slowed

**Progression of BFR in someone who cannot do anything, even walk**

1. Apply restriction to slow muscle loss
2. Walk slowly when able
3. Transition to resistance exercise; this is where they will see the most improvement
4. Go on to high load exercise if they choose

- - Muscle loss occurs in sedentary individuals following surgery or injury
  - Muscle loss in the elderly is huge and has devastating effects
    - For someone in their 70’s if they train hard for 1 year and put on pounds of muscle but then lay in a hospital bed for 10 days, they will lose all of this muscle

- *BFR could be a tool to slow this muscle loss; this needs to be studied*

- Peter remarks this is one thing he discusses with his patients, after age 70 they are 1 fall away from the end of life
  - Even if they don’t die right away
  - Many elderly never get back on their feet after an injury
  - Passive, low-end aerobic, low load resistance exercise could help them regain strength and stamina
    - Ultimately getting back to high load exercise would be great

## What experiments would Jeremy do if he had unlimited resources? [1:51:45]

- He wants to figure out why people get stronger
- This can tie into BFR
- What does a change in strength from resistance training mean for the overall function of a person
  - Does getting stronger carry over to improvements in walking ability, etc.
- He would like to study more applications of BFR in people in a hospital setting, on a large scale
  - Current studies have an extremely small sample size

§

## Selected Links / Related Material

**Review of muscle anatomy**: [Skeletal Muscle Structure](https://youtu.be/XoP1diaXVCI) | GreatPacificMedia (October 4, 2009) (youtube.com) | [8:00]

**Review by Andy Galpin on fast and slow twitch muscle fibers:** [Moving human muscle physiology research forward: an evaluation of fiber type-specific protein research methodologies](https://pubmed.ncbi.nlm.nih.gov/32783659/) | *American Journal of Physiology. Cell Physiology*  (I S Tobias and A J Galpin 1 2020) | [14:00]

**Review of studies assessing the role of muscle growth in strength**: [Is muscle growth a mechanism for increasing strength?](https://pubmed.ncbi.nlm.nih.gov/30902152/) | *Medical Hypothesis* (J P Loenneke *et al.* 2019) | [27:30]

**First publication testing the effects of blood flow restriction exercise on** muscle: [Efficacy of tourniquet ischemia for strength training with low resistance](https://pubmed.ncbi.nlm.nih.gov/9459541/) | *European Journal of Applied Physiology and Occupational Physiology* (M Shinohara *et al.* 1998) | [35:30]

**Discomfort caused by exercise under blood flow restriction**: [Blood Flow Restricted Exercise and Discomfort: A Review | Journal of Strength and Conditioning Research](https://pubmed.ncbi.nlm.nih.gov/32058360/) (Spitz *et al.* 2020) | [43:15]

**Safety of blood flow restriction exercise**: [Potential safety issues with blood flow restriction training](https://pubmed.ncbi.nlm.nih.gov/21410544/) | *Scandinavian Journal of Medicine and Science in Sports* (J P Loenneke *et al.* 2011) | [59:00]

**Exercise under BFR produces gains in strength and size**:

- [Exercise intensity and muscle hypertrophy in blood flow-restricted limbs and non-restricted muscles: a brief review](https://pubmed.ncbi.nlm.nih.gov/22681600/) | *Clinical Physiology and Functional Imaging* (T Abe *et al.* 2012) | [1:05:45]
- [Exercise with blood flow restriction: an updated evidence-based approach for enhanced muscular development](https://pubmed.ncbi.nlm.nih.gov/25430600/) | *Sports Medicine* (B R Scott *et al.* 2015) | [1:05:45]

**Review of studies linking increased muscle growth to increased strength**: [Muscle growth: To infinity and beyond?](https://pubmed.ncbi.nlm.nih.gov/28543604/) | *Muscle and Nerve* (Brittany Counts *et al.* 2017) | [1:12:00]

**Papers commonly cited to support the traditional paradigm of increased muscle size leads to increased strength**:

- [Neural factors versus hypertrophy in the time course of muscle strength gain](https://pubmed.ncbi.nlm.nih.gov/453338/) | *American Journal of Physical Medicine* (T Moritani and H A deVries 1979) | [1:12:30]
- [A study on training effect on strength per unit cross-sectional area of muscle by means of ultrasonic measurement](https://pubmed.ncbi.nlm.nih.gov/5425330/) | *Int Z Angew Physiol* (M Ikai and T Fukunaga 1970) | [1:14:30]

**Review of studies linking increased muscle growth to increased strength**: [Review of studies linking increased muscle growth to increased strength](https://pubmed.ncbi.nlm.nih.gov/30902152/) | *Medical Hypotheses* (Jeremy P Loenneke 2019) | [1:12:00]

**Reviews that suggest a link between muscle hypertrophy and strength:**

- [**Neural adaptation to resistance training**](https://pubmed.ncbi.nlm.nih.gov/3057313/) **|** *Medicine and Science in Sports and Exercise* (DG Sale 1988) | [1:16:00]
- [**Physiology of weight-lifting exercise**](https://pubmed.ncbi.nlm.nih.gov/7073463/) **|** *Archives of Physical Medicine and Rehabilitation* (W J Gonyea and D Sale 1982) | [1:16:00]

**Study using mediation analysis to explore the connection between strength and muscle hypertrophy**: [Assessing differential responders and mean changes in muscle size, strength, and the crossover effect to 2 distinct resistance training protocols](https://pubmed.ncbi.nlm.nih.gov/31553889/) | *Applied Physiology Nutrition and Metabolism* (Scott J Dankel *et al.* 2019) | [1:18:30]

**Podcast episode about bodybuilding**: [#163](https://peterattiamd.com/laynenorton/) – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training | Peter Attia ([The Drive](https://peterattiamd.com/podcast/)) | [1:29:30]

**Review of studies using exercise with low loads plus BFR**: [Strength testing or strength training: considerations for future research](https://pubmed.ncbi.nlm.nih.gov/33017302/) | *Physiological Measurement* (R W Spitz *et al.* 2020) | [1:37:00]

**Explanation of the types of muscle fibers**: [Skeletal Muscle: Form and Function](https://www.google.com/books/edition/Skeletal_Muscle/-EfxEhSFaMYC?hl=en&gbpv=1&dq=muscle%20fibers%20IIab%20IIx&pg=PA187&printsec=frontcover&bsq=muscle%20fibers%20IIab%20IIx) by B R MacIntosh *et al*. (2006) | [1:45:15]

**3 major types of muscle fibers**: [Motor Unit Recruitment in EMG](https://emedicine.medscape.com/article/1141359-overview#a2) | F Sandbrink, Medscape | [1:45:15]

**The use of passive-BFR for rehab after ACL surgery**: [Applications of vascular occlusion diminish disuse atrophy of knee extensor muscles](https://pubmed.ncbi.nlm.nih.gov/11128848/) | *Medicine and science in sports and exercise* (Y Takarada *et al.* 2000) | [1:47:32]

**Meta-analysis of impact of BFR on resistance training**:

- [Low intensity blood flow restriction training: a meta-analysis](https://pubmed.ncbi.nlm.nih.gov/21922259/) | *European Journal of Applied Physiology* (J P Loenneke *et al.* 2011)
- [Resistance training induced changes in strength and specific force at the fiber and whole muscle level: a meta-analysis](https://pubmed.ncbi.nlm.nih.gov/30357517/) | *European Journal of Applied Physiology* (S J Dankel *et al*. 2018)

**Review of studies looking at muscle damage caused by BFR**: [Does blood flow restriction result in skeletal muscle damage? A critical review of available evidence](https://pubmed.ncbi.nlm.nih.gov/24650102/) | *Scandinavian Journal of Medicine and Science in Sports* (J P Loenneke *et al.* 2014)

**Clinical trial evaluating muscle strength resulting from bench press training with BFR (at low or high-intensity) and 1-RM bench press training without BFR:** [Effects of short-term detraining following blood flow restricted low-intensity training on muscle size and strength](https://pubmed.ncbi.nlm.nih.gov/24828574/) | *Clinical Physiology and Functional Imaging* (T Yasuda *et al.* 2014)

**Opinion on exercise parameters to increase muscle growth:** [Frequency: The Overlooked Resistance Training Variable for Inducing Muscle Hypertrophy?](https://pubmed.ncbi.nlm.nih.gov/27752983/) | *Sports Medicine* (S J Dankel *et al.* 2017)

**BFR review for practitioners**:

- [Exercise with blood flow restriction: an updated evidence-based approach for enhanced muscular development](https://pubmed.ncbi.nlm.nih.gov/25430600/) | *Sports Medicine* (B R Scott *et al.* 2015)
- [Blood Flow Restriction Exercise: Considerations of Methodology, Application, and Safety](https://www-ncbi-nlm-nih-gov.gate.lib.buffalo.edu/pmc/articles/PMC6530612/) | *Frontiers in Physiology* (Stephen D Patterson *et al.* 2019)

**The use of BFR for rehab after ACL surgery**: [Comparing the Effectiveness of Blood Flow Restriction and Traditional Heavy Load Resistance Training in the Post-Surgery Rehabilitation of Anterior Cruciate Ligament Reconstruction Patients: A UK National Health Service Randomised Controlled Trial](https://link.springer.com/article/10.1007%2Fs40279-019-01137-2) | *Sports Medicine* (L Hughes *et al.* 2019)

§

## People Mentioned

- [Layne Norton](https://www.biolayne.com/about/), Ph.D. (professional powerlifter and coach) | [5:30, 1:29:30, 1:54:00]
- [Andy Galpin](https://hhd.fullerton.edu/knes/facultystaff/AndyGalpin.php), Ph.D. | [personal website](https://www.andygalpin.com/our-team) (exercise physiologist) | [14:00]
- [Yoshiaki Sato](https://en.wikipedia.org/wiki/Yoshiaki_Sato) [31:15]
- [Minoru “Shino” Shinohara](https://sites.gatech.edu/shinohara/) [35:30]
- [Digby Sale](https://experts.mcmaster.ca/display/saled) [1:16:00]

§

![](https://peterattiamd.com/wp-content/uploads/2021/10/bio-image-jeremyL.jpeg)

##### Jeremy Loenneke, Ph.D.

Dr. Jeremy Loenneke graduated with a PhD in Exercise Physiology from the University of Oklahoma under the mentorship of Dr. Michael Bemben. Dr. Loenneke had previously earned a Master’s degree in Nutrition and Exercise Science from Southeast Missouri State University under the mentorship of Dr. Joe Pujol. As an Associate Professor of Exercise Science at the University of Mississippi, his research focuses on skeletal muscle adaptations to exercise in combination with blood flow restriction. His recent work has answered several important methodological and safety questions with respect to applying blood flow restriction. Dr. Loenneke is the director of the Kevser Ermin Applied Physiology Laboratory. He is a Fellow of the American College of Sports Medicine and a member of the American Physiological Society. He also serves as a peer reviewer for several journals including Sports Medicine, AGE, Medicine and Science in Sports and Exercise, and the Journal of Applied Physiology. [The University of Mississippi [faculty profile](https://olemiss.edu/people/jploenne) and [department of Health, Exercise Science, and Recreation Management](https://hesrm.olemiss.edu/people/jeremy-paul-loenneke/)]