# #79 – Ric Elias: Earning the gift of life

**Source:** [https://peterattiamd.com/ricelias/](https://peterattiamd.com/ricelias/)

---

In this episode, Ric Elias, founder of Red Ventures, opens up about the fateful day he knew for certain that he was going to die as a passenger on [US Airways Flight 1549](https://en.wikipedia.org/wiki/US_Airways_Flight_1549). Ric dives deep into how that day impacted his life, greatly changed his perspective, and improved his relationship with his family and the broader community. We also talk about his incredible role as CEO of an enormous company, his remarkable work in philanthropy, and all the wisdom he has acquired in his extraordinary life.

\*If you enjoy this podcast, you are sure to enjoy [3 Things with Ric Elias](https://blog.redventures.com/category/external/3-things/)—a podcast that gleans insights from remarkable people and hosted by Ric himself (Listen on [Apple Podcasts](https://red.ventures/3-things-apple), [Spotify](https://red.ventures/3-things-spotify), or [Google Play)](https://red.ventures/3-things-google)\*

\_\_\_\_

Subscribe to The Drive: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ricelias/the_Drive_public.png)

Play

#79 - Ric Elias: Earning the gift of life

1x15s30s

0:001:41:53

We discuss:

- Ric’s life leading up to the day of the plane crash [5:30];
- The plane crash—What it’s like knowing you’re about to die, feelings of regret and sadness [11:15];
- The improbable plane landing in the Hudson River [19:00];
- Emotions after the safe landing (and a story he’s never told before) [25:45];
- A powerful story about Captain Sully [29:30];
- Earning his second chance at life, and playing the “infinite game” [38:30];
- Why time is the ultimate currency, and how (and why) to say “no” [46:15];
- Raising kids in an achievement culture, Ric’s definition of life success, and what Ric wants to instill in his kids [53:00];
- What Ric believes is actually worth getting upset about, and the organizations that are taking steps to help people [1:09:00];
- The core principles of Red Ventures (Ric’s company) [1:19:15];
- Ric’s tips for developing business acumen and negotiation skills [1:29:30];
- What qualities does Ric look for in people he wants to work with? [1:32:50];
- What is the next big problem that Ric wants to solve? [1:35:30];
- What is the most challenging part of your business today? [1:37:30];
- If Ric could go back and talk to himself in the morning before getting on that plane, what would he say? [1:39:15]; and
- More.

§

## Show Notes

## Ric’s life leading up to the day of the plane crash [5:30]

Here is Peter’s [blog post](https://peterattiamd.com/tedmed-2013-now-i-get-it/) about his own [2013 TEDMED Talk](https://www.ted.com/talks/peter_attia_what_if_we_re_wrong_about_diabetes?language=en) in which he mentions getting to meet Ric

Peter’s [favorite TED Talk](https://www.ted.com/talks/ric_elias) of all time was given by Ric Elias

**Ric’s life before the crash**

- His company, [Red Ventures](https://www.redventures.com/), was starting to thrive (after years of struggle)
- Would Ric have described himself as “happy”?
- Yes, generally a positive person
- But, at the time he was spending 95% of his time on his business and only sparingly with his family (a wife and 2 kids)
- “Looking back, it was completely out of balance.”

**The morning leading up the crash**

- Ric was scheduled to fly on [US Airways Flight 1549](https://en.wikipedia.org/wiki/US_Airways_Flight_1549)
- He played basketball early in the morning
- It was an overcast, gloomy day
- He remembers eating 2 ice cream cones from McDonald’s at the airport
- He was very stressed about the never ending list things he needed to do during the flight and once he landed

## The plane crash—What it’s like knowing you’re about to die, feelings of regret and sadness [11:15]

> “I knew in that moment, 100% with certainty, that we were going to die.”

**Just a few minutes after takeoff**

- there was a loud BOOM (like a pipe bomb)
- It was the sound of the engines going out after hitting a flock of birds
- At first, it seemed all was okay (the flight attendant was calm)
- [Captain Sullenberger](https://en.wikipedia.org/wiki/Chesley_Sullenberger) gets on the voice system and says three simple words: “**Brace for impact**”
- “*I knew in that moment, 100% with certainty, that we were going to die.*”

**Saying goodbye to your life**

- After “brace for impact”, the plane was gliding downward for 90 seconds
- Ric said you have 90 seconds to “*say goodbye to your life*”
- We tend to believe we are going to live forever, then it all changes in an instant
- Ric was hoping the plane would explode so there would be no suffering

**The feeling of regret**

  1 The first feeling of regret was around:

- The things he did not get to
- The people he needed to ask for forgiveness from
- And the people he needed to hug again and say “I love you” one more time
- Just a profound feeling of “*There’s no going back and there’s no turning back.*”

  2 The other regret was about his ego:

- How much I had allowed my ego to become very active in my life
- So much time spent focusing on being wronged by people
- So much time spent trying to be “right” versus choosing to be happy

> “Wow, I’ve lived my life in a very wasteful way because so much of my energy has been spent on things that did not matter.”

  3 The third regret was around:

- The fact that he had not focused on the things that matters most in my life…his kids
- My most important responsibility was to make sure my kids were the best versions of themselves and he had completely delegated that to my wife in a very unfair way.

**Dying was not scary, it was sad**

- Ric says he felt tremendous sadness about dying, but no fear
- Peter says he’s heard the same sentiment from others with similar experiences

> “Dying to me was not scary. I always thought it would be a scary moment. It was super sad, because I didn’t want to go. I really like my life. I really wasn’t done. I had lots of regrets. It was not scary. That in itself also has been clarifying for me.”

**Why didn’t Ric cash the $10,000 check from the airline (in return for not suing)?**

“I was given the ultimate gift and the ultimate gift was to say goodbye to your life, to close your eyes, to touch your own arm, say I love you, to wish for it to blow up, and to open your eyes and realize that you had a second chance.”

## The improbable plane landing in the Hudson River [19:00]

**[Video](https://www.youtube.com/watch?v=ny9q0KM3Ca8)** **of the plane landing in the Hudson River**:

The crazy statistics around the improbable nature of a safe landing (in Ric’s words):

- We landed I think at 151 miles an hour
- If we are at 153, we blow up
- At 149, we tip over.
- The wind was blowing at like 12.5 MPH
- At 14 MPH it would have been a disaster
- Many things had to be within such a small degree
- All compounding into a moment that you can land a cylinder with 158 people full of gas
- “*It’s like hitting cement.*”

**The last few seconds before impact**

- In the last few seconds before impact, Ric grabbed his own arm and said, “I love you”
- “*I think I had a sense of needing comfort as you exit life. There was probably a lot of acceptance in that statement subconsciously.*”

## Emotions after the safe landing (and a story he’s never told before) [25:45]

**A “selfish” final act**

- Ric was sitting in first class, row 1
- He saw an elderly lady in a wheelchair and a voice him said “Get up, give up your seat. Go sit in the coach.”
- But he rationalized not doing so, and the lady went to the back of the plane
- After the crash, Ric starting panicking about where the lady was
- Eventually, the older lady gets helped into a raft and Ric’s thought was, “*Oh my goodness, my last act would have been one of my most selfish acts.*”
- Ric then offers to carry her up a ladder onto safe ground
- He nearly slips off the ladder but manages to hold on

**Emotions once on safe ground**

- As he got off the boat, he began to cry
- “The river of emotion was insane.”
- He immediately calls his wife
- His wife had heard about the plane crash and immediately thought Ric was dead
- She answers the phone and starts screaming, “He’s alive! He’s alive!”

## A powerful story about Captain Sully [29:30]

- Captain Sully was the last person off the plane
- Once on safe ground, Ric saw Sully standing there in a “stoic” manner
- Ric went up to Sully and said, “*Thank you for saving our lives*.”
- Sully’s response: “*I was just doing my job.*”

> “He said something to me that day that I say to myself all the time when someone thanks me for something. I don’t say it out loud . . .He said, “I was just doing my job.” Can you imagine if we all just kind of did our jobs at any level?”

**Seeing Sully again for the first time**

- It was 10+ years before he would see Captain Sully again
- Eric got to introduce him as a guest of honor at an awards show
- But before the show, they saw each other
- Ric said that he said nothing, they just embraced

> “He could see my eyes what I wanted to say in a way that was so deep and he understood. I saw in his eyes a connection that two human beings can’t manufacture. It was really an amazing moment to see the person that saved your life.”

*What percent of pilots could have pulled this off?*

- Ric thinks the answer is close to zero
- Captain Sully had been preparing his whole life for this moment
- Sully has told other people before that, “***You’re only a pilot when you lose an engine***.”

## Earning his second chance at life, and playing the “infinite game” [38:30]

**Earning it**

- Peter asks Ric if he relates to the [scene from Saving Private Ryan](https://www.youtube.com/watch?v=YadFEDZPLWU) where Tom Hanks’ character’s last words to Private Ryan were, “Earn this.”
- Ric says, 100% he relates
- he feels an obligation to make the most of his second chance at life
- Ric says a few days after the incident he decided to live the rest of his life to earn his gift

> “This is how I would judge my life…”Did I earn my gift?” . . .We in our evolution can’t process death. Otherwise, we would have never left the cave. I left the cave. I was given the gift, and that gift is a responsibility, not a gift.”

**How is he implementing his new attitude towards life?**

- Not postponing anything
- Not dealing with negative energy
- Focusing on what matters
- Ric says he fights with his wife are 10% of what they used to be
- Choosing to be happy rather than always being right:
- “***I ask for forgiveness not because I may have done something wrong, but because someone was offended by what I did. I choose to be happy not righteous.***”

*There’s always three sides to an argument, says Ric*

  1 Your argument

  2 The other person’s argument

  3 The truth

> “If you start every argument understanding that you don’t have the truth, you have your truth, it’s really easy to surrender to that. Most things in life are a shade of grey and not completely black and white. The problem is when we believe we’re right, we have made something black and white.”

**Collecting bad wines**

- Ric has a saying, “I collect bad wines”
- What does he mean by this?
- I collect bad wines is the trigger thought for not postponing anything.
- It comes from the idea that Ric has a lot of bad wines because he’s always opening the best one with his guests
- Collecting bad wines means so much . . .
  - Taking the trip
  - Making the call
  - Taking the risk
  - Having the courage
  - Forcing yourself to things that you know you need to do

**Playing the “infinite game”**

- After the crash, Ric lost about 45 pounds and is much healthier
- But at the same time he now lives life to the fullest
- H*ow does he square these seeming competing ideas*?
- Ric says the whole purpose if life to to play the next game
- (a philosophy from the book [The Infinite Game](https://www.amazon.com/Infinite-Game-Simon-Sinek/dp/073521350X) by Simon Sinek)
- There is no winning, there’s no outcome, there’s no end
- To play the next game, you have to be healthy

> “I can win the game of complete pleasure for a day, a month, a year but then I lose my ability to keep playing the game.”

## Why time is the ultimate currency, and how (and why) to say “no” [46:15]

> “Time is our only currency. It’s the only thing that matters. In our civilization, we solve for wealth first, but find any really rich person that is old or sick and they’ll trade it all for more time.”

Ric sometimes speaks to cools at schools

–A story he tells them:

- “I’m going to give you a million dollars but you have to give me your arms.” All the kids are, “No, no, no.”
- “Okay, I’m going to give you $5 million if you’re going to give me your arms and your legs.” The kids say “No, no, no.”
- “Okay, I’ll give you $10 million if you’re going to give me your arms, your legs and your eyes.”
- The value of the story is **you’re already rich because you have your health**. Money really can’t buy you that.

Ric says he wastes no time and he’s not afraid to say “no” to things

- I’m really comfortable saying no all the time.
- I’m very thoughtful and polite.
- I don’t join any outside boards.
- I have demoted friends that I outgrew so that I can make room for new friends.

> “When you’re saying yes, you’re saying no to something else. Everything in life has a price.”

⇒ Peter’s friend Jason Fried recently said this same thing on a [recent podcast episode](https://peterattiamd.com/jasonfried/)

## Raising kids in an achievement culture, Ric’s definition of life success, and what Ric wants to instill in his kids [53:00]

> **“**Y*ou’re only a leader in a moment of crisis. Otherwise, you’re just in charge. You, as a leader, have to prepare yourself for the moment of crisis. It’s going to come.*”

**With being a parent**:

- Ric says the keys to being a good parent are…
  - Helping your kids to find their gift
  - Then, to help them get to their gift
  - Accept them for their strengths and their weaknesses
  - Not shaming them

> “The last thing you want a kid to feel is shame. When we want something different for our kids, then what they seem to want, there’s a high chance you end up shaming them without wanting to, or guilting them. I think for a parent to lead is to meet the kid where they are and finding their natural bent and encouraging it and making them their best version of themselves.”

**Peter worries about life for teenagers in today’s world**

–Peter asks Ric his advice around putting limits on things like electronics, social media, etc.

–Ric says his mom had the best quote about parenting: “***Raising teenagers is a tug of war you ultimately must lose because that’s how they become adults.***”

- You can’t lose at age 13, but you have to lose incrementally.
- If you ask anybody, what is your goal for your kid?
  - They’ll tell your some version of the same thing, **happy, well adjusted, contributing, growing, finding their passion**…
  - But then we raise our kids and we over-schedule, two sports, a trainer, another coach,  pre-SAT, etc.
  - Did that really help?
  - Then we wonder, why are our kids so stressed out?
- “As parents, we judge so much of our own self-esteem by what others think about our kids.”
- If you really want your kid to be happy, adjusted, whatever, *you would do a lot of things differently*

**Progress is key**

- Put kids in situations that they feel like they are progressing
- They’ll find whatever their ceiling is in the long enough time
- Many kids quit sports because we push them too hard too early and they’re like, “*This doesn’t feel good.*“

**Ric’s definition of life success**:

> “I think the definition of one’s life success is, where do you come from and where did you end? Did you help advance the cause of our race, the human race? . . . If you’re lucky enough, through your community, if you’re lucky enough in a broader way you are impacting a broader set of people. I think the ultimate goal of life is to make it better for others, **starting with your kids**.”

**The impact of hardship and struggle**

-Ric migrated to the US from Puerto Rico at age 18

- He came by himself
- Spoke almost no english
- Enrolled at Boston College
- His dad said to him… “*Go be a man*”
- Ric was getting odd jobs to make ends meet and to pay for college
- “*I didn’t really understand English. I was ill equipped to go to college. But overcoming that was the greatest gift.*”
- As great as this experience was for Ric, he makes the comment, “*I don’t know why I wouldn’t do that to my kids.*”

**How to impart the lessons of hardship into kids**

- Ric’s hardship imparted great life lessons onto him which lead to his success
- Now, his kids have things and opportunities Ric never had
- Peter wants to know …

*⇒ How does Ric plan to instill some of the things that Ric learned through hardship that his kids may not learn without that same experience*?

- I think it’s really hard to be our kids and that we’re giving them a big, big cross to carry
- Ric said his life was “easier” because the game was clear which was to make a better life for himself
- But when kids come from very successful parents, it’s harder because the game isn’t as clear
- You have to set up a different “game” that they feel they can win
- So many of them end up in drugs and end up in other things because they feel like they can’t be successful in the game their parents expect them to play

**So what is Ric trying to instill in his kids?**

*–First, hard work*

- I think, first of all, it’s not what you say is what you do.
- I want them to understand that working hard is part of the way you achieve things in life
- \*As long as it’s protecting family time and what really matters

*–Secondly, how you treat others*

- - The best thing that you can do to teach your kids how to live is to treat strangers with kindness.
  - They’re watching your every action…
  - So remember next time you get righteous b/c an Uber driver is late, or a waitress spill soup on you…*you are teaching them the wrong lesson*

- **The best thing I can do is model hard work, model giving and kindness, model good energy to other people, respect.**

> “You can’t apologize for your success and you can’t run away from it. You have to talk to them about **not**, ‘Hey, I want you to get into an Ivy League school and I want you to do all this stuff.’ [But rather], ‘I want you to find your gift and I want you to figure out a way to give that gift to others.’”

## What Ric believes is actually worth getting upset about, and the organizations that are taking steps to help people [1:09:00]

> “To whom much is given, much is expected.”

**What does Ric believe is worth getting upset about?**

- Ric says injustice is worth being upset about
- Specifically, situations **where the system fails and people that want to help themselves are unable to do so**

⇒ Ric’s best example is undocumented children (aka [DACA](https://en.wikipedia.org/wiki/Deferred_Action_for_Childhood_Arrivals))

- These are young kids that were brought here at a young age illegally by their parents
- But since they were not citizens, they could not get federal financial aid in most cases
- And even getting an education wouldn’t make sense because they couldn’t get a work permit
- Some of this changed with the [DREAM Act](https://en.wikipedia.org/wiki/DREAM_Act) in 2010
- Ric launched [Golden Door Scholars](https://www.goldendoorscholars.org/) to help DACA kids get through college

**Other programs Ric is involved with**:

[Road to Hire](https://www.roadtohire.org/)

- Give unemployed, uneducated young adults 18-24 years old free training in coding, tech, etc.
- They get trained for 6 months
- Then put into a 2 year apprenticeship program

[LifeSports](https://lifesports.org/)

- A program for middle and high school kids that are lacking hope
- Usually they are behind on reading comprehension
- They also used team sports as a vehicle to teach them things and be part of something
- “We give them usually their last meal of the day, we give them an hour worth of reading, because we think if they can catch up with reading, they’ll extend their hope. Then, we give them an hour and a half worth of exercise. Every weekend, there’s activities, we have 250 kids now in the program, we started two and a half years ago. We’re going to grow, we’re going to build our own facility.”

[Forward 787](https://www.forward787.com/)

- A program for Puerto Rico
- Training young Puerto Ricans in the US to prepare them to move back to Puerto Rico and bring back their economy
- And also plan to move business to Puerto Rico

## The core principles of Red Ventures (Ric’s company) [1:19:15]

*One time Peter came to a “business review” at* [*Red Ventures*](https://www.redventures.com/)*…*

–Peter says, “*I have never seen anything like I saw that day, Ric. Your ability to process information, to multitask, to make decisions, to sift through what was not relevant and to always be asking the jugular question in the setting in context of more information than could be processed by any person, blew my mind.*”

***What does Red Ventures do?***

- RV is a significant network of digital assets that all have deep integrations into the different service providers.
- We are trying to aggregate lots of services that consumer buy by owning assets like The Points Guy or Bankrate or Allconnect or Healthline.
- We do very deep integrations with all the services providers, all the card issuers, all the banks, everybody in health care
- Basically trying to change the consumer experience digitally

**Core principles of Red Ventures**

-RV has a series of belief statements that anchor our culture.

- In the middle of that belief statement is “**everything is written in pencil**”
  - It allows us to evolve and change our mind because the world is changing so fast, it really gives us permission to experiment because everything is written in pencil.
- The last one is… we believe that **leaving the woodpile higher than we found it is our purpose**.
- Another belief statement is: **we believe in running up the escalators**.
  - You have to play with pace. This is not about speed, speed, speed. This is about pace.
  - The more reps you get, the more you iterate through problems.
  - For us, it’s really important that we’re playing at the highest pace.
  - That doesn’t mean we’ll work to 7:00 p.m. every night. We work hard. We’re very purposeful. We’re small teams. We’re decisive.
  - Most things in business are pass/fail yet we are trained our whole lives for grades
  - Where a lot of leaders get in trouble is this is why people have a hard time prioritizing
  - If something is a pass-fail event, I’ll put in 20% of the effort
  - Really understanding what’s pass/fail and what’s graded is a really important skill

> “When it’s pass/fail, you just run up the escalator.”

**Business reviews at Red Ventures**

*How do they work?*

- 20-minute meetings
- No charts are passed around
- Nothing in color
- You’ve got to be able to get to your point.
- Start the meeting. “Okay, here’s the problem we’re trying to solve or here’s what we’re trying to talk about.” You have to define your problem.
- Then, you went through it and then we conclude it with something.

–Peter: “*The pace of this was like nothing I’ve ever seen*”

- 27 meetings, 20 minutes each, it’s a 10-hour day
- They are incredibly efficient, the problem is defined, ideas were discussed, a plan was made, and the person left knowing what to do next
- Peter was blown away by Ric’s ability to ask such great questions, make such quick decisions, and to pivot from topic to topic between meetings

–Ric believes in things being a “**threefer**”

- Anything you do in life should be a threefe (some things can be a fourfer)
- Most people are happy to get a twofer
- ⇒ *Quick Example*:

- If you’re going to go play golf because want to play golf. That’s a onefer.
- If you go play golf at a beautiful course that’s a twofer.
- Playing golf, a beautiful course, and with your best friends? That’s a threefer.

*–Ric considers the business review a “fourfer”*

- It’s a way to force prioritization.
- It’s a way to train people how to present.
- The third is it forces decision making
- The fourth is that it culturates.
- Red Ventures has 2,000 25-year-olds that have been trained at a high level because of this process

> “I’d like to set up as an organization, if we’re going to invest that kind of energy and time, something that has currency in many different directions.”

## Ric’s tips for developing business acumen and negotiation skills [1:29:30]

*How did Ric develop his business acumen and negotiation skills?*

- Repetition
- *“Intuition is nothing else than having seen something before.*”
- Another key is to be introspective
- After a negotiation, Ric will sometimes realize “I screwed that up, I did not read that cue, I was too aggressive.”

**Self management is the key to success**

–“Self awareness is really important in life, [but] self management is the key to success. Most people are like, ‘I’m self aware.’ But can you self regulate? Can you self manage? . . . It’s the self management part of that that matters.”

*What makes a good negotiator?*

- Good negotiation is when you can find currency that they value more than you do. Then, you find a way to make it work for everybody.
- You can almost play the inverse game. It’s like can you create an impression of something so that you can create value for something so that you can get something else?
- “This is a journey and there’s always someone better than you. I’m in this constant journey in wanting to get better at all aspects of life.”

## What qualities does Ric look for in people he wants to work with? [1:32:50]

*What type of person do you run from in business?*

- “Negative energy and selfishness”

*What are the subtle signs of selfishness in business settings?*

- The use of “I” versus “we”
- Are you taking the credit for things?
- While Ric says it’s okay to want personal success, he’s really looking for people that are really ambitious for something bigger than themselves.
- We all have a competitive drive, for example, but what’s driving your competitive spirit?

**The 3 different types of driven people**:

-1) You’re either driven by competing and killing a competitor

- Think of [Mohammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) … He needed to see the other person stand over them
- This person is a “warrior”
- The warrior, unless they evolve, they know they’ll lose the last battle and so when they lose they will quit

-2) You’re driven by fear of failure.

- Ric recently [interviewed Andy Roddick](https://podcasts.apple.com/us/podcast/becoming-1-andy-roddick/id1449052965?i=1000451859983) in the first episode of his [podcast](https://blog.redventures.com/category/external/3-things/) and you can tell he was driven completely by fear
- The person that is motivated by fear eventually quits due to exhaustion.
- The more successful they become, they know the harder they will fall
- Many will quit before it’s too late
- The **value of success is so much less than the pain of failing**
- **T**hey can’t take to trade anymore…The success became too significant.

-3) The person driven by the process of getting better

- It’s a race against themselves.
- One is a race against somebody, the other one is a race against fear, the other one is a race against yourself.
- I find **people that have that energy have a better balance about it and can run the longer race**.

## What is the next big problem that Ric wants to solve? [1:35:30]

*What problem is Ric interested in solving?*

- Ric points out that there’s no “winning” … you’re just advancing something forward
- One things he’s currently very motivated about is trying to reverse some bad trends in Puerto Rico

A bigger scale problem he’d like to work on: **How to get companies to be a force for good in their communities?**

- I think big businesses are so powerful not just monetarily but as engines of people and problem solving and access to opportunities
- I want us to become a bit of a beacon of like, “Wow, you can be successful AND be good at the same time”

## What is the most challenging part of your business today? [1:37:30]

What are you trying to sharpen your sword in business?

- “I feel like I’m in over my head right now.”
- This is so much fun… I’m trying to run the matrix
- We are in seven industries from financial services to health care to entertainment.
- We’re building a lot of tech and I’m not a techie and we’re a techie company.
- We have 800 engineers and I’m not an engineer.
- 3200 employees
- 200 employees in London, 110 in Brazil
- They’re in all markets.
- Most challenging thing is that RV grew organically for a long, long time.
- But after a number of acquisitions they have now become a “culture of immigrants”
- When your culture is your competitive advantage, which I think 100% it is, and you have added so much newness to it, leading our way through it is really challenging.
- I have no idea what I’m doing. I’m like Forrest Gump. I just show up everyday and I give it all my effort.
- But if it all goes to zero, Ric says he would not care

> “I’ll be super happy if we go to zero. I’ll find purpose in something else. None of this stuff really matters.”

## If Ric could go back and talk to himself in the morning before getting on that plane, what would he say? [1:39:15]

*If Ric could catch himself in the hotel before rushing to the airport to catch his flight on that fateful morning, what would he say to himself?*

“**Don’t miss that flight.**”

> “That was the most remarkable, remarkable gift I ever got. . .it gave me urgency, it gave me purpose, it gave me humility, it gave me a game to play, which is a game of no regrets.”

§

## Selected Links / Related Material

**Ric’s TED Talk**: [3 things I learned while my plane crashed](https://www.ted.com/talks/ric_elias?language=en) | Ric Elias (ted.com) [4:00, 21:45]

**Peter’s TEDMed Talk**: [Is the obesity crisis hiding a bigger problem?](https://www.ted.com/talks/peter_attia_what_if_we_re_wrong_about_diabetes?language=en) | Peter Attia (ted.com) [4:00]

**Ric’s company**: [Red Ventures](https://www.redventures.com/) | (redventures.com) [5:00, 6:45, 1:19:15]

**Peter’s blog post about Ric’s TED Talk and getting to meet Ric**: [TEDMED 2013…now I get it](https://peterattiamd.com/tedmed-2013-now-i-get-it/) | Peter Attia (peterattiamd.com) [5:45]

**The movie based on the miraculous plane crash**: [Sully (film)](https://en.wikipedia.org/wiki/Sully_(film)) | (wikipedia.org) [19:15]

**A company that works with Red Ventures**: [The Points Guy](https://thepointsguy.com/) | (thepointsguy.com) [34:00]

**Scene from Saving Private Ryan where Tom Hanks’ character’s last words to Private Ryan were, “Earn this.”**: [“Earn This . . . .”](https://www.youtube.com/watch?v=YadFEDZPLWU) | RC Schult (youtube.com) [38:30]

**The book which describes life as an “infinite game”**: [The Infinite Game](https://www.amazon.com/Infinite-Game-Simon-Sinek/dp/073521350X) by Simon Sinek | (amazon.com) [45:30]

**Ric related to the movie “Ghost” when watching his daughter’s recital so after his close call with death**: [Ghost (1990 film)](https://en.wikipedia.org/wiki/Ghost_(1990_film)) | (wikipedia.org) [46:30]

**Episode of The Drive with Jason Fried who shared the sentiment that saying “yes” to something is saying “no” to everything else you could be doing**: [#74 – Jason Fried: Optimizing efficiency and work-life balance](https://peterattiamd.com/jasonfried/) | Peter Attia (peterattiamd.com) [51:45]

**DACA is an example of injustice where the system is not working (per Ric)**: [Deferred Action for Childhood Arrivals](https://en.wikipedia.org/wiki/Deferred_Action_for_Childhood_Arrivals) | (wikipedia.org) [1:11:15]

**Organization launched to help DACA kids get through college**: [Golden Door Scholars](https://www.goldendoorscholars.org/) | (goldendoorscholars.org) [1:12:45]

**Organization created to help young adults (18-24 years old) by giving free training in coding, tech, etc.**: [Road to Hire](https://www.roadtohire.org/) | (roadtohire.org) [1:14:00]

**Organization created to help kids in Charlotte who are behind in reading get special help integrated with team sports**: [LifeSports](https://lifesports.org/) | (lifesports.org) [1:14:45]

**Program launched to train Puerto Ricans in an attempt to help revitalized Puerto Rico’s economy**: [Forward 787](https://www.forward787.com/) | (forward787.com) [1:15:30]

**Some of the companies (or “Brands”) that work with Red Ventures**: [1:22:30]

- [The Points Guy](https://thepointsguy.com/)
- [Bankrate](https://www.bankrate.com/)
- [Allconnect](https://www.allconnect.com/)
- [Healthline](https://www.healthline.com/)

**Ric’s podcast**: [3 Things with Ric Elias](https://blog.redventures.com/category/external/3-things/) | (redventures.com) [1:34:00]

- Apple Podcasts: <https://red.ventures/3-things-apple>
- Spotify: <https://red.ventures/3-things-spotify>
- Google: <https://red.ventures/3-things-google>

**Ric’s podcast interview with Andy Roddick**: [Becoming #1 (Andy Roddick)](https://podcasts.apple.com/us/podcast/becoming-1-andy-roddick/id1449052965?i=1000451859983) | (Apple Podcasts) [1:34:00]

§

## People Mentioned

- [Captain Sully Sullenberger](https://en.wikipedia.org/wiki/Chesley_Sullenberger) (pilot of [US Airways Flight 1549](https://en.wikipedia.org/wiki/US_Airways_Flight_1549)) [13:00, 29:30]
- [Oprah Winfrey](https://en.wikipedia.org/wiki/Oprah_Winfrey) [31:30]
- [Tom Hanks](https://en.wikipedia.org/wiki/Tom_Hanks) (“earn this” from Saving Private Ryan) [38:30]
- [Simon Sinek](https://en.wikipedia.org/wiki/Simon_Sinek) (author of The Infinite Game) [45:30, 1:37:00]
- [Patrick Swayze](https://en.wikipedia.org/wiki/Patrick_Swayze) (Ghost movie) [46:30]
- [Demi Moore](https://en.wikipedia.org/wiki/Demi_Moore) (Ghost movie) [46:30]
- [Doug Flutie](https://en.wikipedia.org/wiki/Doug_Flutie) (famous Boston College football player) [1:03:15]
- [Dan Feldstein](https://www.redventures.com/leadership.html) (cofounder of Red Ventures) [1:20:30]
- [Meg Whitman](https://en.wikipedia.org/wiki/Meg_Whitman) [1:23:00]
- [Andy Roddick](https://en.wikipedia.org/wiki/Andy_Roddick) (someone driven by fear) [1:34:00]
- [Milton Friedman](https://en.wikipedia.org/wiki/Milton_Friedman) [1:37:00]
- [Forrest Gump](https://en.wikipedia.org/wiki/Forrest_Gump_(character)) (who Ric feels like when running his company) [1:38:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/11/bio-pic-ric-elias-500x500.png)

##### Ric Elias

Ric Elias was given the gift of a miracle: to face near-certain death, and then to come back and live differently.

A native of Puerto Rico, Elias attended Boston College and Harvard Business School before starting his career as part of GE’s Financial Management program. He cofounded Red Ventures in 2000, just months before the dot-com bubble burst. The company weathered the storm; by 2007 it was ranked fourth on the *Inc.* 500 list, and in 2015 the company was valuated at more than $1 billion. Elias has cultivated an award-winning company culture, ranking as a “Best Place to Work” in Charlotte, North Carolina, for ten years in a row.

Elias’s leadership style and personal life are deeply influenced by his experience as a survivor of Flight 1549, also known as the “Miracle on the Hudson.” He is devoted to using his platform to “leave the woodpile higher than he found it” — spinning out multiple nonprofits from Red Ventures over the years, all of which are aimed at creating educational opportunity and economic mobility for under-served groups. In 2018, Elias launched Forward787, a social enterprise committed to raising and deploying $100 million to build businesses in Puerto Rico that compete with the world’s top companies. In 2019, he launched a podcast, *3 Things with Ric Elias*, as a continuation of the learning journey he shared on the TED stage. [[ted.com](https://www.ted.com/speakers/ric_elias)]

**Twitter**: [@RicElias](https://twitter.com/ricelias?lang=en)