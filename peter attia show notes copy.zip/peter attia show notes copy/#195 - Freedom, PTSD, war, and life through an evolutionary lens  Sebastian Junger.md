# #195 – Freedom, PTSD, war, and life through an evolutionary lens | Sebastian Junger

**Source:** [https://peterattiamd.com/sebastianjunger/](https://peterattiamd.com/sebastianjunger/)

---

Sebastian Junger is an award-winning journalist, documentary filmmaker, and New York Times best-selling author. In this wide-ranging discussion, Sebastian shares stories from his time as a war reporter and how it shaped his understanding of the psychological effects of combat, including the sacred bond of soldiers, the forces that unify a tribe, and the psychological mechanisms that protect humans from painful experiences. He draws upon his personal struggle with PTSD as he discusses trauma as an all-too-common consequence of war and the importance of community in the healing process. He explains his interest in viewing human behavior through an evolutionary lens, including how it influences his parenting style, and he voices concerns over society’s continuous shift away from our evolutionary roots. Sebastian also tells the story of his near-death experience and his new perspective on the possibility of an afterlife.  Additionally, Sebastian shares his thoughts on the mental health implications of current events, such as the pandemic and the withdrawal of troops from Afghanistan, and contemplates what it really means to be “free” in modern society.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/sebastianjunger/the_Drive_public.png)

Play

#195 - Freedom, PTSD, war, and life through an evolutionary lens | Sebastian Junger

#195 - Freedom, PTSD, war, and life through an evolutionary lens | Sebastian Junger

1x15s30s

0:002:57:01

## We discuss:

- Sebastian’s upbringing and early lessons about the evil of fascism [3:20];
- Sebastian’s search for a career, interest in writing, and what he loved about tree removal [11:30];
- How Sebastian became a great writer [19:30];
- Sebastian’s experience with Achilles injuries [25:30];
- Work as a war reporter and his experience in combat in Afghanistan [28:00];
- Psychological effects of war and Sebastian’s own experience with PTSD [36:30];
- The sacred bond of soldiers and what Sebastian learned from his time with troops in Afghanistan [48:30]
- An evolutionary perspective on the forces that unify and bind tribes [1:00:00];
- Hunter-gatherer societies, dealing with loss, and the ancestral connection to the spiritual realm [1:08:30];
- Psychological mechanisms that protect humans from painful experiences and the power in giving thanks [1:13:15];
- How parenting has changed Sebastian, and the incredible pain of losing a child [1:21:15];
- PTSD and the influence of community on healing [1:32:15];
- Isolation of modern society and the debate over young kids sleeping in bed with their parents [1:37:45];
- Why Sebastian doesn’t own a smartphone [1:43:30];
- Parenting through an evolutionary lens [1:50:00];
- Sebastian’s near-death experience and new perspective on the possibility of an afterlife [1:54:00];
- Sebastian’s experience with depression and anxiety [2:12:00];
- The pandemic’s impact on mental health [2:16:45];
- Sebastian’s thoughts on the withdrawal of troops from Afghanistan [2:22:00];
- Sebastian’s latest book—Freedom, and knowing when to quit [2:27:00];
- Defining freedom in modern society [2:44:30];
- More.

§

## Show Notes

**\*Notes from intro**

- Sebastian is a *New York Times* bestselling author of [Tribe](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638299921&sr=1-3), [The Perfect Storm](https://www.amazon.com/Perfect-Storm-True-Story-Against/dp/039304016X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638300138&sr=1-6), [Fire](https://www.amazon.com/Fire-Sebastian-Junger/dp/0393010465/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638300138&sr=1-7), [A Death in the Belmont](https://www.amazon.com/Death-Belmont-Sebastian-Junger/dp/0393059804/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638299921&sr=1-5), and [War](https://www.amazon.com/WAR-Sebastian-Junger/dp/0446556246/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638299921&sr=1-4)
- His newest book, [Freedom](https://www.amazon.com/Freedom-Sebastian-Junger/dp/1982153415/ref=sr_1_2?keywords=sebastian+junger&qid=1638299921&qsid=131-3146834-4509605&s=books&sr=1-2&sres=1982153415%2CB01D57FNZG%2C044655622X%2C0060742690%2C0393337014%2C0060088613%2CB005YPJ5CU%2CB089V1XS2P%2C1633885704%2CB09BDDV5P2%2CB00HI9K7BI%2CB01IIW6NJI%2CB01JXTW10A%2C1982159006%2CB00A7GZ9KS%2CB07N6MPWLS&srpt=ABIS_BOOK), came out in May of this year, and we spend some time talking about it
- Sebastian is also an award-winning war reporter and journalist who has covered major international stories around the world
- He is also a documentary filmmaker whose debut film, [Restrepo](https://en.wikipedia.org/wiki/Restrepo_(film)), was nominated for an Academy Award
- His other documentaries include [Korengal](https://www.imdb.com/title/tt3578504/?ref_=fn_al_tt_1), [The Last Patrol](https://www.hbo.com/documentaries/the-last-patrol), [Which is the Way to the Front of the Line From Here?](https://www.imdb.com/title/tt2480784/?ref_=fn_al_tt_1), and [Hell on Earth: The Fall of Syria and the Rise of ISIS](https://www.imdb.com/title/tt6794398/?ref_=fn_al_tt_1)
- Peter notes, “*I’ve wanted to interview Sebastian for a while, in fact, ever since reading his book Tribe, which I think I read in 2016 or 2017. And while this is a bit of a different interview compared to a lot of the interviews I do on the podcast, I really wanted to speak with him for a couple of reasons.*”
  - He wants to talk about his very unique life experience and his philosophy of life, which is actually something he only learned about in the prep for this podcast
  - Tribe is a book that he’s thought a lot about in terms of understanding the importance of community in people’s mental health and how it plays into their longevity, of course.
- We talk about his upbringing and how it led him to his career as a war reporter
- We talk about the psychology of war and the PTSD that he saw many around him experience, and that he experienced, although at the time he didn’t really understand that that’s what it was
- From there, we talk about his philosophy on life, what having kids has meant to him, and how he has parented his kids in a way that I think is a little bit non-traditional
- We spoke about his near-death experience
  - This is something he’s spoken about on other podcasts, but here we went into a little more detail
  - We talk about out how this changed him for the better and the worse, and how it led to the new book that he’s writing on what’s going to happen when you die
- We spoke about his trauma and his past depression
  - Why he only uses a flip phone
  - Social media as an addiction
  - The importance of the tribe and the dangers of isolation
- We end our conversation speaking about his newest book, *Freedom*, and the documentary that it’s based on, *The Last Patrol*
  - We talk about what it means to be free and how we know when to quit

## Sebastian’s upbringing and early lessons about the evil of fascism [3:20]

**Sebastian’s Dad**

- Sebastian grew up outside of Boston in a little town called [Belmont, Massachusetts](https://en.wikipedia.org/wiki/Belmont,_Massachusetts)
- His dad was a refugee from 2 wars
  - He grew up in Europe
  - He was a journalist in Europe
  - He lived in Spain, and then they fled to France when the fascists came in in 1936 under [Franco](https://en.wikipedia.org/wiki/Francoist_Spain)
  - His dad’s family was Jewish
  - Then when the Nazis came in a few years later, they fled to the United States
  - His dad made his life here, met my mom, and tried to join the U.S. military, and couldn’t because he had asthma, so he served the country in other ways
  - He was a physicist, and he contributed to a lot of important projects which involved the U.S. military and the U.S. government
  - He was enormously grateful to this country for our sacrifice in World War II
  - It’s interesting that his implacable pacifism was also mixed with an understanding that sometimes force is necessary to protect humanity from fascism and other evils
  - So he had a very complex sort of understanding of our duties as citizens and our place in the world as America

Peter asks, “*how old were you when some of those lessons started to mean something more than just the words that were spoken? And did he communicate through direct words or more indirect means?*”

- When Sebastian grew up, the word fascist was a dirty word
  - He grew up knowing that that was the ultimate evil, and America stood diametrically opposed to fascism, that we were the opposite of fascism
  - America was the ultimate anti-fascist state
- He  grew up during [Vietnam](https://en.wikipedia.org/wiki/Vietnam_War) and in a very liberal environment
  - So every adult he knew, everyone I knew was anti-Vietnam, anti-war, and by extension, though not fairly, were anti-U.S. military
- He was born in 1962; so in 1980, he turned 18 and got a card in the mail from the U.S. government saying, “*You’re an 18-year-old male. We need to know where you live, physically what your address is, in case we need to call you into combat*.”
- So he was very surprised and learned a lot when he said to his dad back then, “*What the hell is this? The draft is over. What do you mean, my government needs to know where I am? It doesn’t need to know where my sister is, but where I am in case they need me to fight one of their wars?… I’m not signing this*.”
  - His dad was a pacifist
  - He expected my father to wholly approve that he wasn’t going to sign this
  - Instead his dad said, “*No, you’re definitely signing it.*” He’s like, “*You don’t know what the next war is going to be. It may be a war that needs to be fought, like World War II was. You don’t owe your country nothing; you owe it something. And you may owe it your life, depending on the circumstances. If a war comes along that you feel is immoral and unnecessary, then it’s your duty to protest, and go to prison, if you need to, to protest it. But you don’t know that yet. You’re going to sign that card because you are part of this country, and it’s a magnificent thing to be part of.*”
  - That completely turned around Sebastian’s thinking about what it means to be an American citizen and a human being and to be part of a community
    - 35 years later, he’s still “chewing over that one”

**His Dad’s thoughts on the Vietnam War**

- Peter asks if his dad viewed Vietnam as a different war from World War II; obviously it was, but what did he say
- His dad said it was unnecessary and the specter of communism taking over the world
  - He said that the [Gulf of Tonkin](https://en.wikipedia.org/wiki/Gulf_of_Tonkin) was a straight-up lie
  - Unlike [9/11](https://en.wikipedia.org/wiki/September_11_attacks), Vietnam started with a straight-up lie
  - They got us into a war that everyone knew was unwinnable and a lot of people thought was not needed, which was very different from 9/11 and from World War II, as far as my dad was concerned
  - So he hated the Vietnam War and was very adamant about it, as was every other adult I knew
    - It speaks to the community he was in
    - He could have grown up somewhere else, and it would’ve been the opposite
- Peter notes, this speaks to his dad’s ability to balance seemingly simultaneous contradictory facts
  - Vietnam ends in ‘74 or ‘75 and 5 years later Sebastian gets a card that is effectively a draft card and his dad can immediately pivot and say “this is very important; I can put Vietnam out of my mind”
  - There’s a [recency bias](https://en.wikipedia.org/wiki/Recency_bias) that could have easily sounded like, “*I don’t want my son being one of the boys that got slaughtered there for no reason.*”
  - His Dad also made it clear that if the war is immoral, it was his job to go to prison to protest it

**The holocaust**

- His dad was half Jewish and he’s a quarter Jewish but he doesn’t identify with the Jewish culture
  - But the [Holocaust](https://en.wikipedia.org/wiki/The_Holocaust) seared itself into the minds of humanity in the 1940s and the sacrifice of American soldiers
  - Now, America acted out of its own interest and thought process; it didn’t join World War II because of the Holocaust
  - But the fact is that there are tens of thousands of American troops buried in France, his dad’s home country of France, stopping fascism, making sure that fascism did not take over Western Europe and the world
  - His dad has seen the graves of American soldiers, young men his age
- The Germans  took Paris without a fight; it was a negotiated surrender
  - They sent advance units and tank columns deep into France to grab the Spanish border; across the border with Franco, it was a friendly fascist regime
  - His father and family fled by car
  - They were in Bion; he was 18 and walking down the street when he saw a German officer on foot in front of a column of tanks, creeping down a boulevard
  - The officer asks his family the way to the center of town; but they didn’t know or have maps
  - His father spoke German; he spoke just about every language in Europe because they lived all over the place
    - His father was born in [Dresden](https://en.wikipedia.org/wiki/Dresden)
  - The German officer was speaking bad French
    - His father spoke back to him in perfect German and lied to him and said, “*Yeah, the center of town is that way*”, and pointed the entire tank column in the opposite direction, and off they went
    - So that was his little act of rebellion
    - At the time his dad said, “*Don’t ever be that stupid again, because they will kill you. If he found that out, he would’ve killed you right there.*”
  - That kind of experience didn’t leave him, and Sebastian’s dad thought the foremost threat to freedom and human dignity and the human race was fascism
  - So Vietnam was a blip in the screen with that; fascism was it and it still is it
  - This country has gone through a little taste of it, and we came out, hopefully, stronger; but that bogeyman has not gone away in human society

## Sebastian’s search for a career, interest in writing, and what he loved about tree removal [11:30]

Peter asks what Sebastian studied in college

- Sebastian’s dad was a physicist, but he was very enamored of history and of anthropology
- Sebastian grew up reading anthropological works; he was very interested in the Native American societies
- He was also a really good long-distance runner in high school and college
  - He ran 4:12 for the mile and went on to run a 2:21:00 marathon
  - He was not world-class, obviously, not even close, but was a pretty good runner
  - He found out in college that the [Navajo](https://en.wikipedia.org/wiki/Navajo) were really good long-distance runners
- In college, he wasn’t there to get a career; instead, he was there to learn stuff that interested him
  - He majored in anthropology, and decided to do field work on the Navajo reservation
  - He went out there in 1983 and spent a summer on the reservation training with their best guys
  - He wrote a thesis on Navajo long-distance runners; that was his first work of journalism; it was the first time he researched something and then wrote about

**His search for a career**

- When he got out of college he did construction for a little while, trying to figure out what he was going to do
- He was sponsored by Etonic running shoes at the regional level; he was running local road races
- He thought maybe he would be a journalist
  - When he was writing his thesis, he just loved it; he was just on fire

> “*It was a long, tortuous path to get there, but that was my naive decision when I was 21*” – Sebastian Junger

- Peter asks when he had a logging job; he heard him discuss this on an interview years ago
- It was post-college; he was in his late 20s
- Fast forward some years out of college, he still had not figured it out
  - He was trying to be a writer, trying to be a journalist
  - Basically, he didn’t have a clue
  - But he was reading a lot of great writers— Peter Matthiessen, [Joan Didion](https://en.wikipedia.org/wiki/Joan_Didion), [Ernest Hemingway](https://en.wikipedia.org/wiki/Ernest_Hemingway)
  - And he was writing and writing and writing, and occasional getting things published
  - He was turning into a better writer, but he couldn’t make a living
  - He was sick of waiting tables
  - He got a job as a climber for tree companies; it wasn’t logging, it was residential tree work
    - Without a crane, they needed a guy up in the tree on a rope with a chainsaw
    - He was a pretty athletic young man and took to it very quickly; he was good at it
    - Basically, he was swinging around on a rope with a pair of climbing irons strapped to his feet, with a chainsaw
    - He was taking down these big trees, some of them 100 feet tall white pines; topping them out and taking them down in a small space
- Peter points out how familiar he with with this process; his middle child (who just turned 7) is obsessed with this process
  - There’s this series on YouTube called [Pine Tree Removal Part 1,](https://youtu.be/e2_RpyZk_kg) [Part 2](https://youtu.be/2V37kVQM9LM), and [Part 3](https://youtu.be/Eb0STCE8nPc)
  - In all, it’s a 6-hour series focused on taking down a 120-foot pine tree in a subdivision between 2 houses that are 30 feet apart
  - Hi son has seen this entire series 30, maybe 40 times; so by extension, he’s seen it 3 times
  - When his son turned 5, he wanted a chainsaw for his birthday
    - He was so upset that he didn’t get it
    - Peter tried to explain to him, “*Dude, you’ll kill yourself with this thing*”
    - He replied, “*I will not. I know how to use this thing*”; he was convinced he knew how to use it because he’d watched so much pine tree removal
    - So Sebastian would literally be his hero
- Sebastian recounts a story of his friend who runs a tree company, and this friend would send his daughter up on a climbing rig, using a little harness and ropes the way climbers would when she was 7 or 8 years old
  - She learned how to work her way up a rope and rappel back down all of maybe 6 feet off the ground; it was safe
  - He suggests that Peter find an arborist in his town to rig something like this up for his son
- Peter’s compromise with his son was to get him a [Gomboy](https://silkysaws.com/silky-gomboy-curve-folding-saw/), a big saw when he was 5
  - His son figured out how to use it without killing himself; now he runs around the woods with a  saw that’s almost as long as him, trimming every dead branch
  - When people come over and see it, they think Peter is a terrible parent to let a little kid use such a big saw
  - But his son has a healthy respect for it and will be using a chainsaw before the age of 16 (which is when Peter told him he could have one)
- Sebastian recalls that he had to control his fear of heights to work high in the air in trees
- He chose this job because he could make $500 or $1,000 bucks a day back in the early ‘90s
  - If he contracted his own job and did the climbing, he could make pretty big money
  - So he could work a couple of times a week, and the rest of the time he could train, write, or do whatever he wanted
  - For a young man, it was a perfect job; he wasn’t without anxiety and fears, but he has a fairly high risk tolerance
  - In tree work, he figured there were no accidents; just like there are no accidents in the game of chess
    - In poker, one might just draw the wrong card, but there are not accidents in chess; if one loses the game it’s because they made worse moves than the other guy
    - If one gets hurt or killed doing tree work, it’s because they screwed up
    - It’s all about the laws of physics; they’re immutable
    - If the front cut is done wrong it comes back on you, it’s because you did it wrong and you didn’t take into account the wind direction
    - There are no variables that are outside of one’s control
    - One’s own stupidity or carelessness is the only thing outside of your control
    - When he figured that out, he thought, “*I’m just going to make sure I don’t screw up*”
- He screwed up once, and hit his leg with the chainsaw and tore it up; it took a while to recover from that
  - That was the injury he needed; after that, he actually wouldn’t be that scared up there because he knew, although it was sometimes terrifying to look down, he knew that he was way safer there than in a car (ironically) as long as he didn’t make a mistake

“*Having that kind of agency over an outcome, unlike driving, unlike combat, unlike a lot of things, that kind of agency was very exciting to have. It gave me a kind of Zen focus in the moment like, ‘You are here right now. Do not blow this.’ That kind of practice was extremely good for me.*” – Sebastian Junger

## How Sebastian became a great writer [19:30]

- Peter asks about the process by which he became a better writer
  - Peter enjoys writing but isn’t very good at it yet; he’s getting better, and is better now than he was 10 years ago
  - He asks, “*Is it something that can be done in isolation, or is it something that requires an editor or someone who can really sharpen your sword?*”
- There are some writers who basically dump out an incredibly rough first draft
  - In their description, sort of vomit it out
  - Sentences aren’t even complete
  - It’s a very sloppy, fast, intuitive brain dump
  - They can do that for 500 pages, and then they go back
  - These people make really good use of an editor who can work through his writing and see how to begin to shape it
- Sebastian doesn’t do this
- He’s sort of like a road paver; he goes 2 miles an hour and leaves behind a pretty much finished roadway
  - Not that editors don’t weigh in at the sentence level like, “*This is slightly confusing*”
  - But he gets very little editing from his editors
  - This is because he’s so obsessive about writing, and he will go over it and over it and over it, and write very carefully
  - The stuff that he writes is definitely flawed, but not that flawed
- He has this feeling… for him, good writing is a matter of efficiency
  - Not quite the minimum possible words, but something close to that
  - Fat creeps into prose very easily, and he can really pare it down
  - It’s about efficiency, and it’s about rhythm; the sentences need rhythm

> “*It’s about saying things in a way that people have never read before*” – Sebastian Junger

- No one ever needs to read a sentence they’ve read before in someone else’s writing
  - If one applies this harshly, they will get rid of a lot of what they wrote
  - It’s amazing how much it’s slightly formulaic and repeating
  - Mortars are always slamming into hillsides, and blah, blah, blah; get rid of that stuff.

> “*Rhythm, efficiency, and originality. And if you do that, it’s going to be pretty good writing*.” – Sebastian Junger

**Rules of journalism and non-fiction writing**

- - Peter notes that so much of Sebastian’s work is telling amazing stories; he asks, “*Do you think journalism and storytelling are similar styles?*”
  - Sebastian replies that he writes longform journalism or longform nonfiction
  - First of all, there is no nonfiction category that is liberated from the rules of journalism, in terms of quote attribution and making stuff up or whatever
    - It’s either true or it’s not true
    - One can’t blend them, because then suddenly everything’s going to be suspect
  - Some great books have wove in stuff that was not the result of research, such as [Truman Capote](https://en.wikipedia.org/wiki/Truman_Capote)’s absolute masterpiece, [*In Cold Blood*](https://www.amazon.com/Blood-Modern-Library-Nonfiction-Books/dp/0812994388/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1639412220&sr=8-1)

- He richly imagined some scenes; no problem; it’s a master work

- But it’s important to understand that it’s actually is *not* nonfiction and it’s *not* journalism

- There’s a whole food chain of journalism
  - There’s a Reuters or AP report that’s written in minutes or maybe an hour; it basically doesn’t have a literary style
    - There’s a lead paragraph and the follow-up and whatever
  - There’s a whole formula to how to construct something that’s packed with information and completely charmless in a literary sense
  - But one doesn’t want charming writing when you’re reading about how [Harare](https://en.wikipedia.org/wiki/Harare) fell to the rebels; one just wants the information
- Then there’s more longform journalism, where one can even use the first person, sparingly
  - One is allowed to be a little bit more scene-setting
  - One can use some novelistic techniques with content which is completely true and real
  - The novelistic techniques might be taking a break at a compelling moment right before the rebels attack the city
    - Take a break and do 1,000 words of backstory about the history of Zimbabwe or whatever, and then resume where the action stopped
  - Those are all novelistic techniques that are great for getting people to read nonfiction
  - It’s making use of factual material, not invented material
- Sebastian is a longform nonfiction writer, and for him, a book is longform nonfiction
- Some of his books can be read in a couple of hours; some of his books can be read in a couple of days
  - But basically it’s all the same rules and creative tools of getting people to read good narrative journalism

## Sebastian’s experience with Achilles injuries [25:30]

**Accident with a saw**

- Fast forward to the late ‘80s, Sebastian injured his [Achilles tendon](https://en.wikipedia.org/wiki/Achilles_tendon)
- He was up in an elm tree in [Waltham, Massachusetts](https://en.wikipedia.org/wiki/Waltham,_Massachusetts); it wasn’t even that high
  - He was in a hurry and hadn’t worn his boots that day because he wasn’t going to be wearing climbing irons; so he just had sneakers on
  - He was cutting something below himself, quickly, one-handed with a little climbing saw
  - The tip of the saw hit the tree, and it popped into the back of his leg and it tore open right across the Achilles tendon; it tore open his leg
  - So he turned the saw off
  - It didn’t hurt at all; he thought, “*Something hit my leg. There’s nothing else moving down there but the saw. I better check, just make sure I’m not cut.*”
  - He turned the saw off, clipped it on, looked, and of course, his leg was hanging open
  - So he pulled his leg up as close as I could to see if the Achilles was intact or not
  - He was very concerned about the Achilles
    - Now, keep in mind, had it been someone else’s leg… he’s not a doctor or a medic, he wouldn’t have looked inside their chainsaw wound to see if the Achilles was intact, but immediately he’s in shock
    - There’s this psychological remove when one is hurt, and he had no problem pulling the cut open and looking for his Achilles
  - It seemed to be there; it was about the thickness of a number two pencil and was a whitish color
  - So he rappelled down to the bottom of the tree, and his crew helped him to the car and drove him to the hospital
- His Achilles was intact; as a runner, that’s a big deal

**Achilles rupture in combat in Afghanistan**

- He did rupture his Achilles in combat, when he was in my mid-40s
  - When he was in the [Korengal Valley](https://en.wikipedia.org/wiki/Korangal_Valley) in eastern Afghanistan, he was moving up a hillside under a big load and  felt something slap into the back of his leg
  - There was a lot of long-distance sniper activity
  - One doesn’t necessarily hear the bullet that hits you; and he thought, “*Oh no, I got shot. I got shot in the back of the leg. Dammit.*”
  - He pulled the pant leg up, and there was no blood
  - He had no idea what had happened, but it was a partial rupture of his Achilles
  - He limped on it for a few days, and then it kind of healed back together a bit and he was able to continue my embed, which was about another month or so
  - He babied it a little bit and scraped by
  - He got physical therapy eventually and it healed it
  - Apparently, the malaria medication that they were giving soldiers, [Lariam (mefloquine](https://en.wikipedia.org/wiki/Mefloquine) is the medical name) makes people prone to Achilles tendon ruptures
    - Who knew? They were all on Lariam out there
    - Peter notes this is also a side effect of [fluoroquinolones](https://en.wikipedia.org/wiki/Quinolone_antibiotic), which are a class of antibiotics, ciprofloxacin being the one that most people are familiar with
    - This is also a side effect of aging

## Work as a war reporter and his experience in combat in Afghanistan [28:00]

![](https://peterattiamd.com/wp-content/uploads/2022/02/afghanistan-restrepo-junger-1024x683.png)

**Figure 1.** Sebastian, left, and Tim Hetherington during the filming of their documentary “Restrepo” in 2007. *Credit:* [*sandiegouniontribune.com*](https://www.sandiegouniontribune.com/entertainment/books/sdut-sebastian-junger-tribe-interview-2016jun03-story.html)

**The pain of heartbreak leads him to freelance war reporting**

- Peter asked when Sebastian realized he wanted to be a journalist that went into the theater of combat
- Sebastian was living in [Gloucester, Massachusetts](https://en.wikipedia.org/wiki/Gloucester,_Massachusetts), and the storm that he wrote about in [*The Perfect Storm*](https://www.amazon.com/Perfect-Storm-True-Story-Against/dp/039304016X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638300138&sr=1-6) hit that town in 1991
- He was still limping around from his chainsaw injury
- He was living with his girlfriend, and he’d never lived with a woman before
- The relationship ended, and ended pretty painfully
- And maybe it was some sort of weird male reaction to heartbreak, he thought “*All right, I’ll show her. I’m going to go to a war.”*
  - It was just some bizarre… there was a civil war in Bosnia, and he decided, “*All right, we’re broken up. I’m going to go to a war zone and learn to be a war reporter*.”
- He was looking for a big life change
  - He was looking for something that felt meaningful and exciting
  - Something that would challenge him, challenge his mind, complete the maturation process
  - He thought maybe an ordeal like war would put him over the threshold into adulthood and into manhood
  - 80% of the other male freelancers over there had all been dumped by their girlfriend; it seemed to be a common reaction for some reason
- He started freelance war reporting in Bosnia as a radio correspondent, and then he wrote his book [*The Perfect Storm*](https://www.amazon.com/Perfect-Storm-True-Story-Against/dp/039304016X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638300138&sr=1-6)
- Two days after he turned it in, he took a flight to [Delhi](https://en.wikipedia.org/wiki/Delhi), and then on into [Peshawar](https://en.wikipedia.org/wiki/Peshawar), and on into [Afghanistan](https://en.wikipedia.org/wiki/Afghanistan)

**Afghanistan**

- It was 1996, and there was a [civil war in Afghanistan](https://en.wikipedia.org/wiki/Afghanistan_conflict_(1978%E2%80%93present)) after the Soviets pulled out
- He was there as the [Taliban](https://en.wikipedia.org/wiki/Taliban) were taking over in the summer of 1996
  - That was his first official war assignment for a magazine in New York city
- It just was the most meaningful, incredible work he’d ever imagined
  - So he kept doing it
- Peter asked what his dad thought of this work
- His dad was proud of him; he was also worried
- His mom, maybe in a classic way, was like, “*Why are you doing this to me?*”
  - She thought his war reporting was directed at her to make her upset.
  - His father didn’t take it that way; he was kind of proud and worried, but also war had completely shaped his life and his family’s life in Europe
  - Sebastian told them, “*Look, war, it’s a part of human society. It’s a part of history. I want to understand what it is, what it’s like, how it works, how I’m going to react in that environment.”*
    - He didn’t find all of that out in Bosnia, but it was the beginning of a process
- The Soviets pulled out in late 1989 after 10 years
- Their proxy government collapsed after a couple of years
- It was a lapse into civil war that was brought to a stop by the Taliban takeover
- In 1996, the Taliban were a religiously inspired political movement that was basically the brainchild of the [ISI, the Pakistani Secret Service](https://en.wikipedia.org/wiki/Inter-Services_Intelligence)
  - This was their way of controlling Afghanistan and giving Pakistan what they called a strategic depth in their fight with India
  - So basically, if they controlled Afghanistan, they would always have a fallback position to fight from in case India invaded them, which was a threat, a possibility
- But the Taliban had [Sharia law](https://en.wikipedia.org/wiki/Sharia); it was incredibly harsh
  - They were stoning adulterers and not letting women go out of the house without a male escort and all kinds of ghastly policies that frankly we see in other allies, like [Saudi Arabia](https://en.wikipedia.org/wiki/Saudi_Arabia), and it doesn’t seem to bother anyone
  - It’s ghastly, wherever it is, whether it’s a US ally or not, it’s all despicable
- He eventually wound up in 2000 in the last quadrant of the country that had not been taken over by the Taliban
  - It was being defended by [Ahmed Shah Massoud](https://en.wikipedia.org/wiki/Ahmad_Shah_Massoud), the legendary guerrilla fighter against the Soviets, and he had organized the [Tajiks](https://en.wikipedia.org/wiki/Tajiks)
  - He was ethnic Tajik; he organized the Tajik and some other allied demographics to hold off the Taliban in this one quadrant of Afghanistan in the Northeast
  - Sebastian was with Massoud in the fall of 2000s as he fought the Taliban

**Profound impacts of war**

- This was big stuff; there were tank battles; there were masked infantry assaults and entrenched positions on ridge tops
  - It was a very, very intense war and extremely traumatic to him
  - He came back very affected by it psychologically and not even knowing he had [PTSD](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder) because that term was not being used yet
  - He  just thought he was going crazy
- But he got back to New York after those two months and was pretty nuts
  - He couldn’t take the subway
  - He couldn’t be in a small crowded space
  - He freaked out in a ski gondola
  - He just had reactions to things he never associated with combat, but it was clearly a by- product of what he experienced
  - He got very angry; he had a short fuse; he cried a lot
  - He had all the classic symptoms; he just didn’t recognize them
- [Massoud](https://en.wikipedia.org/wiki/Ahmad_Shah_Massoud) was killed two days before 9/11
  - Peter comments on the details of his death, “*it’s just hard to believe he kind of fell for that trick. Were you surprised? It just seems like such a ploy that was so transparent in a way, but maybe that’s only true in hindsight*”
  - Massoud relied on other people to keep him safe and people can get paid off a
    - Sebastian doesn’t know the details, but yes, it was a movie camera filled with explosives and there were two Al-Qaeda suicide bombers that were posing as journalists, and they asked to interview him and they blew themselves up
    - One actually survived the blast and tried to run away; he was gunned down
    - There was another young man who was a translator, who was in the room, [Fahim Dashti](https://en.wikipedia.org/wiki/Mohammad_Fahim_Dashty)— a very, very brave young man who worked in a film office that Massoud set up to document his efforts against the Taliban and against Al-Qaeda, and as my father would have put it, against fascism
      - The Taliban caught him last week in the [Panjshir Valley](https://en.wikipedia.org/wiki/Panjshir_Valley), north of [Kabul](https://en.wikipedia.org/wiki/Kabul), and executed him for his work with Massoud; 20 years later
      - There were 4 men in that film office working for Massoud, documenting the war against the Taliban, and they caught Fahim Dashti and executed him just a week ago— tragic

**Back to Afghanistan**

- After Massoud was killed, two days later, 9/11 happens
  - Clearly part of the same strategic thinking by Al-Qaeda
- And as soon as he could, he rushed back to Afghanistan through [Dushanbe](https://en.wikipedia.org/wiki/Dushanbe) in [Tajikistan](https://en.wikipedia.org/wiki/Tajikistan), and joined the commanders he’d been with the year before
  - And he was sleeping in his clothes on a frontline for a month straight until the American bombers had done their work
- And then the [Northern Alliance](https://en.wikipedia.org/wiki/Northern_Alliance)… he never saw an American soldier
  - There were a few Special Forces guys out there, but it was all Northern Alliance foot soldiers
  - They broke through the Taliban frontlines on November 13th, 2001 (he thinks), and they followed them in the back of a pickup truck
  - They walked into Kabul the following morning, passed a pile of dead bodies, and walked into Kabul
  - The jubilation by the populace being liberated from the Taliban was indescribable
  - When people found out he was American, they would come up and hug me for what our country did to liberate them from the Taliban
  - It was an extraordinary moment for him as a person, but he was so filthy
    - They smelled so bad after a month sleeping in the frontlines that when they tried to get a taxi in Kabul, the driver would not take them;
    - They walked across Kabul and found a place like a hotel where they could stay in the chaotic first moments of liberation

## Psychological effects of war and Sebastian’s own experience with PTSD [36:30]

- Peter turns the conversation back to what caused Sebastian’s first bout of PTSD
  - He has seen Sebastian’s documentaries, so he has a sense of what it was like but there are some people listening who don’t
  - Reporting in a war is very different from reporting from Wall Street
  - There’s a distance between the reporter and their subjects in most other forms of reporting that can’t really exist in a war, if for no other reason, than the reporter is literally, physically with their subjects
  - Putting the danger aside for a moment, is there another example in journalism where the reporter is embedded with the subject matter?
- Sebastian notes a reporter can have an emotional connection to anybody
- There are 2 issues:
  - 1) The emotional connection
    - This can occur with anybody: frontline nurses, cops, sanitation workers, teachers, etc.
    - One can be connected to people and affected by their emotional reality because they start to share it and invest in them and become empathic to ehm… sensitized to their issues
    - It’s a powerful experience
  - 2) In war, anywhere near the frontline, one is exposed to risk
    - This is a risk that isn’t found in other places
    - This is also exposure to human suffering

“*Human suffering is incredibly traumatic to behold, particularly if you yourself feel removed from it*” – Sebastian Junger

**Trauma in Liberia**

- One of the hardest things that ever happened to him psychologically was when he was in [Liberia](https://en.wikipedia.org/wiki/Liberia) during the Civil War and a mortar round landed in a crowded field of refugees who had fled the fighting and crammed into [Monrovia](https://en.wikipedia.org/wiki/Monrovia)
- At the time, he was sort of in hiding; the government thought he was a spy
- So he was having his own terrifying thing go on because he thought they might torture or kill him if they caught him
- A mortar landed right in the middle of this field full of people, men, women, children, and killed 27 people, a lot of them children.
- When the mortar hit, he was out; he hit the ground
- It was a bad situation; he was very, very close
- And sometime later, they piled the bodies up in front of the US Embassy as a protest that America was not invading
- They wanted America to invade Liberia and stop the war
  - That was what the populace wanted
- He walked past the bodies on his way into the embassy because he was trying to get evacuated; he was in so much danger
  - And he stopped and his mind just went blank
- It’s hard even now for him to talk about it, and it was almost 20 years ago
- There were children
- He went into shock and didn’t know what to do
  - He started counting them and thought someone needs to know what this number is— it was 27
- So later, the trauma to him was that he’d had no emotional reaction to such a horror
  - He was completely in shock; it was a completely abstract thing
  - This was his psychological defense, and that psychological defense broke down a week or two later when he finally got out to Paris and got to safety

**Sebastian’s first panic attack**

- He was sitting in a café waiting for his girlfriend who was joining him in [Paris](https://en.wikipedia.org/wiki/Paris); he had a couple of days to kill
- While smoking a cigarette at the cafe, he saw two men carrying a mattress across the street and it sort of sagged in exactly the same way that a body does
  - And he just went into a full blown panic attack because he knew he was looking at a mattress
  - The rest of his mind reacted to  a body, a dead body as if he was in a war zone
  - He completely panicked
- He still has trouble talking about that without crying; even now almost 20 years later he still has to sort of choke back the emotions

**The impact of witnessing human suffering**

“*Human suffering… was what happened when I came back from Afghanistan*” – Sebastian Junger

- He saw an enormous amount of human suffering— particularly bloody and gruesome
- And he came back altered
- His group also got shelled very, very badly by the Taliban
  - There was nothing they could do about it
  - They just basically got spanked by [Katyusha rockets](https://en.wikipedia.org/wiki/Katyusha_rocket_launcher) for an hour
    - It killed their pack horse because the horse couldn’t get down like we were
    - They survived but all of that was enormously traumatizing
- And now, the dangerous stuff that he’s been through is easy to process; there’s no problem
- It’s the suffering; it’s the dismemberment, particularly with children— that sight never goes away
  - And still he has to be careful talking about it because he will get choked up
  - That’s a process that he can’t stop once it starts

**The cost of war for those who survive [41:58]**

- - Peter asks, “*Did you ever read the book* [*One Bullet Away*](https://www.amazon.com/One-Bullet-Away-Making-Officer/dp/0618556133/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1639424994&sr=8-1) by Nathan Fick*?*”
    - No, Sebastian has never heard of it
    - It’s a great book about a Marine; he wrote about his tours in Iraq
    - Mortality from combat is often focused on but there are a lot of people who don’t die in combat— who are forever scarred, physically
      - People are also emotionally scarred; and there is a lot of attention paid to this, fortunately
  - Reading this, Peter thought back to his experiences in surgical training which was at a really, really busy [trauma center in Baltimore](https://en.wikipedia.org/wiki/Johns_Hopkins_Hospital)
    - [Baltimore](https://en.wikipedia.org/wiki/Baltimore) was arguably one of the most violent cities in the United States, and lots of patients died
    - Sometimes they would arrive dead
    - When the paramedics got to them, they were alive, but by the time they got to the hospital, they were dead
    - Others would arrive alive, but never made it out of the trauma bay, or they would die in the operating room, or they would die a few days later

- But there were a lot of people who didn’t die, who did leave the hospital, but their lives would never be the same again

- - For example, a transpelvic gunshot wound is almost a universally fatal injury because of the vasculature in there and how difficult it is to get that bleeding under control
    - Sometimes the best victory you can have in that type of a gunshot wound is to sacrifice a limb
    - The femoral artery and vein will have to be ligated, which means the patient will lose their leg, but their life will be saved
    - Peter often thought, “*Well, that person’s not the same*”
  - He remembers reading Nate’s book and thinking about how many of these Marines lived, but everyone forgot their story of how injured they are going forward

> “*It’s that suffering in these other folks who then live and they are to themselves and others a reminder of this trauma. And again, that’s just the physical side of it. The psychological piece, again, could be potentially worse, I’m not sure*.” – Peter Attia

- Sebastian relates this to a command at some military events with older veterans; it’s very moving
  - The command is to stand for the flag or whatever it may be
  - The command is stand as one is able, acknowledging that some people would like to be able to stand and can’t and shouldn’t feel ashamed of their inability to stand
  - It’s a very, very dignified, moving acknowledgement of the cost of war

**How did Sebastian realize that he was experiencing PTSD?**

- Peter asks Sebastian if he was aware of his PTSD in the period of time between Bosnia and when he was trying to get evacuated from the American embassy, during this dozen years or so
  - He’s thinking to his story of sitting in that café in Paris unclear as to why he were having this reaction to the sight of 2 men carrying a mattress

> “*Oh, God, I had no idea why I was having that reaction*” – Sebastian Junger

- It was exactly 10 years— ’93 in Bosnia and 2003 Liberia
- He’d been in a bunch of wars in between those, but no, he  had no idea of his PTSD
- He spent 15 minutes thinking he was going to be executed by rebels in [Sierra Leone](https://en.wikipedia.org/wiki/Sierra_Leone)
- Some bad things happened, and they always had an effect on him, and he always just thought, “*Oh, I’m just losing it. What’s wrong with me?*”
  - And the nation was not talking about PTSD and he didn’t know anything about it
  - Some of the reactions were hard to understand; I mean, there were no ski gondolas in Afghanistan
  - He didn’t understand why he would relate panicking at a ski gondola to combat in Afghanistan
  - He just thought he was going nuts
- Finally, he was at a party and the wife of an older friend, an older woman, who was a psychiatrist asked him, sort of out of curiosity, “*All this combat you’ve covered, have you ever had any psychological consequences?*”
  - This was right after the invasion of Iraq, around ’03
  - He was like, “*No, I don’t think so. No, not really. I’m good.*”
  - But then he mentioned the panic attacks he began to have once in a while; but he didn’t think it had anything to do with combat
  - She was like, “*You’ll find that that probably was connected to combat and there’s something called PTSD…I think America is going to be hearing a lot more about PTSD in the coming years, but you might want to look into it because actually I think you’re suffering more consequences than you realize*”
    - She was absolutely right
- Peter asked how he received this at that point in time
- He was enormously relieved to learn about PTSD and realize that what he was experiencing wasn’t just a unique, empathetic weakness and neurosis; instead it is a normal, healthy reaction to trauma

**Timeline of PTSD and its lasting impact**

- His reactions would be the strongest within a week or 2 of getting back home; after that it would dissipate
  - And a year later, he would be good
  - He might think about it, but it wasn’t invading his daily experience like it was just after returning home
- Likewise with PTSD, he thinks the statistic is about 80% of people a year out from the trauma, have fully recovered and regained a normal functioning healthy life
  - This doesn’t mean they’re not changed by it
  - One can be changed by something, but not in a psychologically dysfunctional state
  - One can grieve their mom’s death or their divorce or whatever it may be, but that doesn’t mean they have a psychological issue
- Peter asked how others, his girlfriend, reacted to his anxiety and panic attacks
- The panic was going on internally; he was literally white-knuckling it and pouring sweat
  - He would conceal it as much as he possibly could, and was probably successful in this
  - He never told anybody about it until later, but not immediately afterwards
  - It wasn’t something he wanted to share

## The sacred bond of soldiers and what Sebastian learned from his time with troops in Afghanistan [48:30]

**Back to Afghanistan in 2005 after the invasion of Iraq**

- Peter asks, “*So, the war in Iraq starts in March of ’03. When are you next back in combat?*”
- He refused to cover Iraq; he thought it was a mistake and a travesty and that it had nothing to do with 9/11, and he didn’t want to get killed covering a mistake
  - He didn’t think he could be unbiased in his reporting; so he didn’t cover Iraq
- By 2005, no one was focusing on the war in Afghanistan because of Iraq
  - Afghanistan was an easy win initially
  - But, because it was so underfunded and undermanned, it didn’t go that well
  - Though it was an easy win, and they had the gratitude of the strong majority of Afghan citizens; the US didn’t follow through
  - By ‘05 the Taliban insurgency started to gain some traction
  - Now Americans are starting to really take some casualties
    - He thinks they were losing a soldier every 3 days in 2005
    - They were starting to get into some god firefights
    - He thought, “*Damn, we saw that coming*”
    - Then he wanted to know what it was like to be an American soldier in combat
- Having grown up in the Vietnam era, it never occurred to him that this would interest him journalistically
- It never occurred to him that the US military would allow unfettered access of the sort that he might find interesting
- It really looked like George Bush made good on his promise to provide full access to American journalists or journalists of any country on the frontlines with American soldiers; and he was like, “*All right, I’m in now. I want to see what this is like.*”

**Sebastian learns unique characteristics of human groups while embedded with the 503rd unit**

- He was in [Zabul Province](https://en.wikipedia.org/wiki/Zabul_Province) with the second of the 503rd
  - This was the same unit he profiled later in Afghanistan, [Battle Company: Korengal](https://www.imdb.com/title/tt3578504/?ref_=fn_al_tt_1)
- Minutes after stepping out of a Black Hawk, he was delivered to a unit that was in the field during combat operation; he was in the middle of a pretty good firefight
  - An RPG almost hit him; boom, all of a sudden he’s in combat with American soldiers
  - He just couldn’t believe the intensity of the fight and the quality of the soldiers
  - All men in this unit were working so hard, physically— the mortar teams were carrying 160 pounds on overnight combat patrol movements, dusk to dawn; basically carrying their own body weight on their back
  - It was unbelievable; they were working way harder at this, to rebuild this other country than anyone he knew ever worked in college
- He really liked those guys
- He thought, “*I want more of this. If this unit goes back to Afghanistan in two years*…”
- It was a two year cycle of deployment
- He wanted to document one platoon in one place for one year and document that with a video camera and by writing a book
  - This became the book [War](https://www.amazon.com/WAR-Sebastian-Junger/dp/0446556246/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638299921&sr=1-4)
  - And the documentary that he made with his friend and brother, [Tim Hetherington](https://en.wikipedia.org/wiki/Tim_Hetherington), that was called [Restrepo](https://www.imdb.com/title/tt1559549/?ref_=fn_al_tt_1)

**Why do guys join the military?**

- Peter asks “*What did you learn about those guys in terms of their motivation? How many of them saw this as a duty, a direct response to what happened on 9/11 in the way that I suspect many young men saw what happened on December 7th, 1941 as their moral obligation to go and do something about it versus how many of them would you infer were looking for a sense of purpose as the primary objective for which this became a vehicle to do it?* ”
- A lot of the guys he knew were from families that had a military history, that had a male relatives that served in one war or another, in prior generations
- A lot of them honestly were young men that were just wanting to test themselves in combat
  - One can join the military and not be in a combat unit, right?
  - The combat units do *not* want people that don’t want to be in combat units
  - There are enough young men that are quite psyched to experience combat; in fact, very driven to experience combat and worried that the war is going to be over before they get to experience combat
  - There’s enough young men to fill those frontline combat units with entirely enthusiastic soldiers
  - And if anything, it’s sometimes hard to get those guys to give combat up
    - He thinks that was probably true in Vietnam as well

**Finding meaning in the wartime experience**

- He’s read letters from American Civil War soldiers and soldiers in World War I talking about how the war was some of the best days of their lives
  - These wars were bloodbaths, right; and these letters said these were some of the most meaningful days of their lives and they miss it
  - The casualty rates were horrific
  - Now, the casualty rates are a lot less
- Indeed, a lot of the guys that he knew out there really miss that experience of combat
  - He just read in *The Washington Post* that the Taliban fighters now sort of have nothing to do because they won the war and that they are openly saying that they miss the fighting
- Maybe guys joined after 9/11 because of patriotism or family history of service; but he would say the majority of them were pretty psyched to see themselves as, “*Yeah, man, I was in combat. I saw the real thing and I did okay.”*
- Peter asks, “*How much of that do you think is the desire to prove themselves in the theater of combat versus the sense of connection that must come from that?*”
  - He has a number of friends who were former Special Forces, and one of the things they talk about is the trust one must have in other soldiers
  - This is completely different from someone working in an office building and asking their colleague, “*Hey, would you mind tracking this thing down for me because I need that piece of information and you’re closer to it. Can you grab it for me?*”
  - It’s quite another thing to be in combat and ask someone to do something where literally somebody’s life is on the line
  - Peter imagines that gives an exceptional sense of purpose, of fulfillment that comes from both leaning on somebody and being leaned on
  - He asks if this is the thing that ultimately hooks people

> “*Yeah… I think humans are wired to respond positively to behaviors and traits that were adaptive in our evolutionary past*” – Sebastian Junger

- People that go through danger together, are loyal to each other when facing that danger, and survive together— they have a special, unique bond
  - This is the thing that describes human groups since the dawn of time
  - In 90% of our evolutionary past, humans lived in groups of 30, 40, 50
  - The loyalty to others who are loyal to you in the face of an attacking lion or whatever; that reaction is very adaptive, and adaptive things feel good
  - The things that keep us alive and allow us to procreate and survive, they feel good, and that’s why we do them; that’s how evolution works
- That mutual group bonds is completely intoxicating, and even if one has not experienced it, they are hardwired to be receptive to it
  - Even at the sort of neurochemical level of dopamine and oxytocin
  - Humans are hardwired to be receptive to it and to grow to want it and to need it
- It would only take some hours in a dangerous situation with some other people to pretty quickly start thinking, “*These are my people. We survived the plane crash together. I’m alive because of them. And I pulled this other guy out of the water and it’s going to be days till we’re rescued, and this is now our tribe.*”
  - It happens in prisons and it happens in all kinds of situations
  - That’s what humans are, and it’s an extraordinary thing that other animals don’t quite have in the same social way that humans do

> “*One of the profound things about humans is that humans will be willing to die for a same-sex peer that they’re not related to*” –  Sebastian Junger

- He’s not going to talk about women because he’s not a woman and hasn’t studied it; so he’ll restrict the conversation to men
- A man will die for a same-sex peer that he’s not related to, not his cousin, not his brother, just another dude who happens to be in the platoon
- And they might not even like each other
  - His friend, Brendan O’Byrne, who was in his platoon in ’07, ’08 said to him, “*It’s funny. There are guys in the platoon who straight up hate each other, but we would all die for each other.*”
- So in these groups that have an arrangement with each other, it’s not dependent on feelings
- This is a very secure place to be as a young man, as a human being

**Forces that bind a tribe together [58:45]**

- There are a lot of groups that function this way
- He knows some guys in the FDNY, the Fire Department in New York City, that completely function like that
  - The willingness to overlook one’s own safety and own concerns for the sake of the group, this is the position these people are in
  - Strangely, they don’t feel like it’s an onerous responsibility or obligation
  - They feel that it’s a privilege, and that they’re honored to be in that role, that they’re special
  - They are special
- He interviewed a fireman in the late ’90s named Pat Brown
  - Anyone in the FDNY would know that name
  - He went into [the World Trade Centers on 9/11](https://en.wikipedia.org/wiki/World_Trade_Center_(1973%E2%80%932001)#Destruction) and his last call was from an emergency phone on the 30th floor saying, “*It’s Pat Brown. We’re on the 30th floor and we’re going to keep moving. There’s casualties coming down, and we’re going to keep moving upwards.*”
  - And he led his men upwards until the buildings collapsed

> “*The ability for humans to do that for each other is a profound thing, and it’s what makes human society possible*” – Sebastian Junger

## An evolutionary perspective on the forces that unify and bind tribes [1:00:00]

- 10,000 years ago anyone may have been in a group of 30 or 40
- The group would have been inseparable and even put aside personal differences because they actually needed each other to survive
  - There’s no one human that could have survived 10,000 years ago in isolation
  - One couldn’t get enough food, enough shelter, and enough security from animals and other humans when alone
- Realize there is some minimum effective group size that was necessary just to survive

**The tribe of firefighters**

- Now consider the example of firefighters
- Peter knows a fire chief in San Jose who was devastated in a way that many people wouldn’t have been during 9/11 because he understood very clearly that his brothers died
- That’s the language he used; his brothers died on 9/11
- Peter talked to him about this recently because of the 20th anniversary
  - And he said he has no doubt that had he been there that day, he would have died
  - This was not something he wondered what would have happened; no, he knows what he would have done
- This is an interesting bond because his tribe scales larger than 30 or 40 people
- Now go one step further with the story of Pat Brown; his tribe now includes a whole bunch of people who were not firefighters
  - He wasn’t going from the 30th floor up to get firefighters out; he was going to get civilians out
  - Peter doesn’t think he was just doing it because it was his job; he was doing it because he felt some higher duty, some higher calling
  - So now his tribe was even larger than just all the firefighters; it was all of the people that were in danger
  - This story suggests that this *connectedness* can scale beyond the group of 30 to 40 people
- Sebastian agrees; he would say Peter’s fireman friends were all emotionally wounded on 9/11 as were all Americans
  - It’s possible that if an equivalent story happened in Pakistan, he might not quite have grieved his Pakistani brothers who had died in a building collapse

**Connections that bind a tribe together**

- Peter clarifies— so this might have been more an American connection than an occupational connection
- Yes, Sebastian thinks they felt like brothers because they share the same country and the country was attacked
  - There are different layers of affiliation
  - Humans have a symbolic capacity for symbolism where one may not know someone, but if they wear the same insignia, the same uniform, do the same job… one can relate to them
  - One may not love this person like a brother, but may respect them and risk their life for them
- One of the sources of pride for firefighters is that they take care of a vulnerable population
- So Pat Brown went up those stairs with his brothers because that’s what they do, and they were doing it together
  - And the question, should they do this or not, did not even come up for review
  - Someone who questions this is not going to be in the fire department; they all know that, and the fire department doesn’t want someone who doesn’t want to be there
  - The sacrifice is part of how Pat Brown probably saw himself
  - The meaning of his existence to some degree came from his role as a fireman
  - So of course he went up the stairs; that’s what a fireman does

**Unity among Americans**

- Back to the question, is it possible to feel affiliated with 300 million people?
  - Can we feel affiliated as a nation, even if we don’t know each other?
  - Yes, because humans are capable of symbolic thought
  - And we’re capable of understanding intellectually that we’re all Americans even though some might be different races and speak different languages
- There are enormous differences between individuals, but this is a country like no other
  - It it filled with every race and language of the world
- The human ability for abstract thought is an extraordinary thing

**Stresses that pull a tribe together**

- Peter asks Sebastian when this American sense of unity, of tribe was it at its peak in American history?
- After 9/11, for sure
- After World War II
  - There was a huge can and metal collecting operation because the armed forces needed metal, aluminum
  - There was a huge amount of national undertaking that everyone understood and said, “*We’re in this together. Buy war bonds*” and all that stuff
- The Depression was another time
- He knew a man who was young during the [Dust Bowl](https://en.wikipedia.org/wiki/Dust_Bowl) and the [Great Depression](https://en.wikipedia.org/wiki/Great_Depression) out in Missouri; he said that the schoolhouse would be left open at night
  - These are one-room schoolhouses
  - This is the 1930s in American West and Midwest
  - The schoolhouse would be left open, unlocked for migrant families were on the move with children
    - They were poor, they were destitute, they were desperate, and they were looking for work in the Dust Bowl
    - They would be driving their horse and cart across the land, and they needed places to sleep with their children.
  - So every town left their schoolhouse open so that these migrants could enter with their children and sleep in a safe, protected place
    - And they would leave before class started in the morning
    - And then every school had a well; so they would have water for the horses
  - And that’s the kind of communalism that typifies a nation enduring great hardship
  - They’re looking out for one’s neighbors and looking out for people that are less well off
- [The blitz in London](https://en.wikipedia.org/wiki/The_Blitz) had plenty of that as well
- People react in very healthy ways to that kind of stress
- In his book [*Tribe*](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638299921&sr=1-3), he researched an earthquake in [Avezzano, Italy in 1915](https://en.wikipedia.org/wiki/1915_Avezzano_earthquake); the mortality rate was more than 90%
  - It was like a nuclear bomb had gone off in that area, and 90% of the people died within minutes
  - One of the survivors wrote that the people who were left, there was a complete [egalitarianism](https://en.wikipedia.org/wiki/Egalitarianism) among the survivors
    - It didn’t matter if one was a criminal, rich, poor, an outcast; it did not matter— the people that were still alive regarded each other as equals because it was a matter of survival
    - And this guy said, “*As soon as outside relief got there, that egalitarianism ended*”
    - And he said that the crisis, the earthquake had briefly given them what the law promises but cannot deliver— equality of all people

> “*Well, if you experience that [equality of all people], you do not want to give it up. And that’s one of the things that soldiers experience in combat with each other in a platoon*.” – Sebastian Junger

## Hunter-gatherer societies, dealing with loss, and the ancestral connection to the spiritual realm [1:08:30]

- Peter asks about our ancestors, 10,000 years ago; did they live in that state because it was effectively a crisis 24/7?
- Sebastian doesn’t think it was a crisis but there were subsistence level Stone Age people that needed everyone to contribute to survive.
  - He’s sure the crises were regular enough that it keep them bonded together
- For a hunter-gatherer society, there’s no getting off the treadmill; they’ve got to keep that system going, pretty much continually
- Studies have been done in very harsh environments, like the [Kalahari Desert](https://en.wikipedia.org/wiki/Kalahari_Desert)
  - The native people of that area, the [!Kung](https://en.wikipedia.org/wiki/%C7%83Kung_people) for example, they worked an average of 4 hours a day to survive in one of the harshest environments of the world
  - Compare this to the average work day for a person in a post-industrial society; they work an 8 hour day; a 40 hour work week
  - So it’s interesting, as we’ve gotten more advanced, the time requirements for survival have increased, not decreased

> “*But at that level, it does not require a full-time effort to survive, but it does require a full-time cooperation, collaboration within the groups*” – Sebastian Junger

**Response to loss— was there depression?**

- Peter asks if there is any sense of how hunter-gatherers treated death or how they responded to loss
- Sebastian has not made a study of it, but going from a very general knowledge, there was very little suicide and depression in hunter-gatherer societies
- The deaths that happened were either violent as a result of warfare or dangerous animals or infant losses from disease
- But for those who lived through the initial high risk years, a lot of people in those societies lived into their 70s and 80s
  - These are long lifespan in Western terms, even by today’s standards
  - There was a general feeling that when a person passed on, they went to a realm that was inhabited by other dead ancestors
- [Shamanism](https://en.wikipedia.org/wiki/Shamanism) is a virtually universal human behavior in almost every human society
  - One of the jobs of the shaman is to shuttle back and forth between the world of the dead and the world of the living with important information about how it’s going over there and what the living people need to do to remain in a right and proper relationship with the dead
- Peter finds this interesting because it suggests that the impact of loss was so significant that people needed a way to explain it, a way to give meaning to life
  - This said that even when one was gone, they still mattered
  - Depending on the belief system, maybe that person would be reincarnated
- Peter relates this to a recent elk hunt
  - He loves hunting but it is never lost on him that when he kills an animal, that animal lived
  - An elk would have lived for 8-9 years
  - He remembers watching this elk die and all of the other elk made a circle around him as he bedded down to die
  - This blew his mind because he hadn’t seen that before
  - A lot of times when the arrow hits the elk, it makes noises; it freaks out and everybody scatters
  - But for whatever reason on this occasion, the arrow hit him; he wandered 40 yards; he bedded down and was making noises like he was dying; he was surrounded by the other elk; and eventually the elk went away when he died
  - He couldn’t help but anthropomorphize that and wonder what they were thinking
    - The largest elk watching him die
    - Do they understand what that means
    - Will they remember that
    - It’s a silly question because it can’t be answered
    - It makes him wonder how other species experience loss

## Psychological mechanisms that protect humans from painful experiences and the power in giving thanks [1:13:15]

**Psychological mechanisms at work regarding war and death**

- Sebastian notes that humans have psychological mechanisms to protect themselves from painful experiences
  - They go into shock physically if they’re in physical pain
  - In war, there’s 2 different ways of processing the fact of killing other human beings
    - At the end of the day, everyone knows that’s wrong, and there’s a moral burden that comes with it
    - 1) Convince yourself that they’re not fully human. “Y*ou’re not really killing humans, right? It’s the enemy. They’re less than human. It doesn’t matter, right?*”
    - That’s a very common one; it’s easy to feel that way when they’re killing friends, and one is filled with rage and grief
    - 2) Accord respect; acknowledge the worthy foe
    - The Greeks did this with the Trojans, “Y*ou’re a worthy foe. Now we are going to wipe you out, make no mistake about it. But you’re a worthy enemy, and we respect you. We respect how hard you are fighting. You’re brave. We’re still going to kill you, but we have respect for you.*”
    - That’s another way of psychologically distancing oneself from the fact of killing people
- There is often this moral burden in hunting because one is killing an animal
- Many native peoples around the world live off hunting in order to survive
- One way to protect the hunter psychologically from the moral questions around that is to say a thank you
  - “*Thank you elk, thank you bison for giving us food to eat. We respect you. We honor you.*”
  - There’s a whole ritual process that incorporates the death into a context of respect

**The miracle of modern society and its flaws [1:15:25]**

- The miracle of modern society is that some nearly miraculous Western medicine intervened when he was dying and saved his life
- So on many, many levels, this society is a miracle; it’s transcendent
  - We understand the cosmos
  - We understand the human body
  - This could go on and on; we can fly airplanes and drive cars
  - It’s insane how amazing it is
- But that it costs the planet a lot
  - We are gouging mountains and cutting down forests and polluting the ocean, etc.
  - That’s the cost of our amazing society
  - And what’s interesting about that is, virtually all humans think that nature is beautiful
  - Take the most hardcore, ultra right wing, anti-climate change, anti-vaxxer, whatever, they know a tree is beautiful
    - And when someone cuts down a tree, it’s less beautiful
    - We all know that; every child knows that

> “*And we are basically killing the elk, killing the buffalo in order to eat without saying thank you*” – Sebastian Junger

- This might change the whole conversation about environmentalism, even if people didn’t do anything differently; even if people kept strip mining mountains
  - The needs of our society, the rational “*because we need to*”
- He’s not saying we should or shouldn’t do anything of that sort
- But if we just added an acknowledgement of the harm and a thank you to the earth for providing our sustenance, if we just did that, it would reconcile this cognitive dissonance of all of us knowing that we hurt something we love in order to exist
  - And liberals hurt the planet just as much as conservatives
  - The liberal piety, “*Oh, I drive a Prius so I’m good*,” is complete nonsense
- He thinks we might learn something from native peoples about protecting ourselves emotionally and psychologically from the necessary harm that we do by overtly stating and ritualizing that relationship with the earth
  - And so the next time they flat top a mountain for coal, why not bring in a minister, a priest, a shaman, or all three to say thank you to the mountain
  - It won’t hurt
  - It might actually do people, the community and the coal miners and all of us that use electricity, a lot of good
- Peter thinks this is very powerful

**Hunting and rituals of thanks**

- Hunting is a controversial topic; he takes the view that if one eats meat, they should understand what it’s like to take the life of what they are eating
  - To remove the distance between oneself and the animal they’re eating
  - It will change the way one eats
  - Peter remarks, “*This will probably be the first year when I will subside entirely on wild game that’s been hunted ethically. And there’s literally been a change in my pallet. I just don’t like eating big steaks*”
- Peter brought his daughter ona hunt once 2 years ago, when she was 11
  - He remembered thinking it could be very traumatic for her because it was a beautiful deer, an [axis deer](https://en.wikipedia.org/wiki/Chital)
  - Fortunately, the deer died very quickly
  - Afterwards, he wanted his daughter to come up and lay her hands on it while it was still warm and understand that she going to eat this tonight, but this thing gave us a gift
  - They thanked the deer because it was going to feed them; and it did feed about 40 people that night
  - She still looks back at this very fondly
- Sebastian thinks that must have been a complete, absolutely core experience of our human ancestors
- For most of human evolution there is this relationship of respect with the animals that one eats
  - He feels like it’s psychologically, enormously healthy
- And one of the ways our society is unhealthy is that it has de-ritualized the vital processes that keep us alive,that keeps us fed, that keeps us sheltered
- This has been de-ritualized and it allows to not acknowledge the harm that we do
- We all know in our heart, right? And then when you could articulate it,
  - Compare it to the break-up of a couple
  - The difference between hurting someone’s feelings and hurting someone’s feelings and saying, “*I’m so sorry that I hurt your feelings. I had to do it. We were good couple. We had to break up, but I’m still hurting from the sorrow that unavoidable decision that I carry in me.*”
  - There’s a world of difference between dumping someone and having a conversation like that

> “*And that’s the conversation we need to have with our planet, regardless of where you fall on the climate change, environmental spectrum*” – Sebastian Junger

## How parenting has changed Sebastian, and the incredible pain of losing a child [1:21:15]

- Peter asks how old Sebastian was when he had his first child
- He was 55
- Peter asked how this changed his appetite or tolerance for risk
  - Sebastian doesn’t seem to be thrill seeking but there is no way to deny that what he was doing was very risky
  - Did having a child change his outlook on his own life?
- Yes, Sebastian acknowledges that his life is not his own now in the sense that if something happened to him, there would be lifelong consequences for his wife and children
- He has 2 little girls, 4 ½ and 1 ½ years old
- They are the center of his world
- He would die for them in an instant
- His main job right now is to not die, to keep himself alive
- He stopped war reporting in 2011
- Right now, he’s incredibly risk averse
  - He looks both ways before he crosses the street
  - He doesn’t cross against the light, most of the time
  - He drives the speed limit
  - He doesn’t even like ladders
  - He’s very, very cautious

**The trauma of losing a close friend [1:22:30]**

- Peter asked if he stopped war reporting after his friend Tim died
- Yes, this was his colleague (brother and friend) at OP Restrepo, where he filmed [Restrepo](https://en.wikipedia.org/wiki/Restrepo_(film)) and when he spent a deployment with the Second Platoon of Battle Company 173rd Airborne
  - They were out there a lot together
  - They made the film together
  - They were nominated for the Oscars together
- A few weeks after the Oscars, they were going to cover the [Arab Spring](https://en.wikipedia.org/wiki/Arab_Spring) on assignment for *Vanity Fair*, and at the last minute Sebastian couldn’t go
- His friend Tim was killed in the city of [Misrata](https://en.wikipedia.org/wiki/Misrata) by shrapnel, a little piece of metal that hit the femoral artery in his groin; and he bled out
- After that, Sebastian saw what his death did to everyone who loved him
- Tim’s death was fairly rapid and painless, and his problems were over
  - But the people who loved him, their problems were just beginning
  - Sebastian watched how this worked and thought “*I’m not going to do that to the people who love me*”
- At that point war reporting went from seeming noble and selfless to something that seemed quite selfish and self-concerned, and so he stopped
  - He might not have had that reaction at 25 or 30 or 35 or 40
  - But he was almost 50, and so he stopped and never looked back
  - He may miss some of those experiences, but he doesn’t want to repeat them

**How having a family changes one’s outlook on sacrifice and risk**

- Peter asks him, having experienced both sides of that sacrifice, what this tells him about the people who can do those jobs— soldiers, firefighters, fishermen in Alaska
  - People who have families and are making these choices
- Sebastian doesn’t know how they do it
- A lot of soldiers don’t have kids
- The guys he was out there with were mostly 19, 20, 21
  - Only a few had children
  - But lots of soldiers do have kids, particularly once you get into the National Guard
- Fireman have a big, very family-centric culture
  - He doesn’t know how they do it
  - He doesn’t know how fireman, paramedics who have children go to car accidents where they’re pulling dead children out of the backseats of vehicles
  - Psychologically, he doesn’t know how they process the trauma
- He can’t even read a news story about something bad happening to a child
- He doesn’t know how they do their work, how they endure that level of trauma
- Thinking of frontline ER doctors, he is reminded of himself in Liberia, counting the bodies in the pile and wincing at the children
  - The cost of that later, 2 weeks, 2 years, 20 years later, the cost of that…
  - He worries about those people
  - He don’t understand how they survive it psychologically
- Peter reminisces about medical school
  - A lot of people who go to med school have a very clear sense of what they want to do; it’s very specific
  - For him, it was pediatric oncology
  - Those were the experiences he had while he was an engineering student that led to his change of heart and led him to decide to go to medical school
  - In one interview for med school, the person interviewing him was an ENT surgeon said, “*Well, you wrote your essay about this and you want to do pediatric oncology. I just want to tell you that I think that’s a horrible idea….Right now, that might seem like something that you can do. But one day you will have kids, and that will be the most difficult thing to do is to take care of dying kids.*”
    - Obviously this is not entirely true because there are lots of people who take care of kids with cancer who have children
    - Peter has seen them, and attached
    - They’re not detached; they’re not cold; they’re not callous
  - At the time though, this comment put him off a bit
  - But he was entirely correct
  - Now that Peter has kids, there is zero chance he could be a pediatric oncologist
- Sebastian agrees; now that he has 2 little girls, his sensitivity to harm to children is so completely unbounded that it makes it hard to even read the newspaper or go through life

> “*It [parenthood] sensitizes you enormously… Trauma also particularly sensitizes you, and seeing trauma to the innocent is something that you will never fully escape the effects of that*” – Sebastian Junger

**Trauma, PTSD, and healing [1:28:00]**

- For him, it’s been 20, 25 years and it hasn’t changed at all in his head
  - It’s the most painful thing he can think of
  - It will not go away
- Peter agrees, even though he went into surgery, he saw lots of trauma
  - He worked at a level-one trauma center
  - They probably averaged 15 penetrating raumas a day
  - This doesn’t count all the blunt traumas, or car accidents
  - Death was always right there
  - He would see kids die because they took care of pediatric trauma
  - Seeing pediatric trauma is by far one of the most difficult things
    - And this is not to say that people dying of cancer isn’t horrible
    - But death from cancer isn’t sudden
    - There was at least a chance to make amends
  - Compared to a kid who dies in a car accident; the parent had zero chance to prepare for this
    - He found this to be the hardest even though paradoxically, it wasn’t always accompanied by suffering of the victim

**Sudden, unexpected loss of a child**

- Peter remembers 1 boy who was 15 or 16 years old
- He was being driven home from school by his older brother
- They were going through an intersection when a guy rand a red light and T-boned them on the passenger side, which is where the victim was sitting
- He arrived alive, but barely; Peter was the trauma chief
- For this type of blunt trauma, when the patient is unresponsive it means there is a head injury or massive internal bleeding
  - He’s not going to be dead because he broke bones; it’s going to be his aorta is sheared or another internal vessel
  - Or he will die from blunt head trauma
- To make a very long story short, he probably should have declared the kid dead in 5 minutes but he wouldn’t do it
  - He was adamant that why keep working
  - 30 minutes later he finally conceded he was dead
- When he told the kids mom, she screamed so loud; it was devastating
  - He remembers, she tore the pocket off his scrubs; she literally grabbed his chest and tore the pocket off his scrubs
  - He spent hours with her
- He would actually go to the kid’s funeral; this was one of the very few people he didn’t know whose funeral he went to
  - He didn’t think the mom would remember him; he was in a suit not scrubs
  - When it came time to walk past the casket, she was there
  - When he got to her, she did the same thing— she completely collapsed, grabbed him, and tore the pocket off his dress shirt
    - He was really, really moved; he just couldn’t believe this had happened
    - He couldn’t believe she would even remember some random person, although obviously, it was such a traumatic experience
    - But he kept that shirt for a very long time as kind of a reminder of something that on a given day can change the course of your life, such a random freak thing
    - It blew his mind; this memory within her of this interaction, separated by days  and by endless sadness

## PTSD and the influence of community on healing [1:32:15]

- Peter asks how our society is doing treating the victims of PTSD
  - Medically or not
  - We can even limit this to combat, even though people can have PTSD from many things that are not related to combat
- Statistically, the more affluent the society, the higher the incidence of PTSD
  - Considering the astronomical levels of addiction, depression, suicide, anxiety, compulsive disorders, and all of the social ills— our society is not doing too great on the PTSD front
- If one lives in an live affluent society, they are statistically prone to worse and longer PTSD than if they live in a poor society
- In a poor society, there’s an expectation that life is hard, so when something bad happens, it’s not so much of a shock
  - Also, in less affluent societies, particularly in the developing world, people have a more *communal existence* because they need each other
  - People who live in a village in Africa, or in Asia, or wherever it may be, are interdependent on one another because they don’t have their own little house in the suburbs, in the American suburbs, the way he grew up
  - And that social proximity is a buffer for psychological struggles
  - So suicide is lower in those communities, depression rates are lower, anxiety’s lower, even though those lives are stressful in all kinds of ways that ours aren’t because we’re an affluent society
- Humans evolved to be great at surviving
  - We evolved in a violent and unpredictable world, where people had accidents, or were attacked by animals or other human beings all the time; life was traumatizing
  - And if trauma was psychologically incapacitating to a majority of people for any length of time, the society wouldn’t exist because the group couldn’t survive because there’d be no one around to function, because everyone’s traumatized
- So clearly, in terms of our species, trauma is something that humans are designed to work through fairly quickly because the business of survival has to be attended to, and the statistics bear this out
- For most people, the majority of trauma symptoms disappear within 3 months
- He has studied this as a journalist and has had his own experience with PTSD
- In his opinion, the reason there is a long-term problem with trauma reaction is partly because we live in such an alienated, socially unconnected, non communitarian society
  - People live in incredible isolation
  - Children have their own bedrooms; this is the first time in human history that a society has been affluent enough to give children each their own room in a middle class house
  - This is insane, in human terms
  - Children aren’t supposed to be by themselves in the dangerous world
  - People traditionally sleep in groups in human society
  - It is also completely insane if families live in their own, self-heated, self-sustaining house, or apartment, unconnected to their neighbors, who are unconnected to any sense of community endeavor
    - This is a completely new in the human experience

**The support of a community is important**

- He would say is that when people experience trauma communally and recover from trauma communally, it goes quite well
  - He looked at a study that was done in a very war-like tribe in East Africa
  - They were a cattle herding society, and warfare was quite normal and still is
  - The warriors that were well connected socially, not status wise
  - They were well embedded in the community, and would come back from these very violent raids with a sort of startle response
    - And some other sort of surface level trauma reactions, like they’d jump at loud noises or whatever, sometimes nightmares
    - But they wouldn’t get depression
    - The depression component of PTSD was not something they had to struggle with because they had a healthy relationship with their society
    - The warriors that were not socially connected in a healthy way, those are the ones who were prone to long-term depression
- PTSD is psychologically stressful for everybody
- But our society is not good at treating PTSD and this can be seen in our rates of depression, suicide, addiction, anxiety, all those other things

## Isolation of modern society and the debate over young kids sleeping in bed with their parents [1:37:45]

- Peter brings back the idea of this challenge with modern life and that it has come with amazing things
  - He wouldn’t want to worry about safe drinking water
  - He likes that he is never starving
  - He likes that there is not a tribe 100 miles away that wants to kill him

**Only in modern society do children sleep alone**

- But at the same time, the example of children sleeping in their room is fascinating
  - He has 3 kids and has found that around age 4 they stop wanting to sleep along
  - They all slept fine in a crib; he had pretty good sleepers
  - But come age 4, they were not happy about being alone in their room
  - The textbooks give all sorts of advice but never say to bring them into the parent’s room
    - But this is exactly what would’ve been happening 10,000 years ago
    - On some level he thinks we probably evolved to sleep with our children
- Sebastian agrees, “*Americans are the only mammal that doesn’t sleep with its young*”
- Our culture is essentially a derivative of England; and in England, removing one’s child from their bed space started in the 1700s and then spread throughout the English speaking world
- But this is not the human norm; it never has been, and it still isn’t.
- Most of the world sleeps in a communal space
- Most of the world is not affluent enough to give their child their own crib and their own bed in their own room
- If one goes camping in the Bob Marshall Wilderness in Montana with their family, one would not have 5 separate tents
  - One would keep your 4 month old right next to them. right?
  - Because it’s a dangerous world, and the 4 month old knows that; and the 4 year old knows that
  - Infants get their safety from proximity to adults, period, end of sentence
  - And they know that if they’re by themselves in the darkness, their life is in danger

> “*Think about how profound that is, Sebastian, because I think someone who doesn’t have kids might think that sounds strange*” – Peter Attia

- Many people listening to this who have kids will appreciate the almost irrational fear that a 4 year old can have of sleeping alone in the darkness
- But if you think about it through this evolutionary lens, it shouldn’t be surprising
- It’s not irrational at all; in the context of modern America it is, most of the time
- Throughout human evolution, the big threat to humans were the large cats
  - Large cats hunt at night, and so night time was a very, very dangerous time for humans
  - Countless early human skulls have been found with the sort of four prongs of the front teeth of a large cat, a large feline, having punctured the skull
  - And so a child or even an adult who was alone in the darkness, their life was at risk
  - One cannot fight off a lion alone unless one happens to have an AK47
- When people are surprised by this, he says, “*Look, try going camping by yourself. Go into the woods and see how much sleep you get if you are completely alone in the* [*Bob Marshall Wilderness*](https://en.wikipedia.org/wiki/Bob_Marshall_Wilderness)*. Now go camping with a group of friends and see how well you sleep*.”
  - People sleep a lot better in a group
  - Could the group do anything if they were attacked by a grizzly bear? Probably not
  - One is probably just as much at risk by themself as in a group, but there’s something about being alone in the darkness that even makes adults fearful, and they will not get a good night’s sleep
- For children that are Ferberized…. there was a doctor named [Dr. Ferber](https://en.wikipedia.org/wiki/Ferber_method), who wrote a book about how to get children to sleep in their own room
  - He wrote, “*Put them down early, and then you and your wife or husband can have a nice evening on your own.*”
  - He later recanted everything he taught
  - In the 1990s, there was an article in [*The New Yorker*](https://www.newyorker.com/magazine/1999/11/08/sleeping-with-the-baby) about it; and he said he was dead wrong about making children sleep by themselves
    - It was completely counter to evolution; it was unhealthy for the child
    - It was quite nice for the adults, but not even that nice because the screaming of the terrorized child is hard to take while they’re being Ferberized
    - So Dr. Ferber himself actually recanted all of that
- Right now, most of the world, people still sleep with their children
- Sebastian and his wife have always slept with their children
  - His eldest is four and a half.
  - They make it clear to her, “*Listen, if you want to take that little mattress and sleep in the kitchen, or sleep on the couch in the living room, go for it. You don’t have to sleep here.*”
  - They have a platform, they have a pad on the floor in what used to be the bedroom; there’s no bed there anymore
  - They tell her she can sleep wherever she wants; it doesn’t matter; but she’s always welcome in the family bed
    - And that’s where she prefers to sleep, in the family bed

## Why Sebastian doesn’t own a smartphone [1:43:30]

Peter notes another thing that Sebastian does that different from the average American is that he doesn’t use a smartphone — “*Talk to me a little bit about it and how it’s probably made your life better, despite the fact that you’ve given some things up*”

- He  never had a smartphone so there was nothing to give up
- He find the idea of sending an email while walking down the street insane; that’s something that happens at one’s desk when they’re working
- When he’s walking down the street, that is what he wants to be experiencing
  - He lives in [New York City, Lower East Side Manhattan](https://en.wikipedia.org/wiki/Lower_East_Side), this sort of bounty of human experience
  - When he’s walking down the street he doesn’t want to get run over by a truck
  - He also wants to observe what’s around him
  - He wants to enjoy the sheer craziness and wonderment of being part of human society in New York City or anywhere
- Email is a tax on his energy and time; he wants to confine that as much as possible
  - It’s drudgery; he doesn’t want it invading something precious to him— which is the experience of being alive
  - Email is something he does at home, working at his desk

**Challenges to freedom in modern society**

- In his book [*Freedom*](https://www.amazon.com/Freedom-Sebastian-Junger/dp/1982153415/ref=sr_1_2?keywords=sebastian+junger&qid=1638299921&qsid=131-3146834-4509605&s=books&sr=1-2&sres=1982153415%2CB01D57FNZG%2C044655622X%2C0060742690%2C0393337014%2C0060088613%2CB005YPJ5CU%2CB089V1XS2P%2C1633885704%2CB09BDDV5P2%2CB00HI9K7BI%2CB01IIW6NJI%2CB01JXTW10A%2C1982159006%2CB00A7GZ9KS%2CB07N6MPWLS&srpt=ABIS_BOOK), he wrote how humans maintain their autonomy in the face of more powerful forces, more powerful societies, oppressors
- In modern society, one of the main ways people are deprived of their freedom is through addiction

> “*We are an enormously addicted society… To the extent that you’re addicted, you are unfree*” – Sebastian Junger

- People are addicted to drugs
- They’re addicted to television
- They’re addicted to social media
- The tech giants that developed social media use algorithms that elicit essentially an addictive, compulsive response to social media engagement
- People are addicted to their iPhones, to social media
  - That addiction is clearly correlated with depression and anxiety and suicide in teenagers, particularly teenage girls, starting with the advent of [Facebook](https://en.wikipedia.org/wiki/Facebook)

- Algorithms used by social media has killed people, young people
  - They have blood on their hands because of this algorithm
- We all have potentially addictive personalities

**Balancing the miracle of modern life with freedom**

- He don’t want to be that guy walking down the street, completely submerged in an environment which is designed to addict one further and further, and then monetize that addiction
- He’ll just go walk down the street on his own, and I’ll check his email when he gets back home, and do all the other stuff that the iPhone offers.
- Again, it’s a little, minor miracle to have all of human knowledge at one’s fingertips
  - He’s not sure he wants all of human knowledge in his pocket
  - All of human knowledge at his desk is an amazing thing; in his pocket, maybe not
- Does he need [Google Maps](https://www.google.com/maps) to get from here to there?
  - No, he knows the sun rises in the East
  - He can put a map in his back pocket
  - He can figure it out, thank you
  - Does he need to get a car, a ride, an Uber with his iPhone?
    - Yeah, that would be convenient
    - But he can also stick out his arm and get a taxi
- There are workarounds for all the stuff that the iPhone offers, and one avoids the enormous downside of compulsive addictive behavior and all the anxiety and depression that statistically gives rise to
- Peter asks if Sebastian’s wife has a smartphone
- Yes, she does
- Peter asks if “*are some people able to utilize it for the benefits and not succumb to the challenges? Are you simply taking a cautionary approach in your own life?*”
- Sebastian notes that his wife is very deliberate and conscious, particularly around the girls, to not engage in obsessive behavior with her phone
- Usually in life, when there is a chore to do, shovel that pile of dirt over there, the more one shovels, the less work is left
  - The weird thing about email is that the more one does, the more one has to do.
  - The [Greek myth of Sisyphus](https://en.wikipedia.org/wiki/Sisyphus#Punishment_in_the_underworld), the never ending task— that’s email
- His wife doesn’t do that; half the time when she leaves the house, she doesn’t even have her iPhone because she forgot it

**Smartphones are designed to be addictive**

- His little girl has had virtually no screen time in her entire life
  - She doesn’t have a tablet
  - They don’t own a television
  - When they take a long drive somewhere, she gets bored; she looks out the window, she whistles, she sings, she goes to sleep
    - She does what people of my generation, did when we were young— “*we got bored and we learned to entertain ourselves with little stories in our mind, or what have you*”
- But if you give her an iPhone, the first thing she does is get addicted to it
- She’s 4, how did she learn this?
- The design is so intuitive that even an uninitiated three year old can learn it within minutes
- And then the only thing she wants to do is play with that phone
- They really knew what they were doing; they figured it out so they could hook a 3-year old within minutes
  - If that’s not evil, what is?
  - So he don’t even let her near a smartphone

## Parenting through an evolutionary lens [1:50:00]

- Peter asks how much of his philosophy around having his kids sleep with him, not having a smartphone, et cetera, how much of that is influenced by his time in combat?
- As a thought experiment, if he went back in time to 1985 and decided to be a lawyer; he’s living in the Lower East Side right now, working for a law firm, and everything else is the same about him (he married the same woman and had the same kids), Peter asks , “*Do you think you carry a smartphone?*”
  - A lawyer might be expected to have his phone on 24/7
- Sebastian thinks it’s a cultural thing
  - If he were young (say 25) and came of age when all this stuff was normal, then he would probably have one
  - He is 59; what de didn’t do was adopt a smartphone in midlife
- There was something about the behaviors of people with iPhones that made him think, “*I don’t want to look like that*”
  - There’s something about the visuals of that addiction that’s so mortifying; and that’s how he feels about the iPhone
- He sees life through the lens of anthropology (that’s what he studied) not combat
  - Through the lens of anthropology, he thinks about what are healthy human behaviors
- He married a like-minded woman, so fortunately they see absolutely eye to eye about that stuff
- He has the reinforcement of other like minded people
- There’s a wonderful website called [Evolutionary Parenting](https://www.evolutionaryparenting.com); it basically walks one through how to raise their child in an evolutionarily consistent way in modern society, taking into account the obvious sort of context of all this
  - It explains how someone can keep within normal, sensible norms, and keep parenting within a way that’s evolutionarily healthy and consistent
- Peter asks what this website says about food
- They focus on behavior
  - Children are not out to foil their training or their parent’s plans
  - When three year olds have temper tantrums, they’re not being bad; it’s part of a process of neurological development that they have to go through
  - When people pathologize normal developmental stages and normal child behavior (like crying when they’re stuck in a dark room), they are simply doing something that they’re evolutionarily wired to do
  - They’re moving through neurological stages, development stages in a normal and healthy way
  - To  pathologize it because it makes the parent’s life inconvenient, eventually, they will learn norms that abide by the parent’s preferences, but that doesn’t mean it’s good for them
    - It means it’s convenient for the parents
- The website talks about these norms and understanding behavior in evolutionary terms
  - For example, every time his daughter sees a sparkly, glittery object, she wants it
  - She can walk through the pharmacy without saying, “*I want that. I want that. I want that.*”
  - Is she an abnormally materialistic, inquisitive girl?
  - No. She’s exhibiting absolutely healthy hunter gatherer norms about acquisition of appealing things.
  - One doesn’t want to pathologize it
  - One doesn’t want to get her everything either
  - But it needs to be put in a proper evolutionary context in order to have patience with it, and that’s what this website does

## Sebastian’s near-death experience and new perspective on the possibility of an afterlife [1:54:00]

**Sebastian’s near-death experience**

- Sebastian has an anatomical anomaly in his abdomen; his [celiac artery](https://en.wikipedia.org/wiki/Celiac_artery) has been compressed by his [median arcuate ligament](https://en.wikipedia.org/wiki/Median_arcuate_ligament), which is in the wrong place
  - This ligament has completely occluded the celiac artery, so the blood was forced to flow throughout his entire lifetime through smaller sub arteries that feed the pancreas and the duodenum, and I guess other digestive organs.
  - It was not asymptomatic
  - These little arteries are smaller and not designed to take the full blood flow that the celiac artery carries
  - Over the course of presumably many years one of these arteries, the [pancreatic duodenal artery](https://en.wikipedia.org/wiki/Superior_pancreaticoduodenal_artery), developed an [aneurysm](https://en.wikipedia.org/wiki/Aneurysm)
    - He hopes this developed over a long time because he don’t want this to happen again
  - And then for about 6 months, he had this really awful pain in his upper abdomen that came and went
    - Him just being a stupid guy, he never went to the doctor
    - He thought, “*If you can bear the pain, it’s probably not going to kill you.*“
    - It was a kind of searing, cramping, slightly nauseous pain; it would come and go
    - He’s been told that abdominal aneurysms can cause pain, and there’s a big nerve center right around the [solar plexus](https://en.wikipedia.org/wiki/Celiac_plexus), and maybe it was pushing on that
    - It wasn’t the pain of kidney stones, but it was way more than indigestion
    - He would sit down and have to wait it out when it happened; it was pretty awful
    - This would happen every couple days, once a day, something like that
    - It would last half and hour, or an hour
- And then after some months of that, he had a lot of other health problem
  - He had sudden onset severe adult allergies for some reason, no idea why
  - He’s always been a big runner and he had trouble running
  - Something was wrong with him and he couldn’t figure it out
- After some months of that, the pain suddenly went away and the allergies suddenly went away overnight
  - He thought, “*Oh, great. I’m good.*”
- But then within a few weeks, he had a dream; it was a horrible nightmare that he’d died
  - This was about 6:00 in the morning
  - He was in bed with his family and everyone’s asleep
  - He had a dream that he’d died by some accident; it was an oversight and stupidity on his part
  - In his dream, he’d died and was looking back at his family grieving
  - He couldn’t return to them because he’d crossed over
  - He thought, “*You idiot. You blew it.*” and he woke up incredibly shaken
- He’s not a doctor, but he thinks his artery had already started dissecting because the following morning, he had sort of ongoing pain when he woke up
- He knew something was wrong, but he still didn’t go to the doctor
- That afternoon, it was a beautiful day, and he was going to go running
- But then he realized that he didn’t feel quite right
- And thank God he didn’t go running, he would’ve died crawling around in the woods
- In about half an hour, he felt a surge of pain in his abdomen; it flooded his entire abdomen
- He was like, “*Jesus, what is that?…Damn, that is strange feeling*.”
  - It wasn’t unbearable, but he’d never had that feeling before
- Within a few minutes, he tried to stand up and almost fell over
  - His blood pressure was just tanking
  - What had happened was the aneurysm in the artery had ruptured, and he was bleeding out into his abdomen
  - Of course, he didn’t know this
- He was in the woods with his wife, in a cabin that he built
- She dragged him back out of the woods, with him stumbling along, and got him to the driveway and in the car so he could sit down
- Then he started to go blind; the sky turned electric white, and that began to take over his entire field of vision
- He was [syncopic](https://en.wikipedia.org/wiki/Syncope_(medicine)); he was in and out of consciousness
- By the time the paramedics got there, he was in something called [compensatory shock](https://www.cdc.gov/dengue/training/cme/ccm/page72318.html); and so suddenly he was feeling okay and was sort of relieved
- The paramedics were like, “*You’re good. We think you’re dehydrated. It’s a hot day. Just drink some water and you’ll probably feel better.*”
  - He thought that sounded good
  - But his wife insisted, “*He went blind a few minutes ago. You’re taking him to the ER.*”  So they took him to the ER
- It took them an hour and a half to get to the ER
- He lost bowel control on the way there
- He remembers thinking, “*All right. I went blind for a while. And I lost my bowels, that’s probably not a good sign. Something’s wrong.*”
- He got to the ER and the medic, the guy in the back of the ambulance with him said, “*We got to the ER and you just tanked. You turned white as a sheet.*”
- His [hemoglobin](https://en.wikipedia.org/wiki/Hemoglobin#Diagnostic_uses) was 1.2; the ER doctors think he probably lost about 90% of his blood
- He was in and out of consciousness
- At the ER his [blood pressure](https://en.wikipedia.org/wiki/Blood_pressure) was 60 over 40; the doctor asked permission to cut into his neck to put a line into my neck, in his [jugular](https://en.wikipedia.org/wiki/Internal_jugular_vein) vein
- He asked the doctor if this was for an emergency; he had no idea he was dying; the doctor replied, “*This is the emergency right now*”
  - So yea, he got permission
- When they started to cut into his neck, this was when he started to die
- A big black pit opened up underneath him and he started to get pulled down into it
- He  said to the doctor, “*You got to hurry. You’re losing me right now. You got to hurry.  I can feel myself going*.”
- And then his dead father appeared
  - Sebastian is an atheist; his father was a physicist
  - He’s not religious; he’s not a supernaturalist; he’s not a mystic
  - He doesn’t believe in anything he can’t measure and can’t test; and his father was the same way
  - But his father appeared above him in a kind of presence; he seemed to be welcoming him and Sebastian wanted to have nothing to do with him
  - It wasn’t a conversation, it was a communication
  - He couldn’t see him; he could feel him; he was a presence
  - And he was like, not now, dad; “*I love you, but I don’t want to have anything to do with you right now. I’m staying, I want to stay here*”
  - He wanted nothing to do with what whatever that was
- His dad had passed away 9 year earlier
  - Sebastian was with him, holding his hand when he died
- Sebastian has a spotty memory of what the doctor said next; he said something about pushing him as fast as he could without running to the cath lab
- He was in and out of consciousness
- He remembers they put him in a CAT scan and they had to shave him
- They put a line in his groin
  - He wanted to joke with them; he almost said, “*I’m sorry, I forgot to shave down there this morning*”
- They put a line in his groin and they had trouble seeing where the bleed was because there was much blood; he’d been bleeding into his abdomen for an hour and a half
- Luckily he’s a long distance runner and has a good heart; the doctor said if he wasn’t in really top shape, he would’ve died
  - He would’ve gone into cardiac arrest and his kidneys would’ve failed; it would’ve been over
- It took them another 8 hours to find the leak
  - He was on the fluoroscope for so long that he got radiation burns on his back
  - 2 weeks later, this square red patch appeared on his back because I had so much radiation
- He knew this was a hard thing to fix; it was in the middle of the night in a small hospital in Cape Cod, Hyannis Hospital
- He remembers the doctors looking at each other and literally were like— “*what do we do? We can’t find it. What do we do?*”
- But they were heroes; they pulled it off; they finally found it and they embolized it through catheter embolism
- They gave him 10 units of blood and saved his life
- He was in the [ICU](https://en.wikipedia.org/wiki/Intensive_care_unit) for 5 days
- He woke up the next morning and had no idea that he’d almost died

**The trauma of almost dying**

- The nurse came in, she was an experienced nurse, in her 50’s or 60’s maybe
  - She said, “*Listen, you almost died yesterday. You are the luckiest guy any of us know. We can’t believe you survived that.*”
    - He was horrified
    - He has these 2 little girls and he was absolutely traumatized by that news; he had no idea that he almost died
    - He sat there and thought about it
- He was throwing up blood pretty regularly
- When the nurse came back and asked how he was doing, he lied, *“Yeah, I’m doing okay physically, but honestly, I’m struggling with what you told me.*”
  - It’s terrifying that he can almost die in front of his family, in his own driveway when he’s a very healthy person on a nice June day
  - He doesn’t have heart problems or anything
  - It’s terrifying that the universe can just take someone out
  - He was totally traumatized by this
- The nurse said, “*Try thinking about that as a sacred experience, rather than a scary experience.*”
  - And then she walked out of the room
  - Now he’s been thinking about that his whole life
  - He was given a glimpse of the mystery, the great mystery of death
  - He was allowed to look at it and allowed to survive the look at it, and he got brought back
  - Then he started to do some research

> “*I can’t tell you how traumatizing that whole thing was, combat’s nothing compared to that. That really messed me up*.” – Sebastian Junger

- This was June of 2020
- He started to think, had he been on an airplane, he would’ve died
  - Had he been on a walk in the woods, he would’ve died
  - Had he been almost anywhere, but where he was, he would’ve died
  - And he got super paranoid; it was extremely traumatic
  - At least in combat, it can be left behind when one comes home

**Reports of near-death experiences share commonalities**

- So he started to look into near-death experiences by people
- Imagine his surprise to find that an awful lot of people see the black pit
  - An awful lot of people have dead relatives at the threshold to engage with them
  - And it really got him interested— what is this? Are we really sure?
  - It really aroused his curiosity about this consistency of experience across many different societies, many different kinds of people
- These experiences are irreproducible through low blood oxygen, ketamine, endogenous DMT— all the things that happened in the dying brain
  - When these things are reproduced artificially, people don’t have near-death experiences
- This made him start to wonder, “*wow, maybe it isn’t just nothing, maybe there is some other dimension that some kind of existence continues on that we just don’t understand, or even don’t even have brains developed enough capable of understanding it.*”
- He knows there has been some research in quantum physics trying to understand a possible post-death existence in terms of quantum physics and quantum fluctuation and all that stuff
  - These are people who are a lot smarter than him and he doesn’t know if he’d even understand it, but it did intrigue him in an empirical sense
  - It aroused the question, “*are we actually completely sure that there’s nothing because that’s not what my experience of it was*”
- He’s talked about this on some podcasts and people have reached out on social media
  - He has had some affirmation, not only of the mystery of it, but of the trauma of it

**His research into near-death experiences**

- He hasn’t spoken to any neuroscientists but he has read some papers on near-death experiences
- One of the things he learned is that [ketamine](https://en.wikipedia.org/wiki/Ketamine) is released in the dying brain
- When someone takes ketamine, they’ll have all kinds of visions
  - They won’t necessarily see their dead father
- Someone can be deprived of oxygen so that the blood levels of oxygen are very low, and they don’t necessarily have the experience of the dying person
- There’s something called [DMT](https://en.wikipedia.org/wiki/N,N-Dimethyltryptamine); he thinks it’s akin to [ecstasy/ MDMA](https://en.wikipedia.org/wiki/MDMA)
  - He’s not sure what the drug is, but there is an endogenous compound that is also a drug that is released in the dying brain
  - This drug doesn’t produce some of the hallmark experiences of near death
  - So there is an ongoing mystery about exactly what this is

**Sebastian’s recovery [2:09:00]**

- Peter asks about his recovery
- He thinks he came home on the 7th day
- He had a huge [hematoma](https://en.wikipedia.org/wiki/Hematoma) in his abdomen; so he had a large amount of dead blood
  - It took months for his body to process that
- Pretty quickly he was walking and then running but his physical activity was really constrained by his paranoia
  - He thought maybe he should rent an apartment next to the hospital
  - He sort of joked about it with my wife, that it was a miracle that survived an hour and a half
  - He just didn’t want to do anything that might make it hard for an ambulance crew to get to him
  - So he definitely wasn’t going to go running in the woods

> “*And all these things that have been part of my life, my whole life, suddenly they were terrifying to me. I became someone I didn’t recognize*.” – Sebastian Junger

- For a while he became an incredibly neurotic, fearful person
  - Frankly, he’s still dealing with it
  - If he didn’t have a family, he might be less worried about it
- Now he worries; he doesn’t want to go to Africa with his family and expire on a transatlantic flight next to his kids
- He’s in the process of making sure that this kind of thing can’t happen with any of his other small arteries
- But as with combat trauma, the passage of time helps
  - But it really changed him and he thinks it might have changed him forever
  - He’s not sure that fear is going to entirely go away
  - There are certain loud noises he still jumps at because they sound like gunshots; he’s not sure that’s ever going away
- Peter asks, “*Have you been able to sort of incorporate the wisdom from that nurse*?”
- He’s working on it
- An anthropologist friend of his said, “*you had a classic shamanic journey*”
  - The [shaman](https://en.wikipedia.org/wiki/Shamanism) goes to the sort of threshold of death, encounters the afterworld then comes back with some information
- For his whole life, he has gone to places of death, war zones, and he has come back with information for people
- So maybe he can look at it as a kind of journalistic journey
  - What information will he come back with that might be useful to other people and to himself
- He’s working on this and is going to write a book called *Pulse* about what happened to him physically, but also what the consequences were psychologically and what the possibilities are metaphysically
  - He wants to talk to a [quantum physicist](https://en.wikipedia.org/wiki/Quantum_mechanics) about [quantum fluctuation](https://en.wikipedia.org/wiki/Quantum_fluctuation) and the possible enduring nature of the soul, et cetera
  - He would like to walk through the possibilities to see what might be the explanation for his experience

## Sebastian’s experience with depression and anxiety [2:12:00]

Peter asks about the PTSD associated with his near-death experience— *Does it cause more depression or anxiety?*

- Anxiety for sure
- His experience as a war reporter also caused PTSD related anxiety

**The death of his friend, TIm and losing an unborn child**

- During his first marriage, his wife lost a pregnancy
- Simultaneously, he found out his friend, Tim was killed
- The timing of both of these things was psychologically complicated for him
- For the first time in his life, he found himself in a real depression, a dangerous depression
  - He felt removed and isolated from every person he loved, including his wife at the time
  - He felt like he was living behind a bulletproof plexiglass and couldn’t escape

> “*It [depression] was a dangerous, dangerous feeling. I figured it out, but it was a very, very unpleasant time in my life*.” – Sebastian Junger

Peter asked, “*What do you think was the most important factor or factors that helped you emerge from that?*”

- Talking to somebody, a professional about it definitely helped
- He was married to someone he really loved, but the marriage wasn’t working and eventually they both sort of confronted that, and acknowledged it, and ended the marriage
  - That was very painful, but it felt like a healthy step
  - They’re still friends
  - The marriage didn’t work, but the divorce did
- He started drinking a little more than he probably should have.
  - By no means was he an alcoholic, but he had a unhealthy relationship with alcohol
  - So then he stopped drinking
    - He had [atrial fibrillation](https://en.wikipedia.org/wiki/Atrial_fibrillation), which is a arrhythmia in the heart
    - He had an ablation that fixed it completely, but the doctor said, “*Alcohol can trigger it. Try not drinking.*” And he didn’t drink for a month
    - Not drinking felt so good that he turned the corner
- And all of a sudden he was starting to feel like an emotionally healthy person
  - It was a lot of different things

Peter asks, “*Who was your tribe at that point in life? You’d obviously lost a very important member of your tribe. If I’m doing the math correctly, you would go on to lose another important member of the tribe, being your father*.”

- Sebastian met someone else and remarried
  - She had been through some pretty tough things herself, not combat
  - There was something about her compassion and understanding that was enormously helpful to him, that was really quite profound

**Anxiety**

- The problem with anxiety is it doesn’t make sense

> “*You’re anxious about something that isn’t rational*” – Sebastian Junger

- So being told rationally not to worry about this, “*you’re not going to get another arterial rupture. It’s not going to happen.*”
  - This doesn’t help
  - The anxiety isn’t necessarily tied to reality
- Likewise with depression, someone can be very depressed and the fraternity of other people, the love of other people might not reach them
  - Because the nature of depression is that they’re at the bottom of the ocean
  - They can’t be reached; they know someone is talking to them, someone loves them, they see their lips moving
  - But no one can understand where they are; they can’t be reached

**Community and being needed by the group helps one recover**

- One of the biggest things that helps someone in those circumstances is feeling needed and feeling useful and being asked to contribute

> “When people are needed by the group, they click into this thing that actually improves their own psychological state of mind.” —Sebastian Junger

- For example…
  - The admissions to psych wards in London during the [Blitz](https://en.wikipedia.org/wiki/The_Blitz) went down, went down during the during the bombings
  - Suicide went down post-[9/11](https://en.wikipedia.org/wiki/September_11_attacks)
- So the crisis engenders this kind of call to action, which allows people to buffer themselves from their psychological troubles
- And the love of one person sometimes is quite painful to experience because one realizes that that person who loves them can’t reach them where they are
- But being **needed** is a different thing

> “*I think ultimately the sense of being necessary might be the ultimate antidote to the experience of depression*” – Sebastian Junger

## The pandemic’s impact on mental health [2:16:45]

Peter reflects on the current opioid epidemic and remembers wondering as the COVID pandemic took hold in March of 2020, if this crisis would make people better and improve the collective state of our emotional health in the way that previous crises had (like Great Depression, WWII, 9/11, etc.)

- But there has been an enormous increase in accidental overdoses since then
  - This has overtaken all other forms of accidental death
  - It’s exceeded car accidents in the aged demographic where car accidents have historically been the leading cause of death
  - This was’t because people weren’t driving; it was due to a surge in overdoses
- Peter asks if the rise in overdoses is fueled by the isolation of the pandemic

Sebastian thinks a couple things are going on

- 1) Everyone was asked to protect the nation by isolating from each other
  - In a crisis, humans want to come together, to be in close physical proximity because that’s what makes people feel safe
  - When someone is scared, if they are facing a crisis and are in the proximity of others their [oxytocin](https://en.wikipedia.org/wiki/Oxytocin) levels rise
    - In men, their [testosterone](https://en.wikipedia.org/wiki/Testosterone) levels rise
    - Being with a group does all kinds of good things that allow the group to deal with the crisis
  - The opposite has happened in this crisis; people are alienated and isolated
    - This very often leads to depression
  - Just ask someone who’s done a week in solitary confinement at a federal penitentiary what the effects of isolation are
  - They’d rather be electrocuted, have their meals taken away, anything than be in a hole by themself
  - Being alone is the hardest thing for humans
- 2) There was no unity of purpose
  - The political leadership was completely contradictory about what it meant to be a good American
  - On one hand, there were knowledgeable people saying being a good American means wearing a mask and social distancing and eventually getting your vaccine, right
  - But then there was political leadership that said it actually means not wearing a mask and not social distancing and not getting a vaccine
  - So the discordant contradictory messages from the upper, upper echelons of our society, made people crazy
  - There was no way to feel like, “*Oh, I’m saving aluminum cans. Once a week, I’m going to take them down to the scrap metal drive in my little town, because the troops overseas need the metal.*”
  - There was no unity of purpose there because people were being told completely contradictory things by the political leadership
- Peter adds the lack of an “external enemy”
  - Peter notes that in the depression, there wasn’t an external enemy in the way that there was in World War II or post-9/11, but unity could still exist
- Sebastian thinks that if [Donald Trump](https://en.wikipedia.org/wiki/Donald_Trump) come out and said, “*it’s your patriotic duty to wear a mask and to social distance, and you know what, if you get the vaccine, I know maybe you were worried about it, maybe you’re scared of it, if you get the vaccine, you’re a damn hero to this country.*”—  most of the country would’ve done it
  - Unfortunately he didn’t choose to do that
  - Even though he sort of mumbled at one point that people should wear a mask and he got himself a vaccine
    - I’m sure the whole White House staff did, as did all of Fox News and all of CNN— everybody got the vaccine
  - But the split messaging from that side of the American political environment was enormously confusing
- Sebastian is a democrat but has enormous respect for elements of the conservative political ideal; he gets it, he doesn’t share it, but he respects it
- He found incredibly selfish and unbelievably anti-American and unpatriotic for the Trump administration to engage in that stuff

## Sebastian’s thoughts on the withdrawal of troops from Afghanistan [2:22:00]

**Peter asks what Sebastian thinks about the withdrawal of troops from Afghanistan**

- He thinks Afghanistan was really more of a peacekeeping operation
  - 5,000 troops could have stayed there in definitely and kept the Taliban at bay
  - This would’ve been a fraction of the number of troops that the US has in Germany, for example, or South Korea or in any number of our allies
- Put the troop number in perspective, there are 40,000 cops in New York City
- When the US finally withdrew the last troops, it was down to a couple thousand, 2,500
  - Include NATO and maybe round this up to 5,000
- Their ability to carry out targeted airstrikes, just a safety trip wire of American forces in Afghanistan, would’ve essentially guaranteed that the Taliban could not overrun the rest of the country
- At minimal cost in lives and treasure, the Taliban had not attacked American forces since February of 2020
- Maybe if the US decided to stay, it wouldn’t have changed anything, but the US could have maintained troops there at minimal costs to this nation and at enormous benefit to the Afghan people
- He wrote a piece for [*Vanity Fair*](https://www.vanityfair.com/news/2021/08/a-vast-criminal-racket-sebastian-junger-on-how-the-us-corrupted-afghanistan) about this recently, a few weeks ago
  - The reason the Taliban were allowed in by the Afghan populist was that they promised to clean up corruption and they pretty much did
  - Abuse at the police checkpoints, where one has to bribe the policeman to get through with one’s family, every time one had to file a piece of paper with the government and had to bribe the clerk to do that
  - That kind of awful endemic corruption makes the lives of ordinary Afghans, ordinary people absolutely miserable and enriches at the top of the food chain; it makes these warlords and government ministers obscenely wealthy
  - The Taliban cleaned that up

> “*Our big mistake was that we stood up a government in Afghanistan that was incredibly corrupt*” – Sebastian Junger

- The US never insisted on any kind of accountability for the money was pumped in there
  - Money was going to these warlords and to corrupt governors, just enriching them
- It was an enormously abusive system and the US didn’t care
- The US gave them the kind of government that Afghans don’t want and that Afghan soldiers understandably, are not willing to die for
- It wasn’t the military; they would’ve done whatever they were ordered
  - If the orders came down, look, you got to track every penny and make sure it’s not getting abused, the military would’ve done that as much as they were capable of
- It was the state department that was not interested in pursuing accountability
- It’s tragic
- In the end, if the US wasn’t going to insist on a decent government, what was the point of staying forever anyway

> “*You can’t ask anyone to die for a corrupt system and that’s what we would’ve been asking American soldiers to do*” – Sebastian Junger

- This begs the question, why did the US allow a corrupt system to blossom under our watch when we held all the trump cards and could have forced that government to actually act ethically?
- He doesn’t know; he brought it up with [John Kerry](https://en.wikipedia.org/wiki/John_Kerry) in 2010
  - The war wasn’t going well then and he asked for a meeting with Sebastian
  - He told Kerry, “*the war’s never going to go well until you address the corruption issue, because Afghans are never going to fight for this government you’ve given them*”
  - Kerry thought they couldn’t do that, that the US lacked leverage
  - Sebastian couldn’t understand this, the US could threaten to leave Afghanistan
    - The last time the Taliban took over, they hung the president [Najibullah](https://en.wikipedia.org/wiki/Mohammad_Najibullah) from a street lamp for corruption
    - Every corrupt government minister knows that if the US pulls out, they’re all hanging from street lamps
    - There was a huge amount of leverage and the US just wouldn’t do it; it was too much of a hassle

## Sebastian’s latest book—*Freedom*, and knowing when to quit [2:27:00]

**Inspiration for the book,** [**Freedom**](https://www.amazon.com/Freedom-Sebastian-Junger/dp/1982153415)

- Sebastian walked along the railroad lines from Washington, DC to Philadelphia to Pittsburgh
  - This is called high speed vagrancy
- Railroad lines are this kind of swath of no man’s land that goes right through America, right through the ghettos and the suburbs and the farms and the industries and the junkyards and everything
  - It’s no man’s land and one can do whatever they want as long as the cops don’t catch them
- There was this interesting 400 mile game of hide and seek with the cops and he was sleeping under bridges and in abandoned buildings and getting water out of creeks
- Most nights, no one knew where they were
- There are many definitions of freedom, but surely this is one of them
- That was 8 years ago that he did that trip with 3 other guys that had been in a lot of combat

**Decision to write a book**

- A few years ago, he decided he wanted to write a book about freedom
- For him, the word freedom, the thing he wanted to understand about it is that humans are the only species where a smaller individual or a smaller group can out fight a larger individual or a larger group
- To talk about freedom, basically it is about an underdog group maintaining their autonomy in the face of a greater power
  - How does that work?
  - The [Montenegrans](https://en.wikipedia.org/wiki/Montenegrins) in the early 1600s were outnumbered 12 to 1 when the [Ottoman Empire](https://en.wikipedia.org/wiki/Ottoman_Empire) invaded their mountain domain
    - And every time the Ottomans came in, the Montenegrans destroyed them
    - There’s no mammal where that could be true, only humans

> “*I organized my thoughts into three sections in my book, ‘run, fight, and think.’ Those are basically the three ways that humans maintain their autonomy*.” – Sebastian Junger

- Humans can *outrun* the oppressors, like the [Apache](https://en.wikipedia.org/wiki/Apache) did
  - The Apache remained autonomous for centuries while their sedentary wealthier, [Pueblo](https://en.wikipedia.org/wiki/Pueblo) neighbors got rolled by the Spanish immediately
  - Some elements of the Apache remained free until 1886
  - They did that by being mobile
- But if humans can’t outrun their oppressor, they’re going to have to *outfight* them
- The ability of small human groups to defeat on the battlefield, much more powerful adversaries, like the Taliban defeated the United States and the Russians before us and the English before that, this is unique to the human species
- He looked at [MMA](https://en.wikipedia.org/wiki/Mixed_martial_arts) and some of the individual martial arts to explore the dynamics of combat to understand how smaller individuals can defeat larger ones
  - One of the reasons that happens is that big muscles require a lot of oxygen
  - If a big guy throws 20 punches in a row and doesn’t connect, he’s out of breath at the end of that
  - Small muscles, small frames use less oxygen and are more reactive and more efficient
  - A smaller fighter can slip 20 punches and not be in oxygen debt, unlike the big guy
    - That’s essentially what the Taliban did with the US on a sort of macro scale
    - Massive armies go through enormous amounts of resources that insurgencies don’t
    - And after 20 years, the US basically ran out of resources and the will to spend them
- The final chapter in his book is called *Think*, and it’s about how one can maintain their autonomy within society
  - So the first thing one has to do is repel the enemy, outrun or out fight the enemy
  - But the problem in human history is that a community, a society that’s well enough organized to outfight an enemy is well enough organized to oppress their own people
    - Fascist dictators throughout history, totalitarian states, they are very militaristic societies that are well armed to repel invaders, but they also use that military organization to oppress their own society and control it
  - He looks at how societies can maintain their freedom from within, from an oppressor that is of their own people, an oppressive leader
  - He looked at the labor movement in America around 100 years ago

> “*And the brilliance of the human species is that we can out-think more powerful entities*” – Sebastian Junger

- And the labor movement was able to eventually get their way in the face of the national guard with fixed bayonets and the entire US government
  - They eventually got their way in terms of fair pay and fair work hours, fair work conditions

**With the right leadership, a small group can succeed against a larger group**

- What is needed to accomplish this is selfless leaders
  - To overthrow the British in Dublin in Ireland in 1916; or to confront the US government as a labor uprising, requires leaders who are willing to die for the cause
  - They cannot tell everyone else to rush the machine guns while they stay hiding behind the sandbags
  - Without leaders that are willing to die, as an underdog group, the group will not win.
- Likewise, women are needed
  - Social movements, political movements, and insurgencies that don’t incorporate women into their power structure and into their stragedy and tactics, will probably not succeed
- He looked at the mill strikes in America, and the turning point came when the [strikers in Lawrence, Massachusetts](https://en.wikipedia.org/wiki/1912_Lawrence_textile_strike) started putting women on the front lines to confront the national guard soldiers with fixed bayonets
  - And the soldiers didn’t know what to do
  - They were not willing to bayonet women; they had mothers, they had sisters, they had wives
  - Killing men is morally much less of a problem even for totalitarian regimes and certainly for democracies
  - So when women are put into the equation, the police don’t quite know what to do
  - As one frustrated policeman said at the time, “*One cop can handle 10 men, but it takes 10 cops to handle one woman.*”
  - That was the beginning of the end for the resistance to these crucial changes that came to the textile industry in 1912, 1914

*Peter asked if the Taliban ever used women for their gains?*

- No, but the thing is that on the battlefield, particularly at the distances that are typical of modern combat, automatic weapons easily fire 200, 300, 400 meters, soldiers don’t see the faces of the people they’re fighting
  - They certainly don’t know what sex they are.
- Women’s capabilities really come to the fore in the kinds of insurgencies… for example, the [battle of Algiers](https://en.wikipedia.org/wiki/Battle_of_Algiers_(1956%E2%80%931957)), when the French were occupying Algiers and Morocco in the 1950s and 1960s, or the mill strikes in Massachusetts
  - Women have lateral networks; they’re not good at top down hierarchies
  - Men are good at top down hierarchies
  - And the top guy says, “A*ll right, now we’re going to charge the machine guns,*” and men will do it, right?
  - And women, their forte is not that so much as lateral egalitarian networks, they’re unranked, but they’re lateral
- It’s very hard for the intelligence agencies to penetrate those networks
- Basically, an insurgency depends on the society from which it springs to fight
  - So that men are exclusively male fighters, but if they are not part of a society that incorporates women (and women are absolutely crucial to any functioning society), if women are not incorporated, it’s not going to go very far
  - [The Easter rising in Ireland](https://en.wikipedia.org/wiki/Easter_Rising) is another excellent example of that
  - If women are literally on the front lines, it doesn’t matter so much in open combat because a lot of it is spray and pray tactics; they’re just unloading a belted machine gun
  - In a situation like the mill strikes in Lawrence, here, society is face to face with itself, and there is some public accountability to murdering women with bayonets

**Will the Taliban be successful in governing Afghanistan?**

- Peter asks, “*now that the Taliban will likely be carrying out their actions, not at 400 meters, what do you think is going to be the natural history of how things go in Afghanistan?*”
- Sebastian replies that it takes a very different temperament and a very different mindset to be a successful insurgency than to run a government
- He has heard that the Taliban fighters are now bored; they miss the war
- The Taliban are brilliant insurgency, brilliant strategic thinkers
  - They outlasted our will to fight the most powerful military ever in human history.
  - Now they have to run Afghanistan
  - It’s twice the population it was in 1996 when they took power back then
    - The cities have been modernized
    - A generation of Afghans have received education
    - The Afghan girls have received education.
    - They’re going to find Afghanistan to be an unwieldy mess that is very, very hard to run and run according to Sharia law

> “*So I don’t know what the future holds, but I imagine that there’s going to be some fracturing within the Taliban*” – Sebastian Junger

- There’s going to be a falling out between the really hardcore, ultra conservative elements and the more modern elements that want engagement witht he west
- The [Tajik resistance](https://en.wikipedia.org/wiki/National_Resistance_Front_of_Afghanistan) is organizing itself in Masud’s old territory [Badakhshan](https://en.wikipedia.org/wiki/Badakhshan), and the Northeast quadrant of the country
- If they don’t abide by some basic international human rights norms, they’re going to have a very, very hard time accessing international donations, international monetary systems, international relief efforts, and recognition by foreign governments
  - Some countries may not care, but to the west, this is important
- The original Taliban was recognized by the UAE, Pakistan and one other country, maybe Saudi Arabia
- $8 billion of Afghan money is sitting in New York banks and it will not be released without some kind of legitimacy to the Afghan government
- The Taliban have a world of hurt ahead of them
- They may make it work, but it’s not going to be the simple prospect that it was in 1996, when all these cities were rubble and the population was half this size and no one had cell phones and whatever else; they’re going to have a tough hill to climb

**Sebastian’s walk with friends is the basis of his book** [***Freedom***](https://www.amazon.com/Freedom-Sebastian-Junger/dp/1982153415/ref=sr_1_2?keywords=sebastian+junger&qid=1638299921&qsid=131-3146834-4509605&s=books&sr=1-2&sres=1982153415%2CB01D57FNZG%2C044655622X%2C0060742690%2C0393337014%2C0060088613%2CB005YPJ5CU%2CB089V1XS2P%2C1633885704%2CB09BDDV5P2%2CB00HI9K7BI%2CB01IIW6NJI%2CB01JXTW10A%2C1982159006%2CB00A7GZ9KS%2CB07N6MPWLS&srpt=ABIS_BOOK) **and the documentary** [***The Last Patrol***](https://www.hbo.com/documentaries/the-last-patrol)

![](https://peterattiamd.com/wp-content/uploads/2022/02/last-patrol-junger-1024x666.jpeg)

**Figure 2.** ‘The Last Patrol’: From left: Brendan O’Byrne, Guillermo Cervera and Sebastian Junger are in this HBO documentary on Monday night. [Image by Guillermo Cervera/HBO.] *Credit:* [*nytimes.com*](https://www.nytimes.com/2014/11/10/arts/in-the-last-patrol-sebastian-junger-zeroes-in-on-manhood.html)

- Peter asked how long his journey was
- He walked on and off for a year
  - Then he kept doing it a little bit after that, from time to time with 1 or 2 buddies
  - They called it the last patrol
- He brought a videographer, who quickly became part of the group
- *The Last Patrol* was aired on HBO in 2015
- But after they stopped shooting, some of them kept going back out there
  - He really liked it out there on the railroad lines

**The end of this journey and the importance of instinct**

- Peter asked, “*When did you know you were done?*”
- He was headed for a place called [Jumonville Glen, where the French and Indian war basically started](https://en.wikipedia.org/wiki/Battle_of_Jumonville_Glen)
  - A young [George Washington](https://en.wikipedia.org/wiki/George_Washington) in 1754 led a war expedition against a French force, reconnaissance force and his sort of native tracker and scout (a [Seneca](https://en.wikipedia.org/wiki/Seneca_people)), he precipitated a massacre of some of the French soldiers who surrendered to Washington
  - And that triggered a reaction by the Brits, which went into the [French and Indian War](https://en.wikipedia.org/wiki/French_and_Indian_War), which eventually set the terms for the [Revolutionary War](https://en.wikipedia.org/wiki/American_Revolutionary_War)
  - Without the British winning the French and Indian war, the seven years war, we might not have dared throw off British rule with France right on the border
  - So it’s an iconic place that very few people have heard of;it’s right outside of [Connellsville, Pennsylvania](https://en.wikipedia.org/wiki/Connellsville,_Pennsylvania), Western Pennsylvania.
  - He wanted to end there; he wanted to sneak into Jumonville Glen, it’s in the woods, and sleep in the woods
  - He was thinking that the last people that slept there under this little cliff might have been the French forces under Jumonville in 1754
  - It’s a national historical site
  - He wanted to get there before dawn, before the park guards showed up.
  - They got to Connellsville; it was very hot day
  - He had sort of shredded his feet — It was 100 degrees during the day; they were carrying a lot of weight (60, 70 lbs on their back) and they were moving 10, 20 miles a day
  - And basically, the bottoms of their feet kind of turned to oatmeal
  - His feet were bleeding and he was in an enormous amount of pain when they got to Connellsville
  - Connellsville was very, very poor;it’s an old industrial town.
  - They stumbled and limped to the cobble of the beach along the [Youghiogheny River](https://en.wikipedia.org/wiki/Youghiogheny_River) and took off their boots and shirt and staggered into the water
  - When he came back, he sat down and they were exhausted; he could barely walk
  - They were going to sleep somewhere in downtown Connellsville
  - They were going to try to hide from the police somewhere and sleep along the river and then keep moving in the morning
  - They had 15 miles to go to get to Jumonville Glen; and he looked around at the guys
    - He was in the middle of getting divorced
    - And he said, “Y*ou know what? The trip just ended. We don’t need to go to Jumonville Glen. It’s over. We’re done. We got what we needed out of this. It’s time to go home and face our… All of us go home and face our lives*,” which is what they did
  - So he recognized the ending when it came to him
    - He didn’t know ahead of time; he  didn’t wake up in the morning thinking that
    - He knew it in the moment

> “One of the great things to work on is to know in the moment when things are over; trips, relationship, anything. When it’s over, you’ve got to know it’s over. And if you don’t, God help you.” —Sebastian Junger

- Peter agrees, knowing when to quit is an amazing gift, “*What are some of the signs? How do you know when it’s time?  Because it’s not always obvious in the moment.*”
- For Sebastian, you’ve got to feel it
  - Instincts, feelings don’t lie
  - But this is different from thinking one should do something because it’s embarrassing not to; that’s not the right reason

> “*Instincts serve us very, very well. And you’ve got to pay attention to them*.” – Sebastian Junger

- He felt it and he thought “*why exactly are you going to Jumonville Glen? Oh, because you thought that would be a cool ending for your little project?… the symbolism of it*”
  - Symbolism is not the right reason to do something
  - He doesn’t want to do something because it’s a good ending
  - He’s got to feel what he needs, what is right, and what is good
  - He looked around, they were all broken; they could do it physically if they had to, ***but why?***
    - He couldn’t answer that question

> “*If you can’t answer that question, very readily, with conviction and with some feeling in your chest, if you can’t answer it, don’t do it*.” – Sebastian Junger

- Peter asked if any of the guys put up an argument
- No; everyone was thrilled; they all knew the trip was over
- Peter asked, “*Do you think that they simultaneously knew or do you think that they had come to that conclusion earlier and didn’t want to speak up?*”
- He thinks he somehow convinced his friends that he knew what he was doing and they trustee his decisions
- They got shot at in Pennsylvania; somebody started shooting at them just because they didn’t like the looks of them
- They were hungry, they were cold, they walked through the winter
- They would walk into a town and buy some food and keep walking out the other side and go back out onto the lines.
- They smoked a little tobacco out there
- They would stop in a town, they’d go in; they looked like hell
  - They looked homeless, basically
  - And then we’d keep going
- The cops were looking for them with a helicopter; all kinds of weird, crazy stuff happened
- But they were a unit, right?
  - They were brothers, they were connected
  - And so when that moment came by the Youghiogheny River, he thinks they all felt it, and it was the obvious thing to do

## Defining freedom in modern society [2:44:30]

Peter asks him to look over the last 250 years of American civilization; *when does he think we are the most free?*

- Politically, we’re the most free now
  - Obviously the initial democratic endeavor with the constitution and the Bill of Rights forgot to include black people, an outrageous transgression; that’s not a free society
  - Politically, by the time of the civil rights movement, suffrage, and then the civil rights movement, the labor movement
  - By time of the 1970s, 1980s, we’re starting to at least approach some political freedom
- Economic freedom is a different matter
- In society where the income gap is too wide between rich and poor, it’s hard to argue it’s a completely free society
  - People can be held in sort of a voluntary bondage, of having to work three jobs— that’s not a free society
- But then following on from that, if one can’t freely make choices that are good for oneself, one is not free
- If someone is addicted to something, they’re not entirely free
  - And we live in a massively addicted society
  - Addicted to substances, addicted to visual stimuli from television or iPhones
  - We are not free people in that sense
  - And he doesn’t know which is worse, the inability to vote or the inability to look up from one’s iPhone
    - Which is a greater form of oppression, which erodes human dignity more?
- Sebastian had the good fortune to interview a man who had spent some decades in prison for doing an extremely bad thing from a very brutal, diminished situation in his family and his society
  - It had the predictable results of violence and crime
  - He killed somebody and he paid the price for it; he spent almost 30 years in prison educating himself
  - He found God; Sebastian is an atheist, but he completely respects someone who finds God
  - And he straightened himself out and he was let out on good behavior
- Sebastian was able to interview this man a couple weeks after he was let out of prison
  - After he spent some 25 years in prison
  - And at the end of the interview, he said, “*I feel silly asking this, but is it possible to be more free in prison than outside of prison?*”
  - And he looked at him like he was crazy and said, “*Yeah, of course it is. Are you kidding? You can’t be a drug addict in prison. You don’t have an iPhone. You can’t be all distracted.*”
  - He looked at people walking around— they’re not free; they’re all chained to something
  - He said, “*If you’re in prison, you’ve got nothing but time, and eventually, eventually you’re going to have an honest conversation with yourself about who you really are and what you’re doing in there. And when you have that conversation with yourself, you’re a free man no matter where you are.*”
  - There are a lot of people on the outside that never get around to having that conversation with themselves

> “*I don’t think you can pin down an era. I would say our freedom right now in a historical context is breathtaking in its depth, but with some very, very serious worrisome caveats*” – Sebastian Junger

- Among these caveats are economic inequality; that’s going to bring us down
- Peter thinks the point of view of that guy who just got out of prison is staggering; the insight is profound

> “*If you can’t look at yourself, if you can’t examine who you are, if you’re too distracted by the trappings of filling the blank, how free are you?*” – Peter Attia

**What does it mean to be free?**

- Peter asks about a guy Sebastian came across while on patrol, he had a shovel tied around his belt and a few other possession; basically everything he owned was with him
  - Is this guy the most free guy he’s ever seen or the least free?
- Sebastian doesn’t have an answer for this
- Material possessions give one a kind of freedom in the sense that they’re not living a survival level marginal existence, but they require work
  - Does one want to have freedom of maneuver?
  - Does one want to be able to be mobile?
  - Does one want to have temporal freedom where their time is their own?
  - Does one want to have freedom where they have a whole ton of money and can make choices? “*I’m going to stay at that hotel. I’m going to do this. I’m going to do that*.”

> “*There’s no form of freedom where you have it all*” – Sebastian Junger

- And so that guy, he didn’t talk to him; he just got a glimpse of him
  - But he had all of his possessions tied to the blade of a snow shovel, and then the snow shovel, the handle was tied to the back of his pants and he was walking along sledding all of his belongings behind him
  - He clearly didn’t have a job to go do in the morning and clearly was living out of dumpsters and whatever else
  - So, yeah, is he free? Is he the ultimate free person or the ultimate oppressed person? Sebastian doesn’t know
- He doesn’t offer answers, but some of the questions are interesting

**Comparing freedom in modern society to nomadic societies**

- And he will say sedentary society started about 10,000 years ago when humans started to cultivate wild grains in [Mesopotamia](https://en.wikipedia.org/wiki/Mesopotamia)
- And what that allowed for, an accumulation of wealth, and it allowed for social hierarchies
  - The development of class, leaders and led, rulers and serfs
  - The advantage of that system is that one could feed a 40,000 man army and defend themselves and their riches very, very easily
- Nothing’s going to overrun the city of [Ur](https://en.wikipedia.org/wiki/Ur)
  - It had huge, massive walls, a massive army
  - The disadvantage is that most people spent most of their day working and working for the Pharaoh
  - Metaphorically speaking, working for their ruler
  - And so the nomads of that era were material really poor like the Apache were, but their time was their own
    - They were completely mobile
    - And it was an egalitarian society
    - It’s hard to oppress people that can put everything they own on the back of a horse and leave in the middle of the night, right?
- So nomadic peoples have typically been materially purely poor and very, very autonomous and very egalitarian
- For a lot of human history, wealthy sedentary people have romanticized, mobile nomadic peoples precisely because it looks and is so free
- Even in this society, we romanticize outlaws and motorcycle gangs and all those groups that most of us never want to be part of
  - But it’s enormously romanticized because they’re mobile and they’re fairly egalitarian
- And that’s exactly what nomads were for 10,000 years and still are
- There’s a very revealing quote from a group, a song from a group of nomads called the [Yomut](https://en.wikipedia.org/wiki/Yomut) in Northern Iran, in the vast grand grasslands around the Caspian Sea.
  - The Yomut were a tribal, mobile, pastoral, nomadic society, very war-like
  - They said of their wealthy, sedentary neighbors, they said, “*I am Yomut. I do not have a mill with Willow trees.*”
    - In other words, they are not a farmer, they do not have a mill with willow trees
    - “*I have a horse in court. I will kill you and go.*”— ultimate arrogance and pride of a nomadic, a war-like, nomadic person
- The enormous wealth and sedentary nature of Western society has enabled us to do astounding things
  - Scientifically, technologically it’s allowed for the rise of democracy and rule of law and the medicine that saved my life
  - The list is endless, but we’re not the Yomut, right?

> “*There is something inherent, something important to human dignity that takes place in a society that is mobile and entirely governing of its own circumstances, and more or less egalitarian.*” –  Sebastian Junger

- There is something essential to human dignity that happens in those societies that has trouble happening in the wealthy, amazing industrial society that we live in
- We’re not going to go back to being nomads, but it might help just to take note of those qualities and maybe instill some of them where we can into our own society

§

## Selected Links / Related Material

**Sebastian’s books:**

- [Tribe: On Homecoming and Belonging by Sebastian Junger](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638299921&sr=1-3) (2016) | [0:45, 1:07:30, 2:14:00]
- [The Perfect Storm: A True Story of Men Against the Sea](https://www.amazon.com/Perfect-Storm-True-Story-Against/dp/039304016X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638300138&sr=1-6) by Sebastian Junger (1997) | [0:45, 28:15]
- [Fire](https://www.amazon.com/Fire-Sebastian-Junger/dp/0393010465/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638300138&sr=1-7) by Sebastian Junger (2001)  [0:45]
- [A Death in Belmont](https://www.amazon.com/Death-Belmont-Sebastian-Junger/dp/0393059804/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638299921&sr=1-5) by Sebastian Junger (2006) | [0:45]
- [War](https://www.amazon.com/WAR-Sebastian-Junger/dp/0446556246/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1638299921&sr=1-4) by Sebastian Junger (2010) | [0:45; 51:30]
- [Freedom](https://www.amazon.com/Freedom-Sebastian-Junger/dp/1982153415/ref=sr_1_2?keywords=sebastian+junger&qid=1638299921&qsid=131-3146834-4509605&s=books&sr=1-2&sres=1982153415%2CB01D57FNZG%2C044655622X%2C0060742690%2C0393337014%2C0060088613%2CB005YPJ5CU%2CB089V1XS2P%2C1633885704%2CB09BDDV5P2%2CB00HI9K7BI%2CB01IIW6NJI%2CB01JXTW10A%2C1982159006%2CB00A7GZ9KS%2CB07N6MPWLS&srpt=ABIS_BOOK) by Sebastian Junger (2021) | [1:00, 1:45:00; 2:27:00]

**Sebastian’s documentaries:**

- [Restrepo](https://www.imdb.com/title/tt1559549/?ref_=fn_al_tt_1) [1:15, 51:45, 1:22:30]
- [Korengal](https://www.imdb.com/title/tt3578504/?ref_=fn_al_tt_1) [1:15; 50:15]
- [The Last Patrol](https://www.hbo.com/documentaries/the-last-patrol) [1:15,3:00, 2:38:00]
- [Which is the Way to the Front of the Line From Here?](https://www.imdb.com/title/tt2480784/?ref_=fn_al_tt_1) [1:15]
- [Hell on Earth: The Fall of Syria and the Rise of ISIS](https://www.imdb.com/title/tt6794398/?ref_=fn_al_tt_1) [1:15]

**Nonfiction masterpiece**: [In Cold Blood](https://www.amazon.com/Blood-Modern-Library-Nonfiction-Books/dp/0812994388/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1639412220&sr=8-1) by Truman Capote (2013) | [23:15]

**Peter asks about this book**: [One Bullet Away: The Making of a Marine Officer](https://www.amazon.com/One-Bullet-Away-Making-Officer/dp/0618556133/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1639424994&sr=8-1) by Nathaniel Fick (2005) [42:00]

**Article about the Ferber Method and co-sleeping**: [Sleeping with the baby](https://www.newyorker.com/magazine/1999/11/08/sleeping-with-the-baby) | *The New Yorker* (November 8, 1999) | [1:42:30]

**Website that explains childhood development and parenting from an evolutionary viewpoint**: [Evolutionary Parenting](https://www.evolutionaryparenting.com) | Tracy Cassels PhD (December 2021) | [1:51:45]

**His article about the US withdrawal from Afghanistan**: “[A Vast Criminal Racket”: Sebastian Junger on How the US Corrupted Afghanistan](https://www.vanityfair.com/news/2021/08/a-vast-criminal-racket-sebastian-junger-on-how-the-us-corrupted-afghanistan) | by Sebastian Junger, *Vanity Fair* (August 31, 2021) | [2:24:15]

**Sebastian’s website**: [sebastianjunger.com](https://www.sebastianjunger.com/)

**Articles from** ***The NY Times*** **about Sebastian’s books**:

- Books of the Times: [The Shipwreck Story No One Survived to Tell](https://www.nytimes.com/1997/06/05/books/the-shipwreck-story-no-one-survived-to-tell.html?searchResultPosition=28) | By Christopher Lehmann-Haupt, *The New York Times* (June 5, 1997)
- Books: [The Tempest](https://www.nytimes.com/1997/06/22/books/the-tempest.html?searchResultPosition=39) | Anthony Bailey, *The New York Times* (June 22, 1997)
- [In The East Village with: Sebastian Junger; The Pose After the Prose](https://www.nytimes.com/1997/11/09/style/in-the-east-village-with-sebastian-junger-the-pose-after-the-prose.html) | Mike Wise, *The New York Times* (November 9, 1997)
- Business: [Talking Money with Sebastian Junger: From ‘The Perfect Storm,’ A Passage to Financial Freedom](https://www.nytimes.com/2000/12/03/business/talking-money-with-sebastian-junger-perfect-storm-passage-financial-freedom.html?searchResultPosition=9) | Geraldine Fabrikant, *The New York Times* (December 3, 2000)
- Books in Brief: Nonfiction: [Fire by Sebastian Junger](https://www.nytimes.com/2001/10/14/books/books-in-brief-nonfiction-499056.html?searchResultPosition=14) | Paula Friedman, *The New York Times* (October 14, 2001)
- Books of the Times: [From Fighting the taliban to battling Blazes in Idaho](https://www.nytimes.com/2001/10/17/books/books-of-the-times-from-fighting-the-taliban-to-battling-blazes-in-idaho.html?searchResultPosition=27) | Michiko Kakutani, *The New York Times* (October 17,, 2001)
- Books: [A Murder Victim’s Daughter Disputes Sebastian Junger Book](https://www.nytimes.com/2006/04/08/arts/a-murder-victims-daughter-disputes-sebastian-junger-book.html?searchResultPosition=7) | Motoko Rich, *The New York Times* (April 8, 2006)
- Arts: Review: [A Death in Belmont](https://www.nytimes.com/2006/04/14/arts/review-a-death-in-belmont.html?searchResultPosition=31) | Alan Dershowitz, *The New York Times* (April 14, 2006)
- Books: [The Belmont Strangler](https://www.nytimes.com/2006/04/16/books/review/the-belmont-strangler.html?searchResultPosition=21) | Alan Dershowitz, *The New York Times* (April 16, 2006)
- [‘Nothing to Do but Kill and Wait’](https://www.nytimes.com/2010/05/16/books/review/Filkins-t.html) | Dexter Filkins, *The New York Times* (May 14, 2010)
- Movie Review: [Haunted by Combat, Yet Missing the Brethren](https://www.nytimes.com/2014/05/30/movies/in-korengal-us-soldiers-recall-their-time-in-afghanistan.html?searchResultPosition=29) | Stephen Holden,  *The New York Times* (May 29, 2010)
- Movie Review: [Battle Company: Loving Life, Making War](https://www.nytimes.com/2010/06/25/movies/25restrepo.html?searchResultPosition=38) | A.O. Scott, *The New York Times* (June 25, 2010)
- Television Review: [Recalling a Chronicler of Combat as It Is](https://www.nytimes.com/2013/04/18/arts/television/jungers-film-which-way-is-the-front-line-from-here-on-hbo.html?searchResultPosition=22) | Mike Hale, *The New York Times* (April 17, 2013)
- Arts: [Sebastian Junger and the Complicated Obligations of Friendship](https://carpetbagger.blogs.nytimes.com/2014/01/15/sebastian-junger-and-the-complicated-obligations-of-friendship/?searchResultPosition=4) | Larry Rother, *The New York Times* (January 15, 2014)
- Arts: [Sebastian Junger on His Companion Film to ‘Restrepo’](https://artsbeat.blogs.nytimes.com/2014/05/29/sebastian-junger-on-his-companion-film-to-restrepo/?searchResultPosition=5) | Mike Hale, *The New York Times* (May 29, 2014)
- Television: [Depicting a Man’s world with One Key Absence](https://www.nytimes.com/2014/11/10/arts/in-the-last-patrol-sebastian-junger-zeroes-in-on-manhood.html?searchResultPosition=17) | Mike Hale, *The New York Times* (November 9, 2014)
- By the Book: [Sebastian Junger: By the Book](https://www.nytimes.com/2016/05/15/books/review/sebastian-junger-by-the-book.html) | *The New York Times* (May 12, 2016)
- Review: [Sebastian Junger’s ‘Tribe’ Examines Disbanded Brothers Returning to a Divided Country](https://www.nytimes.com/2016/05/19/books/review-sebastian-jungers-tribe-examines-disbanded-brothers-returning-to-a-divided-country.html) | Jennifer Senior, *The New York Times* (May 18, 2016)
- Book Review: [Sebastian Junger’s ‘Tribe’](https://www.nytimes.com/2016/05/29/books/review/sebastian-jungers-tribe.html) | Matthew Crawfore, *The New York Times* (May 27, 2016)
- Letters from America: [Did Americans Lose Something on the Path to Modernity?](https://www.nytimes.com/2016/06/07/us/tribe-belonging-sacrifice-sebastian-junger.html) | Anand Giridharadas, *The New York Times* (June 6, 2016)
- Review: [In ‘Hell on Earth,’ Horrors From the Syrian War](https://www.nytimes.com/2017/05/18/movies/hell-on-earth-review-syrian-war-isis.html?searchResultPosition=19) | Glenn Kenny, *The New York Times* (May 18, 2017)
- Book Review: [Nonfiction: What does freedom really mean?](https://www.nytimes.com/2021/05/17/books/review/sebastian-junger-freedom.html) | William Finnegan, *The New York Times* (May 17, 2021)

**Sebastian Junger’s TED Talks**

- [Why Veterans Miss War](https://www.ted.com/talks/sebastian_junger_why_veterans_miss_war?language=en) | Sebastian Junger TEDSalon NY 2014 (January 2014)
- [Our Lonely Society Makes It Hard to Come Home From War](https://www.ted.com/talks/sebastian_junger_our_lonely_society_makes_it_hard_to_come_home_from_war?language=en) | sebastian Junger TED Talks Live (November 2015)

§

## People Mentioned

- [Peter Matthiessen](https://en.wikipedia.org/wiki/Peter_Matthiessen) (A good writer Sebastian read as a young man) [13:30]
- [Joan Didion](https://en.wikipedia.org/wiki/Joan_Didion) (A good writer Sebastian read as a young man) [13:30]
- [Ernest Hemingway](https://en.wikipedia.org/wiki/Ernest_Hemingway) (A good writer Sebastian read as a young man) [13:30]

- [Truman Capote](https://en.wikipedia.org/wiki/Truman_Capote) (author of *In Cold Blood*) [23:15]
- [Ahmed Shah Massoud](https://en.wikipedia.org/wiki/Ahmad_Shah_Massoud) (Afghanistan guerrilla fighter) [32:30]
- [Fahim Dashti](https://en.wikipedia.org/wiki/Mohammad_Fahim_Dashty) (a translator with Massoud when he was killed) [34:15]
- [Nathanial Fick](https://en.wikipedia.org/wiki/Nathaniel_Fick) (author of *One Bullet Away*) [42:00]
- [Tim Hetherington](https://en.wikipedia.org/wiki/Tim_Hetherington) (made the documentary *Restrepo* with Sebastian) [51:45]
- [Dr. Ferber](https://en.wikipedia.org/wiki/Ferber_method) (author of a book on children’s sleep) [1:42:15]
- [Donald Trump](https://en.wikipedia.org/wiki/Donald_Trump) (former US President) [2:20:45]
- [John Kerry](https://en.wikipedia.org/wiki/John_Kerry) (US politician and former Secretary of State) [2:26:15]
- [Najibullah](https://en.wikipedia.org/wiki/Mohammad_Najibullah) (former president of Afghanistan) [2:26:45]
- [George Washington](https://en.wikipedia.org/wiki/George_Washington) (founding father and first president of the US) [2:38:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/02/bio-junger.jpeg)

##### Sebastian Junger

Sebastian Junger is the #1 *New York Times* Bestselling author of *The Perfect Storm, Fire, A Death in Belmont, War, Tribe,* and *Freedom.*  As an award-winning journalist, a contributing editor to *Vanity Fair* and a special correspondent at *ABC News*, he has covered major international news stories around the world, and has received both a National Magazine Award and a Peabody Award. Junger is also a documentary filmmaker whose debut film *Restrepo*, a feature-length documentary (co-directed with Tim Hetherington), was nominated for an Academy Award and won the Grand Jury Prize at Sundance.

*Restrepo*, which chronicled the deployment of a platoon of U.S. soldiers in Afghanistan’s Korengal Valley, is widely considered to have broken new ground in war reporting.  Junger has since produced and directed three additional documentaries about war and its aftermath. *Which Way Is The Front Line From Here?*, which premiered on HBO, chronicles the life and career of his friend and colleague, photojournalist Tim Hetherington, who was killed while covering the civil war in Libya in 2011.  *Korengal* returns to the subject of combat and tries to answer the eternal question of why young men miss war.   *The Last Patrol*, which also premiered on HBO, examines the complexities of returning from war by following Junger and three friends–all of whom had experienced combat, either as soldiers or reporters–as they travel up the East Coast railroad lines on foot as “high-speed vagrants.”

Sebastian Junger is the founder and director of Vets Town Hall.

Junger has also written for magazines including *Harper’s*, *The New York Times Magazine*, *National Geographic Adventure*, *Outside* and *Men’s Journal*. His reporting on Afghanistan in 2000, profiling Northern Alliance leader Ahmed Shah Massoud, who was assassinated just days before 9/11, became the subject of the National Geographic documentary *Into the Forbidden Zone*, and introduced America to the Afghan resistance fighting the Taliban.

He lives in New York City and Cape Cod. [[sebastianjunger.com](https://www.sebastianjunger.com/about)]