# #233 – AMA #42: Optimizing sleep – bedtime routine, molecule regimen, sleep trackers, sauna, & more

**Source:** [https://peterattiamd.com/ama42/](https://peterattiamd.com/ama42/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a number of questions on optimizing sleep. He describes his pre-bedtime routine, how he utilizes a sauna, and his current regimen of medicines and supplements for improving sleep time and quality. He goes in depth on each of the molecules that have shown promise in boosting sleep, including their mechanisms of action as well as any noteworthy contraindications. Peter also discusses sleep wearables, including both the positives and potential negatives of using such trackers, and much more.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #42 show notes page](https://peterattiamd.com/ama42/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Peter’s current pre-bedtime routine [3:30];
- Sauna: Peter’s routine, sleep benefits, and tradeoffs [10:45];
- Importance of keeping an open mind as new information arrives [16:15];
- Importance of reducing stimulation leading up to bedtime [19:30];
- Medications that can enhance sleep: mechanisms of action, contraindications, risks, and Peter’s regimen [20:30];
- Why medications can enhance sleep, but should not replace good sleep habits [34:45];
- Sleep supplements: mechanisms of action, contraindications, and Peter’s regimen [37:30];
- Temperature during sleep, cooling devices, mattresses, and more [53:00];
- A tip to help avoid straining your back in the morning [59:15];
- Contrasting polysomnography with wearable sleep trackers [1:00:45];
- Sleep tracking wearables: interpreting metrics, and the pros and cons of trackers [1:04:30];
- Final takeaways on sleep [1:16:30]; and
- More.

§

The Peter Attia Drive

Optimizing sleep - bedtime routine, molecule regimen, sleep trackers, sauna, & more

§

## Show Notes

§

## Peter’s current pre-bedtime routine [3:30]

⇒ Peter recently [shared](https://www.instagram.com/p/Cif5R9KuXzk/) a bit about his bedtime routine on instagram

***What does Peter’s current pre-bedtime routine consist of?***

- The following is the result of many years of tinkering
- And a lot of these insights are not necessarily new, but it’s just a question of being diligent around putting them in place

**1 – Alcohol**

- It’s very difficult to have a good night’s sleep if you have alcohol in the proximity of bedtime, or even if you have two or three drinks several hours removed from bedtime
- The negative effects manifest itself in a number of ways, but probably most notably is the reduction in the **quality of sleep**
- You’ll trade more deep sleep and REM sleep for light sleep
- And there will be much more frequent wake ups

**2 – Eating too close to bed**

- Peter discovered when fasting the profound positive impact of the low glucose/empty stomach on sleep
- He was amazed how, when fasting, his sleep quality improved in ways that he’s never seen before
- Peter generally eats dinner early in the evening
- And he will notice that when he goes to bed, he’s a little bit hungry (in the past he would have a snack but not he doesn’t)
- Peter strives for about three hours between his last meal and when he goes to bed

**3 – Sauna**

- About 7 years ago, when doing a deep dive into sauna literature, he came to the conclusion that there was really no benefit to sauna that wasn’t captured in a [healthy user bias](https://peterattiamd.com/ns003/)
- By this he means that all of the epidemiologic benefits associated with sauna (such as an enormous reduction in cardiovascular mortality and mortality associated with dementia) seemed to be mostly a healthy user bias
- But in late 2019/early 2020 he [revisited the literature](https://peterattiamd.com/ama16/) and changed his tune a little bit
- He still thinks that maybe the *magnitudes* of the benefits associated with sauna are being amplified by these biases that can’t be controlled for, but the direction of them & the consistency of them across studies led him to believe there’s probably something there in addition to the plausibility of the mechanisms
- Today, Peter personally does sauna 4-6 nights per week before bed basically for two purposes
  - 1 – He believes there is at least SOME mortality benefit that comes from it
  - 2 – Improving sleep – “empirically the impact this has had on my sleep is insane”
  - Peter has often wondered if the mortality benefit of sauna is largely attributed to the sleep benefits that come from its use

**\*Important note of clarification about the 3 principles listed above**:

- These are general principles that are going to get violated quite often, but you want to kind of revert back to them whenever you can
- With sleep in particular, there’s such a psychological component to this that you just don’t want to get too wrapped up in your head about this sort of stuff because that can cause more harm than good
- Interpret what he’s saying as guidelines that we try to stick to, but we have the flexibility to deviate
- (see [AMA #41](https://peterattiamd.com/ama41/) for tips on prioritizing healthy habits while navigating the stresses of life)

⇒ For more on the topic of sleep, be sure to check out the 7 episodes with sleep scientist, Matt Walker: All episodes are listed on the [show notes page for episode #47](https://peterattiamd.com/matthewwalker1/)

## Sauna: Peter’s routine, sleep benefits, and tradeoffs [10:45]

***What’s your current view on sauna use in terms of risk reward?***

- It depends on the individual, say Peter
- There are probably some people who would need to consult with their doctors before getting into a sauna
  - It is very hot inside a sauna (Peter keeps his at 198 degrees Fahrenheit)
  - Peter’s typical routine is 15 minutes and then a cold plunge and then 20 to 25 minutes
  - By the end of that second stint in the sauna, Peter is quite taxed and there’s a subset of the population for whom that might be a little too taxing
- Outside of that, the biggest risk of sauna is probably having accidents in saunas like falling

**Opportunity cost**

- But like anything else, it comes at an opportunity cost
- For instance, Peter’s routine takes him about 1 hour
- The question becomes, is there something better you can be doing in that hour for your physical or mental health?
- For some people that opportunity cost might be too high
- Maybe it’s taking them away from an hour of sleep that they otherwise need
- Each person needs to figure out what they’re giving up for that amount of time
- **Financial cost –** These saunas are expensive to put in your home, so there’s a financial cost there

**These risks/costs need to be weighed against the “benefits”**

- Some benefits are “soft” such as maybe it’s an opportunity time to spend with your spouse (Peter and his wife do the sauna together)
- Improvement of sleep is a tangible way to assess benefit if you fall in the camp of people who sleep is improved by that
- As far as the hard numbers around the reduction in mortality, Peter says…
- “I’d be hard pressed to believe that they are as strong as they are demonstrated in the finished data sets. . .But if they’re half that, they’re still pretty good”
- Note that Peter wouldn’t rate sauna nearly as valuable as exercise  – “*An hour of exercise is better for you than an hour of sauna if you’re really playing the game of inches*”

**Peter’s view on dry sauna and infrared sauna**

- Peter says it’s unclear if infrared and dry have the same benefits
- It’s a very different mechanism
- And they produce a very different feeling if you’re in them
- The literature is mostly on dry saunas
- The infrared devices relatively inexpensive, relatively small, such that if you live in a tiny apartment, you could still have one
- Peter says he still thinks there is a benefit to infrared but it’s going to be much more difficult to quantify by attribution to the literature

*Warm bath/shower*

- For those people who don’t have access, can’t get access, even a warm bath or even a hot shower can still have some of those sleep benefits that it’s worth people testing before they go to bed
- “*The broader theme around sleep is you have to try things several times and realize if they work for you or not*.”

⇒ For info on sauna as a longevity tool, see [AMA #16: Exploring hot and cold therapy](https://peterattiamd.com/ama16/)

## Importance of keeping an open mind as new information arrives [16:15]

***Any advice you would have for people who are maybe a little more rigid and not open to that change in their opinions or their ideals?***

- It comes down to what you anchor to: *Do you anchor to being right or do you anchor to knowing the truth?*
- If you can be more in the camp of the latter, it’s easier for you to accept change
- If you anchor to being right, you can sometimes get the right answer, but if that answer changes, it becomes difficult to change
- Part of it is also understanding the nature of science and the scientific process: Even the best experiments don’t produce certainty, they just increase the **probability** of one idea being more likely than another

**Science isn’t black and white**

- There really isn’t much that’s black and white in science — most things are shades of gray
- Some things are really, really dark shades of gray
  - E.g., it’s really clear that we code from DNA to RNA to protein. It’s called the central dogma.
- But turns out there are a couple of little exceptions with viruses that go the other way around

> “On the edges [of science] there’s always going to be exceptions, potentially, for things that are even sort of ‘ironclad’.” —Peter Attia

- If there was a little bit just more acceptance of how uncertain things are and operating in a world of probabilities, it would just be a lot easier for people to kind of navigate the changes that are coming
- Peter says he doesn’t find, at the level of interacting with patients, that this poses a problem.
  - He can’t think of many examples where a patient was frustrated or disappointed that we were changing our point of view on something in the face of new information.

⇒ For more on changing opinions, check out these 2 “strong convictions, loosely held” episodes:

- [Episode #103](https://peterattiamd.com/strong-convictions-loosely-held/)
- [Episode #202](https://peterattiamd.com/strong-convictions-loosely-held-2/)

⇒ Also see [AMA #40](https://peterattiamd.com/ama40/) where Peter discusses how his opinion on fasting and time-restricted feeding has evolved

⇒ Here is [AMA #41](https://peterattiamd.com/ama41/) where Peter talked about how the biology of aging is quite complex and there’s always going to be changes

## Importance of reducing stimulation leading up to bedtime [19:30]

- Anothing thing Peter focuses on is trying to be as unstimulated as possible before bed
- For instance, he will floss and brush his teeth even before doing the sauna so that once he’s done with that sauna he goes straight to bed
- He even goes as far as not going into the bathroom and turning the lights on
- And he’s certainly not looking at his computer or phone
- That’s probably another part of why this sauna is beneficial for Peter’s sleep — it could simply be that it’s a forced hour of bringing himself down as opposed to working right up until the last minute, brushing teeth, flossing teeth jumping in bed

## Medications that can enhance sleep: mechanisms of action, contraindications, risks, and Peter’s regimen [20:30]

**\*Important Caveat\***

- Peter doesn’t want people to immediately go and replicate his sleep molecule routine. Peter has access to sleep physicians ([Dr. Vikas Jain](https://www.sleepcareonline.com/meet-our-physicians/), [Matt Walker, Ph.D.](https://psychology.berkeley.edu/people/matthew-p-walker), etc.) who he speaks with frequently
- He has the luxury of doing polysomnography and being able to actually test the effects of different molecules on sleep on himself
- And just because a regimen works for Peter doesn’t mean it’s going to work for another person
- Furthermore, two of the five things he takes before bed are pharmaceutical so you would need a prescription for them
- And anyone taking these has to make sure they’re not taking other medications that these interact with them
- **Please note:** Pregabalin is a Schedule V controlled substance due to its potential for respiratory depression. You should not combine Pregabalin with any other medications that can cause respiratory depression (such as benzodiazepines or opiates) and you should not drink alcohol while taking this medication.

**Peter’s current molecule regimen**:

Peter takes 2 pharmaceutical agents and 3 supplements roughly *8.5 hours before he plans to wake up*

- Pharmaceutical agents/medications:
  - 100 milligrams of a drug called [Pregabalin](https://www.webmd.com/drugs/2/drug-93954-1903/pregabalin-oral/pregabalin-extended-release-oral/details)
  - 50 milligrams of a drug called [Trazodone](https://www.webmd.com/drugs/2/drug-11188/trazodone-oral/details)
- Supplements (discussed further in the next section):
  - 2 grams of a supplement called [glycine](https://www.webmd.com/vitamins-and-supplements/glycine-uses-and-risks)
  - 600 milligrams of a supplement called [ashwagandha](https://www.webmd.com/vitamins/ai/ingredientmono-953/ashwagandha)
  - Two capsules, roughly 2 grams, of something called [Magtein](https://magtein.com/?gclid=CjwKCAjwkJj6BRA-EiwA0ZVPVrn13zzzNne52olR9-Jo5ARcCM16YJjaHdmij2jiTFvQVOVTlQ71mxoCgI0QAvD_BwE) or magnesium L-threonate

**More about the pharmaceutical agents/medications mentioned above**:

*Pregabalin*

- This is a drug that used for neuropathic pain and was originally an anti-seizure medication
- These are drugs that tend to have a pretty high LD50, meaning these are drugs that have a broad spectrum of safety
- Mechanism of action – an anxiolytic and it’s a presynaptic inhibitor of excitatory neurotransmitters (that’s where that first indication from a seizure place came from is sort of in anti-seizure medication)
- In [rodent studies](https://jpet.aspetjournals.org/content/299/3/1095), it really increased the duration of non REM deep sleep and came at the expense of some REM sleep
- When Peter has done polysomnography (and even just looking at his sleep trackers), his default is very high REM and not so high non REM deep
  - Peter sees a similar trend in his patients — Most people tend to be long one short another
- Peter’s default sleep stats:
  - Typically he at least 2 hours (sometimes 3 hrs) of REM sleep REM
  - But non REM deep sleep, his default is less than an hour
  - Based on these default number, he became interested in pregabalin
- There’s a small double blind [three-way crossover study](https://academic.oup.com/sleep/article/28/2/187/2696902?login=false) that was done in humans
  - ~24 subjects, using polysomnography
  - It was comparing placebo with Pregabalin
  - It found a significant increase in the proportion of slow wave sleep (deep sleep)
  - This was the reason that he wanted to add it to his regimen

*Trazodone*

- Peter’s been using Trazodone for three years, but the most recent edition of Pregabalin is when he reduced his dose of Trazodone from 100mg to 50mg
  - A [review paper](https://pubmed.ncbi.nlm.nih.gov/24119681/) looked at pregabalin’s effect on sleep across clinical conditions indicated that pregabalin seems to increase total sleep time and decrease wake time (increasing sleep efficiency)
  - A [2022 meta-analysis](https://www.nature.com/articles/s41598-022-18776-7#Sec22) of trazodone studies showed that total sleep time is increased with trazodone

![](https://peterattiamd.com/wp-content/uploads/2022/12/f1.-ama42-1024x260.png)

**Figure 1.** From the [2022 meta-analysis](https://www.nature.com/articles/s41598-022-18776-7#Sec22) of trazodone studies. Total sleep time is increased with trazodone.

- Another default sleep pattern Peter has noticed in himself is that he has many wake ups that he perceived as well as wake ups that he doesn’t necessarily perceive
- The Trazodone really eliminated the frequent wake ups that he perceived (but non perceived wake up still happen)

***Who’s the right person to try these drugs?***

- Probably that person who has REM to spare but needs more non REM deep
- That said, Peter doesn’t even really feel like he’s noticed his REM sleep has decreased that much (he’s still always over 90 minutes)
- So, for Peter personally, it appears that the increase in non REM deep sleep has come out of light sleep
- In other words, it’s been an overall improvement in sleep quality without a reduction of anything including, without a reduction of REM

**Side effects/contraindications for Pregabalin and Trazodone**

*Considerations related to Pregabalin*

- Pregabalin has NOT cleared safety in pregnancy and breastfeeding women
- If your kidney function is not normal, either have it dose changed or avoid completely
- As with the case of any drug, there are some people that have a sensitivity to a drug class. If you have a sensitivity to this or to a cousin of this drug, there’s a drug that is called gabapentin or Neurontin, also kind of a neuropathic pain drug
  - If you have sensitivity to one of those things, you might need to worry about that here
- Finally there’s kind of a rare condition called [angioedema](https://www.nhs.uk/conditions/angioedema/#:~:text=Angioedema%20is%20swelling%20underneath%20the,threatening%20if%20it%20affects%20breathing.). If you have that, you’d need to be cautious with this and probably avoid it

*Considerations related to Trazodone*

- It made its way into the U.S. in the early 80s an antidepressant
- It’s mechanism of action
  - Inhibits both serotonin transporters and serotonin type 2 receptors (it’s a serotonin antagonist and reuptake inhibitor)
    - It also behaves as an antagonist at the serotonin type 2 (5-HT2) receptors, an antagonist at the histamine H1 and alpha1 (α1) adrenergic receptors, and as an inhibitor of serotonin reuptake transporter (SERT).
  - While it’s not as “neat and clean” as the current batch of antidepressants, the SSRIs or even the SNRIs, that’s really what its first indication was
- So Trazodone again came in the market 40 plus years ago and its use case was as an antidepressant.
  - And it was typically dosed in the neighborhood of 150 milligrams twice a day, so roughly 250 to 300 milligrams per day
  - It never really caught on as an antidepressant because the biggest side effect of the drug was drowsiness
  - At those doses it really made people tired and that combined with the development of more targeted drugs kind of left Trazodone out there

*More on trazodone*:

- [Paul Conti](https://www.drpaulconti.com/) (previous podcast guest [#15](https://peterattiamd.com/paulconti/), [#105](https://peterattiamd.com/paulconti2/), [#190](https://peterattiamd.com/paulconti3/)) introduced this drug to Peter
- Peter and Paul had success when prescribing it to patients with bad rumination that resulted in the individual waking up in the middle of the night and unable to go back to sleep
- Some of the things you always want to be looking at when you look at studies for sleep drugs (including drugs like Trazodone that were not designed for sleep, AND drugs that are designed for sleep like Ambien, OR even the newest class which are the orexin antagonists) is:
  - Does it increase or decrease total sleep time?
  - What’s the effect on latency wake ups?
  - And then staging – What happened to specifically REM and non REM deep?
- By these metrics, Trazodone is a very effective drug
  - Increases total sleep time
  - Generally increases non REM stage 2
  - It can also come a little bit at the expense of REM, but “I don’t think it’s as significant as Pregabalin”

*Dosing trazodone*:

- The **main issue with Trazodone is if you overshoot the dose**, you can be quite drowsy in the morning and even have postural hypertension, meaning when you stand up first thing in the morning you can be a little bit lightheaded.
- The ideal dose for sleeping can be as little as 12.5 milligrams and as high as 150 milligrams
- 150 mg is still about half the dose that people were taking when they were using it as an antidepressant
- Peter will typically tell people to start at 25 mg
- Peter was taking 100mg of trazodone before he added the 100 mg of Pregabalin
- But when on 100 mg of both he found it took him 30 minutes in the morning to sort of wake up which is not ideal
- He then settled on 50 mg of trazodone when combining with 100 mg of Pregabalin

*No dependency with trazodone or pregabalin:*

- The beauty of both of these, unlike the Ambiens and Lunestas of the world or the benzos, is there is **no dependency**
- So if you don’t have these, you’ll probably notice it in that your sleep is not as good, but you don’t have any sort of chemical withdrawal from them the way you do with benzos

**Quick note on benzodiazepines**:

- Peter is not a fan of using benzodiazepines in patients at all for insomnia outside of the most extreme circumstances
- A recent example: A person lost her spouse suddenly
- Clearly that’s an indication for low-dose of benzodiazepines to help with the unbelievable anxiety associated with a situation like that
- But again, that has to be monitored very carefully

*Back to trazodone*:

- There’s a non-trivial subset of people in my experience, 10%-15%, for whom we just can’t find a good dose
- It either doesn’t do anything, seems like it’s too low a dose or it just absolutely hammers them to the point where they are dysfunctional for the first hour in the morning when they wake up.

*Contraindications as it relates to trazodone*:

- Patients with [Long QT syndrome](https://www.mayoclinic.org/diseases-conditions/long-qt-syndrome/symptoms-causes/syc-20352518#:~:text=Overview,(congenital%20long%20QT%20syndrome).) or other cardiac disease,
- Patients with bipolar disorder
- Patients receiving MAOI therapy (a certain class of antidepressants)
- Patients with hyponatremia (low sodium)
- “*You have to be under the guidance of someone who knows you and your medical history and also knows what other medications you may or may not be taking so that they can make sure there’s no contraindications through that*.”

⇒ Find the seven episode with Matt Walker on the [show notes page for episode #47](https://peterattiamd.com/matthewwalker1/)

## Why medications can enhance sleep, but should not replace good sleep habits [34:45]

**Peter’s thoughts for people who may not like the idea of using drugs/supplements for sleep**:

“*There are a lot of people who have big hiccups on this and they say, ‘Oh my god, that’s horrible. Why would you take a drug to sleep?’” And I would say if you feel that way, don’t. I don’t think it’s necessary. I mean, I sleep pretty well without those things. I just sleep a lot better with them. I don’t know why, but for some reason, and it’s understandable, I suspect people sort of think this is unnatural. We shouldn’t have to take anything to sleep. But I would argue we don’t necessarily live in a natural world anymore anyway. So I’m kind of looking for any advantage I can get*.”

**Why one should not use drugs to replace good sleep habits**:

- So someone who says, “*I’m going to use these drugs but I’m going to short change sleep*” is in for a painful surprise
- Once you’re taking these, you’re committing to eight hours of sleep
- If you’re going to only sleep 5 hours and you take these, you’re hosed because you’re going to be so drowsy the next day
- Don’t look at these as hacks that you can use to shortchange all of the other stuff that we talk about with respect to hygiene and timing
- These are truly accretive things that get added on and improve quality

## Sleep supplements: mechanisms of action, contraindications, and Peter’s regimen [37:30]

**Supplements Peter takes regularly**:

- Glycine (2 grams)
- Ashwagandha (600 milligrams)
- [Magtein](https://magtein.com/?gclid=CjwKCAjwkJj6BRA-EiwA0ZVPVrn13zzzNne52olR9-Jo5ARcCM16YJjaHdmij2jiTFvQVOVTlQ71mxoCgI0QAvD_BwE) or magnesium L-threonate (Two capsules, roughly 2 grams)

*Supplements Peter takes sparingly (e.g., for jet lag)*:

- Phosphatidylserine
- Melatonin
- See more about Peter’s jet lag protocol in [AMA #4](https://peterattiamd.com/ama04/)

*And Peter’s has personally tinkered with many different supplements*:

- He’s tried lithium (low does of 10-20 mg)
- Peter used to take something called [Phenibut](https://www.webmd.com/vitamins/ai/ingredientmono-1184/phenibut) (a form of GABA given orally that crossed the blood brain barrier)
  - Phenibut was his favorite sleep supplement up until three years ago when the FDA banned it — “This was a mistake in my opinion, an overreaction.”
  - After it was banned, he started looking for other ways to get GABA that can make it into the CNS, but taking straight up GABA does not seem to do it
  - This search is what led Peter to **glycine**

**Glycine (Peter takes 2 g)**:

*Mechanism*:

- Glycine is an inhibitory neurotransmitter in the brainstem and spinal cord. In these areas, glycine inhibits motor activity during rapid eye movement (REM) sleep.
  - Glutamate is the neurotransmitter that excites motor activity during REM
  - Endogenous glycine modulates sensitivity to glutamate and exogenous glycine may augment this modulatory action.
  - In taking glycine, the hope is that it’s calming the central nervous system

*Data*:

- There’s some decent [animal data](https://www.nature.com/articles/npp2014326), but a [polysomnographic study](https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1479-8425.2007.00262.x?crsi=662496636&cicada_org_src=healthwebmagazine.com&cicada_org_mdm=direct) in humans is more interesting
- The [human study](https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1479-8425.2007.00262.x?crsi=662496636&cicada_org_src=healthwebmagazine.com&cicada_org_mdm=direct) used 3g of glycine and found three things that happened:
  - 1 – It shortened latency (fall asleep quicker)
  - 2 – Reduced the latency to slow wave sleep
    - Important because you have a very discreet window in which you’re going to get your slow wave sleep. It occurs early in the evening, early in your sleep
    - So the later you go to bed, the more you’re short changing your deep sleep, your slow wave non REM, and therefore anything that reduces latency to that presumably gives you access to more of it.
  - 3 – It had no alteration of sleep architecture anywhere else

*Contraindications*:

- Patients who are taking [clozapine](https://www.webmd.com/drugs/2/drug-5200/clozapine-oral/details) shouldn’t be taking glycine

**Phosphatidylserine as part of Peter’s jet lag protocol**

- [Phosphatidylserine](https://www.webmd.com/vitamins-and-supplements/phosphatidylserine-uses-and-risks) is an “incredibly potent” [supplement](https://jarrow.com/products/ps-100-100-mg-softgels) is part of Peter’s jet lag protocol that he doesn’t use it regularly
  - It’s mechanisms of action are not entirely clear, but it seems to suppress cortisol release (an adrenal inhibitor)
- When traveling and Peter needs to put himself into the destination time zone (one that’s far ahead) he’ll add this to his routine
- For example, you take off and it’s 2:00 PM but in your destination it’s 10:00 PM
  - The strategy is to go to sleep and act as though it’s 10:00 PM
  - It’s hard sometimes to force yourself to go to sleep at 2:00 PM because there are three variables that are driving sleep primarily: 1) melatonin, 2) cortisol, and 3) adenosine.
  - H*ow to increase adenosine*?
    - No coffee that day
    - Lots of exercise that day very early in the morning
  - H*ow to increase melatonin*?
    - Melatonin is NOT part of Peter’s normal nighttime routine
    - But in the situation for jet lag, he will “slam” himself with 2-5 mg of melatonin
  - Then, *how does he shut down his adrenal glands (cortisol)*?
    - The answer is 400-600 milligrams of phosphatidylserine
    - On a day to day basis, “phosphatidylserine is a bit overkill and I don’t think it’s really efficacious at the 100-200 milligram dose”

**Ashwagandha (Peter takes 600 mg)**:

*Mechanism*

- Ashwagandha is a milder version of phosphatidylserine
- It reduces activation of the hypothalamic pituitary adrenal access and the cortisol release
- An active ingredient of Ashwagandha leaves, triethylene glycol, can induce sleep [in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5313221/) through reducing the NREM sleep onset latency period

*Data*:

- The RCTs in human are “not overwhelmingly robust” says Peter
- Human studies with ashwagandha include:
  - An [RCT](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6827862/) (n = 58), found that 300 mg of ashwagandha 2x per day for 10 weeks shortened sleep onset latency, improved sleep efficiency and sleep quality
  - An [RCT](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6979308/) (n = 58) that used either 250 or 600 mg daily ashwagandha for its anxiolytic effects found that both doses reduced serum cortisol and improved subjective sleep quality based on a 7-point sleep scale.
- While Peter says this data isn’t that robust, he has found objective and subjective benefits when he takes it

Contraindications:

- During pregnancy and breast-feeding, in patients pre-surgery, in patients with stomach ulcers, autoimmune conditions, in patients on medication to manage diabetes, high blood pressure, or thyroid disorders

**Melatonin**

- Melatonin is probably the single most common sleep supplement out there
- But Peter doesn’t use it regularly… *why?*
- **How melatonin works**: The pineal gland releases melatonin in the dark and melatonin therefore is a signal to the body that it is time to sleep
- The increase of melatonin is a very important signal for our body to go to sleep
- When we think about how much physiologic melatonin is secreted by the pineal gland, it’s a very small amount (20-100 micrograms)
- But when people take melatonin over the counter, it’s very hard to find a dose less than 1 milligram, which is 1,000 micrograms.
- But when you look at certain data, it would suggest that anything over 700 or 800 micrograms orally, tends to impact melatonin receptors in the brain by down regulating them
- In other words, when you put so much of the molecule into place, the brain gets sort of desensitized to it and you reduce the receptors
- Peter’s general rule of thumb: If you must take melatonin frequently, which he would NOT encourage, it should be a very low dose (100-200 micrograms)
- Instead you want to work on ways to naturally create melatonin through light removal in the hours leading up to bed

> “And look, melatonin is an antioxidant, it’s a healthy molecule. So I don’t want to sound like I’m sort of dismissive of it, but I don’t view it as a great strategy for your day in day out approach. At least at a dose that is typically acquired.” —Peter Attia

**Magnesium L-threonate**

- Peter first heard about magnesium L-threonate about eight years ago when got interested in it more around the “tantalizing data” with respect to neurodegenerative disease

Taking a step back…

- Magnesium L-threonate is a type of magnesium that can cross the blood brain barrier
- When you take magnesium, it’s doing a bunch of great things in your body, but it’s generally not getting across the blood-brain barrier (so not getting into your brain)
- So the L-threonate is the transporter to the brain
- Approximately 8 years ago, Peter came across some interesting data
  - It’s quite dated so it could be completely incorrect today, but the data were suggesting that, in patients with early MCI (mild cognitive impairment), high doses of magnesium L-threonate were improving symptoms
  - The idea being that magnesium plays an important role in ion channel conductivity, including MDMA receptors, and something about getting more magnesium in the brain was improving neuronal health.

Regarding its impact on sleep, [Matthew Walker has mentioned](https://peterattiamd.com/matthewwalkerama3/) that there is some evidence that:

- Magnesium supplement for sleep likely came from studies in the 80’s and 90’s that found:
- about 60% of subjects who were Mg deficient (400 of 1300 total subjects) had insomnia (higher than the population avg of 15-30%)
  - High circulating levels of Mg in infants is associated with higher levels of quiet sleep (precursor to NREM)
- Those data make it somewhat of a “leap of faith” that supplementing with magnesium will improve sleep

> “Of all the things that are on my list, I would say [magnesium L-threonate] is the one for which I feel the least compelled. Part of my taking it is rooted in somewhat of a belief I have that this is possibly just more of a brain health supplement than an actual sleep supplement.” —Peter Attia

**\*Important note about the individualized nature of sleep supplements/drugs**:

- “*I hope that someone listening to this is also realizing that this stuff’s highly individualized*”
- “*I don’t think we have one single patient in the practice who is taking exactly this combination of meds for sleep*”
- “*Some are doing it with a subset of these. Some are doing it with a subset of these and other things that I don’t take*”
- “*It’s one of those things you have to really tinker with until you kind of find what works for you.*”

## Temperature during sleep, cooling devices, mattresses, and more [53:00]

**Cooling devices/mattresses**:

- Peter used to use a device called the [ChiliPad](https://sleep.me/?offer_id=2&affiliate_id=1495&transaction_id=102a8bf598dbe8b49fa4cacd55fab9&utm_source=TUNE&utm_medium=affiliate) (see [member-only discount page](https://peterattiamd.com/members/discounts/))
- Peter currently uses something called the [Eight Sleep](https://www.eightsleep.com/?utm_source=google&utm_medium=cpc&utm_campaign=18927845903&nbt=nb%3Aadwords%3Ag%3A18927845903%3A146513574474%3A635068208774&nb_adtype=&nb_kwd=eight%20sleep&nb_ti=kwd-149395865568&nb_mi=&nb_pc=&nb_pi=&nb_ppi=&nb_placement=&nb_si=%7Bsourceid%7D&nb_li_ms=&nb_lp_ms=&nb_fii=&nb_ap=&nb_mt=e&gclid=Cj0KCQiAvqGcBhCJARIsAFQ5ke5-NrvfUnDngmr5asq12-i6ZAXSV2VuPhRTVGngsHnf_Amvlsj3sK8aAmvLEALw_wcB)
  - They sell a mattress with a built-in cooling device
  - They also sell a mattress cover, which is what Peter has and he finds it to be an “unbelievable tool”

With Eight Sleep, you get the following:

- You can set the mattress to different temperatures throughout the night (as opposed to one temp all night long)
  - Peter has a certain level of cool when he gets in bed and he has it get cooler and cooler (down to about 60 degrees) before having the temperature rise starting at 4am or 5am preparing to wake up at 6am
- You can also set an alarm where the mattress starts to vibrate to wake you (better than loud alarm on phone)
- Additionally, it also tracks your sleep staging (to the best an algorithm could):
  - It does a remarkable job at measuring heart rate
  - It does a remarkable job at measuring movement
  - But it does an okay job at measuring heart rate variability
  - And those three variables, with a good enough algorithm, can get pretty close (75%-80%) to predicting sleep stages (similar to wearables like [Oura](https://ouraring.com/) and [Fitbit](https://www.fitbit.com/))

**What about weighted blankets?**

- [Gravity Blankets](https://gravityblankets.com/) are an example
- Peter only uses a weighted blanket in the winter time
- While the data on weighted blankets is sparse, anecdotally some people “*feel insanely better with a weighted sleep blanket*”

## A tip to help avoid straining your back in the morning [59:15]

- A lot of people can hurt their back first thing in the morning when they just sort of lurch forward because you’re not warmed up and that puts a lot of strain on your back
- Peter’s tip is to roll on your side towards the edge of the bed to where you’re in an “L shape”
- Drop your legs off the side of the bed which should sort of lift you up naturally (could use a slight push with your arm)
- basically get up sitting facing off the side of the bed.
- Peter has been using this technique since he [hurt his back](https://peterattiamd.com/martymakary/) many years ago

> “I’m amazed at how often a seemingly healthy person will just tweak their back getting out of bed too quickly or with a twist or a torque or doing something that’s otherwise kind of avoidable.” —Peter Attia

## Contrasting polysomnography with wearable sleep trackers [1:00:45]

**Polysomnography**

- A true polysom is “not pleasant” says Peter
- You have to undergo it for a couple of nights because first night or two the data are so unhelpful because you’re not sleeping well because of all the wires you’re tied up to
- Basically, the subject has leads on their chest that are measuring cardiac electricity
- Leads on their face that are measuring electricity, so they’re measuring the muscles of the eyes
- Then they have all sorts of EEG leads on their scalp (you’ve got all of this messy gooey stuff holding these leads to your head and therefore it’s measuring brain activity)

What the scientist or sleep doctor is doing at the end of the night is looking at:

- First and foremost your brainwaves
  - slow wave
  - fast wave
  - What’s the period of the wave?
  - What’s the amplitude of the wave?
- Then they’re also looking at it with movement
  - how much are you moving?
  - How much is your body moving?
  - how much are the muscles around your eyes moving?
  - that’s how you can deduce non REM versus REM from the eye movement
- Then their looking for:
  - stage one, stage two (light)  versus stage three, stage four (deep) where you’re looking at alpha waves, theta waves, delta waves and all those things
- To be clear, this is still somewhat a subjective process because ultimately the person has to make a cutoff – there’s no “biomarker” than says exactly when, for instance, theta wave stopped and this is where the delta wave began
- 10 sleep scientists could look at the exact same polysomnography data and they’re not all going to stage it identically (going to be 80% to 85% agreement, but it’s not going to be 100%)

**Sleep trackers, by contrast**:

- Sleep trackers don’t directly measure sleep the way the polysomnography is attempting to — i.e., they’re not looking at brainwaves
- There are some out there by the way, some headbands, that are trying to look at brainwaves but it’s TBD as to whether or not those things are going to be better than the wearables like [Whoop](https://www.whoop.com/) and [Oura](https://ouraring.com/)
- That said, Peter is generally just excited about this field and the idea that these things are getting better and better

The three main variables that get measured by sleep trackers are:

- i) Movement, ii) heart rate and iii) heart rate variability
- Step 1 when evaluating a sleep tracker is: *How well do you measure those?*
- Step 2 is: *How well do you take those in your algorithm and predict sleep staging, sleep efficiency, wakefulness, etc.?*

## Sleep tracking wearables: interpreting metrics, and the pros and cons of trackers [1:04:30]

**Interpreting metrics from sleep trackers**:

- Most trackers will spit out an “overall” score of your sleep
- But Peter prefers to look at the raw inputs
- For instance, Peter is getting over a virus right now, and for the last three nights:
  - Resting heart rate has been 10 beats higher
  - Heart rate variability has been 10 milliseconds lower
  - Body temperature has been two degrees higher.
  - “Those are three objective measurements that I can see that kind of validate what I know, which is I feel horrible, my workouts suck, I don’t have a lot of energy”
- Now there are other things that will impact that your data negatively
  - Alcohol and lots of food will have the same thing, but not to that extent

***What does Peter want to see in the data?***

*Resting HR*

- Want to see relatively quick drop in heart rate when he goes to sleep
- If it takes all night to get down to the nadir, that’s usually a sign that you’re not well rested, you’re over training or something like that

*Heart rate variability*

- HR variability is generally reported as an average, but want to also pay attention to the peak level
- So not just looking at the average but the variability of heart rate variability
- In other words, you have a tracing of heart rate variability, but the trackers tend to just say this was your average, you want to actually see how it looked and what the peak levels were

*Body temp*

- Temperature is actually a really interesting metric to pay attention to and it’s certainly one of those places where you’ll see late night eating and alcohol have a negative impact.
- For Peter, the cooler his temperature, the better he’s sleeping, and that’s obviously being facilitated through the sleep cooler device

*Movement and wake ups (not always very reliable)*

- He tries to see if there’s a correlation between what the tracker thinks is a wake up and an actual movement – Usually they’re pretty well correlated
- If a device thinks I’m waking up, it’s really just that I’m kind of rolling in bed.
- Sometimes you’ll see a clear wake up — Probably one out of every five nights I get up to pee at some point at night and that’s a real clear wake up and you see that and it’s obviously associated with a lot of movement.
- But also he finds that a lot of times these trackers are completely misinterpreting wake ups
- \*That’s one of those examples where I think sometimes just taking the trackers off, if that’s getting too much in your head
  - If you’re frustrated at the data and when you otherwise feel fine and rested you have to ask yourself, “*Why am I letting this thing tell me that I had a restless night of sleep?*”
  - It makes sense to take it off for a while and just continue to feel fine sleeping and then you might put it back on and see if it’s giving you a different answer

**When a wearable is helpful and not so helpful:**

With sleep trackers (and the same is true for CGM), these things are really good in a couple of settings:

- 1 – when they allow you to tinker with changes that you’re making and assess the outcomes
  - I.e., Does this regimen work better than this regimen? Is this sauna helping or hurting?
  - And it can’t be based on one night, it’s got to be reproducible, i.e., happens most of the time versus not
- 2 – The other area where it can be really helpful is in improving compliance of behaviors
  - Meaning, you change your behaviors because you don’t want to “see” poor results on your tracker

When it’s not so helpful:

- It’s not so helpful when you cross over that threshold and you get into the point where the results of the thing, in this case the sleep tracker, if negative, impact your quality of life
- Like if the suggestion of bad sleep actually makes you feel and perform worse, then you’ve got to take that thing off
- Peter generally takes off his tracker when he KNOWS his sleep will be bad (recent example being when he went hunting for a few days)
  - “*I just didn’t feel the need to be reminded of how poorly my sleep was by those metrics*”

**Several studies have shown that external manipulation of perception of sleep quality can impact cognitive performance as well as subjective feelings of sleepiness.**

![](https://peterattiamd.com/wp-content/uploads/2022/12/f2.-sham-studies-ama42-910x1024.png)

**Figure 2.** [Draganich 2014](https://www.apa.org/pubs/journals/features/xlm-a0035546.pdf), [Gavriloff 2018](https://ora.ox.ac.uk/objects/uuid:fa83bf8c-2e74-4a2d-bb64-3c6ed05a66e2/download_file?file_format=pdf&hyrax_fileset_id=mba46d4dc7d836563ad2a9e2fb78d6ec8&safe_filename=Sham%2Bfeedback%2Bbiases%2Binsomnia-related%2Bsymptom%2Breports%2B-%2BAAM.pdf&type_of_work=Journal+article), [Rahman 2020](https://www.sciencedirect.com/science/article/abs/pii/S0022399919307081)

The [2014 study](https://www.apa.org/pubs/journals/features/xlm-a0035546.pdf):

- This study used false/arbitrary sleep quality “measurements” to assess effect of sleep quality feedback on performance
- Surveyed participants on their previous night’s sleep quality, then pretended to “measure” the previous night’s sleep quality (as a % of REM sleep) from heart rate, pulse, and a sham EEG.
- Each subject was assigned to “below average” or “above average” sleep quality, regardless of self-reported status

\*Quick story on history of sham surgeries:

- Sham experiments are a very important part of medicine
- There was a day when they used to do sham **surgeries**
  - So you would’ve had two groups of people that were randomized, one to actually get the surgical treatment (e.g., removing your gallbladder or repairing your hernia)
  - And the other group was anesthetized and actually cut open and then closed and nothing was done on the inside
- They actually did sham surgeries for coronary artery bypasses
  - So both people are getting the full median sternotomy but one group is actually getting a bypass and one group is not
  - And the question in that situation was like do these things actually help you live longer independent of your belief around whether or not you have the operation?
- ⇒ For more on sham surgery experiments, check out [episode #36 with Eric Chehab](https://peterattiamd.com/ericchehab/)

Back to the [2014 study](https://www.apa.org/pubs/journals/features/xlm-a0035546.pdf)…

- In a test of auditory attention and processing speed  (PASAT – paced auditory serial addition test), those assigned to the “above average” group outperformed those assigned to the “below average” group, but self-reported sleep quality was not predictive of cognitive functioning.
- In other words, **telling people that they slept well versus not well seemed to determine performance**

The [2020 study](https://www.sciencedirect.com/science/article/abs/pii/S0022399919307081):

- This was an inpatient sleep study (i.e., patients that were brought into a facility to sleep)
- In the study, they manipulated the clock speed to influence the patient’s perception of total sleep time
- In other words, all the patients would sleep at the same time, but some thought that they slept more versus less based on the manipulation of clock.
- The results were that the cognitive performance was significantly worse (by an increase in reaction time) in subjects who slept for eight hours but were informed that they were only sleeping five hours compared to those who slept for eight hours and who were correctly informed of it
- “*So you think about that, it’s hard for me to consider data like that and not think that when you tell somebody their sleep score stinks, it’s going to set them up for a bad day*.” says Peter

Side note: Peter was talking with [Inigo San Milan](https://twitter.com/doctorinigo) and asked Inigo whether [Tadej Pogacar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) would wear sleep trackers or even HR trackers during the race…

- Inigo said something along the lines of “*Absolutely not. The last thing I want him thinking when he gets up in the morning is, I didn’t have a good night’s sleep last night. I’m not going to be ready to go out and attack*.”

## Final takeaways on sleep [1:16:30]

***Any last bit of advice you’d want to give people before we sign off?***

- You have to find the balance between the art and the science on this
- Once you’re getting too bent out of shape over it, you’ve gone too far, you’ve got to back off and take the tracker off and stop micromanaging it.
- At the other end of the spectrum, a lot of people who sleep poorly, it’s really easy to fix if they’re really being brutally honest with their sleep hygiene stuff.
  - Are you really stopping your food and your alcohol or cutting your alcohol all together at the right time?
  - Are you really winding yourself down and not winding yourself up before bed?
  - Are you in a dark room?
  - Is it cool?
  - And are you giving yourself 8.5 hours to be in bed?

> “You can get so much of the benefit by just getting those things right. And it’s amazing to me how many people come to me who are complaining of horrible sleep and they tell you they’ve done everything and they haven’t done those things.” —Peter Attia

⇒ For more on sleep metrics like heart rate variability, check out: [#193 – AMA #31: Heart rate variability (HRV), alcohol, sleep, and more](https://peterattiamd.com/ama31/)

§

## Selected Links / Related Material

**Peter’s post on instagram about sleep trackers and pre-sleep routine**: [@PeterAttiaMD](https://www.instagram.com/p/Cif5R9KuXzk/) | (instagram.com) [3:30]

**Episode of The Drive that discusses Peter’s changing thoughts on the literature surrounding hot therapy (sauna)**: [#132 – AMA #16: Exploring hot and cold therapy](https://peterattiamd.com/ama16/) | Peter Attia (peterattiamd.com) [6:45]

**AMA episode of The Drive where Peter provides some tips on prioritizing healthy habits while navigating the stresses of life**: [#231 – AMA #41: Medicine 3.0, developments in the field of aging, healthy habits in times of stress, and more](https://peterattiamd.com/ama41/) | Peter Attia (peterattiamd.com) [10:30]

**Two episodes of The Drive where Peter discusses where his thoughts have evolved and/or opinions have changed on certain topics**: [16:30]

- [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/)
- [#202 – Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes](https://peterattiamd.com/strong-convictions-loosely-held-2/)

**AMA episode where Peter discusses how his opinion on fasting and time-restricted feeding has evolved**:  [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/) | Peter Attia (peterattiamd.com) [16:30]

**Pregabalin study in rats showing that it increased the duration of non REM deep sleep and came at the expense of some REM sleep**: [Pregabalin Enhances Nonrapid Eye Movement Sleep](https://jpet.aspetjournals.org/content/299/3/1095) (Kubota et al., 2001) [24:00]

**Pregabalin study in humans (double blind three-way crossover study using polysomnography) comparing placebo with Pregabalin and found a significant increase in the proportion of slow wave sleep**: [A Double-Blind Study in Healthy Volunteers to Assess the Effects on Sleep of Pregabalin Compared with Alprazolam and Placebo](https://academic.oup.com/sleep/article/28/2/187/2696902?login=false) (Hindmarch et al., 2005) [24:30]

**Review article looking the effects of pregabalin where it showed an increase in total sleep time and a reduction in wake up time**: [A review of the effects of pregabalin on sleep disturbance across multiple clinical conditions](https://pubmed.ncbi.nlm.nih.gov/24119681/) (Roth et al., 2014) [25:30]

**Trazodone meta-analysis showing showed that total sleep time is increased**: [Trazodone changed the polysomnographic sleep architecture in insomnia disorder: a systematic review and meta-analysis](https://www.nature.com/articles/s41598-022-18776-7#Sec22) (Zheng et al., 2022) [25:30]

**Episodes of The Drive with Paul Cont**i: [29:00]

- [#15 – Paul Conti, M.D.: trauma, suicide, community, and self-compassion](https://peterattiamd.com/paulconti/) | Peter Attia (peterattiamd.com)
- [#105 – Paul Conti, M.D.: The psychological toll of a pandemic, and the societal problems it has highlighted](https://peterattiamd.com/paulconti2/) | Peter Attia (peterattiamd.com)
- [#190 – Paul Conti, M.D.: How to heal from trauma and break the cycle of shame](https://peterattiamd.com/paulconti3/) | Peter Attia (peterattiamd.com)

**All seven episodes of The Drive with Matthew Walker**: [34:15]

- April 1, 2019: [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/)
- April 8, 2019: [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/)
- April 15, 2019: [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/)
- June 17, 2019: [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/)
- October 28, 2019: [#77 – AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/)
- August 31, 2020: [#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book](https://peterattiamd.com/matthewwalker4/)
- September 7, 2020: [#127 – AMA #3 with sleep expert, Matthew Walker, Ph.D.: Fasting, gut health, blue light, caffeine, REM sleep, and more](https://peterattiamd.com/matthewwalkerama3/)

**Animal study suggesting benefit of glycine for sleep**: [The Sleep-Promoting and Hypothermic Effects of Glycine are Mediated by NMDA Receptors in the Suprachiasmatic Nucleus](https://www.nature.com/articles/npp2014326) (Kawai et al., 2015) [39:30]

**Glycine study in humans using polysomnography and showing benefits for sleep**: [Glycine ingestion improves subjective sleep quality in human volunteers, correlating with polysomnographic changes](https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1479-8425.2007.00262.x?crsi=662496636&cicada_org_src=healthwebmagazine.com&cicada_org_mdm=direct) (Yamadera et al., 2007) [39:30]

**Episode of The Drive where Peter discusses his “jet lag protocol”**: [#45 – AMA #4: sleep, jet lag protocol, autophagy, metformin, and more](https://peterattiamd.com/ama04/) | Peter Attia (peterattiamd.com) [41:15]

**Ashwagandha studies which Peter says are “not overwhelmingly robust”**: [44:15]

- *An RCT (n=58) that found 300 mg of ashwagandha 2x per day for 10 weeks shortened sleep onset latency, improved sleep efficiency and sleep quality*: [Efficacy and Safety of Ashwagandha (Withania somnifera) Root Extract in Insomnia and Anxiety: A Double-blind, Randomized, Placebo-controlled Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6827862/) (Langade et al., 2019)
- *An RCT (n = 58) that used either 250 or 600 mg daily ashwagandha for its anxiolytic effects found that both doses reduced serum cortisol and improved subjective sleep quality based on a 7-point sleep scale*: [Adaptogenic and Anxiolytic Effects of Ashwagandha Root Extract in Healthy Adults: A Double-blind, Randomized, Placebo-controlled Clinical Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6979308/) (Salve et al., 2019)

**Episode where Peter discussed more about magnesium L-threonate and overall magnesium supplementation**: [#145 – AMA #19: Deep dive on Zone 2 training, magnesium supplementation, and how to engage with your doctor](https://peterattiamd.com/ama19/) | Peter Attia (peterattiamd.com) [48:30]

**The brand of cooling mattress topper that Peter currently uses**: [Eight Sleep](https://www.eightsleep.com/) [53:30]

**Previous cooling device that Peter was using before switching to Eight Sleep**: [ChiliPad](https://sleep.me/) [53:30]

Episode of The Drive where Peter goes into depth about his major back issues dating back to medical school: [#68 – Marty Makary, M.D.: The US healthcare system—why it’s broken, steps to fix it, and how to protect yourself](https://peterattiamd.com/martymakary/) | Peter Attia (peterattiamd.com)

**Wearable sleep trackers mentioned**: [56:30]

- [FitBit](https://www.fitbit.com/global/us/technology/sleep)
- [Oura Ring](https://ouraring.com/) (Peter’s preference)
- [WHOOP](https://www.whoop.com/)

**Several studies have shown that external manipulation of perception of sleep quality can impact cognitive performance as well as subjective feelings of sleepiness**: [1:11:30]

- [Placebo Sleep Affects Cognitive Functioning](https://www.apa.org/pubs/journals/features/xlm-a0035546.pdf) (Draganich et al., 2014)
- [Sham sleep feedback delivered via actigraphy biases daytime symptom reports in people with insomnia: implications for insomnia disorder and wearable devices](https://ora.ox.ac.uk/objects/uuid:fa83bf8c-2e74-4a2d-bb64-3c6ed05a66e2/download_file?file_format=pdf&hyrax_fileset_id=mba46d4dc7d836563ad2a9e2fb78d6ec8&safe_filename=Sham%2Bfeedback%2Bbiases%2Binsomnia-related%2Bsymptom%2Breports%2B-%2BAAM.pdf&type_of_work=Journal+article) (Gavriloff et al., 2018)
- [Manipulating sleep duration perception changes cognitive performance – An exploratory analysis](https://www.sciencedirect.com/science/article/abs/pii/S0022399919307081) (Rahman et al., 2020)

**Episode of The Drive on sleep metrics like heart rate variability and more**: [#193 – AMA #31: Heart rate variability (HRV), alcohol, sleep, and more](https://peterattiamd.com/ama31/) | Peter Attia (peterattiamd.com) [1:17:45]

§

## People Mentioned

- [Matthew Walker](https://www.sleepdiplomat.com/) [00:30, 15:30, 20:45, 34:15]
- [Vikas Jain](https://www.sleepcareonline.com/meet-our-physicians/) [20:45]
- [Paul Conti](https://www.drpaulconti.com/) [29:00]
- [Jocko Willink](https://en.wikipedia.org/wiki/Jocko_Willink) [57:30]
- [Iñigo San Millán](https://twitter.com/doctorinigo) [1:14:00]
- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar) [1:14:00]
- [Steve Levitt](https://en.wikipedia.org/wiki/Steven_Levitt) [1:16:00]

§