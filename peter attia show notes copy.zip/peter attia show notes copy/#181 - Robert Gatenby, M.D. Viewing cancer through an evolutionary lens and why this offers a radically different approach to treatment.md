# #181 – Robert Gatenby, M.D.: Viewing cancer through an evolutionary lens and why this offers a radically different approach to treatment

**Source:** [https://peterattiamd.com/robertgatenby/](https://peterattiamd.com/robertgatenby/)

---

Robert (Bob) Gatenby is a radiologist who specializes in exploring theoretical and experimental models of evolutionary dynamics in cancer and cancer drug resistance. He has developed an adaptive therapy approach for treating cancer which has shown promise in improving survival times with less cumulative drug use. In this episode, Bob explains what brought him into medicine, his search for organizing principles from which to understand cancer, and the mathematical modeling of other complex systems that led him to model the dynamics of tumor cell changes in cancer. He discusses his pilot clinical trial treating metastatic prostate cancer, in which he used an evolutionary game theory model to analyze patient-specific tumor dynamics and determine the on/off cycling of treatment. He describes how altering chemotherapy to maximize the fitness ratio between drug-sensitive and drug-resistant cancer cells can increase patient survival and explains how treatment of metastatic cancer may be improved using adaptive therapy and strategic sequencing of different chemotherapy drugs.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/uR9i2aPD29s)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/robertgatenby/the_Drive_public.png)

Play

#181 - Robert Gatenby, M.D.: Viewing cancer through an evolutionary lens and why this offers a radically different approach to treatment

#181 - Robert Gatenby, M.D.: Viewing cancer through an evolutionary lens and why this offers a radically different approach to treatment

1x15s30s

0:001:59:40

## We discuss:

- Bob’s unlikely path to medicine and his disappointment with his medical school experience [1:45];
- Rethinking the approach to cancer: using first principles and applying mathematical models [12:15];
- Relating predator prey-models to cancer [26:30];
- Insights into cancer gathered from ecological models of pests and pesticides [32:15];
- Bob’s pilot clinical trial: the advantages of adaptive therapy compared to standard prostate cancer treatment [41:45];
- New avenues of cancer therapy: utilizing drug-sensitive cancer cells to control drug-resistant cancer cells [48:15];
- The vulnerability of small populations of cancer cells and the problem with a “single strike” treatment approach [56:00];
- Using a sequence of therapies to make cancer cells more susceptible to targeted treatment [1:05:00];
- How immunotherapy fits into the cancer treatment toolkit [1:15:30];
- Insights into why cancer spreads, where it metastasizes, and the source-sink trade off of cancer [1:20:15];
- Defining Eco- and Evo-indices and how they can be used to make better clinical decisions [1:29:45];
- Advantages of early screening for cancer [1:40:15];
- Bob’s goals for follow-ups after the success of his prostate cancer trial [1:42:15];
- Treatment options for cancer patients who have been told they have “failed therapy” [1:51:15];
- More.

§

## Show Notes

## Bob’s unlikely path to medicine and his disappointment with his medical school experience [1:45]

- Peter stumbled across Bob’s work preparing for another podcast
  - The article in [Wired](https://www.wired.com/story/cancer-treatment-darwin-evolution/) about his new approach to treating cancer quickly captivated him

- *Originally, Bob wanted to be a physicist*

- - After working with some great physicists, he came to the conclusion that he wasn’t smart enough
  - It was the Vietnam war era and going to medical school was considered something that was really for humanity; he decided to do that

- *He was at Princeton as an undergrad in the late sixties-early seventies*

- Peter notes [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) did his PhD at Princeton too, and undergrad at MIT
- There was the shadow of [Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) there in the late sixties because he had just won his [Nobel prize in ‘65](https://www.nobelprize.org/prizes/physics/1965/summary/)
  - [Wheeler](https://en.wikipedia.org/wiki/John_Archibald_Wheeler) was still the department chair; he was one of the great physicists of his generation
  - Bob’s TA won a [Field Medal](https://en.wikipedia.org/wiki/Fields_Medal); it’s only awarded every 4 years
  - He was surrounded by really smart people
  - It was an intellectually exciting to be there at the time
  - [Dr. Witten](https://en.wikipedia.org/wiki/Edward_Witten) was there; he was very involved in string theory
- Going into medicine seemed like the right thing to do in that era
  - Many people, including him, had the desire to help people

**Medical school and how doctors think**

> “I think that’s another part of your story that I can relate to…I realized very quickly that in biology, you couldn’t think your way out of every problem the way you could in math or physics or engineering.” – Peter Attia

- *Bob discovers in his first semester in medical school, in histology that he cannot intuit his way through this class; he has to memorize everything*

- - This foreshadowed some other issues he had with his medical journey
  - It brought him back to his previous 12 years of Catholic school, with catechism; this kind of rote memorization
  - He found similarities between clinical medicine and catechism; when asked the scripted question, one is required to make the scripted answer

- *He remembers one scripted question – why do cancers grow*

- - - The scripted answer was, because cancer cells grow faster than normal cells
      - And that’s totally wrong, on so  many levels that it’s hard to believe
  - Medical school was less scientific than he expected
    - Almost like a trade school in the sense of learning from masters the way to do things

- *It’s very difficult to get physicians as a group, to stop talking dogma and simply think*

- - Memorizing becomes their way of thinking in medical school
  - Bob finds that for things that have been done the same way for the last 5 decades, questioning it doesn’t go over well with physicians
  - This is discussed in books such as  [The Doctor’s Plague](https://www.amazon.com/Doctors-Plague-Childbed-Semmelweis-Discoveries/dp/039332625X/ref=sr_1_1?dchild=1&keywords=the+doctor%27s+plague&qid=1632146077&s=books&sr=1-1) and [The Ghost Map](https://www.amazon.com/Ghost-Map-Londons-Terrifying-Epidemic/dp/1594482691/ref=sr_1_1?dchild=1&keywords=the+ghost+map&qid=1632146178&s=books&sr=1-1)
    - The story of [Ignac Semmelweis](https://en.wikipedia.org/wiki/Ignaz_Semmelweis), a physician in the 1800’s who pioneered handwashing and antiseptic techniques
  - Mid 19th century, the medical community was very, very conservative; and even moving them toward washing hands or using a septic technique took decades

Semmelweis died in an insane asylum for having been so rejected and cast out by the medical community

- Peter relates a story from his medical training, during his residency (6-7 years into his training)
  - He’s looking for any excuse to apply mathematics to problem solving
  - One of his critical care fellows in the ICU rotation (an anesthesiologist) had a PhD in math
    - He was the first person who could really put all of the critical care equations into their truest form of physiologic differential equations
    - He didn’t just explain the dogma but could really show you the theory
    - Peter and he would stay up late, forgo sleep, and talk really deep about medicine
  - Months later Peter became dumbfounded at how naively they would dose antibiotics, based on guessing decay times
  - He thought there must be a more accurate way to do this
  - There were equations that could accurately describe how the plasma concentration of gentamycin would decay; all that was needed was a few more data points
  - In the course of a couple weeks, he built a model that would predict the exact right time to be checking [nadir levels](https://academic.oup.com/cid/article/34/6/730/383556) to re-dose
    - When he attempted to implement this he was met with huge resistance and was actually threatened to be fired by one of the attendings
      - This response does not surprise Bob

## Rethinking the approach to cancer: using first principles and applying mathematical models [12:15]

**What drew Bob to radiology, then radiation oncology?**

- He liked the intellectual exercise, the puzzle of it
- He was a very shy, retiring kid; dealing with patients was very difficult; it was a lot easier to work with films
- It was really one of the few things about school that he liked

**When did he start thinking about cancer differently?**

- His first job was at the [Fox Chase Cancer Center in Philadelphia](https://www.foxchase.org/)
  - His desire to help people was especially strong here because the disease is so awful
  - He spent lots of time learning about cancer, reading textbooks, reading the journal [Cancer Research](https://cancerres.aacrjournals.org/), the flagship journal of the [AACR](https://www.aacr.org/)
    - He asked himself how different studies on cancer fit together
    - He noticed there were no organizing principles; studies were simply making a series of observations and each was quite separate
- In the physics world, observations ultimately led to the development of organizing principles, a [first principle](https://en.wikipedia.org/wiki/First_principle)
- Observations of planetary motion and data observed by [Tycho Brahe](https://en.wikipedia.org/wiki/Tycho_Brahe), then [Kepler](https://en.wikipedia.org/wiki/Johannes_Kepler) developed a kind of [geometric interaction](https://en.wikipedia.org/wiki/Kepler%27s_laws_of_planetary_motion), and ultimately [Newton](https://en.wikipedia.org/wiki/Isaac_Newton) developed the [first principles](https://en.wikipedia.org/wiki/Newton%27s_laws_of_motion) that could put this all together
- One can make the case with [Einstein’s](https://en.wikipedia.org/wiki/Albert_Einstein) work around the [photoelectric effect](https://en.wikipedia.org/wiki/Photoelectric_effect)
- Most people think Einstein won the [Nobel prize](https://www.nobelprize.org/prizes/physics/1921/summary/) for [relativity](https://en.wikipedia.org/wiki/Principle_of_relativity), but it was actually for the photoelectric effect
- He was not the first to observe it but the first to upt it all together

> “And I’ve always found that to be a very illustrative case of what genius really is. It’s that ability to assimilate information and pattern from what others can’t see, and Einstein and others are the examples.” – Peter Attia

**Bob wanted to contribute by developing first principles; it had to be mathematical**

- - He spent a year relearning the mathematics he had forgotten
  - He decided the first principles would focus on evolution and ecology;  that all living systems essentially obey the laws of [Darwin](https://en.wikipedia.org/wiki/Charles_Darwin), [evolution](https://en.wikipedia.org/wiki/Evolution)
    - Therefore cancer must do the same
  - He started writing population dynamic equations and looking at a cancer, looking at the interaction cancer with normal cells and then the cancer cells with each other and competing them
  - Why did Bob focus on a mathematical approach instead of a theoretical one?
    - It was his an appreciation of [nonlinearity](https://en.wikipedia.org/wiki/Nonlinear_system)
    - Humans think [linearly](https://en.wikipedia.org/wiki/Linear_function) and are not good at nonlinear dynamics
    - Complex systems often contain nonlinear things such as a [feedback loop](https://en.wikipedia.org/wiki/Feedback)
    - A great example is when [Benjamin Franklin](https://en.wikipedia.org/wiki/Benjamin_Franklin) wanted to see a [lunar eclipse](https://en.wikipedia.org/wiki/Lunar_eclipse) at a time when a [Nor’easter](https://en.wikipedia.org/wiki/Nor%27easter) came into Philadelphia
      - These are violent storms; winds come from the NE
      - The storm made it so he couldn’t see the lunar eclipse
      - Franklin, like others, thought the wind carried the storm; this is the intuitive thought
      - Franklin talked to his brother in Boston about the eclipse and it turned out that the storm arrived in Boston after the eclipse was over
        - In fact, the storm was going in the opposite direction of the wind

- *Franklin was the first scientist to recognize that something that’s intuitively clear is also wrong*

- - - There are many non-linearities in cancer: feedback, evolution dynamics of resistance, etc.
      - These can’t be intuitively predicted

> “We need to actually understand first principles and the underlying mathematics” – Bob Gatenby

- Peter asks “*Why do you think that evolution gave us, as humans, the ability to understand linear systems quite well, and absolutely no capability to understand nonlinear systems? So for example, it’s clear that we don’t understand* [*hyperbolic discounting*](https://en.wikipedia.org/wiki/Hyperbolic_discounting)*. We just can’t do it. Is it simply that evolution wasn’t optimizing for that problem and it really didn’t, when it came down to reproduction and survival, linearity was sufficient?*”
  - Perhaps what humans need to know to survive and reproduce is sufficiently linear
  - Relatively simple things that are related to eating and running away from predators, and running after mates, are probably sufficiently linear; perhaps that was all that was necessary

- Peter observes that Bob doesn’t have many colleagues in this line of thought, there’s not a conference for theoretical biologists
  - Correct, and similar to the response of Peter’s colleagues to his model of antibiotic dosing, pretty much all of his colleagues hated it and thought it was ridiculous
    - Everyone thought cancer was too complicated to model
    - It takes humility to step back and realize the need to study math models and computer simulations to understand what is happening in cancer

**Other complex systems can be modeled, so can cancer**

> “It’s funny because if I had a dollar for every time someone said to me that cancer is too complicated to model, I wouldn’t have to apply for grants anymore.” – Bob Gatenby

- Peter compares cancer to the complex systems of economics; many of the Nobel prizes awarded in that field are fundamentally based on mathematics, a lot are behavioral as well
  - Peter explains – “*I don’t think anybody is suggesting that the models are sufficient in economics. In other words, that you can take an economic model, you can plug in all of the initial conditions and it will tell you the answer, if unemployment is this, if the rate of home price appreciation is this, if inflation is this, here are 50 starting variables, put them in the model and it will spit out GDP growth 10 years from now. I don’t think anybody is so delusional to believe that that’s true. But it still doesn’t minimize what the model can do for your understanding of the system.*”

> “There’s no way that the human brain is going to understand complex systems without sufficient mathematics.” – Bob Gatenby

- Bob compares it to hurricane modeling and weather modeling in general
  - A classic example of how to master a complex dynamic system
  - One can have confidence in the weather prediction for the next 24 hours; later on the accuracy goes down because of the complexity and stochastic changes
- In cancer modeling, it’s not necessary to predict what’s going to happen 10 years from now; one only needs to know what therapy should be used today, then for the next 3 months, and so on
  - Some people have this idea that doctors/ scientists should be able to predict the entire course of cancer; this is not realistic
- Peter  likes the comparison to hurricanes and weather because they’re some of the most complicated models out there
- This has to do with the fact that they behave as [Lorenz curves](https://en.wikipedia.org/wiki/Lorenz_curve), they are [chaotic systems](https://en.wikipedia.org/wiki/Chaos_theory)
- Weather and storms are so sensitive to initial conditions
  - He remembers studying chaos in college, the first example learned is about the butterfly that flaps its wings in Tokyo, that leads to the storm two weeks later in New York
- Peter asks where Bob would put cancer models on a spectrum of model accuracy, from a linear regression model that works perfectly because you have infinite past data and the future scenarios don’t deviate (a 1) to a chaotic model such as weather or worse (a 10)
  - 8 or 9; cancer is more on the chaotic end
  - Predictions are difficult because there’s a lot of [stochasticity](https://en.wikipedia.org/wiki/Stochastic), there’s also a lot of heterogeneity

> “It’s harder to predict, but not infinitely hard. I mean, I think we can do this. We always have to have a level of humility and understanding that first of all, evolution is very clever and it likes to embarrass you. You can easily crash and burn. But it’s not random either. There’s predictability to it and finding that point between them, where you can predict with reasonable certainty and also hedge your bets in ways, that even if things don’t go exactly as you planned, but you can still benefit the patient” – Bob Gatenby

- Early recognition that treatment is not going the way it was planned can allow for models to be recalibrated, to rethink the underlined dynamics and then move forward
  - This is needed as opposed to here’s the model – take one a day for the next 10 years

## Relating predator prey-models to cancer [26:30]

**What led to the study of** [**predator/prey models**](https://en.wikipedia.org/wiki/Lotka%E2%80%93Volterra_equations)**?**

- Understanding evolutionary dynamics in a swamp ecosystem
  - It’s very appealing because of course they’re living systems
  - The ecology of swamps and that sort of thing is very complicated; but models can, more or les,s master these complex relationships

> “When you work in a cancer center, the cancer almost takes on a persona, an evil entity kind of thing, almost magical in its ability to overcome anything that the physicians do.” – Bob Gatenby

- *Simply saying that cancers have to obey Darwinian laws, that they’re not magic, they’re not unfathomable is useful*

- - Cancers are really good evolutionary machines; this can be mastered
  - Understand evolution to get on top of this
- This deterministic quality, some cause/effect relationships were comforting to him and offered hope for developing better treatments.

**Explain the standard, relatively simple predator/prey models**

- The swamp is too complicated because there might be multiple predators and multiple prey
  - Start with first order differential equations, second order differential equations, in an isolated ecosystem…How does that dynamic work?
- Well, the hares convert local vegetation to babies, to baby hares as they reproduce
- The foxes or whatever the predator is going to eat the rabbits
- These populations rise and fall because if the predator eats too many of the prey, then the prey population will decline
  - As the prey population declines, the predator population expands
  - Then the predator population will decline as there is less prey
- There is a cycling effect that goes on for prolonged periods of time
  - Some data suggest that this is the case, but as with everything that’s living, it’s always more complicated than that
  - There’s always various factors that come into play
- This was one of the first of recognized population models that began to be applied to nature

Bob remarks “*It’s interesting to see that, and predator/prey models are things that we use a little bit like for the immune system. Where the immune system is kind of a predator and it’s chasing after the cancer cells. But of course they’re important differences in that. The predator eats the prey and gains substrate from that. Whereas in the immune system, it kills the cancer cells, but it loses substrate, doesn’t eat them up.*”

> “It’s an appealing model, yet there are important distinctions that you have to recognize that make the biology different and in some ways can give advantages to the prey that you don’t really expect.” – Bob Gatenby

- A swamp would be a more complicated system
  - There is everything from algae to bacteria, to small fish, the amount of sunlight coming in, the temperature… this is more like the human body
  - There may be an algal bloom that consumes all the oxygen and rapidly kills all the fish versus a system that is more sustained where there is some algae but the fish can live
  - There’s kind of a beautiful chain of carbon fixation that goes from algae to fish

**Peter asks “How did you get to the point where you could look at that and say, “We can now model this for human cancer, given that this is far more likely how it behaves?””**

- - It’s simplifying, at best a cartoon
  - Ecologists that are looking at a new ecosystem will begin by asking a very simple question – What’s the birth rate and death rate of each species that’s present?

- *This is not known for cancer*

- - What is the carbon cycle, what’s the iron cycle, what’s the nitrogen, what are all these cycles?
  - How can scientists and doctors watch these [substrates](https://en.wikipedia.org/wiki/Substrate_(chemistry)) pass through individuals, and how does that work?
  - Cancer biologists have never thought in these terms

> “It’s astonishing to me that we don’t know that, and things like that, what’s the growth rate of the tumor? What are we dealing with even in a first of order estimate? … It’s kind of astounding to me that we do things very crudely.” – Bob Gatenby

## Insights into cancer gathered from ecological models of pests and pesticides [32:15]

*The more sophisticated view taken by evolutionary biologists and ecologists*

- The evolutionary biologists and ecologists take a far more sophisticated view of these interactions than cancer biologists do
  - Pesticide manufacturers are required by law to submit a resistance management plan
  - They have to identify the mechanisms of resistance and make a plan to prevent that from occurring
  - Cancer drugs are routinely approved without any knowledge of what the resistance mechanisms are let alone any plan to manage that in patients
- Ecologists and biologists have pushed ahead of cancer biologists and now it’s a game of catch-up  in terms of understanding, in terms of taking their sophisticated models and applying them to cancer

*Ecological models of pests and pesticides gave Bob big insight into cancer*

- The story of the [diamondback moth](https://en.wikipedia.org/wiki/Diamondback_moth) was first recognized somewhere in the Midwest, in the mid 19th century
  - These moths have the honor of having been struck by every pesticide developed in the modern era, yet this has done absolutely nothing to its population; it’s spread all over the country, to Europe, Asia, everywhere
  - In the 1980s diamondback moths were uncovered that were not susceptible to any known pesticide; they’d become resistant to all of them
    - This is interesting, look at this whole process; farmers for centuries used pesticides freely; dump as much as possible on one’s field; get rid of as many of the pests as possible
    - But what people realized is, this practice is selecting for resistance

Peter asks “*Explain to people why that’s true because it is counter intuitive.* I think most people would say, “Well, Gosh, if I’m a farmer and I’ve got my acre of corn here, and there are a million moths that have descended on this acre, I want to get every one of them eradicated. And the best odds of doing that, wouldn’t that just be using all of the pesticide I can just shy of killing my own crop?””

- - Yes. And that’s one of those things that is intuitively appealing, but not necessarily true
  - The reason is that the moths are a very large population, and this is not a uniform population
  - This is biology, which means that there’s heterogeneity within that population
  - So there are moths in that population that are extremely sensitive to the pesticide, and there’s going to be moths in that population that are not very sensitive to the pesticide
  - Let’s put some numbers to it. Take a million moths, dump the best pesticide imaginable on them.
    - Let’s assume that there’s a spectrum and 20% of them die at the first whiff of the pesticide; and 60% of them eventually die
    - But 20% of them are resistant to the pesticide and don’t die
    - This is still good, because 80% of the moths are gone
    - Now dump pesticide on them again
    - The 20% resistant moths now has a whole field that’s open to it, without competitors; this population can rapidly expand
      - And it’s taking his genome with it; t’s offspring will also be somewhat heterogeneous, but they will definitely be shifted more toward pesticide resistance
      - Now dump your massive amounts of pesticide and maybe a 5% of them die or maybe eventually 20% of them die

- *But 80% of them don’t die and the long-term effect is that now it’s a pest that can’t be controlled*

- - - Next, a new pesticide is needed
      - There is always some cross-resistance
      - In any large biological population there is heterogeneity, another source of resistance

- *Experience has shown that large doses of pesticides give short-term gain, but in the long term, it doesn’t work*

- - In the [Nixon administration](https://en.wikipedia.org/wiki/Pesticide_regulation_in_the_United_States) using large doses of pesticides was no longer allowed; this was the beginning of integrated pest management
    - The idea is to give enough pesticide to knock a population low enough that they’re not going to do much crop damage, but don’t give more than that
      - There’s a number of ways this can be accomplished
      - Put pesticide on three quarters of the field and leave one quarter untouched; in this last quarter of the field, no selection for resistance is applied

- *This results in reducing the pest population and there is no selection for resistance*

**Resistance and factors to consider for improving cancer treatment [39:15]**

*There’s another bit to this; resistance costs something*

- - There needs to be the molecular machinery necessary to deal with the chemicals
  - DNA has to be repaired if it’s damaged
  - Chemicals have to be pumped out, this is a common mechanism
  - There are a number of different mechanisms of resistance, but all have a cost
  - It doesn’t necessarily have to be a big cost

- *In the cost benefit ratio, when there is a lot of drug around, the benefit greatly outweighs the cost, but when there’s no drug present, then the benefit does not outweigh the cost*

- In the absence of drug, the guys that are not resistant don’t have to carry that machinery around with them and they are now more fit
- There is a subtle competition that goes on
  - Select for resistance in  say the three quarters of the field; but when the ones that are sensitive move into that area and now the drug is gone, there’s no selection for resistance
  - Their fitness advantage will be such that when the pest population comes back to something close to what it was at the beginning, it’s as sensitive as it was in the beginning

*Can the problem of resistance get better?*

- Is there a scenario where in year one, 20% of the moths are resistant to the pesticide, but if managed correctly, in year five, that number is 10% because they have actually been out-competed by the other moths?
  - Yes, only recently has this scenario come up

## Bob’s pilot clinical trial: the advantages of adaptive therapy compared to standard prostate cancer treatment [41:45]

- Gatenby has [published a study of men with prostate cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5703947/) where patients received drug until the tumor responded to 50% of its pretreatment value, then drug treatment was stopped
  - When the drug is not applied, the expectation is that sensitive cells will grow at the expense of drug-resistant cells
  - Models predict that when the  sensitive population declines (shown in purple in the figure below , the resistant population would increase (resistant cells shown in green)
    - The figure below compares standard prostate cancer treatment (in part a) to the adaptive therapy described here (in part b)

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-1.-robertgatenby-1024x1019.png)

**Figure 1. Utilizing evolutionary dynamics to design adaptive cancer therapy results in tumors that contain fewer drug-resistant cells (b) as compared to standard treatment (a).**  Image credit: Figure 1 from [Integrating evolutionary dynamics into treatment of metastatic castrate-resistant prostate cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5703947/) (*Nature Communications* 2017)

- - The idea is to let  the sensitive population grow and the resistant population would reach a plateau

- *This plateau was assumed to occur in each cycle, but stepwise the resistant population kept increasing and at some point control of tumor growth is lost and treatment fails*

- - Peter remarks about the huge variance observed in treatment of patients in this study, 2-20 cycles; “that could be the difference between a few months and a few years. Why such a difference?”
  - In this study, the fraction of the original tumor made up by the resistant population was unknown
    - So if it’s 1%, that takes longer than if it’s, let’s say 20 to 30%
    - The rate of proliferation also was not clear
    - Birth and death rates of cells were estimated

- *This was a pilot clinical trial of intermittent therapy compared to the standard therapy of maximum tolerated dose*

- - - The difference between the groups was 16 months
    - The median time to progression for standard of care was 14 months
    - The median time to progression for this intermittent/ adaptive therapy was 30 months
      - 4 of these 20 patients are now five years out and still cycling, being treated with adaptive therapy
      - These are patients with metastatic prostate cancer

- *Perhaps the most important thing that came out of this trial was the number seven, because the ratio of the fitness measure for the sensitive cells was seven fold that of the resistant cells*

- They had originally estimated this ratio at 2 or 3; 7 is a big difference in favor of the healthy cell
- This shows that when the sensitive cells go down, resistant cells go up; then when sensitive cells go up, it was expected that resistant cells would plateau when in fact they went down
- Patients enter a sweet spot after 3 cycles where the resistance cells progress toward extinction

**Peter asks if substrate limits are the most important factors creating the fitness differential?**

- - Yes, this is the thought; drug-sensitive and resistant cells are competing for space and substrate
  - Blood flow and delivery of substrate is thought to be poor in the tumor; so substrate is probably the most limiting factor
  - Looking back at these 4 patients, it’s very rare that someone would go five years on this treatment using standard of care
    - Each of these 4 patients had 3 consecutive cycles where the model predicted that they drove the resistant population to extinction or something very close to extinction
    - None of the other patients had these 3 cycles

- *One of the great advantages of having the math models, is the ability to self critique, to see what went right and what went wrong*

- - - Something about the protocol did not hit those 3 consecutive cycles perfectly
    - They over-treated; if they cut back on therapy, the results would have been better

- *The models predicted that every patient in both cohorts of this study could have gained control of the tumor indefinitely*

- - The other cohort received standard of care; but his was not randomized
- PSA was the metric followed and that was probably the biggest mistake
  - When the PSA went down it would be confirmed by radiographic studies
  - PSA levels were monitored every month, but due to insurance restraints, radiographic studies were only performed every 3 months
  - They waited until PSA got to 50% reduction but the radiographic findings were lagging
  - So patients continued to receive drug for 2 months until radiography was performed again
    - Too many of the sensitive cells were killed & the fitness of the sensitive cells was impeded
  - Bob thinks if they had adjusted therapy based solely on PSA levels the results would have been better

> “Your question goes to something that I’ve honestly never thought about before, which is that we thought we could use the sensitive cells to control the resistant cells.” – Bob Gatenby

## New avenues of cancer therapy: utilizing drug-sensitive cancer cells to control drug-resistant cancer cells [48:15]

**Theoretically, this idea of using sensitive cells to control resistant cells is now opening up whole new avenues of therapy**

- - There’s a lot of cases where the initial therapy for cancers gets great results
  - Remission occurs but the  tumor eventually comes back; the resistant cells are there but in a very small number
    - The resistant cells are estimated to be much less fit than the sensitive cells in the absence of treatment
    - The ratio of fitness of sensitive to resistant cells is large; 7 is not unreasonable, it’s highly likely
  - Currently, what is done when therapy causes a tumor to disappear, but drug treatment continues
    - This reduces the fitness of the sensitive cells until the ratio flips in favor of the drug-resistant cells until the tumor is all resistant cells; now the treatment doesn’t work

- *Instead of continuing treatment when the tumor disappears, get the cancer populations to something that’s very, very small, and then hit them again with something different*

- - - Apply additional perturbations
    - Try an approach, called an **extinction approach**; this has not been explored yet
    - When there is a small population, a sequence of smaller perturbations can drive it to extinction
    - It’s a two step process

- *Extinction is achieved through a sequence of perturbations, none of which by itself could cause extinction*

> “For a century we’ve been looking for magic bullets, but maybe all we need is a series of pretty good bullets. So that’s a different sort of thinking process.” – Bob Gatenby

- - This is a hard sell, especially to a medical community where new drug development is what’s most incentivized
  - He’s using a drug called Abiraterone, which is off patent; nobody’s making any money on this
  - The idea is to use drugs that already exist, but use them better

- *There’s not much  natural support for this within the medical community*

**Detour to discuss antibiotic resistance in bacteria [52:15]**

- - Standard thinking for a bacterial infection is to give the antibiotic for a magic number of days, say a 10-course treatment, but 3 days into treatment, the patient feels completely better and the tissue culture is negative
    - Currently, antibiotic treatment continues for the remaining 7 days for fear of generating antibiotic resistance
    - Bob’s results suggest the opposite may be true; giving additional antibiotics might lead to resistance
    - Bob doesn’t work with infections, but others are exploring adaptive approaches to keep the resistant population in check
    - Others are exploring evolution-based mathematical models to plan treatment

- *One difference between antibiotics and bacteria versus chemotherapy and cancer is one could live with billions of cancer cells in your body and be totally fine; it is not known if this is true for* [*MRSA*](https://en.wikipedia.org/wiki/Methicillin-resistant_Staphylococcus_aureus)

- - The one thing to remember is that by the time one has cancer, the tumor has defeated the immune system
  - Bacteria often are still very different from our normal cells and therefore more targetable by the immune system
  - He thinks the dynamic is different for cancer and bacterial infection but would defer to experts in infection

## The vulnerability of small populations of cancer cells and the problem with a “single strike” treatment approach [56:00]

- To detect cancer, it’s amazing how many cancer cells are actually needed; it’s about a billion cells in a centimeter cube
  - Outside of liquid biopsies, there is no clinical way to detect cancer shy of about a billion cells
  - This speaks to the non-linearity of it, to go from a million to a billion versus a billion to a trillion
  - It’s hard for people to wrap their head around what’s involved in those things
  - It’s dealing with something that’s growing with a cube power, not a square power
  - The numbers are so enormous and the heterogeneity is significant

**Bob notes two factors to think about: stochasticity and the** [**Allee effect**](https://en.wikipedia.org/wiki/Allee_effect)

1. Stochasticity

- - If there is a small population then small changes in birth and death rates can be quite significant

- *Small populations can go extinct based on very small changes*

1. The Allee effect

- Classic evolutionary models predict that as a population grows, the fitness should decrease because the population is approaching the carrying capacity of the environment
- The American ecologist Warder Clyde [Allee](https://en.wikipedia.org/wiki/Warder_Clyde_Allee) found that *as a population grows, the fitness actually increases*
  - There is an advantage to groups
  - Herds are an example, they can protect themselves better from predators
  - There is leadership and other things
  - For tumors, there is the need to make blood vessels; so small groups of cells need to get together to make the factors needed for [angiogenesis](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/angiogenesis)
  - Probably not a single cell that can do that; it has to be a loosely organized system
  - The development of an extracellular matrix of collagen and other things that go in between cells that provides a structure for the cells to live on; this also has to be made
  - The immune system must be defeated
  - There is a number of things tumor cells must do together for the tumor to survive and grow and they probably act together to do this

**Applying stochasticity and the Allee effect to cancer**

- *Tumor cells in a small population may not grow as fast as those in a large population; therefore, tumor cells in a small population may be more vulnerable to treatment*

- - - Small populations may not be as able to deal with immunotherapy or targeted therapy or even chemotherapy because they don’t have the capacity to act together
  - These are important factors in understanding treatment
  - Therapies that take large cancers and drive them down so they are not detectable by CT scans, create very small populations
    - These small populations are now vulnerable to dynamics related to stochasticity and Allee effects that the larger populations are not necessarily responsive to
  - Consider [neoadjuvant therapy](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/neoadjuvant-therapy) of a large breast cancer; treatment makes it small and takes it out
    - The tumor isn’t a ball that just shrinks, it fragments
    - Treatment results in the creation of little islands of tumor cells, surrounded by fibrosis, or necrosis or something like that

- *These small populations are highly vulnerable*

- *Bob thinks this is the time to crank it up and kill it*

- - Current dogma in oncology is continuous, maximum tolerated dose until progression
    - *Waiting for progression means waiting until there are billions of cells*; it has to be large enough to feel or image; that’s at least a CC of tumor if not 2-3 CC’s
    - Now this population is large; a few months earlier, a small population could have been treated

**Leukemia is cured by using different treatments in sequence**

- Bob remarks “*What’s interesting is that the pediatric oncologists learned this a long time ago. This is how they cure leukemia.*”
  - First, induction therapy is given
  - Then the therapy is immediately changed to a different drug
  - What they learned was that even after induction therapy, when there was no apparent tumor in the bone marrow or in the blood, that if nothing was done, all the kids would relapse
  - The solution – immediate treatment with another group of drugs, and then another group of drugs. So this is a first strike, second strike kind of approach
  - The outcome can only be measured in the long term by saying, “Well, we’ve cured this kid.””
- Peter notes, in treating leukemia, it is not known which drug is more effective in the cocktail

**A path to extinguishing cancer**

- *There’s a thing called the* [*extinction vortex*](https://en.wikipedia.org/wiki/Extinction_vortex)*; for a small population a sequence of perturbations tend to be self synergizing; as the population gets smaller and smaller it becomes more sensitive to stochastic and Allee effects until it becomes extinct*

- - It’s a different strategy and less precise, but that’s the extinction process
  - Some therapies can act as a single event to cause extinction; the problem is it is in-discriminant

- *But most extinctions are multi-cause, multi-event processes*

- - This idea should be applied to cancer treatment
  - Focus more on multi-cause extinction approaches rather than trying to find a magic bullet that will cure cancer by itself
    - The one-hit extinction approaches often cause huge side effects

> “So far, we’ve not found a magic bullet.” – Bob Gatenby

**Peter notes the problem of collateral damage with the single strike approach**

- Bob often tells people “Well, and to your point, the bigger issue with the dinosaur analogy is not even so much that it’s the exception and not the rule, it’s the collateral damage. When there’s a single strike success, the collateral damage changes the planet. If what killed the dinosaurs when it killed them came to our planet today, it would probably kill a lot of other things as well.”

*A gruesome analogy to understand tumor size and the potential of sequencing treatment:*

- Bob often tells people “1*00 grams of tumor (which is still a pretty small tumor) is going to have 100 billion cells which is far more than the human population on earth*“
- He then asks, could 1 event kill all the people on earth and nothing else?
  - Maybe, but it would be difficult
  - The idea of a magic bullet may not be an achievable result

## Using a sequence of therapies to make cancer cells more susceptible to targeted treatment [1:05:00]

Peter asks a hypothetical:

- - If ideal treatment begins with induction therapy, then a series of therapies follow…
  - What would be better? 6 treatments given in sequence versus giving them all at once?
  - Bob says that *oncology has been doing this for a long time and they find that combination therapy is better than giving therapies one at a time*
    - In other words, the tumor is controlled controlled for a longer period of time, **but the tumor still comes back and the patients die of their disease**

- *What tends to happen is that as you add more and more drugs you get diminishing returns producing more toxicity and achieving no real increase in benefit*

- Bob elaborates:
  - Suppose you have two drugs and you’re applying it to a 10 billion population
    - What is the probability that there are going to be cells present that are resistant to both?
    - This depends on the denominator, the size of the population
  - Now let’s say you have one drug, and you get it down to 10 million cells
    - Now you add the second drug… What is the probability that within these 10 million cells there are cells with some resistance?
    - Then you add a third drug… now, what is the probability of resistant cells in a population of 100,000?
- Peter is confused and asks for clarification: *Wouldn’t those be independent events in the sense that if you just hit the 10 billion cells with all three drugs, shouldn’t you still be able to stratify that resistance pattern. What is it about sequencing those that would create a treatment advantage?*
  - As the population gets smaller, treatment is killing the tumor cells that are sensitive; but remember *resistant cells also have to deploy mechanisms of resistance*
  - And as treatment fragments the tumor population, **there is less of the group network effect**
  - With small populations, subtle changes in birth and death rates will be sufficient to drive into extinction

***How to design this?*** ⇒ Use resistance to your benefit.

- Add in environmental changes, add something anti-angiogenic; now less blood is delivered to the tumor, less substrate is present; it’s a more difficult environment for the cancer cells
  - Atypical medical practices utilize things like antacids and various metabolic things
    - Bob thinks there is a potential advantage to this
- Peter notes they have been mostly discussing chemotherapy, chemicals that are aimed at killing cells that are dividing.

> “The thing we learned in medical school that was incorrect was, cancer cells divide more quickly than regular cells. Those of us that pay attention today know that that’s not actually true at all.” – Peter Attia

**The fundamental difference between a cancer cell and a non cancer cell is the response to cell cycle signaling [1:09:21]**

- - Normal cells don’t divide slower
  - Normal cells stop dividing when they’re told to
  - Cancer cells don’t stop dividing when they’re told to

- *Evolutionarily this has a self-defined fitness function, the proliferation of cancer cells is dependent on its own properties as they interact with the environment, not on instructions from the tissue*

- Normal cells cannot evolve because their birth and death is dependent on tissue controls

- Peter summarizes chemotherapy as the earliest form of modern drug treatment of cancer; this targets cells not responding to cell cycle signaling by killing all dividing cells
  - This is why chemotherapy causes horrible side effects: mucosal ulcers, the hair loss, the skin damage, nail thinning
    - This is all collateral damage from targeting rapidly dividing cells

**Other targets to treat cancer**

- A different target of some cancer drugs is [angiogenesis](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/angiogenesis); [Judah Folkman](https://en.wikipedia.org/wiki/Judah_Folkman) was one of the first to suggest the importance of angiogenesis for cancer growth
- One challenge to cancer cells is to get blood vessels to bring in substrate, glucose, and the things the need to grow
- Vascular endothelial growth factors ([VEGF](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/vegf)) stimulate the formation of new blood vessels
  - Drugs targeting angiogenesis haven’t been very successful
  - Billion-dollar blockbuster drug, [Avastin](https://www.rxlist.com/avastin-drug.htm) was probably the first
  - These drugs extend median survival by only a few months
- Immunotherapy is another approach
- For a few cancers, a single gene mutation exists that can be targeted with
  - For example, [Gleevac](https://www.rxlist.com/gleevec-drug.htm) targets a specific kinase (BCR-ABL tyrosine kinase) present in Chronic Myelogenous Leukemia ([CML](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/cml))
- Peter notes that it seems one could use selective chemotherapies and top it off with anti-VEGF treatment; then *the real question becomes timing, how to cycle those on and off to maximize the gap in fitness*

**Peter asks Bob how to maximize the fitness ratio between drug-sensitive and drug-resistant cancer cells and if his model predicts that 7 is the tipping point?**

- It’s somewhere around 7, when the fitness of drug-sensitive cells are 7-times that of drug resistant cells then adaptive cycling of treatment favors eliminating the cancer
- This ratio is going to vary from tumor to tumor, but I would guess the range is around 5
- Peter wonders if anti-VEGF drugs play a critical role in this when the tumor is scattered
  - To anthropomorphize everything to our society, the United States at 330 million people; if the population were decimated by 90% and there were only 33 million people left, presumably we would no longer continue to be the United States of America. We would be a whole bunch of disparate tribes in total chaos. Therefore we’d be a heck of a lot more susceptible. Is that fair assessment?
  - Bob agrees. In military talk, to defeat an enemy one does not have to deal with the whole population; instead they could do it one at a time
- Bob relates this to tumors after neoadjuvant therapy; these small little populations look like they’re a hundred, maybe a thousand cells, not millions of cells
  - They’re widely separated; they’re not sending cells back and forth very much, if at all
  - It’s a very different dynamic than continuous tumors where if a corner of the tumor were removed, then everything just sort of moves in there and eventually it repopulates; this doesn’t occur in fragmented populations

## How immunotherapy fits into the cancer treatment toolkit [1:15:30]

**Where does immunotherapy fits in to this toolkit**

- - Bob thinks this will be a critical component
  - Immunotherapy is  the closest thing to a magic bullet out there
    - [The Drive podcast #177](https://peterattiamd.com/stevenrosenberg/) explores the history and promise of immunotherapy with Dr. Steven Rosenberg
  - When the cancer population is small, the Allee effects are particularly important in an immuno-response; they are less able to evade the immune system
  - In theory, this is the one you bring in to win the game
  - Peter recalls that first generation immunotherapy was [interleukin 2](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/interleukin-2); melanoma (a cancer sensitive to this) showed a 10-20% response rate, this was treating patients with full blown metastatic melanoma
    - Maybe this would look different in patients who are visibly without disease
  - Bob knows t*here is some evidence to suggest that cells surviving chemotherapy are more vulnerable to immunotherapy*; so this is the thing to do “attack the Achilles heel that’s exposed by this immune response”
  - There is an example of the reverse of this; [one study](https://clincancerres.aacrjournals.org/content/12/3/878.long) used a p53 vaccine in lung cancer patients that had been treated with multiple different things; there was minimal efficacy
    - One patient showed a partial response but the others did not
    - The patients did generate immune cells to the vaccine
    - But giving chemotherapy after the vaccine saw a response rate to the chemotherapy of 60-70%
      - This is astonishing number for patients at that stage of disease; the response rate should have been less than 5%
      - The patients who had the best immune response to the vaccine were the most responsive to chemotherapy; this suggests they developed adaptive strategies that made the cancer more vulnerable to the toxicity of chemotherapy
    - It’s appealing to think that maybe they down-regulated [p53](https://en.wikipedia.org/wiki/P53) so that they were not expressing the target; p53 is important in survival mechanisms; Bob speculates this may be a mechanism for the success observed in this study

- *This is the type of thinking that is needed, instead of providing different therapies in isolation, begin to strategically string together different therapies*

- - - So treatment with one therapy makes the tumor more susceptible to the second therapy and so on
    - Treatments need to be combined in a strategic, thoughtful way instead of a haphazard or intuitive way

- *This is where Bob thinks math models can be very helpful*

## Insights into why cancer spreads, where it metastasizes, and the source-sink trade off of cancer [1:20:15]

- Peter turns the conversation to another feature of cancer he calls the “source sink trade-off”; he’s thought endlessly about this and never came up with a great insight

- *First principles, there aren’t that many cancers that can kill you without spreading*

- - Cancers that can kill without spreading:
    - [glioblastoma multiforme](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/glioblastoma-multiforme) (never leaves the brain),
    - [primary hepatic cancer](https://www.cancer.gov/types/liver/hp/adult-liver-treatment-pdq),
    - [hepatocellular carcinoma](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/hepatocellular-carcinoma),
    - [lung cancer](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/lung-cancer) can kill without spreading but it’s less common
  - Observation #1 – *certain cancers are very deadly; they often* [*metastasize*](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/metastasis) *to other tissues*
    - This includes: breast cancer, prostate cancer, pancreatic cancer, colon cancer
    - These deadly cancers come from an environment that is not especially hospitable to cancers
    - When a woman gets breast cancer, the first thing that cancer wants to do is get out and kill her by going to her bones, her brain, her lungs, her liver
    - Pancreatic cancer virtually always wants to go to the liver, and that’s where it kills
    - Colon cancer wants to go to the lungs, wants to go to the liver, and wants to go to the brain sometimes; and that’s where it kills
    - Prostate virtually always wants to kill you by going to the bones
    - But rarely does a cancer go to the breast, or go to the pancreas, or go to the colon, or go to the prostate
    - The brain is an enormously attractive place for cancers to go; but a primary cancer from the brain never seems to leave
      - Maybe some vascular tumors of the brain can leave, but they’re not really brain parenchymal tumors

**Peter asks Bob if he has any insights into this**

- Bob replies “the short answer is, I don’t know”
- Cancer and metastasis are not a planned events
- It’s common to anthropomorphize cancer – first they go out and prepare a metastatic site, and then they send their cells out to it.

> “That doesn’t happen. An evolving population can never adapt to conditions it has not seen before. It cannot plan to make metastases, and it certainly can’t plan to feather its nest in some distant site before sending out its scouts. That’s not happening.” – Bob Gatenby

- Introductions are seen in nature all the time; a species in introduced and sometimes it is successful and sometimes it is not
- It  has to do with the way their phenotype interacts with the local adaptive landscape and how they adjust
- Sometimes it takes several introductions before the species can expand; and sometimes they go on to die out
- For example, there is a species coming out of the Amazon. The Amazon river collects trees and things that are floating down, the animals are on it and so they go out. Anything downstream of the Amazon is going to be receiving more of these, so they are more likely to see a metastatic monkey or something like that from the middle of the Amazon.
- Back to cancer, the pancreas spills into the portal vein, which then goes into the liver; it’s delivering a lot of its cells to the liver. So it makes sense then that cancer tends to metastasize to the liver, if only because a lot of cells are being sent there.
- Peter agrees; “*the pancreas makes sense. But how do we make sense of the breast? How do we make sense of the prostate going to the bone disproportionately?*”
- Bob suggests a general principle, that there’s something about some of the breast cancer cells that seem to be able to set up shop in bones, some of them in the lung
  - All  for reasons that are not yet clear

**Source-sink dynamic**

- Bob goes back to something Peter mentioned about – source sink, that’s dynamic
  - Source habitat, sink habitats, habitats that have very good blood supply, they are producing a lot of cells; too many cells for the spatial environment, and those cells have to go out
  - In a tumor there are areas with poor blood flow and good blood flow next to one another; one can  imagine cells migrating between these areas
  - This can set up dynamics that are very interesting
    - Think of a breast cancer cell near a blood vessel, now it’s [proliferating](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/proliferating) and there are too many cells, they crowd into the blood vessels; now the blood sends the cells out
      - What if there are syn habitats for this breast cancer cell somewhere else

- *The limiting factor is the dynamics at the metastatic site*

- - If mice are injected with cancer cells, nearly all of these cells die at metastatic sites; only a small percentage of them will grow to form even a few cells

- *This speaks to the importance of small population dynamics; there’s stochastic effects, Allee effects and a lot of statistical problems with going from a single cell to a cancer that’s significant*

> “We are very lucky for that because we know that human cancers are frequently dumping millions of cells into the blood, and yet metastases are relatively rare.” – Bob Gatenby

- Think of people with early stage lung cancer, one can find cancer cells in their bone marrow, and yet they don’t get bone marrow metastasis
  - The same for breast cancer; a bone marrow biopsy on women getting mastectomies for apparently localized disease show breast cancer cells in their bone marrow, but all of them do not develop metastatic disease

- - Peter asks how much of that is attributed to the Allee effects and the stochastic variability that says, “Look, they’re just not going to be fit enough to take up residence there.” Versus some other inherent principle of like the genetic robustness of the tumor itself? Because a lot of those women may go on to get [adjuvant therapy](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/adjuvant-therapy); and then it becomes a question of how successful was the adjuvant therapy.
    - Yes
  - Bob uses breast cancer as an example – adjuvant therapy will reduce the probability of metastatic disease, but not eliminate it; it’s at best a small effect
    - Better adjuvant therapy is needed
    - Currently [platinum](https://en.wikipedia.org/wiki/Platinum-based_antineoplastic) or some drug is given for a period of time and that’s it
    - Why not give a sequence of drugs
    - It’s known that the population of tumor cells is small

- He *suggest taking advantage of that and optimize treatment instead of simply picking up a drug from the shelf and administering it continuously for six month*s

- - This is a good example where oncologists have not thought through the eco evolutionary dynamics of what they’re trying to treat

> “Yeah. It’s basically a paint by numbers approach, right? Which is, paint by numbers is we’re just going to do it this way, and versus “I’m going to think through this strategically”” – Peter Attia

**What is the difference between a billion cancer cells and a trillion?**

- 1 billion is 1 [cc](https://en.wikipedia.org/wiki/Cubic_centimetre)
- With more cancer cells are more mutations

- *There is not just the mass effect of more cells working against successful treatment but also increased chance of fitness by the cancer with more mutations being present*

- The diversity of the tumor ecosystem also increases with increased cell numbers

> “So you have enormous heterogeneity, within the genetic badness for lack of a smarter word.” – Peter Attia

## Defining Eco- and Evo-indices and how they can be used to make better clinical decisions [1:29:45]

- 2017 review, [Classifying the evolutionary and ecological features of neoplasms](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5811185/)
- Cancer cells accumulate random mutations
  - Occasionally a mutation provides a benefit and allows the cells to [proliferate](https://en.wikipedia.org/wiki/Cell_proliferation)

- *This line of thinking about the evolution of cancer and selection of beneficial mutations assumes a stable environment*

- Consider the environment
  - There is tremendous variation in blood flow and other factors within the tumor
  - Where there is low blood flow, the environment is totally different
  - At the edge of the tumor, cancer cells are competing with normal cells
  - Inside the tumor, cancer cells are competing with each other
- *A more evolutionary model is to realize that the different environments within the tumor are the force giving rise to different* [*phenotypes*](https://en.wikipedia.org/wiki/Phenotype)*, which in turn gives rise to different* [*genotypes*](https://en.wikipedia.org/wiki/Genotype)

> “In this case, the genes aren’t causing the evolution, the genes are the consequences of evolution.” – Bob Gatenby

**Could Darwin have written the origin of species from sequence data?**

- Consider [Darwin](https://en.wikipedia.org/wiki/Charles_Darwin), sitting on his ship with a [microarray](https://en.wikipedia.org/wiki/DNA_microarray) machine and lots of fancy molecular biology equipment
- Sailors bring him a random sample of finches, grind them up and put them through the machine
- They get billions and billions of data points

- *Could Darwin have written the “*[*Origin of Species*](https://en.wikipedia.org/wiki/On_the_Origin_of_Species)*” from that data?  No*

- - Darwin saw that the beak of the bird matched the seed it ate; there was a morphologic matching that made common sense
  - Bob remarked “ This isn’t magic. It’s just that beak’s got to be bigger to pick up that seed.”

- *Darwin paired phenotype to environment and then to environmental selection*

- - The beak could be under the control of a few genes

- *How would one distinguish these genetic changes and conclude this codes for a bigger beak so the bird must eat a big seed?*

- - Further, if the DNA sequence was analyzed for the 2 finches with beaks that were very similar (but they ate different seeds) would it be possible to extract which genetic differences accounted for the alteration of the beak?
  - This type of sequence analysis and matching it to the change in trait is very difficult

**Cancer is a disease of the genes, but it’s also more complicated**

- There has been an intense effort to characterize the genetics of tumors

- *This has some benefit but also some disadvantages, because what is lost is the morphologic matching of the environment and the traits of the cell*

- - This common sense matching Darwin had between the shape of the birds beak and the shape of the seed it ate is lost for cancer cells

- *One of the questions an evolutionary biologist likes to ask is “How many niches do you think are present in a cancer and how many species are present?”*

- - Not 1; but is is 9, 100, a million?
- Think of a tumor as a [clade](https://en.wikipedia.org/wiki/Clade) or a group that starts from a single cell; but it is spepeciating all over the place as it gets into different environments
  - Speciation isn’t magic
  - It’s not just due to a random mutation

- *Speciation is driven by environmental variations*

- - Understanding this is essential to get a handle on what the cancer is doing

**There are entirely different environmental forces in the patient, inside the tumor**

- This is why studying cancer cells outside of a patient, in culture in a dish, is entirely different
  - There’s not immune system
  - Cells don’t have to worry about [angiogenesis](https://en.wikipedia.org/wiki/Angiogenesis)
- There are differences within the tumor
  - In terms of access to substrate
  - Competing with tumor cells versus competing with normal cells

**The current literature is focused on molecular biology studies from cancer biopsies**

- Conclusions are reached such as – this came from a lung cancer so it must interact with this to do that
- But the cancer cells remaining in the body have evolved far beyond this; they are different from that original biopsy

- *So the value of these initial characterizations is unclear*

- - Bob doesn’t know if one can extrapolate results from [*in vitro*](https://en.wikipedia.org/wiki/In_vitro) studies to what is going on in the patient (*in vivo*)

- *This has made the literature on cancer very confusing*

- A connection has to be made between genetic changes and its role in the patient, [*in vivo*](https://en.wikipedia.org/wiki/In_vivo)

**Using the Evo-index as a guide to make better clinical decisions**

*How can consideration of evolution be useful clinically to make a decision?*

- How does this fit into the Evo-index?
  - The Evo-index characterizes diversity versus genetic change over time

- - With a heterogenous population, as the heterogeneity increases so does the likelihood that resistance to therapy will occur
  - Analysis of a biopsy from a patient’s tumor could give a sense of drug resistance versus non-resistance, but…
    - Now these cells have been removed
    - The tumor is going to grow and change after biopsy
    - Applying therapy alters its evolution
    - It’s changing rapidly
    - Bob compared it to a hurricane, “*whatever the data you got and day one is important for day two, but becomes less important on day three and day four and day five and ultimately then having nothing to do with it, having no predictive capacity at all for the hurricane*”

- **It’s hard to take this into account in a clinical setting**

> “ I’m sure that someone smarter than me is going to figure this out.” – Bob Gatenby

**There is a need to be careful with how data is used**

- There is a lot of interesting circulating DNA from tumor cells, but there is very little information about where these cells came from
  - Is this DNA from the losers in the evolution game?
    - Only information from winners in the evolution game is useful in treating the cancer
  - Is this data representative of all the different ranges of cells?
  - Does the distribution of data represent the distribution of populations within a tumor?
    - Bob thinks this is highly unlikely

- *Bob sees a need for imaging to look at evolution of the tumor over time*

- - It’s a non-destructive way to get data on the tumor

**There is a need to take the macroscopic-scale images from radiologic studies and bridge to the microscopic level to understand what is going on at the cellular and molecular level**

- *What tools could do this?*

- - Landscape ecologists have the technology to generate species maps from high level satellite images
    - To simplify it, they look for habitats or distinctive areas within the image
    - There are 5 types of habitats and every image is one of these 5
    - Now ecologists don’t have to go through the entire state (or large area) but just 1 of the habitats and collect data on the species distributions there
      - Then they extrapolate to the other satellite images according to what habitat they fall into

- *Applying this to cancer imaging to identify the habitats:*

- - What areas have good blood flow?
  - What areas have poor blood flow?
  - What areas have temporal variations in blood flow?
  - Is there edema?
- Tumor imaging won’t see the cells, but understanding the phenotype present in each ‘habitat’ will provide information on what the cells have to adapt to
  - This can allow one to extrapolate and think about the molecular properties of the cells

- *Perhaps imaging to identify ‘habitats’ in combination with analysis of* [*cell-free DNA*](https://en.wikipedia.org/wiki/Circulating_tumor_DNA) *from the tumors will provide the information needed to understand intra-tumor evolution during therapy*

- - This is a key piece of clinical data that is not currently available

## Advantages of early screening for cancer [1:40:15]

- There are only 6 cancers for with the [American Cancer Society](https://www.cancer.org/healthy/find-cancer-early/american-cancer-society-guidelines-for-the-early-detection-of-cancer.html#) offers a point of view  about early screening
  - The [US Preventive Services Task Force](https://www.uspreventiveservicestaskforce.org/uspstf/recommendation-topics/uspstf-and-b-recommendations) recommendations for preventative care
- Now there are more tools for early detection of cancer: better imaging, [liquid biopsies](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/liquid-biopsy), and [cell-free DNA](https://en.wikipedia.org/wiki/Circulating_free_DNA)

- *Early detection of cancer should provide a better shot at successful treatment*

- - The smaller the population of cancer cells, the more likely treatment can cause extinction
- Bob supports screening, intuitively it makes sense; but this isn’t the focus of his work and he’s not qualified to make recommendations
- Screening comes with challenges
  - Economic
  - Psychological toll of false positives

**Back to the population metaphor for looking at extinction of cancer**

- Going after a population of hunter gatherer colonies rather than the population of the USA is going to be easier; there’s a greater chance of success
  - The likelihood of extinguishing all cancer cells should be greater when the size of the cancer population is small

## Bob’s goals for follow-ups after the success of his prostate cancer trial [1:42:15]

**Why did Bob select prostate cancer for his trial**

- It has a great biomarker, PSA
- He had a very brave oncologist willing to do it, [Jingsong Zhang](https://moffitt.org/providers/jingsong-zhang/)
  - Not many oncologists are willing to “swim against the stream” and try something new
  - 2017 [publication](https://www.nature.com/articles/s41467-017-01968-5)
- After the success of this trial, there is a philanthropic fund in Europe that wants to fund a phase 3 Trial in prostate cancer
  - Otherwise there is a lot of resistance to this approach

> “It’s interesting that article that I mentioned about showing how you can eliminate the resistant cells, this morning actually, I got the 10th rejection for that article. I mean, people just don’t want to hear it.” – Bob Gatenby

**Low hanging fruit, cancers that should be easy to treat (and eliminate) using this method**

- Needs funding and interested oncologists
- Ovarian cancer has a nice marker
- Small cell lung cancer
  - An almost universally fatal disease but on that responds very well to initial therapy

- *Any tumor that responds well to initial therapy*

- - Even metastatic cancer
- Treat men with prostate cancer with androgen deprivation therapy and the [PSA](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/psa) level becomes normal or undetectable in 90% or more
  - After this, these men continue to receive the same treatment, androgen deprivation therapy
  - Even though this therapy causes total metabolic derangement – diabetes and fatty liver disease
  - The patients hat the therapy
  - Bob thinks treatment should change; when PSA normalizes additional therapies would be used, not the same therapy
    - He can’t find an oncologist interested in trying this approach
  - Bob also thinks cycling treatments would be even easier to do
    - The idea would be these men don’t have to keep taking the androgen deprivation therapy
    - Oncologists view the current therapy as different from chemotherapy but the patients are miserable

>  “To be honest, I don’t think this will be something that I’ll see in my lifetime, but I do hope that the next generation of oncologists and cancer biologists will try to at least bring this another step forward.” – Bob Gatenby

**Glioblastoma is a cancers that will be harder to treat**

- Glioblastoma can be controlled locally, but it’s the metastatic disease that cannot be controlled
- Anything in the brain is problematic because of the inability of the brain to absorb growth
- Radiation is the go-to treatment, but this introduces mutagenesis so it could accelerate the ability of cancer cells to out-compete its environment
- Glioblastoma is treated with surgery followed by radiation; very little can survive that but somehow it does
  - Bob suggested trying radiation first then surgery to see if something can be learned about how these cells change during radiation therapy
  - It’s hard to convince anyone to try this because it’s not the way it’s done
  - Surgeons don’t want to work on anything that’s been treated with radiation first
  - Bob hasn’t pushed for this because he is afraid of causing harm to the patient

**Pancreatic adenocarcinoma**

- There is a need to know more about the biology of this cancer
- Pancreatic cancers have a lot of fibrosis associated with them
  - One big question is – “is that fibrosis a host response or a tumor adaptive strategy?”
  - If it’s a host response then maybe the fibroblasts could kill off the tumor cells
    - Giving fibroblast growth factor may help the fibroblasts compete with the tumor cells for space

> “I’m just saying that with every tumor, we could ask questions, because we often don’t know really basic things about the underlying eco-evolutionary dynamics.” Bob Gatenby

- Learning more about each tumor could lead to different solutions or strategies

**Pediatric metastatic sarcoma**

- Another brave pediatric oncologist Bob works with ([Damon Reed](https://moffitt.org/providers/damon-reed/)) has started a trial for kids with metastatic sarcoma
- Rhabdomyosarcoma responds very well to chemotherapy and then comes back and kills the patient
- This disease affects teenagers, young adults; it’s very tragic
- Dr. Reed is trying an extinction therapy protocol in his trial

## Treatment options for cancer patients who have been told they have “failed therapy” [1:51:15]

- Bob and Peter hate the phrase “failed therapy”
- It’s a difficult problem and physicians are very aware of legal issues and are afraid to try something non-standard

- *It’s easier for patients who are just presenting with cancer than for those who have been through many therapies*

- Bob’s father died of esophageal cancer and he remembers the desperation and despair that comes at the end stages of disease

“Well, Bob, I have found your story really interesting and really provocative and I think the frustrating thing about what you say is that there is, in my opinion, very little downside to trying it.” – Peter Attia

- The war on cancer began with Nixon and is now in its 50th year and there’s not a lot to show for it
  - Consider the time and resources devoted to this problem
  - No one in the early 70’s, if they had a crystal ball and they were showed what cancer treatment is today would call it a success
- There has been some progress but not a lot for the metastatic cancer population
  - It’s more or less as fatal as it was 50 years ago
- It’s important to try to rethink what oncologists do
- The current approach is to keep looking for new drugs, to do the same thing over and over again

> “And certainly new drugs, no doubt, are important, but I think we could do better with the old drugs and I don’t think that we’ve been really that incentivized. I’m not sure we’ve really taken a lot of time to think about this.” – Bob Gatenby

- Intuitively it would seem like killing as many cancer cells as possible is the best approach for the patient
  - In a nonlinear system intuition is often correct but when one sees this is not true, it’s hard for everyone

> “In nonlinear systems your intuition can be very misleading and that’s true in life of which biology, especially this corner of biology, happens to be exceedingly nonlinear” – Peter Attia

§

## Selected Links / Related Material

**Article in Wired about Bob’s work to apply principles of evolution to cancer treatment**: [A Clever New Strategy for Treating Cancer, Thanks to Darwin](https://www.wired.com/story/cancer-treatment-darwin-evolution/) | (Roxanne Khamsi, *Wired* (March 25, 2019) | [2:00]

**Books about doctors who questioned current dogma to make great strides in medicine**:

- [The Doctor’s Plague](https://www.amazon.com/Doctors-Plague-Childbed-Semmelweis-Discoveries/dp/039332625X/ref=sr_1_1?dchild=1&keywords=the+doctor%27s+plague&qid=1632146077&s=books&sr=1-1) by Sherwin B. Nuland (2004) [9:45]
- [The Ghost Map](https://www.amazon.com/Ghost-Map-Londons-Terrifying-Epidemic/dp/1594482691/ref=sr_1_1?dchild=1&keywords=the+ghost+map&qid=1632146178&s=books&sr=1-1) by Steven Johnson (2007) [9:45]

**Cancer immunotherapy**: [The Drive podcast #177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers](https://peterattiamd.com/stevenrosenberg/) | host Peter Attia ([peterattiamd.com](https://peterattiamd.com/podcast/)) | [1:15:30]

**Effects of vaccination against p53 studied in humans with small cell lung cancer**: [Combination of p53 Cancer Vaccine with Chemotherapy in Patients with Extensive Stage Small Cell Lung Cancer](https://clincancerres.aacrjournals.org/content/12/3/878.long) | *Clinical Cancer Research* (SJ Antonia *et al.* 2006) | [1:18:15]

**Eco Evo-indices**: [Classifying the evolutionary and ecological features of neoplasms](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5811185/) | *Nature Reviews Cancer* (C C Maley *et al.* 2017) | [1:29:45]

**Early screening recommendations by the American Cancer Society**: [American Cancer Society Guidelines for the Early Detection of Cancer](https://www.cancer.org/healthy/find-cancer-early/american-cancer-society-guidelines-for-the-early-detection-of-cancer.html#) | August 7, 2021 (cancer.org) | [1:40:45]

**Preventative care recommendations by the U.S. Preventive Services Task Force**: [A & B Recommendations](https://www.uspreventiveservicestaskforce.org/uspstf/recommendation-topics/uspstf-and-b-recommendations) (uspreventiveservicestaskforce.org) | [1:40:45]

**Pilot clinical trial using evolution models to guide Abiraterone** **treatment of 11 men with metastatic prostate cancer**: [Integrating evolutionary dynamics into treatment of metastatic castrate-resistant prostate cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5703947/) | *Nature Communications* (J Zhang *et al.* 2017)| [41:45; 1:42:15]

**Damon Reed collaborates with Bob to treat pediatric sarcoma:** [An evolutionary framework for treating pediatric sarcomas](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7318114/) | *Cancer* (D R Reed *et al.* 2020) | [1:50:45]

**Treatment of Chronic Myelogenous Leukemia with Gleevac**: [How Imatinib Transformed Leukemia Treatment and Cancer Research](https://www.cancer.gov/research/progress/discovery/gleevec) | *National Cancer Institute: Progress: Stories of Discovery* 2018

**Applying principles of evolution to cancer treatment**: [Darwin’s Ideas on Evolution Drive a Radical New Approach to Cancer Drug Use](https://www.scientificamerican.com/article/darwins-ideas-on-evolution-drive-a-radical-new-approach-to-cancer-drug-use/) | *Scientific American* (James DeGregori and Robert Gatenby 2019)

**A review of the use of mathematical models in designing adaptive, patient-specific treatment for metastatic prostate cancer**: [The 2019 mathematical oncology roadmap](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6655440/) | *Physical Biology* (R C Rockne *et al.* 2019)

**Treatment of 4 patients with multiple drugs until PSA declines to 50% of pretreatment value**: [Towards multi-drug adaptive therapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7307613/) | *Cancer Research* (Jeffery West *et al.* 2020)

**Bob’s approach to eradicated metastatic cancers**: [Eradicating Metastatic Cancer and the Eco-Evolutionary Dynamics of Anthropocene Extinctions](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7771333/) | *Cancer Research* (R A Gatenby *et al*. 2020)

**Adaptive therapy clinical trial to treat metastatic castrate-resistant prostate cancer**: [Optimal control to reach eco-evolutionary stability in metastatic castrate-resistant prostate cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7723267/) | *PlosOne* (J Cunningham *et al.* 2020)

**A perspective on the role of genetic alterations in the evolutionary process of tumor progression**: [Characterizing the ecological and evolutionary dynamics of cancer](https://pubmed.ncbi.nlm.nih.gov/32719518/) | *Nature Genetics* (N Zahir *et al.* 2020)

**A perspective on tumor evolution discussing the interplay between genetic changes in tumor cells and the selective pressure of the microenvironment**: [Mutation-selection balance and compensatory mechanisms in tumour evolution](https://pubmed.ncbi.nlm.nih.gov/33257848/) | *Nature Reviews Genetics* (E Persi *et al.* 2020)

**Review of extinction therapy, how adaptive therapy guided by the evolutionary dynamics of the patient’s tumor can lead to improved cancer treatment**: [Integrating evolutionary dynamics into cancer therapy](https://pubmed.ncbi.nlm.nih.gov/32699310/) | *Nature Reviews Clinical Oncology* (R A Gatenby and J S Brown 2020)

**A case study treating metastatic prostate cancer with adaptive therapy**: [Toward multidrug adaptive therapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7307613/) | *Cancer Research* (J West *et al.* 2020)

**A review of evolutionarily informed strategies (adaptive, double-bind, and extinction therapies) for overcoming treatment resistance cancer**: [The Evolution and Ecology of Resistance in Cancer Therapy](https://pubmed.ncbi.nlm.nih.gov/33139405/) | *Cold Spring Harbor Perspectives in Medicine* (R A Gatenby and J S Brown 2020)

**Special collection of articles on ecological and evolutionary approaches to cancer treatment**: [Ecological and Evolutionary Approaches to Cancer Control](https://journals.sagepub.com/topic/collections-ccx/ccx-1-eeacc/ccx) | *Cancer Control* (editors C J Whelan and R A Gatenby 2020)

- **A commentary on the fundamental forces driving the formation of cancer and the role of understanding dynamic tumor microenvironment in designing treatment strategies**: [Special Collection on Ecological and Evolutionary Approaches to Cancer Control: Cancer Finds a Conceptual Home](https://journals.sagepub.com/doi/10.1177/1073274820942356) | *Cancer Control* (C J Whelan and R A Gatenby 2020)
- **New ideas for treating cancer based on lessons gleaned from Anthropocene extinctions**: [Insights From the Ecology of Information to Cancer Control](https://journals.sagepub.com/doi/full/10.1177/1073274820945980) | *Cancer Control* (CJ Whelan *et al*. 2020)
- **Lessons learned from pesticide resistance in agriculture can be applied to cancer treatment**: [Resistance is not the end: lessons from pest management](https://journals.sagepub.com/doi/full/10.1177/1073274820922543) | *Cancer Control* (C J Whelan and J J Cunningham 2020)

**Cooperation and competition as it relates to cells in a tumor**: [How Evolution Helps Us Understand Cancer and Control It](https://www.scientificamerican.com/article/how-evolution-helps-us-understand-cancer-and-control-it/) | *Scientific American* (Athena Aktipis 2021)

**Recommendations by the Oncology Think Tank (TOTT) for improved patient care**: [We Must Find Ways to Detect Cancer Much Earlier](https://www.scientificamerican.com/article/we-must-find-ways-to-detect-cancer-much-earlier/) | *Scientific American* (The Oncology Think Tank 2021)

§

## People Mentioned

- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) (famous theoretical physicist did his Ph.D. at Princeton) [3:30]
- [John Archibald Wheeler](https://en.wikipedia.org/wiki/John_Archibald_Wheeler) (famous physicist, department chair at Princeton when Bob was there as an undergrad) [3:45]
- [Edward Witten](https://en.wikipedia.org/wiki/Edward_Witten) (famous mathematical and theoretical physicist was Bob’s TA at Princeton) [4:30]
- [Judah Folkman](https://en.wikipedia.org/wiki/Judah_Folkman) (one of the first scientists to stress the importance of angiogenesis for tumor growth) [1:10:45]
- [Jingsong Zhang](https://moffitt.org/providers/jingsong-zhang/) (oncologist who worked with Bob on the prostate cancer trial) [1:42:45]
- [Damon Reed](https://moffitt.org/providers/damon-reed/)  (pediatric oncologist who used Bob’s method to treat metastatic sarcoma) [1:50:45]

§

![](https://peterattiamd.com/wp-content/uploads/2021/10/1x1-gatenby-500x500.jpg)

##### Robert Gatenby, M.D.

Robert (Bob) received a B.S.E. in Bioengineering and Mechanical Sciences from Princeton University and an M.D. from the University of Pennsylvania. He completed his residency in radiology at the University of Pennsylvania where he also served as chief resident. Bob remains an active clinical radiologist specializing in body imaging.  While working at the Fox Chase Cancer Center after residency, Bob perceived that cancer biology and oncology were awash in data but lacked coherent frameworks of understanding to organize this information and integrate new results. Reaching back to his training in engineering and physical sciences, Bob recognized that cancer was a complex dynamic system (similar, for example, to weather) and that understanding the often nonlinear interactions that govern such systems requires mathematical models and computer simulations.  As a result, most of Bob’s subsequent research has focused on exploring mathematical methods to understand the first principles and key parameters that govern cancer biology and treatment.  In 2008, Bob joined the [Moffitt Cancer Center](https://moffitt.org/research-science/researchers/robert-gatenby/) as chair of radiology and convinced the leadership to add a group of mathematicians to the faculty and form the Integrated Mathematical Oncology (IMO) department. Now numbering 8 faculty mathematicians and over 20 post docs and grad students, the IMO  has catalyzed formation of several disease-oriented teams of oncologists, surgeons, pathologists, radiologists, mathematicians, physicists, cancer biologists, imaging scientists and evolutionary biologists.   These multidisciplinary groups are investigating virtually every aspect of cancer biology and therapy. In fact, IMO members are co-PIs of two ongoing clinical trials that use evolutionary dynamics and computational models to guide therapy. There is no other cancer center in the world that has so completely integrated mathematical modeling and computer simulations into basic science and clinical research.