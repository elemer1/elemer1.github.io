# #158 – Brian Deer: A tale of scientific fraud—exposing Andrew Wakefield and the origin of the belief that vaccines cause autism

**Source:** [https://peterattiamd.com/briandeer/](https://peterattiamd.com/briandeer/)

---

Brian Deer is an award-winning investigative journalist best known for his coverage of the pharmaceutical industry. In this episode, he and Peter discuss the content of his book, [*The Doctor Who Fooled the World: Science, Deception, and the War on Vaccines*](https://www.amazon.com/Doctor-Who-Fooled-World-Deception/dp/1421438003), which exposes the complex and disturbing story behind the infamous 1998 Lancet paper by Andrew Wakefield linking the MMR vaccine and autism. Brian explains how doctors led by Wakefield, a lawyer, and an anti-vaccination parents’ group worked together on a study to validate their preconceived belief that the MMR vaccine caused autism. He reveals what happened behind the scenes as the study was carried out, explains problems in the lab, and discusses inconsistencies in the analysis.  In the end, this is a story that serves as a cautionary tale about the consequences of science driven by an agenda rather than by a spirit of open inquiry.

\*[WATCH PODCAST ON YOUTUBE](https://www.youtube.com/watch?v=icJtTHgR_Ds)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/briandeer/the_Drive_public.png)

Play

#158 - Brian Deer: A tale of scientific fraud—exposing Andrew Wakefield and the origin of the belief that vaccines cause autism

#158 - Brian Deer: A tale of scientific fraud—exposing Andrew Wakefield and the origin of the belief that vaccines cause autism

1x15s30s

0:001:49:38

## We discuss:

- How Andrew Wakefield’s flawed approach to scientific research led to the belief that vaccines cause autism (3:25);
- The importance of following the scientific method, and how Wakefield twisted the science to link measles virus to Crohn’s disease (14:15);
- The backstory behind Andrew Wakefield’s infamous 1998 Lancet paper linking the MMR vaccine and autism (26:45);
- The many flaws and disturbing aspects of Wakefield’s study: suffering children and failure to do strain-specific sequencing (45:15);
- The epicenter of fraud: Bogus PCR testing furthering the belief that measles virus from the MMR vaccine caused autism (1:00:00);
- Additional issues that contaminated the study results (1:22:15);
- Discovering the misrepresented medical records for the kids involved in the study leading to the retraction of the Lancet paper and Wakefield losing his license (1:31:00);
- The resurgence of the anti-vaccination movement, Brian’s motivation to write the book, and parting thoughts (1:36:45); and
- More.

§

## Show Notes

## How Andrew Wakefield’s flawed approach to scientific research led to the belief that vaccines cause autism [3:25]

- This is not just a discussion about vaccines but also about fraud in science
- Vaccines can be a polarizing issue, but it’s important to get to the bottom of the story
- Peter reached out to Brian after reading his book, [*The Doctor Who Fooled the World: Science, Deception, and the War on Vaccines*](https://www.amazon.com/Doctor-Who-Fooled-World-Deception/dp/1421438003), twice

> “I believe too many people enjoy the convenience of opinion without the inconvenience of thought.” —Peter Attia

**Andrew Wakefield**

- To understand the origin of the belief that    c, one must understand the work of [Andrew Wakefield](https://en.wikipedia.org/wiki/Andrew_Wakefield)
  - Peter urges listeners to read Brian’s [book](https://www.amazon.com/Doctor-Who-Fooled-World-Deception/dp/1421438003) in addition to the podcast
  - In [some countries](https://www.statista.com/statistics/790868/people-who-believed-vaccines-cause-autism-worldwide-select-countries/) many people believe that autism is likely or probably caused by vaccines
    - And it’s [not an uncommon](https://www.usnews.com/news/healthiest-communities/articles/2020-01-14/survey-fewer-people-now-support-vaccinating-their-kids-than-in-2001) belief in US
    - Though Brian says [not so much in the UK](https://www.epmmagazine.com/news/majority-of-uk-public-dont-believe-vaccines-cause-autism/) anymore
  - Idea that vaccines might cause autism became prominent in early 1990s
  - Before Brian’s book, Peter assumed Andrew Wakefield was “a misguided and not particularly competent physician,” but now he realizes that it goes well beyond that
- Brian wanted to follow the arc of Wakefield’s development and planned to give him the benefit of the doubt in his early years
  - Wakefield went to Canada and started training in surgery in late 1980s, but despite a long-term goal to be a surgeon for unknown reasons he “moved very quickly” away from surgery into research
  - Brian didn’t find the story of a good guy who was misguided but rather of a guy who became obsessed with an idea that he strangely latched onto and refused to let go
- In Toronto where he trained, they were investigating bowel transplants to treat [Crohn’s disease](https://en.wikipedia.org/wiki/Crohn%27s_disease) (“an appalling, ulcerating, blistering, burning” bowel disease of unknown origin)
  - Theory was that it was an allergic reaction inside the gut, but Wakefield wondered if it could instead be a disease of the gut blood supply caused by an infectious agent
  - This was the late 1980s when AIDS and infectious agents were in the news
- Wakefield got a job in London at a “third rate” hospital, Royal Free in Hampstead North London
  - Was still on payroll of [Wellcome Trust](https://wellcome.org/), which today is a great health-related charity that has enhanced the UK’s coronavirus response, but then was the grant-branching arm of a pharmaceutical company
  - Wakefield knew the funding would eventually go to the med school and wanted to use funding for his Crohn’s idea while he could
- Wakefield went through a two-volume encyclopedia of viruses called [*Fields Virology*](https://www.amazon.com/Fields-Virology-Knipe-2-Set/dp/1451105630) and saw that acute measles can be found in the intestines, so he decided to focus on measles
  - In Crohn’s disease, get little ulcers in the gut
  - In measles, see [Koplik’s spots](https://en.wikipedia.org/wiki/Koplik%27s_spots#:~:text=Koplik's%20spots%20(also%20Koplik's%20sign,and%20are%20pathognomonic%20for%20measles.)
  - So he concluded that measles was the cause of Crohn’s disease
  - However, during infection, measles is found everywhere in the body, not just the gut
  - But Wakefield decided to “prove” that measles caused Crohn’s disease
- Wakefield had a surgeon’s mindset rather than a researcher’s mentality

> “In science, courage isn’t about proving yourself right, it’s in your efforts to prove yourself wrong. . .to try and refute your own hypothesis.” —Brian Deer

- In science you must start with a hypothesis and then collect data about it in a way that tries to disprove it
  - Wakefield never did second step; never doubted or questioned his ideas
  - This is “an extraordinary flaw of character,” especially in a scientist

## The importance of following the scientific method, and how Wakefield twisted the science to link measles virus to Crohn’s disease [14:15]

- Peter says Wakefield’s approach reminds him [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) saying something like “the first principle in science is not to fool yourself”
  - Even the word “proof” is loaded in science
  - You look at a body of experiments and ascertain which way the evidence points
- Peter says it’s not just surgeons but doctors in general who don’t get a lot of training in the scientific method
  - Those who do research get it
  - but not so much in med school generally, where you learn a bit of the history and science and a lot of facts but not really about the scientific method
- Scientific method: generate a hypothesis, figure out what the right questions are, design experiments to test it, look critically for all the ways you could be fooled
  - Peter says it’s hard to learn without good mentoring in a lab
  - Brian says medicine is like a European learning Chinese – you don’t question what you’re taught, you just learn it
- Wakefield’s favorite word was “consistent”: this particular finding or data point was consistent with his hypothesis
  - But consistent means nothing: could say orbit of Mercury is consistent with [inflammatory bowel disease](https://en.wikipedia.org/wiki/Inflammatory_bowel_disease) (IBD), or consistent with Peter and Brian talking
  - Peter says it’s similar to saying “associated with,” which means nothing
  - Being “consistent” doesn’t prove the hypothesis
  - Wakefield “never stopped to question at any stage, or to carry out any experiment, or research, or anything that would conflict with that commitment to the idea that measles virus was the cause of Crohn’s disease”
- Wakefield used [immunohistochemistry](https://en.wikipedia.org/wiki/Immunohistochemistry), a microscopic staining technique
  - Take tissue sample, use antibodies to stain it in a certain way, then look under a microscope
  - Will change color if sample has antigen you stained for
- [Polymerase chain reaction](https://en.wikipedia.org/wiki/Polymerase_chain_reaction) (PCR) technique: when this technique was used, could not find measles in Wakefield’s study samples
  - Wakefield said PCR wasn’t sensitive enough, which made the American undergraduate students Brian told this story to laugh
  - Doesn’t make sense to suggest you could find something under a microscope that you cannot find at a molecular level
- In 1993, Wakefield published a [paper](https://onlinelibrary.wiley.com/doi/abs/10.1002/jmv.1890390415) in the [*Journal of Virology*](https://jvi.asm.org/)
  - Said he found measles in gut biopsies using immunohistochemistry
  - Two years later a Japanese group [could not replicate](https://pubmed.ncbi.nlm.nih.gov/7741861/) his findings using PCR
  - Wakefield’s best defense would be to say it could have been an artifact or a contamination, maybe assay wasn’t done correctly or didn’t have the right controls
  - Measles causing Crohn’s would have been a big deal scientifically
- PCR was becoming the gold standard around the mid-90s
- Gastroenterology is a specialty field where a lot of people know each other
  - Some suspected Wakefield was incompetent because it looked like he had inappropriate controls
  - A few, like [Tom MacDonald](https://experts.webapps.qmul.ac.uk/expert.php?id=134), who is now at St. Bartholomew’s Hospital / Queen Mary University of London, suspected fraud even back then
  - Brian glossed over it because he didn’t want to talk about fraud too soon in the book
  - MacDonald turned down a good job offer to avoid going to Hampstead because Wakefield was working at the time
- Wakefield said he’d seen the measles virus under an electron microscope

> “Doctors … are very reluctant to come to the conclusion that somebody is dishonest as opposed to wrong. … And that’s understandable. You want to give people the benefit of the doubt.” —Brian Deer

- Wakefield dismissed those who found different results and said they didn’t know what they were doing
  - makes no sense to say viral levels were below the threshold of detection by PCR, but not below the level of detection by microscopic immunohistochemistry techniques
  - Peter says “it’s like saying I can see the details on the moon with my naked eye, but I can’t see them with the most high-powered telescope because the resolution isn’t good enough”
  - Then claiming it’s not a good telescope or you don’t know how to use it properly or lens is not good enough

## The backstory behind Andrew Wakefield’s infamous 1998 Lancet paper linking the MMR vaccine and autism [26:45]

- The *Lancet* is probably in the top 5 scientific journals in the world
  - Wakefield’s [paper](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(97)11096-0/fulltext) was essentially a poorly done report on 12 patients who were not recruited at random
  - Peter says “it’s outright amazing that the *Lancet* published it in the first place, let alone took so long to basically pull it”
- At the time, the incidence of Crohn’s disease was rising and measles was in decline because of the advent of vaccination (although this is no longer true)
  - The vaccine contained live measles virus
  - So Wakefield modified his theory to say that vaccines were linked to Crohn’s disease
- [Richard Barr](https://en.wikipedia.org/wiki/MMR_vaccine_and_autism) and Wakefield join forces
  - Barr was an obscure British lawyer
  - Got a contract with a British government agency to try to show that the MMR vaccine was the cause of developmental issues, particularly autism
  - Needed to find a doctor who would support his work, but couldn’t find one because it was a fringe idea
  - In 1996, hired Wakefield “at very generous hourly rates” even though he lacked professional expertise
- How Barr picked autism
  - Woman named [Jackie Fletcher](https://briandeer.com/wakefield/jackie-fletcher-jabs.htm) had a son who developed serious neurological illness a few weeks after getting MMR vaccine
  - Got the idea from other parents that vaccines might be the cause of her son’s condition (but he had an intellectual disability, not autism)
  - Couldn’t sue unless lots of other potential plaintiffs too because would need government support to fund a lawsuit
  - Joined with Barr and Wakefield
- Autism is a construct
  - Symptoms have been observed for hundreds of years, long before MMR
  - Now “it’s a tick-box diagnosis of different signs and symptoms” clustered together
  - As with [schizophrenia](https://en.wikipedia.org/wiki/Schizophrenia), the definition is malleable
  - Rates of schizophrenia decreased as autism increased
  - Both were emerging diagnoses in the early 1990s: the [American Medical Association](https://en.wikipedia.org/wiki/American_Medical_Association) and [World Health Organization](https://en.wikipedia.org/wiki/World_Health_Organization) identified a spectrum of disorders including autism
- Fletcher formed a group and began to survey other parents
  - As a newly emergent diagnostic category, autism was prevalent and can be clustered, so focused on that diagnosis
  - MMR vaccine had been introduced in the UK, so fit together
- Barr and Wakefield applied for a grant from the government-run Legal Aid Board, which would fund a lawsuit for people who couldn’t afford to do it on their own
  - In preparation for a lawsuit, Wakefield had been gathering clients and anecdotes
- This scheme was the origin of the modern anti-vaccination movement and was the “acorn” that grew into today’s anti-coronavirus vaccine arguments
- The agreement was that Wakefield would do the medical tests, Barr would get money for the legal case, and Jackie Fletcher would recruit clients/patients
- Fletcher founded an anti-vaccine organization called [JABS](https://www.jabs.org.uk/) [Justice, Awareness, and Basic Support] and recruited clients for the lawsuit

**A “scientific” study funded by lawyers [36:45]**

- They proposed to the Legal Aid Board that they would show that there was a new syndrome which included both inflammatory bowel disease and autism
  - This proposal was made before any of the patients in the study had been seen at the hospital
  - Legal Aid agreed to fund Wakefield’s research that became the infamous 1998 paper
- Brian points out that he is the one who unmasked this

“And that’s one of the extraordinary things about this story, that the medical establishment just kind of sat back and let all this go on and it appeared that only a journalist spotted the grounds to believe there was something funny going on here.” —Brian Deer

- Wakefield’s [paper](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(97)11096-0/fulltext) is published in *The Lancet* in February 1998
- Approximate ranking of the top general medicine journals is *New England Journal of Medicine*, *The Lancet*, *Journal of the American Medical Association*, *Annals of Internal Medicine*, *British Medical Journal*
- Paper was a case series of 12 children
  - Deer says the paper seemed credible at the time and doesn’t agree with Peter that it was so obvious it was bad at the time of publication
  - A [case series](https://en.wikipedia.org/wiki/Case_series)  is a collection of anecdotes
    - Crohn’s disease (1930s, 14 patients), autism (11 children), and [AIDS](https://en.wikipedia.org/wiki/HIV/AIDS) (1981, 5 patients) were first described in a case series
    - “So there’s nothing questionable or improper or inadequate about a case series of 12 children”
- An [institutional review board](https://en.wikipedia.org/wiki/Institutional_review_board) (IRB) had not approved the protocol the children went through, but the paper falsely claimed that the study had IRB approval
- Brian says he is not on a “pro-vaccine campaign” but was motivated by concerns about the scientific method
  - “One of the things that really bugs me is people who believe they can judge research by a text on a piece of paper or on a screen. And you can’t”
  - people use the word study and paper interchangeably
- He doesn’t think another journalist has ever gone “around the back of the paper” to investigate all of the details on the study subjects: diagnoses, histories, test results, etc.
- How subjects were recruited
  - At face value, it appeared that parents brought their children to the hospital’s pediatric bowel clinic and said their children had been developing normally until receiving the MMR vaccine
  - 11 boys, one girl, all white
  - Parents of 8 of the 12 children said the first symptoms of their child’s developmental issue (mostly autism) appeared within 14 days of receiving the MMR vaccine
  - “If that was true then that could be potentially the first snapshot of a hidden epidemic of catastrophic injuries to children” that also could be happening elsewhere without being noticed
- After the paper came out, the hospital and medical school held a press conference and it got widespread media coverage
  - Man who hired Wakefield from Canada was present, seemed important
  - “There had been leaks and promotional things that had been done to attract more and more attention to this thing. They absolutely knew what they were doing”
  - Bought extra phone lines and answering machines to handle “the public alarm that they knew they were going to create and this hospital”

## The many flaws and disturbing aspects of Wakefield’s study: suffering children and failure to do strain-specific sequencing [45:15]

**The suffering of the children in the study**

- The Legal Aid Board knew in advance what procedures the children would go through
- Also significant that many of the children were autistic: “These are the kind of children who the slightest variation in some cases to their routine will cause them great distress”
- Nearest family was 60 miles away, one came from the US
  - Peter says this clearly shows that these weren’t just kids being seen in this hospital as part of the routine caseload
- For children who are traumatized by any disruption, this was the procedure:
  - Interview parent
  - Bowel studies
    - Prep bowel for ileocolonoscopy
    - [Colonoscopy](https://en.wikipedia.org/wiki/Colonoscopy): go in through the anus, up through the sigmoid colon, up the descending colon, across the transverse colon, down the ascending colon to the cecum, which is pretty much where the appendix is
      - Then for ileocolonoscopy, also go through valve that separates the large bowel from the small bowel
      - The distal section of the small intestine is the [ileum](https://en.wikipedia.org/wiki/Ileum)
      - [Small intestine](https://en.wikipedia.org/wiki/Small_intestine) extracts nutrition from food while [large bowel](https://en.wikipedia.org/wiki/Large_intestine) extracts water
      - difficult maneuver to get into the small intestine
    - Later in the series a child suffered catastrophic damage caused from this procedure and there was a huge financial settlement from the hospital
    - Some of them also had upper [endoscopies](https://en.wikipedia.org/wiki/Endoscopy), putting a tube down the throat to look around in the [duodenum](https://en.wikipedia.org/wiki/Duodenum)
  - Then most kids also had [lumbar punctures](https://en.wikipedia.org/wiki/Lumbar_puncture) (spinal taps), in which a needle is pushed into the space around the base of the spine to extract a sample of [cerebrospinal fluid](https://en.wikipedia.org/wiki/Cerebrospinal_fluid)
  - They also underwent [MRI scans](https://en.wikipedia.org/wiki/Magnetic_resonance_imaging), [electroencephalograms](https://en.wikipedia.org/wiki/Electroencephalography) (EEGs), a [barium meal](https://en.wikipedia.org/wiki/Upper_gastrointestinal_series) (drink a barium drink and then x-rayed to get an image of the gut), and [drawing blood](https://en.wikipedia.org/wiki/Venipuncture) for laboratory tests
- Caused trauma to kids
  - Many of the kids required 3 people to hold them down
    - Wakefield sued Deer for saying that the children were being held down by three people, but they were
  - one child collapsed three times in the corridor
  - one had to be admitted to another hospital after discharge from the effects of the LP
  - another required an emergency home visit from a doctor
- Because many of the children were very constipated, their bowel preps and colonoscopies were very difficult
  - Ironically, given their constipation, they were extremely unlikely to have Crohn’s disease
  - Clinicians had published a panel of blood tests used to determine whether an ileocolonoscopy was indicated, but they did them on these children even though the blood tests were normal
  - Wakefield said that there might be lesser inflammation that wasn’t being picked up by the blood test
  - He had told the Legal Aid Board that the children had bowel disease before he did the research

**Problems with sample analysis (51:30)**

- [John O’Leary](https://briandeer.com/mmr/oleary-pcr.htm) was the pathologist for the study
- Crohn’s disease can be anywhere in the digestive tract but usually in ileum
  - Wakefield wanted to establish the presence of live measles virus in the ileum years after vaccination
  - Planned to scope constipated kids until got a tissue sample from the small intestine (one mother refused after second try)
- Scopes were done by doctors named [Simon Murch](https://www.thelancet.com/journals/lancet/article/PIIS0140673604157085/fulltext) and [Mike Thomson](https://www.paediatricgastroenterologist.co.uk/index.php/about) [53:30]
- Also took biopsy tissue samples along length of large intestine
  - A PhD student ([Nick Chadwick](https://centerforinquiry.org/wp-content/uploads/sites/33/quackwatch/QQ_Chadwick_Declaration_98-916.pdf)) took samples to freeze in liquid nitrogen to test for measles using PCR
  - He developed a gold standard PCR test for measles virus
  - Did not find measles in any of the samples, which is when Wakefield said it wasn’t sensitive enough
- But had to do PCR because had told the Legal Aid Board that they would do PCR for **strain-specific sequencing**
  - three ways to get measles:
    - catch it from someone
    - get it from a laboratory strain (a particular strain kept for laboratory work)
    - from the vaccine
  - can’t tell which from immunohistochemistry, must sequence the nucleotides
  - Peter says think of it as immunohistochemistry can recognize that there’s a person there while PCR can fingerprint the person
- Wakefield wasn’t looking for evidence that he was wrong, just wanted to prove he was right
- “He’d set out what it was he was going to find in his grant application before a single one of these children went anywhere near the hospital”

**An inadequate grant application (57:30)**

- Peter remembers Brian pointing out in the book that there was a lack of rigor in Wakefield’s grant application
- When Peter wrote his first grant application for a summer med school project, a Stanford scientist named [Pat Brown](https://en.wikipedia.org/wiki/Patrick_O._Brown) told him frankly how “pathetic” it was
  - Peter was a first-year med student and didn’t understand the scientific method
  - Someone like Pat Brown would have doubted Wakefield’s abilities to do the research
  - Shows a lack of self-auditing and self-policing
  - Wakefield’s grant was authorized by a young lawyer with no scientific background

## The epicenter of fraud: Bogus PCR testing furthering the belief that measles virus from the MMR vaccine caused autism [1:00:00]

- After finding no measles, Wakefield asked John O’Leary if he could use his PCR equipment
  - O’Leary worked at an Irish maternity hospital
  - Was paid a lot of public money and published a paper claiming that he found measles virus in nearly all the of Wakefield’s samples
  - Peter says he views O’Leary’s lab as the “epicenter of the epicenter of the fraud”
- Must understand PCR to understand what happened in O’Leary’s lab
  - It’s hard to describe molecular amplification, but it’s being done all over the world now to test for coronavirus
  - PCR also used in crime scenes – for example, to test of a drop of blood is from a particular person
  - [Kary Mullis](https://en.wikipedia.org/wiki/Kary_Mullis) shared the 1993 Nobel Prize in Chemistry for developing the PCR technique
  - Brian says it began it with the discovery of a [polymerase](https://en.wikipedia.org/wiki/Polymerase) in Yellowstone National Park
- A polymerase is an enzyme that [catalyzes](https://en.wikipedia.org/wiki/Catalysis) a reaction
  - When a double strand of DNA replicates, need to break apart the strand and then make another template of each half
  - Enzymes both break it part and replicate it
  - DNA’s code is 4 letters and each pairs with another
  - Can be used to 1) duplicate a strand or to break it apart and 2) make single-stranded [messenger RNA](https://en.wikipedia.org/wiki/Messenger_RNA) (mRNA), which carries the message to make a protein
  - polymerase enzymes facilitate both processes
- Classic double helix of DNA is like a ladder joined together
  - PCR machine heats up test tubes with samples and controls
  - As it heats up, ladders split apart
  - In the case of measles, have a preliminary step called [reverse transcription](https://en.wikipedia.org/wiki/Reverse_transcription_polymerase_chain_reaction) because RNA is single stranded but need two strands
  - a second strand is created synthetically and the result is [cDNA](https://en.wikipedia.org/wiki/Complementary_DNA), an artificial construct of DNA
- The polymerase enzyme goes along the broken rungs of the ladder and creates a complementary second ladder
  - “So for each of the points rungs on the ladder, it creates another one which joins to it. And these are the nucleotides, the base nucleotides, the fundamental building blocks of life”
  - Now have two double-stranded samples which are cooled, come together and solidify
  - Repeat and get 4, and then 8, then 16, etc. so increases rapidly and now enough to detect
- Machine reads it with primers and probes
  - Primers: mark a slice of specific “nucleotide bookends”
  - Probes: light up fluorescently if target is present
- A laser is taking measurements by the millisecond
  - signal is recorded on a computer, generating a curve that starts flat and then rises and [asymptotes](https://en.wikipedia.org/wiki/Asymptote) flat again
  - roughly an S shape
  - take a reading before it goes flat (at about 35 cycles, which means 235 copies)
- Automated kit was called TaqMan because of [Taq polymerase](https://en.wikipedia.org/wiki/Taq_polymerase)
- Process was called real-time quantified PCR

![](https://peterattiamd.com/wp-content/uploads/2021/04/PCR-briandeer-1024x546.png)

**Figure 1: Visual representation of PCR.** Image credit: [Encyclopedia Britannica](https://www.britannica.com/science/polymerase-chain-reaction)

“It was literally as simple as a Betty Crocker cooking exercise where you put in your primers, you put in your probes, you put in your Taq, you put in your sample, and the machine would go through everything … and it would spit out for you the information of what’s present and how much of it is present.” —Brian Deer

- You can go up to 35 cycles, but if you start with a large amount of nuclear material, you’ll see it much sooner
  - these tests are really geared for their [negative predictive value](https://en.wikipedia.org/wiki/Positive_and_negative_predictive_values) more than their [positive predictive value](https://en.wikipedia.org/wiki/Positive_and_negative_predictive_values)
  - need to report how many cycles are necessary to get a positive test because it matters how many cycles it takes; big difference in resolution

**Suspicious findings in John O’Leary’s lab [1:10:15]**

- O’Leary was essentially paid to find something
- He was using a state-of-the-art machine, the [ABI PRISM 7700](https://tools.thermofisher.com/content/sfs/manuals/4316192.pdf)
  - No [CLIA certification](https://www.fda.gov/medical-devices/ivd-regulatory-assistance/clinical-laboratory-improvement-amendments-clia) – for research only, not clinical diagnoses
  - Both the manufacturer and [Tony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci) use 35 cycles as a limit
  - once you go past 35 where the rising line asymptote goes flat, what you are seeking either isn’t there or you’ve done something wrong and you need to start again
  - “the apparent simplicity is beguiling and misleading”
- Peter says it wasn’t as simple in 1998 and you can still be fooled by the machine
  - it’s a research tool and not a clinical instrument because of potential for error
  - technology is so sensitive that it’s easy to become contaminated
  - If you’re getting signals after 35 cycles it’s probably contamination
- How is this different from PCR testing for coronavirus?
  - Using a clinical grade PCR assay, which is under far greater regulatory scrutiny and is far more standardized then a research type
  - even under those conditions, the test is far better at demonstrating something is negative than positive: much greater negative predictive value
    - When the test comes back negative it’s with more than 99% certainty truly negative
    - When it comes back positive, not sure it’s positive
    - If patient not symptomatic, test again
    - In Peter’s practice had three false positives on PCR that were later found to be negative
- Richard Barr hired John O’Leary at Wakefield’s recommendation
- O’Leary reported finding measles virus in about 9 out of 10 children
  - Was that measles virus from nature, a lab strain, or from MMR?
  - Labs usually have plasmid room where they prepare materials
  - Would need to sequence virus found in samples to make sure it’s not the lab strain
- Another kind of machine called a sequencer (now called a capillary sequencer) can identify the individual nucleotides
  - DNA nucleotides have the acronyms A, G, C and T
  - For RNA, they are A, G, C, and U
- O’Leary presented himself as an independent researcher, but he had multiple business deals with Wakefield
  - Said he had a sequencer but never produced any sequenced data for the samples from Wakefield’s study
  - Not sequencing has significant consequences because it means you can’t identify where the virus came from
  - Though the legal case cost about $100 million between the two parties, it never came to trial because they never produced any sequence data
- Yet parents around the world had been told that measles virus from the MMR vaccine had been found in samples from the kids in the study
  - Brian says, “That to me is the most extraordinary indictment of these people”
  - In [*The Sunday Times*](https://en.wikipedia.org/wiki/The_Sunday_Times), Deer exposed the fact that the kids in the study were not routine patients but a preselected group of children whose parents wanted to join the lawsuit
- They had a medical board hearing where children’s medical records were disclosed
- Deer says it was a scam
- they weren’t arrested because they can say they believe the MMR vaccines causes autism, but Deer says it’s like the Mafia claiming that they’re the good guys

“They were able to manufacture the belief that the MMR vaccine causes autism. And the consequence of that is that there are … probably hundreds of thousands of families around the world today who’ve been led to believe that their child … was injured as a result of the parents’ own decision to vaccinate them.” —Brian Deer

- These ideas grew the anti-vaccine movement today, which pumps out misinformation on the web and social media about coronavirus
- The parents who believe a vaccine harmed their child “have become mobilized in the belief they need to identify an alternative culprit to themselves”
  - They are not at fault
  - but they “have learned to deflect and project onto others” and allege a conspiracy to promote vaccines

## Additional issues that contaminated the study results [1:22:15]

**Problems with formalin samples in the lab**

- Tissue samples from children in the study went to two places:
  - [Nick Chadwick](https://centerforinquiry.org/wp-content/uploads/sites/33/quackwatch/QQ_Chadwick_Declaration_98-916.pdf), a PhD student working with Wakefield
    - Chadwick has since left science, perhaps because this fiasco left him disillusioned)
    - Froze samples in liquid nitrogen, which would preserve virus
  - Other samples were sent to hospital’s pathology department
    - [Histopathology](https://en.wikipedia.org/wiki/Histopathology): stain samples and examine under microscope
    - Fixed in formalin (the liquid form of [formaldehyde](https://en.wikipedia.org/wiki/Formaldehyde#Forms_of_formaldehyde)), a preservative that tends to degrade the nucleic acids
- If run PCR on formalin samples, need more cycles to get same results
  - Virus detected more much quickly in a frozen sample than one fixed in formalin
- Brian says his work has less to do with promoting vaccines than with the questions about science that are behind it, which impacts much more than just vaccines
- Pharmaceutical companies have money to pay for lawyers and scientific testing and hired Britain’s top expert on PCR technology ([Steve Bustin](https://en.wikipedia.org/wiki/Stephen_Bustin))

***So what happened in O’Leary’s lab?***

- Bustin found that it had taken the same amount of cycles to get results on the frozen and formalin-fixed samples
- The only explanation for this is that **the virus got into the samples after they were fixed in formalin and this did NOT come from the children**
- “*The most gracious explanation is that this was purely a laboratory contamination, a less gracious interpretation is that it was deliberately falsified*”
- Bustin also looked at the individual wells
  - 96 wells per tray: some had the samples being tested, some had controls with a laboratory strain of measles, some distilled water, and some empty
  - O’Leary refused to disclose the data from the wells (made up repeated excuses) and companies had to go to the British and Irish High Courts to force him to turn over the data
    - Bustin found that wells that had been reported by the machine to be positive for measles virus were in fact submitted in legal papers as being an empty well
    - wells that were empty were reported positive
  - In Bustin’s analysis, there had been **manual human intervention to adjust the results** coming from the machine implying that someone had changed the data to get the desired results
    - When Enron’s accounting firm manipulated its books to deceive shareholders, [some executives went to jail](https://en.wikipedia.org/wiki/Enron_scandal)
    - Volkswagen faced consequences for [rigging the recordings](https://en.wikipedia.org/wiki/Volkswagen_emissions_scandal) of fuel emissions from its cars
    - Peter says this seems just as nefarious as those examples; it’s more than corporate incompetence

## Discovering the misrepresented medical records for the kids involved in the study leading to the retraction of the Lancet paper and Wakefield losing his license [1:31:00]

- There were discrepancies between the children’s medical records and what was reported in the paper
- Wakefield initiated a lawsuit against Brian Deer and a British television network ([Channel 4](https://www.channel4.com/)) over an [episode](https://www.youtube.com/watch?v=7UbL8opM6TM) of the TV news show [*Dispatches*](https://www.channel4.com/collection/dispatches) that was about Wakefield, but he then stayed (froze) the lawsuit
  - Deer and company took him to court to force him to sue
  - Deer got access to the children’s medical records and other documents through the legal disclosure process
- “There was not a single one of those 12 children whose cases were accurately reported in that paper”
  - Some kids had developmental issues before the vaccine
  - Others developed symptoms much later than 14 days after the vaccine, sometimes many months later
  - The first patient recruited by Jackie Fletcher admitted that her child did not have symptoms for 9 months after the vaccine (she had said 14 days at the hospital)
  - Some kids were listed as having an autism diagnosis but did not
  - So both diagnoses and time of symptom onset had been changed
  - “there was nothing in that paper that could be reconciled with the actual children’s diagnosis, records, histories, laboratory and blood tests at all”
- Medical board hearing
  - Deer was reading the kids’ records pursuant to a court order in UK, couldn’t reveal what he’d learned until the records were exposed at the medical board hearing
  - Hearing lasted for 217 days (comparable in length to the [O.J. Simpson trial](https://en.wikipedia.org/wiki/O._J._Simpson_murder_case))
  - Eventually [Wakefield lost his license](https://www.nytimes.com/2010/05/25/health/policy/25autism.html) and the *Lancet* [retracted](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(10)60175-4/fulltext) the 1998 paper [1:35:30]
  - The medical board hearing cost about £10 million
- The [*British Medical Journal*](https://www.bmj.com/) asked Deer to do a [series of reports](https://briandeer.com/solved/bmj-secrets-series.htm) on the Wakefield scandal
- Funded by New York financiers [Bernard](https://en.wikipedia.org/wiki/Bernard_Selz) [and Lisa Seltz](https://www.washingtonpost.com/national/health-science/meet-the-new-york-couple-donating-millions-to-the-anti-vax-movement/2019/06/18/9d791bcc-8e28-11e9-b08e-cfd89bd36d4e_story.html), Wakefield sued Deer and *BMJ* in Texas, but the case was thrown out
  - Documents that had been sealed by British courts became available for Deer to use in *The Doctor Who Fooled the World*

## The resurgence of the anti-vaccination movement, Brian’s motivation to write the book, and parting thoughts [1:36:45]

- People ask Brian about the [CDC whistleblower](https://www.forbes.com/sites/emilywillingham/2015/08/06/a-congressman-a-cdc-whisteblower-and-an-autism-tempest-in-a-trashcan/?sh=65a9f93c5396) and Wakefield’s movie [*Vaxxed*](https://vaxxedthemovie.com/) and the rebirth of the anti-vaccine movement
  - But Wakefield had a comeback, as Brian describes in the fourth part of his book
  - The first part is Big Ideas, the second part is Secret Schemes, the third part is Exposed and the fourth part is Avenged
- Wakefield falsely claimed that a researcher at the CDC had accused his colleagues of fraud

- Peter asks if Brian thinks that Andrew Wakefield will ever agree to sit for an interview with Peter
  - Brian says Wakefield will only sit down for an interview with somebody he knows will not ask difficult questions, and he will give dishonest answers
    - For example, he says he was not involved in the lawsuit until after the children were seen at the hospital, which is a lie

**The anti-vaccine mentality**

Peter reads Brian some quotes from a 2011 [article](https://pubmed.ncbi.nlm.nih.gov/21226573/) in *The* *New England Journal of Medicine* called *The age-old struggle against the anti-vaccinationists*:

- *“This has been an issue that’s existed since the 19th century, but now the anti-vaccinationists’ media of choice are typically television and the internet, including social media outlets, which are used to sway public opinion and distract attention from scientific evidence”*

The editorial also says that anti-vaccinationists

- *“tend toward complete mistrust of government and manufacturers, conspiratorial thinking, denialism, low cognitive complexity in thinking patterns, reasoning flaws, and a habit of substituting emotional anecdotes for data, including people who range from those unable to understand and incorporate the concepts of risk and probability into science grounded decision-making and those who use deliberate mistruths, intimidation, falsified data, and even the threats of violence”*

- Peter asks Brian if this is too harsh, but Brian says it’s absolutely right
- Brian observes that the person who wrote this “static prose exposition” is likely educated and experienced
- The author is *telling* you something from a position of knowledge

**Why Brian wrote the book**

- In his book, Brian tried to tell the story as a narrative “to *show* people the real characters behind this and the specific facts of how they did it”

“If he could do what he did, and I show you what he did, who else is doing what in the hospitals and laboratories that we may one day look to for our lives? … And that’s really the message behind the whole thing.” —Brian Deer

- Deer’s goal was not to convince people to vaccinate their children and he doesn’t accept endorsements of his book from vaccine manufacturers
- He wanted people to understand that if Wakefield could do this for so long, many others could be doing similar things that we don’t know about in hospitals and labs, and that’s why the story is so important
  - Wakefield got caught because vaccination is high profile – it affects everyone’s children
- All of Brian’s work on Wakefield took a long time to research, his book was scrutinized by libel lawyers and other journalists, and he can be held contractually responsible if the book if it weren’t true

“What I’ve tried to do is to tell the story of the real people and the specific facts as to how we got the anti-vaccine movement that is today causing all this mischief over SARS-CoV-2 shots.” —Brian Deer

- Peter says listeners should not assume that everything in the book was covered by this podcast
- The book is “incredibly rich with detail”
- Peter read it twice because it’s easy to miss things the first time

**Peter’s closing thoughts (1:44:15)**

- This is not ultimately a book about vaccines but rather about how science can go wrong and be corrupted
- A sad footnote is the children who were “summarily tortured” in the hospital 20 years ago
  - Anyone with a young child, especially a child with autism, knows that these are children in whom any deviation from a normal routine is devastating
  - The kids endured sleeping in a foreign place, bowel prep, having a colonoscope inserted, lumbar punctures, and multiple blood draws
  - And yet “all of this was done without even a modicum of investigational review board oversight” and it was unethical
  - There is no undoing that harm

> “*That’s the kernel of evil that then went on to produce so much angst for so many parents who now are left wondering, ‘Have I done something to cause harm to my child?’*” —Peter Attia

§

## Selected Links / Related Material

**Brian’s book telling the story of Wakefield’s deception:** [*The Doctor Who Fooled the World: Science, Deception, and the War on Vaccines*](https://www.amazon.com/Doctor-Who-Fooled-World-Deception/dp/1421438003) by Brian Deer (2020) | [throughout]

**Surveys on beliefs about vaccines and autism:** [4:00]

*In the United States*:

- [Survey: One third of American parents mistakenly link vaccines to autism](https://nclnet.org/survey_one_third_of_american_parents_mistakenly_link_vaccines_to_autism/) | National Consumers League (April 2, 2014)
- [1 in 5 millennials think vaccines cause autism](https://www.vox.com/2015/1/31/7954725/vaccines-autism-young-adults) | (YouGov survey) German Lopez, *Vox* (January 31, 2015)
- [Survey Shows Anti-Vaccine Arguments Are Starting to Gain Traction](https://www.usnews.com/news/healthiest-communities/articles/2020-01-14/survey-fewer-people-now-support-vaccinating-their-kids-than-in-2001) | (Gallup poll) Gaby Galvin, *U.S. News & World Report* (January 14, 2020)

*In the UK*:

- [Majority of UK public don’t believe vaccines cause autism](https://www.epmmagazine.com/news/majority-of-uk-public-dont-believe-vaccines-cause-autism/) | *European Pharmaceutical Manufacturer* (December 11, 2019)

*Worldwide*:

- [Percentage of respondents in select countries worldwide who believed some vaccines cause autism in healthy children as of 2017](https://www.statista.com/statistics/790868/people-who-believed-vaccines-cause-autism-worldwide-select-countries/) | *Statista* (December 2017)

**Wakefield’s** ***Journal of Virology*** **paper claiming that measles was associated with Crohn’s disease:** [Evidence of persistent measles virus infection in Crohn’s disease](https://onlinelibrary.wiley.com/doi/abs/10.1002/jmv.1890390415), *Journal of Virology* (Wakefield et al. 1993) | [20:00]

**Paper by a Japanese research team reporting that, using PCR, they could not replicate the results of Wakefield’s** ***Journal of Virology*** **paper:** [Absence of measles virus in Crohn’s disease](https://pubmed.ncbi.nlm.nih.gov/7741861/), *The Lancet* (Iizuka et al. 1995) | [20:00]

**Summary of MMR vaccine / autism controversy:** [MMR vaccine and autism](https://en.wikipedia.org/wiki/MMR_vaccine_and_autism) (en.wikipedia.org) | [26:45]

**Wakefield’s infamous paper in the** ***Lancet*** **reporting on a case series of children which suggested that the MMR vaccine was linked to autism (later retracted)**:  [Ileal-lymphoid-nodular hyperplasia, non-specific colitis, and pervasive developmental disorder in children](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(97)11096-0/fulltext), *The Lancet* (Wakefield et al. 1998) | [26:45]

**Jackie Fletcher’s anti-vaccine organization (“a support group for vaccine damaged children”):** [JABS (Justice, Awareness, and Basic Support)](https://www.jabs.org.uk/) **|** [36:15]

**Primer on the PCR technique:** [Polymerase chain reaction](https://en.wikipedia.org/wiki/Polymerase_chain_reaction) (en.wikipedia.org)|  [1:02:00]

**Primer on DNA replication:** [DNA replication](https://en.wikipedia.org/wiki/DNA_replication) (en.wikipedia.org) | [1:03:15]

**Abstract of Nick Chadwick’s thesis revealing that no measles virus was found in the bowel samples from Wakefield’s study**: [Abstract of *Molecular Strategies for the Detection of Measles Virus in Inflammatory Bowel Disease*](https://briandeer.com/wakefield/nick-chadwick.htm) (Chadwick 1998) **|** [1:22:15]

**Summary of the Enron scandal and its consequences**: [Enron scandal](https://en.wikipedia.org/wiki/Enron_scandal) (en.wikipedia.org)| [1:30:00]

**Summary of the Volkswagen emission recording scandal and its consequences**: [Volkswagen emissions scandal](https://en.wikipedia.org/wiki/Volkswagen_emissions_scandal) (en.wikipedia.org) | [1:30:00]

**Episode of** ***Dispatches*** **over which Wakefield sued Brian and a television station**: [MMR – What they didn’t tell you](https://www.youtube.com/watch?v=7UbL8opM6TM) (November 2004) | [1:31:45]

**Article about Andrew Wakefield losing his medical license:** [British Medical Council Bars Doctor Who Linked Vaccine with Autism](https://www.nytimes.com/2010/05/25/health/policy/25autism.html) John F. Burns, *The New York Times* (May 24, 2010) | [1:35:30]

**Announcement of retraction of Wakefield’s 1998 Lancet paper**: [Retraction — Ileal-lymphoid-nodular hyperplasia, non-specific colitis, and pervasive developmental disorder in children](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(10)60175-4/fulltext), *The Lancet* (Editors of *The Lancet* 2010) | [1:35:30]

***BMJ*** **editorial introducing Brian’s series on Wakefield**: [The fraud behind the MMR scare](https://www.bmj.com/content/342/bmj.d22) **|** Fiona Godlee, *British Medical Journal* (January 6, 2011) | [1:36:00]

**Articles from Brian’s series on Wakefield in the** ***British Medical Journal***: [Secrets of the MMR scare](https://briandeer.com/solved/bmj-secrets-series.htm) | [1:36:00]

- [Piltdown medicine: the missing link between MMR and autism](https://blogs.bmj.com/bmj/2011/01/06/brian-deer-piltdown-medicine-the-missing-link-between-mmr-and-autism/) (January 6, 2011)
- [How the case against the MMR vaccine was fixed](https://www.bmj.com/content/342/bmj.c5347) (January 6, 2011)
- [How the vaccine crisis was meant to make money](https://www.bmj.com/content/342/bmj.c5258) (January 11, 2011)
- [*The Lancet*‘s two days to bury bad news](https://pubmed.ncbi.nlm.nih.gov/21245118/) (January 18, 2011)
- [Pathology reports solve “new bowel disease” riddle](https://www.bmj.com/content/343/bmj.d6823) (November 9, 2011)

**More information about the “CDC whistleblower”**: [A Congressman, A CDC Whisteblower and an Autism Tempest in a Trashcan](https://www.forbes.com/sites/emilywillingham/2015/08/06/a-congressman-a-cdc-whisteblower-and-an-autism-tempest-in-a-trashcan/?sh=65a9f93c5396) **|** Emily Willingham, *Forbes* (August 6, 2015) | [1:36:30]

**Wakefield’s anti-vaccine movie**: [*Vaxxed*](https://vaxxedthemovie.com/) (2016)| [1:36:30]

**Discussion of inaccuracies in Wakefield’s movie** ***Vaxxed***: [7 things about vaccines and autism that the movie ‘Vaxxed’ won’t tell you](https://www.washingtonpost.com/news/to-your-health/wp/2016/05/25/7-things-about-vaccines-and-autism-that-the-movie-vaxxed-wont-tell-you/) | Ariana Eunjung Cha, *The Washington Post* (May 25, 2016) |[1:36:30]

**Article on responding to anti-vaccine advocates that Peter quoted to Brian**: [The age-old struggle against the antivaccinationists](https://pubmed.ncbi.nlm.nih.gov/21226573/), *The New England Journal of Medicine* (Poland & Jacobson 2011) | [1:39:30]

§

## People Mentioned

- [Andrew Wakefield](https://en.wikipedia.org/wiki/Andrew_Wakefield) [throughout]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) [14:15]
- [Thomas MacDonald](https://experts.webapps.qmul.ac.uk/expert.php?id=134) (British gastroenterologist and immunologist who suspected Wakefield’s fraud early in the process) [22:00]
- [Richard Barr](https://en.wikipedia.org/wiki/MMR_vaccine_and_autism) (British lawyer who sought to sue doctors and vaccine manufacturers for vaccine-related injuries, paid Wakefield large sums of money, and obtained legal aid funding for the 1998 study) [28:30, 31:30, 32:45, 1:13:15]
- [Jackie Fletcher](https://briandeer.com/wakefield/jackie-fletcher-jabs.htm) (Founder of JABS who hoped to sue vaccine manufacturers and helped recruit patients for the 1998 *Lancet* study) [31:30, 32:30, 32:45, 36:15, 1:33:00]
- [John O’Leary](https://briandeer.com/mmr/oleary-pcr.htm) (Scottish doctor on Richard Barr’s payroll who claimed to have found measles in Wakefield’s 1998 study samples using heavily criticized lab techniques) [51:30, 1:00:24, 1:10:15, 1:13:15, 1:27:15]
- [Simon Murch](https://www.thelancet.com/journals/lancet/article/PIIS0140673604157085/fulltext) (Colleague of Wakefield who scoped many of the children for the 1998 *Lancet* study and was investigated along with Wakefield and Walker-Smith but ultimately did not lose his medical license) [53:30]
- [Michael A. Thomson](https://www.paediatricgastroenterologist.co.uk/index.php/about) (Gastroenterologist who was a co-author of the 1998 *Lancet* paper and scoped a few of the children for the study) [53:30]
- [Patrick O. Brown](https://en.wikipedia.org/wiki/Patrick_O._Brown) [57:30]
- [Kary Mullis](https://en.wikipedia.org/wiki/Kary_Mullis) (American biochemist who shared the 1993 Nobel Prize in Chemistry for developing the PCR technique) [1:02:45]
- [Anthony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci) [1:11:00]
- [Nick Chadwick](https://centerforinquiry.org/wp-content/uploads/sites/33/quackwatch/QQ_Chadwick_Declaration_98-916.pdf) (PhD student who worked with Wakefield on the study but found no measles virus in the samples) [53:30, 1:22:15]
- [Stephen Bustin](https://en.wikipedia.org/wiki/Stephen_Bustin) (British PCR expert) [1:26:15, 01:27:15]
- [Bernard](https://en.wikipedia.org/wiki/Bernard_Selz) [and Lisa Seltz](https://www.washingtonpost.com/national/health-science/meet-the-new-york-couple-donating-millions-to-the-anti-vax-movement/2019/06/18/9d791bcc-8e28-11e9-b08e-cfd89bd36d4e_story.html) (New York financiers who funded Wakefield’s lawsuit against Brian in Texas) [1:36:00]

§

![](https://peterattiamd.com/wp-content/uploads/2021/04/bio-briandeer-500x500.png)

##### Brian Deer

Brian Deer is an award-winning investigative journalist for the London-based *The Sunday Times* who focuses on medicine, particularly the pharmaceutical industry, and social issues; topics he has covered include the withdrawn Merck painkiller Vioxx, an ill-fated drug trial of an experimental monoclonal antibody, and false claims about a link between the MMR vaccine and autism.  The author of *The Doctor Who Fooled the World: Science, Deception, and the War on Vaccines*, Deer won a British Press Award in 1999 and 2011 and the annual HealthWatch award in 2011.  He is a graduate of the University of Warwick.

Website: [briandeer.com](https://briandeer.com/)

Twitter: [@deerbrian](https://twitter.com/deerbrian)